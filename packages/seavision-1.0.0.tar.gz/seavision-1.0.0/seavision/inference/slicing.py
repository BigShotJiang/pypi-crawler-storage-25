"""Slicing module for SeaVision."""

import math
from typing import TYPE_CHECKING, List, Tuple

import numpy as np
from PIL import Image
from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from .infer_abc import Infer

if TYPE_CHECKING:
    from sahi.slicing import SliceImageResult


class SlicingError(ValueError):
    """Raised when an unsupported batch size is provided."""


class AutoSlicer:
    """Automatically calculate image slicing parameters based on batch size."""

    def __init__(self, slice_width: int, slice_height: int):
        """Initialize the AutoSlicer."""
        self.slice_width = slice_width
        self.slice_height = slice_height

    @classmethod
    def from_model(cls, model: Infer) -> "AutoSlicer":
        """Create an AutoSlicer from a model."""
        slice_height, slice_width = model.input_hw
        return cls(slice_width, slice_height)

    def slice(
        self, im: np.ndarray, image_shape: Tuple[int, int], num_slices: int
    ) -> "SliceImageResult":
        """Calculate the slicing parameters based on the batch size.

        Args:
            im: The image to slice.
            image_shape: The shape of the image to slice (width, height).
            num_slices: The number of images to slice.

        Returns:
            SliceImageResult: The result of slicing the image.
        """
        from sahi.slicing import slice_image

        slices_horizontal, slices_vertical = self._find_number_of_slices(
            num_slices, image_shape
        )
        horizontal_overlap, vertical_overlap = self._calculate_overlaps(
            image_shape, slices_horizontal, slices_vertical
        )

        slice_image_result = slice_image(
            image=Image.fromarray(im),
            output_file_name=None,
            output_dir=None,
            slice_height=self.slice_height,
            slice_width=self.slice_width,
            overlap_height_ratio=vertical_overlap,
            overlap_width_ratio=horizontal_overlap,
        )

        return slice_image_result

    def _calculate_axis_overlap(
        self, image_size: int, slice_size: int, num_slices: int
    ) -> float:
        """Calculate overlap percentage for a single axis."""
        if num_slices == 1 or slice_size >= image_size:
            return 0.0

        total_needed = slice_size * num_slices
        if total_needed <= image_size:
            return 0.0

        total_overlap = total_needed - image_size
        overlap_per_intersection = total_overlap / (num_slices - 1)
        return overlap_per_intersection / slice_size

    def _calculate_overlaps(
        self, image_shape: Tuple[int, int], slices_horizontal: int, slices_vertical: int
    ) -> Tuple[float, float]:
        """Calculate the overlap percentages needed to fit the requested number of slices."""
        horizontal = self._calculate_axis_overlap(
            image_shape[1], self.slice_width, slices_horizontal
        )
        vertical = self._calculate_axis_overlap(
            image_shape[0], self.slice_height, slices_vertical
        )
        return horizontal, vertical

    def _find_factorizations(
        self, n: int, image_shape: Tuple[int, int]
    ) -> List[Tuple[int, int]]:
        """Find all factorizations of a number, adjusting for image orientation.

        Args:
            n: The number to factorize.
            image_shape: The shape of the image to slice (height, width).

        Returns:
            A list of (horizontal_slices, vertical_slices) tuples.
        """
        is_landscape = image_shape[0] < image_shape[1]
        factorizations = [
            (n // i, i) for i in range(1, math.isqrt(n) + 1) if n % i == 0
        ]
        return factorizations if is_landscape else [(v, h) for h, v in factorizations]

    def _find_number_of_slices(
        self, num_slices: int, image_shape: Tuple[int, int]
    ) -> Tuple[int, int]:
        """Find the optimal arrangement of slices to cover an image.

        Args:
            num_slices: Total number of slices to divide the image into
            image_shape: Dimensions of the image as (height, width)

        Returns:
            Tuple of (horizontal_slices, vertical_slices)

        Raises:
            SlicingError: If no valid slice arrangement is found or multiple arrangements exist
        """
        image_height, image_width = image_shape

        # Find valid slice arrangements
        valid_slices = [
            (h, v)
            for h, v in self._find_factorizations(num_slices, image_shape)
            if h * self.slice_width >= image_width
            and v * self.slice_height >= image_height
        ]

        if len(valid_slices) == 0:
            raise SlicingError("Not enough slices to cover the full image")
        if len(valid_slices) == 1:
            return valid_slices[0]
        raise SlicingError("Multiple valid slicing possibilities found")


class ModelValidator(BaseModel):
    """Pydantic model for validating AHOY models."""

    model_str: str
    ahoy_model: Infer
    supported_batch_sizes: List[int]

    # Add configuration to allow arbitrary types
    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_validator("model_str")
    @classmethod
    def validate_ahoy_string(cls, v: str) -> str:
        """Validate that the model string is an AHOY model."""
        if "ahoy" not in v:
            raise ValueError("Model must be an AHOY model")
        return v

    @model_validator(mode="after")  # Ensures all fields are validated first
    def validate_batch_size(self) -> "ModelValidator":
        """Validate that the model has a supported batch size."""
        if (
            hasattr(self.ahoy_model, "input_bs")
            and self.ahoy_model.input_bs not in self.supported_batch_sizes
        ):
            raise ValueError(
                f"Model must have an input batch size in {self.supported_batch_sizes} "
                f"but got {self.ahoy_model.input_bs}"
            )
        return self


class ModelValidationMixin:
    """Mixin for validating AHOY-based models."""

    def validate_model(self, model_path: str, supported_batch_sizes: List[int]) -> None:
        """Run validation for the given model."""
        ModelValidator(
            model_str=model_path,
            ahoy_model=self.model,
            supported_batch_sizes=supported_batch_sizes,  # Passed at runtime
        )
