"""Classes to hold inference results."""

import logging
import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .postprocessing import (
    hough_params_to_image_edges,
    hough_params_to_slope_intercept,
    image_edges_to_hough_params,
    image_edges_to_slope_intercept,
    slope_intercept_to_hough_params,
    slope_intercept_to_image_edges,
)
from .utils import LabelEncoder

logger = logging.getLogger(__name__)


if TYPE_CHECKING:
    import fiftyone as fo
    import fiftyone.core.sample as fos


SEMANTIC_COLOR_MAP = {
    "WATER": (0, 127, 200),  # Brighter deep blue
    "LAND": (34, 177, 76),  # Vibrant forest green
    "SKY": (135, 226, 255),  # Brighter sky blue
}

PALETTE = [
    (0, 105, 148),  # Deep ocean blue
    (0, 168, 107),  # Seafoam green
    (255, 140, 0),  # Safety orange
    (0, 191, 255),  # Deep sky blue
    (139, 69, 19),  # Ship brown
    (220, 20, 60),  # Life vest red
    (240, 230, 140),  # Sandy beach
    (70, 130, 180),  # Steel blue
    (255, 215, 0),  # Buoy yellow
    (47, 79, 79),  # Dark slate gray
]


@dataclass
class CoordinateConversion:
    """Class to hold bounding box conversion information."""

    image_width: int
    image_height: int

    def normalized(self, bbox: List[float]) -> List[float]:
        """Convert bounding box to [0, 1] range."""
        return [
            bbox[0] / self.image_width,
            bbox[1] / self.image_height,
            bbox[2] / self.image_width,
            bbox[3] / self.image_height,
        ]

    def absolute(self, bbox: List[float]) -> List[float]:
        """Convert bounding box to absolute pixel values."""
        return [
            bbox[0] * self.image_width,
            bbox[1] * self.image_height,
            bbox[2] * self.image_width,
            bbox[3] * self.image_height,
        ]


@dataclass
class BBox:
    """Class to hold bounding box information."""

    xyxy: Optional[List[float]] = field(default=None, repr=False)
    xyxy_n: Optional[List[float]] = field(default=None, repr=False)
    xywh: Optional[List[float]] = field(default=None, repr=True)
    xywh_n: Optional[List[float]] = field(default=None, repr=True)
    cxcywh: Optional[List[float]] = field(default=None, repr=False)
    cxcywh_n: Optional[List[float]] = field(default=None, repr=False)

    def update_formats(self, conversion: CoordinateConversion) -> None:
        """Update all formats of the bounding box."""
        if self.xyxy is not None:
            self.xywh = self.xyxy_to_xywh(self.xyxy)
            self.cxcywh = self.xywh_to_cxcywh(self.xywh)
        if self.xywh is not None:
            self.cxcywh = self.xywh_to_cxcywh(self.xywh)
            self.xyxy = self.cxcywh_to_xyxy(self.cxcywh)
        if self.cxcywh is not None:
            self.xyxy = self.cxcywh_to_xyxy(self.cxcywh)
            self.xywh = self.xyxy_to_xywh(self.xyxy)

        if self.xyxy_n is not None:
            self.xywh_n = self.xyxy_to_xywh(self.xyxy_n)
            self.cxcywh_n = self.xywh_to_cxcywh(self.xywh_n)
        if self.xywh_n is not None:
            self.cxcywh_n = self.xywh_to_cxcywh(self.xywh_n)
            self.xyxy_n = self.cxcywh_to_xyxy(self.cxcywh_n)
        if self.cxcywh_n is not None:
            self.xyxy_n = self.cxcywh_to_xyxy(self.cxcywh_n)
            self.xywh_n = self.xyxy_to_xywh(self.xyxy_n)

        if all(fmt is None for fmt in [self.xyxy, self.xywh, self.cxcywh]):
            self._update_all_absolute(conversion)
        elif all(fmt is None for fmt in [self.xyxy_n, self.xywh_n, self.cxcywh_n]):
            self._update_all_normalized(conversion)

    def _update_all_normalized(self, conversion: CoordinateConversion) -> None:
        """Update all normalized formats of the bounding box."""
        self.xywh_n = conversion.normalized(self.xywh)
        self.xyxy_n = conversion.normalized(self.xyxy)
        self.cxcywh_n = conversion.normalized(self.cxcywh)

    def _update_all_absolute(self, conversion: CoordinateConversion) -> None:
        """Update all absolute formats of the bounding box."""
        self.xywh = conversion.absolute(self.xywh_n)
        self.xyxy = conversion.absolute(self.xyxy_n)
        self.cxcywh = conversion.absolute(self.cxcywh_n)

    @staticmethod
    def xyxy_to_xywh(xyxy: List[float]) -> List[float]:
        """Convert [x1, y1, x2, y2] to [x, y, w, h]."""
        x1, y1, x2, y2 = xyxy
        return [x1, y1, x2 - x1, y2 - y1]

    @staticmethod
    def xywh_to_cxcywh(xywh: List[float]) -> List[float]:
        """Convert [x, y, w, h] to [cx, cy, w, h]."""
        x, y, w, h = xywh
        return [x + w / 2, y + h / 2, w, h]

    @staticmethod
    def cxcywh_to_xyxy(cxcywh: List[float]) -> List[float]:
        """Convert [cx, cy, w, h] to [x1, y1, x2, y2]."""
        cx, cy, w, h = cxcywh
        return [cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2]

    @property
    def area(self) -> float:
        """Bounding box area."""
        _, _, w, h = self.xywh
        return w * h

    @property
    def area_n(self) -> float:
        """Normalized bounding box area."""
        _, _, w, h = self.xywh_n
        return w * h

    @property
    def center(self) -> List[float]:
        """Bounding box center."""
        x, y, w, h = self.xywh
        return [x + w / 2, y + h / 2]

    @property
    def center_n(self) -> List[float]:
        """Normalized bounding box center."""
        x, y, w, h = self.xywh_n
        return [x + w / 2, y + h / 2]

    @property
    def aspect_ratio(self) -> float:
        """Bounding box aspect ratio."""
        _, _, w, h = self.xywh
        return w / h


@dataclass
class Object:
    """Class to hold object information."""

    bbox: BBox
    score: float
    class_name: Optional[str] = None
    class_id: Optional[int] = None
    p_class_given_bbox: Optional[float] = None

    def __post_init__(self) -> None:
        self.score = self.score if self.score is not None else 1.0
        self.class_id = int(self.class_id) if self.class_id is not None else None

    @property
    def p_class(self) -> Optional[float]:
        """Class probability.

        Computes p(class) by multiplying the class probability given the box
        with the objectness score:  p_class = p(class | bbox) * p(object).

        Returns:
            float: Joint class probability or None if p_class_given_bbox is undefined.
        """
        return (
            self.p_class_given_bbox * self.score
            if self.p_class_given_bbox is not None
            else None
        )


@dataclass
class Line:
    """Class to hold line information."""

    xyxy: Optional[List[float]] = None
    xyxy_n: Optional[List[float]] = None
    rho: Optional[float] = None
    theta: Optional[float] = None
    slope: Optional[float] = None
    intercept: Optional[float] = None

    def update_formats(self, conversion: CoordinateConversion) -> None:
        """Update all formats of the line."""
        if self.xyxy is not None:
            self._from_xyxy(conversion)
        elif self.xyxy_n is not None:
            self._from_xyxy_n(conversion)
        elif self.rho is not None and self.theta is not None:
            self._from_hough(conversion)
        elif self.slope is not None and self.intercept is not None:
            self._from_slope_intercept(conversion)
        else:
            raise ValueError(
                "At least one of xyxy, rho/theta, or slope/intercept must be provided."
            )

    def _from_xyxy(self, conversion: CoordinateConversion) -> None:
        """Initialize the line from image edges."""
        self.xyxy_n = conversion.normalized(self.xyxy)
        self.rho, self.theta = image_edges_to_hough_params(*self.xyxy)
        self.slope, self.intercept = image_edges_to_slope_intercept(*self.xyxy)

    def _from_xyxy_n(self, conversion: CoordinateConversion) -> None:
        """Initialize the line from normalized image edges."""
        self.xyxy = conversion.absolute(self.xyxy_n)
        self.rho, self.theta = image_edges_to_hough_params(*self.xyxy)
        self.slope, self.intercept = image_edges_to_slope_intercept(*self.xyxy)

    def _from_hough(self, conversion: CoordinateConversion) -> None:
        """Initialize the line from Hough parameters."""
        self.xyxy = hough_params_to_image_edges(
            self.rho,
            self.theta,
            (conversion.image_height, conversion.image_width),
        )
        self.xyxy_n = conversion.normalized(self.xyxy)
        self.slope, self.intercept = hough_params_to_slope_intercept(
            self.rho, self.theta
        )

    def _from_slope_intercept(self, conversion: CoordinateConversion) -> None:
        """Initialize the line from slope and intercept."""
        self.xyxy = slope_intercept_to_image_edges(
            self.slope,
            self.intercept,
            (conversion.image_height, conversion.image_width),
        )
        self.xyxy_n = conversion.normalized(self.xyxy)
        self.rho, self.theta = slope_intercept_to_hough_params(
            self.slope, self.intercept
        )

    @property
    def length(self) -> Optional[float]:
        """Compute the length of the line."""
        if self.xyxy is None:
            return None  # Return None if no endpoints are available

        x1, y1, x2, y2 = self.xyxy
        return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)


@dataclass
class Horizon:
    """Class to hold horizon information."""

    line: Line
    score: float
    class_name: Optional[str] = None
    class_id: Optional[int] = None

    def __post_init__(self) -> None:
        self.score = self.score if self.score is not None else 1.0
        self.class_id = int(self.class_id) if self.class_id is not None else None


@dataclass
class SemantickMask:
    """Class to hold semantic mask information."""

    bbox: BBox
    mask: np.ndarray
    class_name: Optional[str] = None
    class_id: Optional[int] = None

    def __post_init__(self) -> None:
        self.class_id = int(self.class_id) if self.class_id is not None else None


@dataclass
class Results:
    """Class to hold inference results."""

    objects: Optional[List[Object]]
    horizon: Optional[Horizon]
    image_width: int
    image_height: int
    masks: Optional[List[SemantickMask]] = None

    def __post_init__(self) -> None:
        if self.objects is not None:
            for obj in self.objects:
                obj.bbox.update_formats(
                    CoordinateConversion(self.image_width, self.image_height)
                )
        if self.masks is not None:
            for mask in self.masks:
                mask.bbox.update_formats(
                    CoordinateConversion(self.image_width, self.image_height)
                )
        if self.horizon is not None:
            self.horizon.line.update_formats(
                CoordinateConversion(self.image_width, self.image_height)
            )

    def apply_homography(
        self, homography_matrix: np.ndarray, new_width: int, new_height: int
    ) -> "Results":
        """Apply the homography transform and return a new Results object."""
        new_objects = []
        if self.objects is not None:
            for obj in self.objects:
                new_bbox = Results._transform_bbox(
                    homography_matrix, obj.bbox, new_width, new_height
                )
                new_objects.append(
                    Object(
                        bbox=new_bbox,
                        score=obj.score,
                        class_name=obj.class_name,
                        class_id=obj.class_id,
                    )
                )

        new_horizon = None
        if self.horizon is not None:
            new_line = Results._transform_line(
                homography_matrix, self.horizon.line, new_width, new_height
            )
            new_horizon = Horizon(
                line=new_line,
                score=self.horizon.score,
                class_name=self.horizon.class_name,
                class_id=self.horizon.class_id,
            )

        return Results(
            objects=new_objects,
            horizon=new_horizon,
            image_width=new_width,
            image_height=new_height,
        )

    @staticmethod
    def _transform_point(
        homography_matrix: np.ndarray, point: List[float]
    ) -> List[float]:
        """Apply homography transform to a single point."""
        homogeneous_point = np.array([point[0], point[1], 1])
        transformed_point = np.dot(homography_matrix, homogeneous_point)
        transformed_point /= transformed_point[2]  # Normalize
        return list(transformed_point[:2])

    @staticmethod
    def _transform_bbox(
        homography_matrix: np.ndarray, bbox: BBox, new_width: int, new_height: int
    ) -> BBox:
        """Apply homography transform to a bounding box."""
        transformed_xyxy = [
            Results._transform_point(homography_matrix, bbox.xyxy[:2]),
            Results._transform_point(homography_matrix, bbox.xyxy[2:]),
        ]
        # clip the transformed bounding box
        transformed_xyxy = Results._clip_bbox_pts(
            transformed_xyxy, new_width, new_height
        )
        transformed_bbox = BBox(xyxy=[*transformed_xyxy[0], *transformed_xyxy[1]])
        transformed_bbox.update_formats(CoordinateConversion(new_width, new_height))
        return transformed_bbox

    @staticmethod
    def _transform_line(
        homography_matrix: np.ndarray, line: Line, new_width: int, new_height: int
    ) -> Line:
        """Apply homography transform to a line."""
        transformed_xyxy = [
            Results._transform_point(homography_matrix, line.xyxy[:2]),
            Results._transform_point(homography_matrix, line.xyxy[2:]),
        ]
        transformed_xyxy = Results._clip_line_pts(transformed_xyxy, new_width)
        transformed_line = Line(xyxy=[*transformed_xyxy[0], *transformed_xyxy[1]])
        transformed_line.update_formats(CoordinateConversion(new_width, new_height))
        return transformed_line

    @staticmethod
    def _clip_bbox_pts(
        pts: List[List[float]], new_width: int, new_height: int
    ) -> List[List[float]]:
        """Clip points to the image size."""
        return np.clip(pts, [0, 0], [new_width, new_height]).tolist()

    @staticmethod
    def _clip_line_pts(pts: List[List[float]], new_width: int) -> List[List[float]]:
        """Clip points to the image size."""
        # get line slope and intercept
        m = (pts[1][1] - pts[0][1]) / (pts[1][0] - pts[0][0])
        b = pts[0][1] - m * pts[0][0]
        # find y-coord for 0 and new_width
        y1 = m * 0 + b
        y2 = m * new_width + b
        # clip points
        pts = np.clip(pts, [0, y1], [new_width, y2]).tolist()
        return pts

    @staticmethod
    def get_line_thickness(
        image_height: int,
        image_width: int,
        base_ratio: float = 0.0015,
        min_px: int = 1,
        max_px: int = 5,
    ) -> int:
        """Compute line thickness based on image size.

        Args:
            image_height: Height of the image.
            image_width: Width of the image.
            base_ratio: Ratio of diagonal length to use as the base thickness.
            min_px: Minimum thickness.
            max_px: Maximum thickness.

        Returns:
            int: Thickness in pixels
        """
        diag = np.sqrt(image_height**2 + image_width**2)
        thickness = int(round(diag * base_ratio))
        return max(min_px, min(thickness, max_px))

    def draw(
        self,
        image: np.ndarray,
        bbox_color: tuple = (0, 255, 0),
        line_color: tuple = (255, 255, 0),
        thickness: int = -1,
        show_labels: bool = False,
        show_horizon: bool = True,
        save_to: Optional[str] = None,
        as_pil: bool = False,
    ) -> Union[np.ndarray, Image.Image]:
        """Draw predictions on image using PIL.

        Args:
            image: Image to draw on. If the image is of type `np.uint16`, it will be
                normalized to `np.uint8` before drawing. If the image is grayscale,
                it will be converted to BGR.
            bbox_color: RGB Color of the bounding boxes. Defaults to (0, 255, 0).
            line_color: RGB Color of the horizon line. Defaults to (255, 255, 0).
            thickness: Thickness of the line. Defaults to -1 (auto from image size).
            show_labels: Whether to show the class name of the bounding boxes.
            show_horizon: Whether to show the horizon line.
            save_to: Path to save the image. If not provided, the image won't be saved.
            as_pil: Whether to return the image as a PIL image. Defaults to `False`.

        Returns:
            Copy of the image with the predictions drawn on it. If `as_pil` is `True`,
            the image will be returned as a PIL image. Otherwise, the image will be
            returned as a numpy array.
        """
        # Normalize if dtype is uint16
        if isinstance(image, np.ndarray) and image.dtype == np.uint16:
            _max, _min = image.max(), image.min()
            image = ((image - _min) / (_max - _min) * 255).astype(np.uint8)

        im = Image.fromarray(image.squeeze()).convert("RGB")
        draw = ImageDraw.Draw(im)
        font = ImageFont.load_default(size=max(min(int(0.02 * im.height), 25), 10))
        thickness = (
            self.get_line_thickness(im.height, im.width)
            if thickness == -1
            else thickness
        )

        self._draw_objects(draw, font, thickness, show_labels, bbox_color)
        if self.horizon is not None and show_horizon:
            self._draw_horizon(draw, font, thickness, line_color)
        if self.masks is not None:
            im = self._draw_masks(draw)

        # Save the im if the path is provided
        if save_to:
            im.save(save_to)

        return im if as_pil else np.array(im)

    def _draw_objects(
        self,
        draw: ImageDraw.ImageDraw,
        font: ImageFont.FreeTypeFont,
        thickness: int,
        show_labels: bool,
        bbox_color: tuple,
    ) -> None:
        # Draw bounding boxes and scores
        im = draw._image  # pylint: disable=protected-access
        for obj in self.objects:
            x1, y1, x2, y2 = np.array(obj.bbox.xyxy_n) * np.array(
                [im.width, im.height, im.width, im.height]
            )
            draw.rectangle([x1, y1, x2, y2], outline=bbox_color, width=thickness)
            draw.text(
                (x1, y1),
                f"{obj.score:.2f}" + (f" ({obj.class_name})" if show_labels else ""),
                font=font,
                fill=bbox_color,
            )

    def _draw_horizon(
        self,
        draw: ImageDraw.ImageDraw,
        font: ImageFont.FreeTypeFont,
        thickness: int,
        line_color: tuple,
    ) -> None:
        """Draw horizon line on the image."""
        im = draw._image  # pylint: disable=protected-access
        x1, y1, x2, y2 = np.array(self.horizon.line.xyxy_n) * np.array(
            [im.width, im.height, im.width, im.height]
        )
        draw.line([x1, y1, x2, y2], fill=line_color, width=thickness)
        draw.text((x1, y1), f"{self.horizon.score:.2f}", font=font, fill=line_color)

    def _draw_masks(
        self,
        draw: ImageDraw.ImageDraw,
        alpha: float = 0.75,
        color_map: Optional[dict[str, tuple[int, int, int]]] = None,
    ) -> Image.Image:
        """Draw segmentation masks on the image with alpha blending.

        Args:
            draw: PIL ImageDraw object
            alpha: Opacity of original image (0-1), mask is (1-alpha)
            color_map: Dictionary of class names to colors. If None, uses the default
                semantic color map.

        Returns:
            PIL Image with masks drawn
        """
        # Convert PIL image to numpy array
        image = np.array(draw._image, dtype=np.uint8)  # pylint: disable=protected-access

        if self.masks is None:
            return Image.fromarray(image)

        if color_map is None:
            color_map = SEMANTIC_COLOR_MAP

        for i, mask in enumerate(self.masks):
            # Get mask region
            x1, y1, x2, y2 = map(int, mask.bbox.xyxy)
            mask_region = np.array(mask.mask)[..., None]
            color = np.array(
                color_map.get(mask.class_name, PALETTE[i % len(PALETTE)]),
                dtype=np.uint8,
            )

            # Alpha blend mask with image
            region = image[y1:y2, x1:x2]
            blended = (region * alpha + color * (1 - alpha)).astype(np.uint8)
            image[y1:y2, x1:x2] = np.where(mask_region == 1, blended, region)

        return Image.fromarray(image)

    def to_fo_detections(self) -> "fo.Detections":
        """Convert results to FiftyOne detections."""
        import fiftyone as fo

        detections = []
        for obj in self.objects:
            detections.append(
                fo.Detection(
                    label=obj.class_name,
                    bounding_box=obj.bbox.xywh_n,
                    confidence=obj.score,
                    p_class_given_bbox=obj.p_class_given_bbox,
                    area=int(np.prod(obj.bbox.xywh[2:])),
                )
            )
        if self.masks is not None:
            for mask in self.masks:
                detections.append(
                    fo.Detection(
                        label=mask.class_name,
                        bounding_box=mask.bbox.xywh_n,
                        confidence=1.0,  # Assuming mask confidence is always 1.0
                        area=int(np.prod(mask.bbox.xywh[2:])),
                        mask=mask.mask,
                    )
                )
        return fo.Detections(detections=detections)

    def to_fo_polylines(self) -> "fo.Polylines":
        """Convert results to FiftyOne polylines."""
        import fiftyone as fo

        polylines = []
        if self.horizon is not None:
            x1, y1, x2, y2 = self.horizon.line.xyxy_n
            polylines.append(
                fo.Polyline(
                    label=self.horizon.class_name,
                    points=[[(x1, y1), (x2, y2)]],
                    confidence=self.horizon.score,
                    closed=False,
                    filled=False,
                )
            )
        return fo.Polylines(polylines=polylines)

    @classmethod
    def from_louisnet_output(
        cls,
        output: Sequence[Sequence],
        image_hw: Sequence[int],
        label_encoder: Optional[LabelEncoder] = None,
    ) -> "Results":
        """Convert LouisNet output to InferResults.

        LouisNet output has the form
        [np.ndarray(yxyx_n), class_name, class_id, score]
        """
        objects = []
        horizon = None
        for predictions in output:
            bbox, class_name, class_id, score = predictions
            if bbox is None:
                continue

            x1, y1, x2, y2 = bbox.tolist()
            if class_name.upper() == "HORIZON":
                horizon = Horizon(
                    line=Line(xyxy_n=[x1, y1, x2, y2]),
                    score=score,
                    class_name=class_name,
                    class_id=(
                        class_id
                        if not label_encoder
                        else label_encoder.transform([class_name]).item()
                    ),
                )
            else:
                objects.append(
                    Object(
                        bbox=BBox(xyxy_n=[x1, y1, x2, y2]),
                        score=score,
                        class_name=class_name,
                        class_id=(
                            class_id
                            if not label_encoder
                            else label_encoder.transform([class_name]).item()
                        ),
                    )
                )
        return cls(
            objects=objects,
            horizon=horizon,
            image_width=image_hw[1],
            image_height=image_hw[0],
        )

    @classmethod
    def from_yolo_output(
        cls,
        output: Sequence[np.ndarray],
        image_hw: Sequence[int],
        cls_map: Dict[int, str],
        label_encoder: Optional[LabelEncoder] = None,
        include_horizon: bool = False,
    ) -> "Results":
        """Convert YOLO output to Results.

        This is the base method for converting model predictions to Results objects.
        Can handle both object-only detection and combined object+horizon detection.

        Args:
            output: Sequence of prediction arrays, each of shape (N, 7) where:
                N is the number of detected bounding boxes,
                first 4 are the coordinates of the bounding box (x1, y1, x2, y2),
                5th is the confidence score of the bounding box,
                6th is the class label of the detected bounding box,
                7th is the class probability given bbox.
            image_hw: Image height and width.
            cls_map: Class mapping from class IDs to class names.
            label_encoder: Optional label encoder for class name transformation.
            include_horizon: If True, process HORIZON class as a Horizon object.
                If False, skip HORIZON class entirely (objects only).

        Returns:
            Results object with objects and optionally horizon.
        """

        def parse_prediction(pred: np.ndarray) -> tuple:
            xyxy = pred[:4].tolist()
            score, raw_class_id, p_class_given_bbox = (*pred[4:].tolist(), None)[:3]
            class_name = cls_map[int(raw_class_id)]
            class_id = (
                label_encoder.transform([class_name]).item()
                if label_encoder
                else int(raw_class_id)
            )
            return xyxy, score, class_id, class_name, p_class_given_bbox

        objects = []
        horizon = None

        for pred in output:
            xyxy, score, class_id, class_name, p_class_given_bbox = parse_prediction(
                pred
            )

            if class_name.upper() == "HORIZON":
                if include_horizon:
                    horizon = Horizon(
                        line=Line(xyxy=xyxy),
                        score=score,
                        class_name=class_name,
                        class_id=class_id,
                    )
            else:
                objects.append(
                    Object(
                        bbox=BBox(xyxy=xyxy),
                        score=score,
                        class_name=class_name,
                        p_class_given_bbox=p_class_given_bbox,
                        class_id=class_id,
                    )
                )

        return cls(
            objects=objects,
            horizon=horizon,
            image_width=image_hw[1],
            image_height=image_hw[0],
        )

    @classmethod
    def from_ahoy_output(
        cls,
        output: Sequence[np.ndarray],
        image_hw: Sequence[int],
        cls_map: Dict[int, str],
        label_encoder: Optional[LabelEncoder] = None,
    ) -> "Results":
        """Convert AHOY output to Results (objects + horizon).

        AHOY extends YOLO with horizon detection capabilities.

        Args:
            output: Sequence of prediction arrays from AHOY model.
            image_hw: Image height and width.
            cls_map: Class mapping from class IDs to class names.
            label_encoder: Optional label encoder for class name transformation.

        Returns:
            Results object with both objects and horizon.
        """
        return cls.from_yolo_output(
            output=output,
            image_hw=image_hw,
            cls_map=cls_map,
            label_encoder=label_encoder,
            include_horizon=True,
        )

    @classmethod
    def from_yolo_ln_output(
        cls,
        output: Dict[str, Any],
        image_hw: Sequence[int],
        cls_map: Dict[int, str],
        background_labels: List[str],
    ) -> "Results":
        """Convert LN_YOLO output to ImageResults.

        Args:
            output: LN_YOLO output.
            image_hw: Image height and width.
            cls_map: Class map.
            background_labels: Background labels.
        """
        objects = []
        back_ground_masks = []
        for i in range(len(output["boxes"])):
            if cls_map[output["labels"][i]] not in background_labels:
                objects.append(
                    Object(
                        bbox=BBox(xyxy=output["boxes"][i]),
                        score=output["scores"][i],
                        class_name=cls_map[output["labels"][i]],
                        class_id=output["labels"][i],
                    )
                )
            else:
                back_ground_masks.append(
                    SemantickMask(
                        bbox=BBox(xyxy=output["boxes"][i]),
                        mask=output["masks"][i],
                        class_name=cls_map[output["labels"][i]],
                        class_id=output["labels"][i],
                    )
                )

        horizon = (
            Horizon(
                line=Line(xyxy_n=[*output["horizon"][0], *output["horizon"][1]]),
                score=output["horizon_confidence"],
            )
            if "horizon" in output and output["horizon"] is not None
            else None
        )

        return cls(
            objects=objects,
            horizon=horizon,
            image_width=image_hw[1],
            image_height=image_hw[0],
            masks=back_ground_masks,
        )

    @classmethod
    def _validate_fo_sample_or_frame(
        cls,
        sample_or_frame: Union["fo.Sample", "fos.SampleView", "fo.Frame"],
        det_field: Optional[str] = None,
        pl_field: Optional[str] = None,
        prefix: Optional[str] = None,
    ) -> None:
        """Validate input for FiftyOne sample or frame.

        Args:
            sample_or_frame: FiftyOne sample or frame to be validated.
            det_field: The field name of FiftyOne detections. Ignored if `prefix` is
                specified.
            pl_field: The field name of FiftyOne polylines. Ignored if `prefix` is
                specified.
            prefix: The prefix for the field names. If specified, it overrides
                `det_field` and `pl_field`.

        Raises:
            ValueError: If `sample_or_frame` is a video sample, or if none of
                `det_field`, `pl_field`, or `prefix` is specified.
        """
        import fiftyone.core.sample as fos

        if (
            isinstance(sample_or_frame, (fos.Sample, fos.SampleView))
            and sample_or_frame.media_type == "video"
        ):
            raise ValueError(
                "`Results` cannot be created from FiftyOne video samples.",
                "Pass in a FiftyOne frame instead.",
            )

        if det_field is None and pl_field is None and prefix is None:
            raise ValueError(
                "At least one of `det_field`, `pl_field`, or `prefix` must be specified"
            )

    @classmethod
    def from_fo_sample_or_frame(
        cls,
        sample_or_frame: Union["fo.Sample", "fos.SampleView", "fo.Frame"],
        image_hw: Tuple[int, int],
        det_field: str = None,
        pl_field: str = None,
        prefix: str = None,
    ) -> "Results":
        """Convert FiftyOne detections to Results.

        Args:
            sample_or_frame: FiftyOne sample or frame.
            image_hw: Image height and width.
            det_field: Field name of FiftyOne detections. Ignored if `prefix`
                is specified.
            pl_field: Field name of FiftyOne polylines. Ignored if `prefix`
                is specified.
            prefix: Prefix of the field names. Will override the `det_field` and
                `pl_field`if specified.

        Returns:
            Results object.
        """
        # Validate input
        cls._validate_fo_sample_or_frame(sample_or_frame, det_field, pl_field, prefix)

        if prefix is not None:
            det_field = f"{prefix}_det"
            det_field = det_field if sample_or_frame.has_field(det_field) else None
            pl_field = f"{prefix}_pl"
            pl_field = pl_field if sample_or_frame.has_field(pl_field) else None

        detections = sample_or_frame[det_field] if det_field else None
        polylines = sample_or_frame[pl_field] if pl_field else None

        objects = None
        horizon = None

        if detections is not None and len(detections) > 0:
            objects = [
                Object(
                    bbox=BBox(xywh_n=det.bounding_box),
                    score=det.confidence,
                    class_name=det.label,
                )
                for det in detections.detections  # pylint: disable=not-an-iterable
            ]

        if polylines is not None and len(polylines.polylines) > 0:

            def flatten_list(nested_list: List[List[float]]) -> List[float]:
                return sum(sum(nested_list, []), [])

            horizon = Horizon(
                line=Line(xyxy_n=flatten_list(polylines.polylines[0].points)),
                score=polylines.polylines[0].confidence,
                class_name=polylines.polylines[0].label,
            )

        return cls(
            objects=objects,
            horizon=horizon,
            image_width=image_hw[1],
            image_height=image_hw[0],
        )

    def apply_confidence_map(
        self,
        conf_map: Dict[int, float],
        cls_map: Dict[int, str],
        fallback_label: str = "HAZARD",
    ) -> "Results":
        """Relabel objects with scores below their class-specific thresholds.

        Args:
            conf_map: Mapping from class IDs to confidence thresholds.
            cls_map: Mapping from class IDs to class names.
            fallback_label: The label to use for low-confidence objects.

        Returns:
            Self for method chaining.
        """
        if not all([conf_map, cls_map, self.objects]):
            return self

        # Find fallback class ID
        fallback_id = next((k for k, v in cls_map.items() if v == fallback_label), None)
        if fallback_id is None:
            logger.warning(
                f"Relabeling not possible: {fallback_label} class not found "
                "in class mapping"
            )
            return self

        for obj in self.objects:
            threshold = conf_map.get(obj.class_id, 0.0)
            p_class = obj.p_class

            if p_class is None:
                logger.warning(
                    "Relabeling not possible: Property p_class of object is None."
                )
                continue

            if p_class <= threshold:
                obj.class_id = fallback_id
                obj.class_name = fallback_label

        return self
