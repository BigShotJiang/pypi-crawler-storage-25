"""Yolo_Lnseg model for object and horizon detection."""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Literal, Sequence, Tuple, Union

import numpy as np
import yaml

from .horizon_extraction import get_horizon_from_masks
from .model_abc import Model, load_engine
from .results import Results

logger = logging.getLogger(__name__)

# Constants for validation
VALID_MERGING_METHODS = {"robust", "trusting_yolo", "optimistic"}
VALID_FITTING_METHODS = {"ransac", "linear_regression"}


def load_class_map_and_background_labels(
    path: Union[str, Path],
) -> Tuple[Dict[int, str], List[str]]:
    """Load class mapping from YAML or JSON file."""
    path = Path(path)
    class_map = {}
    background_labels = []

    if path.suffix.lower() in {".yaml", ".yml"}:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    elif path.suffix.lower() == ".json":
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")

    if "class_map" not in data:
        raise ValueError(f"Missing 'class_map' in {path}")
    if "background_classes" not in data:
        raise ValueError(f"Missing 'background_classes' in {path}")

    class_map = {v: k for k, v in data["class_map"].items()}
    if all(isinstance(k, str) for k in class_map):
        class_map = {int(k): v for k, v in class_map.items()}

    background_labels = data["background_classes"]

    return class_map, background_labels


class HOLY(Model):
    """HOLY model for object and horizon detection.

    This model combines object detection and semantic segmentation to provide
    panoptic segmentation results, including horizon detection.
    It uses a YOLO-based architecture for object detection.
    Segmentation masks are generated using segmentation LNSeg model outputs.
    Horizon detection is performed using the segmentation masks.
    """

    def __init__(
        self,
        model_path: str,
        merging_method: Literal[
            "robust", "trusting_yolo", "optimistic"
        ] = "trusting_yolo",
        fitting_method: Literal["ransac", "linear_regression"] = "ransac",
        horizon_inlier_threshold: float = 3.0,
        recompute_horizon: bool = False,
        **kwargs: Dict[str, Any],
    ) -> None:
        """Initialize the HOLY model.

        HOLY Stands for the following:
        - **H**orizon, segmentation and
        - **O**bject detection
        - **L**Nseg-based and
        - **Y**olo-based model

        Args:
            model_path: Path to the model file.
            merging_method: Method for merging panoptic results.
            fitting_method: Method for horizon line fitting.
            cupy: Whether to use CuPy for GPU acceleration.
            horizon_inlier_threshold: Threshold for horizon inlier detection in pixels.
            recompute_horizon: Whether to recompute horizon.
            **kwargs: Additional keyword arguments for configuration.
        """
        super().__init__()
        logger.info("Initializing HOLY model with path: %s", model_path)

        # Load model engine
        self.model = load_engine(model_path)
        self.cls_map, self.background_labels = load_class_map_and_background_labels(
            Path(model_path).with_suffix(".yaml")
        )
        logger.info(f"Class map: {self.cls_map}")
        logger.info(f"Background labels: {self.background_labels}")

        # Set configuration parameters with validation
        if merging_method not in VALID_MERGING_METHODS:
            raise ValueError(
                f"Invalid merging_method: {merging_method}. "
                f"Must be one of {VALID_MERGING_METHODS}"
            )
        self.merging_method = merging_method

        if fitting_method not in VALID_FITTING_METHODS:
            raise ValueError(
                f"Invalid fitting_method: {fitting_method}. "
                f"Must be one of {VALID_FITTING_METHODS}"
            )
        self.fitting_method = fitting_method

        self.inlier_threshold = float(horizon_inlier_threshold)
        self.recompute_horizon = bool(recompute_horizon)

        # Store any additional kwargs for future use
        self._extra_config = kwargs

    def _preprocess(self, ims: np.ndarray) -> np.ndarray:  # noqa: PLR6301
        """Transform the input image so that the model can infer from it.

        Parameters
        ----------
        ims : np.ndarray
            The input image(s)

        Returns:
        -------
        np.ndarray
            Preprocessed image.
        """
        x = np.stack(ims, axis=0) if isinstance(ims, (list, tuple)) else ims
        x = x.transpose(0, 3, 1, 2)  # NHWC -> NCHW
        return x

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:
        """Transform raw model output to application output.

        Parameters
        ----------
        output : dict
            Raw model output. Keys are the output tensor names.

        Returns:
        -------
        Sequence[np.ndarray]
            List of processed outputs, one for each input image.
        """
        horizons = get_horizon_from_masks(
            output["ln_masks"].astype(bool),
            method=self.fitting_method,
            inlier_threshold=self.inlier_threshold,
            recompute=self.recompute_horizon,
        )
        merged = self.merge_panoptic(
            output["nms_confidence"],
            output["nms_classes"],
            output["nms_boxes"],
            output["num_detections"],
            output["ln_masks"],
            output["ln_probs"],
            horizons,
        )
        return merged

    def _to_results(self, output: Sequence[np.ndarray]) -> List[Results]:
        """Convert the model output to a Results object."""
        return [
            Results.from_yolo_ln_output(
                out,
                image_hw=im0_hw,
                cls_map=self.cls_map,
                background_labels=self.background_labels,
            )
            for out, im0_hw in zip(output, self.orig_hw)
        ]

    def close(self) -> None:
        """Run this before exiting the program to free up resources."""
        self.model.close()

    def merge_panoptic(  # noqa: PLR0914, pylint: disable=too-many-locals
        self,
        scores_vector: np.ndarray,
        class_vector: np.ndarray,
        boxes_vector: np.ndarray,
        detections: np.ndarray,
        ln_out_mask: np.ndarray,
        ln_out_probs: np.ndarray,
        horizons: List[Dict] = None,
    ) -> List[Dict[str, Any]]:
        """Merge semantic segmentation and object detection results.

        Create a singe panoptic output from the segmentation masks
        and object detection results.
        """
        bgl_len = len(self.background_labels)
        batch_results = []

        # iterate over batch
        for i, batched_mask in enumerate(ln_out_mask):
            result = {"boxes": [], "labels": [], "scores": [], "masks": []}

            # backgroundclasses need to be the first three classes
            for bg_id in range(bgl_len):
                # extract bounding box of the stuff region
                coords = np.argwhere(batched_mask[bg_id])
                if len(coords[:, 0]) == 0:
                    continue
                min_y, min_x = coords.min(axis=0)  # Minimum y and x
                max_y, max_x = coords.max(axis=0)  # Maximum y and x

                score = ln_out_probs[i, bg_id, min_y:max_y, min_x:max_x].mean().item()

                result["boxes"].append([min_x, min_y, max_x, max_y])
                result["masks"].append(
                    (batched_mask[bg_id, min_y:max_y, min_x:max_x]).astype(np.uint8)
                )
                result["labels"].append(bg_id)
                result["scores"].append(score)

            # get how many detections we have in the current image
            det = int(detections[i])
            classes = class_vector[i, :det]
            scores = scores_vector[i, :det]
            boxes = boxes_vector[i, :det, :]

            for box, score, cls in zip(boxes, scores, classes):
                x1, y1, x2, y2 = box
                class_idx = int(cls + bgl_len)  # add the stuff labels

                mask = (
                    batched_mask[bgl_len, int(y1) : int(y2), int(x1) : int(x2)]
                ).astype(np.uint8)

                if mask.sum() == 0:
                    if self.merging_method == "robust":
                        continue
                    mask = np.ones((int(y2 - y1), int(x2 - x1)))

                result["boxes"].append([x1, y1, x2, y2])
                result["masks"].append(mask)
                result["labels"].append(class_idx)
                result["scores"].append(score)

            if horizons is not None:
                result["horizon"] = horizons[i]["horizon"]
                result["horizon_confidence"] = horizons[i]["confidence"]

            batch_results.append(result)

        return batch_results
