"""Inference pipeline for the LouisNet model."""

import logging
from pathlib import Path
from typing import Dict, List, Sequence, Union

import numpy as np

from .model_abc import Model
from .postprocessing import postprocess_horizon_louisnet, postprocess_objects_louisnet
from .preprocessing import preprocess_louisnet
from .results import Results

logger = logging.getLogger(__name__)


class LouisNet(Model):
    """Custom designed CNN by David Moser during his Master Thesis."""

    def __init__(
        self,
        model_path: str,
        per_process_gpu_memory_fraction: float = 0,
        device: Union[int, str] = None,
        super_init_only: bool = False,
    ) -> None:
        """Initialize the AHOYv5 model.

        Args:
            model_path: Path to the model file containing the weights and architecture.
            per_process_gpu_memory_fraction: Memory fraction to use.
            device: CUDA device to use.
            super_init_only: Whether to only initialize the super class.
        """
        super().__init__()
        if super_init_only:
            return  # dirty hack, but makes other things easier

        if Path(model_path).suffix == ".engine":
            from .infer_trt import InferTRT

            self.model = InferTRT(model_path, device)
        elif Path(model_path).suffix == ".pb":
            from .infer_tf import InferTF

            self.model = InferTF(model_path, per_process_gpu_memory_fraction)
        elif Path(model_path).suffix == ".onnx":
            from .infer_onnx2torch import InferONNX2Torch

            self.model = InferONNX2Torch(model_path, device)
        else:
            raise ValueError(
                "Only TensorRT engines or TensorFlow models are supported."
            )

        self.model.set_input_dims_order(B=0, H=1, W=2, C=3)

        cls_map_fpath = model_path.replace(Path(model_path).suffix, "__class_enum.json")
        self.init_cls_map(cls_map_fpath, reverse=True)

        self.det_conf_thresh = 0.6
        self.hor_conf_thresh = 0.5
        self.hough_vote_th = 40
        self.counter_stain = 0
        self.t_now = 0
        self.t_last = 0

    @property
    def hough_vote_th(self) -> int:
        """Threshold for Hough transform."""
        return self._hough_vote_th

    @hough_vote_th.setter
    def hough_vote_th(self, value: int) -> None:
        if value < 0:
            raise ValueError("Hough vote threshold must be positive.")
        self._hough_vote_th = value

    def _preprocess(self, ims: np.ndarray) -> np.ndarray:
        """Transform the input image so that the model can infer from it."""
        return preprocess_louisnet(ims, self.model.input_hw)

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:
        """Transform raw model output to application output."""
        rect_label_prob = []
        for hor_mask, obj_mask in zip(
            output["hor_activation"],
            output["cl_activation"],
        ):
            objects_proposals = postprocess_objects_louisnet(
                obj_mask,
                det_conf_thresh=self.det_conf_thresh,
                cls_map=self.cls_map,
            )
            horizon_proposal = postprocess_horizon_louisnet(
                hor_mask[:, :, 0],
                self.hor_conf_thresh,
                self.hough_vote_th,
                cls_map={v: k for k, v in self.cls_map.items()},
            )
            rect_label_prob.append(objects_proposals + [horizon_proposal])

        return rect_label_prob

    def _to_results(self, output: Sequence) -> List[Results]:
        """Convert the model output to the results format."""
        return [
            Results.from_louisnet_output(out, image_hw=im0_hw)
            for out, im0_hw in zip(output, self.orig_hw)
        ]

    @staticmethod
    def output_to_obj_masks(output: Sequence[np.ndarray]) -> Sequence[np.ndarray]:
        """Get the object masks from the model output."""
        return [mask[:, :, 0] for mask in output["cl_activation"]]

    @staticmethod
    def obj_masks_to_output(
        obj_masks: Sequence[np.ndarray], output: Sequence[np.ndarray]
    ) -> Sequence[np.ndarray]:
        """Update the model output with the object masks."""
        for i in range(len(output["cl_activation"])):
            output["cl_activation"][i][:, :, 0] = obj_masks[i]
        return output
