"""Multi-Input Multi-Output Model.

Mainly used for models which are independent from each other,
yet packed into a single onnx graph to save inference time.
"""

import logging
from pathlib import Path
from typing import Any, List, Union

from .model_abc import Model, load_engine

logger = logging.getLogger(__name__)


class MIMO(Model):
    """Multi-Input Multi-Output Model."""

    def __init__(self, model_path: str, device: Union[int, str, None] = None) -> None:
        """Initialize the MIMO model.

        Args:
            model_path: Path to the model file.
            device: Device to run the model on.
        """
        super().__init__()
        self.model = load_engine(model_path, device)
        self.init_cls_map(Path(model_path).with_suffix(".yaml"), multi_input=True)

    def validate_and_rename_outputs(self, expected_names: List[str]) -> None:
        """Check for unexpected model output names and rename if necessary."""
        if all(
            out.name == name for out, name in zip(self.model.outputs, expected_names)
        ):
            return

        logger.warning("Model output names are not as expected. Renaming.")
        for out, name in zip(self.model.outputs, expected_names):
            out.name = name

    @Model.det_conf_thresh.setter
    def det_conf_thresh(self, value: float) -> None:
        """Confidence threshold for p(object)."""
        self._set_attr("_det_conf_thresh", value)

    @Model.det_iou_thresh.setter
    def det_iou_thresh(self, value: float) -> None:
        """Minimum IOU to be counted as a duplicate detection."""
        self._set_attr("_det_iou_thresh", value)

    @Model.hor_conf_thresh.setter
    def hor_conf_thresh(self, value: float) -> None:
        """Confidence threshold for p(horizon)."""
        self._set_attr("_hor_conf_thresh", value)

    def _prop_to_list(
        self, value: Union[int, float, bool, str, List[Any]]
    ) -> List[Any]:
        """Convert a property to a list if not already."""
        if not isinstance(value, list):
            return [value] * len(self.model.inputs)
        return value

    def _set_attr(self, attr_name: str, value: Union[float, bool]) -> None:
        """Set an attribute."""
        value = self._prop_to_list(value)
        if len(value) != len(self.model.inputs):
            raise ValueError(
                f"Length of {attr_name} must match number of model outputs"
            )
        setattr(self, attr_name, value)
