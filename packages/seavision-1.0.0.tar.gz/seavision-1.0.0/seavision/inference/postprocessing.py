"""Collection of postprocessing functions for object detection models.

Most functions are designed to work with NumPy arrays.
"""

from typing import List, NamedTuple, Sequence, Tuple

import cv2
import numpy as np
from scipy import ndimage
from scipy.optimize import curve_fit


class LetterboxGeometry(NamedTuple):
    """Scale and symmetric padding in ``from_shape`` pixel space (letterboxing)."""

    gain: float
    pad_x: float
    pad_y: float


def letterbox_geometry(
    from_shape: Tuple[int, int],
    to_shape: Tuple[int, int],
    upscale: bool = True,
) -> LetterboxGeometry:
    """Map ``to_shape`` into ``from_shape`` with the same rules as :func:`scale_xyxy`.

    Args:
        from_shape: Letterboxed canvas ``(height, width)``.
        to_shape: Original image ``(height, width)``.
        upscale: Same meaning as in :func:`scale_xyxy`.

    Returns:
        ``gain`` and pixel padding ``pad_x``, ``pad_y`` on ``from_shape`` such that
        ``2 * pad_x + to_shape[1] * gain == from_shape[1]`` (and similarly for y).
    """
    gain = min(from_shape[0] / to_shape[0], from_shape[1] / to_shape[1])
    gain = min(gain, 1) if not upscale else gain
    pad_x = (from_shape[1] - to_shape[1] * gain) / 2
    pad_y = (from_shape[0] - to_shape[0] * gain) / 2
    return LetterboxGeometry(gain=gain, pad_x=pad_x, pad_y=pad_y)


def cxcywh_to_xyxy(bboxes: np.ndarray) -> np.ndarray:
    """Convert (center_x, center_y, width, height) to (x1, y1, x2, y2) format.

    Args:
        bboxes: The bounding boxes in (center_x, center_y, width, height) format.

    Returns:
        The bounding boxes as (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
    """
    center_x, center_y, width, height = bboxes.T
    top_left_x = center_x - width / 2
    top_left_y = center_y - height / 2
    bottom_right_x = center_x + width / 2
    bottom_right_y = center_y + height / 2

    return np.array([top_left_x, top_left_y, bottom_right_x, bottom_right_y]).T


def xyxy_to_xywh(bboxes: np.ndarray) -> np.ndarray:
    """Convert absolute bounding boxes to (x, y, w, h) format.

    Args:
        bboxes: The bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).

    Returns:
        The bounding boxes in (top_left_x, top_left_y, width, height) format.
    """
    top_left_x, top_left_y, bottom_right_x, bottom_right_y = bboxes.T
    width = bottom_right_x - top_left_x
    height = bottom_right_y - top_left_y
    return np.array([top_left_x, top_left_y, width, height]).T


def xyxy_to_xyxyn(bboxes: np.ndarray, shape: Tuple[int, int]) -> np.ndarray:
    """Convert absolute bounding boxes to normalized format.

    Args:
        bboxes: The bounding boxes in (x, y, x, y) format.
        shape: The shape in (height, width) to which should be normalized.

    Returns:
        The bounding boxes in (x, y, x, y) format in range [0, 1].
    """
    h, w = shape
    bboxes[:, [0, 2]] /= w
    bboxes[:, [1, 3]] /= h
    return bboxes


def xyxyn_to_xyxy(bboxes: np.ndarray, shape: Tuple[int, int]) -> np.ndarray:
    """Convert normalized bounding boxes from (x, y, x, y) to absolute pixels.

    Args:
        bboxes: The bounding boxes in (x, y, x, y) format.
        shape: The shape in (height, width) to which should be normalized.

    Returns:
        The bounding boxes in (x, y, x, y) format in absolute pixels.
    """
    h, w = shape
    bboxes[:, [0, 2]] *= w
    bboxes[:, [1, 3]] *= h
    return bboxes


def scale_xyxy(
    xyxy: np.ndarray,
    from_shape: Tuple[int, int],
    to_shape: Tuple[int, int],
    upscale: bool = True,
    clip: bool = True,
) -> np.ndarray:
    """Rescale bounding boxes from from_shape to to_shape.

    Args:
        xyxy: bboxes or lines defined by (x1, y1, x2, y2), for bboxes the
            (top_left, bottom_right) coordinates are expected.
        from_shape: The original shape of the image (height, width).
        to_shape: The target shape of the image (height, width).
        upscale: Whether to upscale the bounding boxes.
        clip: Whether to clip the bounding boxes to the target shape.

    Returns:
        The bounding boxes as (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        bounding boxes as (top_left_x, top_left_y, bottom_right_x, bottom_right_y)
    """
    geom = letterbox_geometry(from_shape, to_shape, upscale)

    xyxy = xyxy.astype(np.float32)
    xyxy[..., [0, 2]] -= geom.pad_x
    xyxy[..., [1, 3]] -= geom.pad_y
    xyxy[..., :4] /= geom.gain
    if clip:
        clip_boxes(xyxy, to_shape)
    return xyxy


def clip_boxes(boxes: np.ndarray, shape: Tuple[int, int]) -> None:
    """In-place clip boxes (xyxy) to image shape (height, width)."""
    boxes[..., [0, 2]] = boxes[..., [0, 2]].clip(0, shape[1])  # x1, x2
    boxes[..., [1, 3]] = boxes[..., [1, 3]].clip(0, shape[0])  # y1, y2


def intersection_box(target_box: np.ndarray, boxes: np.ndarray) -> list:
    """Calculate intersection of target boxes with all others in boxes.

    Args:
        target_box: The bounding box as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        boxes: The bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).

    Returns:
        The intersection bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        intersection bboxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y)
    """
    x1, y1, x2, y2 = target_box
    a1, b1, a2, b2 = boxes[..., 0], boxes[..., 1], boxes[..., 2], boxes[..., 3]
    xx1 = np.maximum(x1, a1)
    yy1 = np.maximum(y1, b1)
    xx2 = np.minimum(x2, a2)
    yy2 = np.minimum(y2, b2)

    return np.array([xx1, yy1, xx2, yy2])


def intersection_area(target_box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    """Calculate intersection of target boxes with all others in boxes.

    Args:
        target_box: The bounding box as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        boxes: The bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).

    Returns:
        The areas of intersection bounding boxes.
    """
    xx1, yy1, xx2, yy2 = intersection_box(target_box, boxes)
    w = np.maximum(0, xx2 - xx1 + 1)
    h = np.maximum(0, yy2 - yy1 + 1)

    return w * h


def iou(
    target_box: np.ndarray,
    boxes: np.ndarray,
    target_area: np.ndarray,
    areas: np.ndarray,
) -> np.ndarray:
    """Calculate intersection over union of target box with all others.

    Args:
        target_box: The bounding box as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        boxes: The bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        target_area: The area of the target box.
        areas: The areas of all boxes.

    Returns:
        The intersection over union of the target box with all others.
    """
    inter = intersection_area(target_box, boxes)
    union = target_area + areas - inter

    # avoid division w/ 0
    union[union == 0] += 1e-7

    return inter / union


def nms(
    bboxes: np.ndarray,
    scores: np.ndarray,
    iou_thresh: float,
    classes: np.ndarray = None,
) -> np.ndarray:
    """Non-Maximum-Supression (NMS) algorithm to remove overlapping bounding boxes.

    Args:
        bboxes: The bounding boxes as
            (top_left_x, top_left_y, bottom_right_x, bottom_right_y).
        scores: The confidence scores for each bounding box.
        iou_thresh: The threshold for intersection over union.
        classes: The class labels for each bounding box.
            if None, all boxes are treated as the same class (agnostic NMS).

    Returns:
        The indices of the bounding boxes to keep.
    """
    bboxes = bboxes.astype(np.float32)
    x1, y1 = bboxes[..., 0], bboxes[..., 1]  # top left
    x2, y2 = bboxes[..., 2], bboxes[..., 3]  # bottom right

    areas = (x2 - x1) * (y2 - y1)  # calculate area per bbox
    order = np.argsort(scores)[::-1]  # sort by descending confidence

    keep = np.zeros_like(scores, dtype=bool)  # which boxes (idx) to keep

    while order.size > 1:
        # take current highest confidence box
        i = order[0]
        keep[i] = True

        # calculate intersection over union with all other boxes
        ovr = iou(bboxes[i], bboxes[order[1:]], areas[i], areas[order[1:]])

        # find boxes to keep since they are not overlapping enough
        idxs = np.nonzero(ovr <= iou_thresh)[0]

        if classes:
            # only keep boxes with different classes
            idxs = np.union1d(idxs, np.nonzero(classes[order[1:]] != classes[i]))

        # update order by removing suppressed boxes
        order = order[idxs + 1]  # +1 because we removed the first element

    return keep


def postprocess_yolo(
    model_output: np.ndarray,
    input_hw: tuple,
    orig_hw: tuple,
    conf_thresh: float,
    iou_thresh: float,
    was_upscaled: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Transform raw yolo-like output to bounding boxes, scores and classes.

    Args:
        model_output: The raw yolo-like output.
        input_hw: The shape of the input image (height, width).
        orig_hw: The shape of the original image (height, width).
        conf_thresh: The confidence threshold for p(bbox).
        iou_thresh: The minimum IOU to be counted as a duplicate detection.
        was_upscaled: Whether the input image was upscaled prior to inference.

    Returns:
        The bounding boxes, scores, classes and class probs as a tuple of numpy arrays.
    """
    if model_output.shape[0] < model_output.shape[1]:
        from .utils import yolov8_to_yolov5

        model_output = yolov8_to_yolov5(model_output)

    # Filter out boxes with low confidence
    model_output = model_output[model_output[..., 4] > conf_thresh]

    # Unpack model_output
    bboxes = model_output[..., :4]
    p_bbox = model_output[..., 4]  # p(bbox)
    p_class_given_bbox = model_output[..., 5:]  # p(class | bbox)

    bboxes = cxcywh_to_xyxy(bboxes)

    p_class = (
        p_class_given_bbox * p_bbox[:, None]
    )  # p(class) = p(class | bbox) * p(bbox)
    classes = np.argmax(p_class, axis=1)

    # Class agnostic since classes is not used
    keep = nms(bboxes, p_bbox, iou_thresh)
    bboxes = bboxes[keep]
    classes = classes[keep]
    p_bbox = p_bbox[keep]
    p_class_given_bbox = p_class_given_bbox[keep]

    # Extract raw class probabilities for the selected classes
    p_class_given_bbox = p_class_given_bbox[np.arange(len(classes)), classes]

    bboxes = scale_xyxy(bboxes, input_hw, orig_hw, was_upscaled)

    return (bboxes, p_bbox, classes, p_class_given_bbox)


def _obb_horizon_slope_intercept(
    obboxes: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Slope ``m`` and intercept ``b`` for ``y = m x + b`` along each box long axis."""
    cx, cy, bw, bh, angle = obboxes.T
    theta = np.where(bw >= bh, angle, angle + np.pi / 2)
    m = np.tan(theta)
    return m, cy - m * cx


def cxcywhr_to_lines(
    obboxes: np.ndarray,
    from_shape: Tuple[int, int],
    to_shape: Tuple[int, int],
    upscale: bool = True,
) -> np.ndarray:
    """Transform obb format from center, width, height, angle to line coordinates.

    Args:
        obboxes: The oriented bounding boxes as (cx, cy, w, h, angle).
        from_shape: The shape of the input image (height, width).
        to_shape: The shape of the original image (height, width).
        upscale: Whether the input image was upscaled prior to inference.

    Returns:
        The lines as (x0, y0, x1, y1).
    """
    geom = letterbox_geometry(from_shape, to_shape, upscale)
    m, b = _obb_horizon_slope_intercept(obboxes)
    pad = np.array([geom.pad_x, geom.pad_y], dtype=np.float64)
    xs = np.array([geom.pad_x, from_shape[1] - geom.pad_x])
    ys = m[:, None] * xs + b[:, None]
    pts = np.hstack([np.tile(xs, (len(m), 1)), ys])[:, [0, 2, 1, 3]]
    pts -= np.tile(pad, 2)
    pts /= geom.gain
    return pts


def decode_offset(offset: float, offset_buffer: float = 0.15) -> float:
    """Decode offset logits to their original values.

    Args:
        offset: in [0,1] (horizon line center at offset=0.5)
        offset_buffer: bottom of the image and (1 - offset_buffer) is the
            top of the image. Depends on how the model was trained.

    Returns:
        offset in normalised form [0 - offset_buffer, 1 + offset_buffer]
            where 0 is the bottom of the image and 1 is the top of the image.
    """
    adjusted_offset = offset - offset_buffer
    adjusted_range = 1 - 2 * offset_buffer
    return adjusted_offset / adjusted_range


def decode_theta(theta: float) -> float:
    """Decode theta logits to their original values.

    Args:
        theta: in [0,1] (theta=0 is -pi/2, theta=1 is pi/2)

    Returns:
        theta in radians [-pi/2, pi/2]
    """
    return theta * np.pi - 0.5 * np.pi


def offset_theta_to_slope_intercept(
    offset: float,
    theta: float,
) -> Tuple[float, float]:
    """Convert offset and theta to slope-intercept form of line: m, b.

    Image origin is at the top-left corner.

    Args:
        offset: 0 = bottom of the image, 1 = top of the image
        theta: radians [-pi/2, pi/2]

    Returns:
        m, b (float, float): slope and y-intercept of the line
            in normalised form [0, 1]
    """
    m = np.tan(theta)
    b = offset - m * 0.5
    return m, b


def slope_intercept_to_image_edges(
    m: float, b: float, image_hw: tuple
) -> Tuple[float, float]:
    """Convert slope-intercept form of a line to two points on the line.

    (y = mx + b) to 2 points within (0, 0) and (x_max, y_max).

    Args:
        m: The slope of the line. Use np.inf for vertical lines.
        b: The y-intercept of the line. For vertical lines, this represents the
            x-coordinate where the line intersects.
        image_hw: Shape of the image (height, width).

    Returns:
        Two points (x1, y1) and (x2, y2) that lie on the line within the specified
            bounding box.
    """
    x_max, y_max = image_hw
    b *= y_max  # scale y-intercept to image height
    if m == np.inf:
        x_1, y_1 = b, 0
        x_2, y_2 = b, y_max
    else:
        x_1, y_1 = 0, b
        x_2, y_2 = x_max, m * x_max + b
    return (x_1, y_1), (x_2, y_2)


def image_edges_to_slope_intercept(
    x1: float, y1: float, x2: float, y2: float
) -> Tuple[float, float]:
    """Convert two points lying on a line to slope and intercept of the line.

    Args:
        x1: The x-coordinate of the first point.
        y1: The y-coordinate of the first point.
        x2: The x-coordinate of the second point.
        y2: The y-coordinate of the second point.

    Returns:
        The slope and y-intercept of the line.
    """
    if x2 - x1 == 0:
        m = np.inf
        b = x1
    else:
        m = (y2 - y1) / (x2 - x1)
        b = y1 - m * x1
    return m, b


def hough_params_to_slope_intercept(rho: float, theta: float) -> Tuple[float, float]:
    """Convert hough parameters to slope and intercept of horizon line.

    Args:
        rho: Distance from the origin (top-left) of the image to the line along the
            normal vector
        theta: Angle in radians between normal vector to the line and x-axis

    Returns:
        The slope and y-intercept of the line.
    """
    m = -np.cos(theta) / np.sin(theta)  # -1 / np.tan(theta)
    b = rho / np.sin(theta)
    return m, b


def slope_intercept_to_hough_params(m: float, b: float) -> Tuple[float, float]:
    """Approximate inverse of hough_params_to_slope_intercept.

    Args:
        m: The slope of the line.
        b: The y-intercept of the line.

    Returns:
        The Hough parameters of the line `rho` and `theta`. Where
            `rho` is the distance from the origin (top-left) of the image
            to the line along the normal vector and
            `theta` is the angle between the x-axis and the normal vector.
    """
    theta = np.arctan(-1 / m)
    rho = b * np.sin(theta)
    return rho, theta


def hough_params_to_image_edges(
    rho: float, theta: float, image_hw: tuple
) -> Tuple[float, float, float, float]:
    """Convert hough parameters to horizon points on edges of image.

    Args:
        rho: Distance from the origin (top-left) of the image to the line along the
            normal vector
        theta: Angle in radians between normal vector to the line and x-axis
        image_hw: Shape of the image (height, width)

    Returns:
        Two points lying on the horizon line in the format (x1, y1, x2, y2).
    """
    _, w = image_hw
    k, d = hough_params_to_slope_intercept(rho, theta)
    x1, y1 = (0, d)
    x2, y2 = (w, k * w + d)
    return x1, y1, x2, y2


def image_edges_to_hough_params(
    x1: float, y1: float, x2: float, y2: float, scale_hw: tuple = (1, 1)
) -> Tuple[float, float]:
    """Convert two points lying on a line to Hough parameters.

    Args:
        x1: The x-coordinate of the first point.
        y1: The y-coordinate of the first point.
        x2: The x-coordinate of the second point.
        y2: The y-coordinate of the second point.
        scale_hw: The scaling factor for the image width and height if the points are
            in normalized form. Default is (1, 1).

    Returns:
        The Hough parameters of the line `rho` and `theta`. Where
            `rho` is the distance from the origin (top-left) of the image
            to the line along the normal vector and
            `theta` is the angle between the x-axis and the normal vector.
    """
    h, w = scale_hw
    x1, y1, x2, y2 = x1 * w, y1 * h, x2 * w, y2 * h
    theta = np.arctan2(y2 - y1, x2 - x1) + np.pi / 2  # normal vector
    rho = x1 * np.cos(theta) + y1 * np.sin(theta)
    return rho, theta


def gaussian_curve_fit(
    data: np.ndarray, ftol: float = 1e-4, xtol: float = 1e-4
) -> Tuple[float, float, float]:
    """Fit a gaussian to the softmax data to find peak.

    Args:
        data: The softmax data.
        ftol: The tolerance for the function value.
        xtol: The tolerance for the parameter values.

    Returns:
        The parameters of the 1D gaussian: (A, mu, sigma)
    """

    def gaussian(
        x: np.ndarray, amplitude: float, mu: float, sigma: float
    ) -> np.ndarray:
        return amplitude * np.exp(-((x - mu) ** 2) / (2 * sigma**2))

    # Initial guess for the parameters (amplitude, mean, std deviation)
    p0 = [data.max(), data.argmax() / data.shape[-1], 0.001]
    x = np.linspace(0, 1, data.shape[0], endpoint=False)
    kwargs = {"ftol": ftol, "xtol": xtol}

    curve_params, _ = curve_fit(gaussian, x, data, p0=p0, **kwargs)  # pylint:disable=unbalanced-tuple-unpacking
    return curve_params  # A, mu, sigma


def slope_intercept_to_unpadded_image_edges(
    m: float,
    b: float,
    from_shape: Tuple[int, int],
    to_shape: Tuple[int, int],
    upscale: bool = True,
) -> np.ndarray:
    """Transform slope intercept to two points at edges of original image.

    Args:
        m: slope of horizon in [0, 1]
        b: intercept of horizon in [0, 1]
        from_shape: shape of padded image (height, width)
        to_shape: shape of original, unpadded image (height, width)
        upscale: whether to upscale the bounding boxes

    Returns:
        horizon points for original image
    """
    # gain is the ratio of padded / original
    gain = min(from_shape[0] / to_shape[0], from_shape[1] / to_shape[1])
    gain = min(gain, 1) if not upscale else gain

    # wh padding (normalized to from_shape)
    pad = (
        (from_shape[1] - to_shape[1] * gain) / (2 * from_shape[1]),  # x padding
        (from_shape[0] - to_shape[0] * gain) / (2 * from_shape[0]),  # y padding
    )

    if m == np.inf:
        # vertical line, b is where x-axis is intersected
        x = np.array([b, b]) * to_shape[1]
        y = np.array([0, 1]) * to_shape[0]
    else:
        # original image edges in padded space
        x_padded = np.array([pad[0], 1 - pad[0]])
        y_padded = m * x_padded + b

        # from padded space to original image space
        x = np.array([0, to_shape[1]])
        y = (y_padded - pad[1]) * from_shape[0] / gain

    return np.array([x[0], y[0], x[1], y[1]])


def postprocess_offset_theta(
    offset: np.ndarray,
    theta: np.ndarray,
    input_hw: tuple,
    orig_hw: tuple,
    offset_buffer: float = 0.15,
    conf_thresh: float = 0.1,
    do_curve_fit: bool = False,
    was_upscaled: bool = True,
) -> Tuple[np.ndarray, float, int]:
    """Get line points and score from offset and theta logits.

    Args:
        offset: Offset vector (classification logits)
        theta: Theta vector (classification logits)
        input_hw: Shape of the input image (height, width)
        orig_hw: Original image shape (height, width)
        offset_buffer: Buffer for offset-theta model
        conf_thresh: Confidence threshold for p(bbox)
        do_curve_fit: Whether to fit a gaussian curve to the softmax data
        was_upscaled: Set to True if the input image was upscaled prior to inference.

    Returns:
        points: coordinates of the detected bounding box in the format
            (top-left x, top-left y, bottom-right x, bottom-right y). If no horizon
            is detected, returns `None`.
        score: confidence score of the detected bounding box.
        cls: class label of the detected bounding box. (always -1 for horizon)
    """
    if do_curve_fit:
        offset_prob, offset, _ = gaussian_curve_fit(offset)
        theta_prob, theta, _ = gaussian_curve_fit(theta)
    else:
        offset_prob, offset = offset.max(), offset.argmax() / len(offset)
        theta_prob, theta = theta.max(), theta.argmax() / len(theta)

    # pseudo-probability (because of softmax)
    score = offset_prob * theta_prob
    if score < conf_thresh:
        return None, score, -1

    # decode network output
    offset, theta = decode_offset(offset, offset_buffer), decode_theta(theta)

    # intermediate step: convert offset, theta to m, b
    m, b = offset_theta_to_slope_intercept(offset, theta)

    # get horizon points in original image coordinate system from m,b
    points = slope_intercept_to_unpadded_image_edges(
        m, b, input_hw, orig_hw, upscale=was_upscaled
    )

    # flip y-axis since origin is top left corner
    points[[1, 3]] = orig_hw[0] - points[[1, 3]]

    return points, score, -1  # -1 is the class label for horizon


def postprocess_ahoy(  # pylint:disable=too-many-locals, too-many-arguments
    output_yolo: np.ndarray,
    output_offset: np.ndarray,
    output_theta: np.ndarray,
    input_hw: Tuple[int, int],
    orig_hw: List[Tuple[int, int]],
    det_conf_thresh: float,
    det_iou_thresh: float,
    hor_offset_buffer: float = 0.15,
    hor_conf_thresh: float = 0.1,
    was_upscaled: bool = False,
) -> Sequence[np.ndarray]:
    """Transform raw model output to application output.

    Args:
        output_yolo: Raw model output.
        output_offset: Offset vector (classification logits)
        output_theta: Theta vector (classification logits)
        input_hw: Shape of the input image (height, width)
        orig_hw: Original image shape (height, width)
        det_conf_thresh: Confidence threshold for p(bbox)
        det_iou_thresh: Minimum IOU to be counted as a duplicate detection.
        hor_offset_buffer: Buffer for offset-theta model
        hor_conf_thresh: Confidence threshold for p(horizon)
        do_curve_fit: Whether to fit a gaussian curve to the softmax data
        was_upscaled: Set to True if the input image was upscaled prior to inference.

    Returns:
        Every element is a np.ndarray of shape `(N, 6)` where:
            `N` is the number of detected bounding boxes,
            the first 4 are the coordinates of the bounding box,
            the 5th is the confidence score of the bounding box,
            the 6th is the class label of the detected bounding box.
            the 7th is the class probability of the detected bounding box.
    """
    preds = []  # store List[x1,y1,x2,y2,conf,cls] per batch

    for det_logits, im0_hw in zip(output_yolo, orig_hw):
        bboxes, p_bbox, classes, p_class_given_bbox = postprocess_yolo(
            det_logits,
            input_hw,
            im0_hw,
            conf_thresh=det_conf_thresh,
            iou_thresh=det_iou_thresh,
            was_upscaled=was_upscaled,
        )

        preds.append(np.c_[bboxes, p_bbox, classes, p_class_given_bbox])
    # iterate over offset-theta outputs grouped by batch
    for i, (im0_hw, offset_logits, theta_logits) in enumerate(
        zip(orig_hw, output_offset, output_theta)
    ):
        points, conf, cls = postprocess_offset_theta(
            offset_logits,
            theta_logits,
            input_hw,
            im0_hw,
            offset_buffer=hor_offset_buffer,
            conf_thresh=hor_conf_thresh,
            was_upscaled=was_upscaled,
        )

        if points is not None:
            # append horizon line as a bbox (x1, y1, x2, y2)
            preds[i] = np.r_[
                preds[i],
                np.r_[points, conf, cls, 1].reshape(1, -1),
            ]

    return preds


def postprocess_obb2horizon(
    model_output: np.ndarray,
    input_hw: tuple,
    orig_hw: tuple,
    conf_thresh: float,
    was_upscaled: bool = False,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Transform yolo-obb output to horizon coordinates, scores and classes.

    Args:
        model_output: obb output, it contains bounding box coordinates(cx, cy, w, h),
            confidence scores, and rotation angles with shape (N, 6+)
        input_hw: The shape of the input image (height, width).
        orig_hw: The shape of the original image (height, width).
        conf_thresh: The confidence threshold for p(bbox).
        was_upscaled: Set to True if the input image was upscaled prior to inference.

    Returns:
        Horizon coordinates, scores and classes as a tuple of numpy arrays.
    """
    # Handle empty case first
    if model_output.shape[0] == 0:
        return np.empty((0, 4)), np.array([]), np.array([])

    best_idx = np.argmax(model_output[..., 4])
    best_det = model_output[best_idx : best_idx + 1]

    if best_det[0, 4] > conf_thresh:
        cxcywhr = np.concatenate((best_det[..., :4], best_det[..., -1:]), axis=-1)
        lines = cxcywhr_to_lines(cxcywhr, input_hw, orig_hw, upscale=was_upscaled)
        score = best_det[..., 4]
        cls = np.array([-1])
    else:
        lines = np.empty((0, 4))
        score = np.array([])
        cls = np.array([])

    return lines, score, cls


def postprocess_ahoyv2(  # pylint:disable=too-many-locals
    output_yolo: np.ndarray,
    output_yolo_obb: np.ndarray,
    input_hw: Tuple[int, int],
    orig_hw: List[Tuple[int, int]],
    det_conf_thresh: float,
    det_iou_thresh: float,
    hor_conf_thresh: float,
    was_upscaled: bool = False,
) -> Sequence[np.ndarray]:
    """Transform raw obb model output to application output.

    Args:
        output_yolo: Raw model output.
        output_yolo_obb: Raw model output for OBB horizon detection.
        input_hw: Shape of the input image (height, width)
        orig_hw: Original image shape (height, width)
        det_conf_thresh: Confidence threshold for p(bbox)
        det_iou_thresh: Minimum IOU to be counted as a duplicate detection.
        hor_conf_thresh: Confidence threshold for p(horizon)
        was_upscaled: Set to True if the input image was upscaled prior to inference.

    Returns:
        Every element is a np.ndarray of shape `(N, 6)` where:
            `N` is the number of detected bounding boxes,
            the first 4 are the coordinates of the bounding box,
            the 5th is the confidence score of the bounding box,
            the 6th is the class label of the detected bounding box.
    """
    preds = []  # store List[x1,y1,x2,y2,conf,cls] per batch

    for det_logits, im0_hw in zip(output_yolo, orig_hw):
        bboxes, p_bbox, classes, p_class_given_bbox = postprocess_yolo(
            det_logits,
            input_hw,
            im0_hw,
            conf_thresh=det_conf_thresh,
            iou_thresh=det_iou_thresh,
            was_upscaled=was_upscaled,
        )
        preds.append(np.c_[bboxes, p_bbox, classes, p_class_given_bbox])
    for i, (det_logits, im0_hw) in enumerate(zip(output_yolo_obb, orig_hw)):
        horizon, confs, classes = postprocess_obb2horizon(
            det_logits,
            input_hw,
            im0_hw,
            conf_thresh=hor_conf_thresh,
            was_upscaled=was_upscaled,
        )

        if len(horizon) > 0:
            preds[i] = np.r_[
                preds[i],
                np.r_[
                    horizon[0, :],
                    confs[0],
                    classes[0],
                    1,
                ].reshape(1, -1),
            ]

    return preds


def postprocess_objects_louisnet(  # pylint:disable=too-many-locals
    obj_mask: np.ndarray,
    det_conf_thresh: float,
    cls_map: dict,
) -> List[Tuple[np.ndarray, str, int, float]]:
    """Postprocess the object detection mask.

    Args:
        obj_mask: The object detection mask.
        det_conf_thresh: The confidence threshold for the object detection mask.
        cls_map: The class map with key-value pairs of class_name: class_id.

    Returns:
        The object detections in the format [[bbox, class_name, class_id, score], ...]
    """
    detection_mask = obj_mask[:, :, 0]
    detection_mask = detection_mask < det_conf_thresh

    labeld_detection_mask, number_of_blobs = ndimage.label(detection_mask)
    slices = ndimage.find_objects(labeld_detection_mask)

    img_shape = labeld_detection_mask.shape
    object_detections = []

    for i in range(number_of_blobs):
        _slice = slices[i]

        # from the whole arrays, cut out the rectangle of interest
        slice_cutout = obj_mask[_slice]
        mask_cutout = labeld_detection_mask[_slice]

        # spatial average over the object -> vector in object category space
        class_pred = np.mean(slice_cutout[mask_cutout == i + 1, :], axis=0)
        label_idx = np.argmax(class_pred[1:]) + 1
        object_detections.append(
            [
                np.array(
                    [
                        _slice[1].start / img_shape[1],
                        _slice[0].start / img_shape[0],
                        _slice[1].stop / img_shape[1],
                        _slice[0].stop / img_shape[0],
                    ],
                    np.float64,
                ),
                cls_map[label_idx],
                label_idx,
                class_pred[label_idx],
            ]
        )
    return object_detections


def postprocess_horizon_louisnet(  # pylint:disable=too-many-locals
    hor_mask: np.ndarray,
    hor_conf_thresh: float,
    hough_vote_th: float,
    cls_map: dict,
) -> Tuple[np.ndarray, str, int, float]:
    """Output mask -> binary mask -> Hough transform -> horizon line.

    Args:
        hor_mask: The horizon mask.
        hor_conf_thresh: The confidence threshold for the horizon mask.
        hough_vote_th: The Hough vote threshold.
        cls_map: The class map with key-value pairs of class_name: class_id.

    Returns:
        The horizon line in the format [points, class_name, class_id, score]
    """
    max_val_per_col = np.amax(hor_mask, axis=0).astype(np.float32)
    argmax_per_col = np.argmax(hor_mask, axis=0).astype(np.int32)

    # create mask with only one maximum value per column and threshold it
    mask = np.zeros_like(hor_mask, dtype=float)
    mask[argmax_per_col, range(len(argmax_per_col))] = max_val_per_col
    mask = (mask > hor_conf_thresh).astype(np.uint8)

    # find lines in the mask using Hough transform
    lines = cv2.HoughLines(
        mask,
        0.5,
        0.5 * np.pi / 180,
        threshold=int(hough_vote_th),
    )

    if isinstance(lines, np.ndarray):
        rho, theta = lines[0, 0, :]
        x1, y1, x2, y2 = hough_params_to_image_edges(rho, theta, mask.shape)
        p1, p2 = (x1, y1), (x2, y2)
        # normalize points to [0,1]
        p1 = [p1[0] / mask.shape[1], p1[1] / mask.shape[0]]
        p2 = [p2[0] / mask.shape[1], p2[1] / mask.shape[0]]
        points = np.array([p1, p2], np.float64).flatten()
    else:
        points = None

    return [points, "HORIZON", cls_map["HORIZON"], np.mean(max_val_per_col)]
