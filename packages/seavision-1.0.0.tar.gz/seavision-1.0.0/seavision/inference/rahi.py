"""RAHI Inference Module.

Named taken from SAHI (Sliced Aided Hyper Inference) but using center crop
as ROI instead of slicing. Hence, the name RAHI (ROI Aided Hyper Inference).
"""

from typing import List, Tuple

import numpy as np

from seavision.geometry.utils import create_affine_matrix
from seavision.sensorfusion import SensorFusionMethod

from .models import AHOY
from .preprocessing import center_crop
from .results import Results
from .slicing import ModelValidationMixin


class RAHI(AHOY, ModelValidationMixin):
    """RAHI model for 4k object detection."""

    def __init__(
        self,
        model: str,
        device: str = None,
        crop_shape: Tuple[int, int] = (1280, 1280),
        sf_method: SensorFusionMethod = SensorFusionMethod.WBF,
    ):
        """Initialize the RAHI model.

        Args:
            model: The model file path.
            device: The device to run the model on.
            crop_shape: The crop shape.
            sf_method: The sensor fusion method.
        """
        super().__init__(model, device)

        self.validate_model(model, supported_batch_sizes=[2])
        self.crop_shape = crop_shape
        self.sf_method = sf_method
        self.H = None

    def preprocess_hook(self, im: np.ndarray) -> np.ndarray:
        """Preprocess the input image by cropping ROI and computing homography.

        Args:
            im: Input image array

        Returns:
            Preprocessed image array
        """
        roi = center_crop(im, self.crop_shape)
        self.H = self._compute_homography(im.shape, roi.shape)
        ims = [im, roi]

        return ims

    def to_results_hook(self, output: List[Results]) -> Results:
        """Convert model output to results tuple.

        Args:
            output: Results list from model

        Returns:
            Results object with fused results.
        """
        im_height, im_width = self.orig_hw[0]

        transformed = output[1].apply_homography(
            self.H, new_width=im_width, new_height=im_height
        )

        method = self.sf_method(weights=[1, 1])

        fused_results = method.fuse([output[0], transformed])
        return fused_results

    def _compute_homography(
        self, original_shape: tuple, crop_shape: tuple
    ) -> np.ndarray:
        """Compute homography matrix for ROI projection.

        Args:
            original_shape: Shape of original image
            crop_shape: Shape of cropped ROI

        Returns:
            Homography matrix
        """
        H, W = original_shape[:2]
        crop_h, crop_w = crop_shape[:2]

        dx = (W - crop_w) / 2
        dy = (H - crop_h) / 2

        return create_affine_matrix(dx, dy)


def main():
    """Run the RAHI baseline approach benchmark."""
    print("\nStarting benchmark for 4K ROI approach")
    from seavision.io import load_images_from_folder

    images = load_images_from_folder("data_path")

    rahi = RAHI(
        "model_file",
        sf_method=SensorFusionMethod.WBF,
    )

    for name, im in images.items():
        name = name.removesuffix(".jpg")
        _ = rahi(im, verbose=True)


if __name__ == "__main__":
    main()
