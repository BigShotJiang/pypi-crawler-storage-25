"""SeaYOLO model for object detection."""

import logging
from pathlib import Path
from typing import Dict, List, Sequence, Union

import numpy as np

from .model_abc import Model, load_engine
from .postprocessing import postprocess_yolo
from .preprocessing import preprocess_yolo, resize_and_center_images_in_batch
from .results import Results

logger = logging.getLogger(__name__)


class SeaYOLO(Model):
    """SeaYOLO model for object detection.

    A YOLO-based model for object detection. This serves as the base
    for more complex models like AHOY that add horizon detection.
    """

    def __init__(
        self,
        model_path: str,
        device: Union[int, str, None] = None,
        super_init_only: bool = False,
    ) -> None:
        """Initialize the SeaYOLO model.

        Args:
            model_path: Path to the model file containing the weights and architecture.
            device: CUDA device to use.
            super_init_only: Whether to only initialize the superclass.
        """
        super().__init__()
        if super_init_only:
            return  # dirty hack, but makes other things easier

        self.model = load_engine(model_path, device)
        self.init_cls_map(Path(model_path).with_suffix(".yaml"))

        self.det_conf_thresh = 0.147
        self.det_iou_thresh = 0.1
        self.do_upscale = False

    @property
    def do_upscale(self) -> bool:
        """Whether to upscale the input for inference."""
        return self._do_upscale

    @do_upscale.setter
    def do_upscale(self, value: bool) -> None:
        if not isinstance(value, bool):
            raise ValueError("do_upscale must be a boolean")
        self._do_upscale = value

    def _preprocess(self, ims: np.ndarray) -> np.ndarray:
        """Transform the input image so that the model can infer from it.

        Args:
            ims: The input image(s).

        Returns:
            Preprocessed image.
        """
        if self.model.alloc_arrays is not None:
            return resize_and_center_images_in_batch(
                ims, self.model.alloc_arrays, self.do_upscale
            )
        out = preprocess_yolo(
            ims, self.model.input_hw, self.model.dtype, self.do_upscale
        )
        return out

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:  # pylint:disable=unused-argument
        """Transform raw model output into meaningful results."""
        preds = []

        for det_logits, im0_hw in zip(output["output0"], self.orig_hw):
            bboxes, p_bbox, classes, p_class_given_bbox = postprocess_yolo(
                det_logits,
                self.model.input_hw,
                im0_hw,
                conf_thresh=self.det_conf_thresh,
                iou_thresh=self.det_iou_thresh,
                was_upscaled=self.do_upscale,
            )
            preds.append(np.c_[bboxes, p_bbox, classes, p_class_given_bbox])

        return preds

    def _to_results(self, output: Sequence[np.ndarray]) -> List[Results]:
        """Convert the model output to a Results object."""
        return [
            Results.from_yolo_output(
                out, image_hw=im0_hw, cls_map=self.cls_map
            ).apply_confidence_map(self.conf_map, self.cls_map)
            for out, im0_hw in zip(output, self.orig_hw)
        ]
