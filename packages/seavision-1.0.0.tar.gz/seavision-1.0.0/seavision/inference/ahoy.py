"""AHOY model for object and horizon detection."""

import logging
from typing import Any, Dict, List, Sequence, Tuple, Union

import numpy as np

from .postprocessing import postprocess_ahoy, postprocess_ahoyv2
from .results import Results
from .seayolo import SeaYOLO

logger = logging.getLogger(__name__)


class AHOY(SeaYOLO):
    """Base class for AHOY models.

    AHOY extends SeaYOLO with horizon detection capabilities.

    AHOY Stands for the following:
    - **A**
    - **H**orizon and
    - **O**bject detection
    - **Y**olo-based model
    """

    def __new__(cls, *args: Tuple[Any], **kwargs: Dict[str, Any]) -> "AHOY":
        """Create the appropriate AHOY model instance based on the model path.

        Args:
            *args: Positional arguments passed to the constructor.
            **kwargs: Keyword arguments passed to the constructor.

        Returns:
            An instance of either AHOYv1 or AHOYv2 based on the model path.
        """
        model_path = kwargs.get("model_path") or (args[0] if args else None)
        if model_path is None:
            raise ValueError("model_path must be provided")

        is_v2 = any(x in model_path.lower() for x in ("ahoyv2", "obb"))
        base = AHOYv2 if is_v2 else AHOYv1

        if cls is AHOY:
            return super().__new__(base)

        # Build subclass with new base
        subclass = type(cls.__name__, (cls, base), {})
        instance = super().__new__(subclass)
        return instance

    def __init__(
        self,
        model_path: str,
        device: Union[int, str, None] = None,
        super_init_only: bool = False,
    ) -> None:
        """Initialize the AHOY model.

        Args:
            model_path: Path to the model file containing the weights and architecture.
            device: CUDA device to use.
            super_init_only: Whether to only initialize the superclass.
        """
        super().__init__(model_path, device, super_init_only)
        if super_init_only:
            return

        # AHOY-specific attribute for horizon detection
        self.hor_conf_thresh = 0.05

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:  # pylint:disable=unused-argument
        """Transform raw model output into meaningful results."""
        raise NotImplementedError("Subclass must implement this method")

    def _to_results(self, output: Sequence[np.ndarray]) -> List[Results]:
        """Convert the model output to a Results object."""
        return [
            Results.from_ahoy_output(
                out, image_hw=im0_hw, cls_map=self.cls_map
            ).apply_confidence_map(self.conf_map, self.cls_map)
            for out, im0_hw in zip(output, self.orig_hw)
        ]


class AHOYv1(AHOY):
    """AHOYv1 model implementation.

    Horizon detection is achieved via a model with two classifiers:
    - offset: the midpoint of the horizon
    - theta: the angle of the horizon
    """

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:
        """Transform raw model outputs into meaningful results.

        Args:
            output: Raw model output. Keys are the output tensor names.
                `output0` is the yolo output
                `output1` is the offset output (midpoint of the horizon)
                `output2` is the theta output (angle of the horizon)

        Returns:
            Every element is a np.ndarray of shape `(N, 6)` where:
                `N` is the number of detected bounding boxes,
                the first 4 are the coordinates of the bounding box,
                the 5th is the confidence score of the bounding box,
                the 6th is the class label of the detected bounding box.
        """
        return postprocess_ahoy(
            output_yolo=output["output0"],
            output_offset=output["output1"],
            output_theta=output["output2"],
            input_hw=self.model.input_hw,
            orig_hw=self.orig_hw,
            det_conf_thresh=self.det_conf_thresh,
            det_iou_thresh=self.det_iou_thresh,
            hor_conf_thresh=self.hor_conf_thresh,
            was_upscaled=self.do_upscale,
        )


class AHOYv2(AHOY):
    """AHOYv2 model implementation.

    Horizon detection is achieved via an OBB detection model whose
    output is transformed into a horizon line.
    """

    def _postprocess(self, output: Dict[str, np.ndarray]) -> Sequence[np.ndarray]:
        """Transform raw model outputs into meaningful results.

        Args:
            output: Raw model output. Keys are the output tensor names.
                `output0` is the yolo output
                `output1` is the obb output

        Returns:
            Every element is a np.ndarray of shape `(N, 6)` where:
                `N` is the number of detected bounding boxes,
                the first 4 are the coordinates of the bounding box,
                the 5th is the confidence score of the bounding box,
                the 6th is the class label of the detected bounding box.
        """
        return postprocess_ahoyv2(
            output_yolo=output["output0"],
            output_yolo_obb=output["output1"],
            input_hw=self.model.input_hw,
            orig_hw=self.orig_hw,
            det_conf_thresh=self.det_conf_thresh,
            det_iou_thresh=self.det_iou_thresh,
            hor_conf_thresh=self.hor_conf_thresh,
            was_upscaled=self.do_upscale,
        )
