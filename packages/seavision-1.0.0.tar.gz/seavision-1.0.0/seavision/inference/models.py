"""SEA.AI's inference models."""

import os
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .ahoy import AHOY
from .dan import DAN
from .holy import HOLY
from .louisnet import LouisNet
from .model_abc import Model
from .rahi import RAHI
from .sahi import SAHI
from .seayolo import SeaYOLO
from .yolo import YOLO

try:
    from seavision.utils.general import LOGGER
except ImportError:
    import logging

    LOGGER = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)


class ModelVariant(Enum):
    """Enum for model variants."""

    NONE = None
    SAHI = SAHI
    RAHI = RAHI

    def __eq__(self, other: object) -> bool:
        if isinstance(other, str):
            return self.name == other
        if isinstance(other, ModelVariant):
            return self is other  # Enforces Enum identity comparison
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.name)

    @classmethod
    def _missing_(cls, value: object) -> "ModelVariant":
        # if value is a string, return the enum member with same name, otherwise NONE
        return (
            cls.__members__.get(value, cls.NONE) if isinstance(value, str) else cls.NONE
        )


class ModelFactory:
    """Factory class for creating appropriate model instances based on path names."""

    # Extension-based routing: {extension: {keyword: ModelClass}}
    _extension_routing = {
        ".pt": {"yolo": YOLO},
    }

    # Keyword-based routing: {keyword: ModelClass}
    _keyword_routing = {
        "ahoy": AHOY,
        "dan": DAN,
        "holy": HOLY,
        "yolo": SeaYOLO,
    }

    @classmethod
    def create_model(
        cls,
        path: Union[str, Path],
        device: Optional[str] = None,
        model_variant: Optional[ModelVariant] = None,
        **kwargs: Dict[str, Any],
    ) -> Model:
        """Create appropriate model instance based on path name and optional variant.

        Args:
            path: Path-like object or string representing model path
            device: Device to load model onto (optional)
            model_variant: Optional ModelVariant enum to create special model variants
            **kwargs: Additional arguments to pass to model constructor

        Returns:
            Instantiated model object
        """
        path_str = str(path)
        path_obj = Path(path_str)
        stem = path_obj.stem.lower()
        suffix = path_obj.suffix.lower()

        # Check model variant
        if model_variant and model_variant != ModelVariant.NONE:
            return model_variant.value(path_str, device=device, **kwargs)

        # Check extension-specific routing
        if suffix in cls._extension_routing:
            for keyword, model_class in cls._extension_routing[suffix].items():
                if keyword in path_str.lower():
                    return model_class(path_str, device=device, **kwargs)

        # Check keyword-based routing
        for keyword, model_class in cls._keyword_routing.items():
            if keyword in stem:
                return model_class(path_str, device=device, **kwargs)

        # Default fallback
        return LouisNet(path_str, device=device)


def _resolve_model_path_local(model_path: str) -> Optional[str]:
    """Return model_path if it exists on disk, else None."""
    p = Path(model_path)
    return str(p.resolve()) if p.exists() else None


def _resolve_model_path_hf(model_path: str, repo_id: str) -> Optional[str]:
    """Try to resolve via Hugging Face Hub. Returns local path or None."""
    from seavision.utils.downloads import attempt_download_from_hf

    return attempt_download_from_hf(repo_id, model_path)


def _resolve_model_path_wandb(model_path: str) -> Optional[str]:
    """Try to resolve via W&B (registry or run artifact). Returns local path or None."""
    if ":" not in model_path:
        return None
    from seavision.utils.downloads import attempt_download_from_wandb

    return attempt_download_from_wandb(model_path.strip())


def list_models(
    extension: Optional[str] = None,
    hf_org: Optional[str] = None,
    hf_repo: Optional[str] = None,
) -> List[str]:
    """List all models in the SeaVision repository."""
    from seavision.utils.downloads import list_hf_models

    hf_org = hf_org or os.getenv("SEAVISION_HF_ORG", "SEA-AI")
    hf_repo = hf_repo or os.getenv("SEAVISION_HF_REPO", "seavision")

    return list_hf_models(repo_id=f"{hf_org}/{hf_repo}", extension=extension)


def load_model(
    model_path: str,
    model_variant: Optional[ModelVariant] = None,
    device: Optional[str] = None,
    hf_org: Optional[str] = None,
    hf_repo: Optional[str] = None,
    **kwargs: Dict[str, Any],
) -> Model:
    """Load a model by name.

    Args:
        model_path: Path to the model file, hugging face model name, or wandb artifact.
            for hugging face models, use the format `organization/model_name`.
            for wandb artifacts, use the format `collection:version`
            or `entity/project/artifact:version`.
        model_variant: Optional ModelVariant enum to create special model variants.
        device: Device to load model onto (optional).
        hf_org: Hugging Face organization (optional).
        hf_repo: Hugging Face repository (optional).
        **kwargs: Additional arguments to pass to model constructor.
    """
    hf_org = hf_org or os.getenv("SEAVISION_HF_ORG", "SEA-AI")
    hf_repo = hf_repo or os.getenv("SEAVISION_HF_REPO", "seavision")

    path = None
    for candidate in (
        _resolve_model_path_local(model_path),
        _resolve_model_path_hf(model_path, f"{hf_org}/{hf_repo}"),
        _resolve_model_path_wandb(model_path),
    ):
        if candidate:
            path = Path(candidate)
            break
    if path is None or not path.exists():
        raise FileNotFoundError(
            f"Model file not found: {model_path!r}. Check the path, use Hugging Face "
            "(huggingface-cli login), or for W&B refs (wandb login)."
        )

    # Load the model form the factory
    model = ModelFactory.create_model(
        path, device=device, model_variant=model_variant, **kwargs
    )

    LOGGER.info(f"🚀 Using model: ✨{model.__class__.__name__}✨")
    return model
