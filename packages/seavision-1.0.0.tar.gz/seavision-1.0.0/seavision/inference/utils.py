"""Utility functions for inference."""

import contextlib
import time
from dataclasses import dataclass, field
from traceback import TracebackException
from types import TracebackType
from typing import Dict, List

import numpy as np


class Profile(contextlib.ContextDecorator):
    """Usage: @Profile() decorator or 'with Profile():' context manager."""

    def __init__(self, t: float = 0.0) -> None:
        """Initialize the Profile context manager.

        Args:
            t: The initial time value.
        """
        self.t = t
        self.start = 0.0
        self.dt = 0.0

    def __enter__(self) -> "Profile":
        self.start = Profile.time()
        return self

    def __exit__(
        self, exc_type: Exception, exc_val: TracebackException, exc_tb: TracebackType
    ) -> None:
        self.dt = Profile.time() - self.start  # delta-time
        self.t += self.dt  # accumulate dt

    @staticmethod
    def time() -> float:
        """Return the current time in seconds."""
        return time.time()

    def reset(self) -> None:
        """Reset the accumulated time."""
        self.t = 0.0


@dataclass
class LabelEncoder:
    """Encode labels to integers and vice versa."""

    label_to_int: Dict[str, int] = field(
        init=False, metadata={"description": "Label to integer mapping"}
    )
    int_to_label: Dict[int, str] = field(
        init=False, metadata={"description": "Integer to label mapping"}
    )
    classes_: List[str] = field(
        init=False, metadata={"description": "Classes in the order they were fitted"}
    )

    def __post_init__(self) -> None:
        """Post-initialization hook."""
        self.label_to_int = {}
        self.int_to_label = {}
        self.classes_ = []

    def fit(self, labels: list[str]) -> None:
        """Fits the encoder to the labels."""
        self.classes_ = sorted(set(labels))
        self.label_to_int = {label: idx for idx, label in enumerate(self.classes_)}
        self.int_to_label = {idx: label for label, idx in self.label_to_int.items()}

    def transform(self, labels: list[str]) -> np.ndarray:
        """Transform a list of labels to integers."""
        return np.array([self.label_to_int.get(label, -1) for label in labels])

    def inverse_transform(self, ints: np.ndarray) -> np.ndarray:
        """Transform a list of integers back to their original labels."""
        return np.array([self.int_to_label.get(i, None) for i in ints])


def yolov8_to_yolov5(model_output: np.ndarray) -> np.ndarray:
    """Convert YOLOv8 output to YOLOv5 format.

    Transpose the model output and add a fake objectness score
    which is the argmax of the class probabilities.

    Args:
        model_output: np.ndarray of shape `(4 + NC, N)` where:
            `N` is the number of detected bounding boxes,
            the first 4 are the coordinates of the bounding box,
            the last `NC` are the class probabilities.

    Returns:
        A numpy array of shape `(N, 4 + 1 + NC)` where:
            `N` is the number of detected bounding boxes,
            the first 4 are the coordinates of the bounding box,
            the 5th is the confidence score of the bounding box,
            the last `NC` are the class probabilities.

    Example:
        ```python
        model_output = np.random.rand(4 + NC, N)
        yolov8_to_yolov5(model_output)
        ```
    """
    # (NC + 4, N) -> (N, NC + 4)
    model_output = np.moveaxis(model_output, 0, 1)

    bboxes = model_output[..., :4]
    p_class_given_bbox = model_output[..., 4:]
    objectness = np.max(p_class_given_bbox, axis=1, keepdims=True)  # fake objectness
    return np.concatenate([bboxes, objectness, p_class_given_bbox], axis=1)
