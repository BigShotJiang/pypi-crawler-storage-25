"""YOLO model for object detection."""

import math
import platform
import warnings
from typing import List, Optional, Sequence, Tuple, Union

import numpy as np

from seavision.utils.general import LOGGER

from .infer_abc import IO
from .model_abc import Model
from .results import Results


def make_divisible(x: int, divisor: int) -> int:
    """Adjusts `x` to be divisible by `divisor`.

    Returns the nearest greater or equal value.
    """
    return math.ceil(x / divisor) * divisor


class YOLO(Model):
    """YOLO model for object detection."""

    def __init__(
        self,
        model_path: str,
        device: Union[int, str] = None,
        imgsz: Optional[Union[int, Tuple[int, int]]] = None,
        do_upscale: bool = False,
    ) -> None:
        """Initialize the YOLO model.

        Args:
            model_path: Path to the model file containing the weights and architecture.
            device: CUDA device to use.
            imgsz: Image size to use for inference. If None, the input shape is adjusted
                to the nearest greater or equal multiple of the model stride.
            do_upscale: If True, upscale the image to the model input size.
        """
        import torch

        # Ignore torch.cuda.amp.autocast warning
        warnings.filterwarnings("ignore", category=FutureWarning)

        super().__init__()

        self.do_upscale = do_upscale
        self.imgsz = imgsz
        if not self.imgsz:
            LOGGER.info(
                "YOLO model initialized without explicit imgsz, "
                "no resizing will be applied during preprocessing."
            )
        else:
            LOGGER.info(
                f"YOLO model initialized with imgsz {self.imgsz}, "
                f"longer side will be resized to the nearest multiple of "
                f"the model stride."
            )

        # if darwin, use mps
        device = "mps" if device is None and platform.system() == "Darwin" else device
        self.model = torch.hub.load(
            "ultralytics/yolov5", "custom", model_path, device=device
        )
        self.model.agnostic = True
        self.model.iou = 0.1
        self.model.conf = 0.147
        self.model.multi_label = False
        self.model.max_det = 100
        self.model.verbose = True
        self.init_cls_map()

    def init_cls_map(
        self,
        _cls_map_fpath: str = "",
        _reverse: bool = False,
        _multi_input: bool = False,
    ) -> None:
        """Initialize class mapping. Overridden from superclass."""
        self.cls_map = self.model.names

    def preprocess_hook(
        self, ims: Union[np.ndarray, Sequence[np.ndarray]]
    ) -> Union[np.ndarray, Sequence[np.ndarray]]:
        """Preprocessing to satisfy requirements of preprocess."""
        ims_count = [len(ims)] if isinstance(ims, list) else [1]
        self.model.inputs = [
            IO(
                name="images",
                shape=(ims_count[0], 3, self.imgsz, self.imgsz),
                dtype=ims.dtype if isinstance(ims, np.ndarray) else ims[0].dtype,
            )
        ]
        return ims

    def _preprocess(self, ims: Union[np.ndarray, Sequence[np.ndarray]]) -> Sequence:  # noqa: PLR6301
        """Preprocess the input images."""
        return ims

    def forward(self, ims: Union[np.ndarray, Sequence[np.ndarray]]) -> Sequence:
        """Forward pass of the YOLO model."""
        if isinstance(self.imgsz, (tuple, int)):
            return self.model(ims, size=self.imgsz).pred

        sizes = [make_divisible(max(im.shape), self.model.stride) for im in ims]
        output = [self.model(im, size=size) for im, size in zip(ims, sizes)]
        return [out.pred[0] for out in output]  # squeeze since batch size was 1

    def _postprocess(self, output: Sequence) -> Sequence:  # noqa: PLR6301
        """Rescale bounding boxes to take into account applied pading."""
        return output

    def _to_results(self, output: Sequence[np.ndarray]) -> List[Results]:
        """Convert the model output to a Results object."""
        return [
            Results.from_yolo_output(out, image_hw=im0_hw, cls_map=self.cls_map)
            for out, im0_hw in zip(output, self.orig_hw)
        ]

    @property
    def det_conf_thresh(self) -> float:
        """Confidence threshold for p(class).

        Predictions with score<conf are ignored.
        """
        return self.model.conf

    @det_conf_thresh.setter
    def det_conf_thresh(self, value: float) -> None:
        if not 0 <= value <= 1:
            raise ValueError("det_conf_thresh must be in [0, 1]")
        self.model.conf = value

    @property
    def det_iou_thresh(self) -> float:
        """Minimum IOU to be counted as a duplicate detection."""
        return self.model.iou

    @det_iou_thresh.setter
    def det_iou_thresh(self, value: float) -> None:
        if not 0 <= value <= 1:
            raise ValueError("det_iou_thresh must be in [0, 1]")
        self.model.iou = value
