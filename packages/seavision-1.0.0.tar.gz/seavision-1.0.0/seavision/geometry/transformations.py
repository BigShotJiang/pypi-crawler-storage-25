"""Camera transformations."""

from typing import Tuple

import numpy as np
from scipy.spatial.transform import Rotation as R


def convert_rpy(
    roll_c: float, pitch_c: float, yaw_c: float
) -> Tuple[float, float, float]:
    """Convert roll, pitch, yaw to world coordinates.

    The function transforms the Sentry coordinate system into the Offshore coordinate
    system. The equations were derived using Mathematica to solve the transformations
    required to convert the roll, pitch, and yaw angles from the Sentry coordinate
    system to the Offshore coordinate system (the reference convention).

    Args:
        roll_c: Roll angle in degrees.
        pitch_c: Pitch angle in degrees.
        yaw_c: Yaw angle in degrees.

    Returns:
        Tuple[float, float, float]: Roll, pitch, yaw in degrees in world coordinates.
    """
    # from this function was cloned from
    # SEA-AI/Core-Backend/
    # blob/develop/Core/Utils/calibration_conventions.py
    roll_c, pitch_c, yaw_c = np.deg2rad([roll_c, pitch_c, yaw_c])

    cy = np.cos(yaw_c)
    cp = np.cos(pitch_c)
    cr = np.cos(roll_c)
    sy = np.sin(yaw_c)
    sp = np.sin(pitch_c)
    sr = np.sin(roll_c)
    a = np.sqrt(
        np.power(cy, 2) * np.power(sr, 2)
        - 2 * cr * cy * sp * sr * sy
        + np.power(cr, 2) * (np.power(cp, 2) + np.power(sp, 2) * np.power(sy, 2))
    )
    b = cr * cy * sp + sr * sy

    roll_w = np.arctan2(cr * sp * sy - cy * sr, cp * cr)
    pitch_w = np.arctan2(a * b, (1 - b) * (1 + b))
    yaw_w = np.arctan2(cr * sy - cy * sp * sr, cp * cy)

    roll_w, pitch_w, yaw_w = np.rad2deg([roll_w, pitch_w, yaw_w])
    return roll_w, pitch_w, yaw_w


def rotation_matrix_from_rpy(
    roll: float,
    pitch: float,
    yaw: float,
    degrees: bool = True,
    angle_conversion: bool = False,
) -> np.ndarray:
    """Compute the rotation matrix from roll, pitch, yaw. Input should be in radians.

    Args:
        roll: Roll angle. By default, in degrees.
        pitch: Pitch angle. By default, in degrees.
        yaw: Yaw angle. By default, in degrees.
        degrees: If True, input angles are in degrees. Otherwise, radians are expected.
            Default is True.
        angle_conversion: If True, convert to world coordinates. Default is False.

    Returns:
        Rotation matrix.
    """
    if angle_conversion:
        roll, pitch, yaw = convert_rpy(roll, pitch, yaw)

    # Create a rotation object using roll, pitch, and yaw
    rotation = R.from_euler("zxy", [roll, pitch, yaw], degrees=degrees)

    # Return the rotation matrix
    return rotation.as_matrix()


def camera_matrix_from_intrinsic(
    fx: float, fy: float, cx: float, cy: float, negated_focal_length: bool = False
) -> np.ndarray:
    """Create intrinsic camera matrix with focal lengths negated.

    Args:
        fx: Focal length in x direction.
        fy: Focal length in y direction.
        cx: Principal point in x direction.
        cy: Principal point in y direction.
        negated_focal_length: If True, return the camera matrix with negated focal
            lengths. If False, return the external camera matrix. Default is False.

    Returns:
        Intrinsic camera matrix.
    """
    sign = -1.0 if negated_focal_length else 1.0
    K = np.array([[sign * fx, 0, cx], [0, sign * fy, cy], [0, 0, 1]], dtype=np.float64)
    return K


def homography_from_intrinsics_and_rotation(
    cam_mat_i: np.ndarray,
    rot_mat_i: np.ndarray,
    cam_mat_j: np.ndarray,
    rot_mat_j: np.ndarray,
) -> np.ndarray:
    """Compute homography matrix from camera i to camera j.

    equation: H_ij = K_j @ R_j^-1 @ R_i @ K_i^-1

    Args:
        cam_mat_i: Intrinsic matrix of camera i.
        rot_mat_i: Rotation matrix of camera i.
        cam_mat_j: Intrinsic matrix of camera j.
        rot_mat_j: Rotation matrix of camera j.

    Returns:
        Homography matrix.
    """
    H = cam_mat_j @ np.linalg.inv(rot_mat_j) @ rot_mat_i @ np.linalg.inv(cam_mat_i)
    return H


def apply_homography(pts: np.ndarray, homography: np.ndarray) -> np.ndarray:
    """Apply a homography to a set of 2D points.

    Args:
        pts: Array of points of shape (N, 2) or homogeneous 3D points of shape (N, 3).
        homography: 3x3 Homography matrix.

    Returns:
        Transformed 2D points of shape (N, 2).
    """
    pts = np.array(pts)  # ensure pts is a numpy array

    if pts.ndim == 1:
        pts = pts[np.newaxis, :]

    assert pts.shape[1] == 2 or pts.shape[1] == 3, "Points must be 2D or homogeneous 3D"  # noqa: PLR2004

    # If points are in 2D, convert them to homogeneous coordinates
    if pts.shape[1] == 2:  # noqa: PLR2004
        pts = np.hstack(
            [pts, np.ones((pts.shape[0], 1))]
        )  # Add a column of 1s for homogeneous coordinates

    # Apply the homography matrix
    transformed_pts = (homography @ pts.T).T

    # Convert back from homogeneous to Cartesian coordinates
    return (transformed_pts[:, :2] / transformed_pts[:, 2][:, np.newaxis]).squeeze()
