"""Utility functions for geometry."""

import cv2
import numpy as np


def create_affine_matrix(
    dx: float = 0.0,
    dy: float = 0.0,
    scale_x: float = 1.0,
    scale_y: float = 1.0,
    rotation_deg: float = 0.0,
) -> np.ndarray:
    """Create a 2D affine transformation matrix for translation, scaling, and rotation.

    Rotation (and uniform scale around the rotation center) uses
    :func:`cv2.getRotationMatrix2D`, which only supports one scale factor for both axes.
    Independent ``scale_x`` / ``scale_y`` scaling is applied separately via the
    ``scale_matrix`` numpy multiply.

    Args:
        dx: Translation in the x-direction (default is 0.0).
        dy: Translation in the y-direction (default is 0.0).
        scale_x: Scaling factor in the x-direction (default is 1.0).
        scale_y: Scaling factor in the y-direction (default is 1.0).
        rotation_deg: Rotation angle in degrees (counterclockwise, default is 0.0).

    Returns:
        A 3x3 affine transformation matrix.
    """
    center = (0, 0)  # Rotation center at origin
    rotation_matrix = cv2.getRotationMatrix2D(
        center, rotation_deg, 1.0
    )  # Rotation without scaling

    # Apply separate scale factors for x and y
    scale_matrix = np.array([[scale_x, 0, 0], [0, scale_y, 0], [0, 0, 1]])

    # Convert 2x3 rotation matrix to homogeneous 3x3
    rotation_homogeneous = np.vstack([rotation_matrix, [0, 0, 1]])

    # Combine scaling and rotation
    affine_matrix = rotation_homogeneous @ scale_matrix

    # Apply translations
    affine_matrix[0, 2] += dx
    affine_matrix[1, 2] += dy

    return affine_matrix
