"""Simplified distance estimation using 3D vector and sea surface intersection.

This module provides classes for estimating distance and bearing to targets
detected in images, using camera intrinsics and orientation data.

This method is only compatible with ONEBERRY configuration (for now).

"""

import json
import math
import pathlib
from enum import Enum
from typing import Optional, Tuple

import numpy as np
from pydantic import BaseModel, ConfigDict, Field
from scipy.spatial.transform import Rotation


class Status(Enum):
    """Status of the target estimate."""

    OK = "OK"
    BEHIND_CAMERA = "Behind camera"
    ABOVE_HORIZON = "Above horizon"


class CameraParameters(BaseModel):
    """Camera intrinsic and extrinsic parameters."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    fx: float = Field(gt=0, description="Focal length X in pixels")
    fy: float = Field(gt=0, description="Focal length Y in pixels")
    cx: float = Field(ge=0, description="Principal point X in pixels")
    cy: float = Field(ge=0, description="Principal point Y in pixels")
    roll: float = Field(description="Camera roll angle in degrees")
    pitch: float = Field(description="Camera pitch angle in degrees")
    yaw: float = Field(description="Camera yaw angle in degrees")
    position_mm: Optional[np.ndarray] = Field(
        default=None, description="Camera position [x, y, z] in mm"
    )
    focal_length_mm: Optional[float] = Field(
        default=None, gt=0, description="Lens focal length in millimeters"
    )
    pixel_pitch_um: Optional[float] = Field(
        default=None, gt=0, description="Pixel size in micrometers"
    )
    sensor_resolution: Optional[Tuple[int, int]] = Field(
        default=None, description="Image dimensions as (width, height) in pixels"
    )

    @classmethod
    def from_focal_length(  # pylint: disable=too-many-arguments
        cls,
        focal_length_mm: float,
        pixel_pitch_um: float,
        sensor_resolution: Tuple[int, int],
        *,
        roll: float = 0.0,
        pitch: float = 0.0,
        yaw: float = 0.0,
        position_mm: Optional[np.ndarray] = None,
    ) -> "CameraParameters":
        """Create CameraParameters from physical parameters.

        Args:
            focal_length_mm: Lens focal length in millimeters
            pixel_pitch_um: Pixel size in micrometers
            sensor_resolution: Image dimensions as (width, height) in pixels
            roll: Camera roll angle in degrees (default: 0.0)
            pitch: Camera pitch angle in degrees (default: 0.0)
            yaw: Camera yaw angle in degrees (default: 0.0)
            position_mm: Camera position [x, y, z] in mm

        Returns:
            CameraParameters instance
        """
        pixel_pitch_mm = pixel_pitch_um / 1000.0
        fx = focal_length_mm / pixel_pitch_mm
        fy = focal_length_mm / pixel_pitch_mm
        cx = sensor_resolution[0] / 2.0
        cy = sensor_resolution[1] / 2.0

        return cls(
            fx=fx,
            fy=fy,
            cx=cx,
            cy=cy,
            roll=roll,
            pitch=pitch,
            yaw=yaw,
            position_mm=position_mm,
            focal_length_mm=focal_length_mm,
            pixel_pitch_um=pixel_pitch_um,
            sensor_resolution=sensor_resolution,
        )

    @classmethod
    def from_json(
        cls,
        json_path: str,
        camera_name: str,
    ) -> "CameraParameters":
        """Load CameraParameters from a JSON configuration file.

        Args:
            json_path: Path to the JSON configuration file
            camera_name: Name of the camera in the JSON config (e.g., "t1")

        Returns:
            CameraParameters instance

        Raises:
            FileNotFoundError: If the JSON file doesn't exist
            ValueError: If JSON is malformed
            KeyError: If camera name not found in config

        Example JSON structure:
            {
                "cameras": {
                    "t1": {
                        "focal_length_x": {"value": 1112.61},
                        "focal_length_y": {"value": 1112.50},
                        "center_x": {"value": 319.5},
                        "center_y": {"value": 255.5},
                        "roll": {"value": 0.0},
                        "pitch": {"value": 0.0},
                        "yaw": {"value": 0.0},
                        "position": {"value": [-115.4, 63.6, 42.0]}
                    }
                }
            }
        """
        try:
            with pathlib.Path(json_path).open("r", encoding="utf-8") as f:
                data = json.load(f)
            cam_data = data["cameras"][camera_name]
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Camera config not found: {json_path}") from e
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {json_path}: {e}") from e
        except KeyError as e:
            if "cameras" not in data:
                raise KeyError(f"'cameras' key not found in config: {json_path}") from e
            available = ", ".join(data["cameras"].keys())
            raise KeyError(
                f"Camera '{camera_name}' not found in config. Available: {available}"
            ) from e

        return cls(
            fx=cam_data["focal_length_x"]["value"],
            fy=cam_data["focal_length_y"]["value"],
            cx=cam_data["center_x"]["value"],
            cy=cam_data["center_y"]["value"],
            roll=cam_data["roll"]["value"],
            pitch=cam_data["pitch"]["value"],
            yaw=cam_data["yaw"]["value"],
            position_mm=np.array(cam_data["position"]["value"]),
            sensor_resolution=(
                int(cam_data["center_x"]["value"] * 2),
                int(cam_data["center_y"]["value"] * 2),
            ),
        )


class SystemPose(BaseModel):
    """System orientation and position parameters.

    Note: All rotations follow right-hand rule in the NED-adapted
    coordinate system (X=forward, Y=port, Z=up). Yaw represents compass
    heading (clockwise convention), while the rotation matrix applies the
    corresponding transformation.
    """

    imu_roll: float = Field(
        description="Vessel roll angle in degrees (positive = port/left side down)"
    )
    imu_pitch: float = Field(
        description="Vessel pitch angle in degrees (positive = bow up)"
    )
    imu_yaw: float = Field(
        description="Vessel heading in degrees (0° = North, 90° = East, "
        "clockwise from North)"
    )
    mounting_height_m: float = Field(
        ge=0, description="Mast/sensor height above sea level in meters"
    )
    ptu_pan: float = Field(
        default=0.0,
        description="PTU pan angle in degrees (positive = counter-clockwise "
        "viewed from above)",
    )
    ptu_tilt: float = Field(
        default=0.0, description="PTU tilt angle in degrees (positive = tilt up)"
    )


class TargetEstimate(BaseModel):  # pylint: disable=too-many-instance-attributes
    """Estimated target's distance and bearing."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    distance: float = Field(description="Distance to target in meters")
    bearing: float = Field(description="Relative bearing to target in degrees")
    status: Status = Field(
        default=Status.OK,
        description="Status of estimation",
    )
    target_position: Optional[np.ndarray] = Field(
        default=None, description="3D position of target [x, y, z] in meters"
    )
    distance_3d_m: Optional[float] = Field(
        default=None, description="3D distance to target in meters"
    )
    horizontal_range_m: Optional[float] = Field(
        default=None, description="Horizontal range to target in meters"
    )
    azimuth_deg: Optional[float] = Field(
        default=None, description="Absolute azimuth to target in degrees"
    )
    relative_bearing_deg: Optional[float] = Field(
        default=None, description="Relative bearing to target in degrees"
    )
    elevation_deg: Optional[float] = Field(
        default=None, description="Elevation angle to target in degrees"
    )

    def is_valid(self) -> bool:
        """Check if the target estimate is valid."""
        return self.status == Status.OK


class ApproximateDistEstimator:
    """Estimates distance and bearing using full kinematic chain.

    Coordinate System (NED-like, adapted for maritime):
        - Origin: Vessel reference point at sea level (0, 0, 0)
        - X-axis: Forward (bow direction when yaw=0°)
        - Y-axis: Port side (left when facing bow)
        - Z-axis: Upward (perpendicular to sea surface)
        - Sea surface: Z = 0

    Kinematic Chain:
        Camera Optical Frame → Camera Mount → PTU Tilt → PTU Pan
                             → Mast(IMU) → Global Frame

    The transformation chain applies rotations and translations through each
    joint to transform pixel coordinates from the camera's optical frame into
    global 3D positions for sea surface intersection. The rotation matrix
    R_total is composed as:
    R_total = R_mast @ R_pan @ R_tilt @ R_cam_offset @ R_cam_base
    """

    # Tolerance for near-vertical or invisible horizon line (small R21
    # component causes division instability)
    HORIZON_TOLERANCE = 1e-6

    def __init__(self, camera_params: CameraParameters) -> None:
        """Initialize the distance estimator."""
        self.camera_params = camera_params

    @staticmethod
    def _hough_params_to_slope_intercept(
        rho_h: float, theta_h: float
    ) -> Tuple[float, float]:
        k = -np.cos(theta_h) / np.sin(theta_h)
        d = rho_h / np.sin(theta_h)
        return k, d

    @staticmethod
    def _get_hor_points(
        rho_h: float, theta_h: float, resolution: Tuple[int, int]
    ) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        w, _ = resolution
        k, d = ApproximateDistEstimator._hough_params_to_slope_intercept(rho_h, theta_h)
        p1 = (0, int(d))
        p2 = (w, int(k * w + d))
        return p1, p2

    @staticmethod
    def _euler_angles_to_horizon_points(
        psi_rc: float,
        theta_rc: float,
        resolution: Tuple[int, int],
        focal_and_center: Tuple[float, float, float],
    ) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        fy, cx, cy = focal_and_center
        theta_h = np.pi / 2 - psi_rc
        rho_h = np.sin(psi_rc) * cx + np.cos(psi_rc) * cy - np.tan(theta_rc) * fy
        return ApproximateDistEstimator._get_hor_points(rho_h, theta_h, resolution)

    def _calculate_total_rotation(self, pose: SystemPose) -> np.ndarray:
        """Calculate the total rotation matrix from Camera to Global."""
        r_cam_base = np.array(
            [
                [0, 0, 1],
                [-1, 0, 0],
                [0, -1, 0],
            ]
        )

        r_cam_offset = Rotation.from_euler(
            "ZYX",
            [
                self.camera_params.yaw,
                -self.camera_params.pitch,
                self.camera_params.roll,
            ],
            degrees=True,
        ).as_matrix()

        r_tilt = Rotation.from_euler(
            "ZYX", [0, pose.ptu_tilt, 0], degrees=True
        ).as_matrix()

        r_pan = Rotation.from_euler(
            "ZYX", [pose.ptu_pan, 0, 0], degrees=True
        ).as_matrix()

        r_mast = Rotation.from_euler(
            "ZYX", [pose.imu_yaw, pose.imu_pitch, pose.imu_roll], degrees=True
        ).as_matrix()

        return r_mast @ r_pan @ r_tilt @ r_cam_offset @ r_cam_base

    def calculate_range_and_bearing(  # pylint: disable=too-many-locals  # noqa: PLR0914
        self,
        pose: SystemPose,
        pixel_coords: Tuple[int, int],
    ) -> TargetEstimate:
        """Calculate range and bearing using full kinematic chain.

        Args:
            pose: Current system pose (IMU, PTU, mounting height)
            pixel_coords: (x, y) pixel coordinates of target

        Returns:
            TargetEstimate with distance, bearing, and status
        """
        fx = self.camera_params.fx
        fy = self.camera_params.fy
        cx = self.camera_params.cx
        cy = self.camera_params.cy

        r_mast = Rotation.from_euler(
            "ZYX", [pose.imu_yaw, pose.imu_pitch, pose.imu_roll], degrees=True
        ).as_matrix()

        r_total = self._calculate_total_rotation(pose)

        if self.camera_params.position_mm is not None:
            t_cam = self.camera_params.position_mm / 1000.0  # mm to m
            c_global = r_mast @ t_cam + np.array([0.0, 0.0, pose.mounting_height_m])
        else:
            c_global = np.array([0.0, 0.0, pose.mounting_height_m])

        u, v = pixel_coords
        d_cam = np.array([(u - cx) / fx, (v - cy) / fy, 1.0])
        d_global = r_total @ d_cam
        d_global /= np.linalg.norm(d_global)
        if d_global[2] >= 0:
            return TargetEstimate(
                distance=float("inf"), bearing=0.0, status=Status.ABOVE_HORIZON
            )
        t = -c_global[2] / d_global[2]

        if t <= 0:
            return TargetEstimate(
                distance=0.0, bearing=0.0, status=Status.BEHIND_CAMERA
            )

        p_intersect = c_global + t * d_global

        distance_3d = np.linalg.norm(p_intersect)
        horizontal_range = np.sqrt(p_intersect[0] ** 2 + p_intersect[1] ** 2)
        elevation_deg = math.degrees(math.atan2(p_intersect[2], horizontal_range))
        azimuth_deg = math.degrees(math.atan2(p_intersect[1], p_intersect[0])) % 360.0
        rel_bearing = azimuth_deg - pose.imu_yaw
        rel_bearing = (rel_bearing + 180) % 360 - 180

        return TargetEstimate(
            distance=distance_3d,
            bearing=rel_bearing,
            status="OK",
            target_position=p_intersect,
            distance_3d_m=distance_3d,
            horizontal_range_m=horizontal_range,
            azimuth_deg=azimuth_deg,
            relative_bearing_deg=rel_bearing,
            elevation_deg=elevation_deg,
        )

    def get_valid_range(self, pose: SystemPose) -> Tuple[float, float]:
        """Get the valid detection range for the current pose.

        Approximation using center column.
        """
        _, res_y = self.camera_params.sensor_resolution
        cx = self.camera_params.cx

        est_min = self.calculate_range_and_bearing(pose, (int(cx), res_y))
        est_max = self.calculate_range_and_bearing(pose, (int(cx), 0))

        min_dist = est_min.distance if est_min.status == "OK" else 0.0
        max_dist = est_max.distance if est_max.status == "OK" else float("inf")

        return (min_dist, max_dist)

    def get_horizon_line(  # pylint: disable=too-many-locals
        self, pose: SystemPose
    ) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        """Calculate the horizon line endpoints in the image.

        Returns:
            (p1, p2) where p1 and p2 are (x, y) tuples of the horizon line endpoints.
        """
        if not self.camera_params.sensor_resolution:
            raise ValueError("Sensor resolution required for horizon calculation")

        r_total = self._calculate_total_rotation(pose)

        fx = self.camera_params.fx
        fy = self.camera_params.fy
        cx = self.camera_params.cx
        cy = self.camera_params.cy
        width, _ = self.camera_params.sensor_resolution

        r20, r21, r22 = r_total[2, 0], r_total[2, 1], r_total[2, 2]

        if abs(r21) < ApproximateDistEstimator.HORIZON_TOLERANCE:
            return ((0, int(cy)), (width, int(cy)))

        x1, x2 = 0, width

        y1 = cy - (fy / r21) * (r20 * (x1 - cx) / fx + r22)
        y2 = cy - (fy / r21) * (r20 * (x2 - cx) / fx + r22)

        return ((int(x1), int(y1)), (int(x2), int(y2)))
