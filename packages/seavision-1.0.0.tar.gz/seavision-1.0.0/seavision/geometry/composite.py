"""Create composite images and videos by warping and blending multiple camera views.

Warp and blend multiple camera feeds into one seamless image or video — perfect for:

* 🔧 Verifying **calibration** and **sensor alignment**
* 🌟 Assessing **sensor fusion** coverage
* ⏱️ Checking **recording sync**
* 🎬 Creating slick visualizations

You'll need:

* **Intrinsics**: focal length, principal point, distortion coefficients, etc.
* **Extrinsics**: camera poses (rotation + translation)

How it works:

1. Pick a **master view**
2. Warp others into its frame
3. **Blend** overlapping areas
4. Output the final **composite**
"""

from typing import List, Sequence, Union

import cv2
import numpy as np
from tqdm.auto import tqdm

from seavision.geometry.pinhole import Camera, CameraGeometry
from seavision.io import VideoReader, VideoWriter

MIN_CAMERAS = 2

FrameOrPath = Union[np.ndarray, str]


def _sanity_checks(
    images_or_fpaths: Sequence[FrameOrPath],
    cameras: List[Camera],
    master_idx: int,
) -> None:
    if len(cameras) < MIN_CAMERAS:
        raise ValueError(f"At least {MIN_CAMERAS} cameras are needed for overlay")

    if not 0 <= master_idx < len(cameras):
        raise ValueError(f"Master index must be between 0 and {len(cameras) - 1}")

    if len(cameras) != len(images_or_fpaths):
        raise ValueError("Number of cameras must match number of frames or video paths")


def composite_images(
    images: List[np.ndarray],
    cameras: List[Camera],
    master_idx: int = 0,
    alpha_blend: float = 0.5,
) -> np.ndarray:
    """Create a composite image by warping and blending multiple camera views.

    Args:
        images: List of images from all cameras
        cameras: List of cameras in the same order as the images
        master_idx: Index of the master camera
        alpha_blend: Alpha value for blending in overlapping regions, where 0 means
            only master, 1 means only non-master, and 0.5 means equal blend.

    Returns:
        Composite blended frame
    """
    _sanity_checks(images, cameras, master_idx)

    # Initialize composite with master frame
    composite = images[master_idx].copy()
    composite_height, composite_width = composite.shape[:2]

    # Initialize composite mask to track where pixels have been written
    composite_mask = np.zeros((composite_height, composite_width), dtype=np.uint8)
    composite_mask[...] = 255  # Set initial master frame mask

    for i, image in enumerate(images):
        if i == master_idx:
            continue

        # Warp frame to master perspective
        H = CameraGeometry.compute_homography(cameras[i], cameras[master_idx])
        warped_frame = cv2.warpPerspective(
            image, H, (composite_width, composite_height)
        )

        # Create binary mask for warped frame (255 where there are valid pixels)
        warped_mask = np.any(warped_frame > 0, axis=2).astype(np.uint8) * 255

        # Find overlapping and non-overlapping regions
        overlap_mask = (warped_mask > 0) & (composite_mask > 0)
        non_overlap = (warped_mask > 0) & (composite_mask == 0)

        # convert to 3 channel mask
        overlap_mask = np.stack([overlap_mask, overlap_mask, overlap_mask], axis=2)
        non_overlap = np.stack([non_overlap, non_overlap, non_overlap], axis=2)

        # Copy non-overlapping regions directly
        composite[non_overlap] = warped_frame[non_overlap]

        # For overlapping regions, use weighted blend
        composite = np.where(
            overlap_mask,
            composite * (1 - alpha_blend) + warped_frame * alpha_blend,
            composite,
        )

        # Update composite mask to include newly added pixels
        composite_mask |= warped_mask

    return composite.astype(np.uint8)


def composite_videos(
    video_fpaths: List[str],
    cameras: List[Camera],
    master_idx: int = 0,
    output_fpath: str = "overlay.mp4",
    alpha_blend: float = 0.5,
    progress_bar: bool = True,
) -> str:
    """Generate a video overlay by combining multiple camera views.

    Args:
        video_fpaths: List of video file paths
        cameras: List of cameras in the same order as the video file paths
        master_idx: Index of the master camera (reference frame)
        output_fpath: Output file path
        alpha_blend: Alpha value for blending in overlapping regions
        progress_bar: Whether to show a progress bar

    Returns:
        The output file path
    """
    _sanity_checks(video_fpaths, cameras, master_idx)

    # Open all video captures
    videos = [VideoReader(fpath) for fpath in video_fpaths]

    # Initialize output video writer
    out = VideoWriter(
        output_fpath,
        fps=videos[master_idx].fps,
        frame_width=videos[master_idx].width,
        frame_height=videos[master_idx].height,
    )

    pbar = (
        tqdm(total=min(len(video) for video in videos), desc="Processing frames")
        if progress_bar
        else None
    )
    try:
        # Process frames
        while True:
            # Read frames from all videos
            frames = [next(video) for video in videos]
            if any(frame is None for frame in frames):  # End of video
                break

            # Create overlay from multiple views
            composite = composite_images(
                images=frames,
                cameras=cameras,
                master_idx=master_idx,
                alpha_blend=alpha_blend,
            )

            # Write the composite frame
            out.write(composite)

            if pbar:
                pbar.update(1)
    except StopIteration:
        if pbar:
            pbar.close()

    finally:
        # Release resources
        for video in videos:
            video.close()
        out.close()

    return output_fpath
