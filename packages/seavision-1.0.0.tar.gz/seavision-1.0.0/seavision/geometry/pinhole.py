"""Stitching functions for stereo cameras - refactored architecture.

This module provides a clean separation of concerns:
- Data models: Immutable camera representations
- Geometry: Pure functions for coordinate transformations
- Factory: Camera construction and modification
- Layout: Stereo pair geometry computation
- Stitching: Image warping and blending
"""

from dataclasses import dataclass, replace
from typing import Any, Dict, Self, Tuple

import cv2
import numpy as np
from scipy.spatial.transform import Rotation as R

# ============================================================================
# CORE DATA MODELS
# ============================================================================


@dataclass(frozen=True)
class Camera:
    """Immutable pinhole camera model with intrinsics and pose.

    Represents a camera with known intrinsic parameters (focal length,
    principal point) and extrinsic parameters (orientation in 3D space).

    Convention: x=right, y=down, z=forward (standard pinhole)
    """

    width: int
    height: int
    fx: float  # Focal length x-axis (pixels)
    fy: float  # Focal length y-axis (pixels)
    cx: float  # Principal point x (pixels)
    cy: float  # Principal point y (pixels)
    roll: float  # Rotation around z-axis (degrees)
    pitch: float  # Rotation around x-axis (degrees)
    yaw: float  # Rotation around y-axis (degrees)

    def __post_init__(self) -> None:
        """Validate dimensions are even."""
        if self.width % 2 != 0 or self.height % 2 != 0:
            raise ValueError("Camera dimensions must be even")

    def dict(self) -> Dict[str, Any]:
        """Get the camera as a dictionary."""
        return self.__dict__

    @property
    def size(self) -> Tuple[int, int]:
        """OpenCV-compatible (width, height) tuple."""
        return self.width, self.height

    def extrinsics(self) -> Dict[str, float]:
        """Return pitch/yaw/roll as a plain dict."""
        return {"pitch": self.pitch, "yaw": self.yaw, "roll": self.roll}

    @property
    def corners(self) -> np.ndarray:
        """Image corners as (4, 2) array: [TL, TR, BR, BL]."""
        return np.array(
            [
                [0, 0],
                [self.width, 0],
                [self.width, self.height],
                [0, self.height],
            ],
            dtype=np.float32,
        )

    @property
    def K(self) -> np.ndarray:
        """Get the camera intrinsics matrix."""
        return CameraGeometry.intrinsic_matrix(self)

    @property
    def R(self) -> np.ndarray:
        """Get the camera rotation matrix."""
        return CameraGeometry.rotation_matrix(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Create camera from dictionary of parameters.

        Accepts either 'resolution': [w, h] or 'width'/'height' keys.
        """
        if "resolution" in data:
            width, height = data["resolution"]
        else:
            width = data["width"]
            height = data["height"]

        return cls(
            width=width,
            height=height,
            fx=data["fx"],
            fy=data["fy"],
            cx=data["cx"],
            cy=data["cy"],
            roll=data["roll"],
            pitch=data["pitch"],
            yaw=data["yaw"],
        )

    @classmethod
    def hconcat(cls, left: Self, right: Self) -> Self:
        """Create virtual camera by concatenating two cameras horizontally.

        Averages intrinsics and creates a wider field of view.
        """
        if left.size != right.size:
            raise ValueError("Cameras must have same resolution for concatenation")

        return cls(
            width=left.width + right.width,
            height=max(left.height, right.height),
            fx=(left.fx + right.fx) / 2,
            fy=(left.fy + right.fy) / 2,
            cx=left.width + (right.cx - left.cx) / 2,
            cy=(left.cy + right.cy) / 2,
            roll=0.0,
            pitch=(left.pitch + right.pitch) / 2,
            yaw=0.0,
        )

    def with_extrinsics(
        self,
        *,
        roll: float,
        pitch: float,
        yaw: float,
    ) -> Self:
        """Return a new camera with the same intrinsics and new RPY (degrees)."""
        return replace(self, roll=roll, pitch=pitch, yaw=yaw)


# ============================================================================
# CAMERA GEOMETRY - Pure geometric operations
# ============================================================================


class CameraGeometry:
    """Static methods for camera geometric operations."""

    @staticmethod
    def intrinsic_matrix(
        camera: Camera, flip_focal_lengths: bool = False
    ) -> np.ndarray:
        """Compute 3x3 intrinsic matrix K."""
        flip = -1 if flip_focal_lengths else 1
        return np.array(
            [
                [flip * camera.fx, 0, camera.cx],
                [0, flip * camera.fy, camera.cy],
                [0, 0, 1],
            ],
            dtype=np.float32,
        )

    @staticmethod
    def rotation_matrix(camera: Camera) -> np.ndarray:
        """Compute 3x3 rotation matrix from Euler angles.

        Uses pinhole convention: x=right, y=down, z=forward
        """
        return (
            R.from_euler("zxy", [camera.roll, camera.pitch, camera.yaw], degrees=True)
            .as_matrix()
            .astype(np.float32)
        )

    @staticmethod
    def compute_homography(src: Camera, dst: Camera) -> np.ndarray:
        """Compute homography matrix mapping src pixels to dst pixels.

        The roll pitch and yaw are flipped in the z-plane, so we need to flip the
        focal lengths to get the correct homography matrix. Messy, but it works.

        H transforms points: p_dst = H @ p_src
        """
        K_src = CameraGeometry.intrinsic_matrix(src, flip_focal_lengths=True)
        K_dst = CameraGeometry.intrinsic_matrix(dst, flip_focal_lengths=True)
        R_src = CameraGeometry.rotation_matrix(src)
        R_dst = CameraGeometry.rotation_matrix(dst)

        H = K_dst @ np.linalg.inv(R_dst) @ R_src @ np.linalg.inv(K_src)
        return H.astype(np.float32)

    @staticmethod
    def create_remap_grids(src: Camera, dst: Camera) -> Tuple[np.ndarray, np.ndarray]:
        """Create dense remapping grids from dst to src coordinates.

        Returns:
            (mapx, mapy) where each dst pixel gets its src coordinate
        """
        H = CameraGeometry.compute_homography(src, dst)
        H_inv = np.linalg.inv(H)

        # Create meshgrid of destination pixels
        xs, ys = np.meshgrid(
            np.arange(dst.width, dtype=np.float32),
            np.arange(dst.height, dtype=np.float32),
            indexing="xy",
        )

        # Transform to homogeneous coordinates and apply homography
        ones = np.ones_like(xs, dtype=np.float32)
        dst_coords = np.stack([xs, ys, ones], axis=-1)  # (H, W, 3)
        src_coords_h = dst_coords @ H_inv.T  # (H, W, 3)

        # Normalize by homogeneous coordinate (avoid division by zero)
        src_coords_h[..., 2] = np.clip(src_coords_h[..., 2], 1e-8, None)
        src_coords = src_coords_h[..., :2] / src_coords_h[..., 2:3]

        mapx = np.ascontiguousarray(src_coords[..., 0])
        mapy = np.ascontiguousarray(src_coords[..., 1])

        return mapx, mapy

    @staticmethod
    def project_corners(camera: Camera, target: Camera) -> np.ndarray:
        """Project camera corners into target camera coordinate system.

        Returns:
            (4, 2) array of projected corner coordinates
        """
        H = CameraGeometry.compute_homography(camera, target)
        corners = camera.corners.reshape(1, -1, 2)
        projected = cv2.perspectiveTransform(corners, H)
        return projected[0]

    @staticmethod
    def crop(
        camera: Camera,
        top: float,
        bottom: float,
        left: float,
        right: float,
        force_even: bool = True,
    ) -> "Camera":
        """Return cropped camera with adjusted intrinsics."""
        new_w = int(camera.width - left - right)
        new_h = int(camera.height - top - bottom)

        if new_w <= 0 or new_h <= 0:
            raise ValueError("Crop exceeds image bounds")

        if force_even:
            new_w = (new_w // 2) * 2
            new_h = (new_h // 2) * 2

        return Camera(
            width=new_w,
            height=new_h,
            fx=camera.fx,
            fy=camera.fy,
            cx=camera.cx - left,
            cy=camera.cy - top,
            roll=camera.roll,
            pitch=camera.pitch,
            yaw=camera.yaw,
        )

    @staticmethod
    def crop_to_frame(camera: Camera, frame: np.ndarray) -> Camera:
        """Crop camera intrinsics to match the actual frame dimensions."""
        left = right = (camera.width - frame.shape[1]) // 2
        top = bottom = (camera.height - frame.shape[0]) // 2
        if left <= 0 and top <= 0:
            return camera
        return CameraGeometry.crop(camera, top, bottom, left, right)
