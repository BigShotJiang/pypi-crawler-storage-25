"""Launch the Sentry online calibration web UI.

Starts a local web server for manually calibrating Sentry camera homography
by adjusting pitch, yaw, and roll angles and visually inspecting the overlay.

## Quick Start

```bash
seavision calibration
```

Then open http://localhost:8323 in your browser, paste a recording path,
and start calibrating.

## Examples

### Start with a pre-loaded recording

```bash
seavision calibration --recording /path/to/Sentry_recordings_2024_03_12_10_34_06
```

### Use a different port

```bash
seavision calibration --port 9000
```

### Dry run (preview changes without writing to disk)

```bash
seavision calibration --dry-run
```

### Use a different reference (master) camera

```bash
seavision calibration --reference-camera t_w
```

Tip:
    Without `--recording`, the UI lets you paste or load a recording path
    directly in the browser.
"""

import click

from seavision.calibration.server import run_web_server


@click.command()
@click.option("--recording", default=None, help="Path to a Sentry recording directory.")
@click.option("--port", default=8323, show_default=True, help="Port to listen on.")
@click.option(
    "--host",
    default="0.0.0.0",
    show_default=True,
    help="Host / IP to bind (0.0.0.0 = all interfaces).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Print changes instead of writing to sentry_sensors.json.",
)
@click.option(
    "--reference-camera",
    "reference_camera",
    default=None,
    show_default=False,
    help="Master view to project sources into (default: rgb_w).",
)
def calibration(
    recording: str | None,
    port: int,
    host: str,
    dry_run: bool,
    reference_camera: str | None,
) -> None:
    """Launch the Sentry online calibration web UI."""
    run_web_server(
        recording,
        port,
        host=host,
        dry_run=dry_run,
        reference_camera=reference_camera,
    )
