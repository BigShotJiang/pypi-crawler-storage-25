"""Compose two ONNX models into a single merged model.

This command exposes SeaVision's ONNX composition utility so you can merge
two models directly from the terminal.

## Usage

```bash
seavision compose-onnx MODEL1 MODEL2 OUTPUT
```

## Examples

Merge two local ONNX models:
```bash
seavision compose-onnx ir.onnx rgb.onnx merged.onnx
```

Merge models with input/output prefixes and force FP32 conversion:
```bash
seavision compose-onnx \
  ahoy-IR-b2.onnx \
  ahoy-RGB-b2.onnx \
  models/dan-b2.onnx \
  --prefix1 "ir_" \
  --prefix2 "rgb_" \
  --force-fp32
```
"""

import click


@click.command()
@click.argument("model1", type=str)
@click.argument("model2", type=str)
@click.argument("output", type=str)
@click.option(
    "--prefix1",
    type=str,
    default="",
    show_default=True,
    help="Prefix for the first model's inputs and outputs.",
)
@click.option(
    "--prefix2",
    type=str,
    default="",
    show_default=True,
    help="Prefix for the second model's inputs and outputs.",
)
@click.option(
    "--force-fp32",
    is_flag=True,
    help="Convert models to FP32 before merging.",
)
def compose_onnx(
    model1: str,
    model2: str,
    output: str,
    prefix1: str,
    prefix2: str,
    force_fp32: bool,
) -> None:
    """Compose two ONNX models into one."""
    from seavision.deployment.compose_onnx import merge_onnx_models

    merge_onnx_models(
        model1,
        model2,
        output,
        prefix1=prefix1,
        prefix2=prefix2,
        force_fp32=force_fp32,
    )
