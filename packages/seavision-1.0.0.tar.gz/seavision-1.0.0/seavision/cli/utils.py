"""Utility functions for the CLI."""

import platform
import random
import shlex
from functools import wraps
from typing import Any, Callable, TypeVar

import click
import psutil

import seavision as sv

F = TypeVar("F", bound=Callable[..., Any])


def print_banner():
    """Print the SeaVision CLI banner with style and system info."""
    # 🌍 Platform emoji
    system = platform.system()
    if system == "Darwin":
        system_emoji = "🍏"
    elif system == "Windows":
        system_emoji = "🪟"
    elif system == "Linux":
        system_emoji = "🐧"
    else:
        system_emoji = "💻"

    total_gb = psutil.virtual_memory().total // (1024**3)
    memory_emoji = "💾"

    # 🧵 Threads
    threads = psutil.cpu_count(logical=True)
    threads_info = f"🧵 {threads} threads"

    # ⛵ Maritime flair!
    flair = random.choice(
        ["⚓", "🌊", "🧭", "🐚", "🐬", "🐋", "🚢", "🛥️ ", "⛴️ ", "🛳️ ", "🛟 ", "🪝 "]
    )

    # Components
    title = f"{flair} SeaVision {sv.__version__}"
    python_version = f"🐍 Python {platform.python_version()}"
    system_info = f"{system_emoji} {system} {platform.release()} ({platform.machine()})"
    memory_info = f"{memory_emoji} {total_gb} GB RAM"

    # Print it all
    click.secho(
        " | ".join([title, python_version, system_info, memory_info, threads_info]),
        fg="cyan",
        bold=True,
    )


def echo_resolved_command(f: F) -> F:
    """Decorator that echoes the resolved command before executing it.

    This decorator prints out the full command string that would be executed,
    including all parameters and their values. It's useful for debugging and
    showing users exactly what command is being run.

    Args:
        f: The function to decorate.

    Returns:
        The wrapped function that echoes the command before execution.

    Example:
        @echo_resolved_command
        def my_command():
            pass
    """

    @click.pass_context
    @wraps(f)
    def wrapper(ctx: click.Context, *args: Any, **kwargs: Any) -> Any:
        # Build full command string
        command = ctx.command_path
        params = ctx.params

        formatted_args = []
        for k, v in params.items():
            k = k.replace("_", "") if k.endswith("_") else k
            if isinstance(v, bool):
                if v:
                    formatted_args.append(f"--{k.replace('_', '-')}")
            else:
                formatted_args.append(f"--{k.replace('_', '-')} {shlex.quote(str(v))}")

        full_command = f"{command} {' '.join(formatted_args)}"
        click.secho(f"🚀 CMD: {full_command}\n", fg="cyan")

        return ctx.invoke(f, *args, **kwargs)

    return wrapper  # type: ignore
