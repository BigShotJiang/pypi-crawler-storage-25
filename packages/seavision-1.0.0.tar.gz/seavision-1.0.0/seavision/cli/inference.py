"""Run inference on images and videos using SeaVision's models.

## Features

- 🖼️ **Image Processing**: Run inference on local images
- 🎥 **Video Analysis**: Process local videos, webcams, and RTSP streams
- 🌐 **YouTube Integration**: Analyze YouTube videos directly
- ⚡ **Real-time Processing**: Live inference with optional frame buffering
- 🔄 **Model Selection**: Choose from a variety of pre-trained models

Tip:
    Use `seavision models list` to see all available models.

## Quick Start 🚀

Run inference using your webcam:
```bash
pip install seavision
seavision inference  # webcam window should open
```

## Examples

### Local Video Processing

```bash
seavision inference path/to/video.mp4
```

Tip:
    Use `--buffer` to preserve source's FPS regardless of the model's inference time.

    ```bash
    seavision inference path/to/video.mp4 --buffer
    ```

### RTSP Streams

```bash
seavision inference rtsp://username:password@camera-ip:554/stream
seavision inference rtsp://192.168.1.191:8555/twfov
```

Note:
    By default, frames will be buffered since RTSP streams are live sources.

### YouTube Video Analysis

Warning:
    Live YouTube videos are not supported yet.

Important:
    `pytubefix` is required. Can be installed with `pip install seavision[youtube]`.

```bash
seavision inference https://www.youtube.com/watch?v=ZNehZ52kNb0
```

<div class="youtube-container">
    <iframe
        width="560"
        height="315"
        src="https://www.youtube.com/embed/ZNehZ52kNb0"
        frameborder="0"
        allow="
            accelerometer;
            autoplay;
            clipboard-write;
            encrypted-media;
            gyroscope;
            picture-in-picture
        "
        allowfullscreen>
    </iframe>
</div>

```bash
seavision inference https://www.youtube.com/watch?v=agpaCq36_NY
```

<div class="youtube-container">
    <iframe
        width="560"
        height="315"
        src="https://www.youtube.com/embed/agpaCq36_NY"
        frameborder="0"
        allow="
            accelerometer;
            autoplay;
            clipboard-write;
            encrypted-media;
            gyroscope;
            picture-in-picture
        "
        allowfullscreen>
    </iframe>
</div>

### Custom Model Selection

Use a specific model for inference:

```bash
seavision inference --model experimental/ahoy-MIX-640-b2
```

### Save Results to Image/Video

```bash
seavision inference --save results.mp4
seavision inference --save results.jpg
```

### Disable Video Display

```bash
seavision inference --no-show --save results.jpg
```

### Only Draw Bounding Boxes

Info:
    Most of our models are trained to detect objects and the horizon line.
    If you only want to draw bounding boxes, use the `--only-bbox` flag.

```bash
seavision inference --only-bbox
```

### Show Detection Labels

Info:
    By default, the detection labels are not shown to avoid cluttering the image.

```bash
seavision inference --show-labels
```
"""

import sys
from pathlib import Path
from typing import Optional, Union

import click
import numpy as np
from tqdm import tqdm

import seavision as sv

from .utils import echo_resolved_command


def get_source(source: str, buffer: bool = False) -> Union[np.ndarray, sv.VideoReader]:
    """Check if the source is a valid image or video file."""
    if source.isdigit():
        return sv.VideoReader(f"webcam:{source}")
    if any(source.endswith(ext) for ext in sv.IMAGE_EXTENSIONS):
        return sv.imread(source)
    return sv.VideoReader(source, buffer=buffer)


@click.command()
@click.argument(
    "source",
    type=str,
    default="webcam",
    required=False,
)
@click.option(
    "--model",
    type=str,
    default="experimental/ahoy-MIX-640-b1",
    help=(
        "Path, HF model name (organization/model_name), or W&B ref "
        "(registry: collection:version or run: entity/project/artifact:version)"
    ),
)
@click.option(
    "--save",
    type=str,
    default=None,
    help="Save the results to file in the current directory.",
)
@click.option(
    "--no-show",
    is_flag=True,
    help="Don't display the video window (useful for headless environments)",
)
@click.option(
    "--buffer",
    is_flag=True,
    help="""Enable frame buffering for video sources.
    Useful if you want to preserve the source's FPS.""",
)
@click.option(
    "--only-bbox",
    is_flag=True,
    help="Only draw bounding boxes on the image/video",
)
@click.option(
    "--show-labels",
    is_flag=True,
    help="Show detection labels on the image/video",
)
@click.option(
    "--conf",
    type=float,
    default=None,
    help="Confidence threshold for detection",
)
@click.option(
    "--iou",
    type=float,
    default=None,
    help="IoU threshold for detection",
)
@click.option(
    "--hor-conf",
    type=float,
    default=None,
    help="Confidence threshold for horizon line detection",
)
@echo_resolved_command
def inference(
    source: str,
    model: str,
    save: Optional[str] = None,
    no_show: bool = False,
    buffer: bool = False,
    only_bbox: bool = False,
    show_labels: bool = False,
    conf: Optional[float] = None,
    iou: Optional[float] = None,
    hor_conf: Optional[float] = None,
) -> None:
    """Run inference on a video or image using SeaVision models.

    SOURCE can be a local file path, webcam index (e.g., 0, webcam:0),
    RTSP stream URL, or YouTube URL. By default, the webcam will be used.
    """
    if no_show and not save:
        print("--no-show must be used with --save.")
        sys.exit(1)

    # Load source and model
    _source = get_source(source, buffer)
    _model = sv.load_model(model)
    _model.det_conf_thresh = conf or _model.det_conf_thresh
    _model.det_iou_thresh = iou or _model.det_iou_thresh
    _model.hor_conf_thresh = hor_conf or _model.hor_conf_thresh

    # Handle image input
    if isinstance(_source, np.ndarray):
        process_image(_source, _model, save, no_show, only_bbox, show_labels)
        return

    # Handle video input
    if isinstance(_source, sv.VideoReader):
        process_video(_source, _model, save, no_show, only_bbox, show_labels)
        return

    if not no_show:
        sv.destroyallwindows()


def process_image(
    image: np.ndarray,
    model: sv.Model,
    save: Union[str, None] = None,
    no_show: bool = False,
    only_bbox: bool = False,
    show_labels: bool = False,
) -> None:
    """Process a single image."""
    results = model(image)
    results = results[0] if isinstance(results, list) else results
    draw = results.draw(
        image,
        show_horizon=not only_bbox,
        show_labels=show_labels,
    )
    draw = np.array(draw) if not isinstance(draw, np.ndarray) else draw

    if not no_show:
        sv.imshow("result", draw)
        sv.waitkey(0)

    if save:
        save_path = Path(save).with_suffix(".jpg")
        sv.imwrite(save_path.as_posix(), draw)
        print(f"💾 Saved results to {save_path}")


def process_video(
    video: sv.VideoReader,
    model: sv.Model,
    save: Union[str, None] = None,
    no_show: bool = False,
    only_bbox: bool = False,
    show_labels: bool = False,
) -> None:
    """Process a video stream."""
    writer = None
    if save:
        save_path = Path(save).with_suffix(".mp4")
        print(f"💾 Saving results to {save_path}")
        writer = sv.VideoWriter(
            save_path.as_posix(),
            fps=video.fps,
            frame_height=video.height,
            frame_width=video.width,
        )

    try:
        process_video_frames(video, model, writer, no_show, only_bbox, show_labels)
    except Exception as e:
        print(f"Error processing video frames: {e}")
    finally:
        video.close()
        if writer:
            writer.close()


def process_video_frames(
    video: sv.VideoReader,
    model: sv.Model,
    writer: Union[sv.VideoWriter, None],
    no_show: bool = False,
    only_bbox: bool = False,
    show_labels: bool = False,
) -> None:
    """Process video frames."""
    total = None if video.is_live() or video.buffering else len(video)
    with tqdm(total=total, unit=" frames") as pbar:
        for frame in video:
            results = model(frame)
            results = results[0] if isinstance(results, list) else results
            draw = results.draw(
                frame,
                show_horizon=not only_bbox,
                show_labels=show_labels,
            )
            draw = np.array(draw) if not isinstance(draw, np.ndarray) else draw

            if not no_show:
                sv.imshow(video.path, draw)
                if sv.waitkey(1) & 0xFF == ord("q"):
                    break
            if writer:
                writer.write(draw)
            pbar.update(1)
