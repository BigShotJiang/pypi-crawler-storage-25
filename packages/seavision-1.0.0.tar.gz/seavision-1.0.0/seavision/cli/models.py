"""Utility functions for managing SeaVision models.

## Quick Start

List all available models:
```bash
pip install seavision
seavision models list
```

## Examples

List all models including nested ones:
```bash
seavision models list --all
```

List models with a specific extension:
```bash
seavision models list --ext onnx
```
"""

from typing import Optional

import click

import seavision as sv

from .utils import echo_resolved_command


@click.group()
def models():
    """Manage SeaVision models."""


@models.command(name="list")
@click.option(
    "--all", "all_", is_flag=True, help="Display all models including nested ones"
)
@click.option("--ext", default=None, help="Filter models by extension")
@echo_resolved_command
def lst(all_: bool = False, ext: Optional[str] = None):
    """List all available SeaVision models.

    By default, only root-level models are displayed. Use the `--all` flag
    to display all models including nested ones or the `--ext` flag to filter
    models by extension.
    """
    available_models = sv.list_models(extension=ext)
    if not all_:
        available_models = [model for model in available_models if "/" not in model]

    if not available_models:
        click.echo("No models found.")
        return

    click.echo("Available SeaVision models:")
    for model in available_models:
        click.echo(f"  - {model}")


if __name__ == "__main__":
    models()
