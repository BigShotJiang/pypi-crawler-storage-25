"""SeaVision's Command Line Interface (CLI).

Run CV workflows directly from your terminal.

Whether you're testing a model, analyzing a stream, or undistorting imagery,
the CLI gives you quick access to core functionality **without needing to
write code or open a notebook**.

```bash
seavision --help
```

Each command is designed to solve a **practical, real-world vision task**
out of the box:

- 🤖 `seavision models list` - List available models
- 🎥 `seavision inference` - Run inference on video streams
  (webcam, IP camera, local file)
- 🧭 `seavision calibration` - Open the web UI to tune camera extrinsics
  (pitch/yaw/roll) against a Sentry recording

## 🚀 Why use the CLI?

- No need to write Python scripts
- Easy integration into shell workflows or automation
- Clear, consistent commands for common tasks

## 🧩 Adding a new CLI command

Yes, please! Just follow these steps:

1. Create a new Python module in this folder (e.g. `my_command.py`)
2. Add a **Markdown-friendly docstring** at the top with 1️⃣ a description,
    2️⃣ usage examples and 3️⃣ tips, options, or expected inputs.
3. Use [`click`](https://click.palletsprojects.com/) to define the command.

Tip:
   Look at existing commands for inspiration and structure.

Your docstring will automatically appear in the documentation using
[`mkdocs-gen-files`](https://oprypin.github.io/mkdocs-gen-files/),
so keep it helpful and concise!

## ⚡ Quick Start

```bash
# List available models
seavision models list

# Run inference on a video file
seavision inference path/to/video.mp4
```
"""

import click

from .calibration import calibration as calibration_command
from .compose_onnx import compose_onnx as compose_onnx_command
from .inference import inference as inference_command
from .models import models as models_command
from .utils import print_banner


@click.group()
def cli() -> None:
    """SeaVision - Re-usable computer vision tools for research and development."""
    print_banner()


# Add subcommands
cli.add_command(models_command, name="models")
cli.add_command(inference_command, name="inference")
cli.add_command(compose_onnx_command, name="compose-onnx")
cli.add_command(calibration_command, name="calibration")


if __name__ == "__main__":
    cli()
