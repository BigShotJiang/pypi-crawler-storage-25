"""Utility functions for displaying images and videos."""

import cv2
import numpy as np


def imshow(window_name: str, img: np.ndarray):
    """Wrapper around cv2.imshow that converts the image to BGR format."""
    cv2.imshow(window_name, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))


def waitkey(delay: int = 0) -> int:
    """Wrapper around cv2.waitKey. Delay is in milliseconds."""
    return cv2.waitKey(delay)


def destroyallwindows():
    """Wrapper around cv2.destroyAllWindows."""
    cv2.destroyAllWindows()


def destroywindow(window_name: str):
    """Wrapper around cv2.destroyWindow."""
    cv2.destroyWindow(window_name)
