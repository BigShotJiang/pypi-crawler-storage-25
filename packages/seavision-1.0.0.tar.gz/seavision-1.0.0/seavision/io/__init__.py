"""Input/Output utilities for handling images and videos."""

# import for convenience
from .image import IMAGE_EXTENSIONS, imread, imwrite, load_images_from_folder
from .utils import destroyallwindows, imshow, waitkey
from .video import VideoReader, VideoWriter

__all__ = [
    "VideoReader",
    "VideoWriter",
    "imread",
    "imwrite",
    "load_images_from_folder",
    "imshow",
    "waitkey",
    "destroyallwindows",
    "IMAGE_EXTENSIONS",
]
