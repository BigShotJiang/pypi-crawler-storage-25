"""Video readers for various formats."""

import re
import time
from abc import ABC, abstractmethod
from pathlib import Path
from queue import Empty, Full, Queue
from threading import Thread
from typing import TYPE_CHECKING, Any, Iterator, Literal, Optional, Tuple, Type, Union

import av
import cv2
import ffmpeg
import numpy as np

from seavision.utils.general import LOGGER

if TYPE_CHECKING:
    import subprocess


def get_pixel_format(path: str) -> Union[str, None]:
    """Get the pixel format of the video file."""
    try:
        probe = ffmpeg.probe(path)
        video_stream = next(
            (stream for stream in probe["streams"] if stream["codec_type"] == "video"),
            None,
        )
        if video_stream:
            return video_stream.get("pix_fmt", "Unknown")
        return None
    except ffmpeg.Error as e:
        LOGGER.warning(f"Error probing video file: {e}")
        return None


class VideoFormatRegistry:
    """Registry for video format handlers.

    This class manages the mapping between file formats and their corresponding
    reader/writer classes. It supports format matching by extension, protocol,
    and pixel format.
    """

    def __init__(self) -> None:
        """Initialize an empty registry."""
        self._handlers = {}  # extension/protocol -> handler
        self._format_handlers = {}  # (extension/protocol, format) -> handler

    def register(
        self,
        identifier: str,
        handler: Type[Any],
        pixel_format: Optional[str] = None,
    ) -> None:
        """Register a handler for a specific file format or protocol.

        Args:
            identifier: File extension (e.g., 'mp4', 'avi') or protocol/source
                identifier (e.g., 'rtsp', 'http', 'webcam')
            handler: The handler class to use for this format
            pixel_format: Optional pixel format (e.g., 'gray16be')
        """
        identifier = identifier.lower()

        if pixel_format:
            # Register for specific format
            self._format_handlers[(identifier, pixel_format)] = handler
        else:
            # Register as default handler for this extension/protocol
            self._handlers[identifier] = handler

    def get_handler(self, source: str, pixel_format: Optional[str] = None) -> Type[Any]:
        """Get the appropriate handler for a file or stream.

        Args:
            source: Path to the file or stream identifier
            pixel_format: Optional pixel format

        Returns:
            The handler class for the file/stream

        Raises:
            ValueError: If no suitable handler is found
        """
        # Check if the source is a file path or a direct protocol/source identifier
        if ":" in source and not Path(source).exists() or "webcam" in source:
            # Likely a protocol/source identifier (e.g., "rtsp://...", "webcam:0")
            protocol = source.split(":", maxsplit=1)[0].lower()

            # Try exact match (protocol + pixel format)
            if pixel_format and (protocol, pixel_format) in self._format_handlers:
                return self._format_handlers[(protocol, pixel_format)]

            # Fallback: Try matching only the protocol
            if protocol in self._handlers:
                return self._handlers[protocol]
        else:
            # File path - extract extension
            file_extension = Path(source).suffix.lstrip(".").lower()

            # Try exact match (extension + pixel format)
            if pixel_format and (file_extension, pixel_format) in self._format_handlers:
                return self._format_handlers[(file_extension, pixel_format)]

            # Fallback: Try matching only the extension
            if file_extension in self._handlers:
                return self._handlers[file_extension]

        # No match found
        raise ValueError(f"Unsupported combination {source}:{pixel_format}")


class VideoReaderBase(ABC):
    """Base class for video readers."""

    def __init__(self, path: str) -> None:
        """Initialize the video reader.

        Args:
            path: The path to the video file.
        """
        self.path = path

    @property
    @abstractmethod
    def num_frames(self) -> int:
        """Number of frames in the video."""

    @property
    @abstractmethod
    def fps(self) -> float:
        """Frames per second."""

    @property
    @abstractmethod
    def height(self) -> int:
        """Height of the video frames."""

    @property
    @abstractmethod
    def width(self) -> int:
        """Width of the video frames."""

    @abstractmethod
    def __next__(self) -> np.ndarray:
        """Return the next frame as a numpy array."""

    @abstractmethod
    def close(self) -> None:
        """Release internal buffers."""

    def __len__(self) -> int:
        return self.num_frames

    def __iter__(self) -> Iterator[np.ndarray]:
        return self

    def is_live(self) -> bool:
        """Whether the video is a live stream."""
        return self.num_frames < 0


class MP4Reader(VideoReaderBase):
    """Similar to AviReader, but for MP4 files. Uses OpenCV.

    Example:
        ```python
        video = MP4Reader(video_path)
        for frame in video:
            # frame is a numpy array in RGB format
            process_frame(frame)
        video.close()  # Release internal buffers
    ```
    """

    def __init__(self, path: str) -> None:
        """Initialize the MP4 reader.

        Args:
            path: Path to the video file.
        """
        super().__init__(path)
        self.cap = cv2.VideoCapture(path)

    @property
    def num_frames(self) -> int:
        """Number of frames in the video."""
        return int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))

    @property
    def fps(self) -> float:
        """Frames per second."""
        return self.cap.get(cv2.CAP_PROP_FPS)

    @property
    def height(self) -> int:
        """Height of the video frames."""
        return int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    @property
    def width(self) -> int:
        """Width of the video frames."""
        return int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))

    def __iter__(self) -> Iterator[np.ndarray]:
        return self

    def __next__(self) -> np.ndarray:
        ret, frame = self.cap.read()
        if not ret:
            raise StopIteration
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    def close(self) -> None:
        """Release internal buffers."""
        self.cap.release()


class RGBAVIReader(VideoReaderBase):
    """Simple AVI reader. Wraps AVIReader.

    Example:
        ```python
        video = SimpleAVIReader(video_path)
        for frame in video:
            # frame is a numpy array in RGB format
            process_frame(frame)
        video.close()  # Release internal buffers
    ```
    """

    def __init__(self, path: str) -> None:
        """Initialize the SimpleAVI reader.

        Args:
            path: Path to the video file.
        """
        super().__init__(path)
        self._container = av.open(str(self.path))
        self._stream = self._container.streams.video[0]
        self._frames = self._container.decode(video=0)

    def __next__(self) -> np.ndarray:
        frame = next(self._frames, None)
        if frame is None:
            raise StopIteration
        return frame.to_ndarray(format="rgb24")

    @property
    def num_frames(self) -> int:
        """Number of frames in the video."""
        return self._stream.frames

    @property
    def fps(self) -> float:
        """Frames per second."""
        return self._stream.average_rate

    @property
    def height(self) -> int:
        """Height of the video frames."""
        return int(self._stream.height)

    @property
    def width(self) -> int:
        """Width of the video frames."""
        return int(self._stream.width)

    def close(self) -> None:
        """Release internal buffers."""
        self._container.close()


class Gray16AVIReader(RGBAVIReader):
    """Use AVIReader + handling of 16-bit images from IR cameras.

    Example:
        ```python
        video = Gray16AVIReader(video_path)
        for frame in video:
            # frame is a numpy array in 16-bit grayscale
            process_frame(frame)
        video.close()  # Release internal buffers
    ```
    """

    def __init__(self, path: str) -> None:
        """Initialize the Gray16AVI reader.

        Args:
            path: Path to the video file.
        """
        super().__init__(path)
        # skipping first frame to match 8bit visualisazion of 16bit video
        # why? not sure to be honest
        next(self._frames, None)

    def __next__(self) -> np.ndarray:
        frame = next(self._frames, None)
        if frame is None:
            raise StopIteration
        return frame.to_ndarray(format="gray16be")

    def __len__(self) -> int:
        """Number of frames in the video."""
        return self._stream.frames - 1  # skip first frame


class StreamReader(VideoReaderBase):
    """Concrete streamer for RTSP/HTTP streams, webcam devices, and YouTube URLs.

    - rtsp://192.168.1.191:8555/rgbwfov
    - https://streams.videolan.org/samples/MPEG-4/video.mp4
    - webcam:0
    - webcam
    - https://www.youtube.com/watch?v=dQw4w9WgXcQ

    Example:
        ```python
        stream = StreamReader("rtsp://192.168.1.191:8555/rgbwfov")
        for frame in stream:
            # do something with the frame
        stream.close()
        ```
    """

    youtube_urls: Tuple[str, ...] = ("youtube.com", "youtu.be")
    supported_formats: Tuple[str, ...] = (
        "http",
        "https",
        "rtsp",
        "webcam",
        *youtube_urls,
    )

    def __init__(self, source: str) -> None:
        """Initialize the RTSP streamer.

        Args:
            source: RTSP/HTTP stream, webcam device path, or YouTube URL.

        Raises:
            ValueError: If the stream format is unsupported.
        """
        super().__init__(source)
        if not source.startswith(self.supported_formats) and not source.isdigit():
            raise ValueError(f"Unsupported stream format: {source}")

        if self.is_youtube_url(source):
            _source = self.get_best_youtube_url(source)
        elif source.isdigit():
            _source = int(source)
        elif source.startswith("webcam"):
            _source = int(m.group()) if (m := re.search(r"\d+", source)) else 0
        else:
            _source = source

        self.source = _source
        self.cap = cv2.VideoCapture(self.source)

        if not self.cap.isOpened():
            raise ValueError(f"Unable to open stream: {source}")

    def is_youtube_url(self, source: str) -> bool:
        """Check if the source is a YouTube URL."""
        return any(url in source for url in self.youtube_urls)

    @staticmethod
    def get_best_youtube_url(url: str) -> str:
        """Get youtube stream with highest resolution."""
        try:
            from pytubefix import YouTube

            streams = YouTube(url).streams.filter(file_extension="mp4", only_video=True)
            # sort streams by resolution, highest to lowest
            streams = sorted(
                streams,
                key=lambda s: int(s.resolution.replace("p", "")),
                reverse=True,
            )
            LOGGER.info(f"Best stream: {streams[0]}")
            return streams[0].url
        except Exception as e:
            LOGGER.error(f"Failed to initialize StreamReader: {e}")
            raise ValueError(f"Invalid YouTube stream: {url}") from e

    def __next__(self) -> np.ndarray:
        """Read a frame from the stream.

        Returns:
            np.ndarray: The next frame.

        Raises:
            StopIteration: If the stream is closed or no frame is available.
        """
        success, frame = self.cap.read()
        if not success or frame is None:
            raise StopIteration("Stream ended or failed to read.")
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    def __iter__(self) -> Iterator[np.ndarray]:
        return self

    def close(self) -> None:
        """Release OpenCV resources."""
        if self.cap.isOpened():
            self.cap.release()

    @property
    def height(self) -> int:
        """Height of the video stream."""
        return int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    @property
    def width(self) -> int:
        """Width of the video stream."""
        return int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))

    @property
    def fps(self) -> float:
        """Frame rate of the video stream."""
        return self.cap.get(cv2.CAP_PROP_FPS)

    @property
    def num_frames(self) -> int:
        """Number of frames in the video stream."""
        frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        return frame_count if frame_count > 0 else -1  # live source


class VideoReader(VideoReaderBase):
    """Interface for selecting the appropriate video reader dynamically.

    Supports multiple video formats including AVI (standard rgb24 and gray16be), MP4,
    as well as various streaming sources like RTSP streams, webcams, and YouTube URLs.
    The reader is automatically selected based on the file extension/protocol and
    pixel format.

    Background frame buffering is automatically enabled for live sources to ensure
    smooth playback. It can also be explicitly enabled for local files or non-live
    sources to maintain consistent frame rates during processing.

    Example:
        ```python
        # Basic usage
        video = VideoReader("video.avi")  # local file
        video = VideoReader("rtsp://...")  # RTSP stream (auto-buffering)
        video = VideoReader("webcam:0")  # webcam (auto-buffering)
        video = VideoReader(
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        )  # YouTube URL

        # Explicit buffering for local files
        video = VideoReader("video.mp4", buffer=True)

        for frame in video:
            # frame is a numpy array
            process_frame(frame)

        video.close()  # Release internal buffers
        ```
    """

    # Create a registry instance
    _registry = VideoFormatRegistry()

    # Register all supported formats
    _registry.register("avi", RGBAVIReader)  # Standard AVI
    _registry.register("avi", Gray16AVIReader, "gray16be")  # 16-bit infrared AVI
    _registry.register("mp4", MP4Reader)  # MP4 videos

    # Register protocols and sources
    _registry.register("rtsp", StreamReader)  # RTSP streams
    _registry.register("https", StreamReader)  # HTTP streams
    _registry.register("http", StreamReader)  # HTTP streams
    _registry.register("webcam", StreamReader)  # Webcam devices
    _registry.register("youtube", StreamReader)  # YouTube URLs
    _registry.register("youtu.be", StreamReader)  # YouTube URLs (short)

    def __init__(
        self,
        path: str,
        buffer: bool = False,
        buffer_size: int = 1,
    ) -> None:
        """Initialize the VideoReader.

        Args:
            path: Path to a video file or stream source.
            buffer: Enable background buffering (recommended for live streams).
            buffer_size: Number of frames to buffer.
        """
        path = f"webcam:{path}" if path.isdigit() else path
        if (
            not any(fmt in path for fmt in StreamReader.supported_formats)  # stream
            and not Path(path).exists()  # local file
        ):
            raise FileNotFoundError(path)

        super().__init__(path)
        pixel_format = get_pixel_format(path) if ":" not in path else None
        reader_cls: Type[VideoReaderBase] = self._registry.get_handler(
            path, pixel_format
        )
        self.reader = reader_cls(path)

        self.buffering = self.reader.is_live() or buffer
        self.buffer_size = buffer_size
        self.prefix = "[📺]" if self.reader.is_live() else "[🎥]"

        # Internal buffering state
        self._buffer: Optional[Queue[np.ndarray]] = None
        self._thread: Optional[Thread] = None
        self._running = False

        if self.buffering:
            LOGGER.info(f"{self.prefix} Buffering enabled for {path}")

    def _start_buffering(self) -> None:
        self._buffer = Queue(maxsize=self.buffer_size)
        self._running = True
        self._thread = Thread(target=self._buffer_loop, daemon=True)
        self._thread.start()

    def _buffer_loop(self) -> None:
        next_frame_time = time.perf_counter()

        for frame in self.reader:
            if not self._running:
                break
            try:
                self._buffer.put_nowait(frame)
            except Full:
                try:
                    self._buffer.get_nowait()
                    self._buffer.put_nowait(frame)
                except Empty:
                    pass

            if not self.is_live():
                # Sleep to maintain the frame rate
                sleep_duration = next_frame_time - time.perf_counter()
                time.sleep(max(0, sleep_duration))
                next_frame_time += 1.0 / self.fps

    def _get_frame(self) -> np.ndarray:
        success, frame = True, None
        try:
            frame = next(self.reader)
        except StopIteration:
            raise
        except Exception as e:
            LOGGER.warning(f"{self.prefix} Frame read error: {e}")
            success = False

        if not success or frame is None:
            raise StopIteration("Stream ended or failed.")
        return frame

    def __iter__(self) -> Iterator[np.ndarray]:
        if self.buffering:
            self._start_buffering()
        return self

    def __next__(self) -> np.ndarray:
        if self.buffering:
            try:
                frame = self._buffer.get(timeout=1.0)
            except Empty as e:
                raise StopIteration("No buffered frame available.") from e
        else:
            frame = self._get_frame()
        return frame

    def close(self) -> None:
        """Release resources."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=1)
        self.reader.close()

    @property
    def num_frames(self) -> int:
        """Number of frames in the video."""
        return self.reader.num_frames

    @property
    def fps(self) -> float:
        """Frames per second."""
        return self.reader.fps

    @property
    def height(self) -> int:
        """Height of the video frames."""
        return self.reader.height

    @property
    def width(self) -> int:
        """Width of the video frames."""
        return self.reader.width


class VideoWriterBase(ABC):
    """Base class for video writers."""

    def __init__(
        self, output_path: str, fps: float, frame_width: int, frame_height: int
    ) -> None:
        """Initialize the video writer.

        Args:
            output_path: The path to the output video file.
            fps: The frame rate of the video.
            frame_width: The width of the video frames.
            frame_height: The height of the video frames.
        """
        self.output_path = Path(output_path)
        self.fps = fps
        self.frame_width = frame_width
        self.frame_height = frame_height

    @abstractmethod
    def write(self, frame: np.ndarray) -> None:
        """Write a frame to the video."""

    @abstractmethod
    def close(self) -> None:
        """Release the video writer."""


class Gray16VideoWriter(VideoWriterBase):
    """Writes gray16le images into a gray16be video using ffmpeg."""

    def __init__(
        self, output_path: str, fps: float, frame_width: int, frame_height: int
    ) -> None:
        """Initialize the VideoWriterGray16.

        Args:
            output_path: Path to the output video file.
            fps: Frame rate of the video.
            frame_width: Width of the video frames.
            frame_height: Height of the video frames.
        """
        super().__init__(output_path, fps, frame_width, frame_height)
        self.process = self.get_ffmpeg_process()

    def get_ffmpeg_process(self) -> "subprocess.Popen":
        """Set up the ffmpeg process."""
        return (
            ffmpeg.input(
                "pipe:",
                format="rawvideo",
                pix_fmt="gray16le",
                s=f"{self.frame_width}x{self.frame_height}",
                framerate=self.fps,
            )
            .filter("scale", "trunc(iw/2)*2", "trunc(ih/2)*2")
            .output(self.output_path.as_posix(), pix_fmt="gray16be", vcodec="png")
            .overwrite_output()
            .global_args("-hide_banner", "-loglevel", "error")
            .run_async(pipe_stdin=True)
        )

    def write(self, frame: np.ndarray) -> None:
        """Write a frame to the video."""
        self.process.stdin.write(frame.tobytes())

    def close(self) -> None:
        """Close the video writer."""
        self.process.stdin.close()
        self.process.wait()


class MP4VideoWriter(VideoWriterBase):
    """MP4 video writer using FFmpeg with H.264 encoding."""

    def __init__(
        self,
        output_path: str,
        fps: float,
        frame_width: int,
        frame_height: int,
        crf: int = 23,
        preset: Literal[
            "ultrafast",
            "superfast",
            "veryfast",
            "faster",
            "fast",
            "medium",
            "slow",
            "slower",
            "veryslow",
        ] = "medium",
    ) -> None:
        """Initialize the VideoWriterMP4.

        Args:
            output_path: Path to the output video file.
            fps: Frame rate of the video.
            frame_width: Width of the video frames.
            frame_height: Height of the video frames.
            crf: Constant Rate Factor for H.264 encoding. 0 is lossless, 51 is worst.
            preset: Compression preset for H.264 encoding.
        """
        super().__init__(output_path, fps, frame_width, frame_height)
        self.process = self.get_ffmpeg_process(crf, preset)

    def get_ffmpeg_process(self, crf: int, preset: str) -> "subprocess.Popen":
        """Set up the ffmpeg process with H.264 encoding."""
        return (
            ffmpeg.input(
                "pipe:",
                format="rawvideo",
                pix_fmt="rgb24",
                s=f"{self.frame_width}x{self.frame_height}",
                framerate=self.fps,
            )
            .filter("scale", "trunc(iw/2)*2", "trunc(ih/2)*2")
            .output(
                self.output_path.as_posix(),
                vcodec="libx264",
                preset=preset,
                crf=crf,
                pix_fmt="yuv420p",
            )
            .overwrite_output()
            .global_args("-hide_banner", "-loglevel", "error")
            .run_async(pipe_stdin=True)
        )

    def write(self, frame: np.ndarray) -> None:
        """Write a frame to the MP4 video."""
        self.process.stdin.write(frame.tobytes())

    def close(self) -> None:
        """Close the video writer."""
        self.process.stdin.close()
        self.process.wait()


class VideoWriter(VideoWriterBase):
    """Dynamically selects a video writer based on file format.

    Example:
        ```python
        writer = VideoWriter("output.mp4", 30, 1920, 1080)  # MP4 writer
        writer = VideoWriter(
            "output.avi", 30, 1920, 1080, "gray16be"
        )  # 16-bit grayscale AVI writer

        for frame in frames:
            writer.write(frame)
        writer.close()
        ```
    """

    GRAYSCALE_DIMS = 2

    # Create a registry instance
    _registry = VideoFormatRegistry()

    # Register all supported formats
    _registry.register("avi", MP4VideoWriter)  # Default AVI writer
    _registry.register("avi", Gray16VideoWriter, "gray16be")  # 16-bit grayscale AVI
    _registry.register("mp4", MP4VideoWriter)  # MP4 videos

    def __init__(
        self,
        output_path: str,
        fps: float,
        frame_width: int,
        frame_height: int,
        pix_fmt: Optional[Literal["gray16be"]] = None,
        crf: int = 23,
        preset: Literal[
            "ultrafast",
            "superfast",
            "veryfast",
            "faster",
            "fast",
            "medium",
            "slow",
            "slower",
            "veryslow",
        ] = "medium",
    ) -> None:
        """Initialize the VideoWriter.

        Args:
            output_path: Path to the output video file.
            fps: Frame rate of the video.
            frame_width: Width of the video frames.
            frame_height: Height of the video frames.
            pix_fmt: Pixel format. Defaults to None.
            crf: Constant Rate Factor for H.264 encoding. 0 is lossless, 51 is worst.
            preset: Compression preset for H.264 encoding.
        """
        super().__init__(output_path, fps, frame_width, frame_height)
        writer_cls: Type[VideoWriterBase] = self._registry.get_handler(
            output_path, pix_fmt
        )
        codec_args = {"crf": crf, "preset": preset} if pix_fmt != "gray16be" else {}
        self.writer = writer_cls(
            output_path, fps, frame_width, frame_height, **codec_args
        )

    def write(self, frame: np.ndarray, ensure_3ch: bool = True) -> None:
        """Write a frame to the video."""
        h, w = frame.shape[:2]
        if h != self.frame_height or w != self.frame_width:
            raise ValueError(
                "Frame is not the correct size: "
                f"{h}x{w} != {self.frame_height}x{self.frame_width}"
            )
        if (
            ensure_3ch
            and frame.ndim == self.GRAYSCALE_DIMS
            and not isinstance(self.writer, Gray16VideoWriter)
        ):
            frame = np.stack((frame,) * 3, axis=-1)
        self.writer.write(frame)

    def close(self) -> None:
        """Close the video writer."""
        self.writer.close()
