"""Image readers for various formats."""

from pathlib import Path
from typing import Any, Dict, Literal, Union
from urllib.parse import urlparse
from urllib.request import urlopen

import cv2
import numpy as np
from PIL import Image

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tiff"}


def imread(filepath: Union[str, Path]) -> np.ndarray:
    """Read an image from a file or URL.

    Args:
        filepath: Path to the image file. Can be a local file or a URL.

    Returns:
        The image as a numpy array.
    """
    if is_image_url(filepath):
        with urlopen(filepath) as response:
            image = Image.open(response)
    else:
        image = Image.open(filepath)
    if image.mode == "P":  # palette image
        image = image.convert("RGB")
    return np.array(image)


def load_images_from_folder(
    folder: str,
    include: set = IMAGE_EXTENSIONS,
) -> Dict[str, np.ndarray]:
    """Load all images from a folder.

    Args:
        folder: Path to the folder containing images.
        include: Set of image extensions to include.

    Returns:
        Dictionary where keys are filenames and values are the corresponding loaded images.
    """
    images = {
        file.name: imread(str(file))
        for file in Path(folder).iterdir()
        if file.suffix.lower() in include
    }

    return images


def is_image_url(s: str) -> bool:
    """Check if a string is a valid image URL."""
    image_exts = (".jpg", ".jpeg", ".png", ".tiff")
    try:
        parsed = urlparse(s)
        return (
            parsed.scheme in ("http", "https")
            and bool(parsed.netloc)
            and parsed.path.lower().endswith(image_exts)
        )
    except Exception:
        return False


def imwrite(
    filepath: str,
    image: np.ndarray,
    backend: Literal["cv2", "pil"] = "pil",
    *args: Any,
    **kwargs: Dict[str, Any],
) -> None:
    """Write an image to a file using one of the supported backends.

    Supported backends:
    - cv2: OpenCV
    - pil: PIL

    Args:
        filepath: Path to the file to write the image to.
        image: Image to write.
        backend: Backend to use for image writing. Defaults to "pil".
        *args: Additional arguments to pass to the backend.
        **kwargs: Additional keyword arguments to pass to the backend.
    """
    if backend == "pil":
        return Image.fromarray(image).save(filepath, *args, **kwargs)
    if backend == "cv2":
        return cv2.imwrite(filepath, image, *args, **kwargs)
    raise ValueError(f"Unsupported backend: {backend}")
