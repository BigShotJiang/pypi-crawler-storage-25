r"""Generate a new slice containing a composite video from a dataset of videos.

## Features

- 🎥 **Multi-Camera Fusion**: Combine synchronized camera views into a single video
- 🎯 **Flexible Master View**: Choose any camera as the reference perspective

Note:
    - `fx`, `fy`, `cx`, `cy` should be available under `sample.intrinsics`
    - `roll`, `pitch`, `yaw` should be available under `sample.pose`

    You can upload them manually with:
    ```python
    dataset = fo.load_dataset("my_grouped_dataset")
    for _slice, params in zip(dataset.group_slices, [rgb1_params, t1_params]):
        print(f"Processing slice: {_slice}")
        dataset.group_slice = _slice
        for sample in dataset.iter_samples(progress=True, autosave=True):
            sample["intrinsics"] = fo.DynamicEmbeddedDocument()
            sample.intrinsics["fx"] = params["fx"]
            sample.intrinsics["fy"] = params["fy"]
            sample.intrinsics["cx"] = params["cx"]
            sample.intrinsics["cy"] = params["cy"]

            sample["pose"] = fo.DynamicEmbeddedDocument()
            sample.pose["roll"] = params["roll"]
            sample.pose["pitch"] = params["pitch"]
            sample.pose["yaw"] = params["yaw"]
    ```

## Quick Start 🚀

Create a composite video from a dataset:

```bash
python -m seavision.fiveone.composite \
    --dataset-name my_dataset \
    --master-slice cam1 \
    --slice-name composite \
    --alpha-blend 0.5
```

### Overwrite existing slice

```bash
python -m seavision.fiveone.composite \
    --dataset-name my_dataset \
    --master-slice cam1 \
    --slice-name composite \
    --overwrite
```

### Skip saving to FiftyOne (only generate videos)

```bash
python -m seavision.fiveone.composite \
    --dataset-name my_dataset \
    --master-slice cam1 \
    --slice-name composite \
    --skip-fiftyone
```
"""

import argparse
from pathlib import Path

import fiftyone as fo

import seavision as sv


def replace_camera_id(fname: str, new_id: str = "composite") -> str:
    """Replace the camera ID in a filename.

    Filename format: <SENSOR_NAME>_<CAMERA_ID>_record_<TIMESTAMP>.ext

    Args:
        fname: The filename to replace the camera ID in.
        new_id: The new camera ID to replace the old one with.

    Returns:
        The filename with the new camera ID.
    """
    path = Path(fname)
    parts = path.stem.split("_")

    # Expect: [<SENSOR_NAME>, <CAMERA_ID>, "record", <timestamp_parts>...]
    if parts[2] != "record":
        raise ValueError("Unexpected filename format")

    parts[1] = new_id
    new_stem = "_".join(parts)
    return str(path.with_stem(new_stem))


def main(
    dataset_name: str,
    master_slice: str,
    slice_name: str = "composite",
    alpha_blend: float = 0.5,
    skip_fiftyone: bool = False,
    overwrite: bool = False,
) -> None:
    """Generate a composite video from a dataset of videos.

    Args:
        dataset_name: Name of the FiftyOne dataset
        master_slice: Slice to use as master
        slice_name: Name of the slice to save the composite video to
        alpha_blend: Alpha value for blending in overlapping regions
        skip_fiftyone: Only generate video, do not save to FiftyOne
        overwrite: Overwrite existing slice
    """
    # Load dataset and process each group
    dataset = fo.load_dataset(dataset_name)

    if overwrite and slice_name in dataset.group_slices:
        dataset.delete_group_slice(slice_name)

    if slice_name in dataset.group_slices:
        msg = (
            f"Slice {slice_name} already exists\n"
            + "Use --skip-fiftyone if you just want to (re)generate the video\n"
            + "Use --overwrite if you want to overwrite the existing slice"
        )
        raise ValueError(msg)

    samples = []
    for group in dataset.iter_groups(progress=True, autosave=True):
        video_fpaths = [sample.filepath for sample in group.values()]
        cameras = [
            sv.Camera.from_dict(sample.intrinsics, sample.pose)
            for sample in group.values()
        ]
        try:
            master_idx = list(group.keys()).index(master_slice)
            master_sample: fo.Sample = group[master_slice]
        except ValueError as e:
            raise ValueError(f"Slice {master_slice} not found in dataset") from e

        # Generate output path
        output_fpath = replace_camera_id(video_fpaths[master_idx], slice_name)

        # Create masked overlay with all cameras
        sv.composite_videos(
            video_fpaths=video_fpaths,
            cameras=cameras,
            master_idx=master_idx,
            output_fpath=output_fpath,
            alpha_blend=alpha_blend,
        )

        if not skip_fiftyone:
            frame_fields_to_omit = [
                f"frames.{k}"
                for k in dataset.get_frame_field_schema(
                    embedded_doc_type=[fo.Detections, fo.Polylines]
                )  # keep per-frame metadata like boatbus, imu, etc.
            ]
            sample: fo.Sample = master_sample.copy(
                omit_fields=["group", "tags", *frame_fields_to_omit]
            )
            sample["filepath"] = output_fpath
            sample["group"] = master_sample.group.element(slice_name)
            samples.append(sample)

    if not skip_fiftyone:
        dataset.add_samples(samples)
        dataset.compute_metadata(overwrite=True)
        dataset.ensure_frames()


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Create video overlay from multiple camera views",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--dataset-name", type=str, required=True, help="Name of the FiftyOne dataset"
    )
    parser.add_argument(
        "--master-slice", type=str, required=True, help="Slice to use as master"
    )
    parser.add_argument(
        "--slice-name",
        type=str,
        default="composite",
        help="Name of the slice to save the composite video to",
    )
    parser.add_argument(
        "--alpha-blend",
        type=float,
        default=0.5,
        help="Alpha value for blending in overlapping regions",
    )
    parser.add_argument(
        "--skip-fiftyone",
        action="store_true",
        help="Only generate video, do not save to FiftyOne",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing slice",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    main(**vars(args))
