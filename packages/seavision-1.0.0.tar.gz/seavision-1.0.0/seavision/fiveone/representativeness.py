"""Wrapper around FiftyOne's `compute_representativeness` function.

Particularly useful for video :video_camera: datasets where FiftyOne's built-in
representativeness computation is not supported.

Example usage with Python:
    ```python
    import fiftyone as fo
    from seavision.brain import compute_representativeness

    # Load your dataset
    dataset = fo.load_dataset("my-dataset")

    # Compute representativeness using pre-computed embeddings
    compute_representativeness(
        dataset,
        embeddings_field="embeddings",
        representativeness_field="representativeness",
        method="cluster-center",
    )
    ```
"""

from typing import Literal

import numpy as np
from fiftyone.core.view import DatasetView

try:
    from seavision.utils.general import LOGGER as logger
except ImportError:
    import logging

    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.INFO)


def compute_representativeness(
    dataset_or_view: DatasetView,
    embeddings_field: str,
    representativeness_field: str = "representativeness",
    method: Literal["cluster-center", "cluster-center-downweight"] = "cluster-center",
) -> None:
    """Compute the representativeness of each sample in the dataset.

    This function is adapted from `fiftyone.brain.internal.core.representativeness`
    and is specifically designed for video datasets since FiftyOne's built-in
    `compute_representativeness` function only supports image datasets.

    Args:
        dataset_or_view: The dataset or view to compute representativeness for.
        embeddings_field: The field containing the pre-computed embeddings.
        representativeness_field: The field to store the representativeness values.
        method: The method to use for computing representativeness.
            Supported values are:
            - `"cluster-center"`: Makes a sample's representativeness proportional
              to its proximity to cluster centers
            - `"cluster-center-downweight"`: Ensures more diversity in
              representative samples

    Note:
        Video embeddings must be computed and stored in the dataset before
        calling this function.
    """
    import fiftyone.brain.internal.core.representativeness as fbr
    import fiftyone.core.fields as fof

    logger.info("Computing representativeness...")

    embeddings = np.array(dataset_or_view.values(embeddings_field))
    representativeness = fbr._compute_representativeness(
        embeddings=embeddings,
        method=method,
    )

    # Ensure field exists, even if `representativeness` is empty
    dataset_or_view._dataset.add_sample_field(representativeness_field, fof.FloatField)

    sample_ids = dataset_or_view.values("id")
    representativeness = dict(zip(sample_ids, representativeness))
    if representativeness:
        dataset_or_view.set_values(
            representativeness_field, representativeness, key_field="id"
        )

    logger.info("Representativeness computation complete")
