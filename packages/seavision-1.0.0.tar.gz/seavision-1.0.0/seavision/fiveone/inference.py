r"""Run inference on a given FiftyOne dataset or view using multiple models.

Supports both image and video datasets.

Example usage:
    ```bash
    python -m seavision.brain.inference --config config.yaml
    ```

Example with extra arguments:
    ```bash
    python -m seavision.brain.inference \
        --dataset_name my-dataset \
        --slices my-slice \
        --models "model1,prefix1,np.uint8,variant,key:value"
    ```

Example with multiple models:
    ```bash
    python -m seavision.brain.inference \
        --dataset_name my-dataset \
        --slices my-slice \
        --models "model1,prefix1,np.uint8" "model2,prefix2,np.uint16"
    ```

Example if you want to use raw data (if available) instead of fiftyone's H264 videos:
    ```bash
    python -m seavision.brain.inference \
        --dataset_name my-dataset \
        --slices my-slice \
        --models "model1,prefix1,np.uint8" \
        --use_raw
    ```

Example using Python:
    ```python
    import fiftyone as fo
    from seavision.fiveone import inference

    dataset = fo.load_dataset("my-dataset")
    dataset_view = dataset.select_group_slices(["my-slice"])
    model_configs = [
        inference.ModelConfig("model1", "prefix1", "np.uint8"),
        inference.ModelConfig("model2", "prefix2", "np.uint16"),
        inference.ModelConfig("model3", "prefix3", "np.uint8", ModelVariant.VARIANT),
    ]
    inference.run_inference(dataset_view, model_configs)
    ```
"""

import argparse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

import fiftyone as fo
import numpy as np
import yaml
from tqdm.auto import tqdm

import seavision as sv
from seavision import T
from seavision.sensorfusion import SensorFusionMethod


@dataclass
class ModelConfig:
    """Configuration for a model used in the inference process."""

    model_name: str
    field_prefix: str = field(
        metadata={"description": "Prefix for the field names in the dataset."}
    )
    str_dtype: Literal["np.uint16", "np.uint8"]
    model_variant: Union[str, sv.ModelVariant] = field(
        default_factory=lambda: sv.ModelVariant.NONE
    )
    input_dtype: np.dtype = field(init=False)
    upload_detections: bool = field(default=True)
    upload_polylines: bool = field(default=True)
    conf_threshold: Optional[float] = field(default=None)
    model_kwargs: Dict[str, Any] = field(init=False)

    def __post_init__(self) -> None:
        if self.conf_threshold is not None and not (0.0 <= self.conf_threshold <= 1.0):
            raise ValueError(
                f"Invalid conf_threshold '{self.conf_threshold}'. "
                "Must be between 0.0 and 1.0."
            )
        valid_dtypes = {"np.uint8": np.uint8, "np.uint16": np.uint16}
        if self.str_dtype not in valid_dtypes:
            raise ValueError(
                f"Invalid dtype string '{self.str_dtype}'. "
                f"Must be one of: {list(valid_dtypes.keys())}"
            )
        self.input_dtype = valid_dtypes[self.str_dtype]
        self.model_kwargs = {}

        # Convert model_variant to enum if it exists
        if self.model_variant and isinstance(self.model_variant, str):
            self.model_variant = sv.ModelVariant(self.model_variant)

        # Convert sf_method to enum if it exists in model_kwargs
        if "sf_method" in self.model_kwargs and isinstance(
            self.model_kwargs["sf_method"], str
        ):
            self.model_kwargs["sf_method"] = SensorFusionMethod[
                self.model_kwargs["sf_method"]
            ]


@dataclass
class DatasetConfig:
    """Dataset configuration."""

    name: str
    slices: List[str]


@dataclass
class Config:
    """Inference configuration."""

    dataset: DatasetConfig
    models: List[ModelConfig]

    @classmethod
    def from_yaml(cls, config_path: str) -> "Config":
        """Load configuration from a YAML file.

        Args:
            config_path: Path to the YAML configuration file.

        Returns:
            Config: The loaded configuration object.
        """
        with Path(config_path).open("r", encoding="utf-8") as file:
            data = yaml.safe_load(file)

        dataset = DatasetConfig(**data["dataset"])
        models = [ModelConfig(**model) for model in data["models"]]

        return cls(dataset=dataset, models=models)

    @classmethod
    def from_cli_args(cls, args: argparse.Namespace) -> "Config":
        """Load configuration from command line arguments.

        Args:
            args: Command line arguments namespace.

        Returns:
            Config: The loaded configuration object.
        """
        dataset_config = DatasetConfig(name=args.dataset_name, slices=args.slices)
        models = []
        for model_str in args.models:
            # Split by commas first
            parts = model_str.split(",")

            # Extract name, prefix, dtype
            name, prefix, dtype = parts[:3]
            try:
                variant = parts[3]
            except IndexError:
                variant = None

            # Parse kwargs (e.g., sf_method:NMS)
            kwargs = dict(kv.split(":") for kv in parts[4:] if ":" in kv)
            # decode strings to ints/floats/bools
            for key, value in kwargs.items():
                kwargs[key] = smart_cast(value)

            # Add the model with parsed kwargs
            models.append(ModelConfig(name, prefix, dtype, variant, **kwargs))

        print(models)
        return cls(dataset=dataset_config, models=models)


def smart_cast(val: str) -> Union[bool, int, float, str]:
    """Cast a string to the appropriate type."""
    if val.lower() == "true":
        return True
    elif val.lower() == "false":
        return False
    elif val.isdigit():
        return int(val)
    try:
        return float(val)
    except ValueError:
        return val


def run_inference(
    dataset_or_view: Union[fo.Dataset, fo.DatasetView],
    model_configs: List[ModelConfig],
    use_raw: bool = True,
) -> None:
    """Perform inference on a FiftyOne dataset or view using specified models.

    This function iterates over the samples and frames in the provided
    FiftyOne dataset or view, performing inference using a list of models.
    The results of the inference (detections and/or polylines) are saved back
    into the dataset based on the model configurations.

    Args:
        dataset_or_view: The FiftyOne dataset or view to perform inference on.
        model_configs: List of model configurations.
        use_raw: Whether to use raw data.

    Raises:
        AssertionError: If the media type is not 'video' or 'image'.
    """
    media_type = dataset_or_view.media_type
    assert media_type in {"video", "image"}, (
        f"Only video and image datasets are supported, got '{media_type}'"
    )

    models = []
    for model_config in model_configs:
        model = sv.load_model(
            model_config.model_name,
            model_config.model_variant,
            **model_config.model_kwargs,
        )
        if model_config.conf_threshold is not None:
            if not hasattr(model, "det_conf_thresh"):
                raise AttributeError(
                    f"Model '{model_config.model_name}' does not support "
                    "'det_conf_thresh'; cannot apply conf_threshold."
                )
            model.det_conf_thresh = model_config.conf_threshold
        models.append(model)
    if media_type == "video":
        for sample in tqdm(
            dataset_or_view.iter_samples(autosave=True),
            desc="Inferring videos",
            total=len(dataset_or_view),
        ):
            process_video_sample(sample, models, model_configs, use_raw)

    elif media_type == "image":
        for sample in tqdm(
            dataset_or_view.iter_samples(autosave=True, batch_size=100),
            desc="Inferring images",
            total=len(dataset_or_view),
        ):
            process_image_sample(sample, models, model_configs, use_raw)

    dataset_or_view.save()


def process_video_sample(
    sample: fo.Sample,
    models: List[sv.Model],
    model_configs: List[ModelConfig],
    use_raw: bool = True,
) -> None:
    """Process a single video sample with all models.

    Args:
        sample: The FiftyOne sample to process.
        models: List of models to use for inference.
        model_configs: List of model configurations.
        use_raw: Whether to use raw data.
    """
    filepath = (
        sample.filepath.replace("8Bit", "16Bit").replace("mp4", "avi")
        if use_raw
        else sample.filepath
    )

    video = sv.VideoReader(filepath)
    transform = T.ThermalTransform4Video(fps=video.fps)

    for frame, (_, fo_frame) in zip(
        video, tqdm(sample.frames.items(), leave=False, total=len(sample.frames))
    ):
        run_models_on_image(frame, fo_frame, models, model_configs, transform)


def process_image_sample(
    sample: fo.Sample,
    models: List[sv.Model],
    model_configs: List[ModelConfig],
    use_raw: bool = True,
) -> None:
    """Process a single image sample with all models."""
    filepath = (
        sample.filepath.replace("8Bit", "16Bit").replace("jpg", "png")
        if use_raw
        else sample.filepath
    )

    image = sv.imread(filepath)
    transform = T.ThermalTransform()
    run_models_on_image(image, sample, models, model_configs, transform)


def run_models_on_image(
    image: np.ndarray,
    fo_frame_or_sample: Union[fo.Frame, fo.Sample],
    models: List[sv.Model],
    model_configs: List[ModelConfig],
    transform: Optional[T.Compose] = None,
) -> None:
    """Process a single frame or image with all models.

    Args:
        image: The image to process.
        fo_frame_or_sample: The FiftyOne frame or sample to store results in.
        models: List of models to use for inference.
        model_configs: List of model configurations.
        transform: Optional transform to apply to the frame or image.
    """
    for model, model_config in zip(models, model_configs):
        results = model(
            transform(image) if model_config.input_dtype != image.dtype else image
        )
        upload_results(fo_frame_or_sample, results, model_config)


def upload_results(
    frame_or_sample: Union[fo.Frame, fo.Sample],
    results: sv.Results,
    model_config: ModelConfig,
) -> None:
    """Upload inference results to the dataset.

    Args:
        frame_or_sample: The FiftyOne frame or sample to upload results to.
        results: The inference results to upload.
        model_config: The model configuration.
    """
    if model_config.upload_detections:
        frame_or_sample[f"{model_config.field_prefix}_det"] = results.to_fo_detections()
    if model_config.upload_polylines:
        frame_or_sample[f"{model_config.field_prefix}_pl"] = results.to_fo_polylines()


def parse_args() -> argparse.Namespace:
    """Parse command line arguments.

    Returns:
        argparse.Namespace: The parsed command line arguments.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, help="Path to the configuration file.")
    parser.add_argument(
        "--dataset_name", type=str, help="Name of the FiftyOne dataset."
    )
    parser.add_argument("--slices", nargs="*", help="Group slices to select.")
    parser.add_argument(
        "--models",
        nargs="*",
        help=(
            "List of model configurations in format: "
            "name,prefix,dtype[,variant][,key1:value1,key2:value2,...] "
        ),
    )
    parser.add_argument(
        "--use_raw",
        action="store_true",
        help="Use AVI files instead of MP4 files for video inference.",
    )
    return parser.parse_args()


def main() -> None:
    """Main entry point for the inference script."""
    args = parse_args()

    if args.config:
        config = Config.from_yaml(args.config)
    else:
        if not args.dataset_name or not args.slices or not args.models:
            raise ValueError(
                (
                    "If config is not provided, ",
                    "--dataset_name, --slices, and --models must be specified.",
                )
            )
        config = Config.from_cli_args(args)

    # Load dataset and run inference
    dataset = fo.load_dataset(config.dataset.name)
    dataset_view = dataset.select_group_slices(config.dataset.slices)
    run_inference(dataset_view, config.models, use_raw=args.use_raw)


if __name__ == "__main__":
    main()
