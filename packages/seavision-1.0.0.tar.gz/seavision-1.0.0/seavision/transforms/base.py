"""Base classes for image transformations."""

import inspect
from abc import ABC, abstractmethod
from typing import Any

import numpy as np


class BaseTransform(ABC):
    """Abstract base class for image transformations."""

    def __call__(self, img: np.ndarray) -> np.ndarray:
        """Apply validation and transformation to the image.

        Args:
            img: The image to transform.

        Returns:
            The transformed image.
        """
        self.validate(img)
        return self.apply(img)

    @abstractmethod
    def apply(self, img: np.ndarray) -> np.ndarray:
        """Transform the image.

        Subclasses must implement this method.

        Args:
            img: The image to transform.

        Returns:
            The transformed image.
        """

    def validate(self, img: np.ndarray):
        """Validate the image or raise a ValueError if it is invalid.

        By default, this method does nothing. Subclasses may override it.

        Args:
            img: The image to validate.

        Raises:
            ValueError: If the image is not valid.
        """
        pass

    def get_params(self) -> dict[str, Any]:
        """Retrieve transform parameters as a dictionary."""
        cls = type(self)
        params = inspect.signature(cls.__init__).parameters

        return {
            name: getattr(self, name)
            for name, param in params.items()
            if name != "self" and hasattr(self, name)
        }

    def __str__(self) -> str:
        """Return a detailed string representation of the transformation."""
        params = self.get_params()
        args_str = ", ".join(f"{k}={v!r}" for k, v in params.items())
        return f"{type(self).__name__}({args_str})"

    def __repr__(self) -> str:  # for jupyter notebooks
        """Return a detailed string representation of the transformation."""
        return self.__str__()
