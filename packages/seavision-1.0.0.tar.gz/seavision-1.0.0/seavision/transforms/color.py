"""Color transformations for images."""

import cv2
import numpy as np

from .base import BaseTransform


class GreyToRGB(BaseTransform):
    """Convert the image to uint8."""

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Convert the image to uint8."""
        img = img / np.iinfo(img.dtype).max
        img = (img * 255).astype(np.uint8)
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        return img
