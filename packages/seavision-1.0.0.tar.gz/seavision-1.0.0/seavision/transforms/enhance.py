"""Enhancement transformations for images."""

from typing import Tuple

import cv2
import numpy as np

from .base import BaseTransform

GREYSCALE_DIMS = 2
RGB_DIMS = 3


class UnsharpMask(BaseTransform):
    """Sharpen the image using an unsharp mask."""

    def __init__(
        self,
        kernel_size: int = 5,
        sigma: float = 0.0,
        amount: float = 1.5,
        threshold: float = 0,
    ) -> None:
        """Initialize the UnsharpMask transform.

        Args:
            kernel_size: The size of the kernel to use for the Gaussian blur.
            sigma: The standard deviation of the Gaussian blur.
            amount: The amount of sharpening to apply.
            threshold: The threshold for the unsharp mask.
        """
        self.kernel_size = kernel_size
        self.sigma = sigma
        self.amount = amount
        self.threshold = threshold

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Apply unsharp mask to the image."""
        blurred = cv2.GaussianBlur(
            img, (self.kernel_size, self.kernel_size), self.sigma
        )
        sharpened = cv2.addWeighted(img, 1 + self.amount, blurred, -self.amount, 0)
        mask = np.abs(img - blurred) > self.threshold
        return np.where(mask, sharpened, img)


class GreyCLAHE(BaseTransform):
    """Contrast Limited Adaptive Histogram Equalization for grayscale images.

    It supports both 8-bit and 16-bit images.
    """

    def __init__(
        self, clip_limit: float = 4.0, tile_grid_size: Tuple[int, int] = (0, 0)
    ) -> None:
        """Initialize the GreyCLAHE transform.

        Args:
            clip_limit: The clip limit for the CLAHE.
            tile_grid_size: The size of the tile grid to use for the CLAHE.
        """
        self.clip_limit = clip_limit
        self.tile_grid_size = tile_grid_size

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Apply CLAHE to the image."""
        if self.tile_grid_size == (0, 0):
            # compute tile_grid_size based on image size
            tile_grid_size = np.round(np.array(img.shape) / 160).astype(int)
            tile_grid_size = (tile_grid_size[0], tile_grid_size[1])
        else:
            tile_grid_size = self.tile_grid_size
        clahe = cv2.createCLAHE(clipLimit=self.clip_limit, tileGridSize=tile_grid_size)
        return clahe.apply(img)

    def validate(self, img: np.ndarray) -> None:
        """Check that image is grayscale."""
        if img.ndim == GREYSCALE_DIMS:
            return
        if img.ndim == RGB_DIMS and img.shape[2] == 1:
            return
        raise ValueError(
            f"{self.__class__.__name__} expects a grayscale image, but got {img.shape}."
        )
