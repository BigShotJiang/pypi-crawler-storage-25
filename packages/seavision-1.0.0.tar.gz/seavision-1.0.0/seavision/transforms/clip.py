"""Clip transformations for images."""

import numpy as np

from .base import BaseTransform

MIN_BOUND = 0
MAX_BOUND = 1
MIN_PERCENTILE = 0
MAX_PERCENTILE = 100


class ClipByBounds(BaseTransform):
    """Clip the image by lower and upper bounds."""

    def __init__(self, lower_bound: float = 0.25, upper_bound: float = 0.75) -> None:
        """Initialize the ClipByBounds transform.

        Args:
            lower_bound: The lower bound to clip by. Must be between 0 and 1.
            upper_bound: The upper bound to clip by. Must be between 0 and 1.
        """
        if lower_bound < MIN_BOUND or lower_bound > MAX_BOUND:
            raise ValueError("lower_bound must be between 0 and 1")
        if upper_bound < MIN_BOUND or upper_bound > MAX_BOUND:
            raise ValueError("upper_bound must be between 0 and 1")
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Clip the image by the specified bounds."""
        lower_bound = int(np.iinfo(img.dtype).max * self.lower_bound)
        upper_bound = int(np.iinfo(img.dtype).max * self.upper_bound)
        return np.clip(img, lower_bound, upper_bound)


class ClipByPercentiles(BaseTransform):
    """Clip the image by lower and upper percentiles."""

    def __init__(
        self, lower_percentile: float = 1, upper_percentile: float = 99
    ) -> None:
        """Initialize the ClipByPercentiles transform.

        Args:
            lower_percentile: Must be between 0 and 100.
            upper_percentile: Must be between 0 and 100.
        """
        if not MIN_PERCENTILE <= lower_percentile <= MAX_PERCENTILE:
            raise ValueError("lower_percentile must be between 0 and 100")
        if not MIN_PERCENTILE <= upper_percentile <= MAX_PERCENTILE:
            raise ValueError("upper_percentile must be between 0 and 100")
        self.lower_percentile = lower_percentile
        self.upper_percentile = upper_percentile

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Clip the image by the specified percentiles."""
        lower_bound, upper_bound = np.percentile(
            img, [self.lower_percentile, self.upper_percentile]
        )
        return np.clip(img, lower_bound, upper_bound).astype(img.dtype)
