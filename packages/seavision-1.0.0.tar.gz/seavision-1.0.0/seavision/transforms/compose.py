"""Compose multiple image processing transformations."""

from typing import Callable, List, Optional

import numpy as np

from .base import BaseTransform
from .clip import ClipByBounds
from .color import GreyToRGB
from .enhance import GreyCLAHE, UnsharpMask
from .normalize import EMANormalize, NormalizeMinMax


class Compose(BaseTransform):
    """Compose multiple image processing transformations."""

    def __init__(
        self, transforms: Optional[List[Callable[[np.ndarray], np.ndarray]]] = None
    ):
        """Initialize the Compose transform.

        Args:
            transforms: A list of transformations to be applied sequentially.
        """
        self.transforms = transforms or []

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Apply each transformation in sequence to the input image.

        Args:
            img: The input image.

        Returns:
            The transformed image.
        """
        for t in self.transforms:
            img = t(img)
        return img

    def __str__(self) -> str:
        """Return a readable string representation of the transformation pipeline."""
        transform_strs = [str(transform) for transform in self.transforms]
        join_str = ",\n  ".join(transform_strs)
        return f"{self.__class__.__name__}([\n  {join_str}\n])"


class ThermalTransform(Compose):
    """Default image processing transformations for thermal images.

    Equivalent to:
    ```
    Compose(
        [
            ClipByBounds(lower_bound=15000 / 65535, upper_bound=28000 / 65535),
            GreyCLAHE(clip_limit=4, tile_grid_size=(0, 0)),
            NormalizeMinMax(),
            UnsharpMask(kernel_size=5),
            GreyToRGB(),
        ]
    )(img)
    ```
    """

    def __init__(self):
        """Initialize the ThermalTransform for 16-bit thermal images."""
        super().__init__(
            [
                ClipByBounds(lower_bound=15000 / 65535, upper_bound=28000 / 65535),
                GreyCLAHE(clip_limit=4, tile_grid_size=(0, 0)),
                NormalizeMinMax(),
                UnsharpMask(kernel_size=5),
                GreyToRGB(),
            ]
        )


class ThermalTransform4Video(Compose):
    """Default image processing transformations for thermal videos.

    Equivalent to:
    ```
    Compose(
        [
            ClipByBounds(lower_bound=15000 / 65535, upper_bound=28000 / 65535),
            GreyCLAHE(clip_limit=4, tile_grid_size=(0, 0)),
            EMANormalize(fps=fps, cutoff_frequency=cutoff_frequency),
            UnsharpMask(kernel_size=5),
            GreyToRGB(),
        ]
    )(img)
    ```
    """

    def __init__(self, fps: float, cutoff_frequency: float = 0.5):
        """Initialize the ThermalTransform for 16-bit thermal images."""
        super().__init__(
            [
                ClipByBounds(lower_bound=15000 / 65535, upper_bound=28000 / 65535),
                GreyCLAHE(clip_limit=4, tile_grid_size=(0, 0)),
                EMANormalize(fps=fps, cutoff_frequency=cutoff_frequency),
                UnsharpMask(kernel_size=5),
                GreyToRGB(),
            ]
        )
