"""Normalization transformations for images."""

import cv2
import numpy as np

from .base import BaseTransform


class NormalizeMinMax(BaseTransform):
    """Normalize image to the range [dtype.min, dtype.max]."""

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Normalize the image to the specified range."""
        min_val, max_val = np.iinfo(img.dtype).min, np.iinfo(img.dtype).max
        return cv2.normalize(img, None, min_val, max_val, cv2.NORM_MINMAX).astype(
            img.dtype
        )


class EMANormalize(BaseTransform):
    """Normalize using exponential moving average for smooth transitions between frames.

    Warning:
        This transform stores the min and max values of the image internally.
        If you apply this transform to multiple images, the min and max values
        will be accumulated across all images. It is also not thread-safe.
    """

    def __init__(self, fps: float, cutoff_frequency: float = 0.5):
        """Initialize EMANormalize.

        Args:
            fps: Frame rate of the video.
            cutoff_frequency: Cutoff frequency for temporal smoothing.
        """
        super().__init__()
        self.fps = fps
        self.cutoff_frequency = cutoff_frequency
        self.alpha = self.compute_alpha()
        self.min_val = None
        self.max_val = None

    def compute_alpha(self):
        """Compute smoothing factor for temporal smoothing."""
        dt = 1 / self.fps
        time_constant = 1 / (2 * np.pi * self.cutoff_frequency)
        alpha = dt / (time_constant + dt)
        return alpha

    def apply(self, img: np.ndarray) -> np.ndarray:
        """Apply EMA normalization to frame.

        Args:
            img: Input frame to normalize

        Returns:
            Normalized frame as uint8
        """
        if self.min_val is None or self.max_val is None:
            self.min_val, self.max_val = img.min(), img.max()
        self.min_val = (1 - self.alpha) * self.min_val + self.alpha * img.min()
        self.max_val = (1 - self.alpha) * self.max_val + self.alpha * img.max()

        img = (img - self.min_val) / (self.max_val - self.min_val)
        img = np.clip(img * 255, 0, 255).astype(np.uint8)
        return img
