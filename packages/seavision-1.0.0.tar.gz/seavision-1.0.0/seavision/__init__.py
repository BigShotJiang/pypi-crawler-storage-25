"""SeaVision.

Computer vision tools for R&D at SEA.AI.
"""

from . import calibration, geometry, inference, io
from . import sensorfusion as sf
from . import transforms as T
from .calibration import *  # noqa: F403
from .geometry import *  # noqa: F403
from .inference import *  # noqa: F403
from .io import *  # noqa: F403
from .utils.general import pil_side_by_side, pil_up_down

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:
    from importlib_metadata import PackageNotFoundError, version  # python 3.6 and 3.7

try:
    __version__ = version("seavision")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "geometry",
    "inference",
    "io",
    "calibration",
    "sf",
    "T",
    "pil_side_by_side",
    "pil_up_down",
]
__all__.extend(inference.__all__)
__all__.extend(io.__all__)
__all__.extend(geometry.__all__)
__all__.extend(calibration.__all__)
