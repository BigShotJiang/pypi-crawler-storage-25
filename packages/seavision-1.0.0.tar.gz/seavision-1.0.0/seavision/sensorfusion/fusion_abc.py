"""Abstract base class for sensor fusion strategies."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

from pydantic import BaseModel

from seavision.inference.results import (
    BBox,
    CoordinateConversion,
    Horizon,
    Object,
    Results,
)

from .utils import get_longest_horizon


class FusionParams(BaseModel, ABC):
    """Abstract base class for fusion parameters."""

    class Config:
        """Enable validation on attribute assignment."""

        validate_assignment = True


@dataclass
class ClassMap:
    """Dataclass to map class indices to class names."""

    mapping: Dict[int, str]

    def __getitem__(self, class_id: int) -> str:
        """Return the class name for a given class ID or default to OBJECT."""
        return self.mapping.get(class_id, "OBJECT")

    @classmethod
    def from_results(cls, results_list: Sequence[Results]) -> "ClassMap":
        """Get the class map from a list of results."""
        class_mapping: Dict[int, str] = {
            obj.class_id: obj.class_name
            for result in results_list or []
            for obj in result.objects
        }

        return cls(class_mapping)


# Common type for internal representation
BoxesType = Tuple[List[List[float]], List[List[float]], List[List[int]]]


class SensorFusion(ABC):
    """Base class for sensor fusion strategies."""

    def __init__(self, params: FusionParams):
        """Initialize the sensor fusion object.

        Args:
            params: Fusion parameters
        """
        self.params = params
        self.class_map: Optional[ClassMap] = None
        self.horizon: Optional[Horizon] = None
        self.width, self.height = 0, 0

    def from_results(self, results_list: Sequence[Results]) -> BoxesType:
        """Convert Results objects to internal representation."""
        boxes_list = [
            [obj.bbox.xyxy_n for obj in results.objects] for results in results_list
        ]
        scores_list = [
            [obj.score for obj in results.objects] for results in results_list
        ]
        labels_list = [
            [
                0 if self.params.class_agnostic else obj.class_id
                for obj in results.objects
            ]
            for results in results_list
        ]

        return boxes_list, scores_list, labels_list

    def to_results(self, fused_data: BoxesType) -> Results:
        """Convert internal box representation to Results."""
        boxes, scores, labels = fused_data
        width, height = self.width, self.height
        converter = CoordinateConversion(width, height)

        objects = []
        for box, score, label in zip(boxes, scores, labels):
            bbox = BBox(xyxy_n=box)
            bbox.update_formats(converter)

            class_name = (
                "OBJECT"
                if self.params.class_agnostic or not self.class_map
                else self.class_map[label]
            )

            objects.append(
                Object(
                    bbox=bbox,
                    score=score,
                    class_name=class_name,
                    class_id=label,
                )
            )

        return Results(
            objects=objects,
            horizon=self.horizon,
            image_width=width,
            image_height=height,
        )

    @abstractmethod
    def fuse_internal(self, internal_data: BoxesType) -> BoxesType:
        """Perform fusion on internal representation."""
        pass

    def fuse(self, results_list: Sequence[Results]) -> Results:
        """Run the main fusion pipeline."""
        self._setup_fusion(results_list)
        self._validate_inputs(results_list)
        internal_data = self.from_results(results_list)
        fused_data = self.fuse_internal(internal_data)
        return self.to_results(fused_data)

    def _validate_inputs(self, results_list: Sequence[Results]) -> None:
        if not results_list:
            raise ValueError("Results list cannot be empty")

        expected = (self.width, self.height)
        for results in results_list:
            if (results.image_width, results.image_height) != expected:
                raise ValueError(f"All results must have width and height {expected}")

    def _setup_fusion(self, results_list: Sequence[Results]):
        """Extract image dimensions and determine the best horizon."""
        self.width, self.height = (
            results_list[0].image_width,
            results_list[0].image_height,
        )
        self.horizon = get_longest_horizon(results_list)
        self.class_map = ClassMap.from_results(results_list)


class SensorFusionMethod(Enum):
    """Enum for sensor fusion methods."""

    WBF = "wbf"
    NMS = "nms"

    def __call__(
        self, weights: Sequence[float], **kwargs: Dict[str, Any]
    ) -> SensorFusion:
        """Create a sensor fusion object based on the method.

        Args:
            weights: Sequence of weights for each model's predictions
            **kwargs: Optional parameters to override defaults

        Returns:
            A configured sensor fusion object
        """
        from .nms import NMS, NMSParams
        from .wbf import WBF, WBFParams

        params = {"weights": weights, **kwargs}

        if self == SensorFusionMethod.WBF:
            return WBF(WBFParams(**params))
        elif self == SensorFusionMethod.NMS:
            return NMS(NMSParams(**params))
