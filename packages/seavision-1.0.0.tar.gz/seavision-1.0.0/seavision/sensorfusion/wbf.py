"""Weighted Box Fusion (WBF) implementation."""

from pydantic import Field

from .common import EnsembleBoxesMixin
from .fusion_abc import BoxesType, FusionParams, SensorFusion


class WBFParams(FusionParams, EnsembleBoxesMixin):
    """Parameters for Weighted Box Fusion (WBF) algorithm.

    Extends common box ensemble parameters with WBF-specific threshold.
    """

    skip_box_thr: float = Field(
        default=0.001,
        ge=0,
        le=1,
        description="Threshold for skipping low-confidence boxes",
    )


class WBF(SensorFusion):
    """Weighted Box Fusion implementation."""

    def __init__(self, params: WBFParams):
        """Initialize the WBF fusion algorithm.

        Args:
            params: Parameters for the WBF fusion algorithm.
        """
        super().__init__(params)
        self.params: WBFParams = params  # Type hint for better IDE support

    def fuse_internal(self, internal_data: BoxesType) -> BoxesType:
        """Fuse the detection results using Weighted Box Fusion (WBF)."""
        from ensemble_boxes import weighted_boxes_fusion

        boxes_list, scores_list, labels_list = internal_data

        boxes, scores, labels = weighted_boxes_fusion(
            boxes_list=boxes_list,
            scores_list=scores_list,
            labels_list=labels_list,
            weights=self.params.weights,
            iou_thr=self.params.iou_threshold,
            skip_box_thr=self.params.skip_box_thr,
        )

        return boxes, scores, labels
