"""Package for sensor fusion algorithms.

Heavily inspired by this [Weighted-Boxes-Fusion implementation](https://github.com/ZFTurbo/Weighted-Boxes-Fusion).
"""

from .fusion_abc import SensorFusion, SensorFusionMethod
from .nms import NMS, NMSParams
from .wbf import WBF, WBFParams

__all__ = [
    "NMS",
    "NMSParams",
    "SensorFusion",
    "SensorFusionMethod",
    "WBF",
    "WBFParams",
]
