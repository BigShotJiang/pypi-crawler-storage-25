"""Common classes and functions for sensor fusion algorithms."""

from typing import Sequence

from pydantic import BaseModel, Field, field_validator


class EnsembleBoxesMixin(BaseModel):
    """Mixin for ensemble box detection algorithms.

    Provides common parameters and validation for ensemble methods like NMS and WBF.
    """

    weights: Sequence[float] = Field(
        ..., description="Weights for each model's predictions"
    )
    iou_threshold: float = Field(
        default=0.001, ge=0, le=1, description="IOU threshold for box overlap"
    )

    class_agnostic: bool = Field(
        default=True, description="Whether to apply fusion across all classes"
    )

    @field_validator("weights")
    @classmethod
    def validate_weights(cls, v: Sequence[float]) -> Sequence[float]:
        """Validate that weights are non-negative and non-empty."""
        if not v or any(w < 0 for w in v):
            raise ValueError("Weights must be non-negative and non-empty")
        return v
