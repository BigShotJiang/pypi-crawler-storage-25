"""Non-Maximum Suppression (NMS) fusion implementation."""

from .common import EnsembleBoxesMixin
from .fusion_abc import BoxesType, FusionParams, SensorFusion


class NMSParams(FusionParams, EnsembleBoxesMixin):
    """Parameters for Non-Maximum Suppression (NMS) fusion algorithm.

    Inherits all common box ensemble parameters from EnsembleBoxesMixin.
    """


class NMS(SensorFusion):
    """Non-Maximum Suppression implementation."""

    def __init__(self, params: NMSParams):
        """Initialize the NMS fusion algorithm.

        Args:
            params: Parameters for the NMS fusion algorithm.
        """
        super().__init__(params)
        self.params: NMSParams = params  # Type hint for better IDE support

    def fuse_internal(self, internal_data: BoxesType) -> BoxesType:
        """Fuse the detection results using Non-Maximum Suppression (NMS)."""
        from ensemble_boxes import nms

        boxes, scores, labels = internal_data

        # Do the checks and skip empty predictions
        # https://github.com/ZFTurbo/Weighted-Boxes-Fusion/commit/8ab50856cf1c8be9feb9f472bdf184ad6627398f
        filtered_boxes = []
        filtered_scores = []
        filtered_labels = []
        filtered_weights = []
        for i in range(len(boxes)):  # pylint: disable=consider-using-enumerate
            if len(boxes[i]) != len(scores[i]) or len(boxes[i]) != len(labels[i]):
                print(
                    "Check length of boxes and scores and labels:",
                    f"{len(boxes[i])} {len(scores[i])} {len(labels[i])} at position: {i}.",
                    "Boxes are skipped!",
                )
                continue
            if len(boxes[i]) == 0:
                # print('Empty boxes!')
                continue
            filtered_boxes.append(boxes[i])
            filtered_scores.append(scores[i])
            filtered_labels.append(labels[i])
            filtered_weights.append(self.params.weights[i])

        boxes, scores, labels = nms(
            boxes=filtered_boxes,
            scores=filtered_scores,
            labels=filtered_labels,
            weights=filtered_weights,
            iou_thr=self.params.iou_threshold,
        )

        return boxes, scores, labels
