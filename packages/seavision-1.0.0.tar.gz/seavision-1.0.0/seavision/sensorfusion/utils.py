"""Utility functions for sensor fusion."""

from typing import Optional, Sequence

from seavision.inference.results import Horizon, Results


def get_longest_horizon(results_list: Optional[Sequence[Results]]) -> Optional[Horizon]:
    """Get the longest horizon from a list of results."""
    if not results_list:
        return None

    horizons = [result.horizon for result in results_list if result.horizon]
    if not horizons:
        return None

    return max(horizons, key=lambda h: h.line.length or 0)
