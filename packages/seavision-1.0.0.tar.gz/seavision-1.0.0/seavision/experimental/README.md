# Experimental Area 🧪

## Video Embeddings

The `video_embedding.py` script computes mean embeddings for videos in a FiftyOne dataset using a DINOv2 model. It processes video frames, generates embeddings, and averages them to produce a single vector representing the video.

### Approach

1. **🖼 Frame Embeddings:** Uses a pre-trained DINOv2 model to extract visual features from video frames.
2. **⏩ Subsampling:** Allows you to skip frames (e.g., every 30th frame) to speed up processing.
3. **📊 Mean Embedding:** Averages the frame embeddings to create a single vector that represents the entire video.

### Why Experimental? 🤔

- **Simplification:** Averaging frames' embeddings may miss temporal details.
- **Trade-offs:** Subsampling might overlook important content at the expense of faster processing.
- **Model Fit:** DINOv2 excels with images but isn’t specifically tuned for videos.
