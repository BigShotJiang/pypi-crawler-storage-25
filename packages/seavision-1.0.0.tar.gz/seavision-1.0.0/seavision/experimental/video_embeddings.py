r"""Compute mean video embeddings for a FiftyOne dataset using DINOv2.

Example usage:
    ```bash
    python3 video_embedding.py \
        --dataset_name FLIR-M364C \
        --dinov2_model dinov2_vitb14 \
        --skip_frames 30
    ```

Example with FiftyOne config:
    ```bash
    FIFTYONE_CONFIG_PATH=/etc/fiftyone/config.json python3 video_embedding.py \
        --dataset_name FLIR-M364C \
        --dinov2_model dinov2_vitb14
    ```
"""

import argparse
from typing import Any, Dict, Iterator, Optional

import fiftyone as fo
import torch
import torchvision.transforms as T
from torchvision.io import VideoReader
from tqdm import tqdm


class MeanVideoEmbedder(torch.nn.Module):
    """Compute the mean embedding of video frames."""

    def __init__(
        self,
        embedder: torch.nn.Module,
        transform: Optional[T.Compose] = None,
    ) -> None:
        """Initialize the MeanVideoEmbedder.

        Args:
            embedder: The pre-trained DINOv2 model.
            transform: The transform to apply to the video frames.
        """
        super().__init__()
        self.embedder = embedder
        self.embed_dim = embedder(
            torch.randn(1, 3, 224, 224).to(next(embedder.parameters()).device)
        ).shape[1]
        self.transform = transform if transform else T.Compose([T.Lambda(lambda x: x)])

    @property
    def device(self) -> torch.device:
        """Return the device of the embedder."""
        return next(self.parameters()).device

    @staticmethod
    def _subsampled_frames(
        video: VideoReader, skip_frames: int = 1
    ) -> Iterator[Dict[str, Any]]:
        """Yield every `skip_frames`-th frame of the video.

        Args:
            video: The video to subsample.
            skip_frames: The number of frames to skip between processed frames.

        Yields:
            frame: The subsampled frames of the video.
        """
        for i, frame in enumerate(video):
            if i % max(1, skip_frames) == 0:
                yield frame

    def forward(self, video: VideoReader, skip_frames: int = 1) -> torch.Tensor:
        """Compute the mean embedding of the video with optional subsampling.

        Args:
            video: The video to compute the embedding of.
            skip_frames: The number of frames to skip between processed frames.

        Returns:
            The mean embedding of the video.
        """
        mean_embedding = torch.zeros(self.embed_dim, device=self.device)
        for i, frame in enumerate(self._subsampled_frames(video, skip_frames)):
            x = self.transform(frame["data"].to(self.device))
            embedding = self.embedder(x.unsqueeze(0)).squeeze(0)
            # update running mean
            mean_embedding = (i * mean_embedding + embedding) / (i + 1)
        return mean_embedding


def process_dataset(dataset_name: str, dinov2_model: str, skip_frames: int = 1) -> None:
    """Process a FiftyOne dataset and compute video embeddings.

    Args:
        dataset_name: The name of the FiftyOne dataset.
        dinov2_model: The name of the DINOv2 model to use.
        skip_frames: The number of frames to skip between processed frames.
    """
    # Load the pre-trained DINOv2 model
    dinov2_model = torch.hub.load("facebookresearch/dinov2", dinov2_model)

    # Define the transform
    transform = T.Compose(
        [
            T.Lambda(lambda x: x / 255.0),
            T.Resize(244),
            T.CenterCrop(224),
            T.Normalize([0.5], [0.5]),
        ]
    )

    # Initialize the MeanVideoEmbedder
    embedder = MeanVideoEmbedder(dinov2_model, transform=transform)
    embedder.to("cuda" if torch.cuda.is_available() else "cpu")
    embedder.eval()

    # Load the FiftyOne dataset
    dataset = fo.load_dataset(dataset_name)

    # Process each sample in the dataset
    with torch.inference_mode():
        for sample in tqdm(dataset):
            video_reader = VideoReader(sample.filepath)
            mean_embedding = embedder(video_reader, skip_frames=skip_frames)
            sample["mean_embeddings"] = mean_embedding.cpu().numpy()
            sample.save()


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Compute mean video embeddings for a FiftyOne dataset.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--dataset_name", type=str, required=True, help="Name of the FiftyOne dataset."
    )
    parser.add_argument(
        "--dinov2_model",
        type=str,
        default="dinov2_vitb14",
        help="dinov2_vits14, dinov2_vitb14, dinov2_vitl14 or dinov2_vitg14",
    )
    parser.add_argument(
        "--skip_frames",
        type=int,
        default=1,
        help="Number of frames to skip between processed frames.",
    )

    _args = parser.parse_args()
    if _args.skip_frames < 1:
        parser.error("--skip_frames must be >= 1")
    return _args


if __name__ == "__main__":
    args = parse_args()
    process_dataset(args.dataset_name, args.dinov2_model, skip_frames=args.skip_frames)
