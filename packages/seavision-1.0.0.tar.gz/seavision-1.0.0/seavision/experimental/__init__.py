"""Experimental models and utilities.

If suitable for inclusion in the main library, it will be moved to an
appropriate place within the `seavision` package.
"""
