r"""False zoom inference module for 4K object detection.

False Zoom refers to the case where two images are created out of a single
4K image. The first image is a wide-angle view, and the second image is a
narrow-angle view. The two images are then processed independently and the
results are fused together.
"""

from typing import List, Optional, Tuple

import numpy as np

from seavision.geometry.utils import create_affine_matrix
from seavision.inference.models import AHOY
from seavision.inference.preprocessing import (
    center_crop,
    resize_image_keeping_aspect_ratio,
)
from seavision.inference.results import Results
from seavision.inference.slicing import ModelValidationMixin
from seavision.sensorfusion import SensorFusionMethod


class FalseZoom(AHOY, ModelValidationMixin):
    """Baseline model for 4k object detection."""

    def __init__(
        self,
        model: str,
        device: Optional[str] = None,
        crop_shape: Tuple[int, int] = (1080, 1920),
        sf_method: SensorFusionMethod = SensorFusionMethod.WBF,
    ) -> None:
        """Initialize the FalseZoom model.

        Args:
            model: Path to model file.
            device: Device to run inference on.
            crop_shape: Shape to crop image to (height, width).
            sf_method: Sensor fusion method to use.
        """
        super().__init__(model, device)

        self.validate_model(model, supported_batch_sizes=[2])

        self.crop_shape = crop_shape
        self.sf_method = sf_method
        self.H = None

    def __call__(self, ims: np.ndarray, verbose: bool = False) -> Results:
        """Run the model pipeline on the given input image(s)."""
        rgb_wide = resize_image_keeping_aspect_ratio(ims, self.crop_shape)
        rgb_narrow = center_crop(ims, self.crop_shape)

        self.H = self._compute_homography(ims.shape, rgb_narrow.shape)
        ims = [rgb_wide, rgb_narrow]

        results = super().__call__(ims, verbose=verbose)
        return results

    def to_results_hook(self, output: List[Results]) -> Results:
        """Convert the model output to a tuple of Results objects."""
        im_height, im_width = self.orig_hw[0]

        # Transform narrow results to wide perspective
        transformed = output[1].apply_homography(
            self.H, new_width=im_width, new_height=im_height
        )

        # Fuse results
        method = self.sf_method(weights=[1, 1])
        fused_results = method.fuse([output[0], transformed])

        return fused_results

    @staticmethod
    def _compute_homography(
        original_shape: Tuple[int, int], crop_shape: Tuple[int, int]
    ) -> np.ndarray:
        """Compute the homography matrix (cropped to resized 4K image)."""
        H, W = original_shape[:2]
        crop_h, crop_w = crop_shape[:2]

        sx = crop_w / W
        sy = crop_h / H
        dx = (W - crop_w) / 2 * sx
        dy = (H - crop_h) / 2 * sy

        return create_affine_matrix(dx, dy, sx, sy)
