r"""Combine two ONNX models into one.

Example usage:
    ```bash
    python compose_onnx.py model_1.onnx model_2.onnx output.onnx
    ```

Example with custom prefixes for both models:
    ```bash
    python compose_onnx.py \
        ahoy-IR-b2.onnx \
        ahoy-RGB-b2.onnx \
        models/dan-b2.onnx \
        --prefix1 "ir_" \
        --prefix2 "rgb_"
    ```

Example with custom prefix for the second model:
    ```bash
    python compose_onnx.py \
        cerulean-level-b2-landscape.onnx \
        ahoy-RGB-b2.onnx \
        models/dan-b2.onnx \
        --prefix2 "rgb_"
    ```
"""

import argparse
from typing import Any

import onnx

from seavision.utils.general import LOGGER, colorstr
from seavision.utils.onnx_utils import convert_fp16_model_to_fp32

PREFIX = colorstr("ONNX:")


def merge_common_metadata(model_1: onnx.ModelProto, model_2: onnx.ModelProto) -> None:
    """Merge common metadata properties from two ONNX models.

    If the same key exists in both models, make a list of the values.

    Args:
        model_1: First ONNX model.
        model_2: Second ONNX model.
    """

    def safe_eval(value: Any) -> Any:  # noqa: ANN401
        try:
            return eval(value)  # pylint: disable=eval-used
        except Exception:
            return value

    metadata_1 = {prop.key: safe_eval(prop.value) for prop in model_1.metadata_props}  # pylint: disable=eval-used
    metadata_2 = {prop.key: safe_eval(prop.value) for prop in model_2.metadata_props}  # pylint: disable=eval-used

    common_keys = set(metadata_1.keys()) & set(metadata_2.keys())
    for key in common_keys:
        metadata_1[key] = [metadata_1[key], metadata_2[key]]
        metadata_2[key] = metadata_1[key]

    # overwrite metadata properties
    for model in [model_1, model_2]:
        for prop in model.metadata_props:
            for common_key in common_keys:
                if prop.key == common_key:
                    prop.value = str(metadata_1[common_key])


def merge_onnx_models(
    model_path_1: str,
    model_path_2: str,
    output_path: str,
    prefix1: str = "",
    prefix2: str = "",
    force_fp32: bool = False,
) -> None:
    """Combine two ONNX models into one.

    Args:
        model_path_1: Path to the first ONNX model.
        model_path_2: Path to the second ONNX model.
        output_path: Path to save the merged ONNX model.
        prefix1: Prefix for the first model's inputs and outputs.
        prefix2: Prefix for the second model's inputs and outputs.
        force_fp32: Whether to convert models to FP32 before merging.
    """
    try:
        from seavision.utils.downloads import attempt_download_from_hf

        # Download both models and update paths in one go
        model_path_1 = (
            attempt_download_from_hf("SEA-AI/seavision", model_path_1) or model_path_1
        )
        model_path_2 = (
            attempt_download_from_hf("SEA-AI/seavision", model_path_2) or model_path_2
        )

    except Exception as e:
        LOGGER.warning(f"Could not download models from Hugging Face Hub: {str(e)}")

    model_1 = onnx.load(model_path_1)
    model_2 = onnx.load(model_path_2)
    LOGGER.info(f"{PREFIX} loaded models {model_path_1} and {model_path_2}.")

    if force_fp32:
        model_1 = convert_fp16_model_to_fp32(model_1)
        model_2 = convert_fp16_model_to_fp32(model_2)
        LOGGER.info(f"{PREFIX} converted models to FP32.")

    merge_common_metadata(model_1, model_2)

    ir_version = min(model_1.ir_version, model_2.ir_version)
    opset_version = max(
        model_1.opset_import[0].version, model_2.opset_import[0].version
    )

    model_1.ir_version = ir_version
    model_1 = onnx.version_converter.convert_version(model_1, opset_version)
    model_2.ir_version = ir_version
    model_2 = onnx.version_converter.convert_version(model_2, opset_version)

    model_12 = onnx.compose.merge_models(
        model_1,
        model_2,
        io_map=[],
        prefix1=prefix1,
        prefix2=prefix2,
    )

    onnx.checker.check_model(model_12)
    LOGGER.info(f"{PREFIX} merged inputs: {[i.name for i in model_12.graph.input]}")
    LOGGER.info(f"{PREFIX} merged outputs: {[o.name for o in model_12.graph.output]}")

    onnx.save(model_12, output_path)
    LOGGER.info(f"{PREFIX} saved merged model to {output_path}.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Combine two ONNX models into one.")
    parser.add_argument("model_path_1", type=str, help="Path to the first ONNX model")
    parser.add_argument("model_path_2", type=str, help="Path to the second ONNX model")
    parser.add_argument(
        "output_path", type=str, help="Path to save the merged ONNX model"
    )
    parser.add_argument(
        "--prefix1",
        type=str,
        default="",
        help="Prefix for the first model's inputs and outputs",
    )
    parser.add_argument(
        "--prefix2",
        type=str,
        default="",
        help="Prefix for the second model's inputs and outputs",
    )
    parser.add_argument(
        "--force-fp32",
        action="store_true",
        help="Convert models to FP32 before merging",
    )
    args = parser.parse_args()

    merge_onnx_models(
        args.model_path_1,
        args.model_path_2,
        args.output_path,
        prefix1=args.prefix1,
        prefix2=args.prefix2,
        force_fp32=args.force_fp32,
    )
