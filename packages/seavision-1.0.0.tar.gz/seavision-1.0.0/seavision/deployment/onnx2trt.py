"""Load an ONNX file and export it to a TensorRT engine.

For more info check out the [TensorRT's documentation](https://tinyurl.com/tensorrt-onnx).

Example usage:
    ```bash
    python onnx2trt.py model.onnx
    ```

Example with FP16 and verbose logging:
    ```bash
    python onnx2trt.py model.onnx --half --workspace 4 --verbose
    ```
"""

import argparse
import logging
from pathlib import Path
from typing import Union

import tensorrt as trt  # pylint: disable=import-error

from seavision.utils.general import LOGGER, colorstr


def export_engine(  # pylint: disable=too-many-locals
    onnx: Union[str, Path],
    half: bool = True,
    workspace: int = 4,
    verbose: bool = False,
    prefix: str = colorstr("TensorRT:"),
) -> Path:
    """Export an ONNX file to a TensorRT engine file.

    Args:
        onnx: The ONNX file to export.
        half: If True, the engine is exported as FP16. Otherwise, FP32.
        workspace: The required GPU workspace size in GiB to build TensorRT engine.
        verbose: If True, the logger is set to verbose.
        prefix: The prefix for the logger.

    Returns:
        Path: The path to the exported engine file.

    Raises:
        AssertionError: If the ONNX file does not exist.
        RuntimeError: If the ONNX file cannot be loaded.
    """
    onnx = Path(onnx)

    LOGGER.info(f"\n{prefix} starting export with TensorRT {trt.__version__}...")
    assert onnx.exists(), f"failed to export ONNX file: {onnx}"
    f = onnx.with_suffix(".engine")  # TensorRT engine file
    is_trt10 = int(trt.__version__.split(".")[0]) >= 10  # noqa: PLR2004

    logger = trt.Logger(trt.Logger.INFO)
    if verbose:
        logger.min_severity = trt.Logger.Severity.VERBOSE

    # Initialize plugins (needed for EfficientNMS_TRT and other custom ops)
    try:
        trt.init_libnvinfer_plugins(logger, "")
        logger.log(logger.INFO, "✓ TensorRT plugins initialized")
    except Exception as e:
        logger.log(logger.WARNING, f"⚠️ Could not initialize plugins: {e}")

    builder = trt.Builder(logger)
    config = builder.create_builder_config()
    if is_trt10:
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, workspace << 30)
    else:  # TensorRT versions 7, 8
        config.max_workspace_size = workspace * 1 << 30

    flag = 1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
    network = builder.create_network(flag)
    parser = trt.OnnxParser(network, logger)
    if not parser.parse_from_file(str(onnx)):
        raise RuntimeError(f"failed to load ONNX file: {onnx}")

    inputs = [network.get_input(i) for i in range(network.num_inputs)]
    outputs = [network.get_output(i) for i in range(network.num_outputs)]
    for inp in inputs:
        LOGGER.info(f'{prefix} input "{inp.name}" with shape{inp.shape} {inp.dtype}')
    for out in outputs:
        LOGGER.info(f'{prefix} output "{out.name}" with shape{out.shape} {out.dtype}')

    LOGGER.info(
        f"{prefix} building FP{16 if builder.platform_has_fast_fp16 and half else 32} "
        f"engine as {f}"
    )
    if builder.platform_has_fast_fp16 and half:
        config.set_flag(trt.BuilderFlag.FP16)
    build = builder.build_serialized_network if is_trt10 else builder.build_engine
    with build(network, config) as engine, Path(f).open("wb") as t:
        t.write(engine if is_trt10 else engine.serialize())
    return f


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments.

    Returns:
        argparse.Namespace: The parsed command line arguments.
    """
    parser = argparse.ArgumentParser(
        description="Export an ONNX file to a TensorRT engine"
    )
    parser.add_argument("onnx", type=Path, help="the ONNX file to export")
    parser.add_argument(
        "--half",
        action="store_true",
        help="export the engine as FP16 (default: FP32)",
    )
    parser.add_argument(
        "--workspace",
        type=int,
        default=4,
        help="the maximum workspace size in GB (default: 4)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="set the logger to verbose (default: INFO)",
    )
    return parser.parse_args()


def main() -> None:
    """Export an ONNX file to a TensorRT engine.

    This function is the main entry point for the script. It parses command line
    arguments and exports the ONNX model to a TensorRT engine.
    """
    logging.basicConfig(level=logging.INFO)
    args = parse_args()
    engine = export_engine(args.onnx, args.half, args.workspace, args.verbose)
    LOGGER.info(f"TensorRT engine exported to {engine}")


if __name__ == "__main__":
    main()
