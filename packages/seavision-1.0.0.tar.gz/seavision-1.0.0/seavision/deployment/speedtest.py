"""Speed test for inference.

This module provides functionality to measure inference speed of models using
dummy input data. It supports running inference in a loop and reporting
average inference times.

Note:
    Since this test uses randomly generated dummy data rather than real input
    data, the postprocessing timing measurements may not accurately reflect
    real-world inference performance. **Use this to get a rough estimate of the
    forward pass performance.**

Example usage:
    ```bash
    python speedtest.py path/to/model.ext -n 100
    ```
"""

import argparse
from typing import List

import numpy as np

from seavision import load_model
from seavision.inference.model_abc import Model
from seavision.utils.general import LOGGER


def get_dummy_inputs(model: Model) -> List[np.ndarray]:
    """Generate dummy input data for the model.

    Args:
        model: The model to generate inputs for.

    Returns:
        List[np.ndarray]: List of dummy input arrays matching the model's input
            specifications.
    """
    rng = np.random.default_rng(0x5EED)
    ims = []
    for inp in model.model.inputs:
        dims_order = model.model.dims_order
        im_shape = (
            inp.shape[dims_order.H],
            inp.shape[dims_order.W],
            inp.shape[dims_order.C],
        )
        im = rng.integers(0, 255, size=im_shape, dtype=np.uint8)
        ims.append(im)
    return ims


def inference_loop(model: Model, n: int) -> None:
    """Run inference in loop using dummy data.

    Args:
        model: The model to run inference with.
        n: Number of iterations to run inference for.
    """
    ims = get_dummy_inputs(model)
    batch_szs = (
        [model.model.input_bs]
        if not isinstance(model.model.input_bs, list)
        else model.model.input_bs
    )
    model_input = []
    for im, bs in zip(ims, batch_szs):
        model_input.append(np.stack([im] * bs) if bs > 1 else im)

    # reset profilers
    _ = [profile.reset() for profile in model.profiles.values()]

    LOGGER.info("Measuring speed over %d iterations", n)
    for _ in range(n):
        model(model_input[0] if len(model_input) == 1 else model_input)


def run_speed_test(model_name: str, n: int) -> None:
    """Run speed test for inference.

    Args:
        model_name: Name or path of the model to test.
        n: Number of iterations to run inference for.
    """
    LOGGER.info(f"Running speed test for {model_name}")
    with load_model(model_name) as model:
        inference_loop(model, n)
        for name, profile in model.profiles.items():
            LOGGER.info(f"{profile.t / n * 1e3:>5.1f} ms [avg] - {name}")


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "model_name",
        type=str,
        help="HF model name or path to model file.",
    )
    parser.add_argument(
        "-n",
        type=int,
        default=100,
        help="Number of times to run inference in loop. Default: 100",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_speed_test(args.model_name, args.n)
