"""Utility functions for working with ONNX models."""

import numpy as np
import onnx
from onnx import numpy_helper


def convert_fp16_weights_to_fp32(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Convert all FP16 weights in an ONNX model to FP32.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with FP32 weights.
    """
    # Iterate through initializers (weights) and convert FP16 to FP32
    for tensor in onnx_model.graph.initializer:
        if tensor.data_type == onnx.TensorProto.FLOAT16:
            # Convert FP16 tensor to FP32
            fp32_tensor = numpy_helper.to_array(tensor).astype(np.float32)
            new_tensor = numpy_helper.from_array(fp32_tensor, name=tensor.name)
            # Update the tensor in the model
            tensor.CopyFrom(new_tensor)

    return onnx_model


def convert_fp16_casts_to_fp32(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Convert all Cast nodes in an ONNX model to FP32.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with FP32 Cast nodes.
    """
    for node in onnx_model.graph.node:
        if node.op_type == "Cast":
            for attr in node.attribute:
                if attr.name == "to" and attr.i == onnx.TensorProto.FLOAT16:
                    attr.i = onnx.TensorProto.FLOAT

    return onnx_model


def remove_fp16_cast_nodes(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Remove Cast nodes that cast to FP16 in an ONNX model.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with removed FP16 Cast nodes.
    """
    # Create a mapping for outputs to inputs for Cast nodes that need to be removed
    input_output_map = {}
    nodes_to_remove = []

    for node in onnx_model.graph.node:
        if node.op_type == "Cast":
            for attr in node.attribute:
                if attr.name == "to" and attr.i == onnx.TensorProto.FLOAT16:
                    input_output_map[node.output[0]] = node.input[0]
                    nodes_to_remove.append(node)
                    break

    # Update all nodes to reroute inputs and outputs
    for node in onnx_model.graph.node:
        if node not in nodes_to_remove:
            node.input[:] = [input_output_map.get(input, input) for input in node.input]
            node.output[:] = [
                input_output_map.get(output, output) for output in node.output
            ]

    # Remove Cast nodes
    for node in nodes_to_remove:
        onnx_model.graph.node.remove(node)

    return onnx_model


def convert_io_to_fp32(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Convert all FP16 input and output tensors in an ONNX model to FP32.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with FP32 input and output tensors.
    """
    for inp in onnx_model.graph.input:
        inp.type.tensor_type.elem_type = onnx.TensorProto.FLOAT

    for out in onnx_model.graph.output:
        out.type.tensor_type.elem_type = onnx.TensorProto.FLOAT

    return onnx_model


def convert_fp16_model_to_fp32(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Convert an ONNX model with FP16 weights to FP32.

    - Convert all FP16 weights to FP32.
    - Convert all Cast nodes to FP32.
    - Convert all FP16 input and output tensors to FP32.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with FP32 weights.
    """
    onnx_model = convert_io_to_fp32(onnx_model)
    onnx_model = convert_fp16_casts_to_fp32(onnx_model)
    onnx_model = convert_fp16_weights_to_fp32(onnx_model)

    return onnx_model


def convert_uint8_io_to_fp32(onnx_model: onnx.ModelProto) -> onnx.ModelProto:
    """Convert all UINT8 input and output tensors in an ONNX model to FP32.

    Args:
        onnx_model: ONNX model.

    Returns:
        ONNX model with FP32 input and output tensors.
    """
    for inp in onnx_model.graph.input:
        tensor_type = inp.type.tensor_type
        if tensor_type.elem_type == onnx.TensorProto.UINT8:
            tensor_type.elem_type = onnx.TensorProto.FLOAT

    for out in onnx_model.graph.output:
        tensor_type = out.type.tensor_type
        if tensor_type.elem_type == onnx.TensorProto.UINT8:
            tensor_type.elem_type = onnx.TensorProto.FLOAT

    return onnx_model
