"""Common utility functions."""

import logging
import logging.config
import os
import platform

import numpy as np
from PIL import Image

LOGGING_NAME = "seavision"  # logging name


def emojis(_str: str = ""):
    """Return platform-dependent emoji-safe version of string."""
    return (
        _str.encode().decode("ascii", "ignore")
        if platform.system() == "Windows"
        else _str
    )


def colorstr(*input_str):
    """Colors a string https://en.wikipedia.org/wiki/ANSI_escape_code.

    Example:
        ```python
        colorstr("blue", "hello world")
        ```
    """
    *args, string = (
        input if len(input_str) > 1 else ("blue", "bold", input_str[0])
    )  # color arguments, string
    colors = {
        "black": "\033[30m",  # basic colors
        "red": "\033[31m",
        "green": "\033[32m",
        "yellow": "\033[33m",
        "blue": "\033[34m",
        "magenta": "\033[35m",
        "cyan": "\033[36m",
        "white": "\033[37m",
        "bright_black": "\033[90m",  # bright colors
        "bright_red": "\033[91m",
        "bright_green": "\033[92m",
        "bright_yellow": "\033[93m",
        "bright_blue": "\033[94m",
        "bright_magenta": "\033[95m",
        "bright_cyan": "\033[96m",
        "bright_white": "\033[97m",
        "end": "\033[0m",  # misc
        "bold": "\033[1m",
        "underline": "\033[4m",
    }
    return "".join(colors[x] for x in args) + f"{string}" + colors["end"]


def set_logging(name: str = LOGGING_NAME, verbose: bool = True):
    """Set up logging for the given name.

    Args:
        name: Name of the logger.
        verbose: Whether to print logs to the console.
    """
    rank = int(os.getenv("RANK", -1))  # rank in world for Multi-GPU trainings
    level = logging.INFO if verbose and rank in {-1, 0} else logging.ERROR
    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {name: {"format": "%(message)s"}},
            "handlers": {
                name: {
                    "class": "logging.StreamHandler",
                    "formatter": name,
                    "level": level,
                }
            },
            "loggers": {
                name: {
                    "level": level,
                    "handlers": [name],
                    "propagate": False,
                }
            },
        }
    )


set_logging(LOGGING_NAME)  # run before defining LOGGER
LOGGER = logging.getLogger(
    LOGGING_NAME
)  # define globally (used in train.py, val.py, detect.py, etc.)
if platform.system() == "Windows":
    for fn in LOGGER.info, LOGGER.warning:
        setattr(
            LOGGER, fn.__name__, lambda x, fn=fn: fn(emojis(x))
        )  # emoji safe logging


def pil_side_by_side(img1: Image.Image, img2: Image.Image) -> Image.Image:
    """Combine two PIL images side by side."""
    img1 = Image.fromarray(img1) if isinstance(img1, np.ndarray) else img1
    img2 = Image.fromarray(img2) if isinstance(img2, np.ndarray) else img2
    w1, h1 = img1.size
    w2, h2 = img2.size
    w, h = w1 + w2, max(h1, h2)
    new_img = Image.new("RGBA", (w, h))
    new_img.paste(img1, (0, (h - h1) // 2))
    new_img.paste(img2, (w1, 0))
    return new_img


def pil_up_down(img1: Image.Image, img2: Image.Image) -> Image.Image:
    """Combine two PIL images up and down."""
    img1 = Image.fromarray(img1) if isinstance(img1, np.ndarray) else img1
    img2 = Image.fromarray(img2) if isinstance(img2, np.ndarray) else img2
    w1, h1 = img1.size
    w2, h2 = img2.size

    # Resize wider image to match narrower width
    if w1 > w2:
        ratio = w2 / w1
        new_h1 = int(h1 * ratio)
        img1 = img1.resize((w2, new_h1), Image.Resampling.LANCZOS)
        w1, h1 = img1.size
    elif w2 > w1:
        ratio = w1 / w2
        new_h2 = int(h2 * ratio)
        img2 = img2.resize((w1, new_h2), Image.Resampling.LANCZOS)
        w2, h2 = img2.size

    w = w1  # Both widths are now equal
    h = h1 + h2
    new_img = Image.new("RGBA", (w, h))
    new_img.paste(img1, (0, 0))
    new_img.paste(img2, (0, h1))
    return new_img
