"""Utilities for Jetson devices.

Examples for `jetpack_version`:
    ```python
    print(jetpack_version())  # Computes and caches the version the first time
    print(jetpack_version())  # Reuses the cached version
    ```

Examples for `get_variables_from_dtsfilename`:
    ```python
    print(get_variables_from_dtsfilename())
    {
        "CODENAME": "jakku",
        "SOC": "tegra194",
        "PART_NUMBER": "p3668-0000",
        "CARRIER": "p3509-0000",
        "MODULE": "NVIDIA Jetson Xavier NX (Developer kit)",
        "CUDA_ARCH_BIN": "7.2",
        "L4T": "5.1.2",
        "DEVICE_FAMILY": "Xavier",
        "MODEL": "NX",
    }
    ```
"""

import os
import re
from typing import Dict

# ---------------------
# JETPACK DETECTION
# ---------------------
# Write version of jetpack installed
# https://developer.nvidia.com/embedded/jetpack-archive
NV_TEGRA_RELEASE_PATH = "/etc/nv_tegra_release"
NVIDIA_JETPACK = {
    # -------- JP6 --------
    "36.2.0": "6.0 DP",
    # -------- JP5 --------
    "35.4.1": "5.1.2",
    "35.2.1": "5.1",
    # -------- JP4 --------
    "32.7.4": "4.6.4",
    "32.7.3": "4.6.3",
    "32.7.2": "4.6.2",
    "32.7.1": "4.6.1",
    "32.6.1": "4.6",
    "32.5.2": "4.5.1",
    "32.5.1": "4.5.1",
    "32.5.0": "4.5",
    "32.5": "4.5",
    "32.4.4": "4.4.1",
    "32.4.3": "4.4",
}

CUDA_TABLE = {
    "tegra234": "8.7",  # JETSON ORIN - tegra234
    "tegra23x": "8.7",  # JETSON ORIN - tegra234
    "tegra194": "7.2",  # JETSON XAVIER
    "tegra186": "6.2",  # JETSON TX2
    "tegra210": "5.3",  # JETSON TX1
    "tegra124": "3.2",  # JETSON TK1
}

# Module reference
# https://docs.nvidia.com/jetson/archives/l4t-archived/l4t-3231/index.html
# https://docs.nvidia.com/jetson/archives/r35.2.1/DeveloperGuide/text/IN/QuickStart.html
MODULE_NAME_TABLE = {
    "p3767-0005": "NVIDIA Jetson Orin Nano (Developer kit)",
    "p3767-0004": "NVIDIA Jetson Orin Nano (4GB ram)",
    "p3767-0003": "NVIDIA Jetson Orin Nano (8GB ram)",
    "p3767-0001": "NVIDIA Jetson Orin NX (8GB ram)",
    "p3767-0000": "NVIDIA Jetson Orin NX (16GB ram)",
    "p3701-0005": "NVIDIA Jetson AGX Orin (64GB ram)",
    "p3701-0004": "NVIDIA Jetson AGX Orin (32GB ram)",
    "p3701-0002": "NVIDIA Jetson IGX Orin (Developer kit)",
    "p3701-0000": "NVIDIA Jetson AGX Orin",
    "p3668-0003": "NVIDIA Jetson Xavier NX (16GB ram)",
    "p3668-0001": "NVIDIA Jetson Xavier NX",
    "p3668-0000": "NVIDIA Jetson Xavier NX (Developer kit)",
    "p2888-0008": "NVIDIA Jetson AGX Xavier Industrial (32 GB ram)",
    "p2888-0006": "NVIDIA Jetson AGX Xavier (8 GB ram)",
    "p2888-0005": "NVIDIA Jetson AGX Xavier (64 GB ram)",
    "p2888-0004": "NVIDIA Jetson AGX Xavier (32 GB ram)",
    "p2888-0003": "NVIDIA Jetson AGX Xavier (32 GB ram)",
    "p2888-0001": "NVIDIA Jetson AGX Xavier (16 GB ram)",
    "p3448-0003": "NVIDIA Jetson Nano (2 GB ram)",
    "p3448-0002": "NVIDIA Jetson Nano module (16Gb eMMC)",
    "p3448-0000": "NVIDIA Jetson Nano (4 GB ram)",
    "p3636-0001": "NVIDIA Jetson TX2 NX",
    "p3509-0000": "NVIDIA Jetson TX2 NX",
    "p3489-0888": "NVIDIA Jetson TX2 (4 GB ram)",
    "p3489-0000": "NVIDIA Jetson TX2i",
    "p3310-1000": "NVIDIA Jetson TX2",
    "p2180-1000": "NVIDIA Jetson TX1",
    "r375-0001": "NVIDIA Jetson TK1",
    "p3904-0000": "NVIDIA Clara AGX",
    # Other modules
    "p2595-0000-A0": "Nintendo Switch",
}
DTSFILENAME_RE = re.compile(r"(.*)-p")
DEVICE_FAMILY_RE = re.compile(r"xavier|orin", re.IGNORECASE)
MODEL_RE = re.compile(r"agx|nx|nano", re.IGNORECASE)


def cat(path: str) -> str:
    """Read the first line of a file."""
    with open(path, "r", encoding="utf-8") as f:
        return f.readline().rstrip("\x00")  # remove null characters


def read_nv_tegra_release(path: str = NV_TEGRA_RELEASE_PATH) -> str:
    """Read the first line of the file."""
    if os.path.isfile(path):
        return cat(path)
    return ""


def jetpack_version() -> str:
    """Lazy evaluation of the Jetpack version.

    Returns "Unknown" if the version is not found
    """
    # Check if the version is already cached
    if hasattr(jetpack_version, "cache"):  # function attribute
        return jetpack_version.cache

    nv_tegra_release: str = read_nv_tegra_release()
    if nv_tegra_release:
        # NVIDIA Jetson version
        # references:
        # https://devtalk.nvidia.com/default/topic/860092/jetson-tk1/how-do-i-know-what-version-of-l4t-my-jetson-tk1-is-running-/
        # https://stackoverflow.com/questions/16817646/extract-version-number-from-a-string
        # https://askubuntu.com/questions/319307/reliably-check-if-a-package-is-installed-or-not
        # https://github.com/dusty-nv/jetson-inference/blob/7e81381a96c1ac5f57f1728afbfdec7f1bfeffc2/tools/install-pytorch.sh#L296
        nv_tegra_release = nv_tegra_release.split(", ")
        l4t_release = nv_tegra_release[0].lstrip("# R").rstrip(" (release)")
        l4t_revision = nv_tegra_release[1].lstrip("REVISION: ")
        l4t = ".".join([l4t_release, l4t_revision])
        jetpack_version.cache = NVIDIA_JETPACK.get(l4t, l4t)
    else:
        jetpack_version.cache = "Unknown"
    return jetpack_version.cache


def get_variables_from_dtsfilename() -> Dict[str, str]:
    """Get Jetson hardware variables from dtsfilename.

    Returns:
        dict: A dictionary containing the following keys:

            - `CODENAME`: The codename of the Jetson device
            - `SOC`: The System on a Chip
            - `PART_NUMBER`: The part number of the module
            - `CARRIER`: The part number of the carrier board
            - `MODULE`: The name of the module
            - `CUDA_ARCH_BIN`: The CUDA architecture
            - `L4T`: The L4T version
            - `DEVICE_FAMILY`: The device family
            - `MODEL`: The model of the Jetson device
    """
    hardware = {}
    # Decode dtsfilename
    if os.path.isfile("/proc/device-tree/nvidia,dtsfilename"):
        # Read dtsfilename
        # AGX Orin - tegra234-p3701-0000-p3737-0000
        # Nano - tegra210-p3448-0000-p3449-0000-b00
        # TX2 - tegra186-quill-p3310-1000-c03-00-base
        # TX1 - tegra210-jetson-tx1-p2597-2180-a01-devkit
        # TK1 - tegra124-jetson_tk1-pm375-000-c00-00
        dtsfilename = cat("/proc/device-tree/nvidia,dtsfilename").split("/")
        # Decode codename
        hardware["CODENAME"] = dtsfilename[-3]
        # Decode NVIDIA Jetson type, model and board
        jetson_soc_module_board = dtsfilename[-1].rstrip(".dts").split("-")
        hardware["SOC"] = jetson_soc_module_board[0]
        # print("type: {jetson_type}".format(jetson_type=hardware['TYPE']))
        parts = "-".join(jetson_soc_module_board[1:])
        if "dsboard" in parts:
            dtsfilename_re = re.compile(r"(.*)-dsboard")
        else:
            dtsfilename_re = DTSFILENAME_RE
        match = re.match(dtsfilename_re, parts)
        if match:
            module = match.group(1)
            hardware["PART_NUMBER"] = module
            # print(f"module: {module}".format(module=module))
            carrier = parts.replace("{module}-".format(module=module), "")
            hardware["CARRIER"] = carrier
            # print(f"carrier: {carrier}".format(carrier=carrier))
            # Decode Jetson type of module
            # https://docs.nvidia.com/jetson/archives/r34.1/DeveloperGuide/index.html
            hardware["MODULE"] = MODULE_NAME_TABLE.get(module, "")
        else:
            print("jetson model and board not available")
            print(parts)
    # Decode CUDA architecure
    hardware["CUDA_ARCH_BIN"] = CUDA_TABLE.get(hardware["SOC"], "")
    hardware["L4T"] = jetpack_version()
    hardware["DEVICE_FAMILY"] = DEVICE_FAMILY_RE.search(hardware["MODULE"]).group(0)
    hardware["MODEL"] = MODEL_RE.search(hardware["MODULE"]).group(0)
    return hardware
