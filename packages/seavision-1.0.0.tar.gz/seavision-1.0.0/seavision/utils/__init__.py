"""This module contains utility functions for the seavision package."""
