"""Utility functions for downloading models/data from online sources."""

import os
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from huggingface_hub import hf_hub_download, list_repo_files
from huggingface_hub.errors import HFValidationError, RepositoryNotFoundError

from .general import LOGGER

if TYPE_CHECKING:
    import wandb

_MODEL_EXTENSIONS = (".onnx", ".pt", ".engine")


def list_hf_models(
    repo_id: str, extension: Optional[str] = None, token: Optional[str] = None
) -> list[str]:
    """List all models in the SeaVision repository.

    Args:
        repo_id: Repository ID.
        extension: Extension of the files to list.
        token: Hugging Face token.

    Returns:
        List of model files.
    """
    files = list_repo_files(repo_id=repo_id, repo_type="model", token=token)
    if extension:
        files = [f for f in files if f.endswith(extension)]
    files = [
        f
        for f in files
        if not (f.endswith((".json", ".yaml", ".md")) or f.startswith("."))
    ]
    return files


def attempt_download_from_hf(
    repo_id: str,
    model_name: str,
    hf_token: Optional[str] = None,
    default_extension: str = "onnx",
) -> Optional[str]:
    """Attempt to download the model from the Hugging Face Hub.

    Args:
        repo_id: Repository ID.
        model_name: Model name.
        hf_token: Hugging Face token.
        default_extension: Default extension if no extension is provided.

    Returns:
        Path to the downloaded model file.
    """
    if not Path(model_name).suffix:
        model_name = f"{model_name}.{default_extension}"

    try:
        repo_files = list_repo_files(repo_id=repo_id, repo_type="model", token=hf_token)

        if model_name not in repo_files:
            return None

        file = hf_hub_download(
            repo_id=repo_id,
            filename=model_name,
            token=hf_token,
        )
        yaml_file = Path(model_name).with_suffix(".yaml")
        if yaml_file in repo_files:
            hf_hub_download(
                repo_id=repo_id,
                filename=yaml_file.name,
                token=hf_token,
            )

        json_file = Path(model_name).with_suffix(".json")
        if json_file in repo_files:
            hf_hub_download(
                repo_id=repo_id,
                filename=json_file.name,
                token=hf_token,
            )

        return file
    except (RepositoryNotFoundError, HFValidationError, ValueError):
        return None


def _wandb_artifact_root() -> Path:
    """Return the root directory for W&B artifact downloads (cache-friendly default)."""
    env = os.getenv("WANDB_ARTIFACT_DIR")
    if env:
        return Path(env)
    return Path.home() / ".cache" / "seavision" / "wandb"


def _wandb_artifact_to_model_path(
    api: "wandb.Api", artifact_name: str, root: Path
) -> Optional[str]:
    """Download one artifact and return path to model file, or None."""
    try:
        artifact_path = api.artifact(name=artifact_name).download(root=str(root))
        # Only consider files with allowed extensions, return the first found
        for f in sorted(Path(artifact_path).glob("*")):
            if f.is_file() and f.suffix.lower() in _MODEL_EXTENSIONS:
                return str(f)
        return None
    except Exception:
        return None


def attempt_download_from_wandb(ref: str) -> Optional[str]:
    """Download a model from Weights & Biases: registry or run artifact.

    Args:
        ref: W&B reference. Can be in the format `collection:version` (registry)
            or `entity/project/artifact:version` (run).

    Returns:
        Path to the downloaded model file.

    Environment:
        WANDB_ARTIFACT_DIR: Custom download location (same as wandb's env var).
            If unset, defaults to ``~/.cache/seavision/wandb``.
    """
    import wandb

    api = wandb.Api()
    root = _wandb_artifact_root()
    root.mkdir(parents=True, exist_ok=True)
    candidates = []

    if ":" in ref and "/" not in ref.split(":", maxsplit=1)[0]:
        candidates.append(f"wandb-registry-model/{ref}")
    candidates.append(ref)

    for artifact_name in candidates:
        path = _wandb_artifact_to_model_path(api, artifact_name, root / ref)
        if path:
            LOGGER.info("Downloaded W&B artifact to %s", path)
            return path

    return None
