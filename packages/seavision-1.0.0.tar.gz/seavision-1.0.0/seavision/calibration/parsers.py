"""Parsers for sensor calibration data."""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Union

from seavision.geometry.pinhole import Camera


@dataclass(frozen=True)
class CalibrationData:
    """Calibration bundle loaded from JSON (Oscar / Sentry or legacy intrinsics)."""

    cameras: dict[str, Camera]

    @staticmethod
    def _build_camera(camera_data: Dict[str, Any]) -> Camera:
        """Build a Camera from one JSON camera block."""
        if "focal_length_x" in camera_data:
            width, height = camera_data["resolution"]["value"]
            fx = camera_data["focal_length_x"]["value"]
            fy = camera_data["focal_length_y"]["value"]
            cx = camera_data["center_x"]["value"]
            cy = camera_data["center_y"]["value"]
        else:
            height, width = camera_data["resolution"]["value"]
            f_mm = camera_data["focal_length"]["value"]
            pixel_mm = camera_data["pixel_size"]["value"]
            if pixel_mm == 0:
                raise ValueError(
                    "pixel_size must be non-zero to derive focal length in pixels"
                )
            fx = fy = f_mm / pixel_mm
            cx = width / 2.0
            cy = height / 2.0
        return Camera(
            width=int(width),
            height=int(height),
            fx=float(fx),
            fy=float(fy),
            cx=float(cx),
            cy=float(cy),
            roll=float(camera_data["roll"]["value"]),
            pitch=float(camera_data["pitch"]["value"]),
            yaw=float(camera_data["yaw"]["value"]),
        )

    @classmethod
    def from_json(cls, file_path: Union[str, Path]) -> "CalibrationData":
        """Parse calibration data from a JSON file."""
        with Path(file_path).open("r", encoding="utf-8") as f:
            data = json.load(f)
        cameras = {
            camera_id: cls._build_camera(camera_data)
            for camera_id, camera_data in data.get("cameras", {}).items()
        }
        return cls(cameras=cameras)
