"""FastAPI server for the Sentry homography calibration tool."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import uvicorn
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from seavision.calibration import CalibrationData
from seavision.calibration.utils import (
    CAMERA_PATTERNS,
    DEFAULT_REFERENCE_CAMERA,
    image_to_base64,
    load_first_frames,
    load_sentry_config,
    process_calibration,
    read_sensors_json,
    source_cameras_for_reference,
    update_sensors_json,
)

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Seavision")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@dataclass
class _ServerState:
    """Mutable server state shared across request handlers."""

    sentry: Optional[CalibrationData] = None
    frames: Dict[str, np.ndarray] = field(default_factory=dict)
    recording_path: Optional[str] = None
    reference_camera: str = DEFAULT_REFERENCE_CAMERA
    current_camera: Optional[str] = None
    camera_ui_values: Dict[str, Dict[str, float]] = field(default_factory=dict)
    dry_run: bool = False
    recordings_root: Optional[Path] = None


_state = _ServerState()


def resolve_recording_path(path: str) -> Path:
    """Resolve and validate a recording path against the configured root."""
    resolved = Path(path).expanduser().resolve()
    if _state.recordings_root is not None:
        try:
            resolved.relative_to(_state.recordings_root)
        except ValueError as e:
            raise ValueError("Access outside recordings root is not allowed") from e
    return resolved


def _apply_recording(path: str) -> None:
    """Load recording data into server state (atomic: commits only on full success)."""
    resolved = resolve_recording_path(path)
    sentry = load_sentry_config(str(resolved), reference_camera=_state.reference_camera)
    frames = load_first_frames(str(resolved))
    _state.sentry = sentry
    _state.frames = frames
    _state.recording_path = str(resolved)
    _state.current_camera = None
    _state.camera_ui_values = {}


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    """Serve the calibration UI."""
    return (STATIC_DIR / "index.html").read_text()


@app.get("/api/camera_sources")
def camera_sources() -> Dict[str, Any]:
    """List source cameras for the current reference (fixed at server start)."""
    return {"cameras": source_cameras_for_reference(_state.reference_camera)}


@app.get("/api/select_camera_source")
def select_camera_source(camera: str = Query(...)) -> Dict[str, Any]:
    """Select the active camera and return its current UI values."""
    allowed = source_cameras_for_reference(_state.reference_camera)
    if camera not in allowed:
        raise HTTPException(400, f"Invalid camera: {camera}; allowed: {allowed}")
    _state.current_camera = camera
    if camera not in _state.camera_ui_values:
        _state.camera_ui_values[camera] = (
            _state.sentry.cameras[camera].extrinsics()
            if _state.sentry is not None and camera in _state.sentry.cameras
            else {"pitch": 0.0, "yaw": 0.0, "roll": 0.0}
        )
    return {"camera": camera, "values": _state.camera_ui_values[camera]}


@app.get("/api/process")
def process(
    pitch: float = Query(0.0),
    yaw: float = Query(0.0),
    roll: float = Query(0.0),
    weight: float = Query(0.5),
) -> Dict[str, Any]:
    """Run calibration and return base64-encoded result images."""
    if _state.sentry is None or not _state.frames:
        raise HTTPException(400, "No recording loaded")
    if _state.current_camera is None:
        raise HTTPException(400, "No camera source selected")
    _state.camera_ui_values[_state.current_camera] = {
        "pitch": pitch,
        "yaw": yaw,
        "roll": roll,
    }
    result = process_calibration(
        _state.sentry,
        _state.frames,
        _state.current_camera,
        pitch,
        yaw,
        roll,
        weight,
        reference_camera=_state.reference_camera,
    )
    return {"mixed": image_to_base64(result["mixed"])}


@app.get("/api/reset_camera")
def reset_camera(camera: str = Query(...)) -> Dict[str, Any]:
    """Reset a camera's UI values to the original values from the recording."""
    allowed = source_cameras_for_reference(_state.reference_camera)
    if camera not in allowed:
        raise HTTPException(400, f"Invalid camera: {camera}; allowed: {allowed}")
    if _state.sentry is None:
        raise HTTPException(400, "No recording loaded")
    if camera not in _state.sentry.cameras:
        raise HTTPException(400, f"Camera not found: {camera}")
    _state.camera_ui_values[camera] = _state.sentry.cameras[camera].extrinsics()
    return {"camera": camera, "values": _state.camera_ui_values[camera]}


@app.get("/api/load_recording")
def load_recording(path: str = Query(...)) -> Dict[str, Any]:
    """Load a recording directory into server state."""
    try:
        _apply_recording(path)
    except Exception as e:
        raise HTTPException(400, str(e)) from e
    return {"status": "loaded", "path": path}


@app.get("/api/browse_root")
def browse_root() -> Dict[str, Any]:
    """Return the initial directory for the file browser."""
    root = _state.recordings_root or Path("~").expanduser().resolve()
    return {"path": str(root)}


@app.get("/api/browse")
def browse(path: str = Query(...)) -> Dict[str, Any]:
    """List subdirectories of path, flagging valid recordings."""
    base = Path(path).expanduser().resolve()
    if not base.is_dir():
        raise HTTPException(400, f"Not a directory: {path}")
    if _state.recordings_root is not None:
        try:
            base.relative_to(_state.recordings_root)
        except ValueError as e:
            raise HTTPException(
                403, "Access outside recordings root is not allowed"
            ) from e
    entries = sorted(
        (
            {
                "name": e.name,
                "is_recording": (e / "POWER_Const" / "sentry_sensors.json").exists(),
            }
            for e in base.iterdir()
            if e.is_dir()
        ),
        key=lambda e: (not e["is_recording"], e["name"]),
    )
    root = _state.recordings_root or base.anchor
    return {
        "path": str(base),
        "parent": str(base.parent),
        "root": str(root),
        "entries": entries,
    }


@app.get("/api/sensors_json")
def get_sensors_json() -> Dict[str, Any]:
    """Return the current on-disk sentry_sensors.json and pending UI values."""
    if _state.recording_path is None:
        raise HTTPException(400, "No recording loaded")
    return {
        "data": read_sensors_json(_state.recording_path),
        "pending": _state.camera_ui_values,
    }


@app.get("/api/save_sensors_json")
def save_sensors_json() -> Dict[str, str]:
    """Write pending UI values to sentry_sensors.json."""
    if _state.recording_path is None:
        raise HTTPException(400, "No recording loaded")
    if _state.dry_run:
        for camera, values in _state.camera_ui_values.items():
            print(
                f"[dry-run] {camera}: "
                f"pitch={values['pitch']:.4f}  "
                f"yaw={values['yaw']:.4f}  "
                f"roll={values['roll']:.4f}"
            )
    else:
        update_sensors_json(_state.recording_path, _state.camera_ui_values)
    return {"status": "dry-run (see terminal)" if _state.dry_run else "saved"}


def configure_server(
    recording_path: Optional[str] = None,
    dry_run: bool = False,
    reference_camera: Optional[str] = None,
    recordings_root: Optional[str] = None,
) -> None:
    """Apply startup configuration to server state. Raises SystemExit for bad inputs."""
    _state.dry_run = dry_run
    if recordings_root is not None:
        _state.recordings_root = Path(recordings_root).expanduser().resolve()
    if reference_camera is not None:
        if reference_camera not in CAMERA_PATTERNS:
            raise SystemExit(
                f"calibration: unknown reference {reference_camera!r}; "
                f"expected one of: {sorted(CAMERA_PATTERNS)}"
            )
        _state.reference_camera = reference_camera
    if recording_path is not None:
        _apply_recording(recording_path)
        print(f"Loaded recording: {recording_path}")
    print(f"Reference (master) camera: {_state.reference_camera}")


def run_web_server(
    recording_path: Optional[str] = None,
    port: int = 8323,
    host: str = "0.0.0.0",
    dry_run: bool = False,
    reference_camera: Optional[str] = None,
    recordings_root: Optional[str] = None,
) -> None:
    """Start the calibration web server, optionally with a pre-loaded recording."""
    configure_server(
        recording_path=recording_path,
        dry_run=dry_run,
        reference_camera=reference_camera,
        recordings_root=recordings_root,
    )
    open_url = (
        f"http://127.0.0.1:{port}" if host == "0.0.0.0" else f"http://{host}:{port}"
    )
    print(f"Calibration server listening on {host}:{port} — open {open_url}")
    uvicorn.run(app, host=host, port=port, log_level="warning")
