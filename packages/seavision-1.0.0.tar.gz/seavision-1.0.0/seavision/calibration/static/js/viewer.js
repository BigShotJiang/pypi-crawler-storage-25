import { $, api as fetchApi, esc, getSelectedCamera } from './api.js';
import { sliderVal } from './controls.js';

// ── View state ────────────────────────────────────────────────────────────────
let _activeView = 'image';
let _hasImage = false;

export function getActiveView() { return _activeView; }

// ── Zoom + pan state ──────────────────────────────────────────────────────────
let scale = 1, tx = 0, ty = 0;
let dragging = false, dragStartX = 0, dragStartY = 0, dragTx = 0, dragTy = 0;

function applyTransform() {
  $('img-mixed').style.transform = `translate(${tx}px, ${ty}px) scale(${scale})`;
}


function clampTranslation() {
  const zoomEl = $('zoom-container');
  const cw = zoomEl.clientWidth, ch = zoomEl.clientHeight;
  const iw = cw * scale, ih = ch * scale;
  tx = Math.min(0, Math.max(cw - iw, tx));
  ty = Math.min(0, Math.max(ch - ih, ty));
}

/** Attach zoom + pan listeners to the zoom container. Call once on init. */
export function initZoom() {
  const zoomEl = $('zoom-container');

  zoomEl.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = zoomEl.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const delta = e.deltaY < 0 ? 1.15 : 1 / 1.15;
    const newScale = Math.min(20, Math.max(1, scale * delta));
    tx = mouseX - (mouseX - tx) * (newScale / scale);
    ty = mouseY - (mouseY - ty) * (newScale / scale);
    scale = newScale;
    if (scale === 1) { tx = 0; ty = 0; }
    else clampTranslation();
    applyTransform();
    zoomEl.style.cursor = scale > 1 ? 'grab' : 'default';
  }, { passive: false });

  zoomEl.addEventListener('mousedown', (e) => {
    if (scale <= 1) return;
    dragging = true;
    dragStartX = e.clientX; dragStartY = e.clientY;
    dragTx = tx; dragTy = ty;
    zoomEl.style.cursor = 'grabbing';
    e.preventDefault();
  });

  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    tx = dragTx + (e.clientX - dragStartX);
    ty = dragTy + (e.clientY - dragStartY);
    clampTranslation();
    applyTransform();
  });

  window.addEventListener('mouseup', () => {
    if (!dragging) return;
    dragging = false;
    zoomEl.style.cursor = scale > 1 ? 'grab' : 'default';
  });

  zoomEl.addEventListener('dblclick', () => {
    scale = 1; tx = 0; ty = 0;
    applyTransform();
    zoomEl.style.cursor = 'default';
  });
}

// ── Image display ─────────────────────────────────────────────────────────────

/** Show a base64 image in the viewer, hiding the placeholder. */
export function showImage(key, b64) {
  _hasImage = true;
  $(`ph-${key}`).style.display = 'none';
  $('img-mixed').src = `data:image/jpeg;base64,${b64}`;
  if (_activeView === 'image') $('zoom-container').style.display = 'flex';
}

// ── View switching ────────────────────────────────────────────────────────────

/** Switch between 'image' and 'json' views. */
export function switchView(view) {
  _activeView = view;
  const isJson = view === 'json';

  $('tab-image').classList.toggle('active', !isJson);
  $('tab-json').classList.toggle('active', isJson);
  $('tab-image').setAttribute('aria-selected', String(!isJson));
  $('tab-json').setAttribute('aria-selected', String(isJson));

  $('json-view').classList.toggle('visible', isJson);
  if (isJson) {
    $('ph-mixed').style.display = 'none';
    $('zoom-container').style.display = '';
    refreshJsonViewer();
  } else {
    if (_hasImage) {
      $('zoom-container').style.display = 'flex';
      $('ph-mixed').style.display = 'none';
    } else {
      $('zoom-container').style.display = '';
      $('ph-mixed').style.display = '';
    }
  }
}

// ── JSON renderer ─────────────────────────────────────────────────────────────
let _cachedJsonData = null;
let _cachedPending = {};

function renderJson(data, pending) {
  function isPendingChanged(keyPath, val) {
    if (keyPath.length !== 4) return false;
    if (keyPath[0] !== 'cameras') return false;
    if (!['pitch', 'yaw', 'roll'].includes(keyPath[2])) return false;
    if (keyPath[3] !== 'value') return false;
    const cam = keyPath[1], field = keyPath[2];
    if (!pending[cam]) return false;
    return Math.abs(val - pending[cam][field]) > 1e-9;
  }

  const renderNull = () => `<span class="jb">null</span>`;
  const renderBoolean = (val) => `<span class="jb">${val}</span>`;
  const renderNumber = (val, keyPath) => {
    const str = esc(String(val));
    if (isPendingChanged(keyPath, val)) {
      const pv = pending[keyPath[1]][keyPath[2]];
      return `<span class="jn jchanged" title="On disk: ${str}">${esc(String(pv))}</span>`;
    }
    return `<span class="jn">${str}</span>`;
  };
  const renderString = (val) => `<span class="js">"${esc(val)}"</span>`;
  const renderArray = (val, keyPath, indent) => {
    const pad = '  '.repeat(indent);
    const padInner = '  '.repeat(indent + 1);
    if (!val.length) return `<span class="jp">[]</span>`;
    const items = val.map((v, i) => `${padInner}${renderValue(v, [...keyPath, i], indent + 1)}`);
    return `<span class="jp">[</span>\n${items.join('<span class="jp">,</span>\n')}\n${pad}<span class="jp">]</span>`;
  };
  const renderObject = (val, keyPath, indent) => {
    const pad = '  '.repeat(indent);
    const padInner = '  '.repeat(indent + 1);
    const entries = Object.entries(val);
    if (!entries.length) return `<span class="jp">{}</span>`;
    const lines = entries.map(([k, v]) =>
      `${padInner}<span class="jk">"${esc(k)}"</span><span class="jp">: </span>${renderValue(v, [...keyPath, k], indent + 1)}`
    );
    return `<span class="jp">{</span>\n${lines.join('<span class="jp">,</span>\n')}\n${pad}<span class="jp">}</span>`;
  };

  function renderValue(val, keyPath, indent) {
    if (val === null) return renderNull();
    if (typeof val === 'boolean') return renderBoolean(val);
    if (typeof val === 'number') return renderNumber(val, keyPath);
    if (typeof val === 'string') return renderString(val);
    if (Array.isArray(val)) return renderArray(val, keyPath, indent);
    if (typeof val === 'object') return renderObject(val, keyPath, indent);
    return esc(String(val));
  }

  return renderValue(data, [], 0);
}

/** Re-render JSON from cache with live slider values for the active camera. */
export function applyJsonRender() {
  if (!_cachedJsonData) return;
  const pre = $('json-pre');
  const badge = $('json-changed-badge');

  const cam = getSelectedCamera();
  const livePending = Object.assign({}, _cachedPending);
  if (cam) {
    livePending[cam] = { pitch: sliderVal('pitch'), yaw: sliderVal('yaw'), roll: sliderVal('roll') };
  }

  pre.innerHTML = renderJson(_cachedJsonData, livePending);

  const cameras = _cachedJsonData?.cameras || {};
  let dirty = false;
  outer: for (const [c, vals] of Object.entries(livePending)) {
    for (const field of ['pitch', 'yaw', 'roll']) {
      if (Math.abs((cameras[c]?.[field]?.value ?? vals[field]) - vals[field]) > 1e-9) {
        dirty = true; break outer;
      }
    }
  }
  badge.classList.toggle('visible', dirty);
}

/** Fetch sensors JSON from server and render it. */
export async function refreshJsonViewer() {
  const pre = $('json-pre');
  if (!_cachedJsonData) pre.innerHTML = `<span class="json-muted">Loading…</span>`;
  try {
    const result = await fetchApi('/api/sensors_json');
    if (result.detail || !result.data) {
      _cachedJsonData = null;
      _cachedPending = {};
      pre.innerHTML = `<span class="json-muted">${esc(result.detail || 'No data')}</span>`;
      return;
    }
    _cachedJsonData = result.data;
    _cachedPending = result.pending || {};
    applyJsonRender();
  } catch (e) {
    _cachedJsonData = null;
    _cachedPending = {};
    pre.innerHTML = `<span class="json-error">Failed to load JSON</span>`;
  }
}

/** Reset all viewer state (call on recording load). */
export function resetViewer() {
  _hasImage = false;
  _cachedJsonData = null;
  _cachedPending = {};
  scale = 1; tx = 0; ty = 0;
  $('img-mixed').removeAttribute('src');
  applyTransform();
  $('zoom-container').style.display = '';
  $('ph-mixed').style.display = '';
}

/** Clear only the JSON cache (call after save). */
export function clearJsonCache() {
  _cachedJsonData = null;
}
