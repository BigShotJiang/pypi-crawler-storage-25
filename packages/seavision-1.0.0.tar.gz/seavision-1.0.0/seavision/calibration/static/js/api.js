/** DOM shorthand. */
export const $ = (id) => document.getElementById(id);

/** Update the status bar dot + text. */
export function setStatus(msg, type = '') {
  const dot = $('status-dot');
  const txt = $('status-text');
  txt.textContent = msg;
  txt.className = type;
  dot.className = 'status-dot' + (type ? ' ' + type : '');
}

/** Fetch JSON from a local API path. Throws on network/HTTP/parse errors. */
export async function api(path) {
  let r;
  try {
    r = await fetch(path);
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    throw new Error(`Fetch failed: ${msg}`);
  }
  const text = await r.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (_parseErr) {
    const preview = text.length > 240 ? text.slice(0, 240) + '…' : text;
    throw new Error(
      `Invalid JSON (HTTP ${r.status} ${r.statusText}): ${preview || '(empty body)'}`
    );
  }
  if (!r.ok) {
    const detail =
      data && typeof data === 'object' && data.detail !== undefined
        ? String(data.detail)
        : (text || `${r.status} ${r.statusText}`);
    throw new Error(`HTTP ${r.status} ${r.statusText}: ${detail}`);
  }
  return data;
}

/** HTML-escape a string for safe insertion into innerHTML. */
export function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Active camera id for process / JSON / reset (replaces former #camera-select value). */
let _selectedCamera = '';
export function getSelectedCamera() {
  return _selectedCamera;
}
export function setSelectedCamera(id) {
  _selectedCamera = id ? String(id) : '';
}
