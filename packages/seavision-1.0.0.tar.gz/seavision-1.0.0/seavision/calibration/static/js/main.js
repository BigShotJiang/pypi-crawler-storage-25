import { $, api, setStatus, esc, getSelectedCamera, setSelectedCamera } from './api.js';
import { updateSliderFill, setSlider, sliderVal, resetSliders } from './controls.js';
import {
  initZoom, showImage, switchView, getActiveView,
  applyJsonRender, refreshJsonViewer, resetViewer, clearJsonCache,
} from './viewer.js';
import { initBrowser } from './browser.js';

// ── Debounced auto-process ────────────────────────────────────────────────────
let _debounceTimer = null;

function scheduleProcess() {
  clearTimeout(_debounceTimer);
  _debounceTimer = setTimeout(runProcess, 250);
}

// ── Process ───────────────────────────────────────────────────────────────────
let _inflight = false;
let _pending = false;
let _sessionId = 0;

async function runProcess() {
  const camera = getSelectedCamera();
  if (!camera) return;
  if (_inflight) { _pending = true; return; }
  _inflight = true;
  const session = _sessionId;
  setStatus('Processing…', 'loading');
  const p = sliderVal('pitch'), y = sliderVal('yaw'), r = sliderVal('roll'), w = sliderVal('weight');
  try {
    const data = await api(`/api/process?pitch=${p}&yaw=${y}&roll=${r}&weight=${w}`);
    if (session !== _sessionId) return;
    showImage('mixed', data.mixed);
    setStatus('Done', 'ok');
  } catch (err) {
    if (session !== _sessionId) return;
    const msg = err && err.message ? err.message : 'Network or server error';
    setStatus(msg, 'error');
  } finally {
    if (session === _sessionId) {
      _inflight = false;
      if (_pending) { _pending = false; runProcess(); }
      else if (getActiveView() === 'json') refreshJsonViewer();
    }
  }
}

const TOOLBAR_CAMERA_ICON =
  '<svg class="toolbar-camera-btn-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
  '<path d="M15 7.5V6a1.5 1.5 0 00-1.5-1.5h-7A1.5 1.5 0 005 6v12a1.5 1.5 0 001.5 1.5h7A1.5 1.5 0 0015 18v-1.5l4.5 2.7A1 1 0 0021 18.3V5.7a1 1 0 00-1.5-.9L15 7.5z" ' +
  'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';

function syncCameraRadios(selectedId) {
  const root = $('camera-buttons-root');
  if (!root) return;
  root.querySelectorAll('button.toolbar-camera-btn[role="radio"]').forEach(btn => {
    const on = btn.dataset.camera === selectedId;
    btn.setAttribute('aria-checked', String(on));
  });
}

function renderCameraButtons(cameras) {
  const root = $('camera-buttons-root');
  if (!root) return;
  root.querySelectorAll('button.toolbar-camera-btn[role="radio"]').forEach(el => el.remove());
  if (cameras.length > 0) {
    root.setAttribute('role', 'radiogroup');
  } else {
    root.setAttribute('role', 'group');
  }
  cameras.forEach(id => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'toolbar-camera-btn';
    btn.setAttribute('role', 'radio');
    btn.dataset.camera = id;
    btn.setAttribute('aria-checked', 'false');
    btn.innerHTML =
      `${TOOLBAR_CAMERA_ICON}<span class="toolbar-camera-btn-label">${esc(id)}</span>`;
    btn.addEventListener('click', async () => {
      if (getSelectedCamera() === id) return;
      _sessionId++;
      setSelectedCamera(id);
      syncCameraRadios(id);
      await selectCameraSource(id);
    });
    root.appendChild(btn);
  });
}

function setCameraStripIdle() {
  const dummy = $('camera-strip-dummy');
  const root = $('camera-buttons-root');
  renderCameraButtons([]);
  syncCameraRadios('');
  if (dummy) dummy.hidden = false;
  if (root) root.setAttribute('role', 'group');
}

function setCameraStripActive() {
  const dummy = $('camera-strip-dummy');
  if (dummy) dummy.hidden = true;
}

/** Fetch cameras after a recording is loaded; populate buttons (returns ids). */
async function fetchCamerasAfterRecording() {
  const data = await api('/api/camera_sources');
  const cameras = data.cameras || [];
  renderCameraButtons(cameras);
  return cameras;
}

/** Load server state for one camera and run process. */
async function selectCameraSource(camera) {
  if (!camera) return;
  const session = _sessionId;
  setStatus('Loading camera…', 'loading');
  try {
    const data = await api(`/api/select_camera_source?camera=${encodeURIComponent(camera)}`);
    if (session !== _sessionId || getSelectedCamera() !== camera) return;
    const v = data.values;
    setSlider('pitch', v.pitch);
    setSlider('yaw', v.yaw);
    setSlider('roll', v.roll);
    setStatus(`Camera ${camera} loaded`, 'ok');
    runProcess();
  } catch (err) {
    if (session !== _sessionId || getSelectedCamera() !== camera) return;
    setStatus(err.message, 'error');
  }
}

// ── Load recording ────────────────────────────────────────────────────────────
async function loadRecording() {
  const path = $('recording-path').value.trim();
  if (!path) return;
  _sessionId++;
  _inflight = false;
  _pending = false;
  setStatus('Loading recording…', 'loading');
  try {
    await api(`/api/load_recording?path=${encodeURIComponent(path)}`);
  } catch (err) {
    setStatus(err.message, 'error');
    return;
  }

  $('recording-slot').classList.add('recording-slot--loaded');
  $('recording-path').value = path;

  resetViewer();
  resetSliders();

  setStatus('Recording loaded', 'ok');
  setCameraStripActive();
  const cameras = await fetchCamerasAfterRecording();
  if (cameras.length > 0) {
    setSelectedCamera(cameras[0]);
    syncCameraRadios(cameras[0]);
    await selectCameraSource(cameras[0]);
  }
}

// ── Event wiring ──────────────────────────────────────────────────────────────

// Slider fill init + input sync
document.querySelectorAll('input[type=range]').forEach(el => {
  updateSliderFill(el);
  el.addEventListener('input', () => updateSliderFill(el));
});

function setupSliderListeners(id) {
  $(id).addEventListener('input', () => {
    $(`${id}-num`).value = parseFloat($(id).value).toFixed(2);
    updateSliderFill($(id));
    if (getActiveView() === 'json') applyJsonRender();
    scheduleProcess();
  });
  $(`${id}-num`).addEventListener('input', () => {
    const raw = parseFloat($(`${id}-num`).value);
    if (isNaN(raw)) return;
    const min = parseFloat($(`${id}-num`).min);
    const max = parseFloat($(`${id}-num`).max);
    const clamped = Math.min(max, Math.max(min, raw));
    $(id).value = clamped;
    $(`${id}-num`).value = clamped.toFixed(2);
    updateSliderFill($(id));
    if (getActiveView() === 'json') applyJsonRender();
    scheduleProcess();
  });
}

['pitch', 'yaw', 'roll', 'weight'].forEach(id => {
  setupSliderListeners(id);
});

// +/− buttons
document.querySelectorAll('.num-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const id = btn.dataset.target;
    const dir = parseFloat(btn.dataset.dir);
    const step = parseFloat($(id).step) || 0.01;
    const min = parseFloat($(`${id}-num`).min);
    const max = parseFloat($(`${id}-num`).max);
    const cur = parseFloat($(id).value);
    const next = Math.min(max, Math.max(min, Math.round((cur + dir * step) / step) * step));
    $(id).value = next;
    $(`${id}-num`).value = next.toFixed(2);
    updateSliderFill($(id));
    if (getActiveView() === 'json') applyJsonRender();
    scheduleProcess();
  });
});

// Reset + Save
$('btn-reset').addEventListener('click', async () => {
  const camera = getSelectedCamera();
  if (!camera) { setStatus('Select a camera first', 'error'); return; }
  try {
    const data = await api(`/api/reset_camera?camera=${encodeURIComponent(camera)}`);
    setSlider('pitch', data.values.pitch);
    setSlider('yaw', data.values.yaw);
    setSlider('roll', data.values.roll);
    setStatus('Reset to original values', 'ok');
    runProcess();
  } catch (err) {
    setStatus(err.message, 'error');
  }
});

$('btn-save').addEventListener('click', async () => {
  setStatus('Saving…', 'loading');
  try {
    await api('/api/save_sensors_json');
    setStatus('Saved · original backed up as original_sentry_sensors.json', 'ok');
    if (getActiveView() === 'json') {
      clearJsonCache();
      setTimeout(refreshJsonViewer, 300);
    }
  } catch (err) {
    setStatus(err.message, 'error');
  }
});

// Recording
$('recording-path').addEventListener('keydown', e => { if (e.key === 'Enter') loadRecording(); });

// View tabs
$('tab-image').addEventListener('click', () => switchView('image'));
$('tab-json').addEventListener('click', () => switchView('json'));

// Zoom
initZoom();

// ── Theme switcher ────────────────────────────────────────────────────────────
function setTheme(pref) {
  localStorage.setItem('sea-theme', pref);
  const resolved = pref === 'system'
    ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
    : pref;
  document.documentElement.dataset.theme = resolved;
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === pref);
  });
}

// Init from saved preference
setTheme(localStorage.getItem('sea-theme') || 'dark');

// React to OS theme changes when in system mode
matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => {
  if (localStorage.getItem('sea-theme') === 'system') setTheme('system');
});

// Button clicks
document.querySelectorAll('.theme-btn').forEach(btn => {
  btn.addEventListener('click', () => setTheme(btn.dataset.theme));
});

// Boot — cameras only after a recording is loaded
setCameraStripIdle();
initBrowser();
