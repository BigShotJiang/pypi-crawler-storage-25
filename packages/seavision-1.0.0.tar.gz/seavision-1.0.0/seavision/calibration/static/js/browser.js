import { $, api, setStatus } from './api.js';

const STORAGE_KEY = 'sea-browse-path';

let _isOpen = false;

function _panel() { return document.getElementById('browser-panel'); }

function _esc(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function _render(data) {
  localStorage.setItem(STORAGE_KEY, data.path);

  // Breadcrumb: build segments relative to the server root so we never
  // generate data-path values above the allowed tree.
  const root = data.root || '/';
  const rootNorm = root.replace(/\/$/, '');
  const suffix = data.path.startsWith(rootNorm) ? data.path.slice(rootNorm.length) : '';
  const segs = suffix.split('/').filter(Boolean);
  const crumbHtml = [`<span class="browser-crumb" role="button" tabindex="0" data-path="${_esc(root)}">~</span>`]
    .concat(
      segs.map((seg, i) => {
        const p = rootNorm + '/' + segs.slice(0, i + 1).join('/');
        return `<span class="browser-sep">/</span><span class="browser-crumb" role="button" tabindex="0" data-path="${_esc(p)}">${_esc(seg)}</span>`;
      })
    )
    .join('');
  const breadcrumb = document.getElementById('browser-breadcrumb');
  breadcrumb.innerHTML = crumbHtml;
  breadcrumb.querySelectorAll('.browser-crumb').forEach(el => {
    el.addEventListener('click', () => _navigate(el.dataset.path));
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); _navigate(el.dataset.path); }
    });
  });

  // Entry list
  const folderSvg = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M1 3A1 1 0 0 1 2 2H5.5l1 1.5H12a1 1 0 0 1 1 1V11a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V3z" stroke="currentColor" stroke-width="1.3" fill="none"/></svg>`;
  const backSvg = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M9 2L4 7l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`;

  // Only show "Parent folder" when still inside the allowed root.
  const canGoUp = data.path !== data.parent && data.path !== root && data.path !== rootNorm;
  const parentRow = canGoUp
    ? `<div class="browser-entry browser-entry--parent" role="button" tabindex="0" data-path="${_esc(data.parent)}">${backSvg}<span class="browser-entry-name">Parent folder</span></div>`
    : '';

  const entryRows = data.entries.map(e => {
    const fullPath = data.path.replace(/\/$/, '') + '/' + e.name;
    const cls = e.is_recording ? 'browser-entry browser-entry--recording' : 'browser-entry';
    const badge = e.is_recording ? '<span class="browser-rec-badge">REC</span>' : '';
    return `<div class="${cls}" role="button" tabindex="0" data-path="${_esc(fullPath)}" data-recording="${e.is_recording}">${folderSvg}<span class="browser-entry-name">${_esc(e.name)}</span>${badge}</div>`;
  }).join('');

  const list = document.getElementById('browser-list');
  list.innerHTML = parentRow + entryRows;
  list.querySelectorAll('.browser-entry').forEach(el => {
    const activate = () => {
      if (el.dataset.recording === 'true') {
        _select(el.dataset.path);
      } else {
        _navigate(el.dataset.path);
      }
    };
    el.addEventListener('click', activate);
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(); }
    });
  });
}

async function _navigate(path) {
  try {
    const data = await api(`/api/browse?path=${encodeURIComponent(path)}`);
    _render(data);
  } catch (err) {
    setStatus(err.message, 'error');
    throw err;
  }
}

function _select(path) {
  $('recording-path').value = path;
  _close();
}

function _outsideClick(e) {
  if (!_panel().contains(e.target) && !e.target.closest('#btn-browse')) {
    _close();
  }
}

function _close() {
  if (!_isOpen) return;
  _isOpen = false;
  _panel().hidden = true;
  $('btn-browse').setAttribute('aria-expanded', 'false');
  document.removeEventListener('mousedown', _outsideClick);
}

async function _open() {
  if (_isOpen) { _close(); return; }
  _isOpen = true;
  _panel().hidden = false;
  $('btn-browse').setAttribute('aria-expanded', 'true');
  document.addEventListener('mousedown', _outsideClick);
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      await _navigate(saved);
    } catch {
      localStorage.removeItem(STORAGE_KEY);
      const root = await api('/api/browse_root');
      await _navigate(root.path);
    }
  } else {
    const root = await api('/api/browse_root');
    await _navigate(root.path);
  }
}

export function initBrowser() {
  $('btn-browse').addEventListener('click', _open);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && _isOpen) _close();
  });
}
