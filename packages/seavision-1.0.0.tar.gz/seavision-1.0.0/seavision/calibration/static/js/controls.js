import { $ } from './api.js';

/** Update a range input's fill gradient to reflect its current value. */
export function updateSliderFill(el) {
  const min = parseFloat(el.min), max = parseFloat(el.max), val = parseFloat(el.value);
  const pct = ((val - min) / (max - min)) * 100;
  el.style.setProperty('--slider-progress', `${pct}%`);
}

/** Set a slider + its paired number input to a value, and update the fill. */
export function setSlider(id, value) {
  const rangeEl = $(id);
  const min = parseFloat(rangeEl.min);
  const max = parseFloat(rangeEl.max);
  const v = Math.min(max, Math.max(min, parseFloat(value)));
  rangeEl.value = v;
  $(`${id}-num`).value = v.toFixed(2);
  updateSliderFill(rangeEl);
}

/** Read the current float value of a range slider. */
export function sliderVal(id) {
  return parseFloat($(id).value);
}

/** Reset all calibration sliders to their default values. */
export function resetSliders() {
  setSlider('pitch', 0);
  setSlider('yaw', 0);
  setSlider('roll', 0);
  setSlider('weight', 0.5);
}
