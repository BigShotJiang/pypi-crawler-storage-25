# Online Calibration

A local web tool for manually calibrating Sentry camera homography by adjusting pitch, yaw, and roll angles and visually inspecting the overlay against the RGB reference frame.

## Usage

```bash
uv run -m seavision.calibration
uv run -m seavision.calibration --recording /path/to/Sentry_recordings_2024_03_12_10_34_06
uv run -m seavision.calibration --port 8323 --dry-run
```

Then open http://localhost:8323 in a browser.

## Arguments

| Argument | Default | Description |
|---|---|---|
| `--recording` | — | Path to a Sentry recording directory. Optional — can also be set via the UI. |
| `--port` | `8323` | Port to listen on. |
| `--host` | `0.0.0.0` | Host / IP to bind (`0.0.0.0` = all interfaces). |
| `--dry-run` | `false` | Print calibration changes to terminal instead of writing to `sentry_sensors.json`. |

## UI

- **Recording** — paste a path or use the text input to load a recording directory
- **Angles** — adjust pitch, yaw, roll for the selected camera; the overlay updates live
- **Blend** — control the mix weight between the source and reference frame
- **JSON tab** — toggle between the image overlay and a live view of `sentry_sensors.json`; changed values are highlighted in red
- **Save** — writes updated values to `sentry_sensors.json`; the original is preserved as `original_sentry_sensors.json`

## Structure

```
seavision/calibration/
  __main__.py    Entry point
  server.py      FastAPI server and API endpoints
  utils.py       Recording loading, frame extraction, homography processing
  static/
    index.html   Single-page UI
```
