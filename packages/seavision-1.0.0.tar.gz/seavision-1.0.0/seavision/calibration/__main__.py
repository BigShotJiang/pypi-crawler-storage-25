"""Entry point for the Sentry homography calibration web server.

Usage:
    uv run -m seavision.calibration
    uv run -m seavision.calibration --recording /path/to/Sentry_2024_03_12_10_34_06
    uv run -m seavision.calibration --port 8323 --host 127.0.0.1 --dry-run
"""

import argparse

from seavision.calibration.server import run_web_server

parser = argparse.ArgumentParser(description="Sentry homography calibration server")
parser.add_argument(
    "--recording",
    default=None,
    help="Path to a Sentry recording directory (optional — can be set in the UI)",
)
parser.add_argument(
    "--port", type=int, default=8323, help="Port to listen on (default: 8323)"
)
parser.add_argument(
    "--host",
    default="0.0.0.0",
    help="Host / IP to bind (default: 0.0.0.0 — all interfaces)",
)
parser.add_argument(
    "--reference-camera",
    default=None,
    help="Master view to project sources into (default: t_w)",
)
parser.add_argument(
    "--dry-run",
    action="store_true",
    help="Print changes instead of writing to sentry_sensors.json",
)
args = parser.parse_args()

run_web_server(
    args.recording,
    args.port,
    host=args.host,
    dry_run=args.dry_run,
    reference_camera=args.reference_camera,
)
