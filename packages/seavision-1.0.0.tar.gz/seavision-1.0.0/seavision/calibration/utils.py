"""Utility functions for Sentry homography calibration tool."""

import base64
import json
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np

from seavision.geometry.pinhole import CameraGeometry
from seavision.io.video import VideoReader
from seavision.transforms.compose import ThermalTransform

from .parsers import CalibrationData

CAMERA_PATTERNS = {
    "t_w": "*TwFoV*record*.avi",
    "t_n": "*TnFoV*record*.avi",
    "rgb_w": "*RGBwFoV*record*.avi",
    "rgb_n": "*RGBnFoV*record*.avi",
}

THERMAL_CAMERAS = {"t_w", "t_n"}

# Master view to project sources into. Change here, or pass ``--reference-camera`` to
# ``seavision calibration`` (no hot-swap in the web UI).
DEFAULT_REFERENCE_CAMERA: str = "t_w"

# Supersample warp output: H' = diag(s,s,1) @ H with larger dsize (sharper than
# upscaling after warp). Does not change saved calibration.
WARP_SUPERSAMPLE: int = 2


def source_cameras_for_reference(reference: str) -> List[str]:
    """Stream ids that can be used as calibration sources (all except ``reference``)."""
    if reference not in CAMERA_PATTERNS:
        raise ValueError(
            f"Unknown camera {reference!r}; expected one of: {sorted(CAMERA_PATTERNS)}"
        )
    return [c for c in CAMERA_PATTERNS if c != reference]


def _warp_supersampled(
    source_frame: np.ndarray,
    H: np.ndarray,
    master_frame: np.ndarray,
) -> tuple:
    """Warp source into master's frame with optional supersampling."""
    h, w = master_frame.shape[:2]
    s = max(1, int(WARP_SUPERSAMPLE))
    out_size = (w * s, h * s)
    if s > 1:
        H = np.diag([float(s), float(s), 1.0]) @ H
    projected = cv2.warpPerspective(
        source_frame, H.astype(np.float32), out_size, flags=cv2.INTER_LANCZOS4
    )
    master_s = (
        cv2.resize(master_frame, out_size, interpolation=cv2.INTER_LANCZOS4)
        if s > 1
        else master_frame
    )
    return projected, master_s


def get_available_recordings(base_path: str) -> List[str]:
    """Return subdirectory names that contain POWER_Const/sentry_sensors.json."""
    base = Path(base_path)
    recordings = []
    for subdir in sorted(base.iterdir()):
        if (
            subdir.is_dir()
            and (subdir / "POWER_Const" / "sentry_sensors.json").exists()
        ):
            recordings.append(subdir.name)
    return recordings


def get_video_path(recording_path: str, camera_name: str) -> Optional[Path]:
    """Return the path to the AVI file for the given camera, or None if not found."""
    pattern = CAMERA_PATTERNS.get(camera_name)
    if pattern is None:
        return None
    matches = list(Path(recording_path).glob(pattern))
    return matches[0] if matches else None


def load_sentry_config(
    recording_path: str,
    reference_camera: Optional[str] = None,
) -> CalibrationData:
    """Load sentry_sensors.json and parse into calibration data.

    ``reference_camera`` must have a matching video under ``recording_path`` (used as
    the master view). Defaults to :data:`DEFAULT_REFERENCE_CAMERA`.
    """
    ref = reference_camera or DEFAULT_REFERENCE_CAMERA
    if ref not in CAMERA_PATTERNS:
        raise ValueError(f"Unknown reference camera {ref!r}")

    json_path = Path(recording_path) / "POWER_Const" / "sentry_sensors.json"
    with json_path.open(encoding="utf-8") as f:
        raw = json.load(f)

    backup_path = json_path.with_name("original_sentry_sensors.json")
    if not backup_path.exists():
        with backup_path.open("w", encoding="utf-8") as f:
            json.dump(raw, f, indent=2)

    ref_video = get_video_path(recording_path, ref)
    if ref_video is None:
        raise FileNotFoundError(f"No {ref} video found in {recording_path}")

    return CalibrationData.from_json(json_path)


def load_first_frames(recording_path: str) -> Dict[str, np.ndarray]:
    """Load the first frame from each camera's AVI file as uint8 RGB."""
    thermal_transform = ThermalTransform()
    frames = {}
    for camera_name in CAMERA_PATTERNS:
        video_path = get_video_path(recording_path, camera_name)
        if video_path is None:
            continue
        reader = VideoReader(str(video_path))
        try:
            try:
                frame = next(iter(reader))
            except StopIteration:
                raise ValueError(f"{video_path}: video contains no frames") from None
        finally:
            reader.close()
        if camera_name in THERMAL_CAMERAS:
            frame = thermal_transform.apply(frame)
            gray = frame[:, :, 0]
            frame = cv2.cvtColor(
                cv2.applyColorMap(gray, cv2.COLORMAP_INFERNO), cv2.COLOR_BGR2RGB
            )
        frames[camera_name] = frame
    return frames


def blend_rgb(a: np.ndarray, b: np.ndarray, weight: float) -> np.ndarray:
    """Blend two RGB images: weight * a + (1 - weight) * b, returned as RGB."""
    return cv2.addWeighted(a, weight, b, 1 - weight, 0)


def process_calibration(
    sentry: CalibrationData,
    frames: Dict[str, np.ndarray],
    source_name: str,
    pitch: float,
    yaw: float,
    roll: float,
    weight: float,
    reference_camera: Optional[str] = None,
) -> Dict[str, np.ndarray]:
    """Warp the source camera onto the reference (master) view and blend."""
    ref = reference_camera or DEFAULT_REFERENCE_CAMERA
    allowed = source_cameras_for_reference(ref)
    if source_name == ref:
        raise ValueError("source_name and reference_camera must differ")
    if source_name not in allowed:
        raise ValueError(
            f"Invalid source {source_name!r} for reference {ref!r}; allowed: {allowed}"
        )

    master_cam = CameraGeometry.crop_to_frame(sentry.cameras[ref], frames[ref])
    source_cam = CameraGeometry.crop_to_frame(
        sentry.cameras[source_name].with_extrinsics(roll=roll, pitch=pitch, yaw=yaw),
        frames[source_name],
    )
    H = CameraGeometry.compute_homography(source_cam, master_cam).astype(np.float64)
    projected, master_s = _warp_supersampled(frames[source_name], H, frames[ref])
    return {
        "master": master_s,
        "projected": projected,
        "mixed": blend_rgb(master_s, projected, weight),
    }


def image_to_base64(img_rgb: np.ndarray) -> str:
    """Encode an RGB image as a base64 JPEG string."""
    img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)
    _, buf = cv2.imencode(".jpg", img_bgr)
    return base64.b64encode(buf.tobytes()).decode("utf-8")


def read_sensors_json(recording_path: str) -> Dict:
    """Return the raw sentry_sensors.json data."""
    json_path = Path(recording_path) / "POWER_Const" / "sentry_sensors.json"
    with json_path.open(encoding="utf-8") as f:
        return json.load(f)


def update_sensors_json(
    recording_path: str,
    updates: Dict[str, Dict[str, float]],
) -> None:
    """Update pitch/yaw/roll for one or more cameras in a single read+write."""
    json_path = Path(recording_path) / "POWER_Const" / "sentry_sensors.json"
    try:
        with json_path.open(encoding="utf-8") as f:
            data = json.load(f)

        cameras = data.get("cameras")
        if not isinstance(cameras, dict):
            raise ValueError(
                f"{json_path}: expected a dict at key 'cameras', found "
                f"{type(cameras).__name__!r}"
            )

        for camera_name in updates:
            if camera_name not in cameras:
                raise ValueError(
                    f"{json_path}: camera {camera_name!r} is not present under "
                    "'cameras'"
                )

        for camera_name, values in updates.items():
            cam = cameras[camera_name]
            if not isinstance(cam, dict):
                raise ValueError(
                    f"{json_path}: camera {camera_name!r} must be an object, found "
                    f"{type(cam).__name__!r}"
                )
            for axis in ("pitch", "yaw", "roll"):
                entry = cam.get(axis)
                if not isinstance(entry, dict):
                    cam[axis] = {}
                cam[axis].setdefault("value", 0.0)
            cam["pitch"]["value"] = values["pitch"]
            cam["yaw"]["value"] = values["yaw"]
            cam["roll"]["value"] = values["roll"]

        with json_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(
            f"{json_path}: unexpected error while updating sensors JSON: {e}"
        ) from e
