<div align="center">
  <img width="940" alt="image" src="./docs/assets/banner.png">

  [![CI](https://github.com/SEA-AI/seavision/actions/workflows/ci.yaml/badge.svg)](https://github.com/SEA-AI/seavision/actions/workflows/ci.yaml)
</div>

## <div align="center">🚀 Quick Start</div>

```bash
pip install git+https://github.com/SEA-AI/seavision
```

<details close>
<summary>Optional installation methods</summary>

If you want to install additional dependencies.
```bash
pip install "seavision[inference] @ git+https://github.com/SEA-AI/seavision"
```

If you want to test a specific branch
```bash
pip install git+https://github.com/SEA-AI/seavision@branch-name
```
</details>


```python
import seavision as sv

# load image
img = sv.imread("https://raw.githubusercontent.com/SEA-AI/.github/main/assets/example_1_IR.jpg")
# load model trained on mixed IR and RGB images
model = sv.load_model("ahoyv2n-MIX-b1")
# run inference
results = model(img)
# draw results on image
results.draw(img, as_pil=True).show()
```

![inference-output](./docs/assets/inference-output.png)

## <div align="center">💪 Contributing</div>

Contributions are welcome! Please open an issue or submit a pull request.

[Install uv](https://docs.astral.sh/uv/getting-started/installation/) if you don't have it yet and run the following command to install the main and development dependencies.
```bash
uv sync
```

If you want to install all dependencies.
```bash
uv sync --all-extras
```

- **Pre-commit Hooks:** Use [pre-commit hooks](https://pre-commit.com/) to maintain code quality.
- **Style Guide:** Follow guidelines enforced via `ruff` and run checks before committing.

1. Install pre-commit hooks:

```bash
uvx pre-commit install
```

2. Run Ruff for linting and auto-fixes:

```bash
uvx ruff check --fix
```

3. Add dependencies using UV:

```bash
uv add <package-name>
uv add <package-name>@<version>
uv sync  # Syncs dependencies from pyproject.toml
