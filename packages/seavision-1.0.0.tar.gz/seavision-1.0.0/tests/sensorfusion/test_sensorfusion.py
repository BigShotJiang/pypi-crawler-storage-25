import math
from dataclasses import asdict

import numpy as np
import pytest


def compare_results(result1, result2, rel_tol=1e-5, abs_tol=1e-8):
    """Recursively compare two Results objects with a tolerance for floating-point values."""
    dict1, dict2 = asdict(result1), asdict(result2)

    def compare_values(val1, val2):
        if isinstance(val1, float) and isinstance(val2, float):
            return math.isclose(val1, val2, rel_tol=rel_tol, abs_tol=abs_tol)
        if isinstance(val1, list) and isinstance(val2, list):
            return all(compare_values(v1, v2) for v1, v2 in zip(val1, val2))
        if isinstance(val1, dict) and isinstance(val2, dict):
            return all(compare_values(val1[k], val2[k]) for k in val1 if k in val2)
        return val1 == val2  # Compare non-float values directly

    return compare_values(dict1, dict2)


@pytest.mark.parametrize(
    ("expected_box_types", "nms_fusion"), [(True, True), (False, False)], indirect=True
)
def test_from_results(nms_fusion, sample_results, expected_box_types):
    """Test NMS fusion results in class-agnostic and class-aware modes."""
    boxes, scores, labels = nms_fusion.from_results(sample_results)

    assert len(boxes) == len(
        expected_box_types["boxes"]
    ), "Mismatch in number of elements"
    assert len(scores) == len(
        expected_box_types["scores"]
    ), "Mismatch in number of elements"
    assert len(labels) == len(
        expected_box_types["labels"]
    ), "Mismatch in number of elements"

    for b, be in zip(boxes, expected_box_types["boxes"]):
        np.testing.assert_allclose(b, be, rtol=1e-5, atol=1e-8)

    for s, se in zip(scores, expected_box_types["scores"]):
        np.testing.assert_allclose(s, se, rtol=1e-5, atol=1e-8)

    for l, le in zip(labels, expected_box_types["labels"]):
        assert l == le, f"Labels mismatch: {l} != {le}"


@pytest.mark.parametrize(
    ("expected_results", "nms_fusion"), [(True, True), (False, False)], indirect=True
)
def test_to_results(nms_fusion, sample_results, expected_results):
    """Test NMS fusion results in class-agnostic and class-aware modes."""
    nms_fusion._setup_fusion(sample_results)
    boxes, scores, labels = nms_fusion.from_results(sample_results)

    # Fake fusion results by assuming just the first object is kept
    boxes = boxes[0]
    scores = scores[0]
    labels = labels[0]

    results = nms_fusion.to_results((boxes, scores, labels))

    assert compare_results(results, expected_results)
