"""Pytest fixtures for sensorfusion tests."""

import pytest

from seavision.inference.results import BBox, Horizon, Line, Object, Results
from seavision.sensorfusion.nms import NMS, NMSParams


@pytest.fixture
def expected_results(request):
    """Fixture to provide expected results, influenced by the class_agnostic parameter."""
    class_agnostic = request.param

    expected_results = Results(
        objects=[
            Object(
                bbox=BBox(
                    xywh=[724.423828125, 477.61328125, 7.15234375, 7.7734375],
                    xywh_n=[
                        0.6036865234375,
                        0.49751383463541665,
                        0.0059602864583332416,
                        0.00809733072916674,
                    ],
                ),
                score=0.1988525390625,
                class_name="OBJECT" if class_agnostic else "FAR_AWAY_OBJECT",
                class_id=0 if class_agnostic else 7,
            ),
            Object(
                bbox=BBox(
                    xywh=[615.421875, 459.43749999999994, 62.15625, 30.125000000000114],
                    xywh_n=[
                        0.5128515625,
                        0.4785807291666666,
                        0.051796874999999964,
                        0.03138020833333344,
                    ],
                ),
                score=0.923828125,
                class_name="OBJECT" if class_agnostic else "SHIP",
                class_id=0 if class_agnostic else 3,
            ),
        ],
        horizon=Horizon(
            line=Line(
                xyxy=[0.0, 498.62535892875763, 1200.0, 476.0032124998138],
                xyxy_n=[0.0, 0.5194014155507892, 1.0, 0.49583667968730605],
                rho=498.53677932087567,
                theta=1.5519467708733579,
                slope=-0.01885178869078653,
                intercept=498.62535892875763,
            ),
            score=0.27022719383239746,
            class_name="HORIZON",
            class_id=-1,
        ),
        image_width=1200,
        image_height=960,
    )

    return expected_results


@pytest.fixture
def expected_box_types(request):
    """Fixture to provide expected results, influenced by the class_agnostic parameter."""
    class_agnostic = request.param  # Retrieve parameter value

    boxes_expected = [
        [
            [
                0.6036865234375,
                0.4975138346354167,
                0.6096468098958332,
                0.5056111653645834,
            ],
            [0.5128515625, 0.47858072916666666, 0.5646484374999999, 0.5099609375],
        ],
        [
            [
                0.3323787434895834,
                0.50653076171875,
                0.3355379231770833,
                0.5111775716145832,
            ],
            [
                0.6040706380208334,
                0.49757690429687507,
                0.6092626953125,
                0.5045064290364584,
            ],
            [
                0.5123697916666667,
                0.4779052734375,
                0.5651302083333334,
                0.5106363932291667,
            ],
        ],
    ]

    scores_expected = [
        [0.1988525390625, 0.923828125],
        [0.342041015625, 0.453857421875, 0.94873046875],
    ]

    # Labels depend on class-agnostic mode
    labels_expected = [[0, 0], [0, 0, 0]] if class_agnostic else [[7, 3], [7, 7, 3]]

    return {
        "boxes": boxes_expected,
        "scores": scores_expected,
        "labels": labels_expected,
    }


@pytest.fixture
def nms_fusion(request):
    """Fixture to create NMS fusion object with class_agnostic parameter."""
    class_agnostic = request.param  # Retrieve parameter value

    nms_params = NMSParams(
        weights=[1, 1], iou_threshold=0.001, class_agnostic=class_agnostic
    )

    return NMS(nms_params)
