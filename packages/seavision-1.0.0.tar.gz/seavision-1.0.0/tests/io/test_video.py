"""Test the video functions for the io module."""

from unittest.mock import patch

import ffmpeg
import numpy as np
import pytest

from seavision.io.video import (
    Gray16AVIReader,
    Gray16VideoWriter,
    MP4Reader,
    MP4VideoWriter,
    RGBAVIReader,
    StreamReader,
    VideoFormatRegistry,
    VideoReader,
    VideoWriter,
    get_pixel_format,
)

# Create a mock registry for testing
mock_registry = VideoFormatRegistry()
mock_registry.register("avi", RGBAVIReader)  # Default AVI reader
mock_registry.register("avi", Gray16AVIReader, "gray16be")  # 16-bit infrared AVI
mock_registry.register("mp4", MP4Reader)  # MP4 videos
mock_registry.register("rtsp", StreamReader)  # RTSP streams
mock_registry.register("http", StreamReader)  # HTTP streams
mock_registry.register("https", StreamReader)  # HTTPS streams
mock_registry.register("webcam", StreamReader)  # Webcam devices
mock_registry.register("youtube", StreamReader)  # YouTube URLs


@pytest.mark.parametrize(
    "source, pix_fmt, expected_class",
    [
        # File extensions
        ("video.avi", "gray16be", Gray16AVIReader),
        ("video.avi", None, RGBAVIReader),
        ("video.avi", "unsupported_fmt", RGBAVIReader),
        ("video.mp4", None, MP4Reader),
        # Protocols and sources
        ("rtsp://example.com/stream", None, StreamReader),
        ("http://example.com/stream", None, StreamReader),
        ("https://example.com/stream", None, StreamReader),
        ("webcam:0", None, StreamReader),
        ("youtube:https://www.youtube.com/watch?v=example", None, StreamReader),
    ],
)
def test_registry_get_handler_valid(source, pix_fmt, expected_class):
    """Test valid selections for registry get_handler."""
    assert mock_registry.get_handler(source, pix_fmt) == expected_class


def test_registry_get_handler_invalid():
    """Test that an unsupported format raises ValueError."""
    with pytest.raises(
        ValueError,
        match="Unsupported combination",
    ):
        mock_registry.get_handler("video.mov", "gray16be")


@pytest.mark.parametrize(
    "probe_output, expected_format",
    [
        ({"streams": [{"codec_type": "video", "pix_fmt": "gray16be"}]}, "gray16be"),
        ({"streams": [{"codec_type": "video", "pix_fmt": "yuv420p"}]}, "yuv420p"),
        ({"streams": []}, None),  # No video stream
    ],
)
@patch("seavision.io.video.ffmpeg.probe")
def test_get_pixel_format(mock_probe, probe_output, expected_format):
    """Test pixel format detection with mocked ffmpeg.probe."""
    mock_probe.return_value = probe_output
    assert get_pixel_format("video.avi") == expected_format


@patch("seavision.io.video.ffmpeg.probe", side_effect=ffmpeg.Error("", b"", b""))
def test_get_pixel_format_error(mock_probe):
    """Test that get_pixel_format handles ffmpeg errors gracefully."""
    assert get_pixel_format("video.avi") is None


@pytest.mark.parametrize(
    "fname, pix_fmt, writer_cls, frame_shape, frame_dtype, reader_cls, expected_shape",
    [
        (
            "test_gray16be.avi",
            "gray16be",
            Gray16VideoWriter,
            (720, 1280),
            np.uint16,
            Gray16AVIReader,
            (720, 1280),
        ),
        (
            "test_rgbavi.avi",
            "rgb24",
            MP4VideoWriter,
            (720, 1280, 3),
            np.uint8,
            RGBAVIReader,
            (720, 1280, 3),
        ),
        (
            "test.mp4",
            "yuv420p",
            MP4VideoWriter,
            (720, 1280, 3),
            np.uint8,
            MP4Reader,
            (720, 1280, 3),
        ),
        (
            "test_odd.mp4",
            "yuv420p",
            MP4VideoWriter,
            (719, 1279, 3),
            np.uint8,
            MP4Reader,
            (718, 1278, 3),
        ),
        (
            "test_gray16be_odd.avi",
            "gray16be",
            Gray16VideoWriter,
            (721, 1281),
            np.uint16,
            Gray16AVIReader,
            (720, 1280),
        ),
    ],
)
def test_video_write_and_read(
    tmp_path,
    fname,
    pix_fmt,
    writer_cls,
    frame_shape,
    frame_dtype,
    reader_cls,
    expected_shape,
):
    """Writing and reading video files works correctly for different formats."""
    video_path = tmp_path / fname
    video_length = 10
    fps = 30

    # Create a VideoWriter
    writer = VideoWriter(
        str(video_path),
        fps=fps,
        frame_width=frame_shape[1],
        frame_height=frame_shape[0],
        pix_fmt=pix_fmt,
    )
    # check that the writer is of the correct class
    assert isinstance(writer.writer, writer_cls)

    # write 10 dummy frames
    frame = np.zeros(frame_shape, dtype=frame_dtype)
    for _ in range(video_length):
        writer.write(frame)
    writer.close()

    # Read the video back

    reader = VideoReader(str(video_path))
    assert isinstance(reader.reader, reader_cls)
    assert reader.width == expected_shape[1] and isinstance(reader.height, int)
    assert reader.height == expected_shape[0] and isinstance(reader.width, int)
    assert reader.fps == fps
    assert len(reader) == video_length

    read_frame = next(reader)
    assert read_frame.shape == expected_shape
    assert read_frame.dtype == frame_dtype
    assert np.array_equal(frame[: expected_shape[0], : expected_shape[1]], read_frame)

    reader.close()


@pytest.mark.parametrize(
    "source, expected_reader, height, width, fps",
    [
        (
            "https://streams.videolan.org/samples/MPEG-4/video.mp4",
            StreamReader,
            240,
            320,
            29.97,
        ),
    ],
)
def test_video_reader_with_streams(source, expected_reader, height, width, fps):
    """VideoReader correctly selects the appropriate reader class for streams."""
    reader = VideoReader(source)
    for frame in reader:  # noqa: B007
        break
    assert isinstance(reader.reader, expected_reader)
    assert isinstance(frame, np.ndarray)
    assert frame.shape == (height, width, 3)
    assert abs(reader.fps - fps) < 0.01  # Allow small floating point differences
    assert reader.height == height
    assert reader.width == width
    reader.close()


def test_video_reader_with_youtube():
    """VideoReader correctly selects the appropriate reader class for streams."""
    source = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    with patch("seavision.io.video.StreamReader.get_best_youtube_url") as mock_yt:
        # to avoid pytubefix.exceptions.BotDetection when running automated tests
        mock_yt.return_value = "https://streams.videolan.org/samples/MPEG-4/video.mp4"
        reader = VideoReader(source)
        assert isinstance(reader.reader, StreamReader)


@pytest.mark.parametrize(
    "source, expected_reader",
    [
        ("webcam:0", StreamReader),
        ("webcam", StreamReader),
        ("0", StreamReader),
    ],
)
def test_video_reader_with_webcam(source, expected_reader):
    with patch("cv2.VideoCapture") as mock_capture:
        reader = VideoReader(source)
        assert isinstance(reader.reader, expected_reader)
        mock_capture.assert_called_once_with(0)
        reader.close()


def test_video_reader_buffering_local_file(tmp_path):
    video_path = tmp_path / "test.mp4"
    writer = VideoWriter(str(video_path), fps=30, frame_width=1280, frame_height=720)
    for _ in range(5):
        writer.write(np.zeros((720, 1280, 3), dtype=np.uint8))
    writer.close()
    reader = VideoReader(str(video_path), buffer=True)
    assert reader.buffering
    for _ in reader:
        assert reader._running
    reader.close()
    assert not reader._running


def test_video_writer_write_bad_frame_shape(tmp_path):
    """Test that VideoWriter's write method raises ValueError for bad frame shapes."""
    correct_width, correct_height = 1280, 720
    video_path = tmp_path / "test.mp4"

    writer = VideoWriter(
        str(video_path),
        fps=30,
        frame_width=correct_width,
        frame_height=correct_height,
    )
    frame = np.zeros((correct_height // 2, correct_width // 2, 3), dtype=np.uint8)

    with pytest.raises(ValueError):
        writer.write(frame)
    writer.close()


def test_video_reader_file_not_found():
    with pytest.raises(FileNotFoundError):
        VideoReader("nonexistent.mp4")
