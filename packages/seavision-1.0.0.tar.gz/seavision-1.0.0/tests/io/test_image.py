"""Test image loading and processing."""

from unittest.mock import MagicMock, patch

import cv2
import numpy as np
import pytest

from seavision.io.image import imread, imwrite


@pytest.fixture
def sample_16bit_image():
    """Create a mock image (16-bit grayscale)."""
    return np.random.default_rng(0).integers(0, 65535, (100, 100), dtype=np.uint16)


@pytest.fixture
def sample_8bit_image():
    """Create a mock image (8-bit)."""
    return np.random.default_rng(0).integers(0, 255, (100, 100), dtype=np.uint8)


@pytest.fixture
def sample_rgb_image():
    """Create a mock image (3-channel 8-bit)."""
    return np.random.default_rng(0).integers(0, 255, (100, 100, 3), dtype=np.uint8)


@pytest.mark.parametrize(
    "backend, mock_fn, args, kwargs",
    [
        ("cv2", "cv2.imwrite", [], {}),
        ("pil", "PIL.Image.fromarray", [], {}),
    ],
)
def test_imwrite(tmp_path, backend, mock_fn, args, kwargs, sample_rgb_image):
    """Test `imwrite()` with different backends."""
    filepath = str(tmp_path / "image_8Bit.jpg")

    if backend == "pil":
        mock_image = MagicMock()  # ✅ Create a mock PIL Image object

        with patch("PIL.Image.fromarray", return_value=mock_image) as mock_fromarray:
            imwrite(filepath, sample_rgb_image, backend, *args, **kwargs)

            # ✅ Ensure `fromarray()` was called
            mock_fromarray.assert_called_once_with(sample_rgb_image)

            # ✅ Ensure `save()` was called on the mock PIL Image object
            mock_image.save.assert_called_once_with(filepath, *args, **kwargs)

    elif backend == "cv2":
        with patch(mock_fn) as mock_cv2:
            imwrite(filepath, sample_rgb_image, backend, *args, **kwargs)
            mock_cv2.assert_called_once_with(
                filepath, sample_rgb_image, *args, **kwargs
            )

    else:
        raise ValueError(f"Unsupported backend: {backend}")


def test_imwrite_exception():
    """Test `imwrite()` raises an exception for unsupported backends."""
    with pytest.raises(ValueError, match=r"Unsupported backend: .*torch.*"):
        imwrite("image_8Bit.jpg", sample_rgb_image, backend="torch")


@pytest.mark.parametrize(
    "filename, ndim, dtype",
    [
        ("sailing_tl_320.png", 2, np.uint16),
        ("sailing_rgb_640.jpg", 3, np.uint8),
        ("example_2_IR.jpg", 3, np.uint8),
    ],
)
def test_imread_with_url_images(filename, ndim, dtype):
    """Test `imread()` with a 16-bit image."""
    base_url = "https://raw.githubusercontent.com/SEA-AI/.github/main/assets"

    img_url = f"{base_url}/{filename}"
    img = imread(img_url)
    assert img.ndim == ndim
    if ndim == 3:
        assert img.shape[2] == 3
    assert img.dtype == dtype


def test_imread_returns_rgb_ordered_image(tmp_path):
    """Test `imread()` returns an RGB ordered image."""
    # Create a pure blue image directly instead of downloading
    # This avoids SSL errors and network dependencies
    img_path = str(tmp_path / "pure_blue.jpg")

    # Create a pure blue image (BGR format for OpenCV)
    blue_image_bgr = np.zeros((100, 100, 3), dtype=np.uint8)
    blue_image_bgr[:, :, 0] = 255  # Blue channel (BGR)

    # Save using cv2
    cv2.imwrite(img_path, blue_image_bgr)

    img = imread(img_path)
    R, G, B = img[..., 0], img[..., 1], img[..., 2]
    assert B.mean() > 250
    assert R.mean() < 10
    assert G.mean() < 10
