"""Basic tests for speedtest module."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from seavision.deployment.speedtest import (
    get_dummy_inputs,
    inference_loop,
    parse_args,
    run_speed_test,
)
from seavision.inference.infer_abc import IO, DimsOrder


@pytest.fixture
def mock_infer():
    """Create a mock Infer object with required attributes."""
    mock_infer = MagicMock()
    # Create mock inputs
    mock_infer.inputs = [
        IO(name="input1", shape=(1, 3, 224, 224), dtype="float32"),
    ]
    mock_infer.dims_order = DimsOrder(B=0, C=1, H=2, W=3)
    mock_infer.input_bs = 1
    return mock_infer


@pytest.fixture
def mock_model(mock_infer):
    """Create a mock Model object."""
    mock_model = MagicMock()
    mock_model.model = mock_infer

    # Create separate mock profiles with reset() method and t attribute
    mock_model.profiles = {}
    for name in ["preprocess", "inference", "postprocess"]:
        mock_profile = MagicMock()
        mock_profile.reset = MagicMock()
        mock_profile.t = 0.1  # 100ms total time
        mock_model.profiles[name] = mock_profile

    # MagicMock is callable by default, just configure return_value
    mock_model.return_value = None

    return mock_model


def test_parse_args_default():
    """Test parse_args with default values."""
    with patch("sys.argv", ["speedtest.py", "model.onnx"]):
        args = parse_args()
        assert args.model_name == "model.onnx"
        assert args.n == 100


def test_parse_args_with_n():
    """Test parse_args with custom n value."""
    with patch("sys.argv", ["speedtest.py", "model.onnx", "-n", "50"]):
        args = parse_args()
        assert args.model_name == "model.onnx"
        assert args.n == 50


def test_get_dummy_inputs(mock_model):
    """Test get_dummy_inputs generates correct dummy inputs."""
    inputs = get_dummy_inputs(mock_model)

    assert len(inputs) == 1
    assert isinstance(inputs[0], np.ndarray)
    assert inputs[0].shape == (224, 224, 3)  # H, W, C
    assert inputs[0].dtype == np.uint8


def test_get_dummy_inputs_shape(mock_model):
    """Test get_dummy_inputs generates inputs with correct shape."""
    inputs = get_dummy_inputs(mock_model)

    # Check shape matches expected dimensions
    assert inputs[0].ndim == 3  # HWC format
    assert inputs[0].shape[0] == 224  # Height
    assert inputs[0].shape[1] == 224  # Width
    assert inputs[0].shape[2] == 3  # Channels


def test_inference_loop(mock_model):
    """Test inference_loop runs for specified iterations."""
    n_iterations = 5

    inference_loop(mock_model, n_iterations)

    # Verify model was called n_iterations times
    assert mock_model.call_count == n_iterations

    # Verify profiles were reset (each profile.reset should be called once)
    for name, profile in mock_model.profiles.items():
        assert profile.reset.call_count == 1, (
            f"Profile '{name}' reset should be called once"
        )


def test_inference_loop_with_batch_size(mock_model):
    """Test inference_loop handles batch size correctly."""
    # Set batch size to 2
    mock_model.model.input_bs = 2

    inference_loop(mock_model, 3)

    # Model should be called
    assert mock_model.call_count == 3


@patch("seavision.deployment.speedtest.load_model")
def test_run_speed_test(mock_load_model, mock_model):
    """Test run_speed_test loads model and runs inference."""
    mock_load_model.return_value.__enter__.return_value = mock_model
    mock_load_model.return_value.__exit__.return_value = False

    run_speed_test("test_model.onnx", 10)

    # Verify model was loaded
    mock_load_model.assert_called_once_with("test_model.onnx")

    # Verify inference_loop was called (model should be called 10 times)
    assert mock_model.call_count == 10


@patch("seavision.deployment.speedtest.load_model")
def test_run_speed_test_with_context_manager(mock_load_model, mock_model):
    """Test run_speed_test uses context manager correctly."""
    # Setup context manager mock
    context_mock = MagicMock()
    context_mock.__enter__ = MagicMock(return_value=mock_model)
    context_mock.__exit__ = MagicMock(return_value=False)
    mock_load_model.return_value = context_mock

    run_speed_test("model.onnx", 5)

    # Verify context manager was used
    mock_load_model.assert_called_once_with("model.onnx")
    context_mock.__enter__.assert_called_once()
    context_mock.__exit__.assert_called_once()
