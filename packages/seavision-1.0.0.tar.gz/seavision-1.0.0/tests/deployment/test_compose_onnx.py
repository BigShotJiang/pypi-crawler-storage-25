"""Basic tests for compose_onnx module."""

import onnx
import pytest
from onnx import helper

from seavision.deployment.compose_onnx import merge_common_metadata, merge_onnx_models


def create_minimal_onnx_model(
    name: str, output_path: str, metadata: dict = None
) -> onnx.ModelProto:
    """Create a minimal valid ONNX model for testing.

    Args:
        name: Model name for the input/output tensor.
        output_path: Path to save the model.
        metadata: Optional metadata properties to add.

    Returns:
        Created ONNX model.
    """
    # Create a simple graph: input -> identity -> output
    input_tensor = helper.make_tensor_value_info(
        name, onnx.TensorProto.FLOAT, [1, 3, 224, 224]
    )
    output_tensor = helper.make_tensor_value_info(
        f"{name}_output", onnx.TensorProto.FLOAT, [1, 3, 224, 224]
    )

    # Create an identity node (simplest operation)
    identity_node = helper.make_node(
        "Identity", [name], [f"{name}_output"], name="identity"
    )

    graph = helper.make_graph(
        [identity_node],
        "test_graph",
        [input_tensor],
        [output_tensor],
    )

    # Create model
    model = helper.make_model(graph, producer_name="test")
    model.ir_version = 8
    model.opset_import[0].version = 14

    # Add metadata if provided
    if metadata:
        for key, value in metadata.items():
            helper.set_model_props(model, {key: str(value)})

    # Save model
    onnx.save(model, output_path)
    return model


@pytest.fixture
def minimal_onnx_model_1(tmp_path):
    """Create first minimal ONNX model."""
    path = tmp_path / "model1.onnx"
    model = create_minimal_onnx_model(
        "input1", str(path), {"version": "1.0", "author": "test"}
    )
    return str(path), model


@pytest.fixture
def minimal_onnx_model_2(tmp_path):
    """Create second minimal ONNX model."""
    path = tmp_path / "model2.onnx"
    model = create_minimal_onnx_model(
        "input2", str(path), {"version": "2.0", "author": "test"}
    )
    return str(path), model


def test_merge_common_metadata(minimal_onnx_model_1, minimal_onnx_model_2):
    """Test that merge_common_metadata merges common keys correctly."""
    _, model_1 = minimal_onnx_model_1
    _, model_2 = minimal_onnx_model_2

    # Both models have "author" metadata (but different "version")
    merge_common_metadata(model_1, model_2)

    # Check that common metadata was merged
    metadata_1 = {prop.key: prop.value for prop in model_1.metadata_props}
    metadata_2 = {prop.key: prop.value for prop in model_2.metadata_props}

    # "author" should be the same in both (merged as a list string)
    assert "author" in metadata_1
    assert "author" in metadata_2
    assert metadata_1["author"] == metadata_2["author"]
    # The merged value should be a string representation of a list
    assert "test" in metadata_1["author"]


def test_merge_onnx_models_basic(minimal_onnx_model_1, minimal_onnx_model_2, tmp_path):
    """Test basic merge_onnx_models functionality."""
    path_1, _ = minimal_onnx_model_1
    path_2, _ = minimal_onnx_model_2
    output_path = tmp_path / "merged.onnx"

    # Merge models
    merge_onnx_models(
        path_1,
        path_2,
        str(output_path),
        prefix1="model1_",
        prefix2="model2_",
    )

    # Verify output file exists
    assert output_path.exists()

    # Load and verify merged model
    merged_model = onnx.load(str(output_path))
    assert merged_model is not None

    # Verify inputs are prefixed
    input_names = [inp.name for inp in merged_model.graph.input]
    assert any("model1_" in name for name in input_names)
    assert any("model2_" in name for name in input_names)


def test_merge_onnx_models_with_prefixes(
    minimal_onnx_model_1, minimal_onnx_model_2, tmp_path
):
    """Test merge_onnx_models with custom prefixes."""
    path_1, _ = minimal_onnx_model_1
    path_2, _ = minimal_onnx_model_2
    output_path = tmp_path / "merged_prefixed.onnx"

    merge_onnx_models(
        path_1,
        path_2,
        str(output_path),
        prefix1="ir_",
        prefix2="rgb_",
    )

    merged_model = onnx.load(str(output_path))
    input_names = [inp.name for inp in merged_model.graph.input]

    # Check that prefixes were applied
    assert any("ir_" in name for name in input_names)
    assert any("rgb_" in name for name in input_names)


def test_merge_onnx_models_file_not_found(tmp_path):
    """Test that merge_onnx_models handles missing files gracefully."""
    output_path = tmp_path / "output.onnx"

    with pytest.raises((FileNotFoundError, Exception)):
        merge_onnx_models(
            "nonexistent1.onnx",
            "nonexistent2.onnx",
            str(output_path),
        )
