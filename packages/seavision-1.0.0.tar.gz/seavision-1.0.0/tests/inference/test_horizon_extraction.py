"""Test horizon processing functions."""
# ruff: noqa: PLR6301

import numpy as np
import pytest

from seavision.inference.horizon_extraction import (
    get_horizon_from_masks,
)
from seavision.inference.horizon_extraction.fit import (
    fit_line_lstq,
    get_mean_residuals_and_inliers_linear_model,
    ransac_line_fitting,
    ransac_line_fitting_vectorized,
    robust_linear_regressor,
)
from seavision.inference.horizon_extraction.ops import (
    get_horizon_points_fast_batched,
    remove_water_in_sky_batched,
)

# Constants from the module
WATER_LABEL = 0
SKY_LABEL = 1
LAND_LABEL = 2
OTHER_LABEL = 3

rng = np.random.default_rng(42)


@pytest.fixture
def simple_masks():
    """Create simple test masks with clear water-sky boundary."""
    batch_size, height, width = 3, 100, 200
    masks = np.zeros((batch_size, 4, height, width), dtype=np.uint8)

    # First mask: horizontal horizon at y=50
    masks[0, SKY_LABEL, :50, :] = 1
    masks[0, WATER_LABEL, 50:, :] = 1

    # Second mask: tilted horizon
    for x in range(width):
        horizon_y = 40 + int(10 * x / width)  # Slope from y=40 to y=50
        masks[1, SKY_LABEL, :horizon_y, x] = 1
        masks[1, WATER_LABEL, horizon_y:, x] = 1

    for x in range(width):
        horizon_y = 100 - int(10 * x / width)  # Slope from y=100 to y=90
        masks[2, SKY_LABEL, :horizon_y, x] = 1
        masks[2, WATER_LABEL, horizon_y:, x] = 1

    return masks.astype(bool)


@pytest.fixture
def complex_masks():
    """Create complex test masks with land and noise."""
    batch_size, height, width = 1, 100, 200
    masks = np.zeros((batch_size, 4, height, width), dtype=np.uint8)

    # Sky in upper half
    masks[0, SKY_LABEL, :40, :] = 1
    # Water in lower half
    masks[0, WATER_LABEL, 45:, :] = 1
    # Land on the right side
    masks[0, LAND_LABEL, 30:80, 150:] = 1
    # Some water pixels above sky (should be removed)
    masks[0, WATER_LABEL, 20:30, 50:100] = 1

    return masks.astype(bool)


@pytest.fixture
def line_points():
    """Create test points for line fitting."""
    # Perfect line y = 0.5x + 10 with some noise
    x = np.linspace(0, 100, 51)
    y = 0.5 * x + 10 + rng.normal(0, 1, len(x))
    return np.column_stack([x, y])


class TestRemoveWaterInSkyBatch:
    """Test the remove_water_in_sky_batch function."""

    def test_remove_water_above_sky(self, complex_masks):
        """Test that water pixels above sky regions are removed."""
        original = complex_masks.copy()

        result = remove_water_in_sky_batched(complex_masks)

        # Check that some water pixels were removed
        assert np.sum(result[0, WATER_LABEL]) < np.sum(original[0, WATER_LABEL])

        # Sky and land should remain unchanged
        assert np.array_equal(result[0, SKY_LABEL], original[0, SKY_LABEL])
        assert np.array_equal(result[0, LAND_LABEL], original[0, LAND_LABEL])

    def test_no_sky_regions(self):
        """Test behavior when there are no sky regions."""
        masks = np.zeros((1, 4, 50, 100), dtype=np.uint8)
        masks[0, WATER_LABEL] = 1  # All water, no sky

        original = masks.copy()
        result = remove_water_in_sky_batched(masks)

        # Should remain unchanged
        assert np.array_equal(result, original)

    @pytest.mark.parametrize("k", [5, 10, 20])
    def test_different_k_values(self, simple_masks, k):
        """Test with different k values for sky region detection."""
        result = remove_water_in_sky_batched(simple_masks, k=k)
        assert result.shape == simple_masks.shape


class TestGetHorizonPointsFastNumpyBatched:
    """Test the get_horizon_points_fast_numpy_batched function."""

    def test_simple_horizontal_horizon(self, simple_masks):
        """Test extraction of horizontal horizon points."""
        xs, ys = get_horizon_points_fast_batched(simple_masks, normalize=False)

        assert xs.shape == (3, 200)
        assert ys.shape == (3, 200)

        # First mask should have horizon around y=50
        valid_mask = xs[0] >= 0
        valid_ys = ys[0][valid_mask]
        assert np.all(valid_ys >= 45) and np.all(valid_ys <= 55)

    def test_normalization(self, simple_masks):
        """Test that normalization works correctly."""
        xs_norm, ys_norm = get_horizon_points_fast_batched(simple_masks, normalize=True)
        xs_raw, ys_raw = get_horizon_points_fast_batched(simple_masks, normalize=False)

        # Check that normalized values are in [0, 1] range
        valid_mask = xs_norm >= 0
        assert np.all(xs_norm[valid_mask] >= 0) and np.all(xs_norm[valid_mask] <= 1)
        assert np.all(ys_norm[valid_mask] >= 0) and np.all(ys_norm[valid_mask] <= 1)

        # Check conversion accuracy
        height, width = simple_masks.shape[2], simple_masks.shape[3]
        assert np.allclose(xs_norm[valid_mask] * width, xs_raw[valid_mask])
        assert np.allclose(ys_norm[valid_mask] * height, ys_raw[valid_mask])

    def test_no_valid_points(self):
        """Test behavior when no valid horizon points exist."""
        masks = np.zeros((1, 4, 50, 100), dtype=np.uint8)
        masks[0, SKY_LABEL] = 1  # All sky, no water

        xs, ys = get_horizon_points_fast_batched(masks)
        assert np.all(xs < 0)  # All invalid
        assert np.all(ys < 0)  # All invalid

    @pytest.mark.parametrize("top_thresh", [0, 5, 10])
    def test_top_threshold(self, simple_masks, top_thresh):
        """Test different top threshold values."""
        xs, ys = get_horizon_points_fast_batched(simple_masks, top_thresh=top_thresh)
        top_thresh_norm = top_thresh / simple_masks.shape[2]  # Normalize threshold

        # Points below threshold should be invalid
        valid_mask = (xs >= 0) & (ys >= 0)
        valid_ys = ys[valid_mask]
        assert np.all(valid_ys >= top_thresh_norm)


class TestLineFittingFunctions:
    """Test line fitting functions."""

    def test_fit_line_lstq(self, line_points):
        """Test least squares line fitting."""
        slope, intercept = fit_line_lstq(line_points)

        # Should be close to the true line (y = 0.5x + 10)
        assert abs(slope - 0.5) < 0.1
        assert abs(intercept - 10) < 2

    def test_ransac_line_fitting(self, line_points):
        """Test RANSAC line fitting."""
        model, inliers = ransac_line_fitting(
            line_points, max_iterations=100, threshold=2.0
        )

        assert model is not None
        assert len(inliers) > 0
        slope, intercept = model
        assert abs(slope - 0.5) < 0.2
        assert abs(intercept - 10) < 3

    def test_ransac_line_fitting_low_threshold(self, line_points):
        """Test RANSAC line fitting."""
        model, inliers = ransac_line_fitting(
            line_points, max_iterations=100, threshold=0.04
        )

        assert model is not None
        assert len(inliers) > 0
        slope, intercept = model
        assert abs(slope - 0.5) < 0.2
        assert abs(intercept - 10) < 3
        assert (
            len(inliers) < len(line_points) // 4
        )  # Most of the points should be outliers

    def test_ransac_line_fitting_vectorized(self, line_points):
        """Test vectorized RANSAC line fitting."""
        model, inliers = ransac_line_fitting_vectorized(
            line_points, max_iterations=100, threshold=2.0
        )

        assert model is not None
        assert len(inliers) > 0
        slope, intercept = model
        assert abs(slope - 0.5) < 0.2
        assert abs(intercept - 10) < 3

    def test_robust_linear_regressor(self, line_points):
        """Test robust linear regression."""
        x, y = line_points[:, 0], line_points[:, 1]
        model, _ = robust_linear_regressor(x, y)

        assert model is not None
        slope, intercept = model
        assert abs(slope - 0.5) < 0.2
        assert abs(intercept - 10) < 3

    def test_insufficient_points(self):
        """Test behavior with insufficient points."""
        points = np.array([[0, 0]])  # Only one point

        model, inliers = ransac_line_fitting_vectorized(
            points, max_iterations=10, threshold=1.0
        )

        assert model is None
        assert len(inliers) == 0

    def test_get_mean_residuals_and_inliers(self, line_points):
        """Test residual computation and inlier detection."""
        # Fit a line first
        model, _ = ransac_line_fitting_vectorized(
            line_points, max_iterations=50, threshold=2.0
        )

        x, y = line_points[:, 0], line_points[:, 1]
        mean_residual, inlier_ids = get_mean_residuals_and_inliers_linear_model(
            model, (x, y), threshold=2.0
        )

        assert mean_residual >= 0
        assert inlier_ids is not None
        assert len(inlier_ids) <= len(line_points)
        assert np.all(inlier_ids >= 0) and np.all(inlier_ids < len(line_points))


class TestGetHorizonFromMasks:
    """Test the main horizon extraction function."""

    @pytest.mark.parametrize("method", ["ransac", "linear_regression"])
    def test_basic_horizon_extraction(self, simple_masks, method):
        """Test basic horizon extraction with different methods."""
        results = get_horizon_from_masks(simple_masks, method=method, min_pts=10)

        assert len(results) == 3

        for result in results:
            assert "horizon" in result
            assert "confidence" in result

            if result["horizon"] is not None:
                assert len(result["horizon"]) == 2  # Two points
                assert 0 <= result["confidence"] <= 1

    def test_insufficient_points(self):
        """Test behavior when insufficient points are available."""
        # Create masks with very few water pixels
        masks = np.zeros((1, 4, 50, 100), dtype=np.uint8)
        masks[0, SKY_LABEL, :25, :] = 1
        masks[0, WATER_LABEL, 25:30, 45:55] = 1  # Very small water region

        results = get_horizon_from_masks(
            masks, min_pts=50
        )  # Require more points than available

        assert len(results) == 1
        assert results[0]["horizon"] is None
        assert results[0]["confidence"] == 0

    @pytest.mark.parametrize("subsample", [None, 30, 60])
    def test_subsampling(self, simple_masks, subsample):
        """Test different subsampling strategies."""
        results = get_horizon_from_masks(simple_masks, subsample=subsample)

        assert len(results) == 3
        # Should still find horizons regardless of subsampling
        assert any(r["horizon"] is not None for r in results)

    @pytest.mark.parametrize("inlier_threshold", [1.0, 3.0, 5.0])
    def test_inlier_threshold(self, simple_masks, inlier_threshold):
        """Test different inlier thresholds."""
        results = get_horizon_from_masks(
            simple_masks, inlier_threshold=inlier_threshold
        )

        assert len(results) == 3
        # Lower thresholds should generally give lower confidence
        # (more strict about what counts as inliers)

    def test_recompute_option(self, simple_masks):
        """Test the recompute option for confidence calculation."""
        results_normal = get_horizon_from_masks(simple_masks, recompute=False)
        results_recompute = get_horizon_from_masks(simple_masks, recompute=True)

        assert len(results_normal) == len(results_recompute) == 3

        # Results may differ slightly due to different confidence calculations
        for i in range(len(results_normal)):
            if results_normal[i]["horizon"] is not None:
                assert results_recompute[i]["horizon"] is not None

    def test_empty_masks(self):
        """Test behavior with completely empty masks."""
        masks = np.zeros((2, 4, 50, 100), dtype=np.uint8)

        results = get_horizon_from_masks(masks)

        assert len(results) == 2
        for result in results:
            assert result["horizon"] is None
            assert result["confidence"] == 0

    def test_horizon_line_format(self, simple_masks):
        """Test that horizon lines are in the correct format."""
        results = get_horizon_from_masks(simple_masks)

        for result in results:
            if result["horizon"] is not None:
                horizon = result["horizon"]
                assert len(horizon) == 2  # Two points

                # First point should be at x=0, second at x=1
                assert horizon[0][0] == 0
                assert horizon[1][0] == 1

                # Y coordinates should be in [0, 1] range
                assert (
                    0 <= horizon[0][1] <= 1.05
                )  # 1.05, as the third horizon passes through the top edge
                assert 0 <= horizon[1][1] <= 1


@pytest.mark.parametrize("batch_size", [1, 3, 5])
@pytest.mark.parametrize("height, width", [(64, 128), (100, 200), (200, 400)])
def test_different_input_shapes(batch_size, height, width):
    """Test horizon extraction with different input shapes."""
    masks = np.zeros((batch_size, 4, height, width), dtype=np.uint8)

    # Add simple horizontal horizons
    for b in range(batch_size):
        horizon_y = height // 2 + (b - batch_size // 2) * 5
        horizon_y = max(10, min(height - 10, horizon_y))

        masks[b, SKY_LABEL, :horizon_y, :] = 1
        masks[b, WATER_LABEL, horizon_y:, :] = 1

    results = get_horizon_from_masks(masks)

    assert len(results) == batch_size
    # Most should find valid horizons
    valid_horizons = sum(1 for r in results if r["horizon"] is not None)
    assert valid_horizons >= batch_size // 2
