import numpy as np
import pytest
from PIL import Image

from seavision import T, imread, load_model
from seavision.inference.models import ModelVariant
from seavision.inference.results import Results
from seavision.sensorfusion import SensorFusionMethod

git_assets = "https://raw.githubusercontent.com/SEA-AI/.github/main/assets/"

img_sailing_rgb_320 = imread(git_assets + "sailing_rgb_320.jpg")
img_sailing_irl_320 = imread(git_assets + "sailing_tl_320.png")
img_sailing_irr_320 = imread(git_assets + "sailing_tr_320.png")

img_sailing_rgb_640 = imread(git_assets + "sailing_rgb_640.jpg")
img_sailing_irl_640 = imread(git_assets + "sailing_tl_640.png")
img_sailing_irr_640 = imread(git_assets + "sailing_tr_640.png")

img_sentry_rgbwfov = imread(git_assets + "sentry_rgbwfov.jpg")
img_sentry_rgbnfov = imread(git_assets + "sentry_rgbnfov.jpg")
img_sentry_twfov = imread(git_assets + "sentry_twfov.png")
img_sentry_tnfov = imread(git_assets + "sentry_tnfov.png")

img_wk_rgb_4k = imread(git_assets + "watchkeeper_rgb_4k.jpg")
img_wk_rgb = imread(git_assets + "watchkeeper_rgb.jpg")
img_wk_ir = imread(git_assets + "watchkeeper_t_1280.jpg")

to_uint8 = T.ThermalTransform()


@pytest.mark.parametrize(
    "model_name, input_groups",
    [
        (
            "cerulean-level-b2-portrait.onnx",
            [
                [img_sailing_irl_320, img_sailing_irl_320],
                [img_sailing_irl_640, img_sailing_irl_640],
            ],
        ),
        (
            "cerulean-level-b2-landscape.onnx",
            [
                [img_sentry_twfov, img_sentry_tnfov],
            ],
        ),
        (
            "ahoy-IR-b2.onnx",
            [
                [to_uint8(img_sailing_irl_640)],
                [to_uint8(img_sailing_irl_320), to_uint8(img_sailing_irr_320)],
                [to_uint8(img_sentry_twfov), to_uint8(img_sentry_tnfov)],
            ],
        ),
        (
            "ahoy-RGB-b2.onnx",
            [
                [img_sailing_rgb_640],
                [img_sentry_rgbwfov, img_sentry_rgbnfov],
            ],
        ),
        (
            "watchkeeper/ahoyv2-MIX-576x1920.onnx",
            [
                [img_wk_rgb],
            ],
        ),
        (
            "watchkeeper/ahoyv2-IR-640x1280.onnx",
            [
                [img_wk_ir],
            ],
        ),
        (
            "dan-b2.onnx",
            [
                [
                    [to_uint8(img_sailing_irl_320), to_uint8(img_sailing_irr_320)],
                    [img_sailing_rgb_320],
                ],
                [
                    [to_uint8(img_sailing_irl_640), to_uint8(img_sailing_irr_640)],
                    [img_sailing_rgb_640],
                ],
                [
                    [to_uint8(img_sentry_twfov), to_uint8(img_sentry_tnfov)],
                    [img_sentry_rgbwfov, img_sentry_rgbnfov],
                ],
            ],
        ),
        (
            "watchkeeper/danv2-IR1280-MIX1920.onnx",
            [
                [
                    [img_wk_ir],
                    [img_wk_rgb],
                ],
            ],
        ),
    ],
)
def test_models(model_name, input_groups):
    model = load_model(model_name)
    for input_group in input_groups:
        results = model(input_group)

        if isinstance(results, Results):
            assert len(input_group) == 1
            results = [results]

        flattened_group = [item for sublist in input_group for item in sublist]
        for result, image in zip(results, flattened_group):
            assert isinstance(result, Results)
            assert len(result.objects) >= 1
            draw_result = result.draw(image)
            assert isinstance(draw_result, np.ndarray)


def test_yolov5_model():
    cnn = load_model("experimental/yolov5n-MIX-960-multiscale.pt")

    # test setting confidence and iou thresholds
    cnn.det_conf_thresh = 0.1
    assert cnn.model.conf == 0.1
    cnn.det_iou_thresh = 0.15
    assert cnn.model.iou == 0.15

    ims = [to_uint8(im) for im in [img_sentry_twfov, img_sentry_tnfov]]
    ims.extend([img_sentry_rgbwfov, img_sentry_rgbnfov])

    for imgsz in [None, 640]:
        cnn.imgsz = imgsz
        results = cnn(ims)
        assert len(results) == len(ims)
        for result in results:
            assert isinstance(result, Results)
            assert isinstance(result.draw(ims[0]), np.ndarray)


@pytest.mark.parametrize("sf_method", [SensorFusionMethod.NMS, SensorFusionMethod.WBF])
def test_sahi_model(sf_method):
    im = img_wk_rgb_4k
    cnn = load_model(
        "experimental/ahoy-RGB-b3.onnx",
        ModelVariant.SAHI,
        sf_method=sf_method,
    )

    results = cnn(im)
    assert isinstance(results, Results)
    assert isinstance(results.draw(im), np.ndarray)


def test_inference_results():
    im = to_uint8(img_sailing_irl_640)
    model = load_model("ahoy-IR-b2.onnx")
    results = model([im])
    assert isinstance(results, Results)

    draw_pil = results.draw(im, as_pil=True)
    assert isinstance(draw_pil, Image.Image)

    black_image = np.zeros_like(im)

    draw_np_simple = results.draw(black_image, show_horizon=False)
    assert isinstance(draw_np_simple, np.ndarray)

    draw_np_labels = results.draw(black_image, show_labels=True, show_horizon=False)
    assert isinstance(draw_np_labels, np.ndarray)
    # check black pixels are less than draw_np_simple
    assert np.sum(draw_np_labels == 0) < np.sum(draw_np_simple == 0)

    draw_np_labels_horizon = results.draw(
        black_image, show_labels=True, show_horizon=True
    )
    assert isinstance(draw_np_labels_horizon, np.ndarray)
    # check black pixels are less than draw_np_labels
    assert np.sum(draw_np_labels_horizon == 0) < np.sum(draw_np_labels == 0)
