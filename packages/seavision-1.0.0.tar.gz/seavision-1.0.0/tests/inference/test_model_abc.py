"""Unit tests for model_abc.py."""

import json
import tempfile
from pathlib import Path

import pytest
import yaml
import yaml.parser
import yaml.scanner

from seavision.inference.model_abc import load_mappings


@pytest.fixture(params=["json", "yaml"])
def dummy_file_reverse(request):
    """Create a temporary JSON or YAML file with reversed class mapping."""
    data = {
        "person": 0,
        "car": 1,
        "boat": 2,
    }

    suffix = ".json" if request.param == "json" else ".yaml"
    dumper = json.dump if request.param == "json" else yaml.dump

    with tempfile.NamedTemporaryFile(
        suffix=suffix, mode="w", delete=False, encoding="utf-8"
    ) as f:
        dumper(data, f)
        path = f.name

    yield path

    Path(path).unlink()


def test_load_cls_map_reverse_input(dummy_file_reverse):
    """Test loading a reversed mapping file with reverse=True returns normal mapping."""
    cls_map, conf_map = load_mappings(dummy_file_reverse, reverse=True)

    assert cls_map == {
        0: "person",
        1: "car",
        2: "boat",
    }

    # Since no thresholds in input, defaults to 0.0
    assert not conf_map


@pytest.mark.parametrize(
    "data, expected_conf_map",
    [
        (
            {
                0: {"name": "person", "threshold": 0.9},
                1: {"name": "car", "threshold": 0.8},
                2: {"name": "boat", "threshold": 0.7},
            },
            {
                0: 0.9,
                1: 0.8,
                2: 0.7,
            },
        ),
        (
            [
                {
                    0: {"name": "person", "threshold": 0.9},
                    1: {"name": "car", "threshold": 0.8},
                    2: {"name": "boat", "threshold": 0.7},
                }
            ],
            {
                0: 0.9,
                1: 0.8,
                2: 0.7,
            },
        ),
        (
            {
                0: "person",
                1: "car",
                2: "boat",
            },
            {},
        ),
    ],
)
@pytest.mark.parametrize(
    "format, dumper, suffix",
    [
        ("json", json.dump, ".json"),
        ("yaml", yaml.dump, ".yaml"),
    ],
)
def test_load_cls_map_variants(data, expected_conf_map, format, dumper, suffix):
    """Test loading class mapping from JSON and YAML formats with different shapes.

    Test Case 1:
    - Dict mapping (v2-style): {id: {"name": str, "threshold": float}}

    Test Case 2:
    - List of dict mappings (single element): [{id: {"name": str, "threshold": float}}]

    Test Case 3:
    - Dict mapping (v1-style): {id: "name"} (no thresholds)
    """
    with tempfile.NamedTemporaryFile(
        suffix=suffix, mode="w", delete=False, encoding="utf-8"
    ) as f:
        dumper(data, f)
    path = f.name

    try:
        cls_map, conf_map = load_mappings(path)

        assert cls_map == {
            0: "person",
            1: "car",
            2: "boat",
        }

        assert conf_map == expected_conf_map

    finally:
        Path(path).unlink()


def test_load_cls_map_invalid_format():
    """Test loading class mapping from invalid file format."""
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", encoding="utf-8") as f:
        f.write("dummy content")
        f.flush()
        with pytest.raises(ValueError, match="Unsupported file format"):
            load_mappings(f.name)


def test_load_cls_map_nonexistent_file():
    """Test loading class mapping from nonexistent file."""
    with pytest.raises(FileNotFoundError):
        load_mappings("nonexistent_file.yaml")


def test_load_cls_map_invalid_yaml():
    """Test loading class mapping from invalid YAML file."""
    with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", encoding="utf-8") as f:
        f.write("invalid: yaml: content: [unclosed bracket")
        f.flush()
        with pytest.raises((yaml.parser.ParserError, yaml.scanner.ScannerError)):
            load_mappings(f.name)


def test_load_cls_map_invalid_json():
    """Test loading class mapping from invalid JSON file."""
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w", encoding="utf-8") as f:
        f.write("invalid json content")
        f.flush()
        with pytest.raises(ValueError):
            load_mappings(f.name)
