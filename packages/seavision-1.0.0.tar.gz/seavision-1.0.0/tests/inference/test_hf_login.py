"""Test HF login."""

import os

import pytest
from huggingface_hub import get_token, login, whoami
from huggingface_hub.utils import RepositoryNotFoundError


@pytest.mark.parametrize("hf_token_env_var", ["HF_TOKEN"])
def test_hf_login_possible(hf_token_env_var):
    # Get the Hugging Face token from the environment variable
    hf_token = os.getenv(hf_token_env_var) or get_token()

    # Ensure token is set
    assert hf_token is not None, "Hugging Face token not found."

    try:
        # Login using the provided token
        login(token=hf_token)

        # Check if the login is successful by using whoami
        user_info = whoami()

        # Assert that we got user information after login
        assert user_info is not None, "Login failed; no user info returned."

    except RepositoryNotFoundError as e:
        pytest.fail(f"Login failed due to invalid credentials or repository error: {e}")
