"""Test preprocessing functions."""

import numpy as np
import pytest

from seavision.inference.preprocessing import (
    preprocess_yolo,
    resize_and_center_images_in_batch,
)

rng = np.random.default_rng(42)


def resized_area(h_in, w_in, h_out, w_out, upscale):
    scale = min(h_out / h_in, w_out / w_in)
    if not upscale:
        scale = min(scale, 1.0)
    return int(h_in * scale) * int(w_in * scale)


@pytest.mark.parametrize("upscale", [True, False])
@pytest.mark.parametrize("target_shape", [(640, 640), (640, 960)])
def test_preprocess_yolo(upscale, target_shape):
    fill_value = 127
    input_batch = [
        np.full((320, 320, 1), fill_value, dtype=np.uint8),  # square
        np.full((480, 360, 3), fill_value, dtype=np.uint8),  # portrait
        np.full((360, 480, 3), fill_value, dtype=np.uint8),  # landscape
    ]
    b, c = len(input_batch), 3
    h, w = target_shape

    im_yolo = preprocess_yolo(
        input_batch, (h, w), dtype=input_batch[0].dtype, upscale=upscale
    )

    assert im_yolo.shape == (b, c, h, w)

    expected_pixels = (
        sum(resized_area(*im.shape[:2], h, w, upscale) for im in input_batch) * c
    )
    actual_pixels = np.count_nonzero(im_yolo == fill_value)
    assert actual_pixels == expected_pixels


@pytest.mark.parametrize("upscale", [True, False])
@pytest.mark.parametrize("target_shape", [(640, 640), (640, 960)])
def test_resize_and_center_images_in_batch(upscale, target_shape):
    fill_value = 127
    input_batch = [
        np.full((320, 320, 1), fill_value, dtype=np.uint8),  # square
        np.full((480, 360, 3), fill_value, dtype=np.uint8),  # portrait
        np.full((360, 480, 3), fill_value, dtype=np.uint8),  # landscape
    ]
    b, c = len(input_batch), 3
    h, w = target_shape

    output_batch = np.zeros((b, c, h, w), dtype=np.uint8)
    resize_and_center_images_in_batch(input_batch, output_batch, upscale=upscale)

    expected_pixels = (
        sum(resized_area(*im.shape[:2], h, w, upscale) for im in input_batch) * c
    )
    actual_pixels = np.count_nonzero(output_batch == fill_value)

    assert output_batch.shape == (b, c, h, w)
    assert actual_pixels == expected_pixels
