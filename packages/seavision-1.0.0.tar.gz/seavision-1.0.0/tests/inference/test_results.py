import pytest

from seavision.inference.results import BBox, Object, Results


@pytest.fixture
def base_objects():
    bbox1 = BBox(xyxy=[10, 20, 30, 40])
    bbox2 = BBox(xyxy=[50, 60, 70, 80])
    bbox3 = BBox(xyxy=[90, 100, 110, 120])
    obj1 = Object(
        bbox=bbox1, score=0.8, p_class_given_bbox=1.0, class_name="BOAT", class_id=1
    )
    obj2 = Object(
        bbox=bbox2, score=0.3, p_class_given_bbox=1.0, class_name="PERSON", class_id=2
    )
    obj3 = Object(
        bbox=bbox3, score=0.9, p_class_given_bbox=1.0, class_name="BOAT", class_id=1
    )
    return obj1, obj2, obj3


@pytest.mark.parametrize(
    "score,threshold,expected_class",
    [
        (0.6, 0.5, "BOAT"),  # above
        (0.5, 0.5, "HAZARD"),  # on threshold
        (0.4, 0.5, "HAZARD"),  # below
    ],
)
def test_threshold_behavior(score, threshold, expected_class):
    bbox = BBox(xyxy=[0, 0, 10, 10])
    obj = Object(
        bbox=bbox, score=score, p_class_given_bbox=1.0, class_name="BOAT", class_id=1
    )
    results = Results(objects=[obj], horizon=None, image_width=100, image_height=100)

    conf_map = {1: threshold}
    cls_map = {1: "BOAT", 0: "HAZARD"}

    modified = results.apply_confidence_map(conf_map, cls_map)

    assert len(modified.objects) == 1

    assert modified.objects[0].class_name == expected_class


def test_objects_above_and_below_thresholds(base_objects):
    obj1, obj2, obj3 = base_objects
    results = Results(
        objects=[obj1, obj2, obj3], horizon=None, image_width=640, image_height=480
    )

    conf_map = {1: 0.5, 2: 0.4}
    cls_map = {1: "BOAT", 2: "PERSON", 0: "HAZARD"}

    modified = results.apply_confidence_map(conf_map, cls_map)

    assert modified.objects[0].class_name == "BOAT"
    assert modified.objects[1].class_name == "HAZARD"
    assert modified.objects[2].class_name == "BOAT"
    assert len(modified.objects) == 3


def test_fallback_label_custom(base_objects):
    obj1, obj2, obj3 = base_objects
    results = Results(
        objects=[obj1, obj2, obj3], horizon=None, image_width=640, image_height=480
    )

    conf_map = {1: 0.5, 2: 0.4}
    cls_map = {1: "BOAT", 2: "PERSON", 99: "UNKNOWN"}

    modified = results.apply_confidence_map(conf_map, cls_map, fallback_label="UNKNOWN")

    assert modified.objects[1].class_name == "UNKNOWN"
    assert modified.objects[1].class_id == 99


def test_empty_objects():
    results = Results(objects=[], horizon=None, image_width=640, image_height=480)
    conf_map = {1: 0.5}
    cls_map = {1: "BOAT", 0: "HAZARD"}

    out = results.apply_confidence_map(conf_map, cls_map)
    assert out is results
    assert len(out.objects) == 0


def test_empty_conf_map(base_objects):
    obj1, obj2, obj3 = base_objects
    results = Results(
        objects=[obj1, obj2, obj3], horizon=None, image_width=640, image_height=480
    )
    cls_map = {1: "BOAT", 2: "PERSON", 0: "HAZARD"}

    out = results.apply_confidence_map({}, cls_map)
    assert out is results
    assert out.objects[0].class_name == "BOAT"
    assert out.objects[1].class_name == "PERSON"
    assert out.objects[2].class_name == "BOAT"
    assert len(out.objects) == 3


def test_empty_class_map(base_objects):
    obj1, obj2, obj3 = base_objects
    results = Results(
        objects=[obj1, obj2, obj3], horizon=None, image_width=640, image_height=480
    )
    conf_map = {1: 0.5, 2: 0.4}

    out = results.apply_confidence_map(conf_map, {})
    assert out is results
    assert out.objects[0].class_name == "BOAT"
    assert out.objects[1].class_name == "PERSON"
    assert out.objects[2].class_name == "BOAT"
    assert len(out.objects) == 3
