import numpy as np
import pytest

from seavision.inference.model_abc import convert_to_nested_list, get_image_hw

# --- Fixtures ---

rng = np.random.default_rng(seed=0x5EED)


@pytest.fixture
def single_img_1ch():
    return rng.integers(0, 255, (320, 320))


@pytest.fixture
def single_img_3ch():
    return rng.integers(0, 255, (320, 320, 3))


@pytest.fixture
def batch_img_1ch():
    return rng.integers(0, 255, (4, 320, 320, 1))


@pytest.fixture
def batch_img_3ch():
    return rng.integers(0, 255, (4, 320, 320, 3))


@pytest.fixture
def bchw_img_3ch():
    return rng.integers(0, 255, (4, 3, 320, 320))


# --- Helper ---


def stringify(x):
    result = ""
    if isinstance(x, np.ndarray):
        result += f"{x.shape}, "
    elif isinstance(x, list):
        result += f"{len(x)}, "
        for item in x:
            result += stringify(item)
    return result


# --- Tests ---


@pytest.mark.parametrize(
    "params_func, expected_func",
    [
        (lambda x: {"group_count": 1, "image_data": x}, lambda x: [x]),
        (lambda x: {"group_count": 1, "image_data": [x]}, lambda x: [x]),
    ],
)
@pytest.mark.parametrize(
    "fixture_name",
    [
        "single_img_1ch",
        "single_img_3ch",
    ],
)
def test_single_group_simple(request, fixture_name, params_func, expected_func):
    data = request.getfixturevalue(fixture_name)
    result = convert_to_nested_list(**params_func(data))
    expected = expected_func(data)
    assert stringify(result) == stringify(expected)


@pytest.mark.parametrize(
    "fixture_name",
    [
        "batch_img_1ch",
        "batch_img_3ch",
    ],
)
def test_single_group_batch(request, fixture_name):
    data = request.getfixturevalue(fixture_name)
    result = convert_to_nested_list(group_count=1, image_data=data)
    expected = list(data)
    assert stringify(result) == stringify(expected)


@pytest.mark.parametrize(
    "fixture_name",
    [
        "batch_img_1ch",
        "batch_img_3ch",
    ],
)
def test_single_group_batch_wrapped(request, fixture_name):
    data = request.getfixturevalue(fixture_name)
    result = convert_to_nested_list(group_count=1, image_data=[data])
    expected = list(data)
    assert stringify(result) == stringify(expected)


@pytest.mark.parametrize(
    "fixture_names",
    [
        ("batch_img_1ch", "batch_img_1ch"),
        ("batch_img_1ch", "batch_img_3ch"),
    ],
)
def test_single_group_failed(request, fixture_names):
    images = [request.getfixturevalue(name) for name in fixture_names]
    with pytest.raises(ValueError):
        convert_to_nested_list(group_count=1, image_data=images)


@pytest.mark.parametrize(
    "fixture_names, expected_builder",
    [
        (("single_img_1ch", "single_img_3ch"), lambda a, b: [[a], [b]]),
        (("batch_img_1ch", "single_img_1ch"), lambda a, b: [list(a), [b]]),
        (("single_img_1ch", "batch_img_1ch"), lambda a, b: [[a], list(b)]),
        (("batch_img_1ch", "batch_img_3ch"), lambda a, b: [list(a), list(b)]),
        (
            (["single_img_1ch"], ["single_img_3ch"]),
            lambda a, b: [a, b],
        ),  # already nested
    ],
)
def test_multiple_groups(request, fixture_names, expected_builder):
    if isinstance(fixture_names[0], list):
        # Already nested case
        a = [request.getfixturevalue(fixture_names[0][0])]
        b = [request.getfixturevalue(fixture_names[1][0])]
    else:
        a = request.getfixturevalue(fixture_names[0])
        b = request.getfixturevalue(fixture_names[1])
    result = convert_to_nested_list(group_count=2, image_data=[a, b])
    expected = expected_builder(a, b)
    assert stringify(result) == stringify(expected)


@pytest.mark.parametrize(
    "fixture_name",
    [
        "single_img_1ch",
        "batch_img_1ch",
        "batch_img_3ch",
    ],
)
def test_multiple_groups_failed(request, fixture_name):
    data = request.getfixturevalue(fixture_name)
    with pytest.raises(ValueError):
        convert_to_nested_list(group_count=2, image_data=data)

    with pytest.raises(ValueError):
        convert_to_nested_list(group_count=2, image_data=[data])


@pytest.mark.parametrize(
    "fixture_name, expected",
    [
        ("single_img_1ch", (320, 320)),
        ("single_img_3ch", (320, 320)),
        ("batch_img_1ch", (320, 320)),
        ("batch_img_3ch", (320, 320)),
        ("bchw_img_3ch", (320, 320)),
    ],
)
def test_get_image_hw(request, fixture_name, expected):
    data = request.getfixturevalue(fixture_name)
    assert get_image_hw(data) == expected
