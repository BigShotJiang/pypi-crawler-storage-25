import pytest

from seavision.inference.dan import DAN, DANY, DANv1, DANv2


@pytest.mark.parametrize(
    ("model_path", "expected_cls"),
    [
        ("danv1-b2.onnx", DANv1),
        ("DanV1-b2.onnx", DANv1),
        ("watchkeeper/danv2-IR1280-MIX1920.onnx", DANv2),
        ("something-OBB-variant.onnx", DANv2),
        ("dany-IR-480x640-RGB-576x1920.onnx", DANY),
    ],
)
def test_dan_resolves_correct_variant(model_path: str, expected_cls: type) -> None:
    inst = DAN.__new__(DAN, model_path=model_path)
    assert isinstance(inst, expected_cls)


def test_dan_missing_path_raises() -> None:
    with pytest.raises(ValueError, match="model_path must be provided"):
        DAN.__new__(DAN)
