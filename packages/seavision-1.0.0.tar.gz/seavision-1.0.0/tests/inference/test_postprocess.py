import numpy as np
import pytest
from numpy.testing import assert_allclose

from seavision.inference.postprocessing import (
    cxcywhr_to_lines,
    letterbox_geometry,
    postprocess_obb2horizon,
    scale_xyxy,
    slope_intercept_to_unpadded_image_edges,
)


@pytest.mark.parametrize(
    "input_hw, target_hw, xyxy, upscale, clip, expected",
    [
        # Horizontal line (y1 = y2) - straight line parallel to x-axis
        (
            (384, 1280),
            (768, 2560),
            np.array([[0, 192, 1279, 192]]),
            True,
            True,
            np.array([[0, 384, 2558, 384]]),
        ),
        # Tilted line clockwise (also can be interpreted as bbox since x2>x1 and y2>y1)
        (
            (384, 1280),
            (192, 640),
            np.array([[100, 100, 500, 300]]),
            True,
            True,
            np.array([[50, 50, 250, 150]]),
        ),
        # Tilted line counter-clockwise (not a bbox since y2<y1)
        (
            (384, 1280),
            (576, 1920),
            np.array([[100, 300, 500, 100]]),
            True,
            True,
            np.array([[150, 450, 750, 150]]),
        ),
        # Line that goes out of bounds (x2>x1 and y2>y1) but not clipped
        (
            (384, 1280),
            (768, 2560),
            np.array([[0, -50, 1280, 100]]),
            True,
            False,
            np.array([[0, -100, 2560, 200]]),
        ),
        # Bbox that gets clipped to image boundaries when clip=True
        (
            (384, 1280),
            (768, 2560),
            np.array([[-100, -50, 1400, 800]]),
            True,
            True,
            np.array([[0, 0, 2560, 768]]),  # Clipped to stay within image
        ),
        # Bbox with upscale=False and bbox with same size as target
        (
            (384, 1280),
            (192, 640),  # Target is smaller than input
            np.array([[320, 96, 960, 288]]),  # bbox centered in input_hw
            False,
            True,
            np.array([[0, 0, 640, 192]]),  # bbox covering target_hw
        ),
        # Bbox with upscale=True and smaller target - scales down proportionally
        (
            (384, 1280),
            (192, 640),  # Target is smaller than input
            np.array([[0, 0, 100, 100]]),
            True,
            True,
            np.array([[0, 0, 50, 50]]),  # Scaled down by 0.5
        ),
        # Bbox with larger target - always scales up regardless of upscale flag
        (
            (384, 1280),
            (768, 2560),  # Target is larger than input
            np.array([[0, 0, 100, 100]]),
            False,  # Upscale flag doesn't matter for larger targets
            True,
            np.array([[0, 0, 200, 200]]),  # Scaled up by 2x
        ),
    ],
)
def test_scale_xyxy(input_hw, target_hw, xyxy, upscale, clip, expected):
    scaled_xyxy = scale_xyxy(xyxy, input_hw, target_hw, upscale, clip)
    assert np.allclose(scaled_xyxy, expected)


def test_slope_intercept_to_unpadded_image_edges_y_stays_normalized():
    """Horizon endpoints mapped to orig_hw must lie in [0,1] when normalized.

    Without dividing by `gain` when rescaling from letterboxed coordinates, Y pixels
    are inflated by the upscale factor and can exceed image height (see #25).
    """
    from_shape = (1200, 1200)
    to_shape = (400, 600)
    h, w = to_shape
    pts = slope_intercept_to_unpadded_image_edges(
        0.0, 0.8, from_shape, to_shape, upscale=True
    )
    x_norm = pts[[0, 2]] / w
    y_norm = pts[[1, 3]] / h
    assert np.all(x_norm >= -1e-6) and np.all(x_norm <= 1.0 + 1e-6)
    assert np.all(y_norm >= -1e-6) and np.all(y_norm <= 1.0 + 1e-6), (
        f"normalized y out of bounds: {y_norm}, pts={pts}"
    )


@pytest.mark.parametrize(
    "input_hw, orig_hw, expected_xyxy",
    [
        pytest.param(
            (1088, 1568),
            (800, 1280),
            np.array([[0.0, 400.0, 1280.0, 400.0]], dtype=np.float32),
            id="1088x1568_canvas_to_800x1280_orig",
        ),
        pytest.param(
            (640, 640),
            (600, 400),
            np.array([[0.0, 300.0, 400.0, 300.0]], dtype=np.float32),
            id="square_canvas_horizontal_letterbox_pad_x_regression",
        ),
    ],
)
def test_postprocess_obb2horizon_horizontal_line_in_orig_space(
    input_hw: tuple[int, int],
    orig_hw: tuple[int, int],
    expected_xyxy: np.ndarray,
) -> None:
    """Centered horizontal OBB → horizon line endpoints in ``orig_hw`` pixel space.

    Expected ``xyxy`` is derived analytically from :func:`letterbox_geometry`
    (gain, symmetric padding) and intersecting :math:`y = cy` with the vertical
    edges of the **content** rectangle on the canvas—not the full tensor width,
    which is why the second case fails pre-fix when horizontal padding is non-zero.

    Shapes are ``(height, width)``.
    """
    h_in, w_in = input_hw
    h_o, w_o = orig_hw
    geom = letterbox_geometry(input_hw, orig_hw, upscale=True)
    assert_allclose(2 * geom.pad_x + w_o * geom.gain, w_in, rtol=0, atol=1e-5)
    assert_allclose(2 * geom.pad_y + h_o * geom.gain, h_in, rtol=0, atol=1e-5)

    # Symmetric letterbox: tensor center equals content-area center (any aspect).
    cx, cy = w_in / 2, h_in / 2
    model_output = np.array([[cx, cy, 80.0, 20.0, 0.99, 0.0]], dtype=np.float32)
    lines, score, cls = postprocess_obb2horizon(
        model_output,
        input_hw=input_hw,
        orig_hw=orig_hw,
        conf_thresh=0.5,
        was_upscaled=True,
    )

    assert_allclose(lines, expected_xyxy, rtol=0, atol=1e-5)
    assert score.shape == (1,) and cls.shape == (1,) and cls[0] == -1

    x_n = lines[0, [0, 2]] / w_o
    y_n = lines[0, [1, 3]] / h_o
    assert np.all(x_n >= -1e-5) and np.all(x_n <= 1.0 + 1e-5)
    assert np.all(y_n >= -1e-5) and np.all(y_n <= 1.0 + 1e-5)


@pytest.mark.parametrize(
    "obboxes, input_hw, expected_shape",
    [
        # Basic horizontal box
        (
            np.array([[50, 50, 20, 10, 0]], dtype=np.float32),
            (200, 200),
            (1, 4),
        ),
        # Box rotated 180 degrees
        (
            np.array([[50, 50, 20, 10, np.pi]], dtype=np.float32),
            (200, 200),
            (1, 4),
        ),
        # Box at image edge
        (
            np.array([[640, 384, 500, 20, np.pi / 2]], dtype=np.float32),
            (384, 1280),
            (1, 4),
        ),
        # Multiple boxes with different angles
        (
            np.array(
                [
                    [25, 25, 10, 10, 0],  # horizontal
                    [50, 50, 20, 10, np.pi / 4],  # 45 degrees
                    [75, 75, 30, 15, -np.pi / 2],  # vertical
                ],
                dtype=np.float32,
            ),
            (200, 200),
            (3, 4),
        ),
    ],
)
def test_cxcywhr_to_lines(obboxes, input_hw, expected_shape):
    result = cxcywhr_to_lines(obboxes, input_hw, input_hw)

    def slope(lines: np.ndarray) -> np.ndarray:
        return (lines[..., 3] - lines[..., 1]) / (lines[..., 2] - lines[..., 0])

    assert result.shape == expected_shape
    assert not np.any(np.isnan(result))
    assert np.all(np.isfinite(result))

    # Check that all lines span the full width of the image
    assert np.all(result[..., 0] == 0)
    assert np.all(result[..., 2] == input_hw[1])

    # Check that the slope of the line is equal to the tangent of the angle
    assert np.all(np.isclose(slope(result), np.tan(obboxes[..., 4])))


@pytest.mark.parametrize(
    "model_output, input_hw, orig_hw, conf_thresh, expected_line, expected_cls",
    [
        # Case with detection above confidence threshold
        (
            np.array(
                [
                    [60, 60, 30, 10, 0.95, 0.0],
                    [120, 120, 40, 15, 0.85, 0.0],
                    [180, 180, 35, 12, 0.75, 0.0],
                ],
                dtype=np.float32,
            ),
            (640, 640),
            (640, 640),
            0.9,
            np.array([[0, 60, 640, 60]]),
            np.array([-1]),
        ),
        # Case with no detections above confidence threshold
        (
            np.array(
                [
                    [60, 60, 30, 10, 0.3, 0.0],
                    [120, 120, 40, 15, 0.4, 0.0],
                    [180, 180, 35, 12, 0.2, 0.0],
                ],
                dtype=np.float32,
            ),
            (640, 640),
            (640, 640),
            0.5,
            np.empty((0, 4)),
            np.array([]),
        ),
    ],
)
def test_postprocess_obb2horizon(
    model_output, input_hw, orig_hw, conf_thresh, expected_line, expected_cls
):
    bbox, score, cls = postprocess_obb2horizon(
        model_output,
        input_hw=input_hw,
        orig_hw=orig_hw,
        conf_thresh=conf_thresh,
    )
    assert np.allclose(bbox, expected_line)
    assert np.array_equal(cls, expected_cls)
    if expected_line.shape[0] > 0:
        assert np.all(score >= conf_thresh)
