"""Fixtures for the tests.

Fixtures are automatically detected by pytest.
They are temporary objects that are used to share data between tests.
"""

import logging

import pytest
from click.testing import CliRunner

from seavision.inference.results import BBox, Horizon, Line, Object, Results

# Configure logging to only show ERROR level messages during tests
logging.basicConfig(level=logging.ERROR)
# Also ensure all existing loggers are set to ERROR level
for logger_name in logging.root.manager.loggerDict:
    logging.getLogger(logger_name).setLevel(logging.ERROR)


@pytest.fixture
def cli_runner():
    return CliRunner()


@pytest.fixture
def silence_cli_print_banner(monkeypatch):
    """Disable the CLI group startup banner for deterministic command output."""
    monkeypatch.setattr("seavision.cli.print_banner", lambda: None)


@pytest.fixture
def sample_results():
    return [
        Results(
            objects=[
                Object(
                    bbox=BBox(
                        xywh=[724.423828125, 477.61328125, 7.15234375, 7.7734375],
                        xywh_n=[
                            0.6036865234375,
                            0.49751383463541665,
                            0.0059602864583333335,
                            0.008097330729166666,
                        ],
                    ),
                    score=0.1988525390625,
                    class_name="FAR_AWAY_OBJECT",
                    class_id=7,
                ),
                Object(
                    bbox=BBox(
                        xywh=[615.421875, 459.4375, 62.15625, 30.125],
                        xywh_n=[
                            0.5128515625,
                            0.47858072916666666,
                            0.051796875,
                            0.03138020833333333,
                        ],
                    ),
                    score=0.923828125,
                    class_name="SHIP",
                    class_id=3,
                ),
            ],
            horizon=Horizon(
                line=Line(
                    xyxy=[0.0, 498.62535892875763, 1200.0, 476.0032124998138],
                    xyxy_n=[0.0, 0.5194014155507892, 1.0, 0.49583667968730605],
                    rho=498.53677932087567,
                    theta=1.5519467708733579,
                    slope=-0.01885178869078653,
                    intercept=498.62535892875763,
                ),
                score=0.27022719383239746,
                class_name="HORIZON",
                class_id=-1,
            ),
            image_width=1200,
            image_height=960,
        ),
        Results(
            objects=[
                Object(
                    bbox=BBox(
                        xywh=[398.8544921875, 486.26953125, 3.791015625, 4.4609375],
                        xywh_n=[
                            0.3323787434895834,
                            0.50653076171875,
                            0.0031591796874999023,
                            0.004646809895833215,
                        ],
                    ),
                    score=0.342041015625,
                    class_name="FAR_AWAY_OBJECT",
                    class_id=7,
                ),
                Object(
                    bbox=BBox(
                        xywh=[724.884765625, 477.673828125, 6.23046875, 6.65234375],
                        xywh_n=[
                            0.6040706380208334,
                            0.49757690429687507,
                            0.0051920572916666075,
                            0.006929524739583304,
                        ],
                    ),
                    score=0.453857421875,
                    class_name="FAR_AWAY_OBJECT",
                    class_id=7,
                ),
                Object(
                    bbox=BBox(
                        xywh=[614.84375, 458.7890625, 63.3125, 31.421875],
                        xywh_n=[
                            0.5123697916666667,
                            0.4779052734375,
                            0.05276041666666664,
                            0.03273111979166665,
                        ],
                    ),
                    score=0.94873046875,
                    class_name="SHIP",
                    class_id=3,
                ),
            ],
            horizon=Horizon(
                line=Line(
                    xyxy=[344.0, 476.0032124998138, 856.0, 476.0032124998138],
                    xyxy_n=[
                        0.2866666666666667,
                        0.49583667968730605,
                        0.7133333333333334,
                        0.49583667968730605,
                    ],
                    rho=476.0032124998138,
                    theta=1.5707963267948966,
                    slope=0.0,
                    intercept=476.0032124998138,
                ),
                score=0.13875937461853027,
                class_name="HORIZON",
                class_id=-1,
            ),
            image_width=1200,
            image_height=960,
        ),
    ]
