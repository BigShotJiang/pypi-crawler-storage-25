"""Test the transforms module."""

import inspect

import numpy as np
import pytest

import seavision.transforms as T
from seavision.transforms.base import BaseTransform

rng = np.random.default_rng(0x5EED)


def get_all_transforms():
    """Dynamically get all transform classes from transforms module."""
    return {
        name: cls
        for name, cls in inspect.getmembers(T)
        if inspect.isclass(cls)
        and issubclass(cls, BaseTransform)
        and cls != BaseTransform
    }


@pytest.fixture
def sample_rgb_image():
    """Create a sample RGB image for testing."""
    return rng.integers(0, 256, (100, 100, 3), dtype=np.uint8)


@pytest.fixture
def sample_gray8_image():
    """Create a sample gray8 image for testing."""
    return rng.integers(0, 256, (100, 100), dtype=np.uint8)


@pytest.fixture
def sample_gray16_image():
    """Create a sample gray16 image for testing."""
    return rng.integers(0, 65535, (100, 100), dtype=np.uint16)


def test_transform_registry():
    """Test that all transforms from __init__ are available."""
    transforms_list = get_all_transforms()
    assert len(transforms_list) > 0
    for name in T.__all__:
        assert name in transforms_list, f"Transform {name} not found in registry"


@pytest.mark.parametrize("transform_name", T.__all__)
def test_transform_call(
    transform_name,
    sample_rgb_image,
    sample_gray8_image,
    sample_gray16_image,
):
    """Test that all transforms can be instantiated."""
    transform_class = getattr(T, transform_name)
    if issubclass(transform_class, T.Compose):
        return  # skip composed transforms

    # Handle different transform initialization requirements
    if any(substr in transform_name.lower() for substr in ["grey", "thermal"]):
        input_images = [sample_gray8_image, sample_gray16_image]
    else:
        input_images = [sample_rgb_image]

    # EMANormalize requires fps parameter
    if transform_name == "EMANormalize":
        transform = transform_class(fps=30.0)
    else:
        transform = transform_class()

    for input_image in input_images:
        result = transform(input_image)
        assert isinstance(result, np.ndarray)
        if "torgb" in transform_name.lower():
            assert result.shape == input_image.shape[:2] + (3,)
        else:
            assert result.shape == input_image.shape


def test_compose_empty(sample_rgb_image, sample_gray8_image, sample_gray16_image):
    """Test Compose transform with empty list."""
    transform = T.Compose([])
    input_images = [sample_rgb_image, sample_gray8_image, sample_gray16_image]
    for input_image in input_images:
        result = transform(input_image)
        assert np.array_equal(result, input_image)


def test_compose_multiple(sample_rgb_image, sample_gray8_image, sample_gray16_image):
    """Test Compose transform with multiple transforms."""
    transform = T.Compose(
        [
            T.ClipByPercentiles(),
            T.UnsharpMask(),
        ]
    )
    input_images = [sample_rgb_image, sample_gray8_image, sample_gray16_image]
    for input_image in input_images:
        result = transform(input_image)
        assert isinstance(result, np.ndarray)
        assert not np.array_equal(result, input_image)


@pytest.mark.parametrize(
    "transform, args",
    [
        (T.ThermalTransform, {}),
        (T.ThermalTransform4Video, {"fps": 25}),
    ],
)
def test_thermal_pipelines(transform, args, sample_gray8_image, sample_gray16_image):
    """Test the default thermal pipeline."""
    pipeline = transform(**args)
    input_images = [sample_gray8_image, sample_gray16_image]
    for input_image in input_images:
        result = pipeline(input_image)
        assert len(result.shape) == 3
        assert result.shape[2] == 3
