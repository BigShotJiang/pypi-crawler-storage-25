"""Tests for approximate distance estimation module."""

from pathlib import Path
from typing import Tuple

import numpy as np
import pytest

from seavision.geometry.distance import (
    ApproximateDistEstimator,
    CameraParameters,
    Status,
    SystemPose,
    TargetEstimate,
)

# Tolerance constants
ANGLE_TOLERANCE = 1e-6  # Tolerance for angle comparisons
ROTATION_TOLERANCE = 1e-10  # Tolerance for rotation matrix comparisons
RANGE_TOL_M = 5.0
BEARING_TOL_DEG = 1.0
BEARING_SYMMETRY_TOL_DEG = 2.0
MIN_FAR_DISTANCE_M = 400.0

# Test data paths
TEST_ASSETS_DIR = Path(__file__).parent.parent / "assets"
VALID_CONFIG_PATH = TEST_ASSETS_DIR / "sensors" / "test_camera_config.json"
INVALID_JSON_PATH = TEST_ASSETS_DIR / "sensors" / "invalid_json.json"
NO_CAMERAS_KEY_PATH = TEST_ASSETS_DIR / "sensors" / "invalid_no_cameras_key.json"

# CoastKeeper sensors calibration
COASTKEEPER_SENSORS_PATH = TEST_ASSETS_DIR / "sensors" / "coastkeeper.json"


@pytest.fixture(name="coastkeeper_pose")
def fixture_coastkeeper_pose() -> SystemPose:
    """Return the SystemPose used for CoastKeeper ground truth tests."""
    return SystemPose(
        imu_roll=5.699816751783391,
        imu_pitch=2.13576116742176,
        imu_yaw=0.0,  # Facing North
        mounting_height_m=10.0,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )


@pytest.fixture(name="coastkeeper_estimator")
def fixture_coastkeeper_estimator() -> ApproximateDistEstimator:
    """Return an ApproximateDistEstimator with CoastKeeper parameters."""
    # Load real CoastKeeper t1 camera parameters from JSON
    # Calibrated: 2025-12-02
    camera_params = CameraParameters.from_json(str(COASTKEEPER_SENSORS_PATH), "t1")
    return ApproximateDistEstimator(camera_params)


def assert_is_valid_estimate(
    result: TargetEstimate,
    desc: str = "Estimate",
    check_range: bool = False,
    check_bearing: bool = False,
) -> None:
    """Assert that the estimate is valid.

    Optionally checks for presence of range/bearing.
    """
    assert result.is_valid(), f"{desc}: Status not OK ({result.status})"

    if check_range and result.horizontal_range_m is None:
        pytest.fail(f"{desc}: Missing horizontal range")

    if check_bearing and result.bearing is None:
        pytest.fail(f"{desc}: Missing bearing")


def test_camera_intrinsics_creation() -> None:
    """Test CameraParameters creation with basic parameters."""
    camera_params = CameraParameters(
        fx=1000.0, fy=1000.0, cx=640.0, cy=480.0, roll=0.0, pitch=0.0, yaw=0.0
    )
    assert camera_params.fx == 1000.0
    assert camera_params.fy == 1000.0
    assert camera_params.cx == 640.0
    assert camera_params.cy == 480.0


def test_camera_intrinsics_from_focal_length() -> None:
    """Test CameraParameters creation from physical parameters."""
    camera_params = CameraParameters.from_focal_length(
        focal_length_mm=25.0,
        pixel_pitch_um=5.5,
        sensor_resolution=(1280, 960),
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
    )
    assert camera_params.fx > 0
    assert camera_params.fy > 0
    assert camera_params.cx == 640.0
    assert camera_params.cy == 480.0


def test_camera_parameters_from_json_success() -> None:
    """Test successful loading of CameraParameters from JSON file."""
    camera_params = CameraParameters.from_json(str(VALID_CONFIG_PATH), "t1")

    # Verify loaded values
    assert camera_params.fx == 1112.61
    assert camera_params.fy == 1112.50
    assert camera_params.cx == 319.5
    assert camera_params.cy == 255.5
    assert camera_params.roll == 0.0
    assert camera_params.pitch == 0.0
    assert camera_params.yaw == 0.0
    assert camera_params.position_mm is not None
    np.testing.assert_array_equal(
        camera_params.position_mm, np.array([-115.4, 63.6, 42.0])
    )
    assert camera_params.sensor_resolution == (639, 511)


def test_camera_parameters_from_json_second_camera() -> None:
    """Test loading second camera from JSON file."""
    camera_params = CameraParameters.from_json(str(VALID_CONFIG_PATH), "t2")

    # Verify loaded values for second camera
    assert camera_params.fx == 800.0
    assert camera_params.fy == 800.0
    assert camera_params.cx == 320.0
    assert camera_params.cy == 240.0
    assert camera_params.roll == 1.5
    assert camera_params.pitch == -2.3
    assert camera_params.yaw == 45.0
    np.testing.assert_array_equal(
        camera_params.position_mm, np.array([100.0, 50.0, 30.0])
    )


def test_camera_parameters_from_json_file_not_found() -> None:
    """Test FileNotFoundError when JSON file doesn't exist."""
    with pytest.raises(FileNotFoundError) as exc_info:
        CameraParameters.from_json("nonexistent_file.json", "t1")

    assert "Camera config not found" in str(exc_info.value)
    assert "nonexistent_file.json" in str(exc_info.value)


def test_camera_parameters_from_json_invalid_json() -> None:
    """Test ValueError when JSON file is malformed."""
    with pytest.raises(ValueError) as exc_info:
        CameraParameters.from_json(str(INVALID_JSON_PATH), "t1")

    assert "Invalid JSON" in str(exc_info.value)
    assert str(INVALID_JSON_PATH) in str(exc_info.value)


def test_camera_parameters_from_json_no_cameras_key() -> None:
    """Test KeyError when 'cameras' key is missing from config."""
    with pytest.raises(KeyError) as exc_info:
        CameraParameters.from_json(str(NO_CAMERAS_KEY_PATH), "t1")

    assert "'cameras' key not found in config" in str(exc_info.value)
    assert str(NO_CAMERAS_KEY_PATH) in str(exc_info.value)


def test_camera_parameters_from_json_camera_not_found() -> None:
    """Test KeyError when camera name not found with helpful message."""
    with pytest.raises(KeyError) as exc_info:
        CameraParameters.from_json(str(VALID_CONFIG_PATH), "nonexistent_camera")

    error_message = str(exc_info.value)
    assert "nonexistent_camera" in error_message
    assert "not found in config" in error_message
    # Should list available cameras
    assert "Available:" in error_message
    assert "t1" in error_message
    assert "t2" in error_message


def test_system_pose_creation() -> None:
    """Test SystemPose creation."""
    pose = SystemPose(
        imu_roll=1.0,
        imu_pitch=0.5,
        imu_yaw=45.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )
    assert pose.imu_roll == 1.0
    assert pose.imu_pitch == 0.5
    assert pose.imu_yaw == 45.0
    assert pose.mounting_height_m == 7.5
    assert not pose.ptu_pan
    assert not pose.ptu_tilt


def test_approximate_dist_estimator_initialization() -> None:
    """Test ApproximateDistEstimator initialization."""
    camera_params = CameraParameters(
        fx=1000.0, fy=1000.0, cx=640.0, cy=480.0, roll=0.0, pitch=0.0, yaw=0.0
    )
    estimator = ApproximateDistEstimator(camera_params)
    assert estimator.camera_params == camera_params


def test_calculate_range_and_bearing_above_horizon() -> None:
    """Test calculate_range_and_bearing with pixel above horizon."""
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
        sensor_resolution=(1280, 960),
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)

    # Test with a pixel above horizon (should fail or return error status)
    pixel_coords = (640, 100)  # Above horizon
    result = estimator.calculate_range_and_bearing(pose, pixel_coords)

    # Verify it returns proper error status
    assert isinstance(result, TargetEstimate)
    # Either status is not OK, or distance is invalid
    if not result.is_valid():
        # Should be above horizon status
        assert result.status == Status.ABOVE_HORIZON


def test_get_horizon_line() -> None:
    """Test get_horizon_line method."""
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
        sensor_resolution=(1280, 960),
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)

    # Get horizon line
    p1, p2 = estimator.get_horizon_line(pose)

    # Verify output structure
    assert isinstance(p1, tuple)
    assert isinstance(p2, tuple)
    assert len(p1) == 2
    assert len(p2) == 2

    # Horizon endpoints should be different
    assert p1 != p2

    # X coordinates should span the image width
    assert p1[0] != p2[0]


def test_get_valid_range() -> None:
    """Test get_valid_range method."""
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
        sensor_resolution=(1280, 960),
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)

    # Get valid range
    min_range, max_range = estimator.get_valid_range(pose)

    # Verify output
    if min_range is not None and max_range is not None:
        assert min_range >= 0
        assert max_range > min_range


def test_calculate_range_behind_camera() -> None:
    """Test range calculation for target behind camera (negative t)."""
    # Camera with extreme negative Z position and rotation to trigger t <= 0
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
        position_mm=np.array([0.0, 0.0, -10000.0]),  # 10m below mounting
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=1.0,  # Low mounting height
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)
    pixel_coords = (640, 600)  # Below center
    result = estimator.calculate_range_and_bearing(pose, pixel_coords)

    # Should return "Behind camera" when camera below sea level
    assert result.status == Status.BEHIND_CAMERA
    assert result.distance == 0.0
    assert not result.is_valid()


def test_get_horizon_line_no_resolution() -> None:
    """Test get_horizon_line raises ValueError without sensor_resolution."""
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
        # No sensor_resolution
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)

    with pytest.raises(ValueError) as exc_info:
        estimator.get_horizon_line(pose)

    assert "Sensor resolution required" in str(exc_info.value)


def test_get_horizon_line_horizontal() -> None:
    """Test get_horizon_line with nearly horizontal rotation (edge case)."""
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=90.0,  # Roll 90 degrees to trigger r21 ≈ 0 condition
        pitch=0.0,
        yaw=0.0,
        sensor_resolution=(1280, 960),
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)
    p1, p2 = estimator.get_horizon_line(pose)

    # Should return horizontal line through center
    assert isinstance(p1, tuple)
    assert isinstance(p2, tuple)


def test_calculate_total_rotation_matrix() -> None:
    """Test rotation matrix calculation and r_cam_base values.

    This test validates the critical r_cam_base matrix values and ensures
    the total rotation composition is correct. Any change to r_cam_base
    will break this test.
    """
    camera_params = CameraParameters(
        fx=1000.0,
        fy=1000.0,
        cx=640.0,
        cy=480.0,
        roll=0.0,
        pitch=0.0,
        yaw=0.0,
    )

    pose = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=0.0,
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    estimator = ApproximateDistEstimator(camera_params)
    r_total = estimator._calculate_total_rotation(pose)

    # With all angles at 0, total rotation should equal r_cam_base
    # r_cam_base transforms camera optical frame to mounting frame:
    # Camera: Z forward, X right, Y down
    # Mount: X forward, Y left, Z up
    expected_r_cam_base = np.array(
        [
            [0, 0, 1],  # X_mount from camera axes
            [-1, 0, 0],  # Y_mount from camera axes
            [0, -1, 0],  # Z_mount from camera axes
        ]
    )

    np.testing.assert_allclose(r_total, expected_r_cam_base, atol=1e-10)

    # Test with non-zero IMU yaw (90 degrees)
    pose_yaw = SystemPose(
        imu_roll=0.0,
        imu_pitch=0.0,
        imu_yaw=90.0,  # 90 degrees East
        mounting_height_m=7.5,
        ptu_pan=0.0,
        ptu_tilt=0.0,
    )

    r_total_yaw = estimator._calculate_total_rotation(pose_yaw)

    # The rotation matrix should be different from r_cam_base
    assert not np.allclose(r_total_yaw, expected_r_cam_base)

    # Verify it's a valid rotation matrix (orthogonal, det=1)
    assert np.allclose(np.linalg.det(r_total_yaw), 1.0, atol=1e-10)
    identity = r_total_yaw @ r_total_yaw.T
    np.testing.assert_allclose(identity, np.eye(3), atol=1e-10)


@pytest.mark.parametrize(
    "pixel, desc, expected_range, expected_bearing",
    [
        ((320, 360), "Mid-lower center", 124.0, 0.0),
        ((320, 479), "Bottom center", 73.0, 0.0),
        ((0, 360), "Left edge (port)", 152.0, 8.5),
        ((639, 360), "Right edge (starboard)", 107.0, -9.0),
    ],
)
def test_range_and_bearing_known_points(
    coastkeeper_estimator: ApproximateDistEstimator,
    coastkeeper_pose: SystemPose,
    pixel: Tuple[int, int],
    desc: str,
    expected_range: float,
    expected_bearing: float,
) -> None:
    """Test distance estimation against known ground truth points."""
    result = coastkeeper_estimator.calculate_range_and_bearing(coastkeeper_pose, pixel)

    assert_is_valid_estimate(result, desc=desc, check_range=True, check_bearing=True)

    assert result.horizontal_range_m == pytest.approx(
        expected_range, abs=RANGE_TOL_M
    ), f"{desc}: Range mismatch"

    assert result.bearing == pytest.approx(expected_bearing, abs=BEARING_TOL_DEG), (
        f"{desc}: Bearing mismatch"
    )


def test_bottom_pixel_is_closer_than_mid(
    coastkeeper_estimator: ApproximateDistEstimator,
    coastkeeper_pose: SystemPose,
) -> None:
    """Verify that pixels lower in the image correspond to closer distances."""
    mid = coastkeeper_estimator.calculate_range_and_bearing(
        coastkeeper_pose, (320, 360)
    )
    bottom = coastkeeper_estimator.calculate_range_and_bearing(
        coastkeeper_pose, (320, 479)
    )

    assert_is_valid_estimate(bottom, desc="Bottom pixel", check_range=True)
    assert_is_valid_estimate(mid, desc="Mid pixel", check_range=True)

    assert bottom.horizontal_range_m < mid.horizontal_range_m


def test_left_right_bearing_symmetry(
    coastkeeper_estimator: ApproximateDistEstimator,
    coastkeeper_pose: SystemPose,
) -> None:
    """Verify roughly symmetric bearing for symmetric pixels."""
    left = coastkeeper_estimator.calculate_range_and_bearing(coastkeeper_pose, (0, 360))
    right = coastkeeper_estimator.calculate_range_and_bearing(
        coastkeeper_pose, (639, 360)
    )

    assert_is_valid_estimate(left, desc="Left pixel", check_bearing=True)
    assert_is_valid_estimate(right, desc="Right pixel", check_bearing=True)

    # Check absolute sum is small (symmetry)
    assert abs(left.bearing + right.bearing) < BEARING_SYMMETRY_TOL_DEG


def test_image_center_is_far(
    coastkeeper_estimator: ApproximateDistEstimator,
    coastkeeper_pose: SystemPose,
) -> None:
    """Verify that the image center is estimated to be far away."""
    result_center = coastkeeper_estimator.calculate_range_and_bearing(
        coastkeeper_pose, (320, 240)
    )
    assert_is_valid_estimate(
        result_center,
        desc="Center pixel",
        check_range=True,
        check_bearing=False,
    )
    assert result_center.horizontal_range_m > MIN_FAR_DISTANCE_M


def test_top_of_image_above_horizon(
    coastkeeper_estimator: ApproximateDistEstimator,
    coastkeeper_pose: SystemPose,
) -> None:
    """Verify that the top of the image is considered above the horizon."""
    result_top = coastkeeper_estimator.calculate_range_and_bearing(
        coastkeeper_pose, (320, 0)
    )
    # It might be OK but very far, or explicitly ABOVE_HORIZON
    assert result_top.status in {Status.OK, Status.ABOVE_HORIZON}


def test_static_helper_methods() -> None:
    """Test static helper methods for horizon calculations."""
    # Test _hough_params_to_slope_intercept
    rho_h = 100.0
    theta_h = np.pi / 4  # 45 degrees

    k, d = ApproximateDistEstimator._hough_params_to_slope_intercept(rho_h, theta_h)

    # Verify slope and intercept are calculated
    assert isinstance(k, float)
    assert isinstance(d, float)

    # Test _get_hor_points
    resolution = (1280, 960)
    p1, p2 = ApproximateDistEstimator._get_hor_points(rho_h, theta_h, resolution)

    # Verify points are returned
    assert isinstance(p1, tuple)
    assert isinstance(p2, tuple)
    assert len(p1) == 2
    assert len(p2) == 2

    # Test _euler_angles_to_horizon_points
    psi_rc = 0.1
    theta_rc = 0.05
    focal_and_center = (1000.0, 640.0, 480.0)

    p1, p2 = ApproximateDistEstimator._euler_angles_to_horizon_points(
        psi_rc, theta_rc, resolution, focal_and_center
    )

    # Verify horizon points are calculated
    assert isinstance(p1, tuple)
    assert isinstance(p2, tuple)
    assert len(p1) == 2
    assert len(p2) == 2


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])
