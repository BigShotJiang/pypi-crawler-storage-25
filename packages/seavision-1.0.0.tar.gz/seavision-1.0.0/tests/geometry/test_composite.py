import cv2
import numpy as np
import pytest

from seavision.geometry.composite import composite_images, composite_videos
from seavision.geometry.pinhole import Camera


def make_dummy_camera(fx=1000, fy=1000, cx=640, cy=480, roll=0, pitch=0, yaw=0):
    return Camera(
        width=10,
        height=10,
        fx=fx,
        fy=fy,
        cx=cx,
        cy=cy,
        roll=roll,
        pitch=pitch,
        yaw=yaw,
    )


def make_dummy_image(width=10, height=10, value=100):
    return np.full((height, width, 3), value, dtype=np.uint8)


def create_temp_video(path, num_frames, height=10, width=10, value=100, fps=10):
    frames = [make_dummy_image(height, width, value) for _ in range(num_frames)]
    fourcc = cv2.VideoWriter.fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(path), fourcc, fps, (width, height))
    for frame in frames:
        writer.write(frame)
    writer.release()


def test_sanity_checks_more_than_one_camera():
    num_cameras = 1
    images = [make_dummy_image() for _ in range(num_cameras)]
    cameras = [make_dummy_camera() for _ in range(num_cameras)]
    with pytest.raises(ValueError):
        composite_images(images, cameras, master_idx=0)


def test_sanity_checks_invalid_master_idx():
    num_cameras = 3
    images = [make_dummy_image() for _ in range(num_cameras)]
    cameras = [make_dummy_camera() for _ in range(num_cameras)]
    with pytest.raises(ValueError):
        composite_images(images, cameras, master_idx=num_cameras)


def test_sanity_checks_mismatched_lengths():
    images = [make_dummy_image() for _ in range(3)]
    cameras = [make_dummy_camera() for _ in range(4)]
    with pytest.raises(ValueError):
        composite_images(images, cameras, master_idx=0)


def test_composite_images_identity():
    # Multiple identical images and cameras, should return the same as input
    num_cameras = 2
    img = make_dummy_image(value=50)
    images = [img.copy() for _ in range(num_cameras)]
    cameras = [make_dummy_camera() for _ in range(num_cameras)]
    composite = composite_images(images, cameras, master_idx=0)
    assert composite.shape == img.shape
    assert np.allclose(composite, img)


@pytest.mark.parametrize("alpha_blend", [0.0, 0.5, 1.0])
def test_composite_images_different_values(alpha_blend):
    fill_values = [50, 200]
    images = [make_dummy_image(value=val) for val in fill_values]
    cameras = [make_dummy_camera() for _ in range(len(fill_values))]
    composite = composite_images(images, cameras, master_idx=0, alpha_blend=alpha_blend)
    assert composite.shape == images[0].shape

    # Calculate expected blend value
    expected_value = fill_values[0] * (1 - alpha_blend) + fill_values[1] * alpha_blend
    assert np.allclose(composite, expected_value)


def test_composite_videos_invalid_camera_count(tmp_path):
    video_path = tmp_path / "video1.mp4"
    cameras = [make_dummy_camera()]
    with pytest.raises(ValueError):
        composite_videos(
            [str(video_path)],
            cameras,
            master_idx=0,
            output_fpath=str(tmp_path / "out.mp4"),
            progress_bar=False,
        )


def test_composite_videos_invalid_master_idx(tmp_path):
    num_cameras = 2
    video_paths = [tmp_path / f"video{i}.mp4" for i in range(num_cameras)]
    cameras = [make_dummy_camera() for _ in range(num_cameras)]
    with pytest.raises(ValueError):
        composite_videos(
            [str(path) for path in video_paths],
            cameras,
            master_idx=num_cameras,
            output_fpath=str(tmp_path / "out.mp4"),
            progress_bar=False,
        )


def test_composite_videos_mismatched_lengths(tmp_path):
    video_paths = [tmp_path / f"video{i}.mp4" for i in range(2)]
    cameras = [make_dummy_camera() for _ in range(3)]  # Mismatched number of cameras
    with pytest.raises(ValueError):
        composite_videos(
            [str(path) for path in video_paths],
            cameras,
            master_idx=0,
            output_fpath=str(tmp_path / "out.mp4"),
            progress_bar=False,
        )


@pytest.mark.parametrize("alpha_blend", [0.0, 0.5, 1.0])
def test_composite_videos_real_files(tmp_path, alpha_blend):
    num_frames = 10
    fill_values = [50, 200]

    # Create multiple videos with different constant pixel values
    video_paths, cameras = [], []
    for i, value in enumerate(fill_values):
        video_path = tmp_path / f"video{i}.mp4"
        create_temp_video(video_path, num_frames, value=value)
        video_paths.append(video_path)
        cameras.append(make_dummy_camera())

    output_path = tmp_path / "output.mp4"
    result_path = composite_videos(
        [str(path) for path in video_paths],
        cameras,
        master_idx=0,
        output_fpath=str(output_path),
        alpha_blend=alpha_blend,
        progress_bar=False,
    )

    # Calculate expected blend value
    expected_value = fill_values[0] * (1 - alpha_blend) + fill_values[1] * alpha_blend

    # Read the output video and check its frames
    cap = cv2.VideoCapture(str(result_path))
    count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        assert np.allclose(
            frame[..., 0],
            expected_value,
            atol=10,
        )  # Allow for codec errors
        count += 1
    cap.release()
    assert count == num_frames
