import json
import pathlib

import numpy as np
import pytest
from numpy import deg2rad

from seavision.calibration import CalibrationData
from seavision.geometry.pinhole import CameraGeometry
from seavision.geometry.transformations import (
    apply_homography,
    camera_matrix_from_intrinsic,
    convert_rpy,
    homography_from_intrinsics_and_rotation,
    rotation_matrix_from_rpy,
)


@pytest.mark.skip(reason="Auxiliary function")
def load_json(file_path: str) -> dict:
    with pathlib.Path(file_path).open("r", encoding="utf-8") as f:
        data = json.load(f)
    return data


def test_convert_rpy():
    roll, pitch, yaw = 0.1, 0.2, 0.3
    roll_w, pitch_w, yaw_w = convert_rpy(roll, pitch, yaw)
    assert isinstance(roll_w, float)
    assert isinstance(pitch_w, float)
    assert isinstance(yaw_w, float)


def test_rotation_matrix():
    roll, pitch, yaw = deg2rad(10), deg2rad(20), deg2rad(30)
    R = rotation_matrix_from_rpy(roll, pitch, yaw, angle_conversion=False)
    assert R.shape == (3, 3)
    assert isinstance(R, np.ndarray)


def test_intrinsic_matrix():
    fx, fy, cx, cy = 1000, 1000, 640, 480
    K = camera_matrix_from_intrinsic(fx, fy, cx, cy)
    expected = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    assert np.allclose(K, expected)


def test_intrinsic_negated_focal_lengthl():
    fx, fy, cx, cy = 1000, 1000, 640, 480
    K = camera_matrix_from_intrinsic(fx, fy, cx, cy, negated_focal_length=True)
    expected = np.array([[-fx, 0, cx], [0, -fy, cy], [0, 0, 1]])
    assert np.allclose(K, expected)


def test_get_homography():
    R1 = np.eye(3)
    K1 = camera_matrix_from_intrinsic(1000, 1000, 640, 480)
    R2 = np.eye(3)
    K2 = camera_matrix_from_intrinsic(800, 800, 320, 240)
    H = homography_from_intrinsics_and_rotation(K1, R1, K2, R2)
    assert H.shape == (3, 3)
    assert isinstance(H, np.ndarray)

    # Check that H is correct by comparing with the expected result
    H_expected = K2 @ np.linalg.inv(R2) @ R1 @ np.linalg.inv(K1)
    assert np.allclose(H, H_expected)


def test_compute_sentry_homography_v1():
    sensors_info = CalibrationData.from_json(
        "tests/assets/oceanus_sensors/sentry_v1.json"
    )
    h_tn_to_ref = CameraGeometry.compute_homography(
        sensors_info.cameras["t_n"], sensors_info.cameras["t_w"]
    )
    h_tw_to_ref = CameraGeometry.compute_homography(
        sensors_info.cameras["t_w"], sensors_info.cameras["t_w"]
    )
    h_rgbn_to_ref = CameraGeometry.compute_homography(
        CameraGeometry.crop(sensors_info.cameras["rgb_n"], 0, 0, 40, 40),
        sensors_info.cameras["t_w"],
    )
    h_rgbw_to_ref = CameraGeometry.compute_homography(
        CameraGeometry.crop(sensors_info.cameras["rgb_w"], 0, 0, 40, 40),
        sensors_info.cameras["t_w"],
    )
    expected_h_tn_to_ref = np.array(
        [
            [2.5442976e-01, -6.0860440e-03, 2.4085648e02],
            [6.1076302e-03, 2.5451502e-01, 1.8799245e02],
            [-1.2984421e-07, 1.7095878e-07, 9.9999732e-01],
        ]
    )
    expected_h_tw_to_ref = np.eye(3)
    expected_h_rgbn_to_ref = np.array(
        [
            [1.4848404e-01, -1.0627276e-03, 2.3176799e02],
            [1.0712398e-03, 1.4851053e-01, 1.8355579e02],
            [-3.7594813e-08, 5.6614997e-08, 9.9999529e-01],
        ]
    )
    expected_h_rgbw_to_ref = np.array(
        [
            [6.4985752e-01, -7.5074709e-03, -6.7711151e01],
            [7.8420341e-03, 6.4977199e-01, -6.1677780e01],
            [6.7421689e-07, 5.0838884e-07, 9.9935025e-01],
        ]
    )

    assert np.allclose(h_tn_to_ref, expected_h_tn_to_ref, atol=1e-4)
    assert np.allclose(h_tw_to_ref, expected_h_tw_to_ref, atol=1e-4)
    assert np.allclose(h_rgbn_to_ref, expected_h_rgbn_to_ref, atol=1e-4)
    assert np.allclose(h_rgbw_to_ref, expected_h_rgbw_to_ref, atol=1e-4)


def _make_camera_data_v1() -> dict:
    """Minimal v1 camera dict — no stored fx/fy/cx/cy."""
    return {
        "camera_serial_number": "FLIR_12345",
        "position": {"value": [0.0, 0.0, 0.0]},
        "focal_length": {"value": 14.0},
        "pixel_size": {"value": 0.012},
        "barrel_distortion": {"value": 0.0},
        "roll": {"value": 0.0},
        "pitch": {"value": 0.0},
        "yaw": {"value": 0.0},
        "resolution": {"value": [640, 512]},
        "camera_orientation": {"value": 0},
    }


def _make_camera_data_v2() -> dict:
    """V2 camera dict — stored fx/fy/cx/cy differ from focal_length/pixel_size."""
    data = _make_camera_data_v1()
    data["focal_length_x"] = {"value": 1115.9726220290909}
    data["focal_length_y"] = {"value": 1115.9726220290909}
    data["center_x"] = {"value": 320.0}
    data["center_y"] = {"value": 256.0}
    return data


def test_sentry_camera_v1_derives_fx_from_focal_length():
    """V1: fx/fy are focal_length / pixel_size, cx/cy are resolution / 2."""
    cam = CalibrationData._build_camera(_make_camera_data_v1())
    assert cam.fx == pytest.approx(14.0 / 0.012)
    assert cam.fy == pytest.approx(14.0 / 0.012)
    assert cam.cx == pytest.approx(512 / 2.0)  # resolution[1] / 2
    assert cam.cy == pytest.approx(640 / 2.0)  # resolution[0] / 2


def test_sentry_camera_v2_uses_stored_fx_not_derived():
    """V2: stored fx/fy/cx/cy are used directly, not recalculated."""
    cam = CalibrationData._build_camera(_make_camera_data_v2())
    # focal_length/pixel_size = 14.0/0.012 ≈ 1166.67 — must NOT be used
    assert cam.fx == pytest.approx(1115.9726220290909)
    assert cam.fy == pytest.approx(1115.9726220290909)
    assert cam.cx == pytest.approx(320.0)
    assert cam.cy == pytest.approx(256.0)


# Utility function tests
def test_apply_h():
    pts = np.array([[100, 200], [300, 400], [500, 600]])
    H = np.array([[1, 0, 10], [0, 1, 20], [0, 0, 1]])
    transformed_pts = apply_homography(pts, H)
    expected_pts = np.array([[110, 220], [310, 420], [510, 620]])
    assert np.allclose(transformed_pts, expected_pts)
