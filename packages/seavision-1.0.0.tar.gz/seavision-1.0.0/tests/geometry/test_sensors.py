import numpy as np
import pytest

from seavision.geometry.pinhole import Camera, CameraGeometry


def test_camera_from_dict():
    intrinsics = {"fx": 1000, "fy": 1000, "cx": 640, "cy": 480}
    pose = {"roll": 0, "pitch": 0, "yaw": 0}
    resolution = {"width": 1000, "height": 1000}
    cam = Camera.from_dict(intrinsics | pose | resolution)
    assert cam.fx == 1000
    assert cam.fy == 1000
    assert cam.cx == 640
    assert cam.cy == 480
    assert cam.roll == 0
    assert cam.pitch == 0
    assert cam.yaw == 0


def test_camera_intrinsics_matrix():
    cam = Camera(
        width=640, height=512, fx=1000, fy=1000, cx=640, cy=480, roll=0, pitch=0, yaw=0
    )
    assert np.allclose(cam.K, np.array([[1000, 0, 640], [0, 1000, 480], [0, 0, 1]]))


@pytest.mark.parametrize(
    "roll, pitch, yaw, R_expected",
    [
        (
            0.199114171277386,
            0.39245869768489783,
            -11.471167659063088,
            np.array(
                [
                    [0.98001425447846, -0.004767986698393073, -0.19887012677089605],
                    [0.003475109356402738, 0.9999705025685705, -0.006849642890083284],
                    [0.1988969196191569, 0.006021652232118114, 0.9800019158503753],
                ]
            ),
        ),
        (
            0.20368905453676273,
            0.4370690125943514,
            11.268351470605108,
            np.array(
                [
                    [0.9807218456647012, -0.001995927205974537, 0.19539876588814553],
                    [0.0035549337288018, 0.9999645857308144, -0.0076282193456035435],
                    [-0.1953766206131268, 0.008175791019177502, 0.9806942095062074],
                ]
            ),
        ),
    ],
)
def test_camera_rotation_matrix(roll, pitch, yaw, R_expected):
    cam = Camera(
        width=640,
        height=512,
        fx=1000,
        fy=1000,
        cx=640,
        cy=480,
        roll=roll,
        pitch=pitch,
        yaw=yaw,
    )
    assert np.allclose(cam.R, R_expected)


def test_homography_identity_cameras():
    cam1 = Camera(
        width=640, height=512, fx=1000, fy=1000, cx=640, cy=480, roll=0, pitch=0, yaw=0
    )
    cam2 = Camera(
        width=640,
        height=512,
        fx=1000,
        fy=1000,
        cx=640,
        cy=480,
        roll=0,
        pitch=0,
        yaw=0,
    )
    H = CameraGeometry.compute_homography(cam1, cam2)
    assert np.allclose(H, np.eye(3))


@pytest.mark.parametrize(
    "cam1, cam2, H_expected",
    [
        (
            Camera(
                width=3600,
                height=1080,
                fx=839.3537846789975,
                fy=839.5240275429414,
                cx=1766.7120152441128,
                cy=517.3221917218943,
                roll=-0.13610960289333396,
                pitch=0.24322035701659117,
                yaw=0.32440626336371103,
            ),
            Camera(
                width=1280,
                height=498,
                fx=1488.3262887202504,
                fy=1488.225820423565,
                cx=643.3341587294465,
                cy=248.58913740327247,
                roll=0,
                pitch=0.4147638551396246,
                yaw=0,
            ),
            np.array(
                [
                    [0.557227, -0.004917, 1414.16144],
                    [-0.000614, 0.563066, 380.259728],
                    [-0.000004, -0.000002, 1.002927],
                ]
            ),
        ),
    ],
)
def test_homography(cam1, cam2, H_expected):
    H = CameraGeometry.compute_homography(cam2, cam1)
    # Should be a valid 3x3 matrix, not necessarily identity
    assert np.allclose(H, H_expected, atol=1e-6)


# ---------------------------------------------------------------------------
# Camera.from_dict with resolution key
# ---------------------------------------------------------------------------


def test_camera_from_dict_with_resolution_key():
    data = {
        "resolution": [640, 512],
        "fx": 800.0,
        "fy": 800.0,
        "cx": 320.0,
        "cy": 256.0,
        "roll": 0.0,
        "pitch": 1.0,
        "yaw": -2.0,
    }
    cam = Camera.from_dict(data)
    assert cam.width == 640
    assert cam.height == 512
    assert cam.pitch == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Camera.__post_init__ validation
# ---------------------------------------------------------------------------


def test_camera_odd_dimensions_raise_value_error():
    with pytest.raises(ValueError, match="even"):
        Camera(
            width=641,
            height=512,
            fx=800,
            fy=800,
            cx=320,
            cy=256,
            roll=0,
            pitch=0,
            yaw=0,
        )


# ---------------------------------------------------------------------------
# Camera.dict
# ---------------------------------------------------------------------------


def test_camera_dict_returns_all_fields():
    cam = Camera(
        width=640,
        height=512,
        fx=800,
        fy=800,
        cx=320,
        cy=256,
        roll=0.1,
        pitch=0.2,
        yaw=0.3,
    )
    d = cam.dict()
    assert d["width"] == 640
    assert d["fx"] == pytest.approx(800)
    assert d["roll"] == pytest.approx(0.1)


# ---------------------------------------------------------------------------
# Camera.corners
# ---------------------------------------------------------------------------


def test_camera_corners_shape_and_values():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    c = cam.corners
    assert c.shape == (4, 2)
    assert np.allclose(c[0], [0, 0])  # TL
    assert np.allclose(c[1], [640, 0])  # TR
    assert np.allclose(c[2], [640, 512])  # BR
    assert np.allclose(c[3], [0, 512])  # BL


# ---------------------------------------------------------------------------
# Camera.hconcat
# ---------------------------------------------------------------------------


def test_hconcat_doubles_width_and_adjusts_cx():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    wide = Camera.hconcat(cam, cam)
    assert wide.width == 1280
    assert wide.height == 512
    # cx = left.width + (right.cx - left.cx) / 2 = 640 + 0 = 640
    assert wide.cx == pytest.approx(640)


def test_hconcat_different_sizes_raises():
    cam_a = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    cam_b = Camera(
        width=1280, height=512, fx=800, fy=800, cx=640, cy=256, roll=0, pitch=0, yaw=0
    )
    with pytest.raises(ValueError, match="same resolution"):
        Camera.hconcat(cam_a, cam_b)


# ---------------------------------------------------------------------------
# CameraGeometry.create_remap_grids
# ---------------------------------------------------------------------------


def test_create_remap_grids_returns_correct_shapes():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    mapx, mapy = CameraGeometry.create_remap_grids(cam, cam)
    assert mapx.shape == (512, 640)
    assert mapy.shape == (512, 640)


def test_create_remap_grids_identity_camera_maps_to_self():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    mapx, mapy = CameraGeometry.create_remap_grids(cam, cam)
    # Centre pixel should map to itself
    cx, cy = 320, 256
    assert mapx[cy, cx] == pytest.approx(cx, abs=0.5)
    assert mapy[cy, cx] == pytest.approx(cy, abs=0.5)


# ---------------------------------------------------------------------------
# CameraGeometry.project_corners
# ---------------------------------------------------------------------------


def test_project_corners_identity_returns_own_corners():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    projected = CameraGeometry.project_corners(cam, cam)
    assert projected.shape == (4, 2)
    assert np.allclose(projected, cam.corners, atol=1e-3)


# ---------------------------------------------------------------------------
# CameraGeometry.crop_to_frame
# ---------------------------------------------------------------------------


def test_crop_to_frame_exact_match_returns_unchanged_camera():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    frame = np.zeros((512, 640, 3), dtype=np.uint8)
    result = CameraGeometry.crop_to_frame(cam, frame)
    assert result.width == cam.width
    assert result.height == cam.height
    assert result.cx == cam.cx
    assert result.cy == cam.cy


def test_crop_to_frame_smaller_frame_adjusts_intrinsics():
    cam = Camera(
        width=640, height=512, fx=800, fy=800, cx=320, cy=256, roll=0, pitch=0, yaw=0
    )
    # Frame is 40px narrower on each side (80px total) and 20px shorter each side
    frame = np.zeros((472, 560, 3), dtype=np.uint8)
    result = CameraGeometry.crop_to_frame(cam, frame)
    assert result.width == 560
    assert result.height == 472
    assert result.cx == pytest.approx(320 - 40)
