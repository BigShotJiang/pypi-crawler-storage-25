"""Tests for seavision.calibration.server (FastAPI endpoints)."""

import base64
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
from fastapi.testclient import TestClient

from seavision.calibration import CalibrationData
from seavision.calibration.server import (
    _state,
    app,
    configure_server,
    resolve_recording_path,
)
from seavision.calibration.utils import CAMERA_PATTERNS, DEFAULT_REFERENCE_CAMERA

SENTRY_FIXTURE = (
    Path(__file__).resolve().parents[1] / "assets/oceanus_sensors/sentry_v1.json"
)


@pytest.fixture(autouse=True)
def reset_state():
    """Reset global server state before each test."""
    _state.sentry = None
    _state.frames = {}
    _state.recording_path = None
    _state.reference_camera = DEFAULT_REFERENCE_CAMERA
    _state.current_camera = None
    _state.camera_ui_values = {}
    _state.dry_run = False
    _state.recordings_root = None
    yield


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def sentry():
    return CalibrationData.from_json(SENTRY_FIXTURE)


@pytest.fixture
def fake_frames(sentry):
    """Zero-filled frames matching each camera's exact dimensions."""
    return {
        name: np.zeros((cam.height, cam.width, 3), dtype=np.uint8)
        for name, cam in sentry.cameras.items()
    }


@pytest.fixture
def recording_dir(tmp_path):
    """Minimal recording directory with sentry_sensors.json."""
    sensor_dir = tmp_path / "POWER_Const"
    sensor_dir.mkdir()
    (sensor_dir / "sentry_sensors.json").write_bytes(SENTRY_FIXTURE.read_bytes())
    return tmp_path


# ---------------------------------------------------------------------------
# GET /
# ---------------------------------------------------------------------------


def test_index_returns_html(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "html" in resp.headers["content-type"]


# ---------------------------------------------------------------------------
# GET /api/camera_sources
# ---------------------------------------------------------------------------


def test_camera_sources_excludes_reference_camera(client):
    resp = client.get("/api/camera_sources")
    assert resp.status_code == 200
    cameras = set(resp.json()["cameras"])
    assert cameras == set(CAMERA_PATTERNS) - {_state.reference_camera}


# ---------------------------------------------------------------------------
# GET /api/select_camera_source
# ---------------------------------------------------------------------------


def test_select_camera_invalid_camera_returns_400(client):
    resp = client.get("/api/select_camera_source?camera=bad_cam")
    assert resp.status_code == 400


def test_select_camera_no_sentry_returns_zero_defaults(client):
    resp = client.get("/api/select_camera_source?camera=t_n")
    assert resp.status_code == 200
    data = resp.json()
    assert data["camera"] == "t_n"
    assert data["values"] == {"pitch": 0.0, "yaw": 0.0, "roll": 0.0}


def test_select_camera_with_sentry_returns_extrinsics(client, sentry):
    _state.sentry = sentry
    resp = client.get("/api/select_camera_source?camera=t_n")
    assert resp.status_code == 200
    data = resp.json()
    assert data["camera"] == "t_n"
    assert {"pitch", "yaw", "roll"} == set(data["values"])


def test_select_camera_returns_cached_values_on_second_call(client):
    client.get("/api/select_camera_source?camera=t_n")
    _state.camera_ui_values["t_n"]["pitch"] = 5.0
    resp = client.get("/api/select_camera_source?camera=t_n")
    assert resp.json()["values"]["pitch"] == 5.0


# ---------------------------------------------------------------------------
# GET /api/process
# ---------------------------------------------------------------------------


def test_process_no_recording_returns_400(client):
    resp = client.get("/api/process")
    assert resp.status_code == 400


def test_process_no_camera_selected_returns_400(client, sentry, fake_frames):
    _state.sentry = sentry
    _state.frames = fake_frames
    resp = client.get("/api/process")
    assert resp.status_code == 400


def test_process_returns_valid_jpeg_image(client, sentry, fake_frames):
    _state.sentry = sentry
    _state.frames = fake_frames
    _state.current_camera = "t_n"
    resp = client.get("/api/process?pitch=0.0&yaw=0.0&roll=0.0&weight=0.5")
    assert resp.status_code == 200
    data = resp.json()
    assert set(data.keys()) == {"mixed"}
    assert base64.b64decode(data["mixed"])[:2] == b"\xff\xd8"  # JPEG magic bytes


def test_process_updates_camera_ui_values(client, sentry, fake_frames):
    _state.sentry = sentry
    _state.frames = fake_frames
    _state.current_camera = "t_n"
    client.get("/api/process?pitch=1.5&yaw=-2.0&roll=0.3&weight=0.5")
    assert _state.camera_ui_values["t_n"]["pitch"] == pytest.approx(1.5)
    assert _state.camera_ui_values["t_n"]["yaw"] == pytest.approx(-2.0)


# ---------------------------------------------------------------------------
# GET /api/reset_camera
# ---------------------------------------------------------------------------


def test_reset_camera_invalid_camera_returns_400(client):
    resp = client.get("/api/reset_camera?camera=bad_cam")
    assert resp.status_code == 400


def test_reset_camera_no_sentry_returns_400(client):
    resp = client.get("/api/reset_camera?camera=t_n")
    assert resp.status_code == 400


def test_reset_camera_restores_original_extrinsics(client, sentry):
    _state.sentry = sentry
    _state.camera_ui_values["t_n"] = {"pitch": 99.0, "yaw": 99.0, "roll": 99.0}
    resp = client.get("/api/reset_camera?camera=t_n")
    assert resp.status_code == 200
    data = resp.json()
    assert data["camera"] == "t_n"
    assert data["values"]["pitch"] != pytest.approx(99.0)
    assert data["values"] == sentry.cameras["t_n"].extrinsics()


# ---------------------------------------------------------------------------
# GET /api/load_recording
# ---------------------------------------------------------------------------


def test_load_recording_missing_sensors_json_returns_400(client, tmp_path):
    resp = client.get(f"/api/load_recording?path={tmp_path}")
    assert resp.status_code == 400


def test_load_recording_success_sets_state(client, recording_dir):
    fake_sentry = MagicMock()
    fake_frames = {"t_w": np.zeros((512, 640, 3), dtype=np.uint8)}
    with (
        patch("seavision.calibration.server.load_sentry_config") as mock_sentry,
        patch("seavision.calibration.server.load_first_frames") as mock_frames,
    ):
        mock_sentry.return_value = fake_sentry
        mock_frames.return_value = fake_frames
        resp = client.get(f"/api/load_recording?path={recording_dir}")
    assert resp.status_code == 200
    assert resp.json()["status"] == "loaded"
    assert _state.recording_path == str(recording_dir)
    assert _state.sentry is fake_sentry
    assert _state.frames is fake_frames
    assert _state.camera_ui_values == {}


# ---------------------------------------------------------------------------
# GET /api/sensors_json
# ---------------------------------------------------------------------------


def test_sensors_json_no_recording_returns_400(client):
    resp = client.get("/api/sensors_json")
    assert resp.status_code == 400


def test_sensors_json_returns_data_and_pending(client, recording_dir):
    _state.recording_path = str(recording_dir)
    _state.camera_ui_values = {"t_n": {"pitch": 1.0, "yaw": 0.0, "roll": 0.0}}
    resp = client.get("/api/sensors_json")
    assert resp.status_code == 200
    body = resp.json()
    assert "data" in body and "pending" in body
    assert body["pending"] == {"t_n": {"pitch": 1.0, "yaw": 0.0, "roll": 0.0}}


# ---------------------------------------------------------------------------
# GET /api/save_sensors_json
# ---------------------------------------------------------------------------


def test_save_sensors_json_no_recording_returns_400(client):
    resp = client.get("/api/save_sensors_json")
    assert resp.status_code == 400


def test_save_sensors_json_dry_run_does_not_write(client, recording_dir):
    _state.recording_path = str(recording_dir)
    _state.dry_run = True
    _state.camera_ui_values = {"t_w": {"pitch": 9.9, "yaw": 9.9, "roll": 9.9}}
    original = (recording_dir / "POWER_Const" / "sentry_sensors.json").read_bytes()
    resp = client.get("/api/save_sensors_json")
    assert resp.status_code == 200
    assert "dry-run" in resp.json()["status"]
    assert (
        recording_dir / "POWER_Const" / "sentry_sensors.json"
    ).read_bytes() == original


def test_save_sensors_json_writes_values_to_file(client, recording_dir):
    _state.recording_path = str(recording_dir)
    _state.camera_ui_values = {"t_w": {"pitch": 1.5, "yaw": -2.0, "roll": 0.3}}
    resp = client.get("/api/save_sensors_json")
    assert resp.status_code == 200
    assert resp.json()["status"] == "saved"
    data = json.loads(
        (recording_dir / "POWER_Const" / "sentry_sensors.json").read_text(
            encoding="utf-8"
        )
    )
    assert data["cameras"]["t_w"]["pitch"]["value"] == pytest.approx(1.5)
    assert data["cameras"]["t_w"]["yaw"]["value"] == pytest.approx(-2.0)


# ---------------------------------------------------------------------------
# GET /api/browse
# ---------------------------------------------------------------------------


def test_browse_nonexistent_path_returns_400(client, tmp_path):
    resp = client.get(f"/api/browse?path={tmp_path / 'nonexistent'}")
    assert resp.status_code == 400


def test_browse_file_path_returns_400(client, tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("x")
    resp = client.get(f"/api/browse?path={f}")
    assert resp.status_code == 400


def test_browse_returns_only_directories(client, tmp_path):
    (tmp_path / "subdir").mkdir()
    (tmp_path / "file.txt").write_text("x")
    resp = client.get(f"/api/browse?path={tmp_path}")
    assert resp.status_code == 200
    names = [e["name"] for e in resp.json()["entries"]]
    assert "subdir" in names
    assert "file.txt" not in names


def test_browse_flags_recording_directories(client, tmp_path):
    rec = tmp_path / "my_recording"
    rec.mkdir()
    (rec / "POWER_Const").mkdir()
    (rec / "POWER_Const" / "sentry_sensors.json").write_text("{}")
    plain = tmp_path / "plain_dir"
    plain.mkdir()
    resp = client.get(f"/api/browse?path={tmp_path}")
    assert resp.status_code == 200
    entries = {e["name"]: e["is_recording"] for e in resp.json()["entries"]}
    assert entries["my_recording"] is True
    assert entries["plain_dir"] is False


def test_browse_recordings_sorted_before_plain_dirs(client, tmp_path):
    (tmp_path / "zzz_plain").mkdir()
    rec = tmp_path / "aaa_recording"
    rec.mkdir()
    (rec / "POWER_Const").mkdir()
    (rec / "POWER_Const" / "sentry_sensors.json").write_text("{}")
    resp = client.get(f"/api/browse?path={tmp_path}")
    names = [e["name"] for e in resp.json()["entries"]]
    assert names.index("aaa_recording") < names.index("zzz_plain")


def test_browse_returns_resolved_path_and_parent(client, tmp_path):
    resp = client.get(f"/api/browse?path={tmp_path}")
    assert resp.status_code == 200
    body = resp.json()
    assert body["path"] == str(tmp_path.resolve())
    assert body["parent"] == str(tmp_path.resolve().parent)


def test_browse_outside_recordings_root_returns_403(client, tmp_path):
    allowed = tmp_path / "allowed"
    allowed.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    _state.recordings_root = allowed
    resp = client.get(f"/api/browse?path={outside}")
    assert resp.status_code == 403


def test_browse_inside_recordings_root_is_allowed(client, tmp_path):
    _state.recordings_root = tmp_path
    sub = tmp_path / "sub"
    sub.mkdir()
    resp = client.get(f"/api/browse?path={sub}")
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# GET /api/browse_root
# ---------------------------------------------------------------------------


def test_browse_root_returns_home_when_no_root_configured(client):
    resp = client.get("/api/browse_root")
    assert resp.status_code == 200
    assert resp.json()["path"] == str(Path("~").expanduser().resolve())


def test_browse_root_returns_configured_root(client, tmp_path):
    _state.recordings_root = tmp_path
    resp = client.get("/api/browse_root")
    assert resp.status_code == 200
    assert resp.json()["path"] == str(tmp_path)


# ---------------------------------------------------------------------------
# _resolve_recording_path
# ---------------------------------------------------------------------------


def test_resolve_recording_path_no_root_allows_any_path(tmp_path):
    result = resolve_recording_path(str(tmp_path))
    assert result == tmp_path.resolve()


def test_resolve_recording_path_inside_root_is_allowed(tmp_path):
    _state.recordings_root = tmp_path
    sub = tmp_path / "rec"
    sub.mkdir()
    assert resolve_recording_path(str(sub)) == sub.resolve()


def test_resolve_recording_path_outside_root_raises(tmp_path):
    allowed = tmp_path / "allowed"
    allowed.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    _state.recordings_root = allowed
    with pytest.raises(ValueError, match="outside recordings root"):
        resolve_recording_path(str(outside))


# ---------------------------------------------------------------------------
# _configure_server
# ---------------------------------------------------------------------------


def test_configure_server_sets_dry_run():
    configure_server(dry_run=True)
    assert _state.dry_run is True


def test_configure_server_sets_recordings_root(tmp_path):
    configure_server(recordings_root=str(tmp_path))
    assert _state.recordings_root == tmp_path.resolve()


def test_configure_server_sets_valid_reference_camera():
    valid = next(iter(CAMERA_PATTERNS))
    configure_server(reference_camera=valid)
    assert _state.reference_camera == valid


def test_configure_server_raises_on_unknown_reference_camera():
    with pytest.raises(SystemExit):
        configure_server(reference_camera="not_a_real_camera")


def test_configure_server_loads_recording(recording_dir):
    fake_sentry = MagicMock()
    fake_frames = {"t_w": np.zeros((512, 640, 3), dtype=np.uint8)}
    with (
        patch("seavision.calibration.server.load_sentry_config") as mock_sentry,
        patch("seavision.calibration.server.load_first_frames") as mock_frames,
    ):
        mock_sentry.return_value = fake_sentry
        mock_frames.return_value = fake_frames
        configure_server(recording_path=str(recording_dir))
    assert _state.sentry is fake_sentry
    assert _state.frames is fake_frames
    assert _state.current_camera is None


def test_configure_server_no_recording_leaves_state_empty():
    configure_server()
    assert _state.sentry is None
    assert _state.recording_path is None
