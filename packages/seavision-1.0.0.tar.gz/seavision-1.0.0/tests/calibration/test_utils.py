"""Tests for seavision.calibration.utils (pure helpers only)."""

import base64
import json
from pathlib import Path

import cv2
import numpy as np
import pytest

from seavision.calibration import CalibrationData
from seavision.calibration.utils import (
    blend_rgb,
    get_available_recordings,
    get_video_path,
    image_to_base64,
    load_sentry_config,
    process_calibration,
    read_sensors_json,
    source_cameras_for_reference,
    update_sensors_json,
)

SENTRY_FIXTURE = (
    Path(__file__).resolve().parents[1] / "assets/oceanus_sensors/sentry_v1.json"
)


@pytest.fixture
def sentry_recording(tmp_path):
    sensor_dir = tmp_path / "POWER_Const"
    sensor_dir.mkdir()
    (sensor_dir / "sentry_sensors.json").write_bytes(SENTRY_FIXTURE.read_bytes())
    (tmp_path / "TwFoV_record.avi").touch()
    return tmp_path


@pytest.fixture
def recording_dir(tmp_path):
    sensor_dir = tmp_path / "POWER_Const"
    sensor_dir.mkdir()
    data = {
        "cameras": {
            "t_w": {
                "pitch": {"value": 0.0},
                "yaw": {"value": 0.0},
                "roll": {"value": 0.0},
                "focal_length": {"value": 6.0},
            },
            "rgb_n": {
                "pitch": {"value": 0.0},
                "yaw": {"value": 0.0},
                "roll": {"value": 0.0},
                "focal_length": {"value": 5.0},
            },
        }
    }
    (sensor_dir / "sentry_sensors.json").write_text(json.dumps(data), encoding="utf-8")
    return tmp_path


def test_blend_rgb_weight_extremes() -> None:
    a = np.zeros((4, 4, 3), dtype=np.uint8)
    a[:, :, 0] = 200
    b = np.zeros((4, 4, 3), dtype=np.uint8)
    b[:, :, 2] = 200
    np.testing.assert_array_equal(blend_rgb(a, b, 1.0), a)
    np.testing.assert_array_equal(blend_rgb(a, b, 0.0), b)


def test_update_sensors_json(recording_dir) -> None:
    update_sensors_json(
        str(recording_dir), {"t_w": {"pitch": 1.5, "yaw": -2.3, "roll": 0.7}}
    )
    path = recording_dir / "POWER_Const" / "sentry_sensors.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    tw = data["cameras"]["t_w"]
    assert tw["pitch"]["value"] == pytest.approx(1.5)
    assert tw["yaw"]["value"] == pytest.approx(-2.3)
    assert tw["roll"]["value"] == pytest.approx(0.7)
    # other camera and unrelated keys unchanged
    assert data["cameras"]["rgb_n"]["pitch"]["value"] == 0.0
    assert tw["focal_length"]["value"] == 6.0


def test_image_to_base64_round_trip() -> None:
    img = np.zeros((8, 8, 3), dtype=np.uint8)
    img[:, :, 0] = 200
    raw = base64.b64decode(image_to_base64(img))
    decoded = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
    assert decoded is not None
    assert decoded.shape == img.shape


def test_update_sensors_json_writes_multiple_cameras_in_one_pass(recording_dir) -> None:
    updates = {
        "t_w": {"pitch": 1.5, "yaw": -2.3, "roll": 0.7},
        "rgb_n": {"pitch": 0.1, "yaw": 0.2, "roll": 0.3},
    }
    update_sensors_json(str(recording_dir), updates)
    path = recording_dir / "POWER_Const" / "sentry_sensors.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["cameras"]["t_w"]["pitch"]["value"] == pytest.approx(1.5)
    assert data["cameras"]["t_w"]["yaw"]["value"] == pytest.approx(-2.3)
    assert data["cameras"]["rgb_n"]["pitch"]["value"] == pytest.approx(0.1)


def test_source_cameras_excludes_reference() -> None:
    sources = source_cameras_for_reference("t_w")
    assert "t_w" not in sources
    assert set(sources) == {"t_n", "rgb_w", "rgb_n"}


def test_source_cameras_order_is_stable() -> None:
    assert source_cameras_for_reference("t_w") == ["t_n", "rgb_w", "rgb_n"]
    assert source_cameras_for_reference("t_n") == ["t_w", "rgb_w", "rgb_n"]


def test_source_cameras_unknown_reference_raises() -> None:
    with pytest.raises(ValueError, match="Unknown camera"):
        source_cameras_for_reference("bad_camera")


def test_load_sentry_config_returns_calibration_data(sentry_recording) -> None:
    result = load_sentry_config(str(sentry_recording))
    assert isinstance(result, CalibrationData)
    assert set(result.cameras.keys()) == {"t_w", "t_n", "rgb_w", "rgb_n"}


def test_load_sentry_config_invalid_reference_raises(sentry_recording) -> None:
    with pytest.raises(ValueError, match="Unknown reference camera"):
        load_sentry_config(str(sentry_recording), reference_camera="bad_cam")


def test_load_sentry_config_missing_video_raises(tmp_path) -> None:
    """No matching AVI file → FileNotFoundError."""
    sensor_dir = tmp_path / "POWER_Const"
    sensor_dir.mkdir()
    (sensor_dir / "sentry_sensors.json").write_bytes(SENTRY_FIXTURE.read_bytes())
    # Deliberately no AVI file
    with pytest.raises(FileNotFoundError, match="No t_w video"):
        load_sentry_config(str(tmp_path))


# ---------------------------------------------------------------------------
# get_available_recordings
# ---------------------------------------------------------------------------


def test_get_available_recordings_returns_valid_subdirs(tmp_path) -> None:
    # rec_a, rec_b: valid (have POWER_Const/sentry_sensors.json)
    # no_json: has POWER_Const but no JSON file
    # not_a_rec: plain directory, no POWER_Const at all
    for name in ("rec_a", "rec_b", "no_json", "not_a_rec"):
        (tmp_path / name).mkdir()
    for name in ("rec_a", "rec_b"):
        sensor_dir = tmp_path / name / "POWER_Const"
        sensor_dir.mkdir()
        (sensor_dir / "sentry_sensors.json").write_text("{}", encoding="utf-8")
    (tmp_path / "no_json" / "POWER_Const").mkdir()
    result = get_available_recordings(str(tmp_path))
    assert set(result) == {"rec_a", "rec_b"}
    assert "not_a_rec" not in result
    assert "no_json" not in result


# ---------------------------------------------------------------------------
# get_video_path
# ---------------------------------------------------------------------------


def test_get_video_path_unknown_camera_returns_none(tmp_path) -> None:
    assert get_video_path(str(tmp_path), "nonexistent_camera") is None


def test_get_video_path_known_camera_no_file_returns_none(tmp_path) -> None:
    # t_w is a valid camera name but no matching AVI exists in the directory
    assert get_video_path(str(tmp_path), "t_w") is None


# ---------------------------------------------------------------------------
# read_sensors_json
# ---------------------------------------------------------------------------


def test_read_sensors_json_returns_dict(recording_dir) -> None:
    data = read_sensors_json(str(recording_dir))
    assert isinstance(data, dict)
    assert "cameras" in data


# ---------------------------------------------------------------------------
# process_calibration error paths
# ---------------------------------------------------------------------------


@pytest.fixture
def sentry() -> CalibrationData:
    return CalibrationData.from_json(SENTRY_FIXTURE)


@pytest.fixture
def fake_frames(sentry) -> dict:
    return {
        name: np.zeros((cam.height, cam.width, 3), dtype=np.uint8)
        for name, cam in sentry.cameras.items()
    }


def test_process_calibration_same_source_and_ref_raises(sentry, fake_frames) -> None:
    with pytest.raises(ValueError, match="must differ"):
        process_calibration(
            sentry, fake_frames, "t_w", 0, 0, 0, 0.5, reference_camera="t_w"
        )


def test_process_calibration_invalid_source_raises(sentry, fake_frames) -> None:
    with pytest.raises(ValueError, match="Invalid source"):
        process_calibration(
            sentry, fake_frames, "bad_cam", 0, 0, 0, 0.5, reference_camera="t_w"
        )
