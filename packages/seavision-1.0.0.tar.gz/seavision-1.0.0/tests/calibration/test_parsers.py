"""Tests for :class:`~seavision.calibration.CalibrationData` (JSON parser)."""

from pathlib import Path

import pytest

from seavision.calibration import CalibrationData

SENTRY_FIXTURE = (
    Path(__file__).resolve().parents[1] / "assets/oceanus_sensors/sentry_v1.json"
)


def test_calibration_data_from_sentry_json() -> None:
    cal = CalibrationData.from_json(SENTRY_FIXTURE)
    assert isinstance(cal, CalibrationData)
    assert set(cal.cameras.keys()) == {"t_w", "t_n", "rgb_w", "rgb_n"}

    rgb_w = cal.cameras["rgb_w"]
    assert rgb_w.size == (1280, 960)
    assert rgb_w.fx == pytest.approx(8.0 / 0.004455)
    assert rgb_w.fy == rgb_w.fx
    assert rgb_w.cx == 640.0
    assert rgb_w.cy == 480.0


def test_calibration_data_legacy_intrinsics_format(tmp_path: Path) -> None:
    path = tmp_path / "legacy.json"
    path.write_text(
        """
{
  "cameras": {
    "cam_a": {
      "resolution": {"value": [1920, 1080], "unit": "1"},
      "focal_length_x": {"value": 1000.0, "unit": "px"},
      "focal_length_y": {"value": 1000.0, "unit": "px"},
      "center_x": {"value": 960.0, "unit": "px"},
      "center_y": {"value": 540.0, "unit": "px"},
      "roll": {"value": 0.0, "unit": "deg"},
      "pitch": {"value": 0.0, "unit": "deg"},
      "yaw": {"value": 0.0, "unit": "deg"}
    }
  }
}
""",
        encoding="utf-8",
    )
    cal = CalibrationData.from_json(path)
    cam = cal.cameras["cam_a"]
    assert cam.width == 1920
    assert cam.height == 1080
    assert cam.fx == 1000.0
    assert cam.cy == 540.0
