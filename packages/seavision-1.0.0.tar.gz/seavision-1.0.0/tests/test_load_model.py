"""Test loading models from seavision."""

import pytest
from huggingface_hub import list_repo_files
from pytest import MonkeyPatch, TempPathFactory

from seavision import list_models, load_model


def test_load_onnx_models_from_hf():
    """Test loading onnx models."""
    repo_files = list_repo_files(repo_id="SEA-AI/seavision", repo_type="model")
    # get onnx files only in parent directory
    onnx_files = [f for f in repo_files if ".onnx" in f if "/" not in f]
    for f in onnx_files:
        load_model(f)


@pytest.mark.parametrize(
    "model_id",
    [
        "YOLOv5n-IR:latest",
        "sea-ai/yolo-train/run_4r1jwzav_model:v0",
    ],
)
def test_load_model_from_wandb(
    model_id, monkeypatch: MonkeyPatch, tmp_path: TempPathFactory
):
    """Test loading models from W&B; downloads go to a temp folder."""
    monkeypatch.setenv("WANDB_ARTIFACT_DIR", str(tmp_path))
    model = load_model(model_id)
    assert model is not None


def test_list_models():
    """Test listing models."""
    models = list_models()
    assert len(models) > 0
