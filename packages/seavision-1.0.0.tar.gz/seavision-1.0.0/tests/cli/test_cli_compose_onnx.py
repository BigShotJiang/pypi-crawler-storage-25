from unittest.mock import patch

from seavision.cli import cli


@patch("seavision.deployment.compose_onnx.merge_onnx_models")
def test_compose_onnx_command_defaults(
    mock_merge_onnx_models, cli_runner, silence_cli_print_banner
):
    """Ensure compose-onnx forwards required args with default options."""
    result = cli_runner.invoke(
        cli,
        ["compose-onnx", "model1.onnx", "model2.onnx", "merged.onnx"],
    )

    assert result.exit_code == 0
    mock_merge_onnx_models.assert_called_once_with(
        "model1.onnx",
        "model2.onnx",
        "merged.onnx",
        prefix1="",
        prefix2="",
        force_fp32=False,
    )


@patch("seavision.deployment.compose_onnx.merge_onnx_models")
def test_compose_onnx_command_with_options(
    mock_merge_onnx_models, cli_runner, silence_cli_print_banner
):
    """Ensure compose-onnx forwards optional flags/values correctly."""
    result = cli_runner.invoke(
        cli,
        [
            "compose-onnx",
            "ahoy-IR-b2.onnx",
            "ahoy-RGB-b2.onnx",
            "models/dan-b2.onnx",
            "--prefix1",
            "ir_",
            "--prefix2",
            "rgb_",
            "--force-fp32",
        ],
    )

    assert result.exit_code == 0
    mock_merge_onnx_models.assert_called_once_with(
        "ahoy-IR-b2.onnx",
        "ahoy-RGB-b2.onnx",
        "models/dan-b2.onnx",
        prefix1="ir_",
        prefix2="rgb_",
        force_fp32=True,
    )
