from typing import Any

import numpy as np
import pytest

from seavision.cli.inference import get_source, inference


@pytest.fixture
def mock_image():
    return np.zeros((100, 100, 3), dtype=np.uint8)


@pytest.fixture
def mock_model(monkeypatch):
    class MockModel:
        det_conf_thresh = 0.15
        det_iou_thresh = 0.1
        hor_conf_thresh = 0.1

        def __call__(self, image) -> "MockResults":
            return MockResults()

    class MockResults:
        @staticmethod
        def draw(image, show_horizon=True, show_labels=False) -> np.ndarray:
            return image

    monkeypatch.setattr("seavision.load_model", lambda path: MockModel())
    return MockModel()


def test_get_source_with_image(monkeypatch, mock_image):
    """Ensure get_source returns image array when given a file path."""
    monkeypatch.setattr("seavision.imread", lambda path: mock_image)
    monkeypatch.setattr(
        "seavision.VideoReader",
        lambda *a, **kw: (_ for _ in ()).throw(Exception("Should not be called")),
    )

    result = get_source("image.jpg")
    assert isinstance(result, np.ndarray)
    assert result.shape == (100, 100, 3)


@pytest.mark.parametrize("source", ["webcam", "webcam:0", "rtsp://stream", "video.mp4"])
def test_get_source_with_video(monkeypatch, source):
    """Ensure get_source returns VideoReader for video-like sources."""

    class MockVideoReader:
        def __init__(self, *args: Any, **kwargs: Any) -> None:  # noqa: ANN401
            pass

    monkeypatch.setattr(
        "seavision.imread",
        lambda path: (_ for _ in ()).throw(Exception("Should not be called")),
    )
    monkeypatch.setattr("seavision.VideoReader", MockVideoReader)

    result = get_source(source)
    assert isinstance(result, MockVideoReader)


def test_inference_image_input(cli_runner, monkeypatch, mock_model, tmp_path):
    """Run inference command on image and check output is saved."""
    image_url = "https://raw.githubusercontent.com/SEA-AI/.github/main/assets/sailing_rgb_320.jpg"
    save_path = tmp_path / "out.jpg"

    monkeypatch.setattr("seavision.imshow", lambda *_: None)
    monkeypatch.setattr("seavision.waitkey", lambda *_: 0)

    result = cli_runner.invoke(inference, [image_url, "--save", str(save_path)])

    assert result.exit_code == 0
    assert save_path.exists()
    assert save_path.stat().st_size > 0


def test_inference_video_input(cli_runner, monkeypatch, mock_model, tmp_path):
    """Run inference on video and exit cleanly after simulated key press."""
    video_url = "https://streams.videolan.org/samples/MPEG-4/video.mp4"
    save_path = tmp_path / "out.mp4"

    monkeypatch.setattr("seavision.imshow", lambda *_: None)
    monkeypatch.setattr("time.sleep", lambda *_: None)

    # Simulate 'q' after ~30 frames
    calls = {"count": 0}
    monkeypatch.setattr(
        "seavision.waitkey",
        lambda d: (
            ord("q")
            if (calls.update(count=calls["count"] + 1) or calls["count"]) > 30
            else 0
        ),
    )

    result = cli_runner.invoke(inference, [video_url, "--save", str(save_path)])

    assert result.exit_code == 0
    assert save_path.exists()
    assert save_path.stat().st_size > 0
