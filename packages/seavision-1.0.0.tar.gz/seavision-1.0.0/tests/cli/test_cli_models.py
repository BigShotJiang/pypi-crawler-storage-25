from typing import List, Optional
from unittest.mock import patch

from seavision.cli.models import models


def test_models_command(cli_runner):
    """Test that the models command group works."""
    result = cli_runner.invoke(models)
    assert "Manage SeaVision models" in result.output


def test_list_command_default(cli_runner, monkeypatch):
    """Test the list command with default options."""

    # Mock the list_models function to return a list of models
    def mock_list_models(extension=None) -> List[str]:
        return ["model1.onnx", "model2.onnx", "nested/model3.onnx"]

    monkeypatch.setattr("seavision.list_models", mock_list_models)

    result = cli_runner.invoke(models, ["list"])

    assert result.exit_code == 0
    assert "Available SeaVision models:" in result.output
    assert "  - model1.onnx" in result.output
    assert "  - model2.onnx" in result.output
    assert (
        "  - nested/model3.onnx" not in result.output
    )  # Nested models should be filtered out by default


@patch("seavision.cli.models.sv.list_models")
def test_list_command_all(mock_list_models, cli_runner):
    """Test the list command with --all flag."""
    # Mock the list_models function to return a list of models
    mock_list_models.return_value = ["model1.onnx", "model2.onnx", "nested/model3.onnx"]

    result = cli_runner.invoke(models, ["list", "--all"])

    assert result.exit_code == 0
    assert "Available SeaVision models:" in result.output
    assert "  - model1.onnx" in result.output
    assert "  - model2.onnx" in result.output
    assert (
        "  - nested/model3.onnx" in result.output
    )  # Nested models should be included with --all


def test_list_command_ext(cli_runner, monkeypatch):
    """Test the list command with --ext flag."""
    seen_extensions: List[Optional[str]] = []

    def mock_list_models(extension=None) -> List[str]:
        seen_extensions.append(extension)
        # Top-level .pt must be present in the unfiltered set so passing
        # ``--ext onnx`` is what keeps ".pt" out of the printed list (the CLI
        # forwards ``extension`` to ``list_models``, like ``list_hf_models``).
        candidates = ["model1.onnx", "model2.onnx", "model3.pt"]
        if extension == "onnx":
            return [m for m in candidates if m.endswith(".onnx")]
        return candidates

    monkeypatch.setattr("seavision.list_models", mock_list_models)

    result = cli_runner.invoke(models, ["list", "--ext", "onnx"])

    assert result.exit_code == 0
    assert seen_extensions == ["onnx"]
    assert ".onnx" in result.output
    assert ".pt" not in result.output
