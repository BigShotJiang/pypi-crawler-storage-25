"""Tests for CLI utility functions."""

from unittest.mock import patch

import click
import pytest

from seavision.cli.utils import echo_resolved_command, print_banner


@pytest.mark.parametrize("system", ["Darwin", "Linux", "Windows", "Jetson"])
def test_print_banner(capsys, system):
    """Test that print_banner outputs expected format."""
    with (
        patch("platform.system", return_value=system),
        patch("platform.python_version", return_value="3.9.0"),
        patch("platform.release", return_value="21.0.0"),
        patch("platform.machine", return_value="x86_64"),
        patch("psutil.virtual_memory") as mock_mem,
        patch("psutil.cpu_count", return_value=8),
        patch("random.choice", return_value="⚓"),
    ):
        # Mock memory info
        mock_mem.return_value.total = 16 * 1024**3  # 16 GB

        print_banner()
        captured = capsys.readouterr()

        # Check that key components are in the output
        assert "SeaVision" in captured.out
        assert "Python 3.9.0" in captured.out
        assert system in captured.out
        assert "16 GB RAM" in captured.out
        assert "8 threads" in captured.out


def test_echo_resolved_command(capsys, cli_runner):
    """Test that echo_resolved_command decorator works as expected."""

    @click.command()
    @click.option("--test-param", type=str)
    @echo_resolved_command
    def test_fn(test_param) -> None:
        print(test_param)

    # Create a context and invoke the command
    result = cli_runner.invoke(test_fn, ["--test-param", "test_value"])

    assert "test-fn --test-param test_value" in result.output
    assert result.output.strip().endswith("test_value")
