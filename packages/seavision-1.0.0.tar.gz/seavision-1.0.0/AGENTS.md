# AGENTS.md

This file guides AI coding assistants (e.g. Claude Code, Cursor) when working in this repository.

## Commands

```bash
# Install dependencies (use uv, not pip)
uv sync                    # main + dev dependencies
uv sync --all-extras       # include optional extras (e.g. fiftyone)

# Linting and formatting
uvx ruff check --fix       # lint and auto-fix
uvx ruff format            # format code

# Testing
uv run pytest              # run all tests
uv run pytest tests/path/to/test_file.py  # run a single test file
uv run pytest -k "test_name"              # run tests matching a pattern
uv run pytest --cov        # run with coverage (default in pytest.ini)

# Documentation
uvx mkdocs serve           # serve docs locally

# Pre-commit hooks
uvx pre-commit install     # install hooks
uvx pre-commit run --all-files  # run all hooks manually

# CLI (after install)
seavision models list
seavision inference <path>
seavision calibration
```

## Architecture

SeaVision is a Python computer vision library for maritime/naval applications (ship detection, thermal imaging, horizon detection, sensor fusion). It supports Python 3.9–3.12.

### Module Overview

- **`inference/`** — Core module. Model loading, preprocessing, postprocessing, and inference pipelines. Contains model implementations: AHOY (multi-modal), DAN (dual YOLO), HOLY, RAHI (region-based), SAHI (sliced), LouisNet, SeaYOLO. Supports TensorRT, ONNX2Torch, and TensorFlow backends.
- **`io/`** — VideoReader/VideoWriter with multi-threaded queue-based reading. Handles webcam, RTSP, local files. `VideoFormatRegistry` allows extensible format handlers.
- **`geometry/`** — Immutable pinhole `Camera` (intrinsics/pose) and `CameraGeometry` helpers in `pinhole.py`. Composite image/video utilities for multi-sensor layouts. Distance / JSON config types live in `distance.py`.
- **`calibration/`** — FastAPI-based web UI for interactive camera extrinsic tuning (pitch/yaw/roll).
- **`transforms/`** — Image/video processing: normalization, enhancement, color conversion.
- **`sensorfusion/`** — Multi-sensor fusion: NMS and Weighted Boxes Fusion (WBF, the primary algorithm).
- **`deployment/`** — Model format conversion: ONNX → TRT composition utilities.
- **`cli/`** — Click-based CLI entry point (`seavision` command).
- **`utils/`** — Logging, HuggingFace Hub downloads, ONNX utilities.
- **`fiveone/`** — Optional FiftyOne dataset integration (excluded from coverage).
- **`experimental/`** — Zoom and video embedding experiments.

### Key Patterns

**Inference pipeline:**
```python
output = postprocess(model.forward(preprocess(inputs)))
```

**Abstract base classes:** `Model` (all inference models), `Infer` (inference engine backends), `SensorFusion` (fusion algorithms).

**Factory pattern:** `ModelFactory` loads models from HuggingFace Hub, local ONNX files, TensorRT engines, or W&B. Enum-based model variants select specific configurations.

**Results datamodel:** Immutable dataclasses (`Results`, `Object`, `BBox`, `Horizon`, `Line`) with coordinate helpers (normalized ↔ absolute pixels), FiftyOne export, and drawing/visualization support.

**Public API entry point:**
```python
import seavision as sv
model = sv.load_model("ahoyv2n-MIX-b1")
results = model(image)
results.draw(image).show()
```

### Testing

Tests mirror the source structure. Fixtures in `tests/conftest.py` provide sample `Results` with boats, ships, and horizon data. Test assets in `tests/assets/` include sensor configs (legacy/oceanus/standard). Some tests fetch images from GitHub; set a local asset folder env var for offline testing.

- **`ffmpeg`** must be installed on the system (used by `av` / `ffmpeg-python`); without it, video-related tests and code paths can fail.
- Some tests download models from **Hugging Face** or **Weights & Biases** and need **`HF_TOKEN`** and **`WANDB_API_KEY`**; those tests fail without the secrets, while the rest of the suite can still pass.

Coverage excludes `fiveone/`, TensorRT code, and the HOLY model.

### Code Style

- Ruff enforces Google-style docstrings, 88-char line length, and 14 rule categories (D, E, F, W, ANN, B, TC, PTH, NPY, TID, SIM, I, PL, ERA).
- Single-letter variable names are allowed for matrix conventions: `K` (camera intrinsics), `R` (rotation), `H` (homography), `B` (batch), `C` (channels), `W` (width), `G` (grayscale).
- Heavy dependencies (torch, cv2, onnx) use lazy imports (import-outside-toplevel is allowed); type-only imports go in `TYPE_CHECKING` blocks.
- Max 10 args/attributes per function or class.

### CI

The CI pipeline (`.github/workflows/ci.yaml`) detects changed files and runs Ruff, Pylint, SonarQube, and pytest only on affected code. PRs target the `develop` branch.
