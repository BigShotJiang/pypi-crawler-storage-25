"""Tests for ldapgate."""
