# Connecting LDAPGate to a Corporate AD/NiFi LDAP Setup

This guide documents how to configure LDAPGate to authenticate against the same
Active Directory LDAP server that NiFi uses, including extracting the required TLS
certificates from NiFi's Java keystores.

## Prerequisites

- Access to the NiFi server's `conf/` directory (read-only is sufficient)
- `keytool` (ships with Java — available wherever NiFi is installed)
- `openssl` (standard on RHEL/CentOS/Ubuntu)
- The keystore and truststore passwords from `login-identity-providers.xml`

---

## Step 1: Find your LDAP settings in NiFi

Open `$NIFI_HOME/conf/login-identity-providers.xml` and locate the `ldap-provider` block.
The values you need:

| NiFi property         | LDAPGate config key     | Notes                                      |
|-----------------------|-------------------------|--------------------------------------------|
| Url                   | `ldap.url`              | e.g. `ldaps://ldap-server.corp.com:3269`   |
| Manager DN            | `ldap.bind_dn`          | See bind DN note below                     |
| Manager Password      | `ldap.bind_password`    | See password note below                    |
| User Search Base      | `ldap.base_dn`          |                                            |
| User Search Filter    | `ldap.user_filter`      | Replace `{0}` with `{username}`            |

### Password note: check if it is encrypted

If `nifi.sensitive.props.key` in `nifi.properties` is non-empty, NiFi _may_ have
encrypted its sensitive properties. Encrypted values are wrapped in `enc{...}`.
If the Manager Password does **not** have that wrapper, it is stored in plaintext
and is the actual password.

Quickest verification: try logging into NiFi directly with the Manager DN username
and that password. If it works, the password is correct as-is.

### Bind DN note: bare username may work

NiFi's `Manager DN` field sometimes contains just a bare `sAMAccountName` (e.g.
`svcaccount`) rather than a full DN or UPN. Some AD servers accept this for SIMPLE
bind. If UPN formats like `svcaccount@corp.com` or `DOMAIN\svcaccount` all return
error `49 / data 52e`, try the bare username as `bind_dn`.

---

## Step 2: Extract the client certificate from NiFi's keystore

NiFi uses a Java KeyStore (`.jks`). Python's `ldap3` needs PEM format. Convert it:

```bash
# 1. List aliases to find the cert name
keytool -list \
  -keystore $NIFI_HOME/conf/keystore.jks \
  -storepass <keystore-password>

# 2. Export the keystore to PKCS12
keytool -importkeystore \
  -srckeystore $NIFI_HOME/conf/keystore.jks \
  -destkeystore /tmp/client.p12 \
  -deststoretype PKCS12 \
  -srcstorepass <keystore-password> \
  -deststorepass changeit

# 3. Split into cert and key PEM files
openssl pkcs12 -in /tmp/client.p12 -passin pass:changeit -nokeys -out /tmp/client.crt
openssl pkcs12 -in /tmp/client.p12 -passin pass:changeit -nocerts -nodes -out /tmp/client.key
```

---

## Step 3: Sort out the CA certificate

### Option A: Check if the system already trusts the server cert

```bash
openssl s_client -connect <ldap-host>:<port> < /dev/null 2>&1 | grep "Verify return code"
```

- `Verify return code: 0 (ok)` → your system trusts it. Point LDAPGate at the
  system CA bundle:

  ```yaml
  tls_ca_cert_file: /etc/pki/tls/certs/ca-bundle.crt  # RHEL/CentOS
  # or: /etc/ssl/certs/ca-certificates.crt             # Debian/Ubuntu
  tls_validate: REQUIRED
  ```

- Any other code → the cert is self-signed or uses an internal CA not in your
  system bundle. Use `tls_validate: NONE` (see Option B).

### Option B: Internal CA or self-signed — skip validation

On a trusted internal network this is acceptable:

```yaml
tls_validate: NONE
```

### What did NOT work (for reference)

- Exporting the CA cert from `truststore.jks` with `keytool -exportcert` and
  pointing `tls_ca_cert_file` at it — the exported cert did not match the server's
  issuer chain.
- Pulling the chain with `openssl s_client -showcerts` and using it as
  `tls_ca_cert_file` — same result.
- The system CA bundle (`Verify return code: 0`) was the solution.

---

## Step 4: Complete LDAPGate config

```yaml
ldap:
  url: ldaps://<ldap-host>:<port>
  bind_dn: <manager-dn-or-bare-username>
  bind_password: "<manager-password>"
  base_dn: "DC=domain,DC=corp,DC=com"
  user_filter: "(sAMAccountName={username})"
  use_starttls: false          # ldaps:// already does TLS at connect time
  tls_client_cert_file: /path/to/client.crt
  tls_client_key_file: /path/to/client.key
  tls_ca_cert_file: /etc/pki/tls/certs/ca-bundle.crt  # or omit if tls_validate: NONE
  tls_validate: REQUIRED       # or NONE if system bundle doesn't trust the cert
  follow_referrals: true
  timeout: 10

proxy:
  backend_url: http://your-backend:port
  secret_key: "<random-secret>"
  listen_port: 9000
  session_ttl: 43200           # 12 hours, matching NiFi's default expiration
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `49 / data 52e` on all UPN formats | Try bare `sAMAccountName` as `bind_dn` | See bind DN note above |
| `49 / data 52e` with correct bind DN | Mutual TLS required — no client cert | Extract certs from keystore.jks |
| `ssl verify failed` | Wrong CA cert | Use system bundle or set `tls_validate: NONE` |
| `49 / data 525` | User not found | Check `base_dn` and `user_filter` |
| Password looks like ciphertext | NiFi sensitive props encryption | Verify by logging into NiFi directly |
