# TODO

## 1. LDAPGate — Update README for corp setups
Update ldapgate readme to explain usage config with corp setups.
(Reference `docs/nifi-ldap-integration.md` written today.)
Also mention `ldap_check.py` as a pre-flight check script — add it to the README
so people can verify their setup before configuring LDAPGate.

## 2. Copyparty — WebDAV mount (net use) broken with LDAPGate
`net use w: ldapgate-host:8995` doesn't work. Two concrete issues:
1. LDAPGate proxy route only allows GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS —
   WebDAV needs PROPFIND, MKCOL, COPY, MOVE, LOCK, UNLOCK → getting 405.
2. Windows WebDAV client (net use) can't do cookie auth. It expects a
   401 WWW-Authenticate: Basic challenge. LDAPGate redirects to /_auth/login
   which the WebDAV client ignores, so auth never completes.
Fix:
- Add WebDAV methods to the proxy api_route methods list (easy)
- Add HTTP Basic auth support in the proxy: if Authorization: Basic header
  is present, verify against LDAP directly and inject X-Forwarded-User,
  bypassing the cookie/session flow. Return 401 with WWW-Authenticate: Basic
  if credentials are missing or wrong.
Copyparty launch: copyparty -1 10.52.118.41 -p 8989 --rproxy 1 \
  --xf-proto-fb http --xff-src=10.52.0.0/16 \
  --idp-h-usr X-Forwarded-User --idp-logout /_auth/logout \
  -v /hivestage/deletable:/:rw

## 3. LDAPGate — Add user allowlist (restrict access to specific users)
Add optional `allowed_users` config field under `ldap:`. If set, only users in
the list are allowed through even if LDAP auth succeeds.
Example config:
  ldap:
    allowed_users:
      - alice
      - bob
Already have group_dn for LDAP group restriction, but this is a simpler local
list for when you don't want to manage an AD group.
Apply check in both the proxy login flow and the middleware login flow.

## 4. LDAPGate — WebDAV mounting docs (Windows + Mac)
Document how Windows and Mac WebDAV mounting works once Basic auth is implemented.
Windows: net use w: http://host:port /user:username password
         (or just: net use w: http://host:port — Windows will prompt)
Mac Finder: open "http://host:port"  or Go > Connect to Server
Mac Terminal: osascript -e 'mount volume "http://host:port"'
             osascript -e 'mount volume "http://user:pass@host:port"'
Both work because WebDAV clients respond to 401 WWW-Authenticate: Basic the
same way — LDAPGate just needs to implement Basic auth (see #3).

## 5. LDAPGate — Add "Powered by LDAPGate" to default login page
Nice to have. Add a small "Powered by LDAPGate" line at the bottom of the
default login template (LOGIN_FORM_HTML in proxy.py and login.html template).
