"""
Minimal pre-flight check script for LDAPGate corporate AD setup.
Run this before configuring LDAPGate to verify everything works end to end.

Usage:
    .venv/bin/python3 ldap_check.py
"""

import ssl
from ldap3 import Server, Connection, NONE, SUBTREE, Tls

# --- Fill these in ---
LDAP_URL       = "ldaps://ldap-server.corp.com:3269"
BIND_DN        = "svcaccount"                          # bare sAMAccountName, UPN, or full DN
BIND_PASSWORD  = "yourpassword"
BASE_DN        = "DC=domain,DC=corp,DC=com"
TEST_USERNAME  = "svcaccount"                          # a known user to search for

CLIENT_CERT    = "/tmp/client.crt"                     # extracted from keystore.jks
CLIENT_KEY     = "/tmp/client.key"                     # extracted from keystore.jks
CA_BUNDLE      = "/etc/pki/tls/certs/ca-bundle.crt"   # system CA bundle (RHEL/CentOS)
# CA_BUNDLE    = "/etc/ssl/certs/ca-certificates.crt"  # Debian/Ubuntu alternative
# CA_BUNDLE    = None                                   # set to None to skip CA validation
# ---------------------

tls = Tls(
    local_certificate_file=CLIENT_CERT,
    local_private_key_file=CLIENT_KEY,
    ca_certs_file=CA_BUNDLE,
    validate=ssl.CERT_REQUIRED if CA_BUNDLE else ssl.CERT_NONE,
)

print(f"Connecting to {LDAP_URL} ...")
server = Server(LDAP_URL, connect_timeout=10, get_info=NONE, tls=tls)

try:
    conn = Connection(server, user=BIND_DN, password=BIND_PASSWORD, raise_exceptions=True)
    conn.open()
    conn.bind()
    print(f"✓ Bind OK as '{BIND_DN}'")

    conn.search(BASE_DN, f"(sAMAccountName={TEST_USERNAME})", search_scope=SUBTREE, attributes=["dn"])
    if conn.entries:
        print(f"✓ User search OK: {conn.entries[0].entry_dn}")
    else:
        print(f"✗ User search returned no results for sAMAccountName={TEST_USERNAME}")

    conn.unbind()
    print("\nAll checks passed. LDAPGate should work with this config.")

except Exception as e:
    print(f"✗ Failed: {e}")
    print("\nTips:")
    print("  - 49/52e: wrong password or bind DN format — try bare sAMAccountName")
    print("  - ssl verify failed: try setting CA_BUNDLE = None")
    print("  - connection refused: check URL and port")
