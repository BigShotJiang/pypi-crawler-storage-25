import base64

encrypted_b64 = "YbtQcLy=p0JeZwJLFV3l2bqWyI"   # REPLACE with full value from login-identity-providers.xml
key = "xxbZ2+iBxfEF/Eqf2s+1Zl7wKpuJXDPK"          # nifi.sensitive.props.key from nifi.properties

# NIFI_PBKDF2_AES_GCM_256 parameters
ITERATIONS = 160000
SALT_LEN = 16
IV_LEN = 12
KEY_LEN = 32  # 256-bit

try:
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    data = base64.b64decode(encrypted_b64 + "==")  # pad just in case
    print(f"Decoded bytes length: {len(data)} (need at least {SALT_LEN + IV_LEN + 1})")

    if len(data) < SALT_LEN + IV_LEN + 1:
        print("ERROR: Encrypted value is too short — the value from the screenshot is likely truncated.")
        print("Run this on the NiFi server and paste the full value:")
        print("  grep -i 'Manager Password' $NIFI_HOME/conf/login-identity-providers.xml")
    else:
        salt = data[:SALT_LEN]
        iv = data[SALT_LEN:SALT_LEN + IV_LEN]
        ciphertext = data[SALT_LEN + IV_LEN:]

        kdf = PBKDF2HMAC(algorithm=hashes.SHA512(), length=KEY_LEN, salt=salt, iterations=ITERATIONS)
        derived_key = kdf.derive(key.encode())

        aesgcm = AESGCM(derived_key)
        plaintext = aesgcm.decrypt(iv, ciphertext, None)
        print("Decrypted password:", plaintext.decode())

except ImportError:
    print("ERROR: cryptography not available — run: uv pip install cryptography")
except Exception as e:
    print("ERROR:", e)
