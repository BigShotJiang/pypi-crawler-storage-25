from dataclasses import dataclass


@dataclass
class Group:
    r"""A Kumo group, as determined by IDP group mapping.

    Users cannot create or delete groups — they are managed externally.
    A user operates in exactly one group at a time.
    """
    id: str
    name: str

    def __str__(self) -> str:
        return f"Group(id={self.id!r}, name={self.name!r})"


@dataclass
class Project:
    r"""A Kumo project, belonging to a group.

    Projects are created by users within their group. All objects (graphs,
    tables, predictive queries) and jobs belong to a project. Objects cannot
    be shared across projects.
    """
    id: str
    name: str
    group_id: str

    def __str__(self) -> str:
        return f"Project(id={self.id!r}, name={self.name!r})"
