from typing import TYPE_CHECKING, List

from kumoai.client.endpoints import ProjectEndpoints
from kumoai.client.utils import raise_on_error
from kumoai.rbac import Project

if TYPE_CHECKING:
    from kumoai.client.client import KumoClient


class ProjectsAPI:
    r"""Typed API for RBAC project operations."""
    def __init__(self, client: 'KumoClient') -> None:
        self._client = client

    def list_projects(self, group_id: str) -> List[Project]:
        r"""Lists all projects within the given group."""
        resp = self._client._request(
            ProjectEndpoints.list,
            params={'group_id': group_id},
        )
        raise_on_error(resp)
        return [
            Project(id=p['id'], name=p['display_name'], group_id=group_id)
            for p in resp.json()
        ]

    def create_project(self, name: str, group_id: str) -> Project:
        r"""Creates a new project within the given group."""
        resp = self._client._request(
            ProjectEndpoints.create,
            json={
                'name': name,
                'kumo_group_id': group_id,
            },
        )
        raise_on_error(resp)
        data = resp.json()
        return Project(id=data['id'], name=data['display_name'],
                       group_id=group_id)
