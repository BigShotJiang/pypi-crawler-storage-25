from typing import TYPE_CHECKING, List

from kumoai.client.endpoints import ConnectorEndpoints, GroupEndpoints
from kumoai.client.utils import raise_on_error
from kumoai.rbac import Group

if TYPE_CHECKING:
    from kumoai.client.client import KumoClient
    from kumoai.connector.group_connector import GroupConnector


class GroupsAPI:
    r"""Typed API for RBAC group operations and group connectors."""
    def __init__(self, client: 'KumoClient') -> None:
        self._client = client

    def list_groups(self) -> List[Group]:
        r"""Lists all groups the authenticated user belongs to."""
        resp = self._client._request(GroupEndpoints.list)
        raise_on_error(resp)
        return [
            Group(id=g['group_id'], name=g['display_name'])
            for g in resp.json()
        ]

    def list_group_connectors(self, group_id: str) -> List['GroupConnector']:
        r"""Lists all group connectors available within the given group."""
        from kumoai.connector.group_connector import GroupConnector
        resp = self._client._request(
            ConnectorEndpoints.list_group_connectors,
            params={'group_id': group_id},
        )
        raise_on_error(resp)
        return [
            GroupConnector(
                id=c['id'],
                alias=c['display_name'],
                connector_type=c['connector_type'],
                scope=c.get('scope'),
            ) for c in resp.json()
        ]
