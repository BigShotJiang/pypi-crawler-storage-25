import logging
from abc import abstractmethod
from typing import List, Optional, Type

from kumoapi.data_source import FileConnectorResourceConfig
from kumoapi.source_table import (
    SourceTableConfigRequest,
    SourceTableConfigResponse,
    SourceTableListRequest,
    SourceTableListResponse,
    SourceTableValidateRequest,
    SourceTableValidateResponse,
)
from typing_extensions import Self, override

from kumoai import global_state
from kumoai.connector import Connector

logger = logging.getLogger(__name__)


class FileURI:
    r"""Base class for cloud storage URI parsing (S3, GCS)."""

    _scheme: str  # "s3://" or "gs://" — set by subclass

    def __init__(self, uri: str):
        self.uri: str = uri
        if uri.endswith('/'):  # remove trailing slash
            self.uri = uri[:-1]

    @property
    def is_valid(self) -> bool:
        return self.uri.startswith(self._scheme)

    def validate(self) -> Self:
        if not self.is_valid:
            scheme_name = self._scheme.rstrip('://')
            raise ValueError(
                f"Path {self.uri} is not a valid {scheme_name} URI.")
        return self

    @property
    def root_dir(self) -> str:
        self.validate()
        return self.uri.rsplit('/', 1)[0]

    @property
    def object_name(self) -> str:
        self.validate()
        return self.uri.rsplit('/', 1)[1]

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}('
                f'uri={self.uri}, valid={self.is_valid})')


class FileConnector(Connector):
    r"""Base class for file-based connectors (S3, GCS).

    Subclasses must set:
        _default_name: str — e.g. "s3_connector" or "gcs_connector"
        _uri_class: Type[FileURI] — e.g. S3URI or GCSURI

    Subclasses must implement:
        source_type: property returning DataSourceType
        _make_source_table_request: builds the provider-specific request
    """

    _default_name: str
    _uri_class: Type[FileURI]

    def __init__(
        self,
        root_dir: Optional[str] = None,
        _connector_id: Optional[str] = None,
    ) -> None:
        if _connector_id is not None:
            self._connector_id = _connector_id
            self.root_dir = None
            return

        self._connector_id = self._default_name
        if root_dir is not None:
            root_dir = root_dir.rstrip('/')
        self.root_dir = root_dir

        if global_state.is_spcs and root_dir is not None \
                and self._uri_class(root_dir).is_valid:
            scheme_name = self._uri_class._scheme.rstrip(':/').upper()
            raise ValueError(
                f"{scheme_name} connectors are not supported when running "
                f"Kumo in Snowpark container services. Please use a "
                f"Snowflake connector instead.")

    @override
    @property
    def name(self) -> str:
        return self._connector_id

    @abstractmethod
    def _make_source_table_request(
        self,
        root_dir: str,
        connector_id: Optional[str],
        table_names: List[str],
    ):
        raise NotImplementedError()

    @override
    def _source_table_request(self, table_names: List[str]):
        root_dir = self.root_dir
        if not root_dir and self.name == self._default_name:
            # Handle None root directories (table name is a path):
            table_path = self._uri_class(table_names[0]).validate()
            root_dir = table_path.root_dir
            for i, v in enumerate(table_names):
                uri = self._uri_class(v)
                if uri.root_dir != root_dir:
                    raise ValueError(
                        f"Please ensure that all of your tables are behind "
                        f"the same root directory ({root_dir}).")
                table_names[i] = uri.object_name

        connector_id = self.name if self.name != self._default_name else None
        root_dir = root_dir if self.name == self._default_name else ""

        if global_state._rbac_enabled and connector_id is None:
            raise ValueError(
                "When RBAC is enabled, file tables must reference a group "
                "connector. Use S3Connector.get_by_name('connector_name') "
                "or kumoai.list_group_connectors() to find available "
                "connectors.")

        return self._make_source_table_request(
            root_dir=root_dir or '',
            connector_id=connector_id,
            table_names=table_names,
        )

    @override
    def _list_tables(self) -> SourceTableListResponse:
        connector_id = self.name if self.name != self._default_name else None
        root_dir = self.root_dir if self.name == self._default_name else None
        if root_dir is None and connector_id is None:
            scheme_name = self._uri_class._scheme.rstrip('://')
            raise ValueError(
                "Listing tables without a specified root directory is not "
                "supported. Please specify a root directory to continue; "
                "alternatively, please access individual tables with their "
                f"full {scheme_name.upper()} paths.")

        req = SourceTableListRequest(connector_id=connector_id,
                                     root_dir=root_dir,
                                     source_type=self.source_type)
        return global_state.client.source_table_api.list_tables(req)

    @override
    def _get_table_config(self, table_name: str) -> SourceTableConfigResponse:
        root_dir = self.root_dir
        if not root_dir and self.name == self._default_name:
            # Handle None root directories (table name is a path):
            table_path = self._uri_class(table_name).validate()
            root_dir = table_path.root_dir
            table_name = table_path.object_name

        connector_id = self.name if self.name != self._default_name else None
        root_dir = root_dir if self.name == self._default_name else None

        req = SourceTableConfigRequest(
            connector_id=connector_id,
            root_dir=root_dir,
            table_name=table_name,
            source_type=self.source_type,
        )
        return global_state.client.source_table_api.get_table_config(req)

    @override
    def _validate_table(self, table_name: str) -> SourceTableValidateResponse:
        if table_name in self._validated_tables:
            return SourceTableValidateResponse(is_valid=True, msg='')

        if self.name == self._default_name:
            if self.root_dir:
                req = SourceTableValidateRequest(
                    connector_id=None,
                    table_name=table_name,
                    source_type=self.source_type,
                    root_dir=self.root_dir,
                )
            else:
                uri = self._uri_class(table_name).validate()
                req = SourceTableValidateRequest(
                    connector_id=None,
                    table_name=uri.object_name,
                    source_type=self.source_type,
                    root_dir=uri.root_dir,
                )
        else:
            req = SourceTableValidateRequest(connector_id=self.name,
                                             table_name=table_name,
                                             source_type=self.source_type)

        ret = global_state.client.source_table_api.validate_table(req)
        # Cache the result for the whole session.
        if ret.is_valid:
            self._validated_tables.add(table_name)
        return ret

    @classmethod
    def _validate_get_by_name(cls, config, name: str):
        r"""Hook for subclass-specific validation in get_by_name.
        Override in subclasses to add extra checks (e.g. GCS prefix).
        """
        pass

    @classmethod
    def get_by_name(cls, name: str) -> Self:
        r"""Returns an instance of a named file connector, created in the
        Kumo UI.

        In RBAC-enabled workspaces, this looks up the connector from the
        group connectors available in the current group.

        Args:
            name: The name of the existing connector.
        """
        if global_state._rbac_enabled:
            return cls._get_group_connector_by_name_rbac(name)

        api = global_state.client.connector_api
        resp = api.get(name)
        if resp is None:
            raise ValueError(
                f"There does not exist an existing stored connector with name "
                f"{name}.")
        config = resp.config
        assert isinstance(config, FileConnectorResourceConfig)
        cls._validate_get_by_name(config, name)
        return cls(
            root_dir=None,
            _connector_id=config.name,
        )

    @classmethod
    def _get_group_connector_by_name_rbac(cls, name: str) -> Self:
        r"""Looks up a group connector by name in the current group."""
        gc = cls._find_group_connector_by_name(name)
        if gc._connector_type != "file":
            raise ValueError(f"Group connector {name!r} is a "
                             f"{gc._connector_type} connector, not an S3/GCS "
                             f"connector. Use the correct connector class.")
        return cls(root_dir=None, _connector_id=gc.name)

    def __repr__(self) -> str:
        if self.name != self._default_name:
            return f'{self.__class__.__name__}(name={self.name})'
        root_dir_name = f"\"{self.root_dir}\"" if self.root_dir else "None"
        return f'{self.__class__.__name__}(root_dir={root_dir_name})'
