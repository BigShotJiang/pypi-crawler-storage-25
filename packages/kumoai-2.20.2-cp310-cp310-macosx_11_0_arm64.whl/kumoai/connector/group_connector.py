from typing import List, Optional, Union

from kumoapi.data_source import ConnectorType, DataSourceType
from kumoapi.rbac import ConnectorScope
from kumoapi.source_table import (
    DatabricksSourceTableRequest,
    S3SourceTableRequest,
)
from typing_extensions import override

from kumoai.connector.base import Connector


class GroupConnector(Connector):
    r"""A group-scoped connector, available in RBAC-enabled workspaces.

    Group connectors are created and managed by administrators. Users can list
    available group connectors via :func:`kumoai.list_group_connectors` and use
    them to create tables, exactly as they would with a
    :class:`~kumoai.DatabricksConnector` or :class:`~kumoai.S3Connector`.

    Group connectors live at the group level and are shared across all projects
    within the group. Connection details (host, credentials, catalog, etc.) are
    configured by the administrator and are not exposed to users.

    Example:
        >>> import kumoai
        >>> connectors = kumoai.list_group_connectors()  # doctest: +SKIP
        >>> connector = connectors[0]  # doctest: +SKIP
        >>> source_table = connector.table(  # doctest: +SKIP
        ...     "my_schema.my_table")  # doctest: +SKIP
    """
    def __init__(
        self,
        id: str,
        alias: str,
        connector_type: str,
        scope: Optional[ConnectorScope] = None,
    ) -> None:
        super().__init__()
        self._id = id
        self._alias = alias
        self._connector_type = connector_type
        self._scope = scope

    @property
    def display_name(self) -> str:
        r"""Returns the human-readable display name of this group connector.

        Note: This is distinct from :attr:`name`, which returns the internal
        group connector ID (e.g. ``group_connector_<hex>``) used in API calls.
        """
        return self._alias

    @property
    def scope(self) -> Optional[ConnectorScope]:
        r"""Returns the scope constraints for this group connector, or None
        if no scope is configured.
        """
        return self._scope

    @override
    @property
    def name(self) -> str:
        r"""Returns the group connector ID used in all API calls.

        Note: This is the internal ID (e.g. ``group_connector_<hex>``), not
        the human-readable display name. Use :attr:`display_name` for that.
        """
        return self._id

    @override
    @property
    def source_type(self) -> DataSourceType:
        if self._connector_type == ConnectorType.FILE:
            return DataSourceType.S3
        return DataSourceType(self._connector_type.upper())

    @override
    def _source_table_request(
        self,
        table_names: List[str],
    ) -> Union[DatabricksSourceTableRequest, S3SourceTableRequest]:
        if self._connector_type == "databricks":
            return DatabricksSourceTableRequest(
                connector_id=self._id,
                table_names=table_names,
            )
        elif self._connector_type in ("file", "s3", "gcs"):
            return S3SourceTableRequest(
                s3_root_dir='',
                connector_id=self._id,
                table_names=table_names,
            )
        else:
            raise ValueError(f"Unsupported group connector type: "
                             f"{self._connector_type!r}")

    @override
    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}'
                f'(id={self._id!r}, alias={self._alias!r}, '
                f'type={self._connector_type!r}, '
                f'scope={self._scope!r})')
