import logging
from typing import List, Optional

from kumoapi.data_source import DataSourceType
from kumoapi.source_table import GCSSourceTableRequest
from typing_extensions import override

from kumoai.connector.file_connector import FileConnector, FileURI

logger = logging.getLogger(__name__)


class GCSURI(FileURI):
    r"""A utility class to parse and navigate GCS URIs."""

    _scheme = "gs://"


class GCSConnector(FileConnector):
    r"""Defines a connector to a table stored as a file (or partitioned
    set of files) on `Google Cloud Storage (GCS)
    <https://cloud.google.com/storage>`__. Any table behind a GCS bucket
    accessible by the GKE workload identity can be accessed through this
    connector.

    .. code-block:: python

        import kumoai
        connector = kumoai.GCSConnector(root_dir="gs://...")  # a GCS path.

        # List all tables:
        print(connector.table_names())  # Returns: ['articles', 'customers', 'users']

        # Check whether a table is present:
        assert "articles" in connector

        # Fetch a source table (both approaches are equivalent):
        source_table = connector["articles"]
        source_table = connector.table("articles")

    Args:
        root_dir: The root directory of this connector. If provided, the root
            directory is used as a prefix for tables in this connector. If not
            provided, all tables must be specified by their full GCS paths.
    """  # noqa

    _default_name = 'gcs_connector'
    _uri_class = GCSURI

    @override
    @property
    def source_type(self) -> DataSourceType:
        return DataSourceType.GCS

    @override
    def _make_source_table_request(
        self,
        root_dir: str,
        connector_id: Optional[str],
        table_names: List[str],
    ) -> GCSSourceTableRequest:
        return GCSSourceTableRequest(
            gcs_root_dir=root_dir,
            connector_id=connector_id,
            table_names=table_names,
        )

    @classmethod
    def _validate_get_by_name(cls, config, name: str):
        super()._validate_get_by_name(config, name)
        if not config.root_dir.startswith('gs://'):
            raise ValueError(f"Connector '{name}' is not a GCS connector "
                             f"(root_dir does not start with 'gs://').")
