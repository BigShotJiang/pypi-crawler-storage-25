import logging
from typing import List, Optional

from kumoapi.data_source import DataSourceType
from kumoapi.source_table import S3SourceTableRequest
from typing_extensions import override

from kumoai import global_state
from kumoai.connector.file_connector import FileConnector, FileURI

logger = logging.getLogger(__name__)


class S3URI(FileURI):
    r"""A utility class to parse and navigate S3 URIs."""

    _scheme = "s3://"

    @property
    def is_valid(self) -> bool:
        # TODO(zeyuan): For SPCS, the path can be a local filesystem path
        # For train/pred table.
        if global_state.is_spcs:
            return True
        return super().is_valid


class S3Connector(FileConnector):
    r"""Defines a connector to a table stored as a file (or partitioned
    set of files) on the Amazon `S3 <https://aws.amazon.com/s3/>`__ object
    store. Any table behind an S3 bucket accessible by the shared external IAM
    role can be accessed through this connector.

    .. code-block:: python

        import kumoai
        connector = kumoai.S3Connector(root_dir="s3://...")  # an S3 path.

        # List all tables:
        print(connector.table_names())  # Returns: ['articles', 'customers', 'users']

        # Check whether a table is present:
        assert "articles" in connector

        # Fetch a source table (both approaches are equivalent):
        source_table = connector["articles"]
        source_table = connector.table("articles")

    Args:
        root_dir: The root directory of this connector. If provided, the root
            directory is used as a prefix for tables in this connector. If not
            provided, all tables must be specified by their full S3 paths.
    """  # noqa

    _default_name = 's3_connector'
    _uri_class = S3URI

    @override
    @property
    def source_type(self) -> DataSourceType:
        return DataSourceType.S3

    @override
    def _make_source_table_request(
        self,
        root_dir: str,
        connector_id: Optional[str],
        table_names: List[str],
    ) -> S3SourceTableRequest:
        # TODO(manan): file type?
        return S3SourceTableRequest(
            s3_root_dir=root_dir,
            connector_id=connector_id,
            table_names=table_names,
        )
