# bcijelly.load_data

```python
def load_data(
    dataset_name: str,
    *,
    protocol: str = "single_day",
    task: str | None = None,
    split_ratio: str = "7:1:2",
    subject_index: int = 0,
    day_index: int = 0,
    seed: int | None = 42,
    data_dir: Path | None = None,
    verbose: bool = False,
    auto_download_missing: bool = True,
    fallback_to_first_subject: bool = False,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
    max_days_per_dataset: int | None = None,
) -> DataLoadResult
```

## Overview

`load_data` is the unified data-loading API in BCIJelly. It automatically handles:

- Dataset discovery and availability checks (local or auto-download)
- Protocol/task compatibility validation
- Single-day or cross-day job construction
- NPZ reading with task-aware label key selection
- Train/val/test splitting and feature shape alignment
- Unified output as `DataLoadResult`


## Parameters


#### dataset_name

- Default: none (required).
- Role: selects which dataset directory to load.
- Impact: determines all downstream discovery, validation, job construction, and file loading branches.

#### protocol

- Default: `single_day`.
- Supported: `single_day`, `cross_day`, `train-test`, `train-val-test`.
- Role: defines loading paradigm and split path.
- Key behavior:
  - `train-test` and `train-val-test` run through single-day execution semantics.
  - `cross_day` builds day-block train/val/test partitions.

#### task

- Default: `None`, then fallback to `classification`.
- Supported: `classification`, `regression`, `speech`.
- Role: controls label-key selection and label-shape validation.
- Key behavior:
  - classification expects `(N,)` labels.
  - regression expects `(N,T,2)` labels with matching `T` to neural features.
  - speech currently accepts `(N,)` or `(N,L)`.

#### split_ratio

- Default: `7:1:2`.
- Role: controls train/val/test ratio.
- Rules:
  - `a:b` means train:test.
  - `a:b:c` means train:val:test.
  - train and test ratios must both be non-zero.
- Notes:
  - In cross-day, allocation is by day count, not random per-sample split.
  - Under `train-val-test`, explicit val files may be required by dataset format/declaration.

#### subject_index

- Default: `0`.
- Role: selects subject subdirectory in multi-subject datasets.
- Notes:
  - For non-multi-subject structures, only `0` is valid.

#### day_index

- Default: `0`.
- Role: selects which day/session job for single-day loading.
- Notes:
  - For split-files format, only `day_index=0` is valid.
  - In cross-day, there is typically one job, so `day_index` usually stays `0`.

#### data_dir

- Default: `None` (internally falls back to `data`).
- Role: overrides dataset root location.

#### auto_download_missing

- Default: `True`.
- Role: auto-downloads missing datasets from Hugging Face.

#### fallback_to_first_subject

- Default: `False`.
- Role: when `subject_index` is out of range, fallback to first subject with warning instead of hard error.

#### seed

- Default: `42`.
- Role: controls reproducibility of random splits.
- Key note:
  - Optional; when omitted, default value `42` is used.

#### verbose

- Default: `False`.
- Role: prints dataset/job summaries for diagnostics.

#### repo_id, repo_type

- Role: controls download source (defaults to official HF dataset repo).
- Typical use: private mirror/testing repository.

#### max_days_per_dataset

- Role: caps discovered/constructed day count.
- Typical use: fast debugging and reduced-scale experiments.


## Usage

```python
import bcijelly as bj

# single-day classification
loaded = bj.load_data(
    dataset_name="1_FALCONM1-A",
    protocol="single_day", task="classification",
    subject_index=0, day_index=0,
    split_ratio="7:1:2",
)

# cross-day classification
loaded = bj.load_data(
    dataset_name="1_FALCONM1-A",
    protocol="cross_day", task="classification",
    subject_index=0,
    split_ratio="7:1:2",
)

# single-day regression
loaded = bj.load_data(
    dataset_name="5_Jango_force",
    protocol="single_day", task="regression",
    subject_index=0, day_index=0,
    split_ratio="7:1:2",
)

# cross-day regression
loaded = bj.load_data(
    dataset_name="5_Jango_force",
    protocol="cross_day", task="regression",
    subject_index=0,
    split_ratio="7:1:2",
)
```


## Execution Logic

Main flow in `src/bcijelly/dataset/_loading.py`:

1. Parameter and capability checks

- Validate `protocol` against capability declaration.
- Validate `task` (or fallback to `classification`).
- Parse `split_ratio`.

2. Dataset structure discovery

- `discover_dataset_structure` identifies format:
  - `single_file`
  - `split_files`
  - `day_files`
  - `multi_subject`
  - `virtual_sessions` (for VisualGratingTask)

3. Dataset declaration compatibility validation

- If `dataset_compatibility.json` exists, validate requested protocol/task.

4. Subject resolution

- Resolve subject branch via `subject_index`.
- Out-of-range behavior depends on `fallback_to_first_subject`.

5. Branch A: split_files direct loading

- Fixed train/test (and optional val) file path flow.
- `train-val-test` may require explicit val file.

6. Branch B: build jobs then choose one

- Build `DatasetJob` list via `build_jobs`.
- For single_day, select by `day_index`.
- For cross_day, there is usually one constructed job.

7. Job-level loading (`load_job_data`)

- single_day:
  - pre-split single-file keys -> direct train/test load.
  - raw single-file -> split using `split_ratio + seed`.
- cross_day:
  - load train/val/test day blocks.
  - align to shared minimal `(time, channels)` shape.
  - return aggregated `test_dataset` and per-day `test_day_datasets`.

8. Return result

- Unified `DataLoadResult` fields:
  - `train_dataset`
  - `val_dataset` (optional)
  - `test_dataset`
  - `test_day_datasets` (common in cross-day)
  - `aligned_shape`
  - `job`
  - `requested_task`


<!-- ## 6. Common Errors and Troubleshooting -->

<!-- - Unsupported protocol

  - Check whether protocol is in supported values.
- Unsupported task

  - Check task is one of classification/regression/speech.
- Invalid split_ratio

  - Ensure format `a:b` or `a:b:c`, with non-zero train/test ratios.
- Seed not explicitly provided

  - Default value `42` will be used; pass a custom seed for a different split.
- subject_index/day_index out of range

  - Check subject/day counts for the selected dataset.
- Task label shape mismatch

  - Regression requires `(N,T,2)` and `T` aligned with neural feature length. -->

---

If you want to dive deeper, start from:

- `src/bcijelly/dataset/_loading.py`
- `src/bcijelly/dataset/_discovery.py`
- `src/bcijelly/dataset/_io.py`
