# bcijelly.model

```python
# dynamic factories (examples)
model = bcijelly.model.transformer(task="classification")
model = bcijelly.model.lstm(task="regression")

# capability query
tasks = bcijelly.model.get_supported_tasks("transformer")
```

## Overview

`bcijelly.model` provides dynamic model factory entry points and capability lookup utilities.

Main responsibilities:

- Build model instances by model name + task.
- Validate model/task compatibility.
- Expose a unified adapter interface (`BaseModel`) with `train` and `test` methods.

## Available Model Factories

Current factory names:

- `transformer`
- `lstm`
- `cycle_gan`
- `lfads`
- `stabilization`

These names are resolved dynamically by module-level `__getattr__`.

## Related API

#### get_supported_tasks

```python
def get_supported_tasks(model_name: str) -> tuple[str, ...]
```

- Role: return the declared supported tasks for a model.
- Example outputs:
  - `transformer` -> `("classification", "regression", "speech")`
  - `cycle_gan` -> `("classification", "regression")`

#### create_model

```python
def create_model(*, model_name: str, task: str) -> BaseModel
```

- Role: construct a `BaseModel` instance after compatibility checks.
- Usually you call the dynamic factory instead of `create_model` directly.

## Task Compatibility Matrix

- `transformer`: classification, regression, speech
- `lstm`: classification, regression, speech
- `cycle_gan`: classification, regression
- `lfads`: classification, regression
- `stabilization`: classification, regression

## Usage

```python
import bcijelly

model = bcijelly.model.transformer(task="classification")
print(model.model_name)  # transformer
print(model.task)        # classification
```

<!-- ## Behavior Notes

- Invalid model names raise `ValueError`.
- Invalid tasks raise `ValueError`.
- Unsupported model/task combinations raise `ValueError`.
- `BaseModel` loads backend implementation lazily based on `(model_name, task)`. -->

## See Also

- Data loading: [load_data.en.md](load_data.en.md)
- Train API: [model.train.en.md](model.train.en.md)
- Test API: [model.test.en.md](model.test.en.md)
- Summary API: [summary.en.md](summary.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)
