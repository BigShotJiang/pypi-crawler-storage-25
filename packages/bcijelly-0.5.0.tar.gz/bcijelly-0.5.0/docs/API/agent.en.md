# bcijelly.SearchAgent

```python
from bcijelly import SearchAgent
```

## Overview

`SearchAgent` is an experimental search-and-ensemble API in BCIJelly.

It provides an end-to-end flow:

1. Search candidate architectures on train/validation data.
2. Filter and retain top candidates by validation metric.
3. Select final ensemble members (`mean` / `stacking` / `auto`).
4. Evaluate external test data day-by-day.
5. Summarize final results with `summary(...)`.

## Status (Experimental)

Current `SearchAgent` is a testing/preview feature.

- The searchable model space is not exhaustive.
- Not all model families/tasks in BCIJelly are currently exposed through agent search.
- API may evolve in upcoming versions.

## Constructor


```python
a = SearchAgent(
    task_type=None,  # Task expectation: "classification" or "regression"; None means infer from labels.
    module_root=None,  # Root path for searchable module discovery.
    device="cuda",  # Runtime device preference; auto-fallback to CPU if CUDA is unavailable.
    output_dir="BJ_Agent_outputs_search_ensemble_api",  # Directory for logs, CSV/JSON, and artifacts.
    random_seed=42,  # Global random seed for reproducibility.
    num_workers=0,  # DataLoader worker count.
    save_result_json=True,  # Whether to persist best_result to JSON.
    normalize_regression_target=True,  # Normalize regression targets during fit and denormalize in predict.

    hidden_dim=64,  # Hidden feature width used in composed architectures.
    batch_size=16,  # Batch size for training and inference.
    epochs=12,  # Max training epochs per candidate.
    patience=4,  # Early-stop patience.
    learning_rate=1e-3,  # Optimizer learning rate.
    weight_decay=1e-4,  # Optimizer weight decay.

    max_search_rounds=4,  # Number of search rounds.
    max_models_per_round=8,  # Candidate architectures sampled per round.
    max_trials_per_round=None,  # Backward-compatible alias for max_models_per_round.
    max_depth=4,  # Maximum sampled architecture depth.
    retain_top_k=6,  # Number of retained candidates after filtering.
    val_threshold=0.75,  # Minimum validation metric to retain a candidate.
    ensemble_top_m=4,  # Top retained candidates considered for final ensemble selection.
    ensemble_method="auto",  # Ensemble strategy: "mean", "stacking", or "auto".
    stacking_max_iter=4000,  # Max iterations for logistic-regression stacker.

    search_module_types=None,  # Allowed module type families in search space.
    allowed_module_keys=None,  # Optional whitelist of module keys.
    include_builtin_modules=True,  # Whether built-in modules are included in searchable registry.
    max_per_type=2,  # Max count per module type within one architecture.
    allow_repeat=True,  # Whether repeated module keys are allowed in one architecture.
    min_distinct_types=1,  # Minimum distinct module types required per architecture.
    no_repeat_within_types=None,  # Types that disallow repeated keys within one architecture.
    max_occurrences_per_key=None,  # Optional per-key occurrence cap.
    key_sampling_weights=None,  # Optional sampling weights per key.
)
```

## Core Methods

### fit

```python
fit(
    train_dataset: tuple,
    val_dataset: tuple | None = None,
) -> SearchAgent
```

- `train_dataset`: usually `(X_train, y_train)`.
- `val_dataset`: usually `(X_val, y_val)`, required.

Notes:

- `fit(...)` requires validation data for search/selection.
- After success, agent stores `best_model` and `best_result`.

### predict

```python
predict(X) -> np.ndarray
```

- Runs prediction with the selected final ensemble.

### test

```python
test(
    test_day_data: dict[str, tuple[X, y] | dict[str, Any]] | list[dict[str, Any]]
) -> dict[str, Any]
```

Accepted formats:

1. Dict form: `{day_name: (X, y)}`
2. Dict payload form: `{day_name: {"X": X, "y": y}}`
3. List form: `[{"date": "day_0", "X": X, "y": y}, ...]`

Returns day-by-day metrics and summary fields such as:

- `metric_name`
- `day_accuracy` / `day_r2`
- `average_accuracy` / `average_r2`
- `median_*`, `min_*`
- `day_sample_counts`
- `num_test_days`

### summary

```python
summary(
    mode: Literal["compact", "full"] = "compact",
    print_output: bool = True,
    include: bool = False,
    max: int | None = None,
) -> dict[str, Any]
```

Defaults:

- `mode="compact"`
- `print_output=True`
- `include=False`
- `max=None`

Behavior:

- `compact`: key fields only (`task_type`, method, val metric, members, retained info).
- `full`: includes `selected_ensemble`, `threshold_filter`, output paths, optional `external_test_summary`.
- `include=True`: include retained candidate details.
- `max`: cap candidate details when `include=True`; `None` means no cap.

### get_best_result

```python
get_best_result() -> dict[str, Any]
```

- Returns the internal structured result payload after `fit(...)`.

### get_best_model

```python
get_best_model() -> CombinedEnsembleModel
```

- Returns the selected final ensemble model wrapper.

## Minimal Usage

```python
import bcijelly as bj
from bcijelly import SearchAgent

loaded = bj.load_data(
    dataset_name="5_Jango_force",
    protocol="cross_day",
    task="classification",
    subject_index=0,
    split_ratio="7:1:2",
    verbose=False,
)

agent = SearchAgent(
    task_type="classification",
    device="cpu",
    epochs=1,
    patience=1,
    max_search_rounds=1,
    max_models_per_round=1,
    retain_top_k=1,
    ensemble_top_m=1,
    val_threshold=0.0,
    save_result_json=False,
)

agent.fit(loaded.train_dataset, loaded.val_dataset)

# cross-day test input for SearchAgent
by_day = {f"day_{i}": ds for i, ds in enumerate(loaded.test_day_datasets or [])}
_ = agent.test(by_day)

result = agent.summary(mode="compact")
print(result)
```

## See Also

- [load_data.en.md](load_data.en.md)
- [model.en.md](model.en.md)
- [summary.en.md](summary.en.md)
- [../Demo/demo.en.md](../Demo/demo.en.md)
