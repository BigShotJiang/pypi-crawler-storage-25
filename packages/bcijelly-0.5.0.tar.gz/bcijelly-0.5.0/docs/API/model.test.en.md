# bcijelly.model.BaseModel.test

```python
def test(self, *args: Any, **kwargs: Any) -> dict[str, Any]
```

## Overview

`model.test` is the unified testing entrypoint on a model instance.

Before delegating to backend `test(...)`, the adapter restores train state captured by `model.train(...)` when available.

## Parameters

### Common Parameters Across Most Backends

#### test_dataset

- Type: tuple, task-dependent.
- Role: in-memory test data.
- Required: yes, unless `test_datapath` is provided.

#### verbose

- Type: `bool`.
- Role: print test-time details.

#### test_datapath

- Type: `str | None`.
- Role: path-based test input.

### Model-Specific Test Parameters

#### LFADS classifier

- `cleanup_temp_ckpt: bool = False`
- Role: whether to remove temporary checkpoint artifacts after evaluation.

#### LFADS regressor

- `reduce: str = "center"`
- Role: reduction mode aligned with LFADS regressor flow.

#### CycleGAN classifier/regressor

- `calib_ratio: float = 0.1`
- `min_calib_trials: int = 5`
- `max_calib_trials: int | None = 30`
- Role: split a calibration subset from test data before final evaluation.

#### Stabilization classifier/regressor

- `calib_ratio: float = 0.2`
- `min_calib_trials: int = 1`
- `max_calib_trials: int | None = None`
- Role: calibration/evaluation split for stabilization adaptation path.

### Task-Specific Dataset Formats

- Classification/Regression backends usually expect:
  - `test_dataset: tuple[np.ndarray, np.ndarray]`

- Speech backends expect:
  - `test_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]`

### State and Execution Constraints

- Backends rely on training state in-process; call `model.train(...)` before `model.test(...)` in the same runtime.
- Adapter-level state restore happens automatically before backend test call.

## Return Value

- Type: `dict[str, Any]`
- Typical metric keys depend on task/backend:
  - classification: often `acc`
  - regression: often `r2`
  - some backends may also emit `loss`, `mse`, or `mae`


## Usage

```python
test_result = model.test(
    test_dataset=loaded_data.test_dataset,
    verbose=False,
)
```

For cross-day workflows, this method runs one global test on merged test samples. You can also evaluate per day using:

```python
day_metric_list = []
for one_day_test_dataset in loaded_data.test_day_datasets:
    one_day_result = model.test(test_dataset=one_day_test_dataset, verbose=False)
    day_metric_list.append(float(one_day_result["acc"]))
```

## Source of Truth

- [../../src/bcijelly/model/_transformer/classifier.py](../../src/bcijelly/model/_transformer/classifier.py)
- [../../src/bcijelly/model/_transformer/regressor.py](../../src/bcijelly/model/_transformer/regressor.py)
- [../../src/bcijelly/model/_transformer/speech.py](../../src/bcijelly/model/_transformer/speech.py)
- [../../src/bcijelly/model/_lstm/classifier.py](../../src/bcijelly/model/_lstm/classifier.py)
- [../../src/bcijelly/model/_lstm/regressor.py](../../src/bcijelly/model/_lstm/regressor.py)
- [../../src/bcijelly/model/_lstm/speech.py](../../src/bcijelly/model/_lstm/speech.py)
- [../../src/bcijelly/model/_lfads/classifier.py](../../src/bcijelly/model/_lfads/classifier.py)
- [../../src/bcijelly/model/_lfads/regressor.py](../../src/bcijelly/model/_lfads/regressor.py)
- [../../src/bcijelly/model/_cycle_gan/classifier.py](../../src/bcijelly/model/_cycle_gan/classifier.py)
- [../../src/bcijelly/model/_cycle_gan/regressor.py](../../src/bcijelly/model/_cycle_gan/regressor.py)
- [../../src/bcijelly/model/_stabilization/classifier.py](../../src/bcijelly/model/_stabilization/classifier.py)
- [../../src/bcijelly/model/_stabilization/regressor.py](../../src/bcijelly/model/_stabilization/regressor.py)

## See Also

- Model factory: [model.en.md](model.en.md)
- Train API: [model.train.en.md](model.train.en.md)
- Summary API: [summary.en.md](summary.en.md)
- Demo: [../Demo/complex_demo.en.md](../Demo/complex_demo.en.md)
