# bcijelly.model.BaseModel.train

```python
def train(self, *args: Any, **kwargs: Any) -> dict[str, Any]
```

## Overview

`model.train` is the unified training entrypoint on a model instance.

At adapter level it is `*args/**kwargs`, but the effective parameters are defined by backend model/task implementations.

All backends support a concrete train API with named arguments, including `train_dataset`, `val_dataset`, `seed`, `epochs`, and more.

## Parameters

### Common Parameters Across Most Backends

#### train_dataset

- Type: tuple, task-dependent.
- Role: in-memory training data.
- Required: yes, unless `train_datapath` is provided.

#### val_dataset

- Type: tuple or `None`.
- Role: external validation input.

#### batch_size

- Type: `int`.
- Typical defaults: 16, 32, or 64 depending on backend.

#### epochs

- Type: `int`.
- Typical defaults: 6 to 400 depending on backend/task.

#### lr

- Type: `float`.
- Typical defaults: `1e-4`, `1e-3`, `4e-3`, etc.

#### weight_decay

- Type: `float`.
- Role: optimizer regularization.

#### seed

- Type: `int`.
- Default in all current backends: `42`.

#### device

- Type: `str`.
- Typical values: `"auto"`, `"cpu"`, `"cuda"`.
- Role: runtime device selection.

#### patience

- Type: `int`.
- Role: early-stop patience behavior where implemented.

#### run_name

- Role: labels run outputs directory/name.

#### output_dir

- Type: `str`.
- Default: `"./outputs"` (all current backends).
- Role: output root directory.

#### log_csv

- Type: `str | None`.
- Default: `None` (all current backends).
- Role: optional custom CSV log path.

#### save_ckpt

- Type: `bool`.
- Default: usually `True`.
- Exceptions: speech backends default to `False`:
    - `src/bcijelly/model/_lstm/speech.py`
    - `src/bcijelly/model/_transformer/speech.py`
- Role: whether to save checkpoints.

#### plot

- Type: `bool`.
- Default: `False` (all current backends).
- Role: whether to generate training diagnostic plots.

#### verbose

- Type: `bool`.
- Default: `False` (all current backends).
- Role: print extra runtime logs.

#### train_datapath

- Type: `str | None`.
- Role: path-based training input (npz flow).
- Required: yes, if `train_dataset` is not provided.

#### val_datapath

- Type: `str | None`.
- Role: path-based validation input.

#### val_ratio

- Type: `float`.
- Role: internal validation split ratio for backends that support internal split.


### Task-Specific Dataset Formats

- Classification/Regression backends usually expect:
    - `train_dataset: tuple[np.ndarray, np.ndarray]`
    - `val_dataset: tuple[np.ndarray, np.ndarray]`

- Speech backends expect 5-tuples:
    - `train_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]`
    - `val_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]`

### Model-Specific Parameters

#### Transformer (classification/regression)

- `num_layers: int`
- `d_model: int`
- `n_heads: int`
- `dropout: float`

#### Transformer (speech)

- Same core Transformer params plus:
    - `kernel_len: int`
    - `stride_len: int`
    - `gaussian_smooth_width: float`
    - `white_noise_sd: float`
    - `constant_offset_sd: float`
    - `use_day_idx: bool`

#### LSTM (classification/regression)

- `num_layers: int`
- `hidden_size: int`
- `dropout: float`
- `bidirectional: bool`
- `pooling: str` (classifier backend)

#### LSTM (speech)

- Same LSTM core params plus:
    - `kernel_len: int`
    - `stride_len: int`
    - `gaussian_smooth_width: float`
    - `white_noise_sd: float`
    - `constant_offset_sd: float`
    - `use_day_idx: bool`

#### LFADS

- `fac_dim: int`
- `dropout: float`
- Regressor-only:
    - `reduce: str = "center"`

#### CycleGAN

- `decoder_epochs: int`
- `decoder_lr: float`
- `g_lr: float`
- `d_lr: float`
- `source_ratio: float`
- `generator_hidden: int`
- `discriminator_hidden: int`
- `dropout_decoder: float`
- `dropout_g: float`
- `dropout_d: float`
- `identity_weight: float`
- `cycle_weight: float`
- `loss_type: str`
- `calib_ratio: float`
- `min_calib_trials: int`
- `max_calib_trials: int | None`
- `enable_alignment: bool`

#### Stabilization

- `baseline_ntrials: int`
- `n_latents: int`
- `fa_n_restarts: int`
- `fa_ll_thresh: float`
- `fa_max_its: int`
- `fa_min_priv_var: float`
- `align_th: float`
- `align_n: int`
- Classifier backend:
    - `pooling: str`
    - `hidden_size: int`
    - `enable_alignment: bool`
- Regressor backend:
    - `hidden_sizes: Sequence[int] | None`
    - `fine_tune: bool`
    - `fine_tune_epochs: int`

### Constraints and Behavior Notes

- `train_dataset` and `train_datapath` are alternative input channels; at least one must be provided.
- External validation is enabled when `val_dataset` or `val_datapath` is provided.
- Some backends use `val_ratio` for internal split, while others require explicit external validation.
- After backend `train(...)` returns, adapter state can be captured for later `model.test(...)` reuse.

## Return Value

- Type: `dict[str, Any]`
- Typical fields include training/validation metrics and run metadata (for example device/run directory).
- Exact keys are backend-dependent.

## Usage

```python
train_result = model.train(
    train_dataset=loaded_data.train_dataset,
    val_dataset=loaded_data.val_dataset,
    device="auto",
    run_name="demo_train",
    epochs=1,
    verbose=False,
)
```

## Source of Truth

- [../../src/bcijelly/model/_transformer/classifier.py](../../src/bcijelly/model/_transformer/classifier.py)
- [../../src/bcijelly/model/_transformer/regressor.py](../../src/bcijelly/model/_transformer/regressor.py)
- [../../src/bcijelly/model/_transformer/speech.py](../../src/bcijelly/model/_transformer/speech.py)
- [../../src/bcijelly/model/_lstm/classifier.py](../../src/bcijelly/model/_lstm/classifier.py)
- [../../src/bcijelly/model/_lstm/regressor.py](../../src/bcijelly/model/_lstm/regressor.py)
- [../../src/bcijelly/model/_lstm/speech.py](../../src/bcijelly/model/_lstm/speech.py)
- [../../src/bcijelly/model/_lfads/classifier.py](../../src/bcijelly/model/_lfads/classifier.py)
- [../../src/bcijelly/model/_lfads/regressor.py](../../src/bcijelly/model/_lfads/regressor.py)
- [../../src/bcijelly/model/_cycle_gan/classifier.py](../../src/bcijelly/model/_cycle_gan/classifier.py)
- [../../src/bcijelly/model/_cycle_gan/regressor.py](../../src/bcijelly/model/_cycle_gan/regressor.py)
- [../../src/bcijelly/model/_stabilization/classifier.py](../../src/bcijelly/model/_stabilization/classifier.py)
- [../../src/bcijelly/model/_stabilization/regressor.py](../../src/bcijelly/model/_stabilization/regressor.py)

## See Also

- Model factory: [model.en.md](model.en.md)
- Test API: [model.test.en.md](model.test.en.md)
- Summary API: [summary.en.md](summary.en.md)
- Demo: [../Demo/simple_demo.en.md](../Demo/simple_demo.en.md)
