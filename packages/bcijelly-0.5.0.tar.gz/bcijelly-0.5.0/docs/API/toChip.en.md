# bcijelly.toChip

```python
class toChip(
    model_path: str,
    input_shape: Sequence[int],
    output_dir: str = "./chip_out",
    mode: Literal["ANN", "SNN"] = "ANN",
    chip_type: Literal["Lynxi", "Taibai"] = "Lynxi",
    sim_steps: int = 20,
    ...
)
```

## Overview

`toChip` provides an experimental bridge for deploying a PyTorch model to supported neuromorphic chip toolchains.

Current target toolchains:

- Lynxi (`ANN` and `SNN`)
- Taibai (`SNN`)

This API is integration-oriented. Runtime execution depends on vendor SDK environments.

## Minimal Usage

```python
import bcijelly as bj

chip_model = bj.toChip(
    model_path=model_path,
    input_shape=input_shape,
    output_dir=output_dir,
    mode=mode,
    chip_type=chip_type,
    sim_steps=sim_steps,
)
compiled_path = chip_model.compile()
```

## Common Parameters

- `model_path`: path to a full PyTorch model object saved by `torch.save(model, path)`.
- `input_shape`: model input shape. For Taibai, 2D/3D/4D formats are supported.
- `output_dir`: output directory for compilation artifacts or mapping outputs.
- `mode`: deployment mode (`ANN` or `SNN`).
- `chip_type`: target chip flow (`Lynxi` or `Taibai`).
- `sim_steps`: simulation steps, used in SNN conversion/mapping.

## Return Value

- Lynxi flow: `compile()` returns output path string.
- Taibai flow: `compile()` returns a result dictionary with mapping/config fields.

## Notes

- This API performs argument checks and dynamic imports for chip SDK dependencies.
- Base install does not include all chip SDK dependencies.
- You can start with optional install `bcijelly[chip]`.
- For chip-specific dependency setup (Lynxi ANN/SNN, Taibai SNN), see: [../Demo/chip_deploy.en.md](../Demo/chip_deploy.en.md)

## See Also

- Demo: [../Demo/chip_deploy.en.md](../Demo/chip_deploy.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)