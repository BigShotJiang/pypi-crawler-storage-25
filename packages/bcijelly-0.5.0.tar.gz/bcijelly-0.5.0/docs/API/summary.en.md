# bcijelly.summary

```python
def summary(
    loaded_data: Any | None = None,
    model: Any | None = None,
    train_result: Mapping[str, Any] | None = None,
    test_result: Mapping[str, Any] | None = None,
    title: str = "Summary",
    mode: Literal["compact", "full"] = "compact",
) -> dict[str, Any]
```

## Overview

`summary` builds, prints, and returns a user-facing summary from core pipeline results.

It can produce:

- A compact overview for quick inspection.
- A full sectioned output for detailed diagnostics.

## Parameters

#### loaded_data

- Default: `None`.
- Role: output from `bcijelly.load_data`, used to extract dataset/job/shape metadata.

#### model

- Default: `None`.
- Role: model instance used to infer module name, task type, and primary metric hints.

#### train_result

- Default: `None`.
- Role: dictionary returned by `model.train`.

#### test_result

- Default: `None`.
- Role: dictionary returned by `model.test`.

#### title

- Default: `Summary`.
- Role: display title for compact print mode.

#### mode

- Default: `compact`.
- Supported: `compact`, `full`.
- Role: controls printed detail level.

## Return Value

`summary(...)` returns a dictionary with fixed top-level sections:

- `compact`: key pipeline highlights.
- `loaded_data`: expanded load/job/shape details.
- `module`: model capability metadata.
- `train_result`: copied training result dictionary.
- `test_result`: copied testing result dictionary.

## Metric Inference Behavior

Summary metric display follows this order:

1. Prefer model-declared `PRIMARY_TEST_METRIC` if present in `test_result`.
2. Fallback scan of common keys: `acc`, `r2`, `mse`, `mae`, `loss`.

For compact mode, metric row is shown in a merged text form similar to:

- `acc: train ..., val ..., test ...`
- or `r2: train ..., val ..., test ...`

## Usage

```python
compact_summary = bcijelly.summary(
    loaded_data=loaded_data,
    model=model,
    train_result=train_result,
    test_result=test_result,
    mode="compact",
)

full_summary = bcijelly.summary(
    loaded_data=loaded_data,
    model=model,
    train_result=train_result,
    test_result=test_result,
    mode="full",
)
```

## See Also

- Model factory: [model.en.md](model.en.md)
- Train API: [model.train.en.md](model.train.en.md)
- Test API: [model.test.en.md](model.test.en.md)
- Data loading: [load_data.en.md](load_data.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)
