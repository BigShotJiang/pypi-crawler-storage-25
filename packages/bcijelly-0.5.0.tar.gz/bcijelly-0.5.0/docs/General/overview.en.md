# BCIJelly Documentation Overview

## Introduction

BCIJelly is a Python toolkit for invasive BCI workflows, including data loading, split handling, model training/testing, and result summarization.

Core pipeline:

1. Load data with `bcijelly.load_data`.
2. Create a model with `bcijelly.model.<model_name>(task=...)`.
3. Train with `model.train(...)`.
4. Evaluate with `model.test(...)`.
5. Summarize with `bcijelly.summary(...)`.

## Installation

Install the base package:

```bash
pip install -U bcijelly
```

Install LFADS extras only when needed:

```bash
pip install -U "bcijelly[lfads]"
```

Install chip deployment extras only when needed:

```bash
pip install -U "bcijelly[chip]"
```

Quick verification:

```bash
python -c "import bcijelly; print(bcijelly.__file__)"
python -c "from bcijelly import load_data, summary; print('bcijelly import OK')"
```

## License

BCIJelly is distributed under the MIT License.

- License file: [../../LICENSE](../../LICENSE)

## Contributors

The contributors of BCIJelly include:

- Liyuan Han (hanliyuan@ion.ac.cn)
- TODO: include contributors

## References

Project-level publication references are not finalized yet.

- TODO: add official BCIJelly paper or technical report citation when available.

Related model reference:

- Sedler AR, Pandarinath C. lfads-torch: A modular and extensible implementation of latent factor analysis via dynamical systems. arXiv:2309.01230.

## Documentation Map

Start here, then move by use case.

### General

- Overview (this page): [overview.en.md](overview.en.md)

### Demo

- Simple general demos: [../Demo/demo.en.md](../Demo/demo.en.md)
- Demos for more complex scenarios: [../Demo/complex_scenarios.en.md](../Demo/complex_scenarios.en.md)
- Chip deployment demo: [../Demo/chip_deploy.en.md](../Demo/chip_deploy.en.md)

### API

- Data loading: [../API/load_data.en.md](../API/load_data.en.md)
- Model factory and capability query: [../API/model.en.md](../API/model.en.md)
- Training API: [../API/model.train.en.md](../API/model.train.en.md)
- Testing API: [../API/model.test.en.md](../API/model.test.en.md)
- Summary API: [../API/summary.en.md](../API/summary.en.md)
- Chip deployment API: [../API/toChip.en.md](../API/toChip.en.md)

