# Chip Deploy Demo

## Dependency Setup by Chip

Install the base package first:

```bash
pip install -U bcijelly
```

Optional unified extra in this repo:

```bash
pip install -U "bcijelly[chip]"
```

Chip-specific requirements used by `bj.toChip`:

- Lynxi ANN: `lyngor`
- Lynxi SNN: `lyngor` + `spikingjelly`
- Taibai SNN: `taibaimodels` + `taibaimapping`

Recommended explicit installs:

```bash
# Lynxi ANN
pip install -U lyngor

# Lynxi SNN
pip install -U lyngor spikingjelly

# Taibai SNN
pip install -U taibaimodels taibaimapping
```

If `lyngor`, `taibaimodels`, or `taibaimapping` cannot be installed from public PyPI,
install them from the corresponding vendor SDK package source and ensure the Python
environment can import these modules.

## Minimal Invocation

```python
import bcijelly as bj

chip_model = bj.toChip(
    model_path,
    input_shape,
    output_dir,
    mode,
    chip_type,
    sim_steps,
)
compiled_path = chip_model.compile()
print(compiled_path)
```

## Lynxi Example

```python
import bcijelly as bj

chip_model = bj.toChip(
    model_path="./model.pth",
    input_shape=(1, 1, 128, 128),
    output_dir="./lynxi_out",
    mode="SNN",
    chip_type="Lynxi",
    sim_steps=20,
)

compiled_path = chip_model.compile()
print("Compiled SNN(Lynxi) model:", compiled_path)
```

## Taibai Example

```python
import bcijelly as bj

chip_model = bj.toChip(
    model_path="./model.pth",
    input_shape=(1, 1, 128, 128),
    output_dir="./taibai_out",
    mode="SNN",
    chip_type="Taibai",
    sim_steps=8,
)

compiled_result = chip_model.compile()
print("Compiled SNN(Taibai) result keys:", compiled_result.keys())
```

## Notes

- This demo is for API usage illustration.
- Actual chip deployment requires external SDK environment and hardware/runtime support.

## See Also

- API: [../API/toChip.en.md](../API/toChip.en.md)