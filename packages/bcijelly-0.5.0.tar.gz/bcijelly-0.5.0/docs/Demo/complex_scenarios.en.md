# Cross-Day and Per-Day Evaluation

When your experiment is cross-day and you need either:

- One global test result from merged test samples, or
- Per-day test metrics and an aggregated score.

## Cross-Day Regression with Per-Day Aggregation

```python
import numpy as np
import bcijelly

model = bcijelly.model.transformer(task="regression")

loaded_data = bcijelly.load_data(
    dataset_name="5_Jango_force",
    protocol="cross_day",
    task="regression",
    subject_index=0,
    split_ratio="7:1:2",
    verbose=False,
)

train_result = model.train(
    train_dataset=loaded_data.train_dataset,
    val_dataset=loaded_data.val_dataset,
    seed=42,
    device="auto",
    run_name="demo_cross_day_transformer_regression_jango",
    epochs=1,
    plot=False,
    verbose=False,
)

day_r2_list = []
for one_day_test_dataset in loaded_data.test_day_datasets:
    one_day_result = model.test(
        test_dataset=one_day_test_dataset,
        verbose=False,
    )
    day_r2_list.append(float(one_day_result["r2"]))

test_result = {
    "r2": float(np.mean(day_r2_list)),
    "per_day_r2": day_r2_list,
}

compact_summary = bcijelly.summary(
    loaded_data=loaded_data,
    model=model,
    train_result=train_result,
    test_result=test_result,
    mode="compact",
)
```

## Alternative: Global Test Once

If you only need one test pass, evaluate merged test data:

```python
test_result = model.test(
    test_dataset=loaded_data.test_dataset,
    verbose=False,
)
```

## Practical Notes

- For cross-day, `loaded_data.test_day_datasets` is useful for day-level stability checks.
- Metric keys depend on task/backend (for example `acc` for classification, `r2` for regression).
- Keep your own aggregation dictionary explicit (`per_day_acc`, `per_day_r2`) for traceability.

## See Also

- API: [../API/load_data.en.md](../API/load_data.en.md)
- API: [../API/model.test.en.md](../API/model.test.en.md)
- API: [../API/summary.en.md](../API/summary.en.md)
- Simple flow: [simple_demo.en.md](simple_demo.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)


# Speech Dataset Demo

Use this section when your dataset is speech-oriented and you want a `train-test` protocol workflow aligned with the project test case.

## Speech Train-Test Workflow

```python
import bcijelly

model = bcijelly.model.lfads(task="speech")

loaded_data = bcijelly.load_data(
    dataset_name="11_Speech",
    protocol="train-test",
    task="speech",
    split_ratio="3:3:1",
    verbose=False,
)

train_result = model.train(
    loaded_data.train_dataset,
    loaded_data.val_dataset,
    run_name="demo_train_test_speech",
    epochs=1,
    verbose=False,
)

test_result = model.test(
    loaded_data.test_dataset,
    verbose=False,
)

summary_result = bcijelly.summary(
    loaded_data,
    model,
    train_result,
    test_result,
    mode="compact",
)
```

## Required Inputs

- Speech dataset declaration that supports `task="speech"` and `protocol="train-test"`.
- A speech-capable model/task pair (for example `bcijelly.model.lfads(task="speech")`).

## Expected Outputs

- `loaded_data`: includes `train_dataset`, optional `val_dataset`, and `test_dataset` for speech pipeline.
- `train_result`: dictionary returned by `model.train`.
- `test_result`: dictionary returned by `model.test`.
- `summary_result`: compact result dictionary from `bcijelly.summary`.

## Practical Notes

- For speech task, backends generally consume speech-format tuples produced by `load_data`.
- If you need additional training controls, you can extend `model.train(...)` with supported backend parameters such as `seed`, `device`, and other model-specific options.

## See Also

- API: [../API/load_data.en.md](../API/load_data.en.md)
- API: [../API/model.en.md](../API/model.en.md)
- API: [../API/model.train.en.md](../API/model.train.en.md)
- API: [../API/model.test.en.md](../API/model.test.en.md)
- API: [../API/summary.en.md](../API/summary.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)

