# Load Data Demo

```python
import bcijelly as bj

loaded_data = bj.load_data(
    dataset_name="1_FALCONM1-A",        
    protocol="single_day",                  # "single_day" | "cross_day" | ...
    task="classification",                  # "classification" | "regression" | ...
    subject_index=0,              
    day_index=0,                
    split_ratio="7:1:2",        
    verbose=False,
)

train_dataset, val_dataset, test_dataset = loaded_data.train_dataset, loaded_data.val_dataset, loaded_data.test_dataset

train_neural_signal, train_label = train_dataset
val_neural_signal, val_label = val_dataset
test_neural_signal, test_label = test_dataset

print(train_neural_signal.shape, train_label.shape)
print(val_neural_signal.shape, val_label.shape)
print(test_neural_signal.shape, test_label.shape)
```


# Complete Usage Demo

##

```python
import bcijelly

model = bcijelly.model.transformer(task="classification")

loaded_data = bcijelly.load_data(
    dataset_name="1_FALCONM1-A",
    protocol="single_day", task="classification",
    subject_index=0, day_index=0,
    split_ratio="7:1:2",
    verbose=False,
)

train_result = model.train(
    train_dataset=loaded_data.train_dataset, val_dataset=loaded_data.val_dataset,
    device="auto",
    run_name="demo",
    verbose=False,
)

test_result = model.test(
    test_dataset=loaded_data.test_dataset,
    verbose=False,
)

summary_result = bcijelly.summary(
    loaded_data=loaded_data,
    model=model,
    train_result=train_result,
    test_result=test_result,
    mode="compact",
)
```

## Required Inputs

- A valid dataset available locally or downloadable by `load_data`.
- A model/task pair that is supported (for example `transformer` + `classification`).

## Expected Outputs

- `loaded_data`: includes `train_dataset`, optional `val_dataset`, `test_dataset`.
- `train_result`: dictionary returned by `model.train`.
- `test_result`: dictionary returned by `model.test`.
- `summary_result`: dictionary from `bcijelly.summary` with at least a `compact` section.

## See Also

- API: [../API/load_data.en.md](../API/load_data.en.md)
- API: [../API/model.en.md](../API/model.en.md)
- API: [../API/model.train.en.md](../API/model.train.en.md)
- API: [../API/model.test.en.md](../API/model.test.en.md)
- API: [../API/summary.en.md](../API/summary.en.md)
- Demo: [chip_deploy.en.md](chip_deploy.en.md)
- General entry: [../General/overview.en.md](../General/overview.en.md)


# SearchAgent Demo

`SearchAgent` automatically searches neural network architectures, selects an ensemble, and evaluates
performance across test days. A validation set is required because the search uses it as a selection signal.

```python
import bcijelly as bj
from bcijelly import SearchAgent

# 1. Load data — split_ratio must include a val portion (3-part ratio)
data = bj.load_data(
    dataset_name="1_FALCONM1-A",
    protocol="cross_day",
    task="classification",
    subject_index=0,
    split_ratio="7:1:2",   # train : val : test
    verbose=False,
)

# 2. Create agent
search_agent = SearchAgent(
    task_type="classification",
    device="auto",            # "cuda" | "cpu" | "auto"
    epochs=12,
    max_search_rounds=4,
    output_dir="outputs/search_agent_demo",
)

# 3. Fit — accepts data.train_dataset and data.val_dataset directly
search_agent.fit(data.train_dataset, data.val_dataset)

# 4. Evaluate across test days
#    test_day_data: dict mapping day-name -> (X, y) tuple
test_day_data = {
    f"day_{i}": ds for i, ds in enumerate(data.test_day_datasets)
}
result = search_agent.test(test_day_data)
# Prints: [SearchAgent] Test complete — N day(s), average accuracy: 0.XXXX
```

## Notes

- `fit` accepts any `(X, y)` tuple pair, including `data.train_dataset` / `data.val_dataset` directly.
- `val_dataset=None` raises a `ValueError`; always use a 3-part `split_ratio` (e.g., `"7:1:2"`).
- `test` evaluates the ensemble day by day and returns a summary dict; it also prints a one-line result to stdout.
- `predict(X)` is available for single-array inference after `fit`.
