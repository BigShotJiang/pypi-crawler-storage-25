from __future__ import annotations

from collections.abc import Mapping
from pprint import pformat
from typing import Any, Literal


def _module_name(model: Any | None) -> str:
    if model is None:
        return ""
    explicit_name = getattr(model, "model_name", None)
    if isinstance(explicit_name, str) and explicit_name:
        return explicit_name
    module_name = getattr(model, "__name__", "")
    if not isinstance(module_name, str):
        return ""
    parts = module_name.split(".")
    if len(parts) >= 2 and parts[-1] in {"classifier", "regressor", "speech"}:
        return parts[-2]
    if parts:
        return parts[-1]
    return module_name


def _shape_or_none(dataset: Any) -> tuple[Any, Any] | None:
    if dataset is None:
        return None
    if not isinstance(dataset, tuple) or len(dataset) < 2:
        return None
    x_shape = getattr(dataset[0], "shape", None)
    y_shape = getattr(dataset[1], "shape", None)
    return x_shape, y_shape


def _infer_metric_name(model: Any | None, test_result: Mapping[str, Any] | None) -> str | None:
    metric = getattr(model, "PRIMARY_TEST_METRIC", None)
    if isinstance(metric, str) and metric and test_result is not None and metric in test_result:
        return metric
    if test_result is None:
        return None
    for candidate in ("acc", "r2", "mse", "mae", "loss"):
        if candidate in test_result:
            return candidate
    return None


def _primary_metric_value(result: Mapping[str, Any], metric_name: str | None, prefix: str = "") -> Any:
    if not metric_name:
        return None
    candidate_keys = [f"{prefix}{metric_name}"] if prefix else [metric_name]
    for key in candidate_keys:
        if key in result:
            return result[key]
    return None


def _print_summary_block(title: str, items: Mapping[str, Any]) -> None:
    print(title)
    if not items:
        print("{}")
        return
    key_width = max(len(str(key)) for key in items)
    for key, value in items.items():
        pretty_value = pformat(value, sort_dicts=False, compact=False, width=88)
        print(f"{key:<{key_width}} : {pretty_value}")


def _load_shape(dataset: Any) -> tuple[Any, Any] | None:
    if not isinstance(dataset, tuple) or len(dataset) < 2:
        return None
    x_arr = dataset[0]
    y_arr = dataset[1]
    x_shape = getattr(x_arr, "shape", None)
    y_shape = getattr(y_arr, "shape", None)
    if x_shape is None or y_shape is None:
        return None
    return x_shape, y_shape


def _day_count(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        return len(value)
    return None


def _sample_count(dataset: Any) -> int | None:
    shape = _load_shape(dataset)
    if shape is None:
        return None
    return int(shape[0][0])


def _build_compact_section(
    loaded_data: Any | None,
    model: Any | None,
    train_result: Mapping[str, Any],
    test_result: Mapping[str, Any],
) -> dict[str, Any]:
    job = getattr(loaded_data, "job", None)
    requested_task = getattr(loaded_data, "requested_task", None)
    metric_name = _infer_metric_name(model, test_result)
    train_metric_value = _primary_metric_value(train_result, metric_name, prefix="train_")
    val_metric_value = _primary_metric_value(train_result, metric_name, prefix="val_")
    test_metric_value = _primary_metric_value(test_result, metric_name)

    subject_index = getattr(job, "subject_index", None)
    subject_name = getattr(job, "subject_name", None)
    subject_value = None
    if subject_index is not None or subject_name is not None:
        subject_value = f"[{subject_index}]: {subject_name}"

    section: dict[str, Any] = {
        "dataset": getattr(job, "dataset", None),
        "subject": subject_value,
        "protocol": getattr(job, "protocol", None),
    }
    
    if getattr(job, "protocol", None) == "single_day":
        day_index = getattr(job, "day_index", None)
        train_n = _sample_count(getattr(loaded_data, "train_dataset", None))
        val_n = _sample_count(getattr(loaded_data, "val_dataset", None))
        test_n = _sample_count(getattr(loaded_data, "test_dataset", None))
        section.update(
            {
                "trails": f"[day {day_index}] train {train_n}, val {val_n}, test {test_n}",
            }
        )
    else:
        train_day_count = _day_count(getattr(job, "train_paths", None))
        val_day_count = _day_count(getattr(job, "val_paths", None))
        test_day_count = _day_count(getattr(job, "test_paths", None))
        section.update(
            {
                "days": f"train {train_day_count}, val {val_day_count}, test {test_day_count}",
            }
        )
    
    task_display = getattr(model, "TASK_TYPE", None)
    if task_display is None and requested_task is not None:
        task_display = f"{requested_task} (for loading)"

    section.update({
        "module": _module_name(model),
        "task": task_display,
        "device": train_result.get("device"),
        "run_dir": train_result.get("run_dir"),
    })

    if metric_name is not None:
        section[metric_name] = (
            f"train {train_metric_value}, val {val_metric_value}, test {test_metric_value}"
        )

    return {key: value for key, value in section.items() if value is not None}

def _build_loaded_data_section(loaded_data: Any | None) -> dict[str, Any]:
    if loaded_data is None:
        return {}
    test_day_datasets = getattr(loaded_data, "test_day_datasets", None)
    job = getattr(loaded_data, "job", None)
    job_section = {}
    if job is not None:
        job_section = {
            "dataset": getattr(job, "dataset", None),
            "protocol": getattr(job, "protocol", None),
            "train_day": getattr(job, "train_day", None),
            "test_day": getattr(job, "test_day", None),
            "val_day": getattr(job, "val_day", None),
            "train_path": getattr(job, "train_path", None),
            "test_path": getattr(job, "test_path", None),
            "train_paths": getattr(job, "train_paths", None),
            "val_paths": getattr(job, "val_paths", None),
            "test_paths": getattr(job, "test_paths", None),
            "dataset_format": getattr(job, "dataset_format", None),
            "subject_name": getattr(job, "subject_name", None),
            "subject_index": getattr(job, "subject_index", None),
            "day_index": getattr(job, "day_index", None),
        }
    return {
        "train_shape": _load_shape(getattr(loaded_data, "train_dataset", None)),
        "val_shape": _load_shape(getattr(loaded_data, "val_dataset", None)),
        "test_shape": _load_shape(getattr(loaded_data, "test_dataset", None)),
        "aligned_shape": getattr(loaded_data, "aligned_shape", None),
        "requested_task": getattr(loaded_data, "requested_task", None),
        "train_label_key": getattr(loaded_data, "train_label_key", None),
        "val_label_key": getattr(loaded_data, "val_label_key", None),
        "test_label_key": getattr(loaded_data, "test_label_key", None),
        "has_val_dataset": getattr(loaded_data, "val_dataset", None) is not None,
        "has_test_day_datasets": bool(test_day_datasets),
        "test_day_dataset_count": len(test_day_datasets) if test_day_datasets else 0,
        "job": job_section or None,
    }


def _build_module_section(model: Any | None) -> dict[str, Any]:
    if model is None:
        return {}
    return {
        "module_qualname": getattr(model, "__name__", None),
        "task_type": getattr(model, "TASK_TYPE", None),
        "primary_test_metric": getattr(model, "PRIMARY_TEST_METRIC", None),
        "supports_external_val": getattr(model, "SUPPORTS_EXTERNAL_VAL", None),
        "supports_train_without_val": getattr(model, "SUPPORTS_TRAIN_WITHOUT_VAL", None),
        "auto_split_val_if_missing": getattr(model, "AUTO_SPLIT_VAL_IF_MISSING", None),
    }


def summary(
    # *,
    loaded_data: Any | None = None,
    model: Any | None = None,
    train_result: Mapping[str, Any] | None = None,
    test_result: Mapping[str, Any] | None = None,
    title: str = "Summary",
    mode: Literal["compact", "full"] = "compact",
) -> dict[str, Any]:
    """Build, print, and return a user-facing summary from core pipeline results."""
    train_result_dict = dict(train_result) if train_result is not None else {}
    test_result_dict = dict(test_result) if test_result is not None else {}

    core = _build_compact_section(loaded_data, model, train_result_dict, test_result_dict)
    loaded_data_section = _build_loaded_data_section(loaded_data)
    module_section = _build_module_section(model)

    result: dict[str, Any] = {
        "compact": core,
        "loaded_data": loaded_data_section,
        "module": module_section,
        "train_result": train_result_dict,
        "test_result": test_result_dict,
    }

    if mode == "compact":
        _print_summary_block(title, core)
    else:
        print()
        _print_summary_block("Loaded data details:", loaded_data_section)
        print()
        _print_summary_block("Module details:", module_section)
        print()
        _print_summary_block("Train result:", train_result_dict)
        print()
        _print_summary_block("Test result:", test_result_dict)

    return result
