from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

X_KEYS = ("neural_activity",)
CLASSIFICATION_Y_KEYS = ("classification_label",)
REGRESSION_Y_KEYS = ("regression_target",)
SPEECH_Y_KEYS = ("speech_label",)
DEFAULT_TASK = "classification"
SUPPORTED_TASKS = ("classification", "regression", "speech")
TASK_TO_Y_KEYS: dict[str, tuple[str, ...]] = {
    "classification": CLASSIFICATION_Y_KEYS,
    "regression": REGRESSION_Y_KEYS,
    "speech": SPEECH_Y_KEYS,
}

DEFAULT_DATA_DIR = Path("data")
DEFAULT_HF_REPO_ID = "LiyuanHan/bcijelly-invasive"
DEFAULT_HF_REPO_TYPE = "dataset"

DATASET_FORMAT_DAY_FILES = "day_files"
DATASET_FORMAT_MULTI_SUBJECT = "multi_subject"
DATASET_FORMAT_SINGLE_FILE = "single_file"
DATASET_FORMAT_SPLIT_FILES = "split_files"
DATASET_FORMAT_VIRTUAL_SESSIONS = "virtual_sessions"
DATASET_COMPATIBILITY_FILENAMES = ("dataset_compatibility.json",)

ArrayPair = tuple[np.ndarray, np.ndarray]
SpeechArrayTuple = tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]
DatasetTuple = ArrayPair | SpeechArrayTuple
DayRef = Any


@dataclass(frozen=True)
class DatasetJob:
    """描述一次数据加载任务。"""

    protocol: str
    dataset: str
    train_day: str
    test_day: str
    train_path: DayRef | None = None
    test_path: DayRef | None = None
    train_paths: list[DayRef] | None = None
    val_paths: list[DayRef] | None = None
    test_paths: list[DayRef] | None = None
    val_day: str | None = None
    dataset_format: str = DATASET_FORMAT_DAY_FILES
    subject_name: str | None = None
    subject_index: int | None = None
    day_index: int | None = None


@dataclass
class DataLoadResult:
    """统一的数据加载结果。"""

    train_dataset: DatasetTuple
    test_dataset: DatasetTuple
    val_dataset: DatasetTuple | None = None
    test_day_datasets: list[DatasetTuple] | None = None
    train_label_key: str = ""
    val_label_key: str = ""
    test_label_key: str = ""
    aligned_shape: tuple[int, int] | None = None
    job: DatasetJob | None = None
    requested_task: str | None = None


@dataclass(frozen=True)
class DatasetStructure:
    """数据集目录结构描述。"""

    dataset_name: str
    dataset_root: Path
    storage_format: str
    files: list[DayRef] = field(default_factory=list)
    train_file: Path | None = None
    val_file: Path | None = None
    test_file: Path | None = None
    subject_names: list[str] = field(default_factory=list)
    subject_paths: list[Path] = field(default_factory=list)


def make_virtual_day_ref(source_path: Path, session_name: str) -> dict[str, Any]:
    return {
        "kind": "virtual_session",
        "source_path": source_path,
        "session_name": str(session_name),
    }


def is_virtual_day_ref(day_ref: Any) -> bool:
    return isinstance(day_ref, dict) and day_ref.get("kind") == "virtual_session"


def day_ref_name(day_ref: Any) -> str:
    if is_virtual_day_ref(day_ref):
        return str(day_ref["session_name"])
    if isinstance(day_ref, Path):
        return day_ref.stem
    return str(day_ref)


def day_ref_label(day_ref: Any) -> str:
    if is_virtual_day_ref(day_ref):
        return f"{day_ref['source_path']}::{day_ref['session_name']}"
    return str(day_ref)


def dataset_dir(dataset_name: str, data_dir: Path | None = None) -> Path:
    root = (data_dir or DEFAULT_DATA_DIR).resolve()
    return root / "invasive" / dataset_name


def has_dataset(dataset_name: str, data_dir: Path | None = None) -> bool:
    target_dir = dataset_dir(dataset_name, data_dir)
    return target_dir.exists() and any(target_dir.rglob("*.npz"))


def download_dataset(
    dataset_name: str,
    *,
    data_dir: Path | None = None,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
) -> Path:
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "huggingface_hub is required for automatic dataset download. "
            "Please install it with: pip install huggingface_hub"
        ) from exc

    root = (data_dir or DEFAULT_DATA_DIR).resolve()
    root.mkdir(parents=True, exist_ok=True)

    _ = snapshot_download(
        repo_id=repo_id,
        repo_type=repo_type,
        allow_patterns=[f"invasive/{dataset_name}/**"],
        local_dir=str(root),
    )

    target_dir = dataset_dir(dataset_name, root)
    if not target_dir.exists() or not any(target_dir.rglob("*.npz")):
        raise FileNotFoundError(
            f"Dataset '{dataset_name}' was not found in Hugging Face repo '{repo_id}', "
            f"or no .npz files were downloaded into {target_dir}."
        )

    return target_dir


def ensure_dataset_available(
    dataset_name: str,
    *,
    data_dir: Path | None = None,
    auto_download: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
) -> Path:
    target_dir = dataset_dir(dataset_name, data_dir)
    if target_dir.exists() and any(target_dir.rglob("*.npz")):
        return target_dir
    if not auto_download:
        raise FileNotFoundError(f"Dataset '{dataset_name}' not found in local path: {target_dir}")
    return download_dataset(dataset_name, data_dir=data_dir, repo_id=repo_id, repo_type=repo_type)
