from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.model_selection import train_test_split

from ._types import (
    CLASSIFICATION_Y_KEYS,
    DEFAULT_TASK,
    DatasetTuple,
    SpeechArrayTuple,
    TASK_TO_Y_KEYS,
    X_KEYS,
    ArrayPair,
    DayRef,
    is_virtual_day_ref,
)


def is_valid_classification_label(y: np.ndarray) -> bool:
    return y.ndim == 1


def is_valid_regression_target(y: np.ndarray) -> bool:
    return y.ndim == 3 and np.issubdtype(y.dtype, np.number)


def is_valid_speech_label(y: np.ndarray) -> bool:
    if not np.issubdtype(y.dtype, np.integer):
        return False
    return y.ndim in {1, 2}


def _normalize_task(task: str | None) -> str:
    if task is None:
        return DEFAULT_TASK
    return str(task)


def _is_valid_label_for_task(y: np.ndarray, task: str) -> bool:
    if task == "regression":
        return is_valid_regression_target(y)
    if task == "speech":
        return is_valid_speech_label(y)
    return is_valid_classification_label(y)


def _validate_task_shapes(x: np.ndarray, y: np.ndarray, *, task: str, npz_path: Path) -> None:
    if x.ndim != 3:
        raise ValueError(
            f"Invalid neural_activity shape in {npz_path}: expected (N,T,C), got {x.shape}."
        )

    if task == "classification":
        if y.ndim != 1:
            raise ValueError(
                f"Invalid label shape for task='{task}' in {npz_path}: expected (N,), got {y.shape}."
            )
        return

    if task == "speech":
        if y.ndim not in {1, 2}:
            raise ValueError(
                f"Invalid label shape for task='{task}' in {npz_path}: expected (N,) or (N,L), got {y.shape}."
            )
        return

    if task == "regression":
        if y.ndim != 3:
            raise ValueError(
                f"Invalid regression_target shape in {npz_path}: expected (N,T,2), got {y.shape}."
            )
        if y.shape[1] != x.shape[1]:
            raise ValueError(
                f"Mismatched temporal length in {npz_path}: neural_activity T={x.shape[1]}, "
                f"regression_target T={y.shape[1]}."
            )
        if y.shape[2] != 2:
            raise ValueError(
                f"Invalid regression_target shape in {npz_path}: expected last dim 2, got {y.shape[2]}."
            )


def load_task_npz(npz_path: Path, *, task: str | None = DEFAULT_TASK) -> tuple[np.ndarray, np.ndarray, str]:
    requested_task = _normalize_task(task)
    y_candidates = TASK_TO_Y_KEYS.get(requested_task)
    if not y_candidates:
        raise ValueError(f"Unsupported task: {requested_task}. Supported tasks: {sorted(TASK_TO_Y_KEYS.keys())}")

    if not npz_path.exists():
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")

    with np.load(npz_path, allow_pickle=True) as data:
        files = list(data.files)

        x_key = next((key for key in X_KEYS if key in files), None)
        if x_key is None:
            raise KeyError(f"Unable to infer feature key from {npz_path}. Available keys: {files}")

        y_key = None
        for candidate in y_candidates:
            if candidate not in files:
                continue
            candidate_y = np.asarray(data[candidate])
            if _is_valid_label_for_task(candidate_y, requested_task):
                y_key = candidate
                break

        if y_key is None:
            raise ValueError(
                f"No valid labels found for task='{requested_task}' in {npz_path}. Available keys: {files}. "
                f"Expected one of keys: {list(y_candidates)}."
            )

        x = np.asarray(data[x_key])
        y = np.asarray(data[y_key])

    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples in {npz_path}: X {x.shape}, y {y.shape}")

    _validate_task_shapes(x, y, task=requested_task, npz_path=npz_path)

    return x, y, y_key


def _validate_speech_arrays(
    x: np.ndarray,
    y: np.ndarray,
    x_len: np.ndarray,
    y_len: np.ndarray,
    day_idx: np.ndarray,
    *,
    npz_path: Path,
) -> SpeechArrayTuple:
    if x.ndim != 3:
        raise ValueError(
            f"Invalid neural_activity shape in {npz_path}: expected (N,T,C), got {x.shape}."
        )
    if y.ndim != 2:
        raise ValueError(
            f"Invalid speech_label shape in {npz_path}: expected (N,L), got {y.shape}."
        )

    num_samples = x.shape[0]
    for name, arr in (("speech_label", y), ("X_len", x_len), ("y_len", y_len), ("dayIdx", day_idx)):
        if arr.shape[0] != num_samples:
            raise ValueError(
                f"Mismatched samples in {npz_path}: neural_activity has {num_samples}, {name} has {arr.shape[0]}."
            )

    x = np.asarray(x, dtype=np.float32)
    y = np.asarray(y, dtype=np.int64)
    x_len = np.asarray(x_len, dtype=np.int64).reshape(-1)
    y_len = np.asarray(y_len, dtype=np.int64).reshape(-1)
    day_idx = np.asarray(day_idx, dtype=np.int64).reshape(-1)

    if np.any(x_len <= 0):
        raise ValueError(f"Invalid X_len in {npz_path}: all values must be positive.")
    if np.any(y_len <= 0):
        raise ValueError(f"Invalid y_len in {npz_path}: all values must be positive.")
    if np.any(day_idx < 0):
        raise ValueError(f"Invalid dayIdx in {npz_path}: all values must be non-negative.")
    if np.any(x_len > x.shape[1]):
        raise ValueError(
            f"Invalid X_len in {npz_path}: some values exceed padded time dimension {x.shape[1]}."
        )
    if np.any(y_len > y.shape[1]):
        raise ValueError(
            f"Invalid y_len in {npz_path}: some values exceed padded label dimension {y.shape[1]}."
        )

    return x, y, x_len, y_len, day_idx


def load_speech_npz(npz_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, str]:
    if not npz_path.exists():
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")

    with np.load(npz_path, allow_pickle=True) as data:
        files = list(data.files)
        x_key = next((key for key in X_KEYS if key in files), None)
        if x_key is None:
            raise KeyError(f"Unable to infer speech feature key from {npz_path}. Available keys: {files}")

        if "speech_label" not in files:
            raise KeyError(
                f"Speech dataset in {npz_path} is missing 'speech_label'. Available keys: {files}"
            )
        if "X_len" not in files or "y_len" not in files:
            raise KeyError(
                f"Speech dataset in {npz_path} must contain X_len and y_len. Available keys: {files}"
            )

        x = np.asarray(data[x_key])
        y = np.asarray(data["speech_label"])
        x_len = np.asarray(data["X_len"])
        y_len = np.asarray(data["y_len"])
        if "dayIdx" in files:
            day_idx = np.asarray(data["dayIdx"])
        else:
            day_idx = np.zeros((x.shape[0],), dtype=np.int64)

    validated = _validate_speech_arrays(x, y, x_len, y_len, day_idx, npz_path=npz_path)
    return (*validated, "speech_label")


def load_classification_npz(npz_path: Path) -> tuple[np.ndarray, np.ndarray, str]:
    return load_task_npz(npz_path, task="classification")


def load_visual_grating_virtual_day(
    day_ref: dict[str, Any],
    *,
    task: str | None = DEFAULT_TASK,
) -> tuple[np.ndarray, np.ndarray, str]:
    requested_task = _normalize_task(task)
    y_candidates = TASK_TO_Y_KEYS.get(requested_task)
    if not y_candidates:
        raise ValueError(f"Unsupported task: {requested_task}. Supported tasks: {sorted(TASK_TO_Y_KEYS.keys())}")

    source_path = Path(day_ref["source_path"])
    session_name = str(day_ref["session_name"])

    if not source_path.exists():
        raise FileNotFoundError(f"NPZ file not found: {source_path}")

    with np.load(source_path, allow_pickle=True) as data:
        files = list(data.files)
        label_key = next((candidate for candidate in y_candidates if candidate in files), None)
        if label_key is None:
            raise KeyError(
                f"Visual grating file does not contain task label key for task='{requested_task}'. "
                f"Expected one of {list(y_candidates)}, got keys {files}"
            )

        required = ("neural_activity", label_key, "file_info")
        if not all(key in files for key in required):
            raise KeyError(
                f"Visual grating master file missing required keys {required}: {source_path} with keys {files}"
            )

        samples = np.asarray(data["neural_activity"])
        labels = np.asarray(data[label_key])
        file_info = np.asarray(data["file_info"])

    mask = file_info == session_name
    if not np.any(mask):
        raise ValueError(f"Session '{session_name}' not found in {source_path}")

    x = np.asarray(samples[mask])
    y = np.asarray(labels[mask])

    if y.ndim == 2 and y.shape[1] == 1:
        y = y[:, 0]

    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples in virtual session {session_name}: X {x.shape}, y {y.shape}")

    return x, y, label_key


def load_pre_split_classification_npz(
    npz_path: Path,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, str, str]:
    if not npz_path.exists():
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")

    with np.load(npz_path, allow_pickle=True) as data:
        files = list(data.files)
        required = ("train_data", "label_train", "test_data", "label_test")
        if not all(key in files for key in required):
            raise KeyError(f"Pre-split keys not found in {npz_path}. Available keys: {files}")

        train_x = np.asarray(data["train_data"])
        train_y = np.asarray(data["label_train"])
        test_x = np.asarray(data["test_data"])
        test_y = np.asarray(data["label_test"])

    if train_y.ndim == 2 and train_y.shape[1] == 1:
        train_y = train_y[:, 0]
    if test_y.ndim == 2 and test_y.shape[1] == 1:
        test_y = test_y[:, 0]

    if train_x.shape[0] != train_y.shape[0]:
        raise ValueError(f"Mismatched train samples in {npz_path}: X {train_x.shape}, y {train_y.shape}")
    if test_x.shape[0] != test_y.shape[0]:
        raise ValueError(f"Mismatched test samples in {npz_path}: X {test_x.shape}, y {test_y.shape}")

    return train_x, train_y, test_x, test_y, "label_train", "label_test"


def is_pre_split_single_day_npz(npz_path: Any) -> bool:
    if is_virtual_day_ref(npz_path):
        return False
    if not isinstance(npz_path, Path):
        return False
    if not npz_path.exists():
        return False

    with np.load(npz_path, allow_pickle=True) as data:
        files = set(data.files)
    return {"train_data", "label_train", "test_data", "label_test"}.issubset(files)


def load_train_test_file_pair(
    train_path: Path,
    test_path: Path,
    *,
    task: str | None = DEFAULT_TASK,
) -> tuple[Any, ...]:
    if _normalize_task(task) == "speech":
        train_x, train_y, train_x_len, train_y_len, train_day_idx, train_label_key = load_speech_npz(train_path)
        test_x, test_y, test_x_len, test_y_len, test_day_idx, test_label_key = load_speech_npz(test_path)
        return (
            train_x,
            train_y,
            train_x_len,
            train_y_len,
            train_day_idx,
            test_x,
            test_y,
            test_x_len,
            test_y_len,
            test_day_idx,
            train_label_key,
            test_label_key,
        )
    train_x, train_y, train_label_key = load_task_npz(train_path, task=task)
    test_x, test_y, test_label_key = load_task_npz(test_path, task=task)
    return train_x, train_y, test_x, test_y, train_label_key, test_label_key


def load_train_val_test_file_triplet(
    train_path: Path,
    val_path: Path,
    test_path: Path,
    *,
    task: str | None = DEFAULT_TASK,
) -> tuple[Any, ...]:
    if _normalize_task(task) == "speech":
        train_x, train_y, train_x_len, train_y_len, train_day_idx, train_label_key = load_speech_npz(train_path)
        val_x, val_y, val_x_len, val_y_len, val_day_idx, val_label_key = load_speech_npz(val_path)
        test_x, test_y, test_x_len, test_y_len, test_day_idx, test_label_key = load_speech_npz(test_path)
        return (
            train_x,
            train_y,
            train_x_len,
            train_y_len,
            train_day_idx,
            val_x,
            val_y,
            val_x_len,
            val_y_len,
            val_day_idx,
            test_x,
            test_y,
            test_x_len,
            test_y_len,
            test_day_idx,
            train_label_key,
            val_label_key,
            test_label_key,
        )
    train_x, train_y, train_label_key = load_task_npz(train_path, task=task)
    val_x, val_y, val_label_key = load_task_npz(val_path, task=task)
    test_x, test_y, test_label_key = load_task_npz(test_path, task=task)
    return (
        train_x,
        train_y,
        val_x,
        val_y,
        test_x,
        test_y,
        train_label_key,
        val_label_key,
        test_label_key,
    )


def get_stratify_labels(y: np.ndarray, split_size: float) -> np.ndarray | None:
    y_arr = np.asarray(y)
    if y_arr.ndim == 2 and y_arr.shape[1] == 1:
        y_arr = y_arr[:, 0]
    if y_arr.ndim != 1:
        return None

    _, counts = np.unique(y_arr, return_counts=True)
    n_split = max(1, int(math.ceil(len(y_arr) * split_size)))
    if len(counts) < 2 or counts.min() < 2 or n_split < len(counts):
        return None
    return y_arr


def parse_split_ratio(split_ratio: str) -> tuple[int, ...]:
    parts = [part.strip() for part in split_ratio.split(":")]
    if len(parts) not in {2, 3}:
        raise ValueError(
            f"split_ratio must contain 2 or 3 non-negative integers separated by ':', got {split_ratio!r}"
        )
    if any(part == "" for part in parts):
        raise ValueError(f"split_ratio contains an empty part: {split_ratio!r}")

    values: list[int] = []
    for part in parts:
        if not part.isdigit():
            raise ValueError(f"split_ratio must contain non-negative integers only, got {split_ratio!r}")
        values.append(int(part))

    if all(value == 0 for value in values):
        raise ValueError(f"split_ratio cannot be all zeros, got {split_ratio!r}")

    if values[0] == 0 or values[-1] == 0:
        raise ValueError(
            f"split_ratio must assign non-zero ratios to train and test, got {split_ratio!r}"
        )

    return tuple(values)


def allocate_split_counts(total: int, split_parts: tuple[int, ...]) -> tuple[int, ...]:
    if total < 0:
        raise ValueError(f"total must be non-negative, got {total}")
    if len(split_parts) not in {2, 3}:
        raise ValueError(f"split_parts must contain 2 or 3 values, got {split_parts!r}")
    if any(part < 0 for part in split_parts):
        raise ValueError(f"split_parts must be non-negative, got {split_parts!r}")
    if all(part == 0 for part in split_parts):
        raise ValueError(f"split_parts cannot be all zeros, got {split_parts!r}")

    positive_count = sum(1 for part in split_parts if part > 0)
    if total < positive_count:
        raise ValueError(
            f"Unable to split {total} items with split_ratio={split_parts!r}; each non-zero part needs at least 1 item"
        )

    ratio_sum = sum(split_parts)
    exact_counts = [total * part / ratio_sum if part > 0 else 0.0 for part in split_parts]
    counts = [int(math.floor(value)) if part > 0 else 0 for value, part in zip(exact_counts, split_parts)]

    for index, part in enumerate(split_parts):
        if part > 0 and counts[index] == 0:
            counts[index] = 1

    def _fractional(index: int) -> float:
        return exact_counts[index] - math.floor(exact_counts[index])

    current_total = sum(counts)
    if current_total < total:
        remaining = total - current_total
        order = sorted(
            [index for index, part in enumerate(split_parts) if part > 0],
            key=lambda index: (-_fractional(index), index),
        )
        while remaining > 0:
            for index in order:
                if remaining <= 0:
                    break
                counts[index] += 1
                remaining -= 1
    elif current_total > total:
        excess = current_total - total
        order = sorted(
            [index for index, part in enumerate(split_parts) if part > 0 and counts[index] > 1],
            key=lambda index: (_fractional(index), -counts[index], index),
        )
        if not order:
            raise ValueError(
                f"Unable to reduce split counts to total={total} for split_ratio={split_parts!r}"
            )
        while excess > 0:
            reduced = False
            for index in order:
                if excess <= 0:
                    break
                if counts[index] > 1:
                    counts[index] -= 1
                    excess -= 1
                    reduced = True
            if not reduced:
                raise ValueError(
                    f"Unable to reduce split counts to total={total} for split_ratio={split_parts!r}"
                )

    if sum(counts) != total:
        raise ValueError(
            f"Internal split allocation failed for total={total} and split_ratio={split_parts!r}: {counts}"
        )

    if counts[0] <= 0 or counts[-1] <= 0:
        raise ValueError(
            f"split_ratio={split_parts!r} assigns no items to train or test for total={total}; "
            "train and test must both be non-empty"
        )

    return tuple(counts)


def split_single_day_dataset(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    test_size: float,
) -> tuple[ArrayPair, ArrayPair]:
    stratify = get_stratify_labels(y, test_size)
    train_x, test_x, train_y, test_y = train_test_split(
        x,
        y,
        test_size=test_size,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )
    return (train_x, train_y), (test_x, test_y)


def split_train_val_dataset(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    val_ratio: float,
) -> tuple[ArrayPair, ArrayPair]:
    stratify = get_stratify_labels(y, val_ratio)
    train_x, val_x, train_y, val_y = train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )
    return (train_x, train_y), (val_x, val_y)


def split_train_val_speech_dataset(
    x: np.ndarray,
    y: np.ndarray,
    x_len: np.ndarray,
    y_len: np.ndarray,
    day_idx: np.ndarray,
    seed: int,
    val_ratio: float,
) -> tuple[SpeechArrayTuple, SpeechArrayTuple]:
    indices = np.arange(x.shape[0])
    train_idx, val_idx = train_test_split(
        indices,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
    )
    train_tuple: SpeechArrayTuple = (
        np.asarray(x[train_idx]),
        np.asarray(y[train_idx]),
        np.asarray(x_len[train_idx]),
        np.asarray(y_len[train_idx]),
        np.asarray(day_idx[train_idx]),
    )
    val_tuple: SpeechArrayTuple = (
        np.asarray(x[val_idx]),
        np.asarray(y[val_idx]),
        np.asarray(x_len[val_idx]),
        np.asarray(y_len[val_idx]),
        np.asarray(day_idx[val_idx]),
    )
    return train_tuple, val_tuple


def align_feature_shapes(train_x: np.ndarray, test_x: np.ndarray) -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    if train_x.ndim != 3 or test_x.ndim != 3:
        raise ValueError(f"Expected 3D features, got train {train_x.shape} and test {test_x.shape}")

    target_time = min(train_x.shape[1], test_x.shape[1])
    target_channels = min(train_x.shape[2], test_x.shape[2])
    if target_time <= 0 or target_channels <= 0:
        raise ValueError(f"Unable to align train {train_x.shape} and test {test_x.shape}")

    aligned_train = np.asarray(train_x[:, :target_time, :target_channels])
    aligned_test = np.asarray(test_x[:, :target_time, :target_channels])
    return aligned_train, aligned_test, (target_time, target_channels)


def align_feature_triplet(
    train_x: np.ndarray,
    val_x: np.ndarray,
    test_x: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, tuple[int, int]]:
    if train_x.ndim != 3 or val_x.ndim != 3 or test_x.ndim != 3:
        raise ValueError(
            f"Expected 3D features, got train {train_x.shape}, val {val_x.shape}, test {test_x.shape}"
        )

    target_time = min(train_x.shape[1], val_x.shape[1], test_x.shape[1])
    target_channels = min(train_x.shape[2], val_x.shape[2], test_x.shape[2])
    if target_time <= 0 or target_channels <= 0:
        raise ValueError(
            f"Unable to align train {train_x.shape}, val {val_x.shape}, test {test_x.shape}"
        )

    return (
        np.asarray(train_x[:, :target_time, :target_channels]),
        np.asarray(val_x[:, :target_time, :target_channels]),
        np.asarray(test_x[:, :target_time, :target_channels]),
        (target_time, target_channels),
    )


def align_and_stack_feature_blocks(feature_blocks: list[np.ndarray]) -> tuple[np.ndarray, tuple[int, int]]:
    if not feature_blocks:
        raise ValueError("No feature blocks provided for stacking")
    if any(block.ndim != 3 for block in feature_blocks):
        shapes = [tuple(block.shape) for block in feature_blocks]
        raise ValueError(f"Expected all feature blocks to be 3D, got shapes: {shapes}")

    target_time = min(block.shape[1] for block in feature_blocks)
    target_channels = min(block.shape[2] for block in feature_blocks)
    if target_time <= 0 or target_channels <= 0:
        shapes = [tuple(block.shape) for block in feature_blocks]
        raise ValueError(f"Unable to align feature blocks: {shapes}")

    aligned_blocks = [np.asarray(block[:, :target_time, :target_channels]) for block in feature_blocks]
    return np.concatenate(aligned_blocks, axis=0), (target_time, target_channels)


def load_day_level_classification_npz(
    npz_path: DayRef,
    *,
    task: str | None = DEFAULT_TASK,
) -> tuple[np.ndarray, np.ndarray, str]:
    if is_virtual_day_ref(npz_path):
        return load_visual_grating_virtual_day(npz_path, task=task)

    if is_pre_split_single_day_npz(npz_path):
        train_x, train_y, test_x, test_y, train_label_key, test_label_key = load_pre_split_classification_npz(npz_path)
        x = np.concatenate([train_x, test_x], axis=0)
        y = np.concatenate([train_y, test_y], axis=0)
        return x, y, f"{train_label_key}|{test_label_key}"

    return load_task_npz(npz_path, task=task)


def load_cross_day_datasets(
    train_paths: list[DayRef],
    val_paths: list[DayRef],
    test_paths: list[DayRef],
    *,
    task: str | None = DEFAULT_TASK,
) -> tuple[
    ArrayPair,
    ArrayPair,
    ArrayPair,
    list[ArrayPair],
    str,
    str,
    str,
    tuple[int, int],
]:
    if not train_paths or not val_paths or not test_paths:
        raise ValueError("Cross-day split requires non-empty train/val/test day lists")

    train_x_blocks: list[np.ndarray] = []
    train_y_blocks: list[np.ndarray] = []
    val_x_blocks: list[np.ndarray] = []
    val_y_blocks: list[np.ndarray] = []
    test_x_blocks: list[np.ndarray] = []
    test_y_blocks: list[np.ndarray] = []
    train_label_keys: list[str] = []
    val_label_keys: list[str] = []
    test_label_keys: list[str] = []

    for path in train_paths:
        x, y, label_key = load_day_level_classification_npz(path, task=task)
        train_x_blocks.append(x)
        train_y_blocks.append(y)
        train_label_keys.append(label_key)

    for path in val_paths:
        x, y, label_key = load_day_level_classification_npz(path, task=task)
        val_x_blocks.append(x)
        val_y_blocks.append(y)
        val_label_keys.append(label_key)

    for path in test_paths:
        x, y, label_key = load_day_level_classification_npz(path, task=task)
        test_x_blocks.append(x)
        test_y_blocks.append(y)
        test_label_keys.append(label_key)

    all_blocks = train_x_blocks + val_x_blocks + test_x_blocks
    target_time = min(block.shape[1] for block in all_blocks)
    target_channels = min(block.shape[2] for block in all_blocks)

    aligned_train_x, _ = align_and_stack_feature_blocks(
        [block[:, :target_time, :target_channels] for block in train_x_blocks]
    )
    aligned_val_x, _ = align_and_stack_feature_blocks(
        [block[:, :target_time, :target_channels] for block in val_x_blocks]
    )
    aligned_test_x, _ = align_and_stack_feature_blocks(
        [block[:, :target_time, :target_channels] for block in test_x_blocks]
    )

    aligned_test_day_datasets = [
        (np.asarray(block[:, :target_time, :target_channels]), np.asarray(y_block))
        for block, y_block in zip(test_x_blocks, test_y_blocks)
    ]

    train_y = np.concatenate(train_y_blocks, axis=0)
    val_y = np.concatenate(val_y_blocks, axis=0)
    test_y = np.concatenate(test_y_blocks, axis=0)

    train_label_key = "|".join(sorted(set(train_label_keys)))
    val_label_key = "|".join(sorted(set(val_label_keys)))
    test_label_key = "|".join(sorted(set(test_label_keys)))

    return (
        (aligned_train_x, train_y),
        (aligned_val_x, val_y),
        (aligned_test_x, test_y),
        aligned_test_day_datasets,
        train_label_key,
        val_label_key,
        test_label_key,
        (target_time, target_channels),
    )
