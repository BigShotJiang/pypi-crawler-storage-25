from __future__ import annotations

# Internal-only capability declaration for load_data logic tracking.
# This is not a user-facing dataset declaration.
LOAD_DATA_CAPABILITY_DECLARATION: dict[str, object] = {
    "schema_version": "internal.v1",
    "supported_protocols": ["single_day", "cross_day", "train-test", "train-val-test"],
    "supported_tasks": ["classification", "regression", "speech"],
    "protocol_notes": {
        "single_day": {
            "purpose": "Single-session/day decoding path.",
            "file_patterns": [
                "single file (raw or pre-split keys)",
                "train/test split files (train.npz/test.npz or *_train/*_test)",
            ],
            "use_cases": [
                "Standard within-day decoding baseline",
                "Compatibility entry for declared train-test/train-val-test datasets",
            ],
        },
        "cross_day": {
            "purpose": "Cross-session/day generalization path.",
            "file_patterns": [
                "multiple day/session npz files",
                "virtual sessions for VisualGratingTask",
            ],
            "use_cases": [
                "Train/val/test split by day blocks",
                "Evaluate cross-day transfer performance",
            ],
        },
        "train-test": {
            "purpose": "Explicit train/test split protocol (single-day-like execution).",
            "file_patterns": ["*_train + *_test (or train.npz + test.npz)"],
            "use_cases": [
                "Datasets that provide train/test files only",
                "Allows optional internal val split from train via split_ratio",
            ],
        },
        "train-val-test": {
            "purpose": "Explicit train/val/test split protocol (single-day-like execution).",
            "file_patterns": ["*_train + *_val + *_test (or train.npz/val.npz/test.npz)"],
            "use_cases": [
                "Datasets with fixed external validation split",
                "Disallows internal val split unless split_ratio is compatible",
            ],
        },
    },
    "task_notes": {
        "classification": {
            "target_keys": ["classification_label"],
            "behavior": "Find classification_label and require shape (N,).",
        },
        "regression": {
            "target_keys": ["regression_target"],
            "behavior": "Find regression_target and require shape (N,T,2), aligned with neural_activity (N,T,C).",
        },
        "speech": {
            "target_keys": ["speech_label"],
            "behavior": "Find speech_label together with X_len/y_len/dayIdx and return speech datasets as (X, y, X_len, y_len, dayIdx).",
        },
    },
    "task_handling": {
        "validated_against_dataset_declaration": True,
        "controls_data_loading_branch": True,
    },
    "format_constraints": {
        "split_files": {
            "supported_protocols": ["single_day", "train-test", "train-val-test"],
        }
    },
    "protocol_compatibility": {
        "single_day_is_compatible_with_declared": ["train-test", "train-val-test"],
        "train-test_and_train-val-test_are_mutually_incompatible": True,
    },
}
