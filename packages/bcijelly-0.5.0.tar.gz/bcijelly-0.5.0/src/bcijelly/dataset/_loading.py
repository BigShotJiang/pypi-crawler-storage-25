from __future__ import annotations

from pathlib import Path
import warnings

import numpy as np

# Internal capability declaration source:
# src/bcijelly/dataset/_load_data_capability.py
from ._load_data_capability import LOAD_DATA_CAPABILITY_DECLARATION
from ._discovery import (
    _print_dataset_summary,
    _print_job_summary,
    _resolve_subject_structure,
    _validate_dataset_compatibility,
    build_jobs,
    discover_dataset_structure,
    get_declared_protocols,
)
from ._io import (
    allocate_split_counts,
    align_and_stack_feature_blocks,
    align_feature_shapes,
    align_feature_triplet,
    is_pre_split_single_day_npz,
    load_cross_day_datasets,
    load_pre_split_classification_npz,
    load_train_test_file_pair,
    load_train_val_test_file_triplet,
    load_day_level_classification_npz,
    parse_split_ratio,
    split_single_day_dataset,
    split_train_val_dataset,
    split_train_val_speech_dataset,
)
from ._types import (
    DATASET_FORMAT_DAY_FILES,
    DATASET_FORMAT_SINGLE_FILE,
    DATASET_FORMAT_SPLIT_FILES,
    DATASET_FORMAT_VIRTUAL_SESSIONS,
    DEFAULT_TASK,
    DEFAULT_HF_REPO_ID,
    DEFAULT_HF_REPO_TYPE,
    DataLoadResult,
    DatasetJob,
    ensure_dataset_available,
)


def _split_counts_for_ratio(total: int, split_parts: tuple[int, ...]) -> tuple[int, ...]:
    return allocate_split_counts(total, split_parts)


def _load_single_day_from_single_file(
    file_path: Path,
    *,
    task: str,
    seed: int | None,
    split_parts: tuple[int, ...],
) -> DataLoadResult:
    if is_pre_split_single_day_npz(file_path):
        train_x, train_y, test_x, test_y, train_label_key, test_label_key = load_pre_split_classification_npz(file_path)
        if len(split_parts) == 3:
            (_, val_count) = _split_counts_for_ratio(train_x.shape[0], split_parts[:2])
            if val_count > 0:
                (train_x, train_y), (val_x, val_y) = split_train_val_dataset(
                    train_x,
                    train_y,
                    seed=0 if seed is None else seed,
                    val_ratio=val_count,
                )
                train_x, val_x, test_x, aligned_shape = align_feature_triplet(train_x, val_x, test_x)
                return DataLoadResult(
                    train_dataset=(train_x, train_y),
                    val_dataset=(val_x, val_y),
                    test_dataset=(test_x, test_y),
                    test_day_datasets=None,
                    train_label_key=train_label_key,
                    val_label_key=train_label_key,
                    test_label_key=test_label_key,
                    aligned_shape=aligned_shape,
                )

        train_x, test_x, aligned_shape = align_feature_shapes(train_x, test_x)
        return DataLoadResult(
            train_dataset=(train_x, train_y),
            val_dataset=None,
            test_dataset=(test_x, test_y),
            test_day_datasets=None,
            train_label_key=train_label_key,
            val_label_key="",
            test_label_key=test_label_key,
            aligned_shape=aligned_shape,
        )

    if seed is None:
        raise ValueError(
            "For raw single-day datasets, `seed` is required so train/test split can be reproduced."
        )

    x, y, label_key = load_day_level_classification_npz(file_path, task=task)
    split_counts = _split_counts_for_ratio(len(x), split_parts)
    if len(split_counts) == 2:
        _, test_count = split_counts
        (train_x, train_y), (test_x, test_y) = split_single_day_dataset(
            x,
            y,
            seed=seed,
            test_size=test_count,
        )
    else:
        train_count, val_count, test_count = split_counts
        (train_x, train_y), (test_x, test_y) = split_single_day_dataset(
            x,
            y,
            seed=seed,
            test_size=test_count,
        )
        if val_count > 0:
            (train_x, train_y), (val_x, val_y) = split_train_val_dataset(
                train_x,
                train_y,
                seed=seed,
                val_ratio=val_count,
            )
            train_x, val_x, test_x, aligned_shape = align_feature_triplet(train_x, val_x, test_x)
            return DataLoadResult(
                train_dataset=(train_x, train_y),
                val_dataset=(val_x, val_y),
                test_dataset=(test_x, test_y),
                test_day_datasets=None,
                train_label_key=label_key,
                val_label_key=label_key,
                test_label_key=label_key,
                aligned_shape=aligned_shape,
            )

    train_x, test_x, aligned_shape = align_feature_shapes(train_x, test_x)
    return DataLoadResult(
        train_dataset=(train_x, train_y),
        val_dataset=None,
        test_dataset=(test_x, test_y),
        test_day_datasets=None,
        train_label_key=label_key,
        val_label_key="",
        test_label_key=label_key,
        aligned_shape=aligned_shape,
    )


def _load_single_day_from_split_pair(
    train_path: Path,
    test_path: Path,
    val_path: Path | None,
    *,
    task: str,
    seed: int | None,
    split_parts: tuple[int, ...],
    allow_internal_val_split: bool,
) -> DataLoadResult:
    if task == "speech":
        if val_path is not None:
            if len(split_parts) != 3:
                raise ValueError("This dataset provides an explicit validation split; split_ratio must have 3 parts.")
            (
                train_x,
                train_y,
                train_x_len,
                train_y_len,
                train_day_idx,
                val_x,
                val_y,
                val_x_len,
                val_y_len,
                val_day_idx,
                test_x,
                test_y,
                test_x_len,
                test_y_len,
                test_day_idx,
                train_label_key,
                val_label_key,
                test_label_key,
            ) = load_train_val_test_file_triplet(train_path, val_path, test_path, task=task)
            return DataLoadResult(
                train_dataset=(train_x, train_y, train_x_len, train_y_len, train_day_idx),
                val_dataset=(val_x, val_y, val_x_len, val_y_len, val_day_idx),
                test_dataset=(test_x, test_y, test_x_len, test_y_len, test_day_idx),
                test_day_datasets=None,
                train_label_key=train_label_key,
                val_label_key=val_label_key,
                test_label_key=test_label_key,
                aligned_shape=(int(train_x.shape[1]), int(train_x.shape[2])),
            )

        if len(split_parts) == 3 and not allow_internal_val_split:
            raise ValueError(
                "Current protocol/declaration does not allow internally splitting validation data. "
                "Please use a dataset with explicit val split or switch to a 2-part split_ratio."
            )

        (
            train_x,
            train_y,
            train_x_len,
            train_y_len,
            train_day_idx,
            test_x,
            test_y,
            test_x_len,
            test_y_len,
            test_day_idx,
            train_label_key,
            test_label_key,
        ) = load_train_test_file_pair(train_path, test_path, task=task)

        if len(split_parts) == 3:
            warnings.warn(
                "split_ratio has 3 parts under train-test split-files mode; explicit test data cannot be repartitioned. "
                "Using the first two parts to split train into train/val.",
                stacklevel=2,
            )
            _, val_count = _split_counts_for_ratio(train_x.shape[0], split_parts[:2])
            if val_count > 0:
                train_tuple, val_tuple = split_train_val_speech_dataset(
                    train_x,
                    train_y,
                    train_x_len,
                    train_y_len,
                    train_day_idx,
                    seed=0 if seed is None else seed,
                    val_ratio=val_count,
                )
                train_x, train_y, train_x_len, train_y_len, train_day_idx = train_tuple
                val_x, val_y, val_x_len, val_y_len, val_day_idx = val_tuple
                return DataLoadResult(
                    train_dataset=(train_x, train_y, train_x_len, train_y_len, train_day_idx),
                    val_dataset=(val_x, val_y, val_x_len, val_y_len, val_day_idx),
                    test_dataset=(test_x, test_y, test_x_len, test_y_len, test_day_idx),
                    test_day_datasets=None,
                    train_label_key=train_label_key,
                    val_label_key=train_label_key,
                    test_label_key=test_label_key,
                    aligned_shape=(int(train_x.shape[1]), int(train_x.shape[2])),
                )

        return DataLoadResult(
            train_dataset=(train_x, train_y, train_x_len, train_y_len, train_day_idx),
            val_dataset=None,
            test_dataset=(test_x, test_y, test_x_len, test_y_len, test_day_idx),
            test_day_datasets=None,
            train_label_key=train_label_key,
            val_label_key="",
            test_label_key=test_label_key,
            aligned_shape=(int(train_x.shape[1]), int(train_x.shape[2])),
        )

    if val_path is not None:
        if len(split_parts) != 3:
            raise ValueError("This dataset provides an explicit validation split; split_ratio must have 3 parts.")

        (
            train_x,
            train_y,
            val_x,
            val_y,
            test_x,
            test_y,
            train_label_key,
            val_label_key,
            test_label_key,
        ) = load_train_val_test_file_triplet(train_path, val_path, test_path, task=task)
        train_x, val_x, test_x, aligned_shape = align_feature_triplet(train_x, val_x, test_x)
        return DataLoadResult(
            train_dataset=(train_x, train_y),
            val_dataset=(val_x, val_y),
            test_dataset=(test_x, test_y),
            test_day_datasets=None,
            train_label_key=train_label_key,
            val_label_key=val_label_key,
            test_label_key=test_label_key,
            aligned_shape=aligned_shape,
        )

    if len(split_parts) == 3 and not allow_internal_val_split:
        raise ValueError(
            "Current protocol/declaration does not allow internally splitting validation data. "
            "Please use a dataset with explicit val split or switch to a 2-part split_ratio."
        )

    train_x, train_y, test_x, test_y, train_label_key, test_label_key = load_train_test_file_pair(
        train_path,
        test_path,
        task=task,
    )
    if len(split_parts) == 3:
        _, val_count = _split_counts_for_ratio(train_x.shape[0], split_parts[:2])
        if val_count > 0:
            (train_x, train_y), (val_x, val_y) = split_train_val_dataset(
                train_x,
                train_y,
                seed=0 if seed is None else seed,
                val_ratio=val_count,
            )
            train_x, val_x, test_x, aligned_shape = align_feature_triplet(train_x, val_x, test_x)
            return DataLoadResult(
                train_dataset=(train_x, train_y),
                val_dataset=(val_x, val_y),
                test_dataset=(test_x, test_y),
                test_day_datasets=None,
                train_label_key=train_label_key,
                val_label_key=train_label_key,
                test_label_key=test_label_key,
                aligned_shape=aligned_shape,
            )

    train_x, test_x, aligned_shape = align_feature_shapes(train_x, test_x)
    return DataLoadResult(
        train_dataset=(train_x, train_y),
        val_dataset=None,
        test_dataset=(test_x, test_y),
        test_day_datasets=None,
        train_label_key=train_label_key,
        val_label_key="",
        test_label_key=test_label_key,
        aligned_shape=aligned_shape,
    )


def load_job_data(
    job: DatasetJob,
    *,
    task: str = DEFAULT_TASK,
    seed: int | None = None,
    split_ratio: str = "7:1:2",
    data_dir: Path | None = None,
    auto_download_missing: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
    verbose: bool = False,
) -> DataLoadResult:
    split_parts = parse_split_ratio(split_ratio)
    if task == "speech" and job.protocol == "cross_day":
        raise ValueError("Speech task is not yet supported for protocol='cross_day'.")
    ensure_dataset_available(
        job.dataset,
        data_dir=data_dir,
        auto_download=auto_download_missing,
        repo_id=repo_id,
        repo_type=repo_type,
    )

    if job.protocol == "cross_day":
        if not job.train_paths or not job.test_paths:
            raise ValueError("Cross-day job must provide train_paths and test_paths")

        if job.val_paths:
            (
                train_dataset,
                val_dataset,
                test_dataset,
                test_day_datasets,
                train_label_key,
                val_label_key,
                test_label_key,
                aligned_shape,
            ) = load_cross_day_datasets(
                train_paths=job.train_paths,
                val_paths=job.val_paths,
                test_paths=job.test_paths,
                task=task,
            )
        else:
            train_x_blocks: list[np.ndarray] = []
            train_y_blocks: list[np.ndarray] = []
            test_x_blocks: list[np.ndarray] = []
            test_y_blocks: list[np.ndarray] = []
            train_label_keys: list[str] = []
            test_label_keys: list[str] = []

            for path in job.train_paths:
                x, y, label_key = load_day_level_classification_npz(path, task=task)
                train_x_blocks.append(x)
                train_y_blocks.append(y)
                train_label_keys.append(label_key)

            for path in job.test_paths:
                x, y, label_key = load_day_level_classification_npz(path, task=task)
                test_x_blocks.append(x)
                test_y_blocks.append(y)
                test_label_keys.append(label_key)

            all_blocks = train_x_blocks + test_x_blocks
            target_time = min(block.shape[1] for block in all_blocks)
            target_channels = min(block.shape[2] for block in all_blocks)

            aligned_train_x, _ = align_and_stack_feature_blocks(
                [block[:, :target_time, :target_channels] for block in train_x_blocks]
            )
            aligned_test_x, _ = align_and_stack_feature_blocks(
                [block[:, :target_time, :target_channels] for block in test_x_blocks]
            )

            aligned_test_day_datasets = [
                (np.asarray(block[:, :target_time, :target_channels]), np.asarray(y_block))
                for block, y_block in zip(test_x_blocks, test_y_blocks)
            ]

            train_dataset = (aligned_train_x, np.concatenate(train_y_blocks, axis=0))
            val_dataset = None
            test_dataset = (aligned_test_x, np.concatenate(test_y_blocks, axis=0))
            test_day_datasets = aligned_test_day_datasets
            train_label_key = "|".join(sorted(set(train_label_keys)))
            val_label_key = ""
            test_label_key = "|".join(sorted(set(test_label_keys)))
            aligned_shape = (target_time, target_channels)

        result = DataLoadResult(
            train_dataset=train_dataset,
            val_dataset=val_dataset,
            test_dataset=test_dataset,
            test_day_datasets=test_day_datasets,
            train_label_key=train_label_key,
            val_label_key=val_label_key,
            test_label_key=test_label_key,
            aligned_shape=aligned_shape,
            job=job,
        )
        _print_job_summary(job, result, verbose=verbose)
        return result

    if job.protocol != "single_day":
        raise ValueError(f"Unsupported protocol: {job.protocol}")

    if job.train_path is None:
        raise ValueError("Single-day job must provide train_path")

    if job.dataset_format == DATASET_FORMAT_SPLIT_FILES:
        if not isinstance(job.train_path, Path) or not isinstance(job.test_path, Path):
            raise TypeError("Split-file single-day job must provide Path train_path and test_path.")
        result = _load_single_day_from_split_pair(
            job.train_path,
            job.test_path,
            None,
            task=task,
            seed=seed,
            split_parts=split_parts,
            allow_internal_val_split=True,
        )
        result.job = job
        _print_job_summary(job, result, verbose=verbose)
        return result

    result = _load_single_day_from_single_file(
        Path(job.train_path) if isinstance(job.train_path, Path) else job.train_path,
        task=task,
        seed=seed,
        split_parts=split_parts,
    )
    result.job = job
    _print_job_summary(job, result, verbose=verbose)
    return result


def load_data(
    dataset_name: str,
    *,
    protocol: str = "single_day",
    task: str | None = None,
    seed: int | None = 42,
    split_ratio: str = "7:1:2",
    day_index: int = 0,
    subject_index: int = 0,
    fallback_to_first_subject: bool = False,
    verbose: bool = False,
    data_dir: Path | None = None,
    auto_download_missing: bool = True,
    repo_id: str = DEFAULT_HF_REPO_ID,
    repo_type: str = DEFAULT_HF_REPO_TYPE,
    max_days_per_dataset: int | None = None,
) -> DataLoadResult:
    protocol_alias_to_single_day = {"single_day", "train-test", "train-val-test"}
    supported_protocols = set(LOAD_DATA_CAPABILITY_DECLARATION["supported_protocols"])
    if protocol not in supported_protocols:
        raise ValueError(
            f"Unsupported protocol: {protocol}. "
            f"Supported protocols: {sorted(supported_protocols)}"
        )

    supported_tasks = set(LOAD_DATA_CAPABILITY_DECLARATION.get("supported_tasks", []))
    effective_task = task or DEFAULT_TASK
    if effective_task not in supported_tasks:
        raise ValueError(
            f"Unsupported task: {effective_task}. "
            f"Supported tasks: {sorted(supported_tasks)}"
        )

    split_parts = parse_split_ratio(split_ratio)

    root_structure = discover_dataset_structure(
        dataset_name,
        data_dir=data_dir,
        auto_download_missing=auto_download_missing,
        repo_id=repo_id,
        repo_type=repo_type,
    )

    _validate_dataset_compatibility(
        dataset_name=dataset_name,
        dataset_root=root_structure.dataset_root,
        protocol=protocol,
        task=effective_task,
    )

    declared_protocols = get_declared_protocols(root_structure.dataset_root)

    effective_protocol = protocol
    if protocol in protocol_alias_to_single_day:
        effective_protocol = "single_day"

    allow_internal_val_split = True
    require_explicit_val_split = False

    if protocol == "train-val-test":
        allow_internal_val_split = False
        require_explicit_val_split = True
    elif protocol == "train-test":
        allow_internal_val_split = True
    elif protocol == "single_day" and declared_protocols is not None:
        if "train-val-test" in declared_protocols:
            allow_internal_val_split = False
            require_explicit_val_split = True
        elif "train-test" in declared_protocols:
            allow_internal_val_split = True

    selected_structure, resolved_subject_index, resolved_subject_name = _resolve_subject_structure(
        root_structure,
        subject_index=subject_index,
        fallback_to_first_subject=fallback_to_first_subject,
    )

    _print_dataset_summary(
        root_structure,
        selected_subject_index=resolved_subject_index,
        selected_subject_name=resolved_subject_name,
        verbose=verbose,
    )

    if max_days_per_dataset is not None and selected_structure.storage_format in {
        DATASET_FORMAT_DAY_FILES,
        DATASET_FORMAT_SINGLE_FILE,
        DATASET_FORMAT_VIRTUAL_SESSIONS,
    }:
        files = list(selected_structure.files[:max_days_per_dataset])
    else:
        files = list(selected_structure.files)

    if require_explicit_val_split and selected_structure.storage_format != DATASET_FORMAT_SPLIT_FILES:
        raise ValueError(
            f"Dataset '{dataset_name}' requires explicit train/val/test files for protocol '{protocol}', "
            f"but detected storage format is '{selected_structure.storage_format}'."
        )

    if selected_structure.storage_format == DATASET_FORMAT_SPLIT_FILES:
        if effective_protocol != "single_day":
            raise ValueError(
                f"Dataset '{dataset_name}' uses separate train/test files and therefore only supports protocol='single_day'."
            )
        if day_index != 0:
            raise IndexError(
                f"Dataset '{dataset_name}' uses a fixed single-day split. day_index must be 0, got {day_index}."
            )

        if require_explicit_val_split and selected_structure.val_file is None:
            raise ValueError(
                f"Dataset '{dataset_name}' requires an explicit validation split (train-val-test), "
                "but no val file with *_val suffix (or val.npz) was found."
            )

        job = DatasetJob(
            protocol="single_day",
            dataset=dataset_name,
            train_path=selected_structure.train_file,
            test_path=selected_structure.test_file,
            train_day="train",
            test_day="test",
            dataset_format=DATASET_FORMAT_SPLIT_FILES,
            subject_name=resolved_subject_name,
            subject_index=resolved_subject_index,
            day_index=0,
        )
        result = _load_single_day_from_split_pair(
            selected_structure.train_file,
            selected_structure.test_file,
            selected_structure.val_file,
            task=effective_task,
            seed=seed,
            split_parts=split_parts,
            allow_internal_val_split=allow_internal_val_split,
        )
        result.job = job
        _print_job_summary(job, result, verbose=verbose)

        result.requested_task = effective_task
        return result

    jobs = build_jobs(
        dataset_name,
        files,
        protocols={effective_protocol},
        dataset_format=selected_structure.storage_format,
        subject_name=resolved_subject_name,
        subject_index=resolved_subject_index,
        split_parts=split_parts,
    )
    if not jobs:
        raise ValueError(f"No jobs could be built for dataset '{dataset_name}' with protocol '{protocol}'")

    chosen_index = day_index if effective_protocol == "single_day" else 0
    if chosen_index < 0 or chosen_index >= len(jobs):
        raise IndexError(
            f"day_index={chosen_index} is out of range for dataset '{dataset_name}' and protocol '{protocol}'. "
            f"Available job count: {len(jobs)}"
        )

    result = load_job_data(
        jobs[chosen_index],
        task=effective_task,
        seed=seed,
        split_ratio=split_ratio,
        data_dir=data_dir,
        auto_download_missing=auto_download_missing,
        repo_id=repo_id,
        repo_type=repo_type,
        verbose=verbose,
    )
    result.requested_task = effective_task
    return result
