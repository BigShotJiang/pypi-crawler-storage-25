"""
Plot utility for training CSV files.
"""

from __future__ import annotations

import argparse
import glob
import os

import matplotlib.pyplot as plt
import pandas as pd


def _find_single_csv(folder: str) -> str:
    csv_files = glob.glob(os.path.join(folder, "*.csv"))
    if len(csv_files) == 0:
        raise FileNotFoundError(f"No CSV file found in {folder}")
    if len(csv_files) > 1:
        preferred = [path for path in csv_files if os.path.basename(path) == "train_log.csv"]
        if len(preferred) == 1:
            return preferred[0]
        raise RuntimeError(f"More than one CSV file found in {folder}: {csv_files}")
    return csv_files[0]


def plot_training_csv(csv_path: str, task: str | None = None) -> str:
    df = pd.read_csv(csv_path)
    if "epoch" not in df.columns or "split" not in df.columns:
        raise ValueError("Unsupported CSV format for plotting.")

    fig, ax1 = plt.subplots(figsize=(9, 5))
    ax1.plot(df["epoch"], df["loss"], marker="o", label="loss")
    ax1.set_xlabel("epoch")
    ax1.set_ylabel("loss")

    ax2 = ax1.twinx()
    metric_name = "acc" if (task == "cls" or "acc" in df.columns) else ("mse" if "mse" in df.columns else None)
    if metric_name:
        ax2.plot(df["epoch"], df[metric_name], color="tab:orange", marker="x", label=metric_name)
        ax2.set_ylabel(metric_name)

    ax1.set_title(f"Training Curves - {os.path.basename(csv_path)}")
    fig.tight_layout()
    out_path = os.path.splitext(csv_path)[0] + "_curves.png"
    plt.savefig(out_path, dpi=300)
    print(f"Saved plot to {out_path}")
    return out_path


def main(folder: str | None = None, csv: str | None = None, task: str | None = None) -> str:
    if csv is None:
        if folder is None:
            raise ValueError("Provide --csv or --folder")
        csv = _find_single_csv(folder)
    return plot_training_csv(csv, task=task)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot training CSV")
    parser.add_argument("--folder", type=str, default=None, help="Folder that contains one CSV")
    parser.add_argument("--csv", type=str, default=None, help="Direct CSV path")
    parser.add_argument("--task", type=str, default=None, choices=["cls", "reg"], help="Optional task hint")
    args = parser.parse_args()
    main(folder=args.folder, csv=args.csv, task=args.task)
