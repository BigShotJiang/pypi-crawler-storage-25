"""
Classification interface for LSTM training/testing.
"""

from __future__ import annotations

import argparse
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        LSTMClassifier,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_classification,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        LSTMClassifier,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_classification,
    )


SUPPORTS_EXTERNAL_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "classification"
PRIMARY_TEST_METRIC = "acc"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_raw, y_raw = dataset
    x_arr = np.asarray(x_raw)
    y_arr = np.asarray(y_raw)
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        loaded = load_npz_dataset(datapath)
        x_arr, y_arr = _check_dataset_tuple_shape(loaded, dataset_name)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_classification(x_arr, y_arr)


def _encode_with_known_classes(y: np.ndarray, classes: list[Any]) -> np.ndarray:
    y_obj = np.asarray(y, dtype=object)
    class_to_id = {cls: index for index, cls in enumerate(classes)}
    encoded: list[int] = []
    for item in y_obj:
        label = item
        if isinstance(label, np.ndarray) and label.size == 1:
            label = label.reshape(-1)[0]
        if isinstance(label, (bytes, bytearray)):
            label = label.decode("utf-8", errors="ignore")
        if label not in class_to_id:
            raise ValueError(f"Label '{label}' not found in training label set: {classes}")
        encoded.append(class_to_id[label])
    return np.asarray(encoded, dtype=np.int64)


def _split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    val_ratio: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    stratify = y if len(np.unique(y)) > 1 else None
    return train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )


def _fit_zscore_stats(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = x.mean(axis=(0, 1), keepdims=True)
    std = x.std(axis=(0, 1), keepdims=True) + 1e-6
    return mean.astype(np.float32, copy=False), std.astype(np.float32, copy=False)


def _apply_zscore(x: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return ((x - mean) / std).astype(np.float32, copy=False)


def _is_better_checkpoint(
    current_acc: float,
    current_loss: float,
    best_acc: float,
    best_loss: float,
) -> bool:
    if current_acc > best_acc:
        return True
    if current_acc == best_acc and current_loss < best_loss:
        return True
    return False


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 6,
    lr: float = 1e-3,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    num_layers: int = 2,
    hidden_size: int = 64,
    dropout: float = 0.1,
    bidirectional: bool = True,
    pooling: str = "mean",
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 20,
    verbose: bool = False,
) -> dict[str, Any]:
    x_all, y_all = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath")

    train_x_raw, train_y_raw = x_all, y_all
    used_external_val = val_dataset is not None or bool(val_datapath)
    if used_external_val:
        val_x_raw, val_y_raw = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath")
    else:
        val_x_raw, val_y_raw = train_x_raw, train_y_raw

    train_y_encoded, label_to_id, classes = encode_labels(train_y_raw)
    val_y_encoded = _encode_with_known_classes(val_y_raw, classes)

    x_mean, x_std = _fit_zscore_stats(train_x_raw)
    train_x = _apply_zscore(train_x_raw, x_mean, x_std)
    val_x = _apply_zscore(val_x_raw, x_mean, x_std)

    set_seed(seed)
    dev = resolve_device(device)
    train_loader = make_dataloader(train_x, train_y_encoded, batch_size=batch_size, shuffle=True, task="cls")
    val_loader = make_dataloader(val_x, val_y_encoded, batch_size=batch_size, shuffle=False, task="cls")

    model = LSTMClassifier(
        input_dim=train_x.shape[2],
        output_dim=len(classes),
        hidden_size=hidden_size,
        num_layers=num_layers,
        dropout=dropout,
        bidirectional=bidirectional,
        pooling=pooling,
    ).to(dev)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "train_log.csv")
    ckpt_path = os.path.join(run_dir, "best_model.pt") if save_ckpt else None
    logger = CsvLogger(csv_path, task="cls")

    best_val_acc = -1.0
    best_val_loss = float("inf")
    best_epoch = -1
    best_state_dict = None
    try:
        for epoch in range(1, epochs + 1):
            train_one_epoch(model, train_loader, criterion, optimizer, dev)
            train_metrics = evaluate_classifier(model, train_loader, criterion, dev)
            val_metrics = evaluate_classifier(model, val_loader, criterion, dev)
            current_lr = optimizer.param_groups[0]["lr"]
            logger.log(epoch, "train", train_metrics, current_lr)
            logger.log(epoch, "val", val_metrics, current_lr)
            if _is_better_checkpoint(
                float(val_metrics["acc"]),
                float(val_metrics["loss"]),
                float(best_val_acc),
                float(best_val_loss),
            ):
                best_val_acc = float(val_metrics["acc"])
                best_val_loss = float(val_metrics["loss"])
                best_epoch = epoch
                best_state_dict = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                if ckpt_path:
                    torch.save(
                        {
                            "model_state_dict": best_state_dict,
                            "epoch": epoch,
                            "best_val_acc": best_val_acc,
                            "best_val_loss": best_val_loss,
                            "label_to_id": label_to_id,
                            "classes": classes,
                            "x_mean": x_mean,
                            "x_std": x_std,
                        },
                        ckpt_path,
                    )
            print(
                f"Epoch {epoch}/{epochs} | "
                f"train_loss={train_metrics['loss']:.4f} | train_acc={train_metrics['acc']:.4f} | "
                f"val_loss={val_metrics['loss']:.4f} | val_acc={val_metrics['acc']:.4f}"
            )
            if patience > 0 and epoch - best_epoch >= patience:
                break
    finally:
        logger.close()

    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)

    if plot:
        try:
            from .plot_csv import plot_training_csv
        except ImportError:
            from plot_csv import plot_training_csv

        plot_training_csv(csv_path, task="cls")

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "model": model,
            "device": dev,
            "criterion": criterion,
            "classes": classes,
            "label_to_id": label_to_id,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "x_mean": x_mean,
            "x_std": x_std,
            "batch_size": batch_size,
        }
    )

    used_internal_val_split = False
    has_validation = bool(used_external_val)

    train_result = {
        "task": "classification_train",
        "train_acc": float(train_metrics["acc"]),
        "train_loss": float(train_metrics["loss"]),
        "val_acc": float(best_val_acc),
        "val_loss": float(best_val_loss),
        "best_epoch": int(best_epoch),
        "num_classes": int(len(classes)),
        "classes": classes,
        "label_to_id": label_to_id,
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": bool(used_external_val),
        "used_internal_val_split": bool(used_internal_val_split),
        "has_validation": bool(has_validation),
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")

    x, y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    x = _apply_zscore(x, _TRAIN_STATE["x_mean"], _TRAIN_STATE["x_std"])
    encoded = _encode_with_known_classes(y, _TRAIN_STATE["classes"])
    batch_size = int(_TRAIN_STATE.get("batch_size", 32))
    test_loader = make_dataloader(x, encoded, batch_size=batch_size, shuffle=False, task="cls")
    metrics = evaluate_classifier(_TRAIN_STATE["model"], test_loader, _TRAIN_STATE["criterion"], _TRAIN_STATE["device"])
    print(f"Test Accuracy: {metrics['acc']:.4f}")
    test_result = {
        "task": "classification_test",
        "acc": float(metrics["acc"]),
        "loss": float(metrics["loss"]),
        "confusion_matrix": metrics["confusion_matrix"],
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LSTM classifier train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None, help="Path to training .npz file")
    parser.add_argument("--val_datapath", type=str, default=None, help="Optional path to validation .npz file")
    parser.add_argument("--test_datapath", type=str, default=None, help="Path to testing .npz file")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--hidden_size", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--bidirectional", action="store_true")
    parser.add_argument("--no_bidirectional", action="store_true")
    parser.add_argument("--pooling", type=str, default="mean", choices=["mean", "last"])
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=20)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    bidirectional = not args.no_bidirectional

    if args.train_datapath and not args.test_datapath:
        dataset = load_npz_dataset(args.train_datapath)
        x_all, y_all = _check_dataset_tuple_shape(dataset, "dataset")
        x_all, y_all = validate_dataset_classification(x_all, y_all)
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            stratify=y_all,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            hidden_size=args.hidden_size,
            dropout=args.dropout,
            bidirectional=bidirectional,
            pooling=args.pooling,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_dataset=(test_x, test_y))
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            hidden_size=args.hidden_size,
            dropout=args.dropout,
            bidirectional=bidirectional,
            pooling=args.pooling,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_datapath=args.test_datapath if args.test_datapath else args.train_datapath)

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
