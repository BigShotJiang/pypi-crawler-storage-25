"""
Regression interface for LSTM sequence-to-sequence training/testing.

Expected label shape:
  y: (N, T, D)
where D is the regression target dimension (for example 2 for x/y position,
velocity components, etc.).
"""

from __future__ import annotations

import argparse
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        LSTMRegressor,
        apply_regression_normalizer,
        ensure_output_dir,
        evaluate_regressor,
        fit_regression_normalizer,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_regression,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        LSTMRegressor,
        apply_regression_normalizer,
        ensure_output_dir,
        evaluate_regressor,
        fit_regression_normalizer,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_regression,
    )


SUPPORTS_EXTERNAL_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "regression"
PRIMARY_TEST_METRIC = "r2"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_raw, y_raw = dataset
    x_arr = np.asarray(x_raw)
    y_arr = np.asarray(y_raw)
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        loaded = load_npz_dataset(datapath)
        x_arr, y_arr = _check_dataset_tuple_shape(loaded, dataset_name)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_regression(x_arr, y_arr)


def _split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    val_ratio: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not 0.0 < float(val_ratio) < 1.0:
        raise ValueError(f"val_ratio must be in (0, 1), got {val_ratio}.")
    return train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
    )


def _is_better_checkpoint(
    current_r2: float,
    current_loss: float,
    best_r2: float,
    best_loss: float,
) -> bool:
    if current_r2 > best_r2:
        return True
    if current_r2 == best_r2 and current_loss < best_loss:
        return True
    return False


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 16,
    epochs: int = 15,
    lr: float = 1e-3,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    num_layers: int = 2,
    hidden_size: int = 128,
    dropout: float = 0.1,
    bidirectional: bool = True,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 20,
    verbose: bool = False,
) -> dict[str, Any]:
    x_all, y_all = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath")

    train_x_raw, train_y_raw = x_all, y_all
    used_external_val = val_dataset is not None or bool(val_datapath)
    if used_external_val:
        val_x_raw, val_y_raw = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath")
    else:
        val_x_raw, val_y_raw = train_x_raw, train_y_raw

    set_seed(seed)
    dev = resolve_device(device)

    norm_stats = fit_regression_normalizer(train_x_raw, train_y_raw)
    train_x, train_y = apply_regression_normalizer(train_x_raw, train_y_raw, norm_stats)
    val_x, val_y = apply_regression_normalizer(val_x_raw, val_y_raw, norm_stats)

    train_loader = make_dataloader(train_x, train_y, batch_size=batch_size, shuffle=True, task="reg")
    val_loader = make_dataloader(val_x, val_y, batch_size=batch_size, shuffle=False, task="reg")

    model = LSTMRegressor(
        input_dim=train_x.shape[2],
        output_dim=train_y.shape[2],
        hidden_size=hidden_size,
        num_layers=num_layers,
        dropout=dropout,
        bidirectional=bidirectional,
    ).to(dev)

    criterion = nn.SmoothL1Loss(beta=1.0)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "train_log.csv")
    ckpt_path = os.path.join(run_dir, "best_model.pt") if save_ckpt else None
    logger = CsvLogger(csv_path, task="reg")

    best_val_r2 = -1e9
    best_val_loss = float("inf")
    best_val_mse = float("inf")
    best_val_mae = float("inf")
    best_epoch = -1
    best_state_dict = None
    try:
        for epoch in range(1, epochs + 1):
            train_one_epoch(model, train_loader, criterion, optimizer, dev)
            train_metrics = evaluate_regressor(
                model,
                train_loader,
                criterion,
                dev,
                y_mean=norm_stats["y_mean"],
                y_std=norm_stats["y_std"],
            )
            val_metrics = evaluate_regressor(
                model,
                val_loader,
                criterion,
                dev,
                y_mean=norm_stats["y_mean"],
                y_std=norm_stats["y_std"],
            )
            current_lr = optimizer.param_groups[0]["lr"]
            logger.log(epoch, "train", train_metrics, current_lr)
            logger.log(epoch, "val", val_metrics, current_lr)

            if _is_better_checkpoint(
                float(val_metrics["r2"]),
                float(val_metrics["loss"]),
                float(best_val_r2),
                float(best_val_loss),
            ):
                best_val_r2 = float(val_metrics["r2"])
                best_val_loss = float(val_metrics["loss"])
                best_val_mse = float(val_metrics["mse"])
                best_val_mae = float(val_metrics["mae"])
                best_epoch = epoch
                best_state_dict = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                if ckpt_path:
                    torch.save(
                        {
                            "model_state_dict": best_state_dict,
                            "epoch": epoch,
                            "best_val_r2": best_val_r2,
                            "best_val_loss": best_val_loss,
                            "norm_stats": norm_stats,
                        },
                        ckpt_path,
                    )
            print(
                f"Epoch {epoch}/{epochs} | "
                f"train_loss={train_metrics['loss']:.4f} | train_mse={train_metrics['mse']:.4f} | "
                f"train_mae={train_metrics['mae']:.4f} | train_r2={train_metrics['r2']:.4f} | "
                f"val_loss={val_metrics['loss']:.4f} | val_mse={val_metrics['mse']:.4f} | "
                f"val_mae={val_metrics['mae']:.4f} | val_r2={val_metrics['r2']:.4f}"
            )
            if patience > 0 and epoch - best_epoch >= patience:
                break
    finally:
        logger.close()

    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)

    if plot:
        try:
            from .plot_csv import plot_training_csv
        except ImportError:
            from plot_csv import plot_training_csv

        plot_training_csv(csv_path, task="reg")

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "model": model,
            "device": dev,
            "criterion": criterion,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "batch_size": batch_size,
            "norm_stats": norm_stats,
        }
    )

    used_internal_val_split = False
    has_validation = bool(used_external_val)

    train_result = {
        "task": "regression_train",
        "train_r2": float(train_metrics["r2"]),
        "train_mse": float(train_metrics["mse"]),
        "train_mae": float(train_metrics["mae"]),
        "train_loss": float(train_metrics["loss"]),
        "val_r2": float(best_val_r2),
        "val_mse": float(best_val_mse),
        "val_mae": float(best_val_mae),
        "val_loss": float(best_val_loss),
        "best_epoch": int(best_epoch),
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": bool(used_external_val),
        "used_internal_val_split": bool(used_internal_val_split),
        "has_validation": bool(has_validation),
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")

    x, y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    stats = _TRAIN_STATE["norm_stats"]
    x_norm, y_norm = apply_regression_normalizer(x, y, stats)
    batch_size = int(_TRAIN_STATE.get("batch_size", 32))
    test_loader = make_dataloader(x_norm, y_norm, batch_size=batch_size, shuffle=False, task="reg")

    metrics = evaluate_regressor(
        _TRAIN_STATE["model"],
        test_loader,
        _TRAIN_STATE["criterion"],
        _TRAIN_STATE["device"],
        y_mean=stats["y_mean"],
        y_std=stats["y_std"],
    )
    print(
        f"Test Regression Metrics: "
        f"MSE={metrics['mse']:.4f}, MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}"
    )
    test_result = {
        "task": "regression_test",
        "mse": float(metrics["mse"]),
        "mae": float(metrics["mae"]),
        "r2": float(metrics["r2"]),
        "loss": float(metrics["loss"]),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LSTM regressor train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None, help="Path to training .npz file")
    parser.add_argument("--val_datapath", type=str, default=None, help="Optional path to validation .npz file")
    parser.add_argument("--test_datapath", type=str, default=None, help="Path to testing .npz file")
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--hidden_size", type=int, default=128)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--bidirectional", action="store_true")
    parser.add_argument("--no_bidirectional", action="store_true")
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=20)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    bidirectional = not args.no_bidirectional

    if args.train_datapath and not args.test_datapath:
        dataset = load_npz_dataset(args.train_datapath)
        x_all, y_all = _check_dataset_tuple_shape(dataset, "dataset")
        x_all, y_all = validate_dataset_regression(x_all, y_all)
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            hidden_size=args.hidden_size,
            dropout=args.dropout,
            bidirectional=bidirectional,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_dataset=(test_x, test_y))
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            hidden_size=args.hidden_size,
            dropout=args.dropout,
            bidirectional=bidirectional,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_datapath=args.test_datapath if args.test_datapath else args.train_datapath)

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
