"""
Shared utilities for LSTM-based classification/regression training.
"""

from __future__ import annotations

import csv
import os
import random
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, confusion_matrix, mean_absolute_error, mean_squared_error, r2_score
from torch.utils.data import DataLoader, Dataset


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(device: str = "auto") -> torch.device:
    if device == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Requested device='cuda' but CUDA is not available.")
    return torch.device(device)


def _ensure_3d_x(x: np.ndarray) -> np.ndarray:
    if not isinstance(x, np.ndarray):
        raise TypeError(f"X must be numpy.ndarray, got {type(x)}")
    if x.ndim != 3:
        raise ValueError(f"X must have shape (trials, times, channels), got {x.shape}")
    return x.astype(np.float32, copy=False)


def validate_dataset_classification(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = _ensure_3d_x(x)
    if not isinstance(y, np.ndarray):
        raise TypeError(f"y must be numpy.ndarray, got {type(y)}")
    if y.ndim == 2 and y.shape[1] == 1:
        y = y[:, 0]
    if y.ndim != 1:
        raise ValueError(f"Classification y must have shape (trials,), got {y.shape}")
    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x.shape[0]}, y has {y.shape[0]}")
    return x, y


def validate_dataset_regression(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = _ensure_3d_x(x)
    if not isinstance(y, np.ndarray):
        raise TypeError(f"y must be numpy.ndarray, got {type(y)}")
    if y.ndim != 3 or y.shape[2] != 2:
        raise ValueError(f"Regression y must have shape (trials, times, 2), got {y.shape}")
    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x.shape[0]}, y has {y.shape[0]}")
    if x.shape[1] != y.shape[1]:
        raise ValueError(f"Mismatched time steps: X has {x.shape[1]}, y has {y.shape[1]}")
    return x, y.astype(np.float32, copy=False)


def encode_labels(y: np.ndarray) -> tuple[np.ndarray, dict[Any, int], list[Any]]:
    y_obj = np.asarray(y, dtype=object)
    cleaned = []
    for value in y_obj:
        if isinstance(value, np.ndarray) and value.size == 1:
            value = value.reshape(-1)[0]
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8", errors="ignore")
        cleaned.append(value)
    classes, inv = np.unique(np.asarray(cleaned, dtype=object), return_inverse=True)
    mapping = {cls: i for i, cls in enumerate(classes.tolist())}
    return inv.astype(np.int64), mapping, classes.tolist()


def load_npz_dataset(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")

    data = np.load(npz_path, allow_pickle=False)
    files = list(data.files)
    x_candidates = ("X", "x", "features", "feature", "spike", "samples")
    y_candidates = ("y", "Y", "labels", "label", "targets", "target", "discrete_labels")
    x_key = next((key for key in x_candidates if key in files), None)
    y_key = next((key for key in y_candidates if key in files), None)

    if x_key is not None and y_key is not None:
        try:
            return np.asarray(data[x_key]), np.asarray(data[y_key])
        except ValueError:
            data_pickle = np.load(npz_path, allow_pickle=True)
            return np.asarray(data_pickle[x_key]), np.asarray(data_pickle[y_key])

    if len(files) == 2:
        try:
            return np.asarray(data[files[0]]), np.asarray(data[files[1]])
        except ValueError:
            data_pickle = np.load(npz_path, allow_pickle=True)
            return np.asarray(data_pickle[files[0]]), np.asarray(data_pickle[files[1]])

    raise KeyError(
        f"Unable to infer X/y from {npz_path}. Available keys: {files}. "
        "Expected keys like X/y or features/labels."
    )


class ArrayDataset(Dataset):
    def __init__(self, x: np.ndarray, y: np.ndarray, task: str) -> None:
        self.x = torch.tensor(x, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long if task == "cls" else torch.float32)

    def __len__(self) -> int:
        return self.x.size(0)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.x[idx], self.y[idx]


def make_dataloader(x: np.ndarray, y: np.ndarray, batch_size: int, shuffle: bool, task: str) -> DataLoader:
    return DataLoader(ArrayDataset(x, y, task=task), batch_size=batch_size, shuffle=shuffle)


class TimeDistributedLinear(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(in_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear = nn.Linear(in_dim, out_dim)

    def forward(self, seq: torch.Tensor) -> torch.Tensor:
        return self.linear(self.dropout(self.norm(seq)))


class LSTMClassifier(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_size: int = 64,
        num_layers: int = 2,
        dropout: float = 0.1,
        bidirectional: bool = True,
        pooling: str = "mean",
    ) -> None:
        super().__init__()
        self.pooling = pooling
        self.encoder = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )
        out_dim = hidden_size * (2 if bidirectional else 1)
        self.head = nn.Sequential(nn.LayerNorm(out_dim), nn.Dropout(dropout), nn.Linear(out_dim, output_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        encoded, _ = self.encoder(x)
        pooled = encoded[:, -1, :] if self.pooling == "last" else encoded.mean(dim=1)
        return self.head(pooled)


class LSTMRegressor(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int = 2,
        hidden_size: int = 64,
        num_layers: int = 2,
        dropout: float = 0.1,
        bidirectional: bool = True,
    ) -> None:
        super().__init__()
        self.encoder = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )
        out_dim = hidden_size * (2 if bidirectional else 1)
        self.head = TimeDistributedLinear(out_dim, output_dim, dropout=dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        encoded, _ = self.encoder(x)
        return self.head(encoded)


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> float:
    model.train()
    total_loss = 0.0
    n = 0
    for xb, yb in loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        loss = criterion(model(xb), yb)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item() * xb.size(0)
        n += xb.size(0)
    return total_loss / max(n, 1)


def evaluate_classifier(model: nn.Module, loader: DataLoader, criterion: nn.Module, device: torch.device) -> dict[str, Any]:
    model.eval()
    total_loss = 0.0
    n = 0
    y_true: list[int] = []
    y_pred: list[int] = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            logits = model(xb)
            total_loss += criterion(logits, yb).item() * xb.size(0)
            n += xb.size(0)
            y_true.extend(yb.cpu().numpy().tolist())
            y_pred.extend(logits.argmax(dim=1).cpu().numpy().tolist())
    acc = accuracy_score(y_true, y_pred) if y_true else 0.0
    if y_true:
        labels = sorted(set(y_true) | set(y_pred))
        cm = confusion_matrix(y_true, y_pred, labels=labels).tolist()
    else:
        cm = []
    return {"loss": total_loss / max(n, 1), "acc": float(acc), "confusion_matrix": cm}


def evaluate_regressor(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    y_mean: np.ndarray,
    y_std: np.ndarray,
) -> dict[str, float]:
    model.eval()
    total_loss = 0.0
    n = 0
    y_true: list[np.ndarray] = []
    y_pred: list[np.ndarray] = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            out = model(xb)
            total_loss += criterion(out, yb).item() * xb.size(0)
            n += xb.size(0)
            y_true.append(yb.cpu().numpy())
            y_pred.append(out.cpu().numpy())

    if not y_true:
        return {"loss": 0.0, "mse": 0.0, "mae": 0.0, "r2": 0.0}

    yt = np.concatenate(y_true, axis=0) * y_std + y_mean
    yp = np.concatenate(y_pred, axis=0) * y_std + y_mean
    yt2 = yt.reshape(-1, yt.shape[-1])
    yp2 = yp.reshape(-1, yp.shape[-1])
    return {
        "loss": total_loss / max(n, 1),
        "mse": float(mean_squared_error(yt2, yp2)),
        "mae": float(mean_absolute_error(yt2, yp2)),
        "r2": float(r2_score(yt2, yp2)),
    }


def fit_regression_normalizer(x: np.ndarray, y: np.ndarray) -> dict[str, np.ndarray]:
    return {
        "x_mean": x.mean(axis=(0, 1), keepdims=True),
        "x_std": x.std(axis=(0, 1), keepdims=True) + 1e-6,
        "y_mean": y.mean(axis=(0, 1), keepdims=True),
        "y_std": y.std(axis=(0, 1), keepdims=True) + 1e-6,
    }


def apply_regression_normalizer(x: np.ndarray, y: np.ndarray, stats: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    x_norm = (x - stats["x_mean"]) / stats["x_std"]
    y_norm = (y - stats["y_mean"]) / stats["y_std"]
    return x_norm.astype(np.float32, copy=False), y_norm.astype(np.float32, copy=False)


def ensure_output_dir(output_dir: str, run_name: str | None = None) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = run_name or f"run_{stamp}"
    run_dir = os.path.join(output_dir, run_name)
    os.makedirs(run_dir, exist_ok=True)
    return run_dir, run_name


@dataclass
class CsvLogger:
    path: str | None
    task: str
    file_obj: Any = None
    writer: Any = None

    def __post_init__(self) -> None:
        if not self.path:
            return
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file_obj)
        if self.task == "cls":
            self.writer.writerow(["epoch", "split", "loss", "acc", "lr"])
        else:
            self.writer.writerow(["epoch", "split", "loss", "mse", "mae", "r2", "lr"])

    def log(self, epoch: int, split: str, metrics: dict[str, Any], lr: float) -> None:
        if not self.writer:
            return
        if self.task == "cls":
            self.writer.writerow([epoch, split, metrics.get("loss"), metrics.get("acc"), lr])
        else:
            self.writer.writerow([epoch, split, metrics.get("loss"), metrics.get("mse"), metrics.get("mae"), metrics.get("r2"), lr])
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()



