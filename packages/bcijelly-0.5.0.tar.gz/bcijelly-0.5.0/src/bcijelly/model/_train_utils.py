from __future__ import annotations

import inspect
from typing import Any

import numpy as np

ArrayPair = tuple[np.ndarray, np.ndarray]


def merge_datasets(
    first: ArrayPair,
    second: ArrayPair | None,
) -> ArrayPair:
    if second is None:
        return first
    first_x, first_y = first
    second_x, second_y = second
    return (
        np.concatenate([first_x, second_x], axis=0),
        np.concatenate([first_y, second_y], axis=0),
    )


def supports_external_val(module: Any) -> bool:
    return bool(getattr(module, "SUPPORTS_EXTERNAL_VAL", False))


def auto_split_val_if_missing(module: Any) -> bool:
    return bool(getattr(module, "AUTO_SPLIT_VAL_IF_MISSING", False))


def primary_test_metric(module: Any) -> str:
    return str(getattr(module, "PRIMARY_TEST_METRIC", "acc"))


def task_type(module: Any) -> str:
    return str(getattr(module, "TASK_TYPE", "classification"))


def resolve_train_inputs(
    module: Any,
    train_dataset: ArrayPair,
    val_dataset: ArrayPair | None,
) -> tuple[ArrayPair, ArrayPair | None]:
    if val_dataset is None:
        return train_dataset, None

    if supports_external_val(module):
        return train_dataset, val_dataset

    return merge_datasets(train_dataset, val_dataset), None


def inject_train_val_kwargs(
    module: Any,
    train_kwargs: dict[str, Any],
    val_dataset: ArrayPair | None,
) -> dict[str, Any]:
    signature = inspect.signature(module.train)
    parameters = signature.parameters

    result = dict(train_kwargs)

    if "val_dataset" in parameters:
        if val_dataset is not None:
            result["val_dataset"] = val_dataset
        else:
            result.pop("val_dataset", None)
    else:
        result.pop("val_dataset", None)

    if "val_datapath" in parameters:
        result.pop("val_datapath", None)

    return result


def extract_test_metric(test_result: dict[str, Any], module: Any) -> float:
    metric_key = primary_test_metric(module)
    if metric_key not in test_result:
        raise KeyError(
            f"module.test() result does not contain expected metric '{metric_key}'. "
            f"Available keys: {sorted(test_result.keys())}"
        )
    return float(test_result[metric_key])
