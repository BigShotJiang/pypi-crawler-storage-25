#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stabilization_mlp.py

Python port of the MATLAB pipeline in run_mlp_stab_latent.m and the helper
MATLAB functions:

- fitBaseStabilizer.m
- updateStabilizer.m
- getStabilizatonMatrices.m
- alignLoadingMatrices.m
- identifyStableLoadingRows.m
- learnOptimalOrthonormalTransformation.m

This script performs an end-to-end loop over days:
1) Fit a "base stabilizer" (Factor Analysis) on the last BASELINE_NTRIALS
   training trials for that day.
2) Compute stabilized latents for the whole training set and train an MLP classifier.
3) For the test set of that day, use the first CALIB_NTRIALS trials to update
   the stabilizer (and align loadings to baseline), then evaluate on the
   remaining test trials.

It reproduces the MATLAB hyper-parameters as they appear in run_mlp_stab_latent.m.

Outputs:
- A results matrix [n_days x n_seeds] with accuracy per day.
- A plot of test accuracy vs day for each seed, with a dashed horizontal line
  showing the mean accuracy over test days.

Notes on numerical equivalence:
- MATLAB's fitFA.m is not included in the uploaded scripts. This port implements
  a standard EM algorithm for Gaussian Factor Analysis with diagonal private
  variances (psi). Random initialization is used when C_INIT/PSI_INIT are empty.
  This matches the intended algorithmic structure, but exact numeric equality
  with your MATLAB environment depends on the details of fitFA.m.

Author: ChatGPT (GPT-5.2 Thinking)
"""

from __future__ import annotations

import argparse
import dataclasses
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import numpy as np
import matplotlib.pyplot as plt

from scipy.io import loadmat, savemat
from numpy.linalg import slogdet

from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline


# ----------------------------- Utilities -----------------------------

def set_global_seed(seed: int) -> None:
    np.random.seed(seed)


def _as_1d(a: np.ndarray) -> np.ndarray:
    return np.asarray(a).reshape(-1)


# -------------------------- Factor Analysis --------------------------

@dataclasses.dataclass
class FAModel:
    """A Factor Analysis model matching the MATLAB struct fields."""
    d: np.ndarray            # mean vector, shape (D,)
    C: np.ndarray            # loading matrix, shape (D, K)
    psi: np.ndarray          # private variances (diag), shape (D,)
    diags: Dict[str, np.ndarray]  # diagnostics, includes 'll' array
    alignChs: Optional[np.ndarray] = None  # boolean mask, shape (D,)


def fit_fa(
    X: np.ndarray,
    n_latents: int,
    *,
    max_n_its: int = 100000,
    ll_diff_thresh: float = 1e-5,
    min_priv_var: float = 0.1,
    C_init: Optional[np.ndarray] = None,
    psi_init: Optional[np.ndarray] = None,
    verbose: bool = True,
    batch_size: int = 8192,
) -> FAModel:
    """
    EM for Gaussian Factor Analysis with diagonal Psi.

    X: (N, D) observations.
    Returns FAModel with fields d, C, psi, diags.ll (log-likelihood trace).
    """
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2:
        raise ValueError(f"X must be 2D (N,D). Got shape={X.shape}")

    N, D = X.shape
    d = X.mean(axis=0)
    Xc = X - d

    # Precompute Sxx for likelihood and Psi update (can be large but D is modest)
    Sxx = Xc.T @ Xc  # (D,D)
    diag_Sxx = np.diag(Sxx)

    K = int(n_latents)

    # Initialize parameters
    if C_init is None or (isinstance(C_init, np.ndarray) and C_init.size == 0):
        # Small random loadings
        C = 0.01 * np.random.randn(D, K)
    else:
        C = np.asarray(C_init, dtype=np.float64).copy()
        if C.shape != (D, K):
            raise ValueError(f"C_INIT shape mismatch. Expected {(D, K)} got {C.shape}")

    if psi_init is None or (isinstance(psi_init, np.ndarray) and psi_init.size == 0):
        # Initialize private variances from data variance
        psi = np.maximum(np.var(Xc, axis=0), min_priv_var)
    else:
        psi = _as_1d(np.asarray(psi_init, dtype=np.float64).copy())
        if psi.shape[0] != D:
            raise ValueError(f"PSI_INIT length mismatch. Expected {D} got {psi.shape[0]}")
        psi = np.maximum(psi, min_priv_var)

    ll_trace: List[float] = []
    last_ll = -np.inf

    # Helper to compute total log-likelihood using covariance form
    def compute_ll(C_: np.ndarray, psi_: np.ndarray) -> float:
        # Sigma = C C^T + diag(psi)
        Sigma = C_ @ C_.T + np.diag(psi_)
        sign, logdet = slogdet(Sigma)
        if sign <= 0:
            return -np.inf
        # trace(Sxx * Sigma^{-1}) can be computed via solve
        # Use Cholesky solve for stability
        try:
            L = np.linalg.cholesky(Sigma)
            # Solve Sigma^{-1} Sxx via two triangular solves
            tmp = np.linalg.solve(L, Sxx)
            Sigma_inv_Sxx = np.linalg.solve(L.T, tmp)
            tr_term = np.trace(Sigma_inv_Sxx)
        except np.linalg.LinAlgError:
            # Fallback to inv (less stable)
            Sigma_inv = np.linalg.pinv(Sigma)
            tr_term = np.trace(Sxx @ Sigma_inv)

        ll = -0.5 * (
            N * (D * np.log(2.0 * np.pi) + logdet) + tr_term
        )
        return float(ll)

    for it in range(1, max_n_its + 1):
        # E-step in batches: accumulate sufficient statistics
        inv_psi = 1.0 / psi
        # M = I + C^T Psi^{-1} C
        Ct_invPsi = (C.T * inv_psi)  # (K,D)
        M = np.eye(K) + Ct_invPsi @ C  # (K,K)
        try:
            M_inv = np.linalg.inv(M)
        except np.linalg.LinAlgError:
            M_inv = np.linalg.pinv(M)

        # Accumulators
        sum_xz = np.zeros((D, K), dtype=np.float64)
        sum_zz = np.zeros((K, K), dtype=np.float64)

        # Process Xc in mini-batches to reduce memory
        for start in range(0, N, batch_size):
            end = min(N, start + batch_size)
            Xb = Xc[start:end, :]  # (B,D)
            # Xb Psi^{-1} C  == (Xb * inv_psi) @ C
            Ez_b = (Xb * inv_psi) @ C @ M_inv  # (B,K)
            sum_xz += Xb.T @ Ez_b
            sum_zz += Ez_b.T @ Ez_b

        sum_zz += N * M_inv  # add sum of posterior covariances

        # M-step
        try:
            sum_zz_inv = np.linalg.inv(sum_zz)
        except np.linalg.LinAlgError:
            sum_zz_inv = np.linalg.pinv(sum_zz)

        C_new = sum_xz @ sum_zz_inv  # (D,K)

        # Psi update: diag( (Sxx - C_new sum_xz^T) / N )
        recon = C_new @ sum_xz.T  # (D,D)
        psi_new = (np.diag(Sxx - recon) / N).astype(np.float64)
        psi_new = np.maximum(psi_new, min_priv_var)

        C, psi = C_new, psi_new

        ll = compute_ll(C, psi)
        ll_trace.append(ll)

        if verbose and (it == 1 or it % 25 == 0):
            diff = ll - last_ll
            print(f"[FA] iter={it:6d} ll={ll: .6e}  dll={diff: .3e}")

        if np.isfinite(last_ll) and abs(ll - last_ll) < ll_diff_thresh:
            if verbose:
                print(f"[FA] Converged at iter={it} |dll|<{ll_diff_thresh}")
            break
        last_ll = ll

    return FAModel(d=d, C=C, psi=psi, diags={"ll": np.array(ll_trace, dtype=np.float64)})


def fit_base_stabilizer(
    Y_trials: np.ndarray,
    n_latents: int,
    *,
    n_fa_restarts: int = 5,
    max_n_its: int = 100000,
    ll_diff_thresh: float = 1e-5,
    min_priv_var: float = 0.1,
    C_init: Optional[np.ndarray] = None,
    psi_init: Optional[np.ndarray] = None,
    verbose: bool = True,
) -> FAModel:
    """
    MATLAB fitBaseStabilizer.m:
      - concatenate trials into a single observation matrix
      - fit FA multiple random restarts and pick best final LL
    """
    if Y_trials.ndim != 3:
        raise ValueError(f"Y_trials must be 3D [N,T,C]. Got {Y_trials.shape}")
    N, T, C = Y_trials.shape

    # Concatenate trials like MATLAB: yMat = [y{:}] with each trial [C x T]
    # => shape (C, N*T) then transpose for fitFA => (N*T, C)
    X = Y_trials.reshape(N * T, C).astype(np.float64)

    best: Optional[FAModel] = None
    best_ll = -np.inf

    for r in range(1, n_fa_restarts + 1):
        if verbose:
            print(f"[BaseFA] restart {r}/{n_fa_restarts}")
        fa = fit_fa(
            X,
            n_latents,
            max_n_its=max_n_its,
            ll_diff_thresh=ll_diff_thresh,
            min_priv_var=min_priv_var,
            C_init=C_init,
            psi_init=psi_init,
            verbose=verbose,
        )
        final_ll = float(fa.diags["ll"][-1]) if fa.diags["ll"].size else -np.inf
        if final_ll > best_ll:
            best_ll = final_ll
            best = fa

    assert best is not None
    return best


# ---------------------- Stabilization matrices ----------------------

def get_stabilization_matrices(fa: FAModel) -> Tuple[np.ndarray, np.ndarray]:
    """
    MATLAB getStabilizatonMatrices.m:
      beta = C'/(C*C' + psi)
      o = -beta*d
    Here psi is diagonal; we use diag(psi).
    """
    C = fa.C  # (D,K)
    D, K = C.shape
    Psi = np.diag(fa.psi)  # (D,D)
    Sigma = C @ C.T + Psi
    try:
        Sigma_inv = np.linalg.inv(Sigma)
    except np.linalg.LinAlgError:
        Sigma_inv = np.linalg.pinv(Sigma)
    beta = C.T @ Sigma_inv  # (K,D)
    o = -(beta @ fa.d.reshape(-1, 1))  # (K,1)
    return beta, o


# ---------------------- Loading alignment (Procrustes) ----------------------

def learn_optimal_orthonormal_transformation(m1: np.ndarray, m2: np.ndarray) -> np.ndarray:
    """
    MATLAB learnOptimalOrthonormalTransformation.m:
      S = m1'*m2; [U,~,V]=svd(S); T=U*V'
    """
    S = m1.T @ m2
    U, _, Vt = np.linalg.svd(S, full_matrices=False)
    T = U @ Vt
    return T


def identify_stable_loading_rows(
    m1: np.ndarray,
    m2: np.ndarray,
    n_stable_rows: int,
    th: float,
) -> np.ndarray:
    """
    MATLAB identifyStableLoadingRows.m:
    Returns boolean mask of rows used for alignment.
    """
    m1 = np.asarray(m1, dtype=np.float64)
    m2 = np.asarray(m2, dtype=np.float64)
    if m1.shape != m2.shape:
        raise ValueError(f"m1 and m2 must match shape. Got {m1.shape} vs {m2.shape}")

    m1_norms = np.sqrt((m1 ** 2).sum(axis=1))
    m2_norms = np.sqrt((m2 ** 2).sum(axis=1))
    small_rows = (m1_norms < th) | (m2_norms < th)

    clean_rows = np.where(~small_rows)[0]
    n_clean = clean_rows.size

    m1_clean = m1[clean_rows, :]
    m2_clean = m2[clean_rows, :]

    cur_rows = np.arange(n_clean)
    n_drop = max(n_clean - n_stable_rows, 0)

    for i in range(n_drop):
        cur_m1 = m1_clean[cur_rows, :]
        cur_m2 = m2_clean[cur_rows, :]

        W = learn_optimal_orthonormal_transformation(cur_m1, cur_m2)
        row_delta = np.sqrt(((cur_m1 - cur_m2 @ W.T) ** 2).sum(axis=1))

        n_keep = n_clean - (i + 1)
        sort_order = np.argsort(row_delta, axis=0)
        best_sorted = sort_order[:n_keep]
        cur_rows = np.sort(cur_rows[best_sorted])

    align_rows_enum = clean_rows[cur_rows]
    mask = np.zeros((m1.shape[0],), dtype=bool)
    mask[align_rows_enum] = True

    if align_rows_enum.size < n_stable_rows:
        print("[WARN] Too many small rows: unable to return requested number of alignment rows.")
    if align_rows_enum.size < m1.shape[1]:
        print("[WARN] #alignment rows is less than #latent variables.")

    return mask


def align_loading_matrices(
    m1: np.ndarray,
    m2: np.ndarray,
    n: int,
    th: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    MATLAB alignLoadingMatrices.m:
      alignChs = identifyStableLoadingRows(...)
      W = learnOptimalOrthonormalTransformation(m1(alignChs,:), m2(alignChs,:))
    """
    align_chs = identify_stable_loading_rows(m1, m2, n, th)
    W = learn_optimal_orthonormal_transformation(m1[align_chs, :], m2[align_chs, :])
    return W, align_chs


def update_stabilizer(
    base_fa: FAModel,
    Y_trials: np.ndarray,
    *,
    n_fa_restarts: int = 5,
    max_n_its: int = 100000,
    ll_diff_thresh: float = 1e-5,
    min_priv_var: float = 0.1,
    C_init: Optional[np.ndarray] = None,
    psi_init: Optional[np.ndarray] = None,
    verbose: bool = True,
    align_n: Optional[int] = None,
    align_th: float = 0.01,
) -> FAModel:
    """
    MATLAB updateStabilizer.m:
      - fit FA on update data (multiple restarts, best LL)
      - align loadings to base via alignLoadingMatrices
      - rotate C by W': C <- C * W'
    """
    if align_n is None:
        align_n = base_fa.C.shape[0]

    if Y_trials.ndim != 3:
        raise ValueError(f"Y_trials must be 3D [N,T,C]. Got {Y_trials.shape}")
    N, T, C = Y_trials.shape
    X = Y_trials.reshape(N * T, C).astype(np.float64)

    best: Optional[FAModel] = None
    best_ll = -np.inf

    for r in range(1, n_fa_restarts + 1):
        if verbose:
            print(f"[UpdateFA] restart {r}/{n_fa_restarts}")
        fa = fit_fa(
            X,
            base_fa.C.shape[1],
            max_n_its=max_n_its,
            ll_diff_thresh=ll_diff_thresh,
            min_priv_var=min_priv_var,
            C_init=C_init,
            psi_init=psi_init,
            verbose=verbose,
        )
        final_ll = float(fa.diags["ll"][-1]) if fa.diags["ll"].size else -np.inf
        if final_ll > best_ll:
            best_ll = final_ll
            best = fa

    assert best is not None

    W, align_chs = align_loading_matrices(base_fa.C, best.C, align_n, align_th)
    best.C = best.C @ W.T
    best.alignChs = align_chs
    return best


# ------------------------ Latents + pooling ------------------------

def apply_beta_o(
    beta: np.ndarray,
    o: np.ndarray,
    Y_trials: np.ndarray,
) -> np.ndarray:
    """
    MATLAB apply_beta_o: per trial y [C x T], l = beta*y + o -> [d x T]
    Here Y_trials is [N, T, C]. Returns latents [N, T, d].
    """
    beta = np.asarray(beta, dtype=np.float64)  # (d,C)
    o = np.asarray(o, dtype=np.float64).reshape(-1)  # (d,)
    Y = np.asarray(Y_trials, dtype=np.float64)  # (N,T,C)

    # (N,T,C) @ (C,d) => (N,T,d)
    latents = Y @ beta.T
    latents += o.reshape(1, 1, -1)
    return latents


def pool_trials(latents: np.ndarray, how: str) -> np.ndarray:
    """
    MATLAB pool_trials:
      - mean: per trial mean over time => [N x d]
      - meanstd: concat mean and std => [N x 2d]
      - flatten: reshape [d x T] into vector => [N x d*T]
        (with MATLAB column-wise order; our (N,T,d) representation matches
         MATLAB flattening as contiguous blocks per time step).
    """
    how = how.lower()
    if latents.ndim != 3:
        raise ValueError(f"latents must be 3D [N,T,d]. Got {latents.shape}")
    N, T, d = latents.shape

    if how == "mean":
        return latents.mean(axis=1)
    if how == "meanstd":
        m = latents.mean(axis=1)
        s = latents.std(axis=1, ddof=0)
        return np.concatenate([m, s], axis=1)
    if how == "flatten":
        return latents.reshape(N, T * d)
    raise ValueError(f"Unknown pooling method: {how}")


# ---------------------------- MLP ----------------------------

def train_mlp_classifier(
    X_train: np.ndarray,
    y_train: np.ndarray,
    *,
    seed: int,
    hidden_size: int = 512,
    verbose: int = 1,
) -> Pipeline:
    """
    Rough equivalent to MATLAB fitcnet(... 'LayerSizes',512,'Activations','relu','Standardize',true)
    """
    clf = MLPClassifier(
        hidden_layer_sizes=(hidden_size,),
        activation="relu",
        solver="adam",
        max_iter=1000,          # MATLAB fitcnet default is higher than 200; use 1000 for parity
        random_state=seed,
        verbose=bool(verbose),
    )
    pipe = Pipeline([
        ("scaler", StandardScaler(with_mean=True, with_std=True)),
        ("mlp", clf),
    ])
    pipe.fit(X_train, y_train)
    return pipe


# ----------------------- One day end-to-end -----------------------

def run_mlp_stabilization_onerun(
    *,
    data_file: Union[str, Path],
    n_latents: int = 36,
    baseline_ntrials: int = 100,
    calib_ntrials: int = 28,
    pooling: str = "flatten",
    random_seed: int = 31,
    fa_n_restarts: int = 5,
    fa_ll_thresh: float = 1e-5,
    fa_max_its: int = 100000,
    fa_min_priv_var: float = 1.0,
    align_th: float = 0.1,
    align_n: int = 150,
    save_latents: bool = True,
    out_dir: Union[str, Path] = ".",
    verbose: bool = True,
) -> float:
    """
    Port of the MATLAB function run_mlp_stabilization_onerun(index,seed).
    Returns test accuracy for that day and seed.
    """
    set_global_seed(random_seed)

    data_file = Path(data_file)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if verbose:
        print(f"\n=== Day file: {data_file}  seed={random_seed} ===")

    S = loadmat(data_file, squeeze_me=True, struct_as_record=False)

    def _get(name: str) -> np.ndarray:
        if name not in S:
            raise KeyError(f"Missing variable '{name}' in MAT file: {data_file}")
        return np.asarray(S[name])

    cebra_dir_train = _get("cebra_dir_train")   # [N_train, T, C]
    label_train = _as_1d(_get("label_train"))
    cebra_dir_test = _get("cebra_dir_test")     # [N_test, T, C]
    label_test = _as_1d(_get("label_test"))

    if cebra_dir_train.ndim != 3 or cebra_dir_test.ndim != 3:
        raise ValueError("Expected cebra_dir_train/test to be 3D arrays [N,T,C].")

    N_train, T, C = cebra_dir_train.shape
    N_test = cebra_dir_test.shape[0]

    if N_train < baseline_ntrials:
        raise ValueError("Training set too small for baseline truncation.")
    if N_test < calib_ntrials + 1:
        raise ValueError("Test set too small for calibration+test split.")

    if verbose:
        print(f"Train: {N_train} trials, Test: {N_test} trials, T={T}, C={C}")

    # 1) Fit base stabilizer on last BASELINE_NTRIALS training trials
    baseline_inds = np.arange(N_train - baseline_ntrials, N_train)
    Y_base = cebra_dir_train[baseline_inds, :, :]  # [baseline_ntrials, T, C]

    base_fa = fit_base_stabilizer(
        Y_base,
        n_latents,
        n_fa_restarts=fa_n_restarts,
        max_n_its=fa_max_its,
        ll_diff_thresh=fa_ll_thresh,
        min_priv_var=fa_min_priv_var,
        verbose=verbose,
    )
    beta_base, o_base = get_stabilization_matrices(base_fa)

    # 2) Train set latents -> pool -> train MLP
    L_train = apply_beta_o(beta_base, o_base, cebra_dir_train)   # [N_train,T,d]
    X_train = pool_trials(L_train, pooling)                      # [N_train, D_feat]
    y_train = label_train

    if verbose:
        print(f"MLP training features: {X_train.shape[0]} x {X_train.shape[1]} (pooling={pooling})")

    mdl = train_mlp_classifier(X_train, y_train, seed=random_seed, hidden_size=512, verbose=1 if verbose else 0)

    # 3) New day: calib -> update stabilizer -> test
    calib_inds = np.arange(0, calib_ntrials)
    test_inds = np.arange(calib_ntrials, N_test)

    Y_calib = cebra_dir_test[calib_inds, :, :]
    Y_test = cebra_dir_test[test_inds, :, :]
    y_test = label_test[test_inds]

    new_fa = update_stabilizer(
        base_fa,
        Y_calib,
        n_fa_restarts=fa_n_restarts,
        max_n_its=fa_max_its,
        ll_diff_thresh=fa_ll_thresh,
        min_priv_var=fa_min_priv_var,
        align_n=align_n,
        align_th=align_th,
        verbose=verbose,
    )
    beta_new, o_new = get_stabilization_matrices(new_fa)

    L_test = apply_beta_o(beta_new, o_new, Y_test)
    X_test = pool_trials(L_test, pooling)

    y_pred = mdl.predict(X_test)
    acc = float(np.mean(y_pred == y_test))

    if verbose:
        print(f"Test accuracy on new day (after stabilization): {acc:.4f}")

    # Save latent variables similarly to MATLAB (optional)
    if save_latents:
        latent_data = {
            "train": {
                "latents": L_train,                # [N_train,T,d]
                "pooled_features": X_train,        # [N_train,D_feat]
                "labels": y_train,
                "beta": beta_base,
                "o": o_base,
            },
            "test": {
                "latents": L_test,                 # [N_test-CALIB,T,d]
                "pooled_features": X_test,
                "labels": y_test,
                "beta": beta_new,
                "o": o_new,
                "calib_latents": apply_beta_o(beta_new, o_new, Y_calib),
            },
            "metadata": {
                "N_latents": n_latents,
                "pooling_method": pooling,
                "data_file": str(data_file),
                "seed": int(random_seed),
            },
        }
        latent_filename = out_dir / f"latent_data_{data_file.stem}_seed{random_seed}.mat"
        # savemat prefers plain numpy arrays / dicts
        savemat(latent_filename, {"latent_data": latent_data}, do_compression=True)
        if verbose:
            print(f"Saved latent variables to: {latent_filename}")

    return acc


# ---------------------------- Main loop ----------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="MLP + stabilization (Python port of run_mlp_stab_latent.m)")
    p.add_argument("--data-root", type=str, default=r"D:\GY_mat_singleday",
                   help="Root folder containing GY_data_day-<index>.mat (default matches MATLAB).")
    p.add_argument("--day-start", type=int, default=50, help="Start day index (inclusive).")
    p.add_argument("--day-end", type=int, default=119, help="End day index (inclusive).")
    p.add_argument("--skip-days", type=int, nargs="*", default=[7,10,13,14,17,18,20,21,27,30],
                   help="Day indices to skip (kept identical to MATLAB).")
    p.add_argument("--seeds", type=int, nargs="*", default=[31,44,46,54,69],
                   help="Random seeds to evaluate (identical to MATLAB).")
    p.add_argument("--out-dir", type=str, default="outputs_stabilization_mlp", help="Output directory.")
    p.add_argument("--pooling", type=str, default="flatten", choices=["mean", "meanstd", "flatten"],
                   help="Pooling method (identical options to MATLAB script).")
    # Hyper-parameters (defaults taken from run_mlp_stab_latent.m)
    p.add_argument("--n-latents", type=int, default=36)
    p.add_argument("--baseline-ntrials", type=int, default=100)
    p.add_argument("--calib-ntrials", type=int, default=28)
    p.add_argument("--fa-n-restarts", type=int, default=5)
    p.add_argument("--fa-ll-thresh", type=float, default=1e-5)
    p.add_argument("--fa-max-its", type=int, default=100000)
    p.add_argument("--fa-min-priv-var", type=float, default=1.0)
    p.add_argument("--align-th", type=float, default=0.1)
    p.add_argument("--align-n", type=int, default=150)
    p.add_argument("--no-save-latents", action="store_true", help="Disable saving latent .mat files.")
    p.add_argument("--quiet", action="store_true", help="Less printing.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    days_all = list(range(args.day_start, args.day_end + 1))
    days = [d for d in days_all if d not in set(args.skip_days)]

    seeds: List[int] = list(args.seeds)
    results = np.full((len(days), len(seeds)), np.nan, dtype=np.float64)

    for di, day_idx in enumerate(days):
        data_file = Path(args.data_root) / f"GY_data_day-{day_idx}.mat"
        if not data_file.exists():
            print(f"[WARN] Missing file, skipping: {data_file}")
            continue

        for si, seed in enumerate(seeds):
            acc = run_mlp_stabilization_onerun(
                data_file=data_file,
                n_latents=args.n_latents,
                baseline_ntrials=args.baseline_ntrials,
                calib_ntrials=args.calib_ntrials,
                pooling=args.pooling,
                random_seed=seed,
                fa_n_restarts=args.fa_n_restarts,
                fa_ll_thresh=args.fa_ll_thresh,
                fa_max_its=args.fa_max_its,
                fa_min_priv_var=args.fa_min_priv_var,
                align_th=args.align_th,
                align_n=args.align_n,
                save_latents=(not args.no_save_latents),
                out_dir=out_dir,
                verbose=(not args.quiet),
            )
            results[di, si] = acc

    # Save results matrix
    np.save(out_dir / "results.npy", results)
    np.savetxt(out_dir / "results.csv", results, delimiter=",")
    with open(out_dir / "days.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(map(str, days)))
    with open(out_dir / "seeds.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(map(str, seeds)))

    # Plot accuracy vs day with dashed mean line
    fig = plt.figure(figsize=(10, 5))
    ax = fig.add_subplot(1, 1, 1)

    x = np.array(days, dtype=int)
    for si, seed in enumerate(seeds):
        y = results[:, si]
        ax.plot(x, y, marker="o", linewidth=1.5, label=f"seed {seed}")
        if np.isfinite(y).any():
            mean_y = float(np.nanmean(y))
            ax.axhline(mean_y, linestyle="--", linewidth=1.2)

    ax.set_xlabel("Day index")
    ax.set_ylabel("Test accuracy")
    ax.set_title("Test accuracy per day (dashed = mean over test days)")
    ax.set_ylim(0.0, 1.0)
    ax.grid(True, alpha=0.3)
    ax.legend(loc="best", fontsize=9)

    fig.tight_layout()
    fig_path = out_dir / "test_accuracy_by_day.png"
    fig.savefig(fig_path, dpi=200)
    plt.close(fig)

    print("\n=== Done ===")
    print(f"Saved results to: {out_dir}")
    print(f"Saved plot to: {fig_path}")


if __name__ == "__main__":
    main()
