"""
Classification interface for stabilization + MLP decoding.
"""

from __future__ import annotations

import argparse
import math
import os
from pprint import pformat
from typing import Any

import numpy as np
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        apply_beta_o,
        encode_labels,
        encode_labels_with_classes,
        ensure_output_dir,
        evaluate_classifier_head,
        fit_base_stabilizer,
        fit_classifier_head,
        get_stabilization_matrices,
        load_joblib,
        load_npz_classification,
        plot_classifier_diagnostics,
        pool_trials,
        resolve_align_n,
        resolve_baseline_ntrials,
        resolve_calib_ntrials,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        update_stabilizer,
        validate_dataset_classification,
        validate_device,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        apply_beta_o,
        encode_labels,
        encode_labels_with_classes,
        ensure_output_dir,
        evaluate_classifier_head,
        fit_base_stabilizer,
        fit_classifier_head,
        get_stabilization_matrices,
        load_joblib,
        load_npz_classification,
        plot_classifier_diagnostics,
        pool_trials,
        resolve_align_n,
        resolve_baseline_ntrials,
        resolve_calib_ntrials,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        update_stabilizer,
        validate_dataset_classification,
        validate_device,
    )


SUPPORTS_EXTERNAL_VAL = True
SUPPORTS_TRAIN_WITHOUT_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "classification"
PRIMARY_TEST_METRIC = "acc"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_arr = np.asarray(dataset[0])
    y_arr = np.asarray(dataset[1])
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        x_arr, y_arr = load_npz_classification(datapath)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
        x_arr, y_arr = validate_dataset_classification(x_arr, y_arr)
    return x_arr, y_arr


def _build_val_metrics(
    base_beta: np.ndarray,
    base_o: np.ndarray,
    model: Any,
    val_x: np.ndarray,
    val_y: np.ndarray,
    pooling: str,
) -> dict[str, Any]:
    latent = apply_beta_o(base_beta, base_o, val_x)
    x_val = pool_trials(latent, pooling)
    return evaluate_classifier_head(model, x_val, val_y)


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 300,
    lr: float = 1e-3,
    weight_decay: float = 1e-4,
    seed: int = 42,
    device: str = "auto",
    baseline_ntrials: int = 100,
    n_latents: int = 36,
    pooling: str = "flatten",
    hidden_size: int = 512,
    fa_n_restarts: int = 5,
    fa_ll_thresh: float = 1e-5,
    fa_max_its: int = 100000,
    fa_min_priv_var: float = 1.0,
    align_th: float = 0.1,
    align_n: int = 150,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 0,
    enable_alignment: bool = True,
    verbose: bool = False,
) -> dict[str, Any]:
    del patience, val_ratio
    set_seed(seed)
    validate_device(device)

    x_all, y_all_raw = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath")

    used_external_val = val_dataset is not None or bool(val_datapath)
    used_internal_val_split = False

    if used_external_val:
        fit_x, fit_y_raw = x_all, y_all_raw
        val_x, val_y_raw = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath")
    else:
        fit_x, fit_y_raw = x_all, y_all_raw
        val_x, val_y_raw = None, None

    fit_y, label_to_id, classes = encode_labels(fit_y_raw)
    if used_external_val:
        assert val_y_raw is not None
        val_y = encode_labels_with_classes(val_y_raw, classes)
    else:
        val_y = None

    if enable_alignment:
        baseline_n = resolve_baseline_ntrials(fit_x.shape[0], baseline_ntrials)
        baseline_inds = np.arange(fit_x.shape[0] - baseline_n, fit_x.shape[0])
        base_fa = fit_base_stabilizer(
            fit_x[baseline_inds],
            n_latents,
            n_fa_restarts=fa_n_restarts,
            max_n_its=fa_max_its,
            ll_diff_thresh=fa_ll_thresh,
            min_priv_var=fa_min_priv_var,
            verbose=False,
        )
        beta_base, o_base = get_stabilization_matrices(base_fa)
        train_latents = apply_beta_o(beta_base, o_base, fit_x)
        x_train = pool_trials(train_latents, pooling)
    else:
        baseline_n = 0
        base_fa = None
        beta_base = None
        o_base = None
        x_train = pool_trials(fit_x, pooling)

    model = fit_classifier_head(
        x_train,
        fit_y,
        seed=seed,
        hidden_size=hidden_size,
        batch_size=batch_size,
        epochs=epochs,
        lr=lr,
        weight_decay=weight_decay,
        verbose=True,
    )
    train_metrics = evaluate_classifier_head(model, x_train, fit_y)

    if used_external_val:
        assert val_x is not None and val_y is not None
        if enable_alignment:
            val_metrics = _build_val_metrics(beta_base, o_base, model, val_x, val_y, pooling)
        else:
            val_metrics = evaluate_classifier_head(model, pool_trials(val_x, pooling), val_y)
        val_acc = float(val_metrics["acc"])
        print(
            f"Training Summary | train_acc={train_metrics['acc']:.4f} | "
            f"val_acc={val_metrics['acc']:.4f}"
        )
    else:
        val_metrics = None
        val_acc = float("nan")
        print(f"Training Summary | train_acc={train_metrics['acc']:.4f} | val_acc=nan")

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "metrics.csv")
    logger = CsvLogger(csv_path, task="cls")
    try:
        logger.log("train", train_metrics)
        if val_metrics is not None:
            logger.log("val", val_metrics)
    finally:
        logger.close()

    ckpt_path = os.path.join(run_dir, "best_model.joblib") if save_ckpt else None
    payload = {
        "model": model,
        "classes": classes,
        "label_to_id": label_to_id,
        "beta_base": beta_base,
        "o_base": o_base,
        "base_fa": base_fa,
        "pooling": pooling,
        "align_n": resolve_align_n(fit_x.shape[2], align_n) if enable_alignment else 0,
        "align_th": align_th,
        "fa_n_restarts": fa_n_restarts,
        "fa_ll_thresh": fa_ll_thresh,
        "fa_max_its": fa_max_its,
        "fa_min_priv_var": fa_min_priv_var,
        "baseline_ntrials": baseline_n,
        "enable_alignment": enable_alignment,
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if save_ckpt:
        save_joblib(ckpt_path, payload)

    plot_path = None
    if plot:
        plot_path = plot_classifier_diagnostics(base_fa, model, os.path.join(run_dir, "training_curve.png"))

    save_json(
        os.path.join(run_dir, "config.json"),
        {
            "task": "classification",
            "batch_size": batch_size,
            "epochs": epochs,
            "lr": lr,
            "weight_decay": weight_decay,
            "seed": seed,
            "device": "cpu",
            "baseline_ntrials": baseline_n,
            "n_latents": n_latents,
            "pooling": pooling,
            "hidden_size": hidden_size,
            "fa_n_restarts": fa_n_restarts,
            "fa_ll_thresh": fa_ll_thresh,
            "fa_max_its": fa_max_its,
            "fa_min_priv_var": fa_min_priv_var,
            "align_th": align_th,
            "align_n": align_n,
            "plot_path": plot_path,
            "save_ckpt": save_ckpt,
            "enable_alignment": enable_alignment,
            "used_external_val": used_external_val,
            "used_internal_val_split": used_internal_val_split,
            "has_validation": used_external_val,
        },
    )

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            **payload,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
        }
    )
    train_result = {
        "task": "classification_train",
        "train_acc": float(train_metrics["acc"]),
        "val_acc": val_acc,
        "num_classes": int(len(classes)),
        "classes": classes,
        "label_to_id": label_to_id,
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": "cpu",
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    calib_ratio: float = 0.2,
    min_calib_trials: int = 1,
    max_calib_trials: int | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained stabilization model found. Call train() before test().")

    test_x, test_y_raw = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    test_y = encode_labels_with_classes(test_y_raw, _TRAIN_STATE["classes"])
    if not _TRAIN_STATE.get("enable_alignment", True):
        x_eval = pool_trials(test_x, _TRAIN_STATE["pooling"])
        metrics = evaluate_classifier_head(_TRAIN_STATE["model"], x_eval, test_y)
        print(f"Test Accuracy: {metrics['acc']:.4f}")
        test_result = {
            "task": "classification_test",
            "acc": float(metrics["acc"]),
            "confusion_matrix": metrics["confusion_matrix"],
            "calib_ntrials": 0,
            "eval_ntrials": int(test_x.shape[0]),
        }
        if verbose:
            _print_verbose_result("Test result:", test_result)
        return test_result
    calib_n = resolve_calib_ntrials(test_x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
    calib_x = test_x[:calib_n]
    eval_x = test_x[calib_n:]
    eval_y = test_y[calib_n:]

    updated_fa = update_stabilizer(
        _TRAIN_STATE["base_fa"],
        calib_x,
        align_n=_TRAIN_STATE["align_n"],
        align_th=_TRAIN_STATE["align_th"],
        n_fa_restarts=_TRAIN_STATE["fa_n_restarts"],
        max_n_its=_TRAIN_STATE["fa_max_its"],
        ll_diff_thresh=_TRAIN_STATE["fa_ll_thresh"],
        min_priv_var=_TRAIN_STATE["fa_min_priv_var"],
        verbose=False,
    )
    beta_new, o_new = get_stabilization_matrices(updated_fa)
    eval_latents = apply_beta_o(beta_new, o_new, eval_x)
    x_eval = pool_trials(eval_latents, _TRAIN_STATE["pooling"])
    metrics = evaluate_classifier_head(_TRAIN_STATE["model"], x_eval, eval_y)
    print(f"Test Accuracy: {metrics['acc']:.4f}")
    test_result = {
        "task": "classification_test",
        "acc": float(metrics["acc"]),
        "confusion_matrix": metrics["confusion_matrix"],
        "calib_ntrials": int(calib_n),
        "eval_ntrials": int(eval_x.shape[0]),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="stabilization classifier train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None)
    parser.add_argument("--val_datapath", type=str, default=None)
    parser.add_argument("--test_datapath", type=str, default=None)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--baseline_ntrials", type=int, default=100)
    parser.add_argument("--n_latents", type=int, default=36)
    parser.add_argument("--pooling", type=str, default="flatten", choices=["mean", "meanstd", "flatten"])
    parser.add_argument("--hidden_size", type=int, default=512)
    parser.add_argument("--fa_n_restarts", type=int, default=5)
    parser.add_argument("--fa_ll_thresh", type=float, default=1e-5)
    parser.add_argument("--fa_max_its", type=int, default=100000)
    parser.add_argument("--fa_min_priv_var", type=float, default=1.0)
    parser.add_argument("--align_th", type=float, default=0.1)
    parser.add_argument("--align_n", type=int, default=150)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=0)
    parser.add_argument("--calib_ratio", type=float, default=0.2)
    parser.add_argument("--min_calib_trials", type=int, default=1)
    parser.add_argument("--max_calib_trials", type=int, default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt

    if args.train_datapath and not args.test_datapath:
        x_all, y_all = _resolve_input_dataset(None, args.train_datapath, "train_dataset", "train_datapath")
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
            stratify=y_all if len(np.unique(y_all)) > 1 else None,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            baseline_ntrials=args.baseline_ntrials,
            n_latents=args.n_latents,
            pooling=args.pooling,
            hidden_size=args.hidden_size,
            fa_n_restarts=args.fa_n_restarts,
            fa_ll_thresh=args.fa_ll_thresh,
            fa_max_its=args.fa_max_its,
            fa_min_priv_var=args.fa_min_priv_var,
            align_th=args.align_th,
            align_n=args.align_n,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(
            test_dataset=(test_x, test_y),
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            baseline_ntrials=args.baseline_ntrials,
            n_latents=args.n_latents,
            pooling=args.pooling,
            hidden_size=args.hidden_size,
            fa_n_restarts=args.fa_n_restarts,
            fa_ll_thresh=args.fa_ll_thresh,
            fa_max_its=args.fa_max_its,
            fa_min_priv_var=args.fa_min_priv_var,
            align_th=args.align_th,
            align_n=args.align_n,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(
            test_datapath=args.test_datapath if args.test_datapath else args.train_datapath,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
