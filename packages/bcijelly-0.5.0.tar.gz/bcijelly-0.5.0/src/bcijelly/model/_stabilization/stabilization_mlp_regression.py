#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stabilization_mlp_regression.py

Python port of MATLAB script: run_jango_mlp_stabilization.m
(Regression task: stabilized FA latents + MLP regressor, evaluated per test day.)

Data assumption (per day .mat file):
    features: [nTrials x nBins x nCh]
    labels  : [nTrials x nBins x 2]   (e.g., x/y kinematics)

Pipeline per fold (exactly following the MATLAB script):
1) Aggregate training days (specified by FOLDS), collect all trials.
2) Fit base stabilizer (Factor Analysis) on training trials.
3) Convert training trials to stabilized latents and z-score them using training stats.
4) Train an MLP regressor using Scaled Conjugate Gradient (MATLAB 'trainscg') for trainEpochs.
5) For the fold's test day:
   - take first nCal trials as calibration, fit an updated stabilizer aligned to base
   - optionally fine-tune the same MLP on (train + calib) for fineTuneEpochs (continue weights)
   - evaluate on remaining trials; report R² for x and y and their mean.
6) Save per-fold results and aligned latents for the test day.

Outputs:
- results_per_day.csv / results_per_day.mat
- aligned_latent_features.mat
- plot_r2_by_day.png

Important:
- The MATLAB stabilizedbci repo's fitFA.m is not included in the uploaded files.
  This script implements a standard EM algorithm for Gaussian Factor Analysis with
  diagonal private variances (psi). The stabilization, alignment, and matrix
  formulas match the uploaded MATLAB helper scripts. Exact numerical identity to
  your MATLAB environment depends on the exact fitFA.m implementation details.
"""

from __future__ import annotations

import argparse
import dataclasses
import math
import os
import re
from datetime import datetime, date
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import matplotlib.pyplot as plt

from scipy.io import loadmat, savemat


# =========================
#  Hyperparameters (MATLAB)
# =========================

# Folds copied verbatim from run_jango_mlp_stabilization.m
FOLDS = [
    (['20150730','20150731','20150801','20150805','20150806'], ['20150807']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150808']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150809']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150820']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150824']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150825']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150826']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150827']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150828']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150831']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150905']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150906']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20150908']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20151029']),
    (['20150730','20150731','20150801','20150805','20150806'], ['20151102']),
]

# Stabilizer settings (from MATLAB script)
N_LATENTS = 10
ALIGN_N = 60
ALIGN_TH = 0.01
N_CAL_TRIALS_PER_TEST_DAY = 28

# MLP regressor settings (from MATLAB script)
MLP_HIDDEN = (128, 64)
TRAIN_EPOCHS = 300
FINE_TUNE = True
FINE_TUNE_EPOCHS = 100
RNG_SEED = 44

# FA defaults from fitBaseStabilizer.m / updateStabilizer.m
FA_N_RESTARTS = 5
FA_MAX_ITS = 100000
FA_LL_DIFF_THRESH = 1e-5
FA_MIN_PRIV_VAR = 0.1
FA_VERBOSE = True


# =========================
#     Misc utilities
# =========================

def set_global_seed(seed: int) -> None:
    np.random.seed(seed)


def parse_date_from_file(fname: str) -> date:
    """
    Parse date from file like 'Jango_20150809_001.mat'
    """
    m = re.search(r'Jango_(\d{8})_', fname)
    if not m:
        raise ValueError(f"Cannot parse date from filename: {fname}")
    return datetime.strptime(m.group(1), "%Y%m%d").date()


def date_str(d: date) -> str:
    return d.strftime("%Y%m%d")


def load_mat_compat(path: Union[str, Path]) -> Dict[str, np.ndarray]:
    """
    Load .mat with scipy.io.loadmat. If it's v7.3 (HDF5), try h5py.
    """
    path = Path(path)
    try:
        return loadmat(path, squeeze_me=True, struct_as_record=False)
    except NotImplementedError:
        # likely v7.3
        import h5py
        out: Dict[str, np.ndarray] = {}
        with h5py.File(path, "r") as f:
            for k in f.keys():
                out[k] = np.array(f[k])
        return out


def labels_to_matrix(labels: np.ndarray) -> np.ndarray:
    """
    MATLAB labelsToMatrix(labels):
      labels [nTrials x nBins x 2] -> [2 x (nTrials*nBins)] and then transposed to [N x 2].

    IMPORTANT: MATLAB reshapes in column-major (Fortran) order. To match the exact sample
    ordering (bin varies fastest, then trial), we must reshape with order='F' in NumPy.
    """
    labels = np.asarray(labels)
    if labels.ndim != 3 or labels.shape[2] != 2:
        raise ValueError(f"labels must be [nTrials,nBins,2]. Got {labels.shape}")
    tmp = np.transpose(labels, (2, 1, 0))              # (2, nBins, nTrials)
    Y_2xN = np.reshape(tmp, (2, -1), order="F")        # (2, nBins*nTrials) MATLAB-compatible
    return Y_2xN.T                                      # (N,2)
def zscore_cols(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    MATLAB zscore_cols where X is [nFeatures x nSamples].
    In Python we use X as [nSamples x nFeatures].
    Returns Xz, mu, sd where mu/sd are shape (nFeatures,)
    """
    mu = X.mean(axis=0)
    sd = X.std(axis=0, ddof=1)
    sd[sd == 0] = 1.0
    Xz = (X - mu) / sd
    return Xz, mu, sd


def r2_score_2d(Ytrue: np.ndarray, Ypred: np.ndarray) -> np.ndarray:
    """
    MATLAB r2_score: per output dimension compute R², return shape (2,)
    """
    Ytrue = np.asarray(Ytrue, dtype=np.float64)
    Ypred = np.asarray(Ypred, dtype=np.float64)
    err = Ytrue - Ypred
    ss_res = np.sum(err ** 2, axis=0)
    mu = np.mean(Ytrue, axis=0)
    ss_tot = np.sum((Ytrue - mu) ** 2, axis=0)
    # Avoid divide-by-zero
    ss_tot = np.where(ss_tot == 0, 1e-12, ss_tot)
    r2 = 1.0 - ss_res / ss_tot
    return r2


# =========================
#     Factor Analysis
# =========================

@dataclasses.dataclass
class FAModel:
    d: np.ndarray
    C: np.ndarray
    psi: np.ndarray
    diags: Dict[str, np.ndarray]
    alignChs: Optional[np.ndarray] = None


def fit_fa(
    X: np.ndarray,
    n_latents: int,
    *,
    max_n_its: int,
    ll_diff_thresh: float,
    min_priv_var: float,
    verbose: bool,
    C_init: Optional[np.ndarray] = None,
    psi_init: Optional[np.ndarray] = None,
    batch_size: int = 8192,
) -> FAModel:
    """
    EM for Gaussian Factor Analysis with diagonal Psi.
    X: [N x D] observations.
    """
    X = np.asarray(X, dtype=np.float64)
    N, D = X.shape
    K = int(n_latents)

    d = X.mean(axis=0)
    Xc = X - d

    Sxx = Xc.T @ Xc  # (D,D)

    if C_init is None or (isinstance(C_init, np.ndarray) and C_init.size == 0):
        C = 0.01 * np.random.randn(D, K)
    else:
        C = np.asarray(C_init, dtype=np.float64).copy()
        if C.shape != (D, K):
            raise ValueError(f"C_INIT shape mismatch. Expected {(D,K)} got {C.shape}")

    if psi_init is None or (isinstance(psi_init, np.ndarray) and psi_init.size == 0):
        psi = np.maximum(np.var(Xc, axis=0), min_priv_var)
    else:
        psi = np.asarray(psi_init, dtype=np.float64).reshape(-1)
        psi = np.maximum(psi, min_priv_var)

    ll_trace: List[float] = []
    last_ll = -np.inf

    def compute_ll(C_: np.ndarray, psi_: np.ndarray) -> float:
        Sigma = C_ @ C_.T + np.diag(psi_)
        sign, logdet = np.linalg.slogdet(Sigma)
        if sign <= 0:
            return -np.inf
        try:
            L = np.linalg.cholesky(Sigma)
            tmp = np.linalg.solve(L, Sxx)
            Sigma_inv_Sxx = np.linalg.solve(L.T, tmp)
            tr_term = np.trace(Sigma_inv_Sxx)
        except np.linalg.LinAlgError:
            Sigma_inv = np.linalg.pinv(Sigma)
            tr_term = np.trace(Sxx @ Sigma_inv)
        ll = -0.5 * (N * (D * np.log(2.0 * np.pi) + logdet) + tr_term)
        return float(ll)

    for it in range(1, max_n_its + 1):
        inv_psi = 1.0 / psi
        Ct_invPsi = (C.T * inv_psi)
        M = np.eye(K) + Ct_invPsi @ C
        try:
            M_inv = np.linalg.inv(M)
        except np.linalg.LinAlgError:
            M_inv = np.linalg.pinv(M)

        sum_xz = np.zeros((D, K), dtype=np.float64)
        sum_zz = np.zeros((K, K), dtype=np.float64)

        for start in range(0, N, batch_size):
            end = min(N, start + batch_size)
            Xb = Xc[start:end, :]
            Ez = (Xb * inv_psi) @ C @ M_inv
            sum_xz += Xb.T @ Ez
            sum_zz += Ez.T @ Ez

        sum_zz += N * M_inv

        try:
            sum_zz_inv = np.linalg.inv(sum_zz)
        except np.linalg.LinAlgError:
            sum_zz_inv = np.linalg.pinv(sum_zz)

        C_new = sum_xz @ sum_zz_inv

        recon = C_new @ sum_xz.T
        psi_new = np.diag(Sxx - recon) / N
        psi_new = np.maximum(psi_new, min_priv_var)

        C, psi = C_new, psi_new

        ll = compute_ll(C, psi)
        ll_trace.append(ll)

        if verbose and (it == 1 or it % 25 == 0):
            print(f"[FA] iter={it:6d} ll={ll: .6e} dll={ll - last_ll: .3e}")

        if np.isfinite(last_ll) and abs(ll - last_ll) < ll_diff_thresh:
            if verbose:
                print(f"[FA] Converged at iter={it} |dll|<{ll_diff_thresh}")
            break
        last_ll = ll

    return FAModel(d=d, C=C, psi=psi, diags={"ll": np.array(ll_trace, dtype=np.float64)})


def fit_base_stabilizer(
    Y_trials: np.ndarray,
    n_latents: int,
    *,
    n_fa_restarts: int = FA_N_RESTARTS,
    max_n_its: int = FA_MAX_ITS,
    ll_diff_thresh: float = FA_LL_DIFF_THRESH,
    min_priv_var: float = FA_MIN_PRIV_VAR,
    verbose: bool = FA_VERBOSE,
) -> FAModel:
    """
    Port of fitBaseStabilizer.m for our stacked array format:
    Y_trials: [nTrials x nBins x nCh]
    """
    if Y_trials.ndim != 3:
        raise ValueError(f"Y_trials must be [nTrials,nBins,nCh]. Got {Y_trials.shape}")
    nTrials, nBins, nCh = Y_trials.shape
    X = Y_trials.reshape(nTrials * nBins, nCh)  # [N x D]

    best: Optional[FAModel] = None
    best_ll = -np.inf
    for r in range(1, n_fa_restarts + 1):
        if verbose:
            print(f"[BaseFA] restart {r}/{n_fa_restarts}")
        fa = fit_fa(
            X, n_latents,
            max_n_its=max_n_its,
            ll_diff_thresh=ll_diff_thresh,
            min_priv_var=min_priv_var,
            verbose=verbose,
        )
        ll = float(fa.diags["ll"][-1]) if fa.diags["ll"].size else -np.inf
        if ll > best_ll:
            best_ll = ll
            best = fa
    assert best is not None
    return best


def get_stabilization_matrices(fa: FAModel) -> Tuple[np.ndarray, np.ndarray]:
    """
    Port of getStabilizatonMatrices.m:
      beta = C'/(C*C' + diag(psi))
      o = -beta*d
    """
    C = fa.C
    Psi = np.diag(fa.psi)
    Sigma = C @ C.T + Psi
    try:
        Sigma_inv = np.linalg.inv(Sigma)
    except np.linalg.LinAlgError:
        Sigma_inv = np.linalg.pinv(Sigma)
    beta = C.T @ Sigma_inv
    o = -(beta @ fa.d.reshape(-1, 1))
    return beta, o


def learn_optimal_orthonormal_transformation(m1: np.ndarray, m2: np.ndarray) -> np.ndarray:
    S = m1.T @ m2
    U, _, Vt = np.linalg.svd(S, full_matrices=False)
    return U @ Vt


def identify_stable_loading_rows(m1: np.ndarray, m2: np.ndarray, n_stable_rows: int, th: float) -> np.ndarray:
    m1 = np.asarray(m1, dtype=np.float64)
    m2 = np.asarray(m2, dtype=np.float64)

    m1_norms = np.sqrt((m1 ** 2).sum(axis=1))
    m2_norms = np.sqrt((m2 ** 2).sum(axis=1))
    small = (m1_norms < th) | (m2_norms < th)

    clean = np.where(~small)[0]
    m1c = m1[clean, :]
    m2c = m2[clean, :]

    cur = np.arange(m1c.shape[0])
    n_drop = max(m1c.shape[0] - n_stable_rows, 0)

    for i in range(n_drop):
        cur_m1 = m1c[cur, :]
        cur_m2 = m2c[cur, :]
        W = learn_optimal_orthonormal_transformation(cur_m1, cur_m2)
        row_delta = np.sqrt(((cur_m1 - cur_m2 @ W.T) ** 2).sum(axis=1))

        n_keep = m1c.shape[0] - (i + 1)
        keep = np.argsort(row_delta)[:n_keep]
        cur = np.sort(cur[keep])

    align_enum = clean[cur]
    mask = np.zeros((m1.shape[0],), dtype=bool)
    mask[align_enum] = True

    if align_enum.size < n_stable_rows:
        print("[WARN] Too many small rows; returned fewer alignment rows than requested.")
    if align_enum.size < m1.shape[1]:
        print("[WARN] #alignment rows < #latents (may reduce alignment quality).")

    return mask


def align_loading_matrices(m1: np.ndarray, m2: np.ndarray, n: int, th: float) -> Tuple[np.ndarray, np.ndarray]:
    align_chs = identify_stable_loading_rows(m1, m2, n, th)
    W = learn_optimal_orthonormal_transformation(m1[align_chs, :], m2[align_chs, :])
    return W, align_chs


def update_stabilizer(
    base_fa: FAModel,
    Y_trials: np.ndarray,
    *,
    align_n: int = ALIGN_N,
    align_th: float = ALIGN_TH,
    n_fa_restarts: int = FA_N_RESTARTS,
    max_n_its: int = FA_MAX_ITS,
    ll_diff_thresh: float = FA_LL_DIFF_THRESH,
    min_priv_var: float = FA_MIN_PRIV_VAR,
    verbose: bool = FA_VERBOSE,
) -> FAModel:
    """
    Port of updateStabilizer.m for stacked array format:
    Y_trials: [nTrials x nBins x nCh] using calibration trials only.
    """
    if Y_trials.ndim != 3:
        raise ValueError(f"Y_trials must be [nTrials,nBins,nCh]. Got {Y_trials.shape}")

    nTrials, nBins, nCh = Y_trials.shape
    X = Y_trials.reshape(nTrials * nBins, nCh)

    best: Optional[FAModel] = None
    best_ll = -np.inf
    for r in range(1, n_fa_restarts + 1):
        if verbose:
            print(f"[UpdateFA] restart {r}/{n_fa_restarts}")
        fa = fit_fa(
            X, base_fa.C.shape[1],
            max_n_its=max_n_its,
            ll_diff_thresh=ll_diff_thresh,
            min_priv_var=min_priv_var,
            verbose=verbose,
        )
        ll = float(fa.diags["ll"][-1]) if fa.diags["ll"].size else -np.inf
        if ll > best_ll:
            best_ll = ll
            best = fa
    assert best is not None

    W, align_chs = align_loading_matrices(base_fa.C, best.C, align_n, align_th)
    best.C = best.C @ W.T
    best.alignChs = align_chs
    return best


def apply_beta_o(beta: np.ndarray, o: np.ndarray, Y_trials: np.ndarray) -> np.ndarray:
    """
    Apply l = beta*y + o to trials.
    Y_trials: [nTrials x nBins x nCh]
    beta: [nLatents x nCh]
    o:    [nLatents x 1]
    Returns latents: [nTrials x nBins x nLatents]
    """
    beta = np.asarray(beta, dtype=np.float64)
    o = np.asarray(o, dtype=np.float64).reshape(1, 1, -1)
    Y = np.asarray(Y_trials, dtype=np.float64)
    L = Y @ beta.T
    L = L + o
    return L


# =========================
#   MLP with trainscg (SCG)
# =========================

def tansig(x: np.ndarray) -> np.ndarray:
    # MATLAB tansig == tanh
    return np.tanh(x)


def dtansig_from_act(a: np.ndarray) -> np.ndarray:
    # derivative of tanh given activation a=tanh(z): 1-a^2
    return 1.0 - a * a


class SCGMLPRegressor:
    """
    A minimal MLP regressor trained by Scaled Conjugate Gradient (SCG),
    matching MATLAB fitnet(...,'trainscg') with hidden transfer 'tansig'
    and linear output.
    """

    def __init__(self, input_dim: int, hidden: Sequence[int], output_dim: int, seed: int = 0):
        self.input_dim = int(input_dim)
        self.hidden = tuple(int(h) for h in hidden)
        self.output_dim = int(output_dim)
        self.rng = np.random.RandomState(seed)

        # Parameters (weights/biases) initialized with Nguyen-Widrow (approximate) for tanh
        self.W1, self.b1 = self._nguyen_widrow(self.input_dim, self.hidden[0])
        self.W2, self.b2 = self._nguyen_widrow(self.hidden[0], self.hidden[1])
        # Output layer: small random init
        self.W3 = 0.01 * self.rng.randn(self.hidden[1], self.output_dim)
        self.b3 = np.zeros((self.output_dim,), dtype=np.float64)

    def _nguyen_widrow(self, n_in: int, n_out: int) -> Tuple[np.ndarray, np.ndarray]:
        W = self.rng.uniform(-0.5, 0.5, size=(n_in, n_out))
        # Normalize columns
        col_norm = np.sqrt(np.sum(W * W, axis=0, keepdims=True))
        col_norm = np.where(col_norm == 0, 1.0, col_norm)
        W = W / col_norm
        beta = 0.7 * (n_out ** (1.0 / n_in))
        W = beta * W
        b = self.rng.uniform(-beta, beta, size=(n_out,))
        return W.astype(np.float64), b.astype(np.float64)

    def pack(self) -> np.ndarray:
        return np.concatenate([
            self.W1.ravel(), self.b1.ravel(),
            self.W2.ravel(), self.b2.ravel(),
            self.W3.ravel(), self.b3.ravel(),
        ]).astype(np.float64)

    def unpack(self, w: np.ndarray) -> None:
        w = np.asarray(w, dtype=np.float64).ravel()
        i = 0
        s = self.W1.size
        self.W1 = w[i:i+s].reshape(self.W1.shape); i += s
        s = self.b1.size
        self.b1 = w[i:i+s].reshape(self.b1.shape); i += s
        s = self.W2.size
        self.W2 = w[i:i+s].reshape(self.W2.shape); i += s
        s = self.b2.size
        self.b2 = w[i:i+s].reshape(self.b2.shape); i += s
        s = self.W3.size
        self.W3 = w[i:i+s].reshape(self.W3.shape); i += s
        s = self.b3.size
        self.b3 = w[i:i+s].reshape(self.b3.shape); i += s
        if i != w.size:
            raise ValueError("Unpack size mismatch.")

    def forward(self, X: np.ndarray) -> Tuple[np.ndarray, Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
        X = np.asarray(X, dtype=np.float64)
        z1 = X @ self.W1 + self.b1
        a1 = tansig(z1)
        z2 = a1 @ self.W2 + self.b2
        a2 = tansig(z2)
        Y = a2 @ self.W3 + self.b3
        cache = (a1, a2, z1, z2)
        return Y, cache

    def loss_and_grad(self, w: np.ndarray, X: np.ndarray, Ytrue: np.ndarray) -> Tuple[float, np.ndarray]:
        # Set weights
        self.unpack(w)

        Ypred, (a1, a2, z1, z2) = self.forward(X)
        Ytrue = np.asarray(Ytrue, dtype=np.float64)

        N = X.shape[0]
        err = (Ypred - Ytrue)
        loss = np.mean(err * err)  # MATLAB mse = mean(e(:).^2)

        dY = (2.0 * err) / (N * self.output_dim)  # derivative of mean(err^2) over all elements

        gW3 = a2.T @ dY
        gb3 = dY.sum(axis=0)

        da2 = dY @ self.W3.T
        dz2 = da2 * dtansig_from_act(a2)

        gW2 = a1.T @ dz2
        gb2 = dz2.sum(axis=0)

        da1 = dz2 @ self.W2.T
        dz1 = da1 * dtansig_from_act(a1)

        gW1 = X.T @ dz1
        gb1 = dz1.sum(axis=0)

        grad = np.concatenate([
            gW1.ravel(), gb1.ravel(),
            gW2.ravel(), gb2.ravel(),
            gW3.ravel(), gb3.ravel(),
        ]).astype(np.float64)

        return float(loss), grad

    def fit_scg(self, X: np.ndarray, Y: np.ndarray, *, epochs: int, verbose: bool = True) -> None:
        """
        Scaled Conjugate Gradient (SCG) optimizer, closely following the classic
        Netlab/Møller formulation and MATLAB's trainscg behavior.

        This is full-batch training (no mini-batches), which matches MATLAB fitnet+trainscg.
        """
        X = np.asarray(X, dtype=np.float64)
        Y = np.asarray(Y, dtype=np.float64)

        w = self.pack()
        f, g = self.loss_and_grad(w, X, Y)

        # trainscg-like defaults
        sigma0 = 5.0e-5
        lambd = 5.0e-7
        min_grad = 1.0e-6

        success = True
        n_success = 0

        d = -g
        mu = float(d @ g)  # should be negative for steepest descent

        if verbose:
            print(f"[SCG] init loss={f:.6e} |g|={np.linalg.norm(g):.3e} lambda={lambd:.3e}")

        for it in range(1, int(epochs) + 1):
            if success:
                kappa = float(d @ d)
                if kappa == 0.0:
                    if verbose:
                        print("[SCG] kappa=0, stopping.")
                    break

                sigma = sigma0 / math.sqrt(kappa)
                w_sigma = w + sigma * d
                _, g_sigma = self.loss_and_grad(w_sigma, X, Y)
                theta = float(d @ (g_sigma - g)) / sigma

            delta = theta + lambd * kappa
            if delta <= 0.0:
                # Make Hessian approximation positive definite
                delta = lambd * kappa
                lambd = lambd - theta / kappa

            alpha = -mu / delta
            w_new = w + alpha * d
            f_new, g_new = self.loss_and_grad(w_new, X, Y)

            # Comparison ratio (Netlab/Møller)
            Delta = float(2.0 * (f_new - f) / (alpha * mu))

            if Delta >= 0.0 and np.isfinite(f_new):
                # Successful step
                w_prev = w
                g_prev = g
                w = w_new
                f = f_new
                g = g_new
                success = True
                n_success += 1

                # Conjugate direction update (Polak-Ribiere variant used in SCG)
                if np.linalg.norm(g) < min_grad:
                    if verbose:
                        print(f"[SCG] stop at iter={it} (|g| < min_grad={min_grad}).")
                    break

                beta = float((g @ g) - (g @ g_prev)) / mu  # mu is d^T g_prev (negative)
                d = beta * d - g
                mu = float(d @ g)

                # If direction not a descent direction, reset to steepest descent
                if mu >= 0.0:
                    d = -g
                    mu = float(d @ g)

                if verbose and (it == 1 or it % 25 == 0):
                    print(f"[SCG] iter={it:4d} loss={f:.6e} Delta={Delta:.3e} lambda={lambd:.3e} |g|={np.linalg.norm(g):.3e}")

            else:
                # Unsuccessful step: increase lambda and retry with same direction
                success = False

            # Lambda adaptation
            if Delta < 0.25:
                lambd *= 4.0
            elif Delta > 0.75:
                lambd *= 0.5

            # If too many successful steps, occasionally reset direction
            if success and (n_success % (self.pack().size) == 0):
                d = -g
                mu = float(d @ g)

        self.unpack(w)

    def predict(self, X: np.ndarray) -> np.ndarray:
        Y, _ = self.forward(X)
        return Y


# =========================
#    Data aggregation
# =========================

def load_one_day(mat_path: Union[str, Path]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load one day .mat, returning:
      features: [nTrials x nBins x nCh]
      labels  : [nTrials x nBins x 2]
    """
    S = load_mat_compat(mat_path)
    if "features" not in S or "labels" not in S:
        raise KeyError(f"Missing 'features' or 'labels' in {mat_path}")
    feats = np.asarray(S["features"], dtype=np.float64)
    labs = np.asarray(S["labels"], dtype=np.float64)

    # If the MAT loader yields transposed dims (rare), try to fix automatically:
    # Expect feats.ndim==3 and labs.ndim==3 with last dim 2
    if feats.ndim != 3:
        raise ValueError(f"features must be 3D. Got {feats.shape}")
    if labs.ndim != 3 or labs.shape[-1] != 2:
        raise ValueError(f"labels must be [nTrials,nBins,2]. Got {labs.shape}")

    return feats, labs


def collect_train_arrays(file_paths: Sequence[Path]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Aggregate multiple days into:
      Y_trials: [sumTrials x nBins x nCh]
      Ymat    : [N x 2] where N = sumTrials*nBins
    """
    Y_trials_list: List[np.ndarray] = []
    Ymat_list: List[np.ndarray] = []

    for p in file_paths:
        feats, labs = load_one_day(p)
        Y_trials_list.append(feats)
        Ymat_list.append(labels_to_matrix(labs))  # (N_day,2)

    Y_trials = np.concatenate(Y_trials_list, axis=0) if Y_trials_list else np.zeros((0, 0, 0))
    Ymat = np.concatenate(Ymat_list, axis=0) if Ymat_list else np.zeros((0, 2))
    return Y_trials, Ymat


# =========================
#          Main
# =========================

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Jango stabilization + MLP regression (Python port)")
    p.add_argument("--data-dir", type=str, default=r"D:\研究生\组\MANA\stabilizedbci-master\data\Jango-test",
                   help="Folder containing Jango_*.mat")
    p.add_argument("--out-dir", type=str, default="outputs_stabilization_mlp_regression",
                   help="Output folder.")
    p.add_argument("--seed", type=int, default=RNG_SEED, help="Random seed (default 44, MATLAB).")
    p.add_argument("--quiet", action="store_true", help="Reduce printing.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed)

    data_dir = Path(args.data_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # List files and dates
    files = sorted(data_dir.glob("Jango_*.mat"))
    if not files:
        raise FileNotFoundError(f"No Jango_*.mat files found in: {data_dir}")

    file_dates = [parse_date_from_file(f.name) for f in files]
    # Sort by date
    order = np.argsort([d.toordinal() for d in file_dates])
    files = [files[i] for i in order]
    file_dates = [file_dates[i] for i in order]

    date_to_files: Dict[date, List[Path]] = {}
    for f, d in zip(files, file_dates):
        date_to_files.setdefault(d, []).append(f)

    # Prepare fold dates
    fold_train_dates: List[List[date]] = []
    fold_test_dates: List[date] = []
    for train_list, test_list in FOLDS:
        train_dates = [datetime.strptime(s, "%Y%m%d").date() for s in train_list]
        test_dates = [datetime.strptime(s, "%Y%m%d").date() for s in test_list]
        fold_train_dates.append(train_dates)
        fold_test_dates.append(test_dates[0])  # MATLAB: only first day used for eval

    results_rows: List[Tuple[str, int, float, float, float]] = []
    aligned_features: List[np.ndarray] = []
    aligned_dates: List[str] = []

    verbose = not args.quiet

    for td, test_d in enumerate(fold_test_dates, start=1):
        # Build training file list from specified dates (MATLAB ismember)
        train_file_paths: List[Path] = []
        missing_train: List[str] = []
        for d in fold_train_dates[td-1]:
            if d in date_to_files:
                # include all sessions/files for that date
                train_file_paths.extend(date_to_files[d])
            else:
                missing_train.append(date_str(d))

        if missing_train and verbose:
            print(f"[WARN] Fold {td}: missing train days in directory: {', '.join(missing_train)}")

        # Test day file(s)
        if test_d not in date_to_files:
            if verbose:
                print(f"[WARN] Fold {td}: test day {date_str(test_d)} missing; skipping.")
            continue
        test_file = date_to_files[test_d][0]  # MATLAB picks the file matched; choose first if multiple.

        if verbose:
            print(f"\n===== Fold {td:02d} | Test day {test_d.isoformat()} =====")

        # 1) Fit base stabilizer on aggregated training set
        Y_train_trials, Y_train_mat = collect_train_arrays(train_file_paths)
        if Y_train_trials.size == 0:
            if verbose:
                print(f"[WARN] Fold {td}: empty training set; skipping.")
            continue

        nTrials_train, nBins, nCh = Y_train_trials.shape
        if verbose:
            print(f"Train trials: {nTrials_train}, bins: {nBins}, ch: {nCh}, samples: {Y_train_mat.shape[0]}")

        baseFA = fit_base_stabilizer(
            Y_train_trials, N_LATENTS,
            n_fa_restarts=FA_N_RESTARTS,
            max_n_its=FA_MAX_ITS,
            ll_diff_thresh=FA_LL_DIFF_THRESH,
            min_priv_var=FA_MIN_PRIV_VAR,
            verbose=FA_VERBOSE and verbose,
        )
        betaBase, oBase = get_stabilization_matrices(baseFA)

        # 2) Training latents + z-score (fixed stats)
        L_train = apply_beta_o(betaBase, oBase, Y_train_trials)     # [nTrials,nBins,nLatents]
        X_train_lat = L_train.reshape(-1, N_LATENTS)                # [N, nLatents]
        X_train_z, muX, stdX = zscore_cols(X_train_lat)             # use training stats only

        Y_train = Y_train_mat  # [N,2]

        # 3) Train initial MLP regressor (trainscg)
        net = SCGMLPRegressor(input_dim=N_LATENTS, hidden=MLP_HIDDEN, output_dim=2, seed=args.seed)
        if verbose:
            print(f"Training MLP (SCG) epochs={TRAIN_EPOCHS} hidden={MLP_HIDDEN}")
        net.fit_scg(X_train_z, Y_train, epochs=TRAIN_EPOCHS, verbose=verbose)

        # 4) Load test day and split calib/eval
        feats_day, labels_day = load_one_day(test_file)
        nTrials_day = feats_day.shape[0]
        nCal = min(N_CAL_TRIALS_PER_TEST_DAY, nTrials_day)
        if nTrials_day <= nCal:
            if verbose:
                print(f"[WARN] Test day {date_str(test_d)} has <= {nCal} trials; skipping.")
            continue

        calib_feats = feats_day[:nCal, :, :]
        eval_feats = feats_day[nCal:, :, :]
        calib_labels = labels_day[:nCal, :, :]
        eval_labels = labels_day[nCal:, :, :]

        # Update stabilizer using calibration trials (aligned to base)
        updatedFA = update_stabilizer(
            baseFA, calib_feats,
            align_n=ALIGN_N,
            align_th=ALIGN_TH,
            n_fa_restarts=FA_N_RESTARTS,
            max_n_its=FA_MAX_ITS,
            ll_diff_thresh=FA_LL_DIFF_THRESH,
            min_priv_var=FA_MIN_PRIV_VAR,
            verbose=FA_VERBOSE and verbose,
        )
        betaUpd, oUpd = get_stabilization_matrices(updatedFA)

        # Optional fine-tuning using calib trials (continue weights)
        if FINE_TUNE:
            L_cal = apply_beta_o(betaUpd, oUpd, calib_feats)
            X_cal = L_cal.reshape(-1, N_LATENTS)
            X_cal_z = (X_cal - muX) / stdX
            Y_cal = labels_to_matrix(calib_labels)

            if verbose:
                print(f"Fine-tuning MLP epochs={FINE_TUNE_EPOCHS} (train+calib)")
            X_ft = np.vstack([X_train_z, X_cal_z])
            Y_ft = np.vstack([Y_train, Y_cal])
            net.fit_scg(X_ft, Y_ft, epochs=FINE_TUNE_EPOCHS, verbose=verbose)

        # Save aligned latents for the whole test day (per trial, preserve time bins)
        L_day = apply_beta_o(betaUpd, oUpd, feats_day)               # [nTrials,nBins,nLatents]
        latent_aligned = np.transpose(L_day, (2, 1, 0))             # [nLatents, nBins, nTrials]
        aligned_features.append(latent_aligned.astype(np.float32))
        aligned_dates.append(date_str(test_d))

        # 5) Evaluate on remaining trials with R²
        L_eval = apply_beta_o(betaUpd, oUpd, eval_feats)
        X_eval = L_eval.reshape(-1, N_LATENTS)
        X_eval_z = (X_eval - muX) / stdX
        Y_eval = labels_to_matrix(eval_labels)

        Y_hat = net.predict(X_eval_z)
        r2xy = r2_score_2d(Y_eval, Y_hat)
        r2avg = float(np.mean(r2xy))

        if verbose:
            print(f"R2_x={r2xy[0]:.4f}, R2_y={r2xy[1]:.4f}, R2_avg={r2avg:.4f} "
                  f"(test day {date_str(test_d)}, calib trials={nCal})")

        results_rows.append((date_str(test_d), int(nCal), float(r2xy[0]), float(r2xy[1]), float(r2avg)))

    # Save results
    if results_rows:
        # CSV
        csv_path = out_dir / "results_per_day.csv"
        with open(csv_path, "w", encoding="utf-8") as f:
            f.write("test_date,n_calib,R2_x,R2_y,R2_avg\n")
            for row in results_rows:
                f.write(f"{row[0]},{row[1]},{row[2]:.8f},{row[3]:.8f},{row[4]:.8f}\n")

        # MAT
        mat_path = out_dir / "results_stabilized_mlp_regression.mat"
        results_struct = {
            "per_day": np.array(results_rows, dtype=object)
        }
        savemat(mat_path, {"results": results_struct}, do_compression=True)

        if verbose:
            print("\n================= Summary (per test day) =================")
            for r in results_rows:
                print(f"{r[0]} | nCal={r[1]:2d} | R2_x={r[2]: .4f} R2_y={r[3]: .4f} R2_avg={r[4]: .4f}")
            print(f"\nSaved: {csv_path}")
            print(f"Saved: {mat_path}")
    else:
        if verbose:
            print("[WARN] No results to save (all folds skipped).")

    # Save aligned latent features
    aligned_mat_path = out_dir / "aligned_latent_features.mat"
    # IMPORTANT: avoid NumPy broadcasting errors for ragged shapes by forcing a 1-D object array.
    aligned_features_obj = np.empty((len(aligned_features),), dtype=object)
    for i, arr in enumerate(aligned_features):
        arr = np.asarray(arr)
        # Ensure 3D: [nLatents x T x nTrials]
        if arr.ndim == 2:
            arr = arr[:, :, None]
        aligned_features_obj[i] = arr
    aligned_dates_arr = np.array(aligned_dates, dtype=object)

    savemat(
        aligned_mat_path,
        {"aligned_features": aligned_features_obj, "aligned_dates": aligned_dates_arr},
        do_compression=True
    )
    if verbose:
        print(f"Saved aligned latents: {aligned_mat_path}")

    # Visualization: R² over test days
    if results_rows:
        dates_sorted = [datetime.strptime(r[0], "%Y%m%d").date() for r in results_rows]
        order = np.argsort([d.toordinal() for d in dates_sorted])
        x = np.arange(len(order))
        labels_x = [results_rows[i][0] for i in order]

        r2x = np.array([results_rows[i][2] for i in order], dtype=np.float64)
        r2y = np.array([results_rows[i][3] for i in order], dtype=np.float64)
        r2a = np.array([results_rows[i][4] for i in order], dtype=np.float64)

        fig = plt.figure(figsize=(12, 5))
        ax = fig.add_subplot(1, 1, 1)
        ax.plot(x, r2a, marker="o", linewidth=1.8, label="R2_avg")
        ax.plot(x, r2x, marker=".", linewidth=1.2, label="R2_x")
        ax.plot(x, r2y, marker=".", linewidth=1.2, label="R2_y")

        mean_a = float(np.mean(r2a[np.isfinite(r2a)]))
        ax.axhline(mean_a, linestyle="--", linewidth=1.5, label="mean(R2_avg)")

        ax.set_xticks(x)
        ax.set_xticklabels(labels_x, rotation=45, ha="right")
        ax.set_xlabel("Test day")
        ax.set_ylabel("R²")
        ax.set_title("Stabilized MLP regression performance per test day (dashed = mean of R2_avg)")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best")

        fig.tight_layout()
        fig_path = out_dir / "plot_r2_by_day.png"
        fig.savefig(fig_path, dpi=200)
        plt.close(fig)

        if verbose:
            print(f"Saved plot: {fig_path}")


if __name__ == "__main__":
    main()
