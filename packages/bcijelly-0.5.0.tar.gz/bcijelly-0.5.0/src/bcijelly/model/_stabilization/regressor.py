"""
Regression interface for stabilization + MLP decoding.
"""

from __future__ import annotations

import argparse
import copy
import math
import os
from pprint import pformat
from typing import Any, Sequence

import numpy as np
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        SCGMLPRegressor,
        apply_beta_o,
        ensure_output_dir,
        evaluate_regressor_predictions,
        fit_base_stabilizer,
        get_stabilization_matrices,
        labels_to_matrix,
        load_joblib,
        load_npz_regression,
        plot_regressor_diagnostics,
        resolve_align_n,
        resolve_baseline_ntrials,
        resolve_calib_ntrials,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        update_stabilizer,
        validate_dataset_regression,
        validate_device,
        zscore_cols,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        SCGMLPRegressor,
        apply_beta_o,
        ensure_output_dir,
        evaluate_regressor_predictions,
        fit_base_stabilizer,
        get_stabilization_matrices,
        labels_to_matrix,
        load_joblib,
        load_npz_regression,
        plot_regressor_diagnostics,
        resolve_align_n,
        resolve_baseline_ntrials,
        resolve_calib_ntrials,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        update_stabilizer,
        validate_dataset_regression,
        validate_device,
        zscore_cols,
    )


SUPPORTS_EXTERNAL_VAL = True
SUPPORTS_TRAIN_WITHOUT_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "regression"
PRIMARY_TEST_METRIC = "r2"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_arr = np.asarray(dataset[0])
    y_arr = np.asarray(dataset[1])
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        x_arr, y_arr = load_npz_regression(datapath)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
        x_arr, y_arr = validate_dataset_regression(x_arr, y_arr)
    return x_arr, y_arr


def _normalize_hidden_sizes(hidden_sizes: Sequence[int] | None) -> tuple[int, ...]:
    if hidden_sizes is None:
        return (128, 64)
    normalized = tuple(int(x) for x in hidden_sizes if int(x) > 0)
    if not normalized:
        raise ValueError("hidden_sizes must contain at least one positive integer.")
    return normalized


def _latents_to_regression_arrays(beta: np.ndarray, o: np.ndarray, x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    latents = apply_beta_o(beta, o, x).reshape(-1, beta.shape[0])
    targets = labels_to_matrix(y)
    return latents, targets


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 300,
    lr: float = 1e-3,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    baseline_ntrials: int = 100,
    n_latents: int = 10,
    hidden_sizes: Sequence[int] | None = (128, 64),
    fa_n_restarts: int = 5,
    fa_ll_thresh: float = 1e-5,
    fa_max_its: int = 100000,
    fa_min_priv_var: float = 0.1,
    align_th: float = 0.01,
    align_n: int = 60,
    fine_tune: bool = True,
    fine_tune_epochs: int = 100,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 0,
    verbose: bool = False,
) -> dict[str, Any]:
    del batch_size, lr, weight_decay, patience, val_ratio
    set_seed(seed)
    validate_device(device)

    x_all, y_all = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath")

    used_external_val = val_dataset is not None or bool(val_datapath)
    used_internal_val_split = False

    if used_external_val:
        fit_x, fit_y = x_all, y_all
        val_x, val_y = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath")
    else:
        fit_x, fit_y = x_all, y_all
        val_x, val_y = None, None

    baseline_n = resolve_baseline_ntrials(fit_x.shape[0], baseline_ntrials)
    hidden_layers = _normalize_hidden_sizes(hidden_sizes)
    base_fa = fit_base_stabilizer(
        fit_x[-baseline_n:],
        n_latents,
        n_fa_restarts=fa_n_restarts,
        max_n_its=fa_max_its,
        ll_diff_thresh=fa_ll_thresh,
        min_priv_var=fa_min_priv_var,
        verbose=False,
    )
    beta_base, o_base = get_stabilization_matrices(base_fa)

    x_train_lat, y_train = _latents_to_regression_arrays(beta_base, o_base, fit_x, fit_y)
    x_train_z, mu_x, std_x = zscore_cols(x_train_lat)
    net = SCGMLPRegressor(input_dim=n_latents, hidden=hidden_layers, output_dim=2, seed=seed)
    net.fit_scg(x_train_z, y_train, epochs=epochs, verbose=True)

    train_pred = net.predict(x_train_z)
    train_metrics = evaluate_regressor_predictions(y_train, train_pred)

    if used_external_val:
        assert val_x is not None and val_y is not None
        x_val_lat, y_val = _latents_to_regression_arrays(beta_base, o_base, val_x, val_y)
        x_val_z = (x_val_lat - mu_x) / std_x
        val_pred = net.predict(x_val_z)
        val_metrics = evaluate_regressor_predictions(y_val, val_pred)
        val_r2 = float(val_metrics["r2"])
        print(
            f"Training Summary | train_mse={train_metrics['mse']:.4f} | train_mae={train_metrics['mae']:.4f} | train_r2={train_metrics['r2']:.4f} | "
            f"val_mse={val_metrics['mse']:.4f} | val_mae={val_metrics['mae']:.4f} | val_r2={val_metrics['r2']:.4f}"
        )
    else:
        val_metrics = None
        val_r2 = float("nan")
        print(
            f"Training Summary | train_mse={train_metrics['mse']:.4f} | train_mae={train_metrics['mae']:.4f} | train_r2={train_metrics['r2']:.4f} | "
            f"val_r2=nan"
        )

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "metrics.csv")
    logger = CsvLogger(csv_path, task="reg")
    try:
        logger.log("train", train_metrics)
        if val_metrics is not None:
            logger.log("val", val_metrics)
    finally:
        logger.close()

    ckpt_path = os.path.join(run_dir, "best_model.joblib") if save_ckpt else None
    payload = {
        "model": net,
        "base_fa": base_fa,
        "beta_base": beta_base,
        "o_base": o_base,
        "mu_x": mu_x,
        "std_x": std_x,
        "align_n": resolve_align_n(fit_x.shape[2], align_n),
        "align_th": align_th,
        "fa_n_restarts": fa_n_restarts,
        "fa_ll_thresh": fa_ll_thresh,
        "fa_max_its": fa_max_its,
        "fa_min_priv_var": fa_min_priv_var,
        "fine_tune": bool(fine_tune),
        "fine_tune_epochs": int(fine_tune_epochs),
        "hidden_sizes": list(hidden_layers),
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if save_ckpt:
        save_joblib(ckpt_path, payload)

    plot_path = None
    if plot:
        plot_path = plot_regressor_diagnostics(base_fa, [], os.path.join(run_dir, "training_curve.png"))

    save_json(
        os.path.join(run_dir, "config.json"),
        {
            "task": "regression",
            "epochs": epochs,
            "seed": seed,
            "device": "cpu",
            "baseline_ntrials": baseline_n,
            "n_latents": n_latents,
            "hidden_sizes": list(hidden_layers),
            "fa_n_restarts": fa_n_restarts,
            "fa_ll_thresh": fa_ll_thresh,
            "fa_max_its": fa_max_its,
            "fa_min_priv_var": fa_min_priv_var,
            "align_th": align_th,
            "align_n": align_n,
            "fine_tune": fine_tune,
            "fine_tune_epochs": fine_tune_epochs,
            "plot_path": plot_path,
            "save_ckpt": save_ckpt,
            "used_external_val": used_external_val,
            "used_internal_val_split": used_internal_val_split,
            "has_validation": used_external_val,
        },
    )

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            **payload,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
        }
    )
    train_result = {
        "task": "regression_train",
        "train_r2": float(train_metrics["r2"]),
        "val_r2": val_r2,
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": "cpu",
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    calib_ratio: float = 0.2,
    min_calib_trials: int = 1,
    max_calib_trials: int | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained stabilization model found. Call train() before test().")

    test_x, test_y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    calib_n = resolve_calib_ntrials(test_x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
    calib_x, eval_x = test_x[:calib_n], test_x[calib_n:]
    calib_y, eval_y = test_y[:calib_n], test_y[calib_n:]

    updated_fa = update_stabilizer(
        _TRAIN_STATE["base_fa"],
        calib_x,
        align_n=_TRAIN_STATE["align_n"],
        align_th=_TRAIN_STATE["align_th"],
        n_fa_restarts=_TRAIN_STATE["fa_n_restarts"],
        max_n_its=_TRAIN_STATE["fa_max_its"],
        ll_diff_thresh=_TRAIN_STATE["fa_ll_thresh"],
        min_priv_var=_TRAIN_STATE["fa_min_priv_var"],
        verbose=False,
    )
    beta_new, o_new = get_stabilization_matrices(updated_fa)
    model = copy.deepcopy(_TRAIN_STATE["model"])

    if _TRAIN_STATE["fine_tune"]:
        x_cal_lat, y_cal = _latents_to_regression_arrays(beta_new, o_new, calib_x, calib_y)
        x_cal_z = (x_cal_lat - _TRAIN_STATE["mu_x"]) / _TRAIN_STATE["std_x"]
        model.fit_scg(x_cal_z, y_cal, epochs=_TRAIN_STATE["fine_tune_epochs"], verbose=False)

    x_eval_lat, y_eval = _latents_to_regression_arrays(beta_new, o_new, eval_x, eval_y)
    x_eval_z = (x_eval_lat - _TRAIN_STATE["mu_x"]) / _TRAIN_STATE["std_x"]
    pred = model.predict(x_eval_z)
    metrics = evaluate_regressor_predictions(y_eval, pred)
    print(
        f"Test Regression Metrics: MSE={metrics['mse']:.4f}, "
        f"MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}"
    )
    test_result = {
        "task": "regression_test",
        "mse": float(metrics["mse"]),
        "mae": float(metrics["mae"]),
        "r2": float(metrics["r2"]),
        "r2_x": float(metrics["r2_x"]),
        "r2_y": float(metrics["r2_y"]),
        "calib_ntrials": int(calib_n),
        "eval_ntrials": int(eval_x.shape[0]),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="stabilization regressor train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None)
    parser.add_argument("--val_datapath", type=str, default=None)
    parser.add_argument("--test_datapath", type=str, default=None)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--baseline_ntrials", type=int, default=100)
    parser.add_argument("--n_latents", type=int, default=10)
    parser.add_argument("--hidden_sizes", nargs="+", type=int, default=[128, 64])
    parser.add_argument("--fa_n_restarts", type=int, default=5)
    parser.add_argument("--fa_ll_thresh", type=float, default=1e-5)
    parser.add_argument("--fa_max_its", type=int, default=100000)
    parser.add_argument("--fa_min_priv_var", type=float, default=0.1)
    parser.add_argument("--align_th", type=float, default=0.01)
    parser.add_argument("--align_n", type=int, default=60)
    parser.add_argument("--fine_tune", action="store_true")
    parser.add_argument("--no_fine_tune", action="store_true")
    parser.add_argument("--fine_tune_epochs", type=int, default=100)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=0)
    parser.add_argument("--calib_ratio", type=float, default=0.2)
    parser.add_argument("--min_calib_trials", type=int, default=1)
    parser.add_argument("--max_calib_trials", type=int, default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    fine_tune = not args.no_fine_tune

    if args.train_datapath and not args.test_datapath:
        x_all, y_all = _resolve_input_dataset(None, args.train_datapath, "train_dataset", "train_datapath")
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            baseline_ntrials=args.baseline_ntrials,
            n_latents=args.n_latents,
            hidden_sizes=args.hidden_sizes,
            fa_n_restarts=args.fa_n_restarts,
            fa_ll_thresh=args.fa_ll_thresh,
            fa_max_its=args.fa_max_its,
            fa_min_priv_var=args.fa_min_priv_var,
            align_th=args.align_th,
            align_n=args.align_n,
            fine_tune=fine_tune,
            fine_tune_epochs=args.fine_tune_epochs,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(
            test_dataset=(test_x, test_y),
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            baseline_ntrials=args.baseline_ntrials,
            n_latents=args.n_latents,
            hidden_sizes=args.hidden_sizes,
            fa_n_restarts=args.fa_n_restarts,
            fa_ll_thresh=args.fa_ll_thresh,
            fa_max_its=args.fa_max_its,
            fa_min_priv_var=args.fa_min_priv_var,
            align_th=args.align_th,
            align_n=args.align_n,
            fine_tune=fine_tune,
            fine_tune_epochs=args.fine_tune_epochs,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(
            test_datapath=args.test_datapath if args.test_datapath else args.train_datapath,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
