from __future__ import annotations

import csv
import json
import os
import random
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import joblib
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    from .stabilization_mlp import (
        FAModel,
        apply_beta_o,
        fit_base_stabilizer,
        get_stabilization_matrices,
        pool_trials,
        update_stabilizer,
    )
    from .stabilization_mlp_regression import SCGMLPRegressor, labels_to_matrix, r2_score_2d, zscore_cols
except ImportError:
    from stabilization_mlp import (
        FAModel,
        apply_beta_o,
        fit_base_stabilizer,
        get_stabilization_matrices,
        pool_trials,
        update_stabilizer,
    )
    from stabilization_mlp_regression import SCGMLPRegressor, labels_to_matrix, r2_score_2d, zscore_cols


X_KEYS = ("features", "X", "x", "samples", "spike", "feature", "train_data")
CLS_Y_KEYS = ("discrete_labels", "labels", "y", "Y", "label", "targets", "target", "label_train")
REG_Y_KEYS = ("labels", "y", "Y", "targets", "target", "label")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def ensure_output_dir(output_dir: str, run_name: str | None = None) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved_run_name = run_name or f"run_{stamp}"
    run_dir = os.path.abspath(os.path.join(output_dir, resolved_run_name))
    os.makedirs(run_dir, exist_ok=True)
    return run_dir, resolved_run_name


def save_json(path: str, payload: dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def save_joblib(path: str, obj: Any) -> None:
    joblib.dump(obj, path)


def load_joblib(path: str) -> Any:
    return joblib.load(path)


def validate_device(device: str) -> str:
    normalized = str(device).lower()
    if normalized not in {"auto", "cpu"}:
        raise ValueError("stabilization is CPU-only; supported device values are 'auto' and 'cpu'.")
    return "cpu"


def _pick_key(files: list[str], candidates: tuple[str, ...]) -> str | None:
    return next((key for key in candidates if key in files), None)


def _reduce_class_labels(y: np.ndarray) -> np.ndarray:
    y_arr = np.asarray(y)
    if y_arr.ndim == 2 and y_arr.shape[1] == 1:
        y_arr = y_arr[:, 0]
    if y_arr.ndim == 2 and np.issubdtype(y_arr.dtype, np.integer):
        y_arr = np.asarray([np.bincount(row.astype(np.int64)).argmax() for row in y_arr], dtype=np.int64)
    return y_arr


def load_npz_classification(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")
    data = np.load(npz_path, allow_pickle=True)
    files = list(data.files)
    x_key = _pick_key(files, X_KEYS)
    y_key = _pick_key(files, CLS_Y_KEYS)
    if x_key is None or y_key is None:
        raise KeyError(f"Unable to infer classification keys from {npz_path}. Available keys: {files}")
    x = np.asarray(data[x_key])
    y = _reduce_class_labels(np.asarray(data[y_key]))
    return validate_dataset_classification(x, y)


def load_npz_regression(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")
    data = np.load(npz_path, allow_pickle=True)
    files = list(data.files)
    x_key = _pick_key(files, X_KEYS)
    y_key = _pick_key(files, REG_Y_KEYS)
    if x_key is None or y_key is None:
        raise KeyError(f"Unable to infer regression keys from {npz_path}. Available keys: {files}")
    x = np.asarray(data[x_key])
    y = np.asarray(data[y_key])
    return validate_dataset_regression(x, y)


def validate_dataset_classification(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_arr = np.asarray(x, dtype=np.float64)
    y_arr = _reduce_class_labels(np.asarray(y))
    if x_arr.ndim != 3:
        raise ValueError(f"Classification X must have shape (N,T,C), got {x_arr.shape}")
    if y_arr.ndim != 1:
        raise ValueError(f"Classification y must have shape (N,), got {y_arr.shape}")
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x_arr.shape[0]}, y has {y_arr.shape[0]}")
    return x_arr, y_arr


def validate_dataset_regression(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_arr = np.asarray(x, dtype=np.float64)
    y_arr = np.asarray(y, dtype=np.float64)
    if x_arr.ndim != 3:
        raise ValueError(f"Regression X must have shape (N,T,C), got {x_arr.shape}")
    if y_arr.ndim != 3 or y_arr.shape[-1] != 2:
        raise ValueError(f"Regression y must have shape (N,T,2), got {y_arr.shape}")
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x_arr.shape[0]}, y has {y_arr.shape[0]}")
    if x_arr.shape[1] != y_arr.shape[1]:
        raise ValueError(f"Mismatched time dimension: X has {x_arr.shape[1]}, y has {y_arr.shape[1]}")
    return x_arr, y_arr


def encode_labels(y: np.ndarray) -> tuple[np.ndarray, dict[Any, int], list[Any]]:
    cleaned: list[Any] = []
    for item in np.asarray(y, dtype=object):
        label = item.reshape(-1)[0] if isinstance(item, np.ndarray) and item.size == 1 else item
        if isinstance(label, (bytes, bytearray)):
            label = label.decode("utf-8", errors="ignore")
        cleaned.append(label)
    classes, encoded = np.unique(np.asarray(cleaned, dtype=object), return_inverse=True)
    class_list = classes.tolist()
    return encoded.astype(np.int64), {cls: idx for idx, cls in enumerate(class_list)}, class_list


def encode_labels_with_classes(y: np.ndarray, classes: list[Any]) -> np.ndarray:
    mapping = {cls: idx for idx, cls in enumerate(classes)}
    encoded: list[int] = []
    for item in np.asarray(y, dtype=object):
        label = item.reshape(-1)[0] if isinstance(item, np.ndarray) and item.size == 1 else item
        if isinstance(label, (bytes, bytearray)):
            label = label.decode("utf-8", errors="ignore")
        if label not in mapping:
            raise ValueError(f"Label '{label}' not found in training label set: {classes}")
        encoded.append(mapping[label])
    return np.asarray(encoded, dtype=np.int64)


def split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    *,
    seed: int,
    val_ratio: float,
    task: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if task == "cls":
        stratify = y if len(np.unique(y)) > 1 else None
    else:
        stratify = None
    return train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )


def resolve_baseline_ntrials(n_train: int, baseline_ntrials: int) -> int:
    if n_train < 2:
        raise ValueError("Training set must contain at least 2 trials.")
    return max(1, min(int(baseline_ntrials), int(n_train)))


def resolve_align_n(n_channels: int, align_n: int) -> int:
    return max(1, min(int(align_n), int(n_channels)))


def resolve_calib_ntrials(
    n_test: int,
    calib_ratio: float,
    min_calib_trials: int = 1,
    max_calib_trials: int | None = None,
) -> int:
    if n_test < 2:
        raise ValueError("Test set must contain at least 2 trials.")
    if not (0.0 <= calib_ratio < 1.0):
        raise ValueError(f"calib_ratio must be in [0,1), got {calib_ratio}")
    calib_n = int(np.floor(n_test * calib_ratio))
    calib_n = max(int(min_calib_trials), calib_n)
    if max_calib_trials is not None:
        calib_n = min(calib_n, int(max_calib_trials))
    calib_n = min(calib_n, n_test - 1)
    if calib_n <= 0:
        raise ValueError(f"Resolved calib_ntrials={calib_n} is invalid for n_test={n_test}")
    return int(calib_n)


def fit_classifier_head(
    x_train: np.ndarray,
    y_train: np.ndarray,
    *,
    seed: int,
    hidden_size: int,
    batch_size: int,
    epochs: int,
    lr: float,
    weight_decay: float,
    verbose: bool,
) -> Pipeline:
    clf = MLPClassifier(
        hidden_layer_sizes=(int(hidden_size),),
        activation="relu",
        solver="adam",
        learning_rate_init=float(lr),
        alpha=float(weight_decay),
        batch_size=int(batch_size),
        max_iter=int(epochs),
        random_state=int(seed),
        verbose=bool(verbose),
    )
    pipe = Pipeline(
        [
            ("scaler", StandardScaler(with_mean=True, with_std=True)),
            ("mlp", clf),
        ]
    )
    pipe.fit(x_train, y_train)
    return pipe


def evaluate_classifier_head(model: Pipeline, x_eval: np.ndarray, y_eval: np.ndarray) -> dict[str, Any]:
    pred = model.predict(x_eval)
    labels = np.unique(np.concatenate([np.asarray(y_eval).reshape(-1), np.asarray(pred).reshape(-1)]))
    return {
        "acc": float(accuracy_score(y_eval, pred)),
        "confusion_matrix": confusion_matrix(y_eval, pred, labels=labels).tolist(),
    }


def evaluate_regressor_predictions(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    mse = float(mean_squared_error(y_true, y_pred))
    mae = float(mean_absolute_error(y_true, y_pred))
    r2xy = r2_score_2d(y_true, y_pred)
    return {
        "mse": mse,
        "mae": mae,
        "r2_x": float(r2xy[0]),
        "r2_y": float(r2xy[1]),
        "r2": float(np.mean(r2xy)),
    }


def plot_classifier_diagnostics(base_fa: FAModel, model: Pipeline, output_path: str) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), constrained_layout=True)
    ll = np.asarray(base_fa.diags.get("ll", []), dtype=float)
    axes[0].plot(np.arange(1, ll.size + 1), ll, linewidth=1.8)
    axes[0].set_title("Base FA Log-Likelihood")
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Log-likelihood")
    loss_curve = np.asarray(model.named_steps["mlp"].loss_curve_, dtype=float)
    axes[1].plot(np.arange(1, loss_curve.size + 1), loss_curve, linewidth=1.8)
    axes[1].set_title("MLP Loss Curve")
    axes[1].set_xlabel("Iteration")
    axes[1].set_ylabel("Loss")
    fig.savefig(output_path, dpi=180)
    plt.close(fig)
    return output_path


def plot_regressor_diagnostics(base_fa: FAModel, loss_history: list[float], output_path: str) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), constrained_layout=True)
    ll = np.asarray(base_fa.diags.get("ll", []), dtype=float)
    axes[0].plot(np.arange(1, ll.size + 1), ll, linewidth=1.8)
    axes[0].set_title("Base FA Log-Likelihood")
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Log-likelihood")
    loss_arr = np.asarray(loss_history, dtype=float)
    axes[1].plot(np.arange(1, loss_arr.size + 1), loss_arr, linewidth=1.8)
    axes[1].set_title("SCG Loss Curve")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    fig.savefig(output_path, dpi=180)
    plt.close(fig)
    return output_path


@dataclass
class CsvLogger:
    path: str | None
    task: str
    file_obj: Any = None
    writer: Any = None

    def __post_init__(self) -> None:
        if not self.path:
            return
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file_obj)
        if self.task == "cls":
            self.writer.writerow(["split", "acc"])
        else:
            self.writer.writerow(["split", "mse", "mae", "r2", "r2_x", "r2_y"])

    def log(self, split: str, metrics: dict[str, Any]) -> None:
        if not self.writer:
            return
        if self.task == "cls":
            self.writer.writerow([split, metrics.get("acc")])
        else:
            self.writer.writerow(
                [
                    split,
                    metrics.get("mse"),
                    metrics.get("mae"),
                    metrics.get("r2"),
                    metrics.get("r2_x"),
                    metrics.get("r2_y"),
                ]
            )
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()
