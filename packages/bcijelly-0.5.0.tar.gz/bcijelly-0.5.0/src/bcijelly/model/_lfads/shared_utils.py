from __future__ import annotations

import csv
import json
import os
import random
import shutil
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import h5py
import joblib
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import accuracy_score, confusion_matrix, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_output_dir(output_dir: str, run_name: str | None = None) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved_run_name = run_name or f"run_{stamp}"
    run_dir = os.path.abspath(os.path.join(output_dir, resolved_run_name))
    os.makedirs(run_dir, exist_ok=True)
    return run_dir, resolved_run_name


def load_npz_dataset(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")
    data = np.load(npz_path, allow_pickle=True)
    files = list(data.files)
    x_candidates = ("X", "x", "features", "feature", "spike", "samples", "train_data")
    y_candidates = ("discrete_labels", "y", "Y", "labels", "label", "targets", "target", "label_train")
    x_key = next((key for key in x_candidates if key in files), None)
    y_key = next((key for key in y_candidates if key in files), None)
    if x_key is None or y_key is None:
        raise KeyError(f"Unable to infer X/y from {npz_path}. Available keys: {files}.")
    return np.asarray(data[x_key]), np.asarray(data[y_key])


def validate_dataset_classification(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_arr = np.asarray(x, dtype=np.float32)
    y_arr = np.asarray(y)
    if x_arr.ndim != 3:
        raise ValueError(f"Classification X must have shape (N,T,C), got {x_arr.shape}")
    if y_arr.ndim == 2 and y_arr.shape[1] == 1:
        y_arr = y_arr[:, 0]
    if y_arr.ndim == 2 and np.issubdtype(y_arr.dtype, np.integer):
        y_arr = np.asarray([np.bincount(row.astype(np.int64)).argmax() for row in y_arr], dtype=np.int64)
    if y_arr.ndim != 1:
        raise ValueError(f"Classification y must have shape (N,), got {y_arr.shape}")
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x_arr.shape[0]}, y has {y_arr.shape[0]}")
    return x_arr, y_arr


def validate_dataset_regression(x: np.ndarray, y: np.ndarray, reduce: str = "center") -> tuple[np.ndarray, np.ndarray]:
    x_arr = np.asarray(x, dtype=np.float32)
    y_arr = np.asarray(y)
    if x_arr.ndim != 3:
        raise ValueError(f"Regression X must have shape (N,T,C), got {x_arr.shape}")
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x_arr.shape[0]}, y has {y_arr.shape[0]}")
    if y_arr.ndim == 3:
        if reduce == "mean":
            y_eval = y_arr.mean(axis=1)
        else:
            y_eval = y_arr[:, y_arr.shape[1] // 2, :]
    elif y_arr.ndim == 2:
        if np.issubdtype(y_arr.dtype, np.integer):
            raise ValueError("Integer regression targets look like classification labels.")
        if reduce == "mean":
            y_eval = y_arr.mean(axis=1, keepdims=True)
        else:
            y_eval = y_arr[:, y_arr.shape[1] // 2 : y_arr.shape[1] // 2 + 1]
    else:
        raise ValueError(f"Regression y must have shape (N,T,D) or (N,T), got {y_arr.shape}")
    return x_arr, np.asarray(y_eval, dtype=np.float32)


def encode_labels(y: np.ndarray) -> tuple[np.ndarray, dict[Any, int], list[Any]]:
    cleaned = []
    for value in np.asarray(y, dtype=object):
        if isinstance(value, np.ndarray) and value.size == 1:
            value = value.reshape(-1)[0]
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8", errors="ignore")
        cleaned.append(value)
    classes, inv = np.unique(np.asarray(cleaned, dtype=object), return_inverse=True)
    mapping = {cls: idx for idx, cls in enumerate(classes.tolist())}
    return inv.astype(np.int64), mapping, classes.tolist()


def encode_labels_with_classes(y: np.ndarray, classes: list[Any]) -> np.ndarray:
    class_to_id = {cls: idx for idx, cls in enumerate(classes)}
    encoded: list[int] = []
    for value in np.asarray(y, dtype=object):
        if isinstance(value, np.ndarray) and value.size == 1:
            value = value.reshape(-1)[0]
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8", errors="ignore")
        if value not in class_to_id:
            raise ValueError(f"Label '{value}' not found in training label set: {classes}")
        encoded.append(class_to_id[value])
    return np.asarray(encoded, dtype=np.int64)


def split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    val_ratio: float,
    task: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    stratify = y if task == "cls" and len(np.unique(y)) > 1 else None
    return train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )


def write_lfads_h5(
    path: str,
    train_x: np.ndarray,
    valid_x: np.ndarray,
    test_x: np.ndarray | None = None,
    train_behavior: np.ndarray | None = None,
    valid_behavior: np.ndarray | None = None,
    test_behavior: np.ndarray | None = None,
) -> None:
    with h5py.File(path, "w") as handle:
        handle.create_dataset("train_encod_data", data=train_x)
        handle.create_dataset("train_recon_data", data=train_x)
        handle.create_dataset("valid_encod_data", data=valid_x)
        handle.create_dataset("valid_recon_data", data=valid_x)
        if test_x is not None:
            handle.create_dataset("test_encod_data", data=test_x)
        if train_behavior is not None:
            handle.create_dataset("train_behavior", data=train_behavior)
        if valid_behavior is not None:
            handle.create_dataset("valid_behavior", data=valid_behavior)
        if test_behavior is not None:
            handle.create_dataset("test_behavior", data=test_behavior)


def load_factor_features(h5_path: str, split: str) -> np.ndarray:
    with h5py.File(h5_path, "r") as handle:
        key = f"{split}_factors"
        if key not in handle:
            raise KeyError(f"Missing factors key '{key}' in {h5_path}")
        factors = np.asarray(handle[key])
    if factors.ndim != 3:
        raise ValueError(f"Expected factors to have shape (N,T,F), got {factors.shape}")
    return factors.reshape(factors.shape[0], -1).astype(np.float32, copy=False)


def make_checkpoint_dir(run_dir: str, save_ckpt: bool) -> tuple[str, bool]:
    if save_ckpt:
        ckpt_dir = os.path.join(run_dir, "lfads_run", "lightning_checkpoints")
        os.makedirs(ckpt_dir, exist_ok=True)
        return ckpt_dir, False
    temp_dir = os.path.join(run_dir, "_tmp_lightning_checkpoints")
    os.makedirs(temp_dir, exist_ok=True)
    return temp_dir, True


def cleanup_path(path: str | None) -> None:
    if not path:
        return
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    elif os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass


def plot_lfads_training_csv(csv_path: str, output_path: str) -> str | None:
    if not os.path.exists(csv_path):
        return None

    epochs: dict[int, dict[str, float]] = {}
    with open(csv_path, "r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            epoch_raw = row.get("epoch") or row.get("cur_epoch")
            if epoch_raw in (None, ""):
                continue
            try:
                epoch = int(float(epoch_raw))
            except ValueError:
                continue
            bucket = epochs.setdefault(epoch, {})
            for key in ("train/loss", "valid/loss", "train/recon", "valid/recon", "valid/recon_smth"):
                value = row.get(key)
                if value not in (None, ""):
                    try:
                        bucket[key] = float(value)
                    except ValueError:
                        continue

    if not epochs:
        return None

    xs = sorted(epochs)
    train_loss = [epochs[e].get("train/loss", np.nan) for e in xs]
    valid_loss = [epochs[e].get("valid/loss", np.nan) for e in xs]
    valid_smth = [epochs[e].get("valid/recon_smth", np.nan) for e in xs]

    plt.figure(figsize=(7, 4.5))
    plt.plot(xs, train_loss, label="train/loss", linewidth=2.0)
    plt.plot(xs, valid_loss, label="valid/loss", linewidth=2.0)
    if not np.all(np.isnan(valid_smth)):
        plt.plot(xs, valid_smth, label="valid/recon_smth", linewidth=1.6, linestyle="--")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("LFADS Training Curve")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    return output_path


def fit_classifier_head(train_features: np.ndarray, train_labels: np.ndarray, seed: int) -> tuple[StandardScaler, LogisticRegression]:
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(train_features)
    clf = LogisticRegression(
        max_iter=1000,
        random_state=seed,
        multi_class="auto",
        solver="lbfgs",
    )
    clf.fit(x_scaled, train_labels)
    return scaler, clf


def evaluate_classifier_head(
    scaler: StandardScaler,
    clf: LogisticRegression,
    features: np.ndarray,
    labels: np.ndarray,
) -> dict[str, Any]:
    x_scaled = scaler.transform(features)
    pred = clf.predict(x_scaled)
    cm_labels = np.unique(np.concatenate([np.asarray(labels).reshape(-1), np.asarray(pred).reshape(-1)]))
    return {
        "acc": float(accuracy_score(labels, pred)),
        "confusion_matrix": confusion_matrix(labels, pred, labels=cm_labels).tolist(),
    }


def fit_regressor_head(train_features: np.ndarray, train_targets: np.ndarray) -> tuple[StandardScaler, Ridge]:
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(train_features)
    reg = Ridge(alpha=1.0)
    reg.fit(x_scaled, train_targets)
    return scaler, reg


def evaluate_regressor_head(
    scaler: StandardScaler,
    reg: Ridge,
    features: np.ndarray,
    targets: np.ndarray,
) -> dict[str, float]:
    x_scaled = scaler.transform(features)
    pred = reg.predict(x_scaled)
    return {
        "mse": float(mean_squared_error(targets, pred)),
        "mae": float(mean_absolute_error(targets, pred)),
        "r2": float(r2_score(targets, pred)),
    }


def save_joblib(path: str, obj: Any) -> None:
    joblib.dump(obj, path)


def load_joblib(path: str) -> Any:
    return joblib.load(path)


def save_json(path: str, payload: dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


@contextmanager
def pushd(path: str):
    prev = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(prev)


@dataclass
class CsvLogger:
    path: str | None
    task: str
    file_obj: Any = None
    writer: Any = None

    def __post_init__(self) -> None:
        if not self.path:
            return
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file_obj)
        if self.task == "cls":
            self.writer.writerow(["split", "acc"])
        else:
            self.writer.writerow(["split", "mse", "mae", "r2"])

    def log(self, split: str, metrics: dict[str, Any]) -> None:
        if not self.writer:
            return
        if self.task == "cls":
            self.writer.writerow([split, metrics.get("acc")])
        else:
            self.writer.writerow([split, metrics.get("mse"), metrics.get("mae"), metrics.get("r2")])
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()
