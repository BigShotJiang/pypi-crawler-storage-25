import logging
import os
import warnings
from glob import glob
from pathlib import Path

import hydra
import pytorch_lightning as pl
import torch
from hydra.utils import call, instantiate
from omegaconf import OmegaConf, open_dict

try:
    from ray import tune
except ImportError:  # Optional for single-run training/inference.
    tune = None

from .utils import flatten


def _format_override_value(value):
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, bool):
        return str(value).lower()
    return value


OmegaConf.register_new_resolver(
    "relpath", lambda p: str(Path(__file__).parent / ".." / p)
)
OmegaConf.register_new_resolver("max", lambda *args: max(args))
OmegaConf.register_new_resolver("sum", lambda *args: sum(args))


from .utils_autoconfig import register_autoconfig_resolvers
register_autoconfig_resolvers()  # 确保在任何地方调用 run_model 都有 resolver

def run_model(
    overrides: dict = {},
    checkpoint_dir: str = None,
    config_path: str = "../configs/single.yaml",
    do_train: bool = True,
    do_posterior_sample: bool = True,
    device: str = "auto",
):
    """Adds overrides to the default config, instantiates all PyTorch Lightning
    objects from config, and runs the training pipeline.
    """

    # Compose the train config with properly formatted overrides
    config_path = Path(config_path)
    overrides = [f"{k}={_format_override_value(v)}" for k, v in flatten(overrides).items()]
    with hydra.initialize(
        config_path=config_path.parent,
        job_name="run_model",
        version_base="1.1",
    ):
        config = hydra.compose(config_name=config_path.name, overrides=overrides)

    # Avoid flooding the console with output during multi-model runs
    if config.ignore_warnings:
        logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)
        warnings.filterwarnings("ignore")

    # Set seed for random number generators in pytorch, numpy and python.random
    if config.get("seed") is not None:
        pl.seed_everything(config.seed, workers=True)

    # Instantiate `LightningDataModule` and `LightningModule`
    datamodule = instantiate(config.datamodule, _convert_="all")
    model = instantiate(config.model)

    # If `checkpoint_dir` is passed, attempt to find the most recent checkpoint.
    # For a fresh training run the directory may be empty, which is valid.
    ckpt_path = None
    if checkpoint_dir:
        print(checkpoint_dir)
        ckpt_pattern = os.path.join(checkpoint_dir, "*.ckpt")
        ckpt_matches = glob(ckpt_pattern)
        if ckpt_matches:
            ckpt_path = max(ckpt_matches, key=os.path.getctime)

    if do_train:
        # If both ray.tune and wandb are being used, ensure that loggers use same name
        if "single" not in str(config_path) and "wandb_logger" in config.logger:
            if tune is None:
                raise ImportError("ray is required for non-single LFADS runs that use wandb trial naming.")
            with open_dict(config):
                config.logger.wandb_logger.name = tune.get_trial_name()
                config.logger.wandb_logger.id = tune.get_trial_name()
        # Instantiate the pytorch_lightning `Trainer` and its callbacks and loggers
        if device == "cpu":
            trainer_gpus = 0
        elif device == "auto":
            trainer_gpus = int(torch.cuda.is_available())
        else:
            # 先保守处理；如果后面要支持明确指定 cuda/cuda:0，再细化
            trainer_gpus = int(torch.cuda.is_available())

        trainer = instantiate(
            config.trainer,
            callbacks=[instantiate(c) for c in config.callbacks.values()],
            logger=[instantiate(lg) for lg in config.logger.values()],
            gpus=trainer_gpus,
        )
        # Temporary workaround for PTL step-resuming bug
        if ckpt_path:
            ckpt = torch.load(ckpt_path)
            trainer.fit_loop.epoch_loop._batches_that_stepped = ckpt["global_step"]
        # Train the model
        trainer.fit(
            model=model,
            datamodule=datamodule,
            ckpt_path=ckpt_path,
        )
        # Restore the best checkpoint if necessary - otherwise, use last checkpoint
        if config.posterior_sampling.use_best_ckpt:
            ckpt_path = trainer.checkpoint_callback.best_model_path
            if ckpt_path:
                model.load_state_dict(torch.load(ckpt_path, weights_only=False)["state_dict"])
    else:
        if not ckpt_path:
            raise FileNotFoundError(
                f"No checkpoint found in checkpoint_dir={checkpoint_dir!r} for inference run."
            )
        # If not training, restore model from the checkpoint
        model.load_state_dict(torch.load(ckpt_path)["state_dict"])

    # Run the posterior sampling function
    if do_posterior_sample:
        if device != "cpu" and torch.cuda.is_available():
            model = model.to("cuda")
        call(config.posterior_sampling.fn, model=model, datamodule=datamodule)
