from pathlib import Path
from omegaconf import OmegaConf
import numpy as np, torch, h5py

def _list_h5_datasets(f):
    out = {}
    def _walk(g, prefix=""):
        for k, v in g.items():
            name = f"{prefix}/{k}" if prefix else k
            if isinstance(v, h5py.Dataset):
                out["/" + name] = tuple(v.shape)
            elif isinstance(v, h5py.Group):
                _walk(v, name)
    _walk(f)
    return out

def _infer_specs(path, key=None):
    p = Path(path)
    if p.suffix == ".npz":
        arr = next(iter(np.load(p).values())); shape = arr.shape
    elif p.suffix == ".npy":
        arr = np.load(p, mmap_mode="r"); shape = arr.shape
    elif p.suffix in [".pt", ".pth"]:
        t = torch.load(p, map_location="cpu")
        arr = t if isinstance(t, torch.Tensor) else next(iter(t.values()))
        shape = tuple(arr.shape)
    elif p.suffix in [".h5", ".hdf5", ".mat"]:
        with h5py.File(p, "r") as f:
            if key is None:
                # 默认用 /train_encod_data；如不存在，挑一个 ndim>=2 的最大数据集
                if "/train_encod_data" in f:
                    ds = f["/train_encod_data"]; shape = tuple(ds.shape)
                else:
                    shapes = _list_h5_datasets(f)
                    cand = {k: s for k, s in shapes.items() if len(s) >= 2}
                    if not cand:
                        raise ValueError(f"No 2D/3D dataset found in {p}. All={shapes}")
                    key = max(cand.items(), key=lambda kv: np.prod(kv[1]))[0]
                    shape = cand[key]
            else:
                if key not in f:
                    raise ValueError(f"h5_key '{key}' not found. Avail (head): "
                                     f"{list(_list_h5_datasets(f).keys())[:10]} ...")
                ds = f[key]; shape = tuple(ds.shape)
    else:
        raise ValueError(f"Unsupported file type: {p.suffix}")

    if len(shape) == 3:
        _, T, C = shape
    elif len(shape) == 2:
        T, C = shape
    else:
        raise ValueError(f"Unexpected shape: {shape}, expect [N,T,C] or [T,C]")
    
    print(f"[infer_specs] file={p.name}, h5_key={key}, shape={shape} -> T={T}, C={C}")
    return int(C), int(T)

def register_autoconfig_resolvers():
    OmegaConf.register_new_resolver(
        "infer_dim", lambda path, key=None: _infer_specs(path, key)[0], replace=True
    )
    OmegaConf.register_new_resolver(
        "infer_T",   lambda path, key=None: _infer_specs(path, key)[1], replace=True
    )
