"""
Regression interface for LFADS training/testing.

The external interface stays NPZ-based for consistency with the rest of this
project. LFADS itself still consumes an internal HDF5 file because the
upstream datamodule and posterior-sampling code are HDF5-native.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from pprint import pformat
from typing import Any

import numpy as np
from sklearn.model_selection import train_test_split

if __package__:
    from .lfads_torch.run_model import run_model
    from .shared_utils import (
        CsvLogger,
        cleanup_path,
        ensure_output_dir,
        evaluate_regressor_head,
        fit_regressor_head,
        load_factor_features,
        load_joblib,
        load_npz_dataset,
        make_checkpoint_dir,
        plot_lfads_training_csv,
        pushd,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        validate_dataset_regression,
        write_lfads_h5,
    )
else:
    from lfads_torch.run_model import run_model
    from shared_utils import (
        CsvLogger,
        cleanup_path,
        ensure_output_dir,
        evaluate_regressor_head,
        fit_regressor_head,
        load_factor_features,
        load_joblib,
        load_npz_dataset,
        make_checkpoint_dir,
        plot_lfads_training_csv,
        pushd,
        save_joblib,
        save_json,
        set_seed,
        split_train_val,
        validate_dataset_regression,
        write_lfads_h5,
    )


SUPPORTS_EXTERNAL_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "regression"
PRIMARY_TEST_METRIC = "r2"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_arr = np.asarray(dataset[0])
    y_arr = np.asarray(dataset[1])
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
    reduce: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        loaded = load_npz_dataset(datapath)
        x_arr, y_arr = _check_dataset_tuple_shape(loaded, dataset_name)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_regression(x_arr, y_arr, reduce=reduce)


def _run_lfads(
    h5_path: str,
    run_dir: str,
    checkpoint_dir: str | None,
    batch_size: int,
    epochs: int,
    seed: int,
    fac_dim: int,
    dropout_rate: float,
    lr_init: float,
    weight_decay: float,
    device: str,
    do_train: bool,
    save_ckpt: bool,
    patience: int,
) -> str:
    h5_path = Path(os.path.abspath(h5_path)).as_posix()
    run_dir = os.path.abspath(run_dir)
    if checkpoint_dir:
        checkpoint_dir = os.path.abspath(checkpoint_dir)
    overrides = {
        "data.path": h5_path,
        "datamodule.batch_size": batch_size,
        "trainer.max_epochs": epochs,
        "seed": seed,
        "model.fac_dim": fac_dim,
        "model.dropout_rate": dropout_rate,
        "model.lr_init": lr_init,
        "model.weight_decay": weight_decay,
        "callbacks.early_stopping.patience": patience,
    }
    if checkpoint_dir:
        overrides["callbacks.model_checkpoint.dirpath"] = Path(os.path.abspath(checkpoint_dir)).as_posix()
    if not save_ckpt:
        overrides["callbacks.model_checkpoint.save_last"] = False
    with pushd(run_dir):
        run_model(
            overrides=overrides,
            checkpoint_dir=checkpoint_dir,
            config_path="../configs/single.yaml",
            do_train=do_train,
            do_posterior_sample=True,
            device=device,
        )
    output_files = sorted(Path(run_dir).glob("lfads_output*.h5"))
    if not output_files:
        raise RuntimeError(f"LFADS did not create posterior output in {run_dir}")
    return str(output_files[0])


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 64,
    epochs: int = 50,
    lr: float = 4e-3,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    fac_dim: int = 40,
    dropout: float = 0.02,
    reduce: str = "center",
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 10,
    verbose: bool = False,
) -> dict[str, Any]:
    train_x_raw, train_y_raw = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath", reduce)
    used_external_val = val_dataset is not None or bool(val_datapath)
    used_internal_val_split = False
    if used_external_val:
        train_x, train_y = train_x_raw, train_y_raw
        val_x, val_y = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath", reduce)
    else:
        train_x, train_y = train_x_raw, train_y_raw
        val_x, val_y = train_x_raw, train_y_raw
    has_validation = bool(used_external_val)

    set_seed(seed)
    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    train_h5 = os.path.join(run_dir, "lfads_train.h5")
    write_lfads_h5(
        train_h5,
        train_x=train_x,
        valid_x=val_x,
        train_behavior=train_y,
        valid_behavior=val_y,
    )
    lfads_run_dir = os.path.join(run_dir, "lfads_run")
    os.makedirs(lfads_run_dir, exist_ok=True)
    ckpt_dir, ckpt_is_temp = make_checkpoint_dir(run_dir, save_ckpt)
    output_h5 = _run_lfads(
        h5_path=train_h5,
        run_dir=lfads_run_dir,
        checkpoint_dir=ckpt_dir,
        batch_size=batch_size,
        epochs=epochs,
        seed=seed,
        fac_dim=fac_dim,
        dropout_rate=dropout,
        lr_init=lr,
        weight_decay=weight_decay,
        device=device,
        do_train=True,
        save_ckpt=save_ckpt,
        patience=patience,
    )

    train_features = load_factor_features(output_h5, "train")
    val_features = load_factor_features(output_h5, "valid")
    scaler, regressor = fit_regressor_head(train_features, train_y)
    train_metrics = evaluate_regressor_head(scaler, regressor, train_features, train_y)
    metrics = evaluate_regressor_head(scaler, regressor, val_features, val_y)

    regressor_path = os.path.join(run_dir, "reg_head.joblib")
    save_joblib(regressor_path, {"scaler": scaler, "regressor": regressor})
    csv_path = log_csv if log_csv else os.path.join(run_dir, "metrics.csv")
    logger = CsvLogger(csv_path, task="reg")
    try:
        logger.log("val", metrics)
    finally:
        logger.close()

    lfads_metrics_csv = os.path.join(lfads_run_dir, "csv_logs", "metrics.csv")
    plot_path = None
    if plot:
        plot_path = plot_lfads_training_csv(lfads_metrics_csv, os.path.join(run_dir, "training_curve.png"))

    public_ckpt_path = ckpt_dir if save_ckpt else None

    save_json(
        os.path.join(run_dir, "config.json"),
        {
            "task": "regression",
            "batch_size": batch_size,
            "epochs": epochs,
            "lr": lr,
            "weight_decay": weight_decay,
            "seed": seed,
            "device": device,
            "fac_dim": fac_dim,
            "dropout": dropout,
            "val_ratio": val_ratio,
            "reduce": reduce,
            "patience": patience,
            "save_ckpt": save_ckpt,
            "plot": plot,
            "lfads_metrics_csv": lfads_metrics_csv,
            "plot_path": plot_path,
            "ckpt_path": public_ckpt_path,
        },
    )

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "checkpoint_dir": ckpt_dir,
            "regressor_path": regressor_path,
            "ckpt_is_temp": ckpt_is_temp,
            "train_x": train_x,
            "val_x": val_x,
            "batch_size": batch_size,
            "epochs": epochs,
            "lr": lr,
            "weight_decay": weight_decay,
            "seed": seed,
            "device": device,
            "fac_dim": fac_dim,
            "dropout": dropout,
            "patience": patience,
        }
    )

    train_result = {
        "task": "regression_train",
        "train_r2": float(train_metrics["r2"]),
        "train_mse": float(train_metrics["mse"]),
        "train_mae": float(train_metrics["mae"]),
        "val_r2": float(metrics["r2"]),
        "val_mse": float(metrics["mse"]),
        "val_mae": float(metrics["mae"]),
        "best_epoch": int(epochs),
        "csv_path": csv_path,
        "ckpt_path": public_ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(device),
        "used_external_val": bool(used_external_val),
        "used_internal_val_split": bool(used_internal_val_split),
        "has_validation": bool(has_validation),
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    reduce: str = "center",
    verbose: bool = False,
) -> dict[str, Any]:
    if "checkpoint_dir" not in _TRAIN_STATE:
        raise RuntimeError("No trained LFADS model found. Call train() before test().")

    test_x, test_y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath", reduce)
    payload = load_joblib(_TRAIN_STATE["regressor_path"])
    infer_dir = os.path.join(_TRAIN_STATE["run_dir"], "lfads_test")
    os.makedirs(infer_dir, exist_ok=True)
    infer_h5 = os.path.join(infer_dir, "lfads_test.h5")
    write_lfads_h5(
        infer_h5,
        train_x=_TRAIN_STATE["train_x"],
        valid_x=_TRAIN_STATE["val_x"],
        test_x=test_x,
    )
    output_h5 = _run_lfads(
        h5_path=infer_h5,
        run_dir=infer_dir,
        checkpoint_dir=_TRAIN_STATE["checkpoint_dir"],
        batch_size=_TRAIN_STATE["batch_size"],
        epochs=_TRAIN_STATE["epochs"],
        seed=_TRAIN_STATE["seed"],
        fac_dim=_TRAIN_STATE["fac_dim"],
        dropout_rate=_TRAIN_STATE["dropout"],
        lr_init=_TRAIN_STATE["lr"],
        weight_decay=_TRAIN_STATE["weight_decay"],
        device=_TRAIN_STATE["device"],
        do_train=False,
        save_ckpt=True,
        patience=_TRAIN_STATE["patience"],
    )
    test_features = load_factor_features(output_h5, "test")
    metrics = evaluate_regressor_head(payload["scaler"], payload["regressor"], test_features, test_y)
    if _TRAIN_STATE.get("ckpt_is_temp"):
        cleanup_path(_TRAIN_STATE.get("checkpoint_dir"))
    test_result = {"task": "regression_test", **metrics}
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LFADS regressor train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None)
    parser.add_argument("--val_datapath", type=str, default=None)
    parser.add_argument("--test_datapath", type=str, default=None)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=4e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--fac_dim", type=int, default=40)
    parser.add_argument("--dropout", type=float, default=0.02)
    parser.add_argument("--reduce", type=str, default="center", choices=["center", "mean"])
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=10)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    if args.train_datapath and not args.test_datapath:
        x_all, y_all = _resolve_input_dataset(None, args.train_datapath, "train_dataset", "train_datapath", args.reduce)
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            fac_dim=args.fac_dim,
            dropout=args.dropout,
            reduce=args.reduce,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_dataset=(test_x, test_y), reduce=args.reduce)
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            fac_dim=args.fac_dim,
            dropout=args.dropout,
            reduce=args.reduce,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_datapath=args.test_datapath if args.test_datapath else args.train_datapath, reduce=args.reduce)

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
