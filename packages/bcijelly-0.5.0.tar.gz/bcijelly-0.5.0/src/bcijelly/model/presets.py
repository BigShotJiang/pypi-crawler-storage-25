from __future__ import annotations

from typing import Any


MODULE_DEFAULTS: dict[str, dict[str, dict[str, dict[str, Any]]]] = {
    "classification": {
        "single_day": {
            "transformer": {"batch_size": 32, "epochs": 100, "lr": 1e-4, "weight_decay": 0.0, "device": "auto", "num_layers": 2, "d_model": 64, "n_heads": 4, "dropout": 0.1, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 20},
            "lstm": {"batch_size": 32, "epochs": 6, "lr": 1e-3, "weight_decay": 0.0, "device": "auto", "num_layers": 2, "hidden_size": 64, "dropout": 0.1, "bidirectional": True, "pooling": "mean", "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 20},
            "lfads": {"batch_size": 16, "epochs": 50, "lr": 4e-3, "weight_decay": 0.0, "device": "auto", "fac_dim": 40, "dropout": 0.02, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 10},
            "cycle_gan": {"batch_size": 32, "epochs": 400, "decoder_epochs": 100, "decoder_lr": 1e-3, "g_lr": 1e-3, "d_lr": 1e-2, "device": "auto", "source_ratio": 0.9, "generator_hidden": 0, "discriminator_hidden": 0, "dropout_decoder": 0.3, "dropout_g": 0.2, "dropout_d": 0.2, "identity_weight": 5.0, "cycle_weight": 5.0, "loss_type": "L1", "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 10, "calib_ratio": 0.1, "min_calib_trials": 5, "max_calib_trials": 30, "enable_alignment": False},
            "stabilization": {"batch_size": 32, "epochs": 300, "lr": 1e-3, "weight_decay": 1e-4, "device": "auto", "baseline_ntrials": 100, "n_latents": 36, "pooling": "flatten", "hidden_size": 512, "fa_n_restarts": 5, "fa_ll_thresh": 1e-5, "fa_max_its": 100000, "fa_min_priv_var": 1.0, "align_th": 0.1, "align_n": 150, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 0, "calib_ratio": 0.1, "min_calib_trials": 5, "max_calib_trials": 30, "enable_alignment": False},
        },
        "cross_day": {
            "transformer": {"batch_size": 32, "epochs": 60, "lr": 1e-4, "weight_decay": 1e-3, "device": "auto", "num_layers": 2, "d_model": 64, "n_heads": 4, "dropout": 0.3, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 15},
            "lstm": {"batch_size": 32, "epochs": 40, "lr": 5e-4, "weight_decay": 1e-4, "device": "auto", "num_layers": 2, "hidden_size": 64, "dropout": 0.2, "bidirectional": True, "pooling": "mean", "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 12},
            "lfads": {"batch_size": 64, "epochs": 50, "lr": 4e-3, "weight_decay": 0.0, "device": "auto", "fac_dim": 40, "dropout": 0.02, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 10},
            "cycle_gan": {"batch_size": 32, "epochs": 400, "decoder_epochs": 100, "decoder_lr": 1e-3, "g_lr": 1e-3, "d_lr": 1e-2, "device": "auto", "source_ratio": 0.9, "generator_hidden": 0, "discriminator_hidden": 0, "dropout_decoder": 0.3, "dropout_g": 0.2, "dropout_d": 0.2, "identity_weight": 5.0, "cycle_weight": 5.0, "loss_type": "L1", "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 10, "calib_ratio": 0.1, "min_calib_trials": 5, "max_calib_trials": 30, "enable_alignment": True},
            "stabilization": {"batch_size": 32, "epochs": 300, "lr": 1e-3, "weight_decay": 1e-4, "device": "auto", "baseline_ntrials": 100, "n_latents": 36, "pooling": "flatten", "hidden_size": 512, "fa_n_restarts": 5, "fa_ll_thresh": 1e-5, "fa_max_its": 100000, "fa_min_priv_var": 1.0, "align_th": 0.1, "align_n": 150, "save_ckpt": False, "plot": False, "val_ratio": 0.125, "patience": 0, "calib_ratio": 0.1, "min_calib_trials": 5, "max_calib_trials": 30, "enable_alignment": True},
        },
    },
    "speech": {
        "single_day": {
            "transformer": {"batch_size": 32, "epochs": 50, "lr": 3e-4, "weight_decay": 1e-4, "device": "auto", "num_layers": 4, "d_model": 256, "n_heads": 8, "dropout": 0.2, "kernel_len": 32, "stride_len": 4, "gaussian_smooth_width": 2.0, "save_ckpt": False, "plot": False, "val_ratio": 0.2, "patience": 10, "white_noise_sd": 0.2, "constant_offset_sd": 0.05, "use_day_idx": True},
            "lstm": {"batch_size": 32, "epochs": 50, "lr": 5e-4, "weight_decay": 1e-4, "device": "auto", "num_layers": 4, "hidden_size": 512, "dropout": 0.3, "bidirectional": True, "kernel_len": 32, "stride_len": 4, "gaussian_smooth_width": 2.0, "save_ckpt": False, "plot": False, "val_ratio": 0.2, "patience": 10, "white_noise_sd": 0.2, "constant_offset_sd": 0.05, "use_day_idx": True},
        },
    },
    # "regression": {
    #     "single_day": {
    #         "stabilization": {
    #             "batch_size": 32,
    #             "epochs": 300,
    #             "lr": 1e-3,
    #             "weight_decay": 0.0,
    #             "device": "auto",
    #             "baseline_ntrials": 100,
    #             "n_latents": 10,
    #             "hidden_sizes": (128, 64),
    #             "fa_n_restarts": 5,
    #             "fa_ll_thresh": 1e-5,
    #             "fa_max_its": 100000,
    #             "fa_min_priv_var": 0.1,
    #             "align_th": 0.01,
    #             "align_n": 60,
    #             "fine_tune": True,
    #             "fine_tune_epochs": 100,
    #             "save_ckpt": False,
    #             "plot": False,
    #             "val_ratio": 0.2,
    #             "patience": 0,
    #             "calib_ratio": 0.2,
    #             "min_calib_trials": 1,
    #             "max_calib_trials": None,
    #         },
    #     },
    #     "cross_day": {
    #         "stabilization": {
    #             "batch_size": 32,
    #             "epochs": 300,
    #             "lr": 1e-3,
    #             "weight_decay": 0.0,
    #             "device": "auto",
    #             "baseline_ntrials": 100,
    #             "n_latents": 10,
    #             "hidden_sizes": (128, 64),
    #             "fa_n_restarts": 5,
    #             "fa_ll_thresh": 1e-5,
    #             "fa_max_its": 100000,
    #             "fa_min_priv_var": 0.1,
    #             "align_th": 0.01,
    #             "align_n": 60,
    #             "fine_tune": True,
    #             "fine_tune_epochs": 100,
    #             "save_ckpt": False,
    #             "plot": False,
    #             "val_ratio": 0.2,
    #             "patience": 0,
    #             "calib_ratio": 0.2,
    #             "min_calib_trials": 1,
    #             "max_calib_trials": None,
    #         },
    #     },
    # },
}


QUICK_DEFAULTS: dict[str, dict[str, Any]] = {
    "transformer": {"epochs": 1},
    "lstm": {"epochs": 1},
    "lfads": {"epochs": 1},
    "cycle_gan": {"epochs": 1, "decoder_epochs": 4},
    "stabilization": {"epochs": 1, "fa_n_restarts": 1, "fa_max_its": 100},
}

def get_module_params(
    *,
    module_name: str,
    task: str,
    protocol: str,
    quick: bool = False,
    overrides: dict[str, Any] | None = None,
) -> dict[str, Any]:
    normalized_protocol = protocol
    if protocol in {"train-test", "train-val-test"}:
        normalized_protocol = "single_day"
    params = dict(
        MODULE_DEFAULTS.get(task, {}).get(normalized_protocol, {}).get(module_name, {})
    )
    if quick:
        params.update(QUICK_DEFAULTS.get(module_name, {}))
    if overrides:
        params.update(overrides)
    return params


__all__ = [
    "MODULE_DEFAULTS",
    "QUICK_DEFAULTS",
    "get_module_params",
]
