"""
Shared utilities for CycleGAN-based alignment wrappers.
"""

from __future__ import annotations

import csv
import os
import random
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score, confusion_matrix, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(device: str = "auto") -> torch.device:
    if device == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Requested device='cuda' but CUDA is not available.")
    return torch.device(device)


def ensure_output_dir(output_dir: str, run_name: str | None = None) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved_run_name = run_name or f"run_{stamp}"
    run_dir = os.path.join(output_dir, resolved_run_name)
    os.makedirs(run_dir, exist_ok=True)
    return run_dir, resolved_run_name


def load_npz_dataset(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")
    data = np.load(npz_path, allow_pickle=True)
    files = list(data.files)
    x_candidates = ("X", "x", "features", "feature", "spike", "samples", "train_data")
    y_candidates = ("y", "Y", "labels", "label", "targets", "target", "label_train", "discrete_labels")
    x_key = next((key for key in x_candidates if key in files), None)
    y_key = next((key for key in y_candidates if key in files), None)
    if x_key is None or y_key is None:
        raise KeyError(f"Unable to infer X/y from {npz_path}. Available keys: {files}.")
    return np.asarray(data[x_key]), np.asarray(data[y_key])


def validate_dataset_classification(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(x, np.ndarray) or x.ndim != 3:
        raise ValueError(f"Classification X must have shape (N,T,C), got {getattr(x, 'shape', None)}")
    y_arr = np.asarray(y)
    if y_arr.ndim == 2 and y_arr.shape[1] == 1:
        y_arr = y_arr[:, 0]
    if y_arr.ndim != 1:
        raise ValueError(f"Classification y must have shape (N,), got {y_arr.shape}")
    if x.shape[0] != y_arr.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x.shape[0]}, y has {y_arr.shape[0]}")
    return x.astype(np.float32, copy=False), y_arr


def validate_dataset_regression(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(x, np.ndarray) or x.ndim != 3:
        raise ValueError(f"Regression X must have shape (N,T,C), got {getattr(x, 'shape', None)}")
    y_arr = np.asarray(y)
    if y_arr.ndim != 3 or y_arr.shape[2] != 2:
        raise ValueError(f"Regression y must have shape (N,T,2), got {y_arr.shape}")
    if x.shape[0] != y_arr.shape[0] or x.shape[1] != y_arr.shape[1]:
        raise ValueError(f"Mismatched dataset shapes: X {x.shape}, y {y_arr.shape}")
    return x.astype(np.float32, copy=False), y_arr.astype(np.float32, copy=False)


def encode_labels(y: np.ndarray) -> tuple[np.ndarray, dict[Any, int], list[Any]]:
    cleaned = []
    for value in np.asarray(y, dtype=object):
        if isinstance(value, np.ndarray) and value.size == 1:
            value = value.reshape(-1)[0]
        if isinstance(value, (bytes, bytearray)):
            value = value.decode("utf-8", errors="ignore")
        cleaned.append(value)
    classes, inv = np.unique(np.asarray(cleaned, dtype=object), return_inverse=True)
    mapping = {cls: i for i, cls in enumerate(classes.tolist())}
    return inv.astype(np.int64), mapping, classes.tolist()


def split_ordered_trials(
    x: np.ndarray,
    y: np.ndarray,
    train_ratio: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not (0.0 < train_ratio < 1.0):
        raise ValueError(f"train_ratio must be in (0,1), got {train_ratio}")
    n_trials = int(x.shape[0])
    if n_trials < 2:
        raise ValueError("At least 2 trials are required for an ordered split.")
    train_n = int(np.floor(n_trials * train_ratio))
    train_n = min(max(train_n, 1), n_trials - 1)
    return x[:train_n], x[train_n:], y[:train_n], y[train_n:]


def split_source_target(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
    source_ratio: float = 0.5,
    stratify: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    return train_test_split(
        x,
        y,
        train_size=source_ratio,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )


def resolve_calib_ntrials(
    n_test: int,
    calib_ratio: float,
    min_calib_trials: int = 1,
    max_calib_trials: int | None = None,
) -> int:
    if n_test < 2:
        raise ValueError("Test set must contain at least 2 trials.")
    if not (0.0 <= calib_ratio < 1.0):
        raise ValueError(f"calib_ratio must be in [0,1), got {calib_ratio}")
    calib_n = int(np.floor(n_test * calib_ratio))
    calib_n = max(int(min_calib_trials), calib_n)
    if max_calib_trials is not None:
        calib_n = min(calib_n, int(max_calib_trials))
    calib_n = min(calib_n, n_test - 1)
    if calib_n <= 0:
        raise ValueError(f"Resolved calib_ntrials={calib_n} is invalid for n_test={n_test}")
    return int(calib_n)


def flatten_trials_for_classifier(x: np.ndarray) -> np.ndarray:
    return x.reshape(x.shape[0], -1).astype(np.float32, copy=False)


def flatten_trials_for_regressor(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_flat = x.reshape(x.shape[0] * x.shape[1], x.shape[2]).astype(np.float32, copy=False)
    y_flat = y.reshape(y.shape[0] * y.shape[1], y.shape[2]).astype(np.float32, copy=False)
    valid = ~np.all(y_flat == 0.0, axis=1)
    return x_flat[valid], y_flat[valid]


def as_domain_batches(x: np.ndarray, mode: str) -> list[np.ndarray]:
    return [trial.astype(np.float32, copy=False) for trial in x]


class MLPRegressor(nn.Module):
    def __init__(self, in_dim: int, hidden: list[int], out_dim: int = 2, dropout: float = 0.2) -> None:
        super().__init__()
        layers: list[nn.Module] = []
        prev = in_dim
        for width in hidden:
            layers.extend([nn.Linear(prev, width), nn.ReLU(), nn.LayerNorm(width), nn.Dropout(dropout)])
            prev = width
        layers.append(nn.Linear(prev, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class MLPClassifier(nn.Module):
    def __init__(self, in_dim: int, hidden: list[int], n_classes: int, dropout: float = 0.3) -> None:
        super().__init__()
        layers: list[nn.Module] = []
        prev = in_dim
        for width in hidden:
            layers.extend([nn.Linear(prev, width), nn.ReLU(), nn.LayerNorm(width), nn.Dropout(dropout)])
            prev = width
        layers.append(nn.Linear(prev, n_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class Generator(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float) -> None:
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Dropout(dropout),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Dropout(dropout),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
            nn.ReLU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)


class IdentityAligner(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x


class Discriminator(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, dropout: float) -> None:
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Dropout(dropout),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Dropout(dropout),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)


def train_decoder_classifier(
    x: np.ndarray,
    y: np.ndarray,
    device: torch.device,
    hidden: list[int],
    dropout: float,
    lr: float,
    epochs: int,
    batch_size: int,
    seed: int,
    weight_decay: float = 1e-3,
    patience: int = 10,
    x_val: np.ndarray | None = None,
    y_val: np.ndarray | None = None,
) -> tuple[nn.Module, dict[str, float]]:
    if x_val is None or y_val is None:
        x_train, x_val, y_train, y_val = split_ordered_trials(x, y, train_ratio=0.8)
    else:
        x_train, y_train = x, y
    model = MLPClassifier(x.shape[1], hidden=hidden, n_classes=int(np.max(y)) + 1, dropout=dropout).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    train_loader = DataLoader(TensorDataset(torch.tensor(x_train), torch.tensor(y_train, dtype=torch.long)), batch_size=batch_size, shuffle=False)
    val_loader = DataLoader(TensorDataset(torch.tensor(x_val), torch.tensor(y_val, dtype=torch.long)), batch_size=batch_size, shuffle=False)
    best_state, best_acc = None, -1.0
    bad_epochs = 0
    for _ in range(epochs):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        model.eval()
        y_true, y_pred = [], []
        with torch.no_grad():
            for xb, yb in val_loader:
                pred = model(xb.to(device)).argmax(dim=1).cpu().numpy()
                y_pred.extend(pred.tolist())
                y_true.extend(yb.numpy().tolist())
        acc = accuracy_score(y_true, y_pred)
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {"val_acc": float(best_acc)}


def train_decoder_regressor(x: np.ndarray, y: np.ndarray, device: torch.device, hidden: list[int], dropout: float, lr: float, epochs: int, batch_size: int, seed: int) -> tuple[nn.Module, dict[str, float]]:
    x_train, x_val, y_train, y_val = train_test_split(x, y, test_size=0.1, random_state=seed, shuffle=True)
    model = MLPRegressor(x.shape[1], hidden=hidden, out_dim=y.shape[1], dropout=dropout).to(device)
    criterion = nn.SmoothL1Loss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    train_loader = DataLoader(TensorDataset(torch.tensor(x_train), torch.tensor(y_train)), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(torch.tensor(x_val), torch.tensor(y_val)), batch_size=batch_size, shuffle=False)
    best_state, best_r2 = None, -1e9
    for _ in range(epochs):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
        model.eval()
        y_true, y_pred = [], []
        with torch.no_grad():
            for xb, yb in val_loader:
                y_pred.append(model(xb.to(device)).cpu().numpy())
                y_true.append(yb.numpy())
        r2 = r2_score(np.concatenate(y_true), np.concatenate(y_pred), multioutput="variance_weighted")
        if r2 > best_r2:
            best_r2 = float(r2)
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {"val_r2": float(best_r2)}


def train_cycle_gan_aligner(
    source_trials: np.ndarray,
    target_trials: np.ndarray,
    target_labels: np.ndarray,
    device: torch.device,
    input_dim: int,
    hidden_dim_g: int,
    hidden_dim_d: int,
    dropout_g: float,
    dropout_d: float,
    epochs: int,
    batch_size: int,
    g_lr: float,
    d_lr: float,
    identity_weight: float,
    cycle_weight: float,
    loss_type: str,
    target_train_ratio: float = 0.75,
    eval_decoder: nn.Module | None = None,
) -> nn.Module:
    if epochs <= 0:
        return IdentityAligner().to(device).eval()
    if target_trials.shape[0] < 2:
        return IdentityAligner().to(device).eval()
    target_train_x, target_val_x, _, target_val_y = split_ordered_trials(target_trials, target_labels, train_ratio=target_train_ratio)
    gen_st = Generator(input_dim, hidden_dim_g, dropout_g).to(device)
    gen_ts = Generator(input_dim, hidden_dim_g, dropout_g).to(device)
    disc_s = Discriminator(input_dim, hidden_dim_d, dropout_d).to(device)
    disc_t = Discriminator(input_dim, hidden_dim_d, dropout_d).to(device)
    criterion_cycle = nn.L1Loss() if loss_type == "L1" else nn.MSELoss()
    criterion_identity = nn.L1Loss() if loss_type == "L1" else nn.MSELoss()
    criterion_gan = nn.MSELoss()
    opt_gen_st = optim.Adam(gen_st.parameters(), lr=g_lr)
    opt_gen_ts = optim.Adam(gen_ts.parameters(), lr=g_lr)
    opt_disc_s = optim.Adam(disc_s.parameters(), lr=d_lr)
    opt_disc_t = optim.Adam(disc_t.parameters(), lr=d_lr)
    source_rows = np.concatenate(as_domain_batches(source_trials, "cls"), axis=0).astype(np.float32, copy=False)
    target_rows = np.concatenate(as_domain_batches(target_train_x, "cls"), axis=0).astype(np.float32, copy=False)
    loader_s = DataLoader(TensorDataset(torch.tensor(source_rows)), batch_size=batch_size, shuffle=True)
    loader_t = DataLoader(TensorDataset(torch.tensor(target_rows)), batch_size=batch_size, shuffle=True)
    best_state = None
    best_acc = -1.0
    for _ in range(epochs):
        for (data_s,), (data_t,) in zip(loader_s, loader_t):
            if data_s.size(0) != data_t.size(0):
                continue
            data_s, data_t = data_s.to(device), data_t.to(device)
            real = torch.ones((data_s.size(0), 1), device=device)
            fake = torch.zeros((data_s.size(0), 1), device=device)
            opt_gen_st.zero_grad()
            opt_gen_ts.zero_grad()
            same_t = gen_st(data_t)
            same_s = gen_ts(data_s)
            loss_id = criterion_identity(same_t, data_t) * identity_weight + criterion_identity(same_s, data_s) * identity_weight
            fake_t = gen_st(data_s)
            fake_s = gen_ts(data_t)
            loss_gan = criterion_gan(disc_t(fake_t), real) + criterion_gan(disc_s(fake_s), real)
            rec_s = gen_ts(fake_t)
            rec_t = gen_st(fake_s)
            loss_cycle = criterion_cycle(rec_s, data_s) * cycle_weight + criterion_cycle(rec_t, data_t) * cycle_weight
            loss_gen = loss_id + loss_gan + loss_cycle
            loss_gen.backward()
            opt_gen_st.step()
            opt_gen_ts.step()
            opt_disc_s.zero_grad()
            loss_disc_s = 0.5 * (criterion_gan(disc_s(data_s), real) + criterion_gan(disc_s(fake_s.detach()), fake))
            loss_disc_s.backward()
            opt_disc_s.step()
            opt_disc_t.zero_grad()
            loss_disc_t = 0.5 * (criterion_gan(disc_t(data_t), real) + criterion_gan(disc_t(fake_t.detach()), fake))
            loss_disc_t.backward()
            opt_disc_t.step()
        if eval_decoder is not None:
            aligned_trials = apply_aligner(gen_st, as_domain_batches(target_val_x, "cls"), device)
            aligned_eval = flatten_trials_for_classifier(np.stack(aligned_trials, axis=0))
            eval_metrics = evaluate_classifier(eval_decoder, aligned_eval, target_val_y, device)
            if eval_metrics["acc"] > best_acc:
                best_acc = float(eval_metrics["acc"])
                best_state = {key: value.detach().cpu().clone() for key, value in gen_st.state_dict().items()}
    if best_state is not None:
        gen_st.load_state_dict(best_state)
    return gen_st.eval()


def apply_aligner(aligner: nn.Module, batches: list[np.ndarray], device: torch.device) -> list[np.ndarray]:
    aligner.eval()
    outputs = []
    with torch.no_grad():
        for batch in batches:
            outputs.append(aligner(torch.tensor(batch, dtype=torch.float32, device=device)).cpu().numpy())
    return outputs


def evaluate_classifier(model: nn.Module, x: np.ndarray, y: np.ndarray, device: torch.device) -> dict[str, Any]:
    model.eval()
    with torch.no_grad():
        logits_t = model(torch.tensor(x, dtype=torch.float32, device=device))
        y_t = torch.tensor(np.asarray(y).reshape(-1), dtype=torch.long, device=device)
        loss = nn.functional.cross_entropy(logits_t, y_t).item()
        logits = logits_t.cpu().numpy()
    pred = logits.argmax(axis=1)
    labels = np.unique(np.concatenate([np.asarray(y).reshape(-1), np.asarray(pred).reshape(-1)]))
    return {
        "acc": float(accuracy_score(y, pred)),
        "loss": float(loss),
        "confusion_matrix": confusion_matrix(y, pred, labels=labels).tolist(),
    }


def evaluate_regressor(model: nn.Module, x: np.ndarray, y: np.ndarray, device: torch.device) -> dict[str, float]:
    model.eval()
    with torch.no_grad():
        pred = model(torch.tensor(x, dtype=torch.float32, device=device)).cpu().numpy()
    return {"mse": float(mean_squared_error(y, pred)), "mae": float(mean_absolute_error(y, pred)), "r2": float(r2_score(y, pred, multioutput="variance_weighted"))}


@dataclass
class CsvLogger:
    path: str | None
    task: str
    file_obj: Any = None
    writer: Any = None

    def __post_init__(self) -> None:
        if not self.path:
            return
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file_obj)
        if self.task == "cls":
            self.writer.writerow(["split", "acc"])
        else:
            self.writer.writerow(["split", "mse", "mae", "r2"])

    def log(self, split: str, metrics: dict[str, Any]) -> None:
        if not self.writer:
            return
        if self.task == "cls":
            self.writer.writerow([split, metrics.get("acc")])
        else:
            self.writer.writerow([split, metrics.get("mse"), metrics.get("mae"), metrics.get("r2")])
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()
