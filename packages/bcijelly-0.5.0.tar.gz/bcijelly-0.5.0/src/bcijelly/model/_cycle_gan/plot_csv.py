"""
Plot utility for Cycle_GAN metrics CSV files.
"""

from __future__ import annotations

import argparse
import os

import matplotlib.pyplot as plt
import pandas as pd


def plot_training_csv(csv_path: str) -> str:
    df = pd.read_csv(csv_path)
    metric_cols = [col for col in df.columns if col != "split"]
    if not metric_cols:
        raise ValueError("No metric columns found in CSV.")
    fig, ax = plt.subplots(figsize=(8, 5))
    for col in metric_cols:
        ax.plot(df["split"], df[col], marker="o", label=col)
    ax.set_title(f"Cycle_GAN Metrics - {os.path.basename(csv_path)}")
    ax.legend()
    fig.tight_layout()
    out_path = os.path.splitext(csv_path)[0] + "_curves.png"
    plt.savefig(out_path, dpi=300)
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot Cycle_GAN CSV metrics")
    parser.add_argument("--csv", type=str, required=True)
    args = parser.parse_args()
    out_path = plot_training_csv(args.csv)
    print(f"Saved plot to {out_path}")


if __name__ == "__main__":
    main()
