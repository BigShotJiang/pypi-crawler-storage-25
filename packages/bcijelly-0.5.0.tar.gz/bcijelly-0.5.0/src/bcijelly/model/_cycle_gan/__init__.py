from importlib import import_module


_EXPORTED_TASK_DOERS = {
    "classifier",
    "regressor",
}


def __getattr__(name: str):
    if name in _EXPORTED_TASK_DOERS:
        module = import_module(f"{__name__}.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__() -> list[str]:
    return sorted(set(globals().keys()) | _EXPORTED_TASK_DOERS)

__all__ = [
    "classifier",
    "regressor",
]
