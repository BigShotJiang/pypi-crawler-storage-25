"""
Regression interface for CycleGAN-based domain alignment.

Expected label shape:
  y: (N, T, D)
"""

from __future__ import annotations

import argparse
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch

try:
    from .shared_utils import (
        CsvLogger,
        apply_aligner,
        as_domain_batches,
        ensure_output_dir,
        evaluate_regressor,
        flatten_trials_for_regressor,
        load_npz_dataset,
        resolve_calib_ntrials,
        resolve_device,
        set_seed,
        train_cycle_gan_aligner,
        train_decoder_regressor,
        validate_dataset_regression,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        apply_aligner,
        as_domain_batches,
        ensure_output_dir,
        evaluate_regressor,
        flatten_trials_for_regressor,
        load_npz_dataset,
        resolve_calib_ntrials,
        resolve_device,
        set_seed,
        train_cycle_gan_aligner,
        train_decoder_regressor,
        validate_dataset_regression,
    )


SUPPORTS_EXTERNAL_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "regression"
PRIMARY_TEST_METRIC = "r2"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_arr = np.asarray(dataset[0])
    y_arr = np.asarray(dataset[1])
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        x_arr, y_arr = load_npz_dataset(datapath)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_regression(x_arr, y_arr)


def _resolve_calib_n(total_trials: int, calib_ratio: float, min_calib_trials: int, max_calib_trials: int | None) -> int:
    if total_trials <= 1:
        return 0
    calib_n = resolve_calib_ntrials(total_trials, calib_ratio, min_calib_trials, max_calib_trials)
    calib_n = max(0, min(int(calib_n), total_trials - 1))
    return calib_n


def _flatten_valid_regression_arrays(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    flat_x, flat_y = flatten_trials_for_regressor(x, y)
    flat_y_arr = np.asarray(flat_y)
    if flat_y_arr.ndim == 1:
        valid = ~np.isnan(flat_y_arr)
    else:
        valid = ~np.all(flat_y_arr == 0.0, axis=1)
    return np.asarray(flat_x)[valid], flat_y_arr[valid]


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 8,
    decoder_epochs: int = 40,
    decoder_lr: float = 1e-3,
    g_lr: float = 5e-4,
    d_lr: float = 5e-4,
    seed: int = 42,
    device: str = "auto",
    source_ratio: float = 0.8,
    generator_hidden: int = 256,
    discriminator_hidden: int = 256,
    dropout_decoder: float = 0.3,
    dropout_g: float = 0.2,
    dropout_d: float = 0.2,
    identity_weight: float = 20.0,
    cycle_weight: float = 20.0,
    loss_type: str = "L1",
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 0,
    calib_ratio: float = 0.1,
    min_calib_trials: int = 5,
    max_calib_trials: int | None = 30,
    enable_alignment: bool = True,
    verbose: bool = False,
) -> dict[str, Any]:
    del plot, patience, val_ratio
    x_all, y_all = _resolve_input_dataset(train_dataset, train_datapath, "train_dataset", "train_datapath")
    set_seed(seed)
    dev = resolve_device(device)

    if val_dataset is not None or val_datapath:
        source_train_x, source_train_y = x_all, y_all
        target_val_x, target_val_y = _resolve_input_dataset(val_dataset, val_datapath, "val_dataset", "val_datapath")
    else:
        source_train_x, source_train_y = x_all, y_all
        target_val_x = np.empty((0, *x_all.shape[1:]), dtype=x_all.dtype)
        target_val_y = np.empty((0, *y_all.shape[1:]), dtype=y_all.dtype)

    decoder, decoder_metrics = train_decoder_regressor(
        *flatten_trials_for_regressor(source_train_x, source_train_y),
        device=dev,
        hidden=[512, 256, 128],
        dropout=dropout_decoder,
        lr=decoder_lr,
        epochs=decoder_epochs,
        batch_size=batch_size,
        seed=seed,
    )

    val_metrics = {"mse": float("nan"), "mae": float("nan"), "r2": float("nan")}
    if target_val_x.shape[0] > 0:
        if enable_alignment:
            calib_n = _resolve_calib_n(target_val_x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
            if calib_n > 0:
                aligner = train_cycle_gan_aligner(
                    source_trials=source_train_x,
                    target_trials=target_val_x[:calib_n],
                    target_labels=target_val_y[:calib_n],
                    device=dev,
                    input_dim=source_train_x.shape[2],
                    hidden_dim_g=generator_hidden,
                    hidden_dim_d=discriminator_hidden,
                    dropout_g=dropout_g,
                    dropout_d=dropout_d,
                    epochs=epochs,
                    batch_size=batch_size,
                    g_lr=g_lr,
                    d_lr=d_lr,
                    identity_weight=identity_weight,
                    cycle_weight=cycle_weight,
                    loss_type=loss_type,
                )
                aligned_trials = apply_aligner(aligner, as_domain_batches(target_val_x[calib_n:], "reg"), dev)
                aligned_x = np.concatenate(aligned_trials, axis=0)
                _, flat_y = _flatten_valid_regression_arrays(target_val_x[calib_n:], target_val_y[calib_n:])
                flat_y_raw = target_val_y[calib_n:].reshape(target_val_y[calib_n:].shape[0] * target_val_y[calib_n:].shape[1], target_val_y[calib_n:].shape[2])
                valid = ~np.all(flat_y_raw == 0.0, axis=1)
                val_metrics = evaluate_regressor(decoder, aligned_x[valid], flat_y_raw[valid], dev)
            else:
                direct_x, direct_y = _flatten_valid_regression_arrays(target_val_x, target_val_y)
                val_metrics = evaluate_regressor(decoder, direct_x, direct_y, dev)
        else:
            direct_x, direct_y = _flatten_valid_regression_arrays(target_val_x, target_val_y)
            val_metrics = evaluate_regressor(decoder, direct_x, direct_y, dev)

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "metrics.csv")
    ckpt_path = os.path.join(run_dir, "cycle_gan_regressor.pt") if save_ckpt else None
    logger = CsvLogger(csv_path, task="reg")
    try:
        logger.log("source_decoder_val", {"mse": np.nan, "mae": np.nan, "r2": decoder_metrics["val_r2"]})
        logger.log("target_val", val_metrics)
    finally:
        logger.close()

    if ckpt_path:
        torch.save(
            {
                "decoder_state_dict": decoder.state_dict(),
                "source_train_x": source_train_x,
                "source_train_y": source_train_y,
            },
            ckpt_path,
        )

    source_train_x_flat, source_train_y_flat = _flatten_valid_regression_arrays(source_train_x, source_train_y)
    source_train_metrics = evaluate_regressor(decoder, source_train_x_flat, source_train_y_flat, dev)
    used_external_val = val_dataset is not None or bool(val_datapath)
    has_validation = target_val_x.shape[0] > 0
    used_internal_val_split = (not used_external_val) and has_validation

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "decoder": decoder,
            "device": dev,
            "source_train_x": source_train_x,
            "source_train_y": source_train_y,
            "batch_size": batch_size,
            "epochs": epochs,
            "g_lr": g_lr,
            "d_lr": d_lr,
            "generator_hidden": generator_hidden,
            "discriminator_hidden": discriminator_hidden,
            "dropout_g": dropout_g,
            "dropout_d": dropout_d,
            "identity_weight": identity_weight,
            "cycle_weight": cycle_weight,
            "loss_type": loss_type,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "calib_ratio": calib_ratio,
            "min_calib_trials": min_calib_trials,
            "max_calib_trials": max_calib_trials,
            "enable_alignment": enable_alignment,
        }
    )
    train_result = {
        "task": "regression_train",
        "train_r2": float(source_train_metrics["r2"]),
        "train_mse": float(source_train_metrics["mse"]),
        "train_mae": float(source_train_metrics["mae"]),
        "val_r2": float(val_metrics["r2"]),
        "val_mse": float(val_metrics["mse"]),
        "val_mae": float(val_metrics["mae"]),
        "best_epoch": int(decoder_metrics.get("best_epoch", decoder_epochs)),
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": bool(used_external_val),
        "used_internal_val_split": bool(used_internal_val_split),
        "has_validation": bool(has_validation),
        "source_decoder_val_r2": float(decoder_metrics["val_r2"]),
        "target_val_r2": float(val_metrics["r2"]),
        "target_val_mse": float(val_metrics["mse"]),
        "target_val_mae": float(val_metrics["mae"]),
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    calib_ratio: float = 0.1,
    min_calib_trials: int = 5,
    max_calib_trials: int | None = 30,
    verbose: bool = False,
) -> dict[str, Any]:
    if "decoder" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")

    x, y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    if not _TRAIN_STATE.get("enable_alignment", True):
        direct_x, direct_y = _flatten_valid_regression_arrays(x, y)
        metrics = evaluate_regressor(_TRAIN_STATE["decoder"], direct_x, direct_y, _TRAIN_STATE["device"])
        print(f"Test Regression Metrics: MSE={metrics['mse']:.4f}, MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}")
        test_result = {
            "task": "regression_test",
            "mse": float(metrics["mse"]),
            "mae": float(metrics["mae"]),
            "r2": float(metrics["r2"]),
            "calib_ntrials": 0,
            "eval_ntrials": int(x.shape[0]),
        }
        if verbose:
            _print_verbose_result("Test result:", test_result)
        return test_result

    calib_n = _resolve_calib_n(x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
    if calib_n == 0:
        direct_x, direct_y = _flatten_valid_regression_arrays(x, y)
        metrics = evaluate_regressor(_TRAIN_STATE["decoder"], direct_x, direct_y, _TRAIN_STATE["device"])
        print(f"Test Regression Metrics: MSE={metrics['mse']:.4f}, MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}")
        test_result = {
            "task": "regression_test",
            "mse": float(metrics["mse"]),
            "mae": float(metrics["mae"]),
            "r2": float(metrics["r2"]),
            "calib_ntrials": 0,
            "eval_ntrials": int(x.shape[0]),
        }
        if verbose:
            _print_verbose_result("Test result:", test_result)
        return test_result

    aligner = train_cycle_gan_aligner(
        source_trials=_TRAIN_STATE["source_train_x"],
        target_trials=x[:calib_n],
        target_labels=y[:calib_n],
        device=_TRAIN_STATE["device"],
        input_dim=_TRAIN_STATE["source_train_x"].shape[2],
        hidden_dim_g=_TRAIN_STATE["generator_hidden"],
        hidden_dim_d=_TRAIN_STATE["discriminator_hidden"],
        dropout_g=_TRAIN_STATE["dropout_g"],
        dropout_d=_TRAIN_STATE["dropout_d"],
        epochs=_TRAIN_STATE["epochs"],
        batch_size=_TRAIN_STATE["batch_size"],
        g_lr=_TRAIN_STATE["g_lr"],
        d_lr=_TRAIN_STATE["d_lr"],
        identity_weight=_TRAIN_STATE["identity_weight"],
        cycle_weight=_TRAIN_STATE["cycle_weight"],
        loss_type=_TRAIN_STATE["loss_type"],
    )
    aligned_trials = apply_aligner(aligner, as_domain_batches(x[calib_n:], "reg"), _TRAIN_STATE["device"])
    aligned_x = np.concatenate(aligned_trials, axis=0)
    flat_y = y[calib_n:].reshape(y[calib_n:].shape[0] * y[calib_n:].shape[1], y[calib_n:].shape[2])
    valid = ~np.all(flat_y == 0.0, axis=1)
    metrics = evaluate_regressor(_TRAIN_STATE["decoder"], aligned_x[valid], flat_y[valid], _TRAIN_STATE["device"])
    print(f"Test Regression Metrics: MSE={metrics['mse']:.4f}, MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}")
    test_result = {
        "task": "regression_test",
        "mse": float(metrics["mse"]),
        "mae": float(metrics["mae"]),
        "r2": float(metrics["r2"]),
        "calib_ntrials": int(calib_n),
        "eval_ntrials": int(x.shape[0] - calib_n),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="CycleGAN regressor train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None)
    parser.add_argument("--val_datapath", type=str, default=None)
    parser.add_argument("--test_datapath", type=str, default=None)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--decoder_epochs", type=int, default=40)
    parser.add_argument("--decoder_lr", type=float, default=1e-3)
    parser.add_argument("--g_lr", type=float, default=5e-4)
    parser.add_argument("--d_lr", type=float, default=5e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--source_ratio", type=float, default=0.8)
    parser.add_argument("--generator_hidden", type=int, default=256)
    parser.add_argument("--discriminator_hidden", type=int, default=256)
    parser.add_argument("--dropout_decoder", type=float, default=0.3)
    parser.add_argument("--dropout_g", type=float, default=0.2)
    parser.add_argument("--dropout_d", type=float, default=0.2)
    parser.add_argument("--identity_weight", type=float, default=20.0)
    parser.add_argument("--cycle_weight", type=float, default=20.0)
    parser.add_argument("--loss_type", choices=["L1", "MSE"], default="L1")
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=0)
    parser.add_argument("--calib_ratio", type=float, default=0.1)
    parser.add_argument("--min_calib_trials", type=int, default=5)
    parser.add_argument("--max_calib_trials", type=int, default=30)
    parser.add_argument("--enable_alignment", action="store_true")
    parser.add_argument("--no_enable_alignment", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    enable_alignment = not args.no_enable_alignment

    if args.train_datapath and not args.test_datapath:
        x_all, y_all = _resolve_input_dataset(None, args.train_datapath, "train_dataset", "train_datapath")
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            decoder_epochs=args.decoder_epochs,
            decoder_lr=args.decoder_lr,
            g_lr=args.g_lr,
            d_lr=args.d_lr,
            seed=args.seed,
            device=args.device,
            source_ratio=args.source_ratio,
            generator_hidden=args.generator_hidden,
            discriminator_hidden=args.discriminator_hidden,
            dropout_decoder=args.dropout_decoder,
            dropout_g=args.dropout_g,
            dropout_d=args.dropout_d,
            identity_weight=args.identity_weight,
            cycle_weight=args.cycle_weight,
            loss_type=args.loss_type,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
            enable_alignment=enable_alignment,
        )
        test_results = test(
            test_dataset=(test_x, test_y),
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            decoder_epochs=args.decoder_epochs,
            decoder_lr=args.decoder_lr,
            g_lr=args.g_lr,
            d_lr=args.d_lr,
            seed=args.seed,
            device=args.device,
            source_ratio=args.source_ratio,
            generator_hidden=args.generator_hidden,
            discriminator_hidden=args.discriminator_hidden,
            dropout_decoder=args.dropout_decoder,
            dropout_g=args.dropout_g,
            dropout_d=args.dropout_d,
            identity_weight=args.identity_weight,
            cycle_weight=args.cycle_weight,
            loss_type=args.loss_type,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
            enable_alignment=enable_alignment,
        )
        test_results = test(
            test_datapath=args.test_datapath if args.test_datapath else args.train_datapath,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
