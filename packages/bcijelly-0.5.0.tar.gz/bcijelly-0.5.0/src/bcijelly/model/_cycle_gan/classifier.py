"""
Classification interface for CycleGAN-based domain alignment.
"""

from __future__ import annotations

import argparse
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        apply_aligner,
        as_domain_batches,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        flatten_trials_for_classifier,
        load_npz_dataset,
        resolve_calib_ntrials,
        resolve_device,
        set_seed,
        split_ordered_trials,
        train_cycle_gan_aligner,
        train_decoder_classifier,
        validate_dataset_classification,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        apply_aligner,
        as_domain_batches,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        flatten_trials_for_classifier,
        load_npz_dataset,
        resolve_calib_ntrials,
        resolve_device,
        set_seed,
        split_ordered_trials,
        train_cycle_gan_aligner,
        train_decoder_classifier,
        validate_dataset_classification,
    )


SUPPORTS_EXTERNAL_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "classification"
PRIMARY_TEST_METRIC = "acc"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_arr = np.asarray(dataset[0])
    y_arr = np.asarray(dataset[1])
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        x_arr, y_arr = load_npz_dataset(datapath)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_classification(x_arr, y_arr)


def _encode_with_known_classes(y: np.ndarray, classes: list[Any]) -> np.ndarray:
    y_obj = np.asarray(y, dtype=object)
    class_to_id = {cls: idx for idx, cls in enumerate(classes)}
    encoded: list[int] = []
    for item in y_obj:
        label = item.reshape(-1)[0] if isinstance(item, np.ndarray) and item.size == 1 else item
        if isinstance(label, (bytes, bytearray)):
            label = label.decode("utf-8", errors="ignore")
        if label not in class_to_id:
            raise ValueError(f"Label '{label}' not found in training label set: {classes}")
        encoded.append(class_to_id[label])
    return np.asarray(encoded, dtype=np.int64)


def _get_stratify_labels(y: np.ndarray) -> np.ndarray | None:
    y_arr = np.asarray(y)
    if y_arr.ndim == 2 and y_arr.shape[1] == 1:
        y_arr = y_arr[:, 0]
    if y_arr.ndim != 1:
        return None
    _, counts = np.unique(y_arr, return_counts=True)
    if len(counts) < 2 or counts.min() < 2:
        return None
    return y_arr


def _resolve_calib_n(total_trials: int, calib_ratio: float, min_calib_trials: int, max_calib_trials: int | None) -> int:
    if total_trials <= 1:
        return 0
    calib_n = resolve_calib_ntrials(total_trials, calib_ratio, min_calib_trials, max_calib_trials)
    calib_n = max(0, min(int(calib_n), total_trials - 1))
    return calib_n


def _get_validation_dataset(
    x_fit: np.ndarray,
    y_fit_raw: np.ndarray,
    val_dataset: tuple[np.ndarray, np.ndarray] | None,
    val_datapath: str | None,
    classes: list[Any],
    val_ratio: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if val_dataset is not None or val_datapath:
        target_val_x, target_val_y_raw = _resolve_input_dataset(
            val_dataset,
            val_datapath,
            "val_dataset",
            "val_datapath",
        )
        target_val_y = _encode_with_known_classes(target_val_y_raw, classes)
        return x_fit, y_fit_raw, target_val_x, target_val_y

    del val_ratio
    return x_fit, y_fit_raw, np.empty((0, *x_fit.shape[1:]), dtype=x_fit.dtype), np.empty((0,), dtype=np.int64)


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 400,
    decoder_epochs: int = 100,
    decoder_lr: float = 1e-3,
    g_lr: float = 1e-3,
    d_lr: float = 1e-2,
    seed: int = 42,
    device: str = "auto",
    source_ratio: float = 0.9,
    generator_hidden: int = 0,
    discriminator_hidden: int = 0,
    dropout_decoder: float = 0.3,
    dropout_g: float = 0.2,
    dropout_d: float = 0.2,
    identity_weight: float = 5.0,
    cycle_weight: float = 5.0,
    loss_type: str = "L1",
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 10,
    calib_ratio: float = 0.1,
    min_calib_trials: int = 5,
    max_calib_trials: int | None = 30,
    enable_alignment: bool = True,
    verbose: bool = False,
) -> dict[str, Any]:
    del plot
    x_fit_all, y_fit_raw_all = _resolve_input_dataset(
        train_dataset,
        train_datapath,
        "train_dataset",
        "train_datapath",
    )

    set_seed(seed)
    dev = resolve_device(device)

    y_fit_encoded_all, label_to_id, classes = encode_labels(y_fit_raw_all)
    x_fit_all, y_fit_raw_all, target_val_x, target_val_y = _get_validation_dataset(
        x_fit_all,
        y_fit_raw_all,
        val_dataset,
        val_datapath,
        classes,
        val_ratio,
    )
    y_fit_encoded_all = _encode_with_known_classes(y_fit_raw_all, classes)

    x_source_train, x_source_val, y_source_train, y_source_val = split_ordered_trials(
        x_fit_all,
        y_fit_encoded_all,
        train_ratio=source_ratio,
    )

    decoder, decoder_metrics = train_decoder_classifier(
        flatten_trials_for_classifier(x_source_train),
        y_source_train,
        device=dev,
        hidden=[512, 256, 128],
        dropout=dropout_decoder,
        lr=decoder_lr,
        epochs=decoder_epochs,
        batch_size=batch_size,
        seed=seed,
        weight_decay=1e-3,
        patience=patience,
        x_val=flatten_trials_for_classifier(x_source_val),
        y_val=y_source_val,
    )

    val_metrics = {"acc": float("nan"), "loss": float("nan"), "confusion_matrix": []}
    if target_val_x.shape[0] > 0:
        if enable_alignment:
            calib_n = _resolve_calib_n(target_val_x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
            if calib_n > 0:
                aligner = train_cycle_gan_aligner(
                    source_trials=x_source_train,
                    target_trials=target_val_x[:calib_n],
                    target_labels=target_val_y[:calib_n],
                    device=dev,
                    input_dim=x_source_train.shape[2],
                    hidden_dim_g=generator_hidden if generator_hidden > 0 else x_source_train.shape[2],
                    hidden_dim_d=discriminator_hidden if discriminator_hidden > 0 else x_source_train.shape[2],
                    dropout_g=dropout_g,
                    dropout_d=dropout_d,
                    epochs=epochs,
                    batch_size=256,
                    g_lr=g_lr,
                    d_lr=d_lr,
                    identity_weight=identity_weight,
                    cycle_weight=cycle_weight,
                    loss_type=loss_type,
                    target_train_ratio=0.75,
                    eval_decoder=decoder,
                )
                aligned_val_trials = apply_aligner(aligner, as_domain_batches(target_val_x[calib_n:], "cls"), dev)
                aligned_val = flatten_trials_for_classifier(np.stack(aligned_val_trials, axis=0))
                val_metrics = evaluate_classifier(decoder, aligned_val, target_val_y[calib_n:], dev)
            else:
                direct_val = flatten_trials_for_classifier(target_val_x)
                val_metrics = evaluate_classifier(decoder, direct_val, target_val_y, dev)
        else:
            direct_val = flatten_trials_for_classifier(target_val_x)
            val_metrics = evaluate_classifier(decoder, direct_val, target_val_y, dev)

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "metrics.csv")
    ckpt_path = os.path.join(run_dir, "cycle_gan_classifier.pt") if save_ckpt else None
    logger = CsvLogger(csv_path, task="cls")
    try:
        logger.log("source_decoder_val", {"acc": decoder_metrics["val_acc"]})
        logger.log("target_val", val_metrics)
    finally:
        logger.close()

    if ckpt_path:
        torch.save(
            {
                "decoder_state_dict": decoder.state_dict(),
                "classes": classes,
                "label_to_id": label_to_id,
                "source_train_x": x_source_train,
                "source_train_y": y_source_train,
            },
            ckpt_path,
        )

    source_train_metrics = evaluate_classifier(
        decoder,
        flatten_trials_for_classifier(x_source_train),
        y_source_train,
        dev,
    )
    source_val_metrics = evaluate_classifier(
        decoder,
        flatten_trials_for_classifier(x_source_val),
        y_source_val,
        dev,
    )
    standard_val_metrics = val_metrics if np.isfinite(float(val_metrics["acc"])) else source_val_metrics
    used_external_val = val_dataset is not None or bool(val_datapath)
    has_validation = target_val_x.shape[0] > 0
    used_internal_val_split = (not used_external_val) and has_validation

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "decoder": decoder,
            "device": dev,
            "classes": classes,
            "label_to_id": label_to_id,
            "source_train_x": x_source_train,
            "source_train_y": y_source_train,
            "batch_size": batch_size,
            "epochs": epochs,
            "g_lr": g_lr,
            "d_lr": d_lr,
            "generator_hidden": generator_hidden if generator_hidden > 0 else x_source_train.shape[2],
            "discriminator_hidden": discriminator_hidden if discriminator_hidden > 0 else x_source_train.shape[2],
            "dropout_g": dropout_g,
            "dropout_d": dropout_d,
            "identity_weight": identity_weight,
            "cycle_weight": cycle_weight,
            "loss_type": loss_type,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "calib_ratio": calib_ratio,
            "min_calib_trials": min_calib_trials,
            "max_calib_trials": max_calib_trials,
            "enable_alignment": enable_alignment,
        }
    )
    train_result = {
        "task": "classification_train",
        "train_acc": float(source_train_metrics["acc"]),
        "train_loss": float(source_train_metrics["loss"]),
        "val_acc": float(standard_val_metrics["acc"]),
        "val_loss": float(standard_val_metrics["loss"]),
        "best_epoch": int(decoder_metrics.get("best_epoch", decoder_epochs)),
        "num_classes": int(len(classes)),
        "classes": classes,
        "label_to_id": label_to_id,
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": bool(used_external_val),
        "used_internal_val_split": bool(used_internal_val_split),
        "has_validation": bool(has_validation),
        "source_decoder_val_acc": float(source_val_metrics["acc"]),
        "source_decoder_val_loss": float(source_val_metrics["loss"]),
        "target_val_acc": float(val_metrics["acc"]),
        "target_val_loss": float(val_metrics["loss"]),
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    calib_ratio: float = 0.1,
    min_calib_trials: int = 5,
    max_calib_trials: int | None = 30,
    verbose: bool = False,
) -> dict[str, Any]:
    if "decoder" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")

    x, y = _resolve_input_dataset(test_dataset, test_datapath, "test_dataset", "test_datapath")
    y_encoded = _encode_with_known_classes(y, _TRAIN_STATE["classes"])

    if not _TRAIN_STATE.get("enable_alignment", True):
        direct_x = flatten_trials_for_classifier(x)
        metrics = evaluate_classifier(_TRAIN_STATE["decoder"], direct_x, y_encoded, _TRAIN_STATE["device"])
        print(f"Test Accuracy: {metrics['acc']:.4f}")
        test_result = {
            "task": "classification_test",
            "acc": float(metrics["acc"]),
            "confusion_matrix": metrics["confusion_matrix"],
            "calib_ntrials": 0,
            "eval_ntrials": int(x.shape[0]),
        }
        if verbose:
            _print_verbose_result("Test result:", test_result)
        return test_result

    calib_n = _resolve_calib_n(x.shape[0], calib_ratio, min_calib_trials, max_calib_trials)
    if calib_n == 0:
        direct_x = flatten_trials_for_classifier(x)
        metrics = evaluate_classifier(_TRAIN_STATE["decoder"], direct_x, y_encoded, _TRAIN_STATE["device"])
        print(f"Test Accuracy: {metrics['acc']:.4f}")
        test_result = {
            "task": "classification_test",
            "acc": float(metrics["acc"]),
            "confusion_matrix": metrics["confusion_matrix"],
            "calib_ntrials": 0,
            "eval_ntrials": int(x.shape[0]),
        }
        if verbose:
            _print_verbose_result("Test result:", test_result)
        return test_result

    aligner = train_cycle_gan_aligner(
        source_trials=_TRAIN_STATE["source_train_x"],
        target_trials=x[:calib_n],
        target_labels=y_encoded[:calib_n],
        device=_TRAIN_STATE["device"],
        input_dim=_TRAIN_STATE["source_train_x"].shape[2],
        hidden_dim_g=_TRAIN_STATE["generator_hidden"],
        hidden_dim_d=_TRAIN_STATE["discriminator_hidden"],
        dropout_g=_TRAIN_STATE["dropout_g"],
        dropout_d=_TRAIN_STATE["dropout_d"],
        epochs=_TRAIN_STATE["epochs"],
        batch_size=256,
        g_lr=_TRAIN_STATE["g_lr"],
        d_lr=_TRAIN_STATE["d_lr"],
        identity_weight=_TRAIN_STATE["identity_weight"],
        cycle_weight=_TRAIN_STATE["cycle_weight"],
        loss_type=_TRAIN_STATE["loss_type"],
        target_train_ratio=0.75,
        eval_decoder=_TRAIN_STATE["decoder"],
    )
    aligned_trials = apply_aligner(aligner, as_domain_batches(x[calib_n:], "cls"), _TRAIN_STATE["device"])
    aligned = flatten_trials_for_classifier(np.stack(aligned_trials, axis=0))
    metrics = evaluate_classifier(_TRAIN_STATE["decoder"], aligned, y_encoded[calib_n:], _TRAIN_STATE["device"])
    print(f"Test Accuracy: {metrics['acc']:.4f}")
    test_result = {
        "task": "classification_test",
        "acc": float(metrics["acc"]),
        "confusion_matrix": metrics["confusion_matrix"],
        "calib_ntrials": int(calib_n),
        "eval_ntrials": int(x.shape[0] - calib_n),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="CycleGAN classifier train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None)
    parser.add_argument("--val_datapath", type=str, default=None)
    parser.add_argument("--test_datapath", type=str, default=None)
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=400)
    parser.add_argument("--decoder_epochs", type=int, default=100)
    parser.add_argument("--decoder_lr", type=float, default=1e-3)
    parser.add_argument("--g_lr", type=float, default=1e-3)
    parser.add_argument("--d_lr", type=float, default=1e-2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--source_ratio", type=float, default=0.9)
    parser.add_argument("--generator_hidden", type=int, default=0)
    parser.add_argument("--discriminator_hidden", type=int, default=0)
    parser.add_argument("--dropout_decoder", type=float, default=0.3)
    parser.add_argument("--dropout_g", type=float, default=0.2)
    parser.add_argument("--dropout_d", type=float, default=0.2)
    parser.add_argument("--identity_weight", type=float, default=5.0)
    parser.add_argument("--cycle_weight", type=float, default=5.0)
    parser.add_argument("--loss_type", choices=["L1", "MSE"], default="L1")
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--calib_ratio", type=float, default=0.1)
    parser.add_argument("--min_calib_trials", type=int, default=5)
    parser.add_argument("--max_calib_trials", type=int, default=30)
    parser.add_argument("--enable_alignment", action="store_true")
    parser.add_argument("--no_enable_alignment", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = not args.no_save_ckpt
    enable_alignment = not args.no_enable_alignment

    if args.train_datapath and not args.test_datapath:
        x_all, y_all = _resolve_input_dataset(None, args.train_datapath, "train_dataset", "train_datapath")
        stratify = _get_stratify_labels(y_all)
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
            stratify=stratify,
        )
        train_results = train(
            train_dataset=(train_x, train_y),
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            decoder_epochs=args.decoder_epochs,
            decoder_lr=args.decoder_lr,
            g_lr=args.g_lr,
            d_lr=args.d_lr,
            seed=args.seed,
            device=args.device,
            source_ratio=args.source_ratio,
            generator_hidden=args.generator_hidden,
            discriminator_hidden=args.discriminator_hidden,
            dropout_decoder=args.dropout_decoder,
            dropout_g=args.dropout_g,
            dropout_d=args.dropout_d,
            identity_weight=args.identity_weight,
            cycle_weight=args.cycle_weight,
            loss_type=args.loss_type,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
            enable_alignment=enable_alignment,
        )
        test_results = test(
            test_dataset=(test_x, test_y),
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )
    else:
        train_results = train(
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            decoder_epochs=args.decoder_epochs,
            decoder_lr=args.decoder_lr,
            g_lr=args.g_lr,
            d_lr=args.d_lr,
            seed=args.seed,
            device=args.device,
            source_ratio=args.source_ratio,
            generator_hidden=args.generator_hidden,
            discriminator_hidden=args.discriminator_hidden,
            dropout_decoder=args.dropout_decoder,
            dropout_g=args.dropout_g,
            dropout_d=args.dropout_d,
            identity_weight=args.identity_weight,
            cycle_weight=args.cycle_weight,
            loss_type=args.loss_type,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
            enable_alignment=enable_alignment,
        )
        test_results = test(
            test_datapath=args.test_datapath if args.test_datapath else args.train_datapath,
            calib_ratio=args.calib_ratio,
            min_calib_trials=args.min_calib_trials,
            max_calib_trials=args.max_calib_trials,
        )

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
