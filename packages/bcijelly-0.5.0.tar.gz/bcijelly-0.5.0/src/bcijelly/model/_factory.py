from __future__ import annotations

from importlib import import_module
from types import ModuleType
from typing import Any


_TASK_TO_ENTRYPOINT = {
    "classification": "classifier",
    "regression": "regressor",
    "speech": "speech",
}

_MODEL_TO_IMPL_PACKAGE = {
    "transformer": "_transformer",
    "lstm": "_lstm",
    "cycle_gan": "_cycle_gan",
    "lfads": "_lfads",
    "stabilization": "_stabilization",
}

_MODEL_SUPPORTED_TASKS = {
    "transformer": {"classification", "regression", "speech"},
    "lstm": {"classification", "regression", "speech"},
    "cycle_gan": {"classification", "regression"},
    "lfads": {"classification", "regression"},
    "stabilization": {"classification", "regression"},
}


def get_supported_tasks(model_name: str) -> tuple[str, ...]:
    """Return supported tasks declared for a model.

    This declaration is used by model construction and helper scripts.
    """
    try:
        tasks = _MODEL_SUPPORTED_TASKS[model_name]
    except KeyError as exc:
        raise ValueError(
            f"Unsupported model_name {model_name!r}. Expected one of {sorted(_MODEL_SUPPORTED_TASKS)}"
        ) from exc
    return tuple(sorted(tasks))


class BaseModel:
    """Instance-oriented adapter over algorithm modules.

    Backend algorithm files still provide train/test functions, while this
    adapter stores per-instance runtime state and restores it before testing.
    """

    def __init__(self, *, model_name: str, task: str) -> None:
        try:
            impl_package = _MODEL_TO_IMPL_PACKAGE[model_name]
        except KeyError as exc:
            raise ValueError(
                f"Unsupported model_name {model_name!r}. Expected one of {sorted(_MODEL_TO_IMPL_PACKAGE)}"
            ) from exc

        try:
            entrypoint = _TASK_TO_ENTRYPOINT[task]
        except KeyError as exc:
            raise ValueError(
                f"Unsupported task {task!r}. Expected one of {sorted(_TASK_TO_ENTRYPOINT)}"
            ) from exc

        supported_tasks = set(get_supported_tasks(model_name))
        if task not in supported_tasks:
            raise ValueError(
                f"Model {model_name!r} does not support task {task!r}. "
                f"Supported tasks: {sorted(supported_tasks)}"
            )

        self.model_name = model_name
        self.task = task
        self.entrypoint = entrypoint
        self._backend: ModuleType = import_module(f"bcijelly.model.{impl_package}.{entrypoint}")
        self._train_state: dict[str, Any] = {}

    @property
    def __name__(self) -> str:
        return f"bcijelly.model.{self.model_name}.{self.entrypoint}"

    @property
    def TASK_TYPE(self) -> str | None:
        value = getattr(self._backend, "TASK_TYPE", None)
        return value if isinstance(value, str) else None

    @property
    def PRIMARY_TEST_METRIC(self) -> str | None:
        value = getattr(self._backend, "PRIMARY_TEST_METRIC", None)
        return value if isinstance(value, str) else None

    @property
    def SUPPORTS_EXTERNAL_VAL(self) -> bool:
        return bool(getattr(self._backend, "SUPPORTS_EXTERNAL_VAL", False))

    @property
    def SUPPORTS_TRAIN_WITHOUT_VAL(self) -> bool:
        return bool(getattr(self._backend, "SUPPORTS_TRAIN_WITHOUT_VAL", True))

    @property
    def AUTO_SPLIT_VAL_IF_MISSING(self) -> bool:
        return bool(getattr(self._backend, "AUTO_SPLIT_VAL_IF_MISSING", False))

    def train(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        result = self._backend.train(*args, **kwargs)
        backend_state = getattr(self._backend, "_TRAIN_STATE", None)
        if isinstance(backend_state, dict):
            self._train_state = dict(backend_state)
        return result

    def test(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        backend_state = getattr(self._backend, "_TRAIN_STATE", None)
        if isinstance(backend_state, dict) and self._train_state:
            backend_state.clear()
            backend_state.update(self._train_state)
        return self._backend.test(*args, **kwargs)


def create_model(*, model_name: str, task: str) -> BaseModel:
    return BaseModel(model_name=model_name, task=task)
