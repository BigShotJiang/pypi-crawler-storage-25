﻿"""
Regression interface for transformer sequence-to-sequence training/testing.

Expected label shape:
  y: (N, T, 2)  # regress x,y for each time step

CLI example:
  python regressor.py --train_datapath "D:\\研究生\\组\\建库任务\\复现算法\\transformer\\封装接口\\Jango_20150730_001.npz" --epochs 5
  python regressor.py --train_datapath "...train.npz" --test_datapath "...test.npz" --epochs 5

API example:
  from regressor import train, test
  train_res = train(train_dataset=(X_train, y_train), epochs=5)
  test_res = test(test_dataset=(X_test, y_test))
"""

from __future__ import annotations

import argparse
import math
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        ensure_output_dir,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        ensure_output_dir,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
    )

SUPPORTS_EXTERNAL_VAL = True
SUPPORTS_TRAIN_WITHOUT_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "regression"
PRIMARY_TEST_METRIC = "r2"

# Runtime state shared between train() and test().
_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 1024) -> None:
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        t = x.size(1)
        return x + self.pe[:, :t, :]


class SeqTransformerRegressor(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int = 2,
        d_model: int = 64,
        n_heads: int = 4,
        num_layers: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.input_proj = nn.Linear(input_dim, d_model)
        self.pos = PositionalEncoding(d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, T, C) -> out: (B, T, 2)
        h = self.input_proj(x)
        h = self.pos(h)
        h = self.encoder(h)
        return self.head(h)


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_raw, y_raw = dataset
    x_arr = np.asarray(x_raw)
    y_arr = np.asarray(y_raw)
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _validate_dataset_regression_seq(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(x, np.ndarray):
        raise TypeError(f"X must be numpy.ndarray, got {type(x)}")
    if not isinstance(y, np.ndarray):
        raise TypeError(f"y must be numpy.ndarray, got {type(y)}")

    if x.ndim != 3:
        raise ValueError(f"X must have shape (N, T, C), got {x.shape}")
    if y.ndim != 3 or y.shape[2] != 2:
        raise ValueError(f"y must have shape (N, T, 2), got {y.shape}")

    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched sample size: X has {x.shape[0]}, y has {y.shape[0]}")
    if x.shape[1] != y.shape[1]:
        raise ValueError(f"Mismatched time length: X has T={x.shape[1]}, y has T={y.shape[1]}")

    return x.astype(np.float32, copy=False), y.astype(np.float32, copy=False)


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        loaded = load_npz_dataset(datapath)
        x_arr, y_arr = _check_dataset_tuple_shape(loaded, dataset_name)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)

    return _validate_dataset_regression_seq(x_arr, y_arr)


def _fit_norm_stats(x: np.ndarray, y: np.ndarray) -> dict[str, np.ndarray]:
    x_mean = x.mean(axis=(0, 1), keepdims=True)
    x_std = x.std(axis=(0, 1), keepdims=True) + 1e-6
    y_mean = y.mean(axis=(0, 1), keepdims=True)
    y_std = y.std(axis=(0, 1), keepdims=True) + 1e-6
    return {"x_mean": x_mean, "x_std": x_std, "y_mean": y_mean, "y_std": y_std}


def _apply_norm(x: np.ndarray, y: np.ndarray, stats: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    x_n = (x - stats["x_mean"]) / stats["x_std"]
    y_n = (y - stats["y_mean"]) / stats["y_std"]
    return x_n.astype(np.float32, copy=False), y_n.astype(np.float32, copy=False)


def _evaluate_regressor_seq(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    device: torch.device,
    y_mean: np.ndarray,
    y_std: np.ndarray,
) -> dict[str, float]:
    model.eval()
    total_loss = 0.0
    n = 0
    y_true: list[np.ndarray] = []
    y_pred: list[np.ndarray] = []

    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            out = model(xb)
            loss = criterion(out, yb)
            bsz = xb.size(0)
            total_loss += loss.item() * bsz
            n += bsz
            y_true.append(yb.cpu().numpy())
            y_pred.append(out.cpu().numpy())

    if not y_true:
        return {"loss": 0.0, "mse": 0.0, "mae": 0.0, "r2": 0.0}

    yt_n = np.concatenate(y_true, axis=0)
    yp_n = np.concatenate(y_pred, axis=0)
    yt = yt_n * y_std + y_mean
    yp = yp_n * y_std + y_mean

    yt2 = yt.reshape(-1, 2)
    yp2 = yp.reshape(-1, 2)

    mse = mean_squared_error(yt2, yp2)
    mae = mean_absolute_error(yt2, yp2)
    r2 = r2_score(yt2, yp2)

    return {
        "loss": total_loss / max(n, 1),
        "mse": float(mse),
        "mae": float(mae),
        "r2": float(r2),
    }


def _train_one_epoch(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> float:
    model.train()
    total_loss = 0.0
    n = 0
    for xb, yb in loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        pred = model(xb)
        loss = criterion(pred, yb)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        bsz = xb.size(0)
        total_loss += loss.item() * bsz
        n += bsz
    return total_loss / max(n, 1)


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 100,
    lr: float = 1e-4,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    num_layers: int = 2,
    d_model: int = 64,
    n_heads: int = 4,
    dropout: float = 0.1,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 20,
    verbose: bool = False,
) -> dict[str, Any]:
    del val_ratio
    x, y = _resolve_input_dataset(
        dataset=train_dataset,
        datapath=train_datapath,
        dataset_name="train_dataset",
        datapath_name="train_datapath",
    )

    used_external_val = val_dataset is not None or bool(val_datapath)
    used_internal_val_split = False

    if used_external_val:
        val_x_raw, val_y_raw = _resolve_input_dataset(
            dataset=val_dataset,
            datapath=val_datapath,
            dataset_name="val_dataset",
            datapath_name="val_datapath",
        )
    else:
        val_x_raw, val_y_raw = None, None

    set_seed(seed)
    dev = resolve_device(device)

    norm_stats = _fit_norm_stats(x, y)
    x_n, y_n = _apply_norm(x, y, norm_stats)
    train_loader = make_dataloader(x_n, y_n, batch_size=batch_size, shuffle=True, task="reg")
    val_loader = None
    if used_external_val:
        assert val_x_raw is not None and val_y_raw is not None
        val_x_n, val_y_n = _apply_norm(val_x_raw, val_y_raw, norm_stats)
        val_loader = make_dataloader(val_x_n, val_y_n, batch_size=batch_size, shuffle=False, task="reg")

    model = SeqTransformerRegressor(
        input_dim=x.shape[2],
        output_dim=2,
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dropout=dropout,
    ).to(dev)

    criterion = nn.SmoothL1Loss(beta=1.0)
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=max(weight_decay, 1e-4))
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs, 1), eta_min=lr * 0.1)

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "train_log.csv")
    ckpt_path = os.path.join(run_dir, "best_model.pt") if save_ckpt else None

    logger = CsvLogger(csv_path, task="reg")
    best_metric = -1e9
    best_val_r2 = float("nan")
    best_epoch = -1
    final_train_metrics: dict[str, Any] | None = None

    try:
        for epoch in range(1, epochs + 1):
            train_loss = _train_one_epoch(model, train_loader, criterion, optimizer, dev)
            train_metrics = _evaluate_regressor_seq(
                model,
                train_loader,
                criterion,
                dev,
                y_mean=norm_stats["y_mean"],
                y_std=norm_stats["y_std"],
            )
            final_train_metrics = train_metrics
            current_lr = optimizer.param_groups[0]["lr"]
            logger.log(epoch, "train", train_metrics, current_lr)

            if used_external_val:
                assert val_loader is not None
                val_metrics = _evaluate_regressor_seq(
                    model,
                    val_loader,
                    criterion,
                    dev,
                    y_mean=norm_stats["y_mean"],
                    y_std=norm_stats["y_std"],
                )
                logger.log(epoch, "val", val_metrics, current_lr)
                current_metric = float(val_metrics["r2"])
                best_val_r2 = current_metric
                print(
                    f"Epoch {epoch}/{epochs} | train_loss={train_loss:.4f} | "
                    f"train_mse={train_metrics['mse']:.4f} | train_mae={train_metrics['mae']:.4f} | train_r2={train_metrics['r2']:.4f} | "
                    f"val_mse={val_metrics['mse']:.4f} | val_mae={val_metrics['mae']:.4f} | val_r2={val_metrics['r2']:.4f} | lr={current_lr:.2e}"
                )
            else:
                val_metrics = None
                current_metric = float(train_metrics["r2"])
                print(
                    f"Epoch {epoch}/{epochs} | train_loss={train_loss:.4f} | "
                    f"train_mse={train_metrics['mse']:.4f} | train_mae={train_metrics['mae']:.4f} | train_r2={train_metrics['r2']:.4f} | lr={current_lr:.2e}"
                )

            if current_metric > best_metric:
                best_metric = current_metric
                best_epoch = epoch
                if ckpt_path:
                    torch.save(
                        {
                            "model_state_dict": model.state_dict(),
                            "epoch": epoch,
                            "best_metric": best_metric,
                            "best_val_r2": best_val_r2,
                            "used_external_val": used_external_val,
                            "used_internal_val_split": used_internal_val_split,
                            "norm_stats": norm_stats,
                            "hparams": {
                                "batch_size": batch_size,
                                "epochs": epochs,
                                "lr": lr,
                                "seed": seed,
                                "num_layers": num_layers,
                                "d_model": d_model,
                                "n_heads": n_heads,
                                "dropout": dropout,
                                "weight_decay": max(weight_decay, 1e-4),
                                "patience": patience,
                            },
                        },
                        ckpt_path,
                    )

            scheduler.step()
            if used_external_val and epoch - best_epoch >= patience:
                break
    finally:
        logger.close()

    if plot:
        try:
            from .plot_csv import plot_training_csv
        except ImportError:
            from plot_csv import plot_training_csv

        plot_training_csv(csv_path, task="reg")

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "model": model,
            "device": dev,
            "criterion": criterion,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "batch_size": batch_size,
            "norm_stats": norm_stats,
        }
    )

    train_r2 = float(final_train_metrics["r2"]) if final_train_metrics is not None else float("nan")
    train_result = {
        "task": "regression_train",
        "train_r2": train_r2,
        "val_r2": float(best_val_r2),
        "best_epoch": int(best_epoch),
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")

    x, y = _resolve_input_dataset(
        dataset=test_dataset,
        datapath=test_datapath,
        dataset_name="test_dataset",
        datapath_name="test_datapath",
    )

    stats = _TRAIN_STATE["norm_stats"]
    x_n, y_n = _apply_norm(x, y, stats)

    batch_size = int(_TRAIN_STATE.get("batch_size", 32))
    test_loader = make_dataloader(x_n, y_n, batch_size=batch_size, shuffle=False, task="reg")

    model = _TRAIN_STATE["model"]
    dev = _TRAIN_STATE["device"]
    criterion = _TRAIN_STATE["criterion"]

    metrics = _evaluate_regressor_seq(
        model,
        test_loader,
        criterion,
        dev,
        y_mean=stats["y_mean"],
        y_std=stats["y_std"],
    )
    print(
        f"Test Regression Metrics: MSE={metrics['mse']:.4f}, "
        f"MAE={metrics['mae']:.4f}, R2={metrics['r2']:.4f}"
    )

    test_result = {
        "task": "regression_test",
        "mse": float(metrics["mse"]),
        "mae": float(metrics["mae"]),
        "r2": float(metrics["r2"]),
        "loss": float(metrics["loss"]),
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Transformer regressor train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None, help="Path to training .npz file")
    parser.add_argument("--val_datapath", type=str, default=None, help="Optional path to validation .npz file")
    parser.add_argument("--test_datapath", type=str, default=None, help="Path to testing .npz file")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--d_model", type=int, default=64)
    parser.add_argument("--n_heads", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=20)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = True
    if args.no_save_ckpt:
        save_ckpt = False
    elif args.save_ckpt:
        save_ckpt = True

    if args.train_datapath and not args.test_datapath:
        dataset = load_npz_dataset(args.train_datapath)
        x_all, y_all = _check_dataset_tuple_shape(dataset, "dataset")
        x_all, y_all = _validate_dataset_regression_seq(x_all, y_all)

        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            shuffle=True,
        )
        train_dataset = (train_x, train_y)
        test_dataset = (test_x, test_y)

        train_results = train(
            train_dataset=train_dataset,
            train_datapath=None,
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            d_model=args.d_model,
            n_heads=args.n_heads,
            dropout=args.dropout,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_dataset=test_dataset, test_datapath=None)
    else:
        train_results = train(
            train_dataset=None,
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            d_model=args.d_model,
            n_heads=args.n_heads,
            dropout=args.dropout,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )

        test_path = args.test_datapath if args.test_datapath else args.train_datapath
        test_results = test(test_dataset=None, test_datapath=test_path)

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
