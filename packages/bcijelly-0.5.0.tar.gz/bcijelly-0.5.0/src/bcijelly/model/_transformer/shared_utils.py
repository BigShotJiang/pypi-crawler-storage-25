"""
Shared utilities for transformer-based classification/regression training.
"""

from __future__ import annotations

import csv
import os
import random
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, confusion_matrix, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(device: str = "auto") -> torch.device:
    if device == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Requested device='cuda' but CUDA is not available.")
    return torch.device(device)


def _ensure_3d_x(x: np.ndarray) -> np.ndarray:
    if not isinstance(x, np.ndarray):
        raise TypeError(f"X must be numpy.ndarray, got {type(x)}")
    if x.ndim != 3:
        raise ValueError(f"X must have shape (trials, times, channels), got {x.shape}")
    return x.astype(np.float32, copy=False)


def validate_dataset_classification(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = _ensure_3d_x(x)
    if not isinstance(y, np.ndarray):
        raise TypeError(f"y must be numpy.ndarray, got {type(y)}")
    if y.ndim == 2 and y.shape[1] == 1:
        y = y[:, 0]
    if y.ndim != 1:
        raise ValueError(f"Classification y must have shape (trials,), got {y.shape}")
    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x.shape[0]}, y has {y.shape[0]}")
    return x, y


def validate_dataset_regression(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = _ensure_3d_x(x)
    if not isinstance(y, np.ndarray):
        raise TypeError(f"y must be numpy.ndarray, got {type(y)}")
    if y.ndim != 2 or y.shape[1] != 2:
        raise ValueError(f"Regression y must have shape (trials, 2), got {y.shape}")
    if x.shape[0] != y.shape[0]:
        raise ValueError(f"Mismatched samples: X has {x.shape[0]}, y has {y.shape[0]}")
    return x, y.astype(np.float32, copy=False)


def encode_labels(y: np.ndarray) -> tuple[np.ndarray, dict[Any, int], list[Any]]:
    y_obj = np.asarray(y, dtype=object)
    cleaned = []
    for v in y_obj:
        if isinstance(v, np.ndarray) and v.size == 1:
            v = v.reshape(-1)[0]
        if isinstance(v, (bytes, bytearray)):
            v = v.decode("utf-8", errors="ignore")
        cleaned.append(v)
    classes, inv = np.unique(np.asarray(cleaned, dtype=object), return_inverse=True)
    mapping = {cls: i for i, cls in enumerate(classes.tolist())}
    return inv.astype(np.int64), mapping, classes.tolist()


def load_npz_dataset(npz_path: str) -> tuple[np.ndarray, np.ndarray]:
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"NPZ file not found: {npz_path}")

    data = np.load(npz_path, allow_pickle=False)
    files = list(data.files)

    x_candidates = ("X", "x", "features", "feature", "spike", "samples")
    y_candidates = ("y", "Y", "labels", "label", "targets", "target", "discrete_labels")

    x_key = next((k for k in x_candidates if k in files), None)
    y_key = next((k for k in y_candidates if k in files), None)

    if x_key is not None and y_key is not None:
        try:
            return np.asarray(data[x_key]), np.asarray(data[y_key])
        except ValueError:
            data_pickle = np.load(npz_path, allow_pickle=True)
            return np.asarray(data_pickle[x_key]), np.asarray(data_pickle[y_key])

    if len(files) == 2:
        try:
            return np.asarray(data[files[0]]), np.asarray(data[files[1]])
        except ValueError:
            data_pickle = np.load(npz_path, allow_pickle=True)
            return np.asarray(data_pickle[files[0]]), np.asarray(data_pickle[files[1]])

    raise KeyError(
        f"Unable to infer X/y from {npz_path}. Available keys: {files}. "
        "Expected keys like X/y or features/labels."
    )


class ArrayDataset(Dataset):
    def __init__(self, x: np.ndarray, y: np.ndarray, task: str):
        self.x = torch.tensor(x, dtype=torch.float32)
        if task == "cls":
            self.y = torch.tensor(y, dtype=torch.long)
        else:
            self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self) -> int:
        return self.x.size(0)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor]:
        return self.x[idx], self.y[idx]


def make_dataloader(x: np.ndarray, y: np.ndarray, batch_size: int, shuffle: bool, task: str) -> DataLoader:
    dataset = ArrayDataset(x, y, task=task)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)


class TransformerModel(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        d_model: int = 64,
        n_heads: int = 4,
        num_layers: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.input_proj = nn.Linear(input_dim, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.head = nn.Linear(d_model, output_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.input_proj(x)  # x: (B, T, C) -> (B, T, D)
        h = self.encoder(h)
        pooled = h.mean(dim=1)
        return self.head(pooled)


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> float:
    model.train()
    total_loss = 0.0
    n = 0
    for xb, yb in loader:
        xb = xb.to(device)
        yb = yb.to(device)
        optimizer.zero_grad()
        pred = model(xb)
        loss = criterion(pred, yb)
        loss.backward()
        optimizer.step()
        bsz = xb.size(0)
        total_loss += loss.item() * bsz
        n += bsz
    return total_loss / max(n, 1)


def evaluate_classifier(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> dict[str, Any]:
    model.eval()
    total_loss = 0.0
    n = 0
    y_true: list[int] = []
    y_pred: list[int] = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            logits = model(xb)
            loss = criterion(logits, yb)
            bsz = xb.size(0)
            total_loss += loss.item() * bsz
            n += bsz
            pred = logits.argmax(dim=1)
            y_true.extend(yb.cpu().numpy().tolist())
            y_pred.extend(pred.cpu().numpy().tolist())

    acc = accuracy_score(y_true, y_pred) if y_true else 0.0
    if y_true:
        labels = sorted(set(y_true) | set(y_pred))
        cm = confusion_matrix(y_true, y_pred, labels=labels).tolist()
    else:
        cm = []
    return {"loss": total_loss / max(n, 1), "acc": float(acc), "confusion_matrix": cm}


def evaluate_regressor(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> dict[str, float]:
    model.eval()
    total_loss = 0.0
    n = 0
    y_true: list[np.ndarray] = []
    y_pred: list[np.ndarray] = []
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            out = model(xb)
            loss = criterion(out, yb)
            bsz = xb.size(0)
            total_loss += loss.item() * bsz
            n += bsz
            y_true.append(yb.cpu().numpy())
            y_pred.append(out.cpu().numpy())

    if not y_true:
        return {"loss": 0.0, "mse": 0.0, "mae": 0.0, "r2": 0.0}

    yt = np.concatenate(y_true, axis=0)
    yp = np.concatenate(y_pred, axis=0)
    mse = mean_squared_error(yt, yp)
    mae = mean_absolute_error(yt, yp)
    r2 = r2_score(yt, yp)
    return {"loss": total_loss / max(n, 1), "mse": float(mse), "mae": float(mae), "r2": float(r2)}


def split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    val_ratio: float,
    seed: int,
    task: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not (0.0 < val_ratio < 1.0):
        raise ValueError(f"val_ratio must be in (0,1), got {val_ratio}")
    stratify = y if task == "cls" and len(np.unique(y)) > 1 else None
    return train_test_split(x, y, test_size=val_ratio, random_state=seed, stratify=stratify)


def ensure_output_dir(output_dir: str, run_name: str | None = None) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = run_name or f"run_{stamp}"
    run_dir = os.path.join(output_dir, run_name)
    os.makedirs(run_dir, exist_ok=True)
    return run_dir, run_name


@dataclass
class CsvLogger:
    path: str | None
    task: str
    file_obj: Any = None
    writer: Any = None

    def __post_init__(self) -> None:
        if not self.path:
            return
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file_obj)
        if self.task == "cls":
            self.writer.writerow(["epoch", "split", "loss", "acc", "lr"])
        else:
            self.writer.writerow(["epoch", "split", "loss", "mse", "mae", "r2", "lr"])

    def log(self, epoch: int, split: str, metrics: dict[str, Any], lr: float) -> None:
        if not self.writer:
            return
        if self.task == "cls":
            self.writer.writerow(
                [epoch, split, metrics.get("loss"), metrics.get("acc"), lr]
            )
        else:
            self.writer.writerow(
                [
                    epoch,
                    split,
                    metrics.get("loss"),
                    metrics.get("mse"),
                    metrics.get("mae"),
                    metrics.get("r2"),
                    lr,
                ]
            )
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()



