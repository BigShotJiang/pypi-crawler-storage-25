﻿"""
Plot utility for training CSV files.

Examples:
  python plot_csv.py --csv ./outputs/run_xxx/train_log.csv
  python plot_csv.py --folder ./outputs/run_xxx
"""

from __future__ import annotations

import argparse
import glob
import os

import matplotlib.pyplot as plt
import pandas as pd


def _find_single_csv(folder: str) -> str:
    csv_files = glob.glob(os.path.join(folder, "*.csv"))
    if len(csv_files) == 0:
        raise FileNotFoundError(f"No CSV file found in {folder}")
    if len(csv_files) > 1:
        # Prefer train_log.csv when both exist.
        preferred = [p for p in csv_files if os.path.basename(p) == "train_log.csv"]
        if len(preferred) == 1:
            return preferred[0]
        raise RuntimeError(f"More than one CSV file found in {folder}: {csv_files}")
    return csv_files[0]


def _is_epoch_log(df: pd.DataFrame) -> bool:
    return "epoch" in df.columns and "split" in df.columns


def plot_training_csv(csv_path: str, task: str | None = None) -> str:
    df = pd.read_csv(csv_path)

    if _is_epoch_log(df):
        val_df = df[df["split"] == "val"].copy()
        if val_df.empty:
            raise ValueError("CSV has no val rows for plotting.")

        fig, ax1 = plt.subplots(figsize=(9, 5))
        ax1.plot(val_df["epoch"], val_df["loss"], marker="o", label="val_loss")
        ax1.set_xlabel("epoch")
        ax1.set_ylabel("loss")

        ax2 = ax1.twinx()
        metric_name = None
        if task == "cls" or "acc" in val_df.columns:
            metric_name = "acc"
        elif task == "reg":
            metric_name = "mse" if "mse" in val_df.columns else None
        elif "mse" in val_df.columns:
            metric_name = "mse"

        if metric_name:
            ax2.plot(val_df["epoch"], val_df[metric_name], color="tab:orange", marker="x", label=f"val_{metric_name}")
            ax2.set_ylabel(metric_name)

        ax1.set_title(f"Training Curves - {os.path.basename(csv_path)}")
        fig.tight_layout()
        out_path = os.path.splitext(csv_path)[0] + "_curves.png"
        plt.savefig(out_path, dpi=300)
        print(f"Saved plot to {out_path}")
        return out_path

    # Backward compatibility for old summary format from train.py
    has_header = "file" in df.columns and "task" in df.columns
    if not has_header:
        df = pd.read_csv(csv_path, header=None)
        df.columns = [
            "file",
            "task",
            "epoch",
            "train_loss",
            "val_loss",
            "val_acc_or_r2",
            "best_epoch",
            "best_val_acc_or_r2",
        ]

    inferred_task = str(df.loc[0, "task"]).lower()
    if inferred_task == "cls":
        y_col = "best_val_acc" if "best_val_acc" in df.columns else "best_val_acc_or_r2"
        y_label = "ACC"
    else:
        y_col = "best_val_r2" if "best_val_r2" in df.columns else "best_val_acc_or_r2"
        y_label = "R2"

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(df["file"].astype(str), df[y_col].astype(float))
    ax.set_xlabel("data")
    ax.set_ylabel(y_label)
    ax.set_title(f"Summary Best {y_label}")
    plt.xticks(rotation=30, ha="right")
    ax.bar_label(bars, fmt="%.3f", padding=3)
    plt.tight_layout()
    out_path = os.path.splitext(csv_path)[0] + f"_best_{y_label}.png"
    plt.savefig(out_path, dpi=300)
    print(f"Saved plot to {out_path}")
    return out_path


def main(folder: str | None = None, csv: str | None = None, task: str | None = None) -> str:
    if csv is None:
        if folder is None:
            raise ValueError("Provide --csv or --folder")
        csv = _find_single_csv(folder)
    return plot_training_csv(csv, task=task)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot training CSV")
    parser.add_argument("--folder", type=str, default=None, help="Folder that contains one CSV")
    parser.add_argument("--csv", type=str, default=None, help="Direct CSV path")
    parser.add_argument("--task", type=str, default=None, choices=["cls", "reg"], help="Optional task hint")
    args = parser.parse_args()
    main(folder=args.folder, csv=args.csv, task=args.task)
