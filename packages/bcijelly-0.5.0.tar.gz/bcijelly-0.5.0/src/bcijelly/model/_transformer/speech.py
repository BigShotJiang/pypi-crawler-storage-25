"""Speech interface for transformer training/testing with CER metric."""

from __future__ import annotations

import math
from pathlib import Path
from pprint import pformat
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

from bcijelly.dataset._io import load_speech_npz

try:
    from edit_distance import SequenceMatcher as _SequenceMatcher
except ImportError:
    _SequenceMatcher = None

try:
    from .shared_utils import ensure_output_dir, resolve_device, set_seed
except ImportError:
    from shared_utils import ensure_output_dir, resolve_device, set_seed


SUPPORTS_EXTERNAL_VAL = True
SUPPORTS_TRAIN_WITHOUT_VAL = False
AUTO_SPLIT_VAL_IF_MISSING = True
TASK_TYPE = "speech"
PRIMARY_TEST_METRIC = "cer"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _compute_edit_distance(true_seq: list[int], pred_seq: list[int]) -> int:
    if _SequenceMatcher is not None:
        matcher = _SequenceMatcher(a=true_seq, b=pred_seq)
        return int(matcher.distance())
    rows = len(true_seq) + 1
    cols = len(pred_seq) + 1
    dp = [[0] * cols for _ in range(rows)]
    for idx in range(rows):
        dp[idx][0] = idx
    for idx in range(cols):
        dp[0][idx] = idx
    for row in range(1, rows):
        for col in range(1, cols):
            cost = 0 if true_seq[row - 1] == pred_seq[col - 1] else 1
            dp[row][col] = min(dp[row - 1][col] + 1, dp[row][col - 1] + 1, dp[row - 1][col - 1] + cost)
    return dp[-1][-1]


def _validate_seq2seq_dataset(
    x: np.ndarray,
    y: np.ndarray,
    x_len: np.ndarray,
    y_len: np.ndarray,
    day_idx: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if x.ndim != 3:
        raise ValueError(f"X must have shape (N, T, C), got {x.shape}")
    if y.ndim != 2:
        raise ValueError(f"y must have shape (N, S), got {y.shape}")
    num_samples = x.shape[0]
    for name, arr in (("y", y), ("X_len", x_len), ("y_len", y_len), ("dayIdx", day_idx)):
        if arr.shape[0] != num_samples:
            raise ValueError(f"Mismatched sample size for {name}: expected {num_samples}, got {arr.shape[0]}")
    x = x.astype(np.float32, copy=False)
    y = y.astype(np.int64, copy=False)
    x_len = np.asarray(x_len).reshape(-1).astype(np.int64, copy=False)
    y_len = np.asarray(y_len).reshape(-1).astype(np.int64, copy=False)
    day_idx = np.asarray(day_idx).reshape(-1).astype(np.int64, copy=False)
    if np.any(x_len <= 0):
        raise ValueError("X_len must be positive for all samples.")
    if np.any(y_len <= 0):
        raise ValueError("y_len must be positive for all samples.")
    if np.any(day_idx < 0):
        raise ValueError("dayIdx must be non-negative.")
    if np.any(x_len > x.shape[1]):
        raise ValueError(f"Some X_len exceed padded time dimension {x.shape[1]}.")
    if np.any(y_len > y.shape[1]):
        raise ValueError(f"Some y_len exceed padded label dimension {y.shape[1]}.")
    return x, y, x_len, y_len, day_idx


def _check_dataset_tuple_shape(
    dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray],
    dataset_name: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 5:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y, X_len, y_len, dayIdx)")
    x_raw, y_raw, x_len_raw, y_len_raw, day_raw = dataset
    return _validate_seq2seq_dataset(
        np.asarray(x_raw),
        np.asarray(y_raw),
        np.asarray(x_len_raw),
        np.asarray(y_len_raw),
        np.asarray(day_raw),
    )


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if dataset is not None:
        return _check_dataset_tuple_shape(dataset, dataset_name)
    if not datapath:
        raise ValueError(f"Provide {dataset_name}=(X, y, X_len, y_len, dayIdx) or {datapath_name}=<path.npz>.")
    x, y, x_len, y_len, day_idx, _ = load_speech_npz(Path(datapath))
    return _validate_seq2seq_dataset(x, y, x_len, y_len, day_idx)


def _split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    x_len: np.ndarray,
    y_len: np.ndarray,
    day_idx: np.ndarray,
    val_ratio: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not (0.0 < val_ratio < 1.0):
        raise ValueError(f"val_ratio must be in (0, 1), got {val_ratio}")
    indices = np.arange(x.shape[0])
    train_idx, val_idx = train_test_split(indices, test_size=val_ratio, random_state=seed, shuffle=True)
    return (
        x[train_idx],
        y[train_idx],
        x_len[train_idx],
        y_len[train_idx],
        day_idx[train_idx],
        x[val_idx],
        y[val_idx],
        x_len[val_idx],
        y_len[val_idx],
        day_idx[val_idx],
    )


def _fit_feature_stats(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x_mean = x.mean(axis=(0, 1), keepdims=True)
    x_std = x.std(axis=(0, 1), keepdims=True) + 1e-6
    return x_mean.astype(np.float32, copy=False), x_std.astype(np.float32, copy=False)


def _apply_feature_stats(x: np.ndarray, x_mean: np.ndarray, x_std: np.ndarray) -> np.ndarray:
    return ((x - x_mean) / x_std).astype(np.float32, copy=False)


class SeqDataset(Dataset):
    def __init__(self, x: np.ndarray, y: np.ndarray, x_len: np.ndarray, y_len: np.ndarray, day_idx: np.ndarray) -> None:
        self.x = torch.tensor(x, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)
        self.x_len = torch.tensor(x_len, dtype=torch.long)
        self.y_len = torch.tensor(y_len, dtype=torch.long)
        self.day_idx = torch.tensor(day_idx, dtype=torch.long)

    def __len__(self) -> int:
        return self.x.shape[0]

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return self.x[idx], self.y[idx], self.x_len[idx], self.y_len[idx], self.day_idx[idx]


def make_dataloader(
    x: np.ndarray,
    y: np.ndarray,
    x_len: np.ndarray,
    y_len: np.ndarray,
    day_idx: np.ndarray,
    batch_size: int,
    shuffle: bool,
) -> DataLoader:
    return DataLoader(SeqDataset(x, y, x_len, y_len, day_idx), batch_size=batch_size, shuffle=shuffle)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 4096) -> None:
        super().__init__()
        position = torch.arange(max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, d_model, dtype=torch.float32)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, : x.size(1), :]


class GaussianSmoothing(nn.Module):
    def __init__(self, channels: int, kernel_size: int, sigma: float) -> None:
        super().__init__()
        kernel = torch.arange(int(kernel_size), dtype=torch.float32)
        mean = (kernel_size - 1) / 2
        gaussian = (1 / (sigma * math.sqrt(2 * math.pi))) * torch.exp(-(((kernel - mean) / sigma) ** 2) / 2)
        gaussian = gaussian / torch.sum(gaussian).clamp_min(1e-12)
        weight = gaussian.view(1, 1, -1).repeat(channels, 1, 1)
        self.register_buffer("weight", weight)
        self.groups = channels

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.conv1d(x, weight=self.weight, groups=self.groups, padding="same")


class SpeechFeatureFrontend(nn.Module):
    def __init__(
        self,
        input_dim: int,
        kernel_len: int = 32,
        stride_len: int = 4,
        gaussian_smooth_width: float = 2.0,
        n_days: int | None = None,
        use_day_idx: bool = True,
    ) -> None:
        super().__init__()
        self.kernel_len = int(kernel_len)
        self.stride_len = int(stride_len)
        self.output_dim = input_dim * self.kernel_len
        self.use_day_idx = use_day_idx and n_days is not None and n_days > 0
        self.input_nonlinearity = nn.Softsign()
        self.unfolder = nn.Unfold((self.kernel_len, 1), dilation=1, padding=0, stride=self.stride_len)
        self.gaussian_smoother = GaussianSmoothing(input_dim, 20, float(gaussian_smooth_width))
        if self.use_day_idx:
            self.day_weights = nn.Parameter(torch.randn(n_days, input_dim, input_dim))
            self.day_bias = nn.Parameter(torch.zeros(n_days, 1, input_dim))
            for day in range(n_days):
                self.day_weights.data[day, :, :] = torch.eye(input_dim)
        else:
            self.day_weights = None
            self.day_bias = None

    def compute_output_lengths(self, x_len: torch.Tensor, max_output_len: int | None = None) -> torch.Tensor:
        lengths = torch.div(x_len - self.kernel_len, self.stride_len, rounding_mode="floor")
        lengths = torch.clamp(lengths, min=1)
        if max_output_len is not None:
            lengths = torch.clamp(lengths, max=max_output_len)
        return lengths.to(torch.long)

    def forward(self, x: torch.Tensor, day_idx: torch.Tensor | None = None) -> torch.Tensor:
        features = x.transpose(1, 2)
        features = self.gaussian_smoother(features)
        features = features.transpose(1, 2)
        if self.use_day_idx and day_idx is not None and self.day_weights is not None and self.day_bias is not None:
            day_weights = torch.index_select(self.day_weights, 0, day_idx)
            day_bias = torch.index_select(self.day_bias, 0, day_idx)
            features = torch.einsum("btd,bdk->btk", features, day_weights) + day_bias
        features = self.input_nonlinearity(features)
        unfolded = self.unfolder(features.transpose(1, 2).unsqueeze(3))
        return unfolded.transpose(1, 2)


class TransformerCERModel(nn.Module):
    def __init__(
        self,
        input_dim: int,
        vocab_size: int,
        d_model: int = 128,
        n_heads: int = 4,
        num_layers: int = 3,
        dropout: float = 0.1,
        kernel_len: int = 32,
        stride_len: int = 4,
        gaussian_smooth_width: float = 2.0,
        n_days: int | None = None,
        use_day_idx: bool = True,
    ) -> None:
        super().__init__()
        self.frontend = SpeechFeatureFrontend(
            input_dim=input_dim,
            kernel_len=kernel_len,
            stride_len=stride_len,
            gaussian_smooth_width=gaussian_smooth_width,
            n_days=n_days,
            use_day_idx=use_day_idx,
        )
        self.input_projection = nn.Linear(self.frontend.output_dim, d_model)
        self.positional = PositionalEncoding(d_model)
        self.dropout = nn.Dropout(dropout)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, vocab_size))

    def compute_output_lengths(self, x_len: torch.Tensor, max_output_len: int | None = None) -> torch.Tensor:
        return self.frontend.compute_output_lengths(x_len, max_output_len=max_output_len)

    def forward(self, x: torch.Tensor, x_len: torch.Tensor, day_idx: torch.Tensor | None = None) -> torch.Tensor:
        hidden = self.frontend(x, day_idx)
        hidden = self.input_projection(hidden)
        effective_lengths = self.compute_output_lengths(x_len, max_output_len=hidden.size(1))
        hidden = self.dropout(self.positional(hidden))
        time_steps = hidden.size(1)
        padding_mask = torch.arange(time_steps, device=x.device).unsqueeze(0) >= effective_lengths.unsqueeze(1)
        encoded = self.encoder(hidden, src_key_padding_mask=padding_mask)
        return self.head(encoded)


class CsvLogger:
    def __init__(self, path: str | None) -> None:
        self.path = path
        self.file_obj: Any = None
        self.writer: Any = None
        if not self.path:
            return
        parent = str(Path(self.path).parent)
        if parent:
            Path(parent).mkdir(parents=True, exist_ok=True)
        self.file_obj = open(self.path, "w", newline="", encoding="utf-8")
        import csv

        self.writer = csv.writer(self.file_obj)
        self.writer.writerow(["epoch", "split", "loss", "cer", "lr"])

    def log(self, epoch: int, split: str, loss: float, cer: float, lr: float) -> None:
        if not self.writer:
            return
        self.writer.writerow([epoch, split, loss, cer, lr])
        self.file_obj.flush()

    def close(self) -> None:
        if self.file_obj:
            self.file_obj.close()


def _compute_ctc_loss(
    criterion: nn.CTCLoss,
    logits: torch.Tensor,
    targets: torch.Tensor,
    input_lengths: torch.Tensor,
    target_lengths: torch.Tensor,
) -> torch.Tensor:
    log_probs = logits.log_softmax(dim=-1).permute(1, 0, 2)
    return criterion(log_probs, targets, input_lengths, target_lengths)


def _decode_predictions(logits: torch.Tensor, input_lengths: torch.Tensor) -> list[list[int]]:
    decoded_sequences: list[list[int]] = []
    best_path = logits.argmax(dim=-1)
    for sample_idx in range(best_path.size(0)):
        valid_tokens = best_path[sample_idx, : input_lengths[sample_idx]]
        collapsed = torch.unique_consecutive(valid_tokens)
        decoded_sequences.append([int(token) for token in collapsed.tolist() if int(token) != 0])
    return decoded_sequences


def _evaluate_cer(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.CTCLoss,
    device: torch.device,
) -> dict[str, float]:
    model.eval()
    total_loss = 0.0
    total_samples = 0
    total_edit_distance = 0
    total_seq_length = 0
    with torch.no_grad():
        for xb, yb, x_len_b, y_len_b, day_idx_b in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            x_len_b = x_len_b.to(device)
            y_len_b = y_len_b.to(device)
            day_idx_b = day_idx_b.to(device)
            logits = model(xb, x_len_b, day_idx_b)
            effective_lengths = model.compute_output_lengths(x_len_b, max_output_len=logits.size(1))
            loss = _compute_ctc_loss(criterion, logits, yb, effective_lengths, y_len_b)
            batch_size = xb.size(0)
            total_loss += loss.item() * batch_size
            total_samples += batch_size
            decoded = _decode_predictions(logits, effective_lengths)
            for sample_idx, pred_seq in enumerate(decoded):
                true_len = int(y_len_b[sample_idx].item())
                true_seq = yb[sample_idx, :true_len].detach().cpu().tolist()
                total_edit_distance += _compute_edit_distance(true_seq, pred_seq)
                total_seq_length += len(true_seq)
    avg_loss = total_loss / max(total_samples, 1)
    cer = float(total_edit_distance / max(total_seq_length, 1))
    return {"loss": float(avg_loss), "cer": cer}


def train(
    train_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 50,
    lr: float = 3e-4,
    weight_decay: float = 1e-4,
    seed: int = 42,
    device: str = "auto",
    num_layers: int = 4,
    d_model: int = 256,
    n_heads: int = 8,
    dropout: float = 0.2,
    kernel_len: int = 32,
    stride_len: int = 4,
    gaussian_smooth_width: float = 2.0,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = False,
    plot: bool = False,
    val_ratio: float = 0.2,
    patience: int = 10,
    white_noise_sd: float = 0.2,
    constant_offset_sd: float = 0.05,
    use_day_idx: bool = True,
    verbose: bool = False,
) -> dict[str, Any]:
    del plot
    x_all, y_all, x_len_all, y_len_all, day_idx_all = _resolve_input_dataset(
        dataset=train_dataset,
        datapath=train_datapath,
        dataset_name="train_dataset",
        datapath_name="train_datapath",
    )
    if val_dataset is None and not val_datapath:
        (
            train_x_raw,
            train_y_raw,
            train_x_len,
            train_y_len,
            train_day_idx,
            val_x_raw,
            val_y_raw,
            val_x_len,
            val_y_len,
            val_day_idx,
        ) = _split_train_val(x_all, y_all, x_len_all, y_len_all, day_idx_all, val_ratio=val_ratio, seed=seed)
    else:
        train_x_raw, train_y_raw, train_x_len, train_y_len, train_day_idx = x_all, y_all, x_len_all, y_len_all, day_idx_all
        val_x_raw, val_y_raw, val_x_len, val_y_len, val_day_idx = _resolve_input_dataset(
            dataset=val_dataset,
            datapath=val_datapath,
            dataset_name="val_dataset",
            datapath_name="val_datapath",
        )

    x_mean, x_std = _fit_feature_stats(train_x_raw)
    train_x = _apply_feature_stats(train_x_raw, x_mean, x_std)
    val_x = _apply_feature_stats(val_x_raw, x_mean, x_std)
    vocab_size = int(max(np.max(train_y_raw), np.max(val_y_raw)) + 1)
    n_days = int(max(np.max(train_day_idx), np.max(val_day_idx)) + 1)

    set_seed(seed)
    dev = resolve_device(device)
    train_loader = make_dataloader(train_x, train_y_raw, train_x_len, train_y_len, train_day_idx, batch_size=batch_size, shuffle=True)
    val_loader = make_dataloader(val_x, val_y_raw, val_x_len, val_y_len, val_day_idx, batch_size=batch_size, shuffle=False)
    model = TransformerCERModel(
        input_dim=train_x.shape[2],
        vocab_size=vocab_size,
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dropout=dropout,
        kernel_len=kernel_len,
        stride_len=stride_len,
        gaussian_smooth_width=gaussian_smooth_width,
        n_days=n_days,
        use_day_idx=use_day_idx,
    ).to(dev)
    criterion = nn.CTCLoss(blank=0, reduction="mean", zero_infinity=True)
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=max(patience // 3, 2))
    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else str(Path(run_dir) / "train_log.csv")
    ckpt_path = str(Path(run_dir) / "best_model.pt") if save_ckpt else None
    logger = CsvLogger(csv_path)
    best_val_cer = float("inf")
    best_val_loss = float("inf")
    best_train_cer = float("inf")
    best_train_loss = float("inf")
    best_epoch = -1
    best_state_dict = None
    try:
        for epoch in range(1, epochs + 1):
            model.train()
            for xb, yb, x_len_b, y_len_b, day_idx_b in train_loader:
                xb = xb.to(dev)
                yb = yb.to(dev)
                x_len_b = x_len_b.to(dev)
                y_len_b = y_len_b.to(dev)
                day_idx_b = day_idx_b.to(dev)
                if white_noise_sd > 0:
                    xb = xb + torch.randn_like(xb) * white_noise_sd
                if constant_offset_sd > 0:
                    xb = xb + torch.randn(xb.size(0), 1, xb.size(2), device=dev) * constant_offset_sd
                optimizer.zero_grad()
                logits = model(xb, x_len_b, day_idx_b)
                effective_lengths = model.compute_output_lengths(x_len_b, max_output_len=logits.size(1))
                loss = _compute_ctc_loss(criterion, logits, yb, effective_lengths, y_len_b)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
            train_metrics = _evaluate_cer(model, train_loader, criterion, dev)
            val_metrics = _evaluate_cer(model, val_loader, criterion, dev)
            current_lr = float(optimizer.param_groups[0]["lr"])
            logger.log(epoch, "train", train_metrics["loss"], train_metrics["cer"], current_lr)
            logger.log(epoch, "val", val_metrics["loss"], val_metrics["cer"], current_lr)
            scheduler.step(val_metrics["cer"])
            if val_metrics["cer"] < best_val_cer:
                best_val_cer = val_metrics["cer"]
                best_val_loss = val_metrics["loss"]
                best_train_cer = train_metrics["cer"]
                best_train_loss = train_metrics["loss"]
                best_epoch = epoch
                best_state_dict = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                if ckpt_path:
                    torch.save({"model_state_dict": best_state_dict, "x_mean": x_mean, "x_std": x_std}, ckpt_path)
            if epoch - best_epoch >= patience:
                break
    finally:
        logger.close()

    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "model": model,
            "device": dev,
            "criterion": criterion,
            "x_mean": x_mean,
            "x_std": x_std,
            "batch_size": batch_size,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
        }
    )
    result = {
        "task": "speech_train",
        "train_cer": float(best_train_cer),
        "train_loss": float(best_train_loss),
        "val_cer": float(best_val_cer),
        "val_loss": float(best_val_loss),
        "best_epoch": int(best_epoch),
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
    }
    if verbose:
        _print_verbose_result("Speech transformer train result", result)
    return result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call train() before test().")
    x_raw, y_raw, x_len, y_len, day_idx = _resolve_input_dataset(
        dataset=test_dataset,
        datapath=test_datapath,
        dataset_name="test_dataset",
        datapath_name="test_datapath",
    )
    x = _apply_feature_stats(x_raw, _TRAIN_STATE["x_mean"], _TRAIN_STATE["x_std"])
    batch_size = int(_TRAIN_STATE.get("batch_size", 32))
    test_loader = make_dataloader(x, y_raw, x_len, y_len, day_idx, batch_size=batch_size, shuffle=False)
    metrics = _evaluate_cer(_TRAIN_STATE["model"], test_loader, _TRAIN_STATE["criterion"], _TRAIN_STATE["device"])
    result = {"task": "speech_test", "cer": float(metrics["cer"]), "loss": float(metrics["loss"])}
    if verbose:
        _print_verbose_result("Speech transformer test result", result)
    return result