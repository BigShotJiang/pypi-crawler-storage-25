﻿"""
Classification interface for transformer training/testing.

CLI example:
  python classifier.py --train_datapath "D:\\研究生\\组\\建库任务\\复现算法\\transformer\\封装接口\\20180910.npz" --epochs 5
  python classifier.py --train_datapath "...train.npz" --test_datapath "...test.npz" --epochs 5

API example:
  from classifier import transformer_train, transformer_test
  train_res = transformer_train(train_dataset=(X_train, y_train), epochs=5)
  test_res = transformer_test(test_dataset=(X_test, y_test))
"""

from __future__ import annotations

import argparse
import os
from pprint import pformat
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split

try:
    from .shared_utils import (
        CsvLogger,
        TransformerModel,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_classification,
    )
except ImportError:
    from shared_utils import (
        CsvLogger,
        TransformerModel,
        encode_labels,
        ensure_output_dir,
        evaluate_classifier,
        load_npz_dataset,
        make_dataloader,
        resolve_device,
        set_seed,
        train_one_epoch,
        validate_dataset_classification,
    )


SUPPORTS_EXTERNAL_VAL = True
SUPPORTS_TRAIN_WITHOUT_VAL = True
AUTO_SPLIT_VAL_IF_MISSING = False
TASK_TYPE = "classification"
PRIMARY_TEST_METRIC = "acc"


_TRAIN_STATE: dict[str, Any] = {}


def _print_verbose_result(title: str, result: dict[str, Any]) -> None:
    print(title)
    print(pformat(result, sort_dicts=False, compact=False, width=88))


def _check_dataset_tuple_shape(dataset: tuple[np.ndarray, np.ndarray], dataset_name: str) -> tuple[np.ndarray, np.ndarray]:
    if not isinstance(dataset, tuple) or len(dataset) != 2:
        raise TypeError(f"{dataset_name} must be a tuple: (X, y)")
    x_raw, y_raw = dataset
    x_arr = np.asarray(x_raw)
    y_arr = np.asarray(y_raw)
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            f"{dataset_name} first dimension mismatch: X has {x_arr.shape[0]} samples, "
            f"y has {y_arr.shape[0]} samples."
        )
    return x_arr, y_arr


def _resolve_input_dataset(
    dataset: tuple[np.ndarray, np.ndarray] | None,
    datapath: str | None,
    dataset_name: str,
    datapath_name: str,
) -> tuple[np.ndarray, np.ndarray]:
    if dataset is None:
        if not datapath:
            raise ValueError(f"Provide {dataset_name}=(X, y) or {datapath_name}=<path.npz>.")
        loaded = load_npz_dataset(datapath)
        x_arr, y_arr = _check_dataset_tuple_shape(loaded, dataset_name)
    else:
        x_arr, y_arr = _check_dataset_tuple_shape(dataset, dataset_name)
    return validate_dataset_classification(x_arr, y_arr)


def _encode_with_known_classes(y: np.ndarray, classes: list[Any]) -> np.ndarray:
    y_obj = np.asarray(y, dtype=object)
    class_to_id = {cls: index for index, cls in enumerate(classes)}
    encoded: list[int] = []
    for item in y_obj:
        key = item
        if isinstance(key, np.ndarray) and key.size == 1:
            key = key.reshape(-1)[0]
        if isinstance(key, (bytes, bytearray)):
            key = key.decode("utf-8", errors="ignore")
        if key not in class_to_id:
            raise ValueError(f"Label '{key}' not found in training label set: {classes}")
        encoded.append(class_to_id[key])
    return np.asarray(encoded, dtype=np.int64)


def _split_train_val(
    x: np.ndarray,
    y: np.ndarray,
    val_ratio: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    stratify = y if len(np.unique(y)) > 1 else None
    return train_test_split(
        x,
        y,
        test_size=val_ratio,
        random_state=seed,
        stratify=stratify,
    )


def train(
    train_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    train_datapath: str | None = None,
    val_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    val_datapath: str | None = None,
    batch_size: int = 32,
    epochs: int = 100,
    lr: float = 1e-4,
    weight_decay: float = 0.0,
    seed: int = 42,
    device: str = "auto",
    num_layers: int = 2,
    d_model: int = 64,
    n_heads: int = 4,
    dropout: float = 0.1,
    output_dir: str = "./outputs",
    run_name: str | None = None,
    log_csv: str | None = None,
    save_ckpt: bool = True,
    plot: bool = False,
    val_ratio: float = 0.125,
    patience: int = 20,
    verbose: bool = False,
) -> dict[str, Any]:
    del val_ratio
    x_all, y_all = _resolve_input_dataset(
        dataset=train_dataset,
        datapath=train_datapath,
        dataset_name="train_dataset",
        datapath_name="train_datapath",
    )

    used_external_val = val_dataset is not None or bool(val_datapath)
    used_internal_val_split = False

    if used_external_val:
        train_x, train_y_raw = x_all, y_all
        val_x, val_y_raw = _resolve_input_dataset(
            dataset=val_dataset,
            datapath=val_datapath,
            dataset_name="val_dataset",
            datapath_name="val_datapath",
        )
    else:
        train_x, train_y_raw = x_all, y_all
        val_x, val_y_raw = None, None

    train_y, label_to_id, classes = encode_labels(train_y_raw)
    if used_external_val:
        assert val_y_raw is not None
        val_y = _encode_with_known_classes(val_y_raw, classes)
    else:
        val_y = None

    if train_y.min() < 0 or train_y.max() != (len(classes) - 1):
        raise ValueError("Label encoding failed to produce dense class ids in [0..K-1].")

    set_seed(seed)
    dev = resolve_device(device)

    train_loader = make_dataloader(train_x, train_y, batch_size=batch_size, shuffle=True, task="cls")
    val_loader = None
    if used_external_val:
        assert val_x is not None and val_y is not None
        val_loader = make_dataloader(val_x, val_y, batch_size=batch_size, shuffle=False, task="cls")

    model = TransformerModel(
        input_dim=train_x.shape[2],
        output_dim=len(classes),
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dropout=dropout,
    ).to(dev)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    run_dir, resolved_run_name = ensure_output_dir(output_dir, run_name)
    csv_path = log_csv if log_csv else os.path.join(run_dir, "train_log.csv")
    ckpt_path = os.path.join(run_dir, "best_model.pt") if save_ckpt else None

    logger = CsvLogger(csv_path, task="cls")
    best_metric = -1.0
    best_val_acc = float("nan")
    best_val_loss = float("nan")
    best_epoch = -1
    best_state_dict = None
    final_train_metrics: dict[str, Any] | None = None

    try:
        for epoch in range(1, epochs + 1):
            train_one_epoch(model, train_loader, criterion, optimizer, dev)
            train_metrics = evaluate_classifier(model, train_loader, criterion, dev)
            final_train_metrics = train_metrics
            current_lr = optimizer.param_groups[0]["lr"]
            logger.log(epoch, "train", train_metrics, current_lr)

            if used_external_val:
                assert val_loader is not None
                val_metrics = evaluate_classifier(model, val_loader, criterion, dev)
                logger.log(epoch, "val", val_metrics, current_lr)
                current_metric = float(val_metrics["acc"])
                best_val_acc = current_metric
                best_val_loss = float(val_metrics["loss"])
                print(
                    f"Epoch {epoch}/{epochs} | "
                    f"train_loss={train_metrics['loss']:.4f} | train_acc={train_metrics['acc']:.4f} | "
                    f"val_loss={val_metrics['loss']:.4f} | val_acc={val_metrics['acc']:.4f}"
                )
            else:
                val_metrics = None
                current_metric = float(train_metrics["acc"])
                print(
                    f"Epoch {epoch}/{epochs} | "
                    f"train_loss={train_metrics['loss']:.4f} | train_acc={train_metrics['acc']:.4f}"
                )

            if current_metric > best_metric:
                best_metric = current_metric
                best_epoch = epoch
                best_state_dict = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                if ckpt_path:
                    torch.save(
                        {
                            "model_state_dict": best_state_dict,
                            "epoch": epoch,
                            "best_metric": best_metric,
                            "best_val_acc": best_val_acc,
                            "label_to_id": label_to_id,
                            "classes": classes,
                            "used_external_val": used_external_val,
                            "used_internal_val_split": used_internal_val_split,
                            "hparams": {
                                "batch_size": batch_size,
                                "epochs": epochs,
                                "lr": lr,
                                "seed": seed,
                                "num_layers": num_layers,
                                "d_model": d_model,
                                "n_heads": n_heads,
                                "dropout": dropout,
                                "patience": patience,
                            },
                        },
                        ckpt_path,
                    )

            if used_external_val and epoch - best_epoch >= patience:
                break
    finally:
        logger.close()

    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)

    if plot:
        try:
            from .plot_csv import plot_training_csv
        except ImportError:
            from plot_csv import plot_training_csv

        plot_training_csv(csv_path, task="cls")

    _TRAIN_STATE.clear()
    _TRAIN_STATE.update(
        {
            "model": model,
            "device": dev,
            "criterion": criterion,
            "label_to_id": label_to_id,
            "classes": classes,
            "run_dir": run_dir,
            "run_name": resolved_run_name,
            "csv_path": csv_path,
            "ckpt_path": ckpt_path,
            "batch_size": batch_size,
        }
    )

    train_acc = float(final_train_metrics["acc"]) if final_train_metrics is not None else float("nan")
    train_result = {
        "task": "classification_train",
        "train_acc": train_acc,
        "val_acc": float(best_val_acc),
        "val_loss": float(best_val_loss),
        "best_epoch": int(best_epoch),
        "num_classes": int(len(classes)),
        "classes": classes,
        "label_to_id": label_to_id,
        "csv_path": csv_path,
        "ckpt_path": ckpt_path,
        "run_dir": run_dir,
        "run_name": resolved_run_name,
        "device": str(dev),
        "used_external_val": used_external_val,
        "used_internal_val_split": used_internal_val_split,
        "has_validation": used_external_val,
    }
    if verbose:
        _print_verbose_result("Train result:", train_result)
    return train_result


def test(
    test_dataset: tuple[np.ndarray, np.ndarray] | None = None,
    test_datapath: str | None = None,
    verbose: bool = False,
) -> dict[str, Any]:
    if "model" not in _TRAIN_STATE:
        raise RuntimeError("No trained model found. Call transformer_train() before transformer_test().")

    x, y = _resolve_input_dataset(
        dataset=test_dataset,
        datapath=test_datapath,
        dataset_name="test_dataset",
        datapath_name="test_datapath",
    )
    y_encoded_arr = _encode_with_known_classes(y, _TRAIN_STATE["classes"])
    batch_size = int(_TRAIN_STATE.get("batch_size", 32))
    test_loader = make_dataloader(x, y_encoded_arr, batch_size=batch_size, shuffle=False, task="cls")

    model = _TRAIN_STATE["model"]
    dev = _TRAIN_STATE["device"]
    criterion = _TRAIN_STATE["criterion"]

    metrics = evaluate_classifier(model, test_loader, criterion, dev)
    print(f"Test Accuracy: {metrics['acc']:.4f}")

    test_result = {
        "task": "classification_test",
        "acc": float(metrics["acc"]),
        "loss": float(metrics["loss"]),
        "confusion_matrix": metrics["confusion_matrix"],
    }
    if verbose:
        _print_verbose_result("Test result:", test_result)
    return test_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Transformer classifier train+test for NPZ datasets")
    parser.add_argument("--train_datapath", type=str, default=None, help="Path to training .npz file")
    parser.add_argument("--val_datapath", type=str, default=None, help="Optional path to validation .npz file")
    parser.add_argument("--test_datapath", type=str, default=None, help="Path to testing .npz file")
    parser.add_argument("--batch_size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--d_model", type=int, default=64)
    parser.add_argument("--n_heads", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--output_dir", type=str, default="./outputs")
    parser.add_argument("--run_name", type=str, default=None)
    parser.add_argument("--log_csv", type=str, default=None)
    parser.add_argument("--save_ckpt", action="store_true")
    parser.add_argument("--no_save_ckpt", action="store_true")
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--val_ratio", type=float, default=0.125)
    parser.add_argument("--patience", type=int, default=20)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    save_ckpt = True
    if args.no_save_ckpt:
        save_ckpt = False
    elif args.save_ckpt:
        save_ckpt = True

    if args.train_datapath and not args.test_datapath:
        dataset = load_npz_dataset(args.train_datapath)
        x_all, y_all = _check_dataset_tuple_shape(dataset, "dataset")
        x_all, y_all = validate_dataset_classification(x_all, y_all)
        train_x, test_x, train_y, test_y = train_test_split(
            x_all,
            y_all,
            test_size=0.2,
            random_state=args.seed,
            stratify=y_all,
        )
        train_dataset = (train_x, train_y)
        test_dataset = (test_x, test_y)

        train_results = train(
            train_dataset=train_dataset,
            train_datapath=None,
            val_dataset=None,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            d_model=args.d_model,
            n_heads=args.n_heads,
            dropout=args.dropout,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )
        test_results = test(test_dataset=test_dataset, test_datapath=None)
    else:
        train_results = train(
            train_dataset=None,
            train_datapath=args.train_datapath,
            val_datapath=args.val_datapath,
            batch_size=args.batch_size,
            epochs=args.epochs,
            lr=args.lr,
            weight_decay=args.weight_decay,
            seed=args.seed,
            device=args.device,
            num_layers=args.num_layers,
            d_model=args.d_model,
            n_heads=args.n_heads,
            dropout=args.dropout,
            output_dir=args.output_dir,
            run_name=args.run_name,
            log_csv=args.log_csv,
            save_ckpt=save_ckpt,
            plot=args.plot,
            val_ratio=args.val_ratio,
            patience=args.patience,
        )

        test_path = args.test_datapath if args.test_datapath else args.train_datapath
        test_results = test(test_dataset=None, test_datapath=test_path)

    print("Train Results:", train_results)
    print("Test Results:", test_results)


if __name__ == "__main__":
    main()
