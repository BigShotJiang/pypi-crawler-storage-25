from collections.abc import Callable

from ._factory import BaseModel, create_model, get_supported_tasks


_EXPORTED_MODELS = {
	"transformer",
	"lstm",
	"cycle_gan",
	"lfads",
	"stabilization",
}


def _build_factory(model_name: str) -> Callable[..., BaseModel]:
	def _factory(*, task: str) -> BaseModel:
		return create_model(model_name=model_name, task=task)

	_factory.__name__ = model_name
	_factory.__qualname__ = model_name
	_factory.__doc__ = (
		f"Create a '{model_name}' model instance. "
		"Usage: bj.model.{model_name}(task='classification'|'regression')."
	)
	return _factory


def __getattr__(name: str):
	if name in _EXPORTED_MODELS:
		factory = _build_factory(name)
		globals()[name] = factory
		return factory
	raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__() -> list[str]:
	return sorted(set(globals().keys()) | _EXPORTED_MODELS)


__all__ = [
	"BaseModel",
	"create_model",
	"get_supported_tasks",
    "transformer",
    "lstm",
    "cycle_gan",
    "lfads",
    "stabilization",
]
