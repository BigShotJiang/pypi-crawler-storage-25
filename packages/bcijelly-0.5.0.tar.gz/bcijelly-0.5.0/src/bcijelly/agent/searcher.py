﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import copy
import csv
import random

import torch

from .model_builder import ModelBuilder
from .registry import ModuleRegistry
from .trainer import Trainer
from .utils import count_parameters, estimate_flops


@dataclass
class SearchResult:
    """Best architecture search output."""

    best_model: torch.nn.Module
    best_architecture_keys: list[str]
    best_architecture_layers: list[dict[str, Any]]
    best_val_metric: float
    best_test_metric: float | None
    best_num_parameters: int
    best_flops: int | None
    best_checkpoint_path: str
    best_model_id: int
    best_history: list[dict[str, Any]]
    model_logs: list[dict[str, Any]]
    top_k: list[dict[str, Any]]
    search_csv_path: str | None


class ArchitectureSearcher:
    """Random search over architecture combinations."""

    def __init__(
        self,
        registry: ModuleRegistry,
        builder: ModelBuilder,
        trainer: Trainer,
        device: torch.device,
        max_trials: int,
        max_depth: int,
        max_per_type: int,
        allow_repeat: bool,
        top_k: int,
        random_seed: int,
        save_csv: bool,
        output_dir: str | Path,
        min_distinct_types: int = 1,
        no_repeat_within_types: list[str] | None = None,
        max_occurrences_per_key: dict[str, int] | None = None,
        key_sampling_weights: dict[str, float] | None = None,
        logger: Any | None = None,
    ):
        self.registry = registry
        self.builder = builder
        self.trainer = trainer
        self.device = device
        self.max_trials = max_trials
        self.max_depth = max_depth
        self.max_per_type = max_per_type
        self.allow_repeat = allow_repeat
        self.top_k = top_k
        self.random_seed = random_seed
        self.save_csv = save_csv
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.min_distinct_types = max(1, int(min_distinct_types))
        self.no_repeat_within_types = {item.lower() for item in (no_repeat_within_types or [])}
        self.max_occurrences_per_key = dict(max_occurrences_per_key or {})
        self.key_sampling_weights = {key: float(value) for key, value in (key_sampling_weights or {}).items()}
        self.logger = logger

    def search(self, train_loader, val_loader, test_loader, input_dim: int, seq_len: int) -> SearchResult:
        """Search candidate architectures and return the best result."""
        candidates = self._sample_candidates()
        if not candidates:
            raise RuntimeError("No candidate architectures generated.")

        best_score = -1e18
        best_payload: dict[str, Any] | None = None
        model_logs: list[dict[str, Any]] = []

        for model_id, architecture in enumerate(candidates, start=1):
            model_name = f"model_{model_id:03d}"
            if self.logger is not None:
                self.logger.info("Start %s architecture=%s", model_name, architecture)

            record: dict[str, Any] = {
                "model_id": model_id,
                "model_name": model_name,
                "architecture": " | ".join(architecture),
                "status": "ok",
                "val_metric": None,
                "test_metric": None,
                "num_parameters": None,
                "flops": None,
                "train_time_sec": None,
                "error": "",
            }

            try:
                model, arch_info = self.builder.build(architecture, input_dim=input_dim)
                num_parameters = count_parameters(model)
                flops = estimate_flops(model, input_shape=(2, seq_len, input_dim), device=self.device)
                train_result = self.trainer.fit(
                    model=model,
                    train_loader=train_loader,
                    val_loader=val_loader,
                    test_loader=test_loader,
                    model_name=model_name,
                )

                record["val_metric"] = train_result.best_val_metric
                record["test_metric"] = train_result.test_metric
                record["num_parameters"] = num_parameters
                record["flops"] = flops
                record["train_time_sec"] = train_result.train_time_sec

                if train_result.best_val_metric > best_score:
                    best_score = train_result.best_val_metric
                    best_payload = {
                        "model_id": model_id,
                        "architecture": list(architecture),
                        "arch_layers": arch_info.layer_details,
                        "state_dict": copy.deepcopy(model.state_dict()),
                        "best_val_metric": train_result.best_val_metric,
                        "best_test_metric": train_result.test_metric,
                        "num_parameters": num_parameters,
                        "flops": flops,
                        "checkpoint_path": train_result.checkpoint_path,
                        "history": train_result.history,
                    }
            except Exception as exc:
                record["status"] = "failed"
                record["error"] = str(exc)
                if self.logger is not None:
                    self.logger.warning("%s failed: %s", model_name, exc)

            model_logs.append(record)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        if best_payload is None:
            raise RuntimeError("All trials failed. Check the log and CSV outputs for details.")

        best_model, _ = self.builder.build(best_payload["architecture"], input_dim=input_dim)
        best_model.load_state_dict(best_payload["state_dict"])
        best_model = best_model.to(self.device)

        successful_logs = [row for row in model_logs if row["status"] == "ok" and row["val_metric"] is not None]
        successful_logs.sort(key=lambda row: float(row["val_metric"]), reverse=True)
        top_k_logs = successful_logs[: self.top_k]

        csv_path = None
        if self.save_csv:
            csv_path = str((self.output_dir / "search_models.csv").resolve())
            self._write_csv(model_logs, csv_path)

        return SearchResult(
            best_model=best_model,
            best_architecture_keys=best_payload["architecture"],
            best_architecture_layers=best_payload["arch_layers"],
            best_val_metric=float(best_payload["best_val_metric"]),
            best_test_metric=None if best_payload["best_test_metric"] is None else float(best_payload["best_test_metric"]),
            best_num_parameters=int(best_payload["num_parameters"]),
            best_flops=best_payload["flops"],
            best_checkpoint_path=str(best_payload["checkpoint_path"]),
            best_model_id=int(best_payload["model_id"]),
            best_history=best_payload["history"],
            model_logs=model_logs,
            top_k=top_k_logs,
            search_csv_path=csv_path,
        )

    def _sample_candidates(self) -> list[list[str]]:
        """Randomly sample architectures with simple pruning constraints."""
        all_keys = self.registry.keys()
        if not all_keys:
            return []

        by_type = self.registry.by_type()
        rng = random.Random(self.random_seed)
        candidates: list[list[str]] = []
        seen: set[tuple[str, ...]] = set()

        if self.min_distinct_types <= 1:
            single_budget = max(1, self.max_trials // 3)
            shuffled_keys = all_keys[:]
            rng.shuffle(shuffled_keys)
            for key in shuffled_keys[:single_budget]:
                architecture = (key,)
                seen.add(architecture)
                candidates.append([key])

        attempts = 0
        max_attempts = self.max_trials * 120
        types = list(by_type.keys())
        min_depth = min(max(1, self.min_distinct_types), max(1, self.max_depth))

        while len(candidates) < self.max_trials and attempts < max_attempts:
            attempts += 1
            depth = rng.randint(min_depth, max(1, self.max_depth))
            architecture: list[str] = []
            architecture_types: list[str] = []
            type_counter: dict[str, int] = {}

            for _ in range(depth):
                chosen_type = rng.choice(types)
                if type_counter.get(chosen_type, 0) >= self.max_per_type:
                    continue

                pool = by_type[chosen_type]
                if not self.allow_repeat:
                    pool = [key for key in pool if key not in architecture]
                elif chosen_type in self.no_repeat_within_types:
                    pool = [key for key in pool if key not in architecture]

                filtered_pool = []
                filtered_weights = []
                for key in pool:
                    max_allowed = self.max_occurrences_per_key.get(key)
                    if max_allowed is not None and architecture.count(key) >= max_allowed:
                        continue
                    filtered_pool.append(key)
                    filtered_weights.append(max(0.0, self.key_sampling_weights.get(key, 1.0)))
                if not filtered_pool:
                    continue

                if sum(filtered_weights) > 0:
                    chosen_key = rng.choices(filtered_pool, weights=filtered_weights, k=1)[0]
                else:
                    chosen_key = rng.choice(filtered_pool)
                architecture.append(chosen_key)
                architecture_types.append(chosen_type)
                type_counter[chosen_type] = type_counter.get(chosen_type, 0) + 1

            if not architecture:
                continue
            if len(set(architecture_types)) < self.min_distinct_types:
                continue
            signature = tuple(architecture)
            if signature in seen:
                continue
            seen.add(signature)
            candidates.append(list(signature))

        return candidates[: self.max_trials]

    @staticmethod
    def _write_csv(records: list[dict[str, Any]], path: str) -> None:
        """Persist search records to CSV."""
        headers = [
            "model_id",
            "model_name",
            "architecture",
            "status",
            "val_metric",
            "test_metric",
            "num_parameters",
            "flops",
            "train_time_sec",
            "error",
        ]
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=headers)
            writer.writeheader()
            for row in records:
                writer.writerow({key: row.get(key, "") for key in headers})
