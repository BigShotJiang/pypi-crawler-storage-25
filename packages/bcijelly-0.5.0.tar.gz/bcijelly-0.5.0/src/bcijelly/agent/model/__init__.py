"""SearchAgent model component collection."""
