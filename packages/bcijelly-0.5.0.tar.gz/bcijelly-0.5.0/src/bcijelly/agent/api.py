from __future__ import annotations

import copy
import itertools
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import numpy as np
import torch
import torch.nn as nn
from sklearn.linear_model import LogisticRegression
from torch.utils.data import DataLoader, TensorDataset

from .data_utils import TaskInfo, infer_task_type, to_tensor
from .evaluator import regression_r2
from .model_builder import ModelBuilder
from .registry import ModuleRegistry
from .searcher import ArchitectureSearcher
from .trainer import Trainer
from .utils import (
    count_parameters,
    ensure_dir,
    estimate_flops,
    now_str,
    resolve_project_and_module_root,
    save_json,
    set_seed,
    setup_logger,
)


EnsembleMethod = Literal["mean", "stacking", "auto"]


@dataclass
class ExplicitDataBundle:
    """Explicit train/validation dataloaders and metadata."""

    train_loader: DataLoader
    val_loader: DataLoader
    task_info: TaskInfo
    input_dim: int
    seq_len: int
    train_mean: torch.Tensor
    train_std: torch.Tensor
    y_val_raw: np.ndarray
    class_values: list[int | float] | None
    class_to_index: dict[int | float, int] | None
    target_mean: np.ndarray | None
    target_std: np.ndarray | None


class CombinedEnsembleModel(nn.Module):
    """Runtime wrapper for the selected combined model."""

    def __init__(
        self,
        task_type: str,
        members: list[nn.Module],
        device: torch.device,
        batch_size: int,
        method: EnsembleMethod = "mean",
        class_values: np.ndarray | None = None,
        stacker: LogisticRegression | None = None,
        target_mean: np.ndarray | None = None,
        target_std: np.ndarray | None = None,
    ):
        super().__init__()
        self.task_type = task_type
        self.members = nn.ModuleList(members)
        self.device = device
        self.batch_size = batch_size
        self.method = method
        self.class_values = class_values
        self.stacker = stacker
        self.target_mean = target_mean
        self.target_std = target_std
        self.to(device)
        self.eval()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass returning mean outputs or combined class probabilities."""
        x = x.to(self.device)
        if self.task_type == "regression":
            preds = [member(x) for member in self.members]
            return torch.stack(preds, dim=0).mean(dim=0)

        member_probs = [torch.softmax(member(x), dim=1) for member in self.members]
        mean_probs = torch.stack(member_probs, dim=0).mean(dim=0)
        if self.method != "stacking" or self.stacker is None:
            return mean_probs

        features = np.concatenate([item.detach().cpu().numpy() for item in member_probs], axis=1)
        stacked_probs = self.stacker.predict_proba(features)
        return torch.from_numpy(stacked_probs).to(device=self.device, dtype=mean_probs.dtype)

    def predict_proba(self, X: np.ndarray | torch.Tensor) -> np.ndarray:
        """Predict class probabilities for classification tasks."""
        if self.task_type != "classification":
            raise RuntimeError("predict_proba() is only available for classification.")
        x_tensor = to_tensor(X, dtype=torch.float32)
        outputs: list[torch.Tensor] = []
        self.eval()
        with torch.no_grad():
            for start in range(0, x_tensor.shape[0], self.batch_size):
                batch = x_tensor[start : start + self.batch_size]
                outputs.append(self.forward(batch).detach().cpu())
        probs = torch.cat(outputs, dim=0).numpy()
        return probs

    def predict(self, X: np.ndarray | torch.Tensor) -> np.ndarray:
        """Predict class labels or regression outputs."""
        x_tensor = to_tensor(X, dtype=torch.float32)
        outputs: list[torch.Tensor] = []
        self.eval()
        with torch.no_grad():
            for start in range(0, x_tensor.shape[0], self.batch_size):
                batch = x_tensor[start : start + self.batch_size]
                outputs.append(self.forward(batch).detach().cpu())
        pred = torch.cat(outputs, dim=0).numpy()
        if self.task_type == "classification":
            pred_idx = np.argmax(pred, axis=1)
            if self.class_values is None:
                return pred_idx
            return self.class_values[pred_idx]
        if self.target_mean is not None and self.target_std is not None:
            pred = pred * self.target_std + self.target_mean
        return pred


class SearchAgent:
    """Unified API for architecture search, threshold filtering, and ensemble selection."""

    def __init__(
        self,
        module_root: str | None = None,  # Root path used to discover searchable modules.
        task_type: Literal["classification", "regression"] | None = None,  # Expected task type; None means infer from labels.
        device: str = "cuda",  # Runtime device preference (auto-falls back to CPU if CUDA is unavailable).
        hidden_dim: int = 64,  # Hidden feature width used by composed model blocks.
        batch_size: int = 16,  # Batch size for candidate training and ensemble inference.
        epochs: int = 12,  # Maximum epochs per candidate training run.
        patience: int = 4,  # Early-stop patience for candidate training.
        learning_rate: float = 1e-3,  # Optimizer learning rate.
        weight_decay: float = 1e-4,  # Optimizer weight decay.
        max_depth: int = 4,  # Maximum sampled architecture depth.
        max_models_per_round: int = 8,  # Number of sampled candidates per search round.
        max_trials_per_round: int | None = None,  # Backward-compatible alias overriding max_models_per_round when set.
        max_search_rounds: int = 4,  # Number of search rounds.
        retain_top_k: int = 6,  # Number of retained candidates after threshold filtering.
        val_threshold: float = 0.75,  # Minimum validation metric to retain a candidate.
        ensemble_top_m: int = 4,  # Top retained candidates considered for final ensemble selection.
        ensemble_method: EnsembleMethod = "auto",  # Ensemble strategy: mean, stacking, or auto selection.
        max_per_type: int = 2,  # Maximum count per module type in one sampled architecture.
        allow_repeat: bool = True,  # Whether repeated module keys are allowed in one architecture.
        min_distinct_types: int = 1,  # Minimum number of distinct module types required.
        no_repeat_within_types: list[str] | None = None,  # Module types that disallow repeated keys.
        max_occurrences_per_key: dict[str, int] | None = None,  # Optional per-key occurrence limits.
        key_sampling_weights: dict[str, float] | None = None,  # Optional sampling weights for module keys.
        search_module_types: list[str] | None = None,  # Allowed module type families in search space.
        allowed_module_keys: list[str] | None = None,  # Optional whitelist of module keys.
        include_builtin_modules: bool = True,  # Whether built-in modules are included in searchable registry.
        stacking_max_iter: int = 4000,  # Max iterations for logistic-regression stacker.
        random_seed: int = 42,  # Global random seed for reproducibility.
        num_workers: int = 0,  # DataLoader worker count.
        output_dir: str = "BJ_Agent_outputs_search_ensemble_api",  # Output directory for logs/artifacts/results.
        save_result_json: bool = True,  # Whether to persist best_result into JSON.
        normalize_regression_target: bool = True,  # Normalize regression targets during fit and recover scale in predict.
    ):
        if module_root is None:
            module_root = str(Path(__file__).parent)
        self.module_root = module_root
        self.task_type = task_type
        self.hidden_dim = hidden_dim
        self.batch_size = batch_size
        self.epochs = epochs
        self.patience = patience
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.max_depth = max_depth
        self.max_models_per_round = (
            int(max_models_per_round) if max_trials_per_round is None else int(max_trials_per_round)
        )
        self.max_search_rounds = max_search_rounds
        self.retain_top_k = retain_top_k
        self.val_threshold = val_threshold
        self.ensemble_top_m = ensemble_top_m
        self.ensemble_method = ensemble_method
        self.max_per_type = max_per_type
        self.allow_repeat = allow_repeat
        self.min_distinct_types = min_distinct_types
        self.no_repeat_within_types = no_repeat_within_types
        self.max_occurrences_per_key = max_occurrences_per_key
        self.key_sampling_weights = key_sampling_weights
        self.search_module_types = [item.lower() for item in (search_module_types or ["attention", "conv", "rep", "backbone", "mlp"])]
        self.allowed_module_keys = allowed_module_keys
        self.include_builtin_modules = include_builtin_modules
        self.stacking_max_iter = stacking_max_iter
        self.random_seed = random_seed
        self.num_workers = num_workers
        self.output_dir = ensure_dir(output_dir)
        self.save_result_json = save_result_json
        self.normalize_regression_target = normalize_regression_target

        resolved_device = device
        if resolved_device.startswith("cuda") and not torch.cuda.is_available():
            resolved_device = "cpu"
        self.device = torch.device(resolved_device)
        self.logger = setup_logger("SearchAgent", self.output_dir / f"search_ensemble_{now_str()}.log")

        self.best_model: CombinedEnsembleModel | None = None
        self.best_result: dict[str, Any] | None = None
        self._bundle: ExplicitDataBundle | None = None
        self._registry: ModuleRegistry | None = None
        self._all_candidates: list[dict[str, Any]] = []
        self._retained_candidates: list[dict[str, Any]] = []
        self._fitted = False

    def fit(
        self,
        train_dataset: tuple,
        val_dataset: tuple | None = None,
    ) -> "SearchAgent":
        """Run thresholded architecture search and build the final ensemble.

        Args:
            train_dataset: A (X_train, y_train) tuple, or data.train_dataset from load_data.
            val_dataset: A (X_val, y_val) tuple, or data.val_dataset from load_data.
                         Required — SearchAgent uses the validation set for architecture selection.
        """
        if val_dataset is None:
            raise ValueError(
                "val_dataset is required for SearchAgent.fit(). "
                "Please provide a validation set, e.g. via load_data with split_ratio='7:1:2'."
            )
        X_train, y_train = train_dataset[0], train_dataset[1]
        X_val, y_val = val_dataset[0], val_dataset[1]
        set_seed(self.random_seed)
        bundle = self._prepare_explicit_data(X_train, y_train, X_val, y_val)
        self._bundle = bundle

        registry = self._build_registry()
        self._registry = registry
        builder = ModelBuilder(
            registry=registry,
            hidden_dim=self.hidden_dim,
            task_type=bundle.task_info.task_type,
            num_classes=bundle.task_info.num_classes,
            regression_dim=bundle.task_info.regression_dim,
            input_mean=bundle.train_mean,
            input_std=bundle.train_std,
        )
        trainer = Trainer(
            task_type=bundle.task_info.task_type,
            device=self.device,
            epochs=self.epochs,
            patience=self.patience,
            learning_rate=self.learning_rate,
            weight_decay=self.weight_decay,
            output_dir=self.output_dir,
            logger=self.logger,
        )

        self._all_candidates = []
        retained_by_arch: dict[tuple[str, ...], dict[str, Any]] = {}
        seen_architectures: set[tuple[str, ...]] = set()

        for round_index in range(1, self.max_search_rounds + 1):
            sampled_architectures = self._sample_round_candidates(registry, builder, trainer, bundle, round_index)
            if not sampled_architectures:
                self.logger.warning("Round %d produced no new candidate architectures.", round_index)
                continue

            for local_model_id, architecture in enumerate(sampled_architectures, start=1):
                signature = tuple(architecture)
                if signature in seen_architectures:
                    continue
                seen_architectures.add(signature)
                record = self._train_candidate(
                    builder=builder,
                    trainer=trainer,
                    architecture=architecture,
                    train_loader=bundle.train_loader,
                    val_loader=bundle.val_loader,
                    input_dim=bundle.input_dim,
                    seq_len=bundle.seq_len,
                    round_index=round_index,
                    local_model_id=local_model_id,
                )
                self._all_candidates.append(record)
                if record["status"] != "ok":
                    continue
                if float(record["val_metric"]) >= float(self.val_threshold):
                    previous = retained_by_arch.get(signature)
                    if previous is None or float(record["val_metric"]) > float(previous["val_metric"]):
                        retained_by_arch[signature] = record

            retained_sorted = sorted(retained_by_arch.values(), key=lambda item: float(item["val_metric"]), reverse=True)
            self._retained_candidates = retained_sorted[: self.retain_top_k]
            self.logger.info(
                "After round %d retained=%d threshold=%.4f target_k=%d",
                round_index,
                len(self._retained_candidates),
                self.val_threshold,
                self.retain_top_k,
            )
            if len(self._retained_candidates) >= self.retain_top_k:
                break

        if not self._retained_candidates:
            successful = [item for item in self._all_candidates if item["status"] == "ok"]
            successful.sort(key=lambda item: float(item["val_metric"]), reverse=True)
            self._retained_candidates = successful[: self.retain_top_k]
            threshold_satisfied = False
        else:
            threshold_satisfied = len(self._retained_candidates) >= self.retain_top_k

        if not self._retained_candidates:
            raise RuntimeError("No successful candidates were produced during search.")

        ensemble_result = self._select_best_ensemble(bundle=bundle, builder=builder)
        self.best_model = ensemble_result["model"]
        self.best_result = {
            "task_type": bundle.task_info.task_type,
            "search_config": {
                "max_depth": self.max_depth,
                "max_models_per_round": self.max_models_per_round,
                "max_search_rounds": self.max_search_rounds,
                "retain_top_k": self.retain_top_k,
                "val_threshold": self.val_threshold,
                "ensemble_top_m": self.ensemble_top_m,
                "ensemble_method": self.ensemble_method,
                "max_per_type": self.max_per_type,
                "allow_repeat": self.allow_repeat,
                "min_distinct_types": self.min_distinct_types,
                "search_module_types": self.search_module_types,
                "allowed_module_keys": self.allowed_module_keys,
                "include_builtin_modules": self.include_builtin_modules,
                "normalize_regression_target": self.normalize_regression_target,
            },
            "data_summary": {
                "train_samples": int(bundle.train_loader.dataset.tensors[0].shape[0]),
                "validation_samples": int(bundle.val_loader.dataset.tensors[0].shape[0]),
                "input_dim": int(bundle.input_dim),
                "seq_len": int(bundle.seq_len),
            },
            "threshold_filter": {
                "val_threshold": float(self.val_threshold),
                "qualified_count": int(
                    len([item for item in self._all_candidates if item["status"] == "ok" and float(item["val_metric"]) >= float(self.val_threshold)])
                ),
                "retained_count": int(len(self._retained_candidates)),
                "threshold_satisfied": bool(threshold_satisfied),
            },
            "retained_candidates": self._retained_candidates,
            "selected_ensemble": ensemble_result["summary"],
            "result_json_path": str((self.output_dir / "search_ensemble_result.json").resolve()),
            "search_csv_path": str((self.output_dir / "search_round_models.csv").resolve()),
        }
        self._write_candidate_csv()
        if self.save_result_json:
            save_json(self.best_result, self.best_result["result_json_path"])
        self._fitted = True
        return self

    def predict(self, X: np.ndarray | torch.Tensor) -> np.ndarray:
        """Predict with the selected combined model."""
        self._ensure_fitted()
        assert self.best_model is not None
        return self.best_model.predict(X)

    def get_best_model(self) -> CombinedEnsembleModel:
        """Return the final combined model wrapper."""
        self._ensure_fitted()
        assert self.best_model is not None
        return self.best_model

    def get_best_result(self) -> dict[str, Any]:
        """Return the search and ensemble summary."""
        self._ensure_fitted()
        assert self.best_result is not None
        return self.best_result

    def summary(
        self,
        mode: Literal["compact", "full"] = "compact",
        print_output: bool = True,
        include: bool = False,
        max: int | None = None,
    ) -> dict[str, Any]:
        """Return a user-facing summary for the fitted search result.

        Args:
            mode: "compact" returns key fields only; "full" returns extended details.
            print_output: Whether to print summary text to stdout.
            include: Whether to include retained candidate details.
            max: Optional cap for returned retained candidates when include=True.

        Returns:
            A dict containing compact or full summary content.
        """
        self._ensure_fitted()
        if mode not in {"compact", "full"}:
            raise ValueError("mode must be either 'compact' or 'full'.")
        if max is not None and max < 0:
            raise ValueError("max must be >= 0 or None.")

        assert self.best_result is not None
        best = copy.deepcopy(self.best_result)

        selected = best.get("selected_ensemble") if isinstance(best.get("selected_ensemble"), dict) else {}
        threshold_filter = best.get("threshold_filter") if isinstance(best.get("threshold_filter"), dict) else {}
        retained_candidates_raw = best.get("retained_candidates")
        retained_candidates = retained_candidates_raw if isinstance(retained_candidates_raw, list) else []

        retained_count = threshold_filter.get("retained_count")
        if retained_count is None:
            retained_count = len(retained_candidates)

        compact = {
            "task_type": best.get("task_type"),
            "method": selected.get("method"),
            "val_metric": selected.get("val_metric"),
            "ensemble_size": selected.get("ensemble_size"),
            "members": selected.get("members", []),
            "retained_count": int(retained_count),
            "threshold_satisfied": bool(threshold_filter.get("threshold_satisfied", False)),
        }

        if mode == "compact":
            result: dict[str, Any] = {"compact": compact}
        else:
            result = {
                "compact": compact,
                "selected_ensemble": selected,
                "threshold_filter": threshold_filter,
                "paths": {
                    "result_json_path": best.get("result_json_path"),
                    "search_csv_path": best.get("search_csv_path"),
                    "stacker_path": selected.get("stacker_path"),
                },
                "external_test_summary": best.get("external_test_summary"),
            }
            if include:
                sorted_candidates = sorted(
                    retained_candidates,
                    key=lambda item: float(item.get("val_metric", float("-inf"))),
                    reverse=True,
                )
                if max is not None:
                    sorted_candidates = sorted_candidates[:max]
                result["retained_candidates"] = sorted_candidates

        if print_output:
            print("[SearchAgent] Summary")
            for key, value in compact.items():
                print(f"{key}: {value}")
            if mode == "full":
                print("selected_ensemble:", result.get("selected_ensemble"))
                print("threshold_filter:", result.get("threshold_filter"))
                print("paths:", result.get("paths"))
                if include:
                    print("retained_candidates:", result.get("retained_candidates", []))
                if result.get("external_test_summary") is not None:
                    print("external_test_summary:", result.get("external_test_summary"))

        return result

    def test(
        self,
        test_day_data: dict[str, tuple[np.ndarray | torch.Tensor, np.ndarray | torch.Tensor] | dict[str, Any]]
        | list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Evaluate the final ensemble day by day and report per-day, average, and median metrics.

        Args:
            test_day_data: Either a dict mapping day-name -> (X, y) tuple, or a list of
                           dicts with keys ``date``, ``X``, ``y``.

        Returns:
            Summary dict with keys: task_type, metric_name, day_<metric>, average_<metric>,
            median_<metric>, min_<metric>, day_sample_counts, num_test_days.
        """
        self._ensure_fitted()
        bundle = self._bundle
        assert bundle is not None

        normalized = self._normalize_test_day_data(test_day_data)
        day_metrics: dict[str, float] = {}
        sample_counts: dict[str, int] = {}

        for date, x_day, y_day in normalized:
            pred = self.predict(x_day)
            metric = self._compute_metric(bundle.task_info.task_type, y_day, pred)
            day_metrics[str(date)] = float(metric)
            y_tensor = to_tensor(y_day, dtype=torch.float32)
            sample_counts[str(date)] = int(y_tensor.shape[0])

        values = np.asarray(list(day_metrics.values()), dtype=float)
        metric_name = "accuracy" if bundle.task_info.task_type == "classification" else "r2"
        summary = {
            "task_type": bundle.task_info.task_type,
            "metric_name": metric_name,
            f"day_{metric_name}": day_metrics,
            f"average_{metric_name}": float(np.mean(values)),
            f"median_{metric_name}": float(np.median(values)),
            f"min_{metric_name}": float(np.min(values)),
            "day_sample_counts": sample_counts,
            "num_test_days": int(len(day_metrics)),
        }

        assert self.best_result is not None
        self.best_result["external_test_summary"] = summary
        if self.save_result_json:
            save_json(self.best_result, self.best_result["result_json_path"])
        metric_name = summary.get("metric_name", "metric")
        avg_metric = summary.get(f"average_{metric_name}", float("nan"))
        n_days = summary.get("num_test_days", 0)
        print(
            f"[SearchAgent] Test complete — {n_days} day(s), "
            f"average {metric_name}: {avg_metric:.4f}"
        )
        return summary

    def _prepare_explicit_data(
        self,
        X_train: np.ndarray | torch.Tensor,
        y_train: np.ndarray | torch.Tensor,
        X_val: np.ndarray | torch.Tensor,
        y_val: np.ndarray | torch.Tensor,
    ) -> ExplicitDataBundle:
        x_train = to_tensor(X_train, dtype=torch.float32)
        x_val = to_tensor(X_val, dtype=torch.float32)
        if x_train.ndim != 3 or x_val.ndim != 3:
            raise ValueError("X_train and X_val must both have shape [N,T,C].")
        if x_train.shape[1:] != x_val.shape[1:]:
            raise ValueError("X_train and X_val must share the same [T,C] shape.")

        resolved_task_type = infer_task_type(y_train, user_task_type=self.task_type)
        if infer_task_type(y_val, user_task_type=resolved_task_type) != resolved_task_type:
            raise ValueError("Training and validation labels imply different task types.")

        class_values: list[int | float] | None = None
        class_to_index: dict[int | float, int] | None = None
        target_mean: np.ndarray | None = None
        target_std: np.ndarray | None = None

        if resolved_task_type == "classification":
            y_train_np = to_tensor(y_train, dtype=torch.float32).squeeze().detach().cpu().numpy()
            y_val_np = to_tensor(y_val, dtype=torch.float32).squeeze().detach().cpu().numpy()
            classes = np.unique(np.concatenate([y_train_np.reshape(-1), y_val_np.reshape(-1)], axis=0))
            class_values = classes.tolist()
            class_to_index = {value: index for index, value in enumerate(class_values)}
            y_train_tensor = torch.from_numpy(np.asarray([class_to_index[value] for value in y_train_np], dtype=np.int64))
            y_val_tensor = torch.from_numpy(np.asarray([class_to_index[value] for value in y_val_np], dtype=np.int64))
            task_info = TaskInfo(task_type="classification", num_classes=len(class_values), class_values=class_values)
            y_val_raw = y_val_np.reshape(-1)
        else:
            y_train_tensor = to_tensor(y_train, dtype=torch.float32)
            y_val_tensor = to_tensor(y_val, dtype=torch.float32)
            if y_train_tensor.ndim != 3 or y_val_tensor.ndim != 3:
                raise ValueError("Regression labels must have shape [N,T,C2].")
            if y_train_tensor.shape[1:] != y_val_tensor.shape[1:]:
                raise ValueError("y_train and y_val must share the same [T,C2] shape.")
            if y_train_tensor.shape[1] != x_train.shape[1]:
                raise ValueError("Regression target sequence length must match X sequence length.")
            if self.normalize_regression_target:
                target_mean = y_train_tensor.mean(dim=(0, 1), keepdim=True).detach().cpu().numpy().astype(np.float32)
                target_std = y_train_tensor.std(dim=(0, 1), keepdim=True).clamp_min(1e-6).detach().cpu().numpy().astype(np.float32)
                target_mean_tensor = torch.from_numpy(target_mean)
                target_std_tensor = torch.from_numpy(target_std)
                y_train_tensor = (y_train_tensor - target_mean_tensor) / target_std_tensor
                y_val_tensor = (y_val_tensor - target_mean_tensor) / target_std_tensor
            task_info = TaskInfo(task_type="regression", regression_dim=int(y_train_tensor.shape[-1]))
            y_val_raw = to_tensor(y_val, dtype=torch.float32).detach().cpu().numpy()

        train_loader = DataLoader(
            TensorDataset(x_train, y_train_tensor),
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            drop_last=False,
        )
        val_loader = DataLoader(
            TensorDataset(x_val, y_val_tensor),
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            drop_last=False,
        )

        train_mean = x_train.mean(dim=(0, 1))
        train_std = x_train.std(dim=(0, 1)).clamp_min(1e-6)
        return ExplicitDataBundle(
            train_loader=train_loader,
            val_loader=val_loader,
            task_info=task_info,
            input_dim=int(x_train.shape[-1]),
            seq_len=int(x_train.shape[1]),
            train_mean=train_mean,
            train_std=train_std,
            y_val_raw=y_val_raw,
            class_values=class_values,
            class_to_index=class_to_index,
            target_mean=target_mean,
            target_std=target_std,
        )

    def _build_registry(self) -> ModuleRegistry:
        project_root, code_root = resolve_project_and_module_root(self.module_root)
        registry = ModuleRegistry(project_root=project_root, code_root=code_root, hidden_dim=self.hidden_dim, logger=self.logger)
        registry.scan()
        allowed_types = set(self.search_module_types)
        registry._modules = {
            key: meta
            for key, meta in registry.modules.items()
            if meta.module_type.lower() in allowed_types and (self.include_builtin_modules or meta.source_file != "builtin")
        }
        if self.allowed_module_keys:
            allowed = set(self.allowed_module_keys)
            registry._modules = {key: meta for key, meta in registry.modules.items() if key in allowed}
        if not registry.modules:
            raise RuntimeError("No modules remain after registry filtering.")
        return registry

    def _sample_round_candidates(
        self,
        registry: ModuleRegistry,
        builder: ModelBuilder,
        trainer: Trainer,
        bundle: ExplicitDataBundle,
        round_index: int,
    ) -> list[list[str]]:
        sampler = ArchitectureSearcher(
            registry=registry,
            builder=builder,
            trainer=trainer,
            device=self.device,
            max_trials=self.max_models_per_round,
            max_depth=self.max_depth,
            max_per_type=self.max_per_type,
            allow_repeat=self.allow_repeat,
            top_k=max(1, self.ensemble_top_m),
            random_seed=self.random_seed + round_index * 9973,
            save_csv=False,
            output_dir=self.output_dir,
            min_distinct_types=self.min_distinct_types,
            no_repeat_within_types=self.no_repeat_within_types,
            max_occurrences_per_key=self.max_occurrences_per_key,
            key_sampling_weights=self.key_sampling_weights,
            logger=self.logger,
        )
        _ = bundle
        return sampler._sample_candidates()

    def _train_candidate(
        self,
        builder: ModelBuilder,
        trainer: Trainer,
        architecture: list[str],
        train_loader: DataLoader,
        val_loader: DataLoader,
        input_dim: int,
        seq_len: int,
        round_index: int,
        local_model_id: int,
    ) -> dict[str, Any]:
        model_name = f"round_{round_index:02d}_model_{local_model_id:03d}"
        record: dict[str, Any] = {
            "model_name": model_name,
            "round_index": round_index,
            "local_model_id": local_model_id,
            "architecture_keys": list(architecture),
            "status": "ok",
            "val_metric": None,
            "num_parameters": None,
            "flops": None,
            "checkpoint_path": None,
            "history": [],
            "layer_details": [],
            "train_time_sec": None,
            "error": "",
        }
        try:
            model, arch_info = builder.build(architecture, input_dim=input_dim)
            num_parameters = count_parameters(model)
            flops = estimate_flops(model, input_shape=(2, seq_len, input_dim), device=self.device)
            train_result = trainer.fit(
                model=model,
                train_loader=train_loader,
                val_loader=val_loader,
                test_loader=None,
                model_name=model_name,
            )
            architecture_names = [
                "InputProjection",
                *[layer["module_name"] for layer in arch_info.layer_details],
                "ClassificationHead" if builder.task_type == "classification" else "RegressionHead",
            ]
            record.update(
                {
                    "architecture_names": architecture_names,
                    "layer_details": arch_info.layer_details,
                    "val_metric": float(train_result.best_val_metric),
                    "num_parameters": int(num_parameters),
                    "flops": flops,
                    "checkpoint_path": str(train_result.checkpoint_path),
                    "history": train_result.history,
                    "train_time_sec": float(train_result.train_time_sec),
                }
            )
        except Exception as exc:
            record["status"] = "failed"
            record["error"] = str(exc)
            self.logger.warning("%s failed: %s", model_name, exc)
        return record

    def _select_best_ensemble(self, bundle: ExplicitDataBundle, builder: ModelBuilder) -> dict[str, Any]:
        pool = sorted(self._retained_candidates, key=lambda item: float(item["val_metric"]), reverse=True)[: self.ensemble_top_m]
        if not pool:
            raise RuntimeError("No retained candidates available for ensemble selection.")

        member_predictions: dict[str, np.ndarray] = {}
        models_for_selection: dict[str, nn.Module] = {}
        for candidate in pool:
            model = self._load_candidate_model(candidate, builder)
            models_for_selection[candidate["model_name"]] = model
            if bundle.task_info.task_type == "classification":
                member_predictions[candidate["model_name"]] = self._predict_probabilities(model, bundle.val_loader)
            else:
                member_predictions[candidate["model_name"]] = self._predict_regression(model, bundle.val_loader)

        best_mean: dict[str, Any] | None = None
        names = [item["model_name"] for item in pool]
        for subset_size in range(1, len(names) + 1):
            for subset in itertools.combinations(names, subset_size):
                if bundle.task_info.task_type == "classification":
                    combined = np.mean([member_predictions[name] for name in subset], axis=0)
                    pred_idx = np.argmax(combined, axis=1)
                    class_values = np.asarray(bundle.class_values)
                    pred_labels = class_values[pred_idx]
                    metric = float((pred_labels.reshape(-1) == bundle.y_val_raw.reshape(-1)).mean())
                else:
                    combined = np.mean([member_predictions[name] for name in subset], axis=0)
                    metric = float(regression_r2(bundle.y_val_raw, combined))
                candidate_result = {
                    "method": "mean",
                    "members": list(subset),
                    "ensemble_size": subset_size,
                    "val_metric": metric,
                }
                if best_mean is None or metric > float(best_mean["val_metric"]) or (
                    abs(metric - float(best_mean["val_metric"])) < 1e-12 and subset_size < int(best_mean["ensemble_size"])
                ):
                    best_mean = candidate_result

        if best_mean is None:
            raise RuntimeError("Failed to select a mean ensemble.")

        best_choice = best_mean
        stacker: LogisticRegression | None = None
        selected_member_names = list(best_mean["members"])

        if bundle.task_info.task_type == "classification" and self.ensemble_method in {"stacking", "auto"} and len(pool) >= 2:
            stack_features = np.concatenate([member_predictions[item["model_name"]] for item in pool], axis=1)
            stacker = LogisticRegression(
                max_iter=self.stacking_max_iter,
                multi_class="multinomial",
                solver="lbfgs",
                random_state=self.random_seed,
            )
            stacker.fit(stack_features, bundle.y_val_raw.reshape(-1))
            stack_metric = float((stacker.predict(stack_features).reshape(-1) == bundle.y_val_raw.reshape(-1)).mean())
            stacking_choice = {
                "method": "stacking",
                "members": [item["model_name"] for item in pool],
                "ensemble_size": len(pool),
                "val_metric": stack_metric,
            }
            if self.ensemble_method == "stacking" or (
                self.ensemble_method == "auto" and stack_metric > float(best_mean["val_metric"])
            ):
                best_choice = stacking_choice
                selected_member_names = list(stacking_choice["members"])

        final_members = [self._load_candidate_model(self._find_candidate(name), builder) for name in selected_member_names]
        if best_choice["method"] != "stacking":
            stacker = None

        final_model = CombinedEnsembleModel(
            task_type=bundle.task_info.task_type,
            members=final_members,
            device=self.device,
            batch_size=self.batch_size,
            method="stacking" if best_choice["method"] == "stacking" else "mean",
            class_values=None if bundle.class_values is None else np.asarray(bundle.class_values),
            stacker=stacker,
            target_mean=bundle.target_mean,
            target_std=bundle.target_std,
        )

        stacker_path: str | None = None
        if stacker is not None:
            stacker_path = str((self.output_dir / "ensemble_stacker.pkl").resolve())
            with open(stacker_path, "wb") as handle:
                pickle.dump(stacker, handle)

        summary = {
            "method": best_choice["method"],
            "val_metric": float(best_choice["val_metric"]),
            "ensemble_size": int(best_choice["ensemble_size"]),
            "members": selected_member_names,
            "member_details": [self._find_candidate(name) for name in selected_member_names],
            "candidate_pool_model_names": [item["model_name"] for item in pool],
            "candidate_pool_size": len(pool),
            "stacker_path": stacker_path,
        }
        return {"model": final_model, "summary": summary}

    def _load_candidate_model(self, candidate: dict[str, Any], builder: ModelBuilder) -> nn.Module:
        bundle = self._bundle
        assert bundle is not None
        model, _ = builder.build(candidate["architecture_keys"], input_dim=bundle.input_dim)
        state_dict = torch.load(candidate["checkpoint_path"], map_location="cpu")
        model.load_state_dict(state_dict)
        model = model.to(self.device)
        model.eval()
        return model

    def _predict_probabilities(self, model: nn.Module, loader: DataLoader) -> np.ndarray:
        outputs: list[torch.Tensor] = []
        model.eval()
        with torch.no_grad():
            for xb, _ in loader:
                xb = xb.to(self.device)
                outputs.append(torch.softmax(model(xb), dim=1).detach().cpu())
        return torch.cat(outputs, dim=0).numpy()

    def _predict_regression(self, model: nn.Module, loader: DataLoader) -> np.ndarray:
        outputs: list[torch.Tensor] = []
        model.eval()
        with torch.no_grad():
            for xb, _ in loader:
                xb = xb.to(self.device)
                outputs.append(model(xb).detach().cpu())
        return torch.cat(outputs, dim=0).numpy()

    def _find_candidate(self, model_name: str) -> dict[str, Any]:
        for item in self._retained_candidates:
            if item["model_name"] == model_name:
                return copy.deepcopy(item)
        for item in self._all_candidates:
            if item["model_name"] == model_name:
                return copy.deepcopy(item)
        raise KeyError(f"Unknown candidate model_name: {model_name}")

    def _normalize_test_day_data(
        self,
        test_day_data: dict[str, tuple[np.ndarray | torch.Tensor, np.ndarray | torch.Tensor] | dict[str, Any]]
        | list[dict[str, Any]],
    ) -> list[tuple[str, np.ndarray | torch.Tensor, np.ndarray | torch.Tensor]]:
        normalized: list[tuple[str, np.ndarray | torch.Tensor, np.ndarray | torch.Tensor]] = []
        if isinstance(test_day_data, dict):
            for date, payload in test_day_data.items():
                if isinstance(payload, dict):
                    normalized.append((str(date), payload["X"], payload["y"]))
                else:
                    x_day, y_day = payload
                    normalized.append((str(date), x_day, y_day))
            return normalized

        for item in test_day_data:
            normalized.append((str(item["date"]), item["X"], item["y"]))
        return normalized

    def _compute_metric(self, task_type: str, y_true: np.ndarray | torch.Tensor, y_pred: np.ndarray) -> float:
        if task_type == "classification":
            y_true_tensor = to_tensor(y_true, dtype=torch.float32).squeeze()
            if y_true_tensor.ndim != 1:
                raise ValueError("Classification labels must become 1D after squeeze.")
            y_true_np = y_true_tensor.detach().cpu().numpy()
            y_pred_np = np.asarray(y_pred).reshape(-1)
            return float((y_true_np.reshape(-1) == y_pred_np.reshape(-1)).mean())

        y_true_np = to_tensor(y_true, dtype=torch.float32).detach().cpu().numpy()
        y_pred_np = np.asarray(y_pred)
        if y_true_np.shape != y_pred_np.shape:
            raise ValueError(f"Regression prediction shape mismatch: true={y_true_np.shape}, pred={y_pred_np.shape}")
        return float(regression_r2(y_true_np, y_pred_np))

    def _write_candidate_csv(self) -> None:
        headers = [
            "model_name",
            "round_index",
            "local_model_id",
            "status",
            "val_metric",
            "num_parameters",
            "flops",
            "train_time_sec",
            "architecture_keys",
            "error",
        ]
        path = self.output_dir / "search_round_models.csv"
        lines = [",".join(headers)]
        for item in self._all_candidates:
            row = {
                "model_name": item.get("model_name", ""),
                "round_index": item.get("round_index", ""),
                "local_model_id": item.get("local_model_id", ""),
                "status": item.get("status", ""),
                "val_metric": item.get("val_metric", ""),
                "num_parameters": item.get("num_parameters", ""),
                "flops": item.get("flops", ""),
                "train_time_sec": item.get("train_time_sec", ""),
                "architecture_keys": "|".join(item.get("architecture_keys", [])),
                "error": str(item.get("error", "")).replace(",", ";"),
            }
            lines.append(",".join(str(row[key]) for key in headers))
        path.write_text("\n".join(lines), encoding="utf-8")

    def _ensure_fitted(self) -> None:
        if not self._fitted or self.best_model is None or self.best_result is None:
            raise RuntimeError("Call fit(train_dataset, val_dataset) first.")
