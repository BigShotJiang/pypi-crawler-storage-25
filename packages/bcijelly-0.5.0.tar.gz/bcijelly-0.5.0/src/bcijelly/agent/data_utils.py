﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


TaskType = Literal["classification", "regression"]
SplitMode = Literal["random", "temporal"]


@dataclass
class TaskInfo:
    """Task metadata inferred from the labels."""

    task_type: TaskType
    num_classes: int | None = None
    regression_dim: int | None = None
    class_values: list[int | float] | None = None


@dataclass
class DataBundle:
    """Prepared dataloaders and input metadata."""

    train_loader: DataLoader
    val_loader: DataLoader
    test_loader: DataLoader | None
    refit_loader: DataLoader
    input_dim: int
    seq_len: int
    task_info: TaskInfo
    train_mean: torch.Tensor
    train_std: torch.Tensor
    split_mode: SplitMode


def to_tensor(x: np.ndarray | torch.Tensor, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    """Convert numpy or tensor inputs to torch.Tensor."""
    if isinstance(x, np.ndarray):
        return torch.from_numpy(x).to(dtype=dtype)
    if isinstance(x, torch.Tensor):
        return x.to(dtype=dtype)
    raise TypeError("Input must be numpy.ndarray or torch.Tensor.")


def infer_task_type(y: np.ndarray | torch.Tensor, user_task_type: TaskType | None = None) -> TaskType:
    """Infer task type from y shape unless user overrides it."""
    if user_task_type in {"classification", "regression"}:
        return user_task_type

    y_tensor = to_tensor(y)
    if y_tensor.ndim == 1:
        return "classification"
    if y_tensor.ndim == 2 and y_tensor.shape[1] == 1:
        return "classification"
    if y_tensor.ndim == 3:
        return "regression"
    raise ValueError("Cannot infer task type. Expected y to be [N], [N,1], or [N,T,C2].")


def encode_class_labels(y: np.ndarray | torch.Tensor) -> tuple[torch.Tensor, list[int | float]]:
    """Map class labels to contiguous indices."""
    y_tensor = to_tensor(y, dtype=torch.float32).squeeze()
    if y_tensor.ndim != 1:
        raise ValueError("Classification labels should be 1D after squeeze.")

    y_np = y_tensor.detach().cpu().numpy()
    classes = np.unique(y_np)
    class_to_idx = {value: index for index, value in enumerate(classes)}
    encoded = np.asarray([class_to_idx[value] for value in y_np], dtype=np.int64)
    return torch.from_numpy(encoded), classes.tolist()


def _split_indices(
    n_samples: int,
    val_ratio: float,
    test_ratio: float,
    seed: int,
    split_mode: SplitMode,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Split sample indices into train/val/test with optional test split."""
    if n_samples < 10:
        raise ValueError("At least 10 samples are required for train/val/test splitting.")
    if val_ratio <= 0:
        raise ValueError("val_ratio must be > 0 because architecture search requires validation data.")
    if test_ratio < 0:
        raise ValueError("test_ratio must be >= 0.")
    if val_ratio + test_ratio >= 1:
        raise ValueError("val_ratio + test_ratio must be < 1.")

    n_val = max(1, int(n_samples * val_ratio))
    n_test = 0 if test_ratio == 0 else max(1, int(n_samples * test_ratio))
    n_train = n_samples - n_val - n_test
    if n_train <= 0:
        raise ValueError("Invalid split ratios. Training set would be empty.")

    if split_mode == "temporal":
        indices = np.arange(n_samples)
    else:
        rng = np.random.default_rng(seed)
        indices = np.arange(n_samples)
        rng.shuffle(indices)

    train_idx = indices[:n_train]
    val_idx = indices[n_train : n_train + n_val]
    test_idx = indices[n_train + n_val :] if n_test > 0 else np.asarray([], dtype=np.int64)
    return train_idx, val_idx, test_idx


def prepare_data(
    X: np.ndarray | torch.Tensor,
    y: np.ndarray | torch.Tensor,
    task_type: TaskType | None,
    batch_size: int,
    val_ratio: float,
    test_ratio: float,
    seed: int,
    num_workers: int,
    split_mode: SplitMode = "temporal",
) -> DataBundle:
    """Prepare train/val/test dataloaders and task metadata."""
    x_tensor = to_tensor(X, dtype=torch.float32)
    if x_tensor.ndim != 3:
        raise ValueError("X must have shape [N,T,C1].")

    inferred_task = infer_task_type(y, user_task_type=task_type)

    if inferred_task == "classification":
        y_tensor, class_values = encode_class_labels(y)
        task_info = TaskInfo(
            task_type="classification",
            num_classes=len(class_values),
            class_values=class_values,
        )
    else:
        y_tensor = to_tensor(y, dtype=torch.float32)
        if y_tensor.ndim != 3:
            raise ValueError("Regression labels must have shape [N,T,C2].")
        if y_tensor.shape[0] != x_tensor.shape[0]:
            raise ValueError("X and y must have the same sample count.")
        if y_tensor.shape[1] != x_tensor.shape[1]:
            raise ValueError("Regression target sequence length must match X.")
        task_info = TaskInfo(
            task_type="regression",
            regression_dim=int(y_tensor.shape[-1]),
        )

    train_idx, val_idx, test_idx = _split_indices(
        int(x_tensor.shape[0]),
        val_ratio,
        test_ratio,
        seed,
        split_mode,
    )

    train_ds = TensorDataset(x_tensor[train_idx], y_tensor[train_idx])
    val_ds = TensorDataset(x_tensor[val_idx], y_tensor[val_idx])
    refit_idx = np.concatenate([train_idx, val_idx], axis=0)
    refit_ds = TensorDataset(x_tensor[refit_idx], y_tensor[refit_idx])

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=(split_mode == "random"), num_workers=num_workers, drop_last=False)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, drop_last=False)
    refit_loader = DataLoader(refit_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, drop_last=False)

    test_loader: DataLoader | None = None
    if len(test_idx) > 0:
        test_ds = TensorDataset(x_tensor[test_idx], y_tensor[test_idx])
        test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, drop_last=False)

    train_stats_source = x_tensor[train_idx]
    train_mean = train_stats_source.mean(dim=(0, 1))
    train_std = train_stats_source.std(dim=(0, 1)).clamp_min(1e-6)

    return DataBundle(
        train_loader=train_loader,
        val_loader=val_loader,
        test_loader=test_loader,
        refit_loader=refit_loader,
        input_dim=int(x_tensor.shape[-1]),
        seq_len=int(x_tensor.shape[1]),
        task_info=task_info,
        train_mean=train_mean,
        train_std=train_std,
        split_mode=split_mode,
    )
