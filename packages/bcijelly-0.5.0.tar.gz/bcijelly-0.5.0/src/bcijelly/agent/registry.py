﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import importlib
import importlib.util
import inspect
import sys

import torch
import torch.nn as nn

from .utils import ensure_sys_path, read_markdown_guides


BACKBONE_IMAGE_SIZE = 16
TIMM_BACKBONE_FAMILY_PREFIXES: dict[str, list[str]] = {
    "CaiT": ["cait_"],
    "CeiT": ["ceit_"],
    "CMT": ["cmt_"],
    "CoaT": ["coat_"],
    "ConTNet": ["contnet_"],
    "Container": ["container_"],
    "ConViT": ["convit_"],
    "ConvMixer": ["convmixer_"],
    "CPVT": ["cpvt_"],
    "CrossViT": ["crossvit_"],
    "DeiT": ["deit_"],
    "DViT": ["dvit_"],
    "EfficientFormer": ["efficientformer_"],
    "HATNet": ["hatnet_"],
    "LeViT": ["levit_"],
    "MobileNetV3": ["mobilenetv3_", "fbnetv3_", "lcnet_"],
    "MobileViT": ["mobilevit_"],
    "PatchConvnet": ["patchconvnet_"],
    "PIT": ["pit_"],
    "PVT": ["pvt_"],
    "ShuffleTransformer": ["shuffletransformer_"],
    "swin_transformer": ["swin_"],
    "swin_transformer_v2": ["swinv2_"],
    "swin_transformer_v2_cr": ["swinv2_cr_", "swinv2_"],
    "TnT": ["tnt_"],
    "VOLO": ["volo_"],
    "convnextv2": ["convnextv2_"],
    "resnet": ["resnet"],
    "resnext": ["resnext"],
}
TIMM_PREFERRED_TOKENS = [
    "nano",
    "micro",
    "mini",
    "tiny",
    "xxs",
    "xsmall",
    "small",
    "18",
    "050",
    "075",
    "100",
]


@dataclass
class ModuleMeta:
    """Metadata for a discovered module class."""

    key: str
    name: str
    module_type: str
    cls: type[nn.Module]
    init_kwargs: dict[str, Any]
    forward_mode: str
    output_dim: int
    image_in_channels: int | None
    source_file: str


class BuiltinTemporalConv(nn.Module):
    """Fallback temporal convolution block."""

    module_type = "conv"

    def __init__(self, in_channels: int = 64, out_channels: int = 64, kernel_size: int = 3, dropout: float = 0.1):
        super().__init__()
        padding = kernel_size // 2
        self.net = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, padding=padding),
            nn.BatchNorm1d(out_channels),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x.transpose(1, 2)).transpose(1, 2)


class BuiltinSelfAttention(nn.Module):
    """Fallback self-attention block."""

    module_type = "attention"

    def __init__(self, d_model: int = 64, nhead: int = 4, dropout: float = 0.1):
        super().__init__()
        nhead = max(1, nhead)
        if d_model % nhead != 0:
            nhead = 1
        self.attn = nn.MultiheadAttention(embed_dim=d_model, num_heads=nhead, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y, _ = self.attn(x, x, x)
        return self.norm(x + self.dropout(y))


class BuiltinMLP(nn.Module):
    """Fallback feed-forward block."""

    module_type = "mlp"

    def __init__(self, dim: int = 64, hidden_dim: int = 128, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
        )
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.net(x))


class BuiltinTemporalPooling(nn.Module):
    """Fallback temporal pooling-like context block."""

    module_type = "pooling"

    def __init__(self, dim: int = 64):
        super().__init__()
        self.gate = nn.Sequential(nn.Linear(dim, dim), nn.Sigmoid())

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        pooled = x.mean(dim=1, keepdim=True)
        gate = self.gate(pooled)
        return x * gate + x


class BuiltinFusion(nn.Module):
    """Fallback fusion block combining local and global context."""

    module_type = "fusion"

    def __init__(self, dim: int = 64):
        super().__init__()
        self.local = nn.Linear(dim, dim)
        self.global_proj = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        global_ctx = x.mean(dim=1, keepdim=True).expand_as(x)
        y = self.local(x) + self.global_proj(global_ctx)
        return self.norm(x + y)


class TimmBackboneWrapper(nn.Module):
    """Generic timm backbone wrapper used when local backbone sources are incomplete."""

    module_type = "backbone"

    def __init__(self, model_name: str, in_chans: int = 1, img_size: int = BACKBONE_IMAGE_SIZE, pretrained: bool = False):
        super().__init__()
        self.model_name = model_name
        self.model = self._create_model(model_name=model_name, in_chans=in_chans, img_size=img_size, pretrained=pretrained)

    def _create_model(self, model_name: str, in_chans: int, img_size: int, pretrained: bool) -> nn.Module:
        import timm

        attempts = [
            {"pretrained": pretrained, "in_chans": in_chans, "img_size": img_size, "num_classes": 0, "global_pool": ""},
            {"pretrained": pretrained, "in_chans": in_chans, "img_size": img_size, "num_classes": 0},
            {"pretrained": pretrained, "in_chans": in_chans, "num_classes": 0},
            {"pretrained": pretrained, "in_chans": in_chans},
            {"pretrained": pretrained},
        ]
        last_error: Exception | None = None
        for kwargs in attempts:
            try:
                model = timm.create_model(model_name, **kwargs)
                self._try_reset_classifier(model)
                return model
            except Exception as exc:
                last_error = exc
        raise RuntimeError(f"timm.create_model failed for {model_name}: {last_error}")

    @staticmethod
    def _try_reset_classifier(model: nn.Module) -> None:
        reset_classifier = getattr(model, "reset_classifier", None)
        if reset_classifier is None:
            return
        try:
            reset_classifier(0, "")
        except Exception:
            try:
                reset_classifier(0)
            except Exception:
                pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output: Any
        if hasattr(self.model, "forward_features"):
            output = self.model.forward_features(x)
        else:
            output = self.model(x)
        return self._extract_tensor(output)

    @staticmethod
    def _extract_tensor(output: Any) -> torch.Tensor:
        if isinstance(output, torch.Tensor):
            return output
        if isinstance(output, (tuple, list)):
            tensors = [item for item in output if isinstance(item, torch.Tensor)]
            if tensors:
                return tensors[-1]
        if isinstance(output, dict):
            tensors = [value for value in output.values() if isinstance(value, torch.Tensor)]
            if tensors:
                return tensors[-1]
        raise RuntimeError("timm backbone wrapper did not return a tensor-like output")


class ModuleRegistry:
    """Scan repository modules, read markdown usage docs, and register usable blocks."""

    def __init__(self, project_root: str | Path, code_root: str | Path, hidden_dim: int, logger: Any | None = None):
        self.project_root = Path(project_root)
        self.code_root = Path(code_root)
        self.hidden_dim = hidden_dim
        self.logger = logger

        self._modules: dict[str, ModuleMeta] = {}
        self.scan_errors: list[dict[str, str]] = []
        self.markdown_guides = read_markdown_guides(self.project_root)
        self.timm_backbone_count = 0
        self._availability_cache: dict[str, bool] = {}

    @property
    def modules(self) -> dict[str, ModuleMeta]:
        return self._modules

    def keys(self) -> list[str]:
        return list(self._modules.keys())

    def get(self, key: str) -> ModuleMeta:
        return self._modules[key]

    def by_type(self) -> dict[str, list[str]]:
        grouped: dict[str, list[str]] = {}
        for key, meta in self._modules.items():
            grouped.setdefault(meta.module_type, []).append(key)
        return grouped

    def scan(self) -> None:
        """Scan python files under code_root and register importable nn.Module classes."""
        ensure_sys_path(self.project_root)
        py_files = [
            path
            for path in self.code_root.rglob("*.py")
            if "__pycache__" not in str(path)
            and path.name != "__init__.py"
            and ".egg-info" not in str(path)
        ]

        backbone_fallbacks: list[Path] = []
        for file_path in py_files:
            registered_count = 0
            module = self._safe_import(file_path)
            if module is not None:
                for class_name, cls in inspect.getmembers(module, inspect.isclass):
                    if not issubclass(cls, nn.Module) or cls is nn.Module:
                        continue
                    if cls.__module__ != module.__name__:
                        continue

                    module_type = self._infer_module_type(cls, file_path)
                    meta = self._probe_module_class(cls, module_type, file_path)
                    if meta is None:
                        continue
                    self._register_meta(meta, f"{module_type}.{class_name}")
                    registered_count += 1

            if self._is_backbone_file(file_path) and registered_count == 0:
                backbone_fallbacks.append(file_path)

        self._register_timm_backbone_fallbacks(backbone_fallbacks)
        self._register_builtins()
        if self.logger is not None:
            self.logger.info(
                "Registry scan complete. modules=%d markdown_guides=%d timm_backbones=%d",
                len(self._modules),
                len(self.markdown_guides),
                self.timm_backbone_count,
            )

    def _safe_import(self, file_path: Path):
        ensure_sys_path(self.project_root)

        skip_reason = self._precheck_file_dependencies(file_path)
        if skip_reason is not None:
            self.scan_errors.append({"file": str(file_path), "error": skip_reason})
            if self.logger is not None:
                self.logger.warning("Skip import %s: %s", file_path, skip_reason)
            return None

        qualified_name = self._infer_qualified_module_name(file_path)
        first_error: Exception | None = None
        if qualified_name is not None:
            try:
                if qualified_name in sys.modules:
                    return importlib.reload(sys.modules[qualified_name])
                return importlib.import_module(qualified_name)
            except Exception as exc:
                first_error = exc

        dynamic_name = f"bj_agent_dynamic_{hashlib.md5(str(file_path).encode('utf-8')).hexdigest()[:12]}"
        try:
            spec = importlib.util.spec_from_file_location(dynamic_name, file_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"Cannot build module spec: {file_path}")
            module = importlib.util.module_from_spec(spec)
            sys.modules[dynamic_name] = module
            spec.loader.exec_module(module)
            return module
        except Exception as exc:
            sys.modules.pop(dynamic_name, None)
            error_message = str(exc)
            if first_error is not None:
                error_message = f"import_module={first_error}; spec_import={exc}"
            self.scan_errors.append({"file": str(file_path), "error": error_message})
            if self.logger is not None:
                self.logger.warning("Skip import %s: %s", file_path, error_message)
            return None

    def _precheck_file_dependencies(self, file_path: Path) -> str | None:
        try:
            source = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return None

        helper_map = {
            "from ._builder import": "_builder.py",
            "from ._registry import": "_registry.py",
            "from ._features import": "_features.py",
            "from ._features_fx import": "_features_fx.py",
            "from ._manipulate import": "_manipulate.py",
            "from ._efficientnet_builder import": "_efficientnet_builder.py",
            "from ._efficientnet_blocks import": "_efficientnet_blocks.py",
            "from .vision_transformer import": "vision_transformer.py",
        }
        missing_helpers = [
            helper_name
            for pattern, helper_name in helper_map.items()
            if pattern in source and not (file_path.parent / helper_name).exists()
        ]
        if missing_helpers:
            unique_helpers = ", ".join(sorted(set(missing_helpers)))
            return (
                "missing local helper modules "
                f"[{unique_helpers}] required by this file; a timm backbone fallback will be used if available"
            )

        timm_api_map = {
            "from timm.layers import": "timm.layers",
            "from timm.models.layers.helpers import": "timm.models.layers.helpers",
            "from timm.models.efficientnet_blocks import": "timm.models.efficientnet_blocks",
        }
        for pattern, module_name in timm_api_map.items():
            if pattern in source and not self._module_available(module_name):
                return (
                    f"installed environment does not provide '{module_name}' required by this local source; "
                    "a timm backbone fallback will be used if available"
                )

        return None

    def _module_available(self, module_name: str) -> bool:
        if module_name not in self._availability_cache:
            try:
                importlib.import_module(module_name)
                self._availability_cache[module_name] = True
            except Exception:
                self._availability_cache[module_name] = False
        return self._availability_cache[module_name]

    def _infer_qualified_module_name(self, file_path: Path) -> str | None:
        try:
            relative = file_path.relative_to(self.project_root).with_suffix("")
        except Exception:
            return None
        parts = list(relative.parts)
        if not parts:
            return None
        if not all(part.isidentifier() for part in parts):
            return None
        return ".".join(parts)

    def _infer_module_type(self, cls: type[nn.Module], file_path: Path) -> str:
        explicit = getattr(cls, "module_type", None)
        if isinstance(explicit, str) and explicit.strip():
            return explicit.lower()

        try:
            relative = file_path.relative_to(self.code_root)
            if len(relative.parts) >= 2:
                return relative.parts[0].lower()
        except Exception:
            pass
        return "unknown"

    def _probe_module_class(self, cls: type[nn.Module], module_type: str, file_path: Path) -> ModuleMeta | None:
        return self._probe_meta(
            cls=cls,
            module_type=module_type,
            source_file=str(file_path.resolve()),
            explicit_kwargs=None,
            display_name=cls.__name__,
        )

    def _probe_meta(
        self,
        cls: type[nn.Module],
        module_type: str,
        source_file: str,
        explicit_kwargs: dict[str, Any] | None,
        display_name: str,
    ) -> ModuleMeta | None:
        candidate_kwargs: list[dict[str, Any]] = []
        if explicit_kwargs is not None:
            candidate_kwargs.append(explicit_kwargs)
        else:
            inferred_kwargs = self._infer_init_kwargs(cls)
            if inferred_kwargs is not None:
                candidate_kwargs.append(inferred_kwargs)
            candidate_kwargs.append({})

        instance = None
        used_kwargs: dict[str, Any] | None = None
        for kwargs in candidate_kwargs:
            try:
                instance = cls(**kwargs)
                used_kwargs = kwargs
                break
            except Exception:
                continue

        if instance is None or used_kwargs is None:
            return None

        forward_mode, output_dim, image_in_channels = self._infer_forward_mode_and_output_dim(instance)
        if forward_mode is None or output_dim is None:
            return None

        return ModuleMeta(
            key="",
            name=display_name,
            module_type=module_type,
            cls=cls,
            init_kwargs=used_kwargs,
            forward_mode=forward_mode,
            output_dim=output_dim,
            image_in_channels=image_in_channels,
            source_file=source_file,
        )

    def _infer_init_kwargs(self, cls: type[nn.Module]) -> dict[str, Any] | None:
        try:
            signature = inspect.signature(cls.__init__)
        except Exception:
            return None

        kwargs: dict[str, Any] = {}
        for parameter in list(signature.parameters.values())[1:]:
            if parameter.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            mapped = self._map_param_value(parameter.name)
            if mapped is not None:
                kwargs[parameter.name] = mapped
                continue
            if parameter.default is inspect.Parameter.empty:
                return None
        return kwargs

    def _map_param_value(self, name: str) -> Any | None:
        lowered = name.lower()
        hidden_dim = self.hidden_dim

        if lowered in {"in_channels", "in_channel", "input_dim", "embed_dim", "dim", "d_model", "channel", "channels", "inp", "in_chans", "input_channel"}:
            return hidden_dim
        if lowered in {"out_channels", "out_channel", "out_dim", "planes", "out_planes", "num_features", "output_channel"}:
            return hidden_dim
        if lowered in {"in_planes", "inplanes", "c1", "dim_in"}:
            return hidden_dim
        if lowered in {"c2", "dim_out"}:
            return hidden_dim
        if lowered in {"kernel_size", "ks"}:
            return 3
        if lowered in {"stride", "s"}:
            return 1
        if lowered in {"padding", "p"}:
            return 1
        if lowered in {"dilation"}:
            return 1
        if lowered in {"groups", "group", "grounps"}:
            return 1
        if lowered in {"ratio", "reduction"}:
            return 4
        if lowered in {"k", "num_kernels"}:
            return 4
        if lowered in {"temperature", "temprature"}:
            return 30
        if lowered in {"drop", "dropout", "drop_rate", "dropout_rate", "attn_drop", "proj_drop"}:
            return 0.1
        if lowered in {"mlp_ratio"}:
            return 2.0
        if lowered in {"num_classes"}:
            return 4
        if lowered in {"heads", "num_heads", "head", "h", "nhead"}:
            return 4 if hidden_dim % 4 == 0 else 1
        if lowered in {"d_k", "dk", "qk_dim", "key_dim"}:
            return max(1, hidden_dim // 4)
        if lowered in {"d_v", "dv", "value_dim"}:
            return max(1, hidden_dim // 4)
        if lowered in {"img_size", "input_size", "size", "window_size", "patch_size"}:
            return BACKBONE_IMAGE_SIZE
        if lowered in {"seq_len", "length", "max_len", "num_patches"}:
            return 16
        if "bias" in lowered:
            return False
        return None

    def _infer_forward_mode_and_output_dim(self, module: nn.Module) -> tuple[str | None, int | None, int | None]:
        module.eval()
        x_seq = torch.randn(2, 16, self.hidden_dim)
        image_in_channels = self._infer_image_input_channels(module)
        x_img = torch.randn(2, image_in_channels, 16, self.hidden_dim)
        attempts: list[tuple[str, tuple[torch.Tensor, ...]]] = [
            ("seq", (x_seq,)),
            ("seq_qkv", (x_seq, x_seq, x_seq)),
            ("img", (x_img,)),
            ("img_qkv", (x_img, x_img, x_img)),
        ]

        with torch.no_grad():
            for forward_mode, args in attempts:
                try:
                    output = module(*args)
                    tensor = self._unwrap_output(output)
                    if not isinstance(tensor, torch.Tensor):
                        continue
                    seq_tensor = self._to_sequence(tensor, target_t=16, reference_channels=self.hidden_dim)
                    return forward_mode, int(seq_tensor.shape[-1]), image_in_channels if forward_mode.startswith("img") else None
                except Exception:
                    continue
        return None, None, None

    def _infer_image_input_channels(self, module: nn.Module) -> int:
        for attr_name in ("in_chans", "in_channels", "input_channels", "input_channel"):
            value = getattr(module, attr_name, None)
            if isinstance(value, int) and value > 0:
                return value

        for sub_module in module.modules():
            if isinstance(sub_module, nn.Conv2d) and sub_module.in_channels > 0:
                return int(sub_module.in_channels)

        return 1

    @staticmethod
    def _unwrap_output(output: Any) -> Any:
        if isinstance(output, torch.Tensor):
            return output
        if isinstance(output, (tuple, list)) and output:
            return output[-1]
        if isinstance(output, dict) and output:
            return output[next(reversed(output.keys()))]
        return output

    @staticmethod
    def _to_sequence(tensor: torch.Tensor, target_t: int, reference_channels: int) -> torch.Tensor:
        if tensor.ndim == 4:
            tensor = tensor.mean(dim=3).permute(0, 2, 1)
        elif tensor.ndim == 3:
            if tensor.shape[1] == target_t and tensor.shape[2] != target_t:
                pass
            elif tensor.shape[2] == target_t and tensor.shape[1] != target_t:
                tensor = tensor.permute(0, 2, 1)
            elif tensor.shape[1] == reference_channels and tensor.shape[2] != reference_channels:
                tensor = tensor.permute(0, 2, 1)
        elif tensor.ndim == 2:
            tensor = tensor.unsqueeze(1).repeat(1, target_t, 1)
        else:
            raise RuntimeError(f"Unsupported tensor rank {tensor.ndim}")

        if tensor.shape[1] != target_t:
            tensor = torch.nn.functional.interpolate(
                tensor.permute(0, 2, 1),
                size=target_t,
                mode="linear",
                align_corners=False,
            ).permute(0, 2, 1)
        return tensor

    def _is_backbone_file(self, file_path: Path) -> bool:
        return file_path.parent.name.lower() == "backbone"

    def _register_meta(self, meta: ModuleMeta, key_base: str) -> None:
        key = key_base
        suffix = 1
        while key in self._modules:
            suffix += 1
            key = f"{key_base}_{suffix}"
        meta.key = key
        self._modules[key] = meta

    def _register_timm_backbone_fallbacks(self, backbone_files: list[Path]) -> None:
        if not backbone_files:
            return

        try:
            import timm
        except Exception as exc:
            if self.logger is not None:
                self.logger.warning("timm is unavailable, cannot register backbone fallbacks: %s", exc)
            return

        try:
            available_models = sorted(timm.list_models(pretrained=False))
        except Exception as exc:
            if self.logger is not None:
                self.logger.warning("Failed to enumerate timm models for backbone fallbacks: %s", exc)
            return

        for file_path in sorted(set(backbone_files)):
            family_name = file_path.stem
            prefixes = TIMM_BACKBONE_FAMILY_PREFIXES.get(family_name, self._guess_timm_prefixes(family_name))
            model_name = self._pick_timm_model(available_models, prefixes)
            if model_name is None:
                continue

            meta = self._probe_meta(
                cls=TimmBackboneWrapper,
                module_type="backbone",
                source_file=f"{str(file_path.resolve())} -> timm:{model_name}",
                explicit_kwargs={
                    "model_name": model_name,
                    "in_chans": 1,
                    "img_size": BACKBONE_IMAGE_SIZE,
                    "pretrained": False,
                },
                display_name=f"{family_name}(timm:{model_name})",
            )
            if meta is None:
                continue

            self._register_meta(meta, f"backbone.{family_name}.timm")
            self.timm_backbone_count += 1
            if self.logger is not None:
                self.logger.info("Registered timm backbone fallback for %s using model=%s", family_name, model_name)

    def _guess_timm_prefixes(self, family_name: str) -> list[str]:
        lowered = family_name.lower()
        compact = lowered.replace("_", "")
        return [f"{lowered}_", f"{compact}_", lowered]

    def _pick_timm_model(self, available_models: list[str], prefixes: list[str]) -> str | None:
        matches = [
            name
            for name in available_models
            if any(name.startswith(prefix) for prefix in prefixes)
        ]
        if not matches:
            return None
        return min(matches, key=self._timm_model_sort_key)

    def _timm_model_sort_key(self, model_name: str) -> tuple[int, int, int, str]:
        lowered = model_name.lower()
        token_rank = len(TIMM_PREFERRED_TOKENS)
        for index, token in enumerate(TIMM_PREFERRED_TOKENS):
            if token in lowered:
                token_rank = index
                break
        heavy_penalty = 1 if any(token in lowered for token in ["large", "base", "huge", "384", "512"]) else 0
        return heavy_penalty, token_rank, len(model_name), model_name

    def _register_builtins(self) -> None:
        builtin_metas = [
            ModuleMeta(
                key="builtin.conv.BuiltinTemporalConv",
                name="BuiltinTemporalConv",
                module_type="conv",
                cls=BuiltinTemporalConv,
                init_kwargs={"in_channels": self.hidden_dim, "out_channels": self.hidden_dim, "kernel_size": 3, "dropout": 0.1},
                forward_mode="seq",
                output_dim=self.hidden_dim,
                image_in_channels=None,
                source_file="builtin",
            ),
            ModuleMeta(
                key="builtin.attention.BuiltinSelfAttention",
                name="BuiltinSelfAttention",
                module_type="attention",
                cls=BuiltinSelfAttention,
                init_kwargs={"d_model": self.hidden_dim, "nhead": 4 if self.hidden_dim % 4 == 0 else 1, "dropout": 0.1},
                forward_mode="seq",
                output_dim=self.hidden_dim,
                image_in_channels=None,
                source_file="builtin",
            ),
            ModuleMeta(
                key="builtin.mlp.BuiltinMLP",
                name="BuiltinMLP",
                module_type="mlp",
                cls=BuiltinMLP,
                init_kwargs={"dim": self.hidden_dim, "hidden_dim": self.hidden_dim * 2, "dropout": 0.1},
                forward_mode="seq",
                output_dim=self.hidden_dim,
                image_in_channels=None,
                source_file="builtin",
            ),
            ModuleMeta(
                key="builtin.pooling.BuiltinTemporalPooling",
                name="BuiltinTemporalPooling",
                module_type="pooling",
                cls=BuiltinTemporalPooling,
                init_kwargs={"dim": self.hidden_dim},
                forward_mode="seq",
                output_dim=self.hidden_dim,
                image_in_channels=None,
                source_file="builtin",
            ),
            ModuleMeta(
                key="builtin.fusion.BuiltinFusion",
                name="BuiltinFusion",
                module_type="fusion",
                cls=BuiltinFusion,
                init_kwargs={"dim": self.hidden_dim},
                forward_mode="seq",
                output_dim=self.hidden_dim,
                image_in_channels=None,
                source_file="builtin",
            ),
        ]

        for meta in builtin_metas:
            if meta.key not in self._modules:
                self._modules[meta.key] = meta

