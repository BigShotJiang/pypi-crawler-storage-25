﻿from __future__ import annotations

import numpy as np
import torch


def classification_accuracy(logits: torch.Tensor, labels: torch.Tensor) -> float:
    """Compute accuracy from logits."""
    pred = torch.argmax(logits, dim=1)
    return float((pred == labels).float().mean().item())


def regression_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Compute R2 score with sklearn and a numpy fallback."""
    try:
        from sklearn.metrics import r2_score

        score = float(r2_score(y_true.reshape(-1), y_pred.reshape(-1)))
    except Exception:
        y_true_flat = y_true.reshape(-1)
        y_pred_flat = y_pred.reshape(-1)
        ss_res = float(np.sum((y_true_flat - y_pred_flat) ** 2))
        ss_tot = float(np.sum((y_true_flat - np.mean(y_true_flat)) ** 2))
        score = 1.0 - ss_res / (ss_tot + 1e-12)

    if np.isnan(score):
        return -1e9
    return score
