﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from .registry import ModuleMeta, ModuleRegistry


@dataclass
class ArchitectureInfo:
    """Structured architecture description."""

    module_keys: list[str]
    layer_details: list[dict[str, Any]]


class ModuleBlockAdapter(nn.Module):
    """Adapt arbitrary module IO to unified [N,T,C] sequence tensors."""

    def __init__(
        self,
        module: nn.Module,
        forward_mode: str,
        hidden_dim: int,
        output_dim: int,
        image_in_channels: int | None,
    ):
        super().__init__()
        self.module = module
        self.forward_mode = forward_mode
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.image_in_channels = image_in_channels
        self.output_proj: nn.Module = nn.Identity() if output_dim == hidden_dim else nn.Linear(output_dim, hidden_dim)
        self.image_proj: nn.Module = nn.Identity() if not image_in_channels or image_in_channels == 1 else nn.Conv2d(1, image_in_channels, kernel_size=1)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        y = self._forward_raw(x)
        y = self._unwrap_output(y)
        if not isinstance(y, torch.Tensor):
            raise RuntimeError("Module output is not a tensor.")

        y = self._to_sequence(y, target_t=residual.shape[1], reference_channels=residual.shape[-1])
        if y.shape[-1] != self.hidden_dim:
            if isinstance(self.output_proj, nn.Linear) and y.shape[-1] == self.output_proj.in_features:
                y = self.output_proj(y)
            else:
                y = self._resize_feature_dim(y, self.hidden_dim)
        else:
            y = self.output_proj(y)

        y = self.norm(y)
        if y.shape == residual.shape:
            y = y + residual
        return y

    def _forward_raw(self, x: torch.Tensor) -> Any:
        if self.forward_mode == "seq":
            return self.module(x)
        if self.forward_mode == "seq_qkv":
            return self.module(x, x, x)
        if self.forward_mode == "img":
            x_img = self._sequence_to_image(x)
            x_img = self.image_proj(x_img)
            return self.module(x_img)
        if self.forward_mode == "img_qkv":
            x_img = self._sequence_to_image(x)
            x_img = self.image_proj(x_img)
            return self.module(x_img, x_img, x_img)
        raise ValueError(f"Unsupported forward mode: {self.forward_mode}")

    @staticmethod
    def _sequence_to_image(x: torch.Tensor) -> torch.Tensor:
        return x.unsqueeze(1).contiguous()

    @staticmethod
    def _unwrap_output(output: Any) -> Any:
        if isinstance(output, torch.Tensor):
            return output
        if isinstance(output, (tuple, list)) and output:
            return output[0]
        if isinstance(output, dict) and output:
            return output[next(iter(output.keys()))]
        return output

    @staticmethod
    def _to_sequence(tensor: torch.Tensor, target_t: int, reference_channels: int) -> torch.Tensor:
        if tensor.ndim == 4:
            tensor = tensor.mean(dim=3).permute(0, 2, 1)
        elif tensor.ndim == 3:
            if tensor.shape[1] == target_t and tensor.shape[2] != target_t:
                pass
            elif tensor.shape[2] == target_t and tensor.shape[1] != target_t:
                tensor = tensor.permute(0, 2, 1)
            elif tensor.shape[1] == reference_channels and tensor.shape[2] != reference_channels:
                tensor = tensor.permute(0, 2, 1)
        elif tensor.ndim == 2:
            tensor = tensor.unsqueeze(1).repeat(1, target_t, 1)
        else:
            raise RuntimeError(f"Unsupported tensor rank from module output: {tensor.ndim}")

        if tensor.shape[1] != target_t:
            tensor = F.interpolate(tensor.permute(0, 2, 1), size=target_t, mode="linear", align_corners=False).permute(0, 2, 1)
        return tensor

    @staticmethod
    def _resize_feature_dim(tensor: torch.Tensor, target_dim: int) -> torch.Tensor:
        current_dim = int(tensor.shape[-1])
        if current_dim == target_dim:
            return tensor
        if current_dim > target_dim:
            return tensor[..., :target_dim]
        padding = torch.zeros(*tensor.shape[:-1], target_dim - current_dim, device=tensor.device, dtype=tensor.dtype)
        return torch.cat([tensor, padding], dim=-1)


class CandidateTimeSeriesModel(nn.Module):
    """Unified time-series model skeleton."""

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        blocks: Sequence[ModuleBlockAdapter],
        task_type: str,
        num_classes: int | None,
        regression_dim: int | None,
        input_mean: torch.Tensor | None = None,
        input_std: torch.Tensor | None = None,
    ):
        super().__init__()
        self.task_type = task_type
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.blocks = nn.ModuleList(blocks)
        self.final_norm = nn.LayerNorm(hidden_dim)

        if input_mean is not None:
            self.register_buffer("input_mean", input_mean.view(1, 1, -1).float())
        else:
            self.input_mean = None
        if input_std is not None:
            self.register_buffer("input_std", input_std.view(1, 1, -1).float())
        else:
            self.input_std = None

        if task_type == "classification":
            if num_classes is None:
                raise ValueError("num_classes is required for classification.")
            self.head = nn.Linear(hidden_dim, num_classes)
        elif task_type == "regression":
            if regression_dim is None:
                raise ValueError("regression_dim is required for regression.")
            self.head = nn.Linear(hidden_dim, regression_dim)
        else:
            raise ValueError(f"Unsupported task_type: {task_type}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 3:
            raise ValueError("Input must have shape [N,T,C].")

        if self.input_mean is not None and self.input_std is not None:
            x = (x - self.input_mean) / self.input_std

        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        x = self.final_norm(x)

        if self.task_type == "classification":
            return self.head(x.mean(dim=1))
        return self.head(x)


class ModelBuilder:
    """Build candidate models from registry keys."""

    def __init__(
        self,
        registry: ModuleRegistry,
        hidden_dim: int,
        task_type: str,
        num_classes: int | None = None,
        regression_dim: int | None = None,
        input_mean: torch.Tensor | None = None,
        input_std: torch.Tensor | None = None,
    ):
        self.registry = registry
        self.hidden_dim = hidden_dim
        self.task_type = task_type
        self.num_classes = num_classes
        self.regression_dim = regression_dim
        self.input_mean = input_mean
        self.input_std = input_std

    def build(self, architecture_keys: Sequence[str], input_dim: int) -> tuple[nn.Module, ArchitectureInfo]:
        """Build one candidate model and its structured description."""
        blocks: list[ModuleBlockAdapter] = []
        details: list[dict[str, Any]] = []

        for index, key in enumerate(architecture_keys):
            meta: ModuleMeta = self.registry.get(key)
            module = meta.cls(**meta.init_kwargs)
            adapter = ModuleBlockAdapter(
                module=module,
                forward_mode=meta.forward_mode,
                hidden_dim=self.hidden_dim,
                output_dim=meta.output_dim,
                image_in_channels=meta.image_in_channels,
            )
            blocks.append(adapter)
            details.append(
                {
                    "layer_index": index,
                    "registry_key": key,
                    "module_name": meta.name,
                    "module_type": meta.module_type,
                    "forward_mode": meta.forward_mode,
                    "source_file": meta.source_file,
                    "init_kwargs": meta.init_kwargs,
                }
            )

        model = CandidateTimeSeriesModel(
            input_dim=input_dim,
            hidden_dim=self.hidden_dim,
            blocks=blocks,
            task_type=self.task_type,
            num_classes=self.num_classes,
            regression_dim=self.regression_dim,
            input_mean=self.input_mean,
            input_std=self.input_std,
        )
        return model, ArchitectureInfo(module_keys=list(architecture_keys), layer_details=details)
