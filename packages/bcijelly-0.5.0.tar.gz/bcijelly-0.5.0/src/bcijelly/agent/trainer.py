﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .evaluator import regression_r2


@dataclass
class TrainResult:
    """Training result summary for one candidate architecture."""

    best_val_metric: float
    test_metric: float | None
    best_epoch: int
    checkpoint_path: str
    train_time_sec: float
    history: list[dict[str, Any]]


class Trainer:
    """Standard train/val/test trainer with early stopping."""

    def __init__(
        self,
        task_type: str,
        device: torch.device,
        epochs: int,
        patience: int,
        learning_rate: float,
        weight_decay: float,
        output_dir: str | Path,
        logger: Any | None = None,
    ):
        self.task_type = task_type
        self.device = device
        self.epochs = epochs
        self.patience = patience
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logger

    def fit(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        test_loader: DataLoader | None,
        model_name: str,
    ) -> TrainResult:
        """Train one model and return best validation and optional test metrics."""
        model = model.to(self.device)
        criterion: nn.Module = self._build_criterion()
        optimizer = torch.optim.Adam(model.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)

        best_metric = -1e18
        best_epoch = -1
        best_state: dict[str, torch.Tensor] | None = None
        no_improve = 0
        history: list[dict[str, Any]] = []
        start_time = perf_counter()

        for epoch in range(1, self.epochs + 1):
            train_loss = self._train_epoch(model, train_loader, criterion, optimizer)
            val_loss, val_metric = self.evaluate_loader(model, val_loader, criterion)
            history.append(
                {
                    "epoch": epoch,
                    "train_loss": float(train_loss),
                    "val_loss": float(val_loss),
                    "val_metric": float(val_metric),
                }
            )

            if self.logger is not None:
                self.logger.info(
                    "[%s] epoch=%d train_loss=%.5f val_loss=%.5f val_metric=%.5f",
                    model_name,
                    epoch,
                    train_loss,
                    val_loss,
                    val_metric,
                )

            if val_metric > best_metric:
                best_metric = float(val_metric)
                best_epoch = epoch
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                no_improve = 0
            else:
                no_improve += 1

            if no_improve >= self.patience:
                if self.logger is not None:
                    self.logger.info("[%s] early stopping at epoch %d", model_name, epoch)
                break

        if best_state is None:
            raise RuntimeError("Training did not produce a valid model state.")

        checkpoint_path = self.output_dir / f"{model_name}_best.pt"
        torch.save(best_state, checkpoint_path)

        model.load_state_dict(best_state)
        model.to(self.device)

        test_metric: float | None = None
        if test_loader is not None:
            _, test_metric = self.evaluate_loader(model, test_loader, criterion)

        return TrainResult(
            best_val_metric=float(best_metric),
            test_metric=None if test_metric is None else float(test_metric),
            best_epoch=best_epoch,
            checkpoint_path=str(checkpoint_path.resolve()),
            train_time_sec=float(perf_counter() - start_time),
            history=history,
        )

    def refit(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        epochs: int,
        model_name: str,
        learning_rate: float | None = None,
    ) -> str:
        """Refit the selected best model on train+val data without a validation split."""
        model = model.to(self.device)
        criterion = self._build_criterion()
        optimizer = torch.optim.Adam(
            model.parameters(),
            lr=self.learning_rate if learning_rate is None else learning_rate,
            weight_decay=self.weight_decay,
        )
        model.train()
        for epoch in range(1, epochs + 1):
            train_loss = self._train_epoch(model, train_loader, criterion, optimizer)
            if self.logger is not None:
                self.logger.info("[%s] refit_epoch=%d train_loss=%.5f", model_name, epoch, train_loss)
        checkpoint_path = self.output_dir / f"{model_name}_refit.pt"
        torch.save({key: value.detach().cpu().clone() for key, value in model.state_dict().items()}, checkpoint_path)
        return str(checkpoint_path.resolve())

    def _build_criterion(self) -> nn.Module:
        return nn.CrossEntropyLoss() if self.task_type == "classification" else nn.MSELoss()

    def _train_epoch(
        self,
        model: nn.Module,
        loader: DataLoader,
        criterion: nn.Module,
        optimizer: torch.optim.Optimizer,
    ) -> float:
        model.train()
        total_loss = 0.0
        total_batches = 0

        for xb, yb in loader:
            xb = xb.to(self.device)
            yb = yb.to(self.device)

            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = self._compute_loss(criterion, pred, yb)
            loss.backward()
            optimizer.step()

            total_loss += float(loss.item())
            total_batches += 1

        return total_loss / max(1, total_batches)

    def evaluate_loader(
        self,
        model: nn.Module,
        loader: DataLoader,
        criterion: nn.Module | None = None,
    ) -> tuple[float | None, float]:
        """Evaluate a model on a dataloader and return optional loss plus metric."""
        model.eval()
        total_loss = 0.0
        total_batches = 0
        ys_true: list[np.ndarray] = []
        ys_pred: list[np.ndarray] = []

        with torch.no_grad():
            for xb, yb in loader:
                xb = xb.to(self.device)
                yb = yb.to(self.device)
                pred = model(xb)

                if criterion is not None:
                    loss = self._compute_loss(criterion, pred, yb)
                    total_loss += float(loss.item())
                    total_batches += 1

                if self.task_type == "classification":
                    ys_true.append(yb.detach().cpu().numpy())
                    ys_pred.append(torch.argmax(pred, dim=1).detach().cpu().numpy())
                else:
                    ys_true.append(yb.detach().cpu().numpy())
                    ys_pred.append(pred.detach().cpu().numpy())

        y_true = np.concatenate(ys_true, axis=0)
        y_pred = np.concatenate(ys_pred, axis=0)

        if self.task_type == "classification":
            metric = float((y_true.reshape(-1) == y_pred.reshape(-1)).mean())
        else:
            metric = float(regression_r2(y_true, y_pred))

        avg_loss = None if criterion is None else total_loss / max(1, total_batches)
        return avg_loss, metric

    def _compute_loss(self, criterion: nn.Module, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        if self.task_type == "classification":
            if target.ndim > 1:
                target = target.squeeze(-1)
            target = target.long()
            return criterion(pred, target)

        if pred.shape != target.shape:
            raise RuntimeError(f"Regression output shape mismatch: pred={tuple(pred.shape)}, target={tuple(target.shape)}")
        return criterion(pred, target)
