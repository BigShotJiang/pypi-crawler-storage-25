﻿from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import json
import logging
import random
import re
import sys

import numpy as np
import torch
import torch.nn as nn


KNOWN_MODULE_DIRS = {"attention", "conv", "backbone", "mlp", "rep"}


def ensure_dir(path: str | Path) -> Path:
    """Create a directory if it does not exist."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def now_str() -> str:
    """Return a filesystem friendly timestamp."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def setup_logger(name: str, log_file: str | Path | None = None) -> logging.Logger:
    """Build a logger with stdout and optional file handlers."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if logger.handlers:
        return logger

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    if log_file is not None:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def set_seed(seed: int) -> None:
    """Set random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def count_parameters(model: nn.Module) -> int:
    """Count trainable model parameters."""
    total = 0
    for parameter in model.parameters():
        if not parameter.requires_grad:
            continue
        try:
            total += int(parameter.numel())
        except Exception:
            continue
    return total


def estimate_flops(model: nn.Module, input_shape: tuple[int, int, int], device: torch.device) -> int | None:
    """Estimate FLOPs for common Linear/Conv layers via hooks."""
    hooks = []
    flops = {"total": 0}
    original_device = next(model.parameters(), torch.empty(0)).device

    def linear_hook(module: nn.Linear, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        x = inputs[0]
        batch = int(x.shape[0])
        seq_len = int(x.shape[1]) if x.ndim == 3 else 1
        flops["total"] += batch * seq_len * module.in_features * module.out_features

    def conv1d_hook(module: nn.Conv1d, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        y = output if isinstance(output, torch.Tensor) else output[0]
        batch, out_channels, out_len = y.shape
        kernel_ops = module.kernel_size[0] * (module.in_channels // module.groups)
        flops["total"] += int(batch * out_channels * out_len * kernel_ops)

    def conv2d_hook(module: nn.Conv2d, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        y = output if isinstance(output, torch.Tensor) else output[0]
        batch, out_channels, out_h, out_w = y.shape
        kernel_ops = module.kernel_size[0] * module.kernel_size[1] * (module.in_channels // module.groups)
        flops["total"] += int(batch * out_channels * out_h * out_w * kernel_ops)

    try:
        model = model.to(device)
        for submodule in model.modules():
            if isinstance(submodule, nn.Linear):
                hooks.append(submodule.register_forward_hook(linear_hook))
            elif isinstance(submodule, nn.Conv1d):
                hooks.append(submodule.register_forward_hook(conv1d_hook))
            elif isinstance(submodule, nn.Conv2d):
                hooks.append(submodule.register_forward_hook(conv2d_hook))

        with torch.no_grad():
            dummy = torch.randn(*input_shape, device=device)
            _ = model(dummy)
    except Exception:
        return None
    finally:
        for hook in hooks:
            hook.remove()
        try:
            model.to(original_device)
        except Exception:
            pass

    return int(flops["total"])


def save_json(data: dict[str, Any], path: str | Path) -> None:
    """Save a dict as JSON."""
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _resolve_existing_path(module_root: str | Path) -> Path:
    path = Path(module_root)
    if path.exists():
        return path.resolve()

    cwd = Path.cwd()
    candidate = cwd / str(module_root)
    if candidate.exists():
        return candidate.resolve()

    if cwd.name.lower() == Path(str(module_root)).name.lower():
        return cwd.resolve()

    raise FileNotFoundError(f"module_root does not exist: {module_root}")


def resolve_project_and_module_root(module_root: str | Path) -> tuple[Path, Path]:
    """Resolve project root and actual module code root."""
    resolved = _resolve_existing_path(module_root)
    lower_dirs = {child.name.lower() for child in resolved.iterdir() if child.is_dir()}

    if "model" in lower_dirs:
        return resolved, (resolved / "model").resolve()

    if KNOWN_MODULE_DIRS.intersection(lower_dirs):
        if resolved.name.lower() == "model":
            return resolved.parent.resolve(), resolved.resolve()
        return resolved.resolve(), resolved.resolve()

    raise FileNotFoundError(
        f"Could not find model directories under {resolved}. Expected a repo root containing 'model/' "
        f"or a module root containing one of {sorted(KNOWN_MODULE_DIRS)}."
    )


def ensure_sys_path(path: str | Path) -> None:
    """Add project root to sys.path if needed."""
    path_str = str(Path(path).resolve())
    if path_str not in sys.path:
        sys.path.insert(0, path_str)


def summarize_markdown(text: str) -> str:
    """Create a short summary from markdown headings."""
    headings = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            headings.append(re.sub(r"^#+\s*", "", stripped))
        if len(headings) >= 3:
            break
    return " | ".join(headings[:3])


def read_markdown_guides(project_root: str | Path) -> list[dict[str, str]]:
    """Read markdown files in the repository to capture usage hints."""
    project_root = Path(project_root)
    guides: list[dict[str, str]] = []
    for md_file in sorted(project_root.rglob("*.md")):
        if "BJ_Agent" in md_file.parts:
            continue
        try:
            content = md_file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        guides.append(
            {
                "path": str(md_file.resolve()),
                "summary": summarize_markdown(content),
            }
        )
    return guides
