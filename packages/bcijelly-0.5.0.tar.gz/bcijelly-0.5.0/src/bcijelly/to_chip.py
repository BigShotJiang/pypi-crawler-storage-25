from __future__ import annotations

from pathlib import Path
from typing import Any, Literal, Optional, Sequence

import torch


DeployMode = Literal["ANN", "SNN"]
ChipType = Literal["Lynxi", "Taibai"]


class toChip:
    def __init__(
        self,
        model_path: str,
        input_shape: Sequence[int],
        output_dir: str = "./chip_out",
        mode: DeployMode = "ANN",
        chip_type: ChipType = "Lynxi",
        input_name: str = "data",
        sim_steps: int = 20,
        device_id: int = 0,
        target: str = "apu",
        build_mode: str = "auto",
        apu_only: bool = True,
        save_graph: bool = False,
        is_map: bool = True,
        verify_load: bool = True,
        auto_compile: bool = False,
        weights_only: bool = False,
        taibai_timestep: Optional[int] = None,
        taibai_with_neuron_param: bool = True,
        taibai_test_data: Optional[Any] = None,
        taibai_run_simulator: bool = False,
    ):
        self.model_path = Path(model_path)
        self.input_shape = tuple(input_shape)
        self.output_dir = output_dir
        self.mode = mode.upper()
        self.chip_type = chip_type
        self.input_name = input_name

        self.sim_steps = sim_steps
        self.device_id = device_id
        self.target = target
        self.build_mode = build_mode
        self.apu_only = apu_only
        self.save_graph = save_graph
        self.is_map = is_map
        self.verify_load = verify_load
        self.weights_only = weights_only

        self.taibai_timestep = taibai_timestep
        self.taibai_with_neuron_param = taibai_with_neuron_param
        self.taibai_test_data = taibai_test_data
        self.taibai_run_simulator = taibai_run_simulator

        self.model: Optional[torch.nn.Module] = None
        self.compiled_path: Optional[str] = None
        self.engine: Optional[Any] = None

        self.taibai_result: dict[str, Any] = {}

        self._check_args()

        if auto_compile:
            self.compile()

    def _check_args(self) -> None:
        if self.mode not in ("ANN", "SNN"):
            raise ValueError(f"mode must be 'ANN' or 'SNN', got: {self.mode}")

        if self.chip_type not in ("Lynxi", "Taibai"):
            raise ValueError(f"chip_type must be 'Lynxi' or 'Taibai', got: {self.chip_type}")

        if not 1 <= len(self.input_shape) <= 4:
            raise ValueError(f"input_shape must have 1 to 4 dimensions, got: {self.input_shape}")

        for dim in self.input_shape:
            if not isinstance(dim, int) or dim <= 0:
                raise ValueError(f"input_shape must contain positive integers, got: {self.input_shape}")

        if not self.model_path.exists():
            raise FileNotFoundError(f"model_path not found: {self.model_path}")

        if self.chip_type == "Taibai":
            if self.mode != "SNN":
                raise ValueError("Taibai flow currently expects mode='SNN'.")

            self._parse_taibai_input_shape()

            if self.taibai_timestep is None:
                self.taibai_timestep = self.sim_steps

    def _parse_taibai_input_shape(self) -> tuple[int, int, int]:
        if len(self.input_shape) == 4:
            _, channels, height, width = self.input_shape
        elif len(self.input_shape) == 3:
            channels, height, width = self.input_shape
        elif len(self.input_shape) == 2:
            channels = 1
            height, width = self.input_shape
        else:
            raise ValueError(
                "Taibai input_shape must be 2D, 3D, or 4D. "
                "Examples: (128, 128), (1, 128, 128), or (1, 1, 128, 128)."
            )

        return channels, height, width

    def load_model(self) -> torch.nn.Module:
        try:
            model_obj = torch.load(
                self.model_path,
                map_location="cpu",
                weights_only=self.weights_only,
            )
        except TypeError:
            model_obj = torch.load(self.model_path, map_location="cpu")
        except Exception as e:
            raise RuntimeError(
                "Failed to load model. The pth file must contain a full PyTorch model "
                "saved by torch.save(model, path), not only model.state_dict(). "
                "Also make sure the model class definition is importable. "
                f"Original error: {repr(e)}"
            )

        if isinstance(model_obj, dict):
            raise TypeError(
                "The loaded pth object is a dict, likely a checkpoint or state_dict. "
                "Please save a full model with torch.save(model, 'model_with_graph.pth')."
            )

        if not hasattr(model_obj, "eval") or not callable(model_obj.eval):
            raise TypeError(
                "The loaded object is not a torch.nn.Module. "
                "Please provide a full model saved by torch.save(model, path)."
            )

        model_obj.eval()
        self.model = model_obj
        print(f"[toChip] model loaded: {self.model_path}")
        return model_obj

    def _convert_snn_for_lynxi(self) -> None:
        if self.model is None:
            raise RuntimeError("Call load_model() before SNN conversion.")

        try:
            from spikingjelly.activation_based import functional, lynxi_exchange, neuron  # type: ignore[import-not-found]
        except Exception as e:
            raise ImportError(
                "SNN Lynxi mode requires spikingjelly.activation_based.functional, "
                "lynxi_exchange, and neuron."
            ) from e

        def convert_recursive(module: torch.nn.Module) -> None:
            for name, child in module.named_children():
                if isinstance(child, (neuron.LIFNode, neuron.BaseNode)):
                    new_child = lynxi_exchange.to_lynxi_supported_module(
                        child,
                        self.sim_steps,
                    )
                    setattr(module, name, new_child)
                    print(f"[toChip][SNN] converted node: {name}")
                else:
                    convert_recursive(child)

        convert_recursive(self.model)
        functional.reset_net(self.model)
        print("[toChip][SNN] Lynxi conversion done.")

    def _prepare_model(self) -> None:
        if self.model is None:
            self.load_model()

        if self.chip_type == "Lynxi":
            if self.mode == "ANN":
                print("[toChip] Lynxi ANN mode.")
            elif self.mode == "SNN":
                print("[toChip] Lynxi SNN mode.")
                self._convert_snn_for_lynxi()
            return

        if self.chip_type == "Taibai":
            print("[toChip] Taibai mode.")
            return

    def _compile_lynxi(self) -> str:
        if self.model is None:
            raise RuntimeError("Model is empty. Call _prepare_model() first.")

        try:
            import lyngor as lyn  # type: ignore[import-not-found]
        except Exception as e:
            raise ImportError(
                "Lynxi compilation requires lyngor. Please check the Lynxi SDK environment."
            ) from e

        dl_model = lyn.DLModel()
        dl_model.load(
            self.model,
            model_type="Pytorch",
            inputs_dict={self.input_name: self.input_shape},
        )

        builder = lyn.Builder(target=self.target, is_map=self.is_map)

        out_path = builder.build(
            dl_model.graph,
            dl_model.params,
            out_path=self.output_dir,
            build_mode=self.build_mode,
            apu_only=self.apu_only,
            save_graph=self.save_graph,
        )

        self.compiled_path = out_path
        print(f"[toChip] Lynxi compile done: {out_path}")

        if self.verify_load:
            self.engine = lyn.load(path=out_path, device=self.device_id)
            print(f"[toChip] Lynxi engine loaded on device {self.device_id}")

        return out_path

    def _compile_taibai(self) -> dict[str, Any]:
        if self.model is None:
            raise RuntimeError("Model is empty. Call _prepare_model() first.")

        try:
            from taibaimodels import functional  # type: ignore[import-not-found]
            from taibaimapping.multicast import generate_not_resnet_cfg, mapping_with_datamem  # type: ignore[import-not-found]
            from taibaimapping.chip_simulator import simulator  # type: ignore[import-not-found]
        except Exception as e:
            raise ImportError(
                "Taibai compilation requires taibaimodels and taibaimapping."
            ) from e

        timestep = self.taibai_timestep
        if timestep is None:
            timestep = self.sim_steps

        inchannels, input_height, input_width = self._parse_taibai_input_shape()

        new_net = functional.build_new_model(self.model)
        fused_model = functional.fuse_model(new_net)

        representation = functional.extract_middle_representation(
            fused_model,
            T=timestep,
            inchannels=inchannels,
        )

        cfg, (model_dic, neuron_param) = functional.convert_middle_to_taibai_cfg(
            representation,
            self.taibai_with_neuron_param,
        )

        cfg_all = generate_not_resnet_cfg(
            cfg_all=cfg,
            input_height=input_height,
            input_width=input_width,
        )

        mapping_result = mapping_with_datamem(
            layer_cfg=cfg_all,
            model_dic=model_dic,
            neuron_param=neuron_param,
            timestep=timestep,
        )

        sim_result = None
        if self.taibai_run_simulator:
            if self.taibai_test_data is None:
                raise ValueError("taibai_test_data is required when taibai_run_simulator=True.")

            sim_result = simulator(
                test_data=self.taibai_test_data,
                model_dic=model_dic,
                layer_cfg=cfg_all,
                time_step_all=timestep,
            )

        self.taibai_result = {
            "cfg": cfg,
            "cfg_all": cfg_all,
            "model_dic": model_dic,
            "neuron_param": neuron_param,
            "mapping_result": mapping_result,
            "sim_result": sim_result,
            "input_shape": self.input_shape,
            "inchannels": inchannels,
            "input_height": input_height,
            "input_width": input_width,
            "timestep": timestep,
        }

        self.compiled_path = self.output_dir
        print("[toChip] Taibai mapping done.")
        return self.taibai_result

    def compile(self) -> Any:
        self._prepare_model()

        if self.chip_type == "Lynxi":
            return self._compile_lynxi()

        if self.chip_type == "Taibai":
            return self._compile_taibai()

        raise ValueError(f"Unknown chip_type: {self.chip_type}")

    def __call__(self) -> Any:
        return self.compile()