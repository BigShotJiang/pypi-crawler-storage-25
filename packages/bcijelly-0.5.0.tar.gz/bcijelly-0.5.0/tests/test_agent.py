"""Agent test group.

This file verifies SearchAgent import, fit/test behavior, and summary outputs
on synthetic small datasets.
"""
from __future__ import annotations

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Import smoke test
# ---------------------------------------------------------------------------

def test_search_agent_importable_from_top_level() -> None:
    """SearchAgent must be importable directly from the bcijelly top-level package."""
    import bcijelly
    from bcijelly import SearchAgent  # noqa: F401

    assert hasattr(bcijelly, "SearchAgent")


def test_search_agent_importable_from_agent_subpackage() -> None:
    """SearchAgent must be importable from bcijelly.agent."""
    from bcijelly.agent import SearchAgent  # noqa: F401


def test_search_ensemble_api_name_removed() -> None:
    """SearchEnsembleAPI must NOT be exported (renamed to SearchAgent)."""
    import bcijelly

    assert not hasattr(bcijelly, "SearchEnsembleAPI"), (
        "SearchEnsembleAPI should no longer be exported; use SearchAgent instead."
    )


# ---------------------------------------------------------------------------
# Instantiation
# ---------------------------------------------------------------------------

def test_search_agent_instantiation() -> None:
    """SearchAgent can be created with default arguments."""
    from bcijelly import SearchAgent

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    assert agent is not None


# ---------------------------------------------------------------------------
# fit: val_dataset=None must raise ValueError
# ---------------------------------------------------------------------------

def test_fit_raises_without_val_dataset() -> None:
    """fit() must raise ValueError when val_dataset is None."""
    from bcijelly import SearchAgent

    agent = SearchAgent(
        device="cpu",
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )

    rng = np.random.default_rng(0)
    X = rng.random((20, 10, 4)).astype(np.float32)
    y = rng.integers(0, 2, size=(20,)).astype(np.int64)

    with pytest.raises(ValueError, match="val_dataset is required"):
        agent.fit((X, y), val_dataset=None)


# ---------------------------------------------------------------------------
# fit: dataset-tuple form accepted
# ---------------------------------------------------------------------------

def test_fit_accepts_dataset_tuple_form() -> None:
    """fit((X_train, y_train), (X_val, y_val)) must run end-to-end on small synthetic data."""
    from bcijelly import SearchAgent

    rng = np.random.default_rng(42)
    N_train, N_val, T, C = 60, 20, 10, 4

    X_train = rng.random((N_train, T, C)).astype(np.float32)
    y_train = rng.integers(0, 2, size=(N_train,)).astype(np.int64)
    X_val = rng.random((N_val, T, C)).astype(np.float32)
    y_val = rng.integers(0, 2, size=(N_val,)).astype(np.int64)

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        patience=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )

    returned = agent.fit((X_train, y_train), (X_val, y_val))
    # fit must return self for chaining
    assert returned is agent
    assert agent._fitted


# ---------------------------------------------------------------------------
# test: print message and return dict
# ---------------------------------------------------------------------------

def test_test_prints_message_and_returns_dict(capsys: pytest.CaptureFixture) -> None:
    """test() must print a summary line and return a dict with the expected keys."""
    from bcijelly import SearchAgent

    rng = np.random.default_rng(7)
    N_train, N_val, T, C = 60, 20, 10, 4

    X_train = rng.random((N_train, T, C)).astype(np.float32)
    y_train = rng.integers(0, 2, size=(N_train,)).astype(np.int64)
    X_val = rng.random((N_val, T, C)).astype(np.float32)
    y_val = rng.integers(0, 2, size=(N_val,)).astype(np.int64)

    # Test data: two synthetic days
    X_test_day1 = rng.random((15, T, C)).astype(np.float32)
    y_test_day1 = rng.integers(0, 2, size=(15,)).astype(np.int64)
    X_test_day2 = rng.random((15, T, C)).astype(np.float32)
    y_test_day2 = rng.integers(0, 2, size=(15,)).astype(np.int64)

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        patience=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    agent.fit((X_train, y_train), (X_val, y_val))

    test_day_data = {
        "day_0": (X_test_day1, y_test_day1),
        "day_1": (X_test_day2, y_test_day2),
    }
    result = agent.test(test_day_data)

    # Must return a dict with key fields
    assert isinstance(result, dict)
    assert "task_type" in result
    assert "metric_name" in result
    assert "num_test_days" in result
    assert result["num_test_days"] == 2

    # Must print a summary line to stdout
    captured = capsys.readouterr()
    assert "[SearchAgent] Test complete" in captured.out
    assert "2 day(s)" in captured.out


# ---------------------------------------------------------------------------
# summary: defaults/full/include/pre-fit error
# ---------------------------------------------------------------------------

def test_summary_raises_before_fit() -> None:
    """summary() must raise RuntimeError before fit()."""
    from bcijelly import SearchAgent

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    with pytest.raises(RuntimeError, match=r"Call fit\(train_dataset, val_dataset\) first"):
        _ = agent.summary()


def test_summary_defaults_compact_and_print(capsys: pytest.CaptureFixture) -> None:
    """summary() defaults must be compact + printed output + no candidates."""
    from bcijelly import SearchAgent

    rng = np.random.default_rng(101)
    N_train, N_val, T, C = 48, 16, 10, 4

    X_train = rng.random((N_train, T, C)).astype(np.float32)
    y_train = rng.integers(0, 2, size=(N_train,)).astype(np.int64)
    X_val = rng.random((N_val, T, C)).astype(np.float32)
    y_val = rng.integers(0, 2, size=(N_val,)).astype(np.int64)

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        patience=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    agent.fit((X_train, y_train), (X_val, y_val))

    result = agent.summary()
    assert "compact" in result
    compact = result["compact"]
    for key in ("task_type", "method", "val_metric", "ensemble_size", "members", "retained_count", "threshold_satisfied"):
        assert key in compact

    captured = capsys.readouterr()
    assert "[SearchAgent] Summary" in captured.out


def test_summary_full_include_and_max() -> None:
    """summary(full) should include optional retained_candidates and respect max cap."""
    from bcijelly import SearchAgent

    rng = np.random.default_rng(202)
    N_train, N_val, T, C = 48, 16, 10, 4

    X_train = rng.random((N_train, T, C)).astype(np.float32)
    y_train = rng.integers(0, 2, size=(N_train,)).astype(np.int64)
    X_val = rng.random((N_val, T, C)).astype(np.float32)
    y_val = rng.integers(0, 2, size=(N_val,)).astype(np.int64)

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        patience=1,
        max_search_rounds=1,
        max_models_per_round=2,
        retain_top_k=2,
        ensemble_top_m=2,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    agent.fit((X_train, y_train), (X_val, y_val))

    result = agent.summary(mode="full", print_output=False, include=True, max=1)
    assert "selected_ensemble" in result
    assert "threshold_filter" in result
    assert "paths" in result
    assert "retained_candidates" in result
    assert len(result["retained_candidates"]) <= 1


def test_summary_contains_external_test_summary_after_test() -> None:
    """summary(full) must expose external_test_summary after test()."""
    from bcijelly import SearchAgent

    rng = np.random.default_rng(303)
    N_train, N_val, T, C = 60, 20, 10, 4

    X_train = rng.random((N_train, T, C)).astype(np.float32)
    y_train = rng.integers(0, 2, size=(N_train,)).astype(np.int64)
    X_val = rng.random((N_val, T, C)).astype(np.float32)
    y_val = rng.integers(0, 2, size=(N_val,)).astype(np.int64)
    X_test_day1 = rng.random((12, T, C)).astype(np.float32)
    y_test_day1 = rng.integers(0, 2, size=(12,)).astype(np.int64)
    X_test_day2 = rng.random((14, T, C)).astype(np.float32)
    y_test_day2 = rng.integers(0, 2, size=(14,)).astype(np.int64)

    agent = SearchAgent(
        task_type="classification",
        device="cpu",
        epochs=1,
        patience=1,
        max_search_rounds=1,
        max_models_per_round=1,
        retain_top_k=1,
        ensemble_top_m=1,
        val_threshold=0.0,
        output_dir="tests/outputs/_test_search_agent_tmp",
        save_result_json=False,
    )
    agent.fit((X_train, y_train), (X_val, y_val))
    _ = agent.test({"day_0": (X_test_day1, y_test_day1), "day_1": (X_test_day2, y_test_day2)})

    result = agent.summary(mode="full", print_output=False)
    assert "external_test_summary" in result
    assert isinstance(result["external_test_summary"], dict)
    assert result["external_test_summary"]["num_test_days"] == 2
