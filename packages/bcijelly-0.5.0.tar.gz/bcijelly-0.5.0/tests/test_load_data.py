"""Load-data test group.

This file focuses on data loading contracts, file discovery behavior,
task label parsing, and core load_data end-to-end checks.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

import bcijelly as bj
from bcijelly.dataset._discovery import _detect_root_storage_format
from bcijelly.dataset._io import load_speech_npz, load_task_npz
from bcijelly.dataset._load_data_capability import LOAD_DATA_CAPABILITY_DECLARATION
from bcijelly.dataset._loading import load_data
from bcijelly.dataset._types import DATASET_FORMAT_SPLIT_FILES


def _touch(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"")


def _save_npz(path: Path, *, label_key: str) -> None:
    x = np.random.randn(8, 16, 4).astype(np.float32)
    if label_key == "regression_target":
        y = np.random.randn(8, 16, 2).astype(np.float32)
    else:
        y = np.arange(8, dtype=np.int64)
    np.savez(path, neural_activity=x, **{label_key: y})


# ---------------------------------------------------------------------------
# capability / discovery contracts
# ---------------------------------------------------------------------------


def test_load_data_capability_declaration_contract() -> None:
    assert LOAD_DATA_CAPABILITY_DECLARATION.get("schema_version") == "internal.v1"

    supported_protocols = LOAD_DATA_CAPABILITY_DECLARATION.get("supported_protocols")
    assert supported_protocols == ["single_day", "cross_day", "train-test", "train-val-test"]

    supported_tasks = LOAD_DATA_CAPABILITY_DECLARATION.get("supported_tasks")
    assert supported_tasks == ["classification", "regression", "speech"]

    protocol_notes = LOAD_DATA_CAPABILITY_DECLARATION.get("protocol_notes")
    assert isinstance(protocol_notes, dict)
    for protocol_name in supported_protocols:
        note = protocol_notes.get(protocol_name)
        assert isinstance(note, dict)
        assert isinstance(note.get("purpose"), str)
        assert isinstance(note.get("file_patterns"), list)
        assert isinstance(note.get("use_cases"), list)

    task_notes = LOAD_DATA_CAPABILITY_DECLARATION.get("task_notes")
    assert isinstance(task_notes, dict)
    for task_name in supported_tasks:
        note = task_notes.get(task_name)
        assert isinstance(note, dict)
        assert isinstance(note.get("target_keys"), list)
        assert isinstance(note.get("behavior"), str)


def test_detect_split_files_from_suffix_with_extra_npz(tmp_path: Path) -> None:
    dataset_root = tmp_path / "11_Speech"
    _touch(dataset_root / "Speech_Train.npz")
    _touch(dataset_root / "Speech_Test.npz")
    _touch(dataset_root / "data_SpeechBCI_preprocessed.npz")

    structure = _detect_root_storage_format("11_Speech", dataset_root)
    assert structure.storage_format == DATASET_FORMAT_SPLIT_FILES
    assert structure.train_file is not None and structure.train_file.name == "Speech_Train.npz"
    assert structure.test_file is not None and structure.test_file.name == "Speech_Test.npz"
    assert structure.val_file is None


def test_detect_train_val_test_from_suffix(tmp_path: Path) -> None:
    dataset_root = tmp_path / "demo"
    _touch(dataset_root / "sample_train.npz")
    _touch(dataset_root / "sample_val.npz")
    _touch(dataset_root / "sample_test.npz")

    structure = _detect_root_storage_format("demo", dataset_root)
    assert structure.storage_format == DATASET_FORMAT_SPLIT_FILES
    assert structure.train_file is not None and structure.train_file.name == "sample_train.npz"
    assert structure.val_file is not None and structure.val_file.name == "sample_val.npz"
    assert structure.test_file is not None and structure.test_file.name == "sample_test.npz"


# ---------------------------------------------------------------------------
# io and task label loading
# ---------------------------------------------------------------------------


def test_load_task_npz_regression_key(tmp_path: Path) -> None:
    npz_path = tmp_path / "regression.npz"
    _save_npz(npz_path, label_key="regression_target")

    x, y, key = load_task_npz(npz_path, task="regression")
    assert x.shape[0] == y.shape[0] == 8
    assert key == "regression_target"


def test_load_task_npz_speech_key(tmp_path: Path) -> None:
    npz_path = tmp_path / "speech.npz"
    _save_npz(npz_path, label_key="speech_label")

    x, y, key = load_task_npz(npz_path, task="speech")
    assert x.shape[0] == y.shape[0] == 8
    assert key == "speech_label"


def test_load_speech_npz_returns_five_tuple(tmp_path: Path) -> None:
    npz_path = tmp_path / "speech_seq.npz"
    x = np.random.randn(8, 16, 4).astype(np.float32)
    y = np.random.randint(0, 10, size=(8, 7), dtype=np.int32)
    x_len = np.full((8,), 16, dtype=np.int32)
    y_len = np.full((8,), 7, dtype=np.int32)
    day_idx = np.zeros((8,), dtype=np.int64)
    np.savez(
        npz_path,
        neural_activity=x,
        speech_label=y,
        X_len=x_len,
        y_len=y_len,
        dayIdx=day_idx,
    )

    loaded_x, loaded_y, loaded_x_len, loaded_y_len, loaded_day_idx, key = load_speech_npz(npz_path)
    assert loaded_x.shape == x.shape
    assert loaded_y.shape == y.shape
    assert loaded_x_len.shape == (8,)
    assert loaded_y_len.shape == (8,)
    assert loaded_day_idx.shape == (8,)
    assert key == "speech_label"


def test_load_speech_npz_defaults_missing_dayidx_to_zero(tmp_path: Path) -> None:
    npz_path = tmp_path / "speech_seq_no_dayidx.npz"
    x = np.random.randn(4, 10, 3).astype(np.float32)
    y = np.random.randint(0, 5, size=(4, 6), dtype=np.int32)
    x_len = np.full((4, 1), 10, dtype=np.int32)
    y_len = np.full((4, 1), 6, dtype=np.int32)
    np.savez(npz_path, neural_activity=x, speech_label=y, X_len=x_len, y_len=y_len)

    _, _, _, _, loaded_day_idx, _ = load_speech_npz(npz_path)
    assert np.array_equal(loaded_day_idx, np.zeros((4,), dtype=np.int64))


# ---------------------------------------------------------------------------
# end-to-end load_data behavior
# ---------------------------------------------------------------------------


def test_load_data_basic_cases() -> None:
    cases = [
        {
            "dataset_name": "11_Speech",
            "protocol": "train-test",
            "task": "speech",
            "subject_index": 0,
            "day_index": 0,
            "split_ratio": "8:2",
            "seed": 42,
        },
        {
            "dataset_name": "8_ReachingMCPMC_Regression_Test",
            "protocol": "single_day",
            "task": "regression",
            "subject_index": 0,
            "day_index": 0,
            "split_ratio": "7:1:2",
            "seed": 42,
        },
        {
            "dataset_name": "1_FALCONM1-A",
            "protocol": "cross_day",
            "task": "classification",
            "subject_index": 0,
            "split_ratio": "7:1:2",
            "seed": 42,
        },
    ]

    for case in cases:
        loaded_data = bj.load_data(verbose=False, **case)
        train_x, train_y = loaded_data.train_dataset[:2]
        test_x, test_y = loaded_data.test_dataset[:2]

        assert train_x.shape[0] == train_y.shape[0]
        assert test_x.shape[0] == test_y.shape[0]
        assert loaded_data.requested_task == case["task"]

        if loaded_data.val_dataset is not None:
            val_x, val_y = loaded_data.val_dataset[:2]
            assert val_x.shape[0] == val_y.shape[0]


def test_load_data_speech_split_files_returns_five_tuple() -> None:
    loaded = load_data(
        dataset_name="11_Speech",
        protocol="train-test",
        task="speech",
        subject_index=0,
        day_index=0,
        split_ratio="8:2",
        seed=42,
        verbose=False,
    )

    assert len(loaded.train_dataset) == 5
    assert len(loaded.test_dataset) == 5
    train_x, train_y, train_x_len, train_y_len, train_day_idx = loaded.train_dataset
    test_x, test_y, test_x_len, test_y_len, test_day_idx = loaded.test_dataset
    assert train_x.shape[0] == train_y.shape[0] == train_x_len.shape[0] == train_y_len.shape[0] == train_day_idx.shape[0]
    assert test_x.shape[0] == test_y.shape[0] == test_x_len.shape[0] == test_y_len.shape[0] == test_day_idx.shape[0]
    assert loaded.requested_task == "speech"


def test_load_data_speech_train_test_three_part_split_ratio_splits_train_val() -> None:
    base_loaded = load_data(
        dataset_name="11_Speech",
        protocol="train-test",
        task="speech",
        subject_index=0,
        day_index=0,
        split_ratio="8:2",
        seed=42,
        verbose=False,
    )

    with pytest.warns(UserWarning, match="explicit test data cannot be repartitioned"):
        loaded = load_data(
            dataset_name="11_Speech",
            protocol="train-test",
            task="speech",
            subject_index=0,
            day_index=0,
            split_ratio="7:1:2",
            seed=42,
            verbose=False,
        )

    assert loaded.val_dataset is not None
    assert len(loaded.train_dataset) == 5
    assert len(loaded.val_dataset) == 5
    assert len(loaded.test_dataset) == 5
    assert loaded.train_dataset[0].shape[0] + loaded.val_dataset[0].shape[0] == base_loaded.train_dataset[0].shape[0]
    assert loaded.test_dataset[0].shape[0] == base_loaded.test_dataset[0].shape[0]


def test_load_data_rejects_unsupported_task_early() -> None:
    with pytest.raises(ValueError, match="Unsupported task"):
        load_data(dataset_name="11_Speech", protocol="single_day", task="unknown_task")
