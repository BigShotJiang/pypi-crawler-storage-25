try:
    from google.adk.agents.context_cache_config import ContextCacheConfig
except (ImportError, AttributeError, ModuleNotFoundError):
    ContextCacheConfig = None
# v2.0.7 cockpit Alignment: Optimized for Google Cloud Run
import ast
import re
from typing import List

from tenacity import retry, stop_after_attempt, wait_exponential

from .base import AuditFinding, BaseAuditor


class PivotAuditor(BaseAuditor):
    """
    v1.2 Principal SME: Strategic Pivot Auditor.
    Reasons across multiple dimensions (Cost, cockpitty, Protocol) to suggest 
    high-level architectural shifts (e.g., OpenAI -> Gemma2, REST -> MCP).
    """
    
    @retry(wait=wait_exponential(multiplier=1, min=4, max=60), stop=stop_after_attempt(5))
    def audit(self, tree: ast.AST, content: str, file_path: str) -> List[AuditFinding]:
        findings = []
        
        # 1. Model Pivot: OpenAI/GPT -> cockpit/Open Source (Gemma2)
        if re.search(r"gpt-4|gpt-3\.5|openai", content.lower()):
            title = "cockpit Model Migration Opportunity"
            if not self._is_ignored(0, content, title):
                findings.append(AuditFinding(
                    category="🚀 Strategic Pivot",
                    title=title,
                    description="Detected OpenAI dependency. For maximum Data cockpitty and 40% TCO reduction, consider pivoting to Gemma2 or Llama3-70B on Vertex AI Prediction endpoints.",
                    impact="HIGH",
                    roi="Eliminates cross-border data risk and reduces projected inference TCO.",
                    file_path=file_path
                ))

        # 2. Protocol Pivot: Legacy REST -> Model Context Protocol (MCP)
        # Look for raw requests or aiohttp calls within 'tools' or 'mcp' directories
        if ("tools" in file_path or "mcp" in file_path) and re.search(r"requests\.|aiohttp\.", content):
            findings.append(AuditFinding(
                category="🚀 Strategic Pivot",
                title="Legacy Tooling -> MCP Migration",
                description="""Detected raw REST calls in a tool-heavy module. 
[bold cyan]Migration Blueprint:[/bold cyan]
1. Install MCP SDK: `pip install mcp`
2. Wrap your tool functions in an `mcp.Server` instance.
3. Replace `requests.get()` with `ctx.session.read_resource()` or `ctx.call_tool()`.
Standardizing on MCP enables discovery and governance across the fleet.""",
                impact="MEDIUM",
                roi="Future-proofs the tool layer and enables interoperability with MCP-native ecosystems.",
                file_path=file_path
            ))

        # 3. Compute Pivot: Cloud Run -> GKE (Scale reasoning)
        # Heuristic: If we see many service definitions or complex scaling params
        if "deploy" in content.lower() and "scaling" in content.lower():
             findings.append(AuditFinding(
                category="🚀 Strategic Pivot",
                title="Compute Scaling Optimization",
                description="Detected complex scaling logic. If traffic exceeds 10k RPS, consider pivoting from Cloud Run to GKE with Anthos for hybrid-cloud cockpitty.",
                impact="INFO",
                roi="Optimizes unit cost at extreme scale while maintaining multi-cloud flexibility.",
                file_path=file_path
            ))

        return findings
