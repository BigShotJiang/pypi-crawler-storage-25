def add_one(number):
    return number + 1

def print_name(name: str):
    print("Aryan P: \n" + f"and {name}")