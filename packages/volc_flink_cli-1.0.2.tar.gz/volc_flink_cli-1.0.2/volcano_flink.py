#!/usr/bin/env python3
"""
火山引擎流式计算 Flink 版 Client 工具 - 命令行入口
Volcano Engine Flink Stream Computing Client - Command Line Interface
"""

import argparse
import sys
import json
import time
import getpass
import re
import importlib.resources as importlib_resources
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Any
import requests
from volcano_flink_client.auth.auth import AuthManager, Credentials
from volcano_flink_client.projects.projects import ProjectManager
from volcano_flink_client.resource_pools.resource_pools import ResourcePoolManager, ResourcePoolSpec
from volcano_flink_client.jobs.jobs import JobManager
from volcano_flink_client.drafts.drafts import DraftManager, DraftContent
from volcano_flink_client.catalogs.catalogs import CatalogManager
from volcano_flink_client.sessions.sessions import SessionClusterManager
from volcano_flink_client.files.files import TOSFilesManager
from volcano_flink_client.api import ApiClient


def print_header(title: str):
    """打印标题"""
    print(f"\n{'=' * 60}")
    print(f"{title:^60}")
    print(f"{'=' * 60}")


def print_table(data: list, headers: list):
    """打印表格"""
    if not data:
        print("无数据")
        return
    
    # 计算列宽
    col_widths = []
    for i, header in enumerate(headers):
        max_width = len(header)
        for row in data:
            cell_width = len(str(row[i]))
            if cell_width > max_width:
                max_width = cell_width
        col_widths.append(max_width + 2)
    
    # 打印表头
    for i, header in enumerate(headers):
        print(f"{header:<{col_widths[i]}}", end="")
    print()
    
    # 打印分隔线
    for width in col_widths:
        print(f"{'-' * (width - 2):<{width}}", end="")
    print()
    
    # 打印数据
    for row in data:
        for i, cell in enumerate(row):
            print(f"{str(cell):<{col_widths[i]}}", end="")
        print()

def _format_epoch(ts: int) -> str:
    try:
        return datetime.fromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(ts)

def _downsample_avg(values: List[float], target_n: int) -> List[float]:
    n = len(values)
    if target_n <= 0 or n <= target_n:
        return values
    out: List[float] = []
    for i in range(target_n):
        start = int(i * n / target_n)
        end = int((i + 1) * n / target_n)
        if end <= start:
            end = min(n, start + 1)
        chunk = values[start:end]
        if not chunk:
            continue
        out.append(sum(chunk) / float(len(chunk)))
    return out

def _sparkline(values: List[float], width: int = 80) -> str:
    if not values:
        return ""
    vals = _downsample_avg(values, max(1, int(width)))
    lo = min(vals)
    hi = max(vals)
    levels = "▁▂▃▄▅▆▇█"
    if hi == lo:
        return levels[len(levels) // 2] * len(vals)
    out_chars: List[str] = []
    span = hi - lo
    for v in vals:
        idx = int((float(v - lo) / span) * (len(levels) - 1))
        if idx < 0:
            idx = 0
        if idx >= len(levels):
            idx = len(levels) - 1
        out_chars.append(levels[idx])
    return "".join(out_chars)

def _render_metrics_graph(resp: Any, width: int = 80) -> None:
    if not isinstance(resp, dict):
        print(json.dumps(resp, ensure_ascii=False, indent=2))
        return
    items = resp.get("Data") or []
    if not isinstance(items, list) or not items:
        print("无数据")
        return
    for metric in items:
        if not isinstance(metric, dict):
            continue
        metric_name = str(metric.get("MetricName") or "")
        unit = str(metric.get("Unit") or "")
        period = str(metric.get("Period") or "")
        results = metric.get("MetricDataResults") or []
        if not isinstance(results, list) or not results:
            continue
        for series in results:
            if not isinstance(series, dict):
                continue
            legend = str(series.get("Legend") or metric_name)
            dims = series.get("Dimensions") or []
            dims_kv = []
            if isinstance(dims, list):
                for d in dims:
                    if not isinstance(d, dict):
                        continue
                    n = d.get("Name")
                    v = d.get("Value")
                    if n is None or v is None:
                        continue
                    dims_kv.append(f"{n}={v}")
            dims_str = ", ".join(dims_kv)
            points = series.get("DataPoints") or []
            if not isinstance(points, list) or not points:
                continue
            pts = []
            for p in points:
                if not isinstance(p, dict):
                    continue
                ts = p.get("Timestamp")
                val = p.get("Value")
                if ts is None or val is None:
                    continue
                try:
                    pts.append((int(ts), float(val)))
                except Exception:
                    continue
            if not pts:
                continue
            pts.sort(key=lambda x: x[0])
            ts0, v0 = pts[0]
            ts1, v1 = pts[-1]
            values = [v for _, v in pts]
            line = _sparkline(values, width=width)
            title_parts = [x for x in [metric_name, legend] if x]
            title = " / ".join(title_parts)
            meta_parts = []
            if unit:
                meta_parts.append(unit)
            if period:
                meta_parts.append(period)
            meta = f" ({', '.join(meta_parts)})" if meta_parts else ""
            print(f"{title}{meta}")
            if dims_str:
                print(dims_str)
            print(line)
            print(f"{_format_epoch(ts0)} -> {_format_epoch(ts1)}  min={min(values)} max={max(values)} last={v1}")
            print()


def login(args: argparse.Namespace):
    """登录命令处理"""
    auth_manager = AuthManager()
    
    access_key = args.ak or input("请输入 Access Key (AK): ").strip()
    secret_key = args.sk or getpass.getpass("请输入 Secret Key (SK): ").strip()
    if not access_key or not secret_key:
        print("❌ AK/SK 不能为空")
        return
    
    credentials = auth_manager.login(
        access_key=access_key,
        secret_key=secret_key,
        region=args.region
    )
    print(f"✅ 登录成功！账号: {credentials.access_key}")


def logout():
    """退出登录命令处理"""
    auth_manager = AuthManager()
    if auth_manager.logout():
        print("✅ 退出登录成功")
    else:
        print("❌ 退出登录失败")

def set_tos_jar_prefix(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    updated = auth_manager.set_tos_jar_prefix(args.tos_jar_prefix)
    print("✅ 已保存 TOS Jar 存储路径")
    print(f"TOS Jar Prefix: {updated.tos_jar_prefix}")


def files_list(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("TOS 文件列表")
    try:
        sub_prefix = str(getattr(args, "prefix", "") or "").strip()
        limit = int(getattr(args, "limit", 200) or 200)
        objs = mgr.list(sub_prefix=sub_prefix, limit=limit)
        if getattr(args, "raw", False):
            print(json.dumps([o.__dict__ for o in objs], ensure_ascii=False, indent=2))
            return
        rows = []
        for o in objs:
            rows.append([o.key, str(o.size), o.last_modified, o.etag])
        print_table(rows, ["Key", "Size", "LastModified", "ETag"])
        print(f"\n📊 总计: {len(objs)} 个对象")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_upload(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("上传文件到 TOS")
    try:
        file_path = str(args.file)
        name = str(getattr(args, "name", "") or "").strip() or None
        res = mgr.upload(file_path=file_path, name=name)
        print("✅ 上传成功")
        print(f"TOS: {res.get('tos_uri')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_detail(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("文件详情")
    try:
        name = str(args.name)
        res = mgr.head(name=name)
        print(json.dumps(res, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_update(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("更新文件（覆盖上传）")
    try:
        file_path = str(args.file)
        name = str(args.name)
        res = mgr.upload(file_path=file_path, name=name)
        print("✅ 更新成功")
        print(f"TOS: {res.get('tos_uri')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_url(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("获取文件链接")
    try:
        name = str(args.name)
        expires_in = int(getattr(args, "expires", 3600) or 3600)
        res = mgr.url(name=name, expires_in=expires_in)
        print(f"TOS: {res.get('tos_uri')}")
        print(f"URL: {res.get('url')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def show_config():
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    print_header("当前配置")
    print(f"Region: {credentials.region}")
    print(f"TOS Jar Prefix: {credentials.tos_jar_prefix or ''}")
    print(f"Default Project ID: {credentials.default_project_id or ''}")
    print(f"Default Project Name: {credentials.default_project_name or ''}")

def set_default_project(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    if args.project_id:
        updated = auth_manager.set_default_project_id(args.project_id, project_name=None)
        print("✅ 已保存默认项目")
        print(f"Default Project ID: {updated.default_project_id}")
        return
    project_name = getattr(args, "name", None) or getattr(args, "project_name", None)
    if not project_name:
        raise Exception("请提供 --project-id 或 --name")

    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)
    projects = project_manager.list_projects(search=project_name, page=1, page_size=200)

    exact = [p for p in projects if p.name == project_name]
    candidates = exact or projects
    if not candidates:
        raise Exception("未找到指定项目名称，请使用 projects list 确认名称或直接传 --project-id")
    match = candidates[0]
    updated = auth_manager.set_default_project_id(match.id, project_name=match.name)
    print("✅ 已保存默认项目")
    print(f"Default Project ID: {updated.default_project_id}")
    print(f"Project Name: {match.name}")

def _parse_kv_list(values: Optional[List[str]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not values:
        return out
    for raw in values:
        if raw is None:
            continue
        s = str(raw).strip()
        if not s:
            continue
        if "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        if not k:
            continue
        out[k] = v.strip()
    return out

def _format_session_flinkui(uri_path: str) -> str:
    s = str(uri_path or "").strip()
    if not s:
        return ""
    if s.startswith("http://") or s.startswith("https://"):
        return s
    if s.startswith("/"):
        return "https://console.volcengine.com" + s
    return "https://console.volcengine.com/" + s

def _join_url(endpoint: str, path: str) -> str:
    e = str(endpoint or "").strip()
    p = str(path or "").strip()
    if not e:
        return ""
    if not (e.startswith("http://") or e.startswith("https://")):
        e = "https://" + e
    e = e.rstrip("/")
    if not p:
        return e
    if p.startswith("/"):
        return e + p
    return e + "/" + p

def _resolve_project_id(args: argparse.Namespace, credentials: Credentials) -> str:
    project_id = getattr(args, "project_id", None)
    if project_id:
        return project_id

    project_name = getattr(args, "project", None) or getattr(args, "project_name", None)
    if project_name:
        api_client = ApiClient(credentials)
        project_manager = ProjectManager(api_client)
        projects = project_manager.list_projects(search=project_name, page=1, page_size=200)
        exact = [p for p in projects if p.name == project_name]
        if len(exact) == 1:
            return exact[0].id
        if len(exact) > 1:
            raise Exception("项目名称不唯一，请使用 projects list 确认并改用 --project-id")
        if projects:
            return projects[0].id
        raise Exception("未找到指定项目名称，请使用 projects list 确认名称")

    if credentials.default_project_id:
        return credentials.default_project_id
    if credentials.default_project_name:
        api_client = ApiClient(credentials)
        project_manager = ProjectManager(api_client)
        projects = project_manager.list_projects(search=credentials.default_project_name, page=1, page_size=200)
        exact = [p for p in projects if p.name == credentials.default_project_name]
        if len(exact) == 1:
            return exact[0].id
        if projects:
            return projects[0].id

    raise Exception("未指定项目，请设置默认项目或在命令中传入 -p/--project")

def _draft_console_url(region: str, project_id: str, job_type: str, draft_id: str) -> str:
    active_tab = "jarJob" if "JAR" in (job_type or "").upper() else "sqlJob"
    return (
        f"https://console.volcengine.com/flink/region:flink+{region}"
        f"/project/{project_id}/jobDev?activeModule=jobDev&activeTab={active_tab}-{draft_id}"
    )

def _job_manage_url(region: str, project_id: str) -> str:
    return f"https://console.volcengine.com/flink/region:flink+{region}/project/{project_id}/job/manage"

def _format_job_state(state: str) -> str:
    return (state or "").upper() or "UNKNOWN"

def _try_get_flink_ui_url(job_overview: dict) -> Optional[str]:
    if not isinstance(job_overview, dict):
        return None
    url = job_overview.get("CompleteRestUrl") or job_overview.get("RestUrl")
    if isinstance(url, str) and url.strip():
        return url.strip()
    return None

def _start_mode_label(start_type: str, savepoint_id: Optional[str] = None) -> str:
    if start_type == "FROM_LATEST":
        return "最新状态恢复"
    if start_type == "FROM_NEW":
        return "全新启动（丢弃状态）"
    if start_type == "FROM_SAVEPOINT":
        return f"Savepoint 恢复（{savepoint_id}）" if savepoint_id else "Savepoint 恢复"
    return start_type or "UNKNOWN"


def list_projects(args: argparse.Namespace):
    """列举项目命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)
    
    print_header("项目列表")
    try:
        projects = project_manager.list_projects(
            page=args.page_num,
            page_size=args.page_size,
            search=args.search_key
        )
        data = []
        for project in projects:
            data.append([
                project.id,
                project.name,
                project.status,
                project.create_time
            ])
        
        print_table(data, ["项目ID", "项目名称", "状态", "创建时间"])
        print(f"\n📊 总计: {len(projects)} 个项目")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_project_details(args: argparse.Namespace):
    """项目详情命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)
    
    print_header("项目详情")
    try:
        project = project_manager.get_project_details(project_name=args.name)
        print(f"项目ID: {project.id}")
        print(f"项目名称: {project.name}")
        print(f"状态: {project.status}")
        print(f"创建时间: {project.create_time}")
        print(f"更新时间: {project.update_time}")
        if project.description:
            print(f"描述: {project.description}")
        if project.owner:
            print(f"Owner: {project.owner}")
        if isinstance(project.tags, dict) and project.tags:
            print("Tags:")
            for k, v in project.tags.items():
                print(f"  {k}: {v}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_tree(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)

    region = str(getattr(args, "region", None) or credentials.region)
    include_details = bool(getattr(args, "details", False))
    include_table_details = bool(getattr(args, "table_details", False))
    raw = bool(getattr(args, "raw", False))

    print_header("Catalog 树")
    try:
        catalogs = manager.list_catalogs(region=region)
        only_catalog_id = getattr(args, "catalog_id", None)
        if only_catalog_id is not None and str(only_catalog_id).strip():
            catalogs = [c for c in catalogs if str(c.get("Id") or c.get("CatalogId") or "") == str(only_catalog_id).strip()]
        only_catalog_name = getattr(args, "catalog_name", None)
        if only_catalog_name is not None and str(only_catalog_name).strip():
            name_want = str(only_catalog_name).strip()
            catalogs = [
                c
                for c in catalogs
                if str(c.get("Name") or c.get("CatalogName") or "").strip() == name_want
            ]
        only_db = getattr(args, "database", None)
        only_db = str(only_db).strip() if only_db is not None and str(only_db).strip() else None
        only_table = getattr(args, "table", None)
        only_table = str(only_table).strip() if only_table is not None and str(only_table).strip() else None

        catalog_selected = bool((only_catalog_id is not None and str(only_catalog_id).strip()) or (only_catalog_name is not None and str(only_catalog_name).strip()))

        tree: List[Dict[str, Any]] = []

        def _fmt_catalog(c: Dict[str, Any]) -> str:
            cid = c.get("Id") or c.get("CatalogId") or ""
            name = c.get("Name") or c.get("CatalogName") or ""
            typ = c.get("Type") or c.get("CatalogType") or ""
            parts = [str(x) for x in [name or cid, typ] if str(x)]
            return " ".join(parts).strip()

        def _fmt_db(d: Dict[str, Any]) -> str:
            name = d.get("DatabaseName") or d.get("Name") or d.get("DbName") or ""
            typ = d.get("Type") or d.get("DatabaseType") or ""
            parts = [str(x) for x in [name, typ] if str(x)]
            return " ".join(parts).strip()

        def _fmt_table(t: Dict[str, Any]) -> str:
            name = t.get("TableName") or t.get("Name") or ""
            typ = t.get("Type") or t.get("TableType") or ""
            parts = [str(x) for x in [name, typ] if str(x)]
            return " ".join(parts).strip()

        if not catalog_selected:
            lines: List[str] = []
            for ci, c in enumerate(catalogs):
                if not isinstance(c, dict):
                    continue
                cid = str(c.get("Id") or c.get("CatalogId") or "").strip()
                if not cid:
                    continue
                is_last_catalog = ci == len(catalogs) - 1
                c_prefix = "└── " if is_last_catalog else "├── "
                lines.append(f"{c_prefix}Catalog {cid} {_fmt_catalog(c)}")

            if raw:
                print(json.dumps({"region": region, "project_id": project_id, "catalogs": catalogs}, ensure_ascii=False, indent=2))
                return
            for ln in lines:
                print(ln)
            print(f"\n📊 Catalog: {len(catalogs)}")
            return

        for ci, c in enumerate(catalogs):
            if not isinstance(c, dict):
                continue
            cid = str(c.get("Id") or c.get("CatalogId") or "").strip()
            if not cid:
                continue
            print(f"Catalog {cid} {_fmt_catalog(c)}")
            node_catalog: Dict[str, Any] = {"catalog": c, "databases": []}

            dbs = manager.list_catalog_databases(region=region, catalog_id=cid)
            if not dbs:
                embedded = (
                    c.get("CatalogDatabases")
                    or c.get("Databases")
                    or c.get("DatabaseList")
                    or c.get("CatalogDatabaseList")
                    or []
                )
                if isinstance(embedded, list):
                    dbs = [x for x in embedded if isinstance(x, dict)]
            if only_db:
                dbs = [
                    d
                    for d in dbs
                    if str(d.get("DatabaseName") or d.get("Name") or "").strip() == only_db
                ]

            db_rows = []
            for d in dbs:
                if not isinstance(d, dict):
                    continue
                db_name = str(d.get("DatabaseName") or d.get("Name") or d.get("DbName") or "").strip()
                if not db_name:
                    continue
                db_id = d.get("Id") or d.get("DatabaseId") or ""
                db_type = d.get("Type") or d.get("DatabaseType") or ""
                db_rows.append([db_name, db_id, db_type])
            if raw:
                tree.append(node_catalog)
            if db_rows:
                print_table(db_rows, ["DatabaseName", "Id", "Type"])
                print(f"\n📊 Database: {len(db_rows)}")
            else:
                print("无 Database")
                print("\n📊 Database: 0")

            if not only_db:
                continue

            for di, d in enumerate(dbs):
                if not isinstance(d, dict):
                    continue
                db_name = str(d.get("DatabaseName") or d.get("Name") or d.get("DbName") or "").strip()
                if not db_name:
                    continue
                print(f"\nDB {db_name} {_fmt_db(d)}")

                db_detail: Optional[Dict[str, Any]] = None
                if include_details:
                    try:
                        db_detail = manager.get_catalog_database(region=region, catalog_id=cid, database_name=db_name)
                    except Exception:
                        db_detail = None

                tables = manager.list_catalog_tables(region=region, catalog_id=cid, database_name=db_name)
                if not tables:
                    embedded_tables = (
                        d.get("CatalogTables")
                        or d.get("Tables")
                        or d.get("TableList")
                        or d.get("CatalogTableList")
                        or []
                    )
                    if isinstance(embedded_tables, list):
                        tables = [x for x in embedded_tables if isinstance(x, dict)]
                if only_table:
                    tables = [
                        t
                        for t in tables
                        if str(t.get("TableName") or t.get("Name") or "").strip() == only_table
                    ]

                node_db: Dict[str, Any] = {"database": d, "detail": db_detail, "tables": []}

                tbl_rows = []
                for t in tables:
                    if not isinstance(t, dict):
                        continue
                    table_name = str(t.get("TableName") or t.get("Name") or "").strip()
                    if not table_name:
                        continue
                    table_id = t.get("Id") or t.get("TableId") or ""
                    table_type = t.get("Type") or t.get("TableType") or ""
                    tbl_rows.append([table_name, table_id, table_type])

                    table_detail: Optional[Dict[str, Any]] = None
                    if include_table_details:
                        try:
                            table_detail = manager.get_catalog_table(region=region, catalog_id=cid, database_name=db_name, table_name=table_name)
                        except Exception:
                            table_detail = None

                    node_db["tables"].append({"table": t, "detail": table_detail})

                node_catalog["databases"].append(node_db)
                if tbl_rows:
                    print_table(tbl_rows, ["TableName", "Id", "Type"])
                    print(f"\n📊 Table: {len(tbl_rows)}")
                else:
                    print("无 Table")
                    print("\n📊 Table: 0")

            tree.append(node_catalog)

        if raw:
            print(json.dumps({"region": region, "project_id": project_id, "tree": tree}, ensure_ascii=False, indent=2))
            return
        print(f"\n📊 Catalog: {len(catalogs)}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_catalogs(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Catalog 列表")
    try:
        catalogs = manager.list_catalogs(region=region)
        if raw:
            print(json.dumps(catalogs, ensure_ascii=False, indent=2))
            return
        rows = []
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            cid = c.get("Id") or c.get("CatalogId") or ""
            name = c.get("Name") or c.get("CatalogName") or ""
            typ = c.get("Type") or c.get("CatalogType") or ""
            rows.append([cid, name, typ])
        print_table(rows, ["CatalogId", "Name", "Type"])
        print(f"\n📊 总计: {len(rows)} 个 Catalog")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_catalog(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Catalog 详情")
    try:
        catalogs = manager.list_catalogs(region=region)
        cid = str(getattr(args, "catalog_id", "") or "").strip()
        cname = str(getattr(args, "catalog_name", "") or "").strip()
        pick = None
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            if cid and str(c.get("Id") or c.get("CatalogId") or "").strip() == cid:
                pick = c
                break
            if cname and str(c.get("Name") or c.get("CatalogName") or "").strip() == cname:
                pick = c
                break
        if not pick:
            raise Exception("未找到指定 Catalog，请检查 --catalog-id/--catalog-name")
        if raw:
            print(json.dumps(pick, ensure_ascii=False, indent=2))
            return
        print(json.dumps(pick, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_databases(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Database 列表")
    try:
        catalogs = manager.list_catalogs(region=region)
        cid = str(getattr(args, "catalog_id", "") or "").strip()
        cname = str(getattr(args, "catalog_name", "") or "").strip()
        if not cid and not cname:
            raise Exception("必须指定 --catalog-id 或 --catalog-name")
        pick = None
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            if cid and str(c.get("Id") or c.get("CatalogId") or "").strip() == cid:
                pick = c
                break
            if cname and str(c.get("Name") or c.get("CatalogName") or "").strip() == cname:
                pick = c
                break
        if not pick:
            raise Exception("未找到指定 Catalog，请检查 --catalog-id/--catalog-name")
        catalog_id = str(pick.get("Id") or pick.get("CatalogId") or "").strip()
        dbs = manager.list_catalog_databases(region=region, catalog_id=catalog_id)
        if not dbs:
            embedded = (
                pick.get("CatalogDatabases")
                or pick.get("Databases")
                or pick.get("DatabaseList")
                or pick.get("CatalogDatabaseList")
                or []
            )
            if isinstance(embedded, list):
                dbs = [x for x in embedded if isinstance(x, dict)]
        if raw:
            print(json.dumps(dbs, ensure_ascii=False, indent=2))
            return
        rows = []
        for d in dbs:
            if not isinstance(d, dict):
                continue
            name = d.get("DatabaseName") or d.get("Name") or d.get("DbName") or ""
            did = d.get("Id") or d.get("DatabaseId") or ""
            typ = d.get("Type") or d.get("DatabaseType") or ""
            rows.append([name, did, typ])
        print_table(rows, ["DatabaseName", "Id", "Type"])
        print(f"\n📊 总计: {len(rows)} 个 Database")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_database(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Database 详情")
    try:
        catalogs = manager.list_catalogs(region=region)
        cid = str(getattr(args, "catalog_id", "") or "").strip()
        cname = str(getattr(args, "catalog_name", "") or "").strip()
        db_name = str(getattr(args, "database", "") or "").strip()
        if not db_name:
            raise Exception("必须指定 --database")
        if not cid and not cname:
            raise Exception("必须指定 --catalog-id 或 --catalog-name")
        pick = None
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            if cid and str(c.get("Id") or c.get("CatalogId") or "").strip() == cid:
                pick = c
                break
            if cname and str(c.get("Name") or c.get("CatalogName") or "").strip() == cname:
                pick = c
                break
        if not pick:
            raise Exception("未找到指定 Catalog，请检查 --catalog-id/--catalog-name")
        catalog_id = str(pick.get("Id") or pick.get("CatalogId") or "").strip()
        data = manager.get_catalog_database(region=region, catalog_id=catalog_id, database_name=db_name)
        print(json.dumps(data if raw else data, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_tables(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Table 列表")
    try:
        catalogs = manager.list_catalogs(region=region)
        cid = str(getattr(args, "catalog_id", "") or "").strip()
        cname = str(getattr(args, "catalog_name", "") or "").strip()
        db_name = str(getattr(args, "database", "") or "").strip()
        if not db_name:
            raise Exception("必须指定 --database")
        if not cid and not cname:
            raise Exception("必须指定 --catalog-id 或 --catalog-name")
        pick = None
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            if cid and str(c.get("Id") or c.get("CatalogId") or "").strip() == cid:
                pick = c
                break
            if cname and str(c.get("Name") or c.get("CatalogName") or "").strip() == cname:
                pick = c
                break
        if not pick:
            raise Exception("未找到指定 Catalog，请检查 --catalog-id/--catalog-name")
        catalog_id = str(pick.get("Id") or pick.get("CatalogId") or "").strip()
        tables = manager.list_catalog_tables(region=region, catalog_id=catalog_id, database_name=db_name)
        if not tables:
            embedded = (
                pick.get("CatalogDatabases")
                or pick.get("Databases")
                or pick.get("DatabaseList")
                or pick.get("CatalogDatabaseList")
                or []
            )
            if isinstance(embedded, list):
                for d in embedded:
                    if not isinstance(d, dict):
                        continue
                    name = str(d.get("DatabaseName") or d.get("Name") or "").strip()
                    if name == db_name:
                        embedded_tables = (
                            d.get("CatalogTables")
                            or d.get("Tables")
                            or d.get("TableList")
                            or d.get("CatalogTableList")
                            or []
                        )
                        if isinstance(embedded_tables, list):
                            tables = [x for x in embedded_tables if isinstance(x, dict)]
                        break
        if raw:
            print(json.dumps(tables, ensure_ascii=False, indent=2))
            return
        rows = []
        for t in tables:
            if not isinstance(t, dict):
                continue
            name = t.get("TableName") or t.get("Name") or ""
            tid = t.get("Id") or t.get("TableId") or ""
            typ = t.get("Type") or t.get("TableType") or ""
            rows.append([name, tid, typ])
        print_table(rows, ["TableName", "Id", "Type"])
        print(f"\n📊 总计: {len(rows)} 个 Table")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_table(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = CatalogManager(api_client, project_id)
    region = str(getattr(args, "region", None) or credentials.region)
    raw = bool(getattr(args, "raw", False))

    print_header("Table 详情")
    try:
        catalogs = manager.list_catalogs(region=region)
        cid = str(getattr(args, "catalog_id", "") or "").strip()
        cname = str(getattr(args, "catalog_name", "") or "").strip()
        db_name = str(getattr(args, "database", "") or "").strip()
        table_name = str(getattr(args, "table", "") or "").strip()
        if not db_name:
            raise Exception("必须指定 --database")
        if not table_name:
            raise Exception("必须指定 --table")
        if not cid and not cname:
            raise Exception("必须指定 --catalog-id 或 --catalog-name")
        pick = None
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            if cid and str(c.get("Id") or c.get("CatalogId") or "").strip() == cid:
                pick = c
                break
            if cname and str(c.get("Name") or c.get("CatalogName") or "").strip() == cname:
                pick = c
                break
        if not pick:
            raise Exception("未找到指定 Catalog，请检查 --catalog-id/--catalog-name")
        catalog_id = str(pick.get("Id") or pick.get("CatalogId") or "").strip()
        data = manager.get_catalog_table(region=region, catalog_id=catalog_id, database_name=db_name, table_name=table_name)
        print(json.dumps(data if raw else data, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_list(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("Session 集群列表")
    try:
        clusters = manager.list_clusters()
        if getattr(args, "raw", False):
            print(json.dumps(clusters, ensure_ascii=False, indent=2))
            return
        rows = []
        for c in clusters:
            if not isinstance(c, dict):
                continue
            cid = c.get("Id") or c.get("ClusterId") or ""
            name = c.get("Name") or ""
            runtime_status = c.get("RuntimeStatus") or c.get("State") or c.get("Status") or ""
            engine = c.get("EngineVersion") or ""
            rp = c.get("ResourcePool") or c.get("Queue") or ""
            cluster_id = c.get("ClusterId") or c.get("ClusterID") or c.get("Cluster") or c.get("cluster") or ""
            account_id = c.get("AccountId") or c.get("AccountID") or c.get("Account") or c.get("account") or ""
            uri = SessionClusterManager.pick_uri_path(c)
            rows.append([cid, name, runtime_status, engine, rp, cluster_id, account_id, uri])
        print_table(rows, ["Id", "Name", "RuntimeStatus", "EngineVersion", "ResourcePool", "ClusterId", "AccountId", "UriPath"])
        print(f"\n📊 总计: {len(rows)} 个 Session 集群")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_create(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("创建 Session 集群")
    try:
        dynamic = {}
        if getattr(args, "dynamic_properties", None):
            try:
                dynamic = json.loads(str(args.dynamic_properties))
            except Exception:
                dynamic = {}
        if not isinstance(dynamic, dict):
            dynamic = {}
        dynamic.update(_parse_kv_list(getattr(args, "kv", None)))

        spec: Dict[str, Any] = {
            "TmMinNumber": int(args.tm_min),
            "TmMaxNumber": int(args.tm_max),
            "TmVcore": int(args.tm_vcore),
            "TmMemory": int(args.tm_memory),
            "SlotsPerTm": int(args.slots_per_tm),
            "JmVcore": int(args.jm_vcore),
            "JmMemory": int(args.jm_memory),
            "DynamicProperties": dynamic,
            "Name": str(args.name),
            "ResourcePool": str(args.resource_pool),
            "EngineVersion": str(args.engine_version),
            "Queue": str(args.queue),
            "Context": str(getattr(args, "context", "") or ""),
            "ProjectId": str(project_id),
        }
        resp = manager.create_cluster(spec)
        print("✅ 创建请求已提交")
        print(json.dumps(resp, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_start(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("启动 Session 集群")
    try:
        resp = manager.start_cluster(str(args.id))
        print("✅ 启动请求已提交")
        print(json.dumps(resp, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_stop(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("停止 Session 集群")
    try:
        resp = manager.stop_cluster(str(args.id))
        print("✅ 停止请求已提交")
        print(json.dumps(resp, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_ui(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("Session FlinkUI")
    try:
        clusters = manager.list_clusters()
        target_id = str(getattr(args, "id", "") or "").strip()
        target_name = str(getattr(args, "name", "") or "").strip()
        hit = None
        for c in clusters:
            if not isinstance(c, dict):
                continue
            cid = str(c.get("Id") or c.get("ClusterId") or c.get("ClusterID") or "").strip()
            cname = str(c.get("Name") or "").strip()
            if target_id and cid == target_id:
                hit = c
                break
            if target_name and cname == target_name:
                hit = c
                break
        if not hit:
            raise Exception("未找到 Session 集群，请使用 sessions list 查看 Id/Name")
        uri = SessionClusterManager.pick_uri_path(hit)
        if not uri:
            raise Exception("未获取到 UriPath")
        account_id = ""
        for k in ("AccountId", "AccountID", "Account", "account", "OwnerAccountId", "UserId"):
            v = hit.get(k)
            if v is not None and str(v).strip():
                account_id = str(v).strip()
                break

        cluster_id = ""
        for k in ("ClusterId", "ClusterID", "Cluster", "cluster", "GmsClusterId", "ClusterUuid", "ClusterUUID"):
            v = hit.get(k)
            if v is not None and str(v).strip():
                cluster_id = str(v).strip()
                break
        if not account_id:
            raise Exception("未获取到 AccountId")
        if not cluster_id:
            raise Exception("未获取到 ClusterId")

        token = manager.get_user_token(token_valid_seconds=10800)
        runtime_status = str(hit.get("RuntimeStatus") or hit.get("State") or hit.get("Status") or "").strip()

        endpoint = ""
        last_err: Optional[Exception] = None
        for svc in ("LOGIN", "FLINKUI", "FlinkUI", "UI"):
            try:
                gw = manager.get_gateway_service(cluster_id=cluster_id, account_id=account_id, service=svc, type_="")
                endpoint = SessionClusterManager.pick_gateway_endpoint(gw)
                if endpoint:
                    break
            except Exception as e:
                last_err = e
                if "no service found" in str(e).lower():
                    continue
                raise
        if not endpoint and last_err is not None:
            if "no service found" in str(last_err).lower():
                if runtime_status:
                    raise Exception(f"no service found（RuntimeStatus={runtime_status}），请确认 Session 集群已启动并处于 RUNNING")
                raise last_err
            raise last_err
        if not endpoint:
            raise Exception("未获取到 gateway endpoint")

        base = _join_url(endpoint, uri)
        if not base:
            raise Exception("未生成 FlinkUI 地址")
        base = base.rstrip("/") + "/#overview"
        sep = "&" if "?" in base else "?"
        print(f"{base}{sep}token={token}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_resource_pools(args: argparse.Namespace):
    """列举资源池命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)
    
    print_header("资源池列表")
    try:
        pools = resource_pool_manager.list_resource_pools(page=1, page_size=50)
        data = []
        for pool in pools:
            data.append([
                pool.id,
                pool.name,
                pool.type,
                pool.status,
                pool.vcores,
                pool.memory_gb
            ])
        
        print_table(data, ["资源池ID", "名称", "类型", "状态", "CPU核数", "内存(GB)"])
        print(f"\n📊 总计: {len(pools)} 个资源池")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def create_resource_pool(args: argparse.Namespace):
    """创建资源池命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)
    
    print_header("创建资源池")
    try:
        spec = ResourcePoolSpec(
            vcores=args.vcores,
            memory_gb=args.memory_gb,
            type="flink"
        )
        
        pool = resource_pool_manager.create_resource_pool(
            name=args.name,
            description=args.description,
            spec=spec
        )
        
        print(f"✅ 资源池创建成功!")
        print(f"ID: {pool.id}")
        print(f"名称: {pool.name}")
        print(f"状态: {pool.status}")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def get_resource_pool_details(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)

    print_header("资源池详情")
    try:
        ref = args.resource_pool_id or args.name
        pool = resource_pool_manager.get_resource_pool_details(ref)
        data = [
            ["资源池ID", pool.id],
            ["名称", pool.name],
            ["FullName", pool.full_name],
            ["类型", pool.type],
            ["状态", pool.status],
            ["CPU核数", str(pool.vcores)],
            ["内存(GB)", str(pool.memory_gb)],
            ["可用CPU核数", str(pool.available_vcores)],
            ["可用内存(GB)", str(pool.available_memory_gb)],
            ["描述", pool.description],
            ["创建时间", pool.create_time],
            ["更新时间", pool.update_time],
            ["标签", json.dumps(pool.tags, ensure_ascii=False) if pool.tags else ""],
        ]
        print_table(data, ["字段", "值"])

        extra_info = getattr(pool, "extra_info", None)
        if isinstance(extra_info, dict) and extra_info:
            print("\nExtraInfo:")
            print(json.dumps(extra_info, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_drafts(args: argparse.Namespace):
    """列举草稿命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)

    print_header("草稿列表")
    try:
        apps = draft_manager.list_draft_applications(type="JOB")
        directory = str(getattr(args, "directory", "") or "").strip()
        if directory:
            if "/" in directory:
                path = "/" + "/".join([p for p in directory.strip("/").split("/") if p])
                apps = [a for a in apps if a.directory_path == path]
            else:
                apps = [a for a in apps if a.directory_name == directory]
        data = []
        for a in apps:
            data.append([
                a.id,
                a.name,
                a.job_type,
                a.directory_path,
                a.modified_time,
                "true" if a.is_deployed else "false",
                a.app_id or "",
            ])
        print_table(data, ["草稿ID", "名称", "类型", "目录路径", "更新时间", "已部署", "AppId"])
        print(f"\n📊 总计: {len(apps)} 个草稿")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_draft_directories(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿目录列表")
    try:
        directories = draft_manager.list_draft_directories(type="JOB")
        data = []
        for d in directories:
            data.append([d.id, d.name, d.path, d.parent_id or "", d.create_time])
        print_table(data, ["目录ID", "目录名称", "目录路径", "父目录ID", "创建时间"])
        print(f"\n📊 总计: {len(directories)} 个目录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def create_draft_directory(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("创建草稿目录")
    try:
        result = draft_manager.ensure_directory_path(path=str(args.name), directory_type="JOB")
        print("✅ 创建成功")
        print(f"Path: {result.get('Path')}")
        print(f"Id: {result.get('Id')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def delete_draft_directory(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除草稿目录")
    try:
        dir_id = str(getattr(args, "id", "") or "").strip()
        raw = str(getattr(args, "name", "") or "").strip()
        if not dir_id and not raw:
            raise Exception("请提供 --id 或 --name")
        if not dir_id:
            directories = draft_manager.list_draft_directories(type="JOB")
            want = "/" + "/".join([p for p in raw.strip("/").split("/") if p])
            hit = None
            for d in directories:
                if d.path == want:
                    hit = d
                    break
            if not hit or not hit.id:
                raise Exception("未找到目录路径，请使用 drafts dirs 查看可用目录")
            dir_id = hit.id
        draft_manager.delete_directory(dir_id)
        print("✅ 删除成功")
        if raw:
            print(f"Path: {raw}")
        print(f"Id: {dir_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def delete_draft_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除草稿")
    try:
        draft_id = str(getattr(args, "id", "") or "").strip()
        draft_ref = str(getattr(args, "name", "") or "").strip()
        if not draft_id and not draft_ref:
            raise Exception("请提供 --id 或 --name")
        if not draft_id:
            draft_id = draft_manager.resolve_draft_id(draft_ref)
        draft_manager.delete_draft(draft_id)
        print("✅ 删除成功")
        if draft_ref:
            print(f"Name: {draft_ref}")
        print(f"Id: {draft_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def get_draft_content(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿内容")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)
        content = draft_manager.get_draft_content(draft_id)
        print(f"草稿ID: {draft.id}")
        print(f"名称: {draft.name}")
        print(f"类型: {draft.type}")
        if content.sql:
            print("SQL:")
            print(content.sql)
        if content.jar_uris:
            print("JAR:")
            for u in content.jar_uris:
                print(u)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def validate_draft_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("SQL 校验")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)
        if "SQL" not in str(draft.type or "").upper():
            raise Exception(f"仅支持 SQL 类型草稿校验，当前 JobType={draft.type}")
        resp = draft_manager.validate_draft(draft_id)
        if getattr(args, "raw", False):
            print(json.dumps(resp, ensure_ascii=False, indent=2))
            return
        result: Dict[str, Any] = {}
        if isinstance(resp, dict) and isinstance(resp.get("Result"), dict):
            result = resp["Result"]
        elif isinstance(resp, dict) and "Data" in resp:
            result = resp
        ok = result.get("Data")
        vtype = str(result.get("Type") or "")
        reason = str(result.get("Reason") or "").strip()
        solution = str(result.get("Solution") or "").strip()
        msg = str(result.get("Message") or "").rstrip()
        if ok is True:
            print("✅ SQL 语法校验通过")
            return
        print("❌ SQL 校验失败")
        if vtype:
            print(f"Type: {vtype}")
        if reason:
            print(f"Reason: {reason}")
        if solution:
            print(f"Solution: {solution}")
        if msg:
            print(msg)
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_draft_apps(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿列表")
    try:
        apps = draft_manager.list_draft_applications(type="JOB")
        if args.directory:
            directory = args.directory.strip()
            if "/" in directory:
                path = "/" + "/".join([p for p in directory.strip("/").split("/") if p])
                apps = [a for a in apps if a.directory_path == path]
            else:
                apps = [a for a in apps if a.directory_name == directory]
        data = []
        for a in apps:
            data.append([
                a.id,
                a.name,
                a.job_type,
                a.directory_path,
                a.modified_time,
                "true" if a.is_deployed else "false",
                a.app_id or "",
            ])
        print_table(data, ["草稿ID", "名称", "类型", "目录路径", "更新时间", "已部署", "AppId"])
        print(f"\n📊 总计: {len(apps)} 个草稿")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def create_draft(args: argparse.Namespace):
    """创建草稿命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    
    print_header("创建草稿")
    try:
        job_type = args.job_type
        if not job_type:
            if args.type not in ("sql", "jar") or args.mode not in ("streaming", "batch"):
                raise Exception("请使用 --job-type 或同时提供 --type (sql|jar) 与 --mode (streaming|batch)")
            job_type = f"FLINK_{args.mode.upper()}_{args.type.upper()}"

        engine_version = args.engine_version
        engine_version_map = {
            "FLINK_1_16": "FLINK_VERSION_1_16",
            "FLINK_1_17": "FLINK_VERSION_1_17",
            "FLINK_1_20": "FLINK_VERSION_1_20",
        }
        engine_version = engine_version_map.get(engine_version, engine_version)

        directory_id = args.directory_id
        if not directory_id:
            directory = args.directory
            if not directory:
                raise Exception("请提供 --directory-id 或 --directory")
            directory_id = draft_manager.resolve_directory_id(directory)

        draft_id = draft_manager.create_application_draft(
            job_name=args.name,
            directory_id=directory_id,
            job_type=job_type,
            engine_version=engine_version,
        )

        sql_text = ""
        jar_uris = None

        if job_type.endswith("_SQL"):
            if args.sql:
                sql_text = args.sql
            elif args.sql_file:
                sql_text = Path(args.sql_file).expanduser().read_text(encoding="utf-8")
            elif args.sql_dir:
                sql_dir = Path(args.sql_dir).expanduser()
                files = sorted([p for p in sql_dir.rglob("*.sql") if p.is_file()])
                sql_text = "\n\n".join([p.read_text(encoding="utf-8") for p in files])
            else:
                raise Exception("SQL 作业需要提供 --sql 或 --sql-file 或 --sql-dir")

        if job_type.endswith("_JAR"):
            if not args.main_class:
                raise Exception("JAR 作业需要提供 --main-class")

            jar_tos = None
            jar_ref = getattr(args, "jar", None) or None
            if jar_ref:
                if str(jar_ref).strip().startswith("tos://"):
                    jar_tos = str(jar_ref).strip()
                else:
                    print("开始上传 JAR 到 TOS ...")
                    jar_tos = draft_manager.upload_jar_if_needed(str(jar_ref))
                    print(f"✅ 上传成功: {jar_tos}")
            elif args.jar_tos:
                jar_tos = args.jar_tos
            elif args.jar_path:
                print("开始上传 JAR 到 TOS ...")
                jar_tos = draft_manager.upload_jar_if_needed(args.jar_path)
                print(f"✅ 上传成功: {jar_tos}")
            else:
                raise Exception("JAR 作业需要提供 --jar/--jar-path 或 --jar-tos")

            jar_uris = [jar_tos] if jar_tos else None

        main_args = None
        if getattr(args, "main_arg", None):
            main_args = {}
            for item in args.main_arg:
                if "=" not in item:
                    raise Exception("MainArgs 参数格式错误，应为 key=value")
                k, v = item.split("=", 1)
                main_args[str(k)] = str(v)

        draft_manager.update_application_draft(
            draft_id=draft_id,
            sql_text=sql_text,
            jar_uris=jar_uris,
            jar=(jar_uris[0] if jar_uris else None),
            main_class=getattr(args, "main_class", None),
            args=getattr(args, "args", None),
            main_args=main_args,
        )
        print("✅ 草稿创建成功!")
        print(f"草稿ID: {draft_id}")
        print(f"作业类型: {job_type}")
        print(f"Web: {_draft_console_url(credentials.region, project_id, job_type, draft_id)}")
        print(f"发布命令: volc_flink drafts publish --draft-id {draft_id} --resource-pool YOUR_RESOURCE_POOL_NAME")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def publish_draft(args: argparse.Namespace):
    """发布草稿命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    
    print_header("发布草稿")
    try:
        resource_pool = args.resource_pool
        queue = args.queue
        resource_pool_id = args.resource_pool_id

        rpm = ResourcePoolManager(api_client, project_id)

        if resource_pool_id:
            if not resource_pool or not queue:
                pools = rpm.list_resource_pools(page=1, page_size=1000)
                match = next((p for p in pools if p.id == resource_pool_id), None)
                if not match:
                    raise Exception("未找到指定资源池ID")
                resource_pool = resource_pool or match.name
                queue = queue or match.id

        if resource_pool and not queue:
            pools = rpm.list_resource_pools(page=1, page_size=1000)
            matches = [p for p in pools if p.name == resource_pool]
            if len(matches) == 1:
                queue = matches[0].id
            elif len(matches) > 1:
                raise Exception("资源池名称不唯一，请使用资源池列表确认后再指定")
            else:
                raise Exception("未找到指定资源池名称，请使用 resource-pools list 查询")

        if not resource_pool and not queue:
            raise Exception("请提供 --resource-pool（资源池名称）")

        if not resource_pool:
            pools = rpm.list_resource_pools(page=1, page_size=1000)
            match = next((p for p in pools if p.id == queue), None)
            if not match:
                raise Exception("未找到指定资源池，请使用 resource-pools list 查询")
            resource_pool = match.name

        if not resource_pool or not queue:
            raise Exception("资源池解析失败，请检查资源池名称或使用 resource-pools list 查询")

        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        resp = draft_manager.publish_draft(
            draft_id=draft_id,
            resource_pool=resource_pool,
            queue=queue,
            priority=args.priority,
            schedule_policy=args.schedule_policy,
            schedule_timeout=args.schedule_timeout,
        )
        print("✅ 草稿发布请求已提交!")
        print(f"运维页面: {_job_manage_url(credentials.region, project_id)}")
        if isinstance(resp, dict):
            job_id = resp.get("AppId") or resp.get("JobId") or resp.get("Id")
            if job_id:
                print(f"JobId: {job_id}")
                print(f"启动命令: volc_flink jobs start --job-id {job_id}")
            else:
                print("未获取到 JobId，请打开运维页面在列表中查看任务ID后再启动")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def update_draft(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("更新草稿")
    try:
        sql_text = None
        jar_uris = None
        jar_tos = None

        if args.sql or args.sql_file or args.sql_dir:
            if args.sql:
                sql_text = args.sql
            elif args.sql_file:
                sql_text = Path(args.sql_file).expanduser().read_text(encoding="utf-8")
            elif args.sql_dir:
                sql_dir = Path(args.sql_dir).expanduser()
                files = sorted([p for p in sql_dir.rglob("*.sql") if p.is_file()])
                sql_text = "\n\n".join([p.read_text(encoding="utf-8") for p in files])

        jar_ref = getattr(args, "jar", None) or None
        if jar_ref or args.jar_tos or args.jar_path:
            if jar_ref:
                if str(jar_ref).strip().startswith("tos://"):
                    jar_tos = str(jar_ref).strip()
                else:
                    print("开始上传 JAR 到 TOS ...")
                    jar_tos = draft_manager.upload_jar_if_needed(str(jar_ref))
                    print(f"✅ 上传成功: {jar_tos}")
            elif args.jar_tos:
                jar_tos = args.jar_tos
            else:
                print("开始上传 JAR 到 TOS ...")
                jar_tos = draft_manager.upload_jar_if_needed(args.jar_path)
                print(f"✅ 上传成功: {jar_tos}")
            jar_uris = [jar_tos]

        if sql_text is None and jar_uris is None and not args.main_class and not args.args and not getattr(args, "main_arg", None):
            raise Exception("请至少提供一种更新内容：--sql/--sql-file/--sql-dir 或 --jar-path/--jar-tos 或 --main-class/--args/--main-arg")

        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)

        main_args = None
        if getattr(args, "main_arg", None):
            main_args = {}
            for item in args.main_arg:
                if "=" not in item:
                    raise Exception("MainArgs 参数格式错误，应为 key=value")
                k, v = item.split("=", 1)
                main_args[str(k)] = str(v)

        draft_manager.update_application_draft(
            draft_id=draft_id,
            sql_text=sql_text,
            jar_uris=jar_uris,
            jar=jar_tos,
            main_class=args.main_class,
            args=args.args,
            main_args=main_args,
        )
        print("✅ 草稿更新成功!")
        print(f"草稿ID: {draft_id}")
        print(f"Web: {_draft_console_url(credentials.region, project_id, draft.type, draft_id)}")
        publish_ref = f"--draft {draft_ref!r}" if not str(draft_ref).isdigit() else f"--draft-id {draft_id}"
        print(f"发布命令: volc_flink drafts publish {publish_ref} --resource-pool YOUR_RESOURCE_POOL_NAME")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def drafts_dependency_add(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("添加依赖")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        existing = draft_manager.list_dependency_jars(draft_id)
        to_add: List[str] = []
        for item in args.jar:
            if str(item).strip().startswith("tos://"):
                tos_path = str(item).strip()
            else:
                print("开始上传 JAR 到 TOS ...")
                tos_path = draft_manager.upload_jar_if_needed(str(item))
                print(f"✅ 上传成功: {tos_path}")
            if tos_path not in existing and tos_path not in to_add:
                to_add.append(tos_path)

        if not to_add:
            print("未新增依赖（已存在或未提供有效路径）")
            return

        new_list = existing + to_add
        draft_manager.update_application_draft(draft_id=draft_id, jar_uris=new_list)
        print("✅ 依赖已更新")
        print(json.dumps({"jars": new_list}, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def drafts_dependency_remove(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除依赖")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        existing = draft_manager.list_dependency_jars(draft_id)
        remove_set = set([str(x).strip() for x in args.jar if str(x).strip()])
        new_list = [x for x in existing if x not in remove_set]

        if len(new_list) == len(existing):
            print("未删除任何依赖（未匹配到全路径）")
            return

        draft_manager.update_application_draft(draft_id=draft_id, jar_uris=new_list)
        print("✅ 依赖已更新")
        print(json.dumps({"jars": new_list}, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def drafts_params_set(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("设置动态参数")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        if "=" not in args.kv:
            raise Exception("参数格式错误，应为 key=value")
        key, value = args.kv.split("=", 1)
        key = str(key).strip()
        value = str(value)
        if not key:
            raise Exception("参数 key 不能为空")

        draft_manager.update_application_draft(
            draft_id=draft_id,
            dynamic_options_updates={key: value},
        )
        current = draft_manager.get_dynamic_options(draft_id)
        print("✅ 动态参数已更新")
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def drafts_params_unset(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除动态参数")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        key = str(args.key).strip()
        if not key:
            raise Exception("参数 key 不能为空")

        draft_manager.update_application_draft(
            draft_id=draft_id,
            dynamic_options_updates={key: None},
        )
        current = draft_manager.get_dynamic_options(draft_id)
        print("✅ 动态参数已更新")
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def drafts_params_show(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("动态参数列表")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        current = draft_manager.get_dynamic_options(draft_id)
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_jobs(args: argparse.Namespace):
    """列举任务命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    
    print_header("任务列表")
    try:
        jobs = job_manager.list_jobs(
            page=args.page,
            page_size=args.page_size,
            status=args.status,
            type_filter=args.job_type,
            search=args.search,
        )
        data = []
        for job in jobs:
            data.append([
                job.id,
                job.name,
                job.type,
                job.status,
                job.create_time
            ])
        
        print_table(data, ["任务ID", "名称", "类型", "状态", "创建时间"])
        print(f"\n📊 总计: {len(jobs)} 个任务")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_job_instances_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务实例列表")
    try:
        states = args.states
        state = args.state
        if state is None and not states:
            state = ""

        resp = job_manager.list_job_instances(
            job_id=args.job_id,
            state=state,
            states=states,
            page=args.page,
            page_size=args.page_size,
        )
        records = resp.get("Records") or []
        if not isinstance(records, list):
            records = []
        data = []
        for item in records[: int(args.limit)]:
            if not isinstance(item, dict):
                continue
            data.append(
                [
                    str(item.get("InstanceId") or item.get("Id") or ""),
                    str(item.get("State") or ""),
                    str(item.get("StartTime") or ""),
                    str(item.get("EndTime") or ""),
                    str(item.get("Duration") or ""),
                ]
            )
        print_table(data, ["InstanceId", "State", "StartTime", "EndTime", "Duration"])
        total = resp.get("Total")
        if total is None:
            total = len(records)
        print(f"\n📊 总计: {total} 条实例记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def get_job_events_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务事件")
    try:
        events = job_manager.get_job_events(job_id=args.job_id, limit=args.limit)
        events = events[: int(args.limit)]
        if getattr(args, "raw", False):
            print(json.dumps(events, ensure_ascii=False, indent=2))
            return
        data = []
        for item in events:
            if not isinstance(item, dict):
                continue
            def pick(keys: List[str]) -> str:
                for k in keys:
                    v = item.get(k)
                    if v is not None and str(v) != "":
                        return str(v)
                return ""
            data.append(
                [
                    pick(["Time", "EventTime", "Timestamp", "CreateTime", "LastTimestamp", "FirstTimestamp"]),
                    pick(["Level", "Type", "Severity", "EventType"]),
                    pick(["Collector", "Source", "Component", "Reason", "Name", "Title"]),
                    pick(["Message", "Msg", "Content", "Detail"]),
                ]
            )
        print_table(data, ["Time", "Level", "Collector", "Message"])
        print(f"\n📊 总计: {len(events)} 条事件记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def get_job_detail_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务详情")
    try:
        overview = job_manager.get_job_overview(args.job_id)
        details = None
        try:
            details_obj = job_manager.get_job_details(args.job_id)
            details = details_obj.__dict__ if hasattr(details_obj, "__dict__") else None
        except Exception:
            details = None

        if getattr(args, "raw", False):
            print(json.dumps({"overview": overview, "details": details}, ensure_ascii=False, indent=2))
            return

        manage_url = _job_manage_url(credentials.region, project_id)
        flink_ui = _try_get_flink_ui_url(overview)

        rows = []
        def add(k: str, v: Any):
            if v is None:
                return
            s = str(v)
            if s == "":
                return
            rows.append([k, s])

        add("JobId", overview.get("Id") or args.job_id)
        add("JobName", overview.get("JobName"))
        add("JobType", overview.get("JobType"))
        add("State", overview.get("State"))
        add("ProjectId", overview.get("ProjectId") or project_id)
        add("ResourcePool", overview.get("ResourcePool") or overview.get("Queue"))
        add("DraftId", overview.get("AppDraftId"))
        add("CreateTime", overview.get("CreateTime"))
        add("ModifiedTime", overview.get("ModifiedTime"))
        add("StartTime", overview.get("StartTime"))
        add("EndTime", overview.get("EndTime"))
        add("RestUrl", overview.get("RestUrl"))
        add("CompleteRestUrl", overview.get("CompleteRestUrl"))
        add("ManageUrl", manage_url)
        if flink_ui:
            add("FlinkUI", flink_ui)

        print_table(rows, ["Key", "Value"])

        if details and isinstance(details, dict):
            extras = []
            for k in ("resource_pool_id", "draft_id", "create_time", "update_time", "start_time", "end_time", "status", "type", "name"):
                v = details.get(k)
                if v is None or str(v) == "":
                    continue
                extras.append([f"details.{k}", str(v)])
            if extras:
                print()
                print_table(extras, ["Key", "Value"])

    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def get_job_uuid_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务 GtsJobUuid")
    try:
        overview = job_manager.get_job_overview(args.job_id)
        uuid = None
        for k in ("GtsJobUuid", "GTSJobUuid", "GtsJobUUID", "GTSJobUUID"):
            v = overview.get(k) if isinstance(overview, dict) else None
            if v is not None and str(v).strip():
                uuid = str(v).strip()
                break

        if getattr(args, "raw", False):
            print(json.dumps({"JobId": args.job_id, "GtsJobUuid": uuid, "overview": overview}, ensure_ascii=False, indent=2))
            return

        if not uuid:
            raise Exception("未在任务概览中找到 GtsJobUuid 字段，可使用 --raw 查看返回内容")
        print(uuid)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def start_job(args: argparse.Namespace):
    """启动任务命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    
    print_header("启动任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        printed_flink_ui = False

        try:
            current_overview = job_manager.get_job_overview(job_id)
        except Exception:
            current_overview = {}
        current_state = _format_job_state(str(current_overview.get("State") or ""))
        current_flink_ui = _try_get_flink_ui_url(current_overview)
        if current_flink_ui:
            print(f"FlinkUI: {current_flink_ui}")
            printed_flink_ui = True

        start_type = None
        savepoint_id = None
        if getattr(args, "from_mode", None):
            mode = args.from_mode
            if mode == "latest":
                start_type = "FROM_LATEST"
            elif mode == "new":
                start_type = "FROM_NEW"
            elif mode == "savepoint":
                start_type = "FROM_SAVEPOINT"
                savepoint_id = args.savepoint_id
                if not savepoint_id:
                    raise Exception("from=savepoint 时必须提供 --savepoint-id")
        if not start_type and args.start_type:
            start_type = args.start_type
        if not start_type:
            start_type = "FROM_NEW" if current_state == "CREATED" else "FROM_LATEST"
        if start_type == "FROM_SAVEPOINT" and not savepoint_id:
            savepoint_id = args.savepoint_id
            if not savepoint_id:
                raise Exception("FROM_SAVEPOINT 启动时必须提供 --savepoint-id")

        print(f"本次启动方式: {_start_mode_label(start_type, savepoint_id)}")

        if current_state == "RUNNING":
            print("✅ 任务已在 RUNNING，无需启动")
            return

        result = job_manager.start_job(job_id=job_id, start_type=start_type, savepoint_id=savepoint_id)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")

                flink_ui = _try_get_flink_ui_url(overview)
                if flink_ui and not printed_flink_ui:
                    print(f"FlinkUI: {flink_ui}")
                    printed_flink_ui = True

                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    job_name = overview.get("JobName") or ""
                    if job_name:
                        print(f"查询任务: volc_flink jobs list --search \"{job_name}\"")
                    print(f"查看事件/日志: volc_flink jobs ui --job-id {job_id}")
                    return

                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可继续在运维页面查看状态: {manage_url}")
                    return

                time.sleep(5)
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def stop_job(args: argparse.Namespace):
    """停止任务命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    
    print_header("停止任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        try:
            current_overview = job_manager.get_job_overview(job_id)
        except Exception:
            current_overview = {}
        current_state = _format_job_state(str(current_overview.get("State") or ""))

        if current_state == "STOPPED":
            print("✅ 任务已在 STOPPED，无需停止")
            return

        savepoint_id = None
        if args.savepoint:
            existing_savepoint_ids = set()
            try:
                for sp in job_manager.list_start_savepoints(job_id):
                    spid = sp.get("SavepointId")
                    if spid:
                        existing_savepoint_ids.add(str(spid))
            except Exception:
                existing_savepoint_ids = set()

            result = job_manager.stop_job_with_savepoint(job_id=job_id)
            print(f"✅ {result}")
            print("制作快照中（Savepoint）...")
        else:
            result = job_manager.stop_job(job_id=job_id, force=args.force)
            print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            printed_savepoint = False
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")

                if args.savepoint and not printed_savepoint:
                    try:
                        savepoints = job_manager.list_start_savepoints(job_id)
                    except Exception:
                        savepoints = []
                    new_ids = []
                    for sp in savepoints:
                        spid = sp.get("SavepointId")
                        status = str(sp.get("Status") or "")
                        if not spid:
                            continue
                        spid = str(spid)
                        if spid in existing_savepoint_ids:
                            continue
                        if status.upper() == "AVAILABLE":
                            new_ids.append(spid)
                    if new_ids:
                        savepoint_id = new_ids[0]
                        print(f"SavepointId: {savepoint_id}")
                        print(f"Savepoint 恢复启动: volc_flink jobs start --job-id {job_id} --from savepoint --savepoint-id {savepoint_id}")
                        printed_savepoint = True

                if state == "STOPPED":
                    print("✅ 任务已进入 STOPPED")
                    if args.savepoint and not printed_savepoint:
                        print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                if state in ("FAILED", "SUCCEEDED"):
                    print(f"✅ 任务已进入终态: {state}")
                    if args.savepoint and not printed_savepoint:
                        print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可继续在运维页面查看状态: {manage_url}")
                    if args.savepoint and not printed_savepoint:
                        print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                time.sleep(5)
        elif args.savepoint:
            try:
                savepoints = job_manager.list_start_savepoints(job_id)
            except Exception:
                savepoints = []
            for sp in savepoints:
                spid = sp.get("SavepointId")
                status = str(sp.get("Status") or "")
                if not spid:
                    continue
                spid = str(spid)
                if spid in existing_savepoint_ids:
                    continue
                if status.upper() == "AVAILABLE":
                    savepoint_id = spid
                    print(f"SavepointId: {savepoint_id}")
                    print(f"Savepoint 恢复启动: volc_flink jobs start --job-id {job_id} --from savepoint --savepoint-id {savepoint_id}")
                    break
            if not savepoint_id:
                print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
        
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def restart_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("重启任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        start_type = None
        savepoint_id = None
        if getattr(args, "from_mode", None):
            mode = args.from_mode
            if mode == "latest":
                start_type = "FROM_LATEST"
            elif mode == "new":
                start_type = "FROM_NEW"
            elif mode == "savepoint":
                start_type = "FROM_SAVEPOINT"
                savepoint_id = args.savepoint_id
                if not savepoint_id:
                    raise Exception("from=savepoint 时必须提供 --savepoint-id")
        if not start_type and getattr(args, "start_type", None):
            start_type = args.start_type
        if not start_type:
            start_type = "FROM_LATEST"
        if start_type == "FROM_SAVEPOINT" and not savepoint_id:
            savepoint_id = args.savepoint_id
            if not savepoint_id:
                raise Exception("FROM_SAVEPOINT 重启时必须提供 --savepoint-id")

        print(f"本次重启方式: {_start_mode_label(start_type, savepoint_id)}")

        printed_flink_ui = False
        try:
            overview = job_manager.get_job_overview(job_id)
        except Exception:
            overview = {}
        flink_ui = _try_get_flink_ui_url(overview)
        if flink_ui:
            print(f"FlinkUI: {flink_ui}")
            printed_flink_ui = True

        result = job_manager.restart_job(job_id=job_id, start_type=start_type, savepoint_id=savepoint_id)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")

                flink_ui = _try_get_flink_ui_url(overview)
                if flink_ui and not printed_flink_ui:
                    print(f"FlinkUI: {flink_ui}")
                    printed_flink_ui = True

                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    job_name = overview.get("JobName") or ""
                    if job_name:
                        print(f"查询任务: volc_flink jobs list --search \"{job_name}\"")
                    print(f"查看事件/日志: volc_flink jobs ui --job-id {job_id}")
                    return

                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可继续在运维页面查看状态: {manage_url}")
                    return

                time.sleep(5)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def rescale_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    draft_manager = DraftManager(api_client, project_id)

    print_header("Rescale 任务")
    try:
        job_id = args.job_id
        overview = job_manager.get_job_overview(job_id)
        draft_id = overview.get("AppDraftId") or overview.get("AppDraftID")
        if not draft_id:
            raise Exception("未获取到 AppDraftId，无法定位草稿")
        draft_id = str(draft_id)

        deploy_request = overview.get("DeployRequest") if isinstance(overview.get("DeployRequest"), dict) else {}
        resource_pool = (
            deploy_request.get("ResourcePool")
            or overview.get("ResourcePool")
            or ""
        )
        queue = (
            deploy_request.get("Queue")
            or overview.get("Queue")
            or ""
        )
        if not resource_pool or not queue:
            raise Exception("未获取到资源池信息（ResourcePool/Queue），无法发布草稿")

        priority = str(deploy_request.get("Priority") or "3")
        schedule_policy = str(deploy_request.get("SchedulePolicy") or "GANG")
        schedule_timeout_raw = deploy_request.get("ScheduleTimeout") or 60
        try:
            schedule_timeout = int(schedule_timeout_raw)
        except Exception:
            schedule_timeout = 60

        def _parse_ratio(value: str) -> int:
            v = str(value or "").strip()
            if v in ("1:2", "2"):
                return 2
            if v in ("1:4", "4"):
                return 4
            if v in ("1:8", "8"):
                return 8
            raise Exception("CPU 内存配比仅支持 1:2 / 1:4 / 1:8")

        def _parse_spec(spec: str) -> Optional[Dict[str, int]]:
            if not spec:
                return None
            raw_spec = str(spec)
            cleaned = raw_spec.strip()
            if cleaned.endswith("\\"):
                cleaned = cleaned[:-1].strip()
            if (cleaned.startswith('"') and cleaned.endswith('"')) or (cleaned.startswith("'") and cleaned.endswith("'")):
                cleaned = cleaned[1:-1].strip()
            cleaned = re.sub(r"[\s\u200b\u200c\u200d\ufeff]+", "", cleaned)
            cleaned = re.sub(r"[^0-9cCgGbB]", "", cleaned)
            m = re.match(r"^(\d+)[cC](\d+)[gG][bB]$", cleaned)
            if not m:
                raise Exception(f"规格格式错误（收到: {raw_spec!r}），示例：1C2GB / 2C8GB / 4C16GB")
            cpu = int(m.group(1))
            mem = int(m.group(2))
            return {"cpu": cpu, "mem_gb": mem}

        allowed_cpu = {1, 2, 4, 8, 16}

        tm_cpu = args.tm_cpu
        tm_ratio = _parse_ratio(args.tm_mem_ratio) if args.tm_mem_ratio else None
        tm_spec = _parse_spec(args.tm_spec) if args.tm_spec else None
        if tm_spec:
            tm_cpu = tm_spec["cpu"]
            tm_ratio = None
            tm_mem_gb = tm_spec["mem_gb"]
            if tm_cpu not in allowed_cpu:
                raise Exception("TM CPU 仅支持 1/2/4/8/16")
            if tm_mem_gb % tm_cpu != 0 or (tm_mem_gb // tm_cpu) not in (2, 4, 8):
                raise Exception("TM CPU 内存配比仅支持 1:2 / 1:4 / 1:8")
        else:
            tm_mem_gb = None
            if tm_cpu is not None and tm_cpu not in allowed_cpu:
                raise Exception("TM CPU 仅支持 1/2/4/8/16")
            if tm_cpu is not None and tm_ratio is None and args.tm_mem_ratio is None:
                raise Exception("设置 TM CPU 时必须同时设置 --tm-mem-ratio 或使用 --tm-spec")
            if tm_cpu is not None and tm_ratio is not None:
                tm_mem_gb = int(tm_cpu) * int(tm_ratio)

        jm_cpu = args.jm_cpu
        jm_ratio = _parse_ratio(args.jm_mem_ratio) if args.jm_mem_ratio else None
        jm_spec = _parse_spec(args.jm_spec) if args.jm_spec else None
        if jm_spec:
            jm_cpu = jm_spec["cpu"]
            jm_ratio = None
            jm_mem_gb = jm_spec["mem_gb"]
            if jm_cpu not in allowed_cpu:
                raise Exception("JM CPU 仅支持 1/2/4/8/16")
            if jm_mem_gb % jm_cpu != 0 or (jm_mem_gb // jm_cpu) not in (2, 4, 8):
                raise Exception("JM CPU 内存配比仅支持 1:2 / 1:4 / 1:8")
        else:
            jm_mem_gb = None
            if jm_cpu is not None and jm_cpu not in allowed_cpu:
                raise Exception("JM CPU 仅支持 1/2/4/8/16")
            if jm_cpu is not None and jm_ratio is None and args.jm_mem_ratio is None:
                raise Exception("设置 JM CPU 时必须同时设置 --jm-mem-ratio 或使用 --jm-spec")
            if jm_cpu is not None and jm_ratio is not None:
                jm_mem_gb = int(jm_cpu) * int(jm_ratio)

        updates: Dict[str, Optional[str]] = {}
        if args.parallelism is not None:
            updates["parallelism.default"] = str(int(args.parallelism))
        if args.tm_slots is not None:
            updates["taskmanager.numberOfTaskSlots"] = str(int(args.tm_slots))
        if tm_cpu is not None:
            updates["kubernetes.taskmanager.cpu"] = str(int(tm_cpu))
        if tm_mem_gb is not None:
            updates["taskmanager.memory.process.size"] = f"{int(tm_mem_gb) * 1024}mb"
        if jm_cpu is not None:
            updates["kubernetes.jobmanager.cpu"] = str(int(jm_cpu))
        if jm_mem_gb is not None:
            updates["jobmanager.memory.process.size"] = f"{int(jm_mem_gb) * 1024}mb"

        if not updates:
            print("未指定任何 rescale 参数，将沿用原有配置")

        print(f"JobId: {job_id}")
        print(f"DraftId: {draft_id}")
        print(f"ResourcePool: {resource_pool}")
        print(f"Queue: {queue}")
        if updates:
            print("DynamicOptions 更新项:")
            print(json.dumps(updates, ensure_ascii=False, indent=2, sort_keys=True))

        if args.dry_run:
            print("✅ Dry-run 完成（未更新草稿/未发布/未重启）")
            return

        draft_manager.update_application_draft(draft_id=draft_id, dynamic_options_updates=updates)
        print("✅ 草稿配置已更新")

        resp = draft_manager.publish_draft(
            draft_id=draft_id,
            resource_pool=str(resource_pool),
            queue=str(queue),
            priority=priority,
            schedule_policy=schedule_policy,
            schedule_timeout=schedule_timeout,
        )
        print("✅ 草稿发布请求已提交")
        published_job_id = None
        if isinstance(resp, dict):
            published_job_id = resp.get("AppId") or resp.get("JobId") or resp.get("Id")
        if published_job_id:
            print(f"发布返回 JobId: {published_job_id}")

        target_job_id = str(published_job_id) if published_job_id else str(job_id)
        if target_job_id != str(job_id):
            print(f"将重启发布后的任务: {target_job_id}")

        result = job_manager.restart_job(job_id=target_job_id, start_type="FROM_LATEST", savepoint_id=None)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    ov = job_manager.get_job_overview(target_job_id)
                except Exception:
                    ov = {}
                state = _format_job_state(str(ov.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")
                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    return
                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），请在运维页面查看状态: {_job_manage_url(credentials.region, project_id)}")
                    return
                time.sleep(5)

    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_logs(args: argparse.Namespace):
    """获取任务日志命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    
    print_header("任务日志")
    try:
        instance_id = str(getattr(args, "instance_id", "") or "").strip()
        if not instance_id:
            instance_id = _pick_instance_id(job_manager, str(args.job_id), None)
        component = str(getattr(args, "component", "") or "jobmanager").strip().lower() or "jobmanager"
        file_name = str(getattr(args, "file_name", "") or getattr(args, "file", "") or "").strip()
        level = getattr(args, "level", None)
        cursor = str(getattr(args, "cursor", "") or "").strip()
        page_size = int(getattr(args, "page_size", 500) or 500)
        page = int(getattr(args, "page", 1) or 1)
        if page <= 0:
            page = 1
        if page_size <= 0:
            page_size = 500

        now_ms = int(time.time() * 1000)
        start_ms = getattr(args, "start_time_ms", None)
        end_ms = getattr(args, "end_time_ms", None)
        if start_ms is None and getattr(args, "since", None):
            try:
                start_ms = int(_parse_dt(args.since).timestamp() * 1000)
            except Exception:
                start_ms = None
        if end_ms is None and getattr(args, "until", None):
            try:
                end_ms = int(_parse_dt(args.until).timestamp() * 1000)
            except Exception:
                end_ms = None
        if end_ms is None:
            end_ms = now_ms
        if start_ms is None:
            start_ms = int(end_ms) - 3600 * 1000
        start_ms = int(start_ms)
        end_ms = int(end_ms)
        if start_ms > end_ms:
            raise Exception("StartTime 不能大于 EndTime")

        def _filter_msgs(msgs: List[str]) -> List[str]:
            if not level:
                return msgs
            lv = str(level).upper()
            out = []
            for m in msgs:
                if lv in str(m).upper():
                    out.append(m)
            return out

        def fetch(cursor_in: str, end_override_ms: Optional[int], print_msgs: bool) -> str:
            end_use = int(end_override_ms) if end_override_ms is not None else end_ms
            resp = job_manager.list_gas_logs(
                instance_id=instance_id,
                component=component,
                level=level,
                start_time_ms=start_ms,
                end_time_ms=end_use,
                cursor=cursor_in,
                page_size=page_size,
                file_name=file_name,
            )
            msgs = resp.get("Messages") if isinstance(resp, dict) else None
            next_cursor = str(resp.get("Cursor") or "") if isinstance(resp, dict) else ""
            if isinstance(msgs, list):
                filtered = _filter_msgs([str(x) for x in msgs if x is not None])
                if print_msgs:
                    for m in filtered:
                        print(m)
            return next_cursor

        if page > 1 and not cursor:
            cur = ""
            for _ in range(page - 1):
                nxt = fetch(cur, None, False)
                if not nxt:
                    cur = ""
                    break
                cur = nxt
            cursor = cur

        if getattr(args, "follow", False):
            cur = cursor
            while True:
                now2 = int(time.time() * 1000)
                nxt = fetch(cur, now2 if getattr(args, "until", None) is None and getattr(args, "end_time_ms", None) is None else None, True)
                if nxt:
                    cur = nxt
                time.sleep(float(getattr(args, "interval", 2.0) or 2.0))
        else:
            cursor_out = fetch(cursor, None, True)
            if cursor_out:
                print(f"\nCursor: {cursor_out}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def monitor_flinkui_url(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 地址")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        print(base)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def monitor_flinkui_overview(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 作业概览")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        url = _flinkui_url(job_manager, base, "/jobs/overview", api_prefix=str(args.api_prefix or ""))
        data = _fetch_flinkui_json(url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
        selected_job = None
        selected_job_id = ""
        jobs = data.get("jobs") if isinstance(data, dict) else None
        if isinstance(jobs, list) and jobs:
            selected_job = jobs[0]
            if isinstance(selected_job, dict):
                selected_job_id = str(selected_job.get("jid") or selected_job.get("jobId") or "")
        out = {"overview": data, "selected_job": selected_job, "selected_job_id": selected_job_id, "flinkui": base}
        print(json.dumps(out, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def monitor_flinkui_exceptions(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 异常信息")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        actual_job_id = str(args.flink_job_id or "").strip()
        if not actual_job_id:
            ov_url = _flinkui_url(job_manager, base, "/jobs/overview", api_prefix=str(args.api_prefix or ""))
            overview = _fetch_flinkui_json(ov_url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
            jobs = overview.get("jobs") if isinstance(overview, dict) else None
            if isinstance(jobs, list) and jobs:
                first = jobs[0]
                if isinstance(first, dict):
                    actual_job_id = str(first.get("jid") or first.get("jobId") or "").strip()
        if not actual_job_id:
            raise Exception("未获取到 Flink JobId，请使用 --flink-job-id 指定")
        ex_url = _flinkui_url(job_manager, base, f"/jobs/{actual_job_id}/exceptions", api_prefix=str(args.api_prefix or ""))
        data = _fetch_flinkui_json(ex_url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
        out = {"job_id": actual_job_id, "exceptions": data, "flinkui": base}
        print(json.dumps(out, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_metrics(args: argparse.Namespace):
    """获取任务指标命令处理"""
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    
    if not credentials:
        print("❌ 请先登录")
        return
    
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    
    print_header("任务指标")
    try:
        metric_names = getattr(args, "metric_names", None) or getattr(args, "metric", None) or []
        metric_names = [str(x).strip() for x in metric_names if str(x).strip()]
        if not metric_names:
            raise Exception("必须指定至少一个指标名，例如 -m flink_jobmanager_job_uptime")

        resource_id = getattr(args, "gtsjobuuid", None) or getattr(args, "uuid", None)
        if resource_id:
            resource_id = str(resource_id).strip()
        job_id = getattr(args, "job_id", None)
        if not resource_id and job_id:
            overview = job_manager.get_job_overview(str(job_id))
            for k in ("GtsJobUuid", "GTSJobUuid", "GtsJobUUID", "GTSJobUUID", "ResourceID", "ResourceId"):
                v = overview.get(k) if isinstance(overview, dict) else None
                if v is not None and str(v).strip():
                    resource_id = str(v).strip()
                    break
            if not resource_id:
                raise Exception("未从 Job 概览中解析到 GtsJobUuid，请使用 jobs uuid --raw 检查字段")

        if not resource_id:
            raise Exception("必须指定 -u/--gtsjobuuid 或 -i/--job-id")

        now = int(time.time())
        start_time = getattr(args, "start_time", None)
        end_time = getattr(args, "end_time", None)
        if end_time is None:
            end_time = now
        if start_time is None:
            start_time = int(end_time) - 3600
        start_time = int(start_time)
        end_time = int(end_time)
        if start_time > end_time:
            raise Exception("StartTime 不能大于 EndTime")

        group_by = getattr(args, "group_by", None) or []
        group_by = [str(x).strip() for x in group_by if str(x).strip()]

        sub_namespace = getattr(args, "sub_namespace", None) or "overview"
        region = getattr(args, "region", None) or credentials.region

        body = {
            "MetricNames": metric_names,
            "StartTime": start_time,
            "EndTime": end_time,
            "Namespace": "VCM_Flink",
            "Instances": [
                {
                    "Dimensions": [
                        {"Name": "ResourceID", "Value": resource_id},
                    ]
                }
            ],
            "GroupBy": group_by,
            "SubNamespace": str(sub_namespace),
            "Region": str(region),
        }
        resp = api_client.openapi_invoke(
            action="GetMetricsData",
            version="2018-01-01",
            service="Volc_Observe",
            method="POST",
            query_params=[],
            body=body,
        )
        if getattr(args, "graph", False):
            _render_metrics_graph(resp, width=int(getattr(args, "graph_width", 80) or 80))
        else:
            print(json.dumps(resp, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_job_metrics_catalog(args: argparse.Namespace):
    print_header("可查询指标")
    try:
        raw = None
        try:
            raw = importlib_resources.files("volcano_flink_client").joinpath("vcm_flink_metrics_catalog.json").read_text(encoding="utf-8")
        except Exception:
            raw = None
        if raw is None:
            catalog_path = Path(__file__).resolve().parent / "volcano_flink_client" / "vcm_flink_metrics_catalog.json"
            if not catalog_path.exists():
                raise Exception(f"未找到指标清单文件: {catalog_path}")
            raw = catalog_path.read_text(encoding="utf-8")
        catalog = json.loads(raw)
        items = catalog.get("items") if isinstance(catalog, dict) else None
        if not isinstance(items, list):
            items = []

        sub_ns = getattr(args, "sub_namespace", None)
        if sub_ns is not None:
            sub_ns = str(sub_ns).strip()
            if sub_ns == "":
                sub_ns = None

        rows = []
        for it in items:
            if not isinstance(it, dict):
                continue
            sub = str(it.get("sub_namespace") or "")
            if sub_ns and sub != sub_ns:
                continue
            name = str(it.get("metric_name") or "")
            dims = it.get("dimensions") or []
            if isinstance(dims, list):
                dims_str = ", ".join([str(d) for d in dims if d is not None and str(d) != ""])
            else:
                dims_str = str(dims)
            unit = str(it.get("unit") or "")
            rows.append([sub, name, unit, dims_str])

        rows.sort(key=lambda r: (r[0], r[1]))
        print_table(rows, ["SubNamespace", "MetricName", "Unit", "Dimensions"])
        print(f"\n📊 总计: {len(rows)} 个指标")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def job_ui(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务页面")
    manage_url = _job_manage_url(credentials.region, project_id)
    print(f"运维页面: {manage_url}")

    if args.job_id:
        try:
            overview = job_manager.get_job_overview(args.job_id)
            flink_ui = _try_get_flink_ui_url(overview)
            if flink_ui:
                print(f"FlinkUI: {flink_ui}")
        except Exception as e:
            print(f"❌ 错误: {str(e)}")

def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    raw = str(s).strip()
    if not raw:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt)
        except Exception:
            pass
    raise Exception("时间格式错误，示例：2025-01-01 12:00:00 或 2025-01-01T12:00:00")

def _filter_log_lines(lines: List[str], level: Optional[str], since: Optional[datetime], until: Optional[datetime]) -> List[str]:
    out: List[str] = []
    level_up = str(level).upper() if level else None
    ts_re = re.compile(r"^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})")
    for line in lines:
        if level_up and level_up not in line.upper():
            continue
        if since or until:
            m = ts_re.match(line)
            if m:
                try:
                    dt = _parse_dt(m.group(1).replace("T", " "))
                except Exception:
                    dt = None
                if dt:
                    if since and dt < since:
                        continue
                    if until and dt > until:
                        continue
        out.append(line)
    return out

def _fetch_flink_text(url: str) -> str:
    r = requests.get(url, timeout=20)
    if r.status_code >= 400:
        raise Exception(f"HTTP {r.status_code}")
    return r.text or ""

def _fetch_flink_json(url: str) -> Dict[str, Any]:
    r = requests.get(url, timeout=20)
    if r.status_code >= 400:
        raise Exception(f"HTTP {r.status_code}")
    try:
        return r.json()
    except Exception:
        raise Exception("响应不是 JSON")

def _fetch_flinkui_json(url: str, timeout_s: float = 15.0, verify_ssl: bool = True) -> Any:
    headers = {"open-platform-internal-flag": "true"}
    r = requests.get(url, timeout=float(timeout_s), verify=bool(verify_ssl), headers=headers)
    if r.status_code >= 400:
        raise Exception(f"HTTP {r.status_code}: {r.text}")
    try:
        return r.json()
    except Exception:
        try:
            return json.loads(r.text or "")
        except Exception:
            return {"raw": r.text or ""}

def _resolve_flinkui_base_url(job_manager: JobManager, job_id: str) -> str:
    iid = _pick_instance_id(job_manager, job_id, None)
    inst = job_manager.get_job_instance(iid)
    base = job_manager.get_instance_flink_proxy_base_url(inst)
    if not base:
        raise Exception("未获取到实例的 RestUrl/CompleteRestUrl，无法访问 FlinkUI")
    return str(base)

def _flinkui_url(job_manager: JobManager, base_url: str, path: str, api_prefix: str = "") -> str:
    prefix = str(api_prefix or "").strip().strip("/")
    p = str(path or "").strip()
    if not p.startswith("/"):
        p = "/" + p
    full_path = f"/{prefix}{p}" if prefix else p
    return job_manager.build_flink_proxy_url(base_url, full_path)

def _pick_instance_id(job_manager: JobManager, job_id: str, instance_id: Optional[str]) -> str:
    if instance_id:
        return str(instance_id)
    resp = job_manager.list_job_instances(job_id=job_id, state="RUNNING", page=1, page_size=1)
    records = resp.get("Records") or []
    if isinstance(records, list) and records:
        it = records[0]
        if isinstance(it, dict):
            iid = it.get("InstanceId") or it.get("Id")
            if iid:
                return str(iid)
    resp2 = job_manager.list_job_instances(job_id=job_id, page=1, page_size=1)
    records2 = resp2.get("Records") or []
    if isinstance(records2, list) and records2:
        it = records2[0]
        if isinstance(it, dict):
            iid = it.get("InstanceId") or it.get("Id")
            if iid:
                return str(iid)
    raise Exception("未找到实例，请检查 JobId 或稍后重试")

def monitor_events(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("任务事件")
    try:
        events = job_manager.get_job_events(job_id=args.job_id, limit=args.limit)
        events = events[: int(args.limit)]
        if getattr(args, "raw", False):
            print(json.dumps(events, ensure_ascii=False, indent=2))
            return

        data = []
        for item in events:
            if not isinstance(item, dict):
                continue
            def pick(keys: List[str]) -> str:
                for k in keys:
                    v = item.get(k)
                    if v is not None and str(v) != "":
                        return str(v)
                return ""

            data.append(
                [
                    pick(["Time", "EventTime", "Timestamp", "CreateTime", "LastTimestamp", "FirstTimestamp"]),
                    pick(["Level", "Type", "Severity", "EventType"]),
                    pick(["Collector", "Source", "Component", "Reason", "Name", "Title"]),
                    pick(["Message", "Msg", "Content", "Detail"]),
                ]
            )
        print_table(data, ["Time", "Level", "Collector", "Message"])
        print(f"\n📊 总计: {len(events)} 条事件记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def monitor_logs(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("任务日志")
    try:
        instance_id = str(getattr(args, "instance_id", "") or "").strip()
        if not instance_id:
            instance_id = _pick_instance_id(job_manager, str(args.job_id), None)
        component = str(args.component or "jobmanager").strip().lower() or "jobmanager"
        file_name = str(getattr(args, "file_name", "") or getattr(args, "file", "") or "").strip()

        now_ms = int(time.time() * 1000)
        start_ms = getattr(args, "start_time_ms", None)
        end_ms = getattr(args, "end_time_ms", None)

        if start_ms is None and getattr(args, "since", None):
            try:
                start_ms = int(_parse_dt(args.since).timestamp() * 1000)
            except Exception:
                start_ms = None
        if end_ms is None and getattr(args, "until", None):
            try:
                end_ms = int(_parse_dt(args.until).timestamp() * 1000)
            except Exception:
                end_ms = None

        if end_ms is None:
            end_ms = now_ms
        if start_ms is None:
            start_ms = int(end_ms) - 3600 * 1000

        start_ms = int(start_ms)
        end_ms = int(end_ms)
        if start_ms > end_ms:
            raise Exception("StartTime 不能大于 EndTime")

        cursor = str(getattr(args, "cursor", "") or "").strip()
        page_size = int(getattr(args, "page_size", 500) or 500)
        if page_size <= 0:
            page_size = 500

        def fetch_once(cursor_in: str, end_override_ms: Optional[int]) -> str:
            end_use = int(end_override_ms) if end_override_ms is not None else end_ms
            resp = job_manager.list_gas_logs(
                instance_id=instance_id,
                component=component,
                level=getattr(args, "level", None),
                start_time_ms=start_ms,
                end_time_ms=end_use,
                cursor=cursor_in,
                page_size=page_size,
                file_name=file_name,
            )
            msgs = resp.get("Messages") if isinstance(resp, dict) else None
            next_cursor = str(resp.get("Cursor") or "") if isinstance(resp, dict) else ""
            if isinstance(msgs, list):
                for m in msgs:
                    if m is None:
                        continue
                    print(str(m))
            return next_cursor

        if args.follow:
            cur = cursor
            while True:
                now2 = int(time.time() * 1000)
                cur2 = fetch_once(cur, now2 if getattr(args, "until", None) is None and getattr(args, "end_time_ms", None) is None else None)
                if cur2:
                    cur = cur2
                time.sleep(float(args.interval))
        else:
            cursor_out = fetch_once(cursor, None)
            if cursor_out:
                print(f"\nCursor: {cursor_out}")

    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_job_savepoints(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("快照列表")
    try:
        items = job_manager.list_savepoints(args.job_id, status=args.status)
        data = []
        for sp in items:
            data.append(
                [
                    sp.get("SavepointId") or "",
                    sp.get("Status") or "",
                    sp.get("CreateTime") or "",
                    sp.get("CreateType") or "",
                    sp.get("SavepointPath") or "",
                ]
            )
        print_table(data, ["SavepointId", "状态", "创建时间", "类型", "路径"])
        print(f"\n📊 总计: {len(items)} 个快照")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def make_job_savepoint(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("制作快照")
    try:
        existing_ids = set()
        try:
            for sp in job_manager.list_savepoints(args.job_id):
                spid = sp.get("SavepointId")
                if spid:
                    existing_ids.add(str(spid))
        except Exception:
            existing_ids = set()

        resp = job_manager.make_savepoint(args.job_id, args.description)
        print("✅ 快照制作请求已提交!")
        instance_id = resp.get("InstanceId") if isinstance(resp, dict) else None
        if instance_id:
            print(f"InstanceId: {instance_id}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）查询 Savepoint（剩余 {remaining}s）")
                try:
                    items = job_manager.list_savepoints(args.job_id)
                except Exception:
                    items = []
                new_ids = []
                for sp in items:
                    spid = sp.get("SavepointId")
                    status = str(sp.get("Status") or "")
                    if not spid:
                        continue
                    spid = str(spid)
                    if spid in existing_ids:
                        continue
                    if status.upper() == "AVAILABLE":
                        new_ids.append(spid)
                if new_ids:
                    savepoint_id = new_ids[0]
                    print(f"SavepointId: {savepoint_id}")
                    print(f"Savepoint 恢复启动: volc_flink jobs start --job-id {args.job_id} --from savepoint --savepoint-id {savepoint_id}")
                    return
                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可稍后查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {args.job_id}")
                    return
                time.sleep(5)
        else:
            print(f"查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {args.job_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")

def list_job_start_available_savepoints(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("可恢复快照")
    try:
        info = job_manager.get_start_savepoint_info(args.job_id)
        methods = info.get("EnableStartMethods") or []
        if methods:
            print("可用启动方式: " + ", ".join([str(m) for m in methods]))
        items = info.get("AvailableSavepoints") or []
        if not isinstance(items, list):
            items = []
        data = []
        for sp in items:
            if not isinstance(sp, dict):
                continue
            data.append(
                [
                    sp.get("SavepointId") or "",
                    sp.get("Status") or "",
                    sp.get("CreateTime") or "",
                    sp.get("CreateType") or "",
                    sp.get("SavepointPath") or "",
                ]
            )
        print_table(data, ["SavepointId", "状态", "创建时间", "类型", "路径"])
        print(f"\n📊 总计: {len(data)} 个可恢复快照")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="火山引擎流式计算 Flink 版 Client 工具"
    )
    
    subparsers = parser.add_subparsers(title="子命令", help="可用子命令")
    
    # 登录命令
    login_parser = subparsers.add_parser("login", help="登录火山引擎账号")
    login_parser.add_argument("--ak", help="访问密钥 Access Key（不传则交互式输入）")
    login_parser.add_argument("--sk", help="安全密钥 Secret Key（不传则交互式输入）")
    login_parser.add_argument("--region", default="cn-beijing", help="区域 (默认: cn-beijing)")
    login_parser.set_defaults(func=login)
    
    # 退出登录命令
    logout_parser = subparsers.add_parser("logout", help="退出登录")
    logout_parser.set_defaults(func=lambda x: logout())

    config_parser = subparsers.add_parser("config", help="配置管理")
    config_parser.set_defaults(func=lambda _args, p=config_parser: p.print_help())
    config_subparsers = config_parser.add_subparsers(title="配置子命令")

    config_show_parser = config_subparsers.add_parser("show", help="查看当前配置")
    config_show_parser.set_defaults(func=lambda x: show_config())

    config_set_tos_parser = config_subparsers.add_parser("set-tos-jar-prefix", help="设置 TOS Jar 存储路径")
    config_set_tos_parser.add_argument("--tos-jar-prefix", required=True, help="例如 tos://<bucket>/path/to/jars")
    config_set_tos_parser.set_defaults(func=set_tos_jar_prefix)

    config_set_project_parser = config_subparsers.add_parser("set-default-project", help="设置默认项目")
    config_set_project_parser.add_argument("--project-id", help="项目ID")
    config_set_project_parser.add_argument("-n", "--name", help="项目名称")
    config_set_project_parser.add_argument("--project-name", help="项目名称（兼容参数）")
    config_set_project_parser.set_defaults(func=set_default_project)
    
    # 项目命令
    project_parser = subparsers.add_parser("projects", help="项目操作")
    project_parser.set_defaults(func=lambda _args, p=project_parser: p.print_help())
    project_subparsers = project_parser.add_subparsers(title="项目子命令")
    
    # 列举项目
    list_projects_parser = project_subparsers.add_parser("list", help="列举项目")
    list_projects_parser.add_argument("--search-key", default="", help="按项目名称模糊搜索")
    list_projects_parser.add_argument("--page-size", type=int, default=50, help="每页大小 (默认: 50)")
    list_projects_parser.add_argument("--page-num", type=int, default=1, help="页码 (默认: 1)")
    list_projects_parser.set_defaults(func=list_projects)

    # 项目详情
    project_detail_parser = project_subparsers.add_parser("detail", help="查看项目详情")
    project_detail_parser.add_argument("-n", "--name", required=True, help="项目名称")
    project_detail_parser.set_defaults(func=get_project_details)
    
    # 资源池命令
    resource_pool_parser = subparsers.add_parser("resource-pools", help="资源池操作")
    resource_pool_parser.set_defaults(func=lambda _args, p=resource_pool_parser: p.print_help())
    resource_pool_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    resource_pool_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    resource_pool_subparsers = resource_pool_parser.add_subparsers(title="资源池子命令")
    
    # 列举资源池
    list_resource_pools_parser = resource_pool_subparsers.add_parser("list", help="列举资源池")
    list_resource_pools_parser.set_defaults(func=list_resource_pools)

    detail_resource_pools_parser = resource_pool_subparsers.add_parser("detail", help="查看资源池详情")
    detail_id_group = detail_resource_pools_parser.add_mutually_exclusive_group(required=True)
    detail_id_group.add_argument("-i", "--resource-pool-id", dest="resource_pool_id", help="资源池ID")
    detail_id_group.add_argument("-n", "--name", help="资源池名称")
    detail_resource_pools_parser.set_defaults(func=get_resource_pool_details)
    
    # 创建资源池
    create_resource_pool_parser = resource_pool_subparsers.add_parser("create", help="创建资源池")
    create_resource_pool_parser.add_argument("-n", "--name", required=True, help="资源池名称")
    create_resource_pool_parser.add_argument("-d", "--description", help="资源池描述")
    create_resource_pool_parser.add_argument("-c", "--vcores", type=int, default=4, help="CPU核数 (默认: 4)")
    create_resource_pool_parser.add_argument("-m", "--memory-gb", type=int, default=16, help="内存GB (默认: 16)")
    create_resource_pool_parser.set_defaults(func=create_resource_pool)
    
    # 草稿命令
    draft_parser = subparsers.add_parser("drafts", help="草稿操作")
    draft_parser.set_defaults(func=lambda _args, p=draft_parser: p.print_help())
    draft_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    draft_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    draft_subparsers = draft_parser.add_subparsers(title="草稿子命令")
    
    list_drafts_parser = draft_subparsers.add_parser("list", help="列举草稿（兼容命令）")
    list_drafts_parser.add_argument("--directory", help="按目录名称或路径过滤，例如 /a/b/c 或 tls-test")
    list_drafts_parser.set_defaults(func=list_drafts)

    dirs_parser = draft_subparsers.add_parser("dirs", help="列举草稿目录")
    dirs_parser.set_defaults(func=list_draft_directories)

    mkdir_parser = draft_subparsers.add_parser("mkdir", help="创建草稿目录")
    mkdir_parser.add_argument("--name", required=True, help="目录路径，例如 /a/b/c")
    mkdir_parser.set_defaults(func=create_draft_directory)

    rmr_parser = draft_subparsers.add_parser("rmr", help="删除草稿目录")
    rmr_id_group = rmr_parser.add_mutually_exclusive_group(required=True)
    rmr_id_group.add_argument("--id", required=False, help="目录ID")
    rmr_id_group.add_argument("--name", required=False, help="目录路径，例如 /a/b/c")
    rmr_parser.set_defaults(func=delete_draft_directory)

    apps_parser = draft_subparsers.add_parser("apps", help="列举草稿")
    apps_parser.add_argument("--directory", help="按目录名称或路径过滤，例如 /a/b/c 或 tls-test")
    apps_parser.set_defaults(func=list_draft_apps)

    content_parser = draft_subparsers.add_parser("content", help="获取草稿内容")
    content_id_group = content_parser.add_mutually_exclusive_group(required=True)
    content_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    content_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    content_parser.set_defaults(func=get_draft_content)

    rm_parser = draft_subparsers.add_parser("rm", help="删除草稿")
    rm_id_group = rm_parser.add_mutually_exclusive_group(required=True)
    rm_id_group.add_argument("--id", required=False, help="草稿ID")
    rm_id_group.add_argument("--name", required=False, help="草稿名称或路径，例如 my_draft 或 /a/b/c/my_draft.sql")
    rm_parser.set_defaults(func=delete_draft_cmd)

    validate_parser = draft_subparsers.add_parser("validate", help="SQL 草稿语法校验")
    validate_id_group = validate_parser.add_mutually_exclusive_group(required=True)
    validate_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    validate_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    validate_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    validate_parser.set_defaults(func=validate_draft_cmd)
    
    # 创建草稿
    create_draft_parser = draft_subparsers.add_parser("create", help="创建草稿")
    create_draft_parser.add_argument("-n", "--name", required=True, help="草稿名称")
    create_draft_parser.add_argument("--directory-id", help="草稿目录ID（可通过 drafts dirs 获取）")
    create_draft_parser.add_argument("--directory", help="草稿目录名称或路径，例如 /a/b/c 或 tls-test")
    create_draft_parser.add_argument(
        "--job-type",
        choices=["FLINK_STREAMING_SQL", "FLINK_STREAMING_JAR", "FLINK_BATCH_SQL", "FLINK_BATCH_JAR"],
        help="作业类型",
    )
    create_draft_parser.add_argument(
        "--engine-version",
        default="FLINK_VERSION_1_17",
        choices=["FLINK_VERSION_1_16", "FLINK_VERSION_1_17", "FLINK_VERSION_1_20", "FLINK_1_16", "FLINK_1_17", "FLINK_1_20"],
        help="Flink 引擎版本",
    )
    create_draft_parser.add_argument("-t", "--type", choices=["sql", "jar"], help="兼容参数：sql 或 jar")
    create_draft_parser.add_argument("--mode", choices=["streaming", "batch"], help="兼容参数：streaming 或 batch")
    create_draft_parser.add_argument("-s", "--sql", help="SQL 文本")
    create_draft_parser.add_argument("--sql-file", help="SQL 文件路径")
    create_draft_parser.add_argument("--sql-dir", help="SQL 文件目录（递归读取 *.sql）")
    create_draft_parser.add_argument("--jar", help="JAR 路径：本地路径或 tos://...（等价于 --jar-path/--jar-tos）")
    create_draft_parser.add_argument("--jar-path", help="本地 JAR 文件路径")
    create_draft_parser.add_argument("--jar-tos", help="TOS JAR 路径，例如 tos://<bucket>/path/to/jar.jar")
    create_draft_parser.add_argument("--main-class", help="JAR 作业主类（MainClass）")
    create_draft_parser.add_argument("--args", help="JAR 作业启动参数字符串（Args）")
    create_draft_parser.add_argument("--main-arg", action="append", help="JAR 作业 MainArgs，格式 key=value，可重复传入")
    create_draft_parser.set_defaults(func=create_draft)
    
    # 发布草稿
    publish_draft_parser = draft_subparsers.add_parser("publish", help="发布草稿")
    publish_id_group = publish_draft_parser.add_mutually_exclusive_group(required=True)
    publish_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    publish_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    publish_draft_parser.add_argument("--resource-pool-id", help="资源池ID（兼容参数）")
    publish_draft_parser.add_argument("--resource-pool", help="资源池名称")
    publish_draft_parser.add_argument("--queue", help="资源池 Queue（兼容参数）")
    publish_draft_parser.add_argument("--priority", default="3", help="优先级 1-5，默认 3")
    publish_draft_parser.add_argument("--schedule-policy", default="GANG", choices=["GANG", "DRF"], help="调度策略")
    publish_draft_parser.add_argument("--schedule-timeout", type=int, default=60, help="调度超时秒数（GANG 时使用）")
    publish_draft_parser.set_defaults(func=publish_draft)

    update_draft_parser = draft_subparsers.add_parser("update", help="更新草稿内容")
    update_id_group = update_draft_parser.add_mutually_exclusive_group(required=True)
    update_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    update_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    update_draft_parser.add_argument("-s", "--sql", help="SQL 文本")
    update_draft_parser.add_argument("--sql-file", help="SQL 文件路径")
    update_draft_parser.add_argument("--sql-dir", help="SQL 文件目录（递归读取 *.sql）")
    update_draft_parser.add_argument("--jar", help="JAR 路径：本地路径或 tos://...（等价于 --jar-path/--jar-tos）")
    update_draft_parser.add_argument("--jar-path", help="本地 JAR 文件路径")
    update_draft_parser.add_argument("--jar-tos", help="TOS JAR 路径，例如 tos://<bucket>/path/to/jar.jar")
    update_draft_parser.add_argument("--main-class", help="JAR 作业主类（MainClass）")
    update_draft_parser.add_argument("--args", help="JAR 作业启动参数字符串（Args）")
    update_draft_parser.add_argument("--main-arg", action="append", help="JAR 作业 MainArgs，格式 key=value，可重复传入")
    update_draft_parser.set_defaults(func=update_draft)

    dependency_parser = draft_subparsers.add_parser("dependency", help="管理草稿依赖（Dependency.jars）")
    dependency_subparsers = dependency_parser.add_subparsers(title="dependency 子命令")

    dep_add_parser = dependency_subparsers.add_parser("add", help="添加依赖 JAR")
    dep_add_id_group = dep_add_parser.add_mutually_exclusive_group(required=True)
    dep_add_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    dep_add_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    dep_add_parser.add_argument("--jar", action="append", required=True, help="本地路径或 tos://...，可重复传入")
    dep_add_parser.set_defaults(func=drafts_dependency_add)

    dep_remove_parser = dependency_subparsers.add_parser("remove", help="删除依赖 JAR")
    dep_remove_id_group = dep_remove_parser.add_mutually_exclusive_group(required=True)
    dep_remove_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    dep_remove_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    dep_remove_parser.add_argument("--jar", action="append", required=True, help="依赖的 tos 全路径，可重复传入")
    dep_remove_parser.set_defaults(func=drafts_dependency_remove)

    params_parser = draft_subparsers.add_parser("params", help="管理草稿动态参数（DynamicOptions）")
    params_subparsers = params_parser.add_subparsers(title="params 子命令")

    params_set_parser = params_subparsers.add_parser("set", help="设置动态参数（覆盖或插入）")
    params_set_id_group = params_set_parser.add_mutually_exclusive_group(required=True)
    params_set_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_set_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_set_parser.add_argument("--kv", required=True, help="key=value")
    params_set_parser.set_defaults(func=drafts_params_set)

    params_unset_parser = params_subparsers.add_parser("unset", help="删除动态参数（按 key）")
    params_unset_id_group = params_unset_parser.add_mutually_exclusive_group(required=True)
    params_unset_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_unset_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_unset_parser.add_argument("--key", required=True, help="要删除的参数 key")
    params_unset_parser.set_defaults(func=drafts_params_unset)

    params_show_parser = params_subparsers.add_parser("show", help="查看动态参数（DynamicOptions）")
    params_show_id_group = params_show_parser.add_mutually_exclusive_group(required=True)
    params_show_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_show_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_show_parser.set_defaults(func=drafts_params_show)

    catalog_parser = subparsers.add_parser("catalog", help="Catalog 元数据")
    catalog_parser.set_defaults(func=lambda _args, p=catalog_parser: p.print_help())
    catalog_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    catalog_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    catalog_subparsers = catalog_parser.add_subparsers(title="catalog 子命令")

    catalog_tree_parser = catalog_subparsers.add_parser("tree", help="递归列出 Catalog/Database/Table 树")
    catalog_id_group = catalog_tree_parser.add_mutually_exclusive_group()
    catalog_id_group.add_argument("--catalog-id", help="只看某个 CatalogId")
    catalog_id_group.add_argument("--catalog-name", help="只看某个 CatalogName")
    catalog_tree_parser.add_argument("--database", help="只看某个 DatabaseName")
    catalog_tree_parser.add_argument("--table", help="只看某个 TableName")
    catalog_tree_parser.add_argument("--details", action="store_true", help="拉取 Database detail（GetCatalogDatabase）")
    catalog_tree_parser.add_argument("--table-details", action="store_true", help="拉取 Table detail（GetCatalogTable）")
    catalog_tree_parser.add_argument("--raw", action="store_true", help="输出完整 JSON")
    catalog_tree_parser.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_tree_parser.set_defaults(func=catalog_tree)

    catalog_catalogs_parser = catalog_subparsers.add_parser("catalogs", help="Catalog 查询")
    catalog_catalogs_parser.set_defaults(func=lambda _args, p=catalog_catalogs_parser: p.print_help())
    catalog_catalogs_subparsers = catalog_catalogs_parser.add_subparsers(title="catalogs 子命令")
    catalog_catalogs_list = catalog_catalogs_subparsers.add_parser("list", help="列出 Catalog")
    catalog_catalogs_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_catalogs_list.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_catalogs_list.set_defaults(func=catalog_list_catalogs)
    catalog_catalogs_show = catalog_catalogs_subparsers.add_parser("show", help="查看某个 Catalog 详情")
    catalog_catalogs_show_id_group = catalog_catalogs_show.add_mutually_exclusive_group(required=True)
    catalog_catalogs_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_catalogs_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_catalogs_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_catalogs_show.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_catalogs_show.set_defaults(func=catalog_show_catalog)

    catalog_dbs_parser = catalog_subparsers.add_parser("databases", help="Database 查询")
    catalog_dbs_parser.set_defaults(func=lambda _args, p=catalog_dbs_parser: p.print_help())
    catalog_dbs_subparsers = catalog_dbs_parser.add_subparsers(title="databases 子命令")
    catalog_dbs_list = catalog_dbs_subparsers.add_parser("list", help="列出 Catalog 下的 Database")
    catalog_dbs_list_id_group = catalog_dbs_list.add_mutually_exclusive_group(required=True)
    catalog_dbs_list_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_dbs_list_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_dbs_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_dbs_list.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_dbs_list.set_defaults(func=catalog_list_databases)
    catalog_dbs_show = catalog_dbs_subparsers.add_parser("show", help="查看某个 Database 详情")
    catalog_dbs_show_id_group = catalog_dbs_show.add_mutually_exclusive_group(required=True)
    catalog_dbs_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_dbs_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_dbs_show.add_argument("--database", required=True, help="DatabaseName")
    catalog_dbs_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_dbs_show.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_dbs_show.set_defaults(func=catalog_show_database)

    catalog_tables_parser = catalog_subparsers.add_parser("tables", help="Table 查询")
    catalog_tables_parser.set_defaults(func=lambda _args, p=catalog_tables_parser: p.print_help())
    catalog_tables_subparsers = catalog_tables_parser.add_subparsers(title="tables 子命令")
    catalog_tables_list = catalog_tables_subparsers.add_parser("list", help="列出 Database 下的 Table")
    catalog_tables_list_id_group = catalog_tables_list.add_mutually_exclusive_group(required=True)
    catalog_tables_list_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_tables_list_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_tables_list.add_argument("--database", required=True, help="DatabaseName")
    catalog_tables_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_tables_list.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_tables_list.set_defaults(func=catalog_list_tables)
    catalog_tables_show = catalog_tables_subparsers.add_parser("show", help="查看某个 Table 详情")
    catalog_tables_show_id_group = catalog_tables_show.add_mutually_exclusive_group(required=True)
    catalog_tables_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_tables_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_tables_show.add_argument("--database", required=True, help="DatabaseName")
    catalog_tables_show.add_argument("--table", required=True, help="TableName")
    catalog_tables_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_tables_show.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    catalog_tables_show.set_defaults(func=catalog_show_table)

    sessions_parser = subparsers.add_parser("sessions", help="Session 集群")
    sessions_parser.set_defaults(func=lambda _args, p=sessions_parser: p.print_help())
    sessions_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    sessions_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    sessions_subparsers = sessions_parser.add_subparsers(title="sessions 子命令")

    sessions_list_parser = sessions_subparsers.add_parser("list", help="列举 Session 集群")
    sessions_list_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    sessions_list_parser.set_defaults(func=sessions_list)

    sessions_create_parser = sessions_subparsers.add_parser("create", help="创建 Session 集群")
    sessions_create_parser.add_argument("--name", required=True, help="集群名称")
    sessions_create_parser.add_argument("--resource-pool", required=True, help="资源池名称（ResourcePool）")
    sessions_create_parser.add_argument("--queue", required=True, help="队列（Queue）")
    sessions_create_parser.add_argument("--engine-version", required=True, help="引擎版本（EngineVersion）")
    sessions_create_parser.add_argument("--context", default="", help="Context（例如 DEBUG）")
    sessions_create_parser.add_argument("--tm-min", dest="tm_min", type=int, required=True, help="TmMinNumber")
    sessions_create_parser.add_argument("--tm-max", dest="tm_max", type=int, required=True, help="TmMaxNumber")
    sessions_create_parser.add_argument("--tm-vcore", dest="tm_vcore", type=int, required=True, help="TmVcore")
    sessions_create_parser.add_argument("--tm-memory", dest="tm_memory", type=int, required=True, help="TmMemory（GB）")
    sessions_create_parser.add_argument("--slots-per-tm", dest="slots_per_tm", type=int, required=True, help="SlotsPerTm")
    sessions_create_parser.add_argument("--jm-vcore", dest="jm_vcore", type=int, required=True, help="JmVcore")
    sessions_create_parser.add_argument("--jm-memory", dest="jm_memory", type=int, required=True, help="JmMemory（GB）")
    sessions_create_parser.add_argument("--dynamic-properties", default="", help="DynamicProperties JSON")
    sessions_create_parser.add_argument("--kv", action="append", help="DynamicProperties 追加，格式 key=value，可重复")
    sessions_create_parser.set_defaults(func=sessions_create)

    sessions_start_parser = sessions_subparsers.add_parser("start", help="启动 Session 集群")
    sessions_start_parser.add_argument("--id", required=True, help="Session 集群 ID")
    sessions_start_parser.set_defaults(func=sessions_start)

    sessions_stop_parser = sessions_subparsers.add_parser("stop", help="停止 Session 集群")
    sessions_stop_parser.add_argument("--id", required=True, help="Session 集群 ID")
    sessions_stop_parser.set_defaults(func=sessions_stop)

    sessions_ui_parser = sessions_subparsers.add_parser("ui", help="输出 Session 集群 FlinkUI 地址")
    sessions_ui_id_group = sessions_ui_parser.add_mutually_exclusive_group(required=True)
    sessions_ui_id_group.add_argument("--id", required=False, help="Session 集群 ID")
    sessions_ui_id_group.add_argument("--name", required=False, help="Session 集群名称")
    sessions_ui_parser.set_defaults(func=sessions_ui)

    files_parser = subparsers.add_parser("files", help="TOS 文件（基于 TOS Jar Prefix）")
    files_parser.set_defaults(func=lambda _args, p=files_parser: p.print_help())
    files_subparsers = files_parser.add_subparsers(title="files 子命令")

    files_list_parser = files_subparsers.add_parser("list", help="列出 TOS Jar Prefix 下的文件")
    files_list_parser.add_argument("--prefix", default="", help="子目录前缀（相对 tos_jar_prefix）")
    files_list_parser.add_argument("--limit", type=int, default=200, help="返回条数（默认 200）")
    files_list_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    files_list_parser.set_defaults(func=files_list)

    files_upload_parser = files_subparsers.add_parser("upload", help="上传文件到 TOS Jar Prefix")
    files_upload_parser.add_argument("--file", required=True, help="本地文件路径")
    files_upload_parser.add_argument("--name", default="", help="对象名（相对 tos_jar_prefix，默认使用文件名）")
    files_upload_parser.set_defaults(func=files_upload)

    files_detail_parser = files_subparsers.add_parser("detail", help="查看文件详情（HeadObject）")
    files_detail_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_detail_parser.set_defaults(func=files_detail)

    files_update_parser = files_subparsers.add_parser("update", help="更新文件（覆盖上传）")
    files_update_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_update_parser.add_argument("--file", required=True, help="本地文件路径")
    files_update_parser.set_defaults(func=files_update)

    files_url_parser = files_subparsers.add_parser("url", help="获取下载链接（预签名 URL）")
    files_url_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_url_parser.add_argument("--expires", type=int, default=3600, help="链接有效期秒（默认 3600）")
    files_url_parser.set_defaults(func=files_url)

    monitor_parser = subparsers.add_parser("monitor", help="监控与日志查询")
    monitor_parser.set_defaults(func=lambda _args, p=monitor_parser: p.print_help())
    monitor_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    monitor_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    monitor_subparsers = monitor_parser.add_subparsers(title="monitor 子命令")

    monitor_events_parser = monitor_subparsers.add_parser("events", help="查询任务运行事件")
    monitor_events_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    monitor_events_parser.add_argument("--limit", type=int, default=50, help="返回条数（默认 50）")
    monitor_events_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    monitor_events_parser.set_defaults(func=monitor_events)

    monitor_logs_parser = monitor_subparsers.add_parser("logs", help="查询任务日志（支持历史实例、tail、时间范围、级别过滤）")
    monitor_logs_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    monitor_logs_parser.add_argument("--instance-id", help="实例ID（不传默认选取最新实例）")
    monitor_logs_parser.add_argument("--component", default="jobmanager", choices=["jobmanager", "taskmanager"], help="日志组件")
    monitor_logs_parser.add_argument("--taskmanager-id", help="taskmanager id（component=taskmanager 时可选）")
    monitor_logs_parser.add_argument("--file", help="日志文件名（用于 logs 列表模式）")
    monitor_logs_parser.add_argument("--file-name", dest="file_name", help="日志文件名（兼容参数）")
    monitor_logs_parser.add_argument("--level", choices=["DEBUG", "INFO", "WARN", "ERROR"], help="日志级别过滤")
    monitor_logs_parser.add_argument("--since", help="开始时间，格式 2025-01-01 12:00:00")
    monitor_logs_parser.add_argument("--until", help="结束时间，格式 2025-01-01 13:00:00")
    monitor_logs_parser.add_argument("--start-time-ms", dest="start_time_ms", type=int, help="开始时间（Unix 毫秒）")
    monitor_logs_parser.add_argument("--end-time-ms", dest="end_time_ms", type=int, help="结束时间（Unix 毫秒）")
    monitor_logs_parser.add_argument("--cursor", default="", help="游标（用于从上次位置继续拉取）")
    monitor_logs_parser.add_argument("--page-size", dest="page_size", type=int, default=500, help="返回条数（默认 500）")
    monitor_logs_parser.add_argument("--lines", type=int, default=200, help="展示末尾行数（默认 200）")
    monitor_logs_parser.add_argument("--follow", action="store_true", help="实时 tail")
    monitor_logs_parser.add_argument("--interval", type=float, default=2.0, help="tail 间隔秒（默认 2）")
    monitor_logs_parser.set_defaults(func=monitor_logs)

    monitor_flinkui_parser = monitor_subparsers.add_parser("flinkui", help="FlinkUI 查询（URL/overview/exceptions）")
    monitor_flinkui_parser.set_defaults(func=lambda _args, p=monitor_flinkui_parser: p.print_help())
    flinkui_subparsers = monitor_flinkui_parser.add_subparsers(title="flinkui 子命令")
    flinkui_common = argparse.ArgumentParser(add_help=False)
    flinkui_common.add_argument("-i", "--job-id", required=True, help="任务ID（用于定位实例 FlinkUI）")
    flinkui_common.add_argument("--api-prefix", default="", help="API 前缀（例如 /api，默认空）")
    flinkui_common.add_argument("--timeout", type=float, default=15.0, help="请求超时秒（默认 15）")
    flinkui_common.add_argument("--insecure", action="store_true", help="跳过 SSL 校验")

    flinkui_url_parser = flinkui_subparsers.add_parser("url", parents=[flinkui_common], help="输出 FlinkUI 基础地址")
    flinkui_url_parser.set_defaults(func=monitor_flinkui_url)

    flinkui_overview_parser = flinkui_subparsers.add_parser("overview", parents=[flinkui_common], help="获取作业概览并选取第一个作业")
    flinkui_overview_parser.set_defaults(func=monitor_flinkui_overview)

    flinkui_ex_parser = flinkui_subparsers.add_parser("exceptions", parents=[flinkui_common], help="获取作业异常信息")
    flinkui_ex_parser.add_argument("--flink-job-id", default="", help="Flink 作业 ID（不传则从 overview 取第一个）")
    flinkui_ex_parser.set_defaults(func=monitor_flinkui_exceptions)
    
    # 任务命令
    job_parser = subparsers.add_parser("jobs", help="任务操作")
    job_parser.set_defaults(func=lambda _args, p=job_parser: p.print_help())
    job_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    job_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    job_subparsers = job_parser.add_subparsers(title="任务子命令")
    
    # 列举任务
    list_jobs_parser = job_subparsers.add_parser("list", help="列举任务")
    list_jobs_parser.add_argument("--page", type=int, default=1, help="页码（默认 1）")
    list_jobs_parser.add_argument("--page-size", type=int, default=50, help="每页大小（默认 50）")
    list_jobs_parser.add_argument(
        "--status",
        choices=["CREATED", "RUNNING", "STOPPED", "FAILED", "SUCCEEDED"],
        help="状态筛选",
    )
    list_jobs_parser.add_argument(
        "--job-type",
        choices=["FLINK_STREAMING_SQL", "FLINK_STREAMING_JAR", "FLINK_BATCH_SQL", "FLINK_BATCH_JAR"],
        help="类型筛选",
    )
    list_jobs_parser.add_argument("--search", help="按任务名称模糊搜索")
    list_jobs_parser.set_defaults(func=list_jobs)

    detail_parser = job_subparsers.add_parser("detail", help="获取任务详情")
    detail_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    detail_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    detail_parser.set_defaults(func=get_job_detail_cmd)

    uuid_parser = job_subparsers.add_parser("uuid", help="获取任务的 GtsJobUuid（云监控 ResourceID）")
    uuid_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    uuid_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    uuid_parser.set_defaults(func=get_job_uuid_cmd)

    instances_parser = job_subparsers.add_parser("instances", help="查询任务历史实例")
    instances_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    instances_parser.add_argument("--state", help="按状态筛选（单个）")
    instances_parser.add_argument("--states", action="append", help="按状态筛选（可重复）")
    instances_parser.add_argument("--page", type=int, default=1, help="页码（默认 1）")
    instances_parser.add_argument("--page-size", type=int, default=20, help="每页大小（默认 20）")
    instances_parser.add_argument("--limit", type=int, default=20, help="展示条数（默认 20）")
    instances_parser.set_defaults(func=list_job_instances_cmd)

    events_parser = job_subparsers.add_parser("events", help="查询任务运行事件")
    events_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    events_parser.add_argument("--limit", type=int, default=50, help="返回条数（默认 50）")
    events_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    events_parser.set_defaults(func=get_job_events_cmd)
    
    # 启动任务
    start_job_parser = job_subparsers.add_parser("start", help="启动任务")
    start_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    start_job_parser.add_argument("--from", dest="from_mode", choices=["latest", "new", "savepoint"], help="启动方式")
    start_job_parser.add_argument("--savepoint-id", dest="savepoint_id", help="SavepointId（from=savepoint 时必填）")
    start_job_parser.add_argument("--start-type", default=None, choices=["FROM_NEW", "FROM_LATEST", "FROM_SAVEPOINT"], help="启动类型（兼容参数）")
    start_job_parser.add_argument("--inspect", action="store_true", help="启动后持续轮询任务状态")
    start_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    start_job_parser.set_defaults(func=start_job)
    
    # 停止任务
    stop_job_parser = job_subparsers.add_parser("stop", help="停止任务")
    stop_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    stop_job_parser.add_argument("-f", "--force", action="store_true", help="强制停止")
    stop_job_parser.add_argument("--savepoint", action="store_true", help="停止时制作快照（Savepoint）")
    stop_job_parser.add_argument("--inspect", action="store_true", help="停止后持续轮询任务状态")
    stop_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    stop_job_parser.set_defaults(func=stop_job)

    rescale_job_parser = job_subparsers.add_parser("rescale", help="调整任务并行度与规格并发布重启")
    rescale_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    rescale_job_parser.add_argument("--parallelism", type=int, help="并行度")
    rescale_job_parser.add_argument("--tm-spec", help="TM 规格，例如 1C4GB / 2C8GB")
    rescale_job_parser.add_argument("--tm-cpu", type=int, choices=[1, 2, 4, 8, 16], help="TM CPU（1/2/4/8/16）")
    rescale_job_parser.add_argument("--tm-mem-ratio", choices=["1:2", "1:4", "1:8"], help="TM CPU:内存 配比")
    rescale_job_parser.add_argument("--tm-slots", type=int, help="单个 TM slot 数")
    rescale_job_parser.add_argument("--jm-spec", help="JM 规格，例如 1C4GB / 2C8GB")
    rescale_job_parser.add_argument("--jm-cpu", type=int, choices=[1, 2, 4, 8, 16], help="JM CPU（1/2/4/8/16）")
    rescale_job_parser.add_argument("--jm-mem-ratio", choices=["1:2", "1:4", "1:8"], help="JM CPU:内存 配比")
    rescale_job_parser.add_argument("--dry-run", action="store_true", help="仅展示将要修改的配置，不执行更新/发布/重启")
    rescale_job_parser.add_argument("--inspect", action="store_true", help="重启后轮询任务状态")
    rescale_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    rescale_job_parser.set_defaults(func=rescale_job)

    restart_job_parser = job_subparsers.add_parser("restart", help="重启任务")
    restart_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    restart_job_parser.add_argument("--from", dest="from_mode", choices=["latest", "new", "savepoint"], help="重启方式")
    restart_job_parser.add_argument("--savepoint-id", dest="savepoint_id", help="SavepointId（from=savepoint 时必填）")
    restart_job_parser.add_argument("--start-type", default=None, choices=["FROM_NEW", "FROM_LATEST", "FROM_SAVEPOINT"], help="重启类型（兼容参数）")
    restart_job_parser.add_argument("--inspect", action="store_true", help="重启后持续轮询任务状态")
    restart_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    restart_job_parser.set_defaults(func=restart_job)
    
    # 获取任务日志
    logs_parser = job_subparsers.add_parser("logs", help="获取任务日志（GAS）")
    logs_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    logs_parser.add_argument("--instance-id", help="实例ID（不传默认选取最新实例）")
    logs_parser.add_argument("--component", default="jobmanager", choices=["jobmanager", "taskmanager"], help="日志组件")
    logs_parser.add_argument("--file", help="日志文件名")
    logs_parser.add_argument("--file-name", dest="file_name", help="日志文件名（兼容参数）")
    logs_parser.add_argument("-l", "--level", choices=["DEBUG", "INFO", "WARN", "ERROR"], help="日志级别（按文本过滤）")
    logs_parser.add_argument("--since", help="开始时间，格式 2025-01-01 12:00:00")
    logs_parser.add_argument("--until", help="结束时间，格式 2025-01-01 13:00:00")
    logs_parser.add_argument("--start-time-ms", dest="start_time_ms", type=int, help="开始时间（Unix 毫秒）")
    logs_parser.add_argument("--end-time-ms", dest="end_time_ms", type=int, help="结束时间（Unix 毫秒）")
    logs_parser.add_argument("--cursor", default="", help="游标（用于从上次位置继续拉取）")
    logs_parser.add_argument("-p", "--page", type=int, default=1, help="页码（cursor 未提供时按页跳过）")
    logs_parser.add_argument("-s", "--page-size", dest="page_size", type=int, default=500, help="返回条数（默认 500）")
    logs_parser.add_argument("--follow", action="store_true", help="实时 tail")
    logs_parser.add_argument("--interval", type=float, default=2.0, help="tail 间隔秒（默认 2）")
    logs_parser.set_defaults(func=get_job_logs)
    
    # 获取任务指标
    metrics_parser = job_subparsers.add_parser("metrics", help="任务指标查询")
    metrics_subparsers = metrics_parser.add_subparsers(title="metrics 子命令")
    metrics_list_parser = metrics_subparsers.add_parser("list", help="查询可用指标列表")
    metrics_list_parser.add_argument("--sub-namespace", default=None, help="SubNamespace 过滤")
    metrics_list_parser.set_defaults(func=list_job_metrics_catalog)

    metrics_parser.add_argument("-m", "--metric", dest="metric_names", action="append", help="指标名，可重复")
    metrics_parser.add_argument("-i", "--job-id", help="任务ID（用于自动解析 GtsJobUuid）")
    metrics_parser.add_argument("-u", "--gtsjobuuid", help="GtsJobUuid（云监控 ResourceID），优先级高于 job-id")
    metrics_parser.add_argument("--start-time", type=int, help="开始时间（Unix 秒）")
    metrics_parser.add_argument("--end-time", type=int, help="结束时间（Unix 秒）")
    metrics_parser.add_argument("--group-by", action="append", help="GroupBy 字段，可重复")
    metrics_parser.add_argument("--sub-namespace", default=None, help="SubNamespace（默认 overview）")
    metrics_parser.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    metrics_parser.add_argument("--graph", action="store_true", help="以时序图形式输出")
    metrics_parser.add_argument("--graph-width", type=int, default=80, help="时序图宽度（默认 80）")
    metrics_parser.set_defaults(func=get_job_metrics)

    ui_parser = job_subparsers.add_parser("ui", help="输出任务运维与 FlinkUI 地址")
    ui_parser.add_argument("-i", "--job-id", help="任务ID（可选，用于输出 FlinkUI）")
    ui_parser.set_defaults(func=job_ui)

    savepoint_parser = job_subparsers.add_parser("savepoint", help="快照操作")
    savepoint_parser.set_defaults(func=lambda _args, p=savepoint_parser: p.print_help())
    savepoint_subparsers = savepoint_parser.add_subparsers(title="快照子命令")

    savepoint_make_parser = savepoint_subparsers.add_parser("make", help="制作快照")
    savepoint_make_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_make_parser.add_argument("-d", "--description", required=True, help="快照描述")
    savepoint_make_parser.add_argument("--inspect", action="store_true", help="制作后轮询直到快照可用")
    savepoint_make_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    savepoint_make_parser.set_defaults(func=make_job_savepoint)

    savepoint_list_parser = savepoint_subparsers.add_parser("list", help="查询快照列表")
    savepoint_list_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_list_parser.add_argument("--status", help="状态筛选（AVAILABLE/CREATING/FAIL 等）")
    savepoint_list_parser.set_defaults(func=list_job_savepoints)

    savepoint_available_parser = savepoint_subparsers.add_parser("start-available", help="查询可恢复快照")
    savepoint_available_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_available_parser.set_defaults(func=list_job_start_available_savepoints)

    savepoints_parser = job_subparsers.add_parser("savepoints", help="查询快照列表（兼容命令）")
    savepoints_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoints_parser.add_argument("--status", help="状态筛选（AVAILABLE/CREATING/FAIL 等）")
    savepoints_parser.set_defaults(func=list_job_savepoints)
    
    # 版本信息
    parser.add_argument("-v", "--version", action="version", version="Volcano Flink Client v1.0.0")
    
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    
    args = parser.parse_args()
    
    try:
        args.func(args)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        if hasattr(args, "debug") and args.debug:
            import traceback
            print(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()
