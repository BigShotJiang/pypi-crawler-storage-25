"""
认证模块 - 处理火山引擎账号登录和密钥管理
Authentication Module - Handles Volcano Engine account login and key management
"""

import os
import json
import hashlib
from pathlib import Path
from typing import Optional, Tuple
from dataclasses import dataclass


@dataclass
class Credentials:
    """存储访问密钥的类"""
    access_key: str
    secret_key: str
    region: str = "cn-beijing"
    account_id: Optional[str] = None
    tos_jar_prefix: Optional[str] = None
    default_project_id: Optional[str] = None
    default_project_name: Optional[str] = None


@dataclass
class PublicConfig:
    region: Optional[str]
    tos_jar_prefix: Optional[str]
    default_project_id: Optional[str]
    default_project_name: Optional[str]
    config_dir: str
    credentials_file: str


class AuthManager:
    """
    认证管理类，负责：
    1. 存储和管理用户的 AK/SK
    2. 密钥加密和安全存储
    3. 加载已保存的凭据
    """
    
    def __init__(self, config_dir: str = None):
        if config_dir is None:
            config_dir = self._get_default_config_dir()
        self.config_dir = Path(config_dir).expanduser()
        self.credentials_file = self.config_dir / "credentials.json"
        try:
            self._ensure_config_dir_exists()
        except OSError:
            self.config_dir = Path.cwd() / ".volcano_flink"
            self.credentials_file = self.config_dir / "credentials.json"
            self._ensure_config_dir_exists()
    
    def _get_default_config_dir(self) -> str:
        """获取默认配置目录"""
        env_dir = os.environ.get("VOLC_FLINK_CONFIG_DIR")
        if env_dir:
            return env_dir
        local_dir = Path.cwd() / ".volcano_flink"
        if (local_dir / "credentials.json").exists():
            return str(local_dir)
        home_dir = Path.home()
        return str(home_dir / ".volcano_flink")
    
    def _ensure_config_dir_exists(self):
        """确保配置目录存在"""
        self.config_dir.mkdir(parents=True, exist_ok=True)
    
    def _encrypt_secret_key(self, secret_key: str) -> str:
        """简单的密钥加密（生产环境建议使用更安全的加密方式）"""
        # 这里使用简单的哈希加密，实际项目中建议使用 cryptography 库
        return hashlib.sha256(secret_key.encode()).hexdigest()
    
    def _decrypt_secret_key(self, encrypted_secret: str) -> str:
        """解密密钥（注意：实际项目中需要实现真实的解密逻辑）"""
        # 注意：SHA256 是单向哈希，无法解密
        # 生产环境中应该使用对称加密算法
        raise NotImplementedError("Decryption not supported for hash-based encryption")
    
    def login(self, access_key: str, secret_key: str, region: str = "cn-beijing") -> Credentials:
        """
        用户登录，保存凭据
        
        Args:
            access_key: 访问密钥
            secret_key: 安全密钥
            region: 区域
            
        Returns:
            凭据对象
        """
        credentials = Credentials(
            access_key=access_key,
            secret_key=secret_key,
            region=region
        )
        
        # 保存凭据到文件
        self._save_credentials(credentials)
        
        return credentials
    
    def _save_credentials(self, credentials: Credentials):
        """保存凭据到文件"""
        credentials_data = {
            "format_version": 2,
            "access_key": credentials.access_key,
            "secret_key": credentials.secret_key,
            "region": credentials.region,
            "account_id": credentials.account_id,
            "tos_jar_prefix": credentials.tos_jar_prefix,
            "default_project_id": credentials.default_project_id,
            "default_project_name": credentials.default_project_name,
        }
        
        try:
            with open(self.credentials_file, 'w', encoding='utf-8') as f:
                json.dump(credentials_data, f, ensure_ascii=False, indent=2)
        except OSError:
            self.config_dir = Path.cwd() / ".volcano_flink"
            self.credentials_file = self.config_dir / "credentials.json"
            self._ensure_config_dir_exists()
            with open(self.credentials_file, 'w', encoding='utf-8') as f:
                json.dump(credentials_data, f, ensure_ascii=False, indent=2)
        
        # 设置文件权限为只允许当前用户读写（Unix系统）
        try:
            os.chmod(self.credentials_file, 0o600)
        except Exception as e:
            pass
    
    def load_credentials(self) -> Optional[Credentials]:
        """加载已保存的凭据"""
        if not self.credentials_file.exists():
            return None
        
        try:
            with open(self.credentials_file, 'r', encoding='utf-8') as f:
                credentials_data = json.load(f)
            
            secret_key = credentials_data.get("secret_key")
            if credentials_data.get("format_version") != 2:
                if isinstance(secret_key, str) and len(secret_key) == 64:
                    try:
                        int(secret_key, 16)
                        return None
                    except ValueError:
                        pass

            return Credentials(
                access_key=credentials_data["access_key"],
                secret_key=secret_key,
                region=credentials_data.get("region", "cn-beijing"),
                account_id=credentials_data.get("account_id"),
                tos_jar_prefix=credentials_data.get("tos_jar_prefix"),
                default_project_id=credentials_data.get("default_project_id"),
                default_project_name=credentials_data.get("default_project_name"),
            )
        except Exception as e:
            return None

    def set_tos_jar_prefix(self, tos_jar_prefix: str) -> Credentials:
        credentials = self.load_credentials()
        if not credentials:
            raise ValueError("Not logged in")
        credentials.tos_jar_prefix = tos_jar_prefix
        self._save_credentials(credentials)
        return credentials

    def set_default_project_id(self, project_id: str, project_name: Optional[str] = None) -> Credentials:
        credentials = self.load_credentials()
        if not credentials:
            raise ValueError("Not logged in")
        credentials.default_project_id = project_id
        if project_name is not None:
            credentials.default_project_name = project_name
        self._save_credentials(credentials)
        return credentials

    def get_public_config(self) -> PublicConfig:
        credentials = self.load_credentials()
        if credentials:
            return PublicConfig(
                region=credentials.region,
                tos_jar_prefix=credentials.tos_jar_prefix,
                default_project_id=credentials.default_project_id,
                default_project_name=credentials.default_project_name,
                config_dir=str(self.config_dir),
                credentials_file=str(self.credentials_file),
            )
        return PublicConfig(
            region=None,
            tos_jar_prefix=None,
            default_project_id=None,
            default_project_name=None,
            config_dir=str(self.config_dir),
            credentials_file=str(self.credentials_file),
        )

    def get_region(self) -> Optional[str]:
        return self.get_public_config().region

    def get_tos_jar_prefix(self) -> Optional[str]:
        return self.get_public_config().tos_jar_prefix

    def get_default_project_id(self) -> Optional[str]:
        return self.get_public_config().default_project_id

    def get_default_project_name(self) -> Optional[str]:
        return self.get_public_config().default_project_name

    def get_config_dir(self) -> str:
        return self.get_public_config().config_dir

    def get_credentials_file(self) -> str:
        return self.get_public_config().credentials_file
    
    def logout(self) -> bool:
        """
        退出登录，删除凭据文件
        
        Returns:
            是否成功删除
        """
        if self.credentials_file.exists():
            try:
                self.credentials_file.unlink()
                return True
            except Exception as e:
                return False
        return True
    
    def is_logged_in(self) -> bool:
        """检查用户是否已登录"""
        return self.credentials_file.exists()
