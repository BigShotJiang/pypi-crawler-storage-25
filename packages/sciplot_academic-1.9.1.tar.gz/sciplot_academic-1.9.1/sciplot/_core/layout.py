"""
布局管理 — 图形创建、子图排布、保存、面板标签
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple, Union, cast

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec

from sciplot._core.style import VENUES

if TYPE_CHECKING:
    from sciplot._core.result import GridSpecResult


# ============================================================================
# 论文子图尺寸配置（单位：英寸）
# 键格式："{nrows}x{ncols}"
# ============================================================================

PAPER_LAYOUTS: Dict[str, Dict[str, Tuple[float, float]]] = {
    "thesis": {          # A4 版心宽 6.1in ≈ 15.5cm
        "1x1": (6.1, 4.3),
        "1x2": (6.1, 3.0),
        "1x3": (6.1, 2.4),
        "2x1": (4.0, 5.5),
        "2x2": (6.1, 5.0),
        "2x3": (6.1, 4.0),
        "3x1": (4.0, 7.5),
        "3x2": (6.1, 6.5),
    },
    "ieee": {            # 单栏 3.5in，双栏通栏 7.16in
        "1x1": (3.5, 3.0),
        "1x2": (3.5, 1.8),
        "1x3": (3.5, 1.4),
        "2x1": (3.5, 4.5),
        "2x2": (3.5, 3.0),
        "2x3": (3.5, 2.4),
        "wide-1x1": (7.16, 3.0),   # 双栏通栏图
        "wide-1x2": (7.16, 2.0),
        "wide-2x2": (7.16, 4.5),
    },
    "nature": {          # 单栏 3.5in (89mm)，双栏全图 7.0in (178mm)
        "1x1": (7.0, 5.0),
        "1x2": (7.0, 3.0),
        "1x3": (7.0, 2.4),
        "2x1": (3.5, 5.0),
        "2x2": (7.0, 5.0),
        "2x3": (7.0, 4.0),
        "single-1x1": (3.5, 2.8),  # 单栏图
    },
    "aps": {             # 单栏 3.4in (86mm)
        "1x1": (3.4, 2.8),
        "1x2": (3.4, 1.6),
        "2x1": (3.4, 4.5),
        "2x2": (3.4, 2.8),
        "wide-1x1": (7.0, 2.8),
    },
    "springer": {
        "1x1": (6.0, 4.5),
        "1x2": (6.0, 2.6),
        "2x2": (6.0, 4.2),
    },
    "presentation": {
        "1x1": (8.0, 5.5),
        "1x2": (8.0, 3.5),
        "2x2": (8.0, 5.0),
    },
}


# ============================================================================
# 基础图形创建
# ============================================================================

def new_figure(
    venue: Optional[str] = None,
    figsize: Optional[Tuple[float, float]] = None,
    **kwargs: Any,
) -> Tuple[Figure, Axes]:
    """
    创建新图形，自动套用 venue 默认尺寸

    参数:
        venue  : 期刊预设（'nature' | 'ieee' | 'aps' | 'springer' | 'thesis' | 'presentation'）；
                 为 None 时复用当前 rcParams.figure.figsize
        figsize: 自定义 (宽, 高) 英寸，传入则覆盖 venue 默认值
        **kwargs: 传递给 plt.subplots()

    返回:
        (Figure, Axes) 或 (Figure, ndarray[Axes])（当 kwargs 含 nrows/ncols 时）

    示例:
        >>> fig, ax = sp.new_figure("ieee")
        >>> fig, ax = sp.new_figure(figsize=(5.0, 3.5))
        >>> fig, axes = sp.new_figure("thesis", nrows=1, ncols=2, sharex=True)
    """
    if venue is None:
        if figsize is None:
            return cast(Tuple[Figure, Axes], plt.subplots(**kwargs))
        return cast(Tuple[Figure, Axes], plt.subplots(figsize=figsize, **kwargs))

    if venue not in VENUES:
        raise ValueError(f"未知 venue '{venue}'，可用选项: {list(VENUES.keys())}")
    default_figsize = VENUES[venue].figsize
    size = figsize if figsize is not None else default_figsize
    return cast(Tuple[Figure, Axes], plt.subplots(figsize=size, **kwargs))


# ============================================================================
# 子图布局
# ============================================================================

def create_subplots(
    nrows: int = 1,
    ncols: int = 1,
    venue: str = "nature",
    sharex: bool = False,
    sharey: bool = False,
    palette: Optional[str] = None,
    lang: Optional[str] = None,
    **kwargs: Any,
) -> Tuple[Figure, Union[Axes, np.ndarray]]:
    """
    创建规则网格子图布局（尺寸自动按 venue 比例等比缩放）

    适合快速布局，不要求严格匹配论文版心宽度时使用。
    要求精确匹配版心请用 paper_subplots()。

    参数:
        nrows, ncols: 行列数
        venue       : 期刊预设（影响字号和比例）
        sharex/sharey: 是否共享坐标轴
        palette     : 配色方案
        lang        : 语言设置

    示例:
        >>> fig, axes = sp.create_subplots(2, 2, venue="ieee", sharex=True)
        >>> axes[0, 0].plot(x, y)
    """
    from sciplot._core.utils import apply_resolved_style
    from sciplot._core.config import get_config

    # 当 palette 未显式传入时，读取配置默认值
    if palette is None:
        cfg_palette = get_config("palette")
        if isinstance(cfg_palette, str) and cfg_palette:
            palette = cfg_palette

    effective_venue = apply_resolved_style(venue, palette, lang)
    # 回退为指定的 venue（apply_resolved_style 在上下文中可能返回 None）
    resolved_venue = effective_venue or venue

    base_figsize = VENUES[resolved_venue].figsize
    figsize = (base_figsize[0] * ncols * 0.85, base_figsize[1] * nrows * 0.85)

    fig, axes = plt.subplots(
        nrows=nrows, ncols=ncols, figsize=figsize,
        sharex=sharex, sharey=sharey, **kwargs
    )
    _set_ticks_inward(axes)
    return fig, axes


def paper_subplots(
    nrows: int = 1,
    ncols: int = 1,
    venue: str = "nature",
    figsize: Optional[Tuple[float, float]] = None,
    palette: Optional[str] = None,
    lang: Optional[str] = None,
    **kwargs: Any,
) -> Tuple[Figure, Union[Axes, np.ndarray]]:
    """
    创建严格符合论文版心宽度的子图布局（推荐）

    使用预标定的尺寸表（PAPER_LAYOUTS），确保插入 Word/LaTeX 时不变形。
    如果预设中没有对应布局，自动回退到等比例计算。

    参数:
        nrows, ncols: 行列数
        venue       : 论文类型（'thesis' | 'ieee' | 'nature' | 'aps' | 'springer'）
        figsize     : 覆盖预设尺寸（可选）
        palette     : 配色方案
        lang        : 语言设置

    示例:
        >>> # Word 论文 1×2 子图，精确匹配 A4 版心
        >>> fig, axes = sp.paper_subplots(1, 2, venue="thesis")
        >>> axes[0].plot(x, y1); axes[0].set_title("(a)")
        >>> axes[1].plot(x, y2); axes[1].set_title("(b)")
        >>> sp.save(fig, "thesis_1x2", formats=("png",), dpi=1200)

        >>> # IEEE 2×2 子图
        >>> fig, axes = sp.paper_subplots(2, 2, venue="ieee")
    """
    from sciplot._core.utils import apply_resolved_style
    from sciplot._core.config import get_config

    if palette is None:
        cfg_palette = get_config("palette")
        if isinstance(cfg_palette, str) and cfg_palette:
            palette = cfg_palette

    effective_venue = apply_resolved_style(venue, palette, lang)
    resolved_venue = effective_venue or venue

    if figsize is not None:
        final_figsize: Tuple[float, float] = figsize
    else:
        layout_key = f"{nrows}x{ncols}"
        venue_layouts = PAPER_LAYOUTS.get(resolved_venue, {})
        layout_figsize = venue_layouts.get(layout_key)
        if layout_figsize is None:
            # 回退：基于 venue 默认尺寸等比缩放
            base_fs = VENUES.get(resolved_venue, VENUES["nature"]).figsize
            final_figsize = (base_fs[0] * ncols * 0.85, base_fs[1] * nrows * 0.85)
        else:
            final_figsize = layout_figsize

    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=final_figsize, **kwargs)
    _set_ticks_inward(axes)
    return fig, axes


def create_gridspec(
    nrows: int = 1,
    ncols: int = 1,
    venue: str = "nature",
    palette: Optional[str] = None,
    lang: Optional[str] = None,
    **kwargs: Any,
) -> "GridSpecResult":
    """
    创建 GridSpec 不规则子图布局

    参数:
        nrows, ncols: 行列数
        venue       : 期刊预设
        palette     : 配色方案
        lang        : 语言设置

    示例:
        >>> fig, gs = sp.create_gridspec(2, 3, venue="nature")
        >>> ax_top = fig.add_subplot(gs[0, :])   # 顶部通栏
        >>> ax_bl  = fig.add_subplot(gs[1, 0])
        >>> ax_bm  = fig.add_subplot(gs[1, 1])
        >>> ax_br  = fig.add_subplot(gs[1, 2])
        >>> for ax in fig.axes: ax.tick_params(direction="in")
        >>> sp.save(fig, "gridspec")
    """
    from sciplot._core.utils import apply_resolved_style
    from sciplot._core.result import GridSpecResult
    from sciplot._core.config import get_config

    if palette is None:
        cfg_palette = get_config("palette")
        if isinstance(cfg_palette, str) and cfg_palette:
            palette = cfg_palette

    effective_venue = apply_resolved_style(venue, palette, lang)
    resolved_venue = effective_venue or venue

    figsize = VENUES[resolved_venue].figsize
    fig = plt.figure(figsize=figsize)
    gs = GridSpec(nrows, ncols, figure=fig, **kwargs)
    return GridSpecResult(fig, gs)


def create_twinx(ax: Axes) -> Axes:
    """
    创建共享 X 轴的副 Y 轴（双 Y 轴）

    示例:
        >>> sp.setup_style("ieee", "pastel-2")
        >>> fig, ax1 = sp.new_figure("ieee")
        >>> ax1.plot(x, temp, color="#cdb4db", label="温度")
        >>> ax1.set_ylabel("温度 (K)", color="#cdb4db")
        >>> ax2 = sp.create_twinx(ax1)
        >>> ax2.plot(x, pressure, color="#ffc8dd", label="压力")
        >>> ax2.set_ylabel("压力 (Pa)", color="#ffc8dd")
        >>> sp.save(fig, "dual_axis")
    """
    ax2 = ax.twinx()
    ax2.tick_params(direction="in")
    return ax2


# ============================================================================
# 面板标签
# ============================================================================

def add_panel_labels(
    axes: Union[Axes, np.ndarray, Sequence[Axes]],
    labels: Optional[List[str]] = None,
    style: str = "letter",
    x: float = -0.12,
    y: float = 1.05,
    fontsize: Optional[int] = None,
    fontweight: str = "bold",
) -> None:
    """
    为多子图自动添加面板标签（(a) (b) (c) 或 A B C 等）

    参数:
        axes     : 子图对象（单个 / ndarray / list）
        labels   : 自定义标签列表；为 None 时按 style 自动生成
        style    : 自动生成样式
                   'letter'     → (a) (b) (c) …（默认，最常见）
                   'LETTER'     → (A) (B) (C) …
                   'number'     → (1) (2) (3) …
                   'roman'      → (i) (ii) (iii) …
        x, y     : 标签位置（axes 坐标，x<0 表示轴框左侧）
        fontsize : 字号；为 None 则继承当前 rcParams
        fontweight: 字重，默认 'bold'

    示例:
        >>> fig, axes = sp.paper_subplots(1, 3, venue="thesis")
        >>> # ... 绘图 ...
        >>> sp.add_panel_labels(axes)   # 自动加 (a) (b) (c)
        >>> sp.save(fig, "fig_multi")

        >>> # 自定义标签
        >>> sp.add_panel_labels(axes, labels=["实验组", "对照组", "空白组"],
        ...                     x=-0.18, y=1.08)
    """
    def _int_to_roman(num: int) -> str:
        if num <= 0:
            raise ValueError("roman 序号必须为正整数")
        if num > 3999:
            raise ValueError("roman 序号不能超过 3999")
        vals = [
            (1000, "M"), (900, "CM"), (500, "D"), (400, "CD"),
            (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
            (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I"),
        ]
        result = []
        left = num
        for value, symbol in vals:
            while left >= value:
                result.append(symbol)
                left -= value
        return "".join(result).lower()

    def _int_to_letters(num: int, upper: bool = False) -> str:
        if num <= 0:
            raise ValueError("letter 序号必须为正整数")
        chars: List[str] = []
        idx = num
        while idx > 0:
            idx -= 1
            chars.append(chr(ord("a") + (idx % 26)))
            idx //= 26
        text = "".join(reversed(chars))
        return text.upper() if upper else text

    # 展开 axes
    if isinstance(axes, np.ndarray):
        ax_list = list(axes.flat)
    elif isinstance(axes, Axes):
        ax_list = [axes]
    else:
        ax_list = list(axes)

    n = len(ax_list)

    if labels is not None:
        if len(labels) != n:
            raise ValueError(
                f"labels 长度 ({len(labels)}) 与子图数量 ({n}) 不匹配"
            )
        final_labels = labels
    else:
        if style == "letter":
            final_labels = [f"({_int_to_letters(i + 1)})" for i in range(n)]
        elif style == "LETTER":
            final_labels = [f"({_int_to_letters(i + 1, upper=True)})" for i in range(n)]
        elif style == "number":
            final_labels = [f"({i + 1})" for i in range(n)]
        elif style == "roman":
            final_labels = [f"({_int_to_roman(i + 1)})" for i in range(n)]
        else:
            raise ValueError(
                f"未知 style '{style}'，可选: 'letter' | 'LETTER' | 'number' | 'roman'"
            )

    for ax, lbl in zip(ax_list, final_labels):
        # 根据 x 坐标自动推断对齐方式
        ha = "right" if x <= 0 else "left"
        kw: Dict[str, Any] = dict(
            transform=ax.transAxes,
            fontweight=fontweight,
            va="top",
            ha=ha,
        )
        if fontsize is not None:
            kw["fontsize"] = fontsize
        ax.text(x, y, lbl, **kw)


# ============================================================================
# 保存
# ============================================================================

def _normalize_output_formats(formats: Union[str, Sequence[str]]) -> Tuple[str, ...]:
    """规范化输出格式参数，兼容单字符串输入。"""
    if isinstance(formats, str):
        normalized = (formats,)
    else:
        normalized = tuple(formats)

    if not normalized:
        raise ValueError("formats 不能为空")

    result: List[str] = []
    for fmt in normalized:
        if not isinstance(fmt, str) or not fmt.strip():
            raise ValueError("formats 必须是非空字符串或字符串序列")
        result.append(fmt.strip().lower())

    return tuple(result)

def save(
    fig: Figure,
    name: str,
    dpi: Optional[Union[int, float]] = None,
    formats: Optional[Union[str, Sequence[str]]] = None,
    bbox_inches: str = "tight",
    dir: Optional[str] = None,
    close: bool = False,
    **kwargs: Any,
) -> List[Path]:
    """
    保存图形（同时输出多种格式）

    参数:
        fig        : Matplotlib 图形对象
        name       : 文件名（不含扩展名），可包含子目录路径
        dpi        : 位图分辨率；为 None 时读取配置默认值
        formats    : 输出格式元组；为 None 时读取配置默认值
                     支持："pdf" | "png" | "svg" | "eps"
        bbox_inches: 默认 "tight"，自动裁剪多余白边
        dir        : 保存目录；为 None 则保存到当前工作目录
        close      : 保存后是否自动关闭图形释放内存，默认 False

    返回:
        List[Path]: 已保存文件的路径列表

    示例:
        >>> sp.save(fig, "fig1")                              # → fig1.pdf + fig1.png
        >>> sp.save(fig, "word稿", formats=("png",), dpi=1200) # 仅 PNG
        >>> sp.save(fig, "投稿", formats=("pdf",))             # 仅 PDF
        >>> sp.save(fig, "fig", dir="outputs/figures")        # 保存到指定目录
        >>> sp.save(fig, "nested/dir/fig")                    # 自动创建嵌套目录
        >>> sp.save(fig, "batch", close=True)                 # 保存后自动关闭
    """
    from sciplot._core.config import get_config

    VECTOR_FORMATS = {"pdf", "svg", "eps"}
    resolved_formats = formats if formats is not None else get_config("formats")
    normalized_formats = _normalize_output_formats(resolved_formats)
    resolved_dpi = dpi if dpi is not None else get_config("dpi")

    supported_formats = set(fig.canvas.get_supported_filetypes().keys())
    invalid_formats = [fmt for fmt in normalized_formats if fmt not in supported_formats]
    if invalid_formats:
        raise ValueError(
            f"不支持的输出格式: {invalid_formats}。可用格式: {sorted(supported_formats)}"
        )

    if any(fmt not in VECTOR_FORMATS for fmt in normalized_formats):
        if not isinstance(resolved_dpi, (int, float)) or resolved_dpi <= 0:
            raise ValueError(f"dpi 必须为正数，实际值: {resolved_dpi!r}")

    # 处理 name 可能包含路径的情况
    name_path = Path(name)
    if name_path.name in {"", ".", ".."}:
        raise ValueError("name 必须是有效文件名")

    if dir:
        if name_path.is_absolute():
            raise ValueError("指定 dir 时，name 不能为绝对路径")

        base_dir = Path(dir).expanduser().resolve()
        save_dir = (base_dir / name_path.parent).resolve()
        try:
            save_dir.relative_to(base_dir)
        except ValueError as exc:
            raise ValueError("name 不能通过路径回退跳出 dir 指定目录") from exc
    else:
        save_dir = name_path.parent if name_path.parent != Path(".") else Path.cwd()
        if not save_dir.is_absolute():
            save_dir = Path.cwd() / save_dir

    # 确保目录存在（递归创建）
    save_dir.mkdir(parents=True, exist_ok=True)

    # 纯文件名（不含路径）
    filename = name_path.name

    saved_paths: List[Path] = []
    for fmt in normalized_formats:
        path = save_dir / f"{filename}.{fmt}"
        extra = {} if fmt in VECTOR_FORMATS else {"dpi": resolved_dpi}
        fig.savefig(path, bbox_inches=bbox_inches, format=fmt, **extra, **kwargs)
        saved_paths.append(path)

    if close:
        plt.close(fig)

    return saved_paths


# ============================================================================
# 工具
# ============================================================================

def list_paper_layouts(
    venue: Optional[str] = None,
) -> Dict[str, Dict[str, Tuple[float, float]]]:
    """
    列出论文子图布局预设尺寸

    参数:
        venue: 指定期刊只看该期刊的布局；为 None 则返回全部

    示例:
        >>> sp.list_paper_layouts("thesis")
        {'thesis': {'1x1': (6.1, 4.3), '1x2': (6.1, 3.0), ...}}
    """
    if venue:
        return {venue: PAPER_LAYOUTS.get(venue, {})}
    return PAPER_LAYOUTS


# ============================================================================
# 内部工具
# ============================================================================

def _set_ticks_inward(axes: Union[Axes, np.ndarray, Sequence[Axes]]) -> None:
    """将所有子图的刻度设为朝内，并显式关闭网格线。"""
    if isinstance(axes, np.ndarray):
        for ax in axes.flat:
            if isinstance(ax, Axes):
                ax.tick_params(direction="in")
                ax.grid(False)
    elif isinstance(axes, Axes):
        axes.tick_params(direction="in")
        axes.grid(False)
    elif hasattr(axes, "__iter__"):
        for ax in axes:
            if isinstance(ax, Axes):
                ax.tick_params(direction="in")
                ax.grid(False)

