import uuid
from datetime import datetime, UTC
from importlib.metadata import version
from typing import Any

import sys

from patchwork.core.client.serializers.base import BaseTaskSerializer
from patchwork.core.client.serializers.betterproto import BetterprotoSerializer
from patchwork.core.component import Component
from .task import Task, TaskMetadata

try:
    from prometheus_client import Counter, Histogram, Info, Summary
except ImportError:
    from ..stubs.prometheus import Counter, Histogram, Info, Summary

serialization_time = Summary('publisher_serialization', "Task serialization time")

send_time = Histogram('publisher_send_time', "Publisher send time")
publisher_info = Info("publisher_info", "Publisher info")
publisher_out_count = Counter('publisher_out_count', "Number of messages sent out")
publisher_out_size = Counter('publisher_out_size', "Size of messages sent out")

DEFAULT_MAX_MSG_SIZE = 1 * 1024 * 1024  # 1MB


class PatchworkPublisher(Component):
    """
    Common code for sync and async publishers
    """

    asynchronous: bool

    def __init__(
            self,
            *,
            parent: Component | None = None,
            enabled: bool = True,
            serializer: BaseTaskSerializer = BetterprotoSerializer(),
            max_message_size: int = DEFAULT_MAX_MSG_SIZE
    ):
        super().__init__(parent=parent, enabled=enabled)
        self._max_message_size = max_message_size

        self.task_serializer = serializer
        publisher_info.info(self._get_info())

    def __repr__(self):
        return super().__repr__().replace('Component', 'Publisher')

    def _get_info(self):
        return {
            'patchwork_version': version('patchwork-core') if 'patchwork-core' in sys.modules else ""
        }

    @serialization_time.time()
    def _serialize_task(self, task: Task) -> bytes:
        """
        Take a task and returns serialized task payload as bytes.
        :param task:    Task instance
        :return:    Serialized task
        """
        return self.task_serializer.encode(task)

    def _prepare_task(self, task: Task) -> bytes:
        """
        Prepares task to be send. Makes validation tests on the task and returns serialized payload.
        Internally this method calls _serialize_task()
        :param task:
        :raise ValueError: if task validation fails
        :return: payload of serialized task if validation pass
        """
        if not task.uuid:
            task.uuid = uuid.uuid4()
        task.meta.scheduled = datetime.now(UTC)

        if task.meta.expires and task.meta.expires < task.meta.scheduled:
            raise ValueError('unable to send task which is already expired')

        payload = self._serialize_task(task)
        if len(payload) > self._max_message_size:
            raise ValueError('message is too big')

        return payload

    def _build_task(
            self,
            payload: Any,
            queue_name: str,
            cause: Task = None,
            task_type: str = None,
            not_before: datetime = None,
            expires: datetime = None,
            max_retries: int = None,
            **extra
    ):
        metadata = TaskMetadata(
            queue_name=queue_name
        )
        if not_before is not None:
            metadata.not_before = not_before

        if expires is not None:
            metadata.expires = expires

        if max_retries is not None:
            metadata.max_retries = max_retries

        if extra:
            metadata.extra = dict(extra)

        task = Task(
            uuid=uuid.uuid4(),
            meta=metadata,
            task_type=task_type or payload.__class__.__name__,
            payload=payload
        )

        if cause is not None:
            task.correlation_id = cause.correlation_id or str(cause.uuid)

        return task


class AsyncPublisher(PatchworkPublisher):
    """
    Patchwork asynchronous publisher
    """

    is_asynchronous = True

    async def send(
            self,
            payload: Any,
            *,
            queue_name: str,
            timeout: float = None,
            cause: Task = None,
            task_type: str = None,
            not_before: datetime = None,
            expires: datetime = None,
            max_retries: int = None,
            **extra
    ):
        task = self._build_task(
            payload,
            cause=cause,
            task_type=task_type,
            queue_name=queue_name,
            not_before=not_before,
            expires=expires,
            max_retries=max_retries,
            **extra
        )
        await self.send_task(task, timeout=timeout)
        return task

    async def send_task(self, task: Task, *, timeout: float = None):
        """
        Sends given task, if operation fail in given timeout raises TimeoutError.
        When this method returns it's considered as task has been delivered successfully and it's guaranteed
        that won't be lost (eg queue backend committed the message)
        :param task:
        :param timeout: send operation timeout, None means no timeout. 0 means immediatelly
        :return:
        """
        payload = self._prepare_task(task)

        publisher_out_count.inc()
        publisher_out_size.inc(amount=len(payload))

        with send_time.time():
            await self._send(payload, task, timeout=timeout)

    async def _send(self, payload: bytes, task: Task, *, timeout: float = None):
        """
        Sends given payload

        :param payload: Task payload to send
        :param task: Task instance to send, it should be considered as **immutable**
        :param timeout: Requested send operation timeout, None means no timeout, 0 means immediately
        :return:
        """
        raise NotImplementedError()
