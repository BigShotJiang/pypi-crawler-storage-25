# numind.openapi_client.StructuredExtractionExamplesApi

All URIs are relative to *https://nuextract.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid**](StructuredExtractionExamplesApi.md#delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid) | **DELETE** /api/structured-extraction/{structuredProjectId}/examples/{structuredExampleId} | 
[**get_api_structured_extraction_structuredprojectid_examples**](StructuredExtractionExamplesApi.md#get_api_structured_extraction_structuredprojectid_examples) | **GET** /api/structured-extraction/{structuredProjectId}/examples | 
[**get_api_structured_extraction_structuredprojectid_examples_structuredexampleid**](StructuredExtractionExamplesApi.md#get_api_structured_extraction_structuredprojectid_examples_structuredexampleid) | **GET** /api/structured-extraction/{structuredProjectId}/examples/{structuredExampleId} | 
[**post_api_structured_extraction_structuredprojectid_examples**](StructuredExtractionExamplesApi.md#post_api_structured_extraction_structuredprojectid_examples) | **POST** /api/structured-extraction/{structuredProjectId}/examples | 
[**put_api_structured_extraction_structuredprojectid_examples_structuredexampleid**](StructuredExtractionExamplesApi.md#put_api_structured_extraction_structuredprojectid_examples_structuredexampleid) | **PUT** /api/structured-extraction/{structuredProjectId}/examples/{structuredExampleId} | 


# **delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid**
> delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, x_organization_id=x_organization_id)


Delete a specific **Example**.

#### Error Responses:
`404 Not Found` - If an **Example** with the specified `exampleId` associated with the given `projectId` does not exist.

`403 Forbidden` - If the user does not have permission to update this **Project**.

`403 Locked` - If the **Project** is locked.
  

### Example

* OAuth Authentication (oauth2Auth):

```python
import numind.openapi_client
from numind.openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://nuextract.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = numind.openapi_client.Configuration(
    host = "https://nuextract.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with numind.openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = numind.openapi_client.StructuredExtractionExamplesApi(api_client)
    structured_project_id = 'structured_project_id_example' # str | Unique structured extraction project identifier.
    structured_example_id = 'structured_example_id_example' # str | Unique structured extraction example identifier.
    x_organization_id = 'x_organization_id_example' # str | Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. (optional)

    try:
        api_instance.delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, x_organization_id=x_organization_id)
    except Exception as e:
        print("Exception when calling StructuredExtractionExamplesApi->delete_api_structured_extraction_structuredprojectid_examples_structuredexampleid: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **structured_project_id** | **str**| Unique structured extraction project identifier. | 
 **structured_example_id** | **str**| Unique structured extraction example identifier. | 
 **x_organization_id** | **str**| Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. | [optional] 

### Return type

void (empty response body)

### Authorization

[oauth2Auth](../README.md#oauth2Auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |
**0** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_structured_extraction_structuredprojectid_examples**
> PaginatedResponseT get_api_structured_extraction_structuredprojectid_examples(structured_project_id, x_organization_id=x_organization_id, skip=skip, per_page=per_page)


Return a list of **Examples** associated to the specified **Structured Extraction Project** with pagination support.

#### Error Responses:
`404 Not Found` - If a **Project** with the specified `projectId` does not exist.

`403 Forbidden` - If the user does not have permission to view this **Project**.
  

### Example

* OAuth Authentication (oauth2Auth):

```python
import numind.openapi_client
from numind.models.paginated_response_t import PaginatedResponseT
from numind.openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://nuextract.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = numind.openapi_client.Configuration(
    host = "https://nuextract.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with numind.openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = numind.openapi_client.StructuredExtractionExamplesApi(api_client)
    structured_project_id = 'structured_project_id_example' # str | Unique structured extraction project identifier.
    x_organization_id = 'x_organization_id_example' # str | Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. (optional)
    skip = 56 # int | Number of examples to skip. Min: 0. Default: 0.  (optional)
    per_page = 56 # int | Number of examples per page. Min: 1. Max: 100. Default: 30.  (optional)

    try:
        api_response = api_instance.get_api_structured_extraction_structuredprojectid_examples(structured_project_id, x_organization_id=x_organization_id, skip=skip, per_page=per_page)
        print("The response of StructuredExtractionExamplesApi->get_api_structured_extraction_structuredprojectid_examples:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling StructuredExtractionExamplesApi->get_api_structured_extraction_structuredprojectid_examples: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **structured_project_id** | **str**| Unique structured extraction project identifier. | 
 **x_organization_id** | **str**| Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. | [optional] 
 **skip** | **int**| Number of examples to skip. Min: 0. Default: 0.  | [optional] 
 **per_page** | **int**| Number of examples per page. Min: 1. Max: 100. Default: 30.  | [optional] 

### Return type

[**PaginatedResponseT**](PaginatedResponseT.md)

### Authorization

[oauth2Auth](../README.md#oauth2Auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/plain

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |
**400** | Invalid value for: query parameter skip, Invalid value for: query parameter perPage |  -  |
**0** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_api_structured_extraction_structuredprojectid_examples_structuredexampleid**
> StructuredExampleResponse get_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, x_organization_id=x_organization_id)


Return a specific **Example**.

#### Error Responses:
`404 Not Found` - If an **Example** with the specified `exampleId` associated with the given `projectId` does not exist.

`403 Forbidden` - If the user does not have permission to view this **Project**.
  

### Example

* OAuth Authentication (oauth2Auth):

```python
import numind.openapi_client
from numind.models.structured_example_response import StructuredExampleResponse
from numind.openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://nuextract.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = numind.openapi_client.Configuration(
    host = "https://nuextract.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with numind.openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = numind.openapi_client.StructuredExtractionExamplesApi(api_client)
    structured_project_id = 'structured_project_id_example' # str | Unique structured extraction project identifier.
    structured_example_id = 'structured_example_id_example' # str | Unique structured extraction example identifier.
    x_organization_id = 'x_organization_id_example' # str | Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. (optional)

    try:
        api_response = api_instance.get_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, x_organization_id=x_organization_id)
        print("The response of StructuredExtractionExamplesApi->get_api_structured_extraction_structuredprojectid_examples_structuredexampleid:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling StructuredExtractionExamplesApi->get_api_structured_extraction_structuredprojectid_examples_structuredexampleid: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **structured_project_id** | **str**| Unique structured extraction project identifier. | 
 **structured_example_id** | **str**| Unique structured extraction example identifier. | 
 **x_organization_id** | **str**| Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. | [optional] 

### Return type

[**StructuredExampleResponse**](StructuredExampleResponse.md)

### Authorization

[oauth2Auth](../README.md#oauth2Auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |
**0** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **post_api_structured_extraction_structuredprojectid_examples**
> StructuredExampleResponse post_api_structured_extraction_structuredprojectid_examples(structured_project_id, create_or_update_structured_example_request, x_organization_id=x_organization_id)


Create a new **Example** associated with a specific **Structured Extraction Project**.
An **Example** consists of an (input, output) pair, where the input is identified by a `documentId`, and the output represents the expected inference result.
To obtain a `documentId`, use the endpoints under the ***documents*** tag.
Once created, this **Example** will be automatically applied to subsequent inference calls as an example — unless the output no longer aligns with the current template.
In such cases, the **Example** will be skipped.

#### Note:
 If the **Project** is a **Reference Project**, the **Document** used to create this **Example** will be automatically shared for read access to all users.
 If the **Document** ownership scope does not match the **Project** ownership scope, the **Example** creation will fail.

#### Effect:
 If the **Project** is a **Reference Project**, the **Document** used to create this **Example** will be automatically shared for read access to all users.

#### Response:
 The response contains `exampleId`, which is required to update or delete this **Example**.

#### Error Responses:
`404 Not Found` - If a **Project** with the specified `projectId` does not exist or a **Document** with the specified `documentId` does not exist.

`403 Forbidden` - If the user does not have permission to update this **Project**, use the specified **Document**, or the **Document** ownership scope does not match **Project** ownership scope

`403 Locked` - If the **Project** is locked.
  

### Example

* OAuth Authentication (oauth2Auth):

```python
import numind.openapi_client
from numind.models.create_or_update_structured_example_request import CreateOrUpdateStructuredExampleRequest
from numind.models.structured_example_response import StructuredExampleResponse
from numind.openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://nuextract.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = numind.openapi_client.Configuration(
    host = "https://nuextract.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with numind.openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = numind.openapi_client.StructuredExtractionExamplesApi(api_client)
    structured_project_id = 'structured_project_id_example' # str | Unique structured extraction project identifier.
    create_or_update_structured_example_request = {"documentId":"449af2b9-a3e7-477b-a1c6-13d4d68fa7de","result":{"orderId":"Example: o-67214","customerId":"Example: c-76549","orderDate":"2024-04-05T08:20:00.000Z","status":"pending","totalAmount":89.75,"currency":"USD","items":[{"productId":"p-00567","quantity":1,"unitPrice":89.75}],"shippingAddress":{"street":"123 Elm St","city":"Boston","state":"MA","country":"USA","zip":"02108"},"comments":"Hold at pickup location.","deliveryPreferences":["scheduled_delivery","contactless_delivery"],"estimatedDelivery":"2024-04-10T19:00:00.000Z"}} # CreateOrUpdateStructuredExampleRequest | 
    x_organization_id = 'x_organization_id_example' # str | Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. (optional)

    try:
        api_response = api_instance.post_api_structured_extraction_structuredprojectid_examples(structured_project_id, create_or_update_structured_example_request, x_organization_id=x_organization_id)
        print("The response of StructuredExtractionExamplesApi->post_api_structured_extraction_structuredprojectid_examples:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling StructuredExtractionExamplesApi->post_api_structured_extraction_structuredprojectid_examples: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **structured_project_id** | **str**| Unique structured extraction project identifier. | 
 **create_or_update_structured_example_request** | [**CreateOrUpdateStructuredExampleRequest**](CreateOrUpdateStructuredExampleRequest.md)|  | 
 **x_organization_id** | **str**| Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. | [optional] 

### Return type

[**StructuredExampleResponse**](StructuredExampleResponse.md)

### Authorization

[oauth2Auth](../README.md#oauth2Auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, text/plain

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |
**400** | Invalid value for: body |  -  |
**0** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **put_api_structured_extraction_structuredprojectid_examples_structuredexampleid**
> StructuredExampleResponse put_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, create_or_update_structured_example_request, x_organization_id=x_organization_id)


Update a specific **Example**.

#### Note:
 If the **Document** ownership scope does not match the **Project** ownership scope, the **Example** update will fail.

#### Error Responses:
`404 Not Found` - If an **Example** with the specified `exampleId` associated with the given `projectId` does not exist, or if a **Document** with the specified `documentId` cannot be found.

`403 Forbidden` - If the user does not have permission to update this **Project**, use the specified **Document**, or the **Document** ownership scope does not match **Project** ownership scope.

`403 Locked` - If the **Project** is locked.
  

### Example

* OAuth Authentication (oauth2Auth):

```python
import numind.openapi_client
from numind.models.create_or_update_structured_example_request import CreateOrUpdateStructuredExampleRequest
from numind.models.structured_example_response import StructuredExampleResponse
from numind.openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://nuextract.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = numind.openapi_client.Configuration(
    host = "https://nuextract.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

configuration.access_token = os.environ["ACCESS_TOKEN"]

# Enter a context with an instance of the API client
with numind.openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = numind.openapi_client.StructuredExtractionExamplesApi(api_client)
    structured_project_id = 'structured_project_id_example' # str | Unique structured extraction project identifier.
    structured_example_id = 'structured_example_id_example' # str | Unique structured extraction example identifier.
    create_or_update_structured_example_request = {documentId=449af2b9-a3e7-477b-a1c6-13d4d68fa7de, result={orderId=Example: o-67214, customerId=Example: c-76549, orderDate=2024-04-05T08:20:00.000Z, status=pending, totalAmount=89.75, currency=USD, items=[{productId=p-00567, quantity=1, unitPrice=89.75}], shippingAddress={street=123 Elm St, city=Boston, state=MA, country=USA, zip=02108}, comments=Hold at pickup location., deliveryPreferences=[scheduled_delivery, contactless_delivery], estimatedDelivery=2024-04-10T19:00:00.000Z}} # CreateOrUpdateStructuredExampleRequest | 
    x_organization_id = 'x_organization_id_example' # str | Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. (optional)

    try:
        api_response = api_instance.put_api_structured_extraction_structuredprojectid_examples_structuredexampleid(structured_project_id, structured_example_id, create_or_update_structured_example_request, x_organization_id=x_organization_id)
        print("The response of StructuredExtractionExamplesApi->put_api_structured_extraction_structuredprojectid_examples_structuredexampleid:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling StructuredExtractionExamplesApi->put_api_structured_extraction_structuredprojectid_examples_structuredexampleid: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **structured_project_id** | **str**| Unique structured extraction project identifier. | 
 **structured_example_id** | **str**| Unique structured extraction example identifier. | 
 **create_or_update_structured_example_request** | [**CreateOrUpdateStructuredExampleRequest**](CreateOrUpdateStructuredExampleRequest.md)|  | 
 **x_organization_id** | **str**| Optional organization to use for this request.   No header means that the user personal account will be used.   This token is *only* used by the _frontend_ application and *will be ignored if used with the API*. When using the api, the organization used will be the one of the api key. | [optional] 

### Return type

[**StructuredExampleResponse**](StructuredExampleResponse.md)

### Authorization

[oauth2Auth](../README.md#oauth2Auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, text/plain

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |
**400** | Invalid value for: body |  -  |
**0** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

