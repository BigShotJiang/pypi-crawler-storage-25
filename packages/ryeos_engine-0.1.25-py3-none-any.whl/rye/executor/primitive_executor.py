"""PrimitiveExecutor - Data-driven tool execution with recursive chain resolution.

Routes tools to Lillux primitives based on __executor_id__ metadata.
Loads tools on-demand from .ai/tools/ with 3-tier space precedence.

Architecture:
    Layer 1: Primitives (__executor_id__ = None) - Execute directly via Lillux
    Layer 2: Runtimes (__executor_id__ = "subprocess") - Resolve ENV_CONFIG first
    Layer 3: Tools (__executor_id__ = "python_runtime") - Delegate to runtimes

Caching:
    - Chain cache: Caches resolved execution chains with hash-based invalidation
    - Metadata cache: Caches tool metadata with hash-based invalidation
    - Automatic invalidation when file content changes (via Lillux hash functions)
"""

import hashlib
import logging
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from rye.primitives.execute import ExecutePrimitive, ExecuteResult
from rye.runtime.env_resolver import EnvResolver

from rye.executor.chain_validator import ChainValidator, ChainValidationResult
from rye.utils.extensions import get_tool_extensions, get_parsers_map
from rye.utils.execution_context import ExecutionContext
from rye.utils.integrity import verify_item, IntegrityError
from rye.utils.metadata_manager import MetadataManager
from rye.utils.path_utils import BundleInfo
from rye.utils.parser_router import ParserRouter
from rye.constants import AI_DIR, ItemType

logger = logging.getLogger(__name__)

# Maximum allowed chain depth to prevent infinite loops
MAX_CHAIN_DEPTH = 10


@dataclass
class CacheEntry:
    """Cache entry with hash for invalidation."""

    data: Any
    content_hash: str


@dataclass
class ExecutionResult:
    """Result of tool execution."""

    success: bool
    data: Any = None
    error: Optional[str] = None
    duration_ms: float = 0.0
    chain: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    trace: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ChainElement:
    """Element in the executor chain."""

    item_id: str
    path: Path
    space: str  # "project", "user", "system"
    tool_type: Optional[str] = None
    executor_id: Optional[str] = None
    env_config: Optional[Dict[str, Any]] = None
    config_schema: Optional[Dict[str, Any]] = None
    config: Optional[Dict[str, Any]] = None
    anchor_config: Optional[Dict[str, Any]] = None
    verify_deps_config: Optional[Dict[str, Any]] = None
    config_resolve: Optional[Dict[str, Any]] = None
    execution_params: Optional[List[str]] = None


class PrimitiveExecutor:
    """Data-driven executor that routes tools to Lillux primitives.

    No hardcoded executor IDs - all resolved from .ai/tools/ filesystem.

    Multi-layer routing (up to MAX_CHAIN_DEPTH=10):
        1. Primitive (__executor_id__ = None): Direct Lillux execution
        2. Runtime (__executor_id__ = "subprocess"): ENV_CONFIG resolution + primitive
        3. Tool (__executor_id__ = "python_runtime"): Delegate to runtime
    Three layers is the common case, but chains can be deeper.
    """

    # Primitive ID to Lillux primitive class mapping (full path IDs)
    PRIMITIVE_MAP = {
        "rye/core/primitives/execute": ExecutePrimitive,
    }

    def __init__(
        self,
        ctx: ExecutionContext,
    ):
        """Initialize executor with an explicit execution context.

        Args:
            ctx: Immutable execution context with all resolved paths.
        """
        self.ctx = ctx
        self.project_path = ctx.project_path
        self.user_space = ctx.user_space
        self.system_spaces: List[BundleInfo] = list(ctx.system_spaces)
        # Use first bundle's root_path as the legacy system_space
        self.system_space = self.system_spaces[0].root_path

        self.env_resolver = EnvResolver(project_path=self.project_path)
        self.parser_router = ParserRouter(project_path=self.project_path)
        self.chain_validator = ChainValidator()

        # Primitive instances (lazy loaded)
        self._primitives: Dict[str, Any] = {}

        # Caches with hash-based invalidation
        self._chain_cache: Dict[
            str, CacheEntry
        ] = {}  # item_id -> CacheEntry(chain, hash)
        self._metadata_cache: Dict[
            str, CacheEntry
        ] = {}  # path -> CacheEntry(metadata, hash)

    async def execute(
        self,
        item_id: str,
        parameters: Optional[Dict[str, Any]] = None,
        validate_chain: bool = True,
        trace: bool = False,
        extra_env: Optional[Dict[str, str]] = None,
    ) -> ExecutionResult:
        """Execute a tool by resolving its executor chain recursively.

        Args:
            item_id: Tool identifier (e.g., "git", "python_runtime")
            parameters: Runtime parameters for the tool
            validate_chain: Whether to validate chain before execution
            trace: Whether to collect trace events at each decision point

        Returns:
            ExecutionResult with execution details
        """
        import time

        start_time = time.time()
        parameters = parameters or {}
        trace_events: List[Dict[str, Any]] = []

        try:
            # 1. Build the executor chain
            chain = await self._build_chain(item_id)

            if not chain:
                return ExecutionResult(
                    success=False,
                    error=f"Tool not found: {item_id}",
                    duration_ms=(time.time() - start_time) * 1000,
                    trace=trace_events if trace else [],
                )

            if trace and chain:
                for element in chain:
                    shadowed = self._find_shadowed_paths(element.item_id, element.space)
                    trace_events.append(
                        {
                            "step": "resolve",
                            "item_id": element.item_id,
                            "path": str(element.path),
                            "space": element.space,
                            "shadowed": shadowed,
                        }
                    )

            # 2. Verify integrity of every chain element
            for element in chain:
                verify_item(
                    element.path,
                    ItemType.TOOL,
                    ctx=self.ctx,
                )

            if trace:
                for element in chain:
                    content = element.path.read_text(encoding="utf-8")
                    sig_info = MetadataManager.get_signature_info(
                        ItemType.TOOL,
                        content,
                        file_path=element.path,
                        project_path=self.project_path,
                    )
                    trace_events.append(
                        {
                            "step": "verify_integrity",
                            "item_id": element.item_id,
                            "verified": True,
                            "key_fp": sig_info["pubkey_fp"] if sig_info else None,
                        }
                    )

            # 3. Validate chain if requested
            if validate_chain:
                validation = self._validate_chain(chain)
                if not validation.valid:
                    return ExecutionResult(
                        success=False,
                        error=f"Chain validation failed: {'; '.join(validation.issues)}",
                        chain=[self._chain_element_to_dict(e) for e in chain],
                        duration_ms=(time.time() - start_time) * 1000,
                    )

            # 3.5 Anchor + verify_deps
            anchor_cfg = None
            for element in chain:
                if element.anchor_config:
                    anchor_cfg = element.anchor_config
                    break

            anchor_ctx = self._compute_anchor_context(chain)
            anchor_active = False

            if anchor_cfg and self._anchor_applies(anchor_cfg, chain[0].path.parent):
                anchor_active = True
                anchor_path = self._resolve_anchor_path(anchor_cfg, anchor_ctx)
                anchor_ctx["anchor_path"] = str(anchor_path)

                # Verify all dependencies BEFORE spawn
                self._verify_tool_dependencies(chain, anchor_path)

            # 5. Resolve environment through the chain
            resolved_env = self._resolve_chain_env(chain, anchor_ctx)

            if trace:
                for element in chain:
                    if element.env_config:
                        trace_events.append(
                            {
                                "step": "resolve_env",
                                "contributed_by": element.item_id,
                                "keys": list(element.env_config.keys()),
                            }
                        )

            # 5.5 Apply anchor env mutations
            if anchor_active:
                self._apply_anchor_env(anchor_cfg, resolved_env, anchor_ctx)

            # 5.6 Apply anchor cwd if configured
            if anchor_active and anchor_cfg.get("cwd"):
                cwd = self._template_string(anchor_cfg["cwd"], anchor_ctx)
                parameters = {**(parameters or {}), "cwd": cwd}

            # 5.7 Resolve config from chain elements
            # chain[0] = tool: resolved config → parameters["resolved_config"] (for tool code)
            # chain[1:] = runtime/primitive: resolved config → execution overrides (timeout, cwd, etc.)
            tool_id = chain[0].item_id if chain else None
            for _ci, _element in enumerate(chain):
                if not _element.config_resolve:
                    continue
                _resolved = self._resolve_tool_config(_element.config_resolve)
                if not _resolved:
                    continue
                if _ci == 0:
                    parameters["resolved_config"] = _resolved
                else:
                    # Execution config: merge defaults + per-tool overrides.
                    # Only inject keys the runtime declares in execution_params
                    # (plus universal executor keys like timeout).
                    _exec_defaults = _resolved.get("defaults", {})
                    _tool_overrides = (
                        _resolved.get("tools", {}).get(tool_id, {}) if tool_id else {}
                    )
                    _exec_config = {**_exec_defaults, **_tool_overrides}
                    _UNIVERSAL_EXEC_KEYS = frozenset({"timeout"})
                    _allowed = _UNIVERSAL_EXEC_KEYS | frozenset(
                        _element.execution_params or []
                    )
                    for _ek, _ev in _exec_config.items():
                        if _ek in _allowed and _ek not in parameters:
                            parameters[_ek] = _ev

            # 6. Execute via the root primitive
            # Inject anchor context vars so {runtime_lib}, {anchor_path},
            # {tool_dir}, {tool_parent} are available for subprocess templating
            parameters = {**anchor_ctx, **(parameters or {})}
            result = await self._execute_chain(
                chain, parameters, resolved_env, extra_env=extra_env
            )

            duration_ms = (time.time() - start_time) * 1000

            return ExecutionResult(
                success=result.get("success", False),
                data=result.get("data"),
                error=result.get("error"),
                duration_ms=duration_ms,
                chain=[self._chain_element_to_dict(e) for e in chain],
                metadata={
                    "resolved_env_keys": list(resolved_env.keys()),
                },
                trace=trace_events if trace else [],
            )

        except Exception as e:
            logger.exception(f"Execution failed for {item_id}: {e}")
            return ExecutionResult(
                success=False,
                error=str(e),
                duration_ms=(time.time() - start_time) * 1000,
                trace=trace_events if trace else [],
            )

    async def _build_chain(
        self, item_id: str, force_refresh: bool = False
    ) -> List[ChainElement]:
        """Build executor chain by following __executor_id__ recursively.

        Chain is ordered: [tool, runtime, ..., primitive]
        Root of chain (last element) has executor_id = None.

        Uses hash-based caching for performance. Chain is automatically
        invalidated when any file in the chain changes.

        Args:
            item_id: Starting tool identifier
            force_refresh: Skip cache and rebuild from filesystem

        Returns:
            List of ChainElements from tool to primitive
        """
        # Check cache first (unless force refresh)
        if not force_refresh:
            cached_chain = self._get_cached_chain(item_id)
            if cached_chain is not None:
                return cached_chain

        chain: List[ChainElement] = []
        visited: set[str] = set()
        current_id = item_id
        current_space = "project"  # Start resolution from project space

        while current_id:
            # Detect chain depth limit
            if len(chain) >= MAX_CHAIN_DEPTH:
                raise ValueError(
                    f"Chain too deep (max {MAX_CHAIN_DEPTH}): {item_id}. "
                    "Possible circular dependency or excessive nesting."
                )

            # Detect circular dependencies
            if current_id in visited:
                raise ValueError(f"Circular dependency detected: {current_id}")
            visited.add(current_id)

            # Resolve tool path with precedence
            resolved = self._resolve_tool_path(current_id, current_space)
            if not resolved:
                if chain:
                    raise ValueError(f"Executor not found: {current_id}")
                return []  # Tool not found

            path, space = resolved

            # Load metadata (with caching)
            metadata = self._load_metadata_cached(path)

            element = ChainElement(
                item_id=current_id,
                path=path,
                space=space,
                tool_type=metadata.get("tool_type"),
                executor_id=metadata.get("executor_id"),
                env_config=metadata.get("env_config"),
                config_schema=metadata.get("config_schema"),
                config=metadata.get("config"),
                anchor_config=metadata.get("anchor"),
                verify_deps_config=metadata.get("verify_deps"),
                config_resolve=metadata.get("config_resolve"),
                execution_params=metadata.get("execution_params"),
            )
            chain.append(element)

            # Check if we've reached a primitive
            if element.executor_id is None:
                break

            # Move to next executor in chain
            current_id = element.executor_id
            current_space = space  # Maintain space context for resolution

        # Cache the resolved chain
        if chain:
            self._cache_chain(item_id, chain)

        return chain

    def _load_metadata_cached(self, path: Path) -> Dict[str, Any]:
        """Load metadata with hash-based caching."""
        # Check cache first
        cached = self._get_cached_metadata(path)
        if cached is not None:
            return cached

        # Cache miss - load from file
        metadata = self._load_metadata(path)

        # Cache for future access
        self._cache_metadata(path, metadata)

        return metadata

    def _resolve_tool_path(
        self, item_id: str, current_space: str = "project"
    ) -> Optional[Tuple[Path, str]]:
        """Resolve tool path by relative path ID using 3-tier space precedence.

        Resolution order: project > user > system
        Each space can shadow tools from lower-precedence spaces.

        Args:
            item_id: Relative path from .ai/tools/ without extension.
                    e.g., "rye/core/registry/registry" -> .ai/tools/rye/core/registry/registry.py
            current_space: Current tool's space (affects resolution rules)

        Returns:
            (path, space) tuple or None if not found
        """
        # Build system entries from all bundles
        system_entries = [
            (bundle.root_path / AI_DIR / "tools", f"system:{bundle.bundle_id}")
            for bundle in self.system_spaces
        ]

        # Determine search order based on current space
        if current_space == "system" or current_space.startswith("system"):
            # System tools can only depend on system tools
            search_order = system_entries
        elif current_space == "user":
            # User tools can depend on user or system tools
            search_order = [
                (self.user_space / AI_DIR / "tools", "user"),
                *system_entries,
            ]
        else:  # project
            # Project tools can depend on any space
            search_order = [
                (self.project_path / AI_DIR / "tools", "project"),
                (self.user_space / AI_DIR / "tools", "user"),
                *system_entries,
            ]

        # Get extensions data-driven from extractors
        extensions = get_tool_extensions(self.project_path)

        for base_path, space in search_order:
            if not base_path.exists():
                continue

            for ext in extensions:
                file_path = base_path / f"{item_id}{ext}"
                if file_path.is_file():
                    return (file_path, space)

        return None

    def _find_shadowed_paths(
        self, item_id: str, found_space: str
    ) -> List[Dict[str, str]]:
        """Find items in lower-precedence spaces that are shadowed by the found item."""
        system_entries = [
            (bundle.root_path / AI_DIR / "tools", f"system:{bundle.bundle_id}")
            for bundle in self.system_spaces
        ]

        all_spaces = [
            (self.project_path / AI_DIR / "tools", "project"),
            (self.user_space / AI_DIR / "tools", "user"),
            *system_entries,
        ]

        extensions = get_tool_extensions(self.project_path)
        shadowed = []
        found = False

        for base_path, space in all_spaces:
            if space == found_space:
                found = True
                continue
            if not found:
                continue
            if not base_path.exists():
                continue
            for ext in extensions:
                file_path = base_path / f"{item_id}{ext}"
                if file_path.is_file():
                    shadowed.append({"path": str(file_path), "space": space})
                    break

        return shadowed

    def _load_metadata(self, path: Path) -> Dict[str, Any]:
        """Load tool metadata from file.

        Routes parsing to data-driven parsers via ParserRouter, using the
        extension-to-parser mapping from tool_extractor.yaml.

        Args:
            path: Path to tool file

        Returns:
            Metadata dict with normalised keys (version, tool_type, etc.)
        """
        metadata: Dict[str, Any] = {}

        try:
            content = path.read_text(encoding="utf-8")

            # Data-driven: look up parser name for this extension
            parsers_map = get_parsers_map(self.project_path)
            parser_name = parsers_map.get(path.suffix)
            if not parser_name:
                return metadata

            # Route through ParserRouter (loads parser from .ai/tools/rye/core/parsers/)
            parsed = self.parser_router.parse(parser_name, content)
            if "error" in parsed:
                logger.warning(
                    "Parser %s failed for %s: %s\n"
                    "  Parser expects module-level metadata: "
                    "__version__, __tool_type__, __executor_id__",
                    parser_name,
                    path,
                    parsed["error"],
                )
                return metadata

            # Normalise parser output to metadata dict
            metadata = self._extract_metadata_from_parsed(parsed)
            if (
                metadata
                and not metadata.get("executor_id")
                and not metadata.get("tool_type")
            ):
                logger.debug(
                    "Metadata for %s missing executor_id and tool_type. "
                    "Ensure these are defined at module scope.",
                    path,
                )

        except Exception as e:
            logger.warning(f"Failed to load metadata from {path}: {e}")

        return metadata

    @staticmethod
    def _extract_metadata_from_parsed(parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata fields from parser output.

        Handles different parser output formats:
        - python/ast, javascript: keys at top level (__version__, CONFIG_SCHEMA)
        - yaml: keys under "data" sub-dict with bare names (version, config_schema)

        Uses the extraction_rules key convention: dunder keys for code parsers,
        bare keys for data parsers.
        """
        metadata: Dict[str, Any] = {}

        # Build source candidates: top-level parsed dict, plus yaml "data" sub-dict
        yaml_data = parsed.get("data")
        sources = [parsed]
        if isinstance(yaml_data, dict):
            sources.append(yaml_data)

        # Dunder → metadata field mapping (mirrors extraction_rules in extractor config)
        _DUNDER_FIELDS = {
            "__version__": "version",
            "__tool_type__": "tool_type",
            "__executor_id__": "executor_id",
            "__category__": "category",
            "__tool_description__": "tool_description",
            "__execution_owner__": "execution_owner",
            "__native_async__": "native_async",
            "__native_resume__": "native_resume",
        }

        for dunder_key, field_name in _DUNDER_FIELDS.items():
            for src in sources:
                if dunder_key in src:
                    metadata[field_name] = src[dunder_key]
                    break
                # Bare key fallback (yaml parser uses version, not __version__)
                if field_name in src:
                    metadata[field_name] = src[field_name]
                    break

        # Config/dict fields (UPPER_CASE in code parsers, lower_case in yaml)
        _CONFIG_FIELDS = {
            "CONFIG_SCHEMA": "config_schema",
            "ENV_CONFIG": "env_config",
            "CONFIG": "config",
            "CONFIG_RESOLVE": "config_resolve",
        }

        for upper_key, lower_key in _CONFIG_FIELDS.items():
            for src in sources:
                if upper_key in src:
                    metadata[lower_key] = src[upper_key]
                    break
                if lower_key in src:
                    metadata[lower_key] = src[lower_key]
                    break

        # YAML-specific top-level fields
        for key in ("anchor", "verify_deps"):
            for src in sources:
                if key in src:
                    metadata[key] = src[key]
                    break

        return metadata

    def _validate_chain(self, chain: List[ChainElement]) -> ChainValidationResult:
        """Validate executor chain using ChainValidator."""
        # Convert to format expected by ChainValidator
        chain_dicts = [self._chain_element_to_dict(e) for e in chain]
        return self.chain_validator.validate_chain(chain_dicts)

    def _chain_element_to_dict(self, element: ChainElement) -> Dict[str, Any]:
        """Convert ChainElement to dict for validation/serialization.

        Stores item_id + space (portable) instead of absolute path.
        Includes integrity hash and provider provenance for each element.
        """
        integrity = None
        try:
            content = element.path.read_text(encoding="utf-8")
            integrity = MetadataManager.compute_hash(
                ItemType.TOOL,
                content,
                file_path=element.path,
                project_path=self.project_path,
            )
        except Exception:
            pass

        result: Dict[str, Any] = {
            "item_id": element.item_id,
            "space": element.space,
            "tool_type": element.tool_type,
            "executor_id": element.executor_id,
            "integrity": integrity,
        }

        # Embed provider provenance for system-space entries
        bundle = self._get_bundle_for_space(element.space)
        if bundle:
            result["provider_id"] = bundle.bundle_id
            result["provider_version"] = bundle.version

        return result

    def _get_bundle_for_space(self, space: str) -> Optional[BundleInfo]:
        """Look up the BundleInfo for a system:bundle_id space string."""
        if not space.startswith("system:"):
            return None
        bundle_id = space.split(":", 1)[1]
        for b in self.system_spaces:
            if b.bundle_id == bundle_id:
                return b
        return None

    def _resolve_chain_env(
        self,
        chain: List[ChainElement],
        ctx: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        """Resolve environment variables through the chain.

        Each runtime in the chain can contribute ENV_CONFIG.
        Variables are resolved in order (tool → runtime → primitive).

        Args:
            chain: Executor chain
            ctx: Template context for {var} substitution in env_config values

        Returns:
            Merged resolved environment
        """
        merged_env: Dict[str, str] = {}

        # Process chain in reverse (primitive to tool) for proper override
        for element in reversed(chain):
            if element.env_config:
                env_config = element.env_config
                if ctx:
                    env_config = self._template_dict(env_config, ctx)
                resolved = self.env_resolver.resolve(
                    env_config=env_config,
                    tool_env=merged_env,
                )
                merged_env.update(resolved)

        return merged_env

    async def _execute_chain(
        self,
        chain: List[ChainElement],
        parameters: Dict[str, Any],
        resolved_env: Dict[str, str],
        extra_env: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Execute via the root element in the chain.

        Routes to Lillux primitive classes (tool_type="primitive").

        Args:
            chain: Executor chain (last element is primitive)
            parameters: Runtime parameters
            resolved_env: Resolved environment from chain

        Returns:
            Execution result dict
        """
        if not chain:
            return {"success": False, "error": "Empty chain"}

        # Get the root element (last in chain)
        root_element = chain[-1]

        if root_element.executor_id is not None:
            return {
                "success": False,
                "error": f"Chain root has executor_id: {root_element.item_id}",
            }

        # Build config from chain
        config = self._build_execution_config(chain, resolved_env, parameters)
        if extra_env:
            config.setdefault("env", {}).update(extra_env)

        # Add executor context
        config["project_path"] = str(self.project_path)
        config["user_space"] = str(self.user_space)
        config["system_space"] = str(self.system_space)

        # Handle primitives (Lillux primitive classes)
        primitive_name = root_element.item_id
        primitive = self._get_primitive(primitive_name)

        if not primitive:
            return {
                "success": False,
                "error": f"Unknown primitive: {primitive_name}",
            }

        # Execute primitive
        # All config values are available for {param} templating in args
        # This includes: tool_path, project_path, params_json, system_space,
        # user_space, and any tool config values (server_config_path, tool_name, etc.)
        enriched_params = {**config, **parameters}

        try:
            result = await primitive.execute(config, enriched_params)

            # Convert primitive result to dict
            if isinstance(result, ExecuteResult):
                # Try to parse stdout as JSON (for tool_runner output)
                error_msg = result.stderr if not result.success else None
                parsed_data = None

                if result.stdout:
                    try:
                        import json

                        parsed_data = json.loads(result.stdout)
                        # Extract error from tool output if present
                        if isinstance(parsed_data, dict):
                            if not parsed_data.get("success", True) and not error_msg:
                                error_msg = (
                                    parsed_data.get("error")
                                    or parsed_data.get("stderr")
                                    or ""
                                )
                    except json.JSONDecodeError:
                        pass

                return {
                    "success": result.success
                    and (parsed_data.get("success", True) if parsed_data else True),
                    "data": parsed_data
                    if parsed_data
                    else {
                        "stdout": result.stdout,
                        "stderr": result.stderr,
                        "return_code": result.return_code,
                    },
                    "error": error_msg,
                }
            else:
                return {"success": True, "data": result}

        except Exception as e:
            return {"success": False, "error": str(e)}

    def _get_primitive(self, name: str) -> Optional[Any]:
        """Get or create primitive instance by name."""
        if name in self._primitives:
            return self._primitives[name]

        primitive_class = self.PRIMITIVE_MAP.get(name)
        if primitive_class:
            self._primitives[name] = primitive_class()
            return self._primitives[name]

        return None

    def _build_execution_config(
        self,
        chain: List[ChainElement],
        resolved_env: Dict[str, str],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Build execution config by merging chain configs.

        Args:
            chain: Executor chain
            resolved_env: Resolved environment variables
            parameters: Runtime parameters

        Returns:
            Merged config dict for primitive execution
        """
        import json

        config: Dict[str, Any] = {}

        # Merge configs from chain (primitive first, then overrides)
        for element in reversed(chain):
            if element.config:
                config.update(element.config)

        # Merge runtime parameters (highest priority - override chain config)
        # Separate __dunder keys (non-serializable passthrough like __sinks)
        # Exclude keys that collide with primitive config (command, args, timeout, cwd)
        # — those are tool parameters that belong in params_json, not in the
        # subprocess config.  Anchor context keys are safe to merge.
        _CONFIG_KEYS = frozenset(("command", "args"))
        passthrough = {k: v for k, v in parameters.items() if k.startswith("__")}
        config.update(
            {
                k: v
                for k, v in parameters.items()
                if not k.startswith("__") and k not in _CONFIG_KEYS
            }
        )

        # Apply environment
        config["env"] = resolved_env

        # Inject execution context (generic, available for {param} templating)
        config["project_path"] = str(self.project_path)
        config["user_space"] = str(self.user_space)
        config["system_space"] = str(self.system_space)

        # Inject tool execution context for python_runtime
        # chain[0] is the tool being executed
        if chain:
            tool_element = chain[0]
            config["tool_path"] = str(tool_element.path)

            # Build params_json from parameters (excluding anchor context
            # keys, runtime routing, and non-serializable metadata)
            _EXCLUDE_FROM_PARAMS = frozenset(
                (
                    "env",
                    "tool_path",
                    "tool_dir",
                    "tool_parent",
                    "anchor_path",
                    "runtime_lib",
                    "project_path",
                    "user_space",
                    "system_space",
                    "cwd",
                    "timeout",
                    "server",
                    "tool_name",
                    "server_config_path",
                    "fixed_params",
                    "params_key",
                )
            )
            tool_params = {
                k: v
                for k, v in parameters.items()
                if k not in _EXCLUDE_FROM_PARAMS and not k.startswith("__")
            }

            # fixed_params: merge static params from tool config with
            # LLM-provided params.  Fixed params cannot be overridden.
            # If params_key is set, nest LLM params under that key
            # (e.g. "params" for MCP execute wrappers).
            fixed = config.get("fixed_params")
            if isinstance(fixed, dict):
                params_key = config.get("params_key")
                if params_key:
                    tool_params = {**fixed, params_key: tool_params}
                else:
                    overlap = fixed.keys() & tool_params.keys()
                    if overlap:
                        logger.warning(
                            "Dropping caller params that collide with fixed_params: %s",
                            sorted(overlap),
                        )
                        tool_params = {
                            k: v for k, v in tool_params.items() if k not in fixed
                        }
                    tool_params = {**tool_params, **fixed}

            config["params_json"] = json.dumps(tool_params)

        # Template substitution for ${VAR} in config values
        config = self._template_config(config, resolved_env)

        # Strip unresolved single-placeholder values from body
        # (optional provider fields like tools that weren't supplied)
        if isinstance(config.get("body"), dict):
            import re

            config["body"] = {
                k: v
                for k, v in config["body"].items()
                if not (isinstance(v, str) and re.match(r"^\{\w+\}$", v.strip()))
            }

        # Re-inject passthrough keys for primitive access
        config.update(passthrough)

        return config

    def _template_config(
        self, config: Dict[str, Any], env: Dict[str, str]
    ) -> Dict[str, Any]:
        """Substitute ${VAR} and {param} templates in config values.

        Two-pass templating:
        1. ${VAR} - environment variable substitution (with shell escaping)
        2. {param} - config value substitution (recursive until stable)
        """
        import re

        def escape_shell_value(value: Any) -> Any:
            """Escape values that will be used in shell commands."""
            if isinstance(value, str):
                # Only escape if value contains shell-special characters
                if any(
                    c in value
                    for c in [
                        "$",
                        "`",
                        ";",
                        "|",
                        "&",
                        "<",
                        ">",
                        "(",
                        ")",
                        "{",
                        "}",
                        "[",
                        "]",
                        "\\",
                    ]
                ):
                    return shlex.quote(value)
            return value

        # Env var names: uppercase letters, digits, underscores only.
        # This excludes dotted paths like ${state.issues} which belong to
        # the context interpolation system (loaders/interpolation.py).
        _ENV_VAR_RE = re.compile(r"\$\{([A-Z_][A-Z0-9_]*(?::-[^}]*)?)\}")

        def substitute_env(value: Any) -> Any:
            """Substitute ${VAR} with environment values (with escaping)."""
            if isinstance(value, str):

                def replace_var(match: re.Match[str]) -> str:
                    var_expr = match.group(1)
                    if ":-" in var_expr:
                        var_name, default = var_expr.split(":-", 1)
                        raw_value = env.get(var_name, default)
                    else:
                        raw_value = env.get(var_expr, "")
                    return str(escape_shell_value(raw_value)) if raw_value else ""

                return _ENV_VAR_RE.sub(replace_var, value)
            elif isinstance(value, dict):
                return {k: substitute_env(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [substitute_env(item) for item in value]
            return value

        def substitute_params(value: Any, params: Dict[str, Any]) -> Any:
            """Substitute {param} with config values, preserving types for single placeholders.

            When a value is exactly "{param}" (the entire string is one placeholder),
            the original typed value is returned (int, list, dict, etc.).
            When a value contains mixed text like "prefix-{param}", str() is used.
            """
            if isinstance(value, str):
                stripped = value.strip()
                single_match = re.match(r"^\{(\w+)\}$", stripped)
                if single_match:
                    param_name = single_match.group(1)
                    if param_name in params:
                        return params[param_name]
                    return value

                def replace_param(match: re.Match[str]) -> str:
                    param_name = match.group(1)
                    if param_name in params:
                        return str(params[param_name])
                    return match.group(0)

                return re.sub(r"\{([^}]+)\}", replace_param, value)
            elif isinstance(value, dict):
                return {k: substitute_params(v, params) for k, v in value.items()}
            elif isinstance(value, list):
                return [substitute_params(item, params) for item in value]
            return value

        # Pass 1: env var substitution
        result = substitute_env(config)

        # Pass 2: param substitution (iterate until stable, max 3 passes)
        for _ in range(3):
            new_result = substitute_params(result, result)
            if new_result == result:
                break
            result = new_result

        return result

    def _compute_anchor_context(self, chain: List[ChainElement]) -> Dict[str, str]:
        """Compute template variables for anchor resolution."""
        tool_element = chain[0]
        tool_dir = tool_element.path.parent

        # Resolve runtime_lib from the anchor config's lib field
        runtime_lib = ""
        for element in chain:
            if element.anchor_config and element.anchor_config.get("lib"):
                runtime_lib = str(element.path.parent / element.anchor_config["lib"])
                break

        return {
            "tool_path": str(tool_element.path),
            "tool_dir": str(tool_dir),
            "tool_parent": str(tool_dir.parent),
            "anchor_path": str(tool_dir),  # default, overridden by _resolve_anchor_path
            "runtime_lib": runtime_lib,
            "project_path": str(self.project_path),
            "user_space": str(self.user_space),
            "system_space": str(self.system_space),
        }

    def _anchor_applies(self, anchor_cfg: Dict[str, Any], tool_dir: Path) -> bool:
        """Decide whether anchor setup should activate."""
        mode = anchor_cfg.get("mode", "auto")
        if mode == "never" or not anchor_cfg.get("enabled", False):
            return False
        if mode == "always":
            return True
        # mode == "auto": check for marker files
        markers = anchor_cfg.get("markers_any", [])
        return any((tool_dir / marker).exists() for marker in markers)

    def _resolve_anchor_path(
        self, anchor_cfg: Dict[str, Any], ctx: Dict[str, str]
    ) -> Path:
        """Resolve the anchor root directory from config."""
        root = anchor_cfg.get("root", "tool_dir")
        if root == "tool_dir":
            return Path(ctx["tool_dir"])
        elif root == "tool_parent":
            return Path(ctx["tool_parent"])
        elif root == "project_path":
            return Path(ctx["project_path"])
        return Path(ctx["tool_dir"])

    def _apply_anchor_env(
        self,
        anchor_cfg: Dict[str, Any],
        resolved_env: Dict[str, str],
        ctx: Dict[str, str],
    ) -> None:
        """Mutate resolved_env with anchor path additions.

        Prepends/appends to path-like env vars using os.pathsep.
        Modifies resolved_env in place.
        """
        import os as _os

        env_paths = anchor_cfg.get("env_paths", {})
        for var_name, mutations in env_paths.items():
            existing = resolved_env.get(var_name, _os.environ.get(var_name, ""))
            parts = [p for p in existing.split(_os.pathsep) if p] if existing else []

            for path_template in reversed(mutations.get("prepend", [])):
                resolved = self._template_string(path_template, ctx)
                if resolved and resolved not in parts:
                    parts.insert(0, resolved)

            for path_template in mutations.get("append", []):
                resolved = self._template_string(path_template, ctx)
                if resolved and resolved not in parts:
                    parts.append(resolved)

            resolved_env[var_name] = _os.pathsep.join(parts)

    def _resolve_tool_config(self, config_resolve: Any) -> Dict[str, Any]:
        """Resolve config files from .ai/config/ using 3-tier cascade.

        Supports single spec (dict) or multiple specs (list of dicts).
        Each spec has:
            path: relative path under .ai/config/ (e.g., "agent/agent.yaml")
            mode: "deep_merge" (system→user→project merged) or "first_match" (first found wins)

        Single spec returns the resolved config dict directly.
        Multiple specs returns {path: config_dict} mapping.
        """
        import yaml as _yaml

        if isinstance(config_resolve, list):
            result = {}
            for spec in config_resolve:
                path = spec.get("path", "")
                result[path] = self._resolve_single_config(spec)
            return result
        elif isinstance(config_resolve, dict):
            return self._resolve_single_config(config_resolve)
        return {}

    def _verify_config_file(self, config_path: Path) -> None:
        """Verify config file integrity: warn-if-unsigned, reject-if-tampered."""
        try:
            verify_item(config_path, "config", ctx=self.ctx, allow_unsigned=True)
        except IntegrityError:
            raise
        except Exception:
            logger.warning(
                "Config integrity check failed: %s", config_path, exc_info=True
            )

    def _resolve_single_config(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve a single config file using 3-tier cascade."""
        import yaml as _yaml

        path = spec.get("path")
        if not path:
            return {}

        mode = spec.get("mode", "deep_merge")

        if mode == "deep_merge":
            # system → user → project (lowest to highest priority, all merged)
            config: Dict[str, Any] = {}

            for bundle in self.system_spaces:
                system_path = bundle.root_path / AI_DIR / "config" / path
                if system_path.exists():
                    self._verify_config_file(system_path)
                    with open(system_path) as f:
                        layer = _yaml.safe_load(f) or {}
                    config = self._deep_merge_config(config, layer)

            user_path = self.user_space / AI_DIR / "config" / path
            if user_path.exists():
                self._verify_config_file(user_path)
                with open(user_path) as f:
                    layer = _yaml.safe_load(f) or {}
                config = self._deep_merge_config(config, layer)

            project_path = self.project_path / AI_DIR / "config" / path
            if project_path.exists():
                self._verify_config_file(project_path)
                with open(project_path) as f:
                    layer = _yaml.safe_load(f) or {}
                config = self._deep_merge_config(config, layer)

            return config

        elif mode == "first_match":
            # project → user → system (first found wins)
            candidates = [
                self.project_path / AI_DIR / "config" / path,
                self.user_space / AI_DIR / "config" / path,
            ]
            for bundle in self.system_spaces:
                candidates.append(bundle.root_path / AI_DIR / "config" / path)

            for candidate in candidates:
                if candidate.exists():
                    self._verify_config_file(candidate)
                    with open(candidate) as f:
                        return _yaml.safe_load(f) or {}

        return {}

    @staticmethod
    def _deep_merge_config(base: Dict, override: Dict) -> Dict:
        """Deep merge override into base. Dicts merge recursively, else override."""
        result = dict(base)
        for key, value in override.items():
            if key == "extends":
                continue
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = PrimitiveExecutor._deep_merge_config(result[key], value)
            else:
                result[key] = value
        return result

    def _template_string(self, template: str, ctx: Dict[str, str]) -> str:
        """Substitute {var} placeholders in a template string."""
        import re

        def replace(match):
            key = match.group(1)
            return ctx.get(key, match.group(0))

        return re.sub(r"\{(\w+)\}", replace, template)

    def _template_dict(self, data: Any, ctx: Dict[str, str]) -> Any:
        """Recursively template {var} placeholders in a nested dict/list."""
        if isinstance(data, str):
            return self._template_string(data, ctx)
        elif isinstance(data, dict):
            return {k: self._template_dict(v, ctx) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._template_dict(item, ctx) for item in data]
        return data

    def _verify_tool_dependencies(
        self, chain: List[ChainElement], anchor_path: Path
    ) -> None:
        """Verify all files in the tool's dependency scope before execution.

        Walks the anchor directory tree, verifying every file matching
        configured extensions via verify_item(). Runs BEFORE subprocess spawn.

        Raises IntegrityError if any file fails verification.
        """
        import os as _os

        # Find verify_deps config from chain (runtime element)
        verify_cfg = None
        for element in chain:
            if element.verify_deps_config:
                verify_cfg = element.verify_deps_config
                break

        if not verify_cfg or not verify_cfg.get("enabled", False):
            return

        extensions = set(verify_cfg.get("extensions", []))
        exclude_dirs = set(
            verify_cfg.get(
                "exclude_dirs",
                [
                    "__pycache__",
                    ".venv",
                    "node_modules",
                    ".git",
                ],
            )
        )
        recursive = verify_cfg.get("recursive", True)

        # Determine base path from scope
        scope = verify_cfg.get("scope", "anchor")
        if scope == "tool_file":
            return  # Only the entry point — already verified in chain
        elif scope == "tool_siblings":
            base = chain[0].path.parent
            recursive = False
        elif scope == "tool_dir":
            base = chain[0].path.parent
        else:  # "anchor"
            base = anchor_path

        base = base.resolve()

        for dirpath, dirnames, filenames in _os.walk(base, followlinks=False):
            # Prune excluded directories
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs]

            if not recursive and Path(dirpath) != base:
                dirnames.clear()
                continue

            for filename in filenames:
                filepath = Path(dirpath) / filename
                if filepath.suffix not in extensions:
                    continue

                # Guard against symlink escapes
                real = filepath.resolve()
                if not str(real).startswith(str(base)):
                    raise IntegrityError(
                        f"Symlink escape: {filepath} resolves to {real}"
                    )

                verify_item(filepath, ItemType.TOOL, ctx=self.ctx)

    def _get_user_space(self) -> Path:
        """Get user space path."""
        from rye.utils.path_utils import get_user_space

        return get_user_space()

    def _get_system_spaces(self) -> List[BundleInfo]:
        """Get all system space roots (core + addon bundles)."""
        from rye.utils.path_utils import get_system_spaces

        return get_system_spaces()

    # -------------------------------------------------------------------------
    # Cache Management
    # -------------------------------------------------------------------------

    def _compute_file_hash(self, path: Path) -> str:
        """Compute SHA256 hash of file content."""
        try:
            content = path.read_bytes()
            return hashlib.sha256(content).hexdigest()
        except Exception:
            return ""

    def _get_cached_metadata(self, path: Path) -> Optional[Dict[str, Any]]:
        """Get cached metadata if file unchanged."""
        path_key = str(path)

        if path_key not in self._metadata_cache:
            return None

        cached = self._metadata_cache[path_key]
        current_hash = self._compute_file_hash(path)

        if current_hash != cached.content_hash:
            # File changed - invalidate
            del self._metadata_cache[path_key]
            return None

        return cached.data

    def _cache_metadata(self, path: Path, metadata: Dict[str, Any]) -> None:
        """Cache metadata with content hash."""
        path_key = str(path)
        content_hash = self._compute_file_hash(path)
        self._metadata_cache[path_key] = CacheEntry(
            data=metadata,
            content_hash=content_hash,
        )

    def _get_cached_chain(self, item_id: str) -> Optional[List[ChainElement]]:
        """Get cached chain if all files unchanged."""
        if item_id not in self._chain_cache:
            return None

        cached = self._chain_cache[item_id]
        chain: List[ChainElement] = cached.data

        # Verify all chain elements still have same hash
        combined_hash = self._compute_chain_hash(chain)

        if combined_hash != cached.content_hash:
            # Some file changed - invalidate
            del self._chain_cache[item_id]
            return None

        return chain

    def _cache_chain(self, item_id: str, chain: List[ChainElement]) -> None:
        """Cache chain with combined hash of all elements."""
        combined_hash = self._compute_chain_hash(chain)
        self._chain_cache[item_id] = CacheEntry(
            data=chain,
            content_hash=combined_hash,
        )

    def _compute_chain_hash(self, chain: List[ChainElement]) -> str:
        """Compute combined hash of all files in chain."""
        combined = ""
        for element in chain:
            file_hash = self._compute_file_hash(element.path)
            combined += file_hash
        return hashlib.sha256(combined.encode()).hexdigest()

    def invalidate_tool(self, item_id: str) -> None:
        """Invalidate cache for a specific tool."""
        if item_id in self._chain_cache:
            del self._chain_cache[item_id]

    def clear_caches(self) -> None:
        """Clear all caches."""
        self._chain_cache.clear()
        self._metadata_cache.clear()

    def get_cache_stats(self) -> Dict[str, int]:
        """Get cache statistics."""
        return {
            "chain_cache_size": len(self._chain_cache),
            "metadata_cache_size": len(self._metadata_cache),
        }
