"""
Post-processing optimizer for merged PDF reports.

Reduces file size by merging duplicate font subsets: when N charts each
embed their own subset of the same base font (e.g. ArialMT), this module
replaces all N copies with a single shared subset containing the union of
glyphs.  Content streams and width tables are left untouched — only the
FontFile2 stream references in FontDescriptors are redirected.

This works because Kaleido's PDF output uses CIDToGIDMap /Identity, so
every chart's CIDs map 1-to-1 to the original font's GIDs regardless of
which subset was embedded.
"""

import fitz
import io
import os
import platform
import subprocess


class MissingChartFontError(RuntimeError):
    """Raised when a font required for chart rendering is not installed."""
    pass


def optimize_pdf(pdf_path):
    """
    Optimize a PDF file in-place by merging duplicate font subsets.

    Raises MissingChartFontError if a required font cannot be located;
    the on-disk PDF is left untouched in that case.
    """
    doc = fitz.open(pdf_path)
    try:
        changed = _merge_font_subsets(doc)

        if changed:
            tmp_path = pdf_path + ".tmp"
            doc.save(
                tmp_path,
                garbage=4,
                deflate=True,
                clean=True,
                deflate_fonts=True,
                deflate_images=True,
            )
            doc.close()
            os.replace(tmp_path, pdf_path)
        else:
            doc.close()
    except MissingChartFontError:
        if not doc.is_closed:
            doc.close()
        raise


def _merge_font_subsets(doc):
    """
    Find all CIDFontType2 fonts with /Identity CIDToGIDMap, group by base
    font name, and replace per-chart subsets with a single shared master.
    """
    try:
        from fontTools.ttLib import TTFont
    except ImportError:
        print("  Warning: fontTools not installed -- skipping font optimization")
        return False

    # ---- Step 1: collect embedded fonts grouped by base name ---------------
    font_groups = {}  # base_name -> list of entry dicts
    seen_type0 = set()

    for pno in range(len(doc)):
        for font_info in doc.get_page_fonts(pno):
            type0_xref = font_info[0]
            if type0_xref in seen_type0:
                continue
            seen_type0.add(type0_xref)

            ext = font_info[1]
            name = font_info[3]

            # Accept TrueType (.ttf) fonts only — CFF/Type1 need different handling
            if ext != "ttf":
                continue

            # Extract font binary via the Type0 xref
            _, _, _, buf = doc.extract_font(type0_xref)
            if not buf:
                continue

            # Follow reference chain: Type0 -> CIDFont2 -> FontDescriptor -> FontFile2
            entry = _follow_font_chain(doc, type0_xref)
            if entry is None:
                continue

            entry["buf"] = buf

            # Strip subset prefix (e.g. "AAAAAA+ArialMT" -> "ArialMT")
            base = name.split("+", 1)[-1] if "+" in name else name
            font_groups.setdefault(base, []).append(entry)

    # ---- Step 2: merge each group that has duplicates ----------------------
    changed = False

    for base_name, entries in font_groups.items():
        if len(entries) < 2:
            continue

        # Check whether they already share the same FontFile2 xref
        unique_ff = {e["fontfile_xref"] for e in entries}
        if len(unique_ff) == 1:
            continue

        # Collect union of GIDs across all subsets
        all_gids = set()
        for entry in entries:
            all_gids.update(_extract_gids(entry["buf"], TTFont))

        if not all_gids:
            continue

        # Build the master subset. A sample subset buffer is passed to the
        # builder so it can verify that any candidate system font it finds
        # IS the same font Kaleido embedded (same family, version, metrics)
        # rather than a visually-similar substitute like DejaVu Sans —
        # retain-gids subsetting from a different font would corrupt chart
        # text. If no matching source is found, MissingChartFontError is
        # raised and the on-disk PDF is left untouched.
        sample_buf = entries[0]["buf"]
        master_buf = _build_master_subset(base_name, all_gids, sample_buf)

        # ---- Step 3: point all FontDescriptors at a single shared stream ---
        # Reuse the first entry's FontFile2 xref as the master container
        master_xref = entries[0]["fontfile_xref"]
        doc.update_stream(master_xref, master_buf)
        doc.xref_set_key(master_xref, "Length1", str(len(master_buf)))

        # Redirect all other descriptors to the shared master
        for entry in entries[1:]:
            doc.xref_set_key(
                entry["descriptor_xref"],
                "FontFile2",
                f"{master_xref} 0 R",
            )

        total_old = sum(len(e["buf"]) for e in entries)
        print(
            f"  Merged {len(entries)} '{base_name}' font subsets: "
            f"{total_old:,} -> {len(master_buf):,} bytes"
        )
        changed = True

    return changed


def _follow_font_chain(doc, type0_xref):
    """
    Follow Type0 -> DescendantFonts[0] -> FontDescriptor -> FontFile2
    and verify CIDToGIDMap is /Identity.

    Returns dict with descriptor_xref, fontfile_xref, or None on failure.
    """
    try:
        # Type0 -> DescendantFonts -> first CIDFont2
        _, desc_val = doc.xref_get_key(type0_xref, "DescendantFonts")
        cid_xref = int(desc_val.strip("[] ").split()[0])

        # Verify CIDToGIDMap /Identity
        _, cidmap_val = doc.xref_get_key(cid_xref, "CIDToGIDMap")
        if "Identity" not in cidmap_val:
            return None

        # CIDFont2 -> FontDescriptor
        _, fd_val = doc.xref_get_key(cid_xref, "FontDescriptor")
        descriptor_xref = int(fd_val.strip().split()[0])

        # FontDescriptor -> FontFile2
        _, ff_val = doc.xref_get_key(descriptor_xref, "FontFile2")
        fontfile_xref = int(ff_val.strip().split()[0])

    except (ValueError, KeyError, RuntimeError):
        return None

    return {
        "descriptor_xref": descriptor_xref,
        "fontfile_xref": fontfile_xref,
    }


# ---- GID extraction --------------------------------------------------------


def _extract_gids(buf, TTFont):
    """
    Extract the set of GIDs that carry actual glyph data in a TTF subset.

    Uses the cmap table when available (kaleido 1.x), falls back to scanning
    the glyf table for non-empty outlines (kaleido 0.x subsets that strip cmap).
    """
    gids = set()
    try:
        tt = TTFont(io.BytesIO(buf))

        # Try cmap first (fast and precise)
        cmap = tt.getBestCmap()
        if cmap:
            for glyph_name in cmap.values():
                gids.add(tt.getGlyphID(glyph_name))
        else:
            # Fallback: scan glyf table for glyphs with actual outlines
            glyf = tt.get("glyf")
            if glyf:
                for gid, name in enumerate(tt.getGlyphOrder()):
                    g = glyf[name]
                    # numberOfContours > 0 = simple glyph, -1 = composite
                    if g.numberOfContours != 0:
                        gids.add(gid)

        tt.close()
    except Exception:
        pass
    return gids


# ---- Master subset builder ------------------------------------------------

# PostScript font name (as it appears in the embedded PDF font object)
# -> list of candidate filenames that are *the same font* on disk.
#
# Critical: entries under a given key must all be the same font family (by
# identity), just with different naming conventions across platforms.  We
# must NEVER list visually-similar substitutes here — e.g. DejaVu Sans must
# not be listed as a fallback for ArialMT, because their internal GID
# layouts are different, and retain-gids subsetting would silently corrupt
# chart text.  A runtime identity check (_source_matches_subset) also
# enforces this.
_SYSTEM_FONT_MAP = {
    # Microsoft Arial — Windows ships arial.ttf; ttf-mscorefonts-installer
    # on Debian/Ubuntu puts it at Arial.ttf (under msttcorefonts/ or TTF/);
    # the recursive walk is case-insensitive.
    "ArialMT":              ["arial.ttf", "Arial.ttf"],
    "Arial-BoldMT":         ["arialbd.ttf", "Arial Bold.ttf", "Arial-Bold.ttf"],
    "Arial-ItalicMT":       ["ariali.ttf", "Arial Italic.ttf", "Arial-Italic.ttf"],
    "Arial-BoldItalicMT":   ["arialbi.ttf", "Arial Bold Italic.ttf", "Arial-BoldItalic.ttf"],

    # Red Hat Liberation Sans.
    "LiberationSans":            ["LiberationSans-Regular.ttf"],
    "LiberationSans-Bold":       ["LiberationSans-Bold.ttf"],
    "LiberationSans-Italic":     ["LiberationSans-Italic.ttf"],
    "LiberationSans-BoldItalic": ["LiberationSans-BoldItalic.ttf"],

    # DejaVu Sans (common Linux default sans — the fallback fontconfig
    # returns when nothing better is installed).
    "DejaVuSans":           ["DejaVuSans.ttf"],
    "DejaVuSans-Bold":      ["DejaVuSans-Bold.ttf"],
    "DejaVuSans-Oblique":   ["DejaVuSans-Oblique.ttf"],
}


def _font_search_dirs():
    """Return the list of directories to walk when looking up a font by filename."""
    system = platform.system()

    if system == "Windows":
        return [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")]

    if system == "Darwin":
        return [
            "/System/Library/Fonts",
            "/System/Library/Fonts/Supplemental",
            "/Library/Fonts",
            os.path.expanduser("~/Library/Fonts"),
        ]

    # Linux / *BSD / other
    return [
        "/usr/share/fonts",
        "/usr/local/share/fonts",
        "/usr/share/fonts/truetype",
        "/usr/share/fonts/opentype",
        os.path.expanduser("~/.fonts"),
        os.path.expanduser("~/.local/share/fonts"),
    ]


def _walk_for_font(filenames):
    """Recursively scan font directories for any of *filenames* (case-insensitive)."""
    wanted = {f.lower() for f in filenames}
    for root_dir in _font_search_dirs():
        if not os.path.isdir(root_dir):
            continue
        for dirpath, _dirnames, files in os.walk(root_dir):
            for fname in files:
                if fname.lower() in wanted:
                    return os.path.join(dirpath, fname)
    return None


def _fc_match(base_name):
    """
    Ask fontconfig (Linux/macOS) for the best match for a PostScript font name.
    Returns the resolved file path, or None if fc-match is unavailable or the
    result points to a file whose extension we can't subset.
    """
    if platform.system() == "Windows":
        return None
    try:
        result = subprocess.run(
            ["fc-match", "-f", "%{file}", base_name],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None

    path = (result.stdout or "").strip()
    if not path or not os.path.exists(path):
        return None
    # fontTools can subset .ttf / .otf — skip anything else (e.g. .pfb)
    if not path.lower().endswith((".ttf", ".otf", ".ttc")):
        return None
    return path


def _find_system_font_candidates(base_name):
    """
    Yield candidate full-font paths for *base_name* in priority order.

    Order:
      1. Filenames from _SYSTEM_FONT_MAP, walked case-insensitively through
         platform font directories.
      2. fontconfig (fc-match) on non-Windows — catches names we don't have
         hard-coded and whatever substitute the host system prefers.

    Each candidate must still pass the identity check in
    _source_matches_subset before it can be trusted.
    """
    seen = set()

    filenames = _SYSTEM_FONT_MAP.get(base_name) or []
    if filenames:
        path = _walk_for_font(filenames)
        if path and path not in seen:
            seen.add(path)
            yield path

    fc_path = _fc_match(base_name)
    if fc_path and fc_path not in seen:
        seen.add(fc_path)
        yield fc_path


def _subset_metadata(buf_or_path):
    """
    Extract identity metadata from a TTF (either in-memory bytes or a file
    path). Returns a dict of fields that survive retain-gids subsetting,
    or None if the font can't be parsed.
    """
    from fontTools.ttLib import TTFont

    try:
        if isinstance(buf_or_path, (bytes, bytearray)):
            tt = TTFont(io.BytesIO(buf_or_path))
        else:
            tt = TTFont(buf_or_path)
    except Exception:
        return None

    try:
        meta = {
            "unitsPerEm":   tt["head"].unitsPerEm,
            "fontRevision": round(tt["head"].fontRevision, 4),
            "macStyle":     tt["head"].macStyle,
            "ascender":     tt["hhea"].ascender,
            "descender":    tt["hhea"].descender,
            "family_name":  None,
        }
        if "name" in tt:
            n1 = tt["name"].getName(1, 3, 1, 1033) or tt["name"].getName(1, 1, 0)
            if n1:
                try:
                    meta["family_name"] = n1.toUnicode()
                except Exception:
                    pass
        if "OS/2" in tt:
            meta["os2_xAvgCharWidth"] = tt["OS/2"].xAvgCharWidth
        return meta
    finally:
        tt.close()


def _source_matches_subset(source_path, sample_subset_buf):
    """
    Return True iff *source_path* points at the same font (same family,
    same version, same metrics) that Kaleido embedded as *sample_subset_buf*.

    Uses metadata that is preserved through retain-gids subsetting (name
    table family name, fontRevision, unitsPerEm, ascender/descender,
    OS/2 xAvgCharWidth) — NOT glyph bytes, because fontTools rewrites
    those on save.

    A mismatch here means the host system has a DIFFERENT font than the
    one originally embedded in the PDF (e.g. DejaVu installed locally
    while the PDF's "ArialMT" is real Arial), and using the local one as
    a subsetting source would corrupt chart text.
    """
    src_meta = _subset_metadata(source_path)
    sub_meta = _subset_metadata(sample_subset_buf)
    if src_meta is None or sub_meta is None:
        return False

    # Family name is the strongest signal. Subsets preserve it verbatim.
    if src_meta["family_name"] and sub_meta["family_name"]:
        if src_meta["family_name"] != sub_meta["family_name"]:
            return False

    # Metric identity — cheap but strict: two different fonts essentially
    # never share all of these exactly.
    for key in ("unitsPerEm", "ascender", "descender", "macStyle"):
        if src_meta.get(key) != sub_meta.get(key):
            return False

    # xAvgCharWidth is a useful tie-breaker between same-family fonts of
    # different weights, and between Arial and Liberation Sans.
    if "os2_xAvgCharWidth" in src_meta and "os2_xAvgCharWidth" in sub_meta:
        if src_meta["os2_xAvgCharWidth"] != sub_meta["os2_xAvgCharWidth"]:
            return False

    # Font revision should match exactly; minor releases can tweak glyph
    # outlines, which would poison a retain-gids master.
    if src_meta["fontRevision"] != sub_meta["fontRevision"]:
        return False

    return True


def _build_master_subset(base_name, gids, sample_subset_buf):
    """
    Build a single TTF containing the union of *gids*, using retain-gids
    so that GID indices match the original font (required by /Identity
    CIDToGIDMap).

    A valid master can only be built from a full source font that is a
    superset of every per-chart subset AND byte-compatible with what
    Kaleido originally embedded. If no such source can be located, we
    raise MissingChartFontError. We never fall back to one of the
    subsets (that would drop glyphs from sibling charts), and we never
    fall back to a visually-similar font (its GID layout wouldn't match).
    """
    for candidate in _find_system_font_candidates(base_name):
        if not _source_matches_subset(candidate, sample_subset_buf):
            continue
        try:
            return _subset_from_source(candidate, gids)
        except Exception:
            continue

    raise MissingChartFontError(
        f"Missing font '{base_name}' that is required for charts."
    )


def _subset_from_source(font_path, gids):
    """Subset a full font to the given GIDs with retain-gids."""
    from fontTools.ttLib import TTFont
    from fontTools.subset import Subsetter, Options

    tt = TTFont(font_path)

    options = Options()
    options.retain_gids = True
    # Drop tables that aren't needed for chart text rendering
    options.drop_tables += ["DSIG", "GPOS", "GSUB", "kern", "morx", "GDEF"]

    subsetter = Subsetter(options=options)
    subsetter.populate(gids=gids)
    subsetter.subset(tt)

    buf = io.BytesIO()
    tt.save(buf)
    tt.close()
    return buf.getvalue()
