"""Batch=1 decode profiler.

Attributes per-step time across attention / mlp / sampling / python_overhead.
Runs one uninstrumented pass for the true tok/s, then one instrumented pass for
fractions. Writes a Markdown report to `benchmarks/`.

Usage:
    python -m vllm_mlx.profiling --model mlx-community/Qwen3-0.6B-8bit

See docs/plans/2026-04-18-decode-profiler-design.md for rationale.
"""

from __future__ import annotations

import argparse
import os
import platform
import re
import statistics
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

import mlx.core as mx
import mlx.nn as nn


# The 10 canned prompts from vllm_mlx/benchmark.py — kept verbatim so fractions
# here are comparable with the published tok/s baselines.
PROMPTS: list[str] = [
    "Hello, how are you?",
    "What is 2+2?",
    "Say hello in Spanish.",
    (
        "What is the capital of France and why is it historically significant? "
        "Include some interesting facts about the city."
    ),
    (
        "Write a Python function to calculate fibonacci numbers using memoization. "
        "Explain how it works."
    ),
    (
        "Explain the difference between a list and a tuple in Python. "
        "When should you use each one?"
    ),
    (
        "Explain quantum computing in detail. Cover qubits, superposition, "
        "entanglement, applications in cryptography and drug discovery, and "
        "current hardware limitations. Be thorough."
    ),
    (
        "Write a comprehensive guide to building a REST API with Python Flask. "
        "Cover project structure, routes, JSON validation, JWT authentication, "
        "error handling, testing with pytest, and Swagger docs."
    ),
    (
        "Describe photosynthesis in detail. Cover light-dependent reactions in "
        "thylakoid membranes, the Calvin cycle, chlorophyll pigments, and how "
        "environmental factors affect the rate."
    ),
    (
        "Design a complete microservices architecture for a large e-commerce "
        "platform. Cover service breakdown, database choices per service, "
        "inter-service communication, caching, and observability."
    ),
]

WARMUP_TOKENS = 5


# ---------------------------------------------------------------------------
# Per-step accumulator
# ---------------------------------------------------------------------------


@dataclass
class StepAccumulator:
    """Accumulates component timings for decode steps (post-warmup)."""

    attention_s: list[float] = field(default_factory=list)
    mlp_s: list[float] = field(default_factory=list)
    sampling_s: list[float] = field(default_factory=list)
    total_s: list[float] = field(default_factory=list)

    # Per-step scratchpad; reset each step.
    _attn_step: float = 0.0
    _mlp_step: float = 0.0
    _sampling_step: float = 0.0

    def reset_step(self) -> None:
        self._attn_step = 0.0
        self._mlp_step = 0.0
        self._sampling_step = 0.0

    def add_attention(self, dt: float) -> None:
        self._attn_step += dt

    def add_mlp(self, dt: float) -> None:
        self._mlp_step += dt

    def add_sampling(self, dt: float) -> None:
        self._sampling_step += dt

    def commit_step(self, total_dt: float) -> None:
        self.attention_s.append(self._attn_step)
        self.mlp_s.append(self._mlp_step)
        self.sampling_s.append(self._sampling_step)
        self.total_s.append(total_dt)


# ---------------------------------------------------------------------------
# Instrumentation — wrap the child module at the parent's attribute level
# ---------------------------------------------------------------------------
#
# Why not monkey-patch __call__ on the module instance? Python looks up dunder
# methods on the class, not the instance, so `mod.__call__ = fn` is ignored by
# `mod(x)`. Instead we replace the child attribute on the parent layer with a
# tiny callable wrapper that forwards to the original module and records wall
# time (after forcing mx.eval() so async dispatch is flushed into the bucket
# we're attributing time to).
#
# mlx.nn.Module is a dict subclass. Its __setattr__ stores dict/list/tuple/array
# values inside the dict (so they show up in .parameters()) and puts anything
# else as a normal attribute (while popping the dict entry). Our wrapper object
# is not a dict, so it lands as a normal attribute — attribute access finds it
# first, .parameters() no longer sees the attention/mlp weights but that's fine
# during a pure forward pass: the original module still holds the weights and
# we call through it. We restore originals after each run.


class _TimedChild:
    """Forward-callable that times `inner(*args, **kwargs)` and mx.eval()s."""

    __slots__ = ("_inner", "_record")

    def __init__(self, inner: Any, record: Callable[[float], None]):
        self._inner = inner
        self._record = record

    def __call__(self, *args, **kwargs):
        t0 = time.perf_counter()
        out = self._inner(*args, **kwargs)
        mx.eval(out)
        self._record(time.perf_counter() - t0)
        return out


def _install_instrumentation(
    model: nn.Module, acc: StepAccumulator
) -> list[tuple[Any, str, Any]]:
    """Wrap every layer's self_attn and mlp.

    Returns a list of (parent, attr_name, original_child) tuples for later
    restoration.
    """
    originals: list[tuple[Any, str, Any]] = []
    layers = model.model.layers  # shape: list of TransformerBlock-like modules
    for layer in layers:
        if hasattr(layer, "self_attn"):
            original = layer.self_attn
            originals.append((layer, "self_attn", original))
            layer.self_attn = _TimedChild(original, acc.add_attention)
        if hasattr(layer, "mlp"):
            original = layer.mlp
            originals.append((layer, "mlp", original))
            layer.mlp = _TimedChild(original, acc.add_mlp)
    return originals


def _restore(originals: list[tuple[Any, str, Any]]) -> None:
    for parent, attr, original in originals:
        setattr(parent, attr, original)


def _make_timed_sampler(acc: StepAccumulator) -> Callable[[mx.array], mx.array]:
    """Sampler that mirrors mlx-lm's default (argmax over logprobs)."""

    def sampler(logprobs: mx.array) -> mx.array:
        t0 = time.perf_counter()
        out = mx.argmax(logprobs, axis=-1)
        mx.eval(out)
        acc.add_sampling(time.perf_counter() - t0)
        return out

    return sampler


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


@dataclass
class PromptResult:
    prompt_tokens: int
    decode_tokens: int
    prefill_s: float
    decode_wall_s: float
    tokens_per_sec: float  # decode only
    acc: Optional[StepAccumulator] = None  # only in instrumented runs
    token_ids: Optional[list[int]] = None  # only when collect_tokens=True


def _as_int(tok: Any) -> int:
    """generate_step may yield a Python int or a scalar mx.array depending on
    the mlx-lm version; normalise to int."""
    if isinstance(tok, int):
        return tok
    if hasattr(tok, "item"):
        return int(tok.item())
    return int(tok)


def _tokenize(tokenizer, prompt: str) -> mx.array:
    """Apply chat template when available, else encode raw."""
    if hasattr(tokenizer, "apply_chat_template"):
        messages = [{"role": "user", "content": prompt}]
        try:
            tokens = tokenizer.apply_chat_template(
                messages, add_generation_prompt=True
            )
        except Exception:
            tokens = None
        if tokens is not None:
            if isinstance(tokens, str):
                tokens = tokenizer.encode(tokens)
            return mx.array(tokens)
    return mx.array(tokenizer.encode(prompt))


def _run_prompt(
    model: nn.Module,
    tokenizer,
    prompt: str,
    max_tokens: int,
    sampler: Optional[Callable[[mx.array], mx.array]],
    acc: Optional[StepAccumulator],
    kv_bits: Optional[int] = None,
    kv_group_size: int = 64,
    kv_start: int = 0,
    collect_tokens: bool = False,
) -> PromptResult:
    """Run one prompt. `acc` is None for the baseline (uninstrumented) pass.

    kv_bits/kv_group_size/kv_start are forwarded to mlx_lm.generate_step so the
    active decode cache is quantized in-place once offset >= kv_start.
    collect_tokens=True captures the decoded token ids for parity checks.
    """
    from mlx_lm.generate import generate_step

    prompt_arr = _tokenize(tokenizer, prompt)
    prompt_len = int(prompt_arr.size)

    gen_kwargs: dict[str, Any] = {"max_tokens": max_tokens}
    if sampler is not None:
        gen_kwargs["sampler"] = sampler
    if kv_bits is not None:
        gen_kwargs["kv_bits"] = kv_bits
        gen_kwargs["kv_group_size"] = kv_group_size
        gen_kwargs["quantized_kv_start"] = kv_start
    it = generate_step(prompt_arr, model, **gen_kwargs)

    captured: list[int] = [] if collect_tokens else None  # type: ignore[assignment]

    # First iteration includes prefill + first decoded token.
    t0 = time.perf_counter()
    try:
        first_token, _ = next(it)
    except StopIteration:
        return PromptResult(prompt_len, 0, 0.0, 0.0, float("nan"), acc, captured)
    mx.eval(first_token)
    prefill_s = time.perf_counter() - t0
    if captured is not None:
        captured.append(_as_int(first_token))
    if acc is not None:
        # Don't count prefill components in decode-step fractions.
        acc.reset_step()

    decode_count = 1  # the first_token already counts as one decoded token
    decode_wall_start = time.perf_counter()
    step_idx = 0  # decode steps AFTER the prefill step

    while decode_count < max_tokens:
        step_start = time.perf_counter()
        try:
            tok, _ = next(it)
        except StopIteration:
            break
        mx.eval(tok)
        step_total = time.perf_counter() - step_start

        if captured is not None:
            captured.append(_as_int(tok))
        if acc is not None:
            if step_idx >= WARMUP_TOKENS:
                acc.commit_step(step_total)
            acc.reset_step()

        decode_count += 1
        step_idx += 1

    decode_wall_s = time.perf_counter() - decode_wall_start
    # decode_count - 1 because the first token came from the prefill iteration.
    decode_only = max(decode_count - 1, 0)
    tokens_per_sec = (
        decode_only / decode_wall_s if decode_wall_s > 0 else float("nan")
    )
    return PromptResult(
        prompt_tokens=prompt_len,
        decode_tokens=decode_only,
        prefill_s=prefill_s,
        decode_wall_s=decode_wall_s,
        tokens_per_sec=tokens_per_sec,
        acc=acc,
        token_ids=captured,
    )


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------


def _summarize(results: list[PromptResult]) -> dict:
    tok_per_s = [r.tokens_per_sec for r in results if r.decode_tokens > 0]
    prefill_ms = [r.prefill_s * 1000 for r in results]
    return {
        "n_prompts": len(results),
        "tok_per_s_mean": statistics.mean(tok_per_s) if tok_per_s else 0.0,
        "tok_per_s_median": statistics.median(tok_per_s) if tok_per_s else 0.0,
        "prefill_ms_mean": statistics.mean(prefill_ms) if prefill_ms else 0.0,
        "total_decode_tokens": sum(r.decode_tokens for r in results),
    }


def _fractions(results: list[PromptResult]) -> dict:
    """Build per-step stats from the instrumented run.

    The raw fractions are not directly faithful to baseline decode: each wrapper
    adds an `mx.eval()` sync so `attention`, `mlp`, and `sampling` buckets are
    inflated by the sync cost. `python_overhead` is the one bucket that is NOT
    instrumented, so its absolute time-per-step carries over unchanged between
    instrumented and baseline runs. That makes it the cleanest metric to
    actionize.
    """
    attn = mlp = samp = tot = 0.0
    n_steps = 0
    for r in results:
        if r.acc is None:
            continue
        attn += sum(r.acc.attention_s)
        mlp += sum(r.acc.mlp_s)
        samp += sum(r.acc.sampling_s)
        tot += sum(r.acc.total_s)
        n_steps += len(r.acc.total_s)
    if tot == 0.0 or n_steps == 0:
        return {
            "attention_frac": 0.0,
            "mlp_frac": 0.0,
            "sampling_frac": 0.0,
            "python_overhead_frac": 0.0,
            "attention_ms_per_step": 0.0,
            "mlp_ms_per_step": 0.0,
            "sampling_ms_per_step": 0.0,
            "python_overhead_ms_per_step": 0.0,
            "step_total_ms_instrumented": 0.0,
            "total_s": 0.0,
            "n_steps": 0,
        }
    other = max(tot - (attn + mlp + samp), 0.0)
    return {
        # Raw instrumented fractions (over-weight attention/mlp due to sync cost).
        "attention_frac": attn / tot,
        "mlp_frac": mlp / tot,
        "sampling_frac": samp / tot,
        "python_overhead_frac": other / tot,
        # Absolute ms/step in the instrumented run. python_overhead_ms_per_step
        # is the one number that transfers cleanly to baseline.
        "attention_ms_per_step": (attn / n_steps) * 1000,
        "mlp_ms_per_step": (mlp / n_steps) * 1000,
        "sampling_ms_per_step": (samp / n_steps) * 1000,
        "python_overhead_ms_per_step": (other / n_steps) * 1000,
        "step_total_ms_instrumented": (tot / n_steps) * 1000,
        "total_s": tot,
        "n_steps": n_steps,
    }


def _detect_hw() -> str:
    try:
        out = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"], text=True
        ).strip()
    except Exception:
        out = platform.processor() or "unknown"
    return out


def _sanitize(model_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", model_id).strip("_")


def _write_report(
    path: Path,
    *,
    model_id: str,
    hw: str,
    baseline: dict,
    instrumented: dict,
    fractions: dict,
    prompts_used: int,
    decode_tokens: int,
    warmup: int,
) -> None:
    def pct(x: float) -> str:
        return f"{x * 100:5.1f}%"

    baseline_tok_s = baseline["tok_per_s_mean"]
    baseline_ms_per_step = 1000.0 / baseline_tok_s if baseline_tok_s > 0 else 0.0

    # The one faithful transfer: python_overhead is not instrumented (no extra
    # mx.eval), so its absolute time per step is identical between runs.
    python_ms_in_baseline = fractions["python_overhead_ms_per_step"]
    python_frac_in_baseline = (
        python_ms_in_baseline / baseline_ms_per_step
        if baseline_ms_per_step > 0
        else 0.0
    )

    instrumentation_overhead_ratio = (
        (instrumented["tok_per_s_mean"] / baseline_tok_s) if baseline_tok_s > 0 else 0.0
    )

    lines = [
        f"# Decode profile — {model_id}",
        "",
        f"- **Date:** {time.strftime('%Y-%m-%d %H:%M %Z')}",
        f"- **Hardware:** {hw}",
        f"- **Prompts:** {prompts_used} (canned from `vllm_mlx/benchmark.py`)",
        f"- **Decode tokens / prompt (cap):** {decode_tokens}  |  warm-up discarded: {warmup}",
        f"- **Decode steps used for fractions:** {fractions['n_steps']}",
        "",
        "## Throughput",
        "",
        "| Run | tok/s (mean) | tok/s (median) | prefill ms (mean) |",
        "|---|---:|---:|---:|",
        (
            f"| Baseline (no instrumentation) | {baseline['tok_per_s_mean']:.1f} | "
            f"{baseline['tok_per_s_median']:.1f} | {baseline['prefill_ms_mean']:.1f} |"
        ),
        (
            f"| Instrumented                  | {instrumented['tok_per_s_mean']:.1f} | "
            f"{instrumented['tok_per_s_median']:.1f} | {instrumented['prefill_ms_mean']:.1f} |"
        ),
        "",
        f"Baseline step time: **{baseline_ms_per_step:.2f} ms/token** "
        f"(that's the real number).  "
        f"Instrumented is {instrumentation_overhead_ratio * 100:.0f}% of baseline.",
        "",
        "## The one faithful metric: python overhead per step",
        "",
        "Because Python glue between component calls is NOT instrumented, its "
        "absolute ms/step carries over to baseline unchanged. This is the "
        "cleanest number to decide whether Fase 1.5 (MLX-native sampling + "
        "`mx.async_eval`) pays off for this size class.",
        "",
        f"- **python_overhead: {python_ms_in_baseline:.3f} ms/step**",
        f"- That is **{python_frac_in_baseline * 100:.1f}% of real baseline "
        f"step time** ({baseline_ms_per_step:.2f} ms/step).",
        "",
        "## Raw per-component times (instrumented run)",
        "",
        "These include the per-component `mx.eval()` sync cost we added, so the "
        "**absolute ms for attention / mlp / sampling are inflated** relative "
        "to baseline. The ratio between attention and mlp is also distorted "
        "(both get the same number of extra syncs per layer). Use these for "
        "ordering intuition only; use the python number above for decisions.",
        "",
        "| Component | Instrumented ms/step | Fraction of instrumented step |",
        "|---|---:|---:|",
        f"| attention (all layers) | {fractions['attention_ms_per_step']:.3f} | {pct(fractions['attention_frac'])} |",
        f"| mlp (all layers)       | {fractions['mlp_ms_per_step']:.3f} | {pct(fractions['mlp_frac'])} |",
        f"| sampling               | {fractions['sampling_ms_per_step']:.3f} | {pct(fractions['sampling_frac'])} |",
        f"| python_overhead        | {fractions['python_overhead_ms_per_step']:.3f} | {pct(fractions['python_overhead_frac'])} |",
        f"| **total (instrumented)** | **{fractions['step_total_ms_instrumented']:.3f}** | 100.0% |",
        "",
        "## How to read this",
        "",
        "- **python_overhead ≥ 20% of real step time** → Fase 1.5 (MLX-native "
        "sampling + `mx.async_eval`) is very likely to pay off.",
        "- **python_overhead ≤ 5% of real step time** → Python-level work won't "
        "meaningfully move tok/s for this model class; gains must come from "
        "quantization or kernels.",
        "- **Attention:MLP ratio** (in instrumented ms/step): dominant side "
        "tells you where raw compute lives. Paged Metal kernel (Fase 1.1+) "
        "helps attention, especially beyond batch=1.",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def profile_model(
    model_id: str,
    *,
    n_prompts: int,
    max_tokens: int,
    output_dir: Path,
    kv_bits: Optional[int] = None,
    kv_group_size: int = 64,
    kv_start: int = 0,
    skip_instrumented: bool = False,
) -> Path:
    from mlx_lm import load as mlx_lm_load

    print(f"[profiler] loading {model_id} …", flush=True)
    model, tokenizer = mlx_lm_load(model_id)

    prompts = PROMPTS[:n_prompts]
    kv_label = (
        f"kv_bits={kv_bits} group_size={kv_group_size} start={kv_start}"
        if kv_bits is not None
        else "kv_bits=None (full precision)"
    )
    print(f"[profiler] kv config: {kv_label}", flush=True)

    # Capture the first prompt's token ids on every run so callers can
    # compare across kv_bits settings for a sanity parity check.
    print(f"[profiler] baseline pass over {len(prompts)} prompts …", flush=True)
    baseline_results: list[PromptResult] = []
    for i, p in enumerate(prompts):
        r = _run_prompt(
            model,
            tokenizer,
            p,
            max_tokens,
            sampler=None,
            acc=None,
            kv_bits=kv_bits,
            kv_group_size=kv_group_size,
            kv_start=kv_start,
            collect_tokens=(i == 0),
        )
        print(
            f"  [{i + 1}/{len(prompts)}] {r.decode_tokens:4d} tok "
            f"@ {r.tokens_per_sec:6.1f} tok/s (prefill {r.prefill_s * 1000:.1f} ms)",
            flush=True,
        )
        baseline_results.append(r)
    baseline_summary = _summarize(baseline_results)

    if skip_instrumented:
        instrumented_summary = {
            "n_prompts": 0,
            "tok_per_s_mean": 0.0,
            "tok_per_s_median": 0.0,
            "prefill_ms_mean": 0.0,
            "total_decode_tokens": 0,
        }
        fractions = _fractions([])
    else:
        print("[profiler] instrumented pass …", flush=True)
        instrumented_results: list[PromptResult] = []
        for i, p in enumerate(prompts):
            acc = StepAccumulator()
            originals = _install_instrumentation(model, acc)
            sampler = _make_timed_sampler(acc)
            try:
                r = _run_prompt(
                    model,
                    tokenizer,
                    p,
                    max_tokens,
                    sampler=sampler,
                    acc=acc,
                    kv_bits=kv_bits,
                    kv_group_size=kv_group_size,
                    kv_start=kv_start,
                )
            finally:
                _restore(originals)
            print(
                f"  [{i + 1}/{len(prompts)}] {r.decode_tokens:4d} tok "
                f"@ {r.tokens_per_sec:6.1f} tok/s",
                flush=True,
            )
            instrumented_results.append(r)
        instrumented_summary = _summarize(instrumented_results)
        fractions = _fractions(instrumented_results)

    kv_tag = f"_kv{kv_bits}" if kv_bits is not None else "_kvfp"
    out_path = (
        output_dir
        / f"profile_{_sanitize(model_id)}{kv_tag}_{time.strftime('%Y%m%d')}.md"
    )
    _write_report(
        out_path,
        model_id=model_id,
        hw=_detect_hw(),
        baseline=baseline_summary,
        instrumented=instrumented_summary,
        fractions=fractions,
        prompts_used=len(prompts),
        decode_tokens=max_tokens,
        warmup=WARMUP_TOKENS,
    )
    print(f"[profiler] wrote {out_path}", flush=True)

    print()
    print(f"=== {model_id}  [{kv_label}] ===")
    bl = baseline_summary["tok_per_s_mean"]
    bl_ms = 1000.0 / bl if bl > 0 else 0.0
    print(f"baseline                : {bl:7.1f} tok/s  ({bl_ms:5.2f} ms/token)")
    if not skip_instrumented:
        py_ms = fractions["python_overhead_ms_per_step"]
        py_frac_real = py_ms / bl_ms if bl_ms > 0 else 0.0
        print(
            f"instrumented            : {instrumented_summary['tok_per_s_mean']:7.1f} tok/s"
        )
        print(f"python_ovhd (absolute)  : {py_ms:6.3f} ms/step")
        print(
            f"python_ovhd / baseline  : {py_frac_real * 100:5.1f}%   ← key signal"
        )
        print(f"attn ms/step (inflated) : {fractions['attention_ms_per_step']:6.3f}")
        print(f"mlp  ms/step (inflated) : {fractions['mlp_ms_per_step']:6.3f}")
        print(f"samp ms/step (inflated) : {fractions['sampling_ms_per_step']:6.3f}")
    first_prompt_tokens = (
        baseline_results[0].token_ids if baseline_results else None
    )
    if first_prompt_tokens:
        preview_n = min(20, len(first_prompt_tokens))
        print(
            f"first-prompt tok ids (baseline, first {preview_n}): "
            f"{first_prompt_tokens[:preview_n]}"
        )
    print()

    return out_path


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="python -m vllm_mlx.profiling",
        description="Batch=1 decode time attribution per component.",
    )
    ap.add_argument("--model", required=True, help="HF model id")
    ap.add_argument("--prompts", type=int, default=10)
    ap.add_argument("--tokens", type=int, default=100)
    ap.add_argument("--output-dir", default="benchmarks")
    ap.add_argument(
        "--kv-bits",
        type=int,
        default=None,
        choices=[4, 8],
        help="Quantize the active decode KV cache to N bits (mlx-lm "
        "generate_step semantics). Default: full precision.",
    )
    ap.add_argument("--kv-group-size", type=int, default=64)
    ap.add_argument(
        "--kv-start",
        type=int,
        default=0,
        help="Token offset at which to start quantizing (protects first N "
        "tokens). Default: 0.",
    )
    ap.add_argument(
        "--skip-instrumented",
        action="store_true",
        help="Skip the instrumented (per-component) pass. Faster when "
        "sweeping knobs and only tok/s matters.",
    )
    args = ap.parse_args(argv)

    if args.prompts < 1 or args.prompts > len(PROMPTS):
        print(f"--prompts must be in [1, {len(PROMPTS)}]", file=sys.stderr)
        return 2
    if args.tokens <= WARMUP_TOKENS:
        print(f"--tokens must be > {WARMUP_TOKENS}", file=sys.stderr)
        return 2

    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    profile_model(
        args.model,
        n_prompts=args.prompts,
        max_tokens=args.tokens,
        output_dir=Path(args.output_dir),
        kv_bits=args.kv_bits,
        kv_group_size=args.kv_group_size,
        kv_start=args.kv_start,
        skip_instrumented=args.skip_instrumented,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
