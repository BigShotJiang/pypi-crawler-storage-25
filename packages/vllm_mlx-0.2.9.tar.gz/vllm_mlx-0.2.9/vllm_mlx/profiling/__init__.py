"""Diagnostic profilers for vllm-mlx.

Currently ships:
- decode_profiler: per-component time attribution for batch=1 decode.
  Informs Fase 1.5 (Python hot-path) priorities.
"""
