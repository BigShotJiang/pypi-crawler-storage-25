from vllm_mlx.profiling.decode_profiler import main

if __name__ == "__main__":
    raise SystemExit(main())
