"""Tests for the MoE top_k override."""

from __future__ import annotations

import pytest

from vllm_mlx.scheduler import (
    SchedulerConfig,
    apply_moe_top_k_override,
)


class _FakeMoEBlock:
    def __init__(self, top_k: int = 8):
        self.top_k = top_k

    @property
    def switch_mlp(self):
        return object()  # presence is all apply_moe_top_k_override checks


class _FakeDenseMLP:
    def __init__(self):
        pass  # No top_k, no switch_mlp — must be skipped.


class _FakeLayer:
    def __init__(self, mlp):
        self.mlp = mlp


class _FakeModel:
    def __init__(self, layers):
        self.model = type("Inner", (), {"layers": layers})()


def _moe_model(n_layers: int, top_k: int) -> _FakeModel:
    return _FakeModel([_FakeLayer(_FakeMoEBlock(top_k=top_k)) for _ in range(n_layers)])


def test_config_validates_negative_top_k() -> None:
    with pytest.raises(ValueError, match="must be >= 1"):
        SchedulerConfig(moe_top_k_override=0)
    with pytest.raises(ValueError, match="must be >= 1"):
        SchedulerConfig(moe_top_k_override=-3)


def test_config_accepts_none_and_positive() -> None:
    assert SchedulerConfig().moe_top_k_override is None
    assert SchedulerConfig(moe_top_k_override=4).moe_top_k_override == 4


def test_patch_lowers_top_k_on_every_moe_layer() -> None:
    model = _moe_model(n_layers=48, top_k=8)

    patched = apply_moe_top_k_override(model, 4)

    assert patched == 48
    for layer in model.model.layers:
        assert layer.mlp.top_k == 4


def test_patch_skips_dense_layers() -> None:
    mixed_layers = [
        _FakeLayer(_FakeMoEBlock(top_k=8)),
        _FakeLayer(_FakeDenseMLP()),
        _FakeLayer(_FakeMoEBlock(top_k=8)),
    ]
    model = _FakeModel(mixed_layers)

    patched = apply_moe_top_k_override(model, 4)

    assert patched == 2
    assert mixed_layers[0].mlp.top_k == 4
    assert mixed_layers[2].mlp.top_k == 4
    # Dense layer was untouched.
    assert not hasattr(mixed_layers[1].mlp, "top_k")


def test_patch_rejects_raising_top_k_above_trained_value() -> None:
    model = _moe_model(n_layers=4, top_k=8)

    with pytest.raises(ValueError, match="greater than"):
        apply_moe_top_k_override(model, 16)

    # First layer stays untouched because we fail fast.
    assert model.model.layers[0].mlp.top_k == 8


def test_patch_rejects_non_positive_k() -> None:
    model = _moe_model(n_layers=4, top_k=8)
    with pytest.raises(ValueError, match=">= 1"):
        apply_moe_top_k_override(model, 0)


def test_patch_dense_model_returns_zero() -> None:
    # Dense model — no layer.mlp has top_k, flag is a no-op.
    model = _FakeModel([_FakeLayer(_FakeDenseMLP()) for _ in range(4)])
    assert apply_moe_top_k_override(model, 4) == 0


def test_patch_missing_model_layers_returns_zero() -> None:
    class _NoLayers:
        pass

    assert apply_moe_top_k_override(_NoLayers(), 4) == 0
