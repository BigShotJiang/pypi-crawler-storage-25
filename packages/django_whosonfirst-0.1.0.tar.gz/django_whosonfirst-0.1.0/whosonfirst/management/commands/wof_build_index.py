"""
Management command to build derived indices and materialized views.

Usage:
    python manage.py wof_build_index
    python manage.py wof_build_index --resolve-parents
    python manage.py wof_build_index --update-belongsto
"""

import logging

from django.core.management.base import BaseCommand
from django.db import connection, transaction
from tqdm import tqdm

from whosonfirst.conf import LOGGER_NAME, PLACETYPE_HIERARCHY, get_wof_settings
from whosonfirst.models import Place
from whosonfirst.services.index_builder import resolve_parent_relationships

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Build derived indices and resolve relationships"

    def add_arguments(self, parser):
        parser.add_argument(
            "--resolve-parents",
            action="store_true",
            help="Resolve parent_wof_id to parent FK relationships",
        )
        parser.add_argument(
            "--update-belongsto",
            action="store_true",
            help="Update belongsto arrays based on parent chain",
        )
        parser.add_argument(
            "--rebuild-hierarchy",
            action="store_true",
            help="Rebuild hierarchy JSON from belongsto",
        )
        parser.add_argument(
            "--all",
            action="store_true",
            help="Run all index building operations",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )

    def handle(self, *args, **options):
        settings = get_wof_settings()

        run_all = options["all"]

        if run_all or options["resolve_parents"]:
            self._resolve_parents(options)

        if run_all or options["update_belongsto"]:
            self._update_belongsto(options)

        if run_all or options["rebuild_hierarchy"]:
            self._rebuild_hierarchy(options)

        self.stdout.write(self.style.SUCCESS("Index building complete!"))

    def _resolve_parents(self, options: dict):
        """Resolve parent_wof_id references to FK relationships."""
        self.stdout.write("Resolving parent relationships...")

        resolved = resolve_parent_relationships(
            batch_size=get_wof_settings().batch_size
        )

        self.stdout.write(f"  Resolved {resolved} parent relationships")

    def _update_belongsto(self, options: dict):
        """
        Update belongsto arrays by traversing parent chain.

        This is useful when belongsto data is missing or incomplete.
        """
        self.stdout.write("Updating belongsto arrays...")

        # Get all places with parents but incomplete belongsto
        places_to_update = Place.objects.filter(
            parent__isnull=False
        ).select_related("parent")

        total = places_to_update.count()
        updated = 0

        with tqdm(total=total, disable=options["quiet"]) as pbar:
            for place in places_to_update.iterator():
                ancestors = self._get_ancestor_chain(place)

                if set(ancestors) != set(place.belongsto):
                    place.belongsto = ancestors
                    place.save(update_fields=["belongsto"])
                    updated += 1

                pbar.update(1)

        self.stdout.write(f"  Updated {updated} places")

    def _get_ancestor_chain(self, place: Place, seen: set = None) -> list:
        """
        Get the full ancestor chain for a place.

        Args:
            place: Place to get ancestors for
            seen: Set of already-seen IDs (for cycle detection)

        Returns:
            List of ancestor WOF IDs
        """
        if seen is None:
            seen = set()

        ancestors = []
        current = place.parent

        while current and current.wof_id not in seen:
            seen.add(current.wof_id)
            ancestors.append(current.wof_id)
            current = current.parent

        return ancestors

    def _rebuild_hierarchy(self, options: dict):
        """
        Rebuild hierarchy JSON from belongsto.

        Creates structured hierarchy dicts with placetype keys.
        """
        self.stdout.write("Rebuilding hierarchy JSON...")

        # Build index of all places
        place_index = {}
        for place in Place.objects.only("wof_id", "placetype").iterator():
            place_index[place.wof_id] = place.placetype

        # Update each place's hierarchy
        places = Place.objects.all()
        total = places.count()
        updated = 0

        with tqdm(total=total, disable=options["quiet"]) as pbar:
            for place in places.iterator():
                hierarchy = self._build_hierarchy_dict(place, place_index)

                if hierarchy != place.hierarchy:
                    place.hierarchy = hierarchy
                    place.save(update_fields=["hierarchy"])
                    updated += 1

                pbar.update(1)

        self.stdout.write(f"  Updated {updated} places")

    def _build_hierarchy_dict(self, place: Place, place_index: dict) -> list:
        """
        Build hierarchy dict for a place.

        Args:
            place: Place to build hierarchy for
            place_index: Dict mapping wof_id to placetype

        Returns:
            List containing a single hierarchy dict
        """
        hierarchy = {f"{place.placetype}_id": place.wof_id}

        for ancestor_id in place.belongsto:
            placetype = place_index.get(ancestor_id)
            if placetype:
                hierarchy[f"{placetype}_id"] = ancestor_id

        return [hierarchy]
