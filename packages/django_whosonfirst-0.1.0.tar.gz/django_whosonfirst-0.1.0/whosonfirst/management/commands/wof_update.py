"""
Management command to update Who's On First data.

Downloads fresh data and imports only changed records.

Usage:
    python manage.py wof_update
    python manage.py wof_update --countries=US,CA
"""

import logging

from django.core.management.base import BaseCommand, CommandError
from django.core.management import call_command

from whosonfirst.conf import LOGGER_NAME, get_wof_settings
from whosonfirst.models import Place
from whosonfirst.services import Downloader, SQLiteParser

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Update Who's On First data (download fresh and import changes)"

    def add_arguments(self, parser):
        parser.add_argument(
            "--countries",
            type=str,
            default="",
            help="Comma-separated ISO 3166-1 alpha-2 country codes to update",
        )
        parser.add_argument(
            "--placetypes",
            type=str,
            default="",
            help="Comma-separated placetypes to update",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )
        parser.add_argument(
            "--check-only",
            action="store_true",
            help="Only check for updates, don't import",
        )

    def handle(self, *args, **options):
        settings = get_wof_settings()

        # Parse country codes
        country_codes = []
        if options["countries"]:
            country_codes = [
                code.strip().upper()
                for code in options["countries"].split(",")
                if code.strip()
            ]

        # Step 1: Force download fresh data
        self.stdout.write("Downloading fresh WOF data...")

        download_args = ["--force"]
        if options["quiet"]:
            download_args.append("--quiet")
        if country_codes:
            download_args.extend(["--countries", ",".join(country_codes)])

        call_command("wof_download", *download_args)

        # Step 2: Check for changes
        if options["check_only"]:
            self._check_changes(country_codes, options)
            return

        # Step 3: Import (will update existing records)
        self.stdout.write("Importing updated data...")

        import_args = []
        if options["quiet"]:
            import_args.append("--quiet")
        if country_codes:
            import_args.extend(["--countries", ",".join(country_codes)])
        if options["placetypes"]:
            import_args.extend(["--placetypes", options["placetypes"]])

        call_command("wof_import", *import_args)

        self.stdout.write(self.style.SUCCESS("Update complete!"))

    def _check_changes(self, country_codes: list, options: dict):
        """
        Check for changes without importing.

        Args:
            country_codes: Country codes to check
            options: Command options
        """
        settings = get_wof_settings()
        downloader = Downloader(data_dir=settings.data_dir)

        # Get current lastmodified values from database
        existing_modified = dict(
            Place.objects.values_list("wof_id", "lastmodified")
        )

        total_new = 0
        total_updated = 0
        total_unchanged = 0

        # Check each downloaded bundle
        bundles = downloader.list_available_bundles()

        for code, path in bundles:
            if country_codes and code and code not in country_codes:
                continue

            self.stdout.write(f"Checking {code or 'global'}...")

            parser = SQLiteParser(path, quiet=options["quiet"])

            new_count = 0
            updated_count = 0
            unchanged_count = 0

            for item in parser.iter_places(include_geojson=False):
                wof_id = item.get("wof_id")
                lastmodified = item.get("lastmodified")

                if wof_id not in existing_modified:
                    new_count += 1
                elif existing_modified[wof_id] != lastmodified:
                    updated_count += 1
                else:
                    unchanged_count += 1

            self.stdout.write(
                f"  New: {new_count}, Updated: {updated_count}, Unchanged: {unchanged_count}"
            )

            total_new += new_count
            total_updated += updated_count
            total_unchanged += unchanged_count

        self.stdout.write("")
        self.stdout.write(
            self.style.SUCCESS(
                f"Total: {total_new} new, {total_updated} updated, {total_unchanged} unchanged"
            )
        )
