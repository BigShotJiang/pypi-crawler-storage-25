"""
Management command to import Who's On First data into Django.

Usage:
    python manage.py wof_import
    python manage.py wof_import --countries=US,CA
    python manage.py wof_import --placetypes=country,region,locality
    python manage.py wof_import --flush
    python manage.py wof_import --dry-run
"""

import logging

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from whosonfirst.conf import (
    DEFAULT_PLACETYPES,
    FLUSH_OPTS,
    FLUSH_OPTS_ALL,
    IMPORT_OPTS,
    IMPORT_OPTS_ALL,
    LOGGER_NAME,
    OPTIONAL_PLACETYPES,
    PLACETYPE_HIERARCHY,
    get_wof_settings,
)
from whosonfirst.importer import PlaceImporter
from whosonfirst.models import Place, PlaceName

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Import Who's On First data into Django models"

    # Importer mapping
    IMPORTERS = {
        "place": PlaceImporter,
    }

    def add_arguments(self, parser):
        parser.add_argument(
            "--import",
            type=str,
            default="all",
            dest="import_type",
            help=f"What to import: {', '.join(IMPORT_OPTS)} (default: all)",
        )
        parser.add_argument(
            "--countries",
            type=str,
            default="",
            help="Comma-separated ISO 3166-1 alpha-2 country codes to import (e.g., US,CA,MX). "
            "If not specified, imports all countries from downloaded bundles.",
        )
        parser.add_argument(
            "--placetypes",
            type=str,
            default="",
            help=f"Comma-separated placetypes to import. "
            f"Default: {', '.join(DEFAULT_PLACETYPES)}. "
            f"Optional: {', '.join(OPTIONAL_PLACETYPES)}",
        )
        parser.add_argument(
            "--flush",
            type=str,
            default="",
            help=f"Delete existing data before import: {', '.join(FLUSH_OPTS)}",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force re-download of data files",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Parse data without saving to database",
        )
        parser.add_argument(
            "--no-geometry",
            action="store_true",
            help="Skip importing geometry (faster, smaller database)",
        )
        parser.add_argument(
            "--no-names",
            action="store_true",
            help="Skip importing alternative names",
        )
        parser.add_argument(
            "--no-resolve-parents",
            action="store_true",
            help="Skip resolving parent relationships after import",
        )
        parser.add_argument(
            "--data-dir",
            type=str,
            help="Override data directory (default from WOF_DATA_DIR setting)",
        )

    def handle(self, *args, **options):
        # Parse options
        import_type = options["import_type"]
        flush_type = options.get("flush", "")

        # Parse country codes
        country_codes = []
        if options["countries"]:
            country_codes = [
                code.strip().upper()
                for code in options["countries"].split(",")
                if code.strip()
            ]

        # Parse placetypes
        placetypes = []
        if options["placetypes"]:
            placetypes = [
                pt.strip().lower()
                for pt in options["placetypes"].split(",")
                if pt.strip()
            ]
            # Validate placetypes
            invalid = set(placetypes) - set(PLACETYPE_HIERARCHY)
            if invalid:
                raise CommandError(f"Invalid placetypes: {', '.join(invalid)}")

        # Override settings for geometry import
        settings = get_wof_settings()
        if options["no_geometry"]:
            settings.import_geometry = False

        # Build importer options
        importer_options = {
            "force": options["force"],
            "quiet": options["quiet"],
            "dry_run": options["dry_run"],
            "country_codes": country_codes,
            "placetypes": placetypes,
            "import_names": not options["no_names"],
            "resolve_parents": not options["no_resolve_parents"],
        }

        # Handle flush
        if flush_type:
            self._handle_flush(flush_type)

        # Handle import
        self._handle_import(import_type, importer_options)

    def _handle_flush(self, flush_type: str):
        """
        Delete existing data.

        Args:
            flush_type: What to flush ("all", "place", etc.)
        """
        if flush_type not in FLUSH_OPTS:
            raise CommandError(f"Invalid flush type: {flush_type}")

        flush_targets = FLUSH_OPTS_ALL if flush_type == "all" else [flush_type]

        for target in flush_targets:
            self._flush(target)

    def _flush(self, target: str):
        """
        Flush a specific target.

        Args:
            target: What to flush
        """
        self.stdout.write(f"Flushing {target}...")

        if target == "place":
            # Delete in correct order to respect foreign keys
            PlaceName.objects.all().delete()
            count = Place.objects.all().delete()[0]
            self.stdout.write(f"  Deleted {count} places")

    def _handle_import(self, import_type: str, options: dict):
        """
        Run import operations.

        Args:
            import_type: What to import ("all", "place", etc.)
            options: Importer options dict
        """
        if import_type not in IMPORT_OPTS:
            raise CommandError(f"Invalid import type: {import_type}")

        import_targets = IMPORT_OPTS_ALL if import_type == "all" else [import_type]

        total_stats = {
            "processed": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
        }

        for target in import_targets:
            self._run_importer(target, options, total_stats)

        # Print summary
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Import complete!"))
        self.stdout.write(f"  Processed: {total_stats['processed']}")
        self.stdout.write(f"  Created:   {total_stats['created']}")
        self.stdout.write(f"  Updated:   {total_stats['updated']}")
        self.stdout.write(f"  Skipped:   {total_stats['skipped']}")
        if total_stats["errors"]:
            self.stdout.write(
                self.style.WARNING(f"  Errors:    {total_stats['errors']}")
            )

    def _run_importer(self, target: str, options: dict, total_stats: dict):
        """
        Run a specific importer.

        Args:
            target: Import target name
            options: Importer options
            total_stats: Dict to accumulate statistics
        """
        importer_class = self.IMPORTERS.get(target)
        if not importer_class:
            self.stdout.write(
                self.style.WARNING(f"No importer for: {target}")
            )
            return

        self.stdout.write(f"Importing {target}...")

        try:
            importer = importer_class(self, options)
            stats = importer.run()

            # Accumulate stats
            for key in total_stats:
                total_stats[key] += stats.get(key, 0)

        except Exception as e:
            logger.error("Import failed: %s", e, exc_info=True)
            self.stdout.write(
                self.style.ERROR(f"Import failed: {e}")
            )
            raise CommandError(f"Import failed: {e}") from e
