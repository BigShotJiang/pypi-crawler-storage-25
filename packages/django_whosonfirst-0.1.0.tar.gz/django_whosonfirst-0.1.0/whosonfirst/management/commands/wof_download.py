"""
Management command to download Who's On First data.

Usage:
    python manage.py wof_download
    python manage.py wof_download --countries=US,CA,MX
    python manage.py wof_download --force
    python manage.py wof_download --list
    python manage.py wof_download --clear
"""

import logging

from django.core.management.base import BaseCommand, CommandError

from whosonfirst.conf import LOGGER_NAME, get_wof_settings
from whosonfirst.services import Downloader

logger = logging.getLogger(LOGGER_NAME)


class Command(BaseCommand):
    help = "Download Who's On First SQLite data bundles"

    def add_arguments(self, parser):
        parser.add_argument(
            "--countries",
            type=str,
            default="",
            help="Comma-separated ISO 3166-1 alpha-2 country codes to download (e.g., US,CA,MX). "
            "If not specified, downloads the global admin bundle.",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Force re-download even if files exist in cache",
        )
        parser.add_argument(
            "--quiet",
            action="store_true",
            help="Suppress progress output",
        )
        parser.add_argument(
            "--list",
            action="store_true",
            dest="list_cached",
            help="List cached SQLite bundles",
        )
        parser.add_argument(
            "--clear",
            action="store_true",
            help="Clear cached downloads (use with --countries to clear specific countries)",
        )
        parser.add_argument(
            "--data-dir",
            type=str,
            help="Override data directory (default from WOF_DATA_DIR setting)",
        )

    def handle(self, *args, **options):
        settings = get_wof_settings()
        data_dir = options.get("data_dir") or settings.data_dir

        downloader = Downloader(
            data_dir=data_dir,
            force=options["force"],
            quiet=options["quiet"],
        )

        # Parse country codes
        country_codes = []
        if options["countries"]:
            country_codes = [
                code.strip().upper()
                for code in options["countries"].split(",")
                if code.strip()
            ]

        # Handle --list
        if options["list_cached"]:
            self._list_cached(downloader)
            return

        # Handle --clear
        if options["clear"]:
            self._clear_cache(downloader, country_codes)
            return

        # Download
        self._download(downloader, country_codes, options)

    def _list_cached(self, downloader: Downloader):
        """List cached SQLite bundles."""
        bundles = downloader.list_available_bundles()

        if not bundles:
            self.stdout.write("No cached SQLite bundles found.")
            return

        self.stdout.write("Cached SQLite bundles:")
        for code, path in bundles:
            if code:
                self.stdout.write(f"  {code}: {path}")
            else:
                self.stdout.write(f"  (global): {path}")

    def _clear_cache(self, downloader: Downloader, country_codes: list):
        """Clear cached downloads."""
        if country_codes:
            for code in country_codes:
                downloader.clear_cache(code)
                self.stdout.write(f"Cleared cache for {code}")
        else:
            downloader.clear_cache()
            self.stdout.write("Cleared all cached downloads")

    def _download(self, downloader: Downloader, country_codes: list, options: dict):
        """Download SQLite bundles."""
        downloaded = []
        errors = []

        if country_codes:
            # Download specific countries
            for code in country_codes:
                self.stdout.write(f"Downloading WOF data for {code}...")
                try:
                    path = downloader.download_sqlite(country_code=code)
                    downloaded.append((code, path))
                    self.stdout.write(
                        self.style.SUCCESS(f"  Downloaded: {path}")
                    )
                except Exception as e:
                    errors.append((code, str(e)))
                    self.stdout.write(
                        self.style.ERROR(f"  Failed: {e}")
                    )
        else:
            # Download global bundle
            self.stdout.write("Downloading global WOF admin data...")
            try:
                path = downloader.download_sqlite()
                downloaded.append((None, path))
                self.stdout.write(
                    self.style.SUCCESS(f"Downloaded: {path}")
                )
            except Exception as e:
                errors.append((None, str(e)))
                self.stdout.write(
                    self.style.ERROR(f"Failed: {e}")
                )

        # Summary
        self.stdout.write("")
        if downloaded:
            self.stdout.write(
                self.style.SUCCESS(f"Successfully downloaded {len(downloaded)} bundle(s)")
            )
        if errors:
            self.stdout.write(
                self.style.ERROR(f"Failed to download {len(errors)} bundle(s)")
            )
            for code, error in errors:
                label = code or "global"
                self.stdout.write(f"  {label}: {error}")
