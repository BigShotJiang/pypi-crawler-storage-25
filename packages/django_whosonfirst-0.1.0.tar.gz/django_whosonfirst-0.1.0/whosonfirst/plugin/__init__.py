"""
Plugin system for Who's On First import customization.

Plugins allow you to hook into the import process to:
- Filter records before import
- Modify data during import
- Add custom processing after import

Usage:
1. Create a plugin class with hook methods
2. Add the class path to WOF_PLUGINS in Django settings

Example:
    # myapp/plugins.py
    from whosonfirst.exceptions import HookException

    class MyPlugin:
        def place_pre(self, command, item):
            '''Called before parsing each place.

            Args:
                command: Management command instance
                item: Raw data dict from parser

            Raises:
                HookException: To skip this item
            '''
            # Skip places without geometry
            if not item.get("geometry"):
                raise HookException("No geometry")

            # Modify item in place
            item["name"] = item["name"].upper()

        def place_post(self, command, obj, item):
            '''Called after saving each place.

            Args:
                command: Management command instance
                obj: Saved Place model instance
                item: Raw data dict from parser
            '''
            # Custom post-processing
            if obj.placetype == "locality":
                # Do something with cities
                pass

    # settings.py
    WOF_PLUGINS = ["myapp.plugins.MyPlugin"]

Available Hooks:
    place_pre(command, item) - Before parsing a place
    place_post(command, obj, item) - After saving a place
"""

from ..exceptions import HookException

__all__ = ["HookException"]
