"""Initial migration for Who's On First models."""

import django.contrib.gis.db.models.fields
import django.contrib.postgres.indexes
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Place",
            fields=[
                (
                    "wof_id",
                    models.BigIntegerField(
                        help_text="Who's On First unique identifier",
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                (
                    "placetype",
                    models.CharField(
                        db_index=True,
                        help_text="WOF placetype (continent, country, region, locality, etc.)",
                        max_length=50,
                    ),
                ),
                (
                    "name",
                    models.CharField(
                        db_index=True,
                        help_text="Primary name from wof:name",
                        max_length=255,
                    ),
                ),
                (
                    "slug",
                    models.SlugField(
                        blank=True,
                        help_text="URL-friendly slug",
                        max_length=255,
                    ),
                ),
                (
                    "country_code",
                    models.CharField(
                        blank=True,
                        db_index=True,
                        help_text="ISO 3166-1 alpha-2 country code from wof:country",
                        max_length=2,
                    ),
                ),
                (
                    "parent_wof_id",
                    models.BigIntegerField(
                        blank=True,
                        db_index=True,
                        help_text="Raw parent WOF ID (for deferred resolution)",
                        null=True,
                    ),
                ),
                (
                    "belongsto",
                    models.JSONField(
                        blank=True,
                        default=list,
                        help_text="List of ancestor WOF IDs from wof:belongsto",
                    ),
                ),
                (
                    "hierarchy",
                    models.JSONField(
                        blank=True,
                        default=list,
                        help_text="Full hierarchy from wof:hierarchy",
                    ),
                ),
                (
                    "geom",
                    django.contrib.gis.db.models.fields.MultiPolygonField(
                        blank=True,
                        help_text="Geometry (normalized to MultiPolygon)",
                        null=True,
                        srid=4326,
                    ),
                ),
                (
                    "centroid",
                    django.contrib.gis.db.models.fields.PointField(
                        blank=True,
                        help_text="Centroid point for label placement",
                        null=True,
                        srid=4326,
                    ),
                ),
                (
                    "latitude",
                    models.FloatField(
                        blank=True,
                        help_text="Centroid latitude",
                        null=True,
                    ),
                ),
                (
                    "longitude",
                    models.FloatField(
                        blank=True,
                        help_text="Centroid longitude",
                        null=True,
                    ),
                ),
                (
                    "bbox",
                    models.JSONField(
                        blank=True,
                        help_text="Bounding box [minlon, minlat, maxlon, maxlat]",
                        null=True,
                    ),
                ),
                (
                    "concordances",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        help_text="External ID mappings from wof:concordances",
                    ),
                ),
                (
                    "geonames_id",
                    models.BigIntegerField(
                        blank=True,
                        db_index=True,
                        help_text="GeoNames ID from concordances",
                        null=True,
                    ),
                ),
                (
                    "wikidata_id",
                    models.CharField(
                        blank=True,
                        db_index=True,
                        help_text="Wikidata QID from concordances",
                        max_length=20,
                    ),
                ),
                (
                    "lastmodified",
                    models.BigIntegerField(
                        blank=True,
                        help_text="Unix timestamp from wof:lastmodified",
                        null=True,
                    ),
                ),
                (
                    "is_current",
                    models.BooleanField(
                        db_index=True,
                        default=True,
                        help_text="Whether the place is current (not deprecated/ceased)",
                    ),
                ),
                (
                    "is_deprecated",
                    models.BooleanField(
                        db_index=True,
                        default=False,
                        help_text="Whether the place is deprecated",
                    ),
                ),
                (
                    "superseded_by",
                    models.JSONField(
                        blank=True,
                        default=list,
                        help_text="List of WOF IDs that supersede this record",
                    ),
                ),
                (
                    "supersedes",
                    models.JSONField(
                        blank=True,
                        default=list,
                        help_text="List of WOF IDs this record supersedes",
                    ),
                ),
                (
                    "source_repo",
                    models.CharField(
                        blank=True,
                        help_text="Source repository or bundle name",
                        max_length=100,
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "parent",
                    models.ForeignKey(
                        blank=True,
                        help_text="Parent place from wof:parent_id",
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="children",
                        to="whosonfirst.place",
                    ),
                ),
            ],
            options={
                "verbose_name": "Place",
                "verbose_name_plural": "Places",
                "ordering": ["placetype", "name"],
            },
        ),
        migrations.CreateModel(
            name="PlaceRelation",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "relation_type",
                    models.CharField(
                        choices=[
                            ("supersedes", "Supersedes"),
                            ("superseded_by", "Superseded By"),
                            ("coterminous", "Coterminous With"),
                            ("part_of", "Part Of"),
                            ("contains", "Contains"),
                        ],
                        db_index=True,
                        max_length=20,
                    ),
                ),
                (
                    "from_place",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="relations_from",
                        to="whosonfirst.place",
                    ),
                ),
                (
                    "to_place",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="relations_to",
                        to="whosonfirst.place",
                    ),
                ),
            ],
            options={
                "verbose_name": "Place Relation",
                "verbose_name_plural": "Place Relations",
                "unique_together": {("from_place", "to_place", "relation_type")},
            },
        ),
        migrations.CreateModel(
            name="PlaceName",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("name", models.CharField(db_index=True, max_length=255)),
                (
                    "language",
                    models.CharField(
                        blank=True,
                        db_index=True,
                        help_text="ISO 639-3 language code",
                        max_length=10,
                    ),
                ),
                (
                    "name_type",
                    models.CharField(
                        blank=True,
                        choices=[
                            ("preferred", "Preferred"),
                            ("variant", "Variant"),
                            ("colloquial", "Colloquial"),
                            ("historical", "Historical"),
                            ("official", "Official"),
                            ("", "Unknown"),
                        ],
                        help_text="Type of name (preferred, variant, etc.)",
                        max_length=20,
                    ),
                ),
                ("is_preferred", models.BooleanField(db_index=True, default=False)),
                (
                    "place",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="names",
                        to="whosonfirst.place",
                    ),
                ),
            ],
            options={
                "verbose_name": "Place Name",
                "verbose_name_plural": "Place Names",
                "unique_together": {("place", "name", "language")},
            },
        ),
        migrations.AddIndex(
            model_name="place",
            index=models.Index(
                fields=["placetype", "country_code"],
                name="whosonfirst_placety_85af07_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="place",
            index=models.Index(
                fields=["placetype", "name"],
                name="whosonfirst_placety_f9dd60_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="place",
            index=models.Index(
                fields=["country_code", "placetype"],
                name="whosonfirst_country_a3c9ed_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="place",
            index=django.contrib.postgres.indexes.GinIndex(
                fields=["belongsto"],
                name="place_belongsto_gin",
            ),
        ),
        migrations.AddIndex(
            model_name="placename",
            index=models.Index(
                fields=["language", "is_preferred"],
                name="whosonfirst_languag_6d41cb_idx",
            ),
        ),
    ]
