# Generated manually

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("whosonfirst", "0001_initial"),
    ]

    operations = [
        migrations.DeleteModel(
            name="PlaceRelation",
        ),
    ]
