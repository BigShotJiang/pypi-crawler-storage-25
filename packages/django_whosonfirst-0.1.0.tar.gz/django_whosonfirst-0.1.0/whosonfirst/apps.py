from django.apps import AppConfig


class WhosOnFirstConfig(AppConfig):
    """Django app configuration for Who's On First."""

    name = "whosonfirst"
    verbose_name = "Who's On First"
    default_auto_field = "django.db.models.BigAutoField"
