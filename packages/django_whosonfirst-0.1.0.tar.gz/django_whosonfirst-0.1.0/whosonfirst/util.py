"""Utility functions for Who's On First operations."""

import re
import unicodedata
from typing import Optional

from django.contrib.gis.geos import GEOSGeometry, MultiPolygon, Point, Polygon


def slugify(value: str, allow_unicode: bool = False) -> str:
    """
    Convert a string to a URL-friendly slug.

    Args:
        value: String to slugify
        allow_unicode: If True, allow unicode characters

    Returns:
        Slugified string
    """
    if allow_unicode:
        value = unicodedata.normalize("NFKC", value)
    else:
        value = unicodedata.normalize("NFKD", value)
        value = value.encode("ascii", "ignore").decode("ascii")

    value = re.sub(r"[^\w\s-]", "", value.lower())
    return re.sub(r"[-\s]+", "-", value).strip("-_")


def parse_wof_id(value) -> Optional[int]:
    """
    Parse a WOF ID from various formats.

    Args:
        value: WOF ID as int, str, or None

    Returns:
        Integer WOF ID or None
    """
    if value is None:
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, str):
        value = value.strip()
        if value in ("", "-1", "0"):
            return None
        try:
            parsed = int(value)
            return parsed if parsed > 0 else None
        except ValueError:
            return None
    return None


def parse_wof_ids(value) -> list:
    """
    Parse a list of WOF IDs.

    Args:
        value: List, string, or None

    Returns:
        List of integer WOF IDs
    """
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [wof_id for v in value if (wof_id := parse_wof_id(v)) is not None]
    if isinstance(value, str):
        return parse_wof_ids(value.split(","))
    return []


def _strip_z_coordinates(coords):
    """
    Recursively strip Z dimension from coordinates.

    Args:
        coords: Coordinate array (can be nested)

    Returns:
        Coordinates with only X, Y values
    """
    if not coords:
        return coords

    # Check if this is a coordinate pair/triple (list of numbers)
    if isinstance(coords[0], (int, float)):
        # Return only first two values (x, y), dropping z if present
        return coords[:2]

    # Otherwise it's a nested structure, recurse
    return [_strip_z_coordinates(c) for c in coords]


def normalize_geometry(geom_data: dict) -> Optional[GEOSGeometry]:
    """
    Convert GeoJSON geometry to GEOS geometry.

    Normalizes all polygon types to MultiPolygon for consistency.
    Strips Z dimension from coordinates if present.

    Args:
        geom_data: GeoJSON geometry dict

    Returns:
        GEOSGeometry instance or None
    """
    if not geom_data:
        return None

    geom_type = geom_data.get("type", "").lower()
    coordinates = geom_data.get("coordinates")

    if not coordinates:
        return None

    # Strip Z dimension from coordinates
    coordinates = _strip_z_coordinates(coordinates)

    try:
        if geom_type == "point":
            # Points can't be stored in MultiPolygonField
            # They should be stored as centroid instead
            return None

        elif geom_type == "polygon":
            poly = Polygon(coordinates[0], srid=4326)
            return MultiPolygon(poly, srid=4326)

        elif geom_type == "multipolygon":
            polys = [Polygon(ring[0], srid=4326) for ring in coordinates]
            return MultiPolygon(polys, srid=4326)

        else:
            # Try generic GeoJSON parsing with stripped coordinates
            import json
            stripped_data = {**geom_data, "coordinates": coordinates}
            return GEOSGeometry(json.dumps(stripped_data), srid=4326)

    except Exception:
        return None


def extract_concordances(concordances: dict) -> dict:
    """
    Extract and normalize concordance mappings.

    Args:
        concordances: Raw concordances dict from WOF

    Returns:
        Normalized dict with standard keys
    """
    from .conf import CONCORDANCE_KEYS

    result = {}

    if not concordances:
        return result

    for wof_key, our_key in CONCORDANCE_KEYS.items():
        if wof_key in concordances:
            value = concordances[wof_key]
            # Clean up the value
            if isinstance(value, str):
                value = value.strip()
                if value:
                    result[our_key] = value
            elif value is not None:
                result[our_key] = value

    # Also store any unknown concordances
    known_keys = set(CONCORDANCE_KEYS.keys())
    for key, value in concordances.items():
        if key not in known_keys and value:
            result[key] = value

    return result


def is_current(properties: dict) -> bool:
    """
    Check if a WOF record is current (not deprecated/ceased).

    Args:
        properties: WOF properties dict

    Returns:
        True if the record appears to be current
    """
    # Check mz:is_current flag
    is_current_flag = properties.get("mz:is_current")
    if is_current_flag == 0:
        return False
    if is_current_flag == 1:
        return True

    # Check for deprecation
    deprecated = properties.get("edtf:deprecated")
    if deprecated and deprecated != "uuuu":
        return False

    # Check for cessation
    cessation = properties.get("edtf:cessation")
    if cessation and cessation != "uuuu" and cessation != "":
        # Has a cessation date, might not be current
        # But we'll consider it current unless explicitly marked otherwise
        pass

    # Check for supersession
    superseded_by = properties.get("wof:superseded_by", [])
    if superseded_by:
        return False

    return True


def get_name_from_properties(properties: dict, lang: str = "eng") -> str:
    """
    Extract the best name from WOF properties.

    Tries in order:
    1. wof:name
    2. name:{lang}_x_preferred (e.g., name:eng_x_preferred)
    3. name:{lang}_x_variant
    4. First available name

    Args:
        properties: WOF properties dict
        lang: ISO 639-3 language code

    Returns:
        Best available name or empty string
    """
    # Primary name
    name = properties.get("wof:name")
    if name:
        return name

    # Language-specific preferred name
    preferred_key = f"name:{lang}_x_preferred"
    preferred = properties.get(preferred_key)
    if preferred:
        if isinstance(preferred, list):
            return preferred[0] if preferred else ""
        return preferred

    # Language-specific variant
    variant_key = f"name:{lang}_x_variant"
    variant = properties.get(variant_key)
    if variant:
        if isinstance(variant, list):
            return variant[0] if variant else ""
        return variant

    # Any name field
    for key, value in properties.items():
        if key.startswith("name:") and value:
            if isinstance(value, list):
                return value[0] if value else ""
            return value

    return ""


def extract_label_point(properties: dict) -> tuple:
    """
    Extract label point coordinates from properties.

    Args:
        properties: WOF properties dict

    Returns:
        Tuple of (latitude, longitude) or (None, None)
    """
    # Try label point first
    lat = properties.get("lbl:latitude")
    lon = properties.get("lbl:longitude")

    if lat is not None and lon is not None:
        try:
            return float(lat), float(lon)
        except (ValueError, TypeError):
            pass

    # Fall back to geom centroid
    lat = properties.get("geom:latitude")
    lon = properties.get("geom:longitude")

    if lat is not None and lon is not None:
        try:
            return float(lat), float(lon)
        except (ValueError, TypeError):
            pass

    return None, None


def extract_bbox(properties: dict, geometry: dict = None) -> Optional[list]:
    """
    Extract bounding box from properties or geometry.

    Args:
        properties: WOF properties dict
        geometry: GeoJSON geometry dict

    Returns:
        List [minlon, minlat, maxlon, maxlat] or None
    """
    # Try properties first
    bbox = properties.get("geom:bbox")
    if bbox:
        if isinstance(bbox, str):
            try:
                parts = [float(x.strip()) for x in bbox.split(",")]
                if len(parts) == 4:
                    return parts
            except ValueError:
                pass
        elif isinstance(bbox, (list, tuple)) and len(bbox) == 4:
            try:
                return [float(x) for x in bbox]
            except (ValueError, TypeError):
                pass

    # Try geometry bbox
    if geometry and "bbox" in geometry:
        bbox = geometry["bbox"]
        if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
            try:
                return [float(x) for x in bbox[:4]]
            except (ValueError, TypeError):
                pass

    return None
