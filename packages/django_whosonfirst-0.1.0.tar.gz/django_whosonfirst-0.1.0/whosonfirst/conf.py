"""
Configuration for Who's On First data import.

Settings can be overridden in Django settings using the WOF_ prefix.
"""

import os
from dataclasses import dataclass, field
from typing import Optional

from django.conf import settings as django_settings

# Logger name for all WOF operations
LOGGER_NAME = "whosonfirst"

# Base URLs for WOF data
# Data is now hosted by Geocode Earth: https://geocode.earth/data/whosonfirst/
WOF_SQLITE_BASE_URL = "https://data.geocode.earth/wof/dist/sqlite"
WOF_GITHUB_RAW_BASE = "https://raw.githubusercontent.com/whosonfirst-data"

# Placetype hierarchy (ordered from largest to smallest)
PLACETYPE_HIERARCHY = [
    "continent",
    "empire",
    "country",
    "dependency",
    "disputed",
    "macroregion",
    "region",
    "macrocounty",
    "county",
    "localadmin",
    "locality",
    "borough",
    "macrohood",
    "neighbourhood",
    "microhood",
    "campus",
    "building",
    "address",
    "venue",
    "postalcode",
]

# Default placetypes to import (travel-guide focused)
DEFAULT_PLACETYPES = [
    "continent",
    "country",
    "dependency",
    "disputed",
    "macroregion",
    "region",
    "county",
    "locality",
]

# Optional placetypes that can be enabled
OPTIONAL_PLACETYPES = [
    "borough",
    "macrohood",
    "neighbourhood",
    "venue",
]

# Placetypes to skip by default
SKIP_PLACETYPES = [
    "postalcode",
    "address",
    "building",
    "microhood",
]

# SQLite bundle specifications
# Format: {bundle_key: {filename, description}}
SQLITE_BUNDLES = {
    # Admin bundles by country (pattern-based)
    "admin": {
        "url_pattern": "{base}/whosonfirst-data-admin-{country_lower}.db.bz2",
        "description": "Administrative places for {country}",
    },
    # Global admin bundle
    "admin_global": {
        "url": "{base}/whosonfirst-data-admin-latest.db.bz2",
        "description": "All administrative places worldwide",
    },
}

# WOF property namespaces and their meanings
WOF_PROPERTIES = {
    "wof:id": "Unique WOF identifier",
    "wof:name": "Primary name",
    "wof:placetype": "Place type (country, region, locality, etc.)",
    "wof:parent_id": "Parent place WOF ID",
    "wof:hierarchy": "Full hierarchy as list of dicts",
    "wof:belongsto": "List of ancestor WOF IDs",
    "wof:country": "ISO 3166-1 alpha-2 country code",
    "wof:concordances": "External ID mappings (GeoNames, Wikidata, etc.)",
    "wof:lastmodified": "Unix timestamp of last modification",
    "wof:superseded_by": "List of WOF IDs that supersede this record",
    "wof:supersedes": "List of WOF IDs this record supersedes",
    "wof:cessation": "Date place ceased to exist (UUUU for unknown)",
    "wof:inception": "Date place came into existence",
    "geom:latitude": "Centroid latitude",
    "geom:longitude": "Centroid longitude",
    "geom:bbox": "Bounding box [minlon, minlat, maxlon, maxlat]",
    "iso:country": "ISO country code",
    "lbl:latitude": "Label point latitude",
    "lbl:longitude": "Label point longitude",
    "src:geom": "Source of geometry",
    "mz:is_current": "Whether place is current (-1=unknown, 0=no, 1=yes)",
    "edtf:cessation": "EDTF cessation date",
    "edtf:inception": "EDTF inception date",
}

# Concordance keys we care about
CONCORDANCE_KEYS = {
    "gn:id": "geonames_id",  # GeoNames ID
    "gp:id": "geoplanet_id",  # Yahoo GeoPlanet ID
    "wd:id": "wikidata_id",  # Wikidata QID
    "wk:page": "wikipedia_page",  # Wikipedia page name
    "fips:code": "fips_code",  # FIPS code
    "hasc:id": "hasc_code",  # HASC code
    "iso:id": "iso_code",  # ISO code
    "unlc:id": "un_locode",  # UN/LOCODE
    "iata:code": "iata_code",  # IATA airport code
    "icao:code": "icao_code",  # ICAO airport code
    "ne:id": "natural_earth_id",  # Natural Earth ID
    "qs:id": "quattroshapes_id",  # Quattroshapes ID
    "qs_pg:id": "quattroshapes_pg_id",  # Quattroshapes point-geom ID
}

# Import options for management command
IMPORT_OPTS = ["all", "place"]
IMPORT_OPTS_ALL = ["place"]

# Flush options for management command
FLUSH_OPTS = ["all", "place"]
FLUSH_OPTS_ALL = ["place"]


@dataclass
class WOFSettings:
    """Configuration settings for WOF import operations."""

    # Directory for downloaded data
    data_dir: str = ""

    # Placetypes to import
    placetypes: list = field(default_factory=lambda: DEFAULT_PLACETYPES.copy())

    # Country ISO codes to import (empty = all)
    country_codes: list = field(default_factory=list)

    # Whether to import geometry
    import_geometry: bool = True

    # HTTP download timeout in seconds
    download_timeout: int = 300

    # Maximum download size in bytes (default 10GB)
    max_download_size: int = 10 * 1024 * 1024 * 1024

    # Batch size for bulk operations
    batch_size: int = 1000

    # Whether to skip records marked as deprecated
    skip_deprecated: bool = True

    # Whether to skip records marked as not current
    skip_not_current: bool = False

    # Plugin classes to load
    plugins: list = field(default_factory=list)

    # Languages to import for alternative names (ISO 639-3 codes)
    # Default: ['eng'] (English only)
    # Use empty list [] to import all languages
    languages: list = field(default_factory=lambda: ["eng"])


def get_settings() -> WOFSettings:
    """
    Create settings object from Django settings.

    Reads settings with WOF_ prefix from Django settings.
    """
    # Default data directory
    app_dir = os.path.dirname(os.path.abspath(__file__))
    default_data_dir = os.path.join(app_dir, "data")

    settings_obj = WOFSettings(
        data_dir=getattr(django_settings, "WOF_DATA_DIR", default_data_dir),
        placetypes=getattr(django_settings, "WOF_PLACETYPES", DEFAULT_PLACETYPES.copy()),
        country_codes=getattr(django_settings, "WOF_COUNTRY_CODES", []),
        import_geometry=getattr(django_settings, "WOF_IMPORT_GEOMETRY", True),
        download_timeout=getattr(django_settings, "WOF_DOWNLOAD_TIMEOUT", 300),
        max_download_size=getattr(django_settings, "WOF_MAX_DOWNLOAD_SIZE", 10 * 1024 * 1024 * 1024),
        batch_size=getattr(django_settings, "WOF_BATCH_SIZE", 1000),
        skip_deprecated=getattr(django_settings, "WOF_SKIP_DEPRECATED", True),
        skip_not_current=getattr(django_settings, "WOF_SKIP_NOT_CURRENT", False),
        plugins=getattr(django_settings, "WOF_PLUGINS", []),
        languages=getattr(django_settings, "WOF_LANGUAGES", ["eng"]),
    )

    # Ensure data directory exists
    os.makedirs(settings_obj.data_dir, exist_ok=True)

    return settings_obj


# Singleton settings instance
_settings: Optional[WOFSettings] = None


def get_wof_settings() -> WOFSettings:
    """Get or create the singleton settings instance."""
    global _settings
    if _settings is None:
        _settings = get_settings()
    return _settings


def reset_settings() -> None:
    """Reset settings (useful for testing)."""
    global _settings
    _settings = None
