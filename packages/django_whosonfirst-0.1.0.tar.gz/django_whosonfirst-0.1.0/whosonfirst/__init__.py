"""
Django Who's On First - A Django app for importing and managing WOF geographic data.

Who's On First (WOF) is an open, global gazetteer that provides stable place IDs,
explicit hierarchies, and polygon geometries for geographic entities.

License: MIT
WOF Data License: See https://whosonfirst.org/docs/licenses/
"""

__version__ = "0.1.0"
__author__ = "Your Name"

default_app_config = "whosonfirst.apps.WhosOnFirstConfig"
