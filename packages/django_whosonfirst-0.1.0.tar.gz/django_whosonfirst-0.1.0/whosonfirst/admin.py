"""Django admin configuration for Who's On First models."""

from django.contrib import admin
from django.contrib.gis.admin import GISModelAdmin
from django.utils.html import format_html

from .models import Place, PlaceName


class PlaceNameInline(admin.TabularInline):
    model = PlaceName
    extra = 0
    readonly_fields = ("name", "language", "name_type", "is_preferred")


@admin.register(Place)
class PlaceAdmin(GISModelAdmin):
    """Admin for Place model with GIS support."""

    list_display = (
        "wof_id",
        "name",
        "placetype",
        "country_code",
        "parent_link",
        "is_current",
        "geonames_link",
        "wikidata_link",
    )
    list_filter = (
        "placetype",
        "is_current",
        "is_deprecated",
        "country_code",
    )
    search_fields = (
        "wof_id",
        "name",
        "slug",
        "geonames_id",
        "wikidata_id",
    )
    readonly_fields = (
        "wof_id",
        "created_at",
        "updated_at",
        "parent_link",
        "geonames_link",
        "wikidata_link",
        "hierarchy_display",
        "belongsto_display",
    )
    raw_id_fields = ("parent",)
    inlines = [PlaceNameInline]

    fieldsets = (
        ("Identity", {
            "fields": (
                "wof_id",
                "name",
                "slug",
                "placetype",
                "country_code",
            )
        }),
        ("Hierarchy", {
            "fields": (
                "parent",
                "parent_link",
                "parent_wof_id",
                "belongsto_display",
                "hierarchy_display",
            )
        }),
        ("Location", {
            "fields": (
                "latitude",
                "longitude",
                "bbox",
                "centroid",
                "geom",
            ),
            "classes": ("collapse",),
        }),
        ("Concordances", {
            "fields": (
                "geonames_id",
                "geonames_link",
                "wikidata_id",
                "wikidata_link",
                "concordances",
            )
        }),
        ("Status", {
            "fields": (
                "is_current",
                "is_deprecated",
                "superseded_by",
                "supersedes",
                "lastmodified",
                "source_repo",
            )
        }),
        ("Timestamps", {
            "fields": ("created_at", "updated_at"),
            "classes": ("collapse",),
        }),
    )

    def parent_link(self, obj):
        """Link to parent place."""
        if obj.parent:
            url = f"/admin/whosonfirst/place/{obj.parent.wof_id}/change/"
            return format_html(
                '<a href="{}">{}</a>',
                url,
                obj.parent.name,
            )
        return "-"
    parent_link.short_description = "Parent"

    def geonames_link(self, obj):
        """Link to GeoNames."""
        if obj.geonames_id:
            url = f"https://www.geonames.org/{obj.geonames_id}/"
            return format_html(
                '<a href="{}" target="_blank">{}</a>',
                url,
                obj.geonames_id,
            )
        return "-"
    geonames_link.short_description = "GeoNames"

    def wikidata_link(self, obj):
        """Link to Wikidata."""
        if obj.wikidata_id:
            url = f"https://www.wikidata.org/wiki/{obj.wikidata_id}"
            return format_html(
                '<a href="{}" target="_blank">{}</a>',
                url,
                obj.wikidata_id,
            )
        return "-"
    wikidata_link.short_description = "Wikidata"

    def hierarchy_display(self, obj):
        """Display hierarchy JSON formatted."""
        if obj.hierarchy:
            import json
            return format_html(
                "<pre>{}</pre>",
                json.dumps(obj.hierarchy, indent=2),
            )
        return "-"
    hierarchy_display.short_description = "Hierarchy"

    def belongsto_display(self, obj):
        """Display belongsto with links."""
        if not obj.belongsto:
            return "-"

        links = []
        ancestors = Place.objects.filter(
            wof_id__in=obj.belongsto
        ).values_list("wof_id", "name", "placetype")

        for wof_id, name, placetype in ancestors:
            url = f"/admin/whosonfirst/place/{wof_id}/change/"
            links.append(
                f'<a href="{url}">{name}</a> ({placetype})'
            )

        return format_html("<br>".join(links))
    belongsto_display.short_description = "Belongs To"


@admin.register(PlaceName)
class PlaceNameAdmin(admin.ModelAdmin):
    """Admin for PlaceName model."""

    list_display = ("name", "place", "language", "name_type", "is_preferred")
    list_filter = ("language", "name_type", "is_preferred")
    search_fields = ("name", "place__name")
    raw_id_fields = ("place",)


