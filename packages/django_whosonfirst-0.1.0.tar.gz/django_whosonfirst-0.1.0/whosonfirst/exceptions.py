"""Custom exceptions for Who's On First import operations."""


class WOFException(Exception):
    """Base exception for Who's On First operations."""

    pass


class ValidationError(WOFException):
    """Raised when data validation fails during import."""

    pass


class DownloadError(WOFException):
    """Raised when file download fails."""

    pass


class ParseError(WOFException):
    """Raised when data parsing fails."""

    pass


class HookException(WOFException):
    """Raise in plugin hooks to skip the current item."""

    pass
