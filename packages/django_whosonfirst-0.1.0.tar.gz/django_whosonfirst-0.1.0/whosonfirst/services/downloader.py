"""
File download service for Who's On First data.

Handles downloading SQLite bundles from WOF distribution servers.
"""

import bz2
import logging
import os
import shutil
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import requests
from tqdm import tqdm

from ..conf import LOGGER_NAME, WOF_SQLITE_BASE_URL, get_wof_settings
from ..exceptions import DownloadError

logger = logging.getLogger(LOGGER_NAME)


class Downloader:
    """
    Service for downloading WOF data files.

    Supports:
    - SQLite bundles (compressed with bz2)
    - HTTP downloads with progress tracking
    - Local file caching
    """

    def __init__(self, data_dir: str = None, force: bool = False, quiet: bool = False):
        """
        Initialize the downloader.

        Args:
            data_dir: Directory to store downloaded files
            force: If True, re-download even if file exists
            quiet: If True, suppress progress output
        """
        settings = get_wof_settings()
        self.data_dir = Path(data_dir or settings.data_dir)
        self.force = force
        self.quiet = quiet
        self.timeout = settings.download_timeout
        self.max_size = settings.max_download_size

        # Ensure directories exist
        self.sqlite_dir = self.data_dir / "sqlite"
        self.sqlite_dir.mkdir(parents=True, exist_ok=True)

    def get_sqlite_url(self, country_code: str = None) -> str:
        """
        Get the download URL for a SQLite bundle.

        Args:
            country_code: ISO 3166-1 alpha-2 country code, or None for global

        Returns:
            Download URL
        """
        if country_code:
            # Per-country bundle
            return f"{WOF_SQLITE_BASE_URL}/whosonfirst-data-admin-{country_code.lower()}-latest.db.bz2"
        else:
            # Global admin bundle
            return f"{WOF_SQLITE_BASE_URL}/whosonfirst-data-admin-latest.db.bz2"

    def get_sqlite_path(self, country_code: str = None) -> Path:
        """
        Get the local path for a SQLite database.

        Args:
            country_code: ISO 3166-1 alpha-2 country code, or None for global

        Returns:
            Path to local SQLite file
        """
        if country_code:
            filename = f"whosonfirst-data-admin-{country_code.lower()}.db"
        else:
            filename = "whosonfirst-data-admin-latest.db"
        return self.sqlite_dir / filename

    def download_sqlite(
        self,
        country_code: str = None,
        url: str = None,
    ) -> Path:
        """
        Download a WOF SQLite bundle.

        Args:
            country_code: ISO 3166-1 alpha-2 country code, or None for global
            url: Optional custom URL to download from

        Returns:
            Path to the downloaded (and decompressed) SQLite file

        Raises:
            DownloadError: If download fails
        """
        if url is None:
            url = self.get_sqlite_url(country_code)

        db_path = self.get_sqlite_path(country_code)
        bz2_path = db_path.with_suffix(".db.bz2")

        # Check if already downloaded
        if db_path.exists() and not self.force:
            logger.info("Using cached SQLite database: %s", db_path)
            return db_path

        logger.info("Downloading WOF SQLite bundle from %s", url)

        try:
            # Download with progress bar
            self._download_file(url, bz2_path)

            # Decompress
            logger.info("Decompressing %s", bz2_path.name)
            self._decompress_bz2(bz2_path, db_path)

            # Remove compressed file
            bz2_path.unlink()

            logger.info("Downloaded and extracted: %s", db_path)
            return db_path

        except Exception as e:
            # Cleanup partial downloads
            for path in [bz2_path, db_path]:
                if path.exists():
                    path.unlink()
            raise DownloadError(f"Failed to download {url}: {e}") from e

    def _download_file(self, url: str, dest: Path) -> None:
        """
        Download a file with progress tracking.

        Args:
            url: URL to download
            dest: Destination path

        Raises:
            DownloadError: If download fails
        """
        try:
            response = requests.get(
                url,
                stream=True,
                timeout=self.timeout,
                headers={"User-Agent": "django-whosonfirst/0.1"},
            )
            response.raise_for_status()

            # Check content length
            total_size = int(response.headers.get("content-length", 0))
            if total_size > self.max_size:
                raise DownloadError(
                    f"File too large: {total_size} bytes (max {self.max_size})"
                )

            # Download with progress bar
            with open(dest, "wb") as f:
                with tqdm(
                    total=total_size,
                    unit="B",
                    unit_scale=True,
                    desc=dest.name,
                    disable=self.quiet,
                ) as pbar:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            pbar.update(len(chunk))

        except requests.RequestException as e:
            raise DownloadError(f"HTTP error downloading {url}: {e}") from e

    def _decompress_bz2(self, src: Path, dest: Path) -> None:
        """
        Decompress a bz2 file.

        Args:
            src: Source bz2 file
            dest: Destination file
        """
        with bz2.open(src, "rb") as f_in:
            with open(dest, "wb") as f_out:
                # Stream to avoid memory issues with large files
                shutil.copyfileobj(f_in, f_out, length=1024 * 1024)

    def list_available_bundles(self) -> list:
        """
        List available SQLite bundles in the cache.

        Returns:
            List of (country_code, path) tuples
        """
        bundles = []
        for path in self.sqlite_dir.glob("whosonfirst-data-admin-*.db"):
            name = path.stem
            # Extract country code from filename
            if name == "whosonfirst-data-admin-latest":
                bundles.append((None, path))
            else:
                code = name.replace("whosonfirst-data-admin-", "").upper()
                bundles.append((code, path))
        return sorted(bundles, key=lambda x: x[0] or "")

    def clear_cache(self, country_code: str = None) -> None:
        """
        Clear downloaded files from cache.

        Args:
            country_code: Specific country to clear, or None to clear all
        """
        if country_code:
            path = self.get_sqlite_path(country_code)
            if path.exists():
                path.unlink()
                logger.info("Removed cached file: %s", path)
        else:
            for path in self.sqlite_dir.glob("*.db"):
                path.unlink()
                logger.info("Removed cached file: %s", path)
