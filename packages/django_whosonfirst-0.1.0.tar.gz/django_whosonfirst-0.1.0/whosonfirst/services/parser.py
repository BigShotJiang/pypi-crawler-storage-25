"""
Data parser service for Who's On First SQLite databases.

Parses WOF SQLite bundles and yields place records with their properties.
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Generator, Optional

from ..conf import LOGGER_NAME, get_wof_settings
from ..exceptions import ParseError

logger = logging.getLogger(LOGGER_NAME)


class SQLiteParser:
    """
    Parser for WOF SQLite database bundles.

    WOF SQLite databases contain several tables:
    - spr: "Standard Places Response" - core place data
    - geojson: Full GeoJSON features
    - names: Alternative names
    - ancestors: Place ancestry relationships
    - concordances: External ID mappings
    """

    # SPR table columns (Standard Places Response)
    SPR_COLUMNS = [
        "id",
        "parent_id",
        "name",
        "placetype",
        "country",
        "repo",
        "latitude",
        "longitude",
        "min_latitude",
        "min_longitude",
        "max_latitude",
        "max_longitude",
        "is_current",
        "is_deprecated",
        "is_ceased",
        "is_superseded",
        "is_superseding",
        "superseded_by",
        "supersedes",
        "lastmodified",
    ]

    def __init__(self, db_path: Path, quiet: bool = False):
        """
        Initialize the parser.

        Args:
            db_path: Path to SQLite database file
            quiet: If True, suppress progress output
        """
        self.db_path = Path(db_path)
        self.quiet = quiet
        self.settings = get_wof_settings()

        if not self.db_path.exists():
            raise ParseError(f"Database not found: {db_path}")

    def get_connection(self) -> sqlite3.Connection:
        """
        Get a database connection.

        Returns:
            SQLite connection with row factory
        """
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def get_table_info(self) -> dict:
        """
        Get information about available tables.

        Returns:
            Dict mapping table names to row counts
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Get table names
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
            tables = [row[0] for row in cursor.fetchall()]

            # Get row counts
            info = {}
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                info[table] = cursor.fetchone()[0]

            return info

    def count_places(self, placetypes: list = None) -> int:
        """
        Count places matching the filter criteria.

        Args:
            placetypes: List of placetypes to include, or None for all

        Returns:
            Number of matching places
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()

            if placetypes:
                placeholders = ",".join("?" * len(placetypes))
                cursor.execute(
                    f"SELECT COUNT(*) FROM spr WHERE placetype IN ({placeholders})",
                    placetypes,
                )
            else:
                cursor.execute("SELECT COUNT(*) FROM spr")

            return cursor.fetchone()[0]

    def iter_places(
        self,
        placetypes: list = None,
        include_geojson: bool = True,
        batch_size: int = 1000,
    ) -> Generator[dict, None, None]:
        """
        Iterate over places in the database.

        Args:
            placetypes: List of placetypes to include, or None for all
            include_geojson: If True, include full GeoJSON with geometry
            batch_size: Number of records to fetch per query

        Yields:
            Dict with place data including:
            - spr: Standard Place Response data
            - geojson: Full GeoJSON feature (if include_geojson=True)
            - properties: Parsed properties from GeoJSON
            - geometry: GeoJSON geometry dict
            - names: List of alternative names
            - ancestors: List of ancestor records
            - concordances: Dict of external ID mappings
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Build query
            if placetypes:
                placeholders = ",".join("?" * len(placetypes))
                query = f"SELECT * FROM spr WHERE placetype IN ({placeholders})"
                params = placetypes
            else:
                query = "SELECT * FROM spr"
                params = []

            cursor.execute(query, params)

            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break

                for row in rows:
                    place_data = self._parse_spr_row(dict(row))

                    if include_geojson:
                        # Get full GeoJSON
                        geojson = self._get_geojson(conn, place_data["wof_id"])
                        if geojson:
                            place_data["geojson"] = geojson
                            place_data["properties"] = geojson.get("properties", {})
                            place_data["geometry"] = geojson.get("geometry")
                        else:
                            place_data["geojson"] = None
                            place_data["properties"] = {}
                            place_data["geometry"] = None

                    # Get alternative names
                    place_data["names"] = self._get_names(conn, place_data["wof_id"])

                    # Get concordances
                    place_data["concordances"] = self._get_concordances(
                        conn, place_data["wof_id"]
                    )

                    # Get ancestors
                    place_data["ancestors"] = self._get_ancestors(
                        conn, place_data["wof_id"]
                    )

                    yield place_data

    def _parse_spr_row(self, row: dict) -> dict:
        """
        Parse a row from the SPR table.

        Args:
            row: Dict from SPR table

        Returns:
            Normalized place data dict
        """
        return {
            "wof_id": row.get("id"),
            "parent_wof_id": row.get("parent_id"),
            "name": row.get("name", ""),
            "placetype": row.get("placetype", ""),
            "country_code": row.get("country", ""),
            "source_repo": row.get("repo", ""),
            "latitude": row.get("latitude"),
            "longitude": row.get("longitude"),
            "bbox": self._parse_bbox(row),
            "is_current": row.get("is_current", 1) == 1,
            "is_deprecated": row.get("is_deprecated", 0) == 1,
            "superseded_by": self._parse_json_list(row.get("superseded_by")),
            "supersedes": self._parse_json_list(row.get("supersedes")),
            "lastmodified": row.get("lastmodified"),
        }

    def _parse_bbox(self, row: dict) -> Optional[list]:
        """Parse bounding box from SPR row."""
        try:
            min_lon = row.get("min_longitude")
            min_lat = row.get("min_latitude")
            max_lon = row.get("max_longitude")
            max_lat = row.get("max_latitude")

            if all(v is not None for v in [min_lon, min_lat, max_lon, max_lat]):
                return [float(min_lon), float(min_lat), float(max_lon), float(max_lat)]
        except (ValueError, TypeError):
            pass
        return None

    def _parse_json_list(self, value) -> list:
        """Parse a JSON list from a database value."""
        if not value:
            return []
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return parsed
            except json.JSONDecodeError:
                pass
        return []

    def _get_geojson(self, conn: sqlite3.Connection, wof_id: int) -> Optional[dict]:
        """
        Get full GeoJSON feature for a place.

        Args:
            conn: Database connection
            wof_id: WOF ID

        Returns:
            GeoJSON feature dict or None
        """
        cursor = conn.cursor()
        cursor.execute(
            "SELECT body FROM geojson WHERE id = ?",
            (wof_id,)
        )
        row = cursor.fetchone()

        if row and row[0]:
            try:
                return json.loads(row[0])
            except json.JSONDecodeError:
                logger.warning("Invalid GeoJSON for WOF ID %s", wof_id)
        return None

    def _get_names(self, conn: sqlite3.Connection, wof_id: int) -> list:
        """
        Get alternative names for a place.

        Args:
            conn: Database connection
            wof_id: WOF ID

        Returns:
            List of name dicts with keys: name, language, type, is_preferred
        """
        cursor = conn.cursor()

        # Check if names table exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='names'"
        )
        if not cursor.fetchone():
            return []

        cursor.execute(
            """
            SELECT name, language, extlang, script, region, variant,
                   extension, privateuse, lastmodified
            FROM names WHERE id = ?
            """,
            (wof_id,)
        )

        names = []
        for row in cursor.fetchall():
            names.append({
                "name": row[0],
                "language": row[1] or "",
                "is_preferred": False,  # WOF names table doesn't have this
            })
        return names

    def _get_concordances(self, conn: sqlite3.Connection, wof_id: int) -> dict:
        """
        Get concordances (external ID mappings) for a place.

        Args:
            conn: Database connection
            wof_id: WOF ID

        Returns:
            Dict mapping external source to ID
        """
        cursor = conn.cursor()

        # Check if concordances table exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='concordances'"
        )
        if not cursor.fetchone():
            return {}

        cursor.execute(
            "SELECT other_source, other_id FROM concordances WHERE id = ?",
            (wof_id,)
        )

        concordances = {}
        for row in cursor.fetchall():
            if row[0] and row[1]:
                concordances[row[0]] = row[1]
        return concordances

    def _get_ancestors(self, conn: sqlite3.Connection, wof_id: int) -> list:
        """
        Get ancestor records for a place.

        Args:
            conn: Database connection
            wof_id: WOF ID

        Returns:
            List of ancestor dicts with keys: ancestor_id, ancestor_placetype
        """
        cursor = conn.cursor()

        # Check if ancestors table exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='ancestors'"
        )
        if not cursor.fetchone():
            return []

        cursor.execute(
            """
            SELECT ancestor_id, ancestor_placetype, lastmodified
            FROM ancestors WHERE id = ?
            """,
            (wof_id,)
        )

        ancestors = []
        for row in cursor.fetchall():
            if row[0]:
                ancestors.append({
                    "ancestor_id": row[0],
                    "ancestor_placetype": row[1] or "",
                })
        return ancestors

    def get_place_by_id(self, wof_id: int, include_geojson: bool = True) -> Optional[dict]:
        """
        Get a single place by WOF ID.

        Args:
            wof_id: WOF ID to look up
            include_geojson: If True, include full GeoJSON

        Returns:
            Place data dict or None
        """
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM spr WHERE id = ?", (wof_id,))
            row = cursor.fetchone()

            if not row:
                return None

            place_data = self._parse_spr_row(dict(row))

            if include_geojson:
                geojson = self._get_geojson(conn, wof_id)
                if geojson:
                    place_data["geojson"] = geojson
                    place_data["properties"] = geojson.get("properties", {})
                    place_data["geometry"] = geojson.get("geometry")

            place_data["names"] = self._get_names(conn, wof_id)
            place_data["concordances"] = self._get_concordances(conn, wof_id)
            place_data["ancestors"] = self._get_ancestors(conn, wof_id)

            return place_data
