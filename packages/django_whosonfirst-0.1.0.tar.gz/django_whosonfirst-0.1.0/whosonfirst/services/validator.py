"""
Data validation service for Who's On First import operations.
"""

import logging
from typing import Any, Optional

from django.contrib.gis.geos import Point

from ..conf import LOGGER_NAME
from ..exceptions import ValidationError

logger = logging.getLogger(LOGGER_NAME)


class Validator:
    """
    Validation utilities for WOF data import.

    Provides methods to parse and validate common data types,
    raising ValidationError on failure.
    """

    def parse_int(
        self,
        value: Any,
        field_name: str = "value",
        default: Optional[int] = None,
        allow_negative: bool = False,
    ) -> Optional[int]:
        """
        Parse an integer value.

        Args:
            value: Value to parse
            field_name: Field name for error messages
            default: Default if value is None/empty
            allow_negative: Whether to allow negative values

        Returns:
            Parsed integer or default

        Raises:
            ValidationError: If parsing fails
        """
        if value is None or value == "":
            return default

        try:
            # Handle float values like 6255147.0 from SQLite
            if isinstance(value, float):
                parsed = int(value)
            else:
                parsed = int(float(value)) if isinstance(value, str) and "." in value else int(value)
            if not allow_negative and parsed < 0:
                if default is not None:
                    return default
                raise ValidationError(f"{field_name}: negative value not allowed: {value}")
            return parsed
        except (ValueError, TypeError) as e:
            raise ValidationError(f"{field_name}: invalid integer: {value}") from e

    def parse_float(
        self,
        value: Any,
        field_name: str = "value",
        default: Optional[float] = None,
    ) -> Optional[float]:
        """
        Parse a float value.

        Args:
            value: Value to parse
            field_name: Field name for error messages
            default: Default if value is None/empty

        Returns:
            Parsed float or default

        Raises:
            ValidationError: If parsing fails
        """
        if value is None or value == "":
            return default

        try:
            return float(value)
        except (ValueError, TypeError) as e:
            raise ValidationError(f"{field_name}: invalid float: {value}") from e

    def parse_bool(
        self,
        value: Any,
        default: bool = False,
    ) -> bool:
        """
        Parse a boolean value.

        Handles various boolean representations:
        - True: True, 1, "1", "true", "yes", "t", "y"
        - False: False, 0, "0", "false", "no", "f", "n", -1

        Args:
            value: Value to parse
            default: Default if value is None/empty

        Returns:
            Parsed boolean
        """
        if value is None or value == "":
            return default

        if isinstance(value, bool):
            return value

        if isinstance(value, int):
            return value == 1

        if isinstance(value, str):
            return value.lower() in ("true", "1", "yes", "t", "y")

        return default

    def parse_location(
        self,
        latitude: Any,
        longitude: Any,
        entity_type: str = "place",
    ) -> Optional[Point]:
        """
        Parse latitude/longitude into a Point.

        Args:
            latitude: Latitude value
            longitude: Longitude value
            entity_type: Entity type for error messages

        Returns:
            Point geometry or None if coordinates are invalid

        Raises:
            ValidationError: If coordinates are clearly invalid
        """
        lat = self.parse_float(latitude, "latitude")
        lon = self.parse_float(longitude, "longitude")

        if lat is None or lon is None:
            return None

        # Validate coordinate ranges
        if not -90 <= lat <= 90:
            logger.warning(
                "%s: latitude out of range: %s",
                entity_type,
                lat,
            )
            return None

        if not -180 <= lon <= 180:
            logger.warning(
                "%s: longitude out of range: %s",
                entity_type,
                lon,
            )
            return None

        try:
            return Point(lon, lat, srid=4326)
        except Exception as e:
            logger.warning(
                "%s: failed to create Point(%s, %s): %s",
                entity_type,
                lon,
                lat,
                e,
            )
            return None

    def parse_wof_id(
        self,
        value: Any,
        field_name: str = "wof_id",
        required: bool = False,
    ) -> Optional[int]:
        """
        Parse a WOF ID value.

        WOF uses -1 and 0 to indicate "no parent" or "unknown".

        Args:
            value: Value to parse
            field_name: Field name for error messages
            required: If True, raise error if value is invalid

        Returns:
            WOF ID or None

        Raises:
            ValidationError: If required and value is invalid
        """
        parsed = self.parse_int(value, field_name, default=None, allow_negative=True)

        # WOF uses -1 and 0 for "none" / "unknown"
        if parsed is None or parsed <= 0:
            if required:
                raise ValidationError(f"{field_name}: valid WOF ID required")
            return None

        return parsed

    def parse_list(
        self,
        value: Any,
        item_parser=None,
    ) -> list:
        """
        Parse a list value.

        Args:
            value: Value to parse (list, tuple, or comma-separated string)
            item_parser: Optional function to parse each item

        Returns:
            List of parsed items
        """
        if value is None:
            return []

        if isinstance(value, (list, tuple)):
            items = list(value)
        elif isinstance(value, str):
            items = [v.strip() for v in value.split(",") if v.strip()]
        else:
            items = [value]

        if item_parser:
            parsed = []
            for item in items:
                try:
                    parsed_item = item_parser(item)
                    if parsed_item is not None:
                        parsed.append(parsed_item)
                except (ValueError, ValidationError):
                    pass
            return parsed

        return items

    def require_field(
        self,
        data: dict,
        field_name: str,
        entity_type: str = "record",
    ) -> Any:
        """
        Require a field to be present and non-empty.

        Args:
            data: Data dict to check
            field_name: Field name to require
            entity_type: Entity type for error messages

        Returns:
            Field value

        Raises:
            ValidationError: If field is missing or empty
        """
        value = data.get(field_name)
        if value is None or value == "":
            raise ValidationError(
                f"{entity_type}: required field '{field_name}' is missing or empty"
            )
        return value

    def validate_placetype(
        self,
        placetype: str,
        allowed_placetypes: list = None,
    ) -> bool:
        """
        Validate a placetype.

        Args:
            placetype: Placetype to validate
            allowed_placetypes: List of allowed placetypes, or None to allow all

        Returns:
            True if valid, False otherwise
        """
        if not placetype:
            return False

        if allowed_placetypes is None:
            return True

        return placetype in allowed_placetypes

    def validate_country_code(
        self,
        code: str,
        allowed_codes: list = None,
    ) -> bool:
        """
        Validate a country code.

        Args:
            code: ISO 3166-1 alpha-2 country code
            allowed_codes: List of allowed codes, or None to allow all

        Returns:
            True if valid, False otherwise
        """
        if not code:
            return True  # Empty is valid (for non-country entities)

        if len(code) != 2:
            return False

        if allowed_codes is None:
            return True

        return code.upper() in [c.upper() for c in allowed_codes]
