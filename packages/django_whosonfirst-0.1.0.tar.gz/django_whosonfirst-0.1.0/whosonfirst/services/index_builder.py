"""
Index building service for Who's On First import operations.

Builds in-memory indices for fast lookups during import.
"""

import logging
from typing import Dict, Optional

from ..conf import LOGGER_NAME
from ..models import Place

logger = logging.getLogger(LOGGER_NAME)


class IndexBuilder:
    """
    Builds in-memory indices for efficient lookups during import.

    Creates mappings from WOF IDs to Place objects for relationship resolution.
    """

    def __init__(self, quiet: bool = False):
        """
        Initialize the index builder.

        Args:
            quiet: If True, suppress progress output
        """
        self.quiet = quiet

    def build_place_index(
        self,
        placetypes: list = None,
        country_codes: list = None,
    ) -> Dict[int, Place]:
        """
        Build an index of existing places by WOF ID.

        Args:
            placetypes: Optional filter by placetypes
            country_codes: Optional filter by country codes

        Returns:
            Dict mapping wof_id to Place instance
        """
        logger.info("Building place index...")

        queryset = Place.objects.all()

        if placetypes:
            queryset = queryset.filter(placetype__in=placetypes)

        if country_codes:
            queryset = queryset.filter(country_code__in=country_codes)

        # Only fetch needed fields for memory efficiency
        queryset = queryset.only(
            "wof_id",
            "name",
            "placetype",
            "country_code",
            "parent_wof_id",
        )

        index = {place.wof_id: place for place in queryset.iterator()}

        logger.info("Built place index with %d entries", len(index))
        return index

    def build_wof_id_set(
        self,
        placetypes: list = None,
        country_codes: list = None,
    ) -> set:
        """
        Build a set of existing WOF IDs for fast membership testing.

        Args:
            placetypes: Optional filter by placetypes
            country_codes: Optional filter by country codes

        Returns:
            Set of wof_id values
        """
        logger.info("Building WOF ID set...")

        queryset = Place.objects.all()

        if placetypes:
            queryset = queryset.filter(placetype__in=placetypes)

        if country_codes:
            queryset = queryset.filter(country_code__in=country_codes)

        id_set = set(queryset.values_list("wof_id", flat=True))

        logger.info("Built WOF ID set with %d entries", len(id_set))
        return id_set

    def build_parent_index(self) -> Dict[int, int]:
        """
        Build an index mapping WOF IDs to their parent WOF IDs.

        Returns:
            Dict mapping wof_id to parent_wof_id
        """
        logger.info("Building parent index...")

        queryset = Place.objects.filter(
            parent_wof_id__isnull=False
        ).values_list("wof_id", "parent_wof_id")

        index = {wof_id: parent_id for wof_id, parent_id in queryset}

        logger.info("Built parent index with %d entries", len(index))
        return index

    def build_hierarchy_index(
        self,
        placetype: str,
    ) -> Dict[int, Place]:
        """
        Build an index of places by placetype for hierarchy resolution.

        Args:
            placetype: Placetype to index

        Returns:
            Dict mapping wof_id to Place instance
        """
        logger.info("Building %s index...", placetype)

        queryset = Place.objects.filter(
            placetype=placetype
        ).only("wof_id", "name", "country_code")

        index = {place.wof_id: place for place in queryset.iterator()}

        logger.info("Built %s index with %d entries", placetype, len(index))
        return index

    def build_country_index(self) -> Dict[str, Place]:
        """
        Build an index of countries by ISO code.

        Returns:
            Dict mapping country_code to Place instance
        """
        logger.info("Building country code index...")

        queryset = Place.objects.filter(
            placetype="country"
        ).only("wof_id", "name", "country_code")

        index = {}
        for place in queryset.iterator():
            if place.country_code:
                index[place.country_code.upper()] = place

        logger.info("Built country code index with %d entries", len(index))
        return index

    def build_geonames_index(self) -> Dict[int, Place]:
        """
        Build an index of places by GeoNames ID.

        Returns:
            Dict mapping geonames_id to Place instance
        """
        logger.info("Building GeoNames ID index...")

        queryset = Place.objects.filter(
            geonames_id__isnull=False
        ).only("wof_id", "name", "geonames_id")

        index = {place.geonames_id: place for place in queryset.iterator()}

        logger.info("Built GeoNames ID index with %d entries", len(index))
        return index

    def build_wikidata_index(self) -> Dict[str, Place]:
        """
        Build an index of places by Wikidata ID.

        Returns:
            Dict mapping wikidata_id to Place instance
        """
        logger.info("Building Wikidata ID index...")

        queryset = Place.objects.exclude(
            wikidata_id=""
        ).only("wof_id", "name", "wikidata_id")

        index = {place.wikidata_id: place for place in queryset.iterator()}

        logger.info("Built Wikidata ID index with %d entries", len(index))
        return index


def resolve_parent_relationships(batch_size: int = 1000) -> int:
    """
    Resolve parent_wof_id references to actual parent ForeignKey relationships.

    Call this after import to link places to their parents.

    Args:
        batch_size: Number of records to update per batch

    Returns:
        Number of relationships resolved
    """
    logger.info("Resolving parent relationships...")

    # Get all places with unresolved parent references
    places_to_update = Place.objects.filter(
        parent__isnull=True,
        parent_wof_id__isnull=False,
    ).values_list("wof_id", "parent_wof_id")

    # Build mapping of parent IDs we need
    parent_ids = set(p[1] for p in places_to_update)

    # Get parent places that exist
    existing_parents = set(
        Place.objects.filter(
            wof_id__in=parent_ids
        ).values_list("wof_id", flat=True)
    )

    # Update in batches
    updated = 0
    batch = []

    for wof_id, parent_wof_id in places_to_update:
        if parent_wof_id in existing_parents:
            batch.append((wof_id, parent_wof_id))

            if len(batch) >= batch_size:
                _update_parent_batch(batch)
                updated += len(batch)
                batch = []

    # Final batch
    if batch:
        _update_parent_batch(batch)
        updated += len(batch)

    logger.info("Resolved %d parent relationships", updated)
    return updated


def _update_parent_batch(batch: list) -> None:
    """Update a batch of parent relationships."""
    from django.db import connection

    # Use raw SQL for efficiency
    with connection.cursor() as cursor:
        for wof_id, parent_wof_id in batch:
            cursor.execute(
                "UPDATE whosonfirst_place SET parent_id = %s WHERE wof_id = %s",
                [parent_wof_id, wof_id]
            )
