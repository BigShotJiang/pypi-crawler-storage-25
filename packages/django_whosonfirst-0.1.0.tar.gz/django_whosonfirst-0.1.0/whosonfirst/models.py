"""
Django models for Who's On First geographic data.

These models store WOF places with their hierarchies, geometries, and concordances.
"""

from django.contrib.gis.db import models as gis_models
from django.contrib.postgres.indexes import GinIndex
from django.db import models

from .conf import PLACETYPE_HIERARCHY


class Place(models.Model):
    """
    A geographic place from Who's On First.

    Stores all administrative place types from continents to neighbourhoods.
    """

    # Identity
    wof_id = models.BigIntegerField(
        primary_key=True,
        help_text="Who's On First unique identifier",
    )
    placetype = models.CharField(
        max_length=50,
        db_index=True,
        help_text="WOF placetype (continent, country, region, locality, etc.)",
    )
    name = models.CharField(
        max_length=255,
        db_index=True,
        help_text="Primary name from wof:name",
    )
    slug = models.SlugField(
        max_length=255,
        blank=True,
        db_index=True,
        help_text="URL-friendly slug",
    )

    # Country info
    country_code = models.CharField(
        max_length=2,
        blank=True,
        db_index=True,
        help_text="ISO 3166-1 alpha-2 country code from wof:country",
    )

    # Hierarchy
    parent = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="children",
        help_text="Parent place from wof:parent_id",
    )
    parent_wof_id = models.BigIntegerField(
        null=True,
        blank=True,
        db_index=True,
        help_text="Raw parent WOF ID (for deferred resolution)",
    )
    belongsto = models.JSONField(
        default=list,
        blank=True,
        help_text="List of ancestor WOF IDs from wof:belongsto",
    )
    hierarchy = models.JSONField(
        default=list,
        blank=True,
        help_text="Full hierarchy from wof:hierarchy",
    )

    # Geometry
    geom = gis_models.MultiPolygonField(
        null=True,
        blank=True,
        srid=4326,
        help_text="Geometry (normalized to MultiPolygon)",
    )
    centroid = gis_models.PointField(
        null=True,
        blank=True,
        srid=4326,
        help_text="Centroid point for label placement",
    )
    latitude = models.FloatField(
        null=True,
        blank=True,
        help_text="Centroid latitude",
    )
    longitude = models.FloatField(
        null=True,
        blank=True,
        help_text="Centroid longitude",
    )
    bbox = models.JSONField(
        null=True,
        blank=True,
        help_text="Bounding box [minlon, minlat, maxlon, maxlat]",
    )

    # Concordances (external ID mappings)
    concordances = models.JSONField(
        default=dict,
        blank=True,
        help_text="External ID mappings from wof:concordances",
    )
    geonames_id = models.BigIntegerField(
        null=True,
        blank=True,
        db_index=True,
        help_text="GeoNames ID from concordances",
    )
    wikidata_id = models.CharField(
        max_length=20,
        blank=True,
        db_index=True,
        help_text="Wikidata QID from concordances",
    )

    # Metadata
    lastmodified = models.BigIntegerField(
        null=True,
        blank=True,
        help_text="Unix timestamp from wof:lastmodified",
    )
    is_current = models.BooleanField(
        default=True,
        db_index=True,
        help_text="Whether the place is current (not deprecated/ceased)",
    )
    is_deprecated = models.BooleanField(
        default=False,
        db_index=True,
        help_text="Whether the place is deprecated",
    )
    superseded_by = models.JSONField(
        default=list,
        blank=True,
        help_text="List of WOF IDs that supersede this record",
    )
    supersedes = models.JSONField(
        default=list,
        blank=True,
        help_text="List of WOF IDs this record supersedes",
    )

    # Source tracking
    source_repo = models.CharField(
        max_length=100,
        blank=True,
        help_text="Source repository or bundle name",
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Place"
        verbose_name_plural = "Places"
        ordering = ["placetype", "name"]
        indexes = [
            models.Index(fields=["placetype", "country_code"]),
            models.Index(fields=["placetype", "name"]),
            models.Index(fields=["country_code", "placetype"]),
            GinIndex(fields=["belongsto"], name="place_belongsto_gin"),
        ]

    def __str__(self):
        return f"{self.name} ({self.placetype})"

    def save(self, *args, **kwargs):
        # Auto-generate slug if not set
        if not self.slug:
            from .util import slugify
            base_slug = slugify(self.name)
            self.slug = f"{base_slug}-{self.wof_id}" if base_slug else str(self.wof_id)
        super().save(*args, **kwargs)

    @property
    def placetype_rank(self) -> int:
        """
        Return the rank of this placetype in the hierarchy.

        Lower numbers are larger areas (continent=0, country=2, etc.)
        """
        try:
            return PLACETYPE_HIERARCHY.index(self.placetype)
        except ValueError:
            return 999

    def get_ancestors(self):
        """
        Get all ancestor places based on belongsto.

        Returns:
            QuerySet of Place objects that this place belongs to
        """
        if not self.belongsto:
            return Place.objects.none()
        return Place.objects.filter(wof_id__in=self.belongsto).order_by("placetype")

    def get_descendants(self, placetype: str = None):
        """
        Get all descendant places.

        Args:
            placetype: Optional filter by placetype

        Returns:
            QuerySet of Place objects that belong to this place
        """
        qs = Place.objects.filter(belongsto__contains=[self.wof_id])
        if placetype:
            qs = qs.filter(placetype=placetype)
        return qs

    def get_country(self):
        """Get the country this place belongs to."""
        if self.placetype == "country":
            return self
        return Place.objects.filter(
            wof_id__in=self.belongsto,
            placetype="country"
        ).first()

    def get_region(self):
        """Get the region this place belongs to."""
        if self.placetype == "region":
            return self
        return Place.objects.filter(
            wof_id__in=self.belongsto,
            placetype="region"
        ).first()

    def get_locality(self):
        """Get the locality this place belongs to (or is)."""
        if self.placetype == "locality":
            return self
        return Place.objects.filter(
            wof_id__in=self.belongsto,
            placetype="locality"
        ).first()


class PlaceName(models.Model):
    """
    Alternative names for a place in various languages.

    Stores translated and alternative names from WOF name:* properties.
    """

    place = models.ForeignKey(
        Place,
        on_delete=models.CASCADE,
        related_name="names",
    )
    name = models.CharField(
        max_length=255,
        db_index=True,
    )
    language = models.CharField(
        max_length=10,
        blank=True,
        db_index=True,
        help_text="ISO 639-3 language code",
    )
    name_type = models.CharField(
        max_length=20,
        blank=True,
        choices=[
            ("preferred", "Preferred"),
            ("variant", "Variant"),
            ("colloquial", "Colloquial"),
            ("historical", "Historical"),
            ("official", "Official"),
            ("", "Unknown"),
        ],
        help_text="Type of name (preferred, variant, etc.)",
    )
    is_preferred = models.BooleanField(
        default=False,
        db_index=True,
    )

    class Meta:
        verbose_name = "Place Name"
        verbose_name_plural = "Place Names"
        unique_together = [("place", "name", "language")]
        indexes = [
            models.Index(fields=["language", "is_preferred"]),
        ]

    def __str__(self):
        lang = f" ({self.language})" if self.language else ""
        return f"{self.name}{lang}"


