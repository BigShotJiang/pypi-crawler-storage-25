"""
Place importer for Who's On First data.

Uses bulk operations for high-performance import of large datasets.
"""

import logging
from pathlib import Path
from typing import Optional, Tuple

from django.contrib.gis.geos import Point
from django.db import transaction
from tqdm import tqdm

from ..conf import CONCORDANCE_KEYS, LOGGER_NAME, get_wof_settings
from ..exceptions import ValidationError
from ..models import Place, PlaceName
from ..services import SQLiteParser
from ..services.index_builder import resolve_parent_relationships
from ..util import (
    extract_bbox,
    extract_concordances,
    extract_label_point,
    get_name_from_properties,
    is_current,
    normalize_geometry,
    parse_wof_id,
    parse_wof_ids,
    slugify,
)
from .base import BaseImporter

logger = logging.getLogger(LOGGER_NAME)

# Batch size for bulk operations
BULK_BATCH_SIZE = 2000


class PlaceImporter(BaseImporter):
    """
    Importer for WOF places.

    Imports administrative places from WOF SQLite bundles into the Place model.
    """

    def __init__(self, command, options: dict):
        super().__init__(command, options)

        # Additional options
        self.import_names = options.get("import_names", True)
        self.resolve_parents = options.get("resolve_parents", True)

        # Track created places for relationship resolution
        self.created_wof_ids = set()

    def get_model_class(self) -> type:
        return Place

    def build_indices(self) -> None:
        """Build indices for efficient lookups."""
        # Get set of existing WOF IDs for update detection
        self.existing_ids = self.index_builder.build_wof_id_set()
        logger.info("Found %d existing places", len(self.existing_ids))

    def parse_item(self, item: dict) -> Optional[dict]:
        """
        Parse a place item from the SQLite parser.

        Args:
            item: Dict containing:
                - wof_id, name, placetype, country_code, etc. (from SPR)
                - properties: Full WOF properties (from GeoJSON)
                - geometry: GeoJSON geometry
                - names: Alternative names
                - concordances: External ID mappings
                - ancestors: Ancestor records

        Returns:
            Dict of Place model fields, or None to skip
        """
        settings = get_wof_settings()

        # Extract basic fields
        wof_id = self.validator.parse_wof_id(
            item.get("wof_id"),
            field_name="wof_id",
            required=True,
        )
        if wof_id is None:
            return None

        placetype = item.get("placetype", "")
        if not placetype:
            logger.debug("Skipping record without placetype: %s", wof_id)
            return None

        # Filter by placetype
        if self.placetypes and placetype not in self.placetypes:
            return None

        # Get properties from GeoJSON if available
        properties = item.get("properties", {})

        # Check if current/deprecated
        item_is_current = item.get("is_current", True)
        item_is_deprecated = item.get("is_deprecated", False)

        # Use properties to get more accurate status
        if properties:
            item_is_current = is_current(properties)
            item_is_deprecated = bool(properties.get("edtf:deprecated"))

        # Skip deprecated if configured
        if settings.skip_deprecated and item_is_deprecated:
            return None

        # Skip not current if configured
        if settings.skip_not_current and not item_is_current:
            return None

        # Get name
        name = item.get("name", "")
        if not name and properties:
            name = get_name_from_properties(properties)
        if not name:
            logger.debug("Skipping record without name: %s", wof_id)
            return None

        # Filter by country code
        country_code = item.get("country_code", "").upper()
        if self.country_codes:
            # Allow records without country code (continents, etc.)
            if country_code and country_code not in self.country_codes:
                return None

        # Parse parent
        parent_wof_id = self.validator.parse_wof_id(
            item.get("parent_wof_id"),
            field_name="parent_wof_id",
        )

        # Parse geometry
        geometry = None
        if settings.import_geometry and item.get("geometry"):
            geometry = normalize_geometry(item["geometry"])

        # Parse centroid
        lat, lon = extract_label_point(properties) if properties else (None, None)
        if lat is None:
            lat = self.validator.parse_float(item.get("latitude"), "latitude")
        if lon is None:
            lon = self.validator.parse_float(item.get("longitude"), "longitude")

        centroid = None
        if lat is not None and lon is not None:
            centroid = self.validator.parse_location(lat, lon, f"place {wof_id}")

        # Parse bbox
        bbox = item.get("bbox")
        if not bbox and properties:
            bbox = extract_bbox(properties, item.get("geometry"))

        # Parse hierarchy
        belongsto = []
        if item.get("ancestors"):
            belongsto = [a["ancestor_id"] for a in item["ancestors"] if a.get("ancestor_id")]
        elif properties:
            belongsto = parse_wof_ids(properties.get("wof:belongsto", []))

        hierarchy = properties.get("wof:hierarchy", []) if properties else []

        # Parse concordances
        concordances = item.get("concordances", {})
        if properties and not concordances:
            concordances = properties.get("wof:concordances", {})

        normalized_concordances = extract_concordances(concordances)

        # Extract specific concordance IDs
        # Allow negative values during parsing, then filter them out
        # (WOF uses -99 etc. as sentinel for "unknown")
        geonames_id = self.validator.parse_int(
            normalized_concordances.get("geonames_id"),
            "geonames_id",
            default=None,
            allow_negative=True,
        )
        # Treat negative/zero values as "no ID"
        if geonames_id is not None and geonames_id <= 0:
            geonames_id = None
        wikidata_id = normalized_concordances.get("wikidata_id", "")
        if wikidata_id and not wikidata_id.startswith("Q"):
            wikidata_id = ""

        # Parse supersession
        superseded_by = item.get("superseded_by", [])
        if not superseded_by and properties:
            superseded_by = parse_wof_ids(properties.get("wof:superseded_by", []))

        supersedes = item.get("supersedes", [])
        if not supersedes and properties:
            supersedes = parse_wof_ids(properties.get("wof:supersedes", []))

        # Generate slug
        slug = slugify(name)
        if slug:
            slug = f"{slug}-{wof_id}"
        else:
            slug = str(wof_id)

        return {
            "wof_id": wof_id,
            "placetype": placetype,
            "name": name[:255],
            "slug": slug[:255],
            "country_code": country_code[:2] if country_code else "",
            "parent_wof_id": parent_wof_id,
            "belongsto": belongsto,
            "hierarchy": hierarchy,
            "geom": geometry,
            "centroid": centroid,
            "latitude": lat,
            "longitude": lon,
            "bbox": bbox,
            "concordances": normalized_concordances,
            "geonames_id": geonames_id,
            "wikidata_id": wikidata_id[:20] if wikidata_id else "",
            "lastmodified": item.get("lastmodified"),
            "is_current": item_is_current,
            "is_deprecated": item_is_deprecated,
            "superseded_by": superseded_by,
            "supersedes": supersedes,
            "source_repo": item.get("source_repo", "")[:100],
            # Store raw names for separate import
            "_names": item.get("names", []),
        }

    def _process_database(self, db_path: Path) -> None:
        """
        Process a single database file using bulk operations.

        Overrides the base implementation for high-performance bulk import.

        Args:
            db_path: Path to SQLite database
        """
        logger.info("Processing database: %s (bulk mode)", db_path.name)

        parser = SQLiteParser(db_path, quiet=self.quiet)

        # Get count for progress bar
        total = parser.count_places(placetypes=self.placetypes)
        logger.info("Found %d places to process", total)

        # Batch accumulators
        batch_new = []
        batch_update = []
        batch_names = []

        # Iterate with progress bar
        with tqdm(
            total=total,
            desc=self.get_description(),
            disable=self.quiet,
        ) as pbar:
            for item in parser.iter_places(
                placetypes=self.placetypes,
                include_geojson=self.settings.import_geometry,
            ):
                self.stats["processed"] += 1

                try:
                    # Parse item
                    parsed = self.parse_item(item)
                    if parsed is None:
                        self.stats["skipped"] += 1
                        pbar.update(1)
                        continue

                    if self.dry_run:
                        pbar.update(1)
                        continue

                    # Extract names for later bulk insert
                    names = parsed.pop("_names", [])
                    wof_id = parsed["wof_id"]

                    # Check if new or existing
                    if wof_id not in self.existing_ids:
                        batch_new.append(parsed)
                        self.existing_ids.add(wof_id)
                        self.created_wof_ids.add(wof_id)
                    else:
                        batch_update.append(parsed)

                    # Collect names
                    if self.import_names and names:
                        batch_names.append((wof_id, names))

                    # Flush all batches together when any reaches threshold
                    # This ensures places exist before their names are inserted
                    if (len(batch_new) >= BULK_BATCH_SIZE or
                        len(batch_update) >= BULK_BATCH_SIZE or
                        len(batch_names) >= BULK_BATCH_SIZE):
                        # Always flush places first, then names
                        if batch_new:
                            self._bulk_create_places(batch_new)
                            batch_new = []
                        if batch_update:
                            self._bulk_update_places(batch_update)
                            batch_update = []
                        if batch_names:
                            self._bulk_import_names(batch_names)
                            batch_names = []

                except ValidationError as e:
                    logger.warning("Validation error: %s", e)
                    self.stats["skipped"] += 1
                    raise  # Stop on error for debugging

                except Exception as e:
                    logger.error("Error processing item: %s", e, exc_info=True)
                    self.stats["errors"] += 1
                    raise  # Stop on error for debugging

                pbar.update(1)

        # Flush remaining batches
        if batch_new:
            self._bulk_create_places(batch_new)
        if batch_update:
            self._bulk_update_places(batch_update)
        if batch_names:
            self._bulk_import_names(batch_names)

        logger.info(
            "Bulk import complete: %d created, %d updated",
            self.stats["created"],
            self.stats["updated"],
        )

    def _bulk_create_places(self, batch: list) -> None:
        """
        Bulk create new Place records.

        Args:
            batch: List of parsed place dicts
        """
        if not batch:
            return

        places = []
        for parsed in batch:
            # Extract fields without modifying original dict
            wof_id = parsed["wof_id"]
            geom = parsed.get("geom")
            centroid = parsed.get("centroid")

            # Build kwargs excluding special fields
            kwargs = {k: v for k, v in parsed.items()
                      if k not in ("wof_id", "geom", "centroid")}

            place = Place(wof_id=wof_id, **kwargs)
            if geom:
                place.geom = geom
            if centroid:
                place.centroid = centroid
            places.append(place)

        with transaction.atomic():
            Place.objects.bulk_create(places, ignore_conflicts=True)

        self.stats["created"] += len(places)
        logger.debug("Bulk created %d places", len(places))

    def _bulk_update_places(self, batch: list) -> None:
        """
        Bulk update existing Place records.

        Args:
            batch: List of parsed place dicts
        """
        if not batch:
            return

        # Fields to update (exclude wof_id which is the PK)
        update_fields = [
            "placetype", "name", "slug", "country_code",
            "parent_wof_id", "belongsto", "hierarchy",
            "geom", "centroid", "latitude", "longitude", "bbox",
            "concordances", "geonames_id", "wikidata_id",
            "lastmodified", "is_current", "is_deprecated",
            "superseded_by", "supersedes", "source_repo",
        ]

        places = []
        for parsed in batch:
            # Extract fields without modifying original dict
            wof_id = parsed["wof_id"]
            geom = parsed.get("geom")
            centroid = parsed.get("centroid")

            # Build kwargs excluding special fields
            kwargs = {k: v for k, v in parsed.items()
                      if k not in ("wof_id", "geom", "centroid")}

            place = Place(wof_id=wof_id, **kwargs)
            if geom:
                place.geom = geom
            if centroid:
                place.centroid = centroid
            places.append(place)

        with transaction.atomic():
            Place.objects.bulk_update(places, update_fields, batch_size=500)

        self.stats["updated"] += len(places)
        logger.debug("Bulk updated %d places", len(places))

    def _bulk_import_names(self, batch: list) -> None:
        """
        Bulk import alternative names.

        Args:
            batch: List of (wof_id, names_list) tuples
        """
        if not batch:
            return

        wof_ids = [wof_id for wof_id, _ in batch]

        # Verify which places actually exist (defensive check)
        existing_place_ids = set(
            Place.objects.filter(wof_id__in=wof_ids).values_list("wof_id", flat=True)
        )

        # Filter batch to only include existing places
        batch = [(wof_id, names) for wof_id, names in batch if wof_id in existing_place_ids]
        if not batch:
            return

        wof_ids = [wof_id for wof_id, _ in batch]

        # Delete existing names for these places
        PlaceName.objects.filter(place_id__in=wof_ids).delete()

        # Get language filter from settings (empty list = import all)
        languages = self.settings.languages

        # Collect all name objects
        name_objects = []
        seen = {}  # Track unique (place_id, name, language) combinations

        for wof_id, names in batch:
            for name_data in names:
                name = name_data.get("name", "")[:255]
                language = name_data.get("language", "")[:10]

                if not name:
                    continue

                # Filter by language if configured
                if languages and language not in languages:
                    continue

                # Avoid duplicates within this batch
                key = (wof_id, name, language)
                if key in seen:
                    continue
                seen[key] = True

                name_objects.append(
                    PlaceName(
                        place_id=wof_id,
                        name=name,
                        language=language,
                        is_preferred=name_data.get("is_preferred", False),
                    )
                )

        if name_objects:
            with transaction.atomic():
                PlaceName.objects.bulk_create(name_objects, ignore_conflicts=True)

        logger.debug("Bulk imported %d names for %d places", len(name_objects), len(batch))

    @transaction.atomic
    def create_or_update(self, parsed: dict) -> Tuple[Place, bool]:
        """
        Create or update a Place record (single-record fallback).

        This method is kept for compatibility but the bulk _process_database
        method is used by default for better performance.

        Args:
            parsed: Parsed data from parse_item()

        Returns:
            Tuple of (Place instance, created boolean)
        """
        wof_id = parsed.pop("wof_id")
        names = parsed.pop("_names", [])

        # Separate geometry fields (can't use update_or_create with them directly)
        geom = parsed.pop("geom", None)
        centroid = parsed.pop("centroid", None)

        # Check if exists
        is_new = wof_id not in self.existing_ids

        if is_new:
            # Create new place
            place = Place(wof_id=wof_id, **parsed)
            if geom:
                place.geom = geom
            if centroid:
                place.centroid = centroid
            place.save()
            created = True
            self.existing_ids.add(wof_id)
            self.created_wof_ids.add(wof_id)
        else:
            # Update existing
            place, created = Place.objects.update_or_create(
                wof_id=wof_id,
                defaults=parsed,
            )
            # Update geometry separately if provided
            if geom or centroid:
                if geom:
                    place.geom = geom
                if centroid:
                    place.centroid = centroid
                place.save(update_fields=["geom", "centroid"])

        # Import alternative names
        if self.import_names and names:
            self._import_names(place, names)

        return place, created

    def _import_names(self, place: Place, names: list) -> None:
        """
        Import alternative names for a place.

        Args:
            place: Place instance
            names: List of name dicts
        """
        if not names:
            return

        # Delete existing names for this place
        PlaceName.objects.filter(place=place).delete()

        # Get language filter from settings (empty list = import all)
        languages = self.settings.languages

        # Create new names
        name_objects = []
        seen = set()

        for name_data in names:
            name = name_data.get("name", "")[:255]
            language = name_data.get("language", "")[:10]

            if not name:
                continue

            # Filter by language if configured
            if languages and language not in languages:
                continue

            # Avoid duplicates
            key = (name, language)
            if key in seen:
                continue
            seen.add(key)

            name_objects.append(
                PlaceName(
                    place=place,
                    name=name,
                    language=language,
                    is_preferred=name_data.get("is_preferred", False),
                )
            )

        if name_objects:
            PlaceName.objects.bulk_create(name_objects, ignore_conflicts=True)

    def cleanup(self) -> None:
        """
        Post-import cleanup: resolve parent relationships.
        """
        if self.resolve_parents and not self.dry_run:
            logger.info("Resolving parent relationships...")
            resolved = resolve_parent_relationships(
                batch_size=self.settings.batch_size
            )
            logger.info("Resolved %d parent relationships", resolved)
