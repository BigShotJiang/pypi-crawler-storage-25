"""Basic smoke tests — verify the script is importable and version is set."""

import importlib.util
import io
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

ROOT = Path(__file__).parent.parent
SCRIPT = ROOT / "altergo.py"


def _load_altergo():
    spec = importlib.util.spec_from_file_location("altergo", SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# Load once at module level so monkeypatching targets the same object.
import altergo  # noqa: E402  (import after path manipulation is fine here)


def test_version_set():
    mod = _load_altergo()
    assert mod.__version__, "version must be non-empty"
    parts = mod.__version__.split(".")
    assert len(parts) == 3, "version must be semver (x.y.z)"


def test_version_flag(tmp_path):
    result = subprocess.run(
        [sys.executable, str(SCRIPT), "--version"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0
    assert "altergo" in result.stdout.lower()


def test_help_flag(tmp_path):
    result = subprocess.run(
        [sys.executable, str(SCRIPT), "--help"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def fake_home(tmp_path, monkeypatch):
    """Isolated fake HOME layout.

    Creates the directory skeleton expected by altergo:
      <tmp>/main_home/        ← MAIN_HOME
      <tmp>/main_home/.claude/ ← MAIN_CLAUDE
      <tmp>/main_home/.altergo/accounts/ ← ACCOUNTS_DIR

    Patches the altergo module globals so every function under test uses
    tmp_path instead of the real ~/.
    """
    main_home = tmp_path / "main_home"
    main_claude = main_home / ".claude"
    accounts_dir = main_home / ".altergo" / "accounts"

    main_home.mkdir()
    main_claude.mkdir(parents=True)
    accounts_dir.mkdir(parents=True)

    monkeypatch.setattr(altergo, "MAIN_HOME", main_home)
    monkeypatch.setattr(altergo, "MAIN_CLAUDE", main_claude)
    monkeypatch.setattr(altergo, "ACCOUNTS_DIR", accounts_dir)
    monkeypatch.setattr(altergo, "SETTINGS_FILE", main_home / ".altergo" / ".altergo.json")

    return {
        "main_home": main_home,
        "main_claude": main_claude,
        "accounts_dir": accounts_dir,
    }


# ---------------------------------------------------------------------------
# T6 — Account tests
# ---------------------------------------------------------------------------


def test_unknown_account_error(tmp_path):
    """altergo <name> where the account dir doesn't exist exits 1 with a useful message."""
    # Use a fresh accounts dir with no accounts in it.
    result = subprocess.run(
        [sys.executable, str(SCRIPT), "wokr"],
        capture_output=True,
        text=True,
        env={
            **__import__("os").environ,
            # Point ALTERGO_ACCOUNTS_DIR isn't a real env var — we drive this
            # via the process-level env that sets HOME to a clean tmp dir so
            # that detect_legacy() sees no legacy layout and ACCOUNTS_DIR
            # resolves to a path with no "wokr" subdirectory.
            "HOME": str(tmp_path),
        },
    )
    assert result.returncode == 1
    assert "wokr" in result.stderr
    assert "not found" in result.stderr
    assert "--setup --name wokr" in result.stderr


def test_validate_account_name_valid():
    """validate_account_name raises nothing for a well-formed name."""
    # Should complete without raising.
    altergo.validate_account_name("work")
    altergo.validate_account_name("client-a")
    altergo.validate_account_name("acct_2")


def test_validate_account_name_reserved():
    """validate_account_name raises SystemExit for a reserved name."""
    with pytest.raises(SystemExit):
        altergo.validate_account_name("default")


def test_validate_account_name_bad_chars():
    """validate_account_name raises SystemExit when the name contains spaces."""
    with pytest.raises(SystemExit):
        altergo.validate_account_name("my account")


def test_list_accounts_empty(fake_home):
    """list_accounts returns [] when ACCOUNTS_DIR does not exist."""
    # Remove the accounts dir that fake_home created.
    import shutil
    shutil.rmtree(str(fake_home["accounts_dir"]))
    assert altergo.list_accounts() == []


def test_list_accounts_populated(fake_home):
    """list_accounts returns sorted account names for all subdirectories."""
    accounts_dir = fake_home["accounts_dir"]
    (accounts_dir / "work").mkdir()
    (accounts_dir / "personal").mkdir()
    # Hidden directories should not appear.
    (accounts_dir / ".hidden").mkdir()

    result = altergo.list_accounts()
    assert result == ["personal", "work"]


# ---------------------------------------------------------------------------
# T7 — Migration tests
# ---------------------------------------------------------------------------


@pytest.fixture()
def legacy_home(tmp_path, monkeypatch):
    """Fake HOME with the old (pre-v0.5) layout: ~/.altergo/.claude/ exists."""
    main_home = tmp_path / "main_home"
    legacy_claude = main_home / ".altergo" / ".claude"
    legacy_claude.mkdir(parents=True)
    # Write a sentinel file so we can verify it survived the migration.
    (legacy_claude / ".credentials.json").write_text('{"token": "test"}')

    # ACCOUNTS_DIR does NOT exist yet — that is the trigger condition.
    accounts_dir = main_home / ".altergo" / "accounts"

    monkeypatch.setattr(altergo, "MAIN_HOME", main_home)
    monkeypatch.setattr(altergo, "MAIN_CLAUDE", main_home / ".claude")
    monkeypatch.setattr(altergo, "ACCOUNTS_DIR", accounts_dir)
    monkeypatch.setattr(altergo, "SETTINGS_FILE", main_home / ".altergo" / ".altergo.json")

    return {
        "main_home": main_home,
        "accounts_dir": accounts_dir,
    }


def test_detect_legacy_true(legacy_home):
    """detect_legacy returns True when ~/.altergo/.claude/ exists and accounts/ does not."""
    assert altergo.detect_legacy() is True


def test_detect_legacy_false_new(fake_home):
    """detect_legacy returns False when accounts/ already exists (new layout)."""
    assert altergo.detect_legacy() is False


def test_detect_legacy_false_clean(tmp_path, monkeypatch):
    """detect_legacy returns False when neither .claude/ nor accounts/ exists."""
    main_home = tmp_path / "clean_home"
    main_home.mkdir()
    monkeypatch.setattr(altergo, "MAIN_HOME", main_home)
    monkeypatch.setattr(altergo, "ACCOUNTS_DIR", main_home / ".altergo" / "accounts")

    assert altergo.detect_legacy() is False


def test_migrate_legacy_layout(legacy_home):
    """After migrate_legacy(), the old .claude/ content lives under accounts/default/.claude/."""
    altergo.migrate_legacy()

    default_claude = legacy_home["accounts_dir"] / "default" / ".claude"
    assert default_claude.is_dir()
    assert (default_claude / ".credentials.json").exists()


def test_migrate_legacy_backup(legacy_home):
    """After migrate_legacy(), a backup exists at ~/.altergo-legacy-backup/ (outside the tree)."""
    altergo.migrate_legacy()

    backup = legacy_home["main_home"] / ".altergo-legacy-backup"
    assert backup.is_dir(), f"Expected backup at {backup}"
    # Backup preserves the original content.
    assert (backup / ".claude" / ".credentials.json").exists()


def test_migrate_legacy_prints_once(legacy_home, capsys):
    """migrate_legacy() prints a migration block (not silence) exactly once."""
    altergo.migrate_legacy()

    captured = capsys.readouterr()
    out = captured.out
    # Must mention both the new location and the backup in its output.
    assert "accounts/default" in out
    assert ".altergo-legacy-backup" in out
    # Must not print anything on a second run (idempotent — covered by separate test).
    altergo.migrate_legacy()
    assert capsys.readouterr().out == ""


def test_migrate_legacy_idempotent(legacy_home, capsys):
    """Running migrate_legacy() twice produces no error and no output on the second run."""
    altergo.migrate_legacy()
    capsys.readouterr()  # discard first-run output

    # Second call: accounts/ already exists, so migration is skipped.
    altergo.migrate_legacy()

    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


# ---------------------------------------------------------------------------
# T8 — Symlink audit tests
# ---------------------------------------------------------------------------


def _create_main_claude_sources(main_claude: Path):
    """Create the source dirs/files in MAIN_CLAUDE that do_setup() will symlink."""
    for name in altergo.SYMLINK_DIRS:
        (main_claude / name).mkdir(parents=True, exist_ok=True)
    for name in altergo.SYMLINK_FILES:
        (main_claude / name).touch()


def _create_catalog_sources(main_home: Path):
    """Create source paths in MAIN_HOME for every default_on catalog entry."""
    for entry in altergo.CATALOG:
        if entry["default_on"]:
            for rel in entry["paths"]:
                src = main_home / rel
                src.mkdir(parents=True, exist_ok=True)


def test_setup_creates_claude_symlinks(fake_home):
    """do_setup() creates symlinks for SYMLINK_DIRS inside account_home/.claude/."""
    main_claude = fake_home["main_claude"]
    accounts_dir = fake_home["accounts_dir"]
    _create_main_claude_sources(main_claude)

    altergo.do_setup("work")

    account_claude = accounts_dir / "work" / ".claude"
    for name in altergo.SYMLINK_DIRS:
        link = account_claude / name
        assert link.is_symlink(), f"{name}/ should be a symlink inside account .claude/"
        assert link.resolve() == (main_claude / name).resolve()


def test_setup_creates_claude_file_symlinks(fake_home):
    """do_setup() creates symlinks for SYMLINK_FILES inside account_home/.claude/."""
    main_claude = fake_home["main_claude"]
    accounts_dir = fake_home["accounts_dir"]
    _create_main_claude_sources(main_claude)

    altergo.do_setup("work")

    account_claude = accounts_dir / "work" / ".claude"
    for name in altergo.SYMLINK_FILES:
        link = account_claude / name
        assert link.is_symlink(), f"{name} should be a symlink inside account .claude/"
        assert link.resolve() == (main_claude / name).resolve()


def test_setup_creates_home_dir_symlinks(fake_home):
    """do_setup() creates CATALOG symlinks at account_home level pointing into MAIN_HOME."""
    main_home = fake_home["main_home"]
    accounts_dir = fake_home["accounts_dir"]
    _create_main_claude_sources(fake_home["main_claude"])
    _create_catalog_sources(main_home)

    altergo.do_setup("work")

    account_home = accounts_dir / "work"
    for entry in altergo.CATALOG:
        if not entry["default_on"]:
            continue
        for rel in entry["paths"]:
            link = account_home / rel
            src = main_home / rel
            assert link.is_symlink(), f"~/{rel} should be a symlink at account_home level"
            assert link.resolve() == src.resolve(), f"~/{rel} must point into MAIN_HOME"


def test_symlinks_no_escape(fake_home):
    """All symlink targets inside account_home/.claude/ resolve within MAIN_HOME/.claude/."""
    main_claude = fake_home["main_claude"]
    accounts_dir = fake_home["accounts_dir"]
    _create_main_claude_sources(main_claude)

    altergo.do_setup("work")

    account_claude = accounts_dir / "work" / ".claude"
    for link in account_claude.iterdir():
        if not link.is_symlink():
            continue
        resolved = link.resolve()
        # The target must live inside MAIN_HOME/.claude/, never outside it.
        try:
            resolved.relative_to(main_claude.resolve())
        except ValueError:
            pytest.fail(
                f"Symlink {link.name} escapes MAIN_CLAUDE: target is {resolved}"
            )


def test_teardown_removes_symlinks(fake_home):
    """do_teardown() removes all symlinks that do_setup() created."""
    main_home = fake_home["main_home"]
    main_claude = fake_home["main_claude"]
    accounts_dir = fake_home["accounts_dir"]
    _create_main_claude_sources(main_claude)
    _create_catalog_sources(main_home)

    altergo.do_setup("work")
    altergo.do_teardown("work")

    account_claude = accounts_dir / "work" / ".claude"
    account_home = accounts_dir / "work"

    # All .claude/ symlinks must be gone.
    for name in altergo.SYMLINK_DIRS:
        assert not (account_claude / name).is_symlink(), f"{name}/ symlink should be removed"

    for name in altergo.SYMLINK_FILES:
        assert not (account_claude / name).is_symlink(), f"{name} symlink should be removed"

    # All CATALOG symlinks at account_home level must be gone.
    for entry in altergo.CATALOG:
        if not entry["default_on"]:
            continue
        for rel in entry["paths"]:
            link = account_home / rel
            assert not link.is_symlink(), f"~/{rel} symlink should be removed after teardown"


# ---------------------------------------------------------------------------
# T9 — _ensure_symlinked_dir / _sweep_existing_accounts
# ---------------------------------------------------------------------------


@pytest.fixture()
def sweep_home(tmp_path, monkeypatch):
    """Isolated fake HOME with main .claude/ sources but NO account dirs yet.

    MAIN_CLAUDE/projects and other SYMLINK_DIRS exist as real dirs.
    No accounts are created — tests create them manually to control state.
    """
    main_home = tmp_path / "main_home"
    main_claude = main_home / ".claude"
    accounts_dir = main_home / ".altergo" / "accounts"

    for name in altergo.SYMLINK_DIRS:
        (main_claude / name).mkdir(parents=True, exist_ok=True)
    for name in altergo.SYMLINK_FILES:
        (main_claude / name).touch()

    accounts_dir.mkdir(parents=True, exist_ok=True)

    monkeypatch.setattr(altergo, "MAIN_HOME", main_home)
    monkeypatch.setattr(altergo, "MAIN_CLAUDE", main_claude)
    monkeypatch.setattr(altergo, "ACCOUNTS_DIR", accounts_dir)
    monkeypatch.setattr(altergo, "SETTINGS_FILE", main_home / ".altergo" / ".altergo.json")

    return {
        "main_home": main_home,
        "main_claude": main_claude,
        "accounts_dir": accounts_dir,
    }


def test_resume_after_legacy_migration(sweep_home):
    """Regression: after migration the session stored in account_claude/projects
    is moved to MAIN_CLAUDE/projects and account_claude/projects becomes a
    symlink — so get_sessions() can find it and --resume works.

    This is the exact bug: 0.5 → 0.6 migration left a real dir at
    accounts/default/.claude/projects/ while Claude Code wrote sessions there.
    get_sessions() reads MAIN_CLAUDE/projects/, so those sessions were invisible.
    """
    main_claude = sweep_home["main_claude"]
    accounts_dir = sweep_home["accounts_dir"]

    # Simulate the post-migration state: account exists with a real (non-empty)
    # projects dir that contains a session, while MAIN_CLAUDE/projects is empty.
    account_home = accounts_dir / "default"
    account_claude = account_home / ".claude"
    account_projects = account_claude / "projects"
    proj_dir = account_projects / "test-project"
    proj_dir.mkdir(parents=True, exist_ok=True)
    session_file = proj_dir / "abc123.jsonl"
    session_file.write_text('{"type":"user","message":{"content":"hello"}}\n')

    # MAIN_CLAUDE/projects exists but is empty (as left by migration).
    # (Already created by sweep_home fixture.)
    assert not list((main_claude / "projects").iterdir()), "precondition: main projects dir empty"

    # Run the sweep — this is what main() calls after migrate_legacy().
    altergo._sweep_existing_accounts()

    # (a) session now lives in MAIN_CLAUDE/projects
    main_session = main_claude / "projects" / "test-project" / "abc123.jsonl"
    assert main_session.exists(), (
        "Session was not promoted to MAIN_CLAUDE/projects — get_sessions() won't find it"
    )
    assert main_session.read_text() == '{"type":"user","message":{"content":"hello"}}\n'

    # (b) account_claude/projects is now a symlink
    assert account_projects.is_symlink(), (
        "account_claude/projects must be a symlink after sweep"
    )
    assert account_projects.resolve() == (main_claude / "projects").resolve(), (
        "account_claude/projects symlink must point to MAIN_CLAUDE/projects"
    )

    # (c) session is readable through the symlink (as Claude Code does it)
    via_symlink = account_claude / "projects" / "test-project" / "abc123.jsonl"
    assert via_symlink.exists(), "Session not readable via account symlink"
    assert via_symlink.read_text() == main_session.read_text()


def test_merge_conflict_quarantine(sweep_home):
    """When both src and dst have a file with the same name, the dst file is
    moved to a quarantine directory and a warning is printed.
    """
    main_claude = sweep_home["main_claude"]
    accounts_dir = sweep_home["accounts_dir"]

    # Populate MAIN_CLAUDE/projects with one version of a session file.
    proj_dir_main = main_claude / "projects" / "foo"
    proj_dir_main.mkdir(parents=True, exist_ok=True)
    (proj_dir_main / "bar.jsonl").write_text("main-version\n")

    # Populate account_claude/projects with a *conflicting* version.
    account_home = accounts_dir / "default"
    account_claude = account_home / ".claude"
    proj_dir_acct = account_claude / "projects" / "foo"
    proj_dir_acct.mkdir(parents=True, exist_ok=True)
    (proj_dir_acct / "bar.jsonl").write_text("account-version\n")

    with patch("sys.stdout", new_callable=io.StringIO) as mock_out:
        altergo._sweep_existing_accounts()
        output = mock_out.getvalue()

    # The main version must be untouched.
    assert (proj_dir_main / "bar.jsonl").read_text() == "main-version\n", (
        "MAIN_CLAUDE/projects/foo/bar.jsonl must not be modified"
    )

    # The conflicting account version must be quarantined.
    quarantine = account_claude / "projects.altergo-conflict" / "foo" / "bar.jsonl"
    assert quarantine.exists(), (
        f"Conflicting file not found in quarantine at {quarantine}"
    )
    assert quarantine.read_text() == "account-version\n"

    # A warning must be printed.
    assert "conflict" in output.lower(), (
        f"Expected conflict warning in output, got: {output!r}"
    )


def test_list_then_resume_roundtrip(sweep_home):
    """Session written to MAIN_CLAUDE/projects/ is found by get_sessions() and
    is reachable via account_claude/projects/ (the path Claude Code uses when
    HOME=account_home).  This is the full --list then --resume chain.
    """
    main_claude = sweep_home["main_claude"]
    accounts_dir = sweep_home["accounts_dir"]

    # Set up a properly-symlinked default account.
    altergo.do_setup("default")

    account_home = accounts_dir / "default"
    account_claude = account_home / ".claude"

    # Write a session into MAIN_CLAUDE/projects (as Claude Code would do).
    proj_dir = main_claude / "projects" / "myproject"
    proj_dir.mkdir(parents=True, exist_ok=True)
    session_id = "deadbeef1234"
    session_content = '{"type":"user","message":{"content":"what is 2+2?"}}\n'
    (proj_dir / f"{session_id}.jsonl").write_text(session_content)

    # get_sessions() must find it (it reads MAIN_CLAUDE/projects).
    sessions = altergo.get_sessions()
    session_ids = [s["id"] for s in sessions]
    assert session_id in session_ids, (
        f"Session {session_id!r} not found by get_sessions(); found: {session_ids}"
    )

    # The session file must be reachable via the account symlink
    # (this is the path Claude Code sees when HOME=account_home).
    via_account = account_claude / "projects" / "myproject" / f"{session_id}.jsonl"
    assert via_account.exists(), (
        "Session file not reachable via account_claude/projects symlink — "
        "--resume would fail after --list found the session"
    )
    assert via_account.read_text() == session_content


def test_credentials_not_in_symlink_dirs_or_files():
    """.credentials.json must not appear in SYMLINK_DIRS or SYMLINK_FILES.

    Credentials are per-account by design; symlinking them would collapse
    account isolation entirely.
    """
    assert ".credentials.json" not in altergo.SYMLINK_DIRS
    assert ".credentials.json" not in altergo.SYMLINK_FILES
    assert "credentials" not in altergo.SYMLINK_DIRS
    assert "credentials" not in altergo.SYMLINK_FILES


def test_ensure_symlinked_dir_empty_real_dir(sweep_home, capsys):
    """Case (c): empty real dir is replaced by a symlink."""
    main_claude = sweep_home["main_claude"]
    accounts_dir = sweep_home["accounts_dir"]

    account_home = accounts_dir / "work"
    account_claude = account_home / ".claude"
    account_claude.mkdir(parents=True, exist_ok=True)

    # Create an empty real dir at dst
    dst = account_claude / "projects"
    dst.mkdir()
    src = main_claude / "projects"

    result = altergo._ensure_symlinked_dir("projects", src, dst, account_claude)

    assert result is True
    assert dst.is_symlink(), "Empty real dir must become a symlink"
    assert dst.resolve() == src.resolve()
    captured = capsys.readouterr()
    assert "Converted" in captured.out


def test_ensure_symlinked_dir_noop_when_correct(sweep_home):
    """Case (a): already a correct symlink — no-op, returns False."""
    main_claude = sweep_home["main_claude"]
    accounts_dir = sweep_home["accounts_dir"]

    account_home = accounts_dir / "work"
    account_claude = account_home / ".claude"
    account_claude.mkdir(parents=True, exist_ok=True)

    src = main_claude / "projects"
    dst = account_claude / "projects"
    dst.symlink_to(src)

    result = altergo._ensure_symlinked_dir("projects", src, dst, account_claude)
    assert result is False
