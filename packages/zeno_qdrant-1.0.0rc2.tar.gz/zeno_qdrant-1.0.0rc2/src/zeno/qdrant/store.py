"""`QdrantKnowledgeStore` — `zeno.memory.protocols.KnowledgeStore` over Qdrant.

Design notes:
  - `qdrant-client`'s `AsyncQdrantClient` is natively async — no
    `asyncio.to_thread` wrapping needed (unlike ChromaDB).
  - A single collection with `user_id` in the payload. Query-time
    payload filter enforces multi-tenant isolation.
  - The collection is lazily auto-created on first `add()`. The
    vector is computed via Qdrant's bundled FastEmbed (small local
    model) by default; callers may override by passing a pre-computed
    embedding in `meta["embedding"]`.

We use the default FastEmbed model (`BAAI/bge-small-en-v1.5`, 384 dims
via `AsyncQdrantClient.add`/`query` which auto-embed documents when
`qdrant-client[fastembed]` is installed). This keeps the baseline
test path free of external embedding services.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from zeno.memory.protocols import MemoryHit

if TYPE_CHECKING:
    from qdrant_client import AsyncQdrantClient


_DEFAULT_COLLECTION = "zeno_knowledge"


class QdrantKnowledgeStore:
    """Shared knowledge store backed by an AsyncQdrantClient (local or remote)."""

    def __init__(
        self,
        path: str | Path | None = None,
        *,
        url: str | None = None,
        collection_name: str = _DEFAULT_COLLECTION,
        api_key: str | None = None,
    ) -> None:
        from qdrant_client import AsyncQdrantClient

        if path is None and url is None:
            raise ValueError(
                "QdrantKnowledgeStore requires either `path=` (local file store) "
                "or `url=` (running Qdrant server)"
            )
        if path is not None and url is not None:
            raise ValueError("QdrantKnowledgeStore: pass exactly one of `path=` or `url=`")
        if path is not None:
            self._client: AsyncQdrantClient = AsyncQdrantClient(path=str(path))
        else:
            self._client = AsyncQdrantClient(url=url, api_key=api_key)
        self._collection = collection_name

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Insert `text` tagged with `user_id` into the shared collection."""
        if not text.strip():
            raise ValueError("QdrantKnowledgeStore.add: text must be non-empty")
        payload: dict[str, Any] = {"user_id": user_id, "text": text, **(meta or {})}
        await self._client.add(
            collection_name=self._collection,
            documents=[text],
            metadata=[payload],
        )

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        """User-scoped similarity search; returns at most `k` hits."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        if k <= 0:
            return []
        user_filter = Filter(must=[FieldCondition(key="user_id", match=MatchValue(value=user_id))])
        results = await self._client.query(
            collection_name=self._collection,
            query_text=query,
            limit=k,
            query_filter=user_filter,
        )
        hits: list[MemoryHit] = []
        for item in results:
            text = item.document if hasattr(item, "document") else str(item)
            score = float(getattr(item, "score", 0.0))
            meta = dict(getattr(item, "metadata", {}) or {})
            hits.append(MemoryHit(text=text, score=score, meta=meta))
        return hits
