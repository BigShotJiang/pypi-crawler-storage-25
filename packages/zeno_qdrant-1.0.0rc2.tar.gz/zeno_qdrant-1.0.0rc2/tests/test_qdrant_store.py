"""`QdrantKnowledgeStore` integration tests.

These spin up an embedded Qdrant via `AsyncQdrantClient(path=...)` and
rely on the `fastembed` extra for document vectorization. The first run
downloads the default FastEmbed model; subsequent runs reuse the cache.
Marked `slow` so lightweight CI jobs can skip while full-CI and local
runs exercise the end-to-end path.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest
from zeno.qdrant.store import QdrantKnowledgeStore

_HAS_FASTEMBED = importlib.util.find_spec("fastembed") is not None


@pytest.mark.slow
@pytest.mark.skipif(not _HAS_FASTEMBED, reason="qdrant-client[fastembed] not installed")
async def test_add_then_search_roundtrip(tmp_path: Path) -> None:
    store = QdrantKnowledgeStore(path=tmp_path / "qdrant")
    await store.add("alice", "alice likes ramen")

    hits = await store.search("alice", "ramen")

    assert hits
    assert any("ramen" in h.text.lower() for h in hits)


@pytest.mark.slow
@pytest.mark.skipif(not _HAS_FASTEMBED, reason="qdrant-client[fastembed] not installed")
async def test_cross_user_isolation(tmp_path: Path) -> None:
    store = QdrantKnowledgeStore(path=tmp_path / "qdrant")
    await store.add("alice", "alice secret")
    await store.add("bob", "bob secret")

    alice_hits = await store.search("alice", "secret")
    bob_hits = await store.search("bob", "secret")

    assert all("bob" not in h.text for h in alice_hits)
    assert all("alice" not in h.text for h in bob_hits)


async def test_requires_path_or_url() -> None:
    with pytest.raises(ValueError, match="path=|url="):
        QdrantKnowledgeStore()


async def test_rejects_both_path_and_url(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="exactly one"):
        QdrantKnowledgeStore(path=tmp_path, url="http://localhost:6333")


async def test_empty_text_rejected(tmp_path: Path) -> None:
    store = QdrantKnowledgeStore(path=tmp_path / "qdrant")
    with pytest.raises(ValueError):
        await store.add("alice", "   ")
