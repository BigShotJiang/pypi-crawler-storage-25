import logging
import os

logger = logging.getLogger(__name__)

# Default port numbers
DEFAULT_KAFKA_BROKER_PORT = 9092
DEFAULT_CLICKHOUSE_PORT = 8123

# Scoring worker defaults
DEFAULT_SCORING_WORKER_BATCH_SIZE = 100
DEFAULT_SCORING_WORKER_BATCH_TIMEOUT = 5

# ClickHouse async insert timeout defaults (milliseconds)
DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MIN_MS = 100
DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MAX_MS = 1000

# Kafka Settings


def kafka_broker_host() -> str:
    """The host of the kafka broker."""
    return os.environ.get("KAFKA_BROKER_HOST", "localhost")


def kafka_broker_port() -> int:
    """The port of the kafka broker."""
    return int(os.environ.get("KAFKA_BROKER_PORT", str(DEFAULT_KAFKA_BROKER_PORT)))


def kafka_client_user() -> str | None:
    """The username for the kafka client."""
    return os.environ.get("KAFKA_CLIENT_USER")


def kafka_client_password() -> str | None:
    """The password for the kafka client."""
    return os.environ.get("KAFKA_CLIENT_PASSWORD")


def kafka_producer_max_buffer_size() -> int | None:
    """The maximum number of messages in the Kafka producer buffer."""
    size = os.environ.get("KAFKA_PRODUCER_MAX_BUFFER_SIZE")
    if size is None:
        return None
    try:
        return int(size)
    except ValueError:
        logger.exception("KAFKA_PRODUCER_MAX_BUFFER_SIZE value '%s' is not valid", size)
        return None


def kafka_partition_by_project_id() -> bool:
    """Whether to partition Kafka messages by project_id.

    When enabled, messages are partitioned by project_id to ensure all messages
    for a given project go to the same partition. When disabled, messages are
    distributed round-robin across partitions. Can be safely toggled without
    having to rebalanc/re-partition the topic.
    """
    return os.environ.get("KAFKA_PARTITION_BY_PROJECT_ID", "false").lower() == "true"


# Scoring worker settings


def wf_enable_online_eval() -> bool:
    """Whether to enable online evaluation."""
    return os.environ.get("WEAVE_ENABLE_ONLINE_EVAL", "false").lower() == "true"


def wf_scoring_worker_batch_size() -> int:
    """The batch size for the scoring worker."""
    return int(
        os.environ.get(
            "WF_SCORING_WORKER_BATCH_SIZE", str(DEFAULT_SCORING_WORKER_BATCH_SIZE)
        )
    )


def wf_scoring_worker_batch_timeout() -> int:
    """The timeout for the scoring worker."""
    return int(
        os.environ.get(
            "WF_SCORING_WORKER_BATCH_TIMEOUT", str(DEFAULT_SCORING_WORKER_BATCH_TIMEOUT)
        )
    )


def wf_scoring_worker_check_cancellation() -> bool:
    """Whether to check for cancellation on every poll for faster shutdown.

    When enabled, the worker checks for cancellation on every poll, allowing
    faster graceful shutdown. Useful for tests. Defaults to False.
    """
    return (
        os.environ.get("SCORING_WORKER_CHECK_CANCELLATION", "false").lower() == "true"
    )


def wf_scoring_worker_kafka_consumer_group_id_override() -> str | None:
    """The Kafka consumer group ID override for the scoring worker.

    Returns the override value if set via SCORING_WORKER_KAFKA_CONSUMER_GROUP_ID,
    otherwise returns None. The scoring worker will use its own default if None.
    Useful for tests to set a unique value per test run to avoid offset issues.
    """
    return os.environ.get("SCORING_WORKER_KAFKA_CONSUMER_GROUP_ID")


def wf_scoring_worker_debounced_scoring_max_sampling_rate() -> float:
    """Max sampling rate cap for debounced scoring (delay > 0). 0.0 = disable, 1.0 = no cap beyond monitor rate."""
    default = 0.0
    raw = os.environ.get(
        "WF_SCORING_WORKER_DEBOUNCED_SCORING_MAX_SAMPLING_RATE", str(default)
    )
    try:
        rate = float(raw)
    except ValueError:
        return default
    return max(0.0, min(1.0, rate))


def wf_scoring_worker_debounced_scoring_max_call_history() -> int:
    """Max number of prior calls to fetch per task when aggregation_method is 'all_messages'. 0 = disabled."""
    default = 0
    raw = os.environ.get(
        "WF_SCORING_WORKER_DEBOUNCED_SCORING_MAX_CALL_HISTORY", str(default)
    )
    try:
        value = int(raw)
    except ValueError:
        return default
    return max(0, value)


# Clickhouse Settings


def wf_clickhouse_host() -> str:
    """The host of the clickhouse server."""
    return os.environ.get("WF_CLICKHOUSE_HOST", "localhost")


def wf_clickhouse_port() -> int:
    """The port of the clickhouse server."""
    return int(os.environ.get("WF_CLICKHOUSE_PORT", str(DEFAULT_CLICKHOUSE_PORT)))


def wf_clickhouse_user() -> str:
    """The user of the clickhouse server."""
    return os.environ.get("WF_CLICKHOUSE_USER", "default")


def wf_clickhouse_pass() -> str:
    """The password of the clickhouse server."""
    return os.environ.get("WF_CLICKHOUSE_PASS", "")


def wf_clickhouse_database() -> str:
    """The name of the clickhouse database."""
    return os.environ.get("WF_CLICKHOUSE_DATABASE", "default")


def wf_clickhouse_replicated() -> bool:
    """Whether to use replicated clickhouse tables."""
    return os.environ.get("WF_CLICKHOUSE_REPLICATED", "false").lower() == "true"


def wf_clickhouse_replicated_path() -> str | None:
    """The path of the replicated clickhouse tables."""
    return os.environ.get("WF_CLICKHOUSE_REPLICATED_PATH")


def wf_clickhouse_replicated_cluster() -> str | None:
    """The cluster of the replicated clickhouse tables."""
    return os.environ.get("WF_CLICKHOUSE_REPLICATED_CLUSTER")


def wf_clickhouse_use_distributed_tables() -> bool:
    """Whether to use distributed tables on top of replicated tables."""
    return (
        os.environ.get("WF_CLICKHOUSE_USE_DISTRIBUTED_TABLES", "false").lower()
        == "true"
    )


VALID_CALLS_SHARD_KEYS = frozenset({"trace_id", "id", "project_id"})


def wf_clickhouse_calls_shard_key() -> str:
    """The column used as shard key for calls_complete in distributed mode.

    Valid values: "trace_id" (default), "id", "project_id".

    Raises:
        ValueError: If the configured shard key is not one of the valid values.
    """
    key = os.environ.get("WF_CLICKHOUSE_CALLS_SHARD_KEY", "trace_id")
    if key not in VALID_CALLS_SHARD_KEYS:
        raise ValueError(
            f"Invalid WF_CLICKHOUSE_CALLS_SHARD_KEY: {key!r}. "
            f"Must be one of: {', '.join(sorted(VALID_CALLS_SHARD_KEYS))}"
        )
    return key


def wf_clickhouse_max_memory_usage() -> int | None:
    """The maximum memory usage for the clickhouse server."""
    mem = os.environ.get("WF_CLICKHOUSE_MAX_MEMORY_USAGE")
    if mem is None:
        return None
    try:
        return int(mem)
    except ValueError:
        logger.exception("WF_CLICKHOUSE_MAX_MEMORY_USAGE value '%s' is not valid", mem)
        return None


def wf_clickhouse_max_execution_time() -> int | None:
    """The maximum execution time for the clickhouse server."""
    time = os.environ.get("WF_CLICKHOUSE_MAX_EXECUTION_TIME")
    if time is None:
        return None
    try:
        return int(time)
    except ValueError:
        logger.exception(
            "WF_CLICKHOUSE_MAX_EXECUTION_TIME value '%s' is not valid", time
        )
        return None


def wf_clickhouse_async_insert_busy_timeout_min_ms() -> int:
    """The minimum async insert busy timeout in milliseconds for ClickHouse.

    When async_insert_use_adaptive_busy_timeout is enabled, this sets the lower
    bound and initial value for the adaptive flush interval. Lower values flush
    sooner under low load.
    """
    env_key = "WF_CLICKHOUSE_ASYNC_INSERT_BUSY_TIMEOUT_MIN_MS"
    val = os.environ.get(env_key)
    if val is None:
        return DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MIN_MS
    try:
        return int(val)
    except ValueError:
        logger.exception(
            "WF_CLICKHOUSE_ASYNC_INSERT_BUSY_TIMEOUT_MIN_MS value '%s' is not valid",
            val,
        )
        return DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MIN_MS


def wf_clickhouse_disable_lightweight_update() -> bool:
    """Disable ClickHouse lightweight UPDATE/DELETE support.

    Set to 'true' for old ClickHouse versions that do not support the
    allow_experimental_lightweight_update setting. When disabled, endpoints
    that rely on lightweight updates will return a 502 error.
    """
    return (
        os.environ.get("WF_CLICKHOUSE_DISABLE_LIGHTWEIGHT_UPDATE", "false").lower()
        == "true"
    )


def wf_clickhouse_async_insert_busy_timeout_max_ms() -> int:
    """The maximum async insert busy timeout in milliseconds for ClickHouse.

    When async_insert_use_adaptive_busy_timeout is enabled, this sets the upper
    bound for how long ClickHouse will wait before flushing the async insert
    buffer. The adaptive algorithm starts at async_insert_busy_timeout_min_ms
    and adjusts up to this value based on load.
    """
    env_key = "WF_CLICKHOUSE_ASYNC_INSERT_BUSY_TIMEOUT_MAX_MS"
    val = os.environ.get(env_key)
    if val is None:
        return DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MAX_MS
    try:
        return int(val)
    except ValueError:
        logger.exception(
            "WF_CLICKHOUSE_ASYNC_INSERT_BUSY_TIMEOUT_MAX_MS value '%s' is not valid",
            val,
        )
        return DEFAULT_ASYNC_INSERT_BUSY_TIMEOUT_MAX_MS


# BYOB Settings


def wf_file_storage_uri() -> str | None:
    """The storage bucket URI."""
    return os.environ.get("WF_FILE_STORAGE_URI")


def wf_file_storage_project_allow_list() -> list[str] | None:
    """Get the list of project IDs allowed to use file storage.

    Returns:
        Optional[list[str]]: A list of project IDs that are allowed to use file storage.
            Returns None if no allow list is configured.

    Raises:
        ValueError: If the allow list environment variable is set but contains invalid data.
            The value must be a comma-separated list of non-empty project IDs.
    """
    allow_list = os.environ.get("WF_FILE_STORAGE_PROJECT_ALLOW_LIST")
    if allow_list is None:
        return None
    try:
        project_ids = [pid.strip() for pid in allow_list.split(",") if pid.strip()]
    except Exception as e:
        raise ValueError(
            f"WF_FILE_STORAGE_PROJECT_ALLOW_LIST is not a valid comma-separated list: {allow_list}. Error: {e!s}"
        ) from e

    return project_ids


def wf_storage_bucket_aws_access_key_id() -> str | None:
    """The AWS access key ID."""
    return os.environ.get("WF_FILE_STORAGE_AWS_ACCESS_KEY_ID")


def wf_storage_bucket_aws_secret_access_key() -> str | None:
    """The AWS secret access key."""
    return os.environ.get("WF_FILE_STORAGE_AWS_SECRET_ACCESS_KEY")


def wf_storage_bucket_aws_session_token() -> str | None:
    """The AWS session token."""
    return os.environ.get("WF_FILE_STORAGE_AWS_SESSION_TOKEN")


def wf_storage_bucket_aws_kms_key() -> str | None:
    """The AWS KMS key."""
    return os.environ.get("WF_FILE_STORAGE_AWS_KMS_KEY")


def wf_storage_bucket_aws_region() -> str | None:
    """The AWS region."""
    return os.environ.get("WF_FILE_STORAGE_AWS_REGION")


def wf_storage_bucket_azure_connection_string() -> str | None:
    """The Azure connection string."""
    return os.environ.get("WF_FILE_STORAGE_AZURE_CONNECTION_STRING")


def wf_storage_bucket_azure_access_key() -> str | None:
    """The Azure credential."""
    return os.environ.get("WF_FILE_STORAGE_AZURE_ACCESS_KEY")


def wf_storage_bucket_azure_account_url() -> str | None:
    """The Azure account url (optional override)."""
    return os.environ.get("WF_FILE_STORAGE_AZURE_ACCOUNT_URL")


def wf_storage_bucket_gcp_credentials_json_b64() -> str | None:
    """The GCP credentials JSON string (base64 encoded)."""
    return os.environ.get("WF_FILE_STORAGE_GCP_CREDENTIALS_JSON_B64")


def wf_file_storage_project_ramp_pct() -> int | None:
    """The percentage of projects that should use file storage (0-100).

    Returns:
        Optional[int]: The percentage of projects that should use file storage.
            Returns None if not configured.

    Raises:
        ValueError: If the value is not a valid integer between 0 and 100.
    """
    pct_str = os.environ.get("WF_FILE_STORAGE_PROJECT_RAMP_PCT")
    if not pct_str:
        return None

    try:
        pct = int(pct_str)
    except ValueError as e:
        raise ValueError(
            f"WF_FILE_STORAGE_PROJECT_RAMP_PCT is not a valid integer: {pct_str}. Error: {e!s}"
        ) from e

    if pct < 0 or pct > 100:
        raise ValueError(
            f"WF_FILE_STORAGE_PROJECT_RAMP_PCT must be between 0 and 100, got {pct}"
        )

    return pct


# Inference Service Settings


def inference_service_base_url() -> str:
    """The base URL for the inference service."""
    return os.environ.get(
        "INFERENCE_SERVICE_BASE_URL", "https://api.inference.wandb.ai/v1"
    )


# Redis Settings


def redis_url() -> str | None:
    """Redis connection URL (e.g., redis://127.0.0.1:6379)."""
    return os.environ.get("WEAVE_REDIS_URL")
