from .arrpy import IsNotArrayError

def check(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError