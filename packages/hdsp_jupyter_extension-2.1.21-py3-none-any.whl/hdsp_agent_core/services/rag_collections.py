"""
RAG Collection Manager — 4개 컬렉션(enterprise_tables, bdp_tables, guide_docs, ds_guide_docs) 관리.

핵심 기능:
- 동적 CSV 파싱 (관리자 매핑 기반)
- 마크다운 헤더 기반 시맨틱 청킹
- LLM 청크 요약 임베딩
- 비-md 파일 → 마크다운 변환 (draw.io XML 포함 시 Mermaid 자동 변환)
- 적재 프리뷰, 데이터 브라우저, 검색 테스트, 이력 관리
"""

from __future__ import annotations

import asyncio
import csv
import hashlib
import json
import logging
import os
import re
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

import httpx

logger = logging.getLogger(__name__)

HISTORY_PATH = os.path.expanduser("~/.jupyter/hdsp_rag_history.json")

# 4개 컬렉션 이름
COLLECTION_ENTERPRISE = "enterprise_tables"
COLLECTION_BDP = "bdp_tables"
COLLECTION_GUIDE = "guide_docs"
COLLECTION_DS_GUIDE = "ds_guide_docs"
ALL_COLLECTIONS = [
    COLLECTION_ENTERPRISE,
    COLLECTION_BDP,
    COLLECTION_GUIDE,
    COLLECTION_DS_GUIDE,
]
# guide 계열 컬렉션 (디렉토리 기반 적재)
GUIDE_COLLECTIONS = {COLLECTION_GUIDE, COLLECTION_DS_GUIDE}

# 청킹 기본값
DEFAULT_CHUNKING = {
    "target_size": 800,
    "min_size": 150,
    "max_size": 2000,
    "overlap": 0,
}

# ------------------------------------------------------------------
# 매니저 레지스트리 (chat_service에서 RAG 가용성 체크용)
# ------------------------------------------------------------------
_manager_instance: Optional["RAGCollectionManager"] = None


def register_manager(mgr: "RAGCollectionManager") -> None:
    """RAGCollectionManager 싱글톤 등록."""
    global _manager_instance
    _manager_instance = mgr


def get_manager() -> Optional["RAGCollectionManager"]:
    """등록된 RAGCollectionManager 반환."""
    return _manager_instance


def is_rag_available() -> bool:
    """RAG가 사용 가능한지 빠르게 확인. 매니저 등록 여부만 체크."""
    return _manager_instance is not None


class RAGCollectionManager:
    """3개 RAG 컬렉션의 생성/적재/삭제/검색을 관리."""

    def __init__(
        self,
        qdrant_client: Any,
        embedding_service: Any,
        llm_config: Optional[Dict[str, Any]] = None,
    ):
        self._client = qdrant_client
        self._embedding = embedding_service
        self._llm_config = llm_config or self._load_llm_config()
        self._progress: Dict[str, Any] = {}
        self._upsert_lock = asyncio.Lock()
        self._upsert_cancelled = False

    def get_progress(self) -> Dict[str, Any]:
        """현재 진행 상황 반환."""
        return dict(self._progress)

    def cancel_upsert(self) -> bool:
        """진행 중인 적재를 중지 요청."""
        if self._upsert_lock.locked():
            self._upsert_cancelled = True
            return True
        return False

    # ------------------------------------------------------------------
    # LLM 설정 로드
    # ------------------------------------------------------------------

    @staticmethod
    def _load_llm_config() -> Dict[str, Any]:
        """환경변수 우선 → config 파일 폴백으로 LLM endpoint 로드."""
        # 1. 환경변수 (chat 모드와 동일: VLLM_ENDPOINT, VLLM_API_KEY, VLLM_MODEL)
        env_endpoint = os.environ.get("VLLM_ENDPOINT", "")
        env_api_key = os.environ.get("VLLM_API_KEY", "")
        env_model = os.environ.get("VLLM_MODEL", "")
        if env_endpoint:
            return {
                "endpoint": env_endpoint,
                "api_key": env_api_key,
                "model": env_model,
            }

        # 2. 폴백: config 파일
        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            cfg = get_config_manager().get_config()
            vllm = cfg.get("vllm", {})
            return {
                "endpoint": vllm.get("endpoint", ""),
                "api_key": vllm.get("apiKey", ""),
                "model": vllm.get("model", ""),
            }
        except Exception:
            return {"endpoint": "", "api_key": "", "model": ""}

    # ------------------------------------------------------------------
    # 컬렉션 관리
    # ------------------------------------------------------------------

    async def ensure_collections(self, dimension: int) -> None:
        """3개 컬렉션 생성 (없으면)."""
        from qdrant_client.models import Distance, VectorParams

        existing = {c.name for c in self._client.get_collections().collections}
        for name in ALL_COLLECTIONS:
            if name not in existing:
                self._client.create_collection(
                    collection_name=name,
                    vectors_config=VectorParams(
                        size=dimension, distance=Distance.COSINE
                    ),
                )
                logger.info("Collection created: %s (dim=%d)", name, dimension)

    async def delete_collection(self, collection_name: str) -> None:
        """컬렉션 삭제 후 재생성."""
        if collection_name not in ALL_COLLECTIONS:
            raise ValueError(f"Unknown collection: {collection_name}")
        self._client.delete_collection(collection_name)
        await self.ensure_collections(self._embedding.dimension)
        logger.info("Collection reset: %s", collection_name)

    async def get_collection_stats(self) -> Dict[str, Any]:
        """3개 컬렉션 통계."""
        existing = set()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
        except Exception as e:
            logger.warning("get_collections failed: %s", e)

        stats = {}
        for name in ALL_COLLECTIONS:
            if name not in existing:
                stats[name] = {"points": 0, "vectors": 0, "status": "not_found"}
                continue
            try:
                info = self._client.get_collection(name)
                stats[name] = {
                    "points": info.points_count or 0,
                    "vectors": getattr(info, "vectors_count", 0) or 0,
                    "status": str(getattr(info.status, "value", info.status)),
                }
            except Exception as e:
                logger.warning("get_collection(%s) failed: %s", name, e)
                # count로 포인트 수 직접 카운트
                try:
                    count = self._client.count(name).count
                    stats[name] = {"points": count, "vectors": count, "status": "ok"}
                except Exception:
                    stats[name] = {"points": 0, "vectors": 0, "status": "error"}
        return stats

    # ------------------------------------------------------------------
    # 테이블 컬렉션 적재 (enterprise_tables / bdp_tables)
    # ------------------------------------------------------------------

    async def upsert_table_collection(
        self,
        collection_name: str,
        file_path: str,
        mapping: Dict[str, Any],
        join_file_path: Optional[str] = None,
        join_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """CSV → 동적 매핑 → 임베딩 → upsert.

        Args:
            collection_name: "enterprise_tables" 또는 "bdp_tables"
            file_path: 메인 CSV 경로
            mapping: {groupBy, embeddingFields, tableFields, columnFields}
            join_file_path: 두 번째 CSV (bdp_tables)
            join_key: 조인 키
        """
        if self._upsert_lock.locked():
            return {
                "total": 0,
                "errors": ["적재가 이미 진행 중입니다. 완료 후 다시 시도하세요."],
            }

        async with self._upsert_lock:
            return await self._upsert_table_impl(
                collection_name, file_path, mapping, join_file_path, join_key
            )

    async def _upsert_table_impl(
        self,
        collection_name: str,
        file_path: str,
        mapping: Dict[str, Any],
        join_file_path: Optional[str] = None,
        join_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        start = time.time()
        errors: List[str] = []
        self._progress = {
            "status": "running",
            "total": 0,
            "done": 0,
            "collection": collection_name,
        }

        # CSV 파싱
        rows = self._read_csv(file_path)
        if join_file_path and join_key:
            column_rows = self._read_csv(join_file_path)
            rows = self._join_csvs(rows, column_rows, join_key)

        # 그룹핑 (str 또는 list)
        group_by = mapping.get("groupBy", [])
        if not group_by:
            raise ValueError("mapping.groupBy is required")

        groups = self._group_rows(rows, group_by)
        logger.info(
            "Parsed %d groups from %s (rows=%d)", len(groups), file_path, len(rows)
        )

        # 임베딩 텍스트 생성 + payload 구성
        embedding_fields = mapping.get("embeddingFields", [])
        table_fields = mapping.get("tableFields", [])
        column_fields = mapping.get("columnFields", [])

        # 컬렉션 확보 (없으면 생성, 있으면 유지)
        await self.ensure_collections(self._embedding.dimension)

        # indexFields가 있으면 text payload index 생성
        index_fields = mapping.get("indexFields", [])
        if index_fields:
            self._ensure_text_indexes(collection_name, index_fields)

        # 기존 포인트의 content hash 조회 (변경 감지용)
        existing_hashes: Dict[str, str] = {}  # pid → _content_hash
        try:
            scroll_offset = None
            while True:
                pts, scroll_offset = self._client.scroll(
                    collection_name=collection_name,
                    offset=scroll_offset,
                    limit=100,
                    with_payload=["_content_hash"],
                    with_vectors=False,
                )
                for pt in pts:
                    h = (pt.payload or {}).get("_content_hash", "")
                    existing_hashes[str(pt.id)] = h
                if scroll_offset is None:
                    break
        except Exception:
            pass  # 컬렉션이 비었거나 에러 → 전체 적재

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []
        point_ids: List[str] = []
        skipped_unchanged = 0

        MAX_COLUMNS_PER_CHUNK = 200

        for group_key, group_rows in groups.items():
            first_row = group_rows[0]
            num_columns = len(group_rows)

            if num_columns <= MAX_COLUMNS_PER_CHUNK:
                # 컬럼 수가 적으면 단일 포인트
                pid = str(
                    uuid.uuid5(uuid.NAMESPACE_DNS, f"{collection_name}:{group_key}")
                )

                embed_text = self._build_table_embed_text(
                    first_row, group_rows, table_fields, column_fields, embedding_fields
                )
                if not embed_text.strip():
                    continue

                # 해시 비교: 동일하면 skip
                content_hash = hashlib.sha256(embed_text.encode("utf-8")).hexdigest()[
                    :16
                ]
                if pid in existing_hashes and existing_hashes[pid] == content_hash:
                    skipped_unchanged += 1
                    continue

                payload: Dict[str, Any] = {
                    "_collection": collection_name,
                    "_embed_text": embed_text,
                    "_group_key": group_key,
                    "_content_hash": content_hash,
                }
                for tf in table_fields:
                    payload[tf] = first_row.get(tf, "")
                columns = [
                    {cf: r.get(cf, "") for cf in column_fields} for r in group_rows
                ]
                payload["columns"] = columns

                texts.append(embed_text)
                payloads.append(payload)
                point_ids.append(pid)
            else:
                # 컬럼이 많으면 MAX_COLUMNS_PER_CHUNK 개씩 분할하여 여러 포인트 생성
                for chunk_idx in range(0, num_columns, MAX_COLUMNS_PER_CHUNK):
                    chunk_rows = group_rows[
                        chunk_idx : chunk_idx + MAX_COLUMNS_PER_CHUNK
                    ]
                    pid = str(
                        uuid.uuid5(
                            uuid.NAMESPACE_DNS,
                            f"{collection_name}:{group_key}:chunk{chunk_idx}",
                        )
                    )

                    embed_text = self._build_table_embed_text(
                        first_row,
                        chunk_rows,
                        table_fields,
                        column_fields,
                        embedding_fields,
                    )
                    if not embed_text.strip():
                        continue

                    content_hash = hashlib.sha256(
                        embed_text.encode("utf-8")
                    ).hexdigest()[:16]
                    if pid in existing_hashes and existing_hashes[pid] == content_hash:
                        skipped_unchanged += 1
                        continue

                    chunk_payload: Dict[str, Any] = {
                        "_collection": collection_name,
                        "_embed_text": embed_text,
                        "_group_key": group_key,
                        "_content_hash": content_hash,
                        "_chunk": f"{chunk_idx // MAX_COLUMNS_PER_CHUNK + 1}/"
                        f"{(num_columns + MAX_COLUMNS_PER_CHUNK - 1) // MAX_COLUMNS_PER_CHUNK}",
                    }
                    for tf in table_fields:
                        chunk_payload[tf] = first_row.get(tf, "")
                    columns = [
                        {cf: r.get(cf, "") for cf in column_fields} for r in chunk_rows
                    ]
                    chunk_payload["columns"] = columns

                    texts.append(embed_text)
                    payloads.append(chunk_payload)
                    point_ids.append(pid)

        if not texts:
            return {
                "total": 0,
                "skipped_unchanged": skipped_unchanged,
                "errors": [] if skipped_unchanged else ["No valid groups found"],
            }

        # 배치 임베딩 + upsert (deterministic ID 사용)
        upserted = await self._batch_upsert(
            collection_name, texts, payloads, point_ids=point_ids
        )

        elapsed = round(time.time() - start, 1)
        self._record_history(collection_name, "upsert", upserted, errors, elapsed)
        return {
            "total": upserted,
            "skipped_unchanged": skipped_unchanged,
            "groups": len(groups),
            "elapsed_s": elapsed,
            "errors": errors,
        }

    # ------------------------------------------------------------------
    # 가이드 3단계 파이프라인
    # ------------------------------------------------------------------

    MAX_FILE_CHARS = 100_000  # 10만자 초과 시 skip

    _STEP1_CONCURRENCY = 3  # 1단계 LLM 동시 호출 수

    async def guide_pipeline_step1(
        self,
        source_dir: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """1단계: 원본 파일 → 벡터 임베딩용 MD 재구성 (3개 병렬).

        모든 파일(.md 포함)을 LLM으로 재구성.
        출력: {source_dir}_mdversion/ 에 .md 파일 저장.

        Yields:
            {"status": "running", "current": N, "total": M, "file": "name"}
            {"status": "error", "file": "name", "error": "reason"}
            {"status": "complete", ...}
        """
        p = Path(source_dir)
        out_dir = Path(f"{source_dir}_mdversion")
        out_dir.mkdir(parents=True, exist_ok=True)

        all_files = sorted(
            f
            for f in p.rglob("*")
            if f.is_file()
            and not f.name.startswith(".")
            and not any(part.startswith(".") for part in f.relative_to(p).parts[:-1])
        )

        total = len(all_files)
        sem = asyncio.Semaphore(self._STEP1_CONCURRENCY)
        queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue()
        done_count = 0
        success_count = 0
        error_count = 0

        async def _process_one(fp: Path) -> None:
            nonlocal done_count, success_count, error_count
            async with sem:
                await queue.put(
                    {
                        "status": "running",
                        "current": done_count + 1,
                        "total": total,
                        "file": fp.name,
                    }
                )
                try:
                    content = fp.read_text(encoding="utf-8")

                    if len(content) > self.MAX_FILE_CHARS:
                        await queue.put(
                            {
                                "status": "error",
                                "file": fp.name,
                                "error": f"파일이 너무 큽니다 ({len(content)}자). 수동 분할 필요.",
                            }
                        )
                        error_count += 1
                        return

                    # source URL 추출 후 LLM 변환 전에 제거
                    src_url = self._extract_confluence_url(content)
                    if src_url:
                        content = re.sub(
                            r"^\[source:\s*[^\]]*\]\s*\n?",
                            "",
                            content,
                            count=1,
                        ).lstrip()

                    result = await self._convert_to_markdown(content, fp.name)

                    if not result or not result.strip():
                        await queue.put(
                            {"status": "error", "file": fp.name, "error": "LLM 빈 응답"}
                        )
                        error_count += 1
                        return

                    if len(result.strip()) < len(content) * 0.5:
                        logger.warning(
                            "MD conversion may be truncated: %s (in=%d, out=%d)",
                            fp.name,
                            len(content),
                            len(result),
                        )

                    # source URL을 md 첫 줄에 보존
                    md_content = result.strip()
                    if src_url:
                        md_content = f"[source: {src_url}]\n\n{md_content}"

                    out_path = out_dir / f"{fp.stem}.md"
                    out_path.write_text(md_content, encoding="utf-8")
                    success_count += 1

                except Exception as e:
                    await queue.put(
                        {"status": "error", "file": fp.name, "error": str(e)}
                    )
                    error_count += 1
                finally:
                    done_count += 1

        # 병렬 태스크 시작
        tasks = [asyncio.create_task(_process_one(fp)) for fp in all_files]

        # 큐에서 이벤트를 꺼내서 yield (모든 태스크 완료까지)
        while done_count < total:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=1.0)
                yield event
            except asyncio.TimeoutError:
                continue

        # 잔여 이벤트 drain
        while not queue.empty():
            yield queue.get_nowait()

        # 모든 태스크 완료 대기
        await asyncio.gather(*tasks, return_exceptions=True)

        yield {
            "status": "complete",
            "total": total,
            "success": success_count,
            "errors": error_count,
            "outputDir": str(out_dir),
        }

    async def guide_pipeline_step2(
        self,
        source_dir: str,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """2단계: _mdversion/ 파일 → 청킹 + 요약 → _chunked/ 에 개별 파일 저장.

        Yields:
            {"status": "running", "current": N, "total": M, "file": "name", "phase": "..."}
            {"status": "complete", "total_files": N, "total_chunks": M, "outputDir": "path"}
        """
        md_dir = Path(f"{source_dir}_mdversion")
        chunk_dir = Path(f"{source_dir}_chunked")
        chunk_dir.mkdir(parents=True, exist_ok=True)

        # 기존 청크 파일 삭제 (재실행 시 깨끗하게)
        for old in chunk_dir.glob("*.md"):
            old.unlink()

        md_files = sorted(md_dir.glob("*.md"))
        cfg = {**DEFAULT_CHUNKING}
        total_chunks = 0

        for i, fp in enumerate(md_files):
            yield {
                "status": "running",
                "current": i + 1,
                "total": len(md_files),
                "file": fp.name,
                "phase": "chunking",
            }

            content = fp.read_text(encoding="utf-8")
            confluence_url = self._extract_confluence_url(content)
            if confluence_url:
                # 첫 줄 source URL을 content에서 제거
                content = re.sub(
                    r"^\[source:\s*[^\]]*\]\s*\n?", "", content, count=1
                ).lstrip()
            title = self._extract_title(content, fp.name)
            chunks = self._chunk_markdown(content, cfg)

            if not chunks:
                continue

            yield {
                "status": "running",
                "current": i + 1,
                "total": len(md_files),
                "file": fp.name,
                "phase": "summary",
            }
            summaries = await self._generate_chunk_summaries(chunks, title)

            for j, (chunk, summary) in enumerate(zip(chunks, summaries)):
                section = chunk.get("section", "")
                # YAML frontmatter에서 따옴표 이스케이프
                safe_section = section.replace('"', '\\"')
                safe_summary = summary.replace('"', '\\"')

                frontmatter = (
                    f"---\n"
                    f'source: "{fp.name}"\n'
                    f'section: "{safe_section}"\n'
                    f'summary: "{safe_summary}"\n'
                    f"chunk_index: {j + 1}\n"
                    f"total_chunks: {len(chunks)}\n"
                    + (
                        f'confluence_url: "{confluence_url}"\n'
                        if confluence_url
                        else ""
                    )
                    + "---\n\n"
                )
                chunk_path = chunk_dir / f"{fp.stem}_{j + 1:03d}.md"
                chunk_path.write_text(frontmatter + chunk["content"], encoding="utf-8")
                total_chunks += 1

        yield {
            "status": "complete",
            "total_files": len(md_files),
            "total_chunks": total_chunks,
            "outputDir": str(chunk_dir),
        }

    async def guide_pipeline_step3(
        self,
        source_dir: str,
        collection_name: str = COLLECTION_GUIDE,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """3단계: _chunked/ 파일 → 임베딩 + Qdrant upsert.

        Yields:
            {"status": "running", "current": N, "total": M, "file": "name"}
            {"status": "complete", "total": N, "upserted": M}
        """
        chunk_dir = Path(f"{source_dir}_chunked")
        chunk_files = sorted(chunk_dir.glob("*.md"))

        # 컬렉션 초기화 후 재적재
        try:
            self._client.delete_collection(collection_name)
        except Exception:
            pass
        await self.ensure_collections(self._embedding.dimension)

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for i, fp in enumerate(chunk_files):
            yield {
                "status": "running",
                "current": i + 1,
                "total": len(chunk_files),
                "file": fp.name,
            }

            raw = fp.read_text(encoding="utf-8")
            meta, content = self._parse_chunk_file(raw)

            source = meta.get("source", fp.name)
            section = meta.get("section", "")
            summary = meta.get("summary", "")
            title = self._extract_title(content, source)

            prefix = f"[{title}"
            if section:
                prefix += f" > {section}"
            prefix += "]"

            embed_text = f"{prefix}\n{summary}\n\n{content}"
            texts.append(embed_text)
            confluence_url = meta.get("confluence_url", "") or meta.get(
                "source_url", ""
            )
            payload_entry: Dict[str, Any] = {
                "content": content,
                "summary": summary,
                "source": source,
                "title": title,
                "section": section,
                "_collection": collection_name,
                "_embed_text": embed_text,
            }
            if confluence_url:
                payload_entry["confluence_url"] = confluence_url
            payloads.append(payload_entry)

        upserted = await self._batch_upsert(collection_name, texts, payloads)

        yield {
            "status": "complete",
            "total": len(chunk_files),
            "upserted": upserted,
        }

    @staticmethod
    def _parse_chunk_file(raw: str) -> Tuple[Dict[str, Any], str]:
        """YAML frontmatter + content 파싱."""
        if raw.startswith("---"):
            parts = raw.split("---", 2)
            if len(parts) >= 3:
                import yaml

                try:
                    meta = yaml.safe_load(parts[1]) or {}
                except Exception:
                    meta = {}
                content = parts[2].strip()
                return meta, content
        return {}, raw.strip()

    def guide_pipeline_status(self, source_dir: str) -> Dict[str, Any]:
        """각 단계별 산출물 존재 여부 확인."""
        md_dir = Path(f"{source_dir}_mdversion")
        chunk_dir = Path(f"{source_dir}_chunked")
        return {
            "mdversion": {
                "exists": md_dir.is_dir(),
                "files": len(list(md_dir.glob("*.md"))) if md_dir.is_dir() else 0,
            },
            "chunked": {
                "exists": chunk_dir.is_dir(),
                "files": len(list(chunk_dir.glob("*.md"))) if chunk_dir.is_dir() else 0,
            },
        }

    # ------------------------------------------------------------------
    # 가이드 문서 적재 (레거시 — 하위 호환)
    # ------------------------------------------------------------------

    async def upsert_guide_directory(
        self,
        dir_path: str,
        chunking_config: Optional[Dict[str, int]] = None,
        collection_name: str = COLLECTION_GUIDE,
    ) -> Dict[str, Any]:
        """디렉토리 내 모든 파일 순차 처리 → guide 컬렉션 적재."""
        start = time.time()
        cfg = {**DEFAULT_CHUNKING, **(chunking_config or {})}
        p = Path(dir_path)
        if not p.is_dir():
            return {"error": f"Not a directory: {dir_path}"}

        # 모든 파일 수집 (숨김 디렉토리 .ipynb_checkpoints 등 제외)
        all_files = sorted(
            f
            for f in p.rglob("*")
            if f.is_file()
            and not f.name.startswith(".")
            and not any(part.startswith(".") for part in f.relative_to(p).parts[:-1])
        )
        total_chunks = 0
        converted = 0
        errors: List[Dict[str, str]] = []

        # 진행 상황 초기화
        self._progress = {
            "status": "running",
            "total_files": len(all_files),
            "processed_files": 0,
            "current_file": "",
            "total_chunks": 0,
            "summary_total": 0,
            "summary_done": 0,
        }

        # 기존 컬렉션 전체 삭제 후 재적재
        self._client.delete_collection(collection_name)
        await self.ensure_collections(self._embedding.dimension)

        for fp in all_files:
            self._progress["current_file"] = fp.name
            try:
                result = await self._process_guide_file(fp, cfg, collection_name)
                total_chunks += result.get("chunks", 0)
                self._progress["total_chunks"] = total_chunks
                if result.get("converted"):
                    converted += 1
            except Exception as e:
                errors.append({"file": str(fp), "error": str(e)})
                logger.error("Guide file error %s: %s", fp, e)
            self._progress["processed_files"] += 1

        elapsed = round(time.time() - start, 1)
        self._progress = {
            "status": "done",
            "total_files": len(all_files),
            "processed_files": len(all_files),
            "total_chunks": total_chunks,
            "elapsed_s": elapsed,
        }
        self._record_history(
            collection_name,
            "upsert_directory",
            total_chunks,
            [e["error"] for e in errors],
            elapsed,
        )
        return {
            "total_files": len(all_files),
            "total_chunks": total_chunks,
            "converted_files": converted,
            "errors": errors,
            "elapsed_s": elapsed,
        }

    async def upsert_guide_file(
        self,
        file_path: str,
        chunking_config: Optional[Dict[str, int]] = None,
        collection_name: str = COLLECTION_GUIDE,
    ) -> Dict[str, Any]:
        """guide 컬렉션 파일 1개만 추가/갱신 (해시 비교)."""
        cfg = {**DEFAULT_CHUNKING, **(chunking_config or {})}
        fp = Path(file_path)
        if not fp.is_file():
            return {"error": f"Not a file: {file_path}"}

        source = fp.name
        file_hash = self._file_hash(fp)

        # 기존 동일 source 포인트 해시 비교
        existing = self._scroll_by_source(collection_name, source, limit=1)
        if existing and existing[0].payload.get("_file_hash") == file_hash:
            return {"status": "unchanged", "source": source}

        # 기존 포인트 삭제
        self._delete_by_source(collection_name, source)

        result = await self._process_guide_file(fp, cfg, collection_name)
        return {"status": "updated", "source": source, **result}

    async def delete_guide_file(
        self, source: str, collection_name: str = COLLECTION_GUIDE
    ) -> Dict[str, Any]:
        """guide 컬렉션에서 특정 source 포인트 삭제."""
        count = self._delete_by_source(collection_name, source)
        return {"deleted": count, "source": source}

    async def _process_guide_file(
        self, fp: Path, cfg: Dict[str, int], collection_name: str = COLLECTION_GUIDE
    ) -> Dict[str, Any]:
        """파일 1개 → md 변환 → 청킹 → 요약 → 임베딩 → upsert."""
        content = fp.read_text(encoding="utf-8")
        converted = False

        # 비-md 파일 → 마크다운 변환
        if fp.suffix.lower() != ".md":
            content = await self._convert_to_markdown(content, fp.name)
            # 변환 결과 저장
            md_path = fp.with_suffix(".md")
            md_path.write_text(content, encoding="utf-8")
            converted = True

        source = fp.name
        file_hash = self._file_hash(fp)

        # 제목 추출
        title = self._extract_title(content, fp.name)

        # 청킹
        chunks = self._chunk_markdown(content, cfg)
        if not chunks:
            return {"chunks": 0, "converted": converted}

        # 요약 생성
        summaries = await self._generate_chunk_summaries(chunks, title)

        # 임베딩 텍스트 + payload 구성
        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for chunk, summary in zip(chunks, summaries):
            section = chunk.get("section", "")
            prefix = f"[{title}"
            if section:
                prefix += f" > {section}"
            prefix += "]"

            embed_text = f"{prefix}\n{summary}\n\n{chunk['content']}"
            texts.append(embed_text)
            payloads.append(
                {
                    "content": chunk["content"],
                    "summary": summary,
                    "source": source,
                    "title": title,
                    "section": section,
                    "_collection": collection_name,
                    "_embed_text": embed_text,
                    "_file_hash": file_hash,
                }
            )

        upserted = await self._batch_upsert(collection_name, texts, payloads)
        return {"chunks": upserted, "converted": converted}

    # ------------------------------------------------------------------
    # 마크다운 변환
    # ------------------------------------------------------------------

    async def _convert_to_markdown(self, content: str, filename: str) -> str:
        """비-md 파일 → 마크다운 구조화 (내용 100% 보존, 포맷만 변경)."""
        prompt = (
            "다음 텍스트를 마크다운으로 구조화해주세요.\n"
            "이 마크다운은 벡터 DB 임베딩 적재용이며, ## (소제목) 기준으로 시맨틱 청킹됩니다.\n\n"
            "규칙:\n"
            "1. 원본 내용을 축소/변형/요약하지 않을 것\n"
            "2. 문맥에 따라 제목(#), 소제목(##), 테이블(|), 리스트(-) 포맷만 추가\n"
            "3. 핵심 정보와 의미를 100% 보존할 것 (삭제/축소 금지)\n"
            "4. 내용이 흩어져 있으면 관련 내용끼리 묶어서 문단을 재구성해도 됨\n"
            "5. 마크다운만 출력 (설명이나 메타 텍스트 없이)\n"
            "6. ## 소제목 구성 시 시맨틱 청킹을 고려하여:\n"
            "   - 하나의 ## 섹션이 하나의 의미 단위(주제/개념/기능)를 담도록 구성\n"
            "   - 서로 다른 주제가 한 섹션에 섞이지 않도록 분리\n"
            "   - 섹션당 적절한 길이 유지 (너무 짧거나 너무 길지 않게, 약 200~800자 권장)\n"
            "7. draw.io XML(<mxfile>, <mxGraphModel> 등)이 포함된 경우:\n"
            "   - XML 부분을 Mermaid 다이어그램(```mermaid ... ```)으로 변환\n"
            "   - 다이어그램 유형(flowchart, sequence, class 등)을 자동 판별\n"
            "   - Mermaid 블록 아래에 '## 구성요소 설명'과 '## 데이터 흐름' 섹션을 추가하여\n"
            "     각 노드/요소 설명과 순차적 흐름을 정리\n"
            "   - XML 원본은 제거하고 Mermaid + 설명으로 대체\n\n"
            f"파일명: {filename}\n\n"
            f"원본:\n{content}"
        )
        result, reason = await self._call_llm(prompt, return_finish_reason=True)
        print(
            f"[RAG] MD convert: {filename} finish_reason={reason} "
            f"in={len(content)} out={len(result or '')}",
            flush=True,
        )

        if not result or not result.strip():
            return content

        # 출력이 잘린 경우 이어쓰기 (최대 3회)
        max_continuations = 3
        full_result = result
        for cont_i in range(max_continuations):
            if reason != "length":
                break
            logger.info(
                "MD conversion truncated for %s, continuing (%d/%d)",
                filename,
                cont_i + 1,
                max_continuations,
            )
            # 이미 변환된 부분에 해당하는 원본 위치를 추정하여 나머지만 전달
            # 변환 결과의 마지막 5줄에서 키워드를 추출하여 원본에서 위치 탐색
            last_lines = full_result.strip().splitlines()[-5:]
            remaining = content
            for line in last_lines:
                # 마크다운 포맷 제거 후 원본에서 검색
                clean = line.strip().lstrip("#").strip().strip("*").strip()
                if len(clean) > 15:
                    idx = content.find(clean)
                    if idx > 0:
                        # 해당 위치 이후의 원본을 remaining으로
                        remaining = content[idx + len(clean) :]
                        break

            last_output = "\n".join(last_lines)
            cont_prompt = (
                "이전 마크다운 변환이 출력 한도에 도달하여 중단되었습니다.\n"
                "아래 규칙을 반드시 지켜주세요:\n"
                "1. '이전 출력의 마지막 부분' 바로 다음부터 이어서 변환하세요\n"
                "2. 절대 요약/마무리/결론 섹션을 추가하지 마세요\n"
                "3. 원본 내용을 축소하지 말고 100% 그대로 마크다운으로 변환하세요\n"
                "4. 마크다운만 출력하세요 (설명이나 메타 텍스트 없이)\n\n"
                f"이전 출력의 마지막 부분:\n```\n{last_output}\n```\n\n"
                f"변환할 나머지 원본:\n{remaining}"
            )
            cont_result, reason = await self._call_llm(
                cont_prompt, return_finish_reason=True
            )
            if cont_result and cont_result.strip():
                full_result += "\n" + cont_result

        return full_result.strip()

    # ------------------------------------------------------------------
    # 시맨틱 청킹 (마크다운 헤더 기반)
    # ------------------------------------------------------------------

    def _chunk_markdown(
        self, content: str, cfg: Optional[Dict[str, int]] = None
    ) -> List[Dict[str, Any]]:
        """마크다운 헤더 기반 시맨틱 청킹 + target_size 병합.

        1단계: ## → ### → 빈 줄 → 문장으로 시맨틱 분할
        2단계: 인접 소형 청크를 target_size까지 병합
        """
        c = {**DEFAULT_CHUNKING, **(cfg or {})}
        target = c["target_size"]
        min_sz = c["min_size"]
        max_sz = c["max_size"]

        # 1단계: 시맨틱 분할 (min_size 제한 없이 전부 수집)
        sections = self._split_by_header(content, level=2)
        raw_chunks: List[Dict[str, Any]] = []

        for section_header, section_text in sections:
            if len(section_text) <= max_sz:
                raw_chunks.append({"content": section_text, "section": section_header})
                continue

            # ### (h3)로 재분할
            subsections = self._split_by_header(section_text, level=3)
            for sub_header, sub_text in subsections:
                header = (
                    f"{section_header} > {sub_header}" if sub_header else section_header
                )
                if len(sub_text) <= max_sz:
                    raw_chunks.append({"content": sub_text, "section": header})
                    continue

                # 빈 줄(문단) 기준 분할
                para_chunks = self._split_by_paragraphs(sub_text, target, max_sz)
                for pc in para_chunks:
                    raw_chunks.append({"content": pc, "section": header})

        # 2단계: 인접 소형 청크를 target_size까지 병합
        # 제목 전용 청크(section 없고 짧은)는 무조건 다음 청크에 흡수
        merged: List[Dict[str, Any]] = []
        for chunk in raw_chunks:
            clen = len(chunk["content"])
            prev_is_title_only = (
                merged
                and not merged[-1]["section"]
                and len(merged[-1]["content"]) < min_sz
            )
            can_merge = merged and (
                len(merged[-1]["content"]) + clen + 2 <= target or prev_is_title_only
            )
            if can_merge:
                merged[-1]["content"] += "\n\n" + chunk["content"]
                if chunk["section"] and not merged[-1]["section"]:
                    merged[-1]["section"] = chunk["section"]
            else:
                merged.append(dict(chunk))

        # min_size 미만 잔여 청크 → 이전 또는 다음 청크에 흡수
        final: List[Dict[str, Any]] = []
        for chunk in merged:
            clen = len(chunk["content"].strip())
            if clen < min_sz:
                if final:
                    # 이전 청크에 흡수
                    final[-1]["content"] += "\n\n" + chunk["content"]
                else:
                    # 첫 번째 청크가 작으면 일단 추가 (다음에 흡수될 수 있음)
                    final.append(dict(chunk))
            else:
                # 이전 청크가 min_size 미만이면 현재에 흡수
                if final and len(final[-1]["content"].strip()) < min_sz:
                    chunk["content"] = final[-1]["content"] + "\n\n" + chunk["content"]
                    if not chunk["section"] and final[-1]["section"]:
                        chunk["section"] = final[-1]["section"]
                    final[-1] = chunk
                else:
                    final.append(dict(chunk))

        # 마지막 청크가 min_size 미만이면 이전에 흡수
        if len(final) >= 2 and len(final[-1]["content"].strip()) < min_sz:
            final[-2]["content"] += "\n\n" + final[-1]["content"]
            final.pop()

        return final

    @staticmethod
    def _split_by_header(text: str, level: int) -> List[Tuple[str, str]]:
        """마크다운 헤더 레벨로 분할. 반환: [(header_text, section_content), ...]"""
        pattern = r"^(#{" + str(level) + r"})\s+(.+)$"
        sections: List[Tuple[str, str]] = []
        current_header = ""
        current_lines: List[str] = []

        for line in text.split("\n"):
            m = re.match(pattern, line, re.MULTILINE)
            if m:
                # 이전 섹션 저장
                if current_lines:
                    sections.append((current_header, "\n".join(current_lines).strip()))
                current_header = m.group(2).strip()
                current_lines = [line]
            else:
                current_lines.append(line)

        if current_lines:
            sections.append((current_header, "\n".join(current_lines).strip()))

        return sections if sections else [("", text)]

    @staticmethod
    def _split_by_paragraphs(text: str, target: int, max_sz: int) -> List[str]:
        """빈 줄 기준 문단 분할, target_size에 맞게 병합."""
        paragraphs = re.split(r"\n\s*\n", text)
        chunks: List[str] = []
        current = ""

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            if current and len(current) + len(para) + 2 > target:
                chunks.append(current)
                current = para
            else:
                current = current + "\n\n" + para if current else para

            # max_size 초과 시 문장 단위 분할
            if len(current) > max_sz:
                sentences = re.split(r"(?<=[.!?。])\s+", current)
                buf = ""
                for s in sentences:
                    if buf and len(buf) + len(s) + 1 > target:
                        chunks.append(buf)
                        buf = s
                    else:
                        buf = buf + " " + s if buf else s
                current = buf

        if current:
            chunks.append(current)
        return chunks

    # ------------------------------------------------------------------
    # LLM 청크 요약 생성
    # ------------------------------------------------------------------

    async def _generate_chunk_summaries(
        self,
        chunks: List[Dict[str, Any]],
        doc_title: str,
        concurrency: int = 5,
    ) -> List[str]:
        """각 청크에 대해 LLM 요약을 병렬 생성 (semaphore로 동시 요청 제한)."""
        sem = asyncio.Semaphore(concurrency)

        async def _summarize_one(idx: int, chunk: Dict[str, Any]) -> Tuple[int, str]:
            async with sem:
                section = chunk.get("section", "")
                content = chunk["content"]
                # 너무 짧은 청크는 요약 불필요
                if len(content.strip()) < 50:
                    return idx, content.strip()
                prompt = (
                    "아래 텍스트를 2~3문장으로 간결하게 요약해주세요. 반드시 한국어로 요약하세요. 요약만 출력하세요.\n\n"
                    f"문서: {doc_title}\n"
                    f"섹션: {section}\n\n"
                    "---\n"
                    f"{content[:3000]}\n"
                    "---"
                )
                try:
                    summary = await self._call_llm(prompt)
                    return idx, summary.strip() if summary else ""
                except Exception as e:
                    logger.warning("Chunk summary failed [%d]: %s", idx, e)
                    return idx, ""
                finally:
                    self._progress["summary_done"] = (
                        self._progress.get("summary_done", 0) + 1
                    )

        self._progress["summary_total"] = self._progress.get("summary_total", 0) + len(
            chunks
        )

        tasks = [_summarize_one(i, c) for i, c in enumerate(chunks)]
        results = await asyncio.gather(*tasks)
        results_sorted = sorted(results, key=lambda x: x[0])
        return [r[1] for r in results_sorted]

    # ------------------------------------------------------------------
    # LLM 호출 (OpenAI 호환 API)
    # ------------------------------------------------------------------

    async def _call_llm(
        self, prompt: str, max_retries: int = 5, return_finish_reason: bool = False
    ) -> "str | Tuple[str, str]":
        """vllm 엔드포인트로 LLM 호출 (rate limit 재시도 포함).

        Args:
            return_finish_reason: True면 (content, finish_reason) 튜플 반환.
        """
        endpoint = self._llm_config.get("endpoint", "")
        if not endpoint:
            raise ValueError("LLM endpoint not configured (summarization or vllm)")

        api_key = self._llm_config.get("api_key", "")
        model = self._llm_config.get("model", "")

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.1,
            "max_tokens": 16384,
        }

        base = endpoint.rstrip("/")
        url = (
            f"{base}/v1/chat/completions"
            if "/v1" not in base
            else f"{base}/chat/completions"
        )

        last_error: Optional[Exception] = None
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=120.0, verify=False) as client:
                    resp = await client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"]
                    if return_finish_reason:
                        reason = data["choices"][0].get("finish_reason", "stop")
                        return content, reason
                    return content
            except httpx.HTTPStatusError as e:
                last_error = e
                if e.response.status_code == 429:
                    # Rate limit: Retry-After 헤더 우선, 없으면 exponential backoff
                    retry_after = e.response.headers.get("Retry-After")
                    wait = (
                        float(retry_after) if retry_after else min(2**attempt * 2, 60)
                    )
                    logger.warning(
                        "Rate limited, waiting %.0fs (attempt %d/%d)",
                        wait,
                        attempt + 1,
                        max_retries,
                    )
                    await asyncio.sleep(wait)
                elif e.response.status_code >= 500:
                    wait = min(2**attempt, 30)
                    logger.warning(
                        "Server error %d, retrying in %ds: %s",
                        e.response.status_code,
                        wait,
                        e,
                    )
                    await asyncio.sleep(wait)
                else:
                    raise
            except httpx.RequestError as e:
                last_error = e
                wait = min(2**attempt, 30)
                logger.warning("LLM request error, retrying in %ds: %s", wait, e)
                await asyncio.sleep(wait)

        raise Exception(
            f"LLM call failed after {max_retries} retries: {last_error} (url={url})"
        )

    # ------------------------------------------------------------------
    # 프리뷰 / 검증
    # ------------------------------------------------------------------

    async def dry_run_table(
        self,
        file_path: str,
        mapping: Dict[str, Any],
        join_file_path: Optional[str] = None,
        join_key: Optional[str] = None,
        sample_count: int = 3,
    ) -> Dict[str, Any]:
        """적재 전 프리뷰 — 파싱 샘플 + 임베딩 텍스트 미리보기."""
        rows = self._read_csv(file_path)
        if join_file_path and join_key:
            column_rows = self._read_csv(join_file_path)
            rows = self._join_csvs(rows, column_rows, join_key)

        group_by = mapping.get("groupBy", [])
        groups = self._group_rows(rows, group_by)
        embedding_fields = mapping.get("embeddingFields", [])
        table_fields = mapping.get("tableFields", [])
        column_fields = mapping.get("columnFields", [])

        samples = []
        for i, (key, group_rows) in enumerate(groups.items()):
            if i >= sample_count:
                break
            first_row = group_rows[0]
            embed_text = self._build_table_embed_text(
                first_row, group_rows, table_fields, column_fields, embedding_fields
            )

            payload = {}
            for tf in table_fields:
                payload[tf] = first_row.get(tf, "")
            cols = [{cf: r.get(cf, "") for cf in column_fields} for r in group_rows]

            samples.append(
                {
                    "group_key": key,
                    "embed_text": embed_text[:800],
                    "payload_preview": payload,
                    "columns_count": len(cols),
                    "columns_sample": cols[:3],
                }
            )

        return {
            "total_groups": len(groups),
            "total_rows": len(rows),
            "samples": samples,
        }

    async def dry_run_guide(
        self, dir_path: str, chunking_config: Optional[Dict[str, int]] = None
    ) -> Dict[str, Any]:
        """guide 컬렉션 청킹 프리뷰."""
        cfg = {**DEFAULT_CHUNKING, **(chunking_config or {})}
        p = Path(dir_path)
        files = sorted(
            f
            for f in p.rglob("*")
            if f.is_file()
            and not f.name.startswith(".")
            and not any(part.startswith(".") for part in f.relative_to(p).parts[:-1])
        )
        previews = []
        for fp in files:
            try:
                content = fp.read_text(encoding="utf-8")
                title = self._extract_title(content, fp.name)
                chunks = self._chunk_markdown(content, cfg)
                previews.append(
                    {
                        "file": fp.name,
                        "needs_conversion": fp.suffix.lower() != ".md",
                        "title": title,
                        "chunk_count": len(chunks),
                        "chunks_preview": [
                            {
                                "section": c.get("section", ""),
                                "first_100": c["content"][:100],
                            }
                            for c in chunks[:5]
                        ],
                    }
                )
            except Exception as e:
                previews.append({"file": fp.name, "error": str(e)})
        return {"total_files": len(files), "previews": previews}

    def validate_csv_mapping(
        self, file_path: str, mapping: Dict[str, Any]
    ) -> Dict[str, Any]:
        """CSV 유효성 검증."""
        rows = self._read_csv(file_path)
        if not rows:
            return {"valid": False, "error": "Empty CSV"}

        headers = set(rows[0].keys())
        group_by = mapping.get("groupBy", [])
        if isinstance(group_by, str):
            group_by = [group_by] if group_by else []
        all_fields = (
            group_by
            + mapping.get("embeddingFields", [])
            + mapping.get("tableFields", [])
            + mapping.get("columnFields", [])
        )

        missing = [f for f in all_fields if f and f not in headers]
        warnings: List[str] = []

        # 빈 값 비율 (각 그룹핑 키별)
        for gb in group_by:
            if gb in headers:
                null_count = sum(1 for r in rows if not r.get(gb))
                null_pct = round(null_count / len(rows) * 100, 1)
                if null_pct > 0:
                    warnings.append(f"groupBy '{gb}': NULL {null_pct}%")
        if group_by:
            groups = self._group_rows(rows, group_by)
            warnings.append(f"Unique groups: {len(groups)}")

        return {
            "valid": len(missing) == 0,
            "headers": sorted(headers),
            "missing_fields": missing,
            "total_rows": len(rows),
            "warnings": warnings,
        }

    def parse_csv_headers(self, file_path: str) -> List[str]:
        """CSV 헤더 목록 반환."""
        rows = self._read_csv(file_path, limit=1)
        if rows:
            return sorted(rows[0].keys())
        return []

    def list_directory_files(self, dir_path: str) -> List[Dict[str, Any]]:
        """디렉토리 내 파일 목록."""
        p = Path(dir_path)
        if not p.is_dir():
            return []
        files = []
        for f in sorted(p.rglob("*")):
            if (
                f.is_file()
                and not f.name.startswith(".")
                and not any(
                    part.startswith(".") for part in f.relative_to(p).parts[:-1]
                )
            ):
                files.append(
                    {
                        "name": f.name,
                        "path": str(f),
                        "size": f.stat().st_size,
                        "ext": f.suffix.lower(),
                    }
                )
        return files

    # ------------------------------------------------------------------
    # 데이터 브라우저
    # ------------------------------------------------------------------

    async def browse_collection(
        self,
        collection: str,
        offset: Optional[str] = None,
        limit: int = 10,
        filters: Optional[List[Dict[str, str]]] = None,
    ) -> Dict[str, Any]:
        """컬렉션 포인트 페이징 조회. offset은 Qdrant scroll의 point ID.

        filters: [{"field": "source", "value": "guide.md"}, ...] — AND 조건.
        nested 배열 필터는 field에 "columns[].col_name" 형태 사용.
        """
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        scroll_filter = None
        if filters:
            conditions = [
                FieldCondition(key=f["field"], match=MatchValue(value=f["value"]))
                for f in filters
                if f.get("field") and f.get("value")
            ]
            if conditions:
                scroll_filter = Filter(must=conditions)

        points, next_offset = self._client.scroll(
            collection_name=collection,
            scroll_filter=scroll_filter,
            limit=limit,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )

        items = []
        for pt in points:
            payload = dict(pt.payload) if pt.payload else {}
            # _embed_text 는 너무 크므로 축약
            if "_embed_text" in payload:
                payload["_embed_text"] = payload["_embed_text"][:200] + "..."
            items.append({"id": str(pt.id), "payload": payload})

        return {"items": items, "next_offset": next_offset, "count": len(items)}

    async def delete_point(self, collection: str, point_id: str) -> None:
        """포인트 1개 삭제."""
        from qdrant_client.models import PointIdsList

        self._client.delete(
            collection_name=collection,
            points_selector=PointIdsList(points=[point_id]),
        )

    # ------------------------------------------------------------------
    # 검색 테스트
    # ------------------------------------------------------------------

    async def search_test(
        self, query: str, collection: Optional[str] = None, top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """관리자용 검색 테스트."""
        query_vec = await self._embedding.embed_query(query)
        collections = [collection] if collection else ALL_COLLECTIONS
        results: List[Dict[str, Any]] = []

        for col in collections:
            try:
                hits = self._client.query_points(
                    collection_name=col,
                    query=query_vec,
                    limit=top_k,
                    with_payload=True,
                )
                for hit in hits.points:
                    payload = dict(hit.payload) if hit.payload else {}
                    if "_embed_text" in payload:
                        payload["_embed_text"] = payload["_embed_text"][:200] + "..."
                    results.append(
                        {
                            "collection": col,
                            "score": round(hit.score, 4),
                            "id": str(hit.id),
                            "payload": payload,
                        }
                    )
            except Exception as e:
                logger.warning("Search test failed for %s: %s", col, e)

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    async def search_with_filter(
        self,
        query: str,
        collection: Optional[str] = None,
        filters: Optional[List[Dict[str, str]]] = None,
        top_k: int = 10,
        score_threshold: float = 0.5,
        match_text: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Qdrant pre-filtering 검색. score_threshold 이상만 반환.

        필터 적용 결과가 0건이면, 필터 값을 쿼리에 합쳐서 필터 없이 자동 재검색.
        예: filters=[{field: "db_name", value: "ADW"}], query="카드매출"
            → 0건 시 query="ADW 카드매출" 으로 필터 없이 재검색.

        Args:
            query: 검색 쿼리 텍스트
            collection: 특정 컬렉션 또는 None(전체)
            filters: [{"field": "x", "value": "y"}] AND 조건 리스트
            top_k: 최대 결과 수 (상한)
            score_threshold: 최소 유사도 점수 (기본 0.3)
            match_text: 텍스트 매칭 검색어 리스트 (인덱스 필드 전체에 OR 검색)
        """
        results = await self._search_qdrant(
            query=query,
            collections=[collection] if collection else None,
            filters=filters,
            top_k=top_k,
            score_threshold=score_threshold,
            match_text=match_text,
        )

        # 필터 적용 결과가 0건이면 필터 값을 쿼리에 합쳐서 재검색
        if not results and filters:
            filter_values = [f["value"] for f in filters if f.get("value")]
            if filter_values:
                enriched_query = " ".join(filter_values) + " " + query
                logger.info(
                    "[RAG] filter returned 0 results, retrying without filter: %s",
                    enriched_query,
                )
                results = await self._search_qdrant(
                    query=enriched_query,
                    collections=[collection] if collection else None,
                    filters=None,
                    top_k=top_k,
                    score_threshold=score_threshold,
                    match_text=match_text,
                )

        return results

    async def _search_qdrant(
        self,
        query: str,
        collections: Optional[List[str]] = None,
        filters: Optional[List[Dict[str, str]]] = None,
        top_k: int = 10,
        score_threshold: float = 0.5,
        match_text: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Qdrant 벡터 검색 내부 구현."""
        from qdrant_client.models import FieldCondition, Filter, MatchText, MatchValue

        query_vec = await self._embedding.embed_query(query)
        target_collections = collections or ALL_COLLECTIONS

        query_filter = None
        if filters:
            conditions = [
                FieldCondition(key=f["field"], match=MatchValue(value=f["value"]))
                for f in filters
                if f.get("field") and f.get("value")
            ]
            if conditions:
                query_filter = Filter(must=conditions)

        results: List[Dict[str, Any]] = []
        seen_ids: set = set()
        _match_text_fallback: List[str] = []
        for col in target_collections:
            # match_text가 있으면 MatchText 필터 + 벡터 검색 1회
            # 없으면 일반 벡터 검색 1회
            effective_filter = query_filter
            if match_text:
                try:
                    # text index 필드 조회, 없으면 기본 필드 사용
                    col_info = self._client.get_collection(col)
                    text_fields = [
                        fname
                        for fname, schema in (col_info.payload_schema or {}).items()
                        if "text" in str(getattr(schema, "params", "")).lower()
                        or getattr(schema, "data_type", "") == "text"
                    ]
                    # text index가 없으면 기본 필드로 fallback
                    if not text_fields:
                        text_fields = ["table_name", "korean_name"]
                    mt_conditions = [
                        FieldCondition(key=f, match=MatchText(text=term))
                        for term in match_text
                        for f in text_fields
                        if term and term.strip()
                    ]
                    if mt_conditions:
                        effective_filter = Filter(should=mt_conditions)
                except Exception as e:
                    logger.warning("match_text filter build failed for %s: %s", col, e)

            try:
                hits = self._client.query_points(
                    collection_name=col,
                    query=query_vec,
                    query_filter=effective_filter,
                    limit=top_k,
                    score_threshold=score_threshold,
                    with_payload=True,
                )

                # match_text 필터 결과가 0건이면 필터 제거 후 재검색
                if (
                    match_text
                    and effective_filter is not query_filter
                    and not hits.points
                ):
                    mt_terms = ", ".join(match_text)
                    logger.info(
                        "[RAG] match_text %s returned 0 results for %s, "
                        "retrying without filter",
                        mt_terms,
                        col,
                    )
                    hits = self._client.query_points(
                        collection_name=col,
                        query=query_vec,
                        query_filter=query_filter,
                        limit=top_k,
                        score_threshold=score_threshold,
                        with_payload=True,
                    )
                    _match_text_fallback.append(
                        f"[{col}] match_text {mt_terms}에 해당하는 "
                        f"테이블이 없어 일반 검색 결과입니다. "
                        f"사용자가 요청한 테이블이 맞는지 확인하세요."
                    )

                for hit in hits.points:
                    payload = dict(hit.payload) if hit.payload else {}
                    payload.pop("_embed_text", None)
                    payload.pop("_content_hash", None)
                    point_id = str(hit.id)
                    seen_ids.add(point_id)
                    results.append(
                        {
                            "collection": col,
                            "score": round(hit.score, 4),
                            "id": point_id,
                            "payload": payload,
                        }
                    )
            except Exception as e:
                logger.warning("search failed for %s: %s", col, e)

        # 테이블명 exact/partial match 리랭킹
        query_tokens = set()
        for word in query.lower().split():
            query_tokens.update(word.split("."))
        query_tokens.discard("")

        for r in results:
            payload = r.get("payload", {})
            table_name = (
                payload.get("table_name") or payload.get("table_id") or ""
            ).lower()
            if not table_name or not query_tokens:
                continue
            if table_name in query_tokens:
                r["score"] += 0.5  # exact match
            elif any(table_name in t or t in table_name for t in query_tokens):
                r["score"] += 0.3  # partial match

        results.sort(key=lambda x: x["score"], reverse=True)
        final = results[:top_k]

        # match_text fallback 메시지가 있으면 결과에 첨부
        if _match_text_fallback:
            for r in final:
                r.setdefault("_warnings", []).extend(_match_text_fallback)

        return final

    # ------------------------------------------------------------------
    # 적재 이력
    # ------------------------------------------------------------------

    def get_history(self) -> List[Dict[str, Any]]:
        """이력 로그 조회."""
        try:
            with open(HISTORY_PATH, encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def _record_history(
        self,
        collection: str,
        action: str,
        count: int,
        errors: List[str],
        elapsed_s: float = 0,
    ) -> None:
        """이력 기록."""
        history = self.get_history()
        history.append(
            {
                "timestamp": datetime.now().isoformat(),
                "collection": collection,
                "action": action,
                "count": count,
                "errors": errors[:10],
                "elapsed_s": elapsed_s,
            }
        )
        # 최근 200건만 유지
        history = history[-200:]
        os.makedirs(os.path.dirname(HISTORY_PATH), exist_ok=True)
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

    # ------------------------------------------------------------------
    # 내부 유틸리티
    # ------------------------------------------------------------------

    def _ensure_text_indexes(self, collection_name: str, fields: List[str]) -> None:
        """payload 필드에 text index가 없으면 생성. MatchText 검색용."""
        from qdrant_client.models import TextIndexParams, TokenizerType

        try:
            info = self._client.get_collection(collection_name)
            existing = set(info.payload_schema.keys()) if info.payload_schema else set()
        except Exception:
            existing = set()

        for field in fields:
            if field in existing:
                continue
            try:
                self._client.create_payload_index(
                    collection_name=collection_name,
                    field_name=field,
                    field_schema=TextIndexParams(
                        type="text",
                        tokenizer=TokenizerType.WORD,
                        min_token_len=1,
                        max_token_len=60,
                        lowercase=True,
                    ),
                )
                logger.info("[RAG] Created text index: %s.%s", collection_name, field)
            except Exception as e:
                logger.warning(
                    "[RAG] Failed to create text index %s.%s: %s",
                    collection_name,
                    field,
                    e,
                )

    @staticmethod
    def _build_table_embed_text(
        first_row: Dict[str, str],
        group_rows: List[Dict[str, str]],
        table_fields: List[str],
        column_fields: List[str],
        embedding_fields: List[str],
    ) -> str:
        """Markdown 구조화된 임베딩 텍스트 생성.

        예시 출력 (tableFields=[table_name,korean_name,db_name],
                   columnFields=[col_name,col_korean_name,col_type,pk]):

            ## TB_CARD_TXN (카드거래)
            - db_name: CARDDB

            ### 컬럼
            - col_name: CARD_NO, col_korean_name: 카드번호, col_type: VARCHAR, pk: Y
            - col_name: TXN_AMT, col_korean_name: 거래금액, col_type: NUMBER, pk: N
        """
        lines: List[str] = []

        # 테이블 레벨: 첫 2개 tableFields를 제목으로, 나머지는 key: value
        title_parts = []
        remaining_tf: List[str] = []
        for i, tf in enumerate(table_fields):
            val = first_row.get(tf, "")
            if not val:
                continue
            if i == 0:
                title_parts.append(val)
            elif i == 1:
                title_parts.append(f"({val})")
            else:
                remaining_tf.append(tf)

        if title_parts:
            lines.append(f"## {' '.join(title_parts)}")
        for tf in remaining_tf:
            val = first_row.get(tf, "")
            if val:
                lines.append(f"- {tf}: {val}")

        # 컬럼 리스트: 각 필드명을 라벨로 포함
        if column_fields and group_rows:
            lines.append("")
            lines.append("### 컬럼")
            for r in group_rows:
                parts = []
                for cf in column_fields:
                    v = r.get(cf, "")
                    if v:
                        parts.append(f"{cf}: {v}")
                if parts:
                    lines.append(f"- {', '.join(parts)}")

        # embeddingFields 중 table/column fields에 없는 추가 필드
        extra_fields = [
            f
            for f in embedding_fields
            if f not in table_fields and f not in column_fields
        ]
        if extra_fields:
            extra_vals = set()
            for r in group_rows:
                for f in extra_fields:
                    v = r.get(f, "")
                    if v:
                        extra_vals.add(str(v))
            if extra_vals:
                lines.append("")
                lines.append(" ".join(extra_vals))

        return "\n".join(lines)

    @staticmethod
    def _read_csv(file_path: str, limit: int = 0) -> List[Dict[str, str]]:
        """CSV 또는 Parquet 파일 → dict 리스트. 확장자 또는 magic bytes로 자동 판별."""
        ext = Path(file_path).suffix.lower()
        if ext in (".parquet", ".pq"):
            return RAGCollectionManager._read_parquet(file_path, limit)
        # 확장자 없거나 불명확 → magic bytes로 parquet 감지
        if not ext or ext not in (".csv", ".tsv", ".txt"):
            try:
                with open(file_path, "rb") as f:
                    magic = f.read(4)
                if magic == b"PAR1":
                    return RAGCollectionManager._read_parquet(file_path, limit)
            except Exception:
                pass
        rows = []
        with open(file_path, encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                rows.append(dict(row))
                if limit and i + 1 >= limit:
                    break
        return rows

    @staticmethod
    def _read_parquet(file_path: str, limit: int = 0) -> List[Dict[str, str]]:
        """Parquet 파일 → dict 리스트. 모든 값을 str로 변환."""
        import pandas as pd

        df = pd.read_parquet(file_path)
        if limit:
            df = df.head(limit)
        # NaN → 빈 문자열, 모든 값 str 변환
        df = df.fillna("").astype(str)
        return df.to_dict(orient="records")

    @staticmethod
    def _group_rows(
        rows: List[Dict[str, str]], group_by: Any
    ) -> Dict[str, List[Dict[str, str]]]:
        """groupBy 키(단일 str 또는 list)로 행 그룹핑."""
        if isinstance(group_by, str):
            group_by = [group_by]
        groups: Dict[str, List[Dict[str, str]]] = {}
        for row in rows:
            parts = [row.get(k, "") for k in group_by]
            if not all(parts):
                continue
            key = "||".join(parts)
            groups.setdefault(key, []).append(row)
        return groups

    @staticmethod
    def _join_csvs(
        main_rows: List[Dict[str, str]],
        join_rows: List[Dict[str, str]],
        join_key: str,
    ) -> List[Dict[str, str]]:
        """두 CSV를 조인 키로 병합 (main에 join 정보 추가)."""
        # join_rows를 join_key 기준으로 인덱싱 (1:N 가능)
        join_index: Dict[str, List[Dict[str, str]]] = {}
        for r in join_rows:
            k = r.get(join_key, "")
            if k:
                join_index.setdefault(k, []).append(r)

        merged = []
        for r in main_rows:
            k = r.get(join_key, "")
            matching = join_index.get(k, [])
            if matching:
                for jr in matching:
                    combined = {**r, **jr}
                    merged.append(combined)
            else:
                merged.append(r)
        return merged

    @staticmethod
    def _extract_confluence_url(content: str) -> str:
        """첫 줄의 [source: URL] 패턴에서 URL 추출."""
        first_line = content.split("\n", 1)[0].strip()
        m = re.match(r"^\[source:\s*(.+?)\]", first_line, re.IGNORECASE)
        return m.group(1).strip() if m else ""

    @staticmethod
    def _extract_title(content: str, fallback: str) -> str:
        """마크다운 첫 # 제목 추출."""
        for line in content.split("\n"):
            m = re.match(r"^#\s+(.+)$", line.strip())
            if m:
                return m.group(1).strip()
        return Path(fallback).stem

    @staticmethod
    def _file_hash(fp: Path) -> str:
        """SHA256 해시 (앞 16자)."""
        return hashlib.sha256(fp.read_bytes()).hexdigest()[:16]

    async def _embed_chunked(
        self, text: str, chunk_chars: int = 2000
    ) -> Optional[List[float]]:
        """긴 텍스트를 청크로 나눠 임베딩 후 평균 벡터 반환."""
        chunks = [text[i : i + chunk_chars] for i in range(0, len(text), chunk_chars)]
        try:
            vecs = await self._embedding.embed_texts(chunks)
            if not vecs:
                return None
            # 평균 벡터
            dim = len(vecs[0])
            avg = [0.0] * dim
            for v in vecs:
                for j in range(dim):
                    avg[j] += v[j]
            n = len(vecs)
            return [x / n for x in avg]
        except Exception as e:
            logger.warning("Chunked embed also failed: %s", e)
            return None

    async def _batch_upsert(
        self,
        collection: str,
        texts: List[str],
        payloads: List[Dict[str, Any]],
        point_ids: Optional[List[str]] = None,
        batch_size: int = 1,
        concurrency: int = 64,
    ) -> int:
        """배치 임베딩(병렬) + Qdrant upsert."""
        from qdrant_client.models import PointStruct

        total_items = len(texts)
        self._progress = {
            "status": "running",
            "total": total_items,
            "done": 0,
            "collection": collection,
        }

        # 배치 분할
        batches = []
        for i in range(0, total_items, batch_size):
            batch_ids = point_ids[i : i + batch_size] if point_ids else None
            batches.append(
                (texts[i : i + batch_size], payloads[i : i + batch_size], batch_ids)
            )

        total = 0
        errors = 0

        # concurrency개씩 병렬 임베딩 → 순차 upsert
        self._upsert_cancelled = False
        for group_start in range(0, len(batches), concurrency):
            if self._upsert_cancelled:
                self._progress = {
                    "status": "cancelled",
                    "done": total,
                    "total": total_items,
                }
                logger.info("Upsert cancelled at %d/%d", total, total_items)
                break

            group = batches[group_start : group_start + concurrency]

            # 병렬 임베딩
            embed_tasks = [self._embedding.embed_texts(bt) for bt, _, _ in group]
            embed_results = await asyncio.gather(*embed_tasks, return_exceptions=True)

            # 순차 upsert (Qdrant 로컬은 동기)
            for (batch_texts, batch_payloads, batch_ids), embeddings in zip(
                group, embed_results
            ):
                if isinstance(embeddings, Exception):
                    # 임베딩 에러 → 청크 분할 / 테이블 정보만으로 재시도
                    logger.warning(
                        "Embed failed (will retry): %s | text_len=%d",
                        str(embeddings)[:200],
                        len(batch_texts[0]) if batch_texts else 0,
                    )
                    if batch_texts:
                        retry_ok = True
                        retry_embeddings = []
                        for text in batch_texts:
                            # 1차: 청크 분할 후 평균 벡터
                            chunked = await self._embed_chunked(text)
                            if chunked is not None:
                                retry_embeddings.append(chunked)
                                continue
                            # 2차: 컬럼 제외, 테이블 정보만으로 재시도
                            table_only = text.split("### 컬럼")[0].strip()
                            try:
                                vecs = await self._embedding.embed_texts([table_only])
                                retry_embeddings.append(vecs[0])
                                logger.info(
                                    "Table-only embed OK: %d→%d chars",
                                    len(text),
                                    len(table_only),
                                )
                            except Exception:
                                retry_ok = False
                                break
                        if retry_ok:
                            embeddings = retry_embeddings
                            logger.info(
                                "Embed retry OK: text_len=%d",
                                len(batch_texts[0]),
                            )
                        else:
                            embeddings = None  # 아래 에러 처리로

                    if embeddings is None or isinstance(embeddings, Exception):
                        errors += 1
                        for pl in batch_payloads:
                            table_info = {
                                k: v
                                for k, v in pl.items()
                                if k not in ("columns", "_embed_text", "_collection")
                            }
                            logger.warning(
                                "Embed error: %s | table=%s | text_len=%d",
                                embeddings,
                                table_info,
                                len(batch_texts[0]) if batch_texts else 0,
                            )
                        self._progress["done"] += len(batch_texts)
                        continue
                try:
                    points = [
                        PointStruct(
                            id=pid if pid else str(uuid.uuid4()),
                            vector=emb,
                            payload=pl,
                        )
                        for pl, emb, pid in zip(
                            batch_payloads,
                            embeddings,
                            batch_ids if batch_ids else [None] * len(batch_payloads),
                        )
                    ]
                    self._client.upsert(collection_name=collection, points=points)
                    total += len(points)
                except Exception as e:
                    errors += 1
                    logger.warning("Batch upsert error: %s", e)
                self._progress["done"] = total + (errors * batch_size)

        self._progress = {"status": "done"}
        return total

    def _scroll_by_source(self, collection: str, source: str, limit: int = 100) -> list:
        """source 필드로 포인트 검색."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        points, _ = self._client.scroll(
            collection_name=collection,
            scroll_filter=Filter(
                must=[FieldCondition(key="source", match=MatchValue(value=source))]
            ),
            limit=limit,
            with_payload=True,
            with_vectors=False,
        )
        return points

    def _delete_by_source(self, collection: str, source: str) -> int:
        """source 기준 포인트 삭제."""

        points = self._scroll_by_source(collection, source)
        if not points:
            return 0
        from qdrant_client.models import PointIdsList

        ids = [pt.id for pt in points]
        self._client.delete(
            collection_name=collection,
            points_selector=PointIdsList(points=ids),
        )
        return len(ids)
