import torch


def _gqa_to_regular_q_by_seq_flatten(q: torch.Tensor, num_kv_heads: int, gqa_group_size: int) -> torch.Tensor:
    batch, num_q_heads, seq_len, head_dim = q.shape
    assert num_q_heads == num_kv_heads * gqa_group_size
    return q.reshape(batch, num_kv_heads, gqa_group_size, seq_len, head_dim).permute(0, 1, 3, 2, 4).reshape(
        batch, num_kv_heads, seq_len * gqa_group_size, head_dim
    )


def _regular_q_by_seq_flatten_to_gqa(o_flat: torch.Tensor, gqa_group_size: int) -> torch.Tensor:
    batch, num_kv_heads, flat_seq_len, head_dim = o_flat.shape
    assert flat_seq_len % gqa_group_size == 0
    seq_len = flat_seq_len // gqa_group_size
    return o_flat.reshape(batch, num_kv_heads, seq_len, gqa_group_size, head_dim).permute(0, 1, 3, 2, 4).reshape(
        batch, num_kv_heads * gqa_group_size, seq_len, head_dim
    )


def _run_gqa_equiv_case(batch: int, seq_len_q: int, seq_len_kv: int, num_kv_heads: int, gqa_group_size: int, head_dim: int, dtype: torch.dtype):
    device = "cuda"
    num_q_heads = num_kv_heads * gqa_group_size

    q = torch.randn(batch, num_q_heads, seq_len_q, head_dim, device=device, dtype=dtype)
    k = torch.randn(batch, num_kv_heads, seq_len_kv, head_dim, device=device, dtype=dtype)
    v = torch.randn(batch, num_kv_heads, seq_len_kv, head_dim, device=device, dtype=dtype)

    o_gqa = torch.nn.functional.scaled_dot_product_attention(
        q,
        k,
        v,
        is_causal=False,
        enable_gqa=True,
    )

    k_rep = k.repeat_interleave(gqa_group_size, dim=1)
    v_rep = v.repeat_interleave(gqa_group_size, dim=1)
    o_repeat_kv = torch.nn.functional.scaled_dot_product_attention(
        q,
        k_rep,
        v_rep,
        is_causal=False,
    )

    q_flat = _gqa_to_regular_q_by_seq_flatten(q, num_kv_heads, gqa_group_size)
    o_flat = torch.nn.functional.scaled_dot_product_attention(
        q_flat,
        k,
        v,
        is_causal=False,
    )
    o_seq_flatten = _regular_q_by_seq_flatten_to_gqa(o_flat, gqa_group_size)

    torch.testing.assert_close(o_gqa, o_repeat_kv, rtol=1e-3, atol=1e-3)
    torch.testing.assert_close(o_gqa, o_seq_flatten, rtol=1e-3, atol=1e-3)


def test_gqa_sdpa_equivalent_to_regular_attention():
    _run_gqa_equiv_case(
        batch=1,
        seq_len_q=64,
        seq_len_kv=64,
        num_kv_heads=2,
        gqa_group_size=4,
        head_dim=64,
        dtype=torch.float16,
    )
    _run_gqa_equiv_case(
        batch=2,
        seq_len_q=37,
        seq_len_kv=53,
        num_kv_heads=3,
        gqa_group_size=2,
        head_dim=32,
        dtype=torch.bfloat16,
    )


if __name__ == "__main__":
    test_gqa_sdpa_equivalent_to_regular_attention()