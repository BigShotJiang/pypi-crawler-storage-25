
import ast
import dataclasses
from functools import partial
import math
from typing import Annotated, Any, Optional

import torch
from ttfs.aggtype import TRITON_AGG_FLATTEN_META_FIELD, TRITON_AGG_META_FIELD, constexpr_function
from ttfs.utils import div_up
import triton.language as tl
import triton 
import traceback
from triton.experimental.gluon import language as gl
import ttfs
from ttfs.jitx import _create_agg_from_flatten_args_ast_node, triton_jitx

@ttfs.aggregate
class AttentionManager(ttfs.TensorManagerBase):
    q: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    k: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    v: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    o: ttfs.TensorDesc # contiguous
    lse: ttfs.TensorDesc # contiguous

    S_qo: tl.tensor 
    S_kv: tl.tensor

    B: tl.constexpr
    H: tl.constexpr
    D: tl.constexpr
    D_kv: tl.constexpr

    BLOCK_M: tl.constexpr 
    BLOCK_N: tl.constexpr

    cu_seqlen_q: Any = None 
    cu_seqlen_kv: Any = None 


@ttfs.aggregate
class AttentionArgs:
    tensors: AttentionManager
    sm_scale: tl.constexpr

def _attn_fwd_grid_bshd(META, q_shape):
    res = (triton.cdiv(q_shape[1], META["BLOCK_M"]), q_shape[0] * q_shape[2], 1)
    return res 

@ttfs.triton_jitx_kernel
def attn_fwd_pointer_kernel(args: AttentionArgs, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // args.tensors.H
    h_id = bh_id % args.tensors.H
    tm = args.tensors.offset_all_tensor("B,H,S_qo", (b_id, h_id, seq_id * BLOCK_M))

    q_desc = tm.get_offseted_block_desc("q", "S,D", [BLOCK_M, tm.D])
    k_desc = tm.get_offseted_block_desc("k", "D,S", [tm.D, BLOCK_N])
    # offset_n is constexpr[0] by default in kv. 
    # required when modify offsets in desc directly.
    k_desc = k_desc.make_offset_dim_mutable("S")
    v_desc = tm.get_offseted_block_desc("v", "S,D", [BLOCK_N, tm.D])
    v_desc = v_desc.make_offset_dim_mutable("S")

    q = q_desc.masked_load(apply_mask=True)
    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32) + 1.0
    acc = tl.zeros([BLOCK_M, tm.D], dtype=tl.float32)
    QK_SCALE: tl.constexpr = args.sm_scale * 1.44269504  # 1/log(2)

    num_kv_blocks = tl.cdiv(tm.S_kv, BLOCK_N)
    offs_n = k_desc.get_blocked_offset_base("S")

    for kv_idx in range(num_kv_blocks):
        k = k_desc.masked_load(apply_mask=True) # .T
        # k = tl.load(k_ptrs).T
        qk = tl.dot(q, k)
        qk = tl.where(offs_n[None, :] < tm.S_kv, qk, float("-inf"))

        m_ij = tl.maximum(m_i, tl.max(qk, 1) * QK_SCALE)
        qk = qk * QK_SCALE - m_ij[:, None]
        p = tl.math.exp2(qk)
        # -- compute correction factor
        alpha = tl.math.exp2(m_i - m_ij)
        l_ij = tl.sum(p, 1)
        acc = acc * alpha[:, None]
        # prepare p and v for the dot
        v = v_desc.masked_load(apply_mask=True)
        # v = tl.load(v_ptrs)
        p = p.to(tl.bfloat16)
        # note that this non transposed v for FP8 is only supported on Blackwell
        acc = tl.dot(p, v, acc)
        # update m_i and l_i
        # place this at the end of the loop to reduce register pressure
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        k_desc = k_desc.increment_fixed_block("S", 1)
        v_desc = v_desc.increment_fixed_block("S", 1)
        offs_n += BLOCK_N
    o_desc = tm.get_block_desc("o", "S,D", [BLOCK_M, tm.D])
    lse_desc = tm.get_block_desc("lse", "S", [BLOCK_M])

    m_i += tl.math.log2(l_i)
    acc = acc / l_i[:, None]
    lse_desc.masked_store(m_i)
    o_desc.masked_store(acc.to(tl.bfloat16))

@ttfs.triton_jitx_kernel
def attn_fwd_tma_kernel(args: AttentionArgs, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // args.tensors.H
    h_id = bh_id % args.tensors.H
    # tm = args.tensors.offset_all_tensor("B,H,S_qo", (b_id, h_id, seq_id * BLOCK_M))
    tm = args.tensors.offset_all_tensor_v2(ttfs.offsets(B=b_id, H=h_id, S_qo=seq_id * BLOCK_M))

    q_desc = tm.get_external_tma_block_desc("q", "S,D")
    k_desc = tm.get_external_tma_block_desc("k", "S,D")
    v_desc = tm.get_external_tma_block_desc("v", "S,D")

    q = q_desc.tma_load([0, 0])
    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32) + 1.0
    acc = tl.zeros([BLOCK_M, tm.D], dtype=tl.float32)
    QK_SCALE: tl.constexpr = args.sm_scale * 1.44269504  # 1/log(2)
    offs_n = k_desc.get_blocked_offset_base("S")

    num_kv_blocks = tl.cdiv(tm.S_kv, BLOCK_N)
    for kv_idx in range(num_kv_blocks):
        k = k_desc.tma_load([kv_idx * BLOCK_N, 0]).T
        # k = tl.load(k_ptrs).T
        qk = tl.dot(q, k)
        qk = tl.where(offs_n[None, :] < tm.S_kv, qk, float("-inf"))

        m_ij = tl.maximum(m_i, tl.max(qk, 1) * QK_SCALE)
        qk = qk * QK_SCALE - m_ij[:, None]
        p = tl.math.exp2(qk)
        # -- compute correction factor
        alpha = tl.math.exp2(m_i - m_ij)
        l_ij = tl.sum(p, 1)
        acc = acc * alpha[:, None]
        # prepare p and v for the dot
        v = v_desc.tma_load([kv_idx * BLOCK_N, 0])
        # v = tl.load(v_ptrs)
        p = p.to(tl.bfloat16)
        # note that this non transposed v for FP8 is only supported on Blackwell
        acc = tl.dot(p, v, acc)
        # update m_i and l_i
        # place this at the end of the loop to reduce register pressure
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        offs_n += BLOCK_N 
    o_desc = tm.get_external_tma_block_desc("o", "S,D")
    lse_desc = tm.get_block_desc("lse", "S", [BLOCK_M])

    m_i += tl.math.log2(l_i)
    acc = acc / l_i[:, None]
    lse_desc.masked_store(m_i)
    o_desc.tma_store([0, 0], acc.to(tl.bfloat16))


def attn_fwd(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, sm_scale: Optional[float] = None, use_tma=False,):
    B, S_qo, H, D = q.shape
    D_kv = k.shape[-1]
    S_kv = k.shape[1]
    assert k.shape == (B, S_kv, H, D_kv)
    assert v.shape == (B, S_kv, H, D_kv)
    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(q.size(-1))
    o = torch.empty_like(q)
    lse = torch.empty((B, H, S_qo), device=q.device, dtype=torch.float32)
    BLOCK_M = 128 
    BLOCK_N = 128
    if use_tma:
        tdesc_q = ttfs.TensorDesc.tma_from_tensor_triton(q, "B,S_qo->S,H,D", [1, BLOCK_M, 1, D])
        tdesc_k = ttfs.TensorDesc.tma_from_tensor_triton(k, "B,S_kv->S,H,D_kv->D", [1, BLOCK_N, 1, D_kv])
        tdesc_v = ttfs.TensorDesc.tma_from_tensor_triton(v, "B,S_kv->S,H,D_kv->D", [1, BLOCK_N, 1, D_kv])
        tdesc_o = ttfs.TensorDesc.tma_from_tensor_triton(o, "B,S_qo->S,H,D", [1, BLOCK_M, 1, D])
    else:
        tdesc_q = ttfs.TensorDesc(q, "B,S_qo->S,H,D")
        tdesc_k = ttfs.TensorDesc(k, "B,S_kv->S,H,D_kv->D")
        tdesc_v = ttfs.TensorDesc(v, "B,S_kv->S,H,D_kv->D")
        tdesc_o = ttfs.TensorDesc(o, "B,S_qo->S,H,D")
    tdesc_lse = ttfs.TensorDesc(lse, "B,H,S_qo->S")

    tensors = AttentionManager(
        q=tdesc_q,
        k=tdesc_k,
        v=tdesc_v,
        o=tdesc_o,
        lse=tdesc_lse,
        S_qo=S_qo,
        S_kv=S_kv,
        D_kv=D_kv,
        B=B,
        H=H,
        D=D,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
    )
    args = AttentionArgs(tensors=tensors, sm_scale=sm_scale)
    if use_tma:
        ker = attn_fwd_tma_kernel[partial(_attn_fwd_grid_bshd, q_shape=q.shape)](args=args, BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N)
    else:
        ker = attn_fwd_pointer_kernel[partial(_attn_fwd_grid_bshd, q_shape=q.shape)](args=args, BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N)
    return o, lse

def _test_attn_fwd(B: int, S_qo: int, S_kv: int, H: int, D: int, D_kv: Optional[int] = None):
    if D_kv is None:
        D_kv = D
    q = torch.randn((B, S_qo, H, D), device="cuda", dtype=torch.bfloat16)
    k = torch.randn((B, S_kv, H, D_kv), device="cuda", dtype=torch.bfloat16)
    v = torch.randn((B, S_kv, H, D_kv), device="cuda", dtype=torch.bfloat16)

    o2, lse = attn_fwd(q, k, v, use_tma=True)
    o1, lse = attn_fwd(q, k, v, use_tma=False)

    print("Output shape:", o1.shape)
    print("LSE shape:", lse.shape)

    # test by torch sdpa

    q_tr = q.transpose(1, 2)
    k_tr = k.transpose(1, 2)
    v_tr = v.transpose(1, 2)
    o_ref = torch.nn.functional.scaled_dot_product_attention(q_tr, k_tr, v_tr, is_causal=False).transpose(1, 2)

    torch.testing.assert_close(o1, o_ref, rtol=1e-2, atol=1e-2)
    torch.testing.assert_close(o2, o_ref, rtol=1e-2, atol=1e-2)


def test_attn_fwd():

    _test_attn_fwd(B=2, S_qo=1024, S_kv=1024, H=16, D=128, D_kv=128)
    _test_attn_fwd(B=1, S_qo=353, S_kv=975, H=16, D=64)


if __name__ == "__main__":
    test_attn_fwd()