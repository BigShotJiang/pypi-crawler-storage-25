import torch 


# @torch.compile(fullgraph=True)
def dev_func(q, k, w):
    H_q = q.shape[1]
    H_kv = k.shape[1]
    GQA = H_q // H_kv
    # q: [S, H, D]
    # k: [S, H, D]
    # w: [S, H]
    # calc (bgemm(Q, K) * w)
    k = k.repeat_interleave(GQA, dim=1) # [S, H*4, D]
    q_slast = q.permute(1, 0, 2)
    k_slast = k.permute(1, 0, 2)
    qk = torch.matmul(q_slast, k_slast.transpose(-1, -2)) # [H, S, S]
    w_ = w.T.unsqueeze(-1) # [H, S, 1]
    out = (qk * w_).sum(0)
    return out 


def test_dev_func():
    S = 1024
    H = 16
    D = 64
    q = torch.randn((S, H, D), device="cuda", dtype=torch.bfloat16)
    k = torch.randn((S, H, D), device="cuda", dtype=torch.bfloat16)
    w = torch.randn((S, H), device="cuda", dtype=torch.bfloat16)

    out = dev_func(q, k, w)
    print(out.shape)

if __name__ == "__main__":
    test_dev_func()