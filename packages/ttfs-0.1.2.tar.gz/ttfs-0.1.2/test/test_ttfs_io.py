
import ast
import dataclasses
from typing import Annotated, Any

import numpy as np
import torch
from ttfs.aggtype import TRITON_AGG_FLATTEN_META_FIELD, TRITON_AGG_META_FIELD, constexpr_function
from ttfs.utils import div_up
import triton.language as tl
import triton 
import traceback
from triton.experimental.gluon import language as gl
import ttfs
from ttfs.jitx import _create_agg_from_flatten_args_ast_node, triton_jitx

@ttfs.aggregate
class TensorManager(ttfs.TensorManagerBase):
    a: ttfs.TensorDesc
    b: ttfs.TensorDesc

    M: gl.tensor
    N: gl.tensor 

@ttfs.aggregate
class TensorManagerTriton(ttfs.TensorManagerBase):
    a: ttfs.TensorDesc
    b: ttfs.TensorDesc

    M: tl.tensor
    N: tl.tensor 


@ttfs.triton_jit_kernel
def tt_kernel_copy_b_tr(a_ptr, b_ptr, M, N, BLOCK_M: gl.constexpr, BLOCK_N: gl.constexpr):
    tm = TensorManagerTriton(
        a=ttfs.TensorDesc(
            a_ptr, 
            "M,N",

        ),
        b=ttfs.TensorDesc(
            b_ptr, 
            "N,M"
        ),
        M=M,
        N=N,
    )
    tm = tm.replace_packed_dims("M,N", (M, N))
    idx_m = tl.program_id(1)
    idx_n = tl.program_id(0)
    new_tm = tm.offset_all_tensor("M,N", (idx_m * BLOCK_M, idx_n * BLOCK_N))
    a_blocked_desc = new_tm.get_block_desc("a", "N,M", (BLOCK_N, BLOCK_M))
    b_blocked_desc = new_tm.get_block_desc("b", "N,M", (BLOCK_N, BLOCK_M))

    a_io = ttfs.create_io_iter(a_blocked_desc, "M")
    b_io = ttfs.create_io_iter(b_blocked_desc, "M")
    a = a_io.load("a")
    b_io.store("b", a)

@ttfs.triton_jit_kernel
def tt_kernel_copy_b_tma(a_desc, b_desc, M, N, BLOCK_M: gl.constexpr, BLOCK_N: gl.constexpr):
    tm = TensorManagerTriton(
        a=ttfs.TensorDesc(
            a_desc, 
            "M,N",

        ),
        b=ttfs.TensorDesc(
            b_desc, 
            "N,M"
        ),
        M=M,
        N=N,
    )
    idx_m = tl.program_id(1)
    idx_n = tl.program_id(0)
    new_tm = tm.offset_all_tensor_ptr("M,N", (idx_m * BLOCK_M, idx_n * BLOCK_N))
    a_blocked_desc = new_tm.get_external_tma_block_desc("a", "M,N")
    b_blocked_desc = new_tm.get_external_tma_block_desc("b", "N,M")
    a = a_blocked_desc.tma_load([0, 0]).T
    b_blocked_desc.tma_store([0, 0], a)

@ttfs.aggregate
class TensorManagerBtrTriton(ttfs.TensorManagerBase):
    a: ttfs.TensorDesc
    b: ttfs.TensorDesc
    B: tl.constexpr
    M: tl.tensor
    N: tl.tensor 


@ttfs.triton_jit_kernel
def tt_kernel_batch_tr_simple_tma(a_desc, b_desc, M, N, B: gl.constexpr, BLOCK_M: gl.constexpr, BLOCK_N: gl.constexpr):
    tm = TensorManagerBtrTriton(
        a=ttfs.TensorDesc(
            a_desc, 
            "B,M,N",
        ),
        b=ttfs.TensorDesc(
            b_desc, 
            "B,N,M"
        ),
        B=B,
        M=M,
        N=N,
    )
    bidx = tl.program_id(2)
    idx_m = tl.program_id(1)
    idx_n = tl.program_id(0)
    # new_tm = tm.offset_all_tensor("B,M,N", (2, 128, 256))
    new_tm = tm.offset_all_tensor_ptr("B,M,N", (bidx, idx_m * BLOCK_M, idx_n * BLOCK_N))

    a_blocked_desc = new_tm.get_external_tma_block_desc("a", "M,N")
    b_blocked_desc = new_tm.get_external_tma_block_desc("b", "N,M")
    a = a_blocked_desc.tma_load([0, 0]).T
    b_blocked_desc.tma_store([0, 0], a)
    # a = a_desc.load([bidx, idx_m * BLOCK_M, idx_n * BLOCK_N]).reshape(BLOCK_M, BLOCK_N).T
    # b_desc.store([bidx, idx_n * BLOCK_N, idx_m * BLOCK_M], a.reshape(1, BLOCK_N, BLOCK_M))

@ttfs.aggregate
class ComplexCopyManager(ttfs.TensorManagerBase):
    q: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    o: ttfs.TensorDesc # contiguous

    S_qo: tl.tensor 

    B: tl.constexpr
    H: tl.constexpr
    D: tl.constexpr

    BLOCK_M: tl.constexpr 

@ttfs.triton_jitx_kernel
def complex_copy_kernel(tm: ComplexCopyManager, BLOCK_M: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // tm.H
    h_id = bh_id % tm.H
    tm = tm.offset_all_tensor("B,H,S_qo", (b_id, h_id, seq_id * BLOCK_M))

    q_desc = tm.get_offseted_block_desc("q", "S,D", [BLOCK_M, tm.D])
    q = q_desc.masked_load(apply_mask=True)
    o_desc = tm.get_block_desc("o", "S,D", [BLOCK_M, tm.D])
    o_desc.masked_store(q.to(tl.bfloat16))

@ttfs.triton_jitx_kernel
def complex_copy_tma_kernel(tm: ComplexCopyManager, BLOCK_M: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // tm.H
    h_id = bh_id % tm.H
    tm = tm.offset_all_tensor_ptr("B,H,S_qo", (b_id, h_id, seq_id * BLOCK_M))

    q_desc = tm.get_external_tma_block_desc("q", "S,D")
    q = q_desc.tma_load([0, 0])
    o_desc = tm.get_external_tma_block_desc("o", "S,D")
    o_desc.tma_store([0, 0], q.to(tl.bfloat16))

def test_kernel_copy_tr():
    M = 256
    N = 256
    a = torch.rand((M, N)).cuda().to(torch.float32)
    b = torch.zeros((N, M)).cuda().to(torch.float32)

    block_size = 128

    grid = (div_up(N, block_size), div_up(M, block_size))

    ker = tt_kernel_copy_b_tr[grid](a_ptr=a, b_ptr=b, 
        M=M, N=N,
        BLOCK_M=block_size, BLOCK_N=block_size
    )
    torch.testing.assert_close(a.T, b)
    b.zero_()

    block_shape = [block_size, block_size]
    ker = tt_kernel_copy_b_tma[grid](
        a_desc=ttfs.TensorDesc.get_tma_desc_triton(a, block_shape), 
        b_desc=ttfs.TensorDesc.get_tma_desc_triton(b, block_shape), 
        M=M, N=N,
        BLOCK_M=block_size, BLOCK_N=block_size
    )
    error = torch.abs(a.T - b)
    # error_img = (error.cpu().numpy() > 0).astype(np.int32)
    # import PIL.Image as Image
    # Image.fromarray((error_img * 255).astype(np.uint8)).save("error.png")
    torch.testing.assert_close(a.T, b)

def test_kernel_copy_btr():
    B = 4
    M = 4096 
    N = 2048 
    a = torch.rand((B, M, N)).cuda().to(torch.float32)
    b = torch.zeros((B, N, M)).cuda().to(torch.float32)

    block_size_m = 256
    block_size_n = 128

    grid = (div_up(N, block_size_n), div_up(M, block_size_m), B)

    block_shape_a = [1, block_size_m, block_size_n]
    block_shape_b = [1, block_size_n, block_size_m]

    ker = tt_kernel_batch_tr_simple_tma[grid](
        a_desc=ttfs.TensorDesc.get_tma_desc_triton(a, block_shape_a), 
        b_desc=ttfs.TensorDesc.get_tma_desc_triton(b, block_shape_b), 
        B=B,
        M=M, N=N,
        BLOCK_M=block_size_m, BLOCK_N=block_size_n
    )
    torch.testing.assert_close(a.permute(0, 2, 1), b)

def test_complex_copy():
    B = 1
    S_qo = 1024
    S_kv = 1024
    H = 1
    D = 64
    q = torch.randn((B, S_qo, H, D), device="cuda", dtype=torch.bfloat16)

    o = torch.zeros_like(q)
    tdesc_q = ttfs.TensorDesc(q, "B,S_qo->S,H,D")
    tdesc_o = ttfs.TensorDesc(o, "B,S_qo->S,H,D")
    tm = ComplexCopyManager(
        q=tdesc_q,
        o=tdesc_o,
        S_qo=S_qo,
        B=B,
        H=H,
        D=D,
        BLOCK_M=128,
    )
    grid = (div_up(S_qo, tm.BLOCK_M), H * B)
    ker = complex_copy_kernel[grid](tm=tm, BLOCK_M=tm.BLOCK_M)


    torch.testing.assert_close(o, q, rtol=1e-2, atol=1e-2)
    o = torch.zeros_like(q)

    tdesc_q = ttfs.TensorDesc.tma_from_tensor_triton(q, "B,S_qo->S,H,D", [1, 128, 1, D])
    tdesc_o = ttfs.TensorDesc.tma_from_tensor_triton(o, "B,S_qo->S,H,D", [1, 128, 1, D])
    tm = ComplexCopyManager(
        q=tdesc_q,
        o=tdesc_o,
        S_qo=S_qo,
        B=B,
        H=H,
        D=D,
        BLOCK_M=128,
    )

    ker = complex_copy_tma_kernel[grid](tm=tm, BLOCK_M=tm.BLOCK_M)

    torch.testing.assert_close(o, q, rtol=1e-2, atol=1e-2)

if __name__ == "__main__":
    test_kernel_copy_tr()
    # test_kernel_copy_btr()
    # test_complex_copy()
