"""Tests for deployless.compiler.validator."""
import pytest

from deployless.compiler.validator import ValidationError, validate
from deployless.providers.aws.resources.dynamodb import DynamoDB
from deployless.providers.aws.resources.kms import KMS
from deployless.providers.aws.resources.s3 import S3


def _base_config(**overrides):
    config = {
        "stage": "dev",
        "globals": {"memory": 256, "timeout": 30, "log_retention": 14},
        "api": {"endpoint_type": "REGIONAL", "cors": {}},
    }
    config.update(overrides)
    return config


def _base_state(**overrides):
    state = {"features": {}, "crons": [], "split_routes": [], "lambdas": []}
    state.update(overrides)
    return state


def _feature(routes=None, config=None, resources=None):
    return {
        "config": config or {},
        "resources": resources or {},
        "routes": routes if routes is not None else [{"sam_path": "/test", "methods": ["GET"]}],
    }


class TestConfigValidation:
    def test_valid_config(self):
        state = _base_state(features={"auth": _feature()})
        validate(state, _base_config())  # no exception

    def test_invalid_stage(self):
        with pytest.raises(ValidationError, match="E01"):
            validate(_base_state(features={"a": _feature()}), _base_config(stage="dev-1!"))

    def test_invalid_endpoint_type(self):
        config = _base_config()
        config["api"]["endpoint_type"] = "INVALID"
        with pytest.raises(ValidationError, match="E02"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_invalid_log_retention(self):
        config = _base_config()
        config["globals"]["log_retention"] = 999
        with pytest.raises(ValidationError, match="E03"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_cors_credentials_wildcard(self):
        config = _base_config()
        config["api"]["cors"] = {"allow_credentials": True, "allow_origin": "*"}
        with pytest.raises(ValidationError, match="E04"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_invalid_auth_type(self):
        config = _base_config()
        config["api"]["auth"] = {"type": "oauth2"}
        with pytest.raises(ValidationError, match="E11"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_cognito_requires_arn(self):
        config = _base_config()
        config["api"]["auth"] = {"type": "cognito"}
        with pytest.raises(ValidationError, match="E12"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_lambda_auth_requires_arn(self):
        config = _base_config()
        config["api"]["auth"] = {"type": "lambda"}
        with pytest.raises(ValidationError, match="E13"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_usage_plan_requires_rate_burst(self):
        config = _base_config()
        config["api"]["usage_plan"] = {"quota": 1000}
        with pytest.raises(ValidationError, match="E14"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_domain_requires_domain_name(self):
        config = _base_config()
        config["api"]["domain"] = {"route53": True}
        with pytest.raises(ValidationError, match="E17"):
            validate(_base_state(features={"a": _feature()}), config)

    def test_domain_name_alone_is_valid(self):
        config = _base_config()
        config["api"]["domain"] = {"domain_name": "api.example.com"}
        # Should NOT raise — certificate_arn is optional now
        validate(_base_state(features={"a": _feature()}), config)

    def test_compression_size_invalid(self):
        config = _base_config()
        config["api"]["minimum_compression_size"] = -1
        with pytest.raises(ValidationError, match="E18"):
            validate(_base_state(features={"a": _feature()}), config)


class TestFeatureValidation:
    def test_memory_out_of_range(self):
        state = _base_state(features={"a": _feature(config={"memory": 99})})
        with pytest.raises(ValidationError, match="E05"):
            validate(state, _base_config())

    def test_timeout_out_of_range(self):
        state = _base_state(features={"a": _feature(config={"timeout": 1000})})
        with pytest.raises(ValidationError, match="E06"):
            validate(state, _base_config())

    def test_no_routes(self):
        state = _base_state(features={"a": _feature(routes=[])})
        with pytest.raises(ValidationError, match="E07"):
            validate(state, _base_config())

    def test_ephemeral_storage_out_of_range(self):
        state = _base_state(features={"a": _feature(config={"ephemeral_storage": 100})})
        with pytest.raises(ValidationError, match="E19"):
            validate(state, _base_config())

    def test_reserved_concurrency_negative(self):
        state = _base_state(features={"a": _feature(config={"reserved_concurrency": -1})})
        with pytest.raises(ValidationError, match="E20"):
            validate(state, _base_config())

    def test_provisioned_concurrency_zero(self):
        state = _base_state(features={"a": _feature(config={"provisioned_concurrency": 0})})
        with pytest.raises(ValidationError, match="E21"):
            validate(state, _base_config())

    def test_feature_log_retention_invalid(self):
        state = _base_state(features={"a": _feature(config={"log_retention": 999})})
        with pytest.raises(ValidationError, match="E22"):
            validate(state, _base_config())


class TestAlarmValidation:
    def test_invalid_sns_arn(self):
        alarms = {"sns_topic_arn": "not-an-arn"}
        state = _base_state(features={"a": _feature(config={"alarms": alarms})})
        with pytest.raises(ValidationError, match="E23"):
            validate(state, _base_config())

    def test_duration_pct_out_of_range(self):
        alarms = {"duration": {"threshold_pct": 200}}
        state = _base_state(features={"a": _feature(config={"alarms": alarms})})
        with pytest.raises(ValidationError, match="E24"):
            validate(state, _base_config())


class TestCronValidation:
    def test_invalid_schedule(self):
        crons = [{"name": "bad", "schedule": "every 5 min"}]
        state = _base_state(features={"a": _feature()}, crons=crons)
        with pytest.raises(ValidationError, match="E08"):
            validate(state, _base_config())

    def test_cron_memory_out_of_range(self):
        crons = [{"name": "c", "schedule": "rate(1 hour)", "memory": 99}]
        state = _base_state(features={"a": _feature()}, crons=crons)
        with pytest.raises(ValidationError, match="E09"):
            validate(state, _base_config())

    def test_cron_timeout_out_of_range(self):
        crons = [{"name": "c", "schedule": "rate(1 hour)", "timeout": 1000}]
        state = _base_state(features={"a": _feature()}, crons=crons)
        with pytest.raises(ValidationError, match="E10"):
            validate(state, _base_config())


class TestLambdaValidation:
    def test_lambda_memory_out_of_range(self):
        lambdas = [{"name": "fn", "memory": 50}]
        state = _base_state(features={"a": _feature()}, lambdas=lambdas)
        with pytest.raises(ValidationError, match="E25"):
            validate(state, _base_config())

    def test_lambda_timeout_out_of_range(self):
        lambdas = [{"name": "fn", "timeout": 1000}]
        state = _base_state(features={"a": _feature()}, lambdas=lambdas)
        with pytest.raises(ValidationError, match="E26"):
            validate(state, _base_config())

    def test_lambda_valid(self):
        lambdas = [{"name": "fn", "memory": 256, "timeout": 30}]
        state = _base_state(features={"a": _feature()}, lambdas=lambdas)
        validate(state, _base_config())  # no exception


class TestResourceValidation:
    def test_invalid_resource_reported(self):
        bad_table = DynamoDB("", pk_type="INVALID")
        state = _base_state(features={"a": _feature(resources={"t": bad_table})})
        with pytest.raises(ValidationError, match="E00"):
            validate(state, _base_config())

    def test_resource_validation_in_feature(self):
        bad_bucket = S3("")
        state = _base_state(features={"a": _feature(resources={"b": bad_bucket})})
        with pytest.raises(ValidationError, match="E00"):
            validate(state, _base_config())


class TestDuplicateRoutes:
    def test_duplicate_routes_detected(self):
        f1 = _feature(routes=[{"sam_path": "/users", "methods": ["GET"]}])
        f2 = _feature(routes=[{"sam_path": "/users", "methods": ["GET"]}])
        state = _base_state(features={"auth": f1, "user": f2})
        with pytest.raises(ValidationError, match="Duplicate"):
            validate(state, _base_config())

    def test_same_path_different_methods_ok(self):
        f1 = _feature(routes=[{"sam_path": "/users", "methods": ["GET"]}])
        f2 = _feature(routes=[{"sam_path": "/users", "methods": ["POST"]}])
        state = _base_state(features={"auth": f1, "user": f2})
        validate(state, _base_config())  # no exception


class TestResourcePermissionValidation:
    def test_valid_permission_passes(self):
        table = DynamoDB("users-table")
        feat = _feature(resources={"t": table})
        feat["resource_permissions"] = {"t": "read"}
        state = _base_state(features={"user": feat})
        validate(state, _base_config())  # no exception

    def test_invalid_permission_raises_e30(self):
        table = DynamoDB("users-table")
        feat = _feature(resources={"t": table})
        feat["resource_permissions"] = {"t": "invalid_level"}
        state = _base_state(features={"user": feat})
        with pytest.raises(ValidationError, match="E30"):
            validate(state, _base_config())

    def test_e30_message_includes_valid_levels(self):
        kms = KMS(alias="app")
        feat = _feature(resources={"k": kms})
        feat["resource_permissions"] = {"k": "delete"}
        state = _base_state(features={"auth": feat})
        with pytest.raises(ValidationError, match="crud") as exc_info:
            validate(state, _base_config())
        assert "E30" in str(exc_info.value)

    def test_no_resource_permissions_key_ok(self):
        """Features without resource_permissions should not fail."""
        feat = _feature(resources={"t": DynamoDB("users-table")})
        # No resource_permissions key at all
        state = _base_state(features={"user": feat})
        validate(state, _base_config())  # no exception


class TestInitAppValidation:
    def test_valid_entries(self):
        config = _base_config(init_app=[
            "app.shared.errors.register_error_handlers",
            "app.shared.middleware.register_middleware",
        ])
        state = _base_state(features={"a": _feature()})
        validate(state, config)  # no exception

    def test_invalid_format_no_dot(self):
        config = _base_config(init_app=["register_error_handlers"])
        state = _base_state(features={"a": _feature()})
        with pytest.raises(ValidationError, match="E31"):
            validate(state, config)

    def test_non_string_entry(self):
        config = _base_config(init_app=[123])
        state = _base_state(features={"a": _feature()})
        with pytest.raises(ValidationError, match="E31"):
            validate(state, config)

    def test_empty_list_ok(self):
        config = _base_config(init_app=[])
        state = _base_state(features={"a": _feature()})
        validate(state, config)  # no exception
