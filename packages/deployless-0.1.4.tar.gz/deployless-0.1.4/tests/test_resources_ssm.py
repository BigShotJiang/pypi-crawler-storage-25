"""Tests for SSM resources."""
from deployless.providers.aws.resources.ssm import SSMParam, SSMParameter


class TestSSMParameterInit:
    def test_defaults(self):
        p = SSMParameter("/app/db/host", value="localhost")
        assert p.name == "/app/db/host"
        assert p.type == "String"
        assert p.existing is False


class TestSSMParameterLogicalId:
    def test_basic(self):
        p = SSMParameter("/app/db/host", value="x")
        # /app/db/host → AppDbHostParameter
        assert "Parameter" in p._logical_id()


class TestSSMParameterEnvVar:
    def test_last_segment(self):
        p = SSMParameter("/myapp/db/host", value="x")
        assert p.env_var_name() == "HOST"

    def test_value_ref(self):
        p = SSMParameter("/app/key", value="x")
        assert "Ref" in p.env_var_value()

    def test_value_existing(self):
        p = SSMParameter("/app/key", value="x", existing=True)
        assert p.env_var_value() == "/app/key"


class TestSSMParameterValidation:
    def test_valid(self):
        assert SSMParameter("/app/key", value="val").validate() == []

    def test_no_slash_prefix(self):
        errors = SSMParameter("app/key", value="val").validate()
        assert any("/" in e for e in errors)

    def test_empty_name(self):
        assert len(SSMParameter("", value="val").validate()) > 0

    def test_invalid_type(self):
        errors = SSMParameter("/k", value="v", type="Invalid").validate()
        assert any("type" in e.lower() for e in errors)

    def test_empty_value_non_secure(self):
        errors = SSMParameter("/k", value="").validate()
        assert any("vacío" in e for e in errors)

    def test_empty_value_secure_ok(self):
        errors = SSMParameter("/k", value="", type="SecureString").validate()
        assert not any("vacío" in e for e in errors)


class TestSSMParameterCfn:
    def test_basic(self):
        cfn = SSMParameter("/app/key", value="val").to_cfn()
        assert cfn["Type"] == "AWS::SSM::Parameter"
        assert cfn["Properties"]["Name"] == "/app/key"
        assert cfn["Properties"]["Value"] == "val"

    def test_existing_returns_empty(self):
        assert SSMParameter("/k", value="v", existing=True).to_cfn() == {}


class TestSSMParam:
    def test_plain_reference(self):
        ref = SSMParam("/prod/db/host").to_reference()
        assert ref == "{{resolve:ssm:/prod/db/host}}"

    def test_secure_reference(self):
        ref = SSMParam("/prod/secret", secure=True).to_reference()
        assert ref == "{{resolve:ssm-secure:/prod/secret}}"

    def test_versioned_reference(self):
        ref = SSMParam("/prod/config", version=3).to_reference()
        assert ref == "{{resolve:ssm:/prod/config:3}}"

    def test_secure_versioned(self):
        ref = SSMParam("/prod/secret", secure=True, version=1).to_reference()
        assert ref == "{{resolve:ssm-secure:/prod/secret:1}}"


class TestSSMParameterToPolicy:
    def test_crud_returns_read_policy(self):
        p = SSMParameter("/app/config", value="val")
        policies = p.to_policy("crud")
        assert policies == [{"SSMParameterReadPolicy": {"ParameterName": {"Ref": "AppConfigParameter"}}}]

    def test_read(self):
        policies = SSMParameter("/app/config", value="val").to_policy("read")
        assert policies == [{"SSMParameterReadPolicy": {"ParameterName": {"Ref": "AppConfigParameter"}}}]

    def test_write_returns_inline(self):
        p = SSMParameter("/app/config", value="val")
        policies = p.to_policy("write")
        assert len(policies) == 1
        stmt = policies[0]["Statement"][0]
        assert stmt["Action"] == ["ssm:PutParameter"]

    def test_existing_uses_name(self):
        p = SSMParameter("/app/config", value="val", existing=True)
        policies = p.to_policy("read")
        assert policies == [{"SSMParameterReadPolicy": {"ParameterName": "/app/config"}}]

    def test_valid_permission_levels(self):
        assert SSMParameter.VALID_PERMISSION_LEVELS == {"crud", "read", "write"}
