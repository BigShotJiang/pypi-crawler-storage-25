"""Tests for deployless.compiler.checker — pre-flight checks."""
from unittest.mock import MagicMock, patch

from deployless.compiler.checker import (
    LAMBDA_RESERVED_ENV_VARS,
    check_aws_credentials,
    check_reserved_env_vars,
    check_sam_installed,
    run_checks,
)


class TestReservedEnvVars:
    def test_no_errors_when_clean(self):
        state = {"features": {}, "crons": [], "lambdas": []}
        config = {"env": {"APP_NAME": "myapp", "DB_HOST": "localhost"}}
        assert check_reserved_env_vars(state, config) == []

    def test_catches_reserved_in_global_env(self):
        state = {"features": {}, "crons": [], "lambdas": []}
        config = {"env": {"AWS_REGION": "us-east-1", "APP_NAME": "ok"}}
        errors = check_reserved_env_vars(state, config)
        assert len(errors) == 1
        assert "C01" in errors[0]
        assert "AWS_REGION" in errors[0]

    def test_catches_reserved_in_feature_env(self):
        state = {
            "features": {
                "user": {"config": {"env": {"AWS_ACCESS_KEY_ID": "secret"}}, "routes": []},
            },
            "crons": [],
            "lambdas": [],
        }
        config = {"env": {}}
        errors = check_reserved_env_vars(state, config)
        assert len(errors) == 1
        assert "Feature 'user'" in errors[0]
        assert "AWS_ACCESS_KEY_ID" in errors[0]

    def test_catches_reserved_in_cron_env(self):
        state = {
            "features": {},
            "crons": [{"name": "cleanup", "env": {"AWS_SESSION_TOKEN": "tok"}}],
            "lambdas": [],
        }
        config = {"env": {}}
        errors = check_reserved_env_vars(state, config)
        assert len(errors) == 1
        assert "Cron 'cleanup'" in errors[0]
        assert "AWS_SESSION_TOKEN" in errors[0]

    def test_catches_reserved_in_lambda_env(self):
        state = {
            "features": {},
            "crons": [],
            "lambdas": [{"name": "worker", "env": {"LAMBDA_TASK_ROOT": "/var/task"}}],
        }
        config = {"env": {}}
        errors = check_reserved_env_vars(state, config)
        assert len(errors) == 1
        assert "Lambda 'worker'" in errors[0]

    def test_similar_name_not_reserved(self):
        """AWS_REGION_CUSTOM is not in the reserved list — exact match only."""
        state = {"features": {}, "crons": [], "lambdas": []}
        config = {"env": {
            "AWS_REGION_DYNAMODB": "us-east-1",
            "AWS_ACCESS_KEY_ID_CUSTOM": "abc",
        }}
        assert check_reserved_env_vars(state, config) == []

    def test_multiple_errors_collected(self):
        """All reserved vars are reported, not just the first one."""
        state = {"features": {}, "crons": [], "lambdas": []}
        config = {"env": {"AWS_REGION": "x", "AWS_ACCESS_KEY_ID": "y", "APP": "ok"}}
        errors = check_reserved_env_vars(state, config)
        assert len(errors) == 2

    def test_reserved_list_has_19_entries(self):
        assert len(LAMBDA_RESERVED_ENV_VARS) == 19


class TestSamInstalled:
    def test_sam_found(self):
        mock_result = MagicMock(returncode=0, stdout="SAM CLI, version 1.100.0")
        with patch("subprocess.run", return_value=mock_result):
            assert check_sam_installed() == []

    def test_sam_not_found(self):
        with patch("subprocess.run", side_effect=FileNotFoundError):
            errors = check_sam_installed()
            assert len(errors) == 1
            assert "C02" in errors[0]
            assert "not found" in errors[0]

    def test_sam_error_returncode(self):
        mock_result = MagicMock(returncode=1)
        with patch("subprocess.run", return_value=mock_result):
            errors = check_sam_installed()
            assert len(errors) == 1
            assert "C02" in errors[0]

    def test_sam_timeout(self):
        import subprocess
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("sam", 10)):
            errors = check_sam_installed()
            assert len(errors) == 1
            assert "timed out" in errors[0]


class TestAwsCredentials:
    def test_credentials_ok(self):
        mock_sts = MagicMock()
        mock_sts.get_caller_identity.return_value = {"Account": "123456789012"}
        with patch("boto3.client", return_value=mock_sts):
            assert check_aws_credentials() == []

    def test_no_credentials(self):
        from botocore.exceptions import NoCredentialsError
        with patch("boto3.client", side_effect=NoCredentialsError()):
            errors = check_aws_credentials()
            assert len(errors) == 1
            assert "C03" in errors[0]
            assert "not configured" in errors[0]

    def test_client_error(self):
        from botocore.exceptions import ClientError
        mock_sts = MagicMock()
        mock_sts.get_caller_identity.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Access denied"}},
            "GetCallerIdentity",
        )
        with patch("boto3.client", return_value=mock_sts):
            errors = check_aws_credentials()
            assert len(errors) == 1
            assert "C03" in errors[0]
            assert "Access denied" in errors[0]


class TestRunChecks:
    def _clean_state(self):
        return {"features": {}, "crons": [], "lambdas": []}

    def test_all_pass(self):
        mock_result = MagicMock(returncode=0)
        mock_sts = MagicMock()
        mock_sts.get_caller_identity.return_value = {"Account": "123"}
        with patch("subprocess.run", return_value=mock_result), \
             patch("boto3.client", return_value=mock_sts):
            errors = run_checks(self._clean_state(), {"env": {}})
            assert errors == []

    def test_collects_errors_from_all_checks(self):
        """Fail-slow: all checks run even if one fails."""
        mock_sts = MagicMock()
        from botocore.exceptions import NoCredentialsError
        mock_sts.get_caller_identity.side_effect = NoCredentialsError()

        state = self._clean_state()
        config = {"env": {"AWS_REGION": "us-east-1"}}  # reserved var

        with patch("subprocess.run", side_effect=FileNotFoundError), \
             patch("boto3.client", return_value=mock_sts):
            errors = run_checks(state, config)

        # Should have: C01 (reserved var) + C02 (SAM) + C03 (creds)
        assert "[C01" in " ".join(errors)
        assert "[C02" in " ".join(errors)
        assert "[C03" in " ".join(errors)
