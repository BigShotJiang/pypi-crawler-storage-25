"""Tests for deployless.providers.aws.certificate — ACM cert lifecycle and Route 53 auto-detect."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from deployless.providers.aws.certificate import (
    _acm_region,
    check_certificate_status,
    clear_domain_state,
    find_hosted_zone,
    get_validation_records,
    load_domain_state,
    request_certificate,
    save_certificate_arn,
    save_domain_state,
)

# ---------------------------------------------------------------------------
# find_hosted_zone
# ---------------------------------------------------------------------------

class TestFindHostedZone:
    @patch("deployless.providers.aws.certificate.boto3")
    def test_finds_matching_zone(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.list_hosted_zones_by_name.return_value = {
            "HostedZones": [
                {
                    "Id": "/hostedzone/Z1234567890",
                    "Name": "myapp.com.",
                    "Config": {"PrivateZone": False},
                }
            ]
        }
        zone_id = find_hosted_zone("api.myapp.com")
        assert zone_id == "Z1234567890"
        client.list_hosted_zones_by_name.assert_called_once_with(DNSName="myapp.com.", MaxItems="10")

    @patch("deployless.providers.aws.certificate.boto3")
    def test_no_zone_found(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.list_hosted_zones_by_name.return_value = {"HostedZones": []}
        with pytest.raises(RuntimeError, match="No public Route 53 hosted zone"):
            find_hosted_zone("api.myapp.com")

    @patch("deployless.providers.aws.certificate.boto3")
    def test_skips_private_zones(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.list_hosted_zones_by_name.return_value = {
            "HostedZones": [
                {
                    "Id": "/hostedzone/ZPRIVATE",
                    "Name": "myapp.com.",
                    "Config": {"PrivateZone": True},
                }
            ]
        }
        with pytest.raises(RuntimeError, match="No public Route 53 hosted zone"):
            find_hosted_zone("api.myapp.com")

    @patch("deployless.providers.aws.certificate.boto3")
    def test_multiple_zones_raises(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.list_hosted_zones_by_name.return_value = {
            "HostedZones": [
                {"Id": "/hostedzone/Z1", "Name": "myapp.com.", "Config": {"PrivateZone": False}},
                {"Id": "/hostedzone/Z2", "Name": "myapp.com.", "Config": {"PrivateZone": False}},
            ]
        }
        with pytest.raises(RuntimeError, match="Multiple Route 53 hosted zones"):
            find_hosted_zone("api.myapp.com")

    def test_invalid_domain(self):
        with pytest.raises(RuntimeError, match="Cannot derive base domain"):
            find_hosted_zone("localhost")


# ---------------------------------------------------------------------------
# ACM certificate operations
# ---------------------------------------------------------------------------

class TestRequestCertificate:
    @patch("deployless.providers.aws.certificate.boto3")
    def test_request(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.request_certificate.return_value = {
            "CertificateArn": "arn:aws:acm:us-east-1:123:certificate/abc"
        }
        arn = request_certificate("api.myapp.com")
        assert arn == "arn:aws:acm:us-east-1:123:certificate/abc"
        client.request_certificate.assert_called_once_with(
            DomainName="api.myapp.com",
            ValidationMethod="DNS",
        )


class TestGetValidationRecords:
    @patch("deployless.providers.aws.certificate.boto3")
    def test_returns_records(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.describe_certificate.return_value = {
            "Certificate": {
                "DomainValidationOptions": [
                    {
                        "DomainName": "api.myapp.com",
                        "ResourceRecord": {
                            "Name": "_acme.api.myapp.com",
                            "Type": "CNAME",
                            "Value": "xxx.acm-validations.aws",
                        },
                    }
                ]
            }
        }
        records = get_validation_records("arn:aws:acm:...", timeout=1)
        assert len(records) == 1
        assert records[0]["Name"] == "_acme.api.myapp.com"
        assert records[0]["Value"] == "xxx.acm-validations.aws"


class TestCheckCertificateStatus:
    @patch("deployless.providers.aws.certificate.boto3")
    def test_returns_status(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.describe_certificate.return_value = {
            "Certificate": {"Status": "ISSUED"}
        }
        assert check_certificate_status("arn:aws:acm:...") == "ISSUED"

    @patch("deployless.providers.aws.certificate.boto3")
    def test_pending(self, mock_boto3):
        client = MagicMock()
        mock_boto3.client.return_value = client
        client.describe_certificate.return_value = {
            "Certificate": {"Status": "PENDING_VALIDATION"}
        }
        assert check_certificate_status("arn:aws:acm:...") == "PENDING_VALIDATION"


# ---------------------------------------------------------------------------
# ACM region
# ---------------------------------------------------------------------------

class TestAcmRegion:
    def test_edge_uses_us_east_1(self):
        assert _acm_region("EDGE") == "us-east-1"

    @patch("deployless.providers.aws.certificate.boto3")
    def test_regional_uses_session_region(self, mock_boto3):
        session = MagicMock()
        session.region_name = "eu-west-1"
        mock_boto3.session.Session.return_value = session
        assert _acm_region("REGIONAL") == "eu-west-1"


# ---------------------------------------------------------------------------
# State file operations
# ---------------------------------------------------------------------------

class TestDomainState:
    def test_load_no_file(self, tmp_path):
        assert load_domain_state(tmp_path) is None

    def test_save_and_load(self, tmp_path):
        state = {"certificate_arn": "arn:...", "domain_name": "api.myapp.com"}
        save_domain_state(tmp_path, state)
        loaded = load_domain_state(tmp_path)
        assert loaded == state

    def test_clear(self, tmp_path):
        save_domain_state(tmp_path, {"cert": "arn"})
        clear_domain_state(tmp_path)
        assert load_domain_state(tmp_path) is None

    def test_clear_no_file(self, tmp_path):
        # Should not raise
        clear_domain_state(tmp_path)


# ---------------------------------------------------------------------------
# save_certificate_arn
# ---------------------------------------------------------------------------

class TestSaveCertificateArn:
    def test_writes_to_yaml(self, tmp_path):
        import yaml

        config = {"api": {"domain": {"domain_name": "api.myapp.com"}}}
        config_path = tmp_path / "deployless.yaml"
        with open(config_path, "w") as f:
            yaml.dump(config, f)

        save_certificate_arn(tmp_path, "arn:aws:acm:us-east-1:123:certificate/abc")

        with open(config_path) as f:
            result = yaml.safe_load(f)
        assert result["api"]["domain"]["certificate_arn"] == "arn:aws:acm:us-east-1:123:certificate/abc"
        assert result["api"]["domain"]["domain_name"] == "api.myapp.com"
