"""Tests for deployless.compiler.env_file."""
from deployless.compiler.env_file import _ssm_path, build_secret_env_vars, parse_env_file


class TestParseEnvFile:
    def test_plain_vars(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("DB_HOST=localhost\nAPI_URL=https://api.com\n")
        plain, secrets = parse_env_file(env)
        assert plain == {"DB_HOST": "localhost", "API_URL": "https://api.com"}
        assert secrets == {}

    def test_secret_vars(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("SECRET_API_KEY=abc123\nSECRET_DB_PASS=pass\n")
        plain, secrets = parse_env_file(env)
        assert plain == {}
        assert secrets == {"SECRET_API_KEY": "abc123", "SECRET_DB_PASS": "pass"}

    def test_mixed_vars(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("DB_HOST=localhost\nSECRET_TOKEN=xyz\n")
        plain, secrets = parse_env_file(env)
        assert plain == {"DB_HOST": "localhost"}
        assert secrets == {"SECRET_TOKEN": "xyz"}

    def test_comments_and_blanks_ignored(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("# comment\n\nDB_HOST=localhost\n\n# another comment\n")
        plain, _ = parse_env_file(env)
        assert plain == {"DB_HOST": "localhost"}

    def test_quoted_values(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text('SINGLE=\'value1\'\nDOUBLE="value2"\n')
        plain, _ = parse_env_file(env)
        assert plain == {"SINGLE": "value1", "DOUBLE": "value2"}

    def test_equals_in_value(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("URL=https://api.com?key=abc&token=xyz\n")
        plain, _ = parse_env_file(env)
        assert plain["URL"] == "https://api.com?key=abc&token=xyz"

    def test_no_equals_skipped(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("INVALID_LINE\nVALID=ok\n")
        plain, _ = parse_env_file(env)
        assert plain == {"VALID": "ok"}

    def test_secret_prefix_only(self, tmp_path):
        env = tmp_path / ".env"
        env.write_text("SECRET_=nokey\n")
        plain, secrets = parse_env_file(env)
        assert secrets == {"SECRET_": "nokey"}


class TestSsmPath:
    def test_basic(self):
        assert _ssm_path("my-app", "API_KEY") == "/my-app/API_KEY"

    def test_special_chars_normalized(self):
        path = _ssm_path("My App Name!", "DB_PASS")
        assert path == "/my-app-name-/DB_PASS"


class TestBuildSecretEnvVars:
    def test_returns_ssm_params(self):
        result = build_secret_env_vars("my-app", ["API_KEY", "DB_PASS"])
        assert "API_KEY" in result
        assert "DB_PASS" in result
        ref = result["API_KEY"].to_reference()
        assert "{{resolve:ssm:/my-app/API_KEY}}" == ref
