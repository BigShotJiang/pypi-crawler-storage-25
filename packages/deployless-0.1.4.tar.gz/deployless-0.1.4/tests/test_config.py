"""Tests for deployless.core.config."""
import pytest

from deployless.core.config import (
    ConfigError,
    _deep_merge,
    _interpolate_config,
    _resolve_env_vars,
    load_config,
)


class TestDeepMerge:
    def test_simple_override(self):
        result = _deep_merge({"a": 1}, {"a": 2})
        assert result == {"a": 2}

    def test_adds_new_keys(self):
        result = _deep_merge({"a": 1}, {"b": 2})
        assert result == {"a": 1, "b": 2}

    def test_nested_merge(self):
        base = {"api": {"cors": {"allow_origin": "*"}, "endpoint_type": "REGIONAL"}}
        override = {"api": {"cors": {"allow_origin": "https://example.com"}}}
        result = _deep_merge(base, override)
        assert result["api"]["cors"]["allow_origin"] == "https://example.com"
        assert result["api"]["endpoint_type"] == "REGIONAL"

    def test_list_replaced_not_merged(self):
        base = {"methods": ["GET"]}
        override = {"methods": ["GET", "POST"]}
        result = _deep_merge(base, override)
        assert result["methods"] == ["GET", "POST"]


class TestLoadConfig:
    def test_defaults_without_yaml(self, tmp_path):
        config = load_config(tmp_path)
        assert config["name"] == "deployless-app"
        assert config["provider"] == "aws"
        assert config["stage"] == "dev"
        assert config["globals"]["runtime"] == "python3.13"
        assert config["globals"]["memory"] == 256

    def test_overrides_from_yaml(self, tmp_path):
        (tmp_path / "deployless.yaml").write_text(
            "name: my-api\nstage: prod\nglobals:\n  memory: 512\n"
        )
        config = load_config(tmp_path)
        assert config["name"] == "my-api"
        assert config["stage"] == "prod"
        assert config["globals"]["memory"] == 512
        # Defaults preserved
        assert config["globals"]["runtime"] == "python3.13"

    def test_env_file_default_none(self, tmp_path):
        config = load_config(tmp_path)
        assert config["env_file"] is None


class TestEnvVarInterpolation:
    def test_simple_substitution(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "hello")
        resolved, errors = _resolve_env_vars("${MY_VAR}")
        assert resolved == "hello"
        assert errors == []

    def test_default_value_when_missing(self):
        resolved, errors = _resolve_env_vars("${MISSING_VAR:-fallback}")
        assert resolved == "fallback"
        assert errors == []

    def test_default_ignored_when_var_exists(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "real")
        resolved, errors = _resolve_env_vars("${MY_VAR:-fallback}")
        assert resolved == "real"
        assert errors == []

    def test_empty_default(self):
        resolved, errors = _resolve_env_vars("${MISSING_VAR:-}")
        assert resolved == ""
        assert errors == []

    def test_default_with_colons(self):
        resolved, errors = _resolve_env_vars("${MISSING_VAR:-http://host:8080}")
        assert resolved == "http://host:8080"
        assert errors == []

    def test_mixed_string(self, monkeypatch):
        monkeypatch.setenv("HOST", "api.example.com")
        monkeypatch.setenv("PORT", "443")
        resolved, errors = _resolve_env_vars("https://${HOST}:${PORT}/v1")
        assert resolved == "https://api.example.com:443/v1"
        assert errors == []

    def test_missing_var_returns_error(self):
        resolved, errors = _resolve_env_vars("${TOTALLY_UNDEFINED}")
        assert len(errors) == 1
        assert "[E32]" in errors[0]
        assert "TOTALLY_UNDEFINED" in errors[0]

    def test_multiple_missing_vars_collects_all_errors(self):
        _, errors = _resolve_env_vars("${MISSING_A} and ${MISSING_B}")
        assert len(errors) == 2
        assert "MISSING_A" in errors[0]
        assert "MISSING_B" in errors[1]

    def test_nested_dict_interpolation(self, monkeypatch):
        monkeypatch.setenv("DOMAIN", "api.myapp.com")
        obj = {"api": {"domain": {"domain_name": "${DOMAIN}"}}}
        result, errors = _interpolate_config(obj)
        assert result["api"]["domain"]["domain_name"] == "api.myapp.com"
        assert errors == []

    def test_non_string_values_untouched(self):
        obj = {"memory": 256, "timeout": 30, "verbose": True, "x": None}
        result, errors = _interpolate_config(obj)
        assert result == obj
        assert errors == []

    def test_strings_in_lists(self, monkeypatch):
        monkeypatch.setenv("HEADER", "X-Custom")
        obj = {"headers": ["Content-Type", "${HEADER}"]}
        result, errors = _interpolate_config(obj)
        assert result["headers"] == ["Content-Type", "X-Custom"]
        assert errors == []

    def test_no_vars_passthrough(self):
        obj = {"name": "my-app", "stage": "dev"}
        result, errors = _interpolate_config(obj)
        assert result == obj
        assert errors == []

    def test_load_config_with_interpolation(self, tmp_path, monkeypatch):
        monkeypatch.setenv("APP_DOMAIN", "api.myapp.com")
        (tmp_path / "deployless.yaml").write_text(
            "name: my-api\napi:\n  domain:\n    domain_name: ${APP_DOMAIN}\n"
        )
        config = load_config(tmp_path)
        assert config["api"]["domain"]["domain_name"] == "api.myapp.com"

    def test_load_config_raises_on_missing_var(self, tmp_path):
        (tmp_path / "deployless.yaml").write_text(
            "api:\n  domain:\n    domain_name: ${UNDEFINED_DOMAIN}\n"
        )
        with pytest.raises(ConfigError) as exc_info:
            load_config(tmp_path)
        assert len(exc_info.value.errors) == 1
        assert "UNDEFINED_DOMAIN" in exc_info.value.errors[0]
