"""Tests for deployless.compiler.replacement — replacement detection."""
from __future__ import annotations

from pathlib import Path

import yaml

from deployless.compiler.replacement import check_replacements


def _write_template(tmp_path: Path, resources: dict) -> Path:
    """Write a minimal template.yaml and return its path."""
    path = tmp_path / "template.yaml"
    template = {"AWSTemplateFormatVersion": "2010-09-09", "Resources": resources}
    with open(path, "w") as f:
        yaml.dump(template, f)
    return path


def _template(resources: dict) -> dict:
    return {"AWSTemplateFormatVersion": "2010-09-09", "Resources": resources}


# -- Helpers for building resource snippets ----------------------------------

def _dynamo(table_name="todos", key_schema=None):
    if key_schema is None:
        key_schema = [{"AttributeName": "id", "KeyType": "HASH"}]
    return {
        "Type": "AWS::DynamoDB::Table",
        "Properties": {"TableName": table_name, "KeySchema": key_schema},
    }


def _s3(bucket_name="my-bucket"):
    return {
        "Type": "AWS::S3::Bucket",
        "Properties": {"BucketName": bucket_name},
    }


def _sqs(queue_name="my-queue", fifo=False):
    props = {"QueueName": queue_name}
    if fifo:
        props["FifoQueue"] = True
    return {"Type": "AWS::SQS::Queue", "Properties": props}


def _kms(key_usage="ENCRYPT_DECRYPT", key_spec="SYMMETRIC_DEFAULT"):
    return {
        "Type": "AWS::KMS::Key",
        "Properties": {"KeyUsage": key_usage, "KeySpec": key_spec},
    }


def _ssm(name="/app/param", param_type="String"):
    return {
        "Type": "AWS::SSM::Parameter",
        "Properties": {"Name": name, "Type": param_type},
    }


# -- Tests -------------------------------------------------------------------

class TestNoWarnings:
    """Cases that should produce zero warnings."""

    def test_no_old_template(self, tmp_path):
        new = _template({"T": _dynamo()})
        path = tmp_path / "template.yaml"  # does not exist
        assert check_replacements(new, path) == []

    def test_no_changes(self, tmp_path):
        resources = {"T": _dynamo()}
        path = _write_template(tmp_path, resources)
        assert check_replacements(_template(resources), path) == []

    def test_new_resource_added(self, tmp_path):
        path = _write_template(tmp_path, {"T": _dynamo()})
        new = _template({"T": _dynamo(), "B": _s3()})
        assert check_replacements(new, path) == []

    def test_resource_removed(self, tmp_path):
        path = _write_template(tmp_path, {"T": _dynamo(), "B": _s3()})
        new = _template({"T": _dynamo()})
        assert check_replacements(new, path) == []

    def test_non_replacement_property_changed(self, tmp_path):
        # Rebuild properly
        old_res = _dynamo()
        old_res["Properties"]["BillingMode"] = "PAY_PER_REQUEST"
        new_res = _dynamo()
        new_res["Properties"]["BillingMode"] = "PROVISIONED"
        path = _write_template(tmp_path, {"T": old_res})
        assert check_replacements(_template({"T": new_res}), path) == []

    def test_corrupt_old_template(self, tmp_path):
        path = tmp_path / "template.yaml"
        path.write_text("not: valid: yaml: [")
        new = _template({"T": _dynamo()})
        assert check_replacements(new, path) == []


class TestDynamoDB:
    def test_key_schema_changed(self, tmp_path):
        old_ks = [{"AttributeName": "id", "KeyType": "HASH"}]
        new_ks = [
            {"AttributeName": "id", "KeyType": "HASH"},
            {"AttributeName": "sk", "KeyType": "RANGE"},
        ]
        path = _write_template(tmp_path, {"T": _dynamo(key_schema=old_ks)})
        warnings = check_replacements(_template({"T": _dynamo(key_schema=new_ks)}), path)
        assert len(warnings) == 1
        assert "[W01]" in warnings[0]
        assert "key schema" in warnings[0].lower()

    def test_table_name_changed(self, tmp_path):
        path = _write_template(tmp_path, {"T": _dynamo("old-name")})
        warnings = check_replacements(_template({"T": _dynamo("new-name")}), path)
        assert len(warnings) == 1
        assert "table name" in warnings[0].lower()


class TestS3:
    def test_bucket_name_changed(self, tmp_path):
        path = _write_template(tmp_path, {"B": _s3("old-bucket")})
        warnings = check_replacements(_template({"B": _s3("new-bucket")}), path)
        assert len(warnings) == 1
        assert "bucket name" in warnings[0].lower()


class TestSQS:
    def test_queue_name_changed(self, tmp_path):
        path = _write_template(tmp_path, {"Q": _sqs("old-queue")})
        warnings = check_replacements(_template({"Q": _sqs("new-queue")}), path)
        assert len(warnings) == 1
        assert "queue name" in warnings[0].lower()

    def test_fifo_changed(self, tmp_path):
        path = _write_template(tmp_path, {"Q": _sqs("q", fifo=False)})
        warnings = check_replacements(_template({"Q": _sqs("q", fifo=True)}), path)
        assert len(warnings) == 1
        assert "fifo" in warnings[0].lower()


class TestKMS:
    def test_key_usage_changed(self, tmp_path):
        path = _write_template(tmp_path, {"K": _kms(key_usage="ENCRYPT_DECRYPT")})
        warnings = check_replacements(_template({"K": _kms(key_usage="SIGN_VERIFY")}), path)
        assert len(warnings) == 1
        assert "key usage" in warnings[0].lower()

    def test_key_spec_changed(self, tmp_path):
        path = _write_template(tmp_path, {"K": _kms(key_spec="SYMMETRIC_DEFAULT")})
        warnings = check_replacements(_template({"K": _kms(key_spec="RSA_2048")}), path)
        assert len(warnings) == 1
        assert "key spec" in warnings[0].lower()


class TestSSM:
    def test_name_changed(self, tmp_path):
        path = _write_template(tmp_path, {"P": _ssm("/old/path")})
        warnings = check_replacements(_template({"P": _ssm("/new/path")}), path)
        assert len(warnings) == 1
        assert "parameter name" in warnings[0].lower()

    def test_type_changed(self, tmp_path):
        path = _write_template(tmp_path, {"P": _ssm(param_type="String")})
        warnings = check_replacements(_template({"P": _ssm(param_type="SecureString")}), path)
        assert len(warnings) == 1
        assert "parameter type" in warnings[0].lower()


class TestMultiple:
    def test_multiple_replacements(self, tmp_path):
        path = _write_template(tmp_path, {
            "T": _dynamo("old-table"),
            "B": _s3("old-bucket"),
        })
        new = _template({
            "T": _dynamo("new-table"),
            "B": _s3("new-bucket"),
        })
        warnings = check_replacements(new, path)
        assert len(warnings) == 2

    def test_dynamo_both_name_and_schema(self, tmp_path):
        old_ks = [{"AttributeName": "id", "KeyType": "HASH"}]
        new_ks = [{"AttributeName": "pk", "KeyType": "HASH"}]
        path = _write_template(tmp_path, {"T": _dynamo("old", old_ks)})
        warnings = check_replacements(_template({"T": _dynamo("new", new_ks)}), path)
        assert len(warnings) == 2
