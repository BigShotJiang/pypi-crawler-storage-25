"""Integration tests for the full compilation pipeline."""
from unittest.mock import patch

import pytest
import yaml

from deployless.compiler.main import compile_project
from deployless.compiler.validator import ValidationError


class TestFullCompilation:
    def test_compiles_simple_project(self, tmp_project):
        tmp_project.add_config("""\
            name: test-app
            stage: dev
        """)
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify

            bp = Blueprint("auth", __name__, url_prefix="/auth")

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({"ok": True})
        """)

        state = compile_project(project_root=str(tmp_project.root))

        assert "auth" in state["features"]
        assert len(state["features"]["auth"]["routes"]) == 1
        # Check .dist was created
        dist = tmp_project.root / ".dist"
        assert dist.exists()
        assert (dist / "AuthFunction" / "bootstrap.py").exists()
        assert (dist / "AuthFunction" / "app" / "features" / "auth" / "routes.py").exists()
        # Check template.yaml was created
        template_path = tmp_project.root / "template.yaml"
        assert template_path.exists()
        with open(template_path) as f:
            template = yaml.safe_load(f)
        assert "AuthFunction" in template["Resources"]

    def test_compiles_multiple_features(self, tmp_project):
        tmp_project.add_config("name: multi-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("auth", __name__, url_prefix="/auth")

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)
        tmp_project.add_feature("user", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("user", __name__, url_prefix="/users")

            @bp.route("/", methods=["GET"])
            def list_users():
                return jsonify([])
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert "auth" in state["features"]
        assert "user" in state["features"]

    def test_compiles_with_cron(self, tmp_project):
        tmp_project.add_config("name: cron-app\n")
        tmp_project.add_feature("tasks", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("tasks", __name__, url_prefix="/tasks")

            @bp.route("/", methods=["GET"])
            def list_tasks():
                return jsonify([])

            @pc.cron(schedule="rate(1 hour)", memory=128, timeout=60)
            def cleanup(event, context):
                return {"status": "ok"}
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert len(state["crons"]) == 1
        assert state["crons"][0]["name"] == "cleanup"
        # Cron package built
        assert (tmp_project.root / ".dist" / "CleanupFunction" / "bootstrap.py").exists()

    def test_compiles_with_lambda_function(self, tmp_project):
        tmp_project.add_config("name: lambda-app\n")
        tmp_project.add_feature("worker", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("worker", __name__, url_prefix="/work")

            @bp.route("/status", methods=["GET"])
            def status():
                return jsonify({"ok": True})

            @pc.lambda_function(memory=512, timeout=120)
            def process_queue(event, context):
                return {"processed": True}
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert len(state["lambdas"]) == 1
        assert state["lambdas"][0]["name"] == "process_queue"
        # Lambda package built
        assert (tmp_project.root / ".dist" / "ProcessQueueFunction" / "bootstrap.py").exists()
        # In template
        template_path = tmp_project.root / "template.yaml"
        with open(template_path) as f:
            template = yaml.safe_load(f)
        assert "ProcessQueueFunction" in template["Resources"]

    def test_compiles_with_resources(self, tmp_project):
        tmp_project.add_config("name: res-app\n")
        tmp_project.add_feature("user", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("user", __name__, url_prefix="/users")

            pc.configure(
                memory=512,
                resources={
                    "users": pc.DynamoDB("users-table", pk="id"),
                }
            )

            @bp.route("/", methods=["GET"])
            def list_users():
                return jsonify([])
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert "users" in state["features"]["user"]["resources"]
        template_path = tmp_project.root / "template.yaml"
        with open(template_path) as f:
            template = yaml.safe_load(f)
        assert "UsersTable" in template["Resources"]

    def test_auto_detects_resources_in_feature(self, tmp_project):
        """Resources created in routes.py are auto-detected without configure(resources=...)."""
        tmp_project.add_config("name: autodetect-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("auth", __name__, url_prefix="/auth")

            events_table = pc.DynamoDB("events-table")

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert "events_table" in state["features"]["auth"]["resources"]
        assert state["features"]["auth"]["resource_permissions"]["events_table"] == "crud"
        template_path = tmp_project.root / "template.yaml"
        with open(template_path) as f:
            template = yaml.safe_load(f)
        assert "EventsTable" in template["Resources"]

    def test_auto_detect_with_permission_override(self, tmp_project):
        """Auto-detected resource + configure() override → override wins."""
        tmp_project.add_config("name: override-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("auth", __name__, url_prefix="/auth")

            events_table = pc.DynamoDB("events-table")
            pc.configure(resources={"events_table": (events_table, "read")})

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)

        state = compile_project(project_root=str(tmp_project.root))
        assert state["features"]["auth"]["resource_permissions"]["events_table"] == "read"

    def test_dry_run_no_files(self, tmp_project):
        tmp_project.add_config("name: dry-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("auth", __name__, url_prefix="/auth")

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)

        state = compile_project(project_root=str(tmp_project.root), dry_run=True)
        assert "auth" in state["features"]
        assert not (tmp_project.root / ".dist").exists()
        assert not (tmp_project.root / "template.yaml").exists()

    def test_stage_override(self, tmp_project):
        tmp_project.add_config("name: stage-app\nstage: dev\n")
        tmp_project.add_feature("api", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("api", __name__, url_prefix="/api")

            @bp.route("/health", methods=["GET"])
            def health():
                return jsonify({})
        """)

        compile_project(project_root=str(tmp_project.root), stage="prod")
        template_path = tmp_project.root / "template.yaml"
        with open(template_path) as f:
            template = yaml.safe_load(f)
        assert template["Resources"]["Api"]["Properties"]["StageName"] == "prod"


class TestScreamingArchitecture:
    def test_compiles_screaming_arch_entry(self, tmp_project):
        """Feature with routes/{feature}_routes.py entry point compiles correctly."""
        tmp_project.add_config("name: screaming-app\n")
        tmp_project.add_feature_entry("user", "routes/user_routes.py", """\
            import deployless as pc
            from flask import Blueprint, jsonify

            pc.configure(memory=512, description="User service")

            user_bp = Blueprint("user_bp", __name__, url_prefix="/users")

            @user_bp.route("", methods=["GET"])
            def list_users():
                return jsonify([])

            @user_bp.route("/<user_id>", methods=["GET"])
            def get_user(user_id):
                return jsonify({})
        """)

        state = compile_project(project_root=str(tmp_project.root))

        assert "user" in state["features"]
        assert len(state["features"]["user"]["routes"]) == 2
        assert state["features"]["user"]["config"]["memory"] == 512
        assert state["features"]["user"]["config"]["description"] == "User service"

        dist = tmp_project.root / ".dist"
        assert (dist / "UserFunction" / "bootstrap.py").exists()

    def test_configure_from_helper_in_routes_file(self, tmp_project):
        """configure() works even when called indirectly from a helper inside routes.py."""
        tmp_project.add_config("name: helper-app\n")
        tmp_project.add_feature("order", """\
            import deployless as pc
            from flask import Blueprint, jsonify

            def apply_lambda_config():
                pc.configure(memory=1024, timeout=60)

            apply_lambda_config()

            order_bp = Blueprint("order_bp", __name__, url_prefix="/orders")

            @order_bp.route("", methods=["POST"])
            def create_order():
                return jsonify({}), 201
        """)

        state = compile_project(project_root=str(tmp_project.root))

        assert state["features"]["order"]["config"]["memory"] == 1024
        assert state["features"]["order"]["config"]["timeout"] == 60

    def test_mixed_arch_multiple_features(self, tmp_project):
        """Classic routes.py + screaming arch features coexist in the same project."""
        tmp_project.add_config("name: mixed-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("auth", __name__, url_prefix="/auth")

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)
        tmp_project.add_feature_entry("user", "routes/user_routes.py", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("user_bp", __name__, url_prefix="/users")

            @bp.route("", methods=["GET"])
            def list_users():
                return jsonify([])
        """)

        state = compile_project(project_root=str(tmp_project.root))

        assert "auth" in state["features"]
        assert "user" in state["features"]


class TestValidationFailures:
    def test_invalid_memory_fails(self, tmp_project):
        tmp_project.add_config("name: bad-app\n")
        tmp_project.add_feature("auth", """\
            from flask import Blueprint, jsonify
            import deployless as pc

            bp = Blueprint("auth", __name__, url_prefix="/auth")
            pc.configure(memory=50)

            @bp.route("/login", methods=["POST"])
            def login():
                return jsonify({})
        """)

        with pytest.raises(ValidationError, match="E05"):
            compile_project(project_root=str(tmp_project.root))

    def test_no_routes_fails(self, tmp_project):
        tmp_project.add_config("name: empty-app\n")
        tmp_project.add_feature("empty", """\
            from flask import Blueprint
            bp = Blueprint("empty", __name__, url_prefix="/empty")
            # No routes defined
        """)

        with pytest.raises(ValidationError, match="E07"):
            compile_project(project_root=str(tmp_project.root))


class TestPushSecrets:
    def _make_project_with_env(self, tmp_project):
        tmp_project.add_config("""\
            name: secrets-app
            env_file: .env
        """)
        tmp_project.add_feature("api", """\
            from flask import Blueprint, jsonify
            bp = Blueprint("api", __name__, url_prefix="/api")

            @bp.route("/health", methods=["GET"])
            def health():
                return jsonify({})
        """)
        tmp_project.add_env_file("DB_HOST=localhost\nSECRET_API_KEY=abc123\n")

    def test_push_secrets_false_does_not_call_push(self, tmp_project):
        """Default behavior: secrets are NOT pushed to SSM during build."""
        self._make_project_with_env(tmp_project)

        with patch("deployless.compiler.main._push_secrets") as mock_push:
            compile_project(project_root=str(tmp_project.root), push_secrets=False)
            mock_push.assert_not_called()

    def test_push_secrets_true_calls_push(self, tmp_project):
        """With push_secrets=True, secrets are pushed to SSM."""
        self._make_project_with_env(tmp_project)

        with patch("deployless.compiler.main._push_secrets", return_value=[]) as mock_push:
            compile_project(project_root=str(tmp_project.root), push_secrets=True)
            mock_push.assert_called_once()
            call_args = mock_push.call_args
            assert call_args[0][0] == "secrets-app"  # app_name

    def test_push_secrets_dry_run_never_pushes(self, tmp_project):
        """dry_run=True never pushes even when push_secrets=True."""
        self._make_project_with_env(tmp_project)

        with patch("deployless.compiler.main._push_secrets") as mock_push:
            compile_project(
                project_root=str(tmp_project.root),
                push_secrets=True,
                dry_run=True,
            )
            mock_push.assert_not_called()


class TestDeployFirstRun:
    def test_samconfig_missing_is_first_deploy(self, tmp_path):
        """No samconfig.toml → first deploy detected."""
        assert not (tmp_path / "samconfig.toml").exists()

    def test_samconfig_present_is_not_first_deploy(self, tmp_path):
        """samconfig.toml present → not first deploy."""
        (tmp_path / "samconfig.toml").write_text("[default.deploy.parameters]\n")
        assert (tmp_path / "samconfig.toml").exists()
