"""Tests for SQS resource."""
from deployless.providers.aws.resources.sqs import SQS


class TestSQSInit:
    def test_defaults(self):
        q = SQS("my-queue")
        assert q.queue_name == "my-queue"
        assert q.fifo is False
        assert q.dlq is False
        assert q.visibility_timeout == 30
        assert q.message_retention == 345600
        assert q.encryption is True

    def test_fifo_auto_suffix(self):
        q = SQS("orders", fifo=True)
        assert q.queue_name == "orders.fifo"

    def test_fifo_no_double_suffix(self):
        q = SQS("orders.fifo", fifo=True)
        assert q.queue_name == "orders.fifo"


class TestSQSLogicalId:
    def test_strips_queue_suffix(self):
        assert SQS("notifications-queue")._logical_id() == "NotificationsQueue"

    def test_no_suffix(self):
        assert SQS("events")._logical_id() == "EventsQueue"

    def test_fifo_strips_suffix(self):
        assert SQS("orders", fifo=True)._logical_id() == "OrdersQueue"


class TestSQSEnvVar:
    def test_basic(self):
        assert SQS("notifications-queue").env_var_name() == "NOTIFICATIONS_QUEUE_URL"

    def test_no_suffix(self):
        assert SQS("events").env_var_name() == "EVENTS_QUEUE_URL"


class TestSQSValidation:
    def test_valid(self):
        assert SQS("my-queue").validate() == []

    def test_empty_name(self):
        assert len(SQS("").validate()) > 0

    def test_too_long(self):
        assert len(SQS("a" * 81).validate()) > 0

    def test_invalid_chars(self):
        assert len(SQS("queue name!").validate()) > 0

    def test_visibility_timeout_range(self):
        assert len(SQS("q", visibility_timeout=-1).validate()) > 0
        assert len(SQS("q", visibility_timeout=43201).validate()) > 0

    def test_message_retention_range(self):
        assert len(SQS("q", message_retention=59).validate()) > 0
        assert len(SQS("q", message_retention=1209601).validate()) > 0

    def test_max_receive_count_range(self):
        assert len(SQS("q", max_receive_count=0).validate()) > 0
        assert len(SQS("q", max_receive_count=1001).validate()) > 0


class TestSQSCfn:
    def test_basic(self):
        cfn = SQS("my-queue").to_cfn()
        logical_id = SQS("my-queue")._logical_id()
        assert logical_id in cfn
        assert cfn[logical_id]["Type"] == "AWS::SQS::Queue"

    def test_encryption(self):
        cfn = SQS("q").to_cfn()
        logical_id = SQS("q")._logical_id()
        assert cfn[logical_id]["Properties"]["SqsManagedSseEnabled"] is True

    def test_fifo_properties(self):
        cfn = SQS("q", fifo=True).to_cfn()
        logical_id = SQS("q", fifo=True)._logical_id()
        props = cfn[logical_id]["Properties"]
        assert props["FifoQueue"] is True
        assert props["ContentBasedDeduplication"] is True

    def test_dlq_creates_two_queues(self):
        cfn = SQS("my-queue", dlq=True).to_cfn()
        assert len(cfn) == 2  # main + DLQ

    def test_dlq_has_redrive_policy(self):
        q = SQS("my-queue", dlq=True, max_receive_count=5)
        cfn = q.to_cfn()
        main = cfn[q._logical_id()]
        assert main["Properties"]["RedrivePolicy"]["maxReceiveCount"] == 5

    def test_existing_returns_empty(self):
        assert SQS("old-queue", existing=True).to_cfn() == {}


class TestSQSToPolicy:
    def test_crud_returns_both(self):
        q = SQS("my-queue")
        policies = q.to_policy("crud")
        assert len(policies) == 2
        assert {"SQSSendMessagePolicy": {"QueueName": {"Fn::GetAtt": ["MyQueue", "QueueName"]}}} in policies
        assert {"SQSPollerPolicy": {"QueueName": {"Fn::GetAtt": ["MyQueue", "QueueName"]}}} in policies

    def test_send(self):
        policies = SQS("my-queue").to_policy("send")
        assert policies == [{"SQSSendMessagePolicy": {"QueueName": {"Fn::GetAtt": ["MyQueue", "QueueName"]}}}]

    def test_poll(self):
        policies = SQS("my-queue").to_policy("poll")
        assert policies == [{"SQSPollerPolicy": {"QueueName": {"Fn::GetAtt": ["MyQueue", "QueueName"]}}}]

    def test_existing_uses_queue_name(self):
        policies = SQS("my-queue", existing=True).to_policy("send")
        assert policies == [{"SQSSendMessagePolicy": {"QueueName": "my-queue"}}]

    def test_valid_permission_levels(self):
        assert SQS.VALID_PERMISSION_LEVELS == {"crud", "send", "poll"}
