"""Tests for deployless.core.metadata — decorators, Ref, GetAtt, auto-detect."""
import deployless as pc
from deployless.core.metadata import (
    _UNSET,
    _scan_module_resources,
    get_registry,
    set_compiling_feature,
)


class TestConfigure:
    def test_configure_registers_when_feature_set(self):
        set_compiling_feature("user")
        pc.configure(memory=512, timeout=60)

        reg = get_registry()
        assert "user" in reg["features"]
        assert reg["features"]["user"]["config"]["memory"] == 512
        assert reg["features"]["user"]["config"]["timeout"] == 60

    def test_configure_noop_when_no_feature_set(self):
        # No feature set → should not raise, should not register anything
        pc.configure(memory=512)
        assert get_registry()["features"] == {}

    def test_configure_from_helper_function(self):
        """configure() must work even when called from inside a helper — not from the
        routes module directly. This was broken with the old stack-inspection approach."""
        set_compiling_feature("payment")

        def apply_config():
            # Simulates calling configure() from a helper/factory, not from the
            # top-level of routes.py
            pc.configure(memory=1024, description="from helper")

        apply_config()

        reg = get_registry()
        assert "payment" in reg["features"]
        assert reg["features"]["payment"]["config"]["memory"] == 1024
        assert reg["features"]["payment"]["config"]["description"] == "from helper"

    def test_configure_from_nested_helper(self):
        """Works even when called multiple levels deep."""
        set_compiling_feature("order")

        def level1():
            def level2():
                pc.configure(timeout=120)
            level2()

        level1()

        assert get_registry()["features"]["order"]["config"]["timeout"] == 120

    def test_configure_multiple_features_isolated(self):
        """Each feature gets its own config — no bleed-over."""
        set_compiling_feature("auth")
        pc.configure(memory=128)
        set_compiling_feature(None)

        set_compiling_feature("user")
        pc.configure(memory=512)
        set_compiling_feature(None)

        reg = get_registry()
        assert reg["features"]["auth"]["config"]["memory"] == 128
        assert reg["features"]["user"]["config"]["memory"] == 512

    def test_configure_resources(self):
        set_compiling_feature("product")
        table = pc.DynamoDB("products-table")
        pc.configure(resources={"products": table})
        set_compiling_feature(None)

        reg = get_registry()
        assert "products" in reg["features"]["product"]["resources"]

    def test_configure_resources_with_tuple_permission(self):
        set_compiling_feature("auth")
        table = pc.DynamoDB("users-table")
        kms = pc.KMS(alias="app")
        pc.configure(resources={"table": table, "kms": (kms, "decrypt")})
        set_compiling_feature(None)

        reg = get_registry()
        feat = reg["features"]["auth"]
        assert feat["resources"]["table"] is table
        assert feat["resources"]["kms"] is kms
        assert feat["resource_permissions"]["table"] == "crud"
        assert feat["resource_permissions"]["kms"] == "decrypt"

    def test_configure_resources_default_permission_is_crud(self):
        set_compiling_feature("user")
        table = pc.DynamoDB("users-table")
        pc.configure(resources={"table": table})
        set_compiling_feature(None)

        reg = get_registry()
        assert reg["features"]["user"]["resource_permissions"]["table"] == "crud"

    def test_configure_with_auth_none(self):
        set_compiling_feature("public")
        pc.configure(auth=None)
        set_compiling_feature(None)

        reg = get_registry()
        assert reg["features"]["public"]["config"]["auth"] is None

    def test_configure_with_auth_unset_not_stored(self):
        """auth _UNSET (default) should not appear in config dict."""
        set_compiling_feature("implicit")
        pc.configure(memory=256)
        set_compiling_feature(None)

        reg = get_registry()
        assert "auth" not in reg["features"]["implicit"]["config"]


class TestRef:
    def test_ref_string(self):
        assert pc.Ref("MyTable") == {"Ref": "MyTable"}

    def test_ref_resource(self):
        table = pc.DynamoDB("users-table")
        assert pc.Ref(table) == {"Ref": "UsersTable"}


class TestGetAtt:
    def test_getatt_string(self):
        assert pc.GetAtt("MyQueue", "Arn") == {"Fn::GetAtt": ["MyQueue", "Arn"]}

    def test_getatt_resource(self):
        queue = pc.SQS("events")
        assert pc.GetAtt(queue, "Arn") == {"Fn::GetAtt": ["EventsQueue", "Arn"]}

    def test_getatt_invalid_raises(self):
        import pytest
        with pytest.raises(ValueError):
            pc.GetAtt(42, "Arn")


class TestCronDecorator:
    def test_registers_cron(self):
        @pc.cron(schedule="rate(1 hour)", memory=256, timeout=60, description="Hourly cleanup")
        def cleanup(event, context):
            pass

        reg = get_registry()
        assert len(reg["crons"]) == 1
        c = reg["crons"][0]
        assert c["name"] == "cleanup"
        assert c["schedule"] == "rate(1 hour)"
        assert c["memory"] == 256
        assert c["timeout"] == 60
        assert c["description"] == "Hourly cleanup"

    def test_cron_preserves_function(self):
        @pc.cron(schedule="rate(5 minutes)")
        def task(event, context):
            return "ok"

        assert task(None, None) == "ok"


class TestLambdaFunctionDecorator:
    def test_registers_lambda(self):
        @pc.lambda_function(memory=512, timeout=120, description="SQS processor")
        def process_sqs(event, context):
            pass

        reg = get_registry()
        assert len(reg["lambdas"]) == 1
        lmb = reg["lambdas"][0]
        assert lmb["name"] == "process_sqs"
        assert lmb["memory"] == 512
        assert lmb["timeout"] == 120

    def test_lambda_with_env(self):
        @pc.lambda_function(env={"QUEUE_URL": "https://..."})
        def worker(event, context):
            pass

        reg = get_registry()
        found = [entry for entry in reg["lambdas"] if entry["name"] == "worker"]
        assert found[0]["env"]["QUEUE_URL"] == "https://..."

    def test_preserves_function(self):
        @pc.lambda_function(memory=128)
        def my_func(event, context):
            return {"ok": True}

        assert my_func(None, None) == {"ok": True}


class TestRegistryKey:
    def test_dynamodb_registry_key(self):
        table = pc.DynamoDB("ums-table")
        assert table._registry_key() == "ums_table"

    def test_s3_registry_key(self):
        bucket = pc.S3("uploads-bucket")
        assert bucket._registry_key() == "uploads_bucket"

    def test_sqs_registry_key(self):
        queue = pc.SQS("orders-queue")
        assert queue._registry_key() == "orders_queue"

    def test_sqs_fifo_registry_key(self):
        queue = pc.SQS("orders-queue", fifo=True)
        assert queue._registry_key() == "orders_queue"

    def test_kms_registry_key(self):
        key = pc.KMS(alias="ums-encryption-key")
        assert key._registry_key() == "ums_encryption_key"

    def test_kms_no_alias_registry_key(self):
        key = pc.KMS()
        assert key._registry_key() == "kms_key"

    def test_ssm_registry_key(self):
        param = pc.SSMParameter("/myapp/db/host", value="localhost")
        assert param._registry_key() == "host"


class TestScanModuleResources:
    def test_scan_finds_resources(self):
        import types
        mod = types.ModuleType("fake_mod")
        mod.table = pc.DynamoDB("users-table")
        mod.bucket = pc.S3("uploads-bucket")
        mod.not_a_resource = "hello"

        result = _scan_module_resources(mod)
        assert "users_table" in result
        assert "uploads_bucket" in result
        assert len(result) == 2

    def test_scan_deduplicates_by_identity(self):
        import types
        mod = types.ModuleType("fake_mod")
        table = pc.DynamoDB("users-table")
        mod.table1 = table
        mod.table2 = table  # same object, different name

        result = _scan_module_resources(mod)
        assert len(result) == 1
        assert "users_table" in result

    def test_scan_ignores_non_resources(self):
        import types
        mod = types.ModuleType("fake_mod")
        mod.name = "hello"
        mod.number = 42

        result = _scan_module_resources(mod)
        assert len(result) == 0


class TestRouteDecorator:
    def test_attaches_config_to_func(self):
        @pc.route(memory=1024, timeout=60, description="Heavy export")
        def export_data():
            pass

        cfg = export_data.__deployless_route_config__
        assert cfg["memory"] == 1024
        assert cfg["timeout"] == 60
        assert cfg["description"] == "Heavy export"

    def test_auth_none_is_public(self):
        @pc.route(auth=None)
        def public_route():
            pass

        assert public_route.__deployless_route_config__["auth"] is None

    def test_auth_unset_inherits(self):
        @pc.route()
        def inheriting_route():
            pass

        assert inheriting_route.__deployless_route_config__["auth"] is _UNSET
