"""Tests for Flask adapter."""
from flask import Blueprint

import deployless as pc
from deployless.adapters.flask import FlaskAdapter


class TestFlaskAdapterDetect:
    def test_detects_flask_blueprint(self):
        adapter = FlaskAdapter()
        bp = Blueprint("test", __name__)

        import types
        mod = types.ModuleType("test_module")
        mod.bp = bp

        assert adapter.detect(mod) is True

    def test_rejects_non_flask_module(self):
        adapter = FlaskAdapter()

        import types
        mod = types.ModuleType("test_module")
        mod.something = "not a blueprint"

        assert adapter.detect(mod) is False


class TestFlaskAdapterExtractRoutes:
    def test_extracts_basic_routes(self):
        adapter = FlaskAdapter()
        bp = Blueprint("users", __name__, url_prefix="/users")

        @bp.route("/", methods=["GET"])
        def list_users():
            pass

        @bp.route("/<user_id>", methods=["GET", "PUT"])
        def get_user(user_id):
            pass

        import types
        mod = types.ModuleType("test_module")
        mod.bp = bp

        routes = adapter.extract_routes(mod)
        paths = {r["sam_path"] for r in routes}
        assert "/users/" in paths
        assert "/users/{user_id}" in paths

    def test_detects_split_config(self):
        adapter = FlaskAdapter()
        bp = Blueprint("data", __name__, url_prefix="/data")

        @pc.route(memory=1024, timeout=60)
        @bp.route("/export", methods=["POST"])
        def export_data():
            pass

        @bp.route("/list", methods=["GET"])
        def list_data():
            pass

        import types
        mod = types.ModuleType("test_module")
        mod.bp = bp

        routes = adapter.extract_routes(mod)
        split_routes = [r for r in routes if r.get("split_config")]
        normal_routes = [r for r in routes if not r.get("split_config")]

        assert len(split_routes) == 1
        assert split_routes[0]["split_config"]["memory"] == 1024
        assert len(normal_routes) == 1


class TestToSamPath:
    def test_simple_param(self):
        assert FlaskAdapter._to_sam_path("/users/<user_id>") == "/users/{user_id}"

    def test_typed_param(self):
        assert FlaskAdapter._to_sam_path("/items/<int:id>") == "/items/{id}"

    def test_multiple_params(self):
        result = FlaskAdapter._to_sam_path("/org/<org_id>/users/<user_id>")
        assert result == "/org/{org_id}/users/{user_id}"

    def test_no_params(self):
        assert FlaskAdapter._to_sam_path("/health") == "/health"
