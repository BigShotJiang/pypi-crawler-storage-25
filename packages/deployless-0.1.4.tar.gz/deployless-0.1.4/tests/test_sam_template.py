"""Tests for SAM template generation."""
from deployless.providers.aws.resources.dynamodb import DynamoDB
from deployless.providers.aws.resources.kms import KMS
from deployless.providers.aws.resources.s3 import S3
from deployless.providers.aws.resources.sqs import SQS
from deployless.providers.aws.sam import _collect_auto_policies, _event_name, _to_pascal, generate_template


def _base_config(**overrides):
    config = {
        "name": "test-app",
        "stage": "dev",
        "globals": {"runtime": "python3.13", "memory": 256, "timeout": 30, "log_retention": 14},
        "api": {
            "endpoint_type": "REGIONAL",
            "cors": {"allow_origin": "*", "allow_methods": ["GET", "POST"]},
        },
        "env": {},
        "tags": {},
    }
    config.update(overrides)
    return config


def _base_state(**overrides):
    state = {"features": {}, "crons": [], "split_routes": [], "lambdas": []}
    state.update(overrides)
    return state


class TestHelpers:
    def test_to_pascal(self):
        assert _to_pascal("user-management") == "UserManagement"
        assert _to_pascal("auth_feature") == "AuthFeature"
        assert _to_pascal("simple") == "Simple"

    def test_event_name(self):
        name = _event_name("auth", "/login", "post")
        assert "Auth" in name
        assert "Post" in name


class TestTemplateStructure:
    def test_has_required_sections(self):
        state = _base_state(features={
            "auth": {
                "config": {},
                "resources": {},
                "routes": [{"sam_path": "/login", "methods": ["POST"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "AWSTemplateFormatVersion" in template
        assert "Transform" in template
        assert "Globals" in template
        assert "Resources" in template
        assert "Outputs" in template

    def test_api_gateway_created(self):
        state = _base_state(features={
            "auth": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert "Api" in template["Resources"]
        assert template["Resources"]["Api"]["Type"] == "AWS::Serverless::Api"


class TestFeatureLambda:
    def test_feature_function_created(self):
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/users", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert "UserFunction" in template["Resources"]
        func = template["Resources"]["UserFunction"]
        assert func["Type"] == "AWS::Serverless::Function"
        assert func["Properties"]["Handler"] == "bootstrap.handler"

    def test_feature_memory_override(self):
        state = _base_state(features={
            "user": {"config": {"memory": 512}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert template["Resources"]["UserFunction"]["Properties"]["MemorySize"] == 512

    def test_feature_with_dlq(self):
        state = _base_state(features={
            "user": {"config": {"dlq": True}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert "UserFunctionDLQ" in template["Resources"]

    def test_log_group_created(self):
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert "UserFunctionLogGroup" in template["Resources"]

    def test_output_arn(self):
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config())
        assert "UserFunctionArn" in template["Outputs"]


class TestResourcesInTemplate:
    def test_dynamodb_resource_generated(self):
        table = DynamoDB("users-table")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"users": table},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "UsersTable" in template["Resources"]

    def test_resource_env_vars_injected(self):
        table = DynamoDB("users-table")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"users": table},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        env = template["Resources"]["UserFunction"]["Properties"]["Environment"]["Variables"]
        assert "USERS_TABLE" in env

    def test_sqs_multi_resource(self):
        queue = SQS("orders-queue", dlq=True)
        state = _base_state(features={
            "order": {
                "config": {},
                "resources": {"orders": queue},
                "routes": [{"sam_path": "/orders", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        # SQS with DLQ generates multiple resources
        assert "OrdersQueue" in template["Resources"]
        assert "OrdersDLQueue" in template["Resources"]


class TestCronLambda:
    def test_cron_function_created(self):
        state = _base_state(
            features={"a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}},
            crons=[
                {
                    "name": "cleanup", "schedule": "rate(1 hour)", "memory": 128,
                    "timeout": 60, "env": {}, "description": "Cleanup",
                }
            ],
        )
        template = generate_template(state, _base_config())
        assert "CleanupFunction" in template["Resources"]
        func = template["Resources"]["CleanupFunction"]
        assert func["Properties"]["Events"]["Schedule"]["Properties"]["Schedule"] == "rate(1 hour)"


class TestStandaloneLambda:
    def test_lambda_function_created(self):
        state = _base_state(
            features={"a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}},
            lambdas=[
                {"name": "process_sqs", "memory": 512, "timeout": 120, "env": {"Q": "url"}, "description": "SQS proc"}
            ],
        )
        template = generate_template(state, _base_config())
        assert "ProcessSqsFunction" in template["Resources"]
        func = template["Resources"]["ProcessSqsFunction"]
        assert func["Type"] == "AWS::Serverless::Function"
        assert func["Properties"]["MemorySize"] == 512
        assert func["Properties"]["Environment"]["Variables"]["Q"] == "url"
        # No Events (standalone)
        assert "Events" not in func["Properties"]

    def test_lambda_log_group_and_output(self):
        state = _base_state(
            features={"a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}},
            lambdas=[{"name": "worker", "memory": None, "timeout": None, "env": {}, "description": None}],
        )
        template = generate_template(state, _base_config())
        assert "WorkerFunctionLogGroup" in template["Resources"]
        assert "WorkerFunctionArn" in template["Outputs"]


class TestAutoDetectedResources:
    def test_resource_in_feature_generates_cfn(self):
        """A resource auto-detected in a feature should appear in the template."""
        table = DynamoDB("events-table")
        state = _base_state(features={
            "a": {
                "config": {},
                "resources": {"events_table": table},
                "resource_permissions": {"events_table": "crud"},
                "routes": [{"sam_path": "/x", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "EventsTable" in template["Resources"]

    def test_resource_env_injected_into_feature(self):
        """Auto-detected resources get their env vars injected."""
        table = DynamoDB("events-table")
        state = _base_state(features={
            "a": {
                "config": {},
                "resources": {"events_table": table},
                "resource_permissions": {"events_table": "crud"},
                "routes": [{"sam_path": "/x", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        env = template["Resources"]["AFunction"]["Properties"]["Environment"]["Variables"]
        assert "EVENTS_TABLE" in env

    def test_existing_resource_skips_cfn(self):
        """Resources with existing=True don't generate CFN but still get env vars."""
        table = DynamoDB("legacy-table", existing=True)
        state = _base_state(features={
            "a": {
                "config": {},
                "resources": {"legacy_table": table},
                "resource_permissions": {"legacy_table": "crud"},
                "routes": [{"sam_path": "/x", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "LegacyTable" not in template["Resources"]

    def test_same_resource_in_two_features_emitted_once(self):
        """Deduplication: same resource in multiple features → CFN emitted once."""
        table = DynamoDB("shared-table")
        state = _base_state(features={
            "auth": {
                "config": {},
                "resources": {"shared_table": table},
                "resource_permissions": {"shared_table": "crud"},
                "routes": [{"sam_path": "/auth", "methods": ["POST"]}],
            },
            "user": {
                "config": {},
                "resources": {"shared_table": table},
                "resource_permissions": {"shared_table": "read"},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            },
        })
        template = generate_template(state, _base_config())
        # CFN resource exists
        assert "SharedTable" in template["Resources"]
        # Both features get env vars
        auth_env = template["Resources"]["AuthFunction"]["Properties"]["Environment"]["Variables"]
        user_env = template["Resources"]["UserFunction"]["Properties"]["Environment"]["Variables"]
        assert "SHARED_TABLE" in auth_env
        assert "SHARED_TABLE" in user_env
        # Different permission levels
        auth_policies = template["Resources"]["AuthFunction"]["Properties"]["Policies"]
        user_policies = template["Resources"]["UserFunction"]["Properties"]["Policies"]
        assert {"DynamoDBCrudPolicy": {"TableName": {"Ref": "SharedTable"}}} in auth_policies
        assert {"DynamoDBReadPolicy": {"TableName": {"Ref": "SharedTable"}}} in user_policies


class TestApiGateway:
    def test_cors_config(self):
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        config = _base_config()
        config["api"]["cors"]["max_age"] = 3600
        template = generate_template(state, config)
        cors = template["Resources"]["Api"]["Properties"]["Cors"]
        assert cors["MaxAge"] == 3600

    def test_api_key(self):
        config = _base_config()
        config["api"]["api_keys"] = True
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, config)
        assert "ApiKey" in template["Resources"]

    def test_usage_plan(self):
        config = _base_config()
        config["api"]["api_keys"] = True
        config["api"]["usage_plan"] = {"rate": 1000, "burst": 2000}
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, config)
        assert "UsagePlan" in template["Resources"]

    def test_domain_config(self):
        config = _base_config()
        config["api"]["domain"] = {
            "domain_name": "api.example.com",
            "certificate_arn": "arn:aws:acm:...",
        }
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, config)
        domain = template["Resources"]["Api"]["Properties"]["Domain"]
        assert domain["DomainName"] == "api.example.com"
        assert domain["CertificateArn"] == "arn:aws:acm:..."

    def test_domain_route53_auto_cert(self):
        """Route 53 config without certificate_arn generates an ApiCertificate CFN resource."""
        config = _base_config()
        config["api"]["domain"] = {
            "domain_name": "api.example.com",
            "route53": {"hosted_zone_id": "Z1234567890"},
        }
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, config)
        # ACM certificate resource is created
        assert "ApiCertificate" in template["Resources"]
        cert = template["Resources"]["ApiCertificate"]
        assert cert["Type"] == "AWS::CertificateManager::Certificate"
        assert cert["Properties"]["DomainName"] == "api.example.com"
        assert cert["Properties"]["DomainValidationOptions"][0]["HostedZoneId"] == "Z1234567890"
        # Domain block references the certificate
        domain = template["Resources"]["Api"]["Properties"]["Domain"]
        assert domain["CertificateArn"] == {"Ref": "ApiCertificate"}

    def test_domain_external_dns_no_domain_block(self):
        """Domain with only domain_name (no cert, no route53) should NOT generate Domain block."""
        config = _base_config()
        config["api"]["domain"] = {"domain_name": "api.example.com"}
        state = _base_state(features={
            "a": {"config": {}, "resources": {}, "routes": [{"sam_path": "/x", "methods": ["GET"]}]}
        })
        template = generate_template(state, config)
        assert "Domain" not in template["Resources"]["Api"]["Properties"]
        assert "ApiCertificate" not in template["Resources"]


class TestAlarms:
    def test_alarms_generated(self):
        state = _base_state(features={
            "user": {
                "config": {"alarms": True},
                "resources": {},
                "routes": [{"sam_path": "/u", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "UserFunctionErrorsAlarm" in template["Resources"]
        assert "UserFunctionThrottlesAlarm" in template["Resources"]
        assert "UserFunctionDurationAlarm" in template["Resources"]

    def test_alarms_disabled(self):
        state = _base_state(features={
            "user": {
                "config": {"alarms": False},
                "resources": {},
                "routes": [{"sam_path": "/u", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "UserFunctionErrorsAlarm" not in template["Resources"]


class TestTagPropagation:
    """Tags defined in pycloud.yaml must appear on every resource, not just API Gateway."""

    TAGS = {"env": "prod", "team": "platform"}

    def _config(self):
        return _base_config(tags=self.TAGS)

    def test_api_gateway_has_tags(self):
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, self._config())
        assert template["Resources"]["Api"]["Properties"]["Tags"] == self.TAGS

    def test_feature_lambda_has_tags(self):
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, self._config())
        func = template["Resources"]["UserFunction"]
        assert func["Properties"]["Tags"] == self.TAGS

    def test_cron_lambda_has_tags(self):
        state = _base_state(crons=[{"name": "nightly", "schedule": "rate(1 day)"}])
        template = generate_template(state, self._config())
        func = template["Resources"]["NightlyFunction"]
        assert func["Properties"]["Tags"] == self.TAGS

    def test_standalone_lambda_has_tags(self):
        state = _base_state(lambdas=[{"name": "worker"}])
        template = generate_template(state, self._config())
        func = template["Resources"]["WorkerFunction"]
        assert func["Properties"]["Tags"] == self.TAGS

    def test_split_route_lambda_has_tags(self):
        state = _base_state(split_routes=[{
            "endpoint": "create_user",
            "sam_path": "/users",
            "methods": ["POST"],
            "split_config": {},
        }])
        template = generate_template(state, self._config())
        func = template["Resources"]["CreateUserFunction"]
        assert func["Properties"]["Tags"] == self.TAGS

    def test_dynamodb_has_tags_as_array(self):
        """DynamoDB always → AWS::DynamoDB::Table → array format [{Key, Value}]."""
        db = DynamoDB("users", pk="id")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"users_table": db},
                "routes": [{"sam_path": "/u", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, self._config())
        table = template["Resources"][db._logical_id()]
        assert table["Type"] == "AWS::DynamoDB::Table"
        tags = table["Properties"]["Tags"]
        assert isinstance(tags, list)
        assert {"Key": "env", "Value": "prod"} in tags
        assert {"Key": "team", "Value": "platform"} in tags

    def test_s3_resource_has_tags_as_array(self):
        """S3 → AWS::S3::Bucket → array format [{Key, Value}]."""
        bucket = S3("my-bucket")
        state = _base_state(features={
            "files": {
                "config": {},
                "resources": {"bucket": bucket},
                "routes": [{"sam_path": "/f", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, self._config())
        b = template["Resources"][bucket._logical_id()]
        tags = b["Properties"]["Tags"]
        assert isinstance(tags, list)
        assert {"Key": "env", "Value": "prod"} in tags

    def test_dlq_has_tags_as_array(self):
        """DLQ → AWS::SQS::Queue → array format [{Key, Value}]."""
        state = _base_state(features={
            "worker": {
                "config": {"dlq": True},
                "resources": {},
                "routes": [{"sam_path": "/w", "methods": ["POST"]}],
            }
        })
        template = generate_template(state, self._config())
        dlq = template["Resources"]["WorkerFunctionDLQ"]
        assert dlq["Type"] == "AWS::SQS::Queue"
        tags = dlq["Properties"]["Tags"]
        assert isinstance(tags, list)
        assert {"Key": "env", "Value": "prod"} in tags

    def test_auto_detected_dynamodb_has_tags_as_array(self):
        """DynamoDB auto-detected in a feature still gets tags as array."""
        db = DynamoDB("shared-table", pk="id")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"shared_table": db},
                "resource_permissions": {"shared_table": "crud"},
                "routes": [{"sam_path": "/u", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, self._config())
        table = template["Resources"][db._logical_id()]
        tags = table["Properties"]["Tags"]
        assert isinstance(tags, list)
        assert {"Key": "env", "Value": "prod"} in tags

    def test_no_tags_when_empty(self):
        """When tags={} no Tags key should be injected into Lambdas."""
        state = _base_state(features={
            "user": {"config": {}, "resources": {}, "routes": [{"sam_path": "/u", "methods": ["GET"]}]}
        })
        template = generate_template(state, _base_config(tags={}))
        func = template["Resources"]["UserFunction"]
        assert "Tags" not in func["Properties"]


class TestAutoPolicies:
    def test_collect_auto_policies_basic(self):
        table = DynamoDB("users-table")
        policies = _collect_auto_policies({"t": table}, {"t": "crud"})
        assert policies == [{"DynamoDBCrudPolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_collect_auto_policies_with_level(self):
        table = DynamoDB("users-table")
        policies = _collect_auto_policies({"t": table}, {"t": "read"})
        assert policies == [{"DynamoDBReadPolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_collect_auto_policies_default_crud(self):
        table = DynamoDB("users-table")
        policies = _collect_auto_policies({"t": table}, {})
        assert policies == [{"DynamoDBCrudPolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_feature_auto_policies_in_template(self):
        table = DynamoDB("users-table")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"t": table},
                "resource_permissions": {"t": "crud"},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        policies = template["Resources"]["UserFunction"]["Properties"]["Policies"]
        assert {"DynamoDBCrudPolicy": {"TableName": {"Ref": "UsersTable"}}} in policies

    def test_auto_policies_merge_with_explicit(self):
        table = DynamoDB("users-table")
        custom_policy = {
            "Version": "2012-10-17",
            "Statement": [{"Effect": "Allow", "Action": ["s3:*"], "Resource": "*"}],
        }
        state = _base_state(features={
            "user": {
                "config": {"policies": [custom_policy]},
                "resources": {"t": table},
                "resource_permissions": {"t": "crud"},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        policies = template["Resources"]["UserFunction"]["Properties"]["Policies"]
        assert {"DynamoDBCrudPolicy": {"TableName": {"Ref": "UsersTable"}}} in policies
        assert custom_policy in policies

    def test_duplicate_resource_different_keys_produces_single_policy(self):
        """Same resource object under two keys must not produce duplicate policies."""
        table = DynamoDB("derlinks")
        policies = _collect_auto_policies(
            {"derlinks": table, "table": table},
            {"derlinks": "crud", "table": "crud"},
        )
        assert len(policies) == 1
        assert policies == [{"DynamoDBCrudPolicy": {"TableName": {"Ref": "DerlinksTable"}}}]

    def test_auto_detected_resource_with_permission_override(self):
        """Resource auto-detected but permission overridden via configure()."""
        table = DynamoDB("shared-table")
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {"shared_table": table},
                "resource_permissions": {"shared_table": "read"},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        policies = template["Resources"]["UserFunction"]["Properties"]["Policies"]
        assert {"DynamoDBReadPolicy": {"TableName": {"Ref": "SharedTable"}}} in policies

    def test_kms_auto_policy_decrypt(self):
        kms = KMS(alias="app")
        state = _base_state(features={
            "auth": {
                "config": {},
                "resources": {"kms": kms},
                "resource_permissions": {"kms": "decrypt"},
                "routes": [{"sam_path": "/auth", "methods": ["POST"]}],
            }
        })
        template = generate_template(state, _base_config())
        policies = template["Resources"]["AuthFunction"]["Properties"]["Policies"]
        assert len(policies) == 1
        stmt = policies[0]["Statement"][0]
        assert stmt["Action"] == ["kms:Decrypt"]

    def test_no_policies_when_no_resources(self):
        state = _base_state(features={
            "user": {
                "config": {},
                "resources": {},
                "resource_permissions": {},
                "routes": [{"sam_path": "/users", "methods": ["GET"]}],
            }
        })
        template = generate_template(state, _base_config())
        assert "Policies" not in template["Resources"]["UserFunction"]["Properties"]
