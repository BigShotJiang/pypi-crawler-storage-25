"""Tests for DynamoDB resource."""
from deployless.providers.aws.resources.dynamodb import DynamoDB


class TestDynamoDBInit:
    def test_defaults(self):
        t = DynamoDB("users-table")
        assert t.table_name == "users-table"
        assert t.pk == "id"
        assert t.pk_type == "S"
        assert t.sk is None
        assert t.gsi == []
        assert t.billing_mode == "PAY_PER_REQUEST"
        assert t.existing is False

    def test_composite_key(self):
        t = DynamoDB("orders", pk="user_id", sk="order_id", sk_type="S")
        assert t.sk == "order_id"

    def test_existing_flag(self):
        t = DynamoDB("legacy-table", existing=True)
        assert t.existing is True


class TestDynamoDBLogicalId:
    def test_strips_table_suffix(self):
        assert DynamoDB("users-table")._logical_id() == "UsersTable"

    def test_strips_underscore_table_suffix(self):
        assert DynamoDB("orders_table")._logical_id() == "OrdersTable"

    def test_no_suffix(self):
        assert DynamoDB("sessions")._logical_id() == "SessionsTable"

    def test_pascal_case(self):
        assert DynamoDB("user-activity-table")._logical_id() == "UserActivityTable"


class TestDynamoDBEnvVar:
    def test_basic(self):
        assert DynamoDB("users-table").env_var_name() == "USERS_TABLE"

    def test_no_suffix(self):
        assert DynamoDB("sessions").env_var_name() == "SESSIONS_TABLE"

    def test_value_ref(self):
        t = DynamoDB("users-table")
        assert t.env_var_value() == {"Ref": "UsersTable"}

    def test_value_existing(self):
        t = DynamoDB("legacy-table", existing=True)
        assert t.env_var_value() == "legacy-table"


class TestDynamoDBValidation:
    def test_valid_simple(self):
        assert DynamoDB("users-table").validate() == []

    def test_empty_name(self):
        errors = DynamoDB("").validate()
        assert len(errors) == 1
        assert "vacío" in errors[0]

    def test_invalid_pk_type(self):
        errors = DynamoDB("t", pk_type="X").validate()
        assert any("pk_type" in e for e in errors)

    def test_invalid_billing_mode(self):
        errors = DynamoDB("t", billing_mode="INVALID").validate()
        assert any("billing_mode" in e for e in errors)

    def test_invalid_stream(self):
        errors = DynamoDB("t", stream="INVALID").validate()
        assert any("stream" in e for e in errors)

    def test_valid_gsi(self):
        gsi = [{"name": "StatusIndex", "pk": "status", "projection": "ALL"}]
        assert DynamoDB("t", gsi=gsi).validate() == []

    def test_gsi_missing_name(self):
        gsi = [{"pk": "status"}]
        errors = DynamoDB("t", gsi=gsi).validate()
        assert any("name" in e for e in errors)

    def test_gsi_missing_pk(self):
        gsi = [{"name": "Idx"}]
        errors = DynamoDB("t", gsi=gsi).validate()
        assert any("pk" in e.lower() for e in errors)

    def test_gsi_include_requires_non_key_attributes(self):
        gsi = [{"name": "Idx", "pk": "status", "projection": "INCLUDE"}]
        errors = DynamoDB("t", gsi=gsi).validate()
        assert any("non_key_attributes" in e for e in errors)


class TestDynamoDBCfn:
    def test_partition_key_only_generates_full_table(self):
        cfn = DynamoDB("users-table").to_cfn()
        assert cfn["Type"] == "AWS::DynamoDB::Table"
        assert cfn["Properties"]["TableName"] == "users-table"

    def test_full_table_with_sk(self):
        cfn = DynamoDB("orders", pk="user_id", sk="ts").to_cfn()
        assert cfn["Type"] == "AWS::DynamoDB::Table"
        assert cfn["Properties"]["SSESpecification"]["SSEEnabled"] is True

    def test_full_table_with_gsi(self):
        gsi = [{"name": "StatusIdx", "pk": "status"}]
        cfn = DynamoDB("tasks", gsi=gsi).to_cfn()
        assert cfn["Type"] == "AWS::DynamoDB::Table"
        assert len(cfn["Properties"]["GlobalSecondaryIndexes"]) == 1

    def test_existing_returns_empty(self):
        assert DynamoDB("legacy", existing=True).to_cfn() == {}

    def test_deletion_policy(self):
        cfn = DynamoDB("critical-table", deletion_policy="Retain").to_cfn()
        assert cfn.get("DeletionPolicy") == "Retain"

    def test_ttl(self):
        cfn = DynamoDB("sessions", ttl_attribute="expires_at").to_cfn()
        ttl = cfn["Properties"]["TimeToLiveSpecification"]
        assert ttl["AttributeName"] == "expires_at"
        assert ttl["Enabled"] is True

    def test_pitr(self):
        cfn = DynamoDB("important", point_in_time_recovery=True).to_cfn()
        assert cfn["Properties"]["PointInTimeRecoverySpecification"]["PointInTimeRecoveryEnabled"]

    def test_provisioned_throughput(self):
        cfn = DynamoDB("t", sk="sk", billing_mode="PROVISIONED", read_capacity=10, write_capacity=5).to_cfn()
        pt = cfn["Properties"]["ProvisionedThroughput"]
        assert pt["ReadCapacityUnits"] == 10
        assert pt["WriteCapacityUnits"] == 5

    def test_stream(self):
        cfn = DynamoDB("t", sk="sk", stream="NEW_AND_OLD_IMAGES").to_cfn()
        assert cfn["Properties"]["StreamSpecification"]["StreamViewType"] == "NEW_AND_OLD_IMAGES"


class TestDynamoDBToPolicy:
    def test_crud_default(self):
        t = DynamoDB("users-table")
        policies = t.to_policy()
        assert policies == [{"DynamoDBCrudPolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_read(self):
        policies = DynamoDB("users-table").to_policy("read")
        assert policies == [{"DynamoDBReadPolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_write(self):
        policies = DynamoDB("users-table").to_policy("write")
        assert policies == [{"DynamoDBWritePolicy": {"TableName": {"Ref": "UsersTable"}}}]

    def test_existing_uses_table_name(self):
        policies = DynamoDB("legacy-table", existing=True).to_policy("crud")
        assert policies == [{"DynamoDBCrudPolicy": {"TableName": "legacy-table"}}]

    def test_valid_permission_levels(self):
        assert DynamoDB.VALID_PERMISSION_LEVELS == {"crud", "read", "write"}
