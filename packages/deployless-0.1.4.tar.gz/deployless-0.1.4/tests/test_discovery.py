"""Tests for deployless.core.discovery."""
from deployless.core.discovery import _find_entry_file, discover_features


class TestDiscoverFeatures:
    def test_finds_features(self, tmp_path):
        features_dir = tmp_path / "app" / "features"
        (features_dir / "auth").mkdir(parents=True)
        (features_dir / "auth" / "routes.py").write_text("# auth routes")
        (features_dir / "user").mkdir()
        (features_dir / "user" / "routes.py").write_text("# user routes")

        features = discover_features(tmp_path, "app/features")
        names = [f["name"] for f in features]
        assert names == ["auth", "user"]  # sorted

    def test_ignores_dirs_without_routes(self, tmp_path):
        features_dir = tmp_path / "app" / "features"
        (features_dir / "utils").mkdir(parents=True)
        (features_dir / "utils" / "helpers.py").write_text("# no routes")

        features = discover_features(tmp_path, "app/features")
        assert features == []

    def test_ignores_underscore_dirs(self, tmp_path):
        features_dir = tmp_path / "app" / "features"
        (features_dir / "_shared").mkdir(parents=True)
        (features_dir / "_shared" / "routes.py").write_text("# shared")

        features = discover_features(tmp_path, "app/features")
        assert features == []

    def test_empty_features_dir(self, tmp_path):
        features = discover_features(tmp_path, "app/features")
        assert features == []

    def test_feature_has_dir_and_routes_file(self, tmp_path):
        features_dir = tmp_path / "app" / "features"
        (features_dir / "auth").mkdir(parents=True)
        (features_dir / "auth" / "routes.py").write_text("")

        features = discover_features(tmp_path, "app/features")
        assert features[0]["name"] == "auth"
        assert features[0]["dir"] == features_dir / "auth"
        assert features[0]["routes_file"] == features_dir / "auth" / "routes.py"

    def test_finds_screaming_arch_entry(self, tmp_path):
        """Discovers features using routes/{feature}_routes.py convention."""
        features_dir = tmp_path / "app" / "features"
        user_dir = features_dir / "user"
        routes_dir = user_dir / "routes"
        routes_dir.mkdir(parents=True)
        (routes_dir / "user_routes.py").write_text("# user routes")

        features = discover_features(tmp_path, "app/features")
        assert len(features) == 1
        assert features[0]["name"] == "user"
        assert features[0]["routes_file"] == routes_dir / "user_routes.py"

    def test_finds_single_py_in_routes_dir(self, tmp_path):
        """Discovers entry when there is exactly one .py in routes/ dir."""
        features_dir = tmp_path / "app" / "features"
        order_dir = features_dir / "order"
        routes_dir = order_dir / "routes"
        routes_dir.mkdir(parents=True)
        (routes_dir / "__init__.py").write_text("")
        (routes_dir / "order_http.py").write_text("# order routes")

        features = discover_features(tmp_path, "app/features")
        assert len(features) == 1
        assert features[0]["routes_file"].name == "order_http.py"

    def test_ignores_routes_dir_with_multiple_py_files(self, tmp_path):
        """Ambiguous: multiple .py files in routes/ — feature is skipped."""
        features_dir = tmp_path / "app" / "features"
        payment_dir = features_dir / "payment"
        routes_dir = payment_dir / "routes"
        routes_dir.mkdir(parents=True)
        (routes_dir / "http_routes.py").write_text("")
        (routes_dir / "grpc_routes.py").write_text("")

        features = discover_features(tmp_path, "app/features")
        assert features == []

    def test_classic_routes_takes_priority_over_routes_dir(self, tmp_path):
        """If both routes.py and routes/ exist, routes.py wins."""
        features_dir = tmp_path / "app" / "features"
        user_dir = features_dir / "user"
        routes_dir = user_dir / "routes"
        routes_dir.mkdir(parents=True)
        (user_dir / "routes.py").write_text("# classic")
        (routes_dir / "user_routes.py").write_text("# screaming")

        features = discover_features(tmp_path, "app/features")
        assert features[0]["routes_file"] == user_dir / "routes.py"


class TestFindEntryFile:
    def test_returns_none_when_no_entry(self, tmp_path):
        feature_dir = tmp_path / "user"
        feature_dir.mkdir()
        (feature_dir / "domain").mkdir()

        assert _find_entry_file(feature_dir, "user") is None

    def test_finds_classic_routes(self, tmp_path):
        feature_dir = tmp_path / "user"
        feature_dir.mkdir()
        f = feature_dir / "routes.py"
        f.write_text("")

        assert _find_entry_file(feature_dir, "user") == f

    def test_finds_screaming_arch(self, tmp_path):
        feature_dir = tmp_path / "user"
        routes_dir = feature_dir / "routes"
        routes_dir.mkdir(parents=True)
        f = routes_dir / "user_routes.py"
        f.write_text("")

        assert _find_entry_file(feature_dir, "user") == f

    def test_ignores_init_in_routes_dir(self, tmp_path):
        """__init__.py is not a valid entry point."""
        feature_dir = tmp_path / "user"
        routes_dir = feature_dir / "routes"
        routes_dir.mkdir(parents=True)
        (routes_dir / "__init__.py").write_text("")
        f = routes_dir / "user_routes.py"
        f.write_text("")

        assert _find_entry_file(feature_dir, "user") == f
