"""Tests for S3 resource."""
from deployless.providers.aws.resources.s3 import S3


class TestS3Init:
    def test_defaults(self):
        b = S3("my-bucket")
        assert b.bucket_name == "my-bucket"
        assert b.encryption is True
        assert b.versioning is False
        assert b.public_access_block is True
        assert b.existing is False


class TestS3LogicalId:
    def test_strips_bucket_suffix(self):
        assert S3("uploads-bucket")._logical_id() == "UploadsBucket"

    def test_no_suffix(self):
        assert S3("data")._logical_id() == "DataBucket"


class TestS3EnvVar:
    def test_basic(self):
        assert S3("uploads-bucket").env_var_name() == "UPLOADS_BUCKET"

    def test_no_suffix(self):
        assert S3("data").env_var_name() == "DATA_BUCKET"


class TestS3Validation:
    def test_valid(self):
        assert S3("my-valid-bucket").validate() == []

    def test_empty_name(self):
        assert len(S3("").validate()) > 0

    def test_too_short(self):
        assert len(S3("ab").validate()) > 0

    def test_too_long(self):
        assert len(S3("a" * 64).validate()) > 0

    def test_underscores_invalid(self):
        errors = S3("my_bucket").validate()
        assert any("underscore" in e for e in errors)

    def test_uppercase_invalid(self):
        errors = S3("MyBucket").validate()
        assert len(errors) > 0


class TestS3Cfn:
    def test_basic(self):
        cfn = S3("my-bucket").to_cfn()
        assert cfn["Type"] == "AWS::S3::Bucket"
        assert cfn["Properties"]["BucketName"] == "my-bucket"

    def test_encryption_enabled(self):
        cfn = S3("b").to_cfn()
        assert "BucketEncryption" in cfn["Properties"]

    def test_encryption_disabled(self):
        cfn = S3("my-bucket", encryption=False).to_cfn()
        assert "BucketEncryption" not in cfn["Properties"]

    def test_versioning(self):
        cfn = S3("my-bucket", versioning=True).to_cfn()
        assert cfn["Properties"]["VersioningConfiguration"]["Status"] == "Enabled"

    def test_public_access_block(self):
        cfn = S3("my-bucket").to_cfn()
        block = cfn["Properties"]["PublicAccessBlockConfiguration"]
        assert block["BlockPublicAcls"] is True

    def test_existing_returns_empty(self):
        assert S3("existing-bucket", existing=True).to_cfn() == {}

    def test_deletion_policy(self):
        cfn = S3("my-bucket", deletion_policy="Retain").to_cfn()
        assert cfn["DeletionPolicy"] == "Retain"

    def test_cors(self):
        cors = [{"AllowedOrigins": ["*"], "AllowedMethods": ["GET"]}]
        cfn = S3("my-bucket", cors=cors).to_cfn()
        assert cfn["Properties"]["CorsConfiguration"]["CorsRules"] == cors

    def test_lifecycle_rules(self):
        rules = [{"Status": "Enabled", "ExpirationInDays": 90}]
        cfn = S3("my-bucket", lifecycle_rules=rules).to_cfn()
        assert cfn["Properties"]["LifecycleConfiguration"]["Rules"] == rules


class TestS3ToPolicy:
    def test_crud_default(self):
        policies = S3("my-bucket").to_policy()
        assert policies == [{"S3CrudPolicy": {"BucketName": {"Ref": "MyBucket"}}}]

    def test_read(self):
        policies = S3("my-bucket").to_policy("read")
        assert policies == [{"S3ReadPolicy": {"BucketName": {"Ref": "MyBucket"}}}]

    def test_write(self):
        policies = S3("my-bucket").to_policy("write")
        assert policies == [{"S3WritePolicy": {"BucketName": {"Ref": "MyBucket"}}}]

    def test_existing_uses_bucket_name(self):
        policies = S3("my-bucket", existing=True).to_policy("crud")
        assert policies == [{"S3CrudPolicy": {"BucketName": "my-bucket"}}]

    def test_valid_permission_levels(self):
        assert S3.VALID_PERMISSION_LEVELS == {"crud", "read", "write"}
