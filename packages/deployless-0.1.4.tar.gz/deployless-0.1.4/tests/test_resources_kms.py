"""Tests for KMS resource."""
from deployless.providers.aws.resources.kms import KMS


class TestKMSInit:
    def test_defaults(self):
        k = KMS(alias="myapp")
        assert k.key_usage == "ENCRYPT_DECRYPT"
        assert k.key_spec == "SYMMETRIC_DEFAULT"
        assert k.enable_rotation is True  # auto for symmetric
        assert k.deletion_policy == "Retain"

    def test_asymmetric_no_rotation(self):
        k = KMS(alias="sign", key_spec="RSA_2048", key_usage="SIGN_VERIFY")
        assert k.enable_rotation is False

    def test_existing_key(self):
        k = KMS(existing_key_id="arn:aws:kms:us-east-1:123:key/abc")
        assert k.existing_key_id is not None


class TestKMSLogicalId:
    def test_with_alias(self):
        assert KMS(alias="myapp/encryption")._logical_id() == "MyappEncryptionKey"

    def test_strips_alias_prefix(self):
        assert KMS(alias="alias/myapp")._logical_id() == "MyappKey"

    def test_no_alias(self):
        assert KMS()._logical_id() == "AppKey"


class TestKMSEnvVar:
    def test_with_alias(self):
        assert KMS(alias="myapp/encryption").env_var_name() == "MYAPP_ENCRYPTION_KEY_ID"

    def test_no_alias(self):
        assert KMS().env_var_name() == "KMS_KEY_ID"

    def test_value_existing(self):
        k = KMS(existing_key_id="arn:...")
        assert k.env_var_value() == "arn:..."


class TestKMSValidation:
    def test_valid_symmetric(self):
        assert KMS(alias="myapp").validate() == []

    def test_invalid_key_usage(self):
        errors = KMS(key_usage="INVALID").validate()
        assert any("key_usage" in e for e in errors)

    def test_invalid_key_spec(self):
        errors = KMS(key_spec="INVALID").validate()
        assert any("key_spec" in e for e in errors)

    def test_rotation_on_asymmetric(self):
        errors = KMS(key_spec="RSA_2048", key_usage="SIGN_VERIFY", enable_rotation=True).validate()
        assert any("rotation" in e for e in errors)

    def test_ecc_with_encrypt(self):
        errors = KMS(key_spec="ECC_NIST_P256", key_usage="ENCRYPT_DECRYPT").validate()
        assert any("ECC" in e for e in errors)

    def test_symmetric_with_sign_verify(self):
        errors = KMS(key_spec="SYMMETRIC_DEFAULT", key_usage="SIGN_VERIFY").validate()
        assert len(errors) > 0


class TestKMSCfn:
    def test_creates_key_and_alias(self):
        cfn = KMS(alias="myapp").to_cfn()
        assert "MyappKey" in cfn
        assert "MyappKeyAlias" in cfn
        assert cfn["MyappKey"]["Type"] == "AWS::KMS::Key"
        assert cfn["MyappKeyAlias"]["Type"] == "AWS::KMS::Alias"

    def test_no_alias(self):
        cfn = KMS().to_cfn()
        assert "AppKey" in cfn
        # No alias resource
        assert len(cfn) == 1

    def test_existing_returns_empty(self):
        assert KMS(existing_key_id="arn:...").to_cfn() == {}

    def test_rotation_enabled(self):
        cfn = KMS(alias="app").to_cfn()
        assert cfn["AppKey"]["Properties"]["EnableKeyRotation"] is True

    def test_deletion_policy(self):
        cfn = KMS(alias="app", deletion_policy="Retain").to_cfn()
        assert cfn["AppKey"]["DeletionPolicy"] == "Retain"


class TestKMSToPolicy:
    def test_crud(self):
        k = KMS(alias="app")
        policies = k.to_policy("crud")
        assert len(policies) == 1
        stmt = policies[0]["Statement"][0]
        assert "kms:Encrypt" in stmt["Action"]
        assert "kms:Decrypt" in stmt["Action"]
        assert "kms:GenerateDataKey" in stmt["Action"]
        assert "kms:DescribeKey" in stmt["Action"]
        assert stmt["Resource"] == {"Fn::GetAtt": ["AppKey", "Arn"]}

    def test_encrypt(self):
        policies = KMS(alias="app").to_policy("encrypt")
        stmt = policies[0]["Statement"][0]
        assert stmt["Action"] == ["kms:Encrypt"]

    def test_decrypt(self):
        policies = KMS(alias="app").to_policy("decrypt")
        stmt = policies[0]["Statement"][0]
        assert stmt["Action"] == ["kms:Decrypt"]

    def test_existing_key(self):
        k = KMS(existing_key_id="arn:aws:kms:us-east-1:123:key/abc")
        policies = k.to_policy("decrypt")
        stmt = policies[0]["Statement"][0]
        assert stmt["Resource"] == "arn:aws:kms:us-east-1:123:key/abc"

    def test_valid_permission_levels(self):
        assert KMS.VALID_PERMISSION_LEVELS == {"crud", "encrypt", "decrypt"}
