"""Tests for ``deployless init`` command."""
from __future__ import annotations

import os

import yaml
from click.testing import CliRunner

from deployless.cli import cli

# Default input: name(enter) + stage(enter) + env_file(enter) + runtime(enter) + api(1) + domain(N) + tags(N)
DEFAULT_INPUT = "\n\n\n\n\nN\nN\n"


def _run_init(tmp_path, input_text=DEFAULT_INPUT, args=None):
    """Run ``deployless init`` inside *tmp_path* with the given input."""
    runner = CliRunner()
    prev = os.getcwd()
    os.chdir(tmp_path)
    try:
        return runner.invoke(cli, args or ["init"], input=input_text)
    finally:
        os.chdir(prev)


class TestInitCreatesYaml:
    def test_defaults(self, tmp_path):
        result = _run_init(tmp_path)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["name"] == tmp_path.name
        assert config["provider"] == "aws"
        assert config["stage"] == "dev"
        assert config["env_file"] == ".env"
        # globals always visible
        assert config["globals"]["runtime"] == "python3.13"
        assert config["globals"]["memory"] == 256
        assert config["globals"]["timeout"] == 30
        assert config["globals"]["log_retention"] == 14
        # api defaults always visible
        assert config["api"]["cors"]["allow_origin"] == "*"
        assert config["api"]["endpoint_type"] == "REGIONAL"

    def test_custom_name_stage_runtime(self, tmp_path):
        # name=my-api, stage=prod, env_file=default, runtime=python3.11, api=default, domain=no, tags=no
        result = _run_init(tmp_path, input_text="my-api\nprod\n\npython3.11\n\nN\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["name"] == "my-api"
        assert config["stage"] == "prod"
        assert config["globals"]["runtime"] == "python3.11"

    def test_runtime_by_number(self, tmp_path):
        # Select runtime by number: 3 = python3.11
        result = _run_init(tmp_path, input_text="test\ndev\n\n3\n\nN\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["globals"]["runtime"] == "python3.11"

    def test_invalid_runtime_falls_back(self, tmp_path):
        # Invalid runtime → falls back to python3.13
        result = _run_init(tmp_path, input_text="test\ndev\n\npython2.7\n\nN\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["globals"]["runtime"] == "python3.13"

    def test_default_runtime_explicit(self, tmp_path):
        result = _run_init(tmp_path, input_text="test\ndev\n\npython3.13\n\nN\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["globals"]["runtime"] == "python3.13"


class TestInitApiConfig:
    def test_default_api_in_yaml(self, tmp_path):
        result = _run_init(tmp_path)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["api"]["cors"]["allow_origin"] == "*"
        assert config["api"]["endpoint_type"] == "REGIONAL"

    def test_custom_api(self, tmp_path):
        # api=2(custom), origin=https://myapp.com, endpoint=EDGE, domain=no, tags=no
        result = _run_init(tmp_path, input_text="test\ndev\n\n\n2\nhttps://myapp.com\nEDGE\nN\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["api"]["cors"]["allow_origin"] == "https://myapp.com"
        assert config["api"]["endpoint_type"] == "EDGE"


class TestInitDomain:
    def test_no_domain(self, tmp_path):
        result = _run_init(tmp_path)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert "domain" not in config.get("api", {})

    def test_external_dns_domain(self, tmp_path):
        # domain=Y, name=api.myapp.com, dns=1(external), tags=no
        result = _run_init(tmp_path, input_text="test\ndev\n\n\n\nY\napi.myapp.com\n1\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["api"]["domain"]["domain_name"] == "api.myapp.com"
        assert "route53" not in config["api"]["domain"]

    def test_route53_auto_domain(self, tmp_path):
        # domain=Y, name=api.myapp.com, dns=2(route53), mode=auto, tags=no
        result = _run_init(tmp_path, input_text="test\ndev\n\n\n\nY\napi.myapp.com\n2\nauto\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["api"]["domain"]["domain_name"] == "api.myapp.com"
        assert config["api"]["domain"]["route53"] is True

    def test_route53_explicit_zone(self, tmp_path):
        # domain=Y, name=api.myapp.com, dns=2(route53), mode=Z1234, tags=no
        result = _run_init(tmp_path, input_text="test\ndev\n\n\n\nY\napi.myapp.com\n2\nZ1234567890\nN\n")
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["api"]["domain"]["route53"]["hosted_zone_id"] == "Z1234567890"


class TestInitTags:
    def test_no_tags(self, tmp_path):
        result = _run_init(tmp_path)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert "tags" not in config

    def test_with_tags(self, tmp_path):
        # name, stage, env_file, runtime, api, domain=N, tags=Y, two tags then empty to finish
        input_text = "test\ndev\n\n\n\nN\nY\nProject=my-app\nEnvironment=prod\n\n"
        result = _run_init(tmp_path, input_text=input_text)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["tags"]["Project"] == "my-app"
        assert config["tags"]["Environment"] == "prod"

    def test_invalid_tag_skipped(self, tmp_path):
        # invalid tag (no =) is skipped, then valid tag, then finish
        input_text = "test\ndev\n\n\n\nN\nY\nbadtag\nGood=value\n\n"
        result = _run_init(tmp_path, input_text=input_text)
        assert result.exit_code == 0
        config = yaml.safe_load((tmp_path / "deployless.yaml").read_text())
        assert config["tags"]["Good"] == "value"
        assert "badtag" not in config.get("tags", {})


class TestInitAborts:
    def test_aborts_if_exists(self, tmp_path):
        (tmp_path / "deployless.yaml").write_text("name: existing")
        result = _run_init(tmp_path)
        assert result.exit_code != 0
        assert "already exists" in result.output
        assert "existing" in (tmp_path / "deployless.yaml").read_text()


class TestInitAppFlag:
    def test_creates_structure(self, tmp_path):
        result = _run_init(tmp_path, args=["init", "--app"])
        assert result.exit_code == 0
        assert (tmp_path / "app" / "__init__.py").exists()
        assert "create_app" in (tmp_path / "app" / "__init__.py").read_text()
        assert (tmp_path / "app" / "features" / ".gitkeep").exists()
        assert (tmp_path / "app" / "shared" / ".gitkeep").exists()
        assert (tmp_path / "run.py").exists()
        assert (tmp_path / ".gitignore").exists()

    def test_without_app_no_structure(self, tmp_path):
        result = _run_init(tmp_path)
        assert result.exit_code == 0
        assert not (tmp_path / "app").exists()
        assert not (tmp_path / "run.py").exists()

    def test_app_does_not_overwrite_existing_files(self, tmp_path):
        (tmp_path / "app").mkdir()
        (tmp_path / "app" / "__init__.py").write_text("# custom")
        (tmp_path / "run.py").write_text("# my runner")
        result = _run_init(tmp_path, args=["init", "--app"])
        assert result.exit_code == 0
        assert (tmp_path / "app" / "__init__.py").read_text() == "# custom"
        assert (tmp_path / "run.py").read_text() == "# my runner"
