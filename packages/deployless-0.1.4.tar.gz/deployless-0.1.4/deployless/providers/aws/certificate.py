"""
ACM certificate management and Route 53 hosted-zone auto-detection.

Handles the certificate lifecycle for custom domains:
- Route 53 auto-detect (``route53: true``)
- External DNS flow: request cert → show CNAMEs → verify → persist ARN
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path

import boto3
import yaml  # type: ignore[import-untyped]

logger = logging.getLogger("deployless.providers.aws.certificate")

DOMAIN_STATE_FILE = ".deployless/domain-state.json"


# ---------------------------------------------------------------------------
# Route 53 hosted-zone auto-detection
# ---------------------------------------------------------------------------

def find_hosted_zone(domain_name: str) -> str:
    """Return the Route 53 hosted-zone ID that matches *domain_name*.

    Extracts the base domain (e.g. ``api.myapp.com`` → ``myapp.com``) and
    queries Route 53.  Raises ``RuntimeError`` when no zone is found or
    when there are multiple ambiguous matches.
    """
    parts = domain_name.rstrip(".").split(".")
    if len(parts) < 2:
        raise RuntimeError(
            f"Cannot derive base domain from '{domain_name}'. "
            "Expected a fully-qualified domain like 'api.myapp.com'."
        )
    base_domain = ".".join(parts[-2:]) + "."

    client = boto3.client("route53")
    resp = client.list_hosted_zones_by_name(DNSName=base_domain, MaxItems="10")

    matches = [
        zone for zone in resp.get("HostedZones", [])
        if zone["Name"] == base_domain and not zone["Config"].get("PrivateZone", False)
    ]

    if not matches:
        raise RuntimeError(
            f"No public Route 53 hosted zone found for '{base_domain}'. "
            "Create one first, or provide an explicit hosted_zone_id."
        )
    if len(matches) > 1:
        ids = ", ".join(z["Id"].split("/")[-1] for z in matches)
        raise RuntimeError(
            f"Multiple Route 53 hosted zones found for '{base_domain}': {ids}. "
            "Provide an explicit hosted_zone_id to disambiguate."
        )

    zone_id: str = matches[0]["Id"].split("/")[-1]
    logger.info("Auto-detected Route 53 hosted zone: %s for %s", zone_id, base_domain)
    return zone_id


# ---------------------------------------------------------------------------
# ACM certificate lifecycle (external DNS flow)
# ---------------------------------------------------------------------------

def _acm_region(endpoint_type: str) -> str:
    """Return the ACM region required for the given API Gateway endpoint type.

    EDGE endpoints require ``us-east-1``; REGIONAL endpoints use the
    current default region.
    """
    if endpoint_type.upper() == "EDGE":
        return "us-east-1"
    return boto3.session.Session().region_name or "us-east-1"


def request_certificate(domain_name: str, region: str = "us-east-1") -> str:
    """Request a new ACM certificate with DNS validation.

    Returns the certificate ARN.
    """
    client = boto3.client("acm", region_name=region)
    resp = client.request_certificate(
        DomainName=domain_name,
        ValidationMethod="DNS",
    )
    arn: str = resp["CertificateArn"]
    logger.info("Requested ACM certificate: %s", arn)
    return arn


def get_validation_records(
    certificate_arn: str,
    region: str = "us-east-1",
    timeout: int = 30,
) -> list[dict]:
    """Return the CNAME validation records for *certificate_arn*.

    Polls briefly because the ``ResourceRecord`` field may not be
    available immediately after ``request_certificate()``.
    Returns a list of ``{"Name": ..., "Value": ...}`` dicts.
    """
    client = boto3.client("acm", region_name=region)
    deadline = time.time() + timeout

    while time.time() < deadline:
        resp = client.describe_certificate(CertificateArn=certificate_arn)
        options = resp["Certificate"].get("DomainValidationOptions", [])
        records = [
            {"Name": opt["ResourceRecord"]["Name"], "Value": opt["ResourceRecord"]["Value"]}
            for opt in options
            if "ResourceRecord" in opt
        ]
        if records:
            return records
        time.sleep(2)

    raise RuntimeError(
        f"Timed out waiting for ACM validation records for {certificate_arn}."
    )


def check_certificate_status(certificate_arn: str, region: str = "us-east-1") -> str:
    """Return the current status of the ACM certificate.

    Possible values: ``PENDING_VALIDATION``, ``ISSUED``, ``FAILED``, etc.
    """
    client = boto3.client("acm", region_name=region)
    resp = client.describe_certificate(CertificateArn=certificate_arn)
    status: str = resp["Certificate"]["Status"]
    return status


# ---------------------------------------------------------------------------
# State persistence (.deployless/domain-state.json)
# ---------------------------------------------------------------------------

def _state_path(project_root: Path) -> Path:
    """Return the absolute path to the domain state JSON file."""
    return project_root / DOMAIN_STATE_FILE


def load_domain_state(project_root: Path) -> dict | None:
    """Load the pending domain state, or ``None`` if none exists."""
    path = _state_path(project_root)
    if not path.exists():
        return None
    with open(path) as f:
        return json.load(f)  # type: ignore[no-any-return]


def save_domain_state(project_root: Path, state: dict) -> None:
    """Persist domain state between deploys."""
    path = _state_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(state, f, indent=2)


def clear_domain_state(project_root: Path) -> None:
    """Remove the domain state file."""
    path = _state_path(project_root)
    if path.exists():
        path.unlink()


# ---------------------------------------------------------------------------
# deployless.yaml write-back
# ---------------------------------------------------------------------------

def save_certificate_arn(project_root: Path, certificate_arn: str) -> None:
    """Write *certificate_arn* into ``deployless.yaml`` under ``api.domain``."""
    config_path = project_root / "deployless.yaml"
    with open(config_path) as f:
        config = yaml.safe_load(f) or {}

    config.setdefault("api", {}).setdefault("domain", {})["certificate_arn"] = certificate_arn

    with open(config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    logger.info("Saved certificate_arn to deployless.yaml")
