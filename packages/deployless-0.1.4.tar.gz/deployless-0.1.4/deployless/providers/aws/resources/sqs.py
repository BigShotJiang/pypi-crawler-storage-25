"""
SQS queue resource definition for deployless.

Produces one or two ``AWS::SQS::Queue`` resources — the main queue and,
optionally, an automatically named dead-letter queue (DLQ).  Supports
standard and FIFO queues with optional SSE-SQS encryption.
"""
from __future__ import annotations

import re

from deployless.providers.aws.resources.base import Resource


def _to_pascal(name: str) -> str:
    """Convert a hyphen/underscore-separated name to PascalCase."""
    return "".join(w.capitalize() for w in re.split(r"[-_]", name))


class SQS(Resource):
    """SQS Queue resource. Optionally creates a Dead Letter Queue."""

    def __init__(
        self,
        queue_name: str,
        fifo: bool = False,
        dlq: bool = False,
        visibility_timeout: int = 30,
        message_retention: int = 345600,  # 4 days in seconds
        max_receive_count: int = 3,
        encryption: bool = True,          # SqsManagedSseEnabled (SSE-SQS)
        deletion_policy: str = "Delete",
        existing: bool = False,
    ):
        """
        Args:
            queue_name: SQS queue name.  The ``.fifo`` suffix is appended automatically
                        when *fifo* is ``True`` and the name does not already end with it.
            fifo: Create a FIFO queue (enables ``ContentBasedDeduplication``).
            dlq: Automatically create a companion dead-letter queue and attach a redrive policy.
            visibility_timeout: Message invisibility period in seconds (0–43200, default 30).
            message_retention: How long messages are retained in seconds (60–1209600, default 4 days).
            max_receive_count: Max delivery attempts before a message is sent to the DLQ (1–1000).
            encryption: Enable SSE-SQS managed encryption (default ``True``).
            deletion_policy: CloudFormation deletion policy — ``"Delete"`` (default), ``"Retain"``, etc.
            existing: If ``True``, no resource is created; the queue URL is referenced directly.
        """
        self.queue_name = queue_name
        self.fifo = fifo
        self.dlq = dlq
        self.visibility_timeout = visibility_timeout
        self.message_retention = message_retention
        self.max_receive_count = max_receive_count
        self.encryption = encryption
        self.deletion_policy = deletion_policy
        self.existing = existing
        # Auto-add .fifo suffix for FIFO queues
        if fifo and not queue_name.endswith(".fifo"):
            self.queue_name = queue_name + ".fifo"

    def _resource_name(self) -> str:
        """Return the base queue name without the ``.fifo`` suffix."""
        return self.queue_name.replace(".fifo", "")

    def _logical_id(self) -> str:
        """
        Return the CloudFormation logical ID for the main queue.

        Strips the ``.fifo`` suffix and trailing ``-queue`` / ``_queue`` from the
        queue name before converting to PascalCase and appending ``"Queue"``.
        """
        name = self.queue_name.replace(".fifo", "")
        for suffix in ["-queue", "_queue"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return _to_pascal(name) + "Queue"

    def _dlq_logical_id(self) -> str:
        """Return the CloudFormation logical ID for the companion dead-letter queue."""
        return self._logical_id().replace("Queue", "") + "DLQueue"

    VALID_PERMISSION_LEVELS = {"crud", "send", "poll"}

    def to_policy(self, level: str = "crud") -> list[dict]:
        """Return SAM policy templates for the given permission level."""
        ref = self.queue_name if self.existing else {"Fn::GetAtt": [self._logical_id(), "QueueName"]}
        if level == "send":
            return [{"SQSSendMessagePolicy": {"QueueName": ref}}]
        if level == "poll":
            return [{"SQSPollerPolicy": {"QueueName": ref}}]
        # crud = both send + poll
        return [
            {"SQSSendMessagePolicy": {"QueueName": ref}},
            {"SQSPollerPolicy": {"QueueName": ref}},
        ]

    def validate(self) -> list:
        """Return a list of validation error strings; empty list means valid."""
        errors = []
        base_name = self.queue_name.replace(".fifo", "")
        if not base_name:
            errors.append("queue_name vacío")
        elif len(self.queue_name) > 80:
            errors.append(f"queue_name '{self.queue_name}' excede 80 caracteres ({len(self.queue_name)})")
        elif not re.match(r"^[a-zA-Z0-9_-]+$", base_name):
            errors.append(f"queue_name '{base_name}' contiene caracteres inválidos (solo alfanumérico, '-' y '_')")
        if not (0 <= self.visibility_timeout <= 43200):
            errors.append(f"visibility_timeout={self.visibility_timeout} fuera de rango [0, 43200]")
        if not (60 <= self.message_retention <= 1209600):
            errors.append(f"message_retention={self.message_retention} fuera de rango [60, 1209600]")
        if not (1 <= self.max_receive_count <= 1000):
            errors.append(f"max_receive_count={self.max_receive_count} fuera de rango [1, 1000]")
        return errors

    def env_var_name(self) -> str:
        """
        Return the Lambda environment variable name for this queue URL.

        Example: ``"orders-queue"`` → ``"ORDERS_QUEUE_URL"``.
        """
        name = self.queue_name.replace(".fifo", "")
        for suffix in ["-queue", "_queue"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return re.sub(r"[-]", "_", name).upper() + "_QUEUE_URL"

    def env_var_value(self):
        """Return a CloudFormation ``Ref`` resolving to the queue URL."""
        return {"Ref": self._logical_id()}

    def to_cfn(self) -> dict:
        """
        Return a dict of ``{logical_id: resource_dict}`` entries.

        When ``dlq=True`` a second entry for the dead-letter queue is included.
        Returns an empty dict when ``existing=True``.
        """
        if self.existing:
            return {}

        props = {
            "QueueName": self.queue_name,
            "VisibilityTimeout": self.visibility_timeout,
            "MessageRetentionPeriod": self.message_retention,
        }

        if self.encryption:
            props["SqsManagedSseEnabled"] = True

        if self.fifo:
            props["FifoQueue"] = True
            props["ContentBasedDeduplication"] = True

        if self.dlq:
            props["RedrivePolicy"] = {
                "deadLetterTargetArn": {"Fn::GetAtt": [self._dlq_logical_id(), "Arn"]},
                "maxReceiveCount": self.max_receive_count,
            }

        resources = {self._logical_id(): {"Type": "AWS::SQS::Queue", "Properties": props}}

        if self.dlq:
            dlq_name = self.queue_name.replace(".fifo", "") + "-dlq"
            if self.fifo:
                dlq_name += ".fifo"
            dlq_props = {
                "QueueName": dlq_name,
                "MessageRetentionPeriod": 1209600,  # 14 days
            }
            if self.encryption:
                dlq_props["SqsManagedSseEnabled"] = True
            if self.fifo:
                dlq_props["FifoQueue"] = True
            resources[self._dlq_logical_id()] = {
                "Type": "AWS::SQS::Queue",
                "Properties": dlq_props,
            }

        return resources  # Note: returns dict of logical_id -> resource

    def to_cfn_flat(self) -> dict:
        """Return ``{logical_id: cfn_dict}`` pairs (alias of ``to_cfn()`` for the SAM generator)."""
        return self.to_cfn()
