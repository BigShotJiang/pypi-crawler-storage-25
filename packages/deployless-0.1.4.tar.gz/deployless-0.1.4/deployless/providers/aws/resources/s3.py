"""
S3 bucket resource definition for deployless.

Produces an ``AWS::S3::Bucket`` CloudFormation resource with optional
server-side encryption, versioning, public access blocking, CORS rules,
and lifecycle rules.
"""
from __future__ import annotations

import re
from typing import Any

from deployless.providers.aws.resources.base import Resource


def _to_pascal(name: str) -> str:
    """Convert a hyphen/underscore-separated name to PascalCase."""
    return "".join(w.capitalize() for w in re.split(r"[-_]", name))


class S3(Resource):
    """S3 Bucket resource."""

    def __init__(
        self,
        bucket_name: str,
        versioning: bool = False,
        encryption: bool = True,
        cors: list | None = None,
        lifecycle_rules: list | None = None,
        public_access_block: bool = True,
        deletion_policy: str = "Delete",
        existing: bool = False,
    ):
        """
        Args:
            bucket_name: DNS-compliant S3 bucket name (3–63 characters, lowercase, no underscores).
            versioning: Enable object versioning.
            encryption: Enable AES-256 server-side encryption (default ``True``).
            cors: List of CORS rule dicts passed verbatim to ``CorsConfiguration.CorsRules``.
            lifecycle_rules: List of lifecycle rule dicts passed to ``LifecycleConfiguration.Rules``.
            public_access_block: Block all public access settings (default ``True``).
            deletion_policy: CloudFormation deletion policy — ``"Delete"`` (default), ``"Retain"``, etc.
            existing: If ``True``, no resource is created; the bucket name is used directly as the env var value.
        """
        self.bucket_name = bucket_name
        self.versioning = versioning
        self.encryption = encryption
        self.cors = cors
        self.lifecycle_rules = lifecycle_rules
        self.public_access_block = public_access_block
        self.deletion_policy = deletion_policy
        self.existing = existing

    def _resource_name(self) -> str:
        """Return the physical S3 bucket name."""
        return self.bucket_name

    def _logical_id(self) -> str:
        """
        Return the CloudFormation logical ID for this bucket.

        Strips trailing ``-bucket`` / ``_bucket`` from the bucket name before
        converting to PascalCase and appending ``"Bucket"``.
        """
        name = self.bucket_name
        for suffix in ["-bucket", "_bucket"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return _to_pascal(name) + "Bucket"

    def env_var_name(self) -> str:
        """
        Return the Lambda environment variable name for this bucket.

        Example: ``"uploads-bucket"`` → ``"UPLOADS_BUCKET"``.
        """
        name = self.bucket_name
        for suffix in ["-bucket", "_bucket"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return re.sub(r"[-]", "_", name).upper() + "_BUCKET"

    VALID_PERMISSION_LEVELS = {"crud", "read", "write"}

    def to_policy(self, level: str = "crud") -> list[dict]:
        """Return SAM policy templates for the given permission level."""
        policy_map = {
            "crud": "S3CrudPolicy",
            "read": "S3ReadPolicy",
            "write": "S3WritePolicy",
        }
        ref = self.bucket_name if self.existing else {"Ref": self._logical_id()}
        return [{policy_map[level]: {"BucketName": ref}}]

    def validate(self) -> list:
        """Return a list of validation error strings; empty list means valid."""
        errors = []
        name = self.bucket_name
        if not name:
            errors.append("bucket_name vacío")
        elif len(name) < 3 or len(name) > 63:
            errors.append(f"bucket_name '{name}' debe tener entre 3 y 63 caracteres ({len(name)})")
        elif "_" in name:
            errors.append(f"bucket_name '{name}' no puede contener underscores (S3 es DNS-compliant)")
        elif not re.match(r"^[a-z0-9][a-z0-9.-]*[a-z0-9]$", name):
            errors.append(
                f"bucket_name '{name}' debe ser DNS-compliant"
                " (lowercase, sin underscores, empieza y termina en alfanumérico)"
            )
        return errors

    def to_cfn(self) -> dict:
        """Return the CloudFormation resource dict, or an empty dict when ``existing=True``."""
        if self.existing:
            return {}

        props: dict[str, Any] = {"BucketName": self.bucket_name}

        if self.encryption:
            props["BucketEncryption"] = {
                "ServerSideEncryptionConfiguration": [
                    {"ServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}
                ]
            }

        if self.versioning:
            props["VersioningConfiguration"] = {"Status": "Enabled"}

        if self.public_access_block:
            props["PublicAccessBlockConfiguration"] = {
                "BlockPublicAcls": True,
                "BlockPublicPolicy": True,
                "IgnorePublicAcls": True,
                "RestrictPublicBuckets": True,
            }

        if self.cors:
            props["CorsConfiguration"] = {"CorsRules": self.cors}

        if self.lifecycle_rules:
            props["LifecycleConfiguration"] = {"Rules": self.lifecycle_rules}

        resource = {"Type": "AWS::S3::Bucket", "Properties": props}
        if self.deletion_policy != "Delete":
            resource["DeletionPolicy"] = self.deletion_policy
        return resource
