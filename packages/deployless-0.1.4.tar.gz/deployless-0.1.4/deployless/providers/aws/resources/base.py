"""
Base class for all AWS resource types supported by deployless.

Concrete subclasses (DynamoDB, S3, SQS, KMS, SSMParameter) implement
``_logical_id``, ``to_cfn``, and ``env_var_name`` to produce the correct
CloudFormation fragments and the Lambda environment variable bindings.
"""
import re


class Resource:
    """Base class for all AWS resources managed by deployless."""

    def _logical_id(self) -> str:
        """Return the CloudFormation logical ID for this resource. Subclasses must override."""
        raise NotImplementedError

    def to_cfn(self) -> dict:
        """Return the CloudFormation resource definition dict. Subclasses must override."""
        raise NotImplementedError

    def env_var_name(self) -> str:
        """Return the env var name to inject into Lambda (e.g. USERS_TABLE)."""
        raise NotImplementedError

    def env_var_value(self):
        """Return CFN intrinsic function or string for the env var value."""
        return {"Ref": self._logical_id()}

    def _resource_name(self) -> str:
        """Return the primary name of this resource. Subclasses must override."""
        raise NotImplementedError

    def _registry_key(self) -> str:
        """Derive a snake_case registry key from the resource's primary name."""
        return re.sub(r"[-]", "_", self._resource_name()).lower()
