"""
Project configuration loader for deployless.

Reads ``deployless.yaml`` from the project root and deep-merges it with
built-in defaults so every config key always has a sensible value.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, cast

import yaml  # type: ignore[import-untyped]


class ConfigError(Exception):
    """Raised when environment variable interpolation fails."""

    def __init__(self, errors: list[str]):
        """Initialise with a list of unresolved variable error messages."""
        self.errors = errors
        super().__init__(f"{len(errors)} unresolved variable(s) in deployless.yaml")


_ENV_VAR_RE = re.compile(r"\$\{([^}]+)\}")


def _resolve_env_vars(value: str) -> tuple[str, list[str]]:
    """Replace ``${VAR}`` and ``${VAR:-default}`` references in *value*.

    Returns ``(resolved_string, errors)`` where *errors* lists any
    variables that could not be resolved.
    """
    errors: list[str] = []

    def _replace(match: re.Match) -> str:
        expr = match.group(1)
        name, _, default = expr.partition(":-")
        env_val = os.environ.get(name)
        if env_val is not None:
            return str(env_val)
        if _ == ":-":
            return str(default)
        errors.append(f"[E32] Unresolved variable '${{{name}}}' — not found in environment and no default provided")
        return str(match.group(0))

    resolved = _ENV_VAR_RE.sub(_replace, value)
    return resolved, errors


def _interpolate_config(obj: object) -> tuple[object, list[str]]:
    """Recursively resolve ``${VAR}`` references in string values."""
    errors: list[str] = []

    if isinstance(obj, str):
        if "${" in obj:
            resolved, errs = _resolve_env_vars(obj)
            errors.extend(errs)
            return resolved, errors
        return obj, errors

    if isinstance(obj, dict):
        result = {}
        for key, value in obj.items():
            new_value, errs = _interpolate_config(value)
            errors.extend(errs)
            result[key] = new_value
        return result, errors

    if isinstance(obj, list):
        result_list: list[object] = []
        for item in obj:
            new_item, errs = _interpolate_config(item)
            errors.extend(errs)
            result_list.append(new_item)
        return result_list, errors

    return obj, errors

DEFAULTS: dict[str, Any] = {
    "name": "deployless-app",
    "provider": "aws",
    "stage": "dev",
    "paths": {
        "features": "app/features",
        "shared": "app/shared",
    },
    "globals": {
        "runtime": "python3.13",
        "memory": 256,
        "timeout": 30,
        "log_retention": 14,
    },
    "api": {
        "cors": {
            "allow_origin": "*",
            "allow_methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"],
        },
        "endpoint_type": "REGIONAL",
    },
    "env": {},
    "env_file": None,
    "init_app": [],
}


def _deep_merge(base: dict, override: dict) -> dict:
    """
    Recursively merge *override* into *base*, returning a new dict.

    Nested dicts are merged rather than replaced, so a partial override only
    changes the keys it specifies while keeping all other base values intact.

    Args:
        base: The default configuration dict.
        override: User-supplied values that take precedence.

    Returns:
        A new dict containing the merged result.
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(project_root: str | Path | None = None) -> dict[str, Any]:
    """Load deployless.yaml and merge with defaults.

    Environment variable references (``${VAR}`` / ``${VAR:-default}``) in
    string values are resolved from ``os.environ`` before merging.
    """
    root = Path(project_root) if project_root else Path.cwd()
    config_path = root / "deployless.yaml"
    user_config: dict[str, Any] = {}
    if config_path.exists():
        with open(config_path) as f:
            user_config = dict(yaml.safe_load(f) or {})
        interpolated, errors = _interpolate_config(user_config)
        user_config = cast(dict[str, Any], interpolated)
        if errors:
            raise ConfigError(errors)
    return _deep_merge(DEFAULTS, user_config)
