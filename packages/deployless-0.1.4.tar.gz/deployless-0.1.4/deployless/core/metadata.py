"""
Compile-time metadata decorators and registry for deployless.

This module provides the decorators and helpers that users call inside their
``routes.py`` files (``configure``, ``route``, ``cron``, ``lambda_function``)
as well as the CloudFormation intrinsic helpers ``Ref`` and ``GetAtt``.

All registrations are stored in the in-process ``_REGISTRY`` dict which the
compiler reads after importing every feature module.  At Lambda runtime the
entire module is replaced by a lightweight no-op stub so there is zero overhead.
"""
from __future__ import annotations

import inspect
import sys
from contextvars import ContextVar
from pathlib import Path
from typing import Any

# Sentinel to distinguish "not set" (inherit global) from auth=None (explicitly public)
_UNSET = object()

_REGISTRY: dict[str, Any] = {
    "features": {},   # {feature_name: {"config": {...}, "resources": {}}}
    "crons": [],      # [{name, func, module_file, schedule, memory, timeout, env, description}]
    "lambdas": [],    # [{name, func, module_file, memory, timeout, env, description}]
}

# Set by the compiler before importing each feature module so that configure()
# knows which feature it belongs to — without relying on stack inspection.
_compiling_feature: ContextVar[str | None] = ContextVar("_compiling_feature", default=None)

# Maps feature directory (resolved) → feature name.
# Populated by the compiler before the import loop so that configure() can
# resolve the correct feature from the caller's file path even when Python's
# import chain causes another feature's module to execute first.
_feature_dirs: dict[str, str] = {}


def set_feature_dirs(features: list[dict]):
    """Populate the feature-dir → name mapping used by configure()."""
    _feature_dirs.clear()
    for f in features:
        _feature_dirs[str(Path(f["dir"]).resolve())] = f["name"]


def set_compiling_feature(name: str | None):
    """
    Tell the registry which feature is currently being compiled.
    Called by the compiler around each feature module import.
    Returns a Token that can be passed to reset_compiling_feature().
    """
    return _compiling_feature.set(name)


def _resolve_feature_from_caller() -> str | None:
    """Determine which feature the caller belongs to by inspecting the call stack.

    Walks up the stack to find the first frame whose file is inside a known
    feature directory.  Falls back to ``_compiling_feature`` if no match is
    found (e.g. configure() called from a non-feature helper).
    """
    if _feature_dirs:
        for frame_info in inspect.stack():
            try:
                caller_path = str(Path(frame_info.filename).resolve())
            except (ValueError, OSError):
                continue
            for feat_dir, feat_name in _feature_dirs.items():
                if caller_path.startswith(feat_dir + "/") or caller_path == feat_dir:
                    return feat_name
    return _compiling_feature.get()


def configure(
    # --- Básico ---
    memory: int | None = None,
    timeout: int | None = None,
    description: str | None = None,
    # --- Entorno ---
    env: dict | None = None,
    layers: list | None = None,
    # --- IAM ---
    policies: list | None = None,
    # --- Recursos AWS ---
    resources: dict | None = None,
    # --- Arquitectura ---
    architectures: list | None = None,
    tracing: bool | None = None,
    # --- Concurrencia ---
    reserved_concurrency: int | None = None,
    provisioned_concurrency: int | None = None,
    # --- Almacenamiento ---
    ephemeral_storage: int | None = None,
    # --- Fiabilidad ---
    dlq: bool = False,
    # --- Observabilidad ---
    log_retention: int | None = None,
    alarms=_UNSET,
    # --- Auth (API Gateway) ---
    auth=_UNSET,
):
    """
    Register Lambda configuration for the current feature.
    Call this at module level inside app/features/{feature}/routes.py.
    This is a no-op at runtime — only the deployless compiler reads it.

    auth values:
      (not set)  → inherit global auth from deployless.yaml
      None       → all routes in this feature are public (no auth)
      "api_key"  → all routes in this feature require an API key

    alarms values:
      (not set)  → inherit global alarms config from deployless.yaml
      False      → disable alarms for this feature
      True       → enable with default thresholds
      dict       → custom thresholds (see docs)
    """
    if _compiling_feature.get() is None:
        return

    feature_name = _resolve_feature_from_caller()
    if feature_name is None:
        return

    config: dict[str, Any] = {}
    if memory is not None:
        config["memory"] = memory
    if timeout is not None:
        config["timeout"] = timeout
    if description is not None:
        config["description"] = description
    if env:
        config["env"] = env
    if layers:
        config["layers"] = layers
    if policies:
        config["policies"] = policies
    if architectures:
        config["architectures"] = architectures
    if tracing is not None:
        config["tracing"] = tracing
    if reserved_concurrency is not None:
        config["reserved_concurrency"] = reserved_concurrency
    if provisioned_concurrency is not None:
        config["provisioned_concurrency"] = provisioned_concurrency
    if ephemeral_storage is not None:
        config["ephemeral_storage"] = ephemeral_storage
    if dlq:
        config["dlq"] = dlq
    if log_retention is not None:
        config["log_retention"] = log_retention
    if auth is not _UNSET:
        config["auth"] = auth
    if alarms is not _UNSET:
        config["alarms"] = alarms

    if feature_name not in _REGISTRY["features"]:
        _REGISTRY["features"][feature_name] = {"config": {}, "resources": {}, "resource_permissions": {}}

    _REGISTRY["features"][feature_name]["config"].update(config)

    if resources:
        for name, value in resources.items():
            if isinstance(value, tuple):
                resource, level = value
            else:
                resource = value
                level = "crud"
            _REGISTRY["features"][feature_name]["resources"][name] = resource
            _REGISTRY["features"][feature_name]["resource_permissions"][name] = level


def route(
    memory: int | None = None,
    timeout: int | None = None,
    description: str | None = None,
    auth=_UNSET,
):
    """
    Mark a specific route as its own Lambda function (instead of sharing with the feature).

    auth values:
      (not set)  → inherit feature/global auth
      None       → this route is public
      "api_key"  → this route requires an API key

    Usage:
        @pc.route(memory=1024, timeout=60)
        @bp.route('/export', methods=['POST'])
        def export_data():
            ...
    """
    def decorator(func):
        """Attach split-route config to the decorated function and return it unchanged."""
        func.__deployless_route_config__ = {
            "memory": memory,
            "timeout": timeout,
            "description": description,
            "auth": auth,
        }
        return func
    return decorator


def cron(
    schedule: str,
    memory: int | None = None,
    timeout: int | None = None,
    env: dict | None = None,
    description: str | None = None,
):
    """
    Register a Lambda function triggered on a schedule.

    schedule formats:
      "rate(5 minutes)"
      "rate(1 hour)"
      "cron(0 9 * * ? *)"   # Every day at 9:00 UTC

    Usage:
        @pc.cron(schedule="rate(24 hours)", memory=128, timeout=60)
        def cleanup(event, context):
            return {"status": "ok"}
    """
    def decorator(func):
        """Register the decorated function as a cron Lambda and return it unchanged."""
        _REGISTRY["crons"].append({
            "name": func.__name__,
            "func": func,
            "module_file": inspect.getfile(func),
            "schedule": schedule,
            "memory": memory,
            "timeout": timeout,
            "env": env or {},
            "description": description,
        })
        return func
    return decorator


def lambda_function(
    memory: int | None = None,
    timeout: int | None = None,
    env: dict | None = None,
    description: str | None = None,
):
    """
    Decorator to mark a function as a standalone Lambda (not HTTP, not cron).
    Useful for SQS consumers, S3 triggers, Step Functions, etc.

    Usage:
        @pc.lambda_function(memory=256, timeout=60)
        def process_queue(event, context):
            ...
    """
    def decorator(func):
        """Register the decorated function as a standalone Lambda and return it unchanged."""
        _REGISTRY["lambdas"].append({
            "name": func.__name__,
            "func": func,
            "module_file": inspect.getfile(func),
            "memory": memory,
            "timeout": timeout,
            "env": env or {},
            "description": description,
        })
        return func
    return decorator


def _scan_module_resources(module) -> dict:
    """Scan a module's namespace for Resource instances.

    Returns {registry_key: resource} for each unique Resource found.
    Used to detect shared resources imported in a feature's routes.py.
    """
    from deployless.providers.aws.resources.base import Resource

    seen_ids: set[int] = set()
    result = {}
    for attr_name in dir(module):
        obj = getattr(module, attr_name, None)
        if isinstance(obj, Resource) and id(obj) not in seen_ids:
            seen_ids.add(id(obj))
            result[obj._registry_key()] = obj
    return result


def _scan_feature_dir_resources(feature_dir: str) -> dict:
    """Scan sys.modules for modules whose __file__ is inside feature_dir.

    Returns {registry_key: resource} for all Resource instances found.
    Used to detect resources created within a feature's directory.
    """
    from deployless.providers.aws.resources.base import Resource

    feature_path = Path(feature_dir).resolve()
    seen_ids: set[int] = set()
    result = {}
    for mod in sys.modules.values():
        mod_file = getattr(mod, "__file__", None)
        if not mod_file:
            continue
        try:
            if not Path(mod_file).resolve().is_relative_to(feature_path):
                continue
        except (ValueError, OSError):
            continue
        for attr_name in dir(mod):
            obj = getattr(mod, attr_name, None)
            if isinstance(obj, Resource) and id(obj) not in seen_ids:
                seen_ids.add(id(obj))
                result[obj._registry_key()] = obj
    return result


def Ref(resource) -> dict:
    """Reference an AWS resource (for use in policies or env vars)."""
    if isinstance(resource, str):
        return {"Ref": resource}
    return {"Ref": resource._logical_id()}


def GetAtt(resource, attribute: str) -> dict:
    """Get an attribute from an AWS resource (e.g. GetAtt(my_queue, "Arn"))."""
    if isinstance(resource, str):
        name = resource
    elif hasattr(resource, "_logical_id"):
        name = resource._logical_id()
    else:
        raise ValueError(f"Cannot create GetAtt for {resource}")
    return {"Fn::GetAtt": [name, attribute]}


def get_registry() -> dict:
    """Return the global registry dict populated by the metadata decorators."""
    return _REGISTRY


def reset_registry():
    """Clear all entries from the global registry.

    Called by the compiler at the start of each build so that successive
    ``compile_project`` calls within the same process do not accumulate
    stale registrations from previous runs.
    """
    _REGISTRY["features"] = {}
    _REGISTRY["crons"] = []
    _REGISTRY["lambdas"] = []
    _compiling_feature.set(None)
    _feature_dirs.clear()
