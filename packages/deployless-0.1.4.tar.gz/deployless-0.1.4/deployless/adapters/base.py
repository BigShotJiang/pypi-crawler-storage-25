"""
Abstract base class for web-framework adapters.

Each adapter knows how to inspect a loaded feature module and extract the
route information the compiler needs to build the SAM template.
"""
from abc import ABC, abstractmethod


class FrameworkAdapter(ABC):
    """
    Interface that every framework adapter must implement.

    The compiler uses :meth:`detect` to pick the right adapter for a feature
    module, then calls :meth:`extract_routes` and :meth:`get_url_prefix` to
    collect the routing information required for template generation.
    """

    @abstractmethod
    def detect(self, module) -> bool:
        """Return True if this adapter can handle the given module."""

    @abstractmethod
    def extract_routes(self, module) -> list:
        """
        Extract all routes from the module.
        Returns list of dicts:
        {
            path: str,          # Flask path e.g. /users/<user_id>
            sam_path: str,      # SAM path e.g. /users/{user_id}
            methods: list[str], # ["GET", "POST"]
            endpoint: str,      # endpoint name
            func: callable,     # view function
            split_config: dict | None,  # from @pc.route() if present
        }
        """

    @abstractmethod
    def get_url_prefix(self, module) -> str:
        """Get the URL prefix for this feature's routes."""
