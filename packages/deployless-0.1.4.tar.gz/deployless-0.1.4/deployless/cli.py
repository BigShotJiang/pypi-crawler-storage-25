"""
deployless CLI — build, validate, deploy, clean, secrets
"""
import subprocess
import sys
from pathlib import Path

import click

from deployless.compiler.checker import run_checks
from deployless.compiler.env_file import parse_env_file, push_secrets, sync_secrets
from deployless.compiler.main import compile_project
from deployless.compiler.validator import ValidationError, check_existing_resources
from deployless.core.config import ConfigError, load_config
from deployless.core.discovery import discover_features


@click.group()
@click.version_option(package_name="deployless", prog_name="deployless")
def cli():
    """deployless — compile your Python web app to AWS SAM serverless."""


AWS_PYTHON_RUNTIMES = [
    "python3.13",
    "python3.12",
    "python3.11",
    "python3.10"
]


@cli.command()
@click.option("--app", is_flag=True, help="Also create app/ structure, run.py, and .gitignore.")
def init(app):
    """Initialize a new deployless project with an interactive wizard."""
    root = Path.cwd()
    config_path = root / "deployless.yaml"

    if config_path.exists():
        click.echo(click.style("[deployless] deployless.yaml already exists. Aborting.", fg="red"))
        sys.exit(1)

    click.echo(click.style("[deployless] Initializing new project...\n", fg="green"))

    # 1. Project name
    name = click.prompt("Project name", default=root.name)

    # 2. Stage
    stage = click.prompt("Stage", default="dev")

    # 3. Env file
    env_file = click.prompt("Env file", default=".env")

    # 4. Runtime (show list)
    click.echo("\nAvailable runtimes:")
    for i, rt in enumerate(AWS_PYTHON_RUNTIMES, 1):
        marker = " (default)" if rt == "python3.13" else ""
        click.echo(f"  {i}. {rt}{marker}")
    runtime_input = click.prompt(
        "\nRuntime",
        default="python3.13",
    )
    # Accept number or name
    if runtime_input.isdigit():
        idx = int(runtime_input) - 1
        runtime = AWS_PYTHON_RUNTIMES[idx] if 0 <= idx < len(AWS_PYTHON_RUNTIMES) else "python3.13"
    elif runtime_input in AWS_PYTHON_RUNTIMES:
        runtime = runtime_input
    else:
        click.echo(click.style(f"  '{runtime_input}' not recognized, using python3.13", fg="yellow"))
        runtime = "python3.13"

    # 5. API config
    click.echo("\nAPI configuration:")
    click.echo("  1. Default (CORS: *, all methods, REGIONAL)")
    click.echo("  2. Custom")
    api_choice = click.prompt("API config", default="1")

    if api_choice == "2":
        allow_origin = click.prompt("  CORS allow_origin", default="*")
        endpoint_type = click.prompt("  Endpoint type (REGIONAL/EDGE)", default="REGIONAL")
    else:
        allow_origin = "*"
        endpoint_type = "REGIONAL"

    api_lines = [
        "api:",
        "  cors:",
        f'    allow_origin: "{allow_origin}"',
        '    allow_methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"]',
        '    allow_headers: ["Content-Type", "Authorization"]',
        f"  endpoint_type: {endpoint_type}",
    ]

    # 6. Custom domain
    use_domain = click.confirm("\nConfigure custom domain?", default=False)
    domain_lines = []
    if use_domain:
        domain_name = click.prompt("  Domain name (e.g. api.myapp.com)")
        click.echo("  DNS provider:")
        click.echo("    1. External (Cloudflare, GoDaddy, etc.) — guided flow")
        click.echo("    2. Route 53 — fully automatic")
        dns_choice = click.prompt("  DNS provider", default="1")

        domain_lines = [
            "  domain:",
            f"    domain_name: {domain_name}",
        ]
        if dns_choice == "2":
            route53_mode = click.prompt(
                "    Auto-detect hosted zone or provide ID? (auto/ID)",
                default="auto",
            )
            if route53_mode.lower() == "auto":
                domain_lines.append("    route53: true")
            else:
                domain_lines.append("    route53:")
                domain_lines.append(f"      hosted_zone_id: {route53_mode}")

    # 7. Tags
    tags = {}
    use_tags = click.confirm("\nAdd resource tags?", default=False)
    if use_tags:
        click.echo("  Enter tags as Key=Value (empty line to finish):")
        while True:
            entry = click.prompt("  Tag", default="", show_default=False)
            if not entry:
                break
            if "=" not in entry:
                click.echo(click.style("    Invalid format, use Key=Value", fg="yellow"))
                continue
            key, _, value = entry.partition("=")
            tags[key.strip()] = value.strip()

    # Build YAML
    lines = [
        f"name: {name}",
        "provider: aws",
        f"stage: {stage}",
        f"env_file: {env_file}",
        "globals:",
        f"  runtime: {runtime}",
        "  memory: 256",
        "  timeout: 30",
        "  log_retention: 14",
    ]
    lines += api_lines
    if domain_lines:
        lines += domain_lines
    if tags:
        lines.append("tags:")
        for k, v in tags.items():
            lines.append(f"  {k}: {v}")

    config_path.write_text("\n".join(lines) + "\n")
    created = ["deployless.yaml"]

    if app:
        # app/__init__.py
        app_dir = root / "app"
        app_dir.mkdir(exist_ok=True)
        init_file = app_dir / "__init__.py"
        if not init_file.exists():
            init_file.write_text(
                "from flask import Flask\n\n\n"
                "def create_app():\n"
                "    app = Flask(__name__)\n"
                "    return app\n"
            )
            created.append("app/__init__.py")

        # app/features/ and app/shared/
        for sub in ("features", "shared"):
            d = app_dir / sub
            d.mkdir(exist_ok=True)
            gitkeep = d / ".gitkeep"
            if not gitkeep.exists():
                gitkeep.touch()
            created.append(f"app/{sub}/")

        # run.py
        run_file = root / "run.py"
        if not run_file.exists():
            run_file.write_text(
                "from app import create_app\n\n"
                "app = create_app()\n\n"
                'if __name__ == "__main__":\n'
                '    app.run(host="0.0.0.0", port=5000, debug=True)\n'
            )
            created.append("run.py")

        # .gitignore
        gitignore = root / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text(
                ".dist/\n.aws-sam/\ntemplate.yaml\nsamconfig.toml\n"
                "__pycache__/\n*.pyc\n.env\n"
            )
            created.append(".gitignore")

    click.echo(click.style("\n[deployless] Created:", fg="green"))
    for f in created:
        click.echo(f"  {f}")
    click.echo()


@cli.command()
@click.option("-o", "--output", default="template.yaml", help="Output template file path.")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--dry-run", is_flag=True, help="Validate and show plan without writing files.")
@click.option("-v", "--verbose", is_flag=True, help="Verbose output.")
def build(output, stage, dry_run, verbose):
    """Generate SAM template and build .dist/ Lambda packages."""
    try:
        compile_project(stage=stage, output=output, dry_run=dry_run, verbose=verbose)
    except ConfigError as e:
        click.echo(click.style("\n[deployless] Config failed — unresolved variables:\n", fg="red"))
        for error in e.errors:
            click.echo(click.style(f"  {error}", fg="red"))
        sys.exit(1)
    except ValidationError as e:
        click.echo(click.style("\n[deployless] Build failed — validation errors:\n", fg="red"))
        for error in e.errors:
            click.echo(click.style(f"  {error}", fg="red"))
        sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"\n[deployless] Build failed: {e}", fg="red"))
        raise


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--check-existing", is_flag=True, help="Verify existing=True resources exist in AWS.")
@click.option("-v", "--verbose", is_flag=True)
def validate_cmd(stage, check_existing, verbose):
    """Validate project configuration without generating files."""
    try:
        state = compile_project(stage=stage, dry_run=True, verbose=verbose)
        click.echo(click.style("[deployless] Validation passed.", fg="green"))
    except ConfigError as e:
        click.echo(click.style("[deployless] Config failed — unresolved variables:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    except ValidationError as e:
        click.echo(click.style("[deployless] Validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    if check_existing:
        click.echo("[deployless] Checking existing resources in AWS...")
        errors = check_existing_resources(state)
        if errors:
            click.echo(click.style("[deployless] Check existing failed:\n", fg="red"))
            for err in errors:
                click.echo(click.style(f"  {err}", fg="red"))
            sys.exit(1)
        click.echo(click.style("[deployless] All existing resources verified.", fg="green"))


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("-v", "--verbose", is_flag=True)
def check(stage, verbose):
    """Run pre-flight checks: env vars, SAM CLI, AWS credentials, existing resources."""
    # Compile (dry-run) to get state and run build-time validation
    try:
        state = compile_project(stage=stage, dry_run=True, verbose=verbose)
    except ConfigError as e:
        click.echo(click.style("[deployless] Config failed — unresolved variables:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    config = load_config()
    if stage:
        config["stage"] = stage

    click.echo("[deployless] Running pre-flight checks...")
    errors = run_checks(state, config)

    if errors:
        click.echo(click.style("[deployless] Pre-flight checks failed:\n", fg="red"))
        for err in errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    click.echo(click.style("[deployless] All checks passed.", fg="green"))


def _resolve_domain_certificate(config: dict) -> None:
    """Resolve the ACM certificate for a custom domain if needed.

    Three paths:
    - ``certificate_arn`` already set → no-op.
    - ``route53`` configured → auto-detect hosted zone if ``route53: true``,
      then let CloudFormation handle cert creation.
    - External DNS (no ``route53``) → boto3 flow: request cert, show
      CNAME records, wait for user to validate, persist ARN.
    """
    domain = config.get("api", {}).get("domain")
    if not domain or not domain.get("domain_name"):
        return
    if domain.get("certificate_arn"):
        return  # already provided — nothing to do

    project_root = Path.cwd()
    domain_name = domain["domain_name"]
    route53 = domain.get("route53")

    # Case 1: Route 53 — resolve hosted_zone_id if route53: true
    if route53:
        if route53 is True:
            from deployless.providers.aws.certificate import find_hosted_zone

            click.echo(f"[deployless] Auto-detecting Route 53 hosted zone for '{domain_name}'...")
            try:
                zone_id = find_hosted_zone(domain_name)
            except RuntimeError as e:
                click.echo(click.style(f"[deployless] {e}", fg="red"))
                sys.exit(1)
            click.echo(f"[deployless] Found hosted zone: {zone_id}")
            # Inject resolved zone ID into config so template generation uses it
            config["api"]["domain"]["route53"] = {"hosted_zone_id": zone_id}
        # Route 53 case: CloudFormation handles cert creation — no more work here.
        return

    # Case 2: External DNS — boto3 flow
    from deployless.providers.aws.certificate import (
        _acm_region,
        check_certificate_status,
        clear_domain_state,
        get_validation_records,
        load_domain_state,
        request_certificate,
        save_certificate_arn,
        save_domain_state,
    )

    endpoint_type = config.get("api", {}).get("endpoint_type", "REGIONAL")
    region = _acm_region(endpoint_type)
    state = load_domain_state(project_root)

    if not state:
        # First run: request certificate
        click.echo(f"[deployless] Requesting ACM certificate for '{domain_name}' (region: {region})...")
        try:
            cert_arn = request_certificate(domain_name, region=region)
            records = get_validation_records(cert_arn, region=region)
        except Exception as e:
            click.echo(click.style(f"[deployless] Failed to request certificate: {e}", fg="red"))
            sys.exit(1)

        save_domain_state(project_root, {
            "certificate_arn": cert_arn,
            "domain_name": domain_name,
            "region": region,
        })

        click.echo(click.style(
            "\n[deployless] ACM certificate requested. Add these DNS records at your provider:\n",
            fg="yellow",
        ))
        for rec in records:
            click.echo(f"  CNAME  {rec['Name']}  →  {rec['Value']}")
        click.echo(click.style(
            "\n  Note: If using Cloudflare, set the proxy to 'DNS only' (grey cloud) for this record.",
            fg="yellow",
        ))
        click.echo(click.style(
            "\nThen run 'deployless deploy' again.\n",
            fg="yellow",
        ))
        sys.exit(0)

    # Subsequent run: check validation status
    cert_arn = state["certificate_arn"]
    region = state.get("region", region)

    click.echo("[deployless] Checking ACM certificate status...")
    try:
        status = check_certificate_status(cert_arn, region=region)
    except Exception as e:
        click.echo(click.style(f"[deployless] Failed to check certificate: {e}", fg="red"))
        sys.exit(1)

    if status == "ISSUED":
        click.echo(click.style("[deployless] Certificate validated!", fg="green"))
        save_certificate_arn(project_root, cert_arn)
        clear_domain_state(project_root)
        # Reload the config so the build picks up the new certificate_arn
        config["api"]["domain"]["certificate_arn"] = cert_arn
        return

    if status == "PENDING_VALIDATION":
        try:
            records = get_validation_records(cert_arn, region=region)
        except Exception:
            records = []

        click.echo(click.style(
            "\n[deployless] Certificate still pending validation. Ensure these DNS records exist:\n",
            fg="yellow",
        ))
        for rec in records:
            click.echo(f"  CNAME  {rec['Name']}  →  {rec['Value']}")
        click.echo(click.style(
            "\n  Note: If using Cloudflare, set the proxy to 'DNS only' (grey cloud) for this record.",
            fg="yellow",
        ))
        click.echo(click.style(
            "\nThen run 'deployless deploy' again.\n",
            fg="yellow",
        ))
        sys.exit(0)

    # FAILED or other status
    click.echo(click.style(
        f"[deployless] Certificate status: {status}. Cleaning up — please try again.",
        fg="red",
    ))
    clear_domain_state(project_root)
    sys.exit(1)


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--guided", is_flag=True, help="Force sam deploy --guided (wizard mode).")
@click.option("--push-secrets", is_flag=True, help="Push SECRET_ vars from .env to SSM before deploying.")
@click.option("-v", "--verbose", is_flag=True)
def deploy(stage, guided, push_secrets, verbose):
    """Build and deploy to AWS (runs: check → deployless build → sam build → sam deploy)."""
    # Auto-detect first deploy: samconfig.toml is created by SAM after the first --guided run.
    is_first_deploy = not Path("samconfig.toml").exists()
    if is_first_deploy and not guided:
        click.echo(click.style(
            "[deployless] No samconfig.toml found — running guided setup for the first time.",
            fg="yellow",
        ))

    # Step 1: pre-flight checks (dry-run compile + env vars + SAM + AWS creds + existing resources)
    click.echo("[deployless] Running pre-flight checks...")
    try:
        pre_state = compile_project(stage=stage, dry_run=True, verbose=False)
    except ConfigError as e:
        click.echo(click.style("[deployless] Config failed — unresolved variables:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    pre_config = load_config()
    if stage:
        pre_config["stage"] = stage

    check_errors = run_checks(pre_state, pre_config)
    if check_errors:
        click.echo(click.style("[deployless] Pre-flight checks failed:\n", fg="red"))
        for err in check_errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    click.echo(click.style("[deployless] Pre-flight checks passed.", fg="green"))

    # Step 1.5: Domain certificate resolution
    _resolve_domain_certificate(pre_config)

    # Step 2: full build (with optional secret push)
    click.echo("[deployless] Building...")
    try:
        compile_project(stage=stage, verbose=verbose, push_secrets=push_secrets)
    except ConfigError as e:
        click.echo(click.style("[deployless] Config failed — unresolved variables:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    # Step 3: sam build
    click.echo("[deployless] Running sam build...")
    result = subprocess.run(["sam", "build"], check=False)
    if result.returncode != 0:
        click.echo(click.style("[deployless] sam build failed.", fg="red"))
        sys.exit(result.returncode)

    # Step 4: sam deploy (--guided auto-added on first deploy)
    sam_deploy_cmd = ["sam", "deploy"]
    if guided or is_first_deploy:
        sam_deploy_cmd.append("--guided")

    click.echo(f"[deployless] Running {' '.join(sam_deploy_cmd)}...")
    result = subprocess.run(sam_deploy_cmd, check=False)

    # Step 5: Post-deploy — show custom domain CNAME for external DNS users
    if result.returncode == 0:
        _show_domain_cname(pre_config)

    sys.exit(result.returncode)


def _show_domain_cname(config: dict) -> None:
    """After a successful deploy, show the CNAME the user needs to add for external DNS."""
    domain = config.get("api", {}).get("domain")
    if not domain or not domain.get("domain_name"):
        return
    if domain.get("route53"):
        return  # Route 53 handles DNS automatically

    domain_name = domain["domain_name"]
    endpoint_type = config.get("api", {}).get("endpoint_type", "REGIONAL")

    try:
        import boto3

        client = boto3.client("apigateway")
        resp = client.get_domain_name(domainName=domain_name)
        if endpoint_type.upper() == "EDGE":
            target = resp.get("distributionDomainName", "")
        else:
            target = resp.get("regionalDomainName", "")

        if target:
            click.echo(click.style(
                f"\n[deployless] Custom domain configured: {domain_name}",
                fg="green",
            ))
            click.echo(click.style(
                "[deployless] Add this CNAME record to your DNS provider:\n",
                fg="yellow",
            ))
            click.echo(f"  CNAME  {domain_name}  →  {target}")
            click.echo(click.style(
                "\n  Note: If using Cloudflare, set the proxy to 'DNS only' (grey cloud) for this record.\n",
                fg="yellow",
            ))
    except Exception:
        pass  # Best-effort — don't fail the deploy for this


@cli.command()
@click.option("-o", "--output", default="template.yaml", help="Template file to remove.")
def clean(output):
    """Remove generated files (.dist/ and template.yaml)."""
    import shutil
    root = Path.cwd()

    dist_dir = root / ".dist"
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
        click.echo(f"[deployless] Removed {dist_dir}")

    output_path = root / output
    if output_path.exists():
        output_path.unlink()
        click.echo(f"[deployless] Removed {output_path}")

    if not dist_dir.exists() and not output_path.exists():
        click.echo("[deployless] Nothing to clean.")


@cli.command()
def info():
    """Show detected project structure."""
    config = load_config()
    paths = config.get("paths", {})
    features = discover_features(Path.cwd(), paths.get("features", "app/features"))

    click.echo(f"\nProject  : {config['name']}")
    click.echo(f"Provider : {config['provider']}")
    click.echo(f"Stage    : {config['stage']}")
    click.echo(f"Runtime  : {config.get('globals', {}).get('runtime', 'python3.13')}")
    click.echo(f"\nFeatures ({len(features)}):")
    for f in features:
        click.echo(f"  - {f['name']}  ({f['routes_file']})")
    click.echo()


@cli.group()
def secrets():
    """Manage secrets in AWS SSM Parameter Store."""


@secrets.command(name="push")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--env-file", default=None, help="Path to .env file (overrides deployless.yaml).")
@click.option("-v", "--verbose", is_flag=True)
def secrets_push(stage, env_file, verbose):
    """Push SECRET_ variables from .env file to SSM Parameter Store."""
    config = load_config()
    if stage:
        config["stage"] = stage

    env_file_path = env_file or config.get("env_file")
    if not env_file_path:
        msg = "[deployless] No env_file configured. Set it in deployless.yaml or use --env-file."
        click.echo(click.style(msg, fg="red"))
        sys.exit(1)

    env_path = Path.cwd() / env_file_path
    if not env_path.exists():
        click.echo(click.style(f"[deployless] File not found: {env_file_path}", fg="red"))
        sys.exit(1)

    _, secret_vars = parse_env_file(env_path)
    if not secret_vars:
        click.echo("[deployless] No SECRET_ variables found in .env file.")
        return

    app_name = config.get("name", "deployless-app")
    secrets_kms = config.get("secrets_kms")

    click.echo(f"[deployless] Pushing {len(secret_vars)} secret(s) for '{app_name}'...")
    results = push_secrets(app_name, secret_vars, secrets_kms)
    for path, action in results:
        click.echo(f"  {action}: {path}")
    click.echo(click.style("[deployless] Done.", fg="green"))


@secrets.command(name="sync")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--env-file", default=None, help="Path to .env file (overrides deployless.yaml).")
@click.option("-y", "--yes", is_flag=True, help="Auto-confirm orphan deletion.")
@click.option("-v", "--verbose", is_flag=True)
def secrets_sync(stage, env_file, yes, verbose):
    """Push secrets and delete orphaned parameters from SSM."""
    config = load_config()
    if stage:
        config["stage"] = stage

    env_file_path = env_file or config.get("env_file")
    if not env_file_path:
        msg = "[deployless] No env_file configured. Set it in deployless.yaml or use --env-file."
        click.echo(click.style(msg, fg="red"))
        sys.exit(1)

    env_path = Path.cwd() / env_file_path
    if not env_path.exists():
        click.echo(click.style(f"[deployless] File not found: {env_file_path}", fg="red"))
        sys.exit(1)

    _, secret_vars = parse_env_file(env_path)
    app_name = config.get("name", "deployless-app")
    secrets_kms = config.get("secrets_kms")

    if not yes:
        click.confirm(
            f"This will push {len(secret_vars)} secret(s) and delete orphaned params for '{app_name}'. Continue?",
            abort=True,
        )

    click.echo(f"[deployless] Syncing secrets for '{app_name}'...")
    pushed, deleted = sync_secrets(app_name, secret_vars, secrets_kms)
    for path, action in pushed:
        click.echo(f"  {action}: {path}")
    for path in deleted:
        click.echo(click.style(f"  deleted orphan: {path}", fg="yellow"))
    click.echo(click.style("[deployless] Done.", fg="green"))


# Register validate command with correct name
cli.add_command(validate_cmd, name="validate")


def main():
    """Entry point registered in pyproject.toml under ``[project.scripts]``."""
    cli()


if __name__ == "__main__":
    main()
