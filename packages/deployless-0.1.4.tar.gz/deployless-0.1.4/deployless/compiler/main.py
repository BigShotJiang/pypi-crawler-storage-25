"""
Main compiler orchestrator.
Orchestrates: discovery → import → route extraction → validation → build → generate.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from deployless.adapters.flask import FlaskAdapter
from deployless.compiler.env_file import build_secret_env_vars, parse_env_file
from deployless.compiler.env_file import push_secrets as _push_secrets
from deployless.compiler.validator import validate
from deployless.core.config import load_config
from deployless.core.discovery import discover_features, import_module_from_file
from deployless.core.metadata import (
    _scan_feature_dir_resources,
    _scan_module_resources,
    get_registry,
    reset_registry,
    set_compiling_feature,
    set_feature_dirs,
)
from deployless.providers.aws.packager import (
    build_cron_package,
    build_feature_package,
    build_lambda_package,
    build_split_route_package,
)
from deployless.providers.aws.sam import generate_template

ADAPTERS = [FlaskAdapter()]


def _detect_adapter(module):
    """
    Return the first adapter that recognises *module*, or ``None`` if none match.

    Adapters are tried in the order they appear in ``ADAPTERS``.
    """
    for adapter in ADAPTERS:
        if adapter.detect(module):
            return adapter
    return None


def _find_feature_dir_for_cron(cron: dict, features_root: Path) -> Path | None:
    """Find which feature directory contains the cron's source file.

    Returns the feature subdirectory ``Path`` if the cron's module file
    resides inside *features_root*, or ``None`` for standalone crons.
    """
    cron_file = Path(cron["module_file"])
    try:
        cron_file.relative_to(features_root)
        # It's inside features/ — find the feature subdir
        parts = cron_file.relative_to(features_root).parts
        if parts:
            return features_root / parts[0]
    except ValueError:
        pass
    return None


def compile_project(
    project_root: str | None = None,
    stage: str | None = None,
    output: str = "template.yaml",
    dry_run: bool = False,
    verbose: bool = False,
    push_secrets: bool = False,
) -> dict:
    """Run the full compilation pipeline: load config, discover features, import
    modules, extract routes, auto-detect resources, validate, build ``.dist/``
    packages, and generate the SAM ``template.yaml``.

    Args:
        project_root: Path to the project root directory.  Defaults to ``cwd()``.
        stage: Override the deployment stage from ``deployless.yaml``.
        output: Output template file name (default ``"template.yaml"``).
        dry_run: When ``True`` validate only — do not write any files.
        verbose: Print progress details to stdout.
        push_secrets: Push ``SECRET_`` env vars to SSM Parameter Store.

    Returns:
        The compiled state dict containing features, crons, split routes, and lambdas.

    Raises:
        ValidationError: When one or more validation checks fail.
        ConfigError: When environment variable interpolation fails.
    """
    root = Path(project_root) if project_root else Path.cwd()

    # 1. Load config
    config = load_config(root)
    if stage:
        config["stage"] = stage

    paths = config.get("paths", {})
    features_rel = paths.get("features", "app/features")
    shared_rel = paths.get("shared", "app/shared")

    features_root = root / features_rel
    shared_dir = root / shared_rel
    dist_dir = root / ".dist"

    if verbose:
        print(f"[deployless] Project: {config['name']} | Stage: {config['stage']} | Provider: {config['provider']}")

    # 2. Discover features
    features = discover_features(str(root), features_rel)
    if verbose:
        print(f"[deployless] Features found: {[f['name'] for f in features]}")

    # 3. Import each feature's routes.py (sets DEPLOYLESS_RUNTIME so metadata registers)
    os.environ["DEPLOYLESS_RUNTIME"] = "compiler"
    reset_registry()

    # Add project root to sys.path so shared imports work
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    state: dict[str, Any] = {
        "features": {},
        "crons": [],
        "split_routes": [],
        "lambdas": [],
    }

    set_feature_dirs(features)

    for feature in features:
        module_name = f"deployless_feature_{feature['name']}_routes"
        set_compiling_feature(feature["name"])
        try:
            module = import_module_from_file(module_name, feature["routes_file"], root)
        except Exception as e:
            print(f"[deployless] ERROR importing {feature['name']}/routes.py: {e}")
            raise
        finally:
            set_compiling_feature(None)

        adapter = _detect_adapter(module)
        if adapter is None:
            if verbose:
                print(f"[deployless] WARNING: No framework adapter found for feature '{feature['name']}'. Skipping.")
            continue

        routes = adapter.extract_routes(module)

        # Get metadata registered by pc.configure() in this module
        registry = get_registry()
        feature_meta = registry["features"].get(
            feature["name"],
            {"config": {}, "resources": {}, "resource_permissions": {}},
        )

        # Auto-detect resources:
        # 1. Local: scan all modules inside the feature directory
        local_resources = _scan_feature_dir_resources(feature["dir"])

        # 2. Imported from shared: scan routes.py namespace, exclude locals
        local_ids = {id(r) for r in local_resources.values()}
        imported_resources = {}
        for key, res in _scan_module_resources(module).items():
            if id(res) not in local_ids:
                imported_resources[key] = res

        # Merge: auto-detected (crud) + manual overrides from configure()
        merged_resources = {}
        merged_permissions = {}

        for key, res in {**local_resources, **imported_resources}.items():
            merged_resources[key] = res
            merged_permissions[key] = "crud"

        # Manual overrides win — also remove auto-detected duplicates
        # (same object registered under a different key by pc.configure)
        manual_ids = {id(res) for res in feature_meta.get("resources", {}).values()}
        for key in [k for k, v in merged_resources.items() if id(v) in manual_ids]:
            del merged_resources[key]
            merged_permissions.pop(key, None)

        for key, res in feature_meta.get("resources", {}).items():
            merged_resources[key] = res
        for key, level in feature_meta.get("resource_permissions", {}).items():
            merged_permissions[key] = level

        # Tag split routes
        split_routes = [r for r in routes if r.get("split_config")]
        normal_routes = [r for r in routes if not r.get("split_config")]

        state["features"][feature["name"]] = {
            "config": feature_meta["config"],
            "resources": merged_resources,
            "resource_permissions": merged_permissions,
            "routes": normal_routes,
            "dir": feature["dir"],
            "routes_file": feature["routes_file"],
            "adapter": type(adapter).__name__,
        }

        for split in split_routes:
            split["feature"] = feature["name"]
            split["feature_dir"] = feature["dir"]
            state["split_routes"].append(split)

        if verbose:
            auto_count = len(merged_resources) - len(feature_meta.get("resources", {}))
            print(
                f"[deployless]   {feature['name']}: {len(normal_routes)} routes,"
                f" {len(split_routes)} split, {len(merged_resources)} resources"
                f" ({auto_count} auto-detected)"
            )

    # Collect crons from registry
    state["crons"] = get_registry()["crons"]
    if verbose and state["crons"]:
        print(f"[deployless] Crons: {[c['name'] for c in state['crons']]}")

    # Auto-detect resources for crons
    for cron_entry in state["crons"]:
        module_file = Path(cron_entry["module_file"]).resolve()
        for mod in sys.modules.values():
            mod_file = getattr(mod, "__file__", None)
            if mod_file and Path(mod_file).resolve() == module_file:
                cron_entry["resources"] = _scan_module_resources(mod)
                cron_entry["resource_permissions"] = {k: "crud" for k in cron_entry["resources"]}
                break
        else:
            cron_entry.setdefault("resources", {})
            cron_entry.setdefault("resource_permissions", {})

    # Collect standalone lambdas from registry
    state["lambdas"] = get_registry()["lambdas"]
    if verbose and state["lambdas"]:
        print(f"[deployless] Lambdas: {[lmb['name'] for lmb in state['lambdas']]}")

    # Auto-detect resources for standalone lambdas
    for lmb_entry in state["lambdas"]:
        module_file = Path(lmb_entry["module_file"]).resolve()
        for mod in sys.modules.values():
            mod_file = getattr(mod, "__file__", None)
            if mod_file and Path(mod_file).resolve() == module_file:
                lmb_entry["resources"] = _scan_module_resources(mod)
                lmb_entry["resource_permissions"] = {k: "crud" for k in lmb_entry["resources"]}
                break
        else:
            lmb_entry.setdefault("resources", {})
            lmb_entry.setdefault("resource_permissions", {})

    # 4. Validate
    validate(state, config)
    if verbose:
        print("[deployless] Validation passed.")

    # 4b. Process env_file if configured
    env_file_path = config.get("env_file")
    if env_file_path:
        env_file_full = root / env_file_path
        if not env_file_full.exists():
            from deployless.compiler.validator import ValidationError
            raise ValidationError([f"[E27] env_file '{env_file_path}' does not exist."])

        plain_vars, secret_vars = parse_env_file(env_file_full)

        # Validate SECRET_ vars have non-empty values
        empty_secrets = [k for k, v in secret_vars.items() if not v]
        if empty_secrets:
            from deployless.compiler.validator import ValidationError
            raise ValidationError([
                f"[E28] SECRET_ variable '{k}' has an empty value." for k in empty_secrets
            ])

        # Merge plain vars into global env
        if "env" not in config:
            config["env"] = {}
        config["env"].update(plain_vars)

        # Store secret env var references in config for template generation
        if secret_vars:
            app_name = config.get("name", "deployless-app")
            secret_env = build_secret_env_vars(app_name, secret_vars.keys())
            config["env"].update({k: v.to_reference() for k, v in secret_env.items()})

            if push_secrets and not dry_run:
                secrets_kms = config.get("secrets_kms")
                pushed = _push_secrets(app_name, secret_vars, secrets_kms)
                if verbose:
                    for path, action in pushed:
                        print(f"[deployless]   Secret {action}: {path}")

    if dry_run:
        print("[deployless] Dry run — no files written.")
        return state

    # 5. Build .dist/ packages
    dist_dir.mkdir(exist_ok=True)

    cors_raw = config.get("api", {}).get("cors")
    cors_config = cors_raw if isinstance(cors_raw, dict) else None
    init_app = config.get("init_app", [])

    app_init_file = root / "app" / "__init__.py"
    all_features_meta = [
        {
            "name": fname,
            "dir": fdata["dir"],
            "routes_file": fdata.get("routes_file"),
        }
        for fname, fdata in state["features"].items()
    ]

    for feature_name, feature_data in state["features"].items():
        adapter_name = feature_data.get("adapter", "FlaskAdapter")
        framework = "flask" if "Flask" in adapter_name else "fastapi"

        pkg = build_feature_package(
            feature_name=feature_name,
            feature_dir=feature_data["dir"],
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
            framework=framework,
            cors_config=cors_config,
            init_app=init_app,
            routes_file=feature_data.get("routes_file"),
            app_init_file=app_init_file if app_init_file.exists() else None,
            other_features=all_features_meta,
        )
        if verbose:
            print(f"[deployless]   Built: {pkg.relative_to(root)}")

    for split in state["split_routes"]:
        feature_name = split["feature"]
        feature_dir = split["feature_dir"]
        adapter_name = state["features"][feature_name].get("adapter", "FlaskAdapter")
        framework = "flask" if "Flask" in adapter_name else "fastapi"

        pkg = build_split_route_package(
            split=split,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
            framework=framework,
            cors_config=cors_config,
            init_app=init_app,
            routes_file=state["features"][feature_name].get("routes_file"),
            app_init_file=app_init_file if app_init_file.exists() else None,
            other_features=all_features_meta,
        )
        if verbose:
            print(f"[deployless]   Built split route: {pkg.relative_to(root)}")

    for cron in state["crons"]:
        feature_dir = _find_feature_dir_for_cron(cron, features_root)
        pkg = build_cron_package(
            cron=cron,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
        )
        if verbose:
            print(f"[deployless]   Built cron: {pkg.relative_to(root)}")

    for lmb in state["lambdas"]:
        feature_dir = _find_feature_dir_for_cron(lmb, features_root)  # same logic
        pkg = build_lambda_package(
            lmb=lmb,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
        )
        if verbose:
            print(f"[deployless]   Built lambda: {pkg.relative_to(root)}")

    # 6. Generate template.yaml
    template = generate_template(state, config)

    # 6b. Detect replacement-causing changes vs previous template
    output_path = root / output
    from deployless.compiler.replacement import check_replacements

    replacement_warnings = check_replacements(template, output_path)
    if replacement_warnings:
        from deployless.compiler.validator import ValidationError

        raise ValidationError(replacement_warnings)

    with open(output_path, "w") as f:
        yaml.dump(template, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    print(f"[deployless] Template generated: {output_path}")
    return state
