"""
Detect CloudFormation replacement-causing changes before deploy.

Compares the newly generated template against the previously written
``template.yaml`` and emits W-code warnings for property changes that
would force CloudFormation to *replace* a custom-named resource — an
operation that always fails.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

logger = logging.getLogger("deployless.compiler.replacement")

# ---------------------------------------------------------------------------
# Declarative registry: CFN type → list of dotted property paths whose
# change triggers a resource REPLACEMENT in CloudFormation.
# ---------------------------------------------------------------------------
REPLACEMENT_PROPERTIES: dict[str, list[str]] = {
    "AWS::DynamoDB::Table": [
        "Properties.TableName",
        "Properties.KeySchema",
    ],
    "AWS::S3::Bucket": [
        "Properties.BucketName",
    ],
    "AWS::SQS::Queue": [
        "Properties.QueueName",
        "Properties.FifoQueue",
    ],
    "AWS::KMS::Key": [
        "Properties.KeyUsage",
        "Properties.KeySpec",
    ],
    "AWS::SSM::Parameter": [
        "Properties.Name",
        "Properties.Type",
    ],
}

# Human-readable labels for the leaf property name.
_PROPERTY_LABELS: dict[str, str] = {
    "TableName": "table name",
    "KeySchema": "key schema (PK/SK)",
    "BucketName": "bucket name",
    "QueueName": "queue name",
    "FifoQueue": "FIFO flag",
    "KeyUsage": "key usage",
    "KeySpec": "key spec",
    "Name": "parameter name",
    "Type": "parameter type",
}


def _get_nested(d: Any, path: str) -> Any:
    """Resolve a dotted path (e.g. ``Properties.KeySchema``) into *d*."""
    for key in path.split("."):
        if not isinstance(d, dict):
            return None
        d = d.get(key)
    return d


def check_replacements(
    new_template: dict,
    old_template_path: Path,
) -> list[str]:
    """Compare *new_template* against the existing file at *old_template_path*.

    Returns a list of ``[W01]`` warning strings for every replacement-causing
    property change detected.  Returns an empty list when no old template
    exists (first build) or when nothing changed.
    """
    if not old_template_path.exists():
        return []

    try:
        with open(old_template_path) as f:
            old_template: dict | None = yaml.safe_load(f)
    except Exception:
        logger.debug("Could not parse previous template; skipping replacement check.")
        return []

    if not isinstance(old_template, dict):
        return []

    old_resources = old_template.get("Resources", {})
    new_resources = new_template.get("Resources", {})
    warnings: list[str] = []

    for logical_id, new_resource in new_resources.items():
        if logical_id not in old_resources:
            continue  # new resource — nothing to compare

        old_resource = old_resources[logical_id]
        resource_type = new_resource.get("Type", "")

        if resource_type != old_resource.get("Type", ""):
            continue  # type changed entirely — different situation

        paths = REPLACEMENT_PROPERTIES.get(resource_type)
        if not paths:
            continue

        for path in paths:
            old_val = _get_nested(old_resource, path)
            new_val = _get_nested(new_resource, path)

            if old_val is None and new_val is None:
                continue
            if old_val == new_val:
                continue

            leaf = path.rsplit(".", 1)[-1]
            label = _PROPERTY_LABELS.get(leaf, leaf)
            warnings.append(
                f"[W01] '{logical_id}' ({resource_type}): "
                f"changing '{label}' requires resource REPLACEMENT.\n"
                f"       Deploy will fail because this resource has a custom name.\n"
                f"       To proceed: delete the resource manually or use a new name."
            )

    return warnings
