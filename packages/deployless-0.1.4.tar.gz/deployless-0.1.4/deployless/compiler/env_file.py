"""
.env file parser and secrets management for deployless.

Parses .env files, splits plain vars from SECRET_ prefixed vars,
and manages SSM SecureString parameters for secrets.
"""
import logging
import re

from deployless.providers.aws.resources.ssm import SSMParam

logger = logging.getLogger("deployless.compiler.env_file")


def parse_env_file(path):
    """
    Parse a .env file into (plain_vars, secret_vars).

    - Lines starting with # or empty lines are skipped
    - SECRET_ prefix vars go to secret_vars (prefix stripped from key)
    - Values can be quoted with single or double quotes

    Returns:
        (plain_vars: dict, secret_vars: dict)
    """
    plain_vars = {}
    secret_vars = {}

    with open(path) as f:
        for line_num, raw_line in enumerate(f, 1):
            line = raw_line.strip()

            if not line or line.startswith("#"):
                continue

            if "=" not in line:
                logger.warning("Line %d: skipping (no '=' found): %s", line_num, line)
                continue

            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()

            if not key:
                continue

            # Strip surrounding quotes
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                value = value[1:-1]

            if key.startswith("SECRET_"):
                secret_vars[key] = value
            else:
                plain_vars[key] = value

    return plain_vars, secret_vars


def _ssm_path(app_name, var_name):
    """Build SSM parameter path: /{app_name}/{var_name}."""
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '-', app_name).lower()
    safe_var = var_name.upper()
    return f"/{safe_name}/{safe_var}"


def _get_kms_key_id(secrets_kms):
    """Resolve secrets_kms config to a KMS key ID string (or None)."""
    if secrets_kms is None:
        return None
    if hasattr(secrets_kms, 'alias'):
        alias = secrets_kms.alias
        return alias if alias.startswith("alias/") else f"alias/{alias}"
    return str(secrets_kms)


def push_secrets(app_name, secret_vars, secrets_kms=None):
    """
    Create/update SSM SecureString parameters for each secret.
    Returns list of (path, "created"|"updated") tuples.
    """
    import boto3

    if not secret_vars:
        return []

    ssm = boto3.client("ssm")
    _get_kms_key_id(secrets_kms)
    results = []

    for var_name, value in sorted(secret_vars.items()):
        path = _ssm_path(app_name, var_name)
        kwargs = {
            "Name": path,
            "Value": value,
            "Type": "String",
            "Overwrite": True,
        }

        try:
            ssm.get_parameter(Name=path, WithDecryption=False)
            action = "updated"
        except ssm.exceptions.ParameterNotFound:
            action = "created"

        ssm.put_parameter(**kwargs)
        logger.info("[SECRET] %s %s: %s", action.upper(), var_name, path)
        results.append((path, action))

    return results


def sync_secrets(app_name, secret_vars, secrets_kms=None):
    """
    Push secrets + detect and delete orphaned params under /{app_name}/.
    Returns (pushed: list, deleted: list).
    """
    import boto3

    pushed = push_secrets(app_name, secret_vars, secrets_kms)

    ssm = boto3.client("ssm")
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '-', app_name).lower()
    prefix = f"/{safe_name}/"

    expected_paths = {_ssm_path(app_name, var_name) for var_name in secret_vars}

    deleted = []
    try:
        paginator = ssm.get_paginator("describe_parameters")
        for page in paginator.paginate(
            ParameterFilters=[{"Key": "Name", "Option": "BeginsWith", "Values": [prefix]}]
        ):
            for param in page.get("Parameters", []):
                param_name = param["Name"]
                if param_name not in expected_paths:
                    ssm.delete_parameter(Name=param_name)
                    logger.info("[SECRET] DELETED orphan: %s", param_name)
                    deleted.append(param_name)
    except Exception as e:
        logger.warning("Could not check for orphaned secrets: %s", e)

    return pushed, deleted


def build_secret_env_vars(app_name, secret_var_names):
    """
    Build env var dict mapping secret var names to SSMParam references.
    Returns {VAR_NAME: SSMParam("/app/VAR", secure=True)} dict.
    """
    env_vars = {}
    for var_name in secret_var_names:
        path = _ssm_path(app_name, var_name)
        env_vars[var_name] = SSMParam(path, secure=False)
    return env_vars
