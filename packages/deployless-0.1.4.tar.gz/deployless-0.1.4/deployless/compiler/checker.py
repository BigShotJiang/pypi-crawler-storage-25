"""
Pre-flight checks for deployless — run before build/deploy.

All checks are fail-slow (every check runs regardless of previous failures).
Checks are split into two groups:
  - Local: no AWS calls needed (env vars, SAM CLI)
  - AWS:   require credentials (identity, existing resources)
"""
from __future__ import annotations

import subprocess

# Official AWS Lambda reserved environment variable names — exact match only.
# AWS does NOT use prefix matching: AWS_REGION is reserved, AWS_REGION_CUSTOM is not.
# Source: https://docs.aws.amazon.com/lambda/latest/dg/configuration-envvars.html
LAMBDA_RESERVED_ENV_VARS: frozenset[str] = frozenset({
    "_HANDLER",
    "_X_AMZN_TRACE_ID",
    "AWS_DEFAULT_REGION",
    "AWS_REGION",
    "AWS_EXECUTION_ENV",
    "AWS_LAMBDA_FUNCTION_NAME",
    "AWS_LAMBDA_FUNCTION_MEMORY_SIZE",
    "AWS_LAMBDA_FUNCTION_VERSION",
    "AWS_LAMBDA_INITIALIZATION_TYPE",
    "AWS_LAMBDA_LOG_GROUP_NAME",
    "AWS_LAMBDA_LOG_STREAM_NAME",
    "AWS_ACCESS_KEY",
    "AWS_ACCESS_KEY_ID",
    "AWS_SECRET_ACCESS_KEY",
    "AWS_SESSION_TOKEN",
    "AWS_LAMBDA_RUNTIME_API",
    "LAMBDA_TASK_ROOT",
    "LAMBDA_RUNTIME_DIR",
    "AWS_LAMBDA_MAX_CONCURRENCY",
})


def check_reserved_env_vars(state: dict, config: dict) -> list[str]:
    """
    Check every env var name (global, per-feature, cron, lambda) against
    the list of names reserved by the AWS Lambda runtime.

    AWS rejects these at deploy time with "Reserved environment variable".
    Note: AWS uses exact-name matching — AWS_REGION is reserved but
    AWS_REGION_CUSTOM is not.
    """
    errors = []

    def _check(scope: str, env: dict):
        for key in env:
            if key in LAMBDA_RESERVED_ENV_VARS:
                errors.append(
                    f"[C01] {scope}: env var '{key}' is reserved by AWS Lambda "
                    f"and will cause a deployment error. "
                    f"See: https://docs.aws.amazon.com/lambda/latest/dg/configuration-envvars.html"
                )

    _check("Global env", config.get("env", {}))

    for feature_name, feature_data in state.get("features", {}).items():
        _check(f"Feature '{feature_name}'", feature_data.get("config", {}).get("env", {}))

    for cron in state.get("crons", []):
        _check(f"Cron '{cron['name']}'", cron.get("env", {}))

    for lmb in state.get("lambdas", []):
        _check(f"Lambda '{lmb['name']}'", lmb.get("env", {}))

    return errors


def check_sam_installed() -> list[str]:
    """Verify that the AWS SAM CLI is installed and accessible."""
    try:
        result = subprocess.run(
            ["sam", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return ["[C02] SAM CLI returned an error. Try running: sam --version"]
    except FileNotFoundError:
        return [
            "[C02] SAM CLI not found. Install it from: "
            "https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html"
        ]
    except subprocess.TimeoutExpired:
        return ["[C02] SAM CLI check timed out."]
    return []


def check_aws_credentials() -> list[str]:
    """
    Verify that AWS credentials are configured and functional
    by calling STS GetCallerIdentity.
    """
    try:
        import boto3
        from botocore.exceptions import ClientError, NoCredentialsError
    except ImportError:
        return ["[C03] boto3 is not installed. Run: pip install boto3"]

    try:
        boto3.client("sts").get_caller_identity()
        return []
    except NoCredentialsError:
        return [
            "[C03] AWS credentials not configured. "
            "Run: aws configure  — or set AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY."
        ]
    except ClientError as e:
        return [f"[C03] AWS credentials error: {e.response['Error']['Message']}"]
    except Exception as e:
        return [f"[C03] Could not verify AWS credentials: {e}"]


def run_checks(state: dict, config: dict) -> list[str]:
    """
    Run all pre-flight checks and return a flat list of error strings.
    An empty list means every check passed.

    Checks run in order:
      C01 — Reserved env var names
      C02 — SAM CLI installed
      C03 — AWS credentials configured
      existing resources — resources marked existing=True actually exist in AWS
    """
    errors = []
    errors += check_reserved_env_vars(state, config)
    errors += check_sam_installed()
    errors += check_aws_credentials()

    from deployless.compiler.validator import check_existing_resources
    errors += check_existing_resources(state)

    return errors
