"""Wake-path Lambda: email send via SES relay.

Sends emails through Amazon SES for cloud-only operations (notifications,
digests, cross-device alerts). Part of the local-authoritative + Lambda
batch-wake architecture (ADR-006).
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

SES_CONFIGURATION_SET = os.environ.get("SES_CONFIGURATION_SET", "")
SENDER_DOMAIN = os.environ.get("SENDER_DOMAIN", "workweaver.ai")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

_ses = boto3.client("sesv2", region_name=AWS_REGION)

# Per-tenant rate limiting (max emails per minute)
_RATE_LIMIT = int(os.environ.get("WAKE_EMAIL_RATE_LIMIT", "10"))
_rate_counters: dict[str, list[float]] = {}

_ALLOWED_ORIGINS = {
    "https://workweaver.ai",
    "https://www.workweaver.ai",
    "https://admin.workweaver.ai",
}


def _cors_headers(origin: str = "") -> dict[str, str]:
    allowed = origin if origin in _ALLOWED_ORIGINS else ""
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowed,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400",
    }


def _response(status_code: int, body: dict, origin: str = "") -> dict[str, Any]:
    return {"statusCode": status_code, "headers": _cors_headers(origin), "body": json.dumps(body)}


def _check_rate_limit(tenant_id: str) -> bool:
    now = time.time()
    window = 60.0
    timestamps = _rate_counters.get(tenant_id, [])
    timestamps = [t for t in timestamps if now - t < window]
    if len(timestamps) >= _RATE_LIMIT:
        _rate_counters[tenant_id] = timestamps
        return False
    timestamps.append(now)
    _rate_counters[tenant_id] = timestamps
    return True


def send_email(
    tenant_id: str,
    to: str,
    subject: str,
    body_text: str,
    body_html: str | None = None,
) -> dict[str, Any]:
    """Send an email via SESv2 with per-tenant rate limiting."""
    if not _check_rate_limit(tenant_id):
        return {"sent": False, "error": "rate_limited"}

    sender = f"Workweaver <noreply@{SENDER_DOMAIN}>"
    destination = {"ToAddresses": [to]}
    content: dict[str, Any] = {
        "Simple": {
            "Subject": {"Data": subject},
            "Body": {"Text": {"Data": body_text}},
        }
    }
    if body_html:
        content["Simple"]["Body"]["Html"] = {"Data": body_html}

    kwargs: dict[str, Any] = {
        "FromEmailAddress": sender,
        "Destination": destination,
        "Content": content,
    }
    if SES_CONFIGURATION_SET:
        kwargs["ConfigurationSetName"] = SES_CONFIGURATION_SET

    try:
        resp = _ses.send_email(**kwargs)
    except ClientError as exc:
        logger.error("email_send.ses_error tenant=%s: %s", tenant_id, exc)
        return {"sent": False, "error": "ses_error"}

    message_id = resp.get("MessageId", "")
    logger.info("email_send.sent tenant=%s message_id=%s", tenant_id, message_id)
    return {"sent": True, "message_id": message_id}


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    headers = event.get("headers") or {}
    origin = str(headers.get("origin") or headers.get("Origin") or "").strip()

    http_method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
    )
    if http_method == "OPTIONS":
        return {"statusCode": 200, "headers": _cors_headers(origin), "body": ""}

    body_str = event.get("body", "{}")
    body = json.loads(body_str) if isinstance(body_str, str) else body_str

    tenant_id = body.get("tenant_id", "").strip()
    to = body.get("to", "").strip()
    subject = body.get("subject", "").strip()
    body_text = body.get("body_text", "").strip()
    body_html = body.get("body_html")

    if not tenant_id:
        return _response(400, {"error": "missing_tenant_id"}, origin)
    if not to:
        return _response(400, {"error": "missing_recipient"}, origin)
    if not subject or not body_text:
        return _response(400, {"error": "missing_subject_or_body"}, origin)

    result = send_email(tenant_id, to, subject, body_text, body_html)
    if not result["sent"]:
        status = 429 if result["error"] == "rate_limited" else 500
        return _response(status, result, origin)

    return _response(200, result, origin)
