"""Thin Lambda adapter for the shared schedule-dispatch runtime."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from apps.backend.services import schedule_dispatch_runtime as runtime

_dispatch_service = runtime.dispatch_service
_schedule_service = runtime.schedule_service
_list_active_schedules = runtime.list_active_schedules
_extract_tenant_id = runtime.extract_tenant_id
_minute_slot = runtime.minute_slot
_due_recurring_fire_at = runtime.due_recurring_fire_at
_is_due_recurring = runtime.is_due_recurring
_due_context = runtime.due_context
_deterministic_dispatch_id = runtime.deterministic_dispatch_id


def _enqueue_dispatch(
    *,
    tenant_id: str,
    agent_id: str,
    schedule_id: str,
    schedule_type: str,
    due_slot: str,
    due_at: str,
) -> bool:
    return runtime.enqueue_dispatch(
        tenant_id=tenant_id,
        agent_id=agent_id,
        schedule_type=schedule_type,
        schedule_id=schedule_id,
        due_slot=due_slot,
        due_at=due_at,
        dispatch_service_fn=_dispatch_service,
    )


def _persist_schedule_progress(
    schedule: dict[str, Any],
    *,
    tenant_id: str,
    schedule_id: str,
    due_at: str,
    processed_at: datetime,
) -> None:
    runtime.persist_schedule_progress(
        schedule=schedule,
        tenant_id=tenant_id,
        schedule_id=schedule_id,
        due_at=due_at,
        processed_at=processed_at,
        schedule_service_fn=_schedule_service,
    )


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """EventBridge-triggered schedule runner."""
    _ = event, context
    summary = runtime.run_schedule_dispatch_cycle(
        list_active_schedules_fn=_list_active_schedules,
        extract_tenant_id_fn=_extract_tenant_id,
        due_context_fn=_due_context,
        enqueue_dispatch_fn=_enqueue_dispatch,
        persist_schedule_progress_fn=_persist_schedule_progress,
    )
    return {
        "statusCode": int(summary.get("statusCode", 200)),
        "body": json.dumps(summary.get("body", {})),
    }
