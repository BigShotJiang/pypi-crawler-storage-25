"""
Agent Discovery Module for LiveKit Cloud

This module provides functions to dynamically discover and select available agents
from LiveKit Cloud, eliminating the need for hardcoded agent IDs.

Benefits:
- No hardcoded agent IDs
- Automatic agent selection from available agents
- Validation of agent health before dispatch
- Resilient to agent ID changes

Usage:
    from agent_discovery import get_available_agents, select_first_available_agent

    # Get all available agents
    agents = get_available_agents(livekit_url, api_key, api_secret)

    # Select first available (running) agent
    agent = select_first_available_agent(agents)

    if agent:
        print(f"Using agent: {agent['id']}")
    else:
        print("No available agents found")
"""

import asyncio
import logging

from livekit import api
from livekit.api import ListAgentsRequest

logger = logging.getLogger(__name__)


async def _list_agents_async(
    livekit_url: str,
    api_key: str,
    api_secret: str,
) -> list[dict]:
    """
    List all agents from LiveKit Cloud (async implementation).

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret

    Returns:
        List of agent dictionaries with keys: id, name, status, replicas, region
    """
    try:
        async with api.LiveKitAPI(livekit_url, api_key, api_secret) as lkapi:
            # List agents using the agent service
            response = await lkapi.agent_client.list_agents(ListAgentsRequest())

            agents = []
            for agent in response.agents:
                agents.append(
                    {
                        "id": agent.id,
                        "name": agent.agent_name if hasattr(agent, "agent_name") else agent.id,
                        "status": agent.state if hasattr(agent, "state") else "unknown",
                        "replicas": agent.replicas if hasattr(agent, "replicas") else 0,
                        "region": agent.region if hasattr(agent, "region") else "unknown",
                    }
                )

            return agents

    except Exception as e:
        logger.error("Error listing agents from LiveKit Cloud: %s", e)
        return []


def list_agents(
    livekit_url: str,
    api_key: str,
    api_secret: str,
) -> list[dict]:
    """
    List all agents from LiveKit Cloud (synchronous wrapper).

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret

    Returns:
        List of agent dictionaries with keys: id, name, status, replicas, region
    """
    try:
        return asyncio.run(
            _list_agents_async(
                livekit_url=livekit_url,
                api_key=api_key,
                api_secret=api_secret,
            )
        )
    except Exception as e:
        logger.error("Error in list_agents: %s", e)
        return []


def get_available_agents(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    require_running: bool = True,
) -> list[dict]:
    """
    Get list of available agents from LiveKit Cloud.

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        require_running: If True, only return agents with status "running"
                        If False, return all agents regardless of status

    Returns:
        List of available agent dictionaries
    """
    agents = list_agents(livekit_url, api_key, api_secret)

    if require_running:
        # Filter to only running agents with at least 1 replica
        agents = [agent for agent in agents if agent.get("status") == "running" and agent.get("replicas", 0) > 0]

    return agents


def select_first_available_agent(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    fallback_agent_id: str | None = None,
) -> str | None:
    """
    Select the first available agent from LiveKit Cloud.

    This function:
    1. Fetches all running agents from LiveKit Cloud
    2. Returns the first available agent's NAME (for dispatch routing)
    3. Falls back to fallback_agent_id if no agents available

    IMPORTANT: Returns agent NAME (not agent ID) because dispatch API requires agent_name

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        fallback_agent_id: Optional fallback agent NAME if no agents available

    Returns:
        Agent NAME string if available, None otherwise
    """
    agents = get_available_agents(
        livekit_url=livekit_url,
        api_key=api_key,
        api_secret=api_secret,
        require_running=True,
    )

    if agents and len(agents) > 0:
        # Return first available agent's NAME (not ID)
        agent = agents[0]
        logger.info(
            "Auto-selected agent: %s (id: %s, status: %s)",
            agent["name"],
            agent["id"],
            agent["status"],
        )
        return agent["name"]  # Return NAME for dispatch routing

    # Fallback to default agent NAME if provided
    if fallback_agent_id:
        logger.warning("No running agents found, using fallback: %s", fallback_agent_id)
        return fallback_agent_id

    logger.warning("No available agents found and no fallback provided")
    return None


def validate_agent_exists(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    agent_id: str,
) -> bool:
    """
    Validate that an agent exists in LiveKit Cloud.

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        agent_id: Agent ID to validate

    Returns:
        True if agent exists, False otherwise
    """
    agents = list_agents(livekit_url, api_key, api_secret)

    for agent in agents:
        if agent.get("id") == agent_id or agent.get("name") == agent_id:
            logger.debug("Agent %s found (status: %s)", agent_id, agent.get("status"))
            return True

    logger.warning("Agent %s not found in LiveKit Cloud", agent_id)
    return False
