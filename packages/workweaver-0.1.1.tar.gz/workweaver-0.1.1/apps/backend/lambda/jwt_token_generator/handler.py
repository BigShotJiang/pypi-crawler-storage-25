from apps.backend.config.table_names import resolve_table
from apps.backend.utils.b64url import b64url_decode, b64url_encode
"""
JWT Token Generator for LiveKit

This Lambda function generates JWT tokens for LiveKit room access.
Tokens are signed with RS256 (RSA signature) and include:
- Room name (prefixed with tenant_id)
- Participant name
- Metadata (tenant_id, user_id)
- Expiration (24 hours)

Usage:
    POST /jwt/livekit-token
    {
        "room_name": "tenant-123:room-abc",
        "participant_name": "user-456",
        "metadata": {
            "tenant_id": "tenant-123",
            "user_id": "user-456"
        }
    }

    Response:
    {
        "token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
        "room_url": "wss://livekit.workweaver.com"
    }

Reference:
    - TASK-20250101-003: Deploy Self-Hosted LiveKit
    - LiveKit Docs: https://docs.livekit.io/server-api/rest/
"""

import asyncio
import json
import logging
import os
import time
import hashlib
import hmac
import uuid
import aiohttp
import boto3
from botocore.exceptions import ClientError
from datetime import timedelta
from typing import Any

logger = logging.getLogger(__name__)
from livekit.api import (
    AccessToken,
    VideoGrants,
    LiveKitAPI,
    CreateAgentDispatchRequest,
    CreateRoomRequest,
    DeleteRoomRequest,
    ListParticipantsRequest,
)

# Configuration
# Security: LIVEKIT_API_KEY / LIVEKIT_API_SECRET must be fetched from Secrets Manager only.
# Never accept credentials via environment variables — they leak into Lambda logs and CloudWatch.
LIVEKIT_ROOM_URL = os.environ.get("LIVEKIT_ROOM_URL", "wss://workweaver-prod-5ny6zwt7.livekit.cloud")
TOKEN_EXPIRATION = int(os.environ.get("TOKEN_EXPIRATION", "86400"))  # 24 hours

# Agent Configuration
# IMPORTANT: Use agent NAME (for dispatch routing), not agent ID
# agent_id: CA_vvRy9FQVWU7s (system-assigned, immutable)
# agent_name: workweaver-xai-agent (human-readable, used for dispatch)
DEFAULT_AGENT_NAME = os.environ.get("DEFAULT_AGENT_NAME", "workweaver-xai-agent")
DISPATCH_TASK_TIMEOUT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_TASK_TIMEOUT_SECONDS", "3.2"))
AGENT_READY_WAIT_SECONDS = float(os.environ.get("LIVEKIT_AGENT_READY_WAIT_SECONDS", "1.2"))
AGENT_POLL_INTERVAL_SECONDS = float(os.environ.get("LIVEKIT_AGENT_POLL_INTERVAL_SECONDS", "0.2"))
DISPATCH_RUNNING_WAIT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_RUNNING_WAIT_SECONDS", "2.4"))
MIN_DISPATCH_TIMEOUT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_MIN_TIMEOUT_SECONDS", "12.0"))
ALLOW_FALLBACK_FOR_EXPLICIT_AGENT = os.environ.get(
    "LIVEKIT_AGENT_ALLOW_FALLBACK_FOR_EXPLICIT",
    "0",
).strip().lower() in ("1", "true", "yes")

# AWS Secrets Manager (for LiveKit Cloud credentials)
# Path convention: /workweaver/livekit/* (no env qualifier — AWS IS production)
SECRET_IDS = {
    "livekit_url": os.environ.get("LIVEKIT_URL_SECRET", "/workweaver/livekit/url"),
    "livekit_api_key": os.environ.get("LIVEKIT_API_KEY_SECRET", "/workweaver/livekit/api_key"),
    "livekit_api_secret": os.environ.get("LIVEKIT_API_SECRET_SECRET", "/workweaver/livekit/api_secret"),
}

# DynamoDB configuration (for tenant configuration)
# Region defaults to us-east-1
DYNAMODB_TABLE = resolve_table("runtime_state", env_var="DYNAMODB_TABLE", default_short_name="state")
DYNAMODB_REGION = os.environ.get("DYNAMODB_REGION", "us-east-1")

# L7: Lambda init-phase validation — fail fast if required secret names are missing.
# This catches misconfigured deployments at cold-start rather than at request time.
_REQUIRED_SECRET_VARS = ("LIVEKIT_URL_SECRET", "LIVEKIT_API_KEY_SECRET", "LIVEKIT_API_SECRET_SECRET")
_missing_secrets = [v for v in _REQUIRED_SECRET_VARS if not os.environ.get(v)]
if _missing_secrets:
    # Missing env vars means we fall back to default path names (acceptable for dev).
    # Log a warning so CloudWatch surfaces it without crashing on a valid dev deployment.
    logger.warning(
        "L7: Secret path env vars not explicitly set — using defaults: %s. "
        "Set these in Lambda environment for explicit secret path control.",
        ", ".join(_missing_secrets),
    )

# Cached credentials (for Lambda container reuse)
_cached_credentials = {}

# Initialize boto3 clients
# IMPORTANT: Use us-east-1 region for all AWS resources
_secrets_client = boto3.client("secretsmanager", region_name="us-east-1")
_dynamodb_client = boto3.resource("dynamodb", region_name=DYNAMODB_REGION)

ZARA_ACCESS_TOKEN_ISSUER = os.environ.get("ZARA_ACCESS_TOKEN_ISSUER", "workweaver")
ZARA_ACCESS_TOKEN_AUDIENCE = os.environ.get("ZARA_ACCESS_TOKEN_AUDIENCE", "zara_demo")
_ZARA_ACCESS_KEY_CONTEXT = b"workweaver-zara-access-v1"




def _derive_zara_access_key(api_secret: str) -> bytes:
    return hmac.new(str(api_secret).encode("utf-8"), _ZARA_ACCESS_KEY_CONTEXT, hashlib.sha256).digest()


def _verify_zara_access_token(token: str, api_secret: str) -> dict:
    raw = str(token or "").strip()
    if not raw:
        raise ValueError("missing token")

    parts = raw.split(".")
    if len(parts) != 3:
        raise ValueError("invalid token format")
    header_b64, claims_b64, sig_b64 = parts

    try:
        header = json.loads(b64url_decode(header_b64).decode("utf-8"))
        claims = json.loads(b64url_decode(claims_b64).decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as e:
        raise ValueError("invalid token encoding") from e

    if not isinstance(header, dict) or header.get("alg") != "HS256":
        raise ValueError("unsupported token algorithm")
    if not isinstance(claims, dict):
        raise ValueError("invalid token claims")

    if str(claims.get("iss") or "") != ZARA_ACCESS_TOKEN_ISSUER:
        raise ValueError("invalid token issuer")
    if str(claims.get("aud") or "") != ZARA_ACCESS_TOKEN_AUDIENCE:
        raise ValueError("invalid token audience")

    exp = int(claims.get("exp") or 0)
    if exp <= 0 or int(time.time()) >= exp:
        raise ValueError("token expired")

    signing_input = f"{header_b64}.{claims_b64}".encode()
    key = _derive_zara_access_key(api_secret)
    expected_sig = b64url_encode(hmac.new(key, signing_input, hashlib.sha256).digest())
    if not hmac.compare_digest(str(sig_b64 or ""), expected_sig):
        raise ValueError("invalid token signature")

    return claims


def _env_agent_fallbacks() -> tuple[str, ...]:
    raw = os.environ.get("LIVEKIT_AGENT_FALLBACKS", "")
    seen = set()
    ordered = []
    for item in raw.split(","):
        candidate = str(item or "").strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        ordered.append(candidate)
    return tuple(ordered)


AGENT_FALLBACKS = _env_agent_fallbacks()


def _dispatch_timeout_seconds() -> float:
    # Keep timeout >= internal poll windows so dispatch tasks are not cancelled mid-cleanup.
    return max(
        MIN_DISPATCH_TIMEOUT_SECONDS,
        0.5,
        DISPATCH_TASK_TIMEOUT_SECONDS,
        DISPATCH_RUNNING_WAIT_SECONDS + AGENT_READY_WAIT_SECONDS + 0.6,
    )


def get_livekit_credentials() -> tuple[str, str, str]:
    """Get LiveKit Cloud credentials from AWS Secrets Manager (/workweaver/livekit/*)."""
    global _cached_credentials

    if _cached_credentials:
        return (
            _cached_credentials["url"],
            _cached_credentials["api_key"],
            _cached_credentials["api_secret"],
        )

    try:
        url = _secrets_client.get_secret_value(SecretId=SECRET_IDS["livekit_url"])["SecretString"]
        api_key = _secrets_client.get_secret_value(SecretId=SECRET_IDS["livekit_api_key"])["SecretString"]
        api_secret = _secrets_client.get_secret_value(SecretId=SECRET_IDS["livekit_api_secret"])["SecretString"]

        _cached_credentials = {"url": url, "api_key": api_key, "api_secret": api_secret}
        return url, api_key, api_secret

    except ClientError as e:
        logger.error(f"Failed to fetch LiveKit credentials from Secrets Manager: {e}")
        raise RuntimeError(
            "LiveKit credentials unavailable. Check IAM permissions and secret names "
            f"({', '.join(SECRET_IDS.values())})."
        ) from e


def get_tenant_config(tenant_id: str) -> dict[str, Any]:
    """
    Get tenant configuration from DynamoDB.

    Tenant configuration includes:
    - agent_instructions: Custom instructions for the voice agent
    - voice: Voice model to use (default: 'ara')
    - language: Language setting
    - business_context: Industry-specific context

    DynamoDB pattern: TENANT#<id> / PROFILE

    Args:
        tenant_id: Tenant ID

    Returns:
        Dictionary with tenant configuration (defaults if not found)
    """
    try:
        table = _dynamodb_client.Table(DYNAMODB_TABLE)

        # Query tenant profile: pk=TENANT#<id>, sk=PROFILE
        response = table.get_item(Key={"pk": f"TENANT#{tenant_id}", "sk": "PROFILE"})

        if "Item" in response:
            logger.info(f"Found tenant config for {tenant_id}")
            return response["Item"].get("config", {})

        # Return default config if not found
        logger.info(f"Tenant {tenant_id} not found, using default config")
        return get_default_tenant_config()

    except Exception as e:
        logger.warning(f"Failed to fetch tenant config for {tenant_id}: {e}")
        return get_default_tenant_config()


def get_default_tenant_config() -> dict[str, Any]:
    """
    Get default tenant configuration.

    Returns:
        Default configuration for tenants
    """
    return {
        "agent_instructions": (
            "You are Zara, an AI agent for Workweaver, built by Bitfoundry AI. "
            "You speak like a genuinely helpful human: warm, calm, and never pushy. "
            "Never identify yourself as Grok, xAI, or the underlying model. "
            "Do not interrupt the human. If they interrupt you, stop immediately and listen, then respond. "
            "Keep voice responses concise (2-3 sentences) and ask one clear question at a time. "
            "Open with exactly: 'Hi, I'm Zara from Workweaver. I'm here to help with business operations. How can I help today?' then pause and wait. "
            "Default to clear Indian English; if the user code-switches, naturally adapt into Hinglish (Hindi+English) or Tanglish (Tamil+English) without caricature."
        ),
        "voice": "Ara",  # xAI Grok voice model
        "language": "en",
        "business_context": "general",
    }


_ALLOWED_ORIGINS = {
    "https://workweaver.ai",
    "https://www.workweaver.ai",
    "https://admin.workweaver.ai",
    "https://infra.workweaver.ai",
}
_DEV_ORIGINS = {
    "http://localhost:3000",
    "http://localhost:3001",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:3001",
}


def create_cors_headers(origin: str = "") -> dict[str, str]:
    """
    Create CORS headers for Lambda responses.

    Args:
        origin: Request origin to validate against allowlist.

    Returns:
        Dictionary of CORS headers
    """
    allowed_origin = ""
    if origin in _ALLOWED_ORIGINS:
        allowed_origin = origin
    elif origin in _DEV_ORIGINS:
        allowed_origin = origin
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowed_origin,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400",  # 24 hours
    }


def create_jwt_token(
    api_key: str,
    api_secret: str,
    room_name: str,
    identity: str,
    metadata: str = "",
    expiration: int = TOKEN_EXPIRATION,
) -> str:
    """
    Create JWT token for LiveKit room access.

    Args:
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        room_name: Name of the room
        identity: Participant identity
        metadata: Participant metadata (JSON string)
        expiration: Token expiration time (seconds)

    Returns:
        JWT token string
    """
    # Create token with video grants
    token = (
        AccessToken(api_key, api_secret)
        .with_identity(identity)
        .with_grants(VideoGrants(room_join=True, room=room_name))
        .with_metadata(metadata)
        .with_ttl(timedelta(seconds=expiration))
    )

    return token.to_jwt()


async def _dispatch_agent_to_room_async(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
    requested_agent_name: str,
    participant_name: str,
    metadata: str = "",
) -> tuple[str, bool, bool]:
    """
    Async function to dispatch agent to room using LiveKit API.

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        room_name: Name of the room
        requested_agent_name: Preferred agent name to dispatch
        participant_name: Local browser participant identity
        metadata: Optional metadata for the dispatch

    Returns:
        Tuple of (resolved_agent_name, dispatch_success, agent_ready_hint)
    """
    # Dispatch should be fast and resilient: treat a successful `create_dispatch` as
    # "dispatch_success" even if the agent has not joined yet. The browser UI can
    # wait for the agent to appear via normal room events.
    #
    # IMPORTANT: Do not delete dispatches just because the agent is not ready within
    # a short probe window; that pattern causes false 503s during cold starts and
    # prevents the agent from ever joining.
    candidates = _build_agent_candidates(requested_agent_name)
    resolved_agent_name = candidates[0] if candidates else requested_agent_name

    # Ensure LiveKit API calls are bounded in time; Lambda should never hang for the
    # default Twirp client timeout (60s).
    api_timeout = aiohttp.ClientTimeout(
        total=max(0.8, float(DISPATCH_TASK_TIMEOUT_SECONDS or 0.0)),
    )

    async with LiveKitAPI(livekit_url, api_key, api_secret, timeout=api_timeout) as lkapi:
        # Ensure the room exists before dispatching. Dispatch creation can succeed even when
        # the room hasn't been instantiated yet; pre-creating the room removes a race where
        # the browser connects but the dispatch never triggers reliably.
        try:
            tenant_id = ""
            try:
                if "-room-" in room_name:
                    tenant_id = str(room_name).split("-room-", 1)[0]
            except Exception as exc:
                logger.error("jwt_handler.tenant_id_parse_failed room=%s: %s", room_name, exc, exc_info=True)
                tenant_id = ""

            # Fast cleanup for the public landing demo rooms (avoids room clutter).
            default_empty_timeout = 15 if tenant_id == "testing" else 60

            empty_timeout = int(
                os.environ.get(
                    "LIVEKIT_ROOM_EMPTY_TIMEOUT_SECONDS",
                    str(default_empty_timeout),
                )
            )
        except Exception:
            empty_timeout = 60
        try:
            await lkapi.room.create_room(CreateRoomRequest(name=room_name, empty_timeout=max(5, empty_timeout)))
        except Exception as exc:
            # Room likely already exists (or was auto-created by a participant).
            logger.warning("jwt_handler.room_create_failed room=%s (likely pre-exists): %s", room_name, exc)

        for agent_name in candidates:
            resolved_agent_name = agent_name
            try:
                await lkapi.agent_dispatch.create_dispatch(
                    CreateAgentDispatchRequest(
                        agent_name=agent_name,
                        room=room_name,
                        metadata=metadata,
                    )
                )
                # Hint only: agent may still be starting.
                return resolved_agent_name, True, False
            except Exception as e:
                logger.error(
                    "Failed to dispatch agent %s to room %s: %s",
                    agent_name,
                    room_name,
                    e,
                )
                continue

    return resolved_agent_name, False, False


async def _cleanup_room_dispatches(
    *,
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
    delete_room: bool = False,
) -> None:
    try:
        async with LiveKitAPI(livekit_url, api_key, api_secret) as lkapi:
            dispatches = list(await lkapi.agent_dispatch.list_dispatch(room_name) or [])
            for dispatch in dispatches:
                dispatch_id = str(getattr(dispatch, "id", "") or "").strip()
                if not dispatch_id:
                    continue
                try:
                    await lkapi.agent_dispatch.delete_dispatch(dispatch_id, room_name)
                except Exception as exc:
                    logger.error(
                        "jwt_handler.dispatch_delete_failed room=%s dispatch_id=%s: %s",
                        room_name,
                        dispatch_id,
                        exc,
                        exc_info=True,
                    )
            if delete_room:
                try:
                    await lkapi.room.delete_room(DeleteRoomRequest(room=room_name))
                except Exception as exc:
                    logger.error("jwt_handler.room_delete_failed room=%s: %s", room_name, exc, exc_info=True)
    except Exception as exc:
        logger.error("jwt_handler.cleanup_room_failed room=%s: %s", room_name, exc, exc_info=True)


def _build_agent_candidates(requested_agent_name: str) -> list[str]:
    explicit_requested = str(requested_agent_name or "").strip()
    if explicit_requested and not ALLOW_FALLBACK_FOR_EXPLICIT_AGENT:
        return [explicit_requested]

    candidates = []

    def add(value):
        candidate = str(value or "").strip()
        if candidate and candidate not in candidates:
            candidates.append(candidate)

    add(requested_agent_name)
    add(DEFAULT_AGENT_NAME)
    for fallback in AGENT_FALLBACKS:
        add(fallback)
    return candidates


def _coerce_job_status(status) -> int:
    try:
        return int(status)
    except Exception:
        try:
            return int(getattr(status, "value", 0) or 0)
        except Exception:
            return 0


async def _wait_for_dispatch_running(
    lkapi: LiveKitAPI,
    *,
    dispatch_id: str,
    room_name: str,
) -> bool:
    if not dispatch_id:
        return False

    deadline = time.monotonic() + max(0.0, DISPATCH_RUNNING_WAIT_SECONDS)
    while time.monotonic() <= deadline:
        try:
            dispatches = list(await lkapi.agent_dispatch.list_dispatch(room_name) or [])
            for dispatch in dispatches:
                current_dispatch_id = str(getattr(dispatch, "id", "") or "")
                if current_dispatch_id != dispatch_id:
                    continue
                state = getattr(dispatch, "state", None)
                jobs = list(getattr(state, "jobs", []) or []) or list(getattr(dispatch, "jobs", []) or [])
                saw_pending_job = False
                for job in jobs:
                    status = _coerce_job_status(
                        getattr(getattr(job, "state", None), "status", None) or getattr(job, "status", None)
                    )
                    if status in (1, 2):  # JS_RUNNING | JS_SUCCESS
                        return True
                    if status == 3:  # JS_FAILED
                        return False
                    if status == 0:  # JS_PENDING
                        saw_pending_job = True
                if saw_pending_job or not jobs:
                    break
        except Exception:
            return False

        await asyncio.sleep(max(0.05, AGENT_POLL_INTERVAL_SECONDS))

    return False


async def _wait_for_remote_participant(
    lkapi: LiveKitAPI,
    *,
    room_name: str,
    participant_name: str,
) -> bool:
    deadline = time.monotonic() + max(0.0, AGENT_READY_WAIT_SECONDS)
    while time.monotonic() <= deadline:
        try:
            response = await lkapi.room.list_participants(ListParticipantsRequest(room=room_name))
            participants = list(getattr(response, "participants", []) or [])
            for participant in participants:
                identity = str(getattr(participant, "identity", "") or "").strip()
                if identity and identity != participant_name:
                    return True
        except Exception:
            return False

        await asyncio.sleep(max(0.05, AGENT_POLL_INTERVAL_SECONDS))

    return False


def dispatch_agent_to_room(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
    agent_id: str = None,
    metadata: str = "",
) -> bool:
    """
    Dispatch agent to room using LiveKit API (synchronous wrapper).

    This is a synchronous wrapper around the async dispatch function for use in Lambda.

    Args:
        livekit_url: LiveKit server URL
        api_key: LiveKit API key
        api_secret: LiveKit API secret
        room_name: Name of the room
        agent_id: Agent NAME to dispatch (if None, will use DEFAULT_AGENT_NAME)
        metadata: Optional metadata for the dispatch

    Returns:
        True if dispatch succeeded, False otherwise
    """
    # Use DEFAULT_AGENT_NAME if no agent_id provided
    if agent_id is None:
        agent_id = DEFAULT_AGENT_NAME
        logger.info(f"Using default agent: {agent_id}")

    logger.info(f"Dispatching agent: {agent_id}")
    try:
        _, dispatch_success, _ = asyncio.run(
            _dispatch_agent_to_room_async(
                livekit_url=livekit_url,
                api_key=api_key,
                api_secret=api_secret,
                room_name=room_name,
                requested_agent_name=agent_id,
                participant_name="dispatch-probe",
                metadata=metadata,
            )
        )
        return dispatch_success
    except Exception as e:
        correlation_id = str(uuid.uuid4())
        logger.error(
            "Error in dispatch_agent_to_room [correlation_id=%s]: %s",
            correlation_id,
            e,
            exc_info=True,
        )
        return False


def validate_room_name(room_name: str, tenant_id: str) -> bool:
    """
    Validate room name format and tenant isolation.

    Room names must be prefixed with tenant_id:
        Format: "{tenant_id}-room-{uuid}"
        Example: "tenant-123-room-abc456def789"

    Args:
        room_name: Room name to validate
        tenant_id: Expected tenant ID

    Returns:
        True if valid and belongs to tenant, False otherwise
    """
    if not room_name:
        return False

    # Room must start with tenant_id prefix
    if not room_name.startswith(f"{tenant_id}-"):
        return False

    # Validate format: {tenant_id}-room-{uuid}
    # Remove tenant_id prefix and check for "-room-" suffix
    suffix = room_name[len(tenant_id) :]
    if not suffix.startswith("-room-"):
        return False

    # Check that there's something after "-room-"
    room_id = suffix[6:]  # Remove "-room-" prefix
    if not room_id:
        return False

    # Check alphanumeric and hyphens only (for UUID-like room IDs)
    if not room_name.replace("-", "").isalnum():
        return False

    return True


async def _lambda_handler_async(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """
    Async implementation of JWT token generation with early dispatch.

    This function runs dispatch and JWT generation in parallel to minimize latency.
    """
    # Extract request origin for CORS validation
    headers = event.get("headers") or {}
    request_origin = str(headers.get("origin") or headers.get("Origin") or "").strip()

    # Handle OPTIONS preflight request (API Gateway v1 and v2)
    http_method = event.get("httpMethod") or event.get("requestContext", {}).get("http", {}).get("method")
    if http_method == "OPTIONS":
        return {"statusCode": 200, "headers": create_cors_headers(request_origin), "body": ""}

    try:
        # Parse request body (API Gateway v2 format has raw body as string)
        body_str = event.get("body", "{}")
        if isinstance(body_str, str):
            body = json.loads(body_str)
        else:
            body = body_str

        # Extract parameters
        room_name = body.get("room_name")
        participant_name = body.get("participant_name")
        tenant_id = body.get("tenant_id")
        metadata_dict = body.get("metadata", {})

        # Validate required parameters
        if not room_name or not participant_name or not tenant_id:
            return {
                "statusCode": 400,
                "headers": create_cors_headers(request_origin),
                "body": json.dumps(
                    {
                        "error": "Missing required parameters",
                        "message": "room_name, participant_name, and tenant_id are required",
                    }
                ),
            }

        # Validate room name format and tenant isolation
        if not validate_room_name(room_name, tenant_id):
            logger.warning(
                "Room name validation failed: room_name=%s, tenant_id=%s",
                room_name,
                tenant_id,
            )
            return {
                "statusCode": 403,
                "headers": create_cors_headers(request_origin),
                "body": json.dumps(
                    {
                        "error": "invalid_room_name",
                        "message": "Room name format is invalid or does not match your tenant.",
                    }
                ),
            }

        # Get LiveKit Cloud credentials from AWS Secrets Manager
        livekit_url, api_key, api_secret = get_livekit_credentials()

        # Fetch tenant configuration from DynamoDB
        tenant_config = get_tenant_config(tenant_id)

        # Server-driven landing demo guardrails (do not trust the browser for limits).
        source = ""
        try:
            source = str(metadata_dict.get("source") or "").strip().lower()
        except Exception:
            source = ""
        if source == "landing_widget":
            zara_access_token = str(body.get("zara_access_token") or "").strip()
            if not zara_access_token:
                return {
                    "statusCode": 401,
                    "headers": create_cors_headers(request_origin),
                    "body": json.dumps(
                        {
                            "error": "waitlist_required",
                            "message": "Join the waitlist to unlock Zara live.",
                        }
                    ),
                }
            try:
                zara_access_claims = _verify_zara_access_token(zara_access_token, api_secret)
            except Exception:
                return {
                    "statusCode": 401,
                    "headers": create_cors_headers(request_origin),
                    "body": json.dumps(
                        {
                            "error": "invalid_waitlist_access",
                            "message": "Your Zara access link is invalid or expired. Join the waitlist again.",
                        }
                    ),
                }
            tenant_config = dict(tenant_config or {})
            tenant_config["hard_end_seconds"] = 60
            tenant_config["require_client_ready"] = False
            lead_email = str(zara_access_claims.get("sub") or "").strip().lower()
            if lead_email:
                metadata_dict["zara_user_email"] = lead_email
            if "wl_pos" in zara_access_claims:
                try:
                    metadata_dict["zara_waitlist_position"] = int(zara_access_claims.get("wl_pos"))
                except Exception as exc:
                    logger.error("jwt_handler.waitlist_position_parse_failed: %s", exc, exc_info=True)

        # Add tenant_id and tenant_config to metadata
        metadata_dict["tenant_id"] = tenant_id
        metadata_dict["tenant_config"] = tenant_config

        # Convert metadata to JSON string
        metadata_json = json.dumps(metadata_dict)

        # OPTIMIZATION: Early Dispatch - Start dispatch BEFORE JWT generation
        # This runs JWT generation and dispatch in parallel, saving ~1-2 seconds
        # Get agent_name from request if provided.
        requested_agent_name = body.get("agent_id", None)
        resolved_agent_name = (
            str(requested_agent_name).strip()
            if requested_agent_name and str(requested_agent_name).strip()
            else DEFAULT_AGENT_NAME
        )

        # OPTIMIZATION: Reduce metadata payload for faster dispatch
        # Send only tenant_id - agent will fetch full config from DynamoDB
        # This reduces dispatch payload size and processing time
        dispatch_metadata = json.dumps(
            {
                "tenant_id": tenant_id,
                "source": "jwt-lambda",
                # Note: Agent fetches tenant_config from DynamoDB based on tenant_id
            }
        )

        # Start dispatch in background (non-blocking with timeout)
        # We use asyncio.wait_for to limit dispatch time to 2 seconds max
        # If dispatch takes longer, we return the token anyway (client waits for agent)
        logger.info(f"Starting early dispatch for agent {resolved_agent_name} to room {room_name}...")
        dispatch_task = asyncio.create_task(
            _dispatch_agent_to_room_async(
                livekit_url=livekit_url,
                api_key=api_key,
                api_secret=api_secret,
                room_name=room_name,
                requested_agent_name=resolved_agent_name,
                participant_name=participant_name,
                metadata=dispatch_metadata,
            )
        )

        # Generate JWT token (runs in parallel with dispatch)
        token = create_jwt_token(
            api_key=api_key,
            api_secret=api_secret,
            room_name=room_name,
            identity=participant_name,
            metadata=metadata_json,
        )

        # Wait for dispatch completion. Dispatch itself is time-bounded via LiveKitAPI
        # aiohttp timeouts inside `_dispatch_agent_to_room_async`.
        agent_ready = False
        resolved_agent_name, dispatch_success, agent_ready = await dispatch_task
        if dispatch_success:
            logger.info(
                f"Agent {resolved_agent_name} dispatched successfully to room {room_name} (ready={agent_ready})"
            )
        else:
            logger.error("Failed to dispatch agent %s to room %s", resolved_agent_name, room_name)

        if not dispatch_success:
            try:
                await _cleanup_room_dispatches(
                    livekit_url=livekit_url,
                    api_key=api_key,
                    api_secret=api_secret,
                    room_name=room_name,
                    delete_room=True,
                )
            except Exception as exc:
                logger.error("jwt_handler.dispatch_failure_cleanup_failed room=%s: %s", room_name, exc, exc_info=True)
            return {
                "statusCode": 503,
                "headers": create_cors_headers(request_origin),
                "body": json.dumps(
                    {
                        "error": "voice_demo_busy",
                        "message": "Voice demo is temporarily busy. Please retry in a moment.",
                    }
                ),
            }

        # Return token and room URL
        # Include agent_id and dispatch_success in response so frontend knows which agent to expect
        return {
            "statusCode": 200,
            "headers": create_cors_headers(request_origin),
            "body": json.dumps(
                {
                    "token": token,
                    "room_url": livekit_url,
                    "room_name": room_name,
                    "participant_name": participant_name,
                    "agent_id": resolved_agent_name,
                    "dispatch_success": dispatch_success,
                    "agent_ready": agent_ready,
                    "expires_in": TOKEN_EXPIRATION,
                }
            ),
        }

    except Exception as e:
        correlation_id = str(uuid.uuid4())
        logger.error(
            "Error generating JWT token [correlation_id=%s]: %s",
            correlation_id,
            str(e),
            exc_info=True,
        )

        return {
            "statusCode": 500,
            "headers": create_cors_headers(request_origin),
            "body": json.dumps(
                {
                    "error": "internal_server_error",
                    "message": "An unexpected error occurred. Please try again or contact support.",
                    "correlation_id": correlation_id,
                }
            ),
        }


# ============================================================================
# AWS Lambda handler (synchronous wrapper)
# ============================================================================


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """
    AWS Lambda handler for JWT token generation.

    This is a synchronous wrapper that calls the async implementation.
    AWS Lambda requires synchronous handlers, so we use asyncio.run().

    OPTIMIZATION: Early dispatch - JWT generation and agent dispatch run in parallel.
    This saves ~1-2 seconds compared to sequential execution.

    Args:
        event: API Gateway event (v1 or v2 format)
        context: Lambda context

    Returns:
        API Gateway response

    Request:
        POST /jwt/livekit-token
        {
            "room_name": "tenant-123-room-abc456",
            "participant_name": "user-456",
            "tenant_id": "tenant-123",
            "metadata": {...}
        }

    Response:
        {
            "token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
            "room_url": "wss://workweaver-prod-5ny6zwt7.livekit.cloud",
            "room_name": "tenant-123-room-abc456",
            "expires_in": 86400
        }
    """
    return asyncio.run(_lambda_handler_async(event, context))


# ============================================================================
# Development handler (for local testing)
# ============================================================================

if __name__ == "__main__":
    # Test JWT token generation
    test_event = {
        "body": json.dumps(
            {
                "room_name": "tenant-123-room-abc456def789",
                "participant_name": "user-456",
                "tenant_id": "tenant-123",
                "metadata": {"user_id": "user-456"},
            }
        )
    }

    response = lambda_handler(test_event, None)
    print(json.dumps(json.loads(response["body"]), indent=2))
