"""Precedent Refresh Lambda Handler.

This Lambda function runs on a daily schedule to refresh precedent
freshness scores across all tenants.

Reference: docs/PRODUCT.md P1.1.4B - Operational Context Integration
TASK-1.6.004: Build precedent refresh job (scheduled updates)

Environment Variables:
    PRECEDENTS_TABLE_NAME: DynamoDB table name (default: workweaver-precedents-dev)
    DRY_RUN: If "true", only simulate updates (default: false)
    LOG_LEVEL: Logging level (default: INFO)
    AWS_REGION: AWS region (default: us-east-1)
"""
from apps.backend.config.table_names import resolve_table

import json
import logging
import os
import sys
from datetime import datetime, UTC
from pathlib import Path
from typing import Any

# Add repo root to path for local development
repo_root = Path(__file__).resolve().parents[4]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from apps.backend.services.precedent_freshness import (
    PrecedentFreshness,
    FreshnessUpdateResult,
    FreshnessMetrics,
)


# Configure logging
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
logging.basicConfig(level=getattr(logging, LOG_LEVEL))
logger = logging.getLogger(__name__)


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Main Lambda entry point for precedent refresh.

    Args:
        event: Lambda event containing optional tenant_id and dry_run override
            - tenant_id: Optional tenant ID to filter refresh (default: all tenants)
            - dry_run: Optional boolean to override DRY_RUN env var

        context: Lambda context (unused)

    Returns:
        Dict with:
            - statusCode: HTTP status code (200 on success, 500 on error)
            - body: JSON with status, result, metrics, timestamp, dry_run
    """
    logger.info("precedent_refresh_lambda_invoked", extra={"event": event})

    try:
        # Parse event — tenant_id is required for tenant isolation
        tenant_id = event.get("tenant_id")
        if not tenant_id:
            return {
                "statusCode": 400,
                "body": json.dumps(
                    {
                        "status": "error",
                        "error": "tenant_id is required",
                    }
                ),
            }
        dry_run_override = event.get("dry_run")

        # Determine dry_run mode
        if dry_run_override is not None:
            dry_run = bool(dry_run_override)
        else:
            dry_run = os.environ.get("DRY_RUN", "false").lower() == "true"

        # Initialize service
        table_name = resolve_table("precedents")
        region_name = os.environ.get("AWS_REGION", "us-east-1")

        freshness_service = PrecedentFreshness(
            table_name=table_name,
            region_name=region_name,
        )

        # Run refresh
        logger.info(
            "starting_precedent_refresh",
            extra={
                "tenant_id": tenant_id or "ALL",
                "dry_run": dry_run,
                "table_name": table_name,
            },
        )

        result: FreshnessUpdateResult = freshness_service.refresh_all_freshness(
            tenant_id=tenant_id,
            dry_run=dry_run,
        )

        # Get metrics
        metrics: FreshnessMetrics = freshness_service.get_freshness_metrics(tenant_id=tenant_id)

        # Build response
        timestamp = datetime.now(UTC).isoformat()

        response_body = {
            "status": "success",
            "result": {
                "updated_count": result.updated_count,
                "marked_stale_count": result.marked_stale_count,
                "refreshed_count": result.refreshed_count,
                "failed_count": result.failed_count,
                "time_ms": result.time_ms,
            },
            "metrics": {
                "total_precedents": metrics.total_precedents,
                "fresh_precedents": metrics.fresh_precedents,
                "stale_precedents": metrics.stale_precedents,
                "average_freshness": round(metrics.average_freshness, 3),
                "oldest_precedent_age_days": metrics.oldest_precedent_age_days,
                "newest_precedent_age_days": metrics.newest_precedent_age_days,
            },
            "timestamp": timestamp,
            "dry_run": dry_run,
        }

        logger.info(
            "precedent_refresh_complete",
            extra={
                "updated": result.updated_count,
                "stale": result.marked_stale_count,
                "failed": result.failed_count,
                "time_ms": result.time_ms,
            },
        )

        return {
            "statusCode": 200,
            "body": json.dumps(response_body),
        }

    except Exception as e:
        logger.error(
            "precedent_refresh_failed",
            extra={"error": str(e)},
            exc_info=True,
        )

        return {
            "statusCode": 500,
            "body": json.dumps(
                {
                    "status": "error",
                    "error": str(e),
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            ),
        }


def development_handler():
    """Development entry point for local testing."""
    print("Running precedent refresh in development mode...")

    # Simulate Lambda event
    event = {
        "tenant_id": None,  # All tenants
        "dry_run": True,  # Dry run for safety
    }

    result = lambda_handler(event, None)
    print(json.dumps(json.loads(result["body"]), indent=2))


if __name__ == "__main__":
    development_handler()
