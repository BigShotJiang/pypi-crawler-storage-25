"""Wake-path Lambda: token validation for cloud access.

Validates Cognito JWT tokens and returns user context for cross-device
and cloud-only operations. Part of the local-authoritative + Lambda
batch-wake architecture (ADR-006).
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

COGNITO_USER_POOL_ID = os.environ.get("COGNITO_USER_POOL_ID", "")
COGNITO_CLIENT_ID = os.environ.get("COGNITO_CLIENT_ID", "")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

_cognito_idp = boto3.client("cognito-idp", region_name=AWS_REGION)

_ALLOWED_ORIGINS = {
    "https://workweaver.ai",
    "https://www.workweaver.ai",
    "https://admin.workweaver.ai",
}


def _cors_headers(origin: str = "") -> dict[str, str]:
    allowed = origin if origin in _ALLOWED_ORIGINS else ""
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowed,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400",
    }


def _response(status_code: int, body: dict, origin: str = "") -> dict[str, Any]:
    return {"statusCode": status_code, "headers": _cors_headers(origin), "body": json.dumps(body)}


def validate_token(access_token: str) -> dict[str, Any]:
    """Validate a Cognito access token and return user attributes.

    Uses Cognito's GetUser API which verifies token signature and
    expiration server-side.
    """
    try:
        resp = _cognito_idp.get_user(AccessToken=access_token)
    except _cognito_idp.exceptions.NotAuthorizedException:
        return {"valid": False, "error": "invalid_token"}
    except _cognito_idp.exceptions.UserNotFoundException:
        return {"valid": False, "error": "user_not_found"}
    except ClientError as exc:
        logger.error("token_validate.cognito_error: %s", exc)
        return {"valid": False, "error": "cognito_error"}

    attributes = {}
    for attr in resp.get("UserAttributes", []):
        attributes[attr["Name"]] = attr["Value"]

    return {
        "valid": True,
        "username": resp.get("Username", ""),
        "attributes": attributes,
        "validated_at": int(time.time()),
    }


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    headers = event.get("headers") or {}
    origin = str(headers.get("origin") or headers.get("Origin") or "").strip()

    http_method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
    )
    if http_method == "OPTIONS":
        return {"statusCode": 200, "headers": _cors_headers(origin), "body": ""}

    body_str = event.get("body", "{}")
    body = json.loads(body_str) if isinstance(body_str, str) else body_str

    access_token = body.get("access_token", "").strip()
    if not access_token:
        return _response(400, {"error": "missing_access_token"}, origin)

    result = validate_token(access_token)
    if not result["valid"]:
        status = 401 if result["error"] in ("invalid_token", "user_not_found") else 500
        return _response(status, {"error": result["error"]}, origin)

    return _response(200, result, origin)
