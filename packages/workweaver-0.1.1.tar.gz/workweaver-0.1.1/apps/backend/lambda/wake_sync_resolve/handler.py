"""Wake-path Lambda: sync state resolution for cross-device access.

Resolves the latest sync state for a tenant so that a browser on another
machine can reconcile against the local-authoritative surface. Uses
revision-OCC for conflict detection (ADR-006).
"""

from __future__ import annotations
from apps.backend.config.table_names import TableNameResolutionError, resolve_table

import json
import logging
import os
from typing import Any

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

_dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)

_ALLOWED_ORIGINS = {
    "https://workweaver.ai",
    "https://www.workweaver.ai",
    "https://admin.workweaver.ai",
}


def _cors_headers(origin: str = "") -> dict[str, str]:
    allowed = origin if origin in _ALLOWED_ORIGINS else ""
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": allowed,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400",
    }


def _response(status_code: int, body: dict, origin: str = "") -> dict[str, Any]:
    return {"statusCode": status_code, "headers": _cors_headers(origin), "body": json.dumps(body)}


def resolve_sync_state(tenant_id: str, entity_types: list[str] | None = None) -> dict[str, Any]:
    """Query sync metadata for a tenant from DynamoDB.

    Returns revision vectors for each entity type so the client can
    determine what needs reconciliation.
    """
    try:
        table_name = resolve_table("runtime_state")
    except TableNameResolutionError as exc:
        logger.error("sync_resolve.table_not_configured tenant=%s: %s", tenant_id, exc)
        return {"tenant_id": tenant_id, "entities": {}, "error": "table_not_configured"}

    table = _dynamodb.Table(table_name)

    try:
        resp = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key("pk").eq(
                f"TENANT#{tenant_id}"
            )
            & boto3.dynamodb.conditions.Key("sk").begins_with("SYNC#"),
            ProjectionExpression="sk, revision, updated_at",
        )
    except ClientError as exc:
        logger.error("sync_resolve.query_failed tenant=%s: %s", tenant_id, exc)
        return {"tenant_id": tenant_id, "entities": {}, "error": "query_failed"}

    entities: dict[str, Any] = {}
    for item in resp.get("Items", []):
        sk = item.get("sk", "")
        entity_type = sk.replace("SYNC#", "", 1)
        if entity_types and entity_type not in entity_types:
            continue
        entities[entity_type] = {
            "revision": int(item.get("revision", 0)),
            "updated_at": item.get("updated_at", ""),
        }

    return {"tenant_id": tenant_id, "entities": entities}


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    headers = event.get("headers") or {}
    origin = str(headers.get("origin") or headers.get("Origin") or "").strip()

    http_method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
    )
    if http_method == "OPTIONS":
        return {"statusCode": 200, "headers": _cors_headers(origin), "body": ""}

    body_str = event.get("body", "{}")
    body = json.loads(body_str) if isinstance(body_str, str) else body_str

    tenant_id = body.get("tenant_id", "").strip()
    if not tenant_id:
        return _response(400, {"error": "missing_tenant_id"}, origin)

    entity_types = body.get("entity_types")

    result = resolve_sync_state(tenant_id, entity_types)
    if "error" in result:
        return _response(500, result, origin)

    return _response(200, result, origin)
