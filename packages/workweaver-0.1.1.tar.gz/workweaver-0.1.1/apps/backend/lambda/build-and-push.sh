#!/bin/bash
# Build and push Voice Testing API Lambda Docker image to ECR
set -e

# Configuration
AWS_PROFILE="${AWS_PROFILE:-workweaver-prod-admin}"
AWS_REGION="us-east-1"
ECR_REPOSITORY="voice-testing-api"
IMAGE_TAG="${1:-latest}"

# Get AWS account ID
AWS_ACCOUNT_ID=$(aws --profile $AWS_PROFILE sts get-caller-identity --query Account --output text)
ECR_URI="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

echo "=== Voice Testing API Lambda Build ==="
echo "ECR URI: ${ECR_URI}"
echo "Repository: ${ECR_REPOSITORY}"
echo "Tag: ${IMAGE_TAG}"
echo ""

# Navigate to repo root for proper build context
REPO_ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "${REPO_ROOT}"

# Login to ECR
echo "Logging in to ECR..."
aws --profile $AWS_PROFILE ecr get-login-password --region ${AWS_REGION} | \
  docker login --username AWS --password-stdin ${ECR_URI}

# Build and push Docker image directly to ECR (ARM64 for M1/M2 Mac + AWS Graviton)
echo "Building and pushing Docker image to ECR..."
# Use DOCKER_CLI_EXPERIMENTAL to force docker schema 2 manifest
DOCKER_CLI_EXPERIMENTAL=enabled docker buildx build \
  --platform linux/arm64 \
  --push \
  --output=type=registry \
  -f apps/backend/Dockerfile.lambda \
  -t ${ECR_URI}/${ECR_REPOSITORY}:${IMAGE_TAG} \
  --provenance=false \
  --sbom=false \
  .

echo ""
echo "=== Build Complete ==="
echo "Image URI: ${ECR_URI}/${ECR_REPOSITORY}:${IMAGE_TAG}"
