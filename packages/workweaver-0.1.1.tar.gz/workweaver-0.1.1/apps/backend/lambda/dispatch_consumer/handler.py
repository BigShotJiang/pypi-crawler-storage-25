"""AWS Lambda adapter for the portable dispatch-consumer runtime."""

from __future__ import annotations

import json
from typing import Any
from apps.backend.services.dispatch_consumer_runtime import process_dispatch_records


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Process SQS batch event."""
    _ = context
    records = event.get("Records")
    summary = process_dispatch_records(records)
    return {"statusCode": 200, "body": json.dumps(summary)}
