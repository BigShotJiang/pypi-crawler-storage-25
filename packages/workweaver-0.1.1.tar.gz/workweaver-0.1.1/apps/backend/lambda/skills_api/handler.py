"""
Skills API Lambda Handler

This Lambda function serves the Skills CRUD API using FastAPI and Mangum.
Mangum provides ASGI adapter for running FastAPI on AWS Lambda.

Architecture:
    AWS Lambda (Mangum + FastAPI) → DynamoDB Skills Registry

API Endpoints:
    - GET    /api/v1/skills                          List skills
    - GET    /api/v1/skills/{skill_id}               Get skill
    - POST   /api/v1/skills                          Create skill
    - PATCH  /api/v1/skills/{skill_id}               Update skill
    - DELETE /api/v1/skills/{skill_id}               Delete skill
    - POST   /api/v1/skills/{skill_id}/test          Test skill
    - PATCH  /api/v1/skills/tenants/{tenant_id}/skills/{skill_id}  Enable/disable

Reference:
    - TASK-1.7.001: Create Skill CRUD Lambda function
    - TASK-1.7.002: Implement API Gateway integration with Lambda
    - docs/PRODUCT.md P1.1.5 — Skill CRUD API
    - Mangum: https://github.com/jordaneremieff/mangum
"""

import sys
import os

# Add apps directory to Python path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from mangum import Mangum
from apps.backend.api.skills import router
from apps.backend.middleware.tenant_isolation import TenantIsolationMiddleware
from fastapi import FastAPI

# Create FastAPI application
app = FastAPI(
    title="Workweaver Skills API",
    description="Skills-First AI Platform - Skills CRUD API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Add tenant isolation middleware (all requests must have x-tenant-id header)
app.add_middleware(TenantIsolationMiddleware)

# Include skills router
app.include_router(router, prefix="/api/v1/skills", tags=["Skills"])


def lambda_handler(event, context):
    """
    AWS Lambda handler for FastAPI application using Mangum.

    Args:
        event: Lambda event (from API Gateway)
        context: Lambda context

    Returns:
        API Gateway response (with proper format for HTTP API v2)
    """
    # Mangum adapter handles ASGI to Lambda translation
    asgi_handler = Mangum(app)
    return asgi_handler(event, context)


# ============================================================================
# Development Handler (for local testing)
# ============================================================================

if __name__ == "__main__":
    # For local development: run with uvicorn
    import uvicorn

    print("Starting Skills API in development mode...")
    print("API docs available at: http://localhost:8000/docs")
    print("ReDoc available at: http://localhost:8000/redoc")

    uvicorn.run(
        app,
        host=os.environ.get("UVICORN_HOST", "127.0.0.1"),
        port=int(os.environ.get("UVICORN_PORT", "8000")),
        log_level="info",
    )
