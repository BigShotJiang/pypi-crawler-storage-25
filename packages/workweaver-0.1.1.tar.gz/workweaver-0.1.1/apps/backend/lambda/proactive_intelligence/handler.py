"""Proactive Intelligence Lambda handler (M6.5 + SUP-8).

EventBridge-triggered Lambda that runs on three schedules:
  1. Anomaly detection (every 15 minutes): scans all active tenants,
     calls IntelligenceAggregator.detect_anomalies() per tenant/agent,
     and publishes notifications for any anomalies found.
  2. Daily briefing (06:00 UTC): generates daily intelligence briefings
     for all active tenants via IntelligenceAggregator.get_daily_briefing().
  3. Supervisor review (hourly): runs SupervisorService.run_periodic_review()
     for all active tenants (SUP-8). Quality checks, conflict detection,
     contention detection, deadline watch, and pending proposal review.

Mode is determined by:
  - PROACTIVE_MODE env var (explicit override), OR
  - EventBridge resource ARN suffix ("anomaly", "briefing", or "supervisor")

Environment variables:
  TENANTS_TABLE     -- DynamoDB table storing tenant records
  PROACTIVE_MODE    -- Optional override: "anomaly" | "briefing" | "supervisor_review"
  AWS_REGION        -- AWS region (default us-east-1)
  ENVIRONMENT       -- prod / dev
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import asyncio
import json
import logging
import os
from typing import Any
from datetime import UTC, datetime

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

_TENANTS_TABLE = resolve_table("tenants")
_REGION = os.environ.get("AWS_REGION", "us-east-1")

# Rate limiting: tracks last run timestamp per mode to prevent runs < 10 min apart.
_last_run_timestamps: dict[str, float] = {}
_RATE_LIMIT_SECONDS = 600  # 10 minutes

# Cost tracking: counts LLM calls per tenant per invocation for observability.
_llm_call_counter: dict[str, int] = {}


# ---------------------------------------------------------------------------
# Mode detection
# ---------------------------------------------------------------------------


def _detect_mode(event: dict[str, Any]) -> str:
    """Determine invocation mode: anomaly, briefing, or supervisor_review.

    Priority:
      1. PROACTIVE_MODE env var (if set)
      2. EventBridge resource ARN suffix
      3. Default: "anomaly"
    """
    env_mode = os.environ.get("PROACTIVE_MODE", "").strip().lower()
    if env_mode in ("anomaly", "briefing", "supervisor_review", "forgetting"):
        return env_mode

    resources = event.get("resources", [])
    for resource_arn in resources:
        arn_lower = str(resource_arn).lower()
        if "briefing" in arn_lower:
            return "briefing"
        if "supervisor" in arn_lower:
            return "supervisor_review"
        if "forgetting" in arn_lower:
            return "forgetting"
        if "anomaly" in arn_lower:
            return "anomaly"

    return "anomaly"


# ---------------------------------------------------------------------------
# Tenant scanning
# ---------------------------------------------------------------------------


def _get_active_tenants() -> list[dict[str, Any]]:
    """Scan DynamoDB for active tenants with their active agents.

    Returns list of dicts with keys: tenant_id, agents (list of agent dicts).
    """
    import boto3
    from boto3.dynamodb.conditions import Attr

    table = boto3.resource("dynamodb", region_name=_REGION).Table(_TENANTS_TABLE)
    tenants: list[dict[str, Any]] = []

    try:
        response = table.scan(
            FilterExpression=Attr("status").eq("active") & Attr("SK").eq("METADATA"),
        )
        items: list[dict[str, Any]] = list(response.get("Items", []))
        while "LastEvaluatedKey" in response:
            response = table.scan(
                FilterExpression=Attr("status").eq("active") & Attr("SK").eq("METADATA"),
                ExclusiveStartKey=response["LastEvaluatedKey"],
            )
            items.extend(response.get("Items", []))

        for item in items:
            tenant_id = str(item.get("tenant_id", ""))
            if not tenant_id:
                continue

            agents_raw = item.get("agents", [])
            agents = []
            if isinstance(agents_raw, list):
                for agent in agents_raw:
                    if isinstance(agent, dict) and agent.get("status") == "active":
                        agents.append(agent)

            # Include tenant even if no agents listed -- use a default agent ID
            if not agents:
                agents = [{"agent_id": f"default-{tenant_id}"}]

            tenants.append({"tenant_id": tenant_id, "agents": agents})

    except Exception as exc:
        logger.error("proactive_intelligence: failed to scan tenants: %s", exc)

    return tenants


# ---------------------------------------------------------------------------
# Intelligence aggregator factory
# ---------------------------------------------------------------------------


def _get_aggregator() -> Any:
    """Return an IntelligenceAggregator instance."""
    from apps.backend.services.inference_aggregator import get_intelligence_aggregator

    return get_intelligence_aggregator()


def _get_heartbeat_runner() -> Any:
    """Return the scheduled proactive heartbeat coroutine."""
    from apps.backend.services.inference.intelligence_service import run_heartbeat

    return run_heartbeat


# ---------------------------------------------------------------------------
# Notification and storage helpers
# ---------------------------------------------------------------------------


def _publish_anomaly_notifications(
    *,
    tenant_id: str,
    agent_id: str,
    anomalies: list[str],
) -> None:
    """Publish anomaly notifications to DynamoDB event store.

    In production this writes to the tenant's event stream so the dashboard
    can display anomaly alerts. Kept synchronous for Lambda context.
    """
    import boto3

    try:
        from datetime import datetime

        table = boto3.resource("dynamodb", region_name=_REGION).Table(_TENANTS_TABLE)
        now = datetime.now(UTC).isoformat()
        table.put_item(
            Item={
                "PK": f"TENANT#{tenant_id}#EVENTS",
                "SK": f"ANOMALY#{now}#{agent_id}",
                "tenant_id": tenant_id,
                "agent_id": agent_id,
                "event_type": "mission.intelligence.updated",
                "anomalies": anomalies,
                "timestamp": now,
            }
        )
        logger.info(
            "proactive_intelligence: published %d anomalies for %s/%s",
            len(anomalies),
            tenant_id,
            agent_id,
        )
    except Exception as exc:
        logger.error(
            "proactive_intelligence: failed to publish anomalies for %s/%s: %s",
            tenant_id,
            agent_id,
            exc,
        )


def _store_briefing(
    *,
    tenant_id: str,
    agent_id: str,
    briefing: dict[str, Any],
) -> None:
    """Store daily briefing in DynamoDB for dashboard retrieval."""
    import boto3

    try:
        from datetime import datetime

        table = boto3.resource("dynamodb", region_name=_REGION).Table(_TENANTS_TABLE)
        now = datetime.now(UTC).isoformat()
        table.put_item(
            Item={
                "PK": f"TENANT#{tenant_id}#BRIEFINGS",
                "SK": f"BRIEFING#{now}#{agent_id}",
                "tenant_id": tenant_id,
                "agent_id": agent_id,
                "event_type": "mission.intelligence.updated",
                "briefing": briefing,
                "timestamp": now,
            }
        )
        logger.info(
            "proactive_intelligence: stored briefing for %s/%s",
            tenant_id,
            agent_id,
        )
    except Exception as exc:
        logger.error(
            "proactive_intelligence: failed to store briefing for %s/%s: %s",
            tenant_id,
            agent_id,
            exc,
        )


def _emit_mode_timeblock(
    *,
    tenant_id: str,
    mode: str,
    agent_id: str,
    actual: str,
    outcome: str = "advanced",
    state: str = "completed",
    error: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    objective_map = {
        "anomaly": "Scheduled anomaly detection",
        "briefing": "Scheduled intelligence briefing",
        "supervisor_review": "Scheduled supervisor review",
        "forgetting": "Scheduled forgetting maintenance",
        "crystallization": "Scheduled skill crystallization",
        "newsletter_sync": "Scheduled CRM newsletter sync",
    }
    origin = "system" if mode in {"supervisor_review", "forgetting", "crystallization", "newsletter_sync"} else "autonomous"

    try:
        from apps.backend.services.scheduling.timeblock_materialization import (
            TimeBlockMaterializationRequest,
            get_timeblock_materialization_service,
        )

        started_at = datetime.now(UTC)
        get_timeblock_materialization_service().materialize(
            TimeBlockMaterializationRequest(
                tenant_id=tenant_id,
                agent_id=agent_id or f"proactive-{mode}",
                objective=objective_map.get(mode, f"Scheduled {mode} run"),
                plan=f"Run proactive mode {mode}.",
                actual=actual,
                phase="monitor",
                state=state,
                outcome=outcome,
                origin=origin,
                source="agent",
                block_type="system_ops",
                started_at=started_at,
                ended_at=started_at,
                error=error,
                metadata=metadata or {},
            )
        )
    except Exception as exc:
        logger.warning("proactive_intelligence: failed to emit %s TimeBlock for %s: %s", mode, tenant_id, exc)


# ---------------------------------------------------------------------------
# Anomaly detection pass
# ---------------------------------------------------------------------------


def _run_anomaly_detection(
    tenants: list[dict[str, Any]],
    aggregator: Any,
) -> dict[str, Any]:
    """Run anomaly detection for all tenants. Returns summary stats."""
    total_anomalies = 0
    errors = 0

    for tenant_info in tenants:
        tenant_id = tenant_info["tenant_id"]
        for agent_info in tenant_info.get("agents", []):
            agent_id = str(agent_info.get("agent_id", ""))
            try:
                anomalies = aggregator.detect_anomalies(tenant_id, agent_id)
                if anomalies:
                    total_anomalies += len(anomalies)
                    _publish_anomaly_notifications(
                        tenant_id=tenant_id,
                        agent_id=agent_id,
                        anomalies=anomalies,
                    )
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="anomaly",
                    agent_id=agent_id or "proactive-anomaly",
                    actual=f"Scanned anomaly signals for {agent_id}; anomalies found: {len(anomalies)}.",
                    outcome="advanced" if anomalies else "neutral",
                    metadata={"anomalies": anomalies, "agent_id": agent_id},
                )
            except Exception as exc:
                errors += 1
                logger.error(
                    "proactive_intelligence: anomaly detection failed for %s/%s: %s",
                    tenant_id,
                    agent_id,
                    exc,
                )
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="anomaly",
                    agent_id=agent_id or "proactive-anomaly",
                    actual="Anomaly scan failed.",
                    outcome="regressed",
                    state="failed",
                    error=str(exc),
                    metadata={"agent_id": agent_id},
                )

    return {
        "tenants_processed": len(tenants),
        "anomalies_found": total_anomalies,
        "errors": errors,
    }


def _run_proactive_heartbeats(
    tenants: list[dict[str, Any]],
    heartbeat_runner: Any,
) -> dict[str, Any]:
    """Run the bounded proactive heartbeat for each tenant on the anomaly schedule."""
    summaries_completed = 0
    total_signals = 0
    total_suggestions = 0
    total_pending = 0
    errors = 0
    loop = asyncio.new_event_loop()

    try:
        for tenant_info in tenants:
            tenant_id = tenant_info["tenant_id"]
            try:
                summary = loop.run_until_complete(heartbeat_runner(tenant_id))
                summaries_completed += 1
                total_signals += int(summary.get("signals_scanned", 0) or 0)
                total_suggestions += int(summary.get("suggestions_generated", 0) or 0)
                total_pending += int(summary.get("pending_total", 0) or 0)
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="anomaly",
                    agent_id="proactive_heartbeat",
                    actual=(
                        f"Heartbeat scanned {int(summary.get('signals_scanned', 0) or 0)} signals, "
                        f"generated {int(summary.get('suggestions_generated', 0) or 0)} suggestions."
                    ),
                    outcome="advanced" if int(summary.get("suggestions_generated", 0) or 0) > 0 else "neutral",
                    metadata=summary,
                )
            except Exception as exc:
                errors += 1
                logger.error(
                    "proactive_intelligence: scheduled heartbeat failed for %s: %s",
                    tenant_id,
                    exc,
                )
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="anomaly",
                    agent_id="proactive_heartbeat",
                    actual="Scheduled proactive heartbeat failed.",
                    outcome="regressed",
                    state="failed",
                    error=str(exc),
                )
    finally:
        loop.close()

    return {
        "proactive_runs_completed": summaries_completed,
        "proactive_signals_scanned": total_signals,
        "proactive_suggestions_generated": total_suggestions,
        "proactive_pending_total": total_pending,
        "proactive_errors": errors,
    }


# ---------------------------------------------------------------------------
# Daily briefing pass
# ---------------------------------------------------------------------------


def _run_daily_briefings(
    tenants: list[dict[str, Any]],
    aggregator: Any,
) -> dict[str, Any]:
    """Generate daily briefings for all tenants. Returns summary stats."""
    briefings_generated = 0
    errors = 0
    loop = asyncio.new_event_loop()

    try:
        for tenant_info in tenants:
            tenant_id = tenant_info["tenant_id"]
            for agent_info in tenant_info.get("agents", []):
                agent_id = str(agent_info.get("agent_id", ""))
                try:
                    briefing = loop.run_until_complete(aggregator.get_daily_briefing(tenant_id, agent_id))
                    _store_briefing(
                        tenant_id=tenant_id,
                        agent_id=agent_id,
                        briefing=briefing,
                    )
                    briefings_generated += 1
                    _emit_mode_timeblock(
                        tenant_id=tenant_id,
                        mode="briefing",
                        agent_id=agent_id or "proactive-briefing",
                        actual="Generated intelligence briefing.",
                        metadata={"agent_id": agent_id, "briefing_keys": sorted(briefing.keys())},
                    )
                except Exception as exc:
                    errors += 1
                    logger.error(
                        "proactive_intelligence: briefing failed for %s/%s: %s",
                        tenant_id,
                        agent_id,
                        exc,
                    )
                    _emit_mode_timeblock(
                        tenant_id=tenant_id,
                        mode="briefing",
                        agent_id=agent_id or "proactive-briefing",
                        actual="Intelligence briefing failed.",
                        outcome="regressed",
                        state="failed",
                        error=str(exc),
                        metadata={"agent_id": agent_id},
                    )
    finally:
        loop.close()

    return {
        "tenants_processed": len(tenants),
        "briefings_generated": briefings_generated,
        "errors": errors,
    }


# ---------------------------------------------------------------------------
# Supervisor periodic review pass (SUP-8)
# ---------------------------------------------------------------------------


def _get_supervisor_service() -> Any:
    """Return a SupervisorService instance for periodic review."""
    from apps.backend.services.runtime.supervisor_service import get_supervisor_service

    return get_supervisor_service()


def _run_supervisor_reviews(
    tenants: list[dict[str, Any]],
    supervisor: Any,
) -> dict[str, Any]:
    """Run periodic supervisor review for all tenants. Returns summary stats.

    SUP-8: Calls run_periodic_review per tenant. Since run_periodic_review is
    async, we run it via asyncio.  Each tenant review is independent; errors
    in one tenant do not block others.
    """
    reviews_completed = 0
    errors = 0
    loop = asyncio.new_event_loop()

    try:
        for tenant_info in tenants:
            tenant_id = tenant_info["tenant_id"]
            try:
                result = supervisor.run_periodic_review(tenant_id)
                # Support both sync and async implementations.
                if asyncio.iscoroutine(result):
                    loop.run_until_complete(result)
                reviews_completed += 1
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="supervisor_review",
                    agent_id="supervisor",
                    actual="Completed scheduled supervisor review.",
                )
            except Exception as exc:
                errors += 1
                logger.error(
                    "proactive_intelligence: supervisor review failed for %s: %s",
                    tenant_id,
                    exc,
                )
                _emit_mode_timeblock(
                    tenant_id=tenant_id,
                    mode="supervisor_review",
                    agent_id="supervisor",
                    actual="Scheduled supervisor review failed.",
                    outcome="regressed",
                    state="failed",
                    error=str(exc),
                )
    finally:
        loop.close()

    return {
        "tenants_processed": len(tenants),
        "reviews_completed": reviews_completed,
        "errors": errors,
    }


# ---------------------------------------------------------------------------
# Lambda entry point
# ---------------------------------------------------------------------------


def _check_rate_limit(mode: str) -> bool:
    """Return True if this mode was run less than _RATE_LIMIT_SECONDS ago.

    Uses an in-memory dict (reset on cold start). This is intentional —
    Lambda warm invocations within the same container will share the dict,
    preventing duplicate runs when EventBridge fires overlapping events.
    """
    import time as _time

    now = _time.time()
    last_run = _last_run_timestamps.get(mode, 0.0)
    if now - last_run < _RATE_LIMIT_SECONDS:
        elapsed = int(now - last_run)
        logger.info(
            "proactive_intelligence: rate-limited mode=%s (last run %ds ago, limit=%ds)",
            mode,
            elapsed,
            _RATE_LIMIT_SECONDS,
        )
        return True
    _last_run_timestamps[mode] = now
    return False


def _increment_llm_counter(tenant_id: str, count: int = 1) -> None:
    """Increment the LLM call counter for a tenant (cost tracking)."""
    _llm_call_counter[tenant_id] = _llm_call_counter.get(tenant_id, 0) + count


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda handler for proactive intelligence and supervisor review.

    Triggered by EventBridge on three schedules:
      - Every 15 minutes for anomaly detection
      - Daily at 06:00 UTC for briefing generation
      - Hourly for supervisor periodic review (SUP-8)

    Supports dry_run mode via event payload or PROACTIVE_DRY_RUN env var.
    When dry_run is True, all logic runs but DynamoDB writes are skipped.

    Rate limiting: if the same mode was invoked less than 10 minutes ago
    (within the same Lambda container), the run is skipped with a log message.

    Args:
        event: EventBridge scheduled event (may contain ``dry_run`` key)
        context: Lambda context (unused)

    Returns:
        Response dict with statusCode and body
    """
    mode = _detect_mode(event)
    dry_run = bool(
        event.get("dry_run") or os.environ.get("PROACTIVE_DRY_RUN", "").strip().lower() in ("1", "true", "yes")
    )
    logger.info("proactive_intelligence: mode=%s dry_run=%s", mode, dry_run)

    # Rate limit check
    if _check_rate_limit(mode):
        return {
            "statusCode": 200,
            "body": json.dumps(
                {
                    "mode": mode,
                    "dry_run": dry_run,
                    "rate_limited": True,
                    "message": f"Skipped: mode '{mode}' was run less than {_RATE_LIMIT_SECONDS}s ago",
                }
            ),
        }

    # Reset per-invocation cost counter
    _llm_call_counter.clear()

    try:
        tenants = _get_active_tenants()
        logger.info("proactive_intelligence: found %d active tenants", len(tenants))

        if not tenants:
            return {
                "statusCode": 200,
                "body": json.dumps(
                    {
                        "mode": mode,
                        "dry_run": dry_run,
                        "tenants_processed": 0,
                        "message": "No active tenants found",
                    }
                ),
            }

        if dry_run:
            # Dry run: scan tenants and compute what would happen, skip writes
            stats: dict[str, Any] = {
                "tenants_processed": len(tenants),
                "message": "Dry run — no DynamoDB writes performed",
            }
            # Track LLM calls that would occur (1 per tenant for anomaly/briefing)
            for tenant_info in tenants:
                _increment_llm_counter(tenant_info["tenant_id"])
            stats["llm_calls_would_occur"] = dict(_llm_call_counter)
        elif mode == "supervisor_review":
            supervisor = _get_supervisor_service()
            stats = _run_supervisor_reviews(tenants, supervisor)
        elif mode == "forgetting":
            # Daily memory lifecycle maintenance (5-layer forgetting protocol)
            logger.info("Running forgetting scheduler for %d tenants", len(tenants))
            from apps.backend.services.forgetting_scheduler import ForgettingScheduler

            scheduler = ForgettingScheduler(
                learning_service_url=os.environ.get("WORKMEMORY_URL"),
            )
            tenant_ids = [t["tenant_id"] for t in tenants]
            stats = {
                "tenants_processed": len(tenant_ids),
                "total_affected": 0,
                "forgetting_errors": 0,
            }
            _forgetting_loop = asyncio.new_event_loop()
            try:
                for tid in tenant_ids:
                    try:
                        result = _forgetting_loop.run_until_complete(scheduler.run_unified(tid))
                        stats["total_affected"] += result.total_affected
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="forgetting",
                            agent_id="forgetting_scheduler",
                            actual=f"Completed forgetting maintenance; affected {result.total_affected} memories.",
                            metadata={"total_affected": result.total_affected},
                        )
                    except Exception:
                        stats["forgetting_errors"] += 1
                        logger.warning(
                            "Forgetting scheduler failed for tenant %s",
                            tid,
                            exc_info=True,
                        )
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="forgetting",
                            agent_id="forgetting_scheduler",
                            actual="Forgetting maintenance failed.",
                            outcome="regressed",
                            state="failed",
                        )
            finally:
                _forgetting_loop.close()
        elif mode == "crystallization":
            # Skill crystallization: patterns -> skill drafts
            logger.info("Running skill crystallization for %d tenants", len(tenants))
            from apps.backend.services.skills.crystallization import SkillCrystallizationService

            crystallization = SkillCrystallizationService()
            tenant_ids = [t["tenant_id"] for t in tenants]
            stats = {"tenants_processed": len(tenant_ids), "crystallized": 0}
            _crystal_loop = asyncio.new_event_loop()
            try:
                for tid in tenant_ids:
                    try:
                        drafts = _crystal_loop.run_until_complete(crystallization.check_and_crystallize(tid))
                        if drafts:
                            logger.info("Crystallized %d skills for tenant %s", len(drafts), tid)
                            stats["crystallized"] += len(drafts)
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="crystallization",
                            agent_id="skill_crystallization",
                            actual=f"Checked for skill crystallization drafts; created {len(drafts or [])}.",
                            outcome="advanced" if drafts else "neutral",
                            metadata={"draft_count": len(drafts or [])},
                        )
                    except Exception:
                        logger.warning("Crystallization failed for tenant %s", tid, exc_info=True)
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="crystallization",
                            agent_id="skill_crystallization",
                            actual="Skill crystallization failed.",
                            outcome="regressed",
                            state="failed",
                        )
            finally:
                _crystal_loop.close()
        elif mode == "newsletter_sync":
            # CRM -> Newsletter subscriber sync
            logger.info("Running CRM newsletter sync for %d tenants", len(tenants))
            from apps.backend.services.crm_newsletter_bridge import CRMNewsletterBridge

            bridge = CRMNewsletterBridge()
            tenant_ids = [t["tenant_id"] for t in tenants]
            stats = {"tenants_processed": len(tenant_ids), "synced": 0}
            _sync_loop = asyncio.new_event_loop()
            try:
                for tid in tenant_ids:
                    try:
                        sync_stats = _sync_loop.run_until_complete(bridge.sync_from_crm(tid))
                        if sync_stats.get("synced", 0) > 0:
                            logger.info("Synced %d subscribers for tenant %s", sync_stats["synced"], tid)
                            stats["synced"] += sync_stats["synced"]
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="newsletter_sync",
                            agent_id="crm_newsletter_sync",
                            actual=f"Synced {int(sync_stats.get('synced', 0) or 0)} newsletter subscribers.",
                            outcome="advanced" if int(sync_stats.get("synced", 0) or 0) > 0 else "neutral",
                            metadata=sync_stats,
                        )
                    except Exception:
                        logger.warning("Newsletter sync failed for tenant %s", tid, exc_info=True)
                        _emit_mode_timeblock(
                            tenant_id=tid,
                            mode="newsletter_sync",
                            agent_id="crm_newsletter_sync",
                            actual="CRM newsletter sync failed.",
                            outcome="regressed",
                            state="failed",
                        )
            finally:
                _sync_loop.close()
        else:
            aggregator = _get_aggregator()
            if mode == "briefing":
                stats = _run_daily_briefings(tenants, aggregator)
                # Also fire MorningBriefService.generate_brief() per tenant (D1-CLM-004)
                # This is additive — IntelligenceAggregator briefing and MorningBriefService
                # produce different artefacts and both are needed.
                try:
                    from apps.backend.services.morning_brief_scheduler import MorningBriefScheduler

                    scheduler = MorningBriefScheduler()
                    tenant_ids = [t["tenant_id"] for t in tenants]
                    _brief_loop = asyncio.new_event_loop()
                    try:
                        morning_stats = _brief_loop.run_until_complete(
                            scheduler.run_due_briefs(tenant_ids, now=datetime.now(UTC))
                        )
                    finally:
                        _brief_loop.close()
                    stats = {**stats, "morning_brief": morning_stats}
                except Exception as exc:
                    logger.warning("proactive_intelligence: morning_brief_scheduler failed: %s", exc)
            else:
                heartbeat_runner = _get_heartbeat_runner()
                stats = {
                    **_run_anomaly_detection(tenants, aggregator),
                    **_run_proactive_heartbeats(tenants, heartbeat_runner),
                }
            # Track LLM calls per tenant for cost observability
            for tenant_info in tenants:
                _increment_llm_counter(tenant_info["tenant_id"])

        return {
            "statusCode": 200,
            "body": json.dumps(
                {
                    "mode": mode,
                    "dry_run": dry_run,
                    "llm_cost_counter": dict(_llm_call_counter),
                    **stats,
                }
            ),
        }

    except Exception as exc:
        logger.error("proactive_intelligence: handler failed: %s", exc)
        return {
            "statusCode": 500,
            "body": json.dumps(
                {
                    "error": str(exc),
                    "message": "Proactive intelligence handler failed",
                    "dry_run": dry_run,
                }
            ),
        }
