"""Goal Scheduler Lambda — fires recurring goals every minute.

Triggered by an EventBridge rule (rate: 1 minute).

Responsibilities:
  1. Enumerate all active tenants that have goals with recurrence_cron set.
  2. Invoke GoalSchedulerService.evaluate_due_goals() for each tenant.
  3. Return a structured summary of triggered goals for CloudWatch observability.

Environment variables:
  TENANTS_TABLE          — DynamoDB table storing tenant records
  ENVIRONMENT            — prod / dev (default: prod)
  AWS_REGION_OVERRIDE    — override AWS region (optional)
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import asyncio
import json
import logging
import os
from datetime import datetime, UTC
from typing import Any

import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

_TENANTS_TABLE = resolve_table("tenants")
_REGION = os.environ.get("AWS_REGION_OVERRIDE") or os.environ.get("AWS_REGION", "us-east-1")

_ddb_resource: Any = None
_tenants_tbl: Any = None


# ---------------------------------------------------------------------------
# AWS helpers
# ---------------------------------------------------------------------------


def _resource() -> Any:
    global _ddb_resource
    if _ddb_resource is None:
        _ddb_resource = boto3.resource("dynamodb", region_name=_REGION)
    return _ddb_resource


def _tenants_table() -> Any:
    global _tenants_tbl
    if _tenants_tbl is None:
        _tenants_tbl = _resource().Table(_TENANTS_TABLE)
    return _tenants_tbl


# ---------------------------------------------------------------------------
# Tenant discovery
# ---------------------------------------------------------------------------


def _list_active_tenant_ids() -> list[str]:
    """Scan the tenants table for active tenant IDs.

    Returns a deduplicated list of tenant_id strings.  Falls back to an
    empty list on any DynamoDB error so the Lambda never crashes silently.
    """
    try:
        response = _tenants_table().scan(
            ProjectionExpression="tenant_id",
        )
        items: list[dict[str, Any]] = list(response.get("Items", []))
        while "LastEvaluatedKey" in response:
            response = _tenants_table().scan(
                ProjectionExpression="tenant_id",
                ExclusiveStartKey=response["LastEvaluatedKey"],
            )
            items.extend(response.get("Items", []))

        seen: set[str] = set()
        tenant_ids: list[str] = []
        for item in items:
            tid = str(item.get("tenant_id") or "").strip()
            if tid and tid not in seen:
                seen.add(tid)
                tenant_ids.append(tid)
        return tenant_ids
    except Exception as exc:
        logger.error("goal_scheduler._list_active_tenant_ids failed: %s", exc)
        return []


# ---------------------------------------------------------------------------
# Lambda handler
# ---------------------------------------------------------------------------


async def _process_tenant(
    service: Any,
    tenant_id: str,
) -> tuple[list[dict[str, Any]], bool]:
    """Evaluate due goals for one tenant.

    Returns (triggered_list, had_error).
    """
    try:
        triggered = await service.evaluate_due_goals(tenant_id)
        if triggered:
            logger.info(
                "goal_scheduler.tenant_done tenant=%s triggered=%d",
                tenant_id,
                len(triggered),
            )
        return triggered, False
    except Exception as exc:
        logger.error(
            "goal_scheduler.tenant_failed tenant=%s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        return [], True


async def _process_all_tenants(
    service: Any,
    tenant_ids: list[str],
) -> tuple[list[dict[str, Any]], int]:
    """Evaluate all tenants concurrently via asyncio.gather().

    Returns (tenant_results, total_skipped).
    """
    results = await asyncio.gather(
        *[_process_tenant(service, tid) for tid in tenant_ids],
        return_exceptions=False,
    )

    tenant_results: list[dict[str, Any]] = []
    total_skipped = 0
    for tenant_id, (triggered, had_error) in zip(tenant_ids, results):
        if had_error:
            total_skipped += 1
        elif triggered:
            tenant_results.append(
                {
                    "tenant_id": tenant_id,
                    "triggered": len(triggered),
                    "goals": [g["goal_id"] for g in triggered],
                }
            )
    return tenant_results, total_skipped


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """EventBridge-triggered goal scheduler.

    Evaluates all active tenants concurrently and fires
    GoalSchedulerService.evaluate_due_goals() for each, collecting
    per-tenant results into a single summary response.
    """
    _ = event, context
    now = datetime.now(UTC)
    logger.info("goal_scheduler.start ts=%s", now.isoformat())

    from apps.backend.services.scheduling.goal_scheduler import get_goal_scheduler_service

    service = get_goal_scheduler_service()
    tenant_ids = _list_active_tenant_ids()

    tenant_results, total_skipped = asyncio.run(_process_all_tenants(service, tenant_ids))
    total_triggered = sum(r["triggered"] for r in tenant_results)

    summary = {
        "timestamp": now.isoformat(),
        "tenants_evaluated": len(tenant_ids),
        "total_triggered": total_triggered,
        "total_skipped": total_skipped,
        "tenant_results": tenant_results,
    }
    logger.info("goal_scheduler.done %s", summary)

    return {
        "statusCode": 200,
        "body": json.dumps(summary),
    }
