"""
Tenant Lifecycle Lambda (P1.10.4).

Scheduled Lambda that enforces two lifecycle policies:

1. Idle-stop: tenants with runtime.status == 'ready' (RUNNING) and
   last_activity_at > 30 minutes ago are stopped via EC2 stop_instances.
   DynamoDB runtime state is updated to 'stopped' so auth can wake the
   runtime on demand without pretending the endpoint is still hot.

2. Trial auto-destroy: tenants with status == 'trial' and
   created_at > 72 hours ago are terminated via EC2 terminate_instances.
   Route53 DNS records are deleted, DynamoDB status set to 'destroyed'.

Invocation: EventBridge scheduled rule, every 5 minutes.
Environment variables:
    ENVIRONMENT         - 'dev' | 'staging' | 'prod' (default: 'prod', see config/environment.py)
    AWS_REGION          - AWS region (default: 'us-east-1')
    WORKWEAVER_RUNTIME_ROUTE53_ZONE_ID - Route53 hosted zone ID for DNS cleanup
    WORKWEAVER_RUNTIME_TENANT_DOMAIN_SUFFIX - e.g. 'workweaver.ai'
    IDLE_STOP_MINUTES   - idle threshold in minutes (default: 30)
    TRIAL_TTL_HOURS     - trial TTL in hours (default: 72)
"""

from __future__ import annotations

import json
import logging
import os
from apps.backend.utils.time import parse_iso
from datetime import datetime, UTC
from typing import Any

import boto3
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError

from apps.backend.services.tenants_table import resolve_tenants_table_name

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# =============================================================================
# Configuration
# =============================================================================

from apps.backend.config.environment import get_environment

ENVIRONMENT = get_environment()
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
ROUTE53_ZONE_ID = os.getenv("WORKWEAVER_RUNTIME_ROUTE53_ZONE_ID", "").strip()
DOMAIN_SUFFIX = os.getenv("WORKWEAVER_RUNTIME_TENANT_DOMAIN_SUFFIX", "").strip()
IDLE_STOP_MINUTES = int(os.getenv("IDLE_STOP_MINUTES", "30"))
TRIAL_TTL_HOURS = int(os.getenv("TRIAL_TTL_HOURS", "72"))


# =============================================================================
# Internal helpers
# =============================================================================


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _tenants_table_name() -> str:
    return resolve_tenants_table_name()




def _age_minutes(dt: datetime) -> float:
    return (_utcnow() - dt).total_seconds() / 60.0


def _age_hours(dt: datetime) -> float:
    return (_utcnow() - dt).total_seconds() / 3600.0


def _tenant_domain(tenant_id: str) -> str | None:
    if not DOMAIN_SUFFIX:
        return None
    # Strip "TENANT#" prefix for domain construction
    slug = tenant_id.lower().replace("tenant#", "").replace("#", "-")
    return f"{slug}.{DOMAIN_SUFFIX}"


def _delete_route53_record(route53_client: Any, tenant_id: str) -> None:
    """Delete tenant A-record from Route53. Best-effort; logs on failure."""
    if not ROUTE53_ZONE_ID:
        logger.info("Workweaver Runtime ROUTE53_ZONE_ID not set; skipping DNS cleanup for %s", tenant_id)
        return

    domain = _tenant_domain(tenant_id)
    if not domain:
        logger.info("No domain suffix configured; skipping DNS cleanup for %s", tenant_id)
        return

    try:
        # List to find existing record value before deleting
        resp = route53_client.list_resource_record_sets(
            HostedZoneId=ROUTE53_ZONE_ID,
            StartRecordName=domain,
            StartRecordType="A",
            MaxItems="1",
        )
        records = resp.get("ResourceRecordSets", [])
        if not records:
            logger.info("No Route53 A-record found for %s; nothing to delete", domain)
            return

        record = records[0]
        # Confirm it's the right record (Route53 paginates from StartRecordName)
        if record.get("Name", "").rstrip(".") != domain.rstrip("."):
            logger.info("Route53 record name mismatch for %s; skipping", domain)
            return

        route53_client.change_resource_record_sets(
            HostedZoneId=ROUTE53_ZONE_ID,
            ChangeBatch={
                "Comment": f"Lifecycle cleanup for {tenant_id}",
                "Changes": [
                    {
                        "Action": "DELETE",
                        "ResourceRecordSet": record,
                    }
                ],
            },
        )
        logger.info("Deleted Route53 A-record for %s (%s)", tenant_id, domain)
    except ClientError as exc:
        logger.warning("Failed to delete Route53 record for %s: %s", tenant_id, exc)


def _update_tenant_status(
    table: Any,
    tenant_id: str,
    new_status: str,
    extra_attrs: dict[str, Any] | None = None,
) -> None:
    """Update tenant status in DynamoDB."""
    now = _utcnow().isoformat()
    set_parts = ["#st = :st", "updated_at = :ua"]
    attr_names: dict[str, str] = {"#st": "status"}
    attr_values: dict[str, Any] = {":st": new_status, ":ua": now}

    if extra_attrs:
        for i, (k, v) in enumerate(extra_attrs.items()):
            placeholder = f"#extra_{i}"
            value_placeholder = f":extra_{i}"
            set_parts.append(f"{placeholder} = {value_placeholder}")
            attr_names[placeholder] = k
            attr_values[value_placeholder] = v

    table.update_item(
        Key={"pk": tenant_id, "sk": "METADATA"},
        UpdateExpression="SET " + ", ".join(set_parts),
        ExpressionAttributeNames=attr_names,
        ExpressionAttributeValues=attr_values,
    )


def _mark_runtime_idle_stopped(table: Any, tenant_id: str, *, stopped_at: datetime) -> None:
    """Persist the canonical cold-runtime state after an idle stop."""
    now = stopped_at.isoformat()
    table.update_item(
        Key={"pk": tenant_id, "sk": "METADATA"},
        UpdateExpression=(
            "SET #rt.#st = :runtime_status, "
            "#rt.#step = :runtime_step, "
            "#rt.#chk = :checked_at, "
            "#rt.#idle = :idle_stopped_at, "
            "updated_at = :ua "
            "REMOVE #rt.#err"
        ),
        ExpressionAttributeNames={
            "#rt": "runtime",
            "#st": "status",
            "#step": "step",
            "#chk": "checked_at",
            "#idle": "idle_stopped_at",
            "#err": "last_error",
        },
        ExpressionAttributeValues={
            ":runtime_status": "stopped",
            ":runtime_step": "idle_stopped",
            ":checked_at": now,
            ":idle_stopped_at": now,
            ":ua": now,
        },
    )


def _get_runtime_instance_id(item: dict[str, Any]) -> str | None:
    """Extract EC2 instance ID from nested runtime map."""
    runtime = item.get("runtime")
    if not isinstance(runtime, dict):
        return None
    return runtime.get("instance_id") or None


def _get_runtime_status(item: dict[str, Any]) -> str:
    """Extract runtime.status from tenant item."""
    runtime = item.get("runtime")
    if not isinstance(runtime, dict):
        return ""
    return (runtime.get("status") or "").lower()


def _scan_all(table: Any, filter_expr: Any, projection: str) -> list[dict[str, Any]]:
    """Full DynamoDB scan with pagination."""
    items: list[dict[str, Any]] = []
    kwargs: dict[str, Any] = {
        "FilterExpression": filter_expr,
        "ProjectionExpression": projection,
        "ExpressionAttributeNames": {"#st": "status"},
    }
    for _ in range(100):  # guard against infinite loops
        resp = table.scan(**kwargs)
        items.extend(resp.get("Items", []))
        last_key = resp.get("LastEvaluatedKey")
        if not last_key:
            break
        kwargs["ExclusiveStartKey"] = last_key
    return items


# =============================================================================
# Policy: Idle-stop
# =============================================================================

_RUNNING_STATUSES = {"running", "active", "ready"}

PROJECTION_IDLE = "pk, sk, tenant_id, #st, runtime, last_activity_at"


def _process_idle_stops(
    table: Any,
    ec2_client: Any,
    threshold_minutes: int = IDLE_STOP_MINUTES,
) -> list[dict[str, Any]]:
    """
    Scan for tenants whose Workweaver Runtime instance is RUNNING and last activity
    exceeds threshold_minutes. Stop the EC2 instance and update DynamoDB.

    Returns list of action records for the summary.
    """
    actions: list[dict[str, Any]] = []

    # Scan for tenants in running-like states
    filter_expr = Attr("sk").eq("METADATA") & Attr("#st").is_in(list(_RUNNING_STATUSES))

    items = _scan_all(table, filter_expr, PROJECTION_IDLE)
    logger.info("Idle-stop scan: %d candidates", len(items))

    now = _utcnow()

    for item in items:
        tenant_id: str = item.get("pk") or item.get("tenant_id") or ""
        if not tenant_id:
            continue

        # Only act on tenants whose Workweaver Runtime gateway reports ready/running
        runtime_status = _get_runtime_status(item)
        if runtime_status not in {"ready", "running", "active"}:
            logger.debug(
                "Tenant %s runtime.status=%s — not running; skipping idle-stop",
                tenant_id,
                runtime_status,
            )
            continue

        # Check last_activity_at
        last_activity_raw: str | None = item.get("last_activity_at")
        last_activity = parse_iso(last_activity_raw)

        if last_activity is None:
            # No activity timestamp — use DynamoDB updated_at as proxy
            last_activity = parse_iso(item.get("updated_at"))

        if last_activity is None:
            logger.debug("Tenant %s has no activity timestamp; skipping", tenant_id)
            continue

        idle_minutes = (now - last_activity).total_seconds() / 60.0
        if idle_minutes < threshold_minutes:
            logger.debug(
                "Tenant %s idle for %.1f min (threshold=%d min); not stopping",
                tenant_id,
                idle_minutes,
                threshold_minutes,
            )
            continue

        instance_id = _get_runtime_instance_id(item)
        if not instance_id:
            logger.warning(
                "Tenant %s qualifies for idle-stop but has no instance_id; skipping EC2 call",
                tenant_id,
            )
            continue

        # Stop the EC2 instance
        try:
            ec2_client.stop_instances(InstanceIds=[instance_id])
            logger.info(
                "Idle-stop: stopped EC2 instance %s for tenant %s (idle=%.1f min)",
                instance_id,
                tenant_id,
                idle_minutes,
            )
        except ClientError as exc:
            logger.error(
                "Failed to stop EC2 instance %s for tenant %s: %s",
                instance_id,
                tenant_id,
                exc,
            )
            actions.append(
                {
                    "action": "idle_stop_failed",
                    "tenant_id": tenant_id,
                    "instance_id": instance_id,
                    "idle_minutes": round(idle_minutes, 1),
                    "error": str(exc),
                }
            )
            continue

        # Persist the cold-runtime state without deactivating the tenant.
        try:
            _mark_runtime_idle_stopped(table, tenant_id, stopped_at=now)
        except ClientError as exc:
            logger.error(
                "Stopped EC2 instance %s but failed to update DynamoDB for %s: %s",
                instance_id,
                tenant_id,
                exc,
            )
            actions.append(
                {
                    "action": "idle_stop_dynamo_failed",
                    "tenant_id": tenant_id,
                    "instance_id": instance_id,
                    "error": str(exc),
                }
            )
            continue

        actions.append(
            {
                "action": "idle_stopped",
                "tenant_id": tenant_id,
                "instance_id": instance_id,
                "idle_minutes": round(idle_minutes, 1),
            }
        )

    return actions


# =============================================================================
# Policy: Trial auto-destroy
# =============================================================================

PROJECTION_TRIAL = "pk, sk, tenant_id, #st, runtime, created_at"


def _process_trial_destructions(
    table: Any,
    ec2_client: Any,
    route53_client: Any,
    ttl_hours: int = TRIAL_TTL_HOURS,
) -> list[dict[str, Any]]:
    """
    Scan for trial tenants older than ttl_hours. Terminate EC2 instance,
    clean up Route53, and update DynamoDB to 'destroyed'.

    Returns list of action records for the summary.
    """
    actions: list[dict[str, Any]] = []

    filter_expr = Attr("sk").eq("METADATA") & Attr("#st").eq("trial")
    items = _scan_all(table, filter_expr, PROJECTION_TRIAL)
    logger.info("Trial auto-destroy scan: %d trial tenants", len(items))

    now = _utcnow()

    for item in items:
        tenant_id: str = item.get("pk") or item.get("tenant_id") or ""
        if not tenant_id:
            continue

        created_at = parse_iso(item.get("created_at"))
        if created_at is None:
            logger.warning("Trial tenant %s has no created_at; skipping", tenant_id)
            continue

        age_hours = (now - created_at).total_seconds() / 3600.0
        if age_hours < ttl_hours:
            logger.debug(
                "Trial tenant %s age=%.1f hours (TTL=%d hours); not destroying",
                tenant_id,
                age_hours,
                ttl_hours,
            )
            continue

        instance_id = _get_runtime_instance_id(item)

        # Terminate EC2 instance (if one exists)
        if instance_id:
            try:
                ec2_client.terminate_instances(InstanceIds=[instance_id])
                logger.info(
                    "Trial auto-destroy: terminated EC2 instance %s for tenant %s (age=%.1f hours)",
                    instance_id,
                    tenant_id,
                    age_hours,
                )
            except ClientError as exc:
                logger.error(
                    "Failed to terminate EC2 instance %s for tenant %s: %s",
                    instance_id,
                    tenant_id,
                    exc,
                )
                actions.append(
                    {
                        "action": "trial_destroy_ec2_failed",
                        "tenant_id": tenant_id,
                        "instance_id": instance_id,
                        "age_hours": round(age_hours, 2),
                        "error": str(exc),
                    }
                )
                continue
        else:
            logger.info(
                "Trial tenant %s has no EC2 instance; proceeding to DNS + DynamoDB cleanup",
                tenant_id,
            )

        # Delete Route53 DNS record
        _delete_route53_record(route53_client, tenant_id)

        # Update DynamoDB to destroyed
        try:
            _update_tenant_status(
                table,
                tenant_id,
                "destroyed",
                extra_attrs={"trial_destroyed_at": now.isoformat()},
            )
        except ClientError as exc:
            logger.error(
                "Terminated EC2 for %s but failed to update DynamoDB: %s",
                tenant_id,
                exc,
            )
            actions.append(
                {
                    "action": "trial_destroy_dynamo_failed",
                    "tenant_id": tenant_id,
                    "instance_id": instance_id,
                    "error": str(exc),
                }
            )
            continue

        actions.append(
            {
                "action": "trial_destroyed",
                "tenant_id": tenant_id,
                "instance_id": instance_id,
                "age_hours": round(age_hours, 2),
            }
        )

    return actions


# =============================================================================
# Lambda Handler
# =============================================================================


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """
    Tenant lifecycle Lambda entry point.

    Triggered by EventBridge on a schedule (e.g., every 5 minutes).

    Returns:
        {
            "statusCode": 200,
            "body": {
                "idle_stopped": [...],
                "trial_destroyed": [...],
                "errors": [...]
            }
        }
    """
    table_name = _tenants_table_name()
    logger.info(
        "Tenant lifecycle Lambda invoked — env=%s table=%s idle_threshold=%dmin trial_ttl=%dh",
        ENVIRONMENT,
        table_name,
        IDLE_STOP_MINUTES,
        TRIAL_TTL_HOURS,
    )

    dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
    table = dynamodb.Table(table_name)
    ec2_client = boto3.client("ec2", region_name=AWS_REGION)
    route53_client = boto3.client("route53")

    idle_actions: list[dict[str, Any]] = []
    trial_actions: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    # --- Policy 1: Idle-stop ---
    try:
        idle_actions = _process_idle_stops(table, ec2_client)
    except Exception as exc:
        logger.error("Idle-stop policy failed: %s", exc, exc_info=True)
        errors.append({"policy": "idle_stop", "error": str(exc)})

    # --- Policy 2: Trial auto-destroy ---
    try:
        trial_actions = _process_trial_destructions(table, ec2_client, route53_client)
    except Exception as exc:
        logger.error("Trial auto-destroy policy failed: %s", exc, exc_info=True)
        errors.append({"policy": "trial_destroy", "error": str(exc)})

    # Separate successes from per-item errors
    idle_stopped = [a for a in idle_actions if a["action"] == "idle_stopped"]
    trial_destroyed = [a for a in trial_actions if a["action"] == "trial_destroyed"]
    per_item_errors = (
        [a for a in idle_actions if "failed" in a["action"]]
        + [a for a in trial_actions if "failed" in a["action"]]
        + errors
    )

    summary = {
        "idle_stopped": idle_stopped,
        "trial_destroyed": trial_destroyed,
        "errors": per_item_errors,
    }

    logger.info(
        "Lifecycle run complete — idle_stopped=%d trial_destroyed=%d errors=%d",
        len(idle_stopped),
        len(trial_destroyed),
        len(per_item_errors),
    )

    return {
        "statusCode": 200,
        "body": json.dumps(summary),
    }


# =============================================================================
# Development Entry Point
# =============================================================================

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.DEBUG)
    result = handler({}, None)
    print(json.dumps(json.loads(result["body"]), indent=2))
    sys.exit(0 if not json.loads(result["body"])["errors"] else 1)
