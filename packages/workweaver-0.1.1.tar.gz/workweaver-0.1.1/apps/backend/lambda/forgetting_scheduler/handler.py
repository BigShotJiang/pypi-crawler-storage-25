"""EventBridge-triggered scheduler for WorkMemory forgetting maintenance."""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from urllib.parse import urlparse

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _require_env(name: str) -> str:
    value = str(os.environ.get(name) or "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _require_https(url: str) -> str:
    """#370: enforce https scheme on LEARNING_SERVICE_URL (bandit B310).

    The URL comes from env so its scheme cannot be verified statically.
    Reject anything that isn't https before handing to urlopen.
    """
    scheme = urlparse(url).scheme.lower()
    if scheme != "https":
        raise RuntimeError(f"LEARNING_SERVICE_URL must be https, got {scheme!r}")
    return url


def lambda_handler(event: dict | None, _context) -> dict[str, object]:
    url = _require_https(_require_env("LEARNING_SERVICE_URL"))
    internal_token = _require_env("WORKMEMORY_INTERNAL_TOKEN")
    timeout_seconds = float(str(os.environ.get("REQUEST_TIMEOUT_SECONDS") or "60").strip())

    payload = {
        "dry_run": bool((event or {}).get("dry_run", False)),
        "source": "eventbridge_forgetting_scheduler",
    }
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-workmemory-internal-token": internal_token,
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:  # noqa: S310  # nosec B310
            body_text = response.read().decode("utf-8", errors="replace")
            body = json.loads(body_text) if body_text else {}
            logger.info("Forgetting maintenance completed: status=%s", response.status)
            return {
                "ok": True,
                "status_code": response.status,
                "body": body,
            }
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode("utf-8", errors="replace")
        logger.error("Forgetting maintenance failed: status=%s body=%s", exc.code, body_text)
        raise RuntimeError(f"Forgetting maintenance failed with HTTP {exc.code}: {body_text}") from exc
