"""
Lambda Worker for Document Processing (P1.7D.1).

Async Lambda function that processes documents from SQS queue:
- Downloads document from S3
- Extracts text using DocumentProcessor
- Extracts facts and stores in Learning Service
- Updates metadata in DynamoDB
- Logs events to Operational Context
"""
from apps.backend.config.table_names import resolve_table

import json
import logging
import os
from typing import Any

from apps.backend.services.document_processor import DocumentProcessor, DocumentFormat

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================


S3_BUCKET_NAME = os.environ.get("S3_BUCKET_NAME", "workweaver-documents-dev")
DYNAMODB_TABLE_NAME = resolve_table("document_state", env_var="DYNAMODB_TABLE_NAME", default_short_name="state")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")


# =============================================================================
# Lambda Handler
# =============================================================================


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """
    Lambda handler for document processing.

    Processes SQS messages containing document metadata:
    {
        "tenant_id": "TENANT#...",
        "user_id": "USER#...",
        "s3_key": "uploads/...",
        "format": "pdf|docx|txt"
    }

    Args:
        event: Lambda event (SQS records)
        context: Lambda context

    Returns:
        Response with status code and body
    """
    try:
        # Process each SQS record
        results = []
        failures = []

        for record in event.get("Records", []):
            try:
                # Parse message body
                message = json.loads(record["body"])

                tenant_id = message["tenant_id"]
                user_id = message["user_id"]
                s3_key = message["s3_key"]
                format_str = message["format"]

                # Convert format string to enum
                try:
                    document_format = DocumentFormat(format_str)
                except ValueError:
                    raise ValueError(f"Invalid document format: {format_str}")

                # Create processor
                processor = DocumentProcessor(
                    s3_bucket_name=S3_BUCKET_NAME,
                    dynamodb_table_name=DYNAMODB_TABLE_NAME,
                    region=AWS_REGION,
                )

                # Process document
                result = processor.process_document(
                    tenant_id=tenant_id,
                    user_id=user_id,
                    s3_key=s3_key,
                    format=document_format,
                )

                results.append(
                    {
                        "s3_key": s3_key,
                        "status": result["status"],
                        "text_length": result["text_length"],
                        "facts_extracted": result["facts_extracted"],
                    }
                )

            except Exception as e:
                # Log failure but continue processing other records
                failures.append(
                    {
                        "s3_key": message.get("s3_key", "unknown"),
                        "error": str(e),
                    }
                )
                logger.error(f"Error processing document: {e}")

        # Return response
        response = {
            "statusCode": 200,
            "body": json.dumps(
                {
                    "processed": len(results),
                    "failed": len(failures),
                    "results": results,
                    "failures": failures,
                }
            ),
        }

        return response

    except Exception as e:
        # Catastrophic error (e.g., JSON parse failure)
        logger.error(f"Lambda handler error: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps(
                {
                    "error": str(e),
                    "message": "Failed to process Lambda event",
                }
            ),
        }


# =============================================================================
# Development Entry Point
# =============================================================================


if __name__ == "__main__":
    """
    Development entry point for local testing.

    Usage:
        python -m apps.backend.lambda.document_worker.handler
    """
    import sys

    # Sample event for testing
    sample_event = {
        "Records": [
            {
                "body": json.dumps(
                    {
                        "tenant_id": "TENANT#test-tenant-123",
                        "user_id": "USER#test-user-456",
                        "s3_key": "uploads/test.txt",
                        "format": "txt",
                    }
                )
            }
        ]
    }

    # Allow custom event from command line
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            sample_event = json.load(f)

    result = handler(sample_event, None)
    print(json.dumps(result, indent=2))
