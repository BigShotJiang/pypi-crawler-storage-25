"""ECS Task Definition Lifecycle Lambda (#797).

Nightly maintenance Lambda that enforces a retention policy of "latest
5 active revisions per task definition family". Older revisions are
deregistered (moved to INACTIVE — AWS does not allow true deletion).

Revisions actively referenced by any ECS service in any cluster are
ALWAYS kept regardless of age, so a stale-but-still-running revision
is never accidentally deregistered out from under a service.

Invocation: EventBridge scheduled rule, daily at 04:00 UTC.

Environment variables:
    ENVIRONMENT     - 'dev' | 'staging' | 'prod' (default: 'prod')
    AWS_REGION      - AWS region (default: 'us-east-1')
    KEEP_LATEST_N   - revisions per family to retain (default: 5)
    DRY_RUN         - 'true' to skip the actual deregister calls
                       (still emits the would-be summary)
"""

from __future__ import annotations

import logging
import os
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# =============================================================================
# Configuration
# =============================================================================

ENVIRONMENT = os.getenv("ENVIRONMENT", "prod")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
KEEP_LATEST_N = int(os.getenv("KEEP_LATEST_N", "5"))
DRY_RUN = os.getenv("DRY_RUN", "false").strip().lower() in ("1", "true", "yes")


# =============================================================================
# Internal helpers
# =============================================================================


def _list_active_families(ecs: Any) -> list[str]:
    """Return all task definition families with at least one ACTIVE revision."""
    families: list[str] = []
    paginator = ecs.get_paginator("list_task_definition_families")
    for page in paginator.paginate(status="ACTIVE"):
        families.extend(page.get("families", []))
    return families


def _list_active_revisions(ecs: Any, family: str) -> list[str]:
    """Return all ACTIVE task definition ARNs for a family, sorted DESC.

    Sort=DESC means index 0 is the newest revision.
    """
    arns: list[str] = []
    paginator = ecs.get_paginator("list_task_definitions")
    for page in paginator.paginate(familyPrefix=family, status="ACTIVE", sort="DESC"):
        arns.extend(page.get("taskDefinitionArns", []))
    return arns


def _collect_in_use_arns(ecs: Any) -> set[str]:
    """Return the set of task definition ARNs referenced by any service in any cluster.

    Walks every cluster + every service. Should be cheap for our scale (<100
    services total). If this Lambda ever sees more, batch describe_services
    in chunks of 10 (the AWS limit).
    """
    in_use: set[str] = set()
    cluster_paginator = ecs.get_paginator("list_clusters")
    for page in cluster_paginator.paginate():
        for cluster_arn in page.get("clusterArns", []):
            service_paginator = ecs.get_paginator("list_services")
            for service_page in service_paginator.paginate(cluster=cluster_arn):
                service_arns = service_page.get("serviceArns", [])
                for chunk_start in range(0, len(service_arns), 10):
                    chunk = service_arns[chunk_start : chunk_start + 10]
                    if not chunk:
                        continue
                    desc = ecs.describe_services(cluster=cluster_arn, services=chunk)
                    for svc in desc.get("services", []):
                        td = svc.get("taskDefinition")
                        if td:
                            in_use.add(td)
    return in_use


def _deregister_safely(ecs: Any, arn: str) -> bool:
    """Deregister an ARN. Returns True on success, False on AWS error.

    Errors are logged and swallowed so that one bad family does not abort
    the whole nightly run.
    """
    if DRY_RUN:
        logger.info("dry_run_skip_deregister arn=%s", arn)
        return True
    try:
        ecs.deregister_task_definition(taskDefinition=arn)
        return True
    except (ClientError, BotoCoreError) as exc:
        logger.error("deregister_failed arn=%s error=%s", arn, exc)
        return False


# =============================================================================
# Entry point
# =============================================================================


def lambda_handler(event: dict | None, _context: Any) -> dict[str, Any]:
    """EventBridge entry point.

    Returns a summary dict suitable for CloudWatch logging and downstream
    audit. Never raises — errors are logged per family + per ARN.
    """
    ecs = boto3.client("ecs", region_name=AWS_REGION)

    families = _list_active_families(ecs)
    in_use = _collect_in_use_arns(ecs)
    logger.info(
        "ecs_taskdef_lifecycle_start families=%d in_use_total=%d keep_latest_n=%d dry_run=%s",
        len(families),
        len(in_use),
        KEEP_LATEST_N,
        DRY_RUN,
    )

    families_processed = 0
    revisions_kept = 0
    revisions_deregistered = 0
    errors: list[dict[str, str]] = []

    for family in families:
        families_processed += 1
        try:
            active_arns = _list_active_revisions(ecs, family)
        except (ClientError, BotoCoreError) as exc:
            logger.error("list_revisions_failed family=%s error=%s", family, exc)
            errors.append({"family": family, "phase": "list", "error": str(exc)})
            continue

        # Keep the newest N revisions plus any in-use ARN regardless of age.
        keep = set(active_arns[:KEEP_LATEST_N]) | (in_use & set(active_arns))
        to_deregister = [arn for arn in active_arns if arn not in keep]
        revisions_kept += len(keep)

        if not to_deregister:
            continue

        for arn in to_deregister:
            if _deregister_safely(ecs, arn):
                revisions_deregistered += 1
            else:
                errors.append({"family": family, "phase": "deregister", "error": arn})

    summary = {
        "families_processed": families_processed,
        "revisions_kept": revisions_kept,
        "revisions_deregistered": revisions_deregistered,
        "in_use_total": len(in_use),
        "errors": errors,
        "dry_run": DRY_RUN,
    }
    logger.info("ecs_taskdef_lifecycle_complete %s", summary)
    return summary
