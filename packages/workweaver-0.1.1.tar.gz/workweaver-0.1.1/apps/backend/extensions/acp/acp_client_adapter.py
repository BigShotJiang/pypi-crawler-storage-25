"""ACPClientBridge -- provider bridge for consuming external ACP agents.

This module contains the request/response, evidence, metering, replay, and
fallback scaffold for external ACP providers. ``ACPClientBridge._invoke_provider()``
dispatches to real provider transports via JSON-RPC 2.0 over stdio (claude_code,
codex) or HTTP+SSE (gemini).

Implemented today:
  - Emits evidence receipts for every invocation
  - Tracks metering alongside native inference (4 UsageMetricType values)
  - Stores replay entries for audit
  - Records fallback when provider invocation fails
  - JSON-RPC 2.0 stdio transport for claude_code and codex providers
  - HTTP+SSE transport skeleton for gemini (credential-gated)

Contract reference: docs/reference/runtime/acp-contracts.md
"""

from __future__ import annotations

import hashlib
import json
import logging
import subprocess  # noqa: S404 -- intentional: outbound ACP over stdio
import time
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

# JSON-RPC 2.0 error codes (mirrors acp_daemon.py)
_JSONRPC_INTERNAL_ERROR = -32603

# Provider-to-executable defaults (override via ACPEndpoint.executable)
_PROVIDER_EXECUTABLES: dict[str, list[str]] = {
    "claude_code": ["claude"],
    "codex": ["codex", "--skip-git-repo-check"],
    "gemini": [],  # HTTP transport; no stdio executable
}

# Default subprocess timeout in seconds
_DEFAULT_STDIO_TIMEOUT_SECONDS = 120


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class ACPProvider(str, Enum):
    """Supported external ACP providers."""

    CLAUDE_CODE = "claude_code"
    CLAUDE_AGENT_SDK = "claude_agent_sdk"
    OPENAI_AGENTS = "openai_agents"
    CURSOR = "cursor"
    CODEX = "codex"
    GEMINI = "gemini"


class ACPFallbackPolicy(str, Enum):
    """Fallback policy when ACP provider fails.

    - NATIVE_FIRST: Route to native inference resolver (default).
    - FAIL_FAST: Raise the error to the caller.
    """

    NATIVE_FIRST = "native_first"
    FAIL_FAST = "fail_fast"


# ---------------------------------------------------------------------------
# Endpoint / credential config
# ---------------------------------------------------------------------------


class ACPEndpoint(BaseModel):
    """Per-tenant configuration for one external ACP endpoint.

    Tenant config schema gains ``acp_external_endpoints: list[ACPEndpoint]``
    per issue #2176.
    """

    model_config = ConfigDict(frozen=True)

    endpoint_url: str = ""
    """HTTP base URL for HTTP-transport providers (gemini). Empty for stdio providers."""

    protocol_version: str = "1.0"
    """ACP protocol version advertised during initialize handshake."""

    credential_ref: str = ""
    """Reference to the tenant secret store key holding the API credential."""

    default_model: str = ""
    """Default model name to advertise when no explicit model is requested."""

    executable: list[str] = []
    """Override executable argv for stdio providers. Empty uses provider default."""

    timeout_seconds: float = float(_DEFAULT_STDIO_TIMEOUT_SECONDS)
    """Per-request timeout. Honoured by both stdio and HTTP transports."""

    permission_mode: str | None = None
    """Claude Agent SDK permission_mode passed through to ClaudeAgentOptions."""

    sdk_allowed_tools: list[str] = Field(default_factory=list)
    """Claude Agent SDK tools to auto-approve; does not limit availability."""

    sdk_disallowed_tools: list[str] = Field(default_factory=list)
    """Claude Agent SDK tools to deny before permission mode/callback evaluation."""


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ACPRequest(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    tenant_id: str
    provider: ACPProvider
    prompt: str
    max_tokens: int = 4096
    emits_decision_trace: bool = True
    """Tool-manifest declaration: True when the external provider already emits
    a Decision Trace natively, False when the bridge must auto-wrap the call
    in TraceSynthesis (PRODUCT-CONTEXT.md §15 ObserverProxy mode)."""

    sdk_options: dict[str, Any] = Field(default_factory=dict)
    """Provider-specific SDK options such as sub-agent definitions and MCP tool filters."""


class ACPResponse(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    provider: ACPProvider
    content: str
    tokens_used: int
    elapsed_ms: int
    timestamp: datetime


# ---------------------------------------------------------------------------
# Pydantic models for bridge artifacts
# ---------------------------------------------------------------------------


class ACPInvocation(BaseModel):
    """Canonical record of an ACP provider invocation."""

    request_id: str
    tenant_id: str
    provider: ACPProvider
    prompt: str
    max_tokens: int = 4096
    timestamp: datetime


class ACPEvidenceReceipt(BaseModel):
    """Evidence receipt emitted for every ACP invocation.

    Maps to EvidenceLedgerService.ingest fields per acp-contracts.md section 2.
    """

    evidence_id: str
    request_id: str
    provider: ACPProvider
    prompt_hash: str
    tokens_used: int
    elapsed_ms: int
    outcome: str  # success | error | timeout | fallback
    session_id: str
    risk_level: str  # low | medium | high
    actor_path: str = "acp_client"
    fallback_reason: str | None = None
    synthesized_trace_id: str | None = None
    """When set, the ACP invocation was wrapped in TraceSynthesis because the
    tool manifest declared ``emits_decision_trace=False``.  Links the
    evidence record to the synthesized trace so WorkMemory/Decision Trace
    audit can resolve the surrogate (PRODUCT-CONTEXT.md §15)."""


class ACPMeteringRecord(BaseModel):
    """Metering record for an ACP invocation.

    Tracks 4 UsageMetricType values per acp-contracts.md section 3.
    """

    tenant_id: str
    request_id: str
    provider: ACPProvider
    tokens_in: int
    tokens_out: int
    tool_calls_total: int
    tool_calls_failed: int
    timestamp: datetime


class ACPReplayEntry(BaseModel):
    """Replay entry for audit -- stored in ACPStore.

    Per acp-contracts.md section 4: all invocations and responses stored
    for audit and replay.
    """

    request_id: str
    tenant_id: str
    provider: ACPProvider
    prompt_hash: str
    content: str
    tokens_used: int
    elapsed_ms: int
    timestamp: datetime


# ---------------------------------------------------------------------------
# Store protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ACPStore(Protocol):
    def save_response(self, resp: ACPResponse) -> None: ...
    def get_response(self, request_id: str) -> ACPResponse | None: ...


class InMemoryACPStore:
    def __init__(self) -> None:
        self._responses: dict[str, ACPResponse] = {}

    def save_response(self, resp: ACPResponse) -> None:
        self._responses[resp.request_id] = resp

    def get_response(self, request_id: str) -> ACPResponse | None:
        return self._responses.get(request_id)


# ---------------------------------------------------------------------------
# Invocation result
# ---------------------------------------------------------------------------


@dataclass
class ACPInvocationResult:
    """Aggregated result from an ACP invocation through the bridge."""

    response: ACPResponse
    receipt: ACPEvidenceReceipt
    metering: ACPMeteringRecord
    replay: ACPReplayEntry
    synthesized_trace_id: str | None = None
    """Set when the call was auto-wrapped by ``TraceSynthesisService`` because
    ``request.emits_decision_trace=False``.  ``None`` for native-emitting
    providers."""


# ---------------------------------------------------------------------------
# Evidence service protocol
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 stdio helpers
# ---------------------------------------------------------------------------


def _build_jsonrpc_request(method: str, params: dict[str, Any], *, req_id: str) -> str:
    """Serialize a JSON-RPC 2.0 request to a single newline-terminated line."""
    return json.dumps({"jsonrpc": "2.0", "method": method, "params": params, "id": req_id}) + "\n"


def _parse_jsonrpc_response(line: str) -> dict[str, Any]:
    """Parse one newline-delimited JSON-RPC 2.0 response line.

    Raises ``RuntimeError`` when the response carries a JSON-RPC error.
    """
    payload = json.loads(line)
    if not isinstance(payload, dict):
        raise RuntimeError(f"ACP provider returned non-object: {line!r}")
    if "error" in payload:
        err = payload["error"]
        code = err.get("code", _JSONRPC_INTERNAL_ERROR) if isinstance(err, dict) else _JSONRPC_INTERNAL_ERROR
        msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
        raise RuntimeError(f"ACP provider error [{code}]: {msg}")
    return payload.get("result") or {}


def _stdio_jsonrpc_call(
    *,
    executable: list[str],
    method: str,
    params: dict[str, Any],
    req_id: str,
    timeout_seconds: float,
) -> dict[str, Any]:
    """Run a single JSON-RPC 2.0 request over stdio to an ACP-compliant subprocess.

    The subprocess receives one newline-delimited request on stdin and must
    respond with one newline-delimited response on stdout (matching the ACP
    daemon wire format). The process is given ``timeout_seconds`` to reply.

    Returns the ``result`` dict from the JSON-RPC response.
    Raises ``RuntimeError`` on error responses and ``TimeoutError`` on timeout.
    """
    request_line = _build_jsonrpc_request(method, params, req_id=req_id)
    try:
        proc = subprocess.run(  # noqa: S603 -- argv supplied by caller after validation
            executable,
            input=request_line,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(
            f"ACP provider subprocess timed out after {timeout_seconds}s"
        ) from exc

    stdout = proc.stdout.strip()
    if not stdout:
        raise RuntimeError(
            f"ACP provider subprocess produced no output "
            f"(exit={proc.returncode}, stderr={proc.stderr.strip()!r})"
        )

    # Take the last non-empty line — some providers emit initialize ack first.
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if line:
            return _parse_jsonrpc_response(line)

    raise RuntimeError(f"ACP provider subprocess stdout had no parseable lines: {stdout!r}")


# ---------------------------------------------------------------------------
# Bridge
# ---------------------------------------------------------------------------


class ACPClientBridge:
    """Bridge for consuming external ACP providers via JSON-RPC 2.0.

    Each invoke() call:
      1. Attempts the ACP provider via _invoke_provider()
      2. Emits an evidence receipt (synchronous)
      3. Records metering (4 UsageMetricType values)
      4. Stores a replay entry for audit

    Provider transports:
      - claude_code / codex: JSON-RPC 2.0 over stdio (subprocess).
      - gemini: JSON-RPC 2.0 over HTTP+SSE (credential-gated; falls back when
        no credential_ref is configured).

    Pass an ``ACPEndpoint`` via ``endpoint`` to override defaults per tenant.
    """

    def __init__(
        self,
        store: ACPStore,
        evidence_service: Any,
        usage_tracker: Any,
        fallback_policy: ACPFallbackPolicy = ACPFallbackPolicy.NATIVE_FIRST,
        endpoint: ACPEndpoint | None = None,
        *,
        trace_synthesis: Any | None = None,
        decision_capture_service: Any | None = None,
        claude_agent_sdk_module: Any | None = None,
        openai_agents_module: Any | None = None,
        cursor_http_client: Any | None = None,
        _stdio_transport: Any | None = None,
    ) -> None:
        self._store = store
        self._evidence_service = evidence_service
        self._usage_tracker = usage_tracker
        self._fallback_policy = fallback_policy
        self._endpoint = endpoint or ACPEndpoint()
        # Injectable transport for testing; defaults to module-level function.
        self._stdio_transport = _stdio_transport or _stdio_jsonrpc_call
        # Optional TraceSynthesisService — when wired, requests with
        # emits_decision_trace=False are auto-wrapped to produce a
        # SynthesizedTrace stand-in for the missing native Decision Trace
        # (PRODUCT-CONTEXT.md §15 ObserverProxy mode).
        self._trace_synthesis = trace_synthesis
        self._decision_capture_service = decision_capture_service
        self._claude_agent_sdk_module = claude_agent_sdk_module
        self._openai_agents_module = openai_agents_module
        self._cursor_http_client = cursor_http_client

    # -- Public API ----------------------------------------------------------

    def invoke(self, request: ACPRequest) -> ACPInvocationResult:
        """Invoke an external ACP provider and return the full result.

        On provider failure, applies the fallback policy:
        - NATIVE_FIRST: returns a synthesized native response
        - FAIL_FAST: re-raises the provider exception

        When ``request.emits_decision_trace=False`` and a
        ``TraceSynthesisService`` is wired into the bridge, the underlying
        provider call is auto-wrapped via ``TraceSynthesisService.wrap_call``
        so the synthesized trace becomes the Decision Trace surrogate
        (PRODUCT-CONTEXT.md §15).
        """
        session_id = str(uuid.uuid4())
        prompt_hash = hashlib.sha256(request.prompt.encode()).hexdigest()
        synthesized_trace_id: str | None = None

        try:
            response, synthesized_trace_id = self._invoke_with_optional_synthesis(
                request
            )
            outcome = "success"
            fallback_reason: str | None = None
        except (TimeoutError,) as exc:
            fallback_reason = "timeout"
            response = self._handle_fallback(request, exc, "timeout")
            outcome = "fallback"
        except Exception as exc:
            fallback_reason = "error"
            response = self._handle_fallback(request, exc, "error")
            outcome = "fallback"

        # Emit evidence receipt — synthesized_trace_id is woven into the
        # ledger payload so WorkMemory can resolve the surrogate trace.
        receipt = self._produce_evidence_receipt(
            request=request,
            response=response,
            prompt_hash=prompt_hash,
            outcome=outcome,
            fallback_reason=fallback_reason,
            session_id=session_id,
            synthesized_trace_id=synthesized_trace_id,
        )

        # Record metering
        metering = self._track_metering(
            request=request,
            response=response,
            failed=(outcome != "success"),
        )

        # Store replay entry
        replay = self._store_replay(
            request=request,
            response=response,
            prompt_hash=prompt_hash,
        )

        # Persist response to store
        self._store.save_response(response)

        return ACPInvocationResult(
            response=response,
            receipt=receipt,
            metering=metering,
            replay=replay,
            synthesized_trace_id=synthesized_trace_id,
        )

    def get_response(self, request_id: str) -> ACPResponse | None:
        """Retrieve a previously stored response by request_id."""
        return self._store.get_response(request_id)

    # -- TraceSynthesis auto-wrap -------------------------------------------

    def _invoke_with_optional_synthesis(
        self, request: ACPRequest
    ) -> tuple[ACPResponse, str | None]:
        """Dispatch to ``_invoke_provider`` with optional TraceSynthesis wrap.

        Auto-wraps when ``request.emits_decision_trace=False`` AND a
        ``TraceSynthesisService`` is wired into the bridge.  Otherwise dispatches
        directly so native-emitting providers are not double-instrumented.

        Returns the resolved response and the synthesized trace id (``None``
        when no wrap was performed).

        Authorship: the caller actor_path is encoded in the evidence ledger
        record (``actor_path="acp_client"``) which carries the
        ``synthesized_trace_id`` cross-reference; the trace itself records
        ``tool_id="acp:<provider>"`` so audit can resolve the upstream
        external runtime.
        """
        if request.emits_decision_trace or self._trace_synthesis is None:
            return self._invoke_provider(request), None

        captured: dict[str, Any] = {}

        def _runner(_input: Any) -> dict[str, Any]:
            try:
                response = self._invoke_provider(request)
            except BaseException as exc:
                captured["error"] = exc
                raise
            captured["response"] = response
            return {
                "request_id": response.request_id,
                "tokens_used": response.tokens_used,
                "elapsed_ms": response.elapsed_ms,
                "content_length": len(response.content),
            }

        trace = self._trace_synthesis.wrap_call(
            workspace_id=request.tenant_id,
            tool_id=f"acp:{request.provider.value}",
            input_data={
                "request_id": request.request_id,
                "prompt_hash": hashlib.sha256(request.prompt.encode()).hexdigest(),
                "max_tokens": request.max_tokens,
                "actor_path": "acp_client",
                "provider": request.provider.value,
            },
            callable_fn=_runner,
        )

        if "response" not in captured:
            # ``wrap_call`` swallowed an exception inside the runner; surface
            # the original so the bridge's fallback path applies (the synthesis
            # service has already recorded a TOOL_ERROR trace for audit).
            err = captured.get("error")
            if isinstance(err, BaseException):
                raise err
            raise RuntimeError(
                f"ACP TraceSynthesis runner produced no response "
                f"(trace_id={trace.trace_id})"
            )

        return captured["response"], trace.trace_id

    # -- Provider invocation -------------------------------------------------

    def _invoke_provider(self, request: ACPRequest) -> ACPResponse:
        """Invoke the external ACP provider via JSON-RPC 2.0.

        Transport selection:
        - ``claude_code`` / ``codex``: ACP over stdio (subprocess JSON-RPC).
        - ``gemini``: ACP over HTTP+SSE when ``endpoint.endpoint_url`` is set;
          raises ``RuntimeError`` when not configured.

        The ``agent/run`` method is used for all synchronous invocations.
        """
        provider = request.provider
        endpoint = self._endpoint
        timeout = endpoint.timeout_seconds or _DEFAULT_STDIO_TIMEOUT_SECONDS

        if provider in (ACPProvider.CLAUDE_CODE, ACPProvider.CODEX):
            return self._invoke_stdio_provider(request, timeout=timeout)

        if provider == ACPProvider.CLAUDE_AGENT_SDK:
            return self._invoke_claude_agent_sdk_provider(request)

        if provider == ACPProvider.OPENAI_AGENTS:
            return self._invoke_openai_agents_provider(request)

        if provider == ACPProvider.CURSOR:
            return self._invoke_cursor_provider(request)

        if provider == ACPProvider.GEMINI:
            return self._invoke_http_provider(request, timeout=timeout)

        raise RuntimeError(f"Unknown ACP provider: {provider.value}")

    def _invoke_claude_agent_sdk_provider(self, request: ACPRequest) -> ACPResponse:
        """Run Claude Agent SDK in-process with Workweaver MCP tools and hooks."""
        from apps.backend.extensions.acp.providers.claude_agent_sdk import (
            ClaudeAgentSdkProvider,
            ClaudeAgentSdkRunConfig,
        )

        provider = ClaudeAgentSdkProvider(
            decision_capture_service=self._get_decision_capture_service(),
            sdk_module=self._claude_agent_sdk_module,
        )
        return provider.invoke(
            ClaudeAgentSdkRunConfig(
                request_id=request.request_id,
                tenant_id=request.tenant_id,
                prompt=request.prompt,
                provider=request.provider,
                model=self._endpoint.default_model or None,
                permission_mode=self._endpoint.permission_mode,
                allowed_tools=list(self._endpoint.sdk_allowed_tools),
                disallowed_tools=list(self._endpoint.sdk_disallowed_tools),
                sdk_options=dict(request.sdk_options),
            )
        )

    def _invoke_openai_agents_provider(self, request: ACPRequest) -> ACPResponse:
        """Run OpenAI Agents Python SDK in-process with Workweaver MCP tools."""
        from apps.backend.extensions.acp.providers.openai_agents import (
            OpenAIAgentsProvider,
            OpenAIAgentsRunConfig,
        )

        provider = OpenAIAgentsProvider(
            decision_capture_service=self._get_decision_capture_service(),
            sdk_module=self._openai_agents_module,
        )
        return provider.invoke(
            OpenAIAgentsRunConfig(
                request_id=request.request_id,
                tenant_id=request.tenant_id,
                prompt=request.prompt,
                provider=request.provider,
                model=self._endpoint.default_model or None,
                sdk_options=dict(request.sdk_options),
            )
        )

    def _invoke_cursor_provider(self, request: ACPRequest) -> ACPResponse:
        """Run Cursor's TypeScript SDK through the configured HTTP adapter."""
        from apps.backend.extensions.acp.providers.cursor import (
            CursorAgentProvider,
            CursorAgentRunConfig,
        )

        provider = CursorAgentProvider(
            decision_capture_service=self._get_decision_capture_service(),
            http_client=self._cursor_http_client,
        )
        return provider.invoke(
            CursorAgentRunConfig(
                request_id=request.request_id,
                tenant_id=request.tenant_id,
                prompt=request.prompt,
                provider=request.provider,
                model=self._endpoint.default_model or None,
                endpoint_url=self._endpoint.endpoint_url,
                api_key=self._endpoint.credential_ref,
                timeout_seconds=self._endpoint.timeout_seconds or _DEFAULT_STDIO_TIMEOUT_SECONDS,
                sdk_options=dict(request.sdk_options),
            )
        )

    def _get_decision_capture_service(self) -> Any:
        if self._decision_capture_service is not None:
            return self._decision_capture_service
        from apps.backend.services.context.decision_event_capture import (
            DecisionEventCaptureService,
        )

        self._decision_capture_service = DecisionEventCaptureService()
        return self._decision_capture_service

    def _invoke_stdio_provider(
        self, request: ACPRequest, *, timeout: float
    ) -> ACPResponse:
        """JSON-RPC 2.0 agent/run over stdio subprocess."""
        provider = request.provider
        endpoint = self._endpoint

        # Resolve executable: endpoint override > provider default
        executable = list(endpoint.executable) or _PROVIDER_EXECUTABLES.get(provider.value, [])
        if not executable:
            raise RuntimeError(
                f"No executable configured for ACP stdio provider {provider.value!r}. "
                "Set ACPEndpoint.executable or ensure the provider CLI is on PATH."
            )

        rpc_id = f"acp-{request.request_id}"
        params: dict[str, Any] = {
            "command": request.prompt,
            "timeout_seconds": timeout,
        }

        t0 = time.monotonic()
        result = self._stdio_transport(
            executable=executable,
            method="agent/run",
            params=params,
            req_id=rpc_id,
            timeout_seconds=timeout,
        )
        elapsed_ms = int((time.monotonic() - t0) * 1000)

        stdout = str(result.get("stdout") or "").strip()
        exit_code = result.get("exit_code", 0)
        timed_out = bool(result.get("timed_out", False))

        if timed_out:
            raise TimeoutError(
                f"ACP provider {provider.value!r} agent/run timed out (exit={exit_code})"
            )
        if exit_code != 0:
            stderr = str(result.get("stderr") or "").strip()
            raise RuntimeError(
                f"ACP provider {provider.value!r} agent/run failed "
                f"(exit={exit_code}, stderr={stderr[:200]!r})"
            )

        # Estimate tokens from output length (chars / 4 heuristic)
        tokens_used = max(1, len(stdout) // 4) if stdout else 0

        return ACPResponse(
            request_id=request.request_id,
            provider=provider,
            content=stdout,
            tokens_used=tokens_used,
            elapsed_ms=elapsed_ms,
            timestamp=datetime.now(UTC),
        )

    def _invoke_http_provider(
        self, request: ACPRequest, *, timeout: float
    ) -> ACPResponse:
        """JSON-RPC 2.0 agent/run over HTTP for gemini (or custom HTTP endpoints).

        This is a credential-gated stub: raises ``RuntimeError`` when no
        ``endpoint_url`` is configured. Full HTTP+SSE streaming is deferred
        until a tenant activates a Gemini ACP endpoint.
        """
        endpoint_url = (self._endpoint.endpoint_url or "").strip()
        if not endpoint_url:
            raise RuntimeError(
                f"ACP HTTP provider {request.provider.value!r} requires "
                "ACPEndpoint.endpoint_url. Configure acp_external_endpoints in tenant settings."
            )

        # HTTP JSON-RPC 2.0 — synchronous POST to endpoint_url/rpc
        try:
            import httpx  # deferred: avoid mandatory dep when not using HTTP providers
        except ImportError as exc:
            raise RuntimeError(
                "httpx is required for HTTP-transport ACP providers. "
                "Install it with: pip install httpx"
            ) from exc

        rpc_id = f"acp-{request.request_id}"
        payload = {
            "jsonrpc": "2.0",
            "method": "agent/run",
            "params": {
                "command": request.prompt,
                "timeout_seconds": timeout,
            },
            "id": rpc_id,
        }

        credential_ref = (self._endpoint.credential_ref or "").strip()
        headers: dict[str, str] = {"Content-Type": "application/json", "Accept": "application/json"}
        if credential_ref:
            # Credential lookup deferred to caller via ACPEndpoint.credential_ref;
            # the bridge uses the ref as a bearer token if it looks like a key.
            headers["Authorization"] = f"Bearer {credential_ref}"

        t0 = time.monotonic()
        try:
            with httpx.Client(timeout=timeout) as client:
                response_http = client.post(
                    f"{endpoint_url.rstrip('/')}/rpc",
                    json=payload,
                    headers=headers,
                )
                response_http.raise_for_status()
                data = response_http.json()
        except httpx.TimeoutException as exc:
            raise TimeoutError(
                f"ACP HTTP provider {request.provider.value!r} timed out"
            ) from exc
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(
                f"ACP HTTP provider {request.provider.value!r} HTTP error: "
                f"{exc.response.status_code}"
            ) from exc
        except httpx.RequestError as exc:
            raise RuntimeError(
                f"ACP HTTP provider {request.provider.value!r} request error: {exc}"
            ) from exc

        elapsed_ms = int((time.monotonic() - t0) * 1000)

        result = _parse_jsonrpc_response(json.dumps(data))
        stdout = str(result.get("stdout") or "").strip()
        exit_code = result.get("exit_code", 0)
        timed_out = bool(result.get("timed_out", False))

        if timed_out:
            raise TimeoutError(
                f"ACP HTTP provider {request.provider.value!r} agent/run timed out"
            )
        if exit_code != 0:
            stderr = str(result.get("stderr") or "").strip()
            raise RuntimeError(
                f"ACP HTTP provider {request.provider.value!r} agent/run failed "
                f"(exit={exit_code}, stderr={stderr[:200]!r})"
            )

        tokens_used = max(1, len(stdout) // 4) if stdout else 0
        return ACPResponse(
            request_id=request.request_id,
            provider=request.provider,
            content=stdout,
            tokens_used=tokens_used,
            elapsed_ms=elapsed_ms,
            timestamp=datetime.now(UTC),
        )

    # -- Fallback ------------------------------------------------------------

    def _handle_fallback(
        self,
        request: ACPRequest,
        exc: Exception,
        reason: str,
    ) -> ACPResponse:
        """Apply fallback policy when ACP provider fails."""
        logger.warning(
            "ACP provider %s failed for tenant=%s request=%s: %s",
            request.provider.value,
            request.tenant_id,
            request.request_id,
            exc,
        )

        if self._fallback_policy == ACPFallbackPolicy.FAIL_FAST:
            raise exc

        # NATIVE_FIRST: synthesize a placeholder response until the native
        # inference resolver is wired into this bridge.
        return ACPResponse(
            request_id=request.request_id,
            provider=request.provider,
            content="",
            tokens_used=0,
            elapsed_ms=0,
            timestamp=datetime.now(UTC),
        )

    # -- Evidence emission ---------------------------------------------------

    def _produce_evidence_receipt(
        self,
        *,
        request: ACPRequest,
        response: ACPResponse,
        prompt_hash: str,
        outcome: str,
        fallback_reason: str | None,
        session_id: str,
        synthesized_trace_id: str | None = None,
    ) -> ACPEvidenceReceipt:
        """Emit an evidence receipt via EvidenceLedgerService.ingest.

        Per acp-contracts.md section 2: every ACP invocation MUST produce
        an evidence receipt. Emission is synchronous.

        When ``synthesized_trace_id`` is set the receipt links to the
        ObserverProxy synthesized trace so WorkMemory/Decision Trace audit
        can resolve the surrogate (PRODUCT-CONTEXT.md §15, #3036).
        """
        risk_level = self._infer_risk_level(outcome)

        ledger_data: dict[str, Any] = {
            "request_id": request.request_id,
            "provider": request.provider.value,
            "agent_method": _agent_method_for_provider(request.provider),
            "prompt_hash": prompt_hash,
            "tokens_used": response.tokens_used,
            "elapsed_ms": response.elapsed_ms,
            "outcome": outcome,
            "cost_usd_estimate": _estimate_cost_usd(response.tokens_used),
            "outcome_status": outcome,
            "emits_decision_trace": request.emits_decision_trace,
        }
        if synthesized_trace_id is not None:
            ledger_data["synthesized_trace_id"] = synthesized_trace_id
            ledger_data["trace_synthesis_mode"] = "observer_proxy"

        evidence_record = self._evidence_service.ingest(
            tenant_id=request.tenant_id,
            event_type="evidence:acp_external_invocation",
            data=ledger_data,
            session_id=session_id,
            risk_level=risk_level,
            actor_path="acp_client",
        )

        evidence_id = str(evidence_record.get("evidence_id", ""))

        return ACPEvidenceReceipt(
            evidence_id=evidence_id,
            request_id=request.request_id,
            provider=request.provider,
            prompt_hash=prompt_hash,
            tokens_used=response.tokens_used,
            elapsed_ms=response.elapsed_ms,
            outcome=outcome,
            session_id=session_id,
            risk_level=risk_level,
            actor_path="acp_client",
            fallback_reason=fallback_reason,
            synthesized_trace_id=synthesized_trace_id,
        )

    @staticmethod
    def _infer_risk_level(outcome: str) -> str:
        """Infer risk level from invocation outcome."""
        if outcome == "success":
            return "low"
        if outcome in {"timeout", "fallback"}:
            return "medium"
        return "high"

    # -- Metering ------------------------------------------------------------

    def _track_metering(
        self,
        *,
        request: ACPRequest,
        response: ACPResponse,
        failed: bool,
    ) -> ACPMeteringRecord:
        """Record metering for an ACP invocation.

        Per acp-contracts.md section 3: tracks 4 UsageMetricType values.
        """
        from apps.backend.services.usage_tracker import UsageMetricType  # deferred: avoid circular import

        total_tokens = response.tokens_used
        # Heuristic: split ~20% prompt / ~80% completion
        tokens_in = max(1, total_tokens // 5)
        tokens_out = total_tokens - tokens_in

        timestamp = datetime.now(UTC)

        # LLM_INFERENCE_TOKENS_IN
        self._usage_tracker.record_usage(
            tenant_id=request.tenant_id,
            metric_type=UsageMetricType.LLM_INFERENCE_TOKENS_IN,
            quantity=tokens_in,
            unit="tokens",
            metadata={
                "source": "acp_client",
                "provider": request.provider.value,
                "request_id": request.request_id,
            },
        )

        # LLM_INFERENCE_TOKENS_OUT
        self._usage_tracker.record_usage(
            tenant_id=request.tenant_id,
            metric_type=UsageMetricType.LLM_INFERENCE_TOKENS_OUT,
            quantity=tokens_out,
            unit="tokens",
            metadata={
                "source": "acp_client",
                "provider": request.provider.value,
                "request_id": request.request_id,
            },
        )

        # TOOL_CALLS_TOTAL (every invocation)
        self._usage_tracker.record_usage(
            tenant_id=request.tenant_id,
            metric_type=UsageMetricType.TOOL_CALLS_TOTAL,
            quantity=1,
            unit="call",
            metadata={
                "source": "acp_client",
                "provider": request.provider.value,
                "request_id": request.request_id,
            },
        )

        # TOOL_CALLS_FAILED (only on error/timeout)
        tool_calls_failed = 1 if failed else 0
        if failed:
            self._usage_tracker.record_usage(
                tenant_id=request.tenant_id,
                metric_type=UsageMetricType.TOOL_CALLS_FAILED,
                quantity=1,
                unit="call",
                metadata={
                    "source": "acp_client",
                    "provider": request.provider.value,
                    "request_id": request.request_id,
                },
            )

        return ACPMeteringRecord(
            tenant_id=request.tenant_id,
            request_id=request.request_id,
            provider=request.provider,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            tool_calls_total=1,
            tool_calls_failed=tool_calls_failed,
            timestamp=timestamp,
        )

    # -- Replay store --------------------------------------------------------

    def _store_replay(
        self,
        *,
        request: ACPRequest,
        response: ACPResponse,
        prompt_hash: str,
    ) -> ACPReplayEntry:
        """Build and return a replay entry for audit.

        Per acp-contracts.md section 4: all invocations and responses stored.
        """
        return ACPReplayEntry(
            request_id=request.request_id,
            tenant_id=request.tenant_id,
            provider=request.provider,
            prompt_hash=prompt_hash,
            content=response.content,
            tokens_used=response.tokens_used,
            elapsed_ms=response.elapsed_ms,
            timestamp=response.timestamp,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _estimate_cost_usd(tokens: int) -> float:
    """Very rough token→USD estimate (claude-code tier pricing as baseline)."""
    return round(tokens * 0.000_015, 6)


def _agent_method_for_provider(provider: ACPProvider) -> str:
    if provider == ACPProvider.OPENAI_AGENTS:
        return "Runner.run_sync"
    if provider == ACPProvider.CURSOR:
        return "Agent.create/agent.send/run.stream"
    if provider == ACPProvider.CLAUDE_AGENT_SDK:
        return "ClaudeSDKClient.query"
    return "agent/run"
