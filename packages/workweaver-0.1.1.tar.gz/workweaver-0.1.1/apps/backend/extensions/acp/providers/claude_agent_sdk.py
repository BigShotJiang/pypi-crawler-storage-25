"""Claude Agent SDK in-process ACP provider."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from importlib import import_module
from typing import Any, Callable, Coroutine, TypeVar

from apps.backend.extensions.acp.hook_installers import (
    ClaudeAgentSdkDecisionTraceHooks,
)
from apps.backend.extensions.acp.sdk_mcp_factory import build_workweaver_sdk_mcp_server


logger = logging.getLogger(__name__)
_T = TypeVar("_T")


@dataclass(frozen=True)
class ClaudeAgentSdkRunConfig:
    """Configuration needed to run one Claude Agent SDK invocation."""

    request_id: str
    tenant_id: str
    prompt: str
    provider: Any
    model: str | None
    permission_mode: str | None
    allowed_tools: list[str]
    disallowed_tools: list[str]
    sdk_options: dict[str, Any]


class ClaudeAgentSdkProvider:
    """Runs Claude Agent SDK in-process with Workweaver MCP tools and hooks."""

    def __init__(
        self,
        *,
        decision_capture_service: Any,
        sdk_module: Any | None = None,
    ) -> None:
        self._decision_capture_service = decision_capture_service
        self._sdk = sdk_module or self._load_sdk()

    def invoke(self, config: ClaudeAgentSdkRunConfig) -> Any:
        """Run the async Claude SDK provider behind the existing sync ACP bridge."""

        return _run_async_from_sync(lambda: self.invoke_async(config))

    async def invoke_async(self, config: ClaudeAgentSdkRunConfig) -> Any:
        from apps.backend.extensions.acp.acp_client_adapter import ACPResponse

        t0 = time.monotonic()
        hook_installer = ClaudeAgentSdkDecisionTraceHooks(
            tenant_id=config.tenant_id,
            request_id=config.request_id,
            decision_capture_service=self._decision_capture_service,
            sdk_module=self._sdk,
        )
        mcp_server = build_workweaver_sdk_mcp_server(
            tenant_id=config.tenant_id,
            sdk_module=self._sdk,
            tool_names=config.sdk_options.get("mcp_tool_names"),
        )
        session_id = f"claude-agent-sdk:{config.request_id}"
        hook_installer.emit_lifecycle("SessionStart", session_id=session_id)
        outcome = "success"
        try:
            options = self._sdk.ClaudeAgentOptions(
                mcp_servers={"workweaver": mcp_server.server},
                allowed_tools=config.allowed_tools,
                disallowed_tools=config.disallowed_tools,
                permission_mode=config.permission_mode,
                model=config.model,
                hooks=hook_installer.build_hooks(),
                agents=config.sdk_options.get("agents"),
                max_turns=config.sdk_options.get("max_turns"),
                max_budget_usd=config.sdk_options.get("max_budget_usd"),
                system_prompt=config.sdk_options.get("system_prompt"),
                cwd=config.sdk_options.get("cwd"),
                env=dict(config.sdk_options.get("env") or {}),
            )
            messages: list[Any] = []
            async with self._sdk.ClaudeSDKClient(options=options) as client:
                await client.query(config.prompt)
                async for message in client.receive_response():
                    messages.append(message)
            content = _messages_to_text(messages)
            tokens_used = _estimate_tokens(messages, content)
            return ACPResponse(
                request_id=config.request_id,
                provider=config.provider,
                content=content,
                tokens_used=tokens_used,
                elapsed_ms=int((time.monotonic() - t0) * 1000),
                timestamp=datetime.now(UTC),
            )
        except Exception:
            outcome = "error"
            raise
        finally:
            hook_installer.emit_lifecycle(
                "SessionEnd",
                session_id=session_id,
                run_outcome=outcome,
            )

    @staticmethod
    def _load_sdk() -> Any:
        try:
            claude_agent_sdk = import_module("claude_agent_sdk")
        except ImportError as exc:
            raise RuntimeError(
                "claude-agent-sdk is required for ACPProvider.CLAUDE_AGENT_SDK. "
                "Install the project dependency or disable this provider."
            ) from exc
        return claude_agent_sdk


def _run_async_from_sync(coro_factory: Callable[[], Coroutine[Any, Any, _T]]) -> _T:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro_factory())

    result: dict[str, _T] = {}
    error: dict[str, BaseException] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(coro_factory())
        except BaseException as exc:
            error["value"] = exc

    thread = threading.Thread(target=_runner, name="claude-agent-sdk-provider", daemon=True)
    thread.start()
    thread.join()
    if error:
        raise error["value"]
    return result["value"]


def _messages_to_text(messages: list[Any]) -> str:
    parts: list[str] = []
    for message in messages:
        content = getattr(message, "content", None)
        if isinstance(content, list):
            for block in content:
                text = getattr(block, "text", None)
                if text:
                    parts.append(str(text))
            continue
        if isinstance(content, str):
            parts.append(content)
            continue
        if hasattr(message, "model_dump_json"):
            parts.append(message.model_dump_json())
        elif hasattr(message, "model_dump"):
            parts.append(str(message.model_dump()))
        else:
            rendered = str(message)
            if rendered:
                parts.append(rendered)
    return "\n".join(parts).strip()


def _estimate_tokens(messages: list[Any], content: str) -> int:
    total = 0
    for message in messages:
        usage = getattr(message, "usage", None)
        if usage is None:
            continue
        for attr in ("input_tokens", "output_tokens", "cache_creation_input_tokens"):
            value = getattr(usage, attr, 0) or 0
            if isinstance(value, int):
                total += value
    return total if total > 0 else (max(1, len(content) // 4) if content else 0)
