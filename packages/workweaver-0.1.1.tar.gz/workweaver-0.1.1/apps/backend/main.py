"""Unified Lambda Handler for Workweaver API

Entry point that routes to the appropriate handler based on LAMBDA_HANDLER environment variable:
- "api" or not set: REST API handler (FastAPI with Mangum)
- "websocket": WebSocket handler for real-time latency streaming

Environment Variables:
- LAMBDA_HANDLER: Handler type ("api" or "websocket", default: "api")
- AWS_REGION: AWS region (default: us-east-1)
- ENVIRONMENT: Environment name (dev, staging, prod)
- WEBSOCKET_ENDPOINT: WebSocket API endpoint (for WebSocket handler)
- LOG_LEVEL: Logging level (default: INFO)
"""

import os
import sys
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from importlib import import_module
from pathlib import Path
from typing import Any

from apps.backend.config.table_names import configured_table

# Configure logging first
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Never allow verbose HTTP/WebSocket debug logs in the backend:
# - AWS SDK + urllib can include request/response bodies
# - websockets can include Authorization headers when debug is enabled
# Keep these quiet even when LOG_LEVEL=DEBUG.
for _noisy in (
    "botocore",
    "boto3",
    "urllib3",
    "websockets",
    "websockets.client",
    "websockets.server",
    "httpx",
    "httpcore",
    "twilio",
):
    logging.getLogger(_noisy).setLevel(logging.WARNING)

# Get handler type from environment
handler_type = os.environ.get("LAMBDA_HANDLER", "api")

logger.info(f"Initializing Lambda handler: type={handler_type}")

if handler_type == "websocket":
    # WebSocket handler - bare metal handler
    logger.info("Loading WebSocket handler")

    def lambda_handler(event, context):
        """Route WebSocket events to appropriate handler."""
        from websocket_handler import (
            handle_connect,
            handle_disconnect,
            handle_default,
        )

        route_key = event.get("requestContext", {}).get("routeKey")

        if route_key == "$connect":
            return handle_connect(event)
        elif route_key == "$disconnect":
            return handle_disconnect(event)
        else:
            return handle_default(event)

else:
    # REST API handler - FastAPI with Mangum
    logger.info("Loading REST API handler (FastAPI)")

    # Add repository root to sys.path before loading package-scoped modules.
    current_dir = os.path.abspath(os.path.dirname(__file__))
    if os.path.exists(os.path.join(current_dir, "voice_services")):
        repo_root = os.path.abspath(os.path.join(current_dir, "../.."))
    else:
        repo_root = os.path.abspath(os.path.join(current_dir, "../../.."))

    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    try:
        from mangum import Mangum
    except ImportError:  # pragma: no cover
        Mangum = None
    from fastapi import APIRouter, FastAPI, HTTPException, status
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, RedirectResponse
    from slowapi import _rate_limit_exceeded_handler
    from slowapi.errors import RateLimitExceeded
    from slowapi.middleware import SlowAPIMiddleware
    import sys

    from apps.backend.config.environment import get_environment, is_production_like
    from apps.backend.config.backend_app_policy import resolve_backend_docs_urls
    from apps.backend.config.capability_bundles import (
        CapabilityBundle,
        get_enabled_capability_bundles,
    )

    # Observability: structlog, trace context, error tracking (Track 8)
    from apps.backend.observability.structlog_config import configure_structlog
    from apps.backend.observability.trace_context import (
        component_var,
        error_code_var,
        route_var,
        trace_id_var,
        tenant_id_var,
        user_id_var,
        new_trace_id,
    )
    from apps.backend.observability.error_tracker import ErrorTracker
    import structlog as _structlog

    # Configure structlog early — before any logger usage
    configure_structlog()
    _error_tracker = ErrorTracker()
    _obs_logger = _structlog.get_logger("observability.error_tracking")

    # Issue #2732: structured exception capture via the canonical error
    # router. Sentry SDK is OPTIONAL — when SENTRY_DSN is unset (dev,
    # tests, self-hosted deployments without GlitchTip) the router falls
    # back to LogOnlyProvider so structured logs still carry the
    # canonical event envelope.
    from apps.backend.services.observability import (
        ErrorRouter as _ErrorRouter,
        init_sentry_if_configured as _init_sentry_if_configured,
    )

    _sentry_provider = _init_sentry_if_configured()
    _error_router = _ErrorRouter(provider=_sentry_provider) if _sentry_provider else _ErrorRouter()
    app_error_router = _error_router  # exported for downstream wiring

    from apps.backend.services.public_health_contract import build_public_health_payload

    # FastAPI Application
    _docs_url, _redoc_url, _openapi_url = resolve_backend_docs_urls()
    _enabled_capability_bundles = get_enabled_capability_bundles()
    _voice_bundle_enabled = CapabilityBundle.voice in _enabled_capability_bundles
    _workmemory_bundle_enabled = CapabilityBundle.workmemory in _enabled_capability_bundles

    @asynccontextmanager
    async def _lifespan(app: FastAPI):
        from apps.backend.services.runtime.startup_timeline import startup_timeline
        from apps.backend.services.runtime.runtime_drain_controller import (
            get_runtime_drain_controller,
        )

        with startup_timeline.phase("config-load", metadata={"source": "backend_lifespan"}):
            await _validate_critical_config()
            from apps.backend.services.runtime.bootstrap_diagnostics import (
                build_bootstrap_diagnostics_gate,
            )

            app.state.bootstrap_diagnostics_gate = build_bootstrap_diagnostics_gate()
        # Issue #3266: install SIGTERM drain handler and expose readiness gate.
        drain_controller = get_runtime_drain_controller()
        drain_controller.install_signal_handlers()
        app.state.runtime_drain_controller = drain_controller
        app.state.startup_warmup_tasks = _schedule_readiness_independent_warmers()
        startup_timeline.record(
            "health-ready",
            metadata={
                "source": "backend_lifespan",
                "warmers_deferred": len(app.state.startup_warmup_tasks),
            },
        )
        try:
            yield
        finally:
            await drain_controller.drain(caused_by="lifespan_exit")
            for task in getattr(app.state, "startup_warmup_tasks", []):
                if not task.done():
                    task.cancel()
            await _shutdown_shared_http_clients()
            await _stop_async_scheduler_for_background_work()

    app = FastAPI(
        title="Workweaver API",
        description="Workweaver AI Platform API",
        version="1.0.0",
        docs_url=_docs_url,
        redoc_url=_redoc_url,
        openapi_url=_openapi_url,
        redirect_slashes=False,  # Disable 307 redirects that generate http:// behind ALB/CloudFront
        lifespan=_lifespan,
    )

    class _LazyASGIMiddleware:
        def __init__(self, app: Any, *, module_path: str, class_name: str) -> None:
            self.app = app
            self._module_path = module_path
            self._class_name = class_name
            self._instance: Any | None = None

        def _load(self) -> Any:
            if self._instance is None:
                module = import_module(self._module_path)
                middleware_cls = getattr(module, self._class_name)
                self._instance = middleware_cls(self.app)
            return self._instance

        async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
            await self._load()(scope, receive, send)

    class QuotaEnforcementMiddleware(_LazyASGIMiddleware):
        def __init__(self, app: Any) -> None:
            super().__init__(
                app,
                module_path="apps.backend.middleware.quota_enforcement",
                class_name="QuotaEnforcementMiddleware",
            )

    class StopLossEnforcementMiddleware(_LazyASGIMiddleware):
        def __init__(self, app: Any) -> None:
            super().__init__(
                app,
                module_path="apps.backend.middleware.stoploss_enforcement",
                class_name="StopLossEnforcementMiddleware",
            )

    class SecurityHeadersMiddleware(_LazyASGIMiddleware):
        def __init__(self, app: Any) -> None:
            super().__init__(
                app,
                module_path="apps.backend.middleware.security_headers",
                class_name="SecurityHeadersMiddleware",
            )

    class AuthEnforcementMiddleware(_LazyASGIMiddleware):
        def __init__(self, app: Any) -> None:
            super().__init__(
                app,
                module_path="apps.backend.middleware.auth_enforcement",
                class_name="AuthEnforcementMiddleware",
            )

    # Rate limiting (M1): per-IP DoS protection on all routes.
    # Stricter per-endpoint limits are applied via @limiter.limit decorators in route files.
    # Disabled when DISABLE_RATE_LIMIT=1 (test environments).
    from apps.backend.api.rate_limit import limiter as _limiter

    app.state.limiter = _limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    app.add_middleware(SlowAPIMiddleware)

    # Quota enforcement: reject requests when tenant exceeds tier limits.
    app.add_middleware(QuotaEnforcementMiddleware)

    # Stop-loss enforcement: block inference when tenant spend exceeds budget (#3190).
    app.add_middleware(StopLossEnforcementMiddleware)

    # Security headers: CSP, HSTS, X-Frame-Options, X-Content-Type-Options, etc.
    app.add_middleware(SecurityHeadersMiddleware)

    # Auth enforcement: deny-by-default posture (#1931).
    # Rejects requests to routes without auth dependencies or public registry entry.
    app.add_middleware(AuthEnforcementMiddleware)

    # CORS:
    # Workweaver provisioning uses `credentials: 'include'` so wildcard origins are invalid.
    raw_origins = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "*").split(",") if o.strip()]
    if not raw_origins or raw_origins == ["*"]:
        # L1: localhost origins only included in dev/test environments — never in prod.
        allowed_origins = [
            "https://workweaver.ai",
            "https://www.workweaver.ai",
            "https://admin.workweaver.ai",
            "https://infra.workweaver.ai",
            "https://www.infra.workweaver.ai",
        ]
        if not is_production_like():
            allowed_origins += [
                "http://localhost:3000",
                "http://localhost:3001",
                "http://127.0.0.1:3000",
                "http://127.0.0.1:3001",
            ]
    else:
        allowed_origins = raw_origins
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=[
            "content-type",
            "authorization",
            "x-tenant-id",
            "x-user-id",
            "x-user-email",
            "x-user-name",
            "x-user-role",
            "x-request-id",
            "x-amz-date",
            "x-api-key",
        ],
        expose_headers=[
            "x-request-id",
            "x-quota-warning",
            "retry-after",
        ],
    )

    # Dev/test tenant propagation only:
    # production routes must derive tenant identity from authenticated context,
    # never directly from X-Tenant-Id.
    from fastapi import Request

    import re as _re

    # Security: validate tenant_id format before trusting it from the header.
    # Accepts: TENANT#<alphanumeric+hyphens> or bare UUID — prevents shell injection
    # and control-character injection (CWE-639). The actual tenant isolation check
    # (header must match JWT claim) is enforced in tenant_auth.py for authenticated routes.
    _TENANT_ID_PATTERN = _re.compile(
        r"^(TENANT#)?[0-9a-zA-Z][0-9a-zA-Z\-]{0,127}$",
    )

    @app.middleware("http")
    async def _tenant_header_context(request: Request, call_next):
        try:
            from apps.backend.utils.tenant import strip_tenant_prefix

            if getattr(request.state, "tenant_id", None) is None:
                tenant_id = ""

                # 1. Try X-Tenant-Id header (dev mode or API clients)
                cognito_disabled = os.environ.get("DISABLE_COGNITO", "").strip().lower() in (
                    "1",
                    "true",
                    "yes",
                )
                if cognito_disabled:
                    tenant_id = (request.headers.get("x-tenant-id") or "").strip()
                    if tenant_id and not _TENANT_ID_PATTERN.match(tenant_id):
                        logger.warning("Rejected malformed X-Tenant-ID header (failed format check)")
                        tenant_id = ""
                    user_id = (request.headers.get("x-user-id") or "").strip()
                    if user_id:
                        request.state.user_id = user_id
                        request.state.authenticated_user_id = user_id

                # 2. Fallback: browser session cookie (dashboard cross-origin requests)
                if not tenant_id:
                    from apps.backend.api.auth_helpers import BROWSER_SESSION_COOKIE_NAMES
                    from apps.backend.services.session.browser_session import (
                        BrowserSessionTokenError,
                        verify_browser_session_token,
                    )

                    cookies = getattr(request, "cookies", {}) or {}
                    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
                        token = str(cookies.get(cookie_name) or "").strip()
                        if not token:
                            continue
                        try:
                            claims = verify_browser_session_token(token)
                            tenant_id = claims.tenant_id or ""
                            user_id = claims.user_id or ""
                            if tenant_id:
                                request.state.user_id = user_id
                                request.state.authenticated_user_id = user_id
                                impersonator_id = claims.impersonator_id or ""
                                if impersonator_id:
                                    request.state.impersonator_id = impersonator_id
                                    request.state.authenticated_impersonator_id = impersonator_id
                        except BrowserSessionTokenError:
                            pass
                        break

                if tenant_id:
                    request.state.tenant_id = tenant_id
                    request.state.authenticated_tenant_id = strip_tenant_prefix(tenant_id)
        except Exception:
            # Never block requests due to context extraction issues.
            logger.warning("tenant_header_context_failed", exc_info=True)
        return await call_next(request)

    # ---- Observability: unhandled exception handler (Track 8) ----
    # Registered as an exception_handler (not middleware) so it runs INSIDE
    # the middleware stack where trace_id contextvar is already set.
    # Starlette's call_next in @app.middleware("http") swallows handler
    # exceptions into a pre-committed 500 response whose headers can't be
    # mutated — so we catch exceptions here instead.
    from starlette.responses import JSONResponse as _JSONResponse

    # CRITICAL: Starlette's CORSMiddleware does NOT wrap responses returned
    # from exception_handlers — it only wraps responses that flow through
    # the normal middleware chain via call_next(). When an unhandled
    # exception fires, this handler builds the response directly and the
    # browser sees a 500 with NO Access-Control-Allow-Origin header. The
    # fetch() call then fails with TypeError "Failed to fetch" instead of
    # surfacing the actual status, hiding the real error from the user
    # and from frontend humanization code.
    #
    # Real-user impact: clicking Connect on Slack/Notion/MS Cal in the
    # dashboard returned "Failed to fetch" after a 2s timeout instead of
    # a structured 503 message that the frontend's humanizer could turn
    # into "Slack isn't available right now". Verified 2026-04-06 in
    # Chrome DevTools and confirmed via direct browser fetch().
    #
    # Fix: re-implement the CORS-allowed-origin check inline so error
    # responses always carry the right Origin header. We mirror the
    # CORSMiddleware logic exactly so trusted callers see CORS-allowed
    # responses and untrusted callers see no headers (security-equivalent
    # to the regular middleware).
    _cors_allowed_origins_set = set(allowed_origins)

    def _resolve_cors_headers(request: Request) -> dict[str, str]:
        origin = request.headers.get("origin", "")
        if not origin or origin not in _cors_allowed_origins_set:
            return {}
        return {
            "access-control-allow-origin": origin,
            "access-control-allow-credentials": "true",
            "vary": "Origin",
        }

    @app.exception_handler(Exception)
    async def _unhandled_exception_handler(request: Request, exc: Exception):
        trace_id = trace_id_var.get("")
        route = route_var.get("") or str(request.url.path)
        user_id = user_id_var.get("")
        # Structured logging may fail if structlog processors aren't fully
        # compatible (e.g. PrintLogger lacking stdlib attrs). Guard to ensure
        # the trace_id response header is always set regardless.
        try:
            _obs_logger.error(
                "unhandled_exception",
                trace_id=trace_id,
                tenant_id=tenant_id_var.get(""),
                user_id=user_id,
                route=route,
                component="backend.api",
                error_code="unhandled_exception",
                error=str(exc),
                error_type=type(exc).__name__,
                path=route,
            )
        except Exception:
            import logging

            logging.getLogger(__name__).error(
                "unhandled_exception path=%s error=%s trace_id=%s",
                request.url.path,
                exc,
                trace_id,
            )
        _error_tracker.record(str(request.url.path))
        # Issue #2732: forward unhandled exceptions to the canonical
        # error router so they land in Sentry/GlitchTip + Decision Trace
        # alongside the existing structured log line. The router NEVER
        # raises so the legacy 500-handling path is preserved.
        try:
            from apps.backend.services.observability import AlertSeverity as _AlertSeverity

            _error_router.capture(
                exc,
                tenant_id=tenant_id_var.get(""),
                correlation_id=trace_id,
                component="backend.api",
                severity=_AlertSeverity.P1,
                metadata={"path": route, "user_id": user_id},
            )
        except Exception:
            # Telemetry must never break the 500 path.
            pass
        return _JSONResponse(
            status_code=500,
            content={
                "error": "Something went wrong",
                "request_id": trace_id,
                "recovery": "Retry or contact support",
                "detail": "Internal server error",
            },
            headers={
                "x-trace-id": trace_id,
                "x-request-id": trace_id,  # alias for #1170; same canonical value
                **_resolve_cors_headers(request),
            },
        )

    # Same CORS-on-error fix for HTTPException (4xx/5xx with .detail).
    # FastAPI's default HTTPException handler also bypasses CORSMiddleware
    # in some failure modes (e.g. responses returned from middleware
    # before the route handler runs).
    from fastapi import HTTPException as _HTTPException
    from fastapi.exception_handlers import http_exception_handler as _default_http_handler

    @app.exception_handler(_HTTPException)
    async def _http_exception_with_cors(request: Request, exc: _HTTPException):
        response = await _default_http_handler(request, exc)
        for k, v in _resolve_cors_headers(request).items():
            response.headers[k] = v
        return response

    # Trace-ID + Request-ID middleware: injects a UUID trace_id per request
    # into contextvars and copies it to the response X-Trace-Id AND
    # X-Request-Id headers. Accepts caller-provided X-Trace-Id or
    # X-Request-Id for distributed tracing continuity.
    #
    # Issue #1170: clients expect ``X-Request-Id`` for backend correlation
    # (it's the convention every B2B SaaS dashboard uses for "paste this
    # ID when you contact support"). Codex round-1 review correction:
    # echo from the existing canonical trace_id rather than minting a
    # second ID pipeline so error paths and exception handlers stay
    # consistent. ``X-Request-Id`` and ``X-Trace-Id`` carry the SAME
    # value — they are aliases, not parallel IDs.
    @app.middleware("http")
    async def _trace_id_middleware(request: Request, call_next):
        from apps.backend.observability.action_metrics import (
            finish_action_span,
            record_http_request_duration,
            route_template_from_scope,
            safe_dimensions,
            safe_error_class,
            start_action_span,
        )
        from apps.backend.observability.otel_tracing import SpanKind

        # Honour caller-provided trace_id (legacy header) OR request_id
        # (industry-standard alias) for distributed tracing continuity.
        incoming_trace = (request.headers.get("x-trace-id") or "").strip()
        incoming_request = (request.headers.get("x-request-id") or "").strip()
        trace_id = incoming_trace or incoming_request or new_trace_id()
        token = trace_id_var.set(trace_id)

        # Also propagate tenant_id into the contextvar if available
        tid = getattr(request.state, "tenant_id", None) or (request.headers.get("x-tenant-id") or "").strip()
        uid = getattr(request.state, "user_id", None) or (request.headers.get("x-user-id") or "").strip()
        t_token = tenant_id_var.set(tid)
        u_token = user_id_var.set(uid)
        r_token = route_var.set(str(request.url.path))
        c_token = component_var.set("backend.api")
        e_token = error_code_var.set("")
        started = time.perf_counter()
        status_code = 500
        error_class = "none"
        span = start_action_span(
            "http.request",
            kind=SpanKind.SERVER,
            dimensions=safe_dimensions(
                action="http.request",
                surface="http",
                tenant_id=tid,
                user_id=uid,
                route=str(request.url.path),
                extra={"http.request.method": request.method.upper()},
            ),
        )

        try:
            response = await call_next(request)
            status_code = int(getattr(response, "status_code", 200) or 200)
            error_class = safe_error_class(None, status_code=status_code)
            response.headers["x-trace-id"] = trace_id
            response.headers["x-request-id"] = trace_id  # alias for #1170
            return response
        except Exception as exc:
            error_class = safe_error_class(exc)
            raise
        finally:
            duration_ms = (time.perf_counter() - started) * 1000
            route_template = route_template_from_scope(request.scope, str(request.url.path))
            finish_action_span(span, error_class=error_class, duration_ms=duration_ms)
            await record_http_request_duration(
                duration_ms=duration_ms,
                method=request.method,
                route_template=route_template,
                status_code=status_code,
                error_class=error_class,
                tenant_id=tid,
                user_id=uid,
            )
            trace_id_var.reset(token)
            tenant_id_var.reset(t_token)
            user_id_var.reset(u_token)
            route_var.reset(r_token)
            component_var.reset(c_token)
            error_code_var.reset(e_token)

    # Startup validation: fail fast on missing critical env vars
    async def _validate_critical_config():
        """Fail fast if critical production config is missing."""
        import os
        from apps.backend.services.runtime.startup_timeline import startup_timeline

        # M3: JWT_SECRET must be present and non-trivial in non-test environments.
        # A missing or short JWT_SECRET allows token forgery — fail immediately.
        # Exception: DISABLE_COGNITO=1 implies a test/local-dev environment where
        # Cognito-backed JWT auth is not active, so the JWT_SECRET is not used for
        # token verification and the strict check is relaxed.
        cognito_disabled = os.environ.get("DISABLE_COGNITO", "").strip().lower() in ("1", "true", "yes")
        jwt_secret = os.environ.get("JWT_SECRET", "")
        if not jwt_secret and not cognito_disabled:
            with startup_timeline.phase("secret-resolve", metadata={"secret_ref": "jwt/secret"}):
                try:
                    from apps.backend.config.secrets import get_secret

                    jwt_secret = get_secret("jwt/secret") or ""
                except Exception:
                    jwt_secret = ""
        elif jwt_secret:
            startup_timeline.record(
                "secret-resolve",
                metadata={"source": "environment", "secret_name": "JWT_SECRET"},
            )
        else:
            startup_timeline.record(
                "secret-resolve",
                metadata={"source": "skipped", "reason": "cognito_disabled"},
            )
        if not cognito_disabled and (not jwt_secret or len(jwt_secret) < 32):
            msg = "JWT_SECRET is missing or too short (must be at least 32 characters). Cannot start safely."
            logger.critical(msg)
            raise RuntimeError(msg)

        # Probe get_environment() so any config-loading side effects run at
        # startup (not at first request), matching the pre-existing call
        # pattern. The returned value is unused because production checks
        # below pivot on is_production_like() + direct os.environ reads.
        get_environment()
        if is_production_like():
            # Hard blockers — security risks that MUST crash the app
            hard_blockers = []
            if os.environ.get("DISABLE_COGNITO", "").strip().lower() in ("1", "true", "yes"):
                hard_blockers.append("DISABLE_COGNITO is enabled (authentication bypassed in production)")

            if hard_blockers:
                msg = "CRITICAL: Production config validation failed:\n" + "\n".join(f"  - {m}" for m in hard_blockers)
                logger.critical(msg)
                raise RuntimeError(msg)

            # Soft warnings — degraded features, but app is still functional
            warnings = []
            if os.environ.get("EMAIL_PROVIDER", "console") == "console":
                warnings.append("EMAIL_PROVIDER is 'console' — emails go to stdout, not delivered")
            if not os.environ.get("STRIPE_API_KEY"):
                warnings.append("STRIPE_API_KEY missing — billing/checkout will fail")
            tenants_table = configured_table("tenants")
            if not tenants_table:
                warnings.append("TENANTS_TABLE missing — tenant-scoped runtime paths will fail closed")
            elif tenants_table.endswith("-dev"):
                warnings.append("TENANTS_TABLE defaulting to dev table in non-dev environment")

            if warnings:
                msg = "Production config warnings (non-fatal):\n" + "\n".join(f"  - {w}" for w in warnings)
                logger.warning(msg)

    def _schedule_readiness_independent_warmers() -> list[asyncio.Task[Any]]:
        warmers = (
            ("MCP-connect", _register_admin_mcp_tools),
            ("marketplace_seed", _eager_seed_marketplace),
            ("http_clients", _initialize_shared_http_clients),
            ("scheduler_start", _start_async_scheduler_for_background_work),
            ("event_bus_prime", _prime_event_bus_subscribers),
        )
        return [
            asyncio.create_task(_run_startup_warmer(name, warmer), name=f"startup:{name}")
            for name, warmer in warmers
        ]

    async def _run_startup_warmer(name: str, warmer: Any) -> None:
        from apps.backend.services.runtime.startup_timeline import startup_timeline

        with startup_timeline.phase(name, metadata={"source": "readiness_independent_warmer"}):
            result = warmer()
            if hasattr(result, "__await__"):
                await result

    def _register_admin_mcp_tools() -> None:
        from apps.backend.mcp.admin_tools import register_admin_mcp_tools

        register_admin_mcp_tools()

    async def _eager_seed_marketplace() -> None:
        """Pre-seed the IntegrationMarketplace before any request can race on it.

        Belt-and-suspenders alongside the threading.Lock in
        ``apps/backend/services/connectors/marketplace.py:get_marketplace``.
        The lock is correct under contention; eager init means the first
        user-facing request never pays the seed latency and never sees a
        contended cold start. Issue #822, follow-up to the 2026-04-08
        production outage where a partial seed cascade took down
        ``/api/v1/connectors/catalog`` for ~90 minutes.

        Failing fast at startup also means a future manifest bug surfaces
        in the application logs immediately, not on the first request
        that happens to traverse the catalog endpoint.
        """
        from apps.backend.services.connectors.marketplace import get_marketplace

        try:
            mp = get_marketplace()
            summary = mp.list_connectors(page_size=1)
            logger.info(
                "marketplace_eager_seed_complete connectors=%d",
                summary["total"],
            )
        except Exception:
            logger.exception("marketplace_eager_seed_failed")
            from apps.backend.services.runtime.startup_timeline import startup_timeline

            startup_timeline.record(
                "marketplace_seed",
                status="degraded",
                metadata={"source": "readiness_independent_warmer"},
                error="connector catalog seed failed; connector catalog will fail closed until next warmup",
            )

    def _cleanup_event_bus_subscribers(phase: str) -> None:
        from apps.backend.services.event_bus import cleanup_all_stale_subscribers

        evicted = cleanup_all_stale_subscribers()
        logger.info("event_bus_%s_cleanup evicted=%d", phase, evicted)

    def _env_enabled(name: str, default: bool = True) -> bool:
        return os.environ.get(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}

    async def _initialize_shared_http_clients() -> None:
        from apps.backend.services.http_client_registry import initialize_shared_async_clients

        initialize_shared_async_clients()

    async def _start_async_scheduler_for_background_work() -> None:
        """Start the in-process scheduler for profiles that own local work."""
        from apps.backend.providers.base import DeploymentProfile, get_deployment_profile

        profile = get_deployment_profile()
        if profile in (DeploymentProfile.standalone, DeploymentProfile.self_host_production):
            from apps.backend.dependencies import get_async_scheduler
            from apps.backend.services.portable_background_runtime import register_portable_background_tasks

            scheduler = get_async_scheduler()
            register_portable_background_tasks(scheduler=scheduler)
            await scheduler.start()
            logger.info("async_scheduler.started profile=%s", profile.value)
            return

        if (
            profile == DeploymentProfile.managed_saas
            and not os.environ.get("AWS_LAMBDA_FUNCTION_NAME")
            and _env_enabled("WORKWEAVER_API_REPLICA_BACKGROUND_WORKERS", False)
        ):
            from apps.backend.dependencies import get_async_scheduler
            from apps.backend.services.portable_background_runtime import (
                register_stripe_webhook_outbox_task,
                register_twilio_recording_outbox_task,
            )

            scheduler = get_async_scheduler()
            register_stripe_webhook_outbox_task(scheduler=scheduler)
            if _env_enabled("TWILIO_RECORDING_OUTBOX_WORKER_ENABLED", True):
                register_twilio_recording_outbox_task(scheduler=scheduler)
            await scheduler.start()
            logger.info("async_scheduler.started profile=%s task=external_outboxes", profile.value)
            return

        logger.info("async_scheduler.skipped profile=%s owner=dedicated_worker", profile.value)

    async def _shutdown_shared_http_clients() -> None:
        _cleanup_event_bus_subscribers("shutdown")
        from apps.backend.services.http_client_registry import close_shared_async_clients

        await close_shared_async_clients()

    async def _stop_async_scheduler_for_background_work() -> None:
        """Stop the AsyncScheduler gracefully when this runtime started it."""
        from apps.backend.providers.base import DeploymentProfile, get_deployment_profile

        profile = get_deployment_profile()
        if profile in (
            DeploymentProfile.standalone,
            DeploymentProfile.self_host_production,
        ) or (
            profile == DeploymentProfile.managed_saas
            and not os.environ.get("AWS_LAMBDA_FUNCTION_NAME")
            and _env_enabled("WORKWEAVER_API_REPLICA_BACKGROUND_WORKERS", False)
        ):
            from apps.backend.dependencies import get_async_scheduler

            scheduler = get_async_scheduler()
            await scheduler.stop()
            logger.info("async_scheduler.stopped profile=%s", profile.value)

    async def _prime_event_bus_subscribers() -> None:
        _cleanup_event_bus_subscribers("startup")

    def _load_router(module_path: str, attr: str = "router"):
        module = import_module(module_path)
        return getattr(module, attr)

    _ROUTER_INTERNAL_KWARGS = {"bundle", "optional_deps", "optional_profiles", "disabled_paths"}

    def _disabled_bundle_router(prefix: str, bundle: CapabilityBundle) -> APIRouter:
        router = APIRouter(prefix=prefix, include_in_schema=False)

        async def _bundle_disabled() -> None:
            raise HTTPException(status_code=501, detail=f"{bundle.value} bundle is disabled")

        router.add_api_route(
            "/{path:path}",
            _bundle_disabled,
            methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
        )
        return router

    def _make_unavailable_route(detail: str):
        async def _route_unavailable() -> None:
            raise HTTPException(status_code=501, detail=detail)

        return _route_unavailable

    def _install_unavailable_http_routes(*, paths: dict[str, str]) -> None:
        for path, detail in paths.items():
            app.add_api_route(
                path,
                _make_unavailable_route(detail),
                methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
                include_in_schema=False,
            )

    def _install_disabled_bundle_http_routes(bundle: CapabilityBundle, paths: list[str]) -> None:
        _install_unavailable_http_routes(
            paths={path: f"{bundle.value} bundle is disabled" for path in paths},
        )

    def _missing_optional_router_dependency(
        *,
        exc: Exception,
        kwargs: dict[str, Any],
        deployment_profile: Any,
    ) -> str | None:
        if not isinstance(exc, ModuleNotFoundError):
            return None

        optional_profiles = {
            str(item or "").strip()
            for item in kwargs.get("optional_profiles", ())
            if str(item or "").strip()
        }
        # Degradation is opt-in: a router must declare both the missing dependency
        # and the deployment profiles where a soft 501 placeholder is acceptable.
        if not optional_profiles or deployment_profile.value not in optional_profiles:
            return None

        optional_deps = tuple(
            str(item or "").strip()
            for item in kwargs.get("optional_deps", ())
            if str(item or "").strip()
        )
        if not optional_deps:
            return None

        missing_name = str(getattr(exc, "name", "") or "").strip()
        missing_root = missing_name.split(".", 1)[0] if missing_name else ""
        if missing_root and missing_root in optional_deps:
            return missing_root

        exc_message = str(exc)
        for dependency in optional_deps:
            if f"No module named '{dependency}'" in exc_message or f'No module named "{dependency}"' in exc_message:
                return dependency
        return None

    def _validate_optional_router_contract(
        *,
        module_path: str,
        attr: str,
        kwargs: dict[str, Any],
    ) -> None:
        optional_deps = tuple(
            str(item or "").strip()
            for item in kwargs.get("optional_deps", ())
            if str(item or "").strip()
        )
        if not optional_deps:
            return

        optional_profiles = tuple(
            str(item or "").strip()
            for item in kwargs.get("optional_profiles", ())
            if str(item or "").strip()
        )
        if not optional_profiles:
            raise RuntimeError(
                f"{module_path}.{attr} declares optional_deps but no optional_profiles; "
                "router degradation must be explicitly scoped"
            )

        disabled_paths = tuple(
            str(item or "").strip()
            for item in kwargs.get("disabled_paths", ())
            if str(item or "").strip()
        )
        if not disabled_paths:
            raise RuntimeError(
                f"{module_path}.{attr} declares optional_deps but no disabled_paths; "
                "router degradation must install explicit unavailable placeholders"
            )

    # =================================================================
    import threading as _threading
    from apps.backend.config.router_registry import (
        ALL_GROUPS as _ROUTER_ALL_GROUPS,
        DEFERRED_GROUPS as _ROUTER_DEFERRED_GROUPS,
        READINESS_CRITICAL_GROUPS as _ROUTER_READINESS_CRITICAL_GROUPS,
        ROUTER_GROUPS as _ROUTER_GROUPS,
        STANDALONE_GROUPS as _ROUTER_STANDALONE_GROUPS,
    )

    _runtime_router_lock = _threading.RLock()
    _runtime_routers_installed = False
    _runtime_router_install_error: Exception | None = None

    _RUNTIME_ROUTE_PREFIXES = (
        "/api",
        "/memory",
        "/webhooks",
        "/oauth",
        "/jwt",
        "/get-token",
        "/recordings",
        "/mission",
        "/internal",
    )
    _RUNTIME_SCHEMA_PATHS = tuple(
        path
        for path in (
            _openapi_url,
            _docs_url,
            _redoc_url,
            "/docs/oauth2-redirect",
        )
        if path
    )

    def _runtime_router_load_is_deferred() -> bool:
        return os.environ.get("WORKWEAVER_EAGER_ROUTER_LOAD", "").strip().lower() not in (
            "1",
            "true",
            "yes",
        )

    def _path_needs_runtime_routers(path: str) -> bool:
        normalized = str(path or "")
        return normalized in _RUNTIME_SCHEMA_PATHS or normalized.startswith(_RUNTIME_ROUTE_PREFIXES)

    def _install_runtime_routers_once() -> None:
        global _runtime_routers_installed, _runtime_router_install_error
        if _runtime_routers_installed:
            return
        with _runtime_router_lock:
            if _runtime_routers_installed:
                return
            if _runtime_router_install_error is not None:
                raise _runtime_router_install_error
            try:
                # Data-driven router loading (#1103)
                # =================================================================
                from apps.backend.providers.base import DeploymentProfile, get_deployment_profile

                _deployment_profile = get_deployment_profile()
                _groups_to_load = (
                    _ROUTER_STANDALONE_GROUPS
                    if _deployment_profile == DeploymentProfile.standalone
                    else _ROUTER_ALL_GROUPS
                )

                _loaded_routers: dict[str, Any] = {}
                _load_failures: list[str] = []
                _degraded_router_paths: dict[str, str] = {}
                _degraded_router_failures: list[str] = []

                for group_name in _groups_to_load:
                    if group_name not in _ROUTER_GROUPS:
                        continue
                    for module_path, attr, kwargs in _ROUTER_GROUPS[group_name]:
                        bundle_name = kwargs.get("bundle")
                        # Skip voice routers when voice bundle is disabled
                        if bundle_name == "voice" and not _voice_bundle_enabled:
                            continue
                        try:
                            _validate_optional_router_contract(
                                module_path=module_path,
                                attr=attr,
                                kwargs=kwargs,
                            )
                            router = _load_router(module_path, attr)
                            key = f"{module_path}:{attr}"
                            _loaded_routers[key] = (router, kwargs)
                        except Exception as exc:
                            optional_dependency = _missing_optional_router_dependency(
                                exc=exc,
                                kwargs=kwargs,
                                deployment_profile=_deployment_profile,
                            )
                            if optional_dependency:
                                degraded_paths = tuple(
                                    str(path or "").strip()
                                    for path in kwargs.get("disabled_paths", ())
                                    if str(path or "").strip()
                                )
                                if degraded_paths:
                                    bundle_name = str(kwargs.get("bundle") or "").strip()
                                    detail_prefix = f"{bundle_name} router unavailable" if bundle_name else "router unavailable"
                                    detail = (
                                        f"{detail_prefix}: missing optional dependency "
                                        f"'{optional_dependency}' in this runtime"
                                    )
                                    for path in degraded_paths:
                                        _degraded_router_paths[path] = detail
                                _degraded_router_failures.append(
                                    f"{module_path}.{attr}: missing optional dependency {optional_dependency}"
                                )
                                logger.warning(
                                    "router_load_degraded_optional_dependency module=%s attr=%s dependency=%s profile=%s",
                                    module_path,
                                    attr,
                                    optional_dependency,
                                    _deployment_profile.value,
                                )
                                continue
                            _load_failures.append(f"{module_path}.{attr}: {exc}")
                            logger.warning("router_load_failed module=%s attr=%s error=%s", module_path, attr, exc)

                if _load_failures and _deployment_profile != DeploymentProfile.standalone:
                    logger.critical("Failed to import %d routers: %s", len(_load_failures), _load_failures)
                    raise RuntimeError(f"Router import failures in {_deployment_profile.value}: {_load_failures}")

                # Register all loaded routers
                for key, (router, kwargs) in _loaded_routers.items():
                    bundle_name = kwargs.get("bundle")
                    include_kwargs = {k: v for k, v in kwargs.items() if k not in _ROUTER_INTERNAL_KWARGS}
                    if bundle_name:
                        bundle_enum = CapabilityBundle(bundle_name)
                        if bundle_enum not in _enabled_capability_bundles:
                            continue
                    app.include_router(router, **include_kwargs)

                if _degraded_router_paths:
                    _install_unavailable_http_routes(paths=_degraded_router_paths)

                # Install disabled-voice-bundle placeholder routes (501) for all voice prefixes
                if not _voice_bundle_enabled:
                    _install_disabled_bundle_http_routes(
                        CapabilityBundle.voice,
                        [
                            "/api/connections/{path:path}",
                            "/api/recordings/{path:path}",
                            "/api/call/{path:path}",
                            "/get-token",
                            "/api/provisioning/{path:path}",
                            "/api/phone/{path:path}",
                            "/api/whatsapp/{path:path}",
                            "/api/v1/runtime/whatsapp/{path:path}",
                            "/api/twilio/{path:path}",
                            "/api/v1/voice/{path:path}",
                            "/api/v1/telephony/{path:path}",
                        ],
                    )

                # Inject the global error tracker into the diagnostics module
                try:
                    from apps.backend.api.admin_diagnostics import set_error_tracker

                    set_error_tracker(_error_tracker)
                except Exception:
                    pass  # admin_diagnostics may not be loaded in standalone

                logger.info(
                    "router_loading_complete groups=%d routers=%d failures=%d degraded_optional=%d profile=%s",
                    len(_groups_to_load),
                    len(_loaded_routers),
                    len(_load_failures),
                    len(_degraded_router_failures),
                    _deployment_profile.value,
                )
                try:
                    from apps.backend.services.runtime.startup_timeline import startup_timeline

                    startup_timeline.record(
                        "runtime-router-load",
                        metadata={
                            "profile": _deployment_profile.value,
                            "router_count": len(_loaded_routers),
                            "readiness_critical_group_count": len(_ROUTER_READINESS_CRITICAL_GROUPS),
                            "deferred_router_group_count": len(_ROUTER_DEFERRED_GROUPS),
                            "degraded_router_count": len(_degraded_router_failures),
                            "status": "degraded" if _degraded_router_failures else "ready",
                        },
                    )
                except Exception:
                    pass

                # NOTE: The legacy 138-line _load_router + include_router block was replaced
                # by the data-driven ROUTER_GROUPS loader above (#1103). The block below
                # exists only for the WorkMemory mount which is not a simple router.

                # WorkMemory routes (absorbed from learning-service, #869 Phase 4b)
                # =================================================================
                # Set WORKMEMORY_ROLE=api-only so the SQS ingest consumer does NOT
                # start inside backend replicas — only the standalone learning-service
                # worker (or a dedicated consumer task) should poll the queue.
                os.environ.setdefault("WORKMEMORY_ROLE", "api-only")

                # Keep the standalone workmemory app contract intact and gate it at mount time.
                if CapabilityBundle.workmemory in _enabled_capability_bundles:
                    from apps.backend.workmemory.api.app import app as workmemory_app

                    app.mount("/memory", workmemory_app)
                else:
                    from fastapi import FastAPI as _FastAPI

                    disabled_workmemory_app = _FastAPI()

                    @disabled_workmemory_app.api_route(
                        "/", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"], include_in_schema=False
                    )
                    async def _disabled_workmemory_root() -> None:
                        raise HTTPException(status_code=501, detail="workmemory bundle is disabled")

                    @disabled_workmemory_app.api_route(
                        "/{path:path}",
                        methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"],
                        include_in_schema=False,
                    )
                    async def _disabled_workmemory_route(path: str) -> None:  # noqa: ARG001
                        raise HTTPException(status_code=501, detail="workmemory bundle is disabled")

                    app.mount("/memory", disabled_workmemory_app)

                from apps.backend.middleware.auth_enforcement import warn_unauthenticated_routes as _warn_runtime_routes

                app.openapi_schema = None
                _warn_runtime_routes(app)
                _runtime_routers_installed = True
                app.state.runtime_routers_installed = True
            except Exception as exc:
                _runtime_router_install_error = exc
                app.state.runtime_routers_installed = False
                raise

    app.state.runtime_routers_installed = False
    app.state.install_runtime_routers = _install_runtime_routers_once
    app.state.path_needs_runtime_routers = _path_needs_runtime_routers

    class _RuntimeRouterLoaderMiddleware:
        def __init__(self, asgi_app: Any) -> None:
            self._asgi_app = asgi_app

        async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
            if _runtime_router_load_is_deferred() and scope.get("type") in {"http", "websocket"}:
                path = str(scope.get("path") or "")
                if _path_needs_runtime_routers(path):
                    _install_runtime_routers_once()
            await self._asgi_app(scope, receive, send)

    app.add_middleware(_RuntimeRouterLoaderMiddleware)

    if not _runtime_router_load_is_deferred():
        _install_runtime_routers_once()

    # =====================================================================
    # Embedded UI bundles (pip package embedding, #1258)
    # =====================================================================
    from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
    from fastapi.staticfiles import StaticFiles  # noqa: F811 (re-imported below for admin SPA)

    from apps.backend.services.embedded_assets import resolve_embedded_ui_assets

    _embedded_assets = resolve_embedded_ui_assets(
        force_dashboard_missing=os.environ.get("WORKWEAVER_FORCE_MISSING_DASHBOARD_BUNDLE", "").strip().lower()
        in ("1", "true", "yes")
    )

    if _embedded_assets.dashboard_mount_dir:
        @app.get("/dashboard", include_in_schema=False)
        async def _dashboard_root_redirect() -> RedirectResponse:
            return RedirectResponse(url="/dashboard/", status_code=307)

        app.mount(
            "/dashboard",
            StaticFiles(directory=str(_embedded_assets.dashboard_mount_dir), html=True),
            name="dashboard-spa",
        )
        _runtime_index_path = _embedded_assets.dashboard_mount_dir / "index.html"
        if _runtime_index_path.is_file():
            @app.get("/runtime", include_in_schema=False)
            async def _runtime_root() -> FileResponse:
                return FileResponse(str(_runtime_index_path), media_type="text/html; charset=utf-8")

            app.mount(
                "/runtime",
                StaticFiles(directory=str(_embedded_assets.dashboard_mount_dir), html=True),
                name="runtime-spa",
            )
        logger.info("dashboard_spa_mounted directory=%s", _embedded_assets.dashboard_mount_dir)
    else:
        async def _dashboard_bundle_missing() -> JSONResponse:
            return JSONResponse(
                {
                    "error": "dashboard_bundle_missing",
                    "detail": (
                        "Embedded dashboard assets are unavailable in this runtime. "
                        "Reinstall from a wheel that includes UI assets, or run from a full source checkout."
                    ),
                },
                status_code=503,
            )

        app.add_api_route(
            "/dashboard",
            _dashboard_bundle_missing,
            methods=["GET", "HEAD"],
            include_in_schema=False,
        )
        app.add_api_route(
            "/dashboard/{path:path}",
            _dashboard_bundle_missing,
            methods=["GET", "HEAD"],
            include_in_schema=False,
        )

    # Dashboard runtime shell references absolute asset paths (/components, /js, /utils, ...).
    # When embedded runtime assets are available, mount those roots explicitly.
    _dashboard_design_system_mounted = False
    if _embedded_assets.dashboard_root_dir:
        for _prefix in ("components", "js", "utils"):
            if (
                _prefix == "js"
                and _embedded_assets.landing_public_dir
                and (_embedded_assets.landing_public_dir / "js").is_dir()
            ):
                continue
            _path = _embedded_assets.dashboard_root_dir / _prefix
            if _path.is_dir():
                app.mount(
                    f"/{_prefix}",
                    StaticFiles(directory=str(_path), html=False),
                    name=f"dashboard-{_prefix}",
                )
        _design_system_path = _embedded_assets.dashboard_root_dir / "design-system"
        if _design_system_path.is_dir():
            app.mount(
                "/design-system",
                StaticFiles(directory=str(_design_system_path), html=False),
                name="dashboard-design-system",
            )
            _dashboard_design_system_mounted = True
        _sw_path = _embedded_assets.dashboard_root_dir / "sw.js"
        if _sw_path.is_file():
            @app.get("/sw.js", include_in_schema=False)
            async def _dashboard_sw() -> FileResponse:
                return FileResponse(str(_sw_path), media_type="application/javascript; charset=utf-8")

        _manifest_path = _embedded_assets.dashboard_root_dir / "manifest.webmanifest"
        if _manifest_path.is_file():
            @app.get("/manifest.webmanifest", include_in_schema=False)
            async def _dashboard_manifest() -> FileResponse:
                return FileResponse(str(_manifest_path), media_type="application/manifest+json; charset=utf-8")

    if _embedded_assets.landing_assets_dir:
        app.mount(
            "/landing-assets",
            StaticFiles(directory=str(_embedded_assets.landing_assets_dir), html=False),
            name="landing-assets",
        )

    if _embedded_assets.login_dir:
        _login_index_path = _embedded_assets.login_dir / "index.html"
        if _login_index_path.is_file():
            def _self_host_login_html() -> str:
                html = _login_index_path.read_text(encoding="utf-8")
                html = html.replace(
                    '  <script src="https://accounts.google.com/gsi/client" async defer></script>\n',
                    "",
                )
                html = html.replace("https://workweaver.ai/login", "/login")
                html = html.replace("return 'https://workweaver.ai';", "return window.location.origin;")
                html = html.replace(
                    "return `https://workweaver.ai/login${suffix}${hash}`;",
                    "return window.location.href;",
                )
                html = html.replace(
                    "return CLI_CLIENT_MODE && isLocalPreviewHost() && !override;",
                    "return false; // self-host login stays local",
                )
                return html

            def _login_response(request: Request):
                if _is_self_host_ui_request(request):
                    return HTMLResponse(
                        _self_host_login_html(),
                        media_type="text/html; charset=utf-8",
                    )
                return FileResponse(str(_login_index_path), media_type="text/html; charset=utf-8")

            @app.get("/login", include_in_schema=False)
            async def _login_root(request: Request):
                return _login_response(request)

            @app.get("/login/", include_in_schema=False)
            async def _login_slash(request: Request):
                return _login_response(request)

            @app.get("/login/index.html", include_in_schema=False)
            async def _login_index(request: Request):
                return _login_response(request)

        app.mount(
            "/login",
            StaticFiles(directory=str(_embedded_assets.login_dir), html=True),
            name="login-spa",
        )

    # Issue #3506 — standalone tenant inference settings panel. Lives under
    # /settings/inference/ so wheel installs that omit the dashboard SPA
    # still serve the BYOI / "Connect with ChatGPT" UI without bouncing
    # the user back into /runtime/. The OAuth callback HTML stays at
    # /settings/inference-oauth-callback.html (CloudFront-served on
    # workweaver.ai); embedding mounts both for parity.
    if _embedded_assets.settings_inference_dir:
        app.mount(
            "/settings/inference",
            StaticFiles(directory=str(_embedded_assets.settings_inference_dir), html=True),
            name="settings-inference-panel",
        )

    # =====================================================================
    # Admin Portal SPA (admin.workweaver.ai)
    # =====================================================================
    #
    # admin.workweaver.ai now rides the canonical API/admin public edge. When the
    # Host header is admin.workweaver.ai we serve the self-contained SPA at
    # apps/admin-portal/ instead of the API root JSON.
    #
    # Access is gated in TWO places:
    #   1. The SPA calls /api/v1/auth/me and checks the `is_admin` flag set by
    #      the backend based on WORKWEAVER_ADMIN_EMAILS env var.
    #   2. All /api/v1/admin/* endpoints use Depends(require_platform_admin)
    #      which re-validates the caller's email against the same env var
    #      server-side — so even if someone bypasses the SPA shell, the API
    #      refuses to serve data.
    #
    # The admin allowlist is intentionally a small, hard-to-mutate env var
    # managed by terraform. Tenants cannot escalate themselves into it.
    _ADMIN_PORTAL_DIR = (
        str(_embedded_assets.admin_portal_dir)
        if _embedded_assets.admin_portal_dir
        else os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "admin-portal"))
    )
    # The admin SPA at apps/landing/public/admin/ references /css/ and /js/ paths
    # from the parent landing directory. Resolve the landing public root so we
    # can serve those static assets for admin.workweaver.ai.
    _admin_landing_public = (
        str(Path(_ADMIN_PORTAL_DIR).parent)
        if _ADMIN_PORTAL_DIR and os.path.isdir(_ADMIN_PORTAL_DIR)
        else None
    )
    # Canonical host-routing matcher lives in apps.backend.config.admin_host so
    # it stays testable in unit tests without booting the full FastAPI app
    # (regression surface for issue #1167).
    from apps.backend.config.admin_host import (
        ADMIN_SPA_ROUTES as _ADMIN_HOST_SPA_ROUTES,
        is_admin_host as _is_admin_host_value,
        is_admin_host_request as _is_admin_host,
    )
    # _ADMIN_HOST_SPA_ROUTES is re-exported from the shared module so the
    # registration list below and the regression tests consume the same tuple.
    _ADMIN_SPA_ROUTES = _ADMIN_HOST_SPA_ROUTES

    if os.path.isdir(_ADMIN_PORTAL_DIR):
        # Serve static assets (subdirectories, icons, etc.) at /_admin-assets/*
        # so they never collide with any /api/* or /admin/* backend paths.
        app.mount(
            "/_admin-assets",
            StaticFiles(directory=_ADMIN_PORTAL_DIR, html=False),
            name="admin-portal-assets",
        )

    # Serve landing CSS/JS for admin.workweaver.ai so the admin SPA can load
    # its referenced stylesheets and scripts (/css/*, /js/*).
    if _admin_landing_public and os.path.isdir(_admin_landing_public):
        for _static_sub in ("css", "js", "design-system"):
            if _static_sub == "design-system" and _dashboard_design_system_mounted:
                continue
            _sub_path = os.path.join(_admin_landing_public, _static_sub)
            if os.path.isdir(_sub_path):
                app.mount(
                    f"/{_static_sub}",
                    StaticFiles(directory=_sub_path, html=False),
                    name=f"admin-landing-{_static_sub}",
                )

    def _bootstrap_diagnostics_response():
        from apps.backend.services.runtime.bootstrap_diagnostics import (
            DiagnosticPhase,
            DiagnosticResult,
            DiagnosticSeverity,
            HealthCheckResponse,
            build_bootstrap_diagnostics_gate,
        )

        gate = getattr(app.state, "bootstrap_diagnostics_gate", None)
        if gate is None:
            gate = build_bootstrap_diagnostics_gate()
            app.state.bootstrap_diagnostics_gate = gate

        try:
            return gate.run_diagnostics()
        except Exception as exc:
            logger.exception("bootstrap_diagnostics.health_check_failed")
            return HealthCheckResponse(
                healthy=False,
                http_status=503,
                results=[
                    DiagnosticResult(
                        phase=DiagnosticPhase.CONFIG_VALIDATION,
                        severity=DiagnosticSeverity.CRITICAL,
                        message=f"Diagnostic runner failed: {exc}",
                        repair_hint="Inspect backend startup diagnostics and restart after repair.",
                    )
                ],
            )

    def _bootstrap_health_response_payload() -> tuple[int, dict[str, Any]]:
        payload: dict[str, Any] = build_public_health_payload()
        diagnostics = _bootstrap_diagnostics_response()

        diagnostics_body = diagnostics.to_dict()
        diagnostics_body.pop("timestamp", None)
        payload["diagnostics"] = diagnostics_body
        if not diagnostics.healthy or diagnostics.http_status >= 500:
            payload["status"] = "degraded"
        return diagnostics.http_status, payload

    # =====================================================================    # Health Check
    # =====================================================================
    @app.get("/health")
    async def health_check():
        """Health check endpoint for API Gateway/Lambda."""
        status_code, payload = _bootstrap_health_response_payload()
        return JSONResponse(status_code=status_code, content=payload)

    @app.get("/ready")
    async def readiness_probe():
        """Readiness probe (issue #3266).

        Returns 200 ``ready`` while the pod can accept new traffic, 503
        ``draining`` once SIGTERM/lifespan-shutdown begins. Load balancers
        consult this to stop routing during the drain window.
        """
        from apps.backend.services.runtime.runtime_drain_controller import (
            DrainState,
            get_runtime_drain_controller,
        )

        controller = getattr(app.state, "runtime_drain_controller", None) or get_runtime_drain_controller()
        if controller.is_ready_for_traffic():
            diagnostics = _bootstrap_diagnostics_response()
            if not diagnostics.healthy or diagnostics.http_status >= 500:
                diagnostics_body = diagnostics.to_dict()
                diagnostics_body.pop("timestamp", None)
                return JSONResponse(
                    status_code=503,
                    content={
                        "state": "not_ready",
                        "diagnostics": diagnostics_body,
                    },
                )
            return JSONResponse(status_code=200, content={"state": "ready"})
        body: dict[str, Any] = {"state": controller.state.value}
        report = controller.final_report
        if report is not None:
            body.update(
                {
                    "pod_id": report.pod_id,
                    "sessions_active": report.sessions_active,
                    "sessions_suspended": report.sessions_suspended,
                    "sessions_abandoned": report.sessions_abandoned,
                    "total_ms": report.total_ms,
                    "caused_by": report.caused_by,
                    "budget_exhausted": report.budget_exhausted,
                }
            )
        # 503 while DRAINING or DRAINED so the LB stops routing new traffic.
        body["state"] = "draining" if controller.state is DrainState.DRAINING else "drained"
        return JSONResponse(status_code=503, content=body)

    def _is_self_host_ui_request(_request: Request) -> bool:
        self_host = os.environ.get("WORKWEAVER_SELF_HOST", "").strip().lower() in {"1", "true", "yes"}
        explicit_self_host = (
            os.environ.get("WORKWEAVER_DEPLOYMENT_PROFILE", "").strip().lower() == "self_host_production"
        )
        return self_host or explicit_self_host

    def _admin_login_href(request: Request) -> str:
        if _is_self_host_ui_request(request):
            return "/login?next=/admin/"
        return "https://workweaver.ai/login"

    def _admin_login_response(request: Request) -> HTMLResponse:
        login_href = _admin_login_href(request)
        status_code = 200 if _is_self_host_ui_request(request) else 401
        login_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In | Workweaver Admin</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f5f5f5; }}
    .login-card {{ background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }}
    h1 {{ margin: 0 0 16px; color: #333; }}
    p {{ color: #666; line-height: 1.5; margin: 0 0 24px; }}
    a {{ display: inline-block; padding: 12px 24px; background: #e8852a; color: white; text-decoration: none; border-radius: 6px; }}
    a:hover {{ background: #d47a2e; }}
  </style>
</head>
<body>
  <div class="login-card">
    <h1>Workweaver Admin</h1>
    <p>Use the same Workweaver sign-in as the tenant workspace. The founder portal opens here after authentication if your account is an admin.</p>
    <a href="{login_href}">Sign in to Workweaver</a>
  </div>
</body>
</html>"""
        return HTMLResponse(content=login_html, status_code=status_code)

    def _admin_denial_response() -> HTMLResponse:
        denial_html = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Access Denied | Workweaver</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f5f5f5; }
    .denial-card { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.1); text-align: center; max-width: 400px; }
    h1 { margin: 0 0 16px; color: #333; }
    p { color: #666; line-height: 1.5; margin: 0 0 24px; }
    a { display: inline-block; padding: 10px 20px; background: #e8852a; color: white; text-decoration: none; border-radius: 6px; }
    a:hover { background: #d47a2e; }
  </style>
</head>
<body>
  <div class="denial-card">
    <h1>Access Denied</h1>
    <p>This admin portal is restricted to Workweaver founders.</p>
    <a href="/mission">Go to Workspace</a>
  </div>
</body>
</html>"""
        return HTMLResponse(content=denial_html, status_code=403)

    # =====================================================================    # Root Endpoint
    # =====================================================================
    @app.get("/")
    async def root(request: Request):
        """Root endpoint.

        Serves the admin portal SPA when the Host header is admin.workweaver.ai
        (so the user gets a login UI), otherwise returns the standard API root
        JSON for all other hosts (api.workweaver.ai, direct ALB hits, etc.).
        """
        if _is_admin_host(request):
            # Server-side auth gate for admin portal root (issue #2694)
            from apps.backend.api.founder_admin import require_founder

            try:
                # This will raise HTTPException 401 if no auth, or 403 if not a founder
                require_founder(request)
            except HTTPException as exc:
                if exc.status_code == status.HTTP_401_UNAUTHORIZED:
                    return _admin_login_response(request)
                return _admin_denial_response()

            # Authenticated founder: serve admin SPA index
            index_path = os.path.join(_ADMIN_PORTAL_DIR, "index.html")
            if os.path.isfile(index_path):
                return FileResponse(
                    index_path,
                    media_type="text/html; charset=utf-8",
                )
            return JSONResponse(
                {"error": "admin_portal_unavailable"},
                status_code=503,
            )
        return {
            "name": "Workweaver API",
            "version": "1.0.0",
            "description": "Workweaver AI Platform API",
            "docs": "/docs",
            "health": "/health",
        }

    # SPA history-mode fallback: /admin, /admin/*, /dashboard, /tenants, etc. on
    # admin.workweaver.ai should all serve the SPA shell. We catch a small set of
    # known SPA routes (sourced from apps.backend.config.admin_host so unit
    # tests and production runtime share the same tuple) rather than a
    # wildcard so we don't accidentally shadow real API paths.

    async def _serve_admin_spa(request: Request):
        if not (_is_admin_host(request) or _is_self_host_ui_request(request)):
            return JSONResponse({"error": "not_found"}, status_code=404)

        # Server-side auth gate: verify founder session before serving any static file (issue #2694)
        from apps.backend.api.founder_admin import require_founder

        try:
            # This will raise HTTPException 401 if no auth, or 403 if not a founder
            require_founder(request)
        except HTTPException as exc:
            if exc.status_code == status.HTTP_401_UNAUTHORIZED:
                return _admin_login_response(request)
            return _admin_denial_response()

        # Authenticated founder: serve the requested static file
        # Try to resolve path to a file inside admin-portal first
        rel = request.url.path.lstrip("/")
        candidate = os.path.normpath(os.path.join(_ADMIN_PORTAL_DIR, rel))
        # Defense-in-depth: ensure we stay inside the admin-portal directory
        if candidate.startswith(_ADMIN_PORTAL_DIR + os.sep) and os.path.isfile(candidate):
            return FileResponse(candidate)
        index_path = os.path.join(_ADMIN_PORTAL_DIR, "index.html")
        if os.path.isfile(index_path):
            return FileResponse(
                index_path,
                media_type="text/html; charset=utf-8",
            )
        return JSONResponse({"error": "admin_portal_unavailable"}, status_code=503)

    for _route in _ADMIN_SPA_ROUTES:
        app.add_api_route(
            _route,
            _serve_admin_spa,
            methods=["GET"],
            include_in_schema=False,
        )
        app.add_api_route(
            _route + "/",
            _serve_admin_spa,
            methods=["GET"],
            include_in_schema=False,
        )
        # Register the explicit index.html variant so deep links such as
        # /admin/inference/index.html and /admin/meeting/index.html resolve to
        # the real bundled static file instead of falling through to a FastAPI
        # 404 JSON payload. The admin control planes are navigated directly;
        # this route keeps packaged/static resolution honest across shells.
        app.add_api_route(
            _route + "/index.html",
            _serve_admin_spa,
            methods=["GET"],
            include_in_schema=False,
        )

    # =====================================================================
    # Auth posture audit (#1931): warn on routes missing auth + not in public registry.
    # =====================================================================
    if not _runtime_router_load_is_deferred():
        from apps.backend.middleware.auth_enforcement import warn_unauthenticated_routes

        warn_unauthenticated_routes(app)

    # =====================================================================
    # Lambda Handler
    # =====================================================================
    # Allowed origins for Lambda CORS preflight - must match FastAPI CORS config above.
    _lambda_allowed_origins = {
        "https://workweaver.ai",
        "https://www.workweaver.ai",
        "https://admin.workweaver.ai",
        "https://infra.workweaver.ai",
        "https://www.infra.workweaver.ai",
    }

    def _lambda_event_path(event: Any) -> str:
        http_context = (event.get("requestContext") or {}).get("http") or {}
        return str(event.get("rawPath") or http_context.get("path") or event.get("path") or "/")

    def _lambda_event_method(event: Any) -> str:
        http_context = (event.get("requestContext") or {}).get("http") or {}
        return str(http_context.get("method") or event.get("httpMethod") or "GET").upper()

    def _lambda_event_header(event: Any, name: str) -> str:
        wanted = name.lower()
        for key, value in (event.get("headers") or {}).items():
            if str(key).lower() == wanted:
                return str(value or "")
        return ""

    def _lambda_cors_response(event: Any) -> dict[str, Any] | None:
        if _lambda_event_method(event) != "OPTIONS":
            return None
        origin = ((event.get("headers") or {}).get("origin") or (event.get("headers") or {}).get("Origin") or "")
        if origin not in _lambda_allowed_origins:
            return {"statusCode": 403, "body": "Origin not allowed"}
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": origin,
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
                "Access-Control-Allow-Headers": "content-type, authorization, x-tenant-id, x-request-id, x-amz-date, x-api-key",
                "Access-Control-Allow-Credentials": "true",
                "Access-Control-Max-Age": "86400",
            },
            "body": "",
        }

    def _lambda_fast_response(event: Any) -> dict[str, Any] | None:
        import json

        method = _lambda_event_method(event)
        path = _lambda_event_path(event)
        if method == "GET" and path in {"/health", "/edge/health"}:
            return {
                "statusCode": 200,
                "headers": {"content-type": "application/json"},
                "body": json.dumps(build_public_health_payload()),
            }
        if method == "GET" and path == "/" and not _is_admin_host_value(
            _lambda_event_header(event, "host"),
            _lambda_event_header(event, "x-forwarded-host"),
            origin_header=_lambda_event_header(event, "origin"),
        ):
            return {
                "statusCode": 200,
                "headers": {"content-type": "application/json"},
                "body": json.dumps(
                    {
                        "name": "Workweaver API",
                        "version": "1.0.0",
                        "description": "Workweaver AI Platform API",
                        "docs": "/docs",
                        "health": "/health",
                    }
                ),
            }
        return None

    if Mangum is not None:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.set_event_loop(asyncio.new_event_loop())
        _mangum_handler = Mangum(app, lifespan="auto")

        # Allowed origins for Lambda CORS preflight — must match FastAPI CORS config above.
        _lambda_allowed_origins = {
            "https://workweaver.ai",
            "https://www.workweaver.ai",
            "https://admin.workweaver.ai",
            "https://infra.workweaver.ai",
            "https://www.infra.workweaver.ai",
        }

        def lambda_handler(event, context):
            """Lambda handler with explicit OPTIONS support for CORS preflight."""
            cors_response = _lambda_cors_response(event)
            if cors_response is not None:
                return cors_response
            fast_response = _lambda_fast_response(event)
            if fast_response is not None:
                return fast_response
            return _mangum_handler(event, context)
    else:

        def lambda_handler(event, context):  # type: ignore[no-redef]
            cors_response = _lambda_cors_response(event)
            if cors_response is not None:
                return cors_response
            fast_response = _lambda_fast_response(event)
            if fast_response is not None:
                return fast_response
            raise RuntimeError("Mangum is not installed; Lambda handler is unavailable in this environment")
