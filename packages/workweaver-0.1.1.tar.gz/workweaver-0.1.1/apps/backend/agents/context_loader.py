"""
Context Loader Agent

Loads context for Zara (Voice AI) before call handling:
- Query precedents for similar past decisions
- Query CRM for user/lead information
- Combine into structured context for voice interaction

Reference: docs/PRODUCT.md P1.3.0 - 3-Agent Voice Architecture
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from apps.backend.services.precedent_query import (
    PrecedentQuery,
    PrecedentQueryResult,
    PrecedentMatch,
)


logger = logging.getLogger(__name__)


# ==================== Data Models ====================


@dataclass
class CRMContext:
    """Context from CRM system about caller/lead.

    Attributes:
        lead_id: Unique lead identifier
        name: Contact name
        company: Company name
        status: Lead status (hot, warm, cool, non-lead)
        tags: Lead tags for categorization
        last_contact: Last contact timestamp
        notes: Recent notes or activities
        custom_fields: Any custom CRM fields (vertical-specific)
    """

    lead_id: str | None = None
    name: str | None = None
    company: str | None = None
    status: str | None = None
    tags: list[str] = field(default_factory=list)
    last_contact: datetime | None = None
    notes: str | None = None
    custom_fields: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result = {
            "lead_id": self.lead_id,
            "name": self.name,
            "company": self.company,
            "status": self.status,
            "tags": self.tags,
            "last_contact": self.last_contact.isoformat() if self.last_contact else None,
            "notes": self.notes,
            "custom_fields": self.custom_fields,
        }
        return {k: v for k, v in result.items() if v is not None}


@dataclass
class PrecedentContext:
    """Context from similar past decisions.

    Attributes:
        precedents: List of similar precedents
        top_precedent: Most relevant precedent (highest score)
        decision_type: Type of decision being considered
        similar_count: Number of precedents found
        freshness_summary: Average freshness of precedents
    """

    precedents: list[PrecedentMatch] = field(default_factory=list)
    top_precedent: PrecedentMatch | None = None
    decision_type: str | None = None
    similar_count: int = 0
    freshness_summary: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "precedents": [p.__dict__ for p in self.precedents],
            "top_precedent": self.top_precedent.__dict__ if self.top_precedent else None,
            "decision_type": self.decision_type,
            "similar_count": self.similar_count,
            "freshness_summary": self.freshness_summary,
        }


@dataclass
class VoiceContext:
    """Combined context for voice interaction.

    This is the complete context that Zara uses during voice calls.
    Combines precedent history with CRM lead information.

    Attributes:
        tenant_id: Tenant identifier
        caller_phone: Caller phone number (E.164)
        call_sid: Twilio call SID (if available)
        precedents: Context from similar past decisions
        crm: Context from CRM system
        loaded_at: When context was loaded
        load_time_ms: Time taken to load context in milliseconds
    """

    tenant_id: str
    caller_phone: str
    call_sid: str | None = None
    precedents: PrecedentContext | None = None
    crm: CRMContext | None = None
    loaded_at: datetime = field(default_factory=lambda: datetime.now(UTC).replace(tzinfo=None))
    load_time_ms: int = 0
    preload_status: str = "complete"
    preload_reason: str = ""
    preload_trace_id: str = ""
    preload_budget_ms: int = 0
    agent_context_prompt: str | None = None  # Session continuity prompt from SessionContinuityService
    customer_context_prompt: str | None = None  # Customer personalization prompt from CustomerContextStore

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result = {
            "tenant_id": self.tenant_id,
            "caller_phone": self.caller_phone,
            "call_sid": self.call_sid,
            "precedents": self.precedents.to_dict() if self.precedents else None,
            "crm": self.crm.to_dict() if self.crm else None,
            "loaded_at": self.loaded_at.isoformat(),
            "load_time_ms": self.load_time_ms,
            "preload_status": self.preload_status,
            "preload_reason": self.preload_reason,
            "preload_trace_id": self.preload_trace_id,
            "preload_budget_ms": self.preload_budget_ms,
            "agent_context_prompt": self.agent_context_prompt,
            "customer_context_prompt": self.customer_context_prompt,
        }
        return {k: v for k, v in result.items() if v is not None}

    def get_context_summary(self) -> str:
        """Get human-readable context summary for Zara's prompt."""
        parts = []

        # Session continuity context (prepended — highest priority for agent awareness)
        if self.agent_context_prompt:
            parts.append(self.agent_context_prompt)

        # CRM context
        if self.crm and self.crm.name:
            crm_info = f"Caller: {self.crm.name}"
            if self.crm.company:
                crm_info += f" ({self.crm.company})"
            if self.crm.status:
                crm_info += f" - Status: {self.crm.status}"
            parts.append(crm_info)

        # Customer context prompt (stored personalization)
        if self.customer_context_prompt:
            parts.append(self.customer_context_prompt)

        # Precedent context
        if self.precedents and self.precedents.top_precedent:
            precedent_info = (
                f"Similar past situation: {self.precedents.top_precedent.summary} "
                f"(similarity: {self.precedents.top_precedent.similarity_score:.2f})"
            )
            parts.append(precedent_info)

        if self.precedents and self.precedents.similar_count > 0:
            parts.append(f"Found {self.precedents.similar_count} similar past interactions")

        return "\n".join(parts)


# ==================== Context Loader Agent ====================


class ContextLoaderAgent:
    """
    Agent that loads context for voice interactions.

    Context includes:
    1. Precedents: Similar past decisions (from Operational Context)
    2. CRM Data: Lead/contact information (from CRM integration)
    3. Combined: Structured context for Zara's prompt

    Design principles:
    - Fast context loading (voice latency budget)
    - Tenant isolation enforced
    - Graceful degradation (works even if CRM is unavailable)
    - Structured output for prompt injection
    """

    def __init__(
        self,
        tenant_id: str,
        precedent_query: PrecedentQuery | None = None,
        dynamodb_client: Any | None = None,
        agent_id: str | None = None,
        session_continuity_service: Any | None = None,
        customer_context_store: Any | None = None,
    ):
        """
        Initialize Context Loader agent.

        Args:
            tenant_id: Tenant identifier (with or without TENANT# prefix)
            precedent_query: Optional PrecedentQuery instance (creates default if None)
            dynamodb_client: Optional DynamoDB client for PrecedentQuery
            agent_id: Optional AI agent identifier for session continuity loading
            session_continuity_service: Optional SessionContinuityService for no-amnesia context
            customer_context_store: Optional CustomerContextStore for customer personalization
        """
        # Normalize tenant_id
        if not tenant_id.startswith("TENANT#"):
            self.tenant_id = f"TENANT#{tenant_id}"
        else:
            self.tenant_id = tenant_id

        self.agent_id = agent_id
        self.session_continuity_service = session_continuity_service
        self.customer_context_store = customer_context_store
        if self.customer_context_store is None:
            try:
                from apps.backend.services.customer_context_store import get_customer_context_store

                self.customer_context_store = get_customer_context_store()
            except Exception:
                # Optional dependency; context loading should still work without it.
                self.customer_context_store = None

        # Initialize precedent query service
        if precedent_query:
            self.precedent_query = precedent_query
        else:
            self.precedent_query = PrecedentQuery(dynamodb_client=dynamodb_client)

    async def load_context(
        self,
        caller_phone: str,
        decision_summary: str | None = None,
        decision_type: str = "tool_call",
        top_k: int = 3,
        query_crm: bool = True,
    ) -> VoiceContext:
        """
        Load complete context for voice interaction.

        Workflow:
        1. Query precedents for similar past decisions
        2. Query CRM for lead information (if enabled)
        3. Combine into VoiceContext
        4. Return structured context for Zara

        Args:
            caller_phone: Caller phone number (E.164 format)
            decision_summary: Summary of current situation for precedent search
            decision_type: Type of decision (tool_call, exception_granted, policy_override)
            top_k: Number of precedents to retrieve
            query_crm: Whether to query CRM (default: True)

        Returns:
            VoiceContext with complete context for voice interaction
        """
        import time

        start_time = time.time()

        logger.info(
            f"Loading context for tenant {self.tenant_id}, caller: {caller_phone}, decision_type: {decision_type}"
        )

        # Step 1: Query precedents and CRM in parallel.
        precedent_task = asyncio.create_task(
            self._load_precedent_context(
                caller_phone=caller_phone,
                decision_summary=decision_summary,
                decision_type=decision_type,
                top_k=top_k,
            )
        )
        crm_task = asyncio.create_task(self._load_crm_context(caller_phone=caller_phone)) if query_crm else None

        precedent_ctx = await precedent_task
        crm_ctx = await crm_task if crm_task is not None else None

        # Step 2: Load customer personalization context and session continuity in parallel.
        customer_ctx_prompt = None
        customer_id = self._resolve_customer_id(caller_phone=caller_phone, crm_ctx=crm_ctx)
        customer_task = None
        if self.customer_context_store and customer_id:
            customer_task = asyncio.create_task(
                asyncio.to_thread(
                    self.customer_context_store.build_context_prompt,
                    self.tenant_id,
                    customer_id,
                )
            )

        agent_task = None
        if self.session_continuity_service and self.agent_id:
            agent_task = asyncio.create_task(
                asyncio.to_thread(
                    self.session_continuity_service.build_session_prompt,
                    self.tenant_id,
                    self.agent_id,
                )
            )

        if customer_task is not None:
            try:
                prompt = await customer_task
                customer_ctx_prompt = prompt or None
            except Exception as e:
                logger.warning(
                    "Customer context load failed for caller %s customer_id=%s: %s",
                    caller_phone,
                    customer_id,
                    e,
                )

        agent_ctx_prompt = None
        if agent_task is not None:
            try:
                agent_ctx_prompt = await agent_task
            except Exception as e:
                logger.warning(f"Session context load failed for agent {self.agent_id}: {e}")

        # Calculate load time
        load_time_ms = int((time.time() - start_time) * 1000)

        # Step 4: Combine into VoiceContext
        voice_context = VoiceContext(
            tenant_id=self.tenant_id,
            caller_phone=caller_phone,
            precedents=precedent_ctx,
            crm=crm_ctx,
            load_time_ms=load_time_ms,
            preload_status="complete",
            preload_reason="",
            preload_trace_id="",
            preload_budget_ms=0,
            agent_context_prompt=agent_ctx_prompt,
            customer_context_prompt=customer_ctx_prompt,
        )

        logger.info(
            f"Context loaded successfully: tenant={self.tenant_id}, "
            f"precedents={len(precedent_ctx.precedents) if precedent_ctx else 0}, "
            f"crm={'loaded' if crm_ctx else 'skipped'}, "
            f"customer={'loaded' if customer_ctx_prompt else 'skipped'}, "
            f"session={'loaded' if agent_ctx_prompt else 'skipped'}, "
            f"time={load_time_ms}ms"
        )

        return voice_context

    @staticmethod
    def _normalize_customer_id(raw_id: str) -> str:
        value = (raw_id or "").strip()
        if not value:
            return ""
        return value.replace(" ", "").replace("(", "").replace(")", "").replace("-", "")

    def _resolve_customer_id(self, caller_phone: str, crm_ctx: CRMContext | None) -> str:
        """Resolve stable customer id from CRM first, then caller phone fallback."""
        if crm_ctx and crm_ctx.lead_id:
            return self._normalize_customer_id(str(crm_ctx.lead_id))
        return self._normalize_customer_id(caller_phone)

    async def _load_precedent_context(
        self,
        caller_phone: str,
        decision_summary: str | None,
        decision_type: str,
        top_k: int,
    ) -> PrecedentContext | None:
        """
        Load precedent context for caller.

        Args:
            caller_phone: Caller phone number
            decision_summary: Summary for precedent search
            decision_type: Type of decision
            top_k: Number of precedents to retrieve

        Returns:
            PrecedentContext with similar decisions
        """
        if not decision_summary:
            logger.warning(f"No decision_summary provided for caller {caller_phone}, skipping precedent query")
            return None

        try:
            # Query precedents
            result: PrecedentQueryResult = self.precedent_query.find_precedents(
                tenant_id=self.tenant_id,
                decision_summary=decision_summary,
                decision_type=decision_type,
                top_k=top_k,
                min_freshness=0.3,  # Require reasonably fresh precedents
            )

            if not result.precedents:
                logger.info(f"No precedents found for caller {caller_phone}, decision_type: {decision_type}")
                return None

            # Get top precedent (highest score)
            top_precedent = result.precedents[0] if result.precedents else None

            # Calculate average freshness
            if result.precedents:
                freshness_scores = [p.similarity_score for p in result.precedents]
                avg_freshness = sum(freshness_scores) / len(freshness_scores)
            else:
                avg_freshness = None

            return PrecedentContext(
                precedents=result.precedents,
                top_precedent=top_precedent,
                decision_type=decision_type,
                similar_count=len(result.precedents),
                freshness_summary=avg_freshness,
            )

        except Exception as e:
            logger.error(f"Error loading precedent context for caller {caller_phone}: {e}", exc_info=True)
            return None

    async def _load_crm_context(
        self,
        caller_phone: str,
    ) -> CRMContext | None:
        """
        Load CRM context for caller via Zoho CRM.

        Searches Zoho Leads by Mobile/Phone field using the caller's E.164 number.
        Returns None gracefully if Zoho is not configured or the lead is not found.

        Args:
            caller_phone: Caller phone number (E.164, e.g. +14155552671)

        Returns:
            CRMContext with lead information, or None if unavailable
        """
        try:
            from apps.backend.services.zoho.crm import get_zoho_crm_service

            crm = await get_zoho_crm_service(tenant_id=self.tenant_id)

            # Zoho CRM search by phone: criteria=(Mobile:equals:<phone>)
            # Falls back to searching Phone field if no Mobile match found.
            normalized_phone = caller_phone.strip()
            lead_data = await self._zoho_search_by_phone(crm, normalized_phone)

            if not lead_data:
                logger.info("No Zoho lead found for caller %s", caller_phone)
                return None

            # Map Zoho lead fields to CRMContext
            return self._map_zoho_lead_to_crm_context(lead_data)

        except ValueError as e:
            # Zoho not configured (missing credentials) — degrade gracefully.
            logger.warning(
                "Zoho CRM not configured for CRM context lookup (caller %s): %s",
                caller_phone,
                e,
            )
            return None
        except Exception as e:
            logger.error(
                "Error loading CRM context for caller %s: %s",
                caller_phone,
                e,
                exc_info=True,
            )
            return None

    async def _zoho_search_by_phone(
        self,
        crm: Any,
        phone: str,
    ) -> dict[str, Any] | None:
        """
        Search Zoho Leads by phone number.

        Tries Mobile field first, then Phone field.  Returns the first matching
        lead's full record, or None if not found.

        Args:
            crm: ZohoCRMService instance
            phone: E.164 phone number

        Returns:
            Lead dict from Zoho, or None
        """
        for field_name in ("Mobile", "Phone"):
            try:
                response = await crm._make_api_request(
                    method="GET",
                    path="/Leads/search",
                    query={"criteria": f"({field_name}:equals:{phone})"},
                )
                rows = response.get("data") if isinstance(response, dict) else None
                if rows and isinstance(rows, list):
                    first = rows[0]
                    if isinstance(first, dict):
                        # Fetch full record to get all fields
                        lead_id = str(first.get("id") or "").strip()
                        if lead_id:
                            full_record = await crm.get_lead(lead_id)
                            return full_record or first
            except Exception as exc:
                logger.debug(
                    "Zoho phone search (%s) failed for %s: %s",
                    field_name,
                    phone,
                    exc,
                )
        return None

    @staticmethod
    def _map_zoho_lead_to_crm_context(lead: dict[str, Any]) -> CRMContext:
        """
        Map a Zoho lead record to CRMContext.

        Zoho field names use title-case (First_Name, Last_Name, Company, etc.).

        Args:
            lead: Raw Zoho lead dict

        Returns:
            CRMContext populated from the lead record
        """
        first = (lead.get("First_Name") or "").strip()
        last = (lead.get("Last_Name") or "").strip()
        name = f"{first} {last}".strip() or None

        # Zoho lead status maps to our status field
        raw_status = (lead.get("Lead_Status") or "").strip().lower()

        # Translate Zoho status labels to internal vocab
        status_map: dict[str, str] = {
            "hot": "hot",
            "warm": "warm",
            "cold": "cool",
            "cool": "cool",
            "non-lead": "non-lead",
            "not qualified": "non-lead",
        }
        status = status_map.get(raw_status, raw_status) or None

        # Tags from Zoho Tag field (comma-separated string or list)
        raw_tags = lead.get("Tag") or []
        if isinstance(raw_tags, str):
            tags = [t.strip() for t in raw_tags.split(",") if t.strip()]
        elif isinstance(raw_tags, list):
            tags = [str(t).strip() for t in raw_tags if t]
        else:
            tags = []

        # Last contact: prefer Modified_Time, fall back to Created_Time
        last_contact: datetime | None = None
        for ts_field in ("Modified_Time", "Created_Time"):
            ts_val = lead.get(ts_field)
            if ts_val:
                try:
                    last_contact = datetime.fromisoformat(str(ts_val).replace("Z", "+00:00"))
                    break
                except (ValueError, TypeError):
                    pass

        # Notes: combine Description and Last_Activity_Time for brevity
        notes_parts = []
        if lead.get("Description"):
            notes_parts.append(str(lead["Description"]).strip())
        notes = "\n".join(notes_parts) or None

        # Custom fields: everything not in standard mapping goes here
        standard_keys = {
            "id",
            "First_Name",
            "Last_Name",
            "Company",
            "Lead_Status",
            "Tag",
            "Modified_Time",
            "Created_Time",
            "Description",
            "Mobile",
            "Phone",
            "Email",
        }
        custom_fields = {k: v for k, v in lead.items() if k not in standard_keys and v is not None}

        return CRMContext(
            lead_id=str(lead.get("id") or "").strip() or None,
            name=name,
            company=(lead.get("Company") or "").strip() or None,
            status=status,
            tags=tags,
            last_contact=last_contact,
            notes=notes,
            custom_fields=custom_fields,
        )

    def load_context_sync(
        self,
        caller_phone: str,
        decision_summary: str | None = None,
        decision_type: str = "tool_call",
        top_k: int = 3,
        query_crm: bool = True,
    ) -> VoiceContext:
        """
        Load context synchronously (for synchronous code paths).

        Args:
            caller_phone: Caller phone number (E.164 format)
            decision_summary: Summary of current situation for precedent search
            decision_type: Type of decision (tool_call, exception_granted, policy_override)
            top_k: Number of precedents to retrieve
            query_crm: Whether to query CRM (default: True)

        Returns:
            VoiceContext with complete context for voice interaction
        """
        import asyncio

        # Run async code in event loop
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(
            self.load_context(
                caller_phone=caller_phone,
                decision_summary=decision_summary,
                decision_type=decision_type,
                top_k=top_k,
                query_crm=query_crm,
            )
        )


# ==================== Convenience Functions ====================


def get_context_loader(
    tenant_id: str,
    dynamodb_client: Any | None = None,
    customer_context_store: Any | None = None,
) -> ContextLoaderAgent:
    """
    Factory function to get Context Loader agent instance.

    Args:
        tenant_id: Tenant identifier
        dynamodb_client: Optional DynamoDB client for testing

    Returns:
        ContextLoaderAgent instance
    """
    return ContextLoaderAgent(
        tenant_id=tenant_id,
        dynamodb_client=dynamodb_client,
        customer_context_store=customer_context_store,
    )


async def load_voice_context(
    tenant_id: str,
    caller_phone: str,
    call_sid: str | None = None,
    decision_summary: str | None = None,
    decision_type: str = "tool_call",
    top_k: int = 3,
    query_crm: bool = True,
    dynamodb_client: Any | None = None,
    customer_context_store: Any | None = None,
    timeout_s: float | None = None,
    trace_id: str | None = None,
) -> VoiceContext:
    """
    Load voice context (convenience function).

    Args:
        tenant_id: Tenant identifier
        caller_phone: Caller phone number (E.164 format)
        call_sid: Optional live call identifier to stamp into the returned context
        decision_summary: Summary of current situation for precedent search
        decision_type: Type of decision (tool_call, exception_granted, policy_override)
        top_k: Number of precedents to retrieve
        query_crm: Whether to query CRM (default: True)
        dynamodb_client: Optional DynamoDB client for testing
        timeout_s: Optional preload budget in seconds; returns degraded context on timeout
        trace_id: Optional trace identifier to carry into the returned context

    Returns:
        VoiceContext with complete context for voice interaction
    """
    loader = get_context_loader(
        tenant_id=tenant_id,
        dynamodb_client=dynamodb_client,
        customer_context_store=customer_context_store,
    )
    start = datetime.now(UTC).replace(tzinfo=None)
    kwargs = {
        "caller_phone": caller_phone,
        "decision_summary": decision_summary,
        "decision_type": decision_type,
        "top_k": top_k,
        "query_crm": query_crm,
    }

    try:
        if timeout_s is not None and timeout_s > 0:
            ctx = await asyncio.wait_for(loader.load_context(**kwargs), timeout=timeout_s)
        else:
            ctx = await loader.load_context(**kwargs)
        ctx.call_sid = call_sid or trace_id or ctx.call_sid
        ctx.preload_status = "complete"
        ctx.preload_reason = ""
        ctx.preload_trace_id = trace_id or ctx.preload_trace_id or ""
        ctx.preload_budget_ms = int(timeout_s * 1000) if timeout_s is not None else 0
        return ctx
    except asyncio.TimeoutError:
        elapsed_ms = int((datetime.now(UTC).replace(tzinfo=None) - start).total_seconds() * 1000)
        logger.warning(
            "Voice context preload timed out for tenant %s caller %s after %sms",
            tenant_id,
            caller_phone,
            elapsed_ms,
        )
        return VoiceContext(
            tenant_id=loader.tenant_id,
            caller_phone=caller_phone,
            call_sid=call_sid or trace_id or None,
            loaded_at=datetime.now(UTC).replace(tzinfo=None),
            load_time_ms=elapsed_ms,
            preload_status="degraded",
            preload_reason="timeout",
            preload_trace_id=trace_id or "",
            preload_budget_ms=int(timeout_s * 1000) if timeout_s is not None else 0,
        )
    except Exception as exc:
        elapsed_ms = int((datetime.now(UTC).replace(tzinfo=None) - start).total_seconds() * 1000)
        logger.warning(
            "Voice context preload failed for tenant %s caller %s: %s",
            tenant_id,
            caller_phone,
            exc,
        )
        return VoiceContext(
            tenant_id=loader.tenant_id,
            caller_phone=caller_phone,
            call_sid=call_sid or trace_id or None,
            loaded_at=datetime.now(UTC).replace(tzinfo=None),
            load_time_ms=elapsed_ms,
            preload_status="degraded",
            preload_reason=str(exc)[:200],
            preload_trace_id=trace_id or "",
            preload_budget_ms=int(timeout_s * 1000) if timeout_s is not None else 0,
        )
