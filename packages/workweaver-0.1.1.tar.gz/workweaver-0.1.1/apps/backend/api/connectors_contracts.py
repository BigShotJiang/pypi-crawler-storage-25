"""Pydantic contracts for the connectors API."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import AliasChoices, BaseModel, Field

from apps.backend.models.connector_state import ConnectorState


class ConnectorSummary(BaseModel):
    """Concise connector metadata for list responses."""

    id: str
    name: str
    description: str
    category: str
    auth_type: str
    icon_url: str = ""
    documentation_url: str = ""
    is_builtin: bool = False
    coming_soon: bool = False
    operation_count: int = 0


class ConnectorListResponse(BaseModel):
    """Paginated list of connectors."""

    items: list[ConnectorSummary]
    total: int
    page: int
    page_size: int
    pages: int


class ConnectorDetailResponse(BaseModel):
    """Full connector details including auth fields and operations."""

    id: str
    name: str
    description: str
    version: str
    author: str
    category: str
    auth_type: str
    icon_url: str = ""
    documentation_url: str = ""
    is_builtin: bool = False
    coming_soon: bool = False
    supported_operations: list[str]
    auth_fields: list[dict[str, Any]]
    operations: list[dict[str, Any]]


class CategoryCount(BaseModel):
    """Category with connector counts."""

    category: str
    total: int
    available: int


class InstallRequest(BaseModel):
    """Credentials to install a connector for a tenant."""

    credentials: dict[str, Any] = Field(..., description="Auth credentials required by the connector")
    agent_id: str = Field(default="shared", description="Credential owner identity for this installation")


class InstallResponse(BaseModel):
    """Result of a connector installation."""

    install_id: str
    tenant_id: str
    connector_id: str
    installed_at: str
    updated_at: str
    state: str = "verified"
    credential_owner: str = "shared"
    evidence_event_id: str | None = None
    evidence_url: str | None = None


class InstalledConnector(BaseModel):
    """An installed connector with combined metadata and install info."""

    id: str
    name: str
    install_id: str = ""
    installed_at: str = ""
    updated_at: str = ""
    description: str = ""
    category: str = ""
    auth_type: str = ""
    icon_url: str = ""
    documentation_url: str = ""
    is_builtin: bool = False
    coming_soon: bool = False
    operation_count: int = 0


class ExecuteRequest(BaseModel):
    """Request to execute a connector operation."""

    operation_id: str = Field(
        ...,
        validation_alias=AliasChoices("operation_id", "operation"),
        description="Operation to invoke (e.g. 'search', 'create_contact')",
    )
    params: dict[str, Any] = Field(default_factory=dict, description="Operation input parameters")
    dry_run: bool = Field(default=False, description="Return a side-effect preview without provider execution")
    idempotency_key: str | None = Field(default=None, description="Stable caller key reused from preview to live send")


class ExecuteResponse(BaseModel):
    """Result of a connector operation execution."""

    connector_id: str
    operation_id: str
    success: bool
    result: dict[str, Any] = Field(default_factory=dict)
    dry_run: bool = False
    idempotency_key: str | None = None
    error: str | None = None
    evidence_event_id: str | None = None
    evidence_url: str | None = None
    dry_run: bool = False
    idempotency_key: str | None = None


class HealthResponse(BaseModel):
    """Health check result for a connector.

    Issue #2747 added optional structured remediation hints so the UI
    connector status badge can route a non-live circuit to the right CTA
    without parsing free-text error strings:
    - circuit_state ('closed' | 'half_open' | 'open')
    - last_failure_message (rendered in the tooltip)
    - last_failure_category (e.g. 'auth_expired')
    - needs_reauth (when true, surface the re-auth CTA)
    Defaults preserve backwards compatibility with callers that haven't
    populated these yet.
    """

    connector_id: str
    provider: str
    state: str
    message: str = ""
    latency_ms: float = 0.0
    last_checked_at: str | None = None
    alert_open: bool = False
    evidence_event_id: str | None = None
    evidence_url: str | None = None
    circuit_state: str | None = Field(
        default=None,
        description="closed | half_open | open (issue #2747)",
    )
    last_failure_message: str | None = Field(
        default=None,
        description="Human-readable last failure (rendered into UI tooltip)",
    )
    last_failure_category: str | None = Field(
        default=None,
        description="Short failure category tag, e.g. 'auth_expired'",
    )
    needs_reauth: bool = Field(
        default=False,
        description="When true, the UI surfaces a re-auth CTA",
    )


class ConnectorHealthListResponse(BaseModel):
    """Aggregate health view for installed connectors."""

    items: list[HealthResponse]
    count: int


class ConnectorAvailabilityItem(BaseModel):
    """Availability status for one connector-backed capability surface."""

    connector_id: str
    display_name: str
    capability_ids: list[str] = Field(default_factory=list)
    tool_names: list[str] = Field(default_factory=list)
    status: Literal["functional", "degraded", "unavailable"]
    reason: str
    setup_command: str
    profile_support: dict[str, bool] = Field(default_factory=dict)
    last_checked_at: str | None = None
    evidence_event_id: str | None = None
    evidence_url: str | None = None


class ConnectorAvailabilitySummary(BaseModel):
    """Counts by availability state."""

    total: int
    functional: int
    degraded: int
    unavailable: int


class ConnectorAvailabilityResponse(BaseModel):
    """Full connector availability map for self-host and managed runtimes."""

    items: list[ConnectorAvailabilityItem]
    summary: ConnectorAvailabilitySummary
    profile: str
    generated_at: str
    decision_trace_id: str | None = None


class ConnectionCenterItem(BaseModel):
    """User-facing connector card for the canonical connection center."""

    key: str
    display_name: str
    description: str
    category: str
    auth_type: str
    state: str
    canonical_state: ConnectorState = ConnectorState.ADVANCED_SETUP
    state_reason: str = ""
    icon_url: str = ""
    documentation_url: str = ""
    connector_id: str | None = None
    connection_id: str | None = None
    integration_name: str | None = None
    verified_path: bool = False
    surfaced: bool = False
    surface_rank: int = 999
    demand_based: bool = False
    coming_soon: bool = False
    connected: bool = False
    health_state: str | None = None
    needs_reauth: bool = False
    primary_action: str
    action_label: str
    secondary_action: str | None = None
    supported_operations: list[str] = Field(default_factory=list)


class ConnectionCenterResponse(BaseModel):
    """Canonical connector-center response for runtime and onboarding."""

    surfaced: list[ConnectionCenterItem]
    all_connectors: list[ConnectionCenterItem]
    total_supported: int
    total_verified: int


class ConnectorConnectSessionRequest(BaseModel):
    """Request body for starting a hosted connector auth session."""

    agent_id: str = Field(default="shared", description="Credential owner identity for this connection")
    display_name: str | None = Field(default=None, description="Optional end-user display name for the auth screen")
    email: str | None = Field(default=None, description="Optional end-user email for the auth screen")


class ConnectorConnectSessionResponse(BaseModel):
    """Hosted connector auth session response."""

    provider_id: str
    connection_id: str
    hosted_url: str
    expires_at: str | None = None
    session_token: str | None = None


class StandardConnectorRegisterRequest(BaseModel):
    """Advanced standards-based connector definition."""

    connector_id: str | None = None
    name: str
    description: str = ""
    category: str = "operations"
    documentation_url: str = ""
    transport: dict[str, Any] = Field(default_factory=dict)
    auth: dict[str, Any] = Field(default_factory=dict)
    operations: list[dict[str, Any]] = Field(default_factory=list)


class StandardConnectorDefinitionResponse(BaseModel):
    """Summary for a tenant-scoped standards connector."""

    connector_id: str
    name: str
    description: str = ""
    category: str = ""
    transport_kind: str = ""
    auth_type: str = ""
    operation_count: int = 0
    verification: dict[str, Any] = Field(default_factory=dict)
    created_at: str | None = None
    updated_at: str | None = None


class OpenAPIImportRequest(BaseModel):
    """Import request for an OpenAPI/Swagger connector."""

    spec_url: str
    base_url: str | None = None
    name: str | None = None
    description: str = ""
    auth: dict[str, Any] = Field(default_factory=dict)


class OpenAPIImportResponse(BaseModel):
    """OpenAPI import result with operation capability rows."""

    tenant_id: str
    connector_id: str
    name: str
    operation_count: int
    operations: list[dict[str, Any]]
    capability_rows: list[dict[str, Any]]
    evidence_event_id: str | None = None
    evidence_url: str | None = None


class ZohoAuthStartRequest(BaseModel):
    product_slug: str
    scope: str = "tenant"
    agent_id: str = "shared"
    dc: str | None = None
    scopes: list[str] = Field(default_factory=list)
    redirect_uri: str | None = None
    org_id: str | None = None
    portal_id: str | None = None
    instance_id: str | None = None


class ZohoAuthStartResponse(BaseModel):
    authorization_url: str
    state: str
    requested_scopes: list[str] = Field(default_factory=list)
    connection: "ZohoConnectionResponse"


class ZohoConnectionResponse(BaseModel):
    connection_id: str
    tenant_id: str
    display_name: str
    product_slug: str
    scope: str
    agent_id: str
    dc: str
    accounts_base_url: str
    api_base_url: str
    state: str
    granted_scopes: list[str] = Field(default_factory=list)
    requested_scopes: list[str] = Field(default_factory=list)
    credential_owner: str
    org_id: str | None = None
    portal_id: str | None = None
    instance_id: str | None = None
    last_error: str | None = None
    health_metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str
    updated_at: str


class ZohoAuthCompleteRequest(BaseModel):
    connection_id: str
    code: str
    state: str
    org_id: str | None = None
    portal_id: str | None = None
    instance_id: str | None = None


class ZohoAuthCallbackResponse(BaseModel):
    success: bool
    connection: ZohoConnectionResponse


class CatalogAvailableItem(BaseModel):
    """A connector available for installation (custom + dynamically discovered)."""

    id: str
    name: str
    description: str
    category: str
    auth_type: str
    source: str = "platform"
    installed: bool = False
    available: bool = True
    icon_url: str = ""
    documentation_url: str = ""
    is_builtin: bool = False
    coming_soon: bool = False
    operation_count: int = 0


class CatalogAvailableResponse(BaseModel):
    """Full catalog of all available connectors."""

    items: list[CatalogAvailableItem]
    total: int
    custom_count: int
    discovered_count: int
