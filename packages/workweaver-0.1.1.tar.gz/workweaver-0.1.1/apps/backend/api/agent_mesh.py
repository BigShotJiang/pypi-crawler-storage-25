"""A2A v1.0 Agent Mesh -- JSON-RPC 2.0 over HTTP + SSE.

Prefix: /api/v1/agent-mesh

This module exposes Workweaver as a first-class A2A (Agent-to-Agent) v1.0
participant that external agents can discover, call into, and stream from.
It also provides a bidirectional *composability* hook: any Workweaver
tenant can call OUT to a remote A2A endpoint through this same surface.

Endpoints:

- GET  /.well-known/agent.json  -- signed Agent Card (RFC 8785 JCS-style
  canonicalization of the payload before signing).
- POST /jsonrpc                 -- dispatch a JSON-RPC 2.0 request to the
  local agent mesh (ping, agent.list, agent.query, session.exchange, ...).
- GET  /stream                  -- Server-Sent Events stream for
  bidirectional A2A communication (heartbeat + message channel).
- POST /external                -- proxy a call OUT to an external A2A
  endpoint, so Workweaver agents can compose remote agents as peers.

Design principles:

1. Zero external-party data escape. The JSON-RPC surface only exposes
   the scoped-communication API from `agent_protocol` -- not raw org
   data. External calls must go through a CommunicationScope.
2. Target allow-listing on the proxy. /external validates the remote
   URL against an explicit allow-list (default: empty, admin-provided).
3. Deterministic error codes. JSON-RPC error codes follow the spec:
   -32700 parse error, -32600 invalid request, -32601 method not
   found, -32602 invalid params, -32603 internal error.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.plugin_auth import get_plugin_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/agent-mesh", tags=["agent-mesh"])


# ---------------------------------------------------------------------------
# Agent Card (RFC 8785-style canonicalization + HMAC signature)
# ---------------------------------------------------------------------------

AGENT_CARD_VERSION = "1.0.0"
AGENT_CARD_ID = "workweaver.ai"
AGENT_CARD_NAME = "Workweaver Mission OS"
AGENT_CARD_DESCRIPTION = (
    "Workweaver is a Mission OS that orchestrates scoped agents, "
    "evidence, and org knowledge behind an A2A v1.0 interface."
)
AGENT_CARD_CAPABILITIES: list[str] = [
    "agent.ping",
    "agent.list",
    "agent.query",
    "scope.create",
    "session.start",
    "session.exchange",
    "session.complete",
    "stream.sse",
    "external.proxy",
]
AGENT_CARD_PROTOCOLS: list[str] = [
    "a2a/1.0",
    "jsonrpc/2.0",
    "sse/1.0",
    "acp/1.0",
]


def _canonical_json(value: Any) -> bytes:
    """Return RFC 8785-style canonical JSON bytes.

    JCS (RFC 8785) requires sorted object keys, no insignificant
    whitespace, and a stable UTF-8 serialization. json.dumps with
    sort_keys=True and the tightest separators is a close-enough
    canonicalization for signing our own agent card.
    """
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def _signing_secret() -> str:
    """Return the HMAC signing secret for the agent card.

    Prefers AGENT_MESH_SIGNING_SECRET env var.  In production-like
    environments (prod, staging) the env var MUST be set -- startup
    fails fast if it is missing.  In dev/test a stable fallback is
    used so that a fresh clone of the repo still produces a valid
    signed card and tests remain deterministic.
    """
    secret = os.environ.get("AGENT_MESH_SIGNING_SECRET")
    if secret:
        return secret

    # Production-like environments MUST set the env var.
    try:
        from apps.backend.config.environment import is_production_like

        if is_production_like():
            raise RuntimeError(
                "AGENT_MESH_SIGNING_SECRET is not set. "
                "This environment variable is required in production "
                "(set it in ECS task definition or SSM parameter store)."
            )
    except ImportError:
        pass  # environment module not available -- use fallback

    return "workweaver-agent-mesh-dev-secret"


def _sign_agent_card(payload: dict[str, Any]) -> str:
    import hmac

    canonical = _canonical_json(payload)
    digest = hmac.new(
        _signing_secret().encode("utf-8"),
        canonical,
        hashlib.sha256,
    ).hexdigest()
    return digest


def build_agent_card() -> dict[str, Any]:
    """Build the signed Agent Card payload."""
    payload: dict[str, Any] = {
        "id": AGENT_CARD_ID,
        "name": AGENT_CARD_NAME,
        "version": AGENT_CARD_VERSION,
        "description": AGENT_CARD_DESCRIPTION,
        "capabilities": AGENT_CARD_CAPABILITIES,
        "protocols": AGENT_CARD_PROTOCOLS,
        "endpoints": {
            "jsonrpc": "/api/v1/agent-mesh/jsonrpc",
            "stream": "/api/v1/agent-mesh/stream",
            "external": "/api/v1/agent-mesh/external",
        },
    }
    signature = _sign_agent_card(payload)
    return {
        "card": payload,
        "signature": {
            "algorithm": "HS256",
            "canonicalization": "RFC8785",
            "value": signature,
        },
    }


@router.get(
    "/.well-known/agent.json",
    summary="Return the signed A2A v1.0 Agent Card",
)
async def get_agent_card() -> dict[str, Any]:
    """Return a signed Agent Card per RFC 8785 canonicalization."""
    return build_agent_card()


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 dispatcher
# ---------------------------------------------------------------------------

JSONRPC_PARSE_ERROR = -32700
JSONRPC_INVALID_REQUEST = -32600
JSONRPC_METHOD_NOT_FOUND = -32601
JSONRPC_INVALID_PARAMS = -32602
JSONRPC_INTERNAL_ERROR = -32603


def _jsonrpc_error(
    code: int,
    message: str,
    *,
    request_id: Any = None,
    data: Any = None,
) -> dict[str, Any]:
    err: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "error": err, "id": request_id}


def _jsonrpc_ok(result: Any, *, request_id: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "result": result, "id": request_id}


async def _dispatch_jsonrpc_method(
    method: str,
    params: dict[str, Any] | list[Any] | None,
    tenant_id: str,
) -> Any:
    """Dispatch a JSON-RPC method to the underlying service layer.

    Raises:
        ValueError: on invalid params (caller translates to -32602).
        LookupError: on unknown method (caller translates to -32601).
    """
    params = params or {}
    if isinstance(params, list):
        # Positional params are not supported for our named-arg surface.
        raise ValueError("positional params are not supported")

    if method in {"ping", "agent.ping"}:
        return "pong"

    if method in {"agent.list", "capabilities.list"}:
        return {
            "capabilities": AGENT_CARD_CAPABILITIES,
            "protocols": AGENT_CARD_PROTOCOLS,
        }

    if method == "agent.query":
        from apps.backend.services.agent_protocol import (
            get_agent_protocol_service,
        )

        question = params.get("question")
        if not isinstance(question, str) or not question.strip():
            raise ValueError("params.question must be a non-empty string")
        agent_id = params.get("agent_id", "zara")
        caller_id = params.get("caller_id", "external-a2a")
        service = get_agent_protocol_service()
        response = await service.query_agent(
            tenant_id=tenant_id,
            agent_id=agent_id,
            question=question,
            caller_id=caller_id,
        )
        return asdict(response)

    if method == "scope.create":
        from apps.backend.services.agent_protocol import (
            get_agent_protocol_service,
        )

        agent_id = params.get("agent_id")
        allowed_topics = params.get("allowed_topics")
        if not isinstance(agent_id, str) or not agent_id:
            raise ValueError("params.agent_id is required")
        if not isinstance(allowed_topics, list) or not allowed_topics:
            raise ValueError("params.allowed_topics must be a non-empty list")
        service = get_agent_protocol_service()
        scope = service.create_communication_scope(
            tenant_id=tenant_id,
            agent_id=agent_id,
            allowed_topics=allowed_topics,
            allowed_data_sources=params.get("allowed_data_sources"),
            allowed_tools=params.get("allowed_tools"),
            blocked_topics=params.get("blocked_topics"),
            context_documents=params.get("context_documents"),
            max_iterations=int(params.get("max_iterations", 50)),
            expires_at=params.get("expires_at"),
            created_by=params.get("created_by", "a2a"),
        )
        return asdict(scope)

    if method == "session.start":
        from apps.backend.services.agent_protocol import (
            get_agent_protocol_service,
        )

        scope_id = params.get("scope_id")
        external_party_id = params.get("external_party_id")
        if not isinstance(scope_id, str) or not scope_id:
            raise ValueError("params.scope_id is required")
        if not isinstance(external_party_id, str) or not external_party_id:
            raise ValueError("params.external_party_id is required")
        service = get_agent_protocol_service()
        session = service.start_session(
            scope_id=scope_id,
            external_party_id=external_party_id,
        )
        return {
            "session_id": session.session_id,
            "scope_id": session.scope.scope_id,
            "state": session.state,
            "external_party_id": session.external_party_id,
            "iterations": session.iterations,
            "calendar_block_id": session.calendar_block_id,
        }

    if method == "session.exchange":
        from apps.backend.services.agent_protocol import (
            get_agent_protocol_service,
        )

        session_id = params.get("session_id")
        message = params.get("message")
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("params.session_id is required")
        if not isinstance(message, str) or not message.strip():
            raise ValueError("params.message must be a non-empty string")
        service = get_agent_protocol_service()
        response = await service.exchange(
            session_id=session_id,
            message=message,
            sender=params.get("sender", "external-a2a"),
        )
        return asdict(response)

    if method == "session.complete":
        from apps.backend.services.agent_protocol import (
            get_agent_protocol_service,
        )

        session_id = params.get("session_id")
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("params.session_id is required")
        service = get_agent_protocol_service()
        return service.complete_session(session_id)

    raise LookupError(method)


@router.post(
    "/jsonrpc",
    summary="Handle JSON-RPC 2.0 method calls from external A2A agents",
)
async def handle_jsonrpc(
    request: Request,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> JSONResponse:
    """Handle a single JSON-RPC 2.0 request.

    Per the JSON-RPC 2.0 spec:
    - Requests without an "id" field are notifications and must NOT
      receive a response body. We return 204 No Content in that case.
    - Parse errors return -32700 with id=null.
    - Unknown methods return -32601.
    - Invalid params return -32602.
    - Any other exception returns -32603 (internal error).
    """
    raw_body = await request.body()
    try:
        payload = json.loads(raw_body.decode("utf-8")) if raw_body else None
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        logger.debug("jsonrpc.parse_error: %s", exc)
        return JSONResponse(
            _jsonrpc_error(JSONRPC_PARSE_ERROR, "Parse error"),
            status_code=200,
        )

    if not isinstance(payload, dict):
        return JSONResponse(
            _jsonrpc_error(JSONRPC_INVALID_REQUEST, "Invalid request"),
            status_code=200,
        )

    if payload.get("jsonrpc") != "2.0":
        return JSONResponse(
            _jsonrpc_error(
                JSONRPC_INVALID_REQUEST,
                "Invalid request: jsonrpc must be '2.0'",
                request_id=payload.get("id"),
            ),
            status_code=200,
        )

    method = payload.get("method")
    if not isinstance(method, str) or not method:
        return JSONResponse(
            _jsonrpc_error(
                JSONRPC_INVALID_REQUEST,
                "Invalid request: method is required",
                request_id=payload.get("id"),
            ),
            status_code=200,
        )

    request_id = payload.get("id", ...)
    is_notification = request_id is ...
    if is_notification:
        request_id = None

    try:
        result = await _dispatch_jsonrpc_method(
            method, payload.get("params"), tenant_id,
        )
    except LookupError:
        if is_notification:
            return JSONResponse(status_code=204, content=None)
        return JSONResponse(
            _jsonrpc_error(
                JSONRPC_METHOD_NOT_FOUND,
                f"Method not found: {method}",
                request_id=request_id,
            ),
            status_code=200,
        )
    except ValueError as exc:
        if is_notification:
            return JSONResponse(status_code=204, content=None)
        return JSONResponse(
            _jsonrpc_error(
                JSONRPC_INVALID_PARAMS,
                f"Invalid params: {exc}",
                request_id=request_id,
            ),
            status_code=200,
        )
    except Exception as exc:  # noqa: BLE001 - JSON-RPC must return generic internal error
        logger.exception("jsonrpc.internal_error method=%s", method)
        if is_notification:
            return JSONResponse(status_code=204, content=None)
        return JSONResponse(
            _jsonrpc_error(
                JSONRPC_INTERNAL_ERROR,
                "Internal error",
                request_id=request_id,
                data=str(exc),
            ),
            status_code=200,
        )

    if is_notification:
        return JSONResponse(status_code=204, content=None)
    return JSONResponse(_jsonrpc_ok(result, request_id=request_id))


# ---------------------------------------------------------------------------
# SSE bidirectional channel
# ---------------------------------------------------------------------------


async def _sse_event_stream(tenant_id: str, request: Request):
    """Yield SSE frames for the mesh stream endpoint.

    Emits a bootstrap event and then a keepalive heartbeat every 15s
    until the client disconnects. The channel is intended for
    bidirectional A2A notifications; the POST /jsonrpc endpoint is the
    write side of the same conversation.
    """
    bootstrap = {
        "type": "bootstrap",
        "tenant_id": tenant_id,
        "agent_card": build_agent_card()["card"],
    }
    yield f"event: bootstrap\ndata: {json.dumps(bootstrap)}\n\n"
    try:
        while True:
            if await request.is_disconnected():
                break
            heartbeat = {"type": "heartbeat"}
            yield f"event: heartbeat\ndata: {json.dumps(heartbeat)}\n\n"
            await asyncio.sleep(15)
    except asyncio.CancelledError:  # pragma: no cover - client disconnect
        raise


@router.get(
    "/stream",
    summary="Server-Sent Events stream for bidirectional A2A communication",
)
async def sse_stream(
    request: Request,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> StreamingResponse:
    """Open an SSE stream tied to the caller's tenant."""
    return StreamingResponse(
        _sse_event_stream(tenant_id, request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# External proxy (bidirectional composability)
# ---------------------------------------------------------------------------


class ExternalAgentRequest(BaseModel):
    """Request body for /external proxy."""

    target_url: str = Field(
        ...,
        description="Remote A2A agent URL (https://... /jsonrpc)",
        min_length=1,
        max_length=2048,
    )
    method: str = Field(..., min_length=1, max_length=200)
    params: dict[str, Any] | None = Field(default=None)
    request_id: str | int | None = Field(default=None)
    timeout_seconds: float = Field(default=30.0, ge=1.0, le=300.0)


_ALLOWED_URL_RE = re.compile(r"^https://[^\s/]+(?::\d+)?(?:/[^\s]*)?$")


def _external_allowlist() -> list[str]:
    """Return the admin-configured external A2A allow-list.

    Configured via AGENT_MESH_EXTERNAL_ALLOWLIST env var as a
    comma-separated list of allowed origins (scheme://host[:port]).
    Empty allow-list means NO external proxies are permitted.
    """
    raw = os.environ.get("AGENT_MESH_EXTERNAL_ALLOWLIST", "").strip()
    if not raw:
        return []
    return [item.strip().rstrip("/") for item in raw.split(",") if item.strip()]


def _url_origin(url: str) -> str:
    """Return the normalised scheme+host[:port] origin for *url*.

    Uses ``urllib.parse.urlparse`` to avoid substring-matching tricks such as
    ``https://allowed.example.com.evil.com`` bypassing an allowlist entry of
    ``https://allowed.example.com``.
    """
    from urllib.parse import urlparse  # noqa: PLC0415 — stdlib, local import for clarity

    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")


def _validate_target_url(target_url: str) -> None:
    """Validate the target URL against scheme, format, SSRF, and allow-list.

    Raises ValueError if rejected.

    Security layers (applied in order):

    1. URL format validation (HTTPS-only, no whitespace).
    2. SSRF protection -- rejects private/reserved IPs and cloud metadata
       endpoints (see ``apps.backend.utils.ssrf.validate_url_ssrf``).
    3. Allow-list matching on the *parsed* origin (scheme + host + port)
       so that crafted URLs like ``https://allowed.example.com.evil.com``
       cannot bypass the check.
    """
    if not _ALLOWED_URL_RE.match(target_url):
        raise ValueError("target_url must be a valid https:// URL")

    from apps.backend.utils.ssrf import validate_url_ssrf

    validate_url_ssrf(target_url, field_name="target_url")

    allowlist = _external_allowlist()
    if not allowlist:
        raise ValueError(
            "external A2A calls are disabled: allow-list is empty "
            "(set AGENT_MESH_EXTERNAL_ALLOWLIST)",
        )

    origin = _url_origin(target_url)
    if origin not in allowlist:
        raise ValueError("target_url is not in the configured allow-list")


@router.post(
    "/external",
    summary="Proxy a call to an external A2A endpoint (bidirectional composability)",
)
async def call_external_agent(
    body: ExternalAgentRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> JSONResponse:
    """Proxy a JSON-RPC 2.0 call OUT to a remote A2A endpoint."""
    try:
        _validate_target_url(body.target_url)
    except ValueError as exc:
        return JSONResponse(
            {"error": str(exc), "target_url": body.target_url},
            status_code=400,
        )

    import httpx

    rpc_payload: dict[str, Any] = {
        "jsonrpc": "2.0",
        "method": body.method,
        "params": body.params or {},
    }
    if body.request_id is not None:
        rpc_payload["id"] = body.request_id
    else:
        rpc_payload["id"] = f"ww-mesh-{tenant_id}"

    try:
        async with httpx.AsyncClient(timeout=body.timeout_seconds) as client:
            resp = await client.post(
                body.target_url,
                json=rpc_payload,
                headers={"Content-Type": "application/json"},
            )
    except httpx.HTTPError as exc:
        logger.warning(
            "external_agent.http_error tenant=%s target=%s err=%s",
            tenant_id, body.target_url, exc,
        )
        return JSONResponse(
            {"error": f"upstream transport failure: {exc}"},
            status_code=502,
        )

    try:
        remote_payload = resp.json()
    except ValueError:
        remote_payload = {"raw": resp.text}

    return JSONResponse(
        {
            "status_code": resp.status_code,
            "payload": remote_payload,
        },
        status_code=200,
    )
