"""Lead Magnet API endpoints.

Intelligence-first lead capture with behavioral enrichment.
Captures anonymous visitor tracking and syncs to Zoho CRM.

Zero cash burn model:
- No paid enrichment services
- Open source fingerprinting
- Direct Zoho CRM API integration
"""

import asyncio
import logging
import os
from apps.backend.config.region import AWS_REGION
import threading
from datetime import datetime, UTC
from typing import Any
from urllib.parse import quote

import boto3
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from botocore.exceptions import ClientError

# Repo structure: import via apps.backend.* (works when repo root is on sys.path)
from apps.backend.models.lead import (
    LeadEnrichment,
    LeadMagnetSubmission,
    LeadQuality,
    LeadSource,
    LM2Submission,
)
from apps.backend.services.lead_magnet_scoring import (
    calculate_lm1_score,
    calculate_lm2_results,
)

logger = logging.getLogger(__name__)

# Zoho CRM integration defaults to enabled; individual sync attempts degrade
# gracefully when the public-tenant canonical Zoho connection is absent.
_ZOHO_ENABLED = (os.getenv("ZOHO_SYNC_DISABLED") or "").strip().lower() not in {"1", "true", "yes"}

# PDF report generation (optional - enabled if S3 bucket configured)
_PDF_ENABLED = bool(os.getenv("REPORTS_BUCKET"))

# Email sending (enabled by default using the verified Workweaver sender identity).
#
# Keep this in sync with `apps.backend.services.lead_magnet_email_service.FROM_EMAIL`,
# which defaults to workweaver@bitfoundry.ai when LEAD_MAGNET_FROM_EMAIL is not set.
_EMAIL_ENABLED = bool((os.getenv("LEAD_MAGNET_FROM_EMAIL") or "workweaver@bitfoundry.ai").strip())


def _zoho_public_tenant_id() -> str:
    return (os.getenv("CONTENT_PIPELINE_DEFAULT_TENANT_ID") or "TENANT#public").strip() or "TENANT#public"


# Waitlist counter state (best-effort persistent via DynamoDB with local fallback).
#
# NOTE: Do NOT use `DYNAMODB_TABLE_NAME` here. That env var is reserved for the
# documents subsystem and would silently route waitlist writes to the wrong table.
_WAITLIST_BASE_POSITION = int(os.getenv("WAITLIST_BASE_POSITION", "1284"))
_WAITLIST_TABLE_NAME = os.getenv("WAITLIST_TABLE_NAME", "").strip()
_WAITLIST_COUNTER_PK = os.getenv("WAITLIST_COUNTER_PK", "SYSTEM#WAITLIST")
_WAITLIST_COUNTER_SK = os.getenv("WAITLIST_COUNTER_SK", "COUNTER#GLOBAL")
_WAITLIST_LOCK = threading.Lock()
_WAITLIST_COUNTER = _WAITLIST_BASE_POSITION
_WAITLIST_CACHE: dict[str, int] = {}
_WAITLIST_TABLE = None


def _get_waitlist_table():
    global _WAITLIST_TABLE
    if _WAITLIST_TABLE is not None:
        return _WAITLIST_TABLE
    if not _WAITLIST_TABLE_NAME:
        return None
    region = AWS_REGION
    _WAITLIST_TABLE = boto3.resource("dynamodb", region_name=region).Table(_WAITLIST_TABLE_NAME)
    return _WAITLIST_TABLE


def _assign_waitlist_position(email: str) -> tuple[int, bool]:
    global _WAITLIST_COUNTER

    normalized_email = email.strip().lower()
    if not normalized_email:
        raise ValueError("email is required for waitlist position")

    with _WAITLIST_LOCK:
        cached = _WAITLIST_CACHE.get(normalized_email)
        if cached is not None:
            return cached, False

    table = None
    try:
        table = _get_waitlist_table()
    except Exception as e:
        logger.warning("Waitlist table unavailable, using local fallback: %s", e)

    if table is not None:
        lead_key = {"pk": f"WAITLIST#{normalized_email}", "sk": "PROFILE"}
        now = datetime.now(UTC).isoformat()
        try:
            table.put_item(
                Item={
                    **lead_key,
                    "email": normalized_email,
                    "created_at": now,
                    "updated_at": now,
                },
                ConditionExpression="attribute_not_exists(pk) AND attribute_not_exists(sk)",
            )
            counter = table.update_item(
                Key={"pk": _WAITLIST_COUNTER_PK, "sk": _WAITLIST_COUNTER_SK},
                UpdateExpression="SET waitlist_count = if_not_exists(waitlist_count, :base) + :inc, updated_at = :now",
                ExpressionAttributeValues={
                    ":base": _WAITLIST_BASE_POSITION,
                    ":inc": 1,
                    ":now": now,
                },
                ReturnValues="UPDATED_NEW",
            )
            attrs = counter.get("Attributes", {}) if isinstance(counter, dict) else {}
            position = int(attrs.get("waitlist_count", _WAITLIST_BASE_POSITION + 1))

            table.update_item(
                Key=lead_key,
                UpdateExpression="SET waitlist_position = :position, updated_at = :now",
                ExpressionAttributeValues={":position": position, ":now": now},
            )

            with _WAITLIST_LOCK:
                _WAITLIST_CACHE[normalized_email] = position
                _WAITLIST_COUNTER = max(_WAITLIST_COUNTER, position)
            return position, True
        except ClientError as e:
            code = (e.response or {}).get("Error", {}).get("Code", "")
            if code == "ConditionalCheckFailedException":
                try:
                    existing = table.get_item(Key=lead_key).get("Item", {})
                    existing_position = int(existing.get("waitlist_position", 0))
                    if existing_position > 0:
                        with _WAITLIST_LOCK:
                            _WAITLIST_CACHE[normalized_email] = existing_position
                            _WAITLIST_COUNTER = max(_WAITLIST_COUNTER, existing_position)
                        return existing_position, False
                    # Repair: record exists but waitlist_position was never set (partial write).
                    # Allocate a fresh position and write it conditionally.
                    counter = table.update_item(
                        Key={"pk": _WAITLIST_COUNTER_PK, "sk": _WAITLIST_COUNTER_SK},
                        UpdateExpression="SET waitlist_count = if_not_exists(waitlist_count, :base) + :inc, updated_at = :now",
                        ExpressionAttributeValues={
                            ":base": _WAITLIST_BASE_POSITION,
                            ":inc": 1,
                            ":now": now,
                        },
                        ReturnValues="UPDATED_NEW",
                    )
                    attrs = counter.get("Attributes", {}) if isinstance(counter, dict) else {}
                    position = int(attrs.get("waitlist_count", _WAITLIST_BASE_POSITION + 1))
                    try:
                        table.update_item(
                            Key=lead_key,
                            UpdateExpression="SET waitlist_position = :position, updated_at = :now",
                            ConditionExpression="attribute_not_exists(waitlist_position) OR waitlist_position = :zero",
                            ExpressionAttributeValues={
                                ":position": position,
                                ":now": now,
                                ":zero": 0,
                            },
                        )
                        with _WAITLIST_LOCK:
                            _WAITLIST_CACHE[normalized_email] = position
                            _WAITLIST_COUNTER = max(_WAITLIST_COUNTER, position)
                        return position, True
                    except ClientError as set_err:
                        set_code = (set_err.response or {}).get("Error", {}).get("Code", "")
                        if set_code == "ConditionalCheckFailedException":
                            existing = table.get_item(Key=lead_key).get("Item", {})
                            existing_position = int(existing.get("waitlist_position", 0))
                            if existing_position > 0:
                                with _WAITLIST_LOCK:
                                    _WAITLIST_CACHE[normalized_email] = existing_position
                                    _WAITLIST_COUNTER = max(_WAITLIST_COUNTER, existing_position)
                                return existing_position, False
                except Exception as inner:
                    logger.warning("Waitlist existing lookup failed for %s: %s", normalized_email, inner)
            else:
                logger.warning("Waitlist persistence unavailable (%s), using fallback", code)
        except Exception as e:
            logger.warning("Waitlist persistence failed, using fallback: %s", e)

    with _WAITLIST_LOCK:
        existing = _WAITLIST_CACHE.get(normalized_email)
        if existing is not None:
            return existing, False
        _WAITLIST_COUNTER += 1
        _WAITLIST_CACHE[normalized_email] = _WAITLIST_COUNTER
        return _WAITLIST_COUNTER, True


async def _send_report_email(submission: LeadMagnetSubmission, report_url: str, source: LeadSource) -> dict[str, Any]:
    """Send report email via SES (async, non-blocking).

    Args:
        submission: Lead magnet submission
        report_url: Presigned URL for PDF report
        source: Lead source (LM1 or LM2)

    Returns:
        Email send result
    """
    if not _EMAIL_ENABLED:
        logger.debug("Email sending disabled (no FROM email configured)")
        return {"success": False, "skipped": True, "reason": "Not configured"}

    try:
        from services.lead_magnet_email_service import get_lead_magnet_email_service

        email_service = get_lead_magnet_email_service()

        if source == LeadSource.LM1_AI_ELIGIBILITY:
            result = email_service.send_lm1_report_email(submission, report_url)
        elif source == LeadSource.LM2_REVENUE_CALCULATOR:
            result = email_service.send_lm2_report_email(submission, report_url)
        else:
            result = {"success": False, "error": "Unknown source"}

        logger.info(
            "Report email sent: email=%s, source=%s, message_id=%s",
            submission.email,
            source,
            result.get("MessageId"),
        )
        return result

    except Exception as e:
        logger.error("Failed to send report email: %s", e)
        return {"success": False, "error": "Operation failed. Please try again."}


async def _send_waitlist_confirmation_email(
    submission: LeadMagnetSubmission,
    waitlist_position: int,
    zara_try_url: str | None = None,
) -> dict[str, Any]:
    """Send waitlist confirmation email (async, non-blocking)."""
    if not _EMAIL_ENABLED:
        logger.debug("Waitlist email disabled (no FROM email configured)")
        return {"success": False, "skipped": True, "reason": "Not configured"}

    try:
        try:
            from apps.backend.services.lead_magnet_email_service import (
                get_lead_magnet_email_service,
            )
        except ImportError:  # pragma: no cover
            from services.lead_magnet_email_service import get_lead_magnet_email_service

        email_service = get_lead_magnet_email_service()
        result = email_service.send_waitlist_confirmation_email(
            submission=submission,
            waitlist_position=waitlist_position,
            zara_try_url=zara_try_url,
        )
        logger.info(
            "Waitlist confirmation email sent: email=%s, position=%s, message_id=%s",
            submission.email,
            waitlist_position,
            result.get("MessageId"),
        )
        return result
    except Exception as e:
        logger.error("Failed to send waitlist confirmation email: %s", e)
        return {"success": False, "error": "Operation failed. Please try again."}


def _should_create_zoho_follow_up(submission: LeadMagnetSubmission) -> tuple[bool, str]:
    """Determine whether Zoho follow-up task should be created."""
    source_value = submission.source.value if hasattr(submission.source, "value") else str(submission.source)
    if source_value == LeadSource.LM1_AI_ELIGIBILITY.value and submission.lm1_eligible:
        return True, "Qualified LM1 lead (AI readiness >= 70)"
    if source_value == LeadSource.LM2_REVENUE_CALCULATOR.value and submission.lm2_data:
        quality = submission.lm2_data.lead_quality
        if quality in {LeadQuality.HOT, LeadQuality.VERY_HOT}:
            return True, f"High-value LM2 lead ({quality.value})"
    return False, ""


async def _create_zoho_retry_task_for_report_failure(
    submission: LeadMagnetSubmission,
    reason: str,
) -> None:
    """Best-effort Zoho task for report delivery failures."""
    if not _ZOHO_ENABLED:
        return

    try:
        try:
            from apps.backend.services.zoho.crm import get_zoho_crm_service
        except ImportError:  # pragma: no cover
            from apps.backend.services.zoho.crm import get_zoho_crm_service

        zoho_service = await get_zoho_crm_service(
            tenant_id=_zoho_public_tenant_id(),
            cache_ttl_seconds=int(os.getenv("ZOHO_CREDENTIALS_CACHE_TTL", "900")),
        )
        try:
            lead_id = await zoho_service.find_lead_by_email(submission.email)
            if lead_id:
                await zoho_service.create_follow_up_task(
                    lead_id=lead_id,
                    subject="Retry lead magnet report delivery",
                    description=(
                        "Lead report delivery failed and needs retry.\n"
                        f"Email: {submission.email}\n"
                        f"Reason: {reason[:500]}"
                    ),
                    priority="High",
                )
        finally:
            await zoho_service.close()
    except Exception as e:
        logger.warning("Unable to create Zoho retry task for report failure: %s", e)


async def _generate_and_send_report(submission: LeadMagnetSubmission) -> dict[str, Any]:
    """Generate PDF report and send email (async, non-blocking).

    Args:
        submission: Lead magnet submission

    Returns:
        Result with PDF URL and email status
    """
    if not _PDF_ENABLED or not _EMAIL_ENABLED:
        return {
            "success": False,
            "skipped": True,
            "reason": "PDF or email not configured",
        }

    try:
        from services.pdf_report_service import get_pdf_report_service

        # Generate PDF
        pdf_service = get_pdf_report_service()

        if submission.source == LeadSource.LM1_AI_ELIGIBILITY:
            pdf_key = pdf_service.generate_lm1_report(submission)
        elif submission.source == LeadSource.LM2_REVENUE_CALCULATOR:
            pdf_key = pdf_service.generate_lm2_report(submission)
        else:
            return {"success": False, "error": "Unknown source"}

        # Generate presigned URL (7 day expiry)
        report_url = pdf_service.get_report_url(pdf_key, expires_in=604800)

        # Send email
        email_result = await _send_report_email(submission, report_url, submission.source)

        result = {
            "success": True,
            "pdf_key": pdf_key,
            "report_url": report_url,
            "email_sent": email_result.get("MessageId") is not None,
            "email_message_id": email_result.get("MessageId"),
        }
        if not result["email_sent"]:
            await _create_zoho_retry_task_for_report_failure(
                submission=submission,
                reason=str(email_result.get("error") or "SES message id missing"),
            )
        return result

    except Exception as e:
        logger.error("Failed to generate/send report: %s", e)
        await _create_zoho_retry_task_for_report_failure(
            submission=submission,
            reason=str(e),
        )
        return {"success": False, "error": "Operation failed. Please try again."}


async def _sync_to_zoho(submission: LeadMagnetSubmission) -> dict[str, Any]:
    """Sync lead submission to Zoho CRM (async, non-blocking).

    Args:
        submission: Lead magnet submission

    Returns:
        CRM sync result
    """
    if not _ZOHO_ENABLED:
        logger.debug("Zoho CRM sync disabled")
        return {"success": False, "skipped": True, "reason": "Not configured"}

    try:
        try:
            from apps.backend.services.zoho.crm import get_zoho_crm_service
        except ImportError:  # pragma: no cover
            from apps.backend.services.zoho.crm import get_zoho_crm_service

        zoho_service = await get_zoho_crm_service(
            tenant_id=_zoho_public_tenant_id(),
            cache_ttl_seconds=int(os.getenv("ZOHO_CREDENTIALS_CACHE_TTL", "900")),
        )

        # Create lead in Zoho CRM
        result = await zoho_service.create_lead(submission)

        if result.get("success") and result.get("lead_id"):
            should_follow_up, reason = _should_create_zoho_follow_up(submission)
            if should_follow_up:
                try:
                    await zoho_service.create_follow_up_task(
                        lead_id=str(result["lead_id"]),
                        subject="Prioritized lead follow-up",
                        description=(f"{reason}\nLead source: {submission.source}\nEmail: {submission.email}"),
                        priority="High",
                    )
                except Exception as task_error:
                    logger.warning("Zoho follow-up task creation failed: %s", task_error)

        # Clean up HTTP client
        await zoho_service.close()

        return result

    except Exception as e:
        logger.error("Failed to sync to Zoho CRM: %s", e)
        # Weakness #11: Persist failed lead to DLQ so it's not lost.
        try:
            from apps.backend.services.zoho.lead_queue import ZohoLeadQueue

            dlq = ZohoLeadQueue()
            if dlq.is_configured:
                dlq.enqueue(
                    email=submission.email,
                    submission_payload=submission.model_dump(mode="json"),
                    error=str(e),
                )
                logger.info("Failed lead queued to DLQ for retry: %s", submission.email)
                return {"success": False, "queued": True, "reason": str(e)}
        except Exception as dlq_err:
            logger.warning("DLQ enqueue also failed: %s", dlq_err)
        return {"success": False, "error": "Operation failed. Please try again."}


router = APIRouter(prefix="/api/lead-magnets", tags=["lead-magnets"])


async def extract_enrichment_data(request: Request) -> LeadEnrichment:
    """Extract behavioral enrichment data from request headers and body.

    Headers sent by frontend tracking.js:
    - X-Session-ID: Unique session identifier
    - X-Device-Fingerprint: Browser-generated device fingerprint
    - X-UTM-Source, X-UTM-Medium, etc.: Marketing attribution
    """
    headers = request.headers

    # Get enrichment data from body first (sent by frontend)
    body_data = await request.json() if request.method == "POST" else {}

    # Extract session and fingerprint from headers
    session_id = headers.get("X-Session-ID") or body_data.get("enrichment", {}).get("session_id")
    device_fingerprint = headers.get("X-Device-Fingerprint") or body_data.get("enrichment", {}).get(
        "device_fingerprint"
    )

    # Build enrichment from body data (most complete)
    enrichment_data = body_data.get("enrichment", {})

    # Add technical details from request
    client_host = request.client.host if request.client else None

    return LeadEnrichment(
        session_id=session_id or enrichment_data.get("session_id", "unknown"),
        device_fingerprint=device_fingerprint or enrichment_data.get("device_fingerprint", "unknown"),
        # UTM parameters
        utm_source=enrichment_data.get("utm_source"),
        utm_medium=enrichment_data.get("utm_medium"),
        utm_campaign=enrichment_data.get("utm_campaign"),
        utm_term=enrichment_data.get("utm_term"),
        utm_content=enrichment_data.get("utm_content"),
        utm_id=enrichment_data.get("utm_id"),
        # Visit history
        first_visit_timestamp=enrichment_data.get("first_visit"),
        last_visit_timestamp=enrichment_data.get("last_visit"),
        session_count=enrichment_data.get("session_count", 1),
        is_returning_visitor=enrichment_data.get("is_returning_visitor", False),
        # Behavioral metrics
        total_time_on_site=enrichment_data.get("total_time_on_site", 0),
        max_scroll_depth=enrichment_data.get("max_scroll_depth", 0),
        lead_magnets_viewed=enrichment_data.get("lead_magnets_viewed", []),
        # Event tracking
        total_events=enrichment_data.get("total_events", 0),
        events=enrichment_data.get("events", []),
        # Technical details
        ip_address=client_host,
        user_agent=headers.get("User-Agent"),
        referer=headers.get("Referer"),
        accept_language=headers.get("Accept-Language"),
    )


def categorize_lead_quality(monthly_lost_revenue: int) -> LeadQuality:
    """Categorize lead quality based on monthly revenue loss.

    Categories:
    - Cold: <$10,000/month loss (too small, not ICP)
    - Warm: $10,000 - $50,000/month loss (nurture)
    - Hot: $50,000 - $200,000/month loss (priority follow-up)
    - Very Hot: >$200,000/month loss (immediate call)
    """
    if monthly_lost_revenue < 10000:
        return LeadQuality.COLD
    elif monthly_lost_revenue < 50000:
        return LeadQuality.WARM
    elif monthly_lost_revenue < 200000:
        return LeadQuality.HOT
    else:
        return LeadQuality.VERY_HOT


@router.post("/lm2/submit")
async def submit_lm2(
    request: Request,
) -> JSONResponse:
    """Submit LM2 Revenue Calculator form with behavioral enrichment.

    Flow:
    1. Extract enrichment data from headers/body
    2. Validate form submission
    3. Calculate results (if not provided)
    4. Categorize lead quality
    5. Sync to Zoho CRM (async)
    6. Send report email (async)
    7. Return success with results

    Request Body:
    {
        "deal_size": 10000,
        "daily_calls": 100,
        "missed_percent": 15,
        "team_size": 5,
        "conversion_percent": 15,
        "email": "user@company.com",
        "results": {
            "monthly_lost_revenue": 56250,
            "annual_lost_revenue": 675000,
            ...
        },
        "enrichment": {
            "session_id": "sess_...",
            "device_fingerprint": "...",
            "utm_source": "google",
            ...
        }
    }

    Response:
    {
        "success": true,
        "lead_id": "...",
        "results": {
            "monthly_lost_revenue": 56250,
            "annual_lost_revenue": 675000,
            "lead_quality": "hot"
        }
    }
    """
    try:
        # Parse request body
        body_data = await request.json()

        # Extract enrichment data
        enrichment = await extract_enrichment_data(request)

        # Extract form data
        deal_size = float(body_data.get("deal_size", 0))
        daily_calls = int(body_data.get("daily_calls", 0))
        missed_percent = float(body_data.get("missed_percent", 0))
        team_size = int(body_data.get("team_size", 0))
        conversion_percent = float(body_data.get("conversion_percent", 0))
        email = body_data.get("email", "").lower().strip()

        # Validate required fields
        if not all([deal_size, daily_calls, team_size, email]):
            raise HTTPException(status_code=400, detail="Missing required fields")

        if missed_percent < 0 or missed_percent > 100:
            raise HTTPException(status_code=400, detail="missed_percent must be 0-100")
        if conversion_percent < 0 or conversion_percent > 100:
            raise HTTPException(status_code=400, detail="conversion_percent must be 0-100")

        # Calculate on backend (authoritative), ignore client-supplied `results`.
        server_results = calculate_lm2_results(
            deal_size=deal_size,
            daily_calls=daily_calls,
            missed_percent=missed_percent,
            conversion_percent=conversion_percent,
        )
        daily_missed_calls = server_results["daily_missed_calls"]
        monthly_missed_calls = server_results["monthly_missed_calls"]
        monthly_lost_deals = server_results["monthly_lost_deals"]
        monthly_lost_revenue = server_results["monthly_lost_revenue"]
        annual_lost_revenue = server_results["annual_lost_revenue"]

        # Categorize lead quality
        lead_quality = categorize_lead_quality(monthly_lost_revenue)

        # Create LM2 submission
        lm2_data = LM2Submission(
            deal_size=deal_size,
            daily_calls=daily_calls,
            missed_percent=missed_percent,
            team_size=team_size,
            conversion_percent=conversion_percent,
            email=email,
            daily_missed_calls=daily_missed_calls,
            monthly_missed_calls=monthly_missed_calls,
            monthly_lost_deals=monthly_lost_deals,
            monthly_lost_revenue=monthly_lost_revenue,
            annual_lost_revenue=annual_lost_revenue,
            lead_quality=lead_quality,
        )

        # Create lead submission
        submission = LeadMagnetSubmission(
            source=LeadSource.LM2_REVENUE_CALCULATOR,
            email=email,
            enrichment=enrichment,
            lm2_data=lm2_data,
        )

        # Log submission
        logger.info(
            f"LM2 submission: email={email}, "
            f"monthly_loss=${monthly_lost_revenue:,.0f}, "
            f"quality={lead_quality}, "
            f"session={enrichment.session_id[:8]}..."
        )

        # Sync to Zoho CRM (async, non-blocking)
        if _ZOHO_ENABLED:
            # Non-blocking background sync - don't await for response
            async def sync_background():
                try:
                    return await _sync_to_zoho(submission)
                except Exception as e:
                    logger.error("Background Zoho sync failed: %s", e)
                    return {"success": False, "error": "Operation failed. Please try again."}

            # Fire and forget - don't block response
            asyncio.create_task(sync_background())

        # Generate PDF and send report email (async, non-blocking)
        if _PDF_ENABLED and _EMAIL_ENABLED:

            async def report_background():
                try:
                    return await _generate_and_send_report(submission)
                except Exception as e:
                    logger.error("Background report generation failed: %s", e)
                    return {"success": False, "error": "Operation failed. Please try again."}

            # Fire and forget - don't block response
            asyncio.create_task(report_background())

        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "lead_id": submission.email,  # Will be updated to CRM ID when sync completes
                "results": {
                    "monthly_lost_revenue": monthly_lost_revenue,
                    "annual_lost_revenue": annual_lost_revenue,
                    "lead_quality": lead_quality,
                    "daily_missed_calls": daily_missed_calls,
                    "monthly_missed_calls": monthly_missed_calls,
                    "monthly_lost_deals": monthly_lost_deals,
                    "results_source": "server",
                },
                "enrichment_captured": len(enrichment.events) > 0,
                "zoho_sync": "enabled" if _ZOHO_ENABLED else "disabled",
                "report_email": "enabled" if (_PDF_ENABLED and _EMAIL_ENABLED) else "disabled",
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error processing LM2 submission: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to process submission. Please try again.",
        )


@router.post("/lm1/submit")
async def submit_lm1(
    request: Request,
) -> JSONResponse:
    """Submit LM1 AI Eligibility Assessment form with behavioral enrichment.

    Flow:
    1. Extract enrichment data from headers/body
    2. Validate form submission
    3. Calculate eligibility score
    4. Sync to Zoho CRM (async)
    5. Send report email (async)
    6. Return success with results

    Request Body:
    {
        "website": "https://company.com",
        "employees": "20-50",
        "role": "ceo",
        "industry": "real_estate",
        "country": "United States",
        "crm": "Salesforce",
        "process": "CRM Integration",
        "tool": "QuickBooks",
        "email": "user@company.com",
        "phone": "+1234567890",
        "score": 75,
        "eligible": true,
        "enrichment": {
            "session_id": "sess_...",
            "device_fingerprint": "...",
            "utm_source": "google",
            ...
        }
    }

    Response:
    {
        "success": true,
        "lead_id": "...",
        "score": 75,
        "eligible": true,
        "enrichment_captured": true,
        "zoho_sync": "enabled"
    }
    """
    try:
        # Parse request body
        body_data = await request.json()

        # Extract enrichment data
        enrichment = await extract_enrichment_data(request)

        # Extract form data
        website = body_data.get("website", "").strip()
        employees = body_data.get("employees", "")
        role = body_data.get("role", "")
        industry = body_data.get("industry", "")
        country = body_data.get("country", "")
        crm = body_data.get("crm", "")
        process = body_data.get("process", "")
        tool = body_data.get("tool", "")
        email = body_data.get("email", "").lower().strip()
        phone = body_data.get("phone", "")
        client_score = int(body_data.get("score", 0))
        client_eligible = bool(body_data.get("eligible", False))

        # Validate required fields
        if not all([website, employees, role, industry, country, crm, process, tool, email]):
            raise HTTPException(status_code=400, detail="Missing required fields")

        # Log submission
        logger.info(
            f"LM1 submission: email={email}, "
            f"score(client)={client_score}%, "
            f"eligible(client)={client_eligible}, "
            f"industry={industry}, "
            f"employees={employees}, "
            f"session={enrichment.session_id[:8]}..."
        )

        score_data = calculate_lm1_score(
            employees=employees,
            crm=crm,
            process=process,
            tool=tool,
            industry=industry,
        )
        server_score = int(score_data["score"])
        server_eligible = bool(score_data["eligible"])
        if client_score != server_score or client_eligible != server_eligible:
            logger.warning(
                "LM1 client score mismatch for %s: client=(%s,%s) server=(%s,%s)",
                email,
                client_score,
                client_eligible,
                server_score,
                server_eligible,
            )

        # Create lead submission
        submission = LeadMagnetSubmission(
            source=LeadSource.LM1_AI_ELIGIBILITY,
            email=email,
            phone=phone if phone else None,
            enrichment=enrichment,
            lm1_score=server_score,
            lm1_eligible=server_eligible,
            company_website=website,
            employee_count=employees,
            industry=industry,
            role=role,
            company_name=body_data.get("company", "").strip() or None,
        )

        # Sync to Zoho CRM (async, non-blocking)
        if _ZOHO_ENABLED:

            async def sync_background():
                try:
                    return await _sync_to_zoho(submission)
                except Exception as e:
                    logger.error("Background Zoho sync failed: %s", e)
                    return {"success": False, "error": "Operation failed. Please try again."}

            # Fire and forget - don't block response
            asyncio.create_task(sync_background())

        # Generate PDF and send report email (async, non-blocking)
        if _PDF_ENABLED and _EMAIL_ENABLED:

            async def report_background():
                try:
                    return await _generate_and_send_report(submission)
                except Exception as e:
                    logger.error("Background report generation failed: %s", e)
                    return {"success": False, "error": "Operation failed. Please try again."}

            # Fire and forget - don't block response
            asyncio.create_task(report_background())

        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "lead_id": submission.email,
                "score": server_score,
                "eligible": server_eligible,
                "score_source": score_data["score_source"],
                "score_factors": score_data["factors"],
                "enrichment_captured": len(enrichment.events) > 0,
                "zoho_sync": "enabled" if _ZOHO_ENABLED else "disabled",
                "report_email": "enabled" if (_PDF_ENABLED and _EMAIL_ENABLED) else "disabled",
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error processing LM1 submission: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to process submission. Please try again.",
        )


@router.post("/waitlist/submit")
async def submit_waitlist(
    request: Request,
) -> JSONResponse:
    """Submit waitlist signup with behavioral enrichment.

    Request Body:
    {
        "email": "user@company.com",
        "name": "Ada Lovelace",
        "company": "Analytical Engines Ltd",
        "role_interest": "Operations",
        "phone": "+971501234567",
        "enrichment": {...}
    }
    """
    try:
        body_data = await request.json()
        enrichment = await extract_enrichment_data(request)

        full_name = body_data.get("name", "").strip()
        email = body_data.get("email", "").lower().strip()
        company = body_data.get("company", "").strip()
        role_interest = body_data.get("role_interest", "").strip()
        phone = body_data.get("phone")

        if not full_name:
            raise HTTPException(status_code=400, detail="Name is required")
        if not email:
            raise HTTPException(status_code=400, detail="Email is required")

        waitlist_position, is_new_signup = _assign_waitlist_position(email)

        name_parts = full_name.split()
        first_name = name_parts[0]
        last_name = " ".join(name_parts[1:]) if len(name_parts) > 1 else ""

        submission = LeadMagnetSubmission(
            source=LeadSource.WAITLIST,
            email=email,
            first_name=first_name,
            last_name=last_name or None,
            phone=phone,
            company_name=company or None,
            role=role_interest or None,
            waitlist_position=waitlist_position,
            enrichment=enrichment,
        )

        logger.info(
            f"Waitlist signup: email={email}, "
            f"position={waitlist_position}, new={is_new_signup}, "
            f"session={enrichment.session_id[:8]}..., "
            f"returning={enrichment.is_returning_visitor}"
        )

        zoho_result: dict[str, Any] | None = None
        zoho_ok = True
        if _ZOHO_ENABLED and is_new_signup:
            # NOTE: This is intentionally synchronous for WAITLIST so we can fail-closed
            # and avoid issuing Zara demo access tokens without a CRM record.
            zoho_result = await _sync_to_zoho(submission)
            zoho_ok = bool(zoho_result.get("success"))
            if not zoho_ok:
                logger.warning(
                    "Waitlist Zoho sync failed; Zara access token will not be issued: email=%s",
                    email,
                )

        zara_access_token: str | None = None
        zara_try_url: str | None = None
        zara_unlock_reason = ""

        if zoho_ok:
            try:
                try:
                    from apps.backend.services.zara.zara_access_token_service import (
                        issue_zara_access_token,
                    )
                except ImportError:  # pragma: no cover
                    from services.zara.zara_access_token_service import issue_zara_access_token

                zara_access_token = issue_zara_access_token(
                    email=email,
                    waitlist_position=waitlist_position,
                )
                site_base = str(os.getenv("PUBLIC_SITE_BASE_URL") or "https://workweaver.ai").rstrip("/")
                zara_try_url = f"{site_base}/?zara_access={quote(zara_access_token)}#zara"
            except Exception as e:
                logger.error("Failed to issue Zara access token: %s", e)
                zara_unlock_reason = "token_issue_failed"
        else:
            zara_unlock_reason = "crm_sync_failed"

        if _EMAIL_ENABLED:

            async def waitlist_email_background():
                try:
                    return await _send_waitlist_confirmation_email(
                        submission=submission,
                        waitlist_position=waitlist_position,
                        zara_try_url=zara_try_url,
                    )
                except Exception as e:
                    logger.error("Waitlist confirmation email failed: %s", e)
                    return {"success": False, "error": "Operation failed. Please try again."}

            asyncio.create_task(waitlist_email_background())

        return JSONResponse(
            status_code=200,
            content={
                "success": True,
                "message": "You've been added to the waitlist!",
                "waitlist_position": waitlist_position,
                "is_new_signup": is_new_signup,
                "next_path": "/assess/",
                "zara_access_token": zara_access_token,
                "zara_try_url": zara_try_url,
                "zara_unlock": "enabled" if zara_access_token else "pending",
                "zara_unlock_reason": zara_unlock_reason if not zara_access_token else "",
                "zoho_sync": "enabled" if _ZOHO_ENABLED else "disabled",
                "waitlist_email": "enabled" if _EMAIL_ENABLED else "disabled",
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error processing waitlist submission: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to process signup. Please try again.",
        )


@router.get("/health")
async def health_check() -> JSONResponse:
    """Health check endpoint for lead magnet API."""
    return JSONResponse(
        status_code=200,
        content={
            "status": "healthy",
            "service": "lead-magnets",
            "timestamp": datetime.now(UTC).isoformat(),
        },
    )


@router.post("/zara/authorize")
async def authorize_zara(request: Request) -> JSONResponse:
    """Verify Zara access token and (optionally) sync a phone number to Zoho.

    Body:
    {
      "zara_access_token": "...",
      "phone": "+14155551234" // optional; when set, we upsert the lead with this phone.
    }
    """
    body = await request.json()
    token = str(body.get("zara_access_token") or "").strip()
    phone = str(body.get("phone") or "").strip() or None

    if not token:
        raise HTTPException(status_code=401, detail="zara_access_token is required")

    try:
        try:
            from apps.backend.services.zara.zara_access_token_service import (
                verify_zara_access_token,
                ZaraAccessTokenError,
            )
        except ImportError:  # pragma: no cover
            from services.zara.zara_access_token_service import (
                verify_zara_access_token,
                ZaraAccessTokenError,
            )

        claims = verify_zara_access_token(token)
    except ZaraAccessTokenError:
        raise HTTPException(status_code=401, detail="invalid_zara_access_token")
    except Exception as e:
        logger.error("Zara access token verification failed: %s", e)
        raise HTTPException(status_code=503, detail="authorization_unavailable")

    if phone and _ZOHO_ENABLED:
        enrichment = await extract_enrichment_data(request)
        submission = LeadMagnetSubmission(
            source=LeadSource.WAITLIST,
            email=claims.email,
            phone=phone,
            enrichment=enrichment,
        )
        zoho_result = await _sync_to_zoho(submission)
        if not zoho_result.get("success"):
            raise HTTPException(status_code=503, detail="crm_sync_failed")

    return JSONResponse(
        status_code=200,
        content={
            "success": True,
            "email": claims.email,
            "phone_saved": bool(phone and _ZOHO_ENABLED),
            "zoho_sync": "enabled" if _ZOHO_ENABLED else "disabled",
        },
    )
