"""Shared helpers for auth signup routes."""

from __future__ import annotations

import importlib
import logging
import os
from html import escape
from types import ModuleType
from collections.abc import Callable
from urllib.parse import urlencode, urlparse

from fastapi import HTTPException, Response, status
from fastapi.responses import HTMLResponse, RedirectResponse

from apps.backend.api.auth_models import AuthProvider, SignupResponse
from apps.backend.services.session.browser_session import mint_cli_auth_code
from apps.backend.services.cli_login_bridge import has_cli_login_attempt, publish_cli_login_result
from apps.backend.services.oauth_redirect_state import (
    OAuthRedirectError,
    is_workweaver_host,
    normalize_return_to_origin as normalize_origin,
)
from apps.backend.services.tenant_provisioning import TenantAlreadyExistsError, get_tenant_provisioning_service

logger = logging.getLogger("apps.backend.api.auth_signup")

PUBLIC_WEB_ORIGIN_FALLBACK = "https://workweaver.ai"
PUBLIC_LOGIN_PATH = "/login/"
PUBLIC_MISSION_PATH = "/mission/"
PUBLIC_RUNTIME_PATH = "/runtime/"
PUBLIC_PROVISIONING_PATH = "/provisioning/"
_SUPPORTED_OAUTH_PROVIDERS = frozenset({"google", "microsoft", "oidc", "zoho"})
_SUPPORTED_OAUTH_CLIENTS = frozenset({"web", "cli"})
_PUBLIC_REDIRECT_PATHS = frozenset(
    {
        PUBLIC_LOGIN_PATH,
        PUBLIC_MISSION_PATH,
        PUBLIC_RUNTIME_PATH,
        PUBLIC_PROVISIONING_PATH,
    }
)
CLI_AUTH_CODE_TTL_SECONDS = 120


class OAuthSignupRequiredError(Exception):
    """Raised when a login-only OAuth flow finds no existing Workweaver tenant."""


class ExistingAccountDifferentProviderError(Exception):
    """Raised when an OAuth signin collides with an existing tenant that was
    created via a different auth provider.

    Blocks silent auto-merge which would otherwise permit the following
    account-takeover attack:
      1. Attacker signs up with email+password using victim@example.com
      2. Victim signs into Workweaver with Google using victim@example.com
      3. Without this check, backend finds the attacker's tenant by email
         and returns it to the victim's Google session → attacker owns
         the victim's Workweaver tenant.

    The correct user-facing fix is to surface this as "An account exists
    with this email — please sign in with <original_provider>. You can
    see which provider this account uses by visiting
    https://workweaver.ai/dashboard/settings?tab=signin once signed in."

    #773 (2026-04-09): the recovery-path Settings UI now exists. The
    user can hit /dashboard/settings?tab=signin to see their original
    sign-in method. Multi-provider linking is still on the roadmap
    (#773 follow-up); until it ships, this error message points users
    at the read-only view that answers "which provider did I use".
    """

    def __init__(self, *, email: str, existing_provider: str, attempted_provider: str) -> None:
        self.email = email
        self.existing_provider = existing_provider
        self.attempted_provider = attempted_provider
        super().__init__(
            f"Tenant {email} already exists under provider={existing_provider}; "
            f"attempted sign-in with provider={attempted_provider}"
        )


def get_auth_signup_facade() -> ModuleType:
    return importlib.import_module("apps.backend.api.auth_signup")


def _public_api_base_url() -> str:
    return (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")


# Single canonical OAuth callback URL — see oauth_dispatcher.py for the
# rationale and routing rules. ALL providers register this exact URL in
# their developer console; the dispatcher reads state.flow / state.provider
# to forward to the right internal handler.
#
# Set OAUTH_DISPATCHER_DISABLED=1 to fall back to the legacy per-provider
# URLs during a rollback. The legacy routes are still mounted (the migration
# is backwards compatible) so flipping this flag is a clean revert.
def _unified_oauth_callback_url() -> str:
    return f"{_public_api_base_url()}/oauth/callback"


def _provider_callback_uri(provider: str) -> str:
    provider_key = str(provider or "").strip().lower()
    if provider_key not in _SUPPORTED_OAUTH_PROVIDERS:
        raise ValueError(f"Unsupported OAuth provider: {provider}")
    if os.environ.get("OAUTH_DISPATCHER_DISABLED", "").strip().lower() in {"1", "true", "yes"}:
        # Rollback path: legacy per-provider URLs.
        return f"{_public_api_base_url()}/api/v1/auth/{provider_key}/callback"
    # Default: single canonical URL for all providers.
    return _unified_oauth_callback_url()


def _callback_uri_from_request(request, provider: str) -> str:
    """Build the redirect_uri to use for the token exchange step.

    Echoes back the URL path that the OAuth provider actually redirected
    to. This is critical for in-flight flows during a deploy: an OAuth
    request that started BEFORE the dispatcher deploy used the legacy
    /api/v1/auth/{provider}/callback URL, and the provider validates the
    token-exchange redirect_uri AGAINST that original value. Always
    using _provider_callback_uri() would break in-flight flows because
    that function now returns the NEW dispatcher URL.

    By echoing request.url.path, both the new dispatcher route AND the
    legacy per-provider routes work simultaneously without breaking any
    in-flight flows. After the legacy routes are removed (Phase 3, 30+
    days from now), this function can be inlined to just return the
    dispatcher URL.
    """
    try:
        path = str(getattr(getattr(request, "url", None), "path", "") or "")
    except Exception:
        path = ""
    if not path:
        # Fallback when no request object is available (e.g. tests).
        return _provider_callback_uri(provider)
    return f"{_public_api_base_url()}{path}"


def _normalize_oauth_client(client: str | None) -> str:
    normalized = str(client or "").strip().lower() or "web"
    if normalized not in _SUPPORTED_OAUTH_CLIENTS:
        raise ValueError(f"Unsupported OAuth client: {client}")
    return normalized


def _require_cli_return_to_origin(origin: str) -> str:
    normalized_origin = _safe_return_to_origin(origin)
    parsed = urlparse(normalized_origin)
    host = (parsed.hostname or "").strip().lower()
    if host not in {"localhost"} and not host.startswith("127.") and not is_workweaver_host(host):
        raise ValueError("CLI OAuth return_to must use a Workweaver or local development origin.")
    return normalized_origin


def _is_cli_bridge_origin(origin: str) -> bool:
    parsed = urlparse(str(origin or "").strip())
    host = (parsed.hostname or "").strip().lower()
    return is_workweaver_host(host)


def _resolve_oauth_login_start(
    *,
    provider: str | None = None,
    return_to: str,
    client: str | None,
    client_state: str | None,
    normalize_return_to: Callable[[str], str] = normalize_origin,
    detail_key: str = "message",
) -> tuple[str, str]:
    try:
        return_to_origin = normalize_return_to(return_to)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_return_to", detail_key: str(exc)},
        ) from exc

    try:
        normalized_client = _normalize_oauth_client(client)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_client", detail_key: str(exc)},
        ) from exc

    if normalized_client == "cli":
        try:
            return_to_origin = _require_cli_return_to_origin(return_to_origin)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={"error": "invalid_return_to", detail_key: str(exc)},
            ) from exc
        if not str(client_state or "").strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={"error": "invalid_client_state", detail_key: "CLI OAuth requires a client state value."},
            )
        if _is_cli_bridge_origin(return_to_origin) and not has_cli_login_attempt(
            str(client_state or "").strip(),
            provider=str(provider or "").strip().lower() or None,
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_client_state",
                    detail_key: "CLI OAuth login attempt is missing or expired. Run `ww auth login` again.",
                },
            )

    return return_to_origin, normalized_client


def _safe_return_to_origin(raw_origin: str | None) -> str:
    try:
        return normalize_origin(raw_origin or PUBLIC_WEB_ORIGIN_FALLBACK)
    except OAuthRedirectError:
        return PUBLIC_WEB_ORIGIN_FALLBACK


def _public_redirect_url(
    *,
    origin: str,
    path: str,
    query_params: dict[str, str] | None = None,
) -> str:
    if path not in _PUBLIC_REDIRECT_PATHS:
        raise ValueError(f"Unsupported public redirect path: {path}")

    base = f"{_safe_return_to_origin(origin)}{path}"
    if not query_params:
        return base

    cleaned_params = {
        str(k): str(v) for k, v in query_params.items() if k is not None and v is not None and str(k).strip()
    }
    if not cleaned_params:
        return base

    return f"{base}?{urlencode(cleaned_params)}"


def _provider_error_param(provider: str) -> str:
    provider_key = str(provider or "").strip().lower()
    if provider_key not in _SUPPORTED_OAUTH_PROVIDERS:
        raise ValueError(f"Unsupported OAuth provider: {provider}")
    return f"{provider_key}_error"


def _oauth_error_redirect_url(
    *,
    origin: str,
    provider: str,
    error_code: str,
    client: str | None = None,
    client_state: str | None = None,
) -> str:
    del client, client_state
    return _public_redirect_url(
        origin=origin,
        path=PUBLIC_LOGIN_PATH,
        query_params={_provider_error_param(provider): error_code},
    )


def _oauth_login_start_failure_redirect(
    *,
    provider: str,
    origin: str,
    reason: str,
    client: str | None = None,
    client_state: str | None = None,
) -> Response:
    oauth_client = _normalize_oauth_client(client)
    if oauth_client == "cli":
        if str(client_state or "").strip():
            publish_cli_login_result(
                client_state=client_state,
                provider=provider,
                error="provider_unavailable",
                ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
            )
        logger.warning("%s OAuth login start failed: %s", provider.capitalize(), reason)
        _emit_oauth_callback_event(
            provider=provider,
            outcome="login_start_failed",
            redirect_to="cli_terminal",
            reason=reason,
        )
        return _cli_terminal_page(
            title="Workweaver login unavailable",
            body=(
                f"{provider.capitalize()} sign-in could not start just now. "
                "Return to the terminal and run `ww auth login` again."
            ),
        )
    dest = _oauth_error_redirect_url(
        origin=origin,
        provider=provider,
        error_code="provider_unavailable",
        client=client,
        client_state=client_state,
    )
    logger.warning("%s OAuth login start failed: %s", provider.capitalize(), reason)
    _emit_oauth_callback_event(
        provider=provider,
        outcome="login_start_failed",
        redirect_to=dest,
        reason=reason,
    )
    return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)


def _emit_oauth_callback_event(
    *,
    provider: str,
    outcome: str,
    redirect_to: str,
    email: str | None = None,
    reason: str | None = None,
) -> None:
    email_value = (email or "").strip().lower()
    email_domain = ""
    if "@" in email_value:
        email_domain = email_value.rsplit("@", 1)[-1]

    payload = {
        "provider": str(provider or "").strip().lower(),
        "outcome": str(outcome or "").strip().lower(),
        "redirect_to": redirect_to,
        "email_domain": email_domain or None,
        "reason": reason,
    }
    logger.info("auth_oauth_callback_event %s", payload)


def _cli_terminal_page(*, title: str, body: str, status_code: int = status.HTTP_200_OK) -> HTMLResponse:
    safe_title = escape(str(title or "Workweaver"))
    safe_body = escape(str(body or ""))
    html = (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<title>{safe_title}</title>"
        "<style>body{font-family:system-ui,-apple-system,sans-serif;max-width:48rem;margin:4rem auto;"
        "padding:0 1.5rem;line-height:1.5;color:#111827}h1{font-size:1.5rem}p{color:#374151}</style>"
        f"</head><body><h1>{safe_title}</h1><p>{safe_body}</p></body></html>"
    )
    return HTMLResponse(content=html, status_code=status_code)


def _build_cli_oauth_error_response(
    *,
    provider: str,
    client_state: str | None,
    outcome: str,
    error_code: str,
    message: str,
    reason: str | None = None,
) -> HTMLResponse:
    normalized_client_state = str(client_state or "").strip()
    if normalized_client_state:
        publish_cli_login_result(
            client_state=normalized_client_state,
            provider=provider,
            error=error_code,
            ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
        )
    _emit_oauth_callback_event(
        provider=provider,
        outcome=outcome,
        redirect_to="cli_terminal",
        reason=reason or error_code,
    )
    return _cli_terminal_page(
        title=f"Workweaver {provider} login failed",
        body=f"{message} Return to the terminal and run `ww auth login` again.",
    )


def _build_post_signup_redirect(
    *,
    provider: str,
    response: SignupResponse,
    return_to_origin: str,
    client: str | None = None,
    client_state: str | None = None,
    code_challenge: str | None = None,
    code_challenge_method: str | None = None,
) -> Response:
    oauth_client = _normalize_oauth_client(client)
    if oauth_client == "cli":
        normalized_client_state = str(client_state or "").strip()
        if not normalized_client_state:
            logger.warning("CLI OAuth callback missing client_state for provider=%s", provider)
            return _cli_terminal_page(
                title="Workweaver login failed",
                body="The CLI login could not be completed. Return to the terminal and try again.",
            )
        exchange_code = mint_cli_auth_code(
            tenant_id=response.tenant_id,
            user_id=response.user_id,
            email=response.email,
            provider=provider,
            code_challenge=str(code_challenge or "").strip(),
            code_challenge_method=str(code_challenge_method or "").strip().upper() or "S256",
            ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
        )
        publish_cli_login_result(
            client_state=normalized_client_state,
            provider=provider,
            code=exchange_code,
            ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
        )
        response_redirect = _cli_terminal_page(
            title="Workweaver login complete",
            body="You can return to the terminal. The ww CLI is finishing sign-in now.",
        )
        try:
            _set_runtime_auth_cookies(response_redirect, response)
        except Exception as exc:
            logger.warning("Failed setting runtime auth cookies (cli): %s", exc)
        _emit_oauth_callback_event(
            provider=provider,
            outcome="cli_exchange_ready",
            redirect_to="cli_terminal",
            email=getattr(response, "email", None),
        )
        return response_redirect

    next_step = str(getattr(response, "next_step", "")).strip().lower()
    checkout_url = str(getattr(response, "stripe_checkout_url", "") or "").strip()

    if checkout_url and next_step == "stripe_checkout":
        _emit_oauth_callback_event(
            provider=provider,
            outcome="stripe_checkout_redirect",
            redirect_to="stripe_checkout",
            email=getattr(response, "email", None),
        )
        return RedirectResponse(url=checkout_url, status_code=status.HTTP_302_FOUND)

    if next_step == "runtime_ready":
        mission_url = _public_redirect_url(origin=return_to_origin, path=PUBLIC_MISSION_PATH)
        response_redirect = RedirectResponse(url=mission_url, status_code=status.HTTP_302_FOUND)
        try:
            _set_runtime_auth_cookies(response_redirect, response)
        except Exception as exc:
            logger.warning("Failed setting runtime auth cookies (ready): %s", exc)
        _emit_oauth_callback_event(
            provider=provider,
            outcome="runtime_ready_redirect",
            redirect_to=mission_url,
            email=getattr(response, "email", None),
        )
        return response_redirect

    runtime_url = _public_redirect_url(origin=return_to_origin, path=PUBLIC_RUNTIME_PATH)
    response_redirect = RedirectResponse(url=runtime_url, status_code=status.HTTP_302_FOUND)
    _set_runtime_auth_cookies(response_redirect, response)
    _emit_oauth_callback_event(
        provider=provider,
        outcome="runtime_provisioning_redirect",
        redirect_to=runtime_url,
        email=getattr(response, "email", None),
    )
    return response_redirect


def _oauth_read_authoritative_tenant(tenant_id: str) -> dict | None:
    """Consistent-read the METADATA row for the OAuth existing-tenant
    suspend gate. Returns ``None`` on failure so the caller can fall
    back to the GSI projection (which still has ``status`` from the
    GSI).
    """
    normalized = str(tenant_id or "").strip()
    if not normalized:
        return None
    try:
        from apps.backend.dependency_factories.core import get_tenants_table

        _table = get_tenants_table()
        _resp = _table.get_item(
            Key={"pk": normalized, "sk": "METADATA"},
            ConsistentRead=True,
        )
        return _resp.get("Item") or None
    except Exception:  # noqa: BLE001
        logger.warning("oauth_tenant_metadata_read_failed tenant=%s", normalized, exc_info=True)
        return None


def _signup_response_from_existing_tenant(
    *,
    tenant: dict,
    email: str,
    user_id: str,
    provider: AuthProvider,
) -> SignupResponse:
    # Codex round-4 BLOCK fix (issue #1146): OAuth existing-tenant
    # sign-in previously returned a fresh signup response (and the
    # caller then minted a fresh browser cookie) without consulting
    # tenant status. That let a suspended user re-enter via
    # Google/Microsoft/Zoho and ride the new cookie past the auth
    # gate. Reject here — this is the single seam every OAuth
    # re-login branch funnels through.
    _tenant_status = str(tenant.get("status") or "").strip().lower()
    _suspended_by = str(tenant.get("suspended_by") or "").strip()
    if _tenant_status == "suspended" or _suspended_by:
        # Do a consistent METADATA read for authoritative status —
        # the tenant dict here may be a stale GSI projection.
        _fresh = _oauth_read_authoritative_tenant(str(tenant.get("tenant_id") or tenant.get("pk") or ""))
        _authoritative = _fresh or tenant
        _auth_status = str(_authoritative.get("status") or "").strip().lower()
        _auth_sus_by = str(_authoritative.get("suspended_by") or "").strip()
        if _auth_status == "suspended" and _auth_sus_by:
            from fastapi import HTTPException, status as _status

            # Log via structured extra so the founder email is
            # kept out of the rendered message body.
            logger.warning(
                "oauth_signin_blocked_tenant_suspended",
                extra={
                    "tenant_id": _authoritative.get("tenant_id"),
                    "provider": provider.value,
                },
            )
            raise HTTPException(
                status_code=_status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "tenant_suspended",
                    "message": (
                        "This organization is currently suspended. Please contact Workweaver support to restore access."
                    ),
                    "suspended_reason": str(_authoritative.get("suspended_reason") or "").strip() or None,
                },
            )

    runtime = tenant.get("runtime") if isinstance(tenant.get("runtime"), dict) else {}
    provenance = tenant.get("provenance") if isinstance(tenant.get("provenance"), dict) else {}
    runtime_status = str(runtime.get("status") or "").strip()
    endpoint = str(runtime.get("endpoint") or "").strip() or None
    next_step = "runtime_ready" if runtime_status == "ready" else "runtime_provisioning"

    return SignupResponse(
        tenant_id=str(tenant.get("tenant_id") or ""),
        user_id=user_id,
        status=str(tenant.get("status") or "active"),
        email=email,
        role="ADMIN",
        auth_provider=provider.value,
        next_step=next_step,
        provisioning_mode=str(provenance.get("provisioning_mode") or "stripe_checkout"),
        runtime_instance_id=str(runtime.get("instance_id") or "").strip() or None,
        runtime_public_ip=str(runtime.get("public_ip") or "").strip() or None,
        runtime_endpoint=endpoint,
        runtime_launch_url=None,
        runtime_status=runtime_status or None,
        runtime_step=str(runtime.get("step") or "").strip() or None,
    )


def _lookup_tenant_by_provider_id(
    *,
    owner_user_id: str,
    product: str | None,
) -> dict | None:
    """Strong match: find a tenant by the cryptographically-verified provider ID.

    Safe to auto-return — if the owner_user_id matches, the caller has
    already proven control of that identity (via OAuth ID token validation
    or Cognito authentication).
    """
    provisioning = get_tenant_provisioning_service()
    return provisioning.get_tenant_by_owner(owner_user_id, product=product) or provisioning.get_tenant_by_owner(
        owner_user_id, product=None
    )


def _lookup_tenant_by_email(
    *,
    email: str,
    product: str | None,
) -> dict | None:
    """Weak match: find a tenant purely by email.

    NEVER return this directly as a signed-in session. The caller must
    first verify that the email match corresponds to the same auth provider
    that created the tenant. See _resolve_oauth_signin_response for the
    account-takeover-safe usage.
    """
    provisioning = get_tenant_provisioning_service()
    return provisioning.get_tenant_by_email(email, product=product) or provisioning.get_tenant_by_email(
        email, product=None
    )


def _lookup_existing_tenant_for_identity(
    *,
    owner_user_id: str,
    email: str,
    product: str | None,
) -> dict | None:
    """Strong match only. Retained for backwards compatibility with callers
    that don't need the cross-provider collision check. New callers should
    use _lookup_tenant_by_provider_id / _lookup_tenant_by_email directly
    and explicitly handle the cross-provider case.
    """
    return _lookup_tenant_by_provider_id(
        owner_user_id=owner_user_id,
        product=product,
    )


def _lookup_tenant_id_by_identity_link(provider: str, owner_user_id: str) -> str | None:
    try:
        from apps.backend.services.identity_links import lookup_tenant_by_identity_link

        return lookup_tenant_by_identity_link(provider, owner_user_id)
    except Exception:
        logger.warning("identity_links lookup failed provider=%s", provider, exc_info=True)
        return None


def _touch_identity_link_last_login(provider: str, owner_user_id: str) -> None:
    try:
        from apps.backend.services.identity_links import touch_last_login

        touch_last_login(provider, owner_user_id)
    except Exception:
        logger.warning("touch_last_login failed provider=%s", provider, exc_info=True)


async def _resolve_oauth_signin_response(
    *,
    provider: AuthProvider,
    owner_user_id: str,
    email: str,
    owner_name: str | None = None,
    preferred_region: str | None = None,
    product: str | None = "workweaver",
    invite_token: str | None = None,
    sub_tenant_invite_token: str | None = None,
    allow_signup: bool = True,
    consent: object | None = None,
) -> SignupResponse:
    facade = get_auth_signup_facade()

    # Step 1 (STRONG): match by the cryptographically-verified provider user ID.
    # If this hits, the caller has proven control of that identity via OAuth
    # token validation — safe to return the tenant directly.
    strong_tenant = _lookup_tenant_by_provider_id(
        owner_user_id=owner_user_id,
        product=product,
    )
    if strong_tenant:
        facade._resume_runtime_provisioning_if_needed(
            strong_tenant,
            task_name=f"runtime_resume_from_{provider.value}_signin",
            force=True,
        )
        resolved_user_id = str(strong_tenant.get("owner_user_id") or "").strip() or owner_user_id
        return _signup_response_from_existing_tenant(
            tenant=strong_tenant,
            email=email,
            user_id=resolved_user_id,
            provider=provider,
        )

    # Step 1b (STRONG via identity_links): If the provider identity is
    # registered in the identity_links table (multi-provider linking),
    # resolve the tenant through that table.  This is the path that fires
    # when a user signs in with a *linked* provider (not their original
    # primary provider).
    linked_tenant_id = _lookup_tenant_id_by_identity_link(provider.value, owner_user_id)
    if linked_tenant_id:
        provisioning = get_tenant_provisioning_service()
        linked_tenant = provisioning.get_tenant(linked_tenant_id)
        if linked_tenant:
            _touch_identity_link_last_login(provider.value, owner_user_id)
            facade._resume_runtime_provisioning_if_needed(
                linked_tenant,
                task_name=f"runtime_resume_from_{provider.value}_linked_signin",
                force=True,
            )
            resolved_user_id = str(linked_tenant.get("owner_user_id") or "").strip() or owner_user_id
            return _signup_response_from_existing_tenant(
                tenant=linked_tenant,
                email=email,
                user_id=resolved_user_id,
                provider=provider,
            )

    # Step 2 (WEAK): match by email only. A hit here means a DIFFERENT
    # provider previously claimed this email. We do NOT auto-merge because
    # doing so would allow account takeover: an attacker registers with
    # email+password using a victim's email before the victim signs up,
    # then the victim's legitimate Google sign-in would silently inherit
    # the attacker's tenant.
    #
    # Instead we raise ExistingAccountDifferentProviderError. The web
    # frontend converts this into a message: "An account already exists
    # for this email. Sign in with <original_provider>. You can link
    # additional sign-in methods from Settings → Account."
    weak_tenant = _lookup_tenant_by_email(email=email, product=product)
    if weak_tenant:
        existing_provider = str(weak_tenant.get("auth_provider") or "").strip().lower() or "email"
        raise ExistingAccountDifferentProviderError(
            email=email,
            existing_provider=existing_provider,
            attempted_provider=provider.value,
        )

    if not allow_signup:
        raise OAuthSignupRequiredError("No Workweaver tenant exists for this account.")

    try:
        return await facade._complete_signup_after_identity_verification(
            owner_user_id=owner_user_id,
            email=email,
            auth_provider=provider,
            owner_name=owner_name,
            preferred_region=preferred_region,
            product=product,
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            consent=consent,
        )
    except TenantAlreadyExistsError:
        # Race-condition fallback: create_tenant lost to a concurrent write.
        # SECURITY: Only accept the raced-in tenant if it was created with
        # the SAME provider_user_id. If a different provider (or attacker)
        # got the email first, we surface ExistingAccountDifferentProviderError
        # so the caller can render a clear "sign in with original method" UX.
        # Without this, the race winner could be the attacker's tenant.
        strong_fallback = _lookup_tenant_by_provider_id(
            owner_user_id=owner_user_id,
            product=product,
        )
        if strong_fallback:
            facade._resume_runtime_provisioning_if_needed(
                strong_fallback,
                task_name=f"runtime_resume_from_{provider.value}_signin_conflict",
                force=True,
            )
            return _signup_response_from_existing_tenant(
                tenant=strong_fallback,
                email=email,
                user_id=str(strong_fallback.get("owner_user_id") or "").strip() or owner_user_id,
                provider=provider,
            )
        weak_fallback = _lookup_tenant_by_email(email=email, product=product)
        if weak_fallback:
            existing_provider = str(weak_fallback.get("auth_provider") or "").strip().lower() or "email"
            raise ExistingAccountDifferentProviderError(
                email=email,
                existing_provider=existing_provider,
                attempted_provider=provider.value,
            )
        raise


def _set_runtime_auth_cookies(resp: Response, signup_response: SignupResponse) -> None:
    """Set cookie-backed browser auth for runtime and provisioning flows."""
    next_step = str(getattr(signup_response, "next_step", "") or "").strip().lower()
    if not next_step.startswith("runtime"):
        return

    facade = get_auth_signup_facade()
    facade._set_browser_session_cookie(
        resp,
        tenant_id=signup_response.tenant_id,
        user_id=signup_response.user_id,
        email=signup_response.email,
    )
    facade._set_runtime_provisioning_cookie(resp, tenant_id=signup_response.tenant_id)


def _normalize_product_key(product: str | None) -> str:
    candidate = (product or "").strip().lower()
    if candidate in {"workweaver", "workmemory"}:
        return candidate
    return "workweaver"
