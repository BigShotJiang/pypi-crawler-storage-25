"""Batch processing API endpoints for bulk action execution, scheduling, import, and export."""

from __future__ import annotations

import csv
import io
import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from apps.backend.services.batch_orchestrator import (
    BatchOrchestrator,
    BatchSchedule,
    get_batch_orchestrator,
)

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/batch", tags=["batch-processing"])


def _normalize_tenant_id(value: str | None) -> str:
    raw = (value or "").strip()
    if not raw:
        raise HTTPException(status_code=401, detail="Authentication required")
    return raw if raw.startswith("TENANT#") else f"TENANT#{raw}"


def get_orchestrator() -> BatchOrchestrator:
    return get_batch_orchestrator()


class BatchActionRequest(BaseModel):
    tenant_id: str = Field(..., max_length=140)
    name: str | None = Field(default=None, max_length=200)
    submitted_by: str | None = Field(default=None, max_length=140)
    source: str = Field(default="api", max_length=80)
    actions: list[dict[str, Any]] = Field(..., min_length=1)


class BatchJobResponse(BaseModel):
    tenant_id: str
    job: dict[str, Any]
    message: str = "Batch job submitted"


class BatchQueueResponse(BaseModel):
    tenant_id: str
    total: int
    offset: int
    limit: int
    counts: dict[str, int]
    jobs: list[dict[str, Any]]


class BatchJobSingleResponse(BaseModel):
    tenant_id: str
    job: dict[str, Any]


class BatchActionControlRequest(BaseModel):
    requested_by: str | None = Field(default=None, max_length=140)


class BatchScheduleRequest(BaseModel):
    tenant_id: str = Field(..., max_length=140)
    name: str = Field(..., max_length=180)
    schedule_type: str = Field(..., pattern=r"^(one_time|interval)$")
    actions: list[dict[str, Any]] = Field(..., min_length=1)
    interval_minutes: int | None = Field(default=None, ge=1, le=525600)
    run_at: str | None = Field(default=None, max_length=80)
    created_by: str | None = Field(default=None, max_length=140)


class BatchScheduleResponse(BaseModel):
    tenant_id: str
    schedule: dict[str, Any]
    message: str = "Schedule created"


class BatchSchedulesListResponse(BaseModel):
    tenant_id: str
    schedules: list[dict[str, Any]]


class BatchImportRequest(BaseModel):
    tenant_id: str = Field(..., max_length=140)
    submitted_by: str | None = Field(default=None, max_length=140)
    jobs: list[dict[str, Any]] = Field(..., min_length=1)


class BatchImportResponse(BaseModel):
    tenant_id: str
    submitted_by: str | None
    created: int
    jobs: list[dict[str, Any]]


def _to_csv(jobs: list[dict[str, Any]]) -> str:
    output = io.StringIO()
    writer = csv.DictWriter(
        output,
        fieldnames=[
            "job_id",
            "tenant_id",
            "name",
            "status",
            "source",
            "schedule_id",
            "submitted_by",
            "created_at",
            "started_at",
            "completed_at",
            "total_actions",
            "completed_actions",
            "error",
        ],
    )
    writer.writeheader()
    for job in jobs:
        row = {
            "job_id": job.get("job_id"),
            "tenant_id": job.get("tenant_id"),
            "name": job.get("name"),
            "status": job.get("status"),
            "source": job.get("source"),
            "schedule_id": job.get("schedule_id") or "",
            "submitted_by": job.get("submitted_by") or "",
            "created_at": job.get("created_at") or "",
            "started_at": job.get("started_at") or "",
            "completed_at": job.get("completed_at") or "",
            "total_actions": job.get("total_actions", 0),
            "completed_actions": job.get("completed_actions", 0),
            "error": job.get("error") or "",
        }
        writer.writerow(row)
    return output.getvalue()


@router.post("/actions", response_model=BatchJobResponse, status_code=status.HTTP_201_CREATED)
async def submit_batch_actions(
    payload: BatchActionRequest,
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchJobResponse:
    """Submit a batch of actions for immediate execution."""
    tenant_id = _normalize_tenant_id(payload.tenant_id)
    try:
        job = await orchestrator.submit_job(
            tenant_id=tenant_id,
            name=payload.name or "Batch Job",
            actions=payload.actions,
            source=payload.source or "api",
            submitted_by=payload.submitted_by,
        )
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception("Failed to submit batch job")
        raise HTTPException(status_code=500, detail="Failed to submit batch actions") from error

    return BatchJobResponse(
        tenant_id=tenant_id,
        job=job.to_dict(include_results=False),
        message="Batch job created and queued.",
    )


@router.get("/jobs", response_model=BatchQueueResponse)
async def list_batch_jobs(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    include_results: bool = Query(default=False),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchQueueResponse:
    """List batch jobs and optionally filter by status."""
    payload = await orchestrator.list_jobs(
        tenant_id=_normalize_tenant_id(tenant_id),
        status=status,
        limit=limit,
        offset=offset,
        include_results=include_results,
    )
    return BatchQueueResponse(**payload)


@router.get("/queue")
async def get_batch_queue(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(default=100, ge=1, le=500),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> dict[str, Any]:
    """Alias for list endpoint that powers queue dashboards."""
    return await orchestrator.get_queue(_normalize_tenant_id(tenant_id), limit=limit)


@router.get("/jobs/{job_id}", response_model=BatchJobSingleResponse)
async def get_batch_job(
    job_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchJobSingleResponse:
    """Get a single job by id."""
    job = await orchestrator.get_job(_normalize_tenant_id(tenant_id), job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Batch job not found")
    return BatchJobSingleResponse(tenant_id=_normalize_tenant_id(tenant_id), job=job.to_dict(include_results=True))


@router.post("/jobs/{job_id}/cancel", response_model=BatchJobSingleResponse)
async def cancel_batch_job(
    job_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    payload: BatchActionControlRequest = BatchActionControlRequest(),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchJobSingleResponse:
    """Cancel a job if it is still pending or running."""
    _ = payload.requested_by
    job = await orchestrator.get_job(_normalize_tenant_id(tenant_id), job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Batch job not found")

    cancelled = await orchestrator.cancel_job(_normalize_tenant_id(tenant_id), job_id)
    if not cancelled:
        raise HTTPException(status_code=409, detail="Job cannot be cancelled in current state")

    updated = await orchestrator.get_job(_normalize_tenant_id(tenant_id), job_id)
    return BatchJobSingleResponse(
        tenant_id=_normalize_tenant_id(tenant_id),
        job=updated.to_dict(include_results=True) if updated else job.to_dict(include_results=True),
    )


@router.post("/jobs/{job_id}/retry", response_model=BatchJobSingleResponse)
async def retry_batch_job(
    job_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    payload: BatchActionControlRequest = BatchActionControlRequest(),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchJobSingleResponse:
    """Retry a failed or cancelled batch job."""
    _ = payload.requested_by
    new_job = await orchestrator.retry_job(
        tenant_id=_normalize_tenant_id(tenant_id),
        job_id=job_id,
        requested_by=payload.requested_by,
    )
    if not new_job:
        raise HTTPException(status_code=409, detail="Job is not in a retryable state")
    return BatchJobSingleResponse(
        tenant_id=_normalize_tenant_id(tenant_id),
        job=new_job.to_dict(include_results=False),
    )


@router.post("/schedules", response_model=BatchScheduleResponse, status_code=status.HTTP_201_CREATED)
async def create_batch_schedule(
    payload: BatchScheduleRequest,
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchScheduleResponse:
    """Create a one-time or recurring batch schedule."""
    tenant_id = _normalize_tenant_id(payload.tenant_id)
    try:
        schedule = await orchestrator.create_schedule(
            tenant_id=tenant_id,
            name=payload.name,
            actions=payload.actions,
            schedule_type=payload.schedule_type,
            interval_minutes=payload.interval_minutes,
            run_at=payload.run_at,
            created_by=payload.created_by,
        )
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception("Failed to create batch schedule")
        raise HTTPException(status_code=500, detail="Failed to create batch schedule") from error

    # Backward-compatible representation expected by dashboard consumers.
    return BatchScheduleResponse(
        tenant_id=tenant_id,
        schedule=(
            schedule.to_dict()
            if isinstance(schedule, BatchSchedule)
            else {
                "schedule_id": getattr(schedule, "schedule_id", ""),
                "tenant_id": tenant_id,
                "name": payload.name,
                "schedule_type": payload.schedule_type,
                "interval_seconds": getattr(schedule, "interval_seconds", None),
                "enabled": getattr(schedule, "enabled", True),
                "created_at": None,
                "updated_at": None,
                "next_run_at": None,
                "last_run_at": None,
                "last_job_id": None,
                "last_error": None,
                "action_count": len(payload.actions),
                "created_by": payload.created_by,
            }
        ),
        message="Batch schedule saved.",
    )


@router.get("/schedules", response_model=BatchSchedulesListResponse)
async def list_batch_schedules(
    tenant_id: str = Depends(get_verified_tenant_id),
    include_disabled: bool = Query(default=False),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=100, max_limit=500)),
) -> BatchSchedulesListResponse:
    schedules = await orchestrator.list_schedules(_normalize_tenant_id(tenant_id), include_disabled=include_disabled)
    paged_schedules, _total = paginate_items(schedules, pagination)
    return BatchSchedulesListResponse(tenant_id=_normalize_tenant_id(tenant_id), schedules=paged_schedules)


@router.delete("/schedules/{schedule_id}")
async def delete_batch_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> dict[str, Any]:
    removed = await orchestrator.delete_schedule(_normalize_tenant_id(tenant_id), schedule_id)
    if not removed:
        raise HTTPException(status_code=404, detail="Schedule not found")
    return {
        "tenant_id": _normalize_tenant_id(tenant_id),
        "schedule_id": schedule_id,
        "deleted": True,
        "message": "Schedule deleted",
    }


@router.post("/import", response_model=BatchImportResponse, status_code=status.HTTP_201_CREATED)
async def import_batch_jobs(
    payload: BatchImportRequest,
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> BatchImportResponse:
    tenant_id = _normalize_tenant_id(payload.tenant_id)
    try:
        created_jobs = await orchestrator.import_actions_as_jobs(
            tenant_id=tenant_id,
            jobs=payload.jobs,
            requested_by=payload.submitted_by,
        )
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        logger.exception("Batch import failed")
        raise HTTPException(status_code=500, detail="Batch import failed") from error

    return BatchImportResponse(
        tenant_id=tenant_id,
        submitted_by=payload.submitted_by,
        created=len(created_jobs),
        jobs=[job.to_dict(include_results=False) for job in created_jobs],
    )


@router.get("/export", response_model=None)
async def export_batch_jobs(
    tenant_id: str = Depends(get_verified_tenant_id),
    format: str = Query(default="json", pattern=r"^(json|csv)$"),
    include_results: bool = Query(default=False),
    limit: int = Query(default=1000, ge=1, le=5000),
    orchestrator: BatchOrchestrator = Depends(get_orchestrator),
) -> Response | dict[str, Any]:
    payload = await orchestrator.list_jobs(
        tenant_id=_normalize_tenant_id(tenant_id),
        limit=limit,
        include_results=include_results,
    )
    if format == "csv":
        csv_payload = _to_csv(payload.get("jobs", []))
        return Response(
            content=csv_payload,
            media_type="text/csv; charset=utf-8",
            headers={
                "Content-Disposition": f'attachment; filename="batch-jobs-{tenant_id}.csv"',
            },
        )

    return JSONResponse(content=payload)
