"""Canonical Zara API.

This surface is a thin adapter over ZaraTaskExecutor plus a read-only awareness
contract. Workspace-specific guidance still exists for UI suggestions, but task
execution truth lives in the executor rather than a separate Grok or
pattern-matching route.

The module is split into cohesive sub-modules (``models``, ``validation``,
``explain``, ``routines``) and this package root keeps the route handlers plus
the service-lookup stubs that tests patch (``_get_chat_executor``,
``_get_routine_service``, etc.) at their canonical import path
``apps.backend.api.zara``.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import UTC, datetime, timedelta
from typing import Any

import ulid
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from fastapi.responses import StreamingResponse

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.services.canonical_context import as_dict
from apps.backend.services.sourced_recall import get_sourced_recall_service
from apps.backend.services.zara.zara_awareness_service import (
    build_awareness_prompt_fragment,
    get_zara_awareness_service,
)
from apps.backend.services.zara.zara_control_plane import get_zara_control_plane_service
from apps.backend.services.agent_dispatch import AgentDispatchService, get_agent_dispatch_service
from apps.backend.services.zara.factory import (
    build_zara_task_executor,
    get_workspace_suggestion_labels,
    get_workspace_suggestions,
)
from apps.backend.services.zara.service import TaskContext, TaskExecutionResult
from apps.backend.services.zara.zara_topic_threads import get_zara_topic_thread_service

from apps.backend.api.zara.explain import (
    _build_explain_decision,
    _build_scope_boundaries,
    _decision_context_data as _decision_context_data,
    _decision_match_score as _decision_match_score,
    _decision_trace_ids as _decision_trace_ids,
    _decision_workitem_title,
    _expected_workitem_decision_ids,
    _explain_context_summary,
    _explain_coverage_summary,
    _explain_evidence_summary,
    _explain_summary,
    _matched_explain_decisions,
    _workitem_explain_context,
)
from apps.backend.api.zara.models import (
    AwarenessCapabilities,
    AwarenessCapabilityItem,
    AwarenessControlPlane,
    AwarenessProactive,
    AwarenessResponse,
    AwarenessRoutineItem,
    AwarenessRoutines,
    AwarenessRuntime,
    ZaraMeetingSpeakRequest,
    ZaraMeetingSpeakResponse,
    ChatContext,
    ChatMessage,
    ChatRequest,
    ChatResponse,
    CrossEntityQueryRequest,
    CrossEntityQueryResponse,
    DispatchTaskRequest,
    DispatchTaskResponse,
    ExecutePlanRequest,
    ExecutePlanResponse,
    ExecutionCancelResponse,
    ExecutionStatusResponse,
    ExecutionSteerRequest,
    ExecutionSteerResponse,
    ExplainContextSummary,
    ExplainCoverageSummary,
    ExplainDecision,
    ExplainEvidenceSummary,
    ExplainRequest,
    ExplainResponse,
    PlanConnectorInput,
    PlanDetailResponse,
    PlanListItemResponse,
    PlanListResponse,
    PlanMitigationRequest,
    PlanRequest,
    PlanResponse,
    PlanReviseRequest,
    PlanSteerRequest,
    PlanSteerResponse,
    PlanRevisionResponse,
    PlanSkillInput,
    PlanStepResponse,
    RecallRequest,
    RecallResponse,
    SkillCandidateResponse,
    SkillReuseSummary,
    StepResultResponse,
    SuggestionRequest,
    SuggestionResponse,
    SupportTicketRequest,
    SupportTicketResponse,
    VoiceSessionRequest,
    VoiceSessionResponse,
    ZaraActRequest,
    ZaraApproveRequest,
    ZaraApproveResponse,
    ZaraAskRequest,
)
from apps.backend.api.zara.routines import (
    _detect_routine_action as _detect_routine_action_impl,
    _has_explicit_routine_intent,
    _is_routine_query,
    _render_routine_summary,
    _resolve_routine_target,
)
from apps.backend.api.zara.validation import (
    _AGENT_ID_RE as _AGENT_ID_RE,
    _CONVERSATION_ID_RE as _CONVERSATION_ID_RE,
    _TRACE_ID_RE,
    _WORKSPACE_RE as _WORKSPACE_RE,
    _assert_visible_agent,
    _conversation_id,
    _normalize_trace_ids as _normalize_trace_ids,
    _normalize_workspace,
    _resolve_authenticated_user_id,
    _sanitize_prompt_page_url,
    _token_set as _token_set,
    _validate_agent_id as _validate_agent_id,
)

from apps.backend.api.zara.goal_intake import router as goal_intake_router
from apps.backend.services.zara.execution_event_bus import (
    build_execution_event,
    format_sse,
    get_execution_event_bus,
)
from apps.backend.services.zara.plan_store import (
    build_step_diff,
    default_loss_function,
    get_zara_plan_store,
)
from apps.backend.services.zara.context_loader import (
    PriorContextBundle,
    get_zara_prior_context_loader,
)
from apps.backend.services.zara.zara_goal_intake import GoalMode, IntakeCompiler

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara", tags=["zara"])

# Mount the goal-intake sub-router. The sub-router's prefix ("/goal") is
# relative so the final URL becomes ``POST /api/v1/zara/goal/intake`` (#1064).
router.include_router(goal_intake_router)

# Executor cache is keyed by (tenant_id, agent_id) so each agent maintains its
# own memoised Zara executor instance across requests.
_EXECUTOR_CACHE: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Service-lookup stubs — tests patch these via ``patch("apps.backend.api.zara.X")``
# so they must remain importable attributes on this module.
# ---------------------------------------------------------------------------


def _get_workitem_service():
    from apps.backend.services.execution.workitem_service import get_workitem_service

    return get_workitem_service()


def _get_workitem_goal_store():
    from apps.backend.api.goals import _get_goal_store as _factory

    return _factory()


def _get_workitem_task_store():
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


def _get_decision_service():
    from apps.backend.services.context.decision_event_capture import DecisionEventCaptureService

    return DecisionEventCaptureService()


def _get_chat_executor(tenant_id: str, agent_id: str | None = None):
    # ZARA-1: Cache key includes agent_id so each agent gets its own executor
    cache_key = f"{tenant_id}:{agent_id or ''}"
    if cache_key not in _EXECUTOR_CACHE:
        _EXECUTOR_CACHE[cache_key] = build_zara_task_executor(
            tenant_id=tenant_id,
            agent_id=agent_id,
        )
    return _EXECUTOR_CACHE[cache_key]


def _get_routine_service():
    from apps.backend.services.scheduling.routines import get_routine_service

    return get_routine_service()


def _get_schedule_service():
    from apps.backend.services.scheduling.service import get_schedule_service

    return get_schedule_service()


def _get_agent_dispatch_service() -> AgentDispatchService:
    """Stub for tests to patch: ``apps.backend.api.zara._get_agent_dispatch_service``."""
    return get_agent_dispatch_service()


# ---------------------------------------------------------------------------
# Chat-path helpers — kept in this module so tests can patch the service
# lookups they depend on (``_get_schedule_service``, ``_get_routine_service``)
# while preserving the ``apps.backend.api.zara.<symbol>`` attribute contract.
# ---------------------------------------------------------------------------


def _build_recall_response_payload(
    result: dict[str, Any] | None,
    *,
    default_query: str,
    recall_service: Any,
) -> RecallResponse | None:
    if result is None:
        return None

    citations = list(result.get("citations") or [])
    return RecallResponse(
        query=str(result.get("query") or default_query),
        reason_code=str(result.get("reason_code") or "no_match"),
        retrieval_path=str(result.get("retrieval_path") or "unknown"),
        count=int(result.get("count") or len(citations)),
        citations=citations,
        sources=recall_service.render_sources(citations),
    )


def _topic_metadata_payload(binding: Any | None) -> dict[str, Any] | None:
    if binding is None:
        return None
    return {
        "thread_id": str(getattr(binding, "thread_id", "") or ""),
        "topic_key": str(getattr(binding, "topic_key", "") or ""),
        "topic_label": str(getattr(binding, "topic_label", "") or ""),
        "workmemory_session_id": str(getattr(binding, "workmemory_session_id", "") or ""),
        "continuity_match_count": len(list(getattr(binding, "continuity_segments", ()) or ())),
    }


_IDENTITY_CHAT_QUESTIONS = frozenset(
    {
        "who are you",
        "what are you",
        "who is zara",
        "what is zara",
        "what can you do",
    }
)


def _maybe_handle_identity_chat(
    *,
    workspace: str,
    message: str,
    conversation_id: str,
    voice_mode: bool,
) -> ChatResponse | None:
    normalized = re.sub(r"\s+", " ", str(message or "").strip().lower())
    normalized = normalized.strip(" ?!.")
    if normalized not in _IDENTITY_CHAT_QUESTIONS:
        return None
    return ChatResponse(
        message=(
            "I’m Zara, Workweaver’s AI operator. I can answer questions directly, "
            "help you understand your workspace, and, when you ask for action, turn "
            "the goal into governed work with approvals and proof."
        ),
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=False,
        action_type=None,
        metadata={
            "identity_query": True,
            "workspace": workspace,
            "voice_mode": voice_mode,
        },
    )


def _detect_routine_action(message: str) -> str | None:
    """Wrap the routines helper so it resolves ``_get_schedule_service`` from
    this module's globals (preserving ``patch.object(zara, "_get_schedule_service")``).
    """
    return _detect_routine_action_impl(message, _get_schedule_service())


def _maybe_handle_routine_chat(
    *,
    tenant_id: str,
    authenticated_user_id: str,
    workspace: str,
    message: str,
    conversation_id: str,
) -> ChatResponse | None:
    action = _detect_routine_action(message)
    routine_query = _is_routine_query(message)
    routine_service = _get_routine_service()
    routines = routine_service.list_routines(tenant_id)
    audit = routine_service.build_audit_summary(tenant_id)

    if action is None and not routine_query:
        return None

    if action is not None and not _has_explicit_routine_intent(message, routines):
        return None

    if not routines:
        return ChatResponse(
            message="There are no active routines to inspect yet.",
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            metadata={"routine_query": True, "routine_audit": audit},
        )

    if action is None:
        return ChatResponse(
            message=_render_routine_summary(audit, routines),
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            metadata={"routine_query": True, "routine_audit": audit},
        )

    target = _resolve_routine_target(message, routines)
    if target is None:
        return ChatResponse(
            message="I found multiple routines. Name the routine you want to change, like 'pause Morning Brief' or 'resume Weekly Review'.",
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=True,
            action_type="routine_clarification",
            metadata={"routine_query": True, "routine_audit": audit},
        )

    cron_expression = None
    if action == "update_cadence":
        cron_expression = _get_schedule_service().parse_nl_schedule(message)
        if not cron_expression:
            return ChatResponse(
                message="I understood that as a cadence change, but I couldn't parse the new schedule. Try phrasing it like 'every weekday at 9am' or 'daily at 6pm'.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_cadence_clarification",
                metadata={"routine_query": True, "routine_id": target.routine_id},
            )

    try:
        result = routine_service.mutate(
            tenant_id=tenant_id,
            schedule_id=target.routine_id,
            action=action,
            actor_id=authenticated_user_id,
            note=f"Zara chat: {message}",
            recommendation_signature=(
                as_dict(target.optimization).get("recommended_action", {}).get("signature")
                if action == "keep_current_approach"
                else None
            ),
            cron_expression=cron_expression,
        )
    except ValueError as exc:
        detail = str(exc)
        lowered = detail.lower()
        if "revision mismatch" in lowered:
            return ChatResponse(
                message="That routine changed just now. Refresh the schedule state and try again.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_conflict",
                metadata={"routine_query": True, "routine_id": target.routine_id, "error": detail},
            )
        if "not found" in lowered:
            return ChatResponse(
                message="I couldn't find that routine anymore. Refresh the schedule state and try again.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_not_found",
                metadata={"routine_query": True, "routine_id": target.routine_id, "error": detail},
            )
        raise
    routine_name = result.routine.display_name if result.routine is not None else target.display_name
    return ChatResponse(
        message=f"{result.message} {routine_name} is now {result.routine.status if result.routine is not None else 'updated'}.",
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=False,
        action_type=None,
        metadata={
            "routine_query": True,
            "routine_action": action,
            "routine_id": target.routine_id,
            "routine_result": result.model_dump(mode="json"),
        },
    )


def _build_task_context(
    request: ChatRequest,
    *,
    conversation_id: str,
    awareness_snapshot: dict[str, Any] | None = None,
    topic_binding: Any | None = None,
) -> TaskContext:
    workspace = _normalize_workspace(request.context.workspace)
    skill_id = f"{workspace}_{'voice_chat' if request.voice_mode else 'dashboard_chat'}"
    metadata: dict[str, Any] = {
        "workspace": workspace,
        "skill_id": skill_id,
        "page_url": _sanitize_prompt_page_url(request.context.page_url),
        "conversation_id": conversation_id,
        "voice_mode": request.voice_mode,
    }
    topic_payload = _topic_metadata_payload(topic_binding)
    if topic_payload is not None:
        metadata["thread_id"] = topic_payload["thread_id"]
        metadata["topic_thread_id"] = topic_payload["thread_id"]
        metadata["topic_key"] = topic_payload["topic_key"]
        metadata["topic_label"] = topic_payload["topic_label"]
        metadata["workmemory_session_id"] = topic_payload["workmemory_session_id"]
        continuity_prompt = str(getattr(topic_binding, "continuity_prompt", "") or "").strip()
        if continuity_prompt:
            metadata["topic_continuity"] = continuity_prompt
    if awareness_snapshot:
        metadata["awareness_context"] = build_awareness_prompt_fragment(awareness_snapshot)
    return TaskContext(
        category=f"workspace_{workspace}",
        sub_task="voice_chat" if request.voice_mode else "dashboard_chat",
        capability_class=request.context.capability_class,
        metadata=metadata,
    )


def _derive_action(message: str) -> tuple[bool, str | None]:
    lowered = message.lower()
    if "inbox" in lowered:
        return True, "navigate_inbox"
    if "skill" in lowered and any(keyword in lowered for keyword in ("create", "new", "build")):
        return True, "create_skill"
    return False, None


def _render_chat_message(result: TaskExecutionResult) -> str:
    proof = result.proof_of_work or {}
    completed = str(proof.get("completed") or "").strip()
    if completed:
        return completed
    response_text = str(result.response_text or "").strip()
    if response_text:
        return response_text
    if result.degradation_reasons:
        return str(result.degradation_reasons[0].get("message") or "Zara could not complete this request.")
    return "Zara could not complete this request."


def _chat_metadata(
    request: ChatRequest,
    result: TaskExecutionResult,
    awareness_snapshot: dict[str, Any] | None = None,
    control_plane: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata = {
        "workspace": request.context.workspace,
        "voice_mode": request.voice_mode,
        "timestamp": datetime.now(UTC).isoformat(),
        "execution_mode": result.execution_mode,
        "status": result.status,
        "degraded": result.degraded,
        "trace_id": result.trace_id,
        "degradation_reasons": result.degradation_reasons,
    }
    if control_plane:
        metadata["control_plane"] = dict(control_plane)
    if awareness_snapshot:
        metadata["awareness"] = {
            "runtime_status": awareness_snapshot.get("runtime", {}).get("status"),
            "fallback_mode": awareness_snapshot.get("runtime", {}).get("fallback_mode"),
            "connected_integrations": awareness_snapshot.get("runtime", {}).get("connected_integrations", []),
            "capability_mode": awareness_snapshot.get("capabilities", {}).get("mode"),
            "known_limitations": awareness_snapshot.get("known_limitations", []),
        }
    return metadata


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


@router.get("/awareness", response_model=AwarenessResponse)
async def get_awareness(
    workspace: str = Query("home", description="Current workspace"),
    agent_id: str | None = Query(None, description="AI-func-Ops agent ID for agent-specific posture"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AwarenessResponse:
    """Return Zara's current read-only control-plane awareness snapshot."""
    workspace = _normalize_workspace(workspace)
    agent_id = _assert_visible_agent(tenant_id, agent_id)
    awareness = await get_zara_awareness_service().describe(
        tenant_id=tenant_id,
        workspace=workspace,
        agent_id=agent_id,
    )
    return AwarenessResponse(**awareness)


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ChatResponse:
    """Send message to Zara using the canonical executor-of-record.

    Authenticated tenant context is required for this protected route.
    """
    agent_id = _assert_visible_agent(tenant_id, request.context.agent_id)
    workspace = _normalize_workspace(request.context.workspace)
    conversation_id = _conversation_id(request.conversation_id)
    resolved_user_id = _resolve_authenticated_user_id(authenticated_user_id, request.context.user_id)
    if request.context.user_id and resolved_user_id and request.context.user_id != resolved_user_id:
        raise HTTPException(
            status_code=403,
            detail="User ID mismatch between request body and authenticated identity",
        )
    executor = _get_chat_executor(tenant_id, agent_id=agent_id)
    control_plane_service = get_zara_control_plane_service()
    topic_thread_service = get_zara_topic_thread_service()
    principal_session = None
    topic_binding = None
    control_plane_metadata: dict[str, Any] = {"availability": "available", "active_background_missions": 0}
    try:
        principal_session = await control_plane_service.ensure_principal_session(
            tenant_id=tenant_id,
            conversation_id=conversation_id,
            workspace=workspace,
            user_id=resolved_user_id,
            agent_id=agent_id,
        )
    except Exception as exc:
        logger.warning(
            "Zara principal-session persistence unavailable for tenant=%s conversation=%s: %s",
            tenant_id,
            conversation_id,
            exc,
            exc_info=True,
        )
        control_plane_metadata = {
            "availability": "degraded",
            "principal_session_unavailable": True,
            "active_background_missions": 0,
        }
    else:
        control_plane_metadata = {
            **control_plane_metadata,
            "principal_session_id": principal_session.session_id,
        }

    logger.info(
        "Zara chat request tenant=%s workspace=%s message_length=%d voice_mode=%s",
        tenant_id,
        workspace,
        len(request.message),
        request.voice_mode,
    )

    # Org query intercept: if the message is an org-level question, route to
    # the org query service for cross-tool NL answers instead of the executor.
    try:
        from apps.backend.services.org_query_service import get_org_query_service

        org_svc = get_org_query_service()
        if org_svc.is_org_query(request.message):
            org_result = await org_svc.query(tenant_id, request.message)
            return ChatResponse(
                message=org_result.answer,
                conversation_id=conversation_id,
                suggestions=org_result.suggested_followups or get_workspace_suggestion_labels(workspace),
                requires_action=False,
                action_type=None,
                historical_recall=None,
                metadata={"org_query": True, "query_plan": org_result.query_plan},
            )
    except Exception as exc:
        logger.debug("Org query intercept skipped: %s", exc)

    try:
        routine_response = _maybe_handle_routine_chat(
            tenant_id=tenant_id,
            authenticated_user_id=resolved_user_id,
            workspace=workspace,
            message=request.message,
            conversation_id=conversation_id,
        )
        if routine_response is not None:
            return routine_response
    except Exception as exc:
        logger.debug("Routine chat intercept skipped: %s", exc, exc_info=True)

    identity_response = _maybe_handle_identity_chat(
        workspace=workspace,
        message=request.message,
        conversation_id=conversation_id,
        voice_mode=request.voice_mode,
    )
    if identity_response is not None:
        return identity_response

    awareness_snapshot: dict[str, Any] | None = None
    try:
        awareness_snapshot = await get_zara_awareness_service().describe(
            tenant_id=tenant_id,
            workspace=workspace,
            agent_id=agent_id,
        )
    except Exception as exc:
        logger.warning("Zara awareness snapshot unavailable for tenant=%s: %s", tenant_id, exc, exc_info=True)

    try:
        topic_binding = await topic_thread_service.ensure_binding(
            tenant_id=tenant_id,
            conversation_id=conversation_id,
            workspace=workspace,
            user_id=resolved_user_id,
            agent_id=agent_id,
            principal_session_id=str(getattr(principal_session, "session_id", "") or "") or None,
            topic_id=request.context.topic_id,
            topic_label=request.context.topic_label,
            capability_class=request.context.capability_class,
            recall_query=request.message,
        )
    except Exception as exc:
        logger.warning(
            "Zara topic-thread binding unavailable tenant=%s conversation=%s: %s",
            tenant_id,
            conversation_id,
            exc,
            exc_info=True,
        )
        control_plane_metadata["topic_thread_unavailable"] = True

    async def _hydrate_active_background_truth(metadata: dict[str, Any]) -> dict[str, Any]:
        if principal_session is None:
            return metadata
        try:
            active_background_runs = await control_plane_service.active_background_runs(
                tenant_id,
                principal_session.session_id,
            )
        except Exception as exc:
            logger.warning(
                "Zara background-run discovery unavailable for tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
            return {
                **metadata,
                "availability": "degraded",
                "principal_session_id": principal_session.session_id,
                "background_run_discovery_unavailable": True,
                "active_background_missions": 0,
            }

        hydrated_metadata = {
            **metadata,
            "principal_session_id": principal_session.session_id,
            "active_background_missions": len(active_background_runs),
        }
        if active_background_runs:
            hydrated_metadata["active_run_id"] = active_background_runs[0]["run_id"]
        else:
            hydrated_metadata.pop("active_run_id", None)
        return hydrated_metadata

    control_response = None
    if principal_session is not None:
        try:
            control_response = await control_plane_service.handle_chat_message(
                tenant_id=tenant_id,
                principal_session=principal_session,
                conversation_id=conversation_id,
                workspace=workspace,
                user_id=resolved_user_id,
                agent_id=agent_id,
                message=request.message,
            )
        except Exception as exc:
            logger.warning(
                "Zara control-plane handling unavailable for tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
            control_plane_metadata = {
                **control_plane_metadata,
                "availability": "degraded",
                "principal_session_id": principal_session.session_id,
                "control_plane_handling_unavailable": True,
                "active_background_missions": 0,
            }
        else:
            control_plane_metadata = {
                **control_plane_metadata,
                "principal_session_id": principal_session.session_id,
            }
    if control_response is not None:
        control_plane_metadata = await _hydrate_active_background_truth(control_plane_metadata)
        control_response_metadata = dict(control_response.get("metadata") or {})
        metadata = {
            # Canonical request/system fields must win over adapter-provided metadata.
            **control_response_metadata,
            "workspace": request.context.workspace,
            "voice_mode": request.voice_mode,
            "timestamp": datetime.now(UTC).isoformat(),
            "control_plane": {
                **dict(control_plane_metadata),
                **dict(control_response_metadata.get("control_plane") or {}),
            },
        }
        if awareness_snapshot:
            metadata["awareness"] = {
                "runtime_status": awareness_snapshot.get("runtime", {}).get("status"),
                "fallback_mode": awareness_snapshot.get("runtime", {}).get("fallback_mode"),
                "connected_integrations": awareness_snapshot.get("runtime", {}).get("connected_integrations", []),
                "capability_mode": awareness_snapshot.get("capabilities", {}).get("mode"),
                "known_limitations": awareness_snapshot.get("known_limitations", []),
            }
        topic_payload = _topic_metadata_payload(topic_binding)
        if topic_payload is not None:
            metadata["topic_thread"] = topic_payload
            try:
                await topic_thread_service.record_turn(
                    tenant_id=tenant_id,
                    binding=topic_binding,
                    workspace=workspace,
                    user_message=request.message,
                    assistant_message=str(control_response.get("message") or "").strip(),
                )
            except Exception as exc:
                logger.warning(
                    "Zara topic-thread control response persistence failed tenant=%s conversation=%s: %s",
                    tenant_id,
                    conversation_id,
                    exc,
                    exc_info=True,
                )
        return ChatResponse(
            message=str(control_response.get("message") or "").strip(),
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            historical_recall=None,
            metadata=metadata,
        )

    if principal_session is not None:
        control_plane_metadata = await _hydrate_active_background_truth(control_plane_metadata)

    try:
        result = await executor.execute_task(
            task_description=request.message,
            task_context=_build_task_context(
                request,
                conversation_id=conversation_id,
                awareness_snapshot=awareness_snapshot,
                topic_binding=topic_binding,
            ),
            session_id=conversation_id,
            user_id=resolved_user_id,
        )
    except Exception as exc:
        logger.error("Canonical Zara executor failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable. Please try again.")

    if result.status == "failed":
        detail = _render_chat_message(result)
        raise HTTPException(status_code=503, detail=detail)

    rendered_message = _render_chat_message(result)
    metadata = _chat_metadata(
        request,
        result,
        awareness_snapshot=awareness_snapshot,
        control_plane=control_plane_metadata,
    )
    topic_payload = _topic_metadata_payload(topic_binding)
    if topic_payload is not None:
        metadata["topic_thread"] = topic_payload
    recall_service = get_sourced_recall_service()
    sourced_recall = None
    should_cite = recall_service.should_cite(request.message)
    if should_cite:
        try:
            sourced_recall = await recall_service.recall_with_envelopes(
                tenant_id=tenant_id,
                query=request.message,
                limit=3,
            )
        except Exception as exc:
            logger.warning("Historical recall citation lookup failed: %s", exc, exc_info=True)
    historical_recall = _build_recall_response_payload(
        sourced_recall,
        default_query=request.message,
        recall_service=recall_service,
    )
    citations = list(historical_recall.citations) if historical_recall is not None else []
    if historical_recall and historical_recall.citations:
        rendered_message = f"{rendered_message}\n\nSources:\n{historical_recall.sources}"
        metadata["historical_recall"] = historical_recall.model_dump()
    if topic_binding is not None:
        try:
            await topic_thread_service.record_turn(
                tenant_id=tenant_id,
                binding=topic_binding,
                workspace=workspace,
                user_message=request.message,
                assistant_message=rendered_message,
                citations=citations,
            )
        except Exception as exc:
            logger.warning(
                "Zara topic-thread persistence failed tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
    requires_action, action_type = _derive_action(request.message)
    return ChatResponse(
        message=rendered_message,
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=requires_action,
        action_type=action_type,
        historical_recall=historical_recall,
        metadata=metadata,
    )


@router.post("/suggestions", response_model=SuggestionResponse)
async def get_suggestions(
    request: SuggestionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SuggestionResponse:
    """Get workspace-specific suggestions."""
    try:
        workspace = _normalize_workspace(request.context.workspace)
        suggestions = get_workspace_suggestions(workspace)
        logger.info("Retrieved %d suggestions for tenant=%s workspace=%s", len(suggestions), tenant_id, workspace)
        return SuggestionResponse(suggestions=suggestions)
    except Exception as exc:
        logger.error("Error getting Zara suggestions: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get suggestions")


@router.post("/recall", response_model=RecallResponse)
async def recall(
    request: RecallRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> RecallResponse:
    """Return cited historical recall from the canonical memory path."""
    recall_service = get_sourced_recall_service()
    try:
        result = await recall_service.recall_with_envelopes(
            tenant_id=tenant_id,
            query=request.query,
            limit=request.limit,
        )
    except Exception as exc:
        logger.error(
            "Zara cited recall failed tenant=%s user=%s: %s",
            tenant_id,
            authenticated_user_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")

    return _build_recall_response_payload(
        result,
        default_query=request.query,
        recall_service=recall_service,
    ) or RecallResponse(
        query=request.query,
        reason_code="no_match",
        retrieval_path="unknown",
        count=0,
        citations=[],
        sources="",
    )


@router.post("/explain", response_model=ExplainResponse)
async def explain(
    request: ExplainRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExplainResponse:
    """Return canonical decision-trace explainability for a WorkItem."""
    workitem_service = _get_workitem_service()
    goal_store = _get_workitem_goal_store()
    task_store = _get_workitem_task_store()

    try:
        item = workitem_service.get_work_item(
            tenant_id=tenant_id,
            item_id=request.workitem_id,
            goal_store=goal_store,
            task_store=task_store,
        )
    except Exception as exc:
        logger.error("Failed to load WorkItem for Zara explain tenant=%s: %s", tenant_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to load WorkItem")
    if item is None:
        raise HTTPException(status_code=404, detail="WorkItem not found")

    try:
        evidence_bundle = workitem_service.get_work_item_detail_bundle(
            tenant_id=tenant_id,
            item_id=request.workitem_id,
            goal_store=goal_store,
            task_store=task_store,
        ) or {"overview": item}
    except Exception as exc:
        logger.error(
            "Failed to load WorkItem detail bundle for Zara explain tenant=%s workitem=%s: %s",
            tenant_id,
            request.workitem_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail="Failed to load WorkItem detail bundle")

    workitem_title = _decision_workitem_title(evidence_bundle) or str(item.get("title") or request.workitem_id).strip()
    expected_trace_ids = _expected_workitem_decision_ids(evidence_bundle)
    explain_context = _workitem_explain_context(item, evidence_bundle)

    decision_service = _get_decision_service()
    decision_lookup_limit = min(max(request.max_decisions * 25, 200), 500)
    tenant_decisions = list(
        decision_service.list_decisions(
            tenant_id=tenant_id,
            limit=decision_lookup_limit,
        )
    )
    indexed_decisions = {
        str(getattr(decision, "trace_id", "")).strip(): decision
        for decision in tenant_decisions
        if str(getattr(decision, "trace_id", "")).strip()
    }

    for trace_id in expected_trace_ids:
        if trace_id in indexed_decisions or not _TRACE_ID_RE.fullmatch(trace_id):
            continue
        decision = decision_service.get_decision(tenant_id=tenant_id, trace_id=trace_id)
        if decision is None:
            continue
        indexed_decisions[trace_id] = decision
        tenant_decisions.append(decision)

    matched_decisions, contextual_match_count = _matched_explain_decisions(
        tenant_decisions,
        expected_trace_ids=expected_trace_ids,
        explain_context=explain_context,
    )
    found_trace_ids = {
        str(getattr(decision, "trace_id", "")).strip()
        for decision in matched_decisions
        if str(getattr(decision, "trace_id", "")).strip()
    }
    missing_decision_ids = [trace_id for trace_id in expected_trace_ids if trace_id not in found_trace_ids]
    selected_decisions = matched_decisions[: request.max_decisions]

    return ExplainResponse(
        workitem_id=request.workitem_id,
        workitem_title=workitem_title,
        summary=_explain_summary(
            workitem_title=workitem_title,
            decision_count=len(selected_decisions),
            missing_decision_ids=missing_decision_ids,
        ),
        decision_count=len(selected_decisions),
        explainable=bool(selected_decisions),
        decisions=[
            _build_explain_decision(decision, include_trace_urls=request.include_trace_urls)
            for decision in selected_decisions
        ],
        missing_decision_ids=missing_decision_ids,
        context=_explain_context_summary(explain_context),
        evidence=_explain_evidence_summary(
            evidence_bundle,
            expected_trace_ids=expected_trace_ids,
            selected_decisions=selected_decisions,
        ),
        coverage=_explain_coverage_summary(
            expected_trace_ids=expected_trace_ids,
            missing_decision_ids=missing_decision_ids,
            contextual_match_count=contextual_match_count,
            matched_decisions=matched_decisions,
            selected_decisions=selected_decisions,
        ),
        scope_boundaries=_build_scope_boundaries(explain_context, workitem_title),
        metadata={
            "expected_decision_count": len(expected_trace_ids),
            "matched_context_decision_count": contextual_match_count,
            "decision_lookup_limit": decision_lookup_limit,
            "thread_id": str(explain_context.get("thread_id") or ""),
            "mission_refs": list(explain_context.get("mission_refs") or []),
            "workitem_ids": list(explain_context.get("workitem_ids") or []),
            "truncated_decision_count": max(len(matched_decisions) - len(selected_decisions), 0),
        },
    )


@router.post("/voice/session-token", response_model=VoiceSessionResponse)
async def create_voice_session_token(
    request: VoiceSessionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> VoiceSessionResponse:
    """Create a voice session token for authenticated Zara voice access."""
    agent_id = _assert_visible_agent(tenant_id, request.agent_id)
    resolved_user_id = str(request.user_id or authenticated_user_id or "").strip()
    if str(request.user_id or "").strip() and request.user_id != authenticated_user_id:
        raise HTTPException(
            status_code=403,
            detail="User ID mismatch between request body and authenticated identity",
        )
    if not resolved_user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    try:
        livekit_url = os.getenv("LIVEKIT_URL", "wss://workweaver.livekit.cloud")
        livekit_api_key = os.getenv("LIVEKIT_API_KEY", "")
        livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "")

        if not livekit_api_key or not livekit_api_secret:
            raise HTTPException(
                status_code=503,
                detail="Voice service not configured (LIVEKIT_API_KEY/SECRET missing)",
            )

        import json as _json
        import time as _time

        room_name = f"zara-{tenant_id}-{resolved_user_id}-{int(_time.time())}"
        ttl = 3600

        from livekit.api import AccessToken, VideoGrants

        metadata_dict_voice: dict[str, Any] = {
            "tenant_id": tenant_id,
            "session_type": request.session_type,
        }
        # ZARA-5: Propagate agent_id into voice session metadata
        if agent_id:
            metadata_dict_voice["agent_id"] = agent_id
        metadata = _json.dumps(metadata_dict_voice)

        token = (
            AccessToken(livekit_api_key, livekit_api_secret)
            .with_identity(resolved_user_id)
            .with_grants(VideoGrants(room_join=True, room=room_name))
            .with_metadata(metadata)
            .with_ttl(timedelta(seconds=ttl))
        )

        logger.info("Voice session token created room=%s tenant=%s user=%s", room_name, tenant_id, resolved_user_id)
        return VoiceSessionResponse(
            session_token=token.to_jwt(),
            livekit_url=livekit_url,
            room_name=room_name,
            expires_in=ttl,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to create Zara voice session token: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to create voice session")


@router.get("/health")
async def health_check() -> dict[str, str]:
    """Health check for Zara chat service."""
    return {
        "status": "healthy",
        "service": "zara-chat",
        "timestamp": datetime.now(UTC).isoformat(),
    }


# ---------------------------------------------------------------------------
# PR-16: Zara Awareness Rationalization - orchestration endpoints
# ---------------------------------------------------------------------------


@router.post("/query", response_model=CrossEntityQueryResponse)
async def cross_entity_query(
    request: CrossEntityQueryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CrossEntityQueryResponse:
    """Ask Zara what entities have been doing.

    Zara synthesises an answer from their evidence trails.  She is NOT an
    entity herself - she routes the query to the correct AI worker role.
    """
    try:
        result = await get_zara_awareness_service().cross_entity_query(
            tenant_id=tenant_id,
            query=request.query,
        )
    except Exception as exc:
        logger.error("Zara cross-entity query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return CrossEntityQueryResponse(**result)


@router.post("/dispatch", response_model=DispatchTaskResponse)
async def dispatch_to_entity(
    request: DispatchTaskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DispatchTaskResponse:
    """Route a task to the entity whose capabilities match the task type.

    Zara identifies the correct AI worker role and returns the routing decision.
    Actual execution is the caller's responsibility (fire-and-forget or SQS).
    """
    task_payload: dict[str, Any] = {
        "type": request.type,
        "description": request.description or "",
        "metadata": request.metadata,
    }
    try:
        result = await get_zara_awareness_service().dispatch_to_entity(
            tenant_id=tenant_id,
            task=task_payload,
        )
    except Exception as exc:
        logger.error("Zara dispatch failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return DispatchTaskResponse(**result)


@router.post("/support-ticket", response_model=SupportTicketResponse)
async def create_support_ticket(
    request: SupportTicketRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SupportTicketResponse:
    """Auto-create a support ticket via Zara for troubleshooting.

    Zara assigns a unique ticket ID and returns a structured record.
    """
    issue = {"summary": request.summary, "steps": request.steps}
    try:
        result = await get_zara_awareness_service().create_support_ticket(
            tenant_id=tenant_id,
            issue=issue,
        )
    except Exception as exc:
        logger.error("Zara support ticket creation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return SupportTicketResponse(**result)


# ── Zara Verb Routes (Phase 1 — Shell Parity) ─────────────────────────────────
# Spec: "Zara can ask, act, explain, simulate, and approve."
# These thin wrappers collapse into the canonical /chat + judgment feed paths
# so that callers can declare intent explicitly without new surface areas.
# See docs/PRODUCT.md §Zara, Phase 1 milestone.


@router.post("/ask", response_model=ChatResponse)
async def zara_ask(
    request: ZaraAskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ChatResponse:
    """Explicit ask intent — delegates to /chat with intent=ask in metadata.

    Equivalent to POST /chat; exposes verb intent for callers that need to
    declare ask vs act vs approve explicitly without building a fourth surface.
    """
    chat_request = ChatRequest(
        message=request.message,
        context=request.context,
        conversation_id=request.conversation_id,
        voice_mode=False,
    )
    response = await chat(chat_request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id)
    response.metadata["zara_intent"] = "ask"
    return response


@router.post("/act", response_model=DispatchTaskResponse)
async def zara_act(
    request: ZaraActRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DispatchTaskResponse:
    """Explicit act intent — delegates to /dispatch with intent=act in metadata.

    Equivalent to POST /dispatch; surfaces the act verb for callers that
    declare intent explicitly (e.g. Zara voice commands: "Zara, act on task X").
    """
    dispatch_request = DispatchTaskRequest(
        type=request.type,
        description=request.description,
        metadata={**request.metadata, "zara_intent": "act"},
    )
    return await dispatch_to_entity(dispatch_request, tenant_id=tenant_id)


@router.post("/approve", response_model=ZaraApproveResponse)
async def zara_approve(
    request: ZaraApproveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ZaraApproveResponse:
    """Approve a pending Inbox judgment via Zara — the judgment-feed approve verb.

    Routes to the canonical human-judgment service so that Zara's approve
    command and the Inbox UI approval share a single code path.
    This is the closing piece of: escalation → judgment → policy reduction loop.
    """
    from apps.backend.services.approval_gates import get_approval_gates
    from apps.backend.services.approval_service import ApprovalService
    from apps.backend.services.human_judgment_service import HumanJudgmentService

    def _build_judgment_svc() -> HumanJudgmentService:
        gates = get_approval_gates()
        return HumanJudgmentService(
            approval_service=ApprovalService(approval_gates=gates),
            approval_gates=gates,
        )

    # For approve_pattern actions the caller may supply only pattern_id (no request_id).
    # Fall back to pattern_id as the effective request identifier.
    effective_request_id = request.request_id or request.pattern_id or ""

    try:
        svc = _build_judgment_svc()
        await svc.approve_request(
            tenant_id=tenant_id,
            request_id=effective_request_id,
            actor_id=authenticated_user_id,
            reason=request.reason,
            modified_params=request.modified_params,
            source="zara_approve_verb",
        )
    except Exception as exc:
        logger.error(
            "Zara /approve failed for tenant=%s request_id=%s: %s",
            tenant_id,
            effective_request_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=503, detail="Approval could not be processed.")

    return ZaraApproveResponse(
        success=True,
        message="approved",
        request_id=effective_request_id,
        action=request.action,
    )


# ---------------------------------------------------------------------------
# Plan generation + execution endpoints (Issue #1092)
# ---------------------------------------------------------------------------


def _model_to_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if hasattr(value, "dict"):
        return value.dict()
    return dict(value or {})


def _plan_steps_to_dicts(steps: list[Any]) -> list[dict[str, Any]]:
    return [_model_to_dict(step) for step in steps]


def _plan_step_id(step: dict[str, Any], index: int) -> str:
    return str(step.get("id") or step.get("step_id") or f"step_{index + 1}")


def _latest_step_for_id(
    *,
    tenant_id: str,
    plan_id: str,
    step_id: str,
    fallback: dict[str, Any],
) -> dict[str, Any]:
    record = get_zara_plan_store().get_plan(tenant_id, plan_id) if plan_id else None
    for idx, candidate in enumerate(_plan_steps_to_dicts((record or {}).get("steps") or [])):
        if _plan_step_id(candidate, idx) == step_id:
            return candidate
    return fallback


def _started_execution_step_ids(record: dict[str, Any]) -> set[str]:
    started: set[str] = set()
    for event in record.get("events") or []:
        event_type = str(event.get("type") or "")
        step_id = str(event.get("step_id") or "")
        if step_id and event_type.startswith("step."):
            started.add(step_id)
    return started


async def _revise_plan_record(
    *,
    tenant_id: str,
    plan_id: str,
    instruction: str,
    locked_step_ids: set[str] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise KeyError(f"plan not found: {plan_id}")
    svc = build_zara_task_executor(tenant_id=tenant_id)
    revised = await svc.revise_plan(current, instruction)
    previous_steps = _plan_steps_to_dicts(current.get("steps") or [])
    revised_steps = _plan_steps_to_dicts(revised.get("steps") or [])
    locked = locked_step_ids or set()
    if locked:
        previous_by_id = {_plan_step_id(step, idx): step for idx, step in enumerate(previous_steps)}
        revised_steps = [
            previous_by_id.get(_plan_step_id(step, idx), step) if _plan_step_id(step, idx) in locked else step
            for idx, step in enumerate(revised_steps)
        ]
    diff = build_step_diff(previous_steps, revised_steps)
    record = store.save_revision(
        tenant_id=tenant_id,
        plan_id=plan_id,
        steps=revised_steps,
        instruction=instruction,
        diff=diff,
        summary=str(revised.get("summary") or current.get("summary") or ""),
    )
    return record, diff


def _plan_response_from_record(record: dict[str, Any], *, diff: list[dict[str, Any]] | None = None) -> PlanResponse:
    raw_srs = record.get("skill_reuse_summary") or {}
    if isinstance(raw_srs, dict):
        skill_reuse_summary = SkillReuseSummary(
            matched_skills=list(raw_srs.get("matched_skills") or []),
            matched_entity_schemas=list(raw_srs.get("matched_entity_schemas") or []),
            matched_entity_records=list(raw_srs.get("matched_entity_records") or []),
            ontology_consulted=bool(raw_srs.get("ontology_consulted", True)),
            decision=str(raw_srs.get("decision") or "new"),
        )
    else:
        skill_reuse_summary = SkillReuseSummary()
    return PlanResponse(
        plan_id=str(record.get("plan_id") or ""),
        goal=str(record.get("goal") or ""),
        summary=str(record.get("summary") or ""),
        planner_mode=str(record.get("planner_mode") or "self_organizing_emergent"),
        steps=record.get("steps") or [],
        loss_function=record.get("loss_function") or default_loss_function(),
        revision=int(record.get("latest_rev") or record.get("revision") or 1),
        status=str(record.get("status") or "active"),
        diff=list(diff or []),
        sensitivity=str(record.get("sensitivity") or "low"),
        gate_flags=dict(record.get("gate_flags") or {}),
        inverter=dict(record.get("inverter") or {}),
        swarm_planner=dict(record.get("swarm_planner") or {}),
        prior_context_refs=list(record.get("prior_context_refs") or []),
        alternatives_considered=list(record.get("alternatives_considered") or []),
        effort_policy=dict(record.get("effort_policy") or {}),
        created_at=record.get("created_at"),
        updated_at=record.get("updated_at"),
        skill_reuse_summary=skill_reuse_summary,
    )


def _execution_response_from_record(record: dict[str, Any]) -> ExecutionStatusResponse:
    return ExecutionStatusResponse(
        execution_id=str(record.get("execution_id") or ""),
        plan_id=str(record.get("plan_id") or ""),
        plan_rev=int(record.get("plan_rev") or 1),
        status=str(record.get("status") or "unknown"),
        events=record.get("events") or [],
        steers=record.get("steers") or [],
        created_at=record.get("created_at"),
        updated_at=record.get("updated_at"),
        completed_at=record.get("completed_at"),
    )


def _plan_list_item(record: dict[str, Any]) -> PlanListItemResponse:
    return PlanListItemResponse(
        plan_id=str(record.get("plan_id") or ""),
        goal=str(record.get("goal") or ""),
        status=str(record.get("status") or "active"),
        latest_rev=int(record.get("latest_rev") or 1),
        latest_execution_id=record.get("latest_execution_id"),
        created_at=record.get("created_at"),
        completed_at=record.get("completed_at"),
        loss_score=record.get("loss_score"),
    )


def _record_execution_event(
    *,
    tenant_id: str,
    event: dict[str, Any],
) -> None:
    execution_id = str(event.get("execution_id") or "")
    if not execution_id:
        return
    store = get_zara_plan_store()
    store.append_execution_event(tenant_id=tenant_id, execution_id=execution_id, event=event)
    try:
        get_execution_event_bus().publish(event)
    except Exception:
        logger.warning("Zara execution SSE publish failed after durable append", exc_info=True)


def _log_background_execution_failure(task: asyncio.Task[Any]) -> None:
    try:
        exc = task.exception()
    except asyncio.CancelledError:
        return
    if exc is not None:
        logger.error(
            "Zara plan execution background task failed",
            exc_info=(type(exc), exc, exc.__traceback__),
        )


async def _reply_to_slack_execution_origin(
    *,
    tenant_id: str,
    execution_id: str,
    plan_id: str,
    status: str,
    context: dict[str, Any],
    error: str | None = None,
) -> None:
    slack_workspace_id = str(context.get("slack_workspace_id") or "").strip()
    channel = str(context.get("slack_channel") or "").strip()
    thread_ts = str(context.get("slack_thread_ts") or "").strip()
    decision_trace_id = str(context.get("decision_trace_id") or "").strip()
    if not (slack_workspace_id and channel and thread_ts):
        return
    try:
        from apps.backend.services.zara.zara_intake_service import SlackConnectorThread

        suffix = f" Error: {error}" if error else " Skillify will review this run for reusable skill candidates."
        trace = (
            f" Decision Trace: /api/v1/evidence/decisions/{decision_trace_id}"
            if decision_trace_id
            else ""
        )
        await SlackConnectorThread().reply(
            workspace_id=tenant_id,
            slack_workspace_id=slack_workspace_id,
            channel=channel,
            thread_ts=thread_ts,
            text=(
                f"Zara execution `{execution_id}` for plan `{plan_id}` finished with status `{status}`."
                f"{suffix}{trace}"
            ),
        )
    except Exception:
        logger.warning("zara.execution.slack_origin_reply_failed execution_id=%s", execution_id, exc_info=True)


async def _run_plan_execution(
    *,
    tenant_id: str,
    execution_id: str,
    plan: dict[str, Any],
    context: dict[str, Any],
) -> None:
    from apps.backend.services.dag_executor import DAGExecution, DAGExecutor, DAGStep

    store = get_zara_plan_store()
    bus = get_execution_event_bus()
    bus.register_execution(execution_id)
    plan_id = str(plan.get("plan_id") or "")
    store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status="running")
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.started",
            execution_id=execution_id,
            plan_id=plan_id,
            message="Execution started",
        ),
    )

    plan_revision = int(plan.get("latest_rev") or plan.get("revision") or 1)

    def _make_step_executor(step: dict[str, Any], step_id: str) -> Any:
        async def _exec(_ctx: dict[str, Any]) -> dict[str, Any]:
            if bus.is_cancelled(execution_id):
                raise RuntimeError("execution cancelled")
            effective_step = _latest_step_for_id(
                tenant_id=tenant_id,
                plan_id=plan_id,
                step_id=step_id,
                fallback=step,
            )
            _record_execution_event(
                tenant_id=tenant_id,
                event=build_execution_event(
                    "step.started",
                    execution_id=execution_id,
                    plan_id=plan_id,
                    step_id=step_id,
                    message=str(effective_step.get("name") or step_id),
                    payload={"step": effective_step},
                ),
            )
            try:
                task_description = (
                    f"Execute {effective_step.get('action') or effective_step.get('name') or step_id}"
                    f" using {effective_step.get('connector_or_skill') or 'Zara'}"
                )
                if effective_step.get("inputs"):
                    task_description += f" with inputs: {effective_step.get('inputs')}"

                # Idempotency key: (tenant_id, plan_id, plan_revision, attempt_id)
                # step_id is already unique within a plan; combine with revision for retry-safety.
                attempt_id = f"{step_id}#rev{plan_revision}"
                dispatch_svc = _get_agent_dispatch_service()
                target_agent_id = (
                    str(effective_step.get("target_agent_id") or effective_step.get("connector_or_skill") or "zara")
                )
                dispatched = dispatch_svc.dispatch_swarm_task(
                    tenant_id=tenant_id,
                    target_agent_id=target_agent_id,
                    swarm_id=execution_id,
                    task=task_description,
                    execution_id=execution_id,
                    step_id=step_id,
                    dependencies=list(effective_step.get("depends_on") or []),
                    skill_id=str(effective_step.get("connector_or_skill") or "") or None,
                    inputs=dict(effective_step.get("inputs") or {}),
                    dispatch_kind="step",
                    attempt=1,
                )

                # Emit evidence:plan_dispatched_to_swarm per step (replaces evidence:zara_executed_step).
                try:
                    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

                    get_evidence_ledger_service().ingest(
                        tenant_id=tenant_id,
                        event_type="evidence:plan_dispatched_to_swarm",
                        data={
                            "execution_id": execution_id,
                            "plan_id": plan_id,
                            "plan_revision": plan_revision,
                            "step_id": step_id,
                            "attempt_id": attempt_id,
                            "target_agent_id": target_agent_id,
                            "dispatched": dispatched,
                        },
                        actor_path="zara.execute_plan._dispatch_step",
                    )
                except Exception:
                    logger.warning("zara.execute_plan.dispatch_evidence_failed step=%s", step_id, exc_info=True)

                # Fail fast if the queue refused the dispatch (unconfigured or at capacity).
                if not dispatched:
                    raise RuntimeError(
                        f"AgentDispatchService refused step {step_id} dispatch"
                        f" (dispatched=False; check queue availability)"
                    )

                # From Zara's perspective the step is complete once it has been handed off to
                # the swarm.  The swarm worker's progress is tracked independently by
                # SwarmScheduler.record_step_result.  Recording step.completed here closes
                # the DAGExecutor loop so that the overall execution can advance to the next
                # step (or mark the plan complete) without polling a surface that the swarm
                # worker does not write back to.
                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.completed",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message="Step dispatched to swarm",
                        payload={"dispatched": dispatched, "attempt_id": attempt_id},
                    ),
                )
                return {"status": "dispatched", "output": {"attempt_id": attempt_id}}

            except RuntimeError as exc:
                if str(exc) != "execution cancelled":
                    raise
                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.cancelled",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message="Step cancelled",
                    ),
                )
                raise
            except Exception as exc:
                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.failed",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message=str(exc),
                    ),
                )
                raise

        return _exec

    steps = _plan_steps_to_dicts(plan.get("steps") or [])
    dag_steps = []
    for idx, step in enumerate(steps):
        step_id = _plan_step_id(step, idx)
        dag_steps.append(
            DAGStep(
                id=step_id,
                name=str(step.get("name") or step_id),
                execute_fn=_make_step_executor(step, step_id),
                depends_on=list(step.get("depends_on") or []),
                timeout_seconds=max(int(step.get("estimated_duration_seconds") or 60), 30),
            )
        )
    try:
        result = await DAGExecutor().execute(
            DAGExecution(id=execution_id, steps=dag_steps, context={"tenant_id": tenant_id, **context}),
            interrupt_token=bus.get_interrupt_token(execution_id),
        )
        cancelled = bus.is_cancelled(execution_id) or result.status == "interrupted"
        final_status = "cancelled" if cancelled else result.status
        event_type = (
            "execution.cancelled"
            if cancelled
            else ("execution.completed" if result.status == "completed" else "execution.failed")
        )
        store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status=final_status)
        store.update_plan_status(
            tenant_id=tenant_id,
            plan_id=plan_id,
            status="cancelled" if cancelled else ("completed" if result.status == "completed" else "failed"),
            latest_execution_id=execution_id,
            loss_score=0.0 if result.status == "completed" else None,
        )
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                event_type,
                execution_id=execution_id,
                plan_id=plan_id,
                message=f"Execution {final_status}",
                payload={
                    "status": result.status,
                    "step_results": {
                        step_id: {
                            "status": step_result.status.value
                            if hasattr(step_result.status, "value")
                            else str(step_result.status),
                            "output": step_result.output,
                            "error": step_result.error,
                        }
                        for step_id, step_result in result.results.items()
                    },
                },
            ),
        )
        await _reply_to_slack_execution_origin(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan_id=plan_id,
            status=final_status,
            context=context,
        )
    except Exception as exc:
        logger.error("Zara plan execution failed: %s", exc, exc_info=True)
        store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status="failed")
        if plan_id:
            store.update_plan_status(
                tenant_id=tenant_id,
                plan_id=plan_id,
                status="failed",
                latest_execution_id=execution_id,
            )
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                "execution.failed",
                execution_id=execution_id,
                plan_id=plan_id,
                message=str(exc),
            ),
        )
        await _reply_to_slack_execution_origin(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan_id=plan_id,
            status="failed",
            context=context,
            error=str(exc),
        )


@router.post("/plan", response_model=PlanResponse)
async def generate_plan(
    request: PlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    """Generate a DAG execution plan from a business goal.

    Uses LLM-powered decomposition to produce a structured plan
    with dependency tracking and parallel branch identification.

    When ``request.intake_result`` is not supplied AND ``request.skills`` is
    empty AND the caller has not flagged ``context.intake_skipped``, this
    handler invokes ``IntakeCompiler.compile()`` implicitly and uses the
    result to populate skills, loss function, and composition metadata
    (Behaviour 3 — skill-reuse-first; Behaviour 4 — sophisticated planning).
    """
    from services.planning.engine import (
        ConnectorSpec,
        GeneratedPlan,
        PlanGenerationEngine,
        PlanStepSpec,
        SkillSpec,
    )
    from apps.backend.services.planning.effort_policy import PlanEffortPolicy
    from apps.backend.services.planning.sensitivity_classifier import SensitivityClassifier
    from apps.backend.services.planning.planner_mode import resolve_planner_mode
    from apps.backend.services.tenant_config import get_tenant_config
    from apps.backend.services.zara.inverter_agent import InverterAgent
    from apps.backend.services.zara.role_agent_runtime import invoke_role_llm
    from apps.backend.services.zara.swarm_planner_agent import SwarmPlannerAgent
    connectors = [
        ConnectorSpec(
            id=c.id,
            name=c.name,
            actions=c.actions,
            description=c.description,
        )
        for c in request.connectors
    ]
    skills = [
        SkillSpec(
            id=s.id,
            name=s.name,
            description=s.description,
            inputs=s.inputs,
            outputs=s.outputs,
        )
        for s in request.skills
    ]

    svc_for_roles = build_zara_task_executor(tenant_id=tenant_id)

    # Build the LLM callable from the Zara executor's chat completion path
    async def _llm_fn(system_prompt: str, user_prompt: str) -> str:
        try:
            return await invoke_role_llm(
                svc_for_roles.llm_client,
                model="zara-role-default",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
        except Exception as exc:
            logger.error("Plan generation LLM call failed: %s", exc, exc_info=True)
            raise HTTPException(status_code=503, detail="Plan generation failed") from exc

    engine = PlanGenerationEngine(llm_fn=_llm_fn)
    plan_ctx = dict(request.context)
    plan_ctx["tenant_id"] = tenant_id
    agent_id = str(
        plan_ctx.get("agent_id")
        or plan_ctx.get("actor_id")
        or plan_ctx.get("zara_agent_id")
        or plan_ctx.get("assignee_id")
        or ""
    ).strip()
    try:
        planner_mode = resolve_planner_mode(tenant_id, request.planner_mode, agent_id=agent_id or None)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    plan_ctx["planner_mode"] = planner_mode.value
    prior_context_bundle = PriorContextBundle.empty()
    try:
        prior_context_bundle = await get_zara_prior_context_loader().load(
            workspace_id=tenant_id,
            mission_topic=request.goal,
            selected_skill_ids=[skill.id for skill in skills],
        )
        plan_ctx["prior_context"] = prior_context_bundle.to_planner_context()
        plan_ctx["prior_context_refs"] = list(prior_context_bundle.prior_context_refs)
    except Exception:
        logger.warning(
            "generate_plan: prior context loading failed tenant=%s goal=%r",
            tenant_id,
            request.goal[:80],
            exc_info=True,
        )

    try:
        from apps.backend.services.skillify import SkillifyService

        skillify_guidance = SkillifyService().planning_guidance_for_goal(tenant_id, request.goal)
        if skillify_guidance["positive"] or skillify_guidance["negative"]:
            plan_ctx["skillify_guidance"] = skillify_guidance
    except Exception:
        logger.warning(
            "generate_plan: skillify guidance loading failed tenant=%s goal=%r",
            tenant_id,
            request.goal[:80],
            exc_info=True,
        )

    # ------------------------------------------------------------------
    # Pre-planning context bundle: implicit IntakeCompiler invocation
    #
    # When the caller did not supply an ``intake_result`` AND provided no
    # skills AND has not flagged ``intake_skipped``, compile the goal now
    # so that skill-reuse, loss-function, and composition signals are
    # available for the planning engine (Issue #2171).
    # ------------------------------------------------------------------
    _intake_data: dict[str, Any] = {}
    _skill_reuse_summary = SkillReuseSummary()

    raw_intake = request.intake_result
    intake_skipped = bool(plan_ctx.get("intake_skipped"))
    _compiled_intake_result: Any | None = None

    if raw_intake is not None:
        # Caller supplied explicit intake result — use it directly.
        _intake_data = raw_intake
        logger.debug("generate_plan: using caller-supplied intake_result for goal=%r", request.goal[:80])
    elif not request.skills and not intake_skipped:
        # Implicit compile path — caller gave us no skills and did not opt out.
        try:
            compiled = IntakeCompiler(tenant_id=tenant_id).compile(request.goal)
            _compiled_intake_result = compiled
            _intake_data = {
                "mode": compiled.mode.value,
                "eval_plan": compiled.eval_plan,
                "matched_skills": compiled.matched_skills,
                "matched_entity_schemas": compiled.matched_entity_schemas,
                "matched_entity_records": compiled.matched_entity_records,
                "ontology_consulted": compiled.ontology_consulted,
                "guardrails": compiled.guardrails,
                "approval_gates": compiled.approval_gates,
                "failure_modes": compiled.failure_modes,
                "not_do": compiled.not_do,
                "skillify_decision": compiled.skillify_decision.value,
            }
            matched = compiled.matched_skills
            logger.info(
                "generate_plan: implicit IntakeCompiler compiled goal=%r "
                "mode=%s matched_skills=%d ontology_consulted=%s",
                request.goal[:80],
                compiled.mode.value,
                len(matched),
                compiled.ontology_consulted,
            )
            # Emit Decision Trace evidence event so downstream systems can
            # audit when the implicit compile path fired.
            try:
                from apps.backend.services.zara.execution_event_bus import (
                    get_execution_event_bus,
                )
                bus = get_execution_event_bus(tenant_id=tenant_id)
                bus.emit({
                    "event_type": "evidence:plan_intake_compiled",
                    "tenant_id": tenant_id,
                    "goal": request.goal[:200],
                    "mode": compiled.mode.value,
                    "matched_skill_ids": [s.get("id", s.get("name", "")) for s in matched],
                    "loss_function_applicable": compiled.mode == GoalMode.GRADIENT,
                    "ontology_consulted": compiled.ontology_consulted,
                })
            except Exception:
                logger.debug("generate_plan: decision trace emit failed (non-fatal)", exc_info=True)

            # Augment skills list from matched ontology skills when the
            # request provided none (skill-reuse-first, Behaviour 3).
            if matched and not skills:
                skills = [
                    SkillSpec(
                        id=str(m.get("id") or m.get("name") or f"skill_{i}"),
                        name=str(m.get("name") or m.get("id") or f"skill_{i}"),
                        description=str(m.get("description") or ""),
                        inputs=list(m.get("inputs") or []),
                        outputs=list(m.get("outputs") or []),
                    )
                    for i, m in enumerate(matched)
                ]
                logger.debug(
                    "generate_plan: injected %d matched skill(s) from ontology into planning context",
                    len(skills),
                )
        except Exception:
            logger.warning(
                "generate_plan: IntakeCompiler.compile() failed (non-fatal, proceeding without intake)",
                exc_info=True,
            )

    # Build skill-reuse summary from resolved intake data.
    if _intake_data:
        matched_skills_raw = list(_intake_data.get("matched_skills") or [])
        matched_entity_schemas_raw = list(_intake_data.get("matched_entity_schemas") or [])
        matched_entity_records_raw = list(_intake_data.get("matched_entity_records") or [])
        ontology_consulted = bool(_intake_data.get("ontology_consulted", True))
        if matched_skills_raw or matched_entity_schemas_raw or matched_entity_records_raw:
            decision = "reuse"
        elif ontology_consulted:
            decision = "new"
        else:
            decision = "new"
        _skill_reuse_summary = SkillReuseSummary(
            matched_skills=matched_skills_raw,
            matched_entity_schemas=matched_entity_schemas_raw,
            matched_entity_records=matched_entity_records_raw,
            ontology_consulted=ontology_consulted,
            decision=decision,
        )

    # Derive loss function from intake eval_plan (per goal mode):
    #   GRADIENT -> composed loss function (delta-J weights)
    #   HABIT    -> milestone rubric (expected stays but weights lighten)
    #   EXPLORATORY / absent -> None sentinel (caller uses stored default)
    eval_plan = _intake_data.get("eval_plan") or {}
    intake_mode = _intake_data.get("mode") or ""
    _plan_loss_function: dict[str, Any] | None = None
    if intake_mode == GoalMode.GRADIENT.value and eval_plan.get("method") == "loss_function_with_delta_j":
        _plan_loss_function = {
            "weights": {"task": 0.45, "time": 0.25, "human": 0.05, "risk": 0.15, "cost": 0.10},
            "expected": 0.88,
            "confidence_band": [0.75, 0.94],
            "method": "loss_function_with_delta_j",
            "eval_frequency": eval_plan.get("evaluation_frequency", "weekly"),
        }
    elif intake_mode == GoalMode.HABIT.value:
        _plan_loss_function = {
            "weights": {"task": 0.60, "time": 0.30, "human": 0.05, "risk": 0.05, "cost": 0.00},
            "expected": 0.80,
            "confidence_band": [0.65, 0.90],
            "method": "milestone_rubric",
            "eval_frequency": eval_plan.get("evaluation_frequency", "daily_check_in"),
        }
    # EXPLORATORY and absent: _plan_loss_function stays None → default_loss_function() used below

    # Convert the (possibly intake-augmented) SkillSpec list to dicts for the
    # swarm planner and the single fast-path selector.
    _skills_for_planner = [
        {"id": s.id, "name": s.name, "description": s.description, "inputs": s.inputs, "outputs": s.outputs}
        for s in skills
    ]

    # --- PlanEffortPolicy: scale planning depth from projected execution cost (#2177) ---
    # Reuse the pre-planning intake result when it exists. Callers that supply
    # skills, explicit intake data, or opt out of intake intentionally avoid
    # the compiler here; PlanEffortPolicy falls back to deterministic defaults.
    _intake_result = _compiled_intake_result or object()
    _effort_decision = PlanEffortPolicy.evaluate(
        _intake_result,
        sensitivity_tier="low",  # pre-plan; real sensitivity computed after plan generation
    )
    plan_ctx["plan_pass_budget"] = _effort_decision.planning_pass_budget
    plan_ctx["plan_eval_thoroughness"] = _effort_decision.eval_thoroughness

    try:
        planner_decision = await SwarmPlannerAgent(
            tenant_id=tenant_id,
            llm_client=svc_for_roles.llm_client,
            evidence_service=svc_for_roles.evidence_service,
        ).decide(
            goal=request.goal,
            connectors=[_model_to_dict(c) for c in request.connectors],
            skills=_skills_for_planner,
            context=plan_ctx,
        )
        if planner_decision.output.decision == "single":
            # Prefer the augmented skill list (may include intake-matched skills)
            # over the raw request skills when the caller supplied none.
            selected_tool = (
                str(skills[0].id)
                if skills
                else (str(request.connectors[0].id) if request.connectors else "zara")
            )
            plan = GeneratedPlan(
                plan_id=str(ulid.new()),
                goal=request.goal,
                summary=planner_decision.output.reasoning,
                planner_mode=planner_mode,
                steps=[
                    PlanStepSpec(
                        id="step_1",
                        name="Execute objective",
                        connector_or_skill=selected_tool,
                        action=request.goal,
                        inputs={},
                        depends_on=[],
                        success_criteria="Objective completed with evidence.",
                        estimated_duration_seconds=60,
                    )
                ],
            )
        else:
            plan = await engine.generate_plan(
                goal=request.goal,
                available_connectors=connectors,
                available_skills=skills,
                context=plan_ctx,
                mode=planner_mode,
            )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    response = PlanResponse(
        plan_id=plan.plan_id,
        goal=plan.goal,
        summary=plan.summary,
        planner_mode=plan.planner_mode.value,
        steps=[
            PlanStepResponse(
                id=s.id,
                name=s.name,
                connector_or_skill=s.connector_or_skill,
                action=s.action,
                inputs=s.inputs,
                depends_on=s.depends_on,
                success_criteria=s.success_criteria,
                estimated_duration_seconds=s.estimated_duration_seconds,
                preconditions=list(getattr(s, "preconditions", []) or []),
                step_candidates=[
                    SkillCandidateResponse(
                        skill_id=c.skill_id,
                        name=c.name,
                        capability=c.capability,
                        fit_score=c.fit_score,
                        health_score=c.health_score,
                        queue_depth=c.queue_depth,
                        recent_success_rate=c.recent_success_rate,
                        reasons=c.reasons,
                        metadata=c.metadata,
                    )
                    for c in s.step_candidates
                ],
            )
            for s in plan.steps
        ],
        loss_function=_plan_loss_function if _plan_loss_function is not None else default_loss_function(),
        revision=1,
        status="active",
        skill_reuse_summary=_skill_reuse_summary,
        prior_context_refs=list(prior_context_bundle.prior_context_refs),
        alternatives_considered=list(prior_context_bundle.alternatives_considered),
    )
    plan_steps = _plan_steps_to_dicts(response.steps)
    tenant_config = get_tenant_config(tenant_id)
    sensitivity = SensitivityClassifier().classify_plan(
        goal=response.goal,
        steps=plan_steps,
        tenant_config=tenant_config,
    )
    inverter_payload: dict[str, Any] = {}
    if sensitivity.gate_flags.get("inverter"):
        analysis = await InverterAgent(
            tenant_id=tenant_id,
            llm_client=svc_for_roles.llm_client,
            evidence_service=svc_for_roles.evidence_service,
        ).analyze(
            plan={
                "plan_id": response.plan_id,
                "goal": response.goal,
                "summary": response.summary,
                "steps": plan_steps,
                "sensitivity": sensitivity.to_dict(),
            },
            tenant_context=tenant_config,
            recent_failures=[],
        )
        inverter_payload = analysis.to_plan_payload()

    # Re-evaluate effort policy with real post-classification sensitivity tier.
    effort_decision = PlanEffortPolicy.evaluate(
        _intake_result,
        sensitivity_tier=sensitivity.tier,
    )
    effort_policy_dict = effort_decision.to_dict()

    record = get_zara_plan_store().create_plan(
        tenant_id=tenant_id,
        plan_id=response.plan_id,
        goal=response.goal,
        summary=response.summary,
        steps=plan_steps,
        context=plan_ctx,
        loss_function=_model_to_dict(response.loss_function),
        planner_mode=response.planner_mode,
        sensitivity=sensitivity.tier,
        gate_flags=sensitivity.gate_flags,
        inverter=inverter_payload,
        swarm_planner={
            "decision": planner_decision.output.model_dump(mode="json"),
            "source": planner_decision.source,
            "evidence_id": planner_decision.evidence_id,
        },
        skill_reuse_summary=response.skill_reuse_summary.model_dump(mode="json"),
        prior_context_refs=list(prior_context_bundle.prior_context_refs),
        alternatives_considered=list(prior_context_bundle.alternatives_considered),
        effort_policy=effort_policy_dict,
    )
    return _plan_response_from_record(record)


@router.post("/plan/{plan_id}/revise", response_model=PlanResponse)
async def revise_plan(
    plan_id: str,
    request: PlanReviseRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    try:
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=request.instruction,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Plan not found") from exc
    return _plan_response_from_record(record, diff=diff)


def _plan_steer_trace_id() -> str:
    return f"plan-steer-{ulid.new().str.lower()}"


def _normalize_plan_control_actor(
    *,
    action: str,
    actor_id: str | None,
    actor_source: str | None,
) -> tuple[str, str]:
    source = str(actor_source or "api").strip().lower()
    if source not in {"api", "cli", "mcp", "slack"}:
        raise HTTPException(status_code=422, detail="Unsupported plan control actor source")
    actor = str(actor_id or "").strip()
    if action == "approve":
        if not actor:
            raise HTTPException(status_code=403, detail="Plan approval requires a human actor")
        if source == "mcp" and actor.lower() in {"mcp", "agent", "zara", "system"}:
            raise HTTPException(status_code=403, detail="MCP plan approval requires a member actor_id")
    return actor, source


def _plan_control_source_from_request(request: Request) -> str:
    user_agent = str(request.headers.get("user-agent") or "").strip().lower()
    return "cli" if user_agent.startswith("ww-cli/") else "api"


def _plan_control_idempotency_key(
    *,
    action: str,
    actor_id: str,
    actor_source: str,
    raw_key: str | None,
) -> str | None:
    normalized = str(raw_key or "").strip()
    if not normalized:
        return None
    return f"{action}:{normalized}"


def _plan_approval_revision_idempotency_key(expected_revision: int | None) -> str | None:
    if expected_revision is None:
        return None
    return f"approve:revision:{int(expected_revision)}"


def _require_plan_approve_retry_contract(
    *,
    action: str,
    expected_revision: int | None,
    idempotency_key: str | None,
) -> None:
    if action != "approve":
        return
    if expected_revision is None:
        raise HTTPException(status_code=422, detail="Approve action requires expected_revision")
    if int(expected_revision) < 1:
        raise HTTPException(status_code=422, detail="Approve action requires positive expected_revision")
    if not str(idempotency_key or "").strip():
        raise HTTPException(status_code=422, detail="Approve action requires idempotency_key")


def _idempotent_plan_control_response(current: dict[str, Any], entry: dict[str, Any] | None) -> PlanSteerResponse | None:
    if not isinstance(entry, dict):
        return None
    response = entry.get("response")
    if isinstance(response, dict):
        return PlanSteerResponse(**response)
    return PlanSteerResponse(
        plan_id=str(current.get("plan_id") or ""),
        status=str(current.get("status") or "active"),
        revision=int(current.get("latest_rev") or 1),
        decision_trace_id=str(entry.get("decision_trace_id") or _plan_steer_trace_id()),
        diff=[],
        execution_id=None,
        message="Plan control is already processing.",
    )


def _reserve_plan_control_idempotency(
    *,
    store: Any,
    tenant_id: str,
    plan_id: str,
    key: str | None,
    entry: dict[str, Any],
) -> tuple[bool, dict[str, Any] | None]:
    if not key:
        return True, None
    reserved = store.create_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
        entry=entry,
    )
    if reserved:
        return True, None
    return False, store.get_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
    )


def _complete_plan_control_idempotency(
    *,
    store: Any,
    tenant_id: str,
    plan_id: str,
    key: str | None,
    fields: dict[str, Any],
) -> None:
    if not key:
        return
    store.update_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
        fields=fields,
    )


def _emit_plan_steer_trace(
    *,
    tenant_id: str,
    plan_id: str,
    trace_id: str,
    action: str,
    instruction: str,
    status: str,
    actor_id: str,
    actor_source: str,
    execution_id: str | None = None,
) -> None:
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        get_evidence_ledger_service().ingest(
            tenant_id=tenant_id,
            event_type="evidence:zara_plan_steered",
            data={
                "plan_id": plan_id,
                "action": action,
                "instruction": instruction,
                "status": status,
                "actor_id": actor_id,
                "actor_source": actor_source,
                "execution_id": execution_id,
            },
            decision_trace_id=trace_id,
            actor_path="api.zara.steer_plan",
        )
    except Exception:
        logger.warning("zara.plan_steer_trace_failed plan_id=%s action=%s", plan_id, action, exc_info=True)


async def apply_plan_control(
    *,
    plan_id: str,
    action: str,
    instruction: str | None,
    actor_id: str | None,
    actor_source: str | None,
    tenant_id: str,
    expected_revision: int | None = None,
    idempotency_key: str | None = None,
    execution_context: dict[str, Any] | None = None,
) -> PlanSteerResponse:
    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise HTTPException(status_code=404, detail="Plan not found")

    action = str(action or "").strip()
    instruction = str(instruction or "").strip()
    if action not in {"approve", "steer", "block", "archive"}:
        raise HTTPException(status_code=422, detail="Unsupported plan control action")
    if action == "steer" and not instruction:
        raise HTTPException(status_code=422, detail="Steer action requires instruction")
    _require_plan_approve_retry_contract(
        action=action,
        expected_revision=expected_revision,
        idempotency_key=idempotency_key,
    )
    actor_id, actor_source = _normalize_plan_control_actor(
        action=action,
        actor_id=actor_id,
        actor_source=actor_source,
    )
    idempotency_key = _plan_control_idempotency_key(
        action=action,
        actor_id=actor_id,
        actor_source=actor_source,
        raw_key=idempotency_key,
    )
    duplicate_response = _idempotent_plan_control_response(
        current,
        store.get_plan_control_idempotency(tenant_id=tenant_id, plan_id=plan_id, key=idempotency_key)
        if idempotency_key
        else None,
    )
    if duplicate_response is not None:
        return duplicate_response
    approval_revision_key = _plan_approval_revision_idempotency_key(expected_revision) if action == "approve" else None
    duplicate_response = _idempotent_plan_control_response(
        current,
        store.get_plan_control_idempotency(tenant_id=tenant_id, plan_id=plan_id, key=approval_revision_key)
        if approval_revision_key
        else None,
    )
    if duplicate_response is not None:
        return duplicate_response
    if expected_revision is not None and int(current.get("latest_rev") or 1) != expected_revision:
        raise HTTPException(status_code=409, detail="Plan control is stale")
    trace_id = _plan_steer_trace_id()
    diff: list[dict[str, Any]] = []
    execution_id: str | None = None
    if approval_revision_key:
        reserved, existing_entry = _reserve_plan_control_idempotency(
            store=store,
            tenant_id=tenant_id,
            plan_id=plan_id,
            key=approval_revision_key,
            entry={
                "state": "processing",
                "action": action,
                "actor_id": actor_id,
                "actor_source": actor_source,
                "expected_revision": expected_revision,
                "decision_trace_id": trace_id,
            },
        )
        if not reserved:
            duplicate_response = _idempotent_plan_control_response(current, existing_entry)
            if duplicate_response is not None:
                return duplicate_response
    reserved, existing_entry = _reserve_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=idempotency_key,
        entry={
            "state": "processing",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
        },
    )
    if not reserved:
        duplicate_response = _idempotent_plan_control_response(current, existing_entry)
        if duplicate_response is not None:
            return duplicate_response
        return PlanSteerResponse(
            plan_id=str(current.get("plan_id") or plan_id),
            status=str(current.get("status") or "active"),
            revision=int(current.get("latest_rev") or 1),
            decision_trace_id=str((existing_entry or {}).get("decision_trace_id") or _plan_steer_trace_id()),
            diff=[],
            execution_id=None,
            message="Plan control is already processing.",
        )

    if action == "steer":
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=instruction,
        )
        record = store.update_plan_fields(
            tenant_id=tenant_id,
            plan_id=plan_id,
            fields={
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        message = "Plan updated from channel steering."
    elif action in {"block", "archive"}:
        status_value = "blocked" if action == "block" else "archived"
        diff = [
            {
                "type": "status_changed",
                "before": current.get("status") or "active",
                "after": status_value,
                "instruction": instruction,
                "actor_id": actor_id,
                "actor_source": actor_source,
            }
        ]
        record = store.save_revision(
            tenant_id=tenant_id,
            plan_id=plan_id,
            steps=_plan_steps_to_dicts(current.get("steps") or []),
            instruction=instruction or action,
            diff=diff,
            summary=str(current.get("summary") or ""),
            extra_fields={
                "status": status_value,
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        message = "Plan blocked." if action == "block" else "Plan archived."
    else:
        record = store.save_revision(
            tenant_id=tenant_id,
            plan_id=plan_id,
            steps=_plan_steps_to_dicts(current.get("steps") or []),
            instruction=instruction or "approved",
            diff=[
                {
                    "type": "status_changed",
                    "before": current.get("status") or "active",
                    "after": "approved",
                    "instruction": instruction,
                    "actor_id": actor_id,
                    "actor_source": actor_source,
                }
            ],
            summary=str(current.get("summary") or ""),
            extra_fields={
                "status": "approved",
                "approved_by": actor_id,
                "approved_via": actor_source,
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        execution = await execute_plan(
            ExecutePlanRequest(
                plan_id=plan_id,
                plan_rev=int(record.get("latest_rev") or 1),
                context={
                    "source": "zara_plan_steer",
                    "decision_trace_id": trace_id,
                    "approved_by": actor_id,
                    "approved_via": actor_source,
                    **dict(execution_context or {}),
                },
                explicit_approval=True,
            ),
            tenant_id=tenant_id,
        )
        execution_id = execution.execution_id
        diff = list(record.get("revisions", [])[-1].get("diff") or [])
        message = "Plan approved and handed to governed execution."

    _emit_plan_steer_trace(
        tenant_id=tenant_id,
        plan_id=plan_id,
        trace_id=trace_id,
        action=action,
        instruction=instruction,
        status=str(record.get("status") or "active"),
        actor_id=actor_id,
        actor_source=actor_source,
        execution_id=execution_id,
    )
    response = PlanSteerResponse(
        plan_id=plan_id,
        status=str(record.get("status") or "active"),
        revision=int(record.get("latest_rev") or record.get("revision") or 1),
        decision_trace_id=trace_id,
        diff=diff,
        execution_id=execution_id,
        message=message,
    )
    _complete_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=idempotency_key,
        fields={
            "state": "completed",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
            "response": response.model_dump(mode="json"),
        },
    )
    _complete_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=approval_revision_key,
        fields={
            "state": "completed",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
            "response": response.model_dump(mode="json"),
        },
    )
    return response


@router.post("/plans/{plan_id}/steer", response_model=PlanSteerResponse)
async def steer_plan(
    plan_id: str,
    request: PlanSteerRequest,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> PlanSteerResponse:
    return await apply_plan_control(
        plan_id=plan_id,
        action=request.action,
        instruction=request.instruction,
        actor_id=authenticated_user_id,
        actor_source=_plan_control_source_from_request(http_request),
        tenant_id=tenant_id,
        expected_revision=request.expected_revision,
        idempotency_key=request.idempotency_key,
    )


@router.post("/plan/{plan_id}/mitigations/{mitigation_id}", response_model=PlanResponse)
async def decide_plan_mitigation(
    plan_id: str,
    mitigation_id: str,
    request: PlanMitigationRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    from apps.backend.services.zara.inverter_agent import apply_mitigation_decision

    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise HTTPException(status_code=404, detail="Plan not found")
    try:
        updated, selected = apply_mitigation_decision(
            current,
            mitigation_id=mitigation_id,
            decision=request.decision,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Mitigation not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    previous_steps = _plan_steps_to_dicts(current.get("steps") or [])
    updated_steps = _plan_steps_to_dicts(updated.get("steps") or [])
    diff = build_step_diff(previous_steps, updated_steps)
    record = store.save_revision(
        tenant_id=tenant_id,
        plan_id=plan_id,
        steps=updated_steps,
        instruction=f"mitigation {mitigation_id} {request.decision}",
        diff=diff,
        summary=str(current.get("summary") or ""),
        extra_fields={"inverter": updated.get("inverter") or {}},
    )
    if request.decision == "request_revision":
        mitigation = str(selected.get("mitigation") or selected.get("description") or mitigation_id)
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=f"Address mitigation {mitigation_id}: {mitigation}",
        )
    return _plan_response_from_record(record, diff=diff)


@router.get("/plans", response_model=PlanListResponse)
async def list_plans(
    status_filter: str | None = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=100),
    cursor: str | None = Query(default=None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanListResponse:
    if status_filter and status_filter not in {"active", "approved", "blocked", "archived", "completed", "cancelled", "failed"}:
        raise HTTPException(status_code=422, detail="Unsupported plan status")
    result = get_zara_plan_store().list_plans(tenant_id, status=status_filter, limit=limit, cursor=cursor)
    return PlanListResponse(
        plans=[_plan_list_item(plan) for plan in result["plans"]],
        next_cursor=result.get("next_cursor"),
    )


@router.get("/plans/{plan_id}", response_model=PlanDetailResponse)
async def get_plan_detail(
    plan_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanDetailResponse:
    store = get_zara_plan_store()
    record = store.get_plan(tenant_id, plan_id)
    if not record:
        raise HTTPException(status_code=404, detail="Plan not found")
    executions = store.list_executions_for_plan(tenant_id, plan_id)
    return PlanDetailResponse(
        plan=_plan_response_from_record(record),
        revisions=[PlanRevisionResponse(**item) for item in list(record.get("revisions") or [])],
        executions=[_execution_response_from_record(item) for item in executions if item],
    )


@router.post("/execute-plan", response_model=ExecutePlanResponse, status_code=status.HTTP_202_ACCEPTED)
async def execute_plan(
    request: ExecutePlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutePlanResponse:
    """Start execution for a persisted plan and stream progress separately."""
    store = get_zara_plan_store()
    stored_plan = store.get_plan(tenant_id, request.plan_id)
    if not stored_plan and not request.steps:
        raise HTTPException(status_code=404, detail="Plan not found")
    if stored_plan:
        plan = dict(stored_plan)
    else:
        plan = {
            "plan_id": request.plan_id,
            "goal": request.goal or "",
            "summary": "",
            "steps": _plan_steps_to_dicts(request.steps),
            "latest_rev": request.plan_rev or 1,
            "loss_function": default_loss_function(),
            "sensitivity": "low",
            "gate_flags": {},
            "inverter": {},
            "swarm_planner": {},
            "status": "active",
        }
        store.create_plan(
            tenant_id=tenant_id,
            plan_id=request.plan_id,
            goal=request.goal or request.plan_id,
            summary="",
            steps=_plan_steps_to_dicts(request.steps),
            context=request.context,
            loss_function=default_loss_function(),
        )

    if request.plan_rev and int(plan.get("latest_rev") or 1) != request.plan_rev:
        raise HTTPException(status_code=409, detail="Plan revision is stale")
    gate_flags = plan.get("gate_flags") if isinstance(plan.get("gate_flags"), dict) else {}
    if gate_flags.get("requires_explicit_approval") and not request.explicit_approval:
        raise HTTPException(status_code=409, detail="This plan requires explicit approval before execution")

    execution_id = f"exec_{ulid.new().str}"
    store.create_execution(
        tenant_id=tenant_id,
        execution_id=execution_id,
        plan_id=request.plan_id,
        plan_rev=int(plan.get("latest_rev") or request.plan_rev or 1),
        context=request.context,
    )
    task = asyncio.create_task(
        _run_plan_execution(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan=plan,
            context=request.context,
        )
    )
    if hasattr(task, "add_done_callback"):
        task.add_done_callback(_log_background_execution_failure)
    return ExecutePlanResponse(
        execution_id=execution_id,
        status="accepted",
        step_results={},
    )


@router.get("/executions/{execution_id}", response_model=ExecutionStatusResponse)
async def get_execution_status(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionStatusResponse:
    record = get_zara_plan_store().get_execution(tenant_id, execution_id)
    if not record:
        raise HTTPException(status_code=404, detail="Execution not found")
    return _execution_response_from_record(record)


@router.get("/executions/{execution_id}/stream")
async def stream_execution(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    last_event_id: str | None = Header(default=None, alias="Last-Event-ID"),
) -> StreamingResponse:
    record = get_zara_plan_store().get_execution(tenant_id, execution_id)
    if not record:
        raise HTTPException(status_code=404, detail="Execution not found")
    bus = get_execution_event_bus()
    persisted = list(record.get("events") or [])
    if not bus.history(execution_id):
        for event in persisted:
            bus.publish(event)

    async def _events() -> Any:
        count = 0
        async for event in bus.subscribe(execution_id, last_event_id=last_event_id):
            count += 1
            yield format_sse(event)
        if count == 0:
            yield ": stream closed\n\n"

    return StreamingResponse(
        _events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/executions/{execution_id}/cancel", response_model=ExecutionCancelResponse)
async def cancel_execution(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionCancelResponse:
    store = get_zara_plan_store()
    execution = store.get_execution(tenant_id, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    get_execution_event_bus().cancel(execution_id)
    record = store.mark_cancel_requested(tenant_id=tenant_id, execution_id=execution_id)
    started_step_ids = _started_execution_step_ids(execution)
    plan = store.get_plan(tenant_id, str(record.get("plan_id") or "")) or {}
    for idx, step in enumerate(_plan_steps_to_dicts(plan.get("steps") or [])):
        step_id = _plan_step_id(step, idx)
        if step_id in started_step_ids:
            continue
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                "step.cancelled",
                execution_id=execution_id,
                plan_id=str(record.get("plan_id") or ""),
                step_id=step_id,
                message="Step cancelled before start",
            ),
        )
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.cancel_requested",
            execution_id=execution_id,
            plan_id=str(record.get("plan_id") or ""),
            message="Cancel requested",
        ),
    )
    return ExecutionCancelResponse(execution_id=execution_id, status="cancelling")


@router.post("/executions/{execution_id}/steer", response_model=ExecutionSteerResponse)
async def steer_execution(
    execution_id: str,
    request: ExecutionSteerRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionSteerResponse:
    store = get_zara_plan_store()
    execution = store.get_execution(tenant_id, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    revision_payload: dict[str, Any] = {}
    plan_id = str(execution.get("plan_id") or "")
    if plan_id:
        try:
            revised, diff = await _revise_plan_record(
                tenant_id=tenant_id,
                plan_id=plan_id,
                instruction=request.instruction,
                locked_step_ids=_started_execution_step_ids(execution),
            )
            revision_payload = {
                "plan_rev": revised.get("latest_rev"),
                "diff": diff,
                "steps": revised.get("steps") or [],
            }
        except KeyError:
            revision_payload = {}
    try:
        record = store.append_steer(tenant_id=tenant_id, execution_id=execution_id, instruction=request.instruction)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Execution not found") from exc
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.steered",
            execution_id=execution_id,
            plan_id=str(record.get("plan_id") or ""),
            message="Execution steering received",
            payload={"instruction": request.instruction, **revision_payload},
        ),
    )
    return ExecutionSteerResponse(
        execution_id=execution_id,
        status=str(record.get("status") or "running"),
        instruction=request.instruction,
    )


# ---------------------------------------------------------------------------
# Active Speak (Route C) — Recall.ai live SDK integration (#2717)
# ---------------------------------------------------------------------------


def _get_active_speak_executor():
    """Service-lookup stub. Tests patch this to inject a fake executor.

    Production wiring is intentionally minimal: we lazy-import the executor
    factory so the heavy adapter dependencies don't load on cold start of
    callers that never touch the speak surface.
    """
    from apps.backend.services.meeting.active_speak_executor_factory import (
        get_active_speak_executor,
    )

    return get_active_speak_executor()


@router.post(
    "/meetings/{meeting_id}/speak",
    response_model=ZaraMeetingSpeakResponse,
    status_code=status.HTTP_200_OK,
)
async def zara_meeting_speak(
    meeting_id: str,
    request: ZaraMeetingSpeakRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin_role: Any = Depends(require_admin_user_role),
) -> ZaraMeetingSpeakResponse:
    """Issue an Active Speak (Route C) action through Recall.ai (#2717).

    Pipeline (each gate fails closed and is audited):

      1. Authentication — ``get_verified_tenant_id`` + ``get_verified_user_id``
         supply the verified caller identity.
      2. RBAC — ``require_admin_user_role`` enforces owner/admin only.
      3. Feature flag — ``recall_speak_enabled`` resolved per tenant.
         Off ⇒ 503 with ``feature_disabled: true``.
      4. Consent — an ``ActiveSpeakConsent`` for the meeting must be
         granted, non-revoked, non-expired. Otherwise 412 with a stable
         reason code (``consent_missing | consent_revoked | consent_expired``).
      5. SDK — ``RecallAIMeetingAdapter.output_audio`` POSTs to Recall's
         canonical ``/api/v1/bot/{id}/output_audio/`` endpoint. Provider
         errors map to 502 / 504 / 410 / 404 with stable reason codes.

    Every attempt — success, refusal, or failure — writes a row to the
    decision_trace audit ledger before the response leaves this handler.
    """
    from apps.backend.services.meeting.active_speak_executor import (
        ActiveSpeakConsentRequiredError,
        ActiveSpeakFeatureDisabledError,
        ActiveSpeakProviderError,
    )

    # Workspace id default: tenant_id is the canonical scope when the
    # caller doesn't carry an explicit workspace surface. The contract
    # layer treats workspace_id as a stable tenancy identifier.
    workspace_id = tenant_id

    executor = _get_active_speak_executor()
    try:
        attempt = await executor.speak(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            meeting_id=meeting_id,
            text=request.text,
            voice_persona_id=request.voice_persona_id,
            trigger_reason=request.trigger_reason,
            actor_member_id=authenticated_user_id,
        )
    except ActiveSpeakFeatureDisabledError as exc:
        logger.info(
            "zara.meeting_speak.feature_disabled tenant=%s meeting=%s "
            "user=%s",
            tenant_id,
            meeting_id,
            authenticated_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "feature_disabled": True,
                "reason": "recall_speak_disabled",
                "message": str(exc),
            },
        ) from exc
    except ActiveSpeakConsentRequiredError as exc:
        logger.info(
            "zara.meeting_speak.consent_gate tenant=%s meeting=%s "
            "user=%s reason=%s",
            tenant_id,
            meeting_id,
            authenticated_user_id,
            exc.reason,
        )
        raise HTTPException(
            status_code=status.HTTP_412_PRECONDITION_FAILED,
            detail={
                "consent_required": True,
                "reason": exc.reason,
                "message": str(exc),
            },
        ) from exc
    except ActiveSpeakProviderError as exc:
        logger.warning(
            "zara.meeting_speak.provider_error tenant=%s meeting=%s "
            "reason=%s status=%s",
            tenant_id,
            meeting_id,
            exc.reason,
            exc.http_status,
        )
        raise HTTPException(
            status_code=exc.http_status,
            detail={
                "provider_error": True,
                "reason": exc.reason,
                "message": str(exc),
            },
        ) from exc
    except ValueError as exc:
        # Caller-side input violation — never reaches the SDK.
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "invalid_request", "message": str(exc)},
        ) from exc

    return ZaraMeetingSpeakResponse(
        recall_call_id=attempt.recall_call_id,
        status=attempt.status,
        consent_id=attempt.consent_id,
        decision_trace_id=attempt.decision_trace_id,
        meeting_id=attempt.meeting_id,
        workspace_id=attempt.workspace_id,
    )


__all__ = [
    "router",
    # models
    "AwarenessCapabilities",
    "AwarenessCapabilityItem",
    "AwarenessControlPlane",
    "AwarenessProactive",
    "AwarenessResponse",
    "AwarenessRoutineItem",
    "AwarenessRoutines",
    "AwarenessRuntime",
    "ChatContext",
    "ChatMessage",
    "ChatRequest",
    "ChatResponse",
    "CrossEntityQueryRequest",
    "CrossEntityQueryResponse",
    "DispatchTaskRequest",
    "DispatchTaskResponse",
    "ExecutePlanRequest",
    "ExecutePlanResponse",
    "ExecutionCancelResponse",
    "ExecutionStatusResponse",
    "ExecutionSteerRequest",
    "ExecutionSteerResponse",
    "ExplainContextSummary",
    "ExplainCoverageSummary",
    "ExplainDecision",
    "ExplainEvidenceSummary",
    "ExplainRequest",
    "ExplainResponse",
    "PlanConnectorInput",
    "PlanDetailResponse",
    "PlanListItemResponse",
    "PlanListResponse",
    "PlanRequest",
    "PlanResponse",
    "PlanReviseRequest",
    "PlanRevisionResponse",
    "PlanSkillInput",
    "PlanStepResponse",
    "RecallRequest",
    "RecallResponse",
    "SkillCandidateResponse",
    "StepResultResponse",
    "SuggestionRequest",
    "SuggestionResponse",
    "SupportTicketRequest",
    "SupportTicketResponse",
    "VoiceSessionRequest",
    "VoiceSessionResponse",
    "ZaraActRequest",
    "ZaraApproveRequest",
    "ZaraApproveResponse",
    "ZaraAskRequest",
    "ZaraMeetingSpeakRequest",
    "ZaraMeetingSpeakResponse",
]
