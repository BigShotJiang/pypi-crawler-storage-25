"""Slack Events API and slash command webhook handlers.

Provides:
- POST /api/v1/webhooks/slack/events — handle Slack Events API
    (url_verification, event_callback for message + app_mention)
- POST /api/v1/webhooks/slack/commands — handle slash commands

OPS-7: Slack webhook -> agent routing via channel_router.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
import time
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from apps.backend.services.ambient_adapters.messages import notify_inbound_event
from apps.backend.services.channels.channel_message import (
    ChannelMessage,
    ChannelMessageRenderer,
)
from apps.backend.services.channels.channel_router import summarize_delivery_result
from apps.backend.services.rate_limiter.agentic_limiter import get_agentic_rate_limiter
from apps.backend.services.slack_user_binding import SlackUserBinding, get_slack_user_binding_store
from apps.backend.services.zara.zara_intake_service import SlackConnectorThread, get_zara_intake_service

logger = logging.getLogger(__name__)

_RENDERER = ChannelMessageRenderer()


def _get_thread_service():
    """Lazy import ThreadService to avoid circular imports."""
    try:
        from apps.backend.services.thread_service import get_thread_service

        return get_thread_service()
    except Exception:
        return None


def _record_slack_thread(
    *,
    tenant_id: str,
    channel: str,
    user: str,
    text: str,
    event_type: str,
    thread_ts: str | None = None,
) -> None:
    """Record a Slack event as a canonical thread entry via ThreadService."""
    svc = _get_thread_service()
    if svc is None:
        logger.debug("ThreadService unavailable -- Slack event not recorded as thread")
        return
    try:
        source_ref = thread_ts or channel or user
        message_id = f"slack-{channel}-{thread_ts or user}-{int(time.time())}"
        svc.record_channel_message(
            tenant_id=tenant_id,
            channel="slack",
            source_ref=source_ref,
            message_id=message_id,
            direction="inbound",
            participant=user,
            subject=f"Slack {event_type} in #{channel}",
            body=text,
            event_type=event_type,
            metadata={"slack_channel": channel, "thread_ts": thread_ts},
        )
    except Exception as exc:
        logger.warning("Failed to record Slack thread entry (non-fatal): %s", exc)


def _tenant_for_router(tenant_id: str) -> str:
    normalized = str(tenant_id or "").strip()
    if not normalized:
        return "TENANT#system"
    return normalized if normalized.startswith("TENANT#") else f"TENANT#{normalized}"


def _resolve_slack_actor(*, slack_workspace_id: str, slack_user_id: str) -> SlackUserBinding | None:
    return get_slack_user_binding_store().get_binding(
        slack_workspace_id=slack_workspace_id,
        slack_user_id=slack_user_id,
    )


def _link_invitation_response(*, slack_workspace_id: str, slack_user_id: str) -> JSONResponse:
    logger.info(
        "slack_actor_unbound workspace=%s user=%s action=link_invitation",
        slack_workspace_id,
        slack_user_id,
    )
    return JSONResponse(
        content={
            "ok": True,
            "status": "link_invitation",
            "manual_required": True,
            "text": "Link your Slack account to Workweaver before this action can run.",
        },
        status_code=200,
    )


router = APIRouter(prefix="/api/v1/webhooks/slack", tags=["webhooks", "slack"])

# Slack signing secret for request verification
_SIGNING_SECRET_ENV = "SLACK_SIGNING_SECRET"
_SLACK_EVENT_ID_TTL_SECONDS = 60 * 60
_SLACK_EVENT_ID_MAX = 4096
_SLACK_CONTROL_TTL_SECONDS = 24 * 60 * 60
_seen_slack_event_ids: dict[str, float] = {}
_SlackEventSeenStatus = str


def _verify_slack_signature(
    *,
    signing_secret: str,
    timestamp: str,
    body: bytes,
    signature: str,
) -> bool:
    """Verify that a request came from Slack using HMAC-SHA256.

    Slack sends X-Slack-Signature and X-Slack-Request-Timestamp headers.
    We reconstruct the signature and compare.
    """
    if not signing_secret or not timestamp or not signature:
        return False

    # Reject requests older than 5 minutes to prevent replay attacks
    try:
        ts = int(timestamp)
        if abs(time.time() - ts) > 300:
            return False
    except (ValueError, TypeError):
        return False

    sig_basestring = f"v0:{timestamp}:{body.decode('utf-8')}"
    computed = (
        "v0="
        + hmac.new(
            signing_secret.encode("utf-8"),
            sig_basestring.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
    )

    return hmac.compare_digest(computed, signature)


def _require_slack_signature(request: Request, body_bytes: bytes) -> None:
    """Verify Slack signature — reject if signing secret is not configured.

    Raises HTTPException 500 if SLACK_SIGNING_SECRET is not set.
    Raises HTTPException 401 if signature verification fails.
    """
    signing_secret = os.getenv(_SIGNING_SECRET_ENV, "").strip()
    if not signing_secret:
        raise HTTPException(
            status_code=500,
            detail="SLACK_SIGNING_SECRET not configured — cannot verify Slack requests",
        )

    timestamp = request.headers.get("X-Slack-Request-Timestamp", "")
    signature = request.headers.get("X-Slack-Signature", "")
    if not _verify_slack_signature(
        signing_secret=signing_secret,
        timestamp=timestamp,
        body=body_bytes,
        signature=signature,
    ):
        raise HTTPException(status_code=401, detail="Invalid Slack signature")


def _mark_slack_event_seen_status(
    event_id: str | None,
    *,
    tenant_id: str | None = None,
    slack_workspace_id: str | None = None,
) -> _SlackEventSeenStatus:
    normalized = str(event_id or "").strip()
    if not normalized:
        return "claimed"
    tenant = str(tenant_id or "").strip()
    workspace = str(slack_workspace_id or "").strip()
    if tenant and workspace:
        request = None
        try:
            from apps.backend.services.zara.plan_store import get_zara_plan_store

            claimed = get_zara_plan_store().create_slack_intake_idempotency(
                tenant_id=tenant,
                slack_workspace_id=workspace,
                event_id=normalized,
                entry={
                    "operation": "slack.app_mention",
                    "actor_id": "slack",
                    "idempotency_key": f"slack:{workspace}:{normalized}",
                },
            )
            if not claimed:
                return "duplicate"
            return "claimed"
        except Exception:
            from apps.backend.services.idempotency import (
                IdempotencyClaimRequest,
                IdempotencyRisk,
            )

            request = IdempotencyClaimRequest(
                tenant_id=tenant,
                actor_id="slack",
                operation="slack.app_mention",
                idempotency_key=f"slack:{workspace}:{normalized}",
                risk=IdempotencyRisk.VALUE_BEARING,
                evidence_id=normalized,
            )
            from apps.backend.services.idempotency import _record_claim_decision

            _record_claim_decision(
                request,
                result="refused_unavailable",
                backend="dynamo",
                allowed=False,
                reason="Slack idempotency claim unavailable",
            )
            logger.warning(
                "slack.event_idempotency_claim_unavailable event_id=%s tenant=%s",
                normalized,
                tenant,
                exc_info=True,
            )
            return "blocked"
    now = time.time()
    stale = [
        key
        for key, seen_at in _seen_slack_event_ids.items()
        if now - seen_at > _SLACK_EVENT_ID_TTL_SECONDS
    ]
    for key in stale:
        _seen_slack_event_ids.pop(key, None)
    if normalized in _seen_slack_event_ids:
        return "duplicate"
    _seen_slack_event_ids[normalized] = now
    while len(_seen_slack_event_ids) > _SLACK_EVENT_ID_MAX:
        oldest = min(_seen_slack_event_ids, key=_seen_slack_event_ids.__getitem__)
        _seen_slack_event_ids.pop(oldest, None)
    return "claimed"


def _mark_slack_event_seen(
    event_id: str | None,
    *,
    tenant_id: str | None = None,
    slack_workspace_id: str | None = None,
) -> bool:
    return (
        _mark_slack_event_seen_status(
            event_id,
            tenant_id=tenant_id,
            slack_workspace_id=slack_workspace_id,
        )
        == "claimed"
    )


def _log_background_task_failure(task: asyncio.Task[Any]) -> None:
    try:
        task.result()
    except Exception:
        logger.exception("Slack background task failed")


async def _route_to_channel_router(
    *,
    tenant_id: str,
    channel: str,
    user: str,
    text: str,
    event_type: str,
    thread_ts: str | None = None,
) -> dict[str, Any]:
    """Route a Slack event to the channel router for processing.

    Returns an explicit delivery summary so callers can distinguish a real
    delivery from a manual-required fallback.
    """
    try:
        from apps.backend.services.channels.channel_router import get_channel_router
    except ImportError:
        logger.debug("ChannelRouter not available -- Slack event stored but not routed")
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "manual_required": True,
            "degraded": True,
            "channel": "slack",
            "error": "channel_router_unavailable",
        }

    router = get_channel_router()
    contact_id = user or channel

    try:
        delivery = await router.route_message(
            tenant_id=_tenant_for_router(tenant_id),
            contact_id=contact_id,
            message=text,
            channel_origin="slack",
            preferred_channel=None,
        )
        outcome = summarize_delivery_result(delivery)
        if outcome["manual_required"]:
            logger.warning(
                "Routing Slack %s from user=%s channel=%s requires manual follow-up",
                event_type,
                user,
                channel,
            )
        else:
            logger.info(
                "Routing Slack %s from user=%s channel=%s via channel router",
                event_type,
                user,
                channel,
            )
        return outcome
    except Exception as exc:
        logger.warning("Slack routing failed (non-fatal): %s", exc)
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "manual_required": True,
            "degraded": True,
            "channel": "slack",
            "error": str(exc),
        }


@router.post("/events")
async def handle_slack_events(request: Request) -> JSONResponse:
    """Handle Slack Events API callbacks.

    Supports:
    - url_verification: responds with challenge for Slack app setup
    - event_callback: processes message and app_mention events
    """
    body_bytes = await request.body()

    # Verify Slack signature (mandatory)
    _require_slack_signature(request, body_bytes)

    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event_type = payload.get("type", "")

    # URL verification challenge (Slack app setup)
    if event_type == "url_verification":
        challenge = payload.get("challenge", "")
        return JSONResponse(
            content={"challenge": challenge},
            status_code=200,
        )

    # Event callback
    if event_type == "event_callback":
        event = payload.get("event", {})
        return await _handle_event_callback(payload, event)

    logger.warning("Unrecognized Slack event type: %s", event_type)
    return JSONResponse(content={"ok": True}, status_code=200)


async def _handle_event_callback(payload: dict[str, Any], event: dict[str, Any]) -> JSONResponse:
    """Process an event_callback payload from Slack."""
    event_subtype = event.get("type", "")
    team_id = payload.get("team_id", "")

    # Skip bot messages to avoid loops
    if event.get("bot_id") or event.get("subtype") == "bot_message":
        return JSONResponse(content={"ok": True}, status_code=200)

    if event_subtype == "message":
        return await _handle_message_event(team_id, event)

    if event_subtype == "app_mention":
        return await _handle_app_mention_event(team_id, event, event_id=str(payload.get("event_id") or ""))

    logger.info("Ignoring Slack event subtype: %s", event_subtype)
    return JSONResponse(content={"ok": True}, status_code=200)


async def _handle_message_event(slack_workspace_id: str, event: dict[str, Any]) -> JSONResponse:
    """Handle a Slack message event."""
    channel = event.get("channel", "")
    slack_user = event.get("user", "")
    text = event.get("text", "")
    thread_ts = event.get("thread_ts")
    binding = _resolve_slack_actor(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user)
    if binding is None:
        return _link_invitation_response(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user)

    logger.info(
        "Slack message: tenant=%s channel=%s user=%s text_len=%d",
        binding.tenant_id,
        channel,
        binding.member_user_id,
        len(text),
    )

    # Slack's acknowledgement is immediate, but we still await the router so
    # any degraded/manual-required outcome is captured in logs and telemetry.
    outcome = await _route_to_channel_router(
        tenant_id=binding.tenant_id,
        channel=channel,
        user=binding.member_user_id,
        text=text,
        event_type="message",
        thread_ts=thread_ts,
    )
    if outcome.get("manual_required"):
        logger.warning("Slack message event requires manual follow-up: %s", outcome)

    _record_slack_thread(
        tenant_id=binding.tenant_id,
        channel=channel,
        user=binding.member_user_id,
        text=text,
        event_type="message",
        thread_ts=thread_ts,
    )

    # Fan out to ambient adapter callbacks (best-effort, non-blocking).
    # Structural markers only — body content is excluded by default in the adapter.
    import asyncio as _asyncio

    _asyncio.ensure_future(
        notify_inbound_event(
            tenant_id=binding.tenant_id,
            user_id=binding.member_user_id,
            event={
                "provider": "slack",
                "channel_type": "channel",
                "is_dm": False,
                "is_mention": False,
                "sender": binding.member_user_id,
                "subject": f"Slack message in #{channel}",
                "category": "message",
                "message_id": f"slack-{channel}-{thread_ts or slack_user}",
            },
        )
    )

    return JSONResponse(content={"ok": True}, status_code=200)


def _schedule_app_mention_intake(
    *,
    slack_workspace_id: str,
    binding: SlackUserBinding,
    channel: str,
    slack_user: str,
    text: str,
    thread_ts: str,
    limiter_lease_id: str | None = None,
) -> None:
    task = asyncio.create_task(
        _run_app_mention_intake(
            slack_workspace_id=slack_workspace_id,
            binding=binding,
            channel=channel,
            slack_user=slack_user,
            text=text,
            thread_ts=thread_ts,
            limiter_lease_id=limiter_lease_id,
        )
    )
    task.add_done_callback(_log_background_task_failure)


async def _run_app_mention_intake(
    *,
    slack_workspace_id: str,
    binding: SlackUserBinding,
    channel: str,
    slack_user: str,
    text: str,
    thread_ts: str,
    limiter_lease_id: str | None = None,
) -> None:
    try:
        intake_result = await get_zara_intake_service().handle_inbound_intent(
            workspace_id=binding.tenant_id,
            slack_workspace_id=slack_workspace_id,
            member_id=binding.member_user_id,
            channel=channel,
            text=text,
            thread_ts=thread_ts or channel,
        )
        if getattr(intake_result, "status", "") == "offline":
            logger.warning("Slack app_mention reached Zara intake but planner was offline: %s", intake_result)
    except Exception as exc:
        logger.exception("Slack app_mention Zara intake failed; falling back to delivery router")
        outcome = await _route_to_channel_router(
            tenant_id=binding.tenant_id,
            channel=channel,
            user=binding.member_user_id,
            text=f"Zara is offline: {exc}",
            event_type="app_mention",
            thread_ts=thread_ts,
        )
        if outcome.get("manual_required"):
            logger.warning("Slack app_mention fallback requires manual follow-up: %s", outcome)
    finally:
        if limiter_lease_id:
            get_agentic_rate_limiter().release(
                workspace_id=binding.tenant_id,
                lease_id=limiter_lease_id,
            )


def _schedule_app_mention_rate_limit_reply(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    channel: str,
    thread_ts: str,
    text: str,
) -> None:
    task = asyncio.create_task(
        SlackConnectorThread().reply(
            workspace_id=tenant_id,
            slack_workspace_id=slack_workspace_id,
            channel=channel,
            thread_ts=thread_ts,
            text=text,
        )
    )
    task.add_done_callback(_log_background_task_failure)


async def _handle_app_mention_event(
    slack_workspace_id: str,
    event: dict[str, Any],
    *,
    event_id: str | None = None,
) -> JSONResponse:
    """Handle a Slack app_mention event."""
    channel = event.get("channel", "")
    slack_user = event.get("user", "")
    text = event.get("text", "")
    thread_ts = event.get("thread_ts") or event.get("ts")
    binding = _resolve_slack_actor(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user)
    if binding is None:
        return _link_invitation_response(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user)

    logger.info(
        "Slack app_mention: tenant=%s channel=%s user=%s text_len=%d",
        binding.tenant_id,
        channel,
        binding.member_user_id,
        len(text),
    )

    event_status = _mark_slack_event_seen_status(
        event_id,
        tenant_id=binding.tenant_id,
        slack_workspace_id=slack_workspace_id,
    )
    if event_status == "blocked":
        return JSONResponse(content={"ok": True}, status_code=200)
    if event_status == "claimed":
        decision = get_agentic_rate_limiter().try_acquire(
            workspace_id=binding.tenant_id,
            member_id=binding.member_user_id,
            channel_id=channel,
            mention_id=str(event_id or thread_ts or event.get("ts") or ""),
            sender_role="user",
            sender_subtype=event.get("subtype"),
            target_role="agent",
        )
        if not decision.allowed:
            _schedule_app_mention_rate_limit_reply(
                slack_workspace_id=slack_workspace_id,
                tenant_id=binding.tenant_id,
                channel=channel,
                thread_ts=thread_ts or channel,
                text=decision.user_message or "Zara skipped this mention to avoid an agentic loop.",
            )
            logger.info("Slack app_mention rate-limited reason=%s scope=%s", decision.reason, decision.scope)
        else:
            _schedule_app_mention_intake(
                slack_workspace_id=slack_workspace_id,
                binding=binding,
                channel=channel,
                slack_user=slack_user,
                text=text,
                thread_ts=thread_ts or channel,
                limiter_lease_id=decision.lease_id,
            )
    else:
        logger.info("Duplicate Slack app_mention ignored event_id=%s", event_id)

    _record_slack_thread(
        tenant_id=binding.tenant_id,
        channel=channel,
        user=binding.member_user_id,
        text=text,
        event_type="app_mention",
        thread_ts=thread_ts,
    )

    # Fan out to ambient adapter callbacks — app_mention has salience 0.9 (is_mention=True).
    import asyncio as _asyncio

    _asyncio.ensure_future(
        notify_inbound_event(
            tenant_id=binding.tenant_id,
            user_id=binding.member_user_id,
            event={
                "provider": "slack",
                "channel_type": "channel",
                "is_dm": False,
                "is_mention": True,
                "sender": binding.member_user_id,
                "subject": f"Slack @mention in #{channel}",
                "category": "app_mention",
                "message_id": f"slack-{channel}-{thread_ts or slack_user}",
            },
        )
    )

    return JSONResponse(content={"ok": True}, status_code=200)


def _first_action(payload: dict[str, Any]) -> dict[str, Any]:
    actions = payload.get("actions")
    if isinstance(actions, list) and actions and isinstance(actions[0], dict):
        return actions[0]
    return {}


def _json_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    try:
        parsed = json.loads(str(value or "{}"))
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _slack_payload_team_id(payload: dict[str, Any]) -> str:
    team = payload.get("team")
    if isinstance(team, dict):
        return str(team.get("id") or "").strip()
    return str(payload.get("team_id") or "").strip()


def _slack_payload_user_id(payload: dict[str, Any]) -> str:
    user = payload.get("user")
    if isinstance(user, dict):
        return str(user.get("id") or "").strip()
    return str(payload.get("user_id") or "").strip()


def _slack_payload_channel_id(payload: dict[str, Any]) -> str:
    channel = payload.get("channel")
    if isinstance(channel, dict):
        return str(channel.get("id") or "").strip()
    return str(payload.get("channel_id") or "").strip()


def _slack_payload_thread_ts(payload: dict[str, Any], action_value: dict[str, Any]) -> str:
    if action_value.get("thread_ts"):
        return str(action_value["thread_ts"])
    message = payload.get("message") if isinstance(payload.get("message"), dict) else {}
    container = payload.get("container") if isinstance(payload.get("container"), dict) else {}
    return str(message.get("thread_ts") or container.get("thread_ts") or container.get("message_ts") or message.get("ts") or "")


def _slack_expected_revision(action_value: dict[str, Any]) -> int | None:
    raw = action_value.get("expected_revision")
    if raw in (None, ""):
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def _slack_control_expired(action_value: dict[str, Any]) -> bool:
    raw = action_value.get("issued_at")
    if raw in (None, ""):
        return False
    try:
        issued_at = int(raw)
    except (TypeError, ValueError):
        return True
    return time.time() - issued_at > _SLACK_CONTROL_TTL_SECONDS


def _slack_interaction_id(
    *,
    payload: dict[str, Any],
    action_value: dict[str, Any],
    action: str,
    plan_id: str,
) -> str:
    action_payload = _first_action(payload)
    view = payload.get("view") if isinstance(payload.get("view"), dict) else {}
    user = _slack_payload_user_id(payload)
    control_id = str(action_value.get("control_id") or "").strip()
    if action != "steer":
        return f"{control_id}:{action}"
    raw = (
        action_payload.get("action_ts")
        or payload.get("trigger_id")
        or view.get("hash")
        or view.get("id")
        or ""
    )
    return ":".join(
        [
            control_id,
            action,
            user,
            str(raw),
        ]
    )


def _plan_steer_modal_view(
    *,
    plan_id: str,
    channel: str,
    thread_ts: str,
    expected_revision: int | None,
    idempotency_key: str,
) -> dict[str, Any]:
    return {
        "type": "modal",
        "callback_id": "zara_plan_steer_modal",
        "private_metadata": json.dumps(
            {
                "plan_id": plan_id,
                "channel": channel,
                "thread_ts": thread_ts,
                "expected_revision": expected_revision,
                "idempotency_key": idempotency_key,
            },
            separators=(",", ":"),
        ),
        "title": {"type": "plain_text", "text": "Steer Zara"},
        "submit": {"type": "plain_text", "text": "Update plan"},
        "close": {"type": "plain_text", "text": "Cancel"},
        "blocks": [
            {
                "type": "input",
                "block_id": "instruction",
                "label": {"type": "plain_text", "text": "What should change?"},
                "element": {
                    "type": "plain_text_input",
                    "action_id": "value",
                    "multiline": True,
                    "placeholder": {"type": "plain_text", "text": "Use Salesforce for step 1"},
                },
            }
        ],
    }


def _modal_instruction(payload: dict[str, Any]) -> str:
    view = payload.get("view") if isinstance(payload.get("view"), dict) else {}
    state = view.get("state") if isinstance(view.get("state"), dict) else {}
    values = state.get("values") if isinstance(state.get("values"), dict) else {}
    for block_value in values.values():
        if not isinstance(block_value, dict):
            continue
        for action_value in block_value.values():
            if isinstance(action_value, dict) and action_value.get("value"):
                return str(action_value["value"]).strip()
    return ""


async def _steer_zara_plan_from_slack(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    actor_id: str,
    plan_id: str,
    action: str,
    instruction: str,
    channel: str,
    thread_ts: str,
    expected_revision: int | None,
    idempotency_key: str,
) -> dict[str, Any]:
    from apps.backend.api.zara import apply_plan_control

    result = await apply_plan_control(
        plan_id=plan_id,
        action=action,
        instruction=instruction,
        actor_id=actor_id,
        actor_source="slack",
        expected_revision=expected_revision,
        idempotency_key=idempotency_key,
        tenant_id=tenant_id,
        execution_context={
            "slack_workspace_id": slack_workspace_id,
            "slack_channel": channel,
            "slack_thread_ts": thread_ts,
        },
    )
    return result.model_dump(mode="json") if hasattr(result, "model_dump") else dict(result)


async def _reply_plan_control_result(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    channel: str,
    thread_ts: str,
    result: dict[str, Any],
) -> None:
    plan_id = str(result.get("plan_id") or "")
    decision_trace_id = str(result.get("decision_trace_id") or "")
    message = str(result.get("message") or "Plan updated.")
    status = str(result.get("status") or "active")
    execution_id = str(result.get("execution_id") or "").strip() or None
    await SlackConnectorThread().reply(
        workspace_id=tenant_id,
        slack_workspace_id=slack_workspace_id,
        channel=channel,
        thread_ts=thread_ts,
        text=f"{message} Decision Trace: /api/v1/evidence/decisions/{decision_trace_id}",
        blocks=_RENDERER.to_slack_blocks(
            ChannelMessage.from_zara_control_result(
                plan_id=plan_id,
                status=status,
                decision_trace_id=decision_trace_id,
                message=message,
                execution_id=execution_id,
            )
        ),
    )


async def _reply_plan_control_failure(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    channel: str,
    thread_ts: str,
    message: str,
) -> None:
    await SlackConnectorThread().reply(
        workspace_id=tenant_id,
        slack_workspace_id=slack_workspace_id,
        channel=channel,
        thread_ts=thread_ts,
        text=message,
    )


async def _open_plan_steer_modal(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    trigger_id: str,
    plan_id: str,
    channel: str,
    thread_ts: str,
    expected_revision: int | None,
    idempotency_key: str,
) -> None:
    await SlackConnectorThread().open_modal(
        workspace_id=tenant_id,
        slack_workspace_id=slack_workspace_id,
        trigger_id=trigger_id,
        view=_plan_steer_modal_view(
            plan_id=plan_id,
            channel=channel,
            thread_ts=thread_ts,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
        ),
    )


async def _run_plan_control(
    *,
    slack_workspace_id: str,
    tenant_id: str,
    actor_id: str,
    plan_id: str,
    action: str,
    instruction: str,
    channel: str,
    thread_ts: str,
    expected_revision: int | None,
    idempotency_key: str,
) -> None:
    try:
        result = await _steer_zara_plan_from_slack(
            slack_workspace_id=slack_workspace_id,
            tenant_id=tenant_id,
            actor_id=actor_id,
            plan_id=plan_id,
            action=action,
            instruction=instruction,
            channel=channel,
            thread_ts=thread_ts,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
        )
        await _reply_plan_control_result(
            slack_workspace_id=slack_workspace_id,
            tenant_id=tenant_id,
            channel=channel,
            thread_ts=thread_ts,
            result=result,
        )
    except HTTPException as exc:
        detail = str(exc.detail or "Plan control failed.")
        await _reply_plan_control_failure(
            slack_workspace_id=slack_workspace_id,
            tenant_id=tenant_id,
            channel=channel,
            thread_ts=thread_ts,
            message=detail,
        )


def _schedule_plan_control(coro: Any) -> None:
    task = asyncio.create_task(coro)
    task.add_done_callback(_log_background_task_failure)


@router.post("/interactions")
async def handle_slack_interactions(request: Request) -> JSONResponse:
    """Handle signed Slack Block Kit actions and modal submissions."""
    body_bytes = await request.body()
    _require_slack_signature(request, body_bytes)
    form = await request.form()
    payload = _json_dict(form.get("payload"))
    payload_type = str(payload.get("type") or "").strip()

    if payload_type == "block_actions":
        return await _handle_plan_block_action(payload)
    if payload_type == "view_submission":
        return await _handle_plan_view_submission(payload)
    logger.info("Ignoring Slack interaction type: %s", payload_type)
    return JSONResponse(content={"ok": True}, status_code=200)


async def _handle_plan_block_action(payload: dict[str, Any]) -> JSONResponse:
    action_payload = _first_action(payload)
    action_id = str(action_payload.get("action_id") or "")
    if not action_id.startswith("zara_plan_"):
        return JSONResponse(content={"ok": True}, status_code=200)
    action_value = _json_dict(action_payload.get("value"))
    plan_id = str(action_value.get("plan_id") or "").strip()
    action = str(action_value.get("action") or "").strip()
    slack_workspace_id = _slack_payload_team_id(payload)
    slack_user_id = _slack_payload_user_id(payload)
    channel = _slack_payload_channel_id(payload)
    thread_ts = _slack_payload_thread_ts(payload, action_value)
    binding = _resolve_slack_actor(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user_id)
    if binding is None:
        return _link_invitation_response(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user_id)
    if not plan_id or action not in {"approve", "steer", "block", "archive"}:
        raise HTTPException(status_code=400, detail="Invalid Zara plan action")
    if _slack_control_expired(action_value):
        return JSONResponse(
            content={"response_type": "ephemeral", "text": "This Zara plan control expired. Ask Zara to refresh the plan."}
        )
    expected_revision = _slack_expected_revision(action_value)
    control_id = str(action_value.get("control_id") or "").strip()
    if action == "approve" and (expected_revision is None or not control_id):
        return JSONResponse(
            content={
                "response_type": "ephemeral",
                "text": "This Zara plan control is malformed. Ask Zara to refresh the plan.",
            }
        )
    idempotency_key = _slack_interaction_id(
        payload=payload,
        action_value=action_value,
        action=action,
        plan_id=plan_id,
    )

    if action == "steer":
        trigger_id = str(payload.get("trigger_id") or "").strip()
        _schedule_plan_control(
            _open_plan_steer_modal(
                slack_workspace_id=slack_workspace_id,
                tenant_id=binding.tenant_id,
                trigger_id=trigger_id,
                plan_id=plan_id,
                channel=channel,
                thread_ts=thread_ts,
                expected_revision=expected_revision,
                idempotency_key=idempotency_key,
            )
        )
        return JSONResponse(content={"response_type": "ephemeral", "text": "Opening a steering prompt."})

    instruction = f"Slack {action} by {binding.member_user_id}"
    _schedule_plan_control(
        _run_plan_control(
            slack_workspace_id=slack_workspace_id,
            tenant_id=binding.tenant_id,
            actor_id=binding.member_user_id,
            plan_id=plan_id,
            action=action,
            instruction=instruction,
            channel=channel,
            thread_ts=thread_ts,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
        )
    )
    return JSONResponse(content={"response_type": "ephemeral", "text": f"Plan {action} accepted."})


async def _handle_plan_view_submission(payload: dict[str, Any]) -> JSONResponse:
    view = payload.get("view") if isinstance(payload.get("view"), dict) else {}
    if str(view.get("callback_id") or "") != "zara_plan_steer_modal":
        return JSONResponse(content={"ok": True}, status_code=200)
    metadata = _json_dict(view.get("private_metadata"))
    instruction = _modal_instruction(payload)
    if not instruction:
        return JSONResponse(
            content={
                "response_action": "errors",
                "errors": {"instruction": "Enter a steering instruction."},
            },
            status_code=200,
        )

    slack_workspace_id = _slack_payload_team_id(payload)
    slack_user_id = _slack_payload_user_id(payload)
    binding = _resolve_slack_actor(slack_workspace_id=slack_workspace_id, slack_user_id=slack_user_id)
    if binding is None:
        return JSONResponse(
            content={
                "response_action": "errors",
                "errors": {"instruction": "Link your Slack account to Workweaver first."},
            },
            status_code=200,
        )
    _schedule_plan_control(
        _run_plan_control(
            slack_workspace_id=slack_workspace_id,
            tenant_id=binding.tenant_id,
            actor_id=binding.member_user_id,
            plan_id=str(metadata.get("plan_id") or ""),
            action="steer",
            instruction=instruction,
            channel=str(metadata.get("channel") or ""),
            thread_ts=str(metadata.get("thread_ts") or ""),
            expected_revision=_slack_expected_revision(metadata),
            idempotency_key=str(metadata.get("idempotency_key") or ""),
        )
    )
    return JSONResponse(content={"response_action": "clear"}, status_code=200)


@router.post("/commands")
async def handle_slack_commands(request: Request) -> JSONResponse:
    """Handle Slack slash commands.

    Slack sends slash commands as application/x-www-form-urlencoded POST.
    Returns an immediate acknowledgment to avoid Slack's 3-second timeout.
    """
    body_bytes = await request.body()

    # Verify Slack signature (mandatory)
    _require_slack_signature(request, body_bytes)

    form = await request.form()

    command = str(form.get("command", "")).strip()
    text = str(form.get("text", "")).strip()
    user_id = str(form.get("user_id", "")).strip()
    channel_id = str(form.get("channel_id", "")).strip()
    team_id = str(form.get("team_id", "")).strip()
    response_url = str(form.get("response_url", "")).strip()  # noqa: F841

    binding = _resolve_slack_actor(slack_workspace_id=team_id, slack_user_id=user_id)
    if binding is None:
        return _link_invitation_response(slack_workspace_id=team_id, slack_user_id=user_id)

    logger.info(
        "Slack command: tenant=%s command=%s user=%s channel=%s",
        binding.tenant_id,
        command,
        binding.member_user_id,
        channel_id,
    )

    outcome = await _route_to_channel_router(
        tenant_id=binding.tenant_id,
        channel=channel_id,
        user=binding.member_user_id,
        text=f"{command} {text}".strip(),
        event_type="slash_command",
    )
    if outcome.get("manual_required"):
        logger.warning("Slack slash command requires manual follow-up: %s", outcome)

    _record_slack_thread(
        tenant_id=binding.tenant_id,
        channel=channel_id,
        user=binding.member_user_id,
        text=f"{command} {text}".strip(),
        event_type="slash_command",
    )

    # Acknowledge immediately (Slack requires response within 3 seconds)
    return JSONResponse(
        content={
            "response_type": "ephemeral",
            "text": f"Processing `{command}` ...",
        },
        status_code=200,
    )
