"""Authentication API router aggregation.

This module was split into focused domain modules (Phase 5 tech debt reduction):
- auth_models.py: Pydantic models, enums, response classes
- auth_helpers.py: Shared utilities, config, AWS client singletons
- auth_signup.py: Google OAuth + email signup endpoints
- auth_login.py: Login, tenant/user query, provisioning status endpoints
- auth_management.py: Invitations, password reset, behavioral stops

All symbols that tests or external code previously imported from this module
are re-exported below for backward compatibility.
"""

import asyncio  # noqa: F401 - used by tests via monkeypatch (auth.asyncio)

import boto3  # noqa: F401 - used by tests via mock patching

from fastapi import APIRouter

from apps.backend.api.auth_signup import router as signup_router
from apps.backend.api.auth_login import router as login_router
from apps.backend.api.auth_management import router as management_router

# Aggregated router: sub-routers have NO prefix; this is the single prefix.
router = APIRouter(
    prefix="/api/v1/auth",
    tags=["authentication"],
)
router.include_router(signup_router)
router.include_router(login_router)
router.include_router(management_router)

# ---------------------------------------------------------------------------
# Backward-compatible re-exports
#
# Tests (test_runtime_auth_redirects.py, test_auth_flow.py) import symbols
# from `apps.backend.api.auth` via module attribute access or mock.patch.
# Re-export everything they need so those tests continue to work unchanged.
# ---------------------------------------------------------------------------

# Models & enums
from apps.backend.api.auth_models import (  # noqa: F401, E402
    AuthProvider,
    SignupResponse,
    LoginResponse,
    BehavioralStops,
    AuthMeResponse,
    RuntimeProvisioningStatusResponse,
)

# Helpers & config constants
from apps.backend.api.auth_helpers import (  # noqa: F401, E402
    INTERNAL_SIGNUP_BYPASS_DOMAINS,
    INTERNAL_SIGNUP_SKIP_STRIPE_ENABLED,
    RUNTIME_PROVISIONING_COOKIE_NAME,
    _complete_signup_after_identity_verification,
    _set_runtime_provisioning_cookie,
    _clear_runtime_provisioning_cookie,
    _redact_email,
)

# Service factories re-exported so tests can monkeypatch them on this module
from apps.backend.services.tenant_provisioning import (  # noqa: F401, E402
    get_tenant_provisioning_service,
)
from apps.backend.services.runtime.provisioning_service import (  # noqa: F401, E402
    get_workweaver_runtime_provisioning_service,
)
from apps.backend.services.google_oauth import (  # noqa: F401, E402
    exchange_code_for_tokens,
    validate_google_id_token,
)
from apps.backend.services.runtime.provisioning_token import (  # noqa: F401, E402
    mint_workweaver_runtime_provisioning_cookie,
)
