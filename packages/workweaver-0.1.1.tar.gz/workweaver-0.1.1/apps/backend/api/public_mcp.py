"""Public MCP tool definitions and dispatch for workspace-facing MCP server (M5.1).

Defines the MCP tool schemas exposed to workspaces and dispatches tool
invocations to the shared public API service layer.

Reference: docs/CAPABILITIES.md M5.1
"""

from __future__ import annotations

import logging
import json
import os
import re
from copy import deepcopy
from pathlib import Path
from typing import Any

from apps.backend.mcp.calendar_tools import CALENDAR_MCP_TOOLS, dispatch_calendar_tool
from apps.backend.mcp.places_tools import PLACES_MCP_TOOLS, dispatch_places_tool
from apps.backend.services.research_capability import research_tool_input_schema

logger = logging.getLogger(__name__)

_PLAN_STEER_MCP_TOOLS = frozenset({"ww.plan.steer", "workweaver.plan.steer"})
_GUARDED_PUBLIC_MCP_TOOLS = frozenset({
    "ww.connector.execute", "workweaver.connector.execute",
    "ww.connector.import.openapi",
    "ww.skill.import",
    "ww.wallet.sign", "ww.wallet.broadcast", "ww.wallet.address",
    # Multi-wallet write surfaces (issue #3625 / slice 8e parity)
    "ww.wallet.policy.set",
    "ww.wallet.transactions.sign",
    # Cross-tenant Zara coordination (issue #3625 / family J)
    "ww.zara.coordinate.send",
    "ww.zara.coordinate.broadcast",
    *_PLAN_STEER_MCP_TOOLS,
    "ww.mission.steer", "workweaver.mission.steer",
    "ww.mission.outcome_review",
    "ww.mission.reversal.request",
    "ww.skill.curator.run",
    "ww.skill.curator.latest",
    "ww.skill.curator.list",
    "ww.skill.curator.respond",
})
_SAFE_OPERATION_PREFIXES = ("read", "list", "get", "search", "query", "describe")
_HIGH_RISK_OPERATION_PREFIXES = (
    "create",
    "delete",
    "destroy",
    "execute",
    "patch",
    "publish",
    "post",
    "purge",
    "remove",
    "run",
    "send",
    "terminate",
    "trigger",
    "update",
    "upsert",
    "write",
)
_SAFE_CONNECTOR_HTTP_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
_TOOL_SEARCH_NAME = "ww.tools.search"
_CONNECTOR_EXECUTE_TOOL_NAMES = frozenset({"ww.connector.execute", "workweaver.connector.execute"})
_PARITY_JSON_PATH = Path(__file__).resolve().parents[3] / "apps" / "cli" / "parity.json"


# =====================================================================# MCP Tool Schema Definitions
# =====================================================================
_LEGACY_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "workweaver.task.create",
        "description": "Create a task for an agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Task title"},
                "description": {"type": "string", "description": "Task description", "default": ""},
                "assigned_agent": {"type": "string", "description": "Agent ID to assign task to"},
                "priority": {
                    "type": "string",
                    "description": "Priority level",
                    "enum": ["urgent", "high", "medium", "low"],
                    "default": "medium",
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "workweaver.task.status",
        "description": "Check the status of a task.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Task ID to check"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "workweaver.agent.list",
        "description": "List the workspace's agents.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status_filter": {"type": "string", "description": "Filter by agent status"},
            },
        },
    },
    {
        "name": "workweaver.agent.run",
        "description": "Trigger agent execution with a task description.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to run"},
                "task": {"type": "string", "description": "Task description for the agent"},
            },
            "required": ["agent_id", "task"],
        },
    },
    {
        "name": "workweaver.schedule.create",
        "description": "Create a recurring or triggered schedule for an agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID"},
                "title": {"type": "string", "description": "Schedule title"},
                "schedule_type": {
                    "type": "string",
                    "description": "Schedule type",
                    "enum": ["one_time", "recurring", "triggered"],
                },
                "cron_expression": {"type": "string", "description": "Cron expression for recurring"},
                "description": {"type": "string", "description": "Schedule description", "default": ""},
            },
            "required": ["agent_id", "title", "schedule_type"],
        },
    },
    {
        "name": "workweaver.schedule.trigger",
        "description": "Fire a triggered schedule immediately.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schedule_id": {"type": "string", "description": "Schedule ID to trigger"},
            },
            "required": ["schedule_id"],
        },
    },
    {
        "name": "workweaver.evidence.query",
        "description": "Query the evidence ledger for a workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Filter by agent ID"},
                "event_type": {"type": "string", "description": "Filter by event type"},
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "workweaver.approval.list",
        "description": "List pending approval requests for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max results", "default": 20},
            },
        },
    },
    {
        "name": "workweaver.approval.approve",
        "description": "Approve a pending action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval request ID"},
                "actor_id": {"type": "string", "description": "User ID approving"},
            },
            "required": ["request_id", "actor_id"],
        },
    },
    {
        "name": "workweaver.approval.reject",
        "description": "Reject a pending action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval request ID"},
                "actor_id": {"type": "string", "description": "User ID rejecting"},
                "reason": {"type": "string", "description": "Rejection reason", "default": ""},
            },
            "required": ["request_id", "actor_id"],
        },
    },
    {
        "name": "ww.operational_context.show",
        "description": "Show the Operational Context read model for one subject.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject_id": {"type": "string", "description": "Subject ID to query"},
            },
            "required": ["subject_id"],
        },
    },
    {
        "name": "ww.operational_context.workspace",
        "description": "Show Workspace Operational Context across permitted Member scopes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {"type": "string", "description": "Workspace ID to query"},
                "member_id": {"type": "string", "description": "Optional Member scope"},
                "kind": {"type": "string", "description": "Optional event kind filter"},
                "entity": {"type": "string", "description": "Optional entity filter"},
                "since": {"type": "string", "description": "Optional ISO timestamp lower bound"},
                "cursor": {"type": "string", "description": "Pagination cursor"},
                "limit": {"type": "integer", "description": "Max records", "default": 50},
            },
            "required": ["workspace_id"],
        },
    },
    {
        "name": "ww.operational_context.share",
        "description": "Grant a scoped Operational Context Permission.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "grant_to": {"type": "string", "description": "Member ID or external API key receiving the grant"},
                "scope": {"type": "object", "description": "Permission scope"},
                "expires_at": {"type": "string", "description": "Grant expiry as ISO timestamp"},
                "rights": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["read", "write"]},
                    "default": ["read"],
                },
            },
            "required": ["grant_to", "scope", "expires_at", "rights"],
        },
    },
    # -- Agent Protocol tools -----------------------------------------------
    {
        "name": "workweaver.org.query",
        "description": "Query org-level questions via the default Workweaver agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Natural language question to ask"},
            },
            "required": ["question"],
        },
    },
    {
        "name": "workweaver.org.audit_log",
        "description": "Query the org-level audit log for lease, dispatch, and org-scope evidence events.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "org_id": {"type": "string", "description": "Org ID to query, or current", "default": "current"},
                "since": {
                    "type": "string",
                    "description": "ISO timestamp or relative duration such as 7d",
                    "default": "7d",
                },
                "until": {"type": "string", "description": "Optional ISO timestamp upper bound"},
                "actor": {"type": "string", "description": "Optional actor user ID filter"},
                "event_type": {
                    "type": "array",
                    "description": "Optional event type filters",
                    "items": {"type": "string"},
                    "default": [],
                },
                "limit": {"type": "integer", "description": "Max audit events", "default": 50},
                "cursor": {"type": "string", "description": "Pagination cursor from the previous response"},
            },
        },
    },
    {
        "name": "workweaver.agent.query",
        "description": "Query a specific Workweaver agent by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Target agent ID"},
                "question": {"type": "string", "description": "Natural language question to ask"},
            },
            "required": ["agent_id", "question"],
        },
    },
    # -- Connector tools ----------------------------------------------------
    {
        "name": "workweaver.connector.install",
        "description": "Install a connector for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {
                    "type": "string",
                    "description": "Connector ID (e.g. ghost, zoho-crm, slack)",
                },
                "credentials": {
                    "type": "object",
                    "description": "Connector credentials as key-value pairs",
                    "default": {},
                },
            },
            "required": ["connector_id", "credentials"],
        },
    },
    {
        "name": "workweaver.connector.execute",
        "description": "Execute an operation on an installed connector.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {"type": "string", "description": "Connector ID"},
                "operation": {"type": "string", "description": "Operation to execute"},
                "params": {
                    "type": "object",
                    "description": "Operation parameters",
                    "default": {},
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Return a side-effect preview without provider execution.",
                    "default": False,
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable caller key reused from preview to live execution.",
                },
            },
            "required": ["connector_id", "operation"],
        },
    },
    {
        "name": "workweaver.connector.list",
        "description": "List installed connectors for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.research.search",
        "description": "Run bounded workspace-scoped web research through the shared research lease contract.",
        "inputSchema": research_tool_input_schema(),
    },
    # -- CLI capability wrappers --------------------------------------------
    {
        "name": "workweaver.mission.list",
        "description": "List work items (missions) with optional filters.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Filter by WorkItem status"},
                "agent_id": {"type": "string", "description": "Filter by assigned agent ID"},
                "limit": {"type": "integer", "description": "Max results", "default": 25},
            },
        },
    },
    {
        "name": "workweaver.plan.list",
        "description": "List Zara objective plans and execution history.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by plan status",
                    "enum": ["active", "approved", "blocked", "archived", "completed", "cancelled", "failed"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "workweaver.plan.show",
        "description": "Show a Zara objective plan, revisions, and executions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to inspect"},
            },
            "required": ["plan_id"],
        },
    },
    {
        "name": "workweaver.plan.steer",
        "description": "Approve, revise, block, or archive a Zara objective plan.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to control"},
                "action": {
                    "type": "string",
                    "description": "Plan control action",
                    "enum": ["approve", "steer", "block", "archive"],
                },
                "instruction": {
                    "type": "string",
                    "description": "Natural-language steering or block/archive context",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Human member ID; required when action=approve.",
                },
                "expected_revision": {
                    "type": "integer",
                    "description": "Plan revision the caller reviewed before acting.",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable retry key for this plan-control action.",
                },
            },
            "required": ["plan_id", "action"],
            "allOf": [
                {
                    "if": {"properties": {"action": {"const": "approve"}}, "required": ["action"]},
                    "then": {"required": ["actor_id", "expected_revision", "idempotency_key"]},
                }
            ],
        },
    },
    {
        "name": "ww.plan.list",
        "description": "List Zara objective plans and execution history.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by plan status",
                    "enum": ["active", "approved", "blocked", "archived", "completed", "cancelled", "failed"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.plan.show",
        "description": "Show a Zara objective plan, revisions, and executions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to inspect"},
            },
            "required": ["plan_id"],
        },
    },
    {
        "name": "ww.plan.steer",
        "description": "Approve, revise, block, or archive a Zara objective plan.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to control"},
                "action": {
                    "type": "string",
                    "description": "Plan control action",
                    "enum": ["approve", "steer", "block", "archive"],
                },
                "instruction": {
                    "type": "string",
                    "description": "Natural-language steering or block/archive context",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Human member ID; required when action=approve.",
                },
                "expected_revision": {
                    "type": "integer",
                    "description": "Plan revision the caller reviewed before acting.",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable retry key for this plan-control action.",
                },
            },
            "required": ["plan_id", "action"],
            "allOf": [
                {
                    "if": {"properties": {"action": {"const": "approve"}}, "required": ["action"]},
                    "then": {"required": ["actor_id", "expected_revision", "idempotency_key"]},
                }
            ],
        },
    },
    {
        "name": "ww.mission.steer",
        "description": "Steer a running mission with a typed action after verified mission ownership (cancel, modify, escalate, etc.).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to steer.",
                },
                "action_kind": {
                    "type": "string",
                    "description": "Typed action kind",
                    "enum": [
                        "cancel", "modify", "escalate", "reschedule",
                        "reassign", "block", "archive", "extend_skill",
                        "new_variant", "redirect_channel",
                    ],
                },
                "payload": {
                    "type": "object",
                    "description": "Action-specific metadata.",
                    "default": {},
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Client-generated dedup key.",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Verified Member ID of the actor.",
                },
            },
            "required": ["mission_id", "action_kind", "idempotency_key", "actor_id"],
        },
    },
    {
        "name": "ww.mission.outcome_review",
        "description": "Accept, reject, or correct a reported mission outcome before final TimeBlock completion and Skillify promotion.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {"type": "string", "description": "Mission whose reported outcome is being reviewed."},
                "outcome_id": {"type": "string", "description": "Reported outcome or evidence identifier under review."},
                "timeblock_id": {"type": "string", "description": "Optional Mission Calendar TimeBlock to finalize after accept/correct."},
                "decision": {
                    "type": "string",
                    "enum": ["accept", "reject", "correct"],
                    "description": "Review decision. Only accept/correct finalize completion.",
                },
                "correction": {"type": "string", "description": "Required when decision=correct."},
                "evidence_ref_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": "Evidence references supporting the review.",
                },
                "idempotency_key": {"type": "string", "description": "Stable retry key for this review."},
                "actor_id": {"type": "string", "description": "Verified Member ID of the reviewer."},
            },
            "required": ["mission_id", "outcome_id", "decision", "actor_id"],
        },
    },
    {
        "name": "ww.mission.admission",
        "description": "Read the durable per-Mission worker admission gate snapshot (cap, active workers, lease expiries) — issue #3282.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to inspect.",
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.mission.breaker",
        "description": "Read or reset the per-Mission spawn circuit breaker — issue #3283. Default action is show; pass action=reset with optional reason for operator manual reset.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to inspect or reset.",
                },
                "action": {
                    "type": "string",
                    "enum": ["show", "reset"],
                    "default": "show",
                },
                "reason": {
                    "type": "string",
                    "description": "Reason recorded with the reset Decision Trace.",
                    "default": "operator override",
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.mission.reversal.request",
        "description": "Preview or dispatch mission-level compensating actions from Evidence Ledger side-effect records.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID whose side effects should be reversed.",
                },
                "requested_by": {
                    "type": "string",
                    "description": "Principal requesting the reversal.",
                    "default": "mcp",
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Return the reversal plan without dispatching compensating actions.",
                    "default": False,
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.strategy.trace",
        "description": "List strategic decision traces (OKR + DecisionEvent projection over domain=strategy).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "okr_id": {"type": "string", "description": "Optional OKR ID to filter to a single strategic trace"},
                "limit": {"type": "integer", "description": "Max decisions to scan", "default": 100},
            },
        },
    },
    {
        "name": "workweaver.workitem.create",
        "description": "Create a new work item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Work item title"},
                "description": {"type": "string", "description": "Work item description", "default": ""},
                "source_kind": {
                    "type": "string",
                    "description": "Source kind",
                    "enum": ["goal", "task"],
                    "default": "task",
                },
                "priority": {
                    "type": "string",
                    "description": "Priority",
                    "enum": ["urgent", "high", "medium", "low"],
                    "default": "medium",
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "workweaver.memory.store",
        "description": "Store a memory item for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Memory content to store"},
                "scope": {
                    "type": "string",
                    "description": "Memory scope",
                    "enum": ["tenant", "agent", "session"],
                    "default": "tenant",
                },
                "agent_id": {"type": "string", "description": "Agent ID (required when scope=agent)"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "workweaver.config.get",
        "description": "Get workspace configuration value.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Configuration key to retrieve"},
            },
            "required": ["key"],
        },
    },
    {
        "name": "workweaver.entity.list",
        "description": "List entities for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "entity_type": {"type": "string", "description": "Filter by entity type"},
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.ontology.query",
        "description": "Query workspace ontology nodes for entity schemas, skills, capabilities, policies, and workflows.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "q": {"type": "string", "description": "Search text", "default": ""},
                "kind": {
                    "type": "string",
                    "description": "Optional ontology node kind",
                    "enum": ["entity_schema", "entity_instance", "skill", "capability", "policy", "workflow"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.policy.authority",
        "description": "Inspect the PolicyDecisionEnvelope authority map and final verdict contract.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.governance.anchor.list",
        "description": (
            "List file paths protected by the L4 governance anchor — "
            "kernel skill registry, policy authority map, floor schema, CI gates. "
            "Sub-L4 promotions touching these paths are denied at preflight (#3547)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.policy.allowlist.list",
        "description": "List platform and tenant policy allowlist entries for a kind.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "description": "Allowlist kind to list.",
                    "enum": ["TOOL"],
                    "default": "TOOL",
                },
            },
        },
    },
    {
        "name": "ww.kernel.healing.recent",
        "description": "List recent self-healing recovery actions classified by RemediationPosture (auto_reversible / approval_reversible / escalate_irreversible). #3545.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "window_hours": {
                    "type": "integer",
                    "description": "Lookback window in hours (1-720).",
                    "default": 24,
                    "minimum": 1,
                    "maximum": 720,
                },
            },
        },
    },
    {
        "name": "ww.kernel.skill.list",
        "description": "List the six §14 KernelSkills (kernel.process_inventory, kernel.skill_audit, kernel.memory_consolidation, kernel.capacity_check, kernel.connector_health, kernel.routing_audit). Read-only; immutable, owner=system. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.kernel.skill.show",
        "description": "Show one §14 KernelSkill row by ID. Read-only. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {
                    "type": "string",
                    "description": "Kernel skill ID, e.g. kernel.connector_health.",
                },
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.kernel.skill.run",
        "description": "Probe one §14 KernelSkill and emit a read-only Decision Trace classified as kernel.* with idempotent minute-bucket dedup. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {
                    "type": "string",
                    "description": "Kernel skill ID, e.g. kernel.connector_health.",
                },
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.kernel.connector_locality",
        "description": "Connector locality matrix summary (entry count + per-side-effect-class counts + cloud-required class list) or per-operation explanation when connector_name + operation are provided. PAYMENT / IDENTITY / GOVERNANCE classes are never local-eligible. #2880.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_name": {
                    "type": "string",
                    "description": "Optional connector id (e.g. stripe). Omit to list the matrix.",
                },
                "operation": {
                    "type": "string",
                    "description": "Optional operation id (e.g. charge_customer). Required when connector_name is given.",
                },
                "policy_modes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional policy modes that may shift the decision to POLICY_REQUIRED.",
                },
            },
        },
    },
    {
        "name": "ww.kernel.zero_burn",
        "description": "Tenant-wide zero-burn SLI summary: dormant/total Functions, ratio, and status (clean / drifting / burning / unknown). Read-only. #2879.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.kernel.probe.history",
        "description": "Most recent capability probe outcome for (tenant, capability_id). Read-only; reads the agent_awareness namespace populated by the multi-tenant capability readiness probe. #2340.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "capability_id": {
                    "type": "string",
                    "description": "Capability id, e.g. kernel.connector_health.",
                },
            },
            "required": ["capability_id"],
        },
    },
    {
        "name": "ww.evidence.trace.awareness",
        "description": "Replay the AwarenessSnapshot Zara consulted at plan time for a Decision Trace id. Returns 404 when the trace is legacy (no awareness_snapshot_id stamped) or the snapshot has aged out of retention. #3549.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "trace_id": {
                    "type": "string",
                    "description": "Decision Trace id (returned by ww.evidence.trace).",
                },
            },
            "required": ["trace_id"],
        },
    },
    {
        "name": "ww.healing.digest",
        "description": "Read the monthly healing digest — top auto-heal patterns + escalations + Skillify candidates + posture counts. Read-only. #3550.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "month": {
                    "type": "string",
                    "description": "YYYY-MM. Defaults to the current UTC month.",
                },
            },
        },
    },
    {
        "name": "ww.tenant.conflicts.list",
        "description": "Run the tenant_config × persona × governance × resource_policy conflict matrix and return the detected drift bundle. Read-only. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.tenant.conflicts.show",
        "description": "Show one detected tenant conflict by id. Read-only. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {
                    "type": "string",
                    "description": "Conflict id (returned by ww.tenant.conflicts.list).",
                },
            },
            "required": ["conflict_id"],
        },
    },
    {
        "name": "ww.tenant.conflicts.resolve",
        "description": "Record a resolution decision (accept_suggestion / reject / escalate) for a detected tenant conflict. AUTO_REVERSIBLE actions apply silently; everything else routes to operator approval. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {
                    "type": "string",
                    "description": "Conflict id (returned by ww.tenant.conflicts.list).",
                },
                "action": {
                    "type": "string",
                    "enum": ["accept_suggestion", "reject", "escalate"],
                    "default": "accept_suggestion",
                },
            },
            "required": ["conflict_id"],
        },
    },
    {
        "name": "ww.payment.preflight",
        "description": "Return the deny-by-default PolicyDecisionEnvelope for a payment action without provider calls.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "default": "payment.manage"},
                "actor_id": {"type": "string", "default": "zara"},
                "provider": {"type": "string", "default": "stripe"},
                "amount": {"type": "number"},
                "currency": {"type": "string"},
            },
        },
    },
    {
        "name": "ww.entity_schema.create",
        "description": "Create a draft entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "fields": {"type": "array", "items": {"type": "object"}},
                "relationships": {"type": "array", "items": {"type": "object"}, "default": []},
                "dcl": {"type": "string", "enum": ["DCL-0", "DCL-1", "DCL-2", "DCL-3", "DCL-4"]},
                "owner": {"type": "string"},
                "created_by": {"type": "string"},
                "description": {"type": "string", "default": ""},
            },
            "required": ["name", "fields", "dcl", "owner", "created_by"],
        },
    },
    {
        "name": "ww.entity_schema.list",
        "description": "List entity schemas.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["draft", "active", "retired"]},
                "limit": {"type": "integer", "default": 100},
            },
        },
    },
    {
        "name": "ww.entity_schema.get",
        "description": "Get an entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "version": {"type": "integer"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "ww.entity_schema.activate",
        "description": "Activate a draft entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "version": {"type": "integer"},
                "actor_id": {"type": "string", "default": "mcp"},
            },
            "required": ["name", "version"],
        },
    },
    {
        "name": "ww.entity.record.create",
        "description": "Create a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "fields": {"type": "object", "description": "Record fields validated against the active schema."},
                "evidence_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "decision_id": {"type": "string"},
                "evidence_null_reason": {"type": "string"},
                "decision_null_reason": {"type": "string"},
            },
            "required": ["schema_name", "fields"],
        },
    },
    {
        "name": "ww.entity.record.get",
        "description": "Read a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "record_id": {"type": "string", "description": "Record id."},
            },
            "required": ["schema_name", "record_id"],
        },
    },
    {
        "name": "ww.entity.record.list",
        "description": "List records for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "limit": {"type": "integer", "description": "Max results", "default": 100},
            },
            "required": ["schema_name"],
        },
    },
    {
        "name": "ww.entity.record.update",
        "description": "Update a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "record_id": {"type": "string", "description": "Record id."},
                "fields": {"type": "object", "description": "Fields to update, validated against the active schema."},
                "evidence_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "decision_id": {"type": "string"},
                "evidence_null_reason": {"type": "string"},
                "decision_null_reason": {"type": "string"},
            },
            "required": ["schema_name", "record_id", "fields"],
        },
    },
    {
        "name": "ww.entity.record.schema",
        "description": "Describe allowed fields for entity record create/update tools.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "operation": {"type": "string", "enum": ["create", "update"], "default": "create"},
            },
            "required": ["schema_name"],
        },
    },
    {
        "name": "ww.entity.conflicts",
        "description": "List unresolved local/cloud sync conflicts for workspace entity records.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Optional active entity schema name."},
            },
        },
    },
    {
        "name": "ww.entity.conflict.resolve",
        "description": "Explicitly resolve one local/cloud sync conflict for a workspace entity record.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {"type": "string"},
                "strategy": {
                    "type": "string",
                    "enum": ["keep_local", "keep_cloud", "custom"],
                    "description": "Resolution strategy recorded for audit.",
                },
                "actor_id": {"type": "string", "default": "mcp"},
                "resolved_fields": {
                    "type": "object",
                    "description": "Required by callers when strategy is custom.",
                },
            },
            "required": ["conflict_id", "strategy"],
        },
    },
    {
        "name": "ww.swarm.status",
        "description": "List active swarm executions or show one execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "execution_id": {"type": "string", "description": "Optional execution ID to inspect"},
                "status": {
                    "type": "string",
                    "description": "Optional list filter",
                    "enum": ["active", "admitted", "running", "completed", "failed", "cancelled"],
                    "default": "active",
                },
                "limit": {"type": "integer", "description": "Max list results", "default": 50},
            },
        },
    },
    {
        "name": "ww.swarm.spawn",
        "description": "Plan and start a swarm execution from a free-text goal plus budget envelope.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal": {"type": "string", "description": "Free-text goal for the swarm to execute."},
                "budget": {
                    "type": "string",
                    "description": "Budget axes as tokens=N,dollars=N,wall=Ns,steps=N.",
                },
                "until_done": {
                    "type": "boolean",
                    "description": "Poll the execution until it reaches completed, failed, or cancelled.",
                    "default": False,
                },
                "auto_approve_tier": {
                    "type": "string",
                    "description": "Comma-separated tiers allowed to auto-execute. Only low and medium are accepted.",
                    "default": "low,medium",
                },
                "plan_mode": {
                    "type": "string",
                    "description": "Planner mode override.",
                    "enum": ["emergent", "self_organizing_emergent", "rigid"],
                },
                "agents": {
                    "type": "integer",
                    "description": "Requested worker count for capacity preflight.",
                    "minimum": 1,
                    "default": 1,
                },
                "is_foreground": {
                    "type": "boolean",
                    "description": "Evaluate spawn as a foreground Zara task.",
                    "default": False,
                },
            },
            "required": ["goal"],
        },
    },
    {
        "name": "ww.swarm.search_tools",
        "description": "Search CapabilityRegistry for tools a running swarm agent may request at decision time.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural-language tool need."},
                "modality": {"type": "string", "description": "Optional capability family or action filter."},
                "agent_id": {"type": "string", "description": "Running swarm agent requesting discovery."},
                "limit": {
                    "type": "integer",
                    "description": "Maximum descriptors to return.",
                    "minimum": 1,
                    "maximum": 50,
                    "default": 10,
                },
            },
            "required": ["query", "agent_id"],
        },
    },
    {
        "name": "ww.swarm.activate_tool",
        "description": "Activate a discovered tool for a running swarm agent after Permission and Decision Trace gates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tool_name": {"type": "string", "description": "Canonical MCP tool name to activate."},
                "agent_id": {"type": "string", "description": "Running swarm agent requesting activation."},
                "search_query": {"type": "string", "description": "Discovery query that produced the tool."},
                "ttl_seconds": {
                    "type": "integer",
                    "description": "Activation lease TTL.",
                    "minimum": 1,
                    "maximum": 3600,
                    "default": 300,
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Actor chain recorded in the Decision Trace.",
                },
                "idempotency_key": {"type": "string", "description": "Stable activation idempotency key."},
            },
            "required": ["tool_name", "agent_id", "idempotency_key"],
        },
    },
    {
        "name": "ww.swarm.cancel",
        "description": "Cancel a pending or running swarm execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "execution_id": {"type": "string", "description": "Execution ID to cancel"},
                "reason": {"type": "string", "description": "Cancellation reason for audit evidence"},
            },
            "required": ["execution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.create",
        "description": "Create a versioned shared constitution for swarm execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "content": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "activate": {"type": "boolean", "default": False},
                "idempotency_key": {"type": "string"},
            },
            "required": ["name", "content"],
        },
    },
    {
        "name": "ww.swarm.constitution.list",
        "description": "List swarm constitutions in the authenticated tenant.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.swarm.constitution.get",
        "description": "Return one swarm constitution version.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "version": {"type": "integer", "minimum": 1},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.update",
        "description": "Append a new swarm constitution version.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "content": {"type": "string"},
                "name": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "idempotency_key": {"type": "string"},
            },
            "required": ["constitution_id", "content"],
        },
    },
    {
        "name": "ww.swarm.constitution.activate",
        "description": "Activate one swarm constitution version for dispatch injection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "version": {"type": "integer", "minimum": 1},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "idempotency_key": {"type": "string"},
            },
            "required": ["constitution_id", "version"],
        },
    },
    {
        "name": "ww.swarm.constitution.delete",
        "description": "Delete one swarm constitution from active dispatch.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.deactivate",
        "description": "Deactivate the active swarm constitution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.active",
        "description": "Return the active swarm constitution and dispatch projection.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.function.sli.snapshot",
        "description": "Capture zero-burn SLI snapshot for a Work Function. Returns resource counters and zero-burn compliance.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_id": {"type": "string", "description": "Work Function ID."},
                "window_hours": {
                    "type": "integer",
                    "description": "Observation window in hours (default: 24).",
                    "default": 24,
                },
            },
            "required": ["function_id"],
        },
    },
    {
        "name": "ww.function.sli.reap",
        "description": "Reap idle resource envelopes for a Work Function. Terminates idle envelopes to guarantee zero-burn.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_id": {"type": "string", "description": "Work Function ID."},
                "idle_threshold_minutes": {
                    "type": "integer",
                    "description": "Idle threshold in minutes (default: 30).",
                    "default": 30,
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Preview reap without executing (default: false).",
                    "default": False,
                },
                "actor_id": {
                    "type": "string",
                    "description": "Acting principal ID.",
                    "default": "mcp",
                },
            },
            "required": ["function_id"],
        },
    },
    {
        "name": "ww.pulse.list",
        "description": "List workspace Pulse liveness projections by state, kind, or subject.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "state": {
                    "type": "string",
                    "enum": ["alive", "idle", "executing", "waiting", "blocked", "degraded", "orphaned"],
                },
                "kind": {
                    "type": "string",
                    "enum": ["agent", "swarm", "schedule", "job"],
                },
                "subject_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ww.upgrades.list",
        "description": "List current Weekly Upgrade Digest proposals.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.upgrades.approve",
        "description": "Approve an upgrade proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Approving actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.upgrades.pilot",
        "description": "Schedule a 1-week, 10% pilot for an upgrade proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Approving actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.upgrades.dismiss",
        "description": "Dismiss an upgrade proposal for 90 days.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Dismissing actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.agent.di",
        "description": "Return an agent's Developmental Intelligence score and self-organization gate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to score."},
            },
            "required": ["agent_id"],
        },
    },
    {
        "name": "ww.compound.trajectory",
        "description": "Return per-skill quality_score trajectory for the compounding loop.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {"type": "string", "description": "Skill ID to query."},
                "window_days": {"type": "integer", "description": "Lookback window in days.", "default": 30},
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.precedent.predict",
        "description": "Predict outcome distribution for a proposed action based on historical decision precedents.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action_domain": {
                    "type": "string",
                    "description": "Action domain (e.g. email_send, calendar_book, payment_charge).",
                },
                "description": {
                    "type": "string",
                    "description": "Description of the proposed action.",
                },
                "k_precedents": {
                    "type": "integer",
                    "description": "Maximum number of precedents to consider (default: 20).",
                    "default": 20,
                },
            },
            "required": ["action_domain", "description"],
        },
    },
    {
        "name": "ww.decision.search",
        "description": "Search decision traces with structured filters and full-text query over rationale, summary, and alternatives.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Full-text search over rationale, decision_summary, and alternatives_considered.",
                },
                "domain": {
                    "type": "string",
                    "description": "Filter by domain (operational, customer, strategy).",
                    "enum": ["operational", "customer", "strategy"],
                },
                "tool_name": {
                    "type": "string",
                    "description": "Filter by tool/skill name.",
                },
                "outcome": {
                    "type": "string",
                    "description": "Filter by decision outcome.",
                },
                "skill_id": {
                    "type": "string",
                    "description": "Filter by skill ID.",
                },
                "decision_type": {
                    "type": "string",
                    "description": "Filter by decision type.",
                },
                "min_confidence": {
                    "type": "number",
                    "description": "Minimum quality_score threshold (0.0 to 1.0).",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
                "time_range_start": {
                    "type": "string",
                    "description": "ISO 8601 start of time range.",
                },
                "time_range_end": {
                    "type": "string",
                    "description": "ISO 8601 end of time range.",
                },
                "sop_deviation_present": {
                    "type": "boolean",
                    "description": "Filter for decisions with SOP deviations.",
                },
                "precedent_id": {
                    "type": "string",
                    "description": "Filter by precedent ID in precedent_ids_used.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default: 50).",
                    "default": 50,
                },
                "cursor": {
                    "type": "string",
                    "description": "Pagination cursor from previous response.",
                },
            },
        },
    },
]

_NATIVE_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.browser.run",
        "description": "Run a Browser Workbench task through the tenant sandbox policy.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Task for the browser workbench to perform."},
                "start_url": {"type": "string", "description": "Start URL for the browser task."},
                "url": {"type": "string", "description": "Alias for start_url."},
                "mode": {
                    "type": "string",
                    "enum": ["deterministic", "agentic"],
                    "default": "deterministic",
                    "description": "Browser execution mode.",
                },
                "work_item_id": {"type": "string", "description": "Optional WorkItem ID for trace attribution."},
                "timeblock_id": {"type": "string", "description": "Optional TimeBlock ID for trace attribution."},
                "allowed_url_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": "Allowed URL origins for this run.",
                },
                "public_read_only_default": {
                    "type": "boolean",
                    "default": False,
                    "description": "Allow deterministic read-only public web navigation.",
                },
                "side_effecting": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether the requested task has side effects.",
                },
                "downloads_allowed": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether downloads are requested and policy must allow an artifact temp dir.",
                },
                "artifact_temp_dir": {
                    "type": "string",
                    "description": "Temporary artifact directory for governed downloads.",
                },
                "steps": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Optional deterministic step list for CLI-style execution.",
                },
            },
            "required": ["task"],
            "anyOf": [{"required": ["start_url"]}, {"required": ["url"]}],
        },
    },
    {
        "name": "ww.browser.sandbox_evaluate",
        "description": (
            "Evaluate a URL against the browser sandbox policy. Returns an allow/deny "
            "verdict with reason, without executing any browser action. Use for pre-flight "
            "checks before running browser tasks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to evaluate against the sandbox policy.",
                },
                "task_mode": {
                    "type": "string",
                    "enum": ["deterministic", "agentic"],
                    "default": "deterministic",
                    "description": "Browser task mode for evaluation.",
                },
                "side_effecting": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether the action has side effects (forms, downloads, uploads).",
                },
            },
            "required": ["url"],
        },
    },
    {
        "name": "ww.browser.sandbox_policy",
        "description": (
            "Read the current browser sandbox policy configuration for the workspace. "
            "Returns the allowlist, read-only public-web flag, and artifact temp dir status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.session.intake_queue.status",
        "description": "Read per-member session intake queue counters for Slack, email, and Teams-originated work.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "member_id": {
                    "type": "string",
                    "description": "Optional member or agent ID. Omit to read the caller-scoped queue.",
                },
                "channel": {
                    "type": "string",
                    "enum": ["all", "slack", "email", "teams"],
                    "default": "all",
                    "description": "Optional intake channel filter.",
                },
            },
        },
        "namespace": "ww",
        "category": "sessions",
        "side_effect": False,
    },
    {
        "name": "ww.skill.import",
        "description": "Import or dry-run a governed SkillSource package into the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "origin": {
                    "type": "string",
                    "description": "SkillSource origin URL or local package path.",
                },
                "origin_kind": {
                    "type": "string",
                    "enum": ["github", "local", "registry", "mcp-server"],
                    "description": "Kind of SkillSource origin being imported.",
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Validate and preview the import without installing it.",
                    "default": True,
                },
                "customize": {
                    "type": "boolean",
                    "description": "Apply a customization overlay before import.",
                    "default": False,
                },
                "reject_on_warning": {
                    "type": "boolean",
                    "description": "Reject the import if warnings are produced.",
                    "default": False,
                },
                "customization_overlay": {
                    "type": "object",
                    "description": "Optional SkillCustomizationOverlay payload.",
                    "properties": {
                        "notes": {"type": "string"},
                        "field_overrides": {"type": "object"},
                        "removed_paths": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "required": ["workspace_id", "origin", "origin_kind"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill source import",
            "import skill",
            "dry run skill import",
            "skill package install",
        ],
    },
    {
        "name": "ww.skill.curator.run",
        "description": "Run the proposal-only Skill Curator for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "weights": {
                    "type": "object",
                    "description": "Optional scoring weights for the curator run.",
                    "properties": {
                        "usage": {"type": "number"},
                        "pass_rate": {"type": "number"},
                        "recency": {"type": "number"},
                        "consolidation": {"type": "number"},
                        "richness": {"type": "number"},
                    },
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator run",
            "run skill audit",
            "skill hygiene proposals",
        ],
    },
    {
        "name": "ww.skill.curator.latest",
        "description": "Read the latest Skill Curator run summary for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator latest",
            "latest skill curator run",
            "read skill hygiene run",
        ],
    },
    {
        "name": "ww.skill.curator.list",
        "description": "List Skill Curator proposals for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "status": {
                    "type": "string",
                    "enum": ["pending", "accepted", "rejected", "deferred"],
                    "description": "Optional proposal status filter.",
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator list",
            "list skill curator proposals",
            "skill hygiene proposal queue",
        ],
    },
    {
        "name": "ww.skill.curator.respond",
        "description": "Record an accept, reject, or defer decision for a Skill Curator proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "proposal_id": {
                    "type": "string",
                    "description": "Skill Curator proposal ID.",
                },
                "decision": {
                    "type": "string",
                    "enum": ["accept", "reject", "defer"],
                    "description": "Decision to record.",
                },
                "reason": {
                    "type": "string",
                    "description": "Decision rationale.",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Member or agent actor recording the decision; MCP writes use validated side_effect_proof.actor_id.",
                },
            },
            "required": ["workspace_id", "proposal_id", "decision"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator respond",
            "accept skill curator proposal",
            "reject skill curator proposal",
            "defer skill hygiene proposal",
        ],
    },
    {
        "name": "ww.identity.readiness",
        "description": "Return read-only Zara-owned provider identity readiness for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": [
            "identity readiness",
            "zara identity readiness",
            "agent identity readiness",
        ],
    },
    {
        "name": "ww.agent.identity",
        "description": "Return per-purpose Zara-owned provider identity status (email, calendar, meeting, voice, payment).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "description": "Agent ID (default: zara)",
                    "default": "zara",
                },
            },
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": [
            "agent identity",
            "zara identity",
            "identity status",
            "provider identity",
        ],
    },
    {
        "name": "ww.inbox.list",
        "description": "List pending inbox judgment items.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max pending items", "default": 20},
            },
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["inbox list", "pending approvals", "judgment feed"],
    },
    {
        "name": "ww.inbox.approve",
        "description": "Approve a pending inbox judgment item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval or judgment request ID"},
                "actor_id": {"type": "string", "description": "User ID approving"},
            },
            "required": ["request_id", "actor_id"],
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["approve pending approval", "approve judgment", "inbox approve"],
    },
    {
        "name": "ww.inbox.reject",
        "description": "Reject a pending inbox judgment item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval or judgment request ID"},
                "actor_id": {"type": "string", "description": "User ID rejecting"},
                "reason": {"type": "string", "description": "Rejection reason", "default": ""},
            },
            "required": ["request_id", "actor_id"],
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["reject pending approval", "reject judgment", "inbox reject"],
    },
    {
        "name": "ww.inbox.conversations",
        "description": "List inbox conversations across channels.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "channel": {"type": "string", "description": "Optional channel filter"},
                "limit": {"type": "integer", "description": "Max conversations", "default": 50},
                "offset": {"type": "integer", "description": "Pagination offset", "default": 0},
            },
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["inbox conversations", "email conversations", "conversation inbox"],
    },
    # ── Wallet tool family (#2366) ──────────────────────────────────────
    {
        "name": "ww.wallet.readiness",
        "description": "Check crypto wallet readiness for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet readiness", "crypto readiness", "wallet ready"],
    },
    {
        "name": "ww.wallet.policy",
        "description": "Return the workspace crypto wallet policy (caps, allowlists, slippage, MEV).",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet policy", "crypto policy", "wallet limits"],
    },
    {
        "name": "ww.wallet.address",
        "description": "Derive a wallet address for a given chain family and network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family (evm, solana, cosmos, bitcoin)"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "index": {"type": "integer", "description": "Derivation index", "default": 0},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet address", "derive address", "crypto address"],
    },
    {
        "name": "ww.wallet.balance",
        "description": "Query wallet balance for a chain and network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "token": {"type": "string", "description": "Token contract address (optional)"},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet balance", "crypto balance", "token balance"],
    },
    {
        "name": "ww.wallet.sign",
        "description": "Sign a transaction payload using the configured KeyCustody backend.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "payload": {"type": "string", "description": "Transaction payload JSON"},
            },
            "required": ["chain", "payload"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet sign", "sign transaction", "crypto sign"],
    },
    {
        "name": "ww.wallet.broadcast",
        "description": "Broadcast a signed transaction to the network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "signed_tx": {"type": "string", "description": "Signed transaction JSON"},
            },
            "required": ["chain", "signed_tx"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet broadcast", "broadcast transaction", "send transaction"],
    },
    {
        "name": "ww.wallet.tx_list",
        "description": "List recent wallet transactions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "limit": {"type": "integer", "description": "Max results", "default": 20},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet transactions", "tx history", "crypto transactions"],
    },
    {
        "name": "ww.wallet.tx_get",
        "description": "Get details of a specific transaction by hash.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tx_hash": {"type": "string", "description": "Transaction hash"},
                "chain": {"type": "string", "description": "Chain family"},
            },
            "required": ["tx_hash", "chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet tx", "transaction details", "tx status"],
    },
    {
        "name": "ww.wallet.custody_status",
        "description": "Return the custody backend status for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["custody status", "key custody", "wallet backend"],
    },
    # ── Multi-wallet parity (#3625 / slice 8e) ──────────────────────────
    {
        "name": "ww.wallet.policies.list",
        "description": "List every wallet policy row owned by the caller's tenant (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policies",
            "list wallets",
            "multi-wallet inventory",
        ],
    },
    {
        "name": "ww.wallet.policy.get",
        "description": "Read a per-wallet policy by wallet_id (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Wallet identifier (1..64 chars, [A-Za-z0-9._:-]).",
                    "minLength": 1,
                    "maxLength": 64,
                },
            },
            "required": ["wallet_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policy get",
            "read wallet policy",
            "per-wallet policy",
        ],
    },
    {
        "name": "ww.wallet.policy.set",
        "description": "Upsert a per-wallet policy (issue #3625). Write surface; emits Decision Trace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Wallet identifier (1..64 chars, [A-Za-z0-9._:-]).",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "daily_cap_usd": {
                    "type": "string",
                    "description": "Daily cap as a decimal string.",
                    "default": "0",
                },
                "approval_threshold_usd": {
                    "type": "string",
                    "description": "Multi-approver threshold (decimal string).",
                    "default": "0",
                },
                "max_slippage_bps": {
                    "type": "integer",
                    "description": "Slippage cap in basis points (0..10000).",
                    "minimum": 0,
                    "maximum": 10000,
                    "default": 300,
                },
                "allowlisted_addresses": {
                    "type": "array",
                    "description": "Per-chain allowlist entries.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "chain_family": {"type": "string"},
                            "network_id": {"type": "string"},
                            "address": {"type": "string"},
                        },
                        "required": ["chain_family", "network_id", "address"],
                        "additionalProperties": False,
                    },
                    "default": [],
                },
                "mev_protection_required": {
                    "type": "boolean",
                    "description": "Toggle MEV protection requirement.",
                    "default": True,
                },
                "mev_threshold_usd": {
                    "type": "string",
                    "description": "MEV protection threshold (decimal string).",
                    "default": "1000",
                },
                "allowed_chain_families": {
                    "type": "array",
                    "description": "Chain families this wallet is allowed to operate on.",
                    "items": {"type": "string"},
                    "default": [],
                },
                "compliance_screening_enabled": {
                    "type": "boolean",
                    "description": "Toggle compliance screening.",
                    "default": True,
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Master toggle for the wallet policy.",
                    "default": False,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the wallet_policy_update Decision Trace.",
                },
            },
            "required": ["wallet_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policy set",
            "update wallet policy",
            "configure wallet",
        ],
    },
    {
        "name": "ww.wallet.transactions.list",
        "description": "List wallet transactions for the tenant (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Restrict to one wallet_id; omit to scan every wallet.",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "status": {
                    "type": "string",
                    "enum": ["pending", "signed", "denied", "failed"],
                    "description": "Filter by transaction status.",
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque pagination cursor returned by a previous call.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max rows per page (1..500).",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 50,
                },
            },
            "required": [],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet transactions",
            "tx inbox",
            "pending transactions",
        ],
    },
    {
        "name": "ww.wallet.transactions.sign",
        "description": "Preflight-gated sign of a pending wallet transaction (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tx_id": {
                    "type": "string",
                    "description": "Transaction id from transactions.list.",
                    "minLength": 1,
                },
                "wallet_id": {
                    "type": "string",
                    "description": "Optional wallet scope for the sign call.",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the Decision Trace.",
                },
            },
            "required": ["tx_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet sign transaction",
            "sign pending tx",
            "approve wallet payment",
        ],
    },
    # ── Cross-tenant Zara coordination (#3625 / family J) ──────────────
    {
        "name": "ww.zara.coordinate.send",
        "description": "Dispatch a directive to one other Zara in the caller's org.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "target_tenant_id": {
                    "type": "string",
                    "description": "Same-org tenant id to coordinate with.",
                    "minLength": 1,
                    "maxLength": 128,
                },
                "directive": {
                    "type": "string",
                    "description": "Directive payload (1..4096 chars).",
                    "minLength": 1,
                    "maxLength": 4096,
                },
                "intent_class": {
                    "type": "string",
                    "description": "Intent label propagated to the receiving Zara.",
                    "default": "KNOWLEDGE_WORK",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the coordination trace.",
                },
            },
            "required": ["target_tenant_id", "directive"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordinate",
            "delegate to zara",
            "cross-tenant directive",
        ],
    },
    {
        "name": "ww.zara.coordinate.show",
        "description": "Return merged status + lease view for one coordination.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "coordination_id": {
                    "type": "string",
                    "description": "Coordination id from a previous coordinate / broadcast call.",
                    "minLength": 1,
                },
            },
            "required": ["coordination_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordination status",
            "coordination show",
            "directive status",
        ],
    },
    {
        "name": "ww.zara.coordinate.broadcast",
        "description": "Broadcast a directive to every sub-tenant Zara in the caller's org.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "directive": {
                    "type": "string",
                    "description": "Directive payload (1..4096 chars).",
                    "minLength": 1,
                    "maxLength": 4096,
                },
                "intent_class": {
                    "type": "string",
                    "description": "Intent label propagated to receiving Zaras.",
                    "default": "KNOWLEDGE_WORK",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "target_emails": {
                    "type": "array",
                    "description": "Narrow the broadcast to specific sub-tenant owner emails.",
                    "items": {"type": "string"},
                    "maxItems": 128,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the coordination trace.",
                },
            },
            "required": ["directive"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordination broadcast",
            "fan-out directive",
            "broadcast to sub-tenants",
        ],
    },
    # ── Support tool (#2348) ───────────────────────────────────────────
    {
        "name": "ww.support.file_bug",
        "description": "File a support bug report ticket via MCP.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string", "description": "Bug summary / subject"},
                "category": {"type": "string", "description": "Bug category (e.g. email, calendar, payment)", "default": "general"},
                "evidence_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional evidence envelope IDs to attach",
                    "default": [],
                },
                "attach_decision_trace": {"type": "boolean", "description": "Attach decision trace context", "default": True},
            },
            "required": ["summary"],
        },
        "namespace": "ww",
        "category": "support",
        "callable": True,
        "intent_hints": ["file bug", "report bug", "support ticket", "bug report"],
    },
    # ── Support consent tool (#2342) ───────────────────────────────────
    {
        "name": "ww.support.consent",
        "description": "List or approve investigation consent envelopes for a workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "approve", "revoke", "check"],
                    "description": "Action to perform on investigation consent.",
                    "default": "list",
                },
                "tenant_id": {"type": "string", "description": "Workspace ID"},
                "investigation_id": {"type": "string", "description": "Filter by investigation ID (list action)"},
                "consent_id": {"type": "string", "description": "Consent envelope ID (approve/revoke/check action)"},
                "granted_by": {"type": "string", "description": "User granting consent (approve action)"},
                "scope": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Consent scopes: data_access, ticket_filing, agent_communication (approve action)",
                    "default": ["data_access"],
                },
                "duration_hours": {
                    "type": "integer",
                    "description": "Consent duration in hours (approve action)",
                    "default": 24,
                },
                "reason": {"type": "string", "description": "Revocation reason (revoke action)"},
            },
            "required": ["action", "tenant_id"],
        },
        "namespace": "ww",
        "category": "support",
        "callable": True,
        "intent_hints": [
            "investigation consent",
            "list consent",
            "approve consent",
            "revoke consent",
            "check consent",
            "support consent",
        ],
    },
    # ── Deployment profile tools (#2394) ──────────────────────────────
    {
        "name": "ww.profile.get",
        "description": "Return the current deployment profile configuration.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["profile", "deployment profile", "personal profile", "current profile"],
    },
    {
        "name": "ww.profile.set",
        "description": "Set the deployment profile for this workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "profile": {
                    "type": "string",
                    "description": "Profile name (solo_dogfood, self_host_production, managed_saas, local_native, personal_os)",
                    "enum": ["solo_dogfood", "self_host_production", "managed_saas", "local_native", "personal_os"],
                },
            },
            "required": ["profile"],
        },
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["set profile", "change profile", "switch profile"],
    },
    {
        "name": "ww.profile.list",
        "description": "List all available deployment profiles.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["list profiles", "available profiles", "deployment options"],
    },
    # ── Zara identity purposes (#2231) ────────────────────────────────
    {
        "name": "ww.identity.purposes",
        "description": "List Zara-owned provider identity purposes with readiness status.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID (default: zara)", "default": "zara"},
            },
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": ["identity purposes", "zara purposes", "provider identity", "agent purposes"],
    },
    {
        "name": "ww.identity.purpose_status",
        "description": "Get the provider identity status for a specific agent purpose.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID (default: zara)", "default": "zara"},
                "purpose": {
                    "type": "string",
                    "description": "Purpose to check (email_send, calendar_read, calendar_write, meeting_join, payment_initiate, payment_approve, voice_call, crypto_wallet)",
                },
            },
            "required": ["purpose"],
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": ["purpose status", "identity readiness", "provider auth"],
    },
    # ── Connector tools ───────────────────────────────────────────────────
    {
        "name": "ww.connector.import.openapi",
        "description": "Import an OpenAPI or Swagger document as a tenant-scoped connector.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "spec_url": {"type": "string", "description": "OpenAPI or Swagger spec URL."},
                "base_url": {"type": "string", "description": "Optional API base URL override."},
                "name": {"type": "string", "description": "Optional connector display name."},
                "description": {"type": "string", "description": "Optional connector description."},
                "auth": {
                    "type": "object",
                    "description": "Optional connector auth configuration.",
                    "default": {},
                },
            },
            "required": ["spec_url"],
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "import openapi connector",
            "openapi tool factory",
            "swagger connector import",
        ],
    },
    {
        "name": "ww.connector.health",
        "description": "Get per-connector health metrics: circuit breaker state, success rate, latency percentiles, retry budget.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {
                    "type": "string",
                    "description": "Connector ID to check. Omit to return health for all connectors.",
                },
            },
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "connector health",
            "circuit breaker",
            "connector uptime",
            "connector status",
            "connector metrics",
        ],
    },
    {
        "name": "ww.connector.status",
        "description": "Return the tenant connector availability map with setup commands and Decision Trace evidence.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "connector availability",
            "connectors status",
            "connector setup",
            "available connectors",
        ],
    },
    # Issue #3585: PM connector OAuth auth tool.
    {
        "name": "ww.connector.auth",
        "description": "Initiate OAuth2 authorization for a PM connector (JIRA, Linear, Asana, Trello). Returns the authorization URL to redirect the user to.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "provider": {
                    "type": "string",
                    "description": "PM provider key: jira, linear, asana, or trello.",
                },
                "redirect_uri": {
                    "type": "string",
                    "description": "Override OAuth callback URI. Defaults to the canonical Workweaver callback.",
                },
            },
            "required": ["provider"],
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "authorize connector",
            "connector oauth",
            "connector auth",
            "pm connector auth",
        ],
    },
    # -- Voice persona tools (#2798) --
    {
        "name": "ww.voice.persona.create",
        "description": "Create a new voice persona for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Persona display name"},
                "voice_id": {"type": "string", "description": "TTS voice identifier", "default": "ara"},
                "language": {"type": "string", "description": "Language code", "default": "en"},
                "speaking_rate": {"type": "number", "description": "TTS speed multiplier", "default": 1.0},
                "pitch": {"type": "number", "description": "TTS pitch adjustment", "default": 0.0},
                "from_template": {"type": "string", "description": "Template ID to seed from"},
            },
            "required": ["name"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["create voice persona", "new voice persona"],
    },
    {
        "name": "ww.voice.persona.clone.register",
        "description": "Register provider-backed ownership for a custom voice clone before using it in a persona.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "voice_id": {"type": "string", "description": "Custom voice clone identifier"},
                "name": {"type": "string", "description": "Clone display name"},
                "provider": {"type": "string", "description": "Clone provider", "default": "custom"},
                "provider_clone_id": {
                    "type": "string",
                    "description": "Provider clone identifier",
                    "minLength": 1,
                    "pattern": "\\S",
                },
                "proof_ref": {
                    "type": "string",
                    "description": "Ownership proof or evidence reference",
                    "minLength": 1,
                    "pattern": "\\S",
                },
                "description": {"type": "string", "description": "Clone description"},
            },
            "required": ["voice_id"],
            "anyOf": [
                {"required": ["provider_clone_id"]},
                {"required": ["proof_ref"]},
            ],
        },
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["register voice clone", "custom voice ownership", "voice clone proof"],
    },
    {
        "name": "ww.voice.persona.list",
        "description": "List all voice personas for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["list personas", "voice personas"],
    },
    {
        "name": "ww.voice.catalog.list",
        "description": "List built-in and tenant-owned cloned voices available to the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["list voices", "voice catalog", "available voices"],
    },
    {
        "name": "ww.voice.persona.get",
        "description": "Get a specific voice persona by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {"persona_id": {"type": "string", "description": "Persona ID"}},
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.update",
        "description": "Update fields on an existing voice persona.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "persona_id": {"type": "string", "description": "Persona ID"},
                "name": {"type": "string"}, "voice_id": {"type": "string"},
                "language": {"type": "string"}, "speaking_rate": {"type": "number"},
                "pitch": {"type": "number"}, "greeting_script": {"type": "string"},
                "hold_message": {"type": "string"}, "transfer_message": {"type": "string"},
            },
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.delete",
        "description": "Soft-delete a voice persona (sets disabled=true).",
        "inputSchema": {
            "type": "object",
            "properties": {"persona_id": {"type": "string", "description": "Persona ID"}},
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.templates",
        "description": "List available voice persona templates.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
    },
    # ------------------------------------------------------------------
    # TimeBlock CRUD primitive (W#2785 PR C) — MCP surface over the
    # canonical /api/v1/timeblocks REST API. UTC at rest; soft-delete
    # via state→CANCELLED transition; move is an atomic ledger update.
    # ------------------------------------------------------------------
    {
        "name": "ww.timeblock.list",
        "description": (
            "List TimeBlocks for the workspace. Supports filtering by workspace, "
            "owner, and UTC time window. Read-only — paginated projection over "
            "the canonical AgentWorkLedger. Mirrors GET /api/v1/timeblocks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Filter by workspace id (matches metadata.workspace_id).",
                },
                "since": {
                    "type": "string",
                    "description": "UTC lower bound (ISO 8601). Naive timestamps are interpreted as UTC.",
                },
                "until": {
                    "type": "string",
                    "description": "UTC upper bound (ISO 8601). Naive timestamps are interpreted as UTC.",
                },
                "owner": {
                    "type": "string",
                    "description": "Filter by TimeBlock owner_id (the canonical agent_id on the ledger row).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max items per page (default 50, max 500).",
                    "default": 50,
                    "minimum": 1,
                    "maximum": 500,
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque pagination cursor returned by the previous list call.",
                },
            },
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["list timeblocks", "show today's timeblocks", "agenda"],
    },
    {
        "name": "ww.timeblock.create",
        "description": (
            "Create a TimeBlock for an owner with a UTC start/end window and short "
            "title. Rejects on owner-window conflict unless force=true. The state "
            "change emits an audit-bearing Decision Trace via AgentWorkLedger. "
            "Mirrors POST /api/v1/timeblocks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace id (captured in metadata).",
                },
                "owner_id": {
                    "type": "string",
                    "description": "Owner member id (maps to canonical agent_id).",
                },
                "start_utc": {
                    "type": "string",
                    "description": "UTC start instant (ISO 8601).",
                },
                "end_utc": {
                    "type": "string",
                    "description": "UTC end instant (ISO 8601). Must be strictly after start_utc.",
                },
                "title": {
                    "type": "string",
                    "description": "Short objective for the block.",
                },
                "intent": {
                    "type": "string",
                    "description": "Optional plan / intent free text.",
                    "default": "",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection. Records forced_overlap=true in metadata.",
                    "default": False,
                },
            },
            "required": ["workspace_id", "owner_id", "start_utc", "end_utc", "title"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["create timeblock", "schedule a block", "block out time"],
    },
    {
        "name": "ww.timeblock.show",
        "description": (
            "Read a single TimeBlock by id. Returns the full envelope including "
            "owner, window, title, intent, state, outcome, canonical hour bucket, "
            "and metadata. Mirrors GET /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "TimeBlock id.",
                },
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["show timeblock", "view timeblock"],
    },
    {
        "name": "ww.timeblock.update",
        "description": (
            "Patch one TimeBlock — title, intent, or window. Time edits run owner "
            "conflict detection and reject on overlap unless force=true. Emits a "
            "Decision Trace via AgentWorkLedger. Mirrors PATCH /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
                "title": {
                    "type": "string",
                    "description": "Updated title (optional).",
                },
                "intent": {
                    "type": "string",
                    "description": "Updated plan / intent (optional).",
                },
                "start_utc": {
                    "type": "string",
                    "description": "Updated UTC start (ISO 8601). Triggers conflict detection.",
                },
                "end_utc": {
                    "type": "string",
                    "description": "Updated UTC end (ISO 8601). Triggers conflict detection.",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection on time edits.",
                    "default": False,
                },
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["update timeblock", "rename timeblock", "edit intent"],
    },
    {
        "name": "ww.timeblock.move",
        "description": (
            "Atomically move one TimeBlock to a new UTC window. The block_id and "
            "audit lineage stay stable (single ledger transition, not delete + "
            "create). Conflict-checked unless force=true. Mirrors "
            "POST /api/v1/timeblocks/{id}/move."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
                "new_start_utc": {
                    "type": "string",
                    "description": "New UTC start instant (ISO 8601).",
                },
                "new_end_utc": {
                    "type": "string",
                    "description": "New UTC end instant (ISO 8601). Must be strictly after new_start_utc.",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection.",
                    "default": False,
                },
            },
            "required": ["id", "new_start_utc", "new_end_utc"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["move timeblock", "reschedule timeblock"],
    },
    {
        "name": "ww.timeblock.delete",
        "description": (
            "Soft-delete one TimeBlock — flips state to CANCELLED and stamps "
            "ended_at. The audit row stays for traceability; hard-delete is not "
            "exposed. Mirrors DELETE /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["cancel timeblock", "delete timeblock"],
    },
    # ------------------------------------------------------------------
    # Chat router (Slices 9 + 11) — MCP twin of POST /api/v1/chat/route
    # + POST /api/v1/chat/rollback/{decision_id}.
    # ------------------------------------------------------------------
    {
        "name": "ww.chat.route",
        "description": (
            "Classify a chat message and return the ChatRouterDecision envelope. "
            "Composes safety guardrail + multi-intent splitter + rule-based "
            "classifier + LLM augmentation (xAI Grok when configured) + scope "
            "resolver. Latency budget: 600 ms p95 / 2.5 s ceiling. Mirrors "
            "POST /api/v1/chat/route."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "Raw user message text. Safety-checked before any LLM call.",
                },
                "thread_id": {
                    "type": "string",
                    "description": "Conversation thread identifier (durable across messages).",
                },
                "workspace_context": {
                    "type": "object",
                    "description": (
                        "Snapshot of what the user is looking at right now. "
                        "Fields: currently_open_card_id, currently_open_goal_id, "
                        "recently_viewed_card_ids, active_card_states "
                        "(card_id -> 'gated'/'running'/'pending_review'/'done'/'archived'/'failed')."
                    ),
                },
                "expected_state_hash": {
                    "type": "string",
                    "description": (
                        "For EXECUTE_NOW: hash of the target card's state at "
                        "classification time. The executor rejects + re-routes if "
                        "the card mutated since."
                    ),
                },
                "prior_scope": {
                    "type": "object",
                    "description": (
                        "Optional scope carryover hint for short / pronominal turns."
                    ),
                },
            },
            "required": ["message", "thread_id"],
        },
        "namespace": "ww",
        "category": "chat",
        "callable": True,
        "intent_hints": [
            "classify chat",
            "chat route",
            "route message",
            "what intent",
        ],
    },
    {
        "name": "ww.chat.rollback",
        "description": (
            "Reverse all card placements created by a KNOWLEDGE_WORK plan within "
            "the 5-minute undo window. Fails-closed with status='expired' after "
            "the window. Mirrors POST /api/v1/chat/rollback/{decision_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "Decision id from the original ChatRouterDecision.",
                },
                "actor": {
                    "type": "string",
                    "description": "Who initiated the rollback. Recorded in the decision trace.",
                    "default": "user",
                },
            },
            "required": ["decision_id"],
        },
        "namespace": "ww",
        "category": "chat",
        "callable": True,
        "intent_hints": ["rollback plan", "undo chat plan", "chat undo"],
    },
    {
        "name": "ww.admin.inference.audit_grid",
        "description": (
            "Read-only per-Purpose x per-tenant inference audit grid. "
            "Rows are Purpose enum values (e.g. workmemory.query_expansion, "
            "runtime.planner). Columns are enabled providers from the platform "
            "catalog. Cells contain cost_per_m_tokens, latency_p50_ms, "
            "latency_p95_ms, jurisdiction, call_count, total_cost_usd, "
            "total_tokens. Optional tenant_id and purpose filters narrow the "
            "view. The MCP path scopes audit data to the caller's tenant; "
            "platform-wide aggregation remains gated to the founder REST/CLI "
            "path. Mirrors GET /api/v1/founder/inference/audit-grid. "
            "Issue #3215."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": (
                        "Optional tenant ID to scope cost/latency data. "
                        "Omit to use the caller's tenant scope."
                    ),
                },
                "purpose": {
                    "type": "string",
                    "description": (
                        "Optional Purpose enum value (e.g. 'runtime.planner'). "
                        "When set, only that row is returned."
                    ),
                },
            },
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "inference audit grid",
            "per purpose per tenant audit",
            "provider audit dashboard",
            "ww admin inference audit-grid",
        ],
    },
    # Issue #3224: jurisdiction policy MCP surfaces.
    {
        "name": "ww.admin.jurisdiction.policy_show",
        "description": (
            "Read the current jurisdiction/provenance blocklist policy. "
            "Returns the list of blocked providers with reasons. Mirrors "
            "GET /api/v1/founder/inference/jurisdiction-policy."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "show jurisdiction policy",
            "blocked providers list",
            "inference jurisdiction",
        ],
    },
    {
        "name": "ww.admin.jurisdiction.policy_set",
        "description": (
            "Replace the jurisdiction/provenance blocklist with a new set of "
            "blocked providers. Each entry maps provider_id to block reason. "
            "Mirrors PUT /api/v1/founder/inference/jurisdiction-policy."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "providers": {
                    "type": "object",
                    "description": (
                        "Dict mapping provider_id to block reason. "
                        "Empty dict clears all blocks."
                    ),
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["providers"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "set jurisdiction policy",
            "block inference provider",
            "update jurisdiction blocklist",
        ],
    },
    # Issue #3209: per-Purpose × per-tenant embedding policy MCP surfaces.
    {
        "name": "ww.admin.embedding.policy_show",
        "description": (
            "Read the embedding policy. Provide tenant_id to show one tenant; "
            "omit it to list every policy (platform default + tenant overrides). "
            "Mirrors GET /api/v1/founder/embedding/policy[/{tenant_id}]."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": (
                        "Tenant id; '__platform__' for the global default. "
                        "Omit to list every policy."
                    ),
                },
            },
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "show embedding policy",
            "embedding model selection",
            "per purpose embedding overrides",
        ],
    },
    {
        "name": "ww.admin.embedding.policy_set",
        "description": (
            "Upsert the embedding policy for one tenant or the platform default "
            "('__platform__'). Mode chooses the routing baseline; "
            "per_purpose_overrides selectively pin a specific Purpose to a "
            "specific provider. Mirrors PUT /api/v1/founder/embedding/policy/{tenant_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": "Tenant id; '__platform__' for the global default.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["aws_only", "google_enabled", "dual_provider"],
                    "description": "Mode-based default routing.",
                },
                "per_purpose_overrides": {
                    "type": "object",
                    "description": (
                        "Optional per-Purpose provider overrides. Keys are Purpose "
                        "values (e.g. 'workmemory.embedding.text'); values are one "
                        "of bedrock-titan, bedrock-nova-multimodal, bedrock-cohere-v3, "
                        "gemini-embedding."
                    ),
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["tenant_id"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "set embedding policy",
            "select embedding model",
            "embedding per purpose override",
        ],
    },
    # Issue #3227: admin permissions list/grant/revoke surfaces.
    {
        "name": "ww.admin.permissions.list",
        "description": (
            "List admin role assignments (per-user → AdminRole) and the canonical "
            "role → permission catalog. Mirrors GET /api/v1/admin/permissions. "
            "Requires GOVERNANCE_READ permission."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "list admin permissions",
            "show admin roles",
            "who has admin access",
        ],
    },
    {
        "name": "ww.admin.permissions.grant",
        "description": (
            "Grant an AdminRole to a user. Cross-tenant write — requires "
            "platform_admin (GOVERNANCE_WRITE). Mirrors "
            "POST /api/v1/admin/permissions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "description": "Email of the user to grant a role to.",
                },
                "role": {
                    "type": "string",
                    "enum": [
                        "platform_admin",
                        "tenant_admin",
                        "support_observer",
                        "billing_observer",
                        "compliance_admin",
                    ],
                    "description": "AdminRole to assign.",
                },
                "notes": {
                    "type": "string",
                    "description": "Optional audit notes for the assignment.",
                    "default": "",
                },
            },
            "required": ["email", "role"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "grant admin role",
            "add admin",
            "promote user to admin",
        ],
    },
    {
        "name": "ww.admin.permissions.revoke",
        "description": (
            "Revoke a user's admin role assignment. Cross-tenant write — requires "
            "platform_admin (GOVERNANCE_WRITE). Mirrors "
            "DELETE /api/v1/admin/permissions/{email}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "description": "Email of the user whose role is being revoked.",
                },
            },
            "required": ["email"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": ["revoke admin role", "remove admin", "demote admin"],
    },
    # Issue #3236: CompletionGate MCP surface — mirrors the REST
    # POST /api/v1/swarm/steps/{step_id}/result route. Every invocation
    # emits a swarm.completion_gate.verdict decision trace and meters
    # verifier_judgment_tokens against the tenant.
    {
        "name": "ww.swarm.record_step_result",
        "description": (
            "Submit a terminal-status candidate for a swarm step. Routes "
            "through CompletionGate (verifier + success-criteria evaluator "
            "+ evidence isolation + optimistic-lock CAS). Returns the "
            "verifier verdict and commit outcome (committed / "
            "committed_replay / denied / conflict / isolation_violation)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "step_id": {
                    "type": "string",
                    "description": "Swarm step id to transition.",
                },
                "proposed_status": {
                    "type": "string",
                    "description": (
                        "Terminal status candidate. Non-terminal values "
                        "bypass the gate."
                    ),
                    "default": "completed",
                },
                "evidence_bundle": {
                    "type": "object",
                    "description": (
                        "Evidence dict wrapped in an "
                        "UntrustedContextEnvelope before reaching the "
                        "verifier. Must include matching tenant_id "
                        "(and function_id when supplied at the surface)."
                    ),
                    "default": {},
                },
                "evidence_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Evidence Ledger refs attached on commit.",
                    "default": [],
                },
                "function_id": {
                    "type": "string",
                    "description": "Optional function id for cross-function isolation.",
                    "default": "",
                },
                "completed_at": {
                    "type": "string",
                    "description": "ISO-8601 completion timestamp.",
                    "default": "",
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Caller chain captured in the decision trace.",
                    "default": [],
                },
            },
            "required": ["step_id"],
        },
        "namespace": "ww",
        "category": "swarm",
        "callable": True,
        "intent_hints": [
            "record swarm step result",
            "submit step completion",
            "verifier-as-gate",
            "completion gate",
        ],
    },
    # Issue #3238: success-criteria evaluator MCP surface — mirrors the REST
    # POST /api/v1/swarm/steps/{step_id}/criterion/evaluate route. Every
    # invocation emits a swarm.success_criteria.evaluated decision trace.
    {
        "name": "ww.swarm.success_criteria_eval",
        "description": (
            "Evaluate a swarm step success criterion against an evidence "
            "bundle. Returns passed / criteria_type / details and emits a "
            "swarm.success_criteria.evaluated decision trace."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "step_id": {
                    "type": "string",
                    "description": "Swarm step id the criterion belongs to.",
                },
                "criteria": {
                    "type": "object",
                    "description": (
                        "Criterion specification. Must include criteria_type "
                        "(tool_result, file_exists, api_response, threshold, "
                        "all_of, any_of) plus type-specific fields."
                    ),
                },
                "evidence": {
                    "type": "object",
                    "description": "Evidence bundle to evaluate against.",
                    "default": {},
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Caller chain captured in the decision trace.",
                    "default": [],
                },
            },
            "required": ["step_id", "criteria"],
        },
        "namespace": "ww",
        "category": "swarm",
        "callable": True,
        "intent_hints": [
            "evaluate success criterion",
            "swarm criterion check",
            "completion gate criterion",
        ],
    },
]


def _load_public_mcp_compatibility() -> list[dict[str, Any]]:
    try:
        registry = json.loads(_PARITY_JSON_PATH.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("public_mcp.compatibility_registry_unavailable", exc_info=True)
        return []
    table = registry.get("public_mcp_compatibility", [])
    return [row for row in table if isinstance(row, dict)]


def _derive_canonical_name(legacy_name: str) -> str:
    if legacy_name.startswith("workweaver."):
        return f"ww.{legacy_name[len('workweaver.') :]}"
    return legacy_name


def _legacy_to_canonical_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in _load_public_mcp_compatibility():
        legacy = row.get("legacy_tool")
        if not isinstance(legacy, str):
            continue
        canonical = row.get("canonical_tool")
        mapping[legacy] = (
            canonical if isinstance(canonical, str) and canonical.startswith("ww.") else _derive_canonical_name(legacy)
        )
    for tool in _LEGACY_PUBLIC_MCP_TOOLS:
        legacy = str(tool.get("name") or "")
        if legacy and legacy not in mapping:
            mapping[legacy] = _derive_canonical_name(legacy)
    return mapping


def _tool_category(tool_name: str) -> str:
    parts = tool_name.split(".")
    return parts[1] if len(parts) >= 3 else "tools"


def _slug(value: Any) -> str:
    raw = str(value or "").strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "_", raw).strip("_")
    return slug or "unknown"


def _load_parity_registry() -> dict[str, Any]:
    try:
        return json.loads(_PARITY_JSON_PATH.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("public_mcp.parity_registry_unavailable", exc_info=True)
        return {}


def _load_capability_registry_index() -> tuple[dict[str, Any], dict[tuple[str, str], Any]]:
    try:
        from apps.backend.services.capability_registry import load_capability_registry

        registry = load_capability_registry()
    except Exception:
        logger.warning("public_mcp.capability_registry_unavailable", exc_info=True)
        return {}, {}
    return registry.by_mcp_tool(), registry.by_family_action()


_CAPABILITY_BY_MCP_TOOL, _CAPABILITY_BY_FAMILY_ACTION = _load_capability_registry_index()


def _capability_metadata(
    *, tool_name: str | None = None, family: str | None = None, action: str | None = None
) -> dict[str, Any]:
    row = None
    if tool_name and (not family or not action):
        parts = str(tool_name).split(".")
        if len(parts) >= 3 and parts[0] == "ww":
            family = family or parts[1]
            action = action or ".".join(parts[2:])
    if family and action:
        row = _CAPABILITY_BY_FAMILY_ACTION.get((family, action))
    if row is None and tool_name:
        row = _CAPABILITY_BY_MCP_TOOL.get(tool_name)
    if row is None:
        return {}
    return {
        "capability_id": row.capability_id,
        "contract_id": row.contract_id,
        "owner": row.owner,
        "limitations": list(row.limitations),
        "deployment_profiles": list(row.deployment_profiles),
        "docs": list(row.docs),
        "tests": list(row.tests),
        "missing_surfaces": dict(row.missing_surfaces),
    }


def _compact_capability_metadata(tool: dict[str, Any]) -> dict[str, Any]:
    capability = tool.get("capability")
    if not isinstance(capability, dict):
        return {}
    return {key: capability[key] for key in ("capability_id", "contract_id", "owner") if key in capability}


def _index_capability_metadata(tool: dict[str, Any]) -> dict[str, Any]:
    metadata = _compact_capability_metadata(tool)
    if not metadata:
        return {}
    if metadata.get("owner") == "runtime-parity" and not metadata.get("limitations"):
        return {}
    metadata = {"capability_id": metadata["capability_id"]} if "capability_id" in metadata else {}
    return metadata


def _canonical_name_from_parity_row(family: str, subcommand: dict[str, Any]) -> str:
    declared = subcommand.get("mcp")
    if isinstance(declared, str) and declared.startswith("ww."):
        return declared
    return f"ww.{_slug(family)}.{_slug(subcommand.get('name'))}"


def _parity_catalog_tools() -> list[dict[str, Any]]:
    registry = _load_parity_registry()
    catalog: dict[str, dict[str, Any]] = {}
    for family_entry in registry.get("families", []):
        if not isinstance(family_entry, dict):
            continue
        family = str(family_entry.get("family") or "").strip()
        if not family:
            continue
        family_description = str(family_entry.get("description") or "").strip()
        for subcommand in family_entry.get("subcommands", []):
            if not isinstance(subcommand, dict):
                continue
            name = str(subcommand.get("name") or "").strip()
            if not name:
                continue
            canonical_tool_name = _canonical_name_from_parity_row(family, subcommand)
            tool_name = canonical_tool_name
            if tool_name in catalog:
                row_specific_name = f"ww.{_slug(family)}.{_slug(name)}"
                if row_specific_name != tool_name and row_specific_name not in catalog:
                    tool_name = row_specific_name
                else:
                    continue
            catalog.setdefault(
                tool_name,
                {
                    "name": tool_name,
                    "description": family_description or f"{family} {name}",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "parameters": {
                                "type": "object",
                                "description": "Command parameters for this parity surface.",
                                "default": {},
                            }
                        },
                    },
                    "namespace": "ww",
                    "category": family,
                    "callable": False,
                    "intent_hints": [f"{family} {name}", f"ww {family} {name}", canonical_tool_name],
                    "parity": {
                        "family": family,
                        "subcommand": name,
                        "canonical_mcp_tool": canonical_tool_name,
                        "backend": subcommand.get("backend"),
                        "ui": subcommand.get("ui"),
                    },
                    "capability": _capability_metadata(
                        tool_name=canonical_tool_name,
                        family=family,
                        action=name,
                    ),
                },
            )
    return [catalog[name] for name in sorted(catalog)]


def _canonicalize_live_public_tools() -> list[dict[str, Any]]:
    compatibility = {row.get("legacy_tool"): row for row in _load_public_mcp_compatibility()}
    legacy_to_canonical = _legacy_to_canonical_map()
    by_name: dict[str, dict[str, Any]] = {}

    for legacy_tool in _LEGACY_PUBLIC_MCP_TOOLS:
        legacy_name = str(legacy_tool.get("name") or "")
        canonical_name = legacy_to_canonical.get(legacy_name, _derive_canonical_name(legacy_name))
        tool = deepcopy(legacy_tool)
        tool["name"] = canonical_name
        if canonical_name == "ww.evidence.trace":
            tool["description"] = "Return the hydrated Decision Trace for a WorkItem, task, goal, or subject."
            tool["inputSchema"] = {
                "type": "object",
                "properties": {
                    "workitem_id": {"type": "string", "description": "WorkItem ID to trace"},
                    "task_id": {"type": "string", "description": "Task ID to trace"},
                    "goal_id": {"type": "string", "description": "Goal ID to trace"},
                    "subject_id": {"type": "string", "description": "Generic subject ID to trace"},
                    "subject_type": {"type": "string", "description": "Subject type for generic subject IDs"},
                    "limit": {"type": "integer", "description": "Max decisions to scan", "default": 50},
                },
            }
        aliases = list(dict.fromkeys([*(tool.get("aliases") or []), legacy_name]))
        tool["aliases"] = aliases
        tool["legacyAliases"] = aliases
        tool["namespace"] = "ww"
        tool["category"] = _tool_category(canonical_name)
        tool["callable"] = True
        tool["intent_hints"] = [
            canonical_name.replace(".", " "),
            str(tool.get("description") or ""),
            *aliases,
        ]
        if row := compatibility.get(legacy_name):
            family = row.get("parity_family")
            action = row.get("parity_subcommand")
            tool["parity"] = {
                "family": family,
                "subcommand": action,
                "status": row.get("status"),
                "owner_issue": row.get("owner_issue"),
            }
            tool["capability"] = _capability_metadata(
                tool_name=canonical_name,
                family=family if isinstance(family, str) else None,
                action=action if isinstance(action, str) else None,
            )
        else:
            tool["capability"] = _capability_metadata(tool_name=canonical_name)

        existing = by_name.get(canonical_name)
        if existing is None:
            by_name[canonical_name] = tool
            continue

        existing_aliases = list(existing.get("aliases") or [])
        existing_aliases.extend(alias for alias in aliases if alias not in existing_aliases)
        existing["aliases"] = existing_aliases
        existing["legacyAliases"] = existing_aliases

        # If two legacy aliases converge on one canonical name, keep the richer schema.
        existing_schema_size = len(json.dumps(existing.get("inputSchema") or {}, sort_keys=True))
        candidate_schema_size = len(json.dumps(tool.get("inputSchema") or {}, sort_keys=True))
        if candidate_schema_size > existing_schema_size:
            tool["aliases"] = existing_aliases
            tool["legacyAliases"] = existing_aliases
            by_name[canonical_name] = tool

    return [by_name[name] for name in sorted(by_name)]


def _tool_search_tool_schema() -> dict[str, Any]:
    return {
        "name": _TOOL_SEARCH_NAME,
        "description": "Search the Workweaver MCP tool catalog by natural-language intent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "description": "Natural-language action or goal to resolve"},
                "limit": {"type": "integer", "description": "Maximum matches to return", "default": 5},
            },
            "required": ["intent"],
        },
        "namespace": "ww",
        "category": "tools",
        "callable": True,
    }


_WORKFLOW_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.workflow.template.list",
        "description": "List backend-owned workflow saga templates.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["workflow templates", "list saga templates"],
    },
    {
        "name": "ww.workflow.template.show",
        "description": "Show one backend-owned workflow saga template.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {"type": "string", "description": "Workflow template ID."},
            },
            "required": ["template_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["show workflow template", "inspect saga template"],
    },
    {
        "name": "ww.workflow.saga.run",
        "description": "Run a workflow template as an idempotent workspace-scoped saga.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {"type": "string", "description": "Workflow template ID."},
                "idempotency_key": {"type": "string", "description": "Retry key for exactly-once saga start."},
                "actor_id": {"type": "string", "description": "Actor starting the saga.", "default": "mcp"},
                "initial_data": {"type": "object", "description": "Initial saga input payload."},
                "fail_step_id": {"type": "string", "description": "Test-only failure injection step ID."},
            },
            "required": ["template_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["run workflow saga", "start workflow template"],
    },
    {
        "name": "ww.workflow.saga.status",
        "description": "Return a workflow saga run status and Decision Trace events.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "Workflow saga run ID."},
            },
            "required": ["run_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["workflow saga status", "saga decision trace"],
    },
    {
        "name": "ww.workflow.saga.compensate",
        "description": "Compensate a workflow saga run and record the transition trace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "Workflow saga run ID."},
                "reason": {"type": "string", "description": "Compensation reason.", "default": "manual_compensation"},
                "actor_id": {"type": "string", "description": "Actor compensating the saga.", "default": "mcp"},
            },
            "required": ["run_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["compensate workflow saga", "rollback workflow run"],
    },
]


def _inference_manifest_tools() -> list[dict[str, Any]]:
    """Manifest-driven inference family tools (#3508).

    Returns the ``ww.inference.*`` and ``ww.admin.inference.*`` tool schemas
    generated from ``apps/cli/ww/commands/inference_manifest.yaml``. Tools
    whose names already exist in ``_NATIVE_PUBLIC_MCP_TOOLS`` (e.g. the
    legacy ``ww.admin.inference.audit_grid``) are skipped so the live tool
    definition wins.
    """

    from apps.backend.api.inference_mcp_tools import inference_mcp_tools

    existing = {str(t.get("name") or "") for t in _NATIVE_PUBLIC_MCP_TOOLS}
    return [t for t in inference_mcp_tools() if t["name"] not in existing]


def _workspace_public_description(text: str) -> str:
    """Rewrite internal tenancy vocabulary in public MCP descriptions."""
    replacements = (
        ("ww.tenant.conflicts.list", "the conflict list tool"),
        ("tenant_config", "workspace config"),
        ("target_tenant_id", "target_workspace_id"),
        ("source_tenant_id", "source_workspace_id"),
        ("tenant_override", "workspace_override"),
        ("tenant_id", "workspace_id"),
        ("TenantProviderProfile", "WorkspaceProviderProfile"),
        ("sub-tenant", "child workspace"),
        ("Sub-tenant", "Child workspace"),
        ("cross-tenant", "cross-workspace"),
        ("Cross-tenant", "Cross-workspace"),
        ("multi-tenant", "multi-workspace"),
        ("Multi-tenant", "Multi-workspace"),
        ("tenant-owned", "workspace-owned"),
        ("Tenant-owned", "Workspace-owned"),
        ("tenant_billing", "workspace billing"),
    )
    cleaned = text
    for old, new in replacements:
        cleaned = cleaned.replace(old, new)
    cleaned = re.sub(r"\bTenant\b", "Workspace", cleaned)
    cleaned = re.sub(r"\btenant\b", "workspace", cleaned)
    cleaned = re.sub(r"\bTenants\b", "Workspaces", cleaned)
    cleaned = re.sub(r"\btenants\b", "workspaces", cleaned)
    return cleaned


def _sanitize_public_mcp_text(value: Any, *, sanitize_strings: bool = False) -> Any:
    """Return a copy with customer-visible MCP text using Workspace language."""
    if isinstance(value, list):
        return [_sanitize_public_mcp_text(item, sanitize_strings=sanitize_strings) for item in value]
    if isinstance(value, dict):
        sanitized: dict[str, Any] = {}
        for key, item in value.items():
            if key in {"description", "intent_hints"}:
                sanitized[key] = _sanitize_public_mcp_text(item, sanitize_strings=True)
            else:
                sanitized[key] = _sanitize_public_mcp_text(item)
        return sanitized
    if isinstance(value, str):
        return _workspace_public_description(value) if sanitize_strings else value
    return value


# Issue #3542: WorkspacePersonaOverlay (safe SOUL.md analog).
# Read+write operations on the tenant's persona overlay. Mutations emit an
# identity-class Decision Trace via the service layer; reads do not.
_PERSONA_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.workspace.persona.show",
        "description": "Read the workspace persona overlay (identity/presence/vocabulary/routing_biases/language). Kernel envelope is unaffected.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "show persona",
            "workspace persona",
            "get persona overlay",
        ],
    },
    {
        "name": "ww.workspace.persona.set",
        "description": "Set or replace the workspace persona overlay. Validator refuses kernel/policy/governance/floor keys.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_version": {"type": "string", "enum": ["v1"]},
                "identity": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "voice_id": {"type": "string"},
                        "voice_tone": {
                            "type": "string",
                            "enum": ["warm", "neutral", "crisp", "formal"],
                        },
                    },
                    "required": ["name"],
                },
                "presence": {
                    "type": "object",
                    "properties": {
                        "default_channel": {
                            "type": "string",
                            "enum": [
                                "voice",
                                "email",
                                "slack",
                                "whatsapp",
                                "sms",
                                "dashboard",
                            ],
                        },
                        "work_hours": {"type": "object"},
                        "timezone": {"type": "string"},
                    },
                },
                "vocabulary": {
                    "type": "object",
                    "properties": {
                        "brand_terms": {"type": "array", "items": {"type": "string"}},
                        "forbidden_terms": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                },
                "routing_biases": {
                    "type": "object",
                    "properties": {
                        "prefer_channel_outside_hours": {"type": "string"},
                        "summary_length_preference": {
                            "type": "string",
                            "enum": ["terse", "standard", "detailed"],
                        },
                    },
                },
                "language": {
                    "type": "object",
                    "properties": {
                        "primary": {"type": "string"},
                        "fallback_locale": {"type": "string"},
                    },
                },
            },
            "required": ["identity"],
        },
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "set persona",
            "workspace persona overlay",
            "brand zara",
        ],
    },
    {
        "name": "ww.workspace.persona.reset",
        "description": "Reset the workspace persona overlay to defaults (delete the row).",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "reset persona",
            "delete persona overlay",
            "restore default persona",
        ],
    },
]

_LEGACY_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_LEGACY_PUBLIC_MCP_TOOLS)
_NATIVE_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_NATIVE_PUBLIC_MCP_TOOLS)
_WORKFLOW_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_WORKFLOW_PUBLIC_MCP_TOOLS)
_PERSONA_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_PERSONA_PUBLIC_MCP_TOOLS)

PUBLIC_MCP_TOOLS: list[dict[str, Any]] = _sanitize_public_mcp_text([
    *_canonicalize_live_public_tools(),
    *_NATIVE_PUBLIC_MCP_TOOLS,
    *_inference_manifest_tools(),
    *CALENDAR_MCP_TOOLS,
    *PLACES_MCP_TOOLS,
    *_WORKFLOW_PUBLIC_MCP_TOOLS,
    *_PERSONA_PUBLIC_MCP_TOOLS,
    _tool_search_tool_schema(),
])
_PUBLIC_MCP_CATALOG_TOOLS: list[dict[str, Any]] = []
_catalog_seen: set[str] = set()
for _tool in [*PUBLIC_MCP_TOOLS, *_parity_catalog_tools()]:
    _name = str(_tool.get("name") or "")
    if not _name or _name in _catalog_seen:
        continue
    if live_tool := next((tool for tool in PUBLIC_MCP_TOOLS if tool.get("name") == _name), None):
        _PUBLIC_MCP_CATALOG_TOOLS.append(live_tool)
    else:
        _PUBLIC_MCP_CATALOG_TOOLS.append(_sanitize_public_mcp_text(_tool))
    _catalog_seen.add(_name)
_LEGACY_TO_CANONICAL = _legacy_to_canonical_map()
_CANONICAL_TO_LEGACY: dict[str, str] = {}
for _legacy_name, _canonical_name in _LEGACY_TO_CANONICAL.items():
    _CANONICAL_TO_LEGACY.setdefault(_canonical_name, _legacy_name)
_PUBLIC_TOOL_BY_NAME: dict[str, dict[str, Any]] = {}
for _tool in PUBLIC_MCP_TOOLS:
    _PUBLIC_TOOL_BY_NAME[str(_tool["name"])] = _tool
    for _alias in _tool.get("aliases") or []:
        _PUBLIC_TOOL_BY_NAME[str(_alias)] = _tool
_PUBLIC_CATALOG_TOOL_BY_NAME = {str(_tool["name"]): _tool for _tool in _PUBLIC_MCP_CATALOG_TOOLS}


def canonical_public_mcp_tool_name(tool_name: str) -> str | None:
    """Return the canonical ``ww.*`` name for a public MCP tool or alias."""

    if tool_name == _TOOL_SEARCH_NAME:
        return tool_name
    if tool_name in _LEGACY_TO_CANONICAL:
        return _LEGACY_TO_CANONICAL[tool_name]
    if tool_name in _PUBLIC_TOOL_BY_NAME:
        return str(_PUBLIC_TOOL_BY_NAME[tool_name]["name"])
    return None


def is_public_mcp_tool(tool_name: str) -> bool:
    return canonical_public_mcp_tool_name(tool_name) is not None


def _legacy_dispatch_name(tool_name: str) -> str:
    canonical = canonical_public_mcp_tool_name(tool_name)
    if canonical is None:
        return tool_name
    return _CANONICAL_TO_LEGACY.get(canonical, tool_name)


def get_public_mcp_tool_schema(tool_name: str) -> dict[str, Any]:
    """Return the canonical tool schema for a public MCP tool or compatibility alias."""

    canonical = canonical_public_mcp_tool_name(tool_name)
    if canonical is None and tool_name not in _PUBLIC_CATALOG_TOOL_BY_NAME:
        raise KeyError(tool_name)
    return deepcopy(_PUBLIC_TOOL_BY_NAME.get(canonical or "") or _PUBLIC_CATALOG_TOOL_BY_NAME[tool_name])


def get_public_mcp_tool_index() -> list[dict[str, Any]]:
    """Return progressive-disclosure index rows without full JSON schemas.

    The catalog is intentionally compact: default ``ww`` namespace and callable
    tools are implied so tool growth does not force agents to download repeated
    metadata before asking for the one schema they need.
    """

    rows: list[dict[str, Any]] = []
    for tool in _PUBLIC_MCP_CATALOG_TOOLS:
        description = str(tool.get("description", ""))
        row = {
            "name": tool["name"],
            "description": description if len(description) <= 120 else f"{description[:117]}...",
            "category": tool.get("category", _tool_category(str(tool["name"]))),
        }
        if (namespace := tool.get("namespace", "ww")) != "ww":
            row["namespace"] = namespace
        if not bool(tool.get("callable", True)):
            row["callable"] = False
        if capability := _index_capability_metadata(tool):
            row["capability"] = capability
        rows.append(row)
    return rows


_SEARCH_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _search_text(tool: dict[str, Any]) -> str:
    schema = tool.get("inputSchema") if isinstance(tool.get("inputSchema"), dict) else {}
    properties = schema.get("properties") if isinstance(schema, dict) else {}
    prop_bits: list[str] = []
    if isinstance(properties, dict):
        for prop_name, prop_schema in properties.items():
            prop_bits.append(str(prop_name))
            if isinstance(prop_schema, dict):
                prop_bits.append(str(prop_schema.get("description") or ""))
                enum_values = prop_schema.get("enum") or []
                for ev in enum_values:
                    prop_bits.append(str(ev))
    aliases = " ".join(str(alias) for alias in tool.get("aliases") or [])
    return " ".join(
        [
            str(tool.get("name") or ""),
            aliases,
            str(tool.get("description") or ""),
            str(tool.get("category") or ""),
            " ".join(prop_bits),
        ]
    ).lower()


def _tokens(value: str) -> set[str]:
    return set(_SEARCH_TOKEN_RE.findall(value.lower()))


def search_public_mcp_tools(intent: str, *, limit: int = 5) -> list[dict[str, Any]]:
    """Rank public MCP tools by deterministic lexical match against an intent."""

    query = str(intent or "").strip()
    if not query:
        return []
    query_tokens = _tokens(query)
    scored: list[tuple[int, dict[str, Any]]] = []
    for tool in _PUBLIC_MCP_CATALOG_TOOLS:
        name = str(tool.get("name") or "")
        text = _search_text(tool)
        text_tokens = _tokens(text)
        overlap = len(query_tokens & text_tokens)
        score = overlap * 10
        compact_query = query.lower().replace(" ", ".")
        if compact_query and compact_query in name:
            score += 50
        if any(token in name for token in query_tokens):
            score += 15
        if score:
            scored.append((score, tool))

    ranked = sorted(scored, key=lambda item: (-item[0], str(item[1].get("name") or "")))[: max(1, limit)]
    return [
        {
            "tool_id": tool["name"],
            "name": tool["name"],
            "description": tool.get("description", ""),
            "category": tool.get("category", _tool_category(str(tool["name"]))),
            "score": score,
            "aliases": list(tool.get("aliases") or []),
            "capability": _compact_capability_metadata(tool),
        }
        for score, tool in ranked
    ]


def _dispatch_inbox_conversations(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    from apps.backend.api.inbox import list_conversations

    result = list_conversations(
        tenant_id=tenant_id,
        channel=str(parameters.get("channel") or "").strip() or None,
        limit=int(parameters.get("limit") or 50),
        offset=int(parameters.get("offset") or 0),
    )
    return {"tenant_id": tenant_id, **result}


def _get_swarm_tool_discovery_service() -> Any:
    from apps.backend.services.swarm.tool_discovery import SwarmToolDiscoveryService
    from apps.backend.services.unified_capability_gate import get_unified_capability_gate

    return SwarmToolDiscoveryService(permission_gate=get_unified_capability_gate())


def _plain_swarm_tool_value(value: Any) -> Any:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, list):
        return [_plain_swarm_tool_value(item) for item in value]
    if isinstance(value, dict):
        return value
    return value


def _dispatch_swarm_tool_search(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    service = _get_swarm_tool_discovery_service()
    tools = service.search_tools(
        tenant_id=tenant_id,
        agent_id=str(parameters.get("agent_id") or "").strip(),
        query=str(parameters.get("query") or "").strip(),
        modality=str(parameters.get("modality") or "").strip() or None,
        limit=int(parameters.get("limit") or 10),
    )
    rows = _plain_swarm_tool_value(tools)
    return {"tenant_id": tenant_id, "tools": rows, "count": len(rows)}


def _dispatch_swarm_tool_activation(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    service = _get_swarm_tool_discovery_service()
    idempotency_key = str(parameters.get("idempotency_key") or "").strip()
    if not idempotency_key:
        return {
            "tool_name": str(parameters.get("tool_name") or "").strip(),
            "activated": False,
            "policy_verdict": "DENY",
            "reason": "idempotency_key is required",
            "decision_trace_id": None,
            "permission_lease": None,
        }
    result = service.activate_tool(
        tenant_id=tenant_id,
        agent_id=str(parameters.get("agent_id") or "").strip(),
        tool_name=str(parameters.get("tool_name") or "").strip(),
        search_query=str(parameters.get("search_query") or "").strip() or None,
        ttl_seconds=int(parameters.get("ttl_seconds") or 300),
        actor_chain=[str(item) for item in parameters.get("actor_chain") or []] or None,
        idempotency_key=idempotency_key,
    )
    return _plain_swarm_tool_value(result)


def _dispatch_skill_import(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    from apps.backend.models.skill_source import SkillSourceImportRequest
    from apps.backend.services.skills.skill_source_importer import SkillSourceImportError, run_skill_source_import

    request = SkillSourceImportRequest(
        workspace_id=str(parameters.get("workspace_id") or tenant_id),
        origin=parameters.get("origin"),
        origin_kind=parameters.get("origin_kind"),
        dry_run=parameters.get("dry_run", True),
        customize=parameters.get("customize", False),
        reject_on_warning=parameters.get("reject_on_warning", False),
        customization_overlay=parameters.get("customization_overlay"),
    )
    if request.workspace_id != tenant_id:
        return {
            "accepted": False,
            "dry_run": request.dry_run,
            "skill_source": None,
            "decision_trace_id": None,
            "rejection_reason": "workspace_id must match authenticated tenant_id",
        }
    try:
        return run_skill_source_import(request).model_dump(mode="json")
    except SkillSourceImportError as exc:
        return {
            "accepted": False,
            "dry_run": request.dry_run,
            "skill_source": None,
            "decision_trace_id": None,
            "rejection_reason": str(exc),
        }


_SKILL_CURATOR_STATUSES = frozenset({"pending", "accepted", "rejected", "deferred"})
_SKILL_CURATOR_DECISIONS = frozenset({"accept", "reject", "defer"})
_SYNTHETIC_SKILL_CURATOR_DECISION_ACTORS = frozenset(
    {"mcp", "agent", "agent:mcp", "zara", "system"}
)
_SKILL_CURATOR_WEIGHT_FIELDS = frozenset(
    {"usage", "pass_rate", "recency", "consolidation", "richness"}
)


def _get_skill_curator_service():  # noqa: ANN201
    from apps.backend.services.skills.skill_hygiene_service import SkillHygieneService

    return SkillHygieneService()


def _skill_curator_workspace_error(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, str] | None:
    workspace_id = str(parameters.get("workspace_id") or tenant_id).strip()
    if workspace_id != tenant_id:
        return {
            "status": "error",
            "error": "workspace_id must match authenticated tenant_id",
        }
    return None


def _skill_curator_plain_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if hasattr(value, "dict"):
        return value.dict()
    return dict(value)


def _skill_curator_run_payload(run: Any) -> dict[str, Any]:
    payload = _skill_curator_plain_dict(run)
    proposals = [
        _skill_curator_plain_dict(proposal)
        for proposal in payload.get("proposals", [])
    ]
    payload["proposals"] = proposals
    payload["proposal_count"] = int(payload.get("proposal_count") or len(proposals))
    return payload


def _skill_curator_proposal_payload(proposal: Any) -> dict[str, Any]:
    return _skill_curator_plain_dict(proposal)


def _valid_skill_curator_decision_actor(actor_id: str) -> bool:
    normalized = actor_id.strip().lower()
    return bool(actor_id.strip()) and normalized not in _SYNTHETIC_SKILL_CURATOR_DECISION_ACTORS


def _skill_curator_decision_actor_from_proof(
    side_effect_proof: dict[str, Any] | None,
) -> tuple[str | None, dict[str, Any] | None]:
    actor_id = str((side_effect_proof or {}).get("actor_id") or "").strip()
    if not _valid_skill_curator_decision_actor(actor_id):
        return None, {
            "status": "proof_required",
            "error": "Skill Curator decisions require side_effect_proof.actor_id for an accountable member or agent actor",
        }
    return actor_id, None


def _skill_curator_weights(parameters: dict[str, Any]) -> Any:
    raw = parameters.get("weights")
    if raw in (None, ""):
        return None
    if not isinstance(raw, dict):
        raise ValueError("weights must be an object")
    unknown = set(raw) - _SKILL_CURATOR_WEIGHT_FIELDS
    if unknown:
        raise ValueError(f"unsupported weight field(s): {', '.join(sorted(unknown))}")
    from apps.backend.services.skills.skill_hygiene_service import SkillCuratorWeights

    return SkillCuratorWeights(
        **{
            key: float(value)
            for key, value in raw.items()
            if key in _SKILL_CURATOR_WEIGHT_FIELDS and value is not None
        }
    )


def _dispatch_skill_curator_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    if workspace_error := _skill_curator_workspace_error(tenant_id, parameters):
        return workspace_error
    service = _get_skill_curator_service()

    if tool_name == "ww.skill.curator.run":
        try:
            weights = _skill_curator_weights(parameters)
        except ValueError as exc:
            return {"status": "error", "error": str(exc)}
        run = service.run_curator(tenant_id, weights=weights)
        return _skill_curator_run_payload(run)

    if tool_name == "ww.skill.curator.latest":
        run = service.latest_curator_run(tenant_id)
        if run is None:
            return {"status": "not_found", "error": "No Skill Curator run found"}
        return _skill_curator_run_payload(run)

    if tool_name == "ww.skill.curator.list":
        status_filter = parameters.get("status")
        status_value = str(status_filter).strip() if status_filter not in (None, "") else None
        if status_value is not None and status_value not in _SKILL_CURATOR_STATUSES:
            return {
                "status": "error",
                "error": "status must be one of pending, accepted, rejected, deferred",
            }
        proposals = service.list_curator_proposals(tenant_id, status=status_value)
        serialized = [_skill_curator_proposal_payload(proposal) for proposal in proposals]
        return {"proposals": serialized, "count": len(serialized)}

    if tool_name == "ww.skill.curator.respond":
        proposal_id = str(parameters.get("proposal_id") or "").strip()
        if not proposal_id:
            return {"status": "error", "error": "proposal_id is required"}
        decision = str(parameters.get("decision") or "").strip()
        if decision not in _SKILL_CURATOR_DECISIONS:
            return {"status": "error", "error": "decision must be one of accept, reject, defer"}
        actor_id = str(parameters.get("actor_id") or "").strip()
        if not _valid_skill_curator_decision_actor(actor_id):
            return {
                "status": "error",
                "error": "actor_id is required for an accountable member or agent actor",
            }
        try:
            proposal = service.decide_curator_proposal(
                tenant_id,
                proposal_id,
                decision=decision,
                actor_id=actor_id,
                reason=str(parameters.get("reason") or ""),
            )
        except KeyError as exc:
            return {"status": "error", "error": str(exc)}
        return _skill_curator_proposal_payload(proposal)

    raise ValueError(f"Unknown Skill Curator MCP tool: {tool_name}")

# =====================================================================# MCP Tool Dispatch
# =====================================================================
# Map tool name -> handler function name in _PublicApiService
_TOOL_DISPATCH: dict[str, str] = {
    "workweaver.task.create": "create_task",
    "workweaver.task.status": "get_task_status",
    "workweaver.agent.list": "list_agents",
    "workweaver.agent.run": "run_agent",
    "ww.session.intake_queue.status": "session_intake_queue_status",
    "workweaver.schedule.create": "create_schedule",
    "workweaver.schedule.trigger": "trigger_schedule",
    "workweaver.evidence.query": "query_evidence",
    "ww.evidence.trace": "evidence_trace",
    "workweaver.approval.list": "list_approvals",
    "workweaver.approval.approve": "approve_action",
    "workweaver.approval.reject": "reject_action",
    "ww.inbox.list": "list_approvals",
    "ww.inbox.approve": "approve_action",
    "ww.inbox.reject": "reject_action",
    # Connector tools
    "workweaver.connector.install": "connector_install",
    "ww.connector.import.openapi": "connector_import_openapi",
    "workweaver.connector.execute": "connector_execute",
    "workweaver.connector.list": "connector_list",
    "ww.connector.health": "connector_health",
    "ww.connector.status": "connector_status",
    "ww.connector.auth": "connector_auth",
    "ww.research.search": "research_search",
    "ww.browser.run": "browser_run",
    "ww.browser.sandbox_evaluate": "browser_sandbox_evaluate",
    "ww.browser.sandbox_policy": "browser_sandbox_policy",
    # Issue #3227: admin permissions surfaces.
    "ww.admin.permissions.list": "admin_permissions_list",
    "ww.admin.permissions.grant": "admin_permissions_grant",
    "ww.admin.permissions.revoke": "admin_permissions_revoke",
    "ww.operational_context.show": "operational_context_show",
    "ww.operational_context.workspace": "operational_context_workspace",
    "ww.operational_context.share": "operational_context_share",
    # CLI capability wrappers
    "workweaver.mission.list": "mission_list",
    "workweaver.plan.list": "plan_list",
    "workweaver.plan.show": "plan_show",
    "workweaver.plan.steer": "plan_steer",
    "workweaver.mission.steer": "mission_steer",
    "ww.plan.list": "plan_list",
    "ww.plan.show": "plan_show",
    "ww.plan.steer": "plan_steer",
    "ww.mission.steer": "mission_steer",
    "ww.mission.outcome_review": "mission_outcome_review",
    "ww.mission.admission": "mission_admission_show",
    "ww.mission.breaker": "mission_breaker_show_or_reset",
    "ww.mission.reversal.request": "mission_reversal_request",
    "ww.strategy.trace": "strategy_trace",
    "workweaver.workitem.create": "workitem_create",
    "workweaver.memory.store": "memory_store",
    "workweaver.config.get": "config_get",
    "workweaver.entity.list": "entity_list",
    "ww.ontology.query": "ontology_query",
    "ww.entity_schema.create": "entity_schema_create",
    "ww.entity_schema.list": "entity_schema_list",
    "ww.entity_schema.get": "entity_schema_get",
    "ww.entity_schema.activate": "entity_schema_activate",
    "ww.entity.record.create": "entity_record_create",
    "ww.entity.record.get": "entity_record_get",
    "ww.entity.record.list": "entity_record_list",
    "ww.entity.record.update": "entity_record_update",
    "ww.entity.record.schema": "entity_record_schema",
    "ww.identity.readiness": "agent_identity_readiness",
    "ww.agent.identity": "agent_identity_status",
    "ww.identity.purposes": "agent_identity_purposes",
    "ww.identity.purpose_status": "agent_identity_purpose_status",
    "ww.entity.conflicts": "entity_conflicts",
    "ww.entity.conflict.resolve": "entity_conflict_resolve",
    "ww.swarm.status": "swarm_status",
    "ww.swarm.spawn": "swarm_spawn",
    "ww.swarm.cancel": "swarm_cancel",
    "ww.swarm.record_step_result": "swarm_record_step_result",
    "ww.swarm.success_criteria_eval": "swarm_success_criteria_eval",
    "ww.swarm.constitution.create": "swarm_constitution_create",
    "ww.swarm.constitution.list": "swarm_constitution_list",
    "ww.swarm.constitution.get": "swarm_constitution_get",
    "ww.swarm.constitution.update": "swarm_constitution_update",
    "ww.swarm.constitution.activate": "swarm_constitution_activate",
    "ww.swarm.constitution.deactivate": "swarm_constitution_deactivate",
    "ww.swarm.constitution.delete": "swarm_constitution_delete",
    "ww.swarm.constitution.active": "swarm_constitution_active",
    "ww.workflow.template.list": "workflow_template_list",
    "ww.workflow.template.show": "workflow_template_show",
    "ww.workflow.saga.run": "workflow_saga_run",
    "ww.workflow.saga.status": "workflow_saga_status",
    "ww.workflow.saga.compensate": "workflow_saga_compensate",
    "ww.pulse.list": "pulse_list",
    "ww.upgrades.list": "upgrades_list",
    "ww.upgrades.approve": "upgrades_approve",
    "ww.upgrades.pilot": "upgrades_pilot",
    "ww.upgrades.dismiss": "upgrades_dismiss",
    "ww.agent.di": "agent_di",
    "ww.compound.trajectory": "compound_trajectory",
    "ww.precedent.predict": "precedent_predict",
    "ww.decision.search": "decision_search",
    "workweaver.org.audit_log": "org_audit_log",
    # Support (#2348)
    "ww.support.file_bug": "support_file_bug",
    # Support consent (#2342)
    "ww.support.consent": "support_consent",
    # Wallet (#2366) — read-only tools dispatched via _TOOL_DISPATCH;
    # write tools (sign, broadcast) dispatched directly in dispatch_mcp_tool
    "ww.wallet.readiness": "wallet_readiness",
    "ww.wallet.policy": "wallet_policy",
    "ww.wallet.address": "wallet_address",
    "ww.wallet.balance": "wallet_balance",
    "ww.wallet.tx_list": "wallet_tx_list",
    "ww.wallet.tx_get": "wallet_tx_get",
    "ww.wallet.custody_status": "wallet_custody_status",
    # Wallet write tools — kept in _TOOL_DISPATCH for legacy name resolution
    "ww.wallet.sign": "wallet_sign",
    "ww.wallet.broadcast": "wallet_broadcast",
    # Multi-wallet parity (#3625 / slice 8e). The startswith("ww.wallet.")
    # branch in dispatch_mcp_tool routes the actual handlers via
    # apps.backend.mcp.wallet_tools; entries here exist so legacy callers can
    # resolve canonical names through canonical_public_mcp_tool_name.
    "ww.wallet.policies.list": "wallet_policies_list",
    "ww.wallet.policy.get": "wallet_policy_get",
    "ww.wallet.policy.set": "wallet_policy_set",
    "ww.wallet.transactions.list": "wallet_transactions_list",
    "ww.wallet.transactions.sign": "wallet_transactions_sign",
    # Cross-tenant Zara coordination (#3625 / family J). Routed via the
    # startswith("ww.zara.coordinate.") branch in dispatch_mcp_tool.
    "ww.zara.coordinate.send": "zara_coordinate_send",
    "ww.zara.coordinate.show": "zara_coordinate_show",
    "ww.zara.coordinate.broadcast": "zara_coordinate_broadcast",
    # Profile (#2394)
    "ww.profile.get": "profile_get",
    "ww.profile.set": "profile_set",
    "ww.profile.list": "profile_list",
    # Voice persona (#2798)
    "ww.voice.persona.create": "voice_persona_create",
    "ww.voice.persona.clone.register": "voice_persona_clone_register",
    "ww.voice.persona.list": "voice_persona_list",
    "ww.voice.catalog.list": "voice_catalog_list",
    "ww.voice.persona.get": "voice_persona_get",
    "ww.voice.persona.update": "voice_persona_update",
    "ww.voice.persona.delete": "voice_persona_delete",
    "ww.voice.persona.templates": "voice_persona_templates",
    # TimeBlock CRUD primitive (#2785 PR C)
    "ww.timeblock.list": "timeblock_list",
    "ww.timeblock.create": "timeblock_create",
    "ww.timeblock.show": "timeblock_show",
    "ww.timeblock.update": "timeblock_update",
    "ww.timeblock.move": "timeblock_move",
    "ww.timeblock.delete": "timeblock_delete",
    # Inference audit grid (#3215) — read-only per-Purpose x per-tenant projection
    "ww.admin.inference.audit_grid": "admin_inference_audit_grid",
    # Jurisdiction policy (#3224) — MCP mirrors for founder REST endpoints
    "ww.admin.jurisdiction.policy_show": "admin_jurisdiction_policy_show",
    "ww.admin.jurisdiction.policy_set": "admin_jurisdiction_policy_set",
    # Embedding policy (#3209) — per-Purpose × per-tenant grid
    "ww.admin.embedding.policy_show": "admin_embedding_policy_show",
    "ww.admin.embedding.policy_set": "admin_embedding_policy_set",
    # Agent Protocol tools are dispatched separately (not via _PublicApiService)
    "workweaver.org.query": "_agent_protocol:org_query",
    "workweaver.agent.query": "_agent_protocol:agent_query",
    # Function SLI + reap (#3245)
    "ww.function.sli.snapshot": "function_sli_snapshot",
    "ww.function.sli.reap": "function_sli_reap",
    # Chat router (Slices 9 + 11)
    "ww.chat.route": "chat_route",
    "ww.chat.rollback": "chat_rollback",
}


def get_agent_protocol_service():  # noqa: ANN201
    """Lazy-load agent protocol service for MCP dispatch."""
    from apps.backend.services.agent_protocol import (
        get_agent_protocol_service as _get,
    )

    return _get()


async def _dispatch_agent_protocol_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Handle agent protocol MCP tools."""
    from dataclasses import asdict

    svc = get_agent_protocol_service()

    if tool_name == "workweaver.org.query":
        resp = await svc.query_agent(
            tenant_id=tenant_id,
            agent_id="org",
            question=parameters["question"],
        )
        return asdict(resp)

    if tool_name == "workweaver.agent.query":
        resp = await svc.query_agent(
            tenant_id=tenant_id,
            agent_id=parameters["agent_id"],
            question=parameters["question"],
        )
        return asdict(resp)

    raise ValueError(f"Unknown agent protocol tool: {tool_name}")


def _get_execution_guard():  # noqa: ANN201
    """Lazy-load the canonical execution safety gate."""
    from apps.backend.services.execution.guard_service import get_execution_guard

    return get_execution_guard()


def _normalize_connector_operation(operation: Any) -> str:
    """Collapse provider-specific operation names into guard-friendly verbs."""
    op = str(operation or "execute").strip().lower().replace("-", "_")
    op_parts = {part for part in op.split("_") if part}
    for prefix in _HIGH_RISK_OPERATION_PREFIXES:
        if op == prefix or op.startswith(f"{prefix}_") or prefix in op_parts:
            return prefix
    for prefix in _SAFE_OPERATION_PREFIXES:
        if op == prefix or op.startswith(f"{prefix}_"):
            return prefix
    return op or "execute"


def _mcp_operation_type(tool_name: str, parameters: dict[str, Any]) -> str:
    if tool_name in _PLAN_STEER_MCP_TOOLS:
        return str(parameters.get("action") or "control").strip().lower() or "control"
    if tool_name == "ww.connector.import.openapi":
        return "import"
    if tool_name == "ww.skill.import":
        return "read" if bool(parameters.get("dry_run", True)) else "create"
    if tool_name in {"ww.skill.curator.latest", "ww.skill.curator.list"}:
        return "read"
    if tool_name == "ww.skill.curator.run":
        return "execute"
    if tool_name == "ww.skill.curator.respond":
        return "update"
    if tool_name == "ww.mission.reversal.request":
        return "read" if bool(parameters.get("dry_run", False)) else "create"
    if tool_name == "ww.connector.execute" and bool(parameters.get("dry_run", False)):
        if _connector_has_public_dry_run_preview(parameters):
            return "read"
    return _normalize_connector_operation(parameters.get("operation"))


def _guarded_mcp_operation_requires_gate(tool_name: str, operation_type: str) -> bool:
    if tool_name in _PLAN_STEER_MCP_TOOLS:
        return operation_type == "approve"
    if tool_name in {"ww.connector.execute", "workweaver.connector.execute"} and operation_type == "read":
        return False
    if tool_name == "ww.skill.import" and operation_type == "read":
        return False
    if tool_name in {"ww.skill.curator.latest", "ww.skill.curator.list"} and operation_type == "read":
        return False
    if tool_name == "ww.mission.reversal.request" and operation_type == "read":
        return False
    if tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES and operation_type == "read":
        return False
    return tool_name in _GUARDED_PUBLIC_MCP_TOOLS


def _validate_mcp_plan_approve_actor(parameters: dict[str, Any]) -> None:
    action = str(parameters.get("action") or "").strip().lower()
    if action != "approve":
        return
    from fastapi import HTTPException

    actor_id = str(parameters.get("actor_id") or "").strip()
    if not actor_id or actor_id.lower() in {"mcp", "agent", "zara", "system"}:
        raise HTTPException(status_code=403, detail="MCP plan approval requires a member actor_id")
    expected_revision = parameters.get("expected_revision")
    if expected_revision is None:
        raise HTTPException(status_code=422, detail="MCP plan approval requires expected_revision")
    try:
        reviewed_revision = int(expected_revision)
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail="MCP plan approval requires integer expected_revision") from None
    if reviewed_revision < 1:
        raise HTTPException(status_code=422, detail="MCP plan approval requires positive expected_revision")
    parameters["expected_revision"] = reviewed_revision
    if not str(parameters.get("idempotency_key") or "").strip():
        raise HTTPException(status_code=422, detail="MCP plan approval requires idempotency_key")


def _policy_decision_to_dict(decision: Any) -> dict[str, Any]:
    verdict = getattr(decision, "verdict", None)
    return {
        "verdict": getattr(verdict, "value", verdict),
        "reasons": list(getattr(decision, "reasons", []) or []),
        "requires_approval_from": getattr(decision, "requires_approval_from", None),
        "evidence_receipt": getattr(decision, "evidence_receipt", None),
    }


def _policy_envelope_to_legacy_decision(envelope: Any, decision: Any | None = None) -> dict[str, Any]:
    legacy = _policy_decision_to_dict(decision) if decision is not None else {}
    final = str(getattr(envelope, "final_verdict", "") or "").lower()
    legacy.setdefault("verdict", "require_approval" if final == "require_approval" else final)
    legacy.setdefault("reasons", [getattr(item, "reason", "") for item in getattr(envelope, "sub_verdicts", [])])
    legacy["envelope"] = envelope.to_public_dict() if hasattr(envelope, "to_public_dict") else envelope
    return legacy


def _policy_block_response(
    *,
    tenant_id: str,
    tool_name: str,
    operation_type: str,
    status: str,
    error: str,
    policy_decision: dict[str, Any] | None = None,
) -> dict[str, Any]:
    response = {
        "tenant_id": tenant_id,
        "tool_name": tool_name,
        "operation_type": operation_type,
        "status": status,
        "error": error,
    }
    if policy_decision is not None:
        response["policy_decision"] = policy_decision
    return response


def _connector_operation_http_method(*, tenant_id: str, parameters: dict[str, Any]) -> str | None:
    connector_id = str(parameters.get("connector_id") or "").strip()
    operation_id = str(parameters.get("operation") or "").strip()
    if not connector_id or not operation_id:
        return None

    try:
        from apps.backend.services.connectors.standard_connector_registry import (
            get_standard_connector_registry,
            is_custom_connector_id,
        )

        if not is_custom_connector_id(connector_id):
            return None
        item = get_standard_connector_registry().get_definition(tenant_id, connector_id)
    except Exception:
        return None

    definition = item.get("Definition") if isinstance(item, dict) else None
    if not isinstance(definition, dict):
        return None
    for operation in definition.get("operations") or []:
        if isinstance(operation, dict) and operation.get("id") == operation_id:
            return str(operation.get("method") or "").strip().upper() or None
    return None


def _connector_has_public_dry_run_preview(parameters: dict[str, Any]) -> bool:
    connector_id = str(parameters.get("connector_id") or "").strip()
    if not connector_id:
        return False
    try:
        from apps.backend.api.connectors._core import _CONNECTOR_CLASSES, _load_connector_classes
        from apps.backend.services.connectors.base import ConnectorBase

        _load_connector_classes()
        connector_cls = _CONNECTOR_CLASSES.get(connector_id)
        if connector_cls is None:
            return False
        return connector_cls._dry_run_preview is not ConnectorBase._dry_run_preview
    except Exception:
        return False


def _operation_requires_side_effect_proof(
    tool_name: str,
    operation_type: str,
    *,
    http_method: str | None = None,
    dry_run_preview_supported: bool = False,
) -> bool:
    if tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES and dry_run_preview_supported:
        return False
    if not _guarded_mcp_operation_requires_gate(tool_name, operation_type):
        return False
    if http_method:
        return http_method.upper() not in _SAFE_CONNECTOR_HTTP_METHODS
    return True


def _strip_side_effect_proof(parameters: dict[str, Any]) -> dict[str, Any]:
    cleaned = dict(parameters)
    cleaned.pop("side_effect_proof", None)
    cleaned.pop("verified_actor_id", None)
    cleaned.pop("verified_actor_role", None)
    nested_params = cleaned.get("params")
    if isinstance(nested_params, dict):
        cleaned["params"] = {
            key: value
            for key, value in nested_params.items()
            if key not in {"side_effect_proof", "verified_actor_id", "verified_actor_role"}
        }
    return cleaned


def _validate_public_mcp_side_effect_proof(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
    policy_decision: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    operation_type = _mcp_operation_type(tool_name, parameters)
    http_method = None if tool_name in _PLAN_STEER_MCP_TOOLS else _connector_operation_http_method(
        tenant_id=tenant_id,
        parameters=parameters,
    )
    dry_run_preview_supported = (
        tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES
        and bool(parameters.get("dry_run", False))
        and _connector_has_public_dry_run_preview(parameters)
    )
    if not _operation_requires_side_effect_proof(
        tool_name,
        operation_type,
        http_method=http_method,
        dry_run_preview_supported=dry_run_preview_supported,
    ):
        return None, None

    from apps.backend.services.side_effect_proof import (
        SideEffectProofError,
        side_effect_proof_summary,
        validate_side_effect_proof_bundle,
    )

    proof_payload = parameters.get("side_effect_proof")
    if not isinstance(proof_payload, dict):
        nested_params = parameters.get("params")
        if isinstance(nested_params, dict):
            proof_payload = nested_params.get("side_effect_proof")
    evidence_receipt = (policy_decision or {}).get("evidence_receipt")
    expected_policy_verdict_id = None
    if isinstance(evidence_receipt, dict):
        expected_policy_verdict_id = str(evidence_receipt.get("policy_verdict_id") or "").strip() or None
    if expected_policy_verdict_id is None:
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="proof_required",
            error="Connector side effect blocked until execution guard emits a policy_verdict_id",
            policy_decision=policy_decision,
        )
    try:
        bundle = validate_side_effect_proof_bundle(
            proof_payload,
            tenant_id=tenant_id,
            expected_policy_verdict_id=expected_policy_verdict_id,
            require_decision=True,
            require_timeblock=True,
            require_trace_envelope=True,
        )
    except SideEffectProofError as exc:
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="proof_required",
            error=f"Connector side effect blocked until proof bundle is complete: {exc}",
            policy_decision=policy_decision,
        )
    return side_effect_proof_summary(bundle), None


def _evaluate_public_mcp_execution_gate(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Evaluate the canonical gate for public MCP tools with external effects.

    Returns ``(policy_decision, block_response)``. ``block_response`` is
    non-None when the downstream handler must not run.
    """
    operation_type = _mcp_operation_type(tool_name, parameters)
    if (
        tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES
        and bool(parameters.get("dry_run", False))
        and _connector_has_public_dry_run_preview(parameters)
    ):
        return None, None
    if not _guarded_mcp_operation_requires_gate(tool_name, operation_type):
        return None, None

    from apps.backend.services.execution.guard_service import AutomationLevel
    from apps.backend.services.policy_authority import build_policy_decision_envelope, execution_guard_sub_verdict
    try:
        decision = _get_execution_guard().evaluate(
            tenant_id=tenant_id,
            tool_id=tool_name,
            operation_type=operation_type,
            automation_level=AutomationLevel.ASK_TO_EXECUTE,
            inputs=parameters,
            agent_id=str(parameters.get("agent_id") or "agent:mcp").strip(),
            entity_id=str(parameters.get("agent_id") or parameters.get("connector_id") or "").strip() or None,
            session_id=str(parameters.get("session_id") or parameters.get("trace_id") or "").strip() or None,
            policy_tool_name=tool_name,
            capture_surface="mcp_public",
            service_family="public_mcp",
            context_data={
                "connector_id": parameters.get("connector_id"),
                "requested_operation": parameters.get("operation"),
                "trace_id": parameters.get("trace_id"),
            },
        )
    except Exception as exc:
        logger.warning("public_mcp.execution_guard_unavailable", exc_info=True)
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="policy_denied",
            error=f"Execution safety gate unavailable: {exc}",
        )

    actor_id = str(parameters.get("agent_id") or "agent:mcp").strip()
    guard_sub_verdict = execution_guard_sub_verdict(decision)
    envelope = build_policy_decision_envelope(
        "connector",
        tenant_id=tenant_id,
        actor={"actor_id": actor_id},
        inputs={
            "action": f"{tool_name}:{operation_type}",
            "execution_verdict": guard_sub_verdict.verdict,
            "execution_reason": guard_sub_verdict.reason,
            "execution_evidence_id": guard_sub_verdict.evidence_id,
            "execution_metadata": guard_sub_verdict.metadata,
            "family_policy_reason": "public MCP connector policy preflight completed",
            "family_policy_metadata": {
                "connector_id": parameters.get("connector_id"),
                "requested_operation": parameters.get("operation"),
            },
        },
    )
    policy_decision = _policy_envelope_to_legacy_decision(envelope, decision)
    if envelope.final_verdict == "ALLOW":
        return policy_decision, None
    if envelope.final_verdict == "REQUIRE_APPROVAL":
        return policy_decision, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="approval_required",
            error="Execution requires approval before connector side effects may run",
            policy_decision=policy_decision,
        )
    if envelope.final_verdict == "DRAFT":
        return policy_decision, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="draft_only",
            error="Execution posture allows only a draft; connector side effects were not run",
            policy_decision=policy_decision,
        )
    return policy_decision, _policy_block_response(
        tenant_id=tenant_id,
        tool_name=tool_name,
        operation_type=operation_type,
        status="policy_denied",
        error="Execution denied by canonical safety gate",
        policy_decision=policy_decision,
    )


# ---------------------------------------------------------------------------
# Learning DLQ MCP tools (#2324)
# ---------------------------------------------------------------------------

_LEARNING_DLQ_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.learning.dlq.list",
        "description": "List dead-lettered learning signals for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {"limit": {"type": "integer", "description": "Maximum entries to return.", "default": 50}},
        },
    },
    {
        "name": "ww.learning.dlq.inspect",
        "description": "Inspect a single dead-lettered learning signal.",
        "inputSchema": {
            "type": "object",
            "properties": {"envelope_id": {"type": "string", "description": "DLQ envelope ID to inspect."}},
            "required": ["envelope_id"],
        },
    },
    {
        "name": "ww.learning.dlq.replay",
        "description": "Replay a dead-lettered learning signal for retry.",
        "inputSchema": {
            "type": "object",
            "properties": {"envelope_id": {"type": "string", "description": "DLQ envelope ID to replay."}},
            "required": ["envelope_id"],
        },
    },
]

for _tool in _LEARNING_DLQ_MCP_TOOLS:
    _PUBLIC_MCP_CATALOG_TOOLS.append(_tool)


async def _dispatch_learning_dlq_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch learning DLQ MCP tools."""
    from apps.backend.services.learning.learning_signal_queue import LearningSignalQueue

    queue = LearningSignalQueue()

    if tool_name == "ww.learning.dlq.list":
        limit = int(parameters.get("limit") or 50)
        envelopes = queue.list_dlq(tenant_id, limit=limit)
        items = [
            {
                "id": e.id,
                "work_item_id": e.work_item_id,
                "attempts": e.attempts,
                "dead_lettered": e.dead_lettered,
                "last_error": e.last_error,
                "created_at": e.created_at,
            }
            for e in envelopes
        ]
        return {"items": items, "count": len(items)}

    if tool_name == "ww.learning.dlq.inspect":
        envelope_id = str(parameters.get("envelope_id") or "")
        if not envelope_id:
            return {"status": "error", "error": "envelope_id is required"}
        envelope = queue.inspect(envelope_id, tenant_id)
        if envelope is None:
            return {"status": "error", "error": "DLQ entry not found"}
        return envelope.model_dump(mode="json")

    if tool_name == "ww.learning.dlq.replay":
        envelope_id = str(parameters.get("envelope_id") or "")
        if not envelope_id:
            return {"status": "error", "error": "envelope_id is required"}
        envelope = queue.replay(envelope_id, tenant_id)
        if envelope is None:
            return {"status": "error", "error": "DLQ entry not found"}
        return {"replayed": True, "id": envelope.id, "message": "DLQ entry queued for replay"}

    return {"status": "error", "error": f"Unknown learning DLQ tool: {tool_name}"}




async def _dispatch_wallet_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch wallet.* MCP tools via wallet_tools module (#2366).

    Routes to the wallet dispatch layer which delegates to KeyCustody,
    ChainTxStore, CryptoWalletPolicy and (for issue #3625 multi-wallet
    surfaces) WalletPolicyService.
    """
    from apps.backend.mcp.wallet_tools import dispatch_wallet_tool

    return await dispatch_wallet_tool(tool_name, tenant_id, parameters)


async def _dispatch_zara_coordination_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch ww.zara.coordinate.* MCP tools (#3625 / family J).

    Routes to :mod:`apps.backend.mcp.zara_coordination_tools` which composes
    the same ZaraCoordinationService stack used by the REST handlers.
    """
    from apps.backend.mcp.zara_coordination_tools import (
        dispatch_zara_coordination_tool,
    )

    return await dispatch_zara_coordination_tool(tool_name, tenant_id, parameters)


async def _dispatch_support_file_bug(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch support.file_bug via BugReportProvider (#2348).

    Thin pass-through to FileSupportTicketAction which delegates to the
    deployment-profile-correct BugReportProvider.
    """
    summary = str(parameters.get("summary") or "").strip()
    if not summary:
        return {"status": "error", "error": "summary is required"}

    from apps.backend.providers.bug_report_provider import get_bug_report_provider
    from apps.backend.services.zara.actions.file_support_ticket import FileSupportTicketAction

    provider = get_bug_report_provider()
    action = FileSupportTicketAction(bug_report_provider=provider)
    category = str(parameters.get("category") or "other").strip()
    evidence_refs = parameters.get("evidence_refs") or []

    result = await action.execute(
        tenant_id=tenant_id,
        user_id="mcp",
        category=category,
        summary=summary,
        severity="medium",
        session_context={"evidence": [str(e) for e in evidence_refs]},
    )

    if not result.get("ticket_created"):
        return {"status": "error", "error": result.get("error", "ticket creation failed")}

    ticket_id = result["provider_ticket_id"]
    return {
        "ticket_id": ticket_id,
        "ticket_url": f"/api/v1/support/tickets/{ticket_id}",
        "consent_required": False,
        "status": "open",
    }



async def _dispatch_support_consent(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch support.consent (#2342)."""
    action = str(parameters.get("action") or "list").strip()
    investigation_id = parameters.get("investigation_id")

    from apps.backend.providers.portable_store import get_portable_store
    from apps.backend.providers.object_store import get_evidence_store
    from apps.backend.services.investigation_consent_service import InvestigationConsentService

    store = get_portable_store()
    evidence_store = get_evidence_store()
    svc = InvestigationConsentService(store=store, evidence_store=evidence_store)

    if action == "list":
        results = svc.list_consents(
            tenant_id=tenant_id,
            investigation_id=investigation_id,
        )
        return {
            "action": "list",
            "tenant_id": tenant_id,
            "consents": [
                {
                    "consent_id": c.consent_id,
                    "investigation_id": c.investigation_id,
                    "granted_by": c.granted_by,
                    "scope": c.scope,
                    "granted_at": c.granted_at,
                    "expires_at": c.expires_at,
                    "revoked_at": c.revoked_at,
                    "audit_trail_ref": c.audit_trail_ref,
                }
                for c in results
            ],
            "count": len(results),
        }

    if action == "approve":
        granted_by = str(parameters.get("granted_by") or "").strip()
        if not granted_by:
            return {"status": "error", "error": "granted_by is required for approve action"}
        scope = parameters.get("scope") or ["data_access"]
        duration_hours = int(parameters.get("duration_hours") or 24)
        if not investigation_id:
            return {"status": "error", "error": "investigation_id is required for approve action"}
        envelope = svc.grant_consent(
            tenant_id=tenant_id,
            investigation_id=investigation_id,
            granted_by=granted_by,
            scope=scope,
            duration_hours=duration_hours,
        )
        return {
            "action": "approve",
            "consent_id": envelope.consent_id,
            "investigation_id": envelope.investigation_id,
            "granted_by": envelope.granted_by,
            "scope": envelope.scope,
            "granted_at": envelope.granted_at,
            "expires_at": envelope.expires_at,
            "audit_trail_ref": envelope.audit_trail_ref,
            "status": "granted",
        }

    if action == "revoke":
        consent_id = str(parameters.get("consent_id") or "").strip()
        reason = str(parameters.get("reason") or "").strip()
        if not consent_id:
            return {"status": "error", "error": "consent_id is required for revoke action"}
        if not reason:
            return {"status": "error", "error": "reason is required for revoke action"}
        envelope = svc.revoke_consent(
            tenant_id=tenant_id,
            consent_id=consent_id,
            reason=reason,
        )
        return {
            "action": "revoke",
            "consent_id": envelope.consent_id,
            "revoked_at": envelope.revoked_at,
            "revocation_reason": envelope.revocation_reason,
            "status": "revoked",
        }

    if action == "check":
        consent_id = str(parameters.get("consent_id") or "").strip()
        if not consent_id:
            return {"status": "error", "error": "consent_id is required for check action"}
        valid = svc.check_consent(
            tenant_id=tenant_id,
            consent_id=consent_id,
        )
        return {
            "action": "check",
            "consent_id": consent_id,
            "valid": valid,
        }

    return {"status": "error", "error": f"Unknown action: {action}"}

async def _dispatch_profile_get(tenant_id: str) -> dict[str, Any]:
    """Dispatch profile.get (#2394)."""
    from apps.backend.services.deployment_profiles import get_deployment_profile_config

    profile = os.environ.get("WORKWEAVER_PROFILE", "solo_dogfood")
    cfg = get_deployment_profile_config(profile)
    result = cfg.to_dict()
    result["tenant_id"] = tenant_id
    return result


async def _dispatch_profile_set(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch profile.set (#2394)."""
    from apps.backend.services.deployment_profiles import get_deployment_profile_config

    profile = str(parameters.get("profile") or "").strip()
    if not profile:
        return {"status": "error", "error": "profile is required"}
    cfg = get_deployment_profile_config(profile)
    return {"tenant_id": tenant_id, "profile": cfg.profile.value, "updated": True}


async def _dispatch_profile_list() -> dict[str, Any]:
    """Dispatch profile.list (#2394)."""
    from apps.backend.services.deployment_profiles import list_deployment_profiles

    return {"profiles": list_deployment_profiles()}


async def _dispatch_identity_purposes(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch identity.purposes (#2231)."""
    agent_id = str(parameters.get("agent_id") or "zara").strip()
    purposes = [
        "email_send", "calendar_read", "calendar_write", "meeting_join",
        "payment_initiate", "payment_approve", "voice_call", "crypto_wallet",
    ]
    return {
        "agent_id": agent_id,
        "tenant_id": tenant_id,
        "purposes": {p: {"ready": False, "provider": None, "state": "missing"} for p in purposes},
    }


async def _dispatch_identity_purpose_status(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch identity.purpose_status (#2231)."""
    agent_id = str(parameters.get("agent_id") or "zara").strip()
    purpose = str(parameters.get("purpose") or "").strip()
    if not purpose:
        return {"status": "error", "error": "purpose is required"}
    return {
        "agent_id": agent_id,
        "tenant_id": tenant_id,
        "purpose": purpose,
        "ready": False,
        "provider": None,
        "state": "missing",
        "scopes": [],
    }


def _dispatch_decision_search(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch decision.search (#2489)."""
    from apps.backend.services.decision_search_service import (
        DecisionSearchFilters,
        get_decision_search_service,
    )

    filters = DecisionSearchFilters(
        domain=parameters.get("domain"),
        tool_name=parameters.get("tool_name"),
        outcome=parameters.get("outcome"),
        skill_id=parameters.get("skill_id"),
        decision_type=parameters.get("decision_type"),
        min_confidence=parameters.get("min_confidence"),
        time_range_start=parameters.get("time_range_start"),
        time_range_end=parameters.get("time_range_end"),
        sop_deviation_present=parameters.get("sop_deviation_present"),
        precedent_id=parameters.get("precedent_id"),
        limit=int(parameters.get("limit") or 50),
        cursor=parameters.get("cursor"),
    )
    query = str(parameters.get("query") or "").strip() or None
    service = get_decision_search_service()
    result = service.search(tenant_id=tenant_id, filters=filters, query=query)
    return result.model_dump(mode="json")



def _dispatch_capability_state_show(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch ww.capability.state.show (#3543)."""
    capability_id = str(parameters.get("capability_id") or "").strip()
    if not capability_id:
        raise ValueError("capability_id is required")
    from apps.backend.providers.portable_store import create_portable_store
    from apps.backend.services.capability_registry import load_capability_registry
    from apps.backend.services.capability_state_machine import (
        CapabilityStateMachine,
    )
    from apps.backend.services.zara.zara_awareness_service import (
        translate_capability_state_to_view,
    )
    from apps.backend.workmemory.agent_awareness_store import (
        AgentAwarenessStore,
        Readiness,
    )

    registry = load_capability_registry()
    try:
        row = registry.find(capability_id)
    except KeyError:
        return {
            "capability_id": capability_id,
            "error": "capability_not_in_registry",
        }
    declared_state = row.state
    store = AgentAwarenessStore(store=create_portable_store())
    tenant_row = store.get_capability(tenant_id, capability_id) or {}
    tenant_readiness_value = tenant_row.get("readiness")
    if tenant_readiness_value:
        try:
            tenant_state = CapabilityStateMachine.from_readiness(
                Readiness(tenant_readiness_value)
            )
        except ValueError:
            tenant_state = declared_state
    else:
        tenant_state = declared_state
    return {
        "capability_id": capability_id,
        "tenant_id": tenant_id,
        "declared_state": declared_state.value,
        "declared_view": translate_capability_state_to_view(declared_state),
        "tenant_state": tenant_state.value,
        "tenant_view": translate_capability_state_to_view(tenant_state),
        "last_probe_at": tenant_row.get("last_probe_at"),
        "last_probe_outcome": tenant_row.get("last_probe_outcome"),
    }


def _dispatch_capability_state_list(parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch ww.capability.state.list (#3543)."""
    from apps.backend.services.capability_registry import load_capability_registry
    from apps.backend.services.zara.zara_awareness_service import (
        translate_capability_state_to_view,
    )

    state_filter = parameters.get("state")
    registry = load_capability_registry()
    rows = []
    for row in registry.rows:
        if state_filter and row.state.value != state_filter:
            continue
        rows.append(
            {
                "capability_id": row.capability_id,
                "state": row.state.value,
                "view": translate_capability_state_to_view(row.state),
            }
        )
    return {"rows": rows, "total": len(rows)}


def _dispatch_voice_persona_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch voice persona MCP tools (#2798)."""
    from apps.backend.api.voice_persona_mcp import dispatch_voice_persona_tool
    from apps.backend.services.voice_persona_store import get_voice_persona_service

    service = get_voice_persona_service()
    result = dispatch_voice_persona_tool(
        tool_name=tool_name, tenant_id=tenant_id, parameters=parameters, service=service,
    )
    if isinstance(result, dict):
        return result
    if isinstance(result, list):
        if tool_name == "ww.voice.catalog.list":
            return {"voices": result}
        return {"personas": result}
    return {"result": result}


def _dispatch_workspace_persona_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch the WorkspacePersonaOverlay MCP tools (#3542).

    The overlay is the safe SOUL.md analog: identity, presence, vocabulary,
    routing biases, language. Mutations emit an identity-class Decision
    Trace via the service layer; reads do not. The kernel envelope is
    layered FIRST in the composed Zara system prompt — see
    ``tests/contracts/test_kernel_envelope_first.py``.
    """

    from apps.backend.models.workspace_persona_overlay import (
        PersonaOverlayValidationError,
    )
    from apps.backend.services.persona_overlay_service import (
        get_persona_overlay_service,
    )

    service = get_persona_overlay_service()
    actor_id = str(parameters.get("actor_id") or "mcp").strip() or "mcp"

    if tool_name == "ww.workspace.persona.show":
        overlay = service.get(tenant_id=tenant_id)
        if overlay is None:
            return {"set": False, "overlay": None}
        return {"set": True, "overlay": overlay.model_dump(mode="json")}

    if tool_name == "ww.workspace.persona.set":
        # The MCP caller may pass either a fully-formed overlay dict or a
        # nested {"overlay": {...}} envelope. Accept both for ergonomics.
        raw = parameters.get("overlay") if isinstance(parameters.get("overlay"), dict) else None
        if raw is None:
            raw = {k: v for k, v in parameters.items() if k != "actor_id"}
        try:
            overlay = service.set_from_payload(
                tenant_id=tenant_id,
                payload=raw,
                actor_id=actor_id,
            )
        except PersonaOverlayValidationError as exc:
            return {
                "status": "error",
                "error": "persona_overlay_validation_failed",
                "message": str(exc),
                "violating_keys": exc.violating_keys,
            }
        return {"set": True, "overlay": overlay.model_dump(mode="json")}

    if tool_name == "ww.workspace.persona.reset":
        service.reset(tenant_id=tenant_id, actor_id=actor_id)
        return {"status": "ok", "operation": "workspace.persona.reset"}

    raise ValueError(f"Unknown workspace persona MCP tool: {tool_name}")


async def dispatch_mcp_tool(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
    verified_actor_id: str | None = None,
    verified_actor_role: Any | None = None,
) -> dict[str, Any]:
    """Dispatch an MCP tool invocation to the shared public API service.

    Args:
        tool_name: Fully qualified MCP tool name (e.g. 'ww.workitem.create').
        tenant_id: Authenticated tenant ID.
        parameters: Tool parameters from MCP client.

    Returns:
        Tool execution result as dict.

    Raises:
        ValueError: If tool_name is not recognized.
    """
    if isinstance(verified_actor_id, str):
        verified_actor_id = verified_actor_id.strip() or None
    if isinstance(verified_actor_role, str):
        verified_actor_role = verified_actor_role.strip() or None

    canonical_tool_name = canonical_public_mcp_tool_name(tool_name)
    if canonical_tool_name == _TOOL_SEARCH_NAME:
        return {
            "matches": search_public_mcp_tools(
                str(parameters.get("intent") or parameters.get("query") or ""),
                limit=int(parameters.get("limit") or 5),
            )
        }
    if canonical_tool_name == "ww.policy.authority":
        from apps.backend.services.policy_authority import policy_authority_map_payload

        return {"tenant_id": tenant_id, **policy_authority_map_payload()}
    if canonical_tool_name == "ww.governance.anchor.list":
        # Issue #3547: read-only listing of L4 anchor inventory.
        from apps.backend.services.governance_anchor_paths import list_anchor_paths

        inventory = list_anchor_paths()
        return {
            "tenant_id": tenant_id,
            "paths": list(inventory["paths"]),
            "globs": list(inventory["globs"]),
        }
    if canonical_tool_name == "ww.policy.allowlist.list":
        from apps.backend.api.policy_allowlist import policy_allowlist_payload

        return policy_allowlist_payload(
            kind=str(parameters.get("kind") or "TOOL"),
            tenant_id=tenant_id,
        )
    if canonical_tool_name == "ww.kernel.healing.recent":
        from apps.backend.api.kernel_healing import collect_recent_healing_actions
        from apps.backend.services.mission_run.state import get_mission_run_state_service

        window_hours = parameters.get("window_hours", 24)
        try:
            window_hours_int = int(window_hours)
        except (TypeError, ValueError):
            window_hours_int = 24
        response = collect_recent_healing_actions(
            tenant_id=tenant_id,
            window_hours=window_hours_int,
            service=get_mission_run_state_service(),
        )
        return response.model_dump(mode="json")
    if canonical_tool_name == "ww.member.bind_external":
        from apps.backend.services.identity_binding_service import IdentityBindingService

        service = IdentityBindingService()
        workspace_id = str(parameters.get("workspace_id", ""))
        member_id = str(parameters.get("member_id", ""))
        provider = str(parameters.get("provider", ""))
        external_user_id = str(parameters.get("external_user_id", ""))
        external_email = parameters.get("external_email")
        external_name = parameters.get("external_name")
        binding = service.bind_external_identity(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            member_id=member_id,
            provider=provider,
            external_user_id=external_user_id,
            external_email=external_email,
            external_name=external_name,
            created_by=f"mcp:{tenant_id}",
        )
        return binding.to_record()
    if canonical_tool_name == "ww.member.list_external_identities":
        from apps.backend.services.identity_binding_service import IdentityBindingService

        service = IdentityBindingService()
        member_id = str(parameters.get("member_id", ""))
        bindings = service.list_bindings_for_member(
            tenant_id=tenant_id,
            member_id=member_id,
        )
        return {
            "bindings": [b.to_record() for b in bindings],
            "total": len(bindings),
        }
    if canonical_tool_name in (
        "ww.kernel.skill.list",
        "ww.kernel.skill.show",
        "ww.kernel.skill.run",
    ):
        from apps.backend.api.kernel_skills import (
            KERNEL_SECTION_14_SKILL_IDS,
            get_kernel_skill_executor,
        )

        executor = get_kernel_skill_executor()
        if canonical_tool_name == "ww.kernel.skill.list":
            return {
                "skills": [
                    {
                        "skill_id": skill.skill_id,
                        "name": skill.name,
                        "category": skill.category.value,
                        "description": skill.description,
                        "owner": "system",
                        "immutable": skill.immutable,
                        "backed_by": list(skill.backed_by),
                    }
                    for skill in executor.registry.list_section_14()
                ],
            }
        skill_id = str(parameters.get("skill_id") or "").strip()
        if skill_id not in KERNEL_SECTION_14_SKILL_IDS:
            return {"error": f"Unknown kernel skill: {skill_id}"}
        if canonical_tool_name == "ww.kernel.skill.show":
            skill = executor.registry.get(skill_id)
            if skill is None:
                return {"error": f"Unknown kernel skill: {skill_id}"}
            return {
                "skill_id": skill.skill_id,
                "name": skill.name,
                "category": skill.category.value,
                "description": skill.description,
                "owner": "system",
                "immutable": skill.immutable,
                "backed_by": list(skill.backed_by),
            }
        # ww.kernel.skill.run
        result = executor.run(tenant_id=tenant_id, skill_id=skill_id)
        return {
            "tenant_id": result.tenant_id,
            "skill_id": result.skill_id,
            "operation": result.operation,
            "side_effect_class": result.side_effect_class,
            "idempotency_key": result.idempotency_key,
            "trace_id": result.trace_id,
            "summary": result.summary,
        }
    if canonical_tool_name == "ww.kernel.connector_locality":
        from apps.backend.services.connectors.locality_matrix import (
            DEFAULT_LOCALITY_MATRIX,
        )

        connector_name = str(parameters.get("connector_name") or "").strip()
        operation = str(parameters.get("operation") or "").strip()
        policy_modes = list(parameters.get("policy_modes") or [])
        if connector_name and operation:
            explanation = DEFAULT_LOCALITY_MATRIX.explain(
                connector_name,
                operation,
                policy_modes=policy_modes,
                tenant_id=tenant_id,
            )
            return {
                "connector_name": explanation.connector_name,
                "operation": explanation.operation,
                "decision": explanation.decision.value,
                "side_effect_class": explanation.side_effect_class.value,
                "reason": explanation.reason,
                "allowed_localities": [loc.value for loc in explanation.allowed_localities],
                "fallback": explanation.fallback,
                "policy_modes": list(explanation.policy_modes),
            }
        if connector_name and not operation:
            return {"error": "operation is required when connector_name is provided"}
        return DEFAULT_LOCALITY_MATRIX.tenant_locality_summary()
    if canonical_tool_name == "ww.kernel.zero_burn":
        from apps.backend.services.capacity.zero_burn_sli import (
            get_zero_burn_sli_service,
        )
        from apps.backend.services.zara.zara_awareness_service import (
            list_function_capacity_envelopes,
        )

        envelopes = list_function_capacity_envelopes(tenant_id)
        function_ids = [env.function_id for env in envelopes]
        sli = get_zero_burn_sli_service()
        return sli.tenant_zero_burn_summary(
            workspace_id=tenant_id, function_ids=function_ids
        )
    if canonical_tool_name == "ww.kernel.probe.history":
        from apps.backend.jobs.capability_readiness_probe import (
            get_probe_history_for_tenant,
        )
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.workmemory.agent_awareness_store import AgentAwarenessStore

        capability_id = str(parameters.get("capability_id") or "").strip()
        if not capability_id:
            return {"error": "capability_id is required"}
        store = AgentAwarenessStore(store=create_portable_store())
        return get_probe_history_for_tenant(
            tenant_id=tenant_id,
            capability_id=capability_id,
            store=store,
        )
    if canonical_tool_name == "ww.evidence.trace.awareness":
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.services.context.decision_event_capture import (
            DecisionEventCaptureService,
        )
        from apps.backend.workmemory.services.awareness_snapshot_store import (
            AwarenessSnapshotStore,
        )

        trace_id_param = str(parameters.get("trace_id") or "").strip()
        if not trace_id_param:
            return {"error": "trace_id is required"}
        try:
            decision = DecisionEventCaptureService().get_decision(
                tenant_id=tenant_id, trace_id=trace_id_param
            )
        except Exception:
            decision = None
        if decision is None:
            return {"error": f"trace {trace_id_param} not found"}
        snapshot_id = getattr(decision, "awareness_snapshot_id", None)
        if not snapshot_id:
            return {
                "error": (
                    f"trace {trace_id_param} did not stamp awareness_snapshot_id "
                    "(legacy or non-zara.plan.* operation)"
                ),
            }
        store = AwarenessSnapshotStore(create_portable_store())
        snapshot = store.get(tenant_id=tenant_id, snapshot_id=snapshot_id)
        if snapshot is None:
            return {"error": f"snapshot {snapshot_id} not found"}
        return snapshot.to_storage_record()
    if canonical_tool_name == "ww.healing.digest":
        from apps.backend.services.healing_digest import (
            get_healing_digest_service,
        )

        month = str(parameters.get("month") or "").strip() or None
        digest = get_healing_digest_service().digest(
            tenant_id=tenant_id, month=month
        )
        return digest.model_dump(mode="json")
    if canonical_tool_name == "ww.tenant.conflicts.list":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        bundle = get_conflict_detector_service().detect(tenant_id=tenant_id)
        return bundle.model_dump(mode="json")
    if canonical_tool_name == "ww.tenant.conflicts.show":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        conflict_id = str(parameters.get("conflict_id") or "").strip()
        if not conflict_id:
            return {"error": "conflict_id is required"}
        bundle = get_conflict_detector_service().detect(tenant_id=tenant_id)
        for conflict in bundle.conflicts:
            if conflict.conflict_id == conflict_id:
                return conflict.model_dump(mode="json")
        return {"error": f"conflict {conflict_id} not found"}
    if canonical_tool_name == "ww.tenant.conflicts.resolve":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        conflict_id = str(parameters.get("conflict_id") or "").strip()
        if not conflict_id:
            return {"error": "conflict_id is required"}
        action = str(parameters.get("action") or "accept_suggestion")
        if action not in {"accept_suggestion", "reject", "escalate"}:
            return {"error": f"unsupported action: {action}"}
        detector = get_conflict_detector_service()
        bundle = detector.detect(tenant_id=tenant_id)
        for conflict in bundle.conflicts:
            if conflict.conflict_id == conflict_id:
                result = detector.resolve(conflict=conflict, action=action)  # type: ignore[arg-type]
                return result.model_dump(mode="json")
        return {"error": f"conflict {conflict_id} not found"}
    if canonical_tool_name == "ww.payment.preflight":
        from apps.backend.services.payment_policy_store import load_tenant_payment_policy
        from apps.backend.services.policy_authority import build_payment_policy_preflight

        envelope = build_payment_policy_preflight(
            tenant_id=tenant_id,
            actor={"actor_id": str(parameters.get("actor_id") or "zara").strip()},
            inputs={
                "action": parameters.get("action") or "payment.manage",
                "provider": parameters.get("provider") or "stripe",
                "amount": parameters.get("amount"),
                "currency": parameters.get("currency"),
                "tenant_payment_policy": load_tenant_payment_policy(tenant_id),
            },
        )
        return envelope.to_public_dict()
    if canonical_tool_name == "ww.inbox.conversations":
        return _dispatch_inbox_conversations(tenant_id, parameters)
    # Wallet (#2366) + multi-wallet parity (#3625 / slice 8e)
    if canonical_tool_name and canonical_tool_name.startswith("ww.wallet."):
        return await _dispatch_wallet_tool(canonical_tool_name, tenant_id, parameters)
    # Cross-tenant Zara coordination (#3625 / family J)
    if canonical_tool_name and canonical_tool_name.startswith("ww.zara.coordinate."):
        return await _dispatch_zara_coordination_tool(
            canonical_tool_name, tenant_id, parameters
        )
    # Support (#2348)
    if canonical_tool_name == "ww.support.file_bug":
        return await _dispatch_support_file_bug(tenant_id, parameters)
    # Support consent (#2342)
    if canonical_tool_name == "ww.support.consent":
        return await _dispatch_support_consent(tenant_id, parameters)
    # Profile (#2394)
    if canonical_tool_name == "ww.profile.get":
        return await _dispatch_profile_get(tenant_id)
    if canonical_tool_name == "ww.profile.set":
        return await _dispatch_profile_set(tenant_id, parameters)
    if canonical_tool_name == "ww.profile.list":
        return await _dispatch_profile_list()
    # Identity purposes (#2231)
    if canonical_tool_name == "ww.identity.purposes":
        return await _dispatch_identity_purposes(tenant_id, parameters)
    if canonical_tool_name == "ww.identity.purpose_status":
        return await _dispatch_identity_purpose_status(tenant_id, parameters)
    # Decision search (#2489)
    if canonical_tool_name == "ww.decision.search":
        return _dispatch_decision_search(tenant_id, parameters)
    # Voice persona (#2798)
    if canonical_tool_name and (
        canonical_tool_name.startswith("ww.voice.persona.")
        or canonical_tool_name == "ww.voice.catalog.list"
    ):
        return _dispatch_voice_persona_tool(canonical_tool_name, tenant_id, parameters)
    # Workspace persona overlay (#3542) — safe SOUL.md analog. Dispatched
    # directly because it has its own service + validator; the kernel envelope
    # contract test (tests/contracts/test_kernel_envelope_first.py) asserts
    # that overlays never reach into governance/policy/floor surfaces.
    if canonical_tool_name and canonical_tool_name.startswith("ww.workspace.persona."):
        return _dispatch_workspace_persona_tool(
            canonical_tool_name, tenant_id, parameters
        )
    # Calendar writer (#2716)
    if canonical_tool_name and canonical_tool_name.startswith("ww.calendar."):
        return await dispatch_calendar_tool(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
    # Places venue discovery (#3616)
    if canonical_tool_name and canonical_tool_name.startswith("ww.places."):
        return await dispatch_places_tool(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
    if canonical_tool_name == "ww.swarm.search_tools":
        return _dispatch_swarm_tool_search(tenant_id, parameters)
    if canonical_tool_name == "ww.swarm.activate_tool":
        return _dispatch_swarm_tool_activation(tenant_id, parameters)

    # Issue #3508: manifest-driven inference family. Dispatched before the
    # legacy ``_TOOL_DISPATCH`` map so the manifest is the single source of
    # truth for ``ww.inference.*`` and most ``ww.admin.inference.*`` tools.
    # The hand-rolled ``ww.admin.inference.audit_grid`` and its dispatch
    # mapping below remain — ``inference_mcp_tools.dispatch_inference_tool``
    # delegates to the same handler via its override map.
    if canonical_tool_name and (
        canonical_tool_name.startswith("ww.inference.")
        or canonical_tool_name.startswith("ww.admin.inference.")
    ):
        from apps.backend.api.inference_mcp_tools import (
            dispatch_inference_tool,
            inference_mcp_tool_names,
        )

        if canonical_tool_name in set(inference_mcp_tool_names()):
            return await dispatch_inference_tool(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
            )

    dispatch_tool_name = (
        canonical_tool_name
        if tool_name == canonical_tool_name == "ww.evidence.trace"
        else _legacy_dispatch_name(tool_name)
    )

    # Learning DLQ tools -- dispatched directly (#2324)
    if canonical_tool_name and canonical_tool_name.startswith("ww.learning.dlq."):
        return await _dispatch_learning_dlq_tool(canonical_tool_name, tenant_id, parameters)

    if canonical_tool_name and canonical_tool_name.startswith("ww.skill.curator."):
        operation_type = _mcp_operation_type(canonical_tool_name, parameters)
        side_effect_proof: dict[str, Any] | None = None
        dispatch_parameters = parameters
        if _guarded_mcp_operation_requires_gate(canonical_tool_name, operation_type):
            policy_decision, block_response = _evaluate_public_mcp_execution_gate(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
            )
            if block_response is not None:
                return block_response
            side_effect_proof, proof_block_response = _validate_public_mcp_side_effect_proof(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
                policy_decision=policy_decision,
            )
            if proof_block_response is not None:
                return proof_block_response
            dispatch_parameters = _strip_side_effect_proof(parameters)
            if canonical_tool_name == "ww.skill.curator.respond":
                actor_id, actor_block_response = _skill_curator_decision_actor_from_proof(side_effect_proof)
                if actor_block_response is not None:
                    return actor_block_response
                dispatch_parameters = {**dispatch_parameters, "actor_id": actor_id}
        result = _dispatch_skill_curator_tool(canonical_tool_name, tenant_id, dispatch_parameters)
        if (
            side_effect_proof is not None
            and isinstance(result, dict)
            and result.get("status") != "error"
        ):
            result["side_effect_proof"] = side_effect_proof
        return result

    if canonical_tool_name == "ww.skill.import":
        policy_decision, block_response = _evaluate_public_mcp_execution_gate(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
        if block_response is not None:
            return block_response
        side_effect_proof, proof_block_response = _validate_public_mcp_side_effect_proof(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
            policy_decision=policy_decision,
        )
        if proof_block_response is not None:
            return proof_block_response
        result = _dispatch_skill_import(tenant_id, _strip_side_effect_proof(parameters))
        if side_effect_proof is not None:
            result["side_effect_proof"] = side_effect_proof
        return result
    # Capability rollout state (#3543)
    if canonical_tool_name == "ww.capability.state.show":
        return _dispatch_capability_state_show(tenant_id, parameters)
    if canonical_tool_name == "ww.capability.state.list":
        return _dispatch_capability_state_list(parameters)
    handler_name = _TOOL_DISPATCH.get(dispatch_tool_name)
    if not handler_name:
        raise ValueError(f"Unknown MCP tool: {tool_name}")

    # Agent protocol tools are dispatched via a dedicated path
    if handler_name.startswith("_agent_protocol:"):
        return await _dispatch_agent_protocol_tool(dispatch_tool_name, tenant_id, parameters)

    if canonical_tool_name in _PLAN_STEER_MCP_TOOLS:
        _validate_mcp_plan_approve_actor(parameters)

    policy_decision, block_response = _evaluate_public_mcp_execution_gate(
        tool_name=canonical_tool_name or tool_name,
        tenant_id=tenant_id,
        parameters=parameters,
    )
    if block_response is not None:
        return block_response

    side_effect_proof, proof_block_response = _validate_public_mcp_side_effect_proof(
        tool_name=canonical_tool_name or tool_name,
        tenant_id=tenant_id,
        parameters=parameters,
        policy_decision=policy_decision,
    )
    if proof_block_response is not None:
        return proof_block_response

    from apps.backend.api.public_api_service import PublicResearchError, get_public_api_service

    dispatch_parameters = _strip_side_effect_proof(parameters)
    if verified_actor_id:
        dispatch_parameters["verified_actor_id"] = verified_actor_id
    if verified_actor_role is not None:
        dispatch_parameters["verified_actor_role"] = verified_actor_role
    service = get_public_api_service()
    handler = getattr(service, handler_name)
    try:
        result = await handler(tenant_id=tenant_id, **dispatch_parameters)
    except PublicResearchError as exc:
        return {
            "status": "error",
            "tool_name": canonical_tool_name or tool_name,
            "error": exc.to_dict(),
        }
    except TypeError as exc:
        if handler_name != "research_search":
            raise
        return {
            "status": "error",
            "tool_name": canonical_tool_name or tool_name,
            "error": {
                "code": "invalid_request",
                "message": str(exc),
                "evidence_id": None,
                "retryable": False,
            },
        }
    if policy_decision is not None and isinstance(result, dict):
        result.setdefault("policy_decision", policy_decision)
    if side_effect_proof is not None and isinstance(result, dict):
        result["side_effect_proof"] = side_effect_proof
    return result
