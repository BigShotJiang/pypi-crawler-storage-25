"""Google OAuth and signup region routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response, status
from fastapi.responses import RedirectResponse

from apps.backend.api.auth_models import (
    AuthProvider,
    GoogleAuthConfigResponse,
    GoogleOAuthCodeRequest,
    GoogleOAuthRequest,
    SignupRegionsResponse,
    SignupResponse,
)
from apps.backend.api.auth_signup_shared import (
    PUBLIC_WEB_ORIGIN_FALLBACK,
    ExistingAccountDifferentProviderError,
    OAuthSignupRequiredError,
    _build_cli_oauth_error_response,
    _build_post_signup_redirect,
    _emit_oauth_callback_event,
    _lookup_existing_tenant_for_identity,
    _lookup_tenant_by_email,
    _lookup_tenant_by_provider_id,
    _oauth_error_redirect_url,
    _oauth_login_start_failure_redirect,
    _provider_callback_uri,
    _resolve_oauth_login_start,
    _resolve_oauth_signin_response,
    _safe_return_to_origin,
    _set_runtime_auth_cookies,
    _signup_response_from_existing_tenant,
    get_auth_signup_facade,
    logger,
)
from apps.backend.api.auth_helpers import build_signup_consent
from apps.backend.api.rate_limit import limiter
from apps.backend.services.google_oauth import (
    GoogleOAuthRedirectError,
    mint_google_oauth_state,
    normalize_return_to_origin,
    parse_google_oauth_state,
)
from apps.backend.services.tenant_provisioning import TenantAlreadyExistsError, get_tenant_provisioning_service

router = APIRouter()


@router.post(
    "/signup/google",
    response_model=SignupResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Sign up with Google OAuth",
    description="Create tenant and user via Google OAuth. Redirects to Stripe Checkout.",
)
@limiter.limit("5/minute")
async def signup_with_google(request: Request, body: GoogleOAuthRequest, http_response: Response) -> SignupResponse:
    """Sign up user using Google OAuth."""
    if not body.accepted_terms or not body.accepted_privacy:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "error": "terms_not_accepted",
                "message": "You must accept the Terms of Service and Privacy Policy to sign up.",
            },
        )
    facade = get_auth_signup_facade()
    try:
        logger.info("Google OAuth signup request")

        if not facade.GOOGLE_SIGNUP_ENABLED:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "google_signup_disabled",
                    "message": "Google signup is currently disabled.",
                },
            )

        user_info = await facade.validate_google_id_token(
            id_token=body.id_token,
            access_token=body.access_token,
        )

        token_email = (user_info.get("email") or "").strip().lower()
        token_user_id = (user_info.get("google_user_id") or "").strip()
        if not token_email or not token_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_google_token",
                    "message": "Google token did not include required identity claims.",
                },
            )

        if body.email and body.email.lower() != token_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "email_mismatch",
                    "message": "Google token email does not match request email.",
                },
            )
        if body.google_user_id and body.google_user_id != token_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "google_user_id_mismatch",
                    "message": "Google user ID does not match request.",
                },
            )

        has_invite = bool(
            (body.invite_token and body.invite_token.strip())
            or (body.sub_tenant_invite_token and body.sub_tenant_invite_token.strip())
        )
        if not facade._domain_allowed_for_provisioning(token_email, has_valid_invite=has_invite):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=facade._domain_not_allowed_detail(),
            )

        response = await facade._complete_signup_after_identity_verification(
            owner_user_id=token_user_id,
            email=token_email,
            auth_provider=AuthProvider.GOOGLE,
            owner_name=body.name or user_info.get("name"),
            preferred_region=body.preferred_region,
            product="workweaver",
            invite_token=body.invite_token or None,
            sub_tenant_invite_token=body.sub_tenant_invite_token or None,
            consent=build_signup_consent(body.accepted_terms, body.accepted_privacy),
        )

        logger.info(
            "Created tenant %s via Google OAuth for %s, status=%s, mode=%s",
            response.tenant_id,
            token_email,
            response.status,
            response.provisioning_mode,
        )

        if str(getattr(response, "next_step", "")).startswith("runtime"):
            try:
                _set_runtime_auth_cookies(http_response, response)
            except Exception as exc:
                logger.warning("Failed setting runtime auth cookies: %s", exc)
            response.runtime_provisioning_token = None

        return response

    except HTTPException:
        raise
    except ValueError as exc:
        logger.warning("Google OAuth validation failed for %s: %s", facade._redact_email(body.email), exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_google_token",
                "message": str(exc) or "Invalid Google token",
            },
        ) from exc
    except TenantAlreadyExistsError as exc:
        logger.warning("Tenant already exists for email=%s: %s", facade._redact_email(body.email), exc)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "tenant_already_exists",
                "message": f"An account with email {body.email} already exists",
                "email": body.email,
            },
        ) from exc
    except Exception as exc:
        logger.error("Error in Google OAuth signup for %s: %s", facade._redact_email(body.email), exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "signup_failed",
                "message": "Failed to complete signup. Please try again.",
            },
        ) from exc


@router.post(
    "/signup/google/code",
    response_model=SignupResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Sign up with Google OAuth (code exchange)",
    description=(
        "Sign up using a Google Identity Services authorization code (popup code model). "
        "This avoids FedCM/third-party sign-in issues and does not rely on redirect URIs."
    ),
)
@limiter.limit("5/minute")
async def signup_with_google_code(
    request: Request, body: GoogleOAuthCodeRequest, http_response: Response
) -> SignupResponse:
    """Complete Google signup by exchanging a one-time authorization code server-side."""
    if not body.accepted_terms or not body.accepted_privacy:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "error": "terms_not_accepted",
                "message": "You must accept the Terms of Service and Privacy Policy to sign up.",
            },
        )
    facade = get_auth_signup_facade()
    try:
        logger.info("Google OAuth signup request (code exchange)")

        if not facade.GOOGLE_SIGNUP_ENABLED:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "google_signup_disabled",
                    "message": "Google signup is currently disabled.",
                },
            )

        tokens = await facade.exchange_code_for_tokens(code=body.code, redirect_uri="postmessage")
        id_token = (tokens.get("id_token") or "").strip()
        access_token = (tokens.get("access_token") or "").strip()
        user_info = await facade.validate_google_id_token(
            id_token=id_token or None,
            access_token=access_token or None,
        )

        token_email = (user_info.get("email") or "").strip().lower()
        token_user_id = (user_info.get("google_user_id") or user_info.get("sub") or "").strip()
        if not token_email or not token_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_google_token",
                    "message": "Google token did not include required identity claims.",
                },
            )

        has_invite = bool(
            (body.invite_token and body.invite_token.strip())
            or (body.sub_tenant_invite_token and body.sub_tenant_invite_token.strip())
        )
        if not facade._domain_allowed_for_provisioning(token_email, has_valid_invite=has_invite):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=facade._domain_not_allowed_detail(),
            )

        response = await facade._complete_signup_after_identity_verification(
            owner_user_id=token_user_id,
            email=token_email,
            auth_provider=AuthProvider.GOOGLE,
            owner_name=user_info.get("name"),
            preferred_region=body.preferred_region,
            product="workweaver",
            invite_token=body.invite_token or None,
            sub_tenant_invite_token=body.sub_tenant_invite_token or None,
            consent=build_signup_consent(body.accepted_terms, body.accepted_privacy),
        )

        if str(getattr(response, "next_step", "")).startswith("runtime"):
            try:
                _set_runtime_auth_cookies(http_response, response)
            except Exception as exc:
                logger.warning("Failed setting runtime auth cookies: %s", exc)
            response.runtime_provisioning_token = None

        return response

    except HTTPException:
        raise
    except TenantAlreadyExistsError as exc:
        logger.warning("Tenant already exists for Google OAuth code signup: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "tenant_already_exists",
                "message": "An account with this email already exists. Please sign in instead.",
            },
        ) from exc
    except ValueError as exc:
        logger.warning("Google OAuth code exchange failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_google_token",
                "message": str(exc) or "Invalid Google token",
            },
        ) from exc
    except Exception as exc:
        logger.error("Error in Google OAuth signup (code exchange): %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "signup_failed",
                "message": "Failed to complete signup. Please try again.",
            },
        ) from exc


@router.post(
    "/signin/google/code",
    response_model=SignupResponse,
    status_code=status.HTTP_200_OK,
    summary="Sign in with Google OAuth (code exchange)",
    description="Sign in using a Google Identity Services authorization code (popup code model).",
)
@limiter.limit("5/minute")
async def signin_with_google_code(
    request: Request, body: GoogleOAuthCodeRequest, http_response: Response
) -> SignupResponse:
    """Google OAuth sign-in that supports both existing tenants and first-time provisioning."""
    facade = get_auth_signup_facade()
    token_email = ""
    token_user_id = ""
    try:
        if not facade.GOOGLE_SIGNUP_ENABLED:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "google_signup_disabled",
                    "message": "Google signup is currently disabled.",
                },
            )

        tokens = await facade.exchange_code_for_tokens(code=body.code, redirect_uri="postmessage")
        id_token = (tokens.get("id_token") or "").strip()
        access_token = (tokens.get("access_token") or "").strip()
        user_info = await facade.validate_google_id_token(
            id_token=id_token or None,
            access_token=access_token or None,
        )

        token_email = (user_info.get("email") or "").strip().lower()
        token_user_id = (user_info.get("google_user_id") or user_info.get("sub") or "").strip()
        if not token_email or not token_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_google_token",
                    "message": "Google token did not include required identity claims.",
                },
            )

        # Identity matching: provider-ID FIRST (strong), email SECOND (weak).
        # A weak-match collision raises a clear error instead of silently
        # auto-merging — otherwise an attacker could register email+password
        # with a victim's address and steal the victim's Google sign-in.
        # See ExistingAccountDifferentProviderError for the attack details.
        strong_tenant = _lookup_tenant_by_provider_id(
            owner_user_id=token_user_id,
            product="workweaver",
        )
        if strong_tenant:
            facade._resume_runtime_provisioning_if_needed(
                strong_tenant,
                task_name="runtime_resume_from_google_signin",
                force=True,
            )
            response = _signup_response_from_existing_tenant(
                tenant=strong_tenant,
                email=token_email,
                user_id=token_user_id,
                provider=AuthProvider.GOOGLE,
            )
            try:
                _set_runtime_auth_cookies(http_response, response)
            except Exception as exc:
                logger.warning("Failed setting runtime auth cookies for existing tenant: %s", exc)
            response.runtime_provisioning_token = None
            return response

        weak_tenant = _lookup_tenant_by_email(
            email=token_email,
            product="workweaver",
        )
        if weak_tenant:
            existing_provider = str(weak_tenant.get("auth_provider") or "").strip().lower() or "email"
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error": "existing_account_different_provider",
                    "message": (
                        f"An account with this email already exists using "
                        f"{existing_provider} sign-in. Sign in with that method, "
                        f"then link Google from Settings → Account → Sign-in methods."
                    ),
                    "existing_provider": existing_provider,
                    "attempted_provider": "google",
                    "email": token_email,
                },
            )

        if not body.accepted_terms or not body.accepted_privacy:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "error": "terms_not_accepted",
                    "message": "You must accept the Terms of Service and Privacy Policy to sign up.",
                },
            )

        has_invite = bool(
            (body.invite_token and body.invite_token.strip())
            or (body.sub_tenant_invite_token and body.sub_tenant_invite_token.strip())
        )
        if not facade._domain_allowed_for_provisioning(token_email, has_valid_invite=has_invite):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=facade._domain_not_allowed_detail(),
            )

        response = await facade._complete_signup_after_identity_verification(
            owner_user_id=token_user_id,
            email=token_email,
            auth_provider=AuthProvider.GOOGLE,
            owner_name=user_info.get("name"),
            preferred_region=body.preferred_region,
            product="workweaver",
            invite_token=body.invite_token or None,
            sub_tenant_invite_token=body.sub_tenant_invite_token or None,
            consent=build_signup_consent(body.accepted_terms, body.accepted_privacy),
        )
        try:
            _set_runtime_auth_cookies(http_response, response)
        except Exception as exc:
            logger.warning("Failed setting runtime auth cookies for new tenant sign-in: %s", exc)
        response.runtime_provisioning_token = None
        return response
    except HTTPException:
        raise
    except TenantAlreadyExistsError:
        # Race-condition fallback: create_tenant lost to a concurrent write.
        # SECURITY: we MUST NOT blindly return the tenant found by email —
        # that would reopen the account-takeover vector (an attacker could
        # race to create an email+password tenant between our strong/weak
        # match checks and create_tenant). Only return a fallback tenant
        # if its owner_user_id matches the Google user ID we just
        # cryptographically verified.
        provisioning = get_tenant_provisioning_service()
        fallback_tenant = provisioning.get_tenant_by_owner(
            token_user_id, product="workweaver"
        ) or provisioning.get_tenant_by_owner(token_user_id, product=None)
        if not fallback_tenant:
            # The race was NOT the same Google account racing itself — it was
            # a different provider (or attacker) creating a tenant with the
            # same email. Surface the existing-account-different-provider
            # error so the user can sign in with their original method.
            weak = provisioning.get_tenant_by_email(
                token_email, product="workweaver"
            ) or provisioning.get_tenant_by_email(token_email, product=None)
            if weak:
                existing_provider = str(weak.get("auth_provider") or "").strip().lower() or "email"
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "error": "existing_account_different_provider",
                        "message": (
                            f"An account with this email already exists using "
                            f"{existing_provider} sign-in. Sign in with that method, "
                            f"then link Google from Settings → Account → Sign-in methods."
                        ),
                        "existing_provider": existing_provider,
                        "attempted_provider": "google",
                        "email": token_email,
                    },
                )
            raise
        facade._resume_runtime_provisioning_if_needed(
            fallback_tenant,
            task_name="runtime_resume_from_google_signin_conflict",
            force=True,
        )
        response = _signup_response_from_existing_tenant(
            tenant=fallback_tenant,
            email=token_email,
            user_id=token_user_id or str(fallback_tenant.get("owner_user_id") or ""),
            provider=AuthProvider.GOOGLE,
        )
        try:
            _set_runtime_auth_cookies(http_response, response)
        except Exception as exc:
            logger.warning("Failed setting runtime auth cookies in TenantAlreadyExists fallback: %s", exc)
        response.runtime_provisioning_token = None
        return response


@router.get(
    "/google/config",
    response_model=GoogleAuthConfigResponse,
    summary="Get public Google OAuth config",
    description="Returns Google OAuth client availability and domain policy for frontend.",
)
async def google_auth_config() -> GoogleAuthConfigResponse:
    """Return Google OAuth config used by signup frontend."""
    facade = get_auth_signup_facade()
    google_client_id = facade.get_google_client_id()
    allowed_domain = sorted(facade.ALLOWED_PROVISIONING_DOMAINS)[0] if facade.ALLOWED_PROVISIONING_DOMAINS else None
    return GoogleAuthConfigResponse(
        enabled=facade.GOOGLE_SIGNUP_ENABLED and bool(google_client_id),
        client_id=google_client_id,
        allowed_domain=allowed_domain,
        internal_bypass_domains=sorted(facade.INTERNAL_SIGNUP_BYPASS_DOMAINS),
        monthly_price_usd=facade.SIGNUP_MONTHLY_PRICE_USD,
        region_options=facade._signup_region_options(),
    )


@router.get(
    "/google/login",
    summary="Start Google OAuth redirect flow (code)",
    description="Fallback when browser FedCM/third-party sign-in blocks Google Identity Services.",
)
@limiter.limit("10/minute")
async def google_oauth_login(
    request: Request,
    return_to: str,
    preferred_region: str | None = None,
    client: str | None = None,
    client_state: str | None = None,
    code_challenge: str | None = None,
    code_challenge_method: str | None = None,
):
    """Redirect user to Google OAuth consent screen."""
    facade = get_auth_signup_facade()
    return_to_origin, normalized_client = _resolve_oauth_login_start(
        provider="google",
        return_to=return_to,
        client=client,
        client_state=client_state,
        normalize_return_to=normalize_return_to_origin,
        detail_key="message",
    )

    try:
        redirect_uri = _provider_callback_uri("google")
        state = mint_google_oauth_state(
            return_to_origin=return_to_origin,
            preferred_region=preferred_region,
            client=normalized_client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
            ttl_seconds=10 * 60,
        )
        url = facade.get_google_auth_url(redirect_uri=redirect_uri, state=state)
        return RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        return _oauth_login_start_failure_redirect(
            provider="google",
            origin=return_to_origin,
            reason=str(exc),
            client=normalized_client,
            client_state=client_state,
        )


@router.get(
    "/google/callback",
    summary="Google OAuth redirect callback (code exchange)",
    description="Completes redirect-based Google sign-in and sends the user back to Workweaver.",
)
@limiter.limit("10/minute")
async def google_oauth_callback(
    request: Request,
    http_response: Response,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    facade = get_auth_signup_facade()
    return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK
    preferred_region: str | None = None
    client = "web"
    client_state: str | None = None
    code_challenge: str | None = None
    code_challenge_method: str | None = None
    try:
        if state:
            parsed = parse_google_oauth_state(token=state)
            return_to_origin = parsed.return_to_origin
            preferred_region = parsed.preferred_region
            client = parsed.client
            client_state = parsed.client_state
            code_challenge = parsed.code_challenge
            code_challenge_method = parsed.code_challenge_method
    except GoogleOAuthRedirectError as exc:
        logger.warning("Google OAuth state parse failed: %s", exc)
        return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK

    return_to_origin = _safe_return_to_origin(return_to_origin)

    if error:
        message = (error_description or error or "Google sign-in failed").strip()
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="google",
                client_state=client_state,
                outcome="provider_error",
                error_code=message,
                message=f"Google sign-in returned an error: {message}.",
                reason=message,
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="google",
            error_code=message,
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="google",
            outcome="provider_error",
            redirect_to=dest,
            reason=message,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    if not code:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="google",
                client_state=client_state,
                outcome="missing_code",
                error_code="missing_code",
                message="Google sign-in did not return an authorization code.",
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="google",
            error_code="missing_code",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="google",
            outcome="missing_code",
            redirect_to=dest,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    # Echo back the request path so in-flight OAuth flows that started
    # on the legacy /api/v1/auth/google/callback URL keep working AFTER
    # the dispatcher deploy. See _callback_uri_from_request docstring.
    from apps.backend.api.auth_signup_shared import _callback_uri_from_request

    redirect_uri = _callback_uri_from_request(request, "google")

    try:
        tokens = await facade.exchange_code_for_tokens(code=code, redirect_uri=redirect_uri)
        id_token = (tokens.get("id_token") or "").strip()
        access_token = (tokens.get("access_token") or "").strip()
        user_info = await facade.validate_google_id_token(id_token, access_token or None)

        token_email = (user_info.get("email") or "").strip().lower()
        token_user_id = (user_info.get("google_user_id") or user_info.get("sub") or "").strip()

        if not token_email or not token_user_id:
            raise ValueError("Google sign-in did not include a valid email/user id")

        existing_tenant = _lookup_existing_tenant_for_identity(
            owner_user_id=token_user_id,
            email=token_email,
            product="workweaver",
        )
        if not existing_tenant and client != "cli" and not facade._domain_allowed_for_provisioning(token_email):
            dest = _oauth_error_redirect_url(
                origin=return_to_origin,
                provider="google",
                error_code="early_access_only_join_waitlist",
                client=client,
                client_state=client_state,
            )
            _emit_oauth_callback_event(
                provider="google",
                outcome="domain_denied",
                redirect_to=dest,
                email=token_email,
            )
            return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

        response = await _resolve_oauth_signin_response(
            provider=AuthProvider.GOOGLE,
            owner_user_id=token_user_id,
            email=token_email,
            owner_name=user_info.get("name"),
            preferred_region=preferred_region,
            product="workweaver",
            allow_signup=client != "cli",
        )
        return _build_post_signup_redirect(
            provider="google",
            response=response,
            return_to_origin=return_to_origin,
            client=client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )
    except OAuthSignupRequiredError as exc:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="google",
                client_state=client_state,
                outcome="signup_required",
                error_code="signup_required",
                message="This Google account does not have an existing Workweaver tenant yet.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="google",
            error_code="signup_required",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="google",
            outcome="signup_required",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except ExistingAccountDifferentProviderError as exc:
        # Cross-provider email collision: user has a Workweaver tenant created
        # with a DIFFERENT auth method. Do NOT auto-merge. Surface a clear
        # error so the user signs in with the original method and links
        # Google from Settings.
        logger.info(
            "Google OAuth rejected — existing account under different provider: existing=%s attempted=%s",
            exc.existing_provider,
            exc.attempted_provider,
        )
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="google",
                client_state=client_state,
                outcome="existing_account_different_provider",
                error_code="existing_account_different_provider",
                message=(
                    f"An account with this email already exists using "
                    f"{exc.existing_provider} sign-in. Sign in with that method, "
                    f"then link Google from Settings → Account."
                ),
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="google",
            error_code="existing_account_different_provider",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="google",
            outcome="existing_account_different_provider",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        if client == "cli":
            logger.warning("Google OAuth redirect callback failed: %s", exc)
            return _build_cli_oauth_error_response(
                provider="google",
                client_state=client_state,
                outcome="callback_failed",
                error_code="oauth_callback_failed",
                message="Google sign-in could not be completed.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="google",
            error_code="oauth_callback_failed",
            client=client,
            client_state=client_state,
        )
        logger.warning("Google OAuth redirect callback failed: %s", exc)
        _emit_oauth_callback_event(
            provider="google",
            outcome="callback_failed",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)


@router.get(
    "/signup/regions",
    response_model=SignupRegionsResponse,
    summary="Get signup region options",
    description="Returns human-readable regions users can choose during signup.",
)
async def signup_regions() -> SignupRegionsResponse:
    facade = get_auth_signup_facade()
    return SignupRegionsResponse(
        options=facade._signup_region_options(),
        default_external_region_code=facade.DEFAULT_EXTERNAL_SIGNUP_REGION,
        default_external_region_label=facade._region_label_for_code(facade.DEFAULT_EXTERNAL_SIGNUP_REGION),
        internal_region_code=facade.INTERNAL_SIGNUP_REGION,
        internal_region_label=facade._region_label_for_code(facade.INTERNAL_SIGNUP_REGION),
    )
