"""Goals API (M9.1) — Persistent Goals with Always-On Execution.

Endpoints:
    POST   /api/v1/mission/goals               — create persistent goal
    GET    /api/v1/mission/goals               — list all goals with progress
    GET    /api/v1/mission/goals/{id}          — goal detail with evidence trail
    GET    /api/v1/mission/goals/{id}/tree     — goal tree (nested children)
    PUT    /api/v1/mission/goals/{id}          — update goal
    DELETE /api/v1/mission/goals/{id}          — archive goal
    POST   /api/v1/mission/goals/{id}/pause    — pause goal execution
    POST   /api/v1/mission/goals/{id}/resume   — resume goal execution
    POST   /api/v1/mission/goals/{id}/complete — complete goal (+ learning loop + proof card)

Wire: IntelligenceAggregator.check_goal_alignment() scores each new goal.

Persistence: DynamoDB write-through with in-memory cache fallback.
Key schema: PK=TENANT#{tenant_id}, SK=GOAL#{goal_id}
Follows dynamo_store.py pattern (sync, same as TaskStore).

Hierarchy: Goals support parent_goal_id for tree structures.
Task generation: On goal creation, initial tasks are auto-generated.
"""

from __future__ import annotations

import copy
import logging
import uuid
from datetime import datetime, UTC
from enum import Enum
from typing import Any

from botocore.exceptions import ClientError

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.scheduling.goal_scheduler import validate_cron_expression as _validate_cron_expression
from apps.backend.services.inference_aggregator import (
    GoalAlignmentUnavailableError as _GoalAlignmentUnavailableError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/goals", tags=["goals"])

validate_cron_expression = _validate_cron_expression
GoalAlignmentUnavailableError = _GoalAlignmentUnavailableError


# ---------------------------------------------------------------------------
# Enums & Models
# ---------------------------------------------------------------------------


class GoalStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"


# Valid status transitions — terminal states have empty sets (no exit).
VALID_GOAL_TRANSITIONS: dict[str, set[str]] = {
    "active": {"paused", "completed", "archived"},
    "paused": {"active", "archived"},
    "completed": set(),  # terminal
    "archived": set(),  # terminal
}


class GoalPriority(str, Enum):
    URGENT = "urgent"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class CreateGoalRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200, description="Goal title")
    description: str = Field("", max_length=5000, description="Goal description")
    success_criteria: str = Field("", max_length=2000, description="Measurable success criteria")
    assigned_agent: str | None = Field(None, max_length=100, description="Agent ID to pursue goal")
    recurrence_cron: str | None = Field(None, max_length=100, description="Cron schedule for recurring execution")
    priority: str = Field("medium", description="Priority: urgent|high|medium|low")
    parent_goal_id: str | None = Field(None, max_length=200, description="Parent goal ID for hierarchy")
    due_date: str | None = Field(None, max_length=30, description="ISO-8601 due date (YYYY-MM-DD or full datetime)")


class UpdateGoalRequest(BaseModel):
    revision: int = Field(..., ge=1, description="Expected current revision for optimistic locking")
    title: str | None = Field(None, min_length=1, max_length=200)
    description: str | None = Field(None, max_length=5000)
    success_criteria: str | None = Field(None, max_length=2000)
    assigned_agent: str | None = Field(None, max_length=100)
    recurrence_cron: str | None = Field(None, max_length=100)
    priority: str | None = Field(None)
    parent_goal_id: str | None = Field(None, max_length=200, description="Parent goal ID for hierarchy")
    due_date: str | None = Field(None, max_length=30, description="ISO-8601 due date (YYYY-MM-DD or full datetime)")


class GoalTransitionRequest(BaseModel):
    revision: int = Field(..., ge=1, description="Expected current revision for optimistic locking")


# ---------------------------------------------------------------------------
# Task generation templates
# ---------------------------------------------------------------------------

_TASK_TEMPLATES: list[dict[str, str]] = [
    {
        "suffix": "Define milestones",
        "description_template": "Break down the goal '{title}' into measurable milestones. "
        "Identify 3-5 key checkpoints that indicate progress toward: {description}",
    },
    {
        "suffix": "Research and planning",
        "description_template": "Research best approaches for '{title}'. "
        "Analyze current state, identify blockers, and draft an execution plan. "
        "Success criteria: {success_criteria}",
    },
    {
        "suffix": "Execute first action",
        "description_template": "Take the first concrete action toward '{title}'. "
        "Start with the highest-impact, lowest-effort item from the plan. "
        "Document outcomes and any adjustments needed.",
    },
]


def generate_tasks_for_goal(goal: dict[str, Any]) -> list[dict[str, str]]:
    """Generate initial tasks from a goal's title, description, and success criteria.

    Returns a list of task dicts with 'title' and 'description' fields.
    These are lightweight templates, not LLM-generated.
    """
    title = goal.get("title", "")
    description = goal.get("description", "") or title
    success_criteria = goal.get("success_criteria", "") or "Achieve the stated goal"

    tasks: list[dict[str, str]] = []
    for template in _TASK_TEMPLATES:
        task_title = f"{title}: {template['suffix']}"
        task_description = template["description_template"].format(
            title=title,
            description=description,
            success_criteria=success_criteria,
        )
        tasks.append({"title": task_title[:200], "description": task_description[:5000]})
    return tasks


def _typed_http_exception(status_code: int, code: str, message: str) -> HTTPException:
    """Build a safe typed API error payload."""
    return HTTPException(status_code=status_code, detail={"code": code, "message": message})


class GoalStoreUnavailableError(RuntimeError):
    """Raised when durable goal storage is unavailable in non-local environments."""


class GoalRequestError(RuntimeError):
    """Raised when goal mutation semantics should map to a typed API error."""

    def __init__(self, status_code: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message


def _goal_store_memory_fallback_allowed() -> bool:
    from apps.backend.config.environment import is_development, is_test

    return is_development() or is_test()


def _raise_goal_store_unavailable() -> None:
    raise _typed_http_exception(
        503,
        "goal_store_unavailable",
        "Goal storage is temporarily unavailable.",
    )


def _call_goal_store(method: Any, *args: Any, **kwargs: Any) -> Any:
    try:
        return method(*args, **kwargs)
    except GoalStoreUnavailableError:
        _raise_goal_store_unavailable()
    except GoalRequestError as exc:
        raise _typed_http_exception(exc.status_code, exc.code, exc.message) from exc


def _ensure_parent_goal_belongs_to_tenant(
    store: GoalStore,
    tenant_id: str,
    parent_goal_id: str | None,
    *,
    child_goal_id: str | None = None,
) -> None:
    """Reject parent links that do not resolve to the current tenant."""
    if not parent_goal_id:
        return
    if child_goal_id and parent_goal_id == child_goal_id:
        raise _typed_http_exception(
            422,
            "invalid_parent_goal",
            "A goal cannot be its own parent.",
        )
    parent_goal = store.get_goal(tenant_id, parent_goal_id)
    if not parent_goal or parent_goal.get("tenant_id") != tenant_id:
        raise _typed_http_exception(
            404,
            "parent_goal_not_found",
            "Parent goal must belong to the current tenant.",
        )


# ---------------------------------------------------------------------------
# Store (DynamoDB write-through with in-memory cache fallback)
# ---------------------------------------------------------------------------


class GoalStore:
    """DynamoDB-backed goal store with in-memory cache fallback.

    Uses the shared tenants table via dynamo_store module.
    Key schema: PK=TENANT#{tenant_id}, SK=GOAL#{goal_id}
    Falls back to in-memory-only when DynamoDB is unavailable (local dev/tests).
    """

    SK_PREFIX = "GOAL#"

    def __init__(self) -> None:
        self._cache: dict[str, dict[str, Any]] = {}
        self._dynamo_available: bool | None = None

    def _is_dynamo_available(self) -> bool:
        """Check if DynamoDB is reachable.

        Success is cached so healthy DynamoDB stays fast. Failures are not cached
        permanently so availability is re-probed on subsequent calls.
        """
        if self._dynamo_available is not None:
            return self._dynamo_available
        try:
            from apps.backend.services.dynamo_store import _get_table

            _get_table()
            self._dynamo_available = True
        except Exception:
            if not _goal_store_memory_fallback_allowed():
                logger.error(
                    "DynamoDB unavailable; GoalStore refusing memory-only fallback outside local/dev/test",
                    exc_info=True,
                )
                raise GoalStoreUnavailableError("Durable goal storage is unavailable")
            logger.info("DynamoDB unavailable; GoalStore operating in memory-only mode")
            self._dynamo_available = None
            return False
        return True

    def _sort_key(self, goal_id: str) -> str:
        """Build the SK for a goal. Ensures GOAL# prefix."""
        if goal_id.startswith(self.SK_PREFIX):
            return goal_id
        return f"{self.SK_PREFIX}{goal_id}"

    def _pk(self, tenant_id: str) -> str:
        """Build PK from tenant_id, adding TENANT# prefix if missing."""
        if tenant_id.startswith("TENANT#"):
            return tenant_id
        return f"TENANT#{tenant_id}"

    def _normalize_goal(self, goal: dict[str, Any]) -> dict[str, Any]:
        normalized = copy.deepcopy(goal)
        normalized.setdefault("evidence_trail", [])
        normalized.setdefault("task_history", [])
        normalized.setdefault("revision", 1)
        return normalized

    def _cache_goal(self, tenant_id: str, goal: dict[str, Any]) -> None:
        self._cache[self._cache_key(tenant_id, goal["goal_id"])] = self._normalize_goal(goal)

    def _is_conditional_check_failed(self, exc: Exception) -> bool:
        return (
            isinstance(exc, ClientError)
            and exc.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException"
        )

    def _validate_parent_goal(self, tenant_id: str, goal_id: str, parent_goal_id: str | None) -> None:
        if not parent_goal_id:
            return
        if parent_goal_id == goal_id:
            raise GoalRequestError(
                422,
                "invalid_parent_goal",
                "A goal cannot be its own parent.",
            )
        parent_goal = self.get_goal(tenant_id, parent_goal_id)
        if not parent_goal:
            raise GoalRequestError(
                404,
                "parent_goal_not_found",
                "Parent goal must belong to the current tenant.",
            )

    def _persist(
        self,
        tenant_id: str,
        goal: dict[str, Any],
        *,
        expected_revision: int | None = None,
        creating: bool = False,
    ) -> None:
        """Write goal to DynamoDB, failing closed when a durable write cannot complete."""
        if not self._is_dynamo_available():
            return
        try:
            from apps.backend.services.dynamo_store import _get_table, _serialize_value

            table = _get_table()
            item = {
                "PK": self._pk(tenant_id),
                "SK": self._sort_key(goal["goal_id"]),
                "data": _serialize_value(goal),
                "revision": int(goal.get("revision") or 1),
                "updated_at": goal.get("updated_at"),
                "created_at": goal.get("created_at"),
            }
            put_kwargs: dict[str, Any] = {"Item": item}
            if creating:
                put_kwargs["ConditionExpression"] = "attribute_not_exists(PK) AND attribute_not_exists(SK)"
            elif expected_revision is not None:
                put_kwargs["ConditionExpression"] = "attribute_not_exists(#revision) OR #revision = :expected_revision"
                put_kwargs["ExpressionAttributeNames"] = {"#revision": "revision"}
                put_kwargs["ExpressionAttributeValues"] = {":expected_revision": int(expected_revision)}
            table.put_item(**put_kwargs)
        except Exception as exc:
            self._dynamo_available = None
            if self._is_conditional_check_failed(exc):
                raise GoalRequestError(
                    409,
                    "goal_revision_conflict",
                    "Goal was updated by another process. Retry with a fresh copy.",
                ) from exc
            logger.warning("DynamoDB persist failed for goal %s", goal.get("goal_id"), exc_info=True)
            if _goal_store_memory_fallback_allowed():
                raise GoalStoreUnavailableError("Durable goal storage is unavailable") from exc
            raise GoalStoreUnavailableError("Durable goal storage is unavailable") from exc

    def _load_from_dynamo(self, tenant_id: str, goal_id: str) -> dict[str, Any] | None:
        """Load a single goal from DynamoDB."""
        if not self._is_dynamo_available():
            return None
        try:
            from apps.backend.services.dynamo_store import get_item

            goal = get_item(tenant_id, self._sort_key(goal_id))
            if goal is None:
                return None
            return self._normalize_goal(goal)
        except Exception as exc:
            logger.warning("DynamoDB get failed for goal %s", goal_id, exc_info=True)
            if not _goal_store_memory_fallback_allowed():
                raise GoalStoreUnavailableError("Durable goal storage is unavailable") from exc
            return None

    def _load_all_from_dynamo(self, tenant_id: str) -> list[dict[str, Any]] | None:
        """Load all goals for a tenant from DynamoDB."""
        if not self._is_dynamo_available():
            return None
        try:
            from apps.backend.services.dynamo_store import query_items

            goals = query_items(tenant_id, self.SK_PREFIX)
            return [self._normalize_goal(goal) for goal in goals]
        except Exception as exc:
            logger.warning("DynamoDB query failed for tenant goals", exc_info=True)
            if not _goal_store_memory_fallback_allowed():
                raise GoalStoreUnavailableError("Durable goal storage is unavailable") from exc
            return None

    def _delete_from_dynamo(self, tenant_id: str, goal_id: str) -> None:
        """Delete a goal from DynamoDB."""
        if not self._is_dynamo_available():
            return
        try:
            from apps.backend.services.dynamo_store import delete_item

            delete_item(tenant_id, self._sort_key(goal_id))
        except Exception:
            logger.warning("DynamoDB delete failed for goal %s", goal_id, exc_info=True)

    def _cache_key(self, tenant_id: str, goal_id: str) -> str:
        """Build a unique cache key from tenant and goal IDs."""
        return f"{self._pk(tenant_id)}|{goal_id}"

    def create_goal(
        self,
        tenant_id: str,
        *,
        goal_id: str | None = None,
        title: str,
        description: str = "",
        success_criteria: str = "",
        assigned_agent: str | None = None,
        recurrence_cron: str | None = None,
        priority: str = "medium",
        alignment_score: float = 0.0,
        parent_goal_id: str | None = None,
        due_date: str | None = None,
        status: str | None = None,
        **extra_fields: Any,
    ) -> dict[str, Any]:
        """Create a new goal, persist to DynamoDB, and cache locally."""
        goal_id = goal_id or f"GOAL#{uuid.uuid4().hex[:12]}"
        self._validate_parent_goal(tenant_id, goal_id, parent_goal_id)
        now = datetime.now(UTC).isoformat()
        goal = self._normalize_goal(
            {
                "goal_id": goal_id,
                "tenant_id": tenant_id,
                "title": title,
                "description": description,
                "success_criteria": success_criteria,
                "assigned_agent": assigned_agent,
                "recurrence_cron": recurrence_cron,
                "priority": priority,
                "status": status or GoalStatus.ACTIVE.value,
                "progress": 0.0,
                "alignment_score": alignment_score,
                "parent_goal_id": parent_goal_id,
                "due_date": due_date,
                "evidence_trail": [],
                "task_history": [],
                "created_at": now,
                "updated_at": now,
                "revision": 1,
                **extra_fields,
            }
        )
        # Write-through: DynamoDB first, then cache
        self._persist(tenant_id, goal, creating=True)
        self._cache_goal(tenant_id, goal)
        return copy.deepcopy(goal)

    def list_goals(
        self,
        tenant_id: str,
        *,
        parent_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """List active goals for a tenant, optionally filtered by parent_goal_id.

        Args:
            tenant_id: Tenant ID (with or without TENANT# prefix).
            parent_id: If provided, return only direct children of this goal.
                        Use empty string "" to get root goals (no parent).
        """
        # Try DynamoDB first for authoritative data
        dynamo_goals = self._load_all_from_dynamo(tenant_id)
        if dynamo_goals is not None:
            goals = dynamo_goals
        else:
            # Fallback to cache
            pk = self._pk(tenant_id)
            goals = [
                self._normalize_goal(g)
                for g in self._cache.values()
                if g.get("tenant_id") == tenant_id or self._pk(g.get("tenant_id", "")) == pk
            ]

        # Filter out archived goals
        goals = [g for g in goals if g.get("status") != GoalStatus.ARCHIVED.value]

        # Filter by parent_id if specified
        if parent_id is not None:
            if parent_id == "":
                # Root goals only (no parent)
                goals = [g for g in goals if not g.get("parent_goal_id")]
            else:
                goals = [g for g in goals if g.get("parent_goal_id") == parent_id]

        return [copy.deepcopy(goal) for goal in goals]

    def get_goal(self, tenant_id: str, goal_id: str) -> dict[str, Any] | None:
        """Get a single goal by ID. Tries DynamoDB first, falls back to cache."""
        # Try DynamoDB
        dynamo_goal = self._load_from_dynamo(tenant_id, goal_id)
        if dynamo_goal is not None:
            # Verify tenant isolation
            pk = self._pk(tenant_id)
            goal_tenant = dynamo_goal.get("tenant_id", "")
            if goal_tenant == tenant_id or self._pk(goal_tenant) == pk:
                self._cache_goal(tenant_id, dynamo_goal)
                return copy.deepcopy(dynamo_goal)
            return None

        # Fallback to cache
        cached = self._cache.get(self._cache_key(tenant_id, goal_id))
        if cached:
            return copy.deepcopy(self._normalize_goal(cached))

        return None

    def _assert_no_parent_cycle(self, tenant_id: str, goal_id: str, parent_goal_id: str | None) -> None:
        if not parent_goal_id:
            return

        seen = {goal_id}
        current_parent_id = parent_goal_id
        while current_parent_id:
            if current_parent_id in seen:
                raise GoalRequestError(
                    409,
                    "goal_cycle_detected",
                    "Goal hierarchy cannot contain cycles.",
                )
            seen.add(current_parent_id)
            parent_goal = self.get_goal(tenant_id, current_parent_id)
            if not parent_goal:
                return
            current_parent_id = str(parent_goal.get("parent_goal_id") or "").strip() or None

    def update_goal(
        self,
        tenant_id: str,
        goal_id: str,
        updates: dict[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> dict[str, Any] | None:
        """Update goal fields. Persists to DynamoDB and updates cache."""
        goal = self.get_goal(tenant_id, goal_id)
        if not goal:
            return None

        next_goal = self._normalize_goal(goal)
        current_revision = int(next_goal.get("revision") or 1)
        if expected_revision is not None and current_revision != int(expected_revision):
            raise GoalRequestError(
                409,
                "goal_revision_conflict",
                "Goal was updated by another process. Retry with a fresh copy.",
            )
        for key, value in updates.items():
            if value is not None:
                next_goal[key] = value
        self._validate_parent_goal(tenant_id, goal_id, next_goal.get("parent_goal_id"))
        self._assert_no_parent_cycle(tenant_id, goal_id, next_goal.get("parent_goal_id"))
        next_goal["updated_at"] = datetime.now(UTC).isoformat()
        next_goal["revision"] = current_revision + 1

        # Write-through
        self._persist(tenant_id, next_goal, expected_revision=current_revision)
        self._cache_goal(tenant_id, next_goal)
        return copy.deepcopy(next_goal)

    def archive_goal(self, tenant_id: str, goal_id: str) -> bool:
        """Archive a goal (soft delete). Persists to DynamoDB.

        Uses set_goal_status to enforce transition guards -- only goals in
        a state that allows transitioning to ARCHIVED will succeed.
        Returns False when the goal does not exist or the transition is invalid.
        """
        result = self.set_goal_status(tenant_id, goal_id, GoalStatus.ARCHIVED)
        return result is not None

    def set_goal_status(
        self,
        tenant_id: str,
        goal_id: str,
        status: GoalStatus,
        *,
        expected_revision: int | None = None,
    ) -> dict[str, Any] | None:
        """Set goal status. Persists to DynamoDB.

        Raises:
            ValueError: If the requested transition is not valid from the current status.
        """
        goal = self.get_goal(tenant_id, goal_id)
        if not goal:
            return None

        current_status = goal.get("status", "active")
        new_status = status.value
        valid_next = VALID_GOAL_TRANSITIONS.get(current_status, set())
        if new_status not in valid_next:
            raise GoalRequestError(
                409,
                "invalid_goal_transition",
                f"Goal cannot transition from {current_status} to {new_status}.",
            )

        next_goal = self._normalize_goal(goal)
        current_revision = int(next_goal.get("revision") or 1)
        if expected_revision is not None and current_revision != int(expected_revision):
            raise GoalRequestError(
                409,
                "goal_revision_conflict",
                "Goal was updated by another process. Retry with a fresh copy.",
            )
        next_goal["status"] = status.value
        next_goal["updated_at"] = datetime.now(UTC).isoformat()
        next_goal["revision"] = current_revision + 1

        self._persist(tenant_id, next_goal, expected_revision=current_revision)
        self._cache_goal(tenant_id, next_goal)
        return copy.deepcopy(next_goal)

    def get_goal_tree(self, tenant_id: str, root_goal_id: str) -> dict[str, Any] | None:
        """Build a nested tree structure starting from the given root goal.

        Returns the root goal with a 'children' key containing nested sub-goals.
        """
        root = self.get_goal(tenant_id, root_goal_id)
        if not root:
            return None

        all_goals = self.list_goals(tenant_id)
        return self._build_tree(root, all_goals, ancestors=set())

    def _build_tree(
        self, node: dict[str, Any], all_goals: list[dict[str, Any]], *, ancestors: set[str]
    ) -> dict[str, Any]:
        """Recursively build a tree from a flat list of goals."""
        node_id = node["goal_id"]
        if node_id in ancestors:
            raise GoalRequestError(
                409,
                "goal_cycle_detected",
                "Goal hierarchy cannot contain cycles.",
            )
        next_ancestors = set(ancestors)
        next_ancestors.add(node_id)
        children = [g for g in all_goals if g.get("parent_goal_id") == node_id]
        tree_node = copy.deepcopy(node)
        tree_node["children"] = [self._build_tree(child, all_goals, ancestors=next_ancestors) for child in children]
        return tree_node


# ---------------------------------------------------------------------------
# Singleton factories (for dependency injection)
# ---------------------------------------------------------------------------

_goal_store: GoalStore | None = None


def _get_goal_store() -> GoalStore:
    global _goal_store  # noqa: PLW0603
    if _goal_store is None:
        _goal_store = GoalStore()
    return _goal_store


def _get_intelligence_aggregator():  # type: ignore[return]
    from apps.backend.services.inference_aggregator import get_intelligence_aggregator

    return get_intelligence_aggregator()


def _get_evidence_ledger_service():  # type: ignore[return]
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


def _get_workitem_service():  # type: ignore[return]
    from apps.backend.services.execution.workitem_service import get_workitem_service

    return get_workitem_service()


def get_task_store():  # type: ignore[return]
    """Lazy accessor for TaskStore singleton (avoids import-time DynamoDB connection)."""
    from apps.backend.services.task_store import get_task_store as _factory

    return _factory()


def _get_proof_card_service():  # type: ignore[return]
    """Lazy accessor for ProofCardService singleton."""
    from apps.backend.services.proof_card_service import get_proof_card_service

    return get_proof_card_service()


def _build_learning_loop_for_goal(tenant_id: str) -> Any:
    """Construct a tenant-scoped LearningLoopService for goal completion observation.

    Uses lazy imports to avoid circular dependencies. Returns a service with
    observe_interaction() method, or raises if construction fails.
    """
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service
    from apps.backend.services.learning import build_learning_loop_service
    from apps.backend.services.memory.service import get_memory_service

    return build_learning_loop_service(
        tenant_id=tenant_id,
        memory_service=get_memory_service(),
        evidence_service=get_evidence_ledger_service(),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("", status_code=201)
async def create_goal(
    body: CreateGoalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    aggregator: Any = Depends(_get_intelligence_aggregator),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
    workitems: Any = Depends(_get_workitem_service),
) -> dict[str, Any]:
    """Create a goal through the canonical WorkItem mutation seam."""
    item = await workitems.create_work_item(
        tenant_id=tenant_id,
        payload={
            "source_kind": "goal",
            "title": body.title,
            "description": body.description,
            "success_criteria": body.success_criteria,
            "assigned_agent": body.assigned_agent,
            "recurrence_cron": body.recurrence_cron,
            "priority": body.priority,
            "parent_item_id": body.parent_goal_id,
            "due_date": body.due_date,
        },
        goal_store=store,
        task_store=None,
        aggregator=aggregator,
        evidence_ledger=evidence_ledger,
    )
    return workitems.legacy_goal_payload(item)


async def _create_tasks_for_goal(
    tenant_id: str,
    goal: dict[str, Any],
    *,
    goal_store: GoalStore | None = None,
) -> list[dict[str, Any]]:
    """Create tasks for a goal via WorkItemService (Contract 1 canonical path).

    Returns a list of task_history entries: [{"task_id": ..., "title": ..., "status": ...}].
    Routes through WorkItemService.create_work_item() to maintain one work identity.
    """
    task_templates = generate_tasks_for_goal(goal)
    task_entries: list[dict[str, Any]] = []

    # Route through WorkItemService (Contract 1)
    try:
        from apps.backend.services.execution.workitem_service import WorkItemService

        svc = WorkItemService()
        task_store = get_task_store()

        for tmpl in task_templates:
            wi_result = await svc.create_work_item(
                tenant_id=tenant_id,
                payload={
                    "source_kind": "task",
                    "title": tmpl["title"],
                    "description": tmpl["description"],
                    "assigned_agent": goal.get("assigned_agent"),
                    "status": "paused",  # Unified status; WorkItemService maps to "backlog" for legacy store
                    "priority": goal.get("priority", "medium"),
                    "parent_item_id": goal["goal_id"],
                    "goal_id": goal["goal_id"],
                },
                goal_store=goal_store,
                task_store=task_store,
                parent_goal_snapshot=goal,
            )
            task_entries.append(
                {
                    "task_id": wi_result.get("id") or wi_result.get("item_id", ""),
                    "title": tmpl["title"],
                    "status": "backlog",
                    "created_from": "goal_auto_generate",
                    "goal_id": goal["goal_id"],
                }
            )
        logger.info(
            "Auto-generated %d tasks for goal %s via TaskStore",
            len(task_entries),
            goal["goal_id"],
        )
        # Emit task.created events for async execution dispatch
        try:
            from apps.backend.services.event_bus import get_event_bus

            event_bus = get_event_bus()
            for entry in task_entries:
                await event_bus.publish(
                    event_type="task.created",
                    tenant_id=tenant_id,
                    data={
                        "task_id": entry["task_id"],
                        "goal_id": goal["goal_id"],
                        "title": entry["title"],
                        "status": "backlog",
                        "priority": goal.get("priority", "medium"),
                    },
                )
            logger.info("Emitted task.created events for %d tasks", len(task_entries))
        except Exception as event_exc:
            logger.warning("Failed to emit task.created events: %s", event_exc)
    except Exception as exc:
        # TaskStore unavailable (tests, local dev) — generate inline task records
        logger.warning(
            "TaskStore unavailable for auto-task generation: %s; creating inline records",
            exc,
        )
        for tmpl in task_templates:
            task_id = f"TASK#{uuid.uuid4().hex[:12]}"
            task_entries.append(
                {
                    "task_id": task_id,
                    "title": tmpl["title"],
                    "status": "backlog",
                    "created_from": "goal_auto_generate",
                    "goal_id": goal["goal_id"],
                }
            )

    return task_entries


@router.get("")
def list_goals(
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    parent_id: str | None = Query(None, description="Filter by parent goal ID. Empty string for root goals."),
) -> dict[str, Any]:
    """List all active goals for the tenant, optionally filtered by parent_id."""
    goals = _call_goal_store(store.list_goals, tenant_id, parent_id=parent_id)
    return {"goals": goals, "count": len(goals)}


@router.get("/{goal_id}")
def get_goal(
    goal_id: str,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
) -> dict[str, Any]:
    """Get goal detail with evidence trail and task history."""
    from apps.backend.services.task_store import get_task_store
    from apps.backend.services.execution.workitem_service import get_workitem_service

    try:
        task_store: Any | None = get_task_store()
    except Exception:
        task_store = None

    try:
        goal = get_workitem_service().get_work_item(
            tenant_id=tenant_id,
            item_id=goal_id,
            source_kind="goal",
            goal_store=store,
            task_store=task_store,
        )
    except GoalStoreUnavailableError:
        _raise_goal_store_unavailable()

    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    response.headers["X-Deprecated"] = f"use /api/v1/work-items/{goal_id}"
    return goal


@router.get("/{goal_id}/tree")
def get_goal_tree(
    goal_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
) -> dict[str, Any]:
    """Get goal tree structure with nested children."""
    tree = _call_goal_store(store.get_goal_tree, tenant_id, goal_id)
    if not tree:
        raise HTTPException(status_code=404, detail="Goal not found")
    return tree


@router.put("/{goal_id}")
def update_goal(
    goal_id: str,
    body: UpdateGoalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    workitems: Any = Depends(_get_workitem_service),
) -> dict[str, Any]:
    """Update a goal through the canonical WorkItem mutation seam."""
    updated_item = workitems.update_work_item(
        tenant_id=tenant_id,
        item_id=goal_id,
        payload={
            "revision": body.revision,
            **({"title": body.title} if body.title is not None else {}),
            **({"description": body.description} if body.description is not None else {}),
            **({"success_criteria": body.success_criteria} if body.success_criteria is not None else {}),
            **({"assigned_agent": body.assigned_agent} if body.assigned_agent is not None else {}),
            **({"recurrence_cron": body.recurrence_cron} if body.recurrence_cron is not None else {}),
            **({"priority": body.priority} if body.priority is not None else {}),
            **({"parent_item_id": body.parent_goal_id} if "parent_goal_id" in body.model_fields_set else {}),
            **({"due_date": body.due_date} if body.due_date is not None else {}),
        },
        fields_set={
            "revision",
            *({"title"} if body.title is not None else set()),
            *({"description"} if body.description is not None else set()),
            *({"success_criteria"} if body.success_criteria is not None else set()),
            *({"assigned_agent"} if body.assigned_agent is not None else set()),
            *({"recurrence_cron"} if body.recurrence_cron is not None else set()),
            *({"priority"} if body.priority is not None else set()),
            *({"parent_item_id"} if "parent_goal_id" in body.model_fields_set else set()),
            *({"due_date"} if body.due_date is not None else set()),
        },
        source_kind="goal",
        goal_store=store,
        task_store=None,
    )
    return workitems.legacy_goal_payload(updated_item)


@router.delete("/{goal_id}")
def archive_goal(
    goal_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    workitems: Any = Depends(_get_workitem_service),
) -> dict[str, Any]:
    """Archive a goal through the canonical WorkItem mutation seam."""
    workitems.delete_work_item(
        tenant_id=tenant_id,
        item_id=goal_id,
        source_kind="goal",
        goal_store=store,
        task_store=None,
    )
    return {"goal_id": goal_id, "status": "archived"}


@router.post("/{goal_id}/pause")
def pause_goal(
    goal_id: str,
    body: GoalTransitionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
) -> dict[str, Any]:
    """Pause goal execution. Ingests evidence:goal_status_transition event."""
    # Capture old status before transition
    old_goal = _call_goal_store(store.get_goal, tenant_id, goal_id)
    old_status = old_goal["status"] if old_goal else "unknown"

    goal = _call_goal_store(
        store.set_goal_status,
        tenant_id,
        goal_id,
        GoalStatus.PAUSED,
        expected_revision=body.revision,
    )
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    # Ingest status transition evidence (best-effort)
    try:
        evidence_ledger.ingest(
            tenant_id=tenant_id,
            event_type="evidence:goal_status_transition",
            data={
                "goal_id": goal_id,
                "old_status": old_status,
                "new_status": GoalStatus.PAUSED.value,
            },
            actor_path="goals/status_transition",
        )
    except Exception as exc:
        logger.warning("Evidence ingest failed for goal_status_transition: %s", exc)

    return goal


@router.post("/{goal_id}/resume")
def resume_goal(
    goal_id: str,
    body: GoalTransitionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
) -> dict[str, Any]:
    """Resume goal execution. Ingests evidence:goal_status_transition event."""
    # Capture old status before transition
    old_goal = _call_goal_store(store.get_goal, tenant_id, goal_id)
    old_status = old_goal["status"] if old_goal else "unknown"

    goal = _call_goal_store(
        store.set_goal_status,
        tenant_id,
        goal_id,
        GoalStatus.ACTIVE,
        expected_revision=body.revision,
    )
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    # Ingest status transition evidence (best-effort)
    try:
        evidence_ledger.ingest(
            tenant_id=tenant_id,
            event_type="evidence:goal_status_transition",
            data={
                "goal_id": goal_id,
                "old_status": old_status,
                "new_status": GoalStatus.ACTIVE.value,
            },
            actor_path="goals/status_transition",
        )
    except Exception as exc:
        logger.warning("Evidence ingest failed for goal_status_transition: %s", exc)

    return goal


@router.post("/{goal_id}/complete")
def complete_goal(
    goal_id: str,
    body: GoalTransitionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: GoalStore = Depends(_get_goal_store),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
) -> dict[str, Any]:
    """Complete a goal. Ingests evidence, feeds learning loop, and generates proof card.

    On completion:
    1. Transitions status to COMPLETED
    2. Ingests evidence:goal_status_transition event
    3. Feeds learning loop with goal_completed observation (best-effort)
    4. Generates a proof card for the completed goal (best-effort)
    """
    # Capture old status before transition
    old_goal = _call_goal_store(store.get_goal, tenant_id, goal_id)
    old_status = old_goal["status"] if old_goal else "unknown"

    goal = _call_goal_store(
        store.set_goal_status,
        tenant_id,
        goal_id,
        GoalStatus.COMPLETED,
        expected_revision=body.revision,
    )
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    # Ingest status transition evidence (best-effort)
    try:
        evidence_ledger.ingest(
            tenant_id=tenant_id,
            event_type="evidence:goal_status_transition",
            data={
                "goal_id": goal_id,
                "old_status": old_status,
                "new_status": GoalStatus.COMPLETED.value,
            },
            actor_path="goals/status_transition",
        )
    except Exception as exc:
        logger.warning("Evidence ingest failed for goal_status_transition: %s", exc)

    # Feed learning loop with goal completion observation (best-effort)
    _observe_goal_completion(tenant_id, goal_id, goal)

    # Synthesise goal-scoped retrospective and route verdict to Skillify (best-effort)
    _synthesize_goal_retrospective(tenant_id, goal_id, goal, evidence_ledger=evidence_ledger)

    # Generate proof card for completed goal (best-effort)
    _generate_goal_proof_card(tenant_id, goal_id, goal)

    return goal


def _observe_goal_completion(tenant_id: str, goal_id: str, goal: dict[str, Any]) -> None:
    """Feed the learning loop with a goal_completed observation.

    Best-effort: failures are logged but never block the completion response.
    """
    try:
        ll = _build_learning_loop_for_goal(tenant_id)
    except Exception as exc:
        logger.warning("Learning loop construction failed for goal %s: %s", goal_id, exc)
        return

    agent_id = goal.get("assigned_agent") or "system"
    task_history = goal.get("task_history", [])

    try:
        ll.observe_interaction(
            tenant_id=tenant_id,
            agent_id=agent_id,
            interaction_type="goal_completed",
            input_summary=f"Goal: {goal.get('title', '')}",
            output_summary=f"Completed with {len(task_history)} tasks",
            outcome="success",
            metadata={
                "goal_id": goal_id,
                "tasks_completed": len(task_history),
                "title": goal.get("title", ""),
            },
        )
    except Exception as exc:
        logger.warning("Learning loop observe failed for goal_completed %s: %s", goal_id, exc)


def _generate_goal_proof_card(tenant_id: str, goal_id: str, goal: dict[str, Any]) -> None:
    """Generate a proof card for a completed goal.

    Creates a proof card and immediately completes it with goal metadata.
    Best-effort: failures are logged but never block the completion response.
    """
    try:
        pcs = _get_proof_card_service()
    except Exception as exc:
        logger.warning("Proof card service unavailable for goal %s: %s", goal_id, exc)
        return

    try:
        actor = goal.get("assigned_agent") or "system"
        card = pcs.create_card(
            tenant_id=tenant_id,
            mission_ref=goal_id,
            title=f"Goal completed: {goal.get('title', '')}",
            actor=actor,
            mission_type="goal",
        )
        task_count = len(goal.get("task_history", []))
        pcs.complete_card(
            card_id=card.card_id,
            tenant_id=tenant_id,
            confidence_score=1.0,
            outcome_summary=f"Goal '{goal.get('title', '')}' completed with {task_count} tasks",
        )
    except Exception as exc:
        logger.warning("Proof card generation failed for goal %s: %s", goal_id, exc)


def _build_goal_retrospective_service() -> Any:
    """Construct a GoalScopedRetrospectiveService using lazy imports.

    Reuses the same factory pattern as ``_build_learning_loop_for_goal``.
    Raises if construction fails (caller wraps in try/except).
    """
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service
    from apps.backend.services.memory.service import get_memory_service
    from apps.backend.services.retrospective.goal_scoped_retrospective import GoalScopedRetrospectiveService

    return GoalScopedRetrospectiveService(
        evidence_ledger=get_evidence_ledger_service(),
        tool_call_store=None,
        work_memory=get_memory_service(),
    )


def _build_skillify_service_for_goal() -> Any:
    """Construct a SkillifyService for the skillify hook (best-effort)."""
    from apps.backend.services.skillify import SkillifyService

    return SkillifyService()


def _synthesize_goal_retrospective(
    tenant_id: str,
    goal_id: str,
    goal: dict[str, Any],
    *,
    evidence_ledger: Any,
) -> None:
    """Run goal-scoped retrospective synthesis and route verdict to SkillifyService.

    Decision Trace ordering:
        goal_completed → goal_retrospective → (skillify_proposal | skill_proposal_blocked)

    Best-effort: failures are logged but never block the completion response.
    """
    from apps.backend.services.skillify_hook import route_verdict_to_skillify

    try:
        retro_svc = _build_goal_retrospective_service()
    except Exception as exc:
        logger.warning("Goal retrospective service construction failed for %s: %s", goal_id, exc)
        return

    try:
        synthesis = retro_svc.synthesize_goal(
            tenant_id=tenant_id,
            goal_id=goal_id,
            goal=goal,
        )
    except Exception as exc:
        logger.warning("Goal retrospective synthesis failed for %s: %s", goal_id, exc)
        return

    try:
        skillify_svc = _build_skillify_service_for_goal()
    except Exception as exc:
        logger.warning("SkillifyService construction failed for goal %s: %s", goal_id, exc)
        return

    try:
        route_verdict_to_skillify(
            tenant_id=tenant_id,
            goal_id=goal_id,
            synthesis=synthesis,
            skillify_service=skillify_svc,
            evidence_ledger=evidence_ledger,
        )
    except Exception as exc:
        logger.warning("Skillify routing failed for goal %s: %s", goal_id, exc)
