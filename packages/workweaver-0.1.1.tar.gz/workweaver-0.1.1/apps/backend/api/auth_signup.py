"""Authentication signup facade.

This module preserves the historic import surface for auth signup routes while
delegating the implementation to smaller sibling modules.

The facade pattern: sub-modules (auth_signup_google, auth_signup_enterprise) call
get_auth_signup_facade() → returns this module. They then access attributes as
``facade.X``. This module re-exports everything they need so monkeypatch has a
single consistent target and the facade contract is explicit.
"""

from __future__ import annotations

import os

from fastapi import APIRouter

# ── Router aggregation ────────────────────────────────────────────────────────
from apps.backend.api.auth_signup_email import router as auth_signup_email_router
from apps.backend.api.auth_signup_enterprise import router as auth_signup_enterprise_router
from apps.backend.api.auth_signup_google import router as auth_signup_google_router

# ── Re-exports from auth_helpers (noqa: F401 — accessed via facade.X) ────────
from apps.backend.api.auth_helpers import (  # noqa: F401
    ALLOWED_PROVISIONING_DOMAINS,
    DEFAULT_EXTERNAL_SIGNUP_REGION,
    GOOGLE_SIGNUP_ENABLED,
    INTERNAL_SIGNUP_BYPASS_DOMAINS,
    INTERNAL_SIGNUP_REGION,
    SIGNUP_MONTHLY_PRICE_USD,
    _allow_test_email_bypass,
    _complete_signup_after_identity_verification,
    _disable_cognito,
    _domain_allowed_for_provisioning,
    _domain_not_allowed_detail,
    _is_test_email_bypass_address,
    _redact_email,
    _region_label_for_code,
    _require_cognito_idp,
    _require_verifications_table,
    _resolve_signup_region,
    _resume_runtime_provisioning_if_needed,
    _set_browser_session_cookie,
    _set_runtime_provisioning_cookie,
    _signup_region_options,
)

# ── OAuth client credentials (noqa: F401 — accessed via facade.X) ─────────────
from apps.backend.config.secrets import (  # noqa: F401
    get_google_client_id,
    get_google_client_secret,
    get_microsoft_client_id,
    get_microsoft_client_secret,
    get_zoho_client_id,
    get_zoho_client_secret,
)

# ── OAuth service functions (noqa: F401 — accessed via facade.X) ──────────────
from apps.backend.services.google_oauth import (  # noqa: F401
    exchange_code_for_tokens,
    get_google_auth_url,
    validate_google_id_token,
)
from apps.backend.services.microsoft_auth import (  # noqa: F401
    get_microsoft_auth_url,
    validate_microsoft_signin,
)
from apps.backend.services.zoho.auth import (  # noqa: F401
    get_zoho_auth_url,
    validate_zoho_signin,
)

# ── Env flags (kept here for backward compat + monkeypatch target) ─────────────
MICROSOFT_SIGNUP_ENABLED = os.environ.get("MICROSOFT_SIGNUP_ENABLED", "true").lower() == "true"
ZOHO_SIGNUP_ENABLED = os.environ.get("ZOHO_SIGNUP_ENABLED", "true").lower() == "true"

router = APIRouter()

for child_router in (
    auth_signup_google_router,
    auth_signup_email_router,
    auth_signup_enterprise_router,
):
    router.include_router(child_router)
