"""Kernel tool-call long tail surface (#3544).

Background
----------
``PromptBudget`` collapses Zara's awareness fragment into four fixed slots
(see :mod:`apps.backend.services.zara.prompt_budget`). The long tail of
capabilities, connector health, capacity envelopes, and OTel cost-burn
lives behind on-demand kernel tool-calls so the prompt size never drifts
upward as the surface grows. PRODUCT-CONTEXT §21 calls this the
composable-capability tier split.

Routes
------
* ``GET  /api/v1/kernel/capabilities/search`` — top-K capability rows
  matching a query string. Tenant-scoped; ranks by case-insensitive
  substring score over capability id, display name, description, and
  category.
* ``GET  /api/v1/kernel/connectors/{connector_id}/health`` — circuit
  state, retry budget, success rate, p95/p99 latency, and structured
  remediation hints for one connector.
* ``GET  /api/v1/kernel/capacity`` — tenant-wide capacity envelope —
  per-Function provider context, always-on quota, active workers,
  zero-burn target, and dormant ratio.
* ``GET  /api/v1/kernel/otel/cost-burn`` — rolling cost burn over a
  configurable window (default 24h).

Each route is **read-only**. Decision Trace emission is handled by the
§14 ``kernel.*`` skills already in the registry; this module is the
operator-facing surface tenants and CLI/MCP callers reach for.

Idempotency: every route caches its response per
``(tenant_id, query_hash, minute_bucket)`` so repeated reads in the
same minute collapse onto a single computation.
"""

from __future__ import annotations

import hashlib
import threading
from dataclasses import asdict, is_dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.capability.service import (
    CAPABILITY_CATALOG,
    Capability,
)
from apps.backend.services.capacity.zero_burn_sli import (
    get_zero_burn_sli_service,
)
from apps.backend.services.connector_health_service import (
    ConnectorHealthSnapshot,
    get_connector_health_service,
)
from apps.backend.services.zara.prompt_budget import minute_bucket
from apps.backend.services.zara.zara_awareness_service import (
    list_function_capacity_envelopes,
)


__all__ = [
    "router",
    "CapabilitySearchRow",
    "CapabilitySearchResponse",
    "ConnectorHealthResponse",
    "CapacityEnvelopeResponse",
    "CapacityFunctionRow",
    "OtelCostBurnResponse",
    "score_capability",
    "search_capabilities",
    "build_capacity_envelope_payload",
    "build_otel_cost_burn_payload",
]


router = APIRouter(prefix="/api/v1/kernel", tags=["kernel", "tools"])


# ---------------------------------------------------------------------------
# Tool-call cache (idempotency: tenant + query_hash + minute_bucket)
# ---------------------------------------------------------------------------


class _ToolCallCache:
    """Per-planning-loop cache for kernel tool-call results.

    Keyed by ``(tenant_id, query_hash, minute_bucket)``. The minute
    bucket guarantees stale results never linger past the awareness
    re-fetch cadence; the query_hash means concurrent searches with
    different args do not poison each other.
    """

    def __init__(self, max_entries: int = 256) -> None:
        self._entries: dict[tuple[str, str, int], Any] = {}
        self._lock = threading.Lock()
        self._max_entries = max(1, int(max_entries))

    def get(self, tenant_id: str, query_hash: str, bucket: int) -> Any | None:
        with self._lock:
            return self._entries.get((tenant_id, query_hash, bucket))

    def set(self, tenant_id: str, query_hash: str, bucket: int, value: Any) -> None:
        with self._lock:
            self._entries[(tenant_id, query_hash, bucket)] = value
            if len(self._entries) > self._max_entries:
                oldest = next(iter(self._entries))
                del self._entries[oldest]

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()


_CACHE = _ToolCallCache()


def reset_tool_cache_for_testing() -> None:
    _CACHE.clear()


def _query_hash(payload: Any) -> str:
    raw = repr(payload).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


# ---------------------------------------------------------------------------
# 1) Capabilities search
# ---------------------------------------------------------------------------


class CapabilitySearchRow(BaseModel):
    capability_id: str
    display_name: str
    description: str
    category: str
    score: float = 0.0
    is_enabled: bool = True


class CapabilitySearchResponse(BaseModel):
    tenant_id: str
    query: str
    top_k: int
    results: list[CapabilitySearchRow] = Field(default_factory=list)
    total_candidates: int = 0


def score_capability(capability: Capability, query: str) -> float:
    """Case-insensitive substring score over a capability row.

    Higher is better. Empty query returns the catalog order (score=1.0)
    so callers can list the catalog by passing query="".
    """
    if not query:
        return 1.0
    needle = query.casefold()
    score = 0.0
    for haystack, weight in (
        (capability.id, 3.0),
        (capability.display_name, 2.0),
        (capability.description, 1.0),
        (capability.category, 1.0),
    ):
        if not haystack:
            continue
        if needle in haystack.casefold():
            score += weight
    return score


def search_capabilities(
    *,
    tenant_id: str,
    query: str,
    top_k: int = 5,
) -> CapabilitySearchResponse:
    """Score every catalog capability against ``query`` and return the top K."""
    bounded_top_k = max(1, min(int(top_k or 5), 50))
    catalog = list(CAPABILITY_CATALOG.values())
    scored: list[tuple[float, Capability]] = []
    for cap in catalog:
        score = score_capability(cap, query)
        if score > 0.0:
            scored.append((score, cap))
    scored.sort(key=lambda pair: (-pair[0], pair[1].id))
    rows = [
        CapabilitySearchRow(
            capability_id=cap.id,
            display_name=cap.display_name,
            description=cap.description,
            category=cap.category,
            score=score,
            is_enabled=cap.is_enabled,
        )
        for score, cap in scored[:bounded_top_k]
    ]
    return CapabilitySearchResponse(
        tenant_id=tenant_id,
        query=query,
        top_k=bounded_top_k,
        results=rows,
        total_candidates=len(catalog),
    )


@router.get("/capabilities/search", response_model=CapabilitySearchResponse)
def get_capabilities_search(
    query: str = Query(default="", description="Substring query, case-insensitive."),
    top_k: int = Query(default=5, ge=1, le=50),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapabilitySearchResponse:
    bucket = minute_bucket()
    qhash = _query_hash(("capabilities.search", query, top_k))
    cached = _CACHE.get(tenant_id, qhash, bucket)
    if cached is not None:
        return cached
    response = search_capabilities(tenant_id=tenant_id, query=query, top_k=top_k)
    _CACHE.set(tenant_id, qhash, bucket, response)
    return response


# ---------------------------------------------------------------------------
# 2) Connector health
# ---------------------------------------------------------------------------


class ConnectorHealthResponse(BaseModel):
    tenant_id: str
    connector_id: str
    circuit_state: str
    success_rate_24h: float
    p95_latency_ms: float
    p99_latency_ms: float
    total_calls: int
    total_successes: int
    total_failures: int
    retry_budget_remaining: int
    uptime_percentage_24h: float
    last_failure_at: str | None = None
    last_success_at: str | None = None
    last_failure_message: str | None = None
    last_failure_category: str | None = None
    needs_reauth: bool = False


def _snapshot_to_response(snapshot: ConnectorHealthSnapshot) -> ConnectorHealthResponse:
    return ConnectorHealthResponse(
        tenant_id=snapshot.tenant_id,
        connector_id=snapshot.connector_id,
        circuit_state=snapshot.circuit_state,
        success_rate_24h=float(snapshot.success_rate_24h),
        p95_latency_ms=float(snapshot.p95_latency_ms),
        p99_latency_ms=float(snapshot.p99_latency_ms),
        total_calls=int(snapshot.total_calls),
        total_successes=int(snapshot.total_successes),
        total_failures=int(snapshot.total_failures),
        retry_budget_remaining=int(snapshot.retry_budget_remaining),
        uptime_percentage_24h=float(snapshot.uptime_percentage_24h),
        last_failure_at=snapshot.last_failure_at,
        last_success_at=snapshot.last_success_at,
        last_failure_message=snapshot.last_failure_message,
        last_failure_category=snapshot.last_failure_category,
        needs_reauth=bool(snapshot.needs_reauth),
    )


@router.get("/connectors/{connector_id}/health", response_model=ConnectorHealthResponse)
def get_connector_health(
    connector_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConnectorHealthResponse:
    if not connector_id:
        raise HTTPException(status_code=400, detail="connector_id is required")
    bucket = minute_bucket()
    qhash = _query_hash(("connector_health", connector_id))
    cached = _CACHE.get(tenant_id, qhash, bucket)
    if cached is not None:
        return cached
    service = get_connector_health_service()
    snapshot = service.get_health(tenant_id, connector_id)
    response = _snapshot_to_response(snapshot)
    _CACHE.set(tenant_id, qhash, bucket, response)
    return response


# ---------------------------------------------------------------------------
# 3) Capacity envelope (per-Function rollup)
# ---------------------------------------------------------------------------


class CapacityFunctionRow(BaseModel):
    function_id: str
    provider_context: str | None = None
    always_on_quota: int = 0
    active_workers: int = 0
    max_concurrent: int = 0
    zero_burn_target_usd: float = 0.0
    is_zero_burn: bool = False


class CapacityEnvelopeResponse(BaseModel):
    tenant_id: str
    function_count: int
    active_workers: int
    dormant_count: int
    always_on_quota_total: int
    max_concurrent_total: int
    functions: list[CapacityFunctionRow] = Field(default_factory=list)


def build_capacity_envelope_payload(*, tenant_id: str) -> CapacityEnvelopeResponse:
    envelopes = list_function_capacity_envelopes(tenant_id) or []
    sli = get_zero_burn_sli_service()
    function_ids = [getattr(env, "function_id", None) for env in envelopes]
    function_ids = [fid for fid in function_ids if fid]
    summary = sli.tenant_zero_burn_summary(
        workspace_id=tenant_id, function_ids=function_ids
    )
    zero_burn_rows = {row.get("work_function_id"): row for row in summary.get("functions", [])}

    rows: list[CapacityFunctionRow] = []
    active_workers_total = 0
    always_on_total = 0
    max_concurrent_total = 0
    dormant_count = 0
    for env in envelopes:
        fid = getattr(env, "function_id", None)
        if not fid:
            continue
        active_workers = int(getattr(env, "active_workers", 0) or 0)
        always_on = int(getattr(env, "always_on_quota", 0) or 0)
        max_concurrent = int(getattr(env, "max_concurrent", 0) or 0)
        provider_context = getattr(env, "provider_context", None)
        zero_burn_target = float(getattr(env, "zero_burn_target_usd", 0.0) or 0.0)

        zero_burn_row = zero_burn_rows.get(fid) or {}
        is_zero_burn = bool(zero_burn_row.get("is_zero_burn"))
        if is_zero_burn:
            dormant_count += 1

        active_workers_total += active_workers
        always_on_total += always_on
        max_concurrent_total += max_concurrent

        rows.append(
            CapacityFunctionRow(
                function_id=str(fid),
                provider_context=str(provider_context) if provider_context else None,
                always_on_quota=always_on,
                active_workers=active_workers,
                max_concurrent=max_concurrent,
                zero_burn_target_usd=zero_burn_target,
                is_zero_burn=is_zero_burn,
            )
        )

    return CapacityEnvelopeResponse(
        tenant_id=tenant_id,
        function_count=len(rows),
        active_workers=active_workers_total,
        dormant_count=dormant_count,
        always_on_quota_total=always_on_total,
        max_concurrent_total=max_concurrent_total,
        functions=rows,
    )


@router.get("/capacity", response_model=CapacityEnvelopeResponse)
def get_capacity_envelope(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapacityEnvelopeResponse:
    bucket = minute_bucket()
    qhash = _query_hash(("capacity_envelope",))
    cached = _CACHE.get(tenant_id, qhash, bucket)
    if cached is not None:
        return cached
    response = build_capacity_envelope_payload(tenant_id=tenant_id)
    _CACHE.set(tenant_id, qhash, bucket, response)
    return response


# ---------------------------------------------------------------------------
# 4) OTel cost-burn
# ---------------------------------------------------------------------------


class OtelCostBurnResponse(BaseModel):
    tenant_id: str
    window_hours: int
    window_start: str
    window_end: str
    total_cost_usd: float = 0.0
    metric_totals: dict[str, float] = Field(default_factory=dict)
    sample_count: int = 0
    note: str | None = None


def build_otel_cost_burn_payload(
    *,
    tenant_id: str,
    window_hours: int,
) -> OtelCostBurnResponse:
    if window_hours is None:
        window_hours = 24
    try:
        candidate = int(window_hours)
    except (TypeError, ValueError):
        candidate = 24
    bounded_window = max(1, min(candidate, 24 * 30))
    end = datetime.now(timezone.utc)
    start = end - timedelta(hours=bounded_window)

    total_cost = 0.0
    metric_totals: dict[str, float] = {}
    sample_count = 0
    note: str | None = None

    events: list[dict[str, Any]] = []
    try:
        from apps.backend.services.usage_tracker import UsageTrackerService

        tracker = UsageTrackerService()
        # Walk current and (when needed) prior month so a 24-720h window
        # never silently drops events across month boundaries.
        seen_months: set[tuple[int, int]] = set()
        cursor = end
        while cursor >= start:
            key = (cursor.year, cursor.month)
            if key not in seen_months:
                seen_months.add(key)
                try:
                    chunk = tracker.list_usage_events(
                        tenant_id=tenant_id,
                        year=key[0],
                        month=key[1],
                    )
                except Exception:
                    chunk = []
                events.extend(chunk or [])
            # step to the first day of the previous month
            first_of_month = cursor.replace(day=1)
            cursor = first_of_month - timedelta(days=1)
    except Exception as exc:  # noqa: BLE001 — degrade gracefully
        events = []
        note = f"usage_tracker_unavailable: {type(exc).__name__}"

    for event in events or []:
        if not isinstance(event, dict):
            continue
        timestamp_raw = str(event.get("timestamp") or "").strip()
        if timestamp_raw:
            try:
                ts = datetime.fromisoformat(timestamp_raw.replace("Z", "+00:00"))
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=timezone.utc)
                if ts < start or ts > end:
                    continue
            except ValueError:
                continue
        sample_count += 1
        try:
            cost = float(event.get("cost_usd") or 0.0)
        except (TypeError, ValueError):
            cost = 0.0
        total_cost += cost
        metric = str(event.get("metric_type") or event.get("metric") or "unknown")
        metric_totals[metric] = metric_totals.get(metric, 0.0) + cost

    return OtelCostBurnResponse(
        tenant_id=tenant_id,
        window_hours=bounded_window,
        window_start=start.isoformat(),
        window_end=end.isoformat(),
        total_cost_usd=round(total_cost, 6),
        metric_totals={k: round(v, 6) for k, v in metric_totals.items()},
        sample_count=sample_count,
        note=note,
    )


@router.get("/otel/cost-burn", response_model=OtelCostBurnResponse)
def get_otel_cost_burn(
    window_hours: int = Query(default=24, ge=1, le=24 * 30),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OtelCostBurnResponse:
    bucket = minute_bucket()
    qhash = _query_hash(("cost_burn", window_hours))
    cached = _CACHE.get(tenant_id, qhash, bucket)
    if cached is not None:
        return cached
    response = build_otel_cost_burn_payload(
        tenant_id=tenant_id, window_hours=window_hours
    )
    _CACHE.set(tenant_id, qhash, bucket, response)
    return response


# ---------------------------------------------------------------------------
# Helpers (reused by MCP)
# ---------------------------------------------------------------------------


def to_serializable(payload: Any) -> Any:
    """Best-effort dataclass/Pydantic serialization for MCP responses."""
    if hasattr(payload, "model_dump"):
        return payload.model_dump()
    if is_dataclass(payload):
        return asdict(payload)
    if isinstance(payload, dict):
        return {k: to_serializable(v) for k, v in payload.items()}
    if isinstance(payload, (list, tuple)):
        return [to_serializable(item) for item in payload]
    return payload
