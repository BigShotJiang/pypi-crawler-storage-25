"""Mission watchface — canonical top-level read endpoints (issues #1173-#1179).

The Mission surface (the canonical product home per
``docs/PRODUCT.md``) needs five top-level GETs to render its
watchface tiles:

- ``GET /api/v1/missions``      → list of recent missions for the tenant
- ``GET /api/v1/calendar``      → TimeBlock list for a date / view range
- ``GET /api/v1/tasks``         → tasks filtered by status
- ``GET /api/v1/goals``         → goals filtered by status
- ``GET /api/v1/health/summary`` → tenant health pulse rollup

Each of these used to 404 in production because the underlying data was
stored under sub-prefixes (``/api/v1/mission/tasks``,
``/api/v1/mission/goals``, ``/api/v1/agent-work/calendar``,
``/api/v1/revenue-pack/missions``) and ``/health/summary`` did not
exist. This module is the canonical seam: thin handlers that delegate
to the existing services and expose them at the user-mental-model URL
the frontend was already calling.

Structural properties (post-GLM round-1 review):

1. **Tenant from auth context.** Every handler resolves ``tenant_id``
   via :func:`get_verified_tenant_id`; we never read it from the
   request body or query string.
2. **Hard-cap pagination.** ``limit`` is bounded server-side
   (``Query(..., ge=1, le=N)``) so a malicious or buggy client can't
   scan the whole table.
3. **Enum-validated query params.** ``status``, ``view`` are restricted
   via Literal types — invalid values are 422'd by FastAPI before
   reaching the store.
4. **Empty-state responses are 200, never 500.** Empty tenant returns a
   well-shaped payload with ``count=0`` / ``items=[]`` so the
   watchface tile renders an empty state, not a broken one.
5. **Per-section graceful degradation in /health/summary.** Each metric
   is independently try-caught and returns
   ``{available: false, error: "..."}`` on its own failure rather than
   500'ing the whole response.
6. **Tenant-scoped cache headers.** Responses set
   ``Cache-Control: private, max-age=30`` so browsers / CDN edge can
   coalesce within a tenant. The 30-second TTL bounds staleness for
   the watchface use case.

This file is deliberately small (no business logic — just adapters) so
that future changes to the underlying stores propagate via the existing
service interfaces rather than divergent re-implementations.
"""

from __future__ import annotations

import logging
from datetime import UTC, date, datetime, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["mission-watchface"])

# Limit caps (GLM round-1 review): the watchface needs at most a small
# slice; aggressive caps prevent DOS via ``?limit=99999``.
_MISSIONS_DEFAULT_LIMIT = 5
_MISSIONS_MAX_LIMIT = 50
_TASKS_DEFAULT_LIMIT = 100
_TASKS_MAX_LIMIT = 200
_GOALS_DEFAULT_LIMIT = 100
_GOALS_MAX_LIMIT = 200

# Calendar date clamp (GLM): reject windows outside ±90 days from today
# so a stray client can't scan the full TimeBlock partition.
_CALENDAR_MAX_DAYS_OFFSET = 90

# Per-tenant cache TTL for watchface tiles. 30s balances "feels live"
# against "don't hammer the store on every Mission render."
_WATCHFACE_CACHE_SECONDS = 30


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class MissionSummary(BaseModel):
    """One row in the missions watchface tile."""

    mission_id: str
    title: str | None = None
    status: str | None = None
    updated_at: str | None = None


class MissionsListResponse(BaseModel):
    missions: list[MissionSummary] = Field(default_factory=list)
    count: int = 0


class CalendarBlock(BaseModel):
    block_id: str
    start_at: str
    end_at: str
    title: str | None = None
    state: str | None = None
    outcome: str | None = None
    mission_id: str | None = None


class CalendarResponse(BaseModel):
    date: str
    view: Literal["day", "week", "month"]
    blocks: list[CalendarBlock] = Field(default_factory=list)
    count: int = 0


class TaskSummary(BaseModel):
    task_id: str
    title: str
    status: str
    priority: str | None = None
    assigned_agent: str | None = None
    updated_at: str | None = None


class TasksListResponse(BaseModel):
    tasks: list[TaskSummary] = Field(default_factory=list)
    count: int = 0


class GoalSummary(BaseModel):
    goal_id: str
    title: str | None = None
    status: str | None = None
    progress: float | None = None
    updated_at: str | None = None


class GoalsListResponse(BaseModel):
    goals: list[GoalSummary] = Field(default_factory=list)
    count: int = 0


class HealthSignal(BaseModel):
    """One individually-degradable signal in the tenant health rollup.

    Per Codex round-1 review, ``/api/v1/health/summary`` must surface
    *tenant-facing operational state* (active blocks, pending judgments,
    connector alerts, degraded integrations, failed runs) — not infra
    vanity metrics. Each signal is independently optional so a single
    sub-system outage degrades to ``available=false`` for that signal
    while the rest of the rollup still loads.
    """

    available: bool = True
    error: str | None = None
    value: int | None = None
    detail: str | None = None


class HealthSignalsBundle(BaseModel):
    active_blocks: HealthSignal = Field(default_factory=HealthSignal)
    pending_judgments: HealthSignal = Field(default_factory=HealthSignal)
    connector_alerts: HealthSignal = Field(default_factory=HealthSignal)
    degraded_integrations: HealthSignal = Field(default_factory=HealthSignal)
    failed_runs_24h: HealthSignal = Field(default_factory=HealthSignal)


class HealthSummaryResponse(BaseModel):
    """Tenant-facing operational health rollup.

    Shape per Codex round-1 review (deliberately product-shaped, not
    infra-shaped). The watchface tile reads ``status`` and ``score``
    for the headline; ``signals`` for the drill-down chips.
    """

    status: Literal["healthy", "degraded", "attention", "unknown"] = "unknown"
    score: int = Field(default=0, ge=0, le=100, description="Composite 0-100 health score")
    summary: str = ""
    signals: HealthSignalsBundle = Field(default_factory=HealthSignalsBundle)
    generated_at: str


# ---------------------------------------------------------------------------
# /api/v1/missions
# ---------------------------------------------------------------------------


@router.get("/missions", response_model=MissionsListResponse)
async def list_missions(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(_MISSIONS_DEFAULT_LIMIT, ge=1, le=_MISSIONS_MAX_LIMIT),
    sort: Literal["updated_at", "created_at"] = Query("updated_at"),
) -> MissionsListResponse:
    """Recent missions for the tenant (closes #1175).

    Delegates to revenue_pack mission listing, projecting to the small
    watchface shape. Sort defaults to ``updated_at`` desc.
    """
    response.headers["Cache-Control"] = f"private, max-age={_WATCHFACE_CACHE_SECONDS}"

    try:
        from apps.backend.api.revenue_pack import list_revenue_pack_missions

        rows = await list_revenue_pack_missions(tenant_id=tenant_id, limit=limit)
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001 — keep watchface tile alive on degraded backend
        logger.exception("missions_watchface_load_failed", extra={"tenant_id": tenant_id})
        return MissionsListResponse(missions=[], count=0)

    summaries = [
        MissionSummary(
            mission_id=row.mission_id,
            title=getattr(row, "brief", None) or getattr(row, "subject_id", None),
            status=getattr(row, "approval_state", None),
            updated_at=getattr(row, "created_at", None),
        )
        for row in rows
    ]

    if sort == "updated_at":
        summaries.sort(key=lambda m: (m.updated_at or ""), reverse=True)

    summaries = summaries[:limit]
    return MissionsListResponse(missions=summaries, count=len(summaries))


# ---------------------------------------------------------------------------
# /api/v1/calendar
# ---------------------------------------------------------------------------


def _resolve_calendar_window(date_str: str | None, view: str) -> tuple[datetime, datetime, date]:
    """Resolve ``date`` + ``view`` into a (start, end, anchor_date) tuple.

    Caps the window at ±``_CALENDAR_MAX_DAYS_OFFSET`` from today so a
    crafted query cannot scan the whole partition.
    """
    today = datetime.now(UTC).date()
    if date_str:
        try:
            anchor_date = date.fromisoformat(date_str)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=f"Invalid date: {exc}") from exc
    else:
        anchor_date = today

    delta = abs((anchor_date - today).days)
    if delta > _CALENDAR_MAX_DAYS_OFFSET:
        raise HTTPException(
            status_code=422,
            detail=f"date must be within ±{_CALENDAR_MAX_DAYS_OFFSET} days of today",
        )

    if view == "day":
        start = datetime.combine(anchor_date, datetime.min.time(), tzinfo=UTC)
        end = start + timedelta(days=1)
    elif view == "week":
        # Monday-anchored week.
        weekday = anchor_date.weekday()
        week_start = anchor_date - timedelta(days=weekday)
        start = datetime.combine(week_start, datetime.min.time(), tzinfo=UTC)
        end = start + timedelta(days=7)
    else:  # month
        month_start = anchor_date.replace(day=1)
        start = datetime.combine(month_start, datetime.min.time(), tzinfo=UTC)
        # Step to first day of next month.
        if month_start.month == 12:
            next_month_start = month_start.replace(year=month_start.year + 1, month=1)
        else:
            next_month_start = month_start.replace(month=month_start.month + 1)
        end = datetime.combine(next_month_start, datetime.min.time(), tzinfo=UTC)

    return start, end, anchor_date


@router.get("/calendar", response_model=CalendarResponse)
@router.get("/time-blocks", response_model=CalendarResponse)
async def calendar(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    date_str: str | None = Query(None, alias="date", description="Anchor date (YYYY-MM-DD)"),
    view: Literal["day", "week", "month"] = Query("day"),
) -> CalendarResponse:
    """TimeBlock calendar for the tenant (closes #1176, canonicalized by #1182).

    Delegates to the agent-work-ledger service which owns TimeBlock
    storage. Returns the ``CalendarResponse`` shape the watchface
    expects rather than the heavier internal projection.

    Two public URLs share this handler per docs/PRODUCT.md contract 2:

    - ``/api/v1/calendar`` — legacy adapter noun (kept for one release
      cycle; frontend migrated to the canonical URL in #1182 Phase C).
    - ``/api/v1/time-blocks`` — canonical Contract 2 URL; the name
      matches the ``TimeBlock`` primitive at
      ``apps/backend/models/time_block.py``.
    """
    response.headers["Cache-Control"] = f"private, max-age={_WATCHFACE_CACHE_SECONDS}"

    start, end, anchor_date = _resolve_calendar_window(date_str, view)

    blocks: list[CalendarBlock] = []
    try:
        from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service

        ledger = get_agent_work_ledger_service()
        raw = ledger.list_calendar_blocks(
            tenant_id,
            start_at=start,
            end_at=end,
            timezone_name="UTC",
        )
        # raw may be a Pydantic model, a dict, a SimpleNamespace, or a list.
        # Handle each shape explicitly so the test fixtures (and real
        # services) round-trip through the same projection logic.
        if raw is None:
            items = []
        elif hasattr(raw, "blocks"):
            items = getattr(raw, "blocks", []) or []
        elif isinstance(raw, dict):
            items = raw.get("blocks", []) or []
        elif isinstance(raw, list):
            items = raw
        else:
            items = []
        for item in items:
            if hasattr(item, "model_dump"):
                data = item.model_dump()
            elif hasattr(item, "dict"):
                data = item.dict()
            elif isinstance(item, dict):
                data = item
            else:
                # SimpleNamespace / arbitrary object: pull attributes.
                data = {
                    k: getattr(item, k, None)
                    for k in ("block_id", "id", "start_at", "end_at", "title", "state", "outcome", "mission_id")
                }
            blocks.append(
                CalendarBlock(
                    block_id=str(data.get("block_id") or data.get("id") or ""),
                    start_at=str(data.get("start_at") or ""),
                    end_at=str(data.get("end_at") or ""),
                    title=data.get("title"),
                    state=data.get("state"),
                    outcome=data.get("outcome"),
                    mission_id=data.get("mission_id"),
                )
            )
    except HTTPException:
        raise
    except Exception:  # noqa: BLE001
        logger.exception("calendar_watchface_load_failed", extra={"tenant_id": tenant_id})
        # Empty state, not 500 — watchface tile must still render.

    return CalendarResponse(date=anchor_date.isoformat(), view=view, blocks=blocks, count=len(blocks))


# ---------------------------------------------------------------------------
# /api/v1/tasks
# ---------------------------------------------------------------------------


# Frontend ↔ backend status vocabulary mapping (Codex round-1 critical
# finding). Frontend uses everyday verbs (``running``, ``completed``,
# ``cancelled``); backend's canonical TaskStatus enum at
# ``apps/backend/api/tasks.py:18`` is
# ``recurring | backlog | in_progress | review | done | blocked``. Without
# this normalizer, ``?status=running`` would either 422 (Pydantic Literal
# rejection) or silently no-op (no rows match), breaking the watchface
# tasks tile.
_FRONTEND_TO_BACKEND_TASK_STATUS: dict[str, str] = {
    "running": "in_progress",
    "in_progress": "in_progress",
    "completed": "done",
    "done": "done",
    "blocked": "blocked",
    "backlog": "backlog",
    "review": "review",
    "recurring": "recurring",
    # Cancelled / failed have no canonical backend mapping today; pass
    # through and let the store filter — the store will simply return [].
    "cancelled": "cancelled",
    "failed": "failed",
}


@router.get("/tasks", response_model=TasksListResponse)
async def list_tasks(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    status: Literal[
        "backlog",
        "running",
        "in_progress",
        "review",
        "done",
        "completed",
        "blocked",
        "recurring",
        "cancelled",
        "failed",
    ]
    | None = Query(None),
    limit: int = Query(_TASKS_DEFAULT_LIMIT, ge=1, le=_TASKS_MAX_LIMIT),
) -> TasksListResponse:
    """Tasks filtered by status (closes #1177).

    Delegates to the canonical task store; projects to the small
    watchface shape (no pipelines, no large attachments).

    **No-cache** (Codex round-1): tasks reflect live execution state.
    A 30s cache would mask actual state transitions during a run.
    """
    # Live execution state — no cache.
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"

    backend_status = _FRONTEND_TO_BACKEND_TASK_STATUS.get(status) if status else None

    try:
        from apps.backend.services.task_store import get_task_store

        store = get_task_store()
        if store is None:
            return TasksListResponse(tasks=[], count=0)
        rows = store.list_tasks(tenant_id=tenant_id, status=backend_status, agent_id=None, limit=limit)
    except Exception:  # noqa: BLE001
        logger.exception("tasks_watchface_load_failed", extra={"tenant_id": tenant_id})
        return TasksListResponse(tasks=[], count=0)

    summaries = [
        TaskSummary(
            task_id=str(t.get("task_id") or ""),
            title=str(t.get("title") or ""),
            status=str(t.get("status") or ""),
            priority=str(t.get("priority") or "") or None,
            assigned_agent=t.get("assigned_agent"),
            updated_at=str(t.get("updated_at") or "") or None,
        )
        for t in (rows or [])
    ][:limit]
    return TasksListResponse(tasks=summaries, count=len(summaries))


# ---------------------------------------------------------------------------
# /api/v1/goals
# ---------------------------------------------------------------------------


@router.get("/goals", response_model=GoalsListResponse)
async def list_goals(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    status: Literal["active", "completed", "archived"] | None = Query(None),
    limit: int = Query(_GOALS_DEFAULT_LIMIT, ge=1, le=_GOALS_MAX_LIMIT),
) -> GoalsListResponse:
    """Goals filtered by status (closes #1178).

    Delegates to the canonical goal store. Status defaults to None
    (return all). When ``status="active"`` we filter client-side
    because the upstream store doesn't natively filter by status.
    """
    response.headers["Cache-Control"] = f"private, max-age={_WATCHFACE_CACHE_SECONDS}"

    try:
        # GoalStore lives under apps.backend.api.goals (not services/) — see
        # apps/backend/api/goals.py:226 for the class and :649 for the getter.
        from apps.backend.api.goals import _get_goal_store

        store = _get_goal_store()
        if store is None:
            return GoalsListResponse(goals=[], count=0)
        rows = store.list_goals(tenant_id=tenant_id, parent_id=None) or []
    except Exception:  # noqa: BLE001
        logger.exception("goals_watchface_load_failed", extra={"tenant_id": tenant_id})
        return GoalsListResponse(goals=[], count=0)

    if status:
        rows = [g for g in rows if str(g.get("status") or "").strip().lower() == status]

    summaries = [
        GoalSummary(
            goal_id=str(g.get("goal_id") or ""),
            title=g.get("title"),
            status=g.get("status"),
            progress=g.get("progress") if isinstance(g.get("progress"), (int, float)) else None,
            updated_at=g.get("updated_at"),
        )
        for g in rows
    ][:limit]
    return GoalsListResponse(goals=summaries, count=len(summaries))


# ---------------------------------------------------------------------------
# /api/v1/health/summary
# ---------------------------------------------------------------------------


@router.get("/health/summary", response_model=HealthSummaryResponse)
@router.get("/pulse/tenant", response_model=HealthSummaryResponse)
async def health_summary(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealthSummaryResponse:
    """Tenant-facing operational health rollup (closes #1179, canonicalized by #1182).

    Two public URLs share this handler per docs/PRODUCT.md contract 3:

    - ``/api/v1/health/summary`` — legacy adapter noun (kept for one
      release cycle; frontend migrated to the canonical URL in #1182
      Phase C).
    - ``/api/v1/pulse/tenant`` — canonical Contract 3 URL; the name
      matches the ``Pulse`` primitive owned by
      ``apps/backend/services/agent_instance_manager.py`` and
      ``core/health_watchdog.py``.

    Returns five independently-degraded **product-shaped** signals plus
    a composite ``status``/``score`` headline:

    - ``active_blocks``         — TimeBlocks currently executing
    - ``pending_judgments``     — Inbox items awaiting human decision
    - ``connector_alerts``      — connectors in alerting state
    - ``degraded_integrations`` — connectors marked ``degraded``
    - ``failed_runs_24h``       — autonomous runs that failed in last 24h

    Per Codex + GLM round-1: each signal is independently try-caught
    and returns ``{available: false}`` on its own failure rather than
    500'ing the whole response. **No-cache** because the watchface
    headline must reflect live state — caching would mask actual
    degradation events for up to 30 seconds.
    """
    # Live operational signals — no cache.
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"

    signals = HealthSignalsBundle(
        active_blocks=_safe_signal(_signal_active_blocks, tenant_id),
        pending_judgments=_safe_signal(_signal_pending_judgments, tenant_id),
        connector_alerts=_safe_signal(_signal_connector_alerts, tenant_id),
        degraded_integrations=_safe_signal(_signal_degraded_integrations, tenant_id),
        failed_runs_24h=_safe_signal(_signal_failed_runs_24h, tenant_id),
    )
    status, score, summary = _compose_health_headline(signals)

    return HealthSummaryResponse(
        status=status,
        score=score,
        summary=summary,
        signals=signals,
        generated_at=datetime.now(UTC).isoformat(),
    )


def _safe_signal(fn, tenant_id: str) -> HealthSignal:
    """Run a signal collector, degrading to ``available=false`` on failure."""
    try:
        value, detail = fn(tenant_id)
        return HealthSignal(available=True, value=int(value), detail=detail)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "health_summary_signal_failed",
            extra={
                "tenant_id": tenant_id,
                "signal": getattr(fn, "__name__", str(fn)),
                "error": type(exc).__name__,
            },
        )
        return HealthSignal(available=False, error=type(exc).__name__)


def _signal_active_blocks(tenant_id: str) -> tuple[int, str | None]:
    """Count TimeBlocks currently in ``active`` state."""
    try:
        from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service

        ledger = get_agent_work_ledger_service()
        active = ledger.list_active_blocks(tenant_id) if hasattr(ledger, "list_active_blocks") else []
        items = getattr(active, "blocks", active) if active is not None else []
        return (len(items or []), None)
    except AttributeError:
        # Service interface drift; report unimplemented rather than 500.
        return (0, "unimplemented")


def _signal_pending_judgments(tenant_id: str) -> tuple[int, str | None]:
    """Count Inbox items awaiting human decision."""
    try:
        from apps.backend.services.inbox_service import get_inbox_service

        svc = get_inbox_service()
        pending = svc.list_pending(tenant_id) if hasattr(svc, "list_pending") else []
        return (len(pending or []), None)
    except (ImportError, AttributeError):
        return (0, "unimplemented")


def _signal_connector_alerts(tenant_id: str) -> tuple[int, str | None]:
    """Count connectors currently in an alerting state."""
    try:
        from apps.backend.services.connectors.connector_health_monitor import (
            get_connector_health_monitor,
        )

        monitor = get_connector_health_monitor()
        alerts = monitor.list_alerts(tenant_id) if hasattr(monitor, "list_alerts") else []
        return (len(alerts or []), None)
    except (ImportError, AttributeError):
        return (0, "unimplemented")


def _signal_degraded_integrations(tenant_id: str) -> tuple[int, str | None]:
    """Count connectors marked ``degraded`` (capability-probe partial-scope failures)."""
    try:
        from apps.backend.services.connectors.connector_state_store import (
            get_connector_state_store,
        )

        store = get_connector_state_store()
        if store is None or not hasattr(store, "list_connectors"):
            return (0, "unimplemented")
        states = store.list_connectors(tenant_id) or []
        degraded = sum(1 for s in states if (s.get("status") or "").lower() == "degraded")
        return (degraded, None)
    except (ImportError, AttributeError):
        return (0, "unimplemented")


def _signal_failed_runs_24h(tenant_id: str) -> tuple[int, str | None]:
    """Count autonomous runs that failed in the last 24h."""
    try:
        from apps.backend.api.mission_runtime_api import _get_run_state_service

        run_state = _get_run_state_service()
        runs = run_state.list_runs(tenant_id=tenant_id, limit=200) or []
        cutoff = datetime.now(UTC) - timedelta(hours=24)
        cutoff_iso = cutoff.isoformat()
        failed = sum(
            1
            for r in runs
            if str(r.get("status") or "").lower() == "failed"
            and str(r.get("updated_at") or r.get("created_at") or "") >= cutoff_iso
        )
        return (failed, None)
    except (ImportError, AttributeError):
        return (0, "unimplemented")


def _compose_health_headline(signals: HealthSignalsBundle) -> tuple[str, int, str]:
    """Reduce 5 signals to a single headline ``(status, score, summary)``.

    Algorithm (intentionally simple and explainable per the
    "Decision traces are first-class" invariant):

    - score starts at 100
    - subtract 5 per ``connector_alert`` (max -25)
    - subtract 5 per ``degraded_integration`` (max -25)
    - subtract 10 per ``failed_run_24h`` (max -40)
    - subtract 1 per ``pending_judgment`` over 5 (max -10)
    - status = healthy ≥ 90, attention ≥ 70, degraded < 70
    - If any signal is ``available=false`` and we have no other
      signal indicating problems, status is ``unknown``.

    The summary is a one-line plain-English description so the
    watchface tile can render meaningful copy without a formatter.
    """
    available_signals = [
        s
        for s in (
            signals.active_blocks,
            signals.pending_judgments,
            signals.connector_alerts,
            signals.degraded_integrations,
            signals.failed_runs_24h,
        )
        if s.available
    ]
    if not available_signals:
        return ("unknown", 0, "Health signals temporarily unavailable.")

    score = 100
    if signals.connector_alerts.available and signals.connector_alerts.value:
        score -= min(signals.connector_alerts.value * 5, 25)
    if signals.degraded_integrations.available and signals.degraded_integrations.value:
        score -= min(signals.degraded_integrations.value * 5, 25)
    if signals.failed_runs_24h.available and signals.failed_runs_24h.value:
        score -= min(signals.failed_runs_24h.value * 10, 40)
    if signals.pending_judgments.available and signals.pending_judgments.value:
        backlog = max(0, signals.pending_judgments.value - 5)
        score -= min(backlog, 10)
    score = max(0, min(100, score))

    if score >= 90:
        status: Literal["healthy", "degraded", "attention", "unknown"] = "healthy"
    elif score >= 70:
        status = "attention"
    else:
        status = "degraded"

    parts: list[str] = []
    if signals.active_blocks.available:
        parts.append(f"{signals.active_blocks.value or 0} active block(s)")
    if signals.pending_judgments.available and (signals.pending_judgments.value or 0) > 0:
        parts.append(f"{signals.pending_judgments.value} pending judgment(s)")
    if signals.connector_alerts.available and (signals.connector_alerts.value or 0) > 0:
        parts.append(f"{signals.connector_alerts.value} connector alert(s)")
    if signals.degraded_integrations.available and (signals.degraded_integrations.value or 0) > 0:
        parts.append(f"{signals.degraded_integrations.value} degraded integration(s)")
    if signals.failed_runs_24h.available and (signals.failed_runs_24h.value or 0) > 0:
        parts.append(f"{signals.failed_runs_24h.value} failed run(s) in 24h")
    summary = ", ".join(parts) if parts else "All systems nominal."

    return (status, score, summary)


__all__ = ["router"]
