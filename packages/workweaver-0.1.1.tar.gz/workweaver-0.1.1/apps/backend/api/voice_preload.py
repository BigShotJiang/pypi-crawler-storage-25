"""Shared voice context preload helpers for Twilio answer paths."""

from __future__ import annotations

import os

from apps.backend.agents.context_loader import VoiceContext, load_voice_context


def resolve_voice_preload_timeout_seconds() -> float:
    """Return the bounded preload budget for PSTN answer paths."""

    return float(os.getenv("ZARA_VOICE_CONTEXT_PRELOAD_TIMEOUT_SECONDS", "1.25"))


async def build_voice_preload_metadata(
    *,
    tenant_id: str,
    caller_phone: str,
    call_sid: str,
    decision_summary: str,
    decision_type: str = "voice_answer",
    query_crm: bool = True,
) -> tuple[VoiceContext, dict[str, str]]:
    """Load caller context and package the typed metadata for Twilio streams."""

    voice_context = await load_voice_context(
        tenant_id=tenant_id or "unknown",
        caller_phone=caller_phone or call_sid,
        call_sid=call_sid or None,
        decision_summary=decision_summary,
        decision_type=decision_type,
        query_crm=query_crm,
        timeout_s=resolve_voice_preload_timeout_seconds(),
        trace_id=call_sid or "",
    )
    context_summary = voice_context.get_context_summary().strip()
    return voice_context, {
        "voice_preload_status": voice_context.preload_status,
        "voice_preload_reason": voice_context.preload_reason,
        "voice_preload_trace_id": voice_context.preload_trace_id,
        "voice_preload_ms": str(voice_context.load_time_ms),
        "voice_context_summary": context_summary,
    }
