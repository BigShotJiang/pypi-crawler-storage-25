"""Kernel HEAL ladder REST surface — issue #3545.

Read-only inspection of recent self-healing recovery incidents,
classified by ``RemediationPosture`` (auto_reversible /
approval_reversible / escalate_irreversible).

Tenant-scoped: every recovery attempt is read from the caller's tenant
mission_run state via :class:`MissionRunStateService`. The supervisor
stamps ``remediation_posture`` + ``heal_class`` into every attempt's
``extra`` metadata at write-time, so this endpoint just projects the
posture-classified view.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.mission_run.state import (
    MissionRunStateService,
    get_mission_run_state_service,
)
from apps.backend.services.runtime.remediation_posture import RemediationPosture

router = APIRouter(
    prefix="/api/v1/kernel/healing",
    tags=["kernel", "healing"],
)


class HealingActionRow(BaseModel):
    """One self-healing recovery attempt classified by posture."""

    incident_id: str
    run_id: str
    attempt_id: str | None = None
    failure_class: str
    action: str
    status: str
    actor: str
    summary: str
    started_at: str | None = None
    completed_at: str | None = None
    remediation_posture: str = Field(
        default=RemediationPosture.ESCALATE_IRREVERSIBLE.value,
        description="HEAL ladder posture: auto_reversible / approval_reversible / escalate_irreversible.",
    )
    heal_class: str | None = None
    incident_status: str
    blast_radius: str
    affected_capabilities: list[str] = Field(default_factory=list)


class HealingActionsResponse(BaseModel):
    """Recent self-healing actions for the caller's tenant."""

    tenant_id: str
    window_hours: int
    actions: list[HealingActionRow]
    posture_counts: dict[str, int] = Field(default_factory=dict)


def _parse_iso(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _select_posture(extra: dict[str, Any], signal_details: dict[str, Any]) -> str:
    """Return posture string, falling back to ESCALATE_IRREVERSIBLE."""
    candidate = (
        extra.get("remediation_posture")
        or signal_details.get("remediation_posture")
        or RemediationPosture.ESCALATE_IRREVERSIBLE.value
    )
    text = str(candidate).strip()
    valid = {p.value for p in RemediationPosture}
    return text if text in valid else RemediationPosture.ESCALATE_IRREVERSIBLE.value


def _select_heal_class(
    incident: dict[str, Any], extra: dict[str, Any], signal_details: dict[str, Any]
) -> str | None:
    candidate = (
        extra.get("heal_class")
        or signal_details.get("heal_class")
        or incident.get("failure_class")
    )
    if candidate is None:
        return None
    text = str(candidate).strip()
    return text or None


def collect_recent_healing_actions(
    *,
    tenant_id: str,
    window_hours: int,
    service: MissionRunStateService,
    now: datetime | None = None,
) -> HealingActionsResponse:
    """Return posture-classified healing actions in the last ``window_hours``."""
    bounded_window = max(1, min(int(window_hours or 24), 24 * 30))
    cutoff_now = now or datetime.now(timezone.utc)
    cutoff = cutoff_now - timedelta(hours=bounded_window)

    rows: list[HealingActionRow] = []
    posture_counts: dict[str, int] = {p.value: 0 for p in RemediationPosture}
    try:
        runs = service.list_runs(tenant_id=tenant_id, limit=500)
    except Exception:  # noqa: BLE001 — degrade gracefully when run-state store is unavailable
        runs = []
    for run in runs:
        run_id = str(run.get("run_id") or "")
        if not run_id:
            continue
        try:
            incidents = service.list_recovery_incidents(tenant_id=tenant_id, run_id=run_id)
        except ValueError:
            continue
        for incident in incidents:
            signal_details = dict(incident.get("signal_details") or {})
            attempts = incident.get("attempts") or []
            if not attempts:
                detected = _parse_iso(incident.get("detected_at"))
                if detected and detected < cutoff:
                    continue
                posture = _select_posture({}, signal_details)
                heal_class = _select_heal_class(incident, {}, signal_details)
                rows.append(
                    HealingActionRow(
                        incident_id=str(incident.get("incident_id") or ""),
                        run_id=run_id,
                        attempt_id=None,
                        failure_class=str(incident.get("failure_class") or ""),
                        action=str(incident.get("containment_action") or ""),
                        status="contained_pause",
                        actor="zara.self_healing",
                        summary=str(incident.get("summary") or ""),
                        started_at=str(incident.get("detected_at") or ""),
                        completed_at=None,
                        remediation_posture=posture,
                        heal_class=heal_class,
                        incident_status=str(incident.get("status") or ""),
                        blast_radius=str(incident.get("blast_radius") or ""),
                        affected_capabilities=list(incident.get("affected_capabilities") or []),
                    )
                )
                posture_counts[posture] = posture_counts.get(posture, 0) + 1
                continue
            for attempt in attempts:
                started = _parse_iso(attempt.get("started_at")) or _parse_iso(
                    incident.get("detected_at")
                )
                if started and started < cutoff:
                    continue
                extra = dict(attempt.get("extra") or {})
                posture = _select_posture(extra, signal_details)
                heal_class = _select_heal_class(incident, extra, signal_details)
                rows.append(
                    HealingActionRow(
                        incident_id=str(incident.get("incident_id") or ""),
                        run_id=run_id,
                        attempt_id=str(attempt.get("attempt_id") or ""),
                        failure_class=str(incident.get("failure_class") or ""),
                        action=str(attempt.get("action") or ""),
                        status=str(attempt.get("status") or ""),
                        actor=str(attempt.get("actor") or ""),
                        summary=str(attempt.get("summary") or ""),
                        started_at=str(attempt.get("started_at") or ""),
                        completed_at=str(attempt.get("completed_at") or ""),
                        remediation_posture=posture,
                        heal_class=heal_class,
                        incident_status=str(incident.get("status") or ""),
                        blast_radius=str(incident.get("blast_radius") or ""),
                        affected_capabilities=list(incident.get("affected_capabilities") or []),
                    )
                )
                posture_counts[posture] = posture_counts.get(posture, 0) + 1

    rows.sort(key=lambda row: row.started_at or "", reverse=True)
    return HealingActionsResponse(
        tenant_id=tenant_id,
        window_hours=bounded_window,
        actions=rows,
        posture_counts=posture_counts,
    )


@router.get("/recent", response_model=HealingActionsResponse)
def get_recent_healing_actions(
    window_hours: int = Query(default=24, ge=1, le=24 * 30),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealingActionsResponse:
    """List recent self-healing actions classified by RemediationPosture (#3545)."""
    service = get_mission_run_state_service()
    return collect_recent_healing_actions(
        tenant_id=tenant_id,
        window_hours=window_hours,
        service=service,
    )
