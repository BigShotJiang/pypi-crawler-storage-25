"""Mission Control activity stream endpoint for tenant activity visibility."""

from __future__ import annotations

import csv
import logging
from typing import Any
from apps.backend.utils.time import parse_iso
from datetime import datetime, UTC
from collections import Counter
from io import StringIO

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field

from apps.backend.services.audit_logger import get_audit_logger
from apps.backend.services.tenant_provisioning import get_tenant_provisioning_service


logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1", tags=["activity"])


class ActivityItem(BaseModel):
    """Single activity stream item."""

    timestamp: str = Field(..., description="ISO timestamp for activity")
    actor: str = Field(..., description="Actor who triggered the activity")
    action_type: str = Field(..., description="Normalized action type")
    description: str = Field(..., description="Human-readable activity description")
    activity_id: str | None = Field(default=None, description="Stable activity identifier")
    resource_type: str | None = Field(default=None, description="Optional affected resource type")
    resource_id: str | None = Field(default=None, description="Optional affected resource id")
    source_jumps: list[dict[str, Any] | str] = Field(default_factory=list, description="Optional memory/source jumps")
    citations: list[dict[str, Any] | str] = Field(default_factory=list, description="Optional source citations")
    historical_recall: dict[str, Any] | None = Field(default=None, description="Optional historical recall payload")


class ActivityStreamResponse(BaseModel):
    """Activity stream response payload."""

    tenant_id: str = Field(..., description="Tenant ID requested")
    activities: list[ActivityItem] = Field(..., description="Recent activity entries")
    count: int = Field(..., description="Number of returned activities")
    limit: int = Field(..., description="Requested limit used")


class EvidenceItem(BaseModel):
    """Single evidence timeline entry."""

    evidence_id: str = Field(..., description="Stable evidence identifier")
    type: str = Field(..., description="Evidence type")
    description: str = Field(..., description="Human-readable evidence description")
    timestamp: str = Field(..., description="Evidence timestamp")
    verification_status: str = Field(..., description="Evidence verification status")


class EvidenceTimelineResponse(BaseModel):
    """Evidence timeline response payload."""

    tenant_id: str = Field(..., description="Tenant ID requested")
    evidence: list[EvidenceItem] = Field(..., description="Recent evidence entries")
    count: int = Field(..., description="Number of returned evidence entries")
    limit: int = Field(..., description="Requested limit used")


class EvidenceSearchItem(EvidenceItem):
    """Single searchable evidence entry."""

    actor: str = Field(..., description="Actor who triggered the evidence event")
    action: str = Field(..., description="Raw action code")
    risk_level: str = Field(..., description="High-level risk level")
    resource_type: str | None = Field(default=None, description="Optional resource type")
    resource_id: str | None = Field(default=None, description="Optional resource id")
    skill: str | None = Field(default=None, description="Optional skill label")
    artifact_hash: str | None = Field(default=None, description="Optional artifact hash reference")


class EvidenceSearchResponse(BaseModel):
    """Evidence search response payload."""

    tenant_id: str = Field(..., description="Tenant ID requested")
    query: str | None = Field(default=None, description="Search text")
    evidence: list[EvidenceSearchItem] = Field(..., description="Matched evidence entries")
    count: int = Field(..., description="Number of returned evidence entries")
    limit: int = Field(..., description="Requested limit used")


class EvidenceReportResponse(BaseModel):
    """Evidence report response payload (JSON format)."""

    tenant_id: str = Field(..., description="Tenant ID requested")
    generated_at: str = Field(..., description="Report generated timestamp")
    query: str | None = Field(default=None, description="Search text")
    filters: dict[str, str | None] = Field(..., description="Search filters used for this report")
    count: int = Field(..., description="Entries included in the report")
    verification_summary: dict[str, int] = Field(..., description="Verification status totals")
    risk_summary: dict[str, int] = Field(..., description="Risk level totals")
    evidence: list[EvidenceSearchItem] = Field(..., description="Report entries")


def _normalize_tenant_id(raw: str) -> str:
    """Return tenant ID in `TENANT#...` format."""
    value = (raw or "").strip()
    if not value:
        return ""
    if value.startswith("TENANT#"):
        return value
    return f"TENANT#{value}"


def _humanize_action(action: str) -> str:
    """Convert event action into a readable action type."""
    if not action:
        return "Unknown Action"
    label = action.replace(".", " ").replace("_", " ").strip()
    return " ".join(word.capitalize() for word in label.split())


def _action_description(
    action: str, metadata: dict[str, Any], resource_type: str | None, resource_id: str | None
) -> str:
    """Build a human-readable description from action and metadata."""
    action = (action or "").strip()
    resource_hint = ""
    if resource_type:
        resource_hint = f"{resource_type}"
        if resource_id:
            resource_hint = f"{resource_hint}:{resource_id}"

    note = ""
    for key in ("description", "message", "notes", "review_notes", "reason", "summary"):
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            note = value.strip()
            break

    if action == "golden_trace.approved":
        return "Golden trace approved" + (f" ({resource_hint})" if resource_hint else "")
    if action == "golden_trace.rejected":
        return "Golden trace rejected" + (f" ({resource_hint})" if resource_hint else "")
    if action == "golden_trace.viewed":
        return "Golden trace reviewed" + (f" ({resource_hint})" if resource_hint else "")
    if action == "golden_trace.flagged":
        return "Golden trace flagged" + (f" ({resource_hint})" if resource_hint else "")

    if resource_hint:
        base = f"{_humanize_action(action)} on {resource_hint}"
    else:
        base = _humanize_action(action)

    if note:
        return f"{base}: {note}"
    return base


def _safe_timestamp(value: str) -> str:
    """Return a valid ISO timestamp."""
    if not isinstance(value, str):
        return datetime.now(UTC).isoformat()
    candidate = value.strip()
    if candidate:
        return candidate
    return datetime.now(UTC).isoformat()


def _normalize_verification_status(action: str, metadata: dict[str, Any], severity: str) -> str:
    """Normalize evidence verification status."""
    status = ""
    if isinstance(metadata, dict):
        candidate = metadata.get("verification_status")
        if isinstance(candidate, str):
            status = candidate.strip().lower()

    if not status:
        for value in (action, severity):
            if not isinstance(value, str):
                continue
            normalized = value.lower()
            if "reject" in normalized:
                return "Rejected"
            if normalized == "warning":
                return "Needs Review"
            if normalized in {"error", "critical"}:
                return "Failed"

        if severity.lower() in {"warning"}:
            return "Needs Review"
        if severity.lower() in {"error", "critical"}:
            return "Failed"

    if status in {"verified", "ok", "pass", "passed", "confirmed", "success"}:
        return "Verified"
    if status in {"needs_review", "needs review", "review", "pending_review", "pending"}:
        return "Needs Review"
    if status in {"rejected", "failed", "error", "invalid", "denied"}:
        return "Rejected"

    return status.title() or "Verified"


def _normalize_risk_level(raw: Any) -> str:
    """Normalize a risk level from raw severity or label."""

    if not isinstance(raw, str):
        return "low"
    normalized = raw.strip().lower().replace("_", " ")
    if normalized in {"critical", "error", "failed", "high"}:
        return "high"
    if normalized in {"warning", "medium", "elevated", "risk"}:
        return "medium"
    return "low"




def _extract_evidence_skill(metadata: dict[str, Any]) -> str | None:
    """Extract a skill label from metadata."""

    for key in ("skill", "skill_id", "tool", "tool_name", "agent", "agent_id"):
        value = metadata.get(key)
        if isinstance(value, str):
            candidate = value.strip()
            if candidate:
                return candidate
    return None


def _extract_artifact_hash(metadata: dict[str, Any]) -> str | None:
    """Extract artifact reference from metadata."""

    for key in (
        "artifact_hash",
        "artifact",
        "artifact_id",
        "object_key",
        "recording_id",
    ):
        value = metadata.get(key)
        if isinstance(value, str):
            candidate = value.strip()
            if candidate:
                return candidate
    return None


def _to_evidence_search_item(entry: Any) -> EvidenceSearchItem:
    """Convert an audit log entry into an evidence search item."""

    metadata: dict[str, Any] = {}
    if isinstance(entry.action_metadata, dict):
        metadata = entry.action_metadata

    action = str(entry.action.value) if hasattr(entry.action, "value") else str(entry.action)
    severity = str(entry.severity.value) if hasattr(entry.severity, "value") else str(entry.severity)

    return EvidenceSearchItem(
        actor=str(entry.user_id or "system").strip() or "system",
        action=action,
        evidence_id=str(entry.event_id),
        type=_humanize_action(action),
        description=_action_description(
            action=action,
            metadata=metadata,
            resource_type=str(entry.resource_type) if entry.resource_type else None,
            resource_id=str(entry.resource_id) if entry.resource_id else None,
        ),
        timestamp=_safe_timestamp(entry.timestamp),
        verification_status=_normalize_verification_status(action=action, metadata=metadata, severity=severity),
        risk_level=_normalize_risk_level(severity),
        resource_type=str(entry.resource_type) if entry.resource_type else None,
        resource_id=str(entry.resource_id) if entry.resource_id else None,
        skill=_extract_evidence_skill(metadata),
        artifact_hash=_extract_artifact_hash(metadata),
    )


def _filter_evidence_items(
    items: list[EvidenceSearchItem],
    *,
    query: str | None = None,
    actor: str | None = None,
    skill: str | None = None,
    resource_type: str | None = None,
    status: str | None = None,
    risk_level: str | None = None,
    resource_id: str | None = None,
    from_timestamp: datetime | None = None,
    to_timestamp: datetime | None = None,
) -> list[EvidenceSearchItem]:
    """Apply query and filter constraints to evidence items."""

    requested_query = (query or "").strip().lower()
    actor_filter = (actor or "").strip().lower()
    skill_filter = (skill or "").strip().lower()
    resource_type_filter = (resource_type or "").strip().lower()
    resource_id_filter = (resource_id or "").strip().lower()
    status_filter = (status or "").strip().lower()
    risk_filter = (risk_level or "").strip().lower()

    evidence = []
    for item in items:
        if actor_filter and actor_filter not in (item.actor or "").lower():
            continue
        if skill_filter and (item.skill or "").lower().find(skill_filter) < 0:
            continue
        if resource_type_filter and (item.resource_type or "").lower().find(resource_type_filter) < 0:
            continue
        if resource_id_filter and (item.resource_id or "").lower().find(resource_id_filter) < 0:
            continue
        if status_filter and (item.verification_status or "").lower() != status_filter:
            continue
        if risk_filter and (item.risk_level or "").lower() != risk_filter:
            continue

        event_ts = parse_iso(item.timestamp)
        if from_timestamp and event_ts and event_ts < from_timestamp:
            continue
        if to_timestamp and event_ts and event_ts > to_timestamp:
            continue

        if requested_query:
            haystack = " ".join(
                [
                    item.type,
                    item.description,
                    item.actor,
                    item.action,
                    item.resource_type or "",
                    item.resource_id or "",
                    item.skill or "",
                    item.artifact_hash or "",
                    item.evidence_id,
                ]
            ).lower()
            if requested_query not in haystack:
                continue

        evidence.append(item)

    return evidence


@router.get(
    "/tenant/{tenant_id}/activity-stream",
    response_model=ActivityStreamResponse,
    status_code=status.HTTP_200_OK,
    summary="Get tenant activity stream",
    description="Returns recent tenant activity entries for Mission Control activity stream.",
)
async def get_activity_stream(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=15, max_limit=100)),
) -> ActivityStreamResponse:
    normalized_tenant_id = _normalize_tenant_id(tenant_id)
    normalized_header_tenant = _normalize_tenant_id(x_tenant_id)

    if not normalized_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_id",
                "message": "tenant_id is required and must not be empty",
            },
        )

    if normalized_tenant_id != normalized_header_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_mismatch",
                "message": "X-Tenant-ID does not match requested tenant_id",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(normalized_tenant_id)
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": f"Tenant {normalized_tenant_id} not found",
            },
        )

    logger.info("Fetching activity stream for tenant=%s limit=%s", normalized_tenant_id, pagination.limit)
    audit_logger = get_audit_logger()
    query_limit = min(1000, (pagination.offset + pagination.limit) * 6)
    entries = audit_logger.query_by_tenant(
        tenant_id=normalized_tenant_id,
        limit=query_limit,
    )

    items: list[ActivityItem] = []
    for entry in entries:
        metadata = {}
        if isinstance(entry.action_metadata, dict):
            metadata = entry.action_metadata
        action = str(entry.action.value) if hasattr(entry.action, "value") else str(entry.action)
        actor = (entry.user_id or "system").strip() or "system"
        resource_type = str(entry.resource_type) if entry.resource_type else None
        resource_id = str(entry.resource_id) if entry.resource_id else None

        items.append(
            ActivityItem(
                timestamp=_safe_timestamp(entry.timestamp),
                actor=actor,
                action_type=_humanize_action(action),
                description=_action_description(
                    action,
                    metadata,
                    resource_type,
                    resource_id,
                ),
                activity_id=entry.event_id,
                resource_type=resource_type,
                resource_id=resource_id,
            )
        )

    paged_items = items[pagination.offset : pagination.offset + pagination.limit]
    return ActivityStreamResponse(
        tenant_id=normalized_tenant_id,
        activities=paged_items,
        count=len(paged_items),
        limit=pagination.limit,
    )


@router.get(
    "/tenant/{tenant_id}/evidence-timeline",
    response_model=EvidenceTimelineResponse,
    status_code=status.HTTP_200_OK,
    summary="Get tenant evidence timeline",
    description="Returns recent evidence entries for a tenant.",
)
async def get_evidence_timeline(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=20, max_limit=200)),
) -> EvidenceTimelineResponse:
    normalized_tenant_id = _normalize_tenant_id(tenant_id)
    normalized_header_tenant = _normalize_tenant_id(x_tenant_id)

    if not normalized_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_id",
                "message": "tenant_id is required and must not be empty",
            },
        )

    if normalized_tenant_id != normalized_header_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_mismatch",
                "message": "X-Tenant-ID does not match requested tenant_id",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(normalized_tenant_id)
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": f"Tenant {normalized_tenant_id} not found",
            },
        )

    logger.info(
        "Fetching evidence timeline for tenant=%s limit=%s",
        normalized_tenant_id,
        pagination.limit,
    )
    audit_logger = get_audit_logger()
    entries = audit_logger.query_by_tenant(
        tenant_id=normalized_tenant_id,
        limit=pagination.offset + pagination.limit,
    )

    evidence = []
    for entry in entries:
        metadata: dict[str, Any] = {}
        if isinstance(entry.action_metadata, dict):
            metadata = entry.action_metadata

        action = str(entry.action.value) if hasattr(entry.action, "value") else str(entry.action)
        evidence.append(
            EvidenceItem(
                evidence_id=str(entry.event_id),
                type=_humanize_action(action),
                description=_action_description(
                    action,
                    metadata,
                    str(entry.resource_type) if entry.resource_type else None,
                    str(entry.resource_id) if entry.resource_id else None,
                ),
                timestamp=_safe_timestamp(entry.timestamp),
                verification_status=_normalize_verification_status(
                    action=action,
                    metadata=metadata,
                    severity=str(entry.severity.value if hasattr(entry.severity, "value") else entry.severity),
                ),
            )
        )

    paged_evidence = evidence[pagination.offset : pagination.offset + pagination.limit]
    return EvidenceTimelineResponse(
        tenant_id=normalized_tenant_id,
        evidence=paged_evidence,
        count=len(paged_evidence),
        limit=pagination.limit,
    )


@router.get(
    "/tenant/{tenant_id}/evidence/search",
    response_model=EvidenceSearchResponse,
    status_code=status.HTTP_200_OK,
    summary="Search tenant evidence",
    description="Search and filter tenant evidence entries with structured constraints.",
)
async def search_evidence(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    q: str | None = Query(None, alias="q", max_length=280),
    actor: str | None = Query(None, max_length=120),
    skill: str | None = Query(None, max_length=120),
    resource_type: str | None = Query(None, max_length=120),
    status_filter: str | None = Query(None, alias="status", max_length=80),
    risk_level: str | None = Query(None, max_length=32),
    resource_id: str | None = Query(None, max_length=120),
    from_ts: str | None = Query(None, alias="from", max_length=80),
    to_ts: str | None = Query(None, alias="to", max_length=80),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=500)),
) -> EvidenceSearchResponse:
    normalized_tenant_id = _normalize_tenant_id(tenant_id)
    normalized_header_tenant = _normalize_tenant_id(x_tenant_id)

    if not normalized_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_id",
                "message": "tenant_id is required and must not be empty",
            },
        )

    if normalized_tenant_id != normalized_header_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_mismatch",
                "message": "X-Tenant-ID does not match requested tenant_id",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(normalized_tenant_id)
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": f"Tenant {normalized_tenant_id} not found",
            },
        )

    from_dt = parse_iso(from_ts)
    if from_dt is None and from_ts is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_from_timestamp",
                "message": "from must be an ISO timestamp",
            },
        )
    to_dt = parse_iso(to_ts)
    if to_dt is None and to_ts is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_to_timestamp",
                "message": "to must be an ISO timestamp",
            },
        )

    if from_dt and to_dt and from_dt > to_dt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_time_window",
                "message": "from timestamp must be earlier than to timestamp",
            },
        )

    logger.info(
        "Searching evidence for tenant=%s query=%s limit=%s",
        normalized_tenant_id,
        q,
        pagination.limit,
    )
    audit_logger = get_audit_logger()
    query_limit = min(1000, (pagination.offset + pagination.limit) * 6)
    entries = audit_logger.query_by_tenant(
        tenant_id=normalized_tenant_id,
        limit=query_limit,
    )

    evidence = [_to_evidence_search_item(entry) for entry in entries]
    evidence = _filter_evidence_items(
        evidence,
        query=q,
        actor=actor,
        skill=skill,
        resource_type=resource_type,
        status=status_filter,
        risk_level=risk_level,
        resource_id=resource_id,
        from_timestamp=from_dt,
        to_timestamp=to_dt,
    )

    paged_evidence = evidence[pagination.offset : pagination.offset + pagination.limit]
    return EvidenceSearchResponse(
        tenant_id=normalized_tenant_id,
        query=(q or "").strip() or None,
        evidence=paged_evidence,
        count=len(paged_evidence),
        limit=pagination.limit,
    )


@router.get(
    "/tenant/{tenant_id}/evidence/report",
    status_code=status.HTTP_200_OK,
    summary="Generate tenant evidence report",
    description="Generate a filtered evidence report in JSON or CSV.",
    response_model=None,
)
async def generate_evidence_report(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    q: str | None = Query(None, alias="q", max_length=280),
    actor: str | None = Query(None, max_length=120),
    skill: str | None = Query(None, max_length=120),
    resource_type: str | None = Query(None, max_length=120),
    status_filter: str | None = Query(None, alias="status", max_length=80),
    risk_level: str | None = Query(None, max_length=32),
    resource_id: str | None = Query(None, max_length=120),
    from_ts: str | None = Query(None, alias="from", max_length=80),
    to_ts: str | None = Query(None, alias="to", max_length=80),
    format: str = Query("json", max_length=16),
    limit: int = Query(200, ge=1, le=500),
) -> EvidenceReportResponse | Response:
    normalized_tenant_id = _normalize_tenant_id(tenant_id)
    normalized_header_tenant = _normalize_tenant_id(x_tenant_id)

    if not normalized_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_id",
                "message": "tenant_id is required and must not be empty",
            },
        )

    if normalized_tenant_id != normalized_header_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_mismatch",
                "message": "X-Tenant-ID does not match requested tenant_id",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(normalized_tenant_id)
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": f"Tenant {normalized_tenant_id} not found",
            },
        )

    report_format = (format or "json").strip().lower()
    if report_format not in {"json", "csv"}:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_report_format",
                "message": "format must be json or csv",
            },
        )

    from_dt = parse_iso(from_ts)
    if from_dt is None and from_ts is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_from_timestamp",
                "message": "from must be an ISO timestamp",
            },
        )
    to_dt = parse_iso(to_ts)
    if to_dt is None and to_ts is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_to_timestamp",
                "message": "to must be an ISO timestamp",
            },
        )

    if from_dt and to_dt and from_dt > to_dt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_time_window",
                "message": "from timestamp must be earlier than to timestamp",
            },
        )

    logger.info(
        "Generating evidence report for tenant=%s format=%s limit=%s",
        normalized_tenant_id,
        report_format,
        limit,
    )
    audit_logger = get_audit_logger()
    entries = audit_logger.query_by_tenant(
        tenant_id=normalized_tenant_id,
        limit=limit,
    )

    evidence = [_to_evidence_search_item(entry) for entry in entries]
    evidence = _filter_evidence_items(
        evidence,
        query=q,
        actor=actor,
        skill=skill,
        resource_type=resource_type,
        status=status_filter,
        risk_level=risk_level,
        resource_id=resource_id,
        from_timestamp=from_dt,
        to_timestamp=to_dt,
    )
    generated_at = datetime.now(UTC).isoformat()

    verification_summary = Counter(item.verification_status for item in evidence)
    risk_summary = Counter(item.risk_level for item in evidence)
    filters: dict[str, str | None] = {
        "query": (q or "").strip() or None,
        "actor": (actor or "").strip() or None,
        "skill": (skill or "").strip() or None,
        "resource_type": (resource_type or "").strip() or None,
        "status": (status_filter or "").strip() or None,
        "risk_level": (risk_level or "").strip() or None,
        "resource_id": (resource_id or "").strip() or None,
        "from": (from_ts or "").strip() or None,
        "to": (to_ts or "").strip() or None,
        "format": report_format,
    }
    report = EvidenceReportResponse(
        tenant_id=normalized_tenant_id,
        generated_at=generated_at,
        query=(q or "").strip() or None,
        filters=filters,
        count=len(evidence),
        verification_summary=dict(verification_summary),
        risk_summary=dict(risk_summary),
        evidence=evidence,
    )

    filename_base = f"evidence-report-{normalized_tenant_id.replace('#', '-')}"
    if report_format == "csv":
        output = StringIO()
        writer = csv.DictWriter(
            output,
            fieldnames=[
                "tenant_id",
                "timestamp",
                "evidence_id",
                "type",
                "action",
                "actor",
                "risk_level",
                "verification_status",
                "resource_type",
                "resource_id",
                "skill",
                "artifact_hash",
                "description",
            ],
        )
        writer.writeheader()
        for item in evidence:
            writer.writerow(
                {
                    "tenant_id": normalized_tenant_id,
                    "timestamp": item.timestamp,
                    "evidence_id": item.evidence_id,
                    "type": item.type,
                    "action": item.action,
                    "actor": item.actor,
                    "risk_level": item.risk_level,
                    "verification_status": item.verification_status,
                    "resource_type": item.resource_type or "",
                    "resource_id": item.resource_id or "",
                    "skill": item.skill or "",
                    "artifact_hash": item.artifact_hash or "",
                    "description": item.description,
                }
            )

        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename_base}.csv"},
        )

    payload = report.dict()
    return JSONResponse(
        content=payload,
        headers={"Content-Disposition": f"attachment; filename={filename_base}.json"},
    )
