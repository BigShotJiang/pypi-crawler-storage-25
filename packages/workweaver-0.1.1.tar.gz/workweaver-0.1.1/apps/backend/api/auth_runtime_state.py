"""Auth session and runtime-state endpoints extracted from auth_login.py."""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from apps.backend.api.auth_helpers import (
    BROWSER_SESSION_COOKIE_NAMES,
    RUNTIME_PROVISIONING_COOKIE_NAMES,
    _clear_browser_session_cookie,
    _clear_runtime_provisioning_cookie,
    _resume_runtime_provisioning_if_needed,
    _set_browser_session_cookie,
    _set_runtime_provisioning_cookie,
)
from apps.backend.api.auth_models import (
    AuthMeResponse,
    BehavioralStops,
    RuntimeProvisioningStatusResponse,
)
from apps.backend.api.platform_admin_identity import is_platform_admin_email
from apps.backend.observability.async_tasks import spawn_background_task
from apps.backend.providers.identity_provider import IdentityProviderError, get_identity_provider
from apps.backend.services.session.browser_session import (
    BrowserSessionTokenError,
    CLISessionTokenError,
    BrowserSessionClaims,
    verify_browser_session_token,
    verify_cli_session_token,
)
from apps.backend.dependency_factories.core import get_users_table
from apps.backend.services.onboarding_state import CapabilityChecker, OnboardingStatus
from apps.backend.services.runtime.provisioning_service import (
    get_workweaver_runtime_provisioning_service,
)
from apps.backend.services.runtime.provisioning_token import (
    RuntimeProvisioningTokenError,
    verify_workweaver_runtime_provisioning_token,
)
from apps.backend.services.tenant_provisioning import (
    get_tenant_provisioning_service,
)
from apps.backend.services.session.session_invalidation import (
    DynamoDbSessionInvalidationStore,
    token_is_invalidated,
)
from apps.backend.utils.tenant import derive_tenant_slug

logger = logging.getLogger(__name__)

router = APIRouter()


class OnboardingCapabilityCheckRequest(BaseModel):
    capability: str = Field(..., description="Capability key (oauth_google, oauth_microsoft, oauth_zoom, workmemory)")


class OnboardingCapabilityCheckResponse(BaseModel):
    capability: str
    status: str
    details: str | None = None


def _emit_onboarding_capability_event(
    *,
    capability: str,
    outcome: str,
    http_status: int,
    tenant_id: str | None = None,
    provider: str | None = None,
    detail: str | None = None,
) -> None:
    payload = {
        "tenant_id": tenant_id,
        "capability": capability,
        "provider": provider,
        "outcome": outcome,
        "http_status": int(http_status),
        "detail": detail,
    }
    logger.info("auth_onboarding_capability_event %s", payload)


def _extract_bearer_access_token(request: Request) -> str:
    auth_header = str(request.headers.get("authorization") or request.headers.get("Authorization") or "").strip()
    if not auth_header.lower().startswith("bearer "):
        return ""
    return auth_header.split(" ", 1)[1].strip()


def _canonical_tenant_record_id(*, tenant_id: str, user_id: str, email: str) -> str:
    """Resolve a tenant identifier to the persisted tenant record key."""
    normalized_tenant_id = str(tenant_id or "").strip()
    if normalized_tenant_id.startswith("TENANT#"):
        return normalized_tenant_id

    provisioning_service = get_tenant_provisioning_service()
    tenant = None
    normalized_user_id = str(user_id or "").strip()
    normalized_email = str(email or "").strip().lower()
    if normalized_user_id:
        tenant = provisioning_service.get_tenant_by_owner(normalized_user_id, product="workweaver")
        if not tenant:
            tenant = provisioning_service.get_tenant_by_owner(normalized_user_id, product=None)
    if not tenant and normalized_email:
        tenant = provisioning_service.get_tenant_by_email(normalized_email, product="workweaver")
        if not tenant:
            tenant = provisioning_service.get_tenant_by_email(normalized_email)
    if tenant:
        resolved = str(tenant.get("tenant_id") or normalized_tenant_id).strip()
        if resolved:
            return resolved
    return f"TENANT#{normalized_tenant_id}" if normalized_tenant_id else ""


def _session_invalidation_enforced() -> bool:
    raw = os.environ.get("WORKWEAVER_SESSION_INVALIDATION_ENFORCED", "1").strip()
    return raw not in {"0", "false", "False", ""}


def _read_session_invalidated_at(email: str) -> int:
    if not _session_invalidation_enforced():
        return 0
    table = get_users_table()
    return DynamoDbSessionInvalidationStore(table).get(email)


def _enforce_signed_session_not_invalidated(email: str, iat: int) -> None:
    normalized_email = str(email or "").strip().lower()
    if not normalized_email:
        return
    try:
        invalidated_at = _read_session_invalidated_at(normalized_email)
    except Exception as exc:
        logger.warning(
            "auth_runtime_session_invalidation_lookup_failed",
            extra={"error": type(exc).__name__},
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Cannot verify session. Please retry, or sign in again if the error persists.",
        ) from exc
    if token_is_invalidated(token_iat=int(iat or 0), sessions_invalidated_at=invalidated_at):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session invalidated. Please sign in again.",
        )


def _browser_session_claims_from_cookie(
    request: Request,
    *,
    enforce_invalidation: bool = True,
) -> BrowserSessionClaims | None:
    cookies = getattr(request, "cookies", {}) or {}
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
        token = str(cookies.get(cookie_name) or "").strip()
        if not token:
            continue
        try:
            claims = verify_browser_session_token(token)
            if enforce_invalidation:
                _enforce_signed_session_not_invalidated(claims.email, getattr(claims, "iat", 0))
            return claims
        except BrowserSessionTokenError as exc:
            logger.debug("Browser session cookie rejected during auth session resolution: %s", exc)
            continue
    return None


def _invalidate_browser_pair_sessions(claims: BrowserSessionClaims) -> int:
    normalized_email = str(claims.email or "").strip().lower()
    if not normalized_email or not _session_invalidation_enforced():
        return 0
    table = get_users_table()
    return DynamoDbSessionInvalidationStore(table).invalidate(normalized_email)


def _resolve_browser_session_from_access_token(access_token: str) -> tuple[str, str, str] | None:
    token = str(access_token or "").strip()
    if not token:
        return None

    try:
        claims = verify_cli_session_token(token)
        _enforce_signed_session_not_invalidated(claims.email, claims.iat)
        return claims.tenant_id, claims.user_id, claims.email
    except CLISessionTokenError:
        pass
    except HTTPException:
        pass

    try:
        claims = verify_browser_session_token(token)
        _enforce_signed_session_not_invalidated(claims.email, claims.iat)
        return claims.tenant_id, claims.user_id, claims.email
    except BrowserSessionTokenError:
        pass
    except HTTPException:
        pass

    try:
        envelope = get_identity_provider().resolve_from_access_token(token)
    except IdentityProviderError:
        logger.warning("Unable to recover browser session from bearer token", exc_info=True)
        return None

    tenant_id = str(envelope.tenant_id or "").strip()
    user_id = str(envelope.user_id or "").strip()
    email = str(envelope.email or "").strip().lower()
    if not tenant_id or not user_id or not email:
        return None
    return _canonical_tenant_record_id(tenant_id=tenant_id, user_id=user_id, email=email), user_id, email


def _resolve_authenticated_request_session(request: Request) -> tuple[str, str, str]:
    cookies = getattr(request, "cookies", {}) or {}
    if cookies:
        claims = _browser_session_claims_from_cookie(request)
        if claims:
            return claims.tenant_id, claims.user_id, claims.email

    bearer_access_token = _extract_bearer_access_token(request)
    bearer_session = _resolve_browser_session_from_access_token(bearer_access_token)
    if bearer_session:
        return bearer_session

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "error": "authentication_required",
            "message": "Authentication is required for this endpoint.",
        },
    )


def _resolve_authenticated_request_identity(request: Request) -> tuple[str, str]:
    """Resolve authenticated tenant/user identity from browser cookie or bearer token."""
    tenant_id, user_id, _email = _resolve_authenticated_request_session(request)
    return tenant_id, user_id


def _sanitize_public_runtime_state(runtime_state: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(runtime_state, dict):
        return {}
    public_state = dict(runtime_state)
    public_state.pop("launch_url", None)
    public_state.pop("gateway_token", None)
    return public_state


def _has_broken_fragment_contract(endpoint: str, launch_url: str) -> bool:
    """Return True when the endpoint/launch_url carries an invalid URL fragment.

    A fragment in the endpoint means the stored value is malformed.
    A launch_url fragment equal to 'launch' (or ending in '/launch') is stale
    hot metadata from a previous provisioning run that was never cleaned up.
    Auth self-healing: detect and re-provision rather than serving a broken URL.
    """
    from urllib.parse import urlparse

    ep_parsed = urlparse((endpoint or "").strip())
    lu_parsed = urlparse((launch_url or "").strip())
    lu_frag = str(lu_parsed.fragment or "").strip().lower()
    return bool(ep_parsed.fragment) or lu_frag == "launch" or lu_frag.endswith("/launch")


def _normalized_runtime_state_for_tenant(tenant: dict[str, Any]) -> dict[str, Any]:
    """Return a normalized view of the tenant's runtime state.

    Applies two self-healing rules without writing to DynamoDB:
    1. Cold tenant (stopped/auto_sleep) with stale hot runtime status → normalize to stopped.
    2. Hot runtime with a broken fragment contract → normalize to stopped so auth
       triggers re-provisioning rather than serving the malformed URL.

    The authoritative batch cleanup is ops/scripts/audit_runtime_tenants.py --reconcile.
    This function provides on-demand recovery for the single-tenant auth path.
    """
    runtime_state = dict(tenant.get("runtime") or {}) if isinstance(tenant.get("runtime"), dict) else {}
    runtime_status = str(runtime_state.get("status") or "").strip().lower()
    tenant_status = str(tenant.get("status") or "").strip().lower()

    # Rule 1: tenant is cold but runtime shows hot — normalize.
    if tenant_status in {"stopped", "auto_sleep"} and runtime_status in {"ready", "degraded"}:
        runtime_state["status"] = "stopped"
        runtime_state["step"] = "stopped"
        return runtime_state

    # Rule 2: runtime shows hot but endpoint/launch_url has a broken fragment contract.
    if runtime_status in {"ready", "degraded"}:
        endpoint = str(runtime_state.get("endpoint") or "").strip()
        launch_url = str(runtime_state.get("launch_url") or "").strip()
        if _has_broken_fragment_contract(endpoint, launch_url):
            logger.warning(
                "auth_self_heal_fragment_contract tenant=%s endpoint=%s launch_url=%s",
                str(tenant.get("pk") or tenant.get("tenant_id") or ""),
                endpoint,
                launch_url,
            )
            runtime_state["status"] = "stopped"
            runtime_state["step"] = "audit_fragment_contract"

    return runtime_state


def _runtime_provisioning_token_from_request(
    request: Request,
    header_token: str | None,
) -> str:
    token = str(header_token or "").strip()
    if token:
        return token
    for cookie_name in RUNTIME_PROVISIONING_COOKIE_NAMES:
        token = str(request.cookies.get(cookie_name) or "").strip()
        if token:
            return token
    return ""


@router.get(
    "/me",
    response_model=AuthMeResponse,
    status_code=status.HTTP_200_OK,
    summary="Get current auth state",
    description="Cookie-based auth state used by landing/header route gating.",
)
async def auth_me(
    request: Request,
    response: Response,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> AuthMeResponse:
    session_claims = None
    browser_session_token = ""
    bearer_session = None
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
        browser_session_token = (request.cookies.get(cookie_name) or "").strip()
        if browser_session_token:
            break
    if browser_session_token:
        try:
            session_claims = _browser_session_claims_from_cookie(request)
            if session_claims:
                _set_browser_session_cookie(
                    response,
                    tenant_id=session_claims.tenant_id,
                    user_id=session_claims.user_id,
                    email=session_claims.email,
                )
        except BrowserSessionTokenError:
            _clear_browser_session_cookie(response)
            session_claims = None
        except HTTPException:
            _clear_browser_session_cookie(response)
            session_claims = None

    if not session_claims:
        bearer_session = _resolve_browser_session_from_access_token(_extract_bearer_access_token(request))
        if bearer_session:
            tenant_id, user_id, email = bearer_session
            _set_browser_session_cookie(
                response,
                tenant_id=tenant_id,
                user_id=user_id,
                email=email,
            )

    token = _runtime_provisioning_token_from_request(request, x_workweaver_runtime_provisioning_token)

    if not session_claims and not bearer_session and not token:
        return AuthMeResponse(authenticated=False, next_action="signup")

    tenant_id = ""
    resolved_user_id: str | None = None
    resolved_email: str | None = None
    if session_claims:
        tenant_id = session_claims.tenant_id
        resolved_user_id = session_claims.user_id
        resolved_email = session_claims.email
    elif bearer_session:
        tenant_id, resolved_user_id, resolved_email = bearer_session
    else:
        try:
            claims = verify_workweaver_runtime_provisioning_token(token)
        except RuntimeProvisioningTokenError:
            _clear_runtime_provisioning_cookie(response)
            return AuthMeResponse(authenticated=False, next_action="signup")
        tenant_id = claims.tenant_id

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(tenant_id)
    if not tenant:
        _clear_browser_session_cookie(response)
        _clear_runtime_provisioning_cookie(response)
        return AuthMeResponse(authenticated=False, next_action="signup")

    runtime_state = _normalized_runtime_state_for_tenant(tenant)
    runtime_status = str((runtime_state.get("status") if isinstance(runtime_state, dict) else "") or "").strip().lower()
    if not runtime_status:
        runtime_status = "none"
    tenant_status_raw = str(tenant.get("status") or "").strip().lower()
    cold_runtime = runtime_status in {"stopped", "stopping"}

    onboarding_status: str | None = None
    onboarding_current_step: str | None = None
    onboarding_required = False
    onboarding_completed = False

    try:
        from apps.backend.api.onboarding import get_onboarding_state_service

        onboarding_service = get_onboarding_state_service()
        onboarding_state = await onboarding_service.get_state(tenant_id)
        onboarding_status = str(getattr(onboarding_state.status, "value", onboarding_state.status))
        onboarding_current_step = str(getattr(onboarding_state.current_step, "value", onboarding_state.current_step))
        onboarding_completed = onboarding_status == OnboardingStatus.COMPLETE.value
        onboarding_required = onboarding_status in {
            OnboardingStatus.NOT_STARTED.value,
            OnboardingStatus.IN_PROGRESS.value,
        }
    except Exception as exc:
        logger.warning(
            "Unable to load onboarding state for tenant %s in /api/v1/auth/me: %s",
            tenant_id,
            exc,
        )

    if cold_runtime:
        tenant_state = "provisioning"
        next_action = "provisioning"
    elif runtime_status == "ready":
        tenant_state = "ready"
        next_action = "ready"
    elif runtime_status in {"degraded"}:
        tenant_state = "degraded"
        next_action = "ready"
    elif runtime_status in {"failed", "error"}:
        tenant_state = "error"
        next_action = "provisioning"
    else:
        tenant_state = "provisioning"
        next_action = "provisioning"

    if next_action == "provisioning":
        # Pass the normalized runtime state so self-heal decisions (e.g. fragment
        # contract breakage) actually arm reprovisioning. Using the raw `tenant`
        # dict would leak stale `status=ready` back into the resume helper and
        # short-circuit recovery. Build a shallow copy — never mutate `tenant`.
        if isinstance(runtime_state, dict) and runtime_state:
            tenant_for_provisioning: dict[str, Any] = {**tenant, "runtime": runtime_state}
        else:
            tenant_for_provisioning = tenant
        _resume_runtime_provisioning_if_needed(
            tenant_for_provisioning,
            task_name="runtime_resume_from_auth_me",
        )

    try:
        from apps.backend.services.behavioral_stops_store import (
            _get_stops as _get_canonical_behavioral_stops,
        )

        behavioral_stops = BehavioralStops(**_get_canonical_behavioral_stops(tenant_id))
    except Exception:
        behavioral_stops = BehavioralStops()

    execution_posture = "no_execute"
    preflight_status = "green"

    if tenant_state == "ready":
        if not behavioral_stops.paused:
            execution_posture = "execute"
            preflight_status = "green"
        else:
            preflight_status = "red"
    elif tenant_state == "degraded":
        preflight_status = "yellow"
    else:
        preflight_status = "red"

    trial_expires_at: str | None = None
    if tenant_status_raw == "trial":
        created_at_raw = str(tenant.get("created_at") or "").strip()
        if created_at_raw:
            try:
                created_dt = datetime.fromisoformat(created_at_raw.replace("Z", "+00:00"))
                trial_ttl_hours = int(os.getenv("TRIAL_TTL_HOURS", "72"))
                trial_expires_at = (created_dt + timedelta(hours=trial_ttl_hours)).isoformat()
            except (ValueError, TypeError) as exc:
                logger.debug("Failed to derive trial expiry from tenant created_at %r: %s", created_at_raw, exc)

    user_email_lower = (resolved_email or (tenant.get("email") or "")).strip().lower() or None
    is_admin = is_platform_admin_email(user_email_lower)

    user_name = str(tenant.get("owner_name") or "").strip() or str(tenant.get("name") or "").strip() or None
    if not user_name and user_email_lower and "@" in user_email_lower:
        local_part = user_email_lower.split("@", 1)[0]
        user_name = local_part.replace(".", " ").replace("_", " ").title() or None

    # #2757: forward the tenant URL slug so the runtime can validate the
    # path-prefix (``workweaver.ai/<tenant_slug>/``) against the
    # authenticated tenant. Prefer the persisted slug on the tenant record
    # (admin override, future custom slugs); fall back to deterministic
    # derivation from tenant_id so existing rows still resolve before the
    # backfill migration lands. ``derive_tenant_slug`` never returns an
    # empty string for a non-empty tenant_id, so the response field is
    # always a valid DNS label.
    persisted_slug = str(tenant.get("tenant_slug") or "").strip().lower() or None
    try:
        tenant_slug = persisted_slug or derive_tenant_slug(tenant_id)
    except ValueError:
        tenant_slug = None

    return AuthMeResponse(
        authenticated=True,
        tenant_id=tenant_id,
        tenant_slug=tenant_slug,
        user_id=resolved_user_id,
        email=user_email_lower,
        user_name=user_name,
        is_admin=is_admin,
        tenant_state=tenant_state,
        next_action=next_action,
        runtime_status=runtime_status,
        onboarding_status=onboarding_status,
        onboarding_current_step=onboarding_current_step,
        onboarding_required=onboarding_required,
        onboarding_completed=onboarding_completed,
        tenant_status=tenant_status_raw or None,
        trial_expires_at=trial_expires_at,
        preflight_status=preflight_status,
        execution_posture=execution_posture,
        behavioral_stops=behavioral_stops,
    )


@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Clear browser auth session",
)
async def logout(request: Request) -> Response:
    session_claims = _browser_session_claims_from_cookie(request, enforce_invalidation=False)
    if session_claims:
        try:
            _invalidate_browser_pair_sessions(session_claims)
        except Exception as exc:
            logger.warning(
                "auth_logout_session_invalidation_failed",
                extra={"error": type(exc).__name__},
            )
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Could not revoke linked sessions. Please retry logout in a moment.",
            ) from exc
    response = Response(status_code=status.HTTP_204_NO_CONTENT)
    _clear_browser_session_cookie(response)
    _clear_runtime_provisioning_cookie(response)
    for cookie_name in request.cookies:
        if cookie_name.startswith("CognitoIdentityServiceProvider"):
            for domain in [".workweaver.ai", None]:
                kwargs: dict[str, Any] = {"key": cookie_name, "path": "/"}
                if domain:
                    kwargs["domain"] = domain
                response.delete_cookie(**kwargs)
    return response


@router.post(
    "/onboarding/capabilities/check",
    response_model=OnboardingCapabilityCheckResponse,
    status_code=status.HTTP_200_OK,
    summary="Check onboarding capability status for authenticated tenant",
)
async def check_onboarding_capability(
    request: Request,
    response: Response,
    body: OnboardingCapabilityCheckRequest,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> OnboardingCapabilityCheckResponse:
    capability_key = (body.capability or "").strip().lower()
    token = _runtime_provisioning_token_from_request(request, x_workweaver_runtime_provisioning_token)

    if not token:
        _emit_onboarding_capability_event(
            capability=capability_key,
            outcome="missing_token",
            http_status=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "unauthorized", "message": "Authentication required"},
        )

    try:
        claims = verify_workweaver_runtime_provisioning_token(token)
    except RuntimeProvisioningTokenError:
        _emit_onboarding_capability_event(
            capability=capability_key,
            outcome="invalid_token",
            http_status=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired authentication token",
        )
        _clear_runtime_provisioning_cookie(response)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "unauthorized", "message": "Invalid or expired authentication token"},
        )

    tenant_id = claims.tenant_id

    from apps.backend.api.onboarding import get_onboarding_state_service

    onboarding_service = get_onboarding_state_service()
    checker = CapabilityChecker(onboarding_service.db)

    if capability_key.startswith("oauth_"):
        provider = capability_key.replace("oauth_", "", 1).strip()
        if not provider:
            _emit_onboarding_capability_event(
                capability=capability_key,
                outcome="invalid_capability",
                http_status=status.HTTP_400_BAD_REQUEST,
                tenant_id=tenant_id,
                detail="OAuth provider key is required",
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={"error": "invalid_capability", "message": "OAuth provider key is required"},
            )
        result = await checker.check_oauth_connected(tenant_id, provider)
    elif capability_key == "workmemory":
        provider = None
        result = await checker.check_memory_connected(tenant_id)
    else:
        _emit_onboarding_capability_event(
            capability=capability_key,
            outcome="invalid_capability",
            http_status=status.HTTP_400_BAD_REQUEST,
            tenant_id=tenant_id,
            detail=f"Unsupported capability '{capability_key}'",
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_capability",
                "message": f"Unsupported capability '{capability_key}'",
            },
        )

    status_value = str(getattr(result.status, "value", result.status))
    _emit_onboarding_capability_event(
        capability=capability_key,
        provider=provider,
        outcome="ok",
        http_status=status.HTTP_200_OK,
        tenant_id=tenant_id,
        detail=status_value,
    )
    return OnboardingCapabilityCheckResponse(
        capability=result.capability,
        status=status_value,
        details=result.details,
    )


@router.get(
    "/runtime/provisioning/status",
    response_model=RuntimeProvisioningStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get Workweaver Runtime provisioning status",
    description="Canonical runtime provisioning status endpoint.",
)
async def runtime_provisioning_status(
    request: Request,
    response: Response,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> RuntimeProvisioningStatusResponse:
    def _error(status_code: int, *, error: str, message: str) -> JSONResponse:
        rr = JSONResponse(
            status_code=status_code,
            content={"detail": {"error": error, "message": message}},
        )
        _clear_runtime_provisioning_cookie(rr)
        return rr

    token = _runtime_provisioning_token_from_request(request, x_workweaver_runtime_provisioning_token)
    if not token:
        return _error(
            status.HTTP_401_UNAUTHORIZED,
            error="missing_provisioning_token",
            message="Missing provisioning token",
        )

    try:
        claims = verify_workweaver_runtime_provisioning_token(token)
    except RuntimeProvisioningTokenError as exc:
        return _error(
            status.HTTP_401_UNAUTHORIZED,
            error="invalid_provisioning_token",
            message=str(exc),
        )

    tenant_id = claims.tenant_id
    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(tenant_id)
    if not tenant:
        return _error(
            status.HTTP_404_NOT_FOUND,
            error="tenant_not_found",
            message="Tenant not found",
        )

    runtime_state = _normalized_runtime_state_for_tenant(tenant)
    if not str(runtime_state.get("status") or "").strip():
        runtime_state["status"] = "provisioning"
    if not str(runtime_state.get("step") or "").strip():
        default_step_status = str(runtime_state.get("status") or "").strip().lower()
        if default_step_status == "ready":
            runtime_state["step"] = "ready"
        elif default_step_status in {"stopped", "stopping"}:
            runtime_state["step"] = "stopped"
        elif default_step_status in {"failed", "error"}:
            runtime_state["step"] = "failed"
        elif default_step_status == "disabled":
            runtime_state["step"] = "disabled"
        else:
            runtime_state["step"] = "queued"
    if not str(runtime_state.get("checked_at") or "").strip():
        runtime_state["checked_at"] = datetime.now(UTC).isoformat()

    status_val = runtime_state.get("status") if isinstance(runtime_state, dict) else None
    if str(status_val or "").strip().lower() == "ready":
        _clear_runtime_provisioning_cookie(response)
    else:
        try:
            _set_runtime_provisioning_cookie(response, tenant_id=tenant_id)
        except Exception:
            logger.warning("Failed to refresh provisioning cookie", extra={"tenant_id": tenant_id}, exc_info=True)

    status_lower = str(status_val or "").strip().lower()
    bootstrap_step = str(runtime_state.get("step") or "").strip().lower() if isinstance(runtime_state, dict) else ""
    if not bootstrap_step:
        if status_lower == "ready":
            bootstrap_step = "ready"
        elif status_lower in {"failed", "error"}:
            bootstrap_step = "failed"
        elif status_lower == "disabled":
            bootstrap_step = "disabled"
        else:
            bootstrap_step = "queued"
    execute_blockers: list[str] = []
    if status_lower != "ready":
        execute_blockers.append("runtime_not_ready")
    if status_lower in {"failed", "error"}:
        execute_blockers.append("provisioning_failed")

    next_check = 3 if status_lower in {"provisioning", "queued", "stopped", "stopping", ""} else 10
    next_action = str(runtime_state.get("next_action") or "").strip() if isinstance(runtime_state, dict) else ""
    if not next_action:
        if status_lower == "ready":
            next_action = "ready"
        elif status_lower in {"failed", "error"}:
            next_action = "retry"
        elif status_lower == "disabled":
            next_action = "disabled"
        else:
            next_action = "poll"

    public_runtime_state = _sanitize_public_runtime_state(runtime_state)
    return RuntimeProvisioningStatusResponse(
        runtime=public_runtime_state,
        runtime_status=status_val,
        runtime_endpoint=public_runtime_state.get("endpoint"),
        runtime_launch_url=None,
        runtime_step=bootstrap_step,
        bootstrap_step=bootstrap_step,
        next_action=next_action,
        next_check_seconds=next_check,
        execute_blockers=execute_blockers,
    )


@router.post(
    "/runtime/provisioning/retry",
    response_model=RuntimeProvisioningStatusResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Retry Workweaver Runtime provisioning",
    description="Explicitly restart runtime provisioning after a terminal failure.",
)
async def retry_runtime_provisioning(
    request: Request,
    response: Response,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> RuntimeProvisioningStatusResponse:
    def _error(status_code: int, *, error: str, message: str) -> JSONResponse:
        rr = JSONResponse(
            status_code=status_code,
            content={"detail": {"error": error, "message": message}},
        )
        _clear_runtime_provisioning_cookie(rr)
        return rr

    token = _runtime_provisioning_token_from_request(request, x_workweaver_runtime_provisioning_token)
    if not token:
        return _error(
            status.HTTP_401_UNAUTHORIZED,
            error="missing_provisioning_token",
            message="Missing provisioning token",
        )

    try:
        claims = verify_workweaver_runtime_provisioning_token(token)
    except RuntimeProvisioningTokenError as exc:
        return _error(
            status.HTTP_401_UNAUTHORIZED,
            error="invalid_provisioning_token",
            message=str(exc),
        )

    tenant_id = claims.tenant_id
    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(tenant_id)
    if not tenant:
        return _error(
            status.HTTP_404_NOT_FOUND,
            error="tenant_not_found",
            message="Tenant not found",
        )

    runtime_state = _normalized_runtime_state_for_tenant(tenant)
    current_status = str((runtime_state.get("status") if isinstance(runtime_state, dict) else "") or "").strip().lower()
    if current_status in {"ready", "provisioning", "queued"}:
        return await runtime_provisioning_status(
            request=request,
            response=response,
            x_workweaver_runtime_provisioning_token=(token or None),
        )

    runtime_provisioning_service = get_workweaver_runtime_provisioning_service()
    if not getattr(runtime_provisioning_service, "enabled", False):
        return _error(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            error="runtime_provisioning_disabled",
            message="Runtime provisioning is disabled",
        )

    owner_user_id = (tenant.get("owner_user_id") or "").strip()
    owner_email = (tenant.get("email") or "").strip().lower()
    preferred_region = tenant.get("preferred_region_code")
    if not owner_user_id or not owner_email:
        return _error(
            status.HTTP_409_CONFLICT,
            error="tenant_owner_missing",
            message="Tenant owner details are missing; provisioning cannot be retried",
        )

    try:
        await asyncio.to_thread(
            runtime_provisioning_service.mark_status,
            tenant_id=tenant_id,
            status="provisioning",
            step="queued",
            last_error=None,
        )
    except Exception as exc:
        logger.warning("Unable to mark runtime retry queued for %s: %s", tenant_id, exc)

    if bool(os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "").strip()):
        import concurrent.futures

        inline_timeout = max(int(os.environ.get("WORKWEAVER_RUNTIME_LAMBDA_INLINE_TIMEOUT_SECONDS", "25")), 5)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                fut = pool.submit(
                    runtime_provisioning_service.reconcile_provisioning,
                    tenant_id=tenant_id,
                    owner_email=owner_email,
                    owner_user_id=owner_user_id,
                    region=preferred_region,
                )
                fut.result(timeout=inline_timeout)
        except concurrent.futures.TimeoutError:
            logger.info(
                "runtime_retry_lambda_inline_timeout tenant_id=%s timeout=%ds",
                tenant_id,
                inline_timeout,
            )
        except Exception:
            logger.exception("runtime_retry_lambda_inline_error tenant_id=%s", tenant_id)
    else:
        spawn_background_task(
            asyncio.to_thread(
                runtime_provisioning_service.reconcile_provisioning,
                tenant_id=tenant_id,
                owner_email=owner_email,
                owner_user_id=owner_user_id,
                region=preferred_region,
            ),
            task_name="runtime_retry_from_runtime_status",
            tenant_id=tenant_id,
        )

    return await runtime_provisioning_status(
        request=request,
        response=response,
        x_workweaver_runtime_provisioning_token=(token or None),
    )
