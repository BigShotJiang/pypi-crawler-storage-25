"""Tenant authentication dependency for FastAPI routes.

Validates that the X-Tenant-Id header matches the authenticated user's tenant.
In production, tenant identity is derived from verified identity-provider
context, not from request headers.
In dev mode (DISABLE_COGNITO), the header remains the local-test fallback.
"""

import logging
import os
from typing import Any
from collections.abc import Mapping

from fastapi import Depends, Header, HTTPException, Request, WebSocket, status

from apps.backend.dependency_factories.core import get_tenants_table, get_users_table
from apps.backend.models.user import UserRole

from apps.backend.api.auth_helpers import (
    BROWSER_SESSION_COOKIE_NAMES,
)
from apps.backend.api.platform_admin_identity import is_platform_admin_email
from apps.backend.services.session.browser_session import (
    BrowserSessionTokenError,
    CLISessionTokenError,
    verify_cli_session_token,
    verify_browser_session_token,
)
from apps.backend.services.session.session_invalidation import (
    DynamoDbSessionInvalidationStore,
    token_is_invalidated,
)
from apps.backend.services.tenant_provisioning import get_tenant_provisioning_service
from apps.backend.utils.tenant import strip_tenant_prefix, tenant_pk
from apps.backend.providers.identity_provider import IdentityProviderError, get_identity_provider

# Per-process cache for session-invalidation timestamps.
# Keyed by lowercase email; value is ``(fetched_at_unix, ts)``.
# Tight TTL so a reset propagates quickly; see GAP-003 (issue #1147).
_SESSION_INVALIDATION_CACHE: dict[str, tuple[float, int]] = {}
_SESSION_INVALIDATION_CACHE_TTL_SECONDS = 5.0

# Per-process cache for tenant-suspend enforcement.
# Keyed by tenant_id; value is ``(fetched_at_unix, status, suspended_by)``.
# Tight TTL so a suspend propagates quickly (issue #1146 round-3 BLOCK fix).
# 5-second worst-case staleness is the same bound we accept for
# session invalidation; after that window a suspended tenant is
# deterministically locked out.
_TENANT_SUSPEND_CACHE: dict[str, tuple[float, str, str]] = {}
_TENANT_SUSPEND_CACHE_TTL_SECONDS = 5.0


logger = logging.getLogger(__name__)


def _read_tenant_metadata_consistent(tenant_id: str) -> tuple[str, str]:
    """Read the tenant METADATA row with ``ConsistentRead=True``.

    Returns ``(status, suspended_by)`` — empty strings when the
    read fails or the row does not exist. Callers that require the
    check to be fail-CLOSED must handle the empty-string case
    themselves; this helper fails open (empty-string = "cannot
    verify") so a DDB blip does not lock all tenants out.

    The caller (``_enforce_tenant_not_suspended``) converts the
    read failure into a 503 for the requesting client so they know
    the auth check couldn't complete.
    """
    requested_tenant = str(tenant_id or "").strip()
    if not requested_tenant:
        return "", ""
    try:
        metadata_pk = tenant_pk(requested_tenant)
    except ValueError:
        return "", ""
    try:
        table = get_tenants_table()
        resp = table.get_item(
            Key={"pk": metadata_pk, "sk": "METADATA"},
            ConsistentRead=True,
        )
        item = resp.get("Item") or {}
        return (
            str(item.get("status") or "").strip().lower(),
            str(item.get("suspended_by") or "").strip(),
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "tenant_metadata_read_failed tenant=%s error=%s",
            metadata_pk,
            type(exc).__name__,
        )
        return "", ""


def _tenant_suspend_enforced() -> bool:
    """Evaluated per-call so tests can set
    ``WORKWEAVER_TENANT_SUSPEND_ENFORCED=0`` with
    ``@patch.dict(os.environ, ...)``. Default is on."""
    raw = os.environ.get("WORKWEAVER_TENANT_SUSPEND_ENFORCED", "1").strip()
    return raw not in {"0", "false", "False", ""}


def _enforce_tenant_not_suspended(tenant_id: str) -> None:
    """Reject any authenticated request targeting a suspended tenant.

    Codex round-3 BLOCK fix: the CLI/browser session path already
    gates on ``sessions_invalidated_at`` (which the suspend cascade
    bumps), but the managed bearer-token path previously accepted
    already-issued access tokens without consulting tenant status.
    This helper closes that gap by reading the authoritative
    METADATA row for the tenant on every auth-path traversal (with
    a 5s per-process cache to amortize cost).

    A read failure returns 503 so clients retry on the next request
    — fail-CLOSED is the correct posture. A DDB blip cannot
    silently re-authorize a suspended tenant.

    Scopes are intentionally narrow:
    * Only rejects ``status == "suspended"``.
    * Other terminal states (``cancelled``, ``deleted``) are also
      denied because a destroyed tenant has no valid session.
    * Past-due / trialing / active all pass.
    """
    if not _tenant_suspend_enforced():
        return
    normalized = str(tenant_id or "").strip()
    if not normalized:
        return

    import time as _time

    now_ts = _time.time()
    cached = _TENANT_SUSPEND_CACHE.get(normalized)
    if cached is not None and (now_ts - cached[0]) < _TENANT_SUSPEND_CACHE_TTL_SECONDS:
        status_raw, suspended_by = cached[1], cached[2]
    else:
        status_raw, suspended_by = _read_tenant_metadata_consistent(normalized)
        if not status_raw:
            # Read failure (DDB blip or missing row). Fail CLOSED so
            # a transient outage cannot silently re-authorize a
            # suspended tenant.
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=("Cannot verify organization status. Please retry in a moment."),
            )
        _TENANT_SUSPEND_CACHE[normalized] = (now_ts, status_raw, suspended_by)

    if status_raw in {"suspended", "cancelled", "deleted"}:
        logger.warning(
            "auth_blocked_tenant_status tenant=%s status=%s",
            normalized,
            status_raw,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_suspended",
                "status": status_raw,
                # Never leak the founder email to the blocked user.
                "message": ("This organization is currently unavailable. Please contact Workweaver support."),
            },
        )


def _session_invalidation_enforced() -> bool:
    """Evaluated per-call so tests can set ``WORKWEAVER_SESSION_INVALIDATION_ENFORCED=0``
    with ``@patch.dict(os.environ, ...)``. Default is on."""
    raw = os.environ.get("WORKWEAVER_SESSION_INVALIDATION_ENFORCED", "1").strip()
    return raw not in {"0", "false", "False", ""}


def _enforce_session_not_invalidated(email: str, iat: int) -> None:
    """Reject session tokens minted before a password reset.

    Reads the user's ``SESSION_INVALIDATION`` marker from DynamoDB
    (with a short per-process TTL cache) and raises 401 if the token's
    ``iat`` predates it.

    **Fail-closed** on DDB read errors for already-issued session tokens:
    an attacker who can cause a DDB read failure must not gain continued
    access to a pre-reset session. If DDB is unreachable the verify path
    returns 503 and the user must re-authenticate. Login and
    password-reset flows do not route through this helper so they remain
    available during a partial outage (Codex round-2 flag).

    Dev / test environments without DDB may disable enforcement entirely
    via ``WORKWEAVER_SESSION_INVALIDATION_ENFORCED=0``.
    """
    if not _session_invalidation_enforced():
        return

    import time as _time

    normalized_email = (email or "").strip().lower()
    if not normalized_email:
        # Legacy path without email; cannot enforce. Skip the check — the
        # outer auth path will fail on missing email elsewhere.
        return

    now_ts = _time.time()
    cached = _SESSION_INVALIDATION_CACHE.get(normalized_email)
    if cached is not None and (now_ts - cached[0]) < _SESSION_INVALIDATION_CACHE_TTL_SECONDS:
        invalidated_at = cached[1]
    else:
        try:
            table = get_users_table()
            invalidated_at = DynamoDbSessionInvalidationStore(table).get(normalized_email)
        except Exception as exc:  # noqa: BLE001 — DDB read failure
            logger.warning(
                "session_invalidation_lookup_failed",
                extra={"error": type(exc).__name__},
            )
            # Fail closed. Codex round-2 security correction: DDB blip
            # must not silently re-authorize a pre-reset session.
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=("Cannot verify session. Please retry, or sign in again if the error persists."),
            ) from exc
        _SESSION_INVALIDATION_CACHE[normalized_email] = (now_ts, invalidated_at)

    if token_is_invalidated(token_iat=iat, sessions_invalidated_at=invalidated_at):
        logger.info(
            "rejected_session_token_after_password_reset",
            extra={"iat": iat, "invalidated_at": invalidated_at},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session invalidated by password reset. Please sign in again.",
        )


def _build_auth_envelope(
    *,
    tenant_id: str,
    user_id: str,
    provider: str = "",
    session_type: str = "",
    email: str = "",
    impersonator_id: str = "",
) -> object:
    """Build an AuthEnvelope from resolved identity context.

    Returns the envelope, or None if the import fails (graceful degradation
    during the transition period).
    """
    try:
        from apps.backend.models.auth_envelope import AuthEnvelope, SessionType, normalize_session_type

        session_map = {
            "browser": SessionType.browser,
            "cli": SessionType.cli,
            "api_gateway": SessionType.api_gateway,
            "bearer": SessionType.bearer,
            "bearer_cognito": SessionType.bearer,
            "bearer_oidc": SessionType.bearer_oidc,
            "plugin_api_key": SessionType.plugin_api_key,
            "local_dev": SessionType.local_dev,
        }
        st = session_map.get(session_type, normalize_session_type(session_type or SessionType.local_dev))

        return AuthEnvelope(
            tenant_id=tenant_id,
            user_id=user_id,
            provider=provider,
            session_type=st,
            email=email,
            impersonator_id=impersonator_id,
        )
    except Exception:
        logger.debug("auth_envelope.build_failed", exc_info=True)
        return None


def _resolve_auth_source_provider_session(request: Request) -> tuple[str, str]:
    explicit_provider = str(getattr(request.state, "_auth_provider", "") or "").strip()
    explicit_session_type = str(getattr(request.state, "_auth_session_type", "") or "").strip()
    if explicit_provider or explicit_session_type:
        return explicit_provider or "unknown", explicit_session_type or "local_dev"

    source = str(getattr(request.state, "_auth_source", "bearer") or "bearer")
    source_map = {
        "browser": ("browser_session", "browser"),
        "api_gateway": ("managed_identity", "api_gateway"),
        "bearer": ("managed_identity", "bearer"),
        "state": ("managed_identity", "bearer"),
    }
    return source_map.get(source, ("managed_identity", "bearer"))


def resolve_authenticated_impersonator_id(request: Request) -> str | None:
    impersonator_id = str(
        getattr(request.state, "authenticated_impersonator_id", "")
        or getattr(request.state, "impersonator_id", "")
        or "",
    ).strip()
    return impersonator_id or None


def _extract_authorizer_claims_from_scope(scope: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return API Gateway / Lambda authorizer claims when present."""
    aws_event = scope.get("aws.event") if isinstance(scope, dict) else None
    if not isinstance(aws_event, dict):
        return {}

    request_context = aws_event.get("requestContext")
    if not isinstance(request_context, dict):
        return {}

    authorizer = request_context.get("authorizer")
    if not isinstance(authorizer, dict):
        return {}

    claims = authorizer.get("claims")
    return claims if isinstance(claims, dict) else {}


def _extract_authorizer_claims(request: Request) -> dict[str, Any]:
    return _extract_authorizer_claims_from_scope(request.scope if isinstance(request.scope, dict) else None)


def _extract_user_id(request: Request, *, allow_untrusted_headers: bool) -> str:
    """Best-effort extraction of authenticated user identifier."""
    state_user = str(getattr(request.state, "user_id", "") or "").strip()
    if state_user:
        return state_user

    if allow_untrusted_headers:
        header_user = str(request.headers.get("x-user-id") or "").strip()
        if header_user:
            return header_user

    claims = _extract_authorizer_claims(request)
    sub = str(claims.get("sub") or "").strip()
    if sub:
        return sub

    return ""


def _disable_cognito() -> bool:
    val = os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}
    if not val:
        return False
    from apps.backend.config.environment import get_environment, is_production_like

    env = get_environment()
    if is_production_like():
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in %s environment. "
            "This is a critical security misconfiguration. Ignoring the flag.",
            env,
        )
        return False
    if os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    return True


def _extract_bearer_token(request: Request) -> str:
    auth_header = str(request.headers.get("authorization") or request.headers.get("Authorization") or "").strip()
    if not auth_header.lower().startswith("bearer "):
        return ""
    return auth_header.split(" ", 1)[1].strip()


def _extract_bearer_token_from_headers(headers: Mapping[str, Any]) -> str:
    auth_header = str(headers.get("authorization") or headers.get("Authorization") or "").strip()
    if not auth_header.lower().startswith("bearer "):
        return ""
    return auth_header.split(" ", 1)[1].strip()


def _resolve_tenant_for_identity(*, user_id: str, email: str) -> str:
    provisioning_service = get_tenant_provisioning_service()

    if user_id:
        tenant = provisioning_service.get_tenant_by_owner(user_id, product="workweaver")
        if not tenant:
            tenant = provisioning_service.get_tenant_by_owner(user_id, product=None)
        if tenant:
            return str(tenant.get("tenant_id") or tenant.get("pk") or "").strip()

    if email:
        tenant = provisioning_service.get_tenant_by_email(email, product="workweaver")
        if not tenant:
            tenant = provisioning_service.get_tenant_by_email(email, product=None)
        if tenant:
            return str(tenant.get("tenant_id") or tenant.get("pk") or "").strip()

    return ""


def _canonical_resolved_tenant_id(*, tenant_id: str, user_id: str, email: str) -> str:
    """Resolve a normalized tenant claim to the persisted tenant record key."""
    resolved = _resolve_tenant_for_identity(user_id=user_id, email=email)
    if resolved:
        return resolved

    normalized = strip_tenant_prefix(tenant_id)
    if not normalized:
        return ""
    return tenant_pk(normalized)


def _resolve_context_from_authorizer(request: Request) -> tuple[str, str]:
    claims = _extract_authorizer_claims(request)
    if not claims:
        return "", ""

    try:
        envelope = get_identity_provider().resolve_from_claims(claims)
    except IdentityProviderError as exc:
        raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc

    user_id = str(envelope.user_id or "").strip()
    email = str(envelope.email or "").strip().lower()
    tenant_id = _canonical_resolved_tenant_id(
        tenant_id=str(envelope.tenant_id or "").strip(),
        user_id=user_id,
        email=email,
    )
    request.state._auth_provider = str(envelope.provider or "").strip() or get_identity_provider().provider_name
    request.state._auth_session_type = getattr(envelope.session_type, "value", str(envelope.session_type))
    return tenant_id, user_id


def _resolve_context_from_access_token_value(access_token: str) -> tuple[str, str]:
    try:
        claims = verify_cli_session_token(access_token)
        # GAP-003 (issue #1147): enforce session-invalidation gate.
        _enforce_session_not_invalidated(claims.email, claims.iat)
        # Issue #1146 round-3 BLOCK: reject suspended-tenant sessions.
        _enforce_tenant_not_suspended(claims.tenant_id)
        return claims.tenant_id, claims.user_id
    except CLISessionTokenError:
        pass

    try:
        claims = verify_browser_session_token(access_token)
        _enforce_session_not_invalidated(claims.email, claims.iat)
        _enforce_tenant_not_suspended(claims.tenant_id)
        return claims.tenant_id, claims.user_id
    except BrowserSessionTokenError:
        pass

    try:
        envelope = get_identity_provider().resolve_from_access_token(access_token)
    except IdentityProviderError as exc:
        logger.warning("Failed to validate bearer token for tenant auth", exc_info=True)
        raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc

    user_id = str(envelope.user_id or "").strip()
    email = str(envelope.email or "").strip().lower()
    tenant_id = _canonical_resolved_tenant_id(
        tenant_id=str(envelope.tenant_id or "").strip(),
        user_id=user_id,
        email=email,
    )
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authenticated account is not linked to an organization",
        )

    _enforce_tenant_not_suspended(tenant_id)
    return tenant_id, user_id


def _resolve_context_from_access_token(request: Request) -> tuple[str, str]:
    access_token = _extract_bearer_token(request)
    if not access_token:
        return "", ""
    try:
        envelope = get_identity_provider().resolve_from_access_token(access_token)
        request.state._auth_provider = str(envelope.provider or "").strip() or get_identity_provider().provider_name
        request.state._auth_session_type = getattr(envelope.session_type, "value", str(envelope.session_type))
    except IdentityProviderError:
        logger.debug("Failed to pre-resolve bearer auth source metadata", exc_info=True)
    return _resolve_context_from_access_token_value(access_token)


def _resolve_context_from_browser_session(request: Request) -> tuple[str, str]:
    cookies = getattr(request, "cookies", {}) or {}
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:  # noqa: PLR5501
        token = str(cookies.get(cookie_name) or "").strip()
        if not token:
            continue
        try:
            claims = verify_browser_session_token(token)
        except BrowserSessionTokenError:
            logger.warning("Failed to validate browser session cookie for tenant auth", exc_info=True)
            return "", ""
        # GAP-003 (issue #1147): reject tokens minted before a password reset.
        _enforce_session_not_invalidated(claims.email, claims.iat)
        # Issue #1146 round-3 BLOCK: reject suspended-tenant sessions
        # on the browser-cookie path too, not just managed bearer auth.
        _enforce_tenant_not_suspended(claims.tenant_id)
        impersonator_id = claims.impersonator_id or ""
        if impersonator_id:
            request.state.impersonator_id = impersonator_id
            request.state.authenticated_impersonator_id = impersonator_id
        request.state._auth_provider = "browser_session"
        request.state._auth_session_type = "browser"
        return claims.tenant_id, claims.user_id
    return "", ""


def _resolve_authenticated_context(request: Request) -> tuple[str, str]:
    """Resolve tenant+user from the request, tracking the auth source for envelope truthfulness.

    Codex round-4 BLOCK fix: every return path — including the
    fast-path ``request.state`` shortcut and the API Gateway
    authorizer branch — must go through ``_enforce_tenant_not_suspended``.
    Otherwise a suspended tenant whose token was already verified
    upstream (e.g. by the ``main.py`` browser-session middleware
    that writes ``authenticated_tenant_id`` before any route runs)
    would slip past the suspend gate entirely.
    """
    state_tenant_id = str(getattr(request.state, "authenticated_tenant_id", "") or "").strip()
    state_user_id = str(getattr(request.state, "authenticated_user_id", "") or "").strip()
    if state_tenant_id:
        # Fast path: upstream already verified the session. Still
        # run the suspend gate here — the session verify does not
        # consult tenant status.
        _enforce_tenant_not_suspended(state_tenant_id)
        request.state._auth_source = "state"
        return state_tenant_id, state_user_id

    tenant_id, user_id = _resolve_context_from_browser_session(request)
    if tenant_id:
        request.state._auth_source = "browser"
        return tenant_id, user_id

    tenant_id, user_id = _resolve_context_from_authorizer(request)
    if tenant_id:
        # API Gateway authorizer-claims path. Like the state fast
        # path, the claims verification happened upstream but did
        # not check tenant status — run the gate here.
        _enforce_tenant_not_suspended(tenant_id)
        request.state._auth_source = "api_gateway"
        return tenant_id, user_id

    request.state._auth_source = "bearer"
    return _resolve_context_from_access_token(request)


def get_verified_tenant_id(
    request: Request,
    x_tenant_id: str | None = Header(None),
) -> str:
    """Extract and verify tenant_id.

    In production: extracts tenant_id from JWT token claims and validates
    it matches the X-Tenant-Id header (if provided).
    In dev mode: trusts the X-Tenant-Id header directly.

    Returns:
        Verified tenant_id string.

    Raises:
        HTTPException 401 if no tenant_id can be determined.
        HTTPException 403 if header tenant_id mismatches JWT tenant_id.
    """
    # Dev mode: trust header
    if _disable_cognito():
        if not x_tenant_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="X-Tenant-Id header required",
            )
        normalized = strip_tenant_prefix(x_tenant_id)
        request.state.tenant_id = normalized
        user_id = _extract_user_id(request, allow_untrusted_headers=True)
        if user_id:
            request.state.user_id = user_id
        if not getattr(request.state, "auth_envelope", None):
            request.state.auth_envelope = _build_auth_envelope(
                tenant_id=normalized,
                user_id=user_id,
                provider="local",
                session_type="local_dev",
                impersonator_id=resolve_authenticated_impersonator_id(request) or "",
            )
        return normalized

    tenant_id, user_id = _resolve_authenticated_context(request)
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    # Canonical normalization: strip TENANT# prefix from both sides.
    # DynamoDB layers re-add it via their key builders.
    resolved = strip_tenant_prefix(tenant_id)
    header_normalized = strip_tenant_prefix(x_tenant_id) if x_tenant_id else ""

    if header_normalized and header_normalized != resolved:
        logger.warning("Tenant ID mismatch: header=%s resolved=%s", x_tenant_id, tenant_id)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization ID mismatch between header and authentication token",
        )

    request.state.tenant_id = resolved
    if user_id:
        request.state.user_id = user_id

    if not getattr(request.state, "auth_envelope", None):
        _provider, _session_type = _resolve_auth_source_provider_session(request)
        request.state.auth_envelope = _build_auth_envelope(
            tenant_id=resolved,
            user_id=user_id,
            provider=_provider,
            session_type=_session_type,
            impersonator_id=resolve_authenticated_impersonator_id(request) or "",
        )

    return resolved


def get_verified_user_id(
    request: Request,
    x_user_id: str | None = Header(None),
) -> str:
    """Extract and verify user_id from authenticated context.

    In production: derives user identity from authenticated context and rejects
    mismatched X-User-Id headers.
    In dev mode: trusts X-User-Id header as local fallback.
    """
    if _disable_cognito():
        if not x_user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="X-User-Id header required",
            )
        request.state.user_id = x_user_id
        return x_user_id

    resolved_user_id = str(
        getattr(request.state, "authenticated_user_id", "") or getattr(request.state, "user_id", "") or ""
    ).strip()

    if not resolved_user_id:
        tenant_id, resolved_user_id = _resolve_authenticated_context(request)
        if tenant_id and not getattr(request.state, "tenant_id", None):
            request.state.tenant_id = tenant_id

    if not resolved_user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    if x_user_id and x_user_id != resolved_user_id:
        logger.warning("User ID mismatch: header=%s resolved=%s", x_user_id, resolved_user_id)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User ID mismatch between header and authentication token",
        )

    request.state.user_id = resolved_user_id
    if not getattr(request.state, "auth_envelope", None):
        resolved_tenant_id = strip_tenant_prefix(
            str(
                getattr(request.state, "tenant_id", "")
                or getattr(request.state, "authenticated_tenant_id", "")
                or "",
            ).strip()
        )
        if resolved_tenant_id:
            provider, session_type = _resolve_auth_source_provider_session(request)
            request.state.auth_envelope = _build_auth_envelope(
                tenant_id=resolved_tenant_id,
                user_id=resolved_user_id,
                provider=provider,
                session_type=session_type,
                impersonator_id=resolve_authenticated_impersonator_id(request) or "",
            )
    return resolved_user_id


def resolve_verified_tenant_id(request: Request) -> str:
    """Resolve tenant for non-dependency call sites while preserving prod validation."""
    header_tenant = (
        str(
            request.headers.get("x-tenant-id")
            or request.headers.get("X-Tenant-Id")
            or request.headers.get("X-Tenant-ID")
            or ""
        ).strip()
        or None
    )
    return get_verified_tenant_id(request=request, x_tenant_id=header_tenant)


def _has_authentication_evidence(request: Request) -> bool:
    """Return True when the request carries real auth material.

    Optional-auth routes may fall back to route-specific tenant resolution only
    when the request is genuinely unauthenticated. If auth state, cookies,
    headers, or authorizer claims are present, auth failures must still surface.
    """
    if str(getattr(request.state, "authenticated_tenant_id", "") or "").strip():
        return True
    if str(getattr(request.state, "authenticated_user_id", "") or "").strip():
        return True

    cookies = getattr(request, "cookies", {}) or {}
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
        if str(cookies.get(cookie_name) or "").strip():
            return True

    authorization = str(
        request.headers.get("authorization") or request.headers.get("Authorization") or "",
    ).strip()
    if authorization:
        return True

    header_tenant = str(
        request.headers.get("x-tenant-id")
        or request.headers.get("X-Tenant-Id")
        or request.headers.get("X-Tenant-ID")
        or "",
    ).strip()
    if header_tenant:
        return True

    return bool(_extract_authorizer_claims(request))


def resolve_optional_verified_tenant_id(request: Request) -> str | None:
    """Best-effort tenant resolution for routes where authenticated tenant is optional."""
    auth_evidence = _has_authentication_evidence(request)
    try:
        return resolve_verified_tenant_id(request)
    except HTTPException as exc:
        if exc.status_code == status.HTTP_401_UNAUTHORIZED and not auth_evidence:
            return None
        raise


def resolve_verified_websocket_tenant_id(websocket: WebSocket) -> str:
    """Resolve tenant for websocket handshakes without trusting raw tenant ids in production."""
    query_tenant = str(websocket.query_params.get("tenant_id") or "").strip()
    header_tenant = str(
        websocket.headers.get("x-tenant-id")
        or websocket.headers.get("X-Tenant-Id")
        or websocket.headers.get("X-Tenant-ID")
        or ""
    ).strip()
    provided_tenant_raw = query_tenant or header_tenant or ""
    provided_tenant = strip_tenant_prefix(provided_tenant_raw) if provided_tenant_raw else ""

    if _disable_cognito():
        if not provided_tenant:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="organization_id required")
        return provided_tenant

    claims = _extract_authorizer_claims_from_scope(websocket.scope if isinstance(websocket.scope, dict) else None)
    if claims:
        try:
            envelope = get_identity_provider().resolve_from_claims(claims)
        except IdentityProviderError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        tenant_id = _canonical_resolved_tenant_id(
            tenant_id=str(envelope.tenant_id or "").strip(),
            user_id=str(envelope.user_id or "").strip(),
            email=str(envelope.email or "").strip().lower(),
        )
    else:
        access_token = str(websocket.query_params.get("access_token") or "").strip()
        if not access_token:
            access_token = _extract_bearer_token_from_headers(websocket.headers)
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required",
            )
        tenant_id, _user_id = _resolve_context_from_access_token_value(access_token)

    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authenticated account is not linked to an organization",
        )

    # Codex round-4 BLOCK fix: websocket handshakes went through the
    # authorizer-claims or access-token path without consulting
    # tenant status. A suspended tenant's cached access token would
    # still open a websocket. Gate here.
    _enforce_tenant_not_suspended(tenant_id)

    resolved_tenant_id = strip_tenant_prefix(tenant_id)
    if provided_tenant and provided_tenant != resolved_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization ID mismatch between handshake and authentication token",
        )

    return resolved_tenant_id


# ---------------------------------------------------------------------------
# Verified user attribute resolution (role, email)
# ---------------------------------------------------------------------------

def _resolve_user_record(tenant_id: str, user_id: str) -> dict[str, Any]:
    """Look up a user record from DynamoDB using verified identity.

    Returns the raw DynamoDB item dict, or {} if not found.
    """
    normalized_tenant_id = str(tenant_id or "").strip()
    normalized_user_id = str(user_id or "").strip()
    if not normalized_tenant_id or not normalized_user_id:
        return {}

    try:
        table = get_users_table()
        tenant_key = tenant_pk(normalized_tenant_id)
        user_key = normalized_user_id if normalized_user_id.startswith("USER#") else f"USER#{normalized_user_id}"
        response = table.get_item(Key={"pk": tenant_key, "sk": user_key})
        return response.get("Item") or {}
    except Exception:
        logger.warning(
            "Failed to resolve user record for tenant=%s user=%s",
            tenant_id,
            user_id,
            exc_info=True,
        )
        return {}


def get_verified_user_role(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> UserRole:
    """Return the caller's role from the authoritative user record in DynamoDB.

    Production: looks up role using verified tenant_id + user_id.
    Dev mode (DISABLE_COGNITO): trusts X-User-Role header as local fallback.

    Defaults to UserRole.AGENT (most restrictive) when the role cannot be resolved.
    """
    if _disable_cognito():
        x_role = str(request.headers.get("x-user-role") or "").strip().lower()
        if not x_role:
            return UserRole.AGENT
        try:
            return UserRole(x_role)
        except ValueError:
            return UserRole.AGENT

    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    if not user_id:
        return UserRole.AGENT

    record = _resolve_user_record(tenant_id, user_id)
    role_value = str(record.get("role", "")).strip().lower()
    try:
        return UserRole(role_value) if role_value else UserRole.AGENT
    except ValueError:
        return UserRole.AGENT


def require_admin_user_role(
    user_role: UserRole = Depends(get_verified_user_role),
) -> UserRole:
    """Require an authenticated admin role for tenant-scoped admin surfaces."""
    if user_role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return user_role


def require_platform_admin(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> str:
    """Deprecated: use require_founder from founder_admin.py instead.

    Retained for backward compatibility during migration.

    Distinct from `require_admin_user_role` which checks per-tenant role.
    Platform admins are listed in WORKWEAVER_ADMIN_EMAILS env var, and the
    same allowlist is consumed by AuthMeResponse.is_admin in auth_login.py.

    Returns the verified email so admin endpoints can audit who made the call.
    Raises 403 if the user is not on the allowlist.
    """
    email = get_verified_user_email(request=request, tenant_id=tenant_id)
    email_lower = email.strip().lower() if email else ""
    if not email_lower:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Platform admin required (email unverified)",
        )
    if not is_platform_admin_email(email_lower):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Platform admin required",
        )
    return email_lower


def get_verified_user_email(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> str:
    """Return the caller's email from the authoritative user record in DynamoDB.

    Production: looks up email using verified tenant_id + user_id.
    Dev mode (DISABLE_COGNITO): trusts X-User-Email header as local fallback.

    Returns empty string when the email cannot be resolved.
    """
    if _disable_cognito():
        return str(request.headers.get("x-user-email") or "").strip()

    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    if not user_id:
        return ""

    record = _resolve_user_record(tenant_id, user_id)
    return str(record.get("email", "")).strip().lower()
