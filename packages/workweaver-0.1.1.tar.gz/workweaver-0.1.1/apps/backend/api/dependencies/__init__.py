"""FastAPI dependency injection utilities."""

from .tenant_auth import get_verified_tenant_id
from .plugin_auth import get_plugin_tenant_id
from .admin_permissions import require_admin_permission, require_admin_permission_dep
from .scope_validation import require_role, validate_websocket_scope, role_satisfies
from .redirect_validation import validate_redirect_host, validate_redirect_url

__all__ = [
    "get_verified_tenant_id",
    "get_plugin_tenant_id",
    "require_admin_permission",
    "require_admin_permission_dep",
    "require_role",
    "validate_websocket_scope",
    "role_satisfies",
    "validate_redirect_host",
    "validate_redirect_url",
]
