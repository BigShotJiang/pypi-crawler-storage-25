"""Onboarding API Endpoints.

Backend API for first-run onboarding flow state persistence.
"""

from apps.backend.config.table_names import resolve_table

import asyncio
from apps.backend.config.region import AWS_REGION
import logging
from typing import Any

import boto3
from boto3.dynamodb.conditions import Attr
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.payment_event_resource_store import get_payment_event_resource_store
from apps.backend.services.onboarding_state import (
    OnboardingStateService,
    OnboardingState,
    OnboardingStep,
    OnboardingStatus,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/onboarding", tags=["onboarding"])

# ---------------------------------------------------------------------------
# Persistence adapters
# ---------------------------------------------------------------------------


class OnboardingStoreUnavailable(RuntimeError):
    """Raised when onboarding persistence cannot be reached."""


class _DynamoOnboardingStore:
    """Thin async wrapper around DynamoDB for onboarding state documents."""

    def __init__(self, table):
        self.table = table

    async def find_one(self, collection: str, filters: dict[str, Any]) -> dict[str, Any] | None:
        tenant_id = str(filters.get("tenant_id") or "").strip()
        if not tenant_id:
            return None

        direct_keys = [
            {"pk": tenant_id, "sk": collection},
            {"tenant_id": tenant_id, "collection": collection},
        ]
        for key in direct_keys:
            try:
                response = await asyncio.to_thread(self.table.get_item, Key=key)
            except Exception as exc:
                logger.debug("Dynamo get_item failed for key=%s: %s", key, exc)
                continue
            item = response.get("Item")
            if item:
                return item

        # Fallback scan keeps this adapter resilient to unexpected key schemas.
        try:
            scan_kwargs = {"FilterExpression": Attr("tenant_id").eq(tenant_id) & Attr("collection").eq(collection)}
            response = await asyncio.to_thread(self.table.scan, **scan_kwargs)
            items = response.get("Items", [])
            return items[0] if items else None
        except Exception as exc:
            logger.error(
                "Dynamo scan fallback failed for tenant=%s collection=%s: %s",
                tenant_id,
                collection,
                exc,
            )
            raise OnboardingStoreUnavailable("onboarding_read_failed") from exc

    async def upsert(self, collection: str, key: dict[str, Any], item: dict[str, Any]) -> None:
        tenant_id = str(key.get("tenant_id") or "").strip()
        if not tenant_id:
            return

        payload = dict(item)
        payload["tenant_id"] = tenant_id
        payload["collection"] = collection

        # Tenant table compatible keying with fallback to generic schema.
        payload_with_pk = dict(payload)
        payload_with_pk["pk"] = tenant_id
        payload_with_pk["sk"] = collection

        try:
            await asyncio.to_thread(self.table.put_item, Item=payload_with_pk)
            return
        except Exception as primary_exc:
            logger.debug(
                "Dynamo put_item with pk/sk failed, retrying without pk/sk: %s",
                primary_exc,
            )
            try:
                await asyncio.to_thread(self.table.put_item, Item=payload)
                return
            except Exception as fallback_exc:
                logger.error(
                    "Failed to persist onboarding state (tenant=%s collection=%s): %s",
                    tenant_id,
                    collection,
                    fallback_exc,
                )
                raise OnboardingStoreUnavailable("onboarding_write_failed") from fallback_exc

    async def delete_many(self, collection: str, filters: dict[str, Any]) -> None:
        tenant_id = str(filters.get("tenant_id") or "").strip()
        if not tenant_id:
            return

        deleted = False
        try:
            await asyncio.to_thread(
                self.table.delete_item,
                Key={"pk": tenant_id, "sk": collection},
            )
            deleted = True
        except Exception as exc:
            logger.debug("Dynamo delete_item pk/sk failed: %s", exc)

        if not deleted:
            try:
                candidates = await self.find(collection, filters, limit=1)
                for item in candidates:
                    item_tenant = item.get("tenant_id")
                    item_collection = item.get("collection")
                    if item_tenant != tenant_id or item_collection != collection:
                        continue
                    key = {"pk": item_tenant, "sk": item_collection}
                    try:
                        await asyncio.to_thread(self.table.delete_item, Key=key)
                    except Exception:
                        raise OnboardingStoreUnavailable("onboarding_delete_failed")
            except Exception as exc:
                raise OnboardingStoreUnavailable("onboarding_delete_failed") from exc

    async def find(self, collection: str, filters: dict[str, Any], limit: int = 100) -> list[dict[str, Any]]:
        status_value = filters.get("status")
        limit = max(1, int(limit or 100))

        filter_expression = Attr("collection").eq(collection)
        if status_value is not None:
            filter_expression = filter_expression & Attr("status").eq(status_value)

        try:
            scan_kwargs = {
                "FilterExpression": filter_expression,
                "Limit": limit,
            }
            response = await asyncio.to_thread(self.table.scan, **scan_kwargs)
            return response.get("Items", [])
        except Exception as exc:
            logger.error("Dynamo find failed for collection=%s: %s", collection, exc)
            raise OnboardingStoreUnavailable("onboarding_list_failed") from exc


_ONBOARDING_STORE: Any = None


def _coalesce_env(value: str | None, fallback: str) -> str:
    return value.strip() if isinstance(value, str) and value.strip() else fallback


def _get_onboarding_table_name() -> str:
    return _coalesce_env(
        resolve_table("onboarding_states"),
        _coalesce_env(resolve_table("tenants"), "workweaver-onboarding-states"),
    )


def _get_onboarding_store() -> Any:
    global _ONBOARDING_STORE

    if _ONBOARDING_STORE is not None:
        return _ONBOARDING_STORE

    table_name = _get_onboarding_table_name()
    try:
        region = AWS_REGION
        table = boto3.resource("dynamodb", region_name=region).Table(table_name)
        _ONBOARDING_STORE = _DynamoOnboardingStore(table)
        logger.info("Using DynamoDB onboarding store: table=%s", table_name)
    except Exception as exc:
        logger.error(
            "Onboarding store unavailable (DynamoDB initialization failed). Reason: %s",
            exc,
        )
        raise OnboardingStoreUnavailable("onboarding_store_unavailable") from exc

    return _ONBOARDING_STORE


def get_onboarding_state_service() -> OnboardingStateService:
    try:
        store = _get_onboarding_store()
    except OnboardingStoreUnavailable as exc:
        # Issue #1999 — make this actionable. The previous generic
        # "Unable to save" surfaced no recovery path. Tell the caller
        # exactly what to do: status page + retry budget + support hint.
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "code": "onboarding_storage_unavailable",
                "message": (
                    "Onboarding storage is temporarily unreachable. Your progress is safe — please retry in 30 seconds."
                ),
                "actions": [
                    {"label": "Retry now", "action": "retry"},
                    {
                        "label": "View status",
                        "action": "open_url",
                        "url": "https://status.workweaver.ai",
                    },
                    {
                        "label": "Email support",
                        "action": "open_url",
                        "url": "mailto:support@workweaver.ai?subject=Onboarding%20503",
                    },
                ],
                "retry_after_seconds": 30,
            },
        ) from exc
    payment_event_resource_store = get_payment_event_resource_store()
    return OnboardingStateService(db_client=store, payment_event_resource_store=payment_event_resource_store)


class OnboardingStateResponse(BaseModel):
    """Response model for onboarding state."""

    tenant_id: str
    status: OnboardingStatus
    current_step: OnboardingStep
    completed_steps: list[OnboardingStep]
    data: dict[str, Any]
    started_at: str | None
    updated_at: str | None
    completed_at: str | None
    time_elapsed_seconds: int


class AdvanceStepRequest(BaseModel):
    """Request to advance onboarding step."""

    step: OnboardingStep = Field(..., description="Step being completed")
    step_data: dict[str, Any] = Field(default_factory=dict, description="Data collected from this step")


class UpdateStepDataRequest(BaseModel):
    """Request to update onboarding data."""

    step_data: dict[str, Any] = Field(..., description="Partial data to update")


class ProgressSummaryResponse(BaseModel):
    """Response model for progress summary."""

    tenant_id: str
    status: OnboardingStatus
    current_step: OnboardingStep
    completed_steps: int
    total_steps: int
    progress_percent: int
    time_elapsed_seconds: int
    started_at: str | None
    updated_at: str | None
    completed_at: str | None


class TenantProgressSummary(BaseModel):
    """Summary of tenant onboarding progress."""

    tenant_id: str
    current_step: OnboardingStep
    progress_percent: int
    updated_at: str


def _state_to_response(state: OnboardingState) -> OnboardingStateResponse:
    """Convert internal state into API response payload."""

    return OnboardingStateResponse(
        tenant_id=state.tenant_id,
        status=state.status,
        current_step=state.current_step,
        completed_steps=state.completed_steps,
        data=state.data.model_dump(mode="json"),
        started_at=state.started_at.isoformat() if state.started_at else None,
        updated_at=state.updated_at.isoformat() if state.updated_at else None,
        completed_at=state.completed_at.isoformat() if state.completed_at else None,
        time_elapsed_seconds=state.time_elapsed_seconds,
    )


@router.get(
    "/state",
    response_model=OnboardingStateResponse,
    summary="Get onboarding state",
    description="Retrieve current onboarding state for the authenticated tenant",
)
async def get_onboarding_state(
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Get onboarding state for a tenant."""

    try:
        state = await onboarding_service.get_state(tenant_id)
        return _state_to_response(state)
    except Exception as exc:
        logger.error("Failed to retrieve onboarding state: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve onboarding state",
        )


@router.post(
    "/start",
    response_model=OnboardingStateResponse,
    summary="Start onboarding",
    description="Initialize onboarding for a new tenant",
)
async def start_onboarding(
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Start onboarding for the tenant."""

    try:
        state = await onboarding_service.get_state(tenant_id)
        if state.status != OnboardingStatus.NOT_STARTED:
            return _state_to_response(state)
        return _state_to_response(await onboarding_service.start_onboarding(tenant_id))
    except Exception as exc:
        logger.error("Failed to start onboarding: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to start onboarding",
        )


def _validate_step_data_timezone(step_data: dict[str, Any]) -> None:
    """Validate timezone in step_data if present. Raises HTTPException on invalid value."""
    tz = step_data.get("timezone")
    if tz is not None:
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        tz_str = str(tz).strip()
        if not tz_str:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Timezone must not be empty",
            )
        try:
            ZoneInfo(tz_str)
        except (ZoneInfoNotFoundError, KeyError):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid timezone: {tz_str}",
            )
        # Normalize to validated string
        step_data["timezone"] = tz_str


@router.post(
    "/advance",
    response_model=OnboardingStateResponse,
    summary="Advance onboarding step",
    description="Complete the current step and advance to the next",
)
async def advance_step(
    request: AdvanceStepRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Advance onboarding to the next step."""

    try:
        _validate_step_data_timezone(request.step_data)
        state = await onboarding_service.advance_step(
            tenant_id=tenant_id, step=request.step, step_data=request.step_data
        )
        return _state_to_response(state)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Unable to advance onboarding: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unable to advance onboarding",
        )


@router.put(
    "/data",
    response_model=OnboardingStateResponse,
    summary="Update onboarding data",
    description="Update onboarding data without advancing step",
)
async def update_step_data(
    request: UpdateStepDataRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Update partial onboarding data."""

    try:
        _validate_step_data_timezone(request.step_data)
        state = await onboarding_service.update_step_data(tenant_id=tenant_id, step_data=request.step_data)
        return _state_to_response(state)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to update onboarding data: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update onboarding data",
        )


@router.post(
    "/skip",
    response_model=OnboardingStateResponse,
    summary="Skip onboarding",
    description="Skip the onboarding wizard",
)
async def skip_onboarding(
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Mark onboarding as skipped."""

    try:
        state = await onboarding_service.skip_onboarding(tenant_id)
        return _state_to_response(state)
    except Exception as exc:
        logger.error("Failed to skip onboarding: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to skip onboarding",
        )


@router.post(
    "/reset",
    response_model=OnboardingStateResponse,
    summary="Reset onboarding",
    description="Reset onboarding to start from the beginning",
)
async def reset_onboarding(
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> OnboardingStateResponse:
    """Reset onboarding state."""

    try:
        state = await onboarding_service.reset_onboarding(tenant_id)
        return _state_to_response(state)
    except Exception as exc:
        logger.error("Failed to reset onboarding: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to reset onboarding",
        )


@router.get(
    "/progress",
    response_model=ProgressSummaryResponse,
    summary="Get progress summary",
    description="Get onboarding progress summary with completion percentage",
)
async def get_progress_summary(
    tenant_id: str = Depends(get_verified_tenant_id),
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> ProgressSummaryResponse:
    """Get onboarding progress summary."""

    try:
        summary = await onboarding_service.get_progress_summary(tenant_id)

        # Helper to convert datetime to ISO string (handles already-string values)
        def to_iso_string(value):
            if value is None:
                return None
            if isinstance(value, str):
                return value
            return value.isoformat()

        return ProgressSummaryResponse(
            tenant_id=summary["tenant_id"],
            status=summary["status"],
            current_step=summary["current_step"],
            completed_steps=summary["completed_steps"],
            total_steps=summary["total_steps"],
            progress_percent=summary["progress_percent"],
            time_elapsed_seconds=summary["time_elapsed_seconds"],
            started_at=to_iso_string(summary.get("started_at")),
            updated_at=to_iso_string(summary.get("updated_at")),
            completed_at=to_iso_string(summary.get("completed_at")),
        )
    except Exception as exc:
        logger.error("Failed to fetch onboarding progress: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch onboarding progress",
        )


@router.get(
    "/admin/in-progress",
    response_model=list[TenantProgressSummary],
    summary="List in-progress tenants",
    description="List all tenants with in-progress onboarding",
)
async def list_in_progress_tenants(
    limit: int = 100,
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> list[TenantProgressSummary]:
    """List tenants that have started onboarding."""

    try:
        tenants = await onboarding_service.list_in_progress_tenants(limit)
        return [
            TenantProgressSummary(
                tenant_id=t["tenant_id"],
                current_step=t["current_step"],
                progress_percent=t["progress_percent"],
                updated_at=t["updated_at"],
            )
            for t in tenants
        ]
    except Exception as exc:
        logger.error("Failed to list in-progress onboarding tenants: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list in-progress onboarding organizations",
        )


# ---------------------------------------------------------------------------
# Autonomous first-mission onboarding (Issue #1878)
# ---------------------------------------------------------------------------

from apps.backend.services.zara.first_mission_onboarding import (
    FirstMissionOnboardingRequest as _FirstMissionRequest,
    FirstMissionOnboardingResult as _FirstMissionResult,
    FirstMissionOnboardingService,
)


class FirstMissionRequest(BaseModel):
    """Request body for autonomous first-mission onboarding."""

    goal_text: str = Field(
        ...,
        description="The user goal -- can be vague, the compiler handles it.",
        min_length=1,
        max_length=2000,
    )
    email: str = Field(default="", description="User email for profile prefill.")
    user_name: str | None = Field(default=None, description="Display name from auth provider.")
    timezone: str = Field(default="UTC", description="IANA timezone name.")


class FrictionMetricsResponse(BaseModel):
    """Onboarding friction metrics for UAT measurement."""

    clicks: int
    keystrokes: int
    duration_seconds: float
    screens_visited: int
    steps_auto_advanced: int


class CompiledPlanResponse(BaseModel):
    """Summary of the compiled goal plan."""

    mode: str
    team_structure: str
    todo: list[str]
    not_do: list[str]
    guardrails: list[str]
    skillify_decision: str
    interview_questions: list[str]


class FirstMissionResponse(BaseModel):
    """Response from the autonomous first-mission onboarding endpoint."""

    onboarding: OnboardingStateResponse
    compiled_plan: CompiledPlanResponse
    metrics: FrictionMetricsResponse


def _get_first_mission_service(
    onboarding_service: OnboardingStateService = Depends(get_onboarding_state_service),
) -> FirstMissionOnboardingService:
    """Create a FirstMissionOnboardingService from the same store/payment-event resources."""
    return FirstMissionOnboardingService(
        db_client=onboarding_service.db,
        payment_event_resource_store=onboarding_service.operational_context,
    )


@router.post(
    "/first-mission",
    response_model=FirstMissionResponse,
    summary="Autonomous first-mission onboarding",
    description=(
        "Compile a single goal into a complete onboarding state. "
        "Zara infers skills, connectors, and business profile from the goal "
        "text, eliminating the 6-step wizard. Issue #1878."
    ),
)
async def compile_first_mission(
    request: FirstMissionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    service: FirstMissionOnboardingService = Depends(_get_first_mission_service),
) -> FirstMissionResponse:
    """Compile a goal into an autonomous first-mission onboarding."""

    try:
        result: _FirstMissionResult = await service.compile_first_mission(
            _FirstMissionRequest(
                tenant_id=tenant_id,
                goal_text=request.goal_text,
                email=request.email,
                user_name=request.user_name,
                timezone=request.timezone,
            )
        )
        return FirstMissionResponse(
            onboarding=_state_to_response(result.onboarding_state),
            compiled_plan=CompiledPlanResponse(
                mode=result.compiled_plan.mode.value,
                team_structure=result.compiled_plan.team_structure.value,
                todo=result.compiled_plan.todo,
                not_do=result.compiled_plan.not_do,
                guardrails=result.compiled_plan.guardrails,
                skillify_decision=result.compiled_plan.skillify_decision.value,
                interview_questions=result.compiled_plan.interview_questions,
            ),
            metrics=FrictionMetricsResponse(
                clicks=result.metrics.clicks,
                keystrokes=result.metrics.keystrokes,
                duration_seconds=result.metrics.duration_seconds,
                screens_visited=result.metrics.screens_visited,
                steps_auto_advanced=result.metrics.steps_auto_advanced,
            ),
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("First-mission onboarding failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="First-mission onboarding failed",
        )
