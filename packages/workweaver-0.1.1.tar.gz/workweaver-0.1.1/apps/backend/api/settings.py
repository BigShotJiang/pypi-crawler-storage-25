"""
Settings API

API endpoints for user/tenant settings management including profile, company,
billing, and API key management.

Source: Frontend requirements from apps/dashboard/components/workspace/settings.html
Status: Implementation - Replacing frontend stubs with real API calls
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import secrets
from datetime import datetime, UTC
from typing import Any, Literal

from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, HTTPException, status
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.meetings import get_meeting_consent_policy_summary
from apps.backend.services.inference.settings import (
    merge_hidden_ai_settings as _merge_hidden_ai_settings_impl,
    normalize_ai_settings_payload as _normalize_ai_settings_payload_impl,
)
from apps.backend.services.behavioral_stops_store import (
    BehavioralStopsStoreError,
    LEARNING_CONTROL_FIELDS,
    _emit_evidence_receipt,
    _get_stops as _get_behavioral_stops,
    _save_stops as _save_behavioral_stops,
)
from apps.backend.services.inference.auth_service import (
    InferenceAuthError,
    InferenceConsentError,
    InferencePolicyError,
    InferenceStateError,
    begin_provider_oauth,
    complete_provider_oauth,
    disconnect_provider_oauth,
    get_inference_auth_service,
    refresh_provider_oauth,
    status_provider_oauth,
)
from apps.backend.services.inference.service import (
    ANTHROPIC_PROVIDER,
    BEDROCK_PROVIDER,
    OPENAI_COMPATIBLE_PROVIDER_IDS,
    SUBSCRIPTION_OAUTH_PROVIDER_IDS,
    SUPPORTED_PROVIDER_IDS,
    default_model_selections,
    get_inference_catalog,
    normalize_provider_name,
)

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id  # noqa: F401
from apps.backend.dependency_factories.core import get_tenants_table as get_shared_tenants_table
from apps.backend.schemas.error_response import safe_error_detail
from pydantic import BaseModel, EmailStr, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


class SettingsStorageError(RuntimeError):
    """Raised when durable settings storage is unavailable."""


# Request/Response Models


class ProfileSettings(BaseModel):
    """User profile settings."""

    tenant_id: str | None = None
    user_id: str | None = None
    full_name: str = ""
    email: EmailStr | str = ""
    phone: str = ""
    timezone: str = "UTC"
    language: str = "en"


class CompanySettings(BaseModel):
    """Company/organization settings.

    The mission, ICP, and goals fields power the AI CEO mode —
    they're injected into Zara's system prompt so it knows what
    the company does, who to sell to, and what outcomes to pursue.
    Without these, Zara operates reactively. With them, it operates
    proactively as an autonomous business operator.
    """

    tenant_id: str | None = None
    company_name: str = ""
    industry: str = ""
    size: str = ""
    website: str = ""
    # AI CEO context — enables proactive autonomous operation
    mission_statement: str = ""
    value_proposition: str = ""
    icp_description: str = ""
    business_goals: list[str] = Field(default_factory=list)
    target_audience: str = ""
    key_differentiators: str = ""


class InstructionsSettings(BaseModel):
    """Custom AI instructions — Anthropic-style 'What should the AI know about you?'

    These notes are prepended to every agent system prompt for the tenant.
    Limited to 2000 chars. Maps to settings type 'instructions' in storage.
    """

    tenant_id: str | None = None
    instructions: str = Field(default="", max_length=2000)


class VoiceSettings(BaseModel):
    """Per-tenant voice configuration.

    Controls voice agent identity, provider selection, guardrails,
    and tool bindings (email/calendar) for the tenant's voice AI agent.
    """

    tenant_id: str | None = None
    voice_agent_name: str = "Zara"
    voice_agent_company: str = ""  # Falls back to tenant company name
    voice_id: str = "ara"  # ara | zeus | provider-specific
    voice_provider_pstn: str = "xai"  # xai | gemini
    voice_provider_browser: str = "gemini"  # gemini | xai
    voice_provider_meeting: str = "gemini"  # gemini | xai
    voice_language_hints: list[str] = Field(default_factory=list)
    voice_max_concurrent: int = 5
    voice_max_duration_minutes: int = 60
    voice_spend_cap_daily_usd: float = 50.0
    voice_recording_consent: str = "required"  # required | optional | disabled
    voice_email: str = ""  # Assigned email for voice agent's email tool
    voice_calendar_id: str = ""  # Bound calendar for voice agent's calendar tool


class ContactSettings(BaseModel):
    """Contact information settings."""

    tenant_id: str | None = None
    business_phone: str = ""
    fallback_number: str = ""
    business_email: EmailStr | str = ""


class AISettings(BaseModel):
    """AI agent settings."""

    tenant_id: str | None = None
    ai_name: str = "Your AI Assistant"
    voice_style: str = "professional"
    language: str = "en-US"
    call_recording: bool = True
    recording_disclosure: str = ""
    transcription: bool = True
    llm_provider_priority: list[str] = Field(default_factory=lambda: ["moonshot", "grok"])
    llm_model_overrides: dict[str, str] = Field(default_factory=dict)
    llm_intent_model_overrides: dict[str, dict[str, str]] = Field(default_factory=dict)
    inference_primary_provider: str = BEDROCK_PROVIDER
    inference_fallback_provider: str = BEDROCK_PROVIDER
    inference_provider_order: list[str] = Field(default_factory=lambda: [BEDROCK_PROVIDER])
    inference_model_selections: dict[str, str] = Field(default_factory=default_model_selections)


class InferenceOAuthStartRequest(BaseModel):
    """Start an inference OAuth handshake.

    Issue #3507 — managed-SaaS deployments deny ``oauth_subscription`` by
    default per the upstream vendor's TOS (no pooling subscription tokens
    across tenants). Self-host deployments allow the flow but require
    ``consent=true`` so the caller explicitly attests to the personal-use
    restriction. ``consent_signature`` is a free-form attestation echoed
    back to the audit row.
    """

    redirect_uri: str
    consent: bool = False
    consent_signature: str | None = None


class InferenceOAuthCompleteRequest(BaseModel):
    """Finish an inference OAuth handshake."""

    code: str
    state: str


class InferenceProviderCredentialConnectRequest(BaseModel):
    """Connect or update a non-OAuth inference provider."""

    account_label: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)


class AnthropicInferenceConnectRequest(BaseModel):
    """Compatibility request shape for legacy Anthropic connect callers."""

    token: str
    credential_kind: Literal["auto", "api_key"] = "auto"
    account_label: str = ""


class BillingSettings(BaseModel):
    """Billing settings."""

    tenant_id: str | None = None
    billing_email: EmailStr | str = ""
    invoice_company: str = ""
    tax_id: str = ""
    payment_method: str = ""


class LearningSettings(BaseModel):
    """Learning and personalization settings."""

    tenant_id: str | None = None
    learning_agility: Literal["conservative", "moderate", "aggressive"] = "moderate"
    adaptation_mode: Literal["manual_review", "recommend_reversible", "auto_reversible"] = "recommend_reversible"
    confirmation_mode: Literal["strict", "balanced", "light"] = "balanced"
    proactive_learning_enabled: bool = True
    signal_horizon: Literal["ephemeral", "seasonal", "durable"] = "seasonal"
    drift_sensitivity: Literal["high", "medium", "low"] = "medium"
    no_train: bool = True


class LearningAuditItem(BaseModel):
    """One visible learning artifact for Settings."""

    kind: str
    title: str
    detail: str | None = None
    status: str | None = None
    timestamp: str | None = None
    href: str | None = None
    badges: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class LearningAuditCounts(BaseModel):
    """High-signal learning counts shown in Settings."""

    facts_learned: int = 0
    patterns_strengthened: int = 0
    review_queue: int = 0
    behavior_changes: int = 0


class LearningWeeklyReportSummary(BaseModel):
    """Condensed tenant improvement summary for the Settings card."""

    summary: str = ""
    avg_success_rate: float = 0.0
    total_capabilities: int = 0
    underperforming_count: int = 0


class LearningAuditSummary(BaseModel):
    """Visible learning and improvement summary for Settings."""

    tenant_id: str
    summary: str
    counts: LearningAuditCounts = Field(default_factory=LearningAuditCounts)
    recent_facts: list[LearningAuditItem] = Field(default_factory=list)
    recent_patterns: list[LearningAuditItem] = Field(default_factory=list)
    review_queue_items: list[LearningAuditItem] = Field(default_factory=list)
    recent_changes: list[LearningAuditItem] = Field(default_factory=list)
    capability_watchlist: list[LearningAuditItem] = Field(default_factory=list)
    weekly_report: LearningWeeklyReportSummary = Field(default_factory=LearningWeeklyReportSummary)


class MeetingConsentArtifactSummary(BaseModel):
    """Recent meeting consent artifact summary."""

    consent_id: str
    consent_type: str
    channel: str
    session_id: str | None = None
    consented_by: str | None = None
    consented_at: str
    consent_method: str | None = None
    announcement_language: str | None = None
    participants_notified: list[str] = Field(default_factory=list)
    participants_notified_count: int = 0
    recording_enabled: bool = False
    revoked_at: str | None = None
    revoked_by: str | None = None
    revocation_reason: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    schema_version: str | None = None


class MeetingConsentPolicySettings(BaseModel):
    """Fail-closed meeting consent policy contract."""

    explicit_consent_required: bool = True
    participant_notification_required_for_recording: bool = True
    recording_enabled_default: bool = True
    fail_closed: bool = True
    consent_type: str = "meeting_join_recording"
    consent_channel: str = "voice_api"
    default_consent_method: str = "host_pre_authorization"
    policy_errors: list[str] = Field(default_factory=list)


class MeetingProviderStatusSettings(BaseModel):
    """Meeting-runtime provider readiness surfaced in Settings."""

    provider: str
    state: str
    missing_credentials: list[str] = Field(default_factory=list)
    last_error: str | None = None


class MeetingFallbackOptionSettings(BaseModel):
    """One blocked-join fallback option rendered in Settings."""

    mode: str
    label: str
    description: str
    available: bool
    endpoint: str | None = None
    href: str | None = None
    reason_code: str | None = None


class MeetingFallbackCaptureSettings(BaseModel):
    """Canonical blocked-join fallback contract for product surfaces."""

    capture_ready: bool = False
    recommended_order: list[str] = Field(default_factory=list)
    supporting_surface: str | None = None
    options: list[MeetingFallbackOptionSettings] = Field(default_factory=list)


class MeetingConsentSettings(BaseModel):
    """Read-only meeting consent posture for Mission and CLI surfaces."""

    tenant_id: str
    policy: MeetingConsentPolicySettings
    recent_consents: list[MeetingConsentArtifactSummary] = Field(default_factory=list)
    recent_consents_available: bool = True
    recent_consents_error: str | None = None
    providers: list[MeetingProviderStatusSettings] = Field(default_factory=list)
    fallback_capture: MeetingFallbackCaptureSettings = Field(default_factory=MeetingFallbackCaptureSettings)


class SettingsDashboardBundleResponse(BaseModel):
    """Bounded first-viewport Settings read model."""

    learning: LearningSettings | None = None
    learning_audit: LearningAuditSummary | None = None
    meeting_consent: MeetingConsentSettings | None = None
    connection_center: dict[str, Any] | None = None
    connector_health: dict[str, Any] | None = None
    degraded: list[str] = Field(default_factory=list)


def _jsonable_settings_bundle_part(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    return value


class ApiKeyResponse(BaseModel):
    """Response when creating a new API key."""

    key_id: str
    api_key: str  # Only shown once during creation
    created_at: str
    tenant_id: str


class ApiKeyListItem(BaseModel):
    """API key list item (masked)."""

    key_id: str
    masked_key: str
    created_at: str
    last_used: str | None = None


class ApiKeyListResponse(BaseModel):
    """Response for listing API keys."""

    keys: list[ApiKeyListItem]
    total: int


class ApiKeyRevokeResponse(BaseModel):
    """Response when revoking an API key."""

    success: bool
    key_id: str


def _get_tenants_table():
    """Get DynamoDB table for tenant-scoped settings and API keys."""
    try:
        return get_shared_tenants_table()
    except (BotoCoreError, ClientError, ConnectionError, ValueError) as exc:
        raise SettingsStorageError("settings_table_unavailable") from exc


def _build_learning_audit_service():
    """Build the canonical Settings learning-audit aggregator."""
    from apps.backend.services.learning.learning_audit_service import LearningAuditService

    return LearningAuditService()


def _hash_api_key(raw_key: str) -> str:
    """SHA-256 hash of the raw API key for secure storage and lookup."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _table_key_names(table: Any) -> tuple[str, str]:
    """Resolve hash/range key names from DynamoDB key schema."""
    key_schema = getattr(table, "key_schema", None) or []
    hash_key = None
    range_key = None
    for entry in key_schema:
        key_type = entry.get("KeyType")
        attr_name = entry.get("AttributeName")
        if key_type == "HASH":
            hash_key = attr_name
        elif key_type == "RANGE":
            range_key = attr_name

    return (hash_key or "PK", range_key or "SK")


def _tenant_partition_key(tenant_id: str) -> str:
    """Build canonical partition key: TENANT#<tenant_id>."""
    return tenant_id if tenant_id.startswith("TENANT#") else f"TENANT#{tenant_id}"


def _setting_sort_key(setting_type: str) -> str:
    """Build canonical sort key: SETTING#<setting_type>."""
    return f"SETTING#{setting_type}"


def _extract_setting_payload(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a DynamoDB setting record into a settings payload."""
    if isinstance(item.get("data"), dict):
        return item["data"]

    reserved_keys = {"PK", "SK", "pk", "sk", "tenant_id", "setting_type", "updated_at"}
    return {k: v for k, v in item.items() if k not in reserved_keys}


def _get_settings(tenant_id: str, setting_type: str, defaults: dict) -> dict:
    """Retrieve settings from DynamoDB (fail-closed: no in-memory fallback)."""
    try:
        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)
        response = table.get_item(
            Key={
                hash_key_name: _tenant_partition_key(tenant_id),
                range_key_name: _setting_sort_key(setting_type),
            }
        )
        item = response.get("Item")
        stored = _extract_setting_payload(item) if item else {}
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error(
            "DynamoDB read failed for settings tenant=%s type=%s: %s",
            tenant_id,
            setting_type,
            e,
        )
        raise SettingsStorageError(f"settings_read_unavailable tenant={tenant_id} type={setting_type}") from e

    return {**defaults, **stored, "tenant_id": tenant_id}


def _save_settings(tenant_id: str, setting_type: str, data: dict) -> dict:
    """Save settings to DynamoDB (fail-closed: no in-memory fallback)."""
    payload = dict(data)
    payload["updated_at"] = datetime.now(UTC).isoformat()

    try:
        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)
        table.put_item(
            Item={
                hash_key_name: _tenant_partition_key(tenant_id),
                range_key_name: _setting_sort_key(setting_type),
                "tenant_id": tenant_id,
                "setting_type": setting_type,
                "updated_at": payload["updated_at"],
                "data": payload,
            }
        )
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error(
            "DynamoDB write failed for settings tenant=%s type=%s: %s",
            tenant_id,
            setting_type,
            e,
        )
        raise SettingsStorageError(f"settings_write_unavailable tenant={tenant_id} type={setting_type}") from e

    return payload


def _default_ai_settings(tenant_id: str) -> dict[str, Any]:
    defaults = AISettings(tenant_id=tenant_id).model_dump()
    defaults["inference_model_selections"] = default_model_selections()
    return defaults


def _merge_hidden_ai_settings(stored: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    return _merge_hidden_ai_settings_impl(stored, payload)


def _normalize_ai_settings_payload(payload: dict[str, Any], stored: dict[str, Any] | None = None) -> dict[str, Any]:
    return _normalize_ai_settings_payload_impl(payload, stored=stored)


def _generate_api_key() -> str:
    """Generate a secure API key."""
    # Format: ww_sk_<32 random hex chars>
    random_part = secrets.token_hex(16)
    return f"ww_sk_{random_part}"


def _mask_api_key(api_key: str) -> str:
    """Mask API key for display (show first 10 chars + ***)."""
    if len(api_key) <= 10:
        return "***"
    return f"{api_key[:10]}***"


# Profile Settings Endpoints


@router.get("/profile", response_model=ProfileSettings)
async def get_profile_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> ProfileSettings:
    """Get user profile settings."""
    try:
        defaults = ProfileSettings(tenant_id=tenant_id, user_id=user_id).model_dump()
        settings = _get_settings(tenant_id, f"profile#{user_id}", defaults)
        settings["user_id"] = user_id
        return ProfileSettings(**settings)
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (profile read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        logger.error(f"Failed to get profile settings (validation): {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=safe_error_detail(e),
        )
    except Exception as e:
        logger.error(f"Failed to get profile settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get profile settings",
        )


@router.put("/profile", response_model=ProfileSettings)
async def update_profile_settings(
    profile: ProfileSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> ProfileSettings:
    """Update user profile settings."""
    try:
        data = profile.model_dump(exclude={"tenant_id", "user_id"})
        _save_settings(tenant_id, f"profile#{user_id}", data)

        return ProfileSettings(**{**data, "tenant_id": tenant_id, "user_id": user_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (profile write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        logger.error(f"Failed to update profile settings (validation): {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=safe_error_detail(e),
        )
    except Exception as e:
        logger.error(f"Failed to update profile settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update profile settings",
        )


# Company Settings Endpoints


@router.get("/company", response_model=CompanySettings)
async def get_company_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CompanySettings:
    """Get company settings."""
    try:
        defaults = CompanySettings(tenant_id=tenant_id).model_dump()
        settings = _get_settings(tenant_id, "company", defaults)
        return CompanySettings(**settings)
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (company read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get company settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get company settings",
        )


@router.put("/company", response_model=CompanySettings)
async def update_company_settings(
    company: CompanySettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CompanySettings:
    """Update company settings."""
    try:
        data = company.model_dump(exclude={"tenant_id"})
        _save_settings(tenant_id, "company", data)

        return CompanySettings(**{**data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (company write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update company settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update company settings",
        )


# Custom AI Instructions Endpoints (T5 of Settings IA redesign)
# "What should Workweaver know about you?" — Anthropic-style.
# Stored as a separate settings type so we can rev the schema independently.


@router.get("/instructions", response_model=InstructionsSettings)
async def get_instructions_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstructionsSettings:
    """Get custom AI instructions for the tenant."""
    try:
        defaults = InstructionsSettings(tenant_id=tenant_id).model_dump()
        settings = _get_settings(tenant_id, "instructions", defaults)
        return InstructionsSettings(**{**defaults, **settings, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (instructions read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get instructions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get instructions",
        )


@router.put("/instructions", response_model=InstructionsSettings)
async def update_instructions_settings(
    payload: InstructionsSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstructionsSettings:
    """Update custom AI instructions for the tenant.

    Stored verbatim. Maximum length enforced by Pydantic (2000 chars).
    The next agent run will pick up the new instructions automatically
    via prompt assembly in apps/backend/services/agent_runtime.
    """
    try:
        data = payload.model_dump(exclude={"tenant_id"})
        # Defensive trim — Pydantic already enforces max_length but we want
        # to strip leading/trailing whitespace before persistence
        if data.get("instructions"):
            data["instructions"] = data["instructions"].strip()
        _save_settings(tenant_id, "instructions", data)
        return InstructionsSettings(**{**data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (instructions write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update instructions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update instructions",
        )


# Voice Settings Endpoints


@router.get("/voice", response_model=VoiceSettings)
async def get_voice_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> VoiceSettings:
    """Get voice configuration settings."""
    try:
        defaults = VoiceSettings(tenant_id=tenant_id).model_dump()
        settings = _get_settings(tenant_id, "voice", defaults)
        return VoiceSettings(**settings)
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (voice read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get voice settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get voice settings",
        )


@router.put("/voice", response_model=VoiceSettings)
async def update_voice_settings(
    voice: VoiceSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> VoiceSettings:
    """Update voice configuration settings."""
    try:
        data = voice.model_dump(exclude={"tenant_id"})
        _save_settings(tenant_id, "voice", data)
        return VoiceSettings(**{**data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (voice write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update voice settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update voice settings",
        )


# Contact Settings Endpoints


@router.get("/contact", response_model=ContactSettings)
async def get_contact_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ContactSettings:
    """Get contact settings."""
    try:
        defaults = ContactSettings(tenant_id=tenant_id).model_dump()
        settings = _get_settings(tenant_id, "contact", defaults)
        return ContactSettings(**settings)
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (contact read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get contact settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get contact settings",
        )


@router.put("/contact", response_model=ContactSettings)
async def update_contact_settings(
    contact: ContactSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ContactSettings:
    """Update contact settings."""
    try:
        data = contact.model_dump(exclude={"tenant_id"})
        _save_settings(tenant_id, "contact", data)

        return ContactSettings(**{**data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (contact write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update contact settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update contact settings",
        )


# AI Settings Endpoints


@router.get("/ai", response_model=AISettings)
async def get_ai_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AISettings:
    """Get AI agent settings."""
    try:
        defaults = _default_ai_settings(tenant_id)
        settings = _get_settings(tenant_id, "ai", defaults)
        normalized = _normalize_ai_settings_payload(settings, stored=settings)
        return AISettings(**{**defaults, **normalized, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (ai read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get AI settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get AI settings",
        )


@router.put("/ai", response_model=AISettings)
async def update_ai_settings(
    ai: AISettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AISettings:
    """Update AI agent settings."""
    try:
        defaults = _default_ai_settings(tenant_id)
        stored = _get_settings(tenant_id, "ai", defaults)
        data = _normalize_ai_settings_payload(ai.model_dump(exclude={"tenant_id"}), stored=stored)
        persisted = _merge_hidden_ai_settings(stored, data)
        _save_settings(tenant_id, "ai", persisted)

        return AISettings(**{**defaults, **data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (ai write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update AI settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update AI settings",
        )


@router.get("/ai/inference/catalog", response_model=dict[str, Any])
async def get_ai_inference_catalog() -> dict[str, Any]:
    """Expose supported inference providers and curated model choices."""
    return get_inference_catalog()


@router.get("/ai/inference/status", response_model=dict[str, Any])
async def get_ai_inference_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return public connection state for inference providers."""
    try:
        return get_inference_auth_service().get_public_provider_status(tenant_id)
    except InferenceAuthError as exc:
        logger.error("Failed to load inference provider status for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="inference_status_unavailable")


@router.post("/ai/inference/openai/start", response_model=dict[str, Any])
async def start_openai_inference_oauth(
    request: InferenceOAuthStartRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """Start the OpenAI Codex OAuth flow for the current tenant.

    Issue #3507: ``InferencePolicyError`` (managed SaaS denial) maps to 403
    with a ``policy_denied`` reason; ``InferenceConsentError`` (self-host
    consent missing) maps to 400 with a ``consent_required`` reason; other
    auth failures preserve the existing 400 contract.
    """
    # CVE-2026-32025 (#3184): validate redirect_uri against allowlist.
    from apps.backend.api.dependencies.redirect_validation import validate_redirect_url
    validated_redirect = validate_redirect_url(request.redirect_uri, tenant_id=tenant_id)

    try:
        return await get_inference_auth_service().start_openai_oauth(
            tenant_id=tenant_id,
            user_id=user_id,
            redirect_uri=validated_redirect,
            consent=bool(request.consent),
            consent_signature=request.consent_signature,
        )
    except InferencePolicyError as exc:
        logger.warning(
            "Subscription OAuth denied by deployment-profile TOS gate "
            "tenant=%s user=%s reason=%s",
            tenant_id,
            user_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"reason": "policy_denied", "message": safe_error_detail(exc)},
        )
    except InferenceConsentError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "consent_required", "message": safe_error_detail(exc)},
        )
    except InferenceAuthError as exc:
        logger.error("Failed to start OpenAI inference OAuth for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.post("/ai/inference/openai/complete", response_model=dict[str, Any])
async def complete_openai_inference_oauth(
    request: InferenceOAuthCompleteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """Complete the OpenAI Codex OAuth flow and persist tenant credentials."""
    try:
        return await get_inference_auth_service().complete_openai_oauth(
            tenant_id=tenant_id,
            user_id=user_id,
            code=request.code,
            state=request.state,
        )
    except InferenceStateError as exc:
        logger.error("OpenAI inference OAuth state rejected for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))
    except InferenceAuthError as exc:
        logger.error("Failed to complete OpenAI inference OAuth for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.post("/ai/inference/providers/{provider}/connect", response_model=dict[str, Any])
async def connect_inference_provider(
    provider: str,
    request: InferenceProviderCredentialConnectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Connect or update a BYOI inference provider."""
    normalized_provider = normalize_provider_name(provider)
    if normalized_provider not in {
        *OPENAI_COMPATIBLE_PROVIDER_IDS,
        ANTHROPIC_PROVIDER,
        BEDROCK_PROVIDER,
    }:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="unsupported_provider")
    try:
        return await get_inference_auth_service().connect_provider(
            tenant_id=tenant_id,
            provider=normalized_provider,
            payload=request.payload,
            account_label=request.account_label,
        )
    except InferenceAuthError as exc:
        logger.error("Failed to connect inference provider %s for %s: %s", provider, tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.post("/ai/inference/anthropic/connect", response_model=dict[str, Any])
async def connect_anthropic_inference_compat(
    request: AnthropicInferenceConnectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Backward-compatible Anthropic connect alias."""
    try:
        return await get_inference_auth_service().connect_anthropic_token(
            tenant_id=tenant_id,
            token=request.token,
            credential_kind=request.credential_kind,
            account_label=request.account_label,
        )
    except InferenceAuthError as exc:
        logger.error("Failed to connect Claude inference for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.delete("/ai/inference/providers/{provider}", response_model=dict[str, Any])
async def disconnect_inference_provider(
    provider: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Disconnect an inference provider for the current tenant.

    Note: this endpoint operates on legacy ``catalog``-kind connections
    where the ``provider`` path parameter is the canonical catalog id. For
    free-form ``TenantProviderProfile`` rows (Issue #3509), use
    ``DELETE /ai/inference/provider-profiles/{provider_instance_id}``.
    """
    normalized_provider = normalize_provider_name(provider)
    if normalized_provider not in SUPPORTED_PROVIDER_IDS:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="unsupported_provider")
    try:
        return get_inference_auth_service().disconnect_provider(tenant_id, normalized_provider)
    except InferenceAuthError as exc:
        logger.error("Failed to disconnect inference provider %s for %s: %s", provider, tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


# ---------------------------------------------------------------------------
# Issue #3513 — generic subscription-OAuth dispatcher
# ---------------------------------------------------------------------------
#
# One route family covers OpenAI Codex, Anthropic Claude Pro/Max, GitHub
# Copilot device flow, and Google Gemini PKCE. The provider path segment
# accepts a short alias (``openai`` / ``anthropic`` / ``copilot`` /
# ``gemini``) which ``normalize_provider_name`` resolves to the canonical
# id (``openai`` / ``anthropic_claude_oauth`` / ``github_copilot`` /
# ``google_gemini_oauth``). Inputs to ``begin`` mirror the original
# OpenAI start payload so the existing ``InferenceOAuthStartRequest`` /
# ``InferenceOAuthCompleteRequest`` Pydantic models still apply.


class _ProviderOAuthBeginRequest(BaseModel):
    redirect_uri: str
    consent: bool = False
    consent_signature: str | None = None


class _ProviderOAuthCompleteRequest(BaseModel):
    code: str = ""
    state: str = ""
    device_code: str = ""


def _resolve_oauth_provider_id(provider: str) -> str:
    normalized = normalize_provider_name(provider)
    if normalized not in SUBSCRIPTION_OAUTH_PROVIDER_IDS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "reason": "unsupported_oauth_provider",
                "message": (
                    f"{provider!r} is not a subscription OAuth provider. "
                    f"Supported: {sorted(SUBSCRIPTION_OAUTH_PROVIDER_IDS)}"
                ),
            },
        )
    return normalized


@router.post(
    "/ai/inference/oauth/{provider}/start",
    response_model=dict[str, Any],
)
async def start_subscription_oauth(
    provider: str,
    request: _ProviderOAuthBeginRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """Begin a subscription OAuth flow (Issue #3513).

    PKCE drivers (openai / anthropic / gemini) return ``authorization_url``
    + ``state``. Device-flow drivers (copilot) return ``user_code`` +
    ``verification_uri``.
    """
    normalized = _resolve_oauth_provider_id(provider)
    # CVE-2026-32025 (#3184): validate redirect_uri against allowlist.
    from apps.backend.api.dependencies.redirect_validation import validate_redirect_url
    validated_redirect = validate_redirect_url(request.redirect_uri, tenant_id=tenant_id)
    try:
        return await begin_provider_oauth(
            provider_id=normalized,
            tenant_id=tenant_id,
            user_id=user_id,
            redirect_uri=validated_redirect,
            consent=bool(request.consent),
            consent_signature=request.consent_signature,
        )
    except InferencePolicyError as exc:
        logger.warning(
            "Subscription OAuth denied tenant=%s provider=%s reason=%s",
            tenant_id, normalized, exc,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"reason": "policy_denied", "message": safe_error_detail(exc)},
        )
    except InferenceConsentError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "consent_required", "message": safe_error_detail(exc)},
        )
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "no_driver", "message": str(exc)},
        )
    except InferenceAuthError as exc:
        logger.error(
            "subscription_oauth.start_failed provider=%s tenant=%s error=%s",
            normalized, tenant_id, exc,
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.post(
    "/ai/inference/oauth/{provider}/complete",
    response_model=dict[str, Any],
)
async def complete_subscription_oauth(
    provider: str,
    request: _ProviderOAuthCompleteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """Finish a subscription OAuth flow (Issue #3513)."""
    normalized = _resolve_oauth_provider_id(provider)
    try:
        return await complete_provider_oauth(
            provider_id=normalized,
            tenant_id=tenant_id,
            user_id=user_id,
            code=request.code,
            state=request.state,
            device_code=request.device_code,
        )
    except InferenceStateError as exc:
        logger.error(
            "subscription_oauth.state_rejected provider=%s tenant=%s error=%s",
            normalized, tenant_id, exc,
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "no_driver", "message": str(exc)},
        )
    except InferenceAuthError as exc:
        logger.error(
            "subscription_oauth.complete_failed provider=%s tenant=%s error=%s",
            normalized, tenant_id, exc,
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.post(
    "/ai/inference/oauth/{provider}/refresh",
    response_model=dict[str, Any],
)
async def refresh_subscription_oauth(
    provider: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Force a refresh attempt (Issue #3513).

    Drivers that don't carry a refresh token simply return the current
    status; refresh-revoked failures wipe the credential and emit
    ``oauth.refresh_revoked`` audit events.
    """
    normalized = _resolve_oauth_provider_id(provider)
    try:
        return await refresh_provider_oauth(provider_id=normalized, tenant_id=tenant_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "no_driver", "message": str(exc)},
        )
    except InferenceAuthError as exc:
        logger.error(
            "subscription_oauth.refresh_failed provider=%s tenant=%s error=%s",
            normalized, tenant_id, exc,
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.get(
    "/ai/inference/oauth/{provider}/status",
    response_model=dict[str, Any],
)
async def status_subscription_oauth(
    provider: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the public provider-status row (Issue #3513)."""
    normalized = _resolve_oauth_provider_id(provider)
    try:
        return status_provider_oauth(provider_id=normalized, tenant_id=tenant_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "no_driver", "message": str(exc)},
        )
    except InferenceAuthError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


@router.delete(
    "/ai/inference/oauth/{provider}/disconnect",
    response_model=dict[str, Any],
)
async def disconnect_subscription_oauth(
    provider: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Wipe vault payload + meta row (Issue #3513)."""
    normalized = _resolve_oauth_provider_id(provider)
    try:
        return disconnect_provider_oauth(provider_id=normalized, tenant_id=tenant_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "no_driver", "message": str(exc)},
        )
    except InferenceAuthError as exc:
        logger.error(
            "subscription_oauth.disconnect_failed provider=%s tenant=%s error=%s",
            normalized, tenant_id, exc,
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(exc))


# ---------------------------------------------------------------------------
# Issue #3509 — durable tenant-scoped TenantProviderProfile (free-form custom)
# ---------------------------------------------------------------------------


class TenantProviderProfileAddRequest(BaseModel):
    """Body for ``POST /ai/inference/provider-profiles`` (Issue #3509).

    ``kind``-aware validation lives in ``TenantProviderProfileStore.add``:
    catalog kinds must carry ``provider_template_id``; ``custom_*`` /
    ``local_*`` / ``gateway`` kinds must carry ``base_url``. Bare ``api_key``
    is persisted to the vault as ``{"api_key": <value>}`` matching the
    existing BYOI convention.
    """

    provider_instance_id: str = Field(..., min_length=1, max_length=64)
    kind: str = Field(..., min_length=1, max_length=64)
    label: str | None = Field(default=None, max_length=200)
    base_url: str | None = Field(default=None, max_length=500)
    api_key: str | None = Field(default=None, max_length=8192)
    auth_method: str | None = Field(default=None, max_length=64)
    provider_template_id: str | None = Field(default=None, max_length=120)
    model: list[str] | str | None = Field(default=None)
    locality: str | None = Field(default=None, max_length=32)
    tos_policy: str | None = Field(default=None, max_length=64)
    cost_owner: str | None = Field(default=None, max_length=64)


class TenantProviderProfileUpdateRequest(BaseModel):
    """Body for ``PUT /ai/inference/provider-profiles/{provider_instance_id}``."""

    label: str | None = Field(default=None, max_length=200)
    base_url: str | None = Field(default=None, max_length=500)
    api_key: str | None = Field(default=None, max_length=8192)
    auth_method: str | None = Field(default=None, max_length=64)
    model: list[str] | str | None = Field(default=None)
    locality: str | None = Field(default=None, max_length=32)
    tos_policy: str | None = Field(default=None, max_length=64)
    cost_owner: str | None = Field(default=None, max_length=64)
    enabled: bool | None = None


def _coerce_model_list(raw: list[str] | str | None) -> list[str] | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        return [raw] if raw.strip() else []
    return list(raw)


@router.post("/ai/inference/provider-profiles", response_model=dict[str, Any])
async def add_provider_profile(
    request: TenantProviderProfileAddRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Create a durable tenant-scoped provider profile (Issue #3509).

    Replaces the pre-#3509 catalog-rejection gate with ``kind``-aware
    validation: legacy catalog kinds keep working unchanged, while
    ``custom_openai`` / ``custom_anthropic`` / ``oauth_subscription`` /
    ``local_openai`` / ``ollama_native`` / ``gateway`` are accepted as
    first-class profile kinds.
    """
    from apps.backend.services.inference.tenant_provider_profile import (  # noqa: PLC0415
        TenantProviderProfileAlreadyExistsError,
        TenantProviderProfileValidationError,
        get_tenant_provider_profile_store,
    )

    credentials: dict[str, Any] | None = None
    if request.api_key:
        credentials = {"api_key": request.api_key}
    try:
        profile = get_tenant_provider_profile_store().add(
            tenant_id=tenant_id,
            provider_instance_id=request.provider_instance_id,
            kind=request.kind,
            label=request.label or "",
            base_url=request.base_url,
            credentials=credentials,
            auth_method=request.auth_method or "api_key",
            provider_template_id=request.provider_template_id,
            model_allowlist=_coerce_model_list(request.model),
            locality=request.locality or "cloud",
            tos_policy=request.tos_policy or "open",
            cost_owner=request.cost_owner or "tenant_billing",
        )
    except TenantProviderProfileValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "validation_error", "message": safe_error_detail(exc)},
        )
    except TenantProviderProfileAlreadyExistsError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"reason": "duplicate_provider_instance_id", "message": safe_error_detail(exc)},
        )
    return profile.to_public_dict()


@router.get("/ai/inference/provider-profiles", response_model=dict[str, Any])
async def list_provider_profiles(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List every durable provider profile owned by the current tenant."""
    from apps.backend.services.inference.tenant_provider_profile import (  # noqa: PLC0415
        get_tenant_provider_profile_store,
    )

    profiles = get_tenant_provider_profile_store().list(tenant_id=tenant_id)
    return {"items": [p.to_public_dict() for p in profiles]}


@router.put(
    "/ai/inference/provider-profiles/{provider_instance_id}",
    response_model=dict[str, Any],
)
async def update_provider_profile(
    provider_instance_id: str,
    request: TenantProviderProfileUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update fields on an existing durable provider profile (Issue #3509)."""
    from apps.backend.services.inference.tenant_provider_profile import (  # noqa: PLC0415
        TenantProviderProfileNotFoundError,
        TenantProviderProfileValidationError,
        get_tenant_provider_profile_store,
    )

    credentials: dict[str, Any] | None = None
    if request.api_key:
        credentials = {"api_key": request.api_key}
    try:
        profile = get_tenant_provider_profile_store().update(
            tenant_id=tenant_id,
            provider_instance_id=provider_instance_id,
            label=request.label,
            base_url=request.base_url,
            credentials=credentials,
            auth_method=request.auth_method,
            model_allowlist=_coerce_model_list(request.model),
            locality=request.locality,
            tos_policy=request.tos_policy,
            cost_owner=request.cost_owner,
            enabled=request.enabled,
        )
    except TenantProviderProfileValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "validation_error", "message": safe_error_detail(exc)},
        )
    except TenantProviderProfileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"reason": "provider_profile_not_found", "message": safe_error_detail(exc)},
        )
    return profile.to_public_dict()


@router.delete(
    "/ai/inference/provider-profiles/{provider_instance_id}",
    response_model=dict[str, Any],
)
async def delete_provider_profile(
    provider_instance_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Delete a durable provider profile and revoke its vault credential."""
    from apps.backend.services.inference.tenant_provider_profile import (  # noqa: PLC0415
        TenantProviderProfileValidationError,
        get_tenant_provider_profile_store,
    )

    try:
        deleted = get_tenant_provider_profile_store().delete(
            tenant_id=tenant_id,
            provider_instance_id=provider_instance_id,
        )
    except TenantProviderProfileValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "validation_error", "message": safe_error_detail(exc)},
        )
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"reason": "provider_profile_not_found"},
        )
    return {"deleted": True, "provider_instance_id": provider_instance_id}


# Issue #3515 — portable_e2e credential export / import
class InferenceCredentialExportRequest(BaseModel):
    """Body for ``POST /ai/inference/credentials/export``.

    The passphrase is consumed inline to derive the Argon2id key; it is
    never persisted server-side. Strength is validated by
    ``validate_passphrase_strength``.
    """

    passphrase: str = Field(..., min_length=1, max_length=512)


class InferenceCredentialImportRequest(BaseModel):
    """Body for ``POST /ai/inference/credentials/import``.

    ``bundle`` is the JSON object returned by ``/credentials/export``; the
    passphrase must match the one used at export time.
    """

    passphrase: str = Field(..., min_length=1, max_length=512)
    bundle: dict[str, Any]


@router.post("/ai/inference/credentials/export", response_model=dict[str, Any])
async def export_inference_credentials(
    request: InferenceCredentialExportRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return a portable, passphrase-encrypted bundle of the tenant's
    inference credentials. Issue #3515.

    The passphrase is consumed inline (function arg) and discarded. The
    response body NEVER contains plaintext credentials — only a Fernet
    ciphertext sealed under an Argon2id-derived key.
    """
    from apps.backend.services.inference.credential_export import (  # noqa: PLC0415
        CredentialExportError,
        export_tenant_credentials,
    )
    from apps.backend.services.inference.portable_e2e_cipher import (  # noqa: PLC0415
        WeakPassphraseError,
    )

    try:
        return export_tenant_credentials(
            tenant_id=tenant_id,
            passphrase=request.passphrase,
            auth_service=get_inference_auth_service(),
        )
    except WeakPassphraseError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "weak_passphrase", "message": str(exc)},
        )
    except CredentialExportError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "export_failed", "message": str(exc)},
        )


@router.post("/ai/inference/credentials/import", response_model=dict[str, Any])
async def import_inference_credentials(
    request: InferenceCredentialImportRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Decrypt and persist a portable credential bundle into the current
    tenant's vault. Issue #3515."""
    from apps.backend.services.inference.credential_export import (  # noqa: PLC0415
        CredentialExportError,
        import_tenant_credentials,
    )

    try:
        return import_tenant_credentials(
            tenant_id=tenant_id,
            passphrase=request.passphrase,
            bundle=request.bundle,
            auth_service=get_inference_auth_service(),
        )
    except CredentialExportError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "import_failed", "message": str(exc)},
        )


# ---------------------------------------------------------------------------
# Issue #3512 — tenant-scoped routing override + fallback chain editor
# ---------------------------------------------------------------------------
#
# Tenants can read the founder-authored override for their workspace and
# adjust the per-capability-class ``fallback_chain`` within the founder's
# allowlist. Validation reuses ``_normalize_routing_payload`` so providers
# outside the platform allowlist are rejected at the same gate the founder
# UI uses; tenants cannot escalate their own permissions through this seam.


@router.get("/ai/inference/routing-override", response_model=dict[str, Any])
async def get_tenant_inference_routing_override(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return this tenant's routing override (read view).

    Returns an empty ``capability_classes`` map when no founder-authored
    override exists for the workspace; the panel falls back to platform
    defaults in that case.
    """
    from apps.backend.api.admin_inference import _get_resolver  # noqa: PLC0415

    resolver = _get_resolver()
    return resolver.get_tenant_routing_override(tenant_id)


@router.post("/ai/inference/routing-override", response_model=dict[str, Any])
async def set_tenant_inference_routing_override(
    request: dict[str, Any],
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Persist the tenant's routing override (fallback chain edits).

    The body uses the same ``PlatformRoutingRequest`` shape as the founder
    endpoint; ``_normalize_routing_payload`` enforces that every provider
    in ``primary`` / ``fallback_chain`` / ``provider_order`` is configured
    and enabled in the platform allowlist. Tenants therefore cannot reach
    providers the founder did not authorize.
    """
    from apps.backend.api.admin_inference import (  # noqa: PLC0415
        PlatformRoutingRequest,
        _get_resolver,
        _get_store,
        _normalize_routing_payload,
    )
    from apps.backend.services.inference.admin_resolver import (  # noqa: PLC0415
        get_cached_resolver,
    )
    from pydantic import ValidationError  # noqa: PLC0415

    try:
        body = PlatformRoutingRequest.model_validate(request)
    except ValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=safe_error_detail(exc),
        )

    resolver = _get_resolver()
    store = _get_store()
    normalized = _normalize_routing_payload(body=body, resolver=resolver, store=store)
    persisted = store.set_tenant_routing_override(
        tenant_id=tenant_id,
        capability_classes=normalized,
    )
    get_cached_resolver().invalidate()
    return {
        "tenant_id": str(persisted.get("tenant_id") or tenant_id),
        "source": "tenant_self_override",
        "updated_at": str(persisted.get("updated_at") or ""),
        "capability_classes": normalized,
    }


# Billing Settings Endpoints


@router.get("/billing", response_model=BillingSettings)
async def get_billing_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BillingSettings:
    """Get billing settings."""
    try:
        defaults = BillingSettings(tenant_id=tenant_id).model_dump()
        settings = _get_settings(tenant_id, "billing", defaults)
        return BillingSettings(**settings)
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (billing read): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to get billing settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get billing settings",
        )


@router.put("/billing", response_model=BillingSettings)
async def update_billing_settings(
    billing: BillingSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BillingSettings:
    """Update billing settings."""
    try:
        data = billing.model_dump(exclude={"tenant_id"})
        _save_settings(tenant_id, "billing", data)

        return BillingSettings(**{**data, "tenant_id": tenant_id})
    except SettingsStorageError as e:
        logger.error(f"Settings storage unavailable (billing write): {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=safe_error_detail(e))
    except Exception as e:
        logger.error(f"Failed to update billing settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update billing settings",
        )


@router.get("/learning", response_model=LearningSettings)
async def get_learning_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> LearningSettings:
    """Get canonical tenant learning controls backed by behavioral stops."""
    try:
        stops = _get_behavioral_stops(tenant_id)
        payload = {field: stops.get(field) for field in LEARNING_CONTROL_FIELDS}
        return LearningSettings(**payload, tenant_id=tenant_id)
    except BehavioralStopsStoreError as exc:
        logger.error("Learning settings storage unavailable: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as exc:
        logger.error("Settings validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get learning settings: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get learning settings",
        )


@router.put("/learning", response_model=LearningSettings)
async def update_learning_settings(
    learning: LearningSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> LearningSettings:
    """Update canonical tenant learning controls without creating a second store."""
    try:
        stops = _get_behavioral_stops(tenant_id)
        before = {field: stops.get(field) for field in LEARNING_CONTROL_FIELDS}

        updates = learning.model_dump(exclude={"tenant_id"})
        for field in LEARNING_CONTROL_FIELDS:
            stops[field] = updates[field]

        _save_behavioral_stops(tenant_id, stops)
        _emit_evidence_receipt(
            tenant_id=tenant_id,
            action="learning_settings_updated",
            before=before,
            after={field: stops.get(field) for field in LEARNING_CONTROL_FIELDS},
        )

        return LearningSettings(**{field: stops.get(field) for field in LEARNING_CONTROL_FIELDS}, tenant_id=tenant_id)
    except BehavioralStopsStoreError as exc:
        logger.error("Learning settings storage unavailable: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as exc:
        logger.error("Settings validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to update learning settings: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update learning settings",
        )


@router.get("/learning/audit", response_model=LearningAuditSummary)
async def get_learning_audit_summary(
    tenant_id: str = Depends(get_verified_tenant_id),
    service: Any = Depends(_build_learning_audit_service),
) -> LearningAuditSummary:
    """Return the canonical visible learning summary for Settings."""
    try:
        payload = service.build_summary(tenant_id)
        return LearningAuditSummary(**payload)
    except HTTPException:
        raise
    except BehavioralStopsStoreError as exc:
        logger.error("Learning audit storage unavailable: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (ValueError, KeyError, TypeError) as exc:
        logger.error("Learning audit validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get learning audit summary: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get learning audit summary",
        )


class NoTrainPolicyProof(BaseModel):
    """Auditable proof of the tenant's no_train policy enforcement.

    docs/PRODUCT.md §No shared-model training bar:
    "Make this a top-level Settings policy with auditable proofs and a published invariant."
    """

    tenant_id: str
    no_train_enabled: bool = True
    policy_statement: str = "Your data trains your agents. Nobody else's."
    enforcement_points: list[str] = Field(
        default_factory=lambda: [
            "WorkMemory X-No-Train header on all ingest calls",
            "Learning loop governance checks no_train before pattern promotion",
            "Memory consolidation respects tenant isolation boundary",
            "Cross-tenant model sharing is structurally impossible (no shared embedding space)",
        ]
    )
    last_verified_at: str = ""
    evidence_trail: list[dict[str, Any]] = Field(default_factory=list)


@router.get("/learning/no-train-proof", response_model=NoTrainPolicyProof)
async def get_no_train_proof(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> NoTrainPolicyProof:
    """Return auditable proof of the no_train policy enforcement.

    Provides evidence that the tenant's data is not used to train shared models.
    This is the published invariant required by the No Shared-Model Training bar.
    """
    try:
        settings = await get_learning_settings(tenant_id=tenant_id)
        evidence: list[dict[str, Any]] = []
        if settings.no_train:
            evidence.append(
                {
                    "type": "policy_active",
                    "detail": "no_train=True in tenant learning settings",
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )
        evidence.append(
            {
                "type": "structural_guarantee",
                "detail": "WorkMemory uses per-tenant vector namespaces; no shared embedding space exists",
                "timestamp": datetime.now(UTC).isoformat(),
            }
        )
        return NoTrainPolicyProof(
            tenant_id=tenant_id,
            no_train_enabled=settings.no_train,
            last_verified_at=datetime.now(UTC).isoformat(),
            evidence_trail=evidence,
        )
    except Exception:
        return NoTrainPolicyProof(
            tenant_id=tenant_id,
            last_verified_at=datetime.now(UTC).isoformat(),
        )


@router.get("/meetings/consent", response_model=MeetingConsentSettings)
async def get_meeting_consent_settings(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MeetingConsentSettings:
    """Return the fail-closed meeting consent policy and recent artifacts."""
    try:
        summary = get_meeting_consent_policy_summary(tenant_id)
        return MeetingConsentSettings(
            tenant_id=str(summary.get("tenant_id") or tenant_id),
            policy=MeetingConsentPolicySettings(**dict(summary.get("policy") or {})),
            recent_consents=[
                MeetingConsentArtifactSummary(**dict(item)) for item in list(summary.get("recent_consents") or [])
            ],
            recent_consents_available=bool(summary.get("recent_consents_available", True)),
            recent_consents_error=summary.get("recent_consents_error"),
            providers=[
                MeetingProviderStatusSettings(
                    provider=str(provider),
                    **dict(payload or {}),
                )
                for provider, payload in dict(summary.get("providers") or {}).items()
            ],
            fallback_capture=MeetingFallbackCaptureSettings(**dict(summary.get("fallback_capture") or {})),
        )
    except HTTPException:
        raise
    except (ValueError, KeyError, TypeError) as exc:
        logger.error("Invalid meeting consent summary payload: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get meeting consent settings: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get meeting consent settings",
        )


async def _settings_bundle_part(name: str, func: Any) -> tuple[str, Any, str | None]:
    try:
        return name, await func(), None
    except HTTPException as exc:
        return name, None, str(exc.detail or exc.status_code)
    except Exception as exc:
        logger.warning("Settings dashboard bundle degraded loading %s: %s", name, exc, exc_info=True)
        return name, None, name


@router.get("/dashboard-bundle", response_model=SettingsDashboardBundleResponse)
async def get_settings_dashboard_bundle(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SettingsDashboardBundleResponse:
    """Return Settings first-viewport state through one bounded request."""
    from apps.backend.api.connectors.routes_catalog import get_connection_center, list_connector_health

    connector_health_page = PaginationParams(limit=8, offset=0, page=1, page_size=8)
    learning_audit_service = _build_learning_audit_service()
    parts = await asyncio.gather(
        _settings_bundle_part("learning", lambda: get_learning_settings(tenant_id=tenant_id)),
        _settings_bundle_part(
            "learning_audit",
            lambda: get_learning_audit_summary(tenant_id=tenant_id, service=learning_audit_service),
        ),
        _settings_bundle_part("meeting_consent", lambda: get_meeting_consent_settings(tenant_id=tenant_id)),
        _settings_bundle_part("connection_center", lambda: get_connection_center(tenant_id=tenant_id)),
        _settings_bundle_part(
            "connector_health",
            lambda: list_connector_health(tenant_id=tenant_id, pagination=connector_health_page),
        ),
    )

    payload: dict[str, Any] = {}
    degraded: list[str] = []
    for name, value, error in parts:
        payload[name] = _jsonable_settings_bundle_part(value)
        if error:
            degraded.append(name)
    return SettingsDashboardBundleResponse(**payload, degraded=degraded)


# API Key Management Endpoints


@router.post("/api-keys", response_model=ApiKeyResponse)
async def generate_api_key(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> ApiKeyResponse:
    """Generate a new API key for the tenant.

    Dual-write pattern to DynamoDB:
    1. APIKEY#<sha256_hash> / META -> for O(1) lookup by plugin_auth
    2. TENANT#<tenant_id> / APIKEY#<key_id> -> for listing keys per tenant
    """
    try:
        key_id = secrets.token_hex(8)
        api_key = _generate_api_key()
        created_at = datetime.now(UTC).isoformat()
        key_hash = _hash_api_key(api_key)

        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)

        # Record 1: APIKEY# for O(1) lookup by hash
        table.put_item(
            Item={
                hash_key_name: f"APIKEY#{key_hash}",
                range_key_name: "META",
                "tenant_id": tenant_id,
                "key_id": key_id,
                "user_id": user_id,
                "created_at": created_at,
                "last_used": None,
            }
        )

        # Record 2: TENANT# for listing keys per tenant
        table.put_item(
            Item={
                hash_key_name: _tenant_partition_key(tenant_id),
                range_key_name: f"APIKEY#{key_id}",
                "key_id": key_id,
                "key_hash": key_hash,
                "masked_key": _mask_api_key(api_key),
                "user_id": user_id,
                "created_at": created_at,
                "last_used": None,
            }
        )

        logger.info("Generated API key %s for tenant %s", key_id, tenant_id)

        return ApiKeyResponse(
            key_id=key_id,
            api_key=api_key,
            created_at=created_at,
            tenant_id=tenant_id,
        )
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable generating API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error("DynamoDB write failed generating API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to generate API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate API key",
        )


@router.get("/api-keys", response_model=ApiKeyListResponse)
async def list_api_keys(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> ApiKeyListResponse:
    """List all API keys for the tenant (masked).

    Queries DynamoDB with PK=TENANT#<tenant_id> and SK begins_with APIKEY#.
    """
    try:
        from boto3.dynamodb.conditions import Key

        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)
        response = table.query(
            KeyConditionExpression=Key(hash_key_name).eq(_tenant_partition_key(tenant_id))
            & Key(range_key_name).begins_with("APIKEY#"),
        )

        keys = []
        for item in response.get("Items", []):
            keys.append(
                ApiKeyListItem(
                    key_id=item["key_id"],
                    masked_key=item.get("masked_key", "***"),
                    created_at=item["created_at"],
                    last_used=item.get("last_used"),
                )
            )

        paged_keys, total = paginate_items(keys, pagination)
        return ApiKeyListResponse(keys=paged_keys, total=total)
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable listing API keys: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error("DynamoDB query failed listing API keys: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to list API keys: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list API keys",
        )


@router.delete("/api-keys/{key_id}", response_model=ApiKeyRevokeResponse)
async def revoke_api_key(
    key_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ApiKeyRevokeResponse:
    """Revoke an API key.

    Dual-delete: removes both the APIKEY# lookup record and the TENANT# listing record.
    """
    try:
        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)

        # First, get the tenant record to find the key_hash for cross-reference
        tenant_record = table.get_item(
            Key={
                hash_key_name: _tenant_partition_key(tenant_id),
                range_key_name: f"APIKEY#{key_id}",
            },
        )
        item = tenant_record.get("Item")
        if not item:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="API key not found",
            )

        key_hash = item.get("key_hash", "")

        # Delete the APIKEY# lookup record
        if key_hash:
            table.delete_item(
                Key={
                    hash_key_name: f"APIKEY#{key_hash}",
                    range_key_name: "META",
                }
            )

        # Delete the TENANT# listing record
        table.delete_item(
            Key={
                hash_key_name: _tenant_partition_key(tenant_id),
                range_key_name: f"APIKEY#{key_id}",
            }
        )

        logger.info("Revoked API key %s for tenant %s", key_id, tenant_id)

        return ApiKeyRevokeResponse(success=True, key_id=key_id)
    except HTTPException:
        raise
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable revoking API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error("DynamoDB operation failed revoking API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to revoke API key: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to revoke API key",
        )


# ---------------------------------------------------------------------------
# Approval Gates (M8.7) — Per-tenant configurable approval gates
# ---------------------------------------------------------------------------

from apps.backend.services.interrupt_enforcer import (
    get_approval_gate_config_service,
)


_VALID_APPROVAL_LEVELS = {"required", "optional", "none"}


class ApprovalGateToolConfig(BaseModel):
    """Per-tool approval level: required | optional | none."""

    tools: dict[str, Literal["required", "optional", "none"]]
    default_policy: Literal["required", "optional", "none"] = "required"


class ApprovalGateResponse(BaseModel):
    """Merged approval gates config: defaults + tenant overrides."""

    default_policy: str
    tools: dict[str, str]


def _save_approval_gate_config(
    tenant_id: str,
    config: ApprovalGateToolConfig,
    user_id: str,
) -> None:
    """Save approval gate config to DynamoDB (tenants table, SK=APPROVAL_CONFIG)."""
    try:
        table = _get_tenants_table()
        hash_key_name, range_key_name = _table_key_names(table)
        pk = _tenant_partition_key(tenant_id)
        now = datetime.now(UTC).isoformat()

        table.put_item(
            Item={
                hash_key_name: pk,
                range_key_name: "APPROVAL_CONFIG",
                "approval_config": config.tools,
                "default_policy": config.default_policy,
                "updated_at": now,
                "updated_by": user_id,
            }
        )

        logger.info(
            "Approval gates updated: tenant=%s by=%s tools=%s default=%s",
            tenant_id,
            user_id,
            list(config.tools.keys()),
            config.default_policy,
        )
    except (BotoCoreError, ClientError, ConnectionError) as e:
        logger.error(
            "DynamoDB write failed for approval gates tenant=%s: %s",
            tenant_id,
            e,
        )
        raise SettingsStorageError(f"approval_gates_write_unavailable tenant={tenant_id}") from e


@router.get("/approval-gates", response_model=ApprovalGateResponse)
async def get_approval_gates(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ApprovalGateResponse:
    """Get current per-tool approval gates config (defaults + overrides)."""
    try:
        svc = get_approval_gate_config_service()
        merged = svc.get_merged_config(tenant_id)
        return ApprovalGateResponse(**merged)
    except (SettingsStorageError, BotoCoreError, ClientError) as e:
        logger.error("Approval gates storage unavailable: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to get approval gates: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get approval gates",
        )


@router.put("/approval-gates", response_model=ApprovalGateResponse)
async def update_approval_gates(
    config: ApprovalGateToolConfig,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> ApprovalGateResponse:
    """Update per-tool approval requirements (audit-logged).

    Changes take effect within 60s (cache TTL) for all active sessions.
    """
    try:
        _save_approval_gate_config(tenant_id, config, user_id)

        # Invalidate cache so the new config is picked up immediately
        svc = get_approval_gate_config_service()
        svc.invalidate_cache(tenant_id)

        # Return updated merged config
        merged = svc.get_merged_config(tenant_id)
        return ApprovalGateResponse(**merged)
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable (approval gates write): %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to update approval gates: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update approval gates",
        )


# ---------------------------------------------------------------------------
# Tenant Timezone Endpoints (PR-T1.3)
# ---------------------------------------------------------------------------


class TimezoneSettings(BaseModel):
    """Tenant-level timezone setting."""

    timezone: str = Field(default="UTC", description="IANA timezone name (e.g. 'America/New_York')")


def _validate_timezone(tz: str) -> str:
    """Validate an IANA timezone string. Returns the validated string or raises ValueError."""
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    tz = tz.strip()
    if not tz:
        raise ValueError("Timezone must not be empty")
    try:
        ZoneInfo(tz)
    except (ZoneInfoNotFoundError, KeyError) as exc:
        raise ValueError(f"Invalid timezone: {tz}") from exc
    return tz


@router.get("/timezone", response_model=TimezoneSettings)
async def get_timezone(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TimezoneSettings:
    """Get tenant timezone setting."""
    try:
        defaults = TimezoneSettings().model_dump()
        settings = _get_settings(tenant_id, "timezone", defaults)
        return TimezoneSettings(**{k: v for k, v in settings.items() if k in TimezoneSettings.model_fields})
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable (timezone read): %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to get timezone setting: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get timezone setting",
        )


@router.put("/timezone", response_model=TimezoneSettings)
async def update_timezone(
    body: TimezoneSettings,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TimezoneSettings:
    """Update tenant timezone setting. Validates against IANA timezone database."""
    try:
        validated_tz = _validate_timezone(body.timezone)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    try:
        _save_settings(tenant_id, "timezone", {"timezone": validated_tz})
        return TimezoneSettings(timezone=validated_tz)
    except SettingsStorageError as e:
        logger.error("Settings storage unavailable (timezone write): %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        )
    except Exception as e:
        logger.error("Failed to update timezone setting: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update timezone setting",
        )


def get_router() -> APIRouter:
    """Get the settings router."""
    return router


__all__ = [
    "router",
    "ProfileSettings",
    "CompanySettings",
    "VoiceSettings",
    "ContactSettings",
    "AISettings",
    "BillingSettings",
    "ApiKeyResponse",
    "ApiKeyListResponse",
    "ApiKeyRevokeResponse",
    "ApprovalGateToolConfig",
    "ApprovalGateResponse",
    "TimezoneSettings",
    "get_approval_gate_config_service",
    "_save_approval_gate_config",
    "_validate_timezone",
]
