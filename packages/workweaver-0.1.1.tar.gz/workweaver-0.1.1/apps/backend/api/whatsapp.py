"""
WhatsApp API Endpoints

Provides REST endpoints for Twilio WhatsApp webhooks and messaging:
- POST /api/whatsapp/webhook - Inbound WhatsApp message webhook
- POST /api/whatsapp/send - Send outbound WhatsApp message
- POST /api/whatsapp/status - Message status callback

These endpoints handle WhatsApp messaging using the same Twilio account
as voice calls, ensuring unified billing and simplified troubleshooting.
"""

import asyncio
import logging
import os
from datetime import datetime, UTC

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.channels.whatsapp.service import (
    WhatsAppMessage,
    WhatsAppMessageStatus,
    WhatsAppMessageType,
    get_whatsapp_capability_matrix,
    get_whatsapp_service,
)
from apps.backend.services.channels.whatsapp.handler import get_whatsapp_handler
from apps.backend.services.billing import MeteringService
from apps.backend.services.usage_tracker import UsageMetricType
from apps.backend.services.delivery_guard import (
    DeliveryRateLimitedError,
    get_delivery_guard,
)
from apps.backend.services.ambient_adapters.messages import notify_inbound_event
from apps.backend.services.suppression_guard import DeliverySuppressedError
from apps.backend.services.suppression_store import get_suppression_store


logger = logging.getLogger(__name__)

# ============================================================================
# Router
# ============================================================================

router = APIRouter()


def get_whatsapp_verified_tenant_id(request: Request) -> str:
    """Resolve and verify tenant context for protected WhatsApp endpoints."""
    from apps.backend.api.dependencies.tenant_auth import resolve_verified_tenant_id

    return resolve_verified_tenant_id(request)


def get_suppression_guard():
    """Compatibility shim for existing tests/tools patching this symbol."""
    from apps.backend.services.suppression_guard import get_suppression_guard as _get

    return _get()


def _resolve_tenant_from_phone(phone_number: str, correlation_id: str) -> str:
    """Resolve tenant_id from a Workweaver-owned phone number."""
    from apps.backend.middleware.grok_tenant_context import (
        GrokTenantContextMiddleware,
        TenantResolutionError,
    )

    try:
        middleware = GrokTenantContextMiddleware(enable_phone_lookup=True)
        context = middleware.resolve_from_twilio_phone(
            phone_number=phone_number,
            call_sid=correlation_id,
        )
        logger.info("Resolved tenant %s from phone %s", context.tenant_id, phone_number)
        return context.tenant_id
    except TenantResolutionError as exc:
        logger.warning("Could not resolve tenant from phone %s: %s", phone_number, exc)
        return "TENANT#DEFAULT"


async def _meter_whatsapp_message(
    *,
    tenant_id: str,
    metric: UsageMetricType,
    message_sid: str,
    metadata: dict,
) -> None:
    """Record WhatsApp message metering with stable idempotency keys."""

    async def _emit() -> None:
        await MeteringService().meter(
            tenant_id=tenant_id,
            metric=metric,
            quantity=1,
            unit="messages",
            idempotency_key=f"whatsapp:{metric.value}:{message_sid or 'unknown'}",
            metadata=metadata,
            fail_open=True,
        )

    task = asyncio.create_task(_emit(), name=f"meter-whatsapp-{metric.value}")

    def _log_failure(done_task: asyncio.Task) -> None:
        try:
            done_task.result()
        except Exception:
            logger.warning("whatsapp_metering_emit_failed tenant=%s metric=%s", tenant_id, metric.value, exc_info=True)

    task.add_done_callback(_log_failure)


# Comprehensive opt-out keywords — aligned with SMS (sms.py OPT_OUT_KEYWORDS) and Twilio STOP compliance.
STOP_KEYWORDS = frozenset({
    "STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT", "OPT OUT", "OPTOUT",
})


def _is_unsubscribe_keyword(body: str) -> bool:
    """Return True if inbound message is a recognized opt-out keyword."""
    keyword = str(body or "").strip().upper()
    return keyword in STOP_KEYWORDS


def _resolve_whatsapp_sender_ownership(
    *,
    sender_identity: str,
    authenticated_tenant_id: str,
    correlation_id: str,
) -> dict[str, str | bool]:
    """Resolve sender ownership and fail-closed on mismatches."""
    sender_tenant_id = _resolve_tenant_from_phone(
        phone_number=sender_identity,
        correlation_id=correlation_id,
    )
    owns_sender = bool(authenticated_tenant_id) and sender_tenant_id == authenticated_tenant_id
    return {
        "owned": owns_sender,
        "authenticated_tenant_id": authenticated_tenant_id,
        "resolved_sender_tenant_id": sender_tenant_id,
        "sender_identity": sender_identity,
    }


def _whatsapp_capability_response() -> "WhatsAppCapabilityResponse":
    return WhatsAppCapabilityResponse(**get_whatsapp_capability_matrix().to_dict())


async def _extract_twilio_request_params(request: Request) -> dict[str, str]:
    """Read Twilio callback/query params once for signature validation and parsing."""
    form: dict[str, str] = {}
    if request.method == "POST":
        try:
            form = dict(await request.form())
        except Exception:
            form = {}
    return {**dict(request.query_params), **form}


def _verify_twilio_signature(request: Request, params: dict[str, str]) -> None:
    """Reuse the shared Twilio webhook verifier without importing it at module load time."""
    from apps.backend.services.channels.twilio.voice_webhooks import _verify_twilio_signature as _shared_verify

    _shared_verify(request, params)


# ============================================================================
# Request/Response Models
# ============================================================================


class WhatsAppWebhookResponse(BaseModel):
    """Response for WhatsApp webhook acknowledgement."""

    success: bool = Field(default=True, description="Webhook processed successfully")
    message_sid: str | None = Field(default=None, description="Message SID")


class SendMessageRequest(BaseModel):
    """Request to send outbound WhatsApp message."""

    to_number: str = Field(
        ...,
        description="Destination number (E.164 format)",
        json_schema_extra={"example": "+971501234567"},
    )

    from_number: str = Field(
        ...,
        description="WhatsApp number to send from (E.164 format)",
        json_schema_extra={"example": "+14155551234"},
    )

    content: str = Field(
        ...,
        description="Message content",
        json_schema_extra={"example": "Hello from Workweaver!"},
    )

    message_type: str = Field(
        default="text",
        description="Message type: text, image, audio, video, document, template",
    )

    media_url: str | None = Field(
        default=None,
        description="URL for media messages",
    )

    template_name: str | None = Field(
        default=None,
        description="Template name for template messages",
    )

    template_params: dict | None = Field(
        default=None,
        description="Template parameters",
    )

    @field_validator("message_type")
    @classmethod
    def validate_message_type(cls, v):
        valid_types = {
            "text",
            "image",
            "audio",
            "video",
            "document",
            "template",
            "location",
            "contact",
            "interactive",
        }
        if v not in valid_types:
            raise ValueError(f"Invalid message_type: {v}. Must be one of {valid_types}")
        return v

    @model_validator(mode="after")
    def validate_template_contract(self):
        if self.message_type == "template" and not str(self.template_name or "").strip():
            raise ValueError("template_name is required when message_type is template")
        return self


class SendMessageResponse(BaseModel):
    """Response for sending WhatsApp message."""

    success: bool = Field(description="Whether message was sent successfully")
    message_sid: str | None = Field(default=None, description="Message SID if successful")
    status: str | None = Field(default=None, description="Message status")
    error_code: str | None = Field(default=None, description="Error code if failed")
    error_message: str | None = Field(default=None, description="Error message if failed")


class WhatsAppCapabilityResponse(BaseModel):
    """Canonical WhatsApp capability matrix response."""

    provider: str
    transport: str
    inbound_supported_message_types: list[str]
    inbound_unsupported_message_types: list[str] = []
    outbound_supported_message_types: list[str]
    outbound_unsupported_message_types: list[str]
    sender_ownership_contract: str
    sender_ownership_enforced_by: str
    template_requirement: str
    sender_onboarding_model: str = "byo"


class MessageStatusCallback(BaseModel):
    """Message status callback data."""

    model_config = ConfigDict(validate_by_name=True)

    message_sid: str = Field(..., description="Message SID")
    account_sid: str = Field(..., description="Account SID")
    status: str = Field(..., description="Message status")
    from_number: str = Field(..., alias="From", description="Sender number")
    to_number: str = Field(..., alias="To", description="Recipient number")


# ============================================================================
# Webhook Endpoints
# ============================================================================


@router.post("/webhook", response_model=WhatsAppWebhookResponse)
async def whatsapp_webhook(request: Request):
    """
    Twilio WhatsApp webhook for inbound messages.

    This endpoint is called by Twilio when:
    - A new WhatsApp message is received
    - A message status changes

    The webhook processes the event and acknowledges receipt.

    Query parameters (from Twilio):
    - MessageSid: Unique message identifier
    - AccountSid: Twilio account SID
    - From: Sender phone number (whatsapp:+ format)
    - To: Recipient phone number (whatsapp:+ format)
    - Body: Message body (text content)
    - NumMedia: Number of media attachments
    - MediaUrl0, MediaUrl1, ...: URLs for media attachments
    - MediaContentType0, MediaContentType1, ...: MIME types for media
    - NumSegments: Number of message segments

    Returns:
        WhatsAppWebhookResponse with success status
    """
    try:
        params = await _extract_twilio_request_params(request)
        _verify_twilio_signature(request, params)

        # Extract webhook parameters
        message_sid = str(params.get("MessageSid") or "")
        account_sid = str(params.get("AccountSid") or "")
        from_number = str(params.get("From") or "")
        to_number = str(params.get("To") or "")
        body = str(params.get("Body") or "")
        num_media = int(params.get("NumMedia", 0))

        # Extract media URL and type if present
        media_url: str | None = None
        media_type: str | None = None
        if num_media > 0:
            media_url = str(params.get("MediaUrl0") or "")
            media_type = str(params.get("MediaContentType0") or "")

        num_segments = int(params.get("NumSegments", 1))
        # Twilio includes MessageType for rich message types (location, contact, interactive)
        message_type_hint: str | None = str(params.get("MessageType") or "") or None

        logger.info(
            "WhatsApp webhook: message_sid=%s from=%s to=%s num_media=%d",
            message_sid,
            from_number,
            to_number,
            num_media,
        )

        # Get WhatsApp service and parse webhook event
        service = get_whatsapp_service()
        webhook_event = service.parse_webhook_event(
            message_sid=message_sid,
            account_sid=account_sid,
            from_number=from_number,
            to_number=to_number,
            body=body,
            num_media=num_media,
            media_url=media_url,
            media_type=media_type,
            num_segments=num_segments,
            message_type_hint=message_type_hint,
        )

        logger.info(
            "Parsed WhatsApp webhook event: message_type=%s status=%s",
            webhook_event.message_type.value,
            webhook_event.status,
        )

        # Fail-fast on inbound types not in the capability matrix
        if not service.is_inbound_type_supported(webhook_event.message_type):
            logger.warning(
                "WhatsApp inbound type not supported: message_type=%s message_sid=%s from=%s",
                webhook_event.message_type.value,
                message_sid,
                from_number,
            )
            return WhatsAppWebhookResponse(
                success=False,
                message_sid=message_sid,
            )

        # Process webhook event using WhatsApp handler
        # Extract tenant_id from the to_number (Workweaver number)
        # Resolve tenant from Workweaver phone number (to_number)
        tenant_id = _resolve_tenant_from_phone(
            phone_number=to_number,
            correlation_id=message_sid,
        )

        if _is_unsubscribe_keyword(body):
            try:
                keyword = str(body or "").strip().upper()
                get_suppression_store().upsert(
                    tenant_id=tenant_id,
                    channel="whatsapp",
                    identifier=from_number,
                    reason="unsubscribe",
                    source="whatsapp_webhook",
                    actor="twilio_webhook",
                    metadata={
                        "keyword": keyword,
                        "message_sid": message_sid,
                        "account_sid": account_sid,
                    },
                )
                logger.info(
                    "WhatsApp unsubscribe captured: tenant=%s from=%s keyword=%s",
                    tenant_id,
                    from_number,
                    keyword,
                )
            except Exception:
                logger.warning("Failed to persist WhatsApp unsubscribe suppression", exc_info=True)

            await _meter_whatsapp_message(
                tenant_id=tenant_id,
                metric=UsageMetricType.WHATSAPP_MESSAGE_INBOUND,
                message_sid=message_sid,
                metadata={
                    "channel": "whatsapp",
                    "direction": "inbound",
                    "from": from_number,
                    "to": to_number,
                    "num_segments": num_segments,
                    "suppression_keyword": True,
                },
            )
            return WhatsAppWebhookResponse(
                success=True,
                message_sid=message_sid,
            )

        try:
            # Create WhatsApp handler and process message
            handler = get_whatsapp_handler(tenant_id)
            async with handler:
                # Convert webhook event to WhatsApp message
                whatsapp_message = WhatsAppMessage(
                    message_sid=webhook_event.message_sid,
                    account_sid=webhook_event.account_sid,
                    from_number=webhook_event.from_number,
                    to_number=webhook_event.to_number,
                    content=webhook_event.body,
                    message_type=webhook_event.message_type,
                    status=WhatsAppMessageStatus.QUEUED,
                    timestamp=datetime.now(UTC),
                    direction="inbound",
                    media_url=webhook_event.media_url,
                )

                # Process the message
                result = await handler.process_message(whatsapp_message)

                logger.info(
                    "WhatsApp message processed: status=%s routing_provider=%s",
                    result.status,
                    result.routing_provider,
                )

                # Fan out to ambient adapter callbacks (best-effort, non-blocking).
                # DM-type: WhatsApp inbound is always a direct message → salience 0.9.
                asyncio.ensure_future(
                    notify_inbound_event(
                        tenant_id=tenant_id,
                        user_id=from_number,
                        event={
                            "provider": "whatsapp",
                            "channel_type": "dm",
                            "is_dm": True,
                            "is_mention": False,
                            "sender": from_number,
                            "subject": "WhatsApp inbound message",
                            "category": "message",
                            "message_id": message_sid,
                        },
                    )
                )

            await _meter_whatsapp_message(
                tenant_id=tenant_id,
                metric=UsageMetricType.WHATSAPP_MESSAGE_INBOUND,
                message_sid=message_sid,
                metadata={
                    "channel": "whatsapp",
                    "direction": "inbound",
                    "from": from_number,
                    "to": to_number,
                    "num_segments": num_segments,
                },
            )
        except Exception as e:
            logger.error(f"Error processing WhatsApp message: {e}", exc_info=True)
            # Return success to prevent Twilio retries (error already logged)

        return WhatsAppWebhookResponse(
            success=True,
            message_sid=message_sid,
        )

    except ValueError as e:
        logger.error(f"Validation error in WhatsApp webhook: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid webhook data",
        )
    except Exception as e:
        logger.error(f"Error processing WhatsApp webhook: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process webhook",
        )


@router.get("/capabilities", response_model=WhatsAppCapabilityResponse)
async def whatsapp_capabilities():
    """Return the canonical WhatsApp capability matrix."""
    return _whatsapp_capability_response()


@router.post("/send", response_model=SendMessageResponse)
async def send_whatsapp_message(
    request: SendMessageRequest,
    http_request: Request,
):
    """
    Send outbound WhatsApp message.

    Sends a WhatsApp message from a Workweaver number to a recipient.
    Supports text, media, and template messages.

    Args:
        request: SendMessageRequest with message details

    Returns:
        SendMessageResponse with send result

    Raises:
        HTTPException: If message sending fails
    """
    try:
        caller_tenant_id = get_whatsapp_verified_tenant_id(http_request)
        ownership = _resolve_whatsapp_sender_ownership(
            sender_identity=request.from_number,
            authenticated_tenant_id=caller_tenant_id,
            correlation_id="outbound-send",
        )
        if caller_tenant_id and not ownership["owned"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "sender_not_owned",
                    "message": "Sender identity is not assigned to the authenticated organization.",
                    "authenticated_tenant_id": ownership["authenticated_tenant_id"],
                    "resolved_sender_tenant_id": ownership["resolved_sender_tenant_id"],
                    "sender_identity": ownership["sender_identity"],
                    "ownership_contract": get_whatsapp_capability_matrix().sender_ownership_contract,
                },
            )
        tenant_id = caller_tenant_id or str(ownership["resolved_sender_tenant_id"] or "")

        # ComplianceGuard DNC gate (#2795). Tenant-scoped block list — fails
        # closed (returns 409) if the recipient is on the DNC list for this
        # tenant. Runs before delivery-guard so the user-visible error names
        # the canonical compliance reason.
        try:
            from apps.backend.services.compliance import is_blocked as _dnc_is_blocked

            if _dnc_is_blocked(tenant_id, request.to_number, "whatsapp"):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "error_code": "DNC_BLOCKED",
                        "error_message": "recipient is on the workspace DNC list (whatsapp)",
                        "channel": "whatsapp",
                        "identifier": request.to_number,
                    },
                )
        except HTTPException:
            raise
        except Exception:
            logger.warning("dnc.gate_unavailable", exc_info=True)

        try:
            get_delivery_guard().assert_allowed(
                tenant_id=tenant_id,
                channel="whatsapp",
                identifier=request.to_number,
                source="/api/whatsapp/send",
                actor="whatsapp_api",
                sender=request.from_number,
                metadata={"sender_identity": request.from_number},
            )
        except DeliverySuppressedError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error_code": "SUPPRESSED_RECIPIENT",
                    "error_message": (f"Delivery blocked by suppression policy ({exc.record.reason.value})"),
                    "reason": exc.record.reason.value,
                    "identifier": exc.record.identifier_normalized,
                },
            )
        except DeliveryRateLimitedError as exc:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error_code": "DELIVERY_RATE_LIMITED",
                    "error_message": "Delivery temporarily throttled by policy",
                    "reason": exc.reason,
                    "retry_after_seconds": exc.retry_after_seconds,
                },
            )

        # Get WhatsApp service
        service = get_whatsapp_service()

        message_type = WhatsAppMessageType(request.message_type)

        logger.info(
            "Sending WhatsApp message: to=%s from=%s type=%s",
            request.to_number,
            request.from_number,
            request.message_type,
        )

        # Send message
        result = await service.send_message(
            to_number=request.to_number,
            from_number=request.from_number,
            content=request.content,
            message_type=message_type,
            media_url=request.media_url,
            template_name=request.template_name,
            template_params=request.template_params,
            tenant_id=tenant_id,
        )

        if result.success:
            await _meter_whatsapp_message(
                tenant_id=tenant_id,
                metric=UsageMetricType.WHATSAPP_MESSAGE_OUTBOUND,
                message_sid=result.message_sid or "outbound-send",
                metadata={
                    "channel": "whatsapp",
                    "direction": "outbound",
                    "sender_identity": request.from_number,
                    "to": request.to_number,
                    "message_type": request.message_type,
                },
            )
            logger.info(
                "WhatsApp message sent successfully: sid=%s status=%s",
                result.message_sid,
                result.status,
            )
            return SendMessageResponse(
                success=True,
                message_sid=result.message_sid,
                status=result.status,
            )
        else:
            logger.error(
                "Failed to send WhatsApp message: error_code=%s error_message=%s",
                result.error_code,
                result.error_message,
            )
            if result.error_code == "UNSUPPORTED_MESSAGE_TYPE":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "error": "unsupported_message_type",
                        "message": result.error_message,
                        "capabilities": get_whatsapp_capability_matrix().to_dict(),
                    },
                )
            if result.error_code == "MISSING_TEMPLATE":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "error": "missing_template",
                        "message": result.error_message,
                    },
                )
            if result.error_code == "OUTBOUND_COMPLIANCE_BLOCKED":
                parts = str(result.error_message or "").split(":", 2)
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail={
                        "error_code": "OUTBOUND_COMPLIANCE_BLOCKED",
                        "message": "WhatsApp delivery blocked by outbound compliance preflight",
                        "final_verdict": parts[1] if len(parts) > 1 else "DENY",
                        "evidence": parts[2] if len(parts) > 2 else "",
                    },
                )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error_code": result.error_code,
                    "error_message": result.error_message,
                },
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error sending WhatsApp message: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to send message",
        )


@router.post("/status")
async def whatsapp_status_callback(request: Request):
    """
    Twilio WhatsApp message status callback.

    This endpoint is called by Twilio when a message status changes:
    - queued: Message is queued for delivery
    - sent: Message is sent to the network
    - delivered: Message is delivered to recipient
    - read: Message is read by recipient
    - undelivered: Message could not be delivered
    - failed: Message failed to send

    Args:
        request: FastAPI request containing Twilio callback params

    Returns:
        Success acknowledgment
    """
    params = await _extract_twilio_request_params(request)
    _verify_twilio_signature(request, params)

    try:
        callback = MessageStatusCallback.model_validate(params)
    except ValidationError:
        logger.error("Invalid WhatsApp status callback payload", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid status callback data",
        )

    try:
        logger.info(
            "WhatsApp status callback: message_sid=%s status=%s from=%s to=%s",
            callback.message_sid,
            callback.status,
            callback.from_number,
            callback.to_number,
        )

        # Update message status in database using WhatsApp handler
        # Extract tenant_id from the from_number (Workweaver number for outbound)
        # Resolve tenant from Workweaver phone number (from_number for outbound status)
        tenant_id = _resolve_tenant_from_phone(
            phone_number=callback.from_number,
            correlation_id=callback.message_sid,
        )

        try:
            # Create WhatsApp handler and update status
            handler = get_whatsapp_handler(tenant_id)
            handler.handle_status_callback(
                message_sid=callback.message_sid,
                account_sid=callback.account_sid,
                message_status=callback.status,
            )
            logger.info(f"Updated WhatsApp message status: {callback.message_sid} -> {callback.status}")
        except Exception as e:
            logger.error(f"Error updating WhatsApp message status: {e}", exc_info=True)
            # Return success to prevent Twilio retries (error already logged)

        return {"success": True}

    except Exception as e:
        logger.error(f"Error processing WhatsApp status callback: {e}", exc_info=True)
        # Return success even on error to avoid Twilio retries
        return {"success": True}


@router.get("/health")
async def whatsapp_health():
    """Health check endpoint for WhatsApp service."""
    return {
        "status": "healthy",
        "service": "whatsapp",
        "account_sid": os.environ.get("TWILIO_ACCOUNT_SID", "not configured"),
    }


# ============================================================================
# WhatsApp Skills Endpoints
# ============================================================================


class SkillExecuteRequest(BaseModel):
    """Request to execute a WhatsApp skill."""

    tenant_id: str | None = Field(default=None, description="Tenant identifier")
    from_number: str = Field(..., description="WhatsApp business number (E.164)")
    targets: list[str] = Field(..., description="Recipient phone numbers (E.164)")
    skill_config: dict = Field(default_factory=dict, description="Skill configuration")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")
    kwargs: dict = Field(default_factory=dict, description="Skill-specific parameters")


class SkillConfigureRequest(BaseModel):
    """Request to configure a skill for a tenant."""

    tenant_id: str | None = Field(default=None, description="Tenant identifier")
    config: dict = Field(..., description="Skill configuration to validate")


class SkillExecuteResponse(BaseModel):
    """Response from skill execution."""

    success: bool
    messages_sent: int = 0
    messages_failed: int = 0
    details: dict = Field(default_factory=dict)
    error: str | None = None


@router.get("/skills")
async def list_whatsapp_skills(
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
    verified_tenant_id: str = Depends(get_whatsapp_verified_tenant_id),
):
    """
    List all available WhatsApp Business skills.

    Returns metadata for each registered skill including name, description,
    and supported trigger types.
    """
    from apps.backend.services.channels.whatsapp.skills import skill_registry

    skills = skill_registry.list_skills()
    paged_skills, total = paginate_items(skills, pagination)
    return {"skills": paged_skills, "total": total}


@router.post("/skills/{skill_name}/execute", response_model=SkillExecuteResponse)
async def execute_whatsapp_skill(
    skill_name: str,
    request: SkillExecuteRequest,
    verified_tenant_id: str = Depends(get_whatsapp_verified_tenant_id),
):
    """
    Execute a WhatsApp Business skill.

    Args:
        skill_name: Registered skill name (e.g., follow_up, campaign, broadcast)
        request: Execution context, targets, and skill-specific parameters

    Returns:
        SkillExecuteResponse with execution results

    Raises:
        HTTPException 404: If skill not found
        HTTPException 400: If config validation fails
        HTTPException 500: If execution fails
    """
    from apps.backend.services.channels.whatsapp.skills import skill_registry, SkillContext

    skill = skill_registry.get(skill_name)
    if skill is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_name}' not found. Available: {skill_registry.list_names()}",
        )

    # Validate config before executing
    errors = skill.validate_config(request.skill_config)
    if errors:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"validation_errors": errors},
        )

    if request.tenant_id and request.tenant_id != verified_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization ID mismatch between request and authenticated context",
        )

    sender_tenant_id = _resolve_tenant_from_phone(
        phone_number=request.from_number,
        correlation_id=f"skill-exec-{skill_name}",
    )
    if sender_tenant_id != verified_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="from_number is not authorized for authenticated organization",
        )

    context = SkillContext(
        tenant_id=verified_tenant_id,
        from_number=request.from_number,
        skill_config=request.skill_config,
        metadata=request.metadata,
    )

    try:
        result = await skill.execute(context, request.targets, **request.kwargs)
        return SkillExecuteResponse(
            success=result.success,
            messages_sent=result.messages_sent,
            messages_failed=result.messages_failed,
            details=result.details or {},
            error=result.error,
        )
    except Exception as exc:
        logger.error("Skill execution error (%s): %s", skill_name, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Skill execution failed",
        )


@router.get("/skills/{skill_name}/status/{execution_id}")
async def get_skill_execution_status(
    skill_name: str,
    execution_id: str,
    verified_tenant_id: str = Depends(get_whatsapp_verified_tenant_id),
):
    """
    Get execution status for a long-running skill execution.

    For campaign skill: execution_id is the campaign_id.
    For broadcast skill: execution_id is the broadcast_id.

    Returns:
        Status details for the execution

    Raises:
        HTTPException 404: If execution not found
        HTTPException 400: If skill doesn't support status tracking
    """
    from apps.backend.services.channels.whatsapp.skills.campaign import get_campaign_progress
    from apps.backend.services.channels.whatsapp.skills.broadcast import get_broadcast_report

    if skill_name == "campaign":
        progress = get_campaign_progress(execution_id)
        if progress is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Campaign '{execution_id}' not found",
            )
        return progress.to_dict()

    elif skill_name == "broadcast":
        report = get_broadcast_report(execution_id)
        if report is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Broadcast '{execution_id}' not found",
            )
        return report.to_dict()

    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Skill '{skill_name}' does not support status tracking. "
            f"Status tracking is available for: campaign, broadcast",
        )


@router.post("/skills/{skill_name}/configure")
async def configure_whatsapp_skill(
    skill_name: str,
    request: SkillConfigureRequest,
    verified_tenant_id: str = Depends(get_whatsapp_verified_tenant_id),
):
    """
    Validate and configure a WhatsApp Business skill for a tenant.

    Validates the provided configuration against the skill's schema.
    Does not persist configuration (persistence is handled by the caller).

    Args:
        skill_name: Registered skill name
        request: Tenant ID and configuration to validate

    Returns:
        Validation result with any errors

    Raises:
        HTTPException 404: If skill not found
    """
    from apps.backend.services.channels.whatsapp.skills import skill_registry

    skill = skill_registry.get(skill_name)
    if skill is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_name}' not found. Available: {skill_registry.list_names()}",
        )

    if request.tenant_id and request.tenant_id != verified_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization ID mismatch between request and authenticated context",
        )

    errors = skill.validate_config(request.config)
    if errors:
        return {
            "valid": False,
            "errors": errors,
            "skill": skill_name,
            "tenant_id": verified_tenant_id,
        }

    return {
        "valid": True,
        "errors": [],
        "skill": skill_name,
        "tenant_id": verified_tenant_id,
        "message": "Configuration is valid",
    }
