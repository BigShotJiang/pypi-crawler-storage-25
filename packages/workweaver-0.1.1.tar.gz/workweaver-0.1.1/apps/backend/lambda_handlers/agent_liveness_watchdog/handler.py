"""Scheduled Lambda: sweep agent RuntimeSession liveness.

This is separate from the human-presence heartbeat monitor. Human heartbeat
staleness pauses tenant authority; this watchdog detects agent sessions that
stopped making progress while no human approval/reply is pending.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from apps.backend.services.runtime.liveness_watchdog import (
    LivenessWatchdogConfig,
    RuntimeLivenessWatchdog,
)

logger = logging.getLogger(__name__)


def _get_active_tenant_ids() -> list[str]:
    """Retrieve active tenant IDs from the tenant provisioning service."""

    try:
        from apps.backend.services.tenant_provisioning import TenantProvisioningService

        svc = TenantProvisioningService()
        tenants = getattr(svc, "list_tenants")()
        return [t.get("tenant_id", t.get("id", "")) for t in tenants if t.get("status") == "active"]
    except Exception:
        logger.exception("Failed to list active tenants for agent liveness sweep")
        return []


async def _run_sweep(event: dict[str, Any]) -> dict[str, Any]:
    tenant_ids = event.get("tenant_ids") or _get_active_tenant_ids()
    tenant_ids = [str(tenant_id).strip() for tenant_id in tenant_ids if str(tenant_id).strip()]
    if not tenant_ids:
        logger.info("No active tenants found for agent liveness sweep")
        return {
            "status": "ok",
            "tenants_checked": 0,
            "sessions_checked": 0,
            "stalled_sessions": 0,
            "nudges_sent": 0,
            "needs_attention": 0,
        }

    global_config = LivenessWatchdogConfig.from_mapping(event.get("liveness_config"))
    raw_tenant_configs = event.get("tenant_liveness_config")
    tenant_configs: dict[str, Any] = raw_tenant_configs if isinstance(raw_tenant_configs, dict) else {}
    watchdog = RuntimeLivenessWatchdog()
    results = []
    for tenant_id in tenant_ids:
        config = LivenessWatchdogConfig.from_mapping(tenant_configs.get(tenant_id)) if tenant_id in tenant_configs else global_config
        results.append(await watchdog.sweep_tenant(tenant_id, config=config))

    sessions_checked = sum(result.sessions_checked for result in results)
    stalled_sessions = sum(result.stalled_sessions for result in results)
    nudges_sent = sum(result.nudges_sent for result in results)
    needs_attention = sum(result.needs_attention for result in results)
    logger.info(
        "Agent liveness watchdog complete: tenants=%d sessions=%d stalled=%d nudges=%d needs_attention=%d",
        len(results),
        sessions_checked,
        stalled_sessions,
        nudges_sent,
        needs_attention,
    )
    return {
        "status": "ok",
        "tenants_checked": len(results),
        "sessions_checked": sessions_checked,
        "stalled_sessions": stalled_sessions,
        "nudges_sent": nudges_sent,
        "needs_attention": needs_attention,
    }


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Sweep agent liveness for active tenants.

    EventBridge event payload may contain:
      - tenant_ids: optional list to limit processing to specific tenants
      - liveness_config: optional global threshold override
      - tenant_liveness_config: optional tenant_id -> threshold override map
    """

    return asyncio.run(_run_sweep(event or {}))
