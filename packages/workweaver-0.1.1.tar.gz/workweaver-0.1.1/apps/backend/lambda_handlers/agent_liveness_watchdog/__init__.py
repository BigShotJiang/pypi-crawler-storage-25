"""Scheduled agent liveness watchdog Lambda."""
