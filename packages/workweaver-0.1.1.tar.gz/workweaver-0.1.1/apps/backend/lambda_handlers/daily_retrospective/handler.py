"""Scheduled Lambda adapter for daily tenant retrospectives.

The handler is intentionally thin: tenant/date scheduling and dependency
construction live here, while synthesis and persistence live in
``apps.backend.services.retrospective`` so local runners can invoke the same
runtime without AWS Lambda.
"""

from __future__ import annotations

import argparse
import json
import logging
from datetime import UTC, datetime
from typing import Any

from apps.backend.config.table_names import resolve_table
from apps.backend.providers.portable_store import PortableStore, create_portable_store
from apps.backend.services.retrospective import (
    DailyRetrospectiveService,
    RetrospectiveCadence,
    RetrospectiveCadenceScheduler,
    is_retrospective_due,
    tenant_local_date_for_run,
)

logger = logging.getLogger(__name__)

_ACTIVE_STATUSES = {"active", "running", "trial"}
_TENANTS_ALL_INDEX_PK = "TENANTS_ALL_INDEX"

_service_override: DailyRetrospectiveService | None = None
_tenant_records_override: list[dict[str, Any]] | None = None
_failure_evidence_override: Any | None = None


def configure_daily_retrospective_handler(
    *,
    service: DailyRetrospectiveService | None = None,
    tenant_records: list[dict[str, Any]] | None = None,
    failure_evidence: Any | None = None,
) -> None:
    """Override handler dependencies for tests and alternate runners."""

    global _service_override, _tenant_records_override, _failure_evidence_override
    _service_override = service
    _tenant_records_override = tenant_records
    _failure_evidence_override = failure_evidence


def reset_daily_retrospective_handler() -> None:
    """Reset handler dependency overrides."""

    global _service_override, _tenant_records_override, _failure_evidence_override
    _service_override = None
    _tenant_records_override = None
    _failure_evidence_override = None


def _parse_now(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value.astimezone(UTC) if value.tzinfo else value.replace(tzinfo=UTC)
    raw = str(value or "").strip()
    if not raw:
        return datetime.now(UTC)
    parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    return parsed.astimezone(UTC) if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def _tenant_id_from_record(record: dict[str, Any]) -> str:
    return str(record.get("tenant_id") or record.get("id") or record.get("pk") or "").strip()


def _tenant_timezone(record: dict[str, Any], fallback: str = "UTC") -> str:
    workspace = record.get("org_workspace") if isinstance(record.get("org_workspace"), dict) else {}
    config = record.get("config") if isinstance(record.get("config"), dict) else {}
    for value in (
        record.get("timezone"),
        record.get("preferred_timezone"),
        workspace.get("timezone"),
        config.get("timezone"),
        fallback,
    ):
        normalized = str(value or "").strip()
        if normalized:
            return normalized
    return "UTC"


def _tenant_status(record: dict[str, Any]) -> str:
    return str(record.get("status") or "").strip().lower()


def _manual_tenant_records(event: dict[str, Any]) -> list[dict[str, Any]]:
    tenant_ids = event.get("tenant_ids")
    if tenant_ids is None and event.get("tenant_id"):
        tenant_ids = [event["tenant_id"]]
    if not isinstance(tenant_ids, list):
        return []
    timezone_name = str(event.get("timezone") or "UTC")
    return [
        {"tenant_id": str(tenant_id), "status": "manual", "timezone": timezone_name}
        for tenant_id in tenant_ids
        if str(tenant_id or "").strip()
    ]


def _list_active_tenants_from_service() -> list[dict[str, Any]]:
    try:
        from apps.backend.services.tenant_provisioning import TenantProvisioningService

        svc = TenantProvisioningService()
        list_tenants = getattr(svc, "list_tenants", None)
        if callable(list_tenants):
            rows = list_tenants()
            return [dict(row) for row in rows if isinstance(row, dict)]
    except Exception:
        logger.debug("daily_retrospective.tenant_service_unavailable", exc_info=True)
    return []


def _list_active_tenants_from_store(store: PortableStore | None = None) -> list[dict[str, Any]]:
    try:
        tenant_store = store or create_portable_store(resolve_table("tenants"))
        rows = tenant_store.query(_TENANTS_ALL_INDEX_PK, "", limit=1000)
    except Exception:
        logger.exception("daily_retrospective.tenant_index_read_failed")
        return []
    return [dict(row) for row in rows if isinstance(row, dict)]


def _list_active_tenants(event: dict[str, Any]) -> list[dict[str, Any]]:
    if _tenant_records_override is not None:
        return list(_tenant_records_override)

    manual = _manual_tenant_records(event)
    if manual:
        return manual

    rows = _list_active_tenants_from_service() or _list_active_tenants_from_store()
    return [
        row
        for row in rows
        if _tenant_id_from_record(row)
        and (_tenant_status(row) in _ACTIVE_STATUSES or not _tenant_status(row))
    ]


def _llm_factory(tenant_id: str) -> Any:
    from apps.backend.services.inference.provider_chain import get_llm_provider_chain

    return get_llm_provider_chain(tenant_id=tenant_id, intent="research_analyst")


def _build_service() -> DailyRetrospectiveService:
    if _service_override is not None:
        return _service_override

    source_store = create_portable_store(resolve_table("tenants"))
    retrospective_store = create_portable_store(resolve_table("tenant_retrospectives"))
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        evidence_ledger = get_evidence_ledger_service()
    except Exception:
        logger.debug("daily_retrospective.evidence_ledger_unavailable", exc_info=True)
        evidence_ledger = None
    return DailyRetrospectiveService(
        retrospective_store=retrospective_store,
        source_store=source_store,
        evidence_ledger=evidence_ledger,
        llm_client_factory=_llm_factory,
    )


def _build_scheduler(service: DailyRetrospectiveService | None = None) -> RetrospectiveCadenceScheduler:
    if service is None:
        service = _build_service()
    source_store = create_portable_store(resolve_table("tenants"))
    retrospective_store = create_portable_store(resolve_table("tenant_retrospectives"))
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        evidence_ledger = get_evidence_ledger_service()
    except Exception:
        logger.debug("retrospective_cadence.evidence_ledger_unavailable", exc_info=True)
        evidence_ledger = None
    try:
        from apps.backend.services.zara.execution_event_bus import get_execution_event_bus

        event_bus = get_execution_event_bus()
    except Exception:
        logger.debug("retrospective_cadence.event_bus_unavailable", exc_info=True)
        event_bus = None
    return RetrospectiveCadenceScheduler(
        source_store=source_store,
        retrospective_store=retrospective_store,
        evidence_ledger=evidence_ledger,
        event_bus=event_bus,
        daily_service=service,
    )


def _emit_failure_evidence(
    *,
    tenant_id: str,
    target_date: str,
    error: Exception,
) -> None:
    evidence = _failure_evidence_override
    if evidence is None:
        try:
            from apps.backend.services.evidence_ledger import get_evidence_ledger_service

            evidence = get_evidence_ledger_service()
        except Exception:
            logger.debug("daily_retrospective.failure_evidence_unavailable", exc_info=True)
            return
    try:
        evidence.ingest(
            tenant_id=tenant_id,
            event_type="learning_synthesis_failed",
            data={
                "tenant_id": tenant_id,
                "date": str(target_date),
                "error": str(error),
                "job": "daily_retrospective",
            },
        )
    except Exception:
        logger.warning("daily_retrospective.failure_evidence_emit_failed", exc_info=True)


def run_cadence_lambda(
    cadence: RetrospectiveCadence,
    event: dict[str, Any] | None,
    context: Any,
) -> dict[str, Any]:
    """Run due retrospectives for active tenants.

    Event payload:
      - ``tenant_id`` or ``tenant_ids``: optional manual tenant selection
      - ``date`` / ``target_date``: optional manual tenant-local date
      - ``now``: optional ISO timestamp for deterministic invocation/tests
      - ``force``: overwrite the existing retrospective for the date
      - ``disable_llm``: force deterministic synthesis fallback
    """

    del context
    event = event or {}
    now = _parse_now(event.get("now"))
    explicit_date = event.get("date") or event.get("target_date")
    force = bool(event.get("force", False))
    manual_tenants = bool(event.get("tenant_id") or event.get("tenant_ids"))
    use_llm = not bool(event.get("disable_llm", False))
    service = _build_service()
    scheduler = _build_scheduler(service)

    processed: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    failed: list[dict[str, Any]] = []

    for tenant in _list_active_tenants(event):
        tenant_id = _tenant_id_from_record(tenant)
        if not tenant_id:
            continue
        timezone_name = _tenant_timezone(tenant, str(event.get("timezone") or "UTC"))
        if explicit_date:
            target_date = str(explicit_date)
        else:
            target_date = tenant_local_date_for_run(now, timezone_name).isoformat()

        if (
            cadence == RetrospectiveCadence.DAILY
            and not explicit_date
            and not force
            and not manual_tenants
            and not is_retrospective_due(now, timezone_name)
        ):
            skipped.append({"tenant_id": tenant_id, "reason": "not_due", "timezone": timezone_name})
            continue

        try:
            result = scheduler.run_cadence(
                cadence,
                tenant_id=tenant_id,
                now=now,
                timezone_name=timezone_name,
                force=force,
                use_llm=use_llm,
                target_date=str(explicit_date) if explicit_date else None,
            )
            daily_synthesis = result.daily_synthesis
            processed.append(
                {
                    "tenant_id": tenant_id,
                    "date": getattr(daily_synthesis, "date", None) or result.window.target_date or str(target_date),
                    "retrospective_id": getattr(daily_synthesis, "retrospective_id", None) or result.storage_key,
                    "wins": len(getattr(daily_synthesis, "wins", []) or []),
                    "problems": len(getattr(daily_synthesis, "problems", []) or result.findings),
                    "hypotheses": len(getattr(daily_synthesis, "hypotheses", []) or result.optimization_proposals),
                    "llm_synthesized": bool(getattr(daily_synthesis, "llm_synthesized", False)),
                    "cadence": cadence.value,
                }
            )
        except Exception as exc:
            logger.exception("%s_retrospective.failed tenant=%s date=%s", cadence.value, tenant_id, target_date)
            _emit_failure_evidence(tenant_id=tenant_id, target_date=str(target_date), error=exc)
            failed.append({"tenant_id": tenant_id, "date": str(target_date), "error": str(exc)})

    return {
        "status": "ok" if not failed else "partial_failure",
        "tenants_processed": len(processed),
        "tenants_skipped": len(skipped),
        "tenants_failed": len(failed),
        "processed": processed,
        "skipped": skipped,
        "failed": failed,
    }


def lambda_handler(event: dict[str, Any] | None, context: Any) -> dict[str, Any]:
    """Run due daily retrospectives for active tenants."""

    return run_cadence_lambda(RetrospectiveCadence.DAILY, event, context)


handler = lambda_handler


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run Workweaver daily retrospective synthesis")
    parser.add_argument("--tenant-id", action="append", dest="tenant_ids", help="Tenant ID to synthesize")
    parser.add_argument("--date", dest="date", help="Tenant-local YYYY-MM-DD date to synthesize")
    parser.add_argument("--now", dest="now", help="Override current UTC timestamp")
    parser.add_argument("--force", action="store_true", help="Overwrite an existing retrospective")
    parser.add_argument("--disable-llm", action="store_true", help="Use deterministic synthesis only")
    args = parser.parse_args(argv)
    response = lambda_handler(
        {
            "tenant_ids": args.tenant_ids,
            "date": args.date,
            "now": args.now,
            "force": args.force,
            "disable_llm": args.disable_llm,
        },
        None,
    )
    print(json.dumps(response, indent=2, sort_keys=True))
    return 0 if response["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "configure_daily_retrospective_handler",
    "handler",
    "lambda_handler",
    "main",
    "reset_daily_retrospective_handler",
]
