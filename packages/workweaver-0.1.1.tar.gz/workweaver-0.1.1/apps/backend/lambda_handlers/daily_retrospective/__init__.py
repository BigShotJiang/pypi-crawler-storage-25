"""Daily retrospective Lambda package."""
