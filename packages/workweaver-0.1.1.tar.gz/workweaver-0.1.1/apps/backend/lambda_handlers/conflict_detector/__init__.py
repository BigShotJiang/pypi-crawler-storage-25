"""EventBridge-scheduled conflict detector Lambda."""
