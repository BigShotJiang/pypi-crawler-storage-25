"""Scheduled Lambda: nightly tenant conflict detection (#3548).

EventBridge invokes this once per night (02:00 UTC by default). The
handler enumerates active tenants, runs the conflict detector matrix
for each, and returns a per-tenant summary so the EventBridge log can
attest that the run actually executed.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from apps.backend.jobs.conflict_detector import (
    list_active_tenant_ids,
    run_conflict_detection_for_tenants,
)

logger = logging.getLogger(__name__)


def _resolve_tenant_ids(event: dict[str, Any]) -> list[str]:
    candidates = event.get("tenant_ids")
    if isinstance(candidates, list) and candidates:
        return [str(item) for item in candidates if str(item).strip()]
    return list_active_tenant_ids()


def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda entrypoint."""
    started = datetime.now(UTC)
    tenant_ids = _resolve_tenant_ids(event or {})
    bundles = run_conflict_detection_for_tenants(tenant_ids)
    summary = {
        tenant_id: {
            "conflicts": len(bundle.conflicts),
            "severity_counts": bundle.severity_counts,
        }
        for tenant_id, bundle in bundles.items()
    }
    finished = datetime.now(UTC)
    payload = {
        "tenant_count": len(bundles),
        "tenants": summary,
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "duration_ms": int((finished - started).total_seconds() * 1000),
    }
    logger.info("conflict_detector_lambda_run %s", payload)
    return payload
