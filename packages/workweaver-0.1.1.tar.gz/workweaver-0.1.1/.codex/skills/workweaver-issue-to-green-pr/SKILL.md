---
name: workweaver-issue-to-green-pr
description: Use when implementing Workweaver GitHub issues or issue batches into one or more PRs. Covers issue quality checks, batch scope, worktree/branch discipline, TDD, surface parity, local Docker verification, PR body evidence, CI babysitting, and leaving green PRs for human merge.
---

# Workweaver Issue To Green PR

Use this for any request like "implement issue #N", "burn down this batch", "turn remaining issues into PRs", or "make these Workweaver issues green".

## Workflow

1. Read before coding:
   - `AGENTS.md`
   - `CODEX.md`
   - `docs/PRODUCT-CONTEXT.md`
   - `.gap-audit/DEPENDENCY-MAP.md`
   - `docs/CLI.md` and `docs/RUNTIME.md` when CLI/runtime behavior can be affected
   - `.claude/rules/` when present and relevant

2. Validate scope:
   - Treat GitHub issue numbers as canonical.
   - Obey explicit batch exclusions before starting work.
   - If an issue is under-specified, fix or comment on the issue first. Do not implement against missing file:line citations, vague acceptance criteria, or unclear surface parity.
   - Before creating, editing, closing, or filing a follow-up GitHub issue, use `workweaver-github-issue-authoring` and satisfy its code-truth intake contract.
   - If the issue contains UI acceptance criteria but the assigned lane is backend-only, stop and ask.

3. Create one isolated stream per issue:
   - Base from latest `origin/main`.
   - Use one worktree per issue.
   - Branch as `codex/<NNNN>-<slug>` unless the user gives a stricter name.
   - Keep each PR scoped to one issue unless the issue itself requires multiple PRs.

4. Implement with TDD:
   - Inventory existing tests for the touched behavior before editing implementation.
   - Write or select the failing RED test first. If the test cannot be written before a missing scaffold exists, state the blocker and add it immediately after the scaffold.
   - Implement the smallest structural fix that satisfies the issue.
   - Keep RED -> GREEN -> REFACTOR order explicit in notes, commits, and PR evidence.
   - Refactor toward lower local and global idiot index while keeping focused tests green.
   - Delete or rewrite obsolete, redundant, shallow, import-only, over-mocked, or implementation-detail tests in the touched surface.
   - Add or tighten missing tests for happy path, failure path, authorization / tenant isolation, persistence, idempotency, observability, and surface contracts when those risks exist.
   - Remove touched drift when bounded: dead code, stale TODOs, broken links, wrong names, orphan routes, misleading claims.
   - Do not ship backend halves of UI-coupled work.

5. Preserve surface parity:
   - Map changed behavior across REST, CLI, MCP, UI, docs, persistence, and observability.
   - If a UI surface changes, audit `apps/cli/ww/commands/` and `apps/backend/extensions/mcp_server/` for equivalent surfaces.
   - Bring required parallel surfaces into the same PR or document an explicit issue-backed exemption.

6. Verify locally before PR:
   - Start Docker Desktop on Windows if needed.
   - Run the issue-specific tests.
   - Run every impacted local test suite, not only the newly added test.
   - Run the repo gate required by the issue.
   - Confirm no relevant test is skipped, xfailed, quarantined, not-run, or silently omitted unless an issue-backed exemption exists.
   - For runtime/UI-visible work, run local Docker and gstack/browser verification from the PR branch, not main.

7. Open the PR:
   - Include `Closes #N` or the exact closing keyword required.
   - Map each acceptance criterion to a test path, test name, assertion shape, command, and concrete evidence.
   - Include test inventory: tests added, tests modified, tests deleted as obsolete/redundant, tests intentionally not added, and why this is the complete set for the evolved scope.
   - Include inversions considered, tradeoffs, constraints honored, portability check, idiot-index reduction, debt removed, and surface parity row.
   - State which downstream issue(s) it unblocks when relevant.

8. Babysit until green:
   - Address review comments with new commits.
   - Resolve conflicts.
   - Never amend or force-push unless the user explicitly commands it.
   - Merge Workweaver PRs only when the user explicitly grants merge authority in the current task and the closure verdict is `ALLOW`.
   - When merge authority is granted, carry the work through merge, post-merge `main` verification, and repo hygiene instead of stopping at a ready PR.

## Definition Of Done

Done means the PR is green and code-truth-audited, not merely implemented. All issue acceptance criteria are satisfied with code evidence, all issue-listed tests pass, every impacted local suite passes fresh, the full applicable CI matrix passes, required surfaces are wired or explicitly exempted, local Docker/browser checks pass when applicable, obsolete/redundant tests in the touched surface are removed or rewritten, missing tests are added or explicitly issue-exempted, and no known partial gap is hidden.
