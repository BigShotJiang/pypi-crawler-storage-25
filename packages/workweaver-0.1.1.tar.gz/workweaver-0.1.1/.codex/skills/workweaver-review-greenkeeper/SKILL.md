---
name: workweaver-review-greenkeeper
description: Use when babysitting a Workweaver PR after it is opened. Handles review comments, CI failures, merge conflicts, code-truth regressions, and follow-up commits until the PR is green and ready for human merge.
---

# Workweaver Review Greenkeeper

Use this for "make this PR green", "address review comments", "resolve conflicts", "refresh the PR", or "keep iterating until ready".

## Workflow

1. Inventory the PR:
   - Read the PR body, linked issues, review threads, CI checks, and latest diff.
   - Confirm the PR's branch and target.
   - Restate actionable findings internally before editing.

2. Verify reviewer claims:
   - Reviewers can be wrong.
   - Check each claim against code and tests before changing anything.
   - Do not perform unrelated rewrites while fixing review feedback.

3. Fix in small commits:
   - Address one coherent feedback group at a time.
   - Add or tighten tests for every behavior fix.
   - Never amend or force-push unless explicitly instructed.
   - Preserve unrelated local/user changes.

4. Resolve conflicts structurally:
   - Rebase or merge only when appropriate for the repo's current workflow.
   - Preserve both sides' real intent.
   - Rerun affected tests after conflict resolution.

5. Re-run readiness checks:
   - Issue-specific tests.
   - Required make/CI gates.
   - Code-truth audit if the fix changes issue scope or acceptance evidence.
   - Browser/local Docker checks for visible runtime behavior.

6. Update PR evidence:
   - Ensure the PR body still maps acceptance criteria to test symbols/evidence.
   - Add notes for new tradeoffs, constraints, or follow-up issues.
   - Use `workweaver-github-issue-authoring` before creating, editing, or closing any follow-up GitHub issue discovered during review.
   - Reply to review threads only after the fix is pushed and verified.

7. Stop condition:
   - PR is green.
   - Review threads are answered or resolved according to repo policy.
   - Code-truth audit is `ALLOW`.
   - Do not merge unless the user explicitly granted merge authority.

## Output

Report:

- `worked` or `not worked`
- PR URL and issue number
- Checks run and pass/fail result
- Remaining blockers, if any
- Whether human merge is now safe
