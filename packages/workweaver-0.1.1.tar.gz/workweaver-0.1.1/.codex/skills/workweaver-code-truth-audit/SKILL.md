---
name: workweaver-code-truth-audit
description: Use when verifying whether a Workweaver PR, branch, merged change, or closed GitHub issue truly satisfies its issue. Audits issue body, PR diff, tests, surface parity, dependencies, local Docker/runtime evidence, and idiot-index delta before merge or closure.
---

# Workweaver Code Truth Audit

Use this before declaring a PR ready, before closing an issue, after suspicious merges, or when the user asks whether an issue is truly done. An `ALLOW` verdict marks readiness only; this agent never merges Workweaver PRs.

## Audit Inputs

Collect:

- GitHub issue body, including acceptance criteria, dependencies, implementer's briefing, files to modify, tests to add, and run-before-done commands.
- PR diff or branch diff against `origin/main`.
- Test inventory delta: tests added, modified, deleted as obsolete/redundant, intentionally not added, and rationale.
- Current CI status.
- Local test output from fresh commands.
- Local Docker/browser evidence when runtime or UI behavior is touched.

## Audit Procedure

1. Normalize the claim:
   - Identify exactly which issue(s) the PR claims to close.
   - Reject vague claims like "mostly done" or "green CI means done".
   - If one issue requires multiple PRs, state the split and what remains.

2. Check issue quality:
   - Required file:line citations must exist.
   - Acceptance criteria must be falsifiable.
   - Required surfaces must be named or inferable.
   - Dependencies must be explicit.
   - If the issue is malformed, verdict is `NEEDS-HUMAN` or `BLOCK` until clarified.

3. Map acceptance criteria to evidence:
   - For every criterion, mark `met`, `unmet`, or `ambiguous`.
   - Cite code paths, test paths, test names, assertion shapes, and command evidence.
   - Existing tests count only if they exercise the changed behavior with real assertions.
   - A criterion without feasible automated coverage is `unmet` unless the issue body or a linked follow-up explicitly exempts it.

4. Audit TDD and test completeness:
   - Confirm the PR evidence shows RED -> GREEN -> REFACTOR or an explicit justified exception for a non-code/doc-only change.
   - Check whether touched tests include obsolete, redundant, shallow, import-only, over-mocked, skipped, xfailed, quarantined, or implementation-detail coverage; any retained weak relevant test is `BLOCK`.
   - Check whether required tests are missing for happy path, failure path, authorization / tenant isolation, persistence, idempotency, observability, and surface contracts when those risks exist.
   - Validate the reported test count delta against the diff. Deleted tests must correspond to retired behavior or redundant weaker coverage; otherwise `BLOCK`.
   - Confirm all issue-listed tests, impacted local suites, repo-required gates, and full applicable CI matrix passed. A green PR check alone is not sufficient.

5. Check surface parity:
   - REST/API, CLI, MCP, UI, docs, persistence, observability.
   - Any omitted surface needs an explicit issue-backed reason.
   - Backend-only PRs must not pretend to close UI-coupled issues.

6. Check dependencies:
   - `Blocked By` issues must be closed and present on `main`.
   - Batch order and lane exclusions must be respected.
   - Do not let a green PR bypass a dependency violation.
   - If a deferred gap needs a follow-up issue before the audit can allow readiness, use `workweaver-github-issue-authoring` before creating or editing that issue.

7. Run or verify commands:
   - Use issue-listed commands first.
   - Use `make check-delta` for general changes.
   - Use `scripts/ci/gate.sh` for runtime code when required by repo rules.
   - Use local Docker and gstack/browser checks for runtime/UI-visible work.
   - Read full output before claiming pass.

8. Run idiot-index audit:
   - Local: dead code, wrong names, stale TODOs, broken links, misleading copy, type lies.
   - Global: orphan routes, stale docs, migrated symbols still referenced, broken capability claims, parity drift.
   - Positive global drift is `BLOCK`.

## Verdicts

- `ALLOW`: all criteria met, TDD/test inventory is complete, obsolete/redundant tests are cleaned up, required tests pass locally and in the full applicable CI matrix, surfaces are wired or exempted, dependencies are clear, idiot index did not increase. The PR may be marked ready for the repo owner / CTO or his authorized Codex bot; this agent still does not merge it.
- `BLOCK`: any required criterion, TDD evidence, test inventory, relevant test, surface, dependency, or fresh verifier fails.
- `NEEDS-HUMAN`: product intent or spec language is genuinely ambiguous.

There is no `PARTIAL` ready state. Split deferred work into issue-backed follow-ups first, then rerun the audit.
