# Workweaver Design System

> The AI workforce platform for governed business automation — with proof.
>
> **Plain glass. Bright white. Warm saffron. Ultra-minimalistic.**
> **Zero wasted clicks. Nothing buried. No wrong way to use it.**

This repository defines the full visual + interaction system for
**Workweaver** (by Bit Foundry AI) — both the signed-in product shell
("the runtime") and the marketing site.

---

## What is Workweaver?

Workweaver is an AI workforce platform that runs governed business workflows
end-to-end — every action carries identity, traceability, and proof. The
core promise:

> **Describe the job. Connect the missing tools. Approve the plan. Get proof.**

The platform thesis — stated verbatim across product and marketing:

> **Operating memory: evidence → decision trace → governed action → compounding.**

The revenue-work wedge ships first (outreach, inbox + calendar triage,
lead follow-up), expanding through "guided rollout." The flagship agent
is **Zara** — a voice + multi-skill operator. Every action is reviewable,
revocable, and tenant-scoped.

### Core systems (spoken in-product)
- **Mission Control** — the conversation surface that starts a run
- **Execution Runtime** — where governed work actually runs
- **Evidence Ledger** — immutable decision traces + proof artifacts
- **WorkMemory** — compounding Workspace memory across sessions
- **Harness System** — approval gates + simulation + emergency brake
- **Agent Identity** — tenant-scoped, delegated worker identity

### Surfaces covered
1. **Runtime (product)** — Mission, Settings, Mission docks, and Cmd+K
2. **Landing / marketing** — hero + sections + "How it works" stack

---

## Sources used

Everything was built from the **local codebase mount** at `workweaver/`
(Bit Foundry AI's private monorepo). The GitHub repo
`bitfoundry-ai/workweaver` is **not accessible** via the connected
integration — the org installation covers `workweaver-runtime`, `gstack`,
`openclaw`, `activepieces` but not the main repo. To regenerate from the
canonical repo, install the GitHub app on `bitfoundry-ai/workweaver`.

| Source | Path | What we pulled |
| --- | --- | --- |
| Brand facts | `workweaver/apps/landing/public/.well-known/brand-facts.json` | Name, promise, thesis, capability inventory, boundaries |
| LLM map | `workweaver/apps/landing/public/llms.txt` + `llms-full.txt` | Canonical public-surface map |
| Landing site | `workweaver/apps/landing/public/index.html` (+ `css/workweaver-light-shell.css`) | Hero + section patterns, token precedents |
| Runtime shell | `workweaver/apps/landing/public/runtime/index.html` + `apps/dashboard/runtime/index.html` | Panel structure, Zara launcher, sidebar model |
| Sidebar v2 | `workweaver/apps/dashboard/components/layout/sidebar-redesign.html` | Nav structure, group tagline pattern |
| Logo | User-attached new mark (W with integrated gear) | Saved as `assets/workweaver-logo.png` + re-exported as `assets/workweaver-logo.svg` |

---

## 🗂 Index

```
.
├── README.md                  — this file (start here)
├── README-ADMIN.md            — admin shell kit: porting map + backend gaps
├── SKILL.md                   — system summary for agents
├── HANDOFF.md                 — Claude Code / Codex porting plan
├── CHAT_ROUTER_CONTRACT.md    — inferred-scope chat router contract
├── IMPLEMENTATION_LOG.md      — slice-by-slice landing log
├── colors_and_type.css        — all tokens + text styles
├── assets/                    — logos + favicons + product imagery
│   ├── workweaver-logo.svg    — primary mark (W + gear)
│   ├── workweaver-logo.png    — raster fallback
│   ├── Header.webp            — landing-header logo crop
│   ├── Falcon.webp            — mark-only crop
│   ├── bitfoundry-logo.svg    — parent-org mark
│   └── favicon-{16,32}.png, apple-touch-icon.png
├── preview/                   — design-system cards
│   ├── colors-*.html          — primary / semantic / glass
│   ├── type-*.html            — display / body
│   ├── spacing-*.html         — radii / scale / shadows
│   ├── components-*.html      — buttons / chips / inputs / cards / nav / timeline
│   └── brand-*.html           — logo / iconography
└── ui_kits/
    ├── runtime/index.html     — chat-first runtime click-thru (the only mission view)
    ├── landing/index.html     — marketing click-thru
    └── admin/index.html       — admin.workweaver.ai shell: overview · Zara Identity ·
                                  call history · wallet · pricing · settings
```

---

## 🗣 CONTENT FUNDAMENTALS

Workweaver's voice is technically precise and trust-building. It is the
voice of a senior operator explaining a governed system, not a startup
asking you to believe in magic. Copy is always **concrete over abstract**,
**proof over promise**, **specific over sweeping**.

### Voice & tone
- **Governed, not breathless.** Never "revolutionary AI", never "unlock
  your potential." The product earns trust through traceability.
- **Specific verbs, specific nouns.** "Send email to Sarah Chen." "Book a
  meeting Thursday 2 PM." Avoid *streamline, leverage, empower*.
- **Technical honesty.** Where coverage is partial, copy says so —
  "supported workflows", "guided rollout", "additional surfaces roll out
  in waves." Limitations are published, not hidden.
- **Address the user directly (`you`).** The AI is third-person ("Zara
  proposes", "Workweaver ran") — it's a tool operating on your behalf.
- **Active voice. Present tense.**
- **No filler.** If a sentence can be deleted without losing meaning,
  delete it.

### Casing
- **Sentence case** for UI, buttons, most headings.
- **Title Case** only for **brand nouns**: Mission Control, Execution
  Runtime, Evidence Ledger, WorkMemory, Connected Tools, Agent Identity,
  Proof Card, Emergency Brake.

### Pronouns
- Platform capability → third person ("Workweaver does", "Zara proposes").
- Outcomes the user owns → second person ("You approve").
- Never "we" inside the product.

### Emoji + decoration
- **No emoji. Anywhere.** Not in copy, not in slides, not in UI.
- Iconography is Font Awesome (light) and inline SVG.
- Em-dashes and unicode arrows (`→`) are fine.

### Vibe example (real product copy)

> **AI that works. Proof that it did.**
> Start with revenue work across calls, email follow-up, CRM updates,
> and consented meetings. Every action carries identity, traceability,
> and visibility; every high-risk step stays approval-gated, and every
> completed run leaves proof your team can review and export.

### Sidebar group taglines (the Workweaver voice, distilled)
> Mission — *What are we trying to get done?*
> Mission approvals dock — *What needs my attention now?*
> Memory — *What does Workweaver remember?*
> Connected tools — *Apps Workweaver can use on your behalf.*
> Settings — *Account, workspace, billing.*

### Words to avoid
*revolutionize, unleash, supercharge, seamless, synergy, game-changing,
next-gen, leverage, empower, unlock, journey, delight, magical, 10x.*

### Words to use (from the actual product)
*governed, traced, approval-gated, evidence, proof, decision trace,
compounding, guided rollout, consented, immutable, supported, tenant-scoped,
reviewable, revocable, boundary, escalation, outcome, run.*

---

## 🧭 INTERACTION PRINCIPLES

The look matters less than **how capabilities are exposed to the user.**
These rules are load-bearing — every surface must satisfy them.

### 1. Chat-first, calendar-only
Workweaver has **two surfaces and one rail.** A bottom-pinned chat bar
is the only entry path — there is no top bar, no "New run" button, no
"Ask Workweaver" search. The calendar is the only mission view; goals,
OKRs, tasks, scheduled work, and the execution log all render as cards
on the same calendar at the matching altitude. Steering is
natural-language only — there are **no approve / reject buttons.**

### 2. One data source → one UI surface
Never build two screens that show the same underlying information.
Goals, OKRs, tasks, scheduled work, approval queue, execution log — all
are facets of the same entity graph (workflows × runs × time). They
live on **one calendar**, viewable at five altitudes (Quarter / Month /
Week / Day / Hour). No KPI tiles, no "Active / Awaiting / Shipped"
strip — the calendar alone shows the work.

### 3. Zero redundant clicks
If a capability takes more keystrokes than the user's intent required,
the design is wrong:
- Click card → open modal → click button. **Wrong.** The card opens
  directly in an iframe overlay; the chat at the bottom of the iframe
  is the only action surface.
- Separate view vs. edit modes. **Wrong.** Everything is
  always-editable; changes commit on blur with an undo window.
- A button to do what typing would do. **Wrong.** Type it.

### 4. No wrong way to use it
Every action is **reversible or confirmable**, never both. Reversible
actions just run — users undo or re-steer in chat. High-risk actions
(send email, charge card, delete account) hold in chat with a one-line
"about to do X — say go to send, or steer" message. There is no "Are
you sure?" modal.

Specifically:
- **No unconfigured initial state.** New users land on a guided first
  conversation; the calendar fills as Zara names goals.
- **No mystery icons.** Every icon has a label (tooltip or text), always.
- **No overloaded gestures.** Click = open. Hover = reveal. Drag =
  reschedule. That's it.

### 5. Progressive disclosure, zero-compromise capability
Calm surface, infinite depth. The card shows title, time, status —
clicking opens the iframe with Plan / Connectors / Files / Decision
trace / Memories sections collapsed by default. Every capability is
one tap from the card; nothing is buried.

### 6. Chat is the spine (not ⌘K)
The bottom chat bar replaces the command palette. Every action,
navigation target, run-steer, and lookup is reachable by typing. ⌘K
focuses the chat bar; it does not open a separate palette. The chat
bar starts single-line and expands to **70 % of the viewport** as a
glass overlay over the calendar when the user types or as turns
accumulate.

### 7. Inline steerability via chat
Every card is a steerable surface, but the steering happens in chat —
either the global bar or the inline chat at the bottom of the card
iframe. "Send it now." "Move to 3 pm." "Hand off to Priya." "Pause this
run until I'm back." The card itself reflects state; it is not a
button menu.

### 8. Drag to reschedule
Cards are draggable to any other timeblock or any other day. A dashed
saffron drop zone shows valid targets. Cards can be marked repeatable
(daily / weekly / pattern) inside the card iframe — calendar mechanics
are familiar; the agent layer is what's new.

### 9. Persistent state
Where the user was, what they had open, what they last edited — all
preserved across refresh, across device. `localStorage` for UI state
(left-rail collapse, chat-history collapse, chat-bar height, last
altitude); server-synced for work state.

### 10. Visibility of system status
Zara has a live status dock above the chat bar — idle / listening /
thinking / acting. Click to collapse to an orb. The user never has to
ask "is it doing something?"

### 11. One brain, two altitudes
- **Human altitude** → goals, OKRs, outcomes. Slow cadence.
- **Agent altitude** → tasks, steps, tool calls. Fast cadence.
Both render on the same calendar. Zooming out groups agent steps into
human-readable outcomes. Zooming in reveals every tool call.

---

## 💬 THE SHELL — chat + calendar + rail

Workweaver's runtime is **three vertical zones, never four**:

```
┌────────────┬────────────────────────────────────────────────────┐
│  RAIL      │  CALENDAR  · the only mission view                  │
│ · Mission   │  09:00  ┌─ Q2 · Pipeline +40% ────────────────┐ │
│ · Inbox     │         │  Outreach to 40 SaaS VPs ↑ Zara         │ │
│ · Memory    │         └──────────────────────────────────────────────┘ │
│ · Connected │ ──now────────────────────────────────────────────────────│
│ · Skills    │  10:00  ┌─ Approval gate ──────────────────────┐ │
│ · Members   │         │  Sarah Chen email · awaiting natural │ │
│ · Settings  │         │  language steer in chat below        │ │
├───────────┤         └──────────────────────────────────────────────┘ │
│ CHAT       │                                                    │
│ HISTORY    │                                                    │
│ · Today    │                                                    │
│ · Yesterday│                                                    │
│ · …        │                                                    │
└───────────┴─────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────┐
│ [📎] [🎙] Type to steer Workweaver…                  [⏎]   │   ← chat bar (pinned)
└──────────────────────────────────────────────────────────────────┘
```

### Left rail (232 px collapsed to 60 px)
- Top half: nav (Mission / Settings) plus the user avatar pinned to the
  very bottom. Mission docks and Cmd+K expose memory, connected tools,
  skills, members, and approvals.
- Bottom half: **chat history**. Each entry shows title + 1-line
  preview + relative time. Click an entry to scroll the chat to that
  thread. Single chevron collapses the history pane and gives the rail
  back to nav.
- The rail is the only persistent navigation. There is no top bar.

### Calendar canvas
- Hourly timeblocks at five altitudes. "Now" is a 2 px saffron
  hairline; past time fades to 70 % opacity.
- Cards represent goals or tasks; the **whole card** is clickable.
- Cards are draggable to other timeblocks / other days.
- Empty timeblocks show a soft "type below to add" hint — not a button.

### Bottom chat bar
- Pinned to the bottom. Single-line collapsed; expands to **70 % of
  viewport** as a glass overlay when focused or as turns accumulate.
- Drag-handle at the top edge resizes; Esc collapses.
- Composer: paperclip (file upload), mic (audio with red-pulse
  recording state), text area (Enter sends, Shift+Enter newline), send.
- Quick-chip strip above the composer for common steers.
- Zara dock floats above the bar; click to collapse to an orb.

### Card iframe (progressive disclosure)
Clicking a card opens an iframe overlay (not a modal):
- Header: title + status + time + agent.
- Right: live preview pane (email being drafted, slide deck, document).
- Sections collapsed by default — Plan, Connectors, Files & context,
  Decision trace, Memories.
- Top-right pills: Repeat · Move · Hand-off.
- **Inline chat at the bottom of the iframe** — the only action surface.
  Type to steer; no buttons.

---

## 🕰 THE CALENDAR — the only mission view

> One data source, one UI surface.

Workweaver's central surface is a **single hourly calendar** showing
everything the org is trying to get done — goals, OKRs, tasks, scheduled
work, completed runs — as cards on the same canvas. **There are no
separate Goals / OKRs / Tasks / Schedule / Log screens, and no KPI
strip above the calendar.** They are the same data graph rendered at
different altitudes; the calendar alone shows the work.

### Why this pattern
- Humans keep separate tools for "what I plan" vs "what I'm doing" — and
  they always drift. Workweaver refuses the drift.
- For an agent, time *is* the ground truth — every action has a
  timestamp, so the timeline is the execution log, promoted to the main
  surface.
- A time-block is the ideal steerable unit: it's a noun (a scheduled
  thing) and a verb (the work happening now).

### Structure
```
┌─── Altitude ────────────────────────────────────────────────────┐
│  Quarter   Month   Week   [Day]   Hour    ◂ today ▸  ⌘K         │
├─────────────────────────────────────────────────────────────────┤
│ 09:00                                                           │
│   ╭─ Q4 Goal · Enterprise pipeline +40%   ▸ 2 active runs ──╮   │  ← goal block (quarter altitude)
│   │   ├─ Outreach to 40 SaaS VPs        Zara  [approve] [skip]│  ← steerable INLINE
│   │   └─ Nurture last-week cohort       Zara  [running 2/7]  │
│   ╰──────────────────────────────────────────────────────────╯   │
│ 10:00 ── now ─────────────────────────────────────────────────  │  ← saffron hairline
│   ● Email   draft to Sarah Chen @ TechCo       ◂ awaiting you  │
│   • Meeting Join consented call · Acme         11:00           │
│ 11:00                                                           │
│   • CRM     post-call update to Zoho                            │
└─────────────────────────────────────────────────────────────────┘
```

### Rules
- **Altitude switcher** controls zoom; data set is unchanged. Quarter →
  OKR-as-card. Week → goals with tasks nested. Day → hourly. Hour →
  10-minute subdivisions. Same entity graph, different grouping.
- **"Now" marker** is a 2 px saffron hairline that scrolls with real
  time. Past time fades to 70 % opacity.
- **The whole card is the control surface.** Click anywhere on the card
  to open the iframe; steering happens in the inline chat at the bottom
  of that iframe. **There are no approve / reject / pause buttons** —
  type "send it now", "hold this", "hand off to Priya".
- **Drag a card** to another timeblock or another day to reschedule.
  Repeating cards show a small repeat indicator; repeat pattern is
  edited inside the card iframe.
- **Status icons glow** to communicate state — live (saffron pulse),
  blocked (warning pulse), paused (slow breathe), done (steady success).
- **Horizontal scroll is banned.** Altitude zoom replaces it.
- **One card = one responsible agent.** Agent name + source tool shown.
  When a human takes over, the card gets the human avatar + a "you" tag.

### Block anatomy
- Background: `--ww-on-glass` (solid white) when inside a glass panel;
  `--ww-glass` when rendered directly on the ambient canvas.
- 3px left accent stripe — semantic color:
  - saffron-deep = goal/OKR
  - saffron = task
  - warning = approval-pending
  - danger = blocked / brake
  - success-muted = completed
  - purple-muted = meeting / live session
- Time label: JetBrains Mono 12px `--ww-ink-500`.
- Title: Geist 15px/600, ink-900.
- Meta: Inter 12px/500, ink-500.
- Inline actions: collapsed by default; revealed on `:hover` / `:focus`
  / keyboard `Enter`.

---

## 🎨 VISUAL FOUNDATIONS

### Identity in one line
**Plain glass panels floating on a warm bright-white canvas, with saffron
edges where action lives.** Not glossy, not reflective, not gradient-y —
architectural glass. Calm, instrumentation-grade, warm (never clinical).

### Color
- **Bright white (`#ffffff`)** is the primary surface. Everything sits
  on it. No grey card backgrounds — cards are translucent white glass.
- **Ink scale (`--ww-ink-900 … 300`)** — a cool, slightly-navy black ramp.
  Body is `--ww-ink-700`, not pure black.
- **Single primary accent: Workweaver Saffron `#e8852a`.** Warm, grounded,
  confident. Used for:
  - Primary CTA (filled saffron button with subtle glow shadow)
  - Links, focus ring, active nav, section eyebrow
  - Timeline "now" marker
  - Goal/task left stripes (saffron-deep = goal, saffron = task)
  - The W in the logo
  Never used as a surface fill, never as a gradient, never paired with
  another chromatic accent.
- **Semantic colors are rare and muted.**
  - Success `#12b76a` → proof / shipped / healthy (12% soft fill)
  - Warning `#ffb224` → approval-pending (14% soft fill)
  - Danger `#d9534f` → blocked / emergency brake (12% soft fill)
  - Purple `#8633cc` → meetings / Zara thinking (10% soft fill)
  Full saturation appears only as an icon glyph or a single ink word —
  never a whole surface.

### Typography — free Apple-calm stack
- **Geist** (Vercel's open-source SF-Pro-alike) → display / headings /
  marketing hero. Closest free match to SF Pro Display. Weights
  400/500/600/700/800/900.
- **Inter** → body + UI + chips. 400/500/600/700/800.
- **JetBrains Mono** → code, trace IDs, execution logs, timestamps.
- Use self-hosted font files where available and system fallbacks otherwise.
  Production CSP intentionally blocks remote font stylesheets.
- **Tight tracking** on display/headings (`-0.02em` to `-0.03em`). None
  on body.
- **text-wrap: balance** on h1–h3; **text-wrap: pretty** on prose.
  Non-negotiable.
- **Eyebrows** are ALL-CAPS, 11px, 800 weight, `letter-spacing: 0.14em`,
  saffron accent color.

### Backgrounds
- **Ambient gradient:** three soft saffron-tinted radial bleeds over a
  warm-white linear gradient. Low amplitude — the page reads as white
  with atmosphere, not colored.
- **Never** a dark surface. **Never** a grey fill for a card. **Never** a
  photographic background.

### Plain glass (the load-bearing motif)
This is NOT glossy / iOS-"liquid" / reflective. It is flat architectural
glass — think storefront, not iPhone lock-screen widget.
- Every elevated surface uses:
  - `background: var(--ww-glass)` = `rgba(255, 255, 255, 0.55)`
  - `backdrop-filter: blur(22px) saturate(140%)`
  - `border: 1px solid rgba(18, 28, 48, 0.08)` (hairline)
  - `box-shadow: 0 8px 32px rgba(11, 18, 32, 0.06)` (soft ambient drop)
- **No highlight gradient.** No inner top-edge white sheen. No
  `::before` reflection.
- **Saturation is mild (140%).** Not 180%. We don't want the "pop" of
  candy glass.
- Variants:
  - `--ww-glass` (0.55) — default panel
  - `--ww-glass-strong` (0.72) — sticky header, pinned surfaces
  - `--ww-glass-frost` (0.86) — modal, flyout over scrollable content
- **Elements sitting ON a glass panel are solid `#ffffff`** (the
  `--ww-on-glass` token) with a hairline border. They don't need their
  own blur — they ride on the panel's blur. This produces the desired
  "controls floating on glass" feel.

### Shadows
- 4 tiers: sm / md / lg / xl, plus `glass` (panel-specific) and
  `accent-glow` (saffron, reserved for primary CTA only).
- All shadows use ink-900 at 3–10% alpha. Never pure black.
- No inner shadows.

### Corner radii
- 14px default (buttons, inputs, inline chips-as-boxes).
- 20px cards.
- 28px large glass panels (hero plate, modal, Zara panel).
- 999px pill buttons, chips, badges, avatars.
- 6–10px internals (code snippets, legend dots).
- **Never square corners.**

### Borders
- Default border color: cool navy at ~8% alpha (`--ww-glass-border`).
  Hairline dividers inside cards: `--ww-line` (also 8%). Never thicker
  than 1px. Never pure grey.

### Animation
- **Fast (140ms)** for hovers + state flips.
- **Medium (240ms)** for drawers + modals.
- **Slow (380ms)** only for meaningful reveals.
- Easing: `cubic-bezier(0.2, 0, 0, 1)` (ease-out).
- **Fade + lift** (`opacity 0→1` with `translateY(8→0)`) is the mount.
- No parallax. No scroll-jacked reveals. No stagger cascades.

### Hover + press
- Button lift: `translateY(-1px)` on hover.
- Card lift: `translateY(-2px)` on hover → shadow softens to `lg`.
- Press: `scale(0.98)` for 100ms.
- Link: underline color solidifies from 40% saffron → currentColor on
  hover; text darkens to accent-ink.

### Layout rules
- **No horizontal scrolling. Ever.**
- **Progressive disclosure over stacked disclosure.** No accordions
  inside accordions. When a row expands, nearby rows collapse.
- Fixed elements: sidebar rail (64px) + flyout drawer (232px) on
  desktop; sticky header; bottom mobile nav; Zara launcher
  (bottom-right, above safe-area).
- Max content width: 1200px marketing. No cap on app shell.
- Grid: 4/8/12-column implicit. Gaps from the 4px spacing scale.

### Density + hierarchy
- **One primary action per surface.** Everything else is secondary or
  ghost. A card that has three equal-weight buttons is wrong.
- **One KPI per card header.** Supporting metrics go inline as text.
- **Cards are ≤ 5 rows before scroll.** Deeper = open detail panel.

---

## 🔣 ICONOGRAPHY

- **Font Awesome 6.5.1 free** via CDN — the product's default icon
  system. Used as `<i class="fas fa-X">`, 14–22px, color inherits.
- **Inline feather-style SVGs** (stroke=currentColor, stroke-width=2,
  round caps + joins) on the marketing site — use only where Font
  Awesome lacks a match.
- **UI Avatars** (`ui-avatars.com/api/?name=…&background=E8852A&color=fff`)
  as a fallback avatar generator. Saffron background.
- **No emoji, anywhere.**

### Icon size scale
- 14px inline with text
- 16px sidebar rail items
- 18px dense lists
- 22px card/section titles
- 28px hero/launcher

### Labeling rule
**Every icon has a label** — either visible text or a tooltip on focus.
Icon-only buttons must have `aria-label`. No exceptions. This is how we
deliver "no mystery icons."

---

## Assets manifest (`assets/`)

| File | Use |
| --- | --- |
| `workweaver-logo.svg` | Primary mark — W with integrated gear, "WORK WEAVER" wordmark below. Monochrome ink. |
| `workweaver-logo.png` | Raster of the new mark (user-provided) |
| `Header.webp` | Legacy header-crop logo (for compatibility with landing HTML) |
| `Falcon.webp` | Mark-only crop |
| `bitfoundry-logo.svg` | Parent-org mark |
| `iphone-and-mobile.webp` | Product hero image (mobile context) |
| `favicon-{16,32}.png`, `apple-touch-icon.png` | Favicons |

### Logo rules
- The W + gear mark is **one object.** Never recolor parts.
- Preferred: monochrome `--ww-ink-900` on bright white, or white on
  `--ww-ink-900`.
- Minimum height: 24px (mark + wordmark). Below that, use mark only.
- Clear space: 1× the gear diameter on all sides.
