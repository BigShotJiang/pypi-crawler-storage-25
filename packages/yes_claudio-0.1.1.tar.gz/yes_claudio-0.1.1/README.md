# yes-claudio

Auto-approve Claude Code permission prompts with a denylist and daily limits.

## Install

```bash
pip install yes-claudio
```

## Usage

```bash
# Activate the hook in Claude Code
yes-claudio

# Activate a paid license (unlimited approvals)
yes-claudio activate YOUR-SERIAL-KEY

# Run the hook manually (called by Claude Code automatically)
yes-claudio hook
```

## How it works

- **Free tier:** 10 auto-approvals per day
- **Paid tier ($2):** unlimited approvals — get your key at [gumroad.com](https://bravoevert.gumroad.com/l/yes-claudio)

Installs a `PreToolUse` hook in `~/.claude/settings.json`. Dangerous commands (`rm -rf`, force push, `DROP TABLE`, `sudo`, etc.) are always sent back to you for review.

## License

MIT
