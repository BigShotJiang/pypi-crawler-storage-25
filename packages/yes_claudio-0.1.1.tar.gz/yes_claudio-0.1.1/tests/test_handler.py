import json
from io import StringIO
from unittest.mock import patch

from src.handler import run


def _run_with(payload: dict) -> dict:
    stdin = StringIO(json.dumps(payload))
    stdout = StringIO()
    with patch("sys.stdin", stdin), patch("sys.stdout", stdout):
        run()
    return json.loads(stdout.getvalue())


def _payload(tool="Bash", command="ls -la"):
    return {
        "hook_event_name": "PreToolUse",
        "tool_name": tool,
        "tool_input": {"command": command},
        "session_id": "test",
    }


def _decision(result: dict) -> str:
    return result["hookSpecificOutput"]["permissionDecision"]


# --- Caminho feliz ---

def test_safe_command_free_allows():
    with patch("src.handler.is_paid", return_value=False), \
         patch("src.handler.get_today_count", return_value=0), \
         patch("src.handler.increment"):
        result = _run_with(_payload(command="npm test"))
    assert _decision(result) == "allow"


def test_paid_bypasses_daily_limit():
    with patch("src.handler.is_paid", return_value=True), \
         patch("src.handler.increment"), \
         patch("src.handler.get_today_count", return_value=999):
        result = _run_with(_payload(command="ls"))
    assert _decision(result) == "allow"


# --- Denylist ---

def test_dangerous_command_returns_ask():
    result = _run_with(_payload(command="rm -rf /home"))
    assert _decision(result) == "ask"
    assert "denylist" in result["hookSpecificOutput"]["permissionDecisionReason"]


# --- Limite free ---

def test_daily_limit_returns_ask():
    with patch("src.handler.is_paid", return_value=False), \
         patch("src.handler.get_today_count", return_value=10):
        result = _run_with(_payload(command="ls"))
    assert _decision(result) == "ask"
    assert "Limite" in result["hookSpecificOutput"]["permissionDecisionReason"]


def test_exactly_at_limit_blocks():
    with patch("src.handler.is_paid", return_value=False), \
         patch("src.handler.get_today_count", return_value=10):
        result = _run_with(_payload(command="echo hi"))
    assert _decision(result) == "ask"


def test_below_limit_allows():
    with patch("src.handler.is_paid", return_value=False), \
         patch("src.handler.get_today_count", return_value=9), \
         patch("src.handler.increment"):
        result = _run_with(_payload(command="echo hi"))
    assert _decision(result) == "allow"


# --- Fail-safe ---

def test_invalid_json_returns_ask():
    stdin = StringIO("not {{ valid json")
    stdout = StringIO()
    with patch("sys.stdin", stdin), patch("sys.stdout", stdout):
        run()
    result = json.loads(stdout.getvalue())
    assert _decision(result) == "ask"


def test_exception_in_is_paid_returns_ask():
    with patch("src.handler.is_paid", side_effect=RuntimeError("boom")):
        result = _run_with(_payload(command="ls"))
    assert _decision(result) == "ask"
