import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

import src.license as lic


FAKE_MACHINE = "abc123def456abcd"
NOW = datetime.now(tz=timezone.utc)


def _write_token(path: Path, **overrides) -> dict:
    token = {
        "license_key": "AAAA-BBBB-CCCC-DDDD",
        "valid": True,
        "email": "test@example.com",
        "machine_id": FAKE_MACHINE,
        "last_verified": NOW.isoformat(),
        "uses": 1,
    }
    token.update(overrides)
    path.write_text(json.dumps(token), encoding="utf-8")
    return token


# --- check_local ---

def test_check_local_valid(tmp_path):
    f = tmp_path / "license.json"
    _write_token(f)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        assert lic.check_local(f) is True


def test_check_local_missing_file(tmp_path):
    assert lic.check_local(tmp_path / "license.json") is False


def test_check_local_invalid_flag(tmp_path):
    f = tmp_path / "license.json"
    _write_token(f, valid=False)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        assert lic.check_local(f) is False


def test_check_local_wrong_machine(tmp_path):
    f = tmp_path / "license.json"
    _write_token(f, machine_id="different_machine")
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        assert lic.check_local(f) is False


def test_check_local_grace_expired(tmp_path):
    f = tmp_path / "license.json"
    old_ts = (NOW - timedelta(days=lic.GRACE_DAYS + 1)).isoformat()
    _write_token(f, last_verified=old_ts)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        assert lic.check_local(f) is False


def test_check_local_within_grace(tmp_path):
    f = tmp_path / "license.json"
    recent_ts = (NOW - timedelta(days=lic.GRACE_DAYS - 1)).isoformat()
    _write_token(f, last_verified=recent_ts)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        assert lic.check_local(f) is True


def test_check_local_corrupt_json(tmp_path):
    f = tmp_path / "license.json"
    f.write_text("not json", encoding="utf-8")
    assert lic.check_local(f) is False


# --- activate ---

GUMROAD_SUCCESS = {
    "success": True,
    "purchase": {"email": "buyer@example.com", "uses": 1},
}

GUMROAD_INVALID = {
    "success": False,
    "message": "That license does not exist for the provided product.",
}


def test_activate_no_product_id(tmp_path):
    with patch.object(lic, "PRODUCT_ID", ""):
        ok, msg = lic.activate("AAAA-BBBB-CCCC-DDDD", tmp_path)
    assert ok is False
    assert "product_id" in msg


def test_activate_success(tmp_path):
    with patch.object(lic, "PRODUCT_ID", "fake_pid"), \
         patch.object(lic, "_verify_online", return_value=GUMROAD_SUCCESS), \
         patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        ok, msg = lic.activate("AAAA-BBBB-CCCC-DDDD", tmp_path)
    assert ok is True
    assert "buyer@example.com" in msg
    token = json.loads((tmp_path / "license.json").read_text())
    assert token["valid"] is True
    assert token["machine_id"] == FAKE_MACHINE


def test_activate_invalid_key(tmp_path):
    with patch.object(lic, "PRODUCT_ID", "fake_pid"), \
         patch.object(lic, "_verify_online", return_value=GUMROAD_INVALID):
        ok, msg = lic.activate("XXXX-XXXX-XXXX-XXXX", tmp_path)
    assert ok is False
    assert "license" in msg.lower() or "inválida" in msg.lower() or "product" in msg.lower()


def test_activate_exceeds_max_activations(tmp_path):
    result = {
        "success": True,
        "purchase": {"email": "buyer@example.com", "uses": lic.MAX_ACTIVATIONS + 1},
    }
    with patch.object(lic, "PRODUCT_ID", "fake_pid"), \
         patch.object(lic, "_verify_online", return_value=result):
        ok, msg = lic.activate("AAAA-BBBB-CCCC-DDDD", tmp_path)
    assert ok is False
    assert "máquinas" in msg or "máximo" in msg


# --- refresh ---

def test_refresh_success(tmp_path):
    f = tmp_path / "license.json"
    old_ts = (NOW - timedelta(days=lic.GRACE_DAYS + 1)).isoformat()
    _write_token(f, last_verified=old_ts)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE), \
         patch.object(lic, "_verify_online", return_value=GUMROAD_SUCCESS):
        ok, _ = lic.refresh(f)
    assert ok is True
    token = json.loads(f.read_text())
    assert token["valid"] is True


def test_refresh_revokes_on_failure(tmp_path):
    f = tmp_path / "license.json"
    _write_token(f)
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE), \
         patch.object(lic, "_verify_online", return_value=GUMROAD_INVALID):
        ok, _ = lic.refresh(f)
    assert ok is False
    token = json.loads(f.read_text())
    assert token["valid"] is False


def test_refresh_wrong_machine(tmp_path):
    f = tmp_path / "license.json"
    _write_token(f, machine_id="other_machine")
    with patch.object(lic, "machine_id", return_value=FAKE_MACHINE):
        ok, msg = lic.refresh(f)
    assert ok is False
    assert "máquina" in msg
