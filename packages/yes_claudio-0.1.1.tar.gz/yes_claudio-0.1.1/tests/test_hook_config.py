import json
from pathlib import Path
from unittest.mock import patch

import pytest

import src.gui.hook_config as hc


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")


def _read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


@pytest.fixture()
def sf(tmp_path):
    """Caminho para um settings.json temporário."""
    return tmp_path / ".claude" / "settings.json"


# --- is_hook_active ---

def test_inactive_when_no_file(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        assert hc.is_hook_active() is False


def test_active_when_tag_present(sf):
    _write(sf, {"hooks": {"PreToolUse": [{"matcher": "", "hooks": [{"_tag": hc.HOOK_TAG, "type": "command", "command": "x hook"}]}]}})
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        assert hc.is_hook_active() is True


def test_inactive_without_our_tag(sf):
    _write(sf, {"hooks": {"PreToolUse": [{"matcher": "", "hooks": [{"type": "command", "command": "other"}]}]}})
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        assert hc.is_hook_active() is False


# --- enable_hook ---

def test_enable_creates_file(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
    assert sf.exists()


def test_enable_writes_our_tag(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
    data = _read(sf)
    pre_tool = data["hooks"]["PreToolUse"]
    tags = [h.get("_tag") for e in pre_tool for h in e.get("hooks", [])]
    assert hc.HOOK_TAG in tags


def test_enable_no_duplicate_on_double_call(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
        hc.enable_hook()
    data = _read(sf)
    pre_tool = data["hooks"]["PreToolUse"]
    ours = [h for e in pre_tool for h in e.get("hooks", []) if h.get("_tag") == hc.HOOK_TAG]
    assert len(ours) == 1


def test_enable_preserves_other_hooks(sf):
    _write(sf, {"hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "other-hook"}]}]}})
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
    data = _read(sf)
    pre_tool = data["hooks"]["PreToolUse"]
    others = [h for e in pre_tool for h in e.get("hooks", []) if h.get("command") == "other-hook"]
    assert len(others) == 1


def test_enable_sets_timeout_10(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
    data = _read(sf)
    pre_tool = data["hooks"]["PreToolUse"]
    ours = [h for e in pre_tool for h in e.get("hooks", []) if h.get("_tag") == hc.HOOK_TAG]
    assert ours[0]["timeout"] == 10


# --- disable_hook ---

def test_disable_removes_our_entry(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
        hc.disable_hook()
    data = _read(sf)
    pre_tool = data.get("hooks", {}).get("PreToolUse", [])
    ours = [h for e in pre_tool for h in e.get("hooks", []) if h.get("_tag") == hc.HOOK_TAG]
    assert len(ours) == 0


def test_disable_removes_empty_hooks_key(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
        hc.disable_hook()
    data = _read(sf)
    assert "hooks" not in data


def test_disable_preserves_other_hooks(sf):
    _write(sf, {"hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "other-hook"}]}]}})
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
        hc.disable_hook()
    data = _read(sf)
    pre_tool = data.get("hooks", {}).get("PreToolUse", [])
    others = [h for e in pre_tool for h in e.get("hooks", []) if h.get("command") == "other-hook"]
    assert len(others) == 1


def test_disable_on_inactive_does_not_raise(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.disable_hook()


def test_disable_on_missing_file_does_not_raise(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.disable_hook()
    assert not sf.exists()


# --- round-trip ---

def test_enable_disable_enable_round_trip(sf):
    with patch.object(hc, "CLAUDE_SETTINGS", sf):
        hc.enable_hook()
        assert hc.is_hook_active() is True
        hc.disable_hook()
        assert hc.is_hook_active() is False
        hc.enable_hook()
        assert hc.is_hook_active() is True
