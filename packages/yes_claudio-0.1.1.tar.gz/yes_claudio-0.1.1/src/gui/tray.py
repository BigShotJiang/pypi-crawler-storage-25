import subprocess
import sys

import pystray
from PIL import Image, ImageDraw

from .hook_config import disable_hook, enable_hook, is_hook_active


def _icon_image(active: bool) -> Image.Image:
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    fill = (34, 197, 94) if active else (107, 114, 128)
    draw.ellipse([4, 4, size - 4, size - 4], fill=fill)
    return img


def _panel_cmd() -> list[str]:
    if getattr(sys, "frozen", False):
        return [sys.executable, "panel"]
    return [sys.executable, "-m", "src.main", "panel"]


def run_tray() -> None:
    def open_panel(icon, item):
        subprocess.Popen(_panel_cmd())

    def toggle(icon, item):
        if is_hook_active():
            disable_hook()
        else:
            enable_hook()
        icon.icon = _icon_image(is_hook_active())

    def quit_app(icon, item):
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem("Abrir Painel", open_panel, default=True),
        pystray.MenuItem("Ativar / Desativar Hook", toggle),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Sair", quit_app),
    )

    pystray.Icon(
        name="autoconfirm",
        icon=_icon_image(is_hook_active()),
        title="Auto-Confirm",
        menu=menu,
    ).run()
