import re
import tkinter as tk
from tkinter import messagebox, ttk

from ..denylist import BASH_PATTERNS
from ..license import activate, check_local
from ..storage import CONFIG_DIR, FREE_LIMIT, LICENSE_FILE, get_today_count, load_custom_denylist, save_custom_denylist
from .hook_config import disable_hook, enable_hook, is_hook_active


class Panel:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Auto-Confirm — Claude Code")
        self.root.geometry("380x280")
        self.root.resizable(False, False)
        self._build()
        self._refresh()

    def _build(self):
        pad = {"padx": 12, "pady": 6}

        # --- Status ---
        status = ttk.LabelFrame(self.root, text="Status")
        status.pack(fill="x", **pad)

        self.lbl_count = ttk.Label(status, text="")
        self.lbl_count.pack(anchor="w", padx=8, pady=2)

        self.lbl_license = ttk.Label(status, text="")
        self.lbl_license.pack(anchor="w", padx=8, pady=2)

        self.hook_var = tk.BooleanVar()
        ttk.Checkbutton(
            status,
            text="Hook ativo (aprovação automática ligada)",
            variable=self.hook_var,
            command=self._toggle_hook,
        ).pack(anchor="w", padx=8, pady=4)

        # --- Licença ---
        lic = ttk.LabelFrame(self.root, text="Ativar Licença")
        lic.pack(fill="x", **pad)

        self.serial_var = tk.StringVar()
        row = ttk.Frame(lic)
        row.pack(fill="x", padx=8, pady=6)
        ttk.Entry(row, textvariable=self.serial_var, width=28).pack(side="left")
        ttk.Button(row, text="Ativar", command=self._activate).pack(side="left", padx=6)

        btn_row = ttk.Frame(self.root)
        btn_row.pack(pady=4)
        ttk.Button(btn_row, text="Atualizar", command=self._refresh).pack(side="left", padx=4)
        ttk.Button(btn_row, text="Editar Denylist", command=self._open_denylist).pack(side="left", padx=4)

    def _refresh(self):
        count = get_today_count()
        paid = check_local(LICENSE_FILE)

        if paid:
            self.lbl_count.config(text=f"Aprovações hoje: {count}  (ilimitado)")
            self.lbl_license.config(text="Licença: Paga ✓", foreground="green")
        else:
            remaining = max(0, FREE_LIMIT - count)
            self.lbl_count.config(
                text=f"Aprovações hoje: {count}/{FREE_LIMIT}  ({remaining} restantes)"
            )
            self.lbl_license.config(text="Licença: Gratuita", foreground="#888888")

        self.hook_var.set(is_hook_active())

    def _toggle_hook(self):
        if self.hook_var.get():
            enable_hook()
        else:
            disable_hook()

    def _activate(self):
        key = self.serial_var.get().strip()
        if not key:
            messagebox.showwarning("Serial vazia", "Cole a serial recebida por email.")
            return
        ok, msg = activate(key, CONFIG_DIR)
        if ok:
            messagebox.showinfo("Licença ativada", msg)
            self.serial_var.set("")
        else:
            messagebox.showerror("Erro na ativação", msg)
        self._refresh()

    def _open_denylist(self):
        DenylistEditor(self.root)

    def run(self):
        self.root.mainloop()


class DenylistEditor(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Editar Denylist")
        self.geometry("540x420")
        self.resizable(False, False)
        self.grab_set()
        self._build()
        self._populate()

    def _build(self):
        pad = {"padx": 10, "pady": 6}

        # --- Lista de padrões ---
        frame_list = ttk.LabelFrame(self, text="Padrões ativos")
        frame_list.pack(fill="both", expand=True, **pad)

        scroll = ttk.Scrollbar(frame_list)
        scroll.pack(side="right", fill="y")
        self.listbox = tk.Listbox(frame_list, yscrollcommand=scroll.set, width=60, height=12, selectmode="single")
        self.listbox.pack(side="left", fill="both", expand=True, padx=(4, 0), pady=4)
        scroll.config(command=self.listbox.yview)

        ttk.Button(frame_list, text="Remover selecionado", command=self._remove).pack(pady=(0, 4))

        # --- Adicionar padrão ---
        frame_add = ttk.LabelFrame(self, text="Adicionar padrão (regex)")
        frame_add.pack(fill="x", **pad)

        self.new_pattern_var = tk.StringVar()
        row = ttk.Frame(frame_add)
        row.pack(fill="x", padx=8, pady=6)
        ttk.Entry(row, textvariable=self.new_pattern_var, width=38).pack(side="left")
        ttk.Button(row, text="Adicionar", command=self._add).pack(side="left", padx=6)

        # --- Testar padrão ---
        frame_test = ttk.LabelFrame(self, text="Testar contra comando")
        frame_test.pack(fill="x", **pad)

        self.test_cmd_var = tk.StringVar()
        row2 = ttk.Frame(frame_test)
        row2.pack(fill="x", padx=8, pady=6)
        ttk.Entry(row2, textvariable=self.test_cmd_var, width=38).pack(side="left")
        ttk.Button(row2, text="Testar", command=self._test).pack(side="left", padx=6)

        # --- Salvar ---
        ttk.Button(self, text="Salvar", command=self._save).pack(pady=6)

    def _populate(self):
        self.listbox.delete(0, tk.END)
        for _, reason in BASH_PATTERNS:
            self.listbox.insert(tk.END, f"[builtin] {reason}")
        self._custom = load_custom_denylist()
        for p in self._custom:
            self.listbox.insert(tk.END, p)
        self._builtin_count = len(BASH_PATTERNS)

    def _add(self):
        raw = self.new_pattern_var.get().strip()
        if not raw:
            return
        try:
            re.compile(raw)
        except re.error as e:
            messagebox.showerror("Regex inválido", f"Padrão não compila:\n{e}", parent=self)
            return
        self._custom.append(raw)
        self.listbox.insert(tk.END, raw)
        self.new_pattern_var.set("")

    def _remove(self):
        idx = self.listbox.curselection()
        if not idx:
            return
        i = idx[0]
        if i < self._builtin_count:
            messagebox.showwarning("Padrão builtin", "Padrões builtin não podem ser removidos.", parent=self)
            return
        custom_idx = i - self._builtin_count
        self._custom.pop(custom_idx)
        self.listbox.delete(i)

    def _test(self):
        cmd = self.test_cmd_var.get()
        if not cmd:
            return
        # testa todos os padrões (builtin + custom)
        from ..denylist import check_bash
        reason = check_bash(cmd)
        if reason:
            messagebox.showinfo("Bloqueado", f"Comando seria bloqueado:\n{reason}", parent=self)
        else:
            messagebox.showinfo("Permitido", "Comando seria aprovado (nenhum padrão bateu).", parent=self)

    def _save(self):
        save_custom_denylist(self._custom)
        messagebox.showinfo("Salvo", f"{len(self._custom)} padrão(ões) custom salvos.", parent=self)
        self.destroy()
