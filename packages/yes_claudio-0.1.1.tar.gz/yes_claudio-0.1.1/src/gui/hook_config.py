import json
import shutil
import sys
from pathlib import Path

CLAUDE_SETTINGS = Path.home() / ".claude" / "settings.json"
HOOK_TAG = "autoconfirm-hook"


def _binary_command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}" hook'
    entry = shutil.which("yes-claudio")
    if entry:
        return f'"{entry}" hook'
    return f'"{sys.executable}" -m src.main hook'


def _load() -> dict:
    if not CLAUDE_SETTINGS.exists():
        return {}
    try:
        return json.loads(CLAUDE_SETTINGS.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save(data: dict) -> None:
    CLAUDE_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    CLAUDE_SETTINGS.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def _our_entries(pre_tool: list) -> list:
    return [
        e for e in pre_tool
        if any(h.get("_tag") == HOOK_TAG for h in e.get("hooks", []))
    ]


def _other_entries(pre_tool: list) -> list:
    return [
        e for e in pre_tool
        if not any(h.get("_tag") == HOOK_TAG for h in e.get("hooks", []))
    ]


def is_hook_active() -> bool:
    pre_tool = _load().get("hooks", {}).get("PreToolUse", [])
    return bool(_our_entries(pre_tool))


def enable_hook() -> None:
    data = _load()
    pre_tool = data.setdefault("hooks", {}).get("PreToolUse", [])
    updated = _other_entries(pre_tool) + [{
        "matcher": "",
        "hooks": [{
            "type": "command",
            "command": _binary_command(),
            "timeout": 10,
            "_tag": HOOK_TAG,
        }]
    }]
    data["hooks"]["PreToolUse"] = updated
    _save(data)


def disable_hook() -> None:
    if not CLAUDE_SETTINGS.exists():
        return
    data = _load()
    pre_tool = data.get("hooks", {}).get("PreToolUse", [])
    remaining = _other_entries(pre_tool)

    if remaining:
        data["hooks"]["PreToolUse"] = remaining
    else:
        data.get("hooks", {}).pop("PreToolUse", None)
        if not data.get("hooks"):
            data.pop("hooks", None)
    _save(data)
