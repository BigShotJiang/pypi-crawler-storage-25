import json
import sys
from typing import Any

from .denylist import is_dangerous
from .storage import FREE_LIMIT, get_today_count, increment, is_paid


def _respond(decision: str, reason: str = "") -> None:
    out: dict[str, Any] = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": decision,
        }
    }
    if reason:
        out["hookSpecificOutput"]["permissionDecisionReason"] = reason
    print(json.dumps(out), flush=True)


def run() -> int:
    try:
        payload = json.loads(sys.stdin.read())
        tool_name: str = payload.get("tool_name", "")
        tool_input: dict = payload.get("tool_input", {})

        # 1. Denylist — devolve ao humano sem contar
        danger = is_dangerous(tool_name, tool_input)
        if danger:
            _respond("ask", f"Bloqueado pela denylist: {danger}")
            return 0

        # 2. Licença paga → ilimitado
        if is_paid():
            increment(tool_name, tool_input)
            _respond("allow")
            return 0

        # 3. Free: cap de 10/dia
        if get_today_count() >= FREE_LIMIT:
            _respond(
                "ask",
                f"Limite diário de {FREE_LIMIT} aprovações atingido. "
                "Ative a licença para aprovar sem limite.",
            )
            return 0

        increment(tool_name, tool_input)
        _respond("allow")
        return 0

    except Exception as exc:  # noqa: BLE001 — fail-safe: qualquer erro → ask
        _respond("ask", f"Erro interno no handler: {exc}")
        return 0
