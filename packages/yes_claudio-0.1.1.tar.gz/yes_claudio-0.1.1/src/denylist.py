import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

# (padrão, motivo legível)
BASH_PATTERNS: list[tuple[str, str]] = [
    (r"\brm\s+(-[a-zA-Z]*r[a-zA-Z]*f|-[a-zA-Z]*f[a-zA-Z]*r)\b", "remoção recursiva (rm -rf)"),
    (r"\brm\s+.*--force\b.*-r\b", "remoção recursiva com --force"),
    (r"\bgit\s+push\s+.*(-f\b|--force\b)", "git push --force"),
    (r"\bgit\s+reset\s+--hard\b", "git reset --hard"),
    (r"\bgit\s+clean\s+.*-f\b", "git clean -f"),
    (r"\bDROP\s+(TABLE|DATABASE|SCHEMA|INDEX)\b", "DROP SQL destrutivo"),
    (r"\bTRUNCATE\b", "TRUNCATE SQL"),
    (r"\bsudo\b", "escalada de privilégio (sudo)"),
    (r"\bdd\s+if=", "escrita direta em disco (dd)"),
    (r"\bmkfs\b", "formatação de disco (mkfs)"),
    (r"\bfdisk\b", "particionamento de disco (fdisk)"),
    (r">\s*/dev/(sd[a-z]|hd[a-z]|nvme)", "redirecionamento para dispositivo de bloco"),
    (r"\bshutdown\b", "desligamento do sistema"),
    (r"\breboot\b", "reinicialização do sistema"),
    (r"\bhalt\b", "parada do sistema"),
    (r"\bpoweroff\b", "desligamento do sistema"),
    (r":\(\)\s*\{", "fork bomb"),
    (r"(curl|wget)\b.*\|\s*(ba|da|z|fi)?sh\b", "download e execução direta de script"),
    (r"\bshred\b", "wipe seguro de arquivo (shred)"),
    (r"\bchmod\s+.*777\s+(/|/home|/etc)", "chmod 777 em diretório de sistema"),
]

FILE_PATH_PATTERNS: list[tuple[str, str]] = [
    (r"^/etc/", "diretório de configuração do sistema (/etc)"),
    (r"^/usr/", "diretório de sistema (/usr)"),
    (r"^/bin/", "diretório de binários do sistema (/bin)"),
    (r"^/sbin/", "diretório de binários de sistema (/sbin)"),
    (r"^/boot/", "diretório de boot (/boot)"),
    (r"^/sys/", "sistema de arquivos virtual (/sys)"),
    (r"^/proc/", "sistema de arquivos virtual (/proc)"),
    (r"^/dev/", "diretório de dispositivos (/dev)"),
]

_bash_compiled = [(re.compile(p, re.IGNORECASE), reason) for p, reason in BASH_PATTERNS]
_path_compiled = [(re.compile(p), reason) for p, reason in FILE_PATH_PATTERNS]


def _load_custom_compiled() -> list[tuple[re.Pattern, str]]:
    from .storage import load_custom_denylist
    result = []
    for raw in load_custom_denylist():
        try:
            result.append((re.compile(raw, re.IGNORECASE), f"padrão customizado: {raw}"))
        except re.error:
            logger.warning("Padrão inválido ignorado: %r", raw)
    return result


def check_bash(command: str) -> Optional[str]:
    for pattern, reason in _bash_compiled:
        if pattern.search(command):
            return reason
    for pattern, reason in _load_custom_compiled():
        if pattern.search(command):
            return reason
    return None


def check_file_path(path: str) -> Optional[str]:
    for pattern, reason in _path_compiled:
        if pattern.match(path):
            return reason
    return None


def is_dangerous(tool_name: str, tool_input: dict) -> Optional[str]:
    """Retorna motivo legível se perigoso, None se seguro."""
    if tool_name == "Bash":
        return check_bash(tool_input.get("command", ""))
    if tool_name in ("Edit", "Write"):
        return check_file_path(tool_input.get("file_path", ""))
    return None
