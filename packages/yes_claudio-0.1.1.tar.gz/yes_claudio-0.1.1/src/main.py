import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="yes-claudio",
        description="Auto-Confirm para Claude Code",
    )
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("hook", help="Modo handler — chamado pelo Claude Code via PreToolUse")
    sub.add_parser("app", help="Abre o ícone de bandeja + painel")
    sub.add_parser("panel", help="Abre só o painel (janela tkinter)")
    act = sub.add_parser("activate", help="Ativar licença via serial Gumroad")
    act.add_argument("serial", help="Serial recebida por email após compra")

    args = parser.parse_args()

    if args.cmd == "hook":
        from .handler import run
        sys.exit(run())
    elif args.cmd == "panel":
        from .gui.panel import Panel
        Panel().run()
    elif args.cmd == "app":
        try:
            from .gui.tray import run_tray
            run_tray()
        except Exception as exc:
            # Fallback: abre só o painel se tray falhar (headless, etc.)
            print(f"Tray indisponível ({exc}), abrindo painel direto.")
            from .gui.panel import Panel
            Panel().run()
    elif args.cmd == "activate":
        from .license import activate
        from .storage import CONFIG_DIR
        ok, msg = activate(args.serial, CONFIG_DIR)
        print(msg)
        sys.exit(0 if ok else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
