import json
import os
from datetime import date
from pathlib import Path

CONFIG_DIR = Path(
    os.environ.get("AUTOCONFIRM_CONFIG_DIR", Path.home() / ".config" / "autoconfirm")
)
DATA_FILE = CONFIG_DIR / "data.json"
LICENSE_FILE = CONFIG_DIR / "license.json"
DENYLIST_FILE = CONFIG_DIR / "denylist.json"

FREE_LIMIT = 10
LOG_MAX = 200


def _load() -> dict:
    if not DATA_FILE.exists():
        return {"daily": {}, "log": []}
    try:
        return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"daily": {}, "log": []}


def _save(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def get_today_count() -> int:
    return _load()["daily"].get(date.today().isoformat(), 0)


def increment(tool_name: str, tool_input: dict) -> int:
    data = _load()
    today = date.today().isoformat()
    data["daily"][today] = data["daily"].get(today, 0) + 1
    entry = {
        "date": today,
        "tool": tool_name,
        "cmd": _summarize(tool_input),
    }
    data["log"] = (data.get("log", []) + [entry])[-LOG_MAX:]
    _save(data)
    return data["daily"][today]


def is_paid() -> bool:
    from .license import check_local
    return check_local(LICENSE_FILE)


def load_custom_denylist() -> list[str]:
    if not DENYLIST_FILE.exists():
        return []
    try:
        data = json.loads(DENYLIST_FILE.read_text(encoding="utf-8"))
        return [p for p in data if isinstance(p, str)]
    except (json.JSONDecodeError, OSError):
        return []


def save_custom_denylist(patterns: list[str]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    DENYLIST_FILE.write_text(json.dumps(patterns, indent=2, ensure_ascii=False), encoding="utf-8")


def _summarize(tool_input: dict) -> str:
    cmd = tool_input.get("command") or tool_input.get("file_path") or ""
    return cmd[:80]
