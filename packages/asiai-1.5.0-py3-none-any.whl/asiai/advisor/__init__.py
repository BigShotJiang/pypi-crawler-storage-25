"""Hardware-aware recommendation engine."""
