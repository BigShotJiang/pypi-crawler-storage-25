"""SQLite metrics storage."""
