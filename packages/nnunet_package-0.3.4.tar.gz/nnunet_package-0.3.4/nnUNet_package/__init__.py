__version__ = "0.3.4"
from .predict import GLOBAL_CONTEXT