"""Coordinator — auto-decompose tasks and dispatch to swarm workers."""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import Any, Literal

from llm_code.api.provider import LLMProvider
from llm_code.api.types import Message, MessageRequest, TextBlock
from llm_code.swarm.manager import SwarmManager

logger = logging.getLogger(__name__)

_DECOMPOSE_PROMPT = """\
Break the following task into independent subtasks that can be executed in parallel by specialized agents.

Output ONLY a JSON array (no explanation, no markdown fences). Each element must have:
  - "role": a short role label (e.g. "coder", "tester", "reviewer", "researcher")
  - "task": a clear, self-contained task description

Example output:
[
  {{"role": "coder", "task": "Implement the binary search function in utils.py"}},
  {{"role": "tester", "task": "Write unit tests for the binary search function"}}
]

Task to decompose:
{task}
"""

_SYNTHESIZE_PROMPT = """\
Before delegating this task, analyze what you already know and what needs investigation.

Task: {task}

Reply with ONLY a JSON object (no explanation):
{{
  "known_facts": ["list of things you can determine from the task description"],
  "unknowns": ["list of things that need investigation or implementation"],
  "should_delegate": true or false,
  "reason": "why delegate or not"
}}

If the task is simple enough to handle directly (e.g. a question, single-file change), set should_delegate=false.
"""

_AGGREGATE_PROMPT = """\
You are a coordinator agent summarizing the results of parallel worker agents.

Original task: {original_task}

Worker results:
{results}

Provide a concise summary of what was accomplished, any issues encountered, and the combined outcome.
"""


class Coordinator:
    """Orchestrate task decomposition and parallel worker dispatch.

    Sends the original task to the LLM for decomposition into subtasks,
    creates swarm members per subtask, monitors completion via the mailbox,
    then aggregates results with a final LLM summary.
    """

    POLL_INTERVAL: float = 5.0
    TIMEOUT: float = 300.0
    COORDINATOR_ID: str = "coordinator"
    SYNTHESIZE_MIN_CHARS: int = 200

    def __init__(
        self,
        manager: SwarmManager,
        provider: LLMProvider,
        config: Any,
    ) -> None:
        self._manager = manager
        self._provider = provider
        self._config = config

    async def orchestrate(self, task: str, resume_member_ids: list[str] | None = None) -> str:
        """Synthesize → decompose → dispatch → wait → aggregate.

        Args:
            task: High-level task description to decompose and delegate.
            resume_member_ids: Optional list of existing swarm member IDs to
                reuse instead of spawning fresh ones. Each member receives the
                same subtask as before, but in their accumulated context.
                Set to None for fresh spawn.

        Returns:
            Aggregated summary string from all worker results.
        """
        # Synthesis-first: analyze before delegating
        synthesis = await self._synthesize(task)
        if synthesis and not synthesis.get("should_delegate", True):
            reason = synthesis.get("reason", "Task is simple enough to handle directly.")
            return f"[Coordinator] Skipping delegation: {reason}"

        members: list = []
        # Resume path: reuse existing swarm members instead of decomposing fresh
        if resume_member_ids:
            for mid in resume_member_ids:
                member = self._manager.get_member(mid)
                if member is not None:
                    members.append(member)
                    logger.info("Resuming swarm member %s (%s)", member.id, member.role)
                else:
                    logger.warning("Cannot resume — member not found: %s", mid)

            if not members:
                # Fall through to fresh spawn if all resume targets are gone
                resume_member_ids = None

        if not resume_member_ids:
            # Consult _select_delegation_target against any pre-existing
            # manager members — if there's a high-overlap match, reuse it
            # rather than spawning fresh.
            try:
                existing_members = list(self._manager.list_members())
            except Exception:
                existing_members = []
            if existing_members:
                decision, target = self._select_delegation_target(task, existing_members)
                if decision == "resume":
                    reused = self._manager.get_member(target)
                    if reused is not None:
                        members.append(reused)
                        logger.info(
                            "Resuming swarm member %s via overlap match", reused.id
                        )

        if not resume_member_ids and not members:
            subtasks = await self._decompose(task)
            if not subtasks:
                return f"No subtasks generated for: {task}"

            max_members = getattr(
                getattr(self._config, "swarm", None), "max_members", 5
            )
            subtasks = subtasks[:max_members]

            for subtask in subtasks:
                role = subtask.get("role", "worker")
                subtask_desc = subtask.get("task", "")
                if not subtask_desc:
                    continue
                try:
                    member = await self._manager.create_member(role=role, task=subtask_desc)
                    members.append(member)
                    logger.info("Spawned swarm member %s (%s)", member.id, role)
                except ValueError as exc:
                    logger.warning("Could not create member for role=%s: %s", role, exc)
                    break

        if not members:
            return "Failed to create any swarm members."

        results = await self._wait_for_completion(
            member_ids=[m.id for m in members],
            timeout=self.TIMEOUT,
            poll_interval=self.POLL_INTERVAL,
        )

        summary = await self._aggregate(task, members, results)
        # Append resumable IDs so caller can continue this group later
        ids_line = ", ".join(m.id for m in members)
        return f"{summary}\n\n[Resumable swarm member IDs: {ids_line}]"

    async def _synthesize(self, task: str) -> dict | None:
        """Analyze task before delegation — decide whether to delegate at all.

        Returns a dict with known_facts, unknowns, should_delegate, reason.
        Returns None if synthesis fails (fallback: proceed with delegation).
        """
        synthesis_enabled = getattr(
            getattr(self._config, "swarm", None), "synthesis_enabled", True
        )
        if not synthesis_enabled:
            return None

        # Short-circuit: trivially small tasks skip the LLM round-trip and
        # return a stub synthesis indicating "delegate as usual".
        if len(task) < self.SYNTHESIZE_MIN_CHARS:
            return {
                "known_facts": [],
                "unknowns": [task],
                "should_delegate": True,
                "reason": "stub: task below synthesis short-circuit threshold",
            }

        prompt = _SYNTHESIZE_PROMPT.format(task=task)
        model = getattr(self._config, "model", None) or "default"
        request = MessageRequest(
            model=model,
            messages=(Message(role="user", content=(TextBlock(text=prompt),)),),
            max_tokens=512,
            stream=False,
        )
        try:
            response = await self._provider.send_message(request)
            text = ""
            for block in response.content:
                if isinstance(block, TextBlock):
                    text += block.text
            parsed = self._parse_json_object(text)
            if parsed and isinstance(parsed.get("should_delegate"), bool):
                return parsed
            return None
        except Exception as exc:
            logger.debug("Synthesis failed (proceeding with delegation): %s", exc)
            return None

    @staticmethod
    def _parse_json_object(text: str) -> dict | None:
        """Extract a JSON object from LLM output."""
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip().rstrip("`").strip()
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start == -1 or end == -1:
            return None
        try:
            data = json.loads(cleaned[start : end + 1])
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            return None

    def _select_delegation_target(
        self,
        task: str,
        candidates: list[Any],
    ) -> tuple[Literal["resume", "spawn"], Any]:
        """Decide whether to resume an existing worker or spawn a new one.

        For each candidate (a swarm member with ``.id`` and ``.context``
        or ``.task`` attributes), compute :func:`context_overlap` between
        its accumulated context and *task*. If the maximum overlap meets
        or exceeds ``swarm.overlap_threshold``, return
        ``("resume", member_id)``; otherwise return ``("spawn", task)``.
        """
        threshold = float(
            getattr(getattr(self._config, "swarm", None), "overlap_threshold", 0.6)
        )
        best_score = -1.0
        best_id: Any = None
        for member in candidates or []:
            ctx = (
                getattr(member, "context", None)
                or getattr(member, "task", None)
                or ""
            )
            score = self.context_overlap(str(ctx), task)
            if score > best_score:
                best_score = score
                best_id = getattr(member, "id", member)
        if best_id is not None and best_score >= threshold:
            logger.info(
                "delegation: resume member=%s overlap=%.2f >= threshold=%.2f",
                best_id,
                best_score,
                threshold,
            )
            return ("resume", best_id)
        logger.info(
            "delegation: spawn (best_overlap=%.2f < threshold=%.2f)",
            max(best_score, 0.0),
            threshold,
        )
        return ("spawn", task)

    @staticmethod
    def context_overlap(worker_context: str, next_task: str) -> float:
        """Compute token-level overlap between a worker's context and next task.

        Returns a score 0.0-1.0. Higher = more overlap = better to continue
        the same worker rather than spawning fresh.
        """
        from llm_code.runtime.skill_router import tokenize

        worker_tokens = set(tokenize(worker_context))
        task_tokens = set(tokenize(next_task))
        if not task_tokens:
            return 0.0
        overlap = worker_tokens & task_tokens
        return len(overlap) / len(task_tokens)

    async def _decompose(self, task: str) -> list[dict]:
        """Ask the LLM to decompose task into subtasks. Returns list of dicts."""
        prompt = _DECOMPOSE_PROMPT.format(task=task)
        model = getattr(self._config, "model", None) or "default"
        request = MessageRequest(
            model=model,
            messages=(
                Message(
                    role="user",
                    content=(TextBlock(text=prompt),),
                ),
            ),
            max_tokens=1024,
            stream=False,
        )
        try:
            response = await self._provider.send_message(request)
            text = ""
            for block in response.content:
                if isinstance(block, TextBlock):
                    text += block.text
            return self._parse_json_list(text)
        except Exception as exc:
            logger.error("Decomposition failed: %s", exc)
            return []

    def _parse_json_list(self, text: str) -> list[dict]:
        """Extract a JSON array from LLM output (strips markdown fences)."""
        # Strip markdown code fences if present
        cleaned = re.sub(r"```(?:json)?\s*", "", text).strip().rstrip("`").strip()
        # Find first '[' and last ']'
        start = cleaned.find("[")
        end = cleaned.rfind("]")
        if start == -1 or end == -1:
            logger.warning("Could not find JSON array in decomposition output: %r", text[:200])
            return []
        try:
            data = json.loads(cleaned[start : end + 1])
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
            return []
        except json.JSONDecodeError as exc:
            logger.warning("JSON parse error in decomposition: %s", exc)
            return []

    async def _wait_for_completion(
        self,
        member_ids: list[str],
        timeout: float,
        poll_interval: float,
    ) -> dict[str, list[str]]:
        """Poll the mailbox until all members report completion or timeout.

        Each member is expected to send a message to COORDINATOR_ID containing
        "DONE" or "COMPLETE" when finished.

        Returns:
            Mapping of member_id -> list of message texts received.
        """
        results: dict[str, list[str]] = {mid: [] for mid in member_ids}
        completed: set[str] = set()
        elapsed = 0.0

        while len(completed) < len(member_ids) and elapsed < timeout:
            for mid in member_ids:
                if mid in completed:
                    continue
                msgs = self._manager.mailbox.receive_and_clear(
                    from_id=mid, to_id=self.COORDINATOR_ID
                )
                for msg in msgs:
                    results[mid].append(msg.text)
                    upper = msg.text.upper()
                    if "DONE" in upper or "COMPLETE" in upper or "FINISHED" in upper:
                        completed.add(mid)
                        logger.info("Member %s reported completion", mid)

            if len(completed) < len(member_ids):
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval

        if elapsed >= timeout:
            logger.warning(
                "Coordinator timed out waiting for members: %s",
                [mid for mid in member_ids if mid not in completed],
            )

        return results

    async def _aggregate(self, original_task: str, members: list, results: dict[str, list[str]]) -> str:
        """Ask the LLM to aggregate all worker results into a summary."""
        result_lines = []
        for member in members:
            texts = results.get(member.id, [])
            result_lines.append(
                f"[{member.role}] {member.task}\n"
                + (("\n".join(texts)) if texts else "(no output received)")
            )

        results_text = "\n\n".join(result_lines)
        prompt = _AGGREGATE_PROMPT.format(
            original_task=original_task,
            results=results_text,
        )
        model = getattr(self._config, "model", None) or "default"
        request = MessageRequest(
            model=model,
            messages=(
                Message(
                    role="user",
                    content=(TextBlock(text=prompt),),
                ),
            ),
            max_tokens=2048,
            stream=False,
        )
        try:
            response = await self._provider.send_message(request)
            text = ""
            for block in response.content:
                if isinstance(block, TextBlock):
                    text += block.text
            return text.strip() or results_text
        except Exception as exc:
            logger.error("Aggregation LLM call failed: %s", exc)
            return results_text
