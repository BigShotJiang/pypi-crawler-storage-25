"""IDE integration package."""
