"""Check: secrets-scan — busca patrones de API keys y tokens hardcodeados."""

from __future__ import annotations

import os
import re

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "secrets-scan",
    "name": "Escaneo de secretos hardcodeados",
    "category": "security",
    "severity": "high",
}

_SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS Access Key ID"),
    (re.compile(r"ghp_[A-Za-z0-9]{36}"), "GitHub Personal Access Token"),
    (re.compile(r"ghs_[A-Za-z0-9]{36}"), "GitHub Actions Token"),
    (
        re.compile(r"(?i)api[_-]?key\s*[=:]\s*['\"][A-Za-z0-9+/._-]{16,}['\"]"),
        "API key assignment",
    ),
    (
        re.compile(r"(?i)secret[_-]?key\s*[=:]\s*['\"][A-Za-z0-9+/._-]{16,}['\"]"),
        "Secret key assignment",
    ),
    (
        re.compile(r"(?i)access[_-]?token\s*[=:]\s*['\"][A-Za-z0-9+/._-]{20,}['\"]"),
        "Access token assignment",
    ),
    (
        re.compile(r"(?i)private[_-]?key\s*[=:]\s*['\"][A-Za-z0-9+/._-]{20,}['\"]"),
        "Private key assignment",
    ),
]

_EXCLUDED_DIRS = frozenset(
    {
        "node_modules",
        ".git",
        "__pycache__",
        ".venv",
        "venv",
        "dist",
        "build",
        ".eggs",
        "*.egg-info",
    }
)

_EXCLUDED_EXTENSIONS = frozenset(
    {
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".ico",
        ".svg",
        ".bin",
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".woff",
        ".woff2",
        ".ttf",
        ".eot",
        ".zip",
        ".tar",
        ".gz",
        ".bz2",
        ".lock",
    }
)

_MAX_FILE_SIZE_BYTES = 512 * 1024  # 512 KB
_MAX_FILES_SCANNED = 500


def _walk_text_files(repo_path: str):
    """Yield (relative_path, absolute_path) for scannable text files."""
    count = 0
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in _EXCLUDED_DIRS]
        for fname in sorted(files):
            ext = os.path.splitext(fname)[1].lower()
            if ext in _EXCLUDED_EXTENSIONS:
                continue
            abs_path = os.path.join(root, fname)
            if os.path.getsize(abs_path) > _MAX_FILE_SIZE_BYTES:
                continue
            rel_path = os.path.relpath(abs_path, repo_path).replace("\\", "/")
            yield rel_path, abs_path
            count += 1
            if count >= _MAX_FILES_SCANNED:
                return


def run(repo_path: str) -> CheckResult:
    findings: list[dict[str, object]] = []
    files_scanned = 0

    for rel_path, abs_path in _walk_text_files(repo_path):
        files_scanned += 1
        try:
            with open(abs_path, encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except OSError:
            continue

        for pattern, label in _SECRET_PATTERNS:
            for match in pattern.finditer(content):
                line_num = content[: match.start()].count("\n") + 1
                findings.append(
                    {
                        "file": rel_path,
                        "line": line_num,
                        "pattern": label,
                    }
                )

    return {
        "ok": not findings,
        "findings": findings,
        "files_scanned": files_scanned,
        "patterns_checked": len(_SECRET_PATTERNS),
    }
