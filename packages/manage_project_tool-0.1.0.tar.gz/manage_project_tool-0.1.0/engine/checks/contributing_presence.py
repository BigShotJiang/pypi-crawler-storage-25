"""Check: contributing-presence — verifica que existe CONTRIBUTING.md."""

from __future__ import annotations

import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "contributing-presence",
    "name": "CONTRIBUTING presente",
    "category": "docs",
    "severity": "medium",
}

_CANDIDATES = [
    "CONTRIBUTING.md",
    "CONTRIBUTING.rst",
    "CONTRIBUTING.txt",
    "CONTRIBUTING",
    ".github/CONTRIBUTING.md",
    "docs/CONTRIBUTING.md",
]


def run(repo_path: str) -> CheckResult:
    for candidate in _CANDIDATES:
        if os.path.isfile(os.path.join(repo_path, candidate)):
            return {"ok": True, "file": candidate, "candidates": _CANDIDATES}
    return {"ok": False, "file": None, "candidates": _CANDIDATES}
