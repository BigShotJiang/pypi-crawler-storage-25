"""Check: test-presence — valida que existe carpeta tests/ o script test en package.json."""

from __future__ import annotations

import json
import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "test-presence",
    "name": "Tests presentes",
    "category": "quality",
    "severity": "high",
}

_TEST_DIRS = ["tests", "test", "__tests__", "spec"]


def run(repo_path: str) -> CheckResult:
    for dir_name in _TEST_DIRS:
        if os.path.isdir(os.path.join(repo_path, dir_name)):
            return {
                "ok": True,
                "directory": dir_name,
                "script": None,
                "searched_dirs": _TEST_DIRS,
            }

    pkg_path = os.path.join(repo_path, "package.json")
    if os.path.isfile(pkg_path):
        try:
            with open(pkg_path, encoding="utf-8") as f:
                data = json.load(f)
            test_script = data.get("scripts", {}).get("test")
            if (
                test_script
                and test_script != 'echo "Error: no test specified" && exit 1'
            ):
                return {
                    "ok": True,
                    "directory": None,
                    "script": test_script,
                    "searched_dirs": _TEST_DIRS,
                }
        except (OSError, json.JSONDecodeError):
            pass

    return {"ok": False, "directory": None, "script": None, "searched_dirs": _TEST_DIRS}
