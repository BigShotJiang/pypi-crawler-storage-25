"""Check: env-example-presence — si hay referencias a .env en el repo, existe .env.example."""

from __future__ import annotations

import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "env-example-presence",
    "name": ".env.example presente cuando se usan variables de entorno",
    "category": "hygiene",
    "severity": "high",
}

_ENV_INDICATORS = [
    ".env",
    "docker-compose.yml",
    "docker-compose.yaml",
    "docker-compose.override.yml",
]

_DOCKER_COMPOSE_ENV_MARKER = ".env"


def _has_env_usage(repo_path: str) -> bool:
    """Return True if the repo shows signs of relying on a .env file."""
    if os.path.isfile(os.path.join(repo_path, ".env")):
        return True

    for compose_name in ("docker-compose.yml", "docker-compose.yaml"):
        compose_path = os.path.join(repo_path, compose_name)
        if not os.path.isfile(compose_path):
            continue
        try:
            with open(compose_path, encoding="utf-8") as f:
                if ".env" in f.read():
                    return True
        except OSError:
            pass

    makefile_path = os.path.join(repo_path, "Makefile")
    if os.path.isfile(makefile_path):
        try:
            with open(makefile_path, encoding="utf-8") as f:
                if ".env" in f.read():
                    return True
        except OSError:
            pass

    return False


def run(repo_path: str) -> CheckResult:
    if not _has_env_usage(repo_path):
        return {
            "ok": True,
            "skipped": True,
            "reason": "No .env usage detected",
            "file": None,
        }

    example_path = os.path.join(repo_path, ".env.example")
    found = os.path.isfile(example_path)
    return {
        "ok": found,
        "skipped": False,
        "file": ".env.example" if found else None,
        "has_env_usage": True,
    }
