"""A1 checks package — nuevos checks estándar del roadmap v2 Fase A."""

from __future__ import annotations

from typing import TYPE_CHECKING

from engine.checks import (
    changelog_presence,
    contributing_presence,
    dependency_freshness,
    env_example_presence,
    gitignore_presence,
    license_presence,
    package_json_fields,
    secrets_scan,
    security_audit,
    test_presence,
)

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckRunner

ALL_DEFINITIONS: list[CheckDefinition] = [
    contributing_presence.DEFINITION,
    changelog_presence.DEFINITION,
    license_presence.DEFINITION,
    env_example_presence.DEFINITION,
    package_json_fields.DEFINITION,
    gitignore_presence.DEFINITION,
    dependency_freshness.DEFINITION,
    test_presence.DEFINITION,
    security_audit.DEFINITION,
    secrets_scan.DEFINITION,
]

ALL_RUNNERS: dict[str, CheckRunner] = {
    contributing_presence.DEFINITION["id"]: contributing_presence.run,
    changelog_presence.DEFINITION["id"]: changelog_presence.run,
    license_presence.DEFINITION["id"]: license_presence.run,
    env_example_presence.DEFINITION["id"]: env_example_presence.run,
    package_json_fields.DEFINITION["id"]: package_json_fields.run,
    gitignore_presence.DEFINITION["id"]: gitignore_presence.run,
    dependency_freshness.DEFINITION["id"]: dependency_freshness.run,
    test_presence.DEFINITION["id"]: test_presence.run,
    security_audit.DEFINITION["id"]: security_audit.run,
    secrets_scan.DEFINITION["id"]: secrets_scan.run,
}

__all__ = ["ALL_DEFINITIONS", "ALL_RUNNERS"]
