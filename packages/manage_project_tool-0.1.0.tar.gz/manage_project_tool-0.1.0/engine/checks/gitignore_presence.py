"""Check: gitignore-presence — verifica que existe .gitignore con entradas relevantes."""

from __future__ import annotations

import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "gitignore-presence",
    "name": ".gitignore presente con entradas relevantes",
    "category": "hygiene",
    "severity": "medium",
}

_NODE_INDICATORS = [
    "package.json",
    "package-lock.json",
    "npm-shrinkwrap.json",
    "yarn.lock",
    "pnpm-lock.yaml",
]
_PYTHON_INDICATORS = [
    "pyproject.toml",
    "requirements.txt",
    "requirements-dev.txt",
    "setup.py",
    "setup.cfg",
    "Pipfile",
    "poetry.lock",
    "uv.lock",
]
_ENV_INDICATORS = [
    ".env",
    ".env.example",
    ".env.local",
    ".env.development",
    ".env.production",
]


def _entry_covered(entry: str, lines: list[str]) -> bool:
    """Return True if an ignore line covers the logical entry."""
    clean = entry.rstrip("/")

    for line in lines:
        normalized = line.strip()
        if normalized.startswith("./"):
            normalized = normalized[2:]
        normalized = normalized.rstrip("/")
        segments = [segment for segment in normalized.split("/") if segment]

        if clean == ".env":
            if normalized.startswith(".env"):
                return True
            continue

        if clean in {"node_modules", "__pycache__"}:
            if clean in segments:
                return True
            continue

        if normalized == clean:
            return True

    return False


def _has_any_indicator(repo_path: str, file_names: list[str]) -> bool:
    return any(os.path.exists(os.path.join(repo_path, name)) for name in file_names)


def _has_python_files(repo_path: str) -> bool:
    for root, _dirs, files in os.walk(repo_path):
        if os.path.basename(root) == ".git":
            continue
        for name in files:
            if name.endswith(".py"):
                return True
    return False


def _expected_entries(repo_path: str) -> list[str]:
    expected: list[str] = []

    if _has_any_indicator(repo_path, _NODE_INDICATORS):
        expected.append("node_modules/")
    if _has_any_indicator(repo_path, _PYTHON_INDICATORS) or _has_python_files(
        repo_path
    ):
        expected.append("__pycache__")
    if _has_any_indicator(repo_path, _ENV_INDICATORS):
        expected.append(".env")

    return expected


def run(repo_path: str) -> CheckResult:
    expected_entries = _expected_entries(repo_path)
    gitignore_path = os.path.join(repo_path, ".gitignore")
    if not os.path.isfile(gitignore_path):
        return {
            "ok": False,
            "file": None,
            "missing_entries": expected_entries,
            "found_entries": [],
            "expected_entries": expected_entries,
        }

    with open(gitignore_path, encoding="utf-8") as f:
        lines = [
            line.strip()
            for line in f.read().splitlines()
            if line.strip() and not line.startswith("#")
        ]

    missing = [e for e in expected_entries if not _entry_covered(e, lines)]
    found = [e for e in expected_entries if _entry_covered(e, lines)]

    return {
        "ok": not missing,
        "file": ".gitignore",
        "missing_entries": missing,
        "found_entries": found,
        "expected_entries": expected_entries,
    }
