"""Check: package-json-fields — valida campos obligatorios en package.json."""

from __future__ import annotations

import json
import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "package-json-fields",
    "name": "package.json con campos obligatorios",
    "category": "metadata",
    "severity": "medium",
}

_REQUIRED_FIELDS = ["name", "version", "description", "license", "repository"]


def run(repo_path: str) -> CheckResult:
    pkg_path = os.path.join(repo_path, "package.json")
    if not os.path.isfile(pkg_path):
        return {
            "ok": True,
            "skipped": True,
            "reason": "No package.json found",
            "missing": [],
            "required": _REQUIRED_FIELDS,
        }

    try:
        with open(pkg_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        return {
            "ok": False,
            "skipped": False,
            "error": str(exc),
            "missing": _REQUIRED_FIELDS,
            "required": _REQUIRED_FIELDS,
        }

    missing = [field for field in _REQUIRED_FIELDS if not data.get(field)]
    return {
        "ok": not missing,
        "skipped": False,
        "file": "package.json",
        "missing": missing,
        "required": _REQUIRED_FIELDS,
    }
