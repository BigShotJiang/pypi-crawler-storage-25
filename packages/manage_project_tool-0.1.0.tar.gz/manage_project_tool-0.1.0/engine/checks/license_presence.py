"""Check: license-presence — verifica que existe un fichero LICENSE en cualquier formato."""

from __future__ import annotations

import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "license-presence",
    "name": "LICENSE presente",
    "category": "docs",
    "severity": "high",
}

_CANDIDATES = [
    "LICENSE",
    "LICENSE.md",
    "LICENSE.txt",
    "LICENSE.rst",
    "LICENCE",
    "LICENCE.md",
    "LICENCE.txt",
    "COPYING",
    "COPYING.md",
    "COPYING.txt",
]


def run(repo_path: str) -> CheckResult:
    for candidate in _CANDIDATES:
        if os.path.isfile(os.path.join(repo_path, candidate)):
            return {"ok": True, "file": candidate, "candidates": _CANDIDATES}
    return {"ok": False, "file": None, "candidates": _CANDIDATES}
