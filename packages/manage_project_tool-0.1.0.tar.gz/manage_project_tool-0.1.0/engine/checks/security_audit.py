"""Check: security-audit — ejecuta npm audit / pip-audit y reporta vulnerabilidades."""

from __future__ import annotations

import json
import os
import subprocess

from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "security-audit",
    "name": "Auditoría de seguridad de dependencias",
    "category": "security",
    "severity": "high",
}

_SUBPROCESS_TIMEOUT = 60


def _as_int(value: object, default: int = 0) -> int:
    """Return value as int when possible, otherwise default."""
    return value if isinstance(value, int) else default


def _run_npm_audit(repo_path: str) -> dict[str, object] | None:
    """Run `npm audit --json`. Returns summary or None if unavailable."""
    pkg_path = os.path.join(repo_path, "package.json")
    if not os.path.isfile(pkg_path):
        return None
    try:
        proc = subprocess.run(
            ["npm", "audit", "--json"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
            check=False,
        )
        if proc.stdout.strip():
            parsed = json.loads(proc.stdout)
            data: dict[str, object] = (
                cast(dict[str, object], parsed) if isinstance(parsed, dict) else {}
            )
            metadata = data.get("metadata", {})
            metadata_dict: dict[str, object] = (
                cast(dict[str, object], metadata) if isinstance(metadata, dict) else {}
            )
            vulns_raw = metadata_dict.get("vulnerabilities", {})
            vulns: dict[str, int] = {}
            if isinstance(vulns_raw, dict):
                vulns = {
                    str(key): _as_int(value)
                    for key, value in cast(dict[object, object], vulns_raw).items()
                }
            total = sum(vulns.values())
            return {
                "total": total,
                "vulnerabilities": vulns,
                "critical": _as_int(vulns.get("critical", 0)),
                "high": _as_int(vulns.get("high", 0)),
            }
        return {"total": 0, "vulnerabilities": {}, "critical": 0, "high": 0}
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        return None


def _run_pip_audit(repo_path: str) -> dict[str, object] | None:
    """Run `pip-audit --format json`. Returns summary or None if unavailable."""
    has_reqs = any(
        os.path.isfile(os.path.join(repo_path, f))
        for f in ("requirements.txt", "pyproject.toml", "Pipfile")
    )
    if not has_reqs:
        return None
    try:
        proc = subprocess.run(
            ["pip-audit", "--format", "json", "--progress-spinner", "off"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
            check=False,
        )
        if proc.stdout.strip():
            parsed = json.loads(proc.stdout)
            if isinstance(parsed, list):
                vulns = cast(list[Any], parsed)
                return {"total": len(vulns), "vulnerabilities": vulns}

            data: dict[str, object] = (
                cast(dict[str, object], parsed) if isinstance(parsed, dict) else {}
            )
            vulns_raw = data.get("vulnerabilities", [])
            vulns = cast(list[Any], vulns_raw) if isinstance(vulns_raw, list) else []
            return {"total": len(vulns), "vulnerabilities": vulns}
        return {"total": 0, "vulnerabilities": []}
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        return None


def run(repo_path: str) -> CheckResult:
    npm_result = _run_npm_audit(repo_path)
    pip_result = _run_pip_audit(repo_path)

    if npm_result is None and pip_result is None:
        return {
            "ok": True,
            "skipped": True,
            "reason": "No supported ecosystems detected or audit tools unavailable",
            "npm": None,
            "pip": None,
        }

    npm_critical = (npm_result or {}).get("critical", 0)
    npm_high = (npm_result or {}).get("high", 0)
    pip_total = (pip_result or {}).get("total", 0)

    has_critical_issues = bool(npm_critical or npm_high or pip_total)

    return {
        "ok": not has_critical_issues,
        "skipped": False,
        "npm": npm_result,
        "pip": pip_result,
    }
