"""Check: changelog-presence — verifica que existe CHANGELOG.md o RELEASES.md."""

from __future__ import annotations

import os

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "changelog-presence",
    "name": "CHANGELOG presente",
    "category": "docs",
    "severity": "medium",
}

_CANDIDATES = [
    "CHANGELOG.md",
    "CHANGELOG.rst",
    "CHANGELOG.txt",
    "CHANGELOG",
    "RELEASES.md",
    "RELEASES.rst",
    "HISTORY.md",
    "CHANGES.md",
    "docs/CHANGELOG.md",
]


def run(repo_path: str) -> CheckResult:
    for candidate in _CANDIDATES:
        if os.path.isfile(os.path.join(repo_path, candidate)):
            return {"ok": True, "file": candidate, "candidates": _CANDIDATES}
    return {"ok": False, "file": None, "candidates": _CANDIDATES}
