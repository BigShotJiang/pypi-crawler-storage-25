"""Check: dependency-freshness — detecta dependencias muy desactualizadas."""

from __future__ import annotations

import json
import os
import subprocess

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.engine import CheckDefinition, CheckResult

DEFINITION: CheckDefinition = {
    "id": "dependency-freshness",
    "name": "Dependencias actualizadas",
    "category": "dependencies",
    "severity": "medium",
}

_SUBPROCESS_TIMEOUT = 30


def _run_npm_outdated(repo_path: str) -> dict[str, object] | None:
    """Run `npm outdated --json`. Returns parsed output or None if unavailable."""
    pkg_path = os.path.join(repo_path, "package.json")
    if not os.path.isfile(pkg_path):
        return None
    try:
        proc = subprocess.run(
            ["npm", "outdated", "--json"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
            check=False,
        )
        if proc.stdout.strip():
            return json.loads(proc.stdout)
        return {}
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        return None


def _run_pip_outdated(repo_path: str) -> list[dict[str, str]] | None:
    """Run `pip list --outdated --format json`. Returns list or None if unavailable."""
    has_reqs = any(
        os.path.isfile(os.path.join(repo_path, f))
        for f in (
            "requirements.txt",
            "pyproject.toml",
            "Pipfile",
            "setup.py",
            "setup.cfg",
        )
    )
    if not has_reqs:
        return None
    try:
        proc = subprocess.run(
            ["pip", "list", "--outdated", "--format", "json"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=_SUBPROCESS_TIMEOUT,
            check=False,
        )
        if proc.stdout.strip():
            return json.loads(proc.stdout)
        return []
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        return None


def run(repo_path: str) -> CheckResult:
    npm_outdated = _run_npm_outdated(repo_path)
    pip_outdated = _run_pip_outdated(repo_path)

    if npm_outdated is None and pip_outdated is None:
        return {
            "ok": True,
            "skipped": True,
            "reason": "No supported ecosystems detected or tools unavailable",
            "npm_outdated": None,
            "pip_outdated": None,
        }

    npm_count = len(npm_outdated) if npm_outdated else 0
    pip_count = len(pip_outdated) if pip_outdated else 0
    total_outdated = npm_count + pip_count

    return {
        "ok": total_outdated == 0,
        "skipped": False,
        "total_outdated": total_outdated,
        "npm_outdated": npm_outdated,
        "pip_outdated": pip_outdated,
    }
