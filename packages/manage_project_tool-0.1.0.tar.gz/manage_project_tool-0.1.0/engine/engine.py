"""PoC engine HTTP server.

Exposes minimal API endpoints used by the coordinator in the PoC.
"""

# pylint: disable=too-many-lines

from __future__ import annotations

from http.server import BaseHTTPRequestHandler, HTTPServer
import importlib.util
import json
import os
import sys
from datetime import datetime, timezone
from typing import Any, Callable, TypedDict, cast
import urllib.parse

HOST = os.environ.get("MPT_ENGINE_HOST", "127.0.0.1")
PORT = int(os.environ.get("MPT_ENGINE_PORT", "5001"))

# ---------------------------------------------------------------------------
# Type definitions
# ---------------------------------------------------------------------------

CheckResult = dict[str, object]
CheckRunner = Callable[[str], CheckResult]


class _CheckDefinitionRequired(TypedDict):
    id: str
    name: str
    category: str
    severity: str


class CheckDefinition(_CheckDefinitionRequired, total=False):
    params: dict[str, object]


class LockfileDefinition(TypedDict):
    file: str
    ecosystem: str
    manager: str


class ThresholdsConfig(TypedDict, total=False):
    maxWarnings: int


class ProjectConfigFormat(TypedDict, total=False):
    version: str
    checks: list[str]
    defaults: dict[str, list[str]]
    severity: dict[str, str]
    thresholds: ThresholdsConfig


README_CANDIDATE_NAMES: list[str] = [
    "README.md",
    "README.MD",
    "readme.md",
    "README.rst",
    "readme.rst",
    "README.txt",
    "readme.txt",
    "README",
    "readme",
]
README_SEARCH_DIRECTORIES: list[str] = ["", "docs"]
LOCKFILE_DEFINITIONS: list[LockfileDefinition] = [
    {"file": "package-lock.json", "ecosystem": "node", "manager": "npm"},
    {"file": "npm-shrinkwrap.json", "ecosystem": "node", "manager": "npm"},
    {"file": "yarn.lock", "ecosystem": "node", "manager": "yarn"},
    {"file": "pnpm-lock.yaml", "ecosystem": "node", "manager": "pnpm"},
    {"file": "poetry.lock", "ecosystem": "python", "manager": "poetry"},
    {"file": "Pipfile.lock", "ecosystem": "python", "manager": "pipenv"},
    {"file": "uv.lock", "ecosystem": "python", "manager": "uv"},
    {"file": "Gemfile.lock", "ecosystem": "ruby", "manager": "bundler"},
    {"file": "composer.lock", "ecosystem": "php", "manager": "composer"},
    {"file": "Cargo.lock", "ecosystem": "rust", "manager": "cargo"},
    {"file": "go.sum", "ecosystem": "go", "manager": "go-modules"},
]

CHECK_DEFINITIONS: list[CheckDefinition] = [
    {
        "id": "readme-presence",
        "name": "README presente",
        "category": "docs",
        "severity": "low",
        "params": {},
    },
    {
        "id": "lockfile",
        "name": "Lockfile presente",
        "category": "dependencies",
        "severity": "high",
        "params": {},
    },
    {
        "id": "ci-workflow-presence",
        "name": "Workflow de CI presente",
        "category": "ci",
        "severity": "medium",
        "params": {},
    },
]
CHECK_DEFINITIONS_BY_ID: dict[str, CheckDefinition] = {
    check["id"]: check for check in CHECK_DEFINITIONS
}
DEFAULT_RESULT_SEVERITY_BY_CHECK_SEVERITY: dict[str, str] = {
    "high": "error",
    "medium": "warning",
    "low": "info",
    "error": "error",
    "warning": "warning",
    "info": "info",
}
ALLOWED_RESULT_SEVERITIES: set[str] = {"error", "warning", "info"}
FAILURE_SUGGESTIONS_BY_CHECK_ID: dict[str, str] = {
    "readme-presence": (
        "Crea un README.md en la raiz o en docs/ con descripcion, instalacion y uso."
    ),
    "lockfile": (
        "Genera y versiona un lockfile para hacer reproducibles las instalaciones."
    ),
    "ci-workflow-presence": (
        "Anade un workflow en .github/workflows/ que ejecute lint y tests en cada push o PR."
    ),
    "contributing-presence": (
        "Anade CONTRIBUTING.md con flujo de trabajo, estilo y pasos para contribuir."
    ),
    "changelog-presence": (
        "Anade CHANGELOG.md para registrar cambios relevantes por version."
    ),
    "license-presence": "Incluye un archivo LICENSE con la licencia del proyecto.",
    "env-example-presence": (
        "Anade .env.example con las variables necesarias y valores de ejemplo sin secretos."
    ),
    "package-json-fields": (
        "Completa package.json con name, version, description, scripts y metadatos basicos."
    ),
    "gitignore-presence": (
        "Anade .gitignore con dependencias, artefactos locales y secretos que no deban versionarse."
    ),
    "dependency-freshness": (
        "Revisa dependencias desactualizadas y prioriza actualizar las criticas o vulnerables."
    ),
    "test-presence": (
        "Anade un conjunto basico de pruebas automatizadas y un comando de test reproducible."
    ),
    "security-audit": (
        "Ejecuta una auditoria de dependencias y corrige vulnerabilidades bloqueantes antes de publicar."
    ),
    "secrets-scan": (
        "Elimina secretos del repositorio, rota credenciales expuestas y usa variables de entorno."
    ),
    "has-editorconfig": (
        "Anade .editorconfig para unificar formato basico entre editores y lenguajes."
    ),
}


def get_history_file_path() -> str:
    configured = os.environ.get("MPT_HISTORY_FILE")
    if configured:
        return os.path.abspath(configured)
    return os.path.join(os.path.expanduser("~"), ".mpt", "history.json")


def load_scan_history() -> list[dict[str, object]]:
    history_file = get_history_file_path()
    if not os.path.isfile(history_file):
        return []

    try:
        with open(history_file, encoding="utf-8") as handle:
            parsed = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return []

    if not isinstance(parsed, list):
        return []

    history: list[dict[str, object]] = []
    for item in cast(list[object], parsed):
        if not isinstance(item, dict):
            continue

        normalized_item: dict[str, object] = {}
        for key, value in cast(dict[object, object], item).items():
            if isinstance(key, str):
                normalized_item[key] = value
        history.append(normalized_item)
    return history


def persist_scan_history(history: list[dict[str, object]]) -> None:
    history_file = get_history_file_path()
    history_dir = os.path.dirname(history_file)
    if history_dir:
        os.makedirs(history_dir, exist_ok=True)

    with open(history_file, "w", encoding="utf-8") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2)


def append_scan_history_entry(
    repo_path: str,
    checks: list[str],
    result: dict[str, CheckResult],
    summary: dict[str, object],
    source: str,
) -> None:
    history = load_scan_history()
    history.append(
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "path": repo_path,
            "checks": checks,
            "summary": summary,
            "result": result,
            "source": source,
        }
    )
    persist_scan_history(history)


def build_readme_search_paths() -> list[str]:
    paths: list[str] = []
    for relative_dir in README_SEARCH_DIRECTORIES:
        for name in README_CANDIDATE_NAMES:
            paths.append(f"{relative_dir}/{name}" if relative_dir else name)
    return paths


def list_readme_matches_in_directory(repo_path: str, relative_dir: str) -> list[str]:
    search_dir = os.path.join(repo_path, relative_dir)
    if not os.path.isdir(search_dir):
        return []

    existing_names: dict[str, str] = {
        name.lower(): name for name in os.listdir(search_dir)
    }
    matches: list[str] = []
    for candidate_name in README_CANDIDATE_NAMES:
        actual_name = existing_names.get(candidate_name.lower())
        if actual_name is None:
            continue

        actual_relative_path = (
            f"{relative_dir}/{actual_name}" if relative_dir else actual_name
        )
        if actual_relative_path not in matches:
            matches.append(actual_relative_path)

    return matches


def find_readme(repo_path: str) -> CheckResult:
    matches: list[str] = []
    for relative_dir in README_SEARCH_DIRECTORIES:
        matches.extend(list_readme_matches_in_directory(repo_path, relative_dir))

    return {
        "ok": bool(matches),
        "file": matches[0] if matches else None,
        "matches": matches,
        "searched": build_readme_search_paths(),
    }


def find_lockfiles(repo_path: str) -> CheckResult:
    present: list[dict[str, str]] = []
    ecosystems: list[str] = []

    for definition in LOCKFILE_DEFINITIONS:
        lockfile_path = os.path.join(repo_path, definition["file"])
        if not os.path.exists(lockfile_path):
            continue

        present.append(
            {
                "file": definition["file"],
                "ecosystem": definition["ecosystem"],
                "manager": definition["manager"],
            }
        )
        if definition["ecosystem"] not in ecosystems:
            ecosystems.append(definition["ecosystem"])

    supported = [definition["file"] for definition in LOCKFILE_DEFINITIONS]

    return {
        "ok": bool(present),
        "present": present,
        "ecosystems": ecosystems,
        "supported": supported,
    }


def find_ci_workflows(repo_path: str) -> list[str]:
    workflows_dir = os.path.join(repo_path, ".github", "workflows")
    if not os.path.isdir(workflows_dir):
        return []

    workflow_files: list[str] = []
    for name in sorted(os.listdir(workflows_dir)):
        if name.endswith((".yml", ".yaml")):
            workflow_files.append(f".github/workflows/{name}")
    return workflow_files


def analyze_ci_workflows(repo_path: str) -> CheckResult:
    ci_workflows = find_ci_workflows(repo_path)
    return {
        "ok": bool(ci_workflows),
        "present": ci_workflows,
        "count": len(ci_workflows),
    }


CHECK_RUNNERS: dict[str, CheckRunner] = {
    "readme-presence": find_readme,
    "lockfile": find_lockfiles,
    "ci-workflow-presence": analyze_ci_workflows,
}


def _register_a1_checks() -> None:
    """Import and register the A1 checks from engine/checks/."""
    # Import here to avoid circular imports (engine.checks imports engine.engine)
    from engine.checks import (  # pylint: disable=import-outside-toplevel
        ALL_DEFINITIONS,
        ALL_RUNNERS,
    )

    for definition in ALL_DEFINITIONS:
        check_id = definition["id"]
        if check_id not in CHECK_DEFINITIONS_BY_ID:
            CHECK_DEFINITIONS.append(definition)
            CHECK_DEFINITIONS_BY_ID[check_id] = definition
    CHECK_RUNNERS.update(ALL_RUNNERS)


_register_a1_checks()


# ---------------------------------------------------------------------------
# Plugin discovery
# ---------------------------------------------------------------------------

PLUGINS_DIR = os.path.join(os.path.dirname(__file__), "..", "plugins")


def _load_python_plugin(plugin_dir: str, meta: dict[str, Any]) -> None:
    """Import a Python plugin module and register its checks."""
    module_file = os.path.join(plugin_dir, "plugin.py")
    if not os.path.isfile(module_file):
        return

    plugin_id: str = str(meta.get("id", ""))
    spec = importlib.util.spec_from_file_location(f"plugins.{plugin_id}", module_file)
    if spec is None or spec.loader is None:
        return
    module = importlib.util.module_from_spec(spec)
    sys.modules[f"plugins.{plugin_id}"] = module
    spec.loader.exec_module(module)  # type: ignore[union-attr]

    plugin_runners = getattr(module, "CHECK_RUNNERS", {})
    plugin_checks = meta.get("checks", [])

    for check in plugin_checks:
        check_id = check.get("id")
        if not check_id or check_id in CHECK_DEFINITIONS_BY_ID:
            continue
        CHECK_DEFINITIONS.append(check)
        CHECK_DEFINITIONS_BY_ID[check_id] = check
        if check_id in plugin_runners:
            CHECK_RUNNERS[check_id] = plugin_runners[check_id]


def discover_plugins() -> None:
    """Scan the plugins/ directory and load all Python plugins."""
    plugins_root = os.path.abspath(PLUGINS_DIR)
    if not os.path.isdir(plugins_root):
        return

    for entry in sorted(os.listdir(plugins_root)):
        plugin_dir = os.path.join(plugins_root, entry)
        if not os.path.isdir(plugin_dir):
            continue

        meta_path = os.path.join(plugin_dir, "meta.json")
        if not os.path.isfile(meta_path):
            continue

        try:
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            print(f"[plugins] Warning: could not load {meta_path}: {exc}")
            continue

        plugin_type: str = str(meta.get("type", ""))
        if plugin_type == "python":
            _load_python_plugin(plugin_dir, meta)
            print(f"[plugins] Loaded plugin '{meta.get('id')}' from {plugin_dir}")


discover_plugins()


def load_project_config(repo_path: str) -> ProjectConfigFormat | None:
    """Load and parse mpt.config.json from the project root if it exists.

    Returns None if the file doesn't exist, otherwise returns the parsed config.
    If the config is invalid JSON, logs a warning and returns None.
    """
    config_path = os.path.join(repo_path, "mpt.config.json")
    if not os.path.isfile(config_path):
        return None

    try:
        with open(config_path, encoding="utf-8") as f:
            config: ProjectConfigFormat = json.load(f)
        return config
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[config] Warning: could not load {config_path}: {exc}")
        return None


def normalize_result_severity(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    if normalized in ALLOWED_RESULT_SEVERITIES:
        return normalized
    return None


def get_default_check_severity(check_id: str) -> str:
    check_definition = CHECK_DEFINITIONS_BY_ID.get(check_id)
    configured = (
        check_definition["severity"] if check_definition is not None else "medium"
    )
    configured = str(configured).strip().lower()
    return DEFAULT_RESULT_SEVERITY_BY_CHECK_SEVERITY.get(configured, "warning")


def get_check_suggestion(check_id: str, result: CheckResult) -> str | None:
    existing = result.get("suggestion")
    if isinstance(existing, str) and existing.strip():
        return existing.strip()
    if result.get("ok") is True:
        return None
    return FAILURE_SUGGESTIONS_BY_CHECK_ID.get(check_id)


def get_configured_severity_overrides(
    config: ProjectConfigFormat | None,
) -> dict[str, str]:
    if config is None:
        return {}

    raw_overrides = config.get("severity")
    if not isinstance(raw_overrides, dict):
        return {}

    overrides: dict[str, str] = {}
    for check_id, severity in raw_overrides.items():
        if check_id not in CHECK_DEFINITIONS_BY_ID:
            continue
        normalized = normalize_result_severity(severity)
        if normalized is None:
            continue
        overrides[check_id] = normalized
    return overrides


def get_configured_max_warnings(config: ProjectConfigFormat | None) -> int | None:
    if config is None:
        return None

    thresholds = config.get("thresholds")
    if not isinstance(thresholds, dict):
        return None

    max_warnings = thresholds.get("maxWarnings")
    if isinstance(max_warnings, int) and max_warnings >= 0:
        return max_warnings
    return None


def summarize_analysis(
    analysis_result: dict[str, CheckResult],
    max_warnings: int | None = None,
) -> dict[str, object]:
    passed = 0
    failed = 0
    skipped = 0
    errors = 0
    warnings = 0
    infos = 0

    for result in analysis_result.values():
        if result.get("skipped"):
            skipped += 1
            continue

        if result.get("ok") is True:
            passed += 1
            continue

        failed += 1
        severity = normalize_result_severity(result.get("severity")) or "warning"
        if severity == "error":
            errors += 1
        elif severity == "warning":
            warnings += 1
        else:
            infos += 1

    max_warnings_exceeded = max_warnings is not None and warnings > max_warnings
    exit_code = 1 if errors > 0 or max_warnings_exceeded else 0

    return {
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "total": len(analysis_result),
        "errors": errors,
        "warnings": warnings,
        "infos": infos,
        "maxWarnings": max_warnings,
        "maxWarningsExceeded": max_warnings_exceeded,
        "exitCode": exit_code,
    }


def _read_summary_int(summary: dict[str, object], key: str) -> int:
    value = summary.get(key)
    return value if isinstance(value, int) else 0


def validate_requested_checks(requested_checks: list[str] | None) -> list[str]:
    if requested_checks is None:
        return list(CHECK_RUNNERS.keys())

    unknown_checks = [
        check_id
        for check_id in requested_checks
        if check_id not in CHECK_DEFINITIONS_BY_ID
    ]
    if unknown_checks:
        unknown_checks_csv = ", ".join(sorted(unknown_checks))
        raise ValueError(f"Checks no soportados: {unknown_checks_csv}")

    unique_checks: list[str] = []
    for check_id in requested_checks:
        if check_id not in unique_checks:
            unique_checks.append(check_id)
    return unique_checks


def generate_html_report(
    analysis_result: dict[str, CheckResult],
    summary: dict[str, object] | None = None,
) -> str:
    """Generate an HTML report from analysis results."""
    resolved_summary = summary or summarize_analysis(analysis_result)
    passed_count = _read_summary_int(resolved_summary, "passed")
    failed_count = _read_summary_int(resolved_summary, "failed")

    rows: list[str] = []
    severity_badge_map = {
        "error": '<span class="badge bg-danger">error</span>',
        "warning": '<span class="badge bg-warning text-dark">warning</span>',
        "info": '<span class="badge bg-info text-dark">info</span>',
    }

    for check_id, result in analysis_result.items():
        check_def = CHECK_DEFINITIONS_BY_ID.get(check_id)
        check_name = check_def["name"] if check_def is not None else check_id
        severity = normalize_result_severity(result.get("severity")) or "warning"
        is_ok = result.get("ok") is True
        status_badge = (
            '<span class="badge bg-success">PASS</span>'
            if is_ok
            else '<span class="badge bg-danger">FAIL</span>'
        )
        details_html = format_check_details(result)

        rows.append(f"""
    <tr>
      <td><strong>{check_id}</strong></td>
      <td>{check_name}</td>
      <td>{status_badge}</td>
      <td>{severity_badge_map[severity]}</td>
      <td><details style="cursor: pointer;"><summary>Ver</summary>{details_html}</details></td>
    </tr>""")

    html_content = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ManageProjectTool - Reporte de Análisis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {{
            background-color: #f8f9fa;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Helvetica Neue", Arial, sans-serif;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        .summary-card {{
            background: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            text-align: center;
        }}
        .summary-card .number {{
            font-size: 2rem;
            font-weight: bold;
            margin: 0.5rem 0;
        }}
        .summary-card.pass .number {{
            color: #28a745;
        }}
        .summary-card.fail .number {{
            color: #dc3545;
        }}
        .summary-card.total .number {{
            color: #667eea;
        }}
        .summary-card .label {{
            color: #666;
            font-size: 0.875rem;
        }}
        .checks-table {{
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            overflow: hidden;
        }}
        .checks-table table {{
            margin-bottom: 0;
        }}
        .checks-table thead {{
            background-color: #f8f9fa;
            font-weight: 600;
            color: #333;
        }}
        .checks-table tbody tr:hover {{
            background-color: #f8f9fa;
        }}
        details {{
            padding: 0.5rem 0;
        }}
        details summary::-webkit-details-marker {{
            display: none;
        }}
        details > summary {{
            list-style: none;
            cursor: pointer;
            user-select: none;
        }}
        details > summary::before {{
            content: "▶ ";
            display: inline-block;
            transition: transform 0.3s;
            margin-right: 0.5rem;
        }}
        details[open] > summary::before {{
            transform: rotate(90deg);
        }}
        .detail-content {{
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 4px;
            margin-top: 0.5rem;
            font-size: 0.875rem;
            font-family: "Monaco", "Courier New", monospace;
            word-break: break-word;
        }}
        .footer {{
            text-align: center;
            color: #999;
            margin-top: 2rem;
            font-size: 0.875rem;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="container">
            <h1 class="mb-0">ManageProjectTool</h1>
            <p class="mb-0">Reporte de Análisis de Proyecto</p>
        </div>
    </div>

    <div class="container">
        <div class="summary">
            <div class="summary-card pass">
                <div class="label">Pasados</div>
                <div class="number">{passed_count}</div>
            </div>
            <div class="summary-card fail">
                <div class="label">Fallidos</div>
                <div class="number">{failed_count}</div>
            </div>
            <div class="summary-card total">
                <div class="label">Total</div>
                <div class="number">{len(analysis_result)}</div>
            </div>
        </div>

        <div class="checks-table">
            <table class="table">
                <thead>
                    <tr>
                        <th>Check ID</th>
                        <th>Nombre</th>
                        <th>Estado</th>
                        <th>Severidad</th>
                        <th>Detalles</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows)}
                </tbody>
            </table>
        </div>

        <div class="footer">
            <p>Generado por ManageProjectTool v0.1.0</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""

    return html_content


def format_check_details(result: CheckResult) -> str:
    """Format check-specific result details as HTML.

    Args:
        result: The check result dict

    Returns:
        HTML string with formatted details
    """
    details_list: list[str] = []

    def format_value(val: object) -> str:
        """Recursively format a value for HTML display."""
        if isinstance(val, bool):
            return (
                '<span style="color: #28a745;">✓</span>'
                if val
                else '<span style="color: #dc3545;">✗</span>'
            )
        if isinstance(val, (list, dict)):
            return f"<pre>{json.dumps(val, indent=2)}</pre>"
        return str(val)

    for key, val in result.items():
        if key in ("ok", "severity"):
            continue
        formatted_val = format_value(val)
        details_list.append(f"<div><strong>{key}:</strong> {formatted_val}</div>")

    return (
        f'<div class="detail-content">{"".join(details_list)}</div>'
        if details_list
        else ""
    )


def analyze_repo(
    repo_path: str, requested_checks: list[str] | None = None
) -> dict[str, CheckResult]:
    """Analyze a repository using a set of checks.

    If requested_checks is None, attempts to load mpt.config.json from the repo.
    If no config file is found, runs all registered checks.
    """
    config = load_project_config(repo_path)
    severity_overrides = get_configured_severity_overrides(config)
    checks_to_run: list[str] | None = requested_checks

    if checks_to_run is None and config is not None and "checks" in config:
        checks_to_run = config["checks"]

    selected_checks = validate_requested_checks(checks_to_run)
    result: dict[str, CheckResult] = {}
    for check_id in selected_checks:
        check_result = dict(CHECK_RUNNERS[check_id](repo_path))
        check_result["severity"] = severity_overrides.get(
            check_id, get_default_check_severity(check_id)
        )
        suggestion = get_check_suggestion(check_id, check_result)
        if suggestion is not None:
            check_result["suggestion"] = suggestion
        result[check_id] = check_result
    return result


class Handler(BaseHTTPRequestHandler):
    """Simple HTTP handler implementing the PoC API endpoints.

    Note: `do_GET` and `do_POST` are methods required by BaseHTTPRequestHandler.
    """

    # Declared here so static analysers see it; set by BaseHTTPRequestHandler.handle().
    close_connection: bool

    def _set_headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()

    def do_GET(self) -> None:
        """Handle GET requests for health/version/checks endpoints."""
        if self.path.startswith("/api/v1/health"):
            self._set_headers()
            self.wfile.write(json.dumps({"status": "ok"}).encode())
            return

        if self.path.startswith("/api/v1/version"):
            self._set_headers()
            self.wfile.write(
                json.dumps({"name": "mpt-engine", "version": "0.1.0"}).encode()
            )
            return

        if self.path.startswith("/api/v1/checks"):
            self._set_headers()
            self.wfile.write(json.dumps(CHECK_DEFINITIONS).encode())
            return

        if self.path.startswith("/api/v1/history"):
            self._set_headers()
            self.wfile.write(json.dumps(load_scan_history()).encode())
            return

        if self.path.startswith("/api/v1/analyze/stream"):
            self._handle_sse_stream()
            return

        self.send_error(404, "Not Found")

    def _handle_sse_stream(self) -> None:
        """Stream analysis results as Server-Sent Events."""
        # Force connection close after the stream so the client sees EOF.
        # close_connection is defined by BaseHTTPRequestHandler.handle().
        self.close_connection = True

        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        repo_path = os.path.abspath(params.get("path", ["."])[0])
        checks_raw = params.get("checks", [None])[0]
        requested_checks: list[str] | None = None
        if checks_raw:
            requested_checks = [c.strip() for c in checks_raw.split(",") if c.strip()]

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        config = load_project_config(repo_path)
        severity_overrides = get_configured_severity_overrides(config)

        try:
            selected_checks = validate_requested_checks(requested_checks)
        except ValueError as error:
            error_event = json.dumps({"error": str(error)})
            self.wfile.write(f"event: error\ndata: {error_event}\n\n".encode())
            self.wfile.flush()
            return

        total = len(selected_checks)
        all_results: dict[str, CheckResult] = {}

        for index, check_id in enumerate(selected_checks, start=1):
            check_result = dict(CHECK_RUNNERS[check_id](repo_path))
            check_result["severity"] = severity_overrides.get(
                check_id, get_default_check_severity(check_id)
            )
            suggestion = get_check_suggestion(check_id, check_result)
            if suggestion is not None:
                check_result["suggestion"] = suggestion
            all_results[check_id] = check_result

            event_data = {
                "check": check_id,
                "index": index,
                "total": total,
                **check_result,
            }
            try:
                self.wfile.write(f"data: {json.dumps(event_data)}\n\n".encode())
                self.wfile.flush()
            except OSError:
                return

        summary = summarize_analysis(
            all_results,
            get_configured_max_warnings(config),
        )

        try:
            append_scan_history_entry(
                repo_path,
                selected_checks,
                all_results,
                summary,
                "stream",
            )
        except OSError:
            pass

        try:
            self.wfile.write(f"event: done\ndata: {json.dumps(summary)}\n\n".encode())
            self.wfile.flush()
        except OSError:
            return

    def do_POST(self) -> None:
        """Handle POST requests; supports `/api/v1/analyze` for PoC."""
        if self.path.startswith("/api/v1/analyze"):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)
            try:
                payload = json.loads(body.decode())
            except json.JSONDecodeError:
                self.send_error(400, "Invalid JSON")
                return

            repo_path = payload.get("path", ".")
            # sanitize path: map to absolute path for PoC
            repo_path = os.path.abspath(repo_path)

            try:
                result = analyze_repo(repo_path, payload.get("checks"))
            except ValueError as error:
                self.send_error(400, str(error))
                return

            summary = summarize_analysis(
                result,
                get_configured_max_warnings(load_project_config(repo_path)),
            )

            try:
                append_scan_history_entry(
                    repo_path,
                    list(result.keys()),
                    result,
                    summary,
                    "analyze",
                )
            except OSError:
                pass

            response: dict[str, object] = {
                "status": "completed",
                "result": result,
                "summary": summary,
            }
            self._set_headers()
            self.wfile.write(json.dumps(response).encode())
            return

        if self.path.startswith("/api/v1/report"):
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)
            try:
                payload = json.loads(body.decode())
            except json.JSONDecodeError:
                self.send_error(400, "Invalid JSON")
                return

            repo_path = payload.get("path", ".")
            # sanitize path: map to absolute path for PoC
            repo_path = os.path.abspath(repo_path)

            try:
                result = analyze_repo(repo_path, payload.get("checks"))
            except ValueError as error:
                self.send_error(400, str(error))
                return

            # Generate HTML report
            summary = summarize_analysis(
                result,
                get_configured_max_warnings(load_project_config(repo_path)),
            )

            try:
                append_scan_history_entry(
                    repo_path,
                    list(result.keys()),
                    result,
                    summary,
                    "report",
                )
            except OSError:
                pass

            html_report = generate_html_report(result, summary)
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html_report.encode())
            return

        self.send_error(404, "Not Found")


def run() -> None:
    server = HTTPServer((HOST, PORT), Handler)
    print(f"Engine listening on http://{HOST}:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping engine")
        server.server_close()


if __name__ == "__main__":
    run()
