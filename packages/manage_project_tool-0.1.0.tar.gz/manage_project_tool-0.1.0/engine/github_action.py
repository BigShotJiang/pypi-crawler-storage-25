"""GitHub Action entry point for ManageProjectTool."""

from __future__ import annotations

import json
import os
import sys

from engine import engine

ALLOWED_OUTPUT_FORMATS = {"json", "markdown"}


def parse_requested_checks(raw_value: str | None) -> list[str] | None:
    if raw_value is None:
        return None

    requested_checks = [item.strip() for item in raw_value.split(",") if item.strip()]
    return requested_checks or None


def normalize_output_format(raw_value: str | None) -> str:
    output_format = (raw_value or "markdown").strip().lower()
    if output_format not in ALLOWED_OUTPUT_FORMATS:
        supported = ", ".join(sorted(ALLOWED_OUTPUT_FORMATS))
        raise ValueError(f"Formato no soportado: {output_format}. Usa: {supported}")
    return output_format


def resolve_target_path(workspace_path: str, raw_target_path: str | None) -> str:
    target_path = (raw_target_path or ".").strip() or "."
    if os.path.isabs(target_path):
        return os.path.abspath(target_path)
    return os.path.abspath(os.path.join(workspace_path, target_path))


def to_workspace_relative_path(path: str, workspace_path: str) -> str:
    try:
        relative_path = os.path.relpath(path, workspace_path)
    except ValueError:
        return os.path.abspath(path)
    return relative_path.replace(os.sep, "/")


def build_report_payload(
    target_path: str,
    analysis_result: dict[str, dict[str, object]],
    summary: dict[str, object],
) -> dict[str, object]:
    return {
        "targetPath": target_path,
        "result": analysis_result,
        "summary": summary,
    }


def escape_markdown_cell(value: object) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def read_summary_int(summary: dict[str, object], key: str) -> int:
    value = summary.get(key)
    return value if isinstance(value, int) else 0


def render_markdown_report(
    target_path: str,
    analysis_result: dict[str, dict[str, object]],
    summary: dict[str, object],
) -> str:
    definitions: dict[str, engine.CheckDefinition] = {
        definition["id"]: definition for definition in engine.CHECK_DEFINITIONS
    }
    lines = [
        "# ManageProjectTool Report",
        "",
        f"- Target: `{target_path}`",
        f"- Total: {read_summary_int(summary, 'total')}",
        f"- Passed: {read_summary_int(summary, 'passed')}",
        f"- Failed: {read_summary_int(summary, 'failed')}",
        f"- Errors: {read_summary_int(summary, 'errors')}",
        f"- Warnings: {read_summary_int(summary, 'warnings')}",
        f"- Infos: {read_summary_int(summary, 'infos')}",
        f"- Exit code: {read_summary_int(summary, 'exitCode')}",
    ]

    if summary.get("maxWarnings") is not None:
        lines.append(f"- maxWarnings: {summary['maxWarnings']}")
        lines.append(f"- maxWarningsExceeded: {summary['maxWarningsExceeded']}")

    lines.extend(
        [
            "",
            "| Check | Name | Status | Severity |",
            "| --- | --- | --- | --- |",
        ]
    )

    for check_id, result in analysis_result.items():
        definition = definitions.get(check_id)
        check_name = definition["name"] if definition is not None else check_id
        if result.get("skipped"):
            status = "SKIP"
        elif result.get("ok"):
            status = "PASS"
        else:
            status = "FAIL"
        lines.append(
            "| "
            f"{escape_markdown_cell(check_id)} | "
            f"{escape_markdown_cell(check_name)} | "
            f"{escape_markdown_cell(status)} | "
            f"{escape_markdown_cell(result.get('severity', 'warning'))} |"
        )

    return "\n".join(lines) + "\n"


def write_report_file(
    workspace_path: str,
    output_format: str,
    content: str,
) -> str:
    reports_dir = os.path.join(workspace_path, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    extension = "json" if output_format == "json" else "md"
    report_path = os.path.join(reports_dir, f"mpt-action-report.{extension}")
    with open(report_path, "w", encoding="utf-8") as handle:
        handle.write(content)
        if not content.endswith("\n"):
            handle.write("\n")
    return report_path


def emit_github_output(name: str, value: str) -> None:
    github_output = os.environ.get("GITHUB_OUTPUT")
    if not github_output:
        return

    with open(github_output, "a", encoding="utf-8") as handle:
        handle.write(f"{name}={value}\n")


def append_step_summary(markdown_report: str) -> None:
    step_summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if not step_summary_path:
        return

    with open(step_summary_path, "a", encoding="utf-8") as handle:
        handle.write(markdown_report)
        if not markdown_report.endswith("\n"):
            handle.write("\n")


def run_action() -> int:
    workspace_path = os.environ.get("GITHUB_WORKSPACE", os.getcwd())
    target_path = resolve_target_path(
        workspace_path,
        os.environ.get("INPUT_TARGET_PATH"),
    )

    if not os.path.isdir(target_path):
        print(
            f"Error: target-path '{target_path}' no es un directorio válido.",
            file=sys.stderr,
        )
        return 2

    try:
        output_format = normalize_output_format(os.environ.get("INPUT_FORMAT"))
        requested_checks = parse_requested_checks(os.environ.get("INPUT_CHECKS"))
        analysis_result = engine.analyze_repo(target_path, requested_checks)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    config = engine.load_project_config(target_path)
    summary = engine.summarize_analysis(
        analysis_result,
        engine.get_configured_max_warnings(config),
    )
    display_path = to_workspace_relative_path(target_path, workspace_path)
    payload = build_report_payload(display_path, analysis_result, summary)

    if output_format == "json":
        rendered_report = json.dumps(payload, indent=2)
    else:
        rendered_report = render_markdown_report(
            display_path,
            analysis_result,
            summary,
        )
        append_step_summary(rendered_report)

    report_path = write_report_file(workspace_path, output_format, rendered_report)
    print(rendered_report)

    emit_github_output(
        "report-path",
        to_workspace_relative_path(report_path, workspace_path),
    )
    emit_github_output("exit-code", str(summary["exitCode"]))
    emit_github_output(
        "summary-json",
        json.dumps(summary, separators=(",", ":")),
    )
    return read_summary_int(summary, "exitCode")


def main() -> int:
    return run_action()


if __name__ == "__main__":
    sys.exit(main())
