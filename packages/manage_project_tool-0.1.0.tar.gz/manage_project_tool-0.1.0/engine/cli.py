"""CLI standalone para ManageProjectTool.

Entry point: mpt

Subcomandos:
  mpt scan <ruta>         Escanea un repositorio y muestra los resultados.
  mpt init [ruta]         Genera mpt.config.json interactivo en el repositorio.

Flags de 'scan':
  --format {table,json}   Formato de salida (default: table).
  --checks a,b,c          Lista de checks a ejecutar separados por coma.
  --open                  Genera reporte HTML y lo abre en el navegador.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import webbrowser
from typing import Any


def _get_check_definitions() -> list[Any]:
    from engine import engine  # pylint: disable=import-outside-toplevel

    return list(engine.CHECK_DEFINITIONS)


def _analyze(repo_path: str, checks: list[str] | None) -> dict[str, Any]:
    from engine import engine  # pylint: disable=import-outside-toplevel

    return engine.analyze_repo(repo_path, checks)


def _get_default_check_severity(check_id: str) -> str:
    from engine import engine  # pylint: disable=import-outside-toplevel

    return engine.get_default_check_severity(check_id)


def _summarize_results(
    repo_path: str,
    results: dict[str, Any],
) -> dict[str, Any]:
    from engine import engine  # pylint: disable=import-outside-toplevel

    config = engine.load_project_config(repo_path)
    return engine.summarize_analysis(
        results,
        engine.get_configured_max_warnings(config),
    )


def _generate_html(results: dict[str, Any], summary: dict[str, Any]) -> str:
    from engine import engine  # pylint: disable=import-outside-toplevel

    return engine.generate_html_report(results, summary)


# ---------------------------------------------------------------------------
# Output formatters
# ---------------------------------------------------------------------------

_STATUS_PASS = "PASS"
_STATUS_FAIL = "FAIL"
_STATUS_SKIP = "SKIP"


def _result_status(result: dict[str, Any]) -> str:
    if result.get("skipped"):
        return _STATUS_SKIP
    return _STATUS_PASS if result.get("ok") else _STATUS_FAIL


def print_table(
    repo_path: str,
    results: dict[str, Any],
    definitions: list[dict[str, Any]],
    summary: dict[str, Any] | None = None,
) -> int:
    """Print a human-readable table. Returns exit code (0 pass, 1 fail)."""
    defs_by_id = {d["id"]: d for d in definitions}

    col_id = max(len("CHECK"), *(len(k) for k in results)) + 2
    col_name = (
        max(
            len("NAME"),
            *(len(str(defs_by_id.get(k, {}).get("name", k))) for k in results),
        )
        + 2
    )
    col_severity = 10
    col_status = 8

    header = (
        f"{'CHECK':<{col_id}}{'NAME':<{col_name}}"
        f"{'SEVERITY':<{col_severity}}{'STATUS':<{col_status}}"
    )
    separator = "-" * len(header)

    print(f"\nManageProjectTool — scan: {repo_path}\n")
    print(header)
    print(separator)

    for check_id, result in results.items():
        d = defs_by_id.get(check_id, {})
        name = str(d.get("name", check_id))
        severity = str(result.get("severity", "warning"))
        status = _result_status(result)
        print(
            f"{check_id:<{col_id}}{name:<{col_name}}"
            f"{severity:<{col_severity}}{status:<{col_status}}"
        )

    print(separator)
    resolved_summary = summary or {
        "passed": sum(1 for r in results.values() if r.get("ok") is True),
        "failed": sum(
            1 for r in results.values() if not r.get("ok") and not r.get("skipped")
        ),
        "skipped": sum(1 for r in results.values() if r.get("skipped")),
        "total": len(results),
        "errors": sum(
            1
            for r in results.values()
            if not r.get("ok") and r.get("severity") == "error"
        ),
        "warnings": sum(
            1
            for r in results.values()
            if not r.get("ok") and r.get("severity") == "warning"
        ),
        "infos": sum(
            1
            for r in results.values()
            if not r.get("ok") and r.get("severity") == "info"
        ),
        "maxWarnings": None,
        "maxWarningsExceeded": False,
        "exitCode": (
            1
            if any(not r.get("ok") and not r.get("skipped") for r in results.values())
            else 0
        ),
    }
    print(
        "\n"
        f"{resolved_summary['passed']} passed · {resolved_summary['failed']} failed · "
        f"{resolved_summary['skipped']} skipped · {resolved_summary['total']} total\n"
    )
    if resolved_summary["failed"]:
        print(
            f"Policy: {resolved_summary['errors']} errors · "
            f"{resolved_summary['warnings']} warnings · {resolved_summary['infos']} infos"
        )
        if resolved_summary.get("maxWarnings") is not None:
            print(
                f"maxWarnings={resolved_summary['maxWarnings']} · "
                f"exceeded={resolved_summary['maxWarningsExceeded']}"
            )
        print()

    return int(resolved_summary["exitCode"])


def print_json(results: dict[str, Any], summary: dict[str, Any] | None = None) -> int:
    """Print JSON output. Returns exit code."""
    print(json.dumps(results, indent=2))
    if summary is None:
        failed = sum(
            1 for r in results.values() if not r.get("ok") and not r.get("skipped")
        )
        return 1 if failed else 0
    return int(summary["exitCode"])


# ---------------------------------------------------------------------------
# mpt scan
# ---------------------------------------------------------------------------


def _cmd_scan(args: argparse.Namespace) -> int:
    repo_path = os.path.abspath(args.path)
    if not os.path.isdir(repo_path):
        print(f"Error: '{repo_path}' no es un directorio válido.", file=sys.stderr)
        return 2

    checks: list[str] | None = None
    if args.checks:
        checks = [c.strip() for c in args.checks.split(",") if c.strip()]

    try:
        results = _analyze(repo_path, checks)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    summary = _summarize_results(repo_path, results)

    if args.format == "json":
        exit_code = print_json(results, summary)
    else:
        definitions = _get_check_definitions()
        exit_code = print_table(repo_path, results, definitions, summary)

    if args.open:
        html = _generate_html(results, summary)
        report_path = os.path.join(repo_path, "mpt-report.html")
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)
        webbrowser.open(f"file://{report_path}")
        print(f"Reporte guardado en: {report_path}")

    return exit_code


# ---------------------------------------------------------------------------
# mpt init
# ---------------------------------------------------------------------------

_DEFAULT_CONFIG: dict[str, Any] = {
    "version": "1",
    "checks": [],
    "severity": {},
    "thresholds": {},
}


def _prompt(question: str, default: str = "") -> str:
    """Read a line from stdin, defaulting if empty. Uses sys.stdin for testability."""
    display_default = f" [{default}]" if default else ""
    sys.stdout.write(f"{question}{display_default}: ")
    sys.stdout.flush()
    answer = sys.stdin.readline().rstrip("\n")
    return answer if answer else default


def _cmd_init(args: argparse.Namespace) -> int:
    repo_path = os.path.abspath(args.path)
    if not os.path.isdir(repo_path):
        print(f"Error: '{repo_path}' no es un directorio válido.", file=sys.stderr)
        return 2

    config_path = os.path.join(repo_path, "mpt.config.json")
    if os.path.isfile(config_path):
        overwrite = _prompt(f"'{config_path}' ya existe. ¿Sobreescribir?", "n")
        if overwrite.lower() not in ("y", "yes", "s", "si", "sí"):
            print("Operación cancelada.")
            return 0

    definitions = _get_check_definitions()
    available_ids = [d["id"] for d in definitions]

    print("\nChecks disponibles:")
    for d in definitions:
        print(
            f"  {d['id']:<35} {d.get('category', '')} / "
            f"default={_get_default_check_severity(str(d['id']))}"
        )

    print()
    raw = _prompt(
        "Checks a incluir (separados por coma, vacío = todos)",
        "",
    )

    if raw.strip():
        selected = [c.strip() for c in raw.split(",") if c.strip()]
        unknown = [c for c in selected if c not in available_ids]
        if unknown:
            print(
                f"Advertencia: checks desconocidos ignorados: {', '.join(unknown)}",
                file=sys.stderr,
            )
            selected = [c for c in selected if c in available_ids]
    else:
        selected = available_ids

    max_warnings_raw = _prompt(
        "Max warnings antes de fallar (vacío = sin límite)",
        "",
    )

    thresholds: dict[str, Any] = {}
    if max_warnings_raw.strip():
        try:
            max_warnings = int(max_warnings_raw)
        except ValueError:
            print("Error: maxWarnings debe ser un entero no negativo.", file=sys.stderr)
            return 2
        if max_warnings < 0:
            print("Error: maxWarnings debe ser un entero no negativo.", file=sys.stderr)
            return 2
        thresholds["maxWarnings"] = max_warnings

    config = {**_DEFAULT_CONFIG, "checks": selected, "thresholds": thresholds}
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    print(f"\nmpt.config.json creado en: {config_path}")
    print(f"Checks configurados: {len(selected)}")
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mpt",
        description="ManageProjectTool — auditoría de repositorios",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="<comando>")
    subparsers.required = True

    # scan
    scan_parser = subparsers.add_parser(
        "scan",
        help="Escanea un repositorio y muestra los resultados",
    )
    scan_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Ruta al repositorio a escanear (default: directorio actual)",
    )
    scan_parser.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Formato de salida: table (default) o json",
    )
    scan_parser.add_argument(
        "--checks",
        metavar="CHECKS",
        default=None,
        help="Lista de checks separados por coma (ej: readme-presence,lockfile)",
    )
    scan_parser.add_argument(
        "--open",
        action="store_true",
        default=False,
        help="Genera reporte HTML y lo abre en el navegador",
    )
    scan_parser.set_defaults(func=_cmd_scan)

    # init
    init_parser = subparsers.add_parser(
        "init",
        help="Genera mpt.config.json interactivo en el repositorio",
    )
    init_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Ruta al repositorio (default: directorio actual)",
    )
    init_parser.set_defaults(func=_cmd_init)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point del CLI. Devuelve el exit code."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
