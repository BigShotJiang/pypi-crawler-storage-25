# ManageProjectTool

ManageProjectTool audita repositorios con un engine Python, un coordinator
Node.js, una app Electron y una GitHub Action reutilizable para CI.

## Capacidades actuales

- Ejecuta checks core y plugins sobre documentación, CI, dependencias y seguridad.
- Aplica severidades efectivas (`error`, `warning`, `info`) y umbrales como
  `thresholds.maxWarnings` desde `mpt.config.json`.
- Expone un CLI standalone con `mpt scan` y `mpt init`.
- Genera reportes en JSON, HTML y Markdown según el flujo de uso.

## Uso local

### CLI Python

```bash
python -m engine.cli scan .
python -m engine.cli scan . --format json
python -m engine.cli init .
```

### Validación del workspace

```bash
npm install
npm run validate
```

`npm run validate` ejecuta formato, linters y tests en secuencia.

### Preparación de release (Fase B)

```bash
npm run release:check
```

Este comando valida prerequisitos implementables en el repo para `v0.1.0`
(`LICENSE`, artefactos de Action y assets de Electron) y lista pendientes
externos como Trusted Publisher en PyPI, `NPM_TOKEN` y Marketplace.

## GitHub Action

La Action Docker definida en la raíz permite reutilizar el engine sin levantar
el coordinator.

```yaml
name: Scan repository

on:
  pull_request:
  workflow_dispatch:

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run ManageProjectTool
        id: mpt
        uses: jaminsmoke/ManageProjectTool@v0.1.0
        with:
          target-path: .
          format: markdown
          checks: readme-presence,lockfile,ci-workflow-presence
      - name: Upload report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: mpt-report
          path: ${{ steps.mpt.outputs.report-path }}
```

Entradas soportadas:

- `target-path`: ruta relativa dentro de `GITHUB_WORKSPACE`.
- `checks`: lista separada por comas; vacía usa `mpt.config.json` o todos los checks.
- `format`: `markdown` o `json`.

Salidas expuestas:

- `report-path`: fichero generado en `reports/`.
- `exit-code`: resultado efectivo de la política de severidad.
- `summary-json`: resumen compacto para pasos posteriores.

## Documentación

- [docs/checks.md](docs/checks.md)
- [docs/github-action.md](docs/github-action.md)
- [docs/roadmaps/roadmap2.md](docs/roadmaps/roadmap2.md)
