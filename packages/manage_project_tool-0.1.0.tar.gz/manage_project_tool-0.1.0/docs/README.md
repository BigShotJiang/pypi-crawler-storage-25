# Documentación del proyecto ManageProjectTool

Este directorio contiene los documentos que definen el alcance, diseño y roadmap del proyecto.

Archivos:

- `vision.md` — Visión y objetivos
- `requirements.md` — Requisitos y alcance
- `architecture.md` — Arquitectura y decisiones
- `structure_conventions.md` — Estructura del repositorio y convenciones
- `metrics.md` — Métricas y reglas para auditoría automática
- `checks.md` — Catálogo de checks, severidades y política de salida
- `github-action.md` — Uso de la GitHub Action Docker y sus outputs
- `roadmaps/roadmap2.md` — Roadmap activo y milestones vigentes
- `contribution.md` — Guía para contribuir

Cómo usar:

- Completa y revisa cada documento.
- Los cambios en la carpeta `docs` deben discutirse en PRs.
- Próximo paso: cerrar los pendientes externos de la Fase B y validar el primer release público.
