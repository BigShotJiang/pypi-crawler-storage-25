# Electron Assets

Esta carpeta contiene los iconos usados por `electron-builder`:

- `icon.ico` (Windows)
- `icon.icns` (macOS)
- `icon.png` (Linux)

Las referencias `icon:` ya están habilitadas en
[electron-builder.yml](../../electron-builder.yml).
