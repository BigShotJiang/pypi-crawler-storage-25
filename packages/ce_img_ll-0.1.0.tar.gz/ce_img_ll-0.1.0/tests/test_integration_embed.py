﻿from __future__ import annotations

import zipfile
from pathlib import Path

from wpscellimg.api import embed_image, embed_images
from wpscellimg.constants import NS_MAIN, NS_REL_PKG, qn
from wpscellimg.xml_parts import parse_xml_bytes


def test_embed_single_image(minimal_xlsx: Path, tiny_png: Path, run_dir: Path) -> None:
    output = run_dir / "output.xlsx"
    embed_image(minimal_xlsx, output, "Sheet1", "C3", tiny_png)

    with zipfile.ZipFile(output, "r") as zf:
        names = set(zf.namelist())
        assert "xl/cellimages.xml" in names
        assert "xl/_rels/cellimages.xml.rels" in names
        assert any(name.startswith("xl/media/image") for name in names)

        sheet = parse_xml_bytes(zf.read("xl/worksheets/sheet1.xml")).getroot()
        cell = sheet.find(f".//{qn(NS_MAIN, 'c')}[@r='C3']")
        assert cell is not None
        assert cell.find(qn(NS_MAIN, "f")).text.startswith('_xlfn.DISPIMG("ID_')

        rels = parse_xml_bytes(zf.read("xl/_rels/cellimages.xml.rels")).getroot()
        assert any(
            rel.attrib.get("Type", "").endswith("/image")
            for rel in rels.findall(qn(NS_REL_PKG, "Relationship"))
        )


def test_embed_batch_images(minimal_xlsx: Path, tiny_png: Path, run_dir: Path) -> None:
    output = run_dir / "batch.xlsx"
    second = run_dir / "second.png"
    second.write_bytes(tiny_png.read_bytes())

    embed_images(
        source_xlsx=minimal_xlsx,
        output_xlsx=output,
        sheet_name="Sheet1",
        cell_image_map={"A1": tiny_png, "B2": second},
    )

    with zipfile.ZipFile(output, "r") as zf:
        names = [n for n in zf.namelist() if n.startswith("xl/media/image")]
        assert len(names) == 2
