﻿from __future__ import annotations

import pytest
from xml.etree import ElementTree as ET

from wpscellimg.constants import NS_MAIN, qn
from wpscellimg.errors import InvalidCellReferenceError
from wpscellimg.worksheet import parse_cell_ref, set_dispimg_formula


def test_parse_cell_ref_valid() -> None:
    assert parse_cell_ref("a1") == ("A", 1)
    assert parse_cell_ref("XFD1048576") == ("XFD", 1048576)


@pytest.mark.parametrize("value", ["", "A0", "1A", "AAAA1", "A-1", "A 1"])
def test_parse_cell_ref_invalid(value: str) -> None:
    with pytest.raises(InvalidCellReferenceError):
        parse_cell_ref(value)


def test_set_dispimg_formula_creates_cell() -> None:
    root = ET.fromstring(
        f"<worksheet xmlns=\"{NS_MAIN}\"><sheetData/></worksheet>"
    )
    set_dispimg_formula(root, "B2", "ID_TEST")

    cell = root.find(f".//{qn(NS_MAIN, 'c')}[@r='B2']")
    assert cell is not None
    assert cell.attrib.get("t") == "str"
    assert cell.find(qn(NS_MAIN, "f")).text == '_xlfn.DISPIMG("ID_TEST",1)'
    assert cell.find(qn(NS_MAIN, "v")).text == '=DISPIMG("ID_TEST",1)'
