﻿from __future__ import annotations

from wpscellimg.constants import (
    CELLIMAGES_PART,
    CELLIMAGES_RELS_PART,
    CONTENT_TYPES_PART,
    NS_ETC,
    NS_REL_PKG,
    WPS_CELLIMAGE_CONTENT_TYPE,
    qn,
)
from wpscellimg.xml_parts import (
    append_cellimage_with_media,
    ensure_cellimages_parts,
    ensure_content_type_cellimages,
    ensure_workbook_cellimages_rel,
    parse_xml_bytes,
)


def test_ensure_parts_and_rels(minimal_xlsx, tiny_png) -> None:
    import zipfile

    with zipfile.ZipFile(minimal_xlsx, "r") as zf:
        entries = {name: zf.read(name) for name in zf.namelist() if not name.endswith("/")}

    ensure_content_type_cellimages(entries)
    ensure_workbook_cellimages_rel(entries)
    ensure_cellimages_parts(entries)

    ct = parse_xml_bytes(entries[CONTENT_TYPES_PART]).getroot()
    ns = ct.tag[ct.tag.find("{") + 1 : ct.tag.find("}")]
    override_tag = qn(ns, "Override")
    assert any(
        node.attrib.get("PartName") == "/xl/cellimages.xml"
        and node.attrib.get("ContentType") == WPS_CELLIMAGE_CONTENT_TYPE
        for node in ct.findall(override_tag)
    )

    rels = parse_xml_bytes(entries["xl/_rels/workbook.xml.rels"]).getroot()
    assert any(
        rel.attrib.get("Target") == "cellimages.xml"
        for rel in rels.findall(qn(NS_REL_PKG, "Relationship"))
    )

    image_id = append_cellimage_with_media(entries, tiny_png)
    assert image_id.startswith("ID_")
    assert CELLIMAGES_PART in entries
    assert CELLIMAGES_RELS_PART in entries

    croot = parse_xml_bytes(entries[CELLIMAGES_PART]).getroot()
    assert croot.tag == qn(NS_ETC, "cellImages")
    assert croot.find(qn(NS_ETC, "cellImage")) is not None
