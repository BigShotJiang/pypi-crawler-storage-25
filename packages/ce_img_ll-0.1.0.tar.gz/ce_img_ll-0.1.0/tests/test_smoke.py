﻿from __future__ import annotations

from wpscellimg import __version__, embed_image, embed_images


def test_smoke_imports() -> None:
    assert __version__ == "0.1.0"
    assert callable(embed_image)
    assert callable(embed_images)
