﻿# ce_img_ll

## 中文说明

`ce_img_ll` 用于通过修改 XLSX 底层 OOXML 部件，把图片以 WPS 单元格内图片（`DISPIMG` + `cellimages.xml`）的方式写入指定单元格。

### 功能特性
- 支持单张图片写入单个单元格。
- 支持批量图片写入多个单元格。
- 保留工作簿结构，输出采用原子写入，降低损坏风险。
- 同时提供 Python API 和命令行工具。

### 兼容性说明
- 本库实现的是 WPS 专有的单元格图片机制。
- 在 Microsoft Excel 中，可能显示为公式文本，或表现为部分兼容。

### 安装

```bash
pip install ce_img_ll
```

### Python 用法

```python
from pathlib import Path
from wpscellimg import embed_image, embed_images

embed_image(
    source_xlsx=Path("input.xlsx"),
    output_xlsx=Path("output.xlsx"),
    sheet_name="Sheet1",
    cell_ref="B2",
    image_file=Path("photo.png"),
)

embed_images(
    source_xlsx=Path("input.xlsx"),
    output_xlsx=Path("output-batch.xlsx"),
    sheet_name="Sheet1",
    cell_image_map={
        "A1": Path("a.png"),
        "C3": Path("b.jpg"),
    },
)
```

### CLI 用法

```bash
ce-img-ll --source-xlsx input.xlsx --output-xlsx out.xlsx --sheet Sheet1 --cell A1 --image a.png
```

批量模式：

```bash
ce-img-ll --source-xlsx input.xlsx --output-xlsx out.xlsx --sheet Sheet1 --pair A1=a.png --pair B2=b.png
```

---

## English Documentation

`ce_img_ll` embeds images into `.xlsx` cells using WPS-specific in-cell image mechanics by editing OOXML parts directly (`DISPIMG` + `cellimages.xml`).

### Features
- Insert one image into one target cell.
- Batch insert multiple images into multiple cells.
- Preserve workbook structure and write output atomically.
- Provide both Python API and CLI.

### Compatibility
- This library implements WPS-specific in-cell image behavior.
- In Microsoft Excel, cells may show formula text or have partial compatibility.

### Installation

```bash
pip install ce_img_ll
```

### Python Usage

```python
from pathlib import Path
from wpscellimg import embed_image, embed_images

embed_image(
    source_xlsx=Path("input.xlsx"),
    output_xlsx=Path("output.xlsx"),
    sheet_name="Sheet1",
    cell_ref="B2",
    image_file=Path("photo.png"),
)

embed_images(
    source_xlsx=Path("input.xlsx"),
    output_xlsx=Path("output-batch.xlsx"),
    sheet_name="Sheet1",
    cell_image_map={
        "A1": Path("a.png"),
        "C3": Path("b.jpg"),
    },
)
```

### CLI Usage

```bash
ce-img-ll --source-xlsx input.xlsx --output-xlsx out.xlsx --sheet Sheet1 --cell A1 --image a.png
```

Batch mode:

```bash
ce-img-ll --source-xlsx input.xlsx --output-xlsx out.xlsx --sheet Sheet1 --pair A1=a.png --pair B2=b.png
```

## Development

```bash
python -m venv .venv
.venv\\Scripts\\python -m pip install -e . pytest
.venv\\Scripts\\python -m pytest
```
