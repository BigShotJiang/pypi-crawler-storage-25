﻿from __future__ import annotations

import posixpath
from pathlib import Path
from xml.etree import ElementTree as ET

from .constants import NS_MAIN, NS_REL_DOC, NS_REL_PKG, WORKBOOK_PART, WORKBOOK_RELS_PART, qn
from .errors import InvalidWorkbookError, SheetNotFoundError
from .package import OoxmlPackage
from .worksheet import parse_cell_ref, set_dispimg_formula
from .xml_parts import (
    append_cellimage_with_media,
    ensure_cellimages_parts,
    ensure_content_type_cellimages,
    ensure_workbook_cellimages_rel,
    parse_xml_bytes,
    xml_to_bytes,
)


def _normalize_sheet_part(target: str) -> str:
    value = target.replace("\\", "/")
    if value.startswith("/"):
        value = value.lstrip("/")
    elif not value.startswith("xl/"):
        value = posixpath.normpath(posixpath.join("xl", value))
    if not value.startswith("xl/"):
        raise InvalidWorkbookError(f"Unsupported worksheet target: {target}")
    return value


def _sheet_part_from_name(entries: dict[str, bytes], sheet_name: str) -> str:
    if WORKBOOK_PART not in entries or WORKBOOK_RELS_PART not in entries:
        raise InvalidWorkbookError("Invalid xlsx: missing workbook parts")

    wb_tree = parse_xml_bytes(entries[WORKBOOK_PART])
    rel_tree = parse_xml_bytes(entries[WORKBOOK_RELS_PART])

    rel_root = rel_tree.getroot()
    rel_map = {
        rel.attrib["Id"]: rel.attrib["Target"]
        for rel in rel_root.findall(qn(NS_REL_PKG, "Relationship"))
        if "Id" in rel.attrib and "Target" in rel.attrib
    }

    wb_root = wb_tree.getroot()
    sheets = wb_root.find(qn(NS_MAIN, "sheets"))
    if sheets is None:
        raise InvalidWorkbookError("workbook.xml missing <sheets>")

    for sheet in sheets.findall(qn(NS_MAIN, "sheet")):
        if sheet.attrib.get("name") != sheet_name:
            continue
        rid = sheet.attrib.get(qn(NS_REL_DOC, "id"))
        if not rid or rid not in rel_map:
            raise InvalidWorkbookError(f"Sheet relationship missing for '{sheet_name}'")
        return _normalize_sheet_part(rel_map[rid])

    raise SheetNotFoundError(f"Sheet not found: {sheet_name}")


def embed_images(
    source_xlsx: Path,
    output_xlsx: Path,
    sheet_name: str,
    cell_image_map: dict[str, Path],
) -> None:
    if not source_xlsx.exists():
        raise FileNotFoundError(f"Source xlsx not found: {source_xlsx}")

    if not cell_image_map:
        output_xlsx.parent.mkdir(parents=True, exist_ok=True)
        output_xlsx.write_bytes(source_xlsx.read_bytes())
        return

    normalized_map: dict[str, Path] = {}
    for cell_ref, image in cell_image_map.items():
        parse_cell_ref(cell_ref)
        if not image.exists():
            raise FileNotFoundError(f"Image not found for {cell_ref}: {image}")
        normalized_map[cell_ref.strip().upper()] = image

    pkg = OoxmlPackage.from_xlsx(source_xlsx)
    entries = pkg.entries

    sheet_part = _sheet_part_from_name(entries, sheet_name)
    if sheet_part not in entries:
        raise InvalidWorkbookError(f"Worksheet part not found: {sheet_part}")

    ensure_content_type_cellimages(entries)
    ensure_workbook_cellimages_rel(entries)
    ensure_cellimages_parts(entries)

    sheet_tree = parse_xml_bytes(entries[sheet_part])
    sheet_root = sheet_tree.getroot()

    for cell_ref, image_path in normalized_map.items():
        image_id = append_cellimage_with_media(entries, image_path)
        set_dispimg_formula(sheet_root, cell_ref, image_id)

    entries[sheet_part] = xml_to_bytes(sheet_tree)
    pkg.write_xlsx(output_xlsx)


def embed_image(
    source_xlsx: Path,
    output_xlsx: Path,
    sheet_name: str,
    cell_ref: str,
    image_file: Path,
) -> None:
    embed_images(
        source_xlsx=source_xlsx,
        output_xlsx=output_xlsx,
        sheet_name=sheet_name,
        cell_image_map={cell_ref: image_file},
    )
