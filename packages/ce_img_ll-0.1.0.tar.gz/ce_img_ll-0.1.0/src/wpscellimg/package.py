﻿from __future__ import annotations

import tempfile
import zipfile
from pathlib import Path


class OoxmlPackage:
    def __init__(self, entries: dict[str, bytes]) -> None:
        self.entries = entries

    @classmethod
    def from_xlsx(cls, source: Path) -> "OoxmlPackage":
        with zipfile.ZipFile(source, "r") as zf:
            entries = {
                name: zf.read(name)
                for name in zf.namelist()
                if not name.endswith("/")
            }
        return cls(entries)

    def read_bytes(self, part_name: str) -> bytes:
        return self.entries[part_name]

    def write_bytes(self, part_name: str, payload: bytes) -> None:
        self.entries[part_name] = payload

    def has_part(self, part_name: str) -> bool:
        return part_name in self.entries

    def next_media_index(self) -> int:
        max_index = 0
        for name in self.entries:
            if not name.startswith("xl/media/image"):
                continue
            stem = Path(name).stem
            if not stem.startswith("image"):
                continue
            raw = stem[5:]
            if raw.isdigit():
                max_index = max(max_index, int(raw))
        return max_index + 1

    def write_xlsx(self, output: Path) -> None:
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx", dir=output.parent) as tmp:
            tmp_path = Path(tmp.name)

        try:
            with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                for name in sorted(self.entries):
                    zf.writestr(name, self.entries[name])
            tmp_path.replace(output)
        finally:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
