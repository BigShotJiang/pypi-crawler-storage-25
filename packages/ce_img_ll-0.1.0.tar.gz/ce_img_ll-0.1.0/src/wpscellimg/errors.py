﻿from __future__ import annotations


class WpsCellImageError(Exception):
    """Base exception for the package."""


class InvalidWorkbookError(WpsCellImageError):
    """Workbook does not look like a valid .xlsx package."""


class SheetNotFoundError(WpsCellImageError):
    """Target worksheet name was not found."""


class InvalidCellReferenceError(WpsCellImageError):
    """Cell reference is invalid."""
