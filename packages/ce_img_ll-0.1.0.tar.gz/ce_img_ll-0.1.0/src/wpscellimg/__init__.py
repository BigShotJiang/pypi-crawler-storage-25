﻿from __future__ import annotations

from .api import embed_image, embed_images

__all__ = ["embed_image", "embed_images"]
__version__ = "0.1.0"
