﻿from __future__ import annotations

import argparse
from pathlib import Path

from .api import embed_image, embed_images


def _parse_pair(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("pair must be formatted as CELL=PATH")
    cell, image = value.split("=", 1)
    if not cell.strip() or not image.strip():
        raise argparse.ArgumentTypeError("pair must be formatted as CELL=PATH")
    return cell.strip(), Path(image.strip())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Embed WPS in-cell images into an existing xlsx file.")
    parser.add_argument("--source-xlsx", type=Path, required=True, help="Source xlsx path")
    parser.add_argument("--output-xlsx", type=Path, required=True, help="Output xlsx path")
    parser.add_argument("--sheet", required=True, help="Target sheet name")
    parser.add_argument("--cell", help="Target cell ref, e.g. A1")
    parser.add_argument("--image", type=Path, help="Image path for --cell")
    parser.add_argument(
        "--pair",
        type=_parse_pair,
        action="append",
        help="Batch mode: repeated CELL=IMAGE_PATH, e.g. --pair A1=a.png --pair B2=b.png",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.pair:
        mapping = {cell: path for cell, path in args.pair}
        embed_images(
            source_xlsx=args.source_xlsx,
            output_xlsx=args.output_xlsx,
            sheet_name=args.sheet,
            cell_image_map=mapping,
        )
    else:
        if not args.cell or not args.image:
            parser.error("Either use --pair (repeatable) or provide both --cell and --image.")
        embed_image(
            source_xlsx=args.source_xlsx,
            output_xlsx=args.output_xlsx,
            sheet_name=args.sheet,
            cell_ref=args.cell,
            image_file=args.image,
        )

    print(f"Done: {args.output_xlsx}")
    return 0
