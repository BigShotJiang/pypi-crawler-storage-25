﻿from __future__ import annotations

from xml.etree import ElementTree as ET

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL_DOC = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_REL_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_XDR = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"

NS_ETC = "http://www.wps.cn/officeDocument/2017/etCustomData"
WPS_CELLIMAGE_REL_TYPE = "http://www.wps.cn/officeDocument/2020/cellImage"
WPS_CELLIMAGE_CONTENT_TYPE = "application/vnd.wps-officedocument.cellimage+xml"

CELLIMAGES_PART = "xl/cellimages.xml"
CELLIMAGES_RELS_PART = "xl/_rels/cellimages.xml.rels"
WORKBOOK_PART = "xl/workbook.xml"
WORKBOOK_RELS_PART = "xl/_rels/workbook.xml.rels"
CONTENT_TYPES_PART = "[Content_Types].xml"


ET.register_namespace("", NS_MAIN)
ET.register_namespace("r", NS_REL_DOC)
ET.register_namespace("a", NS_A)
ET.register_namespace("xdr", NS_XDR)
ET.register_namespace("etc", NS_ETC)


def qn(ns: str, tag: str) -> str:
    return f"{{{ns}}}{tag}"
