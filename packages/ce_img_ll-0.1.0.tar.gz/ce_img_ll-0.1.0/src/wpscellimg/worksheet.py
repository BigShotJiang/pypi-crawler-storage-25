﻿from __future__ import annotations

import re
from xml.etree import ElementTree as ET

from .constants import NS_MAIN, qn
from .errors import InvalidCellReferenceError

_CELL_REF_RE = re.compile(r"^([A-Z]{1,3})([1-9][0-9]*)$")


def parse_cell_ref(cell_ref: str) -> tuple[str, int]:
    text = cell_ref.strip().upper()
    match = _CELL_REF_RE.match(text)
    if not match:
        raise InvalidCellReferenceError(f"Invalid cell reference: {cell_ref}")
    col, row = match.group(1), int(match.group(2))
    if col_to_index(col) > 16384:
        raise InvalidCellReferenceError(f"Column out of range: {col}")
    return col, row


def col_to_index(col: str) -> int:
    value = 0
    for ch in col:
        value = value * 26 + (ord(ch) - ord("A") + 1)
    return value


def ensure_sheet_data(sheet_root: ET.Element) -> ET.Element:
    sheet_data = sheet_root.find(qn(NS_MAIN, "sheetData"))
    if sheet_data is None:
        sheet_data = ET.SubElement(sheet_root, qn(NS_MAIN, "sheetData"))
    return sheet_data


def set_dispimg_formula(sheet_root: ET.Element, cell_ref: str, image_id: str) -> None:
    col, row_index = parse_cell_ref(cell_ref)
    ref = f"{col}{row_index}"

    sheet_data = ensure_sheet_data(sheet_root)
    row_elem = None
    for row in sheet_data.findall(qn(NS_MAIN, "row")):
        if row.attrib.get("r") == str(row_index):
            row_elem = row
            break
    if row_elem is None:
        row_elem = ET.SubElement(sheet_data, qn(NS_MAIN, "row"), {"r": str(row_index)})

    cell_elem = None
    for cell in row_elem.findall(qn(NS_MAIN, "c")):
        if cell.attrib.get("r") == ref:
            cell_elem = cell
            break
    if cell_elem is None:
        cell_elem = ET.SubElement(row_elem, qn(NS_MAIN, "c"), {"r": ref, "t": "str"})
    else:
        cell_elem.attrib["t"] = "str"
        for child in list(cell_elem):
            cell_elem.remove(child)

    f_node = ET.SubElement(cell_elem, qn(NS_MAIN, "f"))
    f_node.text = f'_xlfn.DISPIMG("{image_id}",1)'
    v_node = ET.SubElement(cell_elem, qn(NS_MAIN, "v"))
    v_node.text = f'=DISPIMG("{image_id}",1)'
