﻿from __future__ import annotations

import io
import uuid
from pathlib import Path
from xml.etree import ElementTree as ET

from .constants import (
    CELLIMAGES_PART,
    CELLIMAGES_RELS_PART,
    CONTENT_TYPES_PART,
    NS_A,
    NS_ETC,
    NS_REL_DOC,
    NS_REL_PKG,
    NS_XDR,
    WPS_CELLIMAGE_CONTENT_TYPE,
    WPS_CELLIMAGE_REL_TYPE,
    qn,
)


def parse_xml_bytes(payload: bytes) -> ET.ElementTree:
    return ET.ElementTree(ET.fromstring(payload))


def xml_to_bytes(tree: ET.ElementTree) -> bytes:
    buffer = io.BytesIO()
    tree.write(buffer, encoding="utf-8", xml_declaration=True)
    return buffer.getvalue()


def next_rid(root: ET.Element) -> str:
    max_id = 0
    for rel in root.findall(qn(NS_REL_PKG, "Relationship")):
        rid = rel.attrib.get("Id", "")
        if rid.startswith("rId") and rid[3:].isdigit():
            max_id = max(max_id, int(rid[3:]))
    return f"rId{max_id + 1}"


def ensure_content_type_cellimages(entries: dict[str, bytes]) -> None:
    tree = parse_xml_bytes(entries[CONTENT_TYPES_PART])
    root = tree.getroot()
    ns = root.tag[root.tag.find("{") + 1 : root.tag.find("}")]
    override_tag = qn(ns, "Override")
    exists = any(
        node.attrib.get("PartName") == "/xl/cellimages.xml"
        for node in root.findall(override_tag)
    )
    if not exists:
        ET.SubElement(
            root,
            override_tag,
            {
                "PartName": "/xl/cellimages.xml",
                "ContentType": WPS_CELLIMAGE_CONTENT_TYPE,
            },
        )
        entries[CONTENT_TYPES_PART] = xml_to_bytes(tree)


def ensure_workbook_cellimages_rel(entries: dict[str, bytes]) -> None:
    tree = parse_xml_bytes(entries["xl/_rels/workbook.xml.rels"])
    root = tree.getroot()
    rels = root.findall(qn(NS_REL_PKG, "Relationship"))
    if any(rel.attrib.get("Type") == WPS_CELLIMAGE_REL_TYPE for rel in rels):
        return

    ET.SubElement(
        root,
        qn(NS_REL_PKG, "Relationship"),
        {
            "Id": next_rid(root),
            "Type": WPS_CELLIMAGE_REL_TYPE,
            "Target": "cellimages.xml",
        },
    )
    entries["xl/_rels/workbook.xml.rels"] = xml_to_bytes(tree)


def ensure_cellimages_parts(entries: dict[str, bytes]) -> None:
    if CELLIMAGES_PART not in entries:
        root = ET.Element(qn(NS_ETC, "cellImages"))
        entries[CELLIMAGES_PART] = xml_to_bytes(ET.ElementTree(root))
    if CELLIMAGES_RELS_PART not in entries:
        root = ET.Element(qn(NS_REL_PKG, "Relationships"))
        entries[CELLIMAGES_RELS_PART] = xml_to_bytes(ET.ElementTree(root))


def append_cellimage_with_media(
    entries: dict[str, bytes],
    image_path: Path,
) -> str:
    rel_tree = parse_xml_bytes(entries[CELLIMAGES_RELS_PART])
    rel_root = rel_tree.getroot()

    media_index = 1
    for name in entries:
        if name.startswith("xl/media/image"):
            stem = Path(name).stem
            if stem.startswith("image") and stem[5:].isdigit():
                media_index = max(media_index, int(stem[5:]) + 1)

    suffix = image_path.suffix.lower() or ".png"
    media_part = f"xl/media/image{media_index}{suffix}"
    entries[media_part] = image_path.read_bytes()

    rid = next_rid(rel_root)
    ET.SubElement(
        rel_root,
        qn(NS_REL_PKG, "Relationship"),
        {
            "Id": rid,
            "Type": f"{NS_REL_DOC}/image",
            "Target": f"media/{Path(media_part).name}",
        },
    )
    entries[CELLIMAGES_RELS_PART] = xml_to_bytes(rel_tree)

    cellimages_tree = parse_xml_bytes(entries[CELLIMAGES_PART])
    croot = cellimages_tree.getroot()

    existing_ids = []
    for node in croot.findall(f".//{qn(NS_XDR, 'cNvPr')}"):
        raw = node.attrib.get("id", "")
        if raw.isdigit():
            existing_ids.append(int(raw))
    nv_id = str(max(existing_ids, default=1) + 1)

    image_id = f"ID_{uuid.uuid4().hex.upper()}"
    cell_image = ET.SubElement(croot, qn(NS_ETC, "cellImage"))
    pic = ET.SubElement(cell_image, qn(NS_XDR, "pic"))
    nv_pic_pr = ET.SubElement(pic, qn(NS_XDR, "nvPicPr"))
    ET.SubElement(nv_pic_pr, qn(NS_XDR, "cNvPr"), {"id": nv_id, "name": image_id, "descr": "Picture"})
    ET.SubElement(nv_pic_pr, qn(NS_XDR, "cNvPicPr"))

    blip_fill = ET.SubElement(pic, qn(NS_XDR, "blipFill"))
    ET.SubElement(blip_fill, qn(NS_A, "blip"), {qn(NS_REL_DOC, "embed"): rid, "cstate": "print"})
    stretch = ET.SubElement(blip_fill, qn(NS_A, "stretch"))
    ET.SubElement(stretch, qn(NS_A, "fillRect"))

    sp_pr = ET.SubElement(pic, qn(NS_XDR, "spPr"))
    xfrm = ET.SubElement(sp_pr, qn(NS_A, "xfrm"))
    ET.SubElement(xfrm, qn(NS_A, "off"), {"x": "635", "y": "635"})
    ET.SubElement(xfrm, qn(NS_A, "ext"), {"cx": "2476500", "cy": "1790700"})
    geom = ET.SubElement(sp_pr, qn(NS_A, "prstGeom"), {"prst": "rect"})
    ET.SubElement(geom, qn(NS_A, "avLst"))

    entries[CELLIMAGES_PART] = xml_to_bytes(cellimages_tree)
    return image_id
