from io import BytesIO

import pytest
from PIL import Image as PILImage

from codex_agent.message import AssistantMessage, CompactionMessage, DeveloperMessage, InterruptMessage, ServerToolResponseMessage, ToolResultMessage, UserMessage
from codex_agent import utils
from codex_agent.image import ImageMessage, image_input_token_count
from codex_agent.stream_utils import MappingStreamProcessor
from codex_agent.utils import split_history_turns
from codex_agent.utils import project_python_env


def test_split_history_turns_groups_complete_agent_loop():
    prelude = DeveloperMessage(content="session started")
    user = UserMessage(content="hello")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    tool_result = ToolResultMessage(call_id="call_1", content="42")
    final = AssistantMessage(content="done")

    turns, remainder = split_history_turns([prelude, user, tool_call, tool_result, final])

    assert turns == [[prelude, user, tool_call, tool_result, final]]
    assert remainder == []


def test_project_python_env_prefers_running_interpreter():
    env = project_python_env(env={"PATH": "/usr/bin:/bin"}, executable="/opt/project-python/bin/python")

    assert env["PATH"].split(":")[0] == "/opt/project-python/bin"
    assert env["PYTHON"] == "/opt/project-python/bin/python"
    assert env["PYTHON_EXECUTABLE"] == "/opt/project-python/bin/python"


def test_mapping_stream_processor_is_direct_passthrough_without_processors():
    source = iter([{"content": "a"}, {"content": "b"}])
    processor = MappingStreamProcessor(processors={"content": []}, threaded=True)

    result = processor(source)

    assert result is source
    assert list(result) == [{"content": "a"}, {"content": "b"}]


def test_read_document_content_adds_line_numbers_by_default(tmp_path):
    file = tmp_path / "sample.txt"
    file.write_text("alpha\nbeta\ngamma", encoding="utf-8")

    content = utils.read_document_content(str(file), max_tokens=10_000)

    assert content == "1|alpha\n2|beta\n3|gamma"


def test_read_document_content_pattern_returns_all_numbered_snippets(tmp_path):
    file = tmp_path / "sample.txt"
    lines = [f"line {index}" for index in range(1, 61)]
    lines[20] = "line 21 MATCH here"
    lines[49] = "line 50 MATCH again"
    file.write_text("\n".join(lines), encoding="utf-8")

    content = utils.read_document_content(str(file), pattern="MATCH", max_tokens=10_000)

    assert "--- match snippet 1/2: lines 11-31 ---" in content
    assert "11|line 11" in content
    assert "21|line 21 MATCH here" in content
    assert "31|line 31" in content
    assert "10|line 10" not in content
    assert "--- match snippet 2/2: lines 40-60 ---" in content
    assert "50|line 50 MATCH again" in content


def test_read_document_content_pattern_context_is_clamped_to_file_start(tmp_path):
    file = tmp_path / "sample.txt"
    lines = ["line 1", "line 2 MATCH", "line 3"]
    file.write_text("\n".join(lines), encoding="utf-8")

    content = utils.read_document_content(str(file), pattern="MATCH", max_tokens=10_000)

    assert content.startswith("--- match snippet 1/1: lines 1-3 ---\n1|line 1")
    assert "2|line 2 MATCH" in content


def test_read_document_content_pattern_is_regex_by_default(tmp_path):
    file = tmp_path / "sample.txt"
    lines = ["alpha", "ticket ABC-123", "ticket ABC-999", "ticket XYZ-123"]
    file.write_text("\n".join(lines), encoding="utf-8")

    content = utils.read_document_content(str(file), pattern=r"ABC-\d+", pattern_context_lines=0, max_tokens=10_000)

    assert "2|ticket ABC-123" in content
    assert "3|ticket ABC-999" in content
    assert "4|ticket XYZ-123" not in content


def test_read_document_content_can_treat_pattern_as_literal(tmp_path):
    file = tmp_path / "sample.txt"
    lines = ["ticket ABC-123", r"literal ABC-\d+ pattern"]
    file.write_text("\n".join(lines), encoding="utf-8")

    content = utils.read_document_content(str(file), pattern=r"ABC-\d+", regex=False, pattern_context_lines=0, max_tokens=10_000)

    assert "1|ticket ABC-123" not in content
    assert r"2|literal ABC-\d+ pattern" in content


def test_read_document_content_preserves_blank_lines_and_real_line_numbers(tmp_path):
    file = tmp_path / "sample.py"
    file.write_text("one\n\n\n    \nfive", encoding="utf-8")

    content = utils.read_document_content(str(file), max_tokens=10_000)

    assert content == "1|one\n2|\n3|\n4|    \n5|five"


def test_read_document_content_pattern_preserves_blank_lines_in_snippet_context(tmp_path):
    file = tmp_path / "sample.py"
    file.write_text("one\n\n\nMATCH\nfive", encoding="utf-8")

    content = utils.read_document_content(str(file), pattern="MATCH", pattern_context_lines=3, max_tokens=10_000)

    assert content == "--- match snippet 1/1: lines 1-5 ---\n1|one\n2|\n3|\n4|MATCH\n5|five"


def test_read_document_content_rejects_directories_and_urls(tmp_path):
    with pytest.raises(ValueError, match="Use view for directories"):
        utils.read_document_content(str(tmp_path), max_tokens=10_000)

    with pytest.raises(ValueError, match="Use view for URLs"):
        utils.read_document_content("https://example.com", max_tokens=10_000)


def test_view_document_content_keeps_extraction_pipeline_for_directories_without_line_numbers(tmp_path):
    file = tmp_path / "sample.txt"
    file.write_text("hello", encoding="utf-8")

    content = utils.view_document_content(str(tmp_path), max_tokens=10_000)

    assert "sample.txt" in content
    assert "1|" not in content


def test_view_document_content_search_query_returns_unnumbered_snippets(tmp_path):
    file = tmp_path / "sample.txt"
    file.write_text("alpha\nbeta needle\ngamma", encoding="utf-8")

    content = utils.view_document_content(str(file), search_query="needle", max_tokens=10_000)

    assert content.startswith("--- search result 1/1 ---\n")
    assert "beta needle" in content
    assert "2|" not in content


def test_split_history_turns_keeps_current_unfinished_turn_as_remainder():
    complete_user = UserMessage(content="first")
    complete_assistant = AssistantMessage(content="done")
    current_user = UserMessage(content="second")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]

    turns, remainder = split_history_turns([complete_user, complete_assistant, current_user, tool_call])

    assert turns == [[complete_user, complete_assistant]]
    assert remainder == [current_user, tool_call]


def test_split_history_turns_keeps_messages_after_final_assistant_as_remainder():
    user = UserMessage(content="make image")
    assistant = AssistantMessage()
    server = ServerToolResponseMessage(item={"type": "image_generation_call", "id": "ig_123"})

    turns, remainder = split_history_turns([user, assistant, server])

    assert turns == [[user, assistant]]
    assert remainder == [server]


def test_split_history_turns_includes_server_tool_response_before_final_assistant():
    user = UserMessage(content="make image")
    server = ServerToolResponseMessage(item={"type": "image_generation_call", "id": "ig_123"})
    assistant = AssistantMessage(content="done")

    turns, remainder = split_history_turns([user, server, assistant])

    assert turns == [[user, server, assistant]]
    assert remainder == []


def test_split_history_turns_treats_interruption_as_completed_turn():
    user = UserMessage(content="long task")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    interrupted = InterruptMessage()

    turns, remainder = split_history_turns([user, tool_call, interrupted])

    assert turns == [[user, tool_call, interrupted]]
    assert remainder == []


def test_split_history_turns_treats_legacy_interruption_marker_as_completed_turn():
    user = UserMessage(content="long task")
    interrupted = DeveloperMessage(content="The previous agent response was interrupted by the user.")

    turns, remainder = split_history_turns([user, interrupted])

    assert turns == [[user, interrupted]]
    assert remainder == []


def test_split_history_turns_resets_at_latest_compaction():
    old_user = UserMessage(content="old")
    old_assistant = AssistantMessage(content="old done")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_1"}])
    current_user = UserMessage(content="current")
    current_assistant = AssistantMessage(content="current done")

    turns, remainder = split_history_turns([old_user, old_assistant, compaction, current_user, current_assistant])

    assert turns == [[current_user, current_assistant]]
    assert remainder == []


def test_split_history_turns_excludes_compaction_from_unfinished_remainder():
    old_user = UserMessage(content="old")
    old_assistant = AssistantMessage(content="old done")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_1"}])
    current_user = UserMessage(content="current")

    turns, remainder = split_history_turns([old_user, old_assistant, compaction, current_user])

    assert turns == []
    assert remainder == [current_user]


def test_split_history_turns_handles_plain_dict_messages():
    turns, remainder = split_history_turns([
        {"type": "user_message", "content": "hi"},
        {"type": "assistant_message", "content": "hello"},
    ])

    assert turns == [[
        {"type": "user_message", "content": "hi"},
        {"type": "assistant_message", "content": "hello"},
    ]]
    assert remainder == []


def test_gpt5_aliases_use_o200k_tokenizer():
    assert utils.tokenizer_for_model("gpt-5").name == "o200k_base"
    assert utils.tokenizer_for_model("gpt-5.4").name == "o200k_base"
    assert utils.tokenizer_for_model("gpt-5.3-codex").name == "o200k_base"


def test_embedding_models_keep_cl100k_tokenizer():
    assert utils.tokenizer_for_model("text-embedding-3-small").name == "cl100k_base"


def test_message_token_count_uses_response_payload_structure():
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "lookup",
        "arguments": '{"query":"hello"}',
    }]

    expected = utils.token_count_payload(tool_call.to_response_format(), model="gpt-5.4")

    assert utils.msg_token_count(tool_call, model="gpt-5.4") == expected
    assert tool_call.api_token_count(model="gpt-5.4") == expected
    assert tool_call.estimated_token_count["gpt-5.4"]["count"] == expected


def test_message_token_count_cache_is_invalidated_by_payload_change():
    message = DeveloperMessage(content="first")
    first = message.api_token_count(model="gpt-5.4")
    message.content = "first second third fourth"
    second = message.api_token_count(model="gpt-5.4")

    assert second > first
    assert message.estimated_token_count["gpt-5.4"]["count"] == second


def test_effective_api_token_count_excludes_expired_message():
    message = DeveloperMessage(content="visible")
    assert message.effective_api_token_count > 0

    message.turns_left = 0

    assert message.effective_api_token_count == 0


def test_gpt5_image_token_count_uses_official_tile_formula():
    assert image_input_token_count(1024, 1024, detail="high", model="gpt-5") == 630
    assert image_input_token_count(4096, 8192, detail="low", model="gpt-5") == 70


def test_gpt54_image_token_count_uses_patch_formula():
    assert image_input_token_count(1024, 1024, detail="high", model="gpt-5.4") == 1024
    assert image_input_token_count(1024, 1024, detail="high", model="gpt-5.4-mini") == 1659


def test_image_message_token_count_ignores_base64_text_volume():
    image = PILImage.new("RGB", (1024, 1024), color="white")
    buffer = BytesIO()
    buffer.name = "sample.png"
    image.save(buffer, format="PNG")
    buffer.seek(0)
    message = ImageMessage(content=buffer, detail="high")

    count = utils.msg_token_count(message, model="gpt-5")

    assert count > 630
    assert count < 800
    assert message.api_token_count(model="gpt-5") == count
    assert message.estimated_token_count["gpt-5"]["count"] == count


def test_load_runtime_env_reads_runtime_dotenv(isolated_runtime_dir, monkeypatch):
    isolated_runtime_dir.mkdir(parents=True, exist_ok=True)
    env_file = isolated_runtime_dir / ".env"
    env_file.write_text(
        """
        # comment
        OPENAI_API_KEY="sk-test"
        export CODEX_AGENT_VALUE='hello world'
        EMPTY=
        """,
        encoding="utf-8",
    )
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("CODEX_AGENT_VALUE", raising=False)
    monkeypatch.delenv("EMPTY", raising=False)

    loaded = utils.load_runtime_env()

    assert loaded == {
        "OPENAI_API_KEY": "sk-test",
        "CODEX_AGENT_VALUE": "hello world",
        "EMPTY": "",
    }
    assert utils.os.environ["OPENAI_API_KEY"] == "sk-test"
    assert utils.os.environ["CODEX_AGENT_VALUE"] == "hello world"


def test_load_runtime_env_does_not_override_existing_values(isolated_runtime_dir, monkeypatch):
    isolated_runtime_dir.mkdir(parents=True, exist_ok=True)
    (isolated_runtime_dir / ".env").write_text("OPENAI_API_KEY=from-file\n", encoding="utf-8")
    monkeypatch.setenv("OPENAI_API_KEY", "from-env")

    loaded = utils.load_runtime_env()

    assert loaded == {}
    assert utils.os.environ["OPENAI_API_KEY"] == "from-env"


def test_load_runtime_env_can_override_existing_values(isolated_runtime_dir, monkeypatch):
    isolated_runtime_dir.mkdir(parents=True, exist_ok=True)
    (isolated_runtime_dir / ".env").write_text("OPENAI_API_KEY=from-file\n", encoding="utf-8")
    monkeypatch.setenv("OPENAI_API_KEY", "from-env")

    loaded = utils.load_runtime_env(override=True)

    assert loaded == {"OPENAI_API_KEY": "from-file"}
    assert utils.os.environ["OPENAI_API_KEY"] == "from-file"
