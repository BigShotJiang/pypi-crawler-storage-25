import json

from codex_agent import Agent


def test_planner_create_exposes_named_todo_provider():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.planner_create(name="feature", entries=[
        {"title": "Inspect", "description": "Read the relevant files."},
        {"title": "Patch", "description": "Make the code change."},
    ])

    assert result == "Todo 'feature' has 2 entry(s), 0 done and 2 remaining."
    provider_output = agent.plugins.planner.current_todos()
    assert "<current_todos>" in provider_output
    assert 'name="feature"' in provider_output
    assert 'index="1"' in provider_output
    assert 'done_state="pending"' in provider_output
    assert 'title="Inspect"' in provider_output
    assert "Read the relevant files." in provider_output


def test_planner_can_add_entries_to_existing_unfinished_todo():
    agent = Agent(session="new", voice_enabled=False)
    agent.tools.planner_create(name="feature", entries=[
        {"title": "Inspect", "description": "Read the relevant files."},
    ])

    result = agent.tools.planner_add(name="feature", entries=[
        {"title": "Patch", "description": "Make the code change."},
    ])

    assert result == "Todo 'feature' has 2 entry(s), 0 done and 2 remaining."
    provider_output = agent.plugins.planner.current_todos()
    assert 'title="Inspect"' in provider_output
    assert 'title="Patch"' in provider_output


def test_planner_add_response_schema_requires_entries():
    agent = Agent(session="new", voice_enabled=False)

    schema = agent.tools.planner_add.to_response_tool()

    assert schema["parameters"]["required"] == ["name", "entries"]
    assert schema["parameters"]["properties"]["entries"]["type"] == "array"


def test_planner_check_clears_only_completed_todo():
    agent = Agent(session="new", voice_enabled=False)
    agent.tools.planner_create(name="feature", entries=[
        {"title": "Inspect", "description": "Read the relevant files."},
        {"title": "Patch", "description": "Make the code change."},
    ])
    agent.tools.planner_create(name="review", entries=[
        {"title": "Run tests", "description": "Verify the patch."},
    ])

    result = agent.tools.planner_check(name="feature", entries=[1])

    assert result == "Todo 'feature' has 2 entry(s), 1 done and 1 remaining."
    assert 'name="feature"' in agent.plugins.planner.current_todos()
    assert 'name="review"' in agent.plugins.planner.current_todos()

    result = agent.tools.planner_check(name="feature", entries=[2])

    assert result == "Todo complete. Cleared todo: feature"
    provider_output = agent.plugins.planner.current_todos()
    assert 'name="feature"' not in provider_output
    assert 'name="review"' in provider_output
    assert list(agent.plugins.planner.todos) == ["review"]


def test_planner_create_accepts_prechecked_entries_and_clears_all_done_todo():
    agent = Agent(session="new", voice_enabled=False)

    result = agent.tools.planner_create(name="done", entries=[
        {"title": "Done", "description": "Already complete.", "done_state": True},
    ])

    assert result == "Todo complete. Cleared todo: done"
    assert agent.plugins.planner.current_todos() is None


def test_planner_clear_removes_named_or_all_todos():
    agent = Agent(session="new", voice_enabled=False)
    agent.tools.planner_create(name="feature", entries=[
        {"title": "Inspect", "description": "Read the relevant files."},
    ])
    agent.tools.planner_create(name="review", entries=[
        {"title": "Run tests", "description": "Verify the patch."},
    ])

    assert agent.tools.planner_clear(name="feature") == "Todo cleared: feature"
    assert list(agent.plugins.planner.todos) == ["review"]
    assert agent.tools.planner_clear() == "All todos cleared."
    assert agent.plugins.planner.current_todos() is None


def test_planner_persists_todos_in_runtime_file(isolated_runtime_dir):
    agent = Agent(session="new", voice_enabled=False)

    agent.tools.planner_create(name="feature", entries=[
        {"title": "Inspect", "description": "Read the relevant files."},
        {"title": "Patch", "description": "Make the code change."},
    ])

    file = isolated_runtime_dir / "planner.json"
    data = json.loads(file.read_text(encoding="utf-8"))
    assert data["type"] == "planner"
    assert [todo["name"] for todo in data["todos"]] == ["feature"]
    assert [entry["title"] for entry in data["todos"][0]["entries"]] == ["Inspect", "Patch"]

    loaded = Agent(session="new", voice_enabled=False)

    assert list(loaded.plugins.planner.todos) == ["feature"]
    assert "Read the relevant files." in loaded.plugins.planner.current_todos()


def test_planner_persists_only_remaining_todos_when_one_completes(isolated_runtime_dir):
    agent = Agent(session="new", voice_enabled=False)
    agent.tools.planner_create(name="done", entries=[
        {"title": "Done", "description": "Finish the work."},
    ])
    agent.tools.planner_create(name="left", entries=[
        {"title": "Left", "description": "Keep this todo."},
    ])

    assert agent.tools.planner_check(name="done", entries=[1]) == "Todo complete. Cleared todo: done"

    file = isolated_runtime_dir / "planner.json"
    data = json.loads(file.read_text(encoding="utf-8"))
    assert [todo["name"] for todo in data["todos"]] == ["left"]
