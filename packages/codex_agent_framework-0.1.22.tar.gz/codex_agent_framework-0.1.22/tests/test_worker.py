from codex_backend_sdk import OutputItem, TextDelta, ToolCall

from codex_agent import AssistantMessage, SummarizerWorker, TurnSummaryWorker, UserMessage, Worker
from codex_agent.tool import Tool, WebSearchTool


class FakeWorkerClient:
    def __init__(self, events=None):
        self.events = events or [TextDelta("done")]
        self.params = None
        self.aborted = False

    def stream(self, prompt, **params):
        self.params = {"prompt": prompt, **params}
        return iter(self.events)

    def abort(self):
        self.aborted = True


def test_worker_runs_one_shot_backend_call():
    client = FakeWorkerClient([TextDelta("hello"), TextDelta(" world")])
    worker = Worker(client=client, system_prompt="Worker prompt", tools=[WebSearchTool()])

    result = worker.run("Summarize this.")

    assert result.content == "hello world"
    assert result.reasoning == ""
    assert client.params["prompt"] == "Summarize this."
    assert client.params["instructions"] == "Worker prompt"
    assert client.params["model"] == "gpt-5.4"
    assert client.params["reasoning"] == "medium"
    assert client.params["verbosity"] == "medium"
    assert client.params["tools"] == [{"type": "web_search"}]
    assert client.params["tool_choice"] == "auto"
    assert client.params["parallel_tool_calls"] is False
    assert client.params["output_schema"] is None


def test_worker_collects_tool_calls_and_output_items():
    tool_call = ToolCall(call_id="call_1", name="lookup", arguments="{}", raw={"type": "function_call"})
    output_item = OutputItem.from_dict({"type": "message", "role": "assistant", "content": []})
    client = FakeWorkerClient([tool_call, output_item])
    worker = Worker(client=client)

    result = worker.run("Do it.")

    assert result.tool_calls == [{"type": "function_call"}]
    assert result.output_items == [output_item.raw]
    assert result.tool_results == []


def test_worker_resolves_one_local_tool_and_includes_output():
    def write_note(text: str):
        return f"wrote:{text}"

    tool = Tool.from_callable(write_note)
    tool_call = ToolCall(
        call_id="call_1",
        name="write_note",
        arguments='{"text": "hello"}',
        raw={"type": "function_call", "name": "write_note"},
    )
    client = FakeWorkerClient([TextDelta("before"), tool_call])
    worker = Worker(client=client, tools=[tool])

    result = worker.run("Write a note.")

    assert result.content == "before\nwrote:hello"
    assert result.tool_results == [{
        "call_id": "call_1",
        "name": "write_note",
        "output": "wrote:hello",
    }]
    assert client.params["tools"][0]["type"] == "function"
    assert client.params["parallel_tool_calls"] is False


def test_worker_call_returns_text_content():
    worker = Worker(client=FakeWorkerClient([TextDelta("short")]))

    assert worker("Do it.") == "short"


def test_worker_subclasses_specialize_system_prompt():
    summarizer = SummarizerWorker(client=FakeWorkerClient())
    turn_summary = TurnSummaryWorker(client=FakeWorkerClient())

    summarizer.run("content")
    turn_summary.run("turn")

    assert "summarization worker" in summarizer.client.params["instructions"]
    assert "RAG archive worker" in turn_summary.client.params["instructions"]
    assert "exactly one dense, semantically meaningful paragraph" in turn_summary.client.params["instructions"]


def test_worker_abort_delegates_to_client():
    client = FakeWorkerClient()
    worker = Worker(client=client)

    worker.abort()

    assert client.aborted is True


def test_worker_can_force_tool_choice():
    client = FakeWorkerClient()
    worker = Worker(client=client, tools=[WebSearchTool()])

    worker.run("Search this.", tool_choice={"type": "web_search"})

    assert client.params["tool_choice"] == {"type": "web_search"}


def test_worker_can_request_structured_json_output():
    schema = {
        "title": "Summary",
        "type": "object",
        "properties": {"summary": {"type": "string"}},
        "required": ["summary"],
        "additionalProperties": False,
    }
    client = FakeWorkerClient([TextDelta('{"summary":"ok"}')])
    worker = Worker(client=client, output_schema=schema)

    result = worker.run("Summarize.")

    assert result.content == '{"summary":"ok"}'
    assert client.params["output_schema"] == schema
    assert client.params["verbosity"] is None


def test_worker_subclass_can_define_tool_choice_and_schema():
    schema = {
        "title": "Answer",
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
        "additionalProperties": False,
    }

    class JsonSearchWorker(Worker):
        tools = [WebSearchTool()]
        tool_choice = {"type": "web_search"}
        output_schema = schema

    client = FakeWorkerClient()
    worker = JsonSearchWorker(client=client)

    worker.run("Find it.")

    assert client.params["tool_choice"] == {"type": "web_search"}
    assert client.params["output_schema"] == schema


def test_turn_summary_worker_formats_message_turns():
    client = FakeWorkerClient([TextDelta("The user asked for a clean worker and it was added.")])
    worker = TurnSummaryWorker(client=client)
    turn = [
        UserMessage(content="Crée un worker de résumé de tour."),
        AssistantMessage(content="Ajout de TurnSummaryWorker."),
    ]

    result = worker.summarize_turn(turn)

    assert result == "The user asked for a clean worker and it was added."
    assert "<UserMessage " in client.params["prompt"]
    assert "type='user_message'" in client.params["prompt"]
    assert "Crée un worker de résumé de tour." in client.params["prompt"]
    assert "<AssistantMessage " in client.params["prompt"]
    assert "type='assistant_message'" in client.params["prompt"]


def test_turn_summary_worker_accepts_previous_summary_as_background_only():
    client = FakeWorkerClient([TextDelta("New durable summary.")])
    worker = TurnSummaryWorker(client=client)
    turn = [
        UserMessage(content="Continue le travail."),
        AssistantMessage(content="C'est fait."),
    ]

    result = worker.summarize_turn(turn, previous_summary="Previous durable context.")

    assert result == "New durable summary."
    assert "Previous turn summary for background only" in client.params["prompt"]
    assert "<previous_turn_summary>\nPrevious durable context.\n</previous_turn_summary>" in client.params["prompt"]
    assert "<turn_to_summarize>" in client.params["prompt"]
    assert "Continue le travail." in client.params["prompt"]
