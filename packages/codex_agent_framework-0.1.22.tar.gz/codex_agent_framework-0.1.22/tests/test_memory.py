from datetime import datetime

import pytest

import codex_agent.utils as utils
from codex_agent import Agent
from codex_agent.event import AssistantTurnEndEvent, MemoryArchiveErrorEvent
from codex_agent.builtin_plugins.memory import RAGMemory, format_memory_results_xml
from codex_agent.message import AssistantMessage, CompactionMessage, InterruptMessage, UserMessage
from codex_agent.tool import reset_current_agent, set_current_agent


def embedded_message(content, embedding, timestamp="20260101T120000.000", session_id=None):
    return UserMessage(
        content=content,
        embedding=embedding,
        timestamp=timestamp,
        session_id=session_id,
    )


def test_rank_weights_recent_context_messages_more_heavily():
    memory = RAGMemory(half_life_steps=2, moment_exponent=3)
    older_match = embedded_message("older topic", [1.0, 0.0])
    recent_match = embedded_message("recent topic", [0.0, 1.0])
    context = [
        UserMessage(content="older prompt", embedding=[1.0, 0.0]),
        AssistantMessage(content="recent answer", embedding=[0.0, 1.0]),
    ]

    ranked = memory.rank(context, messages=[older_match, recent_match], recent_is_better=False)

    assert ranked == [recent_match, older_match]
    assert memory.relevance_score(recent_match, context) > memory.relevance_score(older_match, context)


def test_rank_adds_pandora_style_temporal_recency_bonus():
    memory = RAGMemory(half_life_days=2)
    old = embedded_message("same topic, old", [1.0, 0.0], timestamp="20260101T120000.000")
    recent = embedded_message("same topic, recent", [1.0, 0.0], timestamp="20260103T120000.000")
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]
    now = datetime.strptime("20260103T120000.000", "%Y%m%dT%H%M%S.%f")

    ranked = memory.rank(context, messages=[old, recent], now=now)

    assert ranked == [recent, old]
    assert memory.temporal_score(recent, now=now) == pytest.approx(1.0)
    assert memory.temporal_score(old, now=now) == pytest.approx(0.5)


def test_retrieve_limits_and_excludes_current_session_without_mutating_memory():
    current = embedded_message("current session", [1.0, 0.0], session_id="current")
    first = embedded_message("best external", [1.0, 0.0], session_id="past")
    second = embedded_message("second external", [0.8, 0.2], session_id="past")
    memory = RAGMemory(messages=[current, first, second])
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]

    retrieved = memory.retrieve(
        context,
        limit=1,
        recent_is_better=False,
        exclude_session_id="current",
    )

    assert retrieved == [first]
    assert memory.messages == [current, first, second]


def test_retrieve_filters_memory_entries_between_timestamp_cutoffs():
    older = embedded_message("older", [1.0, 0.0], timestamp="20260101T120000.000")
    middle = embedded_message("middle", [1.0, 0.0], timestamp="20260102T120000.000")
    newer = embedded_message("newer", [1.0, 0.0], timestamp="20260103T120000.000")
    memory = RAGMemory(messages=[older, middle, newer])
    context = [UserMessage(content="topic", embedding=[1.0, 0.0])]

    retrieved = memory.retrieve(
        context,
        since="20260102T120000.000",
        until="20260103T120000.000",
        recent_is_better=False,
    )

    assert retrieved == [middle, newer]


def test_missing_embedding_requires_an_agent_capable_of_embedding():
    memory = RAGMemory()
    message = UserMessage(content="not embedded")

    with pytest.raises(ValueError, match="no embedding"):
        memory.rank([message], messages=[message])


def test_ensure_embeddings_batches_missing_messages():
    agent = CountingBatchAgent()
    memory = RAGMemory(agent=agent)
    already_embedded = UserMessage(content="cached", embedding=[0.0, 1.0])
    first = UserMessage(content="first")
    second = UserMessage(content="second")

    memory.ensure_embeddings([already_embedded, first, second])

    assert agent.ai.batch_calls == [[first, second]]
    assert agent.ai.message_calls == []
    assert already_embedded.embedding == [0.0, 1.0]
    assert first.embedding == [1.0, 0.0]
    assert second.embedding == [1.0, 0.0]


def test_ensure_embeddings_handles_empty_context_messages():
    agent = CountingBatchAgent()
    memory = RAGMemory(agent=agent)
    empty = UserMessage(content="")
    filled = UserMessage(content="filled")

    memory.ensure_embeddings([empty, filled])

    assert agent.ai.batch_calls == [[empty, filled]]


class FakeEmbeddingAI:
    def embed_message(self, message, precision=5, dimensions=128):
        content = str(message.get("content") or "").lower()
        if "python" in content:
            embedding = [1.0, 0.0]
        elif "rust" in content:
            embedding = [0.0, 1.0]
        else:
            embedding = [0.7, 0.3]
        message.embedding = embedding
        return embedding

    def embed_messages(self, messages, precision=5, dimensions=128):
        return [
            self.embed_message(message, precision=precision, dimensions=dimensions)
            for message in messages
        ]


class StaticEmbeddingAI:
    def embed_message(self, message, precision=5, dimensions=128):
        message.embedding = [1.0, 0.0]
        return message.embedding

    def embed_messages(self, messages, precision=5, dimensions=128):
        return [
            self.embed_message(message, precision=precision, dimensions=dimensions)
            for message in messages
        ]


class FakeEmbeddingAgent:
    ai = StaticEmbeddingAI()


class CountingBatchEmbeddingAI(StaticEmbeddingAI):
    def __init__(self):
        self.message_calls = []
        self.batch_calls = []

    def embed_message(self, message, precision=5, dimensions=128):
        self.message_calls.append(message)
        return super().embed_message(message, precision=precision, dimensions=dimensions)

    def embed_messages(self, messages, precision=5, dimensions=128):
        messages = list(messages)
        self.batch_calls.append(messages)
        for message in messages:
            message.embedding = [1.0, 0.0]
        return [message.embedding for message in messages]


class CountingBatchAgent:
    def __init__(self):
        self.ai = CountingBatchEmbeddingAI()


class OneShotAI:
    def run(self, **params):
        return AssistantMessage(content="done")

    def embed_message(self, message, precision=5, dimensions=128):
        return StaticEmbeddingAI().embed_message(
            message,
            precision=precision,
            dimensions=dimensions,
        )

    def embed_messages(self, messages, precision=5, dimensions=128):
        return StaticEmbeddingAI().embed_messages(
            messages,
            precision=precision,
            dimensions=dimensions,
        )


class FakeTurnSummaryWorker:
    turns = []
    previous_summaries = []

    def summarize_turn(self, turn, previous_summary=None):
        self.turns.append(turn)
        self.previous_summaries.append(previous_summary)
        return "Résumé durable du dernier tour."


class SynchronousThread:
    created = []

    def __init__(self, target, daemon=False):
        self.target = target
        self.daemon = daemon
        self.started = False
        self.created.append(self)

    def start(self):
        self.started = True
        self.target()


def test_agent_initializes_persistent_runtime_memory(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new", voice_enabled=False)

    assert agent.plugins.memory.memory.agent is agent
    assert agent.plugins.memory.memory.file == str(tmp_path / "memory.json")
    assert agent.plugins.memory.memory.messages == []


def test_memory_plugin_declares_assistant_turn_end_archive_handler(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))

    agent = Agent(session="new", voice_enabled=False)

    handlers = agent.events.handlers.get(agent.events.event_type(AssistantTurnEndEvent), [])
    assert agent.plugins.memory.archive_completed_turn in handlers


def test_agent_archives_completed_turn_to_memory_from_plugin_event_handler(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    monkeypatch.setattr("codex_agent.builtin_plugins.memory.TurnSummaryWorker", FakeTurnSummaryWorker)
    monkeypatch.setattr("codex_agent.builtin_plugins.memory.BackgroundThread", SynchronousThread)
    FakeTurnSummaryWorker.turns = []
    FakeTurnSummaryWorker.previous_summaries = []
    SynchronousThread.created = []

    agent = Agent(session="new", voice_enabled=False)
    agent.plugins.memory.config.auto_archive = True
    agent.ai = OneShotAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    agent.ai.embed_message = FakeEmbeddingAI().embed_message
    agent.plugins.memory.memory.remember(
        "Résumé du tour précédent.",
        title="turn:previous",
        source="turn_summary",
        metadata={"session_id": agent.current_session_id},
    )
    agent.add_message(UserMessage(content="Souviens-toi de ce tour."))

    outcome = agent.mainloop_manager.run_agentic_turn()
    assert outcome.completed is True
    assert outcome.reason == "completed"

    assert len(SynchronousThread.created) == 1
    assert SynchronousThread.created[0].daemon is True
    assert FakeTurnSummaryWorker.turns
    assert FakeTurnSummaryWorker.previous_summaries == ["Résumé du tour précédent."]
    assert any(isinstance(message, UserMessage) for message in FakeTurnSummaryWorker.turns[0])
    assert len(agent.plugins.memory.memory.messages) == 2
    assert agent.plugins.memory.memory.messages[-1].content == "Résumé durable du dernier tour."
    assert agent.plugins.memory.memory.messages[-1].source == "turn_summary"


def test_agent_can_disable_completed_turn_memory_archiving(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    monkeypatch.setattr("codex_agent.builtin_plugins.memory.TurnSummaryWorker", FakeTurnSummaryWorker)
    monkeypatch.setattr("codex_agent.builtin_plugins.memory.BackgroundThread", SynchronousThread)
    FakeTurnSummaryWorker.turns = []
    SynchronousThread.created = []

    agent = Agent(session="new", voice_enabled=False)
    agent.plugins.memory.config.auto_archive = False
    agent.ai = OneShotAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    agent.ai.embed_message = FakeEmbeddingAI().embed_message
    agent.add_message(UserMessage(content="Ne pas archiver automatiquement."))

    outcome = agent.mainloop_manager.run_agentic_turn()
    assert outcome.completed is True
    assert outcome.reason == "completed"

    assert SynchronousThread.created == []
    assert FakeTurnSummaryWorker.turns == []
    assert agent.plugins.memory.memory.messages == []


def test_agent_emits_event_when_completed_turn_memory_archiving_fails(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    monkeypatch.setattr("codex_agent.builtin_plugins.memory.BackgroundThread", SynchronousThread)
    SynchronousThread.created = []

    agent = Agent(session="new", voice_enabled=False)
    agent.session.messages = [
        UserMessage(content="Archive this."),
        AssistantMessage(content="done"),
    ]
    events = []
    agent.on(MemoryArchiveErrorEvent, events.append)

    def fail_archive(turn):
        raise RuntimeError("summary failed")

    monkeypatch.setattr(agent.plugins.memory, "archive_turn", fail_archive)

    thread = agent.plugins.memory.archive_last_turn_async()

    assert thread is not None
    assert events
    assert events[0].error == "summary failed"
    assert events[0].end_message_id == agent.session.messages[-1].id


def test_memory_last_complete_turn_uses_final_assistant_boundaries(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    previous_user = UserMessage(content="previous")
    previous_final = AssistantMessage(content="previous done")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    mid_turn_user = UserMessage(content="extra context while you work")
    final = AssistantMessage(content="done")
    agent.session.messages = [previous_user, previous_final, tool_call, mid_turn_user, final]

    assert agent.plugins.memory.last_complete_turn() == [tool_call, mid_turn_user, final]


def test_memory_last_complete_turn_excludes_latest_compaction_boundary(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    old_user = UserMessage(content="old")
    old_final = AssistantMessage(content="old done")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_1"}])
    current_user = UserMessage(content="current")
    current_final = AssistantMessage(content="current done")
    agent.session.messages = [old_user, old_final, compaction, current_user]

    assert agent.plugins.memory.last_complete_turn() is None

    agent.session.messages.append(current_final)

    assert agent.plugins.memory.last_complete_turn() == [current_user, current_final]


def test_memory_last_complete_turn_treats_interruption_as_turn_end(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    user = UserMessage(content="stop this")
    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]
    interrupted = InterruptMessage()
    agent.session.messages = [user, tool_call, interrupted]

    assert agent.plugins.memory.last_complete_turn() == [user, tool_call, interrupted]


def test_memory_plugin_config_commands_update_and_persist_settings(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)

    display = agent("/memory_config").result
    assert "auto_archive: False" in display
    assert "max_tokens: 8000" in display

    result = agent("/memory_config auto_archive=true max_tokens=3 precision=4 half_life_days=1.5").result

    assert "auto_archive=True" in result
    assert "max_tokens=3" in result
    assert "precision=4" in result
    assert "half_life_days=1.5" in result
    assert agent.plugins.memory.config.auto_archive is True
    assert agent.plugins.memory.config.max_tokens == 3
    assert agent.plugins.memory.config.precision == 4
    assert agent.plugins.memory.config.half_life_days == 1.5
    assert RAGMemory(file=str(tmp_path / "memory.json")).settings.max_tokens == 3

    assert agent("/memory_auto_archive").result == "memory_auto_archive: on"
    assert agent("/memory_auto_archive off").result == "Updated memory config: auto_archive=False"
    assert agent.plugins.memory.config.auto_archive is False

    try:
        agent("/memory_config unknown=1")
    except ValueError as exc:
        assert "Unknown memory config keys: unknown" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown memory config key")


def test_memory_tools_create_edit_delete_and_persist_entries(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    token = set_current_agent(agent)
    try:
        created = agent.tools.memory_add(
            content="Python est le langage préféré de Baptiste.",
            title="language",
        )
        entry = agent.plugins.memory.memory.messages[0]
        assert f"Created memory {entry.id}" in created
        assert entry.title == "language"
        assert (tmp_path / "memory.json").is_file()

        loaded = RAGMemory(file=str(tmp_path / "memory.json"))
        assert loaded.messages[0].id == entry.id
        assert loaded.messages[0].embedding == [1.0, 0.0]

        updated = agent.tools.memory_edit(
            memory_id="language",
            content="Rust est aussi important pour Baptiste.",
        )
        assert f"Updated memory {entry.id}" in updated
        assert agent.plugins.memory.memory.messages[0].content.startswith("Rust")
        assert agent.plugins.memory.memory.messages[0].embedding == [0.0, 1.0]

        deleted = agent.tools.memory_delete(memory_id="language")
        assert f"Deleted memory {entry.id}" in deleted
        assert agent.plugins.memory.memory.messages == []
        assert RAGMemory(file=str(tmp_path / "memory.json")).messages == []
    finally:
        reset_current_agent(token)


def test_memory_search_tool_retrieves_without_adding_entries(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    agent.plugins.memory.memory.remember("Python doit être favorisé pour les scripts.", title="python")
    agent.plugins.memory.memory.remember("Rust est utile pour le code système.", title="rust")
    before = list(agent.plugins.memory.memory.messages)

    token = set_current_agent(agent)
    try:
        result = agent.tools.memory_search(query="python scripting", limit=1)
    finally:
        reset_current_agent(token)

    assert result.startswith("<memory ")
    assert " id=" in result
    assert 'title="python"' in result
    assert "score=" not in result
    assert "Python doit être favorisé" in result
    assert result.endswith("</memory>")
    assert agent.plugins.memory.memory.messages == before


def test_memory_search_tool_excludes_entries_after_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    before = agent.plugins.memory.memory.remember("Python avant compaction.", title="before")
    after = agent.plugins.memory.memory.remember("Python apres compaction.", title="after")
    before.timestamp = "20260101T120000.000"
    after.timestamp = "20260103T120000.000"
    agent.session.messages = [
        CompactionMessage(
            timestamp="20260102T120000.000",
            output_items=[{"type": "compaction_summary", "id": "cs_1"}],
        ),
        UserMessage(content="python now"),
    ]

    token = set_current_agent(agent)
    try:
        result = agent.tools.memory_search(query="python", limit=5)
    finally:
        reset_current_agent(token)

    assert 'title="before"' in result
    assert 'title="after"' not in result


def test_search_defaults_to_similarity_without_temporal_bonus():
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    similar_old = embedded_message(
        "semantic match",
        [1.0, 0.0],
        timestamp="20260101T120000.000",
    )
    less_similar_recent = embedded_message(
        "newer but weaker",
        [0.0, 1.0],
        timestamp="20260103T120000.000",
    )
    memory.messages = [less_similar_recent, similar_old]

    results = memory.search(
        "semantic query",
        limit=1,
        now=datetime.strptime("20260103T120000.000", "%Y%m%dT%H%M%S.%f"),
    )

    assert results == [similar_old]


def test_search_filters_memory_entries_between_timestamp_cutoffs():
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    older = embedded_message("older", [1.0, 0.0], timestamp="20260101T120000.000")
    middle = embedded_message("middle", [1.0, 0.0], timestamp="20260102T120000.000")
    newer = embedded_message("newer", [1.0, 0.0], timestamp="20260103T120000.000")
    memory.messages = [older, middle, newer]

    results = memory.search(
        "semantic query",
        since="20260102T120000.000",
        until="20260102T120000.000",
    )

    assert results == [middle]


def test_memory_edit_refreshes_entry_timestamp(monkeypatch):
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    entry = memory.remember("Ancien contenu", title="note")
    entry.timestamp = "20260101T120000.000"
    monkeypatch.setattr(
        "codex_agent.builtin_plugins.memory.timestamp",
        lambda: "20260102T130000.000",
    )

    updated = memory.edit("note", content="Nouveau contenu")

    assert updated.timestamp == "20260102T130000.000"
    assert updated.content == "Nouveau contenu"



def test_format_memory_results_xml_includes_timestamp_and_source():
    memory = RAGMemory(agent=FakeEmbeddingAgent())
    entry = memory.remember(
        "Résumé utile.",
        title="summary",
        source="turn_summary",
    )
    entry.timestamp = "20260101T120501.000"

    result = format_memory_results_xml([entry], root="retrieved_memories")

    assert result.startswith("<retrieved_memories>")
    assert 'title="summary"' in result
    assert 'source="turn_summary"' in result
    assert 'timestamp="20260101T120501.000"' in result
    assert "start_timestamp" not in result
    assert "end_timestamp" not in result
    assert "Résumé utile." in result


def test_retrieved_memory_provider_uses_context_since_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    agent.plugins.memory.memory.remember("Python doit être favorisé pour les scripts.", title="python")
    agent.plugins.memory.memory.remember("Rust est utile pour le code système.", title="rust")

    old = UserMessage(content="python before compaction")
    compaction = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_1"}])
    current = UserMessage(content="rust now")
    agent.session.messages = [old, compaction, current]

    provider_output = next(
        message.content for message in agent.context_manager.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert provider_output.startswith("<retrieved_memories>")
    assert 'title="rust"' in provider_output
    assert 'title="python"' in provider_output
    assert provider_output.index('title="rust"') < provider_output.index('title="python"')
    assert old.embedding is None
    assert current.embedding == [0.0, 1.0]


def test_retrieved_memory_provider_excludes_entries_after_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    before = agent.plugins.memory.memory.remember("Rust avant compaction.", title="before")
    after = agent.plugins.memory.memory.remember("Rust apres compaction.", title="after")
    before.timestamp = "20260101T120000.000"
    after.timestamp = "20260103T120000.000"
    agent.session.messages = [
        CompactionMessage(
            timestamp="20260102T120000.000",
            output_items=[{"type": "compaction_summary", "id": "cs_1"}],
        ),
        UserMessage(content="rust now"),
    ]

    provider_output = next(
        message.content for message in agent.context_manager.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert 'title="before"' in provider_output
    assert 'title="after"' not in provider_output


def test_retrieved_memory_provider_respects_config_max_tokens(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", voice_enabled=False)
    agent.plugins.memory.config.max_tokens = 3
    agent.ai = FakeEmbeddingAI()
    agent.plugins.memory.memory.set_attr("_agent", agent)
    agent.plugins.memory.memory.remember("rust one", title="first")
    agent.plugins.memory.memory.remember("rust two", title="second")
    agent.session.messages = [UserMessage(content="rust now")]

    provider_output = next(
        message.content for message in agent.context_manager.get_providers_messages()
        if message.name == "retrieved_memory"
    )

    assert provider_output.count("<memory ") == 1
    assert ('title="first"' in provider_output) != ('title="second"' in provider_output)
