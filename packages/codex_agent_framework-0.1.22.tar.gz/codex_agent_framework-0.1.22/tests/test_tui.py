import signal
from codex_agent.tui import lifecycle as tui


def test_install_tui_cleanup_handlers_clears_registered_pid_on_signal(monkeypatch):
    calls = []
    handlers = {}
    previous_handlers = {}

    def fake_getsignal(signum):
        return previous_handlers.get(signum, signal.SIG_IGN)

    def fake_signal(signum, handler):
        handlers[signum] = handler

    monkeypatch.setattr(tui.atexit, "register", lambda func, **kwargs: calls.append(("atexit", func, kwargs)))
    monkeypatch.setattr(tui.signal, "getsignal", fake_getsignal)
    monkeypatch.setattr(tui.signal, "signal", fake_signal)
    monkeypatch.setattr(tui, "clear_tui", lambda pid=None: calls.append(("clear", pid)))

    tui.install_tui_cleanup_handlers(pid=1234)
    handlers[signal.SIGHUP](signal.SIGHUP, None)

    assert calls == [
        ("atexit", tui.clear_tui, {"pid": 1234}),
        ("clear", 1234),
    ]
    assert set(handlers) == {signal.SIGTERM, signal.SIGHUP, signal.SIGINT}


def test_install_tui_cleanup_handlers_skips_signals_outside_main_thread(monkeypatch):
    calls = []
    worker_thread = object()

    monkeypatch.setattr(tui.atexit, "register", lambda func, **kwargs: calls.append(("atexit", kwargs)))
    monkeypatch.setattr(tui.threading, "current_thread", lambda: worker_thread)
    monkeypatch.setattr(
        tui.signal,
        "signal",
        lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("signal should not be installed")),
    )

    assert tui.install_tui_cleanup_handlers(pid=1234) is False
    assert calls == [("atexit", {"pid": 1234})]


def test_current_tui_clears_stale_pid(monkeypatch):
    calls = []
    data = {"pid": 9999}

    monkeypatch.setattr(tui.os.path, "isfile", lambda path: True)
    monkeypatch.setattr(tui.modict, "load", lambda path: data)
    monkeypatch.setattr(tui, "pid_alive", lambda pid: False)
    monkeypatch.setattr(tui, "clear_tui", lambda pid=None: calls.append(pid))

    assert tui.current_tui() is None
    assert calls == [None]


def test_terminal_command_candidates_include_macos_terminal(monkeypatch):
    monkeypatch.setattr(tui.sys, "platform", "darwin")
    commands = list(tui.terminal_command_candidates("codex-agent chat"))

    assert commands == [["osascript", "-e", 'tell application "Terminal" to do script "codex-agent chat"']]


def test_terminal_command_candidates_include_windows_terminals(monkeypatch):
    monkeypatch.setattr(tui.sys, "platform", "win32")
    commands = list(tui.terminal_command_candidates("codex-agent chat"))

    assert commands[0][:2] == ["wt.exe", "powershell"]
    assert commands[1][:2] == ["powershell", "-NoExit"]
    assert commands[2][:3] == ["cmd", "/c", "start"]


def test_terminal_process_kwargs_are_platform_aware(monkeypatch):
    monkeypatch.setattr(tui.os, "name", "posix")
    assert tui.terminal_process_kwargs()["start_new_session"] is True

    monkeypatch.setattr(tui.os, "name", "nt")
    monkeypatch.setattr(tui.subprocess, "CREATE_NEW_PROCESS_GROUP", 512, raising=False)
    assert tui.terminal_process_kwargs()["creationflags"] == 512
