from types import SimpleNamespace

from codex_agent.ai import AIClient, MAX_EMBEDDING_INPUT_TOKENS
from codex_agent.message import DeveloperMessage, SystemMessage
from codex_agent.utils import token_count


class FakeEmbeddings:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        count = len(kwargs["input"]) if isinstance(kwargs.get("input"), list) else 1
        return SimpleNamespace(data=[
            SimpleNamespace(embedding=[float(index + 1), 0.0])
            for index in range(count)
        ])


class FakeOpenAIClient:
    def __init__(self):
        self.embeddings = FakeEmbeddings()


class FakeInputTokens:
    def __init__(self):
        self.calls = []

    def count(self, **payload):
        self.calls.append(payload)
        return SimpleNamespace(input_tokens=123)


class FakeResponses:
    def __init__(self):
        self.input_tokens = FakeInputTokens()


class FakeOpenAIClientWithResponses(FakeOpenAIClient):
    def __init__(self):
        super().__init__()
        self.responses = FakeResponses()


def test_embed_content_truncates_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_content(long_content)

    embedded_input = ai._client.embeddings.calls[0]["input"]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS


def test_embed_contents_truncates_each_input_to_embedding_token_budget():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    long_content = "token " * (MAX_EMBEDDING_INPUT_TOKENS + 1000)

    ai.embed_contents([long_content])

    embedded_input = ai._client.embeddings.calls[0]["input"][0]
    assert token_count(embedded_input) <= MAX_EMBEDDING_INPUT_TOKENS


def test_embed_messages_batches_request_and_assigns_embeddings():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    first = DeveloperMessage(content="first")
    second = DeveloperMessage(content="second")

    embeddings = ai.embed_messages([first, second])

    assert len(ai._client.embeddings.calls) == 1
    assert ai._client.embeddings.calls[0]["input"] == ["first", "second"]
    assert embeddings == [first.embedding, second.embedding]
    assert first.embedding == [1.0, 0.0]
    assert second.embedding == [1.0, 0.0]


def test_embed_messages_skips_empty_content_without_api_error():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    empty = DeveloperMessage(content="")
    blank = DeveloperMessage(content="   ")
    filled = DeveloperMessage(content=" filled ")

    embeddings = ai.embed_messages([empty, blank, filled], dimensions=2)

    assert len(ai._client.embeddings.calls) == 1
    assert ai._client.embeddings.calls[0]["input"] == ["filled"]
    assert empty.embedding == [0.0, 0.0]
    assert blank.embedding == [0.0, 0.0]
    assert filled.embedding == [1.0, 0.0]
    assert embeddings == [empty.embedding, blank.embedding, filled.embedding]


def test_embed_message_assigns_zero_embedding_for_empty_content():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClient()
    message = DeveloperMessage(content="")

    embedding = ai.embed_message(message, dimensions=2)

    assert embedding == [0.0, 0.0]
    assert message.embedding == [0.0, 0.0]
    assert ai._client.embeddings.calls == []


def test_count_input_tokens_uses_responses_input_tokens_endpoint():
    ai = AIClient(agent=None)
    ai._client = FakeOpenAIClientWithResponses()

    count = ai.count_input_tokens(model="gpt-5", input="hello", tools=[{"type": "web_search_preview"}])

    assert count == 123
    assert ai._client.responses.input_tokens.calls == [{
        "model": "gpt-5",
        "input": "hello",
        "tools": [{"type": "web_search_preview"}],
    }]


def test_codex_backend_params_move_leading_system_messages_to_instructions():
    ai = AIClient(agent=None)

    params = ai._to_codex_stream_params({
        "messages": [
            SystemMessage(content="Base rules."),
            SystemMessage(content="Extra rules."),
            DeveloperMessage(content="visible context"),
            SystemMessage(content="ignored late rules."),
        ],
        "model": "gpt-5.4",
    })

    assert params["instructions"] == "Base rules.\n\nExtra rules."
    assert params["conversation_history"] == [{
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "visible context"}],
    }]
