import builtins

from modict import modict

from codex_agent import tray


def run_background_immediately(controller, monkeypatch):
    monkeypatch.setattr(controller, "run_in_background", lambda name, target: target())


class FakeService:
    def __init__(self, results=None):
        self.calls = []
        self.installs = []
        self.results = list(results or [])
        self.active_state = False

    def active(self, name):
        self.calls.append(("active", name))
        return self.active_state

    def run(self, command, name, *extra_args, check=False):
        self.calls.append((command, *extra_args, name))
        if self.results:
            return self.results.pop(0)
        return modict(returncode=0, stdout="", stderr="")

    def install(self, **kwargs):
        self.installs.append(kwargs)


def test_agent_tray_controls_user_service(monkeypatch):
    service = FakeService()
    controller = tray.AgentTray(base_url="http://agent.local", service=service)
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: True)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.start_server()
    controller.stop_server()

    assert service.calls == [
        ("start", "--no-block", tray.SERVER_SERVICE_NAME),
        ("stop", "--no-block", tray.SERVER_SERVICE_NAME),
    ]


def test_agent_tray_reports_systemctl_errors(monkeypatch):
    messages = []
    service = FakeService(results=[modict(returncode=1, stdout="", stderr="unit not found")])
    controller = tray.AgentTray(base_url="http://agent.local", service=service)
    monkeypatch.setattr(controller, "notify", lambda title, message: messages.append((title, message)))

    controller.run_systemctl("start")

    assert messages == [("Codex Agent", "unit not found")]


def test_agent_tray_installs_missing_service_before_start(monkeypatch):
    messages = []
    service = FakeService(results=[
        modict(returncode=4, stdout="", stderr="Unit codex-agent.service could not be found."),
        modict(returncode=0, stdout="", stderr=""),
    ])
    controller = tray.AgentTray(base_url="http://agent.local:9999", service=service)
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "notify", lambda title, message: messages.append((title, message)))
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: True)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.start_server()

    assert service.calls == [
        ("start", "--no-block", tray.SERVER_SERVICE_NAME),
        ("start", "--no-block", tray.SERVER_SERVICE_NAME),
    ]
    assert service.installs == [{"host": "agent.local", "port": 9999, "enable": True, "start": False}]
    assert ("Codex Agent", "Server service not installed. Installing it now.") in messages


def test_agent_tray_open_tui_uses_local_terminal(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    monkeypatch.setattr(tray, "open_tui_terminal", lambda base_url: calls.append(base_url) or object())
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.open_tui()

    assert calls == ["http://agent.local"]


def test_agent_tray_close_tui_uses_local_tui_pid(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    monkeypatch.setattr(tray, "current_tui", lambda: modict(pid=1234))
    monkeypatch.setattr(tray, "terminate_tui", lambda pid: calls.append(pid))
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.close_tui()

    assert calls == [1234]


def test_agent_tray_refresh_state_uses_systemd_service_state(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    monkeypatch.setattr(controller, "service_active", lambda: True)
    monkeypatch.setattr(tray, "current_tui", lambda: None)

    assert controller.refresh_state() is True
    assert controller.server_running() is True


def test_agent_tray_refresh_state_uses_local_tui_state(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    monkeypatch.setattr(controller, "service_active", lambda: False)
    monkeypatch.setattr(tray, "current_tui", lambda: modict(pid=1234))

    assert controller.refresh_state() is True
    assert controller.server_running() is False
    assert controller.tui_running() is True


def test_agent_tray_refresh_state_keeps_tui_state_independent_from_server(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    monkeypatch.setattr(controller, "service_active", lambda: False)
    monkeypatch.setattr(tray, "current_tui", lambda: modict(pid=1234))

    assert controller.refresh_state() is True
    assert controller.server_running() is False
    assert controller.tui_running() is True


def test_import_gi_uses_system_dist_packages(monkeypatch, tmp_path):
    imports = []
    fake_dist_packages = tmp_path / "dist-packages"
    fake_dist_packages.mkdir()
    original_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "gi":
            imports.append(list(tray.sys.path))
            if str(fake_dist_packages) not in tray.sys.path:
                raise ImportError("no gi")
            return "gi-module"
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(tray.os.path, "isdir", lambda path: path == str(fake_dist_packages))
    monkeypatch.setattr(tray, "sys", type("FakeSys", (), {"path": []})())
    monkeypatch.setattr(tray, "SYSTEM_DIST_PACKAGES", str(fake_dist_packages))
    monkeypatch.setattr(builtins, "__import__", fake_import)

    assert tray.import_gi() == "gi-module"
    assert len(imports) == 2


def test_agent_tray_updates_appindicator_menu(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    controller.Gtk = object()

    class Icon:
        def set_menu(self, menu):
            calls.append(menu)

    controller.icon = Icon()
    monkeypatch.setattr(controller, "gtk_menu", lambda: "menu")

    controller.update_menu()

    assert calls == ["menu"]


def test_agent_tray_schedules_gtk_menu_updates_from_worker_thread(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    controller._ui_thread = object()

    class GLib:
        @staticmethod
        def idle_add(callback):
            calls.append(callback)

    controller.GLib = GLib
    monkeypatch.setattr(controller, "_update_menu_now", lambda: calls.append("update-now"))

    controller.update_menu()

    assert len(calls) == 1
    assert calls[0].__name__ == "<lambda>"


def test_agent_tray_updates_gtk_menu_immediately_on_ui_thread(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    controller._ui_thread = tray.threading.current_thread()

    class GLib:
        @staticmethod
        def idle_add(callback):
            calls.append("idle")

    controller.GLib = GLib
    monkeypatch.setattr(controller, "_update_menu_now", lambda: calls.append("update-now"))

    controller.update_menu()

    assert calls == ["update-now"]


def test_agent_tray_start_waits_for_server_health(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "run_systemctl", lambda *args: modict(returncode=0, stdout="", stderr=""))
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: calls.append(kwargs) or True)
    monkeypatch.setattr(controller, "update_menu", lambda: calls.append("update"))

    controller.start_server()

    assert {"running": True} in calls
    assert calls[-1] == "update"


def test_agent_tray_stop_waits_for_server_to_go_down(monkeypatch):
    calls = []
    controller = tray.AgentTray(base_url="http://agent.local")
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "run_systemctl", lambda *args: modict(returncode=0, stdout="", stderr=""))
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: calls.append(kwargs) or True)
    monkeypatch.setattr(controller, "update_menu", lambda: calls.append("update"))

    controller.stop_server()

    assert {"running": False, "timeout": 5.0} in calls
    assert calls[-1] == "update"


def test_agent_tray_notifies_when_start_health_check_times_out(monkeypatch):
    messages = []
    controller = tray.AgentTray(base_url="http://agent.local")
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "run_systemctl", lambda *args: modict(returncode=0, stdout="", stderr=""))
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: False)
    monkeypatch.setattr(controller, "notify", lambda title, message: messages.append((title, message)))
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.start_server()

    assert messages == [("Codex Agent", "Server service started, but service state is not active yet.")]


def test_agent_tray_wait_for_server_polls_until_expected_state(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    states = iter([False, False, True])
    sleeps = []
    def fake_refresh_state():
        controller._server_running = next(states)
        controller._tui_running = False
        return True
    monkeypatch.setattr(controller, "refresh_state", fake_refresh_state)
    monkeypatch.setattr(tray.time, "sleep", lambda delay: sleeps.append(delay))
    times = iter([0.0, 0.1, 0.2, 0.3, 0.4])
    monkeypatch.setattr(tray.time, "monotonic", lambda: next(times))

    assert controller.wait_for_server(running=True, timeout=1.0, interval=0.25) is True
    assert sleeps == [0.25, 0.25]


def test_agent_tray_poll_state_updates_menu_only_when_state_changes(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    calls = []
    changes = iter([False, True, False])
    monkeypatch.setattr(controller, "refresh_state", lambda: next(changes))
    monkeypatch.setattr(controller, "apply_menu_state", lambda: calls.append("apply"))

    assert controller.poll_state() is True
    assert calls == []

    assert controller.poll_state() is True
    assert calls == ["apply"]

    assert controller.poll_state() is True
    assert calls == ["apply"]


def test_agent_tray_wait_for_display_times_out_without_display(monkeypatch):
    sleeps = []
    monkeypatch.delenv("DISPLAY", raising=False)
    monkeypatch.delenv("WAYLAND_DISPLAY", raising=False)
    monkeypatch.setattr(tray.time, "sleep", lambda delay: sleeps.append(delay))
    times = iter([0.0, 0.1, 0.3])
    monkeypatch.setattr(tray.time, "monotonic", lambda: next(times))

    assert tray.wait_for_display(timeout=0.2, interval=0.25) is False
    assert sleeps == [0.25]


def test_agent_tray_waits_for_status_notifier_host(monkeypatch):
    sleeps = []
    states = iter([False, False, True])

    monkeypatch.setattr(tray, "status_notifier_host_registered", lambda gi=None: next(states))
    monkeypatch.setattr(tray.time, "sleep", lambda delay: sleeps.append(delay))

    assert tray.wait_for_status_notifier_host(timeout=1.0, interval=0.25, stable_for=0) is True
    assert sleeps == [0.25, 0.25]


def test_agent_tray_status_notifier_wait_times_out(monkeypatch):
    sleeps = []
    times = iter([0.0, 0.1, 0.3])

    monkeypatch.setattr(tray, "status_notifier_host_registered", lambda gi=None: False)
    monkeypatch.setattr(tray.time, "sleep", lambda delay: sleeps.append(delay))
    monkeypatch.setattr(tray.time, "monotonic", lambda: next(times))

    assert tray.wait_for_status_notifier_host(timeout=0.2, interval=0.25, stable_for=0) is False
    assert sleeps == [0.25]


def test_agent_tray_apply_menu_state_updates_gtk_items():
    controller = tray.AgentTray(base_url="http://agent.local")

    class Item:
        def __init__(self):
            self.sensitive = None
        def set_sensitive(self, value):
            self.sensitive = value

    items = {name: Item() for name in ["open_tui", "close_tui", "start", "stop"]}
    controller._gtk_items = items

    controller._server_running = False
    controller._tui_running = True
    controller.apply_menu_state()
    assert items["open_tui"].sensitive is False
    assert items["close_tui"].sensitive is True
    assert items["start"].sensitive is True
    assert items["stop"].sensitive is False

    controller._server_running = True
    controller._tui_running = False
    controller.apply_menu_state()
    assert items["open_tui"].sensitive is True
    assert items["close_tui"].sensitive is False
    assert items["start"].sensitive is False
    assert items["stop"].sensitive is True

    controller._server_running = True
    controller._tui_running = True
    controller.apply_menu_state()
    assert items["open_tui"].sensitive is False
    assert items["close_tui"].sensitive is True
    assert items["start"].sensitive is False
    assert items["stop"].sensitive is True


def test_agent_tray_update_menu_applies_existing_gtk_item_state_without_rebuilding(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    calls = []
    controller.Gtk = object()

    class Icon:
        def set_menu(self, menu):
            calls.append(("set_menu", menu))

    class Item:
        def set_sensitive(self, value):
            calls.append(("sensitive", value))

    controller.icon = Icon()
    controller._gtk_items = {"start": Item()}
    controller._server_running = False
    controller._tui_running = False

    monkeypatch.setattr(controller, "gtk_menu", lambda: "new-menu")

    controller.update_menu()

    assert ("sensitive", True) in calls
    assert ("set_menu", "new-menu") not in calls


def test_agent_tray_server_actions_are_dispatched_in_background(monkeypatch):
    controller = tray.AgentTray(base_url="http://agent.local")
    calls = []

    def fake_background(name, target):
        calls.append(name)
        return "thread"

    monkeypatch.setattr(controller, "run_in_background", fake_background)

    assert controller.stop_server() == "thread"
    assert calls == ["codex-agent-tray-stop-server"]


def test_agent_tray_server_mutations_use_systemd_no_block(monkeypatch):
    service = FakeService()
    controller = tray.AgentTray(base_url="http://agent.local", service=service)
    run_background_immediately(controller, monkeypatch)
    monkeypatch.setattr(controller, "wait_for_server", lambda **kwargs: True)
    monkeypatch.setattr(controller, "refresh_state", lambda: False)
    monkeypatch.setattr(controller, "update_menu", lambda: None)

    controller.stop_server()

    assert service.calls == [("stop", "--no-block", tray.SERVER_SERVICE_NAME)]
