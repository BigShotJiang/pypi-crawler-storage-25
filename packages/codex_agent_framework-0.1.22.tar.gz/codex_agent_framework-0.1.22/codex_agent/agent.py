from .utils import text_content, ensure_runtime_dir, upload_file_to_folder, project_python_env, runtime_join, root_join
import os
from .message import DeveloperMessage, ServerToolResponseMessage, SystemMessage, ToolResultMessage, UserMessage, message_from_data
from .image import ImageMessage
from .command import CommandManager
from .config import ConfigManager
from .context import ContextManager
from .hooks import HookManager
from .mainloop import MainLoopManager
from .plugin import PluginsManager
from .provider import ProvidersManager
from .runtime import RuntimeManager
from .scheduler import AgentScheduler
from .sessions import SessionsManager
from .status import StatusManager
from .tool import ImageGenerationTool, ToolsManager, reset_current_agent, set_current_agent
from .ai import AIClient
from .voice import VoiceProcessor
from .latex import LaTeXProcessor
from .event import AssistantInterruptRequestedEvent, AssistantInterrupted, AssistantInterruptedEvent, AudioPlaybackEvent, EventBus
from threading import Event as ThreadEvent

class Agent:

    def __init__(self,session="latest",**kwargs):
        """Initializes the Agent instance with configuration, events, tools, and message history.

        Args:
            session: Session id or JSON session file to resume. Defaults to
                "latest"; pass "new" to force a fresh session.
            **kwargs: Additional keyword arguments to update the agent configuration.
        """
        ensure_runtime_dir()
        self.init_execution_environment()
        self.config_manager=ConfigManager(self)
        self.config=self.config_manager.config
        self.config_manager.load()
        self.config_manager.update(kwargs, save=False)
        self.config_manager.apply_openai_capability_defaults()
        self.events=EventBus()
        self.tools_manager=ToolsManager(self)
        self.tools=self.tools_manager.tools
        self.providers_manager=ProvidersManager(self)
        self.providers=self.providers_manager.providers
        self.command_manager=CommandManager(self)
        self.commands=self.command_manager.commands
        self.context_manager=ContextManager(self)
        self.plugins_manager=PluginsManager(self)
        self.plugins=self.plugins_manager.plugins
        self.sessions_manager=SessionsManager(self)
        self.runtime=RuntimeManager(self)
        self.scheduler=AgentScheduler(self)
        self.hooks=HookManager(self)
        self.on(AudioPlaybackEvent, self.handle_audio_playback)
        self.mainloop_manager=MainLoopManager(self)
        self._interrupt_requested=ThreadEvent()
        self.current_session_id=None
        self.session=None
        self.status_manager=StatusManager(self)
        self.context_namespace=self.create_context_namespace()
        self.init_workfolder()
        self.sessions_manager.init_folder()
        self.command_manager.init_folder()
        self.plugins_manager.init_folder()
        self.ai=AIClient(self)
        self.voice=VoiceProcessor(self)
        self.latex=LaTeXProcessor()
        self.content_processors=[self.voice]
        self.command_manager.init_builtin()
        self.plugins_manager.init_builtin()
        self.plugins_manager.init_runtime()
        self.command_manager.init_runtime()
        self.tools_manager.init_server_tools()
        self.tools_manager.apply_config_exclusions()
        self.start_new_session() if session == "new" else self.load_session(session)

    def on(self, event_type, handler=None):
        """Register an event handler.

        Can be used as ``agent.on(ResponseContentDeltaEvent, handler)`` or as
        ``@agent.on(ResponseContentDeltaEvent)``.
        """
        return self.events.on(event_type, handler)

    def emit(self, event_type, **data):
        event = self.events.emit(event_type, **data)
        mainloop_manager = getattr(self, "mainloop_manager", None)
        if mainloop_manager is not None:
            mainloop_manager.record_event(event)
        return event

    @property
    def busy(self):
        return self.mainloop_manager.busy

    @property
    def current_turn_id(self):
        return self.mainloop_manager.current_turn_id

    def start(self):
        return self.mainloop_manager.start()

    def stop(self, timeout=None):
        return self.mainloop_manager.stop(timeout=timeout)

    def submit(self, command, **payload):
        return self.mainloop_manager.submit(command, **payload)

    def start_turn(self):
        return self.mainloop_manager.start_turn()

    def resume_turn(self, turn):
        future = self.mainloop_manager.resume_turn(turn)
        return None if future is None else future.wait()

    def submit_command(self, prompt):
        return self.command_manager.submit(prompt)

    def submit_message(self, message):
        return self.mainloop_manager.submit_message(message)

    def set_turn_result(self, data):
        return self.mainloop_manager.set_turn_result(data)

    def list_wakeups(self, include_done=True):
        return self.scheduler.list(include_done=include_done)

    def schedule_wakeup(self, **kwargs):
        if self.mainloop_manager.should_queue_state_command():
            return self.submit("schedule_wakeup", **kwargs).wait().result
        return self.scheduler.schedule(**kwargs)

    def cancel_wakeup(self, job_id):
        if self.mainloop_manager.should_queue_state_command():
            return self.submit("cancel_wakeup", job_id=job_id).wait().result
        return self.scheduler.cancel(job_id)

    def delete_wakeup(self, job_id):
        if self.mainloop_manager.should_queue_state_command():
            return self.submit("delete_wakeup", job_id=job_id).wait().result
        return self.scheduler.delete(job_id)

    def interrupt(self, reason="user"):
        abort_error = None
        if not self._interrupt_requested.is_set():
            self._interrupt_requested.set()
            if getattr(self, "ai", None) is not None:
                try:
                    self.ai.abort()
                except Exception as exc:
                    abort_error = exc
            self.emit(AssistantInterruptedEvent, reason=reason)
        self.emit(AssistantInterruptRequestedEvent, reason=reason, interrupted=True, error=str(abort_error) if abort_error else "")
        return True

    def clear_interrupt(self):
        self._interrupt_requested.clear()

    def is_interrupted(self):
        return self._interrupt_requested.is_set()

    def check_interrupt(self):
        if self.is_interrupted():
            raise AssistantInterrupted()

    def create_context_namespace(self):
        return {
            "agent": self,
            "os": os,
            "runtime_join": runtime_join,
            "root_join": root_join,
            "text_content": text_content,
        }

    def init_workfolder(self):
        if not os.path.isdir(self.config.workfolder):
            os.makedirs(self.config.workfolder,exist_ok=True)

    def init_execution_environment(self):
        os.environ.update(project_python_env())

    def execution_env(self):
        return project_python_env()

    def get_sessions(self):
        return self.sessions_manager.list()

    def latest_session_id(self):
        return self.sessions_manager.latest_id()

    def load_session(self, session):
        return self.sessions_manager.load(session)

    def start_new_session(self):
        return self.sessions_manager.start_new()

    def delete_session(self, session):
        return self.sessions_manager.delete(session)

    def navigate_session(self, direction):
        return self.sessions_manager.navigate(direction)

    def save_session(self):
        return self.sessions_manager.save()

    def compact_session(self, client=None, model=None, instructions=None):
        return self.sessions_manager.compact(client=client, model=model, instructions=instructions)

    def add_message(self,msg,pending=False):
        """Queue a message for the next pending flush, except tool results."""
        if isinstance(msg, ToolResultMessage):
            return self.sessions_manager.append_message(msg)
        if self.mainloop_manager.dumping_pending:
            return self.sessions_manager.append_message(msg)
        return self.mainloop_manager.add_pending_message(msg)

    def new_message(self,pending=False,**kwargs):
        """Helper to create and add a message based on provided keyword arguments.

        Args:
            pending: If True, stores message in pending list instead of main messages.
            **kwargs: Message fields. Must include an explicit ``type``.

        Returns:
            The created message object.
        """
        msg=message_from_data(kwargs)
        return self.add_message(msg,pending=pending)

    def add_image(self,source,pending=False,**kwargs):
        if source:
            img=ImageMessage(
                content=source,
                **kwargs
            )
            if not img.is_valid():
                raise ValueError(f"Invalid or inaccessible image source: {source!r}")
            self.add_message(img,pending=pending)
            return img

    def add_tool(self,func=None,name=None,description=None,parameters=None,required=None,tool_type=None,format=None):
        return self.tools_manager.add(
            func=func,
            name=name,
            description=description,
            parameters=parameters,
            required=required,
            tool_type=tool_type,
            format=format,
        )

    def add_provider(self, func=None, name=None):
        return self.providers_manager.add(func=func, name=name)

    def add_command(self, func=None, name=None):
        return self.command_manager.add(func, name=name)

    def add_hook(self, key, func=None):
        """Register a runtime hook.

        Hooks are callable extension points keyed by name. They are runtime
        functions stored outside persisted payloads, and can be used as
        ``@agent.add_hook("audio_playback_hook")``.
        """
        if func is None:
            def decorator(f):
                return self.add_hook(key, f)
            return decorator

        if hasattr(self, "mainloop_manager") and self.mainloop_manager.should_queue_state_command():
            return self.submit("add_hook", key=key, func=func).wait().result

        return self.hooks.add(key, func)

    def has_hook(self, key):
        return self.hooks.has(key)

    def run_hook(self, key, **payload):
        agent_context = set_current_agent(self)
        try:
            return self.hooks.run(key, **payload)
        finally:
            reset_current_agent(agent_context)

    def run_hooks(self, key, *args):
        agent_context = set_current_agent(self)
        try:
            return self.hooks.run_legacy(key, *args)
        finally:
            reset_current_agent(agent_context)

    def get_messages(self,filter=None):
        return self.sessions_manager.messages(filter=filter)

    def get_status(self):
        return self.status_manager.get_status()

    def create_image(
        self,
        prompt,
        input_images=None,
        model="gpt-5.4",
        reasoning_effort="medium",
        verbosity="medium",
        output_format="png",
        size=None,
        quality=None,
        background=None,
        moderation=None,
    ):
        """Generate an image directly and return the saved image path."""
        content = [{"type": "text", "text": prompt}]
        for source in input_images or []:
            content.extend(ImageMessage(content=source).content_to_response_parts())

        system_prompt = text_content(os.path.join(os.path.dirname(__file__), "prompts", "image_generation_system_prompt.txt"))
        message = self.ai.run(
            messages=[SystemMessage(content=system_prompt), UserMessage(content=content)],
            tools=[ImageGenerationTool(
                output_format=output_format,
                size=size,
                quality=quality,
                background=background,
                moderation=moderation,
            ).to_response_tool()],
            model=model,
            reasoning_effort=reasoning_effort,
            verbosity=verbosity,
        )
        for item in message.output_items:
            if item.get("type") == "image_generation_call":
                return ServerToolResponseMessage(item=item).content
        else:
            raise RuntimeError("The image_generation tool did not return an image.")

    def get_response(self):
        """Run the model, emit response events, and store the final message.

        Returns:
            Message: The aggregated assistant message with content and/or tool calls.
        """
        if self.session and not self.session.is_sane():
            repair = self.session.repair()
            if repair.repaired:
                self.status_manager.invalidate_context_cache()
        messages = self.context_manager.get_context()
        if self.context_manager.should_auto_compact(messages):
            self.compact_session(
                model=self.config.model,
                instructions=self.config_manager.system_message().content,
            )
            messages = self.context_manager.get_context()

        message=self.ai.run(
            messages=messages,
            tools=self.tools_manager.get_response_tools(),
            prompt_cache_key=self.current_session_id,
            **self.config.extract('model','reasoning_effort','verbosity','parallel_tool_calls')
        )
        self.sessions_manager.append_message(message)
        for item in message.output_items:
            if self.tools_manager.server_tool_for_item(item):
                self.sessions_manager.append_message(ServerToolResponseMessage(item=item))
        return message

    def speak(self,text,**kwargs):
        audio=self.ai.text_to_audio(text,**kwargs)
        if audio is not None:
            self.emit(AudioPlaybackEvent, audio=audio)

    def handle_audio_playback(self, event):
        audio = event.get("audio")
        if audio is None:
            return None
        if self.has_hook("audio_playback_hook"):
            return self.run_hooks("audio_playback_hook", audio)
        from .voice import silent_play
        return silent_play(audio)

    def listen(self, source, language=None, **kwargs):
        """
        description: |
            Listen to audio input and transcribe it to text, then process it as a user message.
            Accepts either audio data (BytesIO/bytes) or a file path.
        parameters:
            source:
                description: Audio data as file_path string, BytesIO object or bytes
            language:
                description: ISO-639-1 language code (e.g., "en", "fr")
            kwargs:
                description: Additional parameters for the transcription (model, prompt, temperature, etc.)
        """

        transcribed_text = self.transcribe(source, language, **kwargs)

        # Add transcribed text as a user message
        self.add_message(UserMessage(content=transcribed_text))

    def transcribe(self, source, language=None, **kwargs):
        """
        description: |
            Transcribe audio to text.
            Accepts either audio data (BytesIO/bytes) or a file path.
        parameters:
            source:
                description: Audio data as file_path string, BytesIO object or bytes
            language:
                description: ISO-639-1 language code (e.g., "en", "fr")
            kwargs:
                description: Additional parameters for the transcription (model, prompt, temperature, etc.)
        """
        if source is None:
            raise ValueError("An audio source must be provided")

        # Transcribe audio to text
        transcribed_text = self.ai.audio_to_text(
            source=source,
            language=language,
            **kwargs
        )

        return transcribed_text

    def upload_file(self, source, name=None):
        """
        description: |
            Upload a file to the agent's workfolder and inform the agent via system message.
            Supports file paths (str), BytesIO objects, or raw bytes.
        parameters:
            source:
                description: File source - can be a file path (str), BytesIO object, or bytes
            name:
                description: Optional name for the file. Required when source is bytes without a name attribute.
                             Can include extension to override detection.
        returns:
            description: Absolute path to the uploaded file
        """
        dest_path = upload_file_to_folder(source, self.config.workfolder, name=name)
        dest_filename = os.path.basename(dest_path)

        self.add_message(DeveloperMessage(content=f"File '{dest_filename}' has been uploaded to the workfolder at: {dest_path}"))

        return dest_path

    def __call__(self, prompt=None):
        return self.mainloop_manager.call(prompt=prompt)

    def interact(self):
        """Starts the interactive Textual chat UI."""
        from .utils import set_root_path
        import os
        if os.environ.get('AGENT_ROOT_PATH') is None:
            set_root_path(file=__file__)
        from .tui import Chat
        Chat(self).run()
