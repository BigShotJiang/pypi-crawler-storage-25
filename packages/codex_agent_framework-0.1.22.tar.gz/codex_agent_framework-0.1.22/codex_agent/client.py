import json
import os
import threading
from urllib.parse import urlencode

import requests
from modict import modict

from .utils import snake_case_type


class AgentClient:
    """Small HTTP/SSE client for a codex-agent server."""

    def __init__(self, base_url="http://127.0.0.1:8765", timeout=10):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.event_read_timeout = max(2.0, min(float(timeout), 5.0))
        self.client_pid = os.getpid()
        self._event_handlers = {}
        self._event_thread = None
        self._health_thread = None
        self._event_stop = threading.Event()
        self._server_connected = False
        self._event_stream_connected = False
        self._last_event_sequence = None
        self._server_state_lock = threading.Lock()
        self.health_interval = 1.0
        self.health_failure_threshold = 3
        self._health_failures = 0

    def on(self, event_type, handler=None):
        if handler is None:
            def decorator(func):
                self.on(event_type, func)
                return func
            return decorator
        self._event_handlers.setdefault(self.event_type(event_type), []).append(handler)
        return handler

    def event_type(self, event_type):
        if isinstance(event_type, str):
            return event_type
        if isinstance(event_type, type):
            return snake_case_type(event_type)
        return str(event_type)

    def emit_local(self, event):
        event = modict(event)
        event_type = event.get("type")
        event_types = list(event.get("types") or [event_type])
        if event_type and event_type not in event_types:
            event_types.append(event_type)
        handlers = []
        seen = set()
        for current_type in event_types:
            for handler in self._event_handlers.get(current_type, ()):
                if handler in seen:
                    continue
                seen.add(handler)
                handlers.append(handler)
        for handler in self._event_handlers.get("*", ()):
            if handler in seen:
                continue
            seen.add(handler)
            handlers.append(handler)
        for handler in handlers:
            try:
                handler(event)
            except Exception as exc:
                if event_type != "client_event_error":
                    self.emit_local({"type": "client_event_error", "error": str(exc), "event": event_type})
        return event

    def start_events(self):
        if self._event_thread and self._event_thread.is_alive():
            return self
        self._event_stop.clear()
        self._event_thread = threading.Thread(target=self._event_loop, name="agent-client-events", daemon=True)
        self._health_thread = threading.Thread(target=self._health_loop, name="agent-client-health", daemon=True)
        self._event_thread.start()
        self._health_thread.start()
        return self

    def stop_events(self, timeout=0.2):
        self._event_stop.set()
        if self._event_thread:
            self._event_thread.join(timeout)
        if self._health_thread:
            self._health_thread.join(timeout)
        return self

    def _set_server_connected(self):
        with self._server_state_lock:
            if self._server_connected:
                return False
            self._server_connected = True
        self.emit_local({"type": "server_connected"})
        return True

    def _set_server_offline(self, error=""):
        with self._server_state_lock:
            if not self._server_connected:
                return False
            self._server_connected = False
        self.emit_local({"type": "server_offline", "error": str(error or "")})
        return True

    def _set_event_stream_connected(self, connected):
        with self._server_state_lock:
            self._event_stream_connected = bool(connected)

    def _event_stream_is_connected(self):
        with self._server_state_lock:
            return self._event_stream_connected

    def _health_loop(self):
        while not self._event_stop.is_set():
            try:
                response = requests.get(self.url("/health"), timeout=min(float(self.timeout), 1.0))
                response.raise_for_status()
                self._health_failures = 0
            except Exception as exc:
                self._health_failures += 1
                if self._health_failures >= self.health_failure_threshold and not self._event_stream_is_connected():
                    self._set_server_offline(str(exc))
            self._event_stop.wait(self.health_interval)

    def _event_loop(self):
        while not self._event_stop.is_set():
            try:
                with requests.get(
                    self.events_url(),
                    stream=True,
                    timeout=(self.timeout, self.event_read_timeout),
                    headers={"Accept": "text/event-stream"},
                ) as response:
                    response.raise_for_status()
                    self._set_event_stream_connected(True)
                    self._set_server_connected()
                    stream_ended = True
                    for event in self.iter_sse(response.iter_lines(chunk_size=1, decode_unicode=True)):
                        if self._event_stop.is_set():
                            stream_ended = False
                            break
                        self.remember_event_sequence(event)
                        self.emit_local(event)
                    if stream_ended and not self._event_stop.is_set():
                        self._set_event_stream_connected(False)
                        self._set_server_offline("event stream closed")
                        self._event_stop.wait(0.1)
            except Exception as exc:
                self._set_event_stream_connected(False)
                if not self._event_stop.is_set():
                    self._set_server_offline(str(exc))
                    self.emit_local(self.event_error_payload(exc))
                    self._event_stop.wait(0.1)

    def event_error_payload(self, exc):
        payload = modict(type="client_event_error", error=str(exc), source="event_stream")
        if isinstance(exc, requests.HTTPError) and exc.response is not None:
            payload.status_code = exc.response.status_code
            try:
                detail = exc.response.json().get("detail")
            except Exception:
                detail = exc.response.text
            if detail:
                payload.detail = detail
                payload.error = detail
        return payload

    def iter_sse(self, lines):
        event = None
        data_lines = []
        event_id = None

        def flush():
            if not data_lines:
                return None
            try:
                payload = json.loads("\n".join(data_lines))
            except json.JSONDecodeError as exc:
                payload = {"type": "client_event_error", "error": f"invalid SSE JSON: {exc}"}
            if event and "type" not in payload:
                payload["type"] = event
            if event_id and "id" not in payload:
                payload["id"] = event_id
            return modict(payload)

        for line in lines:
            if line is None:
                continue
            if isinstance(line, bytes):
                line = line.decode("utf-8")
            if line == "":
                payload = flush()
                if payload is not None:
                    yield payload
                event = None
                data_lines = []
                event_id = None
                continue
            if line.startswith(":"):
                continue
            field, _, value = line.partition(":")
            value = value[1:] if value.startswith(" ") else value
            if field == "event":
                event = value
            elif field == "data":
                data_lines.append(value)
            elif field == "id":
                event_id = value
        payload = flush()
        if payload is not None:
            yield payload

    def remember_event_sequence(self, event):
        sequence = event.get("sequence") if isinstance(event, dict) else None
        if sequence is None:
            return
        try:
            sequence = int(sequence)
        except (TypeError, ValueError):
            return
        if self._last_event_sequence is None or sequence > self._last_event_sequence:
            self._last_event_sequence = sequence
    def events_url(self):
        params = {"client_pid": int(self.client_pid)}
        if self._last_event_sequence is not None:
            params["after_sequence"] = int(self._last_event_sequence)
        return self.url(f"/events?{urlencode(params)}")
    def url(self, path):
        return self.base_url + path

    def request(self, method, path, **kwargs):
        kwargs.setdefault("timeout", self.timeout)
        response = requests.request(method, self.url(path), **kwargs)
        response.raise_for_status()
        if not response.content:
            return modict()
        return modict(response.json())

    def get(self, path):
        return self.request("GET", path)

    def post(self, path, payload=None):
        return self.request("POST", path, json=payload or {})

    def delete(self, path):
        return self.request("DELETE", path)

    def health(self):
        return self.get("/health")

    def context_status(self):
        return self.get("/status")

    def get_status(self):
        return self.get("/status")

    def get_config(self):
        return self.get("/config")

    def update_config(self, values=None, save=True, **kwargs):
        payload = dict(values or {})
        payload.update(kwargs)
        return self.request("PATCH", "/config", json={"values": payload, "save": save})

    def tools(self):
        return self.get("/tools")

    def sessions(self):
        return self.get("/sessions")

    def new_session(self):
        return self.post("/sessions/new")

    def load_session(self, session_id):
        return self.post(f"/sessions/{session_id}/load")

    def delete_session(self, session_id):
        return self.delete(f"/sessions/{session_id}")

    @property
    def config(self):
        return self.get_config()

    @property
    def busy(self):
        try:
            return bool(self.health().busy)
        except Exception:
            return False

    def submit_prompt(self, prompt):
        return self.post("/turns", {"prompt": prompt})

    def interrupt(self, reason="client"):
        try:
            return self.post("/interrupt", {"reason": reason})
        except Exception as exc:
            payload = modict(interrupted=False, interrupt_requested=False, error=str(exc))
            self.emit_local({
                "type": "client_event_error",
                "error": str(exc),
                "source": "interrupt",
            })
            return payload

    def list_wakeups(self, include_done=True):
        return self.get(f"/wakeups?include_done={str(bool(include_done)).lower()}")

    def schedule_wakeup(self, prompt, run_at=None, delay_seconds=None, interval_seconds=None, title=""):
        return self.post("/wakeups", {
            "prompt": prompt,
            "run_at": run_at,
            "delay_seconds": delay_seconds,
            "interval_seconds": interval_seconds,
            "title": title,
        })

    def cancel_wakeup(self, job_id):
        return self.post(f"/wakeups/{job_id}/cancel")

    def delete_wakeup(self, job_id):
        return self.delete(f"/wakeups/{job_id}")

    def tui(self):
        return self.get("/tui")

    def open_tui(self):
        return self.post("/tui/open")

    def close_tui(self):
        return self.post("/tui/close")

    def replay_events(self, before_sequence=None, session_id=None):
        path = "/events/replay"
        params = {}
        if before_sequence is not None:
            params["before_sequence"] = int(before_sequence)
        if session_id:
            params["session_id"] = str(session_id)
        if params:
            path += f"?{urlencode(params)}"
        return self.get(path)

    def restart(self, prompt=None, title="post-restart wakeup"):
        return self.post("/restart", {"prompt": prompt, "title": title})

    def stop(self, timeout=None):
        return self.stop_events(timeout=timeout or 0.2)

