from modict import modict


class HookContext(modict):
    """Mutable context passed to hook handlers.

    Hooks are intentionally generic extension points. Handlers may inspect or
    mutate ``payload`` in place, or return a mapping whose keys are merged back
    into the context. A future permission layer can build on top of the same
    primitive without changing call sites.
    """

    name = ""
    payload = modict.factory(modict)
    results = modict.factory(list)
    stopped = False
    error = None

    def stop(self, reason=None):
        self.stopped = True
        if reason is not None:
            self.reason = reason
        return self


class HookManager:
    def __init__(self, agent=None):
        self.agent = agent
        self.handlers = modict()

    def add(self, name, func=None):
        if func is None:
            def decorator(f):
                return self.add(name, f)
            return decorator
        self.handlers.setdefault(str(name), []).append(func)
        return func

    on = add

    def has(self, name):
        return bool(self.handlers.get(str(name)))

    def run(self, name, **payload):
        context = HookContext(name=str(name), payload=modict(payload), results=[])
        for handler in list(self.handlers.get(str(name), ())):
            result = handler(context)
            context.results.append(result)
            if isinstance(result, dict):
                context.update(result)
            if context.stopped:
                break
        return context

    def run_legacy(self, name, *args):
        results = []
        for handler in list(self.handlers.get(str(name), ())):
            results.append(handler(*args))
        return results

    def get(self, name, default=None):
        return self.handlers.get(str(name), default)

    def setdefault(self, name, default):
        return self.handlers.setdefault(str(name), default)

    def __contains__(self, name):
        return str(name) in self.handlers

    def __iter__(self):
        return iter(self.handlers)
