"""Built-in local interface plugin."""

from ...plugin import Plugin
from ...tool import tool
from ..content import system as system_tools


class InterfacePlugin(Plugin):
    name = "interface"
    description = "Open and close the local TUI interface."
    prefix_tools = False

    @tool(name="open_tui")
    def open_tui(self):
        return system_tools.open_tui()

    @tool(name="close_tui")
    def close_tui(self):
        return system_tools.close_tui()


InterfacePlugin.open_tui.__doc__ = system_tools.open_tui.__doc__
InterfacePlugin.close_tui.__doc__ = system_tools.close_tui.__doc__
