"""Built-in Bash execution plugin."""

import os
import subprocess

from ...plugin import Plugin
from ...tool import tool


class BashPlugin(Plugin):
    name = "bash"
    description = "Run Bash commands on the local system."
    prefix_tools = False

    @tool(name="bash", tool_type="custom")
    def bash(self, content=None):
        """
        Runs Bash commands on the local system. Pass raw shell script text,
        not JSON, quotes, or a markdown code fence.
        """
        if not content:
            return "No bash command provided."

        hook = self.agent.run_hook("shell.bash.before", content=content, cwd=os.getcwd())
        content = hook.payload.content
        cwd = hook.payload.cwd
        response = subprocess.run(
            str(content),
            shell=True,
            executable="/bin/bash",
            text=True,
            capture_output=True,
            cwd=cwd,
            env=self.agent.execution_env(),
        )
        output = ""
        if response.stdout:
            output += f"stdout:\n{response.stdout}"
        if response.stderr:
            output += f"stderr:\n{response.stderr}"
        if response.returncode:
            output += f"exit_code: {response.returncode}"
        hook = self.agent.run_hook(
            "shell.bash.after",
            content=content,
            cwd=cwd,
            returncode=response.returncode,
            stdout=response.stdout,
            stderr=response.stderr,
            output=output,
        )
        return hook.payload.output or "Command completed with no output."
