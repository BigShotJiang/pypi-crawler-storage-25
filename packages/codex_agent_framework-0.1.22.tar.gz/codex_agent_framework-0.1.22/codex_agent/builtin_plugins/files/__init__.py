"""Built-in file editing plugin."""

from ...plugin import Plugin
from ...tool import tool
from . import tools as file_tools


class FilesPlugin(Plugin):
    name = "files"
    description = "Strict local UTF-8 file read/write/edit operations."
    prefix_tools = False

    @tool(name="read")
    def read(self, reads):
        return file_tools.read(reads)

    @tool(name="write")
    def write(self, writes):
        return file_tools.write(writes)

    @tool(name="edit")
    def edit(self, edits):
        return file_tools.edit(edits)


FilesPlugin.read.__doc__ = file_tools.read.__doc__
FilesPlugin.write.__doc__ = file_tools.write.__doc__
FilesPlugin.edit.__doc__ = file_tools.edit.__doc__
