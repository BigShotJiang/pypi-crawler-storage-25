"""Built-in runtime environment context plugin."""

from datetime import datetime
import os

from ...plugin import Plugin
from ...provider import provider


class EnvironmentPlugin(Plugin):
    name = "environment"
    description = "Ephemeral runtime context such as current time and working directory."

    @provider
    def date_and_time(self):
        now = datetime.now().astimezone()
        return f"Current date and time: {now.strftime('%Y-%m-%d %H:%M:%S %Z%z')}"

    @provider
    def cwd(self):
        return f"Current working directory: {os.getcwd()}"
