from modict import modict

from .image import ImageMessage
from .message import Message, ProviderMessage, SystemMessage
from .tool import reset_current_agent, set_current_agent
from .utils import sort, token_count_payload, truncate


class ContextManager:
    def __init__(self, agent):
        self.agent = agent

    def provider_context_wrapper(self, provider_name, content):
        return f'<context_provider name="{provider_name}">\n{content}\n</context_provider>'

    def provider_message_from_output(self, provider_name, output):
        if isinstance(output, str):
            return ProviderMessage(name=provider_name, content=output)
        if not isinstance(output, Message):
            raise TypeError(
                f"Provider {provider_name!r} items must be str or Message, got {type(output).__name__}."
            )

        message = output.copy()
        if isinstance(message, ProviderMessage):
            if not message.get("name"):
                message.name = provider_name
            return message

        if isinstance(message, ImageMessage):
            description = message.get("description") or "Image provided by an ephemeral context provider."
            message.description = self.provider_context_wrapper(provider_name, description)
            return message

        content = message.get("content")
        if isinstance(content, str):
            message.content = self.provider_context_wrapper(provider_name, content)
        elif isinstance(content, list):
            wrapped_parts = []
            for part in content:
                if isinstance(part, str):
                    wrapped_parts.append(self.provider_context_wrapper(provider_name, part))
                elif isinstance(part, dict) and part.get("type") == "text":
                    part = dict(part)
                    part["text"] = self.provider_context_wrapper(provider_name, part.get("text", ""))
                    wrapped_parts.append(part)
                else:
                    wrapped_parts.append(part)
            message.content = wrapped_parts
        return message

    def get_providers_messages(self):
        provider_msgs = []
        for provider_name, provider in self.agent.providers.items():
            self.agent.run_hook("provider.call.before", provider_name=provider_name, provider=provider)
            agent_context = set_current_agent(self.agent)
            try:
                provider_output = provider()
            finally:
                reset_current_agent(agent_context)
            hook = self.agent.run_hook("provider.call.after", provider_name=provider_name, provider=provider, output=provider_output)
            provider_output = hook.payload.output
            if provider_output is None:
                continue
            outputs = provider_output if isinstance(provider_output, (list, tuple)) else [provider_output]
            for output in outputs:
                if output is None:
                    continue
                provider_msgs.append(self.provider_message_from_output(provider_name, output))
        return provider_msgs

    def get_context(self):
        self.agent.run_hook("context.build.before")
        max_input_tokens = self.agent.config.get("max_input_tokens", 8000)
        system = [self.agent.config_manager.system_message()]
        response_tools = self.agent.tools_manager.get_response_tools()
        providers_msgs = self.get_providers_messages()
        max_images = self.agent.config.get("max_images", 10)

        self.prune_orphaned_session_tool_outputs()
        session_messages = sort(
            msg for msg in self.agent.session.context_messages()
            if self.is_message_visible_in_context(msg)
        )
        images = self.select_context_images(session_messages, max_images=max_images)
        others = [msg for msg in session_messages if not isinstance(msg, ImageMessage)]
        truncated_others = self.truncate_context_messages(others, max_input_tokens=max_input_tokens)

        current_count = self.response_input_token_count(system + images + providers_msgs, response_tools=response_tools)
        history_start = len(truncated_others)
        for i, msg in enumerate(reversed(truncated_others)):
            msg_count = self.response_input_token_count([msg], response_tools=[])
            if current_count + msg_count <= self.agent.config.input_token_limit:
                current_count += msg_count
                history_start = len(truncated_others) - i - 1
            else:
                break
        history = truncated_others[max(0, history_start):]
        context = system + sort(history + images + providers_msgs)
        formatted_context = list(msg.format(context=self.agent.context_namespace) for msg in context)
        total_session_messages = len(self.agent.session.messages) if self.agent.session else 0
        sent_session_messages = len(history) + len(images)
        persistent_session_messages = sum(
            1 for msg in session_messages
            if msg.get("turns_left", -1) == -1
        )
        temporary_session_messages = sum(
            1 for msg in session_messages
            if isinstance(msg.get("turns_left", -1), int) and msg.get("turns_left", -1) > 0
        )
        token_count_source = "local_estimate"
        try:
            current_count = self.agent.ai.count_input_tokens(
                **self.response_input_token_payload(formatted_context, response_tools=response_tools)
            )
            token_count_source = "openai_input_tokens"
        except Exception:
            pass
        self.agent.status_manager.cache_context_status(modict(
            used_tokens=current_count,
            input_token_limit=self.agent.config.input_token_limit,
            percent=(current_count / self.agent.config.input_token_limit * 100) if self.agent.config.input_token_limit else 0,
            sent_session_messages=sent_session_messages,
            total_session_messages=total_session_messages,
            sent_session_message_percent=(sent_session_messages / total_session_messages * 100) if total_session_messages else 0,
            persistent_session_messages=persistent_session_messages,
            temporary_session_messages=temporary_session_messages,
            token_count_source=token_count_source,
        ))
        hook = self.agent.run_hook("context.build.after", messages=formatted_context)
        return hook.payload.messages

    def select_context_images(self, messages, max_images=10):
        if not self.agent.config.get("vision_enabled", False):
            return []
        return [msg for msg in messages if isinstance(msg, ImageMessage)][-max_images:]

    def truncate_context_messages(self, messages, max_input_tokens):
        truncated = []
        for msg in messages:
            msg_copy = msg.copy()
            if msg_copy.get("content") and isinstance(msg_copy.content, str):
                msg_copy.content = truncate(
                    msg_copy.content,
                    max_tokens=max_input_tokens,
                    model=self.agent.config.model,
                )
            truncated.append(msg_copy)
        return truncated

    def prune_orphaned_session_tool_outputs(self):
        if not self.agent.session:
            return []
        removed = self.agent.session.prune_orphaned_tool_outputs()
        if removed:
            self.agent.status_manager.invalidate_context_cache()
        return removed

    def is_message_visible_in_context(self, msg):
        return msg.get("turns_left", -1) != 0

    def response_tools_token_count(self, response_tools=None):
        response_tools = self.agent.tools_manager.get_response_tools() if response_tools is None else response_tools
        if not response_tools:
            return 0
        return token_count_payload({"tools": response_tools}, model=self.agent.config.model)

    def response_input_token_payload(self, messages, response_tools=None):
        instructions = []
        history = []
        in_instruction_prefix = True
        for msg in messages:
            if in_instruction_prefix and isinstance(msg, SystemMessage):
                instruction = msg.instruction_text()
                if instruction:
                    instructions.append(instruction)
                continue
            in_instruction_prefix = False
            item = msg.to_response_format()
            if item is None:
                continue
            if isinstance(item, list):
                for subitem in item:
                    self.agent.session.append_response_history_item(history, subitem)
            else:
                self.agent.session.append_response_history_item(history, item)

        payload = modict()
        payload.model = self.agent.config.model
        if instructions:
            payload.instructions = "\n\n".join(instructions)
        if history:
            payload.input = history
        if response_tools:
            payload.tools = response_tools
            payload.tool_choice = "auto"
        reasoning_effort = self.agent.config.get("reasoning_effort")
        if reasoning_effort:
            payload.reasoning = {"effort": reasoning_effort}
        return payload

    def local_token_count_payload(self, payload):
        payload = modict(payload).copy()
        payload.pop("model", None)
        payload.pop("reasoning", None)
        payload.pop("tool_choice", None)

        def sanitize(value):
            if isinstance(value, list):
                return [sanitize(item) for item in value]
            if isinstance(value, dict):
                item = modict(value)
                if item.get("type") == "input_image":
                    item = item.copy()
                    item["image_url"] = "<image>"
                    return item
                if item.get("type") == "compaction_summary" and item.get("encrypted_content"):
                    item = item.copy()
                    item["encrypted_content"] = "<encrypted_compaction_summary>"
                    return {key: sanitize(child) for key, child in item.items()}
                return {key: sanitize(child) for key, child in item.items()}
            return value

        return sanitize(payload)

    def response_input_token_count(self, messages, response_tools=None, authoritative=False):
        payload = self.response_input_token_payload(messages, response_tools=response_tools)
        if authoritative:
            try:
                return self.agent.ai.count_input_tokens(**payload)
            except Exception:
                pass
        media_tokens = sum(
            msg.api_token_count(model=self.agent.config.model)
            for msg in messages
            if isinstance(msg, ImageMessage)
        )
        return token_count_payload(self.local_token_count_payload(payload), model=self.agent.config.model) + media_tokens

    def should_auto_compact(self, messages):
        if not self.agent.config.get("auto_compact", True):
            return False
        return self.response_input_token_count(
            messages,
            response_tools=self.agent.tools_manager.get_response_tools(),
        ) > self.agent.config.input_token_limit * 0.9
