from modict import modict

from .image import ImageMessage
from .utils import sort, truncate


class StatusManager:
    def __init__(self, agent):
        self.agent = agent
        self.status_cache = None
        self.context_status_cache = None
        self.wham_status_loaded = False

    def invalidate_context_cache(self):
        self.context_status_cache = None

    def cache_context_status(self, status):
        self.context_status_cache = status
        return status

    def estimated_context_status(self):
        if self.context_status_cache and self.context_status_cache.get("used_tokens"):
            return self.context_status_cache
        return self.context_status()

    def context_status(self):
        """Return a lightweight estimate of context-window usage for UI display."""
        max_input_tokens = self.agent.config.get("max_input_tokens", 8000)
        input_limit = int(self.agent.config.get("input_token_limit", 0) or 0)
        system = [self.agent.config_manager.system_message()]
        response_tools = self.agent.tools_manager.get_response_tools()
        max_images = self.agent.config.get("max_images", 10)
        context_manager = self.agent.context_manager
        context_manager.prune_orphaned_session_tool_outputs()
        session_messages = sort(
            msg for msg in self.agent.session.context_messages()
            if context_manager.is_message_visible_in_context(msg)
        ) if self.agent.session else []
        images = [] if not self.agent.config.get("vision_enabled", False) else [
            msg for msg in session_messages if isinstance(msg, ImageMessage)
        ][-max_images:]
        others = [msg for msg in session_messages if not isinstance(msg, ImageMessage)]

        truncated_others = []
        for msg in others:
            msg_copy = msg.copy()
            if msg_copy.get("content") and isinstance(msg_copy.content, str):
                msg_copy.content = truncate(msg_copy.content, max_tokens=max_input_tokens, model=self.agent.config.model)
            truncated_others.append(msg_copy)

        fixed_tokens = context_manager.response_input_token_count(system + images, response_tools=response_tools)
        current_count = fixed_tokens
        history_start = len(truncated_others)
        for i, msg in enumerate(reversed(truncated_others)):
            msg_count = context_manager.response_input_token_count([msg], response_tools=[])
            if not input_limit or current_count + msg_count <= input_limit:
                current_count += msg_count
                history_start = len(truncated_others) - i - 1
            else:
                break
        visible_history_count = len(truncated_others[max(0, history_start):])
        sent_session_messages = visible_history_count + len(images)
        total_session_messages = len(self.agent.session.messages) if self.agent.session else 0
        persistent_session_messages = sum(
            1 for msg in session_messages
            if msg.get("turns_left", -1) == -1
        )
        temporary_session_messages = sum(
            1 for msg in session_messages
            if isinstance(msg.get("turns_left", -1), int) and msg.get("turns_left", -1) > 0
        )
        percent = (current_count / input_limit * 100) if input_limit else 0
        status = modict(
            used_tokens=current_count,
            input_token_limit=input_limit,
            percent=percent,
            fixed_tokens=fixed_tokens,
            tool_spec_tokens=context_manager.response_tools_token_count(response_tools),
            token_count_source="local_estimate",
            visible_history_messages=visible_history_count,
            total_history_messages=len(truncated_others),
            sent_session_messages=sent_session_messages,
            total_session_messages=total_session_messages,
            sent_session_message_percent=(sent_session_messages / total_session_messages * 100) if total_session_messages else 0,
            persistent_session_messages=persistent_session_messages,
            temporary_session_messages=temporary_session_messages,
            context_session_messages=len(session_messages),
            image_messages=len(images),
            pending_messages=len(self.agent.mainloop_manager.pending),
            auto_compact=bool(self.agent.config.get("auto_compact", True)),
            auto_compact_threshold=int(input_limit * 0.9) if input_limit else 0,
            session_id=self.agent.current_session_id,
        )
        return self.cache_context_status(status)

    def get_status(self):
        if self.status_cache is None and not self.wham_status_loaded:
            self.refresh_wham_status()
        if self.status_cache is not None:
            status = self.status_cache.copy()
            status.update(
                busy=self.agent.mainloop_manager.busy,
                current_turn_id=self.agent.mainloop_manager.current_turn_id,
                session_id=self.agent.current_session_id,
            )
            return status

        estimated = self.estimated_context_status()
        return modict(
            context_current_tokens=estimated.used_tokens,
            context_limit_tokens=estimated.input_token_limit,
            context_percent=estimated.percent,
            sent_session_messages=estimated.sent_session_messages,
            total_session_messages=estimated.total_session_messages,
            sent_session_message_percent=estimated.sent_session_message_percent,
            persistent_session_messages=estimated.get("persistent_session_messages", 0),
            temporary_session_messages=estimated.get("temporary_session_messages", 0),
            quota_5h_percent=None,
            quota_7d_percent=None,
            model=self.agent.config.get("model") or "gpt-5.4",
            busy=self.agent.mainloop_manager.busy,
            current_turn_id=self.agent.mainloop_manager.current_turn_id,
            session_id=self.agent.current_session_id,
            source=estimated.get("token_count_source", "estimated"),
        )

    def refresh_wham_status(self):
        self.wham_status_loaded = True
        try:
            wham = self.wham_status(self.agent.ai.codex_client.usage())
        except Exception:
            return None
        if self.status_cache is None:
            estimated = self.estimated_context_status()
            self.status_cache = modict(
                context_current_tokens=estimated.used_tokens,
                context_limit_tokens=estimated.input_token_limit,
                context_percent=estimated.percent,
                sent_session_messages=estimated.sent_session_messages,
                total_session_messages=estimated.total_session_messages,
                sent_session_message_percent=estimated.sent_session_message_percent,
                persistent_session_messages=estimated.get("persistent_session_messages", 0),
                temporary_session_messages=estimated.get("temporary_session_messages", 0),
                model=self.agent.config.get("model") or "gpt-5.4",
                busy=self.agent.mainloop_manager.busy,
                current_turn_id=self.agent.mainloop_manager.current_turn_id,
                session_id=self.agent.current_session_id,
                source=estimated.get("token_count_source", "estimated"),
            )
        self.status_cache.update(wham)
        return wham

    def refresh_estimated_status_cache(self):
        estimated = self.estimated_context_status()
        if self.status_cache is None:
            return estimated
        previous = self.status_cache.copy()
        previous.update(
            context_current_tokens=estimated.used_tokens,
            context_limit_tokens=estimated.input_token_limit,
            context_percent=estimated.percent,
            sent_session_messages=estimated.sent_session_messages,
            total_session_messages=estimated.total_session_messages,
            sent_session_message_percent=estimated.sent_session_message_percent,
            persistent_session_messages=estimated.get("persistent_session_messages", 0),
            temporary_session_messages=estimated.get("temporary_session_messages", 0),
            model=self.agent.config.get("model") or "gpt-5.4",
            busy=self.agent.mainloop_manager.busy,
            current_turn_id=self.agent.mainloop_manager.current_turn_id,
            session_id=self.agent.current_session_id,
            source=estimated.get("token_count_source", "estimated"),
        )
        previous.setdefault("quota_5h_percent", None)
        previous.setdefault("quota_7d_percent", None)
        self.status_cache = previous
        return self.status_cache

    def cache_api_status(self, usage=None, model=None, quota=None):
        input_tokens = int(getattr(usage, "input_tokens", 0) or 0) if usage is not None else 0
        limit = int(self.agent.config.get("input_token_limit", 0) or 0)
        wham = self.wham_status(quota)
        context_status = self.context_status_cache or self.context_status()
        self.status_cache = modict(
            context_current_tokens=input_tokens,
            context_limit_tokens=limit,
            context_percent=(input_tokens / limit * 100) if limit else 0,
            sent_session_messages=context_status.get("sent_session_messages", 0),
            total_session_messages=context_status.get("total_session_messages", 0),
            sent_session_message_percent=context_status.get("sent_session_message_percent", 0),
            persistent_session_messages=context_status.get("persistent_session_messages", 0),
            temporary_session_messages=context_status.get("temporary_session_messages", 0),
            quota_5h_percent=wham.quota_5h_percent,
            quota_7d_percent=wham.quota_7d_percent,
            model=model or self.agent.config.get("model") or "gpt-5.4",
            busy=self.agent.mainloop_manager.busy,
            current_turn_id=self.agent.mainloop_manager.current_turn_id,
            session_id=self.agent.current_session_id,
            source="last_api_call",
        )
        return self.status_cache

    def wham_status(self, quota=None):
        quota = modict(quota or {})
        rate_limit = modict(quota.get("rate_limit") or {})
        return modict(
            plan_type=quota.get("plan_type"),
            allowed=rate_limit.get("allowed"),
            limit_reached=rate_limit.get("limit_reached"),
            rate_limit_reached_type=quota.get("rate_limit_reached_type"),
            primary_window=rate_limit.get("primary_window"),
            secondary_window=rate_limit.get("secondary_window"),
            additional_rate_limits=quota.get("additional_rate_limits") or [],
            credits=quota.get("credits"),
            quota_5h_percent=self.quota_percent(quota, target_seconds=5 * 60 * 60, fallback_window="primary_window"),
            quota_7d_percent=self.quota_percent(quota, target_seconds=7 * 24 * 60 * 60, fallback_window="secondary_window"),
        )

    def quota_percent(self, quota, target_seconds, fallback_window=None):
        if not quota:
            return None
        windows = self.quota_windows(quota)
        exact = [
            window for window in windows
            if window.get("limit_window_seconds") == target_seconds and window.get("used_percent") is not None
        ]
        if exact:
            return float(exact[0].used_percent)
        if fallback_window:
            rate_limit = quota.get("rate_limit") or {}
            window = rate_limit.get(fallback_window) or {}
            if window.get("used_percent") is not None:
                return float(window.get("used_percent"))
        candidates = [
            window for window in windows
            if window.get("limit_window_seconds") and window.get("used_percent") is not None
        ]
        if not candidates:
            return None
        closest = min(candidates, key=lambda window: abs(window.limit_window_seconds - target_seconds))
        return float(closest.used_percent)

    def quota_windows(self, quota):
        windows = []

        def visit(value):
            if isinstance(value, dict):
                if "used_percent" in value:
                    windows.append(modict(value))
                for child in value.values():
                    visit(child)
            elif isinstance(value, list):
                for child in value:
                    visit(child)

        visit(quota)
        return windows
