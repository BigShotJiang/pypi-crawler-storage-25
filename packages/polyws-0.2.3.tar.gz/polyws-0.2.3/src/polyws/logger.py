"""Logging configuration for polyws."""

import logging

logger = logging.getLogger("polyws")
