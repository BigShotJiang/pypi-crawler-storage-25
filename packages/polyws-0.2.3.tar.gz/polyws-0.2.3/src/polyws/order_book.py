"""Order book cache for Polymarket assets."""

from __future__ import annotations

import bisect
from dataclasses import dataclass

from polyws.types import BookEvent, PriceChangeEvent, PriceLevel


@dataclass(slots=True)
class BookEntry:
    bids: list[PriceLevel]  # Sorted ascending by price
    asks: list[PriceLevel]  # Sorted descending by price
    price: str | None = None
    midpoint: str | None = None
    spread: str | None = None


def _sort_ascending(levels: list[PriceLevel]) -> None:
    try:
        levels.sort(key=lambda p: float(p.price))
    except ValueError:
        pass  # Non-numeric prices left unsorted; spread/midpoint will raise later


def _sort_descending(levels: list[PriceLevel]) -> None:
    try:
        levels.sort(key=lambda p: float(p.price), reverse=True)
    except ValueError:
        pass  # Non-numeric prices left unsorted; spread/midpoint will raise later


class OrderBookCache:
    def __init__(self) -> None:
        self._cache: dict[str, BookEntry] = {}

    def replace_book(self, event: BookEvent) -> None:
        """Full book replacement. Preserves previous price/midpoint/spread."""
        prev = self._cache.get(event.asset_id)
        entry = BookEntry(
            bids=[PriceLevel(p.price, p.size) for p in event.bids],
            asks=[PriceLevel(p.price, p.size) for p in event.asks],
            price=prev.price if prev else None,
            midpoint=prev.midpoint if prev else None,
            spread=prev.spread if prev else None,
        )
        _sort_ascending(entry.bids)
        _sort_descending(entry.asks)
        self._cache[event.asset_id] = entry

    def upsert_price_change(self, event: PriceChangeEvent) -> None:
        """Incremental update from a price_change event.

        Raises ValueError if book not cached for any asset in the event.
        """
        for pc in event.price_changes:
            book = self._cache.get(pc.asset_id)
            if book is None:
                raise ValueError(f"Book not cached for asset {pc.asset_id}")

            size_f = float(pc.size)

            if pc.side == "BUY":
                idx = next(
                    (i for i, b in enumerate(book.bids) if b.price == pc.price),
                    None,
                )
                if idx is not None:
                    if size_f == 0 or pc.size == "0":
                        book.bids.pop(idx)
                    else:
                        book.bids[idx].size = pc.size
                elif size_f > 0:
                    bisect.insort(
                        book.bids,
                        PriceLevel(pc.price, pc.size),
                        key=lambda p: float(p.price),
                    )
            else:  # SELL
                idx = next(
                    (i for i, a in enumerate(book.asks) if a.price == pc.price),
                    None,
                )
                if idx is not None:
                    if size_f == 0 or pc.size == "0":
                        book.asks.pop(idx)
                    else:
                        book.asks[idx].size = pc.size
                elif size_f > 0:
                    # Descending: negate price for bisect (which inserts ascending)
                    bisect.insort(
                        book.asks,
                        PriceLevel(pc.price, pc.size),
                        key=lambda p: -float(p.price),
                    )

    def spread_over(self, asset_id: str, cents: float = 0.1) -> bool:
        """True if bid-ask spread strictly > cents. Updates book.spread."""
        book = self._cache.get(asset_id)
        if book is None:
            raise ValueError(f"Book not cached for {asset_id}")
        if not book.asks:
            raise ValueError(f"No asks in book for {asset_id}")
        if not book.bids:
            raise ValueError(f"No bids in book for {asset_id}")

        # Bids ascending -> highest bid is last
        # Asks descending -> lowest ask is last
        try:
            highest_bid = float(book.bids[-1].price)
            lowest_ask = float(book.asks[-1].price)
        except ValueError:
            raise ValueError(
                f"Non-numeric price: lowestAsk '{book.asks[-1].price}' "
                f"highestBid '{book.bids[-1].price}'"
            )
        spread = lowest_ask - highest_bid

        if spread != spread:  # NaN check
            raise ValueError(
                f"Spread is NaN: lowestAsk '{book.asks[-1].price}' "
                f"highestBid '{book.bids[-1].price}'"
            )

        book.spread = str(round(spread, 3)).rstrip("0").rstrip(".")
        # Ensure we don't return empty string for 0
        if book.spread == "":
            book.spread = "0"

        return spread > cents

    def midpoint(self, asset_id: str) -> str:
        """Midpoint between best bid and best ask, rounded to 3dp."""
        book = self._cache.get(asset_id)
        if book is None:
            raise ValueError(f"Book not cached for {asset_id}")
        if not book.asks:
            raise ValueError(f"No asks in book for {asset_id}")
        if not book.bids:
            raise ValueError(f"No bids in book for {asset_id}")

        try:
            highest_bid = float(book.bids[-1].price)
            lowest_ask = float(book.asks[-1].price)
        except ValueError:
            raise ValueError(
                f"Non-numeric price: lowestAsk '{book.asks[-1].price}' "
                f"highestBid '{book.bids[-1].price}'"
            )
        mid = (highest_bid + lowest_ask) / 2

        if mid != mid:  # NaN check
            raise ValueError(
                f"Midpoint is NaN: lowestAsk '{book.asks[-1].price}' "
                f"highestBid '{book.bids[-1].price}'"
            )

        result = str(round(mid, 3)).rstrip("0").rstrip(".")
        if result == "":
            result = "0"
        book.midpoint = result
        return result

    def get_book_entry(self, asset_id: str) -> BookEntry | None:
        return self._cache.get(asset_id)

    def clear(self, asset_id: str | None = None) -> None:
        if asset_id is not None:
            self._cache.pop(asset_id, None)
        else:
            self._cache.clear()
