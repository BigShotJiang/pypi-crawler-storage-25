"""WebSocket Subscription Manager for Polymarket CLOB."""

from __future__ import annotations

import asyncio
import random
import socket
from dataclasses import dataclass
from uuid import uuid4

import os

import orjson
import websockets

from polyws.logger import logger
from polyws.order_book import BookEntry, OrderBookCache
from polyws.types import (
    BookEvent,
    ConnectionStatus,
    LastTradePriceEvent,
    PolymarketPriceUpdateEvent,
    PolymarketWSEvent,
    PriceChangeEvent,
    TickSizeChangeEvent,
    WebSocketHandlers,
    Book,
    parse_event,
)

CLOB_WSS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"


@dataclass(slots=True)
class ManagerStatistics:
    open_websockets: int
    asset_ids: int
    pending_subscribe: int
    pending_unsubscribe: int


class WSSubscriptionManager:
    """Manages a single WebSocket connection to Polymarket CLOB.

    Each instance is independent — no shared state between managers.
    """

    def __init__(
        self,
        handlers: WebSocketHandlers,
        *,
        reconnect_interval_s: float = 5.0,
    ) -> None:
        self._manager_id = uuid4().hex
        self._handlers = handlers
        self._book_cache = OrderBookCache()
        self._reconnect_interval_s = reconnect_interval_s

        # Asset tracking
        self._subscribed: set[str] = set()
        self._pending_subscribe: set[str] = set()
        self._pending_unsubscribe: set[str] = set()

        # Connection
        self._ws: websockets.WebSocketClientProtocol | None = None
        self._status = ConnectionStatus.DISCONNECTED
        self._connecting = False

        # Background tasks
        self._receive_task: asyncio.Task | None = None
        self._flush_task: asyncio.Task | None = None
        self._reconnect_task: asyncio.Task | None = None
        self._ping_task: asyncio.Task | None = None

        # Event-driven flush
        self._flush_event = asyncio.Event()

    # ── Public API ──────────────────────────────────────────

    async def add_subscriptions(self, asset_ids: list[str]) -> None:
        """Queue assets for subscription. Connects if needed."""
        for aid in asset_ids:
            self._pending_unsubscribe.discard(aid)
            if aid not in self._subscribed:
                self._pending_subscribe.add(aid)

        self._flush_event.set()

        if self._status == ConnectionStatus.DISCONNECTED and not self._connecting:
            await self._connect()

    async def remove_subscriptions(self, asset_ids: list[str]) -> None:
        """Queue assets for unsubscription."""
        for aid in asset_ids:
            # If only pending, just cancel the pending subscription
            if aid in self._pending_subscribe:
                self._pending_subscribe.discard(aid)
                continue
            # If already subscribed, queue for unsubscription
            if aid in self._subscribed:
                self._pending_unsubscribe.add(aid)

        self._flush_event.set()

    def get_asset_ids(self) -> list[str]:
        """All monitored assets (subscribed + pending - pending_unsub)."""
        all_ids = self._subscribed | self._pending_subscribe
        return list(all_ids - self._pending_unsubscribe)

    def get_statistics(self) -> ManagerStatistics:
        return ManagerStatistics(
            open_websockets=1 if self._ws and self._status == ConnectionStatus.CONNECTED else 0,
            asset_ids=len(self.get_asset_ids()),
            pending_subscribe=len(self._pending_subscribe),
            pending_unsubscribe=len(self._pending_unsubscribe),
        )

    async def clear_state(self) -> None:
        """Full teardown. Manager is reusable after this."""
        for task in (self._receive_task, self._flush_task, self._reconnect_task, self._ping_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        self._receive_task = None
        self._flush_task = None
        self._reconnect_task = None
        self._ping_task = None

        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

        self._subscribed.clear()
        self._pending_subscribe.clear()
        self._pending_unsubscribe.clear()
        self._status = ConnectionStatus.DISCONNECTED
        self._connecting = False
        self._book_cache.clear()
        self._flush_event.clear()

    # ── Connection ──────────────────────────────────────────

    async def _connect(self) -> None:
        if self._connecting:
            return
        if self._status == ConnectionStatus.CONNECTED:
            return
        if not self._pending_subscribe and not self._subscribed:
            return

        self._connecting = True
        self._status = ConnectionStatus.CONNECTING

        try:
            logger.info("Connecting to CLOB WebSocket", extra={"manager_id": self._manager_id})
            # Temporarily clear proxy env vars — websockets tries to use HTTP CONNECT
            # through the proxy which often doesn't support WS upgrades properly.
            # The Polymarket WS endpoint is a direct connection.
            saved_proxy = {}
            for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
                if key in os.environ:
                    saved_proxy[key] = os.environ.pop(key)
            try:
                self._ws = await asyncio.wait_for(
                    websockets.connect(CLOB_WSS_URL),
                    timeout=30.0,
                )
            except asyncio.TimeoutError:
                raise ConnectionError("WebSocket connection timeout after 30s")
            finally:
                os.environ.update(saved_proxy)

            # Enable OS-level TCP keepalive on the underlying socket.
            # The kernel sends probe packets independently of the WS protocol —
            # if the remote end stops responding, the OS closes the connection
            # which surfaces as ConnectionClosedError in _receive_loop.
            # This catches dead TCP connections faster and at a lower layer than
            # application-level pings alone.
            try:
                raw_sock = self._ws.transport.get_extra_info("socket")
                if raw_sock is not None:
                    raw_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                    # Linux: first probe after 10s idle, then every 5s, drop after 3 misses
                    # (~25s total to detect a dead connection)
                    if hasattr(socket, "TCP_KEEPIDLE"):
                        raw_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 10)
                    if hasattr(socket, "TCP_KEEPINTVL"):
                        raw_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 5)
                    if hasattr(socket, "TCP_KEEPCNT"):
                        raw_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)
            except Exception as exc:
                logger.debug("Could not set TCP keepalive: %s", exc)

            # Send initial handshake
            handshake = orjson.dumps({"assets_ids": [], "type": "market"})
            await self._ws.send(handshake)

            self._status = ConnectionStatus.CONNECTED
            self._connecting = False

            # Notify open handler
            await self._safe_call(
                self._handlers.on_ws_open,
                self._manager_id,
                list(self._pending_subscribe),
            )

            # Start background tasks
            self._receive_task = asyncio.create_task(self._receive_loop())
            self._flush_task = asyncio.create_task(self._flush_loop())
            self._reconnect_task = asyncio.create_task(self._reconnect_loop())
            self._ping_task = asyncio.create_task(self._ping_loop())

            # Trigger immediate flush
            self._flush_event.set()

        except Exception as exc:
            self._status = ConnectionStatus.DISCONNECTED
            self._connecting = False
            await self._safe_call(self._handlers.on_error, exc)

    # ── Background Loops ────────────────────────────────────

    async def _receive_loop(self) -> None:
        """Read messages from WS, parse, route to handlers."""
        try:
            async for raw_msg in self._ws:
                try:
                    msg_str = raw_msg if isinstance(raw_msg, str) else raw_msg.decode()
                    if msg_str.strip().upper() == "PONG":
                        continue

                    raw_data = orjson.loads(msg_str)
                    items = raw_data if isinstance(raw_data, list) else [raw_data]

                    book_events: list[BookEvent] = []
                    price_change_events: list[PriceChangeEvent] = []
                    last_trade_events: list[LastTradePriceEvent] = []
                    tick_events: list[TickSizeChangeEvent] = []

                    for item in items:
                        if not item:
                            continue
                        try:
                            event = parse_event(item)
                        except (ValueError, KeyError) as exc:
                            await self._safe_call(self._handlers.on_error, exc)
                            continue

                        # Filter: only subscribed assets
                        if isinstance(event, PriceChangeEvent):
                            relevant = [
                                pc for pc in event.price_changes
                                if pc.asset_id in self._subscribed
                            ]
                            if not relevant:
                                continue
                            event = PriceChangeEvent(
                                event_type=event.event_type,
                                market=event.market,
                                timestamp=event.timestamp,
                                price_changes=relevant,
                            )
                            price_change_events.append(event)
                        elif not hasattr(event, "asset_id") or not event.asset_id or event.asset_id not in self._subscribed:
                            continue
                        elif isinstance(event, BookEvent):
                            book_events.append(event)
                        elif isinstance(event, LastTradePriceEvent):
                            last_trade_events.append(event)
                        elif isinstance(event, TickSizeChangeEvent):
                            tick_events.append(event)

                    # Handle each event type
                    await self._handle_book_events(book_events)
                    await self._handle_tick_events(tick_events)
                    await self._handle_price_change_events(price_change_events)
                    await self._handle_last_trade_events(last_trade_events)

                except Exception as exc:
                    logger.warning(
                        "Error handling message",
                        extra={"manager_id": self._manager_id, "error": str(exc)},
                    )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            # WS disconnected
            await self._handle_disconnect(close_code=1006, reason=str(exc))

    async def _flush_loop(self) -> None:
        """Wait for flush event, send pending sub/unsub messages."""
        try:
            while True:
                await self._flush_event.wait()
                self._flush_event.clear()

                if not self._ws or self._status != ConnectionStatus.CONNECTED:
                    continue

                # Unsubscribe first
                if self._pending_unsubscribe:
                    to_unsub = list(self._pending_unsubscribe)
                    msg = orjson.dumps({"operation": "unsubscribe", "assets_ids": to_unsub})
                    try:
                        await self._ws.send(msg)
                        for aid in to_unsub:
                            self._subscribed.discard(aid)
                            self._book_cache.clear(aid)
                        self._pending_unsubscribe.clear()
                        logger.info(
                            f"Unsubscribed from {len(to_unsub)} asset(s)",
                            extra={"manager_id": self._manager_id},
                        )
                    except Exception as exc:
                        logger.warning(f"Failed to send unsubscribe: {exc}")

                # Subscribe
                if self._pending_subscribe:
                    to_sub = list(self._pending_subscribe)
                    msg = orjson.dumps({"operation": "subscribe", "assets_ids": to_sub})
                    try:
                        await self._ws.send(msg)
                        self._subscribed.update(to_sub)
                        self._pending_subscribe.clear()
                        logger.info(
                            f"Subscribed to {len(to_sub)} asset(s)",
                            extra={"manager_id": self._manager_id},
                        )
                    except Exception as exc:
                        logger.warning(f"Failed to send subscribe: {exc}")

                # Close WS if nothing left
                if not self._subscribed and not self._pending_subscribe and not self._pending_unsubscribe:
                    if self._ws:
                        try:
                            await self._ws.close()
                        except Exception:
                            pass
                    self._status = ConnectionStatus.DISCONNECTED

        except asyncio.CancelledError:
            raise

    async def _reconnect_loop(self) -> None:
        """Watch for disconnects, reconnect when needed."""
        try:
            while True:
                await asyncio.sleep(self._reconnect_interval_s)
                if (
                    self._pending_subscribe
                    and self._status != ConnectionStatus.CONNECTED
                    and not self._connecting
                ):
                    logger.info(
                        "Reconnecting",
                        extra={
                            "manager_id": self._manager_id,
                            "pending": len(self._pending_subscribe),
                        },
                    )
                    self._book_cache.clear()
                    await self._connect()
        except asyncio.CancelledError:
            raise

    async def _ping_loop(self) -> None:
        """Periodic ping with jitter. Failed or timed-out pings trigger a reconnect.

        The 10s pong timeout catches dead TCP connections that haven't sent a
        close frame (e.g. network blip, NAT expiry). Without this, the manager
        would stay in CONNECTED state indefinitely while receiving no data.

        Note: this does NOT catch the case where the server is alive and responding
        to pings but has stopped sending market data events — that scenario requires
        an application-level stale-data watchdog.
        """
        try:
            while True:
                await asyncio.sleep(20 + random.uniform(0, 5))
                if self._ws and self._status == ConnectionStatus.CONNECTED:
                    try:
                        pong_waiter = await self._ws.ping()
                        await asyncio.wait_for(pong_waiter, timeout=10.0)
                    except Exception as exc:
                        logger.warning(
                            "Ping failed — triggering reconnect",
                            extra={"manager_id": self._manager_id, "error": str(exc)},
                        )
                        await self._handle_disconnect(close_code=1006, reason=f"ping failed: {exc}")
        except asyncio.CancelledError:
            raise

    # ── Event Handlers ──────────────────────────────────────

    async def _handle_book_events(self, events: list[BookEvent]) -> None:
        if not events:
            return
        for event in events:
            self._book_cache.replace_book(event)
        await self._safe_call(self._handlers.on_book, events)

    async def _handle_tick_events(self, events: list[TickSizeChangeEvent]) -> None:
        if not events:
            return
        await self._safe_call(self._handlers.on_tick_size_change, events)

    async def _handle_price_change_events(self, events: list[PriceChangeEvent]) -> None:
        if not events:
            return
        await self._safe_call(self._handlers.on_price_change, events)

        for event in events:
            try:
                self._book_cache.upsert_price_change(event)
            except Exception as exc:
                logger.debug(f"Skipping derived price calc: {exc}")
                continue

            for pc in event.price_changes:
                try:
                    spread_over = self._book_cache.spread_over(pc.asset_id, 0.1)
                except Exception:
                    continue

                if not spread_over:
                    try:
                        new_price = self._book_cache.midpoint(pc.asset_id)
                    except Exception:
                        continue

                    entry = self._book_cache.get_book_entry(pc.asset_id)
                    if not entry or new_price == entry.price:
                        continue

                    entry.price = new_price
                    update = PolymarketPriceUpdateEvent(
                        event_type="price_update",
                        asset_id=pc.asset_id,
                        timestamp=event.timestamp,
                        triggering_event=event,
                        book=Book(bids=list(entry.bids), asks=list(entry.asks)),
                        price=new_price,
                        midpoint=entry.midpoint or "",
                        spread=entry.spread or "",
                    )
                    await self._safe_call(self._handlers.on_polymarket_price_update, [update])

    async def _handle_last_trade_events(self, events: list[LastTradePriceEvent]) -> None:
        if not events:
            return
        await self._safe_call(self._handlers.on_last_trade_price, events)

        for event in events:
            try:
                spread_over = self._book_cache.spread_over(event.asset_id, 0.1)
            except Exception:
                continue

            if spread_over:
                new_price = str(float(event.price))
                entry = self._book_cache.get_book_entry(event.asset_id)
                if not entry or new_price == entry.price:
                    continue

                entry.price = new_price
                update = PolymarketPriceUpdateEvent(
                    event_type="price_update",
                    asset_id=event.asset_id,
                    timestamp=event.timestamp,
                    triggering_event=event,
                    book=Book(bids=list(entry.bids), asks=list(entry.asks)),
                    price=new_price,
                    midpoint=entry.midpoint or "",
                    spread=entry.spread or "",
                )
                await self._safe_call(self._handlers.on_polymarket_price_update, [update])

    # ── Helpers ─────────────────────────────────────────────

    async def _handle_disconnect(self, close_code: int = 1006, reason: str = "") -> None:
        """Handle WS disconnect: move subscribed to pending, clear cache."""
        for aid in self._subscribed:
            if aid not in self._pending_unsubscribe:
                self._pending_subscribe.add(aid)
        self._subscribed.clear()
        self._pending_unsubscribe.clear()
        self._book_cache.clear()
        self._status = ConnectionStatus.DISCONNECTED
        self._connecting = False
        self._ws = None

        await self._safe_call(self._handlers.on_ws_close, self._manager_id, close_code, reason)

    async def _safe_call(self, handler, *args) -> None:
        """Call a user handler, catching any exceptions."""
        if handler is None:
            return
        try:
            await handler(*args)
        except Exception as exc:
            logger.warning(
                "Error in user handler",
                extra={"manager_id": self._manager_id, "error": str(exc)},
            )
