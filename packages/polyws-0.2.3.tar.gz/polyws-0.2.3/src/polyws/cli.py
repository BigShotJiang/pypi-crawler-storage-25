"""polyws CLI — stream Polymarket data from your terminal."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

import orjson

from polyws.gamma import extract_asset_ids, fetch_markets
from polyws.manager import WSSubscriptionManager
from polyws.types import (
    BookEvent,
    LastTradePriceEvent,
    PolymarketPriceUpdateEvent,
    PriceChangeEvent,
    WebSocketHandlers,
)

IS_TTY: bool = False


# ── Output helpers ───────────────────────────────────────────


def _json_line(data: dict) -> None:
    """Write a JSON line to stdout and flush."""
    sys.stdout.buffer.write(orjson.dumps(data) + b"\n")
    sys.stdout.buffer.flush()


def _pretty(text: str) -> None:
    """Write a pretty line to stdout."""
    sys.stdout.write(text + "\n")
    sys.stdout.flush()


def _format_volume(vol: float) -> str:
    """Format volume as human-readable string."""
    if vol >= 1_000_000:
        return f"${vol / 1_000_000:.1f}M"
    if vol >= 1_000:
        return f"${vol / 1_000:.0f}K"
    return f"${vol:.0f}"


# ── Markets command ──────────────────────────────────────────


def _cmd_markets(args: argparse.Namespace) -> None:
    """Fetch and display markets from Gamma API."""
    markets = fetch_markets(
        limit=args.limit,
        sort=args.sort,
        search=args.search,
    )

    for m in markets:
        question = m.get("question", "Unknown")
        volume = float(m.get("volumeNum", 0) or 0)
        # outcomePrices is a JSON-encoded list like '["0.65","0.35"]'
        try:
            prices = json.loads(m.get("outcomePrices", "[]"))
            price = float(prices[0]) if prices else 0.0
        except (json.JSONDecodeError, IndexError, ValueError):
            price = 0.0

        # Extract first asset_id
        try:
            token_ids = json.loads(m.get("clobTokenIds", "[]"))
            asset_id = token_ids[0] if token_ids else ""
        except (json.JSONDecodeError, IndexError):
            asset_id = ""

        slug = m.get("slug", "")

        if IS_TTY:
            trunc_q = question[:50] + ("..." if len(question) > 50 else "")
            trunc_id = asset_id[:8] + "..." if len(asset_id) > 8 else asset_id
            _pretty(
                f"  {price * 100:5.1f}%  {_format_volume(volume):>7s}  {trunc_q:<54s} [{trunc_id}]"
            )
        else:
            _json_line({
                "asset_id": asset_id,
                "question": question,
                "volume": volume,
                "price": f"{price:.4f}",
                "market_slug": slug,
            })


# ── Stream command ───────────────────────────────────────────


async def _cmd_stream(args: argparse.Namespace) -> None:
    """Stream real-time events from Polymarket CLOB WebSocket."""
    # Resolve asset IDs
    asset_map: dict[str, str] = {}  # asset_id -> question

    if args.asset_id:
        for aid in args.asset_id:
            asset_map[aid] = aid[:12] + "..."
    elif args.search:
        markets = fetch_markets(limit=50, search=args.search)
        asset_map = extract_asset_ids(markets)
        if not asset_map:
            print("No markets found for search query.", file=sys.stderr)
            return
    else:
        n = args.markets or 10
        markets = fetch_markets(limit=n)
        asset_map = extract_asset_ids(markets)

    if not asset_map:
        print("No asset IDs to stream.", file=sys.stderr)
        return

    if IS_TTY:
        _pretty(f"  Streaming {len(asset_map)} market(s)... (Ctrl+C to stop)\n")

    # Build handlers
    async def on_book(events: list[BookEvent]) -> None:
        for ev in events:
            label = asset_map.get(ev.asset_id, ev.asset_id[:12])
            if IS_TTY:
                _pretty(f"  [book] {label}: {len(ev.bids)} bids, {len(ev.asks)} asks")
            else:
                _json_line({
                    "event": "book",
                    "asset_id": ev.asset_id,
                    "bids": len(ev.bids),
                    "asks": len(ev.asks),
                    "timestamp": ev.timestamp,
                })

    async def on_price_update(events: list[PolymarketPriceUpdateEvent]) -> None:
        for ev in events:
            label = asset_map.get(ev.asset_id, ev.asset_id[:12])
            if IS_TTY:
                pct = float(ev.price) * 100
                _pretty(f"  [price] {label}: {pct:.2f}%")
            else:
                _json_line({
                    "event": "price_update",
                    "asset_id": ev.asset_id,
                    "price": ev.price,
                    "midpoint": ev.midpoint,
                    "spread": ev.spread,
                })

    async def on_price_change(events: list[PriceChangeEvent]) -> None:
        for ev in events:
            for pc in ev.price_changes:
                label = asset_map.get(pc.asset_id, pc.asset_id[:12])
                if IS_TTY:
                    _pretty(
                        f"  [change] {label}: {pc.side} {pc.price} x{pc.size}"
                    )
                else:
                    _json_line({
                        "event": "price_change",
                        "asset_id": pc.asset_id,
                        "side": pc.side,
                        "price": pc.price,
                        "size": pc.size,
                    })

    async def on_last_trade(events: list[LastTradePriceEvent]) -> None:
        for ev in events:
            label = asset_map.get(ev.asset_id, ev.asset_id[:12])
            if IS_TTY:
                _pretty(
                    f"  [trade] {label}: {ev.side} {ev.price} x{ev.size}"
                )
            else:
                _json_line({
                    "event": "last_trade",
                    "asset_id": ev.asset_id,
                    "side": ev.side,
                    "price": ev.price,
                    "size": ev.size,
                })

    async def on_error(exc: Exception) -> None:
        print(f"  [error] {exc}", file=sys.stderr)

    handlers = WebSocketHandlers(
        on_book=on_book,
        on_price_change=on_price_change,
        on_last_trade_price=on_last_trade,
        on_polymarket_price_update=on_price_update,
        on_error=on_error,
    )

    mgr = WSSubscriptionManager(handlers)
    try:
        await mgr.add_subscriptions(list(asset_map.keys()))
        # Keep running until interrupted
        while True:
            await asyncio.sleep(1)
    finally:
        await mgr.clear_state()


# ── Entry point ──────────────────────────────────────────────


def main() -> None:
    """CLI entry point. Parses args, dispatches to command handlers."""
    global IS_TTY
    IS_TTY = sys.stdout.isatty()

    parser = argparse.ArgumentParser(
        prog="polyws",
        description="Polymarket WebSocket streaming CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # markets subcommand
    markets_parser = subparsers.add_parser(
        "markets", help="List active Polymarket markets"
    )
    markets_parser.add_argument("--search", type=str, help="Search markets by text")
    markets_parser.add_argument("--limit", type=int, default=20, help="Max results")
    markets_parser.add_argument(
        "--sort",
        choices=["volume", "liquidity", "newest"],
        default="volume",
        help="Sort order",
    )

    # stream subcommand
    stream_parser = subparsers.add_parser(
        "stream", help="Stream real-time market data"
    )
    stream_parser.add_argument("--asset-id", nargs="+", help="Asset ID(s) to stream")
    stream_parser.add_argument("--markets", type=int, help="Top N markets by volume")
    stream_parser.add_argument("--search", type=str, help="Search markets to stream")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Clear proxy env vars before WS connections
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        os.environ.pop(key, None)

    try:
        if args.command == "markets":
            _cmd_markets(args)
        elif args.command == "stream":
            asyncio.run(_cmd_stream(args))
    except KeyboardInterrupt:
        if IS_TTY:
            print("\n  Stopped.", file=sys.stderr)
        sys.exit(0)


if __name__ == "__main__":
    main()
