"""Polymarket WebSocket types — dataclasses, enums, and event parsing."""

from __future__ import annotations

import enum
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Literal


@dataclass(slots=True)
class PriceLevel:
    price: str
    size: str


@dataclass(slots=True)
class MarketSubscriptionMessage:
    assets_ids: list[str]
    type: Literal["market"] = "market"
    custom_feature_enabled: bool | None = None


@dataclass(slots=True)
class SubscribeMessage:
    assets_ids: list[str]
    operation: Literal["subscribe"] = "subscribe"
    custom_feature_enabled: bool | None = None


@dataclass(slots=True)
class UnsubscribeMessage:
    assets_ids: list[str]
    operation: Literal["unsubscribe"] = "unsubscribe"
    custom_feature_enabled: bool | None = None


@dataclass(slots=True)
class PriceChangeItem:
    asset_id: str
    price: str
    size: str
    side: Literal["BUY", "SELL"]
    hash: str
    best_bid: str
    best_ask: str


@dataclass(slots=True)
class BookEvent:
    event_type: Literal["book"]
    market: str
    asset_id: str
    timestamp: str
    hash: str
    bids: list[PriceLevel]
    asks: list[PriceLevel]


@dataclass(slots=True)
class PriceChangeEvent:
    event_type: Literal["price_change"]
    market: str
    timestamp: str
    price_changes: list[PriceChangeItem]


@dataclass(slots=True)
class LastTradePriceEvent:
    event_type: Literal["last_trade_price"]
    asset_id: str
    market: str
    price: str
    side: Literal["BUY", "SELL"]
    size: str
    timestamp: str
    fee_rate_bps: str
    transaction_hash: str


@dataclass(slots=True)
class TickSizeChangeEvent:
    event_type: Literal["tick_size_change"]
    asset_id: str
    market: str
    old_tick_size: str
    new_tick_size: str
    timestamp: str


PolymarketWSEvent = BookEvent | PriceChangeEvent | LastTradePriceEvent | TickSizeChangeEvent


@dataclass(slots=True)
class Book:
    bids: list[PriceLevel]
    asks: list[PriceLevel]


@dataclass(slots=True)
class PolymarketPriceUpdateEvent:
    """Derived event — not from WS directly."""
    event_type: Literal["price_update"]
    asset_id: str
    timestamp: str
    triggering_event: PriceChangeEvent | LastTradePriceEvent
    book: Book
    price: str
    midpoint: str
    spread: str


class ConnectionStatus(str, enum.Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"


@dataclass(slots=True)
class WebSocketHandlers:
    on_book: Callable[[list[BookEvent]], Awaitable[None]] | None = None
    on_price_change: Callable[[list[PriceChangeEvent]], Awaitable[None]] | None = None
    on_last_trade_price: Callable[[list[LastTradePriceEvent]], Awaitable[None]] | None = None
    on_tick_size_change: Callable[[list[TickSizeChangeEvent]], Awaitable[None]] | None = None
    on_polymarket_price_update: Callable[[list[PolymarketPriceUpdateEvent]], Awaitable[None]] | None = None
    on_error: Callable[[Exception], Awaitable[None]] | None = None
    on_ws_close: Callable[[str, int, str], Awaitable[None]] | None = None
    on_ws_open: Callable[[str, list[str]], Awaitable[None]] | None = None


def parse_event(raw: dict) -> PolymarketWSEvent:
    """Parse a raw dict from the WS into a typed event."""
    event_type = raw.get("event_type")
    match event_type:
        case "book":
            return BookEvent(
                event_type="book",
                market=raw["market"],
                asset_id=raw["asset_id"],
                timestamp=raw["timestamp"],
                hash=raw["hash"],
                bids=[PriceLevel(price=p["price"], size=p["size"]) for p in raw["bids"]],
                asks=[PriceLevel(price=p["price"], size=p["size"]) for p in raw["asks"]],
            )
        case "price_change":
            return PriceChangeEvent(
                event_type="price_change",
                market=raw["market"],
                timestamp=raw["timestamp"],
                price_changes=[
                    PriceChangeItem(
                        asset_id=pc["asset_id"],
                        price=pc["price"],
                        size=pc["size"],
                        side=pc["side"],
                        hash=pc["hash"],
                        best_bid=pc["best_bid"],
                        best_ask=pc["best_ask"],
                    )
                    for pc in raw["price_changes"]
                ],
            )
        case "last_trade_price":
            return LastTradePriceEvent(
                event_type="last_trade_price",
                asset_id=raw["asset_id"],
                market=raw["market"],
                price=raw["price"],
                side=raw["side"],
                size=raw["size"],
                timestamp=raw["timestamp"],
                fee_rate_bps=raw["fee_rate_bps"],
                transaction_hash=raw["transaction_hash"],
            )
        case "tick_size_change":
            return TickSizeChangeEvent(
                event_type="tick_size_change",
                asset_id=raw["asset_id"],
                market=raw["market"],
                old_tick_size=raw["old_tick_size"],
                new_tick_size=raw["new_tick_size"],
                timestamp=raw["timestamp"],
            )
        case _:
            raise ValueError(f"Unknown event_type: {event_type}")
