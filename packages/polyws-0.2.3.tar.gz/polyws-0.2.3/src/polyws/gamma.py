"""Gamma API helper for fetching Polymarket markets."""

from __future__ import annotations

import json
import os
from urllib.request import Request, urlopen


GAMMA_API_URL = "https://gamma-api.polymarket.com/markets"

SORT_MAP = {
    "volume": ("volumeNum", "false"),
    "liquidity": ("liquidityNum", "false"),
    "newest": ("startDate", "false"),
}


def fetch_markets(
    limit: int = 20,
    sort: str = "volume",
    search: str | None = None,
) -> list[dict]:
    """Fetch markets from Gamma API.

    Returns list of market dicts with keys: question, clobTokenIds, volume, etc.
    """
    order_field, ascending = SORT_MAP.get(sort, SORT_MAP["volume"])
    params = {
        "limit": str(limit),
        "order": order_field,
        "ascending": ascending,
        "active": "true",
        "closed": "false",
    }
    if search:
        params["q"] = search

    query = "&".join(f"{k}={v}" for k, v in params.items())
    url = f"{GAMMA_API_URL}?{query}"
    req = Request(url, headers={"User-Agent": "polyws/0.1.0"})

    with urlopen(req) as resp:
        return json.loads(resp.read())


def extract_asset_ids(markets: list[dict]) -> dict[str, str]:
    """Extract asset_id -> question mapping from market list.

    Returns dict mapping first clobTokenId to market question.
    """
    result: dict[str, str] = {}
    for m in markets:
        try:
            token_ids = json.loads(m.get("clobTokenIds", "[]"))
            if token_ids:
                result[token_ids[0]] = m.get("question", "Unknown")
        except (json.JSONDecodeError, IndexError):
            continue
    return result
