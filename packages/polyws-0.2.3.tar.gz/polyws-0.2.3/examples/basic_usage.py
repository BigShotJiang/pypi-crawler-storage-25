"""Basic usage: stream top 10 Polymarket markets by volume."""

import asyncio
import json
import os
from urllib.request import Request, urlopen

# Clear proxy for direct WS connection
for _k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
    os.environ.pop(_k, None)

from polyws import WSSubscriptionManager, WebSocketHandlers, PolymarketPriceUpdateEvent


async def main():
    # Fetch top 10 markets
    url = "https://gamma-api.polymarket.com/markets?limit=10&order=volumeNum&ascending=false&active=true&closed=false"
    req = Request(url, headers={"User-Agent": "polyws/0.1.0"})
    with urlopen(req) as resp:
        markets_raw = json.loads(resp.read())

    market_names: dict[str, str] = {}
    asset_ids: list[str] = []
    for m in markets_raw:
        token_ids = json.loads(m["clobTokenIds"])
        if token_ids:
            aid = token_ids[0]
            asset_ids.append(aid)
            market_names[aid] = m["question"]

    from polyws import BookEvent, PriceChangeEvent

    async def on_book(events: list[BookEvent]):
        for e in events:
            name = market_names.get(e.asset_id, e.asset_id[:20])
            print(f"  [book] {name}: {len(e.bids)} bids, {len(e.asks)} asks")

    async def on_price_update(events: list[PolymarketPriceUpdateEvent]):
        for e in events:
            name = market_names.get(e.asset_id, e.asset_id[:20])
            chance = f"{float(e.price) * 100:.2f}%"
            print(f"  [price] {name}: {chance}")

    async def on_price_change(events: list[PriceChangeEvent]):
        for e in events:
            for pc in e.price_changes:
                name = market_names.get(pc.asset_id, pc.asset_id[:20])
                print(f"  [change] {name}: {pc.side} {pc.size} @ {pc.price}")

    async def on_error(error: Exception):
        print(f"Error: {error}")

    handlers = WebSocketHandlers(
        on_book=on_book,
        on_price_change=on_price_change,
        on_polymarket_price_update=on_price_update,
        on_error=on_error,
    )

    stream = WSSubscriptionManager(handlers)
    await stream.add_subscriptions(asset_ids)

    print(f"Streaming {len(asset_ids)} markets... (Ctrl+C to stop)")
    try:
        await asyncio.Event().wait()  # Run forever
    except asyncio.CancelledError:
        pass
    finally:
        await stream.clear_state()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
