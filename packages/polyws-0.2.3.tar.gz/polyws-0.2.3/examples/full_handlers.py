"""Full handlers example: all event types with detailed logging."""

import asyncio
import json
from urllib.request import urlopen

from polyws import (
    WSSubscriptionManager,
    WebSocketHandlers,
    BookEvent,
    PriceChangeEvent,
    LastTradePriceEvent,
    TickSizeChangeEvent,
    PolymarketPriceUpdateEvent,
)


async def on_book(events: list[BookEvent]):
    for e in events:
        print(f"[book] asset={e.asset_id[:20]}... bids={len(e.bids)} asks={len(e.asks)}")


async def on_price_change(events: list[PriceChangeEvent]):
    for e in events:
        for pc in e.price_changes:
            print(f"[price_change] {pc.side} {pc.size} @ {pc.price} asset={pc.asset_id[:20]}...")


async def on_last_trade(events: list[LastTradePriceEvent]):
    for e in events:
        print(f"[last_trade] {e.side} {e.size} @ {e.price} asset={e.asset_id[:20]}...")


async def on_tick_change(events: list[TickSizeChangeEvent]):
    for e in events:
        print(f"[tick_change] {e.old_tick_size} -> {e.new_tick_size} asset={e.asset_id[:20]}...")


async def on_price_update(events: list[PolymarketPriceUpdateEvent]):
    for e in events:
        print(f"[price_update] price={e.price} mid={e.midpoint} spread={e.spread} asset={e.asset_id[:20]}...")


async def on_open(manager_id: str, pending: list[str]):
    print(f"[ws_open] manager={manager_id[:8]} pending={len(pending)}")


async def on_close(manager_id: str, code: int, reason: str):
    print(f"[ws_close] manager={manager_id[:8]} code={code} reason={reason}")


async def on_error(error: Exception):
    print(f"[error] {error}")


async def main():
    url = "https://gamma-api.polymarket.com/markets?limit=5&order=volumeNum&ascending=false&active=true&closed=false"
    with urlopen(url) as resp:
        markets = json.loads(resp.read())

    asset_ids = []
    for m in markets:
        ids = json.loads(m["clobTokenIds"])
        if ids:
            asset_ids.append(ids[0])

    handlers = WebSocketHandlers(
        on_book=on_book,
        on_price_change=on_price_change,
        on_last_trade_price=on_last_trade,
        on_tick_size_change=on_tick_change,
        on_polymarket_price_update=on_price_update,
        on_ws_open=on_open,
        on_ws_close=on_close,
        on_error=on_error,
    )

    stream = WSSubscriptionManager(handlers)
    await stream.add_subscriptions(asset_ids)
    print(f"Streaming {len(asset_ids)} markets... (Ctrl+C to stop)")

    try:
        await asyncio.Event().wait()
    except asyncio.CancelledError:
        pass
    finally:
        await stream.clear_state()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
