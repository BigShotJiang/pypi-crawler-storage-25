"""Tests for WSSubscriptionManager — mocked WebSocket."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from polyws.types import (
    BookEvent,
    LastTradePriceEvent,
    PriceChangeEvent,
    PriceChangeItem,
    PriceLevel,
    PolymarketPriceUpdateEvent,
    TickSizeChangeEvent,
    WebSocketHandlers,
)
from polyws.manager import WSSubscriptionManager


def _make_handlers(**overrides) -> WebSocketHandlers:
    """Create handlers with AsyncMock defaults."""
    return WebSocketHandlers(
        on_book=overrides.get("on_book", AsyncMock()),
        on_price_change=overrides.get("on_price_change", AsyncMock()),
        on_last_trade_price=overrides.get("on_last_trade_price", AsyncMock()),
        on_tick_size_change=overrides.get("on_tick_size_change", AsyncMock()),
        on_polymarket_price_update=overrides.get("on_polymarket_price_update", AsyncMock()),
        on_error=overrides.get("on_error", AsyncMock()),
        on_ws_close=overrides.get("on_ws_close", AsyncMock()),
        on_ws_open=overrides.get("on_ws_open", AsyncMock()),
    )


class MockWebSocket:
    """Simulates a websockets connection for testing."""

    def __init__(self):
        self.sent: list[str] = []
        self.messages: asyncio.Queue[str | Exception] = asyncio.Queue()
        self.open = True
        self.close_code: int | None = None
        self.close_reason: str = ""
        self._closed = asyncio.Event()
        self.pong_waiter = asyncio.Future()
        self.pong_waiter.set_result(None)

    async def send(self, data: str) -> None:
        self.sent.append(data)

    async def recv(self) -> str:
        msg = await self.messages.get()
        if isinstance(msg, Exception):
            raise msg
        return msg

    async def close(self) -> None:
        self.open = False
        self._closed.set()

    async def ping(self) -> asyncio.Future:
        fut = asyncio.Future()
        fut.set_result(None)
        return fut

    def __aiter__(self):
        return self

    async def __anext__(self) -> str:
        msg = await self.messages.get()
        if isinstance(msg, Exception):
            raise msg
        return msg


class TestSubscriptionLifecycle:
    async def test_add_subscriptions_queues_pending(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1", "asset-2"])

            # Should include both assets
            ids = mgr.get_asset_ids()
            assert "asset-1" in ids
            assert "asset-2" in ids

            await mgr.clear_state()

    async def test_remove_pending_subscription(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1", "asset-2"])
            await mgr.remove_subscriptions(["asset-1"])

            ids = mgr.get_asset_ids()
            assert "asset-1" not in ids
            assert "asset-2" in ids

            await mgr.clear_state()

    async def test_clear_state_resets_everything(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])
            await mgr.clear_state()

            assert mgr.get_asset_ids() == []
            stats = mgr.get_statistics()
            assert stats.open_websockets == 0
            assert stats.asset_ids == 0

    async def test_statistics(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["a", "b", "c"])

            stats = mgr.get_statistics()
            assert stats.asset_ids == 3

            await mgr.clear_state()


class TestFlush:
    async def test_sends_handshake_then_subscribe(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])

            # Give the flush loop time to fire
            await asyncio.sleep(0.05)

            # First message should be the market handshake
            assert len(mock_ws.sent) >= 1
            handshake = json.loads(mock_ws.sent[0])
            assert handshake["type"] == "market"
            assert handshake["assets_ids"] == []

            # Second should be the subscribe
            if len(mock_ws.sent) >= 2:
                sub = json.loads(mock_ws.sent[1])
                assert sub["operation"] == "subscribe"
                assert "asset-1" in sub["assets_ids"]

            await mgr.clear_state()

    async def test_sends_unsubscribe(self):
        handlers = _make_handlers()
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])
            await asyncio.sleep(0.05)

            # Now remove
            await mgr.remove_subscriptions(["asset-1"])
            await asyncio.sleep(0.05)

            unsub_msgs = [
                json.loads(m) for m in mock_ws.sent
                if "operation" in json.loads(m) and json.loads(m)["operation"] == "unsubscribe"
            ]
            assert len(unsub_msgs) >= 1
            assert "asset-1" in unsub_msgs[0]["assets_ids"]

            await mgr.clear_state()


class TestEventRouting:
    async def test_book_event_routed(self):
        on_book = AsyncMock()
        handlers = _make_handlers(on_book=on_book)
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])
            await asyncio.sleep(0.05)

            # Simulate incoming book event
            book_raw = json.dumps([{
                "event_type": "book",
                "market": "m",
                "asset_id": "asset-1",
                "timestamp": "123",
                "hash": "h",
                "bids": [{"price": "0.5", "size": "10"}],
                "asks": [{"price": "0.6", "size": "10"}],
            }])
            await mock_ws.messages.put(book_raw)
            await asyncio.sleep(0.05)

            on_book.assert_called()
            events = on_book.call_args[0][0]
            assert len(events) == 1
            assert events[0].asset_id == "asset-1"

            await mgr.clear_state()

    async def test_unsubscribed_events_filtered(self):
        on_book = AsyncMock()
        handlers = _make_handlers(on_book=on_book)
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])
            await asyncio.sleep(0.05)

            # Event for asset-2 (not subscribed)
            book_raw = json.dumps([{
                "event_type": "book",
                "market": "m",
                "asset_id": "asset-2",
                "timestamp": "123",
                "hash": "h",
                "bids": [{"price": "0.5", "size": "10"}],
                "asks": [{"price": "0.6", "size": "10"}],
            }])
            await mock_ws.messages.put(book_raw)
            await asyncio.sleep(0.05)

            # on_book should NOT have been called (or called with empty list which is skipped)
            if on_book.called:
                events = on_book.call_args[0][0]
                assert all(e.asset_id == "asset-1" for e in events)

            await mgr.clear_state()


class TestErrorIsolation:
    async def test_handler_exception_doesnt_break_loop(self):
        call_count = 0

        async def bad_book_handler(events):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("handler crash")

        handlers = _make_handlers(on_book=bad_book_handler)
        mock_ws = MockWebSocket()
        with patch("polyws.manager.websockets.connect", new_callable=AsyncMock, return_value=mock_ws):
            mgr = WSSubscriptionManager(handlers)
            await mgr.add_subscriptions(["asset-1"])
            await asyncio.sleep(0.05)

            # First event — handler crashes
            book_raw = json.dumps([{
                "event_type": "book",
                "market": "m",
                "asset_id": "asset-1",
                "timestamp": "1",
                "hash": "h",
                "bids": [{"price": "0.5", "size": "10"}],
                "asks": [{"price": "0.6", "size": "10"}],
            }])
            await mock_ws.messages.put(book_raw)
            await asyncio.sleep(0.05)

            # Second event — should still work
            await mock_ws.messages.put(book_raw)
            await asyncio.sleep(0.05)

            assert call_count == 2  # Both events were processed

            await mgr.clear_state()
