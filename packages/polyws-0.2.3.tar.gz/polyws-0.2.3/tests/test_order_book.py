"""Tests for OrderBookCache — mirrors TS test coverage."""

import pytest

from polyws.types import BookEvent, PriceChangeEvent, PriceChangeItem, PriceLevel
from polyws.order_book import OrderBookCache, BookEntry

ASSET_ID = "asset-1"


def _book_event(
    bids: list[tuple[str, str]],
    asks: list[tuple[str, str]],
    asset_id: str = ASSET_ID,
) -> BookEvent:
    """Helper to build a BookEvent from (price, size) tuples."""
    return BookEvent(
        event_type="book",
        market="m",
        asset_id=asset_id,
        timestamp="0",
        hash="h",
        bids=[PriceLevel(p, s) for p, s in bids],
        asks=[PriceLevel(p, s) for p, s in asks],
    )


def _price_change(
    changes: list[tuple[str, str, str, str]],
    asset_id: str = ASSET_ID,
) -> PriceChangeEvent:
    """Helper: changes are (price, size, side, hash) tuples."""
    return PriceChangeEvent(
        event_type="price_change",
        market="m",
        timestamp="1",
        price_changes=[
            PriceChangeItem(
                asset_id=asset_id,
                price=p,
                size=s,
                side=side,
                hash=h,
                best_bid="0",
                best_ask="0",
            )
            for p, s, side, h in changes
        ],
    )


def assert_ascending(levels: list[PriceLevel]) -> None:
    for i in range(1, len(levels)):
        assert float(levels[i].price) > float(levels[i - 1].price)


def assert_descending(levels: list[PriceLevel]) -> None:
    for i in range(1, len(levels)):
        assert float(levels[i].price) < float(levels[i - 1].price)


class TestReplaceBook:
    def test_populates_cache_and_sorts(self):
        cache = OrderBookCache()
        evt = _book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.99", "2"), ("0.98", "1")],
        )
        cache.replace_book(evt)
        entry = cache.get_book_entry(ASSET_ID)
        assert entry is not None
        assert_ascending(entry.bids)
        assert_descending(entry.asks)

    def test_preserves_previous_price_data(self):
        cache = OrderBookCache()
        evt1 = _book_event(bids=[("0.50", "10")], asks=[("0.60", "10")])
        cache.replace_book(evt1)
        cache.midpoint(ASSET_ID)  # sets midpoint
        cache.spread_over(ASSET_ID)  # sets spread

        evt2 = _book_event(bids=[("0.40", "5")], asks=[("0.70", "5")])
        cache.replace_book(evt2)
        entry = cache.get_book_entry(ASSET_ID)
        # midpoint/spread from previous book should be preserved
        assert entry.midpoint is not None
        assert entry.spread is not None

    def test_returns_none_for_missing(self):
        cache = OrderBookCache()
        assert cache.get_book_entry("nonexistent") is None


class TestUpsertPriceChange:
    def test_adds_new_bid_level(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.98", "1"), ("0.99", "2")],
        ))
        cache.upsert_price_change(_price_change([("0.90", "3", "BUY", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        assert any(b.price == "0.90" for b in entry.bids)
        assert_ascending(entry.bids)

    def test_updates_existing_bid_size(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.98", "1")],
        ))
        cache.upsert_price_change(_price_change([("0.02", "99", "BUY", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        bid = next(b for b in entry.bids if b.price == "0.02")
        assert bid.size == "99"

    def test_removes_bid_when_size_zero(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5"), ("0.03", "8")],
            asks=[("0.98", "1")],
        ))
        cache.upsert_price_change(_price_change([("0.02", "0", "BUY", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        assert len(entry.bids) == 2
        assert not any(b.price == "0.02" for b in entry.bids)

    def test_removes_ask_when_size_zero(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10")],
            asks=[("0.97", "3"), ("0.98", "1"), ("0.99", "2")],
        ))
        cache.upsert_price_change(_price_change([("0.98", "0", "SELL", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        assert len(entry.asks) == 2
        assert not any(a.price == "0.98" for a in entry.asks)

    def test_noop_when_new_level_size_zero(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.98", "1")],
        ))
        cache.upsert_price_change(_price_change([("0.50", "0", "BUY", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        assert len(entry.bids) == 2

    def test_multiple_changes_in_one_event(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5"), ("0.03", "8")],
            asks=[("0.97", "3"), ("0.98", "1"), ("0.99", "2")],
        ))
        cache.upsert_price_change(_price_change([
            ("0.01", "0", "BUY", "x1"),
            ("0.99", "0", "SELL", "x2"),
        ]))
        entry = cache.get_book_entry(ASSET_ID)
        assert len(entry.bids) == 2
        assert len(entry.asks) == 2

    def test_raises_if_book_not_cached(self):
        cache = OrderBookCache()
        with pytest.raises(ValueError, match="not cached"):
            cache.upsert_price_change(_price_change([("0.50", "1", "BUY", "x")]))

    def test_adds_new_ask_level_maintains_descending(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10")],
            asks=[("0.99", "2"), ("0.97", "3")],
        ))
        cache.upsert_price_change(_price_change([("0.95", "5", "SELL", "x")]))
        entry = cache.get_book_entry(ASSET_ID)
        assert any(a.price == "0.95" for a in entry.asks)
        assert_descending(entry.asks)


class TestSpreadOver:
    def test_wide_spread(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.99", "2"), ("0.98", "1")],
        ))
        assert cache.spread_over(ASSET_ID, 0.1) is True

    def test_narrow_spread(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.90", "5")],
            asks=[("0.99", "2"), ("0.98", "1")],
        ))
        assert cache.spread_over(ASSET_ID, 0.1) is False  # 0.98 - 0.90 = 0.08

    def test_exactly_0_1_returns_false(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.1", "10"), ("0.2", "5")],
            asks=[("0.4", "2"), ("0.3", "1")],
        ))
        assert cache.spread_over(ASSET_ID, 0.1) is False  # 0.3 - 0.2 = 0.1 (not > 0.1)

    def test_updates_spread_field(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.1", "10"), ("0.2", "5")],
            asks=[("0.4", "2"), ("0.3", "1")],
        ))
        cache.spread_over(ASSET_ID)
        entry = cache.get_book_entry(ASSET_ID)
        assert entry.spread == "0.1"

    def test_raises_no_asks(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(bids=[("0.01", "10")], asks=[]))
        with pytest.raises(ValueError, match="No asks"):
            cache.spread_over(ASSET_ID)

    def test_raises_no_bids(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(bids=[], asks=[("0.99", "1")]))
        with pytest.raises(ValueError, match="No bids"):
            cache.spread_over(ASSET_ID)

    def test_raises_on_non_numeric_price(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("A", "1")],
        ))
        with pytest.raises(ValueError):
            cache.spread_over(ASSET_ID)


class TestMidpoint:
    def test_basic_midpoint(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.01", "10"), ("0.02", "5")],
            asks=[("0.99", "2"), ("0.98", "1")],
        ))
        assert cache.midpoint(ASSET_ID) == "0.5"  # (0.02 + 0.98) / 2

    def test_precise_midpoint(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.1", "10"), ("0.2", "5")],
            asks=[("0.4", "2"), ("0.3", "1")],
        ))
        assert cache.midpoint(ASSET_ID) == "0.25"  # (0.2 + 0.3) / 2

    def test_updates_midpoint_field(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("0.2", "5")],
            asks=[("0.3", "1")],
        ))
        cache.midpoint(ASSET_ID)
        entry = cache.get_book_entry(ASSET_ID)
        assert entry.midpoint == "0.25"

    def test_raises_no_bids(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(bids=[], asks=[("0.99", "1")]))
        with pytest.raises(ValueError, match="No bids"):
            cache.midpoint(ASSET_ID)

    def test_raises_on_non_numeric_price(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(
            bids=[("A", "10")],
            asks=[("0.99", "1")],
        ))
        with pytest.raises(ValueError):
            cache.midpoint(ASSET_ID)


class TestClear:
    def test_clear_single(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(bids=[("0.5", "10")], asks=[("0.6", "1")]))
        cache.clear(ASSET_ID)
        assert cache.get_book_entry(ASSET_ID) is None

    def test_clear_all(self):
        cache = OrderBookCache()
        cache.replace_book(_book_event(bids=[("0.5", "10")], asks=[("0.6", "1")], asset_id="a"))
        cache.replace_book(_book_event(bids=[("0.5", "10")], asks=[("0.6", "1")], asset_id="b"))
        cache.clear()
        assert cache.get_book_entry("a") is None
        assert cache.get_book_entry("b") is None
