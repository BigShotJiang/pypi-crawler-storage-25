"""Tests for polyws CLI and gamma helper."""

from __future__ import annotations

import io
import json
import sys
from unittest.mock import MagicMock, patch

import orjson
import pytest

from polyws.gamma import GAMMA_API_URL, SORT_MAP, extract_asset_ids, fetch_markets
from polyws import cli


# ── fetch_markets tests ──────────────────────────────────────


class TestFetchMarkets:
    """Tests for gamma.fetch_markets."""

    def _mock_urlopen(self, response_data: list[dict]):
        """Create a mock urlopen context manager."""
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(response_data).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    @patch("polyws.gamma.urlopen")
    @patch("polyws.gamma.Request")
    def test_default_params(self, mock_request_cls, mock_urlopen):
        """Default call uses volume sort, limit 20, active/open filters."""
        mock_urlopen.return_value = self._mock_urlopen([{"question": "Test?"}])

        result = fetch_markets()

        # Check URL construction
        call_args = mock_request_cls.call_args
        url = call_args[0][0]
        assert "limit=20" in url
        assert "order=volumeNum" in url
        assert "ascending=false" in url
        assert "active=true" in url
        assert "closed=false" in url
        assert "&q=" not in url
        assert result == [{"question": "Test?"}]

    @patch("polyws.gamma.urlopen")
    @patch("polyws.gamma.Request")
    def test_search_param(self, mock_request_cls, mock_urlopen):
        """Search text is passed as q= parameter."""
        mock_urlopen.return_value = self._mock_urlopen([])

        fetch_markets(search="trump")

        url = mock_request_cls.call_args[0][0]
        assert "q=trump" in url

    @patch("polyws.gamma.urlopen")
    @patch("polyws.gamma.Request")
    def test_sort_options(self, mock_request_cls, mock_urlopen):
        """Each sort option maps to correct order field."""
        mock_urlopen.return_value = self._mock_urlopen([])

        for sort_key, (field, _) in SORT_MAP.items():
            fetch_markets(sort=sort_key)
            url = mock_request_cls.call_args[0][0]
            assert f"order={field}" in url

    @patch("polyws.gamma.urlopen")
    @patch("polyws.gamma.Request")
    def test_custom_limit(self, mock_request_cls, mock_urlopen):
        """Custom limit is passed through."""
        mock_urlopen.return_value = self._mock_urlopen([])

        fetch_markets(limit=5)

        url = mock_request_cls.call_args[0][0]
        assert "limit=5" in url

    @patch("polyws.gamma.urlopen")
    @patch("polyws.gamma.Request")
    def test_user_agent(self, mock_request_cls, mock_urlopen):
        """Request includes polyws user agent."""
        mock_urlopen.return_value = self._mock_urlopen([])

        fetch_markets()

        headers = mock_request_cls.call_args[1].get("headers") or mock_request_cls.call_args[0][1] if len(mock_request_cls.call_args[0]) > 1 else mock_request_cls.call_args[1]["headers"]
        assert headers.get("User-Agent", "").startswith("polyws/")


# ── extract_asset_ids tests ──────────────────────────────────


class TestExtractAssetIds:
    """Tests for gamma.extract_asset_ids."""

    def test_basic_extraction(self):
        """Extracts first token ID mapped to question."""
        markets = [
            {"question": "Will X?", "clobTokenIds": '["abc123", "def456"]'},
            {"question": "Will Y?", "clobTokenIds": '["ghi789"]'},
        ]
        result = extract_asset_ids(markets)
        assert result == {"abc123": "Will X?", "ghi789": "Will Y?"}

    def test_empty_token_ids(self):
        """Skips markets with empty clobTokenIds."""
        markets = [
            {"question": "Will X?", "clobTokenIds": "[]"},
        ]
        result = extract_asset_ids(markets)
        assert result == {}

    def test_missing_token_ids(self):
        """Skips markets with no clobTokenIds field."""
        markets = [{"question": "Will X?"}]
        result = extract_asset_ids(markets)
        assert result == {}

    def test_invalid_json(self):
        """Skips markets with malformed clobTokenIds."""
        markets = [
            {"question": "Will X?", "clobTokenIds": "not-json"},
        ]
        result = extract_asset_ids(markets)
        assert result == {}

    def test_missing_question(self):
        """Uses 'Unknown' when question is missing."""
        markets = [{"clobTokenIds": '["abc"]'}]
        result = extract_asset_ids(markets)
        assert result == {"abc": "Unknown"}


# ── CLI arg parsing tests ────────────────────────────────────


class TestArgParsing:
    """Tests for CLI argument parsing."""

    def _parse(self, argv: list[str]):
        """Parse args using the CLI's parser."""
        parser = self._build_parser()
        return parser.parse_args(argv)

    def _build_parser(self):
        parser = argparse.ArgumentParser(prog="polyws")
        subparsers = parser.add_subparsers(dest="command")

        mp = subparsers.add_parser("markets")
        mp.add_argument("--search", type=str)
        mp.add_argument("--limit", type=int, default=20)
        mp.add_argument("--sort", choices=["volume", "liquidity", "newest"], default="volume")

        sp = subparsers.add_parser("stream")
        sp.add_argument("--asset-id", nargs="+")
        sp.add_argument("--markets", type=int)
        sp.add_argument("--search", type=str)

        return parser

    def test_markets_defaults(self):
        args = self._parse(["markets"])
        assert args.command == "markets"
        assert args.limit == 20
        assert args.sort == "volume"
        assert args.search is None

    def test_markets_with_options(self):
        args = self._parse(["markets", "--search", "trump", "--limit", "5", "--sort", "liquidity"])
        assert args.search == "trump"
        assert args.limit == 5
        assert args.sort == "liquidity"

    def test_stream_with_asset_ids(self):
        args = self._parse(["stream", "--asset-id", "abc", "def"])
        assert args.command == "stream"
        assert args.asset_id == ["abc", "def"]

    def test_stream_with_search(self):
        args = self._parse(["stream", "--search", "bitcoin"])
        assert args.search == "bitcoin"

    def test_stream_with_markets_count(self):
        args = self._parse(["stream", "--markets", "5"])
        assert args.markets == 5

    def test_no_command(self):
        args = self._parse([])
        assert args.command is None


# ── Output formatting tests ──────────────────────────────────


class TestOutputFormatting:
    """Tests for output formatting in both TTY and JSON modes."""

    SAMPLE_MARKETS = [
        {
            "question": "Will Trump win the 2028 election?",
            "volumeNum": 1_500_000,
            "outcomePrices": '["0.6500", "0.3500"]',
            "clobTokenIds": '["abc123def456"]',
            "slug": "will-trump-win-2028",
        },
        {
            "question": "Will Bitcoin reach $100k by end of 2026?",
            "volumeNum": 800_000,
            "outcomePrices": '["0.4200", "0.5800"]',
            "clobTokenIds": '["ghi789"]',
            "slug": "bitcoin-100k-2026",
        },
    ]

    @patch("polyws.cli.fetch_markets")
    def test_json_output(self, mock_fetch):
        """Non-TTY mode outputs JSON lines."""
        mock_fetch.return_value = self.SAMPLE_MARKETS

        # Capture stdout bytes
        buf = io.BytesIO()
        old_buffer = sys.stdout.buffer
        cli.IS_TTY = False

        try:
            sys.stdout = MagicMock()
            sys.stdout.buffer = buf
            args = argparse.Namespace(command="markets", limit=20, sort="volume", search=None)
            cli._cmd_markets(args)
        finally:
            sys.stdout = sys.__stdout__

        output = buf.getvalue().decode()
        lines = [l for l in output.strip().split("\n") if l]
        assert len(lines) == 2

        first = orjson.loads(lines[0])
        assert first["asset_id"] == "abc123def456"
        assert first["question"] == "Will Trump win the 2028 election?"
        assert first["volume"] == 1_500_000
        assert first["price"] == "0.6500"
        assert first["market_slug"] == "will-trump-win-2028"

    @patch("polyws.cli.fetch_markets")
    def test_tty_output(self, mock_fetch):
        """TTY mode outputs formatted lines."""
        mock_fetch.return_value = self.SAMPLE_MARKETS

        buf = io.StringIO()
        cli.IS_TTY = True

        try:
            sys.stdout = buf
            args = argparse.Namespace(command="markets", limit=20, sort="volume", search=None)
            cli._cmd_markets(args)
        finally:
            sys.stdout = sys.__stdout__

        output = buf.getvalue()
        assert "65.0%" in output
        assert "Trump" in output
        assert "$1.5M" in output

    def test_format_volume(self):
        """Volume formatting produces human-readable strings."""
        assert cli._format_volume(1_500_000) == "$1.5M"
        assert cli._format_volume(800_000) == "$800K"
        assert cli._format_volume(500) == "$500"
        assert cli._format_volume(0) == "$0"


import argparse
