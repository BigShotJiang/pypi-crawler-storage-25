"""Live integration tests — require network access to Polymarket."""

import asyncio
import os

import pytest

from polyws import WSSubscriptionManager, WebSocketHandlers, BookEvent

# Clear proxy env vars — Polymarket WS doesn't work through HTTP proxies
for _k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
    os.environ.pop(_k, None)


# Use a well-known active asset (fetch dynamically)
async def _get_active_asset_id() -> str:
    """Fetch one active asset from Polymarket API."""
    import json
    from urllib.request import Request, urlopen

    url = "https://gamma-api.polymarket.com/markets?limit=1&order=volumeNum&ascending=false&active=true&closed=false"
    req = Request(url, headers={"User-Agent": "polyws/0.1.0"})
    with urlopen(req) as resp:
        data = json.loads(resp.read())
    return json.loads(data[0]["clobTokenIds"])[0]


@pytest.mark.live
async def test_receives_book_event():
    """Connect to real WS and verify we get a book event within 10s."""
    received = asyncio.Event()
    events_received: list[BookEvent] = []

    async def on_book(events: list[BookEvent]):
        events_received.extend(events)
        received.set()

    errors: list[Exception] = []

    async def on_error(err: Exception):
        errors.append(err)
        print(f"WS Error: {err}")

    asset_id = await _get_active_asset_id()
    handlers = WebSocketHandlers(on_book=on_book, on_error=on_error)
    mgr = WSSubscriptionManager(handlers)

    try:
        await mgr.add_subscriptions([asset_id])
        await asyncio.wait_for(received.wait(), timeout=10.0)
        assert len(events_received) > 0
        assert events_received[0].asset_id == asset_id
        # At least one side of the book should have data
        assert len(events_received[0].bids) > 0 or len(events_received[0].asks) > 0
    finally:
        await mgr.clear_state()
