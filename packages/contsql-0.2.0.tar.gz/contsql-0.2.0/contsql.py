#!/usr/bin/env python3
# v0.2 | 2026-04-13 | case insensitive ILIKE guardrail + önceki sorgu entity context
"""contsql — Minimal DuckDB SQL agent. Soru sor, SQL üret, çalıştır, göster."""

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

import duckdb
import requests


# ── Config ──

OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
MODEL = os.environ.get("CONTSQL_MODEL", "cont-local")
TIMEOUT = int(os.environ.get("CONTSQL_TIMEOUT", "120"))

BANNED_SQL = ["INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "TRUNCATE", "EXEC"]


# ── Schema discovery ──

def read_schema(conn):
    """DB'den tablo/kolon/satır bilgisi çıkar → string."""
    tables = conn.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
    ).fetchall()

    lines = []
    for (tname,) in tables:
        cols = conn.execute(f"""
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_schema='main' AND table_name='{tname}'
            ORDER BY ordinal_position
        """).fetchall()
        count = conn.execute(f"SELECT COUNT(*) FROM {tname}").fetchone()[0]
        col_str = ", ".join(f"{c} ({t})" for c, t in cols)
        lines.append(f"  {tname} ({count} satır): {col_str}")
    return "\n".join(lines)


def read_domain_notes(db_path):
    """domain_notes.txt veya ews_domain.yaml varsa oku."""
    for name in ("domain_notes.txt", "ews_domain.yaml"):
        p = Path(db_path).parent / name
        if p.exists():
            return p.read_text(encoding="utf-8", errors="ignore")
        # contsql dizininde de ara
        p2 = Path(__file__).parent / name
        if p2.exists():
            return p2.read_text(encoding="utf-8", errors="ignore")
    return ""


# ── System prompt ──

def build_system_prompt(schema_text, domain_text="", last_result_entities=None):
    prompt = f"""Sen bir SQL asistanısın. Kullanıcının sorusuna uygun SQL yaz.

Kurallar:
- Sadece SELECT veya WITH ... SELECT yaz. INSERT/UPDATE/DELETE/DROP/ALTER/CREATE yasak.
- Cevabında SADECE SQL ver, ```sql ... ``` bloğu içinde.
- SQL öncesi veya sonrası açıklama ekleme.
- Emin değilsen "Bu soruyu mevcut tablolarla cevaplayamıyorum" de.
- Veri uydurma. Sorgu sonucu olmadan liste verme.
- String karşılaştırmalarında LIKE yerine her zaman ILIKE kullan. Türkçe karakter eşleştirmesi (İ↔i, I↔ı, Ş↔ş, Ü↔ü, Ö↔ö, Ç↔ç, Ğ↔ğ) için ILIKE şart.

Veritabanı şeması:
{schema_text}
"""
    if domain_text:
        prompt += f"\nDomain bilgisi:\n{domain_text}\n"
    if last_result_entities:
        prompt += (
            f"\nÖNCEKİ SORGU SONUCUNDAKI FİRMALAR (entity_id): {last_result_entities}\n"
            "Kullanıcı 'bu firmalar', 'bunların', 'aynıları', 'yukarıdakiler' gibi "
            "referans verirse bu entity_id listesini WHERE koşulunda kullan.\n"
        )
    return prompt


# ── SQL extraction + safety ──

def extract_sql(response_text):
    """Model yanıtından ```sql ... ``` bloğunu çıkar."""
    match = re.search(r'```sql\s*\n?(.*?)```', response_text, re.DOTALL)
    if match:
        return match.group(1).strip()
    # Fallback: tüm metin SQL olabilir
    stripped = response_text.strip()
    if stripped.upper().startswith(("SELECT", "WITH")):
        return stripped
    return None


def _like_to_ilike(sql):
    """LIKE → ILIKE guardrail. String literal içindekilere dokunmaz."""
    return re.sub(
        r"""(?x)
        (                           # Grup 1: string literal — atla
            '(?:[^']|'')*'          #   tek tırnak içi
        )
        |
        \b(NOT\s+)?LIKE\b          # Grup 2: opsiyonel NOT, ardından LIKE keyword
        """,
        lambda m: m.group(0) if m.group(1) else f"{m.group(2) or ''}ILIKE",
        sql,
        flags=re.IGNORECASE,
    )


def check_sql_safety(sql):
    """Sadece SELECT/WITH izinli. Tehlikeli keyword varsa hata döndür."""
    sql_upper = sql.strip().upper()
    if not sql_upper.startswith("SELECT") and not sql_upper.startswith("WITH"):
        return "HATA: Sadece SELECT/WITH sorguları çalıştırılabilir."
    for kw in BANNED_SQL:
        if kw in sql_upper:
            return f"HATA: {kw} komutu yasak. Sadece okuma sorguları izinli."
    return None


# ── LLM call ──

def ask_model(system_prompt, question):
    """Ollama'ya soru gönder, yanıt al."""
    t0 = time.time()
    try:
        resp = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": question},
                ],
                "stream": False,
            },
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        content = data.get("message", {}).get("content", "")
        elapsed = time.time() - t0
        tokens = data.get("eval_count", 0)
        return content, elapsed, tokens
    except Exception as e:
        return f"LLM HATA: {e}", time.time() - t0, 0


# ── Result formatting ──

def _fmt_value(v):
    """Sayısal değerleri Türkçe formatla (binlik nokta, ondalık virgül)."""
    if v is None:
        return "—"
    if isinstance(v, float):
        # Ondalık kısmı olan float
        int_part, dec_part = f"{v:.2f}".split(".")
        int_formatted = f"{int(int_part):,}".replace(",", ".")
        # Sondaki gereksiz sıfırları kaldır ama en az 1 ondalık bırak değil,
        # .00 ise tam sayı gibi göster
        if dec_part == "00":
            return int_formatted
        return f"{int_formatted},{dec_part}"
    if isinstance(v, int):
        return f"{v:,}".replace(",", ".")
    return str(v)


def format_table(columns, rows, max_rows=50):
    """Basit tablo formatı."""
    if not rows:
        return "  (sonuç yok)"

    # Değerleri formatla
    formatted_rows = [
        [_fmt_value(v) for v in row] for row in rows[:max_rows]
    ]

    # Kolon genişlikleri
    widths = [len(str(c)) for c in columns]
    for row in formatted_rows:
        for i, v in enumerate(row):
            widths[i] = max(widths[i], len(v))
    widths = [min(w, 30) for w in widths]

    lines = []
    # Header
    header = " | ".join(str(c).ljust(widths[i]) for i, c in enumerate(columns))
    lines.append(f"  {header}")
    lines.append(f"  {'-+-'.join('-' * w for w in widths)}")
    # Rows
    for row in formatted_rows:
        row_str = " | ".join(
            v[:widths[i]].ljust(widths[i])
            for i, v in enumerate(row)
        )
        lines.append(f"  {row_str}")
    if len(rows) > max_rows:
        lines.append(f"  ... ve {len(rows) - max_rows} satır daha")
    return "\n".join(lines)


# ── Main loop ──

def _extract_entity_ids(columns, rows, max_entities=100):
    """Sorgu sonucundan entity_id listesini çıkar. Yoksa None döner."""
    col_lower = [c.lower() for c in columns]
    if "entity_id" not in col_lower:
        return None
    idx = col_lower.index("entity_id")
    ids = list(dict.fromkeys(row[idx] for row in rows if row[idx] is not None))
    if len(ids) > max_entities:
        return None  # çok geniş, context'e ekleme
    return ids or None


def run_query(conn, system_prompt, question):
    """Tek soru → SQL → çalıştır → sonuç. entity_id listesi döndürür."""
    # 1. Model'e sor
    response, elapsed, tokens = ask_model(system_prompt, question)

    print(f"\n💭 MODEL ({elapsed:.1f}s, ~{tokens} tok)")
    if not response.startswith("LLM HATA"):
        thought = re.sub(r'```sql.*?```', '', response, flags=re.DOTALL).strip()
        if thought:
            print(f"   {thought[:200]}")

    # 2. SQL çıkar
    sql = extract_sql(response)
    if not sql:
        print(f"\n❌ Model SQL üretmedi:")
        print(f"   {response[:300]}")
        return None

    # 3. Güvenlik kontrolü
    safety_error = check_sql_safety(sql)
    if safety_error:
        print(f"\n⛔ {safety_error}")
        print(f"🔍 SQL: {sql[:200]}")
        return None

    # 3b. LIKE → ILIKE guardrail
    sql = _like_to_ilike(sql)

    print(f"🔍 SQL: {sql}")

    # 4. Çalıştır
    try:
        t0 = time.time()
        result = conn.execute(sql)
        columns = [desc[0] for desc in result.description]
        rows = result.fetchall()
        query_ms = (time.time() - t0) * 1000

        print(f"\n📊 SONUÇ ({len(rows)} satır, {query_ms:.0f}ms)")
        print(format_table(columns, rows))

        # Entity context çıkar
        entities = _extract_entity_ids(columns, rows)
        if entities is None and len(rows) > 100:
            print("  ⚠ Önceki sorgu çok geniş — firma referansı için soruyu daraltın.")
        return entities
    except duckdb.Error as e:
        print(f"\n❌ SQL hatası: {e}")
        print(f"🔍 SQL: {sql}")
        return None


def interactive_loop(conn, schema_text, domain_text):
    """REPL döngüsü."""
    print(f"\ncontsql hazır. Model: {MODEL}")
    print("Çıkmak için: quit/exit/q\n")

    last_result_entities = None

    while True:
        try:
            question = input("contsql> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nÇıkış.")
            break

        if not question:
            continue
        if question.lower() in ("quit", "exit", "q", "çık"):
            break
        if question.lower() in ("schema", "şema"):
            print(f"\n{read_schema(conn)}\n")
            continue

        system_prompt = build_system_prompt(schema_text, domain_text, last_result_entities)
        entities = run_query(conn, system_prompt, question)
        if entities is not None:
            last_result_entities = entities
        print()


def main():
    parser = argparse.ArgumentParser(
        description="contsql — DuckDB SQL agent",
        usage="contsql DB_PATH [SORU] [--model MODEL]",
    )
    parser.add_argument("db_path", help="DuckDB dosya yolu")
    parser.add_argument("question", nargs="?", help="Tek soru (opsiyonel)")
    global MODEL
    parser.add_argument("--model", default=MODEL, help="Ollama model adı (default: cont-local)")
    args = parser.parse_args()
    MODEL = args.model

    # DB bağlan
    db_path = Path(args.db_path).expanduser()
    if not db_path.exists():
        print(f"HATA: DB bulunamadı: {db_path}")
        sys.exit(1)

    conn = duckdb.connect(str(db_path), read_only=True)

    # Schema + domain
    schema_text = read_schema(conn)
    domain_text = read_domain_notes(str(db_path))

    print(f"DB: {db_path} | Model: {MODEL}")

    # Tek soru veya interaktif
    if args.question:
        system_prompt = build_system_prompt(schema_text, domain_text)
        run_query(conn, system_prompt, args.question)
    else:
        interactive_loop(conn, schema_text, domain_text)

    conn.close()


if __name__ == "__main__":
    main()
