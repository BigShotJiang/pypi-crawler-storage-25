# pylint: skip-file
# ruff: noqa
# mypy: ignore-errors
import os
import subprocess
from copy import deepcopy
from random import randint
from unittest.mock import MagicMock, patch

import pytest
import requests
from dotenv import load_dotenv
from opentaskpy.taskhandlers import transfer

from opentaskpy.addons.o365.remotehandlers.sharepoint import SharepointTransfer

# Set the log level to maximum
os.environ["OTF_LOG_LEVEL"] = "DEBUG"

local_source_definition = {
    "directory": "",
    "filename": "",
    "protocol": {"name": "local"},
}

local_destination_definition = {
    "directory": "",
    "filename": "",
    "protocol": {"name": "local"},
}

sharepoint_destination_definition = {
    "siteHostname": None,
    "siteName": None,
    "directory": "Dev/dest",
    "protocol": {
        "name": "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer",
        "refreshToken": "",
        "clientId": None,
        "tenantId": None,
    },
    "cacheableVariables": [
        {
            "variableName": "protocol.refreshToken",
            "cachingPlugin": "file",
            "cacheArgs": {
                "file": None,
            },
            "min_cache_age": "600",
        }
    ],
}

sharepoint_source_definition = {
    "siteHostname": None,
    "siteName": None,
    "directory": "Dev/src",
    "fileRegex": "^test.txt$",
    "protocol": {
        "name": "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer",
        "refreshToken": "",
        "clientId": None,
        "tenantId": None,
    },
    "cacheableVariables": [
        {
            "variableName": "protocol.refreshToken",
            "cachingPlugin": "file",
            "cacheArgs": {
                "file": None,
            },
        }
    ],
}

sharepoint_filewatch_task_definition_source = {
    "siteHostname": None,
    "siteName": None,
    "directory": "Dev/src",
    "fileRegex": ".*\\.txt",
    "protocol": {
        "name": "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer",
        "refreshToken": "",
        "clientId": None,
        "tenantId": None,
    },
    "fileWatch": {
        "timeout": 2,
    },
    "cacheableVariables": [
        {
            "variableName": "protocol.refreshToken",
            "cachingPlugin": "file",
            "cacheArgs": {
                "file": None,
            },
        }
    ],
}


sharepoint_source_definition_dest = {
    "siteHostname": None,
    "siteName": None,
    "directory": "Dev/dest",
    "fileRegex": "^pca_move_recursive.txt$",
    "protocol": {
        "name": "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer",
        "refreshToken": "",
        "clientId": None,
        "tenantId": None,
    },
    "cacheableVariables": [
        {
            "variableName": "protocol.refreshToken",
            "cachingPlugin": "file",
            "cacheArgs": {
                "file": None,
            },
        }
    ],
}


"""
These tests are hard to fully automate, given a full set of creds are needed for the environment.

The below tests assume the following exists in the Sharepoint site being tested against:

- A folder called "src" exists
- There are at least 2 files in the "src" folder
- At least one of the files is a .txt file
- There's a .txt file in the top level of the site (default Documents/Shared Documents list)

"""


@pytest.fixture(scope="session")
def o365_creds():
    # If this is not github actions, then load variables from a .env file at the root of
    # the repo
    if "GITHUB_ACTIONS" not in os.environ:
        # Load contents of .env into environment
        # Get the current directory
        current_dir = os.path.dirname(os.path.realpath(__file__))
        load_dotenv(dotenv_path=f"{current_dir}/../.env")

    # If a refresh_token.txt exists at the root, then load that too
    if os.path.exists(f"{current_dir}/../refresh_token.txt"):
        with open(f"{current_dir}/../refresh_token.txt", "r") as f:
            os.environ["REFRESH_TOKEN"] = f.read()

    return {
        "clientId": os.getenv("CLIENT_ID"),
        "tenantId": os.getenv("TENANT_ID"),
        "sharepointSite": os.getenv("SHAREPOINT_SITE"),
        "sharepointHost": os.getenv("SHAREPOINT_HOST"),
        "refreshToken": os.getenv("REFRESH_TOKEN"),
        "rootDir": f"{current_dir}/../",
        "document_library": os.getenv("DOCUMENT_LIBRARY"),
        "source_folder": os.getenv("SOURCE_FOLDER"),
    }


def setup_creds_for_transfer(transfer_definition: dict, creds) -> dict:

    if (
        transfer_definition["source"]["protocol"]["name"]
        == "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer"
    ):

        transfer_definition["source"]["protocol"]["refreshToken"] = creds[
            "refreshToken"
        ]
        transfer_definition["source"]["protocol"]["tenantId"] = creds["tenantId"]
        transfer_definition["source"]["protocol"]["clientId"] = creds["clientId"]

        transfer_definition["source"]["siteHostname"] = creds["sharepointHost"]
        transfer_definition["source"]["siteName"] = creds["sharepointSite"]

        # Set cacheable variable to the right filename path
        transfer_definition["source"]["cacheableVariables"][0]["cacheArgs"][
            "file"
        ] = f"{creds['rootDir']}/refresh_token.txt"

    if (
        transfer_definition["destination"]
        and transfer_definition["destination"][0]["protocol"]["name"]
        == "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer"
    ):
        transfer_definition["destination"][0]["protocol"]["refreshToken"] = creds[
            "refreshToken"
        ]
        transfer_definition["destination"][0]["protocol"]["tenantId"] = creds[
            "tenantId"
        ]
        transfer_definition["destination"][0]["protocol"]["clientId"] = creds[
            "clientId"
        ]

        transfer_definition["destination"][0]["siteHostname"] = creds["sharepointHost"]
        transfer_definition["destination"][0]["siteName"] = creds["sharepointSite"]

        # Set cacheable variable to the right filename path
        transfer_definition["destination"][0]["cacheableVariables"][0]["cacheArgs"][
            "file"
        ] = f"{creds['rootDir']}/refresh_token.txt"

    return transfer_definition


def test_sharepoint_filewatch_root(tmpdir, o365_creds):

    # Load variables from the environment

    sharepoint_filewatch_task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_filewatch_task_definition_source),
        "destination": [deepcopy(local_destination_definition)],
    }

    sharepoint_filewatch_task_definition = setup_creds_for_transfer(
        sharepoint_filewatch_task_definition, o365_creds
    )

    # Set the directory to the top level
    sharepoint_filewatch_task_definition["source"]["directory"] = ""
    # Set the destination directory to the temp directory
    sharepoint_filewatch_task_definition["destination"][0]["directory"] = tmpdir.strpath

    transfer_obj = transfer.Transfer(
        None, "sharepoint_filewatch", sharepoint_filewatch_task_definition
    )

    assert transfer_obj.run()


def test_sharepoint_filewatch_sub_dir(tmpdir, o365_creds):

    # Load variables from the environment

    sharepoint_filewatch_task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_filewatch_task_definition_source),
        "destination": [deepcopy(local_destination_definition)],
    }

    sharepoint_filewatch_task_definition = setup_creds_for_transfer(
        sharepoint_filewatch_task_definition, o365_creds
    )

    # Set the directory to the src sub directory
    sharepoint_filewatch_task_definition["source"]["directory"] = o365_creds[
        "source_folder"
    ]
    # Set the destination directory to the temp directory
    sharepoint_filewatch_task_definition["destination"][0]["directory"] = tmpdir.strpath

    transfer_obj = transfer.Transfer(
        None, "sharepoint_filewatch", sharepoint_filewatch_task_definition
    )

    assert transfer_obj.run()


def test_local_to_sharepoint_transfer(tmpdir, o365_creds):

    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^test.txt$"

    # Create a file in the tmpdir
    with open(f"{tmpdir}/test.txt", "w") as f:
        f.write("test")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)

    assert transfer_obj.run()


def test_local_to_sharepoint_with_file_rename(tmpdir, o365_creds):

    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^test.txt$"

    random = randint(1000, 9999)

    # Set the directory to the temp directory
    task_definition["destination"][0]["rename"] = {
        "pattern": "\\.txt$",
        "sub": f".{random}",
    }

    # Create a file in the tmpdir
    with open(f"{tmpdir}/test.txt", "w") as f:
        f.write("test")

    transfer_obj = transfer.Transfer(
        None, "local-to-sharepoint-rename", task_definition
    )

    assert transfer_obj.run()

    # Make sure that the file was renamed on Sharepoint
    # Call the transfer obj again and use list files to get the files, we need to change the spec
    # to point the source at the destination directory
    transfer_obj = transfer.Transfer(None, "sharepoint-list-files", task_definition)

    transfer_obj._set_remote_handlers()

    files = transfer_obj.dest_remote_handlers[0].list_files(
        task_definition["destination"][0]["directory"]
    )
    # Loop through files and assert that the file we expect is there and has been renamed
    for file in files:
        if file == f"test.{random}":
            break

    assert file == f"test.{random}"


def test_local_to_sharepoint_transfer_document_library(tmpdir, o365_creds):

    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^test.txt$"

    task_definition["destination"][0][
        "directory"
    ] = f"/{o365_creds['document_library']}/Dev/dest"

    # Create a file in the tmpdir
    with open(f"{tmpdir}/test.txt", "w") as f:
        f.write("test")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)

    assert transfer_obj.run()


def test_local_to_sharepoint_transfer_large_file(tmpdir, o365_creds):

    # Generate a random filename
    random = randint(1000, 9999)

    # Create a large file
    large_file_path = f"{tmpdir}/{random}.bin"
    with open(large_file_path, "wb") as f:
        f.write(os.urandom(110 * 1024 * 1024))  # 110 MB of random data

    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = f"^{random}.bin$"

    task_definition["destination"][0]["directory"] = f"Dev/dest/{random}/{random}"

    transfer_obj = transfer.Transfer(
        None, "local-to-sharepoint-copy-large-file", task_definition
    )

    assert transfer_obj.run()

    # Now attempt to upload the same file again, this should use different logic, but still work
    assert transfer_obj.run()


def test_local_to_sharepoint_transfer_large_file_document_library(tmpdir, o365_creds):

    # Generate a random filename
    random = randint(1000, 9999)

    # Create a large file
    large_file_path = f"{tmpdir}/{random}.bin"
    with open(large_file_path, "wb") as f:
        f.write(os.urandom(110 * 1024 * 1024))  # 110 MB of random data

    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = f"^{random}.bin$"

    task_definition["destination"][0][
        "directory"
    ] = f"/{o365_creds['document_library']}/Dev/dest/{random}/{random}"

    transfer_obj = transfer.Transfer(
        None, "local-to-sharepoint-copy-large-file", task_definition
    )

    assert transfer_obj.run()

    # Now attempt to upload the same file again, this should use different logic, but still work
    assert transfer_obj.run()


def test_sharepoint_pca_move_recursive(tmpdir, o365_creds):
    # Upload file first to ensure present before we move
    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^pca_move_recursive4.txt$"
    task_definition["destination"][0]["directory"] = o365_creds["source_folder"]

    # Create a file in the tmpdir
    with open(f"{tmpdir}/pca_move_recursive4.txt", "w") as f:
        f.write("pca_move_recursive")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)
    transfer_obj.run()

    # Then attempt transfer with sharepoint source with PCA move
    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_source_definition_dest),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    # Set the PCA with move
    task_definition["source"]["directory"] = o365_creds["source_folder"]
    task_definition["source"]["fileRegex"] = "^pca_move_recursive4.txt$"
    task_definition["source"]["postCopyAction"] = {
        "action": "move",
        "destination": (
            o365_creds["source_folder"] + "/pca_move_recursive4/testing_7/testing_8"
        ),
    }
    transfer_obj = transfer.Transfer(None, "sharepoint-to-local-copy", task_definition)

    assert transfer_obj.run()


def test_transfer_refresh_token_update(tmpdir, o365_creds):

    # Load variables from the environment

    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_filewatch_task_definition_source),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    transfer_obj = transfer.Transfer(None, "sharepoint_filewatch", task_definition)

    transfer_obj.run()

    # Check that the refresh_token.txt file has been updated and has something different
    # to before
    with open(f"{o365_creds['rootDir']}/refresh_token.txt", "r") as f:
        new_refresh_token = f.read()

    assert new_refresh_token != o365_creds["refreshToken"]


def test_sharepoint_to_local_transfer(tmpdir, o365_creds):

    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_source_definition),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    transfer_obj = transfer.Transfer(None, "sharepoint-to-local-copy", task_definition)

    assert transfer_obj.run()


def test_sharepoint_pca_delete(tmpdir, o365_creds):
    # Upload file first to ensure present before we delete
    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^pca_delete.txt$"
    task_definition["destination"][0]["directory"] = (
        o365_creds["source_folder"] + "/pca_delete"
    )

    # Create a file in the tmpdir
    with open(f"{tmpdir}/pca_delete.txt", "w") as f:
        f.write("pca_delete")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)
    transfer_obj.run()

    # Then attempt transfer with sharepoint source with PCA delete
    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_source_definition),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    # Set the PCA with delete
    task_definition["source"]["directory"] = o365_creds["source_folder"] + "/pca_delete"
    task_definition["source"]["fileRegex"] = "^pca_delete.txt$"
    task_definition["source"]["postCopyAction"] = {
        "action": "delete",
    }
    transfer_obj = transfer.Transfer(None, "sharepoint-to-local-copy", task_definition)

    assert transfer_obj.run()


def test_sharepoint_pca_move(tmpdir, o365_creds):
    # Upload file first to ensure present before we move
    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^pca_move.txt$"
    task_definition["destination"][0]["directory"] = (
        o365_creds["source_folder"] + "/pca_move"
    )

    # Create a file in the tmpdir
    with open(f"{tmpdir}/pca_move.txt", "w") as f:
        f.write("pca_move")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)
    transfer_obj.run()

    # Then attempt transfer with sharepoint source with PCA move
    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_source_definition),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    # Set the PCA with move
    task_definition["source"]["directory"] = o365_creds["source_folder"] + "/pca_move"
    task_definition["source"]["fileRegex"] = "^pca_move.txt$"
    task_definition["source"]["postCopyAction"] = {
        "action": "move",
        "destination": o365_creds["source_folder"] + "/pca_move/archive2",
    }
    transfer_obj = transfer.Transfer(None, "sharepoint-to-local-copy", task_definition)

    assert transfer_obj.run()


def test_sharepoint_pca_rename(tmpdir, o365_creds):
    # Upload file first to ensure present before we rename
    task_definition = {
        "type": "transfer",
        "source": deepcopy(local_source_definition),
        "destination": [deepcopy(sharepoint_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the directory to the temp directory
    task_definition["source"]["directory"] = tmpdir
    task_definition["source"]["fileRegex"] = "^pca_rename.txt$"
    task_definition["destination"][0]["directory"] = (
        o365_creds["source_folder"] + "/pca_rename"
    )

    # Create a file in the tmpdir
    with open(f"{tmpdir}/pca_rename.txt", "w") as f:
        f.write("pca_rename")

    transfer_obj = transfer.Transfer(None, "local-to-sharepoint-copy", task_definition)
    transfer_obj.run()

    # Then attempt transfer with sharepoint source with PCA rename
    task_definition = {
        "type": "transfer",
        "source": deepcopy(sharepoint_source_definition),
        "destination": [deepcopy(local_destination_definition)],
    }

    task_definition = setup_creds_for_transfer(task_definition, o365_creds)

    # Set the destination directory to the temp directory
    task_definition["destination"][0]["directory"] = tmpdir.strpath

    # Set the PCA with rename
    task_definition["source"]["directory"] = o365_creds["source_folder"] + "/pca_rename"
    task_definition["source"]["fileRegex"] = "^pca_rename.txt$"
    task_definition["source"]["postCopyAction"] = {
        "action": "rename",
        "destination": o365_creds["source_folder"] + "/pca_rename/archive",
        "pattern": "rename",
        "sub": "renamed",
    }
    transfer_obj = transfer.Transfer(None, "sharepoint-to-local-copy", task_definition)

    assert transfer_obj.run()


def test_sharepoint_list_files_uses_protocol_timeout_value():
    task_definition = {
        "type": "transfer",
        "source": {
            "siteHostname": "example.sharepoint.com",
            "siteName": "example-site",
            "directory": "",
            "fileRegex": "^does-not-match$",
            "protocol": {
                "name": (
                    "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer"
                ),
                "refreshToken": "initial-refresh-token",
                "clientId": "client-id",
                "tenantId": "tenant-id",
                "timeout": 42,
            },
        },
        "destination": [deepcopy(local_destination_definition)],
    }

    site_lookup_response = MagicMock()
    site_lookup_response.json.return_value = {"id": "site-id"}

    list_response = MagicMock()
    list_response.json.return_value = {"value": []}

    with (
        patch(
            "opentaskpy.addons.o365.remotehandlers.sharepoint.get_access_token",
            return_value={
                "access_token": "access-token",
                "refresh_token": "new-refresh-token",
                "expiry": 4102444800,
            },
        ),
        patch(
            "opentaskpy.addons.o365.remotehandlers.sharepoint.requests.get",
            side_effect=[site_lookup_response, list_response],
        ) as mocked_get,
    ):
        transfer_obj = transfer.Transfer(
            None, "sharepoint-timeout-test", task_definition
        )
        transfer_obj._set_remote_handlers()

        files = transfer_obj.source_remote_handler.list_files()

    assert files == {}
    assert mocked_get.call_count == 2
    assert mocked_get.call_args_list[0].kwargs["timeout"] == 42
    assert mocked_get.call_args_list[1].kwargs["timeout"] == 42


def test_sharepoint_request_retries_on_get_timeout(caplog):
    task_definition = {
        "type": "transfer",
        "source": {
            "siteHostname": "example.sharepoint.com",
            "siteName": "example-site",
            "directory": "",
            "fileRegex": "^does-not-match$",
            "protocol": {
                "name": (
                    "opentaskpy.addons.o365.remotehandlers.sharepoint.SharepointTransfer"
                ),
                "refreshToken": "initial-refresh-token",
                "clientId": "client-id",
                "tenantId": "tenant-id",
                "timeout": 1,
            },
        },
        "destination": [deepcopy(local_destination_definition)],
    }

    init_response = MagicMock()
    init_response.json.return_value = {"id": "site-id"}

    retry_success_response = MagicMock()
    retry_success_response.status_code = 200

    with (
        patch(
            "opentaskpy.addons.o365.remotehandlers.sharepoint.get_access_token",
            return_value={
                "access_token": "access-token",
                "refresh_token": "new-refresh-token",
                "expiry": 4102444800,
            },
        ),
        patch(
            "opentaskpy.addons.o365.remotehandlers.sharepoint.requests.get",
            side_effect=[
                init_response,
                requests.exceptions.ReadTimeout("timeout"),
                requests.exceptions.ReadTimeout("timeout-again"),
                requests.exceptions.ReadTimeout("timeout-again-2"),
                retry_success_response,
            ],
        ) as mocked_get,
        patch("tenacity.nap.sleep", return_value=None),
    ):
        transfer_obj = transfer.Transfer(None, "sharepoint-retry-test", task_definition)
        transfer_obj._set_remote_handlers()

        result = transfer_obj.source_remote_handler._request(
            "GET", "https://example.test/resource", timeout=1
        )

    assert result is retry_success_response
    assert mocked_get.call_count == 5
    assert "retrying attempt 2" in caplog.text.lower()
    assert "retrying attempt 3" in caplog.text.lower()
    assert "retrying attempt 4" in caplog.text.lower()
    assert "traceback" in caplog.text.lower()
