# gildaraio

Placeholder package reserving the `gildaraio` namespace on PyPI.

Real release is in development. Visit https://gildara.io for status.

Contact: accounts@gildara.io
