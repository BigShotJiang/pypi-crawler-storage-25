"""Utilitários adicionais (rateio de valores entre itens).

Porta direta do ``BrasilNFeHelper`` do SDK Node, útil para distribuir valores
(frete, desconto, seguro) proporcionalmente entre itens de uma nota fiscal.
"""
from __future__ import annotations

from enum import IntEnum
from typing import Callable, List, TypeVar

T = TypeVar("T")


class TipoRateio(IntEnum):
    """Estratégia a aplicar ao distribuir o valor entre os itens."""
    SUBSTITUIR = 0
    SOMAR = 1
    SUBTRAIR = 2


class BrasilNFeHelper:
    """Funções utilitárias estáticas."""

    @staticmethod
    def ratear(
        itens: List[T],
        valor_total: float,
        seletor: Callable[[T], float],
        seletor_proporcao: Callable[[T], float],
        tipo_rateio: TipoRateio,
        atualizar_item: Callable[[T, float], None],
    ) -> None:
        """Distribui ``valor_total`` entre ``itens`` proporcional a ``seletor_proporcao``.

        A diferença de arredondamento é acumulada e aplicada ao último item,
        garantindo que a soma final bata exatamente com ``valor_total``.

        Args:
            itens: lista de objetos a serem rateados.
            valor_total: valor a distribuir.
            seletor: devolve o valor atual do item (usado em SOMAR/SUBTRAIR).
            seletor_proporcao: devolve a base usada para o percentual (ex.: valor total do produto).
            tipo_rateio: :class:`TipoRateio`.
            atualizar_item: callback que aplica o novo valor no item.
        """
        if not itens:
            return

        soma_proporcao = sum(seletor_proporcao(item) for item in itens)
        if soma_proporcao <= 0:
            return

        acumulado = 0.0
        ultimo_indice = len(itens) - 1

        for i, item in enumerate(itens):
            if i == ultimo_indice:
                parcela = round(valor_total - acumulado, 6)
            else:
                proporcao = seletor_proporcao(item) / soma_proporcao
                parcela = round(valor_total * proporcao, 6)
                acumulado += parcela

            atual = seletor(item)
            if tipo_rateio == TipoRateio.SUBSTITUIR:
                novo = parcela
            elif tipo_rateio == TipoRateio.SOMAR:
                novo = round(atual + parcela, 6)
            elif tipo_rateio == TipoRateio.SUBTRAIR:
                novo = round(atual - parcela, 6)
            else:
                novo = parcela
            atualizar_item(item, novo)


__all__ = ["BrasilNFeHelper", "TipoRateio"]
