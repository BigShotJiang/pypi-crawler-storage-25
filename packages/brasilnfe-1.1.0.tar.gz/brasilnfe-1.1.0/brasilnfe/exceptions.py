"""
Exceções do SDK Brasil NFe.

Hierarquia:

    BrasilNFeError (base)
    ├── BrasilNFeRequestError      (falhas HTTP / rede / timeout)
    ├── BrasilNFeResponseError     (resposta HTTP fora da faixa 2xx)
    ├── BrasilNFeSerializationError (erro ao serializar/desserializar JSON)
    ├── BrasilNFeAuthenticationError (Token/UserToken ausente ou inválido)
    └── BrasilNFeValidationError   (validação de DTO antes do envio)
"""
from __future__ import annotations

from typing import Any, Optional


class BrasilNFeError(Exception):
    """Exceção base de todo o SDK Brasil NFe."""


class BrasilNFeRequestError(BrasilNFeError):
    """Erro ao efetuar requisição HTTPS com a API Brasil NFe."""

    def __init__(
        self,
        message: str,
        *,
        original: Optional[BaseException] = None,
    ) -> None:
        super().__init__(message)
        self.original = original


class BrasilNFeResponseError(BrasilNFeError):
    """Resposta HTTP inválida (status fora de 2xx)."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class BrasilNFeSerializationError(BrasilNFeError):
    """Falha ao serializar payload de envio ou desserializar resposta."""


class BrasilNFeAuthenticationError(BrasilNFeError):
    """Tokens de autenticação ausentes ou inválidos."""


class BrasilNFeValidationError(BrasilNFeError):
    """Erro de validação do payload antes do envio ao servidor."""
