"""SDK oficial Brasil NFe para Python.

Exemplo rápido:

    >>> from brasilnfe import BrasilNFe, StatusSefazEnvio
    >>> client = BrasilNFe(token="SEU_TOKEN")
    >>> resp = client.consultas.status_sefaz(
    ...     StatusSefazEnvio(modelo_documento=55, tipo_ambiente=2)
    ... )
    >>> print(resp.status_sefaz.ds_status_resposta_sefaz)
"""
from brasilnfe.client import BrasilNFe
from brasilnfe.exceptions import (
    BrasilNFeAuthenticationError,
    BrasilNFeError,
    BrasilNFeRequestError,
    BrasilNFeResponseError,
    BrasilNFeSerializationError,
    BrasilNFeValidationError,
)
from brasilnfe.helper import BrasilNFeHelper, TipoRateio
from brasilnfe.methods import Arquivos, Consultas, Empresa, Eventos, NotaFiscal
from brasilnfe.models import *  # noqa: F403  — reexporta todos os DTOs
from brasilnfe.models import __all__ as _models_all

__version__ = "1.1.0"

__all__ = [
    "BrasilNFe",
    "BrasilNFeAuthenticationError",
    "BrasilNFeError",
    "BrasilNFeHelper",
    "BrasilNFeRequestError",
    "BrasilNFeResponseError",
    "BrasilNFeSerializationError",
    "BrasilNFeValidationError",
    "TipoRateio",
    "Arquivos",
    "Consultas",
    "Empresa",
    "Eventos",
    "NotaFiscal",
    "__version__",
    *_models_all,
]
