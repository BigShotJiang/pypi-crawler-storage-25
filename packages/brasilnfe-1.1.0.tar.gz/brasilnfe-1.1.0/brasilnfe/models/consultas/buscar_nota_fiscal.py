"""Busca de notas fiscais por período."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class BuscarNotaFiscalEnvio(BrasilNFeModel):
    """Payload de busca de NF-e / NFC-e / CT-e.

    ``tipo_documento_fiscal``: 0 = Entradas, 1 = Saídas.
    """
    tipo_documento_fiscal: Optional[int] = field(default=None, metadata={"json": "TipoDocumentoFiscal"})
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IndentificadorInterno"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})


@dataclass
class BuscarNotaFiscalServicoEnvio(BrasilNFeModel):
    """Payload de busca de NFS-e."""
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IndentificadorInterno"})


@dataclass
class DocumentoFiscalResumo(BrasilNFeModel):
    """Resumo de um documento retornado pela busca."""
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
    ds_status: Optional[str] = field(default=None, metadata={"json": "DsStatus"})


@dataclass
class BuscarNotaFiscalRetorno(Erros):
    """Retorno da busca de notas fiscais."""
    documentos: List[DocumentoFiscalResumo] = field(default_factory=list, metadata={"json": "Documentos"})
