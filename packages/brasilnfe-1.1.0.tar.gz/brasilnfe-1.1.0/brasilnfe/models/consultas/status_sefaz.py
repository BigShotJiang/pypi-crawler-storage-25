"""Status de disponibilidade da SEFAZ."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class StatusSefazEnvio(BrasilNFeModel):
    """Payload de consulta de status.

    ``modelo_documento``: 55 = NF-e, 57 = CT-e, 65 = NFC-e, 58 = MDF-e.
    ``tipo_ambiente``: 1 = Produção, 2 = Homologação.
    """
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})


@dataclass
class StatusSefazInfo(BrasilNFeModel):
    """Informações de status retornadas pela SEFAZ."""
    versao: Optional[str] = field(default=None, metadata={"json": "Versao"})
    cod_tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "CodTipoAmbiente"})
    ds_tipo_ambiente: Optional[str] = field(default=None, metadata={"json": "DsTipoAmbiente"})
    cod_status_resposta_sefaz: Optional[int] = field(default=None, metadata={"json": "CodStatusRespostaSefaz"})
    ds_status_resposta_sefaz: Optional[str] = field(default=None, metadata={"json": "DsStatusRespostaSefaz"})
    cod_estado_emitente: Optional[int] = field(default=None, metadata={"json": "CodEstadoEmitente"})
    ds_estado_emitente: Optional[str] = field(default=None, metadata={"json": "DsEstadoEmitente"})


@dataclass
class StatusSefazRetorno(Erros):
    """Retorno da consulta de status da SEFAZ."""
    status_sefaz: Optional[StatusSefazInfo] = field(default=None, metadata={"json": "StatusSefaz"})
