"""Consulta de cadastro na SEFAZ (IE/CNPJ/CPF)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros import Pessoa


@dataclass
class ConsultarCadastroEnvio(BrasilNFeModel):
    """Payload de consulta de cadastro."""
    cpf_cnpj_ie: Optional[str] = field(default=None, metadata={"json": "cpfCnpjIe"})
    uf: Optional[str] = field(default=None, metadata={"json": "uf"})


@dataclass
class ConsultarCadastroRetorno(Pessoa):
    """Resposta da consulta cadastral na SEFAZ."""
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "cpfCnpj"})
    ie: Optional[str] = field(default=None, metadata={"json": "ie"})
    ie_unica: Optional[str] = field(default=None, metadata={"json": "ieUnica"})
    ie_atual: Optional[str] = field(default=None, metadata={"json": "ieAtual"})
    razao_social: Optional[str] = field(default=None, metadata={"json": "razaoSocial"})
    nome_fantasia: Optional[str] = field(default=None, metadata={"json": "nomeFantasia"})
    regime_apuracao: Optional[str] = field(default=None, metadata={"json": "regimeApuracao"})
    cnae_principal: Optional[str] = field(default=None, metadata={"json": "cnaePrincipal"})
    data_inicio_atividade: Optional[datetime] = field(default=None, metadata={"json": "dataInicioAtividade"})
    data_ultima_alteracao_cadastral: Optional[datetime] = field(default=None, metadata={"json": "dataUltimaAlteracaoCadastral"})
    data_ocorrencia_baixa: Optional[datetime] = field(default=None, metadata={"json": "dataOcorrenciaBaixa"})
    uf_consultada: Optional[str] = field(default=None, metadata={"json": "ufConsultada"})
    situacao: Optional[int] = field(default=None, metadata={"json": "situacao"})
    indicador_credenciamento_nfe: Optional[int] = field(default=None, metadata={"json": "indicadorCredenciamentoNFe"})
    indicador_credenciamento_cte: Optional[int] = field(default=None, metadata={"json": "indicadorCredenciamentoCTe"})
    status: Optional[int] = field(default=None, metadata={"json": "status"})
    error: Optional[str] = field(default=None, metadata={"json": "Error"})
