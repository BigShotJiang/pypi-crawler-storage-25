"""Cálculo automático de impostos."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class ImpostosCalculados(BrasilNFeModel):
    """Totais por tipo de tributo."""
    base_calculo_icms: Optional[float] = field(default=None, metadata={"json": "BaseCalculoICMS"})
    base_calculo_icms_st: Optional[float] = field(default=None, metadata={"json": "BaseCalculoICMSST"})
    valor_icms: Optional[float] = field(default=None, metadata={"json": "ValorICMS"})
    valor_icms_st: Optional[float] = field(default=None, metadata={"json": "ValorICMSST"})
    valor_icms_desoneracao: Optional[float] = field(default=None, metadata={"json": "ValorICMSDesoneracao"})
    valor_ipi: Optional[float] = field(default=None, metadata={"json": "ValorIPI"})
    valor_pis: Optional[float] = field(default=None, metadata={"json": "ValorPIS"})
    valor_cofins: Optional[float] = field(default=None, metadata={"json": "ValorCOFINS"})
    valor_fcp: Optional[float] = field(default=None, metadata={"json": "ValorFCP"})
    valor_fcp_st: Optional[float] = field(default=None, metadata={"json": "ValorFCPST"})
    valor_fcp_st_retido: Optional[float] = field(default=None, metadata={"json": "ValorFCPSTRetido"})
    valor_importacao: Optional[float] = field(default=None, metadata={"json": "ValorImportacao"})


@dataclass
class TotalCalculo(BrasilNFeModel):
    """Total geral da nota calculada."""
    valor_frete: Optional[float] = field(default=None, metadata={"json": "ValorFrete"})
    valor_desconto: Optional[float] = field(default=None, metadata={"json": "ValorDesconto"})
    valor_seguro: Optional[float] = field(default=None, metadata={"json": "ValorSeguro"})
    valor_despesas_acessorias: Optional[float] = field(default=None, metadata={"json": "ValorDespesasAcessorias"})
    valor_tributos_aproximados: Optional[float] = field(default=None, metadata={"json": "ValorTributosAproximados"})
    valor_produtos: Optional[float] = field(default=None, metadata={"json": "ValorProdutos"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})


@dataclass
class CalculoImpostosRetorno(Erros):
    """Retorno do cálculo de impostos."""
    impostos: Optional[ImpostosCalculados] = field(default=None, metadata={"json": "Impostos"})
    total: Optional[TotalCalculo] = field(default=None, metadata={"json": "Total"})
