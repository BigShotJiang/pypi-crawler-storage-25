"""Cadastro e edição de empresas."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from brasilnfe.models.outros import Pessoa
from brasilnfe.models.outros.erros import Erros


@dataclass
class EmpresaEnvio(Pessoa):
    """Payload de cadastro ou edição de empresa.

    ``crt``: 1=Simples Nacional, 2=Simples c/ Sublimite, 3=Regime Normal, 4=MEI.
    """
    cnpj: Optional[str] = field(default=None, metadata={"json": "CNPJ"})
    nm_fantasia: Optional[str] = field(default=None, metadata={"json": "NmFantasia"})
    rz_social: Optional[str] = field(default=None, metadata={"json": "RzSocial"})
    tipo_empresa: Optional[int] = field(default=None, metadata={"json": "TipoEmpresa"})
    ie: Optional[str] = field(default=None, metadata={"json": "IE"})
    im: Optional[str] = field(default=None, metadata={"json": "IM"})
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    cnae: Optional[str] = field(default=None, metadata={"json": "CNAE"})
    identificador_csc: Optional[str] = field(default=None, metadata={"json": "IdentificadorCSC"})
    codigo_csc: Optional[str] = field(default=None, metadata={"json": "CodigoCSC"})
    token: Optional[str] = field(default=None, metadata={"json": "Token"})
    site: Optional[str] = field(default=None, metadata={"json": "Site"})
    cod_grupo: Optional[int] = field(default=None, metadata={"json": "CodGrupo"})
    configuracao: Optional[Any] = field(default=None, metadata={"json": "Configuracao"})


@dataclass
class EmpresaRetorno(Erros):
    """Retorno de operações de empresa."""
    cnpj: Optional[str] = field(default=None, metadata={"json": "CNPJ"})
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
    mensagem: Optional[str] = field(default=None, metadata={"json": "Mensagem"})
