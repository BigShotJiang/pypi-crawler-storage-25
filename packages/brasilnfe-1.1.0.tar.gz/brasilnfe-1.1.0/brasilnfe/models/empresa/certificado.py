"""Gestão de certificado digital A1."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class CertificadoEnvio(BrasilNFeModel):
    """Payload para alterar ou verificar um certificado A1 (.pfx).

    ``base64_certificate_file`` deve conter o arquivo .pfx codificado em base64.
    """
    senha: Optional[str] = field(default=None, metadata={"json": "Senha"})
    base64_certificate_file: Optional[str] = field(default=None, metadata={"json": "Base64CertificateFile"})
    interno: Optional[bool] = field(default=None, metadata={"json": "Interno"})


@dataclass
class CertificadoRetorno(Erros):
    """Informações de validade e titular do certificado."""
    cn: Optional[str] = field(default=None, metadata={"json": "CN"})
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    validade: Optional[datetime] = field(default=None, metadata={"json": "Validade"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    emissor: Optional[str] = field(default=None, metadata={"json": "Emissor"})
    valido: Optional[bool] = field(default=None, metadata={"json": "Valido"})
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
