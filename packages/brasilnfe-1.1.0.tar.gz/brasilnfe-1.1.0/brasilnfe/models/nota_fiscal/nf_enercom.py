"""NF-e de Energia / Comunicação (NF3-e / NFCom / EnerCom)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros import Pessoa
from brasilnfe.models.outros.erros import NewError


@dataclass
class NFEnerComEnvio(BrasilNFeModel):
    """Payload de emissão de NF3-e / NFCom (energia e comunicação)."""
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    consumidor: Optional[Pessoa] = field(default=None, metadata={"json": "Consumidor"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    itens: List[dict] = field(default_factory=list, metadata={"json": "Itens"})
    observacao: Optional[str] = field(default=None, metadata={"json": "Observacao"})


@dataclass
class NFEnerComRetorno(NewError):
    """Retorno da emissão de NF3-e / NFCom."""
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})


@dataclass
class ArqEnerComEnvio(BrasilNFeModel):
    """Solicitação de arquivo consolidado de energia/comunicação."""
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})


@dataclass
class ArqEnerComRetorno(NewError):
    """Retorno do arquivo consolidado de energia/comunicação."""
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    registros: Optional[str] = field(default=None, metadata={"json": "Registros"})
    url: Optional[str] = field(default=None, metadata={"json": "Url"})
