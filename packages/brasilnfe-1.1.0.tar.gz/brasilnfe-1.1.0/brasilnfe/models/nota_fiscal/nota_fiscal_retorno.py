"""Retornos das emissões de NF-e / NFC-e."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class DetalhesNF(BrasilNFeModel):
    """Totalizadores da nota (ICMS, IPI, PIS, COFINS)."""
    valor_nf: Optional[float] = field(default=None, metadata={"json": "valorNf"})
    valor_icms: Optional[float] = field(default=None, metadata={"json": "valorIcms"})
    valor_ipi: Optional[float] = field(default=None, metadata={"json": "valorIpi"})
    valor_pis: Optional[float] = field(default=None, metadata={"json": "valorPis"})
    valor_cofins: Optional[float] = field(default=None, metadata={"json": "valorCofins"})


@dataclass
class ReturnNF(BrasilNFeModel):
    """Dados retornados pela SEFAZ sobre a nota emitida."""
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    chave_nf: Optional[str] = field(default=None, metadata={"json": "ChaveNF"})
    cod_tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "CodTipoAmbiente"})
    ds_tipo_ambiente: Optional[str] = field(default=None, metadata={"json": "DsTipoAmbiente"})
    cod_status_resposta_sefaz: Optional[int] = field(default=None, metadata={"json": "CodStatusRespostaSefaz"})
    ds_status_resposta_sefaz: Optional[str] = field(default=None, metadata={"json": "DsStatusRespostaSefaz"})
    ok: Optional[bool] = field(default=None, metadata={"json": "Ok"})
    detalhes: Optional[DetalhesNF] = field(default=None, metadata={"json": "Detalhes"})


@dataclass
class NotaFiscalRetorno(Erros):
    """Retorno da emissão de NF-e / NFC-e.

    ``base64_xml`` contém o XML assinado e autorizado (decodificar com
    :func:`base64.b64decode`). ``base64_file`` traz a DANFE em PDF.
    """
    return_nf: Optional[ReturnNF] = field(default=None, metadata={"json": "ReturnNF"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})


@dataclass
class NotaFiscalLoteRetorno(Erros):
    """Retorno de emissão em lote."""
    notas: List[NotaFiscalRetorno] = field(default_factory=list, metadata={"json": "Notas"})
