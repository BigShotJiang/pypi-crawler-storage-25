"""CT-e (Conhecimento de Transporte Eletrônico - modelo 57)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import NewError


@dataclass
class TomadorCTe(BrasilNFeModel):
    """Tomador do serviço de transporte.

    ``tipo_tomador``: 0=Remetente, 1=Expedidor, 2=Recebedor, 3=Destinatário, 4=Outros.
    """
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    nome_fantasia: Optional[str] = field(default=None, metadata={"json": "NomeFantasia"})
    ie: Optional[str] = field(default=None, metadata={"json": "Ie"})
    indicador_ie: Optional[int] = field(default=None, metadata={"json": "IndicadorIe"})
    tipo_tomador: Optional[int] = field(default=None, metadata={"json": "TipoTomador"})


@dataclass
class ComponenteValor(BrasilNFeModel):
    """Componente que compõe o valor da prestação."""
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})


@dataclass
class ServicoCTe(BrasilNFeModel):
    """Serviço de transporte prestado.

    ``tipo``: 0=Normal, 1=Subcontratação, 2=Redespacho, 3=Redespacho Intermediário,
    4=Multimodal, 6=Pessoas, 7=Valores, 8=Excesso Bagagem.
    """
    tipo: Optional[int] = field(default=None, metadata={"json": "Tipo"})
    cod_municipio_inicio: Optional[int] = field(default=None, metadata={"json": "CodMunicipioInicio"})
    municipio_inicio: Optional[str] = field(default=None, metadata={"json": "MunicipioInicio"})
    uf_inicio: Optional[str] = field(default=None, metadata={"json": "UfInicio"})
    cod_municipio_fim: Optional[int] = field(default=None, metadata={"json": "CodMunicipioFim"})
    municipio_fim: Optional[str] = field(default=None, metadata={"json": "MunicipioFim"})
    uf_fim: Optional[str] = field(default=None, metadata={"json": "UfFim"})
    valor_prestacao: Optional[float] = field(default=None, metadata={"json": "ValorPrestacao"})
    valor_receber: Optional[float] = field(default=None, metadata={"json": "ValorReceber"})
    componentes: List[ComponenteValor] = field(default_factory=list, metadata={"json": "Componentes"})


@dataclass
class DocumentoCarga(BrasilNFeModel):
    """Documento transportado pela carga (NF-e vinculada)."""
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    pin: Optional[str] = field(default=None, metadata={"json": "PIN"})


@dataclass
class DetalheCarga(BrasilNFeModel):
    """Detalhe de peso/quantidade da carga."""
    tipo_medida: Optional[str] = field(default=None, metadata={"json": "TipoMedida"})
    quantidade: Optional[float] = field(default=None, metadata={"json": "Quantidade"})
    unidade: Optional[str] = field(default=None, metadata={"json": "Unidade"})


@dataclass
class CargaCTe(BrasilNFeModel):
    """Informações da carga transportada."""
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    produto_predominante: Optional[str] = field(default=None, metadata={"json": "ProdutoPredominante"})
    detalhes: List[DetalheCarga] = field(default_factory=list, metadata={"json": "Detalhes"})
    documentos: List[DocumentoCarga] = field(default_factory=list, metadata={"json": "Documentos"})


@dataclass
class CTeEnvio(BrasilNFeModel):
    """Payload de emissão de CT-e (modelo 57)."""
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    modelo: Optional[int] = field(default=57, metadata={"json": "Modelo"})
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IdentificadorInterno"})
    natureza_operacao: Optional[str] = field(default=None, metadata={"json": "NaturezaOperacao"})
    tomador: Optional[TomadorCTe] = field(default=None, metadata={"json": "Tomador"})
    servico: Optional[ServicoCTe] = field(default=None, metadata={"json": "Servico"})
    carga: Optional[CargaCTe] = field(default=None, metadata={"json": "Carga"})
    observacao: Optional[str] = field(default=None, metadata={"json": "Observacao"})


@dataclass
class CTeRetorno(NewError):
    """Retorno da emissão de CT-e (usa formato ``NewError``)."""
    chave_cte: Optional[str] = field(default=None, metadata={"json": "ChaveCTe"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
