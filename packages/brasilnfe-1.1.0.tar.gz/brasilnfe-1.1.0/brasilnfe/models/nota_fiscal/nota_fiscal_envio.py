"""Modelos de envio de NF-e (modelo 55) e NFC-e (modelo 65)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros import Pessoa, Produto


@dataclass
class Cliente(Pessoa):
    """Destinatário da nota fiscal."""
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    nm_cliente: Optional[str] = field(default=None, metadata={"json": "NmCliente"})
    indicador_ie: Optional[int] = field(default=None, metadata={"json": "IndicadorIe"})
    ie: Optional[str] = field(default=None, metadata={"json": "Ie"})
    is_uf: Optional[str] = field(default=None, metadata={"json": "IsUf"})


@dataclass
class Pagamento(BrasilNFeModel):
    """Forma de pagamento da nota fiscal."""
    indicador_pagamento: Optional[int] = field(default=None, metadata={"json": "IndicadorPagamento"})
    desconto: Optional[float] = field(default=None, metadata={"json": "Desconto"})
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})
    forma_pagamento: Optional[str] = field(default=None, metadata={"json": "FormaPagamento"})
    vl_pago: Optional[float] = field(default=None, metadata={"json": "VlPago"})
    vl_troco: Optional[float] = field(default=None, metadata={"json": "VlTroco"})
    tipo_integracao: Optional[bool] = field(default=None, metadata={"json": "TipoIntegracao"})
    cnpj_credenciadora: Optional[str] = field(default=None, metadata={"json": "CNPJCredenciadora"})
    bandeira_operadora: Optional[str] = field(default=None, metadata={"json": "BandeiraOperadora"})
    numero_autorizacao: Optional[str] = field(default=None, metadata={"json": "NumeroAutorizacao"})


@dataclass
class Parcela(BrasilNFeModel):
    """Parcela de pagamento (cobrança)."""
    vencimento: Optional[datetime] = field(default=None, metadata={"json": "Vencimento"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})


@dataclass
class Fatura(BrasilNFeModel):
    """Fatura da cobrança."""
    numero: Optional[str] = field(default=None, metadata={"json": "Numero"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})
    desconto: Optional[float] = field(default=None, metadata={"json": "Desconto"})
    valor_liquido: Optional[float] = field(default=None, metadata={"json": "ValorLiquido"})


@dataclass
class Cobranca(BrasilNFeModel):
    """Cobrança da nota fiscal (fatura + parcelas)."""
    fatura: Optional[Fatura] = field(default=None, metadata={"json": "Fatura"})
    parcelas: List[Parcela] = field(default_factory=list, metadata={"json": "Parcelas"})


@dataclass
class Veiculo(BrasilNFeModel):
    """Veículo de transporte."""
    placa: Optional[str] = field(default=None, metadata={"json": "Placa"})
    uf: Optional[str] = field(default=None, metadata={"json": "UF"})
    rntc: Optional[str] = field(default=None, metadata={"json": "RNTC"})


@dataclass
class Reboque(Veiculo):
    """Reboque do veículo de transporte."""


@dataclass
class Volume(BrasilNFeModel):
    """Volume transportado."""
    numero: Optional[str] = field(default=None, metadata={"json": "Numero"})
    quantidade_volume: Optional[int] = field(default=None, metadata={"json": "QuantidadeVolume"})
    especie: Optional[str] = field(default=None, metadata={"json": "Especie"})
    marca: Optional[str] = field(default=None, metadata={"json": "Marca"})
    peso_bruto: Optional[float] = field(default=None, metadata={"json": "PesoBruto"})
    peso_liquido: Optional[float] = field(default=None, metadata={"json": "PesoLiquido"})
    lacres: List[str] = field(default_factory=list, metadata={"json": "Lacres"})


@dataclass
class Transporte(BrasilNFeModel):
    """Informações de transporte da NF-e.

    ``modalidade_frete`` aceita: 0=Emitente, 1=Destinatário, 2=Terceiros,
    3=Próprio Remetente, 4=Próprio Destinatário, 9=Sem frete.
    """
    modalidade_frete: Optional[int] = field(default=None, metadata={"json": "ModalidadeFrete"})
    nm_transportador: Optional[str] = field(default=None, metadata={"json": "NmTransportador"})
    cnpj: Optional[str] = field(default=None, metadata={"json": "CNPJ"})
    nm_municipio: Optional[str] = field(default=None, metadata={"json": "NmMunicipio"})
    ds_endereco: Optional[str] = field(default=None, metadata={"json": "DsEndereco"})
    ie: Optional[str] = field(default=None, metadata={"json": "IE"})
    uf: Optional[str] = field(default=None, metadata={"json": "UF"})
    vagao: Optional[str] = field(default=None, metadata={"json": "Vagao"})
    balsa: Optional[str] = field(default=None, metadata={"json": "Balsa"})
    veiculo: Optional[Veiculo] = field(default=None, metadata={"json": "Veiculo"})
    reboque: List[Reboque] = field(default_factory=list, metadata={"json": "Reboque"})
    volume: Optional[Volume] = field(default=None, metadata={"json": "Volume"})
    volumes: List[Volume] = field(default_factory=list, metadata={"json": "Volumes"})


@dataclass
class Exporta(BrasilNFeModel):
    """Informações de exportação."""
    local_despacho: Optional[str] = field(default=None, metadata={"json": "LocalDespacho"})
    uf_saida_pais: Optional[str] = field(default=None, metadata={"json": "UFSaidaPais"})
    local_embarque_transp: Optional[str] = field(default=None, metadata={"json": "LocalEmbarqueTransp"})


@dataclass
class Entrega(Pessoa):
    """Endereço de entrega quando diferente do destinatário."""
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    ie: Optional[str] = field(default=None, metadata={"json": "Ie"})


@dataclass
class Retencoes(BrasilNFeModel):
    """Retenções federais aplicadas sobre a nota."""
    base_calculo_irrf: Optional[float] = field(default=None, metadata={"json": "BaseCalculoIRRF"})
    valor_irrf: Optional[float] = field(default=None, metadata={"json": "ValorIRRF"})
    valor_retido_pis: Optional[float] = field(default=None, metadata={"json": "ValorRetidoPIS"})
    valor_retido_cofins: Optional[float] = field(default=None, metadata={"json": "ValorRetidoCOFINS"})
    valor_retido_csll: Optional[float] = field(default=None, metadata={"json": "ValorRetidoCSLL"})
    base_calculo_retencao_previdencia: Optional[float] = field(default=None, metadata={"json": "BaseCalculoRetencaoPrevidencia"})
    valor_retencao_previdencia: Optional[float] = field(default=None, metadata={"json": "ValorRetencaoPrevidencia"})


@dataclass
class NotaFiscalEnvio(BrasilNFeModel):
    """Payload de emissão de NF-e (modelo 55) ou NFC-e (modelo 65).

    Campos principais:
        modelo_documento: 55 = NF-e, 65 = NFC-e.
        tipo_ambiente: 1 = Produção, 2 = Homologação.
        finalidade: 1 = Normal, 2 = Complementar, 3 = Ajuste, 4 = Devolução.
        indicador_presenca: 0..5 ou 9 (presencial, não presencial, etc).
    """
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    data_entrada_saida: Optional[datetime] = field(default=None, metadata={"json": "DataEntradaSaida"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    justificativa: Optional[str] = field(default=None, metadata={"json": "Justificativa"})
    nf_referencia: List[str] = field(default_factory=list, metadata={"json": "NFReferencia"})
    indicador_presenca: Optional[int] = field(default=None, metadata={"json": "IndicadorPresenca"})
    indicador_intermediador: Optional[bool] = field(default=None, metadata={"json": "IndicadorIntermediador"})
    consumidor_final: Optional[bool] = field(default=None, metadata={"json": "ConsumidorFinal"})
    calcular_ibpt: Optional[bool] = field(default=None, metadata={"json": "CalcularIBPT"})
    natureza_operacao: Optional[str] = field(default=None, metadata={"json": "NaturezaOperacao"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    finalidade: Optional[int] = field(default=None, metadata={"json": "Finalidade"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    observacao: Optional[str] = field(default=None, metadata={"json": "Observacao"})
    observacao_fisco: Optional[str] = field(default=None, metadata={"json": "ObservacaoFisco"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IdentificadorInterno"})
    enviar_email: Optional[bool] = field(default=None, metadata={"json": "EnviarEmail"})
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    cliente: Optional[Cliente] = field(default=None, metadata={"json": "Cliente"})
    produtos: List[Produto] = field(default_factory=list, metadata={"json": "Produtos"})
    pagamentos: List[Pagamento] = field(default_factory=list, metadata={"json": "Pagamentos"})
    cobranca: Optional[Cobranca] = field(default=None, metadata={"json": "Cobranca"})
    transporte: Optional[Transporte] = field(default=None, metadata={"json": "Transporte"})
    exporta: Optional[Exporta] = field(default=None, metadata={"json": "Exporta"})
    entrega: Optional[Entrega] = field(default=None, metadata={"json": "Entrega"})
    retencoes: Optional[Retencoes] = field(default=None, metadata={"json": "Retencoes"})


@dataclass
class NotaFiscalLoteEnvio(BrasilNFeModel):
    """Envio em lote de múltiplas notas fiscais."""
    notas_fiscais: List[NotaFiscalEnvio] = field(default_factory=list, metadata={"json": "NotasFiscais"})
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
