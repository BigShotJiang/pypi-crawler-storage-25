"""NFS-e (Nota Fiscal de Serviço Eletrônica)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros import Pessoa
from brasilnfe.models.outros.erros import Erros


@dataclass
class Tomador(Pessoa):
    """Pessoa que contratou o serviço."""
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    ie: Optional[str] = field(default=None, metadata={"json": "Ie"})
    indicador_ie: Optional[int] = field(default=None, metadata={"json": "IndicadorIe"})


@dataclass
class Intermediario(Pessoa):
    """Intermediário do serviço (quando aplicável)."""
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    ie: Optional[str] = field(default=None, metadata={"json": "Ie"})


@dataclass
class ConstrucaoCivil(BrasilNFeModel):
    """Informações adicionais para serviços de construção civil."""
    codigo_obra: Optional[str] = field(default=None, metadata={"json": "CodigoObra"})
    art: Optional[str] = field(default=None, metadata={"json": "Art"})


@dataclass
class Valores(BrasilNFeModel):
    """Valores monetários do serviço prestado."""
    valor_servico: Optional[float] = field(default=None, metadata={"json": "ValorServico"})
    valor_inss: Optional[float] = field(default=None, metadata={"json": "ValorInss"})
    aliquota: Optional[float] = field(default=None, metadata={"json": "Aliquota"})
    desconto_condicionado: Optional[float] = field(default=None, metadata={"json": "DescontoCondicionado"})
    desconto_incondicionado: Optional[float] = field(default=None, metadata={"json": "DescontoIncondicionado"})
    outras_retencoes: Optional[float] = field(default=None, metadata={"json": "OutrasRetencoes"})
    valor_deducoes: Optional[float] = field(default=None, metadata={"json": "ValorDeducoes"})
    total_tributos: Optional[float] = field(default=None, metadata={"json": "TotalTributos"})
    aliquota_ir: Optional[float] = field(default=None, metadata={"json": "AliquotaIr"})


@dataclass
class ConfiguracaoImposto(BrasilNFeModel):
    """Configuração de impostos federais sobre o serviço.

    Os campos ``incide_*`` aplicam o imposto apenas acima do limite de
    R$ 215,05. Os campos ``forcar_incidencia_*`` aplicam independente do valor.
    """
    incide_pis: Optional[bool] = field(default=None, metadata={"json": "IncidePis"})
    incide_cofins: Optional[bool] = field(default=None, metadata={"json": "IncideCofins"})
    incide_csll: Optional[bool] = field(default=None, metadata={"json": "IncideCsll"})
    incide_ir: Optional[bool] = field(default=None, metadata={"json": "IncideIr"})
    forcar_incidencia_pis: Optional[bool] = field(default=None, metadata={"json": "ForcarIncidenciaPis"})
    forcar_incidencia_cofins: Optional[bool] = field(default=None, metadata={"json": "ForcarIncidenciaCofins"})
    forcar_incidencia_csll: Optional[bool] = field(default=None, metadata={"json": "ForcarIncidenciaCsll"})
    forcar_incidencia_ir: Optional[bool] = field(default=None, metadata={"json": "ForcarIncidenciaIr"})


@dataclass
class Servico(BrasilNFeModel):
    """Descrição e valores do serviço prestado."""
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})
    item_lista_servico: Optional[str] = field(default=None, metadata={"json": "ItemListaServico"})
    regime_especial_tributacao: Optional[int] = field(default=None, metadata={"json": "RegimeEspecialTributacao"})
    valores: Optional[Valores] = field(default=None, metadata={"json": "Valores"})
    configuracao_imposto: Optional[ConfiguracaoImposto] = field(default=None, metadata={"json": "ConfiguracaoImposto"})


@dataclass
class NFSInfo(BrasilNFeModel):
    """Informação de uma NFS-e (RPS) dentro do envio."""
    enviar_email: Optional[bool] = field(default=None, metadata={"json": "EnviarEmail"})
    serie_rps: Optional[str] = field(default=None, metadata={"json": "SerieRps"})
    numero_rps: Optional[int] = field(default=None, metadata={"json": "NumeroRps"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IdentificadorInterno"})
    data_competencia: Optional[datetime] = field(default=None, metadata={"json": "DataCompetencia"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    tomador: Optional[Tomador] = field(default=None, metadata={"json": "Tomador"})
    intermediario: Optional[Intermediario] = field(default=None, metadata={"json": "Intermediario"})
    construcao_civil: Optional[ConstrucaoCivil] = field(default=None, metadata={"json": "ConstrucaoCivil"})
    servico: Optional[Servico] = field(default=None, metadata={"json": "Servico"})


@dataclass
class NotaFiscalServicoEnvio(BrasilNFeModel):
    """Payload de emissão de NFS-e."""
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    nfs_info: List[NFSInfo] = field(default_factory=list, metadata={"json": "nFSInfo"})


@dataclass
class NotaFiscalServicoRetorno(Erros):
    """Retorno da emissão/busca de NFS-e."""
    status_lote: Optional[int] = field(default=None, metadata={"json": "StatusLote"})
    numero_lote: Optional[str] = field(default=None, metadata={"json": "NumeroLote"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    notas: List[dict] = field(default_factory=list, metadata={"json": "Notas"})
