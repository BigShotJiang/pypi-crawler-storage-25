"""Pré-visualização de DANFE (sem consumir numeração SEFAZ)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe.models.nota_fiscal.nota_fiscal_envio import NotaFiscalEnvio
from brasilnfe.models.outros.erros import Erros


@dataclass
class PreVisualizarNotaFiscalEnvio(NotaFiscalEnvio):
    """Payload idêntico ao de NF-e, mas sem envio à SEFAZ."""
    base64_logo: Optional[str] = field(default=None, metadata={"json": "Base64Logo"})


@dataclass
class PreVisualizarNotaFiscalRetorno(Erros):
    """Retorno da pré-visualização."""
    status: Optional[bool] = field(default=None, metadata={"json": "Status"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    url: Optional[str] = field(default=None, metadata={"json": "Url"})
