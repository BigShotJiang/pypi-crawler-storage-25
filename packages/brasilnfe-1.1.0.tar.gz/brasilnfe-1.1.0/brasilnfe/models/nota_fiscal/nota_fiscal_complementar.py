"""NF-e Complementar."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe.models.nota_fiscal.nota_fiscal_envio import NotaFiscalEnvio


@dataclass
class NotaFiscalComplementarEnvio(NotaFiscalEnvio):
    """Payload de emissão de NF-e complementar.

    Geralmente ``finalidade=2``. A ``chave_referenciada`` identifica a NF-e original.
    """
    chave_referenciada: Optional[str] = field(default=None, metadata={"json": "ChaveReferenciada"})
