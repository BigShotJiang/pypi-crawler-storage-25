"""DC-e (Declaração de Conteúdo Eletrônica)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros import Pessoa
from brasilnfe.models.outros.erros import NewError


@dataclass
class PessoaDCe(Pessoa):
    """Remetente ou destinatário da DC-e."""
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    nome: Optional[str] = field(default=None, metadata={"json": "Nome"})


@dataclass
class ItemDCe(BrasilNFeModel):
    """Item declarado no conteúdo."""
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})
    peso_volume: Optional[float] = field(default=None, metadata={"json": "PesoVolume"})
    quantidade_volume: Optional[int] = field(default=None, metadata={"json": "QuantidadeVolume"})


@dataclass
class DCeEnvio(BrasilNFeModel):
    """Payload de emissão de DC-e.

    ``tipo_emitente``: 0=App Fisco, 1=Marketplace, 2=Emissor, 3=Transportadora, 4=ECT.
    ``modalidade_transporte``: 0=Correios, 1=Conta própria, 2=Transportadora.
    """
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    identificador_interno: Optional[str] = field(default=None, metadata={"json": "IdentificadorInterno"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    tipo_emitente: Optional[int] = field(default=None, metadata={"json": "TipoEmitente"})
    x_orgao_fisco: Optional[str] = field(default=None, metadata={"json": "XOrgaoFisco"})
    uf_fisco: Optional[str] = field(default=None, metadata={"json": "UfFisco"})
    modalidade_transporte: Optional[int] = field(default=None, metadata={"json": "ModalidadeTransporte"})
    site_marketplace: Optional[str] = field(default=None, metadata={"json": "SiteMarketplace"})
    remetente: Optional[PessoaDCe] = field(default=None, metadata={"json": "Remetente"})
    destinatario: Optional[PessoaDCe] = field(default=None, metadata={"json": "Destinatario"})
    itens: List[ItemDCe] = field(default_factory=list, metadata={"json": "Itens"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    informacoes_complementares: Optional[str] = field(default=None, metadata={"json": "InformacoesComplementares"})
    informacoes_adicionais_fisco: Optional[str] = field(default=None, metadata={"json": "InformacoesAdicionaisFisco"})
    declaracao_contribuinte_icms: Optional[str] = field(default=None, metadata={"json": "DeclaracaoContribuinteICMS"})


@dataclass
class DCeRetorno(NewError):
    """Retorno da emissão de DC-e."""
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})
