"""MDF-e (Manifesto Eletrônico de Documentos Fiscais - modelo 58)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class DoctoManifesto(BrasilNFeModel):
    """Documento fiscal incluso no manifesto.

    ``tipo``: 55 = NF-e, 57 = CT-e, 65 = NFC-e.
    """
    tipo: Optional[int] = field(default=None, metadata={"json": "Tipo"})
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    pin: Optional[str] = field(default=None, metadata={"json": "Pin"})


@dataclass
class ManifestoTransporteEnvio(BrasilNFeModel):
    """Payload de emissão de MDF-e (modelo 58)."""
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    lote: Optional[int] = field(default=None, metadata={"json": "Lote"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    data_saida: Optional[datetime] = field(default=None, metadata={"json": "DataSaida"})
    municipio: Optional[str] = field(default=None, metadata={"json": "Municipio"})
    placa: Optional[str] = field(default=None, metadata={"json": "Placa"})
    uf: Optional[str] = field(default=None, metadata={"json": "UF"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    documentos: List[DoctoManifesto] = field(default_factory=list, metadata={"json": "Documentos"})


@dataclass
class ManifestoTransporteRetorno(Erros):
    """Retorno da emissão de MDF-e."""
    chave_mdfe: Optional[str] = field(default=None, metadata={"json": "ChaveMDFe"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    base64_file: Optional[str] = field(default=None, metadata={"json": "Base64File"})
