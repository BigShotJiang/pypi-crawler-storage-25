"""Modelos de pessoa, endereço e contato (compartilhados em vários DTOs)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class Endereco(BrasilNFeModel):
    """Endereço de pessoa física ou jurídica.

    ``cod_municipio`` segue o código do IBGE (7 dígitos). ``uf`` deve ser a
    sigla oficial (ex.: ``SP``). ``cod_pais`` segue a tabela BACEN (Brasil = 1058).
    """
    cep: Optional[str] = field(default=None, metadata={"json": "Cep"})
    logradouro: Optional[str] = field(default=None, metadata={"json": "Logradouro"})
    complemento: Optional[str] = field(default=None, metadata={"json": "Complemento"})
    numero: Optional[str] = field(default=None, metadata={"json": "Numero"})
    bairro: Optional[str] = field(default=None, metadata={"json": "Bairro"})
    cod_municipio: Optional[str] = field(default=None, metadata={"json": "CodMunicipio"})
    municipio: Optional[str] = field(default=None, metadata={"json": "Municipio"})
    uf: Optional[str] = field(default=None, metadata={"json": "Uf"})
    cod_pais: Optional[int] = field(default=None, metadata={"json": "CodPais"})
    pais: Optional[str] = field(default=None, metadata={"json": "Pais"})


@dataclass
class Contato(BrasilNFeModel):
    """Telefone, e-mail e fax de contato."""
    telefone: Optional[str] = field(default=None, metadata={"json": "Telefone"})
    email: Optional[str] = field(default=None, metadata={"json": "Email"})
    fax: Optional[str] = field(default=None, metadata={"json": "Fax"})


@dataclass
class Pessoa(BrasilNFeModel):
    """Representa uma pessoa física ou jurídica com endereço e contato."""
    endereco: Optional[Endereco] = field(default=None, metadata={"json": "Endereco"})
    contato: Optional[Contato] = field(default=None, metadata={"json": "Contato"})
