"""Estruturas de produto, impostos e informações fiscais.

Refletem o modelo ``Produto`` do SDK C#/PHP/Node, com tipagem Python e
atributos em ``snake_case``. O serializer cuida da conversão para os
nomes PascalCase/camelCase aceitos pela API.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class Icms(BrasilNFeModel):
    """Imposto sobre Circulação de Mercadorias e Serviços."""
    cod_situacao_tributaria: Optional[str] = field(default=None, metadata={"json": "CodSituacaoTributaria"})
    aliquota_icms: Optional[float] = field(default=None, metadata={"json": "AliquotaICMS"})
    aliquota_icms_st: Optional[float] = field(default=None, metadata={"json": "AliquotaICMSST"})
    aliquota_mva: Optional[float] = field(default=None, metadata={"json": "AliquotaMVA"})
    aliquota_credito: Optional[float] = field(default=None, metadata={"json": "AliquotaCredito"})
    red_icms: Optional[float] = field(default=None, metadata={"json": "RedICMS"})
    red_icms_st: Optional[float] = field(default=None, metadata={"json": "RedICMSST"})
    base_calculo: Optional[float] = field(default=None, metadata={"json": "BaseCalculo"})
    base_calculo_st: Optional[float] = field(default=None, metadata={"json": "BaseCalculoST"})
    valor_icms: Optional[float] = field(default=None, metadata={"json": "ValorIcms"})
    valor_icms_st: Optional[float] = field(default=None, metadata={"json": "ValorIcmsSt"})
    motivo_desoneracao_icms: Optional[int] = field(default=None, metadata={"json": "motivoDesoneracaoIcms"})
    valor_desoneracao_icms: Optional[float] = field(default=None, metadata={"json": "valorDesoneracaoIcms"})
    aliquota_diferimento: Optional[float] = field(default=None, metadata={"json": "aliquotaDiferimento"})
    modalidade_bc_icms: Optional[int] = field(default=None, metadata={"json": "modalidadeBcIcms"})
    modalidade_bc_icms_st: Optional[int] = field(default=None, metadata={"json": "modalidadeBcIcmsSt"})
    aliquota_fcp: Optional[float] = field(default=None, metadata={"json": "AliquotaFCP"})
    aliquota_fcp_st: Optional[float] = field(default=None, metadata={"json": "AliquotaFCPST"})
    aliquota_fcp_st_retido: Optional[float] = field(default=None, metadata={"json": "AliquotaFCPSTRetido"})
    valor_fcp: Optional[float] = field(default=None, metadata={"json": "ValorFCP"})
    valor_fcp_st: Optional[float] = field(default=None, metadata={"json": "ValorFCPST"})
    valor_fcp_st_retido: Optional[float] = field(default=None, metadata={"json": "ValorFCPSTRetido"})


@dataclass
class Ipi(BrasilNFeModel):
    """Imposto sobre Produtos Industrializados."""
    cod_enquadramento: Optional[str] = field(default=None, metadata={"json": "CodEnquadramento"})
    cod_situacao_tributaria: Optional[str] = field(default=None, metadata={"json": "CodSituacaoTributaria"})
    aliquota: Optional[float] = field(default=None, metadata={"json": "Aliquota"})
    valor_ipi_devolvido: Optional[float] = field(default=None, metadata={"json": "ValorIpiDevolvido"})
    percentual_mercadoria_devolvida: Optional[float] = field(default=None, metadata={"json": "PercentualMercadoriaDevolvida"})


@dataclass
class Pis(BrasilNFeModel):
    """Programa de Integração Social."""
    cod_situacao_tributaria: Optional[str] = field(default=None, metadata={"json": "CodSituacaoTributaria"})
    aliquota: Optional[float] = field(default=None, metadata={"json": "Aliquota"})
    base_calculo: Optional[float] = field(default=None, metadata={"json": "BaseCalculo"})


@dataclass
class Cofins(BrasilNFeModel):
    """Contribuição para o Financiamento da Seguridade Social."""
    cod_situacao_tributaria: Optional[str] = field(default=None, metadata={"json": "CodSituacaoTributaria"})
    aliquota: Optional[float] = field(default=None, metadata={"json": "Aliquota"})
    base_calculo: Optional[float] = field(default=None, metadata={"json": "BaseCalculo"})


@dataclass
class Importacao(BrasilNFeModel):
    """Informações de imposto de importação."""
    base_calculo: Optional[float] = field(default=None, metadata={"json": "BaseCalculo"})
    despesas_aduaneiras: Optional[float] = field(default=None, metadata={"json": "DespesasAduaneiras"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})
    valor_iof: Optional[float] = field(default=None, metadata={"json": "ValorIOF"})


@dataclass
class Ibscbs(BrasilNFeModel):
    """Imposto sobre Bens e Serviços / Contribuição sobre Bens e Serviços (Reforma Tributária)."""
    cod_classificacao_tributaria: Optional[str] = field(default=None, metadata={"json": "CodeClassificacaoTributaria"})
    base_calculo: Optional[float] = field(default=None, metadata={"json": "BaseCalculo"})
    aliquota_ibs_uf: Optional[float] = field(default=None, metadata={"json": "AliquotaIBSUF"})
    aliquota_ibs_mun: Optional[float] = field(default=None, metadata={"json": "AliquotaIBSMun"})
    aliquota_cbs: Optional[float] = field(default=None, metadata={"json": "AliquotaCBS"})


@dataclass
class Imposto(BrasilNFeModel):
    """Agrupador de todos os tributos incidentes sobre um produto."""
    ibscbs: Optional[Ibscbs] = field(default=None, metadata={"json": "IBSCBS"})
    icms: Optional[Icms] = field(default=None, metadata={"json": "ICMS"})
    ipi: Optional[Ipi] = field(default=None, metadata={"json": "IPI"})
    pis: Optional[Pis] = field(default=None, metadata={"json": "PIS"})
    cofins: Optional[Cofins] = field(default=None, metadata={"json": "COFINS"})
    importacao: Optional[Importacao] = field(default=None, metadata={"json": "Importacao"})


@dataclass
class Combustivel(BrasilNFeModel):
    """Informações específicas de combustível (quando aplicável)."""
    cod_produto_anp: Optional[str] = field(default=None, metadata={"json": "CodProdutoANP"})
    descricao_produto_anp: Optional[str] = field(default=None, metadata={"json": "DescricaoProdutoANP"})
    uf_consumo: Optional[str] = field(default=None, metadata={"json": "UFConsumo"})


@dataclass
class DeclaracaoImportacao(BrasilNFeModel):
    """Declaração de Importação associada ao produto."""
    numero: Optional[str] = field(default=None, metadata={"json": "Numero"})
    data_registro: Optional[datetime] = field(default=None, metadata={"json": "DataRegistro"})
    local_desenbaraco: Optional[str] = field(default=None, metadata={"json": "LocalDesenbaraco"})
    uf_desenbaraco: Optional[str] = field(default=None, metadata={"json": "UfDesenbaraco"})
    data_desenbaraco: Optional[datetime] = field(default=None, metadata={"json": "DataDesenbaraco"})
    tipo_via_transporte: Optional[int] = field(default=None, metadata={"json": "TipoViaTransporte"})
    valor_afrmm: Optional[float] = field(default=None, metadata={"json": "ValorAFRMM"})
    tipo_intermedio: Optional[int] = field(default=None, metadata={"json": "TipoIntermedio"})
    cnpj: Optional[str] = field(default=None, metadata={"json": "Cnpj"})
    uf: Optional[str] = field(default=None, metadata={"json": "Uf"})
    cod_exportador: Optional[str] = field(default=None, metadata={"json": "CodExportador"})
    cod_fabricante: Optional[str] = field(default=None, metadata={"json": "CodFabricante"})


@dataclass
class Rastreabilidade(BrasilNFeModel):
    """Dados de rastreabilidade (lote, fabricação, validade)."""
    numero_lote: Optional[str] = field(default=None, metadata={"json": "NumeroLote"})
    quantidade_lote: Optional[float] = field(default=None, metadata={"json": "QuantidadeLote"})
    data_fabricacao: Optional[datetime] = field(default=None, metadata={"json": "DataFabricacao"})
    data_validade: Optional[datetime] = field(default=None, metadata={"json": "DataValidade"})
    codigo_agregacao: Optional[str] = field(default=None, metadata={"json": "CodigoAgregacao"})


@dataclass
class Produto(BrasilNFeModel):
    """Item de uma NF-e / NFC-e / CT-e.

    Todos os valores monetários seguem o padrão brasileiro: ponto como
    separador decimal, duas casas (ou quatro em ``valor_unitario`` conforme
    necessidade do produto). ``ncm`` deve ter 8 dígitos; ``cest`` 7 dígitos;
    ``ean`` 8/12/13/14 dígitos ou ``"SEM GTIN"``.
    """
    nm_produto: Optional[str] = field(default=None, metadata={"json": "NmProduto"})
    cod_produto_servico: Optional[str] = field(default=None, metadata={"json": "CodProdutoServico"})
    ean: Optional[str] = field(default=None, metadata={"json": "EAN"})
    ncm: Optional[str] = field(default=None, metadata={"json": "NCM"})
    cest: Optional[str] = field(default=None, metadata={"json": "CEST"})
    quantidade: Optional[float] = field(default=None, metadata={"json": "Quantidade"})
    quantidade_tributavel: Optional[float] = field(default=None, metadata={"json": "QuantidadeTributavel"})
    unidade_comercial: Optional[str] = field(default=None, metadata={"json": "UnidadeComercial"})
    unidade_comercial_tributavel: Optional[str] = field(default=None, metadata={"json": "UnidadeComercialTributavel"})
    valor_desconto: Optional[float] = field(default=None, metadata={"json": "ValorDesconto"})
    valor_unitario: Optional[float] = field(default=None, metadata={"json": "ValorUnitario"})
    valor_unitario_tributavel: Optional[float] = field(default=None, metadata={"json": "ValorUnitarioTributavel"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    valor_seguro: Optional[float] = field(default=None, metadata={"json": "ValorSeguro"})
    valor_frete: Optional[float] = field(default=None, metadata={"json": "ValorFrete"})
    valor_outras_despesas: Optional[float] = field(default=None, metadata={"json": "ValorOutrasDespesas"})
    cfop: Optional[int] = field(default=None, metadata={"json": "CFOP"})
    n_item_ped: Optional[int] = field(default=None, metadata={"json": "NItemPed"})
    x_ped: Optional[str] = field(default=None, metadata={"json": "xPed"})
    n_fci: Optional[str] = field(default=None, metadata={"json": "nFCI"})
    c_benef: Optional[str] = field(default=None, metadata={"json": "cBenef"})
    informacao_adicional: Optional[str] = field(default=None, metadata={"json": "InformacaoAdicional"})
    origem_produto: Optional[int] = field(default=None, metadata={"json": "OrigemProduto"})
    cod_tributacao: Optional[str] = field(default=None, metadata={"json": "CodTributação"})
    imposto: Optional[Imposto] = field(default=None, metadata={"json": "Imposto"})
    combustivel: Optional[Combustivel] = field(default=None, metadata={"json": "Combustivel"})
    declaracao_importacao: Optional[DeclaracaoImportacao] = field(default=None, metadata={"json": "DeclaracaoImportacao"})
    rastros: List[Rastreabilidade] = field(default_factory=list, metadata={"json": "Rastros"})
