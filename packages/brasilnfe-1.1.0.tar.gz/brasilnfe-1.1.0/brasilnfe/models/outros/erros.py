"""Modelos base para erros e avisos retornados pela API Brasil NFe."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class Erros(BrasilNFeModel):
    """Base dos DTOs de retorno.

    Todos os retornos da API podem conter ``Error`` (mensagem principal) e
    ``Avisos`` (lista de observações). Resultados de sucesso mantêm ``Error``
    vazio — verifique o campo para identificar rejeições de negócio.
    """
    error: Optional[str] = field(default=None, metadata={"json": "Error"})
    avisos: List[str] = field(default_factory=list, metadata={"json": "Avisos"})

    @property
    def ok(self) -> bool:
        """``True`` se não há mensagem de erro preenchida."""
        return not self.error


@dataclass
class ErrorInfo(BrasilNFeModel):
    """Detalhe de um erro específico em respostas CT-e, DC-e, NF3-e."""
    codigo: Optional[str] = field(default=None, metadata={"json": "codigo"})
    descricao: Optional[str] = field(default=None, metadata={"json": "descricao"})
    correcao: Optional[str] = field(default=None, metadata={"json": "correcao"})


@dataclass
class NewError(BrasilNFeModel):
    """Formato alternativo de erro (CT-e, DC-e, NF-e de Energia)."""
    erros: List[ErrorInfo] = field(default_factory=list, metadata={"json": "erros"})
    avisos: List[str] = field(default_factory=list, metadata={"json": "avisos"})
    status: Optional[int] = field(default=None, metadata={"json": "status"})
