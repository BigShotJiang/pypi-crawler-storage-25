"""SPED Fiscal/Contribuições e unificação."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.arquivos.sintegra import SintegraDFe, SintegraInventario
from brasilnfe.models.outros.erros import Erros


@dataclass
class DetalhamentoDFeItem(BrasilNFeModel):
    """Item detalhado de um DF-e dentro do SPED."""
    numero_item: Optional[int] = field(default=None, metadata={"json": "NumeroItem"})
    cfop: Optional[int] = field(default=None, metadata={"json": "Cfop"})
    codigo_produto: Optional[str] = field(default=None, metadata={"json": "CodigoProduto"})
    ncm: Optional[str] = field(default=None, metadata={"json": "Ncm"})
    cst_icms_csosn: Optional[str] = field(default=None, metadata={"json": "CstIcmsCsosn"})
    cst_pis: Optional[str] = field(default=None, metadata={"json": "CstPis"})
    cst_cofins: Optional[str] = field(default=None, metadata={"json": "CstCofins"})
    cst_ipi: Optional[str] = field(default=None, metadata={"json": "CstIpi"})
    quantidade: Optional[float] = field(default=None, metadata={"json": "Quantidade"})
    valor_unitario: Optional[float] = field(default=None, metadata={"json": "ValorUnitario"})
    valor_total: Optional[float] = field(default=None, metadata={"json": "ValorTotal"})
    desconto: Optional[float] = field(default=None, metadata={"json": "Desconto"})
    outros: Optional[float] = field(default=None, metadata={"json": "Outros"})
    frete: Optional[float] = field(default=None, metadata={"json": "Frete"})
    icms: Optional[float] = field(default=None, metadata={"json": "Icms"})
    aliquota_icms: Optional[float] = field(default=None, metadata={"json": "AliquotaIcms"})
    pis: Optional[float] = field(default=None, metadata={"json": "Pis"})
    cofins: Optional[float] = field(default=None, metadata={"json": "Cofins"})
    ipi: Optional[float] = field(default=None, metadata={"json": "Ipi"})


@dataclass
class InfoAjuste(BrasilNFeModel):
    """Ajustes de ICMS/IPI aplicáveis."""
    codigo_ajuste: Optional[str] = field(default=None, metadata={"json": "CodigoAjuste"})
    codigo_produto: Optional[str] = field(default=None, metadata={"json": "CodigoProduto"})
    icms: Optional[float] = field(default=None, metadata={"json": "Icms"})
    bc_icms: Optional[float] = field(default=None, metadata={"json": "BcIcms"})
    outros: Optional[float] = field(default=None, metadata={"json": "Outros"})


@dataclass
class DetalhamentoDFe(BrasilNFeModel):
    """Detalhamento completo de um DF-e no SPED."""
    tipo_movimentacao: Optional[int] = field(default=None, metadata={"json": "TipoMovimentacao"})
    cpf_cnpj: Optional[str] = field(default=None, metadata={"json": "CpfCnpj"})
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    cfop_cte: Optional[int] = field(default=None, metadata={"json": "CfopCte"})
    data_movimentacao: Optional[datetime] = field(default=None, metadata={"json": "DataMovimentacao"})
    itens: List[DetalhamentoDFeItem] = field(default_factory=list, metadata={"json": "Itens"})
    info_ajustes: List[InfoAjuste] = field(default_factory=list, metadata={"json": "InfoAjustes"})


@dataclass
class SpedDetalhamento(BrasilNFeModel):
    """Resumo e itens detalhados do SPED gerado."""
    saldo_credor_transportar_icms_ipi: Optional[float] = field(
        default=None, metadata={"json": "SaldoCredorTransportarIcmsIpi"}
    )
    d_fes: List[DetalhamentoDFe] = field(default_factory=list, metadata={"json": "DFes"})


@dataclass
class SpedEnvio(BrasilNFeModel):
    """Payload de geração de SPED Fiscal / Contribuições."""
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    d_fes: List[SintegraDFe] = field(default_factory=list, metadata={"json": "DFes"})
    inventario: List[SintegraInventario] = field(default_factory=list, metadata={"json": "Inventario"})


@dataclass
class UnificarSpedEnvio(BrasilNFeModel):
    """Payload de SPED unificado (múltiplas empresas / múltiplos DF-es)."""
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    d_fes: List[SintegraDFe] = field(default_factory=list, metadata={"json": "DFes"})
    inventario: List[SintegraInventario] = field(default_factory=list, metadata={"json": "Inventario"})
    cnpjs: List[str] = field(default_factory=list, metadata={"json": "CNPJs"})


@dataclass
class SpedRetorno(Erros):
    """Retorno da geração de SPED.

    ``status``: 3 = processando, 2 = erro, outros valores = sucesso.
    """
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    registros: Optional[str] = field(default=None, metadata={"json": "Registros"})
    url: Optional[str] = field(default=None, metadata={"json": "Url"})
    detalhamento: Optional[SpedDetalhamento] = field(default=None, metadata={"json": "Detalhamento"})
