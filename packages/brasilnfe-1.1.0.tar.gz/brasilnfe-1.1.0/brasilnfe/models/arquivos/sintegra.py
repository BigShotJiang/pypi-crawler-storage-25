"""Geração de arquivo SINTEGRA."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class SintegraProdutoDFe(BrasilNFeModel):
    """Produto dentro do DF-e incluído no SINTEGRA."""
    numero_item: Optional[int] = field(default=None, metadata={"json": "NumeroItem"})
    cod_produto: Optional[str] = field(default=None, metadata={"json": "CodProduto"})
    cfop: Optional[int] = field(default=None, metadata={"json": "CFOP"})
    icms: Optional[str] = field(default=None, metadata={"json": "ICMS"})
    nome_produto: Optional[str] = field(default=None, metadata={"json": "NomeProduto"})


@dataclass
class SintegraDFe(BrasilNFeModel):
    """Documento fiscal (XML base64) a incluir no SINTEGRA."""
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
    emissao_propia: Optional[bool] = field(default=None, metadata={"json": "EmissaoPropia"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    situacao: Optional[int] = field(default=None, metadata={"json": "Situacao"})
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})
    dt_entrada_saida: Optional[datetime] = field(default=None, metadata={"json": "DtEntradaSaida"})
    produtos: List[SintegraProdutoDFe] = field(default_factory=list, metadata={"json": "Produtos"})


@dataclass
class SintegraInventario(BrasilNFeModel):
    """Item do inventário para SINTEGRA."""
    dt_inventario: Optional[datetime] = field(default=None, metadata={"json": "DtInventario"})
    cod_produto: Optional[str] = field(default=None, metadata={"json": "CodProduto"})
    quantidade: Optional[float] = field(default=None, metadata={"json": "Quantidade"})
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})
    cod_posse_mercadoria: Optional[int] = field(default=None, metadata={"json": "CodPosseMercadoria"})
    cnpj_possuidor: Optional[str] = field(default=None, metadata={"json": "CNPJPossuidor"})
    ie_possuidor: Optional[str] = field(default=None, metadata={"json": "IEPossuidor"})
    uf_possuidor: Optional[str] = field(default=None, metadata={"json": "UFPossuidor"})
    nm_produto: Optional[str] = field(default=None, metadata={"json": "NmProduto"})
    ncm: Optional[str] = field(default=None, metadata={"json": "NCM"})
    unidade_medida: Optional[str] = field(default=None, metadata={"json": "UnidadeMedida"})
    aliquota_ipi: Optional[float] = field(default=None, metadata={"json": "AliquotaIPI"})
    aliquota_icms: Optional[float] = field(default=None, metadata={"json": "AliquotaICMS"})
    red_bc_icms: Optional[float] = field(default=None, metadata={"json": "RedBCICMS"})
    bc_icms_st: Optional[float] = field(default=None, metadata={"json": "BCICMSST"})


@dataclass
class SintegraEnvio(BrasilNFeModel):
    """Payload de geração do arquivo SINTEGRA.

    ``crt``: 1=Simples Nacional, 2=Simples c/ Sublimite, 3=Regime Normal, 4=MEI.
    ``cod_id_convenio``: 1, 2 ou 3 conforme convênio aplicável.
    """
    crt: Optional[int] = field(default=None, metadata={"json": "CRT"})
    cod_id_convenio: Optional[int] = field(default=None, metadata={"json": "CodIdConvenio"})
    cod_id_natureza_operacao: Optional[int] = field(default=None, metadata={"json": "CodIdNaturezaOperacao"})
    cod_finalidade: Optional[int] = field(default=None, metadata={"json": "CodFinalidade"})
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    incluir_notas_saidas: Optional[bool] = field(default=None, metadata={"json": "IncluirNotasSaidas"})
    d_fes: List[SintegraDFe] = field(default_factory=list, metadata={"json": "DFes"})
    inventario: List[SintegraInventario] = field(default_factory=list, metadata={"json": "Inventario"})


@dataclass
class SintegraDetalhes(BrasilNFeModel):
    """Totalizadores do SINTEGRA gerado."""
    valor_saidas_nfce: Optional[float] = field(default=None, metadata={"json": "ValorSaidasNFCe"})
    valor_saidas_nfe: Optional[float] = field(default=None, metadata={"json": "ValorSaidasNFe"})
    valor_saidas_cte: Optional[float] = field(default=None, metadata={"json": "ValorSaidasCTe"})
    valor_entradas_nfe: Optional[float] = field(default=None, metadata={"json": "ValorEntradasNFe"})
    valor_entradas_cte: Optional[float] = field(default=None, metadata={"json": "ValorEntradasCTe"})
    valor_inventario: Optional[float] = field(default=None, metadata={"json": "ValorInventario"})


@dataclass
class SintegraRetorno(Erros):
    """Retorno do arquivo SINTEGRA."""
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    status: Optional[bool] = field(default=None, metadata={"json": "Status"})
    registros: Optional[str] = field(default=None, metadata={"json": "Registros"})
    detalhes: Optional[SintegraDetalhes] = field(default=None, metadata={"json": "Detalhes"})
