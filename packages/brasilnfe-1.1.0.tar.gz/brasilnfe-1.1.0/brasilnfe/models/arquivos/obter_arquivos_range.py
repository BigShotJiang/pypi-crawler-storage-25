"""Download em lote por range/período."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class ObterArquivosRangeEnvio(BrasilNFeModel):
    """Payload para obter múltiplos arquivos por período ou range de chaves."""
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    file_type: Optional[int] = field(default=None, metadata={"json": "FileType"})
    tipo_documento_fiscal: Optional[int] = field(default=None, metadata={"json": "TipoDocumentoFiscal"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    chaves: List[str] = field(default_factory=list, metadata={"json": "Chaves"})
    base64_logo: Optional[str] = field(default=None, metadata={"json": "Base64Logo"})


@dataclass
class ArquivoItem(BrasilNFeModel):
    """Um arquivo (XML ou PDF) retornado em base64."""
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    nome_arquivo: Optional[str] = field(default=None, metadata={"json": "NomeArquivo"})
    base64: Optional[str] = field(default=None, metadata={"json": "Base64"})
    tipo: Optional[int] = field(default=None, metadata={"json": "Tipo"})


@dataclass
class ObterArquivosRangeRetorno(Erros):
    """Retorno com a lista de arquivos."""
    arquivos: List[ArquivoItem] = field(default_factory=list, metadata={"json": "Arquivos"})
