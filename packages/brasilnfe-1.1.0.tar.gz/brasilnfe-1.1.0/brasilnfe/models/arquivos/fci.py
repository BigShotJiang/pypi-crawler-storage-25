"""FCI — Ficha de Conteúdo de Importação."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel
from brasilnfe.models.outros.erros import Erros


@dataclass
class FciItem(BrasilNFeModel):
    """Item da FCI."""
    codigo_produto: Optional[str] = field(default=None, metadata={"json": "CodigoProduto"})
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})
    ncm: Optional[str] = field(default=None, metadata={"json": "NCM"})
    unidade_medida: Optional[str] = field(default=None, metadata={"json": "UnidadeMedida"})
    valor_saida: Optional[float] = field(default=None, metadata={"json": "ValorSaida"})
    valor_importado: Optional[float] = field(default=None, metadata={"json": "ValorImportado"})
    conteudo_importacao: Optional[float] = field(default=None, metadata={"json": "ConteudoImportacao"})


@dataclass
class FciEnvio(BrasilNFeModel):
    """Payload de geração de FCI."""
    dt_inicio: Optional[datetime] = field(default=None, metadata={"json": "DtInicio"})
    dt_fim: Optional[datetime] = field(default=None, metadata={"json": "DtFim"})
    itens: List[FciItem] = field(default_factory=list, metadata={"json": "Itens"})


@dataclass
class FciRetorno(Erros):
    """Retorno da geração de FCI."""
    codigo: Optional[str] = field(default=None, metadata={"json": "Codigo"})
    status: Optional[bool] = field(default=None, metadata={"json": "Status"})
    registros: Optional[str] = field(default=None, metadata={"json": "Registros"})
