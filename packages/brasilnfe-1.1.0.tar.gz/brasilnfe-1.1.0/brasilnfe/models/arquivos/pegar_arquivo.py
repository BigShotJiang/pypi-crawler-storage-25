"""Download de XML e DANFE/Cupom PDF."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class PegarArquivoEnvio(BrasilNFeModel):
    """Payload para download de XML ou DANFE.

    ``file_type``: 1 = XML, 2 = DANFE / cupom (PDF).
    ``tipo_documento_fiscal``: 0 = Entrada, 1 = Saída.
    """
    chaves: List[str] = field(default_factory=list, metadata={"json": "Chaves"})
    chave_nf: Optional[str] = field(default=None, metadata={"json": "ChaveNF"})
    file_type: Optional[int] = field(default=None, metadata={"json": "FileType"})
    tipo_documento_fiscal: Optional[int] = field(default=None, metadata={"json": "TipoDocumentoFiscal"})
    base64_logo: Optional[str] = field(default=None, metadata={"json": "Base64Logo"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})


@dataclass
class PegarArquivoEventoEnvio(BrasilNFeModel):
    """Payload para download de arquivo de evento."""
    chave_nf: Optional[str] = field(default=None, metadata={"json": "ChaveNF"})
    file_type: Optional[int] = field(default=None, metadata={"json": "FileType"})
    tipo_evento: Optional[int] = field(default=None, metadata={"json": "TipoEvento"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
