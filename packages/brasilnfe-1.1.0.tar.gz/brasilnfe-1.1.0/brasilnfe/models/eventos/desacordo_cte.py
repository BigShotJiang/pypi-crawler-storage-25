"""Desacordo de CT-e."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class DesacordoCTeEnvio(BrasilNFeModel):
    """Payload de registro de desacordo sobre um CT-e."""
    chave_cte: Optional[str] = field(default=None, metadata={"json": "ChaveCTe"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    justificativa: Optional[str] = field(default=None, metadata={"json": "Justificativa"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
