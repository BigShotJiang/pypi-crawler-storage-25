"""Carta de Correção Eletrônica (CC-e)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class Correcao(BrasilNFeModel):
    """Correção estruturada (usada em CT-e)."""
    campo: Optional[str] = field(default=None, metadata={"json": "Campo"})
    grupo: Optional[str] = field(default=None, metadata={"json": "Grupo"})
    valor: Optional[str] = field(default=None, metadata={"json": "Valor"})


@dataclass
class CartaCorrecaoEnvio(BrasilNFeModel):
    """Payload de carta de correção."""
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    chave_nf: Optional[str] = field(default=None, metadata={"json": "ChaveNF"})
    correcao: Optional[str] = field(default=None, metadata={"json": "Correcao"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
    correcoes: List[Correcao] = field(default_factory=list, metadata={"json": "Correcoes"})
