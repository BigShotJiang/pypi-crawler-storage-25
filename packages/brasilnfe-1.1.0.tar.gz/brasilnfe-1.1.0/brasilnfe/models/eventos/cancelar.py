"""Cancelamento de NF-e / NFC-e / CT-e / MDF-e / DC-e / NFS-e."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class CancelarNotaFiscalEnvio(BrasilNFeModel):
    """Payload de cancelamento.

    Campos:
        chave_nf: Chave de acesso do documento (obrigatório para NF/CT/MDF/DC).
        numero_protocolo: Protocolo de autorização (necessário para SEFAZ).
        justificativa: Motivo do cancelamento (mínimo 15 caracteres).
        tipo_documento: 0 = NF-e/NFC-e/CT-e/MDF-e/DC-e, 1 = NFS-e.
        numero_nfse: Número da NFS-e quando ``tipo_documento = 1``.
        cod_cancelamento_nfse: Código específico para cancelamento de NFS-e (1,2,3,9).
    """
    chave_nf: Optional[str] = field(default=None, metadata={"json": "ChaveNF"})
    numero_protocolo: Optional[str] = field(default=None, metadata={"json": "NumeroProtocolo"})
    justificativa: Optional[str] = field(default=None, metadata={"json": "Justificativa"})
    tipo_ambiente_nfse: Optional[int] = field(default=None, metadata={"json": "TipoAmbienteNFSe"})
    data_evento: Optional[datetime] = field(default=None, metadata={"json": "DataEvento"})
    numero_nfse: Optional[str] = field(default=None, metadata={"json": "NumeroNFSe"})
    cod_cancelamento_nfse: Optional[int] = field(default=None, metadata={"json": "CodCancelamentoNFSe"})
    tipo_documento: Optional[int] = field(default=None, metadata={"json": "TipoDocumento"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
