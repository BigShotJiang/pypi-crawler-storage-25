"""Inutilização de numeração de NF-e / NFC-e."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class InutilizarNumeracaoEnvio(BrasilNFeModel):
    """Payload de inutilização de faixa de numeração."""
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    modelo_documento: Optional[int] = field(default=None, metadata={"json": "ModeloDocumento"})
    serie: Optional[int] = field(default=None, metadata={"json": "Serie"})
    numero_inicial: Optional[int] = field(default=None, metadata={"json": "NumeroInicial"})
    numero_final: Optional[int] = field(default=None, metadata={"json": "NumeroFinal"})
    justificativa: Optional[str] = field(default=None, metadata={"json": "Justificativa"})
    ano: Optional[int] = field(default=None, metadata={"json": "Ano"})
