"""Manifestação do destinatário (MDe)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class ManifestarNotaFiscalEnvio(BrasilNFeModel):
    """Manifestação de NF-e recebida.

    ``tipo_manifestacao``:
        1 = Confirmação da Operação
        2 = Ciência da Operação
        3 = Desconhecimento da Operação
        4 = Operação não Realizada
    """
    chave: Optional[str] = field(default=None, metadata={"json": "Chave"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    tipo_manifestacao: Optional[int] = field(default=None, metadata={"json": "TipoManifestacao"})
    justificativa: Optional[str] = field(default=None, metadata={"json": "Justificativa"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
