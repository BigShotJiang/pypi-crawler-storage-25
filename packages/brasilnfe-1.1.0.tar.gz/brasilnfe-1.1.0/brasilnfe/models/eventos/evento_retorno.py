"""Retorno comum de eventos SEFAZ."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from brasilnfe.models.outros.erros import Erros


@dataclass
class EventoNotaFiscalRetorno(Erros):
    """Retorno padronizado para todos os eventos SEFAZ.

    ``status``:
        1 = Evento processado
        2 = Aguardando processamento
        3 = Ocorreu um erro
    """
    ds_motivo: Optional[str] = field(default=None, metadata={"json": "DsMotivo"})
    ds_evento: Optional[str] = field(default=None, metadata={"json": "DsEvento"})
    ds_ambiente: Optional[str] = field(default=None, metadata={"json": "DsAmbiente"})
    nu_protocolo: Optional[str] = field(default=None, metadata={"json": "NuProtocolo"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
    cod_status_resposta_sefaz: Optional[int] = field(default=None, metadata={"json": "CodStatusRespostaSefaz"})
    status: Optional[int] = field(default=None, metadata={"json": "Status"})
    base64_xml: Optional[str] = field(default=None, metadata={"json": "Base64Xml"})
