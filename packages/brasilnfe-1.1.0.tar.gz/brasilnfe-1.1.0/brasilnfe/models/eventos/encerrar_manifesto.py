"""Encerramento de MDF-e."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from brasilnfe._serializer import BrasilNFeModel


@dataclass
class EncerrarManifestoTransporteEnvio(BrasilNFeModel):
    """Payload de encerramento de manifesto de transporte (MDF-e)."""
    chave_mdfe: Optional[str] = field(default=None, metadata={"json": "ChaveMDFe"})
    tipo_ambiente: Optional[int] = field(default=None, metadata={"json": "TipoAmbiente"})
    data_encerramento: Optional[datetime] = field(default=None, metadata={"json": "DataEncerramento"})
    uf_encerramento: Optional[str] = field(default=None, metadata={"json": "UfEncerramento"})
    cod_municipio: Optional[int] = field(default=None, metadata={"json": "CodMunicipio"})
    municipio: Optional[str] = field(default=None, metadata={"json": "Municipio"})
    protocolo: Optional[str] = field(default=None, metadata={"json": "Protocolo"})
    numero_sequencial: Optional[int] = field(default=None, metadata={"json": "NumeroSequencial"})
