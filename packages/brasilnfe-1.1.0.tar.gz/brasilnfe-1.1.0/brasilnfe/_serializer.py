"""
Serializer interno: converte dataclasses/dicts Python (snake_case) para o
formato JSON aceito pela API Brasil NFe (PascalCase/camelCase, preservando
as chaves originais definidas via ``field(metadata={"json": "..."})``).

A API Brasil NFe usa uma mistura de PascalCase (``NmProduto``, ``Produtos``) e
camelCase (``valorNf``, ``status``). Para manter o código Python idiomático
(PEP 8) sem quebrar a interoperabilidade:

* Atributos dos dataclasses usam ``snake_case``.
* Campos cujo nome JSON difere de ``snake_case -> PascalCase`` automático
  declaram o nome explícito via ``metadata={"json": "nomeOriginal"}``.
* ``to_dict`` omite ``None`` / listas vazias por padrão para manter payloads
  enxutos, exatamente como os outros SDKs.
* ``from_dict`` aceita payloads em qualquer casing (PascalCase, camelCase,
  snake_case) e normaliza para os atributos Python.
"""
from __future__ import annotations

import dataclasses
import datetime
import decimal
import enum
import sys
import typing
from typing import Any, Mapping, Optional, Type, TypeVar, Union, get_args, get_origin

T = TypeVar("T")

_JSON_KEY = "json"


def snake_to_pascal(name: str) -> str:
    """Converte ``nm_produto`` em ``NmProduto`` preservando dígitos."""
    return "".join(part[:1].upper() + part[1:] for part in name.split("_") if part)


def pascal_to_snake(name: str) -> str:
    """Converte ``NmProduto`` / ``valorNf`` em ``nm_produto`` / ``valor_nf``."""
    out: list[str] = []
    for i, ch in enumerate(name):
        if ch.isupper() and i > 0 and (name[i - 1].islower() or name[i - 1].isdigit()):
            out.append("_")
        out.append(ch.lower())
    return "".join(out)


def _field_json_name(field: dataclasses.Field) -> str:
    explicit = field.metadata.get(_JSON_KEY) if field.metadata else None
    return explicit or snake_to_pascal(field.name)


def _is_empty(value: Any) -> bool:
    if value is None:
        return True
    return isinstance(value, (list, tuple, set)) and len(value) == 0


def to_dict(obj: Any, *, drop_empty: bool = True) -> Any:
    """Serializa ``obj`` para estruturas ``dict``/``list``/primitivas.

    * Datetimes são formatadas em ISO-8601 (``YYYY-MM-DDTHH:MM:SS``).
    * Decimal é convertido em ``float`` (a API aceita números JSON padrão).
    * Bytes são codificados em base64.
    * Enums são serializados via ``.value``.
    """
    if obj is None:
        return None
    if isinstance(obj, BrasilNFeModel):
        return obj.to_dict(drop_empty=drop_empty)
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        out: dict[str, Any] = {}
        for f in dataclasses.fields(obj):
            value = getattr(obj, f.name)
            if drop_empty and _is_empty(value):
                continue
            out[_field_json_name(f)] = to_dict(value, drop_empty=drop_empty)
        return out
    if isinstance(obj, Mapping):
        return {k: to_dict(v, drop_empty=drop_empty) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_dict(v, drop_empty=drop_empty) for v in obj]
    if isinstance(obj, datetime.datetime):
        return obj.strftime("%Y-%m-%dT%H:%M:%S")
    if isinstance(obj, datetime.date):
        return obj.strftime("%Y-%m-%dT00:00:00")
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    if isinstance(obj, enum.Enum):
        return obj.value
    if isinstance(obj, (bytes, bytearray)):
        import base64

        return base64.b64encode(bytes(obj)).decode("ascii")
    return obj


def _strip_optional(tp: Any) -> Any:
    origin = get_origin(tp)
    if origin is Union:
        args = [a for a in get_args(tp) if a is not type(None)]
        if len(args) == 1:
            return args[0]
    return tp


def _parse_datetime(value: Any) -> Optional[datetime.datetime]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime.datetime):
        return value
    if isinstance(value, datetime.date):
        return datetime.datetime(value.year, value.month, value.day)
    if isinstance(value, str):
        cleaned = value.replace("Z", "+00:00")
        try:
            return datetime.datetime.fromisoformat(cleaned)
        except ValueError:
            for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
                try:
                    return datetime.datetime.strptime(value, fmt)
                except ValueError:
                    continue
    return None


_HINT_CACHE: dict[type, dict[str, Any]] = {}


def _resolve_hints(cls: type) -> dict[str, Any]:
    """Resolve anotações (incluindo strings vindas de ``from __future__ import annotations``).

    Usa ``typing.get_type_hints`` e faz cache por classe. Se a resolução falhar
    (import circular, nome ausente), cai no ``__annotations__`` bruto.
    """
    cached = _HINT_CACHE.get(cls)
    if cached is not None:
        return cached
    try:
        # Junta globals de todas as classes base para resolver forward refs
        globalns: dict[str, Any] = {}
        for base in reversed(cls.__mro__):
            mod = sys.modules.get(base.__module__)
            if mod is not None:
                globalns.update(vars(mod))
        hints = typing.get_type_hints(cls, globalns=globalns)
    except Exception:
        hints = dict(getattr(cls, "__annotations__", {}))
    _HINT_CACHE[cls] = hints
    return hints


def from_dict(cls: Type[T], data: Any) -> T:
    """Instancia ``cls`` (dataclass) a partir de ``data`` (dict/list/JSON).

    Aceita chaves em qualquer casing — ``NmProduto``, ``nmProduto``,
    ``nm_produto`` são todos mapeados para o atributo ``nm_produto``.
    Campos desconhecidos são silenciosamente ignorados para tolerar
    respostas evolutivas da API.
    """
    if data is None:
        return None  # type: ignore[return-value]
    if not dataclasses.is_dataclass(cls):
        return _coerce_value(cls, data)  # type: ignore[return-value]
    if not isinstance(data, Mapping):
        return data  # type: ignore[return-value]

    # Indexa o dict de entrada por chave normalizada (minúscula)
    normalized: dict[str, Any] = {}
    for k, v in data.items():
        if isinstance(k, str):
            normalized[k.lower()] = v

    hints = _resolve_hints(cls)
    kwargs: dict[str, Any] = {}
    for f in dataclasses.fields(cls):
        raw_value = _find_field_value(f, normalized)
        if raw_value is dataclasses.MISSING:
            continue
        field_type = hints.get(f.name, f.type)
        kwargs[f.name] = _coerce_value(field_type, raw_value)

    return cls(**kwargs)  # type: ignore[call-arg]


def _find_field_value(field: dataclasses.Field, normalized: Mapping[str, Any]) -> Any:
    candidates = {
        _field_json_name(field),
        field.name,
        snake_to_pascal(field.name),
        snake_to_pascal(field.name)[:1].lower() + snake_to_pascal(field.name)[1:],
    }
    for cand in candidates:
        key = cand.lower()
        if key in normalized:
            return normalized[key]
    return dataclasses.MISSING


def _coerce_value(tp: Any, value: Any) -> Any:
    if value is None:
        return None

    tp = _strip_optional(tp)

    # Strings de tipos não resolvidas (ex.: "List[Produto]") -> mantém valor
    if isinstance(tp, str):
        return value

    origin = get_origin(tp)

    if origin in (list, tuple, set):
        item_type = (get_args(tp) or (Any,))[0]
        if not isinstance(value, (list, tuple, set)):
            return value
        return [_coerce_value(item_type, v) for v in value]

    if origin is dict:
        _, val_t = (*get_args(tp), Any, Any)[:2]
        return {k: _coerce_value(val_t, v) for k, v in value.items()}

    if dataclasses.is_dataclass(tp) and isinstance(tp, type):
        return from_dict(tp, value)

    if isinstance(tp, type):
        if issubclass(tp, enum.Enum):
            try:
                return tp(value)
            except ValueError:
                return value
        if tp is datetime.datetime:
            return _parse_datetime(value)
        if tp is datetime.date:
            dt = _parse_datetime(value)
            return dt.date() if dt else None
        if tp is decimal.Decimal and not isinstance(value, decimal.Decimal):
            try:
                return decimal.Decimal(str(value))
            except decimal.InvalidOperation:
                return value
        if tp is bool and not isinstance(value, bool):
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                return value.strip().lower() in ("true", "1", "yes", "sim", "y")

    return value


class BrasilNFeModel:
    """Mixin para dataclasses do SDK.

    Fornece ``to_dict`` / ``from_dict`` baseados em :mod:`dataclasses`,
    sem dependências externas (não usa Pydantic). Qualquer dataclass que
    herde deste mixin ganha serialização consistente com a API Brasil NFe.
    """

    __slots__ = ()

    def to_dict(self, *, drop_empty: bool = True) -> dict[str, Any]:
        if not dataclasses.is_dataclass(self):
            raise TypeError(
                f"{type(self).__name__} precisa ser um @dataclass para usar to_dict()"
            )
        out: dict[str, Any] = {}
        for f in dataclasses.fields(self):
            value = getattr(self, f.name)
            if drop_empty and _is_empty(value):
                continue
            out[_field_json_name(f)] = to_dict(value, drop_empty=drop_empty)
        return out

    @classmethod
    def from_dict(cls: Type[T], data: Any) -> T:
        return from_dict(cls, data)


__all__ = [
    "BrasilNFeModel",
    "from_dict",
    "pascal_to_snake",
    "snake_to_pascal",
    "to_dict",
]
