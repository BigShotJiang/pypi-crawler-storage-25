"""Recursos de alto nível do SDK (nota_fiscal, eventos, consultas, arquivos, empresa)."""
from brasilnfe.methods.arquivos import Arquivos
from brasilnfe.methods.consultas import Consultas
from brasilnfe.methods.empresa import Empresa
from brasilnfe.methods.eventos import Eventos
from brasilnfe.methods.nota_fiscal import NotaFiscal

__all__ = ["Arquivos", "Consultas", "Empresa", "Eventos", "NotaFiscal"]
