"""Recurso ``Eventos`` — cancelamento, CC-e, inutilização, manifestação."""
from __future__ import annotations

from brasilnfe.models.eventos import (
    CancelarNotaFiscalEnvio,
    CartaCorrecaoEnvio,
    EncerrarManifestoTransporteEnvio,
    EventoNotaFiscalRetorno,
    InutilizarNumeracaoEnvio,
    ManifestarNotaFiscalEnvio,
)
from brasilnfe.request import BrasilNFeRequest


class Eventos(BrasilNFeRequest):
    """Eventos SEFAZ: cancelamento, CC-e, inutilização, manifestação, encerramento de MDF-e."""

    def cancelar_nota_fiscal(
        self,
        cancelar_nota_fiscal_envio: CancelarNotaFiscalEnvio,
    ) -> EventoNotaFiscalRetorno:
        """Cancela NF-e / NFC-e / CT-e / MDF-e / DC-e / NFS-e."""
        return self.request(
            cancelar_nota_fiscal_envio, "CancelNF", EventoNotaFiscalRetorno
        )

    # Alias para compatibilidade com o SDK Node
    cancelar_nf = cancelar_nota_fiscal

    def enviar_carta_correcao(
        self,
        carta_correcao_envio: CartaCorrecaoEnvio,
    ) -> EventoNotaFiscalRetorno:
        """Envia Carta de Correção Eletrônica (CC-e)."""
        return self.request(
            carta_correcao_envio, "EnviarCartaCorrecao", EventoNotaFiscalRetorno
        )

    def inutilizar_numeracao(
        self,
        inutilizar_numeracao_envio: InutilizarNumeracaoEnvio,
    ) -> EventoNotaFiscalRetorno:
        """Inutiliza faixa de numeração de NF-e / NFC-e."""
        return self.request(
            inutilizar_numeracao_envio, "InutilizarNumeracao", EventoNotaFiscalRetorno
        )

    def manifestar_nota_fiscal(
        self,
        manifestar_nota_fiscal_envio: ManifestarNotaFiscalEnvio,
    ) -> EventoNotaFiscalRetorno:
        """Manifesta destinatário (confirmação, ciência, desconhecimento, não realizada)."""
        return self.request(
            manifestar_nota_fiscal_envio, "ManifestarNotaFiscal", EventoNotaFiscalRetorno
        )

    def encerrar_manifesto_transporte(
        self,
        encerrar_manifesto_transporte_envio: EncerrarManifestoTransporteEnvio,
    ) -> EventoNotaFiscalRetorno:
        """Encerra MDF-e após a conclusão do trajeto."""
        return self.request(
            encerrar_manifesto_transporte_envio,
            "EncerrarManifestoTransporte",
            EventoNotaFiscalRetorno,
        )
