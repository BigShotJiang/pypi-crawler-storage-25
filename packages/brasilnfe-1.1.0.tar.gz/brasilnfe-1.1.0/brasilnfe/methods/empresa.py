"""Recurso ``Empresa`` — cadastro de empresas e certificado digital."""
from __future__ import annotations

from typing import List

from brasilnfe.models.empresa import (
    CertificadoEnvio,
    CertificadoRetorno,
    EmpresaEnvio,
    EmpresaRetorno,
)
from brasilnfe.request import BrasilNFeRequest


class Empresa(BrasilNFeRequest):
    """Gestão de empresas e certificados digitais.

    Este recurso requer ``user_token`` na inicialização de :class:`BrasilNFe`.
    """

    def alterar_certificado(self, certificado: CertificadoEnvio) -> CertificadoRetorno:
        """Altera / atualiza o certificado digital A1 da empresa."""
        return self.request(certificado, "AlterarCertificado", CertificadoRetorno)

    def verificar_certificado(self, certificado: CertificadoEnvio) -> CertificadoRetorno:
        """Verifica validade e titular do certificado digital A1 (sem persistir)."""
        return self.request(certificado, "VerifyCertificate", CertificadoRetorno)

    def adicionar_empresa(self, empresa: EmpresaEnvio) -> EmpresaRetorno:
        """Cadastra uma nova empresa."""
        return self.request(empresa, "AdicionarEmpresa", EmpresaRetorno)

    def editar_empresa(self, empresa: EmpresaEnvio) -> EmpresaRetorno:
        """Edita dados de uma empresa existente."""
        return self.request(empresa, "EditarEmpresa", EmpresaRetorno)

    def buscar_empresa(self) -> EmpresaEnvio:
        """Busca os dados da empresa autenticada pelo token atual."""
        return self.request({}, "BuscarEmpresa", EmpresaEnvio)

    def buscar_todas_empresas(self) -> List[EmpresaEnvio]:
        """Lista todas as empresas acessíveis pelo ``user_token``."""
        return self.request({}, "BuscarTodasEmpresas", EmpresaEnvio, as_list=True)
