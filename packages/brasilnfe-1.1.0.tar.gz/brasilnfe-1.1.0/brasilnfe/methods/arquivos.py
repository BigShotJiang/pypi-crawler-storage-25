"""Recurso ``Arquivos`` — SPED, SINTEGRA, FCI, download de XML/DANFE."""
from __future__ import annotations

from brasilnfe.models.arquivos import (
    FciEnvio,
    FciRetorno,
    ObterArquivosRangeEnvio,
    ObterArquivosRangeRetorno,
    PegarArquivoEnvio,
    PegarArquivoEventoEnvio,
    SintegraEnvio,
    SintegraRetorno,
    SpedEnvio,
    SpedRetorno,
    UnificarSpedEnvio,
)
from brasilnfe.models.nota_fiscal import ArqEnerComEnvio, ArqEnerComRetorno
from brasilnfe.request import BrasilNFeRequest


class Arquivos(BrasilNFeRequest):
    """Geração e download de arquivos fiscais."""

    def obter_arquivo_sintegra(self, sintegra_envio: SintegraEnvio) -> SintegraRetorno:
        """Gera arquivo SINTEGRA (ICMS/IPI)."""
        return self.request(sintegra_envio, "ObterArquivoSintegra", SintegraRetorno)

    # Alias
    gerar_arquivo_sintegra = obter_arquivo_sintegra

    def obter_arquivo_fci(self, fci_envio: FciEnvio) -> FciRetorno:
        """Gera arquivo FCI (Ficha de Conteúdo de Importação)."""
        return self.request(fci_envio, "ObterArquivoFci", FciRetorno)

    # Alias
    gerar_arquivo_fci = obter_arquivo_fci

    def obter_arq_enercom(self, arq_enercom_envio: ArqEnerComEnvio) -> ArqEnerComRetorno:
        """Obtém arquivo consolidado de NF-e de energia/comunicação."""
        return self.request(arq_enercom_envio, "ObterArquivoNFEnerCom", ArqEnerComRetorno)

    def obter_arquivo_sped(self, sped_envio: SpedEnvio) -> SpedRetorno:
        """Gera SPED Fiscal ou Contribuições."""
        return self.request(sped_envio, "ObterArquivoSped", SpedRetorno)

    # Alias
    gerar_arquivo_sped = obter_arquivo_sped

    def obter_arquivo_sped_unificado(
        self, unificar_sped_envio: UnificarSpedEnvio
    ) -> SpedRetorno:
        """Gera SPED unificado (múltiplas empresas / múltiplos DF-es)."""
        return self.request(unificar_sped_envio, "ObterArquivoSpedUnificado", SpedRetorno)

    # Alias
    unificar_arquivo_sped = obter_arquivo_sped_unificado

    def recriar_arquivo_sped(self, codigo: str) -> SpedRetorno:
        """Recria SPED previamente gerado pelo ``codigo``."""
        return self.request(
            "",
            "RecriarArquivoSped",
            SpedRetorno,
            query={"codigo": codigo},
        )

    def pegar_arquivo(self, pegar_arquivo_envio: PegarArquivoEnvio) -> bytes:
        """Baixa XML (file_type=1) ou DANFE/Cupom (file_type=2).

        Retorna ``bytes`` já decodificados do base64 original. Salve em arquivo:

        >>> pdf = client.arquivos.pegar_arquivo(env)
        >>> Path("danfe.pdf").write_bytes(pdf)
        """
        return self.request_bytes(pegar_arquivo_envio, "GetFile")

    # Alias
    obter_arquivo_nota_fiscal = pegar_arquivo

    def pegar_arquivo_evento(
        self, pegar_arquivo_evento_envio: PegarArquivoEventoEnvio
    ) -> bytes:
        """Baixa arquivo de evento (CC-e, cancelamento, etc)."""
        return self.request_bytes(pegar_arquivo_evento_envio, "GetFileFromEvent")

    # Alias
    obter_arquivo_evento = pegar_arquivo_evento

    def obter_arquivos_por_range(
        self, pegar_arquivos_range_envio: ObterArquivosRangeEnvio
    ) -> ObterArquivosRangeRetorno:
        """Obtém múltiplos arquivos por período / range de chaves."""
        return self.request(
            pegar_arquivos_range_envio,
            "ObterArquivosPorRange",
            ObterArquivosRangeRetorno,
        )

    # Alias
    obter_arquivos_por_periodo = obter_arquivos_por_range
