"""Recurso ``Consultas`` — status SEFAZ, busca de notas, cálculo de impostos."""
from __future__ import annotations

from typing import List

from brasilnfe.models.arquivos import SpedRetorno
from brasilnfe.models.consultas import (
    BuscarNotaFiscalEnvio,
    BuscarNotaFiscalRetorno,
    BuscarNotaFiscalServicoEnvio,
    CalculoImpostosRetorno,
    ConsultarCadastroEnvio,
    ConsultarCadastroRetorno,
    StatusSefazEnvio,
    StatusSefazRetorno,
)
from brasilnfe.models.nota_fiscal import (
    NotaFiscalServicoRetorno,
    PreVisualizarNotaFiscalEnvio,
    PreVisualizarNotaFiscalRetorno,
)
from brasilnfe.models.outros import Produto
from brasilnfe.request import BrasilNFeRequest


class Consultas(BrasilNFeRequest):
    """Consultas à SEFAZ e utilitários de cálculo."""

    def status_sefaz(self, status_sefaz_envio: StatusSefazEnvio) -> StatusSefazRetorno:
        """Consulta o status da SEFAZ para um modelo/ambiente específico."""
        return self.request(status_sefaz_envio, "StatusSefaz", StatusSefazRetorno)

    # Alias para compatibilidade
    consultar_status_sefaz = status_sefaz

    def calcular_impostos(self, produtos: List[Produto]) -> CalculoImpostosRetorno:
        """Calcula impostos federais e estaduais para uma lista de produtos."""
        return self.request({"Produtos": produtos}, "CalcularImpostos", CalculoImpostosRetorno)

    def pre_visualizar_nota_fiscal(
        self,
        pre_visualizar_envio: PreVisualizarNotaFiscalEnvio,
    ) -> PreVisualizarNotaFiscalRetorno:
        """Gera uma pré-visualização da DANFE sem consumir numeração SEFAZ."""
        return self.request(
            pre_visualizar_envio, "PreVisualizarNotaFiscal", PreVisualizarNotaFiscalRetorno
        )

    def buscar_nota_fiscal_servico(
        self,
        buscar_nota_fiscal_servico_envio: BuscarNotaFiscalServicoEnvio,
    ) -> NotaFiscalServicoRetorno:
        """Busca NFS-e emitidas/recebidas no período."""
        return self.request(
            buscar_nota_fiscal_servico_envio, "BuscarNotaFiscalServico", NotaFiscalServicoRetorno
        )

    def buscar_nota_fiscal(
        self,
        buscar_nota_fiscal_envio: BuscarNotaFiscalEnvio,
    ) -> BuscarNotaFiscalRetorno:
        """Busca NF-e / NFC-e / CT-e por período e direção (entrada/saída)."""
        return self.request(
            buscar_nota_fiscal_envio, "BuscarNotaFiscal", BuscarNotaFiscalRetorno
        )

    # Alias
    obter_notas_fiscais = buscar_nota_fiscal

    def consultar_cadastro_sefaz(
        self,
        consultar_cadastro_envio: ConsultarCadastroEnvio,
    ) -> ConsultarCadastroRetorno:
        """Consulta cadastro de contribuinte (IE/CNPJ/CPF) na SEFAZ."""
        return self.request(
            consultar_cadastro_envio, "ConsultarCadastroSefaz", ConsultarCadastroRetorno
        )

    def buscar_arquivo_sped(self, codigo: str) -> SpedRetorno:
        """Busca arquivo SPED previamente gerado pelo ``codigo``."""
        return self.request(
            "",
            "BuscarArquivoSped",
            SpedRetorno,
            query={"codigo": codigo},
        )

    # Alias
    obter_arquivo_sped = buscar_arquivo_sped
