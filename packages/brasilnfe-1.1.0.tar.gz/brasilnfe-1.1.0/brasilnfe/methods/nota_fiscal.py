"""Recurso ``NotaFiscal`` — emissão de documentos fiscais eletrônicos.

Paridade 1:1 com o SDK C# (principal), PHP e Node.
"""
from __future__ import annotations

from typing import Optional

from brasilnfe.models.nota_fiscal import (
    CTeEnvio,
    CTeRetorno,
    DCeEnvio,
    DCeRetorno,
    ManifestoTransporteEnvio,
    ManifestoTransporteRetorno,
    NFEnerComEnvio,
    NFEnerComRetorno,
    NotaFiscalComplementarEnvio,
    NotaFiscalEnvio,
    NotaFiscalLoteEnvio,
    NotaFiscalLoteRetorno,
    NotaFiscalRetorno,
    NotaFiscalServicoEnvio,
    NotaFiscalServicoRetorno,
)
from brasilnfe.request import BrasilNFeRequest


class NotaFiscal(BrasilNFeRequest):
    """Emissão de NF-e, NFC-e, NFS-e, CT-e, MDF-e, DC-e, NF3-e e complementar."""

    def enviar_nota_fiscal(
        self,
        nota_fiscal: NotaFiscalEnvio,
        crt: Optional[int] = None,
    ) -> NotaFiscalRetorno:
        """Emite NF-e (modelo 55) ou NFC-e (modelo 65).

        Args:
            nota_fiscal: payload da nota.
            crt: regime tributário (1=Simples Nacional, 2=Simples c/ Sublimite,
                3=Regime Normal, 4=MEI). Se fornecido, sobrescreve ``nota_fiscal.crt``.
        """
        if crt is not None:
            nota_fiscal.crt = crt
        return self.request(nota_fiscal, "EnviarNotaFiscal", NotaFiscalRetorno)

    def enviar_nota_fiscal_lote(
        self,
        nota_fiscal_lote: NotaFiscalLoteEnvio,
        crt: Optional[int] = None,
    ) -> NotaFiscalLoteRetorno:
        """Emite um lote de NF-e / NFC-e."""
        if crt is not None:
            nota_fiscal_lote.crt = crt
        return self.request(nota_fiscal_lote, "EnviarNotaFiscalLote", NotaFiscalLoteRetorno)

    def enviar_nota_fiscal_servico(
        self,
        nota_fiscal: NotaFiscalServicoEnvio,
    ) -> NotaFiscalServicoRetorno:
        """Emite NFS-e (Nota Fiscal de Serviço)."""
        return self.request(nota_fiscal, "EnviarNotaFiscalServico", NotaFiscalServicoRetorno)

    def enviar_nota_fiscal_complementar(
        self,
        nota_fiscal: NotaFiscalComplementarEnvio,
    ) -> NotaFiscalRetorno:
        """Emite NF-e complementar (geralmente ``finalidade=2``)."""
        return self.request(nota_fiscal, "EnviarNotaFiscalComplementar", NotaFiscalRetorno)

    def enviar_manifesto_transporte(
        self,
        manifesto_transporte: ManifestoTransporteEnvio,
    ) -> ManifestoTransporteRetorno:
        """Emite MDF-e (Manifesto Eletrônico de Documentos Fiscais - modelo 58)."""
        return self.request(
            manifesto_transporte, "EnviarManifestoTransporte", ManifestoTransporteRetorno
        )

    def enviar_conhecimento_transporte(
        self,
        cte_envio: CTeEnvio,
    ) -> CTeRetorno:
        """Emite CT-e (Conhecimento de Transporte Eletrônico - modelo 57)."""
        return self.request(cte_envio, "EnviarConhecimentoTransporte", CTeRetorno)

    def enviar_declaracao_conteudo(
        self,
        dce_envio: DCeEnvio,
    ) -> DCeRetorno:
        """Emite DC-e (Declaração de Conteúdo)."""
        return self.request(dce_envio, "EnviarDeclaracaoConteudo", DCeRetorno)

    def enviar_nf_enercom(
        self,
        nf_enercom_envio: NFEnerComEnvio,
    ) -> NFEnerComRetorno:
        """Emite NF3-e / NFCom (energia e comunicação)."""
        return self.request(nf_enercom_envio, "EnviarNFEnerCom", NFEnerComRetorno)
