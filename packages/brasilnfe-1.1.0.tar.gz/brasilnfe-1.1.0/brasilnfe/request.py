"""Camada HTTP do SDK Brasil NFe.

Encapsula o envio de requisições POST para a API, autenticação via tokens em
headers e desserialização JSON. Expõe ``BrasilNFeRequest`` como base para os
recursos (``NotaFiscal``, ``Eventos``, ``Consultas``, ``Arquivos``, ``Empresa``).
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Mapping, Optional, Type, TypeVar, Union
from urllib.parse import quote

import requests

from brasilnfe._serializer import BrasilNFeModel, from_dict, to_dict
from brasilnfe.exceptions import (
    BrasilNFeRequestError,
    BrasilNFeResponseError,
    BrasilNFeSerializationError,
)

T = TypeVar("T")

#: Versão pública do SDK (enviada como ``Package-Version`` no header).
SDK_VERSION = "1.1.0"

#: Timeout padrão (segundos) — igual aos SDKs C#/PHP/Node.
DEFAULT_TIMEOUT = 300

#: URL base padrão da API Brasil NFe.
DEFAULT_BASE_URL = "https://api.brasilnfe.com.br/services/"


class BrasilNFeRequest:
    """Base HTTP para recursos.

    Args:
        token: Token da empresa (API key). Obrigatório.
        url: URL base do recurso (ex.: ``https://api.brasilnfe.com.br/services/Fiscal/``).
        user_token: Token de usuário (opcional; necessário no recurso ``Empresa``).
        timeout: Timeout em segundos; por padrão ``300`` (5 minutos).
        session: :class:`requests.Session` customizada (útil para testes / retries).
    """

    def __init__(
        self,
        token: str,
        url: str,
        user_token: str = "",
        *,
        timeout: int = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
    ) -> None:
        if not token:
            from brasilnfe.exceptions import BrasilNFeAuthenticationError

            raise BrasilNFeAuthenticationError("token é obrigatório ao inicializar o SDK.")

        self._token = token
        self._user_token = user_token or ""
        self._url = url if url.endswith("/") else url + "/"
        self._timeout = timeout
        self._session = session or requests.Session()

    # ---------------------------------------------------------------- headers
    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "Token": self._token,
            "UserToken": self._user_token,
            "Package-Version": SDK_VERSION,
            "Package-Type": "python",
            "User-Agent": f"brasilnfe-python-sdk/{SDK_VERSION} "
            f"(requests/{requests.__version__})",
        }

    # ---------------------------------------------------------------- request
    def _post(
        self,
        metodo: str,
        payload: Union[BrasilNFeModel, Mapping[str, Any], str, list, None],
        *,
        query: Optional[Mapping[str, Any]] = None,
    ) -> requests.Response:
        """Executa o POST e devolve a Response bruta (sem desserializar)."""
        endpoint = self._url + metodo.lstrip("/")
        if query:
            qs = "&".join(
                f"{quote(str(k))}={quote(str(v))}" for k, v in query.items() if v is not None
            )
            if qs:
                sep = "&" if "?" in endpoint else "?"
                endpoint = f"{endpoint}{sep}{qs}"

        try:
            body = self._serialize_body(payload)
        except (TypeError, ValueError) as exc:
            raise BrasilNFeSerializationError(
                f"Falha ao serializar payload para '{metodo}': {exc}"
            ) from exc

        try:
            resp = self._session.post(
                endpoint,
                data=body.encode("utf-8") if isinstance(body, str) else body,
                headers=self._headers(),
                timeout=self._timeout,
            )
        except requests.exceptions.RequestException as exc:
            now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            raise BrasilNFeRequestError(
                f"{now} - Erro ao efetuar requisição HTTPS com Brasil NFe: {exc}",
                original=exc,
            ) from exc

        if not (200 <= resp.status_code < 300):
            raise BrasilNFeResponseError(
                f"Resposta HTTP inválida ({resp.status_code}) ao chamar '{metodo}': "
                f"{resp.text[:500]}",
                status_code=resp.status_code,
                body=resp.text,
            )
        return resp

    # ------------------------------------------------------------- high-level
    def request(
        self,
        object_sender: Any,
        metodo: str,
        return_type: Optional[Type[T]] = None,
        *,
        query: Optional[Mapping[str, Any]] = None,
        as_list: bool = False,
    ) -> Any:
        """Envia um POST e devolve DTO tipado (ou ``dict`` se ``return_type`` for ``None``).

        Args:
            object_sender: payload (dataclass, dict, lista ou string JSON).
            metodo: nome do endpoint relativo (ex.: ``"EnviarNotaFiscal"``).
            return_type: dataclass do SDK para desserializar a resposta.
            query: parâmetros de query string adicionais.
            as_list: se ``True``, desserializa como ``List[return_type]``.
        """
        resp = self._post(metodo, object_sender, query=query)
        return self._parse_response(resp, return_type, as_list=as_list)

    def request_bytes(
        self,
        object_sender: Any,
        metodo: str,
        *,
        query: Optional[Mapping[str, Any]] = None,
    ) -> bytes:
        """Envia um POST e retorna o resultado decodificado como ``bytes``.

        A API Brasil NFe sempre retorna strings base64 para downloads de XML,
        DANFE e arquivos de eventos. Esta função cuida dessa decodificação
        automaticamente.
        """
        import base64

        resp = self._post(metodo, object_sender, query=query)
        text = resp.text.strip()
        # Alguns endpoints retornam a string base64 envolvida em aspas JSON
        if text.startswith('"') and text.endswith('"'):
            text = json.loads(text)
        elif text.startswith("{"):
            # Resposta pode ser um objeto { "data": "base64..." } ou erro
            try:
                obj = json.loads(text)
            except json.JSONDecodeError as exc:
                raise BrasilNFeSerializationError(
                    f"Resposta inesperada em '{metodo}': {exc}"
                ) from exc
            if isinstance(obj, str):
                text = obj
            elif isinstance(obj, Mapping):
                text = str(
                    obj.get("data")
                    or obj.get("Base64File")
                    or obj.get("base64File")
                    or obj.get("Arquivo")
                    or ""
                )
                if not text and obj.get("Error"):
                    raise BrasilNFeResponseError(
                        f"Erro ao baixar arquivo '{metodo}': {obj.get('Error')}",
                        status_code=resp.status_code,
                        body=obj,
                    )
        try:
            return base64.b64decode(text)
        except (ValueError, TypeError) as exc:
            raise BrasilNFeSerializationError(
                f"Conteúdo de '{metodo}' não é base64 válido: {exc}"
            ) from exc

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _serialize_body(
        payload: Union[BrasilNFeModel, Mapping[str, Any], str, list, None],
    ) -> str:
        if payload is None:
            return "{}"
        if isinstance(payload, str):
            return payload
        data = to_dict(payload)
        return json.dumps(data, ensure_ascii=False, allow_nan=False, separators=(",", ":"))

    @staticmethod
    def _parse_response(
        resp: requests.Response,
        return_type: Optional[Type[T]],
        *,
        as_list: bool,
    ) -> Any:
        if not resp.content:
            return None

        try:
            data = resp.json()
        except (ValueError, json.JSONDecodeError) as exc:
            raise BrasilNFeSerializationError(
                f"Resposta não é JSON válido: {exc}; corpo: {resp.text[:200]}"
            ) from exc

        if return_type is None:
            return data

        if as_list:
            if not isinstance(data, list):
                data = [data] if data else []
            return [from_dict(return_type, item) for item in data]
        return from_dict(return_type, data)
