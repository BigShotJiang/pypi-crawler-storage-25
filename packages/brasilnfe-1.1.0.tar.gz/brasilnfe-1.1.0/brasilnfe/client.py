"""Cliente principal do SDK Brasil NFe.

Agrega os 5 recursos (``nota_fiscal``, ``eventos``, ``consultas``,
``arquivos``, ``empresa``) em uma única fachada. Mesma arquitetura dos
SDKs C#, PHP e Node.
"""
from __future__ import annotations

from typing import Optional

import requests

from brasilnfe.exceptions import BrasilNFeAuthenticationError
from brasilnfe.methods import Arquivos, Consultas, Empresa, Eventos, NotaFiscal
from brasilnfe.request import DEFAULT_BASE_URL, DEFAULT_TIMEOUT


class BrasilNFe:
    """Cliente principal da API Brasil NFe.

    Args:
        token: Token da empresa (obrigatório). Obtido no portal
            https://www.brasilnfe.com.br.
        user_token: Token do usuário (necessário apenas para o recurso
            :attr:`empresa`).
        url: URL base da API. Por padrão aponta para produção.
        timeout: Timeout (segundos) para cada requisição HTTP. Padrão 300.
        session: :class:`requests.Session` customizada (útil para testes ou
            ao configurar retries via ``HTTPAdapter``).

    Exemplo:
        >>> from brasilnfe import BrasilNFe
        >>> client = BrasilNFe(token="SEU_TOKEN")
        >>> status = client.consultas.status_sefaz(
        ...     StatusSefazEnvio(modelo_documento=55, tipo_ambiente=2)
        ... )
        >>> print(status.status_sefaz.ds_status_resposta_sefaz)
    """

    def __init__(
        self,
        token: str,
        user_token: str = "",
        url: str = DEFAULT_BASE_URL,
        *,
        timeout: int = DEFAULT_TIMEOUT,
        session: Optional[requests.Session] = None,
    ) -> None:
        if not token:
            raise BrasilNFeAuthenticationError(
                "token é obrigatório ao inicializar o SDK Brasil NFe."
            )

        base = url if url.endswith("/") else url + "/"
        fiscal_url = base + "Fiscal/"
        empresa_url = base + "Empresa/"

        self._token = token
        self._user_token = user_token or ""
        self._url = base
        self._timeout = timeout
        self._session = session

        self._nota_fiscal = NotaFiscal(
            token, fiscal_url, user_token, timeout=timeout, session=session
        )
        self._eventos = Eventos(
            token, fiscal_url, user_token, timeout=timeout, session=session
        )
        self._consultas = Consultas(
            token, fiscal_url, user_token, timeout=timeout, session=session
        )
        self._arquivos = Arquivos(
            token, fiscal_url, user_token, timeout=timeout, session=session
        )

        self._empresa: Optional[Empresa] = None
        if user_token:
            self._empresa = Empresa(
                token, empresa_url, user_token, timeout=timeout, session=session
            )

    # ---------------------------------------------------------------- resources
    @property
    def nota_fiscal(self) -> NotaFiscal:
        """Emissão de NF-e / NFC-e / NFS-e / CT-e / MDF-e / DC-e / NF3-e."""
        return self._nota_fiscal

    @property
    def eventos(self) -> Eventos:
        """Cancelamento, CC-e, inutilização, manifestação, encerramento MDF-e."""
        return self._eventos

    @property
    def consultas(self) -> Consultas:
        """Status SEFAZ, busca de notas, consulta de cadastro, cálculo de impostos."""
        return self._consultas

    @property
    def arquivos(self) -> Arquivos:
        """SPED, SINTEGRA, FCI, download de XML/DANFE."""
        return self._arquivos

    @property
    def empresa(self) -> Empresa:
        """Cadastro de empresas e certificados digitais.

        Requer ``user_token`` fornecido no construtor.

        Raises:
            BrasilNFeAuthenticationError: se ``user_token`` não foi configurado.
        """
        if self._empresa is None:
            raise BrasilNFeAuthenticationError(
                "user_token não fornecido na inicialização. "
                "Informe-o em BrasilNFe(token, user_token='...') para usar o recurso `empresa`."
            )
        return self._empresa

    # ---------------------------------------------------------------- utils
    @property
    def token(self) -> str:
        """Token de empresa usado nas requisições."""
        return self._token

    @property
    def user_token(self) -> str:
        """Token de usuário (pode ser string vazia)."""
        return self._user_token

    @property
    def url(self) -> str:
        """URL base da API (com barra final)."""
        return self._url

    def __repr__(self) -> str:  # pragma: no cover - cosmético
        masked = f"{self._token[:4]}…{self._token[-4:]}" if len(self._token) > 8 else "***"
        return f"BrasilNFe(token={masked!r}, url={self._url!r})"
