"""Testes do ``BrasilNFeHelper`` (rateio proporcional)."""
from __future__ import annotations

from dataclasses import dataclass

import pytest

from brasilnfe import BrasilNFeHelper, TipoRateio


@dataclass
class _Item:
    valor_total: float
    valor_frete: float = 0.0


class TestRateio:
    def test_ratear_substituir(self):
        itens = [_Item(valor_total=100.0), _Item(valor_total=300.0)]
        BrasilNFeHelper.ratear(
            itens,
            valor_total=40.0,
            seletor=lambda i: i.valor_frete,
            seletor_proporcao=lambda i: i.valor_total,
            tipo_rateio=TipoRateio.SUBSTITUIR,
            atualizar_item=lambda i, v: setattr(i, "valor_frete", v),
        )
        assert itens[0].valor_frete == pytest.approx(10.0, rel=1e-4)
        assert itens[1].valor_frete == pytest.approx(30.0, rel=1e-4)
        assert sum(i.valor_frete for i in itens) == pytest.approx(40.0)

    def test_ratear_somar(self):
        itens = [_Item(valor_total=100.0, valor_frete=5.0)]
        BrasilNFeHelper.ratear(
            itens,
            valor_total=10.0,
            seletor=lambda i: i.valor_frete,
            seletor_proporcao=lambda i: i.valor_total,
            tipo_rateio=TipoRateio.SOMAR,
            atualizar_item=lambda i, v: setattr(i, "valor_frete", v),
        )
        assert itens[0].valor_frete == pytest.approx(15.0)

    def test_ratear_lista_vazia(self):
        BrasilNFeHelper.ratear(
            [],
            valor_total=100.0,
            seletor=lambda i: 0,
            seletor_proporcao=lambda i: 0,
            tipo_rateio=TipoRateio.SUBSTITUIR,
            atualizar_item=lambda i, v: None,
        )

    def test_soma_bate_exato_apos_arredondamento(self):
        """Diferença de arredondamento vai sempre para o último item."""
        itens = [_Item(valor_total=33.33) for _ in range(3)]
        BrasilNFeHelper.ratear(
            itens,
            valor_total=10.0,
            seletor=lambda i: i.valor_frete,
            seletor_proporcao=lambda i: i.valor_total,
            tipo_rateio=TipoRateio.SUBSTITUIR,
            atualizar_item=lambda i, v: setattr(i, "valor_frete", v),
        )
        assert round(sum(i.valor_frete for i in itens), 2) == 10.0
