"""Testes da fachada ``BrasilNFe``."""
from __future__ import annotations

import pytest

from brasilnfe import (
    Arquivos,
    BrasilNFe,
    BrasilNFeAuthenticationError,
    Consultas,
    Empresa,
    Eventos,
    NotaFiscal,
)


class TestClientInit:
    def test_requires_token(self):
        with pytest.raises(BrasilNFeAuthenticationError):
            BrasilNFe(token="")

    def test_default_url(self):
        c = BrasilNFe(token="abc")
        assert c.url == "https://api.brasilnfe.com.br/services/"

    def test_custom_url_adds_trailing_slash(self):
        c = BrasilNFe(token="abc", url="https://example.com/api")
        assert c.url == "https://example.com/api/"

    def test_resources_are_instantiated(self):
        c = BrasilNFe(token="abc")
        assert isinstance(c.nota_fiscal, NotaFiscal)
        assert isinstance(c.eventos, Eventos)
        assert isinstance(c.consultas, Consultas)
        assert isinstance(c.arquivos, Arquivos)

    def test_empresa_requires_user_token(self):
        c = BrasilNFe(token="abc")
        with pytest.raises(BrasilNFeAuthenticationError):
            _ = c.empresa

    def test_empresa_available_when_user_token_set(self):
        c = BrasilNFe(token="abc", user_token="user123")
        assert isinstance(c.empresa, Empresa)
