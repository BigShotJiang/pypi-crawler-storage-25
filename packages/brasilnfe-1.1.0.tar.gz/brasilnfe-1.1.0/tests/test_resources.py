"""Testes dos 5 recursos usando ``responses`` para mockar a API."""
from __future__ import annotations

from datetime import datetime

import responses

from brasilnfe import (
    BrasilNFe,
    CancelarNotaFiscalEnvio,
    Cliente,
    NotaFiscalEnvio,
    PegarArquivoEnvio,
    Produto,
    StatusSefazEnvio,
)

BASE = "https://api.brasilnfe.com.br/services/Fiscal/"
EMPRESA_BASE = "https://api.brasilnfe.com.br/services/Empresa/"


class TestConsultas:
    def test_status_sefaz(self, mock_api, client: BrasilNFe):
        mock_api.add(
            responses.POST,
            BASE + "StatusSefaz",
            json={
                "Error": "",
                "Avisos": [],
                "StatusSefaz": {
                    "Versao": "4.00",
                    "CodStatusRespostaSefaz": 107,
                    "DsStatusRespostaSefaz": "Serviço em operação",
                    "CodTipoAmbiente": 2,
                },
            },
        )
        resp = client.consultas.status_sefaz(
            StatusSefazEnvio(modelo_documento=55, tipo_ambiente=2)
        )
        assert resp.ok
        assert resp.status_sefaz.versao == "4.00"
        assert resp.status_sefaz.cod_status_resposta_sefaz == 107

    def test_buscar_arquivo_sped_uses_query(self, mock_api, client: BrasilNFe):
        mock_api.add(
            responses.POST,
            BASE + "BuscarArquivoSped",
            json={"Error": "", "Codigo": "ABC123", "Status": 1},
            match_querystring=False,
        )
        resp = client.consultas.buscar_arquivo_sped("ABC123")
        assert resp.codigo == "ABC123"
        assert "codigo=ABC123" in mock_api.calls[0].request.url


class TestNotaFiscal:
    def test_enviar_nota_fiscal(self, mock_api, client: BrasilNFe):
        mock_api.add(
            responses.POST,
            BASE + "EnviarNotaFiscal",
            json={
                "Error": "",
                "Avisos": [],
                "ReturnNF": {
                    "Numero": 1,
                    "Serie": 1,
                    "ChaveNF": "35250312345678901234567890123456789012345678",
                    "CodStatusRespostaSefaz": 100,
                    "DsStatusRespostaSefaz": "Autorizado o uso da NF-e",
                    "Ok": True,
                },
                "Base64Xml": "UEhJVEE=",
            },
        )
        nf = NotaFiscalEnvio(
            modelo_documento=55,
            tipo_ambiente=2,
            finalidade=1,
            natureza_operacao="VENDA",
            data_emissao=datetime(2025, 3, 15, 10, 0, 0),
            cliente=Cliente(cpf_cnpj="11144477735", nm_cliente="Cliente Teste"),
            produtos=[
                Produto(
                    nm_produto="Produto A",
                    cod_produto_servico="001",
                    quantidade=1,
                    valor_unitario=10.0,
                    valor_total=10.0,
                    cfop=5102,
                    ncm="12345678",
                )
            ],
        )
        resp = client.nota_fiscal.enviar_nota_fiscal(nf, crt=1)
        assert resp.ok
        assert resp.return_nf.ok is True
        assert resp.return_nf.cod_status_resposta_sefaz == 100
        # Verifica que crt foi aplicado ao payload
        body = mock_api.calls[0].request.body
        assert b'"CRT":1' in body


class TestEventos:
    def test_cancelar_nota_fiscal(self, mock_api, client: BrasilNFe):
        mock_api.add(
            responses.POST,
            BASE + "CancelNF",
            json={
                "Error": "",
                "DsEvento": "Cancelamento de NF-e",
                "NuProtocolo": "135250000000001",
                "Status": 1,
                "CodStatusRespostaSefaz": 135,
            },
        )
        resp = client.eventos.cancelar_nota_fiscal(
            CancelarNotaFiscalEnvio(
                chave_nf="35250312345678901234567890123456789012345678",
                justificativa="Erro na emissão da NF-e — cancelamento solicitado.",
                tipo_documento=0,
            )
        )
        assert resp.status == 1
        assert resp.nu_protocolo == "135250000000001"


class TestArquivos:
    def test_pegar_arquivo_retorna_bytes(self, mock_api, client: BrasilNFe):
        # "UEhJVEE=" em base64 → bytes "PHITA"
        mock_api.add(
            responses.POST,
            BASE + "GetFile",
            json="UEhJVEE=",
        )
        content = client.arquivos.pegar_arquivo(
            PegarArquivoEnvio(
                chaves=["35250312345678901234567890123456789012345678"],
                file_type=2,
            )
        )
        assert content == b"PHITA"


class TestEmpresa:
    def test_buscar_empresa(self, mock_api, client: BrasilNFe):
        mock_api.add(
            responses.POST,
            EMPRESA_BASE + "BuscarEmpresa",
            json={"CNPJ": "12345678000100", "RzSocial": "ACME LTDA", "CRT": 3},
        )
        resp = client.empresa.buscar_empresa()
        assert resp.cnpj == "12345678000100"
        assert resp.rz_social == "ACME LTDA"
        assert resp.crt == 3
