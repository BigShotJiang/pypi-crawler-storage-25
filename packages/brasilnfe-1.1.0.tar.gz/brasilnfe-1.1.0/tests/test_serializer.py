"""Testes do serializer interno (snake_case <-> PascalCase)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from brasilnfe._serializer import (
    BrasilNFeModel,
    from_dict,
    pascal_to_snake,
    snake_to_pascal,
    to_dict,
)


class TestCaseConversion:
    def test_snake_to_pascal(self):
        assert snake_to_pascal("nm_produto") == "NmProduto"
        assert snake_to_pascal("cpf_cnpj") == "CpfCnpj"
        assert snake_to_pascal("serie") == "Serie"
        assert snake_to_pascal("") == ""

    def test_pascal_to_snake(self):
        assert pascal_to_snake("NmProduto") == "nm_produto"
        assert pascal_to_snake("CpfCnpj") == "cpf_cnpj"
        assert pascal_to_snake("valorNf") == "valor_nf"
        assert pascal_to_snake("Serie") == "serie"


@dataclass
class _Inner(BrasilNFeModel):
    valor: Optional[float] = field(default=None, metadata={"json": "Valor"})
    descricao: Optional[str] = field(default=None, metadata={"json": "Descricao"})


@dataclass
class _Outer(BrasilNFeModel):
    numero: Optional[int] = field(default=None, metadata={"json": "Numero"})
    data_emissao: Optional[datetime] = field(default=None, metadata={"json": "DataEmissao"})
    itens: List[_Inner] = field(default_factory=list, metadata={"json": "Itens"})


class TestSerialization:
    def test_to_dict_omits_none(self):
        o = _Outer(numero=123)
        assert to_dict(o) == {"Numero": 123}

    def test_to_dict_nested(self):
        o = _Outer(
            numero=1,
            data_emissao=datetime(2025, 3, 15, 14, 30, 0),
            itens=[_Inner(valor=10.5, descricao="Produto X")],
        )
        result = to_dict(o)
        assert result == {
            "Numero": 1,
            "DataEmissao": "2025-03-15T14:30:00",
            "Itens": [{"Valor": 10.5, "Descricao": "Produto X"}],
        }

    def test_from_dict_pascalcase(self):
        data = {"Numero": 42, "Itens": [{"Valor": 3.14, "Descricao": "ABC"}]}
        o = from_dict(_Outer, data)
        assert o.numero == 42
        assert len(o.itens) == 1
        assert o.itens[0].valor == 3.14

    def test_from_dict_camelcase(self):
        data = {"numero": 7, "dataEmissao": "2025-04-01T10:00:00"}
        o = from_dict(_Outer, data)
        assert o.numero == 7
        assert o.data_emissao == datetime(2025, 4, 1, 10, 0, 0)

    def test_from_dict_ignores_unknown_fields(self):
        data = {"Numero": 1, "CampoQueNaoExiste": "ignorado"}
        o = from_dict(_Outer, data)
        assert o.numero == 1

    def test_roundtrip(self):
        original = _Outer(numero=99, itens=[_Inner(valor=1.0)])
        result = from_dict(_Outer, to_dict(original))
        assert result.numero == original.numero
        assert result.itens[0].valor == original.itens[0].valor
