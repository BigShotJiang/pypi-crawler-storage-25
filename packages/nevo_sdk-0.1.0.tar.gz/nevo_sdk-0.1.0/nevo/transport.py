"""Low-level WebSocket transport: connect, auth, reconnect, message iteration.

No knowledge of events or handlers — just frames in and frames out. The
client layer wraps this.

Reconnect policy:

- Transient failures (connection closed, TCP reset, timeouts) trigger an
  exponential jittered backoff and reconnect. Bounded by ``max_backoff``.
- HTTP 401 at upgrade → :class:`~nevo.AuthError`, terminal.
- WebSocket close codes in 4000–4099 are application-level protocol
  errors that retrying won't help with — terminal.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import random
import sys
from collections.abc import AsyncIterator
from typing import Any

from websockets.asyncio.client import ClientConnection, connect
from websockets.exceptions import ConnectionClosed, InvalidStatus

from ._version import __version__
from .exceptions import AuthError
from .exceptions import ConnectionError as NevoConnectionError

_USER_AGENT = (
    f"nevo-python/{__version__} "
    f"(python/{sys.version_info.major}.{sys.version_info.minor})"
)


class Transport:
    """Manages the WebSocket lifecycle and yields decoded frames."""

    def __init__(
        self,
        url: str,
        token: str,
        *,
        max_backoff: float = 30.0,
        logger: logging.Logger | None = None,
    ) -> None:
        self._url = url
        self._token = token
        self._max_backoff = max_backoff
        self._log = logger or logging.getLogger("nevo.transport")
        self._ws: ClientConnection | None = None
        self._closed = False

    async def messages(self) -> AsyncIterator[dict[str, Any]]:
        """Yield parsed JSON frames. Reconnects transparently.

        Raises:
            AuthError: Server returned 401 at upgrade, or closed with a
                code in the auth range (4001).
            ConnectionError: Server closed with a 4000–4099 protocol error
                the SDK can't recover from.
        """
        backoff = 1.0

        while not self._closed:
            try:
                async with connect(
                    self._url,
                    additional_headers={
                        "Authorization": f"Bearer {self._token}",
                        "User-Agent": _USER_AGENT,
                    },
                    # The server doesn't speak app-level ping/pong, so rely
                    # on the WS library's TCP-level ping to keep proxies
                    # from timing out idle connections.
                    ping_interval=20,
                    ping_timeout=20,
                    close_timeout=5,
                ) as ws:
                    self._ws = ws
                    backoff = 1.0  # reset on successful connect

                    async for raw in ws:
                        if isinstance(raw, bytes):
                            raw = raw.decode("utf-8", errors="replace")
                        try:
                            msg = json.loads(raw)
                        except json.JSONDecodeError:
                            self._log.warning("dropped non-JSON frame (%d bytes)", len(raw))
                            continue
                        if not isinstance(msg, dict):
                            self._log.warning("dropped non-object frame: %r", msg)
                            continue
                        yield msg

            except AuthError:
                raise

            except InvalidStatus as exc:
                status = getattr(exc.response, "status_code", None)
                if status == 401:
                    raise AuthError("invalid or expired token") from exc
                self._log.warning(
                    "connection rejected (HTTP %s); reconnecting in %.1fs", status, backoff
                )
                await self._sleep_backoff(backoff)
                backoff = min(backoff * 2, self._max_backoff)

            except ConnectionClosed as exc:
                if self._closed:
                    return
                code = getattr(exc, "code", None) or 1006
                # 4001 is the Nevo convention for auth rejection post-handshake.
                # 4000–4099 is the application-reserved range — terminal protocol
                # errors the SDK can't fix by reconnecting.
                if code == 4001:
                    raise AuthError(f"server closed with auth code {code}: {exc}") from exc
                if 4000 <= code < 4100:
                    raise NevoConnectionError(
                        f"server closed with protocol code {code}: {exc}"
                    ) from exc
                self._log.warning(
                    "connection lost (code=%s: %s); reconnecting in %.1fs",
                    code, exc, backoff,
                )
                await self._sleep_backoff(backoff)
                backoff = min(backoff * 2, self._max_backoff)

            except (OSError, asyncio.TimeoutError) as exc:
                if self._closed:
                    return
                self._log.warning(
                    "connection lost (%s: %s); reconnecting in %.1fs",
                    type(exc).__name__, exc, backoff,
                )
                await self._sleep_backoff(backoff)
                backoff = min(backoff * 2, self._max_backoff)

            finally:
                self._ws = None

    async def close(self) -> None:
        """Close the WebSocket and prevent further reconnects."""
        self._closed = True
        ws = self._ws
        if ws is not None:
            with contextlib.suppress(Exception):
                await ws.close()

    async def _sleep_backoff(self, backoff: float) -> None:
        # Jitter prevents thundering-herd reconnects after a server-wide drop.
        jittered = backoff + random.uniform(0, min(1.0, backoff * 0.1))
        await asyncio.sleep(jittered)
