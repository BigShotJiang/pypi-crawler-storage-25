"""Thin HTTP client for Nevo's REST surface.

Responsibilities:

- Persist a single ``httpx.AsyncClient`` for connection pooling.
- Send ``Authorization`` + ``User-Agent`` on every request.
- Retry transient failures (network errors, 5xx, 429) with exponential
  jittered backoff, honoring ``Retry-After`` when present.
- Map every failure to a typed ``ReplyError`` subclass so callers can
  distinguish transient from permanent without string-matching.

The token is held in an ``httpx.AsyncClient`` header; it's never included
in exception messages or log output.
"""

from __future__ import annotations

import asyncio
import logging
import random
import sys
from typing import Any

import httpx

from ._version import __version__
from .exceptions import AuthError, NetworkError, RequestError, ServerError

_USER_AGENT = (
    f"nevo-python/{__version__} "
    f"(python/{sys.version_info.major}.{sys.version_info.minor})"
)

# Transient statuses that the SDK retries automatically.
_RETRY_STATUSES = {408, 429, 500, 502, 503, 504}


class HTTPClient:
    """Wraps ``httpx.AsyncClient`` with retry + error-mapping for Nevo."""

    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        timeout: float = 10.0,
        max_retries: int = 3,
        logger: logging.Logger | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._max_retries = max_retries
        self._log = logger or logging.getLogger("nevo.http")
        self._client: httpx.AsyncClient | None = None

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "Authorization": f"Bearer {self._token}",
                    "User-Agent": _USER_AGENT,
                },
                timeout=self._timeout,
            )
        return self._client

    async def post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST ``payload`` as JSON, with retries. Returns the parsed JSON body."""
        client = await self._ensure_client()
        attempt = 0
        while True:
            attempt += 1
            try:
                res = await client.post(path, json=payload)
            except httpx.HTTPError as exc:
                # Network-layer failure (DNS, connection reset, read timeout).
                # Never leak the token — httpx exceptions carry the URL but
                # not the Authorization header; we use repr(exc) defensively.
                if attempt <= self._max_retries:
                    await self._sleep_backoff(attempt)
                    continue
                raise NetworkError(f"network error after {attempt} attempts: {exc!r}") from exc

            if res.status_code == 401:
                # No retry, no body leak — just fail.
                raise AuthError("invalid or expired token")

            if res.status_code in _RETRY_STATUSES and attempt <= self._max_retries:
                await self._sleep_retry(res, attempt)
                continue

            if 500 <= res.status_code < 600:
                code, message, request_id = _extract_error(res)
                raise ServerError(
                    message, status_code=res.status_code, code=code, request_id=request_id,
                )
            if not (200 <= res.status_code < 300):
                code, message, request_id = _extract_error(res)
                raise RequestError(
                    message, status_code=res.status_code, code=code, request_id=request_id,
                )

            try:
                return res.json()
            except ValueError as exc:
                raise RequestError(
                    f"invalid JSON in response: {exc}",
                    status_code=res.status_code,
                    request_id=res.headers.get("X-Request-ID"),
                ) from exc

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def _sleep_retry(self, res: httpx.Response, attempt: int) -> None:
        retry_after = _parse_retry_after(res.headers.get("Retry-After"))
        delay = retry_after if retry_after is not None else _backoff_delay(attempt)
        self._log.debug(
            "retrying request (attempt=%d status=%d delay=%.2fs)",
            attempt, res.status_code, delay,
        )
        await asyncio.sleep(delay)

    async def _sleep_backoff(self, attempt: int) -> None:
        delay = _backoff_delay(attempt)
        self._log.debug("retrying after network error (attempt=%d delay=%.2fs)", attempt, delay)
        await asyncio.sleep(delay)


def _backoff_delay(attempt: int) -> float:
    """Exponential backoff with full jitter: random uniform in [0, cap]
    where cap doubles each attempt. Bounds the worst-case wait."""
    cap = min(0.5 * (2 ** (attempt - 1)), 8.0)
    return random.uniform(0, cap)


def _parse_retry_after(value: str | None) -> float | None:
    """Parse a ``Retry-After`` header value. Only honors the seconds form
    (the HTTP-date form is valid but overkill to handle in an SDK)."""
    if not value:
        return None
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return None
    if seconds < 0 or seconds > 60:
        # Clamp — we don't want a hostile server parking an SDK for an hour.
        return None
    return seconds


def _extract_error(res: httpx.Response) -> tuple[str | None, str, str | None]:
    """Pull ``error.code`` + ``error.message`` + request id out of a response.
    Falls back gracefully when the body isn't the expected JSON shape."""
    request_id = res.headers.get("X-Request-ID")
    try:
        body = res.json()
    except ValueError:
        return None, f"HTTP {res.status_code}: {res.text[:200]}", request_id
    err = body.get("error") if isinstance(body, dict) else None
    if isinstance(err, dict):
        return err.get("code"), err.get("message") or f"HTTP {res.status_code}", request_id
    return None, f"HTTP {res.status_code}", request_id
