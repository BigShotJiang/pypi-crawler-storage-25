"""Nevo Python SDK.

Open a WebSocket to Nevo, hand every event to your async handler, and
send replies back over HTTP. See :class:`Nevo` for the main entry point.
"""

from ._version import __version__
from .client import Nevo
from .events import Attachment, Channel, EmailData, Event, WebhookData
from .exceptions import (
    AuthError,
    ConnectionError,
    HandlerTimeoutError,
    NetworkError,
    NevoError,
    ReplyError,
    RequestError,
    ServerError,
    UnsupportedChannelError,
)
from .replies import ReplyReceipt

__all__ = [
    "Attachment",
    "AuthError",
    "Channel",
    "ConnectionError",
    "EmailData",
    "Event",
    "HandlerTimeoutError",
    "NetworkError",
    "Nevo",
    "NevoError",
    "ReplyError",
    "ReplyReceipt",
    "RequestError",
    "ServerError",
    "UnsupportedChannelError",
    "WebhookData",
    "__version__",
]
