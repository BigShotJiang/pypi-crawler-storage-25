"""Reply submission: param validation + receipt shape.

The actual HTTP send lives in `client.py` — this module keeps the pure
data + validation code together so it's easy to test without standing up
a client."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .exceptions import RequestError, UnsupportedChannelError

# Per-channel allowlists. `text` is the only universal param; everything
# else is channel-scoped so passing e.g. subject on a discord reply fails
# loudly instead of being silently dropped. Adding a channel = add a row.
_ALLOWED_PARAMS: dict[str, set[str]] = {
    "email": {"text", "html", "subject", "cc", "bcc"},
}


def validate_reply_params(channel_type: str, params: dict[str, Any]) -> None:
    """Raise if the channel doesn't accept replies, or if the caller passed
    params the channel can't use. Runs before any network call."""
    allowed = _ALLOWED_PARAMS.get(channel_type)
    if allowed is None:
        raise UnsupportedChannelError(channel_type)

    provided = {k for k, v in params.items() if v is not None}
    disallowed = provided - allowed
    if disallowed:
        raise RequestError(
            f"{', '.join(sorted(disallowed))} "
            f"{'is' if len(disallowed) == 1 else 'are'} not supported for "
            f"{channel_type} replies. valid params for {channel_type}: "
            f"{', '.join(sorted(allowed))}.",
            status_code=400,
            code="invalid_param",
        )

    if not params.get("text") or not str(params["text"]).strip():
        raise RequestError(
            "reply text is required.",
            status_code=400,
            code="body_required",
        )


@dataclass(frozen=True)
class ReplyReceipt:
    """Acknowledgement from Nevo that the reply was accepted for dispatch.
    The actual send happens asynchronously in the worker."""

    reply_id: str
    accepted_at: datetime

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> ReplyReceipt:
        return cls(
            reply_id=payload["reply_id"],
            accepted_at=_parse_iso8601(payload["accepted_at"]),
        )


def _parse_iso8601(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)
