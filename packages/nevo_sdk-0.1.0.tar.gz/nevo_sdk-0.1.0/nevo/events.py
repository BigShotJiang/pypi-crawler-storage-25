"""Dataclasses mirroring the wire format emitted by Nevo's realtime WebSocket.

The :class:`Event` dataclass is the sole public surface here. It ships with
typed accessors (:attr:`Event.webhook`, :attr:`Event.email`) populated
based on ``event.type`` so handlers can branch without dict-digging, and
an :meth:`Event.reply` coroutine that uses the current async context to
find the active :class:`~nevo.Nevo` client.
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .client import Nevo
    from .replies import ReplyReceipt

# Set by the client's dispatcher for the duration of a handler call. Lets
# `event.reply(...)` resolve the owning client without mutating Event or
# holding a back-reference. contextvars is async-safe — each task gets its
# own copy of the context.
_current_client: contextvars.ContextVar[Nevo | None] = contextvars.ContextVar(
    "nevo_current_client", default=None
)


@dataclass(frozen=True)
class Channel:
    """Minimal channel metadata attached to every event. ``type`` determines
    which :attr:`Event.webhook` / :attr:`Event.email` accessor is populated."""

    id: str
    label: str
    type: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Channel:
        return cls(
            id=str(data["id"]),
            label=data.get("label", ""),
            type=data.get("type", ""),
        )


@dataclass(frozen=True)
class Attachment:
    """An email attachment — metadata only. The body bytes are not streamed
    over WebSocket; fetch via the attachment's signed ``url`` when present."""

    filename: str
    content_type: str
    size_bytes: int
    url: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Attachment:
        return cls(
            filename=data.get("filename", ""),
            content_type=data.get("content_type", ""),
            size_bytes=int(data.get("size_bytes", 0)),
            url=data.get("url"),
        )


@dataclass(frozen=True)
class WebhookData:
    """The ``data`` block for a ``webhook.received`` event. ``body_encoding``
    tells you how to read the body: ``"json"`` parses into ``body``,
    ``"text"`` puts the string in ``body``, ``"base64"`` puts the raw bytes
    (base64-encoded) in ``body_raw_b64``."""

    method: str
    path: str
    headers: dict[str, str]
    body_encoding: str
    body: Any | None
    body_raw_b64: str
    body_size_bytes: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WebhookData:
        return cls(
            method=data.get("method", ""),
            path=data.get("path", ""),
            headers=data.get("headers") or {},
            body_encoding=data.get("body_encoding", ""),
            body=data.get("body"),
            body_raw_b64=data.get("body_raw_b64", ""),
            body_size_bytes=int(data.get("body_size_bytes", 0)),
        )


@dataclass(frozen=True)
class EmailData:
    """The ``data`` block for an ``email.received`` event. ``text`` / ``html``
    are populated by the backend from the provider's inbound body; either
    may be empty if enrichment failed. ``from_`` avoids the Python keyword."""

    resend_email_id: str
    message_id: str
    from_: str
    to: list[str]
    matched_address: str
    cc: list[str]
    bcc: list[str]
    subject: str
    text: str
    html: str
    html_url: str
    attachments: list[Attachment]
    received_at: datetime | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EmailData:
        received = data.get("received_at")
        return cls(
            resend_email_id=data.get("resend_email_id", ""),
            message_id=data.get("message_id", ""),
            from_=data.get("from", ""),
            to=list(data.get("to") or []),
            matched_address=data.get("matched_address", ""),
            cc=list(data.get("cc") or []),
            bcc=list(data.get("bcc") or []),
            subject=data.get("subject", ""),
            text=data.get("text", ""),
            html=data.get("html", ""),
            html_url=data.get("html_url", ""),
            attachments=[Attachment.from_dict(a) for a in (data.get("attachments") or [])],
            received_at=_parse_iso8601(received) if received else None,
        )


@dataclass(frozen=True)
class Event:
    """A single event delivered to the SDK handler.

    Attributes:
        id: ULID. Stable across live + replay deliveries.
        schema: Schema version of the payload (e.g. ``nevo.event.v1``).
        type: ``webhook.received`` or ``email.received``.
        origin: ``live`` or ``replay``. Use for idempotency when you don't
            want to double-process a replay.
        created_at: Server-side ingest time.
        project_id: The Nevo project id.
        channel: The channel that received this event.
        data: Raw source payload as a dict — same shape as the provider sent.
        prompt_ready: LLM-ready text rendering of the event.
        prompt_ready_version: Renderer version stamp (for diffing runs).
        webhook: Typed accessor for ``type == "webhook.received"``.
        email: Typed accessor for ``type == "email.received"``.
    """

    id: str
    schema: str
    type: str
    origin: str
    created_at: datetime
    project_id: str
    channel: Channel
    data: dict[str, Any]
    prompt_ready: str
    prompt_ready_version: int = 0

    # Typed accessors. Exactly one is non-None, matching `type`.
    webhook: WebhookData | None = field(default=None)
    email: EmailData | None = field(default=None)

    async def reply(
        self,
        text: str,
        *,
        html: str | None = None,
        subject: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
    ) -> ReplyReceipt:
        """Send a reply to this event. Raises `UnsupportedChannelError` if
        the channel type doesn't accept replies, or `ReplyError` if params
        are invalid or the server rejects the request.

        Must be called from within a handler — the SDK uses the current
        async context to find the active Nevo client.
        """
        client = _current_client.get()
        if client is None:
            raise RuntimeError(
                "event.reply() must be called from inside an @nevo.on_event() handler. "
                "Use nevo.reply(event, ...) from outside the handler."
            )
        return await client.reply(
            self, text=text, html=html, subject=subject, cc=cc, bcc=bcc,
        )

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> Event:
        raw_data = payload.get("data") or {}
        etype = payload.get("type", "")

        webhook: WebhookData | None = None
        email: EmailData | None = None
        if etype == "webhook.received" and isinstance(raw_data, dict):
            webhook = WebhookData.from_dict(raw_data)
        elif etype == "email.received" and isinstance(raw_data, dict):
            email = EmailData.from_dict(raw_data)

        return cls(
            id=payload["id"],
            schema=payload.get("schema", ""),
            type=etype,
            origin=payload.get("origin", "live"),
            created_at=_parse_iso8601(payload["created_at"]),
            project_id=str(payload.get("project_id", "")),
            channel=Channel.from_dict(payload.get("channel") or {}),
            data=raw_data if isinstance(raw_data, dict) else {},
            prompt_ready=payload.get("prompt_ready", ""),
            prompt_ready_version=int(payload.get("prompt_ready_version", 0)),
            webhook=webhook,
            email=email,
        )


def _parse_iso8601(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)
