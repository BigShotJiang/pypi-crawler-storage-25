"""Exception hierarchy.

Catching strategy:

- ``NevoError`` — catch-all for anything the SDK raises.
- ``AuthError`` — token is invalid. Not retryable; fix the key.
- ``ConnectionError`` — WebSocket couldn't connect after retries.
- ``HandlerTimeoutError`` — a handler exceeded ``handler_timeout``.
- ``ReplyError`` — reply failed for any reason. Inspect ``.is_transient``
  to decide whether retrying makes sense. Specific subclasses let callers
  match more precisely when they need to.
"""

from __future__ import annotations


class NevoError(Exception):
    """Base for all Nevo SDK exceptions."""


class AuthError(NevoError):
    """Token was rejected by Nevo. Not retried — fix the token and reconnect."""


class ConnectionError(NevoError):  # noqa: A001 - intentional shadow; scoped to nevo.*
    """Connection could not be established after exhausting retry budget."""


class HandlerTimeoutError(NevoError):
    """Handler exceeded ``handler_timeout``. Logged; event is not retried."""


class ReplyError(NevoError):
    """Reply could not be sent.

    Carries the HTTP status, the server-returned error code, and the
    ``X-Request-ID`` (when present) so ops + support can correlate a
    failure across logs.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id

    def __str__(self) -> str:
        base = super().__str__()
        parts = [base]
        if self.status_code is not None:
            parts.append(f"status={self.status_code}")
        if self.code:
            parts.append(f"code={self.code}")
        if self.request_id:
            parts.append(f"request_id={self.request_id}")
        return " | ".join(parts) if len(parts) > 1 else base

    @property
    def is_transient(self) -> bool:
        """True if retrying the reply might succeed (network blip, 5xx, 429).
        False for validation errors and other terminal failures."""
        return isinstance(self, (NetworkError, ServerError))


class UnsupportedChannelError(ReplyError):
    """This channel type doesn't accept replies (yet). Raised client-side
    before any HTTP round-trip so the developer gets instant feedback."""

    def __init__(self, channel_type: str) -> None:
        super().__init__(
            f"replies are not supported for '{channel_type}' channels yet.",
            status_code=409,
            code="channel_unsupported",
        )
        self.channel_type = channel_type


class NetworkError(ReplyError):
    """Network failure (DNS, timeout, connection reset) after retries.
    ``is_transient`` is True — the caller may re-submit the reply."""


class ServerError(ReplyError):
    """Server returned 5xx after the SDK exhausted retries. ``is_transient``
    is True. Check status page, then retry."""


class RequestError(ReplyError):
    """Server returned 4xx (other than 401) or the SDK's client-side validation
    rejected the request. ``is_transient`` is False — fix the request and resubmit."""
