"""High-level client: register a handler, call :meth:`run`, receive events.

Quick start::

    from nevo import Nevo

    async with Nevo(token="nvo_live_...") as client:
        @client.on_event()
        async def handle(event):
            if event.email:
                await event.reply(text=f"Got it: {event.email.subject}")
        await client.run()
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from collections.abc import Awaitable, Callable
from types import TracebackType
from typing import Self

from ._http import HTTPClient
from .events import Event, _current_client
from .replies import ReplyReceipt, validate_reply_params
from .transport import Transport

Handler = Callable[[Event], Awaitable[None]]

_DEFAULT_URL = "wss://api.nevo.sh/v1/stream"
_DEFAULT_API_URL = "https://api.nevo.sh"
_TOKEN_PREFIX = "nvo_live_"


class Nevo:
    """Main entry point for the Nevo Python SDK.

    Parameters:
        token: API key from the Nevo dashboard (starts with ``nvo_live_``).
        url: WebSocket URL. Override for self-hosted Nevo.
        api_url: HTTP base URL for REST operations (replies). Override for
            self-hosted Nevo.
        handler_timeout: Seconds before a handler is considered stuck. The
            event is logged and skipped; the stream continues.
        reconnect_max_backoff: Cap on exponential WebSocket reconnect delay.
        http_timeout: Per-request timeout for HTTP calls (replies, etc).
        http_max_retries: How many times to retry a transient HTTP failure
            (network errors, 5xx, 429) before giving up.
        logger: Your own ``logging.Logger``. Defaults to ``logging.getLogger("nevo")``.
    """

    def __init__(
        self,
        token: str,
        *,
        url: str = _DEFAULT_URL,
        api_url: str = _DEFAULT_API_URL,
        handler_timeout: float = 30.0,
        reconnect_max_backoff: float = 30.0,
        http_timeout: float = 10.0,
        http_max_retries: int = 3,
        logger: logging.Logger | None = None,
    ) -> None:
        if not token or not token.startswith(_TOKEN_PREFIX):
            raise ValueError(f"token must start with {_TOKEN_PREFIX!r}")

        self._token = token
        self._url = url
        self._api_url = api_url
        self._handler_timeout = handler_timeout
        self._reconnect_max_backoff = reconnect_max_backoff
        self._http_timeout = http_timeout
        self._http_max_retries = http_max_retries
        self._log = logger or logging.getLogger("nevo")
        self._handler: Handler | None = None
        self._transport: Transport | None = None
        self._http: HTTPClient | None = None
        self._closed = False
        self._tasks: set[asyncio.Task[None]] = set()

    # ---- async context manager ---------------------------------------------

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()

    # ---- handler registration ----------------------------------------------

    def on_event(self) -> Callable[[Handler], Handler]:
        """Decorator to register the event handler.

        One handler per client. Branch on ``event.type`` inside the handler
        to route by source kind.
        """
        def decorator(fn: Handler) -> Handler:
            if self._handler is not None:
                raise ValueError(
                    "only one handler can be registered. "
                    "branch on event.type inside your handler instead."
                )
            if not inspect.iscoroutinefunction(fn):
                raise TypeError(
                    "handler must be async. wrap sync work with asyncio.to_thread()."
                )
            self._handler = fn
            return fn
        return decorator

    # ---- lifecycle ---------------------------------------------------------

    async def run(self) -> None:
        """Connect and receive events until :meth:`close` is called.

        Raises :class:`~nevo.AuthError` if the token is rejected at any point.
        Reconnects silently on transient WebSocket failures; raises
        :class:`~nevo.ConnectionError` only after the retry budget is
        exhausted (in practice: never, since the transport retries forever).
        """
        if self._handler is None:
            raise ValueError(
                "no handler registered. add @nevo.on_event() above your handler."
            )

        self._transport = Transport(
            url=self._url,
            token=self._token,
            max_backoff=self._reconnect_max_backoff,
            logger=self._log.getChild("transport"),
        )

        try:
            async for message in self._transport.messages():
                if self._closed:
                    break
                mtype = message.get("type")
                if mtype == "hello":
                    self._log.info(
                        "connected to nevo (project=%s, conn=%s)",
                        message.get("project_id"), message.get("connection_id"),
                    )
                    continue

                # Events don't carry a wrapper ``type: "event"`` — they are
                # serialized ``eventschema.Event`` objects where ``type`` is
                # e.g. ``webhook.received``. Anything with ``id`` + ``schema``
                # is an event.
                if "id" in message and "schema" in message:
                    self._dispatch(message)
                    continue

                self._log.debug("unknown frame: %r", mtype)
        finally:
            await self._drain_tasks()
            if self._transport is not None:
                await self._transport.close()
                self._transport = None
            if self._http is not None:
                await self._http.close()
                self._http = None

    def run_sync(self) -> None:
        """Blocking convenience for scripts. Wraps :meth:`run` with ``asyncio.run``
        and traps ``KeyboardInterrupt`` for a clean shutdown message."""
        try:
            asyncio.run(self.run())
        except KeyboardInterrupt:
            self._log.info("shutting down.")

    async def close(self) -> None:
        """Stop receiving and release transport + HTTP resources. Safe to
        call multiple times."""
        self._closed = True
        if self._transport is not None:
            await self._transport.close()
        if self._http is not None:
            await self._http.close()
            self._http = None

    # ---- replies -----------------------------------------------------------

    async def reply(
        self,
        event: Event,
        *,
        text: str,
        html: str | None = None,
        subject: str | None = None,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
    ) -> ReplyReceipt:
        """Send a reply to an event.

        Validates params client-side (see :func:`~nevo.replies.validate_reply_params`),
        then POSTs ``/v1/replies``.

        Raises:
            UnsupportedChannelError: The channel type doesn't accept replies.
            RequestError: Client-side validation or server 4xx.
            ServerError: Server 5xx after retries.
            NetworkError: Network failure after retries.
            AuthError: Token was rejected by the server.
        """
        params = {
            "text": text,
            "html": html,
            "subject": subject,
            "cc": cc,
            "bcc": bcc,
        }
        validate_reply_params(event.channel.type, params)

        body = {k: v for k, v in params.items() if v is not None}
        payload = {"event_id": event.id, "body": body}

        http = self._ensure_http()
        response = await http.post_json("/v1/replies", payload)
        return ReplyReceipt.from_dict(response)

    # ---- internals ---------------------------------------------------------

    def _ensure_http(self) -> HTTPClient:
        if self._http is None:
            self._http = HTTPClient(
                base_url=self._api_url,
                token=self._token,
                timeout=self._http_timeout,
                max_retries=self._http_max_retries,
                logger=self._log.getChild("http"),
            )
        return self._http

    def _dispatch(self, message: dict[str, object]) -> None:
        try:
            event = Event.from_dict(message)  # type: ignore[arg-type]
        except (KeyError, ValueError, TypeError) as exc:
            self._log.exception("failed to parse event: %s", exc)
            return
        task = asyncio.create_task(self._invoke(event))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _invoke(self, event: Event) -> None:
        assert self._handler is not None
        token = _current_client.set(self)
        try:
            await asyncio.wait_for(self._handler(event), timeout=self._handler_timeout)
        except asyncio.TimeoutError:
            self._log.warning(
                "handler timed out after %.1fs for event %s",
                self._handler_timeout, event.id,
            )
        except Exception:  # noqa: BLE001 — we log and continue; one bad event
            # must not take down the stream.
            self._log.exception("handler raised for event %s", event.id)
        finally:
            _current_client.reset(token)

    async def _drain_tasks(self) -> None:
        if not self._tasks:
            return
        pending = list(self._tasks)
        try:
            await asyncio.wait_for(
                asyncio.gather(*pending, return_exceptions=True),
                timeout=self._handler_timeout + 1,
            )
        except asyncio.TimeoutError:
            for t in pending:
                t.cancel()
