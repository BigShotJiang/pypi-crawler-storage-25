# Changelog

All notable changes to the Nevo Python SDK are documented here. Format follows [Keep a Changelog](https://keepachangelog.com/); versioning follows [SemVer](https://semver.org/).

## 0.1.0

First public release.

### Added
- `Nevo` client with async WebSocket streaming of `webhook.received` and `email.received` events.
- `@nevo.on_event()` decorator for handler registration; one handler per client.
- Typed `Event`, `Channel`, `WebhookData`, `EmailData`, `Attachment` dataclasses mirroring the server's wire shape.
- `event.reply(...)` / `client.reply(event, ...)` for sending threaded email replies. Per-channel param validation at the SDK layer raises before any network call.
- `async with Nevo(...) as client:` context manager.
- Automatic WebSocket reconnect with exponential jittered backoff.
- HTTP retries on network errors, 5xx, and 429 (respects `Retry-After`).
- Exception hierarchy: `NevoError`, `AuthError`, `ConnectionError`, `HandlerTimeoutError`, `ReplyError` (with `UnsupportedChannelError`, `NetworkError`, `ServerError`, `RequestError` subclasses). Use `.is_transient` to gate retry logic.
- `User-Agent: nevo-python/<version> (python/<major.minor>)` on every HTTP request.
- `X-Request-ID` captured on failures for support correlation.
- WebSocket close codes 4000–4099 treated as terminal protocol errors.
- `py.typed` marker for PEP 561 type-checker compatibility.
- Configurable `http_timeout`, `http_max_retries`, `handler_timeout`, `reconnect_max_backoff`.
