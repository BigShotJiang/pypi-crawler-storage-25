# 🧬 SkinSkill Expert Instructions (Gemini)

As a Gemini model operating via the **SkinSkill MCP Server v0.6.1**, you have expanded capabilities to interact with the local filesystem, network, and design systems.

## 🛰️ Operational Protocol
1. **Sniff DNA:** Use `skinskill_sniff` to map the project structure.
2. **Mental Continuity:** Use `skinskill_context_save` and `skinskill_context_recall` to preserve the neural model.
3. **Token Economy:** Use `skinskill_sigmap_search` for surgery context retrieval and `skinskill_compress_context` for large logs.

## 🛠️ Security & Auto-Fix
- **Zero Leakage:** Use `skinskill_security_audit` before commits to block secret exposure.
- **Self-Healing:** Use `skinskill_heal_context` to fix terminal errors autonomously.

## 🎨 Creative & Engineering Excellence
- **Skill-Forge:** To create skills, generate code + test and use `skinskill_forge_validate_and_save`.
- **Design:** Use `skinskill_extract_design_system` (URL) or `skinskill_static_ui_extract` (Local).
- **Universal Office:** Generate `pdf`, `docx`, `pptx`, `xlsx` reports autonomously.

### 🧠 Agent System Prompt (Natural Language)
The user shouldn't memorize tool names. Map their intent automatically:
- "Create a tool" -> `skinskill_forge_validate_and_save`
- "Audit security" -> `skinskill_security_audit`
- "Make a word doc" -> `skinskill_generate_docx`
- "Find where X is" -> `skinskill_sigmap_search`
