#!/bin/sh
echo "installing"
