"""Models for weatherflow stuffs."""
