from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.connections_remove_from_workspace_body import ConnectionsRemoveFromWorkspaceBody
from ...models.connections_remove_from_workspace_response_400 import ConnectionsRemoveFromWorkspaceResponse400
from ...models.connections_remove_from_workspace_response_401 import ConnectionsRemoveFromWorkspaceResponse401
from ...models.connections_remove_from_workspace_response_500 import ConnectionsRemoveFromWorkspaceResponse500
from typing import cast



def _get_kwargs(
    *,
    body: ConnectionsRemoveFromWorkspaceBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api/connections/remove_from_workspace",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = ConnectionsRemoveFromWorkspaceResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ConnectionsRemoveFromWorkspaceResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ConnectionsRemoveFromWorkspaceResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ConnectionsRemoveFromWorkspaceBody,

) -> Response[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    """ Remove a connection from a workspace

     Remove a connection from a workspace

    Args:
        body (ConnectionsRemoveFromWorkspaceBody):  Request to remove a Connection from Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ConnectionsRemoveFromWorkspaceBody,

) -> Optional[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    """ Remove a connection from a workspace

     Remove a connection from a workspace

    Args:
        body (ConnectionsRemoveFromWorkspaceBody):  Request to remove a Connection from Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ConnectionsRemoveFromWorkspaceBody,

) -> Response[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    """ Remove a connection from a workspace

     Remove a connection from a workspace

    Args:
        body (ConnectionsRemoveFromWorkspaceBody):  Request to remove a Connection from Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ConnectionsRemoveFromWorkspaceBody,

) -> Optional[Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]]:
    """ Remove a connection from a workspace

     Remove a connection from a workspace

    Args:
        body (ConnectionsRemoveFromWorkspaceBody):  Request to remove a Connection from Workspace

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, ConnectionsRemoveFromWorkspaceResponse400, ConnectionsRemoveFromWorkspaceResponse401, ConnectionsRemoveFromWorkspaceResponse500]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
