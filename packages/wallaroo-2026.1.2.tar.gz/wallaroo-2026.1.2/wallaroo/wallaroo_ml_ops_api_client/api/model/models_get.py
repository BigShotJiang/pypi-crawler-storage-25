from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.models_get_body import ModelsGetBody
from ...models.models_get_response_200 import ModelsGetResponse200
from ...models.models_get_response_400 import ModelsGetResponse400
from ...models.models_get_response_401 import ModelsGetResponse401
from ...models.models_get_response_500 import ModelsGetResponse500
from typing import cast



def _get_kwargs(
    *,
    body: ModelsGetBody,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/api/models/get",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    if response.status_code == 200:
        response_200 = ModelsGetResponse200.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ModelsGetResponse400.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = ModelsGetResponse401.from_dict(response.json())



        return response_401

    if response.status_code == 500:
        response_500 = ModelsGetResponse500.from_dict(response.json())



        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ModelsGetBody,

) -> Response[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    """ Retrieve model details

     Returns details about a single Model, including attached versions.

    Args:
        body (ModelsGetBody):  Workspace model retrieval request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ModelsGetBody,

) -> Optional[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    """ Retrieve model details

     Returns details about a single Model, including attached versions.

    Args:
        body (ModelsGetBody):  Workspace model retrieval request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ModelsGetBody,

) -> Response[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    """ Retrieve model details

     Returns details about a single Model, including attached versions.

    Args:
        body (ModelsGetBody):  Workspace model retrieval request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ModelsGetBody,

) -> Optional[Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]]:
    """ Retrieve model details

     Returns details about a single Model, including attached versions.

    Args:
        body (ModelsGetBody):  Workspace model retrieval request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ModelsGetResponse200, ModelsGetResponse400, ModelsGetResponse401, ModelsGetResponse500]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
