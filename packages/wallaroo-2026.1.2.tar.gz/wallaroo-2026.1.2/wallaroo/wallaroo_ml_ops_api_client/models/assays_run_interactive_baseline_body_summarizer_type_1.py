from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.assays_run_interactive_baseline_body_summarizer_type_1_type import AssaysRunInteractiveBaselineBodySummarizerType1Type






T = TypeVar("T", bound="AssaysRunInteractiveBaselineBodySummarizerType1")



@_attrs_define
class AssaysRunInteractiveBaselineBodySummarizerType1:
    """ 
        Attributes:
            name (str):
            type_ (AssaysRunInteractiveBaselineBodySummarizerType1Type):
     """

    name: str
    type_: AssaysRunInteractiveBaselineBodySummarizerType1Type
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "type": type_,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = AssaysRunInteractiveBaselineBodySummarizerType1Type(d.pop("type"))




        assays_run_interactive_baseline_body_summarizer_type_1 = cls(
            name=name,
            type_=type_,
        )


        assays_run_interactive_baseline_body_summarizer_type_1.additional_properties = d
        return assays_run_interactive_baseline_body_summarizer_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
