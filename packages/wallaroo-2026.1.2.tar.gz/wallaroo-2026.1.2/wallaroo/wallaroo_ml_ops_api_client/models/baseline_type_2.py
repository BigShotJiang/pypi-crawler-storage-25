from collections.abc import Mapping
from typing import Any, TypeVar, Optional, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.rolling_baseline import RollingBaseline





T = TypeVar("T", bound="BaselineType2")



@_attrs_define
class BaselineType2:
    """ 
        Attributes:
            rolling (RollingBaseline):
     """

    rolling: 'RollingBaseline'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rolling_baseline import RollingBaseline
        rolling = self.rolling.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "Rolling": rolling,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rolling_baseline import RollingBaseline
        d = dict(src_dict)
        rolling = RollingBaseline.from_dict(d.pop("Rolling"))




        baseline_type_2 = cls(
            rolling=rolling,
        )


        baseline_type_2.additional_properties = d
        return baseline_type_2

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
