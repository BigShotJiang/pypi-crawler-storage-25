from enum import Enum

class AccelerationType5(str, Enum):
    ROCM = "rocm"

    def __str__(self) -> str:
        return str(self.value)
