from typing import Literal, cast

"""Contains the definition for the AppVersion"""


AppVersion = Literal["2024.1.0", "2024.1.5", "2024.4.0", "2024.4.1", "2024.4.2", "2024.4.3", "2024.4.4", "2025.1.0", "2025.1.1", "2025.1.2", "2025.1.3", "2025.1.4", "2024.2.0", "2025.1.5", "2025.1.6", "2025.2.0", "2025.2.1", "2025.2.2", "2025.2.3", "2025.2.4", "2025.2.5", "2026.1.0", "2026.1.1", "2024.2.1", "2026.1.2", "2024.2.2", "2024.2.3", "2024.3.0", "2024.3.1", "2024.3.2", "2024.3.3"]


def check_app_version(value: str) -> AppVersion:
    """Check if the provided value is a valid AppVersion.
    
    For backward compatibility, accepts any string value to allow
    older SDKs to work with newer server versions.
    """
    # Accept any string value for backward compatibility
    return cast(AppVersion, value)


def to_dict(obj) -> dict:
    """Get a dict representation of an object"""
    return obj
