"""pylitterbot version."""

__version__ = "2025.3.0"
