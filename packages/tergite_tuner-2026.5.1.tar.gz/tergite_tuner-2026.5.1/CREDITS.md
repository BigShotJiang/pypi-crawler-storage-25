# Credits

## Gustav Grännsjö

The first version of the tergite-autocalibration

## Johan Blomberg

The first version of the tergite-autocalibration

## Eleftherios Moschandreou

The revised second version of the tergite-autocalibration
First full proof of concept of full calibration of chip

## Liangyu Chen

Improvements on the CZ gate automatic tune-up

## Tong Liu

Added demodulation channels
Added functionality for recalibration

## Michele Faucci Giannelli

Automated the scan for starting parameters, bias current, amplitude, frequency (and time if not fixed) of CZ gate  

## Stefan Hill

Added the CLI interface for the tool and infrastructural components.
Work on transformation of the application-focused project to library-ready

## Amr Osman

Improvements on the CZ gate automatic tune-up.

## Damien Crielaard

Created the dataset browser, which was integrated into this library.

## Joel Sandås

Node documentation for first single qubit calibration nodes.

## Martin Ahindura

Stripped down and simpler API of tergite-tuner geared towards being used as a library