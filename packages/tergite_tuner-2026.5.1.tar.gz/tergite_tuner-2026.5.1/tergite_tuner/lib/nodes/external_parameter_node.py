# This code is part of Tergite
#
# (C) Copyright Eleftherios Moschandreou 2024, 2025
# (C) Copyright Michele Faucci Giannelli 2025
# (C) Copyright Abdullah Al Amin 2024
# (C) Chalmers Next Labs 2024, 2025
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

import math
from itertools import product

import numpy as np
import xarray

from tergite_tuner.lib.base.measurement import MeasurementType
from tergite_tuner.utils.measurement import (
    reduce_samplespace,
    samplespace_dimensions,
)


class ExternalParameterNode(MeasurementType):
    def __init__(self, node) -> None:
        self.node = node

    def validate_external_parameter_node(self, node) -> None:
        has_initial = callable(getattr(node, "initial_operation", None))
        has_premeasure = callable(getattr(node, "pre_measurement_operation", None))
        has_final = callable(getattr(node, "final_operation", None))
        if not has_initial:
            raise AttributeError("initial_operation", node)
        if not has_premeasure:
            raise AttributeError("pre_measurement_operation", node)
        if not has_final:
            raise AttributeError("final_operation", node)

    def measure_node(self, measurement_mode) -> xarray.Dataset:

        self.validate_external_parameter_node(self.node)

        external_dimensions = samplespace_dimensions(self.node.external_samplespace)
        # this implementation supports only 1 external parameter
        iterations = product(*(range(n) for n in external_dimensions))
        all_iterations = math.prod(external_dimensions)
        external_dim = list(self.node.external_samplespace.keys())[0]
        external_settables = self.node.external_samplespace.keys()

        result_dataset = xarray.Dataset()

        compiled_schedule = self.node.precompile(self.node.schedule_samplespace)

        self.node.initial_operation()

        for this_interation_index, this_iteration in enumerate(iterations):
            self.node.reduced_external_samplespace = reduce_samplespace(
                this_iteration, self.node.external_samplespace
            )
            element_dict = list(self.node.reduced_external_samplespace.values())[0]

            # current_value = list(element_dict.values())[0]

            self.node.pre_measurement_operation(
                reduced_ext_space=self.node.reduced_external_samplespace
            )

            ds = self.node.measure_compiled_schedule(
                compiled_schedule,
                measurement_mode,
                measurement=(this_interation_index, all_iterations),
            )

            # ds = ds.expand_dims({external_dim: np.array([current_value])})
            for external_dim in self.node.reduced_external_samplespace:
                # NOTE: this assumes the external values are the same for all elements
                ext_value = list(
                    self.node.reduced_external_samplespace[external_dim].values()
                )[0]
                ds = ds.expand_dims({external_dim: np.array([ext_value])})
            # we explicitly set join='outer' because we want the union of the old coordinates with the new
            result_dataset = xarray.merge(
                [ds, result_dataset], join="outer", compat="no_conflicts"
            )

        # example of final Operation is ramping the current back to 0 in coupler spectroscopy
        self.node.final_operation()

        return result_dataset
