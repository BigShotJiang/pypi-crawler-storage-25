# This code is part of Tergite
#
# (C) Copyright Axel Erik Andersson 2025
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

import re
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Dict, Tuple  # , Iterator

from tergite_tuner.utils.logging import logger

# Regex to extract the 'YYYYMMDD-HHMMSS' at the start of folder names
REGEX_MSMT_FOLDER = re.compile(r"^(\d{8}-\d{6})-\d{3}-[0-9a-f]{6}-[\w]+$")
REGEX_RUN_FOLDER = re.compile(r"^(\d{2}-\d{2}-\d{2})_[\w]+-[\w]+$")
REGEX_DAY_FOLDER = re.compile(r"^(\d{4}-\d{2}-\d{2})$")


def is_day_folder(path_to_something: Path | str):
    r"""
    Determine whether the path argument is a day folder.

    The folder has to exist and has to match the regex:
        '^(\d{4}-\d{2}-\d{2})$'
    """
    f = Path(path_to_something).resolve()
    return f.exists() and f.is_dir() and REGEX_DAY_FOLDER.match(f.name)


def is_run_folder(path_to_something: Path | str):
    r"""
    Determine whether the path argument is a run folder.

    The folder has to exist and has to match the regex:
        '^(\d{2}-\d{2}-\d{2})_[\w]+-[\w]+$'
    """
    f = Path(path_to_something).resolve()
    return f.exists() and f.is_dir() and REGEX_RUN_FOLDER.match(f.name)


def is_measurement_folder(path_to_something: Path | str):
    r"""
    Determine whether the path argument is a measurement folder.

    The folder has to exist and has to match the regex:
        '^(\d{8}-\d{6})-\d{3}-[0-9a-f]{6}-[\w]+$'
    """
    f = Path(path_to_something).resolve()
    return f.exists() and f.is_dir() and REGEX_MSMT_FOLDER.match(f.name)


@dataclass(frozen=True)
class MeasurementInfo:
    """
    Dataclass for info on a measurement folder.

    timestamp: when the folder was created.
    tuid: hex identifier for the measurement, without label.
    msmt_idx: first measurement of the run has index 1, second 2, etc.
    measurement_folder_path: the os path to the measurement folder.
    run_folder_path: the os path to the run folder (containing the measurement).
    dataset_path: the os path to the dataset .hdf5 file.
    """

    timestamp: datetime
    tuid: str
    msmt_idx: int
    node_name: str
    measurement_folder_path: Path
    run_folder_path: Path
    dataset_path: Path | None = None


@dataclass(frozen=True)
class RunInfo:
    """
    Dataclass for info a run folder.

    timestamp: when the run folder was created (the HH-MM-SS time it was created).
    run_idx: the first run of the day has index 1, second 2, etc.
    measurements: list of measurement info instances for the measurement folders in the run folder.
    """

    timestamp: time
    run_idx: int
    measurements: list[MeasurementInfo]


@dataclass(frozen=True)
class DayInfo:
    """
    Dataclass for a day folder.

    timestamp: when the day folder was created (the day it was created).
    day_idx: the first day folder has index 1, the second 2, etc.
    runs: list of run info instances for the run folders in the day folder.
    """

    timestamp: date
    day_idx: int
    runs: list[RunInfo]


def _classify_subfolders_by_hdf5(
    root_dir: Path | str,
) -> Tuple[Dict[int, MeasurementInfo], Dict[int, MeasurementInfo]]:
    root_dir = Path(root_dir)
    subfolders = sorted(
        filter(is_measurement_folder, root_dir.iterdir()), key=lambda d: d.name
    )

    with_hdf5: Dict[int, str] = {}
    without_hdf5: Dict[int, str] = {}

    for idx, folder in enumerate(subfolders, start=1):
        ts_match = REGEX_MSMT_FOLDER.match(folder.name)
        ts_str = ts_match.group(1)
        timestamp_val = datetime.strptime(ts_str, "%Y%m%d-%H%M%S")

        dataset_files = [
            file
            for file in folder.iterdir()
            if file.is_file() and file.suffix == ".hdf5"
        ]
        hdf5_exists = any(dataset_files)

        # NOTE: Assumes only one dataset file in folder
        dataset_fp = None if not hdf5_exists else dataset_files[0].resolve()

        tuid = folder.name.rsplit("-", maxsplit=1)[0]
        node_name = folder.name.rsplit("-", maxsplit=1)[1]
        measurement_folder_path = folder.resolve()
        run_folder_path = root_dir.resolve()

        info = MeasurementInfo(
            timestamp=timestamp_val,
            tuid=tuid,
            msmt_idx=idx,
            node_name=node_name,
            measurement_folder_path=measurement_folder_path,
            run_folder_path=run_folder_path,
            dataset_path=dataset_fp,
        )

        if hdf5_exists:
            assert dataset_fp.exists()
            with_hdf5[idx] = info
        else:
            without_hdf5[idx] = info

    return with_hdf5, without_hdf5


def get_run_infos(path_to_day_folder: Path | str) -> list[RunInfo]:
    """
    Returns all the run folder info in the day folder provided.
    """
    path_to_day_folder = Path(path_to_day_folder)
    if not is_day_folder(path_to_day_folder):
        raise FileNotFoundError(f"'{path_to_day_folder}' is not a day folder.")

    subfolders = sorted(
        filter(is_run_folder, path_to_day_folder.iterdir()), key=lambda d: d.name
    )

    run_infos = []

    for idx, run_folder in enumerate(subfolders, start=1):
        run_match = REGEX_RUN_FOLDER.match(run_folder.name)

        run_timestamp_str = run_match.group(1)
        run_ts_val = datetime.strptime(run_timestamp_str, "%H-%M-%S").time()

        msmt_infos_with_data, _ = _classify_subfolders_by_hdf5(run_folder)

        run_info = RunInfo(
            timestamp=run_ts_val,
            run_idx=idx,
            measurements=msmt_infos_with_data.values(),
        )
        run_infos.append(run_info)

    return sorted(run_infos, key=lambda r_i: r_i.timestamp)


def get_day_infos(path_to_tergite_data_out_folder: Path | str) -> list[DayInfo]:
    """
    Returns all the day folder info in the data folder provided.
    """
    path_to_tergite_data_out_folder = Path(path_to_tergite_data_out_folder).resolve()
    if (
        not path_to_tergite_data_out_folder.exists()
        and path_to_tergite_data_out_folder.name == "out"
    ):
        raise FileNotFoundError(
            f"'{path_to_tergite_data_out_folder}' should be the Tergite 'out' folder."
        )

    subfolders = sorted(
        filter(is_day_folder, path_to_tergite_data_out_folder.iterdir()),
        key=lambda d: d.name,
    )

    day_infos = []
    for idx, day_folder in enumerate(subfolders, start=1):
        day_match = REGEX_DAY_FOLDER.match(day_folder.name)

        date_str = day_match.group(1)
        date_val = datetime.strptime(date_str, "%Y-%m-%d").date()

        day_infos.append(
            DayInfo(timestamp=date_val, day_idx=idx, runs=get_run_infos(day_folder))
        )

    return sorted(day_infos, key=lambda d_i: d_i.timestamp)


def search_all_runs_for_measurement(
    path_to_tergite_data_out_folder: Path | str, data_identifier: str
) -> MeasurementInfo | None:
    """
    Explicitly search for a certain measurement folder name or measurement folder path
    inside the provided data folder, using the data_identifier.
    """
    path_to_tergite_data_out_folder = Path(path_to_tergite_data_out_folder)
    day_infos = get_day_infos(path_to_tergite_data_out_folder)
    data_identifier_as_path = Path(data_identifier).resolve()

    for d_i in day_infos:
        for r_i in d_i.runs:
            for m_i in r_i.measurements:
                if (
                    m_i.measurement_folder_path.name == data_identifier
                    or m_i.measurement_folder_path == data_identifier_as_path
                ):
                    return m_i

    return None
