# This code is part of Tergite
#
# (C) Copyright Eleftherios Moschandreou 2024
# (C) Copyright Liangyu Chen 2024
# (C) Copyright Tong Liu 2024
# (C) Copyright Michele Faucci Giannelli 2024, 2025
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

import os.path
import shutil
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Union
from uuid import uuid4

import cf_xarray as cf
import xarray

from tergite_tuner.utils.logging import logger

if TYPE_CHECKING:
    from tergite_tuner.config.session import SessionContext


def to_real_dataset(iq_dataset: xarray.Dataset) -> xarray.Dataset:
    ds = iq_dataset.expand_dims("ReIm", axis=-1)  # Add ReIm axis at the end
    ds = xarray.concat([ds.real, ds.imag], dim="ReIm")
    return ds


def create_node_data_path(session_config: "SessionContext", node_name: str) -> Path:
    """
    Create the folder where measurement results, plots and logs specific to the node are stored.

    Args:
        session_config: the configuration for the current session
        node_name: to create a data path for.

    Returns:
        Path to the measurement log folder as Path.

    """
    now_ = datetime.now()
    measurement_id = (
        f"{now_.strftime('%Y%m%d-%H%M%S-%f')[:19]}-{str(uuid4())[:6]}-{node_name}"
    )
    data_path = Path(os.path.join(session_config.data_dir, measurement_id))
    return data_path


def scrape_and_copy_hdf5_files(
    scrape_directory: Union[Path, str], target_directory: Union[Path, str]
):
    """
    Find all measurement result files and copy them to the target directory.

    Args:
        scrape_directory: Folder with measurement result files.
        target_directory: Target directory to copy files to.
    """

    # Find all data files
    directory = Path(scrape_directory)
    hdf5_files = list(directory.rglob("*.h5")) + list(directory.rglob("*.hdf5"))

    # Ensure the target directory exists
    os.makedirs(target_directory, exist_ok=True)

    # Iterate over files and copy to the new folder
    # Does not preserve any subfolder structures from the scrape directory
    for file in hdf5_files:
        destination_path = os.path.join(target_directory, file.name)
        shutil.copy2(file, destination_path)

    logger.info(f"Copied {len(hdf5_files)} files to {target_directory}.")


def save_dataset(
    result_dataset: xarray.Dataset, node_name: str, data_path: Path
) -> None:
    """
    Save the measurement dataset to a file.

    Args:
        result_dataset (xarray.Dataset): The dataset to save.
        node_name (str): Name of the node being measured.
        data_path (Path): Path where the dataset will be saved.
    """
    data_path.mkdir(parents=True, exist_ok=True)
    measurement_id = data_path.stem[0:19]

    result_dataset = result_dataset.assign_attrs(
        {"name": node_name, "tuid": measurement_id}
    )

    # to_netcdf doesn't like complex numbers, convert to real&imag to save:
    result_dataset_real = to_real_dataset(result_dataset)

    dataset_name = f"dataset_{node_name}.hdf5"
    if "working_points" in result_dataset_real.coords:
        result_dataset_real = cf.encode_multi_index_as_compress(
            result_dataset_real, "working_points"
        )
    result_dataset_real.to_netcdf(data_path / dataset_name)
