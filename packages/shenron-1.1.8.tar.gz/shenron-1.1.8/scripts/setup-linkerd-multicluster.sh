#!/usr/bin/env bash
#
# Sets up linkerd multicluster connectivity from a downstream cluster
# (piccolo/chiaotzu) to the curie GKE cluster.
#
# Prerequisites:
#   - linkerd CLI installed (stable-2.14.x): curl -sL https://run.linkerd.io/install | LINKERD2_VERSION=stable-2.14.10 sh
#   - kubectl context for the downstream cluster set as current
#   - kubectl context "curie-v4" available (for link-gen)
#   - Linkerd control plane + multicluster already installed on both clusters
#
# Usage:
#   # From a downstream cluster (piccolo or chiaotzu):
#   ./scripts/setup-linkerd-multicluster.sh curie-v4
#
#   # To verify:
#   ./scripts/setup-linkerd-multicluster.sh curie-v4 --check
#
set -euo pipefail

CLUSTER_NAME="${1:?Usage: $0 <cluster-name> [--check]}"
CHECK_ONLY="${2:-}"
LINKERD="${LINKERD:-linkerd}"

# ---------------------------------------------------------------------------
# Verify mode
# ---------------------------------------------------------------------------
if [[ "$CHECK_ONLY" == "--check" ]]; then
  echo "Checking linkerd multicluster status..."
  $LINKERD multicluster check
  echo "---"
  $LINKERD multicluster gateways
  echo "---"
  echo "Mirrored services in dynamo namespace:"
  kubectl get svc -n dynamo | grep "$CLUSTER_NAME" || echo "  (none)"
  exit 0
fi

# ---------------------------------------------------------------------------
# Step 1: Generate link from the target cluster
# ---------------------------------------------------------------------------
echo "==> Generating link from context '$CLUSTER_NAME'..."
LINK_YAML=$(mktemp /tmp/linkerd-link-XXXXXX.yaml)

$LINKERD --context="$CLUSTER_NAME" multicluster link-gen --cluster-name "$CLUSTER_NAME" > "$LINK_YAML"

# The link-gen from edge CLI produces v1alpha3 Link resources.
# Downstream clusters running stable-2.14.x only support v1alpha1.
# Downgrade the API version and remove unsupported fields.
sed -i.bak 's|apiVersion: multicluster.linkerd.io/v1alpha3|apiVersion: multicluster.linkerd.io/v1alpha1|' "$LINK_YAML"
sed -i.bak '/federatedServiceSelector:/,/mirror.linkerd.io\/federated: member/d' "$LINK_YAML"
sed -i.bak '/^status: {}$/d' "$LINK_YAML"
rm -f "${LINK_YAML}.bak"

echo "==> Applying link resource..."
kubectl apply -f "$LINK_YAML"

# ---------------------------------------------------------------------------
# Step 2: Create service mirror controller (clone from existing 'curie' link)
# ---------------------------------------------------------------------------
EXISTING_LINK="curie"

if kubectl get deploy "linkerd-service-mirror-${CLUSTER_NAME}" -n linkerd-multicluster &>/dev/null; then
  echo "==> Service mirror controller already exists, skipping."
else
  echo "==> Creating service mirror controller for '$CLUSTER_NAME'..."

  for kind_ns in \
    "sa/linkerd-service-mirror-${EXISTING_LINK}:linkerd-multicluster" \
    "clusterrole/linkerd-service-mirror-access-local-resources-${EXISTING_LINK}:" \
    "clusterrolebinding/linkerd-service-mirror-access-local-resources-${EXISTING_LINK}:" \
    "role/linkerd-service-mirror-read-remote-creds-${EXISTING_LINK}:linkerd-multicluster" \
    "rolebinding/linkerd-service-mirror-read-remote-creds-${EXISTING_LINK}:linkerd-multicluster" \
    "deploy/linkerd-service-mirror-${EXISTING_LINK}:linkerd-multicluster"; do

    kind_name="${kind_ns%%:*}"
    ns="${kind_ns##*:}"
    ns_flag=""
    [[ -n "$ns" ]] && ns_flag="-n $ns"

    # shellcheck disable=SC2086
    kubectl get $kind_name $ns_flag -o json \
      | sed "s/${EXISTING_LINK}/${CLUSTER_NAME}/g" \
      | python3 -c '
import json, sys
d = json.load(sys.stdin)
for k in ["creationTimestamp","resourceVersion","uid","generation"]:
    d["metadata"].pop(k, None)
d["metadata"].pop("managedFields", None)
d.pop("status", None)
print(json.dumps(d))
' | kubectl apply -f -
  done
fi

# ---------------------------------------------------------------------------
# Step 3: Create probe gateway service and endpoint
# ---------------------------------------------------------------------------
PROBE_SVC="probe-gateway-${CLUSTER_NAME}"

if kubectl get svc "$PROBE_SVC" -n linkerd-multicluster &>/dev/null; then
  echo "==> Probe service already exists, skipping."
else
  echo "==> Creating probe gateway service..."

  # Get the gateway IP from the link
  GATEWAY_IP=$(kubectl get link "$CLUSTER_NAME" -n linkerd-multicluster -o jsonpath='{.spec.gatewayAddress}')

  kubectl get svc "probe-gateway-${EXISTING_LINK}" -n linkerd-multicluster -o json \
    | python3 -c "
import json, sys
d = json.load(sys.stdin)
d['metadata']['name'] = '${PROBE_SVC}'
for k in ['creationTimestamp','resourceVersion','uid','managedFields']:
    d['metadata'].pop(k, None)
d['metadata']['labels']['multicluster.linkerd.io/remote-cluster-name'] = '${CLUSTER_NAME}'
d.pop('status', None)
d['spec'].pop('clusterIP', None)
d['spec'].pop('clusterIPs', None)
print(json.dumps(d))
" | kubectl apply -f -

  # Create endpoint pointing to the gateway
  kubectl apply -f - <<EOF
apiVersion: v1
kind: Endpoints
metadata:
  name: ${PROBE_SVC}
  namespace: linkerd-multicluster
subsets:
- addresses:
  - ip: ${GATEWAY_IP}
  ports:
  - name: mc-probe
    port: 4191
    protocol: TCP
EOF
fi

# ---------------------------------------------------------------------------
# Verify
# ---------------------------------------------------------------------------
echo ""
echo "==> Setup complete. Verifying..."
sleep 5

echo "Gateway status:"
$LINKERD multicluster gateways 2>/dev/null || kubectl get link -n linkerd-multicluster

echo ""
echo "Mirrored services:"
kubectl get svc -n dynamo | grep "$CLUSTER_NAME" || echo "  (waiting for services to mirror...)"

rm -f "$LINK_YAML"
echo ""
echo "Done. If gateway shows ALIVE=False, wait ~30s for the probe to succeed."
