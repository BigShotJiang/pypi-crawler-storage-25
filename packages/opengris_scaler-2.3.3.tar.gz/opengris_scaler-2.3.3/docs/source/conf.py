# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.

import os
import sys

from pygments.lexers.python import PythonLexer
from sphinx.highlighting import lexers

sys.path.insert(0, os.path.abspath(os.path.join("..", "..", "src")))

lexers["ipython3"] = PythonLexer()


# -- Project information -----------------------------------------------------

project = "OpenGRIS Scaler"
author = "Citi"

with open("../../src/scaler/version.txt", "rt") as f:
    version = f.read().strip()

release = f"{version}-py3-none-any"

rst_prolog = f"""
.. |version| replace:: {version}
.. |release| replace:: {release}
"""

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.doctest",
    "sphinx_substitution_extensions",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosectionlabel",
    "sphinx_copybutton",
    "sphinx_tabs.tabs",
    "nbsphinx",
]

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
# html_theme = "alabaster"

html_theme = "shibuya"
html_title = f"{project} {version}"

html_theme_options = {
    "nav_links": [
        {"title": "Release Notes", "url": "release_notes"},
        {"title": "Example Gallery", "url": "gallery/index"},
        {"title": "Launchpad", "url": "launchpad/", "resource": True},
    ]
}

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ["_static"]
html_extra_path = ["../html_extra"]
html_css_files = ["style.css"]

# html_static_path = []
# html_css_files = []


# -- Extension configuration -------------------------------------------------

autosectionlabel_prefix_document = True

copybutton_prompt_text = r"\$ "
copybutton_prompt_is_regexp = True

nbsphinx_execute = "never"
nbsphinx_codecell_lexer = "python"
