import sys
import json
from pathlib import Path
import pyperclip
import subprocess

def print_requirements():
    reqs = """numpy
pandas
matplotlib
scikit-learn
seaborn
jupyter"""
    print("To run these experiments, install the required packages:")
    print("pip install numpy pandas matplotlib scikit-learn seaborn jupyter")

def get_experiment_code(choice):
    experiments = {
        '1': '''import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# %%
# 1. Load Dataset
data = pd.read_csv('student_data.csv')
df = pd.DataFrame(data)

print("--- First 5 rows ---")
print(df.head())
print("\\n--- Dataset Info ---")
print(df.info())
print("\\n--- Summary Statistics ---")
print(df.describe())

print("\\n--- Missing Values Count ---")
print(df.isnull().sum())

# %%
# 3. Data Imputation (Mean)
df['Marks'] = df['Marks'].fillna(df['Marks'].mean())
df['Attendance'] = df['Attendance'].fillna(df['Attendance'].mean())

# %%
# 4. Outlier Handling (IQR Method)
Q1 = df['Attendance'].quantile(0.25)
Q3 = df['Attendance'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
df['Attendance'] = np.clip(df['Attendance'], lower_bound, upper_bound)

# %%
# 5. Label Encoding
encoder = LabelEncoder()
df['Pass_Test'] = encoder.fit_transform(df['Pass_Test'])

# %%
# 6. Exploratory Data Analysis (Boxplot)
plt.figure(figsize=(6, 4))
sns.boxplot(x=df['Attendance'])
plt.title("Attendance Boxplot (Outliers Handled)")
plt.show()''',
        '2': '''from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

# %%
# 1. Load Data
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Train Model
clf = DecisionTreeClassifier(random_state=42, max_depth=3)
clf.fit(X_train, y_train)

# 3. Evaluate
y_pred = clf.predict(X_test)
print(f"Decision Tree Accuracy: {accuracy_score(y_test, y_pred):.4f}")

# %%
# 4. Plot Tree
plt.figure(figsize=(12, 8))
plot_tree(clf, filled=True, feature_names=load_iris().feature_names, class_names=load_iris().target_names)
plt.title("Decision Tree Visualization")
plt.show()''',
        '3': '''import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# %%
# 1. Multiple Linear Regression (Using all 8 features of California Housing Data)
data = fetch_california_housing()
X_multi, y_multi = data.data, data.target
X_train_m, X_test_m, y_train_m, y_test_m = train_test_split(X_multi, y_multi, test_size=0.2, random_state=42)

model_multi = LinearRegression()
model_multi.fit(X_train_m, y_train_m)
y_pred_m = model_multi.predict(X_test_m)

print("--- Multiple Linear Regression ---")
print("Intercept:", model_multi.intercept_)
print("Coefficients (first 4):", model_multi.coef_[:4])
print(f"R2 Score: {r2_score(y_test_m, y_pred_m):.4f}\\n")

# %%
# 2. Simple Linear Regression (Sample Data)
# Note: 'salary_data.csv' has been generated in your directory.
df_simple = pd.read_csv('salary_data.csv')
X_simple = df_simple[['YearsExperience']].values
y_simple = df_simple['Salary'].values

model_simple = LinearRegression()
model_simple.fit(X_simple, y_simple)
y_pred_s = model_simple.predict(X_simple)
print("Intercept (a0):", model_simple.intercept_)
print("Slope (a1):", model_simple.coef_[0])

# %%
# 3. Plot Simple Linear Regression
plt.figure(figsize=(6, 4))
plt.scatter(X_simple, y_simple, color='blue', label='Data Points')
plt.plot(X_simple, y_pred_s, color='red', linewidth=2, label='Regression Line')
plt.title("Simple Linear Regression")
plt.xlabel("X")
plt.ylabel("y")
plt.legend()
plt.show()''',
        '4': '''import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

# %%
# 1. Load Data
X, y = load_wine(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Train Model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# 3. Evaluate
y_pred = rf_model.predict(X_test)
print(f"Random Forest Accuracy: {accuracy_score(y_test, y_pred):.4f}\\n")
print(classification_report(y_test, y_pred))

# %%
# 4. Plot Feature Importances
importances = pd.Series(rf_model.feature_importances_, index=load_wine().feature_names)
importances.sort_values(ascending=False).plot(kind='bar', color='teal', figsize=(10, 6))
plt.title("Random Forest - Feature Importances")
plt.ylabel("Importance")
plt.show()''',
        '5': '''import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_curve, auc

# %%
# 1. Load Data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Scale Data (Required for SVM)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 3. Train Model
svm_model = SVC(kernel='linear', random_state=42)
svm_model.fit(X_train_scaled, y_train)

y_pred = svm_model.predict(X_test_scaled)
print(f"SVM Accuracy: {accuracy_score(y_test, y_pred):.4f}")

# %%
# 4. Plot ROC Curve
y_scores = svm_model.decision_function(X_test_scaled)
fpr, tpr, thresholds = roc_curve(y_test, y_scores)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (SVM)')
plt.legend(loc="lower right")
plt.show()''',
        '6': '''from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# %%
# 1. Load Data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Scale Features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 3. Train Model
log_reg = LogisticRegression(random_state=42)
log_reg.fit(X_train_scaled, y_train)

# 4. Evaluate
y_pred = log_reg.predict(X_test_scaled)
print(f"Logistic Regression Accuracy: {accuracy_score(y_test, y_pred):.4f}")

# %%
# 5. Plot Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=load_breast_cancer().target_names,
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# %%
# 1. Load and Preprocess Data
data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(data.data, data.target, test_size=0.2, random_state=42)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# %%
# 2. Model Training
model = LogisticRegression()
model.fit(X_train, y_train)

# 3. Evaluation
y_pred = model.predict(X_test)
print("Classification Report:\\n", classification_report(y_test, y_pred))

# %%
# 4. Plot Confusion Matrix
plt.figure(figsize=(6, 4))
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap='Blues')
plt.title("Logistic Regression Confusion Matrix")
plt.show()''',
        '7': '''import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# %%
# 1. Load Data
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Train Model (K=3)
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)
print(f"KNN Accuracy (K=3): {accuracy_score(y_test, y_pred):.4f}")

# %%
# 3. Plot Accuracy vs K-value (Elbow Method)
k_values = range(1, 15)
accuracies = []

for k in k_values:
    knn_temp = KNeighborsClassifier(n_neighbors=k)
    knn_temp.fit(X_train, y_train)
    accuracies.append(accuracy_score(y_test, knn_temp.predict(X_test)))

plt.figure(figsize=(8, 6))
plt.plot(k_values, accuracies, marker='o', linestyle='dashed', color='red')
plt.title('KNN Accuracy vs. K Value')
plt.xlabel('K Value')
plt.ylabel('Accuracy')
plt.xticks(k_values)
plt.grid(True)
plt.show()''',
        '8': '''import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix

# %%
# 1. Load Data
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %%
# 2. Train Model
nb_model = GaussianNB()
nb_model.fit(X_train, y_train)

# 3. Evaluate
y_pred = nb_model.predict(X_test)
print(f"Naive Bayes Accuracy: {accuracy_score(y_test, y_pred):.4f}")

# %%
# 4. Plot Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Greens",
            xticklabels=load_iris().target_names,
            yticklabels=load_iris().target_names)
plt.title("Naive Bayes - Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()''',
        '9': '''from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans, AgglomerativeClustering
import matplotlib.pyplot as plt

# 1. Generate Toy Cluster Data
X, _ = make_blobs(n_samples=300, centers=4, cluster_std=0.60, random_state=0)

# 2. K-Means Clustering
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
kmeans_labels = kmeans.fit_predict(X)

# 3. Agglomerative Clustering
agg = AgglomerativeClustering(n_clusters=4)
agg_labels = agg.fit_predict(X)

# %%
# 4. Plot Results
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

ax1.scatter(X[:, 0], X[:, 1], c=kmeans_labels, cmap='viridis')
ax1.set_title("K-Means Clustering")

ax2.scatter(X[:, 0], X[:, 1], c=agg_labels, cmap='plasma')
ax2.set_title("Agglomerative Clustering")

plt.show()''',
        '10': '''import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity

# %%
# 1. Create User-Movie Ratings Matrix
# Note: 'movie_ratings.csv' has been generated in your directory.
df = pd.read_csv('movie_ratings.csv', index_col='User')
print("--- User-Movie Ratings ---\\n", df)

# %%
# 2. Compute Cosine Similarity
similarity = cosine_similarity(df.T)
sim_df = pd.DataFrame(similarity, index=df.columns, columns=df.columns)
print("\\n--- Similarity Matrix ---\\n", sim_df)

# %%
# 3. Recommendation Function
def recommend(movie, n=2):
    return sim_df[movie].drop(movie).sort_values(ascending=False).head(n)

print("\\nRecommendations for MovieA:\\n", recommend('MovieA'))

# %%
# 4. Plot Similarity Heatmap
plt.figure(figsize=(6, 5))
sns.heatmap(sim_df, annot=True, cmap="YlGnBu", vmin=0, vmax=1)
plt.title("Movie Similarity Matrix")
plt.show()'''
    }
    
    filenames = {
        '1': 'expt_01_eda',
        '2': 'expt_02_decision_tree',
        '3': 'expt_03_linear_regression',
        '4': 'expt_04_random_forest',
        '5': 'expt_05_svm',
        '6': 'expt_06_logistic_regression',
        '7': 'expt_07_knn',
        '8': 'expt_08_naive_bayes',
        '9': 'expt_09_unsupervised',
        '10': 'expt_10_recommendation'
    }
    
    return experiments.get(choice), filenames.get(choice)

def interactive_menu():
    print("="*60)
    print("              ML EXPERIMENTS CLI")
    print("="*60)
    print("Available Experiments:\\n")
    print("1. 01: Data Preprocessing and Exploratory Data Analysis (EDA)")
    print("2. 02: Decision Trees")
    print("3. 03: Linear Regression")
    print("4. 04: Random Forest")
    print("5. 05: Support Vector Machine")
    print("6. 06: Logistic Regression")
    print("7. 07: K Nearest Neighbor")
    print("8. 08: Naive Bayes")
    print("9. 09: Unsupervised Learning: K Means & Agglomerative Clustering")
    print("10. 10: Recommendation System")
    print("\\nEnter the number of the experiment to clone the code, 'all' for all experiments, or 'q' to quit:")
    
    while True:
        try:
            choice = input("> ").strip().lower()
        except EOFError:
            break
            
        if choice == 'q':
            sys.exit(0)
            
        choices_to_run = []
        if choice == 'all':
            choices_to_run = [str(i) for i in range(1, 11)]
        else:
            if get_experiment_code(choice)[0] is None:
                print("Invalid choice. Please enter a number between 1 and 10, or 'all'.")
                continue
            choices_to_run = [choice]
            
        out_path = Path.cwd()
        all_code = []
        
        for ch in choices_to_run:
            code, filename = get_experiment_code(ch)
            all_code.append(code)
            ipynb_filename = filename + '.ipynb'
            
            # --- Generate Required CSVs ---
            if ch == '1':
                csv_content = """Student_ID,Marks,Attendance,Pass_Test
1,88.0,95.0,Yes
2,30.0,45.0,No
3,65.0,,Yes
4,55.0,75.0,No
5,80.0,88.0,Yes
6,,40.0,No
7,72.0,82.0,Yes
8,45.0,60.0,No
9,92.0,250.0,Yes
10,50.0,65.0,No
11,85.0,90.0,Yes
12,35.0,55.0,No
13,60.0,80.0,Yes
14,,85.0,Yes
15,58.0,70.0,No
"""
                try:
                    with open("student_data.csv", "w") as f:
                        f.write(csv_content)
                    print("[+] Created 'student_data.csv' for EDA experiment.")
                except Exception as e:
                    print(f"Error creating CSV: {e}")
            elif ch == '3':
                csv_content = """YearsExperience,Salary
1.1,39343.0
1.3,46205.0
1.5,37731.0
2.0,43525.0
2.2,39891.0
2.9,56642.0
3.0,60150.0
3.2,54445.0
3.2,64445.0
3.7,57189.0
3.9,63218.0
4.0,55794.0
4.0,56957.0
4.1,57081.0
4.5,61111.0
"""
                try:
                    with open("salary_data.csv", "w") as f:
                        f.write(csv_content)
                    print("[+] Created 'salary_data.csv' for Linear Regression experiment.")
                except Exception as e:
                    print(f"Error creating CSV: {e}")
            elif ch == '10':
                csv_content = """User,MovieA,MovieB,MovieC,MovieD
User1,5,3,0,1
User2,4,5,1,0
User3,0,1,5,4
User4,1,0,4,5
"""
                try:
                    with open("movie_ratings.csv", "w") as f:
                        f.write(csv_content)
                    print("[+] Created 'movie_ratings.csv' for Recommendation System experiment.")
                except Exception as e:
                    print(f"Error creating CSV: {e}")
            
            cells = []
            
            # Split code into multiple cells based on '# %%'
            cell_blocks = code.split('# %%')
            if len(cell_blocks) == 1:
                # If no markers found, use the whole code as one cell
                lines = [line + '\n' for line in code.split('\n')]
                if lines and lines[-1] == '\n':
                    lines[-1] = ''
                cells.append({
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": lines
                })
            else:
                for block in cell_blocks:
                    block = block.strip('\n')
                    if not block.strip():
                        continue
                    lines = [line + '\n' for line in block.split('\n')]
                    if lines and lines[-1] == '\n':
                        lines[-1] = ''
                    cells.append({
                        "cell_type": "code",
                        "execution_count": None,
                        "metadata": {},
                        "outputs": [],
                        "source": lines
                    })
            
            notebook = {
                "cells": cells,
                "metadata": {
                    "kernelspec": {
                        "display_name": "Python 3",
                        "language": "python",
                        "name": "python3"
                    },
                    "language_info": {
                        "codemirror_mode": {"name": "ipython", "version": 3},
                        "file_extension": ".py",
                        "mimetype": "text/x-python",
                        "name": "python",
                        "nbconvert_exporter": "python",
                        "pygments_lexer": "ipython3",
                        "version": "3.8.0"
                    }
                },
                "nbformat": 4,
                "nbformat_minor": 5
            }
            
            try:
                with open(ipynb_filename, 'w') as f:
                    json.dump(notebook, f, indent=1)
                print(f"[+] Cloned '{ipynb_filename}' into current directory.")
            except Exception as e:
                print(f"Error saving file '{ipynb_filename}': {e}")
                
        try:
            pyperclip.copy("\\n\\n".join(all_code))
            if choice == 'all':
                print(" [+] The code for all experiments has also been copied to your clipboard!")
            else:
                print(" [+] The code has also been copied to your clipboard! (You can Ctrl+V it)")
        except Exception as e:
            pass

        print("\\n[*] Automatically installing required libraries (pandas, scikit-learn, etc.)... This may take a minute.")
        try:
            subprocess.run(["python", "-m", "pip", "install", "numpy", "pandas", "matplotlib", "scikit-learn", "seaborn", "jupyter", "openpyxl"], check=True)
            print("[+] Libraries installed successfully!")
        except Exception as e:
            print(f"[-] Warning: Failed to automatically install libraries: {e}")
            print("    You may need to manually run: pip install numpy pandas matplotlib scikit-learn seaborn jupyter openpyxl")

        sys.exit(0)
