"""Core logic for the ``mld dev`` command.

Starts plugin backend + optional frontend dev servers with hot reload.
With ``--platform``, also starts the platform and configures dev proxy.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python < 3.11 fallback
    import tomli as tomllib  # type: ignore[no-redef]

from mld_sdk._discover import discover_plugin
from mld_sdk.cli import _detect_package_manager


def _detect_vite_port(frontend_dir: Path, default: int = 5173) -> int:
    """Extract the dev server port from a Vite config file.

    Parses ``port: NNNN`` from ``vite.config.ts`` or ``vite.config.js``.
    Returns *default* (Vite's own default) if the file is missing or
    the port cannot be determined.
    """
    for name in ("vite.config.ts", "vite.config.js"):
        config_path = frontend_dir / name
        if config_path.exists():
            match = re.search(r"\bport\s*:\s*(\d{4,5})", config_path.read_text())
            if match:
                return int(match.group(1))
            break  # config found but no port → use default
    return default


def _build_backend_cmd(factory_target: str, host: str, port: int) -> list[str]:
    """Build the uvicorn command for running a plugin backend."""
    return [
        "uv", "run", "uvicorn", factory_target,
        "--factory", "--reload", "--host", host, "--port", str(port),
    ]


def _build_frontend_cmd(frontend_dir: Path) -> list[str] | None:
    """Build the dev server command for a frontend directory.

    Returns None if no package.json exists.
    """
    if not (frontend_dir / "package.json").exists():
        return None
    _name, cmd = _detect_package_manager(frontend_dir)
    return [cmd, "run", "dev"]


def _find_platform_dir(start: Path) -> Path | None:
    """Locate the platform directory as a sibling of *start*.

    Walks the parent directory of *start* looking for a directory that
    contains ``api/main.py`` (the platform entrypoint).
    """
    workspace = start.parent
    # Check the conventional name first
    candidate = workspace / "mld"
    if (candidate / "api" / "main.py").exists():
        return candidate

    # Fallback: scan siblings
    try:
        for child in workspace.iterdir():
            if child == start or not child.is_dir():
                continue
            if (child / "api" / "main.py").exists():
                return child
    except OSError:
        pass
    return None


def _load_toml(path: Path) -> dict[str, Any] | None:
    """Load TOML config into a dict, returning None if parsing fails."""
    if not path.exists():
        return {}
    try:
        return tomllib.loads(path.read_text())
    except Exception as exc:
        print(
            f"Warning: could not parse {path}: {exc}",
            file=sys.stderr,
        )
        return None


def _toml_key(key: str) -> str:
    """Render a TOML key, quoting non-bare keys like '/drp'."""
    if re.match(r"^[A-Za-z0-9_-]+$", key):
        return key
    return json.dumps(key)


def _toml_scalar(value: Any) -> str:
    """Serialize a scalar TOML value."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, list) and all(not isinstance(item, (dict, list)) for item in value):
        return "[" + ", ".join(_toml_scalar(item) for item in value) + "]"
    raise TypeError(f"Unsupported TOML scalar value: {value!r}")


def _is_array_of_tables(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, dict) for item in value)


def _dump_toml_table(
    lines: list[str],
    table_data: dict[str, Any],
    path: tuple[str, ...],
) -> None:
    """Serialize a TOML table body recursively."""
    # Scalars first
    for key, value in table_data.items():
        if isinstance(value, dict) or _is_array_of_tables(value):
            continue
        lines.append(f"{_toml_key(key)} = {_toml_scalar(value)}")

    # Child tables
    for key, value in table_data.items():
        if not isinstance(value, dict):
            continue
        if lines and lines[-1] != "":
            lines.append("")
        table_path = path + (key,)
        lines.append(f"[{'.'.join(_toml_key(part) for part in table_path)}]")
        _dump_toml_table(lines, value, table_path)

    # Arrays of tables
    for key, value in table_data.items():
        if not _is_array_of_tables(value):
            continue
        table_path = path + (key,)
        for item in value:
            if lines and lines[-1] != "":
                lines.append("")
            lines.append(f"[[{'.'.join(_toml_key(part) for part in table_path)}]]")
            _dump_toml_table(lines, item, table_path)


def _dump_toml(data: dict[str, Any]) -> str:
    """Serialize config dict to TOML while preserving structured data."""
    lines: list[str] = []
    _dump_toml_table(lines, data, ())
    return ("\n".join(lines).rstrip() + "\n") if lines else ""


def _write_dev_proxy_config(platform_dir: Path, prefix: str, port: int) -> None:
    """Write or update ``config.dev.toml`` with a proxy entry for *prefix*."""
    config_path = platform_dir / "config.dev.toml"
    config = _load_toml(config_path)
    if config is None:
        return

    proxy = config.get("proxy")
    if not isinstance(proxy, dict):
        proxy = {}

    target = f"http://localhost:{port}"
    existing_entry = proxy.get(prefix)
    if isinstance(existing_entry, dict):
        # Preserve metadata (name/version/nav_items/...) while updating target.
        updated_entry = dict(existing_entry)
        updated_entry["target"] = target
        proxy[prefix] = updated_entry
    else:
        proxy[prefix] = target

    config["proxy"] = proxy
    config_path.write_text(_dump_toml(config))


def _cleanup_dev_proxy_config(platform_dir: Path, prefix: str) -> None:
    """Remove *prefix* from ``config.dev.toml``, deleting the file if empty."""
    config_path = platform_dir / "config.dev.toml"
    if not config_path.exists():
        return

    config = _load_toml(config_path)
    if config is None:
        return

    proxy = config.get("proxy")
    if isinstance(proxy, dict):
        proxy.pop(prefix, None)
        if proxy:
            config["proxy"] = proxy
        else:
            config.pop("proxy", None)

    if not config:
        config_path.unlink(missing_ok=True)
        return

    config_path.write_text(_dump_toml(config))


def _resolve_platform_dir(project_dir: Path, platform_dir_arg: str | None) -> Path | None:
    """Resolve the platform directory from CLI arg or sibling auto-discovery."""
    if platform_dir_arg:
        candidate = Path(platform_dir_arg).expanduser().resolve()
        return candidate if (candidate / "api" / "main.py").exists() else None
    return _find_platform_dir(project_dir)


def _label_to_filename(label: str) -> str:
    """Convert a process label to a safe log filename."""
    return label.lower().replace(" ", "-") + ".log"


def _tee_output(
    proc: subprocess.Popen[bytes],
    label: str,
    log_file: Path,
    print_lock: threading.Lock,
) -> None:
    """Read process stdout line by line, writing to both log file and terminal."""
    assert proc.stdout is not None
    try:
        with open(log_file, "w") as f:
            for raw_line in iter(proc.stdout.readline, b""):
                text = raw_line.decode("utf-8", errors="replace")
                f.write(text)
                f.flush()
                with print_lock:
                    sys.stdout.write(f"[{label}] {text}")
                    sys.stdout.flush()
    except (OSError, ValueError):
        pass  # pipe closed during shutdown
    finally:
        try:
            proc.stdout.close()
        except OSError:
            pass


def _run_processes(
    commands: list[tuple[str, list[str], Path]],
    log_dir: Path | None = None,
) -> None:
    """Run multiple processes in parallel, blocking until interrupted.

    Each entry in *commands* is ``(label, argv, cwd)``.
    Sends SIGTERM on shutdown; escalates to SIGKILL after 5 seconds.

    When *log_dir* is provided, process output is captured and teed to
    both the terminal (with ``[label]`` prefixes) and individual log files
    under *log_dir*.  When *log_dir* is ``None``, output goes directly to
    the terminal (original behaviour).
    """
    procs: dict[str, subprocess.Popen[bytes]] = {}
    readers: list[threading.Thread] = []
    print_lock = threading.Lock()
    shutdown = False

    def _on_signal(signum: int, _frame: object) -> None:
        nonlocal shutdown
        shutdown = True

    prev_sigint = signal.signal(signal.SIGINT, _on_signal)
    prev_sigterm = signal.signal(signal.SIGTERM, _on_signal)

    try:
        for label, cmd, cwd in commands:
            if log_dir is not None:
                proc = subprocess.Popen(
                    cmd, cwd=cwd, start_new_session=True,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                )
                log_file = log_dir / _label_to_filename(label)
                t = threading.Thread(
                    target=_tee_output,
                    args=(proc, label, log_file, print_lock),
                    daemon=True,
                )
                t.start()
                readers.append(t)
            else:
                proc = subprocess.Popen(cmd, cwd=cwd, start_new_session=True)
            procs[label] = proc

        # Poll until shutdown or critical process exits
        while not shutdown:
            exited: list[str] = []
            for label, proc in procs.items():
                ret = proc.poll()
                if ret is not None:
                    if "backend" in label.lower():
                        msg = f"\n{label} exited with code {ret}. Shutting down.\n"
                        if log_dir is not None:
                            with print_lock:
                                sys.stderr.write(msg)
                        else:
                            sys.stderr.write(msg)
                        shutdown = True
                    else:
                        msg = f"\nWarning: {label} exited with code {ret}.\n"
                        if log_dir is not None:
                            with print_lock:
                                sys.stderr.write(msg)
                        else:
                            sys.stderr.write(msg)
                    exited.append(label)
            for label in exited:
                del procs[label]
            if not procs:
                break
            time.sleep(0.5)
    finally:
        # Graceful shutdown: SIGTERM all process groups
        for label, proc in procs.items():
            if proc.poll() is None:
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except OSError as exc:
                    print(f"Warning: failed to stop {label}: {exc}", file=sys.stderr)

        # Wait up to 5 seconds, then SIGKILL survivors
        deadline = time.monotonic() + 5
        for label, proc in procs.items():
            remaining = max(0, deadline - time.monotonic())
            try:
                proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except OSError as exc:
                    print(f"Warning: failed to kill {label}: {exc}", file=sys.stderr)

        # Wait for reader threads to drain
        for t in readers:
            t.join(timeout=2)

        # Restore signal handlers after cleanup completes
        signal.signal(signal.SIGINT, prev_sigint)
        signal.signal(signal.SIGTERM, prev_sigterm)


def cmd_dev(args: argparse.Namespace) -> None:
    """Execute the ``mld dev`` command."""
    project_dir = Path.cwd()
    plugin = discover_plugin(project_dir)

    print(f"Discovered plugin: {plugin.class_name} ({plugin.module_path})")

    prefix = getattr(args, "prefix", None) or plugin.routes_prefix
    host = getattr(args, "host", "127.0.0.1")
    port = int(getattr(args, "port", 8003))
    no_frontend = getattr(args, "no_frontend", False)
    platform_mode = getattr(args, "platform", False)
    platform_dir_arg = getattr(args, "platform_dir", None)

    commands: list[tuple[str, list[str], Path]] = []

    # Plugin backend (always)
    backend_cmd = _build_backend_cmd(plugin.factory_target, host, port)
    commands.append(("Plugin backend", backend_cmd, project_dir))

    # Plugin frontend (if present and not skipped)
    plugin_fe_port: int | None = None
    if not no_frontend and plugin.has_frontend:
        frontend_dir = project_dir / "frontend"
        fe_cmd = _build_frontend_cmd(frontend_dir)
        if fe_cmd is not None:
            plugin_fe_port = _detect_vite_port(frontend_dir)
            commands.append(("Plugin frontend", fe_cmd, frontend_dir))

    platform_dir: Path | None = None
    platform_fe_port: int | None = None
    if platform_mode:
        platform_dir = _resolve_platform_dir(project_dir, platform_dir_arg)
        if platform_dir is None:
            print(
                "Error: Could not find platform directory. "
                "Provide --platform-dir or use a sibling directory containing api/main.py.",
                file=sys.stderr,
            )
            sys.exit(1)

        _write_dev_proxy_config(platform_dir, prefix, port)

        platform_backend = [
            "uv", "run", "uvicorn", "api.main:app",
            "--reload", "--port", "8001",
        ]
        commands.append(("Platform backend", platform_backend, platform_dir))

        platform_fe_dir = platform_dir / "frontend"
        platform_fe_cmd = _build_frontend_cmd(platform_fe_dir)
        if platform_fe_cmd is not None:
            platform_fe_port = _detect_vite_port(platform_fe_dir)
            commands.append(("Platform frontend", platform_fe_cmd, platform_fe_dir))

    # Print startup summary
    print()
    if platform_mode:
        print(f"  Platform backend   http://localhost:8001")
        if platform_fe_port is not None:
            print(f"  Platform frontend  http://localhost:{platform_fe_port}")
        print(f"  Plugin backend     http://{host}:{port}/api{prefix}")
        if plugin_fe_port is not None:
            print(f"  Plugin frontend    http://localhost:{plugin_fe_port}")
        print(f"  Proxy              {prefix} -> http://localhost:{port}")
    else:
        print(f"  Backend   http://{host}:{port}/api{prefix}")
        if plugin_fe_port is not None:
            print(f"  Frontend  http://localhost:{plugin_fe_port}")
    # Create log directory
    log_dir = project_dir / ".mld" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    print()
    print(f"  Logs               {log_dir}/")
    print()
    print("Press Ctrl+C to stop.")
    print()

    try:
        _run_processes(commands, log_dir=log_dir)
    finally:
        if platform_dir is not None:
            _cleanup_dev_proxy_config(platform_dir, prefix)
