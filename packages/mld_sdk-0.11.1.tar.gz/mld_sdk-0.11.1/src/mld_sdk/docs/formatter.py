"""Format extracted SDK documentation as markdown or JSON for terminal output."""

from __future__ import annotations

import json
import os
import sys
from typing import Any


# ---------------------------------------------------------------------------
# Color helpers
# ---------------------------------------------------------------------------


def _supports_color() -> bool:
    """Return True if stdout likely supports ANSI color."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    term = os.environ.get("TERM", "")
    return term != "dumb"


def _bold(text: str, color: bool) -> str:
    return f"\033[1m{text}\033[0m" if color else text


def _dim(text: str, color: bool) -> str:
    return f"\033[2m{text}\033[0m" if color else text


def _cyan(text: str, color: bool) -> str:
    return f"\033[36m{text}\033[0m" if color else text


def _green(text: str, color: bool) -> str:
    return f"\033[32m{text}\033[0m" if color else text


def _yellow(text: str, color: bool) -> str:
    return f"\033[33m{text}\033[0m" if color else text


def _red(text: str, color: bool) -> str:
    return f"\033[31m{text}\033[0m" if color else text


def _magenta(text: str, color: bool) -> str:
    return f"\033[35m{text}\033[0m" if color else text


# ---------------------------------------------------------------------------
# Top-level table of contents
# ---------------------------------------------------------------------------


def format_toc(
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
    *,
    as_json: bool = False,
) -> str:
    """Render the top-level table of contents."""
    if as_json:
        toc: dict[str, Any] = {}
        if python_data:
            toc["python"] = {
                "version": python_data.get("version", ""),
                "categories": {
                    k: len(v) for k, v in python_data.get("categories", {}).items()
                },
            }
        if frontend_data:
            toc["frontend"] = {
                "version": frontend_data.get("version", ""),
                "categories": {
                    k: _frontend_category_count(k, v)
                    for k, v in frontend_data.get("categories", {}).items()
                },
            }
        return json.dumps(toc, indent=2)

    c = _supports_color()
    lines: list[str] = []

    version_parts = []
    if python_data:
        version_parts.append(python_data.get("version", ""))
    lines.append(
        _bold("MLD SDK Reference", c) + "  " + _dim(" ".join(version_parts), c)
    )
    lines.append("")

    if frontend_data:
        lines.append(_cyan("frontend", c))
        for cat_name, cat_data in frontend_data.get("categories", {}).items():
            count = _frontend_category_count(cat_name, cat_data)
            summary = _frontend_category_summary(cat_name, cat_data)
            lines.append(f"  {_green(cat_name, c):30s} {count:>3} items   {_dim(summary, c)}")
        lines.append("")

    if python_data:
        lines.append(_cyan("python", c))
        for cat_name, items in python_data.get("categories", {}).items():
            names = ", ".join(i["name"] for i in items[:4])
            suffix = "..." if len(items) > 4 else ""
            lines.append(
                f"  {_green(cat_name, c):30s} {len(items):>3} items   {_dim(names + suffix, c)}"
            )
        lines.append("")

    lines.append(_dim("Use: mld docs <section> [topic]  |  mld docs search <query>", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# SDK overview
# ---------------------------------------------------------------------------


def format_sdk_overview(
    data: dict[str, Any], sdk: str, *, as_json: bool = False
) -> str:
    """Render category listing for a single SDK."""
    if as_json:
        if sdk == "frontend":
            return json.dumps(
                {
                    k: _frontend_category_count(k, v)
                    for k, v in data.get("categories", {}).items()
                },
                indent=2,
            )
        return json.dumps(
            {k: len(v) for k, v in data.get("categories", {}).items()}, indent=2
        )

    c = _supports_color()
    lines = [_bold(f"{sdk.title()} SDK", c), ""]

    categories = data.get("categories", {})
    for cat_name, cat_data in categories.items():
        if sdk == "frontend":
            count = _frontend_category_count(cat_name, cat_data)
            summary = _frontend_category_summary(cat_name, cat_data)
            lines.append(f"  {_green(cat_name, c):25s} {count:>3} items   {_dim(summary, c)}")
        else:
            items = cat_data
            names = ", ".join(i["name"] for i in items[:5])
            suffix = "..." if len(items) > 5 else ""
            lines.append(
                f"  {_green(cat_name, c):25s} {len(items):>3} items   {_dim(names + suffix, c)}"
            )

    lines.append("")
    if sdk == "python":
        lines.append(_dim("Use: mld docs python <category>  |  mld docs python <ClassName>", c))
    else:
        lines.append(
            _dim(
                "Use: mld docs frontend <category>  |  mld docs frontend <ComponentName>",
                c,
            )
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Python: category listing
# ---------------------------------------------------------------------------


def format_category(
    items: list[dict[str, Any]], category: str, *, as_json: bool = False
) -> str:
    """Render all items in a Python SDK category."""
    if as_json:
        return json.dumps(items, indent=2, default=str)

    c = _supports_color()
    lines = [_bold(category.title(), c) + _dim(f"  {len(items)} items", c), ""]

    for item in items:
        kind = item.get("kind", "")
        desc = item.get("description", "")
        if len(desc) > 70:
            desc = desc[:67] + "..."
        lines.append(f"  {_green(item['name'], c):35s} {_dim(kind, c):15s} {desc}")

    lines.append("")
    lines.append(_dim(f"Use: mld docs python <name> for full reference", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Python / Frontend: item detail
# ---------------------------------------------------------------------------


def format_item_detail(
    item: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render full reference for a single item (component, class, etc.)."""
    if as_json:
        return json.dumps(item, indent=2, default=str)

    kind = item.get("kind", "")
    if kind in ("dataclass", "class", "protocol"):
        return _format_class_detail(item)
    if kind == "enum":
        return _format_enum_detail(item)
    if kind == "exception":
        return _format_exception_detail(item)
    if kind == "function":
        return _format_function_detail(item)
    if kind == "alias":
        return _format_alias_detail(item)
    if kind == "component":
        return _format_component_detail(item)
    if kind == "composable":
        return _format_composable_detail(item)
    # Fallback
    return json.dumps(item, indent=2, default=str)


def _format_class_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    # Properties
    props = item.get("properties", [])
    if props:
        lines.append(_cyan("Properties", c))
        for p in props:
            abstract_tag = _red("abstract", c) + " " if p.get("abstract") else ""
            lines.append(
                f"  {_green(p['name'], c):30s} {_yellow(p.get('type', ''), c):25s} {abstract_tag}{_dim(p.get('description', ''), c)}"
            )
        lines.append("")

    # Fields (dataclass)
    fields = item.get("fields", [])
    if fields:
        lines.append(_cyan("Fields", c))
        for f in fields:
            req = _red("required", c) if f.get("required") else _dim(f"= {f.get('default', '?')}", c)
            lines.append(
                f"  {_green(f['name'], c):30s} {_yellow(f.get('type', ''), c):25s} {req}"
            )
        lines.append("")

    # Abstract methods (ABCs) or regular methods
    method_sections = [("Abstract Methods", "abstract_methods")]
    if item.get("concrete_methods") is not None:
        method_sections.append(("Methods", "concrete_methods"))
    else:
        method_sections.append(("Methods", "methods"))

    for section_name, key in method_sections:
        methods = item.get(key, [])
        if methods:
            lines.append(_cyan(section_name, c))
            for m in methods:
                sig = _format_method_signature(m)
                lines.append(f"  {_green(sig, c)}")
                if m.get("description"):
                    lines.append(f"      {_dim(m['description'], c)}")
                lines.append("")

    return "\n".join(lines)


def _format_enum_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    lines.append(_cyan("Members", c))
    for m in item.get("members", []):
        lines.append(f"  {_green(m['name'], c):25s} = {_yellow(repr(m['value']), c)}")

    return "\n".join(lines)


def _format_exception_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    parents = " > ".join(item.get("parents", []))
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if parents:
        lines.append(_dim(f"Inherits: {parents}", c))
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    params = item.get("init_params", [])
    if params:
        lines.append(_cyan("__init__ Parameters", c))
        for p in params:
            default = f" = {p['default']}" if "default" in p else ""
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}{_dim(default, c)}"
            )

    return "\n".join(lines)


def _format_function_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("module", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    ret = item.get("return_type", "")
    if ret:
        lines.append(_dim(f"Returns: {ret}", c))
        lines.append("")

    params = item.get("params", [])
    if params:
        lines.append(_cyan("Parameters", c))
        for p in params:
            default = f" = {p['default']}" if "default" in p else ""
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}{_dim(default, c)}"
            )

    return "\n".join(lines)


def _format_alias_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    target = item.get("target", item.get("type", ""))
    return (
        _bold(item["name"], c)
        + "\n\n"
        + _dim(item.get("description", f"Alias for {target}"), c)
    )


# ---------------------------------------------------------------------------
# Frontend: component detail
# ---------------------------------------------------------------------------


def _format_component_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    group = item.get("group", "")
    source = item.get("source", "")
    lines = [
        _bold(item["name"], c)
        + "  "
        + _dim(f"{group}  •  {source}", c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    # Props
    props = item.get("props", [])
    if props:
        lines.append(_cyan("Props", c))
        for p in props:
            req_str = (
                _red("required", c)
                if p.get("required")
                else _dim(f"= {p.get('default', 'undefined')}", c)
            )
            lines.append(
                f"  {_green(p['name'], c):30s} {_yellow(p.get('type', ''), c):25s} {req_str}   {_dim(p.get('description', ''), c)}"
            )
        lines.append("")

    # Emits
    emits = item.get("emits", [])
    if emits:
        lines.append(_cyan("Emits", c))
        for e in emits:
            lines.append(
                f"  {_green(e['name'], c):30s} {_yellow(e.get('type', ''), c)}"
            )
        lines.append("")

    # Slots
    slots = item.get("slots", [])
    if slots:
        lines.append(_cyan("Slots", c))
        for s in slots:
            bindings = s.get("bindings", {})
            binding_str = ", ".join(f"{k}: {v}" for k, v in bindings.items()) if isinstance(bindings, dict) else str(bindings)
            lines.append(
                f"  {_green(s['name'], c):30s} {_dim(binding_str, c)}"
            )

    return "\n".join(lines)


def _format_composable_detail(item: dict[str, Any]) -> str:
    c = _supports_color()
    lines = [
        _bold(item["name"], c) + "  " + _dim(item.get("source", ""), c),
        "",
    ]
    if item.get("description"):
        lines.append(_magenta(item["description"], c))
        lines.append("")

    params = item.get("params", [])
    if params:
        lines.append(_cyan("Parameters", c))
        for p in params:
            lines.append(
                f"  {_green(p['name'], c):25s} {_yellow(p.get('type', ''), c)}"
            )
        lines.append("")

    return_type = item.get("returnType", "")
    if return_type:
        lines.append(_cyan("Returns", c))
        lines.append(f"  {_yellow(return_type, c)}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Frontend: grouped component listing
# ---------------------------------------------------------------------------


def format_components_grouped(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render all components grouped by category."""
    components = data.get("categories", {}).get("components", [])
    if as_json:
        return json.dumps(components, indent=2, default=str)

    # Build groups
    groups: dict[str, list[dict[str, Any]]] = {}
    for comp in components:
        g = comp.get("group", "other")
        groups.setdefault(g, []).append(comp)

    c = _supports_color()
    total = len(components)
    lines = [
        _bold("Frontend Components", c)
        + _dim(f"  {total} components in {len(groups)} groups", c),
        "",
    ]

    for group_name, group_items in sorted(groups.items()):
        lines.append(_cyan(group_name, c) + _dim(f" ({len(group_items)})", c))
        # Grid layout: 4 columns
        names = [comp["name"] for comp in group_items]
        for i in range(0, len(names), 4):
            row = names[i : i + 4]
            lines.append("  " + "".join(f"{n:25s}" for n in row))
        lines.append("")

    lines.append(
        _dim(
            "Use: mld docs frontend components <group>  |  mld docs frontend <ComponentName>",
            c,
        )
    )
    return "\n".join(lines)


def format_component_group(
    data: dict[str, Any], group: str, *, as_json: bool = False
) -> str:
    """Render components in a single group with descriptions."""
    components = data.get("categories", {}).get("components", [])
    filtered = [comp for comp in components if comp.get("group") == group]

    if as_json:
        return json.dumps(filtered, indent=2, default=str)

    if not filtered:
        return f"No components in group '{group}'."

    c = _supports_color()
    lines = [
        _bold(f"{group.title()} Components", c)
        + _dim(f"  {len(filtered)} components", c),
        "",
    ]
    for comp in filtered:
        desc = comp.get("description", "")
        if len(desc) > 60:
            desc = desc[:57] + "..."
        lines.append(f"  {_green(comp['name'], c):30s} {desc}")

    lines.append("")
    lines.append(
        _dim("Use: mld docs frontend <ComponentName> for full props/emits/slots reference", c)
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Frontend: CSS reference
# ---------------------------------------------------------------------------


def format_css_overview(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render CSS category overview (variables, tailwind, utilities)."""
    css = data.get("categories", {}).get("css", {})
    if as_json:
        return json.dumps(
            {k: len(v) for k, v in css.items()},
            indent=2,
        )

    c = _supports_color()
    lines = [_bold("CSS Reference", c), ""]
    for section_name, section_data in css.items():
        count = len(section_data) if isinstance(section_data, list) else sum(
            len(v) for v in section_data.values()
        ) if isinstance(section_data, dict) else 0
        lines.append(f"  {_green(section_name, c):25s} {count:>3} items")

    lines.append("")
    lines.append(_dim("Use: mld docs frontend css <section>", c))
    return "\n".join(lines)


def format_css_section(
    data: dict[str, Any], section: str, *, as_json: bool = False
) -> str:
    """Render a specific CSS section (variables, tailwind, utilities)."""
    css = data.get("categories", {}).get("css", {})
    section_data = css.get(section)

    if section_data is None:
        available = ", ".join(css.keys())
        return f"Unknown CSS section '{section}'. Available: {available}"

    if as_json:
        return json.dumps(section_data, indent=2, default=str)

    c = _supports_color()
    lines = [_bold(f"CSS {section.title()}", c), ""]

    if isinstance(section_data, dict):
        # Grouped variables: {"Colors": [{"name": ..., "value": ...}], ...}
        for group_name, variables in section_data.items():
            lines.append(_cyan(group_name, c))
            if isinstance(variables, list):
                for var in variables:
                    name = var.get("name", "")
                    value = var.get("value", "")
                    lines.append(f"  {_green(name, c):35s} {_magenta(value, c)}")
            lines.append("")
    elif isinstance(section_data, list):
        for item in section_data:
            if isinstance(item, dict):
                name = item.get("name", "")
                value = item.get("value", item.get("description", ""))
                lines.append(f"  {_green(name, c):35s} {value}")
            else:
                lines.append(f"  {item}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Frontend: composable listing
# ---------------------------------------------------------------------------


def format_composables(
    data: dict[str, Any], *, as_json: bool = False
) -> str:
    """Render composable listing."""
    composables = data.get("categories", {}).get("composables", [])
    if as_json:
        return json.dumps(composables, indent=2, default=str)

    c = _supports_color()
    lines = [
        _bold("Composables", c) + _dim(f"  {len(composables)} items", c),
        "",
    ]
    for comp in composables:
        desc = comp.get("description", "")
        if len(desc) > 55:
            desc = desc[:52] + "..."
        lines.append(f"  {_green(comp['name'], c):35s} {desc}")

    lines.append("")
    lines.append(_dim("Use: mld docs frontend <composableName> for full reference", c))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Search results
# ---------------------------------------------------------------------------


def format_search_results(
    results: list[dict[str, Any]], query: str, *, as_json: bool = False
) -> str:
    """Render search results."""
    if as_json:
        return json.dumps(results, indent=2, default=str)

    if not results:
        return f"No results for '{query}'."

    c = _supports_color()
    lines = [
        _bold(f"Search: {query}", c) + _dim(f"  {len(results)} results", c),
        "",
    ]
    for r in results:
        sdk = r.get("sdk", "")
        category = r.get("category", "")
        name = r.get("name", "")
        context = r.get("match_context", "")
        lines.append(
            f"  {_dim(sdk, c):12s} {_dim(category, c):20s} {_green(name, c):30s} {context}"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _format_method_signature(m: dict[str, Any]) -> str:
    """Format a method as `name(params) -> return_type`."""
    params = m.get("params", [])
    parts = []
    for p in params:
        s = p["name"]
        if "type" in p:
            s += f": {p['type']}"
        if "default" in p:
            s += f" = {p['default']}"
        parts.append(s)

    sig = f"{m['name']}({', '.join(parts)})"
    ret = m.get("return_type", "")
    if ret:
        sig += f" -> {ret}"
    if m.get("async"):
        sig = "async " + sig
    return sig


def _frontend_category_count(cat_name: str, cat_data: Any) -> int:
    """Count items in a frontend category (handles both lists and dicts)."""
    if isinstance(cat_data, list):
        return len(cat_data)
    if isinstance(cat_data, dict):
        return sum(
            len(v) if isinstance(v, list) else 1 for v in cat_data.values()
        )
    return 0


def _frontend_category_summary(cat_name: str, cat_data: Any) -> str:
    """Generate a brief summary for a frontend category."""
    if isinstance(cat_data, list) and cat_data:
        names = [item.get("name", "") for item in cat_data[:4]]
        suffix = "..." if len(cat_data) > 4 else ""
        return ", ".join(names) + suffix
    if isinstance(cat_data, dict):
        return ", ".join(list(cat_data.keys())[:4])
    return ""
