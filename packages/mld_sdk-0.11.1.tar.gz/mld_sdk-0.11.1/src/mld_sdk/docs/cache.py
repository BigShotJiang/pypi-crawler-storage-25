"""Caching layer for extracted SDK documentation."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

_SENTINEL = "packages/sdk-python/src/mld_sdk/__init__.py"

_SOURCE_DIRS: dict[str, tuple[str, frozenset[str]]] = {
    "python": (
        "packages/sdk-python/src/mld_sdk",
        frozenset({".py"}),
    ),
    "frontend": (
        "packages/sdk-frontend/src",
        frozenset({".vue", ".ts", ".css"}),
    ),
}


def find_platform_root(start: Path | None = None) -> Path:
    """Walk upward from *start* (default cwd) looking for the platform root.

    The root is identified by the presence of ``packages/sdk-python/src/mld_sdk/__init__.py``.

    Raises ``FileNotFoundError`` if no root is found.
    """
    current = (start or Path.cwd()).resolve()
    for directory in (current, *current.parents):
        if (directory / _SENTINEL).is_file():
            return directory
    msg = f"Could not locate MLD platform root from {current}"
    raise FileNotFoundError(msg)


def get_cache_dir(platform_root: Path) -> Path:
    """Return the cache directory path, creating it if needed."""
    cache_dir = platform_root / ".mld" / "docs-cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def is_cache_fresh(cache_dir: Path, sdk: str, platform_root: Path) -> bool:
    """Check whether the cached manifest for *sdk* is still valid."""
    fp_file = cache_dir / "fingerprints.json"
    cache_file = cache_dir / f"{sdk}.json"

    if not fp_file.exists() or not cache_file.exists():
        return False

    stored = json.loads(fp_file.read_text())
    stored_fp = stored.get(sdk)
    if not stored_fp:
        return False

    current_fp = _compute_fingerprint(platform_root, sdk)
    return stored_fp == current_fp


def read_cache(cache_dir: Path, sdk: str) -> dict[str, Any] | None:
    """Read a cached manifest.  Returns ``None`` if the file is missing."""
    cache_file = cache_dir / f"{sdk}.json"
    if not cache_file.exists():
        return None
    return json.loads(cache_file.read_text())


def write_cache(
    cache_dir: Path, sdk: str, data: dict[str, Any], platform_root: Path
) -> None:
    """Write a manifest and update its fingerprint."""
    cache_file = cache_dir / f"{sdk}.json"
    cache_file.write_text(json.dumps(data, indent=2, default=str))

    fp_file = cache_dir / "fingerprints.json"
    stored: dict[str, str] = {}
    if fp_file.exists():
        stored = json.loads(fp_file.read_text())
    stored[sdk] = _compute_fingerprint(platform_root, sdk)
    fp_file.write_text(json.dumps(stored, indent=2))


def clear_cache(cache_dir: Path) -> None:
    """Remove all cached files."""
    import shutil

    if cache_dir.exists():
        shutil.rmtree(cache_dir)


# ---------------------------------------------------------------------------
# Fingerprinting
# ---------------------------------------------------------------------------


def _compute_fingerprint(platform_root: Path, sdk: str) -> str:
    """Hash file paths and mtimes for the given SDK's source directory."""
    if sdk not in _SOURCE_DIRS:
        return ""

    rel_dir, extensions = _SOURCE_DIRS[sdk]
    source_dir = platform_root / rel_dir

    if not source_dir.exists():
        return ""

    entries: list[str] = []
    for path in sorted(source_dir.rglob("*")):
        if path.is_file() and path.suffix in extensions:
            rel = path.relative_to(source_dir)
            entries.append(f"{rel}:{path.stat().st_mtime_ns}")

    digest = hashlib.sha256("\n".join(entries).encode()).hexdigest()
    return digest
