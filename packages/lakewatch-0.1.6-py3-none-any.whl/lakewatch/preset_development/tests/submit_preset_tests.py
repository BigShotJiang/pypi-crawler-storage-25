"""Submits the preset regression test suite to Databricks serverless compute.

Builds the lakewatch client wheel, uploads it and the test bundle to workspace
files, submits a serverless job, polls for completion, and prints results.

Prerequisites:
    - databricks-sdk configured for the target workspace (profile or env vars)
    - GITHUB_PAT env var set (stored in Databricks secrets at runtime)
    - Bazel available (to build the lakewatch client wheel)

Usage:
    GITHUB_PAT=ghp_... bazel run //lakewatch/python-lib:submit_preset_tests -- \\
        --catalog lw_citadel
"""
import argparse
import os
import pathlib
import subprocess
import sys
import time
import uuid

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import ResourceAlreadyExists
from databricks.sdk.service.compute import Environment
from databricks.sdk.service.workspace import ImportFormat
from databricks.sdk.service.jobs import (
    JobEnvironment,
    JobRunAs,
    QueueSettings,
    RunLifeCycleState,
    RunResultState,
    SparkPythonTask,
    SubmitTask,
)

_POLL_INTERVAL_SECONDS = 15
_TERMINAL_STATES = {
    RunLifeCycleState.TERMINATED,
    RunLifeCycleState.SKIPPED,
    RunLifeCycleState.INTERNAL_ERROR,
}
_SECRET_SCOPE = "preset-tests"
_BAZEL_TARGET = "//lakewatch/python-lib:client_wheel_local"
_BUNDLE_FILENAME = "preset_tests.py"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run preset regression tests on Databricks serverless compute.",
    )
    parser.add_argument(
        "--catalog",
        required=True,
        help="Unity Catalog catalog name (e.g. lw_citadel)",
    )
    parser.add_argument(
        "--profile",
        default=None,
        help="Databricks CLI profile name",
    )
    parser.add_argument(
        "--ref",
        default="lakewatch-staging",
        help="Git ref (branch, tag, or commit SHA) to fetch presets from "
             "(default: lakewatch-staging)",
    )
    return parser.parse_args()


def _find_repo_root() -> pathlib.Path:
    """Walk up from this script to find the repository root (contains WORKSPACE or .git)."""
    path = pathlib.Path(__file__).resolve().parent
    while path != path.parent:
        if (path / "WORKSPACE").exists() or (path / ".git").exists():
            return path
        path = path.parent
    raise FileNotFoundError("Could not find repository root")


def _build_wheel(repo_root: pathlib.Path) -> pathlib.Path:
    print("Building lakewatch client wheel...")
    subprocess.run(
        [
            "bazel",
            "build",
            _BAZEL_TARGET,
            "--remote_download_outputs=all",
            "--noshow_progress",
            "--noshow_loading_progress",
        ],
        cwd=repo_root,
        check=True,
    )
    wheel_dir = repo_root / "bazel-bin" / "lakewatch" / "python-lib"
    wheels = sorted(wheel_dir.glob("lakewatch-*.whl"), key=lambda p: p.stat().st_mtime)
    if not wheels:
        raise FileNotFoundError(f"No lakewatch wheel found in {wheel_dir}")
    print(f"Using wheel: {wheels[-1]}")
    return wheels[-1]


def _upload_file(
    w: WorkspaceClient, remote_path: str, local_path: pathlib.Path,
) -> None:
    """Upload a file to the workspace.

    Uses ``ImportFormat.AUTO`` so the API handles both source files and binary
    archives like ``.whl`` without the caller needing to distinguish.
    """
    with open(local_path, "rb") as f:
        w.workspace.upload(
            remote_path, f, format=ImportFormat.AUTO, overwrite=True,
        )


def _store_secret(w: WorkspaceClient, github_pat: str, secret_key: str) -> None:
    print("Storing GitHub PAT in Databricks secrets...")
    try:
        w.secrets.create_scope(scope=_SECRET_SCOPE)
    except ResourceAlreadyExists:
        pass
    w.secrets.put_secret(
        scope=_SECRET_SCOPE, key=secret_key, string_value=github_pat,
    )


def _delete_secret(w: WorkspaceClient, secret_key: str) -> None:
    try:
        w.secrets.delete_secret(scope=_SECRET_SCOPE, key=secret_key)
    except Exception:
        pass


def _submit_and_poll(
    w: WorkspaceClient,
    python_file: str,
    whl_remote: str,
    catalog: str,
    user: str,
    ref: str,
    secret_key: str,
) -> int:
    """Submit the test job, poll until done, print output, and return exit code."""
    print(f"Submitting preset regression tests as {user}...")

    waiter = w.jobs.submit(
        run_name="preset-regression-tests",
        tasks=[
            SubmitTask(
                task_key="preset_tests",
                spark_python_task=SparkPythonTask(
                    python_file=python_file,
                    parameters=[
                        "--catalog", catalog,
                        "--ref", ref,
                        "--secret-key", secret_key,
                    ],
                ),
                environment_key="Default",
            ),
        ],
        environments=[
            JobEnvironment(
                environment_key="Default",
                # "2" is the Databricks serverless client version (current generation).
                spec=Environment(client="2", dependencies=[whl_remote]),
            ),
        ],
        run_as=JobRunAs(user_name=user),
        queue=QueueSettings(enabled=True),
    )

    run_id = waiter.run_id
    print(f"Submitted run: {run_id}")
    print("Polling for completion...")

    run = None
    while True:
        run = w.jobs.get_run(run_id)
        if run.state.life_cycle_state in _TERMINAL_STATES:
            break
        print(f"  State: {run.state.life_cycle_state.value}")
        time.sleep(_POLL_INTERVAL_SECONDS)

    run_url = getattr(run, "run_page_url", None) or f"{w.config.host}#job/{run_id}"
    result_state = run.state.result_state
    result_str = result_state.value if result_state else "UNKNOWN"
    print(f"\nRun {run_id} finished: {result_str}")
    print(f"Run URL: {run_url}\n")

    _print_task_output(w, run)

    return 0 if result_state == RunResultState.SUCCESS else 1


def _print_task_output(w: WorkspaceClient, run) -> None:
    for task in run.tasks or []:
        if task.task_key != "preset_tests":
            continue
        try:
            output = w.jobs.get_run_output(task.run_id)
            if output.logs:
                print(output.logs)
                if getattr(output, "logs_truncated", False):
                    print("[Output truncated. View full logs in the Databricks UI.]")
            if output.error and "SystemExit" not in output.error:
                print(f"\nDriver error: {output.error}")
        except Exception as e:
            print(f"Could not retrieve task output: {e}", file=sys.stderr)
        break


def main() -> int:
    args = _parse_args()

    github_pat = os.environ.get("GITHUB_PAT")
    if not github_pat:
        print("Error: GITHUB_PAT environment variable is not set", file=sys.stderr)
        return 1

    w = WorkspaceClient(profile=args.profile)
    user = w.current_user.me().user_name

    repo_root = _find_repo_root()
    wheel_path = _build_wheel(repo_root)

    run_uuid = uuid.uuid4().hex[:12]
    # Per-run secret key prevents concurrent runs from overwriting each other.
    secret_key = f"github-pat-{run_uuid}"
    # Workspace API paths omit the /Workspace prefix.
    ws_api_base = f"/Users/{user}/.preset_tests/{run_uuid}"
    # Job file references need the full /Workspace prefix.
    ws_job_base = f"/Workspace{ws_api_base}"

    bundle_path = pathlib.Path(__file__).resolve().parent / _BUNDLE_FILENAME

    try:
        print(f"Uploading files to {ws_job_base}...")
        w.workspace.mkdirs(ws_api_base)

        _upload_file(w, f"{ws_api_base}/{_BUNDLE_FILENAME}", bundle_path)
        _upload_file(w, f"{ws_api_base}/{wheel_path.name}", wheel_path)

        _store_secret(w, github_pat, secret_key)

        return _submit_and_poll(
            w,
            python_file=f"{ws_job_base}/{_BUNDLE_FILENAME}",
            whl_remote=f"{ws_job_base}/{wheel_path.name}",
            catalog=args.catalog,
            user=user,
            ref=args.ref,
            secret_key=secret_key,
        )
    finally:
        print(f"Cleaning up {ws_job_base}...")
        _delete_secret(w, secret_key)
        try:
            w.workspace.delete(ws_api_base, recursive=True)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
