"""Self-contained preset regression test runner.

Runs on Databricks serverless with the lakewatch client wheel installed.
Uses PreviewEngine.evaluate() public API directly.

The GitHub PAT is read from Databricks secrets (scope: preset-tests,
key passed via --secret-key). The submit_preset_tests.py orchestrator stores
it there before submitting the job.

Usage:
GITHUB_PAT=$(gh auth token --user NON_DATABRICKS_GITHUB_USERNAME) bazel run //lakewatch/python-lib:submit_preset_tests \
    --remote_download_outputs=all --noshow_progress --noshow_loading_progress \
    -- --catalog lw-prod-catalog
"""
import argparse
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
import yaml
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# CLI argument parsing
# ---------------------------------------------------------------------------

_SECRET_SCOPE = "preset-tests"

_CATALOG_PATTERN = re.compile(r'^[a-zA-Z0-9_\-]+$')


def _validate_catalog(catalog: str) -> str:
    if not _CATALOG_PATTERN.match(catalog):
        raise argparse.ArgumentTypeError(
            f"Invalid catalog name: {catalog!r}. "
            "Only alphanumeric characters, underscores, and hyphens are allowed."
        )
    return catalog


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Preset regression test bundle for Databricks serverless.",
    )
    parser.add_argument(
        "--catalog",
        required=True,
        type=_validate_catalog,
        help="Unity Catalog catalog name (e.g. lw_citadel)",
    )
    parser.add_argument(
        "--ref",
        default=_DEFAULT_REF,
        help="Git ref (branch, tag, or commit SHA) to fetch presets from "
             f"(default: {_DEFAULT_REF})",
    )
    parser.add_argument(
        "--secret-key",
        required=True,
        help="Databricks secret key for the GitHub PAT",
    )
    return parser.parse_args()


def _load_github_pat(spark, secret_key: str) -> None:
    """Read the GitHub PAT from Databricks secrets and set it as GITHUB_PAT."""
    from pyspark.dbutils import DBUtils
    dbutils = DBUtils(spark)
    pat = dbutils.secrets.get(scope=_SECRET_SCOPE, key=secret_key)
    os.environ["GITHUB_PAT"] = pat


# ---------------------------------------------------------------------------
# PresetTestResult
# ---------------------------------------------------------------------------

@dataclass
class PresetTestResult:
    preset_name: str
    passed: bool
    output_counts: Dict[str, int] = field(default_factory=dict)
    error: Optional[str] = None
    skipped: bool = False
    skip_reason: Optional[str] = None
    duration_seconds: float = 0.0


# ---------------------------------------------------------------------------
# GitHub fetcher
# ---------------------------------------------------------------------------

_REPO = "antimatterhq/internal-content"
_DEFAULT_REF = "lakewatch-staging"
_BASE_URL = f"https://api.github.com/repos/{_REPO}/contents/presets"
_REQUEST_TIMEOUT_SECONDS = 30


def _build_request(url: str) -> urllib.request.Request:
    pat = os.environ.get("GITHUB_PAT")
    if not pat:
        raise EnvironmentError("GITHUB_PAT environment variable is not set")
    return urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {pat}",
            "Accept": "application/vnd.github.v3.raw",
        },
    )


def fetch_preset_index(ref: str) -> dict:
    url = f"{_BASE_URL}/index.yaml?ref={urllib.parse.quote(ref, safe='')}"
    req = _build_request(url)
    with urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT_SECONDS) as resp:
        return yaml.safe_load(resp.read().decode("utf-8"))


def fetch_preset_yaml(source: str, source_type: str, ref: str) -> str:
    url = (
        f"{_BASE_URL}/{urllib.parse.quote(source, safe='')}/"
        f"{urllib.parse.quote(source_type, safe='')}/preset.yaml"
        f"?ref={urllib.parse.quote(ref, safe='')}"
    )
    req = _build_request(url)
    with urllib.request.urlopen(req, timeout=_REQUEST_TIMEOUT_SECONDS) as resp:
        return resp.read().decode("utf-8")


def fetch_all_presets(ref: str) -> dict:
    index = fetch_preset_index(ref)
    presets = {}
    for entry in index.get("presets", []):
        source = entry.get("source")
        source_type = entry.get("sourceType")
        if not source or not source_type:
            print(f"Skipping index entry with missing source/sourceType: {entry}", file=sys.stderr)
            continue
        name = f"{source}_{source_type}"
        try:
            presets[name] = fetch_preset_yaml(source, source_type, ref)
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            print(f"Failed to fetch preset {name}: {e}", file=sys.stderr)
    return presets


# ---------------------------------------------------------------------------
# Test data registry
# ---------------------------------------------------------------------------

TEST_DATA_REGISTRY: Dict[str, str] = {
    "1password_audit_events": "bronze.1password_audit_events_ps2_tests",
    "1password_sign_in_attempts": "bronze.1password_sign_in_attempts_ps2_tests",
    "akamai_waf": "bronze.akamai_waf_events",
    "crowdstrike_events": "bronze.crowdstrike_events_ps2_tests",
    "m365_azure_ad": "bronze.m365_audit_azure_active_directory_ps2_tests",
    "m365_dlp": "bronze.m365_dlp_all",
    "m365_exchange": "bronze.m365_audit_exchange_ps2_tests",
    "m365_general": "bronze.m365_audit_general_ps2_tests",
    "m365_sharepoint": "bronze.m365_audit_sharepoint_ps2_tests",
    "microsoft_entra": "bronze.microsoft_entra_ps2_tests",
    "okta_system_logs": "bronze.okta_system_logs_ps2_tests",
    "slack_audit_logs": "bronze.slack_audit_logs_ps2_tests",
}


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

class PresetTestRunner:

    def __init__(self, spark, catalog: str):
        self._spark = spark
        self._catalog = catalog

    def run(
        self,
        preset_name: str,
        preset_yaml: str,
        table_path: str,
        record_limit: int = 100,
    ) -> PresetTestResult:
        from lakewatch.preset_development.preview_engine import PreviewEngine
        from lakewatch.preset_development.preview_parameters import PreviewParameters

        start = time.monotonic()
        if "." not in table_path:
            raise ValueError(
                f"Invalid table_path for {preset_name}: {table_path!r}. "
                "Expected format: 'schema.table'"
            )
        schema, table = table_path.split(".", 1)
        table_name = f"`{self._catalog}`.`{schema}`.`{table}`"
        try:
            params = (
                PreviewParameters(self._spark)
                .from_table()
                .set_table(table_name)
                .set_input_record_limit(record_limit)
            )

            engine = PreviewEngine(self._spark, preset_yaml, params)

            # gold_table_schema needs a valid catalog.schema to pass validation.
            # The actual gold table existence check only runs when display=True,
            # so any existing schema works here.
            gold_table_schema = f"`{self._catalog}`.bronze"
            engine.evaluate(gold_table_schema=gold_table_schema, display=False)

            _bronze, _pre_silver, silver_map, gold_map, _pre_bronze = engine.results()

            return self._evaluate_results(preset_name, silver_map, gold_map, start)

        except Exception as e:  # Broad catch intentional: test loop must continue for remaining presets.
            return PresetTestResult(
                preset_name=preset_name,
                passed=False,
                error=str(e).split("\n", 1)[0],
                duration_seconds=time.monotonic() - start,
            )

    def _evaluate_results(self, preset_name, silver_map, gold_map, start):
        duration = time.monotonic() - start

        if not gold_map:
            return PresetTestResult(
                preset_name=preset_name,
                passed=False,
                error="No gold outputs produced",
                duration_seconds=duration,
            )

        output_counts = {}
        for name, df in gold_map.items():
            output_counts[name] = df.count()

        empty_tables = [name for name, count in output_counts.items() if count == 0]
        if empty_tables:
            short_names = ", ".join(_gold_short_name(n) for n in empty_tables)
            return PresetTestResult(
                preset_name=preset_name,
                passed=False,
                output_counts=output_counts,
                error=f"Gold tables with 0 rows: {short_names}",
                duration_seconds=duration,
            )

        return PresetTestResult(
            preset_name=preset_name,
            passed=True,
            output_counts=output_counts,
            duration_seconds=duration,
        )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(spark, catalog: str, ref: str = _DEFAULT_REF, secret_key: str = "github-pat") -> int:
    _load_github_pat(spark, secret_key)
    print(f"Fetching presets from GitHub (ref={ref})...")
    all_presets = fetch_all_presets(ref)
    print(f"Fetched {len(all_presets)} presets from index")

    runner = PresetTestRunner(spark, catalog)
    results: List[PresetTestResult] = []

    for preset_name, preset_yaml in sorted(all_presets.items()):
        if preset_name not in TEST_DATA_REGISTRY:
            results.append(PresetTestResult(
                preset_name=preset_name, passed=False,
                skipped=True, skip_reason="no test data registered",
            ))
            continue

        print(f"Running: {preset_name}...", end=" ", flush=True)
        result = runner.run(preset_name, preset_yaml, TEST_DATA_REGISTRY[preset_name])
        results.append(result)
        if result.passed:
            print(f"PASS ({result.duration_seconds:.1f}s)")
        else:
            print(f"FAIL ({result.duration_seconds:.1f}s)")


    _print_summary(results)

    ran = [r for r in results if not r.skipped]
    if not ran:
        print("\nNo tests were executed.")
        return 1
    if any(not r.passed for r in ran):
        return 1
    return 0


def _gold_short_name(full_name: str) -> str:
    """Extract the short gold stage name (before the '/')."""
    return full_name.split("/")[0] if "/" in full_name else full_name


def _print_summary(results: List[PresetTestResult]) -> None:
    ran = [r for r in results if not r.skipped]
    passed_count = sum(1 for r in ran if r.passed)
    failed_results = [r for r in ran if not r.passed]
    skipped_count = sum(1 for r in results if r.skipped)

    col_name = 40
    col_status = 8
    col_time = 8
    col_detail = 50
    sep = "-" * (col_name + col_status + col_time + col_detail + 3)

    print(f"\n{'PRESET':<{col_name}} {'STATUS':<{col_status}} {'TIME':<{col_time}} DETAIL")
    print(sep)

    for r in results:
        if r.skipped:
            status = "SKIP"
            detail = r.skip_reason or ""
        elif r.passed:
            status = "PASS"
            gold_count = len(r.output_counts)
            total_rows = sum(r.output_counts.values())
            detail = f"{gold_count} gold tables, {total_rows} rows"
        else:
            status = "FAIL"
            detail = r.error[:col_detail] if r.error else ""

        time_str = f"{r.duration_seconds:.1f}s" if r.duration_seconds > 0 else ""
        print(
            f"{r.preset_name:<{col_name}} "
            f"{status:<{col_status}} "
            f"{time_str:<{col_time}} "
            f"{detail}"
        )

    print(sep)
    print(f"Ran: {len(ran)}  Passed: {passed_count}  Failed: {len(failed_results)}  Skipped: {skipped_count}")

    if failed_results:
        print(f"\n{'='*60}")
        print("FAILURE DETAILS")
        print(f"{'='*60}")
        for r in failed_results:
            print(f"\n  {r.preset_name}:")
            if r.error:
                print(f"    {r.error}")
            if r.output_counts:
                for name, count in r.output_counts.items():
                    marker = "  <-- EMPTY" if count == 0 else ""
                    print(f"    {_gold_short_name(name)}: {count} rows{marker}")


if __name__ == "__main__":
    args = _parse_args()

    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()
    result = main(spark, args.catalog, ref=args.ref, secret_key=args.secret_key)
    # Only call sys.exit for failures — Databricks serverless (IPython) treats
    # sys.exit(0) as an error, so we let the script exit naturally on success.
    if result != 0:
        sys.exit(result)
