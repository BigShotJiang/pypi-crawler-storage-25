import abc
import base64
import os
import time
from datetime import datetime

from lakewatch_api import ApiClient
from databricks.sdk.errors import ResourceDoesNotExist

from lakewatch.conn.conn import get_base_conn
from lakewatch.errors.errors import error_handler

from databricks.sdk import WorkspaceClient
from typing import Optional
from urllib.parse import urlparse


# Base path for the DASL API within Databricks
DASL_API_BASE_PATH = "/api/2.0/dasl-apiserver"


def _parse_workspace_url(workspace_url: str) -> tuple:
    """Parse a workspace URL and return (api_endpoint, hostname).

    Strips path, query params, and fragments from the URL, then constructs
    the full Lakewatch API endpoint.

    :returns: Tuple of (api_endpoint, hostname).
    """
    parsed_url = urlparse(workspace_url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
    hostname = parsed_url.hostname or parsed_url.path
    api_endpoint = f"{base_url}{DASL_API_BASE_PATH}"
    return api_endpoint, hostname

class Authorization(abc.ABC):
    """
    A common interface for Authentication
    """

    @abc.abstractmethod
    def client(self) -> ApiClient:
        raise NotImplementedError("conn method must be implemented")

    @abc.abstractmethod
    def workspace(self) -> str:
        raise NotImplementedError("workspace method must be implemented")


class NotebookAuth(Authorization):
    """
    Authorization implementation for use within Databricks notebooks.

    This auth class uses the native Databricks notebook context to obtain
    the API URL and token, then uses those directly to authenticate with
    the Lakewatch API (dasl-apiserver) running within Databricks.

    This is the simplest auth method when running inside a Databricks notebook
    as it requires no additional configuration.
    """

    def __init__(self):
        """
        Initialize NotebookAuth by extracting the API URL and token from
        the Databricks notebook context.

        :raises Exception: If not running inside a Databricks notebook.
        """
        if "DATABRICKS_RUNTIME_VERSION" not in os.environ:
            raise Exception(
                "NotebookAuth can only be used within a Databricks notebook. "
                "Use a different Authorization class outside of notebooks."
            )

        # Import dbutils only when inside a notebook context
        from databricks.sdk.runtime import dbutils

        context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()


        # Get the API URL and token from notebook context
        api_url = context.apiUrl().getOrElse(None)
        if api_url is None:
            raise Exception("Could not obtain API URL from notebook context")

        self._token = context.apiToken().getOrElse(None)
        if self._token is None:
            raise Exception("Could not obtain API token from notebook context")

        # Extract workspace name from the browser host name
        self._workspace = context.browserHostName().getOrElse(None)
        if self._workspace is None:
            raise Exception("Could not obtain workspace hostname from notebook context")

        # Create the API client and configure authentication
        self._client = get_base_conn(host=f"{api_url}{DASL_API_BASE_PATH}")
        # Set access_token on configuration so auth_settings() returns proper auth
        self._client.configuration.access_token = self._token

    def client(self) -> ApiClient:
        """
        Return an API client configured for the Lakewatch API.

        The client uses the native Databricks token which is managed by
        the notebook runtime, so no refresh logic is needed.

        :return: An API client with valid authentication.
        """
        return self._client

    def workspace(self) -> str:
        """
        Return the workspace hostname.

        :return: The workspace hostname (e.g., 'myworkspace.cloud.databricks.com').
        """
        return self._workspace


class PATAuth(Authorization):
    """
    Authorization implementation using a Databricks Personal Access Token (PAT).

    Use this auth class to connect to the Lakewatch API from outside a
    Databricks notebook, such as from a local script, CI/CD pipeline, or
    any environment where you have a Databricks PAT.

    Example usage:
        from lakewatch import Client
        client = Client.for_workspace(
            workspace_url="https://my-workspace.cloud.databricks.com",
            token="dapi...",
        )
    """

    def __init__(self, workspace_url: str, token: str):
        """
        Initialize PATAuth with a workspace URL and PAT.

        :param workspace_url: Databricks workspace URL. Accepts any of these formats:
            - "https://dbc-abc123.cloud.databricks.com"
            - "https://dbc-abc123.cloud.databricks.com/?o=12345"
            - "https://adb-12345.6.azuredatabricks.net"
            Path and query parameters are automatically stripped.
            Note: Account-level URLs (e.g., "https://accounts.cloud.databricks.com")
            are not supported — use the workspace deployment URL.
        :param token: A Databricks Personal Access Token (PAT).
        :raises ValueError: If workspace_url or token is empty.
        """
        if not workspace_url or not workspace_url.strip():
            raise ValueError("workspace_url is required for PAT authentication")
        if not token or not token.strip():
            raise ValueError("token is required for PAT authentication")

        api_endpoint, self._workspace = _parse_workspace_url(workspace_url)
        self._client = get_base_conn(host=api_endpoint)
        self._client.configuration.access_token = token

    def client(self) -> ApiClient:
        """
        Return an API client configured for the Lakewatch API.

        The client uses the PAT directly as a Bearer token. PATs are
        long-lived, so no refresh logic is needed.

        :return: An API client with valid authentication.
        """
        return self._client

    def workspace(self) -> str:
        """
        Return the workspace hostname.

        :return: The workspace hostname (e.g., 'my-workspace.cloud.databricks.com').
        """
        return self._workspace
