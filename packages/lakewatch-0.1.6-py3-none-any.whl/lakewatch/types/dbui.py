from typing import Optional, List
from pydantic import BaseModel

from lakewatch_api import (
    DbuiV1ObservableEventsList,
    DbuiV1ObservableEventsListItemsInnerNotable,
    DbuiV1ObservableEventsListItemsInner,
    DbuiV1TableColumnDetails,
)


class Dbui(BaseModel):
    class TableColumnDetails(BaseModel):
        """
        Table column details.

        Attributes:
            name (Optional[str]):
                The column name.
            type_name (Optional[str]):
                The name of the column type.
            type_detail (Optional[str]):
                Additional information about the column's type.
            position (Optional[int]):
                The column's index in the table.
            nullable (Optional[bool]):
                Indicates if this column is nullable.
        """

        name: Optional[str] = None
        type_name: Optional[str] = None
        type_detail: Optional[str] = None
        position: Optional[int] = None
        nullable: Optional[bool] = None

        @staticmethod
        def from_api_obj(
            obj: Optional[DbuiV1TableColumnDetails],
        ) -> Optional["Dbui.TableColumnDetails"]:
            if obj is None:
                return None
            return Dbui.TableColumnDetails(
                name=obj.name,
                type_name=obj.type_name,
                type_detail=obj.type_detail,
                position=obj.position,
                nullable=obj.nullable,
            )

        def to_api_obj(self) -> DbuiV1TableColumnDetails:
            return DbuiV1TableColumnDetails(
                name=self.name,
                type_name=self.type_name,
                type_detail=self.type_detail,
                position=self.position,
                nullable=self.nullable,
            )

    class ObservableEvents(BaseModel):
        class Notable(BaseModel):
            id: Optional[str] = None
            rule_name: Optional[str] = None
            summary: Optional[str] = None

            @staticmethod
            def from_api_obj(
                obj: Optional[DbuiV1ObservableEventsListItemsInnerNotable],
            ) -> Optional["Dbui.ObservableEvents.Notable"]:
                if obj is None:
                    return None

                return Dbui.ObservableEvents.Notable(id=obj.id, rule_name=obj.rule_name, summary=obj.summary)

        class Event(BaseModel):
            var_from: Optional[str] = None
            adjust_by: Optional[float] = None
            notable: Optional["Dbui.ObservableEvents.Notable"] = None

            @staticmethod
            def from_api_obj(
                obj: Optional[DbuiV1ObservableEventsListItemsInner],
            ) -> Optional["Dbui.ObservableEvents.Event"]:
                if obj is None:
                    return None

                return Dbui.ObservableEvents.Event(
                    var_from=obj.var_from,
                    adjust_by=obj.adjust_by,
                    notable=Dbui.ObservableEvents.Notable.from_api_obj(obj.notable),
                )

        class EventsList(BaseModel):
            cursor: Optional[str] = None
            items: List["Dbui.ObservableEvents.Event"] = []

            @staticmethod
            def from_api_obj(
                obj: Optional[DbuiV1ObservableEventsList],
            ) -> Optional["Dbui.ObservableEvents.EventsList"]:
                if obj is None:
                    return None

                return Dbui.ObservableEvents.EventsList(
                    cursor=obj.cursor,
                    items=[Dbui.ObservableEvents.Event.from_api_obj(item) for item in obj.items],
                )
