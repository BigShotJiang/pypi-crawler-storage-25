from __future__ import annotations

from copy import deepcopy
from typing import Any, Callable, Iterator, Optional, TypeVar, Union

from lakewatch_api import (
    ContentV1Api,
    CoreV1Api,
    CoreV1MigrationStatus,
    DbuiV1Api,
    WorkspaceV1Api,
)
from lakewatch.auth.auth import (
    Authorization,
    NotebookAuth,
    PATAuth,
)
from lakewatch.errors.errors import error_handler

from .exec_rule import ExecRule
from .helpers import Helpers
from .types import (
    Case,
    CaseList,
    CreateOrAmendCaseRequest,
    DataSource,
    DataSourcePreset,
    DataSourcePresetsList,
    Dbui,
    Metadata,
    Rule,
    WorkspaceConfig,
)

T = TypeVar("T")


class Client:
    """
    Antimatter security lakehouse client.
    """

    def __init__(
        self,
        auth: Authorization,
    ):
        """
        Initialize a new client. You should generally prefer to use
        the new_workspace function if creating a new workspace or the
        for_workspace function if connecting to an existing workspace.

        :param auth: Authorization instance for authorizing requests to
            the dasl control plane.
        :returns: Client
        """
        self.auth = auth

    @staticmethod
    def for_workspace(
        workspace_url: Optional[str] = None,
        token: Optional[str] = None,
    ) -> "Client":
        """
        Create a client for the argument workspace, if specified, or
        the current workspace if running in databricks notebook context.

        :param workspace_url: Databricks workspace URL. Accepts formats like:
            "https://dbc-abc123.cloud.databricks.com",
            "https://dbc-abc123.cloud.databricks.com/?o=12345", or
            "https://adb-12345.6.azuredatabricks.net".
            Path and query parameters are automatically stripped.
            Account-level URLs are not supported.
            Required when using token-based auth. If omitted and running in a
            notebook, the URL is inferred from the notebook context.
        :param token: A Databricks Personal Access Token (PAT). If provided,
            the client will use this token for auth instead of notebook-based
            auth. Requires workspace_url to also be provided.
        :returns: Client for the existing workspace.
        """
        with error_handler():
            if token:
                if not workspace_url:
                    raise ValueError(
                        "workspace_url is required when using token-based authentication"
                    )
                return Client(PATAuth(workspace_url=workspace_url, token=token))
            return Client(NotebookAuth())

    def _workspace_client(self) -> WorkspaceV1Api:
        return WorkspaceV1Api(self.auth.client())

    def _core_client(self) -> CoreV1Api:
        return CoreV1Api(self.auth.client())

    def _dbui_client(self) -> DbuiV1Api:
        return DbuiV1Api(self.auth.client())

    def _content_client(self) -> ContentV1Api:
        return ContentV1Api(self.auth.client())

    def _workspace(self) -> str:
        return self.auth.workspace()

    def _list_iter_paginated(
        self,
        list_func: Callable[..., Any],
        convert: Callable[[Any], T],
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Iterator[T]:
        """
        Generic helper for paginated list functions.
        """
        current_cursor = cursor
        results_so_far = 0
        while True:
            page_limit = limit - results_so_far if limit is not None else None
            if limit is not None and page_limit <= 0:
                break

            with error_handler():
                response = list_func(
                    cursor=current_cursor,
                    limit=page_limit,
                )

            for item in response.items:
                yield convert(item)
                results_so_far += 1

            current_cursor = response.metadata.cursor if hasattr(response, "metadata") else None
            if current_cursor is None:
                break

    def get_config(self) -> WorkspaceConfig:
        """
        Retrieve the WorkspaceConfig from the DASL server. The returned
        value can be updated directly and passed to put_config in order
        to make changes.

        :returns: WorkspaceConfig containing the current configuration.
        """
        with error_handler():
            return WorkspaceConfig.from_api_obj(self._workspace_client().workspace_v1_get_config())

    def put_config(
        self,
        config_in: WorkspaceConfig,
    ) -> None:
        """
        Update the WorkspaceConfig stored in the DASL server. See the
        WorkspaceConfig docs for dtails about its contents.

        :param config_in: WorkspaceConfig to replace the existing.
        :returns: WorkspaceConfig. Note that the returned value is a
            clone of config_in and may not be precisely equal to the
            originally passed value.
        """
        with error_handler():
            config = deepcopy(config_in)
            if config.metadata is None:
                config.metadata = Metadata(
                    name="config",
                    workspace=self._workspace(),
                )

            # reset the version; let the server set the version for us
            config.metadata.version = None

            self._workspace_client().workspace_v1_put_config(
                config.to_api_obj(),
            )

    def get_datasource(self, name: str) -> DataSource:
        """
        Get the DataSource with the argument name from the DASL server. The
        returned value can be updated directly and passed to update_datasource
        in order to make changes.

        :param name: The unique name of the DataSource within this workspace
        :returns: DataSource
        """
        with error_handler():
            return DataSource.from_api_obj(self._core_client().core_v1_get_data_source(name))

    def delete_datasource(self, name: str) -> None:
        """
        Delete the DataSource with the argument name from the DASL server.
        The DataSource will not necessarily be deleted immediately as the
        server will dispatch background tasks to clean up any allocated
        resources before actually deleting the resource, so it may take
        some time before its name is available for reuse.

        :param name: The unique name of the DataSource within this workspace
        """
        with error_handler():
            self._core_client().core_v1_delete_data_source(name)

    def list_datasources(self, cursor: Optional[str] = None, limit: Optional[int] = None) -> Iterator[DataSource]:
        """
        List the DataSources in this workspace. Each yielded DataSource
        contains all fields in the DataSource as if it were fetched
        using the get_datasource method.

        :param cursor: The ID of a DataSource. If specified, the results
            will contain DataSources starting (lexically) directly after
            this DataSource. If not specified, then the results will begin
            with the lexically least DataSource.
        :param limit: The maximum number of DataSources to yield. If there
            are fewer than this number of DataSources beginning directly
            after `cursor`, then all such DataSources will be yielded. If
            not specified, then all DataSources starting directly after
            `cursor` will be returned.
        :yields DataSource: One DataSource at a time in lexically
            increasing order
        """
        return self._list_iter_paginated(
            list_func=self._core_client().core_v1_list_data_sources,
            convert=DataSource.from_api_obj,
            cursor=cursor,
            limit=limit,
        )

    def create_datasource(self, name: str, ds_in: DataSource) -> DataSource:
        """
        Create a new DataSource. The chosen name must be unique for your
        workspace, and cannot refer to a DataSource that already exists
        and has not been deleted. See the documentation for delete_datasource
        as there are some caveats around name reuse.

        :param name: The display name of this DataSource in the workspace.
        :param ds_in: The specification of the DataSource to create. See
            the documentation for the DataSource type for more details.
        :returns DataSource: Note that the returned value is a
            clone of ds_in and may not be precisely equal to the
            originally passed value.
        """
        with error_handler():
            ds = deepcopy(ds_in)
            if ds.metadata is None:
                ds.metadata = Metadata()

            ds.metadata.name = None
            ds.metadata.version = None
            ds.metadata.display_name = name
            ds.metadata.workspace = self._workspace()

            result = self._core_client().core_v1_create_data_source(ds.to_api_obj())
            return DataSource.from_api_obj(result)

    def replace_datasource(self, name: str, ds_in: DataSource) -> DataSource:
        """
        Replace an existing DataSource. The name must refer to a DataSource
        that already exists in your workspace.

        :param name: The name of the existing DataSource to replace.
        :param ds_in: The specification of the DataSource taking the place
            of the existing DataSource.
        :returns DataSource: Note that the returned value is a
            clone of ds_in and may not be precisely equal to the
            originally passed value.
        """
        with error_handler():
            ds = deepcopy(ds_in)
            if ds.metadata is None:
                ds.metadata = Metadata(
                    name=name,
                    workspace=self._workspace(),
                )

            # reset the version; let the server set the version for us
            ds.metadata.version = None

            result = self._core_client().core_v1_replace_data_source(
                name,
                ds.to_api_obj(),
            )
            return DataSource.from_api_obj(result)

    def get_rule(self, id: str) -> Rule:
        """
        Get the Rule with the rule id from the DASL server. The
        returned value can be updated directly and passed to update_rule
        in order to make changes.

        :param id: The unique id of the Rule within this workspace
        :returns: Rule
        """
        with error_handler():
            return Rule.from_api_obj(self._core_client().core_v1_get_rule(id))

    def delete_rule(self, id: str) -> None:
        """
        Delete the Rule with the argument id from the DASL server.
        The Rule will not necessarily be deleted immediately as the
        server will dispatch background tasks to clean up any allocated
        resources before actually deleting the resource, so it may take
        some time before its name is available for reuse.

        :param id: The unique id of the Rule within this workspace
        """
        with error_handler():
            self._core_client().core_v1_delete_rule(id)

    def list_rules(self, cursor: Optional[str] = None, limit: Optional[int] = None) -> Iterator[Rule]:
        """
        List the Rules in this workspace. Each yielded Rule contains
        all fields in the Rule as if it were fetched using the
        get_rule method.

        :param cursor: The ID of a Rule. If specified, the results will
            contain DataSources starting (lexically) directly after this
            Rule. If not specified, then the results will begin with the
            lexically least Rule.
        :param limit: The maximum number of Rules to yield. If there are
            fewer than this number of Rules beginning directly after
            `cursor`, then all such Rules will be yielded. If not specified,
            then all Rules starting directly after `cursor` will be returned.
        :yields Rule: One Rule at a time in lexically increasing order.
        """
        return self._list_iter_paginated(
            list_func=self._core_client().core_v1_list_rules,
            convert=Rule.from_api_obj,
            cursor=cursor,
            limit=limit,
        )

    def create_rule(self, name: str, rule_in: Rule) -> Rule:
        """
        Create a new Rule with the provided display name. Note, once created,
        a rule ID will be generated for this rule. The ID must be provided in
        future API interactions with this Rule.

        :param name: The display name of this Rule in the workspace.
        :param rule_in: The specification of the Rule to create. See
            the documentation for the Rule type for more details.
        :returns Rule: Note that the returned value is a clone of
            rule_in and may not be precisely equal to the originally
            passed value.
        """
        with error_handler():
            rule = deepcopy(rule_in)
            if rule.metadata is None:
                rule.metadata = Metadata()

            rule.metadata.name = None
            rule.metadata.version = None
            rule.metadata.display_name = name
            rule.metadata.workspace = self._workspace()

            result = self._core_client().core_v1_create_rule(rule.to_api_obj())
            return Rule.from_api_obj(result)

    def replace_rule(self, id: str, rule_in: Rule) -> Rule:
        """
        Replace an existing Rule. The id must refer to a Rule
        that already exists in your workspace.

        :param id: The id of the existing Rule to replace.
        :param rule_in: The specification of the Rule taking the place
            of the existing Rule.
        :returns Rule: Note that the returned value is a clone of
            rule_in and may not be precisely equal to the originally
            passed value.
        """
        with error_handler():
            rule = deepcopy(rule_in)
            if rule.metadata is None:
                rule.metadata = Metadata(
                    name=id,
                    workspace=self._workspace(),
                )

            # reset the version; let the server set the version for us
            rule.metadata.version = None

            result = self._core_client().core_v1_replace_rule(
                id,
                rule.to_api_obj(),
            )
        return Rule.from_api_obj(result)

    def exec_rule(
        self,
        spark,
        rule_in: Union[Rule, str],
    ) -> ExecRule:
        """
        Locally execute a Rule. Must be run from within a Databricks
        notebook or else an exception will be raised. This is intended
        to facilitate Rule development.

        :param spark: Spark context from Databricks notebook. Will be
            injected into the execution environment for use by the
            Rule notebook.
        :param rule_in:
            The specification of the Rule to execute. If specified as
            a string, it should be in YAML format.
        :returns ExecRule: A class containing various information and
            functionality relating to the execution. See the docs for
            ExecRule for additional details, but note that you must
            call its cleanup function or tables created just for this
            request will leak.
        """
        rule = rule_in
        if isinstance(rule_in, str):
            rule = Rule.from_yaml_str(rule_in)

        Helpers.ensure_databricks()

        with error_handler():
            result = self._core_client().core_v1_render_rule(
                rule.to_api_obj(),
            )

            try:
                import notebook_utils  # noqa: F401
            except ImportError:
                raise ImportError(
                    "Package 'notebook_utils' not found. "
                    "Install it within this this notebook using "
                    f"%pip install {result.notebook_utils_path}"
                )

            exec(result.content, {"spark": spark})
            return ExecRule(spark, result.tables)

    def get_observable_events(
        self,
        warehouse: str,
        kind: str,
        value: str,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dbui.ObservableEvents.EventsList:
        """
        Get the observable events associated with a specific field and value.

        :param warehouse: The warehouse id to perform the operation on
        :param kind: The observable kind
        :param value: The observable value
        :param cursor: A cursor to be used when paginating results
        :param limit: A limit of the number of results to return
        :returns: EventsList
        """
        with error_handler():
            return Dbui.ObservableEvents.EventsList.from_api_obj(
                self._dbui_client().dbui_v1_get_observable_events(
                    warehouse=warehouse,
                    kind=kind,
                    value=value,
                    cursor=cursor,
                    limit=limit,
                )
            )

    def list_cases(
        self,
        cursor: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> CaseList:
        """
        List the Cases in this workspace.

        :param cursor: A cursor for pagination. If specified, the results will
            contain Cases starting after this cursor.
        :param limit: The maximum number of Cases to yield.
        :yields Case: One Case at a time.
        """
        with error_handler():
            return CaseList.from_api_obj(self._core_client().core_v1_list_cases(cursor, limit))

    def get_case(self, case_id: str) -> Case:
        """
        Get the Case with the specified ID from the server.

        :param case_id: The unique ID of the Case (uuidv7 format).
        :returns: Case
        """
        with error_handler():
            return Case.from_api_obj(self._core_client().core_v1_get_case(case_id))

    def create_or_amend_case(self, request: CreateOrAmendCaseRequest) -> Case:
        """
        Create a new Case or amend an existing Case.

        This method can be used to:
        - Create a new case from a notable (FINDING type)
        - Create a new case from an operational alert (OPERATIONAL_ALERT type)
        - Amend an existing case by adding new events

        :param request: CreateOrAmendCaseRequest containing the notable_info,
            operational_alert, or case to create/amend.
        :returns: Case - the created or amended case.
        """
        with error_handler():
            return Case.from_api_obj(self._core_client().core_v1_create_or_amend_case(request.to_api_obj()))

    def list_presets(self) -> DataSourcePresetsList:
        """
        List the Presets in this workspace. This will include any user defined
        presets if a custom presets path has been configured in the workspace.

        :returns: DataSourcePresetsList
        """
        with error_handler():
            return DataSourcePresetsList.from_api_obj(self._content_client().content_v1_get_preset_data_sources())

    def get_preset(self, name: str) -> DataSourcePreset:
        """
        Get the preset with the argument name from the DASL server. If the preset name
        begins with 'internal_' it will instead be collected from the user catalog,
        provided a preset path is set in the workspace config.

        :param name: The unique name of the DataSource preset within this workspace.
        :returns: DataSourcePreset
        """
        with error_handler():
            return DataSourcePreset.from_api_obj(self._content_client().content_v1_get_preset_datasource(name))

    def purge_preset_cache(self) -> None:
        """
        Purge the datasource cache presets. This will cause the DASL workspace
        to fetch presets from provided sources.
        """
        with error_handler():
            self._content_client().content_v1_preset_purge_cache()

    def migration_status(self) -> CoreV1MigrationStatus:
        """
        Fetch the current migration status for the workspace.
        :return: THe current migration status for the given workspace
        """
        with error_handler():
            return self._core_client().core_v1_get_migration_status()
