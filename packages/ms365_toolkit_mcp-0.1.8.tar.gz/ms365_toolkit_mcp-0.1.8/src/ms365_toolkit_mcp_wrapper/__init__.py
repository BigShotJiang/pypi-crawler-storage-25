from __future__ import annotations

from ms365_toolkit.mcp import main as _main


def main(argv: object | None = None) -> int:
    return _main(argv)
