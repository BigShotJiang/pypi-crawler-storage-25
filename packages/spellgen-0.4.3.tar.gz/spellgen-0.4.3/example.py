import spellgen

settings = spellgen.CardFactorySettings(
    assets_path="assets",
    glyph_defs_path="glyph_defs/SpellDescription.xml",
    spell_title_font_path="glyph_defs/SpellTitle_sm.xml",
    spell_description_font_path="glyph_defs/SpellDescription.xml",
    shadow_school_pip_path="school_pip_icons/pip_shadow_large.png",
    balance_school_pip_path="school_pip_icons/pip_balance_no_glow.png",
    death_school_pip_path="school_pip_icons/pip_death_no_glow.png",
    fire_school_pip_path="school_pip_icons/pip_fire_no_glow.png",
    ice_school_pip_path="school_pip_icons/pip_ice_no_glow.png",
    life_school_pip_path="school_pip_icons/pip_life_no_glow.png",
    myth_school_pip_path="school_pip_icons/pip_myth_no_glow.png",
    storm_school_pip_path="school_pip_icons/pip_storm_no_glow.png",
    rank_number_icons=[
        "rank_icons/Rank_00.webp", "rank_icons/Rank_01.webp", "rank_icons/Rank_02.webp",
        "rank_icons/Rank_03.webp", "rank_icons/Rank_04.webp", "rank_icons/Rank_05.webp",
        "rank_icons/Rank_06.webp", "rank_icons/Rank_07.webp", "rank_icons/Rank_08.webp",
        "rank_icons/Rank_09.webp", "rank_icons/Rank_10.webp", "rank_icons/Rank_11.webp",
        "rank_icons/Rank_12.webp", "rank_icons/Rank_13.webp", "rank_icons/Rank_14.webp",
        "rank_icons/Rank_15.webp", "rank_icons/Rank_16.webp", "rank_icons/Rank_17.webp",
        "rank_icons/Rank_18.webp", "rank_icons/Rank_19.webp", "rank_icons/Rank_20.webp",
    ],
    rank_minus_icon="rank_icons/Rank_Minus.webp",
    rank_plus_icon="rank_icons/Rank_Plus.webp",
    rank_x_icon="rank_icons/Rank_X.webp",
    cloak_icon="Type_Cloak.dds",
    cloak_frame_icon="Type_Frame.dds",
    pvp_only_icon="Icon_Flag_PVPOnly.dds",
    pve_only_icon="Type_Card_PVE.dds",
    banned_icon="Type_Card_Banned.dds",
    single_use_icon="Type_x1_PvP.dds",
    cannot_discard_icon="Art_Lock.dds",
    essence_collection_icon="Button_Monster_Magic.dds",
    pierce_icon="Icon_Armor_Penetration.dds",
    pierce_frame_icon="Art_Red01.dds",
    level_requirement_icon="Type_LevelReqPvP.dds",
    default_icon_size = (16, 16),
    default_wide_icon_size = (32, 16),
    cache_madlibs = True
)

factory = spellgen.CardFactory(settings)

card = spellgen.SpellCard(
    title = "Benjamin Time",
    description = "A very IMPORTANT time for Benjamin",
    frame = "frames/School_Fire_Blnk.dds",
    cost = spellgen.SpellCost(20, True, 1, 1, 1, 0, 0, 0, 0, 0),
    school_icon = "school_icons/Icon_Fire.png",
    spell_image = "spell_icons/Spell_Death_Firebane.dds",
    type_icon = "type_icons/Type_Damage.png",
    accuracy = 69,
    booster_pack = "booster_packs/Booster_Eye_of_Bartleby.dds",
    cloaked = False,
    no_pvp = True,
    no_pve = True,
    pierce = 100,
    level_requirement = 69,
    cannot_discard = False,
    essence_collection = False,
    single_use = True
)

img = factory.generate(card)

img.save("testpy.webp")