use std::path::PathBuf;
use std::{fs::File, io::BufReader, path::Path};
use std::io::{Cursor, Read};
use std::sync::OnceLock;
use ahash::AHashMap;
use eyre::Context;
use image::imageops::overlay;
use image::{DynamicImage, ImageError, ImageFormat, RgbaImage};
use log::{debug, error};
use xml::{reader::XmlEvent, EventReader};

#[derive(Clone)]
pub struct GlyphAtlas {
    glyphs: AHashMap<char, Glyph>,
    invalid_glyph: char,
    kernings: AHashMap<(char, char), i8>,
}

impl GlyphAtlas {
    fn empty_glyph() -> &'static Glyph {
        static EMPTY_GLYPH: OnceLock<Glyph> = OnceLock::new();

        EMPTY_GLYPH.get_or_init(|| Glyph {
            img: RgbaImage::new(0, 0),
            offsets: (0, 0, 0),
            value: '\0',
        })
    }

    fn fallback_glyph(&self) -> Option<&Glyph> {
        self.glyphs
            .get(&self.invalid_glyph)
            .or_else(|| self.glyphs.get(&' '))
            .or_else(|| self.glyphs.values().next())
    }

    #[cfg(not(target_arch = "wasm32"))]
    pub fn open(path: impl AsRef<Path>, base_path: impl AsRef<Path>) -> eyre::Result<Self> {
        let path = base_path.as_ref().join(path);
        let file = File::open(&path)?;

        debug!("Successfully opened file for glypth atlas.");
        let file = BufReader::new(file);

        let mut parser = EventReader::new(file);

        let mut glyphs = AHashMap::new();
        let mut kernings = AHashMap::new();
        let mut invalid_glyph = ' ';
        let base_path = if let Some(base_path) = path.parent() { base_path } else { base_path.as_ref() };

        while let Ok(e) = parser.next() {
            if let XmlEvent::StartElement {
                name, attributes, ..
            } = &e
            {
                if name.local_name.as_str() == "GlyphisFont" {
                    for attribute in attributes {
                        if attribute.name.local_name.as_str() == "InvalidGlyph" {
                            invalid_glyph =
                                unsafe {
                                    char::from_u32_unchecked(attribute.value.parse().expect(
                                        "Failed to read 'InvalidGlyph' attribute as a 'char'",
                                    ))
                                };
                        }
                    }
                    Self::handle_font(&mut parser, &mut glyphs, &mut kernings, base_path)?;
                } else {
                    error!("Unexpected start of element: {name}");
                }
            }
            if let XmlEvent::EndDocument = &e {
                break;
            }
        }

        Ok(Self {
            glyphs,
            kernings,
            invalid_glyph,
        })
    }

    #[cfg(target_arch = "wasm32")]
    pub async fn open(path: impl AsRef<Path>, base_path: impl AsRef<Path>) -> eyre::Result<Self> {
        let path = base_path.as_ref().join(path);
        let response = reqwest::get(path.to_str().unwrap())
            .await
            .wrap_err_with(|| format!("Failed to get pip image: {}", path.display()))?;
        let file = response
            .text()
            .await
            .wrap_err_with(|| format!("Failed to get pip image bytes: {}", path.display()))?;

        debug!("Successfully opened file for glyph atlas.");
        let file = Cursor::new(file);

        let mut parser = EventReader::new(file);

        let mut glyphs = AHashMap::new();
        let mut kernings = AHashMap::new();
        let mut invalid_glyph = ' ';
        let base_path = if let Some(base_path) = path.parent() { base_path } else { base_path.as_ref() };

        while let Ok(e) = parser.next() {
            if let XmlEvent::StartElement {
                name, attributes, ..
            } = &e
            {
                if name.local_name.as_str() == "GlyphisFont" {
                    for attribute in attributes {
                        if attribute.name.local_name.as_str() == "InvalidGlyph" {
                            invalid_glyph =
                                unsafe {
                                    char::from_u32_unchecked(attribute.value.parse().expect(
                                        "Failed to read 'InvalidGlyph' attribute as a 'char'",
                                    ))
                                };
                        }
                    }
                    Self::handle_font(&mut parser, &mut glyphs, &mut kernings, base_path).await?;
                } else {
                    error!("Unexpected start of element: {name}");
                }
            }
            if let XmlEvent::EndDocument = &e {
                break;
            }
        }

        Ok(Self {
            glyphs,
            kernings,
            invalid_glyph,
        })
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn handle_font<R: Read>(
        parser: &mut EventReader<R>,
        glyphs: &mut AHashMap<char, Glyph>,
        kernings: &mut AHashMap<(char, char), i8>,
        base_path: &Path
    ) -> eyre::Result<()> {
        let mut pages = Vec::new();
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => match name.local_name.as_str() {
                    "Pages" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                pages.reserve(count);
                            }
                        }
                        Self::handle_pages(parser, &mut pages, base_path)?;
                    }
                    "Glyphs" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                glyphs.reserve(count);
                            }
                        }
                        Self::handle_glyphs(parser, glyphs, &pages);
                    }
                    "KerningPairs" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                kernings.reserve(count);
                            }
                        }
                        Self::handle_kerning_pairs(parser, kernings);
                    }
                    _ => {
                        error!("Unexpected start of element: {name}");
                    }
                },
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "GlyphisFont" {
                        return Ok(());
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    #[cfg(target_arch = "wasm32")]
    async fn handle_font<R: Read>(
        parser: &mut EventReader<R>,
        glyphs: &mut AHashMap<char, Glyph>,
        kernings: &mut AHashMap<(char, char), i8>,
        base_path: &Path
    ) -> eyre::Result<()> {
        let mut pages = Vec::new();
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => match name.local_name.as_str() {
                    "Pages" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                pages.reserve(count);
                            }
                        }
                        Self::handle_pages(parser, &mut pages, base_path).await?;
                    }
                    "Glyphs" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                glyphs.reserve(count);
                            }
                        }
                        Self::handle_glyphs(parser, glyphs, &pages);
                    }
                    "KerningPairs" => {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "Count" {
                                let count = attribute
                                    .value
                                    .parse()
                                    .expect("Failed to parse 'Count' attribute as a usize");
                                kernings.reserve(count);
                            }
                        }
                        Self::handle_kerning_pairs(parser, kernings);
                    }
                    _ => {
                        error!("Unexpected start of element: {name}");
                    }
                },
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "GlyphisFont" {
                        return Ok(());
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn handle_pages<R: Read>(
        parser: &mut EventReader<R>,
        pages: &mut Vec<DynamicImage>,
        base_path: &Path
    ) -> eyre::Result<()> {
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => {
                    if name.local_name.as_str() == "Page" {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "FileName" {
                                let file_path = Path::new(&attribute.value);
                                let mut path = PathBuf::from(base_path);
                                path.push(file_path);
                                if path.extension().map(|e| e.to_str()) == Some(Some("dds")) {
                                        let dds = ddsfile::Dds::read(std::fs::File::open(&path)?)?;


                                    if dds.get_bits_per_pixel() == Some(8) {
                                        let pixels = dds.data.iter().flat_map(|p| [0xff, 0xff, 0xff, *p]).collect::<Vec<u8>>();
                                        let image = image::RgbaImage::from_vec(dds.get_width(), dds.get_height(), pixels).expect("Failed to create image from data");
                                        path.set_extension("webp");
                                        image.save(&path)?;
                                    }
                                }
                                let page = image::ImageReader::open(&path)
                                    .wrap_err_with(|| format!("Failed to load file from page path: {}", path.display()))?
                                    .decode()
                                    .wrap_err_with(|| format!("Failed to decode file from page path: {}", path.display()))?;
                                pages.push(page);
                            }
                        }
                    } else {
                        error!("Unexpected start of element: {name}");
                    }
                }
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "Page" {
                        //Good
                    } else if name.local_name.as_str() == "Pages" {
                        return Ok(());
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    #[cfg(target_arch = "wasm32")]
    async fn handle_pages<R: Read>(
        parser: &mut EventReader<R>,
        pages: &mut Vec<DynamicImage>,
        base_path: &Path
    ) -> eyre::Result<()> {
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => {
                    if name.local_name.as_str() == "Page" {
                        for attribute in attributes {
                            if attribute.name.local_name.as_str() == "FileName" {
                                let file_path = Path::new(&attribute.value);
                                let mut path = PathBuf::from(base_path);
                                path.push(file_path);
                                let page = if path.extension().map(|e| e.to_str()) == Some(Some("dds")) {
                                    let dds = {
                                         let response = reqwest::get(path.to_str().unwrap())
                                             .await
                                             .wrap_err_with(|| format!("Failed to get dds image: {}", path.display()))?;
                                        if !response.status().is_success() {
                                            panic!("Failed to fetch dds image, status: {} for glyph atlas: {}", response.status(), path.display());
                                        }
                                         let bytes = response
                                             .bytes()
                                             .await
                                             .wrap_err_with(|| format!("Failed to get dds image bytes: {}", path.display()))?;
                                         ddsfile::Dds::read(Cursor::new(bytes))?
                                     };
                                     
                                     if dds.get_bits_per_pixel() == Some(8) {
                                         let pixels = dds.data.iter().flat_map(|p| [0xff, 0xff, 0xff, *p]).collect::<Vec<u8>>();
                                         image::RgbaImage::from_vec(dds.get_width(), dds.get_height(), pixels).expect("Failed to create image from data")
                                     } else {
                                        panic!("Unsupported DDS format for glyph atlas: {}, bits_per_pixel = {:?}", path.display(), dds.get_bits_per_pixel());
                                     }
                                } else {
                                    panic!("Unsupported image format for glyph atlas, expected valid DDS: {}", path.display());
                                };
                                pages.push(image::DynamicImage::ImageRgba8(page));
                            }
                        }
                    } else {
                        error!("Unexpected start of element: {name}");
                    }
                }
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "Page" {
                        //Good
                    } else if name.local_name.as_str() == "Pages" {
                        return Ok(());
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    fn handle_glyphs<R: Read>(
        parser: &mut EventReader<R>,
        glyphs: &mut AHashMap<char, Glyph>,
        pages: &[DynamicImage],
    ) {
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => match name.local_name.as_str() {
                    "Glyph" => {
                        let mut page = 0;
                        let mut a = 0;
                        let mut b = 0;
                        let mut c = 0;
                        let mut id = 0;
                        let mut top = 0;
                        let mut bottom = 0;
                        let mut left = 0;
                        let mut right = 0;
                        for attribute in attributes {
                            match attribute.name.local_name.as_str() {
                                "ID" => {
                                    id = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'ID' attribute as a u32");
                                }
                                "A" => {
                                    a = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'A' attribute as a i8");
                                }
                                "B" => {
                                    b = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'B' attribute as a i8");
                                }
                                "C" => {
                                    c = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'C' attribute as a i8");
                                }
                                "Page" => {
                                    page = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Page' attribute as a usize");
                                }
                                "Top" => {
                                    top = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Top' attribute as a u32");
                                }
                                "Bottom" => {
                                    bottom = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Bottom' attribute as a u32");
                                }
                                "Left" => {
                                    left = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Left' attribute as a u32");
                                }
                                "Right" => {
                                    right = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Right' attribute as a u32");
                                }
                                _ => {}
                            }
                        }
                        let page_img = &pages[page];
                        let character = page_img.crop_imm(left, top, right - left, bottom - top);
                        let value = unsafe { char::from_u32_unchecked(id) };
                        glyphs.insert(
                            value,
                            Glyph {
                                img: character.into_rgba8(),
                                offsets: (a, b, c),
                                value,
                            },
                        );
                    }
                    _ => {
                        error!("Unexpected start of element: {name}");
                    }
                },
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "Glyph" {
                        //Good
                    } else if name.local_name.as_str() == "Glyphs" {
                        return;
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
    }

    fn handle_kerning_pairs<R: Read>(
        parser: &mut EventReader<R>,
        kernings: &mut AHashMap<(char, char), i8>,
    ) {
        while let Ok(e) = parser.next() {
            match e {
                XmlEvent::StartElement {
                    name, attributes, ..
                } => match name.local_name.as_str() {
                    "KerningPair" => {
                        let mut first = '\0';
                        let mut second = '\0';
                        let mut amount = 0;
                        for attribute in attributes {
                            match attribute.name.local_name.as_str() {
                                "First" => {
                                    first = unsafe {
                                        char::from_u32_unchecked(
                                            attribute.value.parse().expect(
                                                "Failed to parse 'First' attribute as a char",
                                            ),
                                        )
                                    };
                                }
                                "Second" => {
                                    second = unsafe {
                                        char::from_u32_unchecked(
                                            attribute.value.parse().expect(
                                                "Failed to parse 'Second' attribute as a char",
                                            ),
                                        )
                                    };
                                }
                                "Amount" => {
                                    amount = attribute
                                        .value
                                        .parse()
                                        .expect("Failed to parse 'Amount' attribute as a i8");
                                }
                                _ => {}
                            }
                        }
                        kernings.insert((first, second), amount);
                    }
                    _ => {
                        error!("Unexpected start of element: {name}");
                    }
                },
                XmlEvent::EndElement { name, .. } => {
                    if name.local_name.as_str() == "KerningPair" {
                        //Good
                    } else if name.local_name.as_str() == "KerningPairs" {
                        return;
                    } else {
                        error!("Unexpected end of element: {name}");
                    }
                }
                _ => {}
            }
        }
    }

    pub fn generate_text(&self, text: &str) -> RgbaImage {
        if text.is_empty() {
            return image::RgbaImage::new(0, 0);
        }

        let Some(fallback_glyph) = self.fallback_glyph() else {
            debug!("Glyph atlas is empty while rendering text: '{text}'");
            return image::RgbaImage::new(0, 0);
        };

        let mut characters = Vec::with_capacity(text.len());
        for character in text.chars() {
            if let Some(character) = self.glyphs.get(&character) {
                characters.push(character);
            } else {
                debug!(
                    "Missing glyph '{character}' in atlas; using fallback glyph {:?}",
                    fallback_glyph.value
                );
                characters.push(fallback_glyph);
            }
        }

        if characters.is_empty() {
            // this feels like a bug but I have no idea why this happens.
            debug!("No characters found in text: '{text}'");
            return image::RgbaImage::new(0, 0);
        }

        let mut last_character = '\0';
        let mut width = 1i32;
        let mut kernings = Vec::with_capacity(text.len());
        for character in characters.iter() {
            //width += character.img.width() as i32;
            let kerning = if last_character != '\0' {
                if let Some(kerning) = self.kernings.get(&(last_character, character.value)) {
                    *kerning as i32
                } else {
                    0
                }
            } else {
                0
            };
            kernings.push(kerning);
            width += kerning;
            width += character.offsets.0 as i32;
            width += character.offsets.1 as i32 + character.offsets.2 as i32;
            last_character = character.value;
        }

        let width = width as u32 + 1;
        let height = characters
            .iter()
            .map(|c| c.img.height())
            .max()
            .expect("No characters found");
        let mut output = image::DynamicImage::new_rgba8(width, height);
        let mut offset = 1;

        for (character, kerning) in characters.iter().zip(kernings) {
            offset += kerning as i64;
            offset += character.offsets.0 as i64;
            overlay(&mut output, &character.img, offset, 0);
            offset += character.offsets.1 as i64 + character.offsets.2 as i64;
        }

        output.into_rgba8()
    }

    pub fn generate_text_with_color(&self, text: &str, colour: [u8; 4]) -> RgbaImage {
        if text.is_empty() {
            return RgbaImage::new(0, 0);
        }
        let mut text = self.generate_text(text);
        for pixel in text.pixels_mut() {
            // Black
            pixel.0 = [colour[0], colour[1], colour[2], pixel.0[3]];
        }
        text
    }

    pub fn get_glyph(&self, char: char) -> &Glyph {
        if let Some(output) = self.glyphs.get(&char) {
            output
        } else {
            self.fallback_glyph().unwrap_or_else(|| {
                debug!("Glyph atlas is empty while resolving glyph '{char}'");
                Self::empty_glyph()
            })
        }
    }

    pub fn get_glyph_length(&self, char: char, previous_char: char) -> u32 {
        let mut output = 0;
        let glyph = self.get_glyph(char);
        let kerning = self
            .kernings
            .get(&(previous_char, glyph.value))
            .map_or(0, |v| *v);
        output += kerning as i64;
        output += glyph.offsets.0 as i64;
        output += glyph.offsets.1 as i64 + glyph.offsets.2 as i64;
        output as u32
    }
    pub fn get_word_length(&self, string: &str) -> u32 {
        let mut previous_char = '\0';
        let mut output = 0;
        for char in string.chars() {
            output += self.get_glyph_length(char, previous_char);
            previous_char = char;
        }
        output
    }
}

#[derive(Clone)]
pub struct Glyph {
    img: RgbaImage,
    offsets: (i8, i8, i8),
    value: char,
}

#[cfg(test)]
mod tests {
    use super::{Glyph, GlyphAtlas};
    use ahash::AHashMap;
    use image::RgbaImage;

    fn glyph(value: char, width: u32) -> Glyph {
        Glyph {
            img: RgbaImage::new(width, 4),
            offsets: (0, width as i8, 0),
            value,
        }
    }

    #[test]
    fn generate_text_uses_first_available_glyph_when_invalid_glyph_is_missing() {
        let mut glyphs = AHashMap::new();
        glyphs.insert('A', glyph('A', 3));

        let atlas = GlyphAtlas {
            glyphs,
            invalid_glyph: '?',
            kernings: AHashMap::new(),
        };

        let output = atlas.generate_text("AZ");

        assert_eq!(output.height(), 4);
        assert!(output.width() > 0);
        assert_eq!(atlas.get_glyph('Z').value, 'A');
    }

    #[test]
    fn empty_glyph_atlas_returns_empty_output_instead_of_panicking() {
        let atlas = GlyphAtlas {
            glyphs: AHashMap::new(),
            invalid_glyph: '?',
            kernings: AHashMap::new(),
        };

        let output = atlas.generate_text("AZ");

        assert_eq!(output.width(), 0);
        assert_eq!(output.height(), 0);
        assert_eq!(atlas.get_glyph('Z').value, '\0');
        assert_eq!(atlas.get_word_length("AZ"), 0);
    }
}
