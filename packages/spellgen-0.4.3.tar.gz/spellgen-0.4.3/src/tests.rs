use compact_str::ToCompactString;

use crate::{AccuracyPosition, CardFactory, CardGenerator, SchoolPips, SpellCard, SpellCost, SpellFactorySettings};


fn test_spell_factory() -> eyre::Result<CardFactory> {
    let settings = SpellFactorySettings {
        assets_path: "assets".into(),
        glyph_defs_path: "glyph_defs/SpellDescription.xml".into(),
        spell_title_font_path: "glyph_defs/SpellTitle_sm.xml".into(),
        spell_description_font_path: "glyph_defs/SpellDescription.xml".into(),
        shadow_school_pip_path: "school_pip_icons/pip_shadow_large.png".into(),
        balance_school_pip_path: "school_pip_icons/pip_balance_no_glow.png".into(),
        death_school_pip_path: "school_pip_icons/pip_death_no_glow.png".into(),
        fire_school_pip_path: "school_pip_icons/pip_fire_no_glow.png".into(),
        ice_school_pip_path: "school_pip_icons/pip_ice_no_glow.png".into(),
        life_school_pip_path: "school_pip_icons/pip_life_no_glow.png".into(),
        myth_school_pip_path: "school_pip_icons/pip_myth_no_glow.png".into(),
        storm_school_pip_path: "school_pip_icons/pip_storm_no_glow.png".into(),
        rank_number_icons: [
            "rank_icons/Rank_00.tga".into(),
            "rank_icons/Rank_01.tga".into(),
            "rank_icons/Rank_02.tga".into(),
            "rank_icons/Rank_03.tga".into(),
            "rank_icons/Rank_04.tga".into(),
            "rank_icons/Rank_05.tga".into(),
            "rank_icons/Rank_06.tga".into(),
            "rank_icons/Rank_07.tga".into(),
            "rank_icons/Rank_08.tga".into(),
            "rank_icons/Rank_09.tga".into(),
            "rank_icons/Rank_10.tga".into(),
            "rank_icons/Rank_11.tga".into(),
            "rank_icons/Rank_12.tga".into(),
            "rank_icons/Rank_13.tga".into(),
            "rank_icons/Rank_14.tga".into(),
            "rank_icons/Rank_15.tga".into(),
            "rank_icons/Rank_16.tga".into(),
            "rank_icons/Rank_17.tga".into(),
            "rank_icons/Rank_18.tga".into(),
            "rank_icons/Rank_19.tga".into(),
            "rank_icons/Rank_20.tga".into(),
        ],
        rank_minus_icon: "rank_icons/Rank_Minus.tga".into(),
        rank_plus_icon: "rank_icons/Rank_Plus.tga".into(),
        rank_x_icon: "rank_icons/Rank_X.tga".into(),
        cloak_icon: "Type_Cloak.dds".into(),
        cloak_frame_icon: "Type_Frame.dds".into(),
        pvp_only_icon: "Icon_Flag_PVPOnly.dds".into(),
        pve_only_icon: "Type_Card_PVE.dds".into(),
        banned_icon: "Type_Card_Banned.dds".into(),
        single_use_icon: "Type_x1_PvP.dds".into(),
        cannot_discard_icon: "Art_Lock.dds".into(),
        essence_collection_icon: "Button_Monster_Magic.dds".into(),
        pierce_icon: "Icon_Armor_Penetration.dds".into(),
        pierce_frame_icon: "Art_Red01.dds".into(),
        level_requirement_icon: "Type_LevelReqPvP.dds".into(),
        default_icon_size: (16, 16),
        default_wide_icon_size: (40, 20),
        cache_madlibs: true
    };
    CardFactory::new(settings)
}
#[test]
fn test() -> Result<(), Box<dyn std::error::Error>> {
    let factory = test_spell_factory()?;
    let mut card = SpellCard {
        title: "Benjamin Time".into(),
        title_size: crate::TitleSize::Default,
        description: "615 $i:Icon_Ice.dds$$i:Type_Damage.dds$:$i:Type_Damage.dds$, then\\n5x $c:FF37005B$Clear$c$ $i:Type_Charm.dds$ :\\n+35% $i:Icon_Myth.dds$$i:Type_Trap.dds$".into(),
        description_alignment: crate::textbox::TextAlignment::Left,
        frame: Some("frames/School_Gardening_Blnk.dds".into()),
        cost: Some(SpellCost {
            variable_cost: true,
            base_cost: 20,
            school_pips: SchoolPips {
                shadow: 1,
                fire: 1,
                ice: 1,
                storm: 0,
                myth: 0,
                life: 0,
                death: 0,
                balance: 0,
            }
        }),
        school_icon: Some("school_icons/Icon_Fire.png".into()),
        spell_image: Some("spell_icons/Spell_Death_Firebane.dds".into()),
        spell_image_size: crate::SpellImageSize::Default,
        additional_spell_images_lower: None,
        additional_spell_images_upper: Some(vec!["Golem_A_MOB.dds".into(), "Art_Not.dds".into()]),
        type_icon: Some("type_icons/Type_Damage.png".into()),
        accuracy: "15".into(), //"69%".to_compact_string(),
        accuracy_position: AccuracyPosition::Alternative,
        accuracy_bolding: false,
        accuracy_colour: Some([0, 0, 0, 255]),
        booster_pack: Some("booster_packs/Booster_Eye_of_Bartleby.dds".into()),
        cloaked: false,
        no_pvp: false,
        no_pve: false,
        pierce: 100,
        level_requirement: 69,
        cannot_discard: false,
        essence_collection: false,
        single_use: false,
        legacy_madlib_sizes: false,
    };

    let img = factory.generate(&card)?;
    img.save("tests/test1.webp")?;

    let generated = std::fs::read("tests/test1.webp")?;
    let other = std::fs::read("tests/expected_test1.webp")?;
    assert_eq!(generated, other);

    Ok(())
}

#[test]
fn test2() -> Result<(), Box<dyn std::error::Error>> {
    let factory = test_spell_factory()?;
    let mut card = SpellCard {
        title: "Benjamin Time".into(),
        title_size: crate::TitleSize::Default,
        description: " 150 $i:school_icons/Icon_Star.dds$$i:Type_Damage.dds$ per $i:Type_Pip.dds$ over 3 $i:Icons_Rounds.dds$".into(),
        description_alignment: crate::textbox::TextAlignment::Center,
        frame: Some("frames/School_Gardening_Blnk.dds".into()),
        cost: Some(SpellCost {
            variable_cost: true,
            base_cost: 20,
            school_pips: SchoolPips {
                shadow: 1,
                fire: 1,
                ice: 1,
                storm: 0,
                myth: 0,
                life: 0,
                death: 0,
                balance: 0,
            }
        }),
        school_icon: Some("school_icons/Icon_Fire.png".into()),
        spell_image: Some("spell_icons/Spell_Death_Firebane.dds".into()),
        spell_image_size: crate::SpellImageSize::Default,
        additional_spell_images_lower: None,
        additional_spell_images_upper: Some(vec!["Golem_A_MOB.dds".into(), "Art_Not.dds".into()]),
        type_icon: Some("type_icons/Type_Damage.png".into()),
        accuracy: "15".into(), //"69%".to_compact_string(),
        accuracy_position: AccuracyPosition::Alternative,
        accuracy_bolding: false,
        accuracy_colour: Some([0, 0, 0, 255]),
        booster_pack: Some("booster_packs/Booster_Eye_of_Bartleby.dds".into()),
        cloaked: false,
        no_pvp: false,
        no_pve: false,
        pierce: 100,
        level_requirement: 69,
        cannot_discard: false,
        essence_collection: false,
        single_use: false,
        legacy_madlib_sizes: true,
    };

    let img = factory.generate(&card)?;
    img.save("tests/test2.webp")?;

    let generated = std::fs::read("tests/test2.webp")?;
    let other = std::fs::read("tests/expected_test2.webp")?;
    assert_eq!(generated, other);

    Ok(())
}

#[test]
fn test3() -> Result<(), Box<dyn std::error::Error>> {
    let factory = test_spell_factory()?;
    let mut card = SpellCard {
        title: "Benjamin Time".into(),
        title_size: crate::TitleSize::Default,
        description: "570 $i:Type_Damage.dds$$i:Type_Damage.dds$ and\\n+2$i:school_pip_icons/pip_balance_no_glow.png$\\nif $i:Icons_All_Enemies.dds$&$i:Icon_Self.dds$ have $i:Type_AuraNegative.dds$".into(),
        description_alignment: crate::textbox::TextAlignment::Center,
        frame: Some("frames/School_Gardening_Blnk.dds".into()),
        cost: Some(SpellCost {
            variable_cost: true,
            base_cost: 20,
            school_pips: SchoolPips {
                shadow: 1,
                fire: 1,
                ice: 1,
                storm: 0,
                myth: 0,
                life: 0,
                death: 0,
                balance: 0,
            }
        }),
        school_icon: Some("school_icons/Icon_Fire.png".into()),
        spell_image: Some("spell_icons/Spell_Death_Firebane.dds".into()),
        spell_image_size: crate::SpellImageSize::Default,
        additional_spell_images_lower: None,
        additional_spell_images_upper: Some(vec!["Golem_A_MOB.dds".into(), "Art_Not.dds".into()]),
        type_icon: Some("type_icons/Type_Damage.png".into()),
        accuracy: "15".into(), //"69%".to_compact_string(),
        accuracy_position: AccuracyPosition::Alternative,
        accuracy_bolding: false,
        accuracy_colour: Some([0, 0, 0, 255]),
        booster_pack: Some("booster_packs/Booster_Eye_of_Bartleby.dds".into()),
        cloaked: false,
        no_pvp: false,
        no_pve: false,
        pierce: 100,
        level_requirement: 69,
        cannot_discard: false,
        essence_collection: false,
        single_use: false,
        legacy_madlib_sizes: false,
    };

    let img = factory.generate(&card)?;
    img.save("tests/test3.webp")?;

    Ok(())
}

#[test]
fn test4() -> Result<(), Box<dyn std::error::Error>> {
    let factory = test_spell_factory()?;
    let mut card = SpellCard {
        title: "Benjamin Time".into(),
        title_size: crate::TitleSize::Default,
        description: "570 $i:Type_Damage.dds$$i:Type_Damage.dds$ and\\n+2$i:school_pip_icons/pip_balance_no_glow.png$\\nif $i:Icons_All_Enemies.dds$&$i:Icon_Self.dds$ have $i:Type_AuraNegative.dds$".into(),
        description_alignment: crate::textbox::TextAlignment::Center,
        frame: Some("frames/School_PetSnack_Blnk.dds".into()),
        cost: Some(SpellCost {
            variable_cost: false,
            base_cost: 9,
            school_pips: SchoolPips {
                shadow: 0,
                fire: 0,
                ice: 0,
                storm: 0,
                myth: 0,
                life: 0,
                death: 0,
                balance: 0,
            }
        }),
        school_icon: Some("school_icons/Icon_Ice.png".into()),
        spell_image: Some("spell_icons/PetSnacks_2_FancyYogurt.dds.webp".into()),
        spell_image_size: crate::SpellImageSize::Snack,
        additional_spell_images_lower: None,
        additional_spell_images_upper: None,
        type_icon: None,
        accuracy: "".into(), //"69%".to_compact_string(),
        accuracy_position: AccuracyPosition::Alternative,
        accuracy_bolding: false,
        accuracy_colour: Some([0, 0, 0, 255]),
        booster_pack: None,
        cloaked: false,
        no_pvp: false,
        no_pve: false,
        pierce: 0,
        level_requirement: 0,
        cannot_discard: false,
        essence_collection: false,
        single_use: false,
        legacy_madlib_sizes: true,
    };

    let img = factory.generate(&card)?;
    img.save("tests/test4.webp")?;

    Ok(())
}