use std::{array, io::Cursor, path::{Path, PathBuf}};

use compact_str::{CompactString, ToCompactString};
use image::RgbaImage;
use pyo3::{pyclass, pymethods, types::{PyAnyMethods, PyModule, PyModuleMethods, PyString, PyStringMethods}, Bound, FromPyObject, PyResult};

use crate::{textbox::TextAlignment, CardFactory, CardGenerator, SchoolPips, SpellCard, SpellCost, SpellFactorySettings};


#[pyo3::pymodule]
pub fn spellgen(m: &Bound<'_, PyModule>) -> PyResult<()> {
    let _ = pyo3_log::try_init();
    
    m.add_class::<PySpellFactorySettings>()?;
    m.add_class::<PySpellCard>()?;
    m.add_class::<PyCardFactory>()?;
    m.add_class::<PyCardImage>()?;
    m.add_class::<PySpellCost>()?;
    m.add_class::<PyTextAlignment>()?;
    Ok(())
}

#[pyclass(name = "SpellCard")]
#[derive(Clone)]
pub struct PySpellCard(SpellCard);

#[pymethods]
impl PySpellCard {
    #[new]
    #[pyo3(signature = (title = "",
    title_size = "base",
    description = "",
    description_alignment = PyTextAlignment::center(),
    frame = None,
    spell_image = None,
    spell_image_size = "base",
    additional_spell_images_lower = None,
    additional_spell_images_upper = None,
    cost = None, //PySpellCost(SpellCost::default()),
    school_icon = None,
    type_icon = None,
    accuracy = "0%",
    accuracy_colour = None,
    accuracy_position = "base",
    accuracy_bolding = false,
    booster_pack = None,
    cloaked = false,
    no_pvp = false,
    no_pve = false,
    pierce = 0,
    level_requirement = 0,
    cannot_discard = false,
    essence_collection = false,
    single_use = false,
    legacy_madlib_sizes = false))]
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        title: &str,
        title_size: &str,
        description: &str,
        description_alignment: PyTextAlignment,
        frame: Option<PathBuf>,
        spell_image: Option<PathBuf>,
        spell_image_size: &str,
        additional_spell_images_lower: Option<Vec<PathBuf>>,
        additional_spell_images_upper: Option<Vec<PathBuf>>,
        cost: Option<PySpellCost>,
        school_icon: Option<PathBuf>,
        type_icon: Option<PathBuf>,
        accuracy: Option<&str>,
        accuracy_colour: Option<(u8, u8, u8, u8)>,
        accuracy_position: &str,
        accuracy_bolding: bool,
        booster_pack: Option<PathBuf>,
        cloaked: bool,
        no_pvp: bool,
        no_pve: bool,
        pierce: i16,
        level_requirement: u16,
        cannot_discard: bool,
        essence_collection: bool,
        single_use: bool,
        legacy_madlib_sizes: bool
    ) -> PyResult<Self> {
        let card = SpellCard {
            title: title.into(),
            title_size: match title_size.to_lowercase().as_str() {
                "base" => crate::TitleSize::Default,
                "alt" => crate::TitleSize::Alt,
                _ => crate::TitleSize::Default,
            },
            description: description.into(),
            description_alignment: description_alignment.0,
            frame,
            spell_image,
            spell_image_size: match spell_image_size.to_lowercase().as_str() {
                "base" => crate::SpellImageSize::Default,
                "alt" => crate::SpellImageSize::Alt,
                "snack" => crate::SpellImageSize::Snack,
                _ => crate::SpellImageSize::Default,
            },
            additional_spell_images_lower,
            additional_spell_images_upper,
            cost: cost.map(|e| Some(e.0)).unwrap_or(None),
            school_icon,
            type_icon,
            accuracy: if let Some(v) = accuracy { v.to_compact_string() } else { CompactString::const_new("") },
            accuracy_colour: accuracy_colour.map(|c| [c.0, c.1, c.2, c.3]),
            accuracy_position: match accuracy_position.to_lowercase().as_str() {
                "base" | "default" => crate::AccuracyPosition::Base,
                "alt" | "alternative" => crate::AccuracyPosition::Alternative,
                _ => crate::AccuracyPosition::Base,
            },
            accuracy_bolding,
            booster_pack,
            cloaked,
            no_pvp,
            no_pve,
            pierce,
            level_requirement,
            cannot_discard,
            essence_collection,
            single_use,
            legacy_madlib_sizes,
        };
        Ok(PySpellCard(card))
    }

    #[setter]
    pub fn set_title(&mut self, title: String) {
        self.0.title = title;
    }

    #[getter]
    pub fn get_title(&self) -> &str {
        &self.0.title
    }

    #[setter]
    pub fn set_title_size(&mut self, title_size: &str) {
        self.0.title_size = match title_size.to_lowercase().as_str() {
            "base" => crate::TitleSize::Default,
            "alt" => crate::TitleSize::Alt,
            _ => crate::TitleSize::Default,
        };
    }

    #[getter]
    pub fn get_title_size(&self) -> &str {
        match self.0.title_size {
            crate::TitleSize::Default => "base",
            crate::TitleSize::Alt => "alt",
        }
    }

    #[setter]
    pub fn set_description(&mut self, description: String) {
        self.0.description = description;
    }

    #[getter]
    pub fn get_description(&self) -> &str {
        &self.0.description
    }

    #[setter]
    pub fn set_frame(&mut self, frame: Option<PathBuf>) {
        self.0.frame = frame;
    }

    #[getter]
    pub fn get_frame(&self) -> Option<&Path> {
        self.0.frame.as_deref()
    }

    #[setter]
    pub fn set_spell_image(&mut self, spell_image: Option<PathBuf>) {
        self.0.spell_image = spell_image;
    }

    #[getter]
    pub fn get_spell_image(&self) -> Option<&Path> {
        self.0.spell_image.as_deref()
    }

    #[setter]
    pub fn set_spell_image_size(&mut self, spell_image_size: &str) {
        self.0.spell_image_size = match spell_image_size.to_lowercase().as_str() {
            "base" => crate::SpellImageSize::Default,
            "alt" => crate::SpellImageSize::Alt,
            "snack" => crate::SpellImageSize::Snack,
            _ => crate::SpellImageSize::Default,
        };
    }

    #[getter]
    pub fn get_spell_image_size(&self) -> &str {
        match self.0.spell_image_size {
            crate::SpellImageSize::Default => "base",
            crate::SpellImageSize::Alt => "alt",
            crate::SpellImageSize::Snack => "snack",
        }
    }

    #[setter]
    pub fn set_cost(&mut self, cost: Option<PySpellCost>) {
        self.0.cost = cost.map(|e| Some(e.0)).unwrap_or(None);
    }

    #[getter]
    pub fn get_cost(&self) -> Option<PySpellCost> {
        self.0.cost.map(PySpellCost)
    }

    #[setter]
    pub fn set_school_icon(&mut self, school_icon: Option<PathBuf>) {
        self.0.school_icon = school_icon;
    }

    #[getter]
    pub fn get_school_icon(&self) -> Option<&Path> {
        self.0.school_icon.as_deref()
    }

    #[setter]
    pub fn set_type_icon(&mut self, type_icon: Option<PathBuf>) {
        self.0.type_icon = type_icon;
    }

    #[getter]
    pub fn get_type_icon(&self) -> Option<&Path> {
        self.0.type_icon.as_deref()
    }

    #[setter]
    pub fn set_accuracy(&mut self, accuracy: Option<&str>) {
        if let Some(v) = accuracy {
            self.0.accuracy = v.to_compact_string();
        } else {
            self.0.accuracy = CompactString::const_new("");
        }
    }

    #[getter]
    pub fn get_accuracy(&self) -> Option<&str> {
        if self.0.accuracy.is_empty() {
            None
        } else {
            Some(&self.0.accuracy)
        }
    }

    #[setter]
    pub fn set_accuracy_colour(&mut self, accuracy_colour: Option<(u8, u8, u8, u8)>) {
        self.0.accuracy_colour = accuracy_colour.map(|c| [c.0, c.1, c.2, c.3]);
    }

    #[getter]
    pub fn get_accuracy_colour(&self) -> Option<(u8, u8, u8, u8)> {
        self.0.accuracy_colour.map(|c| (c[0], c[1], c[2], c[3]))
    }

    #[setter]
    pub fn set_accuracy_position(&mut self, accuracy_position: &str) {
        self.0.accuracy_position = match accuracy_position.to_lowercase().as_str() {
            "base" | "default" | "normal" => crate::AccuracyPosition::Base,
            "alt" | "alternative" | "other" => crate::AccuracyPosition::Alternative,
            _ => crate::AccuracyPosition::Base,
        };
    }

    #[getter]
    pub fn get_accuracy_position(&self) -> &str {
        match self.0.accuracy_position {
            crate::AccuracyPosition::Base => "base",
            crate::AccuracyPosition::Alternative => "alt",
        }
    }

    #[getter]
    pub fn get_accuracy_bolding(&self) -> bool {
        self.0.accuracy_bolding
    }

    #[setter]
    pub fn set_accuracy_bolding(&mut self, accuracy_bolding: bool) {
        self.0.accuracy_bolding = accuracy_bolding;
    }

    #[setter]
    pub fn set_booster_pack(&mut self, booster_pack: Option<PathBuf>) {
        self.0.booster_pack = booster_pack;
    }

    #[getter]
    pub fn get_booster_pack(&self) -> Option<&Path> {
        self.0.booster_pack.as_deref()
    }

    #[setter]
    pub fn set_cloaked(&mut self, cloaked: bool) {
        self.0.cloaked = cloaked;
    }

    #[getter]
    pub fn get_cloaked(&self) -> bool {
        self.0.cloaked
    }

    #[setter]
    pub fn set_no_pvp(&mut self, no_pvp: bool) {
        self.0.no_pvp = no_pvp;
    }

    #[getter]
    pub fn get_no_pvp(&self) -> bool {
        self.0.no_pvp
    }

    #[setter]
    pub fn set_no_pve(&mut self, no_pve: bool) {
        self.0.no_pve = no_pve;
    }

    #[getter]
    pub fn get_no_pve(&self) -> bool {
        self.0.no_pve
    }

    #[setter]
    pub fn set_pierce(&mut self, pierce: i16) {
        self.0.pierce = pierce;
    }

    #[getter]
    pub fn get_pierce(&self) -> i16 {
        self.0.pierce
    }

    #[setter]
    pub fn set_level_requirement(&mut self, level_requirement: u16) {
        self.0.level_requirement = level_requirement;
    }

    #[getter]
    pub fn get_level_requirement(&self) -> u16 {
        self.0.level_requirement
    }

    #[setter]
    pub fn set_cannot_discard(&mut self, cannot_discard: bool) {
        self.0.cannot_discard = cannot_discard;
    }

    #[getter]
    pub fn get_cannot_discard(&self) -> bool {
        self.0.cannot_discard
    }

    #[setter]
    pub fn set_essence_collection(&mut self, essence_collection: bool) {
        self.0.essence_collection = essence_collection;
    }

    #[getter]
    pub fn get_essence_collection(&self) -> bool {
        self.0.essence_collection
    }

    #[setter]
    pub fn set_single_use(&mut self, single_use: bool) {
        self.0.single_use = single_use;
    }

    #[getter]
    pub fn get_single_use(&self) -> bool {
        self.0.single_use
    }

    #[setter]
    pub fn set_description_alignment(&mut self, value: PyTextAlignment) {
        self.0.description_alignment = value.0;
    }

    #[getter]
    pub fn get_description_alignment(&self) -> PyTextAlignment {
        PyTextAlignment(self.0.description_alignment)
    }

    #[setter]
    pub fn set_legacy_madlib_sizes(&mut self, legacy_madlib_sizes: bool) {
        self.0.legacy_madlib_sizes = legacy_madlib_sizes;
    }

    #[getter]
    pub fn get_legacy_madlib_sizes(&self) -> bool {
        self.0.legacy_madlib_sizes
    }
}

#[pyclass(name = "CardFactory")]
#[derive(Clone)]
pub struct PyCardFactory(CardFactory);

#[pymethods]
impl PyCardFactory {
    #[new]
    pub fn new(
        settings: PySpellFactorySettings
    ) -> PyResult<Self> {
        let factory = CardFactory::new(settings.0)?;
        Ok(PyCardFactory(factory))
    }

    pub fn generate(&self, card: PySpellCard) -> PyResult<PyCardImage> {
        let img = self.0.generate(&card.0)?;
        Ok(PyCardImage(img))
    }
}

#[pyclass(name = "CardImage")]
#[derive(Clone)]
pub struct PyCardImage(RgbaImage);

#[pymethods]
impl PyCardImage {
    pub fn save(&self, path: &str) -> PyResult<()> {
        self.0.save(path).map_err(|e| pyo3::exceptions::PyIOError::new_err(e.to_string()))?;
        Ok(())
    }
    
    pub fn to_memory(&self) -> PyResult<Vec<u8>> {
        let mut output = Cursor::new(Vec::with_capacity(51200));
        self.0.write_to(&mut output, image::ImageFormat::WebP).map_err(|e| pyo3::exceptions::PyIOError::new_err(e.to_string()))?;
        Ok(output.into_inner())
    }
}

#[pyclass(name = "CardFactorySettings")]
#[derive(Clone)]
pub struct PySpellFactorySettings(SpellFactorySettings);

#[pymethods]
impl PySpellFactorySettings {
    #[new]
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (assets_path = "", 
        glyph_defs_path = "", 
        spell_title_font_path = "", 
        spell_description_font_path = "",
        shadow_school_pip_path = "",
        balance_school_pip_path = "",
        death_school_pip_path = "",
        fire_school_pip_path = "",
        ice_school_pip_path = "",
        life_school_pip_path = "",
        myth_school_pip_path = "",
        storm_school_pip_path = "",
        rank_number_icons = [].to_vec(),
        rank_minus_icon = "",
        rank_plus_icon = "",
        rank_x_icon = "",
        cloak_icon = "",
        cloak_frame_icon = "",
        pvp_only_icon = "",
        pve_only_icon = "",
        banned_icon = "",
        single_use_icon = "",
        cannot_discard_icon = "",
        essence_collection_icon = "",
        pierce_icon = "",
        pierce_frame_icon = "",
        level_requirement_icon = "",
        default_icon_size = (16, 16),
        default_wide_icon_size = (32, 16), //Guess
        cache_madlibs = true))]
    pub fn new(assets_path: &str, 
        glyph_defs_path: &str, 
        spell_title_font_path: &str, 
        spell_description_font_path: &str,
        shadow_school_pip_path: &str,
        balance_school_pip_path: &str,
        death_school_pip_path: &str,
        fire_school_pip_path: &str,
        ice_school_pip_path: &str,
        life_school_pip_path: &str,
        myth_school_pip_path: &str,
        storm_school_pip_path: &str,
        mut rank_number_icons: Vec<PathBuf>,
        rank_minus_icon: &str,
        rank_plus_icon: &str,
        rank_x_icon: &str,
        cloak_icon: &str,
        cloak_frame_icon: &str,
        pvp_only_icon: &str,
        pve_only_icon: &str,
        banned_icon: &str,
        single_use_icon: &str,
        cannot_discard_icon: &str,
        essence_collection_icon: &str,
        pierce_icon: &str,
        pierce_frame_icon: &str,
        level_requirement_icon: &str,
        default_icon_size: (u32, u32),
        default_wide_icon_size: (u32, u32),
        cache_madlibs: bool
    ) -> PySpellFactorySettings {
        PySpellFactorySettings(
            SpellFactorySettings {
                assets_path: assets_path.into(),
                glyph_defs_path: glyph_defs_path.into(), 
                spell_title_font_path: spell_title_font_path.into(), 
                spell_description_font_path: spell_description_font_path.into(),
                shadow_school_pip_path: shadow_school_pip_path.into(),
                balance_school_pip_path: balance_school_pip_path.into(),
                death_school_pip_path: death_school_pip_path.into(),
                fire_school_pip_path: fire_school_pip_path.into(),
                ice_school_pip_path: ice_school_pip_path.into(),
                life_school_pip_path: life_school_pip_path.into(),
                myth_school_pip_path: myth_school_pip_path.into(),
                storm_school_pip_path: storm_school_pip_path.into(),
                rank_number_icons: {
                    if rank_number_icons.len() >= 21 {
                        let mut v = rank_number_icons.drain(..21);
                        array::from_fn(|_| v.next().unwrap())
                    } else {
                        array::from_fn(|_| PathBuf::new())
                    }
                },
                rank_minus_icon: rank_minus_icon.into(),
                rank_plus_icon: rank_plus_icon.into(),
                rank_x_icon: rank_x_icon.into(),
                cloak_icon: cloak_icon.into(),
                cloak_frame_icon: cloak_frame_icon.into(),
                pvp_only_icon: pvp_only_icon.into(),
                pve_only_icon: pve_only_icon.into(),
                banned_icon: banned_icon.into(),
                single_use_icon: single_use_icon.into(),
                cannot_discard_icon: cannot_discard_icon.into(),
                essence_collection_icon: essence_collection_icon.into(),
                pierce_icon: pierce_icon.into(),
                pierce_frame_icon: pierce_frame_icon.into(),
                level_requirement_icon: level_requirement_icon.into(),
                default_icon_size,
                default_wide_icon_size,
                cache_madlibs
            }
        )
    }

    #[getter]
    pub fn get_assets_path(&self) -> &Path {
        &self.0.assets_path
    }

    #[setter]
    pub fn set_assets_path(&mut self, value: PathBuf) {
        self.0.assets_path = value;
    }
    
    #[getter]
    pub fn get_glyph_defs_path(&self) -> &Path {
        &self.0.glyph_defs_path
    }

    #[setter]
    pub fn set_glyph_defs_path(&mut self, value: PathBuf) {
        self.0.glyph_defs_path = value;
    }

    #[getter]
    pub fn get_spell_title_font_path(&self) -> &Path {
        &self.0.spell_title_font_path
    }

    #[setter]
    pub fn set_spell_title_font_path(&mut self, value: PathBuf) {
        self.0.spell_title_font_path = value;
    }

    #[getter]
    pub fn get_spell_description_font_path(&self) -> &Path {
        &self.0.spell_description_font_path
    }

    #[setter]
    pub fn set_spell_description_font_path(&mut self, value: PathBuf) {
        self.0.spell_description_font_path = value;
    }

    #[getter]
    pub fn get_shadow_school_pip_path(&self) -> &Path {
        &self.0.shadow_school_pip_path
    }

    #[setter]
    pub fn set_shadow_school_pip_path(&mut self, value: PathBuf) {
        self.0.shadow_school_pip_path = value;
    }

    #[getter]
    pub fn get_balance_school_pip_path(&self) -> &Path {
        &self.0.balance_school_pip_path
    }

    #[setter]
    pub fn set_balance_school_pip_path(&mut self, value: PathBuf) {
        self.0.balance_school_pip_path = value;
    }

    #[getter]
    pub fn get_death_school_pip_path(&self) -> &Path {
        &self.0.death_school_pip_path
    }

    #[setter]
    pub fn set_death_school_pip_path(&mut self, value: PathBuf) {
        self.0.death_school_pip_path = value;
    }

    #[getter]
    pub fn get_fire_school_pip_path(&self) -> &Path {
        &self.0.fire_school_pip_path
    }

    #[setter]
    pub fn set_fire_school_pip_path(&mut self, value: PathBuf) {
        self.0.fire_school_pip_path = value;
    }

    #[getter]
    pub fn get_ice_school_pip_path(&self) -> &Path {
        &self.0.ice_school_pip_path
    }

    #[setter]
    pub fn set_ice_school_pip_path(&mut self, value: PathBuf) {
        self.0.ice_school_pip_path = value;
    }

    #[getter]
    pub fn get_life_school_pip_path(&self) -> &Path {
        &self.0.life_school_pip_path
    }

    #[setter]
    pub fn set_life_school_pip_path(&mut self, value: PathBuf) {
        self.0.life_school_pip_path = value;
    }

     #[getter]
    pub fn get_myth_school_pip_path(&self) -> &Path {
        &self.0.myth_school_pip_path
    }

    #[setter]
    pub fn set_myth_school_pip_path(&mut self, value: PathBuf) {
        self.0.myth_school_pip_path = value;
    }

    #[getter]
    pub fn get_storm_school_pip_path(&self) -> &Path {
        &self.0.storm_school_pip_path
    }

    #[setter]
    pub fn set_storm_school_pip_path(&mut self, value: PathBuf) {
        self.0.storm_school_pip_path = value;
    }

    #[getter]
    pub fn get_rank_number_icons(&self) -> &[PathBuf; 21] {
        &self.0.rank_number_icons
    }

    #[setter]
    pub fn set_rank_number_icons(&mut self, value: Vec<PathBuf>) -> PyResult<()> {
        if value.len() == 21 {
             // This requires `TryInto` or manual copying if `value` needs to stay owned
             match value.try_into() {
                Ok(arr) => {
                    self.0.rank_number_icons = arr;
                    Ok(())
                }
                Err(_) => Err(pyo3::exceptions::PyValueError::new_err("Conversion to array failed internally")) // Should not happen if len == 21
             }
        } else {
            Err(pyo3::exceptions::PyValueError::new_err(format!("Expected 21 rank number icons, got {}", value.len())))
        }
    }

    #[getter]
    pub fn get_rank_minus_icon(&self) -> &Path {
        &self.0.rank_minus_icon
    }

    #[setter]
    pub fn set_rank_minus_icon(&mut self, value: PathBuf) {
        self.0.rank_minus_icon = value;
    }

    #[getter]
    pub fn get_rank_plus_icon(&self) -> &Path {
        &self.0.rank_plus_icon
    }

    #[setter]
    pub fn set_rank_plus_icon(&mut self, value: PathBuf) {
        self.0.rank_plus_icon = value;
    }

    #[getter]
    pub fn get_rank_x_icon(&self) -> &Path {
        &self.0.rank_x_icon
    }

    #[setter]
    pub fn set_rank_x_icon(&mut self, value: PathBuf) {
        self.0.rank_x_icon = value;
    }

    #[getter]
    pub fn get_cloak_icon(&self) -> &Path {
        &self.0.cloak_icon
    }

    #[setter]
    pub fn set_cloak_icon(&mut self, value: PathBuf) {
        self.0.cloak_icon = value;
    }

    #[getter]
    pub fn get_cloak_frame_icon(&self) -> &Path {
        &self.0.cloak_frame_icon
    }

    #[setter]
    pub fn set_cloak_frame_icon(&mut self, value: PathBuf) {
        self.0.cloak_frame_icon = value;
    }

    #[getter]
    pub fn get_pvp_only_icon(&self) -> &Path {
        &self.0.pvp_only_icon
    }

    #[setter]
    pub fn set_pvp_only_icon(&mut self, value: PathBuf) {
        self.0.pvp_only_icon = value;
    }

     #[getter]
    pub fn get_pve_only_icon(&self) -> &Path {
        &self.0.pve_only_icon
    }

    #[setter]
    pub fn set_pve_only_icon(&mut self, value: PathBuf) {
        self.0.pve_only_icon = value;
    }

     #[getter]
    pub fn get_banned_icon(&self) -> &Path {
        &self.0.banned_icon
    }

    #[setter]
    pub fn set_banned_icon(&mut self, value: PathBuf) {
        self.0.banned_icon = value;
    }

    #[getter]
    pub fn get_single_use_icon(&self) -> &Path {
        &self.0.single_use_icon
    }

    #[setter]
    pub fn set_single_use_icon(&mut self, value: PathBuf) {
        self.0.single_use_icon = value;
    }

    #[getter]
    pub fn get_cannot_discard_icon(&self) -> &Path {
        &self.0.cannot_discard_icon
    }

    #[setter]
    pub fn set_cannot_discard_icon(&mut self, value: PathBuf) {
        self.0.cannot_discard_icon = value;
    }

    #[getter]
    pub fn get_essence_collection_icon(&self) -> &Path {
        &self.0.essence_collection_icon
    }

    #[setter]
    pub fn set_essence_collection_icon(&mut self, value: PathBuf) {
        self.0.essence_collection_icon = value;
    }

    #[getter]
    pub fn get_pierce_icon(&self) -> &Path {
        &self.0.pierce_icon
    }

    #[setter]
    pub fn set_pierce_icon(&mut self, value: PathBuf) {
        self.0.pierce_icon = value;
    }

    #[getter]
    pub fn get_pierce_frame_icon(&self) -> &Path {
        &self.0.pierce_frame_icon
    }

    #[setter]
    pub fn set_pierce_frame_icon(&mut self, value: PathBuf) {
        self.0.pierce_frame_icon = value;
    }

    #[getter]
    pub fn get_level_requirement_icon(&self) -> &Path {
        &self.0.level_requirement_icon
    }

    #[setter]
    pub fn set_level_requirement_icon(&mut self, value: PathBuf) {
        self.0.level_requirement_icon = value;
    }

    #[getter]
    pub fn get_default_icon_size(&self) -> (u32, u32) {
        self.0.default_icon_size
    }

    #[setter]
    pub fn set_default_icon_size(&mut self, value: (u32, u32)) {
        self.0.default_icon_size = value;
    }

    #[getter]
    pub fn get_default_wide_icon_size(&self) -> (u32, u32) {
        self.0.default_wide_icon_size
    }

    #[setter]
    pub fn set_default_wide_icon_size(&mut self, value: (u32, u32)) {
        self.0.default_wide_icon_size = value;
    }

    #[getter]
    pub fn get_cache_madlibs(&self) -> bool {
        self.0.cache_madlibs
    }

    #[setter]
    pub fn set_cache_madlibs(&mut self, value: bool) {
        self.0.cache_madlibs = value;
    }
}

#[pyclass(name = "SpellCost")]
#[derive(Copy, Clone)]
pub struct PySpellCost(SpellCost);

#[pymethods]
impl PySpellCost {
    #[new]
    #[pyo3(signature = (base_cost = 0, variable_cost = false, shadow = 0, balance = 0, death = 0, fire = 0, ice = 0, life = 0, myth = 0, storm = 0))]
    #[allow(clippy::too_many_arguments)]
    pub fn new(base_cost: i8, variable_cost: bool, shadow: u8, balance: u8, death: u8, fire: u8, ice: u8, life: u8, myth: u8, storm: u8) -> PyResult<Self> {
        let school_pips = SchoolPips {
            shadow,
            balance,
            death,
            fire,
            ice,
            life,
            myth,
            storm,
        };
        Ok(PySpellCost(SpellCost {
            variable_cost,
            base_cost,
            school_pips,
        }))
    }

    #[getter]
    pub fn get_base_cost(&self) -> i8 {
        self.0.base_cost
    }

    #[setter]
    pub fn set_base_cost(&mut self, base_cost: i8) {
        self.0.base_cost = base_cost;
    }

    #[getter]
    pub fn get_variable_cost(&self) -> bool {
        self.0.variable_cost
    }

    #[setter]
    pub fn set_variable_cost(&mut self, variable_cost: bool) {
        self.0.variable_cost = variable_cost;
    }

    #[getter]
    pub fn get_shadow(&self) -> u8 {
        self.0.school_pips.shadow
    }

    #[setter]
    pub fn set_shadow(&mut self, shadow: u8) {
        self.0.school_pips.shadow = shadow;
    }

    #[getter]
    pub fn get_balance(&self) -> u8 {
        self.0.school_pips.balance
    }

    #[setter]
    pub fn set_balance(&mut self, balance: u8) {
        self.0.school_pips.balance = balance;
    }

    #[getter]
    pub fn get_death(&self) -> u8 {
        self.0.school_pips.death
    }

    #[setter]
    pub fn set_death(&mut self, death: u8) {
        self.0.school_pips.death = death;
    }

    #[getter]
    pub fn get_fire(&self) -> u8 {
        self.0.school_pips.fire
    }

    #[setter]
    pub fn set_fire(&mut self, fire: u8) {
        self.0.school_pips.fire = fire;
    }

    #[getter]
    pub fn get_ice(&self) -> u8 {
        self.0.school_pips.ice
    }

    #[setter]
    pub fn set_ice(&mut self, ice: u8) {
        self.0.school_pips.ice = ice;
    }

    #[getter]
    pub fn get_life(&self) -> u8 {
        self.0.school_pips.life
    }

    #[setter]
    pub fn set_life(&mut self, life: u8) {
        self.0.school_pips.life = life;
    }

    #[getter]
    pub fn get_myth(&self) -> u8 {
        self.0.school_pips.myth
    }

    #[setter]
    pub fn set_myth(&mut self, myth: u8) {
        self.0.school_pips.myth = myth;
    }

    #[getter]
    pub fn get_storm(&self) -> u8 {
        self.0.school_pips.storm
    }

    #[setter]
    pub fn set_storm(&mut self, storm: u8) {
        self.0.school_pips.storm = storm;
    }
}

#[derive(Debug, Clone, Copy)]
#[pyclass(name = "TextAlignment")]
pub struct PyTextAlignment(TextAlignment);

#[pymethods]
impl PyTextAlignment {
    #[staticmethod]
    pub fn center() -> Self {
        PyTextAlignment(TextAlignment::Center)
    }

    #[staticmethod]
    pub fn left() -> Self {
        PyTextAlignment(TextAlignment::Left)
    }
}