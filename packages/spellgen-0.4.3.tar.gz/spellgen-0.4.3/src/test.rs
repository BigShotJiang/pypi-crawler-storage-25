
// pub struct StringPool {
//     page: [u8; 128],
//     values: 
// }

// pub struct StringPoolString {
//     start: usize,
//     length: usize,
//     pool: *const StringPool,
// }