#![allow(dead_code)]

mod shared;
#[doc(inline)]
#[allow(unused_imports)]
pub use shared::*;
