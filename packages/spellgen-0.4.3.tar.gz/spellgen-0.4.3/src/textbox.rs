use std::io::Cursor;
use std::ops::{Deref, DerefMut};
use std::path::Path;

use eyre::{Context, ContextCompat};
use ddsfile::{D3DFormat, Dds, DxgiFormat};
use image::{imageops::overlay, math::Rect, DynamicImage, RgbaImage};
use log::warn;
use compact_str::{CompactString, ToCompactString};

use crate::glyphs::GlyphAtlas;
use crate::{ImageCache, SizedImagePath};

#[derive(Debug, Eq, PartialEq, Clone)]
enum DescriptionPart {
    Space,
    Word(ColouredString),
    Icon(CompactString, (u32, u32)),
    NewLine,
}

#[derive(Debug, Eq, PartialEq, Clone)]
struct ColouredString {
    string: CompactString,
    colour: [u8; 4],
}

impl ColouredString {
    pub fn new(colour: [u8; 4]) -> Self {
        Self {
            string: CompactString::default(),
            colour,
        }
    }
}

impl std::fmt::Display for ColouredString {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.string.fmt(f)
    }
}

impl Deref for ColouredString {
    type Target = CompactString;

    fn deref(&self) -> &Self::Target {
        &self.string
    }
}

impl DerefMut for ColouredString {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.string
    }
}

#[derive(Debug, Default, Clone, Copy)]
pub enum TextAlignment {
    #[default]
    Center,
    Left
}

pub struct RichTextBox<'a> {
    base_path: &'a Path,
    text: String,
    rect: Rect,
    alignment: TextAlignment,
    atlas: &'a GlyphAtlas,
    word_wrap: bool,
    default_icon_size: (u32, u32),
    default_wide_icon_size: (u32, u32),
    madlib_cache: Option<&'a ImageCache<SizedImagePath>>,
}

#[derive(Debug, PartialEq, Eq)]
enum TagMode {
    Off,
    Checking,
    Color,
    Image,
    ImageRes,
}

impl<'a> RichTextBox<'a> {
    #[allow(clippy::too_many_arguments)]
    pub fn new( base_path: &'a Path, 
                text: String, 
                alignment: TextAlignment,
                atlas: &'a GlyphAtlas, 
                rect: Rect, 
                word_wrap: bool, 
                default_icon_size: (u32, u32), 
                default_wide_icon_size: (u32, u32), 
                madlib_cache: Option<&'a ImageCache<SizedImagePath>>
            ) -> Self {
        Self {
            base_path,
            text,
            rect,
            alignment,
            atlas,
            word_wrap,
            default_icon_size,
            default_wide_icon_size,
            madlib_cache,
        }
    }

    fn generate_tokens(&self) -> eyre::Result<Vec<DescriptionPart>> {
        let mut tokens = Vec::new();

        let mut mode = TagMode::Off;
        let mut slash = false;
        const DEFAULT_COLOUR: [u8; 4] = [0u8, 0, 0, 0xff];
        let mut colour = DEFAULT_COLOUR;
        let mut current_line = ColouredString::new(colour);
        let mut extra_data = CompactString::default();
        for char in self.text.chars() {
            if slash {
                if char == 'n' {
                    if !current_line.is_empty() {
                        tokens.push(DescriptionPart::Word(current_line));
                        current_line = ColouredString::new(colour);
                    }
                    if tokens.last().is_some_and(|f| f == &DescriptionPart::Space) {
                        tokens.pop();
                    }
                    tokens.push(DescriptionPart::NewLine);
                }
                slash = false;
                continue;
            }
            if char == '$' {
                match mode {
                    TagMode::Off => {
                        if !current_line.is_empty() {
                            tokens.push(DescriptionPart::Word(current_line));
                        }
                        mode = TagMode::Checking;
                    }
                    TagMode::Checking => {
                        if matches!(current_line.to_lowercase().as_str(), "colour" | "color" | "c") {
                            colour = DEFAULT_COLOUR;
                            mode = TagMode::Off;
                        } else {
                            warn!("\"{current_line}\" is not a known tag");
                            mode = TagMode::Off;
                        }
                    }
                    TagMode::Color => {
                        colour = u32::from_str_radix(&current_line, 16)
                            .wrap_err("Not a valid colour")?
                            .to_le_bytes();
                        mode = TagMode::Off;
                    }
                    TagMode::Image => {
                        tokens.push(DescriptionPart::Icon(current_line.string, self.default_icon_size));
                        mode = TagMode::Off;
                    }
                    TagMode::ImageRes => {
                        if matches!(extra_data.as_str(), "wide" | "w") {
                            tokens.push(DescriptionPart::Icon(current_line.string, self.default_wide_icon_size)); //needs tested
                        } else {
                            let mut parser = extra_data.split('x');
                            let i_width = parser
                                .next()
                                .wrap_err("Failed to parse resolution")?
                                .parse()
                                .wrap_err("Failed to parse resolution")?;
                            let i_height = parser
                                .next()
                                .wrap_err("Failed to parse resolution")?
                                .parse()
                                .wrap_err("Failed to parse resolution")?;
                            tokens.push(DescriptionPart::Icon(
                                current_line.string,
                                (i_width, i_height),
                            ));
                        }
                        extra_data.clear();
                        mode = TagMode::Off;
                    }
                }
                current_line = ColouredString::new(colour);
            } else if mode == TagMode::Checking && char == ':' {
                let tag = current_line;
                match tag.to_lowercase().as_str() {
                    "color" | "colour" | "c" => {
                        mode = TagMode::Color;
                    }
                    "image" | "img" | "i" => {
                        mode = TagMode::Image;
                    }
                    line => {
                        warn!("\"{line}\" is not a known tag");
                        mode = TagMode::Off;
                    }
                }
                current_line = ColouredString::new(colour);
            } else if mode == TagMode::Image && char == ':' && !matches!(current_line.string.as_str(), "http" | "https" | "https://localhost" | "localhost" | "http://localhost") {
                mode = TagMode::ImageRes;
            } else if mode == TagMode::Off && char == ' ' {
                if !current_line.is_empty() {
                    tokens.push(DescriptionPart::Word(current_line));
                    current_line = ColouredString::new(colour);
                }
                tokens.push(DescriptionPart::Space);
            } else if char == '\\' {
                slash = true;
            } else {
                if mode == TagMode::ImageRes {
                    &mut extra_data
                } else {
                    &mut current_line.string
                }
                .push(char);
            }
        }
        if !current_line.is_empty() {
            tokens.push(DescriptionPart::Word(current_line));
        }
        Ok(tokens)
    }

    fn generate_lines_from_tokens(&self, tokens: Vec<DescriptionPart>) -> Vec<RichTextBoxLine> {
        let mut offset = 0i64;
        let mut senteance = ColouredString::new([0, 0, 0, 0xff]);
        let mut lines = Vec::new();
        let mut line = Vec::new();
        for token in tokens.iter() {
            match token {
                DescriptionPart::NewLine => {
                    if !senteance.is_empty() {
                        line.push(RichTextBoxLinePart::Text(senteance));
                        senteance = ColouredString::new([0, 0, 0, 0xff]);
                    }
                    // next line
                    lines.push((offset, line));
                    line = Vec::new();
                    offset = 0;
                }
                DescriptionPart::Space => {
                    let glyph_length = if let Some(previous_char) = senteance.chars().next() {
                        self.atlas.get_glyph_length(' ', previous_char)
                    } else {
                        self.atlas.get_glyph_length(' ', '\0')
                    } as i64;
                    if offset + glyph_length > self.rect.width as i64 {
                        if !senteance.is_empty() {
                            line.push(RichTextBoxLinePart::Text(senteance));
                            senteance = ColouredString::new([0, 0, 0, 0xff]);
                        }
                        // next line
                        lines.push((offset, line));
                        line = Vec::new();
                        offset = 0;
                    } else {
                        senteance.push(' ');
                        offset += glyph_length;
                    }
                }
                DescriptionPart::Word(word) => {
                    if !senteance.is_empty() && senteance.colour != word.colour {
                        line.push(RichTextBoxLinePart::Text(senteance));
                        senteance = ColouredString::new(word.colour);
                    }
                    let word_length = self.atlas.get_word_length(word) as i64;
                    senteance.colour = word.colour;
                    if offset + word_length > self.rect.width as i64 {
                        if !senteance.is_empty() {
                            if senteance.ends_with(' ') {
                                senteance = ColouredString {
                                    colour: senteance.colour,
                                    string: senteance.trim_end().to_compact_string(),
                                };
                                let glyph_length =
                                    if let Some(previous_char) = senteance.chars().last() {
                                        self.atlas.get_glyph_length(' ', previous_char)
                                    } else {
                                        self.atlas.get_glyph_length(' ', '\0')
                                    } as i64;
                                offset -= glyph_length;
                            }
                            line.push(RichTextBoxLinePart::Text(senteance));
                            senteance = ColouredString::new(word.colour);
                        }
                        // next line
                        lines.push((offset, line));
                        line = Vec::new();
                        senteance.push_str(word);
                        offset = word_length;// - 1; //Need to test this
                    } else {
                        senteance.push_str(word);
                        offset += word_length;
                    }
                }
                DescriptionPart::Icon(icon, (i_width, i_height)) => {
                    let i_width = *i_width;
                    let i_height = *i_height;
                    if offset + i_width as i64 > self.rect.width as i64 {
                        if !senteance.is_empty() {
                            line.push(RichTextBoxLinePart::Text(senteance));
                            senteance = ColouredString::new([0, 0, 0, 0xff]);
                        }
                        // next line
                        lines.push((offset, line));
                        line = Vec::new();
                        line.push(RichTextBoxLinePart::Icon(
                            icon.clone(),
                            (i_width, i_height),
                        ));
                        offset = i_width as i64;
                    } else {
                        if !senteance.is_empty() {
                            line.push(RichTextBoxLinePart::Text(senteance));
                            senteance = ColouredString::new([0, 0, 0, 0xff]);
                        }
                        line.push(RichTextBoxLinePart::Icon(
                            icon.clone(),
                            (i_width, i_height),
                        ));
                        offset += i_width as i64;
                    }
                }
            }
        }
        if !senteance.is_empty() {
            line.push(RichTextBoxLinePart::Text(senteance));
        }
        if !line.is_empty() {
            lines.push((offset, line));
        }

        lines
            .drain(..)
            .map(|f| RichTextBoxLine {
                width: f.0 as u32,
                data: f.1,
            })
            .collect()
    }

    #[cfg(not(target_arch = "wasm32"))]
    pub fn generate_image(&self, height_offset: i64) -> eyre::Result<DynamicImage> {
        let tokens = self.generate_tokens()?;

        const HEIGHT_OFFSET: i64 = 1;

        let lines = self.generate_lines_from_tokens(tokens);

        let mut output = DynamicImage::new_rgba8(self.rect.width, self.rect.height);

        for (index, line) in lines.iter().enumerate() {
            let img = line.generate_image(
                self.base_path,
                self.atlas,
                25,
                if index > 1 {
                    height_offset + 1
                } else {
                    height_offset + 2
                },
                index as u32,
                self.madlib_cache
            )?;
            overlay(
                &mut output,
                &img,
                match self.alignment {
                    TextAlignment::Center => { (self.rect.width as i64) / 2 - line.width as i64 / 2 },
                    TextAlignment::Left => { 1 }
                },
                HEIGHT_OFFSET
                    + if self.word_wrap {
                        (index * 19) as i64
                    } else {
                        0
                    }
                    - 2,
            );
        }
        Ok(output)
    }

    #[cfg(target_arch = "wasm32")]
    pub async fn generate_image(&self, height_offset: i64) -> eyre::Result<DynamicImage> {
        let tokens = self.generate_tokens()?;

        const HEIGHT_OFFSET: i64 = 1;

        let lines = self.generate_lines_from_tokens(tokens);

        let mut output = DynamicImage::new_rgba8(self.rect.width, self.rect.height);

        for (index, line) in lines.iter().enumerate() {
            let img = line.generate_image(
                self.base_path,
                self.atlas,
                25,
                if index > 1 {
                    height_offset + 1
                } else {
                    height_offset + 2
                },
                index as u32,
                self.madlib_cache
            ).await?;
            overlay(
                &mut output,
                &img,
                match self.alignment {
                    TextAlignment::Center => { (self.rect.width as i64) / 2 - line.width as i64 / 2 },
                    TextAlignment::Left => { 1 }
                },
                HEIGHT_OFFSET
                    + if self.word_wrap {
                    (index * 19) as i64
                } else {
                    0
                }
                    - 2,
            );
        }
        Ok(output)
    }
}

#[derive(Debug)]
enum RichTextBoxLinePart {
    Text(ColouredString),
    Icon(CompactString, (u32, u32)),
}

#[derive(Debug)]
struct RichTextBoxLine {
    width: u32,
    data: Vec<RichTextBoxLinePart>,
}

impl RichTextBoxLine {
    #[cfg(not(target_family = "wasm"))]
    pub fn generate_image(
        &self,
        base_path: &Path,
        atlas: &GlyphAtlas,
        height: u32,
        height_offset: i64,
        line_num: u32,
        madlib_cache: Option<&ImageCache<SizedImagePath>>,
    ) -> eyre::Result<DynamicImage> {
        let mut offset = 0;
        let mut output = DynamicImage::new_rgba8(self.width + 1, height);
        let mut has_text = false;
        let mut adjustment = 1;
        for part in self.data.iter() {
            match part {
                RichTextBoxLinePart::Text(txt) => {
                    let text = atlas.generate_text_with_color(&txt.string, txt.colour);
                    overlay(&mut output, &text, offset - adjustment, 3);
                    offset += text.width() as i64 - 1;
                    has_text = true;
                }
                RichTextBoxLinePart::Icon(icon_path, (i_width, i_height)) => {
                    let icon_path = if !icon_path.starts_with("http") && !icon_path.starts_with("localhost") {
                        base_path.join(icon_path)
                    } else {
                        icon_path.into()
                    };
                    if let Some(cache) = madlib_cache {
                        let sized_icon_path = SizedImagePath { image: icon_path.clone() , size: (*i_width, *i_height) };
                        cache.scoped_get_or_insert_with::<(), eyre::Result<()>>(
                            sized_icon_path, 
                            || {
                                load_icon(i_width, i_height, &icon_path)
                            }, 
                            |icon| {
                                apply_icon(height_offset, line_num, &mut offset, &mut output, has_text, &mut adjustment, i_height, icon);
                            }
                        )?;
                    } else {
                        let icon = load_icon(i_width, i_height, &icon_path)?;
                        apply_icon(height_offset, line_num, &mut offset, &mut output, has_text, &mut adjustment, i_height, &icon);
                    }
                }
            }
        }
        Ok(output)
    }

    #[cfg(target_arch = "wasm32")]
    pub async fn generate_image(
        &self,
        base_path: &Path,
        atlas: &GlyphAtlas,
        height: u32,
        height_offset: i64,
        line_num: u32,
        madlib_cache: Option<&ImageCache<SizedImagePath>>,
    ) -> eyre::Result<DynamicImage> {
        let mut offset = 0;
        let mut output = DynamicImage::new_rgba8(self.width + 1, height);
        let mut has_text = false;
        let mut adjustment = 1;
        for part in self.data.iter() {
            match part {
                RichTextBoxLinePart::Text(txt) => {
                    let text = atlas.generate_text_with_color(&txt.string, txt.colour);
                    overlay(&mut output, &text, offset - adjustment, 3);
                    offset += text.width() as i64 - 1;
                    has_text = true;
                }
                RichTextBoxLinePart::Icon(icon_path, (i_width, i_height)) => {
                    let icon_path = if !icon_path.starts_with("http") && !icon_path.starts_with("localhost") {
                        base_path.join(icon_path)
                    } else {
                        icon_path.into()
                    };
                    if let Some(cache) = madlib_cache {
                        let sized_icon_path = SizedImagePath { image: icon_path.clone() , size: (*i_width, *i_height) };
                        cache.scoped_get_or_insert_with_async::<(), eyre::Result<()>, _>(
                            sized_icon_path,
                            async || {
                                load_icon(i_width, i_height, &icon_path).await
                            },
                            |icon| {
                                apply_icon(height_offset, line_num, &mut offset, &mut output, has_text, &mut adjustment, i_height, icon);
                            }
                        ).await?;
                    } else {
                        let icon = load_icon(i_width, i_height, &icon_path).await?;
                        apply_icon(height_offset, line_num, &mut offset, &mut output, has_text, &mut adjustment, i_height, &icon);
                    }
                }
            }
        }
        Ok(output)
    }
}

#[allow(clippy::too_many_arguments)]
fn apply_icon(height_offset: i64, line_num: u32, offset: &mut i64, output: &mut DynamicImage, has_text: bool, adjustment: &mut i64, i_height: &u32, icon: &image::ImageBuffer<image::Rgba<u8>, Vec<u8>>) {
    // Hacky, likely is a offset of line height - icon height or similiar
    let big = icon.height() > 16;// && line_num < 2;
    let mut adjust = if icon.height() == *i_height { 1 } else { 0 };
    if icon.height() != *i_height && line_num > 0 {
        adjust += 1;
    }
    if line_num >= 2 {
        adjust -= 1;
    }
    *adjustment += 1;
    overlay(
        output,
        icon,
        *offset - if has_text { 2 } else { 0 },
        height_offset - adjust + if big { 0 } else { 2 }, // Also hacky but works for now
    );
    *offset += icon.width() as i64;
}

#[cfg(not(target_arch = "wasm32"))]
fn load_icon(i_width: &u32, i_height: &u32, icon_path: &std::path::PathBuf) -> eyre::Result<image::ImageBuffer<image::Rgba<u8>, Vec<u8>>> {
    if is_dds(icon_path) {
        let bytes = std::fs::read(icon_path)
            .wrap_err_with(|| format!("Failed to read icon: {}", icon_path.display()))?;
        if let Some(icon) = decode_dxt1_dds_with_alpha(&bytes)? {
            return Ok(icon
                .resize_exact(*i_width, *i_height, image::imageops::FilterType::Triangle)
                .to_rgba8());
        }
    }

    let Ok(icon) = image::ImageReader::open(icon_path) else {
        return Err(eyre::eyre!("Failed to open icon: {}", icon_path.display()));
    };
    let mut icon = icon.decode()?;
    // Check if the icon is in RGB format and convert it to RGBA
    if matches!(icon, DynamicImage::ImageRgb8(_)) {
        let mut raw = icon.to_rgba8();
        for pixel in raw.pixels_mut() {
            if pixel.0 == [0, 0, 0, 0xff] {
                pixel.0 = [0, 0, 0, 0];
            }
        }
        icon = DynamicImage::from(raw);
    }
    let icon = icon.resize_exact(
        *i_width,
        *i_height,
        image::imageops::FilterType::Triangle,
    );
    Ok(icon.to_rgba8())
}

#[cfg(target_arch = "wasm32")]
async fn load_icon(i_width: &u32, i_height: &u32, icon_path: &std::path::PathBuf) -> eyre::Result<image::ImageBuffer<image::Rgba<u8>, Vec<u8>>> {
    let resp = reqwest::get(icon_path.to_str().unwrap()).await
        .wrap_err("Failed to fetch icon")?;
    let bytes = resp.bytes().await
        .wrap_err("Failed to read icon bytes")?;

    if is_dds(icon_path) {
        if let Some(icon) = decode_dxt1_dds_with_alpha(&bytes)? {
            return Ok(icon
                .resize_exact(*i_width, *i_height, image::imageops::FilterType::Triangle)
                .to_rgba8());
        }
    }

    let mut icon = image::load_from_memory(&bytes)
        .wrap_err("Failed to decode icon")?;
    // Check if the icon is in RGB format and convert it to RGBA
    if matches!(icon, DynamicImage::ImageRgb8(_)) {
        let mut raw = icon.to_rgba8();
        for pixel in raw.pixels_mut() {
            if pixel.0 == [0, 0, 0, 0xff] {
                pixel.0 = [0, 0, 0, 0];
            }
        }
        icon = DynamicImage::from(raw);
    }
    let icon = icon.resize_exact(
        *i_width,
        *i_height,
        image::imageops::FilterType::Triangle,
    );
    Ok(icon.to_rgba8())
}

fn is_dds(path: &Path) -> bool {
    path.extension()
        .and_then(|extension| extension.to_str())
        .is_some_and(|extension| extension.eq_ignore_ascii_case("dds"))
}

fn decode_dxt1_dds_with_alpha(bytes: &[u8]) -> eyre::Result<Option<DynamicImage>> {
    let dds = Dds::read(Cursor::new(bytes)).wrap_err("Failed to read DDS icon")?;
    if !is_dxt1(&dds) {
        return Ok(None);
    }

    let width = dds.get_width();
    let height = dds.get_height();
    let data = dds.get_data(0).wrap_err("Failed to read DDS icon data")?;
    let main_size = dds
        .get_main_texture_size()
        .wrap_err("Failed to determine DDS icon size")? as usize;
    let data = data
        .get(..main_size)
        .wrap_err("DDS icon data is smaller than expected")?;

    let blocks_wide = width.div_ceil(4);
    let blocks_high = height.div_ceil(4);
    let expected_size = (blocks_wide * blocks_high * 8) as usize;
    let data = data
        .get(..expected_size)
        .wrap_err("DDS icon DXT1 data is smaller than expected")?;

    let mut output = RgbaImage::new(width, height);
    for block_y in 0..blocks_high {
        for block_x in 0..blocks_wide {
            let block_index = ((block_y * blocks_wide + block_x) * 8) as usize;
            decode_dxt1_block_rgba(
                &data[block_index..block_index + 8],
                &mut output,
                block_x * 4,
                block_y * 4,
            );
        }
    }

    Ok(Some(DynamicImage::ImageRgba8(output)))
}

fn is_dxt1(dds: &Dds) -> bool {
    matches!(dds.get_d3d_format(), Some(D3DFormat::DXT1))
        || matches!(
            dds.get_dxgi_format(),
            Some(DxgiFormat::BC1_Typeless | DxgiFormat::BC1_UNorm | DxgiFormat::BC1_UNorm_sRGB)
        )
}

fn decode_dxt1_block_rgba(block: &[u8], output: &mut RgbaImage, x_offset: u32, y_offset: u32) {
    let color0 = u16::from_le_bytes([block[0], block[1]]);
    let color1 = u16::from_le_bytes([block[2], block[3]]);
    let color_table = u32::from_le_bytes([block[4], block[5], block[6], block[7]]);

    let mut colors = [[0; 4]; 4];
    colors[0] = rgba_from_565(color0);
    colors[1] = rgba_from_565(color1);

    if color0 > color1 {
        colors[2] = interpolate_rgb_thirds(colors[0], colors[1], 2, 1);
        colors[3] = interpolate_rgb_thirds(colors[0], colors[1], 1, 2);
    } else {
        colors[2] = interpolate_rgb_halves(colors[0], colors[1]);
        colors[3] = [0, 0, 0, 0];
    }

    for y in 0..4 {
        for x in 0..4 {
            let pixel_x = x_offset + x;
            let pixel_y = y_offset + y;
            if pixel_x >= output.width() || pixel_y >= output.height() {
                continue;
            }

            let table_offset = (y * 4 + x) * 2;
            let color_index = ((color_table >> table_offset) & 0b11) as usize;
            output.put_pixel(pixel_x, pixel_y, image::Rgba(colors[color_index]));
        }
    }
}

fn rgba_from_565(color: u16) -> [u8; 4] {
    let r = ((color >> 11) & 0x1f) as u8;
    let g = ((color >> 5) & 0x3f) as u8;
    let b = (color & 0x1f) as u8;

    [
        (r << 3) | (r >> 2),
        (g << 2) | (g >> 4),
        (b << 3) | (b >> 2),
        0xff,
    ]
}

fn interpolate_rgb_thirds(a: [u8; 4], b: [u8; 4], a_weight: u16, b_weight: u16) -> [u8; 4] {
    [
        ((u16::from(a[0]) * a_weight + u16::from(b[0]) * b_weight + 1) / 3) as u8,
        ((u16::from(a[1]) * a_weight + u16::from(b[1]) * b_weight + 1) / 3) as u8,
        ((u16::from(a[2]) * a_weight + u16::from(b[2]) * b_weight + 1) / 3) as u8,
        0xff,
    ]
}

fn interpolate_rgb_halves(a: [u8; 4], b: [u8; 4]) -> [u8; 4] {
    [
        (u16::from(a[0]) + u16::from(b[0])).div_ceil(2) as u8,
        (u16::from(a[1]) + u16::from(b[1])).div_ceil(2) as u8,
        (u16::from(a[2]) + u16::from(b[2])).div_ceil(2) as u8,
        0xff,
    ]
}

#[cfg(test)]
mod tests {
    use image::RgbaImage;

    use super::decode_dxt1_block_rgba;

    #[test]
    fn dxt1_transparent_index_is_alpha_without_turning_black_transparent() {
        let mut image = RgbaImage::new(4, 4);
        let block = [
            0x00, 0x00, // color0: black
            0xff, 0xff, // color1: white, color0 <= color1 enables transparent index 3
            0xe4, 0xe4, 0xe4, 0xe4, // one row each of indices 0, 1, 2, 3
        ];

        decode_dxt1_block_rgba(&block, &mut image, 0, 0);

        assert_eq!(image.get_pixel(0, 0).0, [0, 0, 0, 0xff]);
        assert_eq!(image.get_pixel(3, 3).0, [0, 0, 0, 0]);
    }
}
