use ahash::AHashMap;
use compact_str::CompactString;
use textbox::{RichTextBox};
pub use textbox::TextAlignment;
use eyre::{eyre, Result, WrapErr};
use glyphs::GlyphAtlas;
use image::math::Rect;
use image::{imageops::*, *};
use parking_lot::RwLock;
use std::collections::hash_map::Entry;
use std::future::Future;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use eyre::ContextCompat;

mod textbox;
mod glyphs;

#[cfg(feature="py")]
mod py;

#[cfg(test)]
mod tests;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum SpellImageSize {
    #[default]
    Default,
    Snack,
    Alt
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum TitleSize {
    #[default]
    Default,
    Alt
}

#[derive(Debug, Default, Clone, Copy)]
pub struct SpellCost {
    pub variable_cost: bool,
    pub base_cost: i8,
    pub school_pips: SchoolPips,
}

#[derive(Debug, Default, Clone)]
pub struct SpellCard {
    pub title: String,
    pub title_size: TitleSize,
    pub description: String,
    pub description_alignment: TextAlignment,
    pub frame: Option<PathBuf>,
    pub spell_image: Option<PathBuf>,
    pub spell_image_size: SpellImageSize,
    pub additional_spell_images_lower: Option<Vec<PathBuf>>,
    pub additional_spell_images_upper: Option<Vec<PathBuf>>,
    pub cost: Option<SpellCost>,
    pub school_icon: Option<PathBuf>,
    pub type_icon: Option<PathBuf>,
    pub accuracy: CompactString,
    pub accuracy_position: AccuracyPosition,
    pub accuracy_bolding: bool,
    pub accuracy_colour: Option<[u8; 4]>,
    pub booster_pack: Option<PathBuf>,
    pub cloaked: bool,
    pub no_pvp: bool,
    pub no_pve: bool,
    pub pierce: i16,
    pub level_requirement: u16,
    pub cannot_discard: bool,
    pub essence_collection: bool,
    pub single_use: bool,
    pub legacy_madlib_sizes: bool
}

impl SpellCost {
    pub fn add_pips_from_str(&mut self, pip_name: impl AsRef<str>, amount: u8) {
        self.school_pips.add_pips_from_str(pip_name, amount);
    }

    pub fn inc_pip_from_str(&mut self, pip_name: impl AsRef<str>) {
        self.school_pips.add_pips_from_str(pip_name, 1);
    }

    pub fn sub_pips_from_str(&mut self, pip_name: impl AsRef<str>, amount: u8) {
        self.school_pips.sub_pips_from_str(pip_name, amount);
    }

    pub fn dec_pip_from_str(&mut self, pip_name: impl AsRef<str>) {
        self.school_pips.sub_pips_from_str(pip_name, 1);
    }
}

#[derive(Debug, Default, Clone, Copy)]
pub struct SchoolPips {
    pub shadow: u8,
    pub balance: u8,
    pub death: u8,
    pub fire: u8,
    pub ice: u8,
    pub life: u8,
    pub myth: u8,
    pub storm: u8
}

impl SchoolPips {
    pub fn add_pips_from_str(&mut self, pip_name: impl AsRef<str>, amount: u8) {
        match pip_name.as_ref().to_lowercase().as_str() {
            "shadow" => self.shadow += amount,
            "balance" => self.balance += amount,
            "death" => self.death += amount,
            "fire" => self.fire += amount,
            "ice" => self.ice += amount,
            "life" => self.life += amount,
            "myth" => self.myth += amount,
            "storm" => self.storm += amount,
            _ => {}
        }
    }

    pub fn total_pips(&self) -> u8 {
        self.shadow + self.balance + self.death + self.fire + self.ice + self.life + self.myth + self.storm
    }

    pub fn inc_pip_from_str(&mut self, pip_name: impl AsRef<str>) {
        self.add_pips_from_str(pip_name, 1);
    }

    pub fn sub_pips_from_str(&mut self, pip_name: impl AsRef<str>, amount: u8) {
        match pip_name.as_ref().to_lowercase().as_str() {
            "shadow" => self.shadow -= amount,
            "balance" => self.balance -= amount,
            "death" => self.death -= amount,
            "fire" => self.fire -= amount,
            "ice" => self.ice -= amount,
            "life" => self.life -= amount,
            "myth" => self.myth -= amount,
            "storm" => self.storm -= amount,
            _ => {}
        }
    }

    pub fn dec_pip_from_str(&mut self, pip_name: impl AsRef<str>) {
        self.sub_pips_from_str(pip_name, 1);
    }

    ///Expected pip priorities per school is:
    /// * Shadow - 0
    /// * Balance - 1
    /// * Death - 2
    /// * Fire - 3
    /// * Ice - 4
    /// * Life - 5
    /// * Myth - 6
    /// * Storm - 7
    fn create_pip<S: AsRef<Path>>(path: S) -> Result<RgbaImage> {
        let mut img = image::ImageReader::open(&path)
            .map_err(ImageError::from)
            .wrap_err_with(|| format!("Failed to open pip image: {:?}", path.as_ref()))?
            .decode()
            .wrap_err_with(|| format!("Failed to decode pip image: {:?}", path.as_ref()))?;
        let mut shadow = img
            .resize(img.width() + 4, img.height() + 4, FilterType::Nearest)
            .into_rgba8();
        for pixel in shadow.pixels_mut() {
            if pixel.0[3] > 100 {
                pixel.0 = [0, 0, 0, 0xff];
            }
        }
        let mut shadow = DynamicImage::ImageRgba8(shadow);
        overlay(&mut shadow, &img, 2, 2);
        img = shadow.resize_exact(31, 31, FilterType::Gaussian);

        Ok(img.into_rgba8())
    }

    #[cfg(target_family = "wasm")]
    async fn create_pip_async<S: AsRef<Path>>(path: S) -> Result<RgbaImage> {
        let response = reqwest::get(&path.as_ref().to_string_lossy().to_string())
            .await
            .wrap_err_with(|| format!("Failed to get pip image: {:?}", path.as_ref()))?;
        let bytes = response
            .bytes()
            .await
            .wrap_err_with(|| format!("Failed to get pip image bytes: {:?}", path.as_ref()))?;
        let mut img = image::load_from_memory(&bytes).map_err(ImageError::from)?;
        let mut shadow = img
            .resize(img.width() + 4, img.height() + 4, FilterType::Nearest)
            .into_rgba8();
        for pixel in shadow.pixels_mut() {
            if pixel.0[3] > 100 {
                pixel.0 = [0, 0, 0, 0xff];
            }
        }
        let mut shadow = DynamicImage::ImageRgba8(shadow);
        overlay(&mut shadow, &img, 2, 2);
        img = shadow.resize_exact(31, 31, FilterType::Gaussian);

        Ok(img.into_rgba8())
    }

    fn create_shadow_pip<S: AsRef<Path>>(path: S, other_pip_path: S) -> Result<RgbaImage> {
        let img = image::ImageReader::open(&path)
            .map_err(ImageError::from)
            .wrap_err_with(|| format!("Failed to open pip image: {:?}", path.as_ref()))?
            .decode()
            .wrap_err_with(|| format!("Failed to decode pip image: {:?}", path.as_ref()))?;
        let mut border = image::ImageReader::open(other_pip_path)
            .map_err(ImageError::from)
            .wrap_err("Failed to open balance pip image")?
            .decode()
            .wrap_err("Failed to decode balance pip image")?;
        let mut inner = border.resize(28, 28, FilterType::Gaussian);

        for pixel in inner.as_mut_rgba8().expect("Need to set message").pixels_mut() {
            if pixel.0[3] > 50 {
                pixel.0 = [0xff, 0xff, 0xff, 0xff];
            } else {
                pixel.0 = [0, 0, 0, 0];
            }
        }

        let inner = inner.blur(0.3);
        overlay(&mut border, &inner, 2, 2);

        let mut layer_3 = img.clone().into_rgba8();
        for pixel in layer_3.pixels_mut() {
            if pixel.0[3] == 0xff {
                pixel.0 = [0, 0, 0, 0];
            } else {
                pixel.0[3] = pixel.0[3].saturating_sub(50);
            }
        }

        for (pixel, other) in border
            .as_mut_rgba8()
            .expect("Need to set message")
            .pixels_mut()
            .zip(layer_3.pixels())
        {
            if pixel.0 == [0xff, 0xff, 0xff, 0xff] {
                pixel.0 = [0, 0, 0, 0];
            } else if pixel.0 == [0, 0, 0, 0] {
                pixel.0 = other.0;
            } else if pixel.0[3] != 0 {
                pixel.blend(other);
                pixel.blend(&[0, 0, 0, 60].into());
                pixel.blend(other);
            }
        }

        let mut border_shadow = border
            .resize(border.width() + 4, border.height() + 4, FilterType::Nearest)
            .into_rgba8();
        for pixel in border_shadow.pixels_mut() {
            if pixel.0[3] > 100 {
                pixel.0 = [0, 0, 0, 0xff];
            }
        }
        let mut border_shadow = DynamicImage::ImageRgba8(border_shadow);
        overlay(&mut border_shadow, &border, 2, 2);
        border = border_shadow.resize_exact(31, 31, FilterType::Gaussian);

        let mut layer_2 = img.into_rgba8();
        for pixel in layer_2.pixels_mut() {
            if pixel.0[3] != 0xff {
                pixel.0 = [0, 0, 0, 0];
            }
        };
        overlay(&mut layer_2, &border, 0, 0);
        overlay(&mut layer_3, &layer_2, 0, 0);
        Ok(layer_3)
    }

    #[cfg(target_family = "wasm")]
    async fn create_shadow_pip_async<S: AsRef<Path>>(path: S, other_pip_path: S) -> Result<RgbaImage> {
        let img = {
            let response = reqwest::get(&path.as_ref().to_string_lossy().to_string())
                .await
                .wrap_err_with(|| format!("Failed to get pip image: {:?}", path.as_ref()))?;
            let bytes = response
                .bytes()
                .await
                .wrap_err_with(|| format!("Failed to get pip image bytes: {:?}", path.as_ref()))?;
            image::load_from_memory(&bytes)
                .wrap_err_with(|| format!("Failed to decode pip image: {:?}", path.as_ref()))?
        };
        let mut border = {
            let response = reqwest::get(&other_pip_path.as_ref().to_string_lossy().to_string())
                .await
                .wrap_err_with(|| format!("Failed to get balance pip image: {:?}", other_pip_path.as_ref()))?;
            let bytes = response
                .bytes()
                .await
                .wrap_err_with(|| format!("Failed to get balance pip image bytes: {:?}", other_pip_path.as_ref()))?;
            image::load_from_memory(&bytes).map_err(ImageError::from)
                .wrap_err_with(|| format!("Failed to decode balance pip image: {:?}", other_pip_path.as_ref()))?
        };
        let mut inner = border.resize(28, 28, FilterType::Gaussian);

        for pixel in inner.as_mut_rgba8().expect("Need to set message").pixels_mut() {
            if pixel.0[3] > 50 {
                pixel.0 = [0xff, 0xff, 0xff, 0xff];
            } else {
                pixel.0 = [0, 0, 0, 0];
            }
        }

        let inner = inner.blur(0.3);
        overlay(&mut border, &inner, 2, 2);

        let mut layer_3 = img.clone().into_rgba8();
        for pixel in layer_3.pixels_mut() {
            if pixel.0[3] == 0xff {
                pixel.0 = [0, 0, 0, 0];
            } else {
                pixel.0[3] = pixel.0[3].saturating_sub(50);
            }
        }

        for (pixel, other) in border
            .as_mut_rgba8()
            .expect("Need to set message")
            .pixels_mut()
            .zip(layer_3.pixels())
        {
            if pixel.0 == [0xff, 0xff, 0xff, 0xff] {
                pixel.0 = [0, 0, 0, 0];
            } else if pixel.0 == [0, 0, 0, 0] {
                pixel.0 = other.0;
            } else if pixel.0[3] != 0 {
                pixel.blend(other);
                pixel.blend(&[0, 0, 0, 60].into());
                pixel.blend(other);
            }
        }

        let mut border_shadow = border
            .resize(border.width() + 4, border.height() + 4, FilterType::Nearest)
            .into_rgba8();
        for pixel in border_shadow.pixels_mut() {
            if pixel.0[3] > 100 {
                pixel.0 = [0, 0, 0, 0xff];
            }
        }
        let mut border_shadow = DynamicImage::ImageRgba8(border_shadow);
        overlay(&mut border_shadow, &border, 2, 2);
        border = border_shadow.resize_exact(31, 31, FilterType::Gaussian);

        let mut layer_2 = img.into_rgba8();
        for pixel in layer_2.pixels_mut() {
            if pixel.0[3] != 0xff {
                pixel.0 = [0, 0, 0, 0];
            }
        };
        overlay(&mut layer_2, &border, 0, 0);
        overlay(&mut layer_3, &layer_2, 0, 0);
        Ok(layer_3)
    }
}

#[derive(Debug, Default, Clone)]
pub struct SchoolPipImages {
    pub shadow: RgbaImage,
    pub balance: RgbaImage,
    pub death: RgbaImage,
    pub fire: RgbaImage,
    pub ice: RgbaImage,
    pub life: RgbaImage,
    pub myth: RgbaImage,
    pub storm: RgbaImage
}

#[derive(Clone)]
struct SpellCostImages {
    pub numbers: [RgbaImage; 21],
    pub x: RgbaImage,
    pub minus: RgbaImage,
    pub plus: RgbaImage,
    pub school_pips: SchoolPipImages,
}

#[derive(Debug, Clone, Hash, Eq, PartialEq)]
pub struct SizedImagePath {
    pub image: PathBuf,
    pub size: (u32, u32),
}

#[derive(Default)]
pub struct ImageCache<T = PathBuf> {
    images: RwLock<AHashMap<T, RgbaImage>>,
}

impl<T: Clone> Clone for ImageCache<T> {
    fn clone(&self) -> Self {
        let images = self.images.read();
        let images = images.clone();
        Self {
            images: RwLock::new(images),
        }
    }
}

impl<T: std::hash::Hash + Eq> ImageCache<T> {
    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            images: RwLock::new(AHashMap::with_capacity(capacity)),
        }
    }

    pub fn get_cloned(&self, path: impl AsRef<T>) -> Option<RgbaImage> {
        let images = self.images.read();
        images.get(path.as_ref()).cloned()
    }

    pub fn scoped<O>(&self, path: impl AsRef<T>, fun: impl Fn(&RgbaImage) -> O) -> O {
        let lock = self.images.read();
        let image = lock.get(path.as_ref()).expect("Image not found");
        fun(image)
    }

    pub async fn scoped_async<O, F>(&self, path: impl AsRef<T>, fun: impl for<'a> Fn(&'a RgbaImage) -> F) -> O
    where
        F: Future<Output = O> {
        let lock = self.images.read();
        let image = lock.get(path.as_ref()).expect("Image not found");
        fun(image).await
    }

    pub fn scoped_many<O>(&self, paths: &[impl AsRef<T>], fun: impl Fn(&[&RgbaImage]) -> O) -> O {
        let lock = self.images.read();
        let images = paths.iter().filter_map(|path| lock.get(path.as_ref())).collect::<Vec<_>>();
        fun(&images)
    }

    pub async fn scoped_many_async<O, F>(&self, paths: &[impl AsRef<T>], fun: impl Fn(&[&RgbaImage]) -> F) -> O
    where
        F: Future<Output = O> {
        let lock = self.images.read();
        let images = paths.iter().filter_map(|path| lock.get(path.as_ref())).collect::<Vec<_>>();
        fun(&images).await
    }

    pub fn scoped_mut<O>(&self, path: impl AsRef<T>, fun: impl FnOnce(&mut RgbaImage) -> O) -> O {
        let mut lock = self.images.write();
        let image = lock.get_mut(path.as_ref()).expect("Image not found");
        fun(image)
    }

    pub async fn scoped_mut_async<O, F>(&self, path: impl AsRef<T>, fun: impl FnOnce(&mut RgbaImage) -> F) -> O
    where
        F: Future<Output = O> {
        let mut lock = self.images.write();
        let image = lock.get_mut(path.as_ref()).expect("Image not found");
        fun(image).await
    }

    pub fn inner(&self) -> &RwLock<AHashMap<T, RgbaImage>> {
        &self.images
    }

    pub fn inner_mut(&mut self) -> &mut RwLock<AHashMap<T, RgbaImage>> {
        &mut self.images
    }

    pub fn insert(&self, path: T, image: RgbaImage) {
        let mut images = self.images.write();
        images.insert(path, image);
    }

    pub fn get_cloned_or_insert_with<E, F>(&self, path: impl Into<T>, f: F) -> Result<RgbaImage, E>
    where
        E: std::error::Error,
        F: FnOnce() -> Result<RgbaImage, E>,
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(img) = images.get(&path) {
            return Ok(img.clone());
        }
        // If the image is not in the cache, we need to insert it
        let mut images = self.images.write();
        match images.entry(path) {
            Entry::Occupied(entry) => Ok(entry.get().clone()),
            Entry::Vacant(entry) => {
                let image = f()?;
                entry.insert(image.clone());
                Ok(image)
            }
        }
    }

    pub async fn get_cloned_or_insert_with_async<E, F, Fut>(&self, path: impl Into<T>, f: F) -> Result<RgbaImage, E>
    where
        E: std::error::Error,
        F: FnOnce() -> Fut,
        Fut: Future<Output = Result<RgbaImage, E>>,
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(img) = images.get(&path) {
            return Ok(img.clone());
        }
        // If the image is not in the cache, we need to insert it
        let mut images = self.images.write();
        match images.entry(path) {
            Entry::Occupied(entry) => Ok(entry.get().clone()),
            Entry::Vacant(entry) => {
                let image = f().await?;
                entry.insert(image.clone());
                Ok(image)
            }
        }
    }

    pub fn scoped_get_or_insert_with<O, F>(&self, path: impl Into<T>, f: impl FnOnce() -> Result<RgbaImage>, fun: impl FnOnce(&RgbaImage) -> O) -> Result<O>
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(image) = images.get(&path) {
            return Ok(fun(image));
        }
        drop(images);
        // If the image is not in the cache, we need to insert it
            let mut images = self.images.write();
            match images.entry(path) {
                Entry::Occupied(entry) => { 
                    let image = entry.get();
                    Ok(fun(image))
                },
                // Only here in the unlikely event that the image was removed between the read and write lock
                // this should never happen, but if it does, we will just load the image again
                Entry::Vacant(entry) => {
                    let image = f()?;
                    let image = entry.insert(image);
                    Ok(fun(image))
                }
            
        }
    }

    pub async fn scoped_async_get_or_insert_with<O, F, Fut>(&self, path: impl Into<T>, f: impl FnOnce() -> Result<RgbaImage>, fun: impl FnOnce(&RgbaImage) -> Fut) -> Result<O>
    where
        Fut: Future<Output = O>
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(image) = images.get(&path) {
            return Ok(fun(image).await);
        }
        drop(images);
        // If the image is not in the cache, we need to insert it
        let mut images = self.images.write();
        match images.entry(path) {
            Entry::Occupied(entry) => {
                let image = entry.get();
                Ok(fun(image).await)
            },
            // Only here in the unlikely event that the image was removed between the read and write lock
            // this should never happen, but if it does, we will just load the image again
            Entry::Vacant(entry) => {
                let image = f()?;
                let image = entry.insert(image);
                Ok(fun(image).await)
            }

        }
    }

    pub async fn scoped_get_or_insert_with_async<O, F, Fut>(&self, path: impl Into<T>, f: impl FnOnce() -> Fut, fun: impl FnOnce(&RgbaImage) -> O) -> Result<O>
    where
        Fut: Future<Output = Result<RgbaImage>>
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(image) = images.get(&path) {
            return Ok(fun(image));
        }
        drop(images);
        // If the image is not in the cache, we need to insert it
        let mut images = self.images.write();
        match images.entry(path) {
            Entry::Occupied(entry) => {
                let image = entry.get();
                Ok(fun(image))
            },
            // Only here in the unlikely event that the image was removed between the read and write lock
            // this should never happen, but if it does, we will just load the image again
            Entry::Vacant(entry) => {
                let image = f().await?;
                let image = entry.insert(image);
                Ok(fun(image))
            }

        }
    }

    pub async fn scoped_async_get_or_insert_with_async<O, F, Fut, Fut2>(&self, path: impl Into<T>, f: impl FnOnce() -> Fut, fun: impl FnOnce(&RgbaImage) -> Fut2) -> Result<O>
    where
        Fut: Future<Output = Result<RgbaImage>>,
        Fut2: Future<Output = O>
    {
        let path = path.into();
        let images = self.images.read();
        if let Some(image) = images.get(&path) {
            return Ok(fun(image).await);
        }
        drop(images);
        // If the image is not in the cache, we need to insert it
        let mut images = self.images.write();
        match images.entry(path) {
            Entry::Occupied(entry) => {
                let image = entry.get();
                Ok(fun(image).await)
            },
            // Only here in the unlikely event that the image was removed between the read and write lock
            // this should never happen, but if it does, we will just load the image again
            Entry::Vacant(entry) => {
                let image = f().await?;
                let image = entry.insert(image);
                Ok(fun(image).await)
            }

        }
    }
}

#[derive(Clone)]
pub struct SpellFactorySettings {
    pub assets_path: PathBuf,
    pub glyph_defs_path: PathBuf,
    pub spell_title_font_path: PathBuf,
    pub spell_description_font_path: PathBuf,
    pub shadow_school_pip_path: PathBuf,
    pub balance_school_pip_path: PathBuf,
    pub death_school_pip_path: PathBuf,
    pub fire_school_pip_path: PathBuf,
    pub ice_school_pip_path: PathBuf,
    pub life_school_pip_path: PathBuf,
    pub myth_school_pip_path: PathBuf,
    pub storm_school_pip_path: PathBuf,
    pub rank_number_icons: [PathBuf; 21],
    pub rank_minus_icon: PathBuf,
    pub rank_plus_icon: PathBuf,
    pub rank_x_icon: PathBuf,
    pub cloak_icon: PathBuf,
    pub cloak_frame_icon: PathBuf,
    pub pvp_only_icon: PathBuf,
    pub pve_only_icon: PathBuf,
    pub banned_icon: PathBuf,
    pub single_use_icon: PathBuf,
    pub cannot_discard_icon: PathBuf,
    pub essence_collection_icon: PathBuf,
    pub pierce_icon: PathBuf,
    pub pierce_frame_icon: PathBuf,
    pub level_requirement_icon: PathBuf,
    pub default_icon_size: (u32, u32),
    pub default_wide_icon_size: (u32, u32),
    pub cache_madlibs: bool
}

/// Calculates the perceived brightness of an RGB color using luminance formula
const fn calculate_brightness(r: u8, g: u8, b: u8) -> f32 {
    // Using standard luminance formula (ITU-R BT.709)
    0.299 * r as f32 + 0.587 * g as f32 + 0.114 * b as f32
}

fn recolour_pixel(pixel: Rgba<u8>, target_color: Rgba<u8>, white_threshold: u8) -> Rgba<u8> {        
        // Check if the pixel is actually grayscale
        if pixel.0[3] == 0 {
            return pixel;
        }

        let Rgba([r, g, b, a]) = pixel;
        
        // Check if pixel is considered "white" (all RGB values above threshold)
        if r >= white_threshold && g >= white_threshold && b >= white_threshold {
            // Calculate original brightness (luminance)
            let original_brightness = calculate_brightness(r, g, b);
            
            // Calculate target brightness
            let target_brightness = calculate_brightness(target_color[0], target_color[1], target_color[2]);
            
            let new_color = if original_brightness < target_brightness {
                // Original is darker, so darken the target color proportionally
                let brightness_ratio = original_brightness / target_brightness;
                [
                    (target_color[0] as f32 * brightness_ratio) as u8,
                    (target_color[1] as f32 * brightness_ratio) as u8,
                    (target_color[2] as f32 * brightness_ratio) as u8,
                    a
                ]
            } else {
                // Original is brighter or equal, use target color as-is
                target_color.0
            };
            
            Rgba([new_color[0], new_color[1], new_color[2], a])
        } else {
            pixel
        }
    }

/// This is a reusable factory for creating cards. it will reuse the images and fonts to avoid repeatedly loading them.
/// the exception however is the spell image, which is loaded each time due to the amount.
#[derive(Clone)]
pub struct CardFactory {
    base_path: PathBuf,
    description_text: GlyphAtlas,
    title_text: GlyphAtlas,
    cost_images: SpellCostImages,
    school_icons: ImageCache,
    type_icons: ImageCache,
    booster_icons: ImageCache,
    frames: ImageCache,
    spell_images: ImageCache,
    cloak_icon: RgbaImage,
    cloak_frame_icon: RgbaImage,
    pvp_only_icon: RgbaImage,
    pve_only_icon: RgbaImage,
    banned_icon: RgbaImage,
    single_use_icon_small: RgbaImage,
    single_use_icon: RgbaImage,
    cannot_discard_icon: RgbaImage,
    essence_collection_icon: RgbaImage,
    pierce_icon_path: PathBuf,
    pierce_frame_icon: RgbaImage,
    level_requirement_icon: RgbaImage,
    level_requirement_icon_small: RgbaImage,
    madlib_cache: Option<ImageCache<SizedImagePath>>,
    default_icon_size: (u32, u32),
    default_wide_icon_size: (u32, u32),
}

macro_rules! load_image {
    (async, $path:expr, std::io::Error) => {{
        let response = reqwest::get($path)
        .await.map_err(std::io::Error::other)?;
        let bytes = response.bytes().await.map_err(std::io::Error::other)?;
        image::load_from_memory(&bytes)
            .wrap_err_with(|| format!("Failed to decode image: {:?}", $path))
    }};
    (async, $path:expr) => {{
        let response = reqwest::get($path)
        .await.wrap_err_with(|| format!("Failed to get image: {:?}", $path))?;
        let bytes = response.bytes().await.wrap_err_with(|| format!("Failed to get image: {:?}", $path))?;
        image::load_from_memory(&bytes)
            .wrap_err_with(|| format!("Failed to decode image: {:?}", $path))
    }};
    ($path:expr, std::io::Error) => {
        ImageReader::open($path)
            .map_err(std::io::Error::from)
            .wrap_err_with(|| format!("Failed to open image: {:?}", $path))?
            .decode()
            .wrap_err_with(|| {
                format!("Failed to decode image: {:?}", $path)
            })
    };
    ($path:expr) => {
        ImageReader::open($path)
            .map_err(ImageError::from)
            .wrap_err_with(|| format!("Failed to open image: {:?}", $path))?
            .decode()
            .wrap_err_with(|| {
                format!("Failed to decode image: {:?}", $path)
            })
    };
}

static EMPTY_SPELL_IMAGE: LazyLock<RgbaImage> = LazyLock::new(|| {
    let image = include_bytes!("../empty_spell_image.dds");
    let mut image = image::load_from_memory_with_format(image, ImageFormat::Dds).expect("Need to set message");
    if image.width() != CardFactory::DEFAULT_SPELL_IMG_WIDTH || image.height() != CardFactory::DEFAULT_SPELL_IMG_HEIGHT {
        image = image.resize_exact(CardFactory::DEFAULT_SPELL_IMG_WIDTH, CardFactory::DEFAULT_SPELL_IMG_HEIGHT, FilterType::Nearest); 
    }
    image.into_rgba8()
});

static SNACK_EMPTY_SPELL_IMAGE: LazyLock<RgbaImage> = LazyLock::new(|| {
    let image = include_bytes!("../empty_spell_image.dds");
    let mut image = image::load_from_memory_with_format(image, ImageFormat::Dds).expect("Need to set message");
    if image.width() != CardFactory::SNACK_SPELL_IMG_WIDTH || image.height() != CardFactory::SNACK_SPELL_IMG_HEIGHT {
        image = image.resize_exact(CardFactory::SNACK_SPELL_IMG_WIDTH, CardFactory::SNACK_SPELL_IMG_HEIGHT, FilterType::Nearest); 
    }
    image.into_rgba8()
});


impl CardFactory {
    #[cfg(not(target_family = "wasm"))]
    pub fn new(settings: SpellFactorySettings) -> Result<Self> {
        let path = &settings.assets_path;
        let glyph_path = if settings.glyph_defs_path.is_relative() {
            path.join(&settings.glyph_defs_path)
        } else {
            settings.glyph_defs_path.clone()
        };
        if !path.exists() {
            return Err(eyre!("Base path does not exist: {:?}", path));
        }
        if path.is_file() {
            return Err(eyre!("Base path is not a file: {:?}", path));
        }
        let description_text = GlyphAtlas::open(settings.spell_description_font_path, &glyph_path).wrap_err("Failed to generate glyph atlas for description.")?;
        let title_text = GlyphAtlas::open(settings.spell_title_font_path, &glyph_path).wrap_err("Failed to generate glyph atlas for title.")?;
        // Yellow color for the pip cost text
        const PIP_COST_COLOR: Rgba<u8> = Rgba([243, 237, 70, 0]);
        let mut cost_number_images = std::array::from_fn(|_| RgbaImage::new(0, 0));
        for (rank_path, slot) in settings.rank_number_icons.iter().zip(cost_number_images.iter_mut()) {
            let path = path.join(rank_path);
            let mut image = load_image!(&path, std::io::Error)?.into_rgba8();
            for pixel in image.pixels_mut() {
                if pixel.0[3] == 0 {
                    continue;
                }
                *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
            }
            *slot = image;
        }
        let cost_images = SpellCostImages {
            numbers: cost_number_images,
            x: {
                let path = path.join(&settings.rank_x_icon);
                let mut image = load_image!(&path, std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            minus: {
                let path = path.join(&settings.rank_minus_icon);
                let mut image = load_image!(&path, std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            plus: {
                let path = path.join(&settings.rank_plus_icon);
                let mut image = load_image!(&path, std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            school_pips: {
                macro_rules! create_pip {
                    ($path:expr) => {{
                        let path = path.join($path);
                        SchoolPips::create_pip(&path).map_err(std::io::Error::other).wrap_err_with(|| format!("{:?}", path))
                    }};
                }
                SchoolPipImages {
                    shadow: SchoolPips::create_shadow_pip(path.join(&settings.shadow_school_pip_path), path.join(&settings.balance_school_pip_path)).map_err(std::io::Error::other)?,
                    balance: create_pip!(&settings.balance_school_pip_path)?,
                    death: create_pip!(&settings.death_school_pip_path)?,
                    fire: create_pip!(&settings.fire_school_pip_path)?,
                    ice: create_pip!(&settings.ice_school_pip_path)?,
                    life: create_pip!(&settings.life_school_pip_path)?,
                    myth: create_pip!(&settings.myth_school_pip_path)?,
                    storm: create_pip!(&settings.storm_school_pip_path)?,
                }
            },
        };
        
        Ok(Self {
            base_path: settings.assets_path.clone(),
            description_text,
            title_text,
            cost_images,
            frames: ImageCache::with_capacity(16),
            school_icons: ImageCache::with_capacity(16),
            type_icons: ImageCache::with_capacity(16),
            booster_icons: ImageCache::with_capacity(16),
            spell_images: ImageCache::with_capacity(16),
            cloak_icon: load_image!(path.join(&settings.cloak_icon), std::io::Error)?
                .resize(20, 20, FilterType::CatmullRom)
                .into_rgba8(),
            cloak_frame_icon: load_image!(path.join(&settings.cloak_frame_icon), std::io::Error)?
                .resize_exact(26, 27, FilterType::CatmullRom)
                .into_rgba8(),
            pvp_only_icon: load_image!(path.join(&settings.pvp_only_icon), std::io::Error)?
                .resize(30, 30, FilterType::CatmullRom)
                .into_rgba8(),
            pve_only_icon: load_image!(path.join(&settings.pve_only_icon), std::io::Error)?
                .resize(32, 32, FilterType::CatmullRom).into_rgba8(),
            banned_icon: load_image!(path.join(&settings.banned_icon), std::io::Error)?
                .resize(32, 32, FilterType::CatmullRom)
                .into_rgba8(),
            single_use_icon: load_image!(path.join(&settings.single_use_icon), std::io::Error)?
            .resize(
                32,
                32,
                FilterType::CatmullRom,
            ).into_rgba8(),
            single_use_icon_small: load_image!(path.join(&settings.single_use_icon), std::io::Error)?
            .resize(
                24,
                24,
                FilterType::CatmullRom,
            ).into_rgba8(),
            cannot_discard_icon: load_image!(path.join(&settings.cannot_discard_icon), std::io::Error)?
            .resize_exact(26, 28, FilterType::CatmullRom)
            .into_rgba8(),
            essence_collection_icon: load_image!(path.join(&settings.essence_collection_icon), std::io::Error)?
            .resize_exact(48, 49, FilterType::CatmullRom)
            .into_rgba8(),
            pierce_icon_path: settings.pierce_icon.clone(),
            pierce_frame_icon: {
                let mut img = load_image!(path.join(&settings.pierce_frame_icon), std::io::Error)?
                    .resize_exact(95 - 34, 125 - 95, FilterType::CatmullRom)
                    .into_rgba8();
                for pixel in img.pixels_mut() {
                    if pixel.0[0] <= 25 && pixel.0[1] <= 25 && pixel.0[2] <= 25 {
                        pixel.0 = [0, 0, 0, 0];
                    }
                }
                img
            },
            level_requirement_icon: load_image!(path.join(&settings.level_requirement_icon), std::io::Error)?
            .resize_exact(
                32,
                32,
                FilterType::CatmullRom,
            )
            .into_rgba8(),
            level_requirement_icon_small: load_image!(path.join(&settings.level_requirement_icon), std::io::Error)?
            .resize_exact(
                24,
                24,
                FilterType::CatmullRom,
            )
            .into_rgba8(),
            default_icon_size: settings.default_icon_size,
            default_wide_icon_size: settings.default_wide_icon_size,
            madlib_cache: if settings.cache_madlibs { Some(ImageCache::with_capacity(32)) } else { None },
        })
    }
    #[cfg(target_family = "wasm")]
    pub async fn new_async(settings: SpellFactorySettings) -> Result<Self> {
        let path = &settings.assets_path;
        let glyph_path = &settings.glyph_defs_path;
        let description_text = GlyphAtlas::open(settings.spell_description_font_path, glyph_path).await.wrap_err("Failed to generate glyph atlas for description.")?;
        let title_text = GlyphAtlas::open(settings.spell_title_font_path, glyph_path).await.wrap_err("Failed to generate glyph atlas for title.")?;
        // Yellow color for the pip cost text
        const PIP_COST_COLOR: Rgba<u8> = Rgba([243, 237, 70, 0]);
        let mut cost_number_images = std::array::from_fn(|_| RgbaImage::new(0, 0));
        for (rank_path, slot) in settings.rank_number_icons.iter().zip(cost_number_images.iter_mut()) {
            let path = path.join(rank_path);
            let mut image = load_image!(async, path.to_str().expect("Need to set message"), std::io::Error)?.into_rgba8();
            for pixel in image.pixels_mut() {
                if pixel.0[3] == 0 {
                    continue;
                }
                *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
            }
            *slot = image;
        }
        let cost_images = SpellCostImages {
            numbers: cost_number_images,
            x: {
                let path = path.join(&settings.rank_x_icon);
                let mut image = load_image!(async, path.to_str().expect("Need to set message"), std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            minus: {
                let path = path.join(&settings.rank_minus_icon);
                let mut image = load_image!(async, path.to_str().expect("Need to set message"), std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            plus: {
                let path = path.join(&settings.rank_plus_icon);
                let mut image = load_image!(async, path.to_str().expect("Need to set message"), std::io::Error)?.to_rgba8();
                for pixel in image.pixels_mut() {
                    if pixel.0[3] == 0 {
                        continue;
                    }
                    *pixel = recolour_pixel(*pixel, PIP_COST_COLOR, 0);
                }
                image
            },
            school_pips: {
                macro_rules! create_pip {
                    ($path:expr) => {{
                        let path = path.join($path);
                        SchoolPips::create_pip_async(&path).await.map_err(std::io::Error::other).wrap_err_with(|| format!("{:?}", path))
                    }};
                }
                SchoolPipImages {
                    shadow: SchoolPips::create_shadow_pip_async(path.join(&settings.shadow_school_pip_path), path.join(&settings.balance_school_pip_path)).await.map_err(std::io::Error::other)?,
                    balance: create_pip!(&settings.balance_school_pip_path)?,
                    death: create_pip!(&settings.death_school_pip_path)?,
                    fire: create_pip!(&settings.fire_school_pip_path)?,
                    ice: create_pip!(&settings.ice_school_pip_path)?,
                    life: create_pip!(&settings.life_school_pip_path)?,
                    myth: create_pip!(&settings.myth_school_pip_path)?,
                    storm: create_pip!(&settings.storm_school_pip_path)?,
                }
            },
        };

        Ok(Self {
            base_path: settings.assets_path.clone(),
            description_text,
            title_text,
            cost_images,
            frames: ImageCache::with_capacity(16),
            school_icons: ImageCache::with_capacity(16),
            type_icons: ImageCache::with_capacity(16),
            booster_icons: ImageCache::with_capacity(16),
            spell_images: ImageCache::with_capacity(16),
            cloak_icon: load_image!(async, path.join(&settings.cloak_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(20, 20, FilterType::CatmullRom)
                .into_rgba8(),
            cloak_frame_icon: load_image!(async, path.join(&settings.cloak_frame_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize_exact(26, 27, FilterType::CatmullRom)
                .into_rgba8(),
            pvp_only_icon: load_image!(async, path.join(&settings.pvp_only_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(30, 30, FilterType::CatmullRom)
                .into_rgba8(),
            pve_only_icon: load_image!(async, path.join(&settings.pve_only_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(32, 32, FilterType::CatmullRom).into_rgba8(),
            banned_icon: load_image!(async, path.join(&settings.banned_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(32, 32, FilterType::CatmullRom)
                .into_rgba8(),
            single_use_icon: load_image!(async, path.join(&settings.single_use_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(
                    32,
                    32,
                    FilterType::CatmullRom,
                ).into_rgba8(),
            single_use_icon_small: load_image!(async, path.join(&settings.single_use_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize(
                    24,
                    24,
                    FilterType::CatmullRom,
                ).into_rgba8(),
            cannot_discard_icon: load_image!(async, path.join(&settings.cannot_discard_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize_exact(26, 28, FilterType::CatmullRom)
                .into_rgba8(),
            essence_collection_icon: load_image!(async, path.join(&settings.essence_collection_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize_exact(48, 49, FilterType::CatmullRom)
                .into_rgba8(),
            pierce_icon_path: settings.pierce_icon.clone(),
            pierce_frame_icon: {
                let mut img = load_image!(async, path.join(&settings.pierce_frame_icon).to_str().expect("Need to set message"), std::io::Error)?
                    .resize_exact(95 - 34, 125 - 95, FilterType::CatmullRom)
                    .into_rgba8();
                for pixel in img.pixels_mut() {
                    if pixel.0[0] <= 25 && pixel.0[1] <= 25 && pixel.0[2] <= 25 {
                        pixel.0 = [0, 0, 0, 0];
                    }
                }
                img
            },
            level_requirement_icon: load_image!(async, path.join(&settings.level_requirement_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize_exact(
                    32,
                    32,
                    FilterType::CatmullRom,
                )
                .into_rgba8(),
            level_requirement_icon_small: load_image!(async, path.join(&settings.level_requirement_icon).to_str().expect("Need to set message"), std::io::Error)?
                .resize_exact(
                    24,
                    24,
                    FilterType::CatmullRom,
                )
                .into_rgba8(),
            default_icon_size: settings.default_icon_size,
            default_wide_icon_size: settings.default_wide_icon_size,
            madlib_cache: if settings.cache_madlibs { Some(ImageCache::with_capacity(32)) } else { None },
        })
    }
}

 fn generate_shadow(
        image: &RgbaImage,
        blur: f32,
        darkness: i32,
        offset: u32,
    ) -> RgbaImage {
        // Completely blacks out the image.
        let mut shadow = imageops::brighten(image, darkness);
        // Makes slightly more transparent.
        for pixel in shadow.pixels_mut() {
            *pixel = pixel.map_with_alpha(|f| f, |a| a.saturating_sub(10));
        }
        let shadow = DynamicImage::ImageRgba8(shadow);
        // Stretch the shadow.
        let shadow = shadow.resize_exact(
            shadow.width(),
            shadow.height() + offset,
            FilterType::Nearest,
        );
        // Finally blur it to remove hardness.
        shadow.blur(blur).into_rgba8()
    }
    
impl CardGenerator for CardFactory {
    fn base_path(&self) -> &Path {
        &self.base_path
    }

    fn description_text(&self) -> &GlyphAtlas {
        &self.description_text
    }

    fn title_text(&self) -> &GlyphAtlas {
        &self.title_text
    }

    fn cost_images(&self) -> &SpellCostImages {
        &self.cost_images
    }

    fn school_icons(&self) -> &ImageCache {
        &self.school_icons
    }

    fn type_icons(&self) -> &ImageCache {
        &self.type_icons
    }

    fn booster_icons(&self) -> &ImageCache {
        &self.booster_icons
    }

    fn frames(&self) -> &ImageCache {
        &self.frames
    }

    fn spell_images(&self) -> &ImageCache {
        &self.spell_images
    }

    fn cloak_icon(&self) -> &RgbaImage {
        &self.cloak_icon
    }

    fn cloak_frame_icon(&self) -> &RgbaImage {
        &self.cloak_frame_icon
    }

    fn pvp_only_icon(&self) -> &RgbaImage {
        &self.pvp_only_icon
    }

    fn pve_only_icon(&self) -> &RgbaImage {
        &self.pve_only_icon
    }

    fn banned_icon(&self) -> &RgbaImage {
        &self.banned_icon
    }

    fn single_use_icon_small(&self) -> &RgbaImage {
        &self.single_use_icon_small
    }

    fn single_use_icon(&self) -> &RgbaImage {
        &self.single_use_icon
    }

    fn cannot_discard_icon(&self) -> &RgbaImage {
        &self.cannot_discard_icon
    }

    fn essence_collection_icon(&self) -> &RgbaImage {
        &self.essence_collection_icon
    }

    fn pierce_icon_path(&self) -> &Path {
        &self.pierce_icon_path
    }

    fn pierce_frame_icon(&self) -> &RgbaImage {
        &self.pierce_frame_icon
    }

    fn level_requirement_icon(&self) -> &RgbaImage {
        &self.level_requirement_icon
    }

    fn level_requirement_icon_small(&self) -> &RgbaImage {
        &self.level_requirement_icon_small
    }

    fn madlib_cache(&self) -> Option<&ImageCache<SizedImagePath>> {
        self.madlib_cache.as_ref()
    }

    fn default_icon_size(&self) -> (u32, u32) {
        self.default_icon_size
    }

    fn default_wide_icon_size(&self) -> (u32, u32) {
        self.default_wide_icon_size
    }
}

#[derive(Debug, Clone, Copy, Default)]
pub enum AccuracyPosition {
    #[default]
    Base,
    Alternative
}

pub trait CardGenerator {
    const CARD_HEIGHT: u32 = 196;
    const TRUE_CARD_HEIGHT: u32 = 256;
    const CARD_WIDTH: u32 = 128;
    const DEFAULT_SPELL_IMG_CENTRED_X: i64 = 0;
    const DEFAULT_SPELL_IMG_CENTRED_Y: i64 = 9;
    const ALT_SPELL_IMG_CENTRED_X: i64 = 0;
    const ALT_SPELL_IMG_CENTRED_Y: i64 = 17;
    const SNACK_SPELL_IMG_CENTRED_X: i64 = 14;
    const SNACK_SPELL_IMG_CENTRED_Y: i64 = 23;
    const COST_CENTRE_X: i64 = 18;
    const COST_CENTRE_Y: i64 = 46;
    const SCHOOL_CENTRE_X: i64 = 112;
    const SCHOOL_CENTRE_Y: i64 = 51;
    const TYPE_CENTRE_X: i64 = 113;
    const TYPE_CENTRE_Y: i64 = 123;
    const BASE_ACCURACY_CENTRE_X: i64 = 16;
    const BASE_ACCURACY_CENTRE_Y: i64 = 111;
    const ALTERNATIVE_ACCURACY_CENTRE_X: i64 = 15;
    const ALTERNATIVE_ACCURACY_CENTRE_Y: i64 = 109;
    //TODO: Have accuracy position for energy spells.
    const DEFAULT_SPELL_IMG_WIDTH: u32 = 128;
    const DEFAULT_SPELL_IMG_HEIGHT: u32 = 128;
    const SNACK_SPELL_IMG_WIDTH: u32 = 100;
    const SNACK_SPELL_IMG_HEIGHT: u32 = 100;

    fn base_path(&self) -> &Path;
    fn description_text(&self) -> &GlyphAtlas;
    fn title_text(&self) -> &GlyphAtlas;
    fn cost_images(&self) -> &SpellCostImages;
    fn school_icons(&self) -> &ImageCache;
    fn type_icons(&self) -> &ImageCache;
    fn booster_icons(&self) -> &ImageCache;
    fn frames(&self) -> &ImageCache;
    fn spell_images(&self) -> &ImageCache;
    fn cloak_icon(&self) -> &RgbaImage;
    fn cloak_frame_icon(&self) -> &RgbaImage;
    fn pvp_only_icon(&self) -> &RgbaImage;
    fn pve_only_icon(&self) -> &RgbaImage;
    fn banned_icon(&self) -> &RgbaImage;
    fn single_use_icon_small(&self) -> &RgbaImage;
    fn single_use_icon(&self) -> &RgbaImage;
    fn cannot_discard_icon(&self) -> &RgbaImage;
    fn essence_collection_icon(&self) -> &RgbaImage;
    fn pierce_icon_path(&self) -> &Path;
    fn pierce_frame_icon(&self) -> &RgbaImage;
    fn level_requirement_icon(&self) -> &RgbaImage;
    fn level_requirement_icon_small(&self) -> &RgbaImage;
    fn madlib_cache(&self) -> Option<&ImageCache<SizedImagePath>>;
    fn default_icon_size(&self) -> (u32, u32);
    fn default_wide_icon_size(&self) -> (u32, u32);
    #[cfg(not(target_family = "wasm"))]
    fn generate(&self, card_data: &SpellCard) -> Result<RgbaImage> {
        //Create a empty image as a buffer.
        let mut img = image::RgbaImage::new(Self::CARD_WIDTH, Self::CARD_HEIGHT);
        if let Some(spell_image) = &card_data.spell_image {
            let mut spell_img = load_image!(self.base_path().join(spell_image))?;
            let width = if card_data.spell_image_size == SpellImageSize::Snack {
                    Self::SNACK_SPELL_IMG_WIDTH
                } else {
                    Self::DEFAULT_SPELL_IMG_WIDTH
                };
                let height = if card_data.spell_image_size == SpellImageSize::Snack {
                    Self::SNACK_SPELL_IMG_HEIGHT
                } else {
                    Self::DEFAULT_SPELL_IMG_HEIGHT
                };
                if spell_img.width() != width || spell_img.height() != height {
                    spell_img = spell_img.resize_exact(width, height, FilterType::Nearest);
                }
                let mut spell_img = spell_img.into_rgba8();

            let mask = if card_data.spell_image_size == SpellImageSize::Snack {
                &*SNACK_EMPTY_SPELL_IMAGE
            } else {
                &*EMPTY_SPELL_IMAGE
            };

             // Apply a pixel mask to avoid bleeding.
                for (pixel, mask_pixel) in spell_img.pixels_mut().zip(mask.pixels()) {
                    pixel.0[3] = pixel.0[3].min(mask_pixel.0[3]);
                }

            //Add the spell image.
            overlay(
                    &mut img,
                    &spell_img,
                    if card_data.spell_image_size == SpellImageSize::Snack {
                        Self::SNACK_SPELL_IMG_CENTRED_X
                    } else if card_data.spell_image_size == SpellImageSize::Alt {
                        Self::ALT_SPELL_IMG_CENTRED_X
                    } else {
                        Self::DEFAULT_SPELL_IMG_CENTRED_X
                    },
                    if card_data.spell_image_size == SpellImageSize::Snack {
                        Self::SNACK_SPELL_IMG_CENTRED_Y
                    } else if card_data.spell_image_size == SpellImageSize::Alt {
                        Self::ALT_SPELL_IMG_CENTRED_Y
                    } else {
                        Self::DEFAULT_SPELL_IMG_CENTRED_Y
                    },
                );
        }

        if let Some(additional_spell_images) = &card_data.additional_spell_images_lower {
            for img_path in additional_spell_images.iter() {
                const SPELL_IMG_CENTER: u32 = CardFactory::CARD_WIDTH / 2;
                let mut spell_img = load_image!(self.base_path().join(img_path))?;
                 if spell_img.width() != 86 || spell_img.height() != 86 {
                    spell_img = spell_img.resize_exact(86, 86, Nearest);
                }
                overlay(&mut img, &spell_img, (SPELL_IMG_CENTER - (spell_img.width() / 2)) as i64, 78 - (spell_img.height() / 2) as i64);
            }
        }

        self.add_frame(card_data, &mut img).wrap_err("Failed to add frame")?;

        if let Some(additional_spell_images) = &card_data.additional_spell_images_upper {
            for img_path in additional_spell_images.iter() {
                const SPELL_IMG_CENTER: u32 = CardFactory::CARD_WIDTH / 2;
                let mut spell_img = load_image!(self.base_path().join(img_path))?;
                 if spell_img.width() != 86 || spell_img.height() != 86 {
                    spell_img = spell_img.resize_exact(86, 86, Nearest);
                }
                overlay(&mut img, &spell_img, (SPELL_IMG_CENTER - (spell_img.width() / 2)) as i64, 78 - (spell_img.height() / 2) as i64);
            }
        }

        let cost_width = self.add_pip_cost(card_data, &mut img)
            .wrap_err("Failed to add pip cost")?;

        self.add_school_pips(cost_width, card_data, &mut img);

        self.add_school_icon(card_data, &mut img)
            .wrap_err("Failed to add school icon")?;

        self.add_type_icon(card_data, &mut img)
            .wrap_err("Failed to add type icon")?;

        self.add_spell_title(card_data, &mut img)
            .wrap_err("Failed to add spell title")?;

        self.add_accuracy(card_data, &mut img)
            .wrap_err("Failed to add accuracy")?;

        self.add_description(card_data, &mut img)
            .wrap_err("Failed to add description")?;

        self.add_booster(card_data, &mut img)
            .wrap_err("Failed to add booster")?;

        self.add_pierce(card_data, &mut img)
            .wrap_err("Failed to add pierce")?;

        self.add_cloaked(card_data, &mut img)
            .wrap_err("Failed to add cloaked")?;

        self.add_essence_collection(card_data, &mut img)
            .wrap_err("Failed to add essence collection")?;

        self.add_no_pve(card_data, &mut img)
            .wrap_err("Failed to add no pve")?;

        self.add_no_pvp(card_data, &mut img)
            .wrap_err("Failed to add no pvp")?;

        self.add_no_pvp_or_pve(card_data, &mut img)
            .wrap_err("Failed to add no pvp or pve")?;

        self.add_single_use(card_data, &mut img)
            .wrap_err("Failed to add single use")?;

        if !card_data.no_pvp {
            self.add_level_requirement(card_data, &mut img)
                .wrap_err("Failed to add level requirement")?;
        }

        if card_data.booster_pack.is_none() {
            self.add_no_discard(card_data, &mut img)
                .wrap_err("Failed to add no discard")?;
        }

        Ok(img)
    }
    #[cfg(target_family = "wasm")]
    async fn generate_async(&self, card_data: &SpellCard) -> Result<RgbaImage> {
        //Create a empty image as a buffer.
        let mut img = image::RgbaImage::new(Self::CARD_WIDTH, Self::CARD_HEIGHT);
        if let Some(spell_image) = &card_data.spell_image {
            self.spell_images().scoped_get_or_insert_with_async::<_, fn(&RgbaImage), _>(spell_image, async || {
                let mut spell_img = load_image!(async, self.base_path().join(spell_image).to_str().expect("Need to set message"))?;
                let width = if card_data.spell_image_size == SpellImageSize::Snack {
                    Self::SNACK_SPELL_IMG_WIDTH
                } else {
                    Self::DEFAULT_SPELL_IMG_WIDTH
                };
                let height = if card_data.spell_image_size == SpellImageSize::Snack {
                    Self::SNACK_SPELL_IMG_HEIGHT
                } else {
                    Self::DEFAULT_SPELL_IMG_HEIGHT
                };
                if spell_img.width() != width || spell_img.height() != height {
                    spell_img = spell_img.resize_exact(width, height, FilterType::Nearest);
                }
                let mut spell_img = spell_img.into_rgba8();

                let mask = if card_data.spell_image_size == SpellImageSize::Snack {
                    &*SNACK_EMPTY_SPELL_IMAGE
                } else {
                    &*EMPTY_SPELL_IMAGE
                };

             // Apply a pixel mask to avoid bleeding.
                for (pixel, mask_pixel) in spell_img.pixels_mut().zip(mask.pixels()) {
                    pixel.0[3] = pixel.0[3].min(mask_pixel.0[3]);
                }
                Ok(spell_img)
            }, |spell_img| {
                //Add the spell image.
                overlay(
                    &mut img,
                    spell_img,
                    if card_data.spell_image_size == SpellImageSize::Snack {
                        Self::SNACK_SPELL_IMG_CENTRED_X
                    } else if card_data.spell_image_size == SpellImageSize::Alt {
                        Self::ALT_SPELL_IMG_CENTRED_X
                    } else {
                        Self::DEFAULT_SPELL_IMG_CENTRED_X
                    },
                    if card_data.spell_image_size == SpellImageSize::Snack {
                        Self::SNACK_SPELL_IMG_CENTRED_Y
                    } else if card_data.spell_image_size == SpellImageSize::Alt {
                        Self::ALT_SPELL_IMG_CENTRED_Y
                    } else {
                        Self::DEFAULT_SPELL_IMG_CENTRED_Y
                    },
                );
            }).await?;
        }

        if let Some(additional_spell_images) = &card_data.additional_spell_images_lower {
            for img_path in additional_spell_images.iter() {
                const SPELL_IMG_CENTER: u32 = CardFactory::CARD_WIDTH / 2;
                let mut spell_img = load_image!(async, self.base_path().join(img_path).to_str().expect("Need to set message"))?;
                if spell_img.width() != 86 || spell_img.height() != 86 {
                    spell_img = spell_img.resize_exact(86, 86, Nearest);
                }
                overlay(&mut img, &spell_img, (SPELL_IMG_CENTER - (spell_img.width() / 2)) as i64, 78 - (spell_img.height() / 2) as i64);
            }
        }

        self.add_frame(card_data, &mut img).await.wrap_err("Failed to add frame")?;

        if let Some(additional_spell_images) = &card_data.additional_spell_images_upper {
            for img_path in additional_spell_images.iter() {
                const SPELL_IMG_CENTER: u32 = CardFactory::CARD_WIDTH / 2;
                let mut spell_img = load_image!(async, self.base_path().join(img_path).to_str().expect("Need to set message"))?;
                if spell_img.width() != 86 || spell_img.height() != 86 {
                    spell_img = spell_img.resize_exact(86, 86, Nearest);
                }
                overlay(&mut img, &spell_img, (SPELL_IMG_CENTER - (spell_img.width() / 2)) as i64, 78 - (spell_img.height() / 2) as i64);
            }
        }

        let cost_width = self.add_pip_cost(card_data, &mut img)
            .wrap_err("Failed to add pip cost")?;

        self.add_school_pips(cost_width, card_data, &mut img);

        self.add_school_icon_async(card_data, &mut img).await
            .wrap_err("Failed to add school icon")?;

        self.add_type_icon_async(card_data, &mut img).await
            .wrap_err("Failed to add type icon")?;

        self.add_spell_title(card_data, &mut img)
            .wrap_err("Failed to add spell title")?;

        self.add_accuracy(card_data, &mut img)
            .wrap_err("Failed to add accuracy")?;

        self.add_description(card_data, &mut img).await
            .wrap_err("Failed to add description")?;

        self.add_booster_async(card_data, &mut img).await
            .wrap_err("Failed to add booster")?;

        self.add_pierce(card_data, &mut img).await
            .wrap_err("Failed to add pierce")?;

        self.add_cloaked(card_data, &mut img)
            .wrap_err("Failed to add cloaked")?;

        self.add_essence_collection(card_data, &mut img)
            .wrap_err("Failed to add essence collection")?;

        self.add_no_pve(card_data, &mut img)
            .wrap_err("Failed to add no pve")?;

        self.add_no_pvp(card_data, &mut img)
            .wrap_err("Failed to add no pvp")?;

        self.add_no_pvp_or_pve(card_data, &mut img)
            .wrap_err("Failed to add no pvp or pve")?;

        self.add_single_use(card_data, &mut img)
            .wrap_err("Failed to add single use")?;

        if !card_data.no_pvp {
            self.add_level_requirement(card_data, &mut img).await
                .wrap_err("Failed to add level requirement")?;
        }

        if card_data.booster_pack.is_none() {
            self.add_no_discard(card_data, &mut img)
                .wrap_err("Failed to add no discard")?;
        }

        Ok(img)
    }

    #[cfg(not(target_family = "wasm"))]
    fn add_frame(&self, card_data: &SpellCard, img: &mut ImageBuffer<Rgba<u8>, Vec<u8>>) -> Result<(), eyre::Error> {
        if let Some(frame) = &card_data.frame {
            self.frames().scoped_get_or_insert_with::<_, fn(&RgbaImage)>(frame, || {
                let mut spell_frame = load_image!(self.base_path().join(frame))?;
                if spell_frame.width() != Self::CARD_WIDTH || spell_frame.height() != Self::TRUE_CARD_HEIGHT {
                    spell_frame = spell_frame.resize_exact(Self::CARD_WIDTH, Self::TRUE_CARD_HEIGHT, FilterType::Nearest);
                }
                Ok(spell_frame.to_rgba8())
            }, |spell_frame| {
                // Add the frame.
                overlay(img, spell_frame, 0, 0);
            })?;
        };
        Ok(())
    }

    #[cfg(target_family = "wasm")]
    async fn add_frame(&self, card_data: &SpellCard, img: &mut ImageBuffer<Rgba<u8>, Vec<u8>>) -> Result<(), eyre::Error> {
        Ok(if let Some(frame) = &card_data.frame {
            self.frames().scoped_get_or_insert_with_async::<_, fn(&RgbaImage), _>(frame, async || {
                let mut spell_frame = load_image!(async, self.base_path().join(frame).to_str().expect("Need to set message"))?;
                if spell_frame.width() != Self::CARD_WIDTH || spell_frame.height() != Self::TRUE_CARD_HEIGHT {
                    spell_frame = spell_frame.resize_exact(Self::CARD_WIDTH, Self::TRUE_CARD_HEIGHT, FilterType::Nearest);
                }
                Ok(spell_frame.to_rgba8())
            }, |spell_frame| {
                overlay(img, spell_frame, 0, 0);
            }).await?;
        })
    }
    fn add_spell_title(&self, card_data: &SpellCard, img: &mut RgbaImage) -> std::result::Result<(), ImageError> {
        if card_data.title.is_empty() {
            return Ok(());
        }
        let mut title = self.title_text().generate_text(&card_data.title);
        if card_data.title_size == TitleSize::Alt {
            title = resize(&title, (title.width() as f32 * 0.94) as u32, (title.height() as f32 * 0.94) as u32, FilterType::Gaussian);
        }
        let shadow = generate_shadow(&title, 0.5, -255, 4);
        overlay(
            img,
            &shadow,
            2 + ((Self::CARD_WIDTH / 2) as i64 - (title.width() / 2) as i64),
            8,
        );
        overlay(
            img,
            &title,
            (Self::CARD_WIDTH / 2) as i64 - (title.width() / 2) as i64,
            8,
        );
        Ok(())
    }

    /// Applies the card's pip cost to the upper left section of the card.
    fn add_pip_cost(&self, card_data: &SpellCard, img: &mut RgbaImage) -> std::result::Result<u32, ImageError> {
        let Some(cost) = card_data.cost else { return Ok(0); };
        let base_cost = cost.base_cost.clamp(-20, 20);
        let is_variable_cost = cost.variable_cost;
        let cost_img = &self.cost_images().numbers[base_cost.unsigned_abs() as usize];
        let (cost_width, cost_height) = cost_img.dimensions();

        //Add the pip cost.
        let width = if is_variable_cost {
            let x_cost = &self.cost_images().x;
            let (x_width, x_height) = x_cost.dimensions();
            match cost.base_cost {
                0 => {
                    overlay(
                        img,
                        x_cost,
                        Self::COST_CENTRE_X - (x_width as i64 / 2),
                        Self::COST_CENTRE_Y - (x_height as i64),
                    );
                    x_width
                }
                v if v < 0 => {
                    let minus_cost = &self.cost_images().minus;
                    let (minus_width, minus_height) = minus_cost.dimensions();
                    let width = cost_width + minus_width - 1 + x_width - 2;
                    let height = cost_height.max(minus_height).max(x_height);
                    let mut rank = image::DynamicImage::new_rgba8(width, height);

                    overlay(&mut rank, x_cost, 0, 0);
                    overlay(&mut rank, minus_cost, (x_width - 2) as i64, 0);
                    overlay(
                        &mut rank,
                        cost_img,
                        (x_width + minus_width - 4) as i64,
                        0,
                    );

                    overlay(
                        img,
                        &rank,
                        (Self::COST_CENTRE_X - (width as i64 / 2)).max(2),
                        Self::COST_CENTRE_Y - (height as i64),
                    );
                    width
                }
                v if v > 0 => {
                    let plus_cost = &self.cost_images().plus;
                    let (plus_width, plus_height) = plus_cost.dimensions();
                    let width = x_width + plus_width - 1 + cost_width - 2;
                    let height = cost_height.max(plus_height).max(x_height);
                    let mut rank = image::DynamicImage::new_rgba8(width, height);

                    overlay(&mut rank, cost_img, 0, 0);
                    overlay(&mut rank, plus_cost, (cost_width - 2) as i64, 0);
                    overlay(&mut rank, x_cost, (cost_width + plus_width - 4) as i64, 0);

                    overlay(
                        img,
                        &rank,
                        (Self::COST_CENTRE_X - (width as i64 / 2)).max(2),
                        Self::COST_CENTRE_Y - (height as i64),
                    );
                    width
                }
                // This literally cannot happen, but we need to satisfy the compiler: top branches: v < 0, v > 0, v == 0
                _ => panic!("Somehow hit an impossible branch in pip cost rendering."),
            }
        } else {
            overlay(
                img,
                cost_img,
                Self::COST_CENTRE_X - (cost_width as i64 / 2),
                Self::COST_CENTRE_Y - (cost_height as i64),
            );
            cost_width
        };

        Ok(width)
    }

    #[cfg(not(target_arch = "wasm32"))]
    /// Applies the card's school to the upper right section of the card.
    fn add_school_icon(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(path) = &card_data.school_icon else {
            return Ok(());
        };

        self.school_icons().scoped_get_or_insert_with::<_, fn(&RgbaImage)>(path, || {
            Ok(load_image!(self.base_path().join(path))?
                .resize_exact(22, 22, FilterType::Gaussian).into_rgba8())
        }, |school_icon| {
            let (school_width, school_height) = school_icon.dimensions();
            overlay(
                img,
                school_icon,
                Self::SCHOOL_CENTRE_X - (school_width as i64 / 2),
                Self::SCHOOL_CENTRE_Y - (school_height as i64),
            );
        })
    }

    #[cfg(target_family = "wasm")]
    async fn add_school_icon_async(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(path) = &card_data.school_icon else {
            return Ok(());
        };

        self.school_icons().scoped_get_or_insert_with_async::<_, fn(&RgbaImage), _>(path, async || {
            Ok(load_image!(async, self.base_path().join(path).to_str().expect("Need to set message"))?
                .resize_exact(22, 22, FilterType::Gaussian).into_rgba8())
        }, |school_icon| {
            let (school_width, school_height) = school_icon.dimensions();
            overlay(
                img,
                school_icon,
                Self::SCHOOL_CENTRE_X - (school_width as i64 / 2),
                Self::SCHOOL_CENTRE_Y - (school_height as i64),
            );
        }).await
    }

    #[cfg(not(target_arch = "wasm32"))]
    /// Applies the card's type to the bottom right section of the card.
    fn add_type_icon(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(path) = &card_data.type_icon else {
            return Ok(());
        };
        self.type_icons().scoped_get_or_insert_with::<_, fn(&RgbaImage)>(path, || {
            Ok(load_image!(self.base_path().join(path))?
                .resize_exact(22, 22, FilterType::Gaussian).into_rgba8())
        }, |type_icon| {
            let (type_width, type_height) = type_icon.dimensions();
            overlay(
                img,
                type_icon,
                Self::TYPE_CENTRE_X - (type_width as i64 / 2),
                Self::TYPE_CENTRE_Y - (type_height as i64),
            );
        })?;

        Ok(())
    }

    #[cfg(target_family = "wasm")]
    async fn add_type_icon_async(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(path) = &card_data.type_icon else {
            return Ok(());
        };
        self.type_icons().scoped_get_or_insert_with_async::<_, fn(&RgbaImage), _>(path, async || {
            Ok(load_image!(async, self.base_path().join(path).to_str().expect("Need to set message"))?
                .resize_exact(22, 22, FilterType::Gaussian).into_rgba8())
        }, |type_icon| {
            let (type_width, type_height) = type_icon.dimensions();
            overlay(
                img,
                type_icon,
                Self::TYPE_CENTRE_X - (type_width as i64 / 2),
                Self::TYPE_CENTRE_Y - (type_height as i64),
            );
        }).await?;

        Ok(())
    }

    fn add_accuracy(&self, card_data: &SpellCard, img: &mut RgbaImage) -> std::result::Result<(), ImageError> {
        if card_data.accuracy.is_empty() {
            return Ok(());
        }
        let font_atlas = &self.description_text();
        let mut text = font_atlas.generate_text(&card_data.accuracy);

        let position = match card_data.accuracy_position {
            AccuracyPosition::Alternative => (Self::ALTERNATIVE_ACCURACY_CENTRE_X, Self::ALTERNATIVE_ACCURACY_CENTRE_Y),
            AccuracyPosition::Base => (Self::BASE_ACCURACY_CENTRE_X, Self::BASE_ACCURACY_CENTRE_Y),
        };

        let mut x = position.0 - (text.width() / 2) as i64;
        let y = position.1 - (text.height() / 2) as i64;
        if card_data.accuracy_bolding {
            let shadow = generate_shadow(&text, 0.75, -240, 0);
            overlay(img, &shadow, 2 + x, y + 2);
        }

        if (text.width() / 2) as i64 > position.0 {
            x += (text.width() / 2) as i64 % position.0;
        }

        // Yellow
        let colour = card_data.accuracy_colour.unwrap_or([246, 232, 1, 255]);

        for pixel in text.pixels_mut() {
            pixel.0 = [colour[0], colour[1], colour[2], pixel.0[3]];
        }

        overlay(img, &text, x, y);
        Ok(())
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn add_description(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.description.is_empty() {
            return Ok(());
        }
        let font_atlas = &self.description_text();

        let rect = Rect {
            x: 5,
            y: 128,
            width: 114, //114 originally (needs tests)
            height: 66,
        };
        let text_box: RichTextBox<'_> = RichTextBox::new(&self.base_path(), card_data.description.trim_start().to_string(), card_data.description_alignment, font_atlas, rect, true, if card_data.legacy_madlib_sizes { (20, 20) } else { self.default_icon_size() }, if card_data.legacy_madlib_sizes { (20, 40) } else { self.default_wide_icon_size() }, self.madlib_cache());
        let description = text_box
            .generate_image(1)
            .wrap_err("Failed to generate description")?;
        overlay(img, &description, rect.x as i64, rect.y as i64);
        Ok(())
    }

    #[cfg(target_family = "wasm")]
    async fn add_description(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.description.is_empty() {
            return Ok(());
        }
        let font_atlas = &self.description_text();

        let rect = Rect {
            x: 5,
            y: 128,
            width: 114, //114 originally (needs tests)
            height: 66,
        };
        let text_box = RichTextBox::new(&self.base_path(), card_data.description.to_string(), card_data.description_alignment, font_atlas, rect, true, self.default_icon_size(), self.default_wide_icon_size(), self.madlib_cache());
        let description = text_box
            .generate_image(1).await
            .wrap_err("Failed to generate description")?;
        overlay(img, &description, rect.x as i64, rect.y as i64);
        Ok(())
    }

    fn add_cloaked(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.cloaked {
            let frame = self.cloak_frame_icon();
            let cloak_icon = self.cloak_icon();

            overlay(img, frame, 52, 100);
            overlay(img, cloak_icon, 55, 103);
        }
        Ok(())
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn add_booster(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(booster_icon) = &card_data.booster_pack else {
            return Ok(());
        };
        const X: i64 = 1;
        const Y: i64 = 61;
        self.booster_icons().scoped_get_or_insert_with::<_, fn(&RgbaImage)>(booster_icon, || {
            Ok(load_image!(self.base_path().join(booster_icon))?
                .resize_exact(32, 32, FilterType::CatmullRom).into_rgba8())
        }, |booster_icon| {
            overlay(img, booster_icon, X, Y);
        })?;
        Ok(())
    }

    #[cfg(target_family = "wasm")]
    async fn add_booster_async(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        let Some(booster_icon) = &card_data.booster_pack else {
            return Ok(());
        };
        const X: i64 = 1;
        const Y: i64 = 61;
        self.booster_icons().scoped_get_or_insert_with_async::<_, fn(&RgbaImage), _>(booster_icon, async || {
            Ok(load_image!(async, self.base_path().join(booster_icon).to_str().wrap_err_with(||"Not a valid path").expect("Need to set message"))?
                .resize_exact(32, 32, FilterType::CatmullRom).into_rgba8())
        }, |booster_icon| {
            overlay(img, booster_icon, X, Y);
        }).await?;
        Ok(())
    }

    fn add_no_pve(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.no_pve && !card_data.no_pvp {
            let no_pve_icon = self.pvp_only_icon();

            overlay(img, no_pve_icon, 50, 98);
        }
        Ok(())
    }

    fn add_no_pvp(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.no_pvp && !card_data.no_pve {
            let no_pvp_icon = self.pve_only_icon();

            overlay(img, no_pvp_icon, 49, 97);
        }
        Ok(())
    }

    fn add_no_pvp_or_pve(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.no_pvp && card_data.no_pve {
            let banned_icon = self.banned_icon();

            overlay(img, banned_icon, 49, 97);
        }
        Ok(())
    }

    fn add_single_use(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.single_use {
            let sharing_space = !card_data.no_pvp && card_data.level_requirement > 0;
            let single_use_icon = if sharing_space {
                self.single_use_icon_small()
            } else {
                self.single_use_icon()
            };

            overlay(
                img,
                single_use_icon,
                if sharing_space { 101 } else { 96 },
                if sharing_space { 59 - 9 } else { 59 },
            );
        }
        Ok(())
    }

    fn add_essence_collection(
        &self, card_data: &SpellCard, img: &mut RgbaImage
    ) -> Result<()> {
        if card_data.essence_collection {
            let monster_magic_icon = self.essence_collection_icon();

            overlay(img, monster_magic_icon, 41, 79);
        }
        Ok(())
    }

    fn add_no_discard(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.cannot_discard {
            let no_discard_icon = self.cannot_discard_icon();

            overlay(img, no_discard_icon, 0, 68);
        }
        Ok(())
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn add_pierce(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.pierce != 0 {
            let pierce = card_data.pierce;
            let frame = self.pierce_frame_icon();

            overlay(img, frame, 35, 97);

            let font_atlas = &self.description_text();
            let rect = Rect {
                x: 40,
                y: 99,
                width: 90 - 40,
                height: 125 - 100,
            };
            let text_box = RichTextBox::new(
                self.base_path(),
                format!("{pierce}% $img:{}:16x16$", self.pierce_icon_path().display()),
                TextAlignment::Center,
                font_atlas,
                rect,
                false,
                self.default_icon_size(),
                self.default_wide_icon_size(),
                self.madlib_cache()
            );
            let description = text_box.generate_image(5)?;
            overlay(img, &description, rect.x as i64, rect.y as i64);
        }
        Ok(())
    }

    #[cfg(target_arch = "wasm32")]
    async fn add_pierce(&self, card_data: &SpellCard, img: &mut RgbaImage) -> Result<()> {
        if card_data.pierce != 0 {
            let pierce = card_data.pierce;
            let frame = self.pierce_frame_icon();

            overlay(img, frame, 35, 97);

            let font_atlas = &self.description_text();
            let rect = Rect {
                x: 40,
                y: 99,
                width: 90 - 40,
                height: 125 - 100,
            };
            let text_box = RichTextBox::new(
                self.base_path(),
                format!("{pierce}% $img:{}:16x16$", self.pierce_icon_path().display()),
                TextAlignment::Center,
                font_atlas,
                rect,
                false,
                self.default_icon_size(),
                self.default_wide_icon_size(),
                self.madlib_cache()
            );
            let description = text_box.generate_image(5).await?;
            overlay(img, &description, rect.x as i64, rect.y as i64);
        }
        Ok(())
    }

    #[cfg(not(target_arch = "wasm32"))]
    fn add_level_requirement(
        &self, card_data: &SpellCard, img: &mut RgbaImage
    ) -> Result<()> {
        if card_data.level_requirement > 0 {
            let sharing_space = card_data.single_use;
            let frame = if !sharing_space {
                self.level_requirement_icon()
            } else {
                self.level_requirement_icon_small()
            };

            overlay(
                img,
                frame,
                if sharing_space { 100 } else { 96 },
                if sharing_space { 59 + 14 } else { 59 },
            );

            let font_atlas = &self.description_text();
            let rect = Rect {
                x: 95,
                y: 65 + if sharing_space { 10 } else { 0 },
                width: 32,
                height: 32,
            };
            let r = 246u8;
            let g = 232u8;
            let b = 1u8;
            let a = 255u8;
            let txt = format!(
                "$Color:{:02x}{:02x}{:02x}{:02x}${}",
                a, b, g, r, card_data.level_requirement
            );
            let text_box = RichTextBox::new(self.base_path(), txt, TextAlignment::Center, font_atlas, rect, false, self.default_icon_size(), self.default_wide_icon_size(), self.madlib_cache());
            let description = text_box.generate_image(4)?;
            overlay(img, &description, rect.x as i64, rect.y as i64);
        }
        Ok(())
    }

    #[cfg(target_arch = "wasm32")]
    async fn add_level_requirement(
        &self, card_data: &SpellCard, img: &mut RgbaImage
    ) -> Result<()> {
        if card_data.level_requirement > 0 {
            let sharing_space = card_data.single_use;
            let frame = if !sharing_space {
                self.level_requirement_icon()
            } else {
                self.level_requirement_icon_small()
            };

            overlay(
                img,
                frame,
                if sharing_space { 100 } else { 96 },
                if sharing_space { 59 + 14 } else { 59 },
            );

            let font_atlas = &self.description_text();
            let rect = Rect {
                x: 95,
                y: 65 + if sharing_space { 10 } else { 0 },
                width: 32,
                height: 32,
            };
            let r = 246u8;
            let g = 232u8;
            let b = 1u8;
            let a = 255u8;
            let txt = format!(
                "$Color:{:02x}{:02x}{:02x}{:02x}${}",
                a, b, g, r, card_data.level_requirement
            );
            let text_box = RichTextBox::new(self.base_path(), txt, TextAlignment::Center, font_atlas, rect, false, self.default_icon_size(), self.default_wide_icon_size(), self.madlib_cache());
            let description = text_box.generate_image(4).await?;
            overlay(img, &description, rect.x as i64, rect.y as i64);
        }
        Ok(())
    }

    fn add_school_pips(&self, mut cost_width: u32, card_data: &SpellCard, img: &mut RgbaImage) {
        let Some(cost) = card_data.cost else {
            return;
        };
        cost_width -= 4;
        let x = cost_width.max(25) as i64;
        let y = 24;
        let amount = cost.school_pips.total_pips();
        let gap = match amount {
            i if i < 4 => 20 + 2,
            i if i > 3 => 20 - 6,
            _ => panic!("Somehow hit an impossible branch"),
        };
        let mut i = 0;
        macro_rules! do_school_pips {
            ($school:ident) => {
                let amount = cost.school_pips.$school;
                let pip = &self.cost_images().school_pips.$school;
                for _ in 0..amount {
                    overlay(img, pip, x + (gap * i as i64), y);
                    i += 1;
                }
            }
        }
        // Order of the schools is important for the image generation.
        do_school_pips!(shadow);
        do_school_pips!(balance);
        do_school_pips!(death);
        do_school_pips!(fire);
        do_school_pips!(ice);
        do_school_pips!(life);
        do_school_pips!(myth);
        do_school_pips!(storm);
    }
}