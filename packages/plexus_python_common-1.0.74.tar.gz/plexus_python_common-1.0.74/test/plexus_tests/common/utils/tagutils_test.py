import datetime
import pathlib
import tempfile
import threading
import unittest

import ddt
from iker.common.utils.dtutils import dt_parse_iso
from iker.common.utils.iterutils import last
from iker.common.utils.jsonutils import JsonObject

from plexus.common.utils.tagutils import MutableTagset, Tag, TagCache, Tagset
from plexus.common.utils.tagutils import populate_clip_ranges
from plexus.common.utils.tagutils import predefined_tagsets, render_tagset_markdown_readme
from plexus.common.utils.tagutils import tag_cache_file_path
from plexus.common.utils.tagutils import versioned_identifier


@ddt.ddt
class TagUtilsTest(unittest.TestCase):

    def test_predefined_tagsets(self):
        tagsets = predefined_tagsets()
        for _, tagset in tagsets.items():
            self.assertIsInstance(tagset, Tagset)
            self.assertNotIsInstance(tagset, MutableTagset)

            for tag in tagset:
                self.assertIn(tag, tagset)
                self.assertIn(tag.name, tagset)
                self.assertEqual(tag, tagset.get(tag))
                self.assertEqual(tag.name, tagset.get_bound(tag).name)
                self.assertEqual(tag, tagset.get_bound(tag).unbind())

                if tag.parent_tag_name is not None:
                    self.assertIn(tag.parent_tag_name, tagset)
                    self.assertEqual(tag.parent_tag_name, tagset.get(tag.parent_tag_name).name)
                    self.assertEqual(last(tagset.parent_tags(tag)), tagset.get(tag.parent_tag_name))

                for child_tag in tagset.child_tags(tag):
                    self.assertIn(child_tag, tagset)
                    self.assertIn(child_tag.name, tagset)
                    self.assertIn(tag, tagset.parent_tags(child_tag))

            markdown = render_tagset_markdown_readme(tagset)
            self.assertIsInstance(markdown, str)

            print(markdown)

        self.assertEqual(predefined_tagsets().get("unittest"),
                         predefined_tagsets().get(versioned_identifier("unittest", "1.0.0")))

    data_tag_validate = [
        ("level_1_tag", {"dummy_property": "dummy_value"}, True,),

        # extra keys should not cause validation failure, as specified in the schema with
        # "additionalProperties": True
        ("level_1_tag", {"dummy_property": "dummy_value", "extra_key": True}, True,),

        # missing keys should not cause validation failure, as specified in the schema with "required": []
        ("level_1_tag", {"extra_key": True}, True,),

        # schema absence should not cause validation failure
        ("level_1_tag:level_2_tag", {"dummy_property": "dummy_value"}, True,),

        ("level_1_tag:another_level_2_tag", {"dummy_property": {"dummy_sub_property": "dummy_value"}}, True,),

        # extra keys in nested properties should cause validation failure, as specified in the schema with
        # "additionalProperties": False
        ("level_1_tag:another_level_2_tag",
         {"dummy_property": {"dummy_sub_property": "dummy_value", "extra_key": True}},
         False,),

        # bad type in nested properties should cause validation failure
        ("level_1_tag:another_level_2_tag",
         {"dummy_property": {"dummy_sub_property": 0}},
         False,),

        # at least one element should be present in the array, as specified in the schema with "minItems": 1
        ("another_level_1_tag", {"dummy_elements": []}, False,),

        # at most 3 elements should be present in the array, as specified in the schema with "maxItems": 3
        ("another_level_1_tag", {"dummy_elements": [1, 2, 3, 4, 5]}, False,),

        # integers in the array should be non-negative, as specified in the schema with "minimum": 0
        ("another_level_1_tag", {"dummy_elements": [-1]}, False,),
    ]

    @ddt.idata(data_tag_validate)
    @ddt.unpack
    def test_tagset_validate(self, tag: str, features: JsonObject, should_pass: bool):
        tagset = predefined_tagsets().get("unittest")

        if should_pass:
            self.assertTrue(tagset.validate(tag, features))
        else:
            self.assertFalse(tagset.validate(tag, features))
            with self.assertRaises(Exception):
                tagset.validate(tag, features, raise_on_error=True)

    def test_tag_cache(self):
        tag_names = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        tagset = MutableTagset(namespace="tagset", version="1.0.0", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags_count = len(tag_names)
        tagset_tags_count = sum(1 for tag_name in tag_names if tag_name in tagset)

        cache = TagCache()

        self.assertEqual(cache.file_path, tag_cache_file_path())
        self.assertTrue(cache.file_path.exists())

        cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                         "awesome_tagger",
                         "1.0.0",
                         "dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00+00:00"),
                         dt_parse_iso("2020-01-01T01:00:00+00:00"),
                         props={"dummy_target_prop": "dummy_value"})

        target_cache = cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

        tag_records_count = 1000

        for i in range(tag_records_count):
            tag_name = tag_names[i % len(tag_names)]
            tag = tagset.get_bound(tag_name) or tag_name
            target_cache.add_ranged_record(
                dt_parse_iso("2020-01-01T00:00:00+00:00") + datetime.timedelta(seconds=i),
                dt_parse_iso("2020-01-02T00:00:00+00:00") + datetime.timedelta(seconds=i + 1),
                tag,
                features={
                    "dummy_int": 1,
                    "dummy_float": 1.0e-1,
                    "dummy_bool": True,
                    "dummy_str": "dummy_string",
                    "dummy_list": [1, 1.0e-1, True, "dummy_string"],
                    "dummy_dict": {
                        "dummy_int": 1,
                        "dummy_float": 1.0e-1,
                        "dummy_bool": True,
                        "dummy_str": "dummy_string",
                    },
                },
                props={"dummy_record_prop": "dummy_value"},
            )

        self.assertEqual(target_cache.count_records(), tag_records_count)
        self.assertEqual(len(list(target_cache.iter_records())), tag_records_count)
        self.assertEqual(len(list(target_cache.iter_records(tagsets=[tagset]))),
                         tag_records_count * tagset_tags_count // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                         tag_records_count * (tags_count - tagset_tags_count) // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                         tag_records_count * tagset_tags_count // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                            dt_parse_iso("2020-01-01T00:01:00+00:00")))),
                         60 + 1)
        self.assertEqual(len(list(target_cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                            dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                            tag_prefix="dummy:foo"))),
                         60 // tags_count + 1)
        self.assertEqual(len(list(target_cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                            dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                            tag_prefix="dummy:bar"))),
                         60 // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                            dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                            tag_prefix="dummy"))),
                         60 + 1)
        self.assertEqual(len(list(target_cache.iter_records(tag_prefix="dummy:foo"))),
                         tag_records_count // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(tag_prefix="dummy:bar"))),
                         tag_records_count // tags_count)
        self.assertEqual(len(list(target_cache.iter_records(tag_prefix="dummy"))), tag_records_count)

        self.assertEqual(len(list(cache.iter_records())), tag_records_count)
        self.assertEqual(len(list(cache.iter_records(tagsets=[tagset]))), tag_records_count // 2)
        self.assertEqual(len(list(cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                         tag_records_count * (tags_count - tagset_tags_count) // tags_count)
        self.assertEqual(len(list(cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                         tag_records_count * tagset_tags_count // tags_count)
        self.assertEqual(len(list(cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                     dt_parse_iso("2020-01-01T00:01:00+00:00")))),
                         60 + 1)
        self.assertEqual(len(list(cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                     dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                     tag_prefix="dummy:foo"))),
                         60 // tags_count + 1)
        self.assertEqual(len(list(cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                     dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                     tag_prefix="dummy:bar"))),
                         60 // tags_count)
        self.assertEqual(len(list(cache.iter_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                     dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                     tag_prefix="dummy"))),
                         60 + 1)
        self.assertEqual(len(list(cache.iter_records(tag_prefix="dummy:foo"))), tag_records_count // tags_count)
        self.assertEqual(len(list(cache.iter_records(tag_prefix="dummy:bar"))), tag_records_count // tags_count)
        self.assertEqual(len(list(cache.iter_records(tag_prefix="dummy"))), tag_records_count)

        target_cache.remove_records(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                    dt_parse_iso("2020-01-01T00:01:00+00:00"))

        self.assertEqual(target_cache.count_records(), tag_records_count - (60 + 1))
        self.assertEqual(len(list(target_cache.iter_records())), tag_records_count - (60 + 1))
        self.assertEqual(cache.count_records(), tag_records_count - (60 + 1))
        self.assertEqual(len(list(cache.iter_records())), tag_records_count - (60 + 1))

        target_cache.remove_records(tagsets=[tagset], tagset_inverted=True)

        self.assertEqual(
            target_cache.count_records(),
            tag_records_count * tagset_tags_count // tags_count - (60 * tagset_tags_count // tags_count + 1),
        )
        self.assertEqual(
            len(list(target_cache.iter_records())),
            tag_records_count * tagset_tags_count // tags_count - (60 * tagset_tags_count // tags_count + 1),
        )
        self.assertEqual(
            cache.count_records(),
            tag_records_count * tagset_tags_count // tags_count - (60 * tagset_tags_count // tags_count + 1),
        )
        self.assertEqual(
            len(list(cache.iter_records())),
            tag_records_count * tagset_tags_count // tags_count - (60 * tagset_tags_count // tags_count + 1),
        )

        target_cache.remove_records()

        self.assertEqual(target_cache.count_records(), 0)
        self.assertEqual(len(list(target_cache.iter_records())), 0)
        self.assertEqual(cache.count_records(), 0)
        self.assertEqual(len(list(cache.iter_records())), 0)

    def test_tag_cache__multithread(self):
        tag_names = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        old_tagset = MutableTagset(namespace="tagset", version="1.0.0", desc="A dummy tagset for testing")
        old_tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        old_tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        new_tagset = MutableTagset(namespace="tagset", version="1.1.0", desc="Updated dummy tagset for testing")
        new_tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        new_tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))
        new_tagset.add(Tag(name="dummy:baz", desc="Updated dummy tag for testing"))
        new_tagset.remove("dummy:bar")

        tags_count = len(tag_names)
        tagset_tags_count = sum(1 for tag_name in tag_names if tag_name in old_tagset or tag_name in new_tagset)
        old_tagset_tags_count = sum(1 for tag_name in tag_names if tag_name in old_tagset)

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            cache = TagCache(file_path=temp_directory / "tag_cache.db")

            self.assertEqual(cache.file_path, temp_directory / "tag_cache.db")
            self.assertTrue(cache.file_path.exists())

            target_caches_count = 10

            for i in range(target_caches_count):
                cache.add_target(f"concurrent_tagger/20200101_000000/dummy_vehicle/{i}",
                                 f"concurrent_tagger/tagger_{i}",
                                 f"1.0.{i}",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"),
                                 props={"dummy_target_prop": "dummy_value"})

            target_caches = [cache.with_target(f"concurrent_tagger/20200101_000000/dummy_vehicle/{i}")
                             for i in range(target_caches_count)]

            threads_count_per_target_cache = 10
            tasks_count_per_thread = 100
            tasks_count_per_target_cache = threads_count_per_target_cache * tasks_count_per_thread
            total_threads_count = target_caches_count * threads_count_per_target_cache
            total_tasks_count = total_threads_count * tasks_count_per_thread

            start_barrier = threading.Barrier(total_threads_count)

            def worker(tid):
                target_cache = target_caches[tid % target_caches_count]

                start_barrier.wait()
                for i in range(tasks_count_per_thread):
                    tag_name = tag_names[i % len(tag_names)]
                    tag = old_tagset.get_bound(tag_name) or new_tagset.get_bound(tag_name) or tag_name
                    target_cache.add_ranged_record(
                        dt_parse_iso("2020-01-01T00:00:00+00:00") + datetime.timedelta(seconds=i),
                        dt_parse_iso("2020-01-02T00:00:00+00:00") + datetime.timedelta(seconds=i + 1),
                        tag,
                        features={
                            "dummy_int": 1,
                            "dummy_float": 1.0e-1,
                            "dummy_bool": True,
                            "dummy_str": "dummy_string",
                            "dummy_list": [1, 1.0e-1, True, "dummy_string"],
                            "dummy_dict": {
                                "dummy_int": 1,
                                "dummy_float": 1.0e-1,
                                "dummy_bool": True,
                                "dummy_str": "dummy_string",
                            },
                        },
                        props={"dummy_record_prop": "dummy_value"},
                    )

            threads = [threading.Thread(target=worker, args=(tid,)) for tid in range(total_threads_count)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()

            for target_cache in target_caches:
                self.assertEqual(target_cache.count_records(), tasks_count_per_target_cache)
                self.assertEqual(len(list(target_cache.iter_records())), tasks_count_per_target_cache)
                self.assertEqual(len(list(target_cache.iter_records(tag_prefix="dummy:bar"))),
                                 tasks_count_per_target_cache // tags_count)
                self.assertEqual(len(list(target_cache.iter_records(tagset_namespace="tagset"))),
                                 tasks_count_per_target_cache * tagset_tags_count // tags_count)
                self.assertEqual(
                    len(list(target_cache.iter_records(tagset_namespace="tagset", tagset_version="1.0.0"))),
                    tasks_count_per_target_cache * old_tagset_tags_count // tags_count,
                )

            self.assertEqual(cache.count_records(), total_tasks_count)
            self.assertEqual(len(list(cache.iter_record_and_targets())), total_tasks_count)
            self.assertEqual(len(list(cache.iter_record_and_targets(tag_prefix="dummy:bar"))),
                             total_tasks_count // tags_count)
            self.assertEqual(len(list(cache.iter_record_and_targets(tagset_namespace="tagset"))),
                             total_tasks_count * tagset_tags_count // tags_count)
            self.assertEqual(
                len(list(cache.iter_record_and_targets(tagset_namespace="tagset", tagset_version="1.0.0"))),
                total_tasks_count * old_tagset_tags_count // tags_count,
            )

    def test_tag_cache__clone(self):
        tag_names = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        tagset = MutableTagset(namespace="tagset", version="1.0.0", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags_count = len(tag_names)
        tagset_tags_count = sum(1 for tag_name in tag_names if tag_name in tagset)

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "src_tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tag_records_count = 1000

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_cache = TagCache(file_path=temp_directory / "dst_tag_cache.db")

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(src_target_cache.count_records(), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records())), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * 2 * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)

            self.assertEqual(dst_target_cache.count_records(), tag_records_count)
            self.assertEqual(len(list(dst_target_cache.iter_records())), tag_records_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * tagset_tags_count // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * tagset_tags_count // tags_count)

    def test_tag_cache__clone_same_file(self):
        tag_names = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        tagset = MutableTagset(namespace="tagset", version="1.0.0", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags_count = len(tag_names)
        tagset_tags_count = sum(1 for tag_name in tag_names if tag_name in tagset)

        # Clone to the same file path should not cause any issue, and the cloned cache should be able to read
        # the tags added to the source cache after cloning.
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tag_records_count = 1000

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(src_target_cache.count_records(), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records())), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * 2 * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)

            self.assertEqual(dst_target_cache.count_records(), tag_records_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_records())), tag_records_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * 2 * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tag_records_count = 1000

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_cache = src_cache

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tag_records_count):
                tag_name = tag_names[i % len(tag_names)]
                tag = tagset.get_bound(tag_name) or tag_name
                src_target_cache.add_record(tag)

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(src_target_cache.count_records(), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records())), tag_records_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * 2 * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(src_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)

            self.assertEqual(dst_target_cache.count_records(), tag_records_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_records())), tag_records_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset]))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=True))),
                             tag_records_count * 2 * (tags_count - tagset_tags_count) // tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_records(tagsets=[tagset], tagset_inverted=False))),
                             tag_records_count * 2 * tagset_tags_count // tags_count)

    data_populate_clip_ranges = [
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:50.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:01:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:50.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:15.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:15.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:05.000000+00:00")),
            ],
        )
    ]

    @ddt.idata(data_populate_clip_ranges)
    @ddt.unpack
    def test_populate_clip_ranges(self, data_begin_dt, data_end_dt, expected):
        result = list(populate_clip_ranges(data_begin_dt, data_end_dt))
        self.assertEqual(result, expected)

    data_populate_clip_ranges__customized_duration = [
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:50.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:50.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:40.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:50.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:15.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:15.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00")),
                (dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:20.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:30.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:00.000000+00:00")),
            ],
        ),
        (
            dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
            dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
            [
                (dt_parse_iso("2023-01-01T00:00:00.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:10.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:05.000000+00:00"),
                 dt_parse_iso("2023-01-01T00:00:05.000000+00:00")),
            ],
        )
    ]

    @ddt.idata(data_populate_clip_ranges__customized_duration)
    @ddt.unpack
    def test_populate_clip_ranges__customized_duration(self, data_begin_dt, data_end_dt, expected):
        result = list(populate_clip_ranges(data_begin_dt, data_end_dt, clip_duration_us=10_000_000))
        self.assertEqual(result, expected)
