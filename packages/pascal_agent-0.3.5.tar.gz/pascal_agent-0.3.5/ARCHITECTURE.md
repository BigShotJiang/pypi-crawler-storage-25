# Pascal Architecture Reference

**Version**: 0.3.0 | **Date**: 2026-03-28 | **Total**: ~8,400 LOC (src) + ~3,700 LOC (tests)

---

## System Overview

Pascal is an autonomous AI employee runtime. It receives tasks, plans, executes, and reports back through a **working-document loop** with 4-layer safety.

```
                         ┌─────────────────────────────────┐
                         │         Human / Telegram         │
                         └────────┬──────────────┬─────────┘
                                  │ task/notify   │ reply/status
                         ┌────────▼──────────────▼─────────┐
                         │       __main__.py / daemon.py    │
                         │   CLI entry / always-on daemon   │
                         └────────┬────────────────────────┘
                                  │
              ┌───────────────────▼───────────────────┐
              │              LoopRunner                │
              │            (loop.py)                   │
              │                                       │
              │  ┌─ Outer Loop ───────────────────┐  │
              │  │  for iteration in range(limit): │  │
              │  │    1. Desk.render() → prompt    │  │
              │  │    2. _tool_use_loop():         │  │
              │  │       ┌─ Inner Loop ─────────┐ │  │
              │  │       │ LLM → tool_calls     │ │  │
              │  │       │ execute → observe     │ │  │
              │  │       │ tool_result → LLM     │ │  │
              │  │       │ repeat (max rounds)   │ │  │
              │  │       └──────────────────────┘ │  │
              │  │    3. checkpoint                │  │
              │  │    4. check terminal action     │  │
              │  └────────────────────────────────┘  │
              └───────────────────────────────────────┘
                    │           │           │
         ┌──────────┘           │           └──────────┐
         ▼                      ▼                      ▼
  ┌─────────────┐     ┌────────────────┐     ┌──────────────┐
  │  actions.py │     │   desk.py      │     │  Safety      │
  │ 22 handlers │     │ state→prompt   │     │  4 layers    │
  └──────┬──────┘     └───────┬────────┘     └──────┬───────┘
         │                    │                      │
    ┌────▼────┐         ┌────▼─────┐          ┌─────▼──────┐
    │tools.py │         │ state.py │          │ effect.py  │
    │mcp.py   │         │ SQLite   │          │ trust.py   │
    │sandbox  │         │ 9 tables │          │capability  │
    │uia.py   │         │ FTS5     │          │ sandbox.py │
    └─────────┘         └──────────┘          └────────────┘
```

---

## Module Map (26 files, dependency order)

```
src/pascal/
│
│── types.py .............. Shared DTOs (zero internal deps)
│   Role, Message, ToolCall, LLMResponse, Observation,
│   PlanNode, TaskPlan, PascalConfig, extract_json()
│
│── state.py ←types
│   PascalStore: SQLite persistence, 9 tables, FTS5, migrations
│   Tasks, notifications, rules, history, context, todos, memories,
│   conversations, checkpoints, run_lock
│
│── effect.py ............. Effect Ladder E0-E5 (zero deps)
│   classify_command(), check_allowed(), get_max_effect()
│   Hard regex rules only. LLM self-report ignored.
│
│── trust.py .............. Input Scanner (zero deps)
│   scan(), scan_tool_input() → pass/warn/block
│   Injection, credentials, destructive, network writes
│
│── capability.py ......... Domain Trust Map (zero deps)
│   TrustMap: 6 domains, asymmetric learning (+0.02/-0.10)
│   compute_threshold() → go/caution/block
│
│── sandbox.py ............ Command Isolation (zero deps)
│   DockerSandbox → RestrictedSandbox fallback
│   Env stripping, workspace boundary, path checks
│
│── receipts.py ........... Audit Ledger (zero deps)
│   Ledger: SHA-256 hash-chained JSONL, verify_chain()
│
│── prompt.py ............. System Prompt (zero deps)
│   SYSTEM_PROMPT constant — defines Pascal's behavior
│
│── config.py ←types
│   load_config(): CLI > env > TOML > defaults
│   create_llm(): provider factory
│
│── tools.py ←types, uia
│   TOOL_REGISTRY: 22 built-in tools
│   TOOL_EFFECTS: E0-E3 per tool
│   File, desktop, UIA, clipboard, app lifecycle, skill, channel
│
│── mcp.py ................ MCP Client (pure async)
│   MCPManager, MCPConnection, MCPToolSpec
│   Stdio subprocess, tool discovery, retry with backoff
│
│── schemas.py ............ Tool JSON Schemas for LLM function calling
│   build_tool_schemas() → OpenAI-compatible tool definitions
│
│── desk.py ←state
│   Desk: compile() → dict, render() → prompt string
│   Delta rendering for inner loop token savings
│
│── actions.py ←state, effect, trust, sandbox, mcp, tools, receipts, types
│   ActionContext dataclass + 22 action handlers
│   execute_action(): central dispatcher (legacy shim kept)
│   Plan tree execution, delegation, verification, postmortem
│
│── loop.py ←actions, capability, desk, effect, mcp, receipts, sandbox, state, tools, types
│   LoopRunner: outer iteration loop + inner tool-use loop
│   run_loop(): public API wrapper
│   Stagnation detection, trust gating, context compaction
│
│── scheduler.py ←state
│   Scheduler.tick(): overdue, stale, routines, webhooks
│
│── daemon.py ←config, loop, receipts, state, tools, mcp, channels
│   run_daemon(): Telegram + loop + scheduler (resilient)
│
│── __main__.py ←config, state, receipts, loop, mcp, daemon, desk, scheduler
│   CLI entry point: argparse → run/daemon/tick/resume/notify/status
│
│── llm/
│   ├── openai.py ←types ....... OpenAI Chat Completions (tool_calls)
│   ├── anthropic.py ←types .... Anthropic Messages API (tool_use)
│   └── codex.py ←types ........ ChatGPT Codex Responses SSE (function_call)
│
│── channels/
│   └── telegram.py ←state ..... Telegram bot (aiogram)
│
│── uia.py .................... Windows UI Automation (pywinauto)
│── clipboard.py .............. Clipboard get/set (pyperclip/pywin32)
│── eval/smoke.py ............. 8 smoke test scenarios
```

---

## Database Schema (SQLite, WAL mode)

```sql
┌──────────────────────────────────────────────────────────────┐
│                        tasks                                  │
├──────────────────────────────────────────────────────────────┤
│ id TEXT PK                                                    │
│ goal TEXT NOT NULL                                            │
│ status TEXT ∈ {pending,active,paused,blocked,done,failed}     │
│ progress TEXT                                                 │
│ result TEXT                                                   │
│ priority TEXT ∈ {urgent,normal,low}                           │
│ source TEXT (human|agent)                                     │
│ promised_to TEXT (JSON array)                                 │
│ due_at TEXT (ISO 8601)                                        │
│ proof_required TEXT (JSON array)                              │
│ depends_on TEXT (JSON array)                                  │
│ parent_id TEXT → tasks(id)                                    │
│ plan_json TEXT (TaskPlan JSON)                                │
│ created_at, updated_at TEXT                                   │
└──────────────────────────────────────────────────────────────┘
         │ 1:N              │ 1:N             │ 1:1
         ▼                  ▼                 ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────────┐
│    todos     │  │  checkpoints │  │   plan_json      │
│ id, task_id  │  │ id, task_id  │  │ (stored inline)  │
│ title,status │  │ iteration    │  │ PlanNode tree    │
│ ordinal      │  │ snapshot_json│  │ with leaves      │
└──────────────┘  └──────────────┘  └──────────────────┘

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│  notifications   │  │     rules        │  │    context       │
│ id, source       │  │ id, rule         │  │ key PK, value    │
│ message,priority │  │ tier, mutable    │  │ expires_at       │
│ status, metadata │  │ added_by         │  │ updated_at       │
└──────────────────┘  │ expires_at       │  └──────────────────┘
                      └──────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   history (APPEND-ONLY)                        │
│ Triggers: no UPDATE, no DELETE                                │
├──────────────────────────────────────────────────────────────┤
│ id, summary, task_id, details JSON, idem_key UNIQUE          │
│ action_status ∈ {ok,error,unknown}, created_at               │
└──────────────────────────────────────────────────────────────┘

┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│   memories       │  │ conversations    │  │   capability     │
│ id, kind, content│  │ id, channel      │  │ key PK, value    │
│ source_task_id   │  │ role, content    │  │ (TrustMap JSON)  │
│ access_count     │  │ created_at       │  │ updated_at       │
│ last_accessed    │  └──────────────────┘  └──────────────────┘
└──────────────────┘
        ↕ FTS5                ↕ FTS5
┌──────────────────┐  ┌──────────────────┐
│ memories_fts     │  │conversations_fts │
│ (content, kind)  │  │(content,channel) │
└──────────────────┘  └──────────────────┘

┌──────────────────┐
│    run_lock      │
│ singleton=1 PK   │
│ locked_by,       │
│ locked_at,       │
│ expires_at       │
│ (TTL 5min)       │
└──────────────────┘
```

### Task State Machine

```
         ┌──────────┐
         │ pending  │
         └────┬─────┘
              │ activate
         ┌────▼─────┐
    ┌─────│  active  │─────┐
    │     └────┬─────┘     │
    │ pause    │ block     │ done/fail
    │     ┌────▼─────┐     │
    │     │ blocked  │─────┤
    │     └──────────┘     │
    │                      │
┌───▼──────┐         ┌────▼─────┐
│  paused  │         │   done   │ (terminal)
└────┬─────┘         └──────────┘
     │ reactivate
     │               ┌──────────┐
     └───────────────│  failed  │ → can retry → active/pending
                     └──────────┘
```

---

## 4-Layer Safety Architecture

```
Request from LLM
        │
        ▼
┌─ Layer 1: Effect Ladder (effect.py) ─────────────────────┐
│ Classify command → E0-E5 via hard regex rules            │
│ E0: read │ E1: UI │ E2: write │ E3: push │ E4: merge   │
│ E5: irreversible (ALWAYS BLOCKED)                        │
│ LLM self-report IGNORED. Pipe/&&/|| splitting.           │
│ If effect > max_effect → REJECT                          │
└──────────────────────────┬───────────────────────────────┘
                           │ allowed
                           ▼
┌─ Layer 2: Trust Scanner (trust.py) ──────────────────────┐
│ Scan all string params recursively:                      │
│  • Prompt injection (EN/KR/CN/JP + homoglyph NFKC)     │
│  • Credential exposure (PEM, Bearer, API keys) → BLOCK  │
│  • Destructive commands (rm -rf, DROP TABLE) → BLOCK    │
│  • Network writes (curl POST, fetch) → WARN            │
└──────────────────────────┬───────────────────────────────┘
                           │ pass/warn
                           ▼
┌─ Layer 3: TrustMap Gate (capability.py) ─────────────────┐
│ Domain trust: email/scheduling/file_ops/communication    │
│ Readiness = domain_trust - error_streak_penalty          │
│ E1: need 0.3 │ E2: 0.4 │ E3: 0.6 │ E4: 0.4 or block  │
│ Asymmetric: success +0.02, judgment failure -0.10        │
│ 3+ errors: -15%, 5+ errors: -25%                        │
└──────────────────────────┬───────────────────────────────┘
                           │ go/caution
                           ▼
┌─ Layer 4: Sandbox (sandbox.py) ──────────────────────────┐
│ Docker: --rm, --read-only, --network none, 512MB/1CPU   │
│ Fallback: RestrictedSandbox                              │
│   • Strip secrets from env (AWS, OPENAI, etc.)          │
│   • Temp HOME isolation                                  │
│   • Workspace boundary + path traversal check           │
│   • Symlink/junction creation blocked                    │
└──────────────────────────┬───────────────────────────────┘
                           │ execute
                           ▼
┌─ Audit: Ledger (receipts.py) ────────────────────────────┐
│ Every action → SHA-256 hash-chained JSONL                │
│ {time, kind, prev_hash, action, decision, result, hash}  │
│ + SQLite append-only history (triggers block UPDATE/DEL)  │
└──────────────────────────────────────────────────────────┘
```

---

## Tool Registry (25 tools)

| Tool | Effect | Category |
|------|--------|----------|
| `read_file` | E0 | File |
| `write_file` | E2 | File |
| `list_dir` | E0 | File |
| `screenshot` | E0 | Desktop |
| `click` | E1 | Desktop |
| `type_text` | E1 | Desktop |
| `hotkey` | E1 | Desktop |
| `scroll` | E1 | Desktop |
| `uia_snapshot` | E0 | Windows UIA |
| `uia_click` | E1 | Windows UIA |
| `uia_type` | E2 | Windows UIA |
| `uia_get_text` | E0 | Windows UIA |
| `uia_find` | E0 | Windows UIA |
| `uia_wait` | E0 | Windows UIA |
| `window_focus` | E1 | Windows UIA |
| `clipboard_get` | E0 | Clipboard |
| `clipboard_set` | E1 | Clipboard |
| `app_launch` | E1 | App Lifecycle |
| `app_list` | E0 | App Lifecycle |
| `app_close` | E2 | App Lifecycle |
| `skill` | E0 | Skill Loader |
| `channel_reply` | E3 | Telegram |
| Shell commands | E0-E5 | Sandbox (classified per command) |
| MCP tools | E0/E3 | External (readOnlyHint → E0, else E3) |
| Delegate | E2 | claude-code / codex subprocess |

---

## 22 Action Types

| Action | Terminal? | Batch Break? | Description |
|--------|-----------|-------------|-------------|
| `think` | | | Internal reasoning (no side effects) |
| `execute` | | | Run shell command or tool |
| `plan` | | Yes | Create/patch execution plan tree |
| `delegate` | | Yes | Call claude-code or codex CLI |
| `pick_task` | | | Activate a pending task |
| `create_task` | | | Create new task (E2+ → needs approval) |
| `create_subtask` | | | Add subtask under active task |
| `handle_notification` | | | Mark handled + optional reply |
| `dismiss_notification` | | | Mark dismissed |
| `pause_task` | | | Pause active task |
| `block_task` | | Yes | Mark blocked (external input needed) |
| `fail_task` | **Yes** | Yes | Mark failed + auto-postmortem |
| `complete_task` | **Yes** | Yes | Mark done + verification + memorize |
| `add_todo` | | | Add TODO to active task |
| `complete_todo` | | | Mark TODO done |
| `memorize` | | | Save fact/lesson/preference/procedure |
| `add_rule` | | | Add behavior rule |
| `remove_rule` | | | Remove mutable rule |
| `set_context` | | | Set working memory key-value |
| `wait` | **Yes** | Yes | Idle / await notifications |
| `escalate` | **Yes** | Yes | Ask human for help |

---

## LLM Providers

```
┌─────────────────────────────────────────────────────────┐
│                    LLM Interface                         │
│  async chat(messages: list[Message],                    │
│             tools: list[dict]) → LLMResponse            │
└────────┬─────────────────┬─────────────────┬────────────┘
         │                 │                 │
    ┌────▼────┐      ┌────▼────┐      ┌────▼────┐
    │ OpenAI  │      │Anthropic│      │  Codex  │
    │ gpt-4o  │      │claude-  │      │ gpt-5.4 │
    │         │      │sonnet-4 │      │         │
    │ Chat    │      │Messages │      │Responses│
    │Compltns │      │  API    │      │  SSE    │
    │         │      │         │      │         │
    │tool_    │      │tool_use │      │function │
    │calls[]  │      │ blocks  │      │_call    │
    │         │      │         │      │events   │
    └─────────┘      └─────────┘      └─────────┘
```

| Provider | Auth | Endpoint | Tool Calling |
|----------|------|----------|-------------|
| OpenAI | `OPENAI_API_KEY` | Chat Completions | `tool_calls[]` in response |
| Anthropic | `ANTHROPIC_API_KEY` | Messages API | `tool_use` content blocks |
| Codex | OAuth (`~/.codex/auth.json`) | `chatgpt.com/backend-api/codex/responses` | SSE `function_call` events |

---

## Desk (Working Document)

The Desk compiles all state into a single prompt the LLM reads every iteration:

```
┌─ Full Render (first iteration + force refresh) ─────────────────┐
│ **Now: 2026-03-28 14:30:00 KST (05:30 UTC) | Windows 11**     │
│                                                                  │
│ ## ⚠ Unverified Previous Step (if unknown)                     │
│ ## Mission                                                       │
│ ## Identity                                                      │
│ ## Active Task (goal, progress, priority, due, proof)           │
│ ## Subtasks (done/pending marks)                                │
│ ## Plan (progress, failed nodes for repair)                     │
│ ## TODO (checklist)                                             │
│ ## Conversation (Telegram/Discord recent turns)                 │
│ ## Notifications (external-message isolation)                   │
│ ## Task Queue (actionable, sorted by priority/due)              │
│ **Tools:** read_file, write_file, ... | Shell | Desktop         │
│ ## MCP Tools                                                     │
│ ## Skills                                                        │
│ ## Rules (policy > operator > learned > ephemeral)              │
│ ## Memories                                                      │
│ ## Known Procedures                                              │
│ ## Recent Actions (last 5 with results)                         │
│ ## Working Memory (context keys)                                │
│                                                                  │
│ Context limit: 12,000 chars (~3,000 tokens)                    │
│ Protected sections: Mission, Active Task, Rules, Notifications  │
└──────────────────────────────────────────────────────────────────┘

┌─ Delta Render (inner loop subsequent turns) ─────────────────────┐
│ Tier 1 (pinned): Mission, Task, Rules, Urgent notifications    │
│ Tier 2 (delta): Last observation result                        │
│ Tier 3 (search): Relevant memories                             │
│ ~800-1500 tokens (vs 3000 for full render)                     │
└──────────────────────────────────────────────────────────────────┘
```

---

## Plan Tree Execution

```
LLM creates:
  plan_tree: {
    id: "root", kind: "branch", title: "Write report",
    children: [
      {id: "s0", kind: "leaf", title: "Research",
       done_when: "notes.md exists", action: {action: "execute", command: "..."}},
      {id: "s1", kind: "leaf", title: "Draft",
       done_when: "report.md has 500+ words", action: {action: "execute", tool: "write_file", ...}},
    ]
  }

Execution:
  for leaf in pending_leaves():
    leaf.status = "active"
    result = execute_action(leaf.action)
    if error → leaf.status = "failed", BREAK
    if unknown → leaf.status = "failed", BREAK  (side effect uncertain)
    else → leaf.status = "done"

Repair (on failure):
  LLM sends: {action: "plan", patch_node_id: "s0", plan_tree: {replacement subtree}}
  → Replaces failed node's children with new approach
  → plan.revision incremented
```

---

## Deployment Modes

| Mode | Command | max_effect | max_tool_rounds | Lifecycle |
|------|---------|-----------|-----------------|-----------|
| One-shot | `pascal "goal"` | E2 | 1 (default) | Until terminal action |
| Daemon | `pascal --daemon` | E3 | 3 (default) | Continuous (wake_event) |
| Tick | `pascal --tick` | - | - | Single scheduler check |
| Resume | `pascal --resume ID` | E2 | 1 | Continue paused task |

---

## Configuration Priority

```
CLI args  >  Environment vars  >  pascal.toml  >  Defaults

TOML locations (first found):
  1. ./pascal.toml
  2. ~/.pascal/pascal.toml

Key settings:
  PASCAL_MODEL=gpt-5.4
  PASCAL_PROVIDER=codex          # openai | anthropic | codex
  PASCAL_DB_PATH=~/.pascal/state.db
  PASCAL_MAX_EFFECT=E2           # daemon overrides to E3
  PASCAL_MAX_TOOL_ROUNDS=10
  PASCAL_SLACK_WEBHOOK=https://...
  PASCAL_DISCORD_WEBHOOK=https://...
```

---

## Key Constants

| Constant | Value | Location |
|----------|-------|---------|
| `_DEFAULT_MAX_TOOL_ROUNDS` | 10 | loop.py |
| `_MAX_PARSE_RETRIES` | 3 | loop.py |
| `_MESSAGE_CHAR_BUDGET` | 120,000 | loop.py |
| `_TOOL_RESULT_CHAR_BUDGET` | 8,000 | loop.py |
| `_OUTPUT_HARD_LIMIT` | 8,000 | actions.py |
| `_PLAN_MAX_STEPS` | 20 | actions.py |
| `_DELEGATE_MAX_TIMEOUT` | 600s | actions.py |
| `_LOCK_TTL_SECONDS` | 300 (5min) | state.py |
| `_REPLY_RATE_LIMIT` | 10/60s | tools.py |
| Desk max chars | 12,000 | desk.py |
| Docker memory | 512MB | sandbox.py |

---

## Installation

```bash
# Clone
git clone https://gitlab.com/laum0621/pascal.git
cd pascal

# Install (minimal)
pip install -e .

# Install (all features)
pip install -e ".[all]"

# Codex OAuth (ChatGPT Pro required)
codex auth login

# Configure
mkdir -p ~/.pascal
# Optional: ~/.pascal/pascal.toml, ~/.pascal/telegram.json, ~/.pascal/mcp.json

# Run
python -m pascal "Your task here" --provider codex --model gpt-5.4

# Daemon mode (Telegram)
python -m pascal --daemon

# Tests
pip install -e ".[dev]"
pytest tests/ --ignore=tests/test_uia_integration.py
```

### Dependencies

| Package | Required | Purpose |
|---------|----------|---------|
| `openai>=1.0` | Yes | OpenAI provider |
| `httpx>=0.27` | Yes | Codex SSE streaming |
| `anthropic>=0.30` | Optional | Anthropic provider |
| `pyautogui` + `pillow` | Optional | Desktop screenshot/click |
| `pywinauto>=0.6.8` | Optional | Windows UIA |
| `mcp` | Optional | MCP tool servers |
| `aiogram>=3.0` | Optional | Telegram bot |
| `pyperclip` | Optional | Clipboard |
| `pytest` + `pytest-asyncio` | Dev | Testing |

### System Requirements

- Python >= 3.12
- Windows 11 (for UIA/desktop features)
- Docker (optional, for sandbox isolation)
