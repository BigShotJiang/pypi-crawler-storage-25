"""Tests for plan tree storage, validation, and hybrid execution."""

from __future__ import annotations



from pascal.types import PlanNode, TaskPlan
from pascal.state import PascalStore
from pascal.loop import run_loop

from conftest import MockLLM, j


# ── PlanNode validation ──────────────────────────────────────────

class TestPlanNodeValidation:
    def test_valid_leaf(self):
        node = PlanNode(id="s0", title="test", kind="leaf",
                        done_when="file exists", action={"action": "execute", "command": "touch f"})
        assert node.validate() == []

    def test_leaf_missing_done_when(self):
        node = PlanNode(id="s0", title="test", kind="leaf",
                        action={"action": "execute", "command": "ls"})
        errors = node.validate()
        assert any("done_when" in e for e in errors)

    def test_leaf_missing_action(self):
        node = PlanNode(id="s0", title="test", kind="leaf", done_when="ok")
        errors = node.validate()
        assert any("action" in e.lower() for e in errors)

    def test_leaf_cannot_be_plan(self):
        node = PlanNode(id="s0", title="test", kind="leaf",
                        done_when="ok", action={"action": "plan", "steps": []})
        errors = node.validate()
        assert any("plan" in e for e in errors)

    def test_leaf_cannot_have_children(self):
        child = PlanNode(id="c0", title="c", kind="leaf",
                         done_when="ok", action={"action": "execute"})
        node = PlanNode(id="s0", title="test", kind="leaf",
                        done_when="ok", action={"action": "execute"}, children=[child])
        errors = node.validate()
        assert any("children" in e for e in errors)

    def test_valid_branch(self):
        leaf = PlanNode(id="s0", title="step", kind="leaf",
                        done_when="done", action={"action": "execute", "command": "ls"})
        branch = PlanNode(id="root", title="plan", kind="branch", children=[leaf])
        assert branch.validate() == []

    def test_branch_no_children(self):
        branch = PlanNode(id="root", title="plan", kind="branch")
        errors = branch.validate()
        assert any("children" in e for e in errors)

    def test_branch_cannot_have_action(self):
        leaf = PlanNode(id="s0", title="step", kind="leaf",
                        done_when="done", action={"action": "execute"})
        branch = PlanNode(id="root", title="plan", kind="branch",
                          children=[leaf], action={"action": "execute"})
        errors = branch.validate()
        assert any("action" in e.lower() for e in errors)

    def test_recursive_validation(self):
        """Errors in nested children bubble up."""
        bad_leaf = PlanNode(id="s0", title="bad", kind="leaf")  # missing both
        branch = PlanNode(id="root", title="plan", kind="branch", children=[bad_leaf])
        errors = branch.validate()
        assert len(errors) >= 2  # done_when + action


# ── Serialization roundtrip ──────────────────────────────────────

class TestSerialization:
    def test_plan_node_roundtrip(self):
        leaf = PlanNode(id="s0", title="step", kind="leaf",
                        done_when="file exists", action={"action": "execute", "command": "touch f"})
        d = leaf.to_dict()
        restored = PlanNode.from_dict(d)
        assert restored.id == "s0"
        assert restored.done_when == "file exists"
        assert restored.action["command"] == "touch f"

    def test_task_plan_roundtrip(self):
        leaf1 = PlanNode(id="s0", title="first", kind="leaf",
                         done_when="ok", action={"action": "execute", "command": "echo 1"})
        leaf2 = PlanNode(id="s1", title="second", kind="leaf",
                         done_when="ok", action={"action": "execute", "command": "echo 2"})
        root = PlanNode(id="root", title="plan", kind="branch", children=[leaf1, leaf2])
        plan = TaskPlan(root=root, revision=3)
        d = plan.to_dict()
        restored = TaskPlan.from_dict(d)
        assert restored.revision == 3
        assert len(restored.root.children) == 2
        assert restored.root.children[0].id == "s0"


# ── State storage ────────────────────────────────────────────────

class TestPlanStorage:
    def test_store_and_retrieve_plan(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test task")
        leaf = PlanNode(id="s0", title="step", kind="leaf",
                        done_when="ok", action={"action": "execute", "command": "echo hi"})
        root = PlanNode(id="root", title="plan", kind="branch", children=[leaf])
        plan = TaskPlan(root=root)
        store.set_task_plan(tid, plan.to_dict())

        retrieved = store.get_task_plan(tid)
        assert retrieved is not None
        restored = TaskPlan.from_dict(retrieved)
        assert restored.root.children[0].id == "s0"
        store.close()

    def test_get_plan_returns_none_when_empty(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test task")
        assert store.get_task_plan(tid) is None
        store.close()

    def test_clear_plan(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test task")
        store.set_task_plan(tid, {"version": 1, "root": None})
        store.clear_task_plan(tid)
        assert store.get_task_plan(tid) is None
        store.close()


# ── Tree navigation helpers ──────────────────────────────────────

class TestTreeNavigation:
    def _make_tree(self):
        s0 = PlanNode(id="s0", title="first", kind="leaf", status="done",
                       done_when="ok", action={"action": "execute"})
        s1 = PlanNode(id="s1", title="second", kind="leaf", status="pending",
                       done_when="ok", action={"action": "execute"})
        s2 = PlanNode(id="s2", title="third", kind="leaf", status="pending",
                       done_when="ok", action={"action": "execute"})
        return PlanNode(id="root", title="plan", kind="branch", children=[s0, s1, s2])

    def test_get_leaves(self):
        root = self._make_tree()
        leaves = root.get_leaves()
        assert len(leaves) == 3
        assert [leaf.id for leaf in leaves] == ["s0", "s1", "s2"]

    def test_find_node(self):
        root = self._make_tree()
        assert root.find_node("s1").title == "second"
        assert root.find_node("nonexistent") is None

    def test_next_pending_leaf(self):
        root = self._make_tree()
        assert root.next_pending_leaf().id == "s1"

    def test_count_by_status(self):
        root = self._make_tree()
        counts = root.count_by_status()
        assert counts["done"] == 1
        assert counts["pending"] == 2


# ── Plan action handler (hybrid execution) ───────────────────────

class TestPlanAction:
    async def test_plan_with_tree_format(self, tmp_path):
        """Plan tree is stored and leaves are executed."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test plan tree")
        store.activate_task(tid)

        llm = MockLLM([
            j(action="plan", plan_tree={
                "id": "root", "title": "test plan", "kind": "branch",
                "children": [
                    {"id": "s0", "title": "step 1", "kind": "leaf",
                     "done_when": "file exists",
                     "action": {"action": "execute", "tool": "write_file",
                                "tool_params": {"path": str(tmp_path / "out.txt"), "content": "hello"}}},
                ]
            }),
            j(action="complete_task", summary="Done"),
        ])

        from pascal.tools import set_workspace
        set_workspace(str(tmp_path))
        await run_loop(store, llm, max_iterations=5, workspace=str(tmp_path))
        plan_data = store.get_task_plan(tid)
        assert plan_data is not None
        plan = TaskPlan.from_dict(plan_data)
        assert plan.root is not None
        # Leaf should have been executed
        leaves = plan.root.get_leaves()
        assert len(leaves) == 1
        store.close()

    async def test_plan_with_legacy_steps(self, tmp_path):
        """Legacy flat steps are auto-wrapped into tree."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test legacy steps")
        store.activate_task(tid)

        llm = MockLLM([
            j(action="plan", steps=[
                {"action": "execute", "command": "echo hello", "done_when": "prints hello"},
            ]),
            j(action="complete_task", summary="Done"),
        ])

        await run_loop(store, llm, max_iterations=5, workspace=str(tmp_path))
        plan_data = store.get_task_plan(tid)
        assert plan_data is not None
        plan = TaskPlan.from_dict(plan_data)
        assert plan.root.kind == "branch"
        assert plan.root.children[0].kind == "leaf"
        store.close()

    async def test_plan_rejects_missing_done_when_in_tree(self, tmp_path):
        """Tree format enforces done_when on leaves."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test validation")
        store.activate_task(tid)

        llm = MockLLM([
            j(action="plan", plan_tree={
                "id": "root", "title": "bad plan", "kind": "branch",
                "children": [
                    {"id": "s0", "title": "no done_when", "kind": "leaf",
                     "action": {"action": "execute", "command": "echo hi"}},
                ]
            }),
            j(action="wait", reason="plan was rejected"),
        ])

        await run_loop(store, llm, max_iterations=5, workspace=str(tmp_path))
        # Plan should have been rejected — no plan stored
        plan_data = store.get_task_plan(tid)
        assert plan_data is None
        store.close()

    async def test_plan_subtree_patch(self, tmp_path):
        """patch_node_id replaces a subtree in existing plan."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test patch")
        store.activate_task(tid)

        # Pre-store a plan with a failed node
        failed_leaf = PlanNode(id="s0", title="failed step", kind="leaf",
                               status="failed", done_when="ok",
                               action={"action": "execute", "command": "false"}, attempts=1)
        s1 = PlanNode(id="s1", title="step 2", kind="leaf", status="pending",
                       done_when="ok", action={"action": "execute", "command": "echo done"})
        root = PlanNode(id="root", title="plan", kind="branch", children=[failed_leaf, s1])
        plan = TaskPlan(root=root)
        store.set_task_plan(tid, plan.to_dict())

        # LLM patches the failed node
        llm = MockLLM([
            j(action="plan", patch_node_id="s0", plan_tree={
                "id": "fix", "title": "fixed", "kind": "branch",
                "children": [
                    {"id": "s0a", "title": "alt step", "kind": "leaf",
                     "done_when": "ok", "action": {"action": "execute", "command": "echo fixed"}},
                ]
            }),
            j(action="complete_task", summary="Done"),
        ])

        await run_loop(store, llm, max_iterations=5, workspace=str(tmp_path))
        plan_data = store.get_task_plan(tid)
        plan = TaskPlan.from_dict(plan_data)
        assert plan.revision == 1  # patched once
        # s0 should now be a branch with new children
        s0 = plan.root.find_node("s0")
        assert s0.kind == "branch"
        assert len(s0.children) == 1
        assert s0.children[0].id == "s0a"
        store.close()


# ── Phase B: Desk rendering + plan-aware retry ───────────────────

class TestPlanDeskRendering:
    def test_desk_shows_plan_with_failures(self, tmp_path):
        """Desk renders plan section when there are failed nodes."""
        from pascal.desk import Desk
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test desk plan")
        store.activate_task(tid)

        failed = PlanNode(id="s0", title="broken step", kind="leaf", status="failed",
                          done_when="file exists", action={"action": "execute"},
                          attempts=2, last_error="command not found")
        pending = PlanNode(id="s1", title="next step", kind="leaf", status="pending",
                           done_when="ok", action={"action": "execute"})
        root = PlanNode(id="root", title="plan", kind="branch", children=[failed, pending])
        plan = TaskPlan(root=root)
        store.set_task_plan(tid, plan.to_dict())

        desk = Desk(store)
        rendered = desk.render()
        assert "## Plan" in rendered
        assert "FAILED NODES" in rendered
        assert "broken step" in rendered
        assert "command not found" in rendered
        assert "patch_node_id" in rendered
        assert "next step" in rendered
        store.close()

    def test_desk_shows_plan_progress_no_failures(self, tmp_path):
        """Desk shows plan progress summary even without failures."""
        from pascal.desk import Desk
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test desk plan ok")
        store.activate_task(tid)

        done = PlanNode(id="s0", title="done step", kind="leaf", status="done",
                        done_when="ok", action={"action": "execute"})
        pending = PlanNode(id="s1", title="next", kind="leaf", status="pending",
                           done_when="ok", action={"action": "execute"})
        root = PlanNode(id="root", title="plan", kind="branch", children=[done, pending])
        store.set_task_plan(tid, TaskPlan(root=root).to_dict())

        desk = Desk(store)
        rendered = desk.render()
        assert "## Plan" in rendered
        assert "1/2 done" in rendered
        assert "FAILED" not in rendered
        store.close()


class TestPlanAwareRetry:
    async def test_failed_plan_triggers_repair_feedback(self, tmp_path):
        """When a plan step fails, loop provides plan-aware repair guidance."""
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test plan retry")
        store.activate_task(tid)

        # Pre-store a plan with a failed node (simulating a previous execution failure)
        failed_leaf = PlanNode(id="s0", title="broken", kind="leaf", status="failed",
                               done_when="command succeeds",
                               action={"action": "execute", "command": "bad_cmd"},
                               attempts=1, last_error="command not found")
        root = PlanNode(id="root", title="plan", kind="branch", children=[failed_leaf])
        store.set_task_plan(tid, TaskPlan(root=root).to_dict())

        # LLM should see the failure on the desk and patch it
        llm = MockLLM([
            j(action="plan", patch_node_id="s0", plan_tree={
                "id": "fix", "title": "fixed", "kind": "branch",
                "children": [
                    {"id": "s0a", "title": "alt", "kind": "leaf",
                     "done_when": "ok", "action": {"action": "execute", "command": "echo fixed"}},
                ]
            }),
            j(action="complete_task", summary="Fixed and done"),
        ])

        await run_loop(store, llm, max_iterations=5, workspace=str(tmp_path))
        plan_data = store.get_task_plan(tid)
        plan = TaskPlan.from_dict(plan_data)
        # s0 should now be patched and the new leaf executed
        s0 = plan.root.find_node("s0")
        assert s0.kind == "branch"
        assert s0.status == "pending" or any(c.status == "done" for c in s0.children)
        store.close()

    def test_desk_renders_failed_plan_for_replanning(self, tmp_path):
        """Desk shows failed plan nodes with repair instructions."""
        from pascal.desk import Desk
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test desk replan")
        store.activate_task(tid)

        failed = PlanNode(id="s0", title="install dep", kind="leaf", status="failed",
                          done_when="pip install succeeds",
                          action={"action": "execute", "command": "pip install nonexistent"},
                          attempts=1, last_error="No matching distribution")
        root = PlanNode(id="root", title="plan", kind="branch", children=[failed])
        store.set_task_plan(tid, TaskPlan(root=root).to_dict())

        desk = Desk(store)
        rendered = desk.render()
        assert "patch_node_id" in rendered
        assert "install dep" in rendered
        assert "No matching distribution" in rendered
        store.close()
