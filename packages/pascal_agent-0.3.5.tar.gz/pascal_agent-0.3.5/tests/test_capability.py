"""Tests for Pascal's domain-level capability tracking."""

from __future__ import annotations

import json
import sqlite3

from pascal.capability import TrustMap, compute_threshold, infer_domain


class TestTrustMap:
    def test_defaults_include_all_domains_and_backward_compatible_overall(self):
        trust = TrustMap()

        assert trust.domains == {
            "email": 0.5,
            "scheduling": 0.5,
            "file_ops": 0.5,
            "communication": 0.5,
            "analysis": 0.5,
            "planning": 0.5,
        }
        assert trust.overall == 0.5

    def test_success_updates_only_the_target_domain_and_clamps(self):
        trust = TrustMap()

        trust.update_on_success("email")
        assert trust.domains["email"] == 0.52
        assert trust.domains["analysis"] == 0.5

        for _ in range(100):
            trust.update_on_success("email")

        assert trust.domains["email"] == 1.0

    def test_failure_penalizes_only_judgment_errors(self):
        trust = TrustMap()

        trust.update_on_failure("email", is_judgment_error=False)
        assert trust.domains["email"] == 0.5

        trust.update_on_failure("email", is_judgment_error=True)
        delta = 0.5 - trust.domains["email"]
        assert 0.05 <= delta <= 0.15

    def test_infer_domain_maps_common_actions_and_tools(self):
        assert infer_domain("send_email", "gmail_api") == "email"
        assert infer_domain("schedule_meeting", "calendar_api") == "scheduling"
        assert infer_domain("write_file", "filesystem") == "file_ops"
        assert infer_domain("send_message", "telegram_api") == "communication"
        assert infer_domain("plan_task", "planner") == "planning"
        assert infer_domain("inspect_context", "unknown_tool") == "analysis"

    def test_save_and_load_round_trip_through_capability_table(self, tmp_path):
        db_path = tmp_path / "capability.db"
        conn = sqlite3.connect(db_path)

        trust = TrustMap(
            domains={
                "email": 0.62,
                "scheduling": 0.48,
                "file_ops": 0.7,
                "communication": 0.5,
                "analysis": 0.55,
                "planning": 0.51,
            },
        )
        trust.save(conn)

        row = conn.execute("SELECT key, value FROM capability").fetchone()
        assert row[0] == "trust_map"
        payload = json.loads(row[1])
        assert payload["domains"]["email"] == 0.62

        loaded = TrustMap.load(conn)
        assert loaded == trust
        conn.close()

    def test_load_returns_defaults_when_no_row_exists(self, tmp_path):
        conn = sqlite3.connect(tmp_path / "empty.db")

        loaded = TrustMap.load(conn)

        assert loaded == TrustMap()
        conn.close()


class TestComputeThreshold:
    def test_e0_always_go_even_with_low_trust_and_errors(self):
        trust = TrustMap(domains={"analysis": 0.0})

        decision = compute_threshold(
            "E0",
            trust_map=trust,
            domain="analysis",
            recent_error_streak=99,
        )

        assert decision == "go"

    def test_neutral_default_trust_keeps_low_and_medium_effects_simple(self):
        assert compute_threshold("E1") == "go"
        assert compute_threshold("E2") == "go"
        assert compute_threshold("E3") == "caution"
        assert compute_threshold("E4") == "caution"
        assert compute_threshold("E5") == "block"

    def test_domain_trust_controls_thresholds_by_effect_level(self):
        low_trust = TrustMap(domains={"analysis": 0.29})
        medium_trust = TrustMap(domains={"analysis": 0.39})
        stage_ready = TrustMap(domains={"analysis": 0.6})

        assert compute_threshold("E1", trust_map=low_trust, domain="analysis") == "caution"
        assert compute_threshold("E2", trust_map=medium_trust, domain="analysis") == "caution"
        assert compute_threshold("E3", trust_map=stage_ready, domain="analysis") == "go"
        assert compute_threshold("E4", trust_map=medium_trust, domain="analysis") == "block"

    def test_error_streak_makes_borderline_actions_more_cautious(self):
        trust = TrustMap(domains={"analysis": 0.5})

        normal = compute_threshold("E2", trust_map=trust, domain="analysis", recent_error_streak=0)
        degraded = compute_threshold("E2", trust_map=trust, domain="analysis", recent_error_streak=3)

        assert normal == "go"
        assert degraded == "caution"

    def test_high_error_streak_can_block_commit_level_actions(self):
        trust = TrustMap(domains={"analysis": 0.5})

        decision = compute_threshold(
            "E4",
            trust_map=trust,
            domain="analysis",
            recent_error_streak=5,
        )

        assert decision == "block"
