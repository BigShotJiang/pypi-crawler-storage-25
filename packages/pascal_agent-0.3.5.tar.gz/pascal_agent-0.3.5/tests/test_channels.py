"""Phase 2 tests: scheduler tick."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from pascal.scheduler import Scheduler
from pascal.state import PascalStore


class TestScheduler:
    def test_tick_empty(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["overdue"] == 0
        assert result["stale"] == 0
        store.close()

    def test_overdue_detected(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Overdue task", due_at="2020-01-01T00:00:00Z")
        store.activate_task(store.get_pending_tasks()[0]["id"])
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["overdue"] == 1
        store.close()

    def test_overdue_done_ignored(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Done task", due_at="2020-01-01T00:00:00Z")
        store.activate_task(tid)
        store.update_task(tid, status="done", result="done")
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["overdue"] == 0
        store.close()

    def test_stale_detected(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Stale task")
        store.activate_task(tid)
        store.connection.execute(
            "UPDATE tasks SET updated_at = '2020-01-01T00:00:00.000Z' WHERE id = ?", (tid,),
        )
        store.connection.commit()
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["stale"] == 1
        store.close()

    def test_stale_recent_ignored(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Recent task")
        store.activate_task(tid)
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["stale"] == 0
        store.close()

    def test_stale_detected_on_same_threshold_day(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Threshold-day stale task")
        store.activate_task(tid)
        threshold_day = (datetime.now(timezone.utc) - timedelta(days=3)).strftime("%Y-%m-%d")
        store.connection.execute(
            "UPDATE tasks SET updated_at = ? WHERE id = ?",
            (f"{threshold_day}T00:00:00.000Z", tid),
        )
        store.connection.commit()

        result = Scheduler(store, emit=lambda m: None).tick()

        assert result["stale"] == 1
        store.close()

    def test_expired_context_cleaned(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("temp", "value", ttl_hours=0)
        store.connection.execute(
            "UPDATE context SET expires_at = '2020-01-01T00:00:00.000Z' WHERE key = 'temp'"
        )
        store.connection.commit()
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["expired_context"] >= 1
        store.close()

    def test_tick_emits_overdue(self, tmp_path, capsys):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Late task", due_at="2020-01-01T00:00:00Z")
        store.activate_task(store.get_pending_tasks()[0]["id"])
        Scheduler(store, emit=print).tick()
        output = capsys.readouterr().out
        assert "Overdue" in output
        store.close()
