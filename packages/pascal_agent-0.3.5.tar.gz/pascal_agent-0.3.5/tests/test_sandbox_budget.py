"""Tests for sandbox isolation."""

from __future__ import annotations

import os

from pascal.sandbox import SandboxManager, RestrictedSandbox


# ── Sandbox ──────────────────────────────────────────────────────

class TestRestrictedSandbox:
    def test_basic_execution(self, tmp_path):
        sb = RestrictedSandbox(workspace=str(tmp_path))
        result = sb.execute("echo hello")
        assert result.ok is True
        assert "hello" in result.stdout
        assert result.sandbox_type == "restricted"

    def test_timeout(self, tmp_path):
        sb = RestrictedSandbox(workspace=str(tmp_path))
        result = sb.execute("sleep 10", timeout=1)
        assert result.ok is False
        assert "timeout" in result.error.lower()
        assert result.status == "unknown"

    def test_env_stripped(self, tmp_path):
        os.environ["TEST_SECRET_KEY"] = "should_be_stripped"
        sb = RestrictedSandbox(workspace=str(tmp_path))
        result = sb.execute("env")
        os.environ.pop("TEST_SECRET_KEY", None)
        assert "TEST_SECRET_KEY" not in result.stdout

    def test_workspace_boundary(self, tmp_path):
        sb = RestrictedSandbox(workspace=str(tmp_path))
        result = sb.execute("pwd")
        assert result.ok is True
        # Should run in workspace directory
        assert str(tmp_path) in result.stdout or result.ok

    def test_nonzero_exit_is_error(self, tmp_path):
        sb = RestrictedSandbox(workspace=str(tmp_path))
        result = sb.execute("exit 1")
        assert result.ok is False
        assert result.status == "error"


class TestSandboxManager:
    def test_fallback_to_restricted(self, tmp_path):
        mgr = SandboxManager(workspace=str(tmp_path), prefer_docker=False)
        result = mgr.run("echo from manager")
        assert result.ok is True
        assert "from manager" in result.stdout

    def test_result_has_status(self, tmp_path):
        mgr = SandboxManager(workspace=str(tmp_path), prefer_docker=False)
        ok_result = mgr.run("echo ok")
        assert ok_result.status == "ok"
        err_result = mgr.run("exit 42")
        assert err_result.status == "error"
