"""Shared test infrastructure for Pascal tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Ensure pascal is importable
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from pascal.types import LLMResponse, ToolCall


def _text_to_tool_call(text: str, index: int) -> list[ToolCall] | None:
    """Convert a JSON action string to a ToolCall list.

    This lets existing tests pass text JSON strings while the runtime
    now requires function-calling tool_calls. Returns None if the text
    is not a valid Pascal action JSON.
    """
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return None
    if not isinstance(data, dict) or "action" not in data:
        return None
    action = str(data.pop("action")).strip().lower()
    return [ToolCall(id=f"mock_{index}", name=action, params=data)]


class MockLLM:
    """Test double — returns pre-defined responses in order.

    Responses can be:
      - str: auto-converted to ToolCall if valid action JSON, else returned as text
      - list[ToolCall]: returned as LLMResponse(tool_calls=list)
    """

    def __init__(self, responses: list):
        self._responses = list(responses)
        self._index = 0
        self.call_count = 0

    async def chat(self, messages, tools=None):
        self.call_count += 1
        if self._index >= len(self._responses):
            return LLMResponse(tool_calls=[ToolCall(id="mock_end", name="wait", params={"reason": "out of responses"})])
        resp = self._responses[self._index]
        self._index += 1
        # Already ToolCall list
        if isinstance(resp, list) and resp and isinstance(resp[0], ToolCall):
            return LLMResponse(tool_calls=resp)
        # Text → auto-convert to ToolCall (supports existing tests)
        if isinstance(resp, str):
            tool_calls = _text_to_tool_call(resp, self._index)
            if tool_calls is not None:
                return LLMResponse(tool_calls=tool_calls)
            # Pure text response (not an action JSON)
            return LLMResponse(text=resp)
        return LLMResponse(text=str(resp))


def j(**kwargs) -> str:
    """Shorthand for json.dumps(kwargs)."""
    return json.dumps(kwargs)
