"""Tests for daemon mode components."""
from __future__ import annotations
import asyncio
import json
from unittest.mock import AsyncMock
import pytest

from pascal.loop import run_loop
from pascal.state import PascalStore
from pascal.types import LLMResponse
from pascal import tools


def _j(**kwargs) -> str:
    return json.dumps(kwargs)


class _MockLLM:
    def __init__(self, responses, *, fallback_action="wait"):
        self._responses = list(responses)
        self._i = 0
        self._fallback_action = fallback_action

    async def chat(self, messages, tools=None):
        from pascal.types import ToolCall
        if self._i >= len(self._responses):
            return LLMResponse(tool_calls=[ToolCall(id="mock_end", name=self._fallback_action, params={"reason": "done"})])
        text = self._responses[self._i]
        self._i += 1
        try:
            data = json.loads(text)
            if isinstance(data, dict) and "action" in data:
                action = str(data.pop("action"))
                return LLMResponse(tool_calls=[ToolCall(id=f"mock_{self._i}", name=action, params=data)])
        except (json.JSONDecodeError, TypeError):
            pass
        return LLMResponse(text=text)


class TestResilient:
    async def test_retries_on_crash_then_succeeds(self):
        from pascal.daemon import _resilient
        call_count = 0

        async def crasher():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RuntimeError("boom")

        await _resilient(crasher, "test", max_retries=5)
        assert call_count == 3

    async def test_gives_up_after_max_retries(self):
        from pascal.daemon import _resilient
        call_count = 0

        async def always_crash():
            nonlocal call_count
            call_count += 1
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError, match="failed after 3 retries"):
            await _resilient(always_crash, "test", max_retries=3)
        assert call_count == 3


class TestTelegramConfig:
    def test_load_config_missing_raises(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pascal.channels.telegram.Path.home", staticmethod(lambda: tmp_path))
        from pascal.channels.telegram import load_telegram_config
        with pytest.raises(FileNotFoundError):
            load_telegram_config()

    def test_load_config_valid(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pascal.channels.telegram.Path.home", staticmethod(lambda: tmp_path))
        cfg_dir = tmp_path / ".pascal"
        cfg_dir.mkdir()
        (cfg_dir / "telegram.json").write_text(json.dumps({"bot_token": "test", "owner_chat_id": 123}))
        from pascal.channels.telegram import load_telegram_config
        cfg = load_telegram_config()
        assert cfg["bot_token"] == "test"
        assert cfg["owner_chat_id"] == 123


class TestWakeEvent:
    async def test_wait_blocks_until_event_then_continues(self, tmp_path):
        """In daemon mode, wait doesn't break -- it awaits the event, then continues."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Test task")
        wake = asyncio.Event()

        # Two waits, then escalate to exit the loop cleanly
        llm = _MockLLM([
            _j(action="wait", reason="nothing to do"),
            _j(action="wait", reason="still nothing"),
            _j(action="escalate", question="done", reason="exit"),
        ])

        async def wake_repeatedly():
            for _ in range(5):
                await asyncio.sleep(0.05)
                wake.set()

        wake_task = asyncio.create_task(wake_repeatedly())
        try:
            actions = await run_loop(store, llm, wake_event=wake, max_iterations=5)
            wait_count = sum(1 for a in actions if a["action"] == "wait")
            assert wait_count >= 2, f"Expected >=2 waits (woke up), got {wait_count}"
        finally:
            wake_task.cancel()
            await asyncio.gather(wake_task, return_exceptions=True)
            store.close()

    async def test_oneshot_wait_still_breaks(self, tmp_path):
        """Without wake_event, wait breaks the loop as before."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Test task")

        llm = _MockLLM([
            _j(action="wait", reason="done"),
            _j(action="wait", reason="should not reach"),
        ])

        actions = await run_loop(store, llm, max_iterations=5)
        wait_count = sum(1 for a in actions if a["action"] == "wait")
        assert wait_count == 1, "One-shot should break on first wait"
        store.close()


class TestAsyncEscalate:
    async def test_escalate_blocks_task_in_daemon_mode(self, tmp_path):
        """escalate + wake_event + callback -> block task, continue loop."""
        store = PascalStore(str(tmp_path / "test.db"))
        t1 = store.add_task("Task 1")
        t2 = store.add_task("Task 2")

        mock_approval = AsyncMock()
        tools.set_approval_callback(mock_approval)
        tools.set_channel_bot(AsyncMock(), owner_chat_id=99999)

        wake = asyncio.Event()

        # Use 'think' as fallback so the loop doesn't hang on wait+wake_event
        llm = _MockLLM([
            _j(action="pick_task", task_id=t1, reason="start"),
            _j(action="escalate", question="Deploy to prod?", reason="need approval"),
            _j(action="pick_task", task_id=t2, reason="switch to other work"),
            _j(action="complete_task", summary="done with t2", reason="finished"),
        ], fallback_action="think")

        try:
            actions = await run_loop(store, llm, wake_event=wake, max_iterations=6)
            types = [a["action"] for a in actions]

            assert "pick_task" in types[2:], f"Loop should continue after escalate: {types}"

            task1 = store.connection.execute(
                "SELECT status FROM tasks WHERE id=?", (t1,)
            ).fetchone()
            assert task1["status"] == "blocked"

            mock_approval.assert_called_once()
        finally:
            tools.set_approval_callback(None)
            tools.set_channel_bot(None, 0)
            store.close()

    async def test_oneshot_escalate_still_breaks(self, tmp_path):
        """Without wake_event, escalate breaks as before."""
        store = PascalStore(str(tmp_path / "test.db"))
        t1 = store.add_task("Task 1")

        llm = _MockLLM([
            _j(action="pick_task", task_id=t1, reason="start"),
            _j(action="escalate", question="Help?", reason="stuck"),
            _j(action="wait", reason="should not reach"),
        ])

        actions = await run_loop(store, llm, max_iterations=5)
        types = [a["action"] for a in actions]
        assert types[-1] == "escalate", "One-shot should break on escalate"
        store.close()


class TestIntegrationFlow:
    """End-to-end: message -> notification -> wake -> LLM -> reply."""

    async def test_telegram_message_to_reply(self, tmp_path):
        """Simulate: Telegram message arrives -> becomes notification ->
        LLM handles notification -> LLM replies via channel_reply."""
        store = PascalStore(str(tmp_path / "test.db"))

        # Simulate telegram message already pushed as notification
        store.push_notification(
            source="telegram",
            message="What's the CI status?",
            metadata={"chat_id": "99999"},
        )

        # Mock bot for channel_reply
        mock_bot = AsyncMock()
        tools.set_channel_bot(mock_bot, owner_chat_id=99999)

        notif_id = store.get_pending_notifications()[0]["id"]
        llm = _MockLLM([
            _j(action="handle_notification", notification_id=notif_id,
               response="checking CI", reason="telegram request"),
            _j(action="execute", tool="channel_reply",
               tool_params={"text": "CI is green, all tests passing"},
               reason="report back"),
            _j(action="wait", reason="done"),
        ])

        actions = await run_loop(store, llm, max_iterations=5, max_effect="E3")
        types = [a["action"] for a in actions]

        assert "handle_notification" in types
        assert "execute" in types
        mock_bot.send_message.assert_called_once_with(
            chat_id=99999, text="CI is green, all tests passing"
        )

        tools.set_channel_bot(None, 0)
        store.close()

    async def test_approval_flow_end_to_end(self, tmp_path):
        """Simulate: task needs approval -> escalate -> block -> approval arrives -> unblock."""
        store = PascalStore(str(tmp_path / "test.db"))
        t1 = store.add_task("Deploy to prod")
        t2 = store.add_task("Write docs")
        wake = asyncio.Event()

        approval_calls = []
        async def mock_approval(chat_id, task_id, question):
            approval_calls.append({"chat_id": chat_id, "task_id": task_id, "question": question})

        tools.set_approval_callback(mock_approval)
        tools.set_channel_bot(AsyncMock(), owner_chat_id=99999)

        # Use 'think' as fallback so the loop doesn't hang on wait+wake_event
        llm = _MockLLM([
            _j(action="pick_task", task_id=t1, reason="start deploy"),
            _j(action="escalate", question="Push to main?", reason="need human ok"),
            _j(action="pick_task", task_id=t2, reason="work on docs while waiting"),
            _j(action="complete_task", summary="Docs written", reason="done"),
        ], fallback_action="think")

        try:
            actions = await run_loop(store, llm, wake_event=wake, max_iterations=6)
            types = [a["action"] for a in actions]

            assert "pick_task" in types[2:], f"Should have picked t2 after escalate: {types}"

            row = store.connection.execute("SELECT status FROM tasks WHERE id=?", (t1,)).fetchone()
            assert row["status"] == "blocked"

            row = store.connection.execute("SELECT status FROM tasks WHERE id=?", (t2,)).fetchone()
            assert row["status"] == "done"

            assert len(approval_calls) == 1
            assert approval_calls[0]["question"] == "Push to main?"
        finally:
            tools.set_approval_callback(None)
            tools.set_channel_bot(None, 0)
            store.close()

    async def test_channel_reply_without_daemon(self, tmp_path):
        """In one-shot mode, channel_reply returns error (no bot)."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Test")
        # Ensure no bot is set
        tools.set_channel_bot(None, 0)

        llm = _MockLLM([
            _j(action="execute", tool="channel_reply",
               tool_params={"text": "hello"}, reason="try reply"),
            _j(action="wait", reason="done"),
        ])

        actions = await run_loop(store, llm, max_iterations=3, max_effect="E3")
        # The execute should have an error result
        exec_action = next(a for a in actions if a["action"] == "execute")
        assert exec_action["result"]["status"] == "error"
        assert "No channel" in exec_action["result"]["error"]
        store.close()
