from __future__ import annotations

import json

from pascal.llm.codex import CodexProvider
from pascal.types import Message, Role, ToolCall


def _provider() -> CodexProvider:
    provider = object.__new__(CodexProvider)
    provider._model = "gpt-4o"
    return provider


def test_build_body_serializes_assistant_tool_calls_and_tool_outputs():
    provider = _provider()

    body = provider._build_body(
        [
            Message(role=Role.SYSTEM, content="Be precise."),
            Message(role=Role.USER, content="Check the weather."),
            Message(
                role=Role.ASSISTANT,
                content="Calling weather tool.",
                tool_calls=[
                    ToolCall(
                        id="call_weather",
                        name="get_weather",
                        params={"city": "Seoul"},
                    )
                ],
            ),
            Message(
                role=Role.TOOL,
                tool_call_id="call_weather",
                content='{"temp_c":12}',
            ),
        ],
        tools=None,
    )

    assert body["instructions"] == "Be precise."
    assert body["input"] == [
        {
            "role": "user",
            "content": [{"type": "input_text", "text": "Check the weather."}],
        },
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "Calling weather tool."}],
            "status": "completed",
        },
        {
            "type": "function_call",
            "call_id": "call_weather",
            "name": "get_weather",
            "arguments": json.dumps({"city": "Seoul"}),
        },
        {
            "type": "function_call_output",
            "call_id": "call_weather",
            "output": '{"temp_c":12}',
        },
    ]
