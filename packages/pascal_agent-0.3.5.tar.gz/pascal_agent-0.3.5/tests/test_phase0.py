"""Phase 0 tests: StepSpec, append-only receipts, UNKNOWN_PENDING_PROOF, stagnation."""

from __future__ import annotations

import json
import sqlite3

from conftest import MockLLM, j

from pascal.desk import Desk
from pascal.loop import run_loop, _detect_stagnation
from pascal.state import PascalStore


# ── StepSpec ─────────────────────────────────────────────────────

class TestStepSpec:
    async def test_stepspec_recorded_in_history(self, tmp_path):
        """New loop stores {decision, result} in history details — no StepSpec fields."""
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Test task")
        llm = MockLLM([
            j(action="pick_task", task_id=store.get_pending_tasks()[0]["id"],
               reason="start"),
            j(action="wait", reason="done"),
        ])
        actions = await run_loop(store, llm, max_iterations=5)

        # Action records now contain: iteration, action, reason, result
        assert actions[0]["action"] == "pick_task"
        assert "reason" in actions[0]

        # Verify history details contain decision + result
        history = store.get_recent_history(limit=5)
        details = history[0].get("details")
        if isinstance(details, str):
            details = json.loads(details)
        assert "decision" in details
        assert "result" in details
        store.close()

    async def test_stepspec_defaults_to_empty(self, tmp_path):
        """Action records have iteration/action/reason/result — no StepSpec fields."""
        store = PascalStore(str(tmp_path / "t.db"))
        llm = MockLLM([
            j(action="wait", reason="nothing to do"),
        ])
        actions = await run_loop(store, llm, max_iterations=5)

        assert actions[0]["action"] == "wait"
        assert "reason" in actions[0]
        assert "result" in actions[0]
        store.close()


# ── Append-only receipts ─────────────────────────────────────────

class TestAppendOnlyReceipts:
    def test_idem_key_dedup(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("first", idem_key="key_1", action_status="ok")
        store.record("second", idem_key="key_1", action_status="ok")  # duplicate

        history = store.get_recent_history(limit=10)
        # Only one entry with this key
        entries = [h for h in history if "first" in h["summary"] or "second" in h["summary"]]
        assert len(entries) == 1
        assert entries[0]["summary"] == "first"
        store.close()

    def test_history_no_update(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("immutable entry")
        import pytest
        with pytest.raises(sqlite3.IntegrityError, match="append-only"):
            store.connection.execute("UPDATE history SET summary = 'changed'")
        store.close()

    def test_history_no_delete(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("permanent entry")
        import pytest
        with pytest.raises(sqlite3.IntegrityError, match="append-only"):
            store.connection.execute("DELETE FROM history")
        store.close()

    def test_action_status_recorded(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("ok action", action_status="ok")
        store.record("error action", action_status="error")
        store.record("unknown action", action_status="unknown")

        history = store.get_recent_history(limit=5)
        statuses = [h["action_status"] for h in history]
        assert "ok" in statuses
        assert "error" in statuses
        assert "unknown" in statuses
        store.close()


# ── UNKNOWN_PENDING_PROOF ────────────────────────────────────────

class TestUnknownPendingProof:
    async def test_timeout_returns_unknown(self, tmp_path):
        """When execute_command simulates timeout, status should be unknown."""
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Test timeout")
        task_id = store.get_pending_tasks()[0]["id"]

        def _timeout_command(cmd):
            import subprocess
            raise subprocess.TimeoutExpired(cmd, 1)

        llm = MockLLM([
            j(action="pick_task", task_id=task_id, reason="start",
               expected_evidence="task active", stop_condition="active"),
            j(action="execute", command="slow_cmd", reason="test timeout",
               expected_evidence="output", stop_condition="completes"),
            j(action="wait", reason="done",
               expected_evidence="nothing", stop_condition="ends"),
        ])
        # Can't easily test subprocess timeout with mock, but we can test via action result
        actions = await run_loop(store, llm, max_iterations=5)


        # The execute action should have run (even if it "succeeds" via subprocess)
        assert any(a["action"] == "execute" for a in actions)
        store.close()

    def test_desk_shows_unknown_warning(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        desk = Desk(store)
        rendered = desk.render(has_unknown_step=True)
        assert "Unverified Previous Step" in rendered
        assert "UNKNOWN" in rendered
        assert "Do NOT repeat" in rendered
        store.close()

    def test_desk_no_warning_when_clear(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        desk = Desk(store)
        rendered = desk.render(has_unknown_step=False)
        assert "Unverified" not in rendered
        store.close()

    def test_history_records_unknown_status(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("unknown action", action_status="unknown")
        history = store.get_recent_history(1)
        assert history[0]["action_status"] == "unknown"
        store.close()


# ── Stagnation detection ─────────────────────────────────────────

class TestStagnation:
    def test_stagnation_detected_same_command(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        for _ in range(3):
            store.record("execute: trying", details={
                "decision": {"action": "execute", "command": "failing_cmd"},
                "result": {"error": "failed"},
            })
        assert _detect_stagnation(store, "failing_cmd") == "command"
        store.close()

    def test_no_stagnation_mixed_commands(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("execute: a", details={"decision": {"action": "execute", "command": "cmd_a"}})
        store.record("execute: b", details={"decision": {"action": "execute", "command": "cmd_b"}})
        store.record("execute: c", details={"decision": {"action": "execute", "command": "cmd_c"}})
        assert _detect_stagnation(store, "cmd_c") == ""
        store.close()

    def test_no_stagnation_non_execute(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.record("think: planning", details={"decision": {"action": "think"}})
        store.record("execute: cmd", details={"decision": {"action": "execute", "command": "cmd"}})
        store.record("execute: cmd", details={"decision": {"action": "execute", "command": "cmd"}})
        assert _detect_stagnation(store, "cmd") == ""
        store.close()

    async def test_stagnation_breaks_loop(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("Stuck task")
        task_id = store.get_pending_tasks()[0]["id"]

        # Pre-populate history with 3 identical execute records
        for _ in range(3):
            store.record("execute: stuck", details={
                "decision": {"action": "execute", "command": "same_failing_cmd"},
            })

        llm = MockLLM([
            j(action="pick_task", task_id=task_id, reason="start",
               expected_evidence="active", stop_condition="active"),
            # This 4th execute of same command should trigger stagnation
            j(action="execute", command="same_failing_cmd", reason="retry",
               expected_evidence="output", stop_condition="works"),
        ])
        actions = await run_loop(store, llm, max_iterations=10)


        # Should have escalated due to stagnation
        assert any(a.get("action") == "escalate" or a.get("result", {}).get("stagnation") for a in actions)
        # Should not have run many iterations
        assert len(actions) <= 3
        store.close()
