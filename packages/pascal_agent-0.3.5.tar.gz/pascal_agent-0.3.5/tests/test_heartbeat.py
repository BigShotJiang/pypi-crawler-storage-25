"""Tests for heartbeat: cron matching, routine check, dynamic interval."""
from __future__ import annotations

from datetime import datetime, timezone

from pascal.scheduler import Scheduler, _cron_matches
from pascal.state import PascalStore


class TestCronMatches:
    def test_exact_hour_minute(self):
        dt = datetime(2026, 3, 23, 9, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 9 * * *", dt) is True

    def test_wrong_hour(self):
        dt = datetime(2026, 3, 23, 10, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 9 * * *", dt) is False

    def test_every_hour(self):
        dt = datetime(2026, 3, 23, 14, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 * * * *", dt) is True

    def test_specific_weekday(self):
        # 2026-03-23 is Monday (weekday 0)
        dt = datetime(2026, 3, 23, 9, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 9 * * 0", dt) is True
        assert _cron_matches("0 9 * * 3", dt) is False

    def test_step_every_5_minutes(self):
        dt = datetime(2026, 3, 23, 9, 0, tzinfo=timezone.utc)
        assert _cron_matches("*/5 * * * *", dt) is True  # 0 % 5 == 0
        dt2 = datetime(2026, 3, 23, 9, 3, tzinfo=timezone.utc)
        assert _cron_matches("*/5 * * * *", dt2) is False  # 3 % 5 != 0
        dt3 = datetime(2026, 3, 23, 9, 15, tzinfo=timezone.utc)
        assert _cron_matches("*/5 * * * *", dt3) is True  # 15 % 5 == 0

    def test_step_every_2_hours(self):
        dt = datetime(2026, 3, 23, 8, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 */2 * * *", dt) is True  # 8 % 2 == 0
        dt2 = datetime(2026, 3, 23, 9, 0, tzinfo=timezone.utc)
        assert _cron_matches("0 */2 * * *", dt2) is False  # 9 % 2 != 0

    def test_wildcard_all(self):
        dt = datetime(2026, 3, 23, 15, 30, tzinfo=timezone.utc)
        assert _cron_matches("* * * * *", dt) is True

    def test_invalid_cron(self):
        dt = datetime(2026, 3, 23, 9, 0, tzinfo=timezone.utc)
        assert _cron_matches("invalid", dt) is False
        assert _cron_matches("", dt) is False


class TestRoutineCheck:
    def test_tick_fires_due_routine(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        now = datetime.now(timezone.utc)
        cron = f"{now.minute} {now.hour} * * *"
        store.set_context("routines", [
            {"name": "test routine", "cron": cron, "task_goal": "do the thing"}
        ])
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["due_routines"] >= 1
        notifs = store.get_pending_notifications()
        assert any("do the thing" in n["message"] for n in notifs)
        store.close()

    def test_tick_skips_not_due_routine(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("routines", [
            {"name": "future", "cron": "0 3 * * *", "task_goal": "nope"}
        ])
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["due_routines"] == 0
        store.close()

    def test_tick_dedup_routine(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        now = datetime.now(timezone.utc)
        cron = f"{now.minute} {now.hour} * * *"
        store.set_context("routines", [
            {"name": "dedup test", "cron": cron, "task_goal": "once only"}
        ])
        Scheduler(store, emit=lambda m: None).tick()
        Scheduler(store, emit=lambda m: None).tick()
        notifs = [n for n in store.get_pending_notifications() if "once only" in n["message"]]
        assert len(notifs) == 1
        store.close()

class TestDynamicInterval:
    def test_active_task_short_interval(self, tmp_path):
        from pascal.daemon import _compute_interval
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("active work")
        store.activate_task(store.get_pending_tasks()[0]["id"])
        assert _compute_interval(store) == 300
        store.close()

    def test_no_work_long_interval(self, tmp_path):
        from pascal.daemon import _compute_interval
        store = PascalStore(str(tmp_path / "t.db"))
        assert _compute_interval(store) == 1800
        store.close()

    def test_pending_notifications_short(self, tmp_path):
        from pascal.daemon import _compute_interval
        store = PascalStore(str(tmp_path / "t.db"))
        store.push_notification(source="test", message="hey")
        assert _compute_interval(store) == 300
        store.close()

    def test_pending_tasks_short(self, tmp_path):
        from pascal.daemon import _compute_interval
        store = PascalStore(str(tmp_path / "t.db"))
        store.add_task("pending work")
        assert _compute_interval(store) == 300
        store.close()


    def test_no_routines_context(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        result = Scheduler(store, emit=lambda m: None).tick()
        assert result["due_routines"] == 0
        store.close()
