"""Phase 3 tests: checkpoint/resume + context TTL."""

from __future__ import annotations


from conftest import MockLLM, j

from pascal.loop import run_loop
from pascal.state import PascalStore


# ── Checkpoints ──────────────────────────────────────────────────

class TestCheckpoint:
    def test_save_and_load(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test task")
        store.activate_task(tid)
        store.save_checkpoint(tid, 5, {"has_unknown_step": False})
        cp = store.get_latest_checkpoint(tid)
        assert cp is not None
        assert cp["task_id"] == tid
        assert cp["iteration"] == 5
        assert cp["snapshot"]["has_unknown_step"] is False
        store.close()

    def test_latest_returns_most_recent(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Test task")
        store.activate_task(tid)
        store.save_checkpoint(tid, 1, {})
        store.save_checkpoint(tid, 2, {})
        store.save_checkpoint(tid, 3, {})
        cp = store.get_latest_checkpoint(tid)
        assert cp["iteration"] == 3
        store.close()

    def test_no_checkpoint(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        assert store.get_latest_checkpoint("nonexistent") is None
        store.close()

    def test_prune_keeps_10(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Prunable task")
        store.activate_task(tid)
        for i in range(15):
            store.save_checkpoint(tid, i, {})
        count = store.connection.execute(
            "SELECT COUNT(*) FROM checkpoints WHERE task_id = ?", (tid,),
        ).fetchone()[0]
        assert count == 10
        store.close()

    def test_snapshot_lightweight(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Lightweight task")
        store.activate_task(tid)
        store.push_notification(source="test", message="hello")
        store.set_context("key1", "value1")
        store.record("test action")
        store.save_checkpoint(tid, 0, {"has_unknown_step": True})
        cp = store.get_latest_checkpoint(tid)
        snap = cp["snapshot"]
        # Should contain IDs/keys, not full data
        assert isinstance(snap["active_context_keys"], list)
        assert isinstance(snap["pending_notification_ids"], list)
        assert isinstance(snap["recent_history_ids"], list)
        assert snap["has_unknown_step"] is True
        store.close()

    async def test_loop_creates_checkpoints(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        tid = store.add_task("Checkpoint task")
        llm = MockLLM([
            j(action="pick_task", task_id=tid, reason="start"),
            j(action="execute", command="echo hi", reason="do"),
            j(action="complete_task", summary="Done", reason="done"),
            j(action="wait", reason="done"),
        ])
        await run_loop(store, llm, max_iterations=10)
        cp = store.get_latest_checkpoint(tid)
        assert cp is not None
        assert cp["iteration"] >= 0  # tool-use loop may complete all actions in iteration 0
        store.close()


# ── Context TTL ──────────────────────────────────────────────────

class TestContextTTL:
    def test_set_with_ttl(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("temp", "value", ttl_hours=24)
        row = store.connection.execute(
            "SELECT expires_at FROM context WHERE key = 'temp'"
        ).fetchone()
        assert row["expires_at"] is not None
        store.close()

    def test_set_without_ttl(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("perm", "value")
        row = store.connection.execute(
            "SELECT expires_at FROM context WHERE key = 'perm'"
        ).fetchone()
        assert row["expires_at"] is None
        store.close()

    def test_cleanup_expired(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        store.set_context("expired", "old", ttl_hours=1)
        store.connection.execute(
            "UPDATE context SET expires_at = '2020-01-01T00:00:00.000Z' WHERE key = 'expired'"
        )
        store.connection.commit()
        store.set_context("valid", "new")
        removed = store.cleanup_expired_context()
        assert removed >= 1
        ctx = store.get_all_context()
        assert "expired" not in ctx
        assert "valid" in ctx
        store.close()

    def test_enforce_limit(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        for i in range(105):
            store.set_context(f"key_{i:04d}", f"value_{i}")
        count = store.connection.execute("SELECT COUNT(*) FROM context").fetchone()[0]
        assert count <= 100
        store.close()

    def test_enforce_limit_noop(self, tmp_path):
        store = PascalStore(str(tmp_path / "t.db"))
        for i in range(50):
            store.set_context(f"key_{i}", f"value_{i}")
        count = store.connection.execute("SELECT COUNT(*) FROM context").fetchone()[0]
        assert count == 50
        store.close()
