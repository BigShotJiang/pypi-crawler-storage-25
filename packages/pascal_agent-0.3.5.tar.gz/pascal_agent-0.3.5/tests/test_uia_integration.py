"""Integration tests for UIA layer -- Windows only, manual execution."""

import sys
import time
import subprocess

import pytest

pytestmark = pytest.mark.skipif(
    sys.platform != "win32",
    reason="Windows only -- requires real desktop and pywinauto",
)


@pytest.fixture
def uia():
    from pascal.uia import UIAutomationAdapter
    adapter = UIAutomationAdapter()
    yield adapter
    adapter.clear_refs()


class TestNotepadWorkflow:
    @pytest.fixture(autouse=True)
    def _open_notepad(self):
        self.proc = subprocess.Popen(["notepad.exe"])
        time.sleep(1)
        yield
        self.proc.kill()

    def test_snapshot_finds_notepad(self, uia):
        elements = uia.snapshot(window_title="메모장")
        if not elements:
            elements = uia.snapshot(window_title="Notepad")
        assert len(elements) > 0

    def test_type_and_read(self, uia):
        elements = uia.snapshot(window_title="메모장")
        if not elements:
            elements = uia.snapshot(window_title="Notepad")
        edit = next((e for e in elements if e.control_type in ("Edit", "Document")), None)
        assert edit is not None
        result = uia.type_text(edit.ref, "Hello Pascal UIA!")
        assert result["ok"] is True
        assert "Hello Pascal UIA!" in uia.get_text(edit.ref)


class TestCalculator:
    @pytest.fixture(autouse=True)
    def _open_calc(self):
        self.proc = subprocess.Popen(["calc.exe"])
        time.sleep(2)
        yield
        self.proc.kill()

    def test_snapshot_finds_calculator(self, uia):
        elements = uia.snapshot(window_title="계산기")
        if not elements:
            elements = uia.snapshot(window_title="Calculator")
        assert len(elements) > 0


class TestWindowNotFound:
    def test_snapshot_returns_empty(self, uia):
        assert uia.snapshot(window_title="ThisWindowDoesNotExist12345") == []

    def test_find_returns_empty(self, uia):
        assert uia.find(name="Nonexistent", window_title="ThisWindowDoesNotExist12345") == []
