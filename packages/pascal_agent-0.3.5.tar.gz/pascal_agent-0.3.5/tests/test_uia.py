"""Unit tests for UIA layer -- mock-based, runs on any platform (CI-safe)."""

import pytest
from unittest.mock import MagicMock

from pascal.uia import UIElement, UIAutomationAdapter, render_snapshot


class TestUIElement:
    def test_to_text_basic(self):
        elem = UIElement(ref="e1", control_type="Button", name="Save",
                         value="", is_enabled=True, is_focused=False)
        text = elem.to_text()
        assert "[e1]" in text
        assert "Button" in text
        assert "'Save'" in text

    def test_to_text_with_value(self):
        elem = UIElement(ref="e2", control_type="Edit", name="Filename",
                         value="document.txt", is_enabled=True, is_focused=True)
        text = elem.to_text()
        assert 'value="document.txt"' in text
        assert "focused" in text

    def test_to_text_disabled(self):
        elem = UIElement(ref="e3", control_type="Button", name="Greyed",
                         value="", is_enabled=False, is_focused=False)
        assert "disabled" in elem.to_text()

    def test_to_text_long_value_truncated(self):
        elem = UIElement(ref="e4", control_type="Edit", name="",
                         value="x" * 200, is_enabled=True, is_focused=False)
        assert "..." in elem.to_text()


class TestRefSystem:
    def test_assign_ref_increments(self):
        adapter = UIAutomationAdapter()
        ref1 = adapter._assign_ref(MagicMock())
        ref2 = adapter._assign_ref(MagicMock())
        assert ref1 == "e1"
        assert ref2 == "e2"

    def test_resolve_ref_unknown_raises(self):
        adapter = UIAutomationAdapter()
        with pytest.raises(KeyError, match="Unknown ref"):
            adapter._resolve_ref("e999")

    def test_resolve_ref_stale_raises(self):
        adapter = UIAutomationAdapter()
        mock = MagicMock()
        mock.is_enabled.side_effect = Exception("gone")
        adapter._ref_map["e1"] = mock
        with pytest.raises(KeyError, match="Stale ref"):
            adapter._resolve_ref("e1")

    def test_clear_refs_resets(self):
        adapter = UIAutomationAdapter()
        adapter._assign_ref(MagicMock())
        adapter.clear_refs()
        assert len(adapter._ref_map) == 0
        assert adapter._ref_counter == 0
        assert adapter._assign_ref(MagicMock()) == "e1"


class TestActions:
    def test_click(self):
        adapter = UIAutomationAdapter()
        mock = MagicMock()
        mock.is_enabled.return_value = True
        adapter._ref_map["e1"] = mock
        assert adapter.click("e1")["ok"] is True
        mock.click_input.assert_called_once()

    def test_click_failure(self):
        adapter = UIAutomationAdapter()
        mock = MagicMock()
        mock.is_enabled.return_value = True
        mock.click_input.side_effect = RuntimeError("fail")
        adapter._ref_map["e1"] = mock
        assert adapter.click("e1")["ok"] is False

    def test_type_text(self):
        adapter = UIAutomationAdapter()
        mock = MagicMock()
        mock.is_enabled.return_value = True
        adapter._ref_map["e1"] = mock
        result = adapter.type_text("e1", "hello")
        assert result["ok"] is True
        assert result["chars"] == 5

    def test_get_text(self):
        adapter = UIAutomationAdapter()
        mock = MagicMock()
        mock.is_enabled.return_value = True
        mock.window_text.return_value = "Hello"
        adapter._ref_map["e1"] = mock
        assert adapter.get_text("e1") == "Hello"


class TestRenderSnapshot:
    def test_render_with_title(self):
        elements = [
            UIElement("e1", "Button", "OK", "", True, False),
            UIElement("e2", "Edit", "Name", "John", True, True),
        ]
        text = render_snapshot(elements, window_title="Test App")
        assert '"Test App"' in text
        assert "[e1]" in text
        assert "[e2]" in text


class TestToolRegistration:
    def test_uia_tools_in_registry(self):
        from pascal.tools import TOOL_REGISTRY, TOOL_EFFECTS
        expected = ["uia_snapshot", "uia_click", "uia_type", "uia_get_text",
                    "uia_find", "uia_wait", "window_focus"]
        for name in expected:
            assert name in TOOL_REGISTRY, f"{name} missing from TOOL_REGISTRY"
            assert name in TOOL_EFFECTS, f"{name} missing from TOOL_EFFECTS"

    def test_removed_tools_not_in_registry(self):
        from pascal.tools import TOOL_REGISTRY
        for name in ("window_list",):
            assert name not in TOOL_REGISTRY, f"{name} should have been removed"
        # clipboard_get and clipboard_set are now wired (M4 fix)
        for name in ("clipboard_get", "clipboard_set"):
            assert name in TOOL_REGISTRY, f"{name} should be registered"

    def test_effect_levels(self):
        from pascal.tools import TOOL_EFFECTS
        for name in ("uia_snapshot", "uia_get_text", "uia_find", "uia_wait"):
            assert TOOL_EFFECTS[name] == "E0"
        for name in ("uia_click", "window_focus"):
            assert TOOL_EFFECTS[name] == "E1"
        assert TOOL_EFFECTS["uia_type"] == "E2"
