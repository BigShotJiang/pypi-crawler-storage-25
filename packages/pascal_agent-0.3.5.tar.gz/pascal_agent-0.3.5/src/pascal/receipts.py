"""Append-only hash-chained audit ledger.

Every tool call, result, and governance decision gets a tamper-evident record.
Each entry contains the SHA-256 hash of the previous entry.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _lock_file(f, exclusive: bool = True) -> None:
    """Acquire a file lock (exclusive for writes, shared for reads)."""
    try:
        if sys.platform == "win32":
            import msvcrt
            # msvcrt.locking only supports exclusive locks; use LK_NBLCK for both
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
    except (OSError, ImportError):
        pass  # best-effort locking


def _unlock_file(f) -> None:
    """Release a file lock."""
    try:
        if sys.platform == "win32":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except (OSError, ImportError):
        pass


class Ledger:
    """Append-only JSONL ledger with hash chaining."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path).expanduser().resolve()
        self._path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _json_safe(obj):
        """Handle non-serializable objects (ContentBlock, dataclasses, etc.)."""
        if hasattr(obj, '__dataclass_fields__'):
            return {k: getattr(obj, k) for k in obj.__dataclass_fields__ if k != 'data'}
        return f"<{type(obj).__name__}>"

    def record(self, kind: str, payload: dict[str, Any]) -> str:
        """Append an entry. Returns the entry hash."""
        with open(self._path, "a+b") as f:
            _lock_file(f)
            try:
                prev_hash = self._read_last_hash_from_handle(f)
                entry = {
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                    "kind": kind,
                    "prev": prev_hash,
                    **payload,
                }
                raw = json.dumps(entry, ensure_ascii=False, sort_keys=True, default=self._json_safe)
                entry_hash = hashlib.sha256(raw.encode()).hexdigest()[:16]
                entry["hash"] = entry_hash

                line = (json.dumps(entry, ensure_ascii=False, default=self._json_safe) + "\n").encode("utf-8")
                f.seek(0, os.SEEK_END)
                f.write(line)
                f.flush()
            finally:
                _unlock_file(f)

        return entry_hash

    def record_action(self, action: str, decision: dict[str, Any], result: dict[str, Any]) -> str:
        return self.record("action", {"action": action, "decision": decision, "result": result})

    def verify_chain(self) -> tuple[bool, int]:
        """Verify the hash chain. Returns (valid, entry_count)."""
        if not self._path.exists():
            return True, 0
        prev = "genesis"
        count = 0
        for line in self._path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            entry = json.loads(line)
            if entry.get("prev") != prev:
                return False, count
            check = dict(entry)
            stored_hash = check.pop("hash", "")
            # Use _json_safe to match the serialization used during recording
            raw = json.dumps(check, ensure_ascii=False, sort_keys=True, default=self._json_safe)
            computed = hashlib.sha256(raw.encode()).hexdigest()[:16]
            if computed != stored_hash:
                return False, count
            prev = stored_hash
            count += 1
        return True, count

    def _read_last_hash(self) -> str:
        """Read the hash of the last valid entry, with file locking.

        Reads the tail of the file under a shared lock to prevent reading
        a partially-written line during a concurrent append.
        """
        if not self._path.exists():
            return "genesis"
        try:
            with open(self._path, "rb") as f:
                _lock_file(f, exclusive=False)
                try:
                    return self._read_last_hash_from_handle(f)
                finally:
                    _unlock_file(f)
        except OSError:
            pass
        return "genesis"

    def _read_last_hash_from_handle(self, f) -> str:
        f.seek(0, os.SEEK_END)
        size = f.tell()
        if size == 0:
            return "genesis"
        # Read the last 16KB to cover large delegate-result entries.
        read_size = min(size, 16 * 1024)
        f.seek(size - read_size)
        tail = f.read(read_size).decode("utf-8", errors="replace")
        lines = tail.strip().splitlines()
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                return json.loads(line).get("hash", "genesis")
            except (json.JSONDecodeError, KeyError):
                continue  # skip incomplete/corrupt lines
        return "genesis"
