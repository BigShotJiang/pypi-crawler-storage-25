"""Trust sanitizer -- scan tool inputs for injection, credentials, and suspicious patterns.

Runs before every tool execution. Returns BLOCK/WARN/PASS.

Defense-in-depth: regex scanning is one layer alongside structural isolation
(XML tags in desk.py) and effect ladder (effect.py). No single layer is sufficient.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass


@dataclass(frozen=True)
class ScanResult:
    verdict: str  # "pass", "warn", "block"
    reason: str = ""


# Prompt injection patterns -- expanded with indirect and multi-language variants
_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(previous|above|all|prior|earlier)\s+(instructions?|system|rules?|prompt)", re.I),
    re.compile(r"you\s+are\s+now\s+", re.I),
    re.compile(r"disregard\s+(your|all|the|any)\s+", re.I),
    re.compile(r"forget\s+(everything|your\s+instructions|all\s+rules|the\s+above)", re.I),
    re.compile(r"new\s+instructions?:", re.I),
    re.compile(r"system\s*:\s*you\s+are", re.I),
    # Override / role-switching patterns
    re.compile(r"(?:override|bypass|skip)\s+(?:safety|security|content|filter|guardrail|restriction)", re.I),
    re.compile(r"(?:act|behave|respond|operate)\s+as\s+(?:if|though)\s+", re.I),
    re.compile(r"(?:pretend|imagine|assume)\s+(?:you\s+are|that\s+you|you're)\s+", re.I),
    re.compile(r"(?:enter|switch\s+to|activate)\s+(?:dev|developer|debug|admin|sudo|root|unrestricted)\s+mode", re.I),
    re.compile(r"(?:do\s+not|don't|never)\s+(?:follow|obey|listen|adhere)", re.I),
    # Structural injection (attempting to mimic system/assistant roles)
    re.compile(r"<\s*(?:system|assistant|admin|root)\s*>", re.I),
    re.compile(r"\[(?:SYSTEM|ADMIN|ROOT)\]", re.I),
    # Multi-language injection (Korean, Chinese, Japanese common patterns)
    re.compile(r"(?:이전|위의|모든)\s*(?:지시|명령|규칙|시스템).{0,10}(?:무시|잊|삭제|변경)", re.I),
    re.compile(r"忽略.{0,5}(?:指令|规则|系统|提示)", re.I),
    re.compile(r"指示を(?:無視|忘れ)", re.I),
]

# Credential patterns
_CREDENTIAL_PATTERNS = [
    re.compile(r"-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----"),
    re.compile(r"-----BEGIN\s+CERTIFICATE-----"),
    re.compile(r"(password|passwd|secret|token)\s*[:=]\s*\S+", re.I),
    re.compile(r"(sk|pk|api[_-]?key)[_-][a-zA-Z0-9]{20,}"),
    re.compile(r"Bearer\s+[a-zA-Z0-9._\-]{20,}"),
    re.compile(r"aws[_-]?(secret|access)[_-]?key", re.I),
    re.compile(r"ghp_[a-zA-Z0-9]{36,}"),  # GitHub PAT
    re.compile(r"glpat-[a-zA-Z0-9\-]{20,}"),  # GitLab PAT
    re.compile(r"xox[bprs]-[a-zA-Z0-9\-]+"),  # Slack tokens
]

# Destructive patterns
_DESTRUCTIVE_PATTERNS = [
    re.compile(r"\brm\s+-rf\s+/", re.I),
    re.compile(r"\bformat\s+[a-z]:", re.I),
    re.compile(r"\bdrop\s+(database|table)\b", re.I),
    re.compile(r"\btruncate\s+table\b", re.I),
    re.compile(r"\bDELETE\s+FROM\s+\w+\s*(;|$)", re.I),
    re.compile(r"\b(?:mkfs|wipefs)\b", re.I),
    re.compile(r"\brd\s+/s\s+/q\b", re.I),  # Windows recursive delete
]

# Network write patterns -- defense-in-depth alongside effect.py E4 classification
_NETWORK_WRITE_PATTERNS = [
    # curl POST/PUT/DELETE (various flags)
    re.compile(r"\bcurl\b.*(?:-X\s*(?:POST|PUT|DELETE|PATCH)|--request\s+(?:POST|PUT|DELETE|PATCH))", re.I),
    re.compile(r"\bcurl\b.*(?:-d\s|--data|-F\s|--form|-T\s|--upload-file)", re.I),
    # wget POST
    re.compile(r"\bwget\b.*--(?:post-data|post-file)", re.I),
    # Python/Node indirect network writes
    re.compile(r"requests\.(?:post|put|patch|delete)\s*\(", re.I),
    re.compile(r"urllib\.request\.(?:urlopen|Request)\b.*(?:POST|PUT|DELETE|PATCH|data=)", re.I),
    re.compile(r"httpx\.(?:post|put|patch|delete)\s*\(", re.I),
    re.compile(r"fetch\s*\(.*method\s*:\s*['\"](?:POST|PUT|DELETE|PATCH)", re.I),
    # PowerShell network writes
    re.compile(r"Invoke-(?:WebRequest|RestMethod)\b.*-Method\s+(?:Post|Put|Delete|Patch)", re.I),
]


def _normalize(text: str) -> str:
    """Normalize unicode to catch homoglyph-based bypass attempts.

    NFKC normalization converts lookalike characters (e.g., Cyrillic 'а' → Latin 'a',
    fullwidth 'ｉｇｎｏｒｅ' → 'ignore') to their canonical forms.
    """
    return unicodedata.normalize("NFKC", text)


def scan(text: str) -> ScanResult:
    """Scan text for dangerous patterns. Called before tool execution."""
    if not text:
        return ScanResult("pass")

    # Normalize unicode before scanning to defeat homoglyph attacks
    normalized = _normalize(text)

    for pattern in _INJECTION_PATTERNS:
        if pattern.search(normalized):
            return ScanResult("block", f"Prompt injection detected: {pattern.pattern}")

    for pattern in _CREDENTIAL_PATTERNS:
        # Scan both original and normalized -- credentials may use exact chars
        if pattern.search(text) or pattern.search(normalized):
            return ScanResult("block", f"Credential exposure blocked: {pattern.pattern}")

    for pattern in _DESTRUCTIVE_PATTERNS:
        if pattern.search(normalized):
            return ScanResult("block", f"Destructive operation detected: {pattern.pattern}")

    for pattern in _NETWORK_WRITE_PATTERNS:
        if pattern.search(normalized):
            return ScanResult("warn", f"Network write detected: {pattern.pattern}")

    return ScanResult("pass")


def _extract_strings(value, depth: int = 0) -> list[str]:
    """Recursively extract all string values from nested dicts/lists."""
    if depth > 10:
        return []
    strings = []
    if isinstance(value, str):
        strings.append(value)
    elif isinstance(value, dict):
        for v in value.values():
            strings.extend(_extract_strings(v, depth + 1))
    elif isinstance(value, (list, tuple)):
        for item in value:
            strings.extend(_extract_strings(item, depth + 1))
    return strings


def scan_tool_input(tool_name: str, params: dict) -> ScanResult:
    """Scan all string values in tool parameters, including nested structures."""
    for key, value in params.items():
        strings = _extract_strings(value)
        for s in strings:
            result = scan(s)
            if result.verdict != "pass":
                return ScanResult(
                    result.verdict,
                    f"Tool '{tool_name}' param '{key}': {result.reason}",
                )
    return ScanResult("pass")
