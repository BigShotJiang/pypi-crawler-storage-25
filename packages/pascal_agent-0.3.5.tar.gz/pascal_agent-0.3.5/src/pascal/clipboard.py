"""Clipboard helper -- text-only get/set via pywin32 with pyperclip fallback."""

from __future__ import annotations


def get_text() -> str:
    """Read text from clipboard."""
    try:
        import win32clipboard
    except ImportError:
        import pyperclip
        return str(pyperclip.paste() or "")

    win32clipboard.OpenClipboard()
    try:
        if win32clipboard.IsClipboardFormatAvailable(win32clipboard.CF_UNICODETEXT):
            data = win32clipboard.GetClipboardData(win32clipboard.CF_UNICODETEXT)
            return str(data) if data else ""
        return ""
    finally:
        win32clipboard.CloseClipboard()


def set_text(text: str) -> None:
    """Write text to clipboard."""
    try:
        import win32clipboard
    except ImportError:
        import pyperclip
        pyperclip.copy(text)
        return

    win32clipboard.OpenClipboard()
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(text, win32clipboard.CF_UNICODETEXT)
    finally:
        win32clipboard.CloseClipboard()
