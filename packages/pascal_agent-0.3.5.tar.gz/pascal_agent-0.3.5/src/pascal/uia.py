"""Windows UI Automation adapter -- access native app controls via Accessibility API.

Uses pywinauto with UIA backend. Falls back gracefully on non-Windows platforms.
Ref system: each snapshot assigns short IDs (e1, e2, ...) to controls so the LLM
can refer to them in subsequent actions without needing coordinates.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class UIElement:
    """Lightweight representation of a UIA control for LLM consumption."""
    ref: str
    control_type: str
    name: str
    value: str
    is_enabled: bool
    is_focused: bool

    def to_text(self, indent: int = 0) -> str:
        prefix = "  " * indent
        parts = [f"{prefix}[{self.ref}] {self.control_type}"]
        if self.name:
            parts.append(f"'{self.name}'")
        if self.value:
            display_val = self.value[:100] + ("..." if len(self.value) > 100 else "")
            parts.append(f'value="{display_val}"')
        flags = []
        if self.is_focused:
            flags.append("focused")
        if not self.is_enabled:
            flags.append("disabled")
        if flags:
            parts.append(f"[{', '.join(flags)}]")
        return " ".join(parts)


_INTERACTIVE_TYPES = frozenset({
    "Button", "Edit", "MenuItem", "ListItem", "ComboBox",
    "CheckBox", "RadioButton", "Hyperlink", "Slider", "Spinner",
    "Tab", "TabItem", "TreeItem", "DataItem",
})


class UIAutomationAdapter:
    """Windows UI Automation API wrapper using pywinauto.

    Public methods (7): snapshot, find, click, type_text, get_text, focus_window, wait_for.
    """

    def __init__(self) -> None:
        self._ref_map: dict[str, Any] = {}
        self._ref_counter: int = 0
        self._desktop = None

    def _get_desktop(self):
        if self._desktop is None:
            from pywinauto import Desktop
            self._desktop = Desktop(backend="uia")
        return self._desktop

    # -- Exploration -----------------------------------------------

    def snapshot(
        self,
        window_title: str | None = None,
        *,
        max_depth: int = 3,
        interactive_only: bool = False,
    ) -> list[UIElement]:
        """Take an accessibility tree snapshot of a window."""
        self.clear_refs()
        win = self._find_window(window_title=window_title)
        if win is None:
            return []
        elements: list[UIElement] = []
        self._walk(win, elements, depth=0, max_depth=max_depth,
                   interactive_only=interactive_only)
        return elements

    def find(
        self,
        *,
        name: str | None = None,
        control_type: str | None = None,
        window_title: str | None = None,
    ) -> list[UIElement]:
        """Search for controls matching criteria (AND combination)."""
        win = self._find_window(window_title=window_title)
        if win is None:
            if window_title:
                return []
            desktop = self._get_desktop()
            results: list[UIElement] = []
            for w in desktop.windows():
                try:
                    if not w.is_visible():
                        continue
                    results.extend(self._search_window(w, name=name, control_type=control_type))
                except Exception:
                    continue
            return results
        return self._search_window(win, name=name, control_type=control_type)

    # -- Actions ---------------------------------------------------

    def click(self, ref: str) -> dict:
        """Click a control by ref ID."""
        wrapper = self._resolve_ref(ref)
        try:
            wrapper.click_input()
            return {"ok": True, "action": "click", "ref": ref}
        except Exception as e:
            return {"ok": False, "error": str(e), "ref": ref}

    def type_text(self, ref: str, text: str, *, clear_first: bool = False) -> dict:
        """Type text into an Edit control."""
        wrapper = self._resolve_ref(ref)
        try:
            if clear_first:
                wrapper.set_edit_text("")
            wrapper.type_keys(text, with_spaces=True, pause=0.02)
            return {"ok": True, "action": "type_text", "ref": ref, "chars": len(text)}
        except Exception as e:
            return {"ok": False, "error": str(e), "ref": ref}

    def get_text(self, ref: str) -> str:
        """Get the current text value of a control."""
        wrapper = self._resolve_ref(ref)
        try:
            for method in ("window_text", "get_value", "texts"):
                try:
                    fn = getattr(wrapper, method, None)
                    if fn is None:
                        continue
                    result = fn()
                    if isinstance(result, list):
                        return "\n".join(str(t) for t in result if t)
                    if result:
                        return str(result)
                except Exception:
                    continue
            return ""
        except Exception:
            return ""

    # -- Window management -----------------------------------------

    def focus_window(self, window_title: str | None = None) -> dict:
        """Bring a window to the foreground."""
        win = self._find_window(window_title=window_title)
        if win is None:
            return {"ok": False, "error": f"Window not found: {window_title}"}
        try:
            win.set_focus()
            return {"ok": True, "action": "focus_window", "title": win.window_text()}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def wait_for(
        self,
        *,
        name: str | None = None,
        control_type: str | None = None,
        window_title: str | None = None,
        timeout: float = 10.0,
    ) -> UIElement | None:
        """Wait for a control to appear. For dialog popup handling."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            results = self.find(name=name, control_type=control_type, window_title=window_title)
            if results:
                return results[0]
            time.sleep(0.3)
        return None

    # -- Internal --------------------------------------------------

    def _assign_ref(self, wrapper) -> str:
        self._ref_counter += 1
        ref = f"e{self._ref_counter}"
        self._ref_map[ref] = wrapper
        return ref

    def _resolve_ref(self, ref: str):
        if ref not in self._ref_map:
            raise KeyError(f"Unknown ref: {ref}. Run snapshot first.")
        wrapper = self._ref_map[ref]
        try:
            wrapper.is_enabled()
        except Exception:
            raise KeyError(f"Stale ref: {ref}. Run snapshot again.")
        return wrapper

    def clear_refs(self) -> None:
        self._ref_map.clear()
        self._ref_counter = 0

    def _find_window(self, window_title: str | None = None):
        desktop = self._get_desktop()
        if window_title:
            title_lower = window_title.lower()
            for win in desktop.windows():
                try:
                    wt = win.window_text() or ""
                    if title_lower in wt.lower():
                        return win
                except Exception:
                    continue
            return None
        # No filter: return the foreground window
        import ctypes
        fg_hwnd = ctypes.windll.user32.GetForegroundWindow()
        if fg_hwnd:
            for win in desktop.windows():
                try:
                    if win.handle == fg_hwnd:
                        return win
                except Exception:
                    continue
        return None

    def _walk(self, wrapper, elements: list[UIElement], depth: int, max_depth: int, interactive_only: bool) -> None:
        if depth > max_depth:
            return
        try:
            ctrl_type = wrapper.element_info.control_type or "Unknown"
            if interactive_only and ctrl_type not in _INTERACTIVE_TYPES and depth > 0:
                for child in wrapper.children():
                    self._walk(child, elements, depth + 1, max_depth, interactive_only)
                return

            name = ""
            try:
                name = wrapper.window_text() or ""
            except Exception:
                pass

            value = ""
            try:
                if ctrl_type in ("Edit", "ComboBox", "Spinner"):
                    for method in ("get_value", "window_text"):
                        fn = getattr(wrapper, method, None)
                        if fn:
                            v = fn()
                            if v:
                                value = str(v)
                                break
            except Exception:
                pass

            ref = self._assign_ref(wrapper)
            elements.append(UIElement(
                ref=ref, control_type=ctrl_type, name=name, value=value,
                is_enabled=wrapper.is_enabled() if hasattr(wrapper, "is_enabled") else True,
                is_focused=wrapper.has_focus() if hasattr(wrapper, "has_focus") else False,
            ))

            for child in wrapper.children():
                self._walk(child, elements, depth + 1, max_depth, interactive_only)
        except Exception as e:
            logger.debug("UIA walk error at depth %d: %s", depth, e)

    def _search_window(self, win, *, name: str | None = None, control_type: str | None = None) -> list[UIElement]:
        results: list[UIElement] = []
        criteria: dict[str, Any] = {}
        if control_type:
            criteria["control_type"] = control_type
        if name:
            import re
            criteria["title_re"] = f".*{re.escape(name)}.*"
        try:
            found = win.descendants(**criteria) if criteria else win.descendants()
            for ctrl in found[:50]:
                try:
                    ct = ctrl.element_info.control_type or "Unknown"
                    cn = ""
                    try:
                        cn = ctrl.window_text() or ""
                    except Exception:
                        pass
                    value = ""
                    try:
                        if ct in ("Edit", "ComboBox"):
                            v = ctrl.get_value() if hasattr(ctrl, "get_value") else ""
                            value = str(v) if v else ""
                    except Exception:
                        pass
                    ref = self._assign_ref(ctrl)
                    results.append(UIElement(
                        ref=ref, control_type=ct, name=cn, value=value,
                        is_enabled=ctrl.is_enabled(), is_focused=False,
                    ))
                except Exception:
                    continue
        except Exception as e:
            logger.debug("UIA search error: %s", e)
        return results


def render_snapshot(elements: list[UIElement], window_title: str = "") -> str:
    lines = []
    if window_title:
        lines.append(f'Window: "{window_title}"')
        lines.append("─" * 40)
    for elem in elements:
        lines.append(elem.to_text())
    return "\n".join(lines)
