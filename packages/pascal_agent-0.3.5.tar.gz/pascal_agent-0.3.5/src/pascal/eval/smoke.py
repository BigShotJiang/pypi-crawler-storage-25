"""Smoke test harness -- 5 core scenarios that must pass for Pascal to be viable.

Run: python -m pascal.eval.smoke

1. Task lifecycle: receive → plan → execute → complete
2. Interrupt: notification arrives mid-task → pause → handle → resume
3. Escalation: agent encounters uncertainty → escalate → loop stops
4. Self-learning: agent adds a rule → rule visible in next loop
5. Governor: agent loops → detected → stopped
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Callable

from pascal.loop import run_loop
from pascal.state import PascalStore
from pascal.types import LLMResponse


class _MockLLM:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self._i = 0

    async def chat(self, messages, tools=None):
        if self._i >= len(self._responses):
            return LLMResponse(text=json.dumps({"action": "wait", "reason": "out"}))
        text = self._responses[self._i]
        self._i += 1
        return LLMResponse(text=text)


def _j(**kwargs) -> str:
    return json.dumps(kwargs)


async def _run_scenario(
    name: str,
    store: PascalStore,
    responses: list[str],
    validate: "Callable",
) -> tuple[bool, str]:
    llm = _MockLLM(responses)
    actions = await run_loop(store, llm, max_iterations=15)
    try:
        validate(store, actions)
        return True, f"  PASS: {name}"
    except AssertionError as e:
        return False, f"  FAIL: {name} -- {e}"


async def run_all(tmp_dir: str | None = None) -> dict[str, Any]:
    import tempfile
    base = Path(tmp_dir) if tmp_dir else Path(tempfile.mkdtemp())
    results: list[tuple[bool, str]] = []

    # 1. Task lifecycle
    store = PascalStore(str(base / "s1.db"))
    t1_id = store.add_task("Write hello.txt")

    def v1(s, actions):
        types = [a["action"] for a in actions]
        assert "pick_task" in types, "should pick task"
        assert "complete_task" in types or "wait" in types, "should complete or wait"

    results.append(await _run_scenario("Task lifecycle", store, [
        _j(action="pick_task", task_id=t1_id, reason="start"),
        _j(action="execute", command="echo hello > hello.txt", reason="write"),
        _j(action="complete_task", summary="Created hello.txt", reason="done"),
        _j(action="wait", reason="done"),
    ], v1))
    store.close()

    # 2. Interrupt handling
    store = PascalStore(str(base / "s2.db"))
    task_id = store.add_task("Long work")
    store.activate_task(task_id)
    notif_id = store.push_notification(source="slack", message="Server down!", priority="urgent")

    def v2(s, actions):
        types = [a["action"] for a in actions]
        assert "pause_task" in types, "should pause"
        assert "handle_notification" in types, "should handle notification"

    results.append(await _run_scenario("Interrupt", store, [
        _j(action="pause_task", pause_reason="urgent notification", reason="server"),
        _j(action="handle_notification", notification_id=notif_id, response="checking", reason="urgent"),
        _j(action="wait", reason="investigating"),
    ], v2))
    store.close()

    # 3. Escalation
    store = PascalStore(str(base / "s3.db"))
    t3_id = store.add_task("Deploy to prod")

    def v3(s, actions):
        types = [a["action"] for a in actions]
        assert "escalate" in types, "should escalate"

    results.append(await _run_scenario("Escalation", store, [
        _j(action="pick_task", task_id=t3_id, reason="start"),
        _j(action="escalate", question="Prod deploy needs approval", reason="policy"),
    ], v3))
    store.close()

    # 4. Self-learning
    store = PascalStore(str(base / "s4.db"))
    t4_id = store.add_task("Learn something")

    def v4(s, actions):
        rules = s.get_rules()
        assert any("test" in r["rule"].lower() for r in rules), "should have added a rule"

    results.append(await _run_scenario("Self-learning", store, [
        _j(action="pick_task", task_id=t4_id, reason="start"),
        _j(action="add_rule", rule="Always run tests before deploy", reason="learned"),
        _j(action="complete_task", summary="Learned", reason="done"),
        _j(action="wait", reason="done"),
    ], v4))
    store.close()

    # 5. Governor (loop detection)
    store = PascalStore(str(base / "s5.db"))
    t5_id = store.add_task("Stuck task")

    def v5(s, actions):
        assert len(actions) < 15, f"should stop early, got {len(actions)} actions"

    results.append(await _run_scenario("Governor", store, [
        _j(action="pick_task", task_id=t5_id, reason="start"),
        _j(action="execute", command="false", reason="try"),
        _j(action="execute", command="false", reason="retry"),
        _j(action="execute", command="false", reason="retry again"),
        _j(action="execute", command="false", reason="still trying"),
        _j(action="execute", command="false", reason="one more"),
        _j(action="wait", reason="governor should have warned"),
    ], v5))
    store.close()

    # 6. Plan execution (multi-step in one LLM call)
    store = PascalStore(str(base / "s6.db"))
    t6_id = store.add_task("Multi-step work")

    def v6(s, actions):
        plan_actions = [a for a in actions if a["action"] == "plan"]
        assert plan_actions, "should execute a plan"
        plan_result = plan_actions[0]["result"]
        assert plan_result.get("plan_completed"), "plan should complete"
        assert len(plan_result.get("steps", [])) >= 2, "plan should have multiple steps"

    results.append(await _run_scenario("Plan execution", store, [
        _j(action="pick_task", task_id=t6_id, reason="start"),
        _j(action="plan", reason="do two things", steps=[
            {"action": "execute", "command": "echo step1"},
            {"action": "execute", "command": "echo step2"},
        ]),
        _j(action="complete_task", summary="Done via plan", reason="done"),
        _j(action="wait", reason="done"),
    ], v6))
    store.close()

    # 7. Memory search (FTS5 relevance)
    store = PascalStore(str(base / "s7.db"))
    store.add_memory(kind="fact", content="The deploy server runs on port 8080")
    store.add_memory(kind="lesson", content="Always backup before migration")
    store.add_memory(kind="fact", content="Database password is rotated monthly")
    t7_id = store.add_task("Check deploy config")

    def v7(s, actions):
        # Verify memory search finds relevant results
        results = s.search_memories("deploy server", limit=3)
        assert any("8080" in m["content"] for m in results), "should find deploy memory"

    results.append(await _run_scenario("Memory search", store, [
        _j(action="pick_task", task_id=t7_id, reason="start"),
        _j(action="wait", reason="done"),
    ], v7))
    store.close()

    # 8. Conversation thread + dependency gating
    store = PascalStore(str(base / "s8.db"))
    t8a = store.add_task("Build the app")
    t8b = store.add_task("Deploy the app", depends_on=[t8a])

    def v8(s, actions):
        # t8b should NOT be picked (depends on t8a which isn't done)
        from pascal.desk import Desk
        desk = Desk(s)
        rendered = desk.render()
        # t8b should not appear in actionable queue (dependency not met)
        assert t8b not in rendered or "Deploy" not in rendered.split("Task Queue")[1] if "Task Queue" in rendered else True

    results.append(await _run_scenario("Dependency gating", store, [
        _j(action="pick_task", task_id=t8a, reason="build first"),
        _j(action="wait", reason="building"),
    ], v8))
    store.close()

    passed = sum(1 for ok, _ in results if ok)
    total = len(results)
    print(f"\nPascal Smoke Test: {passed}/{total} passed\n")
    for _, msg in results:
        print(msg)

    return {"passed": passed, "total": total, "results": results}


if __name__ == "__main__":
    asyncio.run(run_all())
