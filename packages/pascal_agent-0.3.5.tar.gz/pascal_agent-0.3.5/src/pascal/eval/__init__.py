"""Evaluation harness for Pascal."""
