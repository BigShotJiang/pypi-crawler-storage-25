"""LLM abstraction layer."""
