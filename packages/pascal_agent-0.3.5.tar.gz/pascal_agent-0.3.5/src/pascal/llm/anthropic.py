"""pascal/llm/anthropic.py -- Anthropic 프로바이더."""

from __future__ import annotations

import logging
from types import ModuleType
from typing import TYPE_CHECKING, Any, Literal, TypeAlias

if TYPE_CHECKING:
    from anthropic import AsyncAnthropic
    from anthropic.types import (
        Base64ImageSourceParam,
        ImageBlockParam,
        MessageParam,
        TextBlockParam,
        ToolParam,
        ToolResultBlockParam,
        ToolUseBlockParam,
    )
else:
    AsyncAnthropic = Any
    Base64ImageSourceParam = dict[str, object]
    ImageBlockParam = dict[str, object]
    MessageParam = dict[str, object]
    TextBlockParam = dict[str, object]
    ToolParam = dict[str, object]
    ToolResultBlockParam = dict[str, object]
    ToolUseBlockParam = dict[str, object]

try:
    import anthropic as anthropic_module
except ImportError:  # pragma: no cover - optional dependency
    anthropic: ModuleType | None = None
else:
    anthropic = anthropic_module

from pascal.types import ContentBlock, LLMResponse, Message, Role, ToolCall

logger = logging.getLogger(__name__)

AnthropicImageMediaType = Literal["image/jpeg", "image/png", "image/gif", "image/webp"]
AnthropicContentBlock: TypeAlias = TextBlockParam | ImageBlockParam
AnthropicAssistantBlock: TypeAlias = AnthropicContentBlock | ToolUseBlockParam


class AnthropicProvider:
    """Anthropic Claude API를 사용하는 LLM 프로바이더."""

    _client: AsyncAnthropic

    def __init__(self, model: str = "claude-sonnet-4-20250514", base_url: str = "") -> None:
        if anthropic is None:
            raise ImportError(
                "Anthropic provider requires optional dependency: pip install pascal[anthropic]"
            )
        from anthropic import AsyncAnthropic

        if base_url:
            self._client = AsyncAnthropic(base_url=base_url)
        else:
            self._client = AsyncAnthropic()
        self._model = model

    async def chat(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        system_parts: list[str] = []
        api_messages: list[MessageParam] = []

        for m in messages:
            if m.role == Role.SYSTEM:
                system_parts.append(m.content)
            elif m.role == Role.ASSISTANT:
                content = self._build_assistant_content(m)
                assistant_message: MessageParam = {"role": "assistant", "content": content}
                api_messages.append(assistant_message)
            elif m.role == Role.TOOL:
                tool_result: ToolResultBlockParam = {
                    "type": "tool_result",
                    "tool_use_id": m.tool_call_id,
                    "content": m.content,
                }
                tool_result_message: MessageParam = {"role": "user", "content": [tool_result]}
                api_messages.append(tool_result_message)
            else:
                api_messages.append(self._convert_user_message(m))

        system = "\n\n".join(system_parts) if system_parts else None
        converted_tools = self._convert_tools(tools) if tools else None

        if system is not None and converted_tools is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                system=system,
                tools=converted_tools,
            )
        elif system is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                system=system,
            )
        elif converted_tools is not None:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
                tools=converted_tools,
            )
        else:
            response = await self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=api_messages,
            )
        return self._parse_response(response)

    def _build_assistant_content(self, msg: Message) -> list[AnthropicAssistantBlock] | str:
        content: list[AnthropicAssistantBlock] = list(self._build_content_blocks(msg))
        tool_calls = getattr(msg, "tool_calls", None) or []
        if not tool_calls:
            return content or msg.content

        for tc in tool_calls:
            content.append(
                {
                    "type": "tool_use",
                    "id": tc.id,
                    "name": tc.name,
                    "input": tc.params,
                }
            )
        return content

    def _convert_user_message(self, msg: Message) -> MessageParam:
        content = self._build_content_blocks(msg)
        return {"role": "user", "content": content or msg.content}

    def _build_content_blocks(self, msg: Message) -> list[AnthropicContentBlock]:
        content: list[AnthropicContentBlock] = []
        if msg.content:
            content.append({"type": "text", "text": msg.content})
        for attachment in msg.attachments:
            block = self._convert_attachment(attachment)
            if block is not None:
                content.append(block)
        return content

    def _convert_attachment(self, attachment: ContentBlock) -> AnthropicContentBlock | None:
        if attachment.type == "image":
            media_type = self._normalize_image_media_type(attachment.mime_type)
            if media_type is None:
                logger.warning("Unsupported Anthropic image media type: %s", attachment.mime_type)
                return None
            source: Base64ImageSourceParam = {
                "type": "base64",
                "media_type": media_type,
                "data": attachment.data,
            }
            image_block: ImageBlockParam = {
                "type": "image",
                "source": source,
            }
            return image_block
        if attachment.type == "text":
            text_block: TextBlockParam = {"type": "text", "text": attachment.data}
            return text_block

        logger.warning("Unsupported content block for Anthropic provider: %s", attachment.type)
        return None

    @staticmethod
    def _normalize_image_media_type(mime_type: str) -> AnthropicImageMediaType | None:
        if mime_type == "image/jpeg":
            return "image/jpeg"
        if mime_type == "image/png":
            return "image/png"
        if mime_type == "image/gif":
            return "image/gif"
        if mime_type == "image/webp":
            return "image/webp"
        return None

    @staticmethod
    def _convert_tools(tools: list[dict]) -> list[ToolParam]:
        default_schema: dict[str, object] = {"type": "object", "properties": {}}
        result: list[ToolParam] = []
        for t in tools:
            func = t.get("function", t)
            name: str = func["name"]
            description: str = func.get("description", "")
            input_schema: dict[str, object] = func.get("parameters", default_schema)
            result.append(
                {
                    "name": name,
                    "description": description,
                    "input_schema": input_schema,
                }
            )
        return result

    @staticmethod
    def _parse_response(response) -> LLMResponse:
        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCall(
                        id=block.id,
                        name=block.name,
                        params=block.input,
                    )
                )

        text = "\n".join(text_parts) if text_parts else None
        return LLMResponse(text=text, tool_calls=tool_calls)
