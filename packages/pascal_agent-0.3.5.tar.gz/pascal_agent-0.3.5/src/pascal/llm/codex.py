"""pascal/llm/codex.py -- ChatGPT OAuth + Responses API provider.

Uses the same auth as Codex CLI (~/.codex/auth.json).
Calls https://chatgpt.com/backend-api/codex/responses (NOT standard OpenAI API).
"""

from __future__ import annotations

import json
import logging
import platform
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from pascal.types import LLMResponse, Message, Role, TokenUsage, ToolCall

logger = logging.getLogger(__name__)

_CODEX_URL = "https://chatgpt.com/backend-api/codex/responses"
_TOKEN_URL = "https://auth.openai.com/oauth/token"
_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_AUTH_PATH = Path.home() / ".codex" / "auth.json"


class CodexProvider:
    """ChatGPT Pro/Plus OAuth provider using Codex Responses API."""

    def __init__(self, model: str = "gpt-5.4-mini") -> None:
        self._model = model
        self._access_token: str = ""
        self._refresh_token: str = ""
        self._account_id: str = ""
        self._expires_at: float = 0.0
        self._load_auth()

    def _load_auth(self) -> None:
        if not _AUTH_PATH.exists():
            raise FileNotFoundError(
                f"Codex auth not found at {_AUTH_PATH}. Run 'codex auth login' first."
            )
        data = json.loads(_AUTH_PATH.read_text(encoding="utf-8"))
        tokens = data.get("tokens", {})
        self._access_token = tokens.get("access_token", "")
        self._refresh_token = tokens.get("refresh_token", "")
        self._account_id = tokens.get("account_id", "")
        if not self._account_id:
            self._account_id = self._extract_account_id(tokens.get("id_token", ""))
        # Decode expiry from access token JWT
        self._expires_at = self._jwt_exp(self._access_token)

    def _refresh_if_needed(self) -> None:
        if time.time() < self._expires_at - 60:
            return
        if not self._refresh_token:
            raise RuntimeError("No refresh token. Run 'codex auth login'.")
        logger.info("Refreshing Codex OAuth token...")
        body = urllib.parse.urlencode({
            "grant_type": "refresh_token",
            "refresh_token": self._refresh_token,
            "client_id": _CLIENT_ID,
        }).encode()
        req = urllib.request.Request(
            _TOKEN_URL, data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
        self._access_token = result["access_token"]
        if "refresh_token" in result:
            self._refresh_token = result["refresh_token"]
        self._expires_at = self._jwt_exp(self._access_token)
        if not self._account_id:
            self._account_id = self._extract_account_id(self._access_token)
        # Save back to auth.json
        self._save_auth()
        logger.info("Token refreshed, expires at %s", time.ctime(self._expires_at))

    def _save_auth(self) -> None:
        data = json.loads(_AUTH_PATH.read_text(encoding="utf-8"))
        data["tokens"]["access_token"] = self._access_token
        if self._refresh_token:
            data["tokens"]["refresh_token"] = self._refresh_token
        if self._account_id:
            data["tokens"]["account_id"] = self._account_id
        _AUTH_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")

    async def chat(self, messages: list[Message], tools: list[dict] | None = None) -> LLMResponse:
        self._refresh_if_needed()
        body = self._build_body(messages, tools)
        headers = self._build_headers()
        return await self._stream_request(headers, body)

    def _build_headers(self) -> dict[str, str]:
        h = {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "OpenAI-Beta": "responses=experimental",
            "originator": "pascal",
            "User-Agent": f"pascal/0.2.0 ({platform.system()} {platform.release()}; {platform.machine()})",
        }
        if self._account_id:
            h["ChatGPT-Account-Id"] = self._account_id
        return h

    def _build_body(self, messages: list[Message], tools: list[dict] | None) -> dict:
        instructions = ""
        input_items: list[dict] = []

        for msg in messages:
            if msg.role == Role.SYSTEM:
                instructions += msg.content + "\n"
            elif msg.role == Role.USER:
                content = self._convert_user_content(msg)
                input_items.append({"role": "user", "content": content})
            elif msg.role == Role.ASSISTANT:
                input_items.extend(self._convert_assistant_items(msg))
            elif msg.role == Role.TOOL:
                input_items.append(self._convert_tool_output(msg))

        body: dict[str, Any] = {
            "model": self._model,
            "store": False,
            "stream": True,
            "instructions": instructions.strip(),
            "input": input_items,
        }
        if tools:
            body["tools"] = self._convert_tools(tools)
            body["tool_choice"] = "auto"
        return body

    @staticmethod
    def _convert_assistant_items(msg: Message) -> list[dict]:
        items: list[dict] = []
        tool_calls = list(getattr(msg, "tool_calls", None) or [])
        content = [{"type": "output_text", "text": msg.content}] if msg.content else []

        if content or not tool_calls:
            items.append({
                "type": "message",
                "role": "assistant",
                "content": content or [{"type": "output_text", "text": ""}],
                "status": "completed",
            })

        for tc in tool_calls:
            items.append({
                "type": "function_call",
                "call_id": tc.id,
                "name": tc.name,
                "arguments": json.dumps(tc.params),
            })

        return items

    @staticmethod
    def _convert_tool_output(msg: Message) -> dict:
        return {
            "type": "function_call_output",
            "call_id": msg.tool_call_id,
            "output": msg.content,
        }

    def _convert_user_content(self, msg: Message) -> list[dict]:
        blocks: list[dict] = []
        if msg.content:
            blocks.append({"type": "input_text", "text": msg.content})
        for att in msg.attachments:
            if att.type == "image":
                blocks.append({
                    "type": "input_image",
                    "image_url": f"data:{att.mime_type};base64,{att.data}",
                    "detail": att.detail,
                })
        return blocks or [{"type": "input_text", "text": ""}]

    @staticmethod
    def _convert_tools(tools: list[dict]) -> list[dict]:
        converted = []
        for t in tools:
            fn = t.get("function", t)
            converted.append({
                "type": "function",
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {}),
                "strict": None,
            })
        return converted

    async def _stream_request(self, headers: dict, body: dict) -> LLMResponse:
        import httpx
        text_parts: list[str] = []
        usage: TokenUsage | None = None
        # Track function calls being built: output_index -> {call_id, name, arg_parts}
        fn_calls: dict[int, dict[str, Any]] = {}

        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream(
                "POST", _CODEX_URL, headers=headers,
                json=body,
            ) as response:
                if response.status_code != 200:
                    error_body = await response.aread()
                    raise RuntimeError(
                        f"Codex API {response.status_code}: {error_body.decode()[:500]}"
                    )
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_str, buffer = buffer.split("\n\n", 1)
                        for line in event_str.split("\n"):
                            if line.startswith("data: "):
                                data = line[6:]
                                if data == "[DONE]":
                                    continue
                                try:
                                    evt = json.loads(data)
                                except json.JSONDecodeError:
                                    continue
                                self._handle_event(evt, text_parts, fn_calls)
                                # Extract usage from completed event
                                if evt.get("type") in ("response.completed", "response.done"):
                                    resp_obj = evt.get("response", {})
                                    u = resp_obj.get("usage", {})
                                    if u:
                                        usage = TokenUsage(
                                            prompt_tokens=u.get("input_tokens", 0),
                                            completion_tokens=u.get("output_tokens", 0),
                                            total_tokens=u.get("total_tokens", 0),
                                        )

        # Build ToolCall list from completed function calls
        tool_calls: list[ToolCall] = []
        for idx in sorted(fn_calls):
            fc = fn_calls[idx]
            args_str = "".join(fc.get("arg_parts", []))
            try:
                params = json.loads(args_str) if args_str else {}
            except (json.JSONDecodeError, ValueError):
                params = {}
            tool_calls.append(ToolCall(
                id=fc.get("call_id", ""),
                name=fc.get("name", ""),
                params=params,
            ))

        return LLMResponse(
            text="".join(text_parts) or None,
            tool_calls=tool_calls,
            usage=usage or TokenUsage(),
        )

    @staticmethod
    def _handle_event(
        evt: dict,
        text_parts: list[str],
        fn_calls: dict[int, dict[str, Any]],
    ) -> None:
        evt_type = evt.get("type", "")
        if evt_type == "response.output_text.delta":
            delta = evt.get("delta", "")
            if delta:
                text_parts.append(delta)
        elif evt_type == "response.output_item.added":
            item = evt.get("item", {})
            if item.get("type") == "function_call":
                idx = evt.get("output_index", 0)
                fn_calls[idx] = {
                    "call_id": item.get("call_id", ""),
                    "name": item.get("name", ""),
                    "arg_parts": [item.get("arguments", "")],
                }
        elif evt_type == "response.function_call_arguments.delta":
            idx = evt.get("output_index", 0)
            delta = evt.get("delta", "")
            if idx in fn_calls and delta:
                fn_calls[idx]["arg_parts"].append(delta)
        elif evt_type == "response.output_item.done":
            item = evt.get("item", {})
            if item.get("type") == "function_call":
                idx = evt.get("output_index", 0)
                # If we missed the .added event, populate from the done event
                if idx not in fn_calls:
                    fn_calls[idx] = {
                        "call_id": item.get("call_id", ""),
                        "name": item.get("name", ""),
                        "arg_parts": [item.get("arguments", "")],
                    }
                else:
                    # Update call_id/name in case they were empty in the added event
                    fc = fn_calls[idx]
                    if not fc.get("call_id"):
                        fc["call_id"] = item.get("call_id", "")
                    if not fc.get("name"):
                        fc["name"] = item.get("name", "")
        elif evt_type == "response.failed":
            error = evt.get("response", {}).get("error", {})
            raise RuntimeError(f"Codex API error: {error}")

    @staticmethod
    def _jwt_exp(token: str) -> float:
        if not token:
            return 0.0
        try:
            import base64
            payload = token.split(".")[1]
            payload += "=" * (4 - len(payload) % 4)
            data = json.loads(base64.b64decode(payload))
            return float(data.get("exp", 0))
        except Exception:
            return 0.0

    @staticmethod
    def _extract_account_id(token: str) -> str:
        if not token:
            return ""
        try:
            import base64
            payload = token.split(".")[1]
            payload += "=" * (4 - len(payload) % 4)
            data = json.loads(base64.b64decode(payload))
            auth = data.get("https://api.openai.com/auth", {})
            return auth.get("chatgpt_account_id", "")
        except Exception:
            return ""
