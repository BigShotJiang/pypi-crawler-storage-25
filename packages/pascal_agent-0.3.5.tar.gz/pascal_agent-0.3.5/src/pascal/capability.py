"""Capability tracking for Pascal's domain-level trust map."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from typing import Any, ClassVar, Literal


DEFAULT_DOMAINS: dict[str, float] = {
    "email": 0.5,
    "scheduling": 0.5,
    "file_ops": 0.5,
    "communication": 0.5,
    "analysis": 0.5,
    "planning": 0.5,
}

_CAPABILITY_SCHEMA = """
CREATE TABLE IF NOT EXISTS capability (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
"""

_CAPABILITY_KEY = "trust_map"
_SUCCESS_DELTA = 0.02
_JUDGMENT_FAILURE_DELTA = 0.10
_NEUTRAL_TRUST = 0.5
_HIGH_ERROR_STREAK = 3
_VERY_HIGH_ERROR_STREAK = 5
_HIGH_ERROR_PENALTY = 0.15
_VERY_HIGH_ERROR_PENALTY = 0.25

Decision = Literal["go", "caution", "block"]


def infer_domain(action_type: str | None, tool_name: str | None) -> str:
    """Infer a capability domain from an action and tool name."""
    haystack = f"{action_type or ''} {tool_name or ''}".lower()

    if _contains_any(haystack, ("email", "gmail", "mail", "inbox")):
        return "email"
    if _contains_any(haystack, ("schedule", "calendar", "meeting", "reminder", "cron")):
        return "scheduling"
    if _contains_any(haystack, ("file", "filesystem", "directory", "path", "read", "write", "edit")):
        return "file_ops"
    if _contains_any(haystack, ("telegram", "message", "chat", "notify", "slack", "discord", "sms")):
        return "communication"
    if _contains_any(haystack, ("plan", "todo", "task", "roadmap", "outline", "planner")):
        return "planning"
    return "analysis"


@dataclass
class TrustMap:
    """Domain-specific trust scores with asymmetric learning."""

    domains: dict[str, float] = field(default_factory=lambda: dict(DEFAULT_DOMAINS))

    DOMAIN_NAMES: ClassVar[tuple[str, ...]] = tuple(DEFAULT_DOMAINS)

    def __post_init__(self) -> None:
        merged_domains = dict(DEFAULT_DOMAINS)
        merged_domains.update(self.domains)
        self.domains = {name: _clamp_score(score) for name, score in merged_domains.items()}

    @property
    def overall(self) -> float:
        """Average domain score for backward compatibility."""
        return sum(self.domains.values()) / len(self.domains)

    def update_on_success(self, domain: str) -> float:
        """Increase trust slowly after a successful action."""
        key = _require_domain(domain)
        self.domains[key] = _clamp_score(self.domains[key] + _SUCCESS_DELTA)
        return self.domains[key]

    def update_on_failure(self, domain: str, is_judgment_error: bool) -> float:
        """Penalize only Pascal's judgment mistakes, not tool or env failures."""
        key = _require_domain(domain)
        if is_judgment_error:
            self.domains[key] = _clamp_score(self.domains[key] - _JUDGMENT_FAILURE_DELTA)
        return self.domains[key]

    def to_dict(self) -> dict[str, Any]:
        return {"domains": dict(self.domains)}

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "TrustMap":
        if not isinstance(data, dict):
            return cls()
        domains = data.get("domains")
        return cls(
            domains=domains if isinstance(domains, dict) else dict(DEFAULT_DOMAINS),
        )

    def save(self, conn: sqlite3.Connection) -> None:
        """Persist the trust map as JSON in the capability table."""
        _ensure_capability_table(conn)
        payload = json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True)
        conn.execute(
            """INSERT INTO capability (key, value, updated_at)
               VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'))
               ON CONFLICT(key) DO UPDATE SET
                   value = excluded.value,
                   updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')""",
            (_CAPABILITY_KEY, payload),
        )
        conn.commit()

    @classmethod
    def load(cls, conn: sqlite3.Connection) -> "TrustMap":
        """Load the persisted trust map or return defaults."""
        _ensure_capability_table(conn)
        row = conn.execute(
            "SELECT value FROM capability WHERE key = ?",
            (_CAPABILITY_KEY,),
        ).fetchone()
        if row is None:
            return cls()
        try:
            return cls.from_dict(json.loads(row[0]))
        except (json.JSONDecodeError, TypeError):
            return cls()


def compute_threshold(
    effect_level: str,
    *,
    trust_map: TrustMap | None = None,
    domain: str | None = None,
    recent_error_streak: int = 0,
) -> Decision:
    """Return a simple action gate from effect level, trust, and recent failures.

    This heuristic intentionally ignores any LLM self-reported confidence.
    """
    level = _normalize_effect_level(effect_level)
    if level == "E0":
        return "go"
    if level == "E5":
        return "block"

    readiness_score = _readiness_score(
        trust_map=trust_map,
        domain=domain,
        recent_error_streak=recent_error_streak,
    )

    if level == "E1":
        return "go" if readiness_score >= 0.3 else "caution"
    if level == "E2":
        return "go" if readiness_score >= 0.4 else "caution"
    if level == "E3":
        return "go" if readiness_score >= 0.6 else "caution"
    if readiness_score < 0.4:
        return "block"
    return "caution"


def _ensure_capability_table(conn: sqlite3.Connection) -> None:
    conn.execute(_CAPABILITY_SCHEMA)
    conn.commit()


def _normalize_effect_level(effect_level: str) -> str:
    if effect_level in {"E0", "E1", "E2", "E3", "E4", "E5"}:
        return effect_level
    return "E2"


def _readiness_score(
    *,
    trust_map: TrustMap | None,
    domain: str | None,
    recent_error_streak: int,
) -> float:
    trust_score = _domain_trust(trust_map, domain)
    penalty = _error_streak_penalty(recent_error_streak)
    return _clamp_score(trust_score - penalty)


def _domain_trust(trust_map: TrustMap | None, domain: str | None) -> float:
    if trust_map is None:
        return _NEUTRAL_TRUST
    if domain is not None and domain in trust_map.domains:
        return trust_map.domains[domain]
    return trust_map.overall


def _error_streak_penalty(recent_error_streak: int) -> float:
    streak = max(0, int(recent_error_streak))
    if streak >= _VERY_HIGH_ERROR_STREAK:
        return _VERY_HIGH_ERROR_PENALTY
    if streak >= _HIGH_ERROR_STREAK:
        return _HIGH_ERROR_PENALTY
    return 0.0


def _require_domain(domain: str) -> str:
    if domain not in DEFAULT_DOMAINS:
        raise KeyError(f"Unknown capability domain: {domain}")
    return domain


def _contains_any(text: str, needles: tuple[str, ...]) -> bool:
    return any(needle in text for needle in needles)


def _clamp_score(value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = 0.0
    return round(min(1.0, max(0.0, number)), 6)
