"""python -m pascal -- run the Pascal loop."""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from textwrap import dedent

# Force UTF-8 output on Windows (fixes Korean/CJK text garbling)
if sys.platform == "win32":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass

from pascal.config import load_config
from pascal.receipts import Ledger
from pascal.loop import run_loop
from pascal.state import PascalStore

_MAIN_EPILOG = dedent(
    """\
    Examples:
      pascal "Review today's inbox and draft replies"
      pascal --status
      pascal --notify "Build finished"
      pascal init
      pascal --init
    """
)

_INIT_EPILOG = dedent(
    """\
    Examples:
      pascal init
      pascal --init
    """
)

_DEFAULT_CONFIG_TOML = dedent(
    """\
    [pascal]
    # model = "gpt-5.4-mini"
    # provider = "openai"  # openai | anthropic | codex
    # db_path = "~/.pascal/state.db"
    # max_effect = "E2"  # E0(read) E1(analyze) E2(write) E3(push) E4(merge) E5(delete)
    # max_tool_rounds = 10
    """
)

_CONFIG_KEYS = {
    "model": "LLM model name (e.g. gpt-4o, claude-sonnet-4-20250514, o3)",
    "provider": "LLM provider: openai | anthropic | codex",
    "base_url": "API base URL override",
    "db_path": "SQLite database path",
    "max_effect": "Max effect level: E0-E5",
    "max_tool_rounds": "Max tool call rounds per turn",
}

_PROVIDERS = ("openai", "anthropic", "codex")
_EFFECTS = ("E0", "E1", "E2", "E3", "E4", "E5")


_SPINNER_FRAMES = ["|", "/", "-", "\\"]
_active_model = ""  # set before loop starts

# Background spinner state
_spinner_running = False
_spinner_thread = None
_spinner_msg = "thinking..."


def _start_spinner(msg: str = "thinking...") -> None:
    """Start background spinner thread."""
    import threading
    global _spinner_running, _spinner_thread, _spinner_msg
    _spinner_msg = msg
    if _spinner_running:
        return
    _spinner_running = True

    def _spin_loop():
        import time
        idx = 0
        while _spinner_running:
            frame = _SPINNER_FRAMES[idx % len(_SPINNER_FRAMES)]
            model_tag = f" ({_active_model})" if _active_model else ""
            print(f"\r  {frame} {_spinner_msg}{model_tag}   ", end="", flush=True)
            idx += 1
            time.sleep(0.15)

    _spinner_thread = threading.Thread(target=_spin_loop, daemon=True)
    _spinner_thread.start()


def _stop_spinner(clear: bool = True) -> None:
    """Stop background spinner and clear the line."""
    global _spinner_running, _spinner_thread
    _spinner_running = False
    if _spinner_thread:
        _spinner_thread.join(timeout=1)
        _spinner_thread = None
    if clear:
        print(f"\r{' ' * 60}\r", end="", flush=True)


# Actions hidden from user (internal bookkeeping)
_SILENT_ACTIONS = frozenset({
    "think", "pick_task", "add_todo", "complete_todo", "memorize",
    "add_rule", "remove_rule", "set_context", "dismiss_notification",
    "pause_task", "block_task", "create_subtask",
})


def _print_action(action: dict) -> None:
    a = action.get("action", "?")
    reason = action.get("reason", "")
    result = action.get("result", {})
    error = result.get("error", "") if isinstance(result, dict) else ""
    output = result.get("output", "") if isinstance(result, dict) else ""

    # Silent actions: start/keep spinner
    if a in _SILENT_ACTIONS:
        _start_spinner("thinking...")
        return

    # Visible action: stop spinner, print result
    _stop_spinner()

    if a == "execute":
        tool = result.get("tool", "") if isinstance(result, dict) else ""
        label = tool or reason[:60] or "running"
        if error:
            print(f"  x {label} -- {error[:80]}")
        elif output:
            preview = output.strip().split("\n")[0][:80]
            print(f"  > {label} -> {preview}")
        else:
            print(f"  > {label}")

    elif a == "delegate":
        tool = result.get("tool", "agent") if isinstance(result, dict) else "agent"
        print(f"  -> delegating to {tool}...")

    elif a == "plan":
        count = result.get("executed", 0) if isinstance(result, dict) else 0
        print(f"  > planning ({count} steps)")

    elif a == "complete_task":
        summary = result.get("summary", reason) if isinstance(result, dict) else reason
        print(f"\n  Done: {summary[:120]}")

    elif a == "fail_task":
        print(f"\n  Failed: {reason[:120]}")

    elif a == "escalate":
        question = action.get("question", reason) if isinstance(action, dict) else reason
        print(f"\n  ? {question[:120]}")

    elif a == "wait":
        pass  # silent

    elif a == "text_response":
        # LLM replied with plain text (no tool calls) — show directly
        text = result.get("text", reason) if isinstance(result, dict) else reason
        if text:
            print(f"\n  {text}\n")

    elif a == "handle_notification":
        reply = result.get("reply_text", "") if isinstance(result, dict) else ""
        if reply and reply.upper() != "NO_REPLY":
            print(f"\n  {reply}")
        else:
            response = result.get("response", "") if isinstance(result, dict) else ""
            if response:
                print(f"\n  {response[:120]}")

    else:
        # Fallback for unknown actions
        print(f"  {a}: {reason[:60]}")


def _resolve_max_tool_rounds(config, args, *, daemon_mode: bool) -> int:
    """Resolve max_tool_rounds: CLI > config > mode default. max_inner_turns is deprecated alias."""
    # Explicit max_tool_rounds takes priority
    cli_rounds = getattr(args, "max_tool_rounds", None) if args else None
    if cli_rounds is not None:
        return max(1, int(cli_rounds))
    config_rounds = getattr(config, "max_tool_rounds", None)
    if config_rounds is not None:
        return max(1, int(config_rounds))
    # Deprecated alias: max_inner_turns
    cli_turns = getattr(args, "max_inner_turns", None) if args else None
    if cli_turns is not None:
        return max(1, int(cli_turns))
    config_turns = getattr(config, "max_inner_turns", None)
    if config_turns is not None:
        return max(1, int(config_turns))
    return 3 if daemon_mode else 1


async def _run(args, config) -> None:
    store = PascalStore(config.db_path)

    # Seed initial task if provided
    if args.task:
        promised_to = json.loads(args.promised_to) if getattr(args, "promised_to", None) else None
        proof_required = json.loads(args.proof_required) if getattr(args, "proof_required", None) else None
        task_id = store.add_task(
            args.task, source="cli",
            promised_to=promised_to,
            due_at=getattr(args, "due", None),
            proof_required=proof_required,
        )
        print(f"Task created: {task_id}")

    # Seed mission if provided
    if args.mission:
        store.set_context("mission", args.mission)

    # Create LLM provider
    from pascal.config import create_llm
    llm = create_llm(config)

    # Audit ledger (hash-chained)
    from pathlib import Path
    ledger_path = Path(config.db_path).parent / "audit.jsonl"
    ledger = Ledger(str(ledger_path))

    # MCP servers (if configured)
    from pascal.mcp import MCPManager
    mcp_manager = MCPManager()
    mcp_configs = _load_mcp_configs(config)
    if mcp_configs:
        await mcp_manager.connect_all(mcp_configs)

    print(f"Pascal loop starting (model: {config.model})")
    print(f"DB: {config.db_path}")
    print(f"Ledger: {ledger_path}")
    if mcp_manager.connected_servers:
        print(f"MCP: {', '.join(mcp_manager.connected_servers)}")
    print()

    try:
        actions = await run_loop(
            store, llm,
            verifier_llm=llm,
            ledger=ledger,
            mcp_manager=mcp_manager if mcp_manager.connected_servers else None,
            max_effect=getattr(args, "max_effect", None) or config.max_effect,
            max_iterations=args.max_iterations,
            max_tool_rounds=_resolve_max_tool_rounds(config, args, daemon_mode=False),
            on_action=_print_action,
        )
    finally:
        await mcp_manager.disconnect_all()

    print(f"\nLoop ended after {len(actions)} action(s).")
    store.close()


async def _resume_run(args, config) -> None:
    store = PascalStore(config.db_path)
    task_id = args.resume
    task = store.connection.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if task is None:
        print(f"Task {task_id} not found", file=sys.stderr)
        sys.exit(1)
    if task["status"] in ("done", "failed"):
        print(f"Task {task_id} is {task['status']}, cannot resume", file=sys.stderr)
        sys.exit(1)
    # Reactivate if paused/blocked
    if task["status"] in ("paused", "blocked"):
        store.activate_task(task_id)
        print(f"Task {task_id} reactivated from {task['status']}")

    from pascal.config import create_llm
    llm = create_llm(config)

    cp = store.get_latest_checkpoint(task_id)
    if cp:
        print(f"Resuming from checkpoint (iteration {cp['snapshot'].get('iteration', '?')})")
    print(f"Pascal resuming task: {task['goal']}")

    # Audit ledger + verifier (same as main path)
    from pathlib import Path as _Path
    ledger_path = _Path(config.db_path).parent / "audit.jsonl"
    ledger = Ledger(str(ledger_path))

    actions = await run_loop(
        store, llm,
        verifier_llm=llm,
        ledger=ledger,
        max_effect=getattr(args, "max_effect", None),
        max_iterations=args.max_iterations,
        max_tool_rounds=_resolve_max_tool_rounds(config, args, daemon_mode=False),
        on_action=_print_action,
    )
    print(f"\nLoop ended after {len(actions)} action(s).")
    store.close()


def _resume(args, config) -> None:
    asyncio.run(_resume_run(args, config))


def _notify(args, config) -> None:
    """Push a notification into Pascal's desk."""
    store = PascalStore(config.db_path)
    notif_id = store.push_notification(
        source=args.notify_source or "cli",
        message=args.notify,
        priority=args.notify_priority or "normal",
    )
    print(f"Notification pushed: {notif_id}")
    store.close()


def _status(config) -> None:
    """Print Pascal's current desk state."""
    import sys
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    from pascal.desk import Desk
    store = PascalStore(config.db_path)
    desk = Desk(store)
    print(desk.render())
    store.close()


def _add_rule(args, config) -> None:
    store = PascalStore(config.db_path)
    mutable = not args.immutable
    rule_id = store.add_rule(args.add_rule, mutable=mutable, added_by="human")
    lock = " [immutable]" if not mutable else ""
    print(f"Rule added{lock}: {rule_id}")
    store.close()


def _load_mcp_configs(config) -> list:
    """Load MCP server configs from ~/.pascal/mcp.json if it exists."""
    from pascal.mcp import MCPServerConfig
    import json as _json
    mcp_path = Path(config.db_path).expanduser().parent / "mcp.json"
    if not mcp_path.exists():
        return []
    try:
        servers = _json.loads(mcp_path.read_text(encoding="utf-8"))
        return [
            MCPServerConfig(
                name=s["name"], command=s["command"],
                args=s.get("args", []), env=s.get("env"),
            )
            for s in servers
        ]
    except Exception as e:
        print(f"Warning: failed to load MCP config: {e}")
        return []


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pascal",
        description="Pascal CLI for running tasks, checking status, and managing your local workspace.",
        epilog=_MAIN_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--init", action="store_true", help="Create ~/.pascal, pascal.toml, and skills/, then exit")
    parser.add_argument("task", nargs="?", default=None, help="Task to add and execute")
    parser.add_argument("--mission", help="Set the agent's mission")
    parser.add_argument("--status", action="store_true", help="Print current desk state")
    parser.add_argument("--notify", help="Push a notification")
    parser.add_argument("--notify-source", default="cli", help="Notification source")
    parser.add_argument("--notify-priority", choices=["urgent", "normal", "low"], default="normal")
    parser.add_argument("--add-rule", help="Add a behavior rule")
    parser.add_argument("--immutable", action="store_true", help="Make the rule immutable")
    parser.add_argument("--max-iterations", type=int, default=20, help="Max loop iterations")
    parser.add_argument(
        "--max-inner-turns",
        type=int,
        default=None,
        help="Max inner reasoning turns (default: 1 one-shot, 3 daemon; env/TOML supported)",
    )
    parser.add_argument(
        "--max-tool-rounds",
        type=int,
        default=None,
        help="Max tool call rounds per turn (default: None; env/TOML supported)",
    )
    parser.add_argument("--max-effect", choices=["E0", "E1", "E2", "E3", "E4", "E5"],
                        help="Max effect level (default: E2, env: PASCAL_MAX_EFFECT)")
    parser.add_argument("--promised-to", help='JSON array of stakeholders')
    parser.add_argument("--due", help="Deadline in ISO 8601")
    parser.add_argument("--proof-required", help='JSON array of required evidence types')
    parser.add_argument("--tick", action="store_true", help="Run scheduler tick")
    parser.add_argument("--resume", metavar="TASK_ID", help="Resume a paused/blocked task from checkpoint")
    parser.add_argument("--daemon", action="store_true", help="Run as always-on daemon with Telegram")
    parser.add_argument("--model", help="LLM model name")
    parser.add_argument("--provider", choices=["anthropic", "openai", "codex"], help="LLM provider")
    parser.add_argument("--base-url", help="API base URL override")
    parser.add_argument("--verbose", "-v", action="store_true")
    return parser


def _build_init_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        prog="pascal init",
        description="Create Pascal's home directory and starter configuration.",
        epilog=_INIT_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )


def _init_pascal_home() -> None:
    pascal_home = Path.home() / ".pascal"
    config_path = pascal_home / "pascal.toml"
    skills_dir = pascal_home / "skills"
    created: list[Path] = []
    existing: list[Path] = []

    try:
        if pascal_home.exists():
            if not pascal_home.is_dir():
                raise NotADirectoryError(f"{pascal_home} exists and is not a directory")
            existing.append(pascal_home)
        else:
            pascal_home.mkdir(parents=True, exist_ok=True)
            created.append(pascal_home)

        if config_path.exists():
            if not config_path.is_file():
                raise IsADirectoryError(f"{config_path} exists and is not a file")
            existing.append(config_path)
        else:
            config_path.write_text(_DEFAULT_CONFIG_TOML, encoding="utf-8")
            created.append(config_path)

        if skills_dir.exists():
            if not skills_dir.is_dir():
                raise NotADirectoryError(f"{skills_dir} exists and is not a directory")
            existing.append(skills_dir)
        else:
            skills_dir.mkdir(parents=True, exist_ok=True)
            created.append(skills_dir)
    except OSError as exc:
        print(f"Pascal initialization failed: {exc}", file=sys.stderr)
        sys.exit(1)

    print("Pascal initialization complete.")
    if created:
        print("Created:")
        for path in created:
            print(f"  - {path}")
    if existing:
        print("Already existed:")
        for path in existing:
            print(f"  - {path}")
    print()
    print("Next steps:")
    print(f"  - Edit {config_path} to choose your model and provider.")
    print(f"  - Add custom skills to {skills_dir}.")


def _read_toml_config() -> tuple[Path, dict]:
    """Read the pascal.toml config. Returns (path, pascal_section)."""
    config_path = Path.home() / ".pascal" / "pascal.toml"
    if not config_path.exists():
        return config_path, {}
    import tomllib
    with config_path.open("rb") as f:
        data = tomllib.load(f)
    return config_path, data.get("pascal", {})


def _write_toml_config(path: Path, section: dict) -> None:
    """Write the pascal section to pascal.toml, preserving [pascal] header."""
    lines = ["[pascal]"]
    for key, value in sorted(section.items()):
        if isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, int):
            lines.append(f"{key} = {value}")
        else:
            lines.append(f'{key} = "{value}"')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _config_show() -> None:
    """Show current resolved configuration."""
    config = load_config()
    config_path, toml_data = _read_toml_config()
    print(f"Config file: {config_path}" + (" (exists)" if config_path.exists() else " (not found)"))
    print()
    fields = {
        "model": config.model,
        "provider": config.provider,
        "base_url": config.base_url or "(default)",
        "db_path": config.db_path,
        "max_effect": config.max_effect,
        "max_tool_rounds": config.max_tool_rounds or "(default)",
    }
    import os
    for key, value in fields.items():
        source = ""
        env_key = f"PASCAL_{key.upper()}"
        if os.environ.get(env_key):
            source = f"  (from ${env_key})"
        elif key in toml_data:
            source = "  (from pascal.toml)"
        else:
            source = "  (default)"
        print(f"  {key:20s} = {value}{source}")

    # API key status
    print()
    for name, env in [("OpenAI", "OPENAI_API_KEY"), ("Anthropic", "ANTHROPIC_API_KEY"), ("Codex", "~/.codex/auth.json")]:
        if env.startswith("~"):
            found = (Path.home() / env.replace("~/", "")).exists()
        else:
            found = bool(os.environ.get(env))
        status = "configured" if found else "not set"
        print(f"  {name:20s} : {status}")


def _config_set(key: str, value: str) -> None:
    """Set a config value in ~/.pascal/pascal.toml."""
    if key not in _CONFIG_KEYS:
        print(f"Unknown config key: {key}")
        print(f"Available keys: {', '.join(sorted(_CONFIG_KEYS))}")
        sys.exit(1)
    if key == "provider" and value not in _PROVIDERS:
        print(f"Invalid provider: {value}. Choose from: {', '.join(_PROVIDERS)}")
        sys.exit(1)
    if key == "max_effect" and value not in _EFFECTS:
        print(f"Invalid effect level: {value}. Choose from: {', '.join(_EFFECTS)}")
        sys.exit(1)

    config_path, section = _read_toml_config()
    if key == "max_tool_rounds":
        section[key] = int(value)
    else:
        section[key] = value
    _write_toml_config(config_path, section)
    print(f"Set {key} = {value} in {config_path}")


def _config_get(key: str) -> None:
    """Get a specific config value."""
    config = load_config()
    value = getattr(config, key, None)
    if value is None:
        print(f"Unknown key: {key}")
        sys.exit(1)
    print(value)


def _setup_interactive() -> None:
    """Interactive guided setup."""
    import os
    print("Pascal Setup")
    print("=" * 40)
    print()

    # Ensure ~/.pascal exists
    _init_pascal_home()
    print()

    config_path, section = _read_toml_config()

    # Provider
    current_provider = section.get("provider", "openai")
    print(f"LLM Provider ({', '.join(_PROVIDERS)})")
    print(f"  Current: {current_provider}")
    provider = input(f"  New value [{current_provider}]: ").strip() or current_provider
    if provider not in _PROVIDERS:
        print(f"  Invalid. Using {current_provider}.")
        provider = current_provider
    section["provider"] = provider

    # Model
    defaults = {"openai": "gpt-5.4-mini", "anthropic": "claude-sonnet-4-20250514", "codex": "o3"}
    current_model = section.get("model", defaults.get(provider, "gpt-5.4-mini"))
    print("\nModel name")
    print(f"  Current: {current_model}")
    model = input(f"  New value [{current_model}]: ").strip() or current_model
    section["model"] = model

    # Max effect
    current_effect = section.get("max_effect", "E2")
    print("\nMax effect level (E0=read E1=analyze E2=write E3=push E4=merge E5=delete)")
    print(f"  Current: {current_effect}")
    effect = input(f"  New value [{current_effect}]: ").strip() or current_effect
    if effect in _EFFECTS:
        section["max_effect"] = effect
    else:
        print(f"  Invalid. Keeping {current_effect}.")

    # API key check
    if provider == "openai":
        if not os.environ.get("OPENAI_API_KEY"):
            print("\nOpenAI API key not found in environment.")
            key = input("  Enter OPENAI_API_KEY (or press Enter to skip): ").strip()
            if key:
                _save_env_var("OPENAI_API_KEY", key)
    elif provider == "anthropic":
        if not os.environ.get("ANTHROPIC_API_KEY"):
            print("\nAnthropic API key not found in environment.")
            key = input("  Enter ANTHROPIC_API_KEY (or press Enter to skip): ").strip()
            if key:
                _save_env_var("ANTHROPIC_API_KEY", key)
    elif provider == "codex":
        auth = Path.home() / ".codex" / "auth.json"
        if not auth.exists():
            print(f"\nCodex auth not found at {auth}")
            print("  Run: codex auth login")

    _write_toml_config(config_path, section)
    print(f"\nSaved to {config_path}")

    # Integrations
    print("\n--- Integrations (optional, press Enter to skip) ---")
    _setup_telegram()
    _setup_discord()

    print()
    print("Ready! Try:")
    print('  pascal "Summarize the files in this directory"')
    print('  pascal --status')
    print('  pascal config')


def _setup_telegram() -> None:
    """Interactive Telegram bot setup."""
    config_path = Path.home() / ".pascal" / "telegram.json"
    if config_path.exists():
        print(f"\nTelegram: already configured ({config_path})")
        reconfigure = input("  Reconfigure? [y/N]: ").strip().lower()
        if reconfigure != "y":
            return

    print("\nTelegram Bot Setup:")
    print("  1. Message @BotFather on Telegram")
    print("  2. Send /newbot and follow the prompts")
    print("  3. Copy the bot token")
    print()

    try:
        token = input("  Bot token (or Enter to skip): ").strip()
    except (KeyboardInterrupt, EOFError):
        return
    if not token:
        return

    print()
    print("  Now get your chat ID:")
    print("  1. Message your new bot on Telegram")
    print("  2. Visit: https://api.telegram.org/bot<TOKEN>/getUpdates")
    print("  3. Find your chat.id in the response")
    print()

    try:
        chat_id = input("  Your chat ID: ").strip()
    except (KeyboardInterrupt, EOFError):
        return
    if not chat_id:
        return

    try:
        chat_id_int = int(chat_id)
    except ValueError:
        print("  Invalid chat ID (must be a number). Skipping.")
        return

    import json as _json
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        _json.dumps({"bot_token": token, "owner_chat_id": chat_id_int}, indent=2),
        encoding="utf-8",
    )
    print(f"  Saved to {config_path}")
    print("  Start daemon mode: pascal --daemon")


def _setup_discord() -> None:
    """Interactive Discord webhook setup."""
    print()
    try:
        webhook = input("  Discord webhook URL (or Enter to skip): ").strip()
    except (KeyboardInterrupt, EOFError):
        return
    if not webhook:
        return
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print("  Invalid URL. Must start with https://discord.com/api/webhooks/")
        return
    _save_env_var("PASCAL_DISCORD_WEBHOOK", webhook)
    print("  Discord webhook saved.")


def _setup_slack() -> None:
    """Interactive Slack webhook setup."""
    print()
    try:
        webhook = input("  Slack webhook URL (or Enter to skip): ").strip()
    except (KeyboardInterrupt, EOFError):
        return
    if not webhook:
        return
    if not webhook.startswith("https://hooks.slack.com/"):
        print("  Invalid URL. Must start with https://hooks.slack.com/")
        return
    _save_env_var("PASCAL_SLACK_WEBHOOK", webhook)
    print("  Slack webhook saved.")


def _connect(args: list[str]) -> None:
    """Handle pascal connect <service> subcommand."""
    if not args:
        print("Usage: pascal connect <service>")
        print()
        print("Services:")
        print("  telegram   Set up Telegram bot (for daemon mode)")
        print("  discord    Set up Discord webhook notifications")
        print("  slack      Set up Slack webhook notifications")
        print()
        # Show current status
        tg_path = Path.home() / ".pascal" / "telegram.json"
        print("Status:")
        print(f"  Telegram: {'configured' if tg_path.exists() else 'not set'}")
        print(f"  Discord:  {'configured' if os.environ.get('PASCAL_DISCORD_WEBHOOK') else 'not set'}")
        print(f"  Slack:    {'configured' if os.environ.get('PASCAL_SLACK_WEBHOOK') else 'not set'}")
        return

    service = args[0].lower()
    if service == "telegram":
        _setup_telegram()
    elif service == "discord":
        _setup_discord()
    elif service == "slack":
        _setup_slack()
    else:
        print(f"Unknown service: {service}")
        print("Available: telegram, discord, slack")


def _save_env_var(key: str, value: str) -> None:
    """Save an env var to ~/.pascal/.env and load into current process."""
    env_path = Path.home() / ".pascal" / ".env"
    env_path.parent.mkdir(parents=True, exist_ok=True)
    # Read existing, replace if key exists, else append
    lines = []
    replaced = False
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith(f"{key}="):
                lines.append(f"{key}={value}")
                replaced = True
            else:
                lines.append(line)
    if not replaced:
        lines.append(f"{key}={value}")
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.environ[key] = value  # load into current process immediately


def _quick_auth_setup() -> bool:
    """Inline auth setup when no provider is detected. Returns True if configured."""
    import shutil
    import subprocess

    print("No LLM provider configured. Quick setup:\n")
    print("  [1] Codex   (free with ChatGPT Pro subscription)")
    print("  [2] OpenAI  (API key)")
    print("  [3] Anthropic (API key)")
    print("  [0] Cancel\n")

    try:
        choice = input("Choose [1-3]: ").strip()
    except (KeyboardInterrupt, EOFError):
        return False

    config_path, section = _read_toml_config()

    if choice == "1":
        # Codex OAuth
        auth_path = Path.home() / ".codex" / "auth.json"
        if auth_path.exists():
            print("Codex auth already exists.")
        elif shutil.which("codex"):
            print("Opening Codex login...")
            try:
                subprocess.run(["codex", "auth", "login"], timeout=120)
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
                print(f"  Login failed: {e}")
                print("  Try manually: codex auth login")
                return False
            if not auth_path.exists():
                print("  Auth file not created. Try: codex auth login")
                return False
        else:
            print("  Codex CLI not found. Install it first:")
            print("    npm install -g @anthropic-ai/codex")
            print("  Then: codex auth login")
            return False
        section["provider"] = "codex"
        section["model"] = "gpt-5.4-mini"
        _write_toml_config(config_path, section)
        print("Done! Provider: codex\n")
        return True

    elif choice == "2":
        # OpenAI API key
        try:
            key = input("OPENAI_API_KEY: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False
        if not key:
            print("  No key provided.")
            return False
        _save_env_var("OPENAI_API_KEY", key)
        section["provider"] = "openai"
        section["model"] = "gpt-5.4-mini"
        _write_toml_config(config_path, section)
        print("Done! Provider: openai\n")
        return True

    elif choice == "3":
        # Anthropic API key
        try:
            key = input("ANTHROPIC_API_KEY: ").strip()
        except (KeyboardInterrupt, EOFError):
            return False
        if not key:
            print("  No key provided.")
            return False
        _save_env_var("ANTHROPIC_API_KEY", key)
        section["provider"] = "anthropic"
        section["model"] = "claude-sonnet-4-20250514"
        _write_toml_config(config_path, section)
        print("Done! Provider: anthropic\n")
        return True

    return False


def _auto_detect_provider() -> tuple[str, str]:
    """Auto-detect the best available provider. Returns (provider, model)."""
    import os
    # Priority: Codex (free with Pro) > OpenAI > Anthropic
    if (Path.home() / ".codex" / "auth.json").exists():
        return "codex", "gpt-5.4-mini"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai", "gpt-5.4-mini"
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic", "claude-sonnet-4-20250514"
    return "", ""


def _ensure_ready() -> bool:
    """Ensure Pascal is initialized. Auto-init on first run. Returns True if ready."""
    pascal_home = Path.home() / ".pascal"
    config_path = pascal_home / "pascal.toml"

    # First run: auto-init
    if not pascal_home.exists():
        print("First run detected. Setting up Pascal...\n")
        _init_pascal_home()
        print()

    # Auto-detect provider if not configured
    _, section = _read_toml_config()
    if not section.get("provider"):
        provider, model = _auto_detect_provider()
        if provider:
            section["provider"] = provider
            section["model"] = model
            _write_toml_config(config_path, section)
            print(f"Auto-detected: provider={provider}, model={model}\n")
        else:
            # Interactive provider setup
            result = _quick_auth_setup()
            if not result:
                return False
    return True


def _print_banner() -> None:
    """Print startup banner with current config."""
    from pascal import __version__
    config = load_config()
    print()
    print(f"  Pascal v{__version__}")
    print(f"  {config.model} via {config.provider} | max effect: {config.max_effect}")
    print()
    print("  Type a task, 'help' for commands, Ctrl+C to exit.")
    print()


async def _run_one_task(task: str, config, *, force_task: bool = False) -> None:
    """Run a single task through the loop.

    force_task=True: always create as task (one-shot CLI mode).
    force_task=False: push as notification, let LLM decide (REPL mode).
    """
    global _active_model
    _active_model = config.model
    store = PascalStore(config.db_path)
    if force_task:
        store.add_task(task, source="cli")
    else:
        # Let the LLM decide: casual chat → reply, real work → create_task
        store.push_notification(source="user", message=task, priority="normal")

    from pascal.config import create_llm
    llm = create_llm(config)

    ledger_path = Path(config.db_path).expanduser().parent / "audit.jsonl"
    ledger = Ledger(str(ledger_path))

    from pascal.mcp import MCPManager
    mcp_manager = MCPManager()
    mcp_configs = _load_mcp_configs(config)
    if mcp_configs:
        try:
            await mcp_manager.connect_all(mcp_configs)
        except Exception:
            pass  # MCP is optional

    _start_spinner("thinking...")
    try:
        await run_loop(
            store, llm,
            verifier_llm=llm,
            ledger=ledger,
            mcp_manager=mcp_manager if mcp_manager.connected_servers else None,
            max_effect=config.max_effect,
            max_iterations=20,
            max_tool_rounds=_resolve_max_tool_rounds(config, None, daemon_mode=False),
            on_action=_print_action,
        )
    finally:
        _stop_spinner()
        try:
            await mcp_manager.disconnect_all()
        except Exception:
            pass
        store.close()


def _interactive() -> None:
    """Interactive REPL mode -- type tasks, see Pascal work, repeat."""
    if not _ensure_ready():
        return

    _print_banner()
    config = load_config()

    # Show pending work if any
    store = PascalStore(config.db_path)
    active = store.get_active_task()
    pending = store.get_pending_tasks()
    notifs = store.get_pending_notifications()
    if active:
        print(f"  Active: {active['goal'][:70]}")
    if pending:
        print(f"  Queued: {len(pending)} task(s)")
    if notifs:
        print(f"  Notifications: {len(notifs)}")
    if active or pending or notifs:
        print()
    store.close()

    while True:
        try:
            task = input("> ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nBye.")
            break

        if not task:
            continue
        if task.lower() in ("exit", "quit", "q"):
            print("Bye.")
            break
        if task.lower() == "help":
            print("  Type any task to run it. Examples:")
            print('    Summarize the files in this directory')
            print('    Read README.md and explain the architecture')
            print()
            print("  Commands:")
            print("    help     Show this help")
            print("    status   Show desk state")
            print("    config   Show current settings")
            print("    exit     Quit")
            print()
            continue
        if task.lower() == "status":
            _status(config)
            print()
            continue
        if task.lower() == "config":
            _config_show()
            print()
            continue

        print()
        try:
            asyncio.run(_run_one_task(task, config))
        except KeyboardInterrupt:
            print("\n  (interrupted)")
        except Exception as exc:
            print(f"  Error: {exc}")
        print()


def main() -> None:
    argv = sys.argv[1:]

    # Subcommands: init, setup, config
    if argv and argv[0] == "init":
        init_parser = _build_init_parser()
        init_parser.parse_args(argv[1:])
        _init_pascal_home()
        return

    if argv and argv[0] == "setup":
        _setup_interactive()
        return

    if argv and argv[0] == "connect":
        _connect(argv[1:])
        return

    if argv and argv[0] == "config":
        rest = argv[1:]
        if not rest:
            _config_show()
        elif rest[0] == "set" and len(rest) >= 3:
            _config_set(rest[1], rest[2])
        elif rest[0] == "get" and len(rest) >= 2:
            _config_get(rest[1])
        else:
            print("Usage:")
            print("  pascal config              Show all settings")
            print("  pascal config set <key> <value>  Set a value")
            print("  pascal config get <key>    Get a value")
            print(f"\nKeys: {', '.join(sorted(_CONFIG_KEYS))}")
        return

    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.init:
        _init_pascal_home()
        return

    # No task + no flags → interactive REPL
    has_action = (
        args.task or args.status or args.notify or args.add_rule
        or args.daemon or args.tick or getattr(args, "resume", None)
        or args.mission
    )
    if not has_action:
        _interactive()
        return

    # Ensure initialized before any real work
    if not _ensure_ready():
        return

    config = load_config(
        **({"model": args.model} if args.model else {}),
        **({"provider": args.provider} if args.provider else {}),
        **({"base_url": args.base_url} if args.base_url else {}),
        **({"max_inner_turns": args.max_inner_turns} if args.max_inner_turns is not None else {}),
        **({"max_tool_rounds": args.max_tool_rounds} if getattr(args, "max_tool_rounds", None) is not None else {}),
    )

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        # Suppress noisy MCP/connection warnings in normal mode
        logging.basicConfig(level=logging.ERROR)

    if args.daemon:
        from pascal.daemon import run_daemon
        asyncio.run(run_daemon(config, args))
        return
    elif getattr(args, "resume", None):
        _resume(args, config)
    elif args.tick:
        from pascal.scheduler import Scheduler
        store = PascalStore(config.db_path)
        result = Scheduler(store, emit=print).tick()
        print(json.dumps(result, indent=2))
        store.close()
    elif args.status:
        _status(config)
    elif args.notify:
        _notify(args, config)
    elif args.add_rule:
        _add_rule(args, config)
    else:
        asyncio.run(_run(args, config))


if __name__ == "__main__":
    main()
