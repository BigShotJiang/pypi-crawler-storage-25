# Pascal — Autonomous AI Employee

An autonomous AI agent that works like a real employee: receives tasks, plans, executes, and reports back.

## Getting Started

### Install

```bash
pip install pascal-agent
```

Or with all optional features:
```bash
pip install "pascal-agent[all]"
```

### Run

```bash
pascal
```

That's it. On first run, Pascal auto-detects your LLM provider or walks you through setup.

### Manual setup (optional)

```bash
# Interactive setup
pascal setup

# Or set individually
pascal config set provider openai
pascal config set model gpt-5.4-mini
pascal config
```

**Provider setup:**

| Provider | Auth | How |
|----------|------|-----|
| OpenAI | API key | `export OPENAI_API_KEY=sk-...` |
| Anthropic | API key | `export ANTHROPIC_API_KEY=sk-ant-...` |
| Codex | ChatGPT Pro OAuth | `codex auth login` (free with Pro subscription) |

## Usage

```bash
# Interactive mode (default)
pascal
> Summarize the files in this directory
> Read README.md and explain the architecture
> exit

# One-shot task
pascal "Write a Python script that downloads weather data"

# Set a mission (persistent context)
pascal --mission "You are a data analyst for the marketing team"

# Check current state
pascal --status

# Always-on daemon with Telegram
pascal --daemon

# Resume a paused task
pascal --resume task_abc123
```

## Configuration

### Config file (`~/.pascal/pascal.toml`)

```toml
[pascal]
model = "gpt-5.4-mini"
provider = "openai"           # openai | anthropic | codex
db_path = "~/.pascal/state.db"
max_effect = "E2"             # E0=read E1=analyze E2=write E3=push E4=merge E5=delete
max_tool_rounds = 10          # max tool calls per LLM turn
```

### CLI config commands

```bash
pascal config                          # Show all settings
pascal config set model gpt-5.4-mini   # Set a value
pascal config get provider             # Get a value
```

### Environment variables (override config file)

```bash
PASCAL_MODEL=gpt-5.4-mini
PASCAL_PROVIDER=openai
PASCAL_MAX_EFFECT=E2
```

API keys can be set as environment variables or saved to `~/.pascal/.env` (auto-loaded).

### Optional integrations

**Telegram bot** (`~/.pascal/telegram.json`):
```json
{"bot_token": "123:ABC...", "owner_chat_id": 12345}
```

**MCP tool servers** (`~/.pascal/mcp.json`):
```json
[{"name": "chrome", "command": "npx", "args": ["chrome-devtools-mcp@latest"]}]
```

**Custom skills** (`~/.pascal/skills/my-skill.md`):
```yaml
---
name: my-skill
description: What this skill does
---
Instructions for Pascal when this skill is activated...
```

## How It Works

```
pascal "Do something"
    |
    v
+---------------------------+
|  Desk compiles state      |  SQLite -> text prompt
|  LLM decides next action  |  22 action types via function calling
|  Execute through safety   |  Effect Ladder + Trust Scanner + Sandbox
|  Record to audit ledger   |  Hash-chained, append-only
|  Repeat                   |
+---------------------------+
    |
    v
Task complete / wait / escalate
```

**22 actions**: think, execute, plan, delegate, pick_task, create_task, create_subtask, complete_task, fail_task, pause_task, block_task, handle_notification, dismiss_notification, add_todo, complete_todo, memorize, add_rule, remove_rule, set_context, wait, escalate

**3 LLM providers**: OpenAI, Anthropic Claude, Codex (ChatGPT Pro)

**4-layer safety**: Effect Ladder (E0-E5) | Trust Scanner | Sandbox (Docker/Restricted) | TrustMap + Audit Ledger

## Daemon Mode

Always-on operation with Telegram integration:

```bash
# Setup Telegram first
echo '{"bot_token": "YOUR_TOKEN", "owner_chat_id": YOUR_ID}' > ~/.pascal/telegram.json

# Start daemon
pascal --daemon
```

Features:
- Telegram DM for tasks and approvals
- Adaptive heartbeat (5min active, 30min idle)
- Auto-restart on crash
- STOP/PAUSE control (`~/.pascal/STOP` or `~/.pascal/PAUSE` file)

## Development

```bash
git clone https://gitlab.com/laum0621/pascal.git
cd pascal
pip install -e ".[dev]"

# Tests (245 pass)
pytest

# Lint (0 errors)
ruff check src/ tests/

# Type check (0 errors)
mypy src/pascal/
```

## Project Structure

```
src/pascal/
  loop.py ........... Core tool-use loop (LoopRunner)
  actions.py ........ 22 action handlers (ActionContext)
  state.py .......... SQLite persistence (9 tables, FTS5)
  desk.py ........... State -> LLM prompt compiler
  tools.py .......... Built-in tools (file, desktop, UIA, clipboard)
  effect.py ......... Effect Ladder (E0-E5, hard regex rules)
  trust.py .......... Input scanner (injection, credentials, destructive)
  capability.py ..... Domain trust map (asymmetric learning)
  sandbox.py ........ Docker + Restricted sandbox
  receipts.py ....... Hash-chained audit ledger
  scheduler.py ...... Cron tick + self-evolution
  daemon.py ......... Always-on mode (Telegram + loop + scheduler)
  config.py ......... Config loader (CLI > env > TOML > defaults)
  schemas.py ........ Tool JSON schemas for LLM function calling
  prompt.py ......... System prompt
  types.py .......... Shared DTOs
  llm/ .............. OpenAI, Anthropic, Codex providers
  channels/ ......... Telegram adapter
  uia.py ............ Windows UI Automation
```

## License

MIT
