"""Dynamic command generation from the /vibe-tools/operations manifest."""

from typing import Any, Callable, Optional

import typer
from rich.console import Console

from vibe_cli.client import VibeClient
from vibe_cli.config import get_manifest_cache, save_manifest_cache
from vibe_cli.output import format_output, print_error

console = Console()


# Mapping from manifest path to client method name
_ROUTE_TO_METHOD = {
    "POST /vibe-tools/data-provider": "data_provider",
    "POST /vibe-tools/swap-quote": "swap_quote",
    "POST /vibe-tools/swap": "swap",
    "POST /vibe-tools/evm/swap-quote": "evm_swap_quote",
    "POST /vibe-tools/evm/swap": "evm_swap",
    "POST /vibe-tools/defi/discover": "defi_discover",
    "POST /vibe-tools/defi/quote": "defi_quote",
    "POST /vibe-tools/defi/deposit": "defi_deposit",
    "POST /vibe-tools/bags/launch-token": "bags_launch_token",
    "POST /vibe-tools/bags/claim-fees": "bags_claim_fees",
    "GET /vibe-tools/bags/positions": "bags_positions",
}

# Parameter definitions for each route (maps CLI flag → request body field)
_ROUTE_PARAMS = {
    "POST /vibe-tools/data-provider": [
        ("--service", "service_name", str, "Provider name (e.g. 'nansen', 'twitter')"),
        ("--route", "route", str, "Endpoint key (e.g. 'smart_money_netflows')"),
        ("--payload", "payload", Optional[str], "JSON payload for the provider"),
    ],
    "POST /vibe-tools/swap-quote": [
        ("--from-token", "input_mint", str, "Input token mint address"),
        ("--to-token", "output_mint", str, "Output token mint address"),
        ("--amount", "amount", int, "Amount in lamports"),
        ("--slippage-bps", "slippage_bps", Optional[int], "Slippage in basis points (default 50)"),
    ],
    "POST /vibe-tools/swap": [
        ("--from-token", "input_mint", str, "Input token mint address"),
        ("--to-token", "output_mint", str, "Output token mint address"),
        ("--amount", "amount", int, "Amount in lamports"),
        ("--slippage-bps", "slippage_bps", Optional[int], "Slippage in basis points"),
    ],
    "POST /vibe-tools/evm/swap-quote": [
        ("--network", "network", str, "EVM network: 'base' or 'ethereum'"),
        ("--from-asset", "from_asset", str, "Source asset (e.g. 'eth', 'usdc')"),
        ("--to-asset", "to_asset", str, "Destination asset"),
        ("--amount", "amount", str, "Amount in human-readable units"),
        ("--slippage-pct", "slippage_pct", Optional[float], "Max slippage percentage"),
    ],
    "POST /vibe-tools/evm/swap": [
        ("--network", "network", str, "EVM network: 'base' or 'ethereum'"),
        ("--from-asset", "from_asset", str, "Source asset"),
        ("--to-asset", "to_asset", str, "Destination asset"),
        ("--amount", "amount", str, "Amount in human-readable units"),
        ("--slippage-pct", "slippage_pct", Optional[float], "Max slippage percentage"),
    ],
    "POST /vibe-tools/defi/discover": [
        ("--protocols", "protocols", Optional[str], "Comma-separated protocol filter"),
    ],
    "POST /vibe-tools/defi/quote": [
        ("--action", "action", str, "DeFi action: stake, supply, borrow, add_liquidity"),
        ("--token", "token", str, "Token symbol"),
        ("--amount", "amount", str, "Amount as decimal string"),
        ("--protocol", "protocol", Optional[str], "Protocol name"),
    ],
    "POST /vibe-tools/defi/deposit": [
        ("--action", "action", str, "DeFi action: stake, supply, borrow, add_liquidity"),
        ("--token", "token", str, "Token symbol"),
        ("--amount", "amount", str, "Amount as decimal string"),
        ("--protocol", "protocol", Optional[str], "Protocol name"),
    ],
    "POST /vibe-tools/bags/launch-token": [
        ("--name", "name", str, "Token name"),
        ("--symbol", "symbol", str, "Token symbol"),
        ("--description", "description", str, "Token description"),
        ("--image-url", "image_url", str, "Token image URL"),
    ],
    "POST /vibe-tools/bags/claim-fees": [
        ("--token-mint", "token_mint", str, "Token mint address"),
    ],
    "GET /vibe-tools/bags/positions": [],
}


def sync_manifest() -> list[dict]:
    """Fetch the operations manifest from the gateway."""
    client = VibeClient()
    response = client.get_operations()

    if "error" in response:
        print_error(response["error"])

    manifest = response.get("data", [])
    save_manifest_cache(manifest)
    return manifest


def get_cached_manifest() -> list[dict]:
    """Get the manifest from cache, or sync if missing."""
    cached = get_manifest_cache()
    if cached:
        return cached
    return sync_manifest()


def list_operations(filter_text: Optional[str] = None) -> None:
    """List all available operations, optionally filtered."""
    manifest = get_cached_manifest()

    if filter_text:
        manifest = [
            op for op in manifest
            if filter_text.lower() in op.get("path", "").lower()
            or filter_text.lower() in op.get("summary", "").lower()
        ]

    for op in manifest:
        method = op.get("method", "?")
        path = op.get("path", "?")
        summary = op.get("summary", "")
        scope = op.get("scope", "")
        rate = op.get("rate_limit", "-")

        console.print(f"  [bold cyan]{method:6s}[/bold cyan] {path}")
        console.print(f"         [dim]{summary}[/dim]")
        console.print(f"         scope={scope}  rate={rate}")
        console.print()


def build_route_key(method: str, path: str) -> str:
    """Build a route key like 'POST /vibe-tools/swap-quote'."""
    return f"{method} {path}"


def execute_operation(
    route_key: str,
    params: dict,
    output_format: str = "table",
    filter_path: Optional[str] = None,
) -> None:
    """Execute a vibe-tools operation by route key."""
    client = VibeClient()
    method_name = _ROUTE_TO_METHOD.get(route_key)

    if not method_name:
        console.print(f"[red]Unknown operation: {route_key}[/red]")
        raise typer.Exit(1)

    method_func = getattr(client, method_name, None)
    if not method_func:
        console.print(f"[red]Client method not found: {method_name}[/red]")
        raise typer.Exit(1)

    # Clean None values from params
    clean_params = {k: v for k, v in params.items() if v is not None}

    # Parse JSON payloads
    if "payload" in clean_params and isinstance(clean_params["payload"], str):
        import json
        try:
            clean_params["payload"] = json.loads(clean_params["payload"])
        except json.JSONDecodeError:
            console.print("[red]Invalid JSON payload[/red]")
            raise typer.Exit(1)

    # Parse comma-separated protocols
    if "protocols" in clean_params and isinstance(clean_params["protocols"], str):
        clean_params["protocols"] = [p.strip() for p in clean_params["protocols"].split(",")]

    response = method_func(**clean_params)

    if "error" in response:
        print_error(response["error"])

    format_output(response.get("data", response), output_format, filter_path)
