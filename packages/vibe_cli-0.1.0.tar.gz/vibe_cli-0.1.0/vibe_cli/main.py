"""VIBE Airforce CLI — Web3 trading and data at your fingertips.

Usage:
    vibe sync                          Fetch operations manifest
    vibe list-operations               List available commands
    vibe auth                          Authenticate with API key
    vibe <command> [options]           Execute a vibe-tools command

Examples:
    vibe sync
    vibe list-operations | grep swap
    vibe swap-quote --from-token So11111111111111111111111111111111111111112 \
                     --to-token EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v \
                     --amount 1000000
    vibe evm-swap-quote --network base --from-asset eth --to-asset usdc --amount 0.1
"""

import json as _json
from typing import Optional

import typer
from rich.console import Console

from vibe_cli import __version__
from vibe_cli.auth import login, logout as auth_logout
from vibe_cli.config import get_api_key
from vibe_cli.operations import sync_manifest, list_operations, execute_operation
from vibe_cli.output import format_output, print_error

console = Console()

app = typer.Typer(
    name="vibe",
    help="VIBE Airforce — Web3 trading and data at your fingertips",
    no_args_is_help=True,
    add_completion=False,
)


# ---------------------------------------------------------------------------
# Core commands
# ---------------------------------------------------------------------------

@app.command()
def sync():
    """Fetch the latest operations manifest from the VIBE gateway."""
    console.print("[bold]Syncing operations manifest...[/bold]")
    manifest = sync_manifest()
    console.print(f"[green]Synced {len(manifest)} operations.[/green]")
    console.print("Run [bold]vibe list-operations[/bold] to see available commands.")


@app.command(name="list-operations")
def list_ops(
    filter: Optional[str] = typer.Argument(None, help="Filter operations by keyword"),
):
    """List all available vibe-tools operations."""
    list_operations(filter)


@app.command()
def auth():
    """Authenticate with your VIBE API key."""
    login(interactive=True)


@app.command()
def logout():
    """Remove saved API key."""
    auth_logout()


@app.command()
def install():
    """Update the VIBE CLI to the latest version."""
    console.print("[bold]Checking for updates...[/bold]")
    import subprocess
    subprocess.run(["pip", "install", "--upgrade", "vibe-cli"])


@app.command()
def feedback(
    message: str = typer.Argument(..., help="Your feedback message"),
):
    """Submit feedback about the VIBE CLI."""
    console.print(f"[green]Thank you for your feedback![/green]")
    console.print(f"[dim]Message: {message}[/dim]")


@app.command()
def version():
    """Show the VIBE CLI version."""
    console.print(f"vibe CLI v{__version__}")


# ---------------------------------------------------------------------------
# Route commands — explicit functions for each vibe-tools operation
# ---------------------------------------------------------------------------

def _output_opts():
    """Common output options shared by all route commands."""
    return {
        "output": typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
        "field": typer.Option(None, "-f", "--field", help="Extract nested field (dot-path e.g. 'body.data')"),
    }


# --- Data Provider ---

@app.command(name="data-provider")
def data_provider(
    service: str = typer.Option(..., "--service", help="Provider name (e.g. 'nansen', 'twitter')"),
    route: str = typer.Option(..., "--route", help="Endpoint key (e.g. 'smart_money_netflows')"),
    payload: Optional[str] = typer.Option(None, "--payload", help="JSON payload for the provider"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Query external data providers (Nansen, Twitter, etc.)."""
    params: dict = {"service_name": service, "route": route}
    if payload:
        try:
            params["payload"] = _json.loads(payload)
        except _json.JSONDecodeError:
            console.print("[red]Invalid JSON payload[/red]")
            raise typer.Exit(1)
    execute_operation("POST /vibe-tools/data-provider", params, output, field)


# --- Solana Swap ---

@app.command(name="swap-quote")
def swap_quote(
    from_token: str = typer.Option(..., "--from-token", help="Input token mint address"),
    to_token: str = typer.Option(..., "--to-token", help="Output token mint address"),
    amount: int = typer.Option(..., "--amount", help="Amount in lamports"),
    slippage_bps: Optional[int] = typer.Option(None, "--slippage-bps", help="Slippage in basis points"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get Solana swap quote (Jupiter, Meteora)."""
    params: dict = {"input_mint": from_token, "output_mint": to_token, "amount": amount}
    if slippage_bps is not None:
        params["slippage_bps"] = slippage_bps
    execute_operation("POST /vibe-tools/swap-quote", params, output, field)


@app.command(name="swap")
def swap(
    from_token: str = typer.Option(..., "--from-token", help="Input token mint address"),
    to_token: str = typer.Option(..., "--to-token", help="Output token mint address"),
    amount: int = typer.Option(..., "--amount", help="Amount in lamports"),
    slippage_bps: Optional[int] = typer.Option(None, "--slippage-bps", help="Slippage in basis points"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute Solana swap (returns unsigned transaction)."""
    params: dict = {"input_mint": from_token, "output_mint": to_token, "amount": amount}
    if slippage_bps is not None:
        params["slippage_bps"] = slippage_bps
    execute_operation("POST /vibe-tools/swap", params, output, field)


# --- EVM Swap ---

@app.command(name="evm-swap-quote")
def evm_swap_quote(
    network: str = typer.Option("base", "--network", help="EVM network: 'base' or 'ethereum'"),
    from_asset: str = typer.Option(..., "--from-asset", help="Source asset (e.g. 'eth', 'usdc')"),
    to_asset: str = typer.Option(..., "--to-asset", help="Destination asset"),
    amount: str = typer.Option(..., "--amount", help="Amount in human-readable units (e.g. '0.1')"),
    slippage_pct: Optional[float] = typer.Option(None, "--slippage-pct", help="Max slippage percentage"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get Base/Ethereum swap quote (0x aggregator)."""
    params: dict = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount}
    if slippage_pct is not None:
        params["slippage_pct"] = slippage_pct
    execute_operation("POST /vibe-tools/evm/swap-quote", params, output, field)


@app.command(name="evm-swap")
def evm_swap(
    network: str = typer.Option("base", "--network", help="EVM network: 'base' or 'ethereum'"),
    from_asset: str = typer.Option(..., "--from-asset", help="Source asset"),
    to_asset: str = typer.Option(..., "--to-asset", help="Destination asset"),
    amount: str = typer.Option(..., "--amount", help="Amount in human-readable units"),
    slippage_pct: Optional[float] = typer.Option(None, "--slippage-pct", help="Max slippage percentage"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute Base/Ethereum swap (CDP managed wallet)."""
    params: dict = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount}
    if slippage_pct is not None:
        params["slippage_pct"] = slippage_pct
    execute_operation("POST /vibe-tools/evm/swap", params, output, field)


# --- DeFi ---

@app.command(name="defi-discover")
def defi_discover(
    protocols: Optional[str] = typer.Option(None, "--protocols", help="Comma-separated protocol filter"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Discover available DeFi protocols and positions."""
    params: dict = {}
    if protocols:
        params["protocols"] = [p.strip() for p in protocols.split(",")]
    execute_operation("POST /vibe-tools/defi/discover", params, output, field)


@app.command(name="defi-quote")
def defi_quote(
    action: str = typer.Option(..., "--action", help="DeFi action: stake, supply, borrow, add_liquidity"),
    token: str = typer.Option(..., "--token", help="Token symbol (e.g. 'SOL', 'USDC')"),
    amount: str = typer.Option(..., "--amount", help="Amount as decimal string"),
    protocol: Optional[str] = typer.Option(None, "--protocol", help="Protocol name"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get DeFi position quote (stake, lend, LP)."""
    params: dict = {"action": action, "token": token, "amount": amount}
    if protocol:
        params["protocol"] = protocol
    execute_operation("POST /vibe-tools/defi/quote", params, output, field)


@app.command(name="defi-deposit")
def defi_deposit(
    action: str = typer.Option(..., "--action", help="DeFi action: stake, supply, borrow, add_liquidity"),
    token: str = typer.Option(..., "--token", help="Token symbol"),
    amount: str = typer.Option(..., "--amount", help="Amount as decimal string"),
    protocol: Optional[str] = typer.Option(None, "--protocol", help="Protocol name"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute DeFi deposit (returns unsigned transaction)."""
    params: dict = {"action": action, "token": token, "amount": amount}
    if protocol:
        params["protocol"] = protocol
    execute_operation("POST /vibe-tools/defi/deposit", params, output, field)


# --- bags.fm ---

@app.command(name="bags-launch-token")
def bags_launch_token(
    name: str = typer.Option(..., "--name", help="Token name"),
    symbol: str = typer.Option(..., "--symbol", help="Token symbol"),
    description: str = typer.Option(..., "--description", help="Token description"),
    image_url: str = typer.Option(..., "--image-url", help="Token image URL (https)"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Launch a token on bags.fm."""
    params: dict = {"name": name, "symbol": symbol, "description": description, "image_url": image_url}
    execute_operation("POST /vibe-tools/bags/launch-token", params, output, field)


@app.command(name="bags-claim-fees")
def bags_claim_fees(
    token_mint: str = typer.Option(..., "--token-mint", help="Token mint address"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Claim bags.fm trading fees."""
    params: dict = {"token_mint": token_mint}
    execute_operation("POST /vibe-tools/bags/claim-fees", params, output, field)


@app.command(name="bags-positions")
def bags_positions(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """View bags.fm positions and fees."""
    execute_operation("GET /vibe-tools/bags/positions", {}, output, field)


if __name__ == "__main__":
    app()
