# LangChain Retriever - NEAR Staking Data

Build a LangChain retriever for staking data.

**Deliverables:**
1. LangChain BaseRetriever implementation
2. Efficient querying
3. Caching support
4. Published to PyPI

**Success Metric:** 20+ downlo

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `NEARStakingRetriever` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, NEARStakingRetriever

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
