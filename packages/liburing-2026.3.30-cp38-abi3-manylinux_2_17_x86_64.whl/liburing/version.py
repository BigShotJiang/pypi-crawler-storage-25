from functools import lru_cache

__all__ = "LINUX_VERSION_MAJOR", "LINUX_VERSION_MINOR", "linux_version_check"

LINUX_VERSION_MAJOR = 0
LINUX_VERSION_MINOR = 0


def _set_linux_version() -> None:
    global LINUX_VERSION_MAJOR, LINUX_VERSION_MINOR
    if not LINUX_VERSION_MAJOR:
        with open("/proc/version", "rb") as file:
            data = file.read()
        major, minor, *_ = data.split()[2].split(b".", 2)
        LINUX_VERSION_MAJOR = int(major)
        LINUX_VERSION_MINOR = int(minor)


_set_linux_version()  # initialize


@lru_cache
def linux_version_check(version: str | int | float) -> bool:
    """Linux Version Check.

    Example
        # note: assuming your linux is 6.7

        >>> linux_version_check(5)
        False
        >>> linux_version_check("6.6")
        False
        >>> linux_version_check(6.7)
        False
        >>> linux_version_check(6.8)
        True
        >>> linux_version_check(7.0)
        True
    """
    major, minor = map(int, str(float(version)).split("."))  # '6.7' -> 6 7
    return (major > LINUX_VERSION_MAJOR) or ((major == LINUX_VERSION_MAJOR) and (minor > LINUX_VERSION_MINOR))
