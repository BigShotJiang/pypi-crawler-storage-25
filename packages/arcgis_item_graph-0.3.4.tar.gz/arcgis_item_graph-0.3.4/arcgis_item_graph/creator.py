"""
ItemGraphCreator — builds the initial organization-wide dependency graph.
Run once to create the GML file used by ItemGraphUpdater and ItemGraphQuery.
"""
import datetime
import logging
import time
from pathlib import Path
from typing import Optional

from arcgis.apps.itemgraph import create_dependency_graph
from arcgis_item_graph.cache import MetadataCache
from arcgis_item_graph.parsers import augment_graph

logger = logging.getLogger(__name__)


class ItemGraphCreator:
    """
    Builds the initial organization-wide item dependency graph.

    WARNING: Can take a very long time for large organizations.

    Args:
        gis: ArcGIS GIS connection object
        gml_file: Path where the GML file will be saved
        timestamp_file: Path where the last-updated timestamp will be saved
        max_items: Maximum number of items to index (default: 10000)
    """

    def __init__(
        self,
        gis,
        gml_file: str,
        timestamp_file: str,
        max_items: int = 10000,
        include_reverse: bool = True,
        outside_org: bool = True,
        cache_path: Optional[str] = None,
        on_progress=None,
        on_warning=None,
        on_step=None,
    ):
        self.gis = gis
        self.gml_file = Path(gml_file)
        self.timestamp_file = Path(timestamp_file)
        self.max_items = max_items
        self.include_reverse = include_reverse
        self.outside_org = outside_org
        self._cache_path = cache_path
        self._on_progress = on_progress or (lambda **kw: None)
        self._on_warning = on_warning or (lambda **kw: None)
        self._on_step = on_step or (lambda label: None)

        self.gml_file.parent.mkdir(parents=True, exist_ok=True)
        self.timestamp_file.parent.mkdir(parents=True, exist_ok=True)

    def create(self) -> dict:
        """
        Create the initial dependency graph.

        Returns:
            dict with keys: success, duration, items_indexed, gml_file,
                            timestamp_file, timestamp  (or error on failure)
        """
        logger.info("=" * 70)
        logger.info("CREATING INITIAL ITEM GRAPH")
        logger.info("=" * 70)
        logger.warning(
            "This process can take a VERY long time for large organizations."
        )
        logger.info(f"Max items to index: {self.max_items}")

        start_time = datetime.datetime.now()

        try:
            self._on_step(label=f"Step 1/3 · Searching portal (max {self.max_items} items)…")
            logger.info(f"Step 1/3: Searching for items (max: {self.max_items})...")
            items = self.gis.content.search("", max_items=self.max_items)
            logger.info(f"Found {len(items)} items")
            self._on_progress(
                count=len(items),
                title=f"Found {len(items)} items",
                item_type="",
            )

            self._on_step(label=f"Step 2/3 · Building dependency graph ({len(items)} items) — this can take a while…")
            logger.info("Step 2/3: Creating dependency graph...")
            graph = create_dependency_graph(
                self.gis,
                items,
                include_reverse=self.include_reverse,
                outside_org=self.outside_org,
            )
            logger.info(f"Graph created with {len(graph.all_items())} items")

            self._on_step(label="Step 3/3 · Augmenting, saving GML, updating cache…")
            logger.info("Step 3/3: Augmenting graph, saving, and updating cache...")
            cache_obj = None
            if self._cache_path:
                try:
                    cache_obj = MetadataCache(self._cache_path)
                except Exception as _e:
                    logger.warning("Could not open metadata cache at %s: %s", self._cache_path, _e)
            try:
                augment_graph(graph, items, self.gis, cache=cache_obj)
                graph.write_to_file(str(self.gml_file))
                if cache_obj is not None:
                    started = int(time.time() * 1000)
                    cache_obj.build(graph, items)
                    broken_count = len(cache_obj.broken_nodes())
                    edge_count = sum(len(list(n.contains())) for n in graph.all_items())
                    cache_obj.record_run("create", started, len(items), edge_count, broken_count)
                    logger.info("MetadataCache written to %s", self._cache_path)
            except Exception as e:
                logger.warning("augment/cache step failed: %s", e)
            finally:
                if cache_obj is not None:
                    cache_obj.close()

            timestamp = int(datetime.datetime.now().timestamp() * 1000)
            self.timestamp_file.write_text(str(timestamp))

            duration = (datetime.datetime.now() - start_time).total_seconds()
            logger.info("INITIAL GRAPH CREATION COMPLETED")
            logger.info(f"Duration: {duration:.2f}s | Items: {len(graph.all_items())}")

            return {
                "success": True,
                "duration": duration,
                "items_indexed": len(graph.all_items()),
                "gml_file": str(self.gml_file),
                "timestamp_file": str(self.timestamp_file),
                "timestamp": timestamp,
            }

        except Exception as e:
            logger.error(f"Failed to create initial graph: {e}", exc_info=True)
            return {"success": False, "error": str(e)}
