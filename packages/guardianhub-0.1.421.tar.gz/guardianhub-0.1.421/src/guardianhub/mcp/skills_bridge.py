from fastmcp import FastMCP
import httpx
import json
import os
import logging
import uuid
from datetime import datetime
from typing import List, Dict, Any

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

mcp = FastMCP("GuardianHub-Skill-Bridge")
logger.info(f"[MCP] GuardianHub-Skill-Bridge initialized")

# Service Configuration
GRAPH_DB_URL = os.getenv("GRAPH_DB_URL", "http://graphdb.guardianhub.com")
SEARXNG_URL = os.getenv("SEARXNG_URL", "http://searxng.guardianhub.com")
TENANT_ID = os.getenv("X_TENANT_ID", "YANTRAM-HQ-BANGALORE")

logger.info(f"[CONFIG] GRAPH_DB_URL: {GRAPH_DB_URL}")
logger.info(f"[CONFIG] SEARXNG_URL: {SEARXNG_URL}")
logger.info(f"[CONFIG] TENANT_ID: {TENANT_ID}")

async def search_leads(query: str) -> List[Dict[str, Any]]:
    """
    Direct discovery via native SearXNG integration.
    """
    logger.info(f"[SEARCH] Starting lead search for query: '{query}'")
    logger.debug(f"[SEARCH] Target URL: {SEARXNG_URL}")

    params = {
        "q": query,
        "format": "json",
        "engines": "google,bing"
    }
    logger.debug(f"[SEARCH] Request params: {params}")

    try:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            logger.debug(f"[SEARCH] Sending GET request to {SEARXNG_URL}")
            response = await client.get(SEARXNG_URL, params=params, timeout=15.0)
            logger.info(f"[SEARCH] Response status: {response.status_code}")
            logger.debug(f"[SEARCH] Response headers: {dict(response.headers)}")

            response.raise_for_status()
            results = response.json()
            logger.debug(f"[SEARCH] Raw results count: {len(results.get('results', []))}")

            # Extract meaningful snippets/links
            leads = [{"title": r.get("title"), "url": r.get("url")} for r in results.get("results", [])[:5]]
            logger.info(f"[SEARCH] Extracted {len(leads)} leads from results")
            logger.debug(f"[SEARCH] Leads: {json.dumps(leads, indent=2)}")
            return leads

    except httpx.HTTPStatusError as e:
        logger.error(f"[SEARCH] HTTP error: {e.response.status_code} - {e.response.text}")
        raise
    except httpx.RequestError as e:
        logger.error(f"[SEARCH] Request error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"[SEARCH] Unexpected error: {str(e)}", exc_info=True)
        raise

async def anchor_to_graph_api(cypher_query: str, params: dict) -> Dict[str, Any]:
    """
    Uplinks data to the Graph-DB REST Service.
    """
    url = f"{GRAPH_DB_URL}/execute-cypher-write"
    logger.info(f"[GRAPH] Anchoring to Graph API: {url}")
    logger.debug(f"[GRAPH] Cypher query preview: {cypher_query[:100]}...")
    logger.debug(f"[GRAPH] Query params: {json.dumps(params, indent=2)}")

    headers = {"X-Tenant-ID": TENANT_ID, "Content-Type": "application/json"}
    payload = {"query": cypher_query, "parameters": params}

    try:
        async with httpx.AsyncClient() as client:
            logger.debug(f"[GRAPH] Sending POST request with timeout=20.0s")
            response = await client.post(url, headers=headers, json=payload, timeout=20.0)
            logger.info(f"[GRAPH] Response status: {response.status_code}")
            logger.debug(f"[GRAPH] Response headers: {dict(response.headers)}")

            response.raise_for_status()
            result = response.json()
            logger.info(f"[GRAPH] Successfully anchored data to graph")
            logger.debug(f"[GRAPH] Response body: {json.dumps(result, indent=2)}")
            return result

    except httpx.HTTPStatusError as e:
        logger.error(f"[GRAPH] HTTP error: {e.response.status_code}")
        logger.error(f"[GRAPH] Response body: {e.response.text}")
        raise
    except httpx.RequestError as e:
        logger.error(f"[GRAPH] Request error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"[GRAPH] Unexpected error: {str(e)}", exc_info=True)
        raise

@mcp.tool()
async def sovereign_discovery_mission(target_sector: str, region: str = "Bangalore") -> Dict[str, Any]:
    """
    Discovers leads via SearXNG and anchors them to the Sovereign Intelligence Graph.
    """
    logger.info(f"[MISSION] Starting sovereign_discovery_mission")
    logger.info(f"[MISSION] Parameters: target_sector='{target_sector}', region='{region}'")
    logger.info(f"[MISSION] Tenant: {TENANT_ID}")

    # 1. Active Discovery
    search_query = f"{target_sector} companies in {region}"
    logger.info(f"[MISSION] Constructed search query: '{search_query}'")

    try:
        leads = await search_leads(search_query)
        logger.info(f"[MISSION] Discovered {len(leads)} leads")
    except Exception as e:
        logger.error(f"[MISSION] Lead discovery failed: {str(e)}", exc_info=True)
        return {
            "status": "MISSION_FAILED",
            "error": f"Discovery failed: {str(e)}",
            "discovery_count": 0,
            "mission_id": None,
            "platform": "GuardianHub-v2-Pure"
        }

    # 2. Pre-generate IDs to avoid server-side plugin dependencies
    mission_uuid = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    logger.info(f"[MISSION] Generated mission UUID: {mission_uuid}")
    logger.debug(f"[MISSION] Timestamp: {now}")

    # Optimized Cypher with explicit parameter handling
    # 2. Define a "Flat" Sovereign Lineage
    # We use MERGE for everything to prevent transaction crashes on duplicates
    # and use raw strings for dates to avoid server-side datetime() issues.
    cypher = """
        MERGE (t:Tenant {id: $tenant_id})
        MERGE (m:Mission {id: $mission_id})
        SET m.sector = $sector, 
            m.region = $region, 
            m.created_at = $timestamp,
            m.engine = 'SearXNG'
        MERGE (t)-[:AUTHORIZED_MISSION]->(m)
        WITH m
        UNWIND $leads as lead
        MERGE (l:Discovery {source_url: lead.url})
        SET l.title = lead.title,
            l.discovered_at = $timestamp
        MERGE (m)-[:DISCOVERED]->(l)
        RETURN m.id as mission_id
        """

    # 3. Uplink with explicit types
    logger.info(f"[MISSION] Anchoring {len(leads)} leads to graph...")
    try:
        write_result = await anchor_to_graph_api(cypher, {
            "tenant_id": TENANT_ID,
            "mission_id": mission_uuid,
            "sector": target_sector,
            "region": region,
            "timestamp": now,
            "leads": leads
        })
        logger.info(f"[MISSION] Graph anchor successful: {write_result.get('mission_id')}")
    except Exception as e:
        logger.error(f"[MISSION] Graph anchoring failed: {str(e)}", exc_info=True)
        return {
            "status": "MISSION_FAILED",
            "error": f"Graph anchoring failed: {str(e)}",
            "discovery_count": len(leads),
            "mission_id": mission_uuid,
            "platform": "GuardianHub-v2-Pure"
        }

    result = {
        "status": "MISSION_ACCOMPLISHED",
        "discovery_count": len(leads),
        "mission_id": write_result.get("mission_id"),
        "platform": "GuardianHub-v2-Pure"
    }
    logger.info(f"[MISSION] Mission accomplished: {result}")
    return result

if __name__ == "__main__":
    logger.info("[MCP] Starting GuardianHub-Skill-Bridge MCP server")
    logger.info(f"[MCP] GRAPH_DB_URL: {GRAPH_DB_URL}")
    logger.info(f"[MCP] SEARXNG_URL: {SEARXNG_URL}")
    logger.info(f"[MCP] TENANT_ID: {TENANT_ID}")
    mcp.run()