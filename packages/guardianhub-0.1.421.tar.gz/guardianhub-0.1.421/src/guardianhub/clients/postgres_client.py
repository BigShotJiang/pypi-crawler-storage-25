# guardianhub/clients/postgres_client.py
import asyncpg
from guardianhub.config.settings import settings

class SovereignPostgresClient:
    def __init__(self, pool: asyncpg.Pool):
        self.pool = pool

    async def fetch_rows(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)