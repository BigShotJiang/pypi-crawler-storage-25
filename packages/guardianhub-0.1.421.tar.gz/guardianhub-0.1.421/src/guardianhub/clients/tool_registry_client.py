# tool_registry_client.py
import json
from typing import Any, Dict, List, Optional

import backoff
import httpx
from guardianhub import get_logger
from guardianhub.clients.sovereign_base_client import SovereignBaseClient

from guardianhub.config.settings import settings

logger = get_logger(__name__)


class ToolRegistryClient(SovereignBaseClient):
    """HTTP client for the tool registry service with retry logic."""

    def __init__(self, http_client: httpx.AsyncClient):
        # We pass the SHARED client up to the base
        super().__init__(
            shared_client=http_client,
            base_url=settings.endpoints.TOOL_REGISTRY_URL
        )

    async def get_agent_spec(self, agent_name: str) -> Dict[str, Any]:
        # Identity is automatically handled by SovereignBaseClient._request
        return await self._request("GET", f"/agent_registry/agents/{agent_name}/spec")

    async def load_agentic_capabilities(self) -> Dict[str, Any]:
        """Get all agent specifications from registry."""
        # First get all agent names (This is actually returning a List[Dict])
        agents_data = await self._request("GET", "/agent_registry/agents/")

        # Then fetch specs for each agent
        agent_specs = {}
        for agent in agents_data:
            # 🎯 Extract the name string from the dictionary
            agent_name = agent.get('name')

            if not agent_name:
                logger.warning(f"⚠️ Found agent entry without a name: {agent}")
                continue

            spec = await self._request("GET", f"/agent_registry/agents/{agent_name}/spec")
            agent_specs[agent_name] = spec

        return agent_specs


    async def get_agent_spec(self, agent_name: str) -> Dict[str, Any]:
        """Get agent specification by name."""
        return await self._request("GET", f"/agent_registry/agents/{agent_name}/spec")

    async def search_tools(
            self,
            query: str,
            agent_id: str,  # 🚀 MANDATORY for security wall
            intent: str,  # 🚀 MANDATORY for context filtering
            n_results: int = 5,
            collection: str = "sutram_agentic_tools"
    ) -> List[Dict[str, Any]]:
        """
        Performs Secure Semantic Discovery.
        """
        payload = {
            "query": query,
            "agent_id": agent_id,
            "intent": intent,
            "n_results": n_results,
            "collection": collection
        }

        # Returns the normalized List[Dict] we perfected in the VectorServiceClient
        response = await self._request("POST", "/data_registry/search/vector", json=payload)
        return response.get("results", [])

    async def list_tools(self, filter_criteria: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """List all available tools with optional filter criteria."""
        params = filter_criteria or {}
        return await self._request("GET", "/tool_registry/tools", params=params)

    # Inside ToolRegistryClient
    async def resolve_semantic_tool(
            self,
            tool_intent: str,
            session_id: str,
            token: Optional[str] = None,
            tenant_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/tool_registry/semantic/resolve/{tool_intent}",
            token=token,
            tenant_id=tenant_id,
            json={'context': {'session_id': session_id}}
        )