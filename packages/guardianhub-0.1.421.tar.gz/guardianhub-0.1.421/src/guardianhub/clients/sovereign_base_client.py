# guardianhub/clients/sovereign_base_client.py
import httpx
from typing import Any, Optional
from opentelemetry import baggage, propagate, context as otel_context
from guardianhub import get_logger

logger = get_logger(__name__)


class SovereignBaseClient:
    """
    Refactored Base Client: Uses a shared session to prevent socket exhaustion.
    Ensures Identity, Tenant, and Trace baggage are injected into every strike.
    """

    def __init__(self, shared_client: httpx.AsyncClient, base_url: str):
        self._client = shared_client  # <--- Shared from the "Well"
        self._base_url = base_url.rstrip('/')

    async def _request(
            self,
            method: str,
            path: str,
            token: Optional[str] = None,
            tenant_id: Optional[str] = None,
            **kwargs
    ) -> Any:
        url = f"{self._base_url}{path}"
        current_ctx = otel_context.get_current()

        # 1. Identity & Tenant Extraction from OTel Baggage
        bg_tenant = tenant_id or baggage.get_baggage("tenant_id", current_ctx)
        bg_token = token or baggage.get_baggage("access_token", current_ctx)

        # 2. Header Preparation
        headers = kwargs.get('headers', {})
        if bg_token:
            headers['Authorization'] = bg_token if "Bearer" in bg_token else f"Bearer {bg_token}"
        if bg_tenant:
            headers['X-Tenant-ID'] = str(bg_tenant)
            headers['X-Sovereign-Context'] = "active"

        # 3. Trace Propagation (Injects traceparent)
        propagate.inject(headers)
        kwargs['headers'] = headers

        try:
            # 🚀 Use the shared client (No 'async with' here!)
            response = await self._client.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"❌ [SOVEREIGN_FAILURE] {method} {path} | Status: {e.response.status_code}")
            raise