import hvac  # The standard HashiCorp Vault Python client
from guardianhub import get_logger
from settings import CoreSettings

logger = get_logger(__name__)

class VaultManager:
    def __init__(self, core_settings: CoreSettings):
        self.settings = core_settings
        self.client = hvac.Client(url=self.settings.vault.url, token=self.settings.vault.token)

    def populate_session_tenant(self, tenant_id: str):
        """
        Reads tenant-specific directories from Vault and populates
        the SDK settings for the current session.
        """
        if not self.settings.vault.enabled:
            config_logger.info("Vault integration disabled, skipping tenant population.")
            return

        # 1. Construct the path
        path = self.settings.vault.tenant_path_template.format(tenant_id=tenant_id)

        try:
            # 2. Read from Vault (KV v2)
            read_response = self.client.secrets.kv.v2.read_secret_version(
                path=path,
                mount_point=self.settings.vault.mount_point
            )
            tenant_secrets = read_response['data']['data']

            # 3. Dynamic Injection into Endpoints or Credentials
            # We update the 'endpoints' and 'credentials' specifically
            for key, value in tenant_secrets.items():
                if hasattr(self.settings.endpoints, key):
                    setattr(self.settings.endpoints, key, value)

                # Also inject into credentials vault
                setattr(self.settings.credentials, key.upper(), value)

            config_logger.info(f"Successfully populated settings for tenant: {tenant_id}")

        except Exception as e:
            config_logger.error(f"Failed to fetch secrets for tenant {tenant_id} from Vault: {e}")
            raise