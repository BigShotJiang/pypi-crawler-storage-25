import json
from mcp.server.fastmcp import FastMCP
from guardianhub.services.container import ServiceContainer, ServiceFlavor

# 1. Initialize FastMCP
mcp = FastMCP("guardianhub-core")

# 2. Singleton Container Access
# This ensures we use the pooled HTTP clients and OTel tracers you built
container = ServiceContainer.get_instance()


# guardianhub-sdk/src/guardianhub/mcp_server.py

@mcp.on_startup()
async def startup():
    """
    Ensure the Well is fully warm before the MCP port opens.
    """
    logger.info("🔥 Igniting Sovereign Well for MCP Subprocess...")
    try:
        # Increase timeout or ensure flavors are minimal for the proxy
        await container.initialize(flavors=[
            ServiceFlavor.CORE,
            ServiceFlavor.KNOWLEDGE
        ])
        logger.info("✅ Well is warm. MCP ready to pinch.")
    except Exception as e:
        logger.error(f"❌ Well Ignition Failed: {e}")
        # Crucial: don't let it hang, exit so OpenClaw can retry
        raise e


@mcp.tool()
async def list_recent_missions(limit: int = 5) -> str:
    """
    Queries the Knowledge Flavor for recently anchored Mission DNA.
    """
    # Use the 'graph' pump directly from the container
    query = "MATCH (m:MissionBlueprint) RETURN m ORDER BY m.last_evolved_at DESC LIMIT $limit"
    results = await container.graph._execute_read_query(query, {"limit": limit})

    return json.dumps(results, indent=2)


@mcp.tool()
async def get_mission_blueprint(template_id: str) -> str:
    """
    Fetches specific Mission DNA using the container's GraphDBClient logic.
    """
    dna = await container.graph.get_mission_dna(template_id)
    if not dna:
        return f"Error: DNA {template_id} not found."
    return json.dumps(dna, indent=2)


@mcp.on_shutdown()
async def shutdown():
    """Gracefully drain the Sovereign Well."""
    await container.shutdown()


if __name__ == "__main__":
    mcp.run()