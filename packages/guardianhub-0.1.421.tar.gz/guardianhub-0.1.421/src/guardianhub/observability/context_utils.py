from typing import Optional, Dict, Any
from opentelemetry import baggage, context, trace
from opentelemetry.trace import SpanContext, TraceFlags

import os
from opentelemetry.trace import SpanContext, TraceFlags

def build_sovereign_context(
    baggage_items: Dict[str, Any],
    trace_id_hex: Optional[str] = None,
    base_ctx: Optional[context.Context] = None
) -> context.Context:
    """
    The Master Builder: Creates an immutable OTel context chain.
    """
    # 1. Inherit existing reality (crucial for Baggage continuity)
    ctx = base_ctx if base_ctx is not None else context.get_current()

    # 2. 🔗 Lazarus Logic: Rebuild the Lineage
    if trace_id_hex:
        try:
            # Fallback span_id: Get current or generate a deterministic one from session_id
            # Using 0 is often ignored by exporters like Langfuse
            current_span = trace.get_current_span().get_span_context()
            fallback_span_id = current_span.span_id if current_span.span_id != 0 else int(os.urandom(8).hex(), 16)

            span_context = SpanContext(
                trace_id=int(trace_id_hex, 16),
                span_id=fallback_span_id,
                is_remote=True,
                trace_flags=TraceFlags(TraceFlags.SAMPLED)
            )
            # This "Welds" the trace ID to the context
            ctx = trace.set_span_in_context(trace.NonRecordingSpan(span_context), context=ctx)
        except Exception as e:
            # Don't let a trace parsing error kill the mission
            print(f"⚠️ Trace reconstitution failed: {e}")

    # 3. 🎒 Immutable Baggage Chain
    for key, value in baggage_items.items():
        if value:
            # We use str() to ensure it's not a NoneType or Object
            ctx = baggage.set_value(key, str(value), context=ctx)

    return ctx

def set_baggage_context(baggage_items: Dict[str, Any], current_ctx: Optional[context.Context] = None) -> context.Token:
    """Attaches identity baggage to the current execution thread."""
    ctx = build_sovereign_context(baggage_items, base_ctx=current_ctx or context.get_current())
    return context.attach(ctx)

def reconstitute_trace_context(trace_id_hex: str, baggage_items: Dict[str, Any]) -> context.Context:
    """Helper for /resume logic to rebuild a trace from Postgres state."""
    return build_sovereign_context(baggage_items, trace_id_hex=trace_id_hex)