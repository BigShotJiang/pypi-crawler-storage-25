# sutram_services/container.py
import os
import httpx
from typing import Optional, Any, List, Set
from guardianhub import get_logger
from guardianhub.config.settings import settings

# SDK Clients refactored for shared pools
from guardianhub.clients.vector_client import VectorClient
from guardianhub.clients.llm_client import LLMClient
from guardianhub.clients.tool_registry_client import ToolRegistryClient
from guardianhub.clients.graph_db_client import GraphDBClient
from guardianhub.clients.langfuse.manager import LangfuseManager
from enum import Enum
from typing import List
from opentelemetry import trace # 👈 Add this import
logger = get_logger(__name__)
# standard Flavours.
class ServiceFlavor(str, Enum):
    CORE = "core"               # HTTP, Langfuse, LLM, Registry
    PERSISTENCE = "persistence" # Postgres Pool & LangGraph Checkpointer
    KNOWLEDGE = "mind"     # Vector & GraphDB (The Librarian)
    WORKFLOW = "muscle"           # Reserved for service-specific extensions
    GATEWAY_UPLINK = "satellite"  # 🛰️ New Flavor for the OpenClaw SDK

class ServiceContainer:
    _instance: Optional['ServiceContainer'] = None

    def __init__(self):
        # 1. Private Infrastructure (Physical Connections)
        self._http_client: Optional[httpx.AsyncClient] = None
        self._db_pool: Optional[Any] = None

        # 2. Public Pumps (Client Instances)
        self.vector: Optional[VectorClient] = None
        self.llm: Optional[LLMClient] = None
        self.registry: Optional[ToolRegistryClient] = None
        self.graph: Optional[GraphDBClient] = None
        self.langfuse: Optional[Any] = None
        self.checkpointer: Optional[Any] = None
        self.prompt_registry: Optional[Any] = None
        self.gateway_client: Optional['OpenClawClient'] = None

        self._active_flavors: Set[ServiceFlavor] = set()
        self.tracer: Optional[trace.Tracer] = None  # 👈 Anchor it here
        self._initialized = False

    @classmethod
    def get_instance(cls) -> 'ServiceContainer':
        if not cls._instance:
            cls._instance = cls()
        return cls._instance

    async def initialize(self, flavors: List[ServiceFlavor] = [ServiceFlavor.CORE]):
        """Lifecycle Start: Dig the well, install the pumps."""
        if self._initialized:
            return


        logger.info("🚀 [SOVEREIGN_WELL] Initializing cluster-wide shared well...")

        self._active_flavors = set(flavors)

        logger.info(f"🚀 [SOVEREIGN_WELL] Initializing with flavors: {[f.value for f in flavors]}")

        if ServiceFlavor.CORE in self._active_flavors:
            from guardianhub.clients.langfuse.manager import LangfuseManager
            from guardianhub.agents.services.prompt_manager import SovereignPromptRegistry
            from guardianhub.clients.llm_client import LLMClient
            from guardianhub.clients.tool_registry_client import ToolRegistryClient

            logger.info("🔧 [SOVEREIGN_WELL] Initializing CORE flavor clients...")

            self.langfuse = LangfuseManager.get_instance()
            logger.info(f"✅ [SOVEREIGN_WELL] Langfuse initialized: {self.langfuse is not None}")

            if self.langfuse:
                self.prompt_registry = SovereignPromptRegistry(self.langfuse)
                logger.info("✅ [SOVEREIGN_WELL] PromptRegistry initialized")

            self._http_client = httpx.AsyncClient(
                limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
                timeout=settings.endpoints.get("GLOBAL_TIMEOUT", 30.0)
            )
            logger.info("✅ [SOVEREIGN_WELL] HTTP client (shared pool) initialized")

            self.tracer = trace.get_tracer(settings.service.name or "guardianhub-service")
            logger.info(f"✅ [SOVEREIGN_WELL] Tracer initialized: {settings.service.name or 'guardianhub-service'}")

            self.llm = LLMClient(shared_client=self._http_client)
            logger.info("✅ [SOVEREIGN_WELL] LLM client initialized")

            self.registry = ToolRegistryClient(http_client=self._http_client)
            logger.info("✅ [SOVEREIGN_WELL] ToolRegistry client initialized")

        # --- FLAVOR: KNOWLEDGE ---
        # Inside ServiceContainer.initialize
        if ServiceFlavor.GATEWAY_UPLINK in self._active_flavors:
            from openclaw_sdk import OpenClawClient

            # We pass the SHARED HTTP POOL to the SDK if the SDK supports it,
            # otherwise we ensure it uses the same environment/tracing logic.
            self.gateway_client = await OpenClawClient.connect(
                api_key=os.getenv("OPENCLAW_API_KEY"),
                # We ensure the SDK connects to the same tracing context
                # used by the rest of the Well.
            )
            logger.info("✅ [SOVEREIGN_WELL] Gateway Uplink (Satellite) Pump installed.")


        if ServiceFlavor.KNOWLEDGE in self._active_flavors:
            from guardianhub.clients.vector_client import VectorClient
            from guardianhub.clients.graph_db_client import GraphDBClient

            logger.info("🔧 [SOVEREIGN_WELL] Initializing KNOWLEDGE flavor clients...")

            # Use shared_client from CORE if available, else build a minimal one
            self.vector = VectorClient(shared_client=self._http_client)
            logger.info("✅ [SOVEREIGN_WELL] Vector client initialized")

            self.graph = GraphDBClient(shared_client=self._http_client)
            logger.info("✅ [SOVEREIGN_WELL] GraphDB client initialized")

            await self.vector.initialize()
            logger.info("✅ [SOVEREIGN_WELL] Vector client warmed up (collections ensured)")
            # --- FLAVOR: PERSISTENCE ---
        if ServiceFlavor.PERSISTENCE in self._active_flavors:
            logger.info("🔧 [SOVEREIGN_WELL] Initializing PERSISTENCE flavor...")

            db_url = (
                f"postgresql://{os.getenv('MASTER_DB_ADMIN')}:"
                f"{os.getenv('MASTER_DB_ADMIN_PASSWORD')}@"
                f"{os.getenv('POSTGRES_HOST', 'localhost')}:5432/"
                f"{os.getenv('MASTER_TENANT_DB')}"
            )
            await self._initialize_db_well(db_url)
            logger.info("✅ [SOVEREIGN_WELL] Database pool and checkpointer initialized")

        self._initialized = True
        logger.info("🏛️ [SOVEREIGN_WELL] Vessel is fully loaded.")

        self._initialized = True
        logger.info("🏛️ [SOVEREIGN_WELL] All infrastructure is warm and observable.")

    async def _initialize_db_well(self, db_url: str):
        """Internalizes connection pooling and LangGraph persistence."""
        try:
            from psycopg_pool import AsyncConnectionPool
            from psycopg.rows import dict_row
            from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

            self._db_pool = AsyncConnectionPool(
                conninfo=db_url,
                min_size=2,
                max_size=20,
                open=False,
                kwargs={"autocommit": True, "row_factory": dict_row},
            )
            await self._db_pool.open()

            # Anchor checkpointer to the shared pool
            self._checkpointer = AsyncPostgresSaver(self._db_pool)
            await self._checkpointer.setup()

            logger.info("✅ [DATABASE] Persistence Well Ready.")
        except ImportError:
            logger.error(
                "❌ [PERSISTENCE_FAIL] 'psycopg' or 'langgraph' missing. "
                "Did you install guardianhub[brain,mind]?"
            )
            raise
        except Exception as e:
            logger.error(f"❌ [DATABASE_FAILURE] {e}")
            raise

    async def shutdown(self):
        """Lifecycle End: Drain connections gracefully."""
        logger.info("🔌 [SOVEREIGN_WELL] Draining connections...")
        if self._http_client:
            await self._http_client.aclose()
        if self._db_pool:
            await self._db_pool.close()
        if self.langfuse:
            self.langfuse.flush()  # 👈 Crucial for Kubernetes exits
        self._initialized = False