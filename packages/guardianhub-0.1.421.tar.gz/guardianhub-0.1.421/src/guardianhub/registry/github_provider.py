import httpx
from guardianhub.config import settings

async def fetch_sovereign_registry():
    """Pulls the latest tool definitions from your private GitHub registry."""
    async with httpx.AsyncClient() as client:
        # Use your GitHub Personal Access Token to hit your private repo
        response = await client.get(
            f"https://api.github.com/repos/{settings.GITHUB_ORG}/mcp-registry/contents/registry.json",
            headers={"Authorization": f"token {settings.GITHUB_TOKEN}"}
        )
        return response.json()