# pylint: disable=missing-module-docstring

from hydpy.core import sequencetools
from hydpy.core.typingtools import *


class Q(sequencetools.FluxSequence):
    """Abfluss [m³/s]."""

    NDIM: Final[Literal[0]] = 0
    SPAN = (0.0, None)
