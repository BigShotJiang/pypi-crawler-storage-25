#!python
# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION
# cython: language_level=3
# cython: cpow=True
# cython: boundscheck=False
# cython: wraparound=False
# cython: initializedcheck=False
# cython: cdivision=True
from typing import Optional
import numpy
cimport numpy
from libc.math cimport exp, fabs, log, sin, cos, tan, tanh, asin, acos, atan, isnan, isinf
from libc.math cimport NAN as nan
from libc.math cimport INFINITY as inf
import cython
from cpython.mem cimport PyMem_Malloc
from cpython.mem cimport PyMem_Realloc
from cpython.mem cimport PyMem_Free
from hydpy.cythons.autogen cimport configutils
from hydpy.cythons.autogen cimport interfaceutils
from hydpy.cythons.autogen cimport interputils
from hydpy.cythons.autogen import pointerutils
from hydpy.cythons.autogen cimport pointerutils
from hydpy.cythons.autogen cimport quadutils
from hydpy.cythons.autogen cimport rootutils
from hydpy.cythons.autogen cimport smoothutils
from hydpy.cythons.autogen cimport masterinterface


cdef void do_nothing(Model model)  noexcept nogil:
    pass

cpdef get_wrapper():
    cdef CallbackWrapper wrapper = CallbackWrapper()
    wrapper.callback = do_nothing
    return wrapper

@cython.final
cdef class Parameters:
    pass
@cython.final
cdef class ControlParameters:
    pass
@cython.final
cdef class DerivedParameters:
    pass
@cython.final
cdef class Sequences:
    pass
@cython.final
cdef class ReceiverSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._q_diskflag_reading:
            self.q = self._q_ncarray[0]
        elif self._q_ramflag:
            self.q = self._q_array[idx]
        if self._watervolume_diskflag_reading:
            k = 0
            for jdx0 in range(self._watervolume_length_0):
                self.watervolume[jdx0] = self._watervolume_ncarray[k]
                k += 1
        elif self._watervolume_ramflag:
            for jdx0 in range(self._watervolume_length_0):
                self.watervolume[jdx0] = self._watervolume_array[idx, jdx0]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._q_diskflag_writing:
            self._q_ncarray[0] = self.q
        if self._q_ramflag:
            self._q_array[idx] = self.q
        if self._watervolume_diskflag_writing:
            k = 0
            for jdx0 in range(self._watervolume_length_0):
                self._watervolume_ncarray[k] = self.watervolume[jdx0]
                k += 1
        if self._watervolume_ramflag:
            for jdx0 in range(self._watervolume_length_0):
                self._watervolume_array[idx, jdx0] = self.watervolume[jdx0]
    cpdef inline set_pointer0d(self, str name, pointerutils.Double value):
        cdef pointerutils.PDouble pointer = pointerutils.PDouble(value)
        if name == "q":
            self._q_pointer = pointer.p_value
    cpdef inline alloc_pointer(self, name, numpy.int64_t length):
        if name == "watervolume":
            self._watervolume_length_0 = length
            self._watervolume_ready = numpy.full(length, 0, dtype=numpy.int64)
            self._watervolume_pointer = <double**> PyMem_Malloc(length * sizeof(double*))
    cpdef inline dealloc_pointer(self, name):
        if name == "watervolume":
            PyMem_Free(self._watervolume_pointer)
    cpdef inline set_pointer1d(self, str name, pointerutils.Double value, numpy.int64_t idx):
        cdef pointerutils.PDouble pointer = pointerutils.PDouble(value)
        if name == "watervolume":
            self._watervolume_pointer[idx] = pointer.p_value
            self._watervolume_ready[idx] = 1
    cpdef get_pointervalue(self, str name):
        cdef numpy.int64_t idx
        if name == "q":
            return self._q_pointer[0]
        if name == "watervolume":
            values = numpy.empty(self.len_watervolume)
            for idx in range(self.len_watervolume):
                pointerutils.check0(self._watervolume_length_0)
                if self._watervolume_ready[idx] == 0:
                    pointerutils.check1(self._watervolume_length_0, idx)
                    pointerutils.check2(self._watervolume_ready, idx)
                values[idx] = self._watervolume_pointer[idx][0]
            return values
    cpdef set_value(self, str name, value):
        if name == "q":
            self._q_pointer[0] = value
        if name == "watervolume":
            for idx in range(self.len_watervolume):
                pointerutils.check0(self._watervolume_length_0)
                if self._watervolume_ready[idx] == 0:
                    pointerutils.check1(self._watervolume_length_0, idx)
                    pointerutils.check2(self._watervolume_ready, idx)
                self._watervolume_pointer[idx][0] = value[idx]
@cython.final
cdef class FactorSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t k
        if self._alertness_diskflag_reading:
            self.alertness = self._alertness_ncarray[0]
        elif self._alertness_ramflag:
            self.alertness = self._alertness_array[idx]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t k
        if self._alertness_diskflag_writing:
            self._alertness_ncarray[0] = self.alertness
        if self._alertness_ramflag:
            self._alertness_array[idx] = self.alertness
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        if name == "alertness":
            self._alertness_outputpointer = value.p_value
    cpdef inline void update_outputs(self) noexcept nogil:
        if self._alertness_outputflag:
            self._alertness_outputpointer[0] = self.alertness
@cython.final
cdef class FluxSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._demandtarget_diskflag_reading:
            self.demandtarget = self._demandtarget_ncarray[0]
        elif self._demandtarget_ramflag:
            self.demandtarget = self._demandtarget_array[idx]
        if self._freedischarge_diskflag_reading:
            self.freedischarge = self._freedischarge_ncarray[0]
        elif self._freedischarge_ramflag:
            self.freedischarge = self._freedischarge_array[idx]
        if self._demandsources_diskflag_reading:
            k = 0
            for jdx0 in range(self._demandsources_length_0):
                self.demandsources[jdx0] = self._demandsources_ncarray[k]
                k += 1
        elif self._demandsources_ramflag:
            for jdx0 in range(self._demandsources_length_0):
                self.demandsources[jdx0] = self._demandsources_array[idx, jdx0]
        if self._possiblerelease_diskflag_reading:
            k = 0
            for jdx0 in range(self._possiblerelease_length_0):
                self.possiblerelease[jdx0] = self._possiblerelease_ncarray[k]
                k += 1
        elif self._possiblerelease_ramflag:
            for jdx0 in range(self._possiblerelease_length_0):
                self.possiblerelease[jdx0] = self._possiblerelease_array[idx, jdx0]
        if self._request_diskflag_reading:
            k = 0
            for jdx0 in range(self._request_length_0):
                self.request[jdx0] = self._request_ncarray[k]
                k += 1
        elif self._request_ramflag:
            for jdx0 in range(self._request_length_0):
                self.request[jdx0] = self._request_array[idx, jdx0]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._demandtarget_diskflag_writing:
            self._demandtarget_ncarray[0] = self.demandtarget
        if self._demandtarget_ramflag:
            self._demandtarget_array[idx] = self.demandtarget
        if self._freedischarge_diskflag_writing:
            self._freedischarge_ncarray[0] = self.freedischarge
        if self._freedischarge_ramflag:
            self._freedischarge_array[idx] = self.freedischarge
        if self._demandsources_diskflag_writing:
            k = 0
            for jdx0 in range(self._demandsources_length_0):
                self._demandsources_ncarray[k] = self.demandsources[jdx0]
                k += 1
        if self._demandsources_ramflag:
            for jdx0 in range(self._demandsources_length_0):
                self._demandsources_array[idx, jdx0] = self.demandsources[jdx0]
        if self._possiblerelease_diskflag_writing:
            k = 0
            for jdx0 in range(self._possiblerelease_length_0):
                self._possiblerelease_ncarray[k] = self.possiblerelease[jdx0]
                k += 1
        if self._possiblerelease_ramflag:
            for jdx0 in range(self._possiblerelease_length_0):
                self._possiblerelease_array[idx, jdx0] = self.possiblerelease[jdx0]
        if self._request_diskflag_writing:
            k = 0
            for jdx0 in range(self._request_length_0):
                self._request_ncarray[k] = self.request[jdx0]
                k += 1
        if self._request_ramflag:
            for jdx0 in range(self._request_length_0):
                self._request_array[idx, jdx0] = self.request[jdx0]
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        if name == "demandtarget":
            self._demandtarget_outputpointer = value.p_value
        if name == "freedischarge":
            self._freedischarge_outputpointer = value.p_value
    cpdef inline void update_outputs(self) noexcept nogil:
        if self._demandtarget_outputflag:
            self._demandtarget_outputpointer[0] = self.demandtarget
        if self._freedischarge_outputflag:
            self._freedischarge_outputpointer[0] = self.freedischarge
@cython.final
cdef class LogSequences:
    pass
@cython.final
cdef class SenderSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._request_diskflag_reading:
            k = 0
            for jdx0 in range(self._request_length_0):
                self.request[jdx0] = self._request_ncarray[k]
                k += 1
        elif self._request_ramflag:
            for jdx0 in range(self._request_length_0):
                self.request[jdx0] = self._request_array[idx, jdx0]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._request_diskflag_writing:
            k = 0
            for jdx0 in range(self._request_length_0):
                self._request_ncarray[k] = self.request[jdx0]
                k += 1
        if self._request_ramflag:
            for jdx0 in range(self._request_length_0):
                self._request_array[idx, jdx0] = self.request[jdx0]
    cpdef inline alloc_pointer(self, name, numpy.int64_t length):
        if name == "request":
            self._request_length_0 = length
            self._request_ready = numpy.full(length, 0, dtype=numpy.int64)
            self._request_pointer = <double**> PyMem_Malloc(length * sizeof(double*))
    cpdef inline dealloc_pointer(self, name):
        if name == "request":
            PyMem_Free(self._request_pointer)
    cpdef inline set_pointer1d(self, str name, pointerutils.Double value, numpy.int64_t idx):
        cdef pointerutils.PDouble pointer = pointerutils.PDouble(value)
        if name == "request":
            self._request_pointer[idx] = pointer.p_value
            self._request_ready[idx] = 1
    cpdef get_pointervalue(self, str name):
        cdef numpy.int64_t idx
        if name == "request":
            values = numpy.empty(self.len_request)
            for idx in range(self.len_request):
                pointerutils.check0(self._request_length_0)
                if self._request_ready[idx] == 0:
                    pointerutils.check1(self._request_length_0, idx)
                    pointerutils.check2(self._request_ready, idx)
                values[idx] = self._request_pointer[idx][0]
            return values
    cpdef set_value(self, str name, value):
        if name == "request":
            for idx in range(self.len_request):
                pointerutils.check0(self._request_length_0)
                if self._request_ready[idx] == 0:
                    pointerutils.check1(self._request_length_0, idx)
                    pointerutils.check2(self._request_ready, idx)
                self._request_pointer[idx][0] = value[idx]
@cython.final
cdef class Model:
    cpdef inline void simulate(self, numpy.int64_t idx)  noexcept nogil:
        cdef double state
        self.idx_sim = idx
        self.load_data(idx)
        self.run()
        self.update_senders()
        self.update_outputs()
    cpdef void simulate_period(self, numpy.int64_t i0, numpy.int64_t i1)  noexcept nogil:
        cdef numpy.int64_t i
        with nogil:
            for i in range(i0, i1):
                self.simulate(i)
                self.update_receivers(i)
                self.save_data(i)
    cpdef void reset_reuseflags(self) noexcept nogil:
        pass
    cpdef void load_data(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        self.sequences.receivers.load_data(idx)
    cpdef void save_data(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        self.sequences.receivers.save_data(idx)
        self.sequences.factors.save_data(idx)
        self.sequences.fluxes.save_data(idx)
        self.sequences.senders.save_data(idx)
    cpdef inline void run(self) noexcept nogil:
        self.calc_freedischarge_v1()
        self.calc_demandtarget_v1()
        self.calc_alertness_v1()
        self.calc_demandsources_v1()
        self.calc_possiblerelease_v1()
        self.calc_request_v1()
        self.update_loggedrequest_v1()
    cpdef void update_inlets(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_outlets(self) noexcept nogil:
        pass
        cdef numpy.int64_t i
    cpdef void update_observers(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_receivers(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        cdef numpy.int64_t i
        if not self.threading:
            self.sequences.receivers.q = self.sequences.receivers._q_pointer[0]
        if not self.threading:
            for i in range(self.sequences.receivers._watervolume_length_0):
                if self.sequences.receivers._watervolume_ready[i]:
                    self.sequences.receivers.watervolume[i] = self.sequences.receivers._watervolume_pointer[i][0]
                else:
                    self.sequences.receivers.watervolume[i] = nan
        self.pick_loggeddischarge_v1()
        self.pick_loggedwatervolume_v1()
    cpdef void update_senders(self) noexcept nogil:
        self.pass_request_v1()
        cdef numpy.int64_t i
        if not self.threading:
            for i in range(self.sequences.senders._request_length_0):
                if self.sequences.senders._request_ready[i]:
                    self.sequences.senders._request_pointer[i][0] = self.sequences.senders._request_pointer[i][0] + self.sequences.senders.request[i]
    cpdef void update_outputs(self) noexcept nogil:
        if not self.threading:
            self.sequences.factors.update_outputs()
            self.sequences.fluxes.update_outputs()
    cpdef inline void pick_loggeddischarge_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.derived.memorylength - 1, 0, -1):
            self.sequences.logs.loggeddischarge[i] = self.sequences.logs.loggeddischarge[i - 1]
        self.sequences.logs.loggeddischarge[0] = self.sequences.receivers.q
    cpdef inline void pick_loggedwatervolume_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.sources):
            self.sequences.logs.loggedwatervolume[i] = self.sequences.receivers.watervolume[i]
    cpdef inline void calc_freedischarge_v1(self) noexcept nogil:
        cdef double q_old
        cdef numpy.int64_t i
        cdef double q_min
        self.sequences.fluxes.freedischarge = self.sequences.logs.loggeddischarge[0] - self.sequences.logs.loggedrequest[self.parameters.control.timedelay]
        q_min = inf
        for i in range(1, self.parameters.control.timewindow):
            q_old = self.sequences.logs.loggeddischarge[i] - self.sequences.logs.loggedrequest[i + self.parameters.control.timedelay]
            q_min = min(q_min, self.sequences.fluxes.freedischarge + (self.sequences.fluxes.freedischarge - q_old) / i)
        self.sequences.fluxes.freedischarge = max(min(self.sequences.fluxes.freedischarge, q_min), 0.0)
    cpdef inline void calc_demandtarget_v1(self) noexcept nogil:
        self.sequences.fluxes.demandtarget = smoothutils.smooth_max1(            self.parameters.control.dischargethreshold - self.sequences.fluxes.freedischarge, 0.0, self.parameters.derived.dischargesmoothpar        )
    cpdef inline void calc_alertness_v1(self) noexcept nogil:
        self.sequences.factors.alertness = smoothutils.smooth_logistic1(            self.parameters.control.dischargethreshold - self.sequences.fluxes.freedischarge, self.parameters.derived.dischargesmoothpar        )
    cpdef inline void calc_demandsources_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef double v2q
        v2q = 1e6 / self.parameters.derived.seconds
        for i in range(self.parameters.control.sources):
            if self.parameters.control.active[i]:
                self.sequences.fluxes.demandsources[i] = (                    self.sequences.factors.alertness                    * v2q                    * smoothutils.smooth_max1(                        self.parameters.control.volumethreshold[i] - self.sequences.logs.loggedwatervolume[i],                        0.0,                        self.parameters.derived.volumesmoothpar[i],                    )                )
            else:
                self.sequences.fluxes.demandsources[i] = 0.0
    cpdef inline void calc_possiblerelease_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef double v2q
        v2q = 1e6 / self.parameters.derived.seconds
        for i in range(self.parameters.control.sources):
            if self.parameters.control.active[i]:
                self.sequences.fluxes.possiblerelease[i] = min(                    v2q * max(self.sequences.logs.loggedwatervolume[i] - self.parameters.control.volumethreshold[i], 0.0),                    self.parameters.control.releasemax[i],                )
            else:
                self.sequences.fluxes.possiblerelease[i] = 0.0
    cpdef inline void calc_request_v1(self) noexcept nogil:
        cdef double demand
        cdef numpy.int64_t j
        cdef numpy.int64_t jj
        cdef double f
        cdef double available
        cdef numpy.int64_t i
        if self.idx_sim < self.parameters.control.commission:
            for i in range(self.parameters.control.sources):
                self.sequences.fluxes.request[i] = 0.0
        else:
            available = 0.0
            for i in range(self.parameters.control.sources):
                if self.parameters.derived.adjacency[i, 0]:
                    available = available + (self.sequences.fluxes.possiblerelease[i])
            f = 0.0 if available <= 0 else min(self.sequences.fluxes.demandtarget / available, 1.0)
            for i in range(self.parameters.control.sources):
                if self.parameters.derived.adjacency[i, 0]:
                    self.sequences.fluxes.request[i] = f * self.sequences.fluxes.possiblerelease[i]
            for jj in range(self.parameters.control.sources):
                j = self.parameters.derived.order[jj]
                demand = self.sequences.fluxes.request[j] + self.sequences.fluxes.demandsources[j]
                if demand <= 0.0:
                    f = 0.0
                else:
                    available = 0.0
                    for i in range(self.parameters.control.sources):
                        if self.parameters.derived.adjacency[i, j + 1]:
                            available = available + (self.sequences.fluxes.possiblerelease[i])
                    f = 0.0 if available <= 0.0 else min(demand / available, 1.0)
                for i in range(self.parameters.control.sources):
                    if self.parameters.derived.adjacency[i, j + 1]:
                        self.sequences.fluxes.request[i] = f * self.sequences.fluxes.possiblerelease[i]
    cpdef inline void update_loggedrequest_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.derived.memorylength - 1, 0, -1):
            self.sequences.logs.loggedrequest[i] = self.sequences.logs.loggedrequest[i - 1]
        self.sequences.logs.loggedrequest[0] = 0.0
        for i in range(self.parameters.control.sources):
            if self.parameters.derived.adjacency[i, 0]:
                self.sequences.logs.loggedrequest[0] = self.sequences.logs.loggedrequest[0] + (self.sequences.fluxes.request[i])
    cpdef inline void pass_request_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.sources):
            self.sequences.senders.request[i] = self.sequences.fluxes.request[i]
    cpdef inline void pick_loggeddischarge(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.derived.memorylength - 1, 0, -1):
            self.sequences.logs.loggeddischarge[i] = self.sequences.logs.loggeddischarge[i - 1]
        self.sequences.logs.loggeddischarge[0] = self.sequences.receivers.q
    cpdef inline void pick_loggedwatervolume(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.sources):
            self.sequences.logs.loggedwatervolume[i] = self.sequences.receivers.watervolume[i]
    cpdef inline void calc_freedischarge(self) noexcept nogil:
        cdef double q_old
        cdef numpy.int64_t i
        cdef double q_min
        self.sequences.fluxes.freedischarge = self.sequences.logs.loggeddischarge[0] - self.sequences.logs.loggedrequest[self.parameters.control.timedelay]
        q_min = inf
        for i in range(1, self.parameters.control.timewindow):
            q_old = self.sequences.logs.loggeddischarge[i] - self.sequences.logs.loggedrequest[i + self.parameters.control.timedelay]
            q_min = min(q_min, self.sequences.fluxes.freedischarge + (self.sequences.fluxes.freedischarge - q_old) / i)
        self.sequences.fluxes.freedischarge = max(min(self.sequences.fluxes.freedischarge, q_min), 0.0)
    cpdef inline void calc_demandtarget(self) noexcept nogil:
        self.sequences.fluxes.demandtarget = smoothutils.smooth_max1(            self.parameters.control.dischargethreshold - self.sequences.fluxes.freedischarge, 0.0, self.parameters.derived.dischargesmoothpar        )
    cpdef inline void calc_alertness(self) noexcept nogil:
        self.sequences.factors.alertness = smoothutils.smooth_logistic1(            self.parameters.control.dischargethreshold - self.sequences.fluxes.freedischarge, self.parameters.derived.dischargesmoothpar        )
    cpdef inline void calc_demandsources(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef double v2q
        v2q = 1e6 / self.parameters.derived.seconds
        for i in range(self.parameters.control.sources):
            if self.parameters.control.active[i]:
                self.sequences.fluxes.demandsources[i] = (                    self.sequences.factors.alertness                    * v2q                    * smoothutils.smooth_max1(                        self.parameters.control.volumethreshold[i] - self.sequences.logs.loggedwatervolume[i],                        0.0,                        self.parameters.derived.volumesmoothpar[i],                    )                )
            else:
                self.sequences.fluxes.demandsources[i] = 0.0
    cpdef inline void calc_possiblerelease(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef double v2q
        v2q = 1e6 / self.parameters.derived.seconds
        for i in range(self.parameters.control.sources):
            if self.parameters.control.active[i]:
                self.sequences.fluxes.possiblerelease[i] = min(                    v2q * max(self.sequences.logs.loggedwatervolume[i] - self.parameters.control.volumethreshold[i], 0.0),                    self.parameters.control.releasemax[i],                )
            else:
                self.sequences.fluxes.possiblerelease[i] = 0.0
    cpdef inline void calc_request(self) noexcept nogil:
        cdef double demand
        cdef numpy.int64_t j
        cdef numpy.int64_t jj
        cdef double f
        cdef double available
        cdef numpy.int64_t i
        if self.idx_sim < self.parameters.control.commission:
            for i in range(self.parameters.control.sources):
                self.sequences.fluxes.request[i] = 0.0
        else:
            available = 0.0
            for i in range(self.parameters.control.sources):
                if self.parameters.derived.adjacency[i, 0]:
                    available = available + (self.sequences.fluxes.possiblerelease[i])
            f = 0.0 if available <= 0 else min(self.sequences.fluxes.demandtarget / available, 1.0)
            for i in range(self.parameters.control.sources):
                if self.parameters.derived.adjacency[i, 0]:
                    self.sequences.fluxes.request[i] = f * self.sequences.fluxes.possiblerelease[i]
            for jj in range(self.parameters.control.sources):
                j = self.parameters.derived.order[jj]
                demand = self.sequences.fluxes.request[j] + self.sequences.fluxes.demandsources[j]
                if demand <= 0.0:
                    f = 0.0
                else:
                    available = 0.0
                    for i in range(self.parameters.control.sources):
                        if self.parameters.derived.adjacency[i, j + 1]:
                            available = available + (self.sequences.fluxes.possiblerelease[i])
                    f = 0.0 if available <= 0.0 else min(demand / available, 1.0)
                for i in range(self.parameters.control.sources):
                    if self.parameters.derived.adjacency[i, j + 1]:
                        self.sequences.fluxes.request[i] = f * self.sequences.fluxes.possiblerelease[i]
    cpdef inline void update_loggedrequest(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.derived.memorylength - 1, 0, -1):
            self.sequences.logs.loggedrequest[i] = self.sequences.logs.loggedrequest[i - 1]
        self.sequences.logs.loggedrequest[0] = 0.0
        for i in range(self.parameters.control.sources):
            if self.parameters.derived.adjacency[i, 0]:
                self.sequences.logs.loggedrequest[0] = self.sequences.logs.loggedrequest[0] + (self.sequences.fluxes.request[i])
    cpdef inline void pass_request(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.sources):
            self.sequences.senders.request[i] = self.sequences.fluxes.request[i]
