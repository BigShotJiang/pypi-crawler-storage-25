#!python
# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION
# cython: language_level=3
# cython: cpow=True
# cython: boundscheck=False
# cython: wraparound=False
# cython: initializedcheck=False
# cython: cdivision=True
from typing import Optional
import numpy
cimport numpy
from libc.math cimport exp, fabs, log, sin, cos, tan, tanh, asin, acos, atan, isnan, isinf
from libc.math cimport NAN as nan
from libc.math cimport INFINITY as inf
import cython
from cpython.mem cimport PyMem_Malloc
from cpython.mem cimport PyMem_Realloc
from cpython.mem cimport PyMem_Free
from hydpy.cythons.autogen cimport configutils
from hydpy.cythons.autogen cimport interfaceutils
from hydpy.cythons.autogen cimport interputils
from hydpy.cythons.autogen import pointerutils
from hydpy.cythons.autogen cimport pointerutils
from hydpy.cythons.autogen cimport quadutils
from hydpy.cythons.autogen cimport rootutils
from hydpy.cythons.autogen cimport smoothutils
from hydpy.cythons.autogen cimport masterinterface
ctypedef void (*CallbackType) (Model)  noexcept nogil
cdef class CallbackWrapper:
    cdef CallbackType callback
@cython.final
cdef class Parameters:
    cdef public ControlParameters control
    cdef public DerivedParameters derived
@cython.final
cdef class ControlParameters:
    cdef public numpy.int64_t commission
    cdef public double dischargethreshold
    cdef public double dischargetolerance
    cdef public numpy.int64_t timedelay
    cdef public numpy.int64_t timewindow
    cdef public numpy.int64_t sources
    cdef public double[:] volumethreshold
    cdef public double[:] volumetolerance
    cdef public double[:] releasemax
    cdef public numpy.npy_bool[:] active
@cython.final
cdef class DerivedParameters:
    cdef public double seconds
    cdef public double dischargesmoothpar
    cdef public double[:] volumesmoothpar
    cdef public numpy.int64_t memorylength
    cdef public numpy.npy_bool[:,:] adjacency
    cdef public numpy.int64_t[:] order
@cython.final
cdef class Sequences:
    cdef public ReceiverSequences receivers
    cdef public FactorSequences factors
    cdef public FluxSequences fluxes
    cdef public LogSequences logs
    cdef public SenderSequences senders
@cython.final
cdef class ReceiverSequences:
    cdef public double q
    cdef public numpy.int64_t _q_ndim
    cdef public numpy.int64_t _q_length
    cdef public bint _q_ramflag
    cdef public double[:] _q_array
    cdef public bint _q_diskflag_reading
    cdef public bint _q_diskflag_writing
    cdef public double[:] _q_ncarray
    cdef double *_q_pointer
    cdef public double[:] watervolume
    cdef public numpy.int64_t _watervolume_ndim
    cdef public numpy.int64_t _watervolume_length
    cdef public numpy.int64_t _watervolume_length_0
    cdef public bint _watervolume_ramflag
    cdef public double[:,:] _watervolume_array
    cdef public bint _watervolume_diskflag_reading
    cdef public bint _watervolume_diskflag_writing
    cdef public double[:] _watervolume_ncarray
    cdef double **_watervolume_pointer
    cdef public numpy.int64_t len_watervolume
    cdef public numpy.int64_t[:] _watervolume_ready
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointer0d(self, str name, pointerutils.Double value)
    cpdef inline alloc_pointer(self, name, numpy.int64_t length)
    cpdef inline dealloc_pointer(self, name)
    cpdef inline set_pointer1d(self, str name, pointerutils.Double value, numpy.int64_t idx)
    cpdef get_pointervalue(self, str name)
    cpdef set_value(self, str name, value)
@cython.final
cdef class FactorSequences:
    cdef public double alertness
    cdef public numpy.int64_t _alertness_ndim
    cdef public numpy.int64_t _alertness_length
    cdef public bint _alertness_ramflag
    cdef public double[:] _alertness_array
    cdef public bint _alertness_diskflag_reading
    cdef public bint _alertness_diskflag_writing
    cdef public double[:] _alertness_ncarray
    cdef public bint _alertness_outputflag
    cdef double *_alertness_outputpointer
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value)
    cpdef inline void update_outputs(self) noexcept nogil
@cython.final
cdef class FluxSequences:
    cdef public double demandtarget
    cdef public numpy.int64_t _demandtarget_ndim
    cdef public numpy.int64_t _demandtarget_length
    cdef public bint _demandtarget_ramflag
    cdef public double[:] _demandtarget_array
    cdef public bint _demandtarget_diskflag_reading
    cdef public bint _demandtarget_diskflag_writing
    cdef public double[:] _demandtarget_ncarray
    cdef public bint _demandtarget_outputflag
    cdef double *_demandtarget_outputpointer
    cdef public double freedischarge
    cdef public numpy.int64_t _freedischarge_ndim
    cdef public numpy.int64_t _freedischarge_length
    cdef public bint _freedischarge_ramflag
    cdef public double[:] _freedischarge_array
    cdef public bint _freedischarge_diskflag_reading
    cdef public bint _freedischarge_diskflag_writing
    cdef public double[:] _freedischarge_ncarray
    cdef public bint _freedischarge_outputflag
    cdef double *_freedischarge_outputpointer
    cdef public double[:] demandsources
    cdef public numpy.int64_t _demandsources_ndim
    cdef public numpy.int64_t _demandsources_length
    cdef public numpy.int64_t _demandsources_length_0
    cdef public bint _demandsources_ramflag
    cdef public double[:,:] _demandsources_array
    cdef public bint _demandsources_diskflag_reading
    cdef public bint _demandsources_diskflag_writing
    cdef public double[:] _demandsources_ncarray
    cdef public double[:] possiblerelease
    cdef public numpy.int64_t _possiblerelease_ndim
    cdef public numpy.int64_t _possiblerelease_length
    cdef public numpy.int64_t _possiblerelease_length_0
    cdef public bint _possiblerelease_ramflag
    cdef public double[:,:] _possiblerelease_array
    cdef public bint _possiblerelease_diskflag_reading
    cdef public bint _possiblerelease_diskflag_writing
    cdef public double[:] _possiblerelease_ncarray
    cdef public double[:] request
    cdef public numpy.int64_t _request_ndim
    cdef public numpy.int64_t _request_length
    cdef public numpy.int64_t _request_length_0
    cdef public bint _request_ramflag
    cdef public double[:,:] _request_array
    cdef public bint _request_diskflag_reading
    cdef public bint _request_diskflag_writing
    cdef public double[:] _request_ncarray
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value)
    cpdef inline void update_outputs(self) noexcept nogil
@cython.final
cdef class LogSequences:
    cdef public double[:] loggeddischarge
    cdef public numpy.int64_t _loggeddischarge_ndim
    cdef public numpy.int64_t _loggeddischarge_length
    cdef public numpy.int64_t _loggeddischarge_length_0
    cdef public double[:] loggedrequest
    cdef public numpy.int64_t _loggedrequest_ndim
    cdef public numpy.int64_t _loggedrequest_length
    cdef public numpy.int64_t _loggedrequest_length_0
    cdef public double[:] loggedwatervolume
    cdef public numpy.int64_t _loggedwatervolume_ndim
    cdef public numpy.int64_t _loggedwatervolume_length
    cdef public numpy.int64_t _loggedwatervolume_length_0
@cython.final
cdef class SenderSequences:
    cdef public double[:] request
    cdef public numpy.int64_t _request_ndim
    cdef public numpy.int64_t _request_length
    cdef public numpy.int64_t _request_length_0
    cdef public bint _request_ramflag
    cdef public double[:,:] _request_array
    cdef public bint _request_diskflag_reading
    cdef public bint _request_diskflag_writing
    cdef public double[:] _request_ncarray
    cdef double **_request_pointer
    cdef public numpy.int64_t len_request
    cdef public numpy.int64_t[:] _request_ready
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil
    cpdef inline alloc_pointer(self, name, numpy.int64_t length)
    cpdef inline dealloc_pointer(self, name)
    cpdef inline set_pointer1d(self, str name, pointerutils.Double value, numpy.int64_t idx)
    cpdef get_pointervalue(self, str name)
    cpdef set_value(self, str name, value)
@cython.final
cdef class Model:
    cdef public numpy.int64_t idx_sim
    cdef public numpy.npy_bool threading
    cdef public Parameters parameters
    cdef public Sequences sequences
    cpdef inline void simulate(self, numpy.int64_t idx)  noexcept nogil
    cpdef void simulate_period(self, numpy.int64_t i0, numpy.int64_t i1)  noexcept nogil
    cpdef void reset_reuseflags(self) noexcept nogil
    cpdef void load_data(self, numpy.int64_t idx) noexcept nogil
    cpdef void save_data(self, numpy.int64_t idx) noexcept nogil
    cpdef inline void run(self) noexcept nogil
    cpdef void update_inlets(self) noexcept nogil
    cpdef void update_outlets(self) noexcept nogil
    cpdef void update_observers(self) noexcept nogil
    cpdef void update_receivers(self, numpy.int64_t idx) noexcept nogil
    cpdef void update_senders(self) noexcept nogil
    cpdef void update_outputs(self) noexcept nogil
    cpdef inline void pick_loggeddischarge_v1(self) noexcept nogil
    cpdef inline void pick_loggedwatervolume_v1(self) noexcept nogil
    cpdef inline void calc_freedischarge_v1(self) noexcept nogil
    cpdef inline void calc_demandtarget_v1(self) noexcept nogil
    cpdef inline void calc_alertness_v1(self) noexcept nogil
    cpdef inline void calc_demandsources_v1(self) noexcept nogil
    cpdef inline void calc_possiblerelease_v1(self) noexcept nogil
    cpdef inline void calc_request_v1(self) noexcept nogil
    cpdef inline void update_loggedrequest_v1(self) noexcept nogil
    cpdef inline void pass_request_v1(self) noexcept nogil
    cpdef inline void pick_loggeddischarge(self) noexcept nogil
    cpdef inline void pick_loggedwatervolume(self) noexcept nogil
    cpdef inline void calc_freedischarge(self) noexcept nogil
    cpdef inline void calc_demandtarget(self) noexcept nogil
    cpdef inline void calc_alertness(self) noexcept nogil
    cpdef inline void calc_demandsources(self) noexcept nogil
    cpdef inline void calc_possiblerelease(self) noexcept nogil
    cpdef inline void calc_request(self) noexcept nogil
    cpdef inline void update_loggedrequest(self) noexcept nogil
    cpdef inline void pass_request(self) noexcept nogil
