#!python
# distutils: define_macros=NPY_NO_DEPRECATED_API=NPY_1_7_API_VERSION
# cython: language_level=3
# cython: cpow=True
# cython: boundscheck=False
# cython: wraparound=False
# cython: initializedcheck=False
# cython: cdivision=True
from typing import Optional
import numpy
cimport numpy
from libc.math cimport exp, fabs, log, sin, cos, tan, tanh, asin, acos, atan, isnan, isinf
from libc.math cimport NAN as nan
from libc.math cimport INFINITY as inf
import cython
from cpython.mem cimport PyMem_Malloc
from cpython.mem cimport PyMem_Realloc
from cpython.mem cimport PyMem_Free
from hydpy.cythons.autogen cimport configutils
from hydpy.cythons.autogen cimport interfaceutils
from hydpy.cythons.autogen cimport interputils
from hydpy.cythons.autogen import pointerutils
from hydpy.cythons.autogen cimport pointerutils
from hydpy.cythons.autogen cimport quadutils
from hydpy.cythons.autogen cimport rootutils
from hydpy.cythons.autogen cimport smoothutils
from hydpy.cythons.autogen cimport masterinterface


cdef void do_nothing(Model model)  noexcept nogil:
    pass

cpdef get_wrapper():
    cdef CallbackWrapper wrapper = CallbackWrapper()
    wrapper.callback = do_nothing
    return wrapper

@cython.final
cdef class Parameters:
    pass
@cython.final
cdef class ControlParameters:
    pass
@cython.final
cdef class DerivedParameters:
    pass
@cython.final
cdef class Sequences:
    pass
@cython.final
cdef class FactorSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._waterdepth_diskflag_reading:
            self.waterdepth = self._waterdepth_ncarray[0]
        elif self._waterdepth_ramflag:
            self.waterdepth = self._waterdepth_array[idx]
        if self._waterlevel_diskflag_reading:
            self.waterlevel = self._waterlevel_ncarray[0]
        elif self._waterlevel_ramflag:
            self.waterlevel = self._waterlevel_array[idx]
        if self._wettedareas_diskflag_reading:
            k = 0
            for jdx0 in range(self._wettedareas_length_0):
                self.wettedareas[jdx0] = self._wettedareas_ncarray[k]
                k += 1
        elif self._wettedareas_ramflag:
            for jdx0 in range(self._wettedareas_length_0):
                self.wettedareas[jdx0] = self._wettedareas_array[idx, jdx0]
        if self._wettedarea_diskflag_reading:
            self.wettedarea = self._wettedarea_ncarray[0]
        elif self._wettedarea_ramflag:
            self.wettedarea = self._wettedarea_array[idx]
        if self._flowareas_diskflag_reading:
            k = 0
            for jdx0 in range(self._flowareas_length_0):
                self.flowareas[jdx0] = self._flowareas_ncarray[k]
                k += 1
        elif self._flowareas_ramflag:
            for jdx0 in range(self._flowareas_length_0):
                self.flowareas[jdx0] = self._flowareas_array[idx, jdx0]
        if self._flowarea_diskflag_reading:
            self.flowarea = self._flowarea_ncarray[0]
        elif self._flowarea_ramflag:
            self.flowarea = self._flowarea_array[idx]
        if self._totalareas_diskflag_reading:
            k = 0
            for jdx0 in range(self._totalareas_length_0):
                self.totalareas[jdx0] = self._totalareas_ncarray[k]
                k += 1
        elif self._totalareas_ramflag:
            for jdx0 in range(self._totalareas_length_0):
                self.totalareas[jdx0] = self._totalareas_array[idx, jdx0]
        if self._totalarea_diskflag_reading:
            self.totalarea = self._totalarea_ncarray[0]
        elif self._totalarea_ramflag:
            self.totalarea = self._totalarea_array[idx]
        if self._wettedperimeters_diskflag_reading:
            k = 0
            for jdx0 in range(self._wettedperimeters_length_0):
                self.wettedperimeters[jdx0] = self._wettedperimeters_ncarray[k]
                k += 1
        elif self._wettedperimeters_ramflag:
            for jdx0 in range(self._wettedperimeters_length_0):
                self.wettedperimeters[jdx0] = self._wettedperimeters_array[idx, jdx0]
        if self._flowperimeters_diskflag_reading:
            k = 0
            for jdx0 in range(self._flowperimeters_length_0):
                self.flowperimeters[jdx0] = self._flowperimeters_ncarray[k]
                k += 1
        elif self._flowperimeters_ramflag:
            for jdx0 in range(self._flowperimeters_length_0):
                self.flowperimeters[jdx0] = self._flowperimeters_array[idx, jdx0]
        if self._wettedperimeter_diskflag_reading:
            self.wettedperimeter = self._wettedperimeter_ncarray[0]
        elif self._wettedperimeter_ramflag:
            self.wettedperimeter = self._wettedperimeter_array[idx]
        if self._wettedperimeterderivatives_diskflag_reading:
            k = 0
            for jdx0 in range(self._wettedperimeterderivatives_length_0):
                self.wettedperimeterderivatives[jdx0] = self._wettedperimeterderivatives_ncarray[k]
                k += 1
        elif self._wettedperimeterderivatives_ramflag:
            for jdx0 in range(self._wettedperimeterderivatives_length_0):
                self.wettedperimeterderivatives[jdx0] = self._wettedperimeterderivatives_array[idx, jdx0]
        if self._flowperimeterderivatives_diskflag_reading:
            k = 0
            for jdx0 in range(self._flowperimeterderivatives_length_0):
                self.flowperimeterderivatives[jdx0] = self._flowperimeterderivatives_ncarray[k]
                k += 1
        elif self._flowperimeterderivatives_ramflag:
            for jdx0 in range(self._flowperimeterderivatives_length_0):
                self.flowperimeterderivatives[jdx0] = self._flowperimeterderivatives_array[idx, jdx0]
        if self._surfacewidths_diskflag_reading:
            k = 0
            for jdx0 in range(self._surfacewidths_length_0):
                self.surfacewidths[jdx0] = self._surfacewidths_ncarray[k]
                k += 1
        elif self._surfacewidths_ramflag:
            for jdx0 in range(self._surfacewidths_length_0):
                self.surfacewidths[jdx0] = self._surfacewidths_array[idx, jdx0]
        if self._surfacewidth_diskflag_reading:
            self.surfacewidth = self._surfacewidth_ncarray[0]
        elif self._surfacewidth_ramflag:
            self.surfacewidth = self._surfacewidth_array[idx]
        if self._flowwidths_diskflag_reading:
            k = 0
            for jdx0 in range(self._flowwidths_length_0):
                self.flowwidths[jdx0] = self._flowwidths_ncarray[k]
                k += 1
        elif self._flowwidths_ramflag:
            for jdx0 in range(self._flowwidths_length_0):
                self.flowwidths[jdx0] = self._flowwidths_array[idx, jdx0]
        if self._totalwidths_diskflag_reading:
            k = 0
            for jdx0 in range(self._totalwidths_length_0):
                self.totalwidths[jdx0] = self._totalwidths_ncarray[k]
                k += 1
        elif self._totalwidths_ramflag:
            for jdx0 in range(self._totalwidths_length_0):
                self.totalwidths[jdx0] = self._totalwidths_array[idx, jdx0]
        if self._totalwidth_diskflag_reading:
            self.totalwidth = self._totalwidth_ncarray[0]
        elif self._totalwidth_ramflag:
            self.totalwidth = self._totalwidth_array[idx]
        if self._dischargederivatives_diskflag_reading:
            k = 0
            for jdx0 in range(self._dischargederivatives_length_0):
                self.dischargederivatives[jdx0] = self._dischargederivatives_ncarray[k]
                k += 1
        elif self._dischargederivatives_ramflag:
            for jdx0 in range(self._dischargederivatives_length_0):
                self.dischargederivatives[jdx0] = self._dischargederivatives_array[idx, jdx0]
        if self._dischargederivative_diskflag_reading:
            self.dischargederivative = self._dischargederivative_ncarray[0]
        elif self._dischargederivative_ramflag:
            self.dischargederivative = self._dischargederivative_array[idx]
        if self._celerity_diskflag_reading:
            self.celerity = self._celerity_ncarray[0]
        elif self._celerity_ramflag:
            self.celerity = self._celerity_array[idx]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._waterdepth_diskflag_writing:
            self._waterdepth_ncarray[0] = self.waterdepth
        if self._waterdepth_ramflag:
            self._waterdepth_array[idx] = self.waterdepth
        if self._waterlevel_diskflag_writing:
            self._waterlevel_ncarray[0] = self.waterlevel
        if self._waterlevel_ramflag:
            self._waterlevel_array[idx] = self.waterlevel
        if self._wettedareas_diskflag_writing:
            k = 0
            for jdx0 in range(self._wettedareas_length_0):
                self._wettedareas_ncarray[k] = self.wettedareas[jdx0]
                k += 1
        if self._wettedareas_ramflag:
            for jdx0 in range(self._wettedareas_length_0):
                self._wettedareas_array[idx, jdx0] = self.wettedareas[jdx0]
        if self._wettedarea_diskflag_writing:
            self._wettedarea_ncarray[0] = self.wettedarea
        if self._wettedarea_ramflag:
            self._wettedarea_array[idx] = self.wettedarea
        if self._flowareas_diskflag_writing:
            k = 0
            for jdx0 in range(self._flowareas_length_0):
                self._flowareas_ncarray[k] = self.flowareas[jdx0]
                k += 1
        if self._flowareas_ramflag:
            for jdx0 in range(self._flowareas_length_0):
                self._flowareas_array[idx, jdx0] = self.flowareas[jdx0]
        if self._flowarea_diskflag_writing:
            self._flowarea_ncarray[0] = self.flowarea
        if self._flowarea_ramflag:
            self._flowarea_array[idx] = self.flowarea
        if self._totalareas_diskflag_writing:
            k = 0
            for jdx0 in range(self._totalareas_length_0):
                self._totalareas_ncarray[k] = self.totalareas[jdx0]
                k += 1
        if self._totalareas_ramflag:
            for jdx0 in range(self._totalareas_length_0):
                self._totalareas_array[idx, jdx0] = self.totalareas[jdx0]
        if self._totalarea_diskflag_writing:
            self._totalarea_ncarray[0] = self.totalarea
        if self._totalarea_ramflag:
            self._totalarea_array[idx] = self.totalarea
        if self._wettedperimeters_diskflag_writing:
            k = 0
            for jdx0 in range(self._wettedperimeters_length_0):
                self._wettedperimeters_ncarray[k] = self.wettedperimeters[jdx0]
                k += 1
        if self._wettedperimeters_ramflag:
            for jdx0 in range(self._wettedperimeters_length_0):
                self._wettedperimeters_array[idx, jdx0] = self.wettedperimeters[jdx0]
        if self._flowperimeters_diskflag_writing:
            k = 0
            for jdx0 in range(self._flowperimeters_length_0):
                self._flowperimeters_ncarray[k] = self.flowperimeters[jdx0]
                k += 1
        if self._flowperimeters_ramflag:
            for jdx0 in range(self._flowperimeters_length_0):
                self._flowperimeters_array[idx, jdx0] = self.flowperimeters[jdx0]
        if self._wettedperimeter_diskflag_writing:
            self._wettedperimeter_ncarray[0] = self.wettedperimeter
        if self._wettedperimeter_ramflag:
            self._wettedperimeter_array[idx] = self.wettedperimeter
        if self._wettedperimeterderivatives_diskflag_writing:
            k = 0
            for jdx0 in range(self._wettedperimeterderivatives_length_0):
                self._wettedperimeterderivatives_ncarray[k] = self.wettedperimeterderivatives[jdx0]
                k += 1
        if self._wettedperimeterderivatives_ramflag:
            for jdx0 in range(self._wettedperimeterderivatives_length_0):
                self._wettedperimeterderivatives_array[idx, jdx0] = self.wettedperimeterderivatives[jdx0]
        if self._flowperimeterderivatives_diskflag_writing:
            k = 0
            for jdx0 in range(self._flowperimeterderivatives_length_0):
                self._flowperimeterderivatives_ncarray[k] = self.flowperimeterderivatives[jdx0]
                k += 1
        if self._flowperimeterderivatives_ramflag:
            for jdx0 in range(self._flowperimeterderivatives_length_0):
                self._flowperimeterderivatives_array[idx, jdx0] = self.flowperimeterderivatives[jdx0]
        if self._surfacewidths_diskflag_writing:
            k = 0
            for jdx0 in range(self._surfacewidths_length_0):
                self._surfacewidths_ncarray[k] = self.surfacewidths[jdx0]
                k += 1
        if self._surfacewidths_ramflag:
            for jdx0 in range(self._surfacewidths_length_0):
                self._surfacewidths_array[idx, jdx0] = self.surfacewidths[jdx0]
        if self._surfacewidth_diskflag_writing:
            self._surfacewidth_ncarray[0] = self.surfacewidth
        if self._surfacewidth_ramflag:
            self._surfacewidth_array[idx] = self.surfacewidth
        if self._flowwidths_diskflag_writing:
            k = 0
            for jdx0 in range(self._flowwidths_length_0):
                self._flowwidths_ncarray[k] = self.flowwidths[jdx0]
                k += 1
        if self._flowwidths_ramflag:
            for jdx0 in range(self._flowwidths_length_0):
                self._flowwidths_array[idx, jdx0] = self.flowwidths[jdx0]
        if self._totalwidths_diskflag_writing:
            k = 0
            for jdx0 in range(self._totalwidths_length_0):
                self._totalwidths_ncarray[k] = self.totalwidths[jdx0]
                k += 1
        if self._totalwidths_ramflag:
            for jdx0 in range(self._totalwidths_length_0):
                self._totalwidths_array[idx, jdx0] = self.totalwidths[jdx0]
        if self._totalwidth_diskflag_writing:
            self._totalwidth_ncarray[0] = self.totalwidth
        if self._totalwidth_ramflag:
            self._totalwidth_array[idx] = self.totalwidth
        if self._dischargederivatives_diskflag_writing:
            k = 0
            for jdx0 in range(self._dischargederivatives_length_0):
                self._dischargederivatives_ncarray[k] = self.dischargederivatives[jdx0]
                k += 1
        if self._dischargederivatives_ramflag:
            for jdx0 in range(self._dischargederivatives_length_0):
                self._dischargederivatives_array[idx, jdx0] = self.dischargederivatives[jdx0]
        if self._dischargederivative_diskflag_writing:
            self._dischargederivative_ncarray[0] = self.dischargederivative
        if self._dischargederivative_ramflag:
            self._dischargederivative_array[idx] = self.dischargederivative
        if self._celerity_diskflag_writing:
            self._celerity_ncarray[0] = self.celerity
        if self._celerity_ramflag:
            self._celerity_array[idx] = self.celerity
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        if name == "waterdepth":
            self._waterdepth_outputpointer = value.p_value
        if name == "waterlevel":
            self._waterlevel_outputpointer = value.p_value
        if name == "wettedarea":
            self._wettedarea_outputpointer = value.p_value
        if name == "flowarea":
            self._flowarea_outputpointer = value.p_value
        if name == "totalarea":
            self._totalarea_outputpointer = value.p_value
        if name == "wettedperimeter":
            self._wettedperimeter_outputpointer = value.p_value
        if name == "surfacewidth":
            self._surfacewidth_outputpointer = value.p_value
        if name == "totalwidth":
            self._totalwidth_outputpointer = value.p_value
        if name == "dischargederivative":
            self._dischargederivative_outputpointer = value.p_value
        if name == "celerity":
            self._celerity_outputpointer = value.p_value
    cpdef inline void update_outputs(self) noexcept nogil:
        if self._waterdepth_outputflag:
            self._waterdepth_outputpointer[0] = self.waterdepth
        if self._waterlevel_outputflag:
            self._waterlevel_outputpointer[0] = self.waterlevel
        if self._wettedarea_outputflag:
            self._wettedarea_outputpointer[0] = self.wettedarea
        if self._flowarea_outputflag:
            self._flowarea_outputpointer[0] = self.flowarea
        if self._totalarea_outputflag:
            self._totalarea_outputpointer[0] = self.totalarea
        if self._wettedperimeter_outputflag:
            self._wettedperimeter_outputpointer[0] = self.wettedperimeter
        if self._surfacewidth_outputflag:
            self._surfacewidth_outputpointer[0] = self.surfacewidth
        if self._totalwidth_outputflag:
            self._totalwidth_outputpointer[0] = self.totalwidth
        if self._dischargederivative_outputflag:
            self._dischargederivative_outputpointer[0] = self.dischargederivative
        if self._celerity_outputflag:
            self._celerity_outputpointer[0] = self.celerity
@cython.final
cdef class FluxSequences:
    cpdef inline void load_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._discharges_diskflag_reading:
            k = 0
            for jdx0 in range(self._discharges_length_0):
                self.discharges[jdx0] = self._discharges_ncarray[k]
                k += 1
        elif self._discharges_ramflag:
            for jdx0 in range(self._discharges_length_0):
                self.discharges[jdx0] = self._discharges_array[idx, jdx0]
        if self._discharge_diskflag_reading:
            self.discharge = self._discharge_ncarray[0]
        elif self._discharge_ramflag:
            self.discharge = self._discharge_array[idx]
    cpdef inline void save_data(self, numpy.int64_t idx)  noexcept nogil:
        cdef numpy.int64_t jdx0
        cdef numpy.int64_t k
        if self._discharges_diskflag_writing:
            k = 0
            for jdx0 in range(self._discharges_length_0):
                self._discharges_ncarray[k] = self.discharges[jdx0]
                k += 1
        if self._discharges_ramflag:
            for jdx0 in range(self._discharges_length_0):
                self._discharges_array[idx, jdx0] = self.discharges[jdx0]
        if self._discharge_diskflag_writing:
            self._discharge_ncarray[0] = self.discharge
        if self._discharge_ramflag:
            self._discharge_array[idx] = self.discharge
    cpdef inline set_pointeroutput(self, str name, pointerutils.PDouble value):
        if name == "discharge":
            self._discharge_outputpointer = value.p_value
    cpdef inline void update_outputs(self) noexcept nogil:
        if self._discharge_outputflag:
            self._discharge_outputpointer[0] = self.discharge
@cython.final
cdef class AideSequences:
    pass
@cython.final
cdef class Model:
    cpdef inline void simulate(self, numpy.int64_t idx)  noexcept nogil:
        cdef double state
        self.idx_sim = idx
        self.run()
        self.update_outputs()
    cpdef void simulate_period(self, numpy.int64_t i0, numpy.int64_t i1)  noexcept nogil:
        cdef numpy.int64_t i
        with nogil:
            for i in range(i0, i1):
                self.simulate(i)
                self.update_receivers(i)
                self.save_data(i)
    cpdef void reset_reuseflags(self) noexcept nogil:
        pass
    cpdef void save_data(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        self.sequences.factors.save_data(idx)
        self.sequences.fluxes.save_data(idx)
    cpdef inline void run(self) noexcept nogil:
        pass
    cpdef void update_inlets(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_outlets(self) noexcept nogil:
        pass
        cdef numpy.int64_t i
    cpdef void update_observers(self) noexcept nogil:
        cdef numpy.int64_t i
        pass
    cpdef void update_receivers(self, numpy.int64_t idx) noexcept nogil:
        self.idx_sim = idx
        cdef numpy.int64_t i
        pass
    cpdef void update_senders(self) noexcept nogil:
        pass
        cdef numpy.int64_t i
    cpdef void update_outputs(self) noexcept nogil:
        if not self.threading:
            self.sequences.factors.update_outputs()
            self.sequences.fluxes.update_outputs()
    cpdef inline void calc_waterdepth_v1(self) noexcept nogil:
        self.sequences.factors.waterdepth = max(self.sequences.factors.waterlevel - self.parameters.control.bottomlevels[0], 0.0)
    cpdef inline void calc_waterdepth_v2(self) noexcept nogil:
        cdef double ss
        cdef numpy.int64_t i
        cdef double w
        cdef double d
        cdef double a
        a = self.sequences.factors.wettedarea
        d = 0.0
        w = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            if a > self.parameters.derived.trapezeareas[i]:
                a = a - (self.parameters.derived.trapezeareas[i])
                d = d + (self.parameters.derived.trapezeheights[i])
                w = w + (self.parameters.control.bottomwidths[i] + self.parameters.derived.slopewidths[i])
            else:
                if a > 0.0:
                    w = w + (self.parameters.control.bottomwidths[i])
                    ss = self.parameters.control.sideslopes[i]
                    if ss > 1e-10:
                        d = d + (((4.0 * ss * a + w**2.0) ** 0.5 - w) / (2.0 * ss))
                    else:
                        d = d + (a / w)
                self.sequences.factors.waterdepth = d
                break
    cpdef inline void calc_waterdepth_v3(self) noexcept nogil:
        self.sequences.factors.waterdepth = max(self.sequences.factors.waterlevel - self.parameters.control.heights[0], 0.0)
    cpdef inline void calc_waterlevel_v1(self) noexcept nogil:
        self.sequences.factors.waterlevel = self.sequences.factors.waterdepth + self.parameters.control.bottomlevels[0]
    cpdef inline void calc_waterlevel_v2(self) noexcept nogil:
        self.sequences.factors.waterlevel = self.sequences.factors.waterdepth + self.parameters.control.heights[0]
    cpdef inline void calc_index_excess_weight_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        if self.sequences.factors.waterlevel <= self.parameters.control.heights[0]:
            self.sequences.aides.index = 0.0
            self.sequences.aides.weight = 0.0
            self.sequences.aides.excess = 0.0
        else:
            for i in range(self.parameters.control.nmbwidths - 1):
                if self.sequences.factors.waterlevel < self.parameters.control.heights[i + 1]:
                    self.sequences.aides.index = i
                    self.sequences.aides.excess = self.sequences.factors.waterlevel - self.parameters.control.heights[i]
                    self.sequences.aides.weight = self.sequences.aides.excess / (self.parameters.control.heights[i + 1] - self.parameters.control.heights[i])
                    break
            else:
                self.sequences.aides.index = self.parameters.control.nmbwidths - 1
                self.sequences.aides.excess = self.sequences.factors.waterlevel - self.parameters.control.heights[self.parameters.control.nmbwidths - 1]
                self.sequences.aides.weight = nan
    cpdef inline void calc_wettedareas_v1(self) noexcept nogil:
        cdef double ws
        cdef double ss
        cdef double wb
        cdef double ht
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedareas[i] = 0.0
            else:
                ht = self.parameters.derived.trapezeheights[i]
                wb = self.parameters.control.bottomwidths[i]
                if d < ht:
                    ss = self.parameters.control.sideslopes[i]
                    self.sequences.factors.wettedareas[i] = (wb + ss * d) * d
                else:
                    ws = self.parameters.derived.slopewidths[i]
                    self.sequences.factors.wettedareas[i] = (wb + ws / 2.0) * ht + (wb + ws) * (d - ht)
    cpdef inline void calc_flowareas_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowareas[i] = self.parameters.derived.sectorflowareas[i, j] + (                self.sequences.aides.excess * (self.parameters.derived.sectorflowwidths[i, j] + self.sequences.factors.flowwidths[i]) / 2.0            )
    cpdef inline void calc_totalareas_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalareas[i] = self.parameters.derived.sectortotalareas[i, j] + (                self.sequences.aides.excess * (self.parameters.derived.sectortotalwidths[i, j] + self.sequences.factors.totalwidths[i]) / 2.0            )
    cpdef inline void calc_wettedarea_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.wettedarea = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.wettedarea = self.sequences.factors.wettedarea + (self.sequences.factors.wettedareas[i])
    cpdef inline void calc_flowarea_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.flowarea = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowarea = self.sequences.factors.flowarea + (self.sequences.factors.flowareas[i])
    cpdef inline void calc_totalarea_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.totalarea = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalarea = self.sequences.factors.totalarea + (self.sequences.factors.totalareas[i])
    cpdef inline void calc_wettedperimeters_v1(self) noexcept nogil:
        cdef double ss
        cdef double wb
        cdef double ht
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedperimeters[i] = 0.0
            else:
                ht = self.parameters.derived.trapezeheights[i]
                wb = self.parameters.control.bottomwidths[i]
                ss = self.parameters.control.sideslopes[i]
                if d < ht:
                    self.sequences.factors.wettedperimeters[i] = wb + 2.0 * d * (ss**2.0 + 1.0) ** 0.5
                else:
                    self.sequences.factors.wettedperimeters[i] = (                        wb + 2.0 * ht * (ss**2.0 + 1.0) ** 0.5 + 2.0 * (d - ht)                    )
    cpdef inline void calc_flowperimeters_v1(self) noexcept nogil:
        cdef double w
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowperimeters[i] = (                    self.parameters.derived.sectorflowperimeters[i, j] + 2.0 * self.sequences.aides.excess                )
        else:
            for i in range(self.parameters.control.nmbsectors):
                w = self.sequences.aides.weight
                self.sequences.factors.flowperimeters[i] = (1.0 - w) * self.parameters.derived.sectorflowperimeters[                    i, j                ] + w * self.parameters.derived.sectorflowperimeters[i, j + 1]
    cpdef inline void calc_wettedperimeter_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.wettedperimeter = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.wettedperimeter = self.sequences.factors.wettedperimeter + (self.sequences.factors.wettedperimeters[i])
    cpdef inline void calc_wettedperimeterderivatives_v1(self) noexcept nogil:
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedperimeterderivatives[i] = 0.0
            elif d < self.parameters.derived.trapezeheights[i]:
                self.sequences.factors.wettedperimeterderivatives[i] = self.parameters.derived.perimeterderivatives[i]
            else:
                self.sequences.factors.wettedperimeterderivatives[i] = 2.0
    cpdef inline void calc_flowperimeterderivatives_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowperimeterderivatives[i] = self.parameters.derived.sectorflowperimeterderivatives[i, j]
    cpdef inline void calc_surfacewidths_v1(self) noexcept nogil:
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.surfacewidths[i] = 0.0
            elif d < self.parameters.derived.trapezeheights[i]:
                self.sequences.factors.surfacewidths[i] = self.parameters.control.bottomwidths[i] + 2.0 * self.parameters.control.sideslopes[i] * d
            else:
                self.sequences.factors.surfacewidths[i] = self.parameters.control.bottomwidths[i] + self.parameters.derived.slopewidths[i]
    cpdef inline void calc_surfacewidth_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.surfacewidth = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.surfacewidth = self.sequences.factors.surfacewidth + (self.sequences.factors.surfacewidths[i])
    cpdef inline void calc_flowwidths_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowwidths[i] = self.parameters.derived.sectorflowwidths[i, j]
        else:
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowwidths[i] = (1.0 - self.sequences.aides.weight) * self.parameters.derived.sectorflowwidths[                    i, j                ] + self.sequences.aides.weight * self.parameters.derived.sectorflowwidths[i, j + 1]
    cpdef inline void calc_totalwidths_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.totalwidths[i] = self.parameters.derived.sectortotalwidths[i, j]
        else:
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.totalwidths[i] = (1.0 - self.sequences.aides.weight) * self.parameters.derived.sectortotalwidths[                    i, j                ] + self.sequences.aides.weight * self.parameters.derived.sectortotalwidths[i, j + 1]
    cpdef inline void calc_totalwidth_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.totalwidth = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalwidth = self.sequences.factors.totalwidth + (self.sequences.factors.totalwidths[i])
    cpdef inline void calc_discharges_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            if self.sequences.factors.waterdepth > self.parameters.derived.bottomdepths[i]:
                self.sequences.fluxes.discharges[i] = (                    self.parameters.control.calibrationfactors[i]                    * self.parameters.control.stricklercoefficients[i]                    * self.parameters.control.bottomslope**0.5                    * self.sequences.factors.wettedareas[i] ** (5.0 / 3.0)                    / self.sequences.factors.wettedperimeters[i] ** (2.0 / 3.0)                )
            else:
                self.sequences.fluxes.discharges[i] = 0.0
    cpdef inline void calc_discharges_v2(self) noexcept nogil:
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbsectors):
            if self.sequences.factors.flowareas[i] > 0.0:
                self.sequences.fluxes.discharges[i] = (                    self.parameters.control.calibrationfactors[i]                    * self.parameters.control.stricklercoefficients[i]                    * self.parameters.control.bottomslope**0.5                    * self.sequences.factors.flowareas[i] ** (5.0 / 3.0)                    / self.sequences.factors.flowperimeters[i] ** (2.0 / 3.0)                )
            else:
                self.sequences.fluxes.discharges[i] = 0.0
    cpdef inline void calc_discharge_v2(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.fluxes.discharge = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.fluxes.discharge = self.sequences.fluxes.discharge + (self.sequences.fluxes.discharges[i])
    cpdef inline void calc_discharge_v3(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.fluxes.discharge = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.fluxes.discharge = self.sequences.fluxes.discharge + (self.sequences.fluxes.discharges[i])
    cpdef inline void calc_dischargederivatives_v1(self) noexcept nogil:
        cdef double dp
        cdef double p
        cdef double da
        cdef double a
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            if self.sequences.factors.waterdepth > self.parameters.derived.bottomdepths[i]:
                a = self.sequences.factors.wettedareas[i]
                da = self.sequences.factors.surfacewidths[i]
                p = self.sequences.factors.wettedperimeters[i]
                dp = self.sequences.factors.wettedperimeterderivatives[i]
                self.sequences.factors.dischargederivatives[i] = (                    self.parameters.control.calibrationfactors[i]                    * self.parameters.control.stricklercoefficients[i]                    * self.parameters.control.bottomslope**0.5                    * (a / p) ** (2.0 / 3.0)                    * (5.0 * p * da - 2.0 * a * dp)                    / (3.0 * p)                )
            else:
                self.sequences.factors.dischargederivatives[i] = 0.0
    cpdef inline void calc_dischargederivatives_v2(self) noexcept nogil:
        cdef double dp
        cdef double p
        cdef double da
        cdef double a
        cdef numpy.int64_t t
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbsectors):
            t = 0 if i == 0 else int(self.parameters.control.transitions[i - 1])
            if self.sequences.factors.waterlevel > self.parameters.control.heights[t]:
                a = self.sequences.factors.flowareas[i]
                da = self.sequences.factors.flowwidths[i]
                p = self.sequences.factors.flowperimeters[i]
                dp = self.sequences.factors.flowperimeterderivatives[i]
                self.sequences.factors.dischargederivatives[i] = (                    self.parameters.control.calibrationfactors[i]                    * self.parameters.control.stricklercoefficients[i]                    * self.parameters.control.bottomslope**0.5                    * (a / p) ** (2.0 / 3.0)                    * (5.0 * p * da - 2.0 * a * dp)                    / (3.0 * p)                )
            else:
                self.sequences.factors.dischargederivatives[i] = 0.0
    cpdef inline void calc_dischargederivative_v1(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.dischargederivative = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.dischargederivative = self.sequences.factors.dischargederivative + (self.sequences.factors.dischargederivatives[i])
    cpdef inline void calc_dischargederivative_v2(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.dischargederivative = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.dischargederivative = self.sequences.factors.dischargederivative + (self.sequences.factors.dischargederivatives[i])
    cpdef inline void calc_celerity_v1(self) noexcept nogil:
        if self.sequences.factors.surfacewidth > 0.0:
            self.sequences.factors.celerity = self.sequences.factors.dischargederivative / self.sequences.factors.surfacewidth
        else:
            self.sequences.factors.celerity = nan
    cpdef inline void calc_celerity_v2(self) noexcept nogil:
        if self.sequences.factors.totalwidth > 0.0:
            self.sequences.factors.celerity = self.sequences.factors.dischargederivative / self.sequences.factors.totalwidth
        else:
            self.sequences.factors.celerity = nan
    cpdef double calculate_discharge_v1(self, double waterdepth) noexcept nogil:
        cdef double f
        cdef double h
        h = smoothutils.smooth_logistic2(            waterdepth - self.parameters.control.crestheight, self.parameters.derived.crestheightregularisation        )
        f = (h / (self.parameters.control.channeldepth - self.parameters.control.crestheight)) ** self.parameters.control.dischargeexponent
        return self.parameters.control.bankfulldischarge * f
    cpdef void set_waterdepth_v1(self, double waterdepth) noexcept nogil:
        self.sequences.factors.waterdepth = waterdepth
    cpdef void set_waterlevel_v1(self, double waterlevel) noexcept nogil:
        self.sequences.factors.waterlevel = waterlevel
    cpdef void set_wettedarea_v1(self, double wettedarea) noexcept nogil:
        self.sequences.factors.wettedarea = wettedarea
    cpdef double get_waterdepth_v1(self) noexcept nogil:
        return self.sequences.factors.waterdepth
    cpdef double get_waterlevel_v1(self) noexcept nogil:
        return self.sequences.factors.waterlevel
    cpdef double get_wettedarea_v1(self) noexcept nogil:
        return self.sequences.factors.wettedarea
    cpdef double get_wettedarea_v2(self) noexcept nogil:
        return self.sequences.factors.totalarea
    cpdef double get_wettedperimeter_v1(self) noexcept nogil:
        return self.sequences.factors.wettedperimeter
    cpdef double get_surfacewidth_v1(self) noexcept nogil:
        return self.sequences.factors.surfacewidth
    cpdef double get_surfacewidth_v2(self) noexcept nogil:
        return self.sequences.factors.totalwidth
    cpdef double get_discharge_v1(self) noexcept nogil:
        return self.sequences.fluxes.discharge
    cpdef double get_celerity_v1(self) noexcept nogil:
        return self.sequences.factors.celerity
    cpdef inline void calc_index_excess_weight(self) noexcept nogil:
        cdef numpy.int64_t i
        if self.sequences.factors.waterlevel <= self.parameters.control.heights[0]:
            self.sequences.aides.index = 0.0
            self.sequences.aides.weight = 0.0
            self.sequences.aides.excess = 0.0
        else:
            for i in range(self.parameters.control.nmbwidths - 1):
                if self.sequences.factors.waterlevel < self.parameters.control.heights[i + 1]:
                    self.sequences.aides.index = i
                    self.sequences.aides.excess = self.sequences.factors.waterlevel - self.parameters.control.heights[i]
                    self.sequences.aides.weight = self.sequences.aides.excess / (self.parameters.control.heights[i + 1] - self.parameters.control.heights[i])
                    break
            else:
                self.sequences.aides.index = self.parameters.control.nmbwidths - 1
                self.sequences.aides.excess = self.sequences.factors.waterlevel - self.parameters.control.heights[self.parameters.control.nmbwidths - 1]
                self.sequences.aides.weight = nan
    cpdef inline void calc_wettedareas(self) noexcept nogil:
        cdef double ws
        cdef double ss
        cdef double wb
        cdef double ht
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedareas[i] = 0.0
            else:
                ht = self.parameters.derived.trapezeheights[i]
                wb = self.parameters.control.bottomwidths[i]
                if d < ht:
                    ss = self.parameters.control.sideslopes[i]
                    self.sequences.factors.wettedareas[i] = (wb + ss * d) * d
                else:
                    ws = self.parameters.derived.slopewidths[i]
                    self.sequences.factors.wettedareas[i] = (wb + ws / 2.0) * ht + (wb + ws) * (d - ht)
    cpdef inline void calc_flowareas(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowareas[i] = self.parameters.derived.sectorflowareas[i, j] + (                self.sequences.aides.excess * (self.parameters.derived.sectorflowwidths[i, j] + self.sequences.factors.flowwidths[i]) / 2.0            )
    cpdef inline void calc_totalareas(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalareas[i] = self.parameters.derived.sectortotalareas[i, j] + (                self.sequences.aides.excess * (self.parameters.derived.sectortotalwidths[i, j] + self.sequences.factors.totalwidths[i]) / 2.0            )
    cpdef inline void calc_wettedarea(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.wettedarea = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.wettedarea = self.sequences.factors.wettedarea + (self.sequences.factors.wettedareas[i])
    cpdef inline void calc_flowarea(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.flowarea = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowarea = self.sequences.factors.flowarea + (self.sequences.factors.flowareas[i])
    cpdef inline void calc_totalarea(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.totalarea = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalarea = self.sequences.factors.totalarea + (self.sequences.factors.totalareas[i])
    cpdef inline void calc_wettedperimeters(self) noexcept nogil:
        cdef double ss
        cdef double wb
        cdef double ht
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedperimeters[i] = 0.0
            else:
                ht = self.parameters.derived.trapezeheights[i]
                wb = self.parameters.control.bottomwidths[i]
                ss = self.parameters.control.sideslopes[i]
                if d < ht:
                    self.sequences.factors.wettedperimeters[i] = wb + 2.0 * d * (ss**2.0 + 1.0) ** 0.5
                else:
                    self.sequences.factors.wettedperimeters[i] = (                        wb + 2.0 * ht * (ss**2.0 + 1.0) ** 0.5 + 2.0 * (d - ht)                    )
    cpdef inline void calc_flowperimeters(self) noexcept nogil:
        cdef double w
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowperimeters[i] = (                    self.parameters.derived.sectorflowperimeters[i, j] + 2.0 * self.sequences.aides.excess                )
        else:
            for i in range(self.parameters.control.nmbsectors):
                w = self.sequences.aides.weight
                self.sequences.factors.flowperimeters[i] = (1.0 - w) * self.parameters.derived.sectorflowperimeters[                    i, j                ] + w * self.parameters.derived.sectorflowperimeters[i, j + 1]
    cpdef inline void calc_wettedperimeter(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.wettedperimeter = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.wettedperimeter = self.sequences.factors.wettedperimeter + (self.sequences.factors.wettedperimeters[i])
    cpdef inline void calc_wettedperimeterderivatives(self) noexcept nogil:
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.wettedperimeterderivatives[i] = 0.0
            elif d < self.parameters.derived.trapezeheights[i]:
                self.sequences.factors.wettedperimeterderivatives[i] = self.parameters.derived.perimeterderivatives[i]
            else:
                self.sequences.factors.wettedperimeterderivatives[i] = 2.0
    cpdef inline void calc_flowperimeterderivatives(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.flowperimeterderivatives[i] = self.parameters.derived.sectorflowperimeterderivatives[i, j]
    cpdef inline void calc_surfacewidths(self) noexcept nogil:
        cdef double d
        cdef numpy.int64_t i
        for i in range(self.parameters.control.nmbtrapezes):
            d = self.sequences.factors.waterdepth - self.parameters.derived.bottomdepths[i]
            if d < 0.0:
                self.sequences.factors.surfacewidths[i] = 0.0
            elif d < self.parameters.derived.trapezeheights[i]:
                self.sequences.factors.surfacewidths[i] = self.parameters.control.bottomwidths[i] + 2.0 * self.parameters.control.sideslopes[i] * d
            else:
                self.sequences.factors.surfacewidths[i] = self.parameters.control.bottomwidths[i] + self.parameters.derived.slopewidths[i]
    cpdef inline void calc_surfacewidth(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.surfacewidth = 0.0
        for i in range(self.parameters.control.nmbtrapezes):
            self.sequences.factors.surfacewidth = self.sequences.factors.surfacewidth + (self.sequences.factors.surfacewidths[i])
    cpdef inline void calc_flowwidths(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowwidths[i] = self.parameters.derived.sectorflowwidths[i, j]
        else:
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.flowwidths[i] = (1.0 - self.sequences.aides.weight) * self.parameters.derived.sectorflowwidths[                    i, j                ] + self.sequences.aides.weight * self.parameters.derived.sectorflowwidths[i, j + 1]
    cpdef inline void calc_totalwidths(self) noexcept nogil:
        cdef numpy.int64_t i
        cdef numpy.int64_t j
        j = int(self.sequences.aides.index)
        if isnan(self.sequences.aides.weight):
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.totalwidths[i] = self.parameters.derived.sectortotalwidths[i, j]
        else:
            for i in range(self.parameters.control.nmbsectors):
                self.sequences.factors.totalwidths[i] = (1.0 - self.sequences.aides.weight) * self.parameters.derived.sectortotalwidths[                    i, j                ] + self.sequences.aides.weight * self.parameters.derived.sectortotalwidths[i, j + 1]
    cpdef inline void calc_totalwidth(self) noexcept nogil:
        cdef numpy.int64_t i
        self.sequences.factors.totalwidth = 0.0
        for i in range(self.parameters.control.nmbsectors):
            self.sequences.factors.totalwidth = self.sequences.factors.totalwidth + (self.sequences.factors.totalwidths[i])
    cpdef double calculate_discharge(self, double waterdepth) noexcept nogil:
        cdef double f
        cdef double h
        h = smoothutils.smooth_logistic2(            waterdepth - self.parameters.control.crestheight, self.parameters.derived.crestheightregularisation        )
        f = (h / (self.parameters.control.channeldepth - self.parameters.control.crestheight)) ** self.parameters.control.dischargeexponent
        return self.parameters.control.bankfulldischarge * f
    cpdef void set_waterdepth(self, double waterdepth) noexcept nogil:
        self.sequences.factors.waterdepth = waterdepth
    cpdef void set_waterlevel(self, double waterlevel) noexcept nogil:
        self.sequences.factors.waterlevel = waterlevel
    cpdef void set_wettedarea(self, double wettedarea) noexcept nogil:
        self.sequences.factors.wettedarea = wettedarea
    cpdef double get_waterdepth(self) noexcept nogil:
        return self.sequences.factors.waterdepth
    cpdef double get_waterlevel(self) noexcept nogil:
        return self.sequences.factors.waterlevel
    cpdef double get_wettedperimeter(self) noexcept nogil:
        return self.sequences.factors.wettedperimeter
    cpdef double get_discharge(self) noexcept nogil:
        return self.sequences.fluxes.discharge
    cpdef double get_celerity(self) noexcept nogil:
        return self.sequences.factors.celerity
    cpdef void use_waterdepth_v1(self, double waterdepth) noexcept nogil:
        self.set_waterdepth_v1(waterdepth)
        self.calc_waterlevel_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeterderivatives_v1()
        self.calc_surfacewidths_v1()
        self.calc_surfacewidth_v1()
        self.calc_discharges_v1()
        self.calc_discharge_v2()
        self.calc_dischargederivatives_v1()
        self.calc_dischargederivative_v1()
        self.calc_celerity_v1()
    cpdef void use_waterdepth_v2(self, double waterdepth) noexcept nogil:
        self.set_waterdepth_v1(waterdepth)
        self.calc_waterlevel_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeter_v1()
    cpdef void use_waterdepth_v3(self, double waterdepth) noexcept nogil:
        self.set_waterdepth_v1(waterdepth)
        self.calc_waterlevel_v2()
        self.calc_index_excess_weight_v1()
        self.calc_flowwidths_v1()
        self.calc_totalwidths_v1()
        self.calc_totalwidth_v1()
        self.calc_flowareas_v1()
        self.calc_totalareas_v1()
        self.calc_flowperimeters_v1()
        self.calc_flowperimeterderivatives_v1()
        self.calc_flowarea_v1()
        self.calc_totalarea_v1()
        self.calc_discharges_v2()
        self.calc_discharge_v3()
        self.calc_dischargederivatives_v2()
        self.calc_dischargederivative_v2()
        self.calc_celerity_v2()
    cpdef void use_waterlevel_v1(self, double waterlevel) noexcept nogil:
        self.set_waterlevel_v1(waterlevel)
        self.calc_waterdepth_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeterderivatives_v1()
        self.calc_surfacewidths_v1()
        self.calc_surfacewidth_v1()
        self.calc_discharges_v1()
        self.calc_discharge_v2()
        self.calc_dischargederivatives_v1()
        self.calc_dischargederivative_v1()
        self.calc_celerity_v1()
    cpdef void use_waterlevel_v2(self, double waterlevel) noexcept nogil:
        self.set_waterlevel_v1(waterlevel)
        self.calc_waterdepth_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeter_v1()
    cpdef void use_waterlevel_v3(self, double waterlevel) noexcept nogil:
        self.set_waterlevel_v1(waterlevel)
        self.calc_waterdepth_v3()
        self.calc_index_excess_weight_v1()
        self.calc_flowwidths_v1()
        self.calc_totalwidths_v1()
        self.calc_totalwidth_v1()
        self.calc_flowareas_v1()
        self.calc_totalareas_v1()
        self.calc_flowperimeters_v1()
        self.calc_flowperimeterderivatives_v1()
        self.calc_flowarea_v1()
        self.calc_totalarea_v1()
        self.calc_discharges_v2()
        self.calc_discharge_v3()
        self.calc_dischargederivatives_v2()
        self.calc_dischargederivative_v2()
        self.calc_celerity_v2()
    cpdef void use_wettedarea_v1(self, double wettedarea) noexcept nogil:
        self.set_wettedarea_v1(wettedarea)
        self.calc_waterdepth_v2()
        self.calc_waterlevel_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeter_v1()
    cpdef void use_wettedarea(self, double wettedarea) noexcept nogil:
        self.set_wettedarea_v1(wettedarea)
        self.calc_waterdepth_v2()
        self.calc_waterlevel_v1()
        self.calc_wettedareas_v1()
        self.calc_wettedarea_v1()
        self.calc_wettedperimeters_v1()
        self.calc_wettedperimeter_v1()
