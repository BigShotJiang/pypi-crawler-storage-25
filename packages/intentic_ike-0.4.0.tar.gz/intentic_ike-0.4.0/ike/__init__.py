"""intentic Knowledge Engine — context-efficient knowledge serving for AI agents."""

__version__ = "0.1.0"
