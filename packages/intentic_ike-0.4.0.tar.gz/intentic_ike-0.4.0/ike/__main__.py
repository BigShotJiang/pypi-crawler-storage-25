from ike.cli import cli

cli()
