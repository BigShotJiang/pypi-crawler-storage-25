"""ike CLI — dynamic command loading from ike/commands/.

Each *_cmd.py in ike/commands/ exports a Click command as `cmd`.
Commands are auto-discovered at CLI startup.
"""

from __future__ import annotations

import importlib
from pathlib import Path

import click

from .core.engine import Engine


class DynamicGroup(click.Group):
    """Click group that auto-discovers commands from ike/commands/*_cmd.py."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._load_commands()

    def _load_commands(self) -> None:
        commands_dir = Path(__file__).parent / "commands"
        if not commands_dir.exists():
            return
        for f in sorted(commands_dir.glob("*_cmd.py")):
            name = f.stem.removesuffix("_cmd").replace("_", "-")
            try:
                mod = importlib.import_module(f"ike.commands.{f.stem}")
                if hasattr(mod, "cmd"):
                    self.add_command(mod.cmd, name)
            except Exception:
                pass  # Graceful: skip broken commands


@click.group(cls=DynamicGroup)
@click.version_option(package_name="intentic-ike")
@click.option(
    "--kb-root",
    type=click.Path(),
    default=None,
    envvar="IKE_KB_ROOT",
    help="KB root directory (default: ~/intentic-kb)",
)
@click.pass_context
def cli(ctx: click.Context, kb_root: str | None) -> None:
    """ike — intentic Knowledge Engine."""
    ctx.ensure_object(dict)
    kb = Path(kb_root).expanduser() if kb_root else None
    ctx.obj["kb_root"] = kb
    try:
        ctx.obj["engine"] = Engine(kb_root=kb)
    except Exception:
        ctx.obj["engine"] = None
