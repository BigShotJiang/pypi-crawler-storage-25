"""ike init — bootstrap ike for a repository."""

from __future__ import annotations

from pathlib import Path

from .artifacts import (
    generate_agents_md,
    generate_cursorrules,
    generate_llms_txt,
    generate_mcp_json,
)


def run_init(kb_root: Path, cwd: Path) -> dict:
    """Scan KB, generate discovery artifacts, return summary."""
    if not kb_root.exists():
        raise FileNotFoundError(f"KB root not found: {kb_root}")

    # Scan docs
    from ._utils import safe_rglob_md
    md_files = safe_rglob_md(kb_root)
    total = len(md_files)

    # Check frontmatter quality
    ready = 0
    fixable = 0
    needs_review = 0

    for f in md_files:
        content = f.read_text(encoding="utf-8")
        has_fm = content.startswith("---")
        has_headers = "\n## " in content or "\n# " in content

        if has_fm and has_headers:
            ready += 1
        elif not has_fm:
            fixable += 1
        else:
            needs_review += 1

    # Generate artifacts
    mcp_path = generate_mcp_json(cwd)
    agents_path = generate_agents_md(kb_root, cwd)

    return {
        "total": total,
        "ready": ready,
        "fixable": fixable,
        "needs_review": needs_review,
        "artifacts": [str(mcp_path), str(agents_path)],
    }
