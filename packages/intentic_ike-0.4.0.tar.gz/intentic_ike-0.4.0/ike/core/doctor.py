"""ike doctor — auto-fix missing frontmatter + cross-reference suggestions."""

from __future__ import annotations

import re
from pathlib import Path

import frontmatter

from .parser import Parser
from .linter import Linter

# Non-greedy, CRLF+BOM-tolerant regex for frontmatter
_FM_RE = re.compile(r"^(?:\ufeff)?---\r?\n(.*?)\r?\n---\r?\n(.*)", re.DOTALL)

_DOMAIN_MAP = {
    "company": "company",
    "engineering": "engineering",
    "product": "product",
    "operations": "operations",
    "content": "content",
    "conventions": "conventions",
    "decisions": "decisions",
    "founding": "founding",
    "agents": "agents",
    "templates": "templates",
}


def _infer_domain(file_path: Path, kb_root: Path) -> str:
    """Infer domain from file path relative to KB root."""
    try:
        rel = file_path.relative_to(kb_root)
        top_dir = rel.parts[0] if len(rel.parts) > 1 else ""
        return _DOMAIN_MAP.get(top_dir, "company")
    except ValueError:
        return "company"


def _infer_title(content: str) -> str:
    """Infer title from first H1 heading."""
    for line in content.split("\n"):
        clean = line.lstrip("\ufeff")
        if clean.startswith("# "):
            return clean[2:].strip()
    return ""


def _infer_summary(content: str) -> str:
    """Infer summary from first non-empty paragraph after H1."""
    lines = content.split("\n")
    past_h1 = False
    for line in lines:
        if line.startswith("# "):
            past_h1 = True
            continue
        if past_h1 and line.strip() and not line.startswith("#"):
            text = line.strip().rstrip(".")
            if len(text) > 120:
                text = text[:117] + "..."
            return text
    return ""


def _analyze_file(file_path: Path, kb_root: Path) -> dict | None:
    """Analyze a file and return proposed frontmatter fixes, or None if OK."""
    content = file_path.read_text(encoding="utf-8")
    match = _FM_RE.match(content)

    if match:
        # Has frontmatter — check for missing fields
        post = frontmatter.loads(content)
        missing = {}
        if not post.get("title"):
            title = _infer_title(post.content)
            if title:
                missing["title"] = title
        if not post.get("domain"):
            missing["domain"] = _infer_domain(file_path, kb_root)
        if not post.get("summary"):
            summary = _infer_summary(post.content)
            if summary:
                missing["summary"] = summary

        if not missing:
            return None
        return {"path": file_path, "missing": missing, "has_fm": True}
    else:
        # No frontmatter — propose full frontmatter
        title = _infer_title(content)
        domain = _infer_domain(file_path, kb_root)
        summary = _infer_summary(content)
        proposed = {}
        if title:
            proposed["title"] = title
        proposed["domain"] = domain
        if summary:
            proposed["summary"] = summary
        return {"path": file_path, "missing": proposed, "has_fm": False}


def _apply_fix(file_path: Path, fix: dict) -> None:
    """Apply frontmatter fix to a file, preserving body byte-exact."""
    content = file_path.read_text(encoding="utf-8")
    match = _FM_RE.match(content)

    if fix["has_fm"] and match:
        # Add missing fields to existing frontmatter
        yaml_block = match.group(1)
        body = match.group(2)

        new_lines = yaml_block.split("\n")
        for key, value in fix["missing"].items():
            new_lines.append(f'{key}: "{value}"')

        new_content = "---\n" + "\n".join(new_lines) + "\n---\n" + body
    else:
        # Prepend new frontmatter, body unchanged
        fm_lines = []
        for key, value in fix["missing"].items():
            fm_lines.append(f'{key}: "{value}"')
        fm_block = "\n".join(fm_lines)
        new_content = f"---\n{fm_block}\n---\n\n{content}"

    file_path.write_text(new_content, encoding="utf-8")


_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
    "has", "have", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "not", "no", "all", "any",
    "each", "every", "both", "few", "more", "most", "other", "some", "such",
    "than", "too", "very", "just", "about", "above", "after", "again",
    "also", "as", "because", "before", "between", "dass", "die", "der",
    "das", "ein", "eine", "und", "oder", "fuer", "mit", "von", "ist",
    "sind", "wird", "werden", "nicht", "auch", "nur", "wenn", "wie",
})


def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful keywords from text, filtering stopwords."""
    words = re.findall(r"\w+", text.lower())
    return {w for w in words if len(w) >= 3 and w not in _STOPWORDS}


def suggest_cross_refs(kb_root: Path) -> list[dict]:
    """Analyze KB and suggest cross-references for orphaned documents.

    Returns list of suggestions:
    [{"file": "path.md", "domain": "...", "keywords": [...],
      "suggestions": [{"target": "other.md", "reason": "...", "score": N}]}]
    """
    parser = Parser(kb_root)
    linter = Linter(parser, kb_root)
    findings = linter.lint_all()

    orphans = {f.file_path for f in findings if f.check == "orphan"}
    if not orphans:
        return []

    # Parse all docs and build metadata map
    from ._utils import safe_rglob_md
    md_files = safe_rglob_md(kb_root)

    doc_meta: dict[str, dict] = {}
    for f in md_files:
        try:
            doc = parser.parse_document(f)
            rel = str(f.relative_to(kb_root))
            title = doc.frontmatter.get("title", "")
            summary = doc.frontmatter.get("summary", "")
            domain = doc.frontmatter.get("domain", "")
            keywords = _extract_keywords(f"{title} {summary}")
            # Add section titles as keywords
            for chunk in doc.chunks:
                keywords |= _extract_keywords(chunk.section_title)
            doc_meta[rel] = {
                "domain": domain,
                "title": title,
                "summary": summary,
                "keywords": keywords,
            }
        except Exception:
            continue

    # For each orphan, find related docs by keyword overlap + domain
    results = []
    for orphan_path in sorted(orphans):
        if orphan_path not in doc_meta:
            continue

        orphan = doc_meta[orphan_path]
        scored: list[dict] = []

        for other_path, other in doc_meta.items():
            if other_path == orphan_path:
                continue

            score = 0
            reasons = []

            # Domain match
            if orphan["domain"] and orphan["domain"] == other["domain"]:
                score += 2
                reasons.append(f"same domain ({orphan['domain']})")

            # Keyword overlap
            overlap = orphan["keywords"] & other["keywords"]
            if len(overlap) >= 2:
                score += len(overlap)
                top_words = sorted(overlap)[:5]
                reasons.append(f"shared keywords: {', '.join(top_words)}")

            if score >= 3:
                scored.append({
                    "target": other_path,
                    "title": other["title"],
                    "reason": "; ".join(reasons),
                    "score": score,
                })

        scored.sort(key=lambda x: x["score"], reverse=True)

        results.append({
            "file": orphan_path,
            "domain": orphan["domain"],
            "title": orphan["title"],
            "suggestions": scored[:5],
        })

    return results


def run_doctor(kb_root: Path, auto_fix: bool = False) -> int:
    """Scan KB docs and fix missing frontmatter.

    Returns number of files fixed.
    """
    if not kb_root.exists():
        raise FileNotFoundError(f"KB root not found: {kb_root}")

    from ._utils import safe_rglob_md
    md_files = safe_rglob_md(kb_root)

    fixes = []
    for f in md_files:
        try:
            fix = _analyze_file(f, kb_root)
            if fix:
                fixes.append(fix)
        except Exception:
            continue

    if not fixes:
        return 0

    fixed = 0
    for fix in fixes:
        rel = fix["path"].relative_to(kb_root)
        fields = ", ".join(f"{k}={v!r}" for k, v in fix["missing"].items())

        if auto_fix:
            _apply_fix(fix["path"], fix)
            fixed += 1
        else:
            print(f"\n{rel}:")
            print(f"  Proposed: {fields}")
            try:
                choice = input("  Apply? [y/s/e] (yes/skip/edit): ").strip().lower()
            except EOFError:
                choice = "s"
            if choice in ("y", "yes"):
                _apply_fix(fix["path"], fix)
                fixed += 1

    return fixed
