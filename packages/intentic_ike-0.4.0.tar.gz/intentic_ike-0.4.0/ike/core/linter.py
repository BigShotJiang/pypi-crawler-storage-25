"""Linter — live-parse + consistency checks.

Checks: orphans, missing frontmatter, headerless docs, stale docs, broken cross-refs.
Cross-refs include both standard Markdown links and Obsidian wikilinks.
"""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

from .parser import Parser
from .types import LintFinding


class Linter:
    def __init__(self, parser: Parser, kb_root: Path) -> None:
        self._parser = parser
        self._kb_root = kb_root

    def lint_all(self) -> list[LintFinding]:
        """Run all checks: orphans, missing_frontmatter, headerless, broken_ref."""
        findings: list[LintFinding] = []
        docs = self._collect_docs()

        # Build incoming reference map
        all_targets: set[str] = set()
        all_refs: dict[str, list] = {}  # file -> cross_refs

        for md_file in docs:
            doc = self._parser.parse_document(md_file)
            rel = self._rel(md_file)
            all_refs[rel] = doc.cross_refs

            # Check missing frontmatter
            if not doc.has_frontmatter:
                findings.append(LintFinding(
                    file_path=rel,
                    severity="warning",
                    check="missing_frontmatter",
                    message="File has no YAML frontmatter",
                ))
            else:
                for field in ("title", "domain", "summary"):
                    if field not in doc.frontmatter:
                        findings.append(LintFinding(
                            file_path=rel,
                            severity="warning",
                            check="missing_frontmatter",
                            message=f"Missing frontmatter field: {field}",
                        ))

            # Check headerless docs
            if not doc.chunks or (len(doc.chunks) == 1 and doc.chunks[0].section_id == "root"):
                findings.append(LintFinding(
                    file_path=rel,
                    severity="warning",
                    check="headerless",
                    message="Document has no Markdown headers — chunking falls back to single chunk",
                ))

        # Collect all files referenced by cross-refs
        all_files = {self._rel(f) for f in docs}

        for source_file, refs in all_refs.items():
            for ref in refs:
                target = ref.target_path
                # Resolve relative paths
                if ref.link_type == "markdown" and not target.startswith("/"):
                    source_dir = str(Path(source_file).parent)
                    resolved = str(Path(source_dir) / target)
                    # Normalize
                    resolved = str(Path(resolved))
                else:
                    # Wikilinks: try to find by filename
                    resolved = None
                    target_name = target + ".md" if not target.endswith(".md") else target
                    for f in all_files:
                        if f.endswith(target_name) or Path(f).stem == target:
                            resolved = f
                            break

                if resolved is not None:
                    all_targets.add(resolved)

                    # Check if target exists
                    if resolved not in all_files:
                        findings.append(LintFinding(
                            file_path=source_file,
                            severity="warning",
                            check="broken_ref",
                            message=f"Broken cross-ref to '{ref.target_path}' (resolved: {resolved})",
                        ))

        # Orphan detection: files with no incoming references
        for rel_file in all_files:
            if rel_file not in all_targets:
                # Skip README and root-level index files
                name = Path(rel_file).name.lower()
                if name in ("readme.md", "index.md", "constitution.md"):
                    continue
                findings.append(LintFinding(
                    file_path=rel_file,
                    severity="warning",
                    check="orphan",
                    message="No incoming cross-references found",
                ))

        return findings

    def lint_freshness(self, max_days: int = 30) -> list[LintFinding]:
        """Find docs with last-updated older than max_days."""
        findings: list[LintFinding] = []
        cutoff = date.today() - timedelta(days=max_days)

        for md_file in self._collect_docs():
            doc = self._parser.parse_document(md_file)
            if not doc.has_frontmatter:
                continue

            last_updated = doc.frontmatter.get("last-updated", "")
            if not last_updated:
                findings.append(LintFinding(
                    file_path=self._rel(md_file),
                    severity="warning",
                    check="stale",
                    message="No last-updated field in frontmatter",
                ))
                continue

            try:
                updated_date = date.fromisoformat(str(last_updated))
                if updated_date < cutoff:
                    days_old = (date.today() - updated_date).days
                    findings.append(LintFinding(
                        file_path=self._rel(md_file),
                        severity="warning",
                        check="stale",
                        message=f"Last updated {days_old} days ago ({last_updated})",
                    ))
            except (ValueError, TypeError):
                findings.append(LintFinding(
                    file_path=self._rel(md_file),
                    severity="warning",
                    check="stale",
                    message=f"Invalid last-updated format: '{last_updated}'",
                ))

        return findings

    # ── Private ─────────────────────────────────────────────────

    def _collect_docs(self) -> list[Path]:
        """Collect all .md files, skip dotfiles and symlinks."""
        from ._utils import safe_rglob_md
        return safe_rglob_md(self._kb_root)

    def _rel(self, file_path: Path) -> str:
        try:
            return str(file_path.relative_to(self._kb_root))
        except ValueError:
            return str(file_path)
