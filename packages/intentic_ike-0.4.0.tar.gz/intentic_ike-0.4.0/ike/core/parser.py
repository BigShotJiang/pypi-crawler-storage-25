"""Central parser module — Single Source of Truth for all Markdown parsing.

Uses markdown-it-py ONLY for source-mapping (Token.map → line numbers).
All mutations (replace, append, frontmatter update) via string/list slicing.
"""

from __future__ import annotations

import re
from datetime import date
from pathlib import Path

import frontmatter
import tiktoken
from markdown_it import MarkdownIt

from .types import Chunk, CrossRef, ParsedDocument


class Parser:
    def __init__(self, kb_root: Path) -> None:
        self.kb_root = kb_root
        self._md = MarkdownIt()
        self._enc = tiktoken.get_encoding("cl100k_base")

    # ── Public API ──────────────────────────────────────────────

    def parse_document(self, file_path: Path) -> ParsedDocument:
        raw_text = file_path.read_text(encoding="utf-8")
        raw_text = self._normalize_crlf(raw_text)

        fm_dict, has_fm, fm_raw, body = self._split_frontmatter(raw_text)

        rel_path = self._relative_path(file_path)
        knowledge_type = self._derive_knowledge_type(fm_dict, rel_path)

        chunks = self._extract_chunks(body, rel_path, knowledge_type)
        cross_refs = self.extract_cross_refs(body)

        return ParsedDocument(
            file_path=file_path,
            frontmatter=fm_dict,
            has_frontmatter=has_fm,
            frontmatter_raw=fm_raw,
            body=body,
            chunks=chunks,
            cross_refs=cross_refs,
            raw_text=raw_text,
        )

    def get_chunks(self, file_path: Path) -> list[Chunk]:
        return self.parse_document(file_path).chunks

    def get_section(self, file_path: Path, section_id: str) -> Chunk | None:
        for chunk in self.get_chunks(file_path):
            if chunk.section_id == section_id:
                return chunk
        return None

    def replace_section(
        self, raw_text: str, section_id: str, new_content: str
    ) -> str | None:
        raw_text = self._normalize_crlf(raw_text)
        _fm_dict, has_fm, fm_raw, body = self._split_frontmatter(raw_text)

        body_lines = body.split("\n")
        headers = self._parse_headers(body)

        target = None
        for h in headers:
            if self._match_section_id(h, headers) == section_id:
                target = h
                break

        if target is None:
            return None

        start_line = target["line"]
        end_line = self._find_section_end(target, headers, len(body_lines))

        new_lines = new_content.split("\n")
        modified_lines = body_lines[:start_line] + new_lines + body_lines[end_line:]
        modified_body = "\n".join(modified_lines)

        if has_fm:
            return fm_raw + "\n" + modified_body
        return modified_body

    def append_content(self, raw_text: str, new_content: str) -> str:
        raw_text = self._normalize_crlf(raw_text)
        return raw_text.rstrip("\n") + "\n\n" + new_content + "\n"

    def update_frontmatter_date(self, raw_text: str) -> str:
        raw_text = self._normalize_crlf(raw_text)

        if not raw_text.startswith("---\n"):
            return raw_text

        end_idx = raw_text.index("\n---\n", 4) + 5 if "\n---\n" in raw_text[4:] else -1
        if end_idx == -1:
            return raw_text

        fm_block = raw_text[:end_idx]
        rest = raw_text[end_idx:]

        today = date.today().isoformat()
        pattern = re.compile(r"(?m)^last-updated:\s*.*$")
        if not pattern.search(fm_block):
            return raw_text

        updated_fm = pattern.sub(f'last-updated: "{today}"', fm_block)
        return updated_fm + rest

    def generate_section_id(
        self,
        header_text: str,
        level: int,
        parent_id: str | None,
        occurrence: int,
    ) -> str:
        slug = self._slugify(header_text)
        if parent_id:
            slug = f"{parent_id}--{slug}"
        if occurrence > 1:
            slug = f"{slug}-{occurrence}"
        return slug

    def extract_cross_refs(self, content: str) -> list[CrossRef]:
        refs: list[CrossRef] = []

        # Standard Markdown links to .md files
        for match in re.finditer(r"\[([^\]]*)\]\(([^)]+\.md[^)]*)\)", content):
            target = match.group(2)
            section = None
            if "#" in target:
                target, section = target.rsplit("#", 1)
            refs.append(CrossRef(target_path=target, section=section, link_type="markdown"))

        # Obsidian wikilinks
        for match in re.finditer(r"\[\[([^\]]+)\]\]", content):
            inner = match.group(1)
            section = None
            if "#" in inner:
                target, section = inner.split("#", 1)
            else:
                target = inner
            refs.append(CrossRef(target_path=target, section=section, link_type="wikilink"))

        return refs

    def count_tokens(self, text: str) -> int:
        return len(self._enc.encode(text))

    # ── Private helpers ─────────────────────────────────────────

    @staticmethod
    def _normalize_crlf(text: str) -> str:
        return text.replace("\r\n", "\n")

    def _split_frontmatter(
        self, raw_text: str
    ) -> tuple[dict, bool, str, str]:
        if not raw_text.startswith("---\n"):
            return {}, False, "", raw_text

        try:
            post = frontmatter.loads(raw_text)
        except Exception:
            return {}, False, "", raw_text

        # Reconstruct frontmatter_raw from raw_text
        # Find the closing --- (handle EOF without trailing newline)
        try:
            second_sep = raw_text.index("\n---\n", 4)
            fm_raw = raw_text[: second_sep + 5].rstrip("\n")  # include closing ---
            body = raw_text[second_sep + 5:]
        except ValueError:
            # Closing --- at EOF without trailing newline (e.g., "---\nkey: val\n---")
            if raw_text.rstrip("\n").endswith("\n---"):
                sep_pos = raw_text.rstrip("\n").rindex("\n---")
                fm_raw = raw_text[: sep_pos + 4].rstrip("\n")
                body = ""
            else:
                return {}, False, "", raw_text
        if body.startswith("\n"):
            body = body[1:]

        return dict(post.metadata), True, fm_raw, body

    def _relative_path(self, file_path: Path) -> str:
        try:
            return str(file_path.relative_to(self.kb_root))
        except ValueError:
            return str(file_path)

    def _derive_knowledge_type(self, fm: dict, rel_path: str) -> str:
        domain = fm.get("domain", "")
        if domain == "company" or "CONSTITUTION" in rel_path:
            return "canonical"
        if domain == "engineering" or "decisions/" in rel_path:
            return "architectural"
        if domain in ("content", "operations"):
            return "procedural"
        if domain == "product":
            return "strategic"
        return "canonical"

    def _parse_headers(self, body: str) -> list[dict]:
        tokens = self._md.parse(body)
        headers = []
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token.type == "heading_open" and token.map:
                level = int(token.tag[1])  # h1 → 1, h2 → 2, etc.
                # Next token is inline with the header text
                inline_token = tokens[i + 1] if i + 1 < len(tokens) else None
                text = inline_token.content if inline_token else ""
                headers.append({
                    "level": level,
                    "text": text,
                    "line": token.map[0],  # 0-based line in body
                    "tag": token.tag,
                })
            i += 1
        return headers

    def _match_section_id(self, header: dict, all_headers: list[dict]) -> str:
        # Find parent (nearest preceding header with lower level)
        # H1 is document title, never a parent. Only H2+ participate in hierarchy.
        # H3/H4 get parent from their enclosing H2.
        parent_id = None
        if header["level"] >= 3:
            for prev in reversed(all_headers):
                if prev is header:
                    continue
                if prev["line"] < header["line"] and prev["level"] < header["level"] and prev["level"] >= 2:
                    parent_id = self._match_section_id(prev, all_headers)
                    break

        # Count occurrence (same text + level + parent)
        occurrence = 1
        for other in all_headers:
            if other is header:
                break
            if (
                other["text"] == header["text"]
                and other["level"] == header["level"]
            ):
                occurrence += 1

        return self.generate_section_id(
            header["text"], header["level"], parent_id, occurrence
        )

    def _find_section_end(
        self, target: dict, all_headers: list[dict], total_lines: int
    ) -> int:
        found = False
        for h in all_headers:
            if h is target:
                found = True
                continue
            if found and h["level"] <= target["level"]:
                return h["line"]
        return total_lines

    def _extract_chunks(
        self, body: str, rel_path: str, knowledge_type: str
    ) -> list[Chunk]:
        body_lines = body.split("\n")
        headers = self._parse_headers(body)

        if not headers:
            # No headers: entire body is one chunk
            content = body.strip()
            if not content:
                return []
            return [
                Chunk(
                    file_path=rel_path,
                    section_id="root",
                    section_title="",
                    content=content,
                    token_count=self.count_tokens(content),
                    knowledge_type=knowledge_type,
                )
            ]

        chunks: list[Chunk] = []
        for i, header in enumerate(headers):
            section_id = self._match_section_id(header, headers)
            start = header["line"]
            end = self._find_section_end(header, headers, len(body_lines))
            content = "\n".join(body_lines[start:end]).strip()

            chunks.append(
                Chunk(
                    file_path=rel_path,
                    section_id=section_id,
                    section_title=header["text"],
                    content=content,
                    token_count=self.count_tokens(content),
                    knowledge_type=knowledge_type,
                )
            )

        return chunks

    @staticmethod
    def _slugify(text: str) -> str:
        text = text.strip().lower()
        text = re.sub(r"[^\w\s-]", "", text)
        text = re.sub(r"[\s_]+", "-", text)
        text = re.sub(r"-+", "-", text)
        text = text.strip("-")
        return text
