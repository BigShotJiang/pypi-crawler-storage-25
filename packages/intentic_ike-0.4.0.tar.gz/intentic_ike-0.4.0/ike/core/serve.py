"""ike serve — start the MCP server."""

from __future__ import annotations

import logging
import sys


def run_serve() -> None:
    """Start the ike MCP server.

    - Lazy-imports fastmcp to keep it optional
    - Configures logging to stderr (stdout reserved for JSON-RPC)
    - Never uses print() or click.echo()
    """
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    try:
        from ike.mcp_server import mcp  # noqa: lazy import
    except ImportError:
        logging.error(
            "MCP dependencies not installed. Run: pip install intentic-ike[mcp]"
        )
        sys.exit(1)

    logger = logging.getLogger("ike.serve")
    logger.info("Starting ike MCP server...")
    mcp.run()
