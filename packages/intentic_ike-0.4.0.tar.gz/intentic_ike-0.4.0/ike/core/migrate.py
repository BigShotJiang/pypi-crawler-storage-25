"""ike migrate-mcp — migrate .mcp.json from absolute paths to portable pattern."""

from __future__ import annotations

import json
from pathlib import Path

from .artifacts import _detect_runner


def run_migrate_mcp(cwd: Path, dry_run: bool = False) -> dict:
    """Migrate .mcp.json ike entry from absolute paths to uvx/pipx pattern.

    Returns dict with old/new config and whether changes were made.
    """
    mcp_path = cwd / ".mcp.json"
    if not mcp_path.exists():
        return {"changed": False, "reason": "no .mcp.json found"}

    data = json.loads(mcp_path.read_text(encoding="utf-8"))
    servers = data.get("mcpServers", {})
    ike_config = servers.get("ike")

    if not ike_config:
        return {"changed": False, "reason": "no ike entry in .mcp.json"}

    old_cmd = ike_config.get("command", "")
    # Check if it's already portable (no absolute path)
    if not old_cmd.startswith("/") and old_cmd not in ("bash",):
        return {"changed": False, "reason": "already portable", "command": old_cmd}

    runner_cmd, runner_args = _detect_runner()
    old_config = dict(ike_config)
    new_config = {"command": runner_cmd, "args": runner_args}

    # Preserve env vars if present
    if "env" in ike_config:
        new_config["env"] = ike_config["env"]

    if dry_run:
        return {
            "changed": True,
            "dry_run": True,
            "old": old_config,
            "new": new_config,
        }

    data["mcpServers"]["ike"] = new_config
    mcp_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return {"changed": True, "old": old_config, "new": new_config}
