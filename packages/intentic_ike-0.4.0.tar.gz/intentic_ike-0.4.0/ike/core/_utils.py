"""Shared utilities for ike core modules."""

from __future__ import annotations

from pathlib import Path


def safe_rglob_md(root: Path) -> list[Path]:
    """Collect .md files under root, skipping dotfiles and symlinks.

    Rejects:
    - Files whose path contains a dotfile component (e.g., .git/)
    - Files that are symlinks
    - Files whose resolved path escapes root
    """
    root_resolved = root.resolve()
    results: list[Path] = []
    for f in sorted(root.rglob("*.md")):
        # Skip dotfile components
        try:
            rel_parts = f.relative_to(root).parts
        except ValueError:
            continue
        if any(part.startswith(".") for part in rel_parts):
            continue
        # Skip symlinks
        if f.is_symlink():
            continue
        # Verify resolved path stays within root
        try:
            f.resolve().relative_to(root_resolved)
        except ValueError:
            continue
        results.append(f)
    return results
