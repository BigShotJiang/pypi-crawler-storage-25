"""Writer — live-parse + file writes + Git commits.

Direct file writes with 2-level locking:
1. File-level lock (filelock) protects the .md file
2. Git-level lock serializes git add + git commit

Content is always received as a string (CLI reads from stdin).
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from filelock import FileLock

from .parser import Parser
from .types import WriteResult


class Writer:
    def __init__(
        self,
        parser: Parser,
        kb_root: Path,
        locks_dir: Path | None = None,
    ) -> None:
        self._parser = parser
        self._kb_root = kb_root
        if locks_dir is None:
            locks_dir = Path.home() / ".ike" / "locks"
        self._locks_dir = locks_dir
        self._locks_dir.mkdir(parents=True, exist_ok=True)

    def write(
        self,
        file_path: Path,
        content: str,
        mode: str,
        section_id: str | None = None,
        agent_id: str = "unknown",
        auto_commit: bool = True,
    ) -> WriteResult:
        """Write content to a KB file.

        mode='append': add content at end
        mode='replace': replace section identified by section_id

        Workflow:
        1. Acquire file-lock
        2. Read + parse
        3. Check readonly
        4. Modify via parser (line-slicing, not AST)
        5. Update frontmatter date (scoped regex)
        6. Write file
        7. Release file-lock
        8. Git commit (if auto_commit, under git-lock)
        """
        try:
            rel = str(file_path.relative_to(self._kb_root))
        except ValueError:
            rel = file_path.name
        lock_name = rel.replace("/", "_").replace("\\", "_") + ".lock"
        file_lock = FileLock(self._locks_dir / lock_name, timeout=10)

        try:
            with file_lock:
                raw_text = file_path.read_text(encoding="utf-8")

                # Readonly check
                doc = self._parser.parse_document(file_path)
                if doc.frontmatter.get("readonly") is True:
                    return WriteResult(
                        file_path=str(file_path),
                        mode=mode,
                        section_id=section_id,
                        success=False,
                        error="File is readonly",
                        committed=False,
                    )

                # Modify
                if mode == "append":
                    modified = self._parser.append_content(raw_text, content)
                elif mode == "replace":
                    if section_id is None:
                        return WriteResult(
                            file_path=str(file_path),
                            mode=mode,
                            section_id=section_id,
                            success=False,
                            error="section_id required for replace mode",
                            committed=False,
                        )
                    modified = self._parser.replace_section(raw_text, section_id, content)
                    if modified is None:
                        return WriteResult(
                            file_path=str(file_path),
                            mode=mode,
                            section_id=section_id,
                            success=False,
                            error=f"Section '{section_id}' not found",
                            committed=False,
                        )
                else:
                    return WriteResult(
                        file_path=str(file_path),
                        mode=mode,
                        section_id=section_id,
                        success=False,
                        error=f"Unknown mode '{mode}'. Use 'append' or 'replace'",
                        committed=False,
                    )

                # Update frontmatter date
                modified = self._parser.update_frontmatter_date(modified)

                # Write
                file_path.write_text(modified, encoding="utf-8")

        except Exception as exc:
            return WriteResult(
                file_path=str(file_path),
                mode=mode,
                section_id=section_id,
                success=False,
                error=str(exc),
                committed=False,
            )

        # Git commit (outside file-lock, under git-lock)
        committed = False
        if auto_commit:
            committed = self._git_commit(file_path, agent_id)

        return WriteResult(
            file_path=str(file_path),
            mode=mode,
            section_id=section_id,
            success=True,
            error=None,
            committed=committed,
        )

    def flag_stale(
        self, file_path: Path, section_id: str, reason: str
    ) -> WriteResult:
        """Mark a section as stale by appending a notice after the header.

        Parses inside the file lock to avoid TOCTOU race conditions.
        """
        try:
            rel = str(file_path.relative_to(self._kb_root))
        except ValueError:
            rel = file_path.name
        lock_name = rel.replace("/", "_").replace("\\", "_") + ".lock"
        file_lock = FileLock(self._locks_dir / lock_name, timeout=10)

        with file_lock:
            doc = self._parser.parse_document(file_path)

            chunk = None
            for c in doc.chunks:
                if c.section_id == section_id:
                    chunk = c
                    break

            if chunk is None:
                return WriteResult(
                    file_path=str(file_path),
                    mode="flag-stale",
                    section_id=section_id,
                    success=False,
                    error=f"Section '{section_id}' not found",
                    committed=False,
                )

            stale_notice = f"\n> **STALE:** {reason}\n"
            new_content = chunk.content.split("\n", 1)
            if len(new_content) > 1:
                replaced = new_content[0] + stale_notice + new_content[1]
            else:
                replaced = new_content[0] + stale_notice

        return self.write(
            file_path, replaced, "replace", section_id, agent_id="stale-flag"
        )

    @staticmethod
    def _sanitize_agent_id(agent_id: str) -> str:
        """Strip newlines and non-printable chars from agent_id."""
        return re.sub(r"[\x00-\x1f\x7f]", "", agent_id)[:64]

    def _git_commit(self, file_path: Path, agent_id: str) -> bool:
        """Git add + commit under git-lock. Returns True if committed."""
        agent_id = self._sanitize_agent_id(agent_id)
        git_lock = FileLock(self._locks_dir / "git.lock", timeout=10)

        try:
            with git_lock:
                status = subprocess.run(
                    ["git", "status", "--porcelain", "--", str(file_path)],
                    cwd=self._kb_root,
                    capture_output=True,
                    text=True,
                )
                if not status.stdout.strip():
                    return False

                subprocess.run(
                    ["git", "add", "--", str(file_path)],
                    cwd=self._kb_root,
                    check=True,
                    capture_output=True,
                )
                subprocess.run(
                    [
                        "git", "commit",
                        "-m", f"ike({agent_id}): update {file_path.name}",
                        "--", str(file_path),
                    ],
                    cwd=self._kb_root,
                    check=True,
                    capture_output=True,
                )
                return True
        except Exception:
            return False
