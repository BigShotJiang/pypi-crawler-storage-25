"""FROZEN dataclasses — the contract for all ike modules.

DO NOT MODIFY these dataclass fields without updating ALL consumers
(parser, index, fetcher, writer, linter, engine, cli, mcp_server).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Chunk:
    file_path: str
    section_id: str
    section_title: str
    content: str
    token_count: int
    knowledge_type: str


@dataclass(frozen=True)
class ChunkRef:
    file_path: str
    section_id: str
    score: float
    token_count: int


@dataclass(frozen=True)
class CrossRef:
    target_path: str
    section: str | None
    link_type: str  # "markdown" | "wikilink"


@dataclass
class ParsedDocument:
    file_path: Path
    frontmatter: dict
    has_frontmatter: bool
    frontmatter_raw: str
    body: str
    chunks: list[Chunk]
    cross_refs: list[CrossRef]
    raw_text: str


@dataclass(frozen=True)
class RouteResult:
    query: str
    chunks: list[ChunkRef]
    total_tokens: int
    tier_used: str


@dataclass(frozen=True)
class FetchResult:
    file_path: str
    section_id: str | None
    content: str
    token_count: int
    metadata: dict


@dataclass(frozen=True)
class LintFinding:
    file_path: str
    severity: str
    check: str
    message: str


@dataclass(frozen=True)
class WriteResult:
    file_path: str
    mode: str
    section_id: str | None
    success: bool
    error: str | None
    committed: bool
