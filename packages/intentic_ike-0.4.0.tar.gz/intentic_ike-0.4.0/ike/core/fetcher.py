"""Fetcher — live-parse + section-level reads.

Always parses the current file via parser.parse_document().
Never uses cached line positions from the index.
"""

from __future__ import annotations

from pathlib import Path

from .parser import Parser
from .types import FetchResult


class Fetcher:
    def __init__(self, parser: Parser) -> None:
        self._parser = parser

    def fetch(
        self, file_path: Path, section_id: str | None = None
    ) -> FetchResult:
        """Load content from a file. Live-parse, never cached.

        section_id=None → entire body (without frontmatter).
        section_id given → only that chunk's content.
        """
        doc = self._parser.parse_document(file_path)

        if section_id is None:
            content = doc.body.strip()
            return FetchResult(
                file_path=str(file_path),
                section_id=None,
                content=content,
                token_count=self._parser.count_tokens(content),
                metadata=doc.frontmatter,
            )

        for chunk in doc.chunks:
            if chunk.section_id == section_id:
                return FetchResult(
                    file_path=str(file_path),
                    section_id=section_id,
                    content=chunk.content,
                    token_count=chunk.token_count,
                    metadata=doc.frontmatter,
                )

        raise KeyError(f"Section '{section_id}' not found in {file_path}")

    def fetch_metadata(self, file_path: Path) -> dict:
        """Return only frontmatter, no content."""
        doc = self._parser.parse_document(file_path)
        return doc.frontmatter
