"""Generate discovery artifacts for AI tools (.mcp.json, AGENTS.md, etc.)."""

from __future__ import annotations

import json
import shutil
from pathlib import Path


def _detect_runner() -> tuple[str, list[str]]:
    """Detect best available runner: uvx > pipx > python3 -m."""
    if shutil.which("uvx"):
        return "uvx", ["--from", "intentic-ike[mcp]", "ike", "serve"]
    if shutil.which("pipx"):
        return "pipx", ["run", "intentic-ike[mcp]", "serve"]
    return "ike", ["serve"]


def generate_mcp_json(target: Path) -> Path:
    """Generate or merge ike entry into .mcp.json."""
    mcp_path = target / ".mcp.json"
    runner_cmd, runner_args = _detect_runner()

    ike_entry = {
        "command": runner_cmd,
        "args": runner_args,
    }

    if mcp_path.exists():
        data = json.loads(mcp_path.read_text(encoding="utf-8"))
    else:
        data = {}

    data.setdefault("mcpServers", {})
    data["mcpServers"]["ike"] = ike_entry

    mcp_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return mcp_path


def generate_agents_md(kb_root: Path, target: Path) -> Path:
    """Generate AGENTS.md for AI tool discovery."""
    agents_path = target / "AGENTS.md"
    kb_name = kb_root.name

    content = f"""# ike — intentic Knowledge Engine

This repository uses **ike** to make its knowledge base queryable by AI tools.
ike indexes the `{kb_name}/` directory and serves content via 2-step retrieval.

## How to query (CLI)

**IMPORTANT:** `ike route` returns file paths relative to the KB root. Use those
EXACT paths with `ike fetch` — do NOT prepend the KB directory name.

```bash
# Step 1: Find relevant sections
ike route "your question"
# Returns: {{"file_path": "architecture/auth.md", "section_id": "rate-limiting", ...}}

# Step 2: Fetch using the EXACT file_path from route results
ike fetch architecture/auth.md --section rate-limiting

# Or combine both steps:
ike query "your question" --depth deep
```

### All CLI commands

| Command | Purpose |
|---------|---------|
| `ike route "query"` | Find relevant sections (returns paths + token counts) |
| `ike fetch <path>` | Load entire file (path from route results) |
| `ike fetch <path> --section <id>` | Load specific section |
| `ike query "text" --depth deep` | Route + fetch combined |
| `ike lint` | Check KB consistency |
| `ike list` | List all indexed sections with paths |

## How to query (MCP)

For MCP-capable tools (Claude Code, Cursor, Windsurf, Zed), the server is
configured in `.mcp.json`. Available tools:

| Tool | Description |
|------|-------------|
| `route(query, limit)` | Find relevant sections (~100 tokens) |
| `fetch(file_path, section_id)` | Load content (use paths from route) |
| `query(query_text, depth)` | Route + fetch in one step |
| `lint(freshness_days)` | Check KB health |

## Example workflow

```bash
$ ike route "authentication"
  architecture/auth.md#api-keys           (score: 3, 120 tokens)
  architecture/auth.md#oauth2-flow        (score: 2, 150 tokens)
  architecture/auth.md#rate-limiting      (score: 1, 80 tokens)

$ ike fetch architecture/auth.md --section rate-limiting
## Rate Limiting
| Tier | Requests/min | Burst |
...
```

## Knowledge Base

- **Root:** `{kb_name}/`
- **Paths:** All file_paths in ike are relative to this root
- **Format:** Markdown with YAML frontmatter (title, domain, summary)
"""
    agents_path.write_text(content, encoding="utf-8")
    return agents_path


def generate_cursorrules(target: Path) -> Path:
    """Generate or append ike snippet to .cursorrules."""
    rules_path = target / ".cursorrules"

    snippet = """
# ike Knowledge Engine
# Use `ike route "query"` to find relevant KB sections, then `ike fetch <path>` to load content.
# MCP tools are also available if configured in .mcp.json.
"""

    if rules_path.exists():
        existing = rules_path.read_text(encoding="utf-8")
        if "ike" not in existing:
            rules_path.write_text(existing.rstrip() + "\n" + snippet, encoding="utf-8")
    else:
        rules_path.write_text(snippet.lstrip(), encoding="utf-8")
    return rules_path


def generate_llms_txt(kb_root: Path, target: Path) -> Path:
    """Generate llms.txt listing KB structure."""
    llms_path = target / "llms.txt"
    lines = [f"# {kb_root.name} Knowledge Base", "", "## Documents", ""]

    from ._utils import safe_rglob_md

    for md in safe_rglob_md(kb_root):
        rel = md.relative_to(kb_root)
        lines.append(f"- {rel}")

    llms_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return llms_path
