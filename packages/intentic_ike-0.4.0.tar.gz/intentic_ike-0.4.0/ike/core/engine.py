"""Engine — Facade orchestrating all core modules.

CLI and MCP delegate exclusively to Engine methods.
Handles wiring of Parser, Index, Fetcher, Writer, Linter.
"""

from __future__ import annotations

import re
from pathlib import Path

from .fetcher import Fetcher
from .index import Index
from .linter import Linter
from .parser import Parser
from .types import (
    ChunkRef,
    FetchResult,
    LintFinding,
    RouteResult,
    WriteResult,
)
from .writer import Writer


class Engine:
    def __init__(
        self,
        kb_root: Path | None = None,
        ike_dir: Path | None = None,
    ) -> None:
        if kb_root is None:
            kb_root = Path.home() / "intentic-kb"
        if ike_dir is None:
            ike_dir = Path.home() / ".ike"

        self.kb_root = kb_root
        self.parser = Parser(kb_root)
        self.index = Index(kb_root, ike_dir / "index.db")
        self.fetcher = Fetcher(self.parser)
        self.writer = Writer(self.parser, kb_root, ike_dir / "locks")
        self.linter = Linter(self.parser, kb_root)

    def route(
        self,
        query: str,
        limit: int = 10,
        knowledge_type: str | None = None,
    ) -> RouteResult:
        """Route a query to relevant KB sections.

        Ensures index freshness, tokenizes query, returns ranked ChunkRefs.
        """
        self.index.ensure_fresh(self.parser)
        keywords = self._tokenize_query(query)
        chunks = self.index.query(keywords, knowledge_type, limit)
        total_tokens = sum(c.token_count for c in chunks)

        return RouteResult(
            query=query,
            chunks=chunks,
            total_tokens=total_tokens,
            tier_used="t2",
        )

    def fetch(
        self, file_path: str, section_id: str | None = None
    ) -> FetchResult:
        """Fetch content from a KB file. Always live-parse."""
        path = self._resolve_path(file_path)
        return self.fetcher.fetch(path, section_id)

    def query_and_fetch(
        self,
        query: str,
        depth: str = "shallow",
        limit: int = 5,
    ) -> list[FetchResult]:
        """Route + fetch in one step.

        shallow: fetch only top-1 result
        deep: fetch top-N results
        """
        route_result = self.route(query, limit)
        n = 1 if depth == "shallow" else limit
        results = []
        for chunk_ref in route_result.chunks[:n]:
            try:
                result = self.fetch(chunk_ref.file_path, chunk_ref.section_id)
                results.append(result)
            except (KeyError, FileNotFoundError):
                continue
        return results

    def write(
        self,
        file_path: str,
        content: str,
        mode: str,
        section_id: str | None = None,
        agent_id: str = "unknown",
        auto_commit: bool = True,
    ) -> WriteResult:
        """Write + index update in one step."""
        path = self._resolve_path(file_path)
        result = self.writer.write(
            path, content, mode, section_id, agent_id, auto_commit
        )
        if result.success:
            self.index.update_file(path, self.parser)
        return result

    def flag_stale(
        self,
        file_path: str,
        section_id: str,
        reason: str,
    ) -> WriteResult:
        """Flag a section as stale."""
        path = self._resolve_path(file_path)
        return self.writer.flag_stale(path, section_id, reason)

    def lint(self, freshness: int | None = None) -> list[LintFinding]:
        """Run lint checks. Optionally include freshness check."""
        self.index.ensure_fresh(self.parser)
        findings = self.linter.lint_all()
        if freshness is not None:
            findings += self.linter.lint_freshness(freshness)
        return findings

    def rebuild_index(self) -> int:
        """Full index rebuild."""
        return self.index.rebuild(self.parser)

    def list_docs(
        self, knowledge_type: str | None = None, limit: int = 999
    ) -> list[ChunkRef]:
        """List all indexed chunks."""
        self.index.ensure_fresh(self.parser)
        return self.index.query([], knowledge_type, limit)

    # ── Private ─────────────────────────────────────────────────

    def _resolve_path(self, file_path: str) -> Path:
        """Resolve file_path relative to kb_root, enforcing containment.

        Raises PermissionError if the resolved path escapes kb_root.
        Rejects symlinks that point outside kb_root.
        """
        candidate = Path(file_path)
        if not candidate.is_absolute():
            candidate = self.kb_root / candidate
        resolved = candidate.resolve()
        kb_resolved = self.kb_root.resolve()
        try:
            resolved.relative_to(kb_resolved)
        except ValueError:
            raise PermissionError(
                f"Path escapes kb_root: {file_path!r}"
            )
        if resolved.is_symlink():
            link_target = resolved.resolve()
            try:
                link_target.relative_to(kb_resolved)
            except ValueError:
                raise PermissionError(
                    f"Symlink escapes kb_root: {file_path!r}"
                )
        return resolved

    @staticmethod
    def _tokenize_query(query: str, max_keywords: int = 20) -> list[str]:
        """Split query into keywords for SQL LIKE matching.

        Caps at max_keywords to prevent quadratic SQL growth (DoS).
        """
        words = re.findall(r"\w+", query.lower())
        filtered = [w for w in words if len(w) >= 2]
        return filtered[:max_keywords]
