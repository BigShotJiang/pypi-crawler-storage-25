"""Flag a section as stale."""

from __future__ import annotations

import click


@click.command("flag-stale")
@click.argument("file_path")
@click.option("--section", required=True, help="Section ID to flag")
@click.option("--reason", required=True, help="Why the section is stale")
@click.pass_context
def cmd(ctx: click.Context, file_path: str, section: str, reason: str) -> None:
    """Flag a section as stale."""
    result = ctx.obj["engine"].flag_stale(file_path, section, reason)
    if not result.success:
        click.echo(f"Error: {result.error}", err=True)
        raise SystemExit(1)
    click.echo(f"Flagged {file_path}#{section} as stale: {reason}")
