"""Route + fetch in one step."""

from __future__ import annotations

import click


@click.command()
@click.argument("query_text")
@click.option("--depth", type=click.Choice(["shallow", "deep"]), default="shallow")
@click.option("--limit", default=5)
@click.pass_context
def cmd(ctx: click.Context, query_text: str, depth: str, limit: int) -> None:
    """Route + fetch in one step."""
    results = ctx.obj["engine"].query_and_fetch(query_text, depth, limit)
    for r in results:
        section_label = f"#{r.section_id}" if r.section_id else ""
        click.echo(f"--- {r.file_path}{section_label} ({r.token_count} tokens) ---")
        click.echo(r.content)
        click.echo()
