"""ike init — bootstrap ike for a repository."""

from __future__ import annotations

from pathlib import Path

import click


@click.command()
@click.option(
    "--kb-root",
    type=click.Path(exists=True),
    required=True,
    help="Path to the knowledge base directory",
)
@click.pass_context
def cmd(ctx: click.Context, kb_root: str) -> None:
    """Bootstrap ike for a repository. Scans docs and generates discovery artifacts."""
    from ike.core.init import run_init

    kb = Path(kb_root).resolve()
    cwd = Path.cwd()

    result = run_init(kb, cwd)

    click.echo(f"Found {result['total']} markdown files in {kb}")
    click.echo()
    click.echo("Quality Report:")
    click.echo(f"  {result['ready']} ready")
    click.echo(f"  {result['fixable']} fixable       (run `ike doctor` to fix)")
    click.echo(f"  {result['needs_review']} need review")
    click.echo()
    for a in result["artifacts"]:
        click.echo(f"Created: {a}")
    click.echo()
    click.echo("Restart your AI tool to activate ike MCP.")
