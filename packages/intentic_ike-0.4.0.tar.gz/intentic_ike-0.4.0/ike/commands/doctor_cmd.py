"""ike doctor — auto-fix missing frontmatter + cross-reference suggestions."""

from __future__ import annotations

from pathlib import Path

import click


@click.command()
@click.option("--yes", "auto_fix", is_flag=True, help="Apply all fixes without prompting")
@click.option("--cross-refs", "cross_refs", is_flag=True, help="Suggest missing cross-references for orphaned docs")
@click.option(
    "--kb-root",
    type=click.Path(exists=True),
    default=None,
    help="KB root (defaults to --kb-root from parent group or IKE_KB_ROOT)",
)
@click.pass_context
def cmd(ctx: click.Context, auto_fix: bool, cross_refs: bool, kb_root: str | None) -> None:
    """Auto-fix missing frontmatter and suggest cross-references."""
    from ike.core.doctor import run_doctor, suggest_cross_refs

    if kb_root:
        kb = Path(kb_root).resolve()
    else:
        kb = ctx.obj.get("kb_root")
        if kb is None:
            kb = Path.home() / "intentic-kb"

    if cross_refs:
        suggestions = suggest_cross_refs(kb)
        if not suggestions:
            click.echo("No orphaned documents found. Cross-references look good.")
            return

        orphans_with_suggestions = [s for s in suggestions if s["suggestions"]]
        orphans_without = [s for s in suggestions if not s["suggestions"]]

        click.echo(f"Found {len(suggestions)} orphaned document(s).\n")

        for item in orphans_with_suggestions:
            click.echo(f"  {item['file']}")
            if item["title"]:
                click.echo(f"    Title: {item['title']}")
            click.echo(f"    Domain: {item['domain'] or 'unknown'}")
            click.echo("    Suggested links:")
            for s in item["suggestions"]:
                click.echo(f"      -> {s['target']} ({s['reason']})")
            click.echo()

        if orphans_without:
            click.echo(f"  {len(orphans_without)} orphan(s) with no clear match:")
            for item in orphans_without:
                click.echo(f"    - {item['file']}")
            click.echo()

        click.echo("To fix: Add Markdown links between related documents,")
        click.echo("e.g., a '## Related' section with links to suggested targets.")
        return

    fixed = run_doctor(kb, auto_fix=auto_fix)
    click.echo(f"\nFixed {fixed} file(s).")
    if fixed > 0:
        click.echo("Run `ike lint` to verify.")
