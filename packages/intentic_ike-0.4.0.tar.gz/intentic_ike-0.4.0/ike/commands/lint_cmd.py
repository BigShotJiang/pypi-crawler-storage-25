"""Run consistency checks on the KB."""

from __future__ import annotations

import click


@click.command()
@click.option("--freshness", type=int, default=None, help="Flag docs older than N days")
@click.pass_context
def cmd(ctx: click.Context, freshness: int | None) -> None:
    """Run consistency checks on the KB."""
    findings = ctx.obj["engine"].lint(freshness)
    if not findings:
        click.echo("No issues found.")
        return
    for f in findings:
        click.echo(f"[{f.severity}] {f.file_path}: {f.check} — {f.message}")
    click.echo(f"\n{len(findings)} issue(s) found.")
