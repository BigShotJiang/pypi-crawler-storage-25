"""Route a query to relevant KB sections."""

from __future__ import annotations

import json
from dataclasses import asdict

import click


@click.command()
@click.argument("query_text")
@click.option("--limit", default=10, help="Max results")
@click.option("--type", "knowledge_type", default=None, help="Filter by type")
@click.pass_context
def cmd(ctx: click.Context, query_text: str, limit: int, knowledge_type: str | None) -> None:
    """Find relevant KB sections. Returns paths + token counts."""
    result = ctx.obj["engine"].route(query_text, limit, knowledge_type)
    click.echo(json.dumps(asdict(result), indent=2))
