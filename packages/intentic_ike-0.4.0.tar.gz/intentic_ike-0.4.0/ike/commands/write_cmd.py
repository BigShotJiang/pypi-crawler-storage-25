"""Modify KB content. Content is read from stdin."""

from __future__ import annotations

import sys

import click


@click.command("write")
@click.option("--file", "file_path", required=True, help="File to modify")
@click.option("--mode", type=click.Choice(["append", "replace"]), required=True)
@click.option("--section", default=None, help="Section ID (required for replace)")
@click.option("--agent-id", default="manual", help="Agent identifier for git commit")
@click.option("--no-commit", is_flag=True, help="Skip git commit")
@click.pass_context
def cmd(
    ctx: click.Context,
    file_path: str,
    mode: str,
    section: str | None,
    agent_id: str,
    no_commit: bool,
) -> None:
    """Modify KB content. Content is read from stdin."""
    content = sys.stdin.read()
    if not content.strip():
        click.echo("Error: No content provided via stdin", err=True)
        raise SystemExit(1)

    result = ctx.obj["engine"].write(
        file_path, content, mode, section, agent_id, not no_commit
    )
    if not result.success:
        click.echo(f"Error: {result.error}", err=True)
        raise SystemExit(1)

    click.echo(f"Written to {result.file_path} (mode={result.mode}, committed={result.committed})")
