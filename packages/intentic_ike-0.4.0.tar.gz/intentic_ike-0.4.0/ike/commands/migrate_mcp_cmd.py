"""ike migrate-mcp — migrate .mcp.json to portable pattern."""

from __future__ import annotations

import json
from pathlib import Path

import click


@click.command("migrate-mcp")
@click.option("--dry-run", is_flag=True, help="Show changes without applying")
def cmd(dry_run: bool) -> None:
    """Migrate .mcp.json from absolute paths to portable uvx/pipx pattern."""
    from ike.core.migrate import run_migrate_mcp

    result = run_migrate_mcp(Path.cwd(), dry_run=dry_run)

    if not result["changed"]:
        click.echo(f"No migration needed: {result.get('reason', 'unknown')}")
        return

    if dry_run:
        click.echo("DRY RUN — would change:")
        click.echo(f"  Old: {json.dumps(result['old'], indent=2)}")
        click.echo(f"  New: {json.dumps(result['new'], indent=2)}")
    else:
        click.echo("Migrated .mcp.json:")
        click.echo(f"  Old command: {result['old'].get('command')}")
        click.echo(f"  New command: {result['new'].get('command')}")
