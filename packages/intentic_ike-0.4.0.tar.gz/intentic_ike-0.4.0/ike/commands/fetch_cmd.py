"""Load KB content (entire file or specific section)."""

from __future__ import annotations

import click


@click.command()
@click.argument("file_path")
@click.option("--section", default=None, help="Section ID to fetch")
@click.pass_context
def cmd(ctx: click.Context, file_path: str, section: str | None) -> None:
    """Load KB content (entire file or specific section)."""
    try:
        result = ctx.obj["engine"].fetch(file_path, section)
        click.echo(result.content)
    except KeyError as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1)
    except FileNotFoundError:
        click.echo(f"Error: File not found: {file_path}", err=True)
        raise SystemExit(1)
