"""List all KB documents and sections."""

from __future__ import annotations

import click


@click.command("list")
@click.option("--type", "knowledge_type", default=None, help="Filter by type")
@click.pass_context
def cmd(ctx: click.Context, knowledge_type: str | None) -> None:
    """List all KB documents and sections."""
    chunks = ctx.obj["engine"].list_docs(knowledge_type)
    for c in chunks:
        section = f"#{c.section_id}" if c.section_id else ""
        click.echo(f"{c.file_path}{section} ({c.token_count} tokens)")
    click.echo(f"\n{len(chunks)} section(s).")
