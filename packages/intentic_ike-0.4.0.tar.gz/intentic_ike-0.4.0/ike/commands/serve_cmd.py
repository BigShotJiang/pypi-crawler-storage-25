"""ike serve — start the MCP server.

CRITICAL: No top-level imports of fastmcp or ike.mcp_server.
CRITICAL: No print(), sys.stdout.write(), or click.echo() — stdout is for JSON-RPC.
"""

from __future__ import annotations

import click


@click.command()
def cmd() -> None:
    """Start the ike MCP server (stdio transport)."""
    from ike.core.serve import run_serve

    run_serve()
