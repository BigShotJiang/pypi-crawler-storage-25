"""Build or rebuild the search index."""

from __future__ import annotations

import click


@click.command()
@click.option("--rebuild", is_flag=True, help="Full rebuild (drop + reindex)")
@click.pass_context
def cmd(ctx: click.Context, rebuild: bool) -> None:
    """Build or rebuild the search index."""
    engine = ctx.obj["engine"]
    if rebuild:
        n = engine.rebuild_index()
        click.echo(f"Index rebuilt: {n} chunks indexed.")
    else:
        engine.index.ensure_fresh(engine.parser)
        click.echo("Index is fresh.")
