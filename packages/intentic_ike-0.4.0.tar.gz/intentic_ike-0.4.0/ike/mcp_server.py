"""ike MCP Server — thin wrapper around Engine.

Exposes route() and fetch() as MCP tools for Claude Desktop,
Cursor, VS Code, Cline, Windsurf, Zed, and any other MCP client.
"""

from __future__ import annotations

import os
from dataclasses import asdict
from pathlib import Path

from fastmcp import FastMCP

from .core.engine import Engine

mcp = FastMCP(
    "ike",
    instructions=(
        "intentic Knowledge Engine — context-efficient knowledge serving. "
        "Use route() first to find relevant sections (~100 tokens), "
        "then fetch() to load specific content. Never fetch everything."
    ),
)

_kb_root = Path(os.environ.get("IKE_KB_ROOT", str(Path.home() / "intentic-kb")))
_ike_dir = Path(os.environ.get("IKE_DIR", str(Path.home() / ".ike")))
_engine = Engine(kb_root=_kb_root, ike_dir=_ike_dir)


_VALID_DEPTHS = {"shallow", "deep"}


def _clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(value, hi))


@mcp.tool()
def route(query: str, limit: int = 10, knowledge_type: str | None = None) -> dict:
    """Find relevant knowledge sections in the KB.

    Returns paths, section IDs, relevance scores, and token counts.
    Use this FIRST to identify what to fetch — costs ~100 tokens.
    Then call fetch() for the sections you actually need.

    Args:
        query: Natural language question or keywords
        limit: Maximum number of results (default: 10)
        knowledge_type: Optional filter (canonical, architectural, procedural, strategic)
    """
    limit = _clamp(limit, 1, 100)
    result = _engine.route(query, limit, knowledge_type)
    return asdict(result)


@mcp.tool()
def fetch(file_path: str, section_id: str | None = None) -> dict:
    """Load content from a specific KB file or section.

    Call route() first to find the right file_path and section_id.

    WARNING: When using write operations, replacing a parent section (H2)
    will include all child sections (H3/H4). Fetch the full section first
    before replacing to avoid accidental data loss.

    Args:
        file_path: Relative path to the KB file (e.g., "company/vision.md")
        section_id: Optional section ID to fetch (e.g., "the-platform"). None = entire file body.
    """
    result = _engine.fetch(file_path, section_id)
    return asdict(result)


@mcp.tool()
def query(query_text: str, depth: str = "shallow", limit: int = 5) -> list[dict]:
    """Route + fetch in one step. Returns content directly.

    Args:
        query_text: Natural language question or keywords
        depth: "shallow" (top-1 result) or "deep" (top-N results)
        limit: Maximum results for deep mode (default: 5)
    """
    if depth not in _VALID_DEPTHS:
        depth = "shallow"
    limit = _clamp(limit, 1, 100)
    results = _engine.query_and_fetch(query_text, depth, limit)
    return [asdict(r) for r in results]


@mcp.tool()
def lint(freshness_days: int | None = None) -> list[dict]:
    """Run consistency checks on the KB.

    Checks: orphan docs, missing frontmatter, broken cross-refs, stale docs.

    Args:
        freshness_days: Flag docs older than N days (optional)
    """
    if freshness_days is not None:
        freshness_days = _clamp(freshness_days, 1, 3650)
    findings = _engine.lint(freshness_days)
    return [asdict(f) for f in findings]


if __name__ == "__main__":
    mcp.run()
