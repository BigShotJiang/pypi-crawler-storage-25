"""Tests for ike.core.writer."""

from pathlib import Path

import pytest

from ike.core.parser import Parser
from ike.core.writer import Writer
from ike.core.types import WriteResult

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def kb(tmp_path):
    """Create a temp KB with a copy of the fixture."""
    src = FIXTURES / "with_frontmatter.md"
    dst = tmp_path / "doc.md"
    dst.write_text(src.read_text())
    return tmp_path


@pytest.fixture
def writer(kb):
    parser = Parser(kb_root=kb)
    locks = kb / ".locks"
    return Writer(parser, kb_root=kb, locks_dir=locks)


def test_write_append(writer, kb):
    doc = kb / "doc.md"
    result = writer.write(doc, "## New Section\n\nNew content.", "append", auto_commit=False)
    assert result.success is True
    text = doc.read_text()
    assert "New content." in text
    assert "First Section" in text  # original still there


def test_write_replace(writer, kb):
    doc = kb / "doc.md"
    result = writer.write(
        doc, "## Second Section\n\nReplaced.", "replace",
        section_id="second-section", auto_commit=False,
    )
    assert result.success is True
    text = doc.read_text()
    assert "Replaced." in text
    assert "More content with" not in text  # old content gone


def test_write_replace_preserves_frontmatter(writer, kb):
    doc = kb / "doc.md"
    original = doc.read_text()
    writer.write(
        doc, "## Second Section\n\nNew.", "replace",
        section_id="second-section", auto_commit=False,
    )
    text = doc.read_text()
    assert text.startswith("---\n")
    assert 'title: "Test Document"' in text


def test_write_replace_not_found(writer, kb):
    doc = kb / "doc.md"
    result = writer.write(
        doc, "New content", "replace",
        section_id="nonexistent", auto_commit=False,
    )
    assert result.success is False
    assert "not found" in result.error


def test_write_replace_missing_section_id(writer, kb):
    doc = kb / "doc.md"
    result = writer.write(doc, "Content", "replace", auto_commit=False)
    assert result.success is False
    assert "section_id required" in result.error


def test_write_invalid_mode(writer, kb):
    doc = kb / "doc.md"
    result = writer.write(doc, "Content", "invalid", auto_commit=False)
    assert result.success is False
    assert "Unknown mode" in result.error


def test_write_readonly(kb):
    doc = kb / "readonly.md"
    doc.write_text('---\ntitle: "RO"\nreadonly: true\n---\n\n# Content\n')
    parser = Parser(kb_root=kb)
    writer = Writer(parser, kb_root=kb, locks_dir=kb / ".locks")
    result = writer.write(doc, "New content", "append", auto_commit=False)
    assert result.success is False
    assert "readonly" in result.error


def test_write_updates_frontmatter_date(writer, kb):
    doc = kb / "doc.md"
    writer.write(doc, "## New\n\nContent.", "append", auto_commit=False)
    text = doc.read_text()
    # Should have updated last-updated from "2026-01-15" to today
    assert "2026-01-15" not in text
    assert "last-updated:" in text


def test_write_concurrent_different_files(kb):
    """Two writers on different files should not deadlock."""
    doc1 = kb / "doc.md"
    doc2 = kb / "doc2.md"
    doc2.write_text("# Doc2\n\nContent.")

    parser = Parser(kb_root=kb)
    locks = kb / ".locks"
    w1 = Writer(parser, kb, locks)
    w2 = Writer(parser, kb, locks)

    r1 = w1.write(doc1, "## Added1\n\nC1.", "append", auto_commit=False)
    r2 = w2.write(doc2, "## Added2\n\nC2.", "append", auto_commit=False)

    assert r1.success is True
    assert r2.success is True
