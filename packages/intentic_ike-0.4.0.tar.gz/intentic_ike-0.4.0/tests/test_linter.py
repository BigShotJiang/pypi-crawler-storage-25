"""Tests for ike.core.linter."""

from pathlib import Path

import pytest

from ike.core.linter import Linter
from ike.core.parser import Parser
from ike.core.types import LintFinding

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def linter():
    return Linter(Parser(kb_root=FIXTURES), kb_root=FIXTURES)


def test_lint_all_returns_findings(linter):
    findings = linter.lint_all()
    assert isinstance(findings, list)
    assert all(isinstance(f, LintFinding) for f in findings)


def test_lint_detects_missing_frontmatter(linter):
    findings = linter.lint_all()
    missing_fm = [f for f in findings if f.check == "missing_frontmatter"
                  and "without_frontmatter" in f.file_path]
    assert len(missing_fm) > 0


def test_lint_detects_orphans(linter):
    findings = linter.lint_all()
    orphans = [f for f in findings if f.check == "orphan"]
    # Some fixtures may be orphans (no incoming refs)
    assert isinstance(orphans, list)


def test_lint_detects_broken_refs(tmp_path):
    """Create a doc with a broken link and check lint finds it."""
    doc = tmp_path / "broken.md"
    doc.write_text('---\ntitle: "Test"\ndomain: product\nsummary: "Test"\n---\n\n## Section\n\nSee [link](./nonexistent.md).\n')

    parser = Parser(kb_root=tmp_path)
    linter = Linter(parser, kb_root=tmp_path)
    findings = linter.lint_all()
    broken = [f for f in findings if f.check == "broken_ref"]
    assert len(broken) >= 1
    assert "nonexistent" in broken[0].message


def test_lint_freshness(tmp_path):
    """Create a stale doc and check lint finds it."""
    doc = tmp_path / "stale.md"
    doc.write_text('---\ntitle: "Old"\nlast-updated: "2020-01-01"\ndomain: engineering\nsummary: "old"\n---\n\n## Content\n\nOld.\n')

    parser = Parser(kb_root=tmp_path)
    linter = Linter(parser, kb_root=tmp_path)
    findings = linter.lint_freshness(max_days=30)
    stale = [f for f in findings if f.check == "stale"]
    assert len(stale) >= 1
    assert "2020-01-01" in stale[0].message


def test_lint_freshness_no_field(tmp_path):
    doc = tmp_path / "nodate.md"
    doc.write_text('---\ntitle: "NoDate"\ndomain: product\nsummary: "test"\n---\n\n## Content\n')

    parser = Parser(kb_root=tmp_path)
    linter = Linter(parser, kb_root=tmp_path)
    findings = linter.lint_freshness(max_days=30)
    stale = [f for f in findings if f.check == "stale"]
    assert len(stale) >= 1
    assert "No last-updated" in stale[0].message


def test_lint_headerless(tmp_path):
    doc = tmp_path / "noheader.md"
    doc.write_text('---\ntitle: "NoH"\ndomain: product\nsummary: "test"\n---\n\nJust text, no headers.\n')

    parser = Parser(kb_root=tmp_path)
    linter = Linter(parser, kb_root=tmp_path)
    findings = linter.lint_all()
    headerless = [f for f in findings if f.check == "headerless"]
    assert len(headerless) >= 1


def test_lint_wikilink_detection(tmp_path):
    """Wikilinks should be recognized as cross-refs."""
    doc1 = tmp_path / "source.md"
    doc1.write_text('---\ntitle: "Src"\ndomain: product\nsummary: "s"\n---\n\n## S\n\nSee [[target]].\n')
    doc2 = tmp_path / "target.md"
    doc2.write_text('---\ntitle: "Tgt"\ndomain: product\nsummary: "t"\n---\n\n## T\n\nContent.\n')

    parser = Parser(kb_root=tmp_path)
    linter = Linter(parser, kb_root=tmp_path)
    findings = linter.lint_all()
    # target.md should NOT be orphan (source links to it via wikilink)
    orphan_targets = [f for f in findings if f.check == "orphan" and "target" in f.file_path]
    assert len(orphan_targets) == 0
