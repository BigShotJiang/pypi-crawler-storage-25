"""Tests for ike init command."""

from pathlib import Path

import pytest

from ike.core.init import run_init


@pytest.fixture
def kb_with_docs(tmp_path):
    """KB with mix of compliant and non-compliant docs."""
    (tmp_path / "company").mkdir()
    (tmp_path / "engineering").mkdir()

    # Compliant: has frontmatter + headers
    (tmp_path / "company" / "vision.md").write_text(
        '---\ntitle: "Vision"\ndomain: "company"\nsummary: "Our vision."\n---\n\n# Vision\n\n## Mission\nContent.\n'
    )
    # Fixable: no frontmatter
    (tmp_path / "engineering" / "arch.md").write_text(
        "# Architecture\n\nOur system.\n\n## API\nREST API.\n"
    )
    # Needs review: no headers
    (tmp_path / "engineering" / "notes.md").write_text(
        "Just some notes without any headers or frontmatter.\n"
    )
    return tmp_path


def test_run_init_counts(kb_with_docs, tmp_path):
    target = tmp_path / "target"
    target.mkdir()
    result = run_init(kb_with_docs, target)
    assert result["total"] == 3
    assert result["ready"] == 1
    assert result["fixable"] == 2  # arch.md (no FM) + notes.md (no FM, no headers)
    assert result["needs_review"] == 0


def test_run_init_generates_artifacts(kb_with_docs, tmp_path):
    target = tmp_path / "target"
    target.mkdir()
    result = run_init(kb_with_docs, target)
    assert (target / ".mcp.json").exists()
    assert (target / "AGENTS.md").exists()
    assert len(result["artifacts"]) == 2


def test_run_init_empty_kb(tmp_path):
    kb = tmp_path / "empty-kb"
    kb.mkdir()
    target = tmp_path / "target"
    target.mkdir()
    result = run_init(kb, target)
    assert result["total"] == 0


def test_run_init_nonexistent_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        run_init(tmp_path / "nope", tmp_path)
