"""Tests for ike.core.fetcher."""

from pathlib import Path

import pytest

from ike.core.fetcher import Fetcher
from ike.core.parser import Parser
from ike.core.types import FetchResult

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def fetcher():
    return Fetcher(Parser(kb_root=FIXTURES))


def test_fetch_entire_file(fetcher):
    result = fetcher.fetch(FIXTURES / "with_frontmatter.md")
    assert isinstance(result, FetchResult)
    assert result.section_id is None
    assert "First Section" in result.content
    assert result.token_count > 0
    assert result.metadata["title"] == "Test Document"


def test_fetch_specific_section(fetcher):
    result = fetcher.fetch(FIXTURES / "with_frontmatter.md", "first-section")
    assert result.section_id == "first-section"
    assert "Content of first section" in result.content
    assert "Second Section" not in result.content


def test_fetch_h3_section(fetcher):
    result = fetcher.fetch(FIXTURES / "with_frontmatter.md", "first-section--sub-section")
    assert "Sub content" in result.content


def test_fetch_section_not_found(fetcher):
    with pytest.raises(KeyError, match="nonexistent"):
        fetcher.fetch(FIXTURES / "with_frontmatter.md", "nonexistent")


def test_fetch_without_frontmatter(fetcher):
    result = fetcher.fetch(FIXTURES / "without_frontmatter.md")
    assert result.metadata == {}
    assert "Simple Document" in result.content


def test_fetch_metadata(fetcher):
    meta = fetcher.fetch_metadata(FIXTURES / "with_frontmatter.md")
    assert meta["title"] == "Test Document"
    assert meta["domain"] == "engineering"


def test_fetch_metadata_no_frontmatter(fetcher):
    meta = fetcher.fetch_metadata(FIXTURES / "without_frontmatter.md")
    assert meta == {}
