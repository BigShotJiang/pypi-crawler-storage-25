"""Tests for ike.core.parser — at least 20 tests covering all ACs."""

from pathlib import Path

import pytest

from ike.core.parser import Parser
from ike.core.types import CrossRef, ParsedDocument

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def parser():
    return Parser(kb_root=FIXTURES)


# ── AC1: parse_document with/without frontmatter ───────────────


def test_parse_with_frontmatter(parser):
    doc = parser.parse_document(FIXTURES / "with_frontmatter.md")
    assert isinstance(doc, ParsedDocument)
    assert doc.has_frontmatter is True
    assert doc.frontmatter["title"] == "Test Document"
    assert doc.frontmatter["domain"] == "engineering"
    assert len(doc.chunks) > 0


def test_parse_without_frontmatter(parser):
    doc = parser.parse_document(FIXTURES / "without_frontmatter.md")
    assert doc.has_frontmatter is False
    assert doc.frontmatter == {}
    assert doc.frontmatter_raw == ""
    assert len(doc.chunks) > 0


def test_parse_empty_file(parser, tmp_path):
    empty = tmp_path / "empty.md"
    empty.write_text("")
    p = Parser(kb_root=tmp_path)
    doc = p.parse_document(empty)
    assert doc.has_frontmatter is False
    assert doc.chunks == []


# ── AC2: Section IDs ───────────────────────────────────────────


def test_section_ids_slugified(parser):
    doc = parser.parse_document(FIXTURES / "with_frontmatter.md")
    ids = [c.section_id for c in doc.chunks]
    assert "first-section" in ids
    assert "second-section" in ids
    assert "third-section" in ids


def test_section_ids_hierarchical(parser):
    doc = parser.parse_document(FIXTURES / "with_frontmatter.md")
    ids = [c.section_id for c in doc.chunks]
    assert "first-section--sub-section" in ids


def test_section_ids_duplicate(parser):
    doc = parser.parse_document(FIXTURES / "code_blocks.md")
    ids = [c.section_id for c in doc.chunks]
    assert "duplicate-header" in ids
    assert "duplicate-header-2" in ids


# ── AC3: Code blocks not parsed as headers ─────────────────────


def test_code_blocks_not_parsed_as_headers(parser):
    doc = parser.parse_document(FIXTURES / "code_blocks.md")
    titles = [c.section_title for c in doc.chunks]
    # Code block comments should NOT appear as section titles
    assert "This is a bash comment NOT a header" not in titles
    assert "This is also NOT a header" not in titles
    assert "Python comment not a header" not in titles
    # Real headers should be present
    assert "Real Header" in titles
    assert "Another Real Header" in titles


# ── AC4: replace_section ──────────────────────────────────────


def test_replace_section_basic(parser):
    raw = FIXTURES.joinpath("with_frontmatter.md").read_text()
    result = parser.replace_section(raw, "second-section", "## Second Section\n\nReplaced content.")
    assert result is not None
    assert "Replaced content." in result
    assert "More content with" not in result  # old content gone


def test_replace_section_preserves_frontmatter(parser):
    raw = FIXTURES.joinpath("with_frontmatter.md").read_text()
    original_fm = raw.split("\n---\n")[0] + "\n---"
    result = parser.replace_section(raw, "second-section", "## Second Section\n\nNew.")
    assert result is not None
    assert result.startswith("---\n")
    assert 'title: "Test Document"' in result
    assert 'last-updated: "2026-01-15"' in result


def test_replace_section_not_found(parser):
    raw = FIXTURES.joinpath("with_frontmatter.md").read_text()
    result = parser.replace_section(raw, "nonexistent-section", "New content")
    assert result is None


def test_replace_section_h3(parser):
    raw = FIXTURES.joinpath("with_frontmatter.md").read_text()
    result = parser.replace_section(raw, "first-section--sub-section", "### Sub Section\n\nReplaced sub.")
    assert result is not None
    assert "Replaced sub." in result
    # Parent section should still be there
    assert "Content of first section." in result


# ── AC5: Cross-refs ───────────────────────────────────────────


def test_extract_markdown_links(parser):
    content = "See [doc](../other/doc.md) and [another](./file.md#section)."
    refs = parser.extract_cross_refs(content)
    md_refs = [r for r in refs if r.link_type == "markdown"]
    assert len(md_refs) == 2
    assert md_refs[0].target_path == "../other/doc.md"
    assert md_refs[1].target_path == "./file.md"
    assert md_refs[1].section == "section"


def test_extract_wikilinks(parser):
    content = "Link to [[Some Page]] here."
    refs = parser.extract_cross_refs(content)
    wiki_refs = [r for r in refs if r.link_type == "wikilink"]
    assert len(wiki_refs) == 1
    assert wiki_refs[0].target_path == "Some Page"
    assert wiki_refs[0].section is None


def test_extract_wikilinks_with_section(parser):
    content = "See [[Page#Header Reference]] for details."
    refs = parser.extract_cross_refs(content)
    wiki_refs = [r for r in refs if r.link_type == "wikilink"]
    assert len(wiki_refs) == 1
    assert wiki_refs[0].target_path == "Page"
    assert wiki_refs[0].section == "Header Reference"


def test_extract_cross_refs_from_document(parser):
    doc = parser.parse_document(FIXTURES / "with_frontmatter.md")
    assert len(doc.cross_refs) >= 3  # at least: doc.md, sibling.md, Wiki Link, Page#Header


# ── AC6: Frontmatter date update ─────────────────────────────


def test_update_frontmatter_date(parser):
    raw = '---\ntitle: "Test"\nlast-updated: "2020-01-01"\n---\n\n# Body\n'
    result = parser.update_frontmatter_date(raw)
    assert "2020-01-01" not in result
    assert "last-updated:" in result
    # Body unchanged
    assert "# Body" in result


def test_update_frontmatter_date_no_frontmatter(parser):
    raw = "# Just markdown\n\nNo frontmatter."
    result = parser.update_frontmatter_date(raw)
    assert result == raw  # unchanged


def test_update_frontmatter_date_no_field(parser):
    raw = '---\ntitle: "Test"\n---\n\n# Body\n'
    result = parser.update_frontmatter_date(raw)
    assert result == raw  # unchanged, no last-updated field


def test_update_frontmatter_date_body_unchanged(parser):
    raw = '---\ntitle: "Test"\nlast-updated: "2020-01-01"\n---\n\nSome text with last-updated: "should not change" in body.\n'
    result = parser.update_frontmatter_date(raw)
    # Body text containing "last-updated" must NOT be modified
    assert 'last-updated: "should not change"' in result


# ── AC7: CRLF normalization ───────────────────────────────────


def test_crlf_normalization(parser):
    doc = parser.parse_document(FIXTURES / "code_blocks.md")
    # File has CRLF on some lines but parsing should work fine
    assert doc.has_frontmatter is True
    assert "\r" not in doc.body
    assert "\r" not in doc.raw_text
    assert len(doc.chunks) > 0


# ── Basic functionality ───────────────────────────────────────


def test_append_content(parser):
    raw = "# Title\n\nContent."
    result = parser.append_content(raw, "## New Section\n\nNew content.")
    assert result.endswith("New content.\n")
    assert "# Title" in result
    assert "\n\n## New Section" in result


def test_count_tokens(parser):
    count = parser.count_tokens("Hello, world!")
    assert isinstance(count, int)
    assert count > 0
    assert count < 100


def test_get_section(parser):
    chunk = parser.get_section(FIXTURES / "with_frontmatter.md", "first-section")
    assert chunk is not None
    assert chunk.section_id == "first-section"
    assert "Content of first section" in chunk.content


def test_get_section_not_found(parser):
    chunk = parser.get_section(FIXTURES / "with_frontmatter.md", "nonexistent")
    assert chunk is None


def test_get_chunks_count(parser):
    chunks = parser.get_chunks(FIXTURES / "with_frontmatter.md")
    # Should have: main-title, first-section, sub-section, second-section, third-section
    assert len(chunks) >= 4


def test_knowledge_type_derived(parser):
    doc = parser.parse_document(FIXTURES / "with_frontmatter.md")
    # domain: engineering → architectural
    for chunk in doc.chunks:
        assert chunk.knowledge_type == "architectural"


def test_knowledge_type_default(parser):
    doc = parser.parse_document(FIXTURES / "without_frontmatter.md")
    # no domain → canonical (default)
    for chunk in doc.chunks:
        assert chunk.knowledge_type == "canonical"
