"""Tests for artifact generation (AGENTS.md, .mcp.json, etc.)."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from ike.core.artifacts import (
    _detect_runner,
    generate_agents_md,
    generate_cursorrules,
    generate_llms_txt,
    generate_mcp_json,
)


def test_generate_mcp_json_creates_file(tmp_path):
    result = generate_mcp_json(tmp_path)
    assert result.exists()
    data = json.loads(result.read_text())
    assert "ike" in data["mcpServers"]


def test_generate_mcp_json_merges_existing(tmp_path):
    existing = {"mcpServers": {"playwright": {"command": "npx", "args": ["@playwright/mcp"]}}}
    (tmp_path / ".mcp.json").write_text(json.dumps(existing))
    generate_mcp_json(tmp_path)
    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert "playwright" in data["mcpServers"]
    assert "ike" in data["mcpServers"]


def test_generate_agents_md_has_examples(tmp_path):
    kb = tmp_path / "kb"
    kb.mkdir()
    result = generate_agents_md(kb, tmp_path)
    content = result.read_text()
    assert "ike route" in content
    assert "ike fetch" in content
    assert "route(" in content  # MCP tool example


def test_generate_cursorrules_creates_new(tmp_path):
    result = generate_cursorrules(tmp_path)
    assert result.exists()
    assert "ike" in result.read_text()


def test_generate_cursorrules_appends_to_existing(tmp_path):
    (tmp_path / ".cursorrules").write_text("# My existing rules\nSome rule.\n")
    generate_cursorrules(tmp_path)
    content = (tmp_path / ".cursorrules").read_text()
    assert "My existing rules" in content
    assert "ike" in content


def test_generate_cursorrules_skips_if_already_present(tmp_path):
    (tmp_path / ".cursorrules").write_text("# Rules\nike is already mentioned.\n")
    generate_cursorrules(tmp_path)
    content = (tmp_path / ".cursorrules").read_text()
    assert content.count("ike") == 1  # not duplicated


def test_generate_llms_txt(tmp_path):
    kb = tmp_path / "kb"
    (kb / "company").mkdir(parents=True)
    (kb / "company" / "vision.md").write_text("# Vision")
    (kb / "company" / "icp.md").write_text("# ICP")
    result = generate_llms_txt(kb, tmp_path)
    content = result.read_text()
    assert "company/vision.md" in content
    assert "company/icp.md" in content


def test_detect_runner_with_uvx():
    with patch("shutil.which", side_effect=lambda x: "/usr/bin/uvx" if x == "uvx" else None):
        cmd, args = _detect_runner()
    assert cmd == "uvx"
    assert "intentic-ike[mcp]" in " ".join(args)


def test_detect_runner_with_pipx():
    with patch("shutil.which", side_effect=lambda x: "/usr/bin/pipx" if x == "pipx" else None):
        cmd, args = _detect_runner()
    assert cmd == "pipx"


def test_detect_runner_fallback():
    with patch("shutil.which", return_value=None):
        cmd, args = _detect_runner()
    assert cmd == "ike"
    assert args == ["serve"]
