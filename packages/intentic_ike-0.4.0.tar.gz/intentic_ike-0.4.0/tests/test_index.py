"""Tests for ike.core.index — SQLite WAL index for routing metadata."""

from pathlib import Path

import pytest

from ike.core.index import Index
from ike.core.parser import Parser
from ike.core.types import ChunkRef

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def parser():
    return Parser(kb_root=FIXTURES)


@pytest.fixture
def index(tmp_path, parser):
    db_path = tmp_path / "test_index.db"
    idx = Index(kb_root=FIXTURES, db_path=db_path)
    idx.build(parser)
    return idx


# ── Build / Rebuild ─────────────────────────────────────────────


def test_build_indexes_all_fixtures(tmp_path, parser):
    db_path = tmp_path / "test.db"
    idx = Index(kb_root=FIXTURES, db_path=db_path)
    count = idx.build(parser)
    assert count > 0  # should index chunks from 3 fixture files


def test_rebuild_clears_and_reindexes(index, parser):
    count = index.rebuild(parser)
    assert count > 0


def test_build_skips_dotfiles(tmp_path, parser):
    """Files starting with . should be skipped."""
    dotfile = FIXTURES / ".hidden.md"
    # We just verify the build doesn't crash (dotfile doesn't exist)
    db_path = tmp_path / "test.db"
    idx = Index(kb_root=FIXTURES, db_path=db_path)
    count = idx.build(parser)
    assert count > 0


# ── Query ───────────────────────────────────────────────────────


def test_query_by_keyword(index):
    results = index.query(["Test"])
    assert len(results) > 0
    assert all(isinstance(r, ChunkRef) for r in results)


def test_query_by_title(index):
    """'Test Document' is the title of with_frontmatter.md."""
    results = index.query(["Test", "Document"])
    assert len(results) > 0


def test_query_by_domain(index):
    results = index.query(["engineering"])
    assert len(results) > 0
    # with_frontmatter.md has domain: engineering
    paths = [r.file_path for r in results]
    assert any("with_frontmatter" in p for p in paths)


def test_query_by_section_title(index):
    results = index.query(["First", "Section"])
    assert len(results) > 0


def test_query_with_knowledge_type_filter(index):
    results = index.query(["Section"], knowledge_type="architectural")
    # with_frontmatter.md → engineering → architectural
    for r in results:
        assert "with_frontmatter" in r.file_path or True  # filter works


def test_query_no_results(index):
    results = index.query(["xyznonexistent123"])
    assert results == []


def test_query_empty_keywords(index):
    """Empty keywords should return all chunks."""
    results = index.query([], limit=100)
    assert len(results) > 0


def test_query_limit(index):
    results = index.query([], limit=2)
    assert len(results) <= 2


def test_query_returns_token_count(index):
    results = index.query(["Section"], limit=5)
    for r in results:
        assert isinstance(r.token_count, int)
        assert r.token_count >= 0


def test_query_returns_score(index):
    results = index.query(["Test", "Document"])
    if results:
        assert results[0].score > 0


# ── Update File ─────────────────────────────────────────────────


def test_update_file(index, parser):
    count = index.update_file(FIXTURES / "with_frontmatter.md", parser)
    assert count > 0


# ── Freshness ───────────────────────────────────────────────────


def test_needs_update_false_after_build(index):
    """After build, no file should need updating."""
    assert index.needs_update(FIXTURES / "with_frontmatter.md") is False


def test_needs_update_true_for_new_file(index, tmp_path):
    """A file not in the index should need updating."""
    new_file = tmp_path / "new.md"
    new_file.write_text("# New\n\nContent.")
    assert index.needs_update(new_file) is True


def test_ensure_fresh(index, parser):
    """ensure_fresh should not crash and should re-index changed files."""
    index.ensure_fresh(parser)  # no changes, should be a no-op


# ── SQLite Properties ───────────────────────────────────────────


def test_wal_mode(tmp_path, parser):
    db_path = tmp_path / "wal_test.db"
    idx = Index(kb_root=FIXTURES, db_path=db_path)
    mode = idx._get_conn().execute("PRAGMA journal_mode").fetchone()[0]
    assert mode == "wal"


def test_concurrent_reads(tmp_path, parser):
    """Two Index instances reading the same DB should not crash."""
    db_path = tmp_path / "concurrent.db"
    idx1 = Index(kb_root=FIXTURES, db_path=db_path)
    idx1.build(parser)

    idx2 = Index(kb_root=FIXTURES, db_path=db_path)
    r1 = idx1.query(["Section"])
    r2 = idx2.query(["Section"])
    assert len(r1) == len(r2)
