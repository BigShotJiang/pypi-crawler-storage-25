"""Tests for ike serve command."""

import sys
from unittest.mock import MagicMock, patch

import pytest


def test_serve_module_imports_without_fastmcp():
    """serve.py should be importable even without fastmcp installed."""
    # This test verifies the lazy import pattern
    from ike.core.serve import run_serve
    assert callable(run_serve)


def test_serve_configures_stderr_logging():
    """serve should configure logging to stderr, not stdout."""
    with patch("ike.core.serve.logging") as mock_logging:
        with patch("ike.mcp_server.mcp") as mock_mcp:
            mock_mcp.run = MagicMock()
            from ike.core.serve import run_serve
            run_serve()
            mock_logging.basicConfig.assert_called_once()
            call_kwargs = mock_logging.basicConfig.call_args
            assert call_kwargs[1]["stream"] is sys.stderr


def test_serve_calls_mcp_run():
    """serve should call mcp.run() from the existing mcp_server."""
    with patch("ike.core.serve.logging"):
        with patch("ike.mcp_server.mcp") as mock_mcp:
            mock_mcp.run = MagicMock()
            from ike.core import serve
            # Reimport to get fresh module
            import importlib
            importlib.reload(serve)
            serve.run_serve()
            mock_mcp.run.assert_called_once()
