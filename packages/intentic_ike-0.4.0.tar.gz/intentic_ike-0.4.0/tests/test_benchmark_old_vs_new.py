"""Benchmark: Old approach (grep/Read) vs. ike approach.

Proves that ike is:
1. More TOKEN-EFFICIENT (less context consumed)
2. More PRECISE (less noise in results)
3. Equally FAST or faster

Run with: pytest tests/test_benchmark_old_vs_new.py -v -s
"""

import subprocess
import time
from pathlib import Path

import pytest

from ike.core.engine import Engine
from ike.core.parser import Parser

KB_ROOT = Path.home() / "intentic-kb"
pytestmark = pytest.mark.skipif(not KB_ROOT.exists(), reason="intentic-kb not found")


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    ike_dir = tmp_path_factory.mktemp("ike_bench")
    eng = Engine(kb_root=KB_ROOT, ike_dir=ike_dir)
    eng.rebuild_index()
    return eng


@pytest.fixture(scope="module")
def parser():
    return Parser(kb_root=KB_ROOT)


# ═══════════════════════════════════════════════════════════════
# BENCHMARK 1: signal_analyzer.py — Loading company context
#
# OLD: Read 4 full files, truncate to 2000 chars each = ~8000 chars
# NEW: ike route → fetch targeted sections = much less
# ═══════════════════════════════════════════════════════════════


class TestSignalAnalyzerBenchmark:
    """Compare old (full file read) vs new (ike targeted fetch) for signal analyzer."""

    def test_old_approach_token_count(self, parser):
        """Old approach: read 4 full files, count total tokens."""
        files = [
            KB_ROOT / "company" / "vision.md",
            KB_ROOT / "company" / "icp-definition.md",
            KB_ROOT / "company" / "positioning-strategy.md",
            KB_ROOT / "company" / "messaging-framework.md",
        ]
        total_tokens = 0
        for f in files:
            content = f.read_text()
            total_tokens += parser.count_tokens(content)

        # Store for comparison
        self.__class__.old_tokens = total_tokens
        print(f"\n  OLD approach: {total_tokens} tokens (4 full files)")
        assert total_tokens > 0

    def test_new_approach_token_count(self, engine):
        """New approach: route for 'company intelligence ICP positioning' → fetch top sections."""
        # Route to find relevant sections
        route_result = engine.route("company intelligence ICP positioning messaging", limit=8)

        # Fetch top 8 sections (equivalent coverage)
        total_tokens = 0
        for chunk in route_result.chunks[:8]:
            result = engine.fetch(chunk.file_path, chunk.section_id)
            total_tokens += result.token_count

        self.__class__.new_tokens = total_tokens
        print(f"  NEW approach: {total_tokens} tokens (8 targeted sections)")
        assert total_tokens > 0

    def test_token_savings(self):
        """ike should use fewer tokens for equivalent information."""
        old = getattr(self.__class__, "old_tokens", None)
        new = getattr(self.__class__, "new_tokens", None)
        if old and new:
            savings = ((old - new) / old) * 100
            print(f"  TOKEN SAVINGS: {savings:.0f}% ({old} → {new})")
            # ike should save at least 30% tokens
            assert new < old, f"ike used MORE tokens ({new}) than full-file read ({old})"


# ═══════════════════════════════════════════════════════════════
# BENCHMARK 2: Ripple analysis — Finding KB mentions
#
# OLD: grep -r "keyword" ~/intentic-kb/ --include="*.md"
# NEW: ike route "keyword" → targeted results with scores
# ═══════════════════════════════════════════════════════════════


class TestRippleAnalysisBenchmark:
    """Compare grep vs ike for knowledge artifact searches."""

    def test_old_grep_approach(self):
        """Old: grep returns file paths, no relevance, no token counts."""
        start = time.perf_counter()
        result = subprocess.run(
            ["grep", "-rl", "Pipeline", str(KB_ROOT), "--include=*.md"],
            capture_output=True, text=True, timeout=10,
        )
        elapsed_grep = time.perf_counter() - start
        grep_files = [f for f in result.stdout.strip().split("\n") if f]

        # grep gives file paths only — agent must read EACH file to understand context
        total_tokens_if_agent_reads = 0
        parser = Parser(kb_root=KB_ROOT)
        for f in grep_files[:5]:  # Agent typically reads top 5
            content = Path(f).read_text()
            total_tokens_if_agent_reads += parser.count_tokens(content)

        self.__class__.grep_files = len(grep_files)
        self.__class__.grep_tokens = total_tokens_if_agent_reads
        self.__class__.grep_time = elapsed_grep
        print(f"\n  OLD grep: {len(grep_files)} files, {total_tokens_if_agent_reads} tokens (if agent reads top 5), {elapsed_grep:.3f}s")

    def test_new_ike_approach(self, engine):
        """New: ike returns ranked sections with token counts — agent picks what to load."""
        start = time.perf_counter()
        route_result = engine.route("Pipeline Phase Gate", limit=10)
        elapsed_ike = time.perf_counter() - start

        # Agent sees token counts BEFORE fetching — can budget
        total_tokens_fetched = 0
        for chunk in route_result.chunks[:5]:  # Agent fetches top 5 sections (not files!)
            result = engine.fetch(chunk.file_path, chunk.section_id)
            total_tokens_fetched += result.token_count

        self.__class__.ike_sections = len(route_result.chunks)
        self.__class__.ike_tokens = total_tokens_fetched
        self.__class__.ike_time = elapsed_ike
        print(f"  NEW ike:  {len(route_result.chunks)} sections, {total_tokens_fetched} tokens (top 5 fetched), {elapsed_ike:.3f}s")

    def test_ike_more_efficient(self):
        """ike should use fewer tokens because it fetches sections, not whole files."""
        grep_tokens = getattr(self.__class__, "grep_tokens", None)
        ike_tokens = getattr(self.__class__, "ike_tokens", None)
        if grep_tokens and ike_tokens:
            savings = ((grep_tokens - ike_tokens) / grep_tokens) * 100
            print(f"  TOKEN SAVINGS: {savings:.0f}% ({grep_tokens} → {ike_tokens})")
            assert ike_tokens < grep_tokens, f"ike ({ike_tokens}) not more efficient than grep ({grep_tokens})"


# ═══════════════════════════════════════════════════════════════
# BENCHMARK 3: Precision — Does ike find the RIGHT content?
#
# OLD: grep "ICP" finds 40 files (most irrelevant)
# NEW: ike route "ICP" ranks by relevance
# ═══════════════════════════════════════════════════════════════


class TestPrecisionBenchmark:
    """ike should return more relevant results than raw grep."""

    def test_grep_precision(self):
        """grep 'ICP' returns every file containing the string — high noise."""
        result = subprocess.run(
            ["grep", "-rl", "ICP", str(KB_ROOT), "--include=*.md"],
            capture_output=True, text=True, timeout=10,
        )
        grep_files = [f for f in result.stdout.strip().split("\n") if f]
        self.__class__.grep_count = len(grep_files)
        print(f"\n  grep 'ICP': {len(grep_files)} files (all containing 'ICP' somewhere)")

    def test_ike_precision(self, engine):
        """ike route 'ICP Definition' — top result should be icp-definition.md."""
        result = engine.route("ICP Definition", limit=5)
        top = result.chunks[0] if result.chunks else None

        self.__class__.ike_top = top.file_path if top else None
        print(f"  ike route: top result = {top.file_path}#{top.section_id} (score={top.score})" if top else "  ike: no results")

        # Top result MUST be the ICP file
        assert top is not None
        assert "icp" in top.file_path.lower()

    def test_ike_more_precise(self):
        """ike returns fewer, more relevant results than grep."""
        grep_count = getattr(self.__class__, "grep_count", 0)
        ike_top = getattr(self.__class__, "ike_top", None)
        print(f"  grep returned {grep_count} files. ike top-1 was correct: {ike_top}")
        # grep returns many files, ike's top-1 is the right one
        assert grep_count > 5, "grep should find ICP in many files"
        assert ike_top and "icp" in ike_top.lower()


# ═══════════════════════════════════════════════════════════════
# BENCHMARK 4: Section-level access (ike-unique capability)
#
# OLD: Read entire file → agent scans for relevant section → wastes context
# NEW: ike fetch with section_id → only the needed section
# ═══════════════════════════════════════════════════════════════


class TestSectionLevelBenchmark:
    """ike's section-level fetch is a capability grep/Read don't have."""

    def test_full_file_vs_section(self, engine):
        """Compare: reading entire data-knowledge-architecture.md vs. one section."""
        full = engine.fetch("engineering/data-knowledge-architecture.md")
        section = engine.fetch(
            "engineering/data-knowledge-architecture.md",
            "13-deployment-strategie"
        )

        ratio = section.token_count / full.token_count * 100
        print(f"\n  Full file: {full.token_count} tokens")
        print(f"  Section:   {section.token_count} tokens ({ratio:.0f}% of full)")
        print(f"  Savings:   {100 - ratio:.0f}%")

        # Section should be much smaller than full file
        assert section.token_count < full.token_count * 0.3  # less than 30% of full

    def test_vision_section_vs_full(self, engine):
        """Vision.md is huge. Fetching one section saves massively."""
        full = engine.fetch("company/vision.md")
        section = engine.fetch("company/vision.md", "6-the-platform")

        ratio = section.token_count / full.token_count * 100
        print(f"\n  vision.md full: {full.token_count} tokens")
        print(f"  #the-platform:  {section.token_count} tokens ({ratio:.0f}%)")

        assert section.token_count < full.token_count * 0.5
