"""Tests for ike.cli — Click CLI."""

from pathlib import Path

import pytest
from click.testing import CliRunner

from ike.cli import cli

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def runner():
    return CliRunner()


def test_cli_help(runner):
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "ike" in result.output


def test_route_command(runner, tmp_path):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "route", "Section"])
    assert result.exit_code == 0
    assert "file_path" in result.output
    assert "section_id" in result.output


def test_fetch_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "fetch", "with_frontmatter.md"])
    assert result.exit_code == 0
    assert "First Section" in result.output


def test_fetch_section_command(runner):
    result = runner.invoke(
        cli, ["--kb-root", str(FIXTURES), "fetch", "with_frontmatter.md", "--section", "first-section"]
    )
    assert result.exit_code == 0
    assert "Content of first section" in result.output


def test_fetch_not_found(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "fetch", "nonexistent.md"])
    assert result.exit_code == 1


def test_query_command(runner):
    # First rebuild index, then query
    runner.invoke(cli, ["--kb-root", str(FIXTURES), "index", "--rebuild"])
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "query", "Section"])
    assert result.exit_code == 0


def test_lint_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "lint"])
    assert result.exit_code == 0


def test_lint_freshness_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "lint", "--freshness", "1"])
    assert result.exit_code == 0


def test_list_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "list"])
    assert result.exit_code == 0
    assert "section(s)" in result.output


def test_index_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "index"])
    assert result.exit_code == 0
    assert "fresh" in result.output


def test_index_rebuild_command(runner):
    result = runner.invoke(cli, ["--kb-root", str(FIXTURES), "index", "--rebuild"])
    assert result.exit_code == 0
    assert "rebuilt" in result.output


def test_write_append_command(runner, tmp_path):
    doc = tmp_path / "test.md"
    doc.write_text("# Title\n\n## Section\n\nContent.\n")
    result = runner.invoke(
        cli,
        ["--kb-root", str(tmp_path), "write", "--file", "test.md", "--mode", "append", "--no-commit"],
        input="## New\n\nAdded.",
    )
    assert result.exit_code == 0
    assert "Written" in result.output
    assert "Added." in doc.read_text()


def test_write_no_stdin(runner, tmp_path):
    doc = tmp_path / "test.md"
    doc.write_text("# Title\n")
    result = runner.invoke(
        cli,
        ["--kb-root", str(tmp_path), "write", "--file", "test.md", "--mode", "append", "--no-commit"],
        input="",
    )
    assert result.exit_code == 1
