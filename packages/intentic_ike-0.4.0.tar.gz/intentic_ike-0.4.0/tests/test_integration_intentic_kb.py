"""Integration tests against the REAL ~/intentic-kb/.

These tests verify that ike can replace all existing KB access patterns
in the vibe-machine pipeline. Each test maps to a concrete access pattern
found in the audit.

Run with: pytest tests/test_integration_intentic_kb.py -v
Skip if KB not present: tests are auto-skipped if ~/intentic-kb/ doesn't exist.
"""

from pathlib import Path

import pytest

from ike.core.engine import Engine

KB_ROOT = Path.home() / "intentic-kb"
pytestmark = pytest.mark.skipif(not KB_ROOT.exists(), reason="intentic-kb not found")


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    ike_dir = tmp_path_factory.mktemp("ike_integration")
    eng = Engine(kb_root=KB_ROOT, ike_dir=ike_dir)
    eng.rebuild_index()
    return eng


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 1: signal_analyzer.py replacement
# Currently: Path.home() / "intentic-kb" / "company" / "vision.md"
# ═══════════════════════════════════════════════════════════════


class TestSignalAnalyzerReplacement:
    """engine/signal_analyzer.py loads 4 KB files for LLM context."""

    def test_vision_accessible(self, engine):
        result = engine.fetch("company/vision.md")
        assert result.token_count > 100
        assert "Company Intelligence" in result.content or "intentic" in result.content

    def test_icp_accessible(self, engine):
        result = engine.fetch("company/icp-definition.md")
        assert result.token_count > 100
        assert "ICP" in result.content or "Customer" in result.content

    def test_positioning_accessible(self, engine):
        result = engine.fetch("company/positioning-strategy.md")
        assert result.token_count > 50

    def test_messaging_accessible(self, engine):
        result = engine.fetch("company/messaging-framework.md")
        assert result.token_count > 50

    def test_vision_section_fetch(self, engine):
        """Signal analyzer could fetch specific sections instead of full files."""
        result = engine.route("Company Intelligence platform vision")
        assert len(result.chunks) > 0
        assert any("vision" in c.file_path for c in result.chunks)


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 2: engagement_composer.py replacement
# Currently: loads voice-and-tone, engagement-rules, messaging, positioning
# ═══════════════════════════════════════════════════════════════


class TestEngagementComposerReplacement:
    """engine/engagement_composer.py loads 4 KB files for social engagement."""

    def test_voice_and_tone(self, engine):
        result = engine.fetch("content/voice-and-tone.md")
        assert result.token_count > 50

    def test_engagement_rules(self, engine):
        result = engine.fetch("content/engagement-rules.md")
        assert result.token_count > 50

    def test_messaging_framework(self, engine):
        result = engine.fetch("company/messaging-framework.md")
        assert result.token_count > 50

    def test_positioning_strategy(self, engine):
        result = engine.fetch("company/positioning-strategy.md")
        assert result.token_count > 50


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 3: KB-Routing table replacement
# Currently: static table in CLAUDE.md mapping topics to file paths
# ═══════════════════════════════════════════════════════════════


class TestKBRoutingReplacement:
    """CLAUDE.md KB-Routing table maps topics to KB paths. ike.route() replaces this."""

    def test_route_vision(self, engine):
        result = engine.route("Vision Strategie Company Intelligence")
        paths = [c.file_path for c in result.chunks]
        assert any("vision" in p for p in paths)

    def test_route_roadmap(self, engine):
        result = engine.route("Roadmap Milestone Phase")
        paths = [c.file_path for c in result.chunks]
        assert any("roadmap" in p for p in paths)

    def test_route_icp(self, engine):
        result = engine.route("ICP Definition Ideal Customer")
        paths = [c.file_path for c in result.chunks]
        assert any("icp" in p for p in paths)

    def test_route_engineering_principles(self, engine):
        result = engine.route("Engineering Prinzipien principles")
        paths = [c.file_path for c in result.chunks]
        assert any("principles" in p or "engineering" in p for p in paths)

    def test_route_deployment(self, engine):
        result = engine.route("Deployment Strategie EU Sovereign")
        paths = [c.file_path for c in result.chunks]
        assert any("data-knowledge" in p or "architecture" in p for p in paths)

    def test_route_design_tokens(self, engine):
        result = engine.route("Design Tokens OKLCH Spacing")
        paths = [c.file_path for c in result.chunks]
        assert any("design" in p for p in paths)


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 4: Template loading replacement
# Currently: direct Read ~/intentic-kb/templates/solution-template.md
# ═══════════════════════════════════════════════════════════════


class TestTemplateLoading:
    """Prompts reference templates from ~/intentic-kb/templates/."""

    def test_solution_template(self, engine):
        result = engine.fetch("templates/solution-template.md")
        assert result.token_count > 100

    def test_spec_template(self, engine):
        result = engine.fetch("templates/SPEC-TEMPLATE.md")
        assert result.token_count > 50

    def test_epic_template(self, engine):
        result = engine.fetch("templates/EPIC-TEMPLATE.md")
        assert result.token_count > 50

    def test_sprint_contract_template(self, engine):
        result = engine.fetch("templates/SPRINT-CONTRACT-TEMPLATE.md")
        assert result.token_count > 50


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 5: Ripple analysis replacement
# Currently: grep -r "keyword" ~/intentic-kb/ --include="*.md"
# ═══════════════════════════════════════════════════════════════


class TestRippleAnalysisReplacement:
    """Ripple analysis greps KB for affected knowledge artifacts."""

    def test_search_for_pipeline_mentions(self, engine):
        """Ripple analysis searches for pipeline-related terms."""
        result = engine.route("Pipeline Phase Gate")
        assert len(result.chunks) > 0

    def test_search_for_agent_mentions(self, engine):
        result = engine.route("Agent Worker Tech Lead QA")
        assert len(result.chunks) > 0

    def test_search_for_vibe_machine(self, engine):
        result = engine.route("Vibe Machine Workflow")
        assert len(result.chunks) > 0
        paths = [c.file_path for c in result.chunks]
        assert any("vibe-machine" in p or "operations" in p for p in paths)


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 6: Data source skill KB loading
# Currently: Read ~/intentic-kb/product/data-sources/exa/
# ═══════════════════════════════════════════════════════════════


class TestDataSourceSkills:
    """Exa, SociaVault, Tavily skills load KB context from data-sources/."""

    def test_exa_overview(self, engine):
        result = engine.fetch("product/data-sources/exa/exa-overview.md")
        assert result.token_count > 50

    def test_sociavault_overview(self, engine):
        result = engine.fetch("product/data-sources/sociavault/sociavault-overview.md")
        assert result.token_count > 50

    def test_tavily_overview(self, engine):
        result = engine.fetch("product/data-sources/tavily/tavily-overview.md")
        assert result.token_count > 50


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 7: Lint against real KB
# ═══════════════════════════════════════════════════════════════


class TestKBHealthCheck:
    """Lint checks the real KB for consistency issues."""

    def test_lint_runs(self, engine):
        findings = engine.lint()
        assert isinstance(findings, list)

    def test_lint_freshness(self, engine):
        findings = engine.lint(freshness=90)
        assert isinstance(findings, list)

    def test_constitution_exists(self, engine):
        result = engine.fetch("CONSTITUTION.md")
        assert result.token_count > 100

    def test_all_specs_accessible(self, engine):
        for spec in ["SPEC-050-company-as-code.md", "SPEC-051-knowledge-portal.md",
                      "SPEC-052-intentic-knowledge-engine.md"]:
            result = engine.fetch(f"product/specs/{spec}")
            assert result.token_count > 50, f"{spec} not accessible or empty"


# ═══════════════════════════════════════════════════════════════
# TEST GROUP 8: Context efficiency
# ═══════════════════════════════════════════════════════════════


class TestContextEfficiency:
    """Verify that ike delivers context-efficient results."""

    def test_route_response_under_200_tokens(self, engine):
        """Route response should be lightweight (~100 tokens metadata)."""
        result = engine.route("ICP Definition")
        # RouteResult itself should be small — only paths + scores
        import json
        from dataclasses import asdict
        route_json = json.dumps(asdict(result))
        route_tokens = engine.parser.count_tokens(route_json)
        assert route_tokens < 500  # metadata only, not content

    def test_section_fetch_is_targeted(self, engine):
        """Fetching a section should return less than the full file."""
        full = engine.fetch("company/vision.md")
        section = engine.fetch("company/vision.md", "6-the-platform")
        assert section.token_count < full.token_count
        assert section.token_count > 0

    def test_deep_vs_shallow(self, engine):
        shallow = engine.query_and_fetch("ICP", depth="shallow")
        deep = engine.query_and_fetch("ICP", depth="deep", limit=5)
        assert len(shallow) <= len(deep)
