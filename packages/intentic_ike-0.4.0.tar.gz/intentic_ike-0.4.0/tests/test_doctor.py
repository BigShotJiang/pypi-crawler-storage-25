"""Tests for ike doctor command."""

from pathlib import Path
from unittest.mock import patch

import pytest

from ike.core.doctor import run_doctor, suggest_cross_refs


@pytest.fixture
def kb_no_fm(tmp_path):
    """KB with a file that has no frontmatter."""
    (tmp_path / "engineering").mkdir()
    (tmp_path / "engineering" / "arch.md").write_text(
        "# System Architecture\n\nOur system uses microservices.\n\n## API\nREST endpoints.\n"
    )
    return tmp_path


@pytest.fixture
def kb_partial_fm(tmp_path):
    """KB with a file that has partial frontmatter (missing domain+summary)."""
    (tmp_path / "ops").mkdir()
    (tmp_path / "ops" / "deploy.md").write_text(
        '---\ntitle: "Deployment"\n---\n\n# Deployment\n\nWe deploy via CI/CD.\n'
    )
    return tmp_path


@pytest.fixture
def kb_compliant(tmp_path):
    """KB with a fully compliant file."""
    (tmp_path / "company").mkdir()
    (tmp_path / "company" / "vision.md").write_text(
        '---\ntitle: "Vision"\ndomain: "company"\nsummary: "Our long-term vision."\n---\n\n# Vision\n\nContent.\n'
    )
    return tmp_path


def test_auto_fix_adds_frontmatter(kb_no_fm):
    fixed = run_doctor(kb_no_fm, auto_fix=True)
    assert fixed == 1
    content = (kb_no_fm / "engineering" / "arch.md").read_text()
    assert content.startswith("---\n")
    assert "title:" in content
    assert "domain:" in content
    assert "engineering" in content  # inferred from path


def test_auto_fix_adds_missing_fields(kb_partial_fm):
    fixed = run_doctor(kb_partial_fm, auto_fix=True)
    assert fixed == 1
    content = (kb_partial_fm / "ops" / "deploy.md").read_text()
    assert "domain:" in content
    assert "summary:" in content


def test_preserves_body(kb_no_fm):
    original = (kb_no_fm / "engineering" / "arch.md").read_text()
    run_doctor(kb_no_fm, auto_fix=True)
    new_content = (kb_no_fm / "engineering" / "arch.md").read_text()
    # Body should be preserved after frontmatter
    assert "# System Architecture" in new_content
    assert "Our system uses microservices." in new_content
    assert "## API" in new_content


def test_compliant_file_returns_zero(kb_compliant):
    fixed = run_doctor(kb_compliant, auto_fix=True)
    assert fixed == 0


def test_infers_title_from_h1(kb_no_fm):
    run_doctor(kb_no_fm, auto_fix=True)
    content = (kb_no_fm / "engineering" / "arch.md").read_text()
    assert '"System Architecture"' in content


def test_infers_domain_from_path(kb_no_fm):
    run_doctor(kb_no_fm, auto_fix=True)
    content = (kb_no_fm / "engineering" / "arch.md").read_text()
    assert '"engineering"' in content


def test_infers_summary_from_first_paragraph(kb_no_fm):
    run_doctor(kb_no_fm, auto_fix=True)
    content = (kb_no_fm / "engineering" / "arch.md").read_text()
    assert "microservices" in content.split("---")[1]  # in frontmatter summary


def test_interactive_skip(kb_no_fm):
    with patch("builtins.input", return_value="s"):
        fixed = run_doctor(kb_no_fm, auto_fix=False)
    assert fixed == 0
    content = (kb_no_fm / "engineering" / "arch.md").read_text()
    assert not content.startswith("---")


def test_interactive_apply(kb_no_fm):
    with patch("builtins.input", return_value="y"):
        fixed = run_doctor(kb_no_fm, auto_fix=False)
    assert fixed == 1


def test_handles_crlf(tmp_path):
    (tmp_path / "doc.md").write_text("# Title\r\n\r\nContent with CRLF.\r\n")
    fixed = run_doctor(tmp_path, auto_fix=True)
    assert fixed == 1
    content = (tmp_path / "doc.md").read_text()
    assert "title:" in content


def test_handles_bom(tmp_path):
    (tmp_path / "doc.md").write_text("\ufeff# BOM Document\n\nContent after BOM.\n")
    fixed = run_doctor(tmp_path, auto_fix=True)
    assert fixed == 1
    content = (tmp_path / "doc.md").read_text()
    assert "title:" in content


def test_nonexistent_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        run_doctor(tmp_path / "nope", auto_fix=True)


def test_returns_count(tmp_path):
    # Create a KB with multiple files needing fixes
    (tmp_path / "engineering").mkdir()
    (tmp_path / "ops").mkdir()
    (tmp_path / "engineering" / "arch.md").write_text("# Arch\n\nSystem.\n")
    (tmp_path / "ops" / "runbook.md").write_text("# Runbook\n\nOps guide.\n")
    fixed = run_doctor(tmp_path, auto_fix=True)
    assert fixed == 2


# ── Cross-reference suggestion tests ──────────────────────────


@pytest.fixture
def kb_orphans(tmp_path):
    """KB with orphaned docs that share domains and keywords."""
    (tmp_path / "engineering").mkdir()
    (tmp_path / "company").mkdir()
    (tmp_path / "engineering" / "architecture.md").write_text(
        '---\ntitle: "System Architecture"\ndomain: "engineering"\n'
        'summary: "API gateway, authentication, and deployment strategy"\n---\n\n'
        "# System Architecture\n\n## Deployment\nHetzner Cloud.\n"
    )
    (tmp_path / "engineering" / "auth.md").write_text(
        '---\ntitle: "Authentication"\ndomain: "engineering"\n'
        'summary: "OAuth2 authentication flow and API key management"\n---\n\n'
        "# Authentication\n\n## OAuth2\nJWT tokens.\n"
    )
    (tmp_path / "company" / "vision.md").write_text(
        '---\ntitle: "Company Vision"\ndomain: "company"\n'
        'summary: "Mission and strategic goals for growth"\n---\n\n'
        "# Company Vision\n\n## Mission\nBuild knowledge tools.\n"
    )
    return tmp_path


@pytest.fixture
def kb_linked(tmp_path):
    """KB where all docs link to each other (no orphans)."""
    (tmp_path / "a.md").write_text(
        '---\ntitle: "Doc A"\ndomain: "test"\nsummary: "A"\n---\n\n'
        "# Doc A\nSee [Doc B](b.md).\n"
    )
    (tmp_path / "b.md").write_text(
        '---\ntitle: "Doc B"\ndomain: "test"\nsummary: "B"\n---\n\n'
        "# Doc B\nSee [Doc A](a.md).\n"
    )
    return tmp_path


def test_cross_refs_finds_orphans(kb_orphans):
    results = suggest_cross_refs(kb_orphans)
    assert len(results) == 3  # all 3 docs are orphans
    files = {r["file"] for r in results}
    assert "engineering/architecture.md" in files
    assert "engineering/auth.md" in files
    assert "company/vision.md" in files


def test_cross_refs_suggests_same_domain(kb_orphans):
    results = suggest_cross_refs(kb_orphans)
    arch = next(r for r in results if r["file"] == "engineering/architecture.md")
    targets = {s["target"] for s in arch["suggestions"]}
    # auth.md should be suggested (same domain: engineering)
    assert "engineering/auth.md" in targets


def test_cross_refs_includes_reason(kb_orphans):
    results = suggest_cross_refs(kb_orphans)
    arch = next(r for r in results if r["file"] == "engineering/architecture.md")
    auth_suggestion = next(s for s in arch["suggestions"] if s["target"] == "engineering/auth.md")
    assert "same domain" in auth_suggestion["reason"]


def test_cross_refs_no_orphans(kb_linked):
    results = suggest_cross_refs(kb_linked)
    assert results == []


def test_cross_refs_max_five_suggestions(tmp_path):
    """Even with many docs, suggestions are capped at 5."""
    for i in range(10):
        (tmp_path / f"doc{i}.md").write_text(
            f'---\ntitle: "Document {i}"\ndomain: "test"\n'
            f'summary: "Shared keywords about deployment and authentication"\n---\n\n'
            f"# Document {i}\n\n## Deployment\nContent about deployment.\n"
        )
    results = suggest_cross_refs(tmp_path)
    for r in results:
        assert len(r["suggestions"]) <= 5
