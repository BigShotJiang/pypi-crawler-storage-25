"""Tests for ike migrate-mcp command."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from ike.core.migrate import run_migrate_mcp


def test_migrate_absolute_paths(tmp_path):
    mcp = {
        "mcpServers": {
            "ike": {
                "command": "/home/user/ike/.venv/bin/fastmcp",
                "args": ["run", "ike.mcp_server:mcp"],
                "env": {"IKE_KB_ROOT": "/home/user/kb"},
            }
        }
    }
    (tmp_path / ".mcp.json").write_text(json.dumps(mcp))

    with patch("shutil.which", side_effect=lambda x: "/usr/bin/uvx" if x == "uvx" else None):
        result = run_migrate_mcp(tmp_path)

    assert result["changed"]
    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert data["mcpServers"]["ike"]["command"] == "uvx"
    assert data["mcpServers"]["ike"]["env"]["IKE_KB_ROOT"] == "/home/user/kb"


def test_migrate_already_portable(tmp_path):
    mcp = {"mcpServers": {"ike": {"command": "uvx", "args": ["ike", "serve"]}}}
    (tmp_path / ".mcp.json").write_text(json.dumps(mcp))
    result = run_migrate_mcp(tmp_path)
    assert not result["changed"]
    assert result["reason"] == "already portable"


def test_migrate_no_mcp_json(tmp_path):
    result = run_migrate_mcp(tmp_path)
    assert not result["changed"]
    assert "no .mcp.json" in result["reason"]


def test_migrate_no_ike_entry(tmp_path):
    mcp = {"mcpServers": {"playwright": {"command": "npx"}}}
    (tmp_path / ".mcp.json").write_text(json.dumps(mcp))
    result = run_migrate_mcp(tmp_path)
    assert not result["changed"]


def test_migrate_dry_run(tmp_path):
    mcp = {
        "mcpServers": {
            "ike": {"command": "/abs/path/to/fastmcp", "args": ["run"]},
            "other": {"command": "npx"},
        }
    }
    (tmp_path / ".mcp.json").write_text(json.dumps(mcp))

    with patch("shutil.which", return_value=None):
        result = run_migrate_mcp(tmp_path, dry_run=True)

    assert result["changed"]
    assert result["dry_run"]
    # File should NOT be modified
    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert data["mcpServers"]["ike"]["command"] == "/abs/path/to/fastmcp"


def test_migrate_preserves_other_servers(tmp_path):
    mcp = {
        "mcpServers": {
            "ike": {"command": "/abs/path", "args": []},
            "playwright": {"command": "npx", "args": ["@playwright/mcp"]},
        }
    }
    (tmp_path / ".mcp.json").write_text(json.dumps(mcp))

    with patch("shutil.which", side_effect=lambda x: "/usr/bin/pipx" if x == "pipx" else None):
        run_migrate_mcp(tmp_path)

    data = json.loads((tmp_path / ".mcp.json").read_text())
    assert "playwright" in data["mcpServers"]
    assert data["mcpServers"]["playwright"]["command"] == "npx"
