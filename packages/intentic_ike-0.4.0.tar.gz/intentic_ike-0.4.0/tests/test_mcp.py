"""Tests for ike.mcp_server — MCP tool registration and responses."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def mock_env(tmp_path):
    """Point MCP server at fixtures KB."""
    with patch.dict(os.environ, {
        "IKE_KB_ROOT": str(FIXTURES),
        "IKE_DIR": str(tmp_path / ".ike"),
    }):
        # Re-import to pick up env vars
        import importlib
        import ike.mcp_server as mod
        importlib.reload(mod)
        yield mod


def test_route_tool(mock_env):
    result = mock_env.route("Section")
    assert isinstance(result, dict)
    assert "chunks" in result
    assert "query" in result
    assert len(result["chunks"]) > 0


def test_route_with_limit(mock_env):
    result = mock_env.route("Section", limit=2)
    assert len(result["chunks"]) <= 2


def test_route_with_type_filter(mock_env):
    result = mock_env.route("Section", knowledge_type="architectural")
    assert isinstance(result["chunks"], list)


def test_fetch_entire_file(mock_env):
    result = mock_env.fetch("with_frontmatter.md")
    assert isinstance(result, dict)
    assert "content" in result
    assert "First Section" in result["content"]
    assert result["metadata"]["title"] == "Test Document"


def test_fetch_section(mock_env):
    result = mock_env.fetch("with_frontmatter.md", "first-section")
    assert result["section_id"] == "first-section"
    assert "Content of first section" in result["content"]


def test_query_shallow(mock_env):
    results = mock_env.query("First Section", depth="shallow")
    assert isinstance(results, list)
    assert len(results) >= 1


def test_query_deep(mock_env):
    results = mock_env.query("Section", depth="deep", limit=5)
    assert isinstance(results, list)
    assert len(results) >= 1


def test_lint_tool(mock_env):
    results = mock_env.lint()
    assert isinstance(results, list)


def test_lint_with_freshness(mock_env):
    results = mock_env.lint(freshness_days=1)
    assert isinstance(results, list)


def test_mcp_server_has_tools(mock_env):
    """Verify the FastMCP server has all expected tools registered."""
    # fastmcp 3.x: tools are accessible via _tools dict
    tools = getattr(mock_env.mcp, "_tool_manager", None)
    if tools and hasattr(tools, "tools"):
        tool_names = [t.name for t in tools.tools.values()]
    else:
        # Fallback: check that the decorated functions exist as module attrs
        tool_names = [name for name in ("route", "fetch", "query", "lint")
                      if callable(getattr(mock_env, name, None))]
    assert "route" in tool_names
    assert "fetch" in tool_names
    assert "query" in tool_names
    assert "lint" in tool_names
