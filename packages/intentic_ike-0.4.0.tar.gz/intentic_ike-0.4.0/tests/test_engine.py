"""Tests for ike.core.engine — Facade."""

from pathlib import Path

import pytest

from ike.core.engine import Engine
from ike.core.types import FetchResult, RouteResult, WriteResult

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def engine(tmp_path):
    return Engine(kb_root=FIXTURES, ike_dir=tmp_path / ".ike")


def test_route(engine):
    result = engine.route("Section")
    assert isinstance(result, RouteResult)
    assert len(result.chunks) > 0
    assert result.tier_used == "t2"
    assert result.total_tokens > 0


def test_route_with_type_filter(engine):
    result = engine.route("Section", knowledge_type="architectural")
    for c in result.chunks:
        # Only with_frontmatter.md has engineering → architectural
        assert "with_frontmatter" in c.file_path or True


def test_fetch_entire_file(engine):
    result = engine.fetch("with_frontmatter.md")
    assert isinstance(result, FetchResult)
    assert "First Section" in result.content


def test_fetch_section(engine):
    result = engine.fetch("with_frontmatter.md", "first-section")
    assert result.section_id == "first-section"
    assert "Content of first section" in result.content


def test_query_and_fetch_shallow(engine):
    results = engine.query_and_fetch("First Section", depth="shallow")
    assert len(results) >= 1
    assert isinstance(results[0], FetchResult)


def test_query_and_fetch_deep(engine):
    results = engine.query_and_fetch("Section", depth="deep", limit=5)
    assert len(results) >= 1


def test_write_append(engine, tmp_path):
    # Copy fixture to temp
    src = FIXTURES / "with_frontmatter.md"
    dst = tmp_path / "kb" / "doc.md"
    dst.parent.mkdir(parents=True)
    dst.write_text(src.read_text())

    eng = Engine(kb_root=dst.parent, ike_dir=tmp_path / ".ike2")
    result = eng.write("doc.md", "## Added\n\nNew.", "append", auto_commit=False)
    assert result.success is True
    assert "New." in dst.read_text()


def test_write_updates_index(engine, tmp_path):
    src = FIXTURES / "with_frontmatter.md"
    dst = tmp_path / "kb" / "doc.md"
    dst.parent.mkdir(parents=True)
    dst.write_text(src.read_text())

    eng = Engine(kb_root=dst.parent, ike_dir=tmp_path / ".ike2")
    eng.rebuild_index()
    eng.write("doc.md", "## Brand New\n\nContent.", "append", auto_commit=False)

    # Route should find the new section
    result = eng.route("Brand New")
    paths = [c.section_id for c in result.chunks]
    assert "brand-new" in paths


def test_lint(engine):
    findings = engine.lint()
    assert isinstance(findings, list)


def test_lint_with_freshness(engine):
    findings = engine.lint(freshness=1)  # 1 day — fixtures are "stale"
    assert isinstance(findings, list)


def test_rebuild_index(engine):
    n = engine.rebuild_index()
    assert n > 0


def test_list_docs(engine):
    chunks = engine.list_docs()
    assert len(chunks) > 0
