"""Configuration and authentication for MSapling CLI."""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import secrets
import socket
import subprocess as _sp
import sys
from pathlib import Path
from typing import Any, Optional, Tuple

_log = logging.getLogger(__name__)

from pydantic_settings import BaseSettings


_CONFIG_DIR = Path.home() / ".msapling"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
# Legacy plaintext token file — still read for migration, never written to.
_TOKEN_FILE = _CONFIG_DIR / "token"
# Encrypted fallback token file (Fernet-encrypted).
_TOKEN_ENC_FILE = _CONFIG_DIR / "token.enc"
# Machine-specific salt for key derivation.
_KEYFILE = _CONFIG_DIR / ".keyfile"
_KEYRING_SERVICE = "msapling-cli"
_KEYRING_USERNAME = "auth_token"


def _get_keyring_backend():
    if os.getenv("MSAPLING_DISABLE_KEYRING", "").strip().lower() in ("1", "true", "yes", "on"):
        return None
    try:
        import keyring  # type: ignore
        return keyring
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Machine-key derivation for Fernet fallback
# ---------------------------------------------------------------------------

def _get_machine_key() -> bytes:
    """Derive a machine-specific Fernet key.

    Components:
    - hostname (machine identity)
    - current OS username (user identity)
    - random salt in ~/.msapling/.keyfile (created on first call, chmod 600)

    Returns a URL-safe base64-encoded 32-byte key suitable for Fernet.
    """
    # Ensure config dir exists before we try to write .keyfile.
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if _KEYFILE.exists():
        salt = _KEYFILE.read_bytes()
    else:
        salt = secrets.token_bytes(32)
        if sys.platform == "win32":
            # On Windows, use write_bytes for reliable cache flush,
            # then apply ACLs via icacls (POSIX mode bits are ignored).
            _KEYFILE.write_bytes(salt)
            try:
                username = os.environ.get("USERNAME", "")
                if username:
                    _sp.run(
                        ["icacls", str(_KEYFILE), "/inheritance:r", "/grant:r", f"{username}:F"],
                        capture_output=True, check=False,
                    )
            except Exception:
                pass
        else:
            # Unix: atomic create with 0o600 permissions.
            try:
                fd = os.open(str(_KEYFILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                try:
                    os.write(fd, salt)
                    os.fsync(fd)
                finally:
                    os.close(fd)
            except OSError:
                _KEYFILE.write_bytes(salt)

    hostname = socket.gethostname().encode("utf-8", errors="replace")
    username = (os.environ.get("USER") or os.environ.get("USERNAME") or "").encode("utf-8", errors="replace")
    raw = hashlib.sha256(hostname + b":" + username + b":" + salt).digest()
    return base64.urlsafe_b64encode(raw)


def is_keyring_available() -> bool:
    """Return True if the system keyring backend is functional."""
    kb = _get_keyring_backend()
    if kb is None:
        return False
    _probe_svc = "msapling-cli-probe"
    _probe_user = "_probe_"
    _probe_val = "probe"
    try:
        kb.set_password(_probe_svc, _probe_user, _probe_val)
        result = kb.get_password(_probe_svc, _probe_user)
        kb.delete_password(_probe_svc, _probe_user)
        return result == _probe_val
    except Exception:
        return False


def _fernet_encrypt(token: str) -> bytes:
    """Encrypt *token* with the machine key and return raw bytes."""
    from cryptography.fernet import Fernet  # type: ignore
    f = Fernet(_get_machine_key())
    return f.encrypt(token.encode("utf-8"))


def _fernet_decrypt(data: bytes) -> Optional[str]:
    """Decrypt raw bytes from the encrypted token file. Returns None on error."""
    try:
        from cryptography.fernet import Fernet  # type: ignore
        f = Fernet(_get_machine_key())
        return f.decrypt(data).decode("utf-8")
    except Exception:
        return None


def _save_to_enc_file(token: str) -> None:
    """Write Fernet-encrypted token to _TOKEN_ENC_FILE (chmod 600 on Unix)."""
    _TOKEN_ENC_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = _fernet_encrypt(token)
    if sys.platform == "win32":
        # On Windows, use write_bytes for reliable cache flush,
        # then apply ACLs via icacls.
        _TOKEN_ENC_FILE.write_bytes(data)
        try:
            username = os.environ.get("USERNAME", "")
            if username:
                _sp.run(
                    ["icacls", str(_TOKEN_ENC_FILE), "/inheritance:r", "/grant:r", f"{username}:F"],
                    capture_output=True, check=False,
                )
        except Exception:
            pass
    else:
        # Unix: atomic create with 0o600 permissions.
        try:
            fd = os.open(str(_TOKEN_ENC_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            try:
                os.write(fd, data)
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError:
            _TOKEN_ENC_FILE.write_bytes(data)


def _load_from_enc_file() -> Optional[str]:
    """Read and decrypt token from _TOKEN_ENC_FILE. Returns None if missing or corrupt."""
    if not _TOKEN_ENC_FILE.exists():
        return None
    data = _TOKEN_ENC_FILE.read_bytes()
    if not data:
        return None
    return _fernet_decrypt(data)


def _migrate_plaintext_token() -> Optional[str]:
    """If the legacy plaintext token file exists, migrate it to encrypted storage.

    Returns the migrated token value, or None if no migration was needed.
    """
    if not _TOKEN_FILE.exists():
        return None
    try:
        legacy_token = _TOKEN_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return None
    if not legacy_token:
        _TOKEN_FILE.unlink(missing_ok=True)
        return None
    # Save to keyring or encrypted file.
    _save_encrypted(legacy_token)
    # Delete the plaintext file after successful migration.
    try:
        _TOKEN_FILE.unlink()
    except Exception:
        pass
    _log.info("Migrated plaintext token to encrypted storage and deleted %s", _TOKEN_FILE)
    return legacy_token


def _save_encrypted(token: str) -> None:
    """Save token: keyring first, encrypted file as fallback. Does NOT write plaintext."""
    keyring_backend = _get_keyring_backend()
    if keyring_backend is not None:
        try:
            keyring_backend.set_password(_KEYRING_SERVICE, _KEYRING_USERNAME, token)
            # Remove encrypted file if keyring succeeded (avoid stale data).
            if _TOKEN_ENC_FILE.exists():
                _TOKEN_ENC_FILE.unlink()
            return
        except Exception:
            pass
    # Keyring unavailable or failed — use encrypted file fallback.
    _save_to_enc_file(token)


class Settings(BaseSettings):
    api_url: str = "https://api.msapling.com"
    default_model: str = "google/gemini-2.0-flash-001"
    max_tokens: int = 4096
    temperature: float = 0.7
    theme: str = "diamond"
    # Legacy/local Ollama settings still used by CLI commands and older configs.
    ollama_base_url: str = "http://127.0.0.1:11434"
    ollama_enabled: bool = True

    # Be forward/backward compatible with older/newer config keys.
    model_config = {"env_prefix": "MSAPLING_", "extra": "ignore"}


_PROFILES_DIR = _CONFIG_DIR / "profiles"


def get_settings(profile: Optional[str] = None) -> Settings:
    """Load settings, optionally from a named profile."""
    # Check for active profile from env or explicit arg
    profile = profile or os.getenv("MSAPLING_PROFILE")
    if profile:
        profile_file = _PROFILES_DIR / f"{profile}.json"
        if profile_file.exists():
            try:
                data = json.loads(profile_file.read_text(encoding="utf-8"))
                return Settings(**data)
            except Exception as exc:
                _log.warning(
                    "Failed to load profile %r from %s: %s — using defaults",
                    profile, profile_file, exc,
                )

    if _CONFIG_FILE.exists():
        try:
            data = json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
            return Settings(**data)
        except Exception as exc:
            _log.warning(
                "Failed to load config from %s: %s — using defaults",
                _CONFIG_FILE, exc,
            )
    return Settings()


def save_profile(name: str, settings: Settings) -> None:
    """Save a named configuration profile."""
    _PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    path = _PROFILES_DIR / f"{name}.json"
    path.write_text(json.dumps(settings.model_dump(), indent=2), encoding="utf-8")


def list_profiles() -> list:
    """List available configuration profiles."""
    if not _PROFILES_DIR.exists():
        return []
    return [f.stem for f in sorted(_PROFILES_DIR.glob("*.json"))]


def save_settings(settings: Settings) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(settings.model_dump(), indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# 3-level hierarchical config resolution
# Level 1 (lowest): user-level   ~/.msapling/config.json
# Level 2:          project-level .msapling/config.json in cwd
# Level 3 (highest): environment variables  MSAPLING_<KEY>
# ---------------------------------------------------------------------------

def _load_user_config() -> dict:
    """Load the user-level config file (~/.msapling/config.json)."""
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _load_project_config() -> dict:
    """Load the project-level config (.msapling/config.json in cwd)."""
    project_config = Path.cwd() / ".msapling" / "config.json"
    if project_config.exists():
        try:
            return json.loads(project_config.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _env_key_for(key: str) -> str:
    """Convert a config key to its MSAPLING_ env var name."""
    return f"MSAPLING_{key.upper()}"


def get_config_with_source(key: str) -> Tuple[Any, str]:
    """Return (value, source) for a config key using 3-level resolution.

    Resolution order (highest wins):
      1. Environment variable  MSAPLING_<KEY>   → source "env"
      2. Project-level file    .msapling/config.json → source "project"
      3. User-level file       ~/.msapling/config.json → source "user"

    Returns (None, "default") if the key is not set at any level.
    """
    # Level 3: environment variables (highest priority)
    env_val = os.getenv(_env_key_for(key))
    if env_val is not None:
        return env_val, "env"

    # Level 2: project-level config
    project_cfg = _load_project_config()
    if key in project_cfg:
        return project_cfg[key], "project"

    # Level 1: user-level config
    user_cfg = _load_user_config()
    if key in user_cfg:
        return user_cfg[key], "user"

    return None, "default"


def _token_from_env() -> Optional[str]:
    token = os.getenv("MSAPLING_TOKEN")
    if token is None:
        return None
    token = token.strip()
    return token or None


def _token_from_file() -> Optional[str]:
    """Load token from encrypted file.  Transparently migrates legacy plaintext file."""
    # Migrate legacy plaintext token if it exists.
    migrated = _migrate_plaintext_token()
    if migrated:
        return migrated
    return _load_from_enc_file()


def _token_from_keyring() -> Optional[str]:
    keyring_backend = _get_keyring_backend()
    if keyring_backend is None:
        return None
    try:
        token = keyring_backend.get_password(_KEYRING_SERVICE, _KEYRING_USERNAME)
        if token:
            return token.strip()
    except Exception:
        pass
    return None


def inspect_token_sources() -> dict[str, Optional[str]]:
    return {
        "env": _token_from_env(),
        "file": _token_from_file(),
        "keyring": _token_from_keyring(),
    }


def get_token_source() -> Optional[str]:
    sources = inspect_token_sources()
    for name in ("env", "file", "keyring"):
        if sources.get(name):
            return name
    return None


def get_token() -> Optional[str]:
    sources = inspect_token_sources()
    return sources.get("env") or sources.get("file") or sources.get("keyring")


# Also expose as load_token() for symmetry with the save_token() API.
def load_token() -> Optional[str]:
    """Alias for get_token(). Calling this triggers legacy plaintext migration."""
    return get_token()


def save_token(token: str, force_insecure: bool = False) -> None:
    """Save token to keyring (preferred) or Fernet-encrypted file (fallback).

    Never writes plaintext to disk. Removes legacy plaintext token file if
    present.
    """
    # Backward-compat only: older call sites pass force_insecure.
    # We intentionally ignore it to avoid writing plaintext tokens.
    _ = force_insecure
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    token = str(token).strip()
    # Migrate any residual legacy plaintext file immediately.
    if _TOKEN_FILE.exists():
        try:
            _TOKEN_FILE.unlink()
        except Exception:
            pass
    _save_encrypted(token)


def delete_token() -> None:
    """Remove token from all stores: keyring, encrypted file, and legacy plaintext."""
    clear_token()


def clear_token() -> None:
    """Remove token from keyring, encrypted fallback file, and legacy plaintext file."""
    keyring_backend = _get_keyring_backend()
    if keyring_backend is not None:
        try:
            keyring_backend.delete_password(_KEYRING_SERVICE, _KEYRING_USERNAME)
        except Exception:
            pass
    if _TOKEN_ENC_FILE.exists():
        _TOKEN_ENC_FILE.unlink()
    if _TOKEN_FILE.exists():
        _TOKEN_FILE.unlink()
