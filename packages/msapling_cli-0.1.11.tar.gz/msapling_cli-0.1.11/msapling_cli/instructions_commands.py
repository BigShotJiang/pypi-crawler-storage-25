"""CLI commands for managing MSapling AI instructions (global, project, chat)."""
from __future__ import annotations

import asyncio
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.text import Text

from .api import APIError, MSaplingClient, OfflineError
from .config import get_settings, get_token
from .tui import console

instructions_app = typer.Typer(
    name="instructions",
    help="Manage AI system instructions — global, per-project, or per-chat.",
)


def _run(coro):
    return asyncio.run(coro)


def _require_auth() -> str:
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run `msapling login` first.[/red]")
        raise typer.Exit(1)
    return token


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------

@instructions_app.command("get")
def instructions_get(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name (omit for global instructions)"),
    chat: Optional[str] = typer.Option(None, "--chat", "-c", help="Chat ID (overrides --project; highest precedence)"),
    resolved: bool = typer.Option(False, "--resolved", "-r", help="Show fully resolved prompt with precedence source"),
):
    """Fetch and display AI instructions.

    With no flags: shows global instructions.
    With --project NAME: shows per-project instructions.
    With --chat ID: shows per-chat instructions.
    With --resolved --chat ID: shows resolved prompt with source annotation.
    """
    token = _require_auth()

    async def _fetch():
        async with MSaplingClient(token=token) as client:
            http = await client._get_client()

            if resolved:
                if not chat:
                    console.print("[red]--resolved requires --chat <chat_id>[/red]")
                    raise typer.Exit(1)
                resp = await http.get(f"/api/instructions/resolved", params={"chat_id": chat})
                resp.raise_for_status()
                data = resp.json()
                source = data.get("source", "none")
                prompt = data.get("prompt", "")
                color_map = {"chat": "cyan", "project": "yellow", "global": "green", "none": "dim"}
                color = color_map.get(source, "white")

                console.print(Panel(
                    prompt or "[dim](empty)[/dim]",
                    title=f"Resolved Instructions  [bold {color}][source: {source}][/bold {color}]",
                    border_style=color,
                    expand=False,
                ))
                if data.get("chat_prompt"):
                    console.print(f"  [cyan]Chat[/cyan]: {data['chat_prompt'][:80]}...")
                if data.get("project_prompt"):
                    console.print(f"  [yellow]Project[/yellow]: {data['project_prompt'][:80]}...")
                if data.get("global_prompt"):
                    console.print(f"  [green]Global[/green]: {data['global_prompt'][:80]}...")
                return

            if chat:
                resp = await http.get(f"/api/instructions/chat/{chat}")
                resp.raise_for_status()
                data = resp.json()
                level = "Chat"
                border = "cyan"
            elif project:
                resp = await http.get(f"/api/instructions/project/{project}")
                resp.raise_for_status()
                data = resp.json()
                level = f"Project: {project}"
                border = "yellow"
            else:
                resp = await http.get("/api/instructions/global")
                resp.raise_for_status()
                data = resp.json()
                level = "Global"
                border = "green"

            text = data.get("instructions", "") or ""
            console.print(Panel(
                text if text else "[dim](no instructions set)[/dim]",
                title=f"[bold]AI Instructions — {level}[/bold]",
                border_style=border,
                expand=False,
            ))

    try:
        _run(_fetch())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# set
# ---------------------------------------------------------------------------

@instructions_app.command("set")
def instructions_set(
    text: str = typer.Argument(..., help="The instruction text to set"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name (omit for global)"),
    chat: Optional[str] = typer.Option(None, "--chat", "-c", help="Chat ID (highest precedence)"),
):
    """Set AI system instructions for global, project, or chat scope.

    Examples:
        msapling instructions set "Always reply in bullet points."
        msapling instructions set "Focus on Python best practices." --project MyProject
        msapling instructions set "Be concise." --chat abc123
    """
    token = _require_auth()

    async def _set():
        async with MSaplingClient(token=token) as client:
            http = await client._get_client()
            payload = {"instructions": text.strip()}

            if chat:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch(f"/api/instructions/chat/{chat}", json=payload)
                )
                level = f"chat {chat}"
            elif project:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch(f"/api/instructions/project/{project}", json=payload)
                )
                level = f"project '{project}'"
            else:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch("/api/instructions/global", json=payload)
                )
                level = "global"

            resp.raise_for_status()
            preview = text[:80] + ("…" if len(text) > 80 else "")
            console.print(f"[green]Instructions updated[/green] ({level}): [dim]{preview}[/dim]")

    try:
        _run(_set())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------

@instructions_app.command("clear")
def instructions_clear(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name (omit for global)"),
    chat: Optional[str] = typer.Option(None, "--chat", "-c", help="Chat ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Clear AI instructions for global, project, or chat scope.

    Clearing reverts the scope to empty so the next-lower level takes effect
    (precedence: chat > project > global).
    """
    token = _require_auth()

    if chat:
        target = f"chat {chat}"
    elif project:
        target = f"project '{project}'"
    else:
        target = "global"

    if not yes:
        confirmed = Confirm.ask(f"Clear {target} instructions?", default=False)
        if not confirmed:
            console.print("[yellow]Aborted.[/yellow]")
            raise typer.Exit(0)

    async def _clear():
        async with MSaplingClient(token=token) as client:
            http = await client._get_client()
            payload = {"instructions": ""}

            if chat:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch(f"/api/instructions/chat/{chat}", json=payload)
                )
            elif project:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch(f"/api/instructions/project/{project}", json=payload)
                )
            else:
                resp = await client._request_with_csrf_retry(
                    lambda: http.patch("/api/instructions/global", json=payload)
                )

            resp.raise_for_status()
            console.print(f"[green]Instructions cleared[/green] ({target})")

    try:
        _run(_clear())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
