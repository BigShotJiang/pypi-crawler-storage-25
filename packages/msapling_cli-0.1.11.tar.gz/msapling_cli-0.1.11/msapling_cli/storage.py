﻿"""Local file storage helpers for MSapling CLI."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import sys
import tempfile
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _chmod_owner_only(path) -> None:
    """Restrict *path* to owner read/write (0o600). No-op on Windows."""
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    except OSError:
        pass

# Thread-level lock guards in-process concurrent writes.
_write_lock = threading.Lock()


@contextmanager
def _file_lock(path: Path):
    """Cross-platform advisory file lock around a write operation.

    Uses fcntl.flock on POSIX and msvcrt.locking on Windows as the
    OS-level lock, with a Python threading.Lock as an in-process guard.
    Falls back to the threading lock alone if the OS lock is unavailable.
    """
    with _write_lock:
        if sys.platform == "win32":
            try:
                import msvcrt
                # Open (or create) the lock sentinel file
                lock_path = path.with_suffix(path.suffix + ".lock")
                with open(lock_path, "a+b") as lf:
                    # Lock 1 byte at the start of the file
                    try:
                        msvcrt.locking(lf.fileno(), msvcrt.LK_LOCK, 1)
                        locked = True
                    except OSError:
                        locked = False
                    try:
                        yield
                    finally:
                        if locked:
                            lf.seek(0)
                            try:
                                msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)
                            except OSError:
                                pass
            except Exception:
                yield
        else:
            try:
                import fcntl
                lock_path = path.with_suffix(path.suffix + ".lock")
                with open(lock_path, "w") as lf:
                    try:
                        fcntl.flock(lf, fcntl.LOCK_EX)
                        yield
                    finally:
                        fcntl.flock(lf, fcntl.LOCK_UN)
            except Exception:
                yield


_ROOT = Path.home() / ".msapling"


def _ensure(*parts: str) -> Path:
    path = _ROOT.joinpath(*parts)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _legacy_project_slug(project_root: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]", "-", str(project_root).strip('/\\'))


def _project_slug(project_root: str) -> str:
    """Convert a project path to a collision-resistant slug."""
    resolved_root = str(Path(project_root).resolve())
    base = _legacy_project_slug(resolved_root).strip("-") or "project"
    digest = hashlib.sha256(resolved_root.lower().encode("utf-8")).hexdigest()[:10]
    return f"{base}-{digest}"


def _project_dirs(project_root: str) -> List[Path]:
    primary = _ROOT / "projects" / _project_slug(project_root)
    legacy = _ROOT / "projects" / _legacy_project_slug(project_root)
    dirs = [primary]
    if legacy != primary and legacy.exists():
        dirs.append(legacy)
    return dirs


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


# Settings

def load_settings() -> Dict[str, Any]:
    path = _ROOT / "settings.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "permissions": {"allow": ["read_file", "glob_files", "grep_search", "web_search"]},
        "model": "google/gemini-2.0-flash-001",
        "effortLevel": "high",
    }


def save_settings(settings: Dict[str, Any]):
    _ensure()
    path = _ROOT / "settings.json"
    # Atomic write: write to a temp file in the same directory, then rename.
    # This prevents partial/corrupt reads if two threads save concurrently.
    tmp_fd, tmp_path_str = tempfile.mkstemp(dir=str(_ROOT), suffix=".tmp")
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(settings, indent=2))
        # On Windows, os.replace() may fail with PermissionError under heavy concurrency.
        # Retry with brief backoff before propagating.
        for _attempt in range(3):
            try:
                Path(tmp_path_str).replace(path)
                _chmod_owner_only(path)
                break
            except PermissionError:
                if _attempt == 2:
                    raise
                time.sleep(0.01 * (2 ** _attempt))
    except Exception:
        try:
            Path(tmp_path_str).unlink(missing_ok=True)
        except Exception:
            pass
        raise


# History

def append_history(prompt: str, project: str, session_id: str):
    """Append a user prompt to global history."""
    _ensure()
    path = _ROOT / "history.jsonl"
    entry = {
        "display": prompt[:500],
        "timestamp": int(time.time() * 1000),
        "project": project,
        "sessionId": session_id,
    }
    with _file_lock(path):
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry) + "\n")
            handle.flush()
        _chmod_owner_only(path)


def load_history(limit: int = 50) -> List[Dict[str, Any]]:
    path = _ROOT / "history.jsonl"
    if not path.exists():
        return []
    entries = []
    try:
        for line in path.read_text(encoding="utf-8").strip().splitlines():
            if line.strip():
                entries.append(json.loads(line))
    except Exception:
        pass
    return entries[-limit:]


# Sessions

_SESSION_FORMAT_VERSION = 2


def _migrate_session_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """Migrate session data to the current format version.

    v1 (no _format_version field): strip any __internal__ keys.
    v2+: already current.
    """
    version = data.get("_format_version")
    if version is None:
        # Treat as v1: strip __internal__ keys
        data = {k: v for k, v in data.items() if not k.startswith("__internal__")}
        data["_format_version"] = _SESSION_FORMAT_VERSION
    elif version < _SESSION_FORMAT_VERSION:
        # v1 → v2: strip __internal__ keys
        data = {k: v for k, v in data.items() if not k.startswith("__internal__")}
        data["_format_version"] = _SESSION_FORMAT_VERSION
    return data


def register_session(pid: int, session_id: str, cwd: str):
    """Register an active session (file-locked to prevent concurrent corruption)."""
    _ensure("sessions")
    path = _ROOT / "sessions" / f"{pid}.json"
    payload = json.dumps({
        "_format_version": _SESSION_FORMAT_VERSION,
        "pid": pid,
        "sessionId": session_id,
        "cwd": cwd,
        "startedAt": int(time.time() * 1000),
        "kind": "interactive",
        "entrypoint": "cli",
    })
    with _file_lock(path):
        # Write atomically via a temp file in the same directory
        tmp_fd, tmp_name = tempfile.mkstemp(
            dir=path.parent, prefix=f"{pid}_", suffix=".json.tmp"
        )
        try:
            with open(tmp_fd, "w", encoding="utf-8") as fh:
                fh.write(payload)
            Path(tmp_name).replace(path)
            _chmod_owner_only(path)
        except Exception:
            try:
                Path(tmp_name).unlink(missing_ok=True)
            except Exception:
                pass
            raise


def unregister_session(pid: int):
    path = _ROOT / "sessions" / f"{pid}.json"
    if path.exists():
        path.unlink()


def list_active_sessions() -> List[Dict[str, Any]]:
    sessions_dir = _ROOT / "sessions"
    if not sessions_dir.exists():
        return []
    results = []
    for session_file in sessions_dir.glob("*.json"):
        try:
            raw = session_file.read_text(encoding="utf-8")
            data = json.loads(raw)
            migrated = _migrate_session_data(data)
            # Persist migrated data back so we don't re-migrate on every load
            if migrated.get("_format_version") != data.get("_format_version"):
                try:
                    tmp_fd, tmp_name = tempfile.mkstemp(
                        dir=session_file.parent, prefix=session_file.stem + "_", suffix=".json.tmp"
                    )
                    with open(tmp_fd, "w", encoding="utf-8") as fh:
                        fh.write(json.dumps(migrated))
                    os.replace(tmp_name, session_file)
                    _chmod_owner_only(session_file)
                except Exception:
                    pass
            results.append(migrated)
        except Exception:
            continue
    return results


# Project conversations

def append_conversation(
    project_root: str,
    session_id: str,
    msg_type: str,
    content: str,
    parent_uuid: Optional[str] = None,
    uuid_val: Optional[str] = None,
):
    """Append a message to the conversation transcript."""
    import uuid as _uuid

    slug = _project_slug(project_root)
    _ensure("projects", slug)
    path = _ROOT / "projects" / slug / f"{session_id}.jsonl"
    entry = {
        "parentUuid": parent_uuid,
        "type": msg_type,
        "message": {"role": msg_type, "content": content[:10000]},
        "uuid": uuid_val or str(_uuid.uuid4()),
        "timestamp": _utc_timestamp(),
        "sessionId": session_id,
        "cwd": project_root,
    }
    with _file_lock(path):
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry) + "\n")
            handle.flush()
        _chmod_owner_only(path)

    # Update the sessions index so list_project_sessions can avoid
    # reading every transcript file.
    _update_sessions_index(
        project_dir=_ROOT / "projects" / slug,
        session_id=session_id,
        msg_type=msg_type,
        content=content,
    )


def _update_sessions_index(
    project_dir: Path,
    session_id: str,
    msg_type: str,
    content: str,
) -> None:
    """Atomically update ``sessions_index.json`` inside *project_dir*.

    The index maps session_id -> {first_prompt, message_count, modified} so
    that ``list_project_sessions`` can read a single file instead of scanning
    every transcript.
    """
    index_path = project_dir / "sessions_index.json"

    with _file_lock(index_path):
        # Load existing index (if any)
        index: Dict[str, Any] = {}
        if index_path.exists():
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
            except Exception:
                index = {}

        entry = index.get(session_id)
        if entry is None:
            entry = {"first_prompt": "", "message_count": 0, "modified": _utc_timestamp()}

        entry["message_count"] = entry.get("message_count", 0) + 1
        entry["modified"] = _utc_timestamp()

        # Capture first user prompt if we don't have one yet
        if not entry.get("first_prompt") and msg_type == "user":
            entry["first_prompt"] = content[:80]

        index[session_id] = entry

        # Atomic write via temp file
        tmp_fd, tmp_name = tempfile.mkstemp(
            dir=str(project_dir), prefix="idx_", suffix=".json.tmp"
        )
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
                fh.write(json.dumps(index, indent=1))
            Path(tmp_name).replace(index_path)
            _chmod_owner_only(index_path)
        except Exception:
            try:
                Path(tmp_name).unlink(missing_ok=True)
            except Exception:
                pass
            raise


def _rebuild_sessions_index(project_dir: Path) -> Dict[str, Any]:
    """Full-scan fallback: rebuild the index from transcript files on disk."""
    index: Dict[str, Any] = {}
    for transcript in project_dir.glob("*.jsonl"):
        session_id = transcript.stem
        try:
            lines = transcript.read_text(encoding="utf-8").strip().splitlines()
            first_user = ""
            for line in lines:
                rec = json.loads(line)
                if rec.get("type") == "user" and not rec.get("isMeta"):
                    first_user = rec.get("message", {}).get("content", "")[:80]
                    break
            index[session_id] = {
                "first_prompt": first_user,
                "message_count": len(lines),
                "modified": datetime.fromtimestamp(
                    transcript.stat().st_mtime, tz=timezone.utc
                ).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            }
        except Exception:
            continue

    # Persist the rebuilt index so next call is fast
    try:
        index_path = project_dir / "sessions_index.json"
        tmp_fd, tmp_name = tempfile.mkstemp(
            dir=str(project_dir), prefix="idx_", suffix=".json.tmp"
        )
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(index, indent=1))
        Path(tmp_name).replace(index_path)
        _chmod_owner_only(index_path)
    except Exception:
        pass

    return index


def list_project_sessions(project_root: str) -> List[Dict[str, Any]]:
    project_dirs = [path for path in _project_dirs(project_root) if path.exists()]
    if not project_dirs:
        return []

    results = []
    seen_session_ids: set = set()

    for project_dir in project_dirs:
        index_path = project_dir / "sessions_index.json"

        # Try the fast path: read the single index file
        index: Optional[Dict[str, Any]] = None
        if index_path.exists():
            try:
                index = json.loads(index_path.read_text(encoding="utf-8"))
            except Exception:
                index = None

        # Fallback: rebuild from transcript files if index is missing/corrupt
        if index is None:
            index = _rebuild_sessions_index(project_dir)

        for session_id, meta in index.items():
            if session_id in seen_session_ids:
                continue
            seen_session_ids.add(session_id)
            # Parse ISO timestamp to a float for sorting compatibility
            modified = meta.get("modified", "")
            try:
                mtime = datetime.fromisoformat(
                    modified.replace("Z", "+00:00")
                ).timestamp()
            except Exception:
                mtime = 0.0
            results.append({
                "session_id": session_id,
                "messages": meta.get("message_count", 0),
                "first_prompt": meta.get("first_prompt", ""),
                "modified": mtime,
            })

    results.sort(key=lambda x: x["modified"], reverse=True)
    return results


# Plans

def save_plan(name: str, content: str):
    _ensure("plans")
    path = _ROOT / "plans" / f"{name}.md"
    path.write_text(content, encoding="utf-8")
    _chmod_owner_only(path)


def list_plans() -> List[str]:
    plans_dir = _ROOT / "plans"
    if not plans_dir.exists():
        return []
    return [plan.stem for plan in plans_dir.glob("*.md")]


def load_plan(name: str) -> Optional[str]:
    path = _ROOT / "plans" / f"{name}.md"
    if path.exists():
        return path.read_text(encoding="utf-8")
    return None


# File backups

def backup_file(file_path: str, content: str, session_id: str):
    """Save a backup of a file before editing."""
    _ensure("backups", session_id)
    safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", file_path)
    backup_path = _ROOT / "backups" / session_id / f"{safe_name}.{int(time.time())}"
    backup_path.write_text(content, encoding="utf-8")
    _chmod_owner_only(backup_path)
    return str(backup_path)


def list_backups(session_id: str) -> List[Dict[str, Any]]:
    backup_dir = _ROOT / "backups" / session_id
    if not backup_dir.exists():
        return []
    results = []
    for backup in sorted(backup_dir.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        results.append({
            "name": backup.name,
            "size": backup.stat().st_size,
            "time": backup.stat().st_mtime,
        })
    return results


# Cache

def cache_set(key: str, data: Any, ttl: int = 3600):
    _ensure("cache")
    path = _ROOT / "cache" / f"{key}.json"
    payload = {"data": data, "expires": time.time() + ttl}
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(payload), encoding="utf-8")
    os.replace(tmp, path)
    _chmod_owner_only(path)


def cache_get(key: str) -> Optional[Any]:
    path = _ROOT / "cache" / f"{key}.json"
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("expires", 0) < time.time():
            path.unlink()
            return None
        return payload.get("data")
    except Exception:
        return None
