"""Worker pool for MSapling CLI multi-chat.

Manages N parallel chat workers within a single project, providing:
- Worker-to-worker event notification (file write → dependents see new code)
- Conflict detection (two workers editing the same file)
- Smart task distribution (/plan --workers N auto-splits work)
- Cost ceiling enforcement across the pool
"""
from __future__ import annotations

import asyncio
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

console = Console()

# Maximum concurrent workers (matches web's 6-panel grid)
MAX_WORKERS = 6


class WorkerEvent:
    """An event that one worker broadcasts to others."""
    __slots__ = ("source", "event_type", "data", "timestamp")

    def __init__(self, source: str, event_type: str, data: Dict[str, Any]):
        self.source = source
        self.event_type = event_type  # "file_written", "task_done", "error"
        self.data = data
        self.timestamp = time.time()


class Worker:
    """A single parallel chat worker."""

    def __init__(self, name: str, chat_id: str, model: str):
        self.name = name
        self.chat_id = chat_id
        self.model = model
        self.status: str = "ready"  # ready | running | done | error
        self.messages: List[Dict[str, str]] = []
        self.cost: float = 0.0
        self.tokens: int = 0
        self.files_written: Set[str] = set()
        self.task: Optional[str] = None  # Assigned task description
        self._pending_events: List[WorkerEvent] = []
        self._events_lock = threading.Lock()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "chat_id": self.chat_id,
            "model": self.model,
            "status": self.status,
            "cost": self.cost,
            "tokens": self.tokens,
            "task": self.task,
            "messages": self.messages,
        }

    def receive_event(self, event: WorkerEvent):
        """Queue an event from another worker (thread-safe)."""
        if event.source != self.name:
            with self._events_lock:
                self._pending_events.append(event)

    def drain_events(self) -> str:
        """Consume pending events and format as context for the LLM (thread-safe)."""
        with self._events_lock:
            if not self._pending_events:
                return ""
            # Snapshot and clear atomically under the lock so concurrent
            # receive_event calls cannot interleave with the clear().
            events, self._pending_events = self._pending_events, []
        parts = []
        for ev in events:
            if ev.event_type == "file_written":
                parts.append(
                    f"[Worker '{ev.source}' just wrote {ev.data.get('path', '?')}]"
                )
            elif ev.event_type == "task_done":
                parts.append(
                    f"[Worker '{ev.source}' finished: {ev.data.get('summary', '?')}]"
                )
        return "\n".join(parts)


class WorkerPool:
    """Manages a set of parallel workers within a project."""

    def __init__(self, project_name: str, cost_ceiling: Optional[float] = None):
        self.project_name = project_name
        self.workers: List[Worker] = []
        self.cost_ceiling = cost_ceiling
        self._conflict_log: List[Dict[str, Any]] = []
        self._lock = threading.Lock()  # Thread-safe worker mutations

    @property
    def total_cost(self) -> float:
        return sum(w.cost for w in self.workers)

    @property
    def total_tokens(self) -> int:
        return sum(w.tokens for w in self.workers)

    def is_over_budget(self) -> bool:
        if self.cost_ceiling is None:
            return False
        return self.total_cost >= self.cost_ceiling

    def add_worker(self, name: str, chat_id: str, model: str) -> Worker:
        with self._lock:
            if len(self.workers) >= MAX_WORKERS:
                raise ValueError(f"Max {MAX_WORKERS} workers per project")
            w = Worker(name, chat_id, model)
            self.workers.append(w)
            return w

    def get_worker(self, name_or_index: str) -> Optional[Worker]:
        """Find worker by name or 1-based index."""
        try:
            idx = int(name_or_index) - 1
            if 0 <= idx < len(self.workers):
                return self.workers[idx]
        except ValueError:
            pass
        for w in self.workers:
            if w.name.lower() == name_or_index.lower():
                return w
        return None

    def remove_worker(self, name_or_index: str) -> Optional[Worker]:
        with self._lock:
            w = self.get_worker(name_or_index)
            if w:
                self.workers.remove(w)
            return w

    # ─── Worker-to-Worker Communication ──────────────────────────────

    def broadcast_event(self, event: WorkerEvent):
        """Send an event from one worker to all others (thread-safe)."""
        with self._lock:
            for w in self.workers:
                w.receive_event(event)

    def notify_file_written(self, source_name: str, file_path: str):
        """Notify all workers that a file was written."""
        # Hold lock for both the lookup and the mutation so no other thread
        # can remove the worker or change files_written between the two steps.
        with self._lock:
            source = self.get_worker(source_name)
            if source:
                source.files_written.add(file_path)
            # Broadcast inside the lock so the event reflects consistent state.
            for w in self.workers:
                w.receive_event(WorkerEvent(
                    source=source_name,
                    event_type="file_written",
                    data={"path": file_path},
                ))

    def notify_task_done(self, source_name: str, summary: str):
        """Notify all workers that a task completed."""
        with self._lock:
            source = self.get_worker(source_name)
            if source:
                source.status = "done"
            for w in self.workers:
                w.receive_event(WorkerEvent(
                    source=source_name,
                    event_type="task_done",
                    data={"summary": summary},
                ))

    # ─── Conflict Detection ──────────────────────────────────────────

    def check_conflicts(self) -> List[Dict[str, Any]]:
        """Detect if two or more workers wrote the same file."""
        file_to_workers: Dict[str, List[str]] = {}
        for w in self.workers:
            for f in w.files_written:
                file_to_workers.setdefault(f, []).append(w.name)

        conflicts = []
        for file_path, writers in file_to_workers.items():
            if len(writers) > 1:
                conflict = {
                    "file": file_path,
                    "workers": writers,
                    "timestamp": time.time(),
                }
                conflicts.append(conflict)
                self._conflict_log.append(conflict)
        return conflicts

    # ─── Smart Task Distribution ─────────────────────────────────────

    def distribute_tasks(self, subtasks: List[str]):
        """Assign a list of subtasks to available workers round-robin."""
        available = [w for w in self.workers if w.status in ("ready", "done")]
        if not available:
            return
        for i, task in enumerate(subtasks):
            worker = available[i % len(available)]
            worker.task = task
            worker.status = "ready"

    # ─── Display ─────────────────────────────────────────────────────

    def render_status(self) -> Table:
        """Render a Rich table showing all workers."""
        table = Table(title=f"Workers — {self.project_name}")
        table.add_column("#", style="cyan", width=3)
        table.add_column("Name", style="bold")
        table.add_column("Model")
        table.add_column("Status")
        table.add_column("Task", max_width=40)
        table.add_column("Tokens", justify="right")
        table.add_column("Cost", justify="right")

        for i, w in enumerate(self.workers, 1):
            model_short = w.model.split("/")[-1] if "/" in w.model else w.model
            status_style = {
                "ready": "yellow", "running": "green",
                "done": "cyan", "error": "red",
            }.get(w.status, "white")
            table.add_row(
                str(i), w.name, model_short,
                f"[{status_style}]{w.status}[/{status_style}]",
                (w.task or "")[:40],
                f"{w.tokens:,}",
                f"${w.cost:.4f}",
            )

        if self.cost_ceiling is not None:
            remaining = max(0, self.cost_ceiling - self.total_cost)
            table.caption = f"Budget: ${self.total_cost:.4f} / ${self.cost_ceiling:.4f} (${remaining:.4f} remaining)"

        return table
