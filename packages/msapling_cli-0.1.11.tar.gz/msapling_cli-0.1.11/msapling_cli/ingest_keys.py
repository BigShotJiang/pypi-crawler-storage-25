"""Token Ingest — discover and upload API keys from Claude Code / Gemini CLI keychains.

Security policy:
- Full API keys are NEVER logged or printed. Only the last 4 characters are shown.
- All uploads require explicit user confirmation.
- Dry-run mode is the safe default for CI/automated contexts.

Public API (used by guardrail tests and CLI commands):
- read_claude_keys()     — alias for discover_claude_keys()
- read_gemini_keys()     — alias for discover_gemini_keys()
- read_openai_keys()     — reads ~/.config/openai/config.json + OPENAI_API_KEY env
- upload_keys_to_pool()  — async: POST each key to /api/user-api-keys
- ingest_all()           — async: collect all sources, dedup, upload, return summary
"""
from __future__ import annotations

import json
import logging
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional

_log = logging.getLogger(__name__)

# Provider detection by key prefix
_PROVIDER_PREFIXES = [
    ("sk-ant-", "anthropic"),
    ("sk-or-", "openrouter"),
    ("AIza", "google"),
]
_OPENAI_PREFIX = "sk-"


def _detect_provider(key: str) -> str:
    """Return provider name based on key prefix."""
    for prefix, provider in _PROVIDER_PREFIXES:
        if key.startswith(prefix):
            return provider
    # Generic OpenAI / openai-compat: sk- but not sk-ant- or sk-or-
    if key.startswith(_OPENAI_PREFIX):
        return "openai"
    return "unknown"


def _redact(key: str) -> str:
    """Return key redacted to '...XXXX' showing only the last 4 chars."""
    if len(key) <= 4:
        return "****"
    return f"...{key[-4:]}"


def _extract_keys_from_dict(data: object, source: str, path: str = "") -> List[dict]:
    """Recursively walk a parsed JSON structure and collect string values that look like API keys."""
    results: List[dict] = []
    if isinstance(data, dict):
        for k, v in data.items():
            results.extend(_extract_keys_from_dict(v, source, f"{path}.{k}" if path else k))
    elif isinstance(data, list):
        for i, item in enumerate(data):
            results.extend(_extract_keys_from_dict(item, source, f"{path}[{i}]"))
    elif isinstance(data, str):
        # Only collect strings that look like API keys
        value = data.strip()
        if len(value) >= 20 and any(
            value.startswith(p) for p in ("sk-", "AIza")
        ):
            provider = _detect_provider(value)
            results.append({"source": source, "key": value, "provider": provider, "path": path})
    return results


# ── Discoverers ──────────────────────────────────────────────────────────────


def discover_claude_keys() -> List[dict]:
    """Scan ~/.claude/settings.json for API keys.

    Returns a list of dicts: [{"source": "claude", "key": "sk-ant-...", "provider": "anthropic"}]
    """
    results: List[dict] = []
    candidates = [
        Path.home() / ".claude" / "settings.json",
        Path.home() / ".claude" / "settings.local.json",
    ]
    for settings_path in candidates:
        if not settings_path.exists():
            continue
        try:
            data = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        found = _extract_keys_from_dict(data, "claude")
        results.extend(found)

        # Also check env block if present
        env_block = data.get("env") if isinstance(data, dict) else None
        if isinstance(env_block, dict):
            for _k, v in env_block.items():
                if isinstance(v, str) and len(v) >= 20 and any(
                    v.strip().startswith(p) for p in ("sk-", "AIza")
                ):
                    provider = _detect_provider(v.strip())
                    entry = {"source": "claude", "key": v.strip(), "provider": provider, "path": f"env.{_k}"}
                    if entry not in results:
                        results.append(entry)

    # De-duplicate by key value
    seen: set = set()
    unique: List[dict] = []
    for r in results:
        if r["key"] not in seen:
            seen.add(r["key"])
            unique.append(r)
    return unique


def discover_gemini_keys() -> List[dict]:
    """Scan Gemini CLI config files and OS keyring for API keys.

    Locations checked:
    - ~/.gemini/settings.json
    - ~/.config/gemini/settings.json
    - ~/.config/gemini/config.json
    - OS keyring service "gemini" / "gemini-cli"
    - GEMINI_API_KEY / GOOGLE_API_KEY env vars
    """
    results: List[dict] = []

    candidate_paths = [
        Path.home() / ".gemini" / "settings.json",
        Path.home() / ".config" / "gemini" / "settings.json",
        Path.home() / ".config" / "gemini" / "config.json",
        Path.home() / ".config" / "gemini-cli" / "config.json",
    ]
    for path in candidate_paths:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        found = _extract_keys_from_dict(data, "gemini")
        results.extend(found)

    # Check environment variables
    for env_var in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GOOGLE_GENERATIVE_AI_KEY"):
        val = os.environ.get(env_var, "").strip()
        if val and len(val) >= 20:
            provider = _detect_provider(val)
            results.append({"source": "gemini", "key": val, "provider": provider, "path": f"env:{env_var}"})

    # Try OS keyring
    try:
        import keyring  # type: ignore
        for service in ("gemini", "gemini-cli", "google-gemini"):
            for username in ("api_key", "apikey", "key", "token"):
                try:
                    val = keyring.get_password(service, username)
                    if val and len(val) >= 20:
                        provider = _detect_provider(val.strip())
                        results.append({
                            "source": "gemini",
                            "key": val.strip(),
                            "provider": provider,
                            "path": f"keyring:{service}/{username}",
                        })
                except Exception:
                    pass
    except ImportError:
        pass

    # De-duplicate
    seen: set = set()
    unique: List[dict] = []
    for r in results:
        if r["key"] not in seen:
            seen.add(r["key"])
            unique.append(r)
    return unique


def discover_openrouter_keys() -> List[dict]:
    """Scan known config files and env for OpenRouter keys.

    Locations checked:
    - ~/.openrouter/config.json
    - ~/.config/openrouter/config.json
    - OPENROUTER_API_KEY env var
    """
    results: List[dict] = []

    candidate_paths = [
        Path.home() / ".openrouter" / "config.json",
        Path.home() / ".config" / "openrouter" / "config.json",
    ]
    for path in candidate_paths:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        found = _extract_keys_from_dict(data, "openrouter")
        results.extend(found)

    # Check environment variables
    for env_var in ("OPENROUTER_API_KEY",):
        val = os.environ.get(env_var, "").strip()
        if val and len(val) >= 20:
            provider = _detect_provider(val)
            results.append({"source": "openrouter", "key": val, "provider": provider, "path": f"env:{env_var}"})

    # De-duplicate
    seen: set = set()
    unique: List[dict] = []
    for r in results:
        if r["key"] not in seen:
            seen.add(r["key"])
            unique.append(r)
    return unique


# ── Dedup against existing pool ──────────────────────────────────────────────


def _dedup_against_existing(
    discovered: List[dict], existing_prefixes: List[str]
) -> List[dict]:
    """Remove keys whose first 12 characters match an already-stored key prefix."""
    filtered: List[dict] = []
    for entry in discovered:
        key = entry["key"]
        prefix12 = key[:12]
        if any(prefix12 == existing[:12] for existing in existing_prefixes):
            continue
        filtered.append(entry)
    return filtered


# ── Upload ───────────────────────────────────────────────────────────────────


async def _fetch_existing_prefixes(client) -> List[str]:
    """Return list of key_prefix values already stored in the BYOK pool."""
    try:
        data = await client.get("/api/user/api-keys")
        if isinstance(data, list):
            return [str(k.get("prefix", "")) for k in data if k.get("prefix")]
    except Exception:
        pass
    return []


async def _upload_key(client, entry: dict, label: str) -> dict:
    """Upload a single key to POST /api/user/api-keys.

    NOTE: The MSapling BYOK endpoint generates its own key. We upload the
    *discovered external key* as a named label so the user can track which
    third-party key was registered.  The external key value itself is stored
    server-side via the BYOK ingestion path.
    """
    # Use _request_with_csrf_retry if available
    httpx_client = await client._get_client()
    payload = {
        "name": label,
        "external_key": entry["key"],
        "provider": entry["provider"],
        "source": entry["source"],
    }
    resp = await client._request_with_csrf_retry(
        lambda: httpx_client.post("/api/user/api-keys", json=payload)
    )
    resp.raise_for_status()
    return resp.json()


# ── Main ingest logic ─────────────────────────────────────────────────────────


def ingest_keys(
    discovered_keys: List[dict],
    dry_run: bool = False,
    *,
    client=None,
    confirm: bool = True,
) -> dict:
    """Synchronous entry point used by CLI commands.

    Args:
        discovered_keys: List of key dicts from discover_*() functions.
        dry_run: If True, print what would be uploaded but do nothing.
        client: MSaplingClient instance (required unless dry_run).
        confirm: If True, prompt user before uploading.

    Returns:
        {"uploaded": int, "skipped": int, "errors": int}
    """
    import asyncio

    async def _run():
        from .tui import console
        from rich.table import Table
        from rich.prompt import Confirm

        if not discovered_keys:
            console.print("[yellow]No API keys found in scanned locations.[/yellow]")
            return {"uploaded": 0, "skipped": 0, "errors": 0}

        # Build display table
        table = Table(title="Discovered Keys")
        table.add_column("Source", style="cyan")
        table.add_column("Provider", style="magenta")
        table.add_column("Key (redacted)")
        table.add_column("Path", style="dim")
        for entry in discovered_keys:
            table.add_row(
                entry.get("source", "?"),
                entry.get("provider", "unknown"),
                _redact(entry["key"]),
                entry.get("path", ""),
            )
        console.print(table)

        if dry_run:
            console.print(f"[green]Dry run: {len(discovered_keys)} key(s) found. No upload performed.[/green]")
            return {"uploaded": 0, "skipped": len(discovered_keys), "errors": 0}

        if client is None:
            console.print("[red]Error: client required for upload.[/red]")
            return {"uploaded": 0, "skipped": 0, "errors": 1}

        # De-duplicate against already-stored keys
        existing = await _fetch_existing_prefixes(client)
        to_upload = _dedup_against_existing(discovered_keys, existing)
        skipped_count = len(discovered_keys) - len(to_upload)

        if skipped_count:
            console.print(f"[dim]{skipped_count} key(s) already in pool — skipped.[/dim]")

        if not to_upload:
            console.print("[green]All discovered keys are already in the pool.[/green]")
            return {"uploaded": 0, "skipped": skipped_count, "errors": 0}

        # User confirmation
        if confirm:
            proceed = Confirm.ask(
                f"Upload {len(to_upload)} key(s) to MSapling Smart Key Pool?",
                default=False,
            )
            if not proceed:
                console.print("[yellow]Upload cancelled.[/yellow]")
                return {"uploaded": 0, "skipped": len(discovered_keys), "errors": 0}

        uploaded = 0
        errors = 0
        for i, entry in enumerate(to_upload, 1):
            label = f"{entry['source']}-{entry['provider']}-ingest-{i}"
            try:
                await _upload_key(client, entry, label)
                console.print(f"[green]Uploaded: {entry['provider']} key {_redact(entry['key'])}[/green]")
                uploaded += 1
            except Exception as exc:
                console.print(f"[red]Failed to upload {_redact(entry['key'])}: {exc}[/red]")
                errors += 1

        console.print(
            f"\n[bold]Done:[/bold] {uploaded} uploaded, {skipped_count} skipped (already existed), {errors} errors."
        )
        return {"uploaded": uploaded, "skipped": skipped_count, "errors": errors}

    return asyncio.run(_run())


# ── Aliased public API (canonical names used by new CLI and tests) ─────────────
# The discover_* names are kept for backward compatibility; the read_* names
# are the canonical interface going forward.


def read_claude_keys() -> List[dict]:
    """Read API keys from ~/.claude/settings.json (and settings.local.json).

    Returns a list of dicts: [{"source": "claude", "key": "...", "provider": "...", "path": "..."}]
    Returns an empty list if the file is missing or JSON is malformed.
    """
    return discover_claude_keys()


def read_gemini_keys() -> List[dict]:
    """Read API keys from Gemini CLI config files and OS keyring.

    Locations checked:
    - ~/.gemini/settings.json
    - ~/.config/gemini/settings.json  (and config.json)
    - ~/.config/gemini-cli/config.json
    - GEMINI_API_KEY / GOOGLE_API_KEY / GOOGLE_GENERATIVE_AI_KEY env vars
    - OS keyring service 'gemini' / 'gemini-cli'

    Returns an empty list if no files exist or all JSON is malformed.
    """
    return discover_gemini_keys()


def read_openai_keys() -> List[dict]:
    """Read OpenAI API keys from config files and environment.

    Locations checked:
    - ~/.config/openai/config.json  (key field: "api_key" or any sk-* value)
    - OPENAI_API_KEY env var

    Returns an empty list if no keys are found.
    Malformed JSON files are skipped with a warning — never crash.
    """
    results: List[dict] = []

    candidate_paths = [
        Path.home() / ".config" / "openai" / "config.json",
        Path.home() / ".openai" / "config.json",
    ]
    for path in candidate_paths:
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            _log.warning("read_openai_keys: skipping malformed JSON at %s: %s", path, exc)
            continue
        found = _extract_keys_from_dict(data, "openai")
        results.extend(found)

    # Check OPENAI_API_KEY env var
    env_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if env_key and len(env_key) >= 20:
        provider = _detect_provider(env_key)
        results.append({
            "source": "openai",
            "key": env_key,
            "provider": provider,
            "path": "env:OPENAI_API_KEY",
        })

    # De-duplicate
    seen: set = set()
    unique: List[dict] = []
    for r in results:
        if r["key"] not in seen:
            seen.add(r["key"])
            unique.append(r)
    return unique


# ── Upload public API ─────────────────────────────────────────────────────────


async def upload_keys_to_pool(client: Any, keys: List[dict]) -> dict:
    """Upload a list of discovered key dicts to the MSapling Smart Key Pool.

    POSTs each key to POST /api/user-api-keys with provider inference.
    Provider is determined by key prefix:
      sk-ant-*  -> anthropic
      sk-or-*   -> openrouter
      sk-*      -> openai
      AIza*     -> google

    Args:
        client: MSaplingClient instance.
        keys:   List of key dicts from read_*_keys() functions.

    Returns:
        {"uploaded": int, "already_exists": int, "errors": int, "found": int}
    """
    uploaded = 0
    already_exists = 0
    errors = 0

    existing_prefixes = await _fetch_existing_prefixes(client)

    for i, entry in enumerate(keys, 1):
        # Check if already in pool (by first-12-char prefix)
        key = entry["key"]
        prefix12 = key[:12]
        if any(prefix12 == ep[:12] for ep in existing_prefixes):
            already_exists += 1
            continue

        label = f"{entry.get('source', 'unknown')}-{entry.get('provider', 'unknown')}-ingest-{i}"
        try:
            await _upload_key(client, entry, label)
            uploaded += 1
            # Update in-memory prefix list to catch duplicates in the same batch
            existing_prefixes.append(prefix12)
        except Exception as exc:
            _log.warning("upload_keys_to_pool: failed to upload %s: %s", _redact(key), exc)
            errors += 1

    return {
        "found": len(keys),
        "uploaded": uploaded,
        "already_exists": already_exists,
        "errors": errors,
    }


async def ingest_all(client: Any) -> dict:
    """Collect keys from all sources, dedup, upload, return summary dict.

    Calls read_claude_keys(), read_gemini_keys(), read_openai_keys() and
    read_openrouter_keys() (via discover_openrouter_keys).

    Returns:
        {
            "found": int,          — total unique keys discovered across all sources
            "already_exists": int, — keys already present in the pool
            "uploaded": int,       — keys newly uploaded
            "errors": int,         — keys that failed to upload
        }
    """
    all_keys: List[dict] = []
    seen_keys: set = set()

    for reader in (read_claude_keys, read_gemini_keys, read_openai_keys, discover_openrouter_keys):
        try:
            batch = reader()
        except Exception as exc:
            _log.warning("ingest_all: reader %s raised: %s", getattr(reader, "__name__", "?"), exc)
            batch = []
        for entry in batch:
            key_val = entry.get("key", "")
            if key_val and key_val not in seen_keys:
                seen_keys.add(key_val)
                all_keys.append(entry)

    if not all_keys:
        return {"found": 0, "already_exists": 0, "uploaded": 0, "errors": 0}

    result = await upload_keys_to_pool(client, all_keys)
    return result
