"""MSapling Interactive Shell - Feature parity with Claude Code / Gemini CLI / Codex.

Provides a persistent interactive session with:
- Slash commands (/help, /model, /cost, /compact, /clear, /files, /plan, etc.)
- Local file operations (read, write, search, glob, grep)
- Terminal command execution
- Session persistence (save/resume)
- Project context auto-loading (.msapling.md)
- Cost tracking per session
- Diff mode (token-efficient output)
- Multi-model support
"""
from __future__ import annotations

import asyncio
import glob as globmod
import json
import logging
import os
import re
import shlex
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.tree import Tree

from .agent_registry import (
    configure_agent as configure_registry_agent,
    default_models_from_registry,
    list_agents as list_registry_agents,
    reload_agent_registry,
    set_agent_enabled as set_registry_agent_enabled,
)
from .fanout_governance import fanout_budget_detail, runtime_fanout_budget
from .tui import (
    console as tui_console,
    render_session_header,
    render_prompt,
    render_user_message,
    render_assistant_response,
    render_cost_footer,
    render_help,
    render_working_panel,
    status_bar,
)
from .status_bar import StatusBar, CONN_CONNECTED, CONN_DISCONNECTED, CONN_CHECKING

from . import __version__
from .api import DEFAULT_PROJECT_NAME, MSaplingClient

# ---------------------------------------------------------------------------
# Prompt-toolkit session (scroll wheel, persistent history, line-editing)
# ---------------------------------------------------------------------------
_pt_session: Optional[Any] = None
_pt_session_unavailable: bool = False


def _stdout_is_tty() -> bool:
    try:
        return bool(getattr(sys.stdout, "isatty", lambda: False)())
    except Exception:
        return False


def _get_pt_session() -> Optional[Any]:
    """Return a cached PromptSession with file history, or None if unavailable."""
    global _pt_session, _pt_session_unavailable
    if _pt_session is not None:
        return _pt_session
    if _pt_session_unavailable:
        return None
    try:
        from prompt_toolkit import PromptSession
    except Exception:
        _pt_session_unavailable = True
        return None

    history = None
    try:
        from prompt_toolkit.history import FileHistory
        history_path = Path.home() / ".msapling" / "chat_history"
        history_path.parent.mkdir(parents=True, exist_ok=True)
        history = FileHistory(str(history_path))
    except Exception:
        history = None

    try:
        _pt_session = PromptSession(history=history)
        _pt_session_unavailable = False
    except Exception:
        # In a real interactive shell, fallback to plain console input rather
        # than a DummyOutput prompt that can hide typed text.
        if _stdout_is_tty():
            _pt_session_unavailable = True
            _pt_session = None
            return None
        try:
            # Headless Windows test environments may not expose a console buffer.
            from prompt_toolkit.output import DummyOutput
            _pt_session = PromptSession(history=history, output=DummyOutput())
            _pt_session_unavailable = False
        except Exception:
            _pt_session_unavailable = True
            _pt_session = None
    return _pt_session
from .completer import setup_completion
from .config import get_settings, get_token, save_settings
from .local import detect_project_root, build_file_tree, read_files_as_context, git_status
from .memory import get_memories, add_memory, list_memories, clear_memories
from .storage import (
    register_session, unregister_session, append_history,
    append_conversation, list_project_sessions, save_plan, list_plans,
    load_plan, backup_file, load_settings as load_global_settings,
)
from .session import save_session, load_session, list_sessions, SessionMetadata
from .tier import check_tier, is_free_model
from .toast import toast
from .quality_gate import run_session_quality_gate, print_quality_gate_result
from .stream_lock import acquire_stream_lock, release_stream_lock
from .lineage_bridge import (
    record_conversation_turn as _lineage_record_conversation_turn,
    record_shell_command as _lineage_record_shell_command,
)

console = Console()
_log = logging.getLogger(__name__)

# ─── Project Instructions (.msapling.md) ──────────────────────────────

INSTRUCTION_FILES = [".msapling.md", "MSAPLING.md", "CLAUDE.md", "GEMINI.md", "AGENTS.md"]


def _load_project_instructions(project_root: str) -> str:
    """Load project instruction file (like CLAUDE.md) if present."""
    for name in INSTRUCTION_FILES:
        fpath = Path(project_root) / name
        if fpath.is_file():
            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")[:8000]
                return f"[Project instructions from {name}]\n{content}"
            except Exception:
                continue
    return ""


# ─── Slash Commands ───────────────────────────────────────────────────

SLASH_HELP = """
[bold]Session & Navigation[/bold]
  /help              Show this help
  /sidebar           Toggle sidebar panel (projects, chats, workers)
  /clear             Clear conversation history
  /compact           Summarize old messages via LLM to compress context
  /context           Show context window usage
  /save              Save session for later (local)
  /save-remote [desc] Save snapshot to MSapling backend (any-machine resume)
  /resume [id]       Resume a previous session (local)
  /resume-remote [id] Resume a server-side snapshot (list if no id given)
  /sessions          List saved sessions (project, cost, duration)
  /session-info      Show rich metadata for the current live session
  /fork              Fork current conversation into new session
  /rewind [n]        Undo last n messages (default: 2)
  /redo              Restore last rewound messages
  /copy              Copy last response to clipboard
  /export [fmt] [file]  Export conversation: md (default), html, pdf
  /restore [file]    Restore file from pre-edit backup
  /diff              Interactive git diff viewer
  /profile [name]    Load context profile (backend/frontend/cli) or list available
  /permissions ...    Manage permission mode, scope, trust, approvals, audit logs
  /quit              Exit (also: /exit, /q, Ctrl+C)

[bold]Model & Mode[/bold]
  /model <id>        Switch model (e.g. /model gpt-4o)
  /models            List available models
  /shadow [mode]     Shadow mode: on|off|toggle|status
  /filter ...        Shadow filters: add/list/remove
  AUTO_ROUTE_MODEL   Env var: pin all auto-routing to a specific model ID
                     (overrides complexity-based routing; leave unset to let
                     the shell pick haiku/sonnet/opus automatically)
  /plan              Toggle plan mode (read-only suggestions)
  /agent             Toggle agent mode (AI uses tools autonomously -- DEFAULT ON)
  /simple            Switch to simple chat mode (no tool use)
  /vim               Toggle vim-style input (multiline with Esc)
  /fast              Toggle fast/quality mode
  /effort <lvl>      Set thinking effort (low/medium/high)

[bold]File Operations[/bold]
  /files [pattern]   List files matching glob (e.g. /files **/*.py)
  /read <path>       Read file into context
  /write <path>      Write content to file (opens editor)
  /edit <path>       Edit file with AI (ask what to change)
  /grep <pattern>    Search file contents (regex)
  /mention <path>    Attach file to next message

[bold]Terminal & Git[/bold]
  /run <command>     Execute shell command
  /bridge <tool> <args...> [--timeout N] [--allow-tools]
                     Run external coding CLI (codex/claude) with transcript capture
  /git <args>        Run git command
  /diff              Show git diff
  /status            Show git status

[bold]Multi-Model[/bold]
  /multi <prompt>    Send to multiple models in parallel (Pro)
  /swarm <prompt>    Run swarm with synthesis (Pro)
  /agents ...        Manage agent registry (list/reload/enable/disable/config)
  /agent <prompt>    Spawn background subagent (Pro)

[bold]Scheduling & Automation[/bold]
  /timer <dur> <prompt>   Schedule a prompt after a delay (30s/5m/1h/2h30m)
  /timer list             Show pending timers with time remaining
  /timer cancel <id>      Cancel a pending timer
  /timer clear            Cancel all pending timers
  /repeat <prompt> [--every <dur>] [--count N | --until <time>]
                          Repeat a prompt on an interval
  /repeat stop            Stop the active repeat

[bold]Workers (Multi-Chat)[/bold]
  /workers           List active parallel workers
  /join <name|#>     Switch focus to a worker
  /broadcast <msg>   Send message to all workers
  /collect           Show last response from each worker
  /kill <name|#>     Stop and remove a worker
  /budget [amount]   Set/view cost ceiling (e.g. /budget 0.50)

[bold]Project & Account[/bold]
  /project           Show project info
  /init              Generate .msapling.md from project
  /skill list        List bundled skills from cli/skills/
  /skill load <name> Load a bundled skill into current session context
  /whoami            Show account info
  /cost              Show session cost and token usage
  /hooks             Manage lifecycle hooks
  /image <path>      Attach image to next message
  /paste             Paste image from clipboard into next message
  /paste-image       Paste image from clipboard (alias for /paste; shows vision preview)
  /attach <path>     Attach file (image or text) to next message with fuzzy path completion
  /attach list       List pending attachments
  /attach clear      Clear all pending attachments

[bold]SES Benchmark[/bold]
  /ses run --model <id> [--api-key <key>] [--hardware <label>]
                     Queue a benchmark run for a model
  /ses results <run_id>
                     View SES benchmark results by category
  /ses leaderboard   Show top 10 models on the SES leaderboard
""".strip()

# ─── Hooks System ─────────────────────────────────────────────────────
# Supported events (matching Claude Code's hook model):
#   on_session_start    — Shell starts (after auth, before input loop)
#   on_session_end      — Shell exits (before save)
#   on_before_message   — Before sending user message to LLM
#   on_after_message    — After receiving LLM response
#   on_before_tool      — Before agent executes a tool
#   on_after_tool       — After agent executes a tool
#   on_tool_failure     — When a tool execution fails
#   on_file_write       — After a file is written (by agent or /write)
#   on_file_read        — After a file is read into context
#   on_permission_ask   — When user is prompted for tool approval
#   on_model_change     — When model is switched (/model or agent model_switch)
#   on_compact           — When context is compacted (/compact)
#   on_worktree_create  — When a git worktree is created
#   on_worktree_remove  — When a git worktree is removed
#   on_subagent_start   — When a background subagent is spawned
#   on_subagent_done    — When a subagent completes
#   on_worker_spawn     — When a multi-chat worker is created
#   on_worker_kill      — When a worker is killed
#   on_instructions_loaded — When project instructions (.msapling.md) are loaded
#   on_budget_exceeded  — When cost ceiling is hit
#   on_config_change    — When a setting is changed
#   on_cwd_change       — When project root / worktree changes

HOOKS_FILE = Path.home() / ".msapling" / "hooks.json"
SKILLS_ROOT = Path(__file__).resolve().parents[1] / "skills"


_HOOK_EVENTS = [
    "on_session_start",
    "on_session_end",
    "on_before_message",
    "on_after_message",
    "on_before_tool",
    "on_tool_use",
    "on_after_tool",
    "on_tool_failure",
    "on_file_write",
    "on_file_read",
    "on_permission_ask",
    "on_compile_error",
    "on_compact",
    "on_worktree_create",
    "on_worktree_remove",
    "on_subagent_start",
    "on_subagent_done",
    "on_worker_spawn",
    "on_worker_kill",
    "on_model_change",
    "on_budget_exceeded",
    "on_instructions_loaded",
    "on_config_change",
    "on_cwd_change",
]

_HOOK_SCRIPT_EXTENSIONS = {".sh", ".py", ".bash", ".zsh", ".ps1", ".cmd", ".bat"}


def _load_hooks() -> Dict[str, List[str]]:
    """Load hooks from ~/.msapling/hooks.json, then auto-discover scripts from
    ~/.msapling/hooks/<event_name>.<ext> and merge them in.

    Auto-discovery: any executable file (or Python script) named after a known
    hook event inside ~/.msapling/hooks/ is registered automatically without
    requiring manual hooks.json registration.

    Example: ~/.msapling/hooks/on_after_message.sh → registered for on_after_message.
    """
    hooks: Dict[str, List[str]] = {}

    # 1. Load explicit registrations from hooks.json (if present).
    if HOOKS_FILE.exists():
        try:
            loaded = json.loads(HOOKS_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                hooks = {str(k): list(v) for k, v in loaded.items() if isinstance(v, list)}
        except Exception:
            pass
    else:
        # Initialise an empty template so users know the file exists.
        try:
            HOOKS_FILE.parent.mkdir(parents=True, exist_ok=True)
            HOOKS_FILE.write_text(
                json.dumps({event: [] for event in _HOOK_EVENTS}, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    # 2. Auto-discover scripts in ~/.msapling/hooks/ directory.
    hooks_dir = HOOKS_FILE.parent / "hooks"
    if hooks_dir.is_dir():
        for child in hooks_dir.iterdir():
            # Symlink containment check: skip paths that resolve outside hooks dir.
            if not child.resolve().is_relative_to(hooks_dir.resolve()):
                continue
            if child.suffix.lower() not in _HOOK_SCRIPT_EXTENSIONS:
                continue
            event_name = child.stem  # filename without extension
            if event_name not in _HOOK_EVENTS:
                continue
            # Build the invocation command.
            if child.suffix.lower() == ".py":
                cmd = f"{sys.executable} {str(child)}"
            else:
                cmd = str(child)
            # Only add if not already registered (explicit registrations take priority).
            existing = hooks.setdefault(event_name, [])
            if cmd not in existing:
                existing.append(cmd)

    # 3. Load plugin-declared hooks from ~/.msapling/plugins/*/manifest.json
    for event, commands in _load_plugin_hooks().items():
        existing = hooks.setdefault(event, [])
        for cmd in commands:
            if cmd not in existing:
                existing.append(cmd)

    return hooks


def _normalize_plugin_hook_command(raw_cmd: str, plugin_dir: Path) -> Optional[str]:
    cmd = str(raw_cmd or "").strip()
    if not cmd:
        return None
    # Shell command string (contains args/operators) — keep as-is.
    if any(ch in cmd for ch in (" ", "\t", "|", "&", ";")):
        return cmd

    try:
        plugin_root = plugin_dir.resolve()
    except Exception:
        plugin_root = plugin_dir

    candidate = Path(cmd)
    if not candidate.is_absolute():
        candidate = (plugin_root / candidate).resolve()
    try:
        if candidate.is_file() and candidate.is_relative_to(plugin_root):
            if candidate.suffix.lower() == ".py":
                return f"{sys.executable} {candidate}"
            return str(candidate)
    except Exception:
        pass
    return cmd


def _load_plugin_hooks() -> Dict[str, List[str]]:
    plugin_hooks: Dict[str, List[str]] = {}
    plugins_dir = HOOKS_FILE.parent / "plugins"
    if not plugins_dir.is_dir():
        return plugin_hooks

    for plugin_dir in sorted(plugins_dir.iterdir()):
        if not plugin_dir.is_dir():
            continue
        manifest = plugin_dir / "manifest.json"
        if not manifest.is_file():
            continue
        try:
            payload = json.loads(manifest.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        declared_hooks = payload.get("hooks")
        if not isinstance(declared_hooks, dict):
            continue
        for event, commands in declared_hooks.items():
            event_name = str(event or "").strip()
            if event_name not in _HOOK_EVENTS:
                continue
            if isinstance(commands, str):
                command_list = [commands]
            elif isinstance(commands, list):
                command_list = [item for item in commands if isinstance(item, str)]
            else:
                command_list = []
            if not command_list:
                continue
            bucket = plugin_hooks.setdefault(event_name, [])
            for raw_cmd in command_list:
                normalized = _normalize_plugin_hook_command(raw_cmd, plugin_dir)
                if normalized and normalized not in bucket:
                    bucket.append(normalized)
    return plugin_hooks


def _save_hooks(hooks: Dict[str, List[str]]):
    HOOKS_FILE.parent.mkdir(parents=True, exist_ok=True)
    HOOKS_FILE.write_text(json.dumps(hooks, indent=2), encoding="utf-8")


def _iter_bundled_skill_files() -> List[Path]:
    try:
        base = SKILLS_ROOT.resolve()
    except Exception:
        base = SKILLS_ROOT
    if not base.is_dir():
        return []
    out: List[Path] = []
    for path in sorted(base.rglob("*.md")):
        try:
            if path.is_file() and path.resolve().is_relative_to(base):
                out.append(path.resolve())
        except Exception:
            continue
    return out


def _skill_ref_from_path(path: Path) -> str:
    try:
        rel = path.resolve().relative_to(SKILLS_ROOT.resolve()).as_posix()
    except Exception:
        rel = path.name
    if rel.lower().endswith(".md"):
        rel = rel[:-3]
    return rel


def _find_bundled_skill(skill_ref: str) -> Optional[Path]:
    raw = str(skill_ref or "").strip().replace("\\", "/").lstrip("/")
    if not raw:
        return None
    if "/" not in raw:
        matches = [p for p in _iter_bundled_skill_files() if p.stem.lower() == raw.lower()]
        if len(matches) == 1:
            return matches[0]
        return None
    try:
        candidate = (SKILLS_ROOT / f"{raw}.md").resolve()
        if candidate.is_file() and candidate.is_relative_to(SKILLS_ROOT.resolve()):
            return candidate
    except Exception:
        return None
    return None


def _normalize_local_path_arg(value: str) -> str:
    raw = str(value or "").strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        raw = raw[1:-1].strip()
    return raw


def _registry_model_lane_budget() -> Dict[str, int]:
    budget: Dict[str, int] = {}
    try:
        for agent in list_registry_agents(enabled_only=True):
            model_id = str(agent.model or "").strip()
            if not model_id:
                continue
            max_parallel = max(1, int(agent.max_parallel or 1))
            budget[model_id] = budget.get(model_id, 0) + max_parallel
    except Exception:
        return {}
    return budget


def _lane_cap_violations(models: List[str]) -> List[str]:
    counts: Dict[str, int] = {}
    for model_id in models:
        counts[model_id] = counts.get(model_id, 0) + 1
    budget = _registry_model_lane_budget()
    violations: List[str] = []
    for model_id, used in sorted(counts.items()):
        allowed = int(budget.get(model_id, 1))
        if used > allowed:
            violations.append(f"{model_id}: requested={used}, allowed={allowed}")
    return violations


def _adaptive_fanout_cap(
    models: List[str],
    *,
    command_name: str,
    provider_hint: Optional[int] = None,
) -> int:
    budget = runtime_fanout_budget(provider_hint=provider_hint) if provider_hint is not None else runtime_fanout_budget()
    recommended = max(1, int(budget.get("recommended_cap") or 1))
    cap = min(recommended, max(1, len(models)))
    if len(models) > cap:
        console.print(
            f"[yellow]{command_name}: applying adaptive fanout cap {cap}/{len(models)} "
            f"({fanout_budget_detail(budget)}).[/yellow]"
        )
    return cap


# ─── Vision Preview Helper ────────────────────────────────────────────

def _to_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_model_price_per_token(model_row: Dict[str, Any], *, direction: str) -> Optional[float]:
    if direction not in {"in", "out"}:
        return None
    direct_key = "price_in" if direction == "in" else "price_out"
    for key in (f"msapling_{direct_key}", direct_key):
        value = _to_float(model_row.get(key))
        if value is not None:
            return max(0.0, value)
    pricing = model_row.get("pricing")
    if isinstance(pricing, dict):
        nested_key = "prompt" if direction == "in" else "completion"
        value = _to_float(pricing.get(nested_key))
        if value is not None:
            return max(0.0, value)
    return None


def _format_price_per_million(price_per_token: Optional[float]) -> str:
    if price_per_token is None:
        return "-"
    if price_per_token <= 0:
        return "free"
    return f"${price_per_token * 1_000_000:.3f}"


def _model_price_confirmation(model_id: str, model_row: Dict[str, Any]) -> Optional[str]:
    price_in = _extract_model_price_per_token(model_row, direction="in")
    price_out = _extract_model_price_per_token(model_row, direction="out")
    if price_in is None and price_out is None:
        return None
    return (
        f"Switched to {model_id}  |  "
        f"{_format_price_per_million(price_in)} in / "
        f"{_format_price_per_million(price_out)} out per 1M tokens"
    )


_IMAGE_EXTS = frozenset({".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff", ".tif"})
_TEXT_EXTS = frozenset({
    ".txt", ".md", ".py", ".js", ".ts", ".jsx", ".tsx", ".json", ".yaml", ".yml",
    ".toml", ".cfg", ".ini", ".env", ".sh", ".bash", ".zsh", ".html", ".css",
    ".xml", ".csv", ".rst", ".log", ".sql", ".go", ".rs", ".java", ".c", ".cpp",
    ".h", ".hpp", ".rb", ".php", ".swift", ".kt", ".r", ".m", ".tf",
})
_SHADOW_FILTER_TYPES = (
    "secret_redact",
    "syntax_check",
    "token_reduce",
    "python_check",
    "code_quality",
    "output_verify",
)
_SHADOW_MODEL_PREFIXES = ("ollama:", "api:", "mllm:", "gguf:")


def _valid_shadow_model_spec(model_spec: str) -> bool:
    lowered = model_spec.strip().lower()
    if not lowered:
        return False
    for prefix in _SHADOW_MODEL_PREFIXES:
        if lowered.startswith(prefix):
            return len(lowered) > len(prefix)
    return False


def _vision_preview(img_obj: Any, width: int = 40) -> None:
    """Render a compact terminal preview of an image.

    Attempts Rich image rendering first; falls back to printing dimensions.
    ``img_obj`` may be a PIL Image instance or a ``pathlib.Path``.
    """
    try:
        from PIL import Image as _PILImage
        if isinstance(img_obj, Path):
            pil_img = _PILImage.open(img_obj)
        else:
            pil_img = img_obj
        w, h = pil_img.size
        try:
            # Rich >= 13 supports console.print(rich.image.Image(...))
            from rich.image import Image as RichImage
            rich_img: Any
            if isinstance(img_obj, Path):
                rich_img = RichImage(str(img_obj), width=width)
            else:
                import io as _io
                buf = _io.BytesIO()
                pil_img.save(buf, format="PNG")
                buf.seek(0)
                rich_img = RichImage.from_url("data:image/png;base64," + __import__("base64").b64encode(buf.getvalue()).decode(), width=width)
            console.print(rich_img)
        except Exception:
            pass  # Rich image rendering not available — fall through to text preview
        console.print(f"[dim]  [Image: {w}x{h}px][/dim]")
    except ImportError:
        console.print("[dim]  [Image preview requires Pillow][/dim]")
    except Exception:
        console.print("[dim]  [Preview unavailable][/dim]")


def _grab_clipboard_image() -> Any:
    """Grab an image from the system clipboard.

    Returns a PIL Image on success, None if no image is available.
    Raises ImportError if Pillow is not installed.
    Raises RuntimeError for platform-specific failures.
    """
    if sys.platform == "win32" or sys.platform == "darwin":
        from PIL import ImageGrab  # type: ignore
        return ImageGrab.grabclipboard()
    else:
        # Linux: use xclip / xsel / wl-paste to read clipboard PNG bytes
        from PIL import Image as _PILImage  # type: ignore
        import io as _io
        for cmd in (
            ["xclip", "-selection", "clipboard", "-t", "image/png", "-o"],
            ["xsel", "--clipboard", "--output"],
            ["wl-paste", "--type", "image/png"],
        ):
            try:
                result = subprocess.run(cmd, capture_output=True, timeout=3)
                if result.returncode == 0 and result.stdout:
                    return _PILImage.open(_io.BytesIO(result.stdout))
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return None


def _fuzzy_suggest_paths(base: str, fragment: str, n: int = 3) -> List[str]:
    """Return up to ``n`` close filename matches under ``base`` for ``fragment``."""
    import difflib
    base_path = Path(base)
    fragment_lower = fragment.lower()
    candidates: List[str] = []
    try:
        for p in base_path.rglob("*"):
            if p.is_file():
                candidates.append(str(p.relative_to(base_path)))
    except Exception:
        pass
    # Match against the fragment (basename or full relative path)
    matches = difflib.get_close_matches(fragment_lower, [c.lower() for c in candidates], n=n, cutoff=0.4)
    # Map back to original casing
    lower_to_orig = {c.lower(): c for c in candidates}
    return [lower_to_orig[m] for m in matches if m in lower_to_orig]


def _safe_path(project_root: str, rel_path: str) -> Optional[Path]:
    """Resolve a path and verify it stays within the project root."""
    import re as _re
    # Reject shell injection patterns (consistent with agent.py's _safe_path)
    _SHELL_INJECTION = _re.compile(r'(\$\(|\$\{|\$[A-Za-z_]|`|%[A-Za-z_][A-Za-z0-9_]*%|\\\\\\\\|^//)')
    if _SHELL_INJECTION.search(rel_path):
        return None
    try:
        resolved = (Path(project_root) / _normalize_local_path_arg(rel_path)).resolve()
        root_resolved = Path(project_root).resolve()
        if resolved == root_resolved or resolved.is_relative_to(root_resolved):
            return resolved
    except Exception:
        pass
    return None


def _parse_menu_number(choice: str, action: str, *, allow_bare_number: bool = False) -> Optional[int]:
    """Parse menu actions like `R 1`, `R1`, `R<1>`, or bare `1`."""
    cleaned = str(choice or "").strip().upper()
    if not cleaned:
        return None
    if allow_bare_number and cleaned.isdigit():
        value = int(cleaned)
        return value if value > 0 else None
    match = re.fullmatch(rf"{re.escape(action.upper())}\s*<?\s*(\d+)\s*>?", cleaned)
    if not match:
        return None
    value = int(match.group(1))
    return value if value > 0 else None


# ─── Auto-Routing ─────────────────────────────────────────────────────

# Keywords that indicate a complex task requiring a capable model.
_COMPLEX_KEYWORDS = frozenset({
    "implement", "refactor", "debug", "analyze", "analyse",
    "design", "architect", "optimize", "optimise", "migrate",
    "rewrite", "review",
})

# Greeting / simple-question patterns.
_SIMPLE_PATTERN = re.compile(
    r"^(hi|hello|hey|thanks|thank you|ok|okay|yes|no|sure|please|"
    r"what is|what's|who is|who's|how do|when|where|why)\b",
    re.IGNORECASE,
)


def _classify_complexity(message: str) -> str:
    """Classify message complexity as 'simple', 'medium', or 'complex'.

    Rules (checked in order):
    - "complex": code fences present, >200 chars, or contains a complex keyword.
    - "simple":  <50 chars or matches a greeting/simple-question pattern.
    - "medium":  everything else.
    """
    stripped = message.strip()
    lower = stripped.lower()

    # Complex signals take highest priority.
    if "```" in stripped:
        return "complex"
    if len(stripped) > 200:
        return "complex"
    words = re.findall(r"[a-zA-Z]+", lower)
    if any(w in _COMPLEX_KEYWORDS for w in words):
        return "complex"

    # Simple signals.
    if len(stripped) < 50:
        return "simple"
    if _SIMPLE_PATTERN.match(stripped):
        return "simple"

    return "medium"


def _get_routed_model(complexity: str) -> Optional[str]:
    """Return the model to use for *this request* based on complexity.

    Priority:
    1. ``AUTO_ROUTE_MODEL`` env var — if set, always use it (kill-switch).
    2. complexity → model family:
       - "simple"  → haiku (cheapest / fastest)
       - "complex" → opus  (most capable)
       - "medium"  → sonnet (balanced default)
    Returns None when no routing decision can be made.

    Environment variables
    ---------------------
    ``AUTO_ROUTE_MODEL``
        Override all auto-routing logic and always route to this model ID.
        Set to a full model ID (e.g. ``anthropic/claude-3-5-sonnet``) to
        pin every request regardless of detected complexity.
    """
    # Kill-switch: pin to a specific model unconditionally.
    env_override = os.environ.get("AUTO_ROUTE_MODEL", "").strip()
    if env_override:
        return env_override

    if complexity == "simple":
        # Prefer claude-haiku variants; fall back to generic haiku label.
        return "anthropic/claude-haiku-4-5"
    if complexity == "complex":
        return "anthropic/claude-opus-4-5"
    # medium — use default sonnet; return None so the caller keeps its model.
    return None


def _run_hooks(event: str, hooks: Dict[str, List[str]], cwd: str) -> List[str]:
    """Run hooks for a lifecycle event. Returns list of outputs."""
    outputs = []
    for cmd in hooks.get(event, []):
        try:
            cmd_parts = shlex.split(cmd, posix=(sys.platform != "win32"))
            try:
                result = subprocess.run(
                    cmd_parts, shell=False, cwd=cwd,
                    capture_output=True, text=True, timeout=10,
                )
            except FileNotFoundError:
                # Windows shell builtins (e.g. "echo") are not standalone
                # executables; retry via cmd so simple hook commands still work.
                if sys.platform == "win32":
                    result = subprocess.run(
                        ["cmd", "/c", cmd], shell=False, cwd=cwd,
                        capture_output=True, text=True, timeout=10,
                    )
                else:
                    raise
            if result.returncode != 0:
                stderr_msg = (result.stderr or "").strip()
                console.print(
                    f"[yellow]⚠ Hook '{cmd}' exited with code {result.returncode}"
                    + (f": {stderr_msg}" if stderr_msg else "")
                    + "[/yellow]"
                )
                _log.warning(
                    "Hook returned non-zero exit code",
                    extra={"hook_event": event, "hook_cmd": cmd,
                           "exit_code": result.returncode, "stderr": stderr_msg},
                )
            if result.stdout.strip():
                outputs.append(result.stdout.strip())
        except Exception as exc:
            console.print(f"[yellow]⚠ Hook '{cmd}' failed: {exc}[/yellow]")
            _log.warning(
                "Hook execution error: %s", exc,
                extra={"hook_event": event, "hook_cmd": cmd},
                exc_info=True,
            )
    return outputs


def _bridge_default_log_path(session_id: str, tool_name: str) -> Path:
    stamp = int(time.time())
    base = Path.home() / ".msapling" / "bridges" / session_id
    base.mkdir(parents=True, exist_ok=True)
    safe_tool = re.sub(r"[^a-zA-Z0-9._-]", "_", tool_name.strip() or "tool")
    return base / f"{stamp}_{safe_tool}.log"


def _write_bridge_transcript(
    *,
    out_path: Path,
    tool_name: str,
    argv: List[str],
    cwd: str,
    return_code: Optional[int],
    status: str,
    stdout_text: str,
    stderr_text: str,
) -> None:
    lines = [
        f"tool: {tool_name}",
        f"status: {status}",
        f"return_code: {return_code if return_code is not None else ''}",
        f"cwd: {cwd}",
        f"argv: {' '.join(argv)}",
        "",
        "=== STDOUT ===",
        stdout_text or "",
        "",
        "=== STDERR ===",
        stderr_text or "",
        "",
    ]
    out_path.write_text("\n".join(lines), encoding="utf-8")


def _parse_bridge_args(raw_args: str) -> Dict[str, Any]:
    parts = shlex.split(raw_args, posix=(sys.platform != "win32"))
    if not parts:
        raise ValueError("Usage: /bridge <codex|claude> <args...> [--timeout N] [--allow-tools]")

    tool = parts[0].strip()
    timeout_s = 300.0
    allow_tools = False
    cli_args: List[str] = []
    i = 1
    while i < len(parts):
        token = parts[i]
        if token == "--timeout":
            if i + 1 >= len(parts):
                raise ValueError("--timeout requires a value in seconds.")
            try:
                timeout_s = float(parts[i + 1])
            except ValueError as exc:
                raise ValueError("--timeout must be a numeric value.") from exc
            i += 2
            continue
        if token == "--allow-tools":
            allow_tools = True
            i += 1
            continue
        cli_args.append(token)
        i += 1

    if timeout_s <= 0:
        raise ValueError("--timeout must be > 0.")
    return {
        "tool": tool,
        "timeout_s": timeout_s,
        "allow_tools": allow_tools,
        "cli_args": cli_args,
    }


class _HookRunner:
    """Adapter exposing the ``run(...)`` hook interface expected by agent.py."""

    def __init__(self, hooks: Dict[str, List[str]], get_cwd):
        self._hooks = hooks
        self._get_cwd = get_cwd

    def run(self, event: str, cwd: Optional[str] = None, **_kwargs) -> List[str]:
        target_cwd = str(cwd or self._get_cwd() or ".")
        return _run_hooks(event, self._hooks, target_cwd)


# --- BM25 Session Search ------------------------------------------------------

def _sessions_search(query: str, limit: int = 10) -> list:
    """Search saved sessions using the BM25Index from session_search module.

    Returns list of SearchResult objects (session_id, title, project, score,
    matched_snippet).  Falls back gracefully if the module is unavailable.
    """
    try:
        from .session_search import build_default_index
        index = build_default_index()
        return index.search(query, top_k=limit)
    except Exception as exc:
        _log.debug("BM25 session search failed: %s", exc)
        return []



class InteractiveShell:
    """Persistent interactive shell for MSapling CLI.

    On startup, requires user to select a project and chat mode (single or
    multi-chat up to 6 parallel workers).  Same limits as the web UI.
    """

    # Hardcoded limits — must match backend config.py
    MAX_CHATS_PER_PROJECT = 6
    FREE_MAX_CHATS = 2

    def __init__(self, model=None, project=None, session_id=None, resume_id=None, ephemeral: bool = False):
        settings = get_settings()
        self.model = model or settings.default_model
        self.project_root, self.project_info = detect_project_root(".")
        self.project_name = project  # Set during startup flow (None = ask user)
        self.session_id = session_id or str(uuid.uuid4())[:12]
        self.chat_id: Optional[str] = None  # Active chat (server-side)
        self.ephemeral = ephemeral  # If True, chat is hidden from web/app sidebar
        self.messages: List[Dict[str, str]] = []
        self._rewind_buffer: List[Dict[str, str]] = []  # Stores messages removed by /rewind
        self.cost_total = 0.0
        self.tokens_total = 0
        self.plan_mode = False
        self.vim_mode = False
        self.fast_mode = False
        self.effort = "high"
        self.pending_attachments: List[Dict[str, str]] = []
        self.hooks = _load_hooks()
        self.hook_runner = _HookRunner(self.hooks, lambda: self.project_root)
        self.loaded_skills: List[str] = []
        self.workers: List[Dict[str, Any]] = []  # Parallel chat workers
        self.subagents: List[Dict[str, Any]] = []  # Background subagents
        self.cost_ceiling: Optional[float] = None  # Max $ for this session (None = no limit)
        self.agent_mode = True
        self.permission_persist_scope: str = "workspace"  # workspace or user
        self.client = MSaplingClient()
        set_session_id = getattr(self.client, "set_session_id", None)
        if callable(set_session_id) and not asyncio.iscoroutinefunction(set_session_id):
            try:
                set_session_id(self.session_id)
            except Exception:
                pass
        self.user: Dict[str, Any] = {}
        self._completer = None
        self._resume_id = resume_id
        # MCP client manager — lazy import so it doesn't affect startup time
        self._mcp_manager = None
        # ── Session metadata tracking ──
        self._session_start_time: float = time.time()
        self.models_used: List[str] = [self.model] if self.model else []
        self.files_touched: List[str] = []
        self.commands_run: List[str] = []
        self.slash_commands_used: List[str] = []  # every /command dispatched
        self.turn_count: int = 0  # user LLM turns (non-slash messages)
        self.tokens_in: int = 0   # estimated input tokens
        self.tokens_out: int = 0  # estimated output tokens
        # ── Scheduled timers (/timer command) ──
        self._scheduled_timers: Dict[str, asyncio.Task] = {}  # id -> Task
        self._timer_meta: Dict[str, Dict[str, Any]] = {}      # id -> {prompt, delay, fire_at}
        # ── Active repeats (/repeat command) ──
        self._active_repeats: List[asyncio.Task] = []
        # ── TUI status bar ──
        self.no_tui: bool = False  # set True via --no-tui CLI flag
        self._status_bar: StatusBar = StatusBar(self)
        # ── Sidebar ──
        self._sidebar_visible: bool = False
        # ── Offline / Ollama failover ──
        self._backend_reachable: bool = True   # updated by _check_backend_health()
        self._ollama_active: bool = False       # True while routed to local Ollama
        self._pre_failover_model: Optional[str] = None  # model before handover
        from .offline_queue import OfflineTokenAccumulator
        self._offline_accumulator: OfflineTokenAccumulator = OfflineTokenAccumulator()
        self._model_catalog: Dict[str, Dict[str, Any]] = {}
        self.shadow_mode: bool = False
        self.shadow_filters: List[Dict[str, Any]] = []
        self._next_shadow_filter_id: int = 1

    # ─── Startup Flow ────────────────────────────────────────────────

    async def start(self):
        """Main entry: authenticate, select project, select chat mode, then run."""
        token = get_token()
        if not token:
            console.print("[red]Not logged in. Run: msapling login[/red]")
            return
        try:
            self.user = await self.client.me()
        except Exception as e:
            console.print(f"[red]Auth failed: {e}[/red]")
            return

        tier = self.user.get("tier", "free")
        credits = self.user.get("fuel_credits", 0)
        is_paid = tier in ("pro", "monthly", "lifetime") or self.user.get("is_pro")

        console.print()
        console.print(f"[bold]  * MSapling CLI[/bold] [dim]v{__version__}[/dim]")
        console.print(f"  [dim]Logged in:[/dim] {self.user.get('email', '?')} [dim]({tier}, ${credits:.4f} fuel)[/dim]")
        console.print(f"  [dim]Type /help for commands, Tab to autocomplete, /quit to exit.[/dim]")
        console.print()

        # If resuming a saved session, skip the selection flow
        if self._resume_id:
            await self._resume_session()
        else:
            # ── Step 1: Select or create project ──
            selected = await self._select_project(is_paid)
            if selected is None:
                return  # User quit

            # ── Step 2: Select chat mode ──
            started = await self._select_chat_mode(selected, is_paid)
            if not started:
                return  # User quit

        # ── Load context ──
        instructions = _load_project_instructions(self.project_root)
        if instructions:
            self.messages.append({"role": "system", "content": instructions})
            _run_hooks("on_instructions_loaded", self.hooks, self.project_root)

        memories = get_memories(self.project_root)
        if memories:
            self.messages.append({"role": "system", "content": memories})

        # ── Load precompact snapshot for this session ────────────────────────
        try:
            from .precompact_hook import load_latest_precompact, format_for_injection
            _pc_snapshot = load_latest_precompact(self.session_id)
            if _pc_snapshot is not None:
                _pc_injection = format_for_injection(_pc_snapshot)
                if _pc_injection:
                    _log.debug("precompact snapshot loaded for session %s", self.session_id)
        except Exception as _pc_load_exc:
            _log.debug("load_latest_precompact failed (non-fatal): %s", _pc_load_exc)

        # ── Inject session-start context (precompact + recent sessions) ──────
        try:
            from .session_start_hook import (
                load_session_start_context,
                inject_into_system_prompt,
            )
            _ssc = load_session_start_context(self.session_id, self.project_root)
            if not _ssc.is_empty():
                # Build the opening system prompt (instructions already appended above;
                # we prepend the continuity block to any existing system messages).
                _combined = inject_into_system_prompt("", _ssc)
                if _combined:
                    self.messages.append({"role": "system", "content": _combined})
                    console.print("[dim][Context loaded from previous session][/dim]")
        except Exception as _ssc_exc:
            _log.debug("session_start_hook load failed (non-fatal): %s", _ssc_exc)

        # Session header
        worker_count = len(self.workers)
        mode_desc = f"{worker_count} workers" if worker_count > 1 else "single chat"
        render_session_header(
            model=self.model,
            tier=tier,
            credits=credits,
            project=self.project_name or "~",
            agent_mode=self.agent_mode,
            instructions_loaded=bool(instructions),
            memories_loaded=bool(memories),
        )
        if worker_count > 1:
            console.print(f"  [bold cyan]{worker_count} parallel workers active[/bold cyan]  [dim]type /workers to see status[/dim]")
            console.print()

        # Reset agent tool permissions at session start (security)
        from .agent import reset_permissions
        reset_permissions()

        register_session(os.getpid(), self.session_id, self.project_root)
        self._completer = setup_completion(project_root=self.project_root)

        for out in _run_hooks("on_session_start", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")

        # ── Start sticky status bar (TTY only) ────────────────────────────
        self._status_bar.update(connected=CONN_CONNECTED)
        # Keep prompt/input rendering stable in Windows terminals by avoiding
        # concurrent rich.Live redraws while typing.
        if _get_pt_session() is None and os.name != "nt":
            self._status_bar.start()
        else:
            _log.debug("status bar disabled for interactive prompt rendering")

        await self._main_loop()

        # ── Stop status bar before cleanup output ─────────────────────────
        self._status_bar.stop()

        for out in _run_hooks("on_session_end", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")
        self._cancel_all_timers()
        self._cancel_all_repeats()
        self._save()
        try:
            import asyncio as _aio
            async def _snap():
                snap_payload = {
                    "session_id": self.session_id,
                    "project_name": self.project_name or "",
                    "model": self.model,
                    "messages": self.messages[-50:],  # last 50 messages
                    "tokens_total": self.tokens_total,
                    "cost_total": self.cost_total,
                }
                await self.client._request("POST", "/api/snapshots", json=snap_payload)
            _aio.get_event_loop().run_until_complete(_snap())
            console.print("[dim][Session snapshot saved to server][/dim]")
        except Exception:
            pass  # best-effort
        self._write_session_state()
        # ── Stop quality gate ──────────────────────────────────────────────
        _touched = self._extract_files_from_messages()
        if _touched:
            try:
                _qg_result = run_session_quality_gate(_touched)
                print_quality_gate_result(_qg_result)
                if _qg_result.dirty:
                    console.print(
                        "[bold red]Session marked DIRTY — fix quality issues before promoting[/bold red]"
                    )
            except Exception as _qg_exc:
                _log.warning("Quality gate error (non-fatal): %s", _qg_exc)
        # ──────────────────────────────────────────────────────────────────
        unregister_session(os.getpid())
        console.print("[ms.dim]Session saved. Resume with: msapling shell --resume[/ms.dim]")
        await self.client.close()

    async def _select_project(self, is_paid: bool) -> Optional[Dict[str, Any]]:
        """Interactive project selection. Returns project dict or None to quit."""
        try:
            overview = await self.client.projects_overview(self.user)
        except Exception as e:
            console.print(f"[red]Failed to load projects: {e}[/red]")
            return None

        projects = overview.get("projects", [])
        project_limit = overview.get("project_limit", 10)
        can_create = overview.get("can_create_project", True)

        console.print(f"  [bold]Your Projects[/bold] [dim]({len(projects)}/{project_limit}):[/dim]")
        console.print()
        for i, p in enumerate(projects, 1):
            name = p["name"]
            count = p["chat_count"]
            limit = p["chat_limit"]
            full_tag = "  [red][FULL][/red]" if p["is_full"] else ""
            console.print(f"    [cyan]{i}.[/cyan] {name}  [dim]{count}/{limit} chats[/dim]{full_tag}")

        console.print()
        if can_create:
            console.print("    [cyan]N.[/cyan] New project")
        console.print("    [cyan]Q.[/cyan] Quit")
        console.print()

        while True:
            try:
                choice = console.input("  [bold]Select:[/bold] ").strip().upper()
            except (KeyboardInterrupt, EOFError):
                return None

            if choice == "Q":
                return None

            if choice == "N":
                if not can_create:
                    console.print(f"  [yellow]Project limit reached ({project_limit} max).[/yellow]")
                    continue
                try:
                    name = console.input("  [bold]Project name:[/bold] ").strip()
                except (KeyboardInterrupt, EOFError):
                    return None
                if not name:
                    continue
                try:
                    result = await self.client.create_project(name)
                    self.project_name = name
                    return {"name": name, "chat_count": 0, "chat_limit": self.MAX_CHATS_PER_PROJECT if is_paid else self.FREE_MAX_CHATS, "is_full": False, "chats": []}
                except Exception as e:
                    console.print(f"  [red]{e}[/red]")
                    continue

            try:
                idx = int(choice) - 1
                if 0 <= idx < len(projects):
                    selected = projects[idx]
                    self.project_name = selected["name"]
                    # Fetch existing chats for this project
                    try:
                        chats = await self.client.list_project_chats(selected["name"])
                        selected["chats"] = chats
                    except Exception:
                        selected["chats"] = []
                    return selected
            except ValueError:
                pass
            console.print("  [yellow]Invalid choice.[/yellow]")

    async def _select_chat_mode(self, project: Dict[str, Any], is_paid: bool) -> bool:
        """After project is selected, pick resume/single/multi chat. Returns False to quit."""
        chats = project.get("chats", [])
        chat_count = project.get("chat_count", len(chats))
        chat_limit = project.get("chat_limit", self.MAX_CHATS_PER_PROJECT)
        free_slots = max(0, chat_limit - chat_count)

        console.print()
        console.print(f"  [bold]{self.project_name}[/bold] [dim]({chat_count}/{chat_limit} chats):[/dim]")
        console.print()

        if chats:
            for i, c in enumerate(chats, 1):
                title = c.get("title", c.get("slot_label", "Chat"))
                model = c.get("model", "?")
                model_short = model.split("/")[-1] if "/" in model else model
                console.print(f"    [cyan]{i}.[/cyan] {title}  [dim]({model_short})[/dim]")
            console.print()

        console.print(f"  [dim]{free_slots} slot(s) free[/dim]")
        console.print()
        console.print("  [bold]Options:[/bold]")
        if chats:
            console.print("    [cyan]R <#>[/cyan]       Resume existing chat")
        if free_slots > 0:
            console.print("    [cyan]S[/cyan]           New single chat")
            if is_paid and free_slots >= 2:
                max_w = min(free_slots, 6)
                console.print(f"    [cyan]M <2-{max_w}>[/cyan]      New multi-chat (parallel workers)")
        if chats:
            console.print("    [cyan]D <#>[/cyan]       Delete chat to free slot")
        console.print("    [cyan]B[/cyan]           Back to projects")
        console.print()

        while True:
            try:
                choice = console.input("  [bold]Select:[/bold] ").strip().upper()
            except (KeyboardInterrupt, EOFError):
                return False

            if choice == "B":
                return False

            # Resume existing chat
            resume_number = _parse_menu_number(choice, "R", allow_bare_number=True)
            if resume_number is not None and chats:
                idx = resume_number - 1
                if 0 <= idx < len(chats):
                    c = chats[idx]
                    self.chat_id = c.get("id")
                    self.model = c.get("model", self.model)
                    console.print(f"  [green]Resumed: {c.get('title', 'Chat')}[/green]")
                    return True
                console.print("  [yellow]Invalid chat number.[/yellow]")
                continue
            if choice == "R" or (choice.startswith("R") and chats):
                console.print("  [yellow]Usage: R <number>[/yellow]")
                continue

            # New single chat
            if choice == "S":
                if free_slots <= 0:
                    console.print("  [yellow]No free slots. Delete a chat first.[/yellow]")
                    continue
                try:
                    _create_kwargs: Dict[str, Any] = dict(
                        project_name=self.project_name,
                        title=f"cli:{os.environ.get('COMPUTERNAME', 'shell')}",
                        model=self.model,
                        client_type="cli",
                    )
                    if self.ephemeral:
                        _create_kwargs["hidden"] = True
                    result = await self.client.create_chat(**_create_kwargs)
                    self.chat_id = result["chat_id"]
                    console.print(f"  [green]Created: {result.get('title', 'CLI Chat')}[/green]")
                    return True
                except Exception as e:
                    console.print(f"  [red]{e}[/red]")
                    continue

            # Multi-chat workers
            multi_number = _parse_menu_number(choice, "M")
            if choice == "M" or multi_number is not None:
                if not is_paid:
                    console.print("  [yellow]Multi-chat requires Pro tier.[/yellow]")
                    continue
                count = multi_number if multi_number is not None else 2
                if choice.startswith("M") and multi_number is None and choice != "M":
                    console.print("  [yellow]Usage: M <number>[/yellow]")
                    continue
                if count < 2:
                    count = 2
                if count > free_slots:
                    console.print(f"  [yellow]Only {free_slots} slot(s) free. Max M {free_slots}.[/yellow]")
                    continue
                if count > 6:
                    console.print("  [yellow]Max 6 parallel chats.[/yellow]")
                    continue
                # Create workers
                await self._setup_workers(count)
                if self.workers:
                    self.chat_id = self.workers[0]["chat_id"]
                    self.model = self.workers[0]["model"]
                    return True
                continue

            # Delete chat
            delete_number = _parse_menu_number(choice, "D")
            if delete_number is not None and chats:
                idx = delete_number - 1
                if 0 <= idx < len(chats):
                    c = chats[idx]
                    try:
                        await self.client.delete_chat(c["id"])
                        title = c.get("title", "Chat")
                        console.print(f"  [green]Deleted: {title}[/green]")
                        chats.pop(idx)
                        chat_count -= 1
                        free_slots += 1
                    except Exception as e:
                        console.print(f"  [red]{e}[/red]")
                else:
                    console.print("  [yellow]Invalid chat number.[/yellow]")
                continue
            if choice == "D" or (choice.startswith("D") and chats):
                console.print("  [yellow]Usage: D <number>[/yellow]")
                continue

            console.print("  [yellow]Invalid choice.[/yellow]")

    async def _setup_workers(self, count: int):
        """Create N worker chats interactively."""
        from .completer import resolve_model
        self.workers = []
        for i in range(1, count + 1):
            console.print(f"  [cyan]Worker {i}/{count}:[/cyan]")
            try:
                name = console.input(f"    Name: ").strip() or f"worker-{i}"
                model_input = console.input(f"    Model [{self.model}]: ").strip()
            except (KeyboardInterrupt, EOFError):
                break
            if model_input:
                resolved, _ = resolve_model(model_input)
            else:
                resolved = self.model
            try:
                result = await self.client.create_chat(
                    self.project_name,
                    title=f"worker:{name}",
                    model=resolved,
                    client_type="cli-worker",
                )
                self.workers.append({
                    "name": name,
                    "chat_id": result["chat_id"],
                    "model": resolved,
                    "status": "ready",
                    "messages": [],
                    "cost": 0.0,
                    "tokens": 0,
                })
                console.print(f"    [green]Created worker:{name} ({resolved.split('/')[-1]})[/green]")
            except Exception as e:
                console.print(f"    [red]Failed: {e}[/red]")
                break
        if self.workers:
            console.print(f"  [green]{len(self.workers)} workers ready.[/green]")

    async def _resume_session(self):
        """Resume a saved session by ID."""
        sessions = list_sessions()
        target = None
        try:
            idx = int(self._resume_id) - 1
            if 0 <= idx < len(sessions):
                target = sessions[idx]
        except ValueError:
            for s in sessions:
                if s["id"] == self._resume_id or s["id"].startswith(self._resume_id):
                    target = s
                    break
        if target:
            self.session_id = target["id"]
            self.client.set_session_id(self.session_id)
            self.messages = target.get("messages", [])
            self.model = target.get("model", self.model)
            self.cost_total = target.get("cost_total", 0)
            self.tokens_total = target.get("tokens_total", 0)
            self.project_name = target.get("metadata", {}).get("project_name") or self.project_name
            self.chat_id = target.get("metadata", {}).get("chat_id")
            if target.get("project_root"):
                self.project_root = target["project_root"]
            n = len(self.messages)
            console.print(f"  [green]Resumed session {self.session_id} ({n} messages)[/green]")
            # Best-effort: clear any stale lock from a crashed prior session
            if self.chat_id:
                asyncio.ensure_future(self.client.force_release_lock(self.chat_id))
        else:
            console.print("  [yellow]Session not found, starting fresh.[/yellow]")

    # ─── Main Input Loop ─────────────────────────────────────────────

    def _is_chat_locked_error(self, exc: Exception) -> bool:
        status_code = getattr(exc, "status_code", None)
        if status_code == 423:
            return True
        response = getattr(exc, "response", None)
        return getattr(response, "status_code", None) == 423

    def _get_permission_context(self, role: str = "coordinator", correlation_id: Optional[str] = None) -> Dict[str, Any]:
        """Generate a permission context for the current shell state."""
        worker_name = "coordinator"
        worker_role = role
        for worker in self.workers:
            if worker.get("chat_id") == self.chat_id:
                worker_name = str(worker.get("name") or "worker")
                worker_role = "worker"
                break
        return {
            "role": worker_role,
            "name": worker_name,
            "chat_id": self.chat_id or "",
            "source": "shell",
            "approval_scope": getattr(self, "permission_persist_scope", "workspace"),
            "correlation_id": correlation_id or uuid.uuid4().hex[:12],
        }

    async def _provider_fanout_hint(self) -> Optional[int]:
        try:
            data = await self.client.get_active_streams()
        except Exception:
            return None
        if not isinstance(data, dict):
            return None
        try:
            limit = int(data.get("limit") or 0)
            active = int(data.get("active_stream_count") or 0)
        except (TypeError, ValueError):
            return None
        if limit <= 0:
            return None
        return max(1, min(8, limit - active))

    def _cache_model_catalog(self, models: List[Dict[str, Any]]) -> None:
        catalog: Dict[str, Dict[str, Any]] = {}
        for row in models:
            if not isinstance(row, dict):
                continue
            model_id = str(row.get("id", row.get("model_id", ""))).strip()
            if not model_id:
                continue
            catalog[model_id] = row
        if catalog:
            self._model_catalog = catalog

    async def _ensure_model_catalog(self) -> None:
        if self._model_catalog:
            return
        get_models = getattr(self.client, "get_models", None)
        if not callable(get_models):
            return
        try:
            models = await get_models()
        except Exception:
            return
        if isinstance(models, list):
            self._cache_model_catalog(models)

    def _render_shadow_filters(self) -> None:
        if not self.shadow_filters:
            console.print("[dim]No shadow filters configured. Use /filter add <type> <model>[/dim]")
            return
        table = Table(title="Shadow Filters")
        table.add_column("ID", style="cyan", justify="right")
        table.add_column("Type")
        table.add_column("Model")
        table.add_column("Enabled", justify="center")
        for row in self.shadow_filters:
            table.add_row(
                str(row.get("id", "?")),
                str(row.get("type", "")),
                str(row.get("model", "")),
                "yes" if row.get("enabled", True) else "no",
            )
        console.print(table)

    async def _wait_for_lock_retry(self, attempt: int, wait_seconds: int = 10) -> None:
        """Print a clear countdown message while waiting between lock retries.

        Shows remaining wait seconds so the user knows the shell is alive and
        recoverable, not frozen.  After the wait, if the total time blocked
        exceeds 60 s the user also gets a suggestion to switch chats.
        """
        if not hasattr(self, "_lock_wait_start") or self._lock_wait_start is None:
            self._lock_wait_start = time.monotonic()

        retry_num = attempt + 1  # 1-based for display
        console.print(
            f"[yellow][Stream Locked] This chat is active in another session. "
            f"Retrying in {wait_seconds}s... (Ctrl+C to cancel) "
            f"[attempt {retry_num}/3][/yellow]"
        )

        # Countdown display
        for remaining in range(wait_seconds, 0, -1):
            try:
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                raise
            except KeyboardInterrupt:
                console.print("\n[dim]Lock wait cancelled.[/dim]")
                raise

        # After enough time, suggest switching chats
        elapsed = time.monotonic() - self._lock_wait_start
        if elapsed > 60:
            console.print(
                "[dim]  You have been waiting >60s. "
                "Consider '/new' to start a fresh chat.[/dim]"
            )

    def _reset_lock_wait(self) -> None:
        """Reset lock-wait timer after a successful send."""
        self._lock_wait_start = None

    async def _recover_locked_chat(self) -> bool:
        original_project = self.project_name or DEFAULT_PROJECT_NAME
        original_chat_id = self.chat_id
        candidates = [original_project]
        if DEFAULT_PROJECT_NAME not in candidates:
            candidates.append(DEFAULT_PROJECT_NAME)
        errors = []
        for project_name in candidates:
            try:
                result = await self.client.create_chat(
                    project_name,
                    title=f"cli:{os.environ.get('COMPUTERNAME', 'shell')}",
                    model=self.model,
                    client_type="cli",
                )
                self.chat_id = result["chat_id"]
                self.project_name = project_name
                if project_name == original_project:
                    console.print("[yellow]Stream lock: chat already active in another session. Switched to a fresh chat.[/yellow]")
                    console.print("[dim]  Tip: run /unlock to force-release if no other session is streaming.[/dim]")
                else:
                    console.print(f"[yellow]Current chat is locked and {original_project} had no recovery slot; switched to {project_name} and retrying.[/yellow]")
                    console.print("[dim]  Tip: run /unlock to force-release if no other session is streaming.[/dim]")
                return True
            except Exception as recovery_exc:
                errors.append(f"{project_name}: {recovery_exc}")
        self.chat_id = original_chat_id
        self.project_name = original_project
        console.print(f"[red]Stream lock stuck — auto-recovery failed: {'; '.join(errors)}[/red]")
        console.print("[dim]  Try: /unlock  or  msapling doctor  to diagnose the issue.[/dim]")
        return False

    async def _main_loop(self):
        """Main input loop after project/chat selection."""
        while True:
            try:
                if self.vim_mode:
                    console.print("[dim](vim mode: empty line to send)[/dim]")
                    lines = []
                    while True:
                        try:
                            line = console.input("[bold green]| [/bold green]")
                        except KeyboardInterrupt:
                            # Ctrl+C in vim mode: cancel current input, don't break outer loop
                            lines = []
                            console.print("\n[dim]Cancelled.[/dim]")
                            break
                        if line.strip() == ".":
                            lines = []
                            break
                        if line == "":
                            break
                        lines.append(line)
                    prompt = "\n".join(lines)
                else:
                    _model_str = f"({self.model}) " if getattr(self, "model", None) else ""
                    _pt = _get_pt_session()
                    if _pt is not None:
                        # prompt_toolkit: scroll wheel, persistent history, full line-editing
                        prompt = await _pt.prompt_async(f"{_model_str}> ")
                    else:
                        _model_label = f"[dim]{self.model}[/dim] " if getattr(self, "model", None) else ""
                        # Pause live footer while waiting for user input so the
                        # prompt remains anchored and typed text stays visible.
                        status_bar_was_active = bool(getattr(self._status_bar, "_active", False))
                        if status_bar_was_active:
                            self._status_bar.stop()
                        try:
                            prompt = console.input(f"{_model_label}{render_prompt()}")
                        finally:
                            if status_bar_was_active:
                                self._status_bar.start()
            except (KeyboardInterrupt, EOFError):
                break

            prompt = prompt.strip()
            if not prompt:
                continue
            # Allow bare quit aliases without leading slash
            if prompt.lower() in ("q", "quit", "exit"):
                break
            if prompt.startswith("/"):
                should_continue = await self._handle_slash(prompt)
                if not should_continue:
                    break
                continue
            await self._chat(prompt)

    def _total_session_cost(self) -> float:
        """Total cost across main chat + all workers."""
        worker_cost = sum(w.get("cost", 0.0) for w in self.workers)
        return self.cost_total + worker_cost

    def _check_cost_ceiling(self) -> bool:
        """Returns True if under budget, False if ceiling hit."""
        if self.cost_ceiling is None:
            return True
        if self._total_session_cost() >= self.cost_ceiling:
            console.print(f"[red]Cost ceiling reached (${self.cost_ceiling:.4f}). Use /budget to adjust.[/red]")
            _run_hooks("on_budget_exceeded", self.hooks, self.project_root)
            return False
        return True

    def _record_usage(self, tokens: int, cost: float):
        self.tokens_total += int(tokens)
        self.cost_total += float(cost)

    # --- Context Usage Tracking ---

    # Known context window sizes per model family (token counts)
    _CTX_LIMITS = {
        "claude-3": 200000,
        "claude-3-5": 200000,
        "claude-3-7": 200000,
        "claude-opus": 200000,
        "claude-sonnet": 200000,
        "claude-haiku": 200000,
        "gpt-4o": 128000,
        "gpt-4": 128000,
        "gpt-3.5": 16000,
        "gemini-1.5": 1000000,
        "gemini-2": 1000000,
        "gemini-flash": 1000000,
        "default": 128000,
    }

    def _get_context_limit(self) -> int:
        """Return the context window token limit for the active model."""
        model_lower = (self.model or "").lower()
        for key, limit in self._CTX_LIMITS.items():
            if key in model_lower:
                return limit
        return self._CTX_LIMITS["default"]

    def _estimate_context_tokens(self) -> int:
        """Estimate total tokens used across all messages using len(text) / 3.3."""
        total_chars = sum(len(m.get("content", "")) for m in self.messages)
        return int(total_chars / 3.3)

    def _check_context_usage_warning(self) -> None:
        """After each LLM response, emit a warning if context usage crosses 50/75/90%.

        Uses token estimation: len(text) / 3.3 for each message.
        Tracks cumulative tokens across the session. Warnings emitted only
        once per threshold crossing to avoid spam.
        """
        estimated_tokens = self._estimate_context_tokens()
        max_ctx = self._get_context_limit()
        if max_ctx <= 0:
            return
        usage_pct = estimated_tokens / max_ctx * 100

        # Thresholds in descending order — emit highest new warning only
        thresholds = [
            (90, "[bold red][Context: 90% — WARNING] Context nearly full. Next message may fail.[/bold red]"),
            (75, "[yellow][Context: 75%] Consider summarizing or starting fresh.[/yellow]"),
            (50, "[dim][Context: 50%] Half your context window is used.[/dim]"),
        ]
        already_warned = getattr(self, "_ctx_warned_pcts", set())
        for threshold, message in thresholds:
            if usage_pct >= threshold and threshold not in already_warned:
                console.print(message)
                already_warned.add(threshold)
                break  # Only show the highest new threshold per call
        self._ctx_warned_pcts = already_warned

    async def _chat(self, prompt: str):
        """Send a message and stream the response."""
        self.turn_count += 1  # count every user LLM turn
        if not self._check_cost_ceiling():
            return
        allowed, msg = check_tier(self.user, "chat", self.model)
        if not allowed:
            console.print(f"[yellow]{msg}[/yellow]")
            return

        if self.plan_mode:
            prompt = "[PLAN MODE - suggest only]\n" + prompt

        # ── Auto-routing: pick the right model tier for this message ──
        _complexity = _classify_complexity(prompt)
        _routed = _get_routed_model(_complexity)
        _effective_model = self.model  # model used for this request only
        if _routed and _routed != self.model:
            console.print(f"[dim][Auto-routing to {_routed}][/dim]")
            _effective_model = _routed

        # Auto-checkpoint when user says "implement" or "start implementing"
        _lp = prompt.lower()
        if any(kw in _lp for kw in ("implement", "start implementing")):
            try:
                import time as _time
                from .checkpoint import CheckpointManager as _CPM
                _cp_mgr = _CPM(repo_root=self.project_root)
                if _cp_mgr._is_git_repo():
                    _auto_label = f"auto-{int(_time.time())}"
                    _cp_result = _cp_mgr.create(_auto_label)
                    if _cp_result["ok"]:
                        console.print(f"[dim][auto-checkpoint] {_cp_result['tag']}[/dim]")
            except Exception:
                pass  # Silent fail — never interrupt the chat flow

        if self.pending_attachments:
            att = "\n\n".join(
                f"[Attached: {a['name']}]\n```\n{a['content']}\n```"
                for a in self.pending_attachments
            )
            prompt = prompt + "\n\n" + att
            n_att = len(self.pending_attachments)
            console.print(f"[dim]Attached {n_att} file(s)[/dim]")
            self.pending_attachments.clear()

        # --- MBrain recall injection ---
        # If the user's message references past sessions, prepend a context block.
        try:
            from .mbrain_integration import should_inject_context, build_sync_from_config
            if should_inject_context(prompt):
                _mbrain = build_sync_from_config()
                if _mbrain is not None:
                    _ctx = _mbrain.get_session_context(prompt)
                    if _ctx:
                        prompt = _ctx + "\n\n" + prompt
                        console.print("[dim][mbrain] Past session context injected[/dim]")
        except Exception:
            pass  # Never interrupt the chat flow

        for out in _run_hooks("on_before_message", self.hooks, self.project_root):
            console.print(f"[dim][hook] {out}[/dim]")

        if self.agent_mode:
            from .agent import run_agent_loop, get_and_clear_switched_model

            for attempt in range(3):
                messages_before = list(self.messages)
                try:
                    worker_name = "coordinator"
                    worker_role = "coordinator"
                    for worker in self.workers:
                        if worker.get("chat_id") == self.chat_id:
                            worker_name = str(worker.get("name") or "worker")
                            worker_role = "worker"
                            break

                    def _on_usage(tokens: int, cost: float):
                        self.tokens_total += tokens
                        self.cost_total += cost

                    response = await run_agent_loop(
                        client=self.client,
                        prompt=prompt,
                        model=_effective_model,
                        project_root=self.project_root,
                        messages=self.messages,
                        on_text=lambda text: None,
                        on_usage=_on_usage,
                        project_name=self.project_name or "",
                        chat_id=self.chat_id or "",
                        hooks_mgr=self.hook_runner,
                        permission_context=self._get_permission_context(),
                    )
                    if response:
                        render_assistant_response(response)
                        # Only persist history after confirmed server response.
                        append_history(prompt, self.project_root, self.session_id)
                        append_conversation(self.project_root, self.session_id, "user", prompt)
                        append_conversation(self.project_root, self.session_id, "assistant", response)
                        await _lineage_record_conversation_turn(
                            session_id=self.session_id,
                            role="user",
                            content=prompt,
                            project_name=self.project_name or self.project_root,
                            metadata={"chat_id": self.chat_id or ""},
                        )
                        await _lineage_record_conversation_turn(
                            session_id=self.session_id,
                            role="assistant",
                            content=response,
                            project_name=self.project_name or self.project_root,
                            metadata={"chat_id": self.chat_id or ""},
                        )
                    render_cost_footer(self.tokens_total, self.cost_total)
                    _fuel = self.user.get("fuel_credits", 0)
                    console.print(f"[dim]Credits: {_fuel:.2f}[/dim]")
                    self._check_context_usage_warning()
                    _run_hooks("on_after_message", self.hooks, self.project_root)
                    # Update status bar with latest token count and credits
                    self._status_bar.update(
                        tokens=self.tokens_total,
                        connected=CONN_CONNECTED,
                        credits=self.user.get("fuel_credits", 0),
                    )

                    new_model = get_and_clear_switched_model()
                    if new_model:
                        self.model = new_model
                        self._track_model(new_model)
                        console.print(f"[dim]Agent switched model to: {new_model}[/dim]")
                    self._reset_lock_wait()
                    return
                except Exception as e:
                    self.messages = messages_before
                    if self._is_chat_locked_error(e):
                        if attempt < 2:
                            try:
                                await self._wait_for_lock_retry(attempt, wait_seconds=10)
                            except (KeyboardInterrupt, asyncio.CancelledError):
                                console.print("[dim]Lock wait cancelled by user.[/dim]")
                                self._reset_lock_wait()
                                return
                            continue
                        # attempt == 2: hard failure path
                        self._reset_lock_wait()
                        console.print(
                            "[yellow][Stream Locked] Chat appears stuck after 3 retries. "
                            "Use '/unlock' to force-release or '/new' to start a fresh chat.[/yellow]"
                        )
                        if await self._recover_locked_chat():
                            continue
                    console.print(f"[red]Agent error: {e}[/red]")
                    return

        for attempt in range(3):
            messages_before = list(self.messages)
            self.messages.append({"role": "user", "content": prompt})

            history_to_send = self.messages[-20:]
            if self.chat_id:
                try:
                    server_history = await self.client.get_chat_history(self.chat_id, limit=20)
                    if server_history:
                        history_to_send = server_history
                except Exception:
                    pass

            # ── Process-level stream lock (Task 3) ────────────────────
            _stream_chat_id = self.chat_id or self.session_id
            _lock_err = acquire_stream_lock(_stream_chat_id)
            if _lock_err:
                console.print(f"[yellow]{_lock_err}[/yellow]")
                return

            try:
                parts = []
                thinking_parts = []
                started_at = time.monotonic()
                # Progress bar shown while waiting for the first chunk to arrive.
                _stream_progress = self._show_progress("Waiting for response…")
                _stream_progress_task: Optional[Any] = None

                # Accumulators for extended chunk types.
                _cap_status: Optional[dict] = None
                _vision_tokens: int = 0
                _vision_images: int = 0
                _artifacts: list = []

                def _render_stream_state():
                    if parts:
                        return Markdown("".join(parts))
                    detail = "".join(thinking_parts) if thinking_parts else None
                    return render_working_panel("Thinking", time.monotonic() - started_at, detail=detail)

                with _stream_progress:
                    _stream_progress_task = _stream_progress.add_task(
                        "Waiting for response…", total=None
                    )

                    # Collect the stream; progress stops on first content chunk.
                    _first_chunk = True
                    _live_ctx: Optional[Any] = None

                    async def _do_stream_inner():
                        nonlocal _first_chunk, _live_ctx, _cap_status, _vision_tokens, _vision_images
                        async for chunk in self.client.stream_chat(
                            chat_id=_stream_chat_id,
                            prompt=prompt,
                            model=_effective_model,
                            project_name=self.project_name,
                            history=history_to_send,
                        ):
                            # Guard: NDJSON spec guarantees objects, but defensive
                            # check prevents AttributeError if backend sends a list,
                            # null, or bare string as a JSON line.
                            if not isinstance(chunk, dict):
                                _log.debug("stream: skipping non-dict chunk: %r", chunk)
                                continue
                            content = chunk.get("content", "")
                            chunk_type = chunk.get("type", "")

                            # ── thinking ──────────────────────────────────
                            if chunk_type == "thinking" or chunk.get("thinking"):
                                thinking_text = chunk.get("thinking", content)
                                if thinking_text:
                                    thinking_parts.append(thinking_text)
                                continue

                            # ── usage ─────────────────────────────────────
                            if chunk_type == "usage" or chunk.get("usage"):
                                usage = chunk.get("usage", {})
                                self.tokens_total += usage.get("total_tokens", 0)
                                self.cost_total += float(chunk.get("cost", 0))
                                continue

                            # ── cap_status ────────────────────────────────
                            if chunk_type == "cap_status":
                                _cap_status = chunk
                                continue

                            # ── vision_usage ──────────────────────────────
                            if chunk_type == "vision_usage":
                                _vision_tokens += int(chunk.get("vision_tokens", 0))
                                _vision_images += int(chunk.get("image_count", 0))
                                continue

                            # ── artifact ──────────────────────────────────
                            if chunk_type == "artifact":
                                _artifacts.append(chunk)
                                continue

                            # ── tool_use (stream-side, not agent-loop) ────
                            if chunk_type == "tool_use":
                                tool_name = chunk.get("name", "unknown")
                                status = chunk.get("status", "")
                                _log.debug("stream tool_use: %s status=%s", tool_name, status)
                                if status == "running":
                                    console.print(f"[dim]⚡ {tool_name} running…[/dim]")
                                continue

                            # ── error ─────────────────────────────────────
                            if chunk_type == "error":
                                err_msg = chunk.get("error", "Unknown stream error")
                                console.print(f"[red]Stream error: {err_msg}[/red]")
                                continue

                            # ── content (default) ─────────────────────────
                            if content:
                                parts.append(content)
                            # Unknown chunk types are silently skipped.

                    await _do_stream_inner()

                # Progress context has exited (transient=True cleans up the bar).
                # Now render the full streamed response.
                if thinking_parts:
                    thinking_text_full = "".join(thinking_parts)
                    if len(thinking_text_full) > 200:
                        console.print(Panel(
                            f"[dim italic]{thinking_text_full[:500]}{'...' if len(thinking_text_full) > 500 else ''}[/dim italic]",
                            title="[dim]Thinking[/dim]",
                            border_style="dim",
                        ))

                response = "".join(parts)
                if response:
                    self.messages.append({"role": "assistant", "content": response})
                    # Only persist history after confirmed server response.
                    append_history(prompt, self.project_root, self.session_id)
                    append_conversation(self.project_root, self.session_id, "user", prompt)
                    append_conversation(self.project_root, self.session_id, "assistant", response)
                    await _lineage_record_conversation_turn(
                        session_id=self.session_id,
                        role="user",
                        content=prompt,
                        project_name=self.project_name or self.project_root,
                        metadata={"chat_id": self.chat_id or ""},
                    )
                    await _lineage_record_conversation_turn(
                        session_id=self.session_id,
                        role="assistant",
                        content=response,
                        project_name=self.project_name or self.project_root,
                        metadata={"chat_id": self.chat_id or ""},
                    )
                    # Render with diff detection if applicable.
                    self._render_diff(response)
                    render_cost_footer(self.tokens_total, self.cost_total)
                    # vision_usage footer supplement
                    if _vision_tokens > 0:
                        console.print(
                            f"[dim]Vision: {_vision_images} image(s)  ·  {_vision_tokens:,} tokens[/dim]"
                        )
                    _fuel = self.user.get("fuel_credits", 0)
                    console.print(f"[dim]Credits: {_fuel:.2f}[/dim]")
                    # cap_status quota line — use `is not None` so zero-value
                    # quota (exhausted) still renders rather than being silenced
                    # by a falsy check.
                    if _cap_status is not None:
                        _msgs_rem = _cap_status.get("messages_remaining")
                        _tok_today = _cap_status.get("tokens_used_today", 0)
                        _cred_rem = _cap_status.get("credits_remaining")
                        _msgs_str = str(_msgs_rem) if _msgs_rem is not None else "?"
                        _cred_str = f"${float(_cred_rem):.2f}" if _cred_rem is not None else "?"
                        console.print(
                            f"[dim]Remaining: {_msgs_str} msgs  ·  "
                            f"{int(_tok_today):,} tokens today  ·  "
                            f"{_cred_str} credits[/dim]"
                        )
                    # artifact summary
                    if _artifacts:
                        _art_count = len(_artifacts)
                        _art_paths = [a.get("path", "") for a in _artifacts if a.get("path")]
                        _art_label = _art_paths[0] if _art_paths else "artifact"
                        console.print(
                            f"[dim][{_art_count} artifact{'s' if _art_count > 1 else ''} — {_art_label}][/dim]"
                        )
                    self._check_context_usage_warning()
                    # Update status bar with latest token count and credits
                    self._status_bar.update(
                        tokens=self.tokens_total,
                        connected=CONN_CONNECTED,
                        credits=self.user.get("fuel_credits", 0),
                    )
                else:
                    console.print("[yellow]No response[/yellow]")
                self._reset_lock_wait()
                return
            except Exception as e:
                self.messages = messages_before
                if self._is_chat_locked_error(e):
                    if attempt < 2:
                        try:
                            await self._wait_for_lock_retry(attempt, wait_seconds=10)
                        except (KeyboardInterrupt, asyncio.CancelledError):
                            console.print("[dim]Lock wait cancelled by user.[/dim]")
                            self._reset_lock_wait()
                            release_stream_lock(_stream_chat_id)
                            return
                        continue
                    # attempt == 2: hard failure path
                    self._reset_lock_wait()
                    console.print(
                        "[yellow][Stream Locked] Chat appears stuck after 3 retries. "
                        "Use '/unlock' to force-release or '/new' to start a fresh chat.[/yellow]"
                    )
                    if await self._recover_locked_chat():
                        continue
                console.print(f"[red]{type(e).__name__}: {e}[/red]")
                return
            finally:
                release_stream_lock(_stream_chat_id)

    # ─── Offline / Ollama Failover ───────────────────────────────────

    async def _check_backend_health(self) -> bool:
        """Probe the backend health endpoint.  Returns True if reachable."""
        try:
            resp = await self.client.get("/health")
            if isinstance(resp, dict):
                return resp.get("status") in ("ok", "healthy", True)
            return True
        except Exception:
            return False

    def _get_ollama_url(self) -> Optional[str]:
        """Return the configured local Ollama URL, or None if not set."""
        return (
            os.environ.get("MSAPLING_OLLAMA_URL")
            or os.environ.get("VITE_MLLM_LOCAL_URL")
        )

    def _get_ollama_model(self) -> str:
        """Return the Ollama model to fall back to."""
        return os.environ.get("MSAPLING_OLLAMA_MODEL", "llama3")

    def _engage_ollama_failover(self) -> bool:
        """Switch to local Ollama if configured.  Returns True if handover succeeded."""
        from .offline_queue import OFFLINE_HANDOVER_KEY
        ollama_url = self._get_ollama_url()
        if not ollama_url:
            return False
        ollama_model = self._get_ollama_model()
        old_model = self.model
        self._pre_failover_model = old_model
        self._ollama_active = True
        self._backend_reachable = False
        self.model = ollama_model
        _log.warning(
            OFFLINE_HANDOVER_KEY,
            extra={"old_model": old_model, "new_model": ollama_model},
        )
        console.print(
            Panel(
                f"[bold yellow]⚡ Backend unreachable — switching to local Ollama model[/bold yellow]\n"
                f"[dim]old_model:[/dim] {old_model}  →  [dim]new_model:[/dim] {ollama_model}\n"
                f"[dim]Tokens will be recorded locally and reported when backend restores.[/dim]",
                border_style="yellow",
                title="[yellow]Offline Failover[/yellow]",
            )
        )
        return True

    async def _restore_from_failover(self) -> None:
        """Restore original model and drain the offline token accumulator."""
        from .offline_queue import ONLINE_RESTORE_KEY
        if not self._ollama_active:
            return
        self._ollama_active = False
        self._backend_reachable = True
        old_model = self.model
        if self._pre_failover_model:
            self.model = self._pre_failover_model
            self._pre_failover_model = None
        _log.info(
            ONLINE_RESTORE_KEY,
            extra={"old_model": old_model, "new_model": self.model},
        )
        console.print(
            f"[bold green]✓ Backend restored — switching back to {self.model}[/bold green]"
        )
        # Drain any accumulated offline tokens
        pending = self._offline_accumulator.pending_count()
        if pending > 0:
            console.print(f"[dim]Reporting {pending} offline token record(s)…[/dim]")
            try:
                reported = await self._offline_accumulator.drain_and_report(self.client)
                if reported > 0:
                    console.print(f"[dim]✓ {reported} record(s) synced to server.[/dim]")
            except Exception as exc:
                _log.warning("OFFLINE_DRAIN_FAIL: %s", exc)

    # ─── Timer / Repeat helpers ──────────────────────────────────────

    @staticmethod
    def _parse_duration(s: str) -> Optional[float]:
        """Parse a human duration string into seconds.

        Supported formats: 30s, 5m, 1h, 2h30m, 90, 1h15m30s
        Returns None if the string is unparseable.
        """
        s = s.strip().lower()
        if not s:
            return None
        # Bare integer → seconds
        if s.isdigit():
            return float(s)
        total = 0.0
        pattern = re.compile(r"(\d+(?:\.\d+)?)\s*([hms]?)")
        pos = 0
        matched_any = False
        for m in pattern.finditer(s):
            if m.start() != pos:
                return None  # unexpected chars between tokens
            value = float(m.group(1))
            unit = m.group(2)
            if unit == "h":
                total += value * 3600
            elif unit == "m":
                total += value * 60
            elif unit == "s" or unit == "":
                total += value
            else:
                return None
            pos = m.end()
            matched_any = True
        if pos != len(s):
            return None
        return total if matched_any else None

    @staticmethod
    def _format_duration(seconds: float) -> str:
        """Format a duration in seconds to a human-readable string."""
        seconds = max(0.0, seconds)
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        parts = []
        if h:
            parts.append(f"{h}h")
        if m:
            parts.append(f"{m}m")
        if s or not parts:
            parts.append(f"{s}s")
        return "".join(parts)

    @staticmethod
    def _parse_until_time(s: str) -> Optional[float]:
        """Parse a 'until' time string into an absolute epoch timestamp.

        Accepts: 5pm, 17:00, 5:30pm, 17:30
        Returns None if the string is unparseable.
        """
        import datetime as _dt
        s = s.strip().lower()
        now = _dt.datetime.now()
        # Try common patterns
        patterns = [
            (re.compile(r"^(\d{1,2}):(\d{2})(am|pm)$"), "hm_ampm"),
            (re.compile(r"^(\d{1,2})(am|pm)$"), "h_ampm"),
            (re.compile(r"^(\d{1,2}):(\d{2})$"), "hm_24"),
        ]
        for rx, kind in patterns:
            m = rx.match(s)
            if not m:
                continue
            if kind == "hm_ampm":
                hour = int(m.group(1))
                minute = int(m.group(2))
                ampm = m.group(3)
                if ampm == "pm" and hour != 12:
                    hour += 12
                elif ampm == "am" and hour == 12:
                    hour = 0
            elif kind == "h_ampm":
                hour = int(m.group(1))
                ampm = m.group(2)
                minute = 0
                if ampm == "pm" and hour != 12:
                    hour += 12
                elif ampm == "am" and hour == 12:
                    hour = 0
            else:  # hm_24
                hour = int(m.group(1))
                minute = int(m.group(2))
            try:
                target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            except ValueError:
                return None  # e.g. hour=25 is invalid
            if target <= now:
                target += _dt.timedelta(days=1)
            return target.timestamp()
        return None

    def _cancel_all_timers(self) -> None:
        """Cancel all pending timer tasks."""
        for tid, task in list(self._scheduled_timers.items()):
            task.cancel()
        self._scheduled_timers.clear()
        self._timer_meta.clear()

    def _cancel_all_repeats(self) -> None:
        """Cancel all active repeat tasks."""
        for task in self._active_repeats:
            task.cancel()
        self._active_repeats.clear()

    async def _run_timer(self, timer_id: str, delay: float, prompt: str) -> None:
        """Background coroutine: sleep then execute prompt."""
        try:
            await asyncio.sleep(delay)
        except asyncio.CancelledError:
            return
        meta = self._timer_meta.pop(timer_id, {})
        self._scheduled_timers.pop(timer_id, None)
        console.print(f"\n[bold cyan][Timer fired][/bold cyan] Running: '{prompt}'")
        await self._chat(prompt)

    async def _run_repeat(self, prompt: str, interval: float, max_count: Optional[int],
                          until_ts: Optional[float]) -> None:
        """Background coroutine: run prompt at intervals."""
        import datetime as _dt
        count = 0
        while True:
            count += 1
            label = f"{count}/{max_count}" if max_count is not None else str(count)
            console.print(f"\n[bold cyan][Repeat {label}][/bold cyan] Running: '{prompt}'")
            try:
                await self._chat(prompt)
            except Exception as exc:
                console.print(f"[red][Repeat] Error: {exc}[/red]")
            # Check stop conditions
            if max_count is not None and count >= max_count:
                console.print(f"[dim][Repeat] Completed {count} iteration(s).[/dim]")
                break
            if until_ts is not None and _dt.datetime.now().timestamp() >= until_ts:
                console.print("[dim][Repeat] Until-time reached. Stopping.[/dim]")
                break
            try:
                await asyncio.sleep(interval)
            except asyncio.CancelledError:
                console.print("[dim][Repeat] Stopped.[/dim]")
                return
        # Remove self from active repeats list
        current = asyncio.current_task()
        if current in self._active_repeats:
            self._active_repeats.remove(current)

    async def _cmd_timer(self, args: str) -> None:
        """Handle /timer command."""
        sub_parts = args.split(None, 1)
        sub = sub_parts[0].lower() if sub_parts else ""
        rest = sub_parts[1] if len(sub_parts) > 1 else ""

        if sub == "list":
            if not self._scheduled_timers:
                console.print("[dim]No pending timers.[/dim]")
                return
            table = Table(title="Pending Timers")
            table.add_column("ID", style="cyan")
            table.add_column("Prompt")
            table.add_column("Fires in", justify="right")
            import time as _time
            now_ts = _time.time()
            for tid, meta in self._timer_meta.items():
                remaining = max(0.0, meta["fire_at"] - now_ts)
                table.add_row(tid, meta["prompt"][:60], self._format_duration(remaining))
            console.print(table)
            return

        if sub == "cancel":
            tid = rest.strip()
            if not tid:
                console.print("[yellow]Usage: /timer cancel <id>[/yellow]")
                return
            if tid in self._scheduled_timers:
                self._scheduled_timers[tid].cancel()
                self._scheduled_timers.pop(tid, None)
                self._timer_meta.pop(tid, None)
                console.print(f"[green]Timer {tid} cancelled.[/green]")
            else:
                console.print(f"[yellow]Timer '{tid}' not found.[/yellow]")
            return

        if sub == "clear":
            n = len(self._scheduled_timers)
            self._cancel_all_timers()
            console.print(f"[green]Cancelled {n} timer(s).[/green]")
            return

        # /timer <duration> <prompt>
        if not sub or not rest:
            console.print("[yellow]Usage: /timer <duration> <prompt>[/yellow]")
            console.print("[dim]Examples: /timer 30s 'Check server' | /timer 2h30m 'Daily sync'[/dim]")
            console.print("[dim]Sub-commands: /timer list | /timer cancel <id> | /timer clear[/dim]")
            return

        delay = self._parse_duration(sub)
        if delay is None:
            console.print(f"[red]Invalid duration: '{sub}'. Use 30s, 5m, 1h, 2h30m.[/red]")
            return
        if delay <= 0:
            console.print("[red]Duration must be > 0.[/red]")
            return

        prompt = _normalize_local_path_arg(rest)
        tid = str(uuid.uuid4())[:8]
        import time as _time
        fire_at = _time.time() + delay

        task = asyncio.create_task(self._run_timer(tid, delay, prompt))
        self._scheduled_timers[tid] = task
        self._timer_meta[tid] = {"prompt": prompt, "delay": delay, "fire_at": fire_at}

        console.print(
            f"[bold cyan][Timer][/bold cyan] Will run in "
            f"[bold]{self._format_duration(delay)}[/bold]: '{prompt}'  [dim](id: {tid})[/dim]"
        )

    async def _cmd_repeat(self, args: str) -> None:
        """Handle /repeat command."""
        args = args.strip()

        if args.lower() == "stop":
            if not self._active_repeats:
                console.print("[dim]No active repeats.[/dim]")
            else:
                n = len(self._active_repeats)
                self._cancel_all_repeats()
                console.print(f"[green]Stopped {n} active repeat(s).[/green]")
            return

        if not args:
            console.print("[yellow]Usage: /repeat <prompt> [--every <duration>] [--count N | --until <time>][/yellow]")
            console.print("[dim]Examples:[/dim]")
            console.print("  [dim]/repeat 'Check status' --every 5m --count 10[/dim]")
            console.print("  [dim]/repeat 'Summarize logs' --every 1h --until 5pm[/dim]")
            console.print("  [dim]/repeat stop  — stop active repeat[/dim]")
            return

        # Parse flags out of args
        # We extract --every, --count, --until first, remainder is the prompt
        every_val: Optional[str] = None
        count_val: Optional[int] = None
        until_val: Optional[str] = None

        # Use a simple token-level parser
        tokens = args.split()
        i = 0
        remaining_tokens = []
        while i < len(tokens):
            tok = tokens[i]
            if tok == "--every" and i + 1 < len(tokens):
                every_val = tokens[i + 1]
                i += 2
            elif tok == "--count" and i + 1 < len(tokens):
                try:
                    count_val = int(tokens[i + 1])
                except ValueError:
                    console.print(f"[red]Invalid --count value: {tokens[i + 1]}[/red]")
                    return
                i += 2
            elif tok == "--until" and i + 1 < len(tokens):
                until_val = tokens[i + 1]
                i += 2
            else:
                remaining_tokens.append(tok)
                i += 1

        prompt = " ".join(remaining_tokens).strip()
        # Strip surrounding quotes from prompt if present
        prompt = _normalize_local_path_arg(prompt)
        if not prompt:
            console.print("[red]No prompt provided.[/red]")
            return

        # Parse --every
        interval: float = 3600.0  # default 1h
        if every_val is not None:
            parsed_interval = self._parse_duration(every_val)
            if parsed_interval is None:
                console.print(f"[red]Invalid --every duration: '{every_val}'[/red]")
                return
            interval = parsed_interval

        # Parse --until
        until_ts: Optional[float] = None
        if until_val is not None:
            until_ts = self._parse_until_time(until_val)
            if until_ts is None:
                console.print(f"[red]Invalid --until time: '{until_val}'. Use 5pm, 17:00, 5:30pm.[/red]")
                return

        # Guard: only one active repeat at a time
        # Clean up finished tasks first
        self._active_repeats = [t for t in self._active_repeats if not t.done()]
        if self._active_repeats:
            console.print(
                "[yellow]A repeat is already running. Use /repeat stop to cancel it first.[/yellow]"
            )
            return

        task = asyncio.create_task(
            self._run_repeat(prompt, interval, count_val, until_ts)
        )
        self._active_repeats.append(task)

        # Show config summary
        summary_parts = [f"every [bold]{self._format_duration(interval)}[/bold]"]
        if count_val is not None:
            summary_parts.append(f"for {count_val} iteration(s)")
        if until_val is not None:
            summary_parts.append(f"until {until_val}")
        console.print(
            f"[bold cyan][Repeat][/bold cyan] '{prompt}' — {', '.join(summary_parts)}"
        )

    # ─── TUI: Progress bars ───────────────────────────────────────────────

    def _show_progress(self, description: str, total: Optional[int] = None):
        """Return a ``rich.progress.Progress`` context manager for long operations.

        Displays a spinner column + elapsed time column.  Returns a no-op
        context manager when ``MSAPLING_NO_PROGRESS=1`` is set (CI/scripted use)
        or when the shell has ``no_tui=True``.

        Usage::

            with self._show_progress("Waiting for response…") as prog:
                task = prog.add_task(description, total=total)
                # … do work …
                # On first real data: break / return; Progress auto-stops.

        Args:
            description: Label shown next to the spinner.
            total: Optional total units (``None`` = indeterminate spinner).

        Returns:
            A ``rich.progress.Progress`` instance (or a _NullProgress no-op).
        """
        from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn, TextColumn

        no_progress = (
            os.environ.get("MSAPLING_NO_PROGRESS", "").strip().lower() in ("1", "true", "yes")
            or getattr(self, "no_tui", False)
        )

        if no_progress:
            # Return a minimal no-op object so callers can use the same API.
            class _NullProgress:
                def add_task(self, *a, **kw):
                    return 0
                def update(self, *a, **kw):
                    pass
                def __enter__(self):
                    return self
                def __exit__(self, *a):
                    pass
            return _NullProgress()

        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=console,
            transient=True,
        )

    # ─── TUI: Diff detection & rendering ─────────────────────────────────

    @staticmethod
    def _is_diff_block(text: str) -> bool:
        """Return True when *text* looks like a unified diff block.

        Heuristic: the text contains at least one ``@@`` hunk header **and**
        at least one line starting with ``+`` or ``-`` (ignoring ``---``/``+++``
        header lines).
        """
        has_hunk = False
        has_delta = False
        for line in text.splitlines():
            if line.startswith("@@") and "@@" in line[2:]:
                has_hunk = True
            if has_hunk and len(line) > 1 and line[0] in ("+", "-") and not line.startswith(("---", "+++")):
                has_delta = True
            if has_hunk and has_delta:
                return True
        return False

    def _render_diff(self, text: str) -> None:
        """Detect diff blocks inside *text* and render them with syntax highlighting.

        Scans the text for fenced diff sections (triple-backtick ``diff`` blocks)
        or bare unified-diff sections.  Each detected diff is printed via
        ``rich.syntax.Syntax`` with the ``diff`` lexer and ``monokai`` theme,
        giving green added / red removed / cyan hunk-header colouring in terminals
        that support ANSI.

        Non-diff surrounding text is printed as-is via :func:`render_assistant_response`.

        Args:
            text: Full LLM response text that may contain one or more diff blocks.
        """
        # Split on fenced ```diff … ``` blocks first.
        fenced_pattern = re.compile(
            r"```(?:diff|patch)\n(.*?)```",
            re.DOTALL | re.IGNORECASE,
        )

        last_end = 0
        found_any = False
        for m in fenced_pattern.finditer(text):
            found_any = True
            # Print any non-diff text before this block.
            before = text[last_end:m.start()].strip()
            if before:
                render_assistant_response(before)
            diff_body = m.group(1)
            console.print(
                Syntax(diff_body, "diff", theme="monokai", line_numbers=False)
            )
            last_end = m.end()

        if found_any:
            # Print any remaining non-diff text after the last block.
            after = text[last_end:].strip()
            if after:
                render_assistant_response(after)
            return

        # No fenced blocks — check if the whole text is a bare diff.
        if self._is_diff_block(text):
            console.print(
                Syntax(text, "diff", theme="monokai", line_numbers=False)
            )
            return

        # Fallback: render as normal markdown.
        render_assistant_response(text)

    def _render_sidebar(self, projects: Optional[List[Dict[str, Any]]] = None, chats: Optional[List[Dict[str, Any]]] = None) -> None:
        """Render sidebar panel showing project/chat browser.

        When terminal width >= 80 uses rich.layout.Layout with a left panel and
        right chat area.  When width < 80 (narrow terminal) falls back to a
        compact inline list to avoid wrapping artefacts.
        """
        from rich.layout import Layout
        from rich.columns import Columns

        term_width = console.width or 80

        # ── Build sidebar content ──────────────────────────────────────────
        sidebar_table = Table(
            title="Sidebar",
            box=None,
            show_header=False,
            padding=(0, 1),
            expand=True,
        )
        sidebar_table.add_column("", style="cyan", no_wrap=True)

        # Current project
        project_label = self.project_name or "(no project)"
        sidebar_table.add_row(f"[bold]Project:[/bold] {project_label}")
        sidebar_table.add_row("")

        # Recent chats (last 5)
        sidebar_table.add_row("[bold]Recent Chats:[/bold]")
        if chats:
            for i, c in enumerate(chats[-5:], 1):
                title = c.get("title", c.get("slot_label", f"Chat {i}"))
                model_str = c.get("model", "")
                model_short = model_str.split("/")[-1] if "/" in model_str else model_str
                marker = "[green]>[/green] " if c.get("id") == self.chat_id else "  "
                sidebar_table.add_row(f"{marker}[dim]{i}.[/dim] {title[:20]}")
                if model_short:
                    sidebar_table.add_row(f"    [dim]{model_short[:18]}[/dim]")
        else:
            sidebar_table.add_row("  [dim](none)[/dim]")

        sidebar_table.add_row("")

        # Active workers
        sidebar_table.add_row("[bold]Workers:[/bold]")
        if self.workers:
            for w in self.workers[:4]:
                wname = w.get("name", "worker")
                wstatus = w.get("status", "idle")
                color = "green" if wstatus == "active" else "dim"
                sidebar_table.add_row(f"  [{color}]{wname}[/{color}]")
        else:
            sidebar_table.add_row("  [dim](none)[/dim]")

        # ── Narrow terminal: inline fallback (width < 80) ─────────────────
        if term_width < 80:
            console.print(Panel(sidebar_table, title="[bold cyan]Sidebar[/bold cyan]", border_style="cyan", width=term_width))
            return

        # ── Wide terminal: Layout with sidebar left / chat area right ──────
        layout = Layout()
        layout.split_row(
            Layout(Panel(sidebar_table, title="[bold cyan]Sidebar[/bold cyan]", border_style="cyan"), name="sidebar", size=30),
            Layout(Panel(
                f"[dim]Project:[/dim] {project_label}\n"
                f"[dim]Model:[/dim]   {self.model}\n"
                f"[dim]Messages:[/dim] {len([m for m in self.messages if m.get('role') != 'system'])}\n"
                f"[dim]Cost:[/dim]    ${self.cost_total:.4f}\n\n"
                "[dim]Use /sidebar to hide. Arrow keys navigate.[/dim]",
                title="[bold]Chat Area[/bold]",
                border_style="dim",
            ), name="chat"),
        )
        console.print(layout)

    async def _handle_slash(self, cmd: str) -> bool:
        """Handle slash command. Returns False to exit."""
        parts = cmd.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        # Track every slash command dispatched (excluding pure quit aliases to
        # keep the list meaningful — quit is implicit from session end).
        if command not in ("/quit", "/exit", "/q"):
            self.slash_commands_used.append(command)

        if command in ("/quit", "/exit", "/q"):
            return False
        elif command == "/help":
            render_help()
        elif command == "/model":
            if args:
                from .completer import resolve_model
                old = self.model
                resolved, was_fuzzy = resolve_model(args.strip())
                self.model = resolved
                self._track_model(resolved)
                if was_fuzzy:
                    console.print(f"[ms.accent]Model: {old} -> {self.model}[/ms.accent] [ms.dim](matched from '{args.strip()}')[/ms.dim]")
                else:
                    console.print(f"[ms.accent]Model: {old} -> {self.model}[/ms.accent]")
                await self._ensure_model_catalog()
                cached = self._model_catalog.get(self.model)
                if isinstance(cached, dict):
                    confirmation = _model_price_confirmation(self.model, cached)
                    if confirmation:
                        console.print(f"[dim]{confirmation}[/dim]")
                _run_hooks("on_model_change", self.hooks, self.project_root)
            else:
                console.print(f"Current model: [ms.accent]{self.model}[/ms.accent]")
        elif command == "/models":
            try:
                models = await self.client.get_models()
                self._cache_model_catalog(models)
                model_ids = []
                for m in models[:20]:
                    mid = m.get("id", "?")
                    model_ids.append(mid)
                    tag = "[green]free[/green]" if is_free_model(mid) else "[yellow]pro[/yellow]"
                    console.print(f"  {mid} ({tag})")
                if len(models) > 20:
                    console.print(f"  [dim]...and {len(models) - 20} more[/dim]")
                    model_ids.extend(m.get("id", "") for m in models[20:] if m.get("id"))
                # Update tab completer with fetched model IDs
                if self._completer and model_ids:
                    self._completer.set_models(model_ids)
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/shadow":
            action = args.strip().lower()
            if action in {"", "status"}:
                state = "ON" if self.shadow_mode else "OFF"
                console.print(f"[cyan]Shadow mode:[/cyan] [bold]{state}[/bold]")
                self._render_shadow_filters()
            elif action in {"on", "off", "toggle"}:
                if action == "toggle":
                    self.shadow_mode = not self.shadow_mode
                else:
                    self.shadow_mode = action == "on"
                state = "ON" if self.shadow_mode else "OFF"
                console.print(f"[green]Shadow mode {state}[/green]")
                if self.shadow_mode and not self.shadow_filters:
                    console.print("[dim]No filters configured yet. Use /filter add <type> <model>[/dim]")
            else:
                console.print("[yellow]Usage: /shadow [on|off|toggle|status][/yellow]")
        elif command == "/filter":
            parts = args.split()
            if not parts:
                console.print("[yellow]Usage: /filter [add|list|remove] ...[/yellow]")
            else:
                sub = parts[0].lower()
                if sub == "list":
                    self._render_shadow_filters()
                elif sub == "add":
                    if len(parts) < 3:
                        console.print("[yellow]Usage: /filter add <type> <model>[/yellow]")
                        console.print(
                            f"[dim]Types: {', '.join(_SHADOW_FILTER_TYPES)}[/dim]"
                        )
                        console.print(
                            f"[dim]Model format: {', '.join(_SHADOW_MODEL_PREFIXES)}[/dim]"
                        )
                        return True
                    filter_type = parts[1].strip().lower()
                    model_spec = " ".join(parts[2:]).strip()
                    if filter_type not in _SHADOW_FILTER_TYPES:
                        console.print(
                            f"[red]Unknown filter type: {filter_type}[/red]\n"
                            f"[dim]Allowed: {', '.join(_SHADOW_FILTER_TYPES)}[/dim]"
                        )
                        return True
                    if not _valid_shadow_model_spec(model_spec):
                        console.print(
                            "[red]Invalid model spec.[/red]\n"
                            f"[dim]Use one of: {', '.join(_SHADOW_MODEL_PREFIXES)}[/dim]"
                        )
                        return True
                    row = {
                        "id": self._next_shadow_filter_id,
                        "type": filter_type,
                        "model": model_spec,
                        "enabled": True,
                    }
                    self._next_shadow_filter_id += 1
                    self.shadow_filters.append(row)
                    console.print(
                        f"[green]Added shadow filter #{row['id']}:[/green] "
                        f"{filter_type} -> {model_spec}"
                    )
                elif sub == "remove":
                    if len(parts) != 2 or not parts[1].isdigit():
                        console.print("[yellow]Usage: /filter remove <id>[/yellow]")
                        return True
                    target_id = int(parts[1])
                    before = len(self.shadow_filters)
                    self.shadow_filters = [
                        row for row in self.shadow_filters if int(row.get("id", -1)) != target_id
                    ]
                    if len(self.shadow_filters) == before:
                        console.print(f"[yellow]No filter found with id {target_id}[/yellow]")
                    else:
                        console.print(f"[green]Removed filter #{target_id}[/green]")
                else:
                    console.print("[yellow]Usage: /filter [add|list|remove] ...[/yellow]")
        elif command == "/cost":
            console.print(f"[cyan]Session cost:[/cyan] ${self.cost_total:.4f}")
            console.print(f"[cyan]Tokens used:[/cyan] {self.tokens_total:,}")
            console.print(f"[cyan]Messages:[/cyan] {len(self.messages)}")
            fuel = self.user.get('fuel_credits', 0)
            console.print(f"[cyan]Fuel remaining:[/cyan] ${fuel:.4f}")
        elif command == "/clear":
            from rich.prompt import Confirm
            if not Confirm.ask("[yellow]Clear conversation history?[/yellow]", default=False):
                console.print("[dim]Cancelled.[/dim]")
                return True
            self.messages = [m for m in self.messages if m.get("role") == "system"]
            self.cost_total = 0.0
            self.tokens_total = 0
            console.print("[green]Conversation cleared[/green]")
        elif command == "/compact":
            await self._compact_context()
        elif command == "/context":
            # Better token estimation: ~3.5 chars/token for English code
            sys_msgs = [m for m in self.messages if m.get("role") == "system"]
            user_msgs = [m for m in self.messages if m.get("role") == "user"]
            asst_msgs = [m for m in self.messages if m.get("role") == "assistant"]
            sys_chars = sum(len(m.get("content", "")) for m in sys_msgs)
            user_chars = sum(len(m.get("content", "")) for m in user_msgs)
            asst_chars = sum(len(m.get("content", "")) for m in asst_msgs)
            total_chars = sys_chars + user_chars + asst_chars
            # ~3.5 chars per token for code-heavy content
            token_est = int(total_chars / 3.5)
            # Visual bar (rough context usage assuming 128k model)
            max_ctx = 128000
            pct = min(100, int(token_est / max_ctx * 100))
            bar_len = 30
            filled = int(bar_len * pct / 100)
            bar = "[green]" + "█" * filled + "[/green]" + "[dim]░[/dim]" * (bar_len - filled)
            color = "green" if pct < 50 else ("yellow" if pct < 80 else "red")

            console.print(f"  [cyan]Model:[/cyan]    {self.model}")
            console.print(f"  [cyan]Messages:[/cyan] {len(sys_msgs)} system, {len(user_msgs)} user, {len(asst_msgs)} assistant")
            console.print(f"  [cyan]Tokens:[/cyan]   ~{token_est:,} / {max_ctx:,} [{color}]({pct}%)[/{color}]")
            console.print(f"  [cyan]Usage:[/cyan]    {bar} {pct}%")
            console.print(f"  [cyan]Cost:[/cyan]     ${self.cost_total:.4f}  ({self.tokens_total:,} tokens used)")
            if pct > 70:
                console.print("  [yellow]Consider /compact to free context space.[/yellow]")
        elif command == "/files":
            raw_arg = _normalize_local_path_arg(args)
            pattern = raw_arg or "**/*"
            try:
                skip = {".git", "node_modules", "__pycache__", "venv", "dist", "build"}
                if raw_arg and not globmod.has_magic(raw_arg):
                    target = _safe_path(self.project_root, raw_arg)
                    if not target:
                        console.print("[red]Path outside project root[/red]")
                        return True
                    if target.is_dir():
                        candidates = sorted(target.rglob("*"))
                    elif target.exists():
                        candidates = [target]
                    else:
                        console.print(f"[yellow]No files matched: {args}[/yellow]")
                        return True
                else:
                    candidates = [Path(p) for p in sorted(globmod.glob(str(Path(self.project_root) / pattern), recursive=True))]
                shown = 0
                for f in candidates:
                    rel = os.path.relpath(f, self.project_root).replace("\\", "/")
                    if any(s in rel.split("/") for s in skip):
                        continue
                    if os.path.isfile(f):
                        size = os.path.getsize(f)
                        console.print(f"  {rel} ({size / 1024:.1f}KB)")
                        shown += 1
                        if shown >= 50:
                            break
                if shown == 0:
                    console.print("[yellow]No files matched.[/yellow]")
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/read":
            raw_path = _normalize_local_path_arg(args)
            fpath = _safe_path(self.project_root, raw_path)
            if not fpath:
                console.print("[red]Path outside project root[/red]")
            elif fpath.is_dir():
                console.print(f"[yellow]Path is a directory: {raw_path}. Use /files or ask the agent to list it.[/yellow]")
            elif not fpath.is_file():
                console.print(f"[red]File not found: {raw_path}[/red]")
            else:
                try:
                    content = fpath.read_text(encoding="utf-8", errors="ignore")
                    if len(content) > 50000:
                        content = content[:50000]
                    ext = fpath.suffix.lstrip(".")
                    lang_map = {"py": "python", "ts": "typescript", "js": "javascript", "tsx": "tsx"}
                    console.print(Syntax(content, lang_map.get(ext, ext), theme="monokai", line_numbers=True))
                    self.messages.append({
                        "role": "user",
                        "content": f"[File: {raw_path}]\n```\n{content}\n```",
                    })
                    self._track_file(raw_path)
                    console.print(f"[dim]Added to context ({len(content)//4} tokens)[/dim]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
        elif command == "/grep":
            if not args:
                console.print("[yellow]Usage: /grep <pattern> [path][/yellow]")
            else:
                gp = args.split(maxsplit=1)
                pat = gp[0]
                sp = gp[1] if len(gp) > 1 else "."
                cmds = [
                    ["rg", "-n", "--max-count=30", pat, sp],
                    ["grep", "-rn", pat, sp],
                ]
                found = False
                for gc in cmds:
                    try:
                        r = subprocess.run(gc, cwd=self.project_root, capture_output=True, text=True, timeout=10)
                        if r.stdout:
                            for ln in r.stdout.strip().split("\n")[:30]:
                                console.print(f"  {ln}")
                        else:
                            console.print("[yellow]No matches[/yellow]")
                        found = True
                        break
                    except FileNotFoundError:
                        continue
                if not found:
                    console.print("[red]Neither rg nor grep found.[/red]")
        elif command == "/run":
            if not args:
                console.print("[yellow]Usage: /run <command>[/yellow]")
            else:
                try:
                    # shlex.split with posix=False on Windows to preserve backslashes
                    cp = shlex.split(args, posix=(sys.platform != "win32"))
                    self.commands_run.append(args.strip())
                    try:
                        r = subprocess.run(
                            cp,
                            shell=False,
                            cwd=self.project_root,
                            capture_output=True,
                            text=True,
                            timeout=30,
                        )
                    except FileNotFoundError:
                        # Windows builtins (e.g. "echo", "dir") are handled by cmd.exe.
                        if sys.platform == "win32":
                            r = subprocess.run(
                                ["cmd", "/c", args],
                                shell=False,
                                cwd=self.project_root,
                                capture_output=True,
                                text=True,
                                timeout=30,
                            )
                        else:
                            raise
                    if r.stdout:
                        console.print(r.stdout[:5000])
                    if r.stderr and r.returncode != 0:
                        console.print(f"[red]{r.stderr[:2000]}[/red]")
                    console.print(f"[dim]exit code: {r.returncode}[/dim]")
                    if r.returncode != 0:
                        _run_hooks("on_compile_error", self.hooks, self.project_root)
                    await _lineage_record_shell_command(
                        session_id=self.session_id,
                        command=args.strip(),
                        exit_code=r.returncode,
                        stdout=r.stdout or "",
                        stderr=r.stderr or "",
                        project_name=self.project_name or self.project_root,
                        metadata={"cwd": self.project_root, "kind": "run"},
                    )
                except subprocess.TimeoutExpired:
                    console.print("[red]Command timed out (30s)[/red]")
                    _run_hooks("on_compile_error", self.hooks, self.project_root)
                    await _lineage_record_shell_command(
                        session_id=self.session_id,
                        command=args.strip(),
                        exit_code=None,
                        stdout="",
                        stderr="timeout",
                        project_name=self.project_name or self.project_root,
                        metadata={"cwd": self.project_root, "kind": "run"},
                    )
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
                    _run_hooks("on_compile_error", self.hooks, self.project_root)
                    await _lineage_record_shell_command(
                        session_id=self.session_id,
                        command=args.strip(),
                        exit_code=None,
                        stdout="",
                        stderr=str(e),
                        project_name=self.project_name or self.project_root,
                        metadata={"cwd": self.project_root, "kind": "run"},
                    )
        elif command == "/bridge":
            if not args.strip():
                console.print(
                    "[yellow]Usage: /bridge <codex|claude> <args...> "
                    "[--timeout N] [--allow-tools][/yellow]"
                )
            else:
                try:
                    parsed = _parse_bridge_args(args)
                except ValueError as exc:
                    console.print(f"[red]{exc}[/red]")
                    return True

                tool_name = str(parsed["tool"]).strip()
                timeout_s = float(parsed["timeout_s"])
                allow_tools = bool(parsed["allow_tools"])
                cli_args = list(parsed["cli_args"])
                supported = {"codex", "claude"}
                if tool_name.lower() not in supported:
                    console.print(
                        f"[red]Unsupported bridge tool: {tool_name}. "
                        f"Supported: {', '.join(sorted(supported))}[/red]"
                    )
                    return True
                if not cli_args:
                    console.print("[yellow]Bridge requires child CLI arguments after the tool name.[/yellow]")
                    return True

                joined = " ".join(cli_args).lower()
                if "msapling shell" in joined or "python -m msapling_cli" in joined:
                    console.print("[red]Recursion guard: nested msapling shell invocation is blocked.[/red]")
                    return True

                dangerous_flags = {
                    "--dangerously-skip-permissions",
                    "--dangerously-allow-all",
                    "--unsafe",
                    "--skip-sandbox",
                }
                if not allow_tools and any(tok.lower() in dangerous_flags for tok in cli_args):
                    console.print(
                        "[red]Blocked dangerous child CLI flags. Re-run with --allow-tools "
                        "to explicitly permit tool access.[/red]"
                    )
                    return True

                argv = [tool_name] + cli_args
                env = os.environ.copy()
                env["MSAPLING_BRIDGE_ACTIVE"] = "1"
                env["MSAPLING_CHILD_TOOL_ACCESS"] = "allow" if allow_tools else "deny"
                transcript_path = _bridge_default_log_path(self.session_id, tool_name)

                self.commands_run.append("/bridge " + args.strip())
                console.print(
                    f"[cyan]Launching bridge:[/cyan] {tool_name} "
                    f"[dim](timeout={int(timeout_s)}s, tools={env['MSAPLING_CHILD_TOOL_ACCESS']})[/dim]"
                )
                proc: Optional[subprocess.Popen] = None
                stdout_text = ""
                stderr_text = ""
                rc: Optional[int] = None
                status = "error"
                try:
                    proc = subprocess.Popen(
                        argv,
                        cwd=self.project_root,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        env=env,
                    )
                    try:
                        stdout_text, stderr_text = proc.communicate(timeout=timeout_s)
                        rc = int(proc.returncode)
                        status = "ok" if rc == 0 else "failed"
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        stdout_text, stderr_text = proc.communicate()
                        status = "timeout"
                        rc = 124
                        console.print(f"[red]Bridge command timed out after {int(timeout_s)}s.[/red]")
                    except KeyboardInterrupt:
                        proc.kill()
                        stdout_text, stderr_text = proc.communicate()
                        status = "cancelled"
                        rc = 130
                        console.print("[yellow]Bridge command cancelled.[/yellow]")
                except FileNotFoundError:
                    status = "missing"
                    rc = 127
                    stderr_text = f"Command not found: {tool_name}"
                    console.print(f"[red]{stderr_text}[/red]")
                except Exception as exc:
                    status = "error"
                    rc = 1
                    stderr_text = str(exc)
                    console.print(f"[red]Bridge failed: {exc}[/red]")
                finally:
                    try:
                        _write_bridge_transcript(
                            out_path=transcript_path,
                            tool_name=tool_name,
                            argv=argv,
                            cwd=self.project_root,
                            return_code=rc,
                            status=status,
                            stdout_text=stdout_text,
                            stderr_text=stderr_text,
                        )
                        console.print(f"[dim]Transcript: {transcript_path}[/dim]")
                    except Exception as exc:
                        console.print(f"[yellow]Failed to write bridge transcript: {exc}[/yellow]")

                    await _lineage_record_shell_command(
                        session_id=self.session_id,
                        command=" ".join(argv),
                        exit_code=rc,
                        stdout=stdout_text,
                        stderr=stderr_text,
                        project_name=self.project_name or self.project_root,
                        metadata={
                            "cwd": self.project_root,
                            "kind": "bridge",
                            "bridge_tool": tool_name,
                            "tool_access": env.get("MSAPLING_CHILD_TOOL_ACCESS", "deny"),
                            "status": status,
                        },
                    )

                if stdout_text.strip():
                    console.print(stdout_text[:5000])
                if stderr_text.strip():
                    style = "red" if rc else "yellow"
                    console.print(f"[{style}]{stderr_text[:2000]}[/{style}]")
                console.print(f"[dim]bridge exit code: {rc if rc is not None else '?'}[/dim]")
        elif command == "/git":
            if not args:
                args = "status --short"
            try:
                r = subprocess.run(["git"] + args.split(), cwd=self.project_root, capture_output=True, text=True, timeout=30)
                out = r.stdout or r.stderr
                if args.split()[0] in ("diff", "show", "log"):
                    console.print(Syntax(out[:5000], "diff", theme="monokai"))
                else:
                    console.print(out[:5000])
                await _lineage_record_shell_command(
                    session_id=self.session_id,
                    command=f"git {args}",
                    exit_code=r.returncode,
                    stdout=r.stdout or "",
                    stderr=r.stderr or "",
                    project_name=self.project_name or self.project_root,
                    metadata={"cwd": self.project_root, "kind": "git"},
                )
            except Exception as e:
                console.print(f"[red]{e}[/red]")
                await _lineage_record_shell_command(
                    session_id=self.session_id,
                    command=f"git {args}",
                    exit_code=None,
                    stdout="",
                    stderr=str(e),
                    project_name=self.project_name or self.project_root,
                    metadata={"cwd": self.project_root, "kind": "git"},
                )
        elif command == "/status":
            await self._handle_slash("/git status --short")
        elif command == "/plan":
            from .agent import set_permission_mode
            self.plan_mode = not self.plan_mode
            if self.plan_mode:
                set_permission_mode("plan")
                console.print("[green]Plan mode: ON[/green] [dim](read-only, no file writes or commands)[/dim]")
            else:
                set_permission_mode("ask")
                console.print("[red]Plan mode: OFF[/red] [dim](back to normal)[/dim]")
        elif command == "/save":
            self._save()
            console.print(f"[green]Session saved: {self.session_id}[/green]")
        elif command == "/save-remote":
            await self._cmd_save_remote(args.strip())
        elif command == "/resume-remote":
            await self._cmd_resume_remote(args.strip())
        elif command == "/resume":
            sessions = list_sessions()
            if not sessions:
                console.print("[yellow]No saved sessions[/yellow]")
            else:
                # Default: show 20 most recent; pass "all" or a number to change.
                _limit = 20
                _show_all = args.strip().lower() == "all"
                if args.strip().isdigit():
                    _limit = int(args.strip())
                # --search filter: /resume --search <term>
                _search_query: Optional[str] = None
                _args_lower = args.strip().lower()
                if "--search" in args:
                    _search_idx = args.index("--search")
                    _search_query = args[_search_idx + len("--search"):].strip()
                    if _search_query:
                        _sq = _search_query.lower()
                        sessions = [
                            s for s in sessions
                            if _sq in (s.get("id") or "").lower()
                            or _sq in (s.get("_summary") or "").lower()
                            or _sq in (s.get("metadata", {}).get("project_name") or "").lower()
                            or any(
                                _sq in (m.get("content") or "").lower()
                                for m in (s.get("messages") or [])[:1]
                            )
                        ]
                        if not sessions:
                            console.print(f"[yellow]No sessions match '{_search_query}'[/yellow]")
                            return True
                display_sessions = sessions if _show_all else sessions[:_limit]
                table = Table(title="Saved Sessions")
                table.add_column("#", style="cyan")
                table.add_column("ID")
                table.add_column("Model")
                table.add_column("Messages", justify="right")
                table.add_column("Last Prompt")
                for i, s in enumerate(display_sessions):
                    table.add_row(
                        str(i + 1), s["id"], s.get("model", "?"),
                        str(len(s.get("messages", []))),
                        s.get("_summary", "")[:60],
                    )
                console.print(table)
                if not _show_all and not _search_query and len(sessions) > _limit:
                    console.print(f"[dim]Showing {_limit} of {len(sessions)} sessions. Use /resume all or /resume <n> for more.[/dim]")
        elif command == "/sessions":
            sub_parts = args.split(maxsplit=1) if args.strip() else []
            sub_cmd = sub_parts[0].lower() if sub_parts else "list"
            sub_arg = sub_parts[1] if len(sub_parts) > 1 else ""
            if sub_cmd == "search":
                query = sub_arg.strip()
                if not query:
                    console.print("[yellow]Usage: /sessions search <query>[/yellow]")
                else:
                    results = _sessions_search(query)
                    console.print(f"[bold]Session Search Results for:[/bold] [cyan]{query}[/cyan]")
                    if not results:
                        console.print("  [yellow]No matching sessions found.[/yellow]")
                    else:
                        tbl = Table(show_header=True, header_style="bold cyan")
                        tbl.add_column("#", style="dim", width=3)
                        tbl.add_column("Session ID")
                        tbl.add_column("Title")
                        tbl.add_column("Project")
                        tbl.add_column("Score", justify="right")
                        tbl.add_column("Snippet")
                        for i, r in enumerate(results, 1):
                            tbl.add_row(
                                str(i),
                                r.session_id[:12],
                                (r.title or "")[:30],
                                (r.project or "")[:20],
                                f"{r.score:.3f}",
                                (r.matched_snippet or "")[:60],
                            )
                        console.print(tbl)
            elif sub_cmd == "list" or not sub_cmd:
                # Enhanced listing: show project name, cost, and duration.
                sessions = list_sessions()
                if not sessions:
                    console.print("[yellow]No saved sessions.[/yellow]")
                else:
                    table = Table(title="Saved Sessions")
                    table.add_column("#", style="cyan")
                    table.add_column("ID")
                    table.add_column("Project")
                    table.add_column("Model")
                    table.add_column("Msgs", justify="right")
                    table.add_column("Cost", justify="right")
                    table.add_column("Duration", justify="right")
                    table.add_column("Summary")
                    for i, s in enumerate(sessions, 1):
                        meta = s.get("metadata", {})
                        project = meta.get("project_name") or s.get("project_root", "—") or "—"
                        if project and len(project) > 20:
                            project = "…" + project[-18:]
                        cost_val = meta.get("total_cost_usd") or meta.get("cost_usd") or 0.0
                        cost_str = f"${cost_val:.4f}" if cost_val else "—"
                        dur = meta.get("duration_seconds")
                        dur_str = InteractiveShell._format_duration(dur) if dur else "—"
                        table.add_row(
                            str(i),
                            s.get("id", "?")[:12],
                            str(project)[:20],
                            s.get("model", "?").split("/")[-1][:16],
                            str(len(s.get("messages", []))),
                            cost_str,
                            dur_str,
                            (meta.get("summary") or s.get("_summary", ""))[:50],
                        )
                    console.print(table)
                    console.print(f"[dim]Use /resume to restore a session by number.[/dim]")
            else:
                console.print("[yellow]Usage: /sessions [list|search <query>][/yellow]")
                console.print("  [dim]list   — show saved sessions with metadata (default)[/dim]")
                console.print("  [dim]search — BM25 search across session contents[/dim]")
        elif command == "/session-info":
            # Show rich metadata for the current live session.
            import datetime as _dt
            duration_secs = time.time() - self._session_start_time
            tokens_in_est = self.tokens_in if self.tokens_in else int(self.tokens_total * 0.6)
            tokens_out_est = self.tokens_out if self.tokens_out else (self.tokens_total - tokens_in_est)

            table = Table(title=f"Session Info — {self.session_id}", show_header=False, box=None)
            table.add_column("Field", style="cyan", min_width=20)
            table.add_column("Value")
            table.add_row("Session ID", self.session_id)
            table.add_row("Project", self.project_name or "(none)")
            table.add_row("Models used", ", ".join(self.models_used) or "(none)")
            table.add_row("Turn count", str(self.turn_count))
            table.add_row("Cost (est.)", f"${self._estimate_cost_usd():.6f}")
            table.add_row("Tokens in (est.)", f"{tokens_in_est:,}")
            table.add_row("Tokens out (est.)", f"{tokens_out_est:,}")
            table.add_row("Duration", InteractiveShell._format_duration(duration_secs))
            started = _dt.datetime.fromtimestamp(self._session_start_time, tz=_dt.timezone.utc)
            table.add_row("Started at", started.strftime("%Y-%m-%d %H:%M:%S UTC"))
            table.add_row("Slash commands", str(len(self.slash_commands_used)))

            console.print(table)

            # Files touched
            all_files = self._extract_files_from_messages()
            if all_files:
                console.print(f"\n  [cyan]Files touched ({len(all_files)}):[/cyan]")
                for fp in all_files[:20]:
                    console.print(f"    {fp}")
                if len(all_files) > 20:
                    console.print(f"    [dim]...and {len(all_files) - 20} more[/dim]")
            else:
                console.print("  [dim]No files touched yet.[/dim]")
        elif command == "/project":
            console.print(f"[cyan]Root:[/cyan] {self.project_root}")
            console.print(f"[cyan]Type:[/cyan] {self.project_info.get('type', 'unknown')}")
            console.print(f"[cyan]Git:[/cyan] {git_status(self.project_root)[:200]}")
        elif command == "/init":
            await self._generate_project_instructions()
        elif command == "/skill":
            tokens = args.strip().split(maxsplit=1) if args.strip() else ["list"]
            sub = tokens[0].lower()
            subarg = tokens[1].strip() if len(tokens) > 1 else ""
            if sub in {"list", "ls"}:
                files = _iter_bundled_skill_files()
                if not files:
                    console.print("[yellow]No bundled skills found.[/yellow]")
                else:
                    table = Table(title="Bundled Skills")
                    table.add_column("#", style="cyan")
                    table.add_column("Skill")
                    table.add_column("Status")
                    for idx, path in enumerate(files, 1):
                        ref = _skill_ref_from_path(path)
                        status = "loaded" if ref in self.loaded_skills else ""
                        table.add_row(str(idx), ref, status)
                    console.print(table)
                    console.print("[dim]Load with: /skill load <domain/name>[/dim]")
            elif sub == "load":
                if not subarg:
                    console.print("[yellow]Usage: /skill load <domain/name>[/yellow]")
                else:
                    skill_path = _find_bundled_skill(subarg)
                    if skill_path is None:
                        console.print(f"[yellow]Skill not found: {subarg}[/yellow]")
                    else:
                        ref = _skill_ref_from_path(skill_path)
                        if ref in self.loaded_skills:
                            console.print(f"[dim]Skill already loaded: {ref}[/dim]")
                        else:
                            try:
                                content = skill_path.read_text(encoding="utf-8", errors="ignore").strip()
                            except Exception as exc:
                                console.print(f"[red]Failed to load skill '{ref}': {exc}[/red]")
                                content = ""
                            if content:
                                self.messages.append(
                                    {
                                        "role": "system",
                                        "content": f"[Loaded skill: {ref}]\n{content[:12000]}",
                                    }
                                )
                                self.loaded_skills.append(ref)
                                console.print(f"[green]Loaded skill:[/green] {ref}")
            else:
                console.print("[yellow]Usage: /skill [list|load <domain/name>][/yellow]")
        elif command == "/whoami":
            console.print(f"[cyan]Email:[/cyan] {self.user.get('email', '?')}")
            console.print(f"[cyan]Tier:[/cyan] {self.user.get('tier', 'free')}")
            fuel = self.user.get('fuel_credits', 0)
            console.print(f"[cyan]Credits:[/cyan] ${fuel:.4f}")
        elif command == "/memory":
            if not args.strip():
                entries = list_memories(self.project_root)
                if not entries:
                    console.print("[yellow]No memories.[/yellow]")
                else:
                    for e in entries[-15:]:
                        sc = e.get("_scope", "?")
                        console.print(f"  [{sc}] {e.get('text', '')[:100]}")
            elif args.startswith("add "):
                text = args[4:].strip()
                if text:
                    r = add_memory(text, project_root=self.project_root)
                    console.print(f"[green]{r}[/green]")
            elif args.strip() == "clear":
                clear_memories(self.project_root)
                console.print("[green]Memories cleared[/green]")
        elif command == "/permissions":
            from .agent import get_permission_mode, set_permission_mode
            from .policy import (
                add_trusted_path,
                generated_policy_path,
                list_generated_approval_rules,
                load_permission_decisions,
                list_trusted_paths,
                remove_generated_approval,
                remove_trusted_path,
            )

            raw_args = args.strip()
            parts = raw_args.split(maxsplit=1) if raw_args else []
            tokens = raw_args.split() if raw_args else []
            subcommand = parts[0].lower() if parts else ""
            subarg = parts[1].strip() if len(parts) > 1 else ""

            if not parts:
                mode = get_permission_mode()
                trusted = list_trusted_paths(workspace=self.project_root)
                console.print(f"[cyan]Permission mode:[/cyan] {mode}")
                console.print(f"[cyan]Approval scope:[/cyan] {self.permission_persist_scope}")
                console.print("[dim]  ask      = prompt for writes/commands (default)")
                console.print("  auto     = auto-approve edits, ask for commands")
                console.print("  readonly = block all writes")
                console.print("  full     = approve everything")
                console.print("  /permissions scope [workspace|user] set where permanent approvals are saved")
                console.print("  /permissions trust [path]   add a trusted folder (default: project root)")
                console.print("  /permissions untrust <path|#> remove trusted folder")
                console.print("  /permissions list           list trusted folders")
                console.print("  /permissions approvals [list|remove] manage stored permanent approvals")
                console.print("  /permissions audit [limit] [allow|deny] [tool=<name>] show recent decisions")
                if trusted:
                    console.print("[cyan]Trusted folders:[/cyan]")
                    for idx, trust_path in enumerate(trusted, 1):
                        console.print(f"  {idx}. {trust_path}")
                else:
                    console.print("[dim]No trusted folders configured.[/dim]")
                console.print(f"[dim]Policy file: {generated_policy_path(self.project_root)}[/dim]")
            elif subcommand in {"ask", "auto", "readonly", "full", "plan"}:
                new_mode = set_permission_mode(subcommand)
                console.print(f"[green]Permission mode: {new_mode}[/green]")
            elif subcommand == "scope":
                if not subarg:
                    console.print(f"[cyan]Approval scope:[/cyan] {self.permission_persist_scope}")
                    console.print("[dim]Set with: /permissions scope <workspace|user>[/dim]")
                else:
                    scope = subarg.lower()
                    if scope not in {"workspace", "user"}:
                        console.print("[yellow]Usage: /permissions scope <workspace|user>[/yellow]")
                    else:
                        self.permission_persist_scope = scope
                        console.print(f"[green]Approval scope: {scope}[/green]")
            elif subcommand == "trust":
                target = subarg or "."
                try:
                    resolved, added = add_trusted_path(target, workspace=self.project_root)
                    if added:
                        console.print(f"[green]Trusted folder added:[/green] {resolved}")
                    else:
                        console.print(f"[yellow]Trusted folder already exists:[/yellow] {resolved}")
                    console.print(f"[dim]Policy file: {generated_policy_path(self.project_root)}[/dim]")
                except Exception as exc:
                    console.print(f"[red]{exc}[/red]")
            elif subcommand in {"untrust", "distrust"}:
                if not subarg:
                    console.print("[yellow]Usage: /permissions untrust <path|#>[/yellow]")
                else:
                    removed = remove_trusted_path(subarg, workspace=self.project_root)
                    if removed is None:
                        console.print(f"[yellow]Trusted folder not found:[/yellow] {subarg}")
                    else:
                        console.print(f"[green]Trusted folder removed:[/green] {removed}")
            elif subcommand in {"list", "trusted"}:
                trusted = list_trusted_paths(workspace=self.project_root)
                if not trusted:
                    console.print("[dim]No trusted folders configured.[/dim]")
                else:
                    table = Table(title="Trusted Folders")
                    table.add_column("#", style="cyan")
                    table.add_column("Path")
                    for idx, trust_path in enumerate(trusted, 1):
                        table.add_row(str(idx), str(trust_path))
                    console.print(table)
                console.print(f"[dim]Policy file: {generated_policy_path(self.project_root)}[/dim]")
            elif subcommand in {"approvals", "approval"}:
                action = tokens[1].lower() if len(tokens) > 1 else "list"
                if action in {"list", "ls"}:
                    scope = tokens[2].lower() if len(tokens) > 2 else self.permission_persist_scope
                    if scope not in {"workspace", "user"}:
                        console.print("[yellow]Usage: /permissions approvals list [workspace|user][/yellow]")
                    else:
                        rules = list_generated_approval_rules(workspace=self.project_root, scope=scope)
                        if not rules:
                            console.print(f"[dim]No stored approvals in {scope} scope.[/dim]")
                        else:
                            console.print(f"[cyan]Stored Approvals ({scope})[/cyan]")
                            table = Table(title=f"Stored Approvals ({scope})")
                            table.add_column("#", style="cyan")
                            table.add_column("Name")
                            table.add_column("Tool")
                            table.add_column("Modes")
                            table.add_column("Match")
                            for idx, rule in enumerate(rules, 1):
                                modes = ",".join(str(m) for m in (rule.get("modes") or [])) or "*"
                                match = str(rule.get("commandPrefix") or rule.get("argsPattern") or "*")
                                table.add_row(
                                    str(idx),
                                    str(rule.get("name") or ""),
                                    str(rule.get("toolName") or ""),
                                    modes,
                                    match,
                                )
                            console.print(table)
                elif action in {"remove", "rm", "delete"}:
                    target = tokens[2] if len(tokens) > 2 else ""
                    scope = tokens[3].lower() if len(tokens) > 3 else self.permission_persist_scope
                    if not target:
                        console.print("[yellow]Usage: /permissions approvals remove <name|#> [workspace|user][/yellow]")
                    elif scope not in {"workspace", "user"}:
                        console.print("[yellow]Usage: /permissions approvals remove <name|#> [workspace|user][/yellow]")
                    else:
                        removed = remove_generated_approval(target, workspace=self.project_root, scope=scope)
                        if removed is None:
                            console.print(f"[yellow]Approval not found:[/yellow] {target}")
                        else:
                            console.print(f"[green]Removed approval:[/green] {removed.get('name', target)}")
                else:
                    console.print("[yellow]Usage: /permissions approvals [list|remove <name|#>] [workspace|user][/yellow]")
            elif subcommand in {"audit", "logs", "log"}:
                limit = 20
                decision_filter = ""
                tool_filter = ""
                for token in tokens[1:]:
                    tok = token.strip()
                    if not tok:
                        continue
                    low = tok.lower()
                    if tok.isdigit():
                        limit = max(1, min(200, int(tok)))
                    elif low in {"allow", "deny"}:
                        decision_filter = low
                    elif low.startswith("tool="):
                        tool_filter = tok.split("=", 1)[1].strip()
                    elif not tool_filter:
                        tool_filter = tok
                rows = load_permission_decisions(
                    limit=limit,
                    decision=decision_filter or None,
                    tool=tool_filter or None,
                )
                if not rows:
                    console.print("[dim]No permission decisions logged yet.[/dim]")
                else:
                    console.print("[cyan]Permission Decisions[/cyan]")
                    table = Table(title="Permission Decisions")
                    table.add_column("Time", style="cyan")
                    table.add_column("Decision")
                    table.add_column("Tool")
                    table.add_column("Mode")
                    table.add_column("Role")
                    table.add_column("Source")
                    table.add_column("Reason")
                    table.add_column("Correlation")
                    for row in rows:
                        table.add_row(
                            str(row.get("ts") or ""),
                            str(row.get("decision") or ""),
                            str(row.get("tool") or ""),
                            str(row.get("mode") or ""),
                            str(row.get("permission_name") or row.get("permission_role") or ""),
                            str(row.get("source") or ""),
                            str(row.get("reason") or "")[:70],
                            str(row.get("correlation_id") or ""),
                        )
                    console.print(table)
            else:
                console.print("[yellow]Usage: /permissions [ask|auto|readonly|full|plan][/yellow]")
                console.print("[yellow]       /permissions scope <workspace|user>[/yellow]")
                console.print("[yellow]       /permissions trust [path][/yellow]")
                console.print("[yellow]       /permissions untrust <path|#>[/yellow]")
                console.print("[yellow]       /permissions list[/yellow]")
                console.print("[yellow]       /permissions approvals [list|remove <name|#>] [workspace|user][/yellow]")
                console.print("[yellow]       /permissions audit [limit] [allow|deny] [tool=<name>][/yellow]")
        elif command == "/worktree":
            sub = args.split()[0].lower() if args.strip() else "list"
            wt_arg = args.split()[1] if len(args.split()) > 1 else ""
            if sub == "list":
                try:
                    r = subprocess.run(["git", "worktree", "list"], cwd=self.project_root,
                                       capture_output=True, text=True, timeout=10)
                    console.print(r.stdout or "[yellow]No worktrees[/yellow]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "create" and wt_arg:
                branch = wt_arg
                wt_path = os.path.join(self.project_root, f"../{Path(self.project_root).name}-{branch}")
                try:
                    r = subprocess.run(
                        ["git", "worktree", "add", wt_path, "-b", branch],
                        cwd=self.project_root, capture_output=True, text=True, timeout=30,
                    )
                    if r.returncode == 0:
                        console.print(f"[green]Worktree created: {wt_path}[/green]")
                        console.print(f"[dim]Switch with: /worktree switch {branch}[/dim]")
                    else:
                        console.print(f"[red]{r.stderr}[/red]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "switch" and wt_arg:
                try:
                    r = subprocess.run(["git", "worktree", "list", "--porcelain"],
                                       cwd=self.project_root, capture_output=True, text=True, timeout=10)
                    for line in r.stdout.split("\n"):
                        if line.startswith("worktree ") and wt_arg in line:
                            new_root = line.replace("worktree ", "").strip()
                            self.project_root = new_root
                            console.print(f"[green]Switched to worktree: {new_root}[/green]")
                            break
                    else:
                        console.print(f"[yellow]Worktree not found: {wt_arg}[/yellow]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            elif sub == "delete" and wt_arg:
                try:
                    r = subprocess.run(["git", "worktree", "remove", wt_arg],
                                       cwd=self.project_root, capture_output=True, text=True, timeout=10)
                    if r.returncode == 0:
                        console.print(f"[green]Worktree removed: {wt_arg}[/green]")
                    else:
                        console.print(f"[red]{r.stderr}[/red]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")
            else:
                console.print("[yellow]Usage: /worktree <create|list|switch|delete> [branch][/yellow]")
        elif command == "/unlock":
            target_id = args.strip() or self.chat_id
            if not target_id:
                console.print("[red]No chat ID — you must be in a chat to unlock.[/red]")
                return True
            console.print(f"[yellow]Force-releasing stream lock for chat {target_id}...[/yellow]")
            released = await self.client.force_release_lock(target_id)
            if released:
                console.print("[green]Lock released. You can now send messages.[/green]")
                toast("Stream unlocked", level="info")
            else:
                console.print("[yellow]No active lock found (or server could not release it).[/yellow]")
            return True
        elif command == "/sandbox":
            from .agent import set_sandbox, _sandbox_enabled
            if not args.strip():
                status = "[green]ON[/green]" if _sandbox_enabled else "[red]OFF[/red]"
                console.print(f"[cyan]Command sandbox:[/cyan] {status}")
                console.print("[dim]  Blocks dangerous commands (rm -rf /, sudo, curl|bash, etc.)")
                console.print("  /sandbox off  — disable  |  /sandbox on  — enable[/dim]")
            elif args.strip().lower() in ("on", "true", "1"):
                set_sandbox(True)
                console.print("[green]Sandbox: ON[/green]")
            elif args.strip().lower() in ("off", "false", "0"):
                set_sandbox(False)
                console.print("[bold yellow]⚠ Sandbox: OFF — dangerous commands allowed[/bold yellow]")
                console.print("[dim]  Sandbox will auto-re-enable after the current agent loop completes.[/dim]")
        elif command == "/simple":
            self.agent_mode = False
            console.print("Mode: [yellow]Simple[/yellow]")
        elif command == "/agent":
            if not args.strip():
                # Toggle agent mode
                self.agent_mode = True
                console.print("Mode: [green]Agent[/green]")
            else:
                # Spawn background subagent with task
                allowed, msg = check_tier(self.user, "swarm")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    aid = str(uuid.uuid4())[:8]
                    console.print(f"[cyan]Spawning agent {aid}...[/cyan]")
                    try:
                        response = await self.client.chat_once(
                            args.strip(),
                            model=self.model,
                            permission_context=self._get_permission_context(),
                        )

                        self.subagents.append({"id": aid, "task": args.strip(), "result": response[:2000]})
                        console.print(Panel(Markdown(response[:2000]), title=f"Agent {aid}", border_style="magenta"))
                    except Exception as e:
                        console.print(f"[red]Agent failed: {e}[/red]")
        elif command == "/vim":
            self.vim_mode = not self.vim_mode
            st = "[green]ON[/green]" if self.vim_mode else "[red]OFF[/red]"
            console.print(f"Vim mode: {st}")
        elif command == "/fast":
            self.fast_mode = not self.fast_mode
            st = "[green]ON[/green]" if self.fast_mode else "[red]OFF[/red]"
            console.print(f"Fast mode: {st}")
        elif command == "/effort":
            if args.strip() in ("low", "medium", "high"):
                self.effort = args.strip()
                console.print(f"[green]Effort: {self.effort}[/green]")
            else:
                console.print(f"Current: {self.effort}. Options: low, medium, high")
        elif command == "/write":
            if not args.strip():
                console.print("[yellow]Usage: /write <path>[/yellow]")
            else:
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath:
                    console.print("[red]Path outside project root[/red]")
                    return True
                console.print("[cyan]Enter content (empty line to finish):[/cyan]")
                lines = []
                while True:
                    try:
                        line = console.input("[dim]| [/dim]")
                        if line == "":
                            break
                        lines.append(line)
                    except (KeyboardInterrupt, EOFError):
                        break
                if lines:
                    content = "\n".join(lines)
                    fpath.parent.mkdir(parents=True, exist_ok=True)
                    fpath.write_text(content, encoding="utf-8")
                    self._track_file(args.strip())
                    _run_hooks("on_file_write", self.hooks, self.project_root)
                    console.print(f"[green]Wrote {len(content)} bytes[/green]")
        elif command == "/edit":
            if not args.strip():
                console.print("[yellow]Usage: /edit <path>[/yellow]")
            else:
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath or not fpath.is_file():
                    console.print(f"[red]File not found: {args}[/red]")
                else:
                    instruction = console.input("[cyan]What to change: [/cyan]")
                    if instruction.strip():
                        original = fpath.read_text(encoding="utf-8", errors="ignore")
                        ep = (
                            f"Edit this file: {args.strip()}\n"
                            f"Instruction: {instruction}\n\n"
                            f"```\n{original[:30000]}\n```\n\n"
                            "Return ONLY the unified diff."
                        )
                        ep_parts = []
                        try:
                            async for chunk in self.client.stream_chat(
                                chat_id=str(uuid.uuid4()), prompt=ep, model=self.model,
                            ):
                                if not isinstance(chunk, dict):
                                    continue
                                if chunk.get("content"):
                                    ep_parts.append(chunk["content"])
                            diff_text = "".join(ep_parts)
                            console.print(Syntax(diff_text, "diff", theme="monokai"))
                            confirm = console.input("[cyan]Apply? (y/n): [/cyan]")
                            if confirm.strip().lower() in ("y", "yes"):
                                try:
                                    r = await self.client.apply_diff(original, diff_text)
                                    applied = r.get("applied_content", "")
                                    if applied:
                                        fpath.write_text(applied, encoding="utf-8")
                                        self._track_file(args.strip())
                                        _run_hooks("on_file_write", self.hooks, self.project_root)
                                        console.print(f"[green]Applied[/green]")
                                    else:
                                        console.print("[yellow]Could not apply diff[/yellow]")
                                except Exception as e:
                                    console.print(f"[red]Apply failed: {e}[/red]")
                        except Exception as e:
                            console.print(f"[red]{type(e).__name__}: {e}[/red]")
        elif command in ("/mention", "/attach"):
            sub = args.strip()
            if not sub:
                console.print("[yellow]Usage: /attach <path>  |  /attach list  |  /attach clear[/yellow]")
            elif sub.lower() == "list":
                if not self.pending_attachments:
                    console.print("[dim]No pending attachments.[/dim]")
                else:
                    console.print(f"[cyan]Pending attachments ({len(self.pending_attachments)}):[/cyan]")
                    for i, att in enumerate(self.pending_attachments, 1):
                        att_type = "image" if att.get("content", "").startswith("data:image") else "text"
                        console.print(f"  {i}. [bold]{att['name']}[/bold] ({att_type})")
            elif sub.lower() == "clear":
                n = len(self.pending_attachments)
                self.pending_attachments.clear()
                console.print(f"[green]Cleared {n} pending attachment(s).[/green]")
            else:
                import base64 as _b64
                # Try as absolute path first, then relative to project root
                raw_path = _normalize_local_path_arg(sub)
                abs_candidate = Path(raw_path)
                if abs_candidate.is_absolute() and abs_candidate.is_file():
                    fpath: Optional[Path] = abs_candidate
                else:
                    fpath = _safe_path(self.project_root, raw_path)
                    if fpath and not fpath.is_file():
                        fpath = None

                if fpath is None or not fpath.is_file():
                    # Fuzzy match suggestions
                    suggestions = _fuzzy_suggest_paths(self.project_root, raw_path)
                    console.print(f"[red]File not found: {sub}[/red]")
                    if suggestions:
                        console.print("[yellow]Did you mean?[/yellow]")
                        for s in suggestions:
                            console.print(f"  [dim]{s}[/dim]")
                else:
                    ext = fpath.suffix.lower()
                    kb = fpath.stat().st_size // 1024
                    if ext in _IMAGE_EXTS:
                        # Encode as base64 image attachment
                        try:
                            with self._show_progress(f"Reading {fpath.name}…") as _att_prog:
                                _att_prog.add_task(f"Reading {fpath.name}…", total=None)
                                data = fpath.read_bytes()
                            if len(data) > 10 * 1024 * 1024:
                                console.print("[red]Image too large (10MB max).[/red]")
                            else:
                                b64 = _b64.b64encode(data).decode("ascii")
                                mime_map = {
                                    ".png": "image/png", ".jpg": "image/jpeg",
                                    ".jpeg": "image/jpeg", ".gif": "image/gif",
                                    ".webp": "image/webp", ".bmp": "image/bmp",
                                }
                                mime = mime_map.get(ext, "image/png")
                                uri = f"data:{mime};base64,{b64}"
                                self.pending_attachments.append({"name": fpath.name, "content": uri})
                                console.print(f"[green]Attached: {fpath.name} ({kb}KB). Will be included in your next message.[/green]")
                                _vision_preview(fpath)
                        except Exception as e:
                            console.print(f"[red]Could not read image: {e}[/red]")
                    else:
                        # Text/code file — include as context
                        try:
                            with self._show_progress(f"Reading {fpath.name}…") as _att_prog:
                                _att_prog.add_task(f"Reading {fpath.name}…", total=None)
                                content = fpath.read_text(encoding="utf-8", errors="ignore")[:30000]
                            self.pending_attachments.append({"name": fpath.name, "content": content})
                            console.print(f"[green]Attached: {fpath.name} ({kb}KB). Will be included in your next message.[/green]")
                        except Exception as e:
                            console.print(f"[red]Could not read file: {e}[/red]")
        elif command == "/image":
            if not args.strip():
                console.print("[yellow]Usage: /image <path>[/yellow]")
            else:
                import base64
                fpath = _safe_path(self.project_root, args.strip())
                if not fpath:
                    console.print("[red]Path outside project root.[/red]")
                elif not fpath.is_file():
                    console.print(f"[red]File not found: {args}[/red]")
                else:
                    try:
                        data = fpath.read_bytes()
                        if len(data) > 10 * 1024 * 1024:
                            console.print("[red]Image too large (10MB max).[/red]")
                        else:
                            b64 = base64.b64encode(data).decode("ascii")
                            ext = fpath.suffix.lower().lstrip(".")
                            mime_map = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}
                            mime = mime_map.get(ext, "image/png")
                            kb = len(data) // 1024
                            # Full base64 data URI — NOT truncated
                            uri = f"data:{mime};base64,{b64}"
                            self.pending_attachments.append({"name": args.strip(), "content": uri})
                            console.print(f"[green]Image attached: {args.strip()} ({kb}KB)[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")
        elif command in ("/paste", "/paste-image"):
            import base64 as _cb64
            import io as _cio
            try:
                img = _grab_clipboard_image()
                if img is None:
                    console.print("[yellow]No image in clipboard. Copy an image first.[/yellow]")
                    console.print("[dim]Tip: right-click an image and choose Copy, then run /paste-image[/dim]")
                else:
                    buf = _cio.BytesIO()
                    img.save(buf, format="PNG")
                    raw = buf.getvalue()
                    w, h = img.size
                    kb = len(raw) // 1024
                    b64 = _cb64.b64encode(raw).decode("ascii")
                    uri = f"data:image/png;base64,{b64}"
                    self.pending_attachments.append({"name": "clipboard.png", "content": uri})
                    console.print(
                        f"[green]Image captured from clipboard ({w}x{h}, {kb}KB). "
                        f"Will be attached to your next message.[/green]"
                    )
                    _vision_preview(img)
            except ImportError:
                console.print("[yellow]Install Pillow for clipboard image support: pip install Pillow[/yellow]")
            except Exception as e:
                console.print(f"[red]Clipboard paste error: {e}[/red]")
        elif command == "/agents":
            try:
                tokens = shlex.split(args) if args.strip() else ["list"]
            except ValueError as exc:
                console.print(f"[red]Invalid /agents arguments: {exc}[/red]")
                return True

            sub = (tokens[0] if tokens else "list").lower()
            rest = tokens[1:] if len(tokens) > 1 else []

            if sub in {"list", "ls"}:
                enabled_only = "--enabled-only" in rest
                agents = list_registry_agents(enabled_only=enabled_only)
                if not agents:
                    console.print("[yellow]No agents configured.[/yellow]")
                    return True
                table = Table(title="Agent Registry")
                table.add_column("#", style="cyan", width=3)
                table.add_column("ID", style="bold")
                table.add_column("Name")
                table.add_column("Model")
                table.add_column("Enabled", justify="center")
                table.add_column("Max", justify="right")
                table.add_column("Tags")
                for idx, agent in enumerate(agents, 1):
                    table.add_row(
                        str(idx),
                        agent.id,
                        agent.name,
                        agent.model,
                        "yes" if agent.enabled else "no",
                        str(agent.max_parallel),
                        ",".join(agent.tags) if agent.tags else "—",
                    )
                console.print(table)
            elif sub == "reload":
                reset = "--reset" in rest
                agents = reload_agent_registry(reset=reset)
                action = "Reset" if reset else "Reloaded"
                console.print(f"[green]{action} agent registry.[/green] ({len(agents)} agent(s))")
            elif sub in {"enable", "disable"}:
                if not rest:
                    console.print(f"[yellow]Usage: /agents {sub} <id|name|index>[/yellow]")
                    return True
                ref = rest[0]
                try:
                    updated = set_registry_agent_enabled(ref, sub == "enable")
                except KeyError as exc:
                    console.print(f"[red]{exc}[/red]")
                    return True
                state = "enabled" if updated.enabled else "disabled"
                console.print(f"[green]{updated.id} {state}[/green]")
            elif sub == "config":
                if not rest:
                    console.print(
                        "[yellow]Usage: /agents config <id|name|index> "
                        "[--model <id>] [--name <name>] [--max-parallel <n>] "
                        "[--tags a,b] [--description <text>][/yellow]"
                    )
                    return True
                ref = rest[0]
                model_opt: Optional[str] = None
                name_opt: Optional[str] = None
                desc_opt: Optional[str] = None
                max_parallel_opt: Optional[int] = None
                tags_opt: Optional[List[str]] = None
                i = 1
                while i < len(rest):
                    tok = rest[i]
                    if tok == "--model" and i + 1 < len(rest):
                        model_opt = rest[i + 1]
                        i += 2
                        continue
                    if tok == "--name" and i + 1 < len(rest):
                        name_opt = rest[i + 1]
                        i += 2
                        continue
                    if tok == "--description" and i + 1 < len(rest):
                        desc_opt = rest[i + 1]
                        i += 2
                        continue
                    if tok == "--max-parallel" and i + 1 < len(rest):
                        try:
                            max_parallel_opt = int(rest[i + 1])
                        except ValueError:
                            console.print("[red]--max-parallel requires an integer.[/red]")
                            return True
                        i += 2
                        continue
                    if tok == "--tags" and i + 1 < len(rest):
                        tags_opt = [t.strip() for t in rest[i + 1].split(",") if t.strip()]
                        i += 2
                        continue
                    console.print(f"[red]Unknown /agents config option: {tok}[/red]")
                    return True
                try:
                    updated = configure_registry_agent(
                        ref,
                        model=model_opt,
                        name=name_opt,
                        description=desc_opt,
                        max_parallel=max_parallel_opt,
                        tags=tags_opt,
                    )
                except KeyError as exc:
                    console.print(f"[red]{exc}[/red]")
                    return True
                console.print(f"[green]Updated[/green] {updated.id} -> {updated.model}")
            else:
                console.print(
                    "[yellow]Usage: /agents [list|reload|enable|disable|config] ...[/yellow]"
                )
        elif command == "/multi":
            if not args.strip():
                console.print("[yellow]Usage: /multi <prompt> [--strict][/yellow]")
            else:
                prompt_text = args.strip()
                is_strict = "--strict" in prompt_text
                if is_strict:
                    prompt_text = prompt_text.replace("--strict", "").strip()
                
                allowed, msg = check_tier(self.user, "multi")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    console.print("[cyan]Running multi-model...[/cyan]")
                    try:
                        # 3 attempts with transient retry envelope
                        final_results = []
                        models_to_run = default_models_from_registry(limit=3)
                        if not models_to_run:
                            models_to_run = [
                                "google/gemini-2.0-flash-001",
                                "anthropic/claude-3-haiku",
                                "openai/gpt-4o-mini",
                            ]
                        command_correlation_id = uuid.uuid4().hex[:12]
                        permission_context = self._get_permission_context(correlation_id=command_correlation_id)
                        provider_hint = await self._provider_fanout_hint()
                        fanout_cap = _adaptive_fanout_cap(
                            models_to_run,
                            command_name="/multi",
                            provider_hint=provider_hint,
                        )
                        violations = _lane_cap_violations(models_to_run)
                        if violations:
                            console.print("[red]Model fanout exceeds configured agent max_parallel budget.[/red]")
                            for row in violations:
                                console.print(f"[red]- {row}[/red]")
                            return True
                        
                        for attempt in range(3):
                            results = []
                            for i in range(0, len(models_to_run), fanout_cap):
                                chunk = models_to_run[i : i + fanout_cap]
                                chunk_rows = await self.client.multi_chat(
                                    prompt_text,
                                    chunk,
                                    permission_context=permission_context,
                                )
                                results.extend(chunk_rows)
                            
                            # Process results, find retryable failures
                            retryable_models = []
                            for r in results:
                                if r["status"] == "ok":
                                    # Deduplicate by model if we have multiple attempts
                                    if not any(fr["model"] == r["model"] for fr in final_results):
                                        final_results.append(r)
                                elif r.get("retryable") and attempt < 2:
                                    retryable_models.append(r["model"])
                                else:
                                    # Non-retryable or last attempt
                                    if not any(fr["model"] == r["model"] for fr in final_results):
                                        final_results.append(r)
                            
                            if not retryable_models:
                                break
                            
                            models_to_run = retryable_models
                            wait = 0.5 * (2 ** attempt)
                            console.print(f"[dim]Retrying {len(retryable_models)} models in {wait}s...[/dim]")
                            await asyncio.sleep(wait)

                        # Render results
                        for r in final_results:
                            color = "green" if r["status"] == "ok" else "red"
                            label = f"[{color}]{r['model']}[/{color}]"
                            if r["status"] == "ok":
                                body = Markdown(r["response"][:2000])
                                console.print(Panel(body, title=label, border_style=color))
                            else:
                                console.print(f"{label}: [red]FAILED[/red] ({r.get('error_code', 'unknown')})")
                                if r.get("error"):
                                    console.print(f"  [dim]{r['error']}[/dim]")

                        # Enforce strict mode exits
                        all_ok = all(r["status"] == "ok" for r in final_results)
                        if is_strict and not all_ok:
                            console.print("[bold red]Strict mode: one or more models failed. Exiting.[/bold red]")
                            return False
                        
                        # If all failed, nonzero exit semantic (in non-interactive this would exit)
                        if not any(r["status"] == "ok" for r in final_results):
                            console.print("[yellow]All model paths failed.[/yellow]")

                    except Exception as e:
                        console.print(f"[red]Multi-chat failed: {e}[/red]")
        elif command == "/swarm":
            if not args.strip():
                console.print("[yellow]Usage: /swarm <prompt> [--strict][/yellow]")
            else:
                prompt_text = args.strip()
                is_strict = "--strict" in prompt_text
                if is_strict:
                    prompt_text = prompt_text.replace("--strict", "").strip()
                
                allowed, msg = check_tier(self.user, "swarm")
                if not allowed:
                    console.print(f"[yellow]{msg}[/yellow]")
                else:
                    console.print("[cyan]Running swarm...[/cyan]")
                    try:
                        # 3 attempts with transient retry envelope
                        final_result = None
                        swarm_models = default_models_from_registry(limit=3)
                        if not swarm_models:
                            swarm_models = [
                                "google/gemini-2.0-flash-001",
                                "anthropic/claude-3-haiku",
                                "openai/gpt-4o-mini",
                            ]
                        command_correlation_id = uuid.uuid4().hex[:12]
                        permission_context = self._get_permission_context(correlation_id=command_correlation_id)
                        provider_hint = await self._provider_fanout_hint()
                        fanout_cap = _adaptive_fanout_cap(
                            swarm_models,
                            command_name="/swarm",
                            provider_hint=provider_hint,
                        )
                        violations = _lane_cap_violations(swarm_models)
                        if violations:
                            console.print("[red]Model fanout exceeds configured agent max_parallel budget.[/red]")
                            for row in violations:
                                console.print(f"[red]- {row}[/red]")
                            return True
                        for attempt in range(3):
                            if len(swarm_models) > fanout_cap:
                                agent_rows = []
                                for i in range(0, len(swarm_models), fanout_cap):
                                    chunk = swarm_models[i : i + fanout_cap]
                                    chunk_rows = await self.client.multi_chat(
                                        prompt_text,
                                        chunk,
                                        permission_context=permission_context,
                                    )
                                    agent_rows.extend(chunk_rows)
                                judge_model = swarm_models[0] if swarm_models else self.model
                                synthesis = ""
                                if judge_model:
                                    synthesis_parts = []
                                    for row in agent_rows:
                                        status = "OK" if row.get("status") == "ok" else "FAILED"
                                        snippet = str(row.get("response") or row.get("error") or "")[:2000]
                                        synthesis_parts.append(f"[{row.get('model', '?')} - {status}]:\n{snippet}")
                                    synthesis_prompt = (
                                        "You are a synthesis judge. Multiple AI models were asked the same question.\n\n"
                                        f"Original question: {prompt_text}\n\n"
                                        "Their responses:\n\n"
                                        + "\n\n---\n\n".join(synthesis_parts)
                                        + "\n\nSynthesize the best answer. Combine strengths, note disagreements, give a final answer."
                                    )
                                    synthesis = await self.client.chat_once(
                                        synthesis_prompt,
                                        judge_model,
                                        permission_context=permission_context,
                                    )
                                result = {
                                    "agent_responses": agent_rows,
                                    "synthesis": synthesis,
                                    "judge_model": judge_model,
                                    "models_used": list(swarm_models),
                                }
                            else:
                                result = await self.client.swarm(
                                    prompt_text,
                                    models=swarm_models,
                                    permission_context=permission_context,
                                )
                            # Check if synthesis is empty but agents succeeded (rare but possible)
                            # Or if all agents failed.
                            any_ok = any(r["status"] == "ok" for r in result.get("agent_responses", []))
                            if any_ok or not result.get("agent_responses"):
                                final_result = result
                                break
                            
                            if attempt < 2:
                                wait = 1.0 * (2 ** attempt)
                                console.print(f"[dim]Swarm failed to get healthy responses. Retrying in {wait}s...[/dim]")
                                await asyncio.sleep(wait)
                            else:
                                final_result = result

                        if final_result:
                            for r in final_result["agent_responses"]:
                                color = "green" if r["status"] == "ok" else "red"
                                console.print(f"[dim]-- {r['model']} --[/dim]")
                                if r["status"] == "ok":
                                    console.print(Markdown(r["response"][:1000]))
                                else:
                                    console.print(f"[red]FAILED[/red] ({r.get('error_code', 'unknown')})")
                            
                            if final_result.get("synthesis"):
                                console.print(Panel(Markdown(final_result["synthesis"]), title="Synthesis", border_style="cyan"))
                            
                            # Enforce strict mode
                            any_ok = any(r["status"] == "ok" for r in final_result.get("agent_responses", []))
                            if is_strict and not any_ok:
                                console.print("[bold red]Strict mode: all swarm agents failed. Exiting.[/bold red]")
                                return False

                    except Exception as e:
                        console.print(f"[red]Swarm failed: {e}[/red]")
        elif command == "/rewind":
            n = 2
            if args.strip().isdigit():
                n = int(args.strip())
            if len(self.messages) < n:
                console.print(f"[yellow]Only {len(self.messages)} messages[/yellow]")
            else:
                removed = self.messages[-n:]
                self._rewind_buffer = removed  # Save for /redo
                self.messages = self.messages[:-n]
                # Adjust cost/token counts for removed messages (best-effort estimate)
                for m in removed:
                    tokens_est = len(m.get("content", "")) // 4
                    self.tokens_total = max(0, self.tokens_total - tokens_est)
                console.print(f"[green]Rewound {n} messages.[/green]")
                console.print("[dim]Use /undo to restore.[/dim]")
        elif command == "/undo":
            if not self._rewind_buffer:
                console.print("[yellow]Nothing to undo.[/yellow]")
            else:
                self.messages.extend(self._rewind_buffer)
                for m in self._rewind_buffer:
                    tokens_est = len(m.get("content", "")) // 4
                    self.tokens_total += tokens_est
                n_restored = len(self._rewind_buffer)
                self._rewind_buffer = []
                console.print(f"[green]Restored {n_restored} message(s).[/green]")
        elif command == "/redo":
            if not self._rewind_buffer:
                console.print("[yellow]Nothing to redo.[/yellow]")
            else:
                self.messages.extend(self._rewind_buffer)
                for m in self._rewind_buffer:
                    tokens_est = len(m.get("content", "")) // 4
                    self.tokens_total += tokens_est
                n_restored = len(self._rewind_buffer)
                self._rewind_buffer = []
                console.print(f"[green]Restored {n_restored} message(s).[/green]")
        elif command == "/fork":
            old_session_id = self.session_id
            old_chat_id = self.chat_id
            self._save()
            self.session_id = str(uuid.uuid4())[:12]
            self.client.set_session_id(self.session_id)
            # Create a new server-side chat for the fork so API calls go to a new conversation
            if self.project_name:
                try:
                    new_chat = await self.client.create_chat(self.project_name)
                    self.chat_id = new_chat.get("chat_id") or new_chat.get("id") or old_chat_id
                except Exception:
                    pass  # Keep old chat_id if API call fails
            console.print(f"[green]Forked {old_session_id} -> {self.session_id}[/green]")
            self._save()
        elif command == "/copy":
            # Copy last assistant response to clipboard
            last_response = ""
            for m in reversed(self.messages):
                if m.get("role") == "assistant":
                    last_response = m.get("content", "")
                    break
            if not last_response:
                console.print("[yellow]No response to copy.[/yellow]")
            else:
                try:
                    import subprocess as _sp
                    # Try platform-native clipboard
                    if sys.platform == "win32":
                        _sp.run(["clip"], input=last_response.encode("utf-8"), check=True)
                    elif sys.platform == "darwin":
                        _sp.run(["pbcopy"], input=last_response.encode("utf-8"), check=True)
                    else:
                        _sp.run(["xclip", "-selection", "clipboard"], input=last_response.encode("utf-8"), check=True)
                    console.print(f"[green]Copied {len(last_response)} chars to clipboard.[/green]")
                except Exception:
                    # Fallback: print it so user can manually copy
                    console.print("[yellow]Clipboard not available. Last response:[/yellow]")
                    console.print(last_response[:500])
        elif command == "/profile":
            from .context_profiles import load_profile, list_profiles, BUILTIN_PROFILES
            if not args or args.strip() == "list":
                names = list(BUILTIN_PROFILES.keys())
                user_names = list_profiles()
                console.print("[cyan]Built-in profiles:[/cyan] " + ", ".join(names))
                if user_names:
                    console.print("[cyan]User profiles:[/cyan] " + ", ".join(user_names))
                console.print("[dim]Usage: /profile <name>  — inject profile files into context[/dim]")
            else:
                name = args.strip()
                profile = load_profile(name, self.project_root or Path("."))
                if profile is None:
                    console.print(f"[yellow]Profile '{name}' not found. Use /profile list.[/yellow]")
                else:
                    # Inject pre-loaded context into the next system message
                    ctx = profile.get("context", "")
                    suffix = profile.get("system_suffix", "")
                    if ctx or suffix:
                        injection = f"[Profile: {name}]\n{ctx}\n{suffix}".strip()
                        self.messages.append({"role": "user", "content": f"<context_profile name=\"{name}\">\n{injection}\n</context_profile>"})
                        self.messages.append({"role": "assistant", "content": f"Context profile '{name}' loaded: {profile.get('description', name)}"})
                    console.print(f"[green]Profile '{name}' loaded: {profile.get('description', name)}[/green]")
                    for f in profile.get("files", []):
                        console.print(f"  [dim]+ {f}[/dim]")
        elif command == "/export":
            # Export conversation — supports /export [format] [filename]
            # Formats: md (default), html, pdf
            # Examples: /export  /export html  /export pdf report.pdf
            _export_parts = args.strip().split() if args.strip() else []
            _export_fmt = "md"
            _export_file: Optional[str] = None

            if _export_parts:
                if _export_parts[0].lower() in ("md", "html", "pdf"):
                    _export_fmt = _export_parts[0].lower()
                    _export_file = _export_parts[1] if len(_export_parts) > 1 else None
                else:
                    # Treat first arg as filename, infer format from extension
                    _export_file = _export_parts[0]
                    _ext = Path(_export_file).suffix.lower().lstrip(".")
                    if _ext in ("html", "pdf", "md"):
                        _export_fmt = _ext

            _export_file = _export_file or f"msapling-export-{self.session_id}.{_export_fmt}"
            _export_path = Path(_export_file)

            # Build a session dict from current live state
            from .session import SessionMetadata as _SMeta
            _live_meta = _SMeta(
                session_id=self.session_id,
                project_name=self.project_name,
                models_used=list(dict.fromkeys(self.models_used)),
                files_touched=list(self.files_touched),
                slash_commands_used=list(self.slash_commands_used),
                total_cost_usd=self.cost_total,
                total_tokens_in=self.tokens_in,
                total_tokens_out=self.tokens_out,
                turn_count=self.turn_count,
            )
            _live_session: Dict[str, Any] = {
                "id": self.session_id,
                "messages": list(self.messages),
                "model": self.model,
                "project_root": self.project_root,
                "cost_total": self.cost_total,
                "tokens_total": self.tokens_total,
                "metadata": _live_meta.to_dict(),
            }

            try:
                from .export_formats import export_markdown, export_html, export_pdf
                if _export_fmt == "html":
                    _result_path = export_html(_live_session, _export_path)
                elif _export_fmt == "pdf":
                    _result_path = export_pdf(_live_session, _export_path)
                else:
                    _result_path = export_markdown(_live_session, _export_path)
                _fsize = _result_path.stat().st_size
                console.print(f"[green]Exported to {_result_path}[/green]  [dim]({_fsize:,} bytes)[/dim]")
            except Exception as e:
                console.print(f"[red]Export failed: {e}[/red]")
        elif command == "/restore":
            # Restore a file from backup
            if not args.strip():
                from .storage import list_backups
                backups = list_backups(self.session_id)
                if not backups:
                    console.print("[yellow]No backups for this session.[/yellow]")
                else:
                    console.print(f"[cyan]Backups ({len(backups)}):[/cyan]")
                    for i, b in enumerate(backups[:20], 1):
                        console.print(f"  {i}. {b['name']}  ({b['size']} bytes)")
                    console.print("[dim]Usage: /restore <filename>[/dim]")
            else:
                from .storage import list_backups
                _restore_args = args.strip()
                _dry_run = False
                if _restore_args.endswith(" --dry-run") or _restore_args.startswith("--dry-run "):
                    _dry_run = True
                    target = _restore_args.replace("--dry-run", "").strip()
                else:
                    target = _restore_args
                backups = list_backups(self.session_id)
                found = None
                for b in backups:
                    if target in b["name"]:
                        found = b
                        break
                if not found:
                    console.print(f"[yellow]Backup not found: {target}[/yellow]")
                else:
                    from pathlib import Path as _Path
                    backup_path = _Path.home() / ".msapling" / "backups" / self.session_id / found["name"]
                    try:
                        content = backup_path.read_text(encoding="utf-8")
                        # Extract original filename from backup name (strip timestamp suffix)
                        orig_name = found["name"].rsplit(".", 1)[0].replace("_", "/")
                        safe_restore_path = _safe_path(self.project_root, orig_name)
                        if safe_restore_path is None:
                            console.print("[red]Invalid backup path[/red]")
                            return
                        if _dry_run:
                            # Preview mode: show what would be restored without writing.
                            lines = content.splitlines()
                            preview = "\n".join(lines[:20]) + (f"\n... ({len(lines)} total lines)" if len(lines) > 20 else "")
                            console.print(Panel(
                                f"[dim]{preview}[/dim]",
                                title=f"[cyan]Preview: {orig_name}[/cyan] ({found['size']} bytes)",
                                border_style="cyan",
                            ))
                            console.print(f"[dim]Run /restore {target} (without --dry-run) to apply.[/dim]")
                        else:
                            from rich.prompt import Confirm
                            console.print(f"[cyan]File:[/cyan] {orig_name}  [cyan]Size:[/cyan] {found['size']} bytes")
                            if not Confirm.ask("Restore this file? Current file will be replaced.", default=False):
                                console.print("[dim]Cancelled.[/dim]")
                                return True
                            safe_restore_path.write_text(content, encoding="utf-8")
                            console.print(f"[green]Restored {orig_name} from backup.[/green]")
                    except Exception as e:
                        console.print(f"[red]Restore failed: {e}[/red]")
        elif command == "/diff":
            # Interactive git diff viewer
            try:
                r = subprocess.run(
                    ["git", "diff", "--stat"], cwd=self.project_root,
                    capture_output=True, text=True, timeout=10,
                )
                if not r.stdout.strip():
                    console.print("[yellow]No uncommitted changes.[/yellow]")
                else:
                    console.print(Panel(
                        Syntax(r.stdout[:3000], "diff", theme="monokai"),
                        title="[cyan]Uncommitted Changes (summary)[/cyan]",
                        border_style="cyan",
                    ))
                    # Full diff
                    r2 = subprocess.run(
                        ["git", "diff"], cwd=self.project_root,
                        capture_output=True, text=True, timeout=10,
                    )
                    if r2.stdout:
                        console.print(Syntax(r2.stdout[:8000], "diff", theme="monokai", line_numbers=True))
                        if len(r2.stdout) > 8000:
                            console.print(f"[dim]... {len(r2.stdout) - 8000} more chars (use /git diff for full)[/dim]")
            except Exception as e:
                console.print(f"[red]{e}[/red]")
        elif command == "/hooks":
            if not args.strip():
                if self.hooks:
                    for event, cmds in self.hooks.items():
                        console.print(f"  [cyan]{event}:[/cyan]")
                        for hc in cmds:
                            console.print(f"    {hc}")
                else:
                    console.print("[yellow]No hooks configured.[/yellow]")
            else:
                hp = args.split(maxsplit=2)
                if len(hp) >= 3 and hp[0] == "add":
                    ev, hc = hp[1], hp[2]
                    if ev not in self.hooks:
                        self.hooks[ev] = []
                    self.hooks[ev].append(hc)
                    _save_hooks(self.hooks)
                    console.print(f"[green]Added hook: {ev} -> {hc}[/green]")
                elif len(hp) >= 2 and hp[0] == "remove":
                    ev = hp[1]
                    if ev in self.hooks:
                        del self.hooks[ev]
                        _save_hooks(self.hooks)
                        console.print(f"[green]Removed hooks for: {ev}[/green]")
                elif hp[0] == "clear":
                    self.hooks.clear()
                    _save_hooks(self.hooks)
                    console.print("[green]All hooks cleared[/green]")
        elif command == "/mdrive":
            sub_parts = args.split() if args.strip() else ["status"]
            sub = sub_parts[0].lower()
            sub_arg = sub_parts[1] if len(sub_parts) > 1 else ""
            sub_arg2 = sub_parts[2] if len(sub_parts) > 2 else ""

            if sub == "status":
                console.print(f"  [cyan]Project:[/cyan]  {self.project_name}")
                try:
                    usage = await self.client.mdrive_usage()
                    total_bytes = usage.get("total_bytes", 0)
                    total_files = usage.get("total_files", 0)
                    kb = total_bytes / 1024 if total_bytes else 0
                    console.print(f"  [cyan]Storage:[/cyan]  {kb:.1f} KB across {total_files} files")
                except Exception:
                    console.print("  [dim]Storage stats unavailable[/dim]")
                console.print("  [dim]Commands: ls, push, pull, sync, history, trash, search[/dim]")

            elif sub == "ls":
                path = sub_arg or "/"
                try:
                    files = await self.client.list_files(self.project_name, path)
                    if not files:
                        console.print("[yellow]No files.[/yellow]")
                    else:
                        table = Table(title=f"MDrive: {self.project_name}{path}")
                        table.add_column("Name", style="cyan")
                        table.add_column("Size", justify="right")
                        table.add_column("Modified")
                        for f in files[:50]:
                            name = f.get("name", f.get("file_path", "?"))
                            size = f.get("size", f.get("size_bytes", 0))
                            modified = str(f.get("modified", f.get("updated_at", "")))[:19]
                            size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
                            table.add_row(name, size_str, modified)
                        console.print(table)
                except Exception as e:
                    console.print(f"[red]{e}[/red]")

            elif sub == "push":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive push <file|glob>[/yellow]")
                else:
                    import glob as _glob
                    pattern = str(Path(self.project_root) / sub_arg)
                    matches = _glob.glob(pattern, recursive=True)
                    if not matches:
                        # Try as single file
                        fpath = Path(self.project_root) / sub_arg
                        if fpath.is_file():
                            matches = [str(fpath)]
                        else:
                            console.print(f"[red]No files matched: {sub_arg}[/red]")
                    pushed = 0
                    for fpath_str in matches:
                        fpath = Path(fpath_str)
                        if not fpath.is_file():
                            continue
                        rel = os.path.relpath(fpath_str, self.project_root).replace("\\", "/")
                        try:
                            content = fpath.read_text(encoding="utf-8", errors="ignore")
                            await self.client.mdrive_write(
                                self.project_name, rel, content,
                                agent_id="cli", change_summary=f"Pushed from CLI",
                            )
                            console.print(f"  [green]Pushed {rel}[/green]")
                            pushed += 1
                        except Exception as e:
                            console.print(f"  [red]{rel}: {e}[/red]")
                    if pushed > 1:
                        console.print(f"[green]{pushed} files pushed.[/green]")

            elif sub == "pull":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive pull <file>[/yellow]")
                else:
                    safe_pull_path = _safe_path(self.project_root, sub_arg)
                    if safe_pull_path is None:
                        console.print("[red]Invalid file path[/red]")
                    else:
                        try:
                            content = await self.client.mdrive_read(self.project_name, sub_arg)
                            safe_pull_path.parent.mkdir(parents=True, exist_ok=True)
                            safe_pull_path.write_text(content, encoding="utf-8")
                            console.print(f"[green]Pulled {sub_arg} ({len(content)} bytes)[/green]")
                        except Exception as e:
                            console.print(f"[red]{e}[/red]")

            elif sub == "sync":
                console.print("[cyan]Syncing local ↔ MDrive...[/cyan]")
                try:
                    remote_files = await self.client.list_files(self.project_name)
                    remote_set = {f.get("name", f.get("file_path", "")): f for f in remote_files}
                    # Pull remote files that don't exist locally
                    pulled = 0
                    for name, meta in remote_set.items():
                        local_path = Path(self.project_root) / name
                        if not local_path.exists():
                            try:
                                content = await self.client.mdrive_read(self.project_name, name)
                                local_path.parent.mkdir(parents=True, exist_ok=True)
                                local_path.write_text(content, encoding="utf-8")
                                pulled += 1
                            except Exception:
                                pass
                    console.print(f"  [green]Pulled {pulled} new files from MDrive.[/green]")
                except Exception as e:
                    console.print(f"[red]Sync failed: {e}[/red]")

            elif sub == "history":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive history <file>[/yellow]")
                else:
                    try:
                        versions = await self.client.mdrive_versions(self.project_name, sub_arg)
                        if not versions:
                            console.print(f"[yellow]No version history for {sub_arg}[/yellow]")
                        else:
                            table = Table(title=f"Versions: {sub_arg}")
                            table.add_column("#", style="cyan")
                            table.add_column("Version")
                            table.add_column("Size", justify="right")
                            table.add_column("By")
                            table.add_column("Date")
                            table.add_column("Summary")
                            for v in versions[:20]:
                                ver_num = str(v.get("version_number", "?"))
                                size = v.get("size_bytes", 0)
                                by = v.get("created_by_agent", v.get("created_by_user", "?"))[:15]
                                date = str(v.get("created_at", ""))[:19]
                                summary = (v.get("change_summary", "") or "")[:40]
                                table.add_row(ver_num, v.get("id", "?")[:8], f"{size:,}", by, date, summary)
                            console.print(table)
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "restore":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive restore <file> [version_id][/yellow]")
                else:
                    try:
                        result = await self.client.mdrive_restore(self.project_name, sub_arg, sub_arg2)
                        console.print(f"[green]Restored {sub_arg} to version {sub_arg2 or 'latest'}[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "trash":
                try:
                    files = await self.client.mdrive_trash(self.project_name)
                    if not files:
                        console.print("[yellow]Trash is empty.[/yellow]")
                    else:
                        for f in files[:30]:
                            name = f.get("file_path", f.get("name", "?"))
                            deleted = str(f.get("deleted_at", ""))[:19]
                            console.print(f"  [red]{name}[/red]  [dim]deleted {deleted}[/dim]")
                        console.print(f"[dim]Recover with: /mdrive undelete <file>[/dim]")
                except Exception as e:
                    console.print(f"[red]{e}[/red]")

            elif sub == "undelete":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive undelete <file>[/yellow]")
                else:
                    try:
                        await self.client.mdrive_undelete(self.project_name, sub_arg)
                        console.print(f"[green]Restored {sub_arg} from trash.[/green]")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            elif sub == "search":
                if not sub_arg:
                    console.print("[yellow]Usage: /mdrive search <query>[/yellow]")
                else:
                    query = " ".join(sub_parts[1:])
                    try:
                        results = await self.client.mdrive_search(self.project_name, query)
                        if not results:
                            console.print("[yellow]No results.[/yellow]")
                        else:
                            for r in results[:15]:
                                name = r.get("file_path", r.get("name", "?"))
                                preview = (r.get("preview", r.get("snippet", "")) or "")[:80]
                                console.print(f"  [cyan]{name}[/cyan]  {preview}")
                    except Exception as e:
                        console.print(f"[red]{e}[/red]")

            else:
                console.print("[yellow]MDrive commands: status, ls, push, pull, sync, history, restore, trash, undelete, search[/yellow]")
        # ─── Budget / Cost Ceiling ────────────────────────────────────
        elif command == "/budget":
            if not args.strip():
                if self.cost_ceiling is not None:
                    total = self._total_session_cost()
                    console.print(f"[cyan]Budget:[/cyan] ${total:.4f} / ${self.cost_ceiling:.4f}")
                    remaining = max(0, self.cost_ceiling - total)
                    console.print(f"[cyan]Remaining:[/cyan] ${remaining:.4f}")
                else:
                    console.print(f"[cyan]No budget set.[/cyan] Session cost so far: ${self._total_session_cost():.4f}")
                    console.print("[dim]Set with: /budget 0.50[/dim]")
            elif args.strip().lower() in ("off", "none", "clear"):
                self.cost_ceiling = None
                console.print("[green]Budget removed (no ceiling).[/green]")
            else:
                try:
                    val = float(args.strip().lstrip("$"))
                    if val <= 0:
                        console.print("[yellow]Budget must be > $0.[/yellow]")
                    else:
                        self.cost_ceiling = val
                        console.print(f"[green]Budget set: ${val:.4f}. All workers stop when total hits this.[/green]")
                except ValueError:
                    console.print("[yellow]Usage: /budget <amount> or /budget off[/yellow]")
        # ─── Worker Commands (multi-chat) ────────────────────────────
        elif command == "/workers":
            if not self.workers:
                console.print("[yellow]No workers. Start with multi-chat (M) at startup.[/yellow]")
            else:
                table = Table(title=f"Workers in {self.project_name}")
                table.add_column("#", style="cyan")
                table.add_column("Name", style="bold")
                table.add_column("Model")
                table.add_column("Status")
                table.add_column("Tokens", justify="right")
                table.add_column("Cost", justify="right")
                for i, w in enumerate(self.workers, 1):
                    active = "[green]>>>[/green] " if w["chat_id"] == self.chat_id else "    "
                    model_short = w["model"].split("/")[-1] if "/" in w["model"] else w["model"]
                    console.print(f"{active}[cyan]{i}.[/cyan] {w['name']}  [dim]{model_short}[/dim]  {w['status']}  {w['tokens']:,} tok  ${w['cost']:.4f}")
        elif command == "/join":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /join <name or #>[/yellow]")
            else:
                target = args.strip()
                found = None
                # By number
                try:
                    idx = int(target) - 1
                    if 0 <= idx < len(self.workers):
                        found = self.workers[idx]
                except ValueError:
                    pass
                # By name
                if not found:
                    for w in self.workers:
                        if w["name"].lower() == target.lower():
                            found = w
                            break
                if found:
                    # Save current context to the worker we're leaving
                    for w in self.workers:
                        if w["chat_id"] == self.chat_id:
                            w["messages"] = list(self.messages)
                            break
                    self.chat_id = found["chat_id"]
                    self.model = found["model"]
                    self.messages = list(found.get("messages", []))
                    console.print(f"[green]Joined worker: {found['name']} ({found['model'].split('/')[-1]})[/green]")
                else:
                    console.print(f"[yellow]Worker not found: {target}[/yellow]")
        elif command == "/broadcast":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /broadcast <message>[/yellow]")
            elif not self._check_cost_ceiling():
                pass  # Budget exceeded
            else:
                msg = args.strip()
                console.print(f"[cyan]Broadcasting to {len(self.workers)} in parallel...[/cyan]")

                async def _broadcast_one(w):
                    try:
                        parts = []
                        async for chunk in self.client.stream_chat(
                            chat_id=w["chat_id"], prompt=msg, model=w["model"],
                            project_name=self.project_name, history=w.get("messages", [])[-10:],
                            permission_context=self._get_permission_context(role="worker"),
                        ):
                            if not isinstance(chunk, dict):
                                continue
                            content = chunk.get("content", "")
                            if content:
                                parts.append(content)
                            if chunk.get("type") == "usage":
                                usage = chunk.get("usage", {})
                                tok = usage.get("total_tokens", 0)
                                cst = float(chunk.get("cost", 0))
                                w["tokens"] += tok
                                w["cost"] += cst
                                self.tokens_total += tok
                                self.cost_total += cst
                        response = "".join(parts)
                        if response:
                            w.setdefault("messages", []).append({"role": "user", "content": msg})
                            w["messages"].append({"role": "assistant", "content": response})
                        return w["name"], response, None
                    except Exception as e:
                        return w["name"], "", e

                results = await asyncio.gather(*[_broadcast_one(w) for w in self.workers])
                for name, response, err in results:
                    if err:
                        console.print(f"  [red]{name}: {err}[/red]")
                    elif response:
                        preview = f"{response[:120]}..." if len(response) > 120 else response
                        console.print(f"  [green]{name}[/green]: {preview}")
                    else:
                        console.print(f"  [yellow]{name}[/yellow]: (no response)")
        elif command == "/collect":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            else:
                for w in self.workers:
                    msgs = w.get("messages", [])
                    last = ""
                    for m in reversed(msgs):
                        if m.get("role") == "assistant":
                            last = m.get("content", "")[:200]
                            break
                    console.print(f"  [cyan]{w['name']}[/cyan] ({w['status']}): {last or '[no response yet]'}")
        elif command == "/kill":
            if not self.workers:
                console.print("[yellow]No workers active.[/yellow]")
            elif not args.strip():
                console.print("[yellow]Usage: /kill <name or #>[/yellow]")
            else:
                target = args.strip()
                found_idx = None
                try:
                    idx = int(target) - 1
                    if 0 <= idx < len(self.workers):
                        found_idx = idx
                except ValueError:
                    for i, w in enumerate(self.workers):
                        if w["name"].lower() == target.lower():
                            found_idx = i
                            break
                if found_idx is not None:
                    removed = self.workers.pop(found_idx)
                    console.print(f"[green]Killed worker: {removed['name']}[/green]")
                    if self.chat_id == removed["chat_id"] and self.workers:
                        self.chat_id = self.workers[0]["chat_id"]
                        console.print(f"[dim]Switched to: {self.workers[0]['name']}[/dim]")
                else:
                    console.print(f"[yellow]Worker not found: {target}[/yellow]")
        elif command == "/loop":
            # /loop N <prompt>  or  /loop until:PHRASE <prompt>
            # e.g. /loop 3 summarize this file
            # e.g. /loop until:DONE refactor the next function
            loop_parts = args.split(None, 1)
            if len(loop_parts) < 2:
                console.print("[yellow]Usage: /loop <N|until:PHRASE> <prompt>[/yellow]")
                console.print("[dim]Examples: /loop 3 check for bugs | /loop until:DONE refactor next fn[/dim]")
            else:
                n_or_until = loop_parts[0]
                sub_prompt = loop_parts[1]
                stop_phrase: Optional[str] = None
                max_iter = 5

                if n_or_until.startswith("until:"):
                    stop_phrase = n_or_until[len("until:"):].strip()
                    max_iter = 20  # generous ceiling for until-mode
                else:
                    try:
                        max_iter = max(1, min(int(n_or_until), 20))
                    except ValueError:
                        console.print(f"[red]Invalid loop count: {n_or_until!r}[/red]")
                        return True

                for i in range(1, max_iter + 1):
                    console.print(f"[dim][Loop {i}/{max_iter if not stop_phrase else '?'}][/dim]")
                    await self._chat(sub_prompt)
                    if stop_phrase:
                        # Check last assistant message for stop phrase
                        last_assistant = next(
                            (m["content"] for m in reversed(self.messages) if m.get("role") == "assistant"),
                            ""
                        )
                        if stop_phrase.lower() in last_assistant.lower():
                            console.print(f"[green]Loop stopped: found '{stop_phrase}'[/green]")
                            break
                    if i < max_iter or stop_phrase:
                        # Small pause between iterations for readability
                        await asyncio.sleep(0.2)
        elif command == "/mcp":
            # /mcp connect <name> <command>
            # /mcp tools
            # /mcp call <server> <tool> <json_args>
            from .mcp.client import MCPClientManager
            if self._mcp_manager is None:
                self._mcp_manager = MCPClientManager()

            mcp_parts = args.split(None, 1)
            mcp_sub = mcp_parts[0].lower() if mcp_parts else ""
            mcp_rest = mcp_parts[1] if len(mcp_parts) > 1 else ""

            if mcp_sub == "connect":
                # /mcp connect <name> <shell-command...>
                conn_parts = mcp_rest.split(None, 1)
                if len(conn_parts) < 2:
                    console.print("[yellow]Usage: /mcp connect <name> <command>[/yellow]")
                    console.print("[dim]Example: /mcp connect filesystem npx -y @modelcontextprotocol/server-filesystem /path[/dim]")
                else:
                    srv_name = conn_parts[0]
                    srv_cmd = conn_parts[1]
                    console.print(f"[cyan]Connecting to MCP server '{srv_name}'...[/cyan]")
                    try:
                        await self._mcp_manager.connect_server(srv_name, srv_cmd)
                        console.print(f"[green]Connected: {srv_name}[/green]")
                    except Exception as exc:
                        console.print(f"[red]Failed to connect '{srv_name}': {exc}[/red]")

            elif mcp_sub == "disconnect":
                # /mcp disconnect <name>
                if not mcp_rest.strip():
                    console.print("[yellow]Usage: /mcp disconnect <name>[/yellow]")
                else:
                    name = mcp_rest.strip()
                    try:
                        await self._mcp_manager.disconnect_server(name)
                        console.print(f"[green]Disconnected: {name}[/green]")
                    except Exception as exc:
                        console.print(f"[red]Error disconnecting '{name}': {exc}[/red]")

            elif mcp_sub == "tools":
                # /mcp tools — list all tools from all connected servers
                if not self._mcp_manager.servers:
                    console.print("[yellow]No MCP servers connected. Use /mcp connect <name> <command>[/yellow]")
                else:
                    try:
                        all_tools = await self._mcp_manager.list_all_tools()
                        if not all_tools:
                            console.print("[yellow]No tools available from connected servers.[/yellow]")
                        else:
                            table = Table(title="MCP Tools")
                            table.add_column("Server", style="cyan")
                            table.add_column("Tool")
                            table.add_column("Description")
                            for t in all_tools:
                                if "error" in t:
                                    table.add_row(t["server"], "[red]<error>[/red]", str(t["error"]))
                                else:
                                    table.add_row(
                                        t.get("server", "?"),
                                        t.get("original_name", t.get("name", "?")),
                                        str(t.get("description", ""))[:80],
                                    )
                            console.print(table)
                    except Exception as exc:
                        console.print(f"[red]Error listing tools: {exc}[/red]")

            elif mcp_sub == "call":
                # /mcp call <server> <tool> <json_args>
                call_parts = mcp_rest.split(None, 2)
                if len(call_parts) < 2:
                    console.print("[yellow]Usage: /mcp call <server> <tool> [json_args][/yellow]")
                    console.print('[dim]Example: /mcp call filesystem read_file {"path":"/foo.py"}[/dim]')
                else:
                    srv_name = call_parts[0]
                    tool_name = call_parts[1]
                    json_args_str = call_parts[2] if len(call_parts) > 2 else "{}"
                    try:
                        tool_args = json.loads(json_args_str)
                    except json.JSONDecodeError as exc:
                        console.print(f"[red]Invalid JSON arguments: {exc}[/red]")
                        tool_args = None
                    if tool_args is not None:
                        try:
                            result = await self._mcp_manager.call_tool(srv_name, tool_name, tool_args)
                            # Render result: extract text content if available
                            if isinstance(result, dict):
                                content_items = result.get("content", [])
                                if content_items:
                                    for item in content_items:
                                        if item.get("type") == "text":
                                            console.print(item.get("text", ""))
                                        else:
                                            console.print_json(json.dumps(item))
                                else:
                                    console.print_json(json.dumps(result))
                            else:
                                console.print(str(result))
                        except KeyError as exc:
                            console.print(f"[red]Server not found: {exc}[/red]")
                        except Exception as exc:
                            console.print(f"[red]Tool call failed: {exc}[/red]")

            elif mcp_sub == "servers":
                # /mcp servers — list connected servers
                if not self._mcp_manager.servers:
                    console.print("[yellow]No MCP servers connected.[/yellow]")
                else:
                    table = Table(title="Connected MCP Servers")
                    table.add_column("Name", style="cyan")
                    table.add_column("Command")
                    for name, client in self._mcp_manager.servers.items():
                        table.add_row(name, client.command)
                    console.print(table)

            else:
                console.print("[bold]MCP Client Commands:[/bold]")
                console.print("  /mcp connect <name> <command>  — Connect to an external MCP server")
                console.print("  /mcp tools                     — List tools from all connected servers")
                console.print("  /mcp call <srv> <tool> [json]  — Call a tool on a server")
                console.print("  /mcp servers                   — List connected servers")
                console.print("  /mcp disconnect <name>         — Disconnect a server")
                console.print("[dim]Example: /mcp connect fs npx -y @modelcontextprotocol/server-filesystem .[/dim]")
        # ─── Checkpoint Commands ──────────────────────────────────────
        elif command == "/checkpoint":
            if not args.strip():
                console.print("[yellow]Usage: /checkpoint <label>[/yellow]")
                console.print("[dim]Creates a named git checkpoint (stash + annotated tag).[/dim]")
            else:
                from .checkpoint import CheckpointManager
                mgr = CheckpointManager(repo_root=self.project_root)
                label = args.strip()
                console.print(f"[cyan]Creating checkpoint '{label}'...[/cyan]")
                result = mgr.create(label)
                if result["ok"]:
                    console.print(f"[green]Checkpoint created:[/green] {result['tag']}")
                    if result["stash"]:
                        console.print(f"  [dim]Stash: {result['stash']}[/dim]")
                    else:
                        console.print("  [dim]No uncommitted changes to stash.[/dim]")
                else:
                    console.print(f"[red]Checkpoint failed: {result['error']}[/red]")
        elif command == "/checkpoint-compare":
            if not args.strip():
                console.print("[yellow]Usage: /checkpoint-compare <tag>[/yellow]")
                console.print("[dim]Diff current state vs a checkpoint tag. Use /checkpoints to list tags.[/dim]")
            else:
                from .checkpoint import CheckpointManager
                mgr = CheckpointManager(repo_root=self.project_root)
                tag = args.strip()
                result = mgr.compare(tag)
                if result.get("error"):
                    console.print(f"[red]{result['error']}[/red]")
                else:
                    files = result["files_changed"]
                    added = result["lines_added"]
                    removed = result["lines_removed"]
                    console.print(f"[cyan]Comparing HEAD vs {tag}[/cyan]")
                    if not files and added == 0 and removed == 0:
                        console.print("[green]No differences found.[/green]")
                    else:
                        console.print(
                            f"  [green]+{added}[/green] / [red]-{removed}[/red] lines  "
                            f"[dim]{len(files)} file(s) changed[/dim]"
                        )
                        for f in files[:20]:
                            console.print(f"    [dim]{f}[/dim]")
                        if len(files) > 20:
                            console.print(f"  [dim]...and {len(files) - 20} more[/dim]")
        elif command == "/checkpoint-restore":
            if not args.strip():
                console.print("[yellow]Usage: /checkpoint-restore <tag>[/yellow]")
                console.print("[dim]Restores to a checkpoint. All uncommitted changes will be discarded.[/dim]")
            else:
                from .checkpoint import CheckpointManager
                mgr = CheckpointManager(repo_root=self.project_root)
                tag = args.strip()
                # Count pending changes before prompting
                _, status_out = mgr._run_git(["status", "--porcelain"])
                n_changes = len([ln for ln in status_out.splitlines() if ln.strip()])
                if n_changes > 0:
                    try:
                        confirm_input = console.input(
                            f"[yellow]This will discard {n_changes} uncommitted change(s). Confirm? [yes/no]: [/yellow]"
                        ).strip().lower()
                    except (KeyboardInterrupt, EOFError):
                        console.print("[dim]Cancelled.[/dim]")
                        return True
                else:
                    try:
                        confirm_input = console.input(
                            f"[yellow]Restore to checkpoint {tag}? Confirm? [yes/no]: [/yellow]"
                        ).strip().lower()
                    except (KeyboardInterrupt, EOFError):
                        console.print("[dim]Cancelled.[/dim]")
                        return True
                if confirm_input == "yes":
                    result = mgr.restore(tag, confirmed=True)
                    if result["ok"]:
                        console.print(f"[green]Restored to {tag}.[/green]")
                        if result["discarded_changes"]:
                            console.print(f"  [dim]{result['discarded_changes']} change(s) discarded.[/dim]")
                    else:
                        console.print(f"[red]Restore failed: {result['error']}[/red]")
                else:
                    console.print("[dim]Restore cancelled.[/dim]")
        elif command == "/checkpoints":
            from .checkpoint import CheckpointManager
            mgr = CheckpointManager(repo_root=self.project_root)
            checkpoints = mgr.list_checkpoints()
            if not checkpoints:
                console.print("[yellow]No checkpoints found. Create one with /checkpoint <label>[/yellow]")
            else:
                table = Table(title="Git Checkpoints")
                table.add_column("#", style="cyan")
                table.add_column("Tag")
                table.add_column("Label", style="bold")
                table.add_column("Date")
                table.add_column("Commit", style="dim")
                for i, cp in enumerate(checkpoints, 1):
                    table.add_row(
                        str(i),
                        cp["tag"],
                        cp["label"],
                        cp.get("date", ""),
                        cp.get("commit", ""),
                    )
                console.print(table)
        elif command == "/ses":
            # SES Benchmark Commands
            import httpx as _httpx
            ses_parts = args.split() if args.strip() else []
            ses_sub = ses_parts[0].lower() if ses_parts else ""
            _ses_base = getattr(self.client, "api_url", "https://api.msapling.com")

            if ses_sub == "run":
                model_id = None
                api_key_val = None
                hardware_val = None
                _ses_tokens = ses_parts[1:]
                _i = 0
                while _i < len(_ses_tokens):
                    if _ses_tokens[_i] == "--model" and _i + 1 < len(_ses_tokens):
                        model_id = _ses_tokens[_i + 1]
                        _i += 2
                    elif _ses_tokens[_i] == "--api-key" and _i + 1 < len(_ses_tokens):
                        api_key_val = _ses_tokens[_i + 1]
                        _i += 2
                    elif _ses_tokens[_i] == "--hardware" and _i + 1 < len(_ses_tokens):
                        hardware_val = _ses_tokens[_i + 1]
                        _i += 2
                    else:
                        _i += 1
                if not model_id:
                    console.print("[yellow]Usage: /ses run --model <model_id> [--api-key <key>] [--hardware <label>][/yellow]")
                else:
                    _ses_payload = {"model_id": model_id}
                    if api_key_val:
                        _ses_payload["api_key"] = api_key_val
                    if hardware_val:
                        _ses_payload["hardware"] = hardware_val
                    try:
                        async with _httpx.AsyncClient(timeout=30) as _hc:
                            _resp = await _hc.post(
                                f"{_ses_base}/api/benchmark/ses/run",
                                json=_ses_payload,
                                headers={"Authorization": f"Bearer {getattr(self.client, 'token', '')}"},
                            )
                        if _resp.status_code == 503:
                            console.print("[SES] MBenchmark not installed on server.")
                        elif _resp.status_code in (200, 201, 202):
                            _data = _resp.json()
                            run_id = _data.get("run_id", _data.get("id", "unknown"))
                            console.print(f"[SES] Queued benchmark run for model: {model_id}. Run ID: {run_id}")
                        else:
                            console.print(f"[red][SES] Server error {_resp.status_code}: {_resp.text[:200]}[/red]")
                    except Exception as _exc:
                        console.print(f"[red][SES] Request failed: {_exc}[/red]")

            elif ses_sub == "results":
                _ses_run_id = ses_parts[1] if len(ses_parts) > 1 else ""
                if not _ses_run_id:
                    console.print("[yellow]Usage: /ses results <run_id>[/yellow]")
                else:
                    try:
                        async with _httpx.AsyncClient(timeout=30) as _hc:
                            _resp = await _hc.get(
                                f"{_ses_base}/api/benchmark/ses/results",
                                params={"run_id": _ses_run_id},
                                headers={"Authorization": f"Bearer {getattr(self.client, 'token', '')}"},
                            )
                        if _resp.status_code == 503:
                            console.print("[SES] MBenchmark not installed on server.")
                        elif _resp.status_code == 200:
                            _data = _resp.json()
                            _status_val = _data.get("status", "")
                            if _status_val == "pending":
                                console.print("[SES] Status: pending. Check back in a few minutes.")
                            else:
                                _scores = _data.get("scores", _data.get("results", {}))
                                _rtable = Table(title=f"SES Results: {_ses_run_id}")
                                _rtable.add_column("Category", style="cyan")
                                _rtable.add_column("Score", justify="right")
                                if isinstance(_scores, dict):
                                    for _cat, _score in _scores.items():
                                        _rtable.add_row(str(_cat), str(_score))
                                elif isinstance(_scores, list):
                                    for _item in _scores:
                                        if isinstance(_item, dict):
                                            _rtable.add_row(
                                                str(_item.get("category", _item.get("name", "?"))),
                                                str(_item.get("score", "?")),
                                            )
                                else:
                                    _rtable.add_row("overall", str(_scores))
                                _overall = _data.get("overall_score", _data.get("score", ""))
                                if _overall:
                                    _rtable.add_row("[bold]Overall[/bold]", f"[bold]{_overall}[/bold]")
                                console.print(_rtable)
                        else:
                            console.print(f"[red][SES] Server error {_resp.status_code}: {_resp.text[:200]}[/red]")
                    except Exception as _exc:
                        console.print(f"[red][SES] Request failed: {_exc}[/red]")

            elif ses_sub == "leaderboard":
                try:
                    async with _httpx.AsyncClient(timeout=30) as _hc:
                        _resp = await _hc.get(
                            f"{_ses_base}/api/benchmark/ses/leaderboard",
                            headers={"Authorization": f"Bearer {getattr(self.client, 'token', '')}"},
                        )
                    if _resp.status_code == 503:
                        console.print("[SES] MBenchmark not installed on server.")
                    elif _resp.status_code == 200:
                        _data = _resp.json()
                        _entries = _data if isinstance(_data, list) else _data.get("entries", _data.get("leaderboard", []))
                        if not _entries:
                            console.print("[SES] Leaderboard is empty. Run a benchmark first.")
                        else:
                            _ltable = Table(title="SES Leaderboard")
                            _ltable.add_column("Rank", style="cyan", justify="right")
                            _ltable.add_column("Model ID")
                            _ltable.add_column("Score", justify="right")
                            for _rank, _entry in enumerate(_entries[:10], 1):
                                _mname = _entry.get("model_id", _entry.get("model", "?"))
                                _sval = str(_entry.get("score", _entry.get("overall_score", "?")))
                                _ltable.add_row(str(_rank), _mname, _sval)
                            console.print(_ltable)
                    else:
                        console.print(f"[red][SES] Server error {_resp.status_code}: {_resp.text[:200]}[/red]")
                except Exception as _exc:
                    console.print(f"[red][SES] Request failed: {_exc}[/red]")

            else:
                console.print("[bold]SES Benchmark Commands:[/bold]")
                console.print("  /ses run --model <model_id> [--api-key <key>] [--hardware <label>]")
                console.print("      Queue a benchmark run for a model")
                console.print("  /ses results <run_id>")
                console.print("      View results for a completed benchmark run")
                console.print("  /ses leaderboard")
                console.print("      Show top 10 models on the SES leaderboard")
        elif command == "/timer":
            await self._cmd_timer(args)
        elif command == "/repeat":
            await self._cmd_repeat(args)
        elif command == "/projects":
            await self._cmd_list_projects()
        elif command == "/chats":
            await self._cmd_list_chats(args)
        elif command == "/sidebar":
            self._sidebar_visible = not self._sidebar_visible
            if self._sidebar_visible:
                # Fetch latest chats for the sidebar
                chats: List[Dict[str, Any]] = []
                if self.project_name:
                    try:
                        chats = await self.client.list_project_chats(self.project_name)
                    except Exception:
                        pass
                self._render_sidebar(chats=chats)
            else:
                console.print("[dim]Sidebar hidden.[/dim]")
        else:
            console.print(f"[yellow]Unknown command: {command}. Type /help[/yellow]")

        return True

    async def _compact_context(self):
        """Compress context using backend Layer 0/1/2 system when available,
        or local LLM summarization as fallback."""

        # ── PreCompact hook: capture and persist critical context ──────────
        try:
            from .precompact_hook import capture_precompact_context, persist_precompact_context
            _pc_ctx = capture_precompact_context(self.__dict__)
            persist_precompact_context(_pc_ctx, self.session_id)
        except Exception as _pc_exc:
            _log.debug("precompact_hook failed (non-fatal): %s", _pc_exc)

        # ── Strategy 1: Server-side compact (triggers refresh_summaries) ──
        if self.chat_id:
            console.print("[cyan]Requesting server-side context compression (Layer 0/1/2)...[/cyan]")
            try:
                # The backend auto-runs refresh_summaries on each message.
                # Sending a lightweight system-level "compact" hint triggers it.
                # We fetch updated history which includes saga + blocks.
                server_history = await self.client.get_chat_history(self.chat_id, limit=20)
                if server_history:
                    # Replace local messages with server-compressed version
                    sys_msgs = [m for m in self.messages if m.get("role") == "system"]
                    self.messages = sys_msgs + server_history
                    console.print(f"[green]Context refreshed from server ({len(server_history)} messages with Layer 1/2 compression).[/green]")

                    # Show layer stats
                    try:
                        stats = await self.client.get_context_stats(self.chat_id)
                        tokens = stats.get("tokens_used", 0)
                        console.print(f"[dim]  Server stats: {tokens:,} tokens used in this chat[/dim]")
                    except Exception:
                        pass
                    return
            except Exception as e:
                console.print(f"[yellow]Server compact unavailable ({e}), using local fallback...[/yellow]")

        # ── Strategy 2: Local LLM-based compression (offline fallback) ──
        if len(self.messages) <= 6:
            console.print("[yellow]Not enough messages to compact.[/yellow]")
            return
        sys_msgs = [m for m in self.messages if m.get("role") == "system"]
        non_sys = [m for m in self.messages if m.get("role") != "system"]
        recent = non_sys[-5:]
        old_msgs = non_sys[:-5]
        if not old_msgs:
            console.print("[yellow]Nothing to summarize.[/yellow]")
            return
        n_old = len(old_msgs)
        console.print(f"[cyan]Summarizing {n_old} older messages via LLM...[/cyan]")
        parts = []
        for m in old_msgs:
            role = m.get("role", "unknown")
            text = m.get("content", "")[:2000]
            parts.append(f"{role}: {text}")
        transcript = "\n\n".join(parts)
        if len(transcript) > 12000:
            transcript = transcript[:12000] + "\n... (truncated)"
        summary_prompt = (
            "Summarize the following conversation into a concise recap. "
            "Preserve key decisions, code changes, file paths, and action items. "
            "Keep it under 500 words.\n\n"
            "--- Conversation ---\n" + transcript + "\n--- End ---"
        )
        try:
            summary = await self.client.chat_once(summary_prompt, self.model)
            if not summary.strip():
                summary = f"[Previous {n_old} messages compacted.]"
            self.messages = sys_msgs + [
                {"role": "system", "content": f"[Conversation summary]\n{summary}"}
            ] + recent
            console.print(f"[green]Compacted {n_old} messages → {len(self.messages)} remaining.[/green]")
            toast("Summary updated in background", level="info")
        except Exception as exc:
            self.messages = sys_msgs + [
                {"role": "system", "content": f"[Previous {n_old} messages compacted. Summary unavailable: {exc}]"}
            ] + recent
            console.print(f"[yellow]LLM summary failed. {len(self.messages)} messages remaining.[/yellow]")

    async def _generate_project_instructions(self):
        """Generate .msapling.md from project analysis."""
        console.print("[cyan]Analyzing project...[/cyan]")
        files = build_file_tree(self.project_root, max_files=20)
        context = read_files_as_context(self.project_root, files[:10], max_size_kb=30)
        prompt = (
            "Analyze this project and generate a .msapling.md instructions file. "
            "Include: project description, tech stack, key files, coding conventions, "
            "testing commands, and any important notes."
            + "\n\n" + context[:8000]
        )
        parts = []
        try:
            async for chunk in self.client.stream_chat(
                chat_id=str(uuid.uuid4()), prompt=prompt, model=self.model,
            ):
                if not isinstance(chunk, dict):
                    continue
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
            result = "".join(parts)
            out_path = Path(self.project_root) / ".msapling.md"
            out_path.write_text(result, encoding="utf-8")
            console.print(f"[green]Generated {out_path}[/green]")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")

    # ─── Listing Commands with rich.table ───────────────────────────

    @staticmethod
    def _fmt_relative(ts_str: str) -> str:
        """Format an ISO timestamp string (or raw float) as a relative label."""
        import datetime as _dt
        try:
            if not ts_str:
                return "—"
            # Try float epoch first
            try:
                epoch = float(ts_str)
                delta = time.time() - epoch
            except (ValueError, TypeError):
                # Try ISO string
                ts_str_clean = str(ts_str).replace("Z", "+00:00")
                parsed = _dt.datetime.fromisoformat(ts_str_clean)
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=_dt.timezone.utc)
                delta = (
                    _dt.datetime.now(_dt.timezone.utc) - parsed
                ).total_seconds()
            if delta < 0:
                return "just now"
            if delta < 60:
                return f"{int(delta)}s ago"
            if delta < 3600:
                return f"{int(delta // 60)}m ago"
            if delta < 86400:
                return f"{int(delta // 3600)}h ago"
            return f"{int(delta // 86400)}d ago"
        except Exception:
            return str(ts_str)[:16] if ts_str else "—"

    async def _cmd_list_projects(self) -> None:
        """List projects using a rich.table.Table."""
        import rich.box as _rbox
        try:
            overview = await self.client.projects_overview(self.user)
        except Exception as e:
            console.print(f"[red]Failed to load projects: {e}[/red]")
            return

        projects = overview.get("projects", [])
        project_limit = overview.get("project_limit", 10)

        table = Table(
            title=f"Your Projects  ({len(projects)}/{project_limit})",
            box=_rbox.ROUNDED,
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Name", style="bold #e2e8f0", min_width=14)
        table.add_column("Chats", justify="right")
        table.add_column("Model", style="#94a3b8")
        table.add_column("Last Active")

        for p in projects:
            name = p.get("name", "?")
            chat_count = p.get("chat_count", 0)
            chat_limit = p.get("chat_limit", "?")
            chats_str = f"{chat_count}/{chat_limit}"
            if p.get("is_full"):
                chats_str += " [red][FULL][/red]"
            model = p.get("model", "") or p.get("default_model", "") or "—"
            model_short = model.split("/")[-1] if "/" in model else model
            last_active = p.get("updated_at") or p.get("last_active") or p.get("created_at") or ""
            last_active_str = self._fmt_relative(str(last_active)) if last_active else "—"
            table.add_row(name, chats_str, model_short, last_active_str)

        console.print(table)

    async def _cmd_list_chats(self, args: str = "") -> None:
        """List chats for current (or specified) project using a rich.table.Table."""
        import rich.box as _rbox
        project_name = args.strip() or self.project_name
        if not project_name:
            console.print("[yellow]No active project. Usage: /chats [project_name][/yellow]")
            return
        try:
            chats = await self.client.list_project_chats(project_name)
        except Exception as e:
            console.print(f"[red]Failed to load chats: {e}[/red]")
            return

        table = Table(
            title=f"Chats — {project_name}  ({len(chats)} chat(s))",
            box=_rbox.ROUNDED,
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("#", style="cyan", justify="right", min_width=3)
        table.add_column("Name", style="bold #e2e8f0", min_width=16)
        table.add_column("Model", style="#94a3b8")
        table.add_column("Messages", justify="right")
        table.add_column("Cost", justify="right", style="#facc15")
        table.add_column("Last Active")

        for i, c in enumerate(chats, 1):
            title = c.get("title", c.get("slot_label", "Chat"))
            model = c.get("model", "") or "—"
            model_short = model.split("/")[-1] if "/" in model else model
            msg_count = c.get("message_count", c.get("messages", "?"))
            if isinstance(msg_count, list):
                msg_count = len(msg_count)
            cost = c.get("cost_usd", c.get("cost", 0) or 0)
            cost_str = f"${float(cost):.4f}" if cost else "—"
            last_active = c.get("updated_at") or c.get("last_active") or c.get("created_at") or ""
            last_active_str = self._fmt_relative(str(last_active)) if last_active else "—"
            table.add_row(str(i), title, model_short, str(msg_count), cost_str, last_active_str)

        console.print(table)

    # ─── Session Metadata Helpers ───────────────────────────────────

    _FILE_PATH_RE = re.compile(
        r'(?:^|\s)'                       # start of string or whitespace
        r'([\w./\-]+/'                  # path segment with slash
        r'[\w./\-]*'                    # rest of path
        r'\.(?:py|ts|tsx|js|jsx|json|yaml|yml|md|sh|txt|env|cfg|toml|ini))'
        r"""(?:\s|$|["']|,|\))""",        # terminated by whitespace/punctuation
        re.MULTILINE,
    )

    def _extract_files_from_messages(self) -> List[str]:
        """Scan conversation messages for file path mentions."""
        seen: set = set()
        results: List[str] = []
        for msg in self.messages:
            content = msg.get("content", "") or ""
            if not isinstance(content, str):
                continue
            for m in self._FILE_PATH_RE.finditer(content):
                fp = m.group(1).strip()
                if fp and fp not in seen:
                    seen.add(fp)
                    results.append(fp)
        # Also include files explicitly tracked during the session
        for fp in self.files_touched:
            if fp not in seen:
                seen.add(fp)
                results.append(fp)
        return results

    # Per-token cost estimates (USD per 1k tokens, blended input+output rough average)
    _COST_PER_1K: dict = {
        "haiku":  0.003,
        "sonnet": 0.015,
        "opus":   0.075,
    }
    _COST_DEFAULT = 0.015  # sonnet-tier fallback

    def _estimate_cost_usd(self) -> float:
        """Estimate session cost in USD from tokens_total and model family."""
        model_lower = (self.model or "").lower()
        if "haiku" in model_lower:
            rate = self._COST_PER_1K["haiku"]
        elif "opus" in model_lower:
            rate = self._COST_PER_1K["opus"]
        else:
            rate = self._COST_PER_1K.get("sonnet", self._COST_DEFAULT)
        return (self.tokens_total / 1000.0) * rate

    def _track_model(self, new_model: str) -> None:
        """Record a model into models_used (de-duplicated)."""
        if new_model and new_model not in self.models_used:
            self.models_used.append(new_model)

    def _track_file(self, path_str: str) -> None:
        """Record a file path into files_touched (de-duplicated, insertion-ordered).

        Called whenever a slash command explicitly reads, writes, or edits a
        file.  The path is stored as the user typed it so the list is human-
        readable in /session-info output.
        """
        if path_str and path_str not in self.files_touched:
            self.files_touched.append(path_str)

    def _save(self):
        import datetime as _dt
        duration_seconds = time.time() - self._session_start_time
        cost_usd = self._estimate_cost_usd()
        files_touched = self._extract_files_from_messages()

        # Approximate token split: 60 % input / 40 % output (no per-call split yet).
        tokens_in = self.tokens_in if self.tokens_in else int(self.tokens_total * 0.6)
        tokens_out = self.tokens_out if self.tokens_out else (self.tokens_total - tokens_in)

        # Auto-generate a one-line summary from the last user message.
        summary: Optional[str] = None
        for m in reversed(self.messages):
            if m.get("role") == "user":
                raw = (m.get("content") or "")
                if isinstance(raw, str):
                    summary = raw[:120].replace("\n", " ").strip() or None
                break

        started_at = _dt.datetime.fromtimestamp(
            self._session_start_time, tz=_dt.timezone.utc
        ).isoformat()
        ended_at = _dt.datetime.now(_dt.timezone.utc).isoformat()

        meta = SessionMetadata(
            session_id=self.session_id,
            project_name=self.project_name,
            models_used=list(self.models_used),
            files_touched=files_touched,
            slash_commands_used=list(self.slash_commands_used),
            total_cost_usd=cost_usd,
            total_tokens_in=tokens_in,
            total_tokens_out=tokens_out,
            started_at=started_at,
            ended_at=ended_at,
            duration_seconds=duration_seconds,
            turn_count=self.turn_count,
            summary=summary,
        )

        # Carry forward non-metadata fields (chat_id, workers) alongside
        # the rich SessionMetadata payload.
        meta_dict = meta.to_dict()
        meta_dict.update({
            "chat_id": self.chat_id,
            "commands_run": list(self.commands_run),
            "workers": [
                {"name": w["name"], "chat_id": w["chat_id"], "model": w["model"]}
                for w in self.workers
            ],
        })

        save_session(
            session_id=self.session_id,
            messages=self.messages,
            model=self.model,
            project_root=self.project_root,
            cost_total=self.cost_total,
            tokens_total=self.tokens_total,
            metadata=meta_dict,
        )
        toast("Session saved", level="info")

        # --- MBrain background sync (non-blocking) ---
        try:
            from .mbrain_integration import build_sync_from_config
            _mbrain = build_sync_from_config()
            if _mbrain is not None:
                _session_for_sync = {
                    "id": self.session_id,
                    "messages": self.messages,
                    "model": self.model,
                    "project_root": self.project_root,
                    "cost_total": self.cost_total,
                    "tokens_total": self.tokens_total,
                    "metadata": meta_dict,
                }
                _mbrain.sync_session(_session_for_sync)
        except Exception:
            pass  # Never interrupt session teardown

    def _build_snapshot_data(self) -> Dict[str, Any]:
        """Build a snapshot payload suitable for server-side persistence."""
        return {
            "session_id": self.session_id,
            "model": self.model,
            "project_name": self.project_name,
            "project_root": self.project_root,
            "chat_id": self.chat_id,
            "messages": self.messages,
            "cost_total": self.cost_total,
            "tokens_total": self.tokens_total,
            "metadata": {
                "models_used": list(self.models_used),
                "files_touched": self._extract_files_from_messages(),
                "commands_run": list(self.commands_run),
                "cost_usd": self._estimate_cost_usd(),
                "workers": [
                    {"name": w["name"], "chat_id": w["chat_id"], "model": w["model"]}
                    for w in self.workers
                ],
            },
        }

    async def _cmd_save_remote(self, description: str) -> None:
        """Handle /save-remote [description] — persist snapshot to MSapling backend."""
        desc = description or f"CLI snapshot {self.session_id}"
        snapshot_data = self._build_snapshot_data()
        console.print("[cyan]Saving snapshot to MSapling backend...[/cyan]")
        try:
            result = await self.client.create_session_snapshot(
                session_id=self.session_id,
                snapshot_data=snapshot_data,
                description=desc,
                project_id=self.chat_id,
            )
            snap_id = result.get("id", "?")
            console.print(
                f"[green]Snapshot saved:[/green] [bold]{snap_id}[/bold]"
                f"\n  [dim]Description: {desc}[/dim]"
                f"\n  [dim]Resume on any machine with:[/dim] [bold cyan]/resume-remote {snap_id}[/bold cyan]"
            )
        except Exception as exc:
            console.print(f"[red]Snapshot save failed: {exc}[/red]")

    async def _cmd_resume_remote(self, snapshot_id: str) -> None:
        """Handle /resume-remote [snapshot_id] — fetch and restore a remote snapshot."""
        if not snapshot_id:
            # List available snapshots
            try:
                data = await self.client.list_session_snapshots(limit=20)
                snapshots = data.get("snapshots", [])
                if not snapshots:
                    console.print("[yellow]No remote snapshots found.[/yellow]")
                    console.print("[dim]Use /save-remote to create one.[/dim]")
                    return
                table = Table(title="Remote Snapshots")
                table.add_column("#", style="cyan")
                table.add_column("ID")
                table.add_column("Session ID")
                table.add_column("Description")
                table.add_column("Created At")
                for i, snap in enumerate(snapshots):
                    table.add_row(
                        str(i + 1),
                        snap.get("id", "?")[:20],
                        snap.get("session_id", "?")[:12],
                        (snap.get("description") or "")[:50],
                        snap.get("created_at", "")[:19],
                    )
                console.print(table)
                console.print("[dim]Use /resume-remote <id> to restore a snapshot.[/dim]")
            except Exception as exc:
                console.print(f"[red]Failed to list snapshots: {exc}[/red]")
            return

        # Restore specific snapshot
        console.print(f"[cyan]Fetching snapshot {snapshot_id}...[/cyan]")
        try:
            snap = await self.client.get_session_snapshot(snapshot_id)
        except Exception as exc:
            console.print(f"[red]Failed to fetch snapshot: {exc}[/red]")
            return

        snap_data = snap.get("snapshot_data", {})
        if not snap_data:
            console.print("[red]Snapshot data is empty.[/red]")
            return

        # Restore conversation state
        restored_messages = snap_data.get("messages", [])
        if restored_messages:
            # Keep current system messages; replace non-system with snapshot
            sys_msgs = [m for m in self.messages if m.get("role") == "system"]
            snap_sys = [m for m in restored_messages if m.get("role") == "system"]
            snap_non_sys = [m for m in restored_messages if m.get("role") != "system"]
            self.messages = sys_msgs + snap_sys + snap_non_sys

        if snap_data.get("model"):
            self.model = snap_data["model"]
        if snap_data.get("session_id"):
            self.session_id = snap_data["session_id"]
            self.client.set_session_id(self.session_id)
        if snap_data.get("cost_total") is not None:
            self.cost_total = float(snap_data["cost_total"])
        if snap_data.get("tokens_total") is not None:
            self.tokens_total = int(snap_data["tokens_total"])

        meta = snap_data.get("metadata", {})
        if meta.get("commands_run"):
            self.commands_run = list(meta["commands_run"])
        if meta.get("models_used"):
            self.models_used = list(meta["models_used"])

        console.print(
            f"[green]Snapshot restored:[/green] {snap.get('description', snapshot_id)}"
            f"\n  [dim]{len(restored_messages)} messages, model: {self.model}[/dim]"
        )


    def _write_session_state(self) -> None:
        """Write a session state file to ~/.msapling/sessions/session_state_{timestamp}.md.

        Called at the end of each conversation or on exit. The file provides a
        human-readable summary that can be used to resume or understand the session.
        """
        import datetime as _dt
        try:
            sessions_dir = Path.home() / ".msapling" / "sessions"
            sessions_dir.mkdir(parents=True, exist_ok=True)

            now = _dt.datetime.now(_dt.timezone.utc)
            iso_ts = now.strftime("%Y-%m-%dT%H-%M-%SZ")
            out_path = sessions_dir / f"session_state_{iso_ts}.md"

            # Git branch
            branch = "unknown"
            try:
                r = subprocess.run(
                    ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                    cwd=self.project_root, capture_output=True, text=True, timeout=5,
                )
                if r.returncode == 0:
                    branch = r.stdout.strip() or "unknown"
            except Exception:
                pass

            # Duration
            start_time = getattr(self, "_session_start_time", None)
            if start_time is not None:
                duration = int(time.time() - start_time)
            else:
                duration = 0

            # Last 3 non-system messages as context
            non_sys = [m for m in self.messages if m.get("role") != "system"]
            recent = non_sys[-3:] if len(non_sys) >= 3 else non_sys
            summary_lines = []
            for m in recent:
                role = m.get("role", "?")
                content = (m.get("content") or "")[:300]
                summary_lines.append(f"**{role}**: {content}")
            conversation_summary = "\n\n".join(summary_lines) if summary_lines else "No messages yet."

            # auto_summary hook for session on-exit summarization
            auto_summary_note = ""
            if recent:
                auto_summary_note = "\n\n> Auto-summary: session ended normally."

            content_md = f"""# Session State — {now.isoformat()}

## Session Metadata
- branch: {branch}
- model: {self.model}
- duration: {duration}s
- messages: {len(self.messages)}

## Conversation Summary
{conversation_summary}{auto_summary_note}

## Resume Command
To resume: load this file and summarize the context
"""

            out_path.write_text(content_md, encoding="utf-8")
            _log.debug("Session state written to %s", out_path)
        except Exception as exc:
            _log.warning("Failed to write session state: %s", exc)


async def run_shell(model=None, project=None, resume_id=None, ephemeral: bool = False):
    """Entry point for the interactive shell."""
    shell = InteractiveShell(model=model, project=project, resume_id=resume_id, ephemeral=ephemeral)
    await shell.start()
