"""Provider-aware transcript hygiene and repair helpers."""
from __future__ import annotations

import json
import re
import shutil
import time
from difflib import unified_diff
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Set, Tuple


_TOOL_CALL_ID_PATTERNS = (
    re.compile(r"(tool_call_id\s*[:=]\s*)([A-Za-z0-9_.:-]+)", re.IGNORECASE),
    re.compile(r"(tool-call-id\s*[:=]\s*)([A-Za-z0-9_.:-]+)", re.IGNORECASE),
    re.compile(r"(<tool_call\s+id=\")([A-Za-z0-9_.:-]+)(\")", re.IGNORECASE),
)


@dataclass
class HygieneReport:
    dropped_messages: int = 0
    rewritten_roles: int = 0
    deduped_messages: int = 0
    normalized_tool_call_ids: int = 0
    paired_tool_results: int = 0
    dropped_unpaired_tool_results: int = 0
    ordering_fixups: int = 0

    def to_dict(self) -> Dict[str, int]:
        return {
            "dropped_messages": self.dropped_messages,
            "rewritten_roles": self.rewritten_roles,
            "deduped_messages": self.deduped_messages,
            "normalized_tool_call_ids": self.normalized_tool_call_ids,
            "paired_tool_results": self.paired_tool_results,
            "dropped_unpaired_tool_results": self.dropped_unpaired_tool_results,
            "ordering_fixups": self.ordering_fixups,
        }


def _normalize_role(role: Any) -> Tuple[str, bool]:
    raw = str(role or "").strip().lower()
    if raw in {"assistant", "user", "system", "tool"}:
        return raw, False
    if raw in {"model", "ai", "bot"}:
        return "assistant", True
    if raw in {"human"}:
        return "user", True
    if raw in {"function", "tool_result"}:
        return "tool", True
    return "user", True


def _normalize_tool_call_ids(
    text: str,
    report: HygieneReport,
    id_map: Dict[str, str],
    next_id_ref: List[int],
) -> str:
    if not text:
        return text
    out = text

    def _rewrite(original_id: str) -> str:
        key = original_id.strip()
        if key not in id_map:
            id_map[key] = f"toolcall-{next_id_ref[0]:03d}"
            next_id_ref[0] += 1
        return id_map[key]

    for pattern in _TOOL_CALL_ID_PATTERNS:
        def _sub(match: re.Match[str]) -> str:
            original = match.group(2)
            updated = _rewrite(original)
            if updated != original:
                report.normalized_tool_call_ids += 1
            if len(match.groups()) == 3:
                return f"{match.group(1)}{updated}{match.group(3)}"
            return f"{match.group(1)}{updated}"

        out = pattern.sub(_sub, out)
    return out


def _extract_tool_call_ids(text: str) -> Set[str]:
    ids: Set[str] = set()
    if not text:
        return ids
    for pattern in _TOOL_CALL_ID_PATTERNS:
        for match in pattern.finditer(text):
            if len(match.groups()) >= 2:
                value = str(match.group(2) or "").strip()
                if value:
                    ids.add(value)
    return ids


def sanitize_transcript_messages(messages: Iterable[Any]) -> Tuple[List[Dict[str, str]], HygieneReport]:
    report = HygieneReport()
    normalized_rows: List[Dict[str, str]] = []
    id_map: Dict[str, str] = {}
    next_id_ref = [1]

    for item in messages:
        if not isinstance(item, dict):
            report.dropped_messages += 1
            continue
        role, rewritten = _normalize_role(item.get("role"))
        if rewritten:
            report.rewritten_roles += 1
        content_raw = item.get("content", "")
        content = str(content_raw or "").replace("\r\n", "\n").strip()
        if not content:
            report.dropped_messages += 1
            continue
        content = _normalize_tool_call_ids(content, report, id_map, next_id_ref)
        normalized = {"role": role, "content": content}
        if (
            normalized_rows
            and normalized_rows[-1]["role"] == role
            and normalized_rows[-1]["content"] == content
        ):
            report.deduped_messages += 1
            continue
        normalized_rows.append(normalized)

    # Tool call/result pairing and ordering repair.
    cleaned: List[Dict[str, str]] = []
    seen_assistant_calls: Set[str] = set()
    seen_assistant_message = False
    deferred_tool_results: Dict[str, List[Dict[str, str]]] = {}

    for msg in normalized_rows:
        role = msg["role"]
        content = msg["content"]
        ids = _extract_tool_call_ids(content)

        if role == "tool":
            if not ids:
                if seen_assistant_calls or seen_assistant_message:
                    cleaned.append(msg)
                    report.paired_tool_results += 1
                    continue
                report.dropped_messages += 1
                report.dropped_unpaired_tool_results += 1
                continue
            if any(tid in seen_assistant_calls for tid in ids):
                cleaned.append(msg)
                continue
            key = sorted(ids)[0]
            deferred_tool_results.setdefault(key, []).append(msg)
            report.ordering_fixups += 1
            continue

        cleaned.append(msg)
        if role == "assistant":
            seen_assistant_message = True
            if ids:
                for tid in sorted(ids):
                    seen_assistant_calls.add(tid)
                    pending = deferred_tool_results.pop(tid, [])
                    if pending:
                        cleaned.extend(pending)
                        report.paired_tool_results += len(pending)

    for pending in deferred_tool_results.values():
        cleaned.extend(pending)

    return cleaned, report


def repair_session_file(path: Path, *, dry_run: bool = True) -> Dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {
            "id": path.stem,
            "path": str(path),
            "changed": False,
            "error": f"invalid_json: {exc}",
        }

    original_messages = payload.get("messages", [])
    cleaned, report = sanitize_transcript_messages(original_messages if isinstance(original_messages, list) else [])
    changed = cleaned != original_messages
    diff_preview = ""
    diff_line_count = 0
    if changed:
        before_lines = json.dumps(original_messages, indent=2, ensure_ascii=False).splitlines()
        after_lines = json.dumps(cleaned, indent=2, ensure_ascii=False).splitlines()
        diff_lines = list(
            unified_diff(
                before_lines,
                after_lines,
                fromfile="messages.before",
                tofile="messages.after",
                lineterm="",
            )
        )
        diff_line_count = len(diff_lines)
        max_lines = 160
        if diff_line_count > max_lines:
            diff_preview = "\n".join(diff_lines[:max_lines] + ["... (truncated)"])
        else:
            diff_preview = "\n".join(diff_lines)

    backup_path = None
    if changed and not dry_run:
        archive_root = path.parent / "archive" / time.strftime("%Y%m%d")
        archive_root.mkdir(parents=True, exist_ok=True)
        backup_path = archive_root / path.name
        shutil.copy2(path, backup_path)
        payload["messages"] = cleaned
        payload["metadata"] = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        payload["metadata"]["transcript_hygiene"] = report.to_dict()
        payload["updated_at"] = time.time()
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    return {
        "id": path.stem,
        "path": str(path),
        "changed": changed,
        "backup_path": str(backup_path) if backup_path else None,
        "report": report.to_dict(),
        "diff_preview": diff_preview,
        "diff_line_count": diff_line_count,
        "error": None,
    }
