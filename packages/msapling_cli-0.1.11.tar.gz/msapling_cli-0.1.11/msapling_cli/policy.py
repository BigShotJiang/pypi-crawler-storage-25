"""Policy engine for MSapling CLI tool decisions.

Rules are intentionally data-only and are evaluated before the interactive
approval prompt. This provides Gemini-style persistent allow/deny/ask controls
without bypassing AgentShield or the command sandbox hard gates.
"""
from __future__ import annotations

from dataclasses import dataclass
import fnmatch
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterable


VALID_DECISIONS = frozenset({"allow", "deny", "ask_user"})
GENERATED_POLICY_FILENAME = "generated.rules.json"
TRUSTED_PATHS_KEY = "trusted_paths"
APPROVAL_RULE_PREFIX = "approval:"
TIER_BASE = {
    "default": 1.0,
    "workspace": 3.0,
    "user": 4.0,
    "admin": 5.0,
}


@dataclass(frozen=True)
class PolicyRule:
    tool_name: str = "*"
    decision: str = "ask_user"
    priority: int = 0
    tier: str = "user"
    source: str = ""
    args_pattern: str | None = None
    command_prefix: str | None = None
    modes: tuple[str, ...] = ()
    interactive: bool | None = None
    name: str = ""

    @property
    def final_priority(self) -> float:
        return TIER_BASE.get(self.tier, TIER_BASE["user"]) + (max(0, min(int(self.priority), 999)) / 1000.0)


@dataclass(frozen=True)
class PolicyDecision:
    decision: str
    reason: str
    rule: PolicyRule


def normalize_mode(mode: str | None) -> str:
    """Normalize MSapling/Gemini-style mode aliases to one vocabulary."""
    raw = str(mode or "default").strip().lower().replace("-", "_")
    aliases = {
        "ask": "default",
        "default": "default",
        "auto": "auto_edit",
        "autoedit": "auto_edit",
        "auto_edit": "auto_edit",
        "readonly": "plan",
        "read_only": "plan",
        "plan": "plan",
        "full": "yolo",
        "yolo": "yolo",
    }
    return aliases.get(raw, raw)


def stable_args_json(args: dict[str, Any]) -> str:
    return json.dumps(args or {}, sort_keys=True, separators=(",", ":"), default=str)


def _normalize_modes(value: Any) -> tuple[str, ...]:
    if value is None or value == "":
        return ()
    if isinstance(value, str):
        raw_modes = [value]
    elif isinstance(value, Iterable):
        raw_modes = list(value)
    else:
        raw_modes = [str(value)]
    return tuple(normalize_mode(str(item)) for item in raw_modes if str(item).strip())


def _as_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
    return None


def _rule_from_mapping(data: dict[str, Any], *, tier: str, source: Path) -> PolicyRule | None:
    tool_name = str(data.get("toolName") or data.get("tool_name") or data.get("tool") or "*").strip() or "*"
    decision = str(data.get("decision") or "ask_user").strip().lower().replace("-", "_")
    if decision in {"ask", "confirm"}:
        decision = "ask_user"
    if decision not in VALID_DECISIONS:
        return None
    try:
        priority = int(data.get("priority", 0))
    except Exception:
        priority = 0
    return PolicyRule(
        tool_name=tool_name,
        decision=decision,
        priority=priority,
        tier=tier,
        source=str(source),
        args_pattern=data.get("argsPattern") or data.get("args_pattern"),
        command_prefix=data.get("commandPrefix") or data.get("command_prefix"),
        modes=_normalize_modes(data.get("modes") or data.get("mode")),
        interactive=_as_bool(data.get("interactive")),
        name=str(data.get("name") or ""),
    )


def _parse_toml_fallback(text: str) -> dict[str, Any]:
    """Parse the simple policy TOML shape used by MSapling tests/docs.

    This keeps Python 3.10 installs dependency-free when stdlib ``tomllib`` is
    unavailable. It supports repeated ``[[rule]]`` blocks with string, boolean,
    integer, and string-list values.
    """
    rules: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    def _value(raw: str) -> Any:
        raw = raw.strip()
        if raw.startswith("[") and raw.endswith("]"):
            inner = raw[1:-1].strip()
            if not inner:
                return []
            return [_value(part.strip()) for part in inner.split(",")]
        if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
            return raw[1:-1]
        lowered = raw.lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        try:
            return int(raw)
        except ValueError:
            return raw

    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        if line == "[[rule]]":
            current = {}
            rules.append(current)
            continue
        if "=" in line and current is not None:
            key, raw_value = line.split("=", 1)
            current[key.strip()] = _value(raw_value)
    return {"rule": rules}


def _verify_policy_safety(path: Path, tier: str) -> bool:
    """Check if a policy file is safe to load (not world-writable)."""
    try:
        import os
        stat = path.stat()
        # On POSIX, check world-writable bit (others write)
        if os.name == "posix" and hasattr(stat, "st_mode"):
            if stat.st_mode & 0o002:
                # World-writable!
                return False
        
        # On Windows, we trust the path for now.
        return True
    except Exception:
        return False


def _load_policy_file(path: Path, tier: str) -> list[PolicyRule]:
    if not _verify_policy_safety(path, tier):
        # Log or print warning? For now just skip for safety.
        return []
    try:
        if path.suffix.lower() == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
        else:
            text = path.read_text(encoding="utf-8")
            try:
                import tomllib  # Python 3.11+
                data = tomllib.loads(text)
            except Exception:
                data = _parse_toml_fallback(text)
    except Exception:
        return []

    raw_rules = data.get("rule") if isinstance(data, dict) else None
    if raw_rules is None and isinstance(data, dict):
        raw_rules = data.get("rules")
    if isinstance(raw_rules, dict):
        raw_rules = [raw_rules]
    if not isinstance(raw_rules, list):
        return []

    rules: list[PolicyRule] = []
    for item in raw_rules:
        if isinstance(item, dict):
            rule = _rule_from_mapping(item, tier=tier, source=path)
            if rule is not None:
                rules.append(rule)
    return rules


def _iter_policy_files(path: Path) -> list[Path]:
    try:
        if path.is_file() and path.suffix.lower() in {".toml", ".json"}:
            return [path]
        if path.is_dir():
            return sorted(
                item
                for item in path.iterdir()
                if item.is_file() and item.suffix.lower() in {".toml", ".json"}
            )
    except Exception:
        return []
    return []


def _split_env_paths(value: str) -> list[Path]:
    return [Path(part).expanduser() for part in value.split(os.pathsep) if part.strip()]


def default_policy_locations(workspace: str | Path | None = None) -> dict[str, list[Path]]:
    workspace_path = Path(workspace or Path.cwd())
    user_paths = [Path.home() / ".msapling" / "policies"]
    workspace_paths = [workspace_path / ".msapling" / "policies"]

    if sys.platform == "win32":
        program_data = Path(os.environ.get("ProgramData", r"C:\ProgramData"))
        admin_paths = [program_data / "msapling-cli" / "policies"]
    elif sys.platform == "darwin":
        admin_paths = [Path("/Library/Application Support/MSaplingCli/policies")]
    else:
        admin_paths = [Path("/etc/msapling-cli/policies")]

    extra_user = _split_env_paths(os.getenv("MSAPLING_POLICY_PATHS", ""))
    extra_admin = _split_env_paths(os.getenv("MSAPLING_ADMIN_POLICY_PATHS", ""))
    return {
        "workspace": workspace_paths,
        "user": user_paths + extra_user,
        "admin": admin_paths + extra_admin,
    }


def load_policy_rules(workspace: str | Path | None = None) -> list[PolicyRule]:
    rules: list[PolicyRule] = []
    for tier, paths in default_policy_locations(workspace).items():
        for location in paths:
            for path in _iter_policy_files(location):
                rules.extend(_load_policy_file(path, tier))
    return sorted(rules, key=lambda rule: rule.final_priority, reverse=True)


def rule_matches(
    rule: PolicyRule,
    tool_name: str,
    args: dict[str, Any] | None = None,
    *,
    mode: str = "default",
    interactive: bool = True,
) -> bool:
    normalized_mode = normalize_mode(mode)
    if rule.modes and normalized_mode not in rule.modes:
        return False
    if rule.interactive is not None and rule.interactive != interactive:
        return False
    if not fnmatch.fnmatchcase(tool_name.lower(), rule.tool_name.lower()):
        return False
    args = args or {}
    if rule.command_prefix is not None:
        command = str(args.get("command", "")).strip().lower()
        if not command.startswith(str(rule.command_prefix).strip().lower()):
            return False
    if rule.args_pattern:
        try:
            if not re.search(rule.args_pattern, stable_args_json(args)):
                return False
        except re.error:
            return False
    return True


def evaluate_policy(
    tool_name: str,
    args: dict[str, Any] | None = None,
    *,
    mode: str = "default",
    interactive: bool = True,
    workspace: str | Path | None = None,
) -> PolicyDecision | None:
    for rule in load_policy_rules(workspace):
        if rule_matches(rule, tool_name, args, mode=mode, interactive=interactive):
            decision = "deny" if rule.decision == "ask_user" and not interactive else rule.decision
            label = rule.name or f"{rule.tier} policy"
            return PolicyDecision(
                decision=decision,
                reason=f"{label}: {decision} {tool_name}",
                rule=rule,
            )
    return None


def generated_policy_path(workspace: str | Path | None = None) -> Path:
    workspace_path = Path(workspace or Path.cwd()).resolve()
    return workspace_path / ".msapling" / "policies" / GENERATED_POLICY_FILENAME


def generated_policy_path_for_scope(
    scope: str = "workspace",
    *,
    workspace: str | Path | None = None,
) -> Path:
    normalized = str(scope or "workspace").strip().lower()
    if normalized == "workspace":
        return generated_policy_path(workspace)
    if normalized == "user":
        return Path.home() / ".msapling" / "policies" / GENERATED_POLICY_FILENAME
    raise ValueError(f"Unsupported scope: {scope}")


def _load_generated_payload(path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"rule": [], TRUSTED_PATHS_KEY: []}
    if not isinstance(raw, dict):
        return {"rule": [], TRUSTED_PATHS_KEY: []}
    rules = raw.get("rule")
    if not isinstance(rules, list):
        raw["rule"] = []
    trusted = raw.get(TRUSTED_PATHS_KEY)
    if not isinstance(trusted, list):
        raw[TRUSTED_PATHS_KEY] = []
    return raw


def _save_generated_payload(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _select_generated_policy_path(
    *,
    workspace: str | Path | None = None,
    scope: str = "workspace",
) -> Path:
    return generated_policy_path_for_scope(scope, workspace=workspace)


def _slug(value: str) -> str:
    text = re.sub(r"[^a-z0-9._-]+", "-", value.lower()).strip("-")
    return text[:80] or "scope"


def _normalize_workspace_path(path: str | Path, *, workspace: str | Path | None = None) -> Path:
    workspace_root = Path(workspace or Path.cwd()).resolve()
    value = str(path).strip()
    if not value:
        raise ValueError("Path cannot be empty.")
    candidate = Path(value)
    resolved = candidate.resolve() if candidate.is_absolute() else (workspace_root / candidate).resolve()
    if not (resolved == workspace_root or resolved.is_relative_to(workspace_root)):
        raise ValueError(f"Path must stay within workspace: {workspace_root}")
    return resolved


def _ensure_trust_guardrail_rules(payload: dict[str, Any], *, enabled: bool) -> None:
    raw_rules = payload.get("rule")
    rules = raw_rules if isinstance(raw_rules, list) else []
    guardrail_rules = {
        "trust-guardrail:deny-sensitive-write": {
            "name": "trust-guardrail:deny-sensitive-write",
            "toolName": "write_file",
            "decision": "deny",
            "priority": 995,
            "argsPattern": r"(?:^|[\\/])(?:\.git[\\/]|\.env(?:\.[^\"\\/]*)?$|id_rsa(?:\.pub)?$|authorized_keys$|.*\.(?:pem|key)$)",
        },
        "trust-guardrail:deny-sensitive-edit": {
            "name": "trust-guardrail:deny-sensitive-edit",
            "toolName": "edit_file",
            "decision": "deny",
            "priority": 995,
            "argsPattern": r"(?:^|[\\/])(?:\.git[\\/]|\.env(?:\.[^\"\\/]*)?$|id_rsa(?:\.pub)?$|authorized_keys$|.*\.(?:pem|key)$)",
        },
        "trust-guardrail:deny-network-command": {
            "name": "trust-guardrail:deny-network-command",
            "toolName": "run_command",
            "decision": "deny",
            "priority": 995,
            "argsPattern": r"(?:curl|wget|invoke-webrequest|iwr)\s+https?://",
        },
    }
    existing = {str(item.get("name") or "") for item in rules if isinstance(item, dict)}
    if enabled:
        for _, guardrail in guardrail_rules.items():
            if guardrail["name"] not in existing:
                rules.append(guardrail)
    else:
        rules = [
            item for item in rules
            if not (isinstance(item, dict) and str(item.get("name") or "").startswith("trust-guardrail:"))
        ]
    payload["rule"] = rules


def list_trusted_paths(workspace: str | Path | None = None) -> list[Path]:
    payload = _load_generated_payload(_select_generated_policy_path(workspace=workspace, scope="workspace"))
    trusted = payload.get(TRUSTED_PATHS_KEY)
    out: list[Path] = []
    if not isinstance(trusted, list):
        return out
    for item in trusted:
        try:
            out.append(Path(str(item)).resolve())
        except Exception:
            continue
    return sorted(set(out))


def add_trusted_path(path: str | Path, *, workspace: str | Path | None = None) -> tuple[Path, bool]:
    resolved = _normalize_workspace_path(path, workspace=workspace)
    if not resolved.exists():
        raise ValueError(f"Path does not exist: {resolved}")
    policy_path = _select_generated_policy_path(workspace=workspace, scope="workspace")
    payload = _load_generated_payload(policy_path)
    trusted = payload.get(TRUSTED_PATHS_KEY)
    entries = [str(Path(str(item)).resolve()) for item in trusted] if isinstance(trusted, list) else []
    key = str(resolved)
    added = key not in entries
    if added:
        entries.append(key)
    payload[TRUSTED_PATHS_KEY] = sorted(set(entries))
    _ensure_trust_guardrail_rules(payload, enabled=bool(payload[TRUSTED_PATHS_KEY]))
    _save_generated_payload(policy_path, payload)
    return resolved, added


def remove_trusted_path(path_or_index: str, *, workspace: str | Path | None = None) -> Path | None:
    policy_path = _select_generated_policy_path(workspace=workspace, scope="workspace")
    payload = _load_generated_payload(policy_path)
    trusted_paths = list_trusted_paths(workspace)
    if not trusted_paths:
        return None
    removed: Path | None = None
    value = str(path_or_index or "").strip()
    if value.isdigit():
        idx = int(value) - 1
        if 0 <= idx < len(trusted_paths):
            removed = trusted_paths[idx]
    else:
        try:
            target = _normalize_workspace_path(value, workspace=workspace)
            for item in trusted_paths:
                if item == target:
                    removed = item
                    break
        except Exception:
            removed = None
    if removed is None:
        return None
    payload[TRUSTED_PATHS_KEY] = [str(item) for item in trusted_paths if item != removed]
    _ensure_trust_guardrail_rules(payload, enabled=bool(payload[TRUSTED_PATHS_KEY]))
    _save_generated_payload(policy_path, payload)
    return removed


def is_path_trusted(path: str | Path, *, workspace: str | Path | None = None) -> bool:
    trusted_paths = list_trusted_paths(workspace)
    if not trusted_paths:
        return False
    try:
        candidate = _normalize_workspace_path(path, workspace=workspace)
    except Exception:
        return False
    for trusted in trusted_paths:
        try:
            if candidate == trusted or candidate.is_relative_to(trusted):
                return True
        except Exception:
            continue
    return False


def command_is_sensitive_network_action(command: str) -> bool:
    cmd = str(command or "").strip().lower()
    if not cmd:
        return False
    return bool(re.search(r"(?:^|\s)(curl|wget|invoke-webrequest|iwr)\s+https?://", cmd))


def _upsert_generated_rule(
    rule: dict[str, Any],
    *,
    workspace: str | Path | None = None,
    scope: str = "workspace",
) -> Path:
    name = str(rule.get("name") or "").strip()
    if not name:
        raise ValueError("Rule name is required.")
    policy_path = _select_generated_policy_path(workspace=workspace, scope=scope)
    payload = _load_generated_payload(policy_path)
    raw_rules = payload.get("rule")
    rules = raw_rules if isinstance(raw_rules, list) else []
    next_rules = [item for item in rules if not (isinstance(item, dict) and str(item.get("name") or "") == name)]
    next_rules.append(rule)
    payload["rule"] = next_rules
    _save_generated_payload(policy_path, payload)
    return policy_path


def persist_permanent_approval(
    tool_name: str,
    args: dict[str, Any] | None = None,
    *,
    mode: str = "default",
    workspace: str | Path | None = None,
    scope: str = "workspace",
) -> Path:
    args = args or {}
    normalized_mode = normalize_mode(mode)
    rule: dict[str, Any] = {
        "toolName": str(tool_name or "*"),
        "decision": "allow",
        "priority": 780,
        "modes": [normalized_mode] if normalized_mode else [],
    }
    match_scope = "global"
    if tool_name == "run_command":
        command = str(args.get("command") or "").strip()
        if command:
            parts = command.split()
            command_prefix = " ".join(parts[:2]).lower().strip()
            if command_prefix:
                rule["commandPrefix"] = command_prefix
                match_scope = command_prefix
    path_value = args.get("path")
    if isinstance(path_value, str) and path_value.strip():
        normalized_path = path_value.strip().replace("\\", "/")
        rule["argsPattern"] = re.escape(normalized_path)
        match_scope = normalized_path
    rule["name"] = f"approval:{normalized_mode}:{tool_name}:{_slug(match_scope)}"
    return _upsert_generated_rule(rule, workspace=workspace, scope=scope)


def list_generated_approval_rules(
    *,
    workspace: str | Path | None = None,
    scope: str = "workspace",
) -> list[dict[str, Any]]:
    policy_path = _select_generated_policy_path(workspace=workspace, scope=scope)
    payload = _load_generated_payload(policy_path)
    rules = payload.get("rule")
    if not isinstance(rules, list):
        return []
    approvals: list[dict[str, Any]] = []
    for item in rules:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        if name.startswith(APPROVAL_RULE_PREFIX):
            approvals.append(item)
    return sorted(approvals, key=lambda row: str(row.get("name") or ""))


def remove_generated_approval(
    name_or_index: str,
    *,
    workspace: str | Path | None = None,
    scope: str = "workspace",
) -> dict[str, Any] | None:
    policy_path = _select_generated_policy_path(workspace=workspace, scope=scope)
    payload = _load_generated_payload(policy_path)
    rules = payload.get("rule")
    if not isinstance(rules, list) or not rules:
        return None
    approvals = list_generated_approval_rules(workspace=workspace, scope=scope)
    if not approvals:
        return None
    target: dict[str, Any] | None = None
    raw = str(name_or_index or "").strip()
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(approvals):
            target = approvals[idx]
    else:
        for item in approvals:
            if str(item.get("name") or "") == raw:
                target = item
                break
    if target is None:
        return None
    target_name = str(target.get("name") or "")
    payload["rule"] = [
        item for item in rules
        if not (isinstance(item, dict) and str(item.get("name") or "") == target_name)
    ]
    _save_generated_payload(policy_path, payload)
    return target


def permission_log_path() -> Path:
    return Path.home() / ".msapling" / "logs" / "cli.jsonl"


def load_permission_decisions(
    *,
    limit: int = 30,
    decision: str | None = None,
    tool: str | None = None,
) -> list[dict[str, Any]]:
    path = permission_log_path()
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    want_decision = str(decision or "").strip().lower()
    want_tool = str(tool or "").strip().lower()
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except Exception:
                continue
            if str(record.get("event") or "") != "PERMISSION_DECISION":
                continue
            data = record.get("data")
            if not isinstance(data, dict):
                continue
            got_decision = str(data.get("decision") or "").lower()
            got_tool = str(data.get("tool") or "").lower()
            if want_decision and got_decision != want_decision:
                continue
            if want_tool and got_tool != want_tool:
                continue
            rows.append(
                {
                    "ts": str(record.get("ts") or ""),
                    "session": str(record.get("session") or ""),
                    "decision": got_decision,
                    "tool": got_tool,
                    "mode": str(data.get("mode") or ""),
                    "source": str(data.get("source") or ""),
                    "reason": str(data.get("reason") or ""),
                    "permission_role": str(data.get("permission_role") or ""),
                    "permission_name": str(data.get("permission_name") or ""),
                    "correlation_id": str(data.get("correlation_id") or ""),
                    "policy_rule": str(data.get("policy_rule") or ""),
                    "policy_tier": str(data.get("policy_tier") or ""),
                }
            )
    except Exception:
        return []
    rows.reverse()
    if limit <= 0:
        return rows
    return rows[:limit]
