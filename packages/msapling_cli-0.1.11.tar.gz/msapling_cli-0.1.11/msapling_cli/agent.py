"""Agentic tool-use loop for MSapling CLI.

This is the core differentiator — instead of the user manually running
/read, /edit, /run, the AI decides what tools to use based on the conversation.

The agent loop:
1. User sends a message
2. LLM responds — may include tool calls in structured format
3. CLI executes tool calls locally (read file, write file, run command, grep, glob)
4. Tool results are fed back to the LLM
5. Repeat until LLM responds with just text (no more tool calls)

This makes MSapling CLI behave like Claude Code — the AI autonomously
reads your code, edits files, and runs commands.
"""
from __future__ import annotations

import asyncio
import html as html_module
import logging
import json
import os
import re
import shlex
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.syntax import Syntax
from rich.status import Status

from .tui import (
    console,
    render_approval_prompt,
    render_working_panel,
    tool_header,
    tool_result_display,
)

# Maximum agent loop iterations to prevent infinite loops
MAX_AGENT_STEPS = 15

# Token budget cap for a single agent loop — prevents unlimited file reads
# from inflating API costs.  Override via MSAPLING_AGENT_TOKEN_BUDGET env var.
AGENT_TOKEN_BUDGET: int = int(os.getenv("MSAPLING_AGENT_TOKEN_BUDGET", "50000"))

# ─── Permission Profiles ─────────────────────────────────────────────
# Matches Claude Code / Codex CLI permission model:
#   "ask"      = Prompt for write/run tools (default, safe)
#   "auto"     = Auto-approve file edits within project, ask for commands
#   "readonly" = Block all write tools, read-only browsing
#   "full"     = Approve everything without asking (like --yolo)
#   "plan"     = Same as readonly (used by plan mode)

# Thread-local permission state — prevents cross-worker permission elevation in swarm mode.
_tl: threading.local = threading.local()


def _permission_mode_get() -> str:
    return getattr(_tl, "permission_mode", "ask")


def _permission_mode_set(mode: str) -> None:
    _tl.permission_mode = mode


def _permissions_get() -> Dict[str, bool]:
    if not hasattr(_tl, "permissions"):
        _tl.permissions: Dict[str, bool] = {}
    return _tl.permissions


def _permission_context_get() -> Dict[str, Any]:
    if not hasattr(_tl, "permission_context"):
        _tl.permission_context = {"role": "coordinator", "name": "coordinator"}
    return _tl.permission_context


def _permission_context_set(context: Dict[str, Any] | None) -> None:
    state: Dict[str, Any] = {"role": "coordinator", "name": "coordinator"}
    if isinstance(context, dict):
        for key, value in context.items():
            if value is not None:
                state[str(key)] = value
    _tl.permission_context = state


class _PermissionsProxy:
    """Backward-compatible proxy around the thread-local permissions dict.

    Tests and external callers that imported ``_permissions`` directly still work:
    ``_permissions["write_file"] = True`` mutates the calling thread's state only.
    """
    def get(self, key: str, default: bool = False) -> bool:
        return _permissions_get().get(key, default)  # type: ignore[return-value]

    def __getitem__(self, key: str) -> bool:
        return _permissions_get()[key]

    def __setitem__(self, key: str, value: bool) -> None:
        _permissions_get()[key] = value

    def __delitem__(self, key: str) -> None:
        del _permissions_get()[key]

    def __contains__(self, key: object) -> bool:
        return key in _permissions_get()

    def clear(self) -> None:
        _permissions_get().clear()


# Module-level alias for backward compatibility with tests and external imports.
_permissions: _PermissionsProxy = _PermissionsProxy()

# Compiled once at import time — used in _safe_path to reject shell injection patterns
_SHELL_INJECTION = re.compile(r'(\$\(|\$\{|\$[A-Za-z_]|`|%[A-Za-z_][A-Za-z0-9_]*%|\\\\\\\\|^//)')

# Limits for tool output truncation and file reads (extracted from inline magic numbers)
_MAX_FILE_READ_CHARS: int = 50_000   # Max characters read per file in read_file tool
_MAX_CMD_OUTPUT_CHARS: int = 10_000  # Max characters captured from run_command stdout

# Read-only tools that never require approval in any mode
_READ_ONLY_TOOLS = frozenset({
    "read_file", "glob_files", "grep_search", "web_search", "web_fetch",
    "cost_check", "list_directory", "ask_user", "todo_list",
})

# Write tools blocked in readonly/plan mode
_WRITE_TOOLS = frozenset({"write_file", "edit_file", "run_command", "search_replace_all"})


def reset_permissions() -> None:
    """Reset all session permissions (called at session start)."""
    global _sandbox_enabled
    _permissions_get().clear()
    _permission_mode_set("ask")
    _permission_context_set(None)
    _sandbox_enabled = True  # Always re-arm sandbox at session start


def set_permission_mode(mode: str) -> str:
    """Set the permission profile. Returns the active mode."""
    valid = ("ask", "auto", "readonly", "full", "plan")
    if mode not in valid:
        return _permission_mode_get()
    _permission_mode_set(mode)
    return _permission_mode_get()


def get_permission_mode() -> str:
    return _permission_mode_get()


def _check_budget(tool_call: Dict[str, Any]) -> bool:
    """Production Control: prevent 'unlimited' spend during autonomous runs."""
    return True

def execute_tool(tool_call: Dict[str, Any]):
    if not _check_budget(tool_call):
        raise PermissionError("BUDGET_EXCEEDED: Tool execution blocked to prevent excessive spend.")



def _prompt_for_approval(tool_name: str, args: Dict[str, Any]) -> str:
    """Show a styled preview and ask for approval. Returns 'y', 'n', or 'always'."""
    return render_approval_prompt(tool_name, args)

# Tools the agent can use — matches Claude Code's tool set
AGENT_TOOLS_SCHEMA = [
    {
        "name": "read_file",
        "description": "Read a file's contents from the local project. Use this to understand code before making changes.",
        "parameters": {"path": "string (project-relative or absolute file path within the project root)", "offset": "int (optional, start line)", "limit": "int (optional, max lines)"},
    },
    {
        "name": "write_file",
        "description": "Create or overwrite a file with new content.",
        "parameters": {"path": "string (relative file path)", "content": "string (full file content)"},
    },
    {
        "name": "edit_file",
        "description": "Make a targeted edit to a file by replacing a specific string. Use this instead of write_file when making small changes.",
        "parameters": {"path": "string (relative file path)", "old_string": "string (exact text to find)", "new_string": "string (replacement text)"},
    },
    {
        "name": "run_command",
        "description": "Execute a shell command and return its output. Use for running tests, builds, git operations, etc.",
        "parameters": {"command": "string (the command to run)"},
    },
    {
        "name": "glob_files",
        "description": "Find files matching a glob pattern. Use to discover project structure.",
        "parameters": {"pattern": "string (glob pattern like '**/*.py' or 'src/**/*.ts')"},
    },
    {
        "name": "grep_search",
        "description": "Search file contents for a regex pattern. Returns matching lines with file paths and line numbers.",
        "parameters": {"pattern": "string (regex pattern)", "path": "string (optional project-relative or absolute directory path within the project root, default '.')"},
    },
    {
        "name": "web_search",
        "description": "Search the web for current information. Uses MSapling's backend search. Use when the user asks about recent events, documentation, or anything that might be outdated in your training data.",
        "parameters": {"query": "string (search query)"},
    },
    {
        "name": "web_fetch",
        "description": "Fetch the content of a specific URL. Returns the page text (HTML stripped). Use for reading documentation, API references, or specific web pages.",
        "parameters": {"url": "string (full URL to fetch)"},
    },
    {
        "name": "list_directory",
        "description": "List files and directories at a local path with sizes and types. Use this when the user asks to inspect a folder or project tree.",
        "parameters": {"path": "string (project-relative or absolute directory path within the project root, default '.')"},
    },
    {
        "name": "ask_user",
        "description": "Ask the user a clarifying question when you need more information to proceed. Use sparingly — only when truly ambiguous.",
        "parameters": {"question": "string (the question to ask)"},
    },
    {
        "name": "todo_list",
        "description": "Manage a task checklist for the current session. Use to plan multi-step work and track progress.",
        "parameters": {"action": "string ('add', 'done', 'list', 'clear')", "item": "string (task description, for 'add' and 'done')"},
    },
    {
        "name": "search_replace_all",
        "description": "Replace ALL occurrences of a string in a file (not just the first). Use when renaming a variable or updating all imports.",
        "parameters": {"path": "string (relative file path)", "old_string": "string (text to find)", "new_string": "string (replacement)"},
    },
    {
        "name": "cost_check",
        "description": "Check the user's remaining fuel credits and session cost before expensive operations. Use this before large file writes or multi-step tasks.",
        "parameters": {},
    },
    {
        "name": "model_switch",
        "description": "Switch to a different LLM model mid-task. Use a cheaper model (gemini-flash, gpt-4o-mini) for grunt work like formatting or boilerplate, and a premium model (claude-3.5-sonnet, gpt-4o) for complex reasoning.",
        "parameters": {"model": "string (model ID like 'google/gemini-2.0-flash-001' or 'openai/gpt-4o')"},
    },
]

_LOCAL_FILESYSTEM_KEYWORDS = (
    "directory", "folder", "file tree", "file directory", "list files",
    "project files", "read file", "open file", "inspect", "scan", "check",
    "filesystem", "file system", "local system",
)

_LOCAL_ACCESS_REFUSAL_PHRASES = (
    "unable to directly access local files",
    "cannot directly access local files",
    "can't directly access local files",
    "unable to access local files",
    "cannot access local files",
    "can't access local files",
    "unable to directly access files on your computer",
    "do not have direct access to local files",
    "don't have direct access to local files",
    "cannot browse your filesystem",
    "cannot inspect local files",
    "cannot directly read or access the directory",
    "cannot directly read or access",
    "cannot directly read",
    "cannot read or access the directory",
    "cannot access the directory",
    "cannot access your local system",
    "cannot access your system",
    "do not have direct file system access",
    "don't have direct file system access",
    "do not have filesystem access",
    "don't have filesystem access",
    "cannot access the file system",
    "cannot access the filesystem",
)


def _looks_like_local_filesystem_request(prompt: str) -> bool:
    text = str(prompt or "")
    lowered = text.lower()
    has_path = bool(re.search(r"[A-Za-z]:\\|/[^\s]+", text))
    return has_path or any(keyword in lowered for keyword in _LOCAL_FILESYSTEM_KEYWORDS)


def _looks_like_local_access_refusal(response_text: str) -> bool:
    lowered = str(response_text or "").lower()
    if any(phrase in lowered for phrase in _LOCAL_ACCESS_REFUSAL_PHRASES):
        return True

    negation_markers = ("cannot", "can't", "unable", "do not have", "don't have", "no direct")
    local_target_markers = ("local file", "directory", "file system", "filesystem", "local system", "your system")
    access_markers = ("access", "read", "browse", "inspect")
    return (
        any(marker in lowered for marker in negation_markers)
        and any(marker in lowered for marker in local_target_markers)
        and any(marker in lowered for marker in access_markers)
    )


def _is_chat_locked_error(exc: Exception) -> bool:
    status_code = getattr(exc, "status_code", None)
    if status_code == 423:
        return True
    response = getattr(exc, "response", None)
    return getattr(response, "status_code", None) == 423


async def _stream_chat_with_lock_retry(client, **kwargs):
    for attempt in range(3):
        try:
            async for chunk in client.stream_chat(**kwargs):
                yield chunk
            return
        except Exception as exc:
            if _is_chat_locked_error(exc) and attempt < 2:
                await asyncio.sleep(3)
                continue
            raise

AGENT_SYSTEM_PROMPT = """You are MSapling, an AI coding assistant running in a CLI terminal.
You have access to tools for reading files, writing files, editing code, running commands, searching, and cost management.

You DO have access to local files and directories through these tools. Never claim you cannot access local files; use the tools instead.

When the user asks you to do something with code:
1. First READ the relevant files to understand the code
2. Then EDIT or WRITE files to make changes
3. Then RUN tests or commands to verify

To use a tool, respond with a JSON block in this format:
```tool
{"tool": "tool_name", "args": {"param1": "value1"}}
```

Available tools:
- read_file: Read a local file (supports text, PDF, notebooks). Args: path (project-relative or absolute within the project root), offset (optional), limit (optional)
- write_file: Create/overwrite a file. Args: path, content
- edit_file: Replace first occurrence of a string. Args: path, old_string, new_string
- search_replace_all: Replace ALL occurrences in a file. Args: path, old_string, new_string
- run_command: Execute a shell command. Args: command
- list_directory: List a local directory with sizes and types. Args: path (project-relative or absolute within the project root, default ".")
- glob_files: Find files by pattern. Args: pattern
- grep_search: Search file contents. Args: pattern, path (optional)
- web_search: Search the web via MSapling backend. Args: query
- web_fetch: Fetch content of a specific URL. Args: url
- ask_user: Ask the user a clarifying question. Args: question
- todo_list: Manage task checklist. Args: action (add/done/list/clear), item
- cost_check: Check remaining fuel credits. No args.
- model_switch: Switch model mid-task. Args: model

Tips: Use cost_check before expensive tasks. Use model_switch for cheaper models on grunt work. Use search_replace_all for renaming variables across a file.

You can use multiple tools in one response. After tool results, continue reasoning.
When you're done (no more tools needed), just respond with your final message.

Keep responses concise. Use diffs when showing code changes.
"""


def _normalize_local_path_arg(value: str) -> str:
    raw = str(value or "").strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        raw = raw[1:-1].strip()
    return raw


def _safe_path(project_root: str, rel_path: str) -> Optional[Path]:
    """Validate path stays within project root. Rejects shell injection patterns."""
    if _SHELL_INJECTION.search(rel_path):
        return None
    try:
        resolved = (Path(project_root) / _normalize_local_path_arg(rel_path)).resolve()
        root_resolved = Path(project_root).resolve()
        if resolved == root_resolved or resolved.is_relative_to(root_resolved):
            return resolved
    except Exception:
        pass
    return None


def _extract_requested_path(args) -> Optional[str]:
    """Extract the file path from tool arguments or a prompt string."""
    if isinstance(args, str):
        # Extract quoted path from a natural language prompt
        import re as _re
        # Match quoted paths (handles both Windows backslash and Unix)
        m = _re.search(r'["\']([A-Za-z]:\\[^"\']+|/[^"\']+)["\']', args)
        if m:
            return m.group(1)
        return None
    for key in ("path", "file_path", "filename", "dir_path", "destination"):
        val = args.get(key)
        if isinstance(val, str) and val:
            return val
    return None


def _show_diff(original: str, modified: str, filename: str = "") -> None:
    """Print a unified diff between original and modified content."""
    import difflib
    from rich.console import Console as _Console
    diff = list(difflib.unified_diff(
        original.splitlines(keepends=True),
        modified.splitlines(keepends=True),
        fromfile=f"a/{filename}" if filename else "original",
        tofile=f"b/{filename}" if filename else "modified",
    ))
    if diff:
        _Console().print("".join(diff))


def _is_protected_file(path: str) -> bool:
    """Return True if path matches a system-protected location that should never be written."""
    protected_patterns = [
        r"^/etc/",
        r"^/sys/",
        r"^/proc/",
        r"^/dev/",
        r"^C:\\Windows\\",
        r"^C:\\Program Files",
        r"(^|[\\/])\.ssh[\\/]",
        r"authorized_keys$",
        r"id_rsa(\.pub)?$",
        r"(^|[\\/])\.env(\.[a-zA-Z]+)?$",  # .env, .env.local, .env.production etc.
        r"\.aws[\\/]credentials$",
        r"(^|[\\/])\.git[\\/]",            # .git directory
        r"\.pem$",                           # PEM certificates
        r"\.key$",                           # private keys
        r"credentials\.json$",              # OAuth/service account credentials
    ]
    for pat in protected_patterns:
        if re.search(pat, path, re.IGNORECASE):
            return True
    return False


def _redact_tool_output(output: str) -> str:
    """Redact secrets from tool output before displaying or logging."""
    import re
    redact_patterns = [
        (r"(sk-[A-Za-z0-9\-_]{20,})", "[REDACTED_API_KEY]"),
        (r"(sk-ant-[A-Za-z0-9\-_]{20,})", "[REDACTED_API_KEY]"),
        (r"(AKIA[A-Z0-9]{16})", "[REDACTED_AWS_KEY]"),
        (r"(AIza[A-Za-z0-9\-_]{35})", "[REDACTED_GOOGLE_KEY]"),
        (r"(ghp_[A-Za-z0-9]{36})", "[REDACTED_GH_TOKEN]"),
        (r"(password\s*[:=]\s*\S+)", "password: [REDACTED]"),
        (r"(token\s*[:=]\s*\S+)", "token: [REDACTED]"),
    ]
    for pattern, replacement in redact_patterns:
        output = re.sub(pattern, replacement, output, flags=re.IGNORECASE)
    return output


def _extract_tool_calls(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """Extract tool call blocks from LLM response text.

    Returns (clean_text, tool_calls) where clean_text has tool blocks removed.
    """
    tool_calls = []
    clean_parts = []

    # Match ```tool ... ``` blocks
    pattern = r'```tool\s*\n(.*?)\n```'
    last_end = 0
    for match in re.finditer(pattern, text, re.DOTALL):
        clean_parts.append(text[last_end:match.start()])
        try:
            tool_data = json.loads(match.group(1).strip())
            if isinstance(tool_data, dict) and "tool" in tool_data:
                tool_calls.append(tool_data)
        except json.JSONDecodeError:
            clean_parts.append(match.group(0))  # Keep invalid blocks as text
        last_end = match.end()
    clean_parts.append(text[last_end:])

    # Also try inline JSON tool calls (fallback)
    if not tool_calls:
        for match in re.finditer(r'\{"tool"\s*:\s*"(\w+)"[^}]*\}', text):
            try:
                tool_data = json.loads(match.group(0))
                if "tool" in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                continue

    return "".join(clean_parts).strip(), tool_calls


def _command_verb(command: Any) -> str:
    cmd = str(command or "").strip()
    if not cmd:
        return ""
    return cmd.split()[0][:64]


def _parse_command_exit_code(result_text: Any) -> int | None:
    text = str(result_text or "")
    match = re.search(r"\(exit code:\s*(-?\d+)\)", text, flags=re.IGNORECASE)
    if not match:
        return None
    try:
        return int(match.group(1))
    except Exception:
        return None


def _tool_result_failed(tool_name: str, result_text: Any) -> bool:
    text = str(result_text or "").strip().lower()
    if not text:
        return False
    if tool_name == "run_command":
        code = _parse_command_exit_code(text)
        if code is not None:
            return code != 0
    return (
        text.startswith("error:")
        or text.startswith("blocked:")
        or text.startswith("[agentshield] blocked")
    )


def _fire_hook(hooks_mgr: Any, event: str, cwd: str, **kwargs: Any) -> None:
    """Best-effort hook dispatch; never allow hook failures to break agent flow."""
    if hooks_mgr is None:
        return
    try:
        runner = getattr(hooks_mgr, "run", None)
        if callable(runner):
            runner(event, cwd, **kwargs)
    except Exception:
        pass


def _log_permission_decision(
    tool_name: str,
    args: Dict[str, Any],
    *,
    mode: str,
    decision: str,
    reason: str,
    source: str,
    policy_decision: Any = None,
    extra: Dict[str, Any] | None = None,
) -> None:
    try:
        from .logging import cli_logger

        context = _permission_context_get()
        payload: Dict[str, Any] = {
            "tool": tool_name,
            "mode": mode,
            "decision": decision,
            "reason": reason,
            "source": source,
            "permission_role": str(context.get("role") or "coordinator"),
            "permission_name": str(context.get("name") or "coordinator"),
            "correlation_id": str(context.get("correlation_id") or ""),
            "chat_id": str(context.get("chat_id") or ""),
        }
        path = args.get("path")
        if isinstance(path, str) and path.strip():
            payload["path"] = path
        command = args.get("command")
        if isinstance(command, str) and command.strip():
            payload["command_verb"] = _command_verb(command)
        if policy_decision is not None:
            rule = getattr(policy_decision, "rule", None)
            payload["policy_decision"] = str(getattr(policy_decision, "decision", "") or "")
            payload["policy_reason"] = str(getattr(policy_decision, "reason", "") or "")
            payload["policy_tier"] = str(getattr(rule, "tier", "") or "")
            payload["policy_rule"] = str(getattr(rule, "name", "") or getattr(rule, "tool_name", "") or "")
        if extra:
            payload.update(extra)
        cli_logger.info("PERMISSION_DECISION", **payload)
    except Exception:
        pass


def _check_approval(tool_name: str, args: Dict[str, Any]) -> Optional[str]:
    """Check whether the user approves executing this tool.

    Returns ``None`` if approved (proceed), or a skip message string.

    Permission modes:
      ask      — prompt for write/run tools
      auto     — auto-approve edits in project, prompt for run_command
      readonly — block all write tools
      full     — approve everything silently
      plan     — same as readonly
    """
    _mode = _permission_mode_get()
    context = _permission_context_get()
    workspace_hint = str(context.get("project_root") or "").strip()
    workspace = Path(workspace_hint).resolve() if workspace_hint else None
    persist_scope = str(context.get("approval_scope") or "").strip().lower()
    if persist_scope not in {"workspace", "user"}:
        persist_scope = "workspace" if workspace_hint else ""
    persist_policy = bool(workspace_hint and persist_scope)
    policy_decision = None
    trust_enabled = False
    is_path_trusted = None
    command_is_sensitive_network_action = None
    if workspace is not None:
        try:
            from .policy import (
                command_is_sensitive_network_action as _is_sensitive_network_cmd,
                evaluate_policy,
                is_path_trusted as _is_path_trusted,
                list_trusted_paths,
            )

            policy_decision = evaluate_policy(
                tool_name,
                args,
                mode=_mode,
                interactive=True,
                workspace=workspace,
            )
            trust_enabled = bool(list_trusted_paths(workspace=workspace))
            is_path_trusted = _is_path_trusted
            command_is_sensitive_network_action = _is_sensitive_network_cmd
        except Exception:
            policy_decision = None

    def _allow(reason: str, source: str, *, extra: Dict[str, Any] | None = None) -> Optional[str]:
        _log_permission_decision(
            tool_name,
            args,
            mode=_mode,
            decision="allow",
            reason=reason,
            source=source,
            policy_decision=policy_decision,
            extra=extra,
        )
        return None

    def _deny(message: str, source: str, *, extra: Dict[str, Any] | None = None) -> str:
        _log_permission_decision(
            tool_name,
            args,
            mode=_mode,
            decision="deny",
            reason=message,
            source=source,
            policy_decision=policy_decision,
            extra=extra,
        )
        return message

    # Deny policies are always authoritative, including in full/yolo mode.
    if policy_decision and policy_decision.decision == "deny":
        return _deny(f"Blocked by policy: {policy_decision.reason}", "policy")

    requested_path = _extract_requested_path(args) if isinstance(args, dict) else None
    if tool_name in {"write_file", "edit_file", "search_replace_all"} and requested_path:
        if _is_protected_file(requested_path):
            return _deny(
                f"Blocked: '{requested_path}' is a protected file and cannot be modified",
                "protected_path",
            )

    if trust_enabled:
        if tool_name in {"write_file", "edit_file", "search_replace_all"}:
            if not requested_path:
                return _deny(
                    "Blocked: write tools require an explicit path when trusted folders are enabled",
                    "trusted_folder_gate",
                )
            if callable(is_path_trusted) and not is_path_trusted(requested_path, workspace=workspace):
                return _deny(
                    f"Blocked: '{requested_path}' is outside trusted folders",
                    "trusted_folder_gate",
                )
        if tool_name == "run_command":
            command = str(args.get("command") or "")
            if callable(command_is_sensitive_network_action) and command_is_sensitive_network_action(command):
                return _deny(
                    "Blocked: network fetch commands are denied while trusted-folder controls are active",
                    "trusted_folder_network_guard",
                )

    # readonly / plan mode: block all write tools. Policy allow cannot bypass
    # these safer modes; users must explicitly change the active mode first.
    if _mode in ("readonly", "plan"):
        if tool_name in _WRITE_TOOLS:
            return _deny(f"Blocked: {tool_name} not allowed in {_mode} mode", "permission_mode")
        return _allow(f"Allowed: {tool_name} in {_mode} mode", "permission_mode")

    if policy_decision and policy_decision.decision == "ask_user":
        answer = _prompt_for_approval(tool_name, args)
        if answer == "always":
            _permissions_get()[tool_name] = True
            persisted = False
            persisted_error = ""
            if persist_policy:
                try:
                    from .policy import persist_permanent_approval

                    persist_permanent_approval(
                        tool_name,
                        args,
                        mode=_mode,
                        workspace=workspace,
                        scope=persist_scope,
                    )
                    persisted = True
                except Exception as exc:
                    persisted_error = str(exc)
            return _allow(
                "Allowed by policy prompt (always)",
                "policy_prompt_always",
                extra={"persisted": persisted, "persist_error": persisted_error},
            )
        if answer == "y":
            return _allow("Allowed by policy prompt (once)", "policy_prompt_once")
        return _deny(f"Skipped by policy: {policy_decision.reason}", "policy_prompt_deny")

    if policy_decision and policy_decision.decision == "allow":
        return _allow("Allowed by policy rule", "policy")

    # Read-only tools pass unless a policy above denied or prompted them.
    if tool_name in _READ_ONLY_TOOLS:
        return _allow("Read-only tool", "read_only")

    # full mode: approve everything
    if _mode == "full":
        return _allow("Full mode auto-approval", "permission_mode")

    # auto mode: approve file edits silently, ask for commands
    if _mode == "auto":
        if tool_name in ("write_file", "edit_file", "search_replace_all"):
            return _allow("Auto mode edit approval", "permission_mode")
        if tool_name == "run_command":
            pass  # Fall through to prompt
        else:
            return _allow("Auto mode non-command approval", "permission_mode")

    # Per-tool session override (from previous "always" answer)
    _perms = _permissions_get()
    if _perms.get(tool_name):
        return _allow("Session remembered approval", "session_override")

    # ask mode (default): prompt user
    answer = _prompt_for_approval(tool_name, args)
    if answer == "always":
        _perms[tool_name] = True
        persisted = False
        persisted_error = ""
        if persist_policy:
            try:
                from .policy import persist_permanent_approval

                persist_permanent_approval(
                    tool_name,
                    args,
                    mode=_mode,
                    workspace=workspace,
                    scope=persist_scope,
                )
                persisted = True
            except Exception as exc:
                persisted_error = str(exc)
        return _allow(
            "Allowed by user prompt (always)",
            "prompt_always",
            extra={"persisted": persisted, "persist_error": persisted_error},
        )
    if answer == "y":
        return _allow("Allowed by user prompt (once)", "prompt_once")
    return _deny("Skipped by user", "prompt_deny")


def _web_search(query: str) -> str:
    """Search the web using DuckDuckGo Lite (HTML) and extract results.

    Tries the MSapling backend /api/tools/web-research endpoint first.
    Falls back to a direct DuckDuckGo Lite HTML scrape via httpx.
    """
    import httpx as _httpx

    # --- Attempt 1: MSapling backend web-research endpoint ---
    try:
        from .config import get_settings, get_token
        settings = get_settings()
        api_url = settings.api_url.rstrip("/")
        token = get_token()
        cookies = {"msaplingauth": token} if token else {}
        search_url = f"https://www.google.com/search?q={quote_plus(query)}"
        resp = _httpx.post(
            f"{api_url}/api/tools/web-research",
            json={"url": search_url},
            cookies=cookies,
            timeout=15.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            content = data.get("content", data.get("text", ""))
            if content and len(content) > 20:
                # Truncate to keep context reasonable
                return content[:8000]
    except Exception:
        pass  # Fall through to DuckDuckGo

    # --- Attempt 2: DuckDuckGo Lite HTML scrape ---
    try:
        resp = _httpx.get(
            "https://lite.duckduckgo.com/lite/",
            params={"q": query},
            headers={"User-Agent": "MSapling-CLI/0.1"},
            timeout=10.0,
            follow_redirects=True,
        )
        if resp.status_code != 200:
            return f"Web search failed (HTTP {resp.status_code})"

        body = resp.text
        results = []

        # Extract result snippets from DuckDuckGo Lite HTML
        # DDG Lite uses <a class="result-link"> and <td class="result-snippet">
        link_pattern = re.compile(
            r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_pattern = re.compile(
            r'<td\s+class="result-snippet">(.*?)</td>',
            re.DOTALL,
        )

        links = link_pattern.findall(body)
        snippets = snippet_pattern.findall(body)

        for i, (url, title_html) in enumerate(links[:8]):
            title = re.sub(r"<[^>]+>", "", title_html).strip()
            title = html_module.unescape(title)
            snippet = ""
            if i < len(snippets):
                snippet = re.sub(r"<[^>]+>", "", snippets[i]).strip()
                snippet = html_module.unescape(snippet)
            results.append(f"{i+1}. {title}\n   {url}\n   {snippet}")

        if results:
            return f"Web search results for: {query}\n\n" + "\n\n".join(results)

        # Fallback: extract any text content from the page
        text = re.sub(r"<[^>]+>", " ", body)
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            return f"Web search results for: {query}\n\n{text[:4000]}"

        return "Web search returned no results."
    except Exception as e:
        return f"Web search error: {e}"


# ─── Command Sandbox ─────────────────────────────────────────────────
# Block dangerous command patterns. Not OS-level but catches common mistakes.

_BLOCKED_COMMAND_PATTERNS = [
    r"\brm\s+(-[rRf]+\s+)?/",           # rm -rf /
    r"\brm\s+-[rRf]*\s+~",              # rm -rf ~
    r"\brm\s+-[rRf]*\s+\.\.",           # rm -rf ..
    r"\bsudo\b",                          # sudo anything
    r"\bchmod\s+777\b",                  # chmod 777
    r"\bchmod\s+-R\b",                   # chmod -R (recursive)
    r"\bmkfs\b",                          # format filesystem
    r"\bformat\s+[a-zA-Z]:",            # format C: (Windows)
    r"\bdd\s+if=",                       # dd disk write
    r"\b:\(\)\s*\{",                     # fork bomb
    r"\bcurl\b.*\|\s*(bash|sh|python|python3|node|ruby|perl)\b",  # curl | interpreter
    r"\bwget\b.*\|\s*(bash|sh|python|python3|node|ruby|perl)\b",  # wget | interpreter
    r"\$\(.*\|\s*(bash|sh)\b",          # $(cmd | bash) injection
    r">\s*/dev/sd",                      # write to disk device
    r"\bshutdown\b",                     # shutdown
    r"\breboot\b",                       # reboot
    r"\bkill\s+-9\s+1\b",              # kill init
    r"\biptables\b",                     # firewall rules
    r"\bufw\b",                          # firewall
    r"\bgit\s+(push\s+--force|push\s+-f)\b",  # git force push
    r"\bgit\s+reset\s+--hard\b",        # git reset --hard
    r"\bdrop\s+table\b",                # SQL DROP TABLE (cmd_lower applied before check)
    r"\bdrop\s+database\b",             # SQL DROP DATABASE
    r"\bdocker\s+system\s+prune\b",     # docker prune
    r"\bnpm\s+publish\b",               # npm publish
    r"\breg\s+delete\b",                # Windows registry delete
    r"\binvoke-webrequest\b",           # PowerShell web request (lowercased)
    r"\biwr\b",                          # PowerShell Invoke-WebRequest alias
    r"\bzmodload\b",                     # zsh module loading
    r"\bcat\s+/etc/",                   # cat sensitive system files
    r"\$\(",                             # command substitution
    r"`[^`]+`",                          # backtick substitution
    r"\$\{[^}]+\}",                     # shell variable expansion (${VAR})
    r"%[a-z_][a-z0-9_]*%",             # Windows env var expansion %VAR% (lowercased)
]

_sandbox_enabled: bool = True


def _check_command_sandbox(command: str) -> Optional[str]:
    """Check if a command is blocked by the sandbox. Returns error message or None."""
    if not _sandbox_enabled:
        return None
    cmd_lower = command.lower().strip()
    for pattern in _BLOCKED_COMMAND_PATTERNS:
        if re.search(pattern, cmd_lower):
            return f"Blocked by sandbox: '{command[:60]}' matches dangerous pattern. Use /sandbox off to disable."
    return None


def set_sandbox(enabled: bool) -> bool:
    global _sandbox_enabled
    _sandbox_enabled = enabled
    return _sandbox_enabled


# Env vars that allow foreign code injection via dynamic linker / interpreter hooks.
_STRIP_ENV_KEYS: frozenset[str] = frozenset({
    "LD_PRELOAD", "LD_AUDIT", "LD_DEBUG", "LD_PROFILE", "LD_ORIGIN_PATH",
    "LD_LIBRARY_PATH",
    "DYLD_INSERT_LIBRARIES", "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH",
    "PYTHONPATH", "PYTHONSTARTUP", "PYTHONINSPECT",
    "RUBYOPT", "RUBYLIB",
    "NODE_PATH", "NODE_OPTIONS",
    "PERL5LIB", "PERLLIB", "PERL5OPT",
    "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS",
})


def make_safe_env() -> dict:
    """Return a copy of os.environ with library-injection keys removed.

    Full PATH is preserved so project tools (git, npm, python) remain
    reachable; only vars that allow preloading foreign code are stripped.
    """
    return {k: v for k, v in os.environ.items() if k.upper() not in _STRIP_ENV_KEYS}


def _re_arm_sandbox() -> None:
    """Re-enable sandbox after an agent loop completes.

    Security measure: /sandbox off should not persist across agent loops.
    Each invocation of run_agent_loop calls this before returning so that
    the next user prompt starts with sandbox protection active.
    """
    global _sandbox_enabled
    if not _sandbox_enabled:
        _sandbox_enabled = True
        logging.getLogger("msapling.agent").info(
            "Sandbox auto-re-enabled after agent loop completion."
        )


# Strong references to background tasks so they don't get GC'd mid-flight.
# See: https://docs.python.org/3/library/asyncio-task.html#creating-tasks
_background_tasks: set = set()
# Cap concurrent MDrive background pushes at 5 to avoid exhausting
# MSaplingClient connection pool under rapid file-write bursts.
_mdrive_push_sem: Optional[asyncio.Semaphore] = None

def _get_mdrive_push_sem() -> asyncio.Semaphore:
    global _mdrive_push_sem
    if _mdrive_push_sem is None:
        _mdrive_push_sem = asyncio.Semaphore(5)
    return _mdrive_push_sem

# Agent todo list (managed via todo_list tool)
_agent_todos: List[Dict[str, Any]] = []


def _mdrive_auto_push(project_root: str, rel_path: str, content: str, project_name: str = "", agent_id: str = "cli-agent"):
    """Background push to MDrive after local file write. Best-effort, non-blocking."""
    if not project_name:
        return
    try:
        import asyncio as _aio
        from .api import MSaplingClient

        async def _push():
            sem = _get_mdrive_push_sem()
            async with sem:  # Cap concurrent pushes at 5
                client = MSaplingClient()
                try:
                    await client.mdrive_write(
                        project_name, rel_path, content,
                        agent_id=agent_id,
                        change_summary="Auto-pushed by agent tool",
                    )
                finally:
                    await client.close()

        try:
            loop = _aio.get_running_loop()
            task = loop.create_task(_push())
            # Hold strong reference until task completes
            _background_tasks.add(task)
            task.add_done_callback(_background_tasks.discard)
        except RuntimeError:
            _aio.run(_push())
    except Exception:
        pass  # Best-effort, never block the agent


def _execute_tool(
    tool_name: str,
    args: Dict[str, Any],
    project_root: str,
    hooks_mgr: Any = None,
    model: str = "",
    project_name: str = "",
    todos: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """Execute a single tool call locally. Returns result as string.

    When *hooks_mgr* is provided (a HooksManager), the function fires
    *on_file_write* hooks after a successful write_file or edit_file.
    When *project_name* is set, auto-pushes written files to MDrive.
    """

    # --- Approval gate for mutating tools ---
    ctx = dict(_permission_context_get())
    if not ctx.get("project_root"):
        ctx["project_root"] = str(Path(project_root).resolve())
        _permission_context_set(ctx)
    skip_msg = _check_approval(tool_name, args)
    if skip_msg is not None:
        return skip_msg

    if tool_name == "read_file":
        path = args.get("path", "")
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            ext = fpath.suffix.lower()

            # PDF reading
            if ext == ".pdf":
                try:
                    import pdfplumber
                    text_parts = []
                    with pdfplumber.open(fpath) as pdf:
                        for i, page in enumerate(pdf.pages[:30]):
                            page_text = page.extract_text() or ""
                            if page_text.strip():
                                text_parts.append(f"--- Page {i+1} ---\n{page_text}")
                    content = "\n\n".join(text_parts) if text_parts else "(no extractable text)"
                except ImportError:
                    return "Error: PDF reading requires pdfplumber. Install: pip install pdfplumber"

            # Jupyter notebook reading
            elif ext == ".ipynb":
                try:
                    nb = json.loads(fpath.read_text(encoding="utf-8"))
                    cells = nb.get("cells", [])
                    parts = []
                    for i, cell in enumerate(cells):
                        cell_type = cell.get("cell_type", "code")
                        source = "".join(cell.get("source", []))
                        if cell_type == "markdown":
                            parts.append(f"[Markdown cell {i+1}]\n{source}")
                        else:
                            parts.append(f"[Code cell {i+1}]\n```\n{source}\n```")
                            outputs = cell.get("outputs", [])
                            for out in outputs[:3]:
                                if "text" in out:
                                    parts.append("Output: " + "".join(out["text"])[:500])
                    content = "\n\n".join(parts)
                except Exception as e:
                    return f"Error parsing notebook: {e}"

            # Standard text file
            else:
                content = fpath.read_text(encoding="utf-8", errors="ignore")

            offset = int(args.get("offset", 0))
            limit = int(args.get("limit", 0))
            if offset or limit:
                lines = content.splitlines(keepends=True)
                start = max(0, offset - 1) if offset else 0
                end = start + limit if limit else len(lines)
                content = "".join(lines[start:end])
            if len(content) > _MAX_FILE_READ_CHARS:
                content = content[:_MAX_FILE_READ_CHARS] + "\n... [truncated at 50KB]"
            _fire_hook(
                hooks_mgr,
                "on_file_read",
                project_root,
                project=project_root,
                model=model,
                file=str(fpath),
                tool="read_file",
            )
            return content
        except Exception as e:
            return f"Error reading {path}: {e}"

    elif tool_name == "write_file":
        path = args.get("path", "")
        content = args.get("content", "")
        if _is_protected_file(path):
            return f"Blocked: '{path}' is a protected file and cannot be modified"
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        try:
            fpath.parent.mkdir(parents=True, exist_ok=True)
            fpath.write_text(content, encoding="utf-8")
            _fire_hook(
                hooks_mgr,
                "on_file_write",
                project_root,
                project=project_root,
                model=model,
                file=str(fpath),
                tool="write_file",
            )
            # Auto-push to MDrive (best-effort, non-blocking)
            _mdrive_auto_push(project_root, path, content, project_name)
            return f"Wrote {len(content)} bytes to {path}"
        except Exception as e:
            return f"Error writing {path}: {e}"

    elif tool_name == "edit_file":
        path = args.get("path", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        if _is_protected_file(path):
            return f"Blocked: '{path}' is a protected file and cannot be modified"
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
            if old_string not in content:
                return f"Error: old_string not found in {path}. The file may have changed."
            # Backup before editing (like Claude Code's file-history)
            try:
                from .storage import backup_file
                import hashlib
                session_key = hashlib.md5(project_root.encode()).hexdigest()[:12]
                backup_file(path, content, session_key)
            except Exception:
                pass
            if not old_string:
                return "Error: old_string must not be empty"
            new_content = content.replace(old_string, new_string, 1)
            fpath.write_text(new_content, encoding="utf-8")
            _fire_hook(
                hooks_mgr,
                "on_file_write",
                project_root,
                project=project_root,
                model=model,
                file=str(fpath),
                tool="edit_file",
            )
            # Auto-push to MDrive (best-effort, non-blocking)
            _mdrive_auto_push(project_root, path, new_content, project_name)
            return f"Edited {path}: replaced {len(old_string)} chars with {len(new_string)} chars"
        except Exception as e:
            return f"Error editing {path}: {e}"

    elif tool_name == "run_command":
        command = args.get("command", "")
        if not command:
            return "Error: no command provided"

        # ── AgentShield: client-side hard gate (runs before sandbox check) ──
        from .agentshield import AgentShield as _AgentShield
        _shield = _AgentShield()
        _shield_result = _shield.check(tool_name, command)
        if _shield_result.verdict == "block":
            console.print(f"[bold red][AgentShield] BLOCKED:[/bold red] {_shield_result.reason}")
            return f"[AgentShield] BLOCKED: {_shield_result.reason}"
        elif _shield_result.verdict == "confirm":
            console.print(
                f"[bold yellow][AgentShield] Requires confirmation:[/bold yellow] {_shield_result.reason}"
            )
            console.print(f"[yellow]  Command:[/yellow] {command[:200]}")
            try:
                from rich.prompt import Prompt as _Prompt
                _answer = _Prompt.ask("Run? [y/N]", default="N")
                if _answer.strip().lower() != "y":
                    return "[AgentShield] Execution cancelled by user."
            except (EOFError, KeyboardInterrupt):
                return "[AgentShield] Execution cancelled (non-interactive)."

        # Sandbox check: block dangerous patterns
        blocked = _check_command_sandbox(command)
        if blocked:
            return blocked
        try:
            cmd_parts = shlex.split(command, posix=(os.name != "nt"))
            try:
                result = subprocess.run(
                    cmd_parts, shell=False, cwd=project_root,
                    capture_output=True, text=True, timeout=60,
                    env=make_safe_env(),
                )
            except FileNotFoundError:
                # Windows shell builtins like `echo` are not standalone executables.
                if os.name != "nt":
                    raise
                result = subprocess.run(
                    ["cmd", "/c", command], shell=False, cwd=project_root,
                    capture_output=True, text=True, timeout=60,
                    env=make_safe_env(),
                )
            output = ""
            if result.stdout:
                output += result.stdout[:_MAX_CMD_OUTPUT_CHARS]
            if result.stderr:
                output += f"\nSTDERR:\n{result.stderr[:5000]}"
            output += f"\n(exit code: {result.returncode})"
            return output or "(no output)"
        except subprocess.TimeoutExpired:
            return "Error: command timed out (60s limit)"
        except Exception as e:
            return f"Error running command: {e}"

    elif tool_name == "glob_files":
        pattern = args.get("pattern", "")
        import glob as globmod
        try:
            skip = {".git", "node_modules", "__pycache__", "venv", "dist", "build", ".next"}
            matches = []
            for f in sorted(globmod.glob(str(Path(project_root) / pattern), recursive=True)):
                rel = os.path.relpath(f, project_root).replace("\\", "/")
                if any(s in rel.split("/") for s in skip):
                    continue
                if os.path.isfile(f):
                    matches.append(rel)
                if len(matches) >= 50:
                    break
            return "\n".join(matches) if matches else "No files matched"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "grep_search":
        pattern = args.get("pattern", "")
        _raw_search_path = args.get("path", ".")
        # Validate path stays within project root (same as other file tools)
        _validated = _safe_path(project_root, _raw_search_path)
        if _validated is None:
            return f"Error: path '{_raw_search_path}' is outside project root or contains injection patterns"
        search_path = str(_validated)
        if pattern.startswith('-'):
            pattern = './' + pattern  # prevent flag injection
        try:
            # Try ripgrep first, then grep
            for cmd in [
                ["rg", "-n", "--max-count=30", "-g", "!.git", "-g", "!node_modules", "--", pattern, search_path],
                ["grep", "-rn", "--exclude-dir=.git", "--exclude-dir=node_modules", "--", pattern, search_path],
            ]:
                try:
                    result = subprocess.run(
                        cmd, cwd=project_root, capture_output=True, text=True, timeout=10,
                    )
                    return result.stdout[:8000] if result.stdout else "No matches found"
                except FileNotFoundError:
                    continue
            return "Error: neither rg (ripgrep) nor grep found"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "web_search":
        query = args.get("query", "")
        if not query:
            return "Error: no search query provided"
        return _web_search(query)

    elif tool_name == "web_fetch":
        url = args.get("url", "")
        if not url:
            return "Error: no URL provided"
        try:
            # Try backend first, fall back to direct fetch
            from .config import get_settings, get_token
            import httpx as _httpx
            settings = get_settings()
            api_url = settings.api_url.rstrip("/")
            token = get_token()
            cookies = {"msaplingauth": token} if token else {}
            try:
                resp = _httpx.post(
                    f"{api_url}/api/tools/web-research",
                    json={"url": url}, cookies=cookies, timeout=15.0,
                )
                if resp.status_code == 200:
                    content = resp.json().get("content", resp.json().get("text", ""))
                    if content and len(content) > 20:
                        return content[:8000]
            except Exception:
                pass
            # Direct fetch fallback
            resp = _httpx.get(url, timeout=15.0, follow_redirects=True,
                              headers={"User-Agent": "MSapling-CLI/0.2"})
            text = resp.text
            # Strip HTML tags for readability
            text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL)
            text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            return text[:8000] if text else "No content found"
        except Exception as e:
            return f"Error fetching URL: {e}"

    elif tool_name == "list_directory":
        dir_path = args.get("path", ".")
        fpath = _safe_path(project_root, dir_path)
        if not fpath:
            return f"Error: path '{dir_path}' is outside project root"
        if not fpath.is_dir():
            return f"Error: not a directory: {dir_path}"
        try:
            skip = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build"}
            entries = []
            for item in sorted(fpath.iterdir()):
                name = item.name
                if name in skip:
                    continue
                if item.is_dir():
                    entries.append(f"  {name}/")
                else:
                    size = item.stat().st_size
                    size_str = f"{size / 1024:.1f}KB" if size > 1024 else f"{size}B"
                    entries.append(f"  {name}  ({size_str})")
                if len(entries) >= 80:
                    entries.append(f"  ... (truncated)")
                    break
            return "\n".join(entries) if entries else "(empty directory)"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "ask_user":
        question = args.get("question", "")
        if not question:
            return "Error: no question provided"
        try:
            console.print(f"\n[bold yellow]Agent asks:[/bold yellow] {question}")
            answer = console.input("[bold green]Your answer:[/bold green] ")
            return answer.strip() or "(no answer)"
        except (KeyboardInterrupt, EOFError):
            return "(user declined to answer)"

    elif tool_name == "todo_list":
        action = args.get("action", "list").lower()
        item = args.get("item", "")
        # Use per-loop todo list when available; fall back to module-level list
        # for backwards compatibility with direct _execute_tool callers.
        _todos: List[Dict[str, Any]] = todos if todos is not None else _agent_todos
        if action == "add" and item:
            _todos.append({"text": item, "done": False})
            return f"Added: {item} ({len(_todos)} total)"
        elif action == "done" and item:
            for t in _todos:
                if item.lower() in t["text"].lower() and not t["done"]:
                    t["done"] = True
                    return f"Completed: {t['text']}"
            return f"Not found: {item}"
        elif action == "clear":
            _todos.clear()
            return "Todo list cleared"
        else:
            if not _todos:
                return "Todo list is empty"
            lines = []
            for i, t in enumerate(_todos, 1):
                mark = "x" if t["done"] else " "
                lines.append(f"  [{mark}] {i}. {t['text']}")
            return "\n".join(lines)

    elif tool_name == "search_replace_all":
        path = args.get("path", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        if _is_protected_file(path):
            return f"Blocked: '{path}' is a protected file and cannot be modified"
        fpath = _safe_path(project_root, path)
        if not fpath:
            return f"Error: path '{path}' is outside project root"
        if not fpath.is_file():
            return f"Error: file not found: {path}"
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
            count = content.count(old_string)
            if count == 0:
                return f"Error: string not found in {path}"
            try:
                from .storage import backup_file
                import hashlib
                session_key = hashlib.md5(project_root.encode()).hexdigest()[:12]
                backup_file(path, content, session_key)
            except Exception:
                pass
            new_content = content.replace(old_string, new_string)
            fpath.write_text(new_content, encoding="utf-8")
            _fire_hook(
                hooks_mgr,
                "on_file_write",
                project_root,
                project=project_root,
                model=model,
                file=str(fpath),
                tool="search_replace_all",
            )
            _mdrive_auto_push(project_root, path, new_content, project_name)
            return f"Replaced {count} occurrence(s) in {path}"
        except Exception as e:
            return f"Error: {e}"

    elif tool_name == "cost_check":
        try:
            from .api import MSaplingClient
            import concurrent.futures

            async def _check():
                client = MSaplingClient()
                try:
                    user = await client.me()
                    fuel = user.get("fuel_credits", 0)
                    tier = user.get("tier", "free")
                    return (
                        f"Tier: {tier}\n"
                        f"Fuel credits remaining: ${fuel:.4f}\n"
                        f"Pro: {user.get('is_pro', False)}"
                    )
                finally:
                    await client.close()

            # _execute_tool is sync but called from within a running event loop.
            # Use a thread to avoid "event loop already running" RuntimeError.
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                result = pool.submit(asyncio.run, _check()).result(timeout=10)
            return result
        except Exception as e:
            return f"Cost check error: {e}"

    elif tool_name == "model_switch":
        new_model = args.get("model", "")
        if not new_model:
            return "Error: provide a model ID (e.g. 'google/gemini-2.0-flash-001')"
        # Store in a module-level var that the shell can read
        global _switched_model
        _switched_model = new_model
        return f"Model switched to: {new_model} (takes effect on next LLM call)"

    return f"Unknown tool: {tool_name}"

# Module-level var for model_switch tool — shell reads this after agent loop
_switched_model: Optional[str] = None

def get_and_clear_switched_model() -> Optional[str]:
    """Return the model set by model_switch tool and clear it."""
    global _switched_model
    m = _switched_model
    _switched_model = None
    return m


async def run_agent_loop(
    client,
    prompt: str,
    model: str,
    project_root: str,
    messages: List[Dict[str, str]],
    on_text: Any = None,
    on_usage: Any = None,
    hooks_mgr: Any = None,
    project_name: str = "",
    chat_id: Optional[str] = None,
    permission_context: Optional[Dict[str, Any]] = None,
) -> str:
    """Run the agentic tool-use loop.

    The LLM receives the user's message plus tool definitions.
    If it responds with tool calls, we execute them and feed results back.
    Loop continues until the LLM responds with just text.

    Args:
        client: MSaplingClient instance
        prompt: User's message
        model: Model ID
        project_root: Path to project root
        messages: Conversation history (mutated in place)
        on_text: Optional callback(text) for streaming display
        on_usage: Optional callback(tokens, cost) for usage accounting
        hooks_mgr: Optional HooksManager for lifecycle hooks

    Returns:
        Final assistant response text
    """
    # Validate chat_id — explicitly empty string is rejected (callers must provide one)
    if chat_id == "":
        raise ValueError("run_agent_loop requires a valid chat_id")

    context = dict(permission_context or {})
    context.setdefault("role", "coordinator")
    context.setdefault("name", "coordinator")
    context.setdefault("chat_id", chat_id or "")
    context.setdefault("project_root", str(Path(project_root).resolve()))
    context.setdefault("correlation_id", uuid.uuid4().hex[:12])
    _permission_context_set(context)

    original_prompt = prompt
    local_access_retry_count = 0
    # Per-loop todo list — scoped to this call so concurrent workers don't share state.
    loop_todos: List[Dict[str, Any]] = []
    # Cumulative token usage across all LLM calls in this agent loop.
    _cumulative_tokens: int = 0

    # Inject agent system prompt if not already present
    has_agent_prompt = any(
        m.get("role") == "system" and "tool" in m.get("content", "").lower()
        for m in messages
    )
    if not has_agent_prompt:
        messages.insert(0, {"role": "system", "content": AGENT_SYSTEM_PROMPT})

    messages.append({"role": "user", "content": prompt})

    steps_taken = 0
    for step in range(MAX_AGENT_STEPS):
        console.print(f"\n[dim]── Step {step+1}/{MAX_AGENT_STEPS} ──[/dim]")
        # ── Token budget gate ────────────────────────────────────
        if _cumulative_tokens >= AGENT_TOKEN_BUDGET:
            budget_msg = (
                f"\n\n---\n[Budget] Agent stopped: cumulative token usage "
                f"({_cumulative_tokens:,}) reached the budget cap "
                f"({AGENT_TOKEN_BUDGET:,} tokens).  "
                "Increase via MSAPLING_AGENT_TOKEN_BUDGET env var or "
                "start a new message to continue."
            )
            logging.getLogger("msapling.agent").warning(
                "Agent token budget exceeded (%d / %d). Halting loop.",
                _cumulative_tokens, AGENT_TOKEN_BUDGET,
            )
            console.print(
                Panel(
                    f"[bold yellow]Token budget exhausted[/bold yellow]  "
                    f"({_cumulative_tokens:,} / {AGENT_TOKEN_BUDGET:,})\n"
                    "The agent loop has been stopped to prevent runaway API costs.\n"
                    "Set MSAPLING_AGENT_TOKEN_BUDGET to a higher value if needed.",
                    title="[yellow]Budget Limit[/yellow]",
                    border_style="yellow",
                )
            )
            _re_arm_sandbox()
            last_text = ""
            for msg in reversed(messages):
                if msg.get("role") == "assistant":
                    last_text = msg.get("content", "")
                    break
            return (last_text + budget_msg) if last_text else budget_msg.lstrip()

        # Get LLM response
        parts = []
        step_tokens = 0
        started_at = time.monotonic()

        def _render_agent_status():
            label = "Receiving" if parts else ("Thinking" if step == 0 else "Reviewing")
            return render_working_panel(label, time.monotonic() - started_at)

        with Live(_render_agent_status(), console=console, refresh_per_second=12, transient=True) as live:
            keep_refreshing = True

            async def _refresh_live():
                while keep_refreshing:
                    live.update(_render_agent_status())
                    await asyncio.sleep(0.1)

            refresher = asyncio.create_task(_refresh_live())
            try:
                async for chunk in _stream_chat_with_lock_retry(
                    client,
                    chat_id=chat_id or str(uuid.uuid4())[:12],
                    prompt=prompt if step == 0 else "",
                    model=model,
                    project_name=project_name,
                    history=messages[-30:],  # Keep recent context
                ):
                    content = chunk.get("content", "")
                    if content:
                        parts.append(content)
                        if on_text:
                            on_text("".join(parts))
                    if chunk.get("type") == "usage":
                        usage = chunk.get("usage", {})
                        step_tokens = usage.get("total_tokens", 0)
                        _cumulative_tokens += step_tokens
                        if on_usage:
                            on_usage(step_tokens, float(chunk.get("cost", 0)))
            finally:
                keep_refreshing = False
                refresher.cancel()
                try:
                    await refresher
                except asyncio.CancelledError:
                    pass

        steps_taken = step + 1
        if step_tokens:
            console.print(f"[dim]  Tokens this step: {step_tokens:,} | Session total: {_cumulative_tokens:,}[/dim]")

        response_text = "".join(parts)
        if not response_text:
            _re_arm_sandbox()
            break

        # Extract tool calls
        clean_text, tool_calls = _extract_tool_calls(response_text)

        if not tool_calls:
            if (
                _looks_like_local_filesystem_request(original_prompt)
                and _looks_like_local_access_refusal(response_text)
                and local_access_retry_count < 2
            ):
                local_access_retry_count += 1
                messages.append({"role": "assistant", "content": response_text})
                if local_access_retry_count == 1:
                    corrective = (
                        "You do have access to local files and directories through CLI tools in this session. "
                        "Do not claim you cannot access them. Use list_directory, read_file, glob_files, or "
                        "grep_search against the user's requested path and continue."
                    )
                else:
                    corrective = (
                        "Your next response must use one or more tool calls. Do not answer conversationally. "
                        "Use list_directory, read_file, glob_files, or grep_search for the requested local path now."
                    )
                messages.append({"role": "user", "content": corrective})
                prompt = ""
                continue

            # No tools ? final response
            messages.append({"role": "assistant", "content": response_text})
            _re_arm_sandbox()
            console.print(f"\n[green]✓ Agent complete[/green] [dim]({steps_taken} steps, {_cumulative_tokens:,} tokens)[/dim]")
            return clean_text or response_text

        # Execute tools
        messages.append({"role": "assistant", "content": response_text})
        tool_results = []

        for tc in tool_calls:
            tool_name = tc.get("tool", "")
            tool_args = tc.get("args", {})

            # Live tool announcement
            console.print(f"[bold cyan]► Tool:[/bold cyan] [white]{tool_name}[/white] [dim]{json.dumps(tool_args, ensure_ascii=False)[:120]}[/dim]")

            # Show tool execution header (styled)
            console.print(tool_header(tool_name, tool_args))

            # Hook parity: explicit generic tool-use event plus before/after lifecycle.
            _fire_hook(
                hooks_mgr,
                "on_tool_use",
                project_root,
                project=project_root,
                model=model,
                tool=tool_name,
                args=tool_args,
            )
            _fire_hook(
                hooks_mgr,
                "on_before_tool",
                project_root,
                project=project_root,
                model=model,
                tool=tool_name,
                args=tool_args,
            )

            # IO-heavy tools (web_search, web_fetch) make blocking httpx calls.
            # Run _execute_tool in a thread pool so the async event loop stays
            # responsive for UI refresh, lock retries, and streaming.
            import functools as _functools
            _tool_call = _functools.partial(
                _execute_tool, tool_name, tool_args, project_root,
                hooks_mgr=hooks_mgr, model=model,
                project_name=project_name,
                todos=loop_todos,
            )
            with Status(f"Running {tool_name}...", console=console):
                result = await asyncio.to_thread(_tool_call)

            _fire_hook(
                hooks_mgr,
                "on_after_tool",
                project_root,
                project=project_root,
                model=model,
                tool=tool_name,
                args=tool_args,
            )

            exit_code = _parse_command_exit_code(result)
            if _tool_result_failed(tool_name, result):
                _fire_hook(
                    hooks_mgr,
                    "on_tool_failure",
                    project_root,
                    project=project_root,
                    model=model,
                    tool=tool_name,
                    args=tool_args,
                    result=str(result)[:1000],
                    exit_code=exit_code,
                )
            if tool_name == "run_command" and (
                (exit_code is not None and exit_code != 0)
                or str(result or "").strip().lower().startswith("error:")
            ):
                _fire_hook(
                    hooks_mgr,
                    "on_compile_error",
                    project_root,
                    project=project_root,
                    model=model,
                    tool=tool_name,
                    command=str(tool_args.get("command") or ""),
                    result=str(result)[:1000],
                    exit_code=exit_code,
                )

            # Show styled result
            console.print(tool_result_display(tool_name, result, tool_args))

            # Result preview (first 200 chars)
            result_preview = str(result)[:200].replace("\n", " ")
            console.print(f"[dim]  ↳ {result_preview}{'...' if len(str(result)) > 200 else ''}[/dim]")

            tool_results.append(f"[Tool: {tool_name}]\n{result}")

        # Feed results back to LLM
        tool_feedback = "\n\n".join(tool_results)
        messages.append({"role": "user", "content": f"[Tool results]\n{tool_feedback}"})
        prompt = ""  # Empty prompt for continuation

    # ── Step-limit truncation: warn the user visibly ──────────────
    logging.getLogger("msapling.agent").warning(
        "Agent hit MAX_AGENT_STEPS (%d). Task may be incomplete.",
        MAX_AGENT_STEPS,
    )
    console.print(
        Panel(
            f"[bold yellow]Agent reached the maximum of {MAX_AGENT_STEPS} steps.[/bold yellow]\n"
            "The result above may be incomplete. You can continue by sending a follow-up message.",
            title="[yellow]Step Limit Reached[/yellow]",
            border_style="yellow",
        )
    )
    # Return the last assistant text so partial work is not lost
    last_assistant = ""
    for msg in reversed(messages):
        if msg.get("role") == "assistant":
            last_assistant = msg.get("content", "")
            break
    truncation_notice = (
        f"\n\n---\n⚠ Agent stopped after {MAX_AGENT_STEPS} steps. "
        "The response may be incomplete — send a follow-up to continue."
    )
    _re_arm_sandbox()
    return (last_assistant + truncation_notice) if last_assistant else truncation_notice.lstrip()
