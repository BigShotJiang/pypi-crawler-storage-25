"""AgentShield: Client-side hard gate for MSapling CLI tool execution.

AgentShield sits between the CLI and the backend's tool responses,
blocking or requiring confirmation for destructive operations locally
before they are executed — regardless of what the backend permits.

This is analogous to gemini-cli/packages/core/src/sandbox and ensures
that even if the backend authorises a tool call, the client applies its
own safety layer.

Secret-scanning helpers (scan_file, scan_directory, get_grade) are
preserved from the legacy module for backward-compatibility.
"""
from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import List, Optional, Tuple

_log = logging.getLogger(__name__)

# ─── Config plumbing ─────────────────────────────────────────────────────────

_CONFIG_DIR = Path.home() / ".msapling"
_CONFIG_FILE = _CONFIG_DIR / "config.json"

_CONFIG_KEY = "agentshield_enabled"


def _load_raw_config() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def _save_raw_config(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ─── ShieldResult ─────────────────────────────────────────────────────────────


class ShieldResult:
    """Result of an AgentShield evaluation."""

    __slots__ = ("verdict", "reason", "blocked_pattern", "tool_name", "command")

    def __init__(
        self,
        verdict: str,
        reason: str,
        blocked_pattern: Optional[str] = None,
        tool_name: str = "",
        command: str = "",
    ) -> None:
        #: "allow" | "block" | "confirm"
        self.verdict = verdict
        self.reason = reason
        self.blocked_pattern = blocked_pattern
        self.tool_name = tool_name
        self.command = command

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"ShieldResult(verdict={self.verdict!r}, reason={self.reason!r}, "
            f"blocked_pattern={self.blocked_pattern!r})"
        )


# ─── AgentShield ──────────────────────────────────────────────────────────────


class AgentShield:
    """Client-side hard gate for tool execution safety.

    Two tiers of protection:
    - BLOCKED_ALWAYS   — never permitted; returns verdict="block"
    - REQUIRES_CONFIRMATION — returns verdict="confirm"; the caller must
      obtain explicit user consent before proceeding

    When the shield is disabled via config (agentshield_enabled=false) or
    the MSAPLING_SHIELD_DISABLED env var, all calls return verdict="allow".
    """

    # Patterns that are NEVER allowed regardless of user settings.
    # Evaluated against the raw command string (case-insensitive).
    BLOCKED_ALWAYS: List[Tuple[str, str]] = [
        (
            r"rm\s+-[a-z]*r[a-z]*f[a-z]*\s+/(?![\w])",
            "rm -rf / and variants that target the filesystem root are permanently blocked",
        ),
        (
            r"format\s+[A-Za-z]:",
            "Disk format operations (format C:) are permanently blocked",
        ),
        (
            r"\bDROP\s+DATABASE\b",
            "SQL DROP DATABASE is permanently blocked",
        ),
        (
            r"\bdd\s+.*\bif=.*\bof=/dev/",
            "Raw disk overwrite (dd if=... of=/dev/...) is permanently blocked",
        ),
    ]

    # Patterns that require explicit user confirmation before execution.
    REQUIRES_CONFIRMATION: List[Tuple[str, str]] = [
        (
            r"rm\s+-[a-z]*r[a-z]*f",
            "Recursive forced delete (rm -rf) requires confirmation",
        ),
        (
            r"\bDROP\s+TABLE\b",
            "SQL DROP TABLE requires confirmation",
        ),
        (
            r"\bgit\s+(reset|clean)\b.*(-f\b|--hard\b|--force\b)",
            "Force git reset/clean (--hard/--force/-f) requires confirmation",
        ),
        (
            r">(>?)\s*/dev/null",
            "Output suppression to /dev/null requires confirmation (potential cover for destructive ops)",
        ),
    ]

    def __init__(self) -> None:
        # Compile all patterns once at construction time for efficiency.
        self._blocked_compiled = [
            (re.compile(pat, re.IGNORECASE), reason)
            for pat, reason in self.BLOCKED_ALWAYS
        ]
        self._confirm_compiled = [
            (re.compile(pat, re.IGNORECASE), reason)
            for pat, reason in self.REQUIRES_CONFIRMATION
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_enabled(self) -> bool:
        """Return True if AgentShield is active (default: True).

        Resolution order (highest wins):
          1. MSAPLING_SHIELD_DISABLED env var  — "1"/"true"/"yes" → disabled
          2. config key ``agentshield_enabled`` in ~/.msapling/config.json
          3. Default: enabled
        """
        env_override = os.getenv("MSAPLING_SHIELD_DISABLED", "").strip().lower()
        if env_override in ("1", "true", "yes", "on"):
            return False

        raw = _load_raw_config()
        if _CONFIG_KEY in raw:
            val = raw[_CONFIG_KEY]
            # Accept bool or string representations
            if isinstance(val, bool):
                return val
            if isinstance(val, str):
                return val.strip().lower() not in ("0", "false", "no", "off")
        # Default: enabled
        return True

    def set_enabled(self, enabled: bool) -> None:
        """Persist the enabled state to ~/.msapling/config.json."""
        raw = _load_raw_config()
        raw[_CONFIG_KEY] = enabled
        _save_raw_config(raw)
        _log.info("AgentShield %s", "enabled" if enabled else "disabled")

    def check(self, tool_name: str, command: str) -> ShieldResult:
        """Evaluate a tool call and return a ShieldResult.

        Args:
            tool_name: Name of the tool being invoked (e.g. "run_command").
            command:   The command string or argument to evaluate.

        Returns:
            ShieldResult with verdict "allow", "block", or "confirm".
        """
        if not self.is_enabled():
            return ShieldResult(
                verdict="allow",
                reason="AgentShield is disabled",
                tool_name=tool_name,
                command=command,
            )

        # 1. Hard-block tier — checked first, highest priority
        for compiled_pat, reason in self._blocked_compiled:
            if compiled_pat.search(command):
                _log.warning(
                    "[AgentShield] BLOCKED tool=%r command=%r pattern=%r",
                    tool_name, command[:120], compiled_pat.pattern,
                )
                return ShieldResult(
                    verdict="block",
                    reason=reason,
                    blocked_pattern=compiled_pat.pattern,
                    tool_name=tool_name,
                    command=command,
                )

        # 2. Confirmation tier — lower priority
        for compiled_pat, reason in self._confirm_compiled:
            if compiled_pat.search(command):
                _log.info(
                    "[AgentShield] CONFIRM tool=%r command=%r pattern=%r",
                    tool_name, command[:120], compiled_pat.pattern,
                )
                return ShieldResult(
                    verdict="confirm",
                    reason=reason,
                    blocked_pattern=compiled_pat.pattern,
                    tool_name=tool_name,
                    command=command,
                )

        # 3. Clean pass
        return ShieldResult(
            verdict="allow",
            reason="Passed all AgentShield checks",
            tool_name=tool_name,
            command=command,
        )

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def blocked_always_count(self) -> int:
        return len(self.BLOCKED_ALWAYS)

    @property
    def requires_confirmation_count(self) -> int:
        return len(self.REQUIRES_CONFIRMATION)


# ─── Legacy secret-scanning helpers (preserved for backward-compat) ──────────

_SECRET_PATTERNS = [
    (re.compile(r'sk-[a-zA-Z0-9]{20,}'), "Hardcoded API key"),
    (re.compile(r'sk-ant-[a-zA-Z0-9]{20,}'), "Hardcoded Anthropic key"),
    (re.compile(r'AKIA[A-Z0-9]{16}'), "Hardcoded AWS access key"),
    (re.compile(r'password\s*[=:]\s*["\']?[^\s"\']{8,}', re.I), "Possible hardcoded password"),
]

_SCAN_TARGETS = [
    ".msapling.md",
    "CLAUDE.md",
    ".env.example",
    ".env",
]


def scan_file(path: Path) -> List[Tuple[int, str, str]]:
    """Returns list of (line_num, issue_type, snippet)."""
    findings: List[Tuple[int, str, str]] = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return findings
    for lineno, line in enumerate(text.splitlines(), start=1):
        for pattern, label in _SECRET_PATTERNS:
            m = pattern.search(line)
            if m:
                snippet = line.strip()[:120]
                start, end = m.span()
                redacted = line[:start] + ("*" * min(len(m.group()), 8)) + line[end:]
                snippet = redacted.strip()[:120]
                findings.append((lineno, label, snippet))
    return findings


def scan_directory(root: Path) -> dict:
    """Scan .msapling/, CLAUDE.md, .env.example for issues. Returns grade + findings."""
    all_findings: List[dict] = []

    for name in _SCAN_TARGETS:
        target = root / name
        if target.is_file():
            file_findings = scan_file(target)
            for lineno, issue_type, snippet in file_findings:
                all_findings.append({
                    "file": str(target.relative_to(root)),
                    "line": lineno,
                    "issue": issue_type,
                    "snippet": snippet,
                })

    msapling_dir = root / ".msapling"
    if msapling_dir.is_dir():
        for fpath in sorted(msapling_dir.rglob("*")):
            if fpath.is_file() and fpath.suffix in (".md", ".json", ".yaml", ".yml", ".txt", ".sh", ""):
                file_findings = scan_file(fpath)
                for lineno, issue_type, snippet in file_findings:
                    all_findings.append({
                        "file": str(fpath.relative_to(root)),
                        "line": lineno,
                        "issue": issue_type,
                        "snippet": snippet,
                    })

    issue_count = len(all_findings)
    grade = get_grade(issue_count)

    return {
        "grade": grade,
        "issue_count": issue_count,
        "findings": all_findings,
        "scanned_root": str(root),
    }


def get_grade(issue_count: int) -> str:
    """Grade A (0-1 issues) → F (9+)."""
    if issue_count <= 1:
        return 'A'
    elif issue_count <= 3:
        return 'B'
    elif issue_count <= 5:
        return 'C'
    elif issue_count <= 8:
        return 'D'
    else:
        return 'F'
