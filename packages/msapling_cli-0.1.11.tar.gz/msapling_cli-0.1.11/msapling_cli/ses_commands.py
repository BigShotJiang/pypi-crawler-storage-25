"""SES (MSapling SES score) commands for the CLI.

Provides `msapling ses` sub-commands for querying and displaying
SES (Subjective Evaluation Score) data for models, and running SES benchmarks.
"""
from __future__ import annotations

import asyncio
import json as _json
from typing import Optional

import typer

from msapling_cli.api import MSaplingClient, _retry_request

ses_app = typer.Typer(name="ses", help="SES model benchmark commands and score queries.")


@ses_app.command("score")
def ses_score(
    model: str = typer.Argument(..., help="Model ID (e.g. google/gemini-2.0-flash-001)"),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
):
    """Show the SES score for a specific model."""
    from msapling_cli.tui import console, working_spinner

    async def _fetch():
        client = MSaplingClient()
        try:
            async with working_spinner("Fetching SES score"):
                resp = await client.get(f"/api/ses/score?model_id={model}")
            if output == "json":
                console.print(_json.dumps(resp))
                return
            score = resp.get("ses_score") or resp.get("score")
            tier = resp.get("tier") or resp.get("quality_tier")
            if score is None:
                console.print(f"[yellow]No SES score found for {model}[/yellow]")
                return
            color = "green" if float(score) >= 0.8 else "yellow" if float(score) >= 0.5 else "red"
            console.print(f"Model:  [cyan]{model}[/cyan]")
            console.print(f"SES:    [{color}]{score}[/{color}]")
            if tier:
                console.print(f"Tier:   {tier}")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())


@ses_app.command("top")
def ses_top(
    limit: int = typer.Option(10, "--limit", "-n", help="Number of top models to show"),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help="Filter by provider prefix"),
):
    """List top-scoring models by SES score."""
    from msapling_cli.tui import console, working_spinner
    from rich.table import Table

    async def _fetch():
        client = MSaplingClient()
        try:
            async with working_spinner("Loading SES rankings"):
                resp = await client.get(f"/api/ses/rankings?limit={limit}")
            models = resp if isinstance(resp, list) else resp.get("models", resp.get("data", []))
            if provider:
                models = [m for m in models if str(m.get("model_id", "")).startswith(provider)]
            if output == "json":
                console.print(_json.dumps(models))
                return
            if not models:
                console.print("[yellow]No SES data available.[/yellow]")
                return
            table = Table(title=f"Top {len(models)} Models by SES Score")
            table.add_column("Rank", justify="right", style="dim")
            table.add_column("Model", style="cyan")
            table.add_column("SES", justify="right")
            table.add_column("Tier")
            for i, m in enumerate(models, 1):
                mid = m.get("model_id") or m.get("id") or "?"
                score = m.get("ses_score") or m.get("score") or "?"
                tier = m.get("tier") or m.get("quality_tier") or "?"
                try:
                    score_f = float(score)
                    color = "green" if score_f >= 0.8 else "yellow" if score_f >= 0.5 else "red"
                    score_str = f"[{color}]{score_f:.3f}[/{color}]"
                except (TypeError, ValueError):
                    score_str = str(score)
                table.add_row(str(i), mid, score_str, str(tier))
            console.print(table)
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())


@ses_app.command("compare")
def ses_compare(
    models: list[str] = typer.Argument(..., help="Two or more model IDs to compare"),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
):
    """Compare SES scores for two or more models side by side."""
    from msapling_cli.tui import console, working_spinner
    from rich.table import Table

    if len(models) < 2:
        console.print("[red]Provide at least two model IDs to compare.[/red]")
        raise typer.Exit(1)

    async def _fetch():
        client = MSaplingClient()
        try:
            results = []
            async with working_spinner("Fetching SES scores"):
                for model_id in models:
                    try:
                        resp = await client.get(f"/api/ses/score?model_id={model_id}")
                        results.append((model_id, resp))
                    except Exception:
                        results.append((model_id, {}))
            if output == "json":
                console.print(_json.dumps([{"model": m, "data": d} for m, d in results]))
                return
            table = Table(title="SES Comparison")
            table.add_column("Model", style="cyan")
            table.add_column("SES", justify="right")
            table.add_column("Tier")
            for model_id, data in results:
                score = data.get("ses_score") or data.get("score") or "N/A"
                tier = data.get("tier") or data.get("quality_tier") or "?"
                try:
                    score_f = float(score)
                    color = "green" if score_f >= 0.8 else "yellow" if score_f >= 0.5 else "red"
                    score_str = f"[{color}]{score_f:.3f}[/{color}]"
                except (TypeError, ValueError):
                    score_str = str(score)
                table.add_row(model_id, score_str, str(tier))
            console.print(table)
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())


# ---------------------------------------------------------------------------
# SES Benchmark commands (POST /api/benchmark/ses/run etc.)
# ---------------------------------------------------------------------------

@ses_app.command("run")
def ses_run(
    model: str = typer.Argument(..., help="Model ID, e.g. openai/gpt-4o, local/model.gguf"),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="SES_API_KEY"),
    subject: str = typer.Option("all", "--subject", help="Subject filter: all/math/code/reasoning"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save results to JSON file"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show config without running"),
):
    """Run SES benchmark on a model. Calls POST /api/benchmark/ses/run."""
    from msapling_cli.tui import console

    config = {"model": model, "subject": subject, "api_key": "***" if api_key else None}

    if dry_run:
        console.print("[bold]Dry-run mode — no API call will be made.[/bold]")
        console.print(_json.dumps(config, indent=2))
        return

    async def _run():
        client = MSaplingClient()
        try:
            payload: dict = {"model_id": model, "subject_filter": subject}
            if api_key:
                payload["api_key_override"] = api_key

            console.print(f"[cyan]Submitting SES benchmark for [bold]{model}[/bold]...[/cyan]")
            http_client = await client._get_client()
            resp = await _retry_request(
                lambda: http_client.post("/api/benchmark/ses/run", json=payload)
            )
            if resp.status_code == 402:
                console.print("[red]Insufficient fuel credits. Visit msapling.com to add fuel.[/red]")
                raise typer.Exit(1)
            if resp.status_code == 401:
                console.print("[red]Authentication required. Run `msapling login`.[/red]")
                raise typer.Exit(1)
            resp.raise_for_status()
            data = resp.json()

            run_id = data.get("run_id", "")
            est_minutes = data.get("estimated_minutes", "?")
            console.print(f"[green]Queued.[/green] run_id=[bold]{run_id}[/bold]  estimated={est_minutes}m")
            console.print("Polling for completion (Ctrl-C to stop)...")

            # Poll for status
            final_data = data
            for _attempt in range(60):
                await asyncio.sleep(5)
                try:
                    poll_resp = await _retry_request(
                        lambda rid=run_id: http_client.get(f"/api/benchmark/ses/status/{rid}")
                    )
                    if poll_resp.status_code == 200:
                        poll_data = poll_resp.json()
                        status = poll_data.get("status", "")
                        pct = poll_data.get("progress_pct", 0)
                        console.print(f"  [{pct}%] {status}")
                        if status in ("completed", "failed", "error"):
                            final_data = poll_data
                            break
                except Exception:
                    pass

            if output:
                import pathlib
                pathlib.Path(output).write_text(_json.dumps(final_data, indent=2), encoding="utf-8")
                console.print(f"[dim]Results saved to {output}[/dim]")
            else:
                console.print(_json.dumps(final_data, indent=2))

        except typer.Exit:
            raise
        except Exception as e:
            if "402" in str(e):
                console.print("[red]Insufficient fuel credits.[/red]")
            elif "401" in str(e):
                console.print("[red]Authentication required. Run `msapling login`.[/red]")
            else:
                console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_run())


@ses_app.command("results")
def ses_results(
    model: Optional[str] = typer.Option(None, "--model", help="Filter by model"),
    last: int = typer.Option(10, "--last", help="Show last N results"),
):
    """Show SES benchmark results. Calls GET /api/benchmark/ses/results."""
    from msapling_cli.tui import console
    from rich.table import Table

    async def _fetch():
        client = MSaplingClient()
        try:
            params: dict = {"limit": last}
            if model:
                params["model_id"] = model
            http_client = await client._get_client()
            resp = await _retry_request(
                lambda: http_client.get("/api/benchmark/ses/results", params=params)
            )
            if resp.status_code == 401:
                console.print("[red]Authentication required. Run `msapling login`.[/red]")
                raise typer.Exit(1)
            resp.raise_for_status()
            rows = resp.json()
            if not rows:
                console.print("[yellow]No SES results found.[/yellow]")
                return
            table = Table(title=f"SES Results (last {last})")
            table.add_column("Run ID", style="dim", max_width=12)
            table.add_column("Model", style="cyan")
            table.add_column("Subject")
            table.add_column("Score", justify="right")
            table.add_column("Latency p50", justify="right")
            table.add_column("Cost USD", justify="right")
            table.add_column("Completed At")
            for row in rows:
                table.add_row(
                    str(row.get("run_id", ""))[:12],
                    str(row.get("model_id", "")),
                    str(row.get("subject", "")),
                    f"{row.get('score', ''):.3f}" if row.get("score") is not None else "-",
                    f"{row.get('latency_p50_ms', '')}ms" if row.get("latency_p50_ms") is not None else "-",
                    f"${row.get('cost_usd', 0):.4f}" if row.get("cost_usd") is not None else "-",
                    str(row.get("completed_at", "") or "-")[:19],
                )
            console.print(table)
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())


@ses_app.command("leaderboard")
def ses_leaderboard(
    subject: str = typer.Option("overall", "--subject"),
    top: int = typer.Option(20, "--top"),
):
    """Show SES leaderboard. Calls GET /api/benchmark/ses/leaderboard."""
    from msapling_cli.tui import console
    from rich.table import Table

    async def _fetch():
        client = MSaplingClient()
        try:
            http_client = await client._get_client()
            resp = await _retry_request(
                lambda: http_client.get(
                    "/api/benchmark/ses/leaderboard",
                    params={"subject": subject, "top": top},
                )
            )
            resp.raise_for_status()
            data = resp.json()
            rows = data if isinstance(data, list) else data.get("leaderboard", data.get("results", []))
            if not rows:
                console.print("[yellow]Leaderboard is empty.[/yellow]")
                return
            table = Table(title=f"SES Leaderboard — {subject}")
            table.add_column("Rank", justify="right", style="dim")
            table.add_column("Model", style="cyan")
            table.add_column("Avg Score", justify="right")
            table.add_column("Runs", justify="right")
            for i, row in enumerate(rows[:top], 1):
                score = row.get("avg_score") or row.get("score") or row.get("ses_score")
                score_str = f"{float(score):.3f}" if score is not None else "-"
                table.add_row(
                    str(i),
                    str(row.get("model_id") or row.get("model", "")),
                    score_str,
                    str(row.get("run_count") or row.get("runs") or ""),
                )
            console.print(table)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())


@ses_app.command("status")
def ses_status(run_id: str = typer.Argument(..., help="SES benchmark run ID")):
    """Check status of a running SES benchmark job."""
    from msapling_cli.tui import console

    async def _fetch():
        client = MSaplingClient()
        try:
            http_client = await client._get_client()
            resp = await _retry_request(
                lambda: http_client.get(f"/api/benchmark/ses/status/{run_id}")
            )
            if resp.status_code == 404:
                console.print(f"[red]Run ID not found: {run_id}[/red]")
                raise typer.Exit(1)
            if resp.status_code == 401:
                console.print("[red]Authentication required. Run `msapling login`.[/red]")
                raise typer.Exit(1)
            resp.raise_for_status()
            data = resp.json()
            status = data.get("status", "unknown")
            pct = data.get("progress_pct", 0)
            color = "green" if status == "completed" else "yellow" if status in ("queued", "running") else "red"
            console.print(f"Run ID:   [bold]{run_id}[/bold]")
            console.print(f"Status:   [{color}]{status}[/{color}]  ({pct}%)")
            console.print(f"Model:    {data.get('model_id', '-')}")
            console.print(f"Started:  {data.get('started_at', '-')}")
            if data.get("error"):
                console.print(f"[red]Error: {data['error']}[/red]")
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    asyncio.run(_fetch())
