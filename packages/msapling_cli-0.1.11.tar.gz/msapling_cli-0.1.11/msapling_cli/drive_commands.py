"""MDrive CLI commands — push, pull, sync, ls, share, status.

Usage:
    msapling drive push [PATH] [--project NAME] [--dry-run]
    msapling drive pull PROJECT [--dest PATH] [--dry-run]
    msapling drive sync [PATH] [--project NAME]
    msapling drive ls [PROJECT] [--long]
    msapling drive share PROJECT [--file PATH] [--expires DAYS]
    msapling drive status
"""
from __future__ import annotations

import asyncio
import fnmatch
import hashlib
import os
import time
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)
from rich.table import Table
from rich.text import Text

from .api import APIError, MSaplingClient, OfflineError
from .config import get_settings, get_token
from .tui import console

drive_app = typer.Typer(name="drive", help="MDrive cloud file sync — push, pull, sync, share.")

# ─── constants ────────────────────────────────────────────────────────────────

_DEFAULT_IGNORE_PATTERNS: List[str] = [
    "node_modules",
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    "*.pyc",
    "*.pyo",
    ".DS_Store",
    "Thumbs.db",
    ".env",
    ".venv",
    "venv",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "coverage",
    ".coverage",
    "*.egg-info",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
]

_MDRIVEIGNORE_FILENAME = ".mdriveignore"

# ─── helpers ──────────────────────────────────────────────────────────────────


def _run(coro):
    """Run an async coroutine from a sync context."""
    return asyncio.run(coro)


def _load_ignore_patterns(root: Path) -> List[str]:
    """Load patterns from .mdriveignore (gitignore-style) and merge with defaults."""
    patterns = list(_DEFAULT_IGNORE_PATTERNS)
    ignore_file = root / _MDRIVEIGNORE_FILENAME
    if ignore_file.is_file():
        for line in ignore_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    return patterns


def _is_ignored(path: Path, root: Path, patterns: List[str]) -> bool:
    """Return True if path should be excluded based on ignore patterns."""
    try:
        rel = path.relative_to(root)
    except ValueError:
        return False
    parts = rel.parts
    for pattern in patterns:
        # Match any path component or the full relative path
        for part in parts:
            if fnmatch.fnmatch(part, pattern):
                return True
        if fnmatch.fnmatch(str(rel), pattern):
            return True
    return False


def _collect_local_files(root: Path, patterns: List[str]) -> List[Path]:
    """Walk root recursively, skipping ignored paths. Returns list of file Paths."""
    files: List[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirpath_p = Path(dirpath)
        # Prune ignored directories in-place
        dirnames[:] = [
            d for d in dirnames
            if not _is_ignored(dirpath_p / d, root, patterns)
        ]
        for fname in filenames:
            fpath = dirpath_p / fname
            if not _is_ignored(fpath, root, patterns):
                files.append(fpath)
    return files


def _sha256_file(path: Path) -> str:
    """Compute SHA256 hex digest of a local file."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha256_content(content: str) -> str:
    """Compute SHA256 hex digest of string content."""
    return hashlib.sha256(content.encode("utf-8", errors="replace")).digest().hex()


def _fmt_size(size_bytes: int) -> str:
    """Human-readable file size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / 1024 ** 2:.1f} MB"
    return f"{size_bytes / 1024 ** 3:.2f} GB"


def _require_auth() -> str:
    """Return current token or abort with a helpful message."""
    token = get_token()
    if not token:
        console.print("[bold red]Not authenticated.[/bold red] Run [bold]msapling login[/bold] first.")
        raise typer.Exit(1)
    return token


async def _drive_push_files(
    client: MSaplingClient,
    project: str,
    files: List[dict],
) -> dict:
    """Upload a batch of files to MDrive. Returns summary dict."""
    return await client.drive_push(project, files)


async def _drive_pull_files(client: MSaplingClient, project: str) -> List[dict]:
    """Fetch remote file list with content for a project."""
    return await client.drive_pull(project)


# ─── drive push ───────────────────────────────────────────────────────────────


@drive_app.command("push")
def drive_push(
    path: Optional[Path] = typer.Argument(None, help="Local directory or file to push (default: cwd)"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="MDrive project name"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be uploaded without uploading"),
):
    """Upload local files to MDrive. Respects .mdriveignore."""
    _require_auth()
    root = (path or Path.cwd()).resolve()
    if not root.exists():
        console.print(f"[red]Path does not exist: {root}[/red]")
        raise typer.Exit(1)

    proj_name = project or root.name
    ignore_patterns = _load_ignore_patterns(root if root.is_dir() else root.parent)

    if root.is_file():
        local_files = [root]
        root_dir = root.parent
    else:
        root_dir = root
        console.print(f"[ms.dim]Scanning [ms.file]{root}[/ms.file]...[/ms.dim]")
        local_files = _collect_local_files(root, ignore_patterns)

    if not local_files:
        console.print("[ms.warn]No files found to push.[/ms.warn]")
        raise typer.Exit(0)

    if dry_run:
        console.print(f"[ms.accent]Dry run — {len(local_files)} file(s) would be uploaded to project '{proj_name}':[/ms.accent]")
        for f in local_files:
            rel = f.relative_to(root_dir)
            size = f.stat().st_size
            console.print(f"  [ms.file]{rel}[/ms.file]  [ms.dim]{_fmt_size(size)}[/ms.dim]")
        raise typer.Exit(0)

    # Build payload list
    files_payload: List[dict] = []
    read_errors = 0
    for f in local_files:
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
            rel_path = str(f.relative_to(root_dir)).replace("\\", "/")
            files_payload.append({
                "path": rel_path,
                "content": content,
                "size": f.stat().st_size,
                "sha256": _sha256_file(f),
            })
        except Exception as exc:
            console.print(f"[ms.warn]  Skipping {f.name}: {exc}[/ms.warn]")
            read_errors += 1

    if not files_payload:
        console.print("[red]No readable files to upload.[/red]")
        raise typer.Exit(1)

    async def _do_push():
        async with MSaplingClient() as client:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                TimeElapsedColumn(),
                console=console,
                transient=True,
            ) as progress:
                task_id = progress.add_task(
                    f"[ms.accent]Uploading to '{proj_name}'[/ms.accent]",
                    total=len(files_payload),
                )
                # Chunk in batches of 50 to avoid huge single requests
                uploaded = 0
                errors = 0
                skipped = 0
                batch_size = 50
                for i in range(0, len(files_payload), batch_size):
                    batch = files_payload[i : i + batch_size]
                    try:
                        result = await client.drive_push(proj_name, batch)
                        uploaded += int(result.get("uploaded", len(batch)))
                        skipped += int(result.get("skipped", 0))
                        errors += int(result.get("errors", 0))
                    except (APIError, OfflineError) as exc:
                        console.print(f"\n[red]Upload failed: {exc}[/red]")
                        raise typer.Exit(1)
                    progress.advance(task_id, len(batch))
            return uploaded, skipped, errors

    uploaded, skipped, errors = _run(_do_push())
    console.print(
        f"[ms.accent2]Push complete.[/ms.accent2] "
        f"[bold]{uploaded}[/bold] uploaded, "
        f"[ms.dim]{skipped}[/ms.dim] skipped, "
        f"[ms.error]{errors + read_errors}[/ms.error] errors."
    )


# ─── drive pull ───────────────────────────────────────────────────────────────


@drive_app.command("pull")
def drive_pull(
    project: str = typer.Argument(..., help="MDrive project name to download"),
    dest: Optional[Path] = typer.Option(None, "--dest", "-d", help="Local destination directory (default: ./<project>)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be downloaded without writing files"),
):
    """Download all files from a remote MDrive project to a local directory."""
    _require_auth()
    dest_dir = (dest or Path.cwd() / project).resolve()

    async def _do_pull():
        async with MSaplingClient() as client:
            try:
                remote_files = await client.drive_pull(project)
            except APIError as exc:
                if exc.status_code == 401:
                    console.print("[red]Not authenticated. Run `msapling login`.[/red]")
                elif exc.status_code == 404:
                    console.print(f"[red]Project '{project}' not found.[/red]")
                else:
                    console.print(f"[red]Pull failed: {exc}[/red]")
                raise typer.Exit(1)
            except OfflineError as exc:
                console.print(f"[red]Cannot connect to API: {exc}[/red]")
                raise typer.Exit(1)
            return remote_files

    remote_files = _run(_do_pull())

    if not remote_files:
        console.print(f"[ms.warn]No files found in project '{project}'.[/ms.warn]")
        raise typer.Exit(0)

    if dry_run:
        console.print(f"[ms.accent]Dry run — {len(remote_files)} file(s) would be downloaded to '{dest_dir}':[/ms.accent]")
        for f in remote_files:
            fpath = f.get("path", f.get("name", "?"))
            size = f.get("size", 0)
            console.print(f"  [ms.file]{fpath}[/ms.file]  [ms.dim]{_fmt_size(int(size or 0))}[/ms.dim]")
        raise typer.Exit(0)

    dest_dir.mkdir(parents=True, exist_ok=True)
    written = 0
    errors = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task_id = progress.add_task(
            f"[ms.accent]Downloading '{project}'[/ms.accent]",
            total=len(remote_files),
        )
        for f in remote_files:
            fpath = f.get("path", f.get("name", ""))
            content = f.get("content", "")
            if not fpath:
                progress.advance(task_id)
                errors += 1
                continue
            local_path = dest_dir / fpath.lstrip("/")
            try:
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text(content, encoding="utf-8")
                written += 1
            except Exception as exc:
                console.print(f"\n[ms.warn]  Failed to write {fpath}: {exc}[/ms.warn]")
                errors += 1
            progress.advance(task_id)

    console.print(
        f"[ms.accent2]Pull complete.[/ms.accent2] "
        f"[bold]{written}[/bold] files written to [ms.file]{dest_dir}[/ms.file], "
        f"[ms.error]{errors}[/ms.error] errors."
    )


# ─── drive sync ───────────────────────────────────────────────────────────────


@drive_app.command("sync")
def drive_sync(
    path: Optional[Path] = typer.Argument(None, help="Local directory to sync (default: cwd)"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="MDrive project name"),
):
    """Bidirectional sync using SHA256 hash comparison. Shows diff: local_only, remote_only, conflict, same."""
    _require_auth()
    root = (path or Path.cwd()).resolve()
    if not root.exists():
        console.print(f"[red]Path does not exist: {root}[/red]")
        raise typer.Exit(1)
    if not root.is_dir():
        console.print(f"[red]Sync requires a directory, got: {root}[/red]")
        raise typer.Exit(1)

    proj_name = project or root.name
    ignore_patterns = _load_ignore_patterns(root)
    local_files = _collect_local_files(root, ignore_patterns)

    # Build local index: rel_path -> sha256
    local_index: dict = {}
    for f in local_files:
        rel = str(f.relative_to(root)).replace("\\", "/")
        local_index[rel] = _sha256_file(f)

    async def _fetch_remote():
        async with MSaplingClient() as client:
            try:
                return await client.drive_ls(proj_name)
            except APIError as exc:
                if exc.status_code in (401, 403):
                    console.print("[red]Not authenticated. Run `msapling login`.[/red]")
                elif exc.status_code == 404:
                    console.print(f"[yellow]Project '{proj_name}' not found on remote — treating all local files as local_only.[/yellow]")
                    return []
                else:
                    console.print(f"[red]Sync failed: {exc}[/red]")
                    raise typer.Exit(1)
            except OfflineError as exc:
                console.print(f"[red]Cannot connect to API: {exc}[/red]")
                raise typer.Exit(1)
            return []

    remote_files = _run(_fetch_remote())

    # Build remote index: rel_path -> {sha256, size, modified}
    remote_index: dict = {}
    for f in remote_files:
        rpath = f.get("path", f.get("name", "")).lstrip("/")
        if rpath:
            remote_index[rpath] = f

    # Classify
    local_only: List[str] = []
    remote_only: List[str] = []
    conflict: List[str] = []
    same: List[str] = []

    all_paths = set(local_index.keys()) | set(remote_index.keys())
    for rp in sorted(all_paths):
        in_local = rp in local_index
        in_remote = rp in remote_index
        if in_local and not in_remote:
            local_only.append(rp)
        elif in_remote and not in_local:
            remote_only.append(rp)
        else:
            remote_hash = remote_index[rp].get("sha256", remote_index[rp].get("hash", ""))
            if remote_hash and remote_hash != local_index[rp]:
                conflict.append(rp)
            else:
                same.append(rp)

    # Render diff table
    table = Table(title=f"Sync status: '{proj_name}'", show_header=True, header_style="bold blue")
    table.add_column("Status", style="bold", width=14)
    table.add_column("File", style="cyan")

    for f in local_only:
        table.add_row("[green]local_only[/green]", f)
    for f in remote_only:
        table.add_row("[yellow]remote_only[/yellow]", f)
    for f in conflict:
        table.add_row("[red]conflict[/red]", f)
    for f in same:
        table.add_row("[dim]same[/dim]", f)

    console.print(table)
    console.print(
        f"Summary: "
        f"{len(local_only)} local_only  "
        f"{len(remote_only)} remote_only  "
        f"{len(conflict)} conflict  "
        f"{len(same)} same"
    )

    if local_only:
        console.print(f"\nTip: run [bold]msapling drive push --project {proj_name}[/bold] to upload local-only files.")
    if remote_only:
        console.print(f"Tip: run [bold]msapling drive pull {proj_name}[/bold] to download remote-only files.")


# ─── drive ls ─────────────────────────────────────────────────────────────────


@drive_app.command("ls")
def drive_ls(
    project: Optional[str] = typer.Argument(None, help="MDrive project name (default: lists all projects)"),
    long: bool = typer.Option(False, "--long", "-l", help="Show detailed columns: size, modified, version"),
):
    """List remote files in a MDrive project."""
    _require_auth()

    async def _fetch():
        async with MSaplingClient() as client:
            try:
                if project:
                    return await client.drive_ls(project)
                else:
                    return await client.drive_ls("")
            except APIError as exc:
                if exc.status_code in (401, 403):
                    console.print("[red]Not authenticated. Run `msapling login`.[/red]")
                elif exc.status_code == 404:
                    console.print(f"[yellow]Project '{project}' not found.[/yellow]")
                else:
                    console.print(f"[red]ls failed: {exc}[/red]")
                raise typer.Exit(1)
            except OfflineError as exc:
                console.print(f"[red]Cannot connect to API: {exc}[/red]")
                raise typer.Exit(1)

    files = _run(_fetch())

    if not files:
        msg = f"No files in project '{project}'." if project else "No files found."
        console.print(f"[ms.dim]{msg}[/ms.dim]")
        raise typer.Exit(0)

    if long:
        table = Table(show_header=True, header_style="bold blue")
        table.add_column("Name", style="cyan", no_wrap=False)
        table.add_column("Size", justify="right", style="white")
        table.add_column("Modified", style="dim")
        table.add_column("Version", justify="right", style="dim")
        for f in files:
            name = str(f.get("path", f.get("name", "?")))
            size_raw = f.get("size", 0)
            size = _fmt_size(int(size_raw or 0))
            modified = str(f.get("updated_at", f.get("modified_at", f.get("modified", "—"))))[:19]
            version = str(f.get("version", f.get("version_id", "—")))
            table.add_row(name, size, modified, version)
        console.print(table)
    else:
        for f in files:
            name = str(f.get("path", f.get("name", "?")))
            console.print(f"[ms.file]{name}[/ms.file]")

    console.print(f"\n[ms.dim]{len(files)} file(s)[/ms.dim]")


# ─── drive share ──────────────────────────────────────────────────────────────


@drive_app.command("share")
def drive_share(
    project: str = typer.Argument(..., help="MDrive project name"),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Specific file path within the project to share"),
    expires: int = typer.Option(24, "--expires", "-e", help="Link expiry in hours (default: 24, max: 168)"),
):
    """Generate a public share link for a project file."""
    _require_auth()
    expires = max(1, min(int(expires), 168))
    file_path = file or ""

    if not file_path:
        console.print("[ms.warn]Specify a file with --file PATH to share a specific file.[/ms.warn]")
        raise typer.Exit(1)

    async def _do_share():
        async with MSaplingClient() as client:
            try:
                return await client.drive_share(project, file_path, expires)
            except APIError as exc:
                if exc.status_code in (401, 403):
                    console.print("[red]Not authenticated. Run `msapling login`.[/red]")
                elif exc.status_code == 404:
                    console.print(f"[red]Project '{project}' or file '{file_path}' not found.[/red]")
                else:
                    console.print(f"[red]Share failed: {exc}[/red]")
                raise typer.Exit(1)
            except OfflineError as exc:
                console.print(f"[red]Cannot connect to API: {exc}[/red]")
                raise typer.Exit(1)

    result = _run(_do_share())

    if isinstance(result, str):
        share_url = result
        expires_at = "—"
        token = "—"
    else:
        share_url = result.get("url", result.get("share_url", result.get("share_path", "?")))
        expires_at = str(result.get("expires_at", "—"))[:19]
        token = str(result.get("token", "—"))

    console.print(f"\n[ms.accent2]Share link created![/ms.accent2]")
    console.print(f"  [bold]URL:[/bold]     [ms.file]{share_url}[/ms.file]")
    console.print(f"  [bold]Expires:[/bold] [ms.dim]{expires_at} (in {expires}h)[/ms.dim]")
    console.print(f"  [bold]Token:[/bold]   [ms.dim]{token}[/ms.dim]")


# ─── drive status ─────────────────────────────────────────────────────────────


@drive_app.command("status")
def drive_status():
    """Show current MDrive storage usage and sync status."""
    _require_auth()

    async def _fetch():
        async with MSaplingClient() as client:
            try:
                return await client.mdrive_usage()
            except APIError as exc:
                if exc.status_code in (401, 403):
                    console.print("[red]Not authenticated. Run `msapling login`.[/red]")
                    raise typer.Exit(1)
                console.print(f"[red]Status fetch failed: {exc}[/red]")
                raise typer.Exit(1)
            except OfflineError as exc:
                console.print(f"[red]Cannot connect to API: {exc}[/red]")
                raise typer.Exit(1)

    usage = _run(_fetch())

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="bold blue")
    table.add_column("Value", style="white")

    used_bytes = int(usage.get("storage_used_bytes", usage.get("used_bytes", 0)))
    limit_bytes = int(usage.get("storage_limit_bytes", usage.get("limit_bytes", 0)))
    file_count = usage.get("file_count", usage.get("total_files", "—"))
    project_count = usage.get("project_count", "—")
    last_sync = str(usage.get("last_sync", usage.get("updated_at", "—")))[:19]

    table.add_row("Storage used", _fmt_size(used_bytes))
    table.add_row("Storage limit", _fmt_size(limit_bytes) if limit_bytes else "—")
    if limit_bytes:
        pct = (used_bytes / limit_bytes * 100) if limit_bytes else 0
        table.add_row("Usage %", f"{pct:.1f}%")
    table.add_row("Files", str(file_count))
    table.add_row("Projects", str(project_count))
    table.add_row("Last sync", last_sync)

    console.print("\nMDrive Status")
    console.print(table)
