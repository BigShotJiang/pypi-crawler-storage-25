"""Shared helpers for repo-grounded coding workflows."""
from __future__ import annotations

import re
import shlex
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple


_SKIP_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
    ".pytest_cache",
    ".pytest_tmp",
    ".tmp_codex",
    "tmp_cli_probe",
}

_HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")
_DIFF_GIT_RE = re.compile(r"^diff --git a/(.+?) b/(.+)$")


@dataclass
class VerifyStepResult:
    command: str
    return_code: int
    output: str = ""

    @property
    def ok(self) -> bool:
        return self.return_code == 0


@dataclass
class VerificationResult:
    ok: bool
    steps: List[VerifyStepResult] = field(default_factory=list)

    def failure_summary(self, *, max_chars: int = 4000) -> str:
        if self.ok:
            return ""
        lines: List[str] = []
        for step in self.steps:
            if step.ok:
                continue
            lines.append(f"$ {step.command}")
            body = (step.output or "").strip()
            if body:
                lines.append(body[:1200])
            lines.append("")
        text = "\n".join(lines).strip()
        return text[:max_chars]


def normalize_rel_path(path: str) -> str:
    return path.replace("\\", "/").lstrip("./")


def detect_workspace_root(start: str | Path = ".") -> Path:
    from .local import detect_project_root

    root, _ = detect_project_root(str(start))
    return Path(root).resolve()


def build_workspace_index(workspace_root: Path) -> Set[str]:
    """Return normalized relative file paths in the workspace."""
    root = workspace_root.resolve()
    rg = shutil.which("rg")
    if rg:
        try:
            proc = subprocess.run(
                [rg, "--files"],
                cwd=str(root),
                capture_output=True,
                text=True,
                timeout=20,
            )
            if proc.returncode == 0:
                return {
                    normalize_rel_path(line.strip())
                    for line in proc.stdout.splitlines()
                    if line.strip()
                }
        except Exception:
            pass

    results: Set[str] = set()
    for path in root.rglob("*"):
        try:
            rel = path.relative_to(root)
        except Exception:
            continue
        if any(part in _SKIP_DIRS for part in rel.parts):
            continue
        if path.is_file():
            results.add(normalize_rel_path(str(rel)))
    return results


def validate_repo_target(
    target_path: str | Path,
    *,
    workspace_root: Path,
    workspace_index: Optional[Set[str]] = None,
) -> Tuple[Path, str]:
    """Validate that target path exists in workspace and index."""
    target = Path(target_path).expanduser()
    if not target.is_absolute():
        target = (workspace_root / target)
    resolved = target.resolve()

    if not resolved.exists() or not resolved.is_file():
        raise ValueError(f"Target file not found: {target_path}")
    if not (resolved == workspace_root or resolved.is_relative_to(workspace_root)):
        raise ValueError(f"Target path is outside workspace: {target_path}")

    rel = normalize_rel_path(str(resolved.relative_to(workspace_root)))
    if workspace_index is not None and rel not in workspace_index:
        raise ValueError(f"Target file is not in workspace index: {rel}")
    return resolved, rel


def extract_unified_diff(text: str) -> str:
    """Strip prose/code-fence wrappers and return only unified diff text."""
    fence_match = re.search(r"```(?:diff)?\n(.*?)```", text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1)

    lines = text.splitlines()
    diff_lines: List[str] = []
    in_diff = False
    had_hunk = False
    for line in lines:
        if not in_diff:
            if line.startswith("---") or line.startswith("diff --git"):
                in_diff = True
                diff_lines.append(line)
            continue

        if (
            line.startswith("---")
            or line.startswith("+++")
            or line.startswith("@@")
            or line.startswith(" ")
            or line.startswith("+")
            or line.startswith("-")
            or line.startswith("\\")
            or line == ""
        ):
            if line.startswith("@@"):
                had_hunk = True
            diff_lines.append(line)
            continue
        if had_hunk:
            break
        diff_lines.append(line)

    return "\n".join(diff_lines).strip()


def normalize_unified_diff_headers(diff_text: str) -> str:
    diff_text = re.sub(r"^---\s+(?!a/)(.+)$", r"--- a/\1", diff_text, flags=re.MULTILINE)
    diff_text = re.sub(r"^\+\+\+\s+(?!b/)(.+)$", r"+++ b/\1", diff_text, flags=re.MULTILINE)
    return diff_text


def _strip_diff_prefix(raw: str) -> str:
    value = raw.strip().split("\t", 1)[0]
    if value in ("/dev/null", "nul"):
        return value
    if value.startswith("a/") or value.startswith("b/"):
        value = value[2:]
    return normalize_rel_path(value)


def extract_diff_paths(diff_text: str) -> Set[str]:
    """Return normalized repo-relative paths touched by a unified diff."""
    touched: Set[str] = set()
    for line in diff_text.splitlines():
        if line.startswith("diff --git "):
            match = _DIFF_GIT_RE.match(line.strip())
            if match:
                a_path = _strip_diff_prefix(match.group(1))
                b_path = _strip_diff_prefix(match.group(2))
                if a_path not in {"/dev/null", "nul"}:
                    touched.add(a_path)
                if b_path not in {"/dev/null", "nul"}:
                    touched.add(b_path)
            continue
        if line.startswith("--- ") or line.startswith("+++ "):
            stripped = _strip_diff_prefix(line[4:])
            if stripped not in {"/dev/null", "nul"}:
                touched.add(stripped)
    return touched


def enforce_repo_grounded_diff(
    diff_text: str,
    *,
    workspace_index: Set[str],
    allowed_paths: Optional[Iterable[str]] = None,
) -> List[str]:
    """Ensure diff touches only known indexed files (and optional allowlist)."""
    touched = extract_diff_paths(diff_text)
    if not touched:
        raise ValueError("Diff does not reference any file path.")

    unknown = sorted(path for path in touched if path not in workspace_index)
    if unknown:
        raise ValueError(f"Diff references path(s) outside workspace index: {', '.join(unknown)}")

    if allowed_paths is not None:
        allowed = {normalize_rel_path(p) for p in allowed_paths}
        disallowed = sorted(path for path in touched if path not in allowed)
        if disallowed:
            raise ValueError(f"Diff touched disallowed path(s): {', '.join(disallowed)}")
    return sorted(touched)


def extract_structured_evidence(diff_text: str, *, default_file: str) -> List[Dict[str, object]]:
    """Extract {file, line, snippet} evidence from diff hunks."""
    evidence: List[Dict[str, object]] = []
    current_file = normalize_rel_path(default_file)
    current_line: Optional[int] = None
    captured_for_hunk = False

    for raw in diff_text.splitlines():
        line = raw.rstrip("\n")
        if line.startswith("+++ "):
            parsed = _strip_diff_prefix(line[4:])
            if parsed not in {"/dev/null", "nul"}:
                current_file = parsed
            continue

        hunk_match = _HUNK_RE.match(line)
        if hunk_match:
            current_line = int(hunk_match.group(1))
            captured_for_hunk = False
            continue

        if current_line is None:
            continue
        if line.startswith("\\"):
            continue

        if line.startswith("+") and not line.startswith("+++"):
            snippet = line[1:].strip()
            if snippet and not captured_for_hunk:
                evidence.append({"file": current_file, "line": current_line, "snippet": snippet[:240]})
                captured_for_hunk = True
            current_line += 1
            continue

        if line.startswith("-") and not line.startswith("---"):
            snippet = line[1:].strip()
            if snippet and not captured_for_hunk:
                anchor = max(current_line - 1, 1)
                evidence.append({"file": current_file, "line": anchor, "snippet": snippet[:240]})
                captured_for_hunk = True
            continue

        current_line += 1

    return evidence


def build_default_verify_commands(target_rel: str, *, workspace_root: Path) -> List[str]:
    """Return targeted verification commands for a file path."""
    rel = normalize_rel_path(target_rel)
    ext = Path(rel).suffix.lower()
    commands: List[str] = []

    if ext == ".py":
        quoted = shlex.quote(rel)
        commands.append(f"python -m py_compile {quoted}")
        if shutil.which("ruff"):
            commands.append(f"ruff check {quoted}")
            commands.append(f"ruff format --check {quoted}")
        return commands

    # For non-Python edits, run no implicit commands by default to avoid
    # project-specific false failures. Callers can pass --verify-cmd.
    return commands


def run_verify_commands(
    commands: List[str],
    *,
    cwd: Path,
    timeout_s: float = 120.0,
) -> VerificationResult:
    if not commands:
        return VerificationResult(ok=True, steps=[])

    steps: List[VerifyStepResult] = []
    all_ok = True
    for command in commands:
        try:
            proc = subprocess.run(
                command,
                shell=True,
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=max(1.0, float(timeout_s)),
            )
            output = ((proc.stdout or "") + ("\n" if proc.stdout and proc.stderr else "") + (proc.stderr or "")).strip()
            step = VerifyStepResult(command=command, return_code=int(proc.returncode), output=output[:4000])
        except subprocess.TimeoutExpired:
            step = VerifyStepResult(command=command, return_code=124, output="Command timed out.")
        except Exception as exc:
            step = VerifyStepResult(command=command, return_code=1, output=str(exc))
        steps.append(step)
        if not step.ok:
            all_ok = False
    return VerificationResult(ok=all_ok, steps=steps)
