"""Process-level stream lock for MSapling CLI.

Prevents two CLI processes from streaming to the same chat_id simultaneously.
Uses a PID file under ~/.msapling/locks/<chat_id>.lock for best-effort
cross-process coordination.  If the CLI crashes the lock file stays on disk
but is treated as stale when the PID is no longer alive.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

_log = logging.getLogger(__name__)

_LOCKS_DIR = Path("~/.msapling/locks").expanduser()


def _locks_dir() -> Path:
    """Return (and create) the locks directory."""
    _LOCKS_DIR.mkdir(parents=True, exist_ok=True)
    return _LOCKS_DIR


def _lock_path(chat_id: str) -> Path:
    # Sanitise the chat_id so it can safely be used as a filename.
    safe = "".join(c if (c.isalnum() or c in "-_") else "_" for c in str(chat_id))
    return _locks_dir() / f"{safe}.lock"


def _pid_alive(pid: int) -> bool:
    """Return True if the process with *pid* is currently running."""
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def acquire_stream_lock(chat_id: Optional[str]) -> Optional[str]:
    """Try to acquire a stream lock for *chat_id*.

    Returns None on success (lock acquired).
    Returns a human-readable error message if the chat is already locked by a
    live process, so the caller can display it and abort.

    Stale lock files (PID no longer alive) are removed automatically.

    Edge cases handled:
    - chat_id is None/empty: no-op, returns None (lock skipped)
    - Same process calling acquire twice: re-entrant, treats own lock as stale
    - TOCTOU race: uses exclusive open('x') mode — only one writer wins
    - Corrupt/unreadable lock file: removed and lock is re-acquired
    """
    if not chat_id:
        return None  # Nothing to lock — skip silently

    path = _lock_path(str(chat_id))
    my_pid = os.getpid()

    # Remove stale or same-process lock before attempting exclusive create.
    if path.exists():
        try:
            existing_pid = int(path.read_text(encoding="utf-8").strip())
            if existing_pid == my_pid:
                # Re-entrant call from same process — treat as stale (no deadlock).
                _log.debug("stream_lock: re-entrant acquire by pid %d, removing own lock", my_pid)
                path.unlink(missing_ok=True)
            elif _pid_alive(existing_pid):
                return (
                    f"Chat {chat_id} is already streaming in process {existing_pid}. "
                    "Use /new to start a fresh chat."
                )
            else:
                # Stale lock — remove and proceed.
                _log.debug("stream_lock: removing stale lock for pid %d", existing_pid)
                path.unlink(missing_ok=True)
        except (ValueError, OSError) as exc:
            _log.debug("stream_lock: unreadable lock file, removing: %s", exc)
            path.unlink(missing_ok=True)

    # Atomic exclusive create — only one process wins the race.
    try:
        with open(path, "x", encoding="utf-8") as fh:
            fh.write(str(my_pid))
        return None
    except FileExistsError:
        # Lost the race — another process created the file between our unlink and
        # our open('x').  Read its PID and report.
        try:
            winner_pid = int(path.read_text(encoding="utf-8").strip())
            if _pid_alive(winner_pid):
                return (
                    f"Chat {chat_id} is already streaming in process {winner_pid}. "
                    "Use /new to start a fresh chat."
                )
            # Winner died before we could check — remove and skip locking.
            path.unlink(missing_ok=True)
        except (ValueError, OSError):
            pass
        return None  # Best-effort: proceed without lock rather than block the user
    except Exception as exc:  # pragma: no cover
        _log.debug("stream_lock: acquire failed (best-effort): %s", exc)
        return None


def release_stream_lock(chat_id: Optional[str]) -> None:
    """Release the stream lock for *chat_id* (best-effort, never raises).

    Only removes the lock file if it contains our own PID, preventing a
    late-arriving release from wiping a lock legitimately owned by another
    process (e.g. after a re-acquisition race).
    """
    if not chat_id:
        return
    try:
        path = _lock_path(str(chat_id))
        if not path.exists():
            return
        try:
            stored_pid = int(path.read_text(encoding="utf-8").strip())
            if stored_pid == os.getpid():
                path.unlink(missing_ok=True)
            else:
                _log.debug(
                    "stream_lock: release skipped — lock owned by pid %d, we are %d",
                    stored_pid, os.getpid(),
                )
        except (ValueError, OSError):
            # Corrupt file — safe to remove regardless.
            path.unlink(missing_ok=True)
    except Exception as exc:  # pragma: no cover
        _log.debug("stream_lock: release failed (best-effort): %s", exc)
