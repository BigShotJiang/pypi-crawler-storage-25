"""Exhaustive health-check logic for `msapling doctor`.

Each check is an async function returning ``(status, detail)`` where
*status* is ``"ok"``, ``"warn"``, or ``"fail"``.  All exceptions are
swallowed — a crashing check returns ``("fail", error_message)``.
"""
from __future__ import annotations

import asyncio
import os
import shutil
import time
from datetime import datetime, timezone
from typing import Tuple

from .fanout_governance import fanout_budget_detail, runtime_fanout_budget

# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------
CheckResult = Tuple[str, str]  # (status, detail)


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

async def check_api_ping(api_url: str) -> CheckResult:
    """GET /health and measure round-trip latency."""
    try:
        import httpx
        start = time.monotonic()
        async with httpx.AsyncClient(base_url=api_url, timeout=5.0) as client:
            resp = await client.get("/health")
        elapsed_ms = int((time.monotonic() - start) * 1000)
        if resp.status_code != 200:
            return ("fail", f"HTTP {resp.status_code} ({elapsed_ms}ms)")
        if elapsed_ms < 200:
            return ("ok", f"{elapsed_ms}ms")
        if elapsed_ms < 1000:
            return ("warn", f"{elapsed_ms}ms (slow)")
        return ("fail", f"{elapsed_ms}ms (too slow)")
    except Exception as exc:
        return ("fail", str(exc))


async def check_auth_token() -> CheckResult:
    """Read stored token and check if it decodes without expiry."""
    try:
        from .config import get_token
        token = get_token()
        if not token:
            return ("warn", "no token — run: msapling login")

        # Try to decode without verification (just inspect claims)
        try:
            import base64, json as _json
            parts = token.split(".")
            if len(parts) == 3:
                # JWT: decode payload (pad to multiple of 4)
                payload_b64 = parts[1]
                padding = 4 - len(payload_b64) % 4
                if padding != 4:
                    payload_b64 += "=" * padding
                payload = _json.loads(base64.urlsafe_b64decode(payload_b64))
                exp = payload.get("exp")
                if exp:
                    exp_dt = datetime.fromtimestamp(exp, tz=timezone.utc)
                    now = datetime.now(tz=timezone.utc)
                    if exp_dt < now:
                        return ("fail", f"token expired {exp_dt.date()}")
                    return ("ok", f"token valid, expires {exp_dt.date()}")
                return ("ok", "token present (no expiry claim)")
            # Opaque token (not a JWT)
            return ("ok", f"token present ({len(token)} chars)")
        except Exception:
            # Non-decodable token — still present
            return ("ok", f"token present ({len(token)} chars)")
    except Exception as exc:
        return ("fail", str(exc))


async def check_backend_version(api_url: str) -> CheckResult:
    """GET /api/status or /health and report backend version."""
    try:
        import httpx
        async with httpx.AsyncClient(base_url=api_url, timeout=5.0) as client:
            for path in ("/api/status", "/health"):
                try:
                    resp = await client.get(path)
                    if resp.status_code == 200:
                        data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
                        version = (
                            data.get("version")
                            or data.get("app_version")
                            or data.get("v")
                        )
                        if version:
                            return ("ok", f"v{version}")
                        return ("ok", f"reachable (no version field at {path})")
                except Exception:
                    continue
        return ("warn", "no status endpoint returned version info")
    except Exception as exc:
        return ("fail", str(exc))


async def check_model_list(api_url: str, token: str | None) -> CheckResult:
    """GET /api/models and count available models."""
    try:
        import httpx
        headers: dict = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        async with httpx.AsyncClient(base_url=api_url, timeout=10.0) as client:
            resp = await client.get("/api/models", headers=headers)
        if resp.status_code == 401:
            return ("warn", "not authenticated — model list unavailable")
        if resp.status_code != 200:
            return ("fail", f"HTTP {resp.status_code}")
        data = resp.json()
        if isinstance(data, list):
            count = len(data)
        elif isinstance(data, dict):
            count = len(data.get("models", data.get("data", [])))
        else:
            count = 0
        if count == 0:
            return ("warn", "0 models returned")
        return ("ok", f"{count} models")
    except Exception as exc:
        return ("fail", str(exc))


async def check_ws_endpoint(api_url: str) -> CheckResult:
    """Check WebSocket / Redis connectivity via /api/ws/health or /health."""
    try:
        import httpx
        # We probe a lightweight HTTP endpoint that exercises the Redis layer.
        # If the backend exposes /api/ws/health we use that; else fall back.
        ws_url = api_url.replace("https://", "wss://").replace("http://", "ws://")
        # First try HTTP probe
        async with httpx.AsyncClient(base_url=api_url, timeout=5.0) as client:
            for path in ("/api/ws/health", "/api/redis/health", "/health"):
                try:
                    resp = await client.get(path)
                    if resp.status_code == 200:
                        data = {}
                        try:
                            data = resp.json()
                        except Exception:
                            pass
                        redis_ok = data.get("redis", data.get("ws", True))
                        if redis_ok is False:
                            return ("fail", f"Redis/WS unhealthy at {path}")
                        return ("ok", f"connected (via {path})")
                except Exception:
                    continue
        return ("warn", f"no WS health probe reachable at {api_url}")
    except Exception as exc:
        return ("fail", str(exc))


async def check_cli_version() -> CheckResult:
    """Compare installed CLI version to latest on PyPI."""
    try:
        from . import __version__ as installed
        import httpx
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get("https://pypi.org/pypi/msapling-cli/json")
            if resp.status_code == 200:
                data = resp.json()
                latest = data.get("info", {}).get("version", "?")
                if latest == installed:
                    return ("ok", f"{installed} (up to date)")
                # Simple semver comparison: treat as strings for now
                try:
                    from packaging.version import Version
                    if Version(installed) < Version(latest):
                        return ("warn", f"{installed} (latest: {latest} — run: msapling upgrade)")
                except ImportError:
                    if installed != latest:
                        return ("warn", f"{installed} (latest: {latest})")
                return ("ok", f"{installed} (up to date)")
            return ("warn", f"{installed} (PyPI unreachable: HTTP {resp.status_code})")
        except Exception:
            return ("warn", f"{installed} (could not reach PyPI)")
    except Exception as exc:
        return ("fail", str(exc))


async def check_dependencies() -> CheckResult:
    """Check that httpx, rich, and keyring are importable; report versions."""
    try:
        from importlib.metadata import version as _ver, PackageNotFoundError

        results = []
        missing = []
        for pkg in ("httpx", "rich", "keyring"):
            try:
                v = _ver(pkg)
                results.append(f"{pkg}={v}")
            except PackageNotFoundError:
                missing.append(pkg)

        if missing:
            return ("warn", f"missing: {', '.join(missing)}; found: {', '.join(results)}")
        return ("ok", ", ".join(results))
    except Exception as exc:
        return ("fail", str(exc))


async def check_auth_source() -> CheckResult:
    """Report which token source is active and flag conflicts between sources."""
    try:
        from .config import inspect_token_sources, get_token
        sources = inspect_token_sources()
        env_token = sources.get("env")
        file_token = sources.get("file")
        keyring_token = sources.get("keyring")

        active_sources = [
            (label, tok)
            for label, tok in [
                ("env var MSAPLING_TOKEN", env_token),
                ("~/.msapling/token file", file_token),
                ("keyring", keyring_token),
            ]
            if tok
        ]

        if not active_sources:
            return ("warn", "no token — run: msapling login")

        # Conflict: env and keyring both present with different values
        if env_token and keyring_token and env_token != keyring_token:
            return ("warn", "conflict: env var MSAPLING_TOKEN and keyring disagree")
        if env_token and file_token and env_token != file_token:
            return ("warn", "conflict: env var MSAPLING_TOKEN and token file disagree")

        label, _ = active_sources[0]
        return ("ok", f"active source: {label}")
    except Exception as exc:
        return ("fail", str(exc))


async def check_active_project() -> CheckResult:
    """Report the active project and chat from local config, if present."""
    try:
        from pathlib import Path
        import json as _json

        config_path = Path.home() / ".msapling" / "config.json"
        if not config_path.exists():
            return ("warn", "no local config (~/.msapling/config.json missing)")

        try:
            data = _json.loads(config_path.read_text(encoding="utf-8"))
        except Exception as exc:
            return ("warn", f"config unreadable: {exc}")

        active_project = data.get("active_project") or data.get("project")
        active_chat = data.get("active_chat_id") or data.get("chat_id")

        if not active_project:
            return ("warn", "no active project configured in local config")

        detail = f"project: {active_project}"
        if active_chat:
            detail += f", chat: {active_chat}"
        return ("ok", detail)
    except Exception as exc:
        return ("fail", str(exc))


async def check_model_source() -> CheckResult:
    """Report where the active model setting comes from."""
    try:
        import os
        from .config import get_settings

        env_model = os.environ.get("MSAPLING_MODEL")
        if env_model:
            return ("ok", f"MSAPLING_MODEL env: {env_model}")

        settings = get_settings()
        if settings.default_model:
            return ("ok", f"settings.default_model: {settings.default_model}")

        return ("ok", "default fallback: google/gemini-2.0-flash-001")
    except Exception as exc:
        return ("fail", str(exc))


async def check_history_source() -> CheckResult:
    """Report how history is retrieved and whether a local cache exists."""
    try:
        from pathlib import Path

        sessions_dir = Path.home() / ".msapling" / "sessions"
        if not sessions_dir.exists():
            return ("ok", "server only (no local cache)")

        session_files = list(sessions_dir.glob("*.json"))
        count = len(session_files)
        if count == 0:
            return ("ok", "server only (sessions dir empty)")
        return ("ok", f"server + local cache ({count} sessions)")
    except Exception as exc:
        return ("fail", str(exc))


async def check_lock_state(api_url: str, token: str | None) -> CheckResult:
    """Probe /health to check for any active stream locks reported by the backend."""
    try:
        import httpx
        headers: dict = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        try:
            async with httpx.AsyncClient(base_url=api_url, timeout=5.0) as client:
                resp = await client.get("/health", headers=headers)
            if resp.status_code != 200:
                return ("warn", f"server returned HTTP {resp.status_code} — lock state unknown")
            data = {}
            try:
                data = resp.json()
            except Exception:
                pass
            locked = data.get("locked_chats") or data.get("active_streams")
            if locked:
                return ("warn", f"{locked} active stream lock(s) detected")
            return ("ok", "no active streams detected (probe only)")
        except Exception:
            return ("warn", "server unreachable — lock state unknown")
    except Exception as exc:
        return ("fail", str(exc))


async def check_worker_state(api_url: str, token: str | None) -> CheckResult:
    """Probe backend for active background workers or task queue depth."""
    try:
        import httpx
        headers: dict = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        try:
            async with httpx.AsyncClient(base_url=api_url, timeout=5.0) as client:
                for path in ("/api/status", "/health"):
                    try:
                        resp = await client.get(path, headers=headers)
                        if resp.status_code == 200:
                            data = {}
                            try:
                                data = resp.json()
                            except Exception:
                                pass
                            workers = data.get("workers") or data.get("active_tasks") or data.get("task_queue_depth")
                            if isinstance(workers, int) and workers > 0:
                                return ("warn", f"{workers} active worker(s)")
                            return ("ok", "no active workers")
                    except Exception:
                        continue
            return ("warn", "server unreachable — worker state unknown")
        except Exception:
            return ("warn", "server unreachable — worker state unknown")
    except Exception as exc:
        return ("fail", str(exc))


async def check_credential_resolution() -> CheckResult:
    """Show which credential source is active and the resolution order."""
    try:
        import os
        from .config import get_settings, inspect_token_sources

        sources = inspect_token_sources()
        env_token = sources.get("env") or ""
        file_token = sources.get("file") or ""
        keyring_token = sources.get("keyring") or ""

        active: str | None = None
        source_lines: list[str] = []

        if env_token:
            source_lines.append("MSAPLING_TOKEN env var (active)")
            active = "env var MSAPLING_TOKEN"
        else:
            source_lines.append("MSAPLING_TOKEN env var (not set)")

        if file_token:
            source_lines.append("config file token (present)")
            if not active:
                active = "config file"
        else:
            source_lines.append("config file token (not found)")

        if keyring_token:
            source_lines.append("OS keyring (present)")
            if not active:
                active = "OS keyring"
        else:
            source_lines.append("OS keyring (empty)")

        order_str = "MSAPLING_TOKEN -> config file -> keyring"
        detail = (
            f"Resolution order: {order_str} | "
            f"Active: {active or 'none'} | "
            + ", ".join(source_lines)
        )

        if active:
            return ("ok", detail)
        return ("warn", detail + " | run: msapling login")
    except Exception as exc:
        return ("fail", str(exc))


async def check_session_endpoint(api_url: str, token: str | None) -> CheckResult:
    """Verify the sessions endpoint is reachable (cross-surface parity check)."""
    try:
        if not token:
            return ("warn", "not authenticated — run: msapling login")
        import httpx
        base = api_url.rstrip("/")
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(
                    f"{base}/api/chat/sessions?limit=1",
                    headers={"Authorization": f"Bearer {token}"},
                )
            if resp.status_code in (200, 401):
                return ("ok", f"sessions endpoint reachable (HTTP {resp.status_code})")
            return ("warn", f"sessions endpoint returned HTTP {resp.status_code}")
        except Exception as e:
            return ("warn", f"sessions endpoint unreachable: {e}")
    except Exception as exc:
        return ("fail", str(exc))


async def _probe_runtime_endpoint(
    base_url: str,
    paths: tuple[str, ...],
    *,
    timeout_s: float = 2.5,
) -> tuple[bool, str]:
    """Probe a runtime endpoint and return (reachable, detail)."""
    import httpx

    url = str(base_url or "").strip().rstrip("/")
    if not url:
        return (False, "missing URL")

    timeout = httpx.Timeout(connect=timeout_s, read=timeout_s, write=timeout_s, pool=timeout_s)
    last_error = "unreachable"
    async with httpx.AsyncClient(base_url=url, timeout=timeout) as client:
        for path in paths:
            try:
                resp = await client.get(path)
                # Accept 2xx/3xx/4xx as proof the process is reachable.
                if resp.status_code < 500:
                    return (True, f"{url}{path} (HTTP {resp.status_code})")
                last_error = f"HTTP {resp.status_code}"
            except Exception as exc:
                last_error = str(exc)
    return (False, last_error)


async def check_local_runtime_matrix() -> CheckResult:
    """Probe local-runtime support matrix for ollama, llama.cpp, and mllama."""
    try:
        from .config import get_settings

        entries: list[str] = []
        any_warn = False
        any_fail = False

        # --- Ollama ---
        settings = get_settings()
        ollama_enabled = bool(getattr(settings, "ollama_enabled", True))
        ollama_env = str(os.environ.get("MSAPLING_OLLAMA_URL", "") or "").strip()
        ollama_url = (
            ollama_env
            or str(getattr(settings, "ollama_base_url", "http://127.0.0.1:11434")).strip()
        ).rstrip("/")

        if not ollama_enabled:
            any_warn = True
            entries.append("ollama: disabled (enable with `msapling ollama base-url <url>`)")  # noqa: E501
        else:
            ok, detail = await _probe_runtime_endpoint(ollama_url, ("/api/version", "/api/tags"))
            if ok:
                entries.append(f"ollama: ready @ {ollama_url}")
            else:
                if ollama_env:
                    any_fail = True
                    entries.append(
                        f"ollama: configured but unreachable @ {ollama_url} ({detail}); "
                        "run `ollama serve` or unset MSAPLING_OLLAMA_URL"
                    )
                else:
                    any_warn = True
                    entries.append(
                        f"ollama: unavailable @ {ollama_url} ({detail}); run `ollama serve`"
                    )

        # --- llama.cpp ---
        llama_cpp_url = (
            str(os.environ.get("MSAPLING_LLAMA_CPP_URL", "") or "").strip()
            or str(os.environ.get("LLAMA_CPP_URL", "") or "").strip()
        ).rstrip("/")
        llama_server_bin = shutil.which("llama-server")
        if llama_cpp_url:
            ok, detail = await _probe_runtime_endpoint(
                llama_cpp_url,
                ("/health", "/v1/models", "/props"),
            )
            if ok:
                entries.append(f"llama.cpp: ready @ {llama_cpp_url}")
            else:
                any_fail = True
                entries.append(
                    f"llama.cpp: configured but unreachable @ {llama_cpp_url} ({detail}); "
                    "verify `llama-server` is running and endpoint is reachable"
                )
        elif llama_server_bin:
            any_warn = True
            entries.append(
                "llama.cpp: binary found but URL unset (set MSAPLING_LLAMA_CPP_URL, "
                "e.g. http://127.0.0.1:8080)"
            )
        else:
            any_warn = True
            entries.append(
                "llama.cpp: not configured (install/start `llama-server` and set MSAPLING_LLAMA_CPP_URL)"
            )

        # --- mllama ---
        mllama_url = (
            str(os.environ.get("MSAPLING_MLLAMA_URL", "") or "").strip()
            or str(os.environ.get("MLLAMA_BASE_URL", "") or "").strip()
            or str(os.environ.get("MLLAMA_URL", "") or "").strip()
        ).rstrip("/")
        mllama_key = (
            str(os.environ.get("MSAPLING_MLLAMA_KEY", "") or "").strip()
            or str(os.environ.get("MLLAMA_API_KEY", "") or "").strip()
        )
        if mllama_url:
            ok, detail = await _probe_runtime_endpoint(mllama_url, ("/health", "/v1/models"))
            if ok:
                if mllama_key:
                    entries.append(f"mllama: ready @ {mllama_url} (api-key present)")
                else:
                    any_warn = True
                    entries.append(f"mllama: reachable @ {mllama_url} (no API key configured)")
            else:
                any_fail = True
                entries.append(
                    f"mllama: configured but unreachable @ {mllama_url} ({detail}); "
                    "verify endpoint and MSAPLING_MLLAMA_URL"
                )
        elif mllama_key:
            any_warn = True
            entries.append("mllama: API key set but URL missing (set MSAPLING_MLLAMA_URL)")
        else:
            any_warn = True
            entries.append("mllama: not configured (set MSAPLING_MLLAMA_URL and MSAPLING_MLLAMA_KEY)")

        detail = " | ".join(entries)
        if any_fail:
            return ("fail", detail)
        if any_warn:
            return ("warn", detail)
        return ("ok", detail)
    except Exception as exc:
        return ("fail", str(exc))


async def check_state_drift(api_url: str, token: str | None) -> CheckResult:
    """Compare local project cache count to server project count."""
    try:
        # Count server projects
        import httpx
        headers: dict = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        server_count: int | None = None
        try:
            async with httpx.AsyncClient(base_url=api_url, timeout=10.0) as client:
                resp = await client.get("/api/projects", headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list):
                    server_count = len(data)
                elif isinstance(data, dict):
                    projects = data.get("projects", data.get("data", None))
                    if isinstance(projects, (list, dict)):
                        server_count = len(projects)
        except Exception:
            pass

        # Count local cached projects
        from pathlib import Path
        local_dir = Path.home() / ".msapling" / "projects"
        local_count = 0
        if local_dir.exists():
            local_count = sum(1 for d in local_dir.iterdir() if d.is_dir())

        if server_count is None:
            return ("warn", f"local cache: {local_count} projects (server unreachable)")

        if server_count == local_count:
            return ("warn", f"server:{server_count} projects, local cache:{local_count} (in sync)")

        diff = abs(server_count - local_count)
        direction = "ahead" if local_count > server_count else "behind"
        return ("warn", f"server:{server_count} projects, local cache:{local_count} ({diff} drift, local {direction})")
    except Exception as exc:
        return ("fail", str(exc))


async def check_fanout_governance() -> CheckResult:
    """Report adaptive multi/swarm lane cap recommendations for this runtime."""
    try:
        budget = runtime_fanout_budget()
        cap = int(budget.get("recommended_cap") or 1)
        detail = fanout_budget_detail(budget)
        if cap <= 1:
            return ("warn", detail)
        return ("ok", detail)
    except Exception as exc:
        return ("fail", str(exc))


# ---------------------------------------------------------------------------
# Check registry
# ---------------------------------------------------------------------------

CHECKS = [
    "API connectivity",
    "Authentication",
    "Backend version",
    "Model availability",
    "Redis/WebSocket",
    "CLI version",
    "Dependency versions",
    "Local state drift",
    "Auth source",
    "Active project",
    "Model source",
    "History source",
    "Lock state",
    "Worker state",
    "Credential resolution",
    "Cross-surface sessions",
    "Local runtime matrix",
    "Fanout governance",
]


async def run_all_checks(api_url: str, token: str | None) -> list[tuple[str, str, str]]:
    """Run all checks and return list of (name, status, detail)."""
    tasks = [
        ("API connectivity",      check_api_ping(api_url)),
        ("Authentication",        check_auth_token()),
        ("Backend version",       check_backend_version(api_url)),
        ("Model availability",    check_model_list(api_url, token)),
        ("Redis/WebSocket",       check_ws_endpoint(api_url)),
        ("CLI version",           check_cli_version()),
        ("Dependency versions",   check_dependencies()),
        ("Local state drift",     check_state_drift(api_url, token)),
        ("Auth source",           check_auth_source()),
        ("Active project",        check_active_project()),
        ("Model source",          check_model_source()),
        ("History source",        check_history_source()),
        ("Lock state",            check_lock_state(api_url, token)),
        ("Worker state",          check_worker_state(api_url, token)),
        ("Credential resolution", check_credential_resolution()),
        ("Cross-surface sessions",check_session_endpoint(api_url, token)),
        ("Local runtime matrix", check_local_runtime_matrix()),
        ("Fanout governance", check_fanout_governance()),
    ]
    results = []
    for name, coro in tasks:
        status, detail = await coro
        results.append((name, status, detail))
    return results


def print_report(results: list[tuple[str, str, str]], date_str: str) -> None:
    """Print the doctor report using rich if available, else plain text."""
    bar = "\u2501" * 36

    icons = {"ok": "\u2713", "warn": "!", "fail": "\u2717"}  # ✓ ! ✗

    passed = sum(1 for _, s, _ in results if s == "ok")
    warned = sum(1 for _, s, _ in results if s == "warn")
    failed = sum(1 for _, s, _ in results if s == "fail")
    total = len(results)

    try:
        from rich.console import Console
        from rich.text import Text

        c = Console()
        c.print(f"[bold]MSapling Doctor[/bold] \u2014 {date_str}")
        c.print(bar)
        for name, status, detail in results:
            icon = icons[status]
            name_padded = f"{name:<22}"
            if status == "ok":
                c.print(f"  [green]{icon}[/green] {name_padded} {detail}")
            elif status == "warn":
                c.print(f"  [yellow]{icon}[/yellow] {name_padded} {detail}")
            else:
                c.print(f"  [red]{icon}[/red] {name_padded} {detail}")
        c.print(bar)
        summary_parts = []
        if passed:
            summary_parts.append(f"[green]{passed} passed[/green]")
        if warned:
            summary_parts.append(f"[yellow]{warned} warnings[/yellow]")
        if failed:
            summary_parts.append(f"[red]{failed} failed[/red]")
        result_str = ", ".join(summary_parts) if summary_parts else "no checks"
        c.print(f"Result: {passed}/{total} checks passed  ({result_str})")
    except ImportError:
        # Fallback: plain text
        print(f"MSapling Doctor — {date_str}")
        print(bar)
        for name, status, detail in results:
            icon = icons[status]
            name_padded = f"{name:<22}"
            print(f"  {icon} {name_padded} {detail}")
        print(bar)
        print(f"Result: {passed}/{total} checks passed")
