"""Local file operations for MSapling CLI.

Provides direct local filesystem access for coding workflows -
reading files, applying diffs, running git commands, detecting projects.
No server required for these operations.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def detect_project_root(start: str = ".") -> Tuple[str, Dict]:
    """Walk up from start to find project root markers."""
    current = Path(start).resolve()
    markers = {
        ".git": "git",
        "package.json": "node",
        "pyproject.toml": "python",
        "Cargo.toml": "rust",
        "go.mod": "go",
        "pom.xml": "java",
        "requirements.txt": "python",
        "tsconfig.json": "typescript",
    }
    while current != current.parent:
        found = {}
        for marker, ptype in markers.items():
            if (current / marker).exists():
                found[marker] = ptype
        if found:
            primary = list(found.values())[0]
            return str(current), {"type": primary, "markers": list(found.keys())}
        current = current.parent
    return str(Path(start).resolve()), {"type": "unknown", "markers": []}


def build_file_tree(root: str, patterns: Optional[List[str]] = None, max_files: int = 100) -> List[Dict]:
    """Build a file tree of the project for context injection."""
    patterns = patterns or ["*.py", "*.ts", "*.tsx", "*.js", "*.jsx", "*.md", "*.yaml", "*.yml", "*.toml", "*.json"]
    skip_dirs = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build", ".next", "coverage", ".mypy_cache", ".pytest_tmp", ".pytest_cache", "pytest-cache-files-lhmmue2m", "tmp_cli_probe"}

    root_path = Path(root)
    files = []
    for pattern in patterns:
        for fpath in sorted(root_path.rglob(pattern)):
            if len(files) >= max_files:
                break
            if any(p in skip_dirs for p in fpath.relative_to(root_path).parts):
                continue
            if not fpath.is_file():
                continue
            # Guard against symlinks that escape the project root
            try:
                resolved = fpath.resolve()
                if not resolved.is_relative_to(root_path.resolve()):
                    continue
            except Exception:
                continue
            rel = str(fpath.relative_to(root_path)).replace("\\", "/")
            size = fpath.stat().st_size
            files.append({
                "path": rel,
                "size": size,
                "lines": _count_lines(fpath),
            })
    return files


def _count_lines(fpath: Path) -> int:
    try:
        return len(fpath.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception:
        return 0


def read_files_as_context(root: str, files: List[Dict], max_size_kb: int = 50) -> str:
    """Read file contents and format as LLM context block."""
    root_path = Path(root)
    parts = []

    # Tree summary
    tree_lines = []
    for f in files:
        size_kb = f["size"] / 1024
        tree_lines.append(f"  {f['path']} ({f['lines']} lines, {size_kb:.1f}KB)")
    parts.append("## Project Structure\n```\n" + "\n".join(tree_lines) + "\n```")

    # File contents
    for f in files:
        if f["size"] > max_size_kb * 1024:
            continue
        fpath = root_path / f["path"]
        try:
            content = fpath.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        ext = Path(f["path"]).suffix.lstrip(".")
        lang = {"py": "python", "ts": "typescript", "tsx": "tsx", "js": "javascript", "md": "markdown"}.get(ext, ext)
        parts.append(f"## {f['path']}\n```{lang}\n{content}\n```")

    return "\n\n".join(parts)


def git_status(cwd: str = ".") -> str:
    """Get git status of the project."""
    try:
        result = subprocess.run(
            ["git", "status", "--short"],
            cwd=cwd, capture_output=True, text=True, timeout=10,
        )
        return result.stdout.strip() if result.returncode == 0 else result.stderr.strip()
    except Exception as e:
        return f"git not available: {e}"


def git_diff(cwd: str = ".", staged: bool = False) -> str:
    """Get git diff."""
    cmd = ["git", "diff"]
    if staged:
        cmd.append("--staged")
    try:
        result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=30)
        return result.stdout.strip()
    except Exception as e:
        return f"git diff failed: {e}"


def git_log(cwd: str = ".", count: int = 10) -> str:
    """Get recent git log."""
    try:
        result = subprocess.run(
            ["git", "log", f"--oneline", f"-{count}"],
            cwd=cwd, capture_output=True, text=True, timeout=10,
        )
        return result.stdout.strip()
    except Exception as e:
        return f"git log failed: {e}"
