"""SessionStart Hook — load prior session context into the system prompt on startup.

On every session start this module assembles a continuity block from:
  1. The most-recent precompact snapshot for the session (if any).
  2. Short summaries (title + key decisions) from the last N completed sessions.
  3. Project-level memories (if a project is active).

The assembled block is prepended to the opening system prompt so the LLM has
full continuity without any manual setup from the user.

Usage from shell.py ``start()``:
    from .session_start_hook import load_session_start_context, inject_into_system_prompt
    ctx = load_session_start_context(session_id, project_name)
    system_prompt = inject_into_system_prompt(existing_system_prompt, ctx)
    if ctx.precompact_summary or ctx.recent_session_summary:
        console.print("[Context loaded from previous session]")
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------

MARKER_OPEN = "<!-- session-start-context -->"
MARKER_CLOSE = "<!-- /session-start-context -->"

_RECENT_SESSION_COUNT = 3


@dataclass
class SessionStartContext:
    """Assembled context loaded at session start for LLM continuity.

    Attributes
    ----------
    precompact_summary:
        Formatted text from the most-recent precompact snapshot, or empty
        string if no snapshot exists.
    recent_session_summary:
        Multi-line text summarising the last N completed sessions
        (titles + key decisions from metadata).
    memories_injected:
        ``True`` if project-level memories were loaded and included.
    profile_used:
        The context profile name used to assemble this context, or empty
        string when the default profile is applied.
    assembled_at:
        Unix timestamp of when this context was assembled.
    """

    precompact_summary: str = ""
    recent_session_summary: str = ""
    memories_injected: bool = False
    profile_used: str = ""
    assembled_at: float = field(default_factory=time.time)

    def is_empty(self) -> bool:
        """Return True when there is nothing to inject."""
        return not self.precompact_summary and not self.recent_session_summary


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_session_start_context(
    session_id: str,
    project: Optional[str] = None,
    *,
    recent_n: int = _RECENT_SESSION_COUNT,
    project_id: Optional[str] = None,
    messages: Optional[List[dict]] = None,
) -> SessionStartContext:
    """Assemble a SessionStartContext for injection at session start.

    Parameters
    ----------
    session_id:
        The ID of the session being started (used to look up the matching
        precompact snapshot).
    project:
        The project name/root path, if known.  When provided, project-level
        memories are loaded.
    recent_n:
        How many recent sessions to include in the continuity summary.
    project_id:
        An explicit project identifier for profile persistence.  Falls back
        to *project* when not provided.
    messages:
        Recent messages used for auto-detection when no saved profile exists.

    Returns
    -------
    SessionStartContext
        Fully populated context (all fields default to empty/falsy when no
        prior data is available, so the caller may always safely call
        ``format_start_injection()`` without a None-check).
    """
    precompact_summary = _load_precompact(session_id)
    recent_summary = _load_recent_sessions(recent_n=recent_n, exclude_id=session_id)
    memories_injected = False

    if project:
        memories_injected = _has_project_memories(project)

    # --- Profile resolution ---------------------------------------------------
    # Use the explicit project_id if given, otherwise derive from project path.
    pid = project_id or (project or "default")
    profile_used = _resolve_profile(pid, messages=messages)

    return SessionStartContext(
        precompact_summary=precompact_summary,
        recent_session_summary=recent_summary,
        memories_injected=memories_injected,
        profile_used=profile_used,
        assembled_at=time.time(),
    )


def format_start_injection(ctx: SessionStartContext) -> str:
    """Format a SessionStartContext as a system-prompt-ready string.

    Returns an empty string when the context has nothing to inject.

    Parameters
    ----------
    ctx:
        The assembled context to format.

    Returns
    -------
    str
        Non-empty formatted block, or ``""`` when nothing to inject.
    """
    if ctx.is_empty():
        return ""

    parts: List[str] = []

    if ctx.precompact_summary:
        parts.append("### Session Context")
        parts.append(ctx.precompact_summary)

    if ctx.recent_session_summary:
        parts.append("")
        parts.append("### Recent Work")
        parts.append(ctx.recent_session_summary)

    assembled_ts = ""
    try:
        assembled_ts = datetime.fromtimestamp(ctx.assembled_at, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M UTC"
        )
    except Exception:
        pass

    if assembled_ts:
        parts.append("")
        parts.append(f"*Context assembled: {assembled_ts}*")

    return "\n".join(parts).strip()


def inject_into_system_prompt(system_prompt: str, ctx: SessionStartContext) -> str:
    """Prepend the session-start context block to an existing system prompt.

    The injected block is wrapped in HTML-comment markers so it can be
    stripped programmatically if needed:
        ``<!-- session-start-context --> ... <!-- /session-start-context -->``

    Parameters
    ----------
    system_prompt:
        The existing system prompt string (may be empty).
    ctx:
        The assembled context to prepend.

    Returns
    -------
    str
        The combined system prompt.  If there is nothing to inject the
        original ``system_prompt`` is returned unchanged.  Repeated calls
        are idempotent — an existing marker block is replaced rather than
        duplicated.
    """
    # Strip any previously injected block to prevent duplication.
    prompt = _strip_existing_marker(system_prompt)

    injection = format_start_injection(ctx)
    if not injection:
        return prompt

    tagged = f"{MARKER_OPEN}\n{injection}\n{MARKER_CLOSE}"

    if prompt:
        return f"{tagged}\n\n{prompt}"
    return tagged


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _load_precompact(session_id: str) -> str:
    """Load and format the most-recent precompact snapshot for *session_id*."""
    try:
        from .precompact_hook import load_latest_precompact, format_for_injection  # type: ignore
        ctx = load_latest_precompact(session_id)
        if ctx is None:
            return ""
        return format_for_injection(ctx)
    except Exception:
        return ""


def _load_recent_sessions(*, recent_n: int, exclude_id: str) -> str:
    """Build a short summary of the last *recent_n* sessions.

    Each line is:  ``<title> — <key decision snippet>``

    Old sessions that lack a ``"metadata"`` key are still included using a
    synthetic title derived from ``_summary`` or message count.
    """
    try:
        from .session import list_sessions  # type: ignore
        sessions = list_sessions(limit=recent_n + 5)  # fetch a few extra to allow exclusion
    except Exception:
        return ""

    lines: List[str] = []
    for s in sessions:
        if s.get("id") == exclude_id:
            continue

        meta = s.get("metadata") or {}
        title = (
            meta.get("summary")
            or s.get("_summary", "")
            or f"Session {s.get('id', '')[:8]}"
        )[:120]

        project = meta.get("project_name") or ""
        project_tag = f" [{project}]" if project else ""

        lines.append(f"- {title}{project_tag}")
        if len(lines) >= recent_n:
            break

    return "\n".join(lines) if lines else ""


def _has_project_memories(project: str) -> bool:
    """Return True if a project memory file exists and has entries."""
    try:
        from .memory import get_memories  # type: ignore
        result = get_memories(project_root=project)
        return bool(result and result.strip())
    except Exception:
        return False


def _resolve_profile(project_id: str, *, messages: Optional[List[dict]] = None) -> str:
    """Return the active profile name for *project_id*.

    Resolution order:
    1. Saved profile from ``profile_persistence.load_profile()``.
    2. Auto-detected via ``context_profiles.detect_profile()`` (result is saved
       so subsequent sessions reuse it).
    3. Empty string as a safe fallback.
    """
    try:
        from .profile_persistence import load_profile, save_profile
        saved = load_profile(project_id)
        if saved:
            return saved
    except Exception:
        pass

    # Auto-detect from messages when available
    try:
        import sys
        import importlib

        # context_profiles lives in backend/services — attempt a direct import
        # when the backend is on sys.path, otherwise skip gracefully.
        cp = importlib.import_module("backend.services.context_profiles")
        if messages:
            detected = cp.detect_profile(messages)
        else:
            detected = None
        if detected:
            try:
                from .profile_persistence import save_profile  # type: ignore[assignment]
                save_profile(project_id, detected)
            except Exception:
                pass
            return detected
    except Exception:
        pass

    return ""


def _strip_existing_marker(text: str) -> str:
    """Remove any previously injected session-start-context block from *text*."""
    import re
    pattern = re.compile(
        rf"{re.escape(MARKER_OPEN)}.*?{re.escape(MARKER_CLOSE)}\n*",
        re.DOTALL,
    )
    return pattern.sub("", text).lstrip()
