"""
MSapling CLI — Offline Token Accounting
Persists token events generated during provider failover to a local JSONL
ledger and syncs them to the server when connectivity is restored.

Usage:
    ledger = LocalTokenLedger()
    ledger.record_local("anthropic/claude-3-haiku", 500, 300, 0.0002, "primary_circuit_open")
    result = await ledger.sync_to_server(client)
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Default ledger path — ~/.msapling/offline_tokens.jsonl
# ---------------------------------------------------------------------------
def _default_ledger_path() -> Path:
    base = Path(os.environ.get("MSAPLING_OFFLINE_LEDGER_DIR", "")).expanduser()
    if not base or not base.is_dir():
        base = Path.home() / ".msapling"
    base.mkdir(parents=True, exist_ok=True)
    return base / "offline_tokens.jsonl"


# ---------------------------------------------------------------------------
# LocalTokenLedger
# ---------------------------------------------------------------------------

class LocalTokenLedger:
    """File-backed JSONL ledger for CLI offline token accounting.

    Each line in the JSONL file is a complete, self-contained JSON object
    representing one pending token event.  Synced entries are marked in-place
    by rewriting the synced/synced_at fields.

    Thread-safety: This class is not thread-safe; it is designed for use in a
    single-threaded async CLI context.  Do not share instances across threads.
    """

    def __init__(self, ledger_path: Optional[Path] = None) -> None:
        self._path: Path = ledger_path or _default_ledger_path()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def record_local(
        self,
        model: str,
        tokens_in: int,
        tokens_out: int,
        cost_usd: float,
        reason: str,
        *,
        chat_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Append a new pending token event to the local ledger.

        Args:
            model: Model identifier used during the failover call.
            tokens_in: Prompt tokens consumed.
            tokens_out: Completion tokens generated.
            cost_usd: Pre-calculated USD cost.
            reason: Why the failover occurred (e.g. "primary_circuit_open").
            chat_id: Optional chat session ID for correlation.

        Returns:
            The dict that was appended (includes generated ``entry_id``).
        """
        recorded_at = time.time()
        entry_id = str(uuid.uuid4())
        # Deterministic idempotency key prevents double-sync on crash-replay
        raw_key = f"{model}:{chat_id or ''}:{recorded_at:.3f}:{entry_id}"
        idempotency_key = hashlib.sha256(raw_key.encode()).hexdigest()

        entry: Dict[str, Any] = {
            "entry_id": entry_id,
            "model": str(model or ""),
            "chat_id": chat_id,
            "tokens_in": max(0, int(tokens_in or 0)),
            "tokens_out": max(0, int(tokens_out or 0)),
            "cost_usd": max(0.0, float(cost_usd or 0.0)),
            "reason": str(reason or ""),
            "recorded_at": recorded_at,
            "synced": False,
            "synced_at": None,
            "idempotency_key": idempotency_key,
        }

        try:
            with self._path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError as exc:
            raise RuntimeError(f"Failed to write offline ledger: {exc}") from exc

        return entry

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get_pending(self) -> List[Dict[str, Any]]:
        """Return all entries that have not yet been synced.

        Returns:
            List of entry dicts sorted ascending by ``recorded_at``.
            Returns an empty list when the ledger file does not exist.
        """
        if not self._path.exists():
            return []
        entries: List[Dict[str, Any]] = []
        try:
            with self._path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if not entry.get("synced", False):
                        entries.append(entry)
        except OSError:
            return []
        entries.sort(key=lambda e: float(e.get("recorded_at") or 0.0))
        return entries

    # ------------------------------------------------------------------
    # Mark synced
    # ------------------------------------------------------------------

    def mark_synced(self, entry_ids: List[str]) -> int:
        """Rewrite the ledger file marking the given entry IDs as synced.

        This is an atomic read-modify-write over the entire file.  The
        operation is O(n) but the ledger is expected to be small (hundreds
        of entries at most between syncs).

        Args:
            entry_ids: List of ``entry_id`` strings to mark as synced.

        Returns:
            Number of entries actually updated.
        """
        if not entry_ids or not self._path.exists():
            return 0

        id_set = set(entry_ids)
        updated = 0
        synced_at = time.time()
        new_lines: List[str] = []

        try:
            with self._path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    stripped = line.strip()
                    if not stripped:
                        new_lines.append("")
                        continue
                    try:
                        entry = json.loads(stripped)
                    except json.JSONDecodeError:
                        new_lines.append(stripped)
                        continue
                    if entry.get("entry_id") in id_set and not entry.get("synced", False):
                        entry["synced"] = True
                        entry["synced_at"] = synced_at
                        updated += 1
                    new_lines.append(json.dumps(entry, ensure_ascii=False))
        except OSError:
            return 0

        try:
            tmp_path = self._path.with_suffix(".jsonl.tmp")
            with tmp_path.open("w", encoding="utf-8") as fh:
                for line in new_lines:
                    fh.write(line + "\n")
            tmp_path.replace(self._path)
        except OSError:
            return 0

        return updated

    # ------------------------------------------------------------------
    # Sync to server
    # ------------------------------------------------------------------

    async def sync_to_server(self, client: Any) -> Dict[str, Any]:
        """POST pending entries to ``POST /api/usage/sync-offline`` and mark synced.

        Args:
            client: An ``MSaplingClient`` instance with a working HTTP connection.

        Returns:
            Server response dict with keys ``accepted``, ``rejected``, ``total_cost``,
            augmented with ``local_sent`` (number of entries submitted) and
            ``local_marked_synced`` (number marked synced in the local file).
            Returns a zero-count dict when there is nothing to sync.
        """
        pending = self.get_pending()
        if not pending:
            return {
                "accepted": 0,
                "rejected": 0,
                "total_cost": 0.0,
                "local_sent": 0,
                "local_marked_synced": 0,
            }

        try:
            http_client = await client._get_client()
            # Use the CSRF-safe POST path
            resp = await client._request_with_csrf_retry(
                lambda: http_client.post(
                    "/api/usage/sync-offline",
                    json={"entries": pending},
                )
            )
            resp.raise_for_status()
            server_result: Dict[str, Any] = resp.json() if resp.content else {}
        except Exception as exc:
            return {
                "accepted": 0,
                "rejected": 0,
                "total_cost": 0.0,
                "local_sent": len(pending),
                "local_marked_synced": 0,
                "error": str(exc),
            }

        # Mark the entries that the server accepted as synced
        accepted_ids: List[str] = server_result.get("accepted_ids") or [
            e["entry_id"] for e in pending
        ]
        marked = self.mark_synced(accepted_ids)

        return {
            **server_result,
            "local_sent": len(pending),
            "local_marked_synced": marked,
        }
