"""Session persistence for MSapling CLI.

Saves and resumes conversation history, project context, and settings
so users can pick up where they left off.

Rich metadata (SessionMetadata) is stored under the ``"metadata"`` key in every
session JSON file.  Old sessions that lack this key load without error — all
fields default to empty/zero values via ``SessionMetadata.from_dict({})``).
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

_SESSION_DIR = Path.home() / ".msapling" / "sessions"


@dataclass
class SessionMetadata:
    """Rich per-session metadata recorded during and at the end of a session.

    All fields have safe defaults so that ``from_dict({})`` always succeeds —
    old session files that lack a ``"metadata"`` key load transparently.

    Attributes
    ----------
    session_id:
        Unique identifier for this session (matches the top-level ``id`` field).
    project_name:
        The MSapling project the session was run under, or ``None`` when the
        project is not yet known (e.g. the user quit during project selection).
    models_used:
        Deduplicated, ordered list of every model ID that was active at least
        once during the session.  The initial model is always the first entry.
    files_touched:
        Paths of files read, written, or edited via explicit slash commands
        (``/read``, ``/write``, ``/edit``) or extracted from message content.
        Deduplicated; relative-path strings preserved as the user typed them.
    slash_commands_used:
        Every slash command that was dispatched during the session, in order.
        Duplicates are kept so the caller can compute frequency if desired.
    total_cost_usd:
        Accumulated cost in USD estimated from token usage.  This may differ
        slightly from ``cost_total`` (which uses the raw server-reported cost)
        because this field uses the per-model rate table in ``_save()``.
    total_tokens_in:
        Estimated input (prompt) tokens consumed during the session.
        Currently approximated as 60 % of ``tokens_total`` (no per-call
        split from the server yet; will be exact once the API exposes it).
    total_tokens_out:
        Estimated output (completion) tokens produced during the session.
        Currently approximated as 40 % of ``tokens_total``.
    started_at:
        ISO-8601 UTC timestamp of when the shell was instantiated.
    ended_at:
        ISO-8601 UTC timestamp of when ``_save()`` was called, or ``None``
        if the session was not cleanly saved.
    duration_seconds:
        Wall-clock seconds from shell instantiation to ``_save()``, or
        ``None`` if unavailable.
    turn_count:
        Number of user-submitted prompts (non-slash-command messages) sent
        to the LLM during the session.  Each call to ``_chat()`` increments
        this counter by 1.
    summary:
        Optional one-line human-readable summary of the session.  Currently
        auto-generated from the last user message; will be replaced by an
        LLM-generated summary in a future release.
    """

    session_id: str = ""
    project_name: Optional[str] = None
    models_used: List[str] = field(default_factory=list)
    files_touched: List[str] = field(default_factory=list)
    slash_commands_used: List[str] = field(default_factory=list)
    total_cost_usd: float = 0.0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    started_at: str = ""
    ended_at: Optional[str] = None
    duration_seconds: Optional[float] = None
    turn_count: int = 0
    summary: Optional[str] = None

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain JSON-compatible dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SessionMetadata":
        """Deserialise from a dict, tolerating missing or extra keys.

        Missing keys fall back to the dataclass field defaults so that old
        session files (which store only a subset of keys) load without error.
        """
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)


def _ensure_dir():
    _SESSION_DIR.mkdir(parents=True, exist_ok=True)
    try:
        _SESSION_DIR.chmod(0o700)
    except OSError:
        pass  # Windows doesn't support Unix permissions


def _sorted_session_files() -> List[Path]:
    """Return session JSON files sorted by mtime descending."""
    _ensure_dir()
    files = list(_SESSION_DIR.glob("*.json"))
    return sorted(
        files,
        key=lambda p: p.stat().st_mtime if p.exists() else 0.0,
        reverse=True,
    )


def save_session(
    session_id: str,
    messages: List[Dict[str, str]],
    model: str,
    project_root: Optional[str] = None,
    cost_total: float = 0.0,
    tokens_total: int = 0,
    metadata: Optional[Any] = None,
) -> Path:
    """Persist a session to ``~/.msapling/sessions/<session_id>.json``.

    Parameters
    ----------
    metadata:
        Either a :class:`SessionMetadata` instance (preferred) or a plain
        ``dict`` (backward-compatible).  ``None`` results in an empty dict
        being stored, which loads correctly on resume.
    """
    _ensure_dir()
    path = _SESSION_DIR / f"{session_id}.json"

    # Normalise metadata to a plain dict.
    if isinstance(metadata, SessionMetadata):
        meta_dict: Dict[str, Any] = metadata.to_dict()
    elif isinstance(metadata, dict):
        meta_dict = metadata
    else:
        meta_dict = {}

    data = {
        "_schema_version": _CURRENT_SCHEMA_VERSION,
        "id": session_id,
        "messages": messages,
        "model": model,
        "project_root": project_root,
        "cost_total": cost_total,
        "tokens_total": tokens_total,
        "updated_at": time.time(),
        "metadata": meta_dict,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions
    return path


# Schema version history:
#   1 — original (messages, model, project_root, cost_total, tokens_total)
#   2 — adds rich SessionMetadata (models_used, files_touched, slash_commands_used,
#         turn_count, total_cost_usd, total_tokens_in, total_tokens_out,
#         started_at, ended_at, duration_seconds, summary)
_CURRENT_SCHEMA_VERSION = 2

import logging as _logging
_session_log = _logging.getLogger(__name__)


def load_session(session_id: str) -> Optional[Dict[str, Any]]:
    _ensure_dir()
    path = _SESSION_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        loaded_version = data.get("_schema_version", 0)
        if loaded_version > _CURRENT_SCHEMA_VERSION:
            _session_log.warning(
                "Session %s has schema_version=%d but current is %d; "
                "some fields may be unrecognised.",
                session_id, loaded_version, _CURRENT_SCHEMA_VERSION,
            )
        return data
    except Exception:
        return None


def list_sessions(limit: int = 20) -> List[Dict[str, Any]]:
    """Return a list of saved sessions, newest first.

    Each entry is the full session dict enriched with two synthetic keys:

    * ``_path`` — absolute path to the ``.json`` file.
    * ``_summary`` — a one-line human-readable summary
      (``"N msgs | <last user message snippet>"``).

    When the session contains a :class:`SessionMetadata` payload under the
    ``"metadata"`` key the caller may access fields such as
    ``data["metadata"]["project_name"]``, ``data["metadata"]["total_cost_usd"]``
    and ``data["metadata"]["duration_seconds"]`` directly.
    """
    _ensure_dir()
    sessions = []
    for p in _sorted_session_files():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            data["_path"] = str(p)
            msg_count = len(data.get("messages", []))
            last_msg = ""
            for m in reversed(data.get("messages", [])):
                if m.get("role") == "user":
                    last_msg = (m.get("content", "") or "")[:80]
                    break
            data["_summary"] = f"{msg_count} msgs | {last_msg}"
            # Ensure metadata is always a dict (tolerates missing key).
            if "metadata" not in data or not isinstance(data["metadata"], dict):
                data["metadata"] = {}
            sessions.append(data)
        except Exception:
            continue
        if len(sessions) >= limit:
            break
    return sessions


def cleanup_sessions(
    max_sessions: Optional[int] = None,
    max_age_days: Optional[int] = None,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Prune old session files by count and/or age.

    Parameters
    ----------
    max_sessions:
        Keep at most this many most-recent session files.
    max_age_days:
        Delete sessions older than this many days.
    dry_run:
        When True, report what would be deleted without writing.
    """
    if max_sessions is None and max_age_days is None:
        raise ValueError("At least one retention constraint is required.")
    if max_sessions is not None and max_sessions < 1:
        raise ValueError("max_sessions must be >= 1")
    if max_age_days is not None and max_age_days < 1:
        raise ValueError("max_age_days must be >= 1")

    files = _sorted_session_files()
    now = time.time()
    age_cutoff = (
        now - (max_age_days * 24 * 60 * 60)
        if max_age_days is not None
        else None
    )

    planned: List[Dict[str, Any]] = []
    for idx, path in enumerate(files):
        reasons: List[str] = []
        if max_sessions is not None and idx >= max_sessions:
            reasons.append("count")
        if age_cutoff is not None:
            try:
                if path.stat().st_mtime < age_cutoff:
                    reasons.append("age")
            except OSError:
                reasons.append("age")
        if reasons:
            planned.append(
                {
                    "id": path.stem,
                    "path": str(path),
                    "reasons": reasons,
                }
            )

    removed: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    if dry_run:
        removed = list(planned)
    else:
        for item in planned:
            path = Path(item["path"])
            try:
                path.chmod(0o666)  # Ensure writable before delete (Windows compat)
            except OSError:
                pass
            try:
                path.unlink()
                removed.append(item)
            except FileNotFoundError:
                # Treat as already removed.
                removed.append(item)
            except Exception as exc:
                errors.append(
                    {
                        "id": item["id"],
                        "path": item["path"],
                        "error": str(exc),
                        "reasons": item["reasons"],
                    }
                )

    total_before = len(files)
    removed_count = len(removed)
    if dry_run:
        remaining_count = max(total_before - removed_count, 0)
    else:
        remaining_count = max(total_before - removed_count, 0) + len(errors)

    return {
        "dry_run": dry_run,
        "max_sessions": max_sessions,
        "max_age_days": max_age_days,
        "total_before": total_before,
        "planned_remove_count": len(planned),
        "removed_count": removed_count,
        "remaining_count": remaining_count,
        "removed_session_ids": [r["id"] for r in removed],
        "removed_paths": [r["path"] for r in removed],
        "planned": planned,
        "errors": errors,
        "error_count": len(errors),
    }


def delete_session(session_id: str) -> bool:
    path = _SESSION_DIR / f"{session_id}.json"
    if not path.exists():
        return False
    try:
        path.chmod(0o666)  # Ensure writable before delete (Windows compat)
    except OSError:
        pass
    for _ in range(5):
        try:
            path.unlink()
            return True
        except PermissionError:
            time.sleep(0.05)
        except FileNotFoundError:
            return True
    return False
