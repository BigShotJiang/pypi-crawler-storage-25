"""Tab completion for MSapling interactive shell.

Provides:
- Slash command completion: typing "/" then Tab shows matching commands
- File path completion: after /read, /edit, /write, /mention, /image, Tab completes
  file paths relative to the project root
- Model completion: after /model, Tab shows available model IDs

Uses Python's readline module on Linux/Mac. On Windows, attempts to use
pyreadline3; if unavailable, completion is silently disabled.
"""
from __future__ import annotations

import glob as globmod
import os
from pathlib import Path
from typing import List, Optional, Sequence


class AmbiguousModelError(ValueError):
    """Raised when a model query matches multiple candidates."""

    def __init__(self, query: str, candidates: List[str]):
        self.query = query
        self.candidates = candidates
        super().__init__(f"Ambiguous model '{query}'")


# ---------------------------------------------------------------------------
# All known slash commands (extracted from shell.py SLASH_HELP + handlers)
# ---------------------------------------------------------------------------
SLASH_COMMANDS: List[str] = [
    "/help",
    "/clear",
    "/compact",
    "/context",
    "/save",
    "/resume",
    "/sessions",
    "/fork",
    "/rewind",
    "/quit",
    "/exit",
    "/q",
    "/model",
    "/models",
    "/shadow",
    "/filter",
    "/plan",
    "/agent",
    "/simple",
    "/vim",
    "/fast",
    "/effort",
    "/files",
    "/read",
    "/write",
    "/edit",
    "/grep",
    "/mention",
    "/attach",
    "/image",
    "/run",
    "/git",
    "/diff",
    "/status",
    "/multi",
    "/swarm",
    "/project",
    "/init",
    "/whoami",
    "/cost",
    "/hooks",
    "/memory",
    "/mdrive",
    "/workers",
    "/join",
    "/broadcast",
    "/collect",
    "/kill",
    "/budget",
    "/copy",
    "/export",
    "/restore",
    "/permissions",
    "/sandbox",
    "/worktree",
    "/undo",
    "/checkpoint",
    "/rollback",
    "/commit",
    "/branch",
    "/pr",
    "/history",
    "/theme",
    "/keys",
    "/test",
    "/review",
    "/feedback",
    "/bug",
    "/doctor",
    "/paste",
    "/windows",
    "/pr-review",
]

# Commands after which Tab should complete file paths
FILE_PATH_COMMANDS = {"/read", "/edit", "/write", "/mention", "/attach", "/image"}

# Directories to skip during file path completion
_SKIP_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", "dist", "build", ".mypy_cache", ".pytest_cache"}

# Well-known model IDs for offline completion (supplemented at runtime)
DEFAULT_MODELS: List[str] = [
    "google/gemini-2.0-flash-001",
    "google/gemini-pro-1.5",
    "google/gemini-2.0-flash",
    "anthropic/claude-3-haiku",
    "anthropic/claude-3-sonnet",
    "anthropic/claude-3-opus",
    "anthropic/claude-3.5-sonnet",
    "openai/gpt-4o",
    "openai/gpt-4o-mini",
    "openai/gpt-4-turbo",
    "openai/o1-mini",
    "openai/o1-preview",
    "meta-llama/llama-3-70b-instruct",
    "meta-llama/llama-3-8b-instruct",
    "mistralai/mistral-large",
    "mistralai/mistral-small",
    "qwen/qwen-2-72b-instruct",
]


class MSaplingCompleter:
    """Readline-compatible completer for the MSapling interactive shell."""

    def __init__(
        self,
        commands: Optional[Sequence[str]] = None,
        project_root: str = ".",
        models: Optional[Sequence[str]] = None,
    ):
        self.commands = sorted(commands or SLASH_COMMANDS)
        self.project_root = os.path.abspath(project_root)
        self.models = sorted(set(models or DEFAULT_MODELS))
        self._matches: List[str] = []

    def set_models(self, models: Sequence[str]) -> None:
        """Update the model list (e.g. after fetching from the server)."""
        self.models = sorted(set(list(models) + DEFAULT_MODELS))

    # ------------------------------------------------------------------
    # Core readline interface
    # ------------------------------------------------------------------

    def complete(self, text: str, state: int) -> Optional[str]:
        """Called by readline for each successive completion.

        *text* is the current word being completed (the portion after the
        last whitespace). *state* counts up from 0; return None to signal
        end of matches.
        """
        if state == 0:
            # Compute matches fresh for state == 0
            try:
                line = _get_line_buffer()
            except Exception:
                line = text
            # If line buffer is empty (readline not fully wired), use text
            if not line:
                line = text

            self._matches = self._compute_matches(text, line)

        if state < len(self._matches):
            return self._matches[state]
        return None

    # ------------------------------------------------------------------
    # Match computation
    # ------------------------------------------------------------------

    def _compute_matches(self, text: str, full_line: str) -> List[str]:
        """Decide which completions to offer based on context."""
        stripped = full_line.lstrip()

        # ── Case 0: @file mention anywhere in prompt ────────────────
        if "@" in text and not text.startswith("/"):
            at_idx = text.rfind("@")
            if at_idx >= 0:
                partial = text[at_idx + 1:]
                paths = self._complete_path(partial)
                return ["@" + p for p in paths]

        # ── Case 1: completing a slash command name ──────────────────
        if stripped.startswith("/") and " " not in stripped:
            return [cmd + " " for cmd in self.commands if cmd.startswith(stripped)]

        # ── Case 2: completing arguments to a command ────────────────
        parts = stripped.split(None, 1)
        if len(parts) >= 1:
            cmd = parts[0].lower()

            # File path completion
            if cmd in FILE_PATH_COMMANDS:
                partial = parts[1] if len(parts) > 1 else ""
                return self._complete_path(partial)

            # Model completion - match full ID or suffix after /
            if cmd == "/model":
                partial = (parts[1] if len(parts) > 1 else "").lower()
                return [m + " " for m in self.models
                        if m.lower().startswith(partial) or m.split("/", 1)[-1].lower().startswith(partial)]

            # /effort level completion
            if cmd == "/effort":
                partial = parts[1] if len(parts) > 1 else ""
                levels = ["low", "medium", "high"]
                return [lv + " " for lv in levels if lv.startswith(partial)]

            # /hooks subcommand completion
            if cmd == "/hooks":
                partial = parts[1] if len(parts) > 1 else ""
                hook_subs = ["add", "remove", "clear"]
                return [s + " " for s in hook_subs if s.startswith(partial)]

            # /mdrive subcommand completion
            if cmd == "/mdrive":
                partial = parts[1] if len(parts) > 1 else ""
                mdrive_subs = ["status", "ls", "push", "pull"]
                return [s + " " for s in mdrive_subs if s.startswith(partial)]

            # /memory subcommand completion
            if cmd == "/memory":
                partial = parts[1] if len(parts) > 1 else ""
                mem_subs = ["add", "clear"]
                return [s + " " for s in mem_subs if s.startswith(partial)]

        return []

    # ------------------------------------------------------------------
    # File path completion
    # ------------------------------------------------------------------

    def _complete_path(self, partial: str) -> List[str]:
        """Complete a file path relative to the project root.

        Returns paths with a trailing '/' for directories so the user can
        keep drilling down without pressing Tab again.
        """
        partial = partial.replace("\\", "/")

        # Block path traversal and absolute paths
        if ".." in partial or partial.startswith("/"):
            return []

        # Pre-filter: don't glob into expensive directories
        partial_parts = partial.split("/")
        if any(p in _SKIP_DIRS for p in partial_parts):
            return []

        abs_prefix = os.path.join(self.project_root, partial)
        # Verify resolved path stays within project root using Path.resolve() +
        # relative_to() to prevent bypass via symlinks or redundant '.' components
        # that can fool a simple startswith() check on Windows paths.
        try:
            resolved = Path(abs_prefix).resolve()
            root_resolved = Path(self.project_root).resolve()
            resolved.relative_to(root_resolved)  # raises ValueError if outside root
        except ValueError:
            return []
        except Exception:
            return []

        try:
            raw = globmod.glob(abs_prefix + "*")
        except Exception:
            return []

        matches: List[str] = []
        for full_path in sorted(raw)[:30]:  # Reduced from 60 for responsiveness
            rel = os.path.relpath(full_path, self.project_root).replace("\\", "/")

            # Skip hidden / noisy directories
            parts = rel.split("/")
            if any(p in _SKIP_DIRS for p in parts):
                continue

            if os.path.isdir(full_path):
                matches.append(rel + "/")
            else:
                matches.append(rel + " ")

        return matches


# ======================================================================
# Module-level setup function (called from shell.py)
# ======================================================================

_rl = None  # Will hold the readline module if available


def _get_line_buffer() -> str:
    """Return the current readline line buffer, or empty string."""
    if _rl is not None:
        try:
            return _rl.get_line_buffer()
        except Exception:
            pass
    return ""


def setup_completion(
    project_root: str = ".",
    commands: Optional[Sequence[str]] = None,
    models: Optional[Sequence[str]] = None,
) -> Optional[MSaplingCompleter]:
    """Configure readline tab completion for the interactive shell.

    Returns the MSaplingCompleter instance (so the caller can later call
    ``completer.set_models(...)``), or ``None`` if readline is not available.

    Safe to call on any platform -- silently does nothing on Windows if
    neither readline nor pyreadline3 is installed.
    """
    global _rl

    # Try to import readline (works on Linux/Mac; may exist on Windows with pyreadline3)
    try:
        import readline as rl
        _rl = rl
    except (ImportError, AttributeError, TypeError):
        try:
            # pyreadline3 is a Windows drop-in replacement
            import pyreadline3 as rl  # type: ignore[import-untyped]
            _rl = rl
        except (ImportError, AttributeError, TypeError, Exception):
            # No readline available -- tab completion disabled silently
            return None

    completer = MSaplingCompleter(
        commands=commands,
        project_root=project_root,
        models=models,
    )

    _rl.set_completer(completer.complete)

    # Set the word delimiters. We want "/" to NOT be a delimiter so that
    # "/mod" is treated as one word (not split at "/").
    _rl.set_completer_delims(" \t\n;")

    # Enable tab completion binding.
    # On Mac with libedit, the syntax is different.
    try:
        if "libedit" in (_rl.__doc__ or ""):
            _rl.parse_and_bind("bind ^I rl_complete")
        else:
            _rl.parse_and_bind("tab: complete")
    except Exception:
        # Last resort -- try both and ignore errors
        try:
            _rl.parse_and_bind("tab: complete")
        except Exception:
            pass

    return completer


# ======================================================================
# Fuzzy model resolver
# ======================================================================

# Common model aliases — user-friendly names → OpenRouter IDs
MODEL_ALIASES: dict[str, str] = {
    # Gemini
    "gemini": "google/gemini-2.0-flash-001",
    "gemini flash": "google/gemini-2.0-flash-001",
    "gemini 2.0 flash": "google/gemini-2.0-flash-001",
    "gemini 2 flash": "google/gemini-2.0-flash-001",
    "gemini 2.5 flash": "google/gemini-2.5-flash-preview-05-20",
    "gemini flash 1.5": "google/gemini-2.0-flash-001",
    "gemini 1.5 flash": "google/gemini-2.0-flash-001",
    "gemini pro": "google/gemini-2.0-pro-exp-02-05",
    "gemini 2.0 pro": "google/gemini-2.0-pro-exp-02-05",
    "gemini 1.5 pro": "google/gemini-pro-1.5",
    # Claude — cover common user patterns
    "claude": "anthropic/claude-sonnet-4",
    "claude sonnet": "anthropic/claude-sonnet-4",
    "claude 4 sonnet": "anthropic/claude-sonnet-4",
    "claude sonnet 4": "anthropic/claude-sonnet-4",
    "claude 3.5 sonnet": "anthropic/claude-3.5-sonnet",
    "claude haiku": "anthropic/claude-haiku-4.5",
    "claude 3 haiku": "anthropic/claude-3-haiku",
    "claude 3.5 haiku": "anthropic/claude-3.5-haiku",
    "claude 4 haiku": "anthropic/claude-haiku-4.5",
    "claude opus": "anthropic/claude-opus-4",
    "claude 3 opus": "anthropic/claude-3-opus",
    "claude 4 opus": "anthropic/claude-opus-4",
    "claude opus 4": "anthropic/claude-opus-4",
    "claude 3.5 opus": "anthropic/claude-opus-4",
    "sonnet": "anthropic/claude-sonnet-4",
    "opus": "anthropic/claude-opus-4",
    "haiku": "anthropic/claude-haiku-4.5",
    # GPT
    "gpt4": "openai/gpt-4o",
    "gpt 4": "openai/gpt-4o",
    "gpt4o": "openai/gpt-4o",
    "gpt 4o": "openai/gpt-4o",
    "gpt4 mini": "openai/gpt-4o-mini",
    "gpt 4o mini": "openai/gpt-4o-mini",
    "gpt mini": "openai/gpt-4o-mini",
    "o1": "openai/o1",
    "o1 mini": "openai/o1-mini",
    "o3 mini": "openai/o3-mini",
    # Llama
    "llama": "meta-llama/llama-3.1-70b-instruct",
    "llama 3": "meta-llama/llama-3.1-70b-instruct",
    "llama 3.1": "meta-llama/llama-3.1-70b-instruct",
    "llama 70b": "meta-llama/llama-3.1-70b-instruct",
    "llama 8b": "meta-llama/llama-3.1-8b-instruct",
    # Mistral
    "mistral": "mistralai/mistral-large",
    "mistral large": "mistralai/mistral-large",
    "mistral small": "mistralai/mistral-small",
    # DeepSeek
    "deepseek": "deepseek/deepseek-chat",
    "deepseek coder": "deepseek/deepseek-coder",
    # Qwen
    "qwen": "qwen/qwen-2.5-72b-instruct",
}


def _clean_model_input(user_input: str) -> str:
    text = str(user_input or "").strip().strip('"').strip("'")
    lowered = text.lower()
    for suffix in ("(free)", "(pro)"):
        if lowered.endswith(suffix):
            text = text[: -len(suffix)].rstrip()
            lowered = text.lower()
    return text



def _normalize_model_key(value: str) -> str:
    cleaned = _clean_model_input(value).lower().replace("/", " ")
    chars = []
    for ch in cleaned:
        chars.append(ch if ch.isalnum() else " ")
    return " ".join("".join(chars).split())



def _model_token_signature(value: str) -> tuple[str, ...]:
    tokens = _normalize_model_key(value).split()
    return tuple(sorted(tokens))



def _unique_preserve_order(values: List[str]) -> List[str]:
    seen = set()
    out: List[str] = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            out.append(value)
    return out



def _all_model_candidates(available_models: Optional[List[str]] = None) -> List[str]:
    merged: List[str] = []
    if available_models:
        merged.extend(m for m in available_models if m)
    merged.extend(DEFAULT_MODELS)
    merged.extend(MODEL_ALIASES.values())
    return _unique_preserve_order(merged)



def _strict_model_match(user_input: str, candidates: List[str]) -> tuple[Optional[str], List[str]]:
    cleaned = _clean_model_input(user_input)
    lowered = cleaned.lower()
    norm = _normalize_model_key(cleaned)
    sig = _model_token_signature(cleaned)

    exact = [mid for mid in candidates if lowered == mid.lower()]
    if len(exact) == 1:
        return exact[0], exact

    suffix_matches = [mid for mid in candidates if lowered == mid.split("/", 1)[-1].lower()]
    suffix_matches = _unique_preserve_order(suffix_matches)
    if len(suffix_matches) == 1:
        return suffix_matches[0], suffix_matches
    if len(suffix_matches) > 1:
        return None, suffix_matches

    normalized = []
    signature = []
    token_subset = []
    substring = []
    query_tokens = set(norm.split())
    for mid in candidates:
        suffix = mid.split("/", 1)[-1]
        mid_norm = _normalize_model_key(mid)
        suffix_norm = _normalize_model_key(suffix)
        if norm and norm in (mid_norm, suffix_norm):
            normalized.append(mid)
        if sig and sig == _model_token_signature(suffix):
            signature.append(mid)
        if query_tokens:
            candidate_tokens = set(suffix_norm.split())
            if query_tokens.issubset(candidate_tokens):
                token_subset.append(mid)
        if norm and (norm in mid_norm or norm in suffix_norm):
            substring.append(mid)

    for matches in (normalized, signature, token_subset, substring):
        uniq = _unique_preserve_order(matches)
        if len(uniq) == 1:
            return uniq[0], uniq
        if len(uniq) > 1:
            return None, uniq

    return None, []



def validate_model_choice(user_input: str, available_models: Optional[List[str]] = None) -> tuple[str, bool]:
    cleaned = _clean_model_input(user_input)
    if not cleaned:
        return "google/gemini-2.0-flash-001", True

    alias_key = _normalize_model_key(cleaned)
    candidates = _all_model_candidates(available_models)

    # Check aliases FIRST — they are curated and should take priority
    # over fuzzy matches against potentially unroutable catalog IDs
    alias_matches = [
        model_id
        for alias, model_id in MODEL_ALIASES.items()
        if alias_key == _normalize_model_key(alias) and (not available_models or model_id in candidates)
    ]
    alias_matches = _unique_preserve_order(alias_matches)
    if len(alias_matches) == 1:
        return alias_matches[0], True

    # Then try strict catalog match
    strict_match, strict_matches = _strict_model_match(cleaned, candidates)
    if strict_match:
        return strict_match, strict_match.lower() != cleaned.lower()

    if len(alias_matches) > 1:
        strict_matches = alias_matches

    if strict_matches:
        raise AmbiguousModelError(cleaned, strict_matches[:10])

    raise ValueError(f"Unknown model '{cleaned}'. Use /models to inspect exact available IDs.")



def resolve_model(user_input: str, available_models: Optional[List[str]] = None) -> tuple[str, bool]:
    """Resolve a fuzzy model name to an exact OpenRouter model ID.

    Returns:
        (model_id, was_fuzzy) - the resolved ID and whether fuzzy matching was used.
    """
    cleaned = _clean_model_input(user_input)
    if not cleaned:
        return "google/gemini-2.0-flash-001", True

    candidates = _all_model_candidates(available_models)
    alias_key = _normalize_model_key(cleaned)
    for alias, model_id in MODEL_ALIASES.items():
        if alias_key == _normalize_model_key(alias):
            return model_id, True

    strict_match, strict_matches = _strict_model_match(cleaned, candidates)
    if strict_match:
        return strict_match, strict_match.lower() != cleaned.lower()

    user_words = alias_key.split()
    best_alias = None
    best_score = 0
    for alias, model_id in MODEL_ALIASES.items():
        alias_words = _normalize_model_key(alias).split()
        matches = sum(1 for word in user_words if any(word in alias_word for alias_word in alias_words))
        if matches > best_score:
            best_score = matches
            best_alias = model_id
    if best_alias and best_score >= max(1, len(user_words)):
        return best_alias, True

    if strict_matches:
        return cleaned, False

    return cleaned, False

