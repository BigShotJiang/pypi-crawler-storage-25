"""Persistent memory for MSapling CLI.

Auto-memory that survives across sessions — like Claude Code's memory system.
Stores user preferences, project notes, and learned patterns.

Memory is stored per-project at .msapling/memory.json
Global memory at ~/.msapling/memory.json
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List, Optional


_GLOBAL_MEMORY_FILE = Path.home() / ".msapling" / "memory.json"


def _project_memory_file(project_root: str) -> Path:
    return Path(project_root) / ".msapling" / "memory.json"


def _load(path: Path) -> List[Dict]:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save(path: Path, entries: List[Dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def add_memory(text: str, *, project_root: Optional[str] = None, scope: str = "project") -> str:
    """Add a memory entry. Returns confirmation."""
    path = _project_memory_file(project_root) if project_root and scope == "project" else _GLOBAL_MEMORY_FILE
    entries = _load(path)
    entry = {
        "text": text.strip(),
        "created_at": time.time(),
        "scope": scope,
    }
    entries.append(entry)
    # Cap at 100 entries — warn on truncation
    if len(entries) > 100:
        dropped = len(entries) - 100
        entries = entries[-100:]
        import sys
        print(f"Note: Memory capped at 100 entries ({dropped} oldest removed).", file=sys.stderr)
    _save(path, entries)
    return f"Saved ({scope}): {text[:80]}"


def _sanitize_memory_text(text: str) -> str:
    """Sanitize memory text for safe LLM context injection."""
    # Collapse newlines to prevent multi-line prompt injection
    sanitized = str(text).replace("\n", " ").replace("\r", " ").strip()
    # Truncate individual entries
    return sanitized[:500] if len(sanitized) > 500 else sanitized


def get_memories(project_root: Optional[str] = None) -> str:
    """Get all memories as a formatted string for LLM context injection."""
    parts = []

    # Global memories
    global_entries = _load(_GLOBAL_MEMORY_FILE)
    if global_entries:
        global_text = "\n".join(f"- {_sanitize_memory_text(e['text'])}" for e in global_entries[-20:])
        parts.append(f"[Global memories]\n{global_text}")

    # Project memories
    if project_root:
        proj_entries = _load(_project_memory_file(project_root))
        if proj_entries:
            proj_text = "\n".join(f"- {_sanitize_memory_text(e['text'])}" for e in proj_entries[-20:])
            parts.append(f"[Project memories]\n{proj_text}")

    return "\n\n".join(parts)


def list_memories(project_root: Optional[str] = None) -> List[Dict]:
    """List all memories with metadata."""
    results = []
    for entry in _load(_GLOBAL_MEMORY_FILE):
        entry["_scope"] = "global"
        results.append(entry)
    if project_root:
        for entry in _load(_project_memory_file(project_root)):
            entry["_scope"] = "project"
            results.append(entry)
    return results


def clear_memories(project_root: Optional[str] = None, scope: str = "all"):
    """Clear memories."""
    if scope in ("all", "global"):
        _save(_GLOBAL_MEMORY_FILE, [])
    if scope in ("all", "project") and project_root:
        _save(_project_memory_file(project_root), [])
