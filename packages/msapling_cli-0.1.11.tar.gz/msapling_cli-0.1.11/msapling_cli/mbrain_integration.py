"""MBrain Session Search Integration for MSapling CLI.

Syncs CLI session history to the MBrain knowledge base so past decisions and
code patterns are searchable from new chats.

Usage::

    from msapling_cli.mbrain_integration import MBrainSessionSync

    sync = MBrainSessionSync(base_url="https://app.msapling.com", token="<jwt>")
    sync.sync_session(session_dict)                       # fire-and-forget
    results = sync.search_sessions("async/await pattern") # remote search
    ctx = sync.get_session_context("last time I used Redis")  # inject block
"""
from __future__ import annotations

import asyncio
import logging
import re
import threading
import time
from typing import Any, Dict, List, Optional

import urllib.request
import urllib.parse
import urllib.error
import json as _json

_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Temporal/recall trigger phrases that warrant context injection
# ---------------------------------------------------------------------------

_RECALL_PATTERNS: List[re.Pattern] = [
    re.compile(r"\b(last time|previously|earlier|before|remember when|in a previous session)\b", re.I),
    re.compile(r"\b(you (told|said|mentioned|suggested)|we decided|we agreed|we talked about)\b", re.I),
    re.compile(r"\b(session [a-zA-Z0-9_-]+|from session)\b", re.I),
    re.compile(r"\b(as (before|discussed|mentioned|noted))\b", re.I),
]


def _has_recall_trigger(text: str) -> bool:
    """Return True if *text* contains any recall/reference phrase."""
    return any(p.search(text) for p in _RECALL_PATTERNS)


# ---------------------------------------------------------------------------
# HTTP helper (stdlib-only, no requests dependency)
# ---------------------------------------------------------------------------

def _http_get(url: str, token: str, timeout: int = 10) -> Optional[Dict[str, Any]]:
    """Perform a GET request and return parsed JSON or None on error."""
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        _log.debug("MBrain GET %s → HTTP %d", url, exc.code)
    except Exception as exc:
        _log.debug("MBrain GET %s failed: %s", url, exc)
    return None


def _http_post(url: str, token: str, payload: Dict[str, Any], timeout: int = 10) -> Optional[Dict[str, Any]]:
    """Perform a POST request with JSON body and return parsed JSON or None on error."""
    data = _json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        _log.debug("MBrain POST %s → HTTP %d", url, exc.code)
    except Exception as exc:
        _log.debug("MBrain POST %s failed: %s", url, exc)
    return None


# ---------------------------------------------------------------------------
# MBrainSessionSync
# ---------------------------------------------------------------------------

class MBrainSessionSync:
    """Sync CLI session data to MBrain and retrieve session-aware context.

    Parameters
    ----------
    base_url:
        Root URL of the MSapling backend, e.g. ``https://app.msapling.com``.
        Must NOT have a trailing slash.
    token:
        JWT bearer token for the authenticated user.
    knowledge_endpoint:
        Override the knowledge/add endpoint path.  Defaults to
        ``/api/mbrain/entries`` with ``/api/knowledge/add`` as fallback.
    search_endpoint:
        Override the search endpoint path.
    """

    _KNOWLEDGE_PATHS = ["/api/mbrain/entries", "/api/knowledge/add"]
    _SEARCH_PATH = "/api/mbrain/search"

    def __init__(
        self,
        base_url: str,
        token: str,
        knowledge_endpoint: Optional[str] = None,
        search_endpoint: Optional[str] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._knowledge_endpoint = knowledge_endpoint
        self._search_endpoint = search_endpoint or self._SEARCH_PATH

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def format_session_entry(self, session: Dict[str, Any]) -> Dict[str, Any]:
        """Convert a CLI session dict to a MBrain entry payload.

        The returned dict is ready to POST to the knowledge endpoint.

        Parameters
        ----------
        session:
            Full session dict as returned by :func:`session.load_session` or
            :func:`session.list_sessions`.  Must contain at least ``"id"``.
        """
        meta: Dict[str, Any] = session.get("metadata") or {}
        session_id: str = session.get("id") or meta.get("session_id") or ""
        project: str = meta.get("project_name") or session.get("project_root") or ""
        models: List[str] = meta.get("models_used") or []
        if session.get("model") and session["model"] not in models:
            models.append(session["model"])
        summary: str = meta.get("summary") or ""
        started_at: str = meta.get("started_at") or ""
        ended_at: str = meta.get("ended_at") or ""
        cost_usd: float = float(meta.get("total_cost_usd") or session.get("cost_total") or 0.0)
        turn_count: int = int(meta.get("turn_count") or 0)
        files: List[str] = meta.get("files_touched") or []
        commands: List[str] = meta.get("slash_commands_used") or []

        # Build a rich text content block that BM25/semantic search can index.
        msg_snippets: List[str] = []
        for msg in (session.get("messages") or [])[:30]:  # cap at 30 msgs for size
            role = msg.get("role", "")
            raw = msg.get("content") or ""
            text = raw if isinstance(raw, str) else " ".join(
                b.get("text", "") for b in raw if isinstance(b, dict)
            )
            if text.strip():
                msg_snippets.append(f"[{role}] {text[:200]}")

        content_parts = []
        if summary:
            content_parts.append(f"Summary: {summary}")
        if project:
            content_parts.append(f"Project: {project}")
        if models:
            content_parts.append(f"Models used: {', '.join(models)}")
        if files:
            content_parts.append(f"Files touched: {', '.join(files[:10])}")
        if commands:
            content_parts.append(f"Commands: {', '.join(commands[:10])}")
        if msg_snippets:
            content_parts.append("Messages:\n" + "\n".join(msg_snippets))

        content = "\n".join(content_parts)

        # Title: prefer summary, fall back to last user message or session_id.
        title = summary or session_id[:40]

        tags = ["cli_session"]
        if project:
            tags.append(f"project:{project}")
        for model in models:
            safe = model.replace("/", "_")
            tags.append(f"model:{safe}")

        return {
            "title": title,
            "content": content,
            "tags": tags,
            "source": "cli_session",
            "source_id": session_id,
            "metadata": {
                "session_id": session_id,
                "project": project,
                "models": models,
                "cost_usd": cost_usd,
                "turn_count": turn_count,
                "started_at": started_at,
                "ended_at": ended_at,
                "files_touched": files,
            },
        }

    def sync_session(self, session: Dict[str, Any]) -> None:
        """POST *session* summary to MBrain.  Runs in a background thread.

        The call is non-blocking.  If the network is unavailable the error is
        silently logged — this must never interrupt the CLI session.

        Parameters
        ----------
        session:
            Full session dict as returned by :func:`session.load_session`.
        """
        # Skip trivially empty sessions (no messages or no session id).
        if not session.get("id") and not (session.get("metadata") or {}).get("session_id"):
            return
        if not (session.get("messages") or []):
            return

        entry = self.format_session_entry(session)
        thread = threading.Thread(
            target=self._post_entry,
            args=(entry,),
            name="mbrain-sync",
            daemon=True,
        )
        thread.start()

    def search_sessions(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Search past sessions via MBrain remote search.

        Parameters
        ----------
        query:
            Free-text search query.
        limit:
            Maximum number of results to return (1–20).

        Returns
        -------
        list of dict
            Each dict contains ``session_id``, ``title``, ``project``,
            ``score``, ``snippet``, and ``metadata``.
        """
        limit = max(1, min(20, limit))
        params = urllib.parse.urlencode({"q": query, "type": "session", "limit": limit})
        url = f"{self.base_url}{self._search_endpoint}?{params}"
        data = _http_get(url, self.token)
        if data is None:
            return []
        # Support both {"results": [...]} and {"entries": [...]} response shapes.
        items: List[Dict[str, Any]] = (
            data.get("results")
            or data.get("entries")
            or (data if isinstance(data, list) else [])
        )
        # Normalise each item to a consistent schema.
        out: List[Dict[str, Any]] = []
        for item in items[:limit]:
            if not isinstance(item, dict):
                continue
            meta_raw = item.get("metadata") or {}
            out.append({
                "session_id": (
                    item.get("source_id")
                    or meta_raw.get("session_id")
                    or item.get("id", "")
                ),
                "title": item.get("title") or item.get("name", ""),
                "project": meta_raw.get("project") or item.get("project", ""),
                "score": float(item.get("score") or item.get("relevance") or 0.0),
                "snippet": item.get("snippet") or item.get("content", "")[:200],
                "metadata": meta_raw,
            })
        return out

    def get_session_context(self, query: str) -> str:
        """Return a formatted context block for injection into a new chat prompt.

        Calls :meth:`search_sessions` and formats the results as a compact
        "From past sessions" citation block.  Returns an empty string if no
        results are found or the backend is unavailable.

        Parameters
        ----------
        query:
            The user's message / query to search against past sessions.
        """
        results = self.search_sessions(query, limit=3)
        if not results:
            return ""

        lines = ["[From past sessions — for reference only]"]
        for i, r in enumerate(results, 1):
            title = r.get("title") or r.get("session_id", "unknown")
            project = r.get("project", "")
            snippet = (r.get("snippet") or "").strip().replace("\n", " ")
            if len(snippet) > 300:
                snippet = snippet[:297] + "..."
            citation = f"[Session {i}: {title}"
            if project:
                citation += f" (project: {project})"
            citation += "]"
            lines.append(citation)
            if snippet:
                lines.append(f"  {snippet}")
        lines.append("[End past sessions]")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post_entry(self, entry: Dict[str, Any]) -> None:
        """Attempt to POST entry to the knowledge endpoint.  Tries both paths."""
        endpoints = (
            [self._knowledge_endpoint]
            if self._knowledge_endpoint
            else self._KNOWLEDGE_PATHS
        )
        for path in endpoints:
            url = f"{self.base_url}{path}"
            result = _http_post(url, self.token, entry)
            if result is not None:
                _log.debug("MBrain sync OK → %s (id=%s)", url, result.get("id", "?"))
                return
        _log.debug("MBrain sync failed for session %s (all endpoints tried)", entry.get("source_id", "?"))


# ---------------------------------------------------------------------------
# Convenience: check if a prompt needs recall injection
# ---------------------------------------------------------------------------

def should_inject_context(prompt: str) -> bool:
    """Return True when *prompt* contains recall/reference trigger phrases.

    Used by the shell to decide whether to call
    :meth:`MBrainSessionSync.get_session_context` before sending to the LLM.
    """
    return _has_recall_trigger(prompt)


# ---------------------------------------------------------------------------
# Module-level singleton factory
# ---------------------------------------------------------------------------

def build_sync_from_config() -> Optional[MBrainSessionSync]:
    """Build a :class:`MBrainSessionSync` from the CLI config, or return None.

    Returns None when no auth token or base URL is available (so callers never
    crash when MBrain is not configured).
    """
    try:
        from .config import get_settings, get_token
        settings = get_settings()
        token = get_token()
        if not token:
            return None
        base_url: str = (
            getattr(settings, "api_url", None)
            or "https://app.msapling.com"
        )
        return MBrainSessionSync(base_url=base_url, token=token)
    except Exception as exc:
        _log.debug("build_sync_from_config failed: %s", exc)
        return None
