"""Non-interactive agent session for MSapling CLI.

Enables automated CI/CD pipelines, script-based code edits, and scheduled
tasks by running a single prompt against the MSapling API without launching
an interactive shell.

Exit codes:
    0 — success
    1 — API / general error
    2 — authentication error
    3 — quota exceeded (402 / 429)
"""
from __future__ import annotations

import asyncio
import json as _json
import os
import sys
from pathlib import Path
from typing import Optional

from .api import APIError, MSaplingClient, OfflineError
from .config import get_settings, get_token


# ──────────────────────────────────────────────────────────────────────────
# Exit code constants
# ──────────────────────────────────────────────────────────────────────────

EXIT_SUCCESS = 0
EXIT_API_ERROR = 1
EXIT_AUTH_ERROR = 2
EXIT_QUOTA_EXCEEDED = 3


# ──────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────

def _resolve_prompt(
    prompt_arg: Optional[str],
    file: Optional[Path],
    use_stdin: bool,
    extra_stdin: Optional[str] = None,
) -> str:
    """Return the effective prompt string from argument, --file, or stdin.

    Resolution order:
    1. ``--file`` path (reads file contents, optionally appended with stdin)
    2. ``prompt_arg`` positional argument (optionally appended with stdin)
    3. Stdin (when ``use_stdin`` is True or stdin is not a TTY)
    """
    if file is not None:
        base = file.read_text(encoding="utf-8").strip()
        if extra_stdin:
            return f"{base}\n\n{extra_stdin.strip()}"
        return base

    if prompt_arg:
        if extra_stdin:
            return f"{prompt_arg.strip()}\n\n{extra_stdin.strip()}"
        return prompt_arg.strip()

    if use_stdin or not sys.stdin.isatty():
        data = extra_stdin if extra_stdin is not None else sys.stdin.read()
        return data.strip()

    return ""


def _classify_http_error(status_code: int) -> int:
    """Map HTTP status to CLI exit code."""
    if status_code in (401, 403):
        return EXIT_AUTH_ERROR
    if status_code in (402, 429):
        return EXIT_QUOTA_EXCEEDED
    return EXIT_API_ERROR


def _emit_json(obj: dict) -> None:
    """Write a JSON object to stdout followed by a newline (no Rich markup)."""
    sys.stdout.write(_json.dumps(obj) + "\n")
    sys.stdout.flush()


def _emit_text(text: str) -> None:
    sys.stdout.write(text)
    sys.stdout.flush()


def _resolve_noninteractive_model(explicit_model: Optional[str], default_model: Optional[str]) -> str:
    """Resolve the model for headless runs with safe fallback behavior.

    If the user explicitly passes ``--model`` we always honor it.
    When ``--model`` is omitted and the configured default is a local Ollama model,
    fall back to a cloud-safe default unless Ollama was explicitly selected via env.
    """
    resolved = str(explicit_model or default_model or "").strip()
    if not resolved:
        return "google/gemini-2.0-flash-001"

    if explicit_model is None and resolved.lower().startswith("ollama/"):
        provider_env = str(os.getenv("MSAPLING_PROVIDER", "") or "").strip().lower()
        ollama_url_env = str(os.getenv("MSAPLING_OLLAMA_URL", "") or "").strip()
        if provider_env != "ollama" and not ollama_url_env:
            return "google/gemini-2.0-flash-001"

    return resolved


# ──────────────────────────────────────────────────────────────────────────
# Core async runner
# ──────────────────────────────────────────────────────────────────────────

async def run_noninteractive(
    *,
    prompt: str,
    model: Optional[str] = None,
    project: Optional[str] = None,
    max_tokens: Optional[int] = None,
    json_output: bool = False,
    stream: bool = False,
    timeout: float = 120.0,
) -> int:
    """Execute a single prompt against the MSapling API without an interactive shell.

    Returns an exit code (0, 1, 2, or 3).
    """
    settings = get_settings()
    model_id = _resolve_noninteractive_model(model, settings.default_model)
    token = get_token()

    if not token:
        if json_output:
            _emit_json({"error": "Not authenticated. Run: msapling login", "exit_code": EXIT_AUTH_ERROR})
        else:
            sys.stderr.write("Not authenticated. Run: msapling login\n")
        return EXIT_AUTH_ERROR

    client = MSaplingClient()
    chat_id: Optional[str] = None
    try:
        async with asyncio.timeout(timeout):
            # Resolve project — use CLI Utility project when no project is given
            if project:
                chat_id = await client.ensure_server_chat(
                    project_name=project,
                    title="Agent Run",
                    model=model_id,
                    client_type="cli-run",
                )
            else:
                chat_id = await client.ensure_utility_chat(model=model_id)

            # Clear stale stream locks from prior crashed/aborted runs.
            if chat_id and hasattr(client, "force_release_lock"):
                try:
                    await client.force_release_lock(chat_id)
                except Exception:
                    pass

            parts: list[str] = []
            usage_data: dict = {}

            if stream:
                # Streaming: emit each content token immediately to stdout
                async for chunk in client.stream_chat(
                    chat_id=chat_id,
                    prompt=prompt,
                    model=model_id,
                    project_name=project,
                    history_enabled=False,
                ):
                    content = chunk.get("content", "")
                    if content:
                        parts.append(content)
                        if json_output:
                            _emit_json({"type": "content", "text": content})
                        else:
                            _emit_text(content)
                    if chunk.get("type") == "usage":
                        usage_data = chunk
                    if chunk.get("type") == "error":
                        err = chunk.get("error", "Stream error")
                        if json_output:
                            _emit_json({"type": "error", "error": err})
                        else:
                            sys.stderr.write(f"Stream error: {err}\n")

                # Emit final summary for JSON mode
                if json_output:
                    tokens = usage_data.get("usage", {}).get("total_tokens", 0)
                    cost = usage_data.get("cost", 0.0)
                    _emit_json({
                        "type": "done",
                        "model": model_id,
                        "tokens": tokens,
                        "cost_usd": float(cost),
                    })
            else:
                # Non-streaming: collect full response, then emit
                async for chunk in client.stream_chat(
                    chat_id=chat_id,
                    prompt=prompt,
                    model=model_id,
                    project_name=project,
                    history_enabled=False,
                ):
                    content = chunk.get("content", "")
                    if content:
                        parts.append(content)
                    if chunk.get("type") == "usage":
                        usage_data = chunk

                response = "".join(parts)
                tokens = usage_data.get("usage", {}).get("total_tokens", 0)
                cost = usage_data.get("cost", 0.0)

                if json_output:
                    _emit_json({
                        "response": response,
                        "model": model_id,
                        "tokens": tokens,
                        "cost_usd": float(cost),
                    })
                else:
                    _emit_text(response)
                    if response and not response.endswith("\n"):
                        _emit_text("\n")

        return EXIT_SUCCESS

    except asyncio.TimeoutError:
        msg = f"Request timed out after {timeout:.0f}s"
        if json_output:
            _emit_json({"error": msg, "exit_code": EXIT_API_ERROR})
        else:
            sys.stderr.write(f"{msg}\n")
        return EXIT_API_ERROR

    except APIError as exc:
        code = _classify_http_error(exc.status_code)
        msg = str(exc)
        if json_output:
            _emit_json({"error": msg, "exit_code": code})
        else:
            sys.stderr.write(f"API error: {msg}\n")
        return code

    except OfflineError as exc:
        msg = str(exc)
        if json_output:
            _emit_json({"error": msg, "exit_code": EXIT_API_ERROR})
        else:
            sys.stderr.write(f"Connection error: {msg}\n")
        return EXIT_API_ERROR

    except Exception as exc:
        # Inspect status_code attribute for HTTP exceptions from httpx
        status_code = getattr(exc, "status_code", 0)
        if status_code == 0 and hasattr(exc, "response"):
            status_code = getattr(exc.response, "status_code", 0)
        code = _classify_http_error(status_code) if status_code else EXIT_API_ERROR
        msg = str(exc)
        if json_output:
            _emit_json({"error": msg, "exit_code": code})
        else:
            sys.stderr.write(f"Error: {msg}\n")
        return code

    finally:
        # Best-effort cleanup to prevent lock leakage between scripted runs.
        if chat_id and hasattr(client, "force_release_lock"):
            try:
                await client.force_release_lock(chat_id)
            except Exception:
                pass
        await client.close()
