"""CLI commands for managing workspace context profile persistence.

Commands:
    msapling profile show [--project PROJECT_ID]
    msapling profile set <profile_name> [--project PROJECT_ID]
    msapling profile clear [--project PROJECT_ID]
    msapling profile list
"""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from .profile_persistence import (
    VALID_PROFILES,
    clear_profile,
    list_profiles,
    load_profile,
    save_profile,
)

profile_app = typer.Typer(help="Manage workspace context profiles per project.")
console = Console()

_ALL_VALID = sorted(VALID_PROFILES) + ["auto"]


def _resolve_project(project: Optional[str]) -> str:
    """Return the effective project ID (from option or config)."""
    if project:
        return project
    # Try to read the active project from settings
    try:
        from .config import get_settings
        settings = get_settings()
        pid = getattr(settings, "current_project", None) or getattr(settings, "project", None)
        if pid:
            return str(pid)
    except Exception:
        pass
    return "default"


@profile_app.command("show")
def profile_show(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project ID"),
) -> None:
    """Show the current context profile for a project (or 'auto' if not set)."""
    pid = _resolve_project(project)
    saved = load_profile(pid)
    if saved:
        console.print(f"[bold]{pid}[/bold]: [green]{saved}[/green]")
    else:
        console.print(f"[bold]{pid}[/bold]: [dim]auto[/dim] (profile not set — will detect from messages)")


@profile_app.command("set")
def profile_set(
    profile_name: str = typer.Argument(..., help=f"Profile name: {', '.join(sorted(VALID_PROFILES))}, auto"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project ID"),
) -> None:
    """Set (persist) a context profile for a project.

    Use 'auto' to clear the saved profile and revert to auto-detection.
    """
    pid = _resolve_project(project)

    if profile_name == "auto":
        clear_profile(pid)
        console.print(f"[bold]{pid}[/bold]: reset to [dim]auto[/dim]-detect")
        return

    if profile_name not in VALID_PROFILES:
        console.print(
            f"[red]Invalid profile '{profile_name}'. "
            f"Valid values: {', '.join(sorted(VALID_PROFILES))}, auto[/red]"
        )
        raise typer.Exit(code=1)

    save_profile(pid, profile_name)
    console.print(f"[bold]{pid}[/bold]: profile set to [green]{profile_name}[/green]")


@profile_app.command("clear")
def profile_clear(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project ID"),
) -> None:
    """Clear the saved profile for a project (revert to auto-detect)."""
    pid = _resolve_project(project)
    clear_profile(pid)
    console.print(f"[bold]{pid}[/bold]: profile cleared (auto-detect will run next session)")


@profile_app.command("list")
def profile_list() -> None:
    """List all projects with a saved context profile."""
    profiles = list_profiles()
    if not profiles:
        console.print("[dim]No profiles saved yet.[/dim]")
        return

    table = Table(title="Saved Context Profiles", show_header=True, header_style="bold")
    table.add_column("Project ID", style="cyan")
    table.add_column("Profile", style="green")
    for pid, pname in sorted(profiles.items()):
        table.add_row(pid, pname)
    console.print(table)
