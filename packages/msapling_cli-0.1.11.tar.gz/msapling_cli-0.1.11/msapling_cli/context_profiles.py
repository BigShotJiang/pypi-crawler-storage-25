"""Context profile system: pre-load relevant context for different task types."""
import json
from pathlib import Path
from typing import Dict, List, Optional

BUILTIN_PROFILES: Dict[str, Dict] = {
    "backend": {
        "description": "FastAPI backend development",
        "files": ["backend/main.py", "backend/database.py", "CLAUDE.md"],
        "system_suffix": "You are working on a FastAPI Python backend.",
    },
    "frontend": {
        "description": "React TypeScript frontend development",
        "files": ["frontend/src/pages/MainApp.tsx", "frontend/src/api.ts"],
        "system_suffix": "You are working on a React TypeScript frontend.",
    },
    "cli": {
        "description": "CLI tool development",
        "files": ["cli/msapling_cli/shell.py", "cli/msapling_cli/agent.py"],
        "system_suffix": "You are working on a Python CLI tool.",
    },
}

_PROFILES_DIR = Path.home() / ".msapling" / "context_profiles"


def load_profile(name: str, workspace: Path) -> Optional[Dict]:
    """Load a context profile by name.

    Checks built-in profiles first, then user-saved profiles in
    ``~/.msapling/context_profiles/<name>.json``.

    Returns a dict with keys ``description``, ``files``, ``system_suffix``,
    and ``context`` (pre-loaded file contents), or None if not found.
    """
    profile: Optional[Dict] = None

    # Check built-in profiles first
    if name in BUILTIN_PROFILES:
        profile = dict(BUILTIN_PROFILES[name])
    else:
        # Check user-saved profiles
        profile_path = _PROFILES_DIR / f"{name}.json"
        if profile_path.exists():
            try:
                profile = json.loads(profile_path.read_text(encoding="utf-8"))
            except Exception:
                return None

    if profile is None:
        return None

    # Pre-load file contents from workspace
    file_contexts: List[str] = []
    for rel_path in profile.get("files", []):
        abs_path = workspace / rel_path
        if abs_path.is_file():
            try:
                content = abs_path.read_text(encoding="utf-8", errors="ignore")[:4000]
                file_contexts.append(f"[{rel_path}]\n{content}")
            except Exception:
                pass

    profile["context"] = "\n\n".join(file_contexts)
    return profile


def save_profile(name: str, description: str, files: List[str], system_suffix: str) -> Path:
    """Save a user-defined context profile to ``~/.msapling/context_profiles/<name>.json``."""
    _PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    profile_data = {
        "description": description,
        "files": files,
        "system_suffix": system_suffix,
    }
    profile_path = _PROFILES_DIR / f"{name}.json"
    profile_path.write_text(json.dumps(profile_data, indent=2), encoding="utf-8")
    return profile_path


def list_profiles() -> List[str]:
    """Return the names of all available profiles (built-in + user-saved)."""
    names: List[str] = list(BUILTIN_PROFILES.keys())
    if _PROFILES_DIR.exists():
        for p in sorted(_PROFILES_DIR.glob("*.json")):
            user_name = p.stem
            if user_name not in names:
                names.append(user_name)
    return names
