"""Session pattern extractor — runs at session end to find learnable patterns."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List


PATTERN_SIGNATURES: Dict[str, Any] = {
    "frequent_file_edit": lambda msgs: sum(
        1 for m in msgs if '"edit_file"' in m.get("content", "")
    ) > 3,
    "error_recovery": lambda msgs: any(
        "error" in m.get("content", "").lower()
        and "fixed" in m.get("content", "").lower()
        for m in msgs
    ),
    "refactor_session": lambda msgs: any(
        "refactor" in m.get("content", "").lower() for m in msgs
    ),
}


def extract_patterns(history: List[Dict[str, Any]]) -> List[str]:
    """Return the names of all patterns that match the session history."""
    return [name for name, check in PATTERN_SIGNATURES.items() if check(history)]


def save_patterns(patterns: List[str], session_id: str) -> Path:
    """Append pattern results to ~/.msapling/session_patterns.jsonl.

    Returns the path that was written to.
    """
    out_dir = Path.home() / ".msapling"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / "session_patterns.jsonl"
    record = {"session": session_id, "patterns": patterns}
    with open(out, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return out


def run(session_id: str, history_path: str) -> int:
    """Load history from *history_path*, extract patterns, write results.

    Returns 0 on success, 1 on error (safe for shell use).
    """
    try:
        raw = Path(history_path).read_text(encoding="utf-8")
        history: List[Dict[str, Any]] = json.loads(raw)
        if not isinstance(history, list):
            history = []
    except (OSError, json.JSONDecodeError) as exc:
        print(f"session_patterns: could not read history: {exc}", flush=True)
        return 1

    patterns = extract_patterns(history)
    dest = save_patterns(patterns, session_id)
    if patterns:
        print(f"session_patterns: saved {patterns} → {dest}", flush=True)
    else:
        print(f"session_patterns: no patterns detected → {dest}", flush=True)
    return 0


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("Usage: session_patterns.py <session_id> <history_json_path>")
        sys.exit(1)
    sys.exit(run(sys.argv[1], sys.argv[2]))
