"""Export formats for MSapling CLI session export.

Supports exporting a session dict to Markdown, self-contained HTML, and PDF.

Session dict shape (from session.py / shell state):
    {
        "id": str,
        "messages": [{"role": str, "content": str}, ...],
        "model": str,
        "project_root": Optional[str],
        "cost_total": float,
        "tokens_total": int,
        "updated_at": float,
        "metadata": {
            "project_name": Optional[str],
            "models_used": List[str],
            "total_cost_usd": float,
            "total_tokens_in": int,
            "total_tokens_out": int,
            "started_at": str,
            "ended_at": Optional[str],
            "duration_seconds": Optional[float],
            "turn_count": int,
            "summary": Optional[str],
        },
    }
"""
from __future__ import annotations

import html as _html_module
import json
import re
import textwrap
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _session_metadata(session: dict) -> dict:
    """Return the metadata sub-dict, tolerating missing/None values."""
    meta = session.get("metadata") or {}
    if not isinstance(meta, dict):
        meta = {}
    return meta


def _session_messages(session: dict) -> List[Dict[str, str]]:
    """Return non-system messages from the session."""
    msgs = session.get("messages") or []
    return [m for m in msgs if isinstance(m, dict) and m.get("role") != "system"]


def _session_date(session: dict) -> str:
    meta = _session_metadata(session)
    started = meta.get("started_at") or ""
    if started:
        try:
            return started[:10]  # ISO date portion
        except Exception:
            pass
    ts = session.get("updated_at")
    if ts:
        try:
            return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d")
        except Exception:
            pass
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")


def _session_cost(session: dict) -> float:
    meta = _session_metadata(session)
    # Prefer rich metadata cost, fall back to top-level cost_total
    cost = meta.get("total_cost_usd")
    if cost is None:
        cost = session.get("cost_total", 0.0)
    try:
        return float(cost)
    except (TypeError, ValueError):
        return 0.0


def _session_duration(session: dict) -> Optional[float]:
    meta = _session_metadata(session)
    dur = meta.get("duration_seconds")
    if dur is not None:
        try:
            return float(dur)
        except (TypeError, ValueError):
            pass
    return None


def _session_project(session: dict) -> str:
    meta = _session_metadata(session)
    proj = meta.get("project_name") or session.get("project_root") or ""
    if proj:
        return str(Path(proj).name) if "/" in proj or "\\" in proj else proj
    return "unknown"


def _session_models(session: dict) -> List[str]:
    meta = _session_metadata(session)
    models = meta.get("models_used") or []
    if not models:
        model = session.get("model") or ""
        if model:
            models = [model]
    return models


def _format_duration(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        m, s = divmod(int(seconds), 60)
        return f"{m}m {s}s"
    else:
        h, rem = divmod(int(seconds), 3600)
        m, s = divmod(rem, 60)
        return f"{h}h {m}m"


def _extract_code_blocks(content: str) -> List[tuple]:
    """Return list of (start, end, lang, code) tuples for fenced code blocks."""
    pattern = re.compile(r"```(\w*)\n(.*?)```", re.DOTALL)
    results = []
    for m in pattern.finditer(content):
        results.append((m.start(), m.end(), m.group(1), m.group(2)))
    return results


def _detect_topics(messages: List[Dict[str, str]]) -> str:
    """Very lightweight topic detection from first few user messages."""
    user_texts = [
        m.get("content", "")[:200]
        for m in messages
        if m.get("role") == "user"
    ][:3]
    if not user_texts:
        return "general topics"
    combined = " ".join(user_texts)
    # Extract the first ~80 chars as the topic snippet
    snippet = combined[:80].strip()
    if len(combined) > 80:
        snippet += "..."
    return snippet


# ---------------------------------------------------------------------------
# Public: auto_generate_summary
# ---------------------------------------------------------------------------

def auto_generate_summary(session: dict) -> str:
    """Generate a 2-sentence human-readable summary of the session.

    Returns a string like:
        "Session on 2026-04-17 covered explain my code. 8 messages exchanged
        with claude-3-5-sonnet, costing $0.0032."
    """
    date = _session_date(session)
    messages = _session_messages(session)
    n = len(messages)
    cost = _session_cost(session)
    models = _session_models(session)
    model_str = models[0] if models else "unknown model"
    topics = _detect_topics(messages)

    sentence1 = f"Session on {date} covered {topics}."
    sentence2 = f"{n} message{'s' if n != 1 else ''} exchanged with {model_str}, costing ${cost:.4f}."
    return f"{sentence1} {sentence2}"


# ---------------------------------------------------------------------------
# Public: export_markdown
# ---------------------------------------------------------------------------

def export_markdown(session: dict, output_path: Path) -> Path:
    """Export session as a Markdown document.

    Parameters
    ----------
    session:
        Session dict (from load_session or shell state).
    output_path:
        Target .md file path. Parent directories are created if needed.

    Returns
    -------
    Path
        Absolute path to the written file.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    meta = _session_metadata(session)
    sid = session.get("id") or session.get("session_id") or "unknown"
    project = _session_project(session)
    models = _session_models(session)
    cost = _session_cost(session)
    date = _session_date(session)
    duration = _session_duration(session)
    messages = _session_messages(session)
    turn_count = meta.get("turn_count") or len([m for m in messages if m.get("role") == "user"])

    lines: List[str] = []

    # Header
    lines.append(f"# MSapling Session Export\n")
    lines.append(f"**Session ID:** `{sid}`  ")
    lines.append(f"**Date:** {date}  ")
    lines.append(f"**Project:** {project}  ")
    lines.append(f"**Model(s):** {', '.join(models) or 'unknown'}  ")
    lines.append(f"**Cost:** ${cost:.4f}  ")
    if duration is not None:
        lines.append(f"**Duration:** {_format_duration(duration)}  ")
    lines.append(f"**Turns:** {turn_count}  ")
    lines.append("")
    lines.append("---\n")

    # Summary
    summary = meta.get("summary") or auto_generate_summary(session)
    lines.append(f"> {summary}\n")
    lines.append("")

    # Messages
    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        if role == "user":
            lines.append("## **User**\n")
        elif role == "assistant":
            lines.append("## **Assistant**\n")
        else:
            lines.append(f"## **{role.title()}**\n")
        lines.append(content)
        lines.append("\n---\n")

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path.resolve()


# ---------------------------------------------------------------------------
# Public: export_html
# ---------------------------------------------------------------------------

_HTML_CSS = """
:root {
  --bg: #0d1117;
  --bg-card: #161b22;
  --bg-user: #1a2332;
  --bg-assistant: #161b22;
  --border: #30363d;
  --text: #e6edf3;
  --text-dim: #8b949e;
  --text-link: #58a6ff;
  --accent: #238636;
  --accent-user: #1f6feb;
  --code-bg: #0d1117;
  --code-text: #c9d1d9;
  --tag-bg: #21262d;
  --tag-text: #79c0ff;
  --cost: #3fb950;
  --radius: 8px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  background: var(--bg);
  color: var(--text);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 15px;
  line-height: 1.6;
  min-height: 100vh;
  padding: 24px 16px 64px;
}

.session-container {
  max-width: 860px;
  margin: 0 auto;
}

/* ── Header ── */
.session-header {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px 24px;
  margin-bottom: 28px;
}

.session-header h1 {
  font-size: 1.4rem;
  font-weight: 700;
  color: var(--text);
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 10px;
}

.session-header h1 .badge {
  font-size: 0.75rem;
  font-weight: 500;
  background: var(--tag-bg);
  color: var(--tag-text);
  padding: 2px 8px;
  border-radius: 12px;
  font-family: monospace;
}

.meta-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
  margin-top: 16px;
}

.meta-item {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.meta-label {
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-dim);
  font-weight: 600;
}

.meta-value {
  font-size: 0.9rem;
  color: var(--text);
  font-weight: 500;
}

.meta-value.cost { color: var(--cost); }
.meta-value.model { color: var(--tag-text); font-family: monospace; font-size: 0.83rem; }

/* ── Summary ── */
.session-summary {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-left: 3px solid var(--accent);
  border-radius: var(--radius);
  padding: 14px 18px;
  margin-bottom: 24px;
  color: var(--text-dim);
  font-style: italic;
  font-size: 0.92rem;
}

/* ── Messages ── */
.messages {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message {
  max-width: 88%;
  border-radius: var(--radius);
  padding: 14px 18px;
  position: relative;
  border: 1px solid var(--border);
}

.message.user {
  background: var(--bg-user);
  border-color: #1f6feb55;
  align-self: flex-end;
  border-bottom-right-radius: 2px;
}

.message.assistant {
  background: var(--bg-assistant);
  align-self: flex-start;
  border-bottom-left-radius: 2px;
}

.message-role {
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-bottom: 8px;
}

.message.user .message-role { color: #58a6ff; }
.message.assistant .message-role { color: #3fb950; }

.message-content {
  white-space: pre-wrap;
  word-break: break-word;
  line-height: 1.65;
}

/* ── Code blocks ── */
pre {
  background: var(--code-bg);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 14px 16px;
  overflow-x: auto;
  margin: 10px 0;
  font-size: 0.84rem;
}

code {
  font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
  color: var(--code-text);
}

pre code {
  background: none;
  padding: 0;
  border: none;
  font-size: inherit;
}

p code, li code {
  background: var(--tag-bg);
  color: var(--tag-text);
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 0.87em;
}

/* ── Thinking blocks (CSS :target trick — no JS) ── */
.thinking-wrapper {
  margin: 10px 0;
}

.thinking-toggle {
  display: inline-block;
  font-size: 0.8rem;
  color: var(--text-dim);
  border: 1px dashed var(--border);
  border-radius: 4px;
  padding: 3px 10px;
  cursor: pointer;
  text-decoration: none;
  user-select: none;
}

.thinking-toggle:hover { color: var(--text); border-color: var(--text-dim); }

.thinking-content {
  display: none;
  background: #0a0d12;
  border: 1px dashed var(--border);
  border-radius: 4px;
  padding: 10px 14px;
  margin-top: 6px;
  font-size: 0.83rem;
  color: var(--text-dim);
  white-space: pre-wrap;
  word-break: break-word;
}

.thinking-content:target {
  display: block;
}

/* ── Syntax highlight classes (no JS) ── */
.kw   { color: #ff7b72; }  /* keywords */
.str  { color: #a5d6ff; }  /* strings */
.cmt  { color: #8b949e; font-style: italic; }  /* comments */
.num  { color: #79c0ff; }  /* numbers */
.fn   { color: #d2a8ff; }  /* function names */
.cls  { color: #ffa657; }  /* class names */
.op   { color: #ff7b72; }  /* operators */
.punc { color: #e6edf3; }  /* punctuation */

/* ── Footer ── */
.export-footer {
  text-align: center;
  margin-top: 40px;
  padding-top: 20px;
  border-top: 1px solid var(--border);
  font-size: 0.78rem;
  color: var(--text-dim);
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

@media (max-width: 600px) {
  .message { max-width: 98%; }
  .meta-grid { grid-template-columns: 1fr 1fr; }
}

@media print {
  body { background: #fff; color: #000; }
  .message.user { background: #e8f0fe; border-color: #aac4f7; }
  .message.assistant { background: #f6f8fa; }
  pre { background: #f6f8fa; }
}
"""


def _content_to_html(content: str) -> str:
    """Convert plain message content to HTML with code block and inline code support."""
    # Split on fenced code blocks first
    parts = re.split(r"(```(?:\w+)?\n.*?```)", content, flags=re.DOTALL)
    html_parts: List[str] = []

    for i, part in enumerate(parts):
        if part.startswith("```"):
            # Extract language and code
            m = re.match(r"```(\w*)\n(.*?)```", part, re.DOTALL)
            if m:
                lang = _html_module.escape(m.group(1)) if m.group(1) else ""
                code = _html_module.escape(m.group(2))
                lang_class = f' class="lang-{lang}"' if lang else ""
                html_parts.append(f'<pre><code{lang_class}>{code}</code></pre>')
            else:
                html_parts.append(f'<pre><code>{_html_module.escape(part)}</code></pre>')
        else:
            # Handle inline code `...`
            escaped = _html_module.escape(part)
            # Replace inline code
            escaped = re.sub(
                r"`([^`\n]+?)`",
                lambda m2: f'<code>{_html_module.escape(m2.group(1))}</code>',
                escaped,
            )
            # Preserve line breaks
            html_parts.append(escaped.replace("\n", "<br>"))

    return "".join(html_parts)


def export_html(session: dict, output_path: Path) -> Path:
    """Export session as a self-contained HTML document with dark theme.

    The output file has no external dependencies (no CDN links, no JS includes).
    All CSS is inlined in a <style> tag.

    Parameters
    ----------
    session:
        Session dict.
    output_path:
        Target .html file path. Parent directories are created if needed.

    Returns
    -------
    Path
        Absolute path to the written file.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    meta = _session_metadata(session)
    sid = session.get("id") or session.get("session_id") or "unknown"
    project = _session_project(session)
    models = _session_models(session)
    cost = _session_cost(session)
    date = _session_date(session)
    duration = _session_duration(session)
    messages = _session_messages(session)
    turn_count = meta.get("turn_count") or len([m for m in messages if m.get("role") == "user"])
    summary = meta.get("summary") or auto_generate_summary(session)
    tokens_in = meta.get("total_tokens_in") or 0
    tokens_out = meta.get("total_tokens_out") or 0

    # ── Build metadata section ──
    duration_html = ""
    if duration is not None:
        duration_html = f"""
          <div class="meta-item">
            <span class="meta-label">Duration</span>
            <span class="meta-value">{_html_module.escape(_format_duration(duration))}</span>
          </div>"""

    tokens_html = ""
    if tokens_in or tokens_out:
        tokens_html = f"""
          <div class="meta-item">
            <span class="meta-label">Tokens In / Out</span>
            <span class="meta-value">{tokens_in:,} / {tokens_out:,}</span>
          </div>"""

    model_items_html = ""
    for mdl in models:
        model_items_html += f"""
          <div class="meta-item">
            <span class="meta-label">Model</span>
            <span class="meta-value model">{_html_module.escape(mdl)}</span>
          </div>"""

    # ── Build message bubbles ──
    thinking_counter = 0
    messages_html_parts: List[str] = []

    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        if role not in ("user", "assistant"):
            continue

        role_label = "You" if role == "user" else "Assistant"
        content_html = _content_to_html(content)

        # Detect thinking blocks enclosed in <thinking>...</thinking>
        def replace_thinking(m3: re.Match) -> str:
            nonlocal thinking_counter
            thinking_counter += 1
            tid = f"thinking-{thinking_counter}"
            inner = _html_module.escape(m3.group(1))
            return (
                f'<div class="thinking-wrapper">'
                f'<a class="thinking-toggle" href="#{tid}">&#128161; Show thinking</a>'
                f'<div class="thinking-content" id="{tid}">{inner}</div>'
                f'</div>'
            )

        content_html = re.sub(
            r"&lt;thinking&gt;(.*?)&lt;/thinking&gt;",
            replace_thinking,
            content_html,
            flags=re.DOTALL,
        )

        messages_html_parts.append(f"""
        <div class="message {_html_module.escape(role)}">
          <div class="message-role">{_html_module.escape(role_label)}</div>
          <div class="message-content">{content_html}</div>
        </div>""")

    messages_html = "\n".join(messages_html_parts)

    export_ts = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MSapling Session — {_html_module.escape(sid)}</title>
  <style>
{_HTML_CSS}
  </style>
</head>
<body>
  <div class="session-container">

    <header class="session-header">
      <h1>
        MSapling Session
        <span class="badge">{_html_module.escape(sid)}</span>
      </h1>
      <div class="meta-grid">
        <div class="meta-item">
          <span class="meta-label">Date</span>
          <span class="meta-value">{_html_module.escape(date)}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Project</span>
          <span class="meta-value">{_html_module.escape(project)}</span>
        </div>
        {model_items_html}
        <div class="meta-item">
          <span class="meta-label">Cost</span>
          <span class="meta-value cost">${cost:.4f}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Turns</span>
          <span class="meta-value">{turn_count}</span>
        </div>
        {duration_html}
        {tokens_html}
      </div>
    </header>

    <div class="session-summary">
      {_html_module.escape(summary)}
    </div>

    <div class="messages">
      {messages_html}
    </div>

    <footer class="export-footer">
      Exported by MSapling CLI &middot; {export_ts}
    </footer>

  </div>
</body>
</html>"""

    output_path.write_text(html, encoding="utf-8")
    return output_path.resolve()


# ---------------------------------------------------------------------------
# Public: export_pdf
# ---------------------------------------------------------------------------

def export_pdf(session: dict, output_path: Path) -> Path:
    """Export session as a PDF document.

    Attempts to use ``weasyprint`` if installed. If weasyprint is not available,
    falls back to exporting an HTML file with a note instructing the user to
    print the page as PDF from their browser.

    Parameters
    ----------
    session:
        Session dict.
    output_path:
        Target .pdf file path. Parent dirs are created if needed.
        For the weasyprint-absent fallback the extension is changed to .html.

    Returns
    -------
    Path
        Absolute path to the written file (.pdf if weasyprint available,
        .html fallback otherwise).
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import weasyprint  # type: ignore[import]

        # Render HTML in-memory, then convert to PDF
        html_path = output_path.with_suffix(".html")
        export_html(session, html_path)
        html_content = html_path.read_text(encoding="utf-8")
        weasyprint.HTML(string=html_content).write_pdf(str(output_path))
        # Clean up intermediate HTML
        try:
            html_path.unlink(missing_ok=True)
        except Exception:
            pass
        return output_path.resolve()

    except ImportError:
        # weasyprint not installed — fall back to HTML with print instructions
        html_path = output_path.with_suffix(".html")

        # Inject a print banner at the top of the HTML
        meta = _session_metadata(session)
        sid = session.get("id") or "unknown"
        banner_session: dict = dict(session)
        # We'll add a print note via a modified summary
        original_summary = meta.get("summary") or auto_generate_summary(session)
        banner_meta = dict(meta)
        banner_meta["summary"] = (
            original_summary
            + " [PDF export: weasyprint not installed. "
            "Open this HTML file in your browser and use File > Print > Save as PDF.]"
        )
        banner_session = dict(session)
        banner_session["metadata"] = banner_meta

        export_html(banner_session, html_path)
        return html_path.resolve()
