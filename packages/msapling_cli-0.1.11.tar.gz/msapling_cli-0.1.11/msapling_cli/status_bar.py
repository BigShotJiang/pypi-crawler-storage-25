"""MSapling StatusBar — sticky footer with rich.live background refresh.

Displays: [◆ model] | [ctx X% / NK] | [↑ tokens] | [💳 credits] | [● connection] | [📁 dir] | [env]

Usage:
    bar = StatusBar(shell)
    bar.start()          # begin background refresh (only in TTY / interactive)
    bar.update(tokens=1247, connected=True)
    bar.stop()           # clean up Live instance
"""
from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from rich.live import Live
from rich.text import Text

if TYPE_CHECKING:
    from .shell import InteractiveShell


# ── Connection state constants ────────────────────────────────────────────
CONN_CONNECTED = "connected"
CONN_DISCONNECTED = "disconnected"
CONN_CHECKING = "checking"


# ── Model context window sizes (tokens) ──────────────────────────────────
_MODEL_CONTEXT: dict[str, int] = {
    # Anthropic Claude
    "claude-3-5-sonnet": 200_000,
    "claude-3-5-haiku": 200_000,
    "claude-3-opus": 200_000,
    "claude-3-haiku": 200_000,
    "claude-sonnet-4": 200_000,
    "claude-opus-4": 200_000,
    "claude-haiku-4": 200_000,
    # OpenAI
    "gpt-4o": 128_000,
    "gpt-4o-mini": 128_000,
    "gpt-4-turbo": 128_000,
    "gpt-4": 8_192,
    "gpt-3.5-turbo": 16_385,
    "o1": 200_000,
    "o1-mini": 128_000,
    "o3-mini": 200_000,
    # Google Gemini
    "gemini-2.0-flash": 1_048_576,
    "gemini-2.0-flash-lite": 1_048_576,
    "gemini-1.5-flash": 1_048_576,
    "gemini-1.5-pro": 2_097_152,
    "gemini-flash": 1_048_576,
    "gemini-pro": 2_097_152,
    # Meta Llama
    "llama-3.1-405b": 131_072,
    "llama-3.1-70b": 131_072,
    "llama-3.1-8b": 131_072,
    "llama-3.3-70b": 131_072,
    # Mistral
    "mistral-7b": 32_768,
    "mixtral-8x7b": 32_768,
    "mistral-nemo": 131_072,
    # Fallback for unknown / Ollama local
    "default": 32_768,
}


def _model_context_size(model_id: str) -> int:
    """Return the context window size for a model ID (best-effort substring match)."""
    model_lower = model_id.lower()
    for key, size in _MODEL_CONTEXT.items():
        if key in model_lower:
            return size
    return _MODEL_CONTEXT["default"]


def _context_bar(pct: float) -> tuple[str, str]:
    """Return (3-char bar, color) for a context-usage percentage 0–100."""
    if pct >= 75:
        bar = "███"
        color = "#ef4444"  # red — nearly full
    elif pct >= 50:
        bar = "██░"
        color = "#f59e0b"  # amber — half full
    elif pct >= 25:
        bar = "█░░"
        color = "#22c55e"  # green — comfortable
    else:
        bar = "░░░"
        color = "#22c55e"  # green — lots of room
    return bar, color


def _short_cwd(project_root: str = "") -> str:
    """Return a compact directory label (last 2 path components)."""
    try:
        path = Path(project_root or os.getcwd())
        parts = path.parts
        if len(parts) >= 2:
            return f"{parts[-2]}/{parts[-1]}"
        return path.name or str(path)
    except Exception:
        return "~"


def _is_tty() -> bool:
    """Return True if stdout is an interactive terminal."""
    return sys.stdout.isatty()


def _relative_time(ts: float) -> str:
    """Format a Unix timestamp as a human-readable relative string."""
    delta = time.time() - ts
    if delta < 5:
        return "just now"
    if delta < 60:
        return f"{int(delta)}s ago"
    if delta < 3600:
        return f"{int(delta // 60)}m ago"
    if delta < 86400:
        return f"{int(delta // 3600)}h ago"
    return f"{int(delta // 86400)}d ago"


class StatusBar:
    """Sticky footer status bar displayed via rich.live.

    Fields:
        model       — active model name (short form after last /)
        tokens      — cumulative session token count
        connected   — CONN_CONNECTED / CONN_DISCONNECTED / CONN_CHECKING
        environment — string label ("lab", "prod", etc.)

    Only activates in interactive (TTY) mode or when ``force=True``.
    The ``--no-tui`` flag (detected via ``MSAPLING_NO_TUI=1`` env var or
    the ``no_tui`` attribute on the shell) also disables the bar.
    """

    # Refresh rate for the background Live loop
    REFRESH_PER_SECOND = 4

    def __init__(self, shell: "InteractiveShell"):
        self._shell = shell
        self._tokens: int = 0
        self._credits: float = 0.0
        self._connected: str = CONN_CHECKING
        self._environment: str = self._detect_environment()
        self._live: Optional[Live] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._active = False

    # ── Internal helpers ────────────────────────────────────────────────

    def _detect_environment(self) -> str:
        """Determine environment label from env vars or config."""
        env = os.environ.get("MSAPLING_ENV", "").strip()
        if env:
            return env
        api_url = os.environ.get("MSAPLING_API_URL", "")
        if not api_url:
            try:
                from .config import get_settings
                api_url = get_settings().api_url
            except Exception:
                api_url = ""
        if "localhost" in api_url or "127.0.0.1" in api_url:
            return "local"
        if "staging" in api_url:
            return "staging"
        if "lab" in api_url:
            return "lab"
        return "prod"

    def _no_tui_requested(self) -> bool:
        """Return True if TUI should be suppressed."""
        if os.environ.get("MSAPLING_NO_TUI", "").strip().lower() in ("1", "true", "yes"):
            return True
        if getattr(self._shell, "no_tui", False):
            return True
        return False

    # ── Public API ──────────────────────────────────────────────────────

    def render(self) -> Text:
        """Build and return the status bar as a Rich Text object.

        Format:
          ◆ <model>  |  ctx ███ 12%/200K  |  ↑ 24,150 tok  |  💳 4.50 cr
                     |  📁 MSapling_LAB  |  ● Connected  |  prod
        """
        shell = self._shell
        model_full: str = getattr(shell, "model", "") or ""
        model_short = model_full.split("/")[-1] if "/" in model_full else model_full
        tokens: int = getattr(shell, "tokens_total", 0) or self._tokens
        connected: str = self._connected
        environment: str = self._environment
        project_root: str = getattr(shell, "project_root", "") or ""

        bar = Text()

        # ── Model ─────────────────────────────────────────────────────
        bar.append(" ◆ ", style="bold #3b82f6")
        bar.append(model_short or "—", style="bold #e2e8f0")

        bar.append("  |  ", style="dim #64748b")

        # ── Context window usage ──────────────────────────────────────
        ctx_size = _model_context_size(model_full)
        pct = min((tokens / ctx_size) * 100.0, 100.0) if ctx_size > 0 else 0.0
        mini_bar, bar_color = _context_bar(pct)
        bar.append("ctx ", style="dim #64748b")
        bar.append(mini_bar, style=f"bold {bar_color}")
        bar.append(f" {pct:.0f}%", style=bar_color)
        # Show context size in K or M
        if ctx_size >= 1_000_000:
            ctx_label = f"/{ctx_size // 1_000_000}M"
        else:
            ctx_label = f"/{ctx_size // 1_000}K"
        bar.append(ctx_label, style="dim #64748b")

        bar.append("  |  ", style="dim #64748b")

        # ── Token count ───────────────────────────────────────────────
        bar.append("↑ ", style="#94a3b8")
        bar.append(f"{tokens:,} tok", style="#e2e8f0")

        bar.append("  |  ", style="dim #64748b")

        # ── Fuel credits ───────────────────────────────────────────────
        credits: float = float(self._credits)
        if credits > 5:
            credits_style = "#22c55e"
        elif credits >= 1:
            credits_style = "#f59e0b"
        else:
            credits_style = "#ef4444"
        bar.append("💳 ", style=credits_style)
        bar.append(f"{credits:.2f} cr", style=credits_style)

        bar.append("  |  ", style="dim #64748b")

        # ── Current directory ─────────────────────────────────────────
        bar.append("📁 ", style="dim #64748b")
        bar.append(_short_cwd(project_root), style="#38bdf8")

        bar.append("  |  ", style="dim #64748b")

        # ── Connection status ──────────────────────────────────────────
        if connected == CONN_CONNECTED:
            bar.append("● Connected", style="bold #22c55e")
        elif connected == CONN_DISCONNECTED:
            bar.append("○ Disconnected", style="bold #ef4444")
        else:
            bar.append("◌ Checking", style="#f59e0b")

        bar.append("  |  ", style="dim #64748b")

        # ── Environment ────────────────────────────────────────────────
        env_style = "#22c55e" if environment == "prod" else "#f59e0b"
        bar.append(environment or "—", style=env_style)

        bar.append(" ", style="")
        return bar

    def update(
        self,
        tokens: Optional[int] = None,
        connected: Optional[str] = None,
        environment: Optional[str] = None,
        credits: Optional[float] = None,
    ) -> None:
        """Update one or more fields. Safe to call from any thread."""
        if tokens is not None:
            self._tokens = tokens
        if connected is not None:
            self._connected = connected
        if environment is not None:
            self._environment = environment
        if credits is not None:
            self._credits = credits
        # Trigger a live refresh if running
        if self._live is not None:
            try:
                self._live.update(self.render())
            except Exception:
                pass

    def start(self, force: bool = False) -> None:
        """Start the background Live refresh thread.

        Only starts if:
        - ``force=True``, or
        - stdout is a real TTY and ``--no-tui`` was not requested.
        """
        if not force and (not _is_tty() or self._no_tui_requested()):
            return
        if self._active:
            return
        self._active = True
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run_live, daemon=True, name="msapling-status-bar")
        self._thread.start()

    def stop(self) -> None:
        """Stop the background refresh thread and clean up the Live instance."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        self._live = None
        self._active = False

    # ── Background thread ───────────────────────────────────────────────

    def _run_live(self) -> None:
        """Background thread: keep a rich.Live instance refreshing the bar."""
        from .tui import console as tui_console

        interval = 1.0 / self.REFRESH_PER_SECOND
        try:
            with Live(
                self.render(),
                console=tui_console,
                refresh_per_second=self.REFRESH_PER_SECOND,
                transient=False,
            ) as live:
                self._live = live
                while not self._stop_event.is_set():
                    live.update(self.render())
                    self._stop_event.wait(timeout=interval)
        except Exception:
            pass
        finally:
            self._live = None
