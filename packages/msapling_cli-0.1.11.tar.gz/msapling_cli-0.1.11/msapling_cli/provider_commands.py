"""CLI commands for inspecting MSapling provider and circuit-breaker status."""
from __future__ import annotations

import asyncio
from typing import Optional

import typer
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .api import APIError, MSaplingClient, OfflineError
from .config import get_token
from .tui import console

providers_app = typer.Typer(
    name="providers",
    help="Inspect AI provider health and circuit-breaker state.",
)


def _run(coro):
    return asyncio.run(coro)


def _require_auth() -> str:
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run `msapling login` first.[/red]")
        raise typer.Exit(1)
    return token


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

@providers_app.command("status")
def providers_status(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show additional failure metadata"),
):
    """Show current circuit-breaker status for all tracked AI providers.

    STATE legend:
      [green]CLOSED[/green]  — healthy, requests flowing normally
      [yellow]HALF_OPEN[/yellow] — probing after a trip; 1 success re-closes
      [red]OPEN[/red]    — tripped; requests blocked until retry window passes
    """
    token = _require_auth()

    async def _fetch():
        async with MSaplingClient(token=token) as client:
            data = await client.get_provider_circuit_summary()
            return data

    try:
        rows = _run(_fetch())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if not rows:
        console.print(Panel(
            "[dim]No provider circuit state tracked yet.\n"
            "Providers appear here after the first request is routed through them.[/dim]",
            title="Provider Circuit Breaker Status",
            border_style="dim",
            expand=False,
        ))
        return

    table = Table(
        title="Provider Circuit Breaker Status",
        show_header=True,
        header_style="bold magenta",
        expand=False,
    )
    table.add_column("Provider", style="bold", min_width=20)
    table.add_column("State", min_width=10)
    table.add_column("Failures", justify="right", min_width=8)
    table.add_column("Last Failure", min_width=20)
    if verbose:
        table.add_column("Retry After (s)", justify="right", min_width=14)

    for row in rows:
        provider = str(row.get("provider", "unknown"))
        state = str(row.get("state", "UNKNOWN")).upper()
        failures = str(row.get("consecutive_failures", row.get("failures", 0)))
        last_failure = str(row.get("last_failure_at", row.get("last_failure", "—")) or "—")
        retry_after = str(row.get("retry_after_s", "—"))

        if state == "CLOSED":
            state_text = Text("CLOSED", style="bold green")
        elif state == "HALF_OPEN":
            state_text = Text("HALF_OPEN", style="bold yellow")
        elif state == "OPEN":
            state_text = Text("OPEN", style="bold red")
        else:
            state_text = Text(state, style="dim")

        if verbose:
            table.add_row(provider, state_text, failures, last_failure, retry_after)
        else:
            table.add_row(provider, state_text, failures, last_failure)

    console.print(table)

    open_count = sum(1 for r in rows if str(r.get("state", "")).upper() == "OPEN")
    if open_count:
        console.print(f"\n[red]{open_count} provider(s) currently OPEN[/red] — requests to those providers are blocked.")
    else:
        console.print("\n[green]All tracked providers are healthy.[/green]")


# ---------------------------------------------------------------------------
# reset
# ---------------------------------------------------------------------------

@providers_app.command("reset")
def providers_reset(
    provider: str = typer.Argument(..., help="Provider key to reset (e.g. openrouter, anthropic)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Force-reset a provider's circuit breaker to CLOSED (healthy) state.

    Use this after a provider incident is resolved and you want to resume
    traffic immediately without waiting for the automatic retry window.
    """
    token = _require_auth()

    if not yes:
        from rich.prompt import Confirm
        confirmed = Confirm.ask(
            f"Force-reset circuit breaker for provider '{provider}'?",
            default=False,
        )
        if not confirmed:
            console.print("[yellow]Aborted.[/yellow]")
            raise typer.Exit(0)

    async def _reset():
        async with MSaplingClient(token=token) as client:
            http = await client._get_client()
            resp = await client._request_with_csrf_retry(
                lambda: http.post(
                    "/api/provider/circuit/reset",
                    json={"provider": provider},
                )
            )
            if resp.status_code == 404:
                console.print(
                    f"[yellow]Reset endpoint not available on this server. "
                    f"The circuit will self-heal after the retry window.[/yellow]"
                )
                return
            resp.raise_for_status()
            console.print(f"[green]Circuit breaker reset[/green] for provider '{provider}'.")

    try:
        _run(_reset())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
