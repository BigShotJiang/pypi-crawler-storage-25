"""Typed memory system for MSapling (memdir).

Stores memories as typed markdown files with YAML frontmatter.
Works for both CLI and web backend.

Memory types:
  - user: Who the user is, preferences, expertise
  - feedback: What to do / not do (corrections + confirmations)
  - project: Current work, goals, deadlines
  - reference: Pointers to external resources

Storage:
  - Project: .msapling/memory/
  - Global: ~/.msapling/memory/
  - Index: MEMORY.md (one-line summaries, max 200 lines)

Retrieval:
  - BM25 keyword matching for fast local retrieval
  - Optional LLM-based relevance ranking for deeper context
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

MemoryType = Literal["user", "feedback", "project", "reference"]
VALID_TYPES = ("user", "feedback", "project", "reference")

_GLOBAL_DIR = Path.home() / ".msapling" / "memory"
_INDEX_NAME = "MEMORY.md"
_MAX_INDEX_LINES = 200


def _project_dir(project_root: str) -> Path:
    return Path(project_root) / ".msapling" / "memory"


def _slugify(text: str) -> str:
    """Convert text to a safe filename slug."""
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower().strip())
    return slug[:60].strip("_") or "untitled"


def _parse_frontmatter(content: str) -> tuple[Dict[str, str], str]:
    """Parse YAML frontmatter from markdown content."""
    if not content.startswith("---"):
        return {}, content
    parts = content.split("---", 2)
    if len(parts) < 3:
        return {}, content
    meta = {}
    for line in parts[1].strip().split("\n"):
        if ":" in line:
            key, val = line.split(":", 1)
            meta[key.strip()] = val.strip()
    return meta, parts[2].strip()


def _build_frontmatter(name: str, description: str, mem_type: str) -> str:
    return f"""---
name: {name}
description: {description}
type: {mem_type}
created: {time.strftime("%Y-%m-%d")}
---

"""


# ─── Core API ────────────────────────────────────────────────────

def save_memory(
    name: str,
    content: str,
    mem_type: MemoryType,
    description: str = "",
    *,
    project_root: Optional[str] = None,
    scope: str = "project",
) -> str:
    """Save a typed memory as a markdown file.

    Returns confirmation string.
    """
    if mem_type not in VALID_TYPES:
        return f"Error: type must be one of {VALID_TYPES}"

    base_dir = _project_dir(project_root) if project_root and scope == "project" else _GLOBAL_DIR
    base_dir.mkdir(parents=True, exist_ok=True)

    slug = _slugify(name)
    filename = f"{mem_type}_{slug}.md"
    filepath = base_dir / filename

    # Build file content
    desc = description or content[:100].replace("\n", " ")
    file_content = _build_frontmatter(name, desc, mem_type) + content.strip() + "\n"

    filepath.write_text(file_content, encoding="utf-8")

    # Update index
    _update_index(base_dir, filename, name, desc)

    return f"Saved {mem_type} memory: {name}"


def get_memory(name: str, *, project_root: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Get a specific memory by name."""
    slug = _slugify(name)
    for base_dir in _search_dirs(project_root):
        for f in base_dir.glob(f"*_{slug}.md"):
            entry = _read_memory_file(f)
            return _add_staleness_caveat(entry) if entry else None
    return None


def list_memories(project_root: Optional[str] = None, mem_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """List all memories, optionally filtered by type."""
    results = []
    for base_dir in _search_dirs(project_root):
        if not base_dir.is_dir():
            continue
        for f in sorted(base_dir.glob("*.md")):
            if f.name == _INDEX_NAME:
                continue
            entry = _read_memory_file(f)
            if entry and (not mem_type or entry.get("type") == mem_type):
                results.append(_add_staleness_caveat(entry))
    return results


def delete_memory(name: str, *, project_root: Optional[str] = None) -> str:
    """Delete a memory by name."""
    slug = _slugify(name)
    for base_dir in _search_dirs(project_root):
        for f in base_dir.glob(f"*_{slug}.md"):
            f.unlink()
            _rebuild_index(base_dir)
            return f"Deleted: {name}"
    return f"Not found: {name}"


def clear_memories(project_root: Optional[str] = None, scope: str = "all"):
    """Clear all memories."""
    dirs = []
    if scope in ("all", "global"):
        dirs.append(_GLOBAL_DIR)
    if scope in ("all", "project") and project_root:
        dirs.append(_project_dir(project_root))
    for d in dirs:
        if d.is_dir():
            for f in d.glob("*.md"):
                f.unlink()


# ─── Context Building (for LLM injection) ────────────────────────

def build_memory_context(
    project_root: Optional[str] = None,
    query: Optional[str] = None,
    max_entries: int = 15,
) -> str:
    """Build memory context string for LLM system prompt.

    If query is provided, uses BM25-style keyword matching to rank relevance.
    Otherwise returns most recent memories.
    """
    all_memories = list_memories(project_root)
    if not all_memories:
        return ""

    if query:
        # BM25-style keyword scoring
        scored = []
        query_terms = set(query.lower().split())
        for mem in all_memories:
            text = (mem.get("name", "") + " " + mem.get("description", "") + " " + mem.get("content", "")).lower()
            score = sum(1 for term in query_terms if term in text)
            if score > 0:
                scored.append((score, mem))
        scored.sort(key=lambda x: x[0], reverse=True)
        selected = [m for _, m in scored[:max_entries]]
    else:
        selected = all_memories[-max_entries:]

    if not selected:
        return ""

    parts = []
    for mem in selected:
        mem_type = mem.get("type", "?")
        name = mem.get("name", "?")
        content = mem.get("content", "")[:300]
        parts.append(f"[{mem_type}] {name}: {content}")

    return "[Memories]\n" + "\n".join(parts)


# ─── Backward Compatibility ──────────────────────────────────────

def add_memory(text: str, *, project_root: Optional[str] = None, scope: str = "project") -> str:
    """Backward-compatible API — saves as 'project' type memory."""
    # Auto-detect type from content
    lower = text.lower()
    if any(w in lower for w in ("don't", "stop", "never", "always", "prefer")):
        mem_type: MemoryType = "feedback"
    elif any(w in lower for w in ("http", "url", "link", "docs", "wiki")):
        mem_type = "reference"
    elif any(w in lower for w in ("role", "expertise", "background", "prefer")):
        mem_type = "user"
    else:
        mem_type = "project"

    name = text[:50].replace("\n", " ").strip()
    return save_memory(name, text, mem_type, project_root=project_root, scope=scope)


def get_memories(project_root: Optional[str] = None) -> str:
    """Backward-compatible API — returns formatted string for LLM context."""
    return build_memory_context(project_root)


# ─── Internal Helpers ─────────────────────────────────────────────

def _search_dirs(project_root: Optional[str]) -> List[Path]:
    dirs = [_GLOBAL_DIR]
    if project_root:
        dirs.append(_project_dir(project_root))
    return dirs


def _add_staleness_caveat(memory: dict) -> dict:
    """Add staleness warning to old memories."""
    saved_at = memory.get("saved_at")
    if saved_at:
        age_days = (time.time() - saved_at) / 86400
        if age_days > 1:
            memory["content"] = f"[Note: This memory is {age_days:.0f} days old and may be stale]\n\n{memory['content']}"
    return memory


def _read_memory_file(path: Path) -> Optional[Dict[str, Any]]:
    try:
        raw = path.read_text(encoding="utf-8")
        meta, body = _parse_frontmatter(raw)
        # Use file mtime as saved_at (creation date for new files, modification otherwise)
        try:
            saved_at = path.stat().st_mtime
        except Exception:
            saved_at = None
        return {
            "name": meta.get("name", path.stem),
            "type": meta.get("type", "project"),
            "description": meta.get("description", ""),
            "created": meta.get("created", ""),
            "content": body,
            "path": str(path),
            "saved_at": saved_at,
            "_scope": "global" if str(_GLOBAL_DIR) in str(path) else "project",
        }
    except Exception:
        return None


def _update_index(base_dir: Path, filename: str, name: str, description: str):
    """Add or update an entry in MEMORY.md index."""
    index_path = base_dir / _INDEX_NAME
    line = f"- [{name}]({filename}) -- {description[:100]}"

    existing = []
    if index_path.exists():
        existing = [
            l for l in index_path.read_text(encoding="utf-8").strip().split("\n")
            if l.strip()
        ]

    # Remove old entry for same file
    existing = [l for l in existing if filename not in l]
    existing.append(line)

    # Cap at max lines
    if len(existing) > _MAX_INDEX_LINES:
        existing = existing[-_MAX_INDEX_LINES:]

    index_path.write_text("\n".join(existing) + "\n", encoding="utf-8")


def _rebuild_index(base_dir: Path):
    """Rebuild MEMORY.md from all memory files."""
    lines = []
    for f in sorted(base_dir.glob("*.md")):
        if f.name == _INDEX_NAME:
            continue
        meta, _ = _parse_frontmatter(f.read_text(encoding="utf-8"))
        name = meta.get("name", f.stem)
        desc = meta.get("description", "")[:100]
        lines.append(f"- [{name}]({f.name}) -- {desc}")

    index_path = base_dir / _INDEX_NAME
    index_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
