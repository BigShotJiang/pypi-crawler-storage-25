"""Runtime fanout governance helpers for multi/swarm orchestration."""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

MAX_FANOUT_CAP = 8


def _parse_cap(value: Any) -> Optional[int]:
    try:
        if value is None:
            return None
        cap = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return max(1, min(MAX_FANOUT_CAP, cap))


def _detect_memory_gb() -> Optional[float]:
    # Prefer psutil when present for cross-platform consistency.
    try:
        import psutil  # type: ignore

        total = int(psutil.virtual_memory().total)
        if total > 0:
            return round(total / (1024 ** 3), 1)
    except Exception:
        pass

    # Windows fallback without extra dependencies.
    try:
        import ctypes

        class _MemoryStatusEx(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        stat = _MemoryStatusEx()
        stat.dwLength = ctypes.sizeof(_MemoryStatusEx)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):  # type: ignore[attr-defined]
            total = int(stat.ullTotalPhys)
            if total > 0:
                return round(total / (1024 ** 3), 1)
    except Exception:
        pass

    return None


def _memory_cap(memory_gb: Optional[float]) -> int:
    if memory_gb is None:
        return MAX_FANOUT_CAP
    if memory_gb < 2:
        return 1
    if memory_gb < 4:
        return 2
    if memory_gb < 8:
        return 3
    if memory_gb < 16:
        return 4
    if memory_gb < 32:
        return 6
    return MAX_FANOUT_CAP


def runtime_fanout_budget(*, provider_hint: Optional[int] = None) -> Dict[str, Any]:
    """Return host/provider-derived lane recommendations for fanout commands."""
    cpu_count = max(1, int(os.cpu_count() or 1))
    cpu_cap = max(1, min(MAX_FANOUT_CAP, (cpu_count + 1) // 2))
    memory_gb = _detect_memory_gb()
    mem_cap = _memory_cap(memory_gb)

    env_cap = _parse_cap(os.environ.get("MSAPLING_FANOUT_CAP"))
    hint_cap = _parse_cap(provider_hint)
    if hint_cap is None:
        hint_cap = _parse_cap(os.environ.get("MSAPLING_PROVIDER_CONCURRENCY_HINT"))

    caps = [cpu_cap, mem_cap]
    if env_cap is not None:
        caps.append(env_cap)
    if hint_cap is not None:
        caps.append(hint_cap)
    recommended = max(1, min(caps))

    return {
        "recommended_cap": recommended,
        "cpu_count": cpu_count,
        "cpu_cap": cpu_cap,
        "memory_gb": memory_gb,
        "memory_cap": mem_cap,
        "provider_hint_cap": hint_cap,
        "env_cap": env_cap,
    }


def fanout_budget_detail(budget: Dict[str, Any]) -> str:
    cap = int(budget.get("recommended_cap") or 1)
    cpu_count = int(budget.get("cpu_count") or 1)
    cpu_cap = int(budget.get("cpu_cap") or 1)
    mem_cap = int(budget.get("memory_cap") or MAX_FANOUT_CAP)
    memory_gb = budget.get("memory_gb")
    hint_cap = budget.get("provider_hint_cap")
    env_cap = budget.get("env_cap")
    mem_label = f"{memory_gb}GB" if isinstance(memory_gb, (int, float)) else "unknown"
    hint_label = str(hint_cap) if isinstance(hint_cap, int) else "-"
    env_label = str(env_cap) if isinstance(env_cap, int) else "-"
    return (
        f"recommended={cap} lanes (cpu={cpu_count}->{cpu_cap}, "
        f"memory={mem_label}->{mem_cap}, provider_hint={hint_label}, env_cap={env_label})"
    )
