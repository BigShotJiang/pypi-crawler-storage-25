"""ECC-inspired git checkpoint system for MSapling CLI.

Provides named git checkpoints via stash + annotated tags so users can
snapshot their work before risky operations and roll back cleanly.
"""
from __future__ import annotations

import py_compile
import subprocess
import time
from pathlib import Path
from typing import List, Optional, Tuple


class CheckpointManager:
    """Manage named git checkpoints (stash + tag pairs)."""

    TAG_PREFIX = "ms-checkpoint-"

    def __init__(self, repo_root: Optional[str] = None):
        if repo_root is None:
            repo_root = "."
        self.repo_root = str(Path(repo_root).resolve())

    def _run_git(self, args: List[str]) -> Tuple[int, str]:
        """Run a git command inside repo_root. Returns (returncode, stdout)."""
        try:
            result = subprocess.run(
                ["git"] + args,
                cwd=self.repo_root,
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = (result.stdout or "").strip()
            if result.returncode != 0:
                output = (result.stderr or result.stdout or "").strip()
            return result.returncode, output
        except FileNotFoundError:
            return 127, "git not found in PATH"
        except subprocess.TimeoutExpired:
            return 1, "git command timed out"
        except Exception as exc:
            return 1, str(exc)

    def _is_git_repo(self) -> bool:
        rc, _ = self._run_git(["rev-parse", "--git-dir"])
        return rc == 0

    def _quality_check(self) -> Tuple[bool, str]:
        """Run py_compile on .py files under repo_root (skip venv/node_modules)."""
        SKIP_DIRS = {".git", "venv", ".venv", "node_modules", "__pycache__", "dist", "build"}
        errors: List[str] = []
        root = Path(self.repo_root)
        for py_file in root.rglob("*.py"):
            if any(skip in py_file.parts for skip in SKIP_DIRS):
                continue
            try:
                py_compile.compile(str(py_file), doraise=True)
            except py_compile.PyCompileError as exc:
                errors.append(str(exc))
                if len(errors) >= 5:
                    break
        if errors:
            return False, "; ".join(errors[:3])
        return True, ""

    def _has_changes(self) -> bool:
        """True when there are staged or unstaged changes (anything stashable)."""
        rc, out = self._run_git(["status", "--porcelain"])
        return rc == 0 and bool(out.strip())

    def create(self, label: str) -> dict:
        """Create a named checkpoint.

        Steps:
          1. Quality check (py_compile on Python files).
          2. git stash push with the label as the stash message.
          3. git tag ms-checkpoint-{ts}-{label} pointing at HEAD.

        Returns dict with keys: tag, stash, ok, error.
        """
        if not self._is_git_repo():
            return {"tag": None, "stash": None, "ok": False, "error": "not a git repository"}

        safe_label = "".join(c if c.isalnum() or c in "-_." else "_" for c in label)
        ts = int(time.time())
        tag_name = f"{self.TAG_PREFIX}{ts}-{safe_label}"

        ok, qc_error = self._quality_check()
        if not ok:
            return {
                "tag": None,
                "stash": None,
                "ok": False,
                "error": f"quality check failed: {qc_error}",
            }

        stash_ref = None
        if self._has_changes():
            rc, out = self._run_git(
                ["stash", "push", "--include-untracked", "-m", f"checkpoint: {label}"]
            )
            if rc != 0:
                return {"tag": None, "stash": None, "ok": False, "error": f"stash failed: {out}"}
            _, stash_list = self._run_git(["stash", "list", "--format=%gd %s"])
            if stash_list:
                stash_ref = stash_list.split()[0] if stash_list else "stash@{0}"
            else:
                stash_ref = "stash@{0}"

        rc, out = self._run_git(
            ["tag", "-a", tag_name, "-m", f"MSapling checkpoint: {label}"]
        )
        if rc != 0:
            if stash_ref:
                self._run_git(["stash", "pop"])
            return {"tag": None, "stash": stash_ref, "ok": False, "error": f"tag failed: {out}"}

        return {"tag": tag_name, "stash": stash_ref, "ok": True, "error": None}

    def compare(self, checkpoint_tag: str) -> dict:
        """Diff the current working state vs a checkpoint tag.

        Returns dict with keys: files_changed, lines_added, lines_removed.
        """
        if not self._is_git_repo():
            return {
                "files_changed": [], "lines_added": 0, "lines_removed": 0,
                "error": "not a git repository",
            }

        rc, _ = self._run_git(["rev-parse", "--verify", checkpoint_tag])
        if rc != 0:
            return {
                "files_changed": [], "lines_added": 0, "lines_removed": 0,
                "error": f"tag not found: {checkpoint_tag}",
            }

        rc, stat_out = self._run_git(["diff", "--stat", checkpoint_tag, "HEAD"])
        if rc != 0:
            rc, stat_out = self._run_git(["diff", "--stat", checkpoint_tag])

        files_changed: List[str] = []
        lines_added = 0
        lines_removed = 0

        for line in stat_out.splitlines():
            line = line.strip()
            if not line:
                continue
            if "file" in line and "changed" in line:
                import re
                m_add = re.search(r"(\d+) insertion", line)
                m_del = re.search(r"(\d+) deletion", line)
                if m_add:
                    lines_added = int(m_add.group(1))
                if m_del:
                    lines_removed = int(m_del.group(1))
            else:
                parts = line.split("|")
                if parts:
                    fname = parts[0].strip()
                    if fname:
                        files_changed.append(fname)

        if lines_added == 0 and lines_removed == 0:
            rc2, numstat = self._run_git(["diff", "--numstat", checkpoint_tag, "HEAD"])
            if rc2 == 0:
                for row in numstat.splitlines():
                    parts = row.split("\t")
                    if len(parts) >= 2:
                        try:
                            lines_added += int(parts[0]) if parts[0] != "-" else 0
                            lines_removed += int(parts[1]) if parts[1] != "-" else 0
                        except ValueError:
                            pass

        return {
            "files_changed": files_changed,
            "lines_added": lines_added,
            "lines_removed": lines_removed,
            "error": None,
        }

    def restore(self, checkpoint_tag: str, confirmed: bool = False) -> dict:
        """Restore to a checkpoint tag.

        Requires confirmed=True to proceed (safety guard).
        Discards all uncommitted changes and resets to the tagged commit.

        Returns dict with keys: ok, discarded_changes, error.
        """
        if not confirmed:
            return {
                "ok": False,
                "discarded_changes": 0,
                "error": "restore requires confirmed=True to proceed",
            }

        if not self._is_git_repo():
            return {"ok": False, "discarded_changes": 0, "error": "not a git repository"}

        rc, tag_commit = self._run_git(["rev-parse", "--verify", checkpoint_tag])
        if rc != 0:
            return {
                "ok": False,
                "discarded_changes": 0,
                "error": f"tag not found: {checkpoint_tag}",
            }

        _, status_out = self._run_git(["status", "--porcelain"])
        discarded = len([l for l in status_out.splitlines() if l.strip()])

        rc, out = self._run_git(["reset", "--hard", checkpoint_tag])
        if rc != 0:
            return {"ok": False, "discarded_changes": 0, "error": f"reset failed: {out}"}

        self._run_git(["clean", "-fd"])
        return {"ok": True, "discarded_changes": discarded, "error": None}

    def list_checkpoints(self) -> List[dict]:
        """List all ms-checkpoint-* tags sorted newest first.

        Each entry has: tag, date, label, commit.
        """
        if not self._is_git_repo():
            return []

        rc, out = self._run_git([
            "tag", "-l", f"{self.TAG_PREFIX}*",
            "--sort=-creatordate",
            "--format=%(refname:short)|%(creatordate:short)|%(objectname:short)",
        ])
        if rc != 0 or not out.strip():
            return []

        results: List[dict] = []
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split("|")
            tag = parts[0] if len(parts) > 0 else line
            date = parts[1] if len(parts) > 1 else ""
            commit = parts[2] if len(parts) > 2 else ""
            label = ""
            remainder = tag[len(self.TAG_PREFIX):]
            dash_idx = remainder.find("-")
            if dash_idx != -1:
                label = remainder[dash_idx + 1:]
            results.append({"tag": tag, "date": date, "label": label, "commit": commit})
        return results
