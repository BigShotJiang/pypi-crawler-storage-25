"""MSapling CLI - Multi-chat AI development environment in your terminal.

Usage:
    msapling login                          # Authenticate
    msapling chat "explain this code"       # Quick chat
    msapling chat -i                        # Interactive chat session
    msapling edit "add type hints" main.py  # LLM-driven file editing
    msapling diff old.py new.py             # Generate unified diff
    msapling ls                             # List MDrive files
    msapling cat src/main.py                # View file content
    msapling models                         # List available models
    msapling projects                       # List projects
"""
from __future__ import annotations

import asyncio
from contextlib import suppress
import os
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import typer
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.status import Status
from rich.syntax import Syntax
from rich.table import Table
from rich.prompt import Prompt

from . import __version__
from .agent_registry import (
    configure_agent as configure_registry_agent,
    default_models_from_registry,
    list_agents as list_registry_agents,
    reload_agent_registry,
    set_agent_enabled as set_registry_agent_enabled,
)
from .config import get_settings, save_settings, get_token, save_token, clear_token, Settings
from .api import MSaplingClient, OfflineError
from .fanout_governance import fanout_budget_detail, runtime_fanout_budget
from .tier import require_pro, require_auth, is_free_model
from .transcript_hygiene import repair_session_file
from .tui import render_working_panel, working_spinner, console
from .coding_workflow import (
    build_default_verify_commands,
    build_workspace_index,
    detect_workspace_root,
    enforce_repo_grounded_diff,
    extract_diff_paths,
    extract_structured_evidence,
    extract_unified_diff as _workflow_extract_unified_diff,
    normalize_unified_diff_headers,
    run_verify_commands,
    validate_repo_target,
)

# Cache user info for tier checks within a session (5-min TTL)
_cached_user: dict = {}
_cached_user_ts: float = 0.0
_CACHED_USER_TTL = 300.0  # seconds


def _package_version(pkg: str) -> str:
    """Return installed version of a package, or '?' if not found."""
    try:
        from importlib.metadata import version
        return version(pkg)
    except Exception:
        return "?"


def _console_safe_text(text: str) -> str:
    """Strip BOM and replace unencodable characters for the current stdout encoding."""
    # Strip BOM
    text = text.lstrip("\ufeff")
    encoding = getattr(sys.stdout, "encoding", "utf-8") or "utf-8"
    # Replace characters that can't be encoded in stdout's encoding
    return text.encode(encoding, errors="replace").decode(encoding, errors="replace")


def get_token_source() -> Optional[str]:
    """Return the source of the current auth token ('env', 'file', 'keyring', or None)."""
    if os.environ.get("MSAPLING_TOKEN"):
        return "env"
    if get_token():
        return "file"
    try:
        import keyring
        if keyring.get_password("msapling", "token"):
            return "keyring"
    except Exception:
        pass
    return None


def inspect_token_sources() -> dict:
    """Return all token sources and their values for conflict detection."""
    sources: dict = {"env": None, "file": None, "keyring": None}
    sources["env"] = os.environ.get("MSAPLING_TOKEN") or None
    sources["file"] = get_token() or None
    try:
        import keyring
        sources["keyring"] = keyring.get_password("msapling", "token") or None
    except Exception:
        pass
    return sources


def _is_tier_402(detail: object) -> bool:
    """Return True if a 402 detail value indicates a tier/model restriction.

    Accepts any type — coerces to str before matching so callers never need
    to guard.  Uses word-boundary regex so "pro" does not match "provide" or
    "process", and "plan" does not match "planck".
    """
    import re
    low = str(detail).lower() if detail is not None else ""
    return bool(re.search(r"\b(model|tier|pro|plan|allowlist|upgrade)\b", low))


def _handle_error(e: Exception, context: str = "", verbose: bool = False) -> None:
    """Print a user-friendly error message based on exception type."""
    import httpx
    if hasattr(e, "status_code") or isinstance(e, httpx.HTTPStatusError):
        status = getattr(e, "status_code", None) or (
            e.response.status_code if hasattr(e, "response") else "?"
        )
        if status in (401, 403):
            console.print("[red]Authentication failed. Run `msapling login`.[/red]")
        elif status == 429:
            console.print("[yellow]Rate limited. Please wait a moment and retry.[/yellow]")
        elif status == 402:
            # Distinguish tier-gated model from plain credit exhaustion.
            detail = ""
            try:
                if hasattr(e, "response") and e.response is not None:
                    body = e.response.json() if callable(getattr(e.response, "json", None)) else {}
                    detail = str(body.get("detail") or body.get("message") or "")
            except Exception:
                detail = str(e)
            if _is_tier_402(detail):
                console.print(
                    "[yellow]Model not available on free plan. "
                    "Upgrade to Pro: msapling.com/pricing[/yellow]"
                )
            else:
                console.print("[red]Insufficient credits. Add fuel at msapling.com[/red]")
        else:
            console.print(f"[red]API error {status}: {e}[/red]")
    elif isinstance(e, (TimeoutError, ConnectionError)) or (
        hasattr(httpx, "TimeoutException") and isinstance(e, httpx.TimeoutException)
    ):
        console.print("[yellow]Connection timed out. Check your network and retry.[/yellow]")
    elif verbose:
        console.print_exception()
    else:
        console.print(f"[red]Error: {e}[/red] (use --verbose for details)")


def _handle_api_error(e: Exception, context: str = "") -> None:
    """Convert API errors to user-friendly messages."""
    import httpx
    err_str = str(e)
    if "401" in err_str or "Unauthorized" in err_str:
        console.print(f"[red]Session expired. Run: msapling login[/red]")
    elif "402" in err_str or "fuel" in err_str.lower() or "credits" in err_str.lower():
        # Distinguish tier-gated model from plain credit exhaustion.
        # APIError from stream_chat encodes the body detail as "402:<detail>".
        from .api import APIError as _APIError
        detail_payload = ""
        if isinstance(e, _APIError) and err_str.startswith("402:"):
            detail_payload = err_str[4:]  # strip "402:" prefix to get raw detail
        if _is_tier_402(detail_payload or err_str):
            console.print(
                "[yellow]Model not available on free plan. "
                "Upgrade to Pro: msapling.com/pricing[/yellow]"
            )
        else:
            console.print(f"[red]Out of credits. Top up at msapling.com[/red]")
    elif "429" in err_str or "rate limit" in err_str.lower():
        from .api import APIError as _APIError
        detail_payload = ""
        if isinstance(e, _APIError) and err_str.startswith("429:"):
            detail_payload = err_str[4:].strip()
        low_429 = (detail_payload or err_str).lower()
        if "stream limit" in low_429 or "already streaming" in low_429:
            console.print(
                f"[yellow]{detail_payload or 'Account stream limit reached. Wait for one active chat to finish.'}[/yellow]"
            )
        else:
            console.print(f"[yellow]Rate limited. Please wait a moment and retry.[/yellow]")
    elif "503" in err_str or "unavailable" in err_str.lower():
        console.print(f"[red]Backend unavailable. Check status at msapling.com/status[/red]")
    elif "404" in err_str:
        console.print(f"[yellow]Not found{': ' + context if context else ''}.[/yellow]")
    elif isinstance(e, ConnectionError) or "connect" in err_str.lower():
        console.print(f"[red]Connection failed. Check your network or run: msapling doctor[/red]")
    else:
        console.print(f"[red]Error{': ' + context if context else ''}: {e}[/red]")


def _status_code_from_exception(exc: Exception) -> Optional[int]:
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code
    response = getattr(exc, "response", None)
    response_code = getattr(response, "status_code", None)
    if isinstance(response_code, int):
        return response_code
    return None


def _is_transient_error_text(message: str) -> bool:
    low = str(message or "").lower()
    if not low:
        return False
    hard_no = (
        "401 unauthorized",
        "403 forbidden",
        "402",
        "payment required",
        "not a valid model id",
        "model unavailable",
        "requires a pro subscription",
    )
    if any(token in low for token in hard_no):
        return False
    transient_tokens = (
        "423",
        "429",
        "500",
        "502",
        "503",
        "504",
        "internal server error",
        "temporarily unavailable",
        "timeout",
        "timed out",
        "connection failed",
        "all connection attempts failed",
        "remoteprotocolerror",
        "connecterror",
        "readerror",
        "stream interrupted",
        "server disconnected",
        "already streaming",
        "stream limit reached",
    )
    return any(token in low for token in transient_tokens)


def _is_transient_exception(exc: Exception) -> bool:
    code = _status_code_from_exception(exc)
    if code in {423, 429, 500, 502, 503, 504}:
        return True
    if code in {400, 401, 402, 403, 404, 422}:
        return False
    return _is_transient_error_text(str(exc))


def _version_callback(value: bool):
    if value:
        Console().print(f"msapling-cli v{__version__}")
        raise typer.Exit()


def _default_callback(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", callback=_version_callback, is_eager=True, help="Show version"),
    prompt: Optional[str] = typer.Option(None, "-p", "--prompt", help="Non-interactive: run prompt and exit (headless mode)"),
    headless_model: Optional[str] = typer.Option(None, "--model", "-m", help="Model for headless mode"),
    output_format: str = typer.Option("text", "--output", "-o", help="Output format: text, json, stream-json"),
    max_turns: int = typer.Option(1, "--max-turns", help="Max agent turns in headless mode"),
):
    """Launch interactive shell when no command is given. Use -p for headless mode."""
    # Auto-update check (once per day, skipped in CI / tests)
    if not os.getenv("MSAPLING_NO_UPDATE_CHECK"):
        from .update_check import check_and_notify
        check_and_notify()

    if ctx.invoked_subcommand is None:
        if prompt:
            # Headless mode: run single prompt, print result, exit
            _run(_headless(prompt, headless_model, output_format, max_turns))
        else:
            from .shell import run_shell
            asyncio.run(run_shell())


app = typer.Typer(
    name="msapling",
    help="MSapling CLI - Multi-chat AI development in your terminal",
    invoke_without_command=True,
    callback=_default_callback,
)
ollama_app = typer.Typer(help="Manage local Ollama usage for msapling CLI.")
app.add_typer(ollama_app, name="ollama")
from .ses_commands import ses_app  # noqa: E402
app.add_typer(ses_app, name="ses")
from .cron import cron_app  # noqa: E402
app.add_typer(cron_app, name="cron")
from .export_commands import export_app  # noqa: E402
app.add_typer(export_app, name="export")
from .drive_commands import drive_app  # noqa: E402
app.add_typer(drive_app, name="drive")
from .instructions_commands import instructions_app  # noqa: E402
app.add_typer(instructions_app, name="instructions")
from .provider_commands import providers_app  # noqa: E402
app.add_typer(providers_app, name="providers")
from .dev_commands import dev_app  # noqa: E402
app.add_typer(dev_app, name="dev")
from .worktree_commands import worktree_app  # noqa: E402
app.add_typer(worktree_app, name="worktree")
from .profile_commands import profile_app  # noqa: E402
app.add_typer(profile_app, name="profile")
# console imported from tui (has MSAPLING_THEME; required for ms.* styles)


def _run(coro):
    """Run async function in sync context."""
    return asyncio.run(coro)
    return asyncio.run(coro)


def _registry_default_models(limit: int = 3) -> List[str]:
    models = [m.strip() for m in default_models_from_registry(limit=limit) if str(m).strip()]
    if models:
        return models
    return [
        "google/gemini-2.0-flash-001",
        "anthropic/claude-3-haiku",
        "openai/gpt-4o-mini",
    ][: max(1, int(limit))]


def _parse_models_option(raw_models: Optional[str], *, limit: int = 3) -> List[str]:
    if raw_models and raw_models.strip():
        return [m.strip() for m in raw_models.split(",") if m.strip()]
    return _registry_default_models(limit=limit)


def _registry_model_lane_budget() -> Dict[str, int]:
    budget: Dict[str, int] = {}
    try:
        for agent in list_registry_agents(enabled_only=True):
            model_id = str(agent.model or "").strip()
            if not model_id:
                continue
            max_parallel = max(1, int(agent.max_parallel or 1))
            budget[model_id] = budget.get(model_id, 0) + max_parallel
    except Exception:
        return {}
    return budget


def _enforce_registry_lane_caps(models: List[str]) -> None:
    counts: Dict[str, int] = {}
    for model_id in models:
        counts[model_id] = counts.get(model_id, 0) + 1

    budget = _registry_model_lane_budget()
    violations: List[str] = []
    for model_id, used in sorted(counts.items()):
        allowed = int(budget.get(model_id, 1))
        if used > allowed:
            violations.append(f"{model_id}: requested={used}, allowed={allowed}")
    if violations:
        console.print("[red]Model fanout exceeds configured agent max_parallel budget.[/red]")
        for line in violations:
            console.print(f"[red]- {line}[/red]")
        raise typer.Exit(1)


def _adaptive_fanout_cap(models: List[str], *, command_name: str) -> int:
    budget = runtime_fanout_budget()
    recommended = max(1, int(budget.get("recommended_cap") or 1))
    cap = min(recommended, max(1, len(models)))
    if len(models) > cap:
        console.print(
            f"[yellow]{command_name}: applying adaptive fanout cap {cap}/{len(models)} "
            f"({fanout_budget_detail(budget)}).[/yellow]"
        )
    return cap


def _adaptive_fanout_cap_with_hint(
    models: List[str],
    *,
    command_name: str,
    provider_hint: Optional[int],
) -> int:
    budget = runtime_fanout_budget(provider_hint=provider_hint) if provider_hint is not None else runtime_fanout_budget()
    recommended = max(1, int(budget.get("recommended_cap") or 1))
    cap = min(recommended, max(1, len(models)))
    if len(models) > cap:
        console.print(
            f"[yellow]{command_name}: applying adaptive fanout cap {cap}/{len(models)} "
            f"({fanout_budget_detail(budget)}).[/yellow]"
        )
    return cap


def _sum_usage_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    totals = {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0, "total": 0, "costUsd": 0.0}
    for row in rows:
        usage = row.get("usage")
        if not isinstance(usage, dict):
            continue
        for key in ("input", "output", "cacheRead", "cacheWrite", "total"):
            try:
                totals[key] += int(usage.get(key) or 0)
            except (TypeError, ValueError):
                continue
        try:
            totals["costUsd"] += float(usage.get("costUsd") or 0.0)
        except (TypeError, ValueError):
            continue
    totals["costUsd"] = round(float(totals["costUsd"]), 8)
    return totals


def _to_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_model_price_per_token(model_row: Dict[str, Any], *, direction: str) -> Optional[float]:
    if direction not in {"in", "out"}:
        return None
    direct_key = "price_in" if direction == "in" else "price_out"
    preferred_keys = [f"msapling_{direct_key}", direct_key]
    for key in preferred_keys:
        value = _to_float(model_row.get(key))
        if value is not None:
            return max(0.0, value)
    pricing = model_row.get("pricing")
    if isinstance(pricing, dict):
        nested_key = "prompt" if direction == "in" else "completion"
        value = _to_float(pricing.get(nested_key))
        if value is not None:
            return max(0.0, value)
    return None


def _format_price_per_million(price_per_token: Optional[float]) -> str:
    if price_per_token is None:
        return "-"
    if price_per_token <= 0:
        return "free"
    return f"${price_per_token * 1_000_000:.3f}"


def _model_sort_key(model_row: Dict[str, Any], *, sort_field: str) -> Any:
    field = str(sort_field or "id").strip().lower()
    if field == "price_in":
        value = _extract_model_price_per_token(model_row, direction="in")
        return float("inf") if value is None else value
    if field == "price_out":
        value = _extract_model_price_per_token(model_row, direction="out")
        return float("inf") if value is None else value
    if field == "context":
        ctx = model_row.get("context_length", model_row.get("context", 0))
        try:
            return int(ctx)
        except (TypeError, ValueError):
            return 0
    mid = str(model_row.get("id", model_row.get("model_id", "")))
    return mid.lower()


def _command_permission_context(command_name: str, correlation_id: Optional[str] = None) -> Dict[str, Any]:
    return {
        "role": "coordinator",
        "name": f"main:{command_name}",
        "source": "main",
        "approval_scope": "workspace",
        "correlation_id": correlation_id or uuid.uuid4().hex[:12],
    }


async def _provider_fanout_hint(client: MSaplingClient) -> Optional[int]:
    try:
        data = await client.get_active_streams()
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    try:
        limit = int(data.get("limit") or 0)
        active = int(data.get("active_stream_count") or 0)
    except (TypeError, ValueError):
        return None
    if limit <= 0:
        return None
    return max(1, min(8, limit - active))


def _extract_unified_diff(text: str) -> str:
    """Strip prose/code-fence wrappers from LLM output and keep unified diff only."""
    return _workflow_extract_unified_diff(text)


def _render_evidence_table(evidence: List[Dict[str, Any]]) -> None:
    if not evidence:
        return
    table = Table(title="Change Evidence")
    table.add_column("File", style="cyan")
    table.add_column("Line", justify="right")
    table.add_column("Snippet")
    for item in evidence[:20]:
        snippet = str(item.get("snippet", "")).replace("\n", " ").strip()
        table.add_row(
            str(item.get("file", "?")),
            str(item.get("line", "?")),
            snippet[:120],
        )
    console.print(table)


async def _apply_diff_with_fallback(
    *,
    client: MSaplingClient,
    path: Path,
    original: str,
    diff_text: str,
    raw_response: str,
) -> Dict[str, Any]:
    """Apply an LLM-proposed diff with API-first and local fallbacks."""
    result: Dict[str, Any] = {}
    applied = False
    new_content = ""

    try:
        result = await client.apply_diff(original, diff_text, file_path=str(path))
    except Exception as exc:
        result = {"error": str(exc)}

    if result.get("success") or result.get("new_content") or result.get("applied_content"):
        new_content = result.get("new_content") or result.get("applied_content", "")
        if new_content:
            return {"applied": True, "new_content": new_content, "result": result}

    # If the model emitted malformed non-hunk diff text, try regenerating diff server-side.
    if "@@" not in diff_text:
        try:
            import re as _re2

            new_content_match = _re2.split(r"^\+{3}[^\n]*\n", raw_response, maxsplit=1, flags=_re2.MULTILINE)
            if len(new_content_match) == 2:
                guessed_new_content = new_content_match[1].strip()
                gen_result = await client.generate_diff(
                    old_content=original,
                    new_content=guessed_new_content,
                    filename=path.name,
                )
                regen_diff = gen_result.get("diff", gen_result.get("unified_diff", ""))
                if regen_diff:
                    result2 = await client.apply_diff(original, regen_diff, file_path=str(path))
                    if result2.get("success") or result2.get("new_content") or result2.get("applied_content"):
                        new_content = result2.get("new_content") or result2.get("applied_content", "")
                        if new_content:
                            return {"applied": True, "new_content": new_content, "result": result2}
        except Exception:
            pass

    # Last resort: local `patch` utility if installed.
    try:
        import os as _os
        import subprocess as _sp
        import tempfile as _tf

        with _tf.NamedTemporaryFile(mode="w", suffix=".patch", delete=False, encoding="utf-8") as patch_file:
            patch_file.write(diff_text)
            patch_path = patch_file.name
        try:
            for strip in ("1", "0"):
                proc = _sp.run(
                    ["patch", f"-p{strip}", "--quiet", "-i", patch_path, str(path)],
                    capture_output=True,
                    cwd=str(path.parent),
                    text=True,
                    timeout=20,
                )
                if proc.returncode == 0:
                    applied = True
                    break
        finally:
            _os.unlink(patch_path)
        if applied:
            try:
                new_content = path.read_text(encoding="utf-8")
            except Exception:
                new_content = ""
            return {"applied": True, "new_content": new_content, "result": result}
    except FileNotFoundError:
        pass
    except Exception:
        pass

    return {"applied": False, "new_content": "", "result": result}


def _retarget_single_file_diff(diff_text: str, target_rel: str) -> str:
    """Rewrite basename-only diff headers to target_rel for single-file edits."""
    touched = extract_diff_paths(diff_text)
    if not touched:
        return diff_text
    target_base = Path(target_rel).name.lower()
    if any(Path(path).name.lower() != target_base for path in touched):
        return diff_text

    rewritten: List[str] = []
    for line in diff_text.splitlines():
        if line.startswith("diff --git "):
            rewritten.append(f"diff --git a/{target_rel} b/{target_rel}")
        elif line.startswith("--- "):
            src = line[4:].strip().split("\t", 1)[0]
            if src not in {"/dev/null", "nul"}:
                rewritten.append(f"--- a/{target_rel}")
            else:
                rewritten.append(line)
        elif line.startswith("+++ "):
            dst = line[4:].strip().split("\t", 1)[0]
            if dst not in {"/dev/null", "nul"}:
                rewritten.append(f"+++ b/{target_rel}")
            else:
                rewritten.append(line)
        else:
            rewritten.append(line)
    return "\n".join(rewritten)


async def _headless(prompt: str, model: Optional[str], output_format: str, max_turns: int):
    """Non-interactive headless execution. Like `claude -p` or `codex exec`."""
    import json as _json
    settings = get_settings()
    model_id = model or settings.default_model
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run: msapling login[/red]", style="bold red")
        raise SystemExit(1)

    client = MSaplingClient()
    try:
        if max_turns > 1:
            # Agent mode: run tool loop
            from .agent import run_agent_loop
            from .local import detect_project_root
            project_root, _ = detect_project_root(".")
            messages: list = []
            result = await run_agent_loop(
                client=client, prompt=prompt, model=model_id,
                project_root=project_root, messages=messages,
                on_text=None,
                permission_context={
                    "role": "coordinator",
                    "name": "headless",
                    "source": "headless",
                    "approval_scope": "workspace",
                },
            )
            if output_format == "json":
                print(_json.dumps({"response": result, "model": model_id}))
            else:
                print(result)
        else:
            # Single-shot streaming
            async with working_spinner("Connecting"):
                chat_id = await client.ensure_utility_chat(model=model_id)
            parts = []
            usage_data = {}
            async for chunk in client.stream_chat(
                chat_id=chat_id, prompt=prompt, model=model_id,
            ):
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
                    if output_format == "stream-json":
                        print(_json.dumps({"type": "content", "text": content}))
                if chunk.get("type") == "usage":
                    usage_data = chunk
            response = "".join(parts)
            if output_format == "json":
                print(_json.dumps({
                    "response": response, "model": model_id,
                    "tokens": usage_data.get("usage", {}).get("total_tokens", 0),
                    "cost": usage_data.get("cost", 0),
                }))
            elif output_format == "stream-json":
                print(_json.dumps({"type": "done", "tokens": usage_data.get("usage", {}).get("total_tokens", 0)}))
            else:
                print(response)
    except Exception as e:
        if output_format == "json":
            print(_json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]{e}[/red]")
        raise SystemExit(1)
    finally:
        await client.close()


def _get_user_or_exit() -> dict:
    """Fetch user info (TTL-cached). Exits if not authenticated. Handles offline."""
    import time as _time
    global _cached_user_ts
    require_auth(get_token())
    if _cached_user and (_time.monotonic() - _cached_user_ts) < _CACHED_USER_TTL:
        return _cached_user

    async def _fetch():
        client = MSaplingClient()
        try:
            user = await client.me()
            _cached_user.clear()
            _cached_user.update(user)
            global _cached_user_ts
            _cached_user_ts = _time.monotonic()
            return user
        except OfflineError:
            console.print("[red]Cannot reach MSapling API. Check your connection or use offline commands (scan, context, git).[/red]")
            raise SystemExit(1)
        except Exception as e:
            console.print(f"[red]Auth failed: {e}[/red]")
            raise SystemExit(1)
        finally:
            await client.close()

    return _run(_fetch())


# ─── Auth ─────────────────────────────────────────────────────────────

@app.command()
def register(
    email: str = typer.Option(..., prompt=True),
    password: str = typer.Option(..., prompt=True, hide_input=True, confirmation_prompt=True),
    api_url: Optional[str] = typer.Option(None, help="API URL override"),
    force_insecure: bool = typer.Option(False, "--force-insecure", help="Save token in plaintext if keyring is unavailable"),
):
    """Create a new MSapling account from the terminal."""
    async def _register():
        client = MSaplingClient(api_url=api_url)
        try:
            http = await client._get_client()
            resp = await http.post("/auth/register", json={
                "email": email,
                "password": password,
            })
            if resp.status_code in (200, 201):
                console.print(f"[green]Account created for {email}[/green]")
                console.print("[dim]Logging in...[/dim]")
                # Auto-login after register
                await client.login(email, password)
                if client.token:
                    save_token(client.token, force_insecure=force_insecure)
                    if api_url:
                        settings = get_settings()
                        settings.api_url = api_url
                        save_settings(settings)
                    user = await client.me()
                    console.print(f"[green]Logged in as {user.get('email', email)}[/green]")
                    console.print(f"  Tier: {user.get('tier', 'free')}")
                    console.print(f"  Fuel: ${user.get('fuel_credits', 0):.4f}")
            elif resp.status_code == 400:
                detail = resp.json().get("detail", "Registration failed")
                console.print(f"[red]{detail}[/red]")
            elif resp.status_code == 409:
                console.print(f"[yellow]Account already exists for {email}. Use: msapling login[/yellow]")
            else:
                console.print(f"[red]Registration failed (HTTP {resp.status_code})[/red]")
        except Exception as e:
            console.print(f"[red]Registration failed: {e}[/red]")
        finally:
            await client.close()

    _run(_register())


@app.command()
def login(
    email: str = typer.Option(..., prompt=True),
    password: str = typer.Option(..., prompt=True, hide_input=True),
    api_url: Optional[str] = typer.Option(None, help="API URL override"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Dump raw HTTP traffic for debugging"),
    force_insecure: bool = typer.Option(False, "--force-insecure", help="Save token in plaintext if keyring is unavailable"),
):
    """Authenticate with MSapling backend.

    Token precedence (highest to lowest):
      1. MSAPLING_TOKEN environment variable
      2. System keyring (macOS Keychain / Windows Credential Store)
      3. ~/.msapling/token (Legacy/Insecure — requires --force-insecure)

    Run 'msapling doctor' to see which source is currently active.
    """
    async def _login():
        client = MSaplingClient(api_url=api_url)
        try:
            result = await client.login(email, password)
            if client.token:
                save_token(client.token, force_insecure=force_insecure)
                if api_url:
                    settings = get_settings()
                    settings.api_url = api_url
                    save_settings(settings)
                user = await client.me()
                console.print(f"[green]Logged in as {user.get('email', email)}[/green]")
                console.print(f"  Tier: {user.get('tier', 'free')}")
                console.print(f"  Fuel: ${user.get('fuel_credits', 0):.4f}")
                return True
            else:
                console.print("[red]Login failed - no token received[/red]")
                return False
        except Exception as e:
            console.print(f"[red]Login failed: {e}[/red]")
            if verbose:
                import traceback
                console.print(f"[dim]{traceback.format_exc()}[/dim]")
            return False
        finally:
            await client.close()

    ok = _run(_login())
    if not ok:
        raise typer.Exit(1)


@app.command()
def logout(force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt")):
    """Clear saved authentication."""
    if not force:
        from rich.prompt import Confirm
        if not Confirm.ask("Log out and clear saved credentials?", default=False):
            console.print("[dim]Cancelled.[/dim]")
            return
    clear_token()
    _cached_user.clear()
    global _cached_user_ts
    _cached_user_ts = 0.0
    console.print("[yellow]Logged out[/yellow]")


@app.command()
def whoami():
    """Show current user info."""
    async def _whoami() -> bool:
        client = MSaplingClient()
        try:
            async with working_spinner("Fetching account"):
                user = await client.me()
            table = Table(title="Account")
            table.add_column("Field", style="cyan")
            table.add_column("Value")
            table.add_row("Email", str(user.get("email", "?")))
            table.add_row("Tier", str(user.get("tier", "free")))
            table.add_row("Fuel Credits", f"${user.get('fuel_credits', 0):.4f}")
            table.add_row("Pro", str(user.get("is_pro", False)))
            console.print(table)
            return True
        except Exception as e:
            console.print(f"[red]Not authenticated: {e}[/red]")
            return False
        finally:
            await client.close()

    if not _run(_whoami()):
        raise typer.Exit(1)


# ─── Chat ─────────────────────────────────────────────────────────────

@app.command()
def streams(
    json_output: bool = typer.Option(False, "--json", help="Print raw JSON response"),
):
    """Show account-wide active stream usage (web/cli/app)."""

    def _short_chat(chat_id: object) -> str:
        value = str(chat_id or "").strip()
        if not value:
            return "unknown"
        if len(value) <= 12:
            return value
        return f"{value[:8]}..."

    def _mask_session(session_id: object) -> str:
        value = str(session_id or "").strip()
        if not value:
            return "unknown"
        if len(value) <= 8:
            return value
        return f"{value[:4]}...{value[-2:]}"

    def _started_label(started_at: object) -> str:
        try:
            value = float(started_at or 0.0)
        except Exception:
            return "n/a"
        if value <= 0:
            return "n/a"
        if value > 1_000_000_000:
            age = max(0, int(time.time() - value))
            if age < 60:
                return f"{age}s ago"
            mins = age // 60
            if mins < 60:
                return f"{mins}m ago"
            hours = mins // 60
            return f"{hours}h ago"
        return "active"

    async def _streams() -> int:
        client = MSaplingClient()
        try:
            async with working_spinner("Fetching active streams"):
                data = await client.get_active_streams()

            if json_output:
                import json as _json
                console.print(_json.dumps(data))
                return 0

            active_count = int(data.get("active_stream_count") or 0)
            limit = int(data.get("limit") or 0)
            tier = str(data.get("tier") or "unknown")
            stream_rows = data.get("active_streams") if isinstance(data.get("active_streams"), list) else []
            at_limit = limit > 0 and active_count >= limit

            summary = f"Account streams: {active_count}/{limit}" if limit > 0 else f"Account streams: {active_count}"
            summary += f" ({tier})"
            if at_limit:
                console.print(f"[yellow]{summary} [LIMIT][/yellow]")
            else:
                console.print(f"[cyan]{summary}[/cyan]")

            if not stream_rows:
                console.print("[dim]No active streams.[/dim]")
                return 0

            table = Table(title="Active Streams")
            table.add_column("Surface", style="cyan")
            table.add_column("Session")
            table.add_column("Chat")
            table.add_column("Status")
            table.add_column("Started")

            for row in stream_rows[:32]:
                if not isinstance(row, dict):
                    continue
                surface = str(row.get("client_type") or "unknown").upper()
                session = _mask_session(row.get("session_id"))
                chat = _short_chat(row.get("chat_id"))
                status = str(row.get("status") or "streaming")
                started = _started_label(row.get("started_at"))
                table.add_row(surface, session, chat, status, started)

            console.print(table)
            if at_limit:
                console.print("[yellow]Stream cap reached. Finish one active chat before starting another.[/yellow]")
            return 0
        except Exception as e:
            _handle_api_error(e, "streams")
            return 1
        finally:
            await client.close()

    exit_code = _run(_streams())
    if exit_code:
        raise typer.Exit(exit_code)

@app.command()
def chat(
    prompt: Optional[str] = typer.Argument(None, help="Message to send"),
    model: Optional[str] = typer.Option(None, "-m", help="Model ID"),
    provider: Optional[str] = typer.Option(None, "--provider", help="Provider: ollama|openrouter|anthropic|openai|google|auto"),
    ollama_url: Optional[str] = typer.Option(None, "--ollama-url", help="Ollama base URL (default: http://localhost:11434)"),
    project: Optional[str] = typer.Option(None, "-p", help="Project name"),
    interactive: bool = typer.Option(False, "-i", help="Interactive session"),
    agent: bool = typer.Option(False, "-a", help="Enable agent mode"),
    save: Optional[str] = typer.Option(None, "--save", "-o", help="Save response to file"),
    system_prompt: Optional[str] = typer.Option(None, "--system", "-s", help="System prompt / context to prepend"),
    cwd: Optional[str] = typer.Option(None, "--cwd", help="Working directory for all file operations (use with worktrees)"),
    ephemeral: bool = typer.Option(False, "--ephemeral", help="Create a hidden chat — won't appear in web/app sidebar."),
):
    """Chat with an LLM. Use -i for interactive session.

    Free tier: Flash, Haiku, Mini, Llama, Mistral models only.
    Pro tier: All models + unlimited messages.

    Examples:
        msapling chat "Explain async/await" --save output.md
        msapling chat "Review this code" --system "You are a senior Python engineer"
        msapling chat --provider ollama --model llama3 "Hello"
        msapling chat -i --cwd /path/to/worktree   # scoped to a git worktree
    """
    # --cwd: change working directory for all file operations (worktree support)
    if cwd:
        cwd_path = Path(cwd).resolve()
        if not cwd_path.is_dir():
            console.print(f"[red]--cwd path does not exist or is not a directory: {cwd}[/red]")
            raise typer.Exit(1)
        os.chdir(str(cwd_path))
        os.environ["MSAPLING_CWD"] = str(cwd_path)

    from .completer import resolve_model
    settings = get_settings()

    # When --provider ollama is given, force the model into ollama/ namespace.
    provider_lower = str(provider or "").strip().lower()
    if provider_lower == "ollama":
        raw_model_name = str(model or "").strip()
        if raw_model_name and not raw_model_name.lower().startswith("ollama/"):
            raw_model = f"ollama/{raw_model_name}"
        elif raw_model_name:
            raw_model = raw_model_name
        else:
            raw_model = settings.default_model
            if not str(raw_model).lower().startswith("ollama/"):
                console.print(
                    "[yellow]--provider ollama requires a model name. "
                    "Use -m <model> or msapling ollama use <model>[/yellow]"
                )
                raise typer.Exit(1)
    else:
        raw_model = model or settings.default_model

    model_id, was_fuzzy = resolve_model(raw_model)
    if was_fuzzy and model:
        console.print(f"[dim]Model: {model} -> {model_id}[/dim]")

    # If --provider ollama is set, expose MSAPLING_PROVIDER and MSAPLING_OLLAMA_URL
    # in the process environment so downstream code and tests can inspect them.
    # --ollama-url flag takes priority over env and settings.
    if provider_lower == "ollama":
        os.environ["MSAPLING_PROVIDER"] = "ollama"
        resolved_ollama_url = (
            str(ollama_url or "").strip()
            or os.environ.get("MSAPLING_OLLAMA_URL")
            or str(getattr(settings, "ollama_base_url", "http://localhost:11434")).rstrip("/")
        )
        os.environ["MSAPLING_OLLAMA_URL"] = resolved_ollama_url.rstrip("/")

    is_local_ollama = (
        str(model_id or "").lower().startswith("ollama/")
        or provider_lower == "ollama"
    )
    if not is_local_ollama:
        user = _get_user_or_exit()
        require_pro(user, "chat", model_id)
    # chat_id is resolved server-side so the backend has a real ChatSession row
    _resolved_chat_id: Optional[str] = None
    chat_failed = False

    async def _chat_once(msg: str):
        nonlocal _resolved_chat_id, chat_failed
        client = MSaplingClient()
        try:
            # Ensure a real server-side chat exists before first message
            if not _resolved_chat_id and not is_local_ollama:
                _resolved_chat_id = await client.ensure_server_chat(
                    project_name=project or "",
                    title="CLI Chat",
                    model=model_id,
                    client_type="cli",
                )
            # Clear stale locks from prior interrupted CLI sessions before sending.
            if _resolved_chat_id:
                with suppress(Exception):
                    await client.force_release_lock(_resolved_chat_id)
            # Prepend system prompt if provided
            effective_msg = msg
            if system_prompt and system_prompt.strip():
                effective_msg = f"[System context: {system_prompt.strip()}]\n\n{msg}"
            parts = []

            if save:
                # Non-interactive save path: stream without Live to avoid terminal
                # manipulation that interferes with test runners and redirected stdout.
                async for chunk in client.stream_chat(
                    chat_id=_resolved_chat_id,
                    prompt=effective_msg,
                    model=model_id,
                    project_name=project,
                    agent_mode=agent,
                ):
                    content = chunk.get("content", "")
                    if content:
                        parts.append(content)
                if parts:
                    save_path = Path(save)
                    save_path.write_text("".join(parts), encoding="utf-8")
                    typer.echo(f"Saved to {save_path}")
                else:
                    typer.echo("No response received")
            else:
                started_at = time.monotonic()

                def _render_stream_state():
                    if parts:
                        return Markdown("".join(parts))
                    return render_working_panel("Thinking", time.monotonic() - started_at)

                with Live(_render_stream_state(), console=console, refresh_per_second=12, redirect_stderr=False) as live:
                    keep_refreshing = True

                    async def _refresh_live():
                        while keep_refreshing:
                            live.update(_render_stream_state())
                            await asyncio.sleep(0.1)

                    refresher = asyncio.create_task(_refresh_live())
                    try:
                        async for chunk in client.stream_chat(
                            chat_id=_resolved_chat_id,
                            prompt=effective_msg,
                            model=model_id,
                            project_name=project,
                            agent_mode=agent,
                        ):
                            content = chunk.get("content", "")
                            if content:
                                parts.append(content)
                                live.update(_render_stream_state())
                            if chunk.get("type") == "usage":
                                usage = chunk.get("usage", {})
                                tokens = usage.get("total_tokens", 0)
                                cost = chunk.get("cost", 0)
                                console.print(f"\n[dim]({tokens} tokens, ${cost:.4f})[/dim]")
                    finally:
                        keep_refreshing = False
                        refresher.cancel()
                        try:
                            await refresher
                        except asyncio.CancelledError:
                            pass
                if not parts:
                    console.print("[yellow]No response received[/yellow]")
        except Exception as e:
            chat_failed = True
            _handle_api_error(e, "chat")
        finally:
            await client.close()

    if interactive:
        console.print(f"[cyan]MSapling Chat[/cyan] | model: {model_id} | type 'exit' to quit")
        console.print("─" * 60)
        while True:
            try:
                msg = Prompt.ask("[bold green]You[/bold green]")
                if msg.lower() in ("exit", "quit", "q"):
                    break
                if not msg.strip():
                    continue
                _run(_chat_once(msg))
                console.print()
            except (KeyboardInterrupt, EOFError):
                break
        console.print("[yellow]Session ended[/yellow]")
    elif prompt:
        _run(_chat_once(prompt))
        if chat_failed:
            raise typer.Exit(1)
    else:
        console.print("[yellow]Provide a prompt or use -i for interactive mode[/yellow]")


# ─── Multi-Chat & Swarm ───────────────────────────────────────────────

@app.command()
def multi(
    prompt: str = typer.Argument(..., help="Prompt to send to all models"),
    models: Optional[str] = typer.Option(
        None,
        "-m", help="Comma-separated model IDs (default: enabled agents registry models)",
    ),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    max_attempts: int = typer.Option(3, "--max-attempts", help="Max transient retry attempts", min=1, max=8),
    backoff_s: float = typer.Option(0.35, "--backoff-s", help="Initial retry backoff seconds", min=0.0, max=5.0),
    strict: bool = typer.Option(False, "--strict", help="Exit nonzero if any model run fails"),
):
    """Send the same prompt to multiple models in parallel. Compare responses side-by-side.

    Requires Pro subscription.
    """
    user = _get_user_or_exit()
    require_pro(user, "multi")
    import json as _json
    model_list = _parse_models_option(models, limit=3)
    if not model_list:
        console.print("[red]Error: model list is empty. Provide at least one model with -m[/red]")
        raise typer.Exit(1)
    _enforce_registry_lane_caps(model_list)

    async def _multi():
        client = MSaplingClient()
        try:
            remaining = list(model_list)
            results_by_model: dict[str, dict[str, Any]] = {}
            attempt = 0
            retried_models = 0
            permission_context = _command_permission_context("multi")
            provider_hint = await _provider_fanout_hint(client)
            fanout_cap = _adaptive_fanout_cap_with_hint(
                model_list,
                command_name="multi",
                provider_hint=provider_hint,
            )

            while remaining and attempt < max_attempts:
                attempt += 1
                batch_models = list(remaining)
                remaining = []
                indexed: dict[str, dict[str, Any]] = {}
                for i in range(0, len(batch_models), fanout_cap):
                    chunk_models = batch_models[i : i + fanout_cap]
                    try:
                        if output == "json":
                            batch_results = await client.multi_chat(
                                prompt,
                                chunk_models,
                                permission_context=permission_context,
                            )
                        else:
                            with Status(
                                f"Querying {len(chunk_models)} model(s) (attempt {attempt}/{max_attempts})...",
                                console=console,
                            ):
                                batch_results = await client.multi_chat(
                                    prompt,
                                    chunk_models,
                                    permission_context=permission_context,
                                )
                    except Exception as exc:
                        if _is_transient_exception(exc) and attempt < max_attempts:
                            remaining.extend(chunk_models)
                            retried_models += len(chunk_models)
                            continue
                        raise
                    for item in batch_results:
                        if not isinstance(item, dict):
                            continue
                        model_id = str(item.get("model") or "").strip()
                        if model_id:
                            indexed[model_id] = item

                for model_id in batch_models:
                    if model_id in remaining:
                        continue
                    raw = indexed.get(model_id)
                    if raw is None:
                        raw = {
                            "model": model_id,
                            "response": "",
                            "status": "error",
                            "error": "No response returned for model",
                            "error_code": "missing_response",
                            "http_status": None,
                            "provider": None,
                            "retryable": False,
                        }
                    status = str(raw.get("status") or "").lower()
                    if status == "ok":
                        results_by_model[model_id] = {
                            "model": model_id,
                            "response": str(raw.get("response") or ""),
                            "status": "ok",
                        }
                        continue

                    err_text = str(raw.get("error") or raw.get("response") or "Unknown model failure")
                    if _is_transient_error_text(err_text) and attempt < max_attempts:
                        remaining.append(model_id)
                        retried_models += 1
                        continue

                    error_code = str(raw.get("error_code") or "")
                    http_status = raw.get("http_status")
                    provider_name = raw.get("provider")
                    retryable = raw.get("retryable")
                    if not error_code:
                        error_code = (
                            f"http_{http_status}" if isinstance(http_status, int) else "model_error"
                        )
                    if retryable is None:
                        retryable = _is_transient_error_text(err_text)

                    results_by_model[model_id] = {
                        "model": model_id,
                        "response": "",
                        "status": "error",
                        "error": err_text,
                        "error_code": error_code,
                        "http_status": http_status if isinstance(http_status, int) else None,
                        "provider": provider_name if provider_name else None,
                        "retryable": bool(retryable),
                    }

                if remaining and attempt < max_attempts:
                    wait_s = backoff_s * (2 ** (attempt - 1))
                    if output != "json":
                        console.print(
                            f"[yellow]multi: retrying {len(remaining)} transient model failure(s) "
                            f"({attempt + 1}/{max_attempts})[/yellow]"
                        )
                    if wait_s > 0:
                        await asyncio.sleep(wait_s)

            for model_id in model_list:
                if model_id not in results_by_model:
                    results_by_model[model_id] = {
                        "model": model_id,
                        "response": "",
                        "status": "error",
                        "error": "Retry budget exhausted",
                        "error_code": "retry_budget_exhausted",
                        "http_status": None,
                        "provider": None,
                        "retryable": False,
                    }

            results = [results_by_model[m] for m in model_list]
            success_count = sum(1 for r in results if str(r.get("status")) == "ok")
            failure_count = len(results) - success_count

            if output == "json":
                Console().print(_json.dumps(results))
            else:
                for r in results:
                    status_color = "green" if r["status"] == "ok" else "red"
                    err_meta = ""
                    if r.get("status") != "ok":
                        err_bits = []
                        if r.get("error_code"):
                            err_bits.append(str(r.get("error_code")))
                        if r.get("http_status") is not None:
                            err_bits.append(f"http={r.get('http_status')}")
                        if r.get("provider"):
                            err_bits.append(f"provider={r.get('provider')}")
                        if r.get("retryable") is not None:
                            err_bits.append(f"retryable={bool(r.get('retryable'))}")
                        if err_bits:
                            err_meta = "\n[dim]" + " | ".join(err_bits) + "[/dim]"
                    console.print(Panel(
                        Markdown(r["response"][:3000]) if r["response"] else f"[red]{r.get('error', 'No response')}[/red]{err_meta}",
                        title=f"[{status_color}]{r['model']}[/{status_color}]",
                        border_style=status_color,
                    ))
                console.print(
                    f"[bold]Multi summary:[/bold] "
                    f"[green]{success_count} succeeded[/green], "
                    f"[red]{failure_count} failed[/red], "
                    f"[cyan]{retried_models} retried[/cyan]"
                )
                if failure_count > 0 and success_count > 0 and not strict:
                    console.print("[yellow]Partial success: returning best available outputs.[/yellow]")

            if strict and failure_count > 0:
                raise typer.Exit(1)
            if success_count == 0:
                raise typer.Exit(1)
        except Exception as e:
            _handle_api_error(e, "multi")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_multi())


@app.command()
def swarm(
    prompt: str = typer.Argument(..., help="Task for the swarm"),
    models: Optional[str] = typer.Option(
        None,
        "-m",
        help="Comma-separated models (default: enabled agents registry models)",
    ),
    judge: Optional[str] = typer.Option(None, "-j", help="Judge model for synthesis"),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    max_attempts: int = typer.Option(3, "--max-attempts", help="Max transient retry attempts", min=1, max=8),
    backoff_s: float = typer.Option(0.35, "--backoff-s", help="Initial retry backoff seconds", min=0.0, max=5.0),
    strict: bool = typer.Option(False, "--strict", help="Exit nonzero if any agent run fails"),
):
    """Run a multi-model swarm: N models answer in parallel, then a judge synthesizes.

    Requires Pro subscription.

    Example:
        msapling swarm "explain async/await" -m "gpt-4o,claude-3.5-sonnet,gemini-pro"
    """
    user = _get_user_or_exit()
    require_pro(user, "swarm")
    resolved_models = _parse_models_option(models, limit=3)
    _enforce_registry_lane_caps(resolved_models)

    import json as _json

    async def _swarm():
        client = MSaplingClient()
        try:
            result: Optional[dict[str, Any]] = None
            retry_count = 0
            permission_context = _command_permission_context("swarm")
            provider_hint = await _provider_fanout_hint(client)
            fanout_cap = _adaptive_fanout_cap_with_hint(
                resolved_models,
                command_name="swarm",
                provider_hint=provider_hint,
            )

            async def _swarm_chunked_backpressure() -> dict[str, Any]:
                started = time.monotonic()
                agent_rows: List[Dict[str, Any]] = []
                for i in range(0, len(resolved_models), fanout_cap):
                    chunk = resolved_models[i : i + fanout_cap]
                    chunk_rows = await client.multi_chat(
                        prompt,
                        chunk,
                        permission_context=permission_context,
                    )
                    agent_rows.extend(chunk_rows)
                judge_model = judge or (resolved_models[0] if resolved_models else "")
                synthesis = ""
                if judge_model:
                    lines = []
                    for row in agent_rows:
                        status = "OK" if str(row.get("status") or "").lower() == "ok" else "FAILED"
                        snippet = str(row.get("response") or row.get("error") or "")[:2000]
                        lines.append(f"[{row.get('model', '?')} - {status}]:\n{snippet}")
                    synthesis_prompt = (
                        "You are a synthesis judge. Multiple AI models were asked the same question.\n\n"
                        f"Original question: {prompt}\n\n"
                        "Their responses:\n\n"
                        + "\n\n---\n\n".join(lines)
                        + "\n\nSynthesize the best answer. Combine strengths, note disagreements, give a final answer."
                    )
                    synthesis = await client.chat_once(
                        synthesis_prompt,
                        judge_model,
                        permission_context=permission_context,
                    )
                return {
                    "agent_responses": agent_rows,
                    "synthesis": synthesis,
                    "judge_model": judge_model,
                    "models_used": list(resolved_models),
                    "latency_ms": int((time.monotonic() - started) * 1000),
                    "usage": _sum_usage_rows(agent_rows),
                }

            for attempt in range(1, max_attempts + 1):
                try:
                    if output == "json":
                        if len(resolved_models) > fanout_cap:
                            candidate = await _swarm_chunked_backpressure()
                        else:
                            candidate = await client.swarm(
                                prompt,
                                models=resolved_models,
                                synthesize_model=judge,
                                permission_context=permission_context,
                            )
                    else:
                        with Status(
                            f"Running swarm (attempt {attempt}/{max_attempts})...",
                            console=console,
                        ):
                            if len(resolved_models) > fanout_cap:
                                candidate = await _swarm_chunked_backpressure()
                            else:
                                candidate = await client.swarm(
                                    prompt,
                                    models=resolved_models,
                                    synthesize_model=judge,
                                    permission_context=permission_context,
                                )
                except Exception as exc:
                    if _is_transient_exception(exc) and attempt < max_attempts:
                        retry_count += 1
                        wait_s = backoff_s * (2 ** (attempt - 1))
                        if output != "json":
                            console.print(
                                f"[yellow]swarm: transient error, retrying "
                                f"({attempt + 1}/{max_attempts})[/yellow]"
                            )
                        if wait_s > 0:
                            await asyncio.sleep(wait_s)
                        continue
                    raise

                agent_rows = candidate.get("agent_responses", []) if isinstance(candidate, dict) else []
                success_count = sum(
                    1 for r in agent_rows
                    if isinstance(r, dict) and str(r.get("status") or "").lower() == "ok"
                )
                failures = [
                    r for r in agent_rows
                    if isinstance(r, dict) and str(r.get("status") or "").lower() != "ok"
                ]
                transient_failures = [
                    r for r in failures
                    if _is_transient_error_text(str(r.get("error") or r.get("response") or ""))
                ]
                synthesis_text = str(candidate.get("synthesis") or "") if isinstance(candidate, dict) else ""

                should_retry = (
                    attempt < max_attempts
                    and bool(transient_failures)
                    and (success_count == 0 or not synthesis_text.strip())
                )
                if should_retry:
                    retry_count += 1
                    wait_s = backoff_s * (2 ** (attempt - 1))
                    if output != "json":
                        console.print(
                            f"[yellow]swarm: transient agent failures detected, retrying "
                            f"({attempt + 1}/{max_attempts})[/yellow]"
                        )
                    if wait_s > 0:
                        await asyncio.sleep(wait_s)
                    continue

                result = candidate
                break

            if result is None:
                raise RuntimeError("Swarm failed without returning a result.")

            agent_rows = result.get("agent_responses", []) if isinstance(result, dict) else []
            success_count = sum(
                1 for r in agent_rows
                if isinstance(r, dict) and str(r.get("status") or "").lower() == "ok"
            )
            failure_count = len(agent_rows) - success_count
            synthesis_text = str(result.get("synthesis") or "") if isinstance(result, dict) else ""

            if output == "json":
                Console().print(_json.dumps(result))
            else:
                # Show individual agent responses
                for r in result["agent_responses"]:
                    status = "OK" if r["status"] == "ok" else "FAIL"
                    console.print(f"\n-- {r['model']} ({status}) --")
                    if r.get("response"):
                        console.print(Markdown(r["response"][:1500]))
                    elif r.get("error"):
                        console.print(f"[red]{r['error']}[/red]")
                        err_bits = []
                        if r.get("error_code"):
                            err_bits.append(str(r.get("error_code")))
                        if r.get("http_status") is not None:
                            err_bits.append(f"http={r.get('http_status')}")
                        if r.get("provider"):
                            err_bits.append(f"provider={r.get('provider')}")
                        if r.get("retryable") is not None:
                            err_bits.append(f"retryable={bool(r.get('retryable'))}")
                        if err_bits:
                            console.print(f"[dim]{' | '.join(err_bits)}[/dim]")

                # Show synthesis
                console.print(Panel(
                    Markdown(result["synthesis"]),
                    title=f"[bold cyan]Synthesis by {result['judge_model']}[/bold cyan]",
                    border_style="cyan",
                ))
                console.print(f"[dim]Models used: {', '.join(result['models_used'])}[/dim]")
                console.print(
                    f"[bold]Swarm summary:[/bold] "
                    f"[green]{success_count} agent(s) succeeded[/green], "
                    f"[red]{failure_count} failed[/red], "
                    f"[cyan]{retry_count} retried[/cyan]"
                )
                if failure_count > 0 and success_count > 0 and not strict:
                    console.print("[yellow]Partial success: returning best available outputs.[/yellow]")
                if not synthesis_text.strip():
                    console.print("[yellow]Synthesis was empty.[/yellow]")

            if strict and (failure_count > 0 or not synthesis_text.strip()):
                raise typer.Exit(1)
            if success_count == 0:
                raise typer.Exit(1)
        except Exception as e:
            _handle_api_error(e, "swarm")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_swarm())


# ─── Code Editing ─────────────────────────────────────────────────────

@app.command()
def edit(
    instruction: str = typer.Argument(..., help="What to change"),
    filepath: str = typer.Argument(..., help="File to edit"),
    model: Optional[str] = typer.Option(None, "-m", help="Model ID"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show diff without applying"),
    repo_grounded: bool = typer.Option(
        True,
        "--repo-grounded/--no-repo-grounded",
        help="Require file targets and diff paths to resolve to indexed workspace files.",
    ),
    verify: bool = typer.Option(
        True,
        "--verify/--no-verify",
        help="Run post-edit verification; rollback file if validation still fails.",
    ),
    verify_cmd: List[str] = typer.Option(
        None,
        "--verify-cmd",
        help="Verification command to run (repeatable).",
    ),
    repair_attempts: int = typer.Option(
        1,
        "--repair-attempts",
        min=0,
        max=5,
        help="Automatic repair retries after verification/apply failures.",
    ),
    require_evidence: bool = typer.Option(
        True,
        "--require-evidence/--no-require-evidence",
        help="Require structured evidence (file,line,snippet) from each proposed diff.",
    ),
):
    """Edit a file using natural language instructions.

    Requires Pro subscription.
    """
    user = _get_user_or_exit()
    require_pro(user, "edit")
    workspace_root = detect_workspace_root(Path(filepath).expanduser().parent)
    workspace_index = build_workspace_index(workspace_root) if repo_grounded else set()
    try:
        path, target_rel = validate_repo_target(
            filepath,
            workspace_root=workspace_root,
            workspace_index=workspace_index if repo_grounded else None,
        )
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)

    original = path.read_text(encoding="utf-8")
    settings = get_settings()
    model_id = model or settings.default_model
    default_verify = build_default_verify_commands(target_rel, workspace_root=workspace_root)
    verify_commands = [str(cmd).strip() for cmd in (verify_cmd or default_verify) if str(cmd).strip()]

    async def _edit():
        client = MSaplingClient()
        current_content = original
        verification_feedback = ""
        max_attempts = max(1, int(repair_attempts) + 1)
        try:
            for attempt in range(1, max_attempts + 1):
                if attempt == 1:
                    console.print(f"[cyan]Generating edit for {target_rel}...[/cyan]")
                else:
                    console.print(
                        f"[yellow]Repair attempt {attempt - 1}/{max_attempts - 1} "
                        f"for {target_rel}...[/yellow]"
                    )

                prompt_text = (
                    f"Edit the following file according to this instruction: {instruction}\n\n"
                    f"Workspace root: {workspace_root}\n"
                    f"Target file: {target_rel}\n"
                    f"Current file content:\n```\n{current_content}\n```\n\n"
                    "Return ONLY a unified diff (no explanation). Start with --- and +++."
                )
                if verification_feedback:
                    prompt_text += (
                        "\n\nPrevious attempt failed validation. Fix it while preserving intent.\n"
                        f"Validation output:\n{verification_feedback}\n"
                    )

                raw = await client.chat_once(prompt_text, model_id, history_enabled=False)
                diff_text = normalize_unified_diff_headers(_extract_unified_diff(raw))
                diff_text = _retarget_single_file_diff(diff_text, target_rel)
                if not diff_text.strip():
                    if attempt < max_attempts:
                        verification_feedback = "Model returned empty diff."
                        continue
                    console.print("[red]Model returned empty diff output.[/red]")
                    raise typer.Exit(1)

                if repo_grounded:
                    try:
                        enforce_repo_grounded_diff(
                            diff_text,
                            workspace_index=workspace_index,
                            allowed_paths=[target_rel],
                        )
                    except ValueError as exc:
                        console.print(f"[red]{exc}[/red]")
                        raise typer.Exit(1)

                evidence = extract_structured_evidence(diff_text, default_file=target_rel)
                if require_evidence and not evidence:
                    console.print(
                        "[red]Evidence guardrail failed: no structured {file,line,snippet} "
                        "evidence could be derived from proposed diff.[/red]"
                    )
                    raise typer.Exit(1)

                console.print(
                    Panel(
                        Syntax(diff_text, "diff", theme="monokai"),
                        title=f"Proposed changes to {target_rel}",
                    )
                )
                _render_evidence_table(evidence)

                if dry_run:
                    console.print("[yellow]Dry run - no changes applied[/yellow]")
                    return

                apply_result = await _apply_diff_with_fallback(
                    client=client,
                    path=path,
                    original=current_content,
                    diff_text=diff_text,
                    raw_response=raw,
                )
                if not bool(apply_result.get("applied")):
                    err_msg = str((apply_result.get("result") or {}).get("error") or "unknown")
                    if attempt < max_attempts:
                        verification_feedback = f"Diff application failed: {err_msg}"
                        continue
                    console.print(f"[red]Failed to apply diff: {err_msg}[/red]")
                    console.print("[dim]Diff shown above. Apply manually or use --dry-run.[/dim]")
                    raise typer.Exit(1)

                candidate_content = str(apply_result.get("new_content") or "")
                if candidate_content:
                    path.write_text(candidate_content, encoding="utf-8")
                    current_content = candidate_content
                console.print(f"[green]Applied changes to {target_rel}[/green]")

                if not verify:
                    return

                verification = run_verify_commands(verify_commands, cwd=workspace_root)
                if verification.ok:
                    if verify_commands:
                        console.print("[green]Verification passed.[/green]")
                    return

                console.print("[yellow]Verification failed.[/yellow]")
                for step in verification.steps:
                    if not step.ok:
                        console.print(f"[red]$ {step.command} (exit {step.return_code})[/red]")
                        if step.output:
                            console.print(f"[dim]{step.output[:800]}[/dim]")

                verification_feedback = verification.failure_summary()
                if attempt >= max_attempts:
                    path.write_text(original, encoding="utf-8")
                    console.print(
                        "[red]Validation failed after all repair attempts. "
                        "Rolled back file to original content.[/red]"
                    )
                    raise typer.Exit(1)

            raise typer.Exit(1)
        except typer.Exit:
            raise
        except Exception as e:
            _handle_api_error(e, "edit")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_edit())


# ─── Diff ─────────────────────────────────────────────────────────────

@app.command()
def diff(
    old_file: str = typer.Argument(..., help="Original file"),
    new_file: str = typer.Argument(..., help="Modified file"),
):
    """Generate a unified diff between two files."""
    old_path, new_path = Path(old_file), Path(new_file)
    if not old_path.exists():
        console.print(f"[red]File not found: {old_file}[/red]")
        raise typer.Exit(1)
    if not new_path.exists():
        console.print(f"[red]File not found: {new_file}[/red]")
        raise typer.Exit(1)

    old_content = old_path.read_text(encoding="utf-8")
    new_content = new_path.read_text(encoding="utf-8")

    def _local_diff() -> str:
        import difflib as _difflib
        return "".join(
            _difflib.unified_diff(
                old_content.splitlines(keepends=True),
                new_content.splitlines(keepends=True),
                fromfile=f"a/{old_file}",
                tofile=f"b/{new_file}",
            )
        )

    async def _diff():
        client = MSaplingClient()
        try:
            diff_text = ""
            try:
                result = await client.generate_diff(
                    old_content=old_content,
                    new_content=new_content,
                    filename=old_file,
                )
                diff_text = result.get("diff", result.get("unified_diff", ""))
            except Exception as api_err:
                # Production-safe fallback: still provide a usable diff when
                # backend endpoint contracts drift (e.g., temporary 422/5xx).
                diff_text = _local_diff()
                console.print(
                    "[yellow]API diff unavailable; used local fallback "
                    f"({type(api_err).__name__}).[/yellow]"
                )
            if diff_text:
                console.print(Syntax(diff_text, "diff", theme="monokai"))
                added = sum(1 for ln in diff_text.splitlines() if ln.startswith("+") and not ln.startswith("+++"))
                removed = sum(1 for ln in diff_text.splitlines() if ln.startswith("-") and not ln.startswith("---"))
                console.print(f"\n[dim]Diff: [green]+{added}[/green] [red]-{removed}[/red] lines  ({old_file} -> {new_file})[/dim]")
            else:
                console.print("[yellow]Files are identical[/yellow]")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_diff())


# ─── File Operations ──────────────────────────────────────────────────

@app.command(name="ls")
def list_files(
    project_id: str = typer.Option("default", "--project", "-p", help="Project ID"),
    path: str = typer.Option("/", help="Directory path"),
):
    """List files in an MDrive project."""
    async def _ls():
        client = MSaplingClient()
        try:
            async with working_spinner("Listing files"):
                files = await client.list_files(project_id, path)
            if not files:
                console.print("[yellow]No files found[/yellow]")
                return
            table = Table(title=f"Files in {project_id}:{path}")
            table.add_column("Name", style="cyan")
            table.add_column("Size", justify="right")
            table.add_column("Modified")
            for f in files:
                name = f.get("name", f.get("file_path", "?"))
                size = f.get("size", f.get("size_bytes", 0))
                modified = f.get("modified", f.get("updated_at", ""))
                size_str = f"{size / 1024:.1f} KB" if size > 1024 else f"{size} B"
                table.add_row(name, size_str, str(modified)[:19])
            console.print(table)
        except Exception as e:
            _handle_api_error(e, "ls")
        finally:
            await client.close()

    _run(_ls())


@app.command(name="cat")
def read_file(
    project_id: str = typer.Argument(..., help="Project ID"),
    filepath: str = typer.Argument(..., help="File path"),
):
    """Read a file from MDrive."""
    async def _cat():
        client = MSaplingClient()
        try:
            async with working_spinner("Reading file"):
                content = await client.read_file(project_id, filepath)
            ext = Path(filepath).suffix.lstrip(".")
            lang_map = {"py": "python", "ts": "typescript", "js": "javascript", "tsx": "tsx", "md": "markdown"}
            lang = lang_map.get(ext, ext)
            console.print(Syntax(content, lang, theme="monokai", line_numbers=True))
        except Exception as e:
            _handle_api_error(e, "cat")
        finally:
            await client.close()

    _run(_cat())


# ─── Models & Projects ────────────────────────────────────────────────

@app.command()
def models(
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    limit: int = typer.Option(30, "--limit", "-n", help="Max models to show. Use 0 for all."),
    all_models: bool = typer.Option(False, "--all", "-a", help="Show all models (overrides --limit)"),
    page: int = typer.Option(1, "--page", "-p", help="Page number (30 per page, use with --limit)"),
    sort: str = typer.Option("id", "--sort", help="Sort by: id, context, price_in, price_out."),
    sort_by_price: Optional[str] = typer.Option(
        None,
        "--sort-by-price",
        help="Shortcut for price sorting: in|out (alias for --sort price_in|price_out).",
    ),
    provider: Optional[str] = typer.Option(None, "--provider", help="Filter by provider: ollama, openrouter, anthropic, openai, google"),
    ollama_url: Optional[str] = typer.Option(None, "--ollama-url", help="Ollama base URL (only with --provider ollama)"),
):
    """List available LLM models.

    Use --provider ollama to list locally available Ollama models instead of
    cloud models (queries GET http://localhost:11434/api/tags).
    """
    import json as _json

    async def _models():
        client = MSaplingClient()
        try:
            sort_field = str(sort or "id").strip().lower()
            if sort_by_price:
                alias = str(sort_by_price).strip().lower()
                if alias in {"in", "input", "price_in"}:
                    sort_field = "price_in"
                elif alias in {"out", "output", "price_out"}:
                    sort_field = "price_out"
                else:
                    console.print("[red]Invalid --sort-by-price value. Use in or out.[/red]")
                    raise typer.Exit(1)
            if sort_field not in {"id", "context", "price_in", "price_out"}:
                console.print("[red]Invalid --sort value. Use id, context, price_in, or price_out.[/red]")
                raise typer.Exit(1)

            # Special case: --provider ollama lists local Ollama models directly
            provider_lower = str(provider or "").strip().lower()
            if provider_lower == "ollama":
                resolved_url = (
                    str(ollama_url or "").strip()
                    or os.environ.get("MSAPLING_OLLAMA_URL")
                    or str(getattr(get_settings(), "ollama_base_url", "http://localhost:11434")).rstrip("/")
                )
                async with working_spinner("Querying local Ollama"):
                    model_list = await client.ollama_models(base_url=resolved_url)
                if output == "json":
                    Console().print(_json.dumps(model_list))
                    return
                effective_limit = 0 if (all_models or limit == 0) else limit
                display = model_list if effective_limit == 0 else model_list[:effective_limit]
                table = Table(title=f"Local Ollama Models ({resolved_url})")
                table.add_column("Model ID", style="cyan")
                table.add_column("Size", justify="right")
                table.add_column("Modified")
                table.add_column("In $/1M", justify="right", style="green")
                table.add_column("Out $/1M", justify="right", style="yellow")
                for m in display:
                    size = int(m.get("size", 0) or 0)
                    size_str = f"{size / (1024 ** 3):.2f} GB" if size else "-"
                    table.add_row(
                        str(m.get("id", "?")),
                        size_str,
                        str(m.get("modified_at", ""))[:19],
                        _format_price_per_million(_extract_model_price_per_token(m, direction="in")),
                        _format_price_per_million(_extract_model_price_per_token(m, direction="out")),
                    )
                console.print(table)
                if effective_limit > 0 and len(model_list) > effective_limit:
                    console.print(f"[dim]Showing {effective_limit} of {len(model_list)} local models.[/dim]")
                return

            # Standard cloud model listing
            async with working_spinner("Loading models"):
                model_list = await client.get_models()
            # Optional provider filter
            if provider_lower and provider_lower != "auto":
                model_list = [
                    m for m in model_list
                    if str(m.get("id", m.get("model_id", ""))).lower().startswith(provider_lower + "/")
                ]
            model_list = sorted(model_list, key=lambda row: _model_sort_key(row, sort_field=sort_field))
            if output == "json":
                Console().print(_json.dumps(model_list))
                return
            effective_limit = 0 if (all_models or limit == 0) else limit
            if effective_limit == 0:
                display = model_list
            else:
                per_page = effective_limit
                start = (page - 1) * per_page
                display = model_list[start:start + per_page]
            table = Table(title="Available Models")
            table.add_column("Model ID", style="cyan")
            table.add_column("Provider")
            table.add_column("Context", justify="right")
            table.add_column("In $/1M", justify="right", style="green")
            table.add_column("Out $/1M", justify="right", style="yellow")
            for m in display:
                mid = m.get("id", m.get("model_id", "?"))
                prov = mid.split("/")[0] if "/" in mid else "unknown"
                ctx = m.get("context_length", m.get("context", "?"))
                table.add_row(
                    mid,
                    prov,
                    str(ctx),
                    _format_price_per_million(_extract_model_price_per_token(m, direction="in")),
                    _format_price_per_million(_extract_model_price_per_token(m, direction="out")),
                )
            console.print(table)
            if effective_limit > 0 and len(model_list) > effective_limit:
                console.print(f"[dim]Showing {effective_limit} of {len(model_list)} models. Use --all to see all.[/dim]")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_models())


@ollama_app.command("status")
def ollama_status():
    """Show local Ollama connectivity and current model count."""
    async def _status():
        client = MSaplingClient()
        try:
            status = await client.ollama_status()
            console.print("[green]Ollama connected[/green]")
            console.print(f"  Base URL: {status.get('base_url', '?')}")
            console.print(f"  Version:  {status.get('version', '?')}")
            models = status.get("models", []) if isinstance(status.get("models", []), list) else []
            console.print(f"  Models:   {len(models)}")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_status())


@ollama_app.command("models")
def ollama_models(
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max local models to show (0 = all)"),
):
    """List locally available Ollama models."""
    import json as _json

    async def _models():
        client = MSaplingClient()
        try:
            model_list = await client.ollama_models()
            if output == "json":
                Console().print(_json.dumps(model_list))
                return
            effective_limit = 0 if limit == 0 else max(1, limit)
            display = model_list if effective_limit == 0 else model_list[:effective_limit]
            table = Table(title="Local Ollama Models")
            table.add_column("Model ID", style="cyan")
            table.add_column("Size", justify="right")
            table.add_column("Modified")
            for m in display:
                size = int(m.get("size", 0) or 0)
                size_str = f"{size / (1024 ** 3):.2f} GB" if size else "-"
                table.add_row(str(m.get("id", "?")), size_str, str(m.get("modified_at", ""))[:19])
            console.print(table)
            if effective_limit > 0 and len(model_list) > effective_limit:
                console.print(f"[dim]Showing {effective_limit} of {len(model_list)} local models.[/dim]")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_models())


@ollama_app.command("pull")
def ollama_pull(model: str = typer.Argument(..., help="Model name (e.g. qwen2.5:3b)")):
    """Pull a model into local Ollama."""
    async def _pull():
        client = MSaplingClient()
        try:
            console.print(f"[cyan]Pulling {model}...[/cyan]")
            _ = await client.ollama_pull(model)
            console.print(f"[green]Pulled {model}[/green]")
            console.print(f"[dim]Use with: msapling chat -m ollama/{model} \"...\"[/dim]")
        except Exception as e:
            console.print(f"[red]{type(e).__name__}: {e}[/red]")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_pull())


@ollama_app.command("use")
def ollama_use(model: str = typer.Argument(..., help="Local model name (e.g. qwen2.5:3b)")):
    """Set default CLI model to a local Ollama model."""
    settings = get_settings()
    settings.default_model = f"ollama/{model.strip()}"
    settings.ollama_enabled = True
    save_settings(settings)
    console.print(f"[green]Default model set to {settings.default_model}[/green]")


@ollama_app.command("base-url")
def ollama_base_url(url: Optional[str] = typer.Argument(None, help="Set local Ollama base URL (e.g. http://127.0.0.1:11434)")):
    """Get or set local Ollama base URL for CLI direct mode."""
    settings = get_settings()
    if not url:
        console.print(str(settings.ollama_base_url))
        return
    settings.ollama_base_url = str(url).rstrip("/")
    settings.ollama_enabled = True
    save_settings(settings)
    console.print(f"[green]Ollama base URL set to {settings.ollama_base_url}[/green]")


@app.command()
def projects(
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max projects to show (0 = all)"),
    page: int = typer.Option(1, "--page", help="Page number when using --limit"),
    all: bool = typer.Option(False, "--all", "-a", help="Show all projects (overrides --limit)"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Filter projects by name"),
    watch: bool = typer.Option(False, "--watch", help="Poll every 30s and refresh display when projects change."),
):
    """List your projects."""
    import json as _json

    async def _projects():
        client = MSaplingClient()
        try:
            async with working_spinner("Loading projects"):
                payload = await client.list_projects()
            # Handle both list and dict response shapes
            if isinstance(payload, dict):
                proj_list = []
                for name, stats in payload.get("projects", payload).items():
                    entry = {"name": name}
                    if isinstance(stats, dict):
                        entry.update(stats)
                    proj_list.append(entry)
            else:
                proj_list = list(payload)
            # Sort by updated_at descending
            proj_list = sorted(proj_list, key=lambda p: p.get("updated_at", "") or "", reverse=True)
            # Filter by search term
            if search:
                proj_list = [p for p in proj_list if search.lower() in (p.get("name", "") or "").lower()]
            total = len(proj_list)
            effective_limit = 0 if all else limit
            if effective_limit > 0:
                offset = (page - 1) * effective_limit
                display = proj_list[offset:offset + effective_limit]
            else:
                display = proj_list
            if not all and total > 20 and effective_limit > 0:
                console.print(f"[dim]Showing {len(display)} of {total} projects. Use --all to see all.[/dim]")
            if output == "json":
                Console().print(_json.dumps(display))
                return
            title = f"Projects ({len(display)}/{total})" if effective_limit > 0 and total > effective_limit else "Projects"
            table = Table(title=title)
            table.add_column("Name", style="cyan")
            table.add_column("Tokens Used", justify="right")
            table.add_column("Cost", justify="right")
            for p in display:
                name = p.get("name", "?")
                tokens = p.get("tokens_used", 0)
                cost = p.get("cost_used", 0)
                table.add_row(name, f"{tokens:,}", f"${float(cost):.4f}")
            console.print(table)
            if effective_limit > 0 and total > effective_limit:
                console.print(f"[dim]Page {page} of {(total + effective_limit - 1) // effective_limit}. Use --page or --limit to navigate.[/dim]")
        except Exception as e:
            _handle_api_error(e, "projects")
        finally:
            await client.close()

    if watch:
        try:
            while True:
                console.clear()
                _run(_projects())
                console.print("[dim]Watching for changes… Ctrl+C to stop[/dim]")
                time.sleep(30)
        except KeyboardInterrupt:
            pass
    else:
        _run(_projects())


@app.command()
def sessions(
    limit: int = typer.Option(20, help="Max sessions to show"),
    project: Optional[str] = typer.Option(None, help="Filter by project name"),
):
    """List all chat sessions across web, app, and CLI."""
    async def _run():
        async with MSaplingClient() as client:
            token = get_token()
            if not token:
                console.print("[red]Not logged in. Run: msapling login[/red]")
                raise typer.Exit(1)
            try:
                params = {"limit": limit}
                if project:
                    params["project"] = project
                resp = await client._request("GET", "/api/chat/sessions", params=params)
                data = resp.json()
                sessions_list = data.get("sessions", [])
                if not sessions_list:
                    console.print("[dim]No sessions found.[/dim]")
                    return
                table = Table(title=f"Chat Sessions ({len(sessions_list)} shown)", show_header=True)
                table.add_column("ID", style="dim", width=12)
                table.add_column("Project", style="cyan")
                table.add_column("Title", style="white")
                table.add_column("Model", style="green", width=20)
                table.add_column("Surface", style="yellow", width=8)
                table.add_column("Cost", style="magenta", width=8)
                table.add_column("Created", style="dim")
                for s in sessions_list:
                    sid = str(s.get("id", ""))[:10]
                    surface = s.get("client_type", "web")
                    created = str(s.get("created_at", ""))[:16]
                    cost = f"${float(s.get('cost', 0)):.4f}"
                    table.add_row(sid, s.get("project_name",""), s.get("title",""), s.get("model",""), surface, cost, created)
                console.print(table)
            except Exception as e:
                _handle_api_error(e, "sessions")
    asyncio.run(_run())


@app.command()
def resume(
    snapshot_id: Optional[str] = typer.Argument(None, help="Snapshot ID to resume. Lists recent if omitted."),
):
    """Resume a session from a server-side snapshot (works from any machine)."""
    async def _run():
        async with MSaplingClient() as client:
            token = get_token()
            if not token:
                console.print("[red]Not logged in.[/red]"); raise typer.Exit(1)
            try:
                if not snapshot_id:
                    resp = await client._request("GET", "/api/snapshots")
                    snaps = resp.json().get("snapshots", [])
                    if not snaps:
                        console.print("[dim]No snapshots found. Session auto-saves on exit.[/dim]")
                        return
                    table = Table(title="Available Snapshots")
                    table.add_column("ID", style="dim")
                    table.add_column("Project")
                    table.add_column("Model")
                    table.add_column("Messages", justify="right")
                    table.add_column("Saved At")
                    for s in snaps[:10]:
                        table.add_row(str(s.get("id",""))[:16], s.get("project_name",""), s.get("model",""), str(s.get("message_count",0)), str(s.get("created_at",""))[:16])
                    console.print(table)
                    console.print("[dim]Run: msapling resume <id>[/dim]")
                    return
                resp = await client._request("GET", f"/api/snapshots/{snapshot_id}")
                snap = resp.json()
                console.print(f"[green]Resuming snapshot {snapshot_id[:16]}... launching shell[/green]")
                # Launch shell with restored context
                from .shell import InteractiveShell
                shell = InteractiveShell(
                    model=snap.get("model", ""),
                    project_name=snap.get("project_name", ""),
                    restored_messages=snap.get("messages", []),
                )
                await shell.run()
            except Exception as e:
                _handle_api_error(e, "resume")
    asyncio.run(_run())


# ─── Config ───────────────────────────────────────────────────────────

config_app = typer.Typer(help="View or set CLI configuration.")
app.add_typer(config_app, name="config")


@config_app.callback(invoke_without_command=True)
def config(
    ctx: typer.Context,
    key: Optional[str] = typer.Argument(None, help="Setting key"),
    value: Optional[str] = typer.Argument(None, help="Setting value"),
):
    """View or set configuration.

    Examples:
        msapling config                        # show all settings
        msapling config default_model gpt-4o   # set a value
        msapling config theme diamond           # set theme via positional args
        msapling config theme --list            # list themes (subcommand)
    """
    if ctx.invoked_subcommand is not None:
        return

    # Legacy positional config syntax conflicts with subcommand parsing in Typer.
    # Route common subcommand forms explicitly so "msapling config theme --help"
    # and "msapling config shield --help" don't mutate settings.
    if key == "theme":
        if value in ("--help", "-h"):
            console.print("Get or set the CLI color theme.")
            console.print("Usage: msapling config theme [NAME] [--list]")
            return
        if value in ("--list", "-l"):
            config_theme(name=None, list_themes=True)
            return
        config_theme(name=value if value else None, list_themes=False)
        return

    if key == "shield":
        if value in (None, "--help", "-h"):
            console.print("Manage AgentShield client-side safety gate.")
            console.print("Usage: msapling config shield [enable|disable|status]")
            return
        if value == "enable":
            shield_enable()
            return
        if value == "disable":
            shield_disable()
            return
        if value == "status":
            shield_status()
            return
        console.print(f"[red]Unknown shield action: {value}[/red]")
        raise typer.Exit(1)

    if key == "policy":
        if value in (None, "--help", "-h"):
            console.print("Inspect MSapling tool policy rules.")
            console.print("Usage: msapling config policy [status|paths|log]")
            return
        if value == "status":
            policy_status(workspace=".")
            return
        if value == "paths":
            policy_paths(workspace=".")
            return
        if value == "log":
            policy_log()
            return
        console.print(f"[red]Unknown policy action: {value}[/red]")
        raise typer.Exit(1)

    settings = get_settings()
    if key and value:
        if hasattr(settings, key):
            setattr(settings, key, value)
            save_settings(settings)
            console.print(f"[green]Set {key} = {value}[/green]")
        else:
            console.print(f"[red]Unknown setting: {key}[/red]")
    elif key:
        # Show single key value
        if hasattr(settings, key):
            console.print(str(getattr(settings, key)))
        else:
            console.print(f"[red]Unknown setting: {key}[/red]")
    else:
        table = Table(title="Configuration")
        table.add_column("Key", style="cyan")
        table.add_column("Value")
        for k, v in settings.model_dump().items():
            table.add_row(k, str(v))
        table.add_row("authenticated", str(bool(get_token())))
        console.print(table)


@config_app.command("theme")
def config_theme(
    name: Optional[str] = typer.Argument(None, help="Theme name: diamond, onyx, lab"),
    list_themes: bool = typer.Option(False, "--list", "-l", help="List all available themes"),
):
    """Get or set the CLI color theme.

    Examples:
        msapling config theme            # show current theme
        msapling config theme diamond    # set Diamond theme
        msapling config theme onyx       # set Onyx theme
        msapling config theme lab        # set Lab theme
        msapling config theme --list     # list all themes with descriptions
    """
    from .themes import THEMES, get_active_theme, DEFAULT_THEME, list_themes as _list_themes

    if list_themes:
        table = Table(title="Available Themes")
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        table.add_column("Prompt Color")
        table.add_column("Prefixes")
        for theme_name, desc in _list_themes().items():
            theme_data = THEMES[theme_name]
            table.add_row(
                _console_safe_text(theme_name),
                _console_safe_text(str(desc)),
                _console_safe_text(str(theme_data.get("prompt", ""))),
                _console_safe_text(f"{theme_data.get('user_prefix', '')} / {theme_data.get('ai_prefix', '')}"),
            )
        console.print(table)
        return

    settings = get_settings()

    if not name:
        # Show current theme
        active = getattr(settings, "theme", DEFAULT_THEME) or DEFAULT_THEME
        if active not in THEMES:
            active = DEFAULT_THEME
        theme_data = THEMES[active]
        console.print(f"Current theme: [bold]{_console_safe_text(active)}[/bold]")
        console.print(f"  {_console_safe_text(str(theme_data.get('description', '')))}")
        console.print(f"  Prompt color : {_console_safe_text(str(theme_data.get('prompt', '')))}")
        console.print(f"  User prefix  : {_console_safe_text(str(theme_data.get('user_prefix', '')))}")
        console.print(f"  AI prefix    : {_console_safe_text(str(theme_data.get('ai_prefix', '')))}")
        console.print(f"\nUse [cyan]msapling config theme --list[/cyan] to see all themes.")
        return

    # Validate and set
    name_lower = name.strip().lower()
    if name_lower not in THEMES:
        valid = ", ".join(sorted(THEMES))
        console.print(f"[red]Unknown theme: {name!r}. Valid: {valid}[/red]")
        raise typer.Exit(1)

    settings.theme = name_lower
    save_settings(settings)
    console.print(f"Theme set to: {name_lower}")


# ─── Config Shield ────────────────────────────────────────────────────

shield_app = typer.Typer(help="Manage AgentShield client-side safety gate.")
config_app.add_typer(shield_app, name="shield")


@shield_app.command("enable")
def shield_enable():
    """Enable AgentShield (client-side hard gate for destructive tool calls)."""
    from .agentshield import AgentShield
    AgentShield().set_enabled(True)
    console.print("[green]AgentShield: ENABLED[/green]")
    console.print("[dim]Destructive tool calls will be blocked or require confirmation.[/dim]")


@shield_app.command("disable")
def shield_disable():
    """Disable AgentShield (NOT recommended — removes client-side safety gate)."""
    from .agentshield import AgentShield
    AgentShield().set_enabled(False)
    console.print("[yellow]AgentShield: DISABLED[/yellow]")
    console.print("[dim]Warning: all tool calls will proceed without client-side safety checks.[/dim]")


@shield_app.command("status")
def shield_status():
    """Show AgentShield status and rule counts."""
    from .agentshield import AgentShield
    shield = AgentShield()
    enabled = shield.is_enabled()
    status_str = "[green]ENABLED[/green]" if enabled else "[red]DISABLED[/red]"
    table = Table(title="AgentShield Status")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")
    table.add_row("Status", status_str)
    table.add_row("BLOCKED_ALWAYS rules", str(shield.blocked_always_count))
    table.add_row("REQUIRES_CONFIRMATION rules", str(shield.requires_confirmation_count))
    table.add_row("Config key", "agentshield_enabled")
    table.add_row("Env override", "MSAPLING_SHIELD_DISABLED=1  (disables shield)")
    console.print(table)


# --- Config Policy -----------------------------------------------------------

policy_app = typer.Typer(help="Inspect MSapling tool policy rules.")
app.add_typer(policy_app, name="policy")


@policy_app.command("status")
def policy_status(
    workspace: str = typer.Option(".", "--workspace", "-w", help="Workspace root for workspace-tier policies"),
):
    """Show loaded tool policy rules in priority order."""
    from .policy import load_policy_rules

    rules = load_policy_rules(workspace)
    if not rules:
        console.print("[dim]No policy rules loaded.[/dim]")
        console.print("[dim]Create .msapling/policies/*.toml in this workspace or ~/.msapling/policies/*.toml.[/dim]")
        return

    table = Table(title="MSapling Tool Policies")
    table.add_column("Priority", justify="right")
    table.add_column("Tier")
    table.add_column("Decision")
    table.add_column("Tool")
    table.add_column("Modes")
    table.add_column("Source")
    for rule in rules:
        modes = ",".join(rule.modes) if rule.modes else "*"
        table.add_row(
            f"{rule.final_priority:.3f}",
            _console_safe_text(rule.tier),
            _console_safe_text(rule.decision),
            _console_safe_text(rule.tool_name),
            _console_safe_text(modes),
            _console_safe_text(rule.source),
        )
    console.print(table)


@policy_app.command("paths")
def policy_paths(
    workspace: str = typer.Option(".", "--workspace", "-w", help="Workspace root for workspace-tier policies"),
):
    """Show policy lookup locations."""
    from .policy import default_policy_locations

    table = Table(title="MSapling Policy Paths")
    table.add_column("Tier", style="cyan")
    table.add_column("Path")
    for tier, paths in default_policy_locations(workspace).items():
        for path in paths:
            table.add_row(_console_safe_text(tier), _console_safe_text(str(path)))
    console.print(table)


@policy_app.command("log")
def policy_log(
    limit: int = typer.Option(30, "--limit", "-n", min=1, max=500, help="Max decision rows to show"),
    decision: Optional[str] = typer.Option(None, "--decision", help="Filter by decision: allow or deny"),
    tool: Optional[str] = typer.Option(None, "--tool", help="Filter by tool name"),
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
):
    """Show recent permission decision logs."""
    import json as _json
    from .policy import load_permission_decisions, permission_log_path

    filt_decision = str(decision or "").strip().lower()
    if filt_decision and filt_decision not in {"allow", "deny"}:
        console.print("[red]--decision must be allow or deny[/red]")
        raise typer.Exit(1)

    rows = load_permission_decisions(
        limit=limit,
        decision=filt_decision or None,
        tool=(tool.strip() if isinstance(tool, str) and tool.strip() else None),
    )
    if output == "json":
        print(_json.dumps(rows, indent=2))
        return
    if not rows:
        console.print("[dim]No permission decisions logged yet.[/dim]")
        console.print(f"[dim]Log file: {permission_log_path()}[/dim]")
        return

    table = Table(title="Permission Decisions")
    table.add_column("Time", style="cyan")
    table.add_column("Decision")
    table.add_column("Tool")
    table.add_column("Mode")
    table.add_column("Role")
    table.add_column("Source")
    table.add_column("Reason")
    table.add_column("Correlation")
    for row in rows:
        table.add_row(
            _console_safe_text(str(row.get("ts") or "")),
            _console_safe_text(str(row.get("decision") or "")),
            _console_safe_text(str(row.get("tool") or "")),
            _console_safe_text(str(row.get("mode") or "")),
            _console_safe_text(str(row.get("permission_name") or row.get("permission_role") or "")),
            _console_safe_text(str(row.get("source") or "")),
            _console_safe_text(str(row.get("reason") or "")[:90]),
            _console_safe_text(str(row.get("correlation_id") or "")),
        )
    console.print(table)
    tools = sorted({str(row.get("tool") or "").strip() for row in rows if str(row.get("tool") or "").strip()})
    if tools:
        console.print(f"[dim]Tools: {', '.join(tools)}[/dim]")
    console.print(f"[dim]Log file: {permission_log_path()}[/dim]")


# ─── Local Project Operations (no server needed) ─────────────────────

@app.command()
def context(
    path: str = typer.Argument(".", help="Project directory"),
    patterns: Optional[str] = typer.Option(None, help="Glob patterns (comma-separated)"),
    max_files: int = typer.Option(30, help="Max files to include"),
    output: Optional[str] = typer.Option(None, "-o", help="Save context to file"),
):
    """Scan a local project and build LLM-ready context.

    This runs locally — no server needed. Use this to load any codebase
    into a context block you can paste into chat or pipe to 'msapling chat'.
    """
    from .local import detect_project_root, build_file_tree, read_files_as_context

    root, info = detect_project_root(path)
    console.print(f"[cyan]Project root:[/cyan] {root}")
    console.print(f"[cyan]Type:[/cyan] {info['type']} | Markers: {', '.join(info['markers'])}")

    pattern_list = patterns.split(",") if patterns else None
    files = build_file_tree(root, patterns=pattern_list, max_files=max_files)
    console.print(f"[cyan]Files found:[/cyan] {len(files)}")

    context_block = read_files_as_context(root, files)
    token_est = len(context_block) // 4
    console.print(f"[cyan]Context size:[/cyan] ~{token_est:,} tokens ({len(context_block):,} chars)")

    if output:
        Path(output).write_text(context_block, encoding="utf-8")
        console.print(f"[green]Saved to {output}[/green]")
    else:
        console.print(Panel(
            f"[dim]{context_block[:500]}...[/dim]" if len(context_block) > 500 else context_block,
            title="Context Preview (first 500 chars)",
        ))
        console.print(f"\n[yellow]Use -o context.md to save full context, or pipe to chat:[/yellow]")
        console.print(f"  msapling context . -o ctx.md && msapling chat -i")


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def git(
    ctx: typer.Context,
    args: List[str] = typer.Argument(None, help="Git arguments (e.g. status --short, log --oneline -5)"),
    cwd: str = typer.Option(".", help="Working directory"),
):
    """Run git commands locally with pretty output."""
    from .local import git_status, git_diff, git_log
    import subprocess

    parts = list(args or [])
    # Support `msapling git status --short` by consuming unknown options from
    # Typer context; also preserve legacy quoted form `msapling git "status --short"`.
    if not parts and getattr(ctx, "args", None):
        parts = [str(p) for p in ctx.args]
    if len(parts) == 1 and " " in parts[0]:
        import shlex
        parts = shlex.split(parts[0])
    if not parts:
        console.print("[red]Usage: msapling git <args...>[/red]")
        raise typer.Exit(1)
    subcmd = parts[0] if parts else ""

    # Shortcuts for common commands
    if subcmd == "s":
        console.print(Syntax(git_status(cwd), "diff", theme="monokai"))
        return
    if subcmd == "d":
        console.print(Syntax(git_diff(cwd), "diff", theme="monokai"))
        return
    if subcmd == "l":
        console.print(git_log(cwd))
        return

    try:
        result = subprocess.run(
            ["git"] + parts,
            cwd=cwd, capture_output=True, text=True, timeout=30,
        )
        if result.stdout:
            if subcmd in ("diff", "show", "log"):
                console.print(Syntax(result.stdout, "diff", theme="monokai"))
            else:
                console.print(result.stdout)
        if result.stderr and result.returncode != 0:
            console.print(f"[red]{result.stderr}[/red]")
    except subprocess.TimeoutExpired:
        console.print("[red]Git command timed out (30s)[/red]")
    except FileNotFoundError:
        console.print("[red]Git not found — install git first[/red]")


@app.command()
def scan(
    path: str = typer.Argument(".", help="Directory or file to scan for context building"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path, or '-' for stdout"),
    max_files: int = typer.Option(50, "--max-files", help="Maximum number of files to include"),
    max_size_kb: int = typer.Option(100, "--max-size-kb", help="Maximum file size in KB to include"),
    include: Optional[str] = typer.Option(None, "--include", help="Comma-separated glob patterns to include (e.g. '*.py,*.ts')"),
    exclude: Optional[str] = typer.Option(
        "__pycache__,node_modules,.git,.mypy_cache,.pytest_cache,dist,build,.venv,venv",
        "--exclude",
        help="Comma-separated directory/file patterns to exclude",
    ),
):
    """Recursively scan a path and build an LLM-ready context file.

    Reads each matching file, estimates token count (len/3.3), and
    aggregates all content into a structured markdown context block
    suitable for pasting into chat or piping to 'msapling chat'.

    Examples:
        msapling scan src/ --output context.md
        msapling scan . --include "*.py,*.ts" --max-files 30
        msapling scan src/ --output - | msapling chat -i
    """
    import fnmatch
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

    scan_path = Path(path).resolve()
    if not scan_path.exists():
        console.print(f"[red]Path does not exist: {scan_path}[/red]")
        raise typer.Exit(1)

    # Parse include/exclude patterns
    include_patterns = [p.strip() for p in include.split(",")] if include else []
    exclude_patterns = [p.strip() for p in exclude.split(",")] if exclude else []

    def _is_excluded(p: Path) -> bool:
        for part in p.parts:
            for pat in exclude_patterns:
                if fnmatch.fnmatch(part, pat):
                    return True
        return False

    def _matches_include(p: Path) -> bool:
        if not include_patterns:
            return True
        name = p.name
        return any(fnmatch.fnmatch(name, pat) for pat in include_patterns)

    # Collect candidate files
    if scan_path.is_file():
        candidates = [scan_path]
    else:
        candidates = [
            f for f in scan_path.rglob("*")
            if f.is_file() and not _is_excluded(f.relative_to(scan_path)) and _matches_include(f)
        ]
        candidates = sorted(candidates)[:max_files]

    to_stdout = output == "-"
    blocks: list = []
    total_tokens = 0
    skipped = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total} files"),
        TimeElapsedColumn(),
        console=console,
        disable=to_stdout,
    ) as progress:
        task = progress.add_task("Scanning files...", total=len(candidates))
        for file_path in candidates:
            progress.update(task, description=f"[cyan]{file_path.name}[/cyan]")
            size_kb = file_path.stat().st_size / 1024
            if size_kb > max_size_kb:
                skipped += 1
                progress.advance(task)
                continue
            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                skipped += 1
                progress.advance(task)
                continue

            rel = file_path.relative_to(scan_path) if not scan_path.is_file() else file_path.name
            token_est = int(len(content) / 3.3)
            total_tokens += token_est
            ext = file_path.suffix.lstrip(".") or "text"
            block = f"# File: {rel} ({token_est} tokens)\n```{ext}\n{content}\n```\n"
            blocks.append(block)
            progress.advance(task)

    context_output = "\n".join(blocks)

    if to_stdout:
        # Stream to stdout for piping
        sys.stdout.write(_console_safe_text(context_output))
        sys.stdout.flush()
    elif output:
        Path(output).write_text(context_output, encoding="utf-8")
        console.print(f"[green]Context written to {output}[/green]")
        console.print(f"[cyan]Files:[/cyan] {len(blocks)} included, {skipped} skipped")
        console.print(f"[cyan]Total tokens:[/cyan] ~{total_tokens:,}")
    else:
        # Preview mode
        preview = context_output[:800]
        console.print(Panel(
            f"[dim]{preview}[/dim]" + ("[dim]...[/dim]" if len(context_output) > 800 else ""),
            title=f"Context Preview ({len(blocks)} files)",
        ))
        console.print(f"[cyan]Files:[/cyan] {len(blocks)} included, {skipped} skipped")
        console.print(f"[cyan]Total tokens:[/cyan] ~{total_tokens:,}")
        console.print("[yellow]Use --output context.md to save, or --output - to pipe to chat[/yellow]")


@app.command()
def summarize(
    file_or_glob: str = typer.Argument(..., help="File path or glob pattern to summarize"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path (default: stdout)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model override (Ollama or MSapling model ID)"),
):
    """Summarize file(s) using local Ollama or the MSapling summary endpoint.

    Uses MSAPLING_OLLAMA_URL environment variable for local Ollama summarization.
    Falls back to the MSapling /api/chat/summarize endpoint if Ollama is not configured.

    Examples:
        msapling summarize context.md
        msapling summarize "src/*.py" --output summary.md
        msapling summarize notes.txt -m llama3
    """
    import glob as _glob
    import json as _json

    SUMMARY_PROMPT = (
        "Summarize the conversation chunk into a concise, factual block. "
        "Preserve file paths, function names, variable names, IDs, and diffs. "
        "Preserve code blocks verbatim (including fenced blocks) and do not rewrite code. "
        "Keep the summary compact and avoid speculation."
    )

    # Resolve files
    matched = _glob.glob(file_or_glob, recursive=True)
    if not matched:
        # Try as a literal path
        p = Path(file_or_glob)
        if p.is_file():
            matched = [str(p)]
        else:
            console.print(f"[red]No files found matching: {file_or_glob}[/red]")
            raise typer.Exit(1)

    # Read all content
    parts: list = []
    for fp in sorted(matched):
        try:
            content = Path(fp).read_text(encoding="utf-8", errors="replace")
            parts.append(f"### {fp}\n{content}")
        except Exception as e:
            console.print(f"[yellow]Skipping {fp}: {e}[/yellow]")
    combined = "\n\n".join(parts)
    full_prompt = f"{SUMMARY_PROMPT}\n\n{combined}"

    ollama_url = os.environ.get("MSAPLING_OLLAMA_URL", "")
    resolved_model = str(model or get_settings().default_model or "").strip()
    if not resolved_model:
        resolved_model = "google/gemini-2.0-flash-001"
    # If summarize is using the backend path (no local Ollama URL), do not
    # route through a local-only default model unless the user explicitly asked for it.
    if not model and not ollama_url and resolved_model.lower().startswith("ollama/"):
        resolved_model = "google/gemini-2.0-flash-001"

    async def _summarize():
        summary = ""
        summary_chat_id: Optional[str] = None
        if ollama_url:
            # Use local Ollama via MSAPLING_OLLAMA_URL
            import httpx as _httpx
            ollama_model = model or "llama3"
            if not ollama_model.startswith("ollama/"):
                ollama_model_name = ollama_model
            else:
                ollama_model_name = ollama_model.replace("ollama/", "", 1)
            generate_url = ollama_url.rstrip("/") + "/api/generate"
            try:
                async with _httpx.AsyncClient(timeout=120) as hx:
                    resp = await hx.post(generate_url, json={
                        "model": ollama_model_name,
                        "prompt": full_prompt,
                        "stream": False,
                    })
                    resp.raise_for_status()
                    data = resp.json()
                    summary = data.get("response", "")
            except Exception as e:
                console.print(f"[red]Ollama error: {e}[/red]")
                raise typer.Exit(1)
        else:
            # Fall back to MSapling summary endpoint
            client = MSaplingClient()
            try:
                async with working_spinner("Summarizing via MSapling"):
                    summary_chat_id = await client.ensure_utility_chat(model=resolved_model)
                if summary_chat_id:
                    with suppress(Exception):
                        await client.force_release_lock(summary_chat_id)
                parts_resp: list = []
                async for chunk in client.stream_chat(
                    chat_id=summary_chat_id,
                    prompt=full_prompt,
                    model=resolved_model,
                    history_enabled=False,
                    bypass_diff_mode=True,
                ):
                    content_chunk = chunk.get("content", "")
                    if content_chunk:
                        parts_resp.append(content_chunk)
                summary = "".join(parts_resp)
            except Exception as e:
                console.print(f"[red]MSapling summary error: {e}[/red]")
                raise typer.Exit(1)
            finally:
                if summary_chat_id:
                    with suppress(Exception):
                        await client.force_release_lock(summary_chat_id)
                await client.close()

        return summary

    result = _run(_summarize())

    if output:
        Path(output).write_text(result, encoding="utf-8")
        console.print(f"[green]Summary written to {output}[/green]")
    else:
        print(result)


@app.command()
def shell(
    model: Optional[str] = typer.Option(None, "-m", help="Model ID"),
    project: Optional[str] = typer.Option(None, "-p", help="Project name"),
    resume: Optional[str] = typer.Option(None, "--resume", "-r", help="Resume session (ID or number)"),
):
    """Start interactive shell (like Claude Code / Gemini CLI).

    Full-featured coding environment with slash commands:
      /help, /model, /cost, /read, /grep, /run, /git, /plan, /save, /resume

    Examples:
      msapling shell                    # start new session
      msapling shell -m gpt-4o          # with specific model
      msapling shell --resume           # resume last session
      msapling shell -r 1               # resume session #1
    """
    from .shell import run_shell
    _run(run_shell(model=model, project=project, resume_id=resume))


@app.command(name="mcp-serve")
def mcp_serve():
    """Start MSapling as an MCP server (for Claude Code, Cursor, etc).

    This runs as a subprocess that communicates via stdin/stdout using
    the Model Context Protocol. Add to your tool's MCP config:

    Claude Code (~/.claude/settings.json):
      "mcpServers": { "msapling": { "command": "msapling", "args": ["mcp-serve"] } }

    Cursor (.cursor/mcp.json):
      { "msapling": { "command": "msapling", "args": ["mcp-serve"] } }
    """
    from .mcp.server import serve
    serve()


@app.command()
def benchmark(
    prompt: str = typer.Argument("Explain the difference between a stack and a queue.", help="Prompt to benchmark"),
    models: str = typer.Option(
        "google/gemini-2.0-flash-001,anthropic/claude-3-haiku,openai/gpt-4o-mini",
        "-m", help="Comma-separated model IDs to compare",
    ),
):
    """Run a model benchmark from the CLI. Compares speed, cost, and quality.

    Sends the same prompt to multiple models and shows results side-by-side
    with tokens/sec, cost, and response preview.

    Example:
        msapling benchmark "explain recursion" -m "gpt-4o,claude-3.5-sonnet,gemini-flash"
    """
    from .completer import resolve_model
    user = _get_user_or_exit()
    require_pro(user, "benchmark")
    model_list = [resolve_model(m.strip())[0] for m in models.split(",") if m.strip()]

    async def _benchmark():
        import time as _time
        client = MSaplingClient()
        try:
            results = []
            for mid in model_list:
                model_short = mid.split("/")[-1] if "/" in mid else mid
                with Status(f"Running {model_short}...", console=console):
                    t0 = _time.monotonic()
                    parts = []
                    total_tokens = 0
                    cost = 0.0
                    try:
                        _bmark_chat_id = await client.ensure_server_chat(
                            title=f"CLI Benchmark {model_short}",
                            model=mid, client_type="cli-benchmark",
                        )
                        async for chunk in client.stream_chat(
                            chat_id=_bmark_chat_id,
                            prompt=prompt,
                            model=mid,
                        ):
                            content = chunk.get("content", "")
                            if content:
                                parts.append(content)
                            if chunk.get("type") == "usage":
                                usage = chunk.get("usage", {})
                                total_tokens = usage.get("total_tokens", 0)
                                cost = float(chunk.get("cost", 0))
                        elapsed = _time.monotonic() - t0
                        tps = total_tokens / elapsed if elapsed > 0 else 0
                        results.append({
                            "model": mid, "response": "".join(parts),
                            "tokens": total_tokens, "cost": cost,
                            "elapsed": elapsed, "tps": tps, "status": "ok",
                        })
                    except Exception as e:
                        results.append({
                            "model": mid, "response": "", "tokens": 0,
                            "cost": 0, "elapsed": 0, "tps": 0,
                            "status": f"error: {e}",
                        })

            # Results table
            table = Table(title="Benchmark Results")
            table.add_column("Model", style="cyan")
            table.add_column("Tokens", justify="right")
            table.add_column("TPS", justify="right")
            table.add_column("Cost", justify="right")
            table.add_column("Time", justify="right")
            table.add_column("Status")
            for r in sorted(results, key=lambda x: x["tps"], reverse=True):
                model_short = r["model"].split("/")[-1] if "/" in r["model"] else r["model"]
                status_color = "green" if r["status"] == "ok" else "red"
                table.add_row(
                    model_short,
                    f"{r['tokens']:,}",
                    f"{r['tps']:.1f}",
                    f"${r['cost']:.4f}",
                    f"{r['elapsed']:.1f}s",
                    f"[{status_color}]{r['status']}[/{status_color}]",
                )
            console.print(table)

            # Show responses
            for r in results:
                if r["response"]:
                    model_short = r["model"].split("/")[-1] if "/" in r["model"] else r["model"]
                    console.print(Panel(
                        Markdown(r["response"][:2000]),
                        title=f"[cyan]{model_short}[/cyan] ({r['tokens']:,} tok, {r['tps']:.1f} tok/s)",
                        border_style="cyan" if r["status"] == "ok" else "red",
                    ))
        except Exception as e:
            console.print(f"[red]Benchmark failed: {e}[/red]")
        finally:
            await client.close()

    _run(_benchmark())


@app.command()
def completions(
    shell_name: str = typer.Argument("bash", help="Shell: bash, zsh, fish, powershell"),
    install: bool = typer.Option(False, "--install", help="Install completions to shell profile"),
):
    """Generate or install shell tab completions.

    Examples:
        msapling completions bash --install
        msapling completions zsh >> ~/.zshrc
        msapling completions fish > ~/.config/fish/completions/msapling.fish
        msapling completions powershell >> $PROFILE
    """
    import subprocess as _sp
    shell_map = {"bash": "bash", "zsh": "zsh", "fish": "fish", "powershell": "powershell", "pwsh": "powershell"}
    target = shell_map.get(shell_name.lower())
    if not target:
        console.print(f"[red]Unknown shell: {shell_name}. Options: bash, zsh, fish, powershell[/red]")
        raise typer.Exit(1)

    if install:
        # Determine the target shell profile path for the preview message.
        _profile_hints = {
            "bash": "~/.bashrc  (or ~/.bash_profile)",
            "zsh": "~/.zshrc",
            "fish": "~/.config/fish/completions/msapling.fish",
            "powershell": "$PROFILE",
        }
        _profile = _profile_hints.get(target, "your shell profile")
        console.print(f"[bold]Shell:[/bold] {target}")
        console.print(f"[bold]Target profile:[/bold] {_profile}")
        console.print("[yellow]This will modify your shell profile to load MSapling tab completions.[/yellow]")
        from rich.prompt import Confirm
        if not Confirm.ask("Proceed with installation?", default=False):
            console.print("[dim]Cancelled.[/dim]")
            return
        try:
            # Use typer's built-in completion installer
            import typer.completion as _tc
            _tc.install(shell=target)
            console.print(f"[green]Completions installed for {target}.[/green]")
        except Exception:
            console.print(f"[yellow]Auto-install not available. Generate manually:[/yellow]")
            console.print(f"  msapling completions {shell_name} >> <your-shell-profile>")
    else:
        try:
            result = _sp.run(
                [sys.executable, "-m", "msapling_cli.main"],
                env={**os.environ, "_MSAPLING_COMPLETE": f"complete_{target}"},
                capture_output=True, text=True,
            )
            if result.stdout:
                print(result.stdout)
            else:
                console.print(f"[dim]Completion script for {target} (pipe to your shell profile).[/dim]")
        except Exception as e:
            console.print(f"[red]{e}[/red]")


@app.command()
def doctor(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    strict: bool = typer.Option(False, "--strict", help="Exit 1 if any check fails"),
    exhaustive: bool = typer.Option(False, "--exhaustive", "-e", help="Run the full 14-check exhaustive report"),
):
    """Diagnose installation, auth, and connectivity.

    By default runs a quick connectivity + auth check.
    Use --exhaustive (or -e) for the full 14-check health report.
    """
    import json as _json
    import shutil

    settings = get_settings()
    token = get_token()
    token_source = get_token_source()
    sources = inspect_token_sources()

    # Check for auth conflict (multiple token sources with different values)
    present_tokens = {k: v for k, v in sources.items() if v}
    auth_conflict = len(set(present_tokens.values())) > 1

    # ------------------------------------------------------------------
    # Exhaustive mode: run all 8 checks via doctor module
    # ------------------------------------------------------------------
    if exhaustive and not json_output:
        from . import doctor as _doctor_mod
        from datetime import date

        async def _run_exhaustive():
            return await _doctor_mod.run_all_checks(settings.api_url, token)

        try:
            results = _run(_run_exhaustive())
        except Exception as exc:
            console.print(f"[red]Doctor failed: {exc}[/red]")
            raise typer.Exit(1)

        date_str = date.today().isoformat()
        _doctor_mod.print_report(results, date_str)

        if strict:
            any_fail = any(s == "fail" for _, s, _ in results)
            if any_fail:
                raise typer.Exit(1)
        return

    # ------------------------------------------------------------------
    # Standard mode (legacy): quick connectivity + auth
    # ------------------------------------------------------------------

    # API connectivity + identity
    async def _check_api():
        client = MSaplingClient()
        try:
            ok = await client.health_check()
            if ok:
                identity = None
                error = None
                try:
                    # Use the /users/me endpoint to validate the token is not stale/revoked.
                    user = await client.me()
                    identity = user.get("email") if isinstance(user, dict) else None
                except Exception as exc:
                    error = str(exc)
                return ok, identity, error
            return ok, None, "unreachable"
        finally:
            await client.close()

    try:
        api_reachable, identity, auth_error = _run(_check_api())
    except Exception:
        api_reachable, identity, auth_error = False, None, "connection failed"

    warnings: list = []
    failures: list = []

    if auth_conflict:
        warnings.append("auth_conflict")
    if not shutil.which("git"):
        warnings.append("git_not_found")
    if not shutil.which("rg"):
        warnings.append("ripgrep_not_found")
    if auth_error:
        failures.append("auth_check_failed")

    if json_output:
        data = {
            "version": __version__,
            "auth": {
                "present": bool(token),
                "source": token_source,
                "conflict": auth_conflict,
            },
            "api": {
                "reachable": api_reachable,
                "auth_check_ok": auth_error is None,
                "identity": identity,
                "error": auth_error,
                "url": settings.api_url,
            },
            "tools": {
                "git": shutil.which("git"),
                "ripgrep": shutil.which("rg"),
            },
            "warnings": warnings,
            "failures": failures,
        }
        Console().print_json(_json.dumps(data))
        if strict and failures:
            raise typer.Exit(1)
        return

    console.print("[bold]MSapling Doctor[/bold]")
    console.print()
    console.print(f"  Version:    {__version__}")
    console.print(f"  Python:     {sys.version.split()[0]}")
    console.print()

    # Dependencies
    for pkg in ["httpx", "rich", "typer", "pydantic"]:
        ver = _package_version(pkg)
        console.print(f"  {pkg:12s} {ver}")

    # Git / ripgrep
    git_path = shutil.which("git")
    rg_path = shutil.which("rg")
    console.print(f"  git:        {'[green]' + git_path + '[/green]' if git_path else '[red]NOT FOUND[/red]'}")
    console.print(f"  ripgrep:    {'[green]' + rg_path + '[/green]' if rg_path else '[yellow]not found (grep fallback)[/yellow]'}")

    # Auth
    console.print(f"  Auth token: {'[green]present (' + str(token_source) + ')[/green]' if token else '[red]missing (run: msapling login)[/red]'}")
    # Show which source provided the active token
    _active_source = "none"
    if os.environ.get("MSAPLING_TOKEN"):
        _active_source = "env var (MSAPLING_TOKEN)"
    elif token_source == "keyring":
        _active_source = "system keyring"
    elif token_source == "file":
        _active_source = "config file (~/.msapling/token)"
    console.print(f"  [cyan]→[/cyan] Token source: {_active_source}")
    console.print("  [dim]Credential resolution order: 1) MSAPLING_TOKEN env var, 2) config file, 3) system keyring[/dim]")
    if auth_conflict:
        console.print("  [yellow]WARNING: Multiple token sources detected — conflict possible[/yellow]")

    # API
    console.print(f"  API:        {'[green]reachable[/green]' if api_reachable else '[red]unreachable[/red]'}")
    if identity:
        console.print(f"  Identity:   [green]{identity}[/green]")
    if auth_error:
        console.print(f"  Auth error: [red]{auth_error}[/red]")

    console.print(f"  API URL:    {settings.api_url}")
    console.print(f"  Model:      {settings.default_model}")
    console.print()

    console.print("\n[bold]MCP Server[/bold]")

    # Check 1: MCP server module importable
    try:
        from msapling_cli.mcp import server as _mcp_server
        console.print("  [green]✓[/green] MCP server module: OK")
    except ImportError as e:
        console.print(f"  [red]✗[/red] MCP server module: FAILED ({e})")

    # Check 2: Detect transport from env
    mcp_transport = os.environ.get("MCP_TRANSPORT", "stdio")
    console.print(f"  [cyan]→[/cyan] Transport: {mcp_transport}")

    # Check 3: Tool count
    try:
        tool_count = len([k for k in dir(_mcp_server) if k.startswith("msapling_")])
        console.print(f"  [green]✓[/green] Tools registered: {tool_count}")
    except Exception:
        console.print("  [yellow]?[/yellow] Tools registered: unknown")

    # Check 4: Last MCP log entry (if log file exists)
    mcp_log = Path.home() / ".msapling" / "mcp_last_connect.txt"
    if mcp_log.exists():
        try:
            last = mcp_log.read_text().strip()
            console.print(f"  [green]✓[/green] Last connection: {last}")
        except Exception:
            pass
    else:
        console.print("  [dim]  No connection history[/dim]")

    console.print("[dim]Tip: run 'msapling doctor --exhaustive' for the full 8-check health report.[/dim]")

    if strict and failures:
        raise typer.Exit(1)


@app.command()
def version():
    """Show version."""
    console.print(f"msapling-cli v{__version__}")


def _get_scripts_dir() -> "Path":
    """Return the pip Scripts/bin directory for the current interpreter."""
    from pathlib import Path as _Path
    base = _Path(sys.executable).resolve().parent
    # In a venv the scripts dir is next to the interpreter; in a system install
    # it may be in a sibling Scripts (Windows) or bin (Unix) directory.
    candidates = [base, base / "Scripts", base.parent / "Scripts",
                  base / "bin", base.parent / "bin"]
    for d in candidates:
        if (d / "msapling").exists() or (d / "msapling.exe").exists():
            return d
    # Fall back to the directory containing this interpreter
    return base


def _print_path_guidance() -> None:
    """Print post-install PATH guidance so the new binary is reachable."""
    import os as _os
    from pathlib import Path as _Path

    scripts_dir = _get_scripts_dir()
    path_env = _os.environ.get("PATH", "")
    in_path = str(scripts_dir) in path_env or str(scripts_dir).lower() in path_env.lower()

    if in_path:
        console.print("[dim]Restart your shell (or open a new terminal) to use the updated version.[/dim]")
        return

    console.print()
    console.print("[yellow]PATH notice:[/yellow] msapling may not be reachable after this upgrade.")
    console.print(f"  Scripts directory: [cyan]{scripts_dir}[/cyan]")
    if sys.platform == "win32":
        console.print("  Add it to your PATH permanently (PowerShell, run once):")
        console.print(f'    [dim]$env:PATH += ";{scripts_dir}"[/dim]')
        console.print("  Or permanently via System Properties → Environment Variables.")
        console.print("  Then open a new terminal to pick up the change.")
    else:
        shell_rc = "~/.zshrc" if _os.environ.get("SHELL", "").endswith("zsh") else "~/.bashrc"
        console.print(f"  Add to {shell_rc}:")
        console.print(f'    [dim]export PATH="$PATH:{scripts_dir}"[/dim]')
        console.print("  Then run: source " + shell_rc)


@app.command(name="path-check")
def path_check():
    """Check whether the msapling binary is reachable on PATH.

    Diagnoses common Windows and Unix install / PATH issues so users
    don't hit 'command not found' after install or upgrade.
    """
    import os as _os
    import shutil as _shutil

    scripts_dir = _get_scripts_dir()
    path_env = _os.environ.get("PATH", "")
    in_path = str(scripts_dir) in path_env or str(scripts_dir).lower() in path_env.lower()
    which = _shutil.which("msapling")

    console.print(f"  Scripts dir:  [cyan]{scripts_dir}[/cyan]")
    console.print(f"  In PATH:      {'[green]yes[/green]' if in_path else '[red]no[/red]'}")
    console.print(f"  which msapling: [cyan]{which or 'not found'}[/cyan]")
    console.print(f"  Python:       [dim]{sys.executable}[/dim]")

    if not in_path or not which:
        console.print()
        console.print("[yellow]Fix:[/yellow] Run `msapling upgrade` for instructions, or add manually:")
        if sys.platform == "win32":
            console.print(f'  PowerShell: $env:PATH += ";{scripts_dir}"')
        else:
            console.print(f'  Bash/Zsh: export PATH="$PATH:{scripts_dir}"')
        raise typer.Exit(1)

    console.print("[green]PATH looks correct.[/green]")


@app.command()
def upgrade():
    """Upgrade msapling-cli to the latest version from PyPI."""
    import subprocess as _sp

    try:
        # Check current vs. latest version
        import importlib.metadata as _meta
        current = _meta.version("msapling-cli")
    except Exception:
        current = __version__

    console.print(f"Current version: [cyan]{current}[/cyan]")
    console.print("Checking PyPI for latest version...")

    try:
        import urllib.request, json as _json
        with urllib.request.urlopen("https://pypi.org/pypi/msapling-cli/json", timeout=5) as r:
            data = _json.loads(r.read())
        latest = data["info"]["version"]
        console.print(f"Latest version:  [cyan]{latest}[/cyan]")
        if latest == current:
            console.print("[green]Already up to date.[/green]")
            return
    except Exception:
        console.print("[yellow]Could not fetch version info from PyPI. Attempting upgrade anyway...[/yellow]")
        latest = "?"

    console.print(f"Upgrading msapling-cli {current} → {latest}...")
    with console.status("[ms.accent]Installing...[/ms.accent]", spinner="dots"):
        result = _sp.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "msapling-cli"],
            capture_output=True,
            text=True,
        )
    if result.returncode == 0:
        console.print("[green]Upgrade complete.[/green]")
        _print_path_guidance()
    else:
        console.print(f"[red]Upgrade failed:[/red]\n{result.stderr}")
        raise typer.Exit(1)


async def _doctor_api_check(api_url: str, token: Optional[str]):
    """Probe backend /health and /users/me; return (reachable, identity, error).

    The backend uses JWT cookie auth (msaplingauth), not Bearer tokens, for /users/me.
    We send the token as both the cookie and a Bearer header to cover all auth backends.
    """
    import httpx
    try:
        cookies = {}
        headers = {}
        if token:
            # Cookie auth: matches how MSaplingClient._get_client() authenticates
            cookies["msaplingauth"] = token
            # Bearer fallback for any endpoints that support it
            headers["Authorization"] = f"Bearer {token}"
        async with httpx.AsyncClient(base_url=api_url, timeout=5.0, cookies=cookies) as client:
            health_resp = await client.get("/health")
            reachable = health_resp.status_code == 200
            identity = None
            error = None
            if reachable:
                try:
                    me_resp = await client.get("/users/me", headers=headers)
                    if me_resp.status_code == 200:
                        me_data = me_resp.json()
                        identity = me_data.get("email") or me_data.get("username")
                    else:
                        error = f"{me_resp.status_code} {me_resp.reason_phrase}"
                except Exception as exc:
                    error = str(exc)
            return (reachable, identity, error)
    except Exception as exc:
        return (False, None, str(exc))


@app.command()
def doctor(
    exhaustive: bool = typer.Option(
        False,
        "--exhaustive",
        help="Run all extended checks (network, drift, workers, WS).",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit JSON instead of the human-readable report.",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Exit with code 1 if any check fails (including auth).",
    ),
):
    """Run an exhaustive health check of MSapling CLI and backend connectivity."""
    import json as _json
    import shutil
    from datetime import datetime, timezone

    from . import doctor as _doctor

    settings = get_settings()
    api_url = settings.api_url
    token = get_token()
    token_source = get_token_source()
    token_sources = inspect_token_sources()

    date_str = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    # --exhaustive: delegate entirely to the doctor module
    if exhaustive:
        results = asyncio.run(_doctor.run_all_checks(api_url, token))
        has_failures = any(s == "fail" for _, s, _ in results)
        if json_output:
            output = {
                "timestamp": date_str,
                "checks": [
                    {"name": name, "status": status, "detail": detail}
                    for name, status, detail in results
                ],
                "healthy": not has_failures,
            }
            console.print_json(_json.dumps(output))
        else:
            _doctor.print_report(results, date_str)
        if has_failures:
            raise typer.Exit(1)
        return

    # -----------------------------------------------------------------------
    # Default / --json mode: structured report
    # -----------------------------------------------------------------------
    reachable, identity, api_error = _run(_doctor_api_check(api_url, token))

    # Auth conflict: file vs keyring disagree (both non-None but different)
    env_tok = token_sources.get("env")
    file_tok = token_sources.get("file")
    kr_tok = token_sources.get("keyring")
    auth_conflict = bool(
        (env_tok and kr_tok and env_tok != kr_tok)
        or (env_tok and file_tok and env_tok != file_tok)
        or (file_tok and kr_tok and file_tok != kr_tok)
    )

    warnings: list[str] = []
    failures: list[str] = []

    if auth_conflict:
        warnings.append("auth_conflict")
    if not token:
        warnings.append("no_token")
    if not shutil.which("git"):
        warnings.append("git_not_found")
    if not shutil.which("rg"):
        warnings.append("ripgrep_not_found")

    auth_check_ok = identity is not None and api_error is None
    if strict and not auth_check_ok and token:
        failures.append("auth_check_failed")
    if strict and not reachable:
        failures.append("backend_unreachable")

    report = {
        "version": __version__,
        "timestamp": date_str,
        "auth": {
            "present": bool(token),
            "source": token_source,
            "conflict": auth_conflict,
            "identity": identity,
        },
        "api": {
            "url": api_url,
            "reachable": reachable,
            "auth_check_ok": auth_check_ok,
            "identity": identity,
            "error": api_error,
        },
        "python": {
            "version": sys.version.split()[0],
            "ok": sys.version_info >= (3, 10),
        },
        "tools": {
            "git": shutil.which("git"),
            "rg": shutil.which("rg"),
        },
        "warnings": warnings,
        "failures": failures,
        "healthy": not failures,
    }

    # -----------------------------------------------------------------------
    # MCP startup state
    # -----------------------------------------------------------------------
    import importlib.util
    from pathlib import Path as _Path

    # Transport: prefer MCP_TRANSPORT env var, then config file, default stdio
    mcp_transport_env = os.environ.get("MCP_TRANSPORT", "")
    mcp_transport = mcp_transport_env.strip().lower() if mcp_transport_env.strip() else "stdio"

    # Whether mcp-serve is startable: check that the mcp.server module is importable
    _mcp_spec = importlib.util.find_spec("msapling_cli.mcp.server")
    mcp_startable = _mcp_spec is not None

    # Last MCP handshake timestamp
    _handshake_file = _Path.home() / ".msapling" / "mcp_last_handshake"
    if _handshake_file.exists():
        try:
            mcp_last_handshake = _handshake_file.read_text(encoding="utf-8").strip()
        except OSError:
            mcp_last_handshake = "unreadable"
    else:
        mcp_last_handshake = "never"

    # Any transport error from error log
    _mcp_error_log = _Path.home() / ".msapling" / "mcp_error.log"
    if _mcp_error_log.exists():
        try:
            _error_text = _mcp_error_log.read_text(encoding="utf-8").strip()
            mcp_transport_error = _error_text[-500:] if _error_text else None
        except OSError:
            mcp_transport_error = "unreadable"
    else:
        mcp_transport_error = None

    mcp_info = {
        "transport": mcp_transport,
        "transport_source": "env" if mcp_transport_env.strip() else "default",
        "startable": mcp_startable,
        "last_handshake": mcp_last_handshake,
        "transport_error": mcp_transport_error,
    }
    report["mcp"] = mcp_info

    if json_output:
        typer.echo(_json.dumps(report))
    else:
        _mcp_transport_status = "ok" if mcp_startable else "warn"
        _mcp_transport_detail = (
            f"transport={mcp_transport} (source={mcp_info['transport_source']}), "
            f"startable={'yes' if mcp_startable else 'NO'}, "
            f"last_handshake={mcp_last_handshake}"
        )
        if mcp_transport_error:
            _mcp_transport_status = "warn"
            _mcp_transport_detail += f", error={mcp_transport_error[:120]}"
        _doctor.print_report(
            [
                ("Backend reachable", "ok" if reachable else "fail",
                 f"{api_url} {'reachable' if reachable else 'UNREACHABLE'}"),
                ("Auth", "ok" if auth_check_ok else ("warn" if not token else "fail"),
                 f"{'Logged in as ' + identity if identity else 'Not authenticated'}"
                 + (" [CONFLICT]" if auth_conflict else "")),
                ("Python", "ok" if sys.version_info >= (3, 10) else "fail",
                 sys.version.split()[0]),
                ("Tools", "ok" if (shutil.which("git") and shutil.which("rg")) else "warn",
                 f"git={'found' if shutil.which('git') else 'MISSING'}, "
                 f"rg={'found' if shutil.which('rg') else 'MISSING'}"),
                ("MCP", _mcp_transport_status, _mcp_transport_detail),
            ],
            date_str,
        )

    if failures:
        raise typer.Exit(1)


# ─── Non-Interactive Agent Session ───────────────────────────────────

async def _run_agentic_edit_workflow(
    *,
    prompt: str,
    target: Path,
    model_id: str,
    max_iterations: int,
    verify_commands: List[str],
    timeout: float,
    json_output: bool,
) -> int:
    """Plan -> edit -> verify -> iterate workflow for coding parity."""
    import json as _json

    workspace_root = detect_workspace_root(target.expanduser().parent)
    workspace_index = build_workspace_index(workspace_root)
    try:
        target_path, target_rel = validate_repo_target(
            target,
            workspace_root=workspace_root,
            workspace_index=workspace_index,
        )
    except ValueError as exc:
        if json_output:
            typer.echo(_json.dumps({"mode": "agentic", "error": str(exc), "exit_code": 1}))
        else:
            console.print(f"[red]{exc}[/red]")
        return 1

    original = target_path.read_text(encoding="utf-8")
    current_content = original
    verification_feedback = ""
    plan_text = ""
    client = MSaplingClient()
    try:
        async with asyncio.timeout(timeout):
            plan_prompt = (
                "Create a concise implementation plan for the requested file fix. "
                "Respond with numbered steps only.\n\n"
                f"Task: {prompt}\n"
                f"Workspace: {workspace_root}\n"
                f"Target: {target_rel}\n"
                f"Current content:\n```\n{current_content[:12000]}\n```"
            )
            plan_text = await client.chat_once(plan_prompt, model_id, history_enabled=False)
            if not json_output:
                console.print(Panel(Markdown(plan_text), title="Agentic Plan", border_style="cyan"))

            for iteration in range(1, max(1, int(max_iterations)) + 1):
                if not json_output:
                    console.print(
                        f"[cyan]Agentic iteration {iteration}/{max(1, int(max_iterations))}: "
                        f"editing {target_rel}[/cyan]"
                    )
                edit_prompt = (
                    f"Task: {prompt}\n\n"
                    f"Workspace root: {workspace_root}\n"
                    f"Target file: {target_rel}\n"
                    f"Current file content:\n```\n{current_content}\n```\n\n"
                    "Return ONLY a unified diff for this file. "
                    "Do not include prose or markdown fences."
                )
                if verification_feedback:
                    edit_prompt += (
                        "\n\nPrior attempt failed verification. Fix all failures while preserving behavior.\n"
                        f"Verification output:\n{verification_feedback}\n"
                    )

                raw = await client.chat_once(edit_prompt, model_id, history_enabled=False)
                diff_text = normalize_unified_diff_headers(_extract_unified_diff(raw))
                diff_text = _retarget_single_file_diff(diff_text, target_rel)
                if not diff_text.strip():
                    verification_feedback = "Model returned empty diff output."
                    continue

                try:
                    enforce_repo_grounded_diff(
                        diff_text,
                        workspace_index=workspace_index,
                        allowed_paths=[target_rel],
                    )
                except ValueError as exc:
                    if json_output:
                        typer.echo(_json.dumps({"mode": "agentic", "error": str(exc), "exit_code": 1}))
                    else:
                        console.print(f"[red]{exc}[/red]")
                    return 1

                evidence = extract_structured_evidence(diff_text, default_file=target_rel)
                if not evidence:
                    verification_feedback = (
                        "Evidence guardrail failed: provide changes with clear hunks and changed snippets."
                    )
                    continue

                if not json_output:
                    console.print(
                        Panel(Syntax(diff_text, "diff", theme="monokai"), title=f"Agentic diff for {target_rel}")
                    )
                    _render_evidence_table(evidence)

                applied = await _apply_diff_with_fallback(
                    client=client,
                    path=target_path,
                    original=current_content,
                    diff_text=diff_text,
                    raw_response=raw,
                )
                if not bool(applied.get("applied")):
                    verification_feedback = str((applied.get("result") or {}).get("error") or "Diff apply failed.")
                    continue

                candidate_content = str(applied.get("new_content") or "")
                if candidate_content:
                    target_path.write_text(candidate_content, encoding="utf-8")
                    current_content = candidate_content

                verification = run_verify_commands(verify_commands, cwd=workspace_root)
                if verification.ok:
                    if json_output:
                        typer.echo(
                            _json.dumps(
                                {
                                    "mode": "agentic",
                                    "status": "ok",
                                    "target": target_rel,
                                    "iterations_used": iteration,
                                    "plan": plan_text,
                                    "verification_commands": verify_commands,
                                }
                            )
                        )
                    else:
                        console.print(
                            f"[green]Agentic edit completed for {target_rel} in {iteration} iteration(s).[/green]"
                        )
                    return 0

                verification_feedback = verification.failure_summary()
                if not json_output:
                    console.print("[yellow]Verification failed; iterating with repair feedback...[/yellow]")

    except asyncio.TimeoutError:
        if json_output:
            typer.echo(_json.dumps({"mode": "agentic", "error": f"Request timed out after {timeout:.0f}s", "exit_code": 1}))
        else:
            console.print(f"[red]Request timed out after {timeout:.0f}s[/red]")
        target_path.write_text(original, encoding="utf-8")
        return 1
    except Exception as exc:
        status = _status_code_from_exception(exc)
        code = 1
        if status in (401, 403):
            code = 2
        elif status in (402, 429):
            code = 3
        if json_output:
            typer.echo(_json.dumps({"mode": "agentic", "error": str(exc), "exit_code": code}))
        else:
            _handle_api_error(exc, "run --agentic")
        target_path.write_text(original, encoding="utf-8")
        return code
    finally:
        await client.close()

    target_path.write_text(original, encoding="utf-8")
    if json_output:
        typer.echo(
            _json.dumps(
                {
                    "mode": "agentic",
                    "status": "failed",
                    "target": target_rel,
                    "plan": plan_text,
                    "verification_commands": verify_commands,
                    "exit_code": 1,
                    "rolled_back": True,
                }
            )
        )
    else:
        console.print("[red]Agentic workflow failed after all iterations. Rolled back file to original content.[/red]")
    return 1


@app.command()
def run(
    prompt: Optional[str] = typer.Argument(None, help="Prompt text to send (omit to read from stdin or --file)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model ID override"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project context to run in"),
    chat: Optional[str] = typer.Option(None, "--chat", help="Chat ID to use (advanced, normally auto-resolved)"),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read prompt from file"),
    use_stdin: bool = typer.Option(False, "--stdin", help="Explicitly read prompt from stdin"),
    json_output: bool = typer.Option(False, "--json", help="Output JSON: {response, model, tokens, cost_usd}"),
    stream: bool = typer.Option(False, "--stream", help="Stream tokens to stdout as they arrive"),
    max_tokens: Optional[int] = typer.Option(None, "--max-tokens", help="Limit output tokens (passed to model)"),
    timeout: float = typer.Option(120.0, "--timeout", help="Abort after N seconds (default 120)"),
    agentic: bool = typer.Option(
        False,
        "--agentic",
        help="Plan->edit->verify workflow for code-fix tasks.",
    ),
    target: Optional[Path] = typer.Option(
        None,
        "--target",
        help="Workspace file target required for --agentic mode.",
    ),
    max_iterations: int = typer.Option(
        3,
        "--max-iterations",
        min=1,
        max=8,
        help="Maximum edit/verify iterations for --agentic mode.",
    ),
    verify_cmd: List[str] = typer.Option(
        None,
        "--verify-cmd",
        help="Verification command for --agentic mode (repeatable).",
    ),
):
    """Run a prompt non-interactively — for CI/CD, scripts, and automation.

    Reads prompt from argument, --file, or stdin (piped or --stdin flag).
    Prints the response to stdout and exits. No interactive shell.

    Exit codes:
      0 — success
      1 — API / general error
      2 — authentication error
      3 — quota exceeded

    Examples:

    \\b
      # Inline prompt
      msapling run "Review these changes for security issues"

    \\b
      # Pipe git diff into the prompt
      git diff HEAD~1 | msapling run --model anthropic/claude-3-haiku --json

    \\b
      # Read prompt from file, append piped stdin, output JSON
      msapling run --file prompts/daily_check.txt --project DevTeam --json

    \\b
      # Scheduled standup — append to JSONL log
      msapling run --file daily_standup.txt --project DevTeam --json >> logs/standup.jsonl

    \\b
      # Stream tokens directly to terminal
      msapling run --stream "Explain async/await in Python"
    """
    from .noninteractive_session import _resolve_prompt, run_noninteractive

    # Read piped stdin once so it can be appended to --file or prompt arg
    piped_stdin: Optional[str] = None
    if not sys.stdin.isatty() and not use_stdin:
        # stdin is piped but --stdin flag not set — still read it so it can
        # be appended to a --file prompt or inline prompt argument.
        try:
            piped_stdin = sys.stdin.read()
        except Exception:
            piped_stdin = None
    elif use_stdin:
        try:
            piped_stdin = sys.stdin.read()
        except Exception:
            piped_stdin = None

    effective_prompt = _resolve_prompt(
        prompt_arg=prompt,
        file=file,
        use_stdin=use_stdin,
        extra_stdin=piped_stdin,
    )

    if not effective_prompt:
        console.print("[red]Error: no prompt provided. Pass a prompt argument, --file, or pipe via stdin.[/red]")
        raise typer.Exit(1)

    if agentic:
        if target is None:
            console.print("[red]--agentic requires --target <file>[/red]")
            raise typer.Exit(1)
        user = _get_user_or_exit()
        require_pro(user, "run --agentic")
        settings = get_settings()
        model_id = model or settings.default_model
        workspace_root = detect_workspace_root(target.expanduser().parent)
        verify_commands = [str(cmd).strip() for cmd in (verify_cmd or []) if str(cmd).strip()]
        if not verify_commands:
            try:
                _, target_rel_for_defaults = validate_repo_target(
                    target,
                    workspace_root=workspace_root,
                    workspace_index=build_workspace_index(workspace_root),
                )
                verify_commands = build_default_verify_commands(
                    target_rel_for_defaults,
                    workspace_root=workspace_root,
                )
            except Exception:
                verify_commands = []
        if not verify_commands:
            console.print(
                "[yellow]No verification commands configured for --agentic. "
                "Use --verify-cmd for project-specific checks.[/yellow]"
            )
        exit_code = _run(
            _run_agentic_edit_workflow(
                prompt=effective_prompt,
                target=target,
                model_id=model_id,
                max_iterations=max_iterations,
                verify_commands=verify_commands,
                timeout=timeout,
                json_output=json_output,
            )
        )
        if exit_code != 0:
            raise typer.Exit(exit_code)
        return

    exit_code = _run(run_noninteractive(
        prompt=effective_prompt,
        model=model,
        project=project,
        max_tokens=max_tokens,
        json_output=json_output,
        stream=stream,
        timeout=timeout,
    ))
    if exit_code != 0:
        raise typer.Exit(exit_code)


# ─── Log Streaming ───────────────────────────────────────────────────

@app.command()
def logs(
    follow: bool = typer.Option(False, "-f", "--follow", help="Follow/tail mode — stream new log entries as they arrive (SSE)"),
    level: str = typer.Option("INFO", "--level", "-l", help="Minimum log level: DEBUG, INFO, WARNING, ERROR"),
    lines: int = typer.Option(50, "-n", "--lines", help="Number of recent log lines to show"),
):
    """Watch backend logs in real-time (admin only).

    Examples:
        msapling logs              # show last 50 log lines
        msapling logs -f           # follow/tail mode (SSE stream)
        msapling logs --level WARN # filter by level
        msapling logs -n 200       # show last 200 lines
        msapling logs -f -l ERROR  # follow, errors only
    """
    import json as _json
    import httpx as _httpx
    import datetime as _dt

    # Per-level Rich style
    _LEVEL_STYLES = {
        "DEBUG": "dim white",
        "INFO": "white",
        "WARNING": "yellow",
        "WARN": "yellow",
        "ERROR": "bold red",
        "CRITICAL": "bold red",
    }

    def _format_entry(entry: dict) -> str:
        lvl = str(entry.get("lvl", "INFO")).upper()
        style = _LEVEL_STYLES.get(lvl, "white")
        ts_raw = entry.get("ts")
        if ts_raw:
            try:
                ts_str = _dt.datetime.fromtimestamp(float(ts_raw)).strftime("%H:%M:%S")
            except Exception:
                ts_str = str(ts_raw)
        else:
            ts_str = "??"
        msg = str(entry.get("msg", "")).rstrip()
        return f"[{style}][{lvl:8s}][/{style}] [dim]{ts_str}[/dim] {msg}"

    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run: msapling login[/red]")
        raise typer.Exit(1)

    settings = get_settings()
    base_url = settings.api_url.rstrip("/")
    params: dict = {
        "level": level.upper(),
        "limit": str(lines),
        "follow": "true" if follow else "false",
    }
    req_headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "text/event-stream" if follow else "application/json",
    }

    if follow:
        console.print(
            f"[cyan]Following backend logs[/cyan] "
            f"(level=[bold]{level.upper()}[/bold], Ctrl+C to stop)"
        )
        console.rule()
        try:
            with _httpx.Client(
                base_url=base_url,
                headers=req_headers,
                timeout=None,
            ) as client:
                with client.stream(
                    "GET",
                    "/api/admin/logs/stream",
                    params=params,
                ) as resp:
                    if resp.status_code == 403:
                        console.print("[red]Access denied — admin account required[/red]")
                        raise typer.Exit(1)
                    if resp.status_code != 200:
                        console.print(f"[red]Server error {resp.status_code}[/red]")
                        raise typer.Exit(1)
                    for raw_line in resp.iter_lines():
                        raw_line = raw_line.strip()
                        if not raw_line or raw_line.startswith(":"):
                            # SSE keepalive comment — ignore
                            continue
                        if raw_line.startswith("data:"):
                            payload = raw_line[5:].strip()
                        else:
                            payload = raw_line
                        if not payload:
                            continue
                        try:
                            entry = _json.loads(payload)
                            console.print(_format_entry(entry))
                        except Exception:
                            console.print(f"[dim]{payload}[/dim]")
        except KeyboardInterrupt:
            console.print("\n[yellow]Stream stopped[/yellow]")
        except _httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            if status == 403:
                console.print("[red]Access denied — admin account required[/red]")
            else:
                console.print(f"[red]HTTP error {status}: {exc}[/red]")
            raise typer.Exit(1)
        except Exception as exc:
            console.print(f"[red]{type(exc).__name__}: {exc}[/red]")
            raise typer.Exit(1)
    else:
        # Non-follow: fetch snapshot then print
        async def _fetch_snapshot() -> None:
            client = MSaplingClient()
            try:
                http = await client._get_client()
                resp = await http.get(
                    "/api/admin/logs/stream",
                    params=params,
                    headers={"Accept": "application/json"},
                )
                if resp.status_code == 403:
                    console.print("[red]Access denied — admin account required[/red]")
                    raise typer.Exit(1)
                if resp.status_code != 200:
                    console.print(f"[red]Server returned {resp.status_code}[/red]")
                    raise typer.Exit(1)
                entries = _json.loads(resp.text)
                if not entries:
                    console.print("[yellow]No log entries in buffer yet[/yellow]")
                    return
                console.print(
                    f"[cyan]Last {len(entries)} log entries[/cyan] "
                    f"(level=[bold]{level.upper()}[/bold])"
                )
                console.rule()
                for entry in entries:
                    console.print(_format_entry(entry))
            except typer.Exit:
                raise
            except Exception as exc:
                console.print(f"[red]{type(exc).__name__}: {exc}[/red]")
                raise typer.Exit(1)
            finally:
                await client.close()

        _run(_fetch_snapshot())


# ─── Keys (BYOK Token Ingest) ─────────────────────────────────────────────

keys_app = typer.Typer(help="Manage BYOK keys and ingest API keys from external tools.")
app.add_typer(keys_app, name="keys")


@keys_app.command("ingest")
def keys_ingest(
    dry_run: bool = typer.Option(False, "--dry-run", help="Show discovered keys without uploading."),
    source: Optional[str] = typer.Option(
        None,
        "--source",
        help="Only scan a specific source: claude, gemini, openrouter. Omit to scan all.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt and upload immediately."),
):
    """Discover API keys from Claude Code / Gemini CLI / OpenRouter configs and upload to MSapling Smart Key Pool.

    Examples:
        msapling keys ingest --dry-run         # show what would be uploaded
        msapling keys ingest                   # interactive ingest (confirm before upload)
        msapling keys ingest --yes             # ingest without confirmation
        msapling keys ingest --source claude   # only scan Claude settings
        msapling keys ingest --source gemini   # only scan Gemini settings
        msapling keys ingest --source openrouter
    """
    from .ingest_keys import (
        discover_claude_keys,
        discover_gemini_keys,
        discover_openrouter_keys,
        _redact,
        _dedup_against_existing,
        _fetch_existing_prefixes,
    )
    from .tui import console as _console

    token = get_token()
    if not token and not dry_run:
        console.print("[red]Not logged in. Run: msapling login[/red]")
        raise typer.Exit(1)

    # Collect keys from requested sources
    discovered: list = []
    src = (source or "").lower().strip()

    if src and src not in ("claude", "gemini", "openrouter"):
        console.print(f"[red]Unknown source '{source}'. Valid: claude, gemini, openrouter[/red]")
        raise typer.Exit(1)

    if not src or src == "claude":
        claude_keys = discover_claude_keys()
        discovered.extend(claude_keys)
        console.print(f"[dim]Claude settings: {len(claude_keys)} key(s) found[/dim]")

    if not src or src == "gemini":
        gemini_keys = discover_gemini_keys()
        discovered.extend(gemini_keys)
        console.print(f"[dim]Gemini config: {len(gemini_keys)} key(s) found[/dim]")

    if not src or src == "openrouter":
        or_keys = discover_openrouter_keys()
        discovered.extend(or_keys)
        console.print(f"[dim]OpenRouter config: {len(or_keys)} key(s) found[/dim]")

    if not discovered:
        console.print("[yellow]No API keys found in scanned locations.[/yellow]")
        return

    if dry_run:
        from rich.table import Table

        table = Table(title="Discovered Keys (dry run — no upload)")
        table.add_column("Source", style="cyan")
        table.add_column("Provider", style="magenta")
        table.add_column("Key (redacted)")
        table.add_column("Path", style="dim")
        for entry in discovered:
            table.add_row(
                entry.get("source", "?"),
                entry.get("provider", "unknown"),
                _redact(entry["key"]),
                entry.get("path", ""),
            )
        console.print(table)
        console.print(f"[green]Dry run: {len(discovered)} key(s) found. No upload performed.[/green]")
        return

    async def _do_ingest():
        from rich.table import Table
        from rich.prompt import Confirm

        client = MSaplingClient()
        try:
            table = Table(title="Discovered Keys")
            table.add_column("Source", style="cyan")
            table.add_column("Provider", style="magenta")
            table.add_column("Key (redacted)")
            table.add_column("Path", style="dim")
            for entry in discovered:
                table.add_row(
                    entry.get("source", "?"),
                    entry.get("provider", "unknown"),
                    _redact(entry["key"]),
                    entry.get("path", ""),
                )
            console.print(table)

            # De-duplicate against already-stored keys
            existing_prefixes = await _fetch_existing_prefixes(client)
            to_upload = _dedup_against_existing(discovered, existing_prefixes)
            skipped = len(discovered) - len(to_upload)
            if skipped:
                console.print(f"[dim]{skipped} key(s) already in pool — skipped.[/dim]")

            if not to_upload:
                console.print("[green]All discovered keys are already in the pool.[/green]")
                return

            # User confirmation
            if not yes:
                proceed = Confirm.ask(
                    f"Upload {len(to_upload)} key(s) to MSapling Smart Key Pool?",
                    default=False,
                )
                if not proceed:
                    console.print("[yellow]Upload cancelled.[/yellow]")
                    return

            uploaded = 0
            errors = 0
            http_client = await client._get_client()
            for i, entry in enumerate(to_upload, 1):
                label = f"{entry['source']}-{entry['provider']}-ingest-{i}"
                payload = {
                    "name": label,
                    "external_key": entry["key"],
                    "provider": entry["provider"],
                    "source": entry["source"],
                }
                try:
                    resp = await client._request_with_csrf_retry(
                        lambda: http_client.post("/api/user/api-keys", json=payload)
                    )
                    resp.raise_for_status()
                    console.print(
                        f"[green]Uploaded[/green]: {entry['provider']} key {_redact(entry['key'])}"
                    )
                    uploaded += 1
                except Exception as exc:
                    console.print(f"[red]Failed to upload {_redact(entry['key'])}: {exc}[/red]")
                    errors += 1

            console.print(
                f"\n[bold]Done:[/bold] {uploaded} uploaded, {skipped} skipped (already existed), {errors} errors."
            )
        except Exception as exc:
            _handle_error(exc, context="keys ingest")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_do_ingest())


@keys_app.command("list")
def keys_list(
    output: str = typer.Option("text", "--output", "-o", help="Output format: text or json"),
):
    """List your currently stored BYOK keys in the MSapling Smart Key Pool.

    Examples:
        msapling keys list
        msapling keys list --output json
    """
    import json as _json

    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run: msapling login[/red]")
        raise typer.Exit(1)

    async def _list():
        from rich.table import Table

        client = MSaplingClient()
        try:
            data = await client.get("/api/user/api-keys")
            if output == "json":
                console.print(_json.dumps(data, indent=2))
                return
            if not isinstance(data, list) or not data:
                console.print("[yellow]No API keys stored.[/yellow]")
                return
            table = Table(title="Stored BYOK Keys")
            table.add_column("ID", style="dim")
            table.add_column("Name", style="cyan")
            table.add_column("Prefix")
            table.add_column("Created")
            table.add_column("Last Used")
            table.add_column("Expires")
            for k in data:
                table.add_row(
                    str(k.get("id", ""))[:8] + "...",
                    str(k.get("name", "")),
                    str(k.get("prefix", "")),
                    str(k.get("created_at", ""))[:10],
                    str(k.get("last_used_at", "") or "never")[:10],
                    str(k.get("expires_at", "") or "never")[:10],
                )
            console.print(table)
        except Exception as exc:
            _handle_error(exc, context="keys list")
            raise typer.Exit(1)
        finally:
            await client.close()

    _run(_list())


# ─── Sessions ────────────────────────────────────────────────────────────────

agents_app = typer.Typer(help="Manage multi/swarm agent registry controls.")
app.add_typer(agents_app, name="agents")


@agents_app.command("list")
def agents_list(
    enabled_only: bool = typer.Option(False, "--enabled-only", help="Show only enabled agents."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
):
    """List persisted agents used by multi/swarm defaults."""
    import json as _json

    agents = list_registry_agents(enabled_only=enabled_only)
    if json_output:
        console.print(_json.dumps([a.to_dict() for a in agents], indent=2))
        return

    if not agents:
        console.print("[yellow]No agents configured.[/yellow]")
        return

    table = Table(title="Agent Registry")
    table.add_column("#", style="cyan", width=3)
    table.add_column("ID", style="bold")
    table.add_column("Name")
    table.add_column("Model")
    table.add_column("Enabled", justify="center")
    table.add_column("Max", justify="right")
    table.add_column("Tags")
    table.add_column("Updated")
    for i, agent in enumerate(agents, 1):
        updated = ""
        try:
            if agent.updated_at:
                updated = time.strftime("%Y-%m-%d %H:%M", time.localtime(float(agent.updated_at)))
        except Exception:
            updated = str(agent.updated_at or "")
        table.add_row(
            str(i),
            agent.id,
            agent.name,
            agent.model,
            "yes" if agent.enabled else "no",
            str(agent.max_parallel),
            ",".join(agent.tags) if agent.tags else "—",
            updated or "—",
        )
    console.print(table)


@agents_app.command("reload")
def agents_reload(
    reset: bool = typer.Option(False, "--reset", help="Reset registry to built-in defaults."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
):
    """Reload persisted agent registry and merge in default entries."""
    import json as _json

    agents = reload_agent_registry(reset=reset)
    if json_output:
        console.print(_json.dumps([a.to_dict() for a in agents], indent=2))
        return
    mode = "Reset" if reset else "Reloaded"
    console.print(f"[green]{mode} agent registry.[/green] ({len(agents)} agent(s))")


@agents_app.command("enable")
def agents_enable(
    ref: str = typer.Argument(..., help="Agent id/name/index."),
):
    """Enable an agent in the registry."""
    try:
        agent = set_registry_agent_enabled(ref, True)
    except KeyError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Enabled[/green] {agent.id} ({agent.model})")


@agents_app.command("disable")
def agents_disable(
    ref: str = typer.Argument(..., help="Agent id/name/index."),
):
    """Disable an agent in the registry."""
    try:
        agent = set_registry_agent_enabled(ref, False)
    except KeyError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    console.print(f"[yellow]Disabled[/yellow] {agent.id} ({agent.model})")


@agents_app.command("config")
def agents_config(
    ref: str = typer.Argument(..., help="Agent id/name/index."),
    model: Optional[str] = typer.Option(None, "--model", help="Set model id."),
    name: Optional[str] = typer.Option(None, "--name", help="Set display name."),
    description: Optional[str] = typer.Option(None, "--description", help="Set description."),
    max_parallel: Optional[int] = typer.Option(None, "--max-parallel", min=1, max=8, help="Set max parallel lanes."),
    tags: Optional[str] = typer.Option(None, "--tags", help="Comma-separated tags."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
):
    """Update an agent's model/name/limits/tags."""
    import json as _json

    tag_list: Optional[List[str]] = None
    if tags is not None:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    try:
        agent = configure_registry_agent(
            ref,
            model=model,
            name=name,
            description=description,
            max_parallel=max_parallel,
            tags=tag_list,
        )
    except KeyError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    if json_output:
        console.print(_json.dumps(agent.to_dict(), indent=2))
        return
    console.print(f"[green]Updated[/green] {agent.id} -> {agent.model}")


sessions_app = typer.Typer(help="Manage and search saved CLI sessions.")
app.add_typer(sessions_app, name="sessions")


@sessions_app.command("list")
def sessions_list(
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum number of sessions to show"),
):
    """List saved sessions with metadata (project, model, cost, duration)."""
    from .session import list_sessions as _list_sessions
    sessions = _list_sessions(limit=limit)
    if not sessions:
        console.print("[yellow]No saved sessions.[/yellow]")
        return
    table = Table(title="Saved Sessions")
    table.add_column("#", style="cyan", width=3)
    table.add_column("ID")
    table.add_column("Project")
    table.add_column("Model")
    table.add_column("Msgs", justify="right")
    table.add_column("Cost (USD)", justify="right")
    table.add_column("Duration", justify="right")
    table.add_column("Summary")
    for i, s in enumerate(sessions, 1):
        meta = s.get("metadata", {})
        project = meta.get("project_name") or s.get("project_root", "—") or "—"
        if project and len(str(project)) > 20:
            project = "…" + str(project)[-18:]
        cost_val = meta.get("total_cost_usd") or 0.0
        cost_str = f"${cost_val:.4f}" if cost_val else "—"
        dur = meta.get("duration_seconds")
        if dur:
            mins, secs = divmod(int(dur), 60)
            dur_str = f"{mins}m{secs:02d}s" if mins else f"{secs}s"
        else:
            dur_str = "—"
        table.add_row(
            str(i),
            s.get("id", "?")[:12],
            str(project)[:20],
            s.get("model", "?").split("/")[-1][:16],
            str(len(s.get("messages", []))),
            cost_str,
            dur_str,
            (meta.get("summary") or s.get("_summary", ""))[:50],
        )
    console.print(table)


@sessions_app.command("search")
def sessions_search(
    query: str = typer.Argument(..., help="Search query (BM25 full-text ranking)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Maximum number of results"),
):
    """Search past sessions using BM25 full-text ranking.

    Indexes message content, title, project name, and models used.
    The index is cached in ~/.msapling/search_index.json and rebuilt
    automatically when session files are newer than the cache.

    Examples:
        msapling sessions search "async fastapi"
        msapling sessions search "billing invoice" --limit 5
    """
    from .session_search import build_default_index

    with console.status("[cyan]Building search index…[/cyan]", spinner="dots"):
        try:
            index = build_default_index()
        except Exception as exc:
            console.print(f"[red]Failed to build search index: {exc}[/red]")
            raise typer.Exit(1)

    results = index.search(query, top_k=limit)

    console.print(f"\n[bold]BM25 Session Search[/bold] — query: [cyan]{query}[/cyan]\n")

    if not results:
        console.print("[yellow]No matching sessions found.[/yellow]")
        return

    table = Table(title="Search Results", show_header=True, header_style="bold cyan")
    table.add_column("Rank", style="dim", width=4)
    table.add_column("Session ID")
    table.add_column("Title")
    table.add_column("Project")
    table.add_column("Score", justify="right")
    table.add_column("Snippet")

    for i, r in enumerate(results, 1):
        table.add_row(
            str(i),
            r.session_id[:12],
            (r.title or "")[:40],
            (r.project or "—")[:20],
            f"{r.score:.4f}",
            (r.matched_snippet or "")[:70],
        )

    console.print(table)
    console.print(
        f"\n[dim]Showing {len(results)} result(s). Use --limit to expand.[/dim]"
    )


@sessions_app.command("cleanup")
def sessions_cleanup(
    max_sessions: Optional[int] = typer.Option(
        None,
        "--max-sessions",
        help="Keep at most N most-recent local sessions.",
    ),
    max_age_days: Optional[int] = typer.Option(
        None,
        "--max-age-days",
        help="Delete sessions older than N days.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview what would be deleted without writing.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit machine-readable JSON output.",
    ),
):
    """Prune local session files by count and/or age retention."""
    import json as _json
    from .session import cleanup_sessions as _cleanup_sessions

    if max_sessions is None and max_age_days is None:
        console.print(
            "[red]Provide at least one retention bound: --max-sessions and/or --max-age-days.[/red]"
        )
        raise typer.Exit(1)

    try:
        result = _cleanup_sessions(
            max_sessions=max_sessions,
            max_age_days=max_age_days,
            dry_run=dry_run,
        )
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)

    if json_output:
        console.print(_json.dumps(result, indent=2))
        if result.get("error_count"):
            raise typer.Exit(1)
        return

    action = "Would remove" if dry_run else "Removed"
    console.print(
        f"[cyan]{action}[/cyan] [bold]{result['removed_count']}[/bold] session(s)"
    )
    console.print(
        f"[dim]Before: {result['total_before']} | After: {result['remaining_count']}[/dim]"
    )

    removed_ids = result.get("removed_session_ids") or []
    if removed_ids:
        shown = ", ".join(removed_ids[:10])
        if len(removed_ids) > 10:
            shown = f"{shown}, ..."
        console.print(f"[dim]Sessions: {shown}[/dim]")

    if result.get("error_count"):
        console.print(f"[red]Failed to delete {result['error_count']} session(s).[/red]")
        for err in (result.get("errors") or [])[:5]:
            console.print(
                f"[red]- {err.get('id', '?')}: {err.get('error', 'unknown error')}[/red]"
            )
        raise typer.Exit(1)


@sessions_app.command("doctor")
def sessions_doctor(
    limit: int = typer.Option(200, "--limit", "-n", help="Maximum number of local sessions to inspect."),
    changed_only: bool = typer.Option(False, "--changed-only", help="Show only sessions that need repair."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
):
    """Validate transcript hygiene invariants for local session files."""
    import json as _json
    from .session import list_sessions as _list_sessions

    sessions = _list_sessions(limit=max(1, limit))
    reports: List[Dict[str, Any]] = []
    for row in sessions:
        path = Path(str(row.get("_path") or "")).expanduser()
        if not path.is_file():
            continue
        result = repair_session_file(path, dry_run=True)
        if changed_only and not result.get("changed"):
            continue
        reports.append(result)

    changed = sum(1 for r in reports if r.get("changed"))
    errors = [r for r in reports if r.get("error")]
    payload = {
        "inspected": len(reports),
        "changed": changed,
        "unchanged": max(len(reports) - changed, 0),
        "errors": errors,
        "results": reports,
    }

    if json_output:
        console.print(_json.dumps(payload, indent=2))
        if errors:
            raise typer.Exit(1)
        return

    if not reports:
        console.print("[yellow]No sessions matched.[/yellow]")
        return

    table = Table(title="Session Hygiene Doctor")
    table.add_column("Session")
    table.add_column("Changed", justify="center")
    table.add_column("Dropped", justify="right")
    table.add_column("Roles", justify="right")
    table.add_column("Deduped", justify="right")
    table.add_column("Tool IDs", justify="right")
    table.add_column("Paired", justify="right")
    table.add_column("Unpaired", justify="right")
    table.add_column("Fixups", justify="right")
    table.add_column("Diff", justify="right")
    table.add_column("Error")
    for item in reports:
        report = item.get("report") or {}
        table.add_row(
            str(item.get("id", "?"))[:16],
            "yes" if item.get("changed") else "no",
            str(report.get("dropped_messages", 0)),
            str(report.get("rewritten_roles", 0)),
            str(report.get("deduped_messages", 0)),
            str(report.get("normalized_tool_call_ids", 0)),
            str(report.get("paired_tool_results", 0)),
            str(report.get("dropped_unpaired_tool_results", 0)),
            str(report.get("ordering_fixups", 0)),
            str(item.get("diff_line_count", 0)),
            str(item.get("error") or ""),
        )
    console.print(table)
    console.print(
        f"[dim]Inspected: {len(reports)} | Changed: {changed} | Errors: {len(errors)}[/dim]"
    )
    if errors:
        raise typer.Exit(1)


@sessions_app.command("repair")
def sessions_repair(
    session_id: Optional[str] = typer.Argument(
        None,
        help="Optional session id (full or prefix). Use --all to repair many.",
    ),
    all_sessions: bool = typer.Option(False, "--all", help="Repair every local session."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview repairs without writing."),
    show_diff: bool = typer.Option(True, "--show-diff/--no-show-diff", help="Show deterministic message diff previews."),
    limit: int = typer.Option(200, "--limit", "-n", help="Max sessions considered when using --all."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
):
    """Repair local session transcripts with backup files under sessions/archive/YYYYMMDD/."""
    import json as _json
    from .session import list_sessions as _list_sessions

    if not session_id and not all_sessions:
        console.print("[red]Provide a session id or pass --all.[/red]")
        raise typer.Exit(1)

    candidates = _list_sessions(limit=max(1, limit))
    if session_id:
        needle = session_id.strip().lower()
        candidates = [s for s in candidates if str(s.get("id", "")).lower().startswith(needle)]

    if not candidates:
        console.print("[yellow]No matching sessions found.[/yellow]")
        raise typer.Exit(1)

    results: List[Dict[str, Any]] = []
    for row in candidates:
        path = Path(str(row.get("_path") or "")).expanduser()
        if not path.is_file():
            continue
        results.append(repair_session_file(path, dry_run=dry_run))

    changed = sum(1 for r in results if r.get("changed"))
    errors = [r for r in results if r.get("error")]
    backups = [r.get("backup_path") for r in results if r.get("backup_path")]
    payload = {
        "dry_run": dry_run,
        "inspected": len(results),
        "changed": changed,
        "errors": errors,
        "backups": backups,
        "results": results,
    }

    if json_output:
        console.print(_json.dumps(payload, indent=2))
        if errors:
            raise typer.Exit(1)
        return

    action = "Would repair" if dry_run else "Repaired"
    console.print(f"[cyan]{action}[/cyan] [bold]{changed}[/bold] session(s).")
    if backups and not dry_run:
        console.print(f"[dim]Backups written: {len(backups)}[/dim]")
    if show_diff:
        changed_rows = [r for r in results if r.get("changed")]
        for item in changed_rows[:5]:
            preview = str(item.get("diff_preview") or "").strip()
            if not preview:
                continue
            console.print(
                Panel(
                    _console_safe_text(preview),
                    title=f"Repair Diff: {str(item.get('id', '?'))[:16]}",
                    border_style="cyan",
                )
            )
        if len(changed_rows) > 5:
            console.print(f"[dim]Additional diffs omitted: {len(changed_rows) - 5}[/dim]")
    if errors:
        console.print(f"[red]Encountered {len(errors)} error(s).[/red]")
        for err in errors[:5]:
            console.print(f"[red]- {err.get('id', '?')}: {err.get('error', 'unknown error')}[/red]")
        raise typer.Exit(1)


# ─── Credentials Encryption ───────────────────────────────────────────────────
# Salt file path for PBKDF2 key derivation.
_CREDENTIALS_FILE = Path.home() / ".msapling" / "credentials.json"
_CREDENTIALS_SALT_FILE = Path.home() / ".msapling" / ".credentials_salt"
_CREDENTIALS_ENCRYPTED_FILE = Path.home() / ".msapling" / "credentials.enc"


def _derive_fernet_key(password: str, salt: bytes) -> bytes:
    """Derive a Fernet-compatible key from ``password`` using PBKDF2-HMAC-SHA256."""
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    import base64
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=480_000,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


credentials_app = typer.Typer(help="Manage local credential encryption.")
app.add_typer(credentials_app, name="credentials")


@credentials_app.command("encrypt")
def credentials_encrypt(
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing encryption without prompt"),
):
    """Encrypt ~/.msapling/credentials.json using a master password (Fernet/PBKDF2).

    The encrypted ciphertext is written to ~/.msapling/credentials.enc and the
    original plaintext file is removed.  The random salt is persisted to
    ~/.msapling/.credentials_salt so the same key can be re-derived on unlock.

    OS-native keyring is preferred when available; Fernet encryption is used
    when keyring is unavailable or when an explicit master password is desired.
    """
    import os as _os
    import secrets

    # ── Try OS-native keyring first ──────────────────────────────────────
    try:
        import keyring as _kr  # noqa: F401
        # If keyring is available the token is already stored securely; nothing
        # more to do unless the user explicitly wants Fernet encryption.
        if not force:
            console.print(
                "[green]OS-native keyring is active — your credentials are already "
                "stored securely.[/green]\n"
                "[dim]Use --force to apply an additional Fernet layer on top.[/dim]"
            )
            return
    except ImportError:
        pass

    # ── Build the credential payload to encrypt ───────────────────────────
    cred_data: dict = {}
    if _CREDENTIALS_FILE.exists():
        try:
            import json as _json
            cred_data = _json.loads(_CREDENTIALS_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            console.print(f"[red]Failed to read credentials.json: {exc}[/red]")
            raise typer.Exit(1)
    else:
        # Also include the plaintext token file if it exists
        token_path = Path.home() / ".msapling" / "token"
        if token_path.exists():
            cred_data["token"] = token_path.read_text(encoding="utf-8").strip()

    if not cred_data:
        console.print("[yellow]No credentials found to encrypt.[/yellow]")
        return

    # ── Prompt for master password ────────────────────────────────────────
    import getpass as _getpass
    try:
        pw1 = _getpass.getpass("Master password: ")
        pw2 = _getpass.getpass("Confirm password: ")
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    if pw1 != pw2:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)
    if len(pw1) < 8:
        console.print("[red]Password must be at least 8 characters.[/red]")
        raise typer.Exit(1)

    # ── Derive Fernet key from password + fresh random salt ───────────────
    try:
        from cryptography.fernet import Fernet  # noqa: F401
    except ImportError:
        console.print(
            "[red]cryptography package not installed. "
            "Run: pip install cryptography[/red]"
        )
        raise typer.Exit(1)

    from cryptography.fernet import Fernet
    import json as _json

    salt = secrets.token_bytes(32)
    fernet_key = _derive_fernet_key(pw1, salt)
    fernet = Fernet(fernet_key)

    plaintext = _json.dumps(cred_data).encode("utf-8")
    ciphertext = fernet.encrypt(plaintext)

    # ── Persist salt + ciphertext ─────────────────────────────────────────
    _CREDENTIALS_SALT_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_SALT_FILE.write_bytes(salt)
    _CREDENTIALS_ENCRYPTED_FILE.write_bytes(ciphertext)

    # Remove plaintext files
    if _CREDENTIALS_FILE.exists():
        _CREDENTIALS_FILE.unlink()
    token_path = Path.home() / ".msapling" / "token"
    if token_path.exists():
        token_path.unlink()

    console.print("[green]Credentials encrypted successfully.[/green]")
    console.print(f"  Ciphertext: {_CREDENTIALS_ENCRYPTED_FILE}")
    console.print(f"  Salt:       {_CREDENTIALS_SALT_FILE}")
    console.print("[dim]Run 'msapling credentials unlock' to decrypt.[/dim]")


@credentials_app.command("unlock")
def credentials_unlock():
    """Decrypt ~/.msapling/credentials.enc and restore credentials.json.

    Reads the persisted salt from ~/.msapling/.credentials_salt and prompts
    for the master password to derive the Fernet key for decryption.
    """
    import json as _json

    if not _CREDENTIALS_ENCRYPTED_FILE.exists():
        console.print("[yellow]No encrypted credentials file found.[/yellow]")
        raise typer.Exit(1)
    if not _CREDENTIALS_SALT_FILE.exists():
        console.print("[red]Salt file missing. Cannot derive decryption key.[/red]")
        raise typer.Exit(1)

    try:
        from cryptography.fernet import Fernet, InvalidToken
    except ImportError:
        console.print(
            "[red]cryptography package not installed. "
            "Run: pip install cryptography[/red]"
        )
        raise typer.Exit(1)

    import getpass as _getpass
    try:
        pw = _getpass.getpass("Master password: ")
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    salt = _CREDENTIALS_SALT_FILE.read_bytes()
    fernet_key = _derive_fernet_key(pw, salt)
    fernet = Fernet(fernet_key)

    ciphertext = _CREDENTIALS_ENCRYPTED_FILE.read_bytes()
    try:
        plaintext = fernet.decrypt(ciphertext)
    except Exception:
        console.print("[red]Decryption failed — wrong password or corrupted file.[/red]")
        raise typer.Exit(1)

    cred_data = _json.loads(plaintext.decode("utf-8"))

    # Restore credentials
    _CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_FILE.write_text(_json.dumps(cred_data, indent=2), encoding="utf-8")

    # Also restore the auth token file if present
    if "token" in cred_data:
        token_path = Path.home() / ".msapling" / "token"
        token_path.write_text(cred_data["token"], encoding="utf-8")

    console.print("[green]Credentials decrypted and restored.[/green]")
    console.print(f"  Restored to: {_CREDENTIALS_FILE}")


@credentials_app.command("rotate")
def credentials_rotate():
    """Re-encrypt credentials with a new master password (key rotation).

    Decrypts with the current password and re-encrypts with a new password
    and a freshly generated salt.  Safe to run at any time; the old encrypted
    file is replaced atomically only after the new ciphertext is verified.
    """
    import json as _json
    import os as _os

    if not _CREDENTIALS_ENCRYPTED_FILE.exists():
        console.print("[yellow]No encrypted credentials file found. Run 'msapling credentials encrypt' first.[/yellow]")
        raise typer.Exit(1)
    if not _CREDENTIALS_SALT_FILE.exists():
        console.print("[red]Salt file missing. Cannot derive current decryption key.[/red]")
        raise typer.Exit(1)

    try:
        from cryptography.fernet import Fernet, InvalidToken
    except ImportError:
        console.print("[red]cryptography package not installed. Run: pip install cryptography[/red]")
        raise typer.Exit(1)

    import getpass as _getpass

    # Step 1: decrypt with current password
    try:
        current_pw = _getpass.getpass("Current master password: ")
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    current_salt = _CREDENTIALS_SALT_FILE.read_bytes()
    current_key = _derive_fernet_key(current_pw, current_salt)
    try:
        plaintext = Fernet(current_key).decrypt(_CREDENTIALS_ENCRYPTED_FILE.read_bytes())
    except Exception:
        console.print("[red]Decryption failed — wrong password or corrupted file.[/red]")
        raise typer.Exit(1)

    # Step 2: prompt for new password
    try:
        new_pw = _getpass.getpass("New master password: ")
        new_pw_confirm = _getpass.getpass("Confirm new password: ")
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    if new_pw != new_pw_confirm:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)
    if not new_pw:
        console.print("[red]Password cannot be empty.[/red]")
        raise typer.Exit(1)

    # Step 3: re-encrypt with new key + fresh salt
    new_salt = _os.urandom(32)
    new_key = _derive_fernet_key(new_pw, new_salt)
    new_ciphertext = Fernet(new_key).encrypt(plaintext)

    # Atomic write: write new files then swap (rename is atomic on all platforms)
    tmp_enc = _CREDENTIALS_ENCRYPTED_FILE.with_suffix(".enc.tmp")
    tmp_salt = _CREDENTIALS_SALT_FILE.with_suffix(".tmp")
    tmp_enc.write_bytes(new_ciphertext)
    tmp_salt.write_bytes(new_salt)
    tmp_enc.replace(_CREDENTIALS_ENCRYPTED_FILE)
    tmp_salt.replace(_CREDENTIALS_SALT_FILE)

    console.print("[green]Key rotation complete. Credentials re-encrypted with new password.[/green]")


@app.command()
def profile(
    name: Optional[str] = typer.Argument(
        None,
        help=(
            "Profile to activate: dev, research, review, security, auto, off. "
            "Omit to list available profiles and show the current session setting."
        ),
    ),
    detect: Optional[str] = typer.Option(
        None,
        "--detect",
        help="Dry-run: auto-detect profile for the given message text.",
    ),
):
    """Manage context profiles — dynamic system prompt injection for task-type awareness.

    Context profiles inject a focused system prompt prefix before every LLM call
    so the model behaves as the right expert for the current task.

    \\b
    Profiles:
      dev        Senior software engineer (code, tests, file paths)
      research   Research analyst (citations, summaries, sources)
      review     Code reviewer (SOLID, security, maintainability)
      security   Security analyst (OWASP, CVEs, threat modelling)
      auto       Auto-detect profile per message via keyword heuristics (default)
      off        Disable all profile injection

    \\b
    Examples:
      msapling profile                # list profiles + current setting
      msapling profile dev            # pin to 'dev' for this session
      msapling profile auto           # re-enable auto-detection
      msapling profile off            # disable profiles
      msapling profile --detect "fix the SQL injection bug"
    """
    from .context_profiles import BUILTIN_PROFILES, detect_profile as _detect_profile

    # Dry-run detection mode
    if detect is not None:
        detected = _detect_profile(detect)
        console.print(f"[cyan]Detected profile:[/cyan] [bold]{detected}[/bold]")
        console.print(f"[dim]Message: {detect[:120]}[/dim]")
        return

    _VALID_NAMES = set(BUILTIN_PROFILES.keys()) | {"auto", "off"}

    if name is None:
        # List mode
        console.print("[bold cyan]Context Profiles[/bold cyan]\n")
        rows = [
            ("dev",      "Senior software engineer — code, tests, file paths"),
            ("research", "Research analyst — citations, summaries, sources"),
            ("review",   "Code reviewer — SOLID, security, maintainability"),
            ("security", "Security analyst — OWASP, CVEs, threat modelling"),
            ("auto",     "Auto-detect per message (default)"),
            ("off",      "Disable profile injection"),
        ]
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Profile", style="cyan", width=12)
        table.add_column("Description")
        for pname, pdesc in rows:
            table.add_row(pname, pdesc)
        console.print(table)
        console.print()
        console.print(
            "[dim]Usage:[/dim] [cyan]msapling profile <name>[/cyan]  "
            "or in interactive shell: [cyan]/profile <name>[/cyan]"
        )
        return

    name_lower = name.strip().lower()
    if name_lower not in _VALID_NAMES:
        console.print(
            f"[red]Unknown profile '{name}'.[/red] "
            f"Valid options: {', '.join(sorted(_VALID_NAMES))}"
        )
        raise typer.Exit(1)

    # Persist the choice to settings so interactive shell sessions pick it up
    settings = get_settings()
    settings_dict = settings.model_dump() if hasattr(settings, "model_dump") else vars(settings)
    settings_dict["active_profile"] = name_lower
    try:
        save_settings(Settings(**settings_dict))
        console.print(f"[green]Active context profile set to:[/green] [bold]{name_lower}[/bold]")
    except Exception as exc:
        # Fallback: just print — settings persistence is optional
        console.print(f"[green]Active context profile:[/green] [bold]{name_lower}[/bold]")
        console.print(f"[dim](Settings save failed: {exc})[/dim]")


@app.command()
def doctor(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show extra detail on failures"),
    exhaustive: bool = typer.Option(False, "--exhaustive", "-e", help="Run full 16-check exhaustive health report"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
    strict: bool = typer.Option(False, "--strict", help="Exit non-zero if any check fails."),
):
    """Run exhaustive health checks and report CLI + API status.

    \\b
    Checks:
      Network       Ping the configured API base URL and report latency
      Auth          Verify credentials file exists and token is accepted
      Dependencies  Python version, requests, rich, click / typer versions
      Models        Call /api/models and report available count
      Version drift Compare local CLI version against server-reported version
      Config        Echo key config values (base_url, log_level, default_model)
    """
    import importlib.metadata as _im
    import sys as _sys
    import time as _time
    import platform as _platform

    settings = get_settings()
    base_url: str = settings.api_url
    token: Optional[str] = get_token()

    # ------------------------------------------------------------------
    # JSON output path (--json / --strict)
    # ------------------------------------------------------------------
    if json_output:
        import json as _json
        import shutil as _shutil

        token_source = get_token_source()
        sources = inspect_token_sources()
        non_null_sources = [v for v in sources.values() if v is not None]
        auth_conflict = len(non_null_sources) > 1

        async def _check_api():
            import httpx as _httpx
            headers = {"Authorization": f"Bearer {token}"} if token else {}
            cookies = {"msaplingauth": token} if token else {}
            try:
                async with _httpx.AsyncClient(timeout=5.0, headers=headers, cookies=cookies) as c:
                    r = await c.get(f"{base_url}/api/health")
                    reachable = r.status_code < 500
                    if not reachable or not token:
                        return reachable, None, "no_token" if not token else "unreachable"
                    r2 = await c.get(f"{base_url}/users/me")
                if r2.status_code == 200:
                    identity = r2.json().get("email")
                    return reachable, identity, None
                return reachable, None, f"{r2.status_code}"
            except Exception as exc:
                return False, None, str(exc)

        api_reachable, api_identity, api_error = _run(_check_api())

        warnings: list = []
        failures: list = []

        if auth_conflict:
            warnings.append("auth_conflict")
        if not token:
            warnings.append("no_token")
        if not _shutil.which("git"):
            warnings.append("git_not_found")
        if not _shutil.which("rg"):
            warnings.append("ripgrep_not_found")

        auth_check_ok = api_error is None and api_identity is not None
        if not auth_check_ok and token:
            failures.append("auth_check_failed")

        report = {
            "version": __version__,
            "auth": {
                "present": token is not None,
                "source": token_source,
                "conflict": auth_conflict,
            },
            "api": {
                "reachable": api_reachable,
                "auth_check_ok": auth_check_ok,
                "identity": api_identity,
            },
            "warnings": warnings,
            "failures": failures,
        }
        typer.echo(_json.dumps(report))
        if strict and (failures or not api_reachable):
            raise typer.Exit(1)
        return

    if exhaustive:
        from . import doctor as _doctor_mod
        results = _run(_doctor_mod.run_all_checks(settings.api_url, token))
        for name, status, detail in results:
            icon = "[green][OK][/green]" if status == "ok" else "[yellow][WARN][/yellow]" if status == "warn" else "[red][FAIL][/red]"
            console.print(f"{icon} [bold]{name}:[/bold] {detail}")
        return

    any_fail = False

    def _ok(label: str, msg: str) -> None:
        console.print(f"[green][OK][/green] [bold]{label}:[/bold] {msg}")

    def _warn(label: str, msg: str) -> None:
        console.print(f"[yellow][WARN][/yellow] [bold]{label}:[/bold] {msg}")

    def _fail(label: str, msg: str) -> None:
        nonlocal any_fail
        any_fail = True
        console.print(f"[red][FAIL][/red] [bold]{label}:[/bold] {msg}")

    # ------------------------------------------------------------------
    # 1. Network
    # ------------------------------------------------------------------
    try:
        import httpx as _httpx
        t0 = _time.monotonic()
        r = _httpx.get(f"{base_url}/api/health", timeout=5.0)
        latency_ms = int((_time.monotonic() - t0) * 1000)
        host = base_url.replace("https://", "").replace("http://", "").split("/")[0]
        if r.status_code < 500:
            _ok("Network", f"{host} responded in {latency_ms}ms (HTTP {r.status_code})")
        else:
            _warn("Network", f"{host} returned HTTP {r.status_code} in {latency_ms}ms")
    except Exception as exc:
        _fail("Network", f"Could not reach {base_url} - {exc}" if verbose else f"Could not reach {base_url}")

    # ------------------------------------------------------------------
    # 2. Auth
    # ------------------------------------------------------------------
    try:
        from pathlib import Path as _Path
        token_file = _Path.home() / ".msapling" / "token"
        if not token:
            _fail("Auth", "No credentials found - run `msapling login`")
        else:
            # Quick /api/users/me to validate token
            import httpx as _httpx
            r = _httpx.get(
                f"{base_url}/users/me",
                headers={"Authorization": f"Bearer {token}"},
                cookies={"msaplingauth": token},
                timeout=5.0,
            )
            if r.status_code == 200:
                email = r.json().get("email", "unknown")
                _ok("Auth", f"credentials valid ({email})")
            elif r.status_code in (401, 403):
                _fail("Auth", "token rejected - run `msapling login`")
            else:
                _warn("Auth", f"unexpected response HTTP {r.status_code}")
    except Exception as exc:
        _fail("Auth", str(exc) if verbose else "check failed")

    # ------------------------------------------------------------------
    # 3. Dependencies
    # ------------------------------------------------------------------
    try:
        py_ver = _platform.python_version()
        click_ver = _im.version("click")
        rich_ver = _im.version("rich")
        typer_ver = _im.version("typer")
        _ok(
            "Dependencies",
            f"Python {py_ver}, click {click_ver}, rich {rich_ver}, typer {typer_ver}",
        )
    except Exception as exc:
        _warn("Dependencies", str(exc))

    # ------------------------------------------------------------------
    # 4. Model availability
    # ------------------------------------------------------------------
    try:
        import httpx as _httpx
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        r = _httpx.get(f"{base_url}/api/models", headers=headers, timeout=8.0)
        if r.status_code == 200:
            data = r.json()
            count = len(data) if isinstance(data, list) else len(data.get("models", data.get("data", [])))
            _ok("Models", f"{count} available")
        else:
            _warn("Models", f"HTTP {r.status_code}")
    except Exception as exc:
        _fail("Models", str(exc) if verbose else "could not fetch model list")

    # ------------------------------------------------------------------
    # 5. Version drift
    # ------------------------------------------------------------------
    try:
        import httpx as _httpx
        r = _httpx.get(f"{base_url}/api/version", timeout=4.0)
        if r.status_code == 200:
            server_ver = r.json().get("cli_version") or r.json().get("version")
            if server_ver and server_ver != __version__:
                _warn(
                    "Version drift",
                    f"CLI v{__version__}, server expects v{server_ver} (non-blocking)",
                )
            elif server_ver:
                _ok("Version drift", f"CLI v{__version__} matches server")
            else:
                _ok("Version drift", f"CLI v{__version__} (server version not reported)")
        else:
            _ok("Version drift", f"CLI v{__version__} (server endpoint unavailable)")
    except Exception:
        _ok("Version drift", f"CLI v{__version__} (server endpoint unavailable)")

    # ------------------------------------------------------------------
    # 6. Config
    # ------------------------------------------------------------------
    log_level = os.environ.get("LOG_LEVEL", os.environ.get("MSAPLING_LOG_LEVEL", "INFO"))
    default_model = getattr(settings, "default_model", "?")
    _ok(
        "Config",
        f"base_url={base_url}, log_level={log_level}, default_model={default_model}",
    )

    # ------------------------------------------------------------------
    # Exit
    # ------------------------------------------------------------------
    if any_fail:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Pipeline sub-app
# ---------------------------------------------------------------------------
pipeline_app = typer.Typer(help="Named multi-step AI pipelines.")
app.add_typer(pipeline_app, name="pipeline")


@pipeline_app.command("create")
def pipeline_create():
    """Interactively create a new named pipeline."""
    from .pipeline import create_pipeline_wizard
    create_pipeline_wizard()


@pipeline_app.command("list")
def pipeline_list():
    """List all saved pipelines."""
    from .pipeline import list_pipelines
    pipelines = list_pipelines()
    if not pipelines:
        console.print("[dim]No pipelines saved. Run: msapling pipeline create[/dim]")
        return
    table = Table(title="Saved Pipelines")
    table.add_column("Name", style="cyan")
    table.add_column("Mode", style="yellow")
    table.add_column("Steps", justify="right")
    table.add_column("Description")
    for p in pipelines:
        table.add_row(
            p.get("name", ""),
            p.get("mode", ""),
            str(len(p.get("steps", []))),
            p.get("description", ""),
        )
    console.print(table)


@pipeline_app.command("run")
def pipeline_run(
    name: str = typer.Argument(..., help="Pipeline name"),
    prompt: str = typer.Argument(..., help="Input prompt"),
):
    """Run a named pipeline against a prompt."""
    from .pipeline import load_pipeline, run_pipeline
    p = load_pipeline(name)
    if not p:
        console.print(f"[red]Pipeline '{name}' not found. Run: msapling pipeline list[/red]")
        raise typer.Exit(1)

    async def _run():
        async with MSaplingClient() as client:
            result = await run_pipeline(p, prompt, client)
            final = next(
                (r for r in reversed(result.get("results", [])) if r.get("output")),
                None,
            )
            if final:
                console.print(
                    Panel(str(final["output"])[:3000], title=f"Pipeline: {name}", border_style="cyan")
                )

    asyncio.run(_run())


@pipeline_app.command("delete")
def pipeline_delete(
    name: str = typer.Argument(..., help="Pipeline name to delete"),
):
    """Delete a saved pipeline."""
    from .pipeline import delete_pipeline
    from rich.prompt import Confirm
    if Confirm.ask(f"Delete pipeline '{name}'?", default=False):
        if delete_pipeline(name):
            console.print(f"[green]Deleted '{name}'.[/green]")
        else:
            console.print(f"[yellow]Pipeline '{name}' not found.[/yellow]")


# ---------------------------------------------------------------------------
# parallel — fire N parallel chats with the same prompt
# ---------------------------------------------------------------------------
@app.command()
def parallel(
    prompt: str = typer.Argument(..., help="Prompt to send"),
    n: int = typer.Option(3, "--n", "-n", help="Number of parallel chats", min=2, max=8),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    project: str = typer.Option("CLI Utility", "--project", help="Project to charge/track budget against"),
    max_attempts: int = typer.Option(4, "--max-attempts", help="Max attempts per run", min=1, max=8),
    backoff_s: float = typer.Option(0.35, "--backoff-s", help="Initial retry backoff seconds", min=0.0, max=5.0),
    stagger_s: float = typer.Option(0.12, "--stagger-s", help="Initial per-run stagger seconds", min=0.0, max=2.0),
    strict: bool = typer.Option(False, "--strict", help="Exit nonzero if any run fails"),
):
    """Fire N parallel chats with the same prompt and compare results."""
    async def _run():
        async with MSaplingClient() as client:
            token = get_token()
            if not token:
                console.print("[red]Not logged in.[/red]")
                raise typer.Exit(1)
            from .pipeline import run_parallel_chats
            settings = get_settings()
            _model = model or getattr(settings, "model", None) or "google/gemini-2.0-flash-001"
            with suppress(Exception):
                user = await client.me()
                fuel = float((user or {}).get("fuel_credits", 0.0) or 0.0)
                tier = str((user or {}).get("tier", "free"))
                console.print(
                    f"[dim]Budget check: tier={tier}, fuel=${fuel:.4f}, project={project}[/dim]"
                )
            results = await run_parallel_chats(
                prompt,
                n,
                _model,
                client,
                project_name=project,
                max_attempts=max_attempts,
                backoff_s=backoff_s,
                stagger_s=stagger_s,
            )

            normalized = []
            for idx, raw in enumerate(results, start=1):
                if isinstance(raw, dict):
                    item = dict(raw)
                else:
                    item = {"idx": idx, "content": None, "error": str(raw)}
                item.setdefault("idx", idx)
                item.setdefault("content", None)
                item.setdefault("error", None)
                item.setdefault("attempts", 1)
                item.setdefault("retried", False)
                normalized.append(item)

            success_count = 0
            failure_count = 0
            retried_count = 0

            for r in normalized:
                failed = bool(r.get("error"))
                if failed:
                    failure_count += 1
                else:
                    success_count += 1

                if bool(r.get("retried")):
                    retried_count += 1

                attempts = int(r.get("attempts") or 1)
                title = f"Run {r.get('idx', '?')}" + (" [red](failed)[/red]" if failed else "")
                if attempts > 1:
                    title += f" [dim](attempts: {attempts})[/dim]"
                content = r.get("content") or r.get("error") or "No response returned"
                console.print(
                    Panel(
                        str(content)[:2000],
                        title=title,
                        border_style="red" if failed else "green",
                    )
                )

            console.print(
                f"[bold]Parallel summary:[/bold] "
                f"[green]{success_count} succeeded[/green], "
                f"[red]{failure_count} failed[/red], "
                f"[cyan]{retried_count} retried[/cyan]"
            )

            if failure_count > 0 and success_count > 0 and not strict:
                console.print("[yellow]Partial success: returning best available outputs.[/yellow]")
            if strict and failure_count > 0:
                console.print("[red]Strict mode: failing because one or more runs failed.[/red]")
                raise typer.Exit(1)
            if success_count == 0:
                raise typer.Exit(1)

    asyncio.run(_run())


if __name__ == "__main__":
    app()
