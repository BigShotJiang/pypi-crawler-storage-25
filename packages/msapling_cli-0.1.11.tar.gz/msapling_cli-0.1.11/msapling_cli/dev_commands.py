"""CLI commands for the MSapling Developer Portal."""
from __future__ import annotations

import asyncio
from typing import Optional

import typer
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .api import APIError, MSaplingClient, OfflineError
from .config import get_token
from .tui import console

dev_app = typer.Typer(
    name="dev",
    help="Developer portal — API keys, usage stats, and rate limits.",
)


def _run(coro):
    return asyncio.run(coro)


def _require_auth() -> str:
    token = get_token()
    if not token:
        console.print("[red]Not logged in. Run `msapling login` first.[/red]")
        raise typer.Exit(1)
    return token


@dev_app.command("dashboard")
def dev_dashboard(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
):
    """Show the developer portal dashboard: account, API keys, and 30-day usage."""
    token = _require_auth()

    async def _fetch():
        async with MSaplingClient(token=token) as client:
            return await client.get_developer_dashboard()

    try:
        data = _run(_fetch())
    except (APIError, OfflineError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if json_out:
        import json
        console.print_json(json.dumps(data, default=str))
        return

    account = data.get("account", {})
    usage = data.get("usage_30d", {})
    keys = data.get("api_keys", [])
    rate = data.get("rate_limits", {})

    # --- Account panel ---
    tier = str(account.get("tier", "free"))
    is_pro = bool(account.get("is_pro", False))
    tier_style = "bold green" if is_pro else "bold yellow"
    credits = float(account.get("fuel_credits", 0) or 0)

    console.print(Panel(
        f"[bold]{account.get('email', '?')}[/bold]\n"
        f"Tier: [{tier_style}]{tier}[/{tier_style}]  |  "
        f"Fuel Credits: [cyan]{credits:.4f}[/cyan]",
        title="Account",
        border_style="blue",
        expand=False,
    ))

    # --- Usage table ---
    usage_table = Table(title="30-Day Usage", show_header=True, header_style="bold magenta", expand=False)
    usage_table.add_column("Metric")
    usage_table.add_column("Value", justify="right")
    usage_table.add_row("Total Requests", str(usage.get("total_requests", 0)))
    usage_table.add_row("Total Tokens", f"{usage.get('total_tokens', 0):,}")
    usage_table.add_row("Total Cost (USD)", f"${float(usage.get('total_cost_usd', 0) or 0):.6f}")
    console.print(usage_table)

    # --- API keys table ---
    if keys:
        keys_table = Table(title="Personal API Keys", show_header=True, header_style="bold magenta", expand=False)
        keys_table.add_column("Name")
        keys_table.add_column("Prefix")
        keys_table.add_column("Active")
        keys_table.add_column("Created")
        keys_table.add_column("Last Used")
        for k in keys:
            active_text = Text("yes", style="green") if k.get("is_active") else Text("no", style="red")
            created = str(k.get("created_at", "—") or "—")[:10]
            last_used = str(k.get("last_used_at", "—") or "—")[:10]
            keys_table.add_row(
                str(k.get("name", "—")),
                str(k.get("key_prefix", "—")),
                active_text,
                created,
                last_used,
            )
        console.print(keys_table)
    else:
        console.print("[dim]No personal API keys.[/dim]")

    # --- Rate limits ---
    console.print(
        f"\n[dim]Rate limits: {rate.get('requests_per_minute', '?')} req/min  |  "
        f"Max keys: {rate.get('max_api_keys', '?')}[/dim]"
    )
