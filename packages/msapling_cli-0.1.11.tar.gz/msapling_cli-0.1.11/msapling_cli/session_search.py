"""BM25 full-text search index over MSapling CLI session files.

Usage:
    from msapling_cli.session_search import BM25Index

    index = BM25Index.index_sessions(session_files)
    results = index.search("my query", top_k=10)
    for r in results:
        print(r.session_id, r.title, r.score, r.matched_snippet)

The index is cached to ``~/.msapling/search_index.json`` and rebuilt
automatically whenever any session file is newer than the cache.
"""
from __future__ import annotations

import json
import logging
import math
import re
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

_log = logging.getLogger(__name__)

_SESSION_DIR = Path.home() / ".msapling" / "sessions"
_CACHE_FILE = Path.home() / ".msapling" / "search_index.json"

# ---------------------------------------------------------------------------
# Token helpers
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[a-z0-9']+")


def _tokenize(text: str) -> List[str]:
    """Lowercase and split on whitespace + punctuation boundaries."""
    return _TOKEN_RE.findall(text.lower())


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class SearchResult:
    """One ranked result from a BM25 search."""
    session_id: str
    title: str
    project: str
    score: float
    matched_snippet: str  # 50-char context window around first term match


@dataclass
class _DocEntry:
    """Indexed document entry (stored in the cache file)."""
    session_id: str
    title: str
    project: str
    file_path: str
    mtime: float
    text: str               # full concatenated text used for indexing
    term_freqs: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "_DocEntry":
        return cls(**d)


# ---------------------------------------------------------------------------
# BM25 Index
# ---------------------------------------------------------------------------

class BM25Index:
    """Pure-Python BM25 index over session files.

    Parameters
    ----------
    k1:
        Term-frequency saturation parameter (default 1.5).
    b:
        Length normalisation parameter (default 0.75).
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self._docs: List[_DocEntry] = []
        self._df: Dict[str, int] = {}   # document frequency per term
        self._avg_dl: float = 0.0
        self._built_at: float = 0.0

    # ------------------------------------------------------------------
    # Class-level factory
    # ------------------------------------------------------------------

    @classmethod
    def index_sessions(cls, session_files: List[Path]) -> "BM25Index":
        """Build (or restore from cache) a BM25 index for *session_files*.

        The cache at ``~/.msapling/search_index.json`` is used when ALL of:
        - it exists and is valid JSON,
        - its ``built_at`` timestamp is newer than every file in
          *session_files*.

        If any file is newer than the cache, the index is rebuilt from
        scratch and the cache is updated atomically.
        """
        idx = cls()

        # Try loading from cache first.
        if _CACHE_FILE.exists():
            try:
                cache_mtime = _CACHE_FILE.stat().st_mtime
                all_older = all(
                    p.stat().st_mtime <= cache_mtime for p in session_files if p.exists()
                )
                if all_older:
                    raw = json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
                    idx._load_cache(raw)
                    return idx
            except Exception as exc:
                _log.debug("search_index cache miss (%s) — rebuilding", exc)

        # Build from scratch.
        idx._build(session_files)
        idx._save_cache()
        return idx

    # ------------------------------------------------------------------
    # Public search
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 10) -> List[SearchResult]:
        """Return up to *top_k* :class:`SearchResult` objects ranked by BM25.

        Returns an empty list when the index is empty or no document matches.
        """
        if not self._docs or not query.strip():
            return []

        terms = _tokenize(query)
        if not terms:
            return []

        n = len(self._docs)
        results: List[Tuple[float, _DocEntry]] = []

        for doc in self._docs:
            score = self._score(terms, doc, n)
            if score > 0.0:
                results.append((score, doc))

        results.sort(key=lambda x: x[0], reverse=True)

        out: List[SearchResult] = []
        for score, doc in results[:top_k]:
            snippet = self._snippet(query, doc.text)
            out.append(SearchResult(
                session_id=doc.session_id,
                title=doc.title,
                project=doc.project,
                score=round(score, 4),
                matched_snippet=snippet,
            ))
        return out

    # ------------------------------------------------------------------
    # Scoring
    # ------------------------------------------------------------------

    def _score(self, terms: List[str], doc: _DocEntry, n: int) -> float:
        k1, b = self.k1, self.b
        dl = sum(doc.term_freqs.values())
        avg_dl = self._avg_dl or 1.0
        score = 0.0
        for term in terms:
            tf = doc.term_freqs.get(term, 0)
            if tf == 0:
                continue
            df = self._df.get(term, 0)
            # Standard BM25 IDF (Okapi variant, +0.5 smoothing, clamped ≥ 0).
            idf = max(0.0, math.log((n - df + 0.5) / (df + 0.5) + 1.0))
            tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / avg_dl))
            score += idf * tf_norm
        return score

    # ------------------------------------------------------------------
    # Snippet extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _snippet(query: str, text: str, window: int = 50) -> str:
        """Return a *window*-char context window around the first query term match."""
        terms = _tokenize(query)
        lower = text.lower()
        for term in terms:
            idx = lower.find(term)
            if idx != -1:
                start = max(0, idx - window // 2)
                end = min(len(text), idx + len(term) + window // 2)
                snippet = text[start:end].replace("\n", " ").strip()
                if start > 0:
                    snippet = "…" + snippet
                if end < len(text):
                    snippet = snippet + "…"
                return snippet
        return text[:window].replace("\n", " ").strip()

    # ------------------------------------------------------------------
    # Build / persist
    # ------------------------------------------------------------------

    def _build(self, session_files: List[Path]) -> None:
        self._docs = []
        self._df = {}

        for path in session_files:
            if not path.exists():
                continue
            try:
                doc = _parse_session_file(path)
                if doc is None:
                    continue
                self._docs.append(doc)
                for term in set(doc.term_freqs.keys()):
                    self._df[term] = self._df.get(term, 0) + 1
            except Exception as exc:
                _log.debug("Failed to index %s: %s", path, exc)

        total_tokens = sum(sum(d.term_freqs.values()) for d in self._docs)
        self._avg_dl = total_tokens / len(self._docs) if self._docs else 0.0
        self._built_at = time.time()

    def _save_cache(self) -> None:
        try:
            _CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "built_at": self._built_at,
                "avg_dl": self._avg_dl,
                "df": self._df,
                "docs": [d.to_dict() for d in self._docs],
            }
            _CACHE_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as exc:
            _log.debug("Failed to save search_index cache: %s", exc)

    def _load_cache(self, raw: dict) -> None:
        self._built_at = raw.get("built_at", 0.0)
        self._avg_dl = raw.get("avg_dl", 0.0)
        self._df = raw.get("df", {})
        self._docs = [_DocEntry.from_dict(d) for d in raw.get("docs", [])]


# ---------------------------------------------------------------------------
# Session file parser
# ---------------------------------------------------------------------------

def _parse_session_file(path: Path) -> Optional[_DocEntry]:
    """Parse a session JSON file into a :class:`_DocEntry` for indexing."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return None

    session_id = raw.get("id") or path.stem
    metadata = raw.get("metadata") or {}

    # Title: prefer summary, fall back to last user message snippet, then filename.
    title: str = (
        metadata.get("summary")
        or _last_user_message(raw.get("messages", []))
        or path.stem
    )

    project: str = metadata.get("project_name") or raw.get("project_root") or ""
    models: List[str] = metadata.get("models_used") or []
    if raw.get("model") and raw["model"] not in models:
        models.append(raw["model"])

    # Build searchable text corpus.
    parts: List[str] = [title, project] + models
    for msg in raw.get("messages", []):
        content = msg.get("content") or ""
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            # Structured content blocks (e.g. Claude tool-use messages).
            for block in content:
                if isinstance(block, dict):
                    parts.append(block.get("text") or "")

    text = " ".join(p for p in parts if p)

    term_freqs: Dict[str, int] = {}
    for token in _tokenize(text):
        term_freqs[token] = term_freqs.get(token, 0) + 1

    return _DocEntry(
        session_id=session_id,
        title=title,
        project=project,
        file_path=str(path),
        mtime=path.stat().st_mtime,
        text=text,
        term_freqs=term_freqs,
    )


def _last_user_message(messages: list) -> str:
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content") or ""
            if isinstance(content, str):
                return content[:120].strip()
    return ""


# ---------------------------------------------------------------------------
# Convenience function: build from default sessions dir
# ---------------------------------------------------------------------------

def build_default_index(limit: int = 500) -> BM25Index:
    """Build (or restore) index for all session JSON files in *_SESSION_DIR*."""
    if not _SESSION_DIR.exists():
        return BM25Index()
    files = sorted(
        _SESSION_DIR.glob("*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )[:limit]
    return BM25Index.index_sessions(files)
