"""Export commands for MSapling CLI.

Provides `msapling export` sub-commands for exporting session data to
external tools (e.g. Claude Code memory files).
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from .tui import console

export_app = typer.Typer(help="Export MSapling sessions to external tools.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_converter():
    """Lazily import the msapling_to_claude converter script."""
    # Try to import from the scripts/ directory at the project root
    import importlib.util
    import os

    # Look for the script relative to this package install location
    # or relative to a well-known project root
    candidate_dirs = [
        Path(__file__).parent.parent.parent / "scripts",  # dev: cli/../scripts
        Path(__file__).parent.parent / "scripts",
        Path.cwd() / "scripts",
        Path(os.environ.get("MSAPLING_ROOT", ".")) / "scripts",
    ]
    for d in candidate_dirs:
        script = d / "msapling_to_claude.py"
        if script.exists():
            spec = importlib.util.spec_from_file_location("msapling_to_claude", script)
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)  # type: ignore[union-attr]
                return mod

    # Fallback: try normal import (installed as package)
    try:
        import msapling_to_claude  # type: ignore[import]
        return msapling_to_claude
    except ImportError:
        return None


# ---------------------------------------------------------------------------
# `msapling export claude` command
# ---------------------------------------------------------------------------

@export_app.command("claude")
def export_claude(
    recent: Optional[int] = typer.Option(
        None,
        "--recent",
        metavar="N",
        help="Export N most recent sessions.",
    ),
    all_sessions: bool = typer.Option(
        False,
        "--all",
        help="Export ALL sessions.",
    ),
    list_only: bool = typer.Option(
        False,
        "--list",
        help="List sessions that would be exported without converting.",
    ),
    output_dir: Optional[str] = typer.Option(
        None,
        "--output-dir",
        metavar="DIR",
        help="Directory to write memory files (default: ~/.claude/memory/).",
    ),
    fmt: str = typer.Option(
        "memory",
        "--format",
        metavar="FORMAT",
        help="Output format: 'memory' or 'claude-md'.",
    ),
    project: Optional[str] = typer.Option(
        None,
        "--project",
        metavar="NAME",
        help="Filter sessions by project name (substring match).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview what would be written without writing files.",
    ),
):
    """Export MSapling sessions as Claude Code memory files.

    Examples:

        msapling export claude --recent 5

        msapling export claude --all

        msapling export claude --list

        msapling export claude --recent 3 --dry-run

        msapling export claude --recent 5 --output-dir ~/my-memory/
    """
    converter = _get_converter()
    if converter is None:
        console.print(
            "[red]ERROR: Could not find scripts/msapling_to_claude.py. "
            "Ensure MSAPLING_ROOT is set or run from the project root.[/red]"
        )
        raise typer.Exit(code=1)

    # Build argv list for converter's main()
    argv: list[str] = []

    if list_only:
        argv.append("--list")
    elif all_sessions:
        argv.append("--all")
    elif recent is not None:
        argv += ["--all-recent", str(recent)]
    else:
        # Default: list mode so user sees what's available
        console.print(
            "[yellow]No selection provided. Use --recent N, --all, or --list.[/yellow]"
        )
        console.print("  msapling export claude --recent 5   # export 5 most recent sessions")
        console.print("  msapling export claude --list        # list available sessions")
        console.print("  msapling export claude --all         # export all sessions")
        raise typer.Exit(code=0)

    if output_dir:
        argv += ["--output-dir", output_dir]
    if fmt and fmt != "memory":
        argv += ["--format", fmt]
    if project:
        argv += ["--project", project]
    if dry_run:
        argv.append("--dry-run")

    result = converter.main(argv)
    if result and result != 0:
        raise typer.Exit(code=result)


# ---------------------------------------------------------------------------
# `msapling export session` command
# ---------------------------------------------------------------------------

@export_app.command("session")
def export_session(
    session_id: str = typer.Argument(..., help="Session ID to export (or 'latest')."),
    fmt: str = typer.Option(
        "html",
        "--format",
        "-f",
        metavar="FORMAT",
        help="Output format: html, md, pdf.",
    ),
    output: Optional[str] = typer.Option(
        None,
        "--output",
        "-o",
        metavar="FILE",
        help="Output file path. Defaults to msapling-export-<id>.<format> in current dir.",
    ),
):
    """Export a saved MSapling session as HTML, Markdown, or PDF.

    Examples:

        msapling export session abc123 --format html

        msapling export session latest --format pdf --output report.pdf

        msapling export session abc123 --format md --output notes.md
    """
    from .session import load_session, list_sessions

    fmt = fmt.lower().lstrip(".")
    if fmt not in ("html", "md", "pdf"):
        console.print(f"[red]Unknown format '{fmt}'. Use: html, md, pdf[/red]")
        raise typer.Exit(code=1)

    # Resolve "latest"
    if session_id.lower() == "latest":
        sessions = list_sessions(limit=1)
        if not sessions:
            console.print("[red]No saved sessions found.[/red]")
            raise typer.Exit(code=1)
        session_id = sessions[0].get("id") or sessions[0].get("session_id") or ""
        if not session_id:
            console.print("[red]Could not determine latest session ID.[/red]")
            raise typer.Exit(code=1)
        console.print(f"[dim]Using latest session: {session_id}[/dim]")

    session = load_session(session_id)
    if session is None:
        console.print(f"[red]Session '{session_id}' not found. Run: msapling sessions[/red]")
        raise typer.Exit(code=1)

    out_file = output or f"msapling-export-{session_id}.{fmt}"
    out_path = Path(out_file)

    try:
        from .export_formats import export_markdown, export_html, export_pdf
        if fmt == "html":
            result_path = export_html(session, out_path)
        elif fmt == "pdf":
            result_path = export_pdf(session, out_path)
        else:
            result_path = export_markdown(session, out_path)

        file_size = result_path.stat().st_size
        console.print(f"[green]Exported:[/green] {result_path}")
        console.print(f"[dim]Format: {fmt.upper()}  |  Size: {file_size:,} bytes[/dim]")
    except Exception as e:
        console.print(f"[red]Export failed: {e}[/red]")
        raise typer.Exit(code=1)
