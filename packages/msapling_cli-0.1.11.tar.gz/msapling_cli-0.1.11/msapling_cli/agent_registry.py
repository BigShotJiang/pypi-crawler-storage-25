"""Persistent agent registry for multi/swarm control-plane parity.

Stores per-agent definitions under ``~/.msapling/agents.json`` and exposes
helpers for list/reload/enable/disable/config flows used by both headless CLI
commands and interactive shell slash commands.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional


REGISTRY_FILE = Path.home() / ".msapling" / "agents.json"
REGISTRY_SCHEMA_VERSION = 1


@dataclass
class AgentDefinition:
    id: str
    name: str
    model: str
    enabled: bool = True
    max_parallel: int = 1
    description: str = ""
    tags: List[str] = field(default_factory=list)
    updated_at: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "AgentDefinition":
        now = time.time()
        return cls(
            id=str(raw.get("id") or "").strip(),
            name=str(raw.get("name") or raw.get("id") or "").strip(),
            model=str(raw.get("model") or "").strip(),
            enabled=bool(raw.get("enabled", True)),
            max_parallel=max(1, min(8, int(raw.get("max_parallel") or 1))),
            description=str(raw.get("description") or "").strip(),
            tags=[str(t).strip() for t in (raw.get("tags") or []) if str(t).strip()],
            updated_at=float(raw.get("updated_at") or now),
        )


def _default_agents() -> List[AgentDefinition]:
    now = time.time()
    return [
        AgentDefinition(
            id="gemini-fast",
            name="Gemini Fast",
            model="google/gemini-2.0-flash-001",
            enabled=True,
            max_parallel=2,
            description="Fast broad reasoning and low-cost fanout leg.",
            tags=["default", "fast"],
            updated_at=now,
        ),
        AgentDefinition(
            id="claude-analyst",
            name="Claude Analyst",
            model="anthropic/claude-3-haiku",
            enabled=True,
            max_parallel=2,
            description="Analytical second opinion for compare/swarm runs.",
            tags=["default", "analysis"],
            updated_at=now,
        ),
        AgentDefinition(
            id="gpt-synth",
            name="GPT Synth",
            model="openai/gpt-4o-mini",
            enabled=True,
            max_parallel=2,
            description="Reliable synthesis/judge lane for final responses.",
            tags=["default", "judge"],
            updated_at=now,
        ),
    ]


def _normalize_ref(value: str) -> str:
    return str(value or "").strip().lower()


def _ensure_parent() -> None:
    try:
        REGISTRY_FILE.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        # Read-only or restricted home directories should not break CLI usage.
        pass


def _load_raw() -> Dict[str, Any]:
    _ensure_parent()
    defaults = {
        "schema_version": REGISTRY_SCHEMA_VERSION,
        "agents": [a.to_dict() for a in _default_agents()],
    }
    if not REGISTRY_FILE.exists():
        try:
            REGISTRY_FILE.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        except Exception:
            pass
        return defaults
    try:
        data = json.loads(REGISTRY_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return defaults


def load_agent_registry() -> List[AgentDefinition]:
    raw = _load_raw()
    out: List[AgentDefinition] = []
    for item in raw.get("agents", []):
        if not isinstance(item, dict):
            continue
        agent = AgentDefinition.from_dict(item)
        if agent.id and agent.name and agent.model:
            out.append(agent)
    if not out:
        out = _default_agents()
        save_agent_registry(out)
    return out


def save_agent_registry(agents: List[AgentDefinition]) -> None:
    _ensure_parent()
    payload = {
        "schema_version": REGISTRY_SCHEMA_VERSION,
        "agents": [a.to_dict() for a in agents],
    }
    try:
        REGISTRY_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception:
        pass


def list_agents(*, enabled_only: bool = False) -> List[AgentDefinition]:
    agents = load_agent_registry()
    if enabled_only:
        return [a for a in agents if a.enabled]
    return agents


def resolve_agent(agents: List[AgentDefinition], ref: str) -> Optional[AgentDefinition]:
    key = _normalize_ref(ref)
    if not key:
        return None
    try:
        idx = int(key) - 1
        if 0 <= idx < len(agents):
            return agents[idx]
    except ValueError:
        pass
    for agent in agents:
        if _normalize_ref(agent.id) == key or _normalize_ref(agent.name) == key:
            return agent
    return None


def set_agent_enabled(ref: str, enabled: bool) -> AgentDefinition:
    agents = load_agent_registry()
    agent = resolve_agent(agents, ref)
    if agent is None:
        raise KeyError(f"Agent not found: {ref}")
    agent.enabled = bool(enabled)
    agent.updated_at = time.time()
    save_agent_registry(agents)
    return agent


def configure_agent(
    ref: str,
    *,
    model: Optional[str] = None,
    name: Optional[str] = None,
    description: Optional[str] = None,
    max_parallel: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> AgentDefinition:
    agents = load_agent_registry()
    agent = resolve_agent(agents, ref)
    if agent is None:
        raise KeyError(f"Agent not found: {ref}")

    if model is not None:
        agent.model = str(model).strip() or agent.model
    if name is not None:
        clean_name = str(name).strip()
        if clean_name:
            agent.name = clean_name
    if description is not None:
        agent.description = str(description).strip()
    if max_parallel is not None:
        agent.max_parallel = max(1, min(8, int(max_parallel)))
    if tags is not None:
        agent.tags = [str(t).strip() for t in tags if str(t).strip()]
    agent.updated_at = time.time()
    save_agent_registry(agents)
    return agent


def reload_agent_registry(*, reset: bool = False) -> List[AgentDefinition]:
    if reset:
        defaults = _default_agents()
        save_agent_registry(defaults)
        return defaults

    current = load_agent_registry()
    current_by_id = {a.id: a for a in current}
    merged: List[AgentDefinition] = []
    for default in _default_agents():
        existing = current_by_id.pop(default.id, None)
        merged.append(existing if existing is not None else default)
    # Preserve custom agents not present in defaults.
    merged.extend(current_by_id.values())
    save_agent_registry(merged)
    return merged


def default_models_from_registry(limit: int = 3) -> List[str]:
    models: List[str] = []
    for agent in list_agents(enabled_only=True):
        mid = str(agent.model).strip()
        if mid and mid not in models:
            models.append(mid)
        if len(models) >= max(1, int(limit)):
            break
    if models:
        return models
    return [a.model for a in _default_agents()[: max(1, int(limit))]]
