"""quality_gate.py — CLI-side stop quality gate.

Invoked at session end to run ruff (format + lint) against modified Python
files and tsc --noEmit against modified TypeScript files.

Designed to be fast, non-blocking, and safe to call even when ruff/tsc are
not installed — missing tools emit a warning rather than crashing.

Usage (programmatic):
    from msapling_cli.quality_gate import run_session_quality_gate
    result = run_session_quality_gate(session.files_touched)
    if result.dirty:
        console.print("[bold red]Session marked DIRTY[/bold red]")

Usage (standalone CLI smoke-check):
    python -m msapling_cli.quality_gate path/to/file.py path/to/comp.tsx
"""
from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class QualityGateResult:
    """Result of a session-end quality gate run.

    Attributes:
        passed:        True when all applicable checks succeed.
        dirty:         True when any check failed (always ``not passed``).
        failures:      Human-readable failure messages (one per check issue).
        warnings:      Non-fatal messages, e.g. "ruff not found — skipped".
        duration_ms:   Wall-clock milliseconds for the full gate run.
        files_checked: Number of .py / .ts / .tsx files actually inspected.
    """

    passed: bool = True
    dirty: bool = False
    failures: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    duration_ms: int = 0
    files_checked: int = 0

    def __post_init__(self) -> None:
        # Keep passed / dirty in sync regardless of how the object was built.
        self.dirty = not self.passed


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_PROJECT_ROOT: Optional[Path] = None


def _project_root() -> Path:
    """Return the project root (two levels above this file's package)."""
    global _PROJECT_ROOT
    if _PROJECT_ROOT is None:
        # cli/msapling_cli/quality_gate.py  ->  cli/  ->  <project_root>
        _PROJECT_ROOT = Path(__file__).resolve().parents[2]
    return _PROJECT_ROOT


def _run(cmd: List[str], cwd: Optional[Path] = None) -> tuple[int, str]:
    """Run *cmd*, return (exit_code, combined_stdout+stderr).

    Returns (-1, message) when the executable is not found so callers can
    distinguish "tool missing" from "tool ran and failed".
    """
    try:
        result = subprocess.run(
            cmd,
            cwd=str(cwd or _project_root()),
            capture_output=True,
            text=True,
            timeout=120,
        )
        output = (result.stdout + result.stderr).strip()
        return result.returncode, output
    except FileNotFoundError:
        return -1, f"[SKIP] Command not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 1, f"[TIMEOUT] {' '.join(cmd)}"
    except Exception as exc:  # noqa: BLE001
        return 1, f"[ERROR] {exc}"


def _tool_available(name: str) -> bool:
    """Return True if *name* resolves to an executable on PATH."""
    code, _ = _run([name, "--version"])
    return code == 0


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------


def _check_ruff_format(py_files: List[Path]) -> tuple[bool, List[str], List[str]]:
    """Run ``ruff format --check`` over *py_files*.

    Returns (ok, failures, warnings).
    """
    if not py_files:
        return True, [], []

    if not _tool_available("ruff"):
        return True, [], ["[SKIP] ruff not found — format check skipped"]

    code, out = _run(["ruff", "format", "--check"] + [str(f) for f in py_files])
    if code != 0:
        lines = [f"FORMAT: {ln}" for ln in out.splitlines() if ln.strip()]
        return False, lines or ["ruff format --check failed (no details)"], []
    return True, [], []


def _check_ruff_lint(py_files: List[Path]) -> tuple[bool, List[str], List[str]]:
    """Run ``ruff check`` over *py_files*.

    Returns (ok, failures, warnings).
    """
    if not py_files:
        return True, [], []

    if not _tool_available("ruff"):
        return True, [], ["[SKIP] ruff not found — lint check skipped"]

    code, out = _run(["ruff", "check"] + [str(f) for f in py_files])
    if code != 0:
        lines = [f"LINT: {ln}" for ln in out.splitlines() if ln.strip()]
        return False, lines[:30] or ["ruff check failed (no details)"], []
    return True, [], []


def _check_tsc(ts_files: List[Path]) -> tuple[bool, List[str], List[str]]:
    """Run ``tsc --noEmit`` in the frontend directory when *ts_files* is non-empty.

    Returns (ok, failures, warnings).
    """
    if not ts_files:
        return True, [], []

    frontend_dir = _project_root() / "frontend"
    tsconfig = frontend_dir / "tsconfig.json"
    if not tsconfig.exists():
        return True, [], ["[SKIP] frontend/tsconfig.json not found — tsc check skipped"]

    # Prefer local tsc; fall back to npx tsc
    if _tool_available("tsc"):
        tsc_cmd: List[str] = ["tsc"]
    else:
        # Try npx (Node.js project tsc)
        npx_check, _ = _run(["npx", "--yes", "tsc", "--version"])
        if npx_check == 0:
            tsc_cmd = ["npx", "tsc"]
        else:
            return True, [], ["[SKIP] tsc / npx tsc not found — TypeScript check skipped"]

    code, out = _run(tsc_cmd + ["--noEmit"], cwd=frontend_dir)
    if code != 0:
        lines = [f"TSC: {ln}" for ln in out.splitlines() if ln.strip()]
        return False, lines[:30] or ["tsc --noEmit failed (no details)"], []
    return True, [], []


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_session_quality_gate(session_files: List[str]) -> QualityGateResult:
    """Run all quality checks against *session_files* and return a result.

    Args:
        session_files: List of file path strings (absolute or relative to
            project root). Non-existent files and non-code files are skipped
            silently.

    Returns:
        :class:`QualityGateResult` with ``passed``, ``dirty``, ``failures``,
        ``warnings``, ``duration_ms``, and ``files_checked`` populated.
    """
    t0 = time.monotonic()

    root = _project_root()

    # Resolve paths; keep only existing .py / .ts / .tsx
    resolved: List[Path] = []
    for raw in session_files:
        p = Path(raw)
        if not p.is_absolute():
            p = root / p
        if p.suffix in (".py", ".ts", ".tsx") and p.exists():
            resolved.append(p)

    py_files = [f for f in resolved if f.suffix == ".py"]
    ts_files = [f for f in resolved if f.suffix in (".ts", ".tsx")]

    all_failures: List[str] = []
    all_warnings: List[str] = []
    overall_pass = True

    for check_fn, files in [
        (_check_ruff_format, py_files),
        (_check_ruff_lint, py_files),
        (_check_tsc, ts_files),
    ]:
        ok, failures, warnings = check_fn(files)  # type: ignore[arg-type]
        all_failures.extend(failures)
        all_warnings.extend(warnings)
        if not ok:
            overall_pass = False

    duration_ms = int((time.monotonic() - t0) * 1000)

    return QualityGateResult(
        passed=overall_pass,
        dirty=not overall_pass,
        failures=all_failures,
        warnings=all_warnings,
        duration_ms=duration_ms,
        files_checked=len(resolved),
    )


# ---------------------------------------------------------------------------
# Rich console printer (used by shell.py and standalone __main__)
# ---------------------------------------------------------------------------


def print_quality_gate_result(result: QualityGateResult) -> None:
    """Print a formatted quality gate summary to the Rich console.

    Imports ``rich`` lazily so that test code running without Rich installed
    can still use :func:`run_session_quality_gate` without errors.
    """
    try:
        from rich.console import Console  # type: ignore[import]
        from rich.panel import Panel  # type: ignore[import]

        console = Console(stderr=True)
    except ImportError:
        # Fallback: plain print
        if result.passed:
            print("[QUALITY GATE] PASS")
        else:
            print("[QUALITY GATE] FAIL")
            for f in result.failures:
                print(f"  {f}")
            print("Session marked DIRTY — fix quality issues before promoting")
        return

    if result.passed:
        console.print(
            Panel(
                f"[bold green]PASS[/bold green]  "
                f"{result.files_checked} file(s) checked in {result.duration_ms}ms",
                title="Quality Gate",
                border_style="green",
            )
        )
        if result.warnings:
            for w in result.warnings:
                console.print(f"  [yellow]{w}[/yellow]")
    else:
        lines = [f"[red]{f}[/red]" for f in result.failures]
        if result.warnings:
            lines += [f"[yellow]{w}[/yellow]" for w in result.warnings]
        lines.append(
            "\n[bold red]Session marked DIRTY — fix quality issues before promoting[/bold red]"
        )
        console.print(
            Panel(
                "\n".join(lines),
                title="[bold red]Quality Gate: FAIL[/bold red]",
                border_style="red",
            )
        )


# ---------------------------------------------------------------------------
# __main__ for quick CLI smoke-testing
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    files = sys.argv[1:]
    if not files:
        print("Usage: python -m msapling_cli.quality_gate <file> [file ...]")
        sys.exit(0)

    result = run_session_quality_gate(files)
    print_quality_gate_result(result)
    sys.exit(0 if result.passed else 1)
