"""PreCompact Hook — capture and persist critical context before LLM compaction.

Before context is compacted (old messages summarised/discarded), this module
extracts the most important context (decisions, file paths, active task,
errors encountered) and persists it to disk.  On session start the most
recent precompact snapshot is loaded and injected into the system prompt so
the LLM has continuity even after compaction.

Storage layout:
    ~/.msapling/precompact/<session_id>_<unix_timestamp>.json

Usage from shell.py:
    Before _compact_context():
        ctx = capture_precompact_context(shell.__dict__)
        persist_precompact_context(ctx, shell.session_id)

    On session start (after loading memories):
        prior = load_latest_precompact(shell.session_id)
        if prior:
            shell.messages.append({
                "role": "system",
                "content": format_for_injection(prior),
            })
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

_PRECOMPACT_DIR = Path.home() / ".msapling" / "precompact"

# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------

@dataclass
class PreCompactContext:
    """Snapshot of critical session state captured just before compaction.

    All fields default to safe empty values so that ``from_dict({})`` always
    succeeds, making the schema forward- and backward-compatible.

    Attributes
    ----------
    decisions_made:
        Short bullet-point strings extracted from assistant messages that
        contain decision-indicating phrases ("decided", "will use", "chosen",
        "approach", etc.).
    files_modified:
        Paths of files that were read, written, or explicitly mentioned in
        messages during the session.
    active_task:
        The most recent user message (first ~300 chars), representing the
        last known goal/task the user was working on.
    errors_encountered:
        Snippets from assistant or user messages containing error indicators
        ("error", "failed", "exception", "traceback").
    model_used:
        The model ID active at the time of compaction.
    turn_count:
        Number of LLM turns completed at the point of compaction.
    cost_so_far:
        Accumulated cost in USD at the point of compaction.
    captured_at:
        Unix timestamp of when this snapshot was taken.
    session_id:
        The session this snapshot belongs to.
    """

    decisions_made: List[str] = field(default_factory=list)
    files_modified: List[str] = field(default_factory=list)
    active_task: str = ""
    errors_encountered: List[str] = field(default_factory=list)
    model_used: str = ""
    turn_count: int = 0
    cost_so_far: float = 0.0
    captured_at: float = field(default_factory=time.time)
    session_id: str = ""

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain JSON-compatible dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PreCompactContext":
        """Deserialise from a dict, tolerating missing or extra keys."""
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


# ---------------------------------------------------------------------------
# Extraction helpers
# ---------------------------------------------------------------------------

_DECISION_PATTERNS = re.compile(
    r"\b(decided|decision|will use|chosen|going with|approach:|plan:|"
    r"instead of|rather than|settled on|opted for|the solution is)\b",
    re.IGNORECASE,
)

_ERROR_PATTERNS = re.compile(
    r"\b(error|exception|traceback|failed|failure|crash|crashed|"
    r"undefined|not found|cannot|could not|ImportError|TypeError|"
    r"ValueError|RuntimeError|AssertionError|404|500)\b",
    re.IGNORECASE,
)

_FILE_PATH_PATTERNS = re.compile(
    # Unix absolute, Windows absolute (C:\), relative with dot, or obvious extensions
    r"(?:^|[\s`'\"])("
    r"(?:[A-Za-z]:[\\/][\w\\/._-]+)|"         # Windows absolute
    r"(?:/[\w/._-]{3,})|"                      # Unix absolute
    r"(?:\.{0,2}/[\w/._-]{3,})|"              # Relative ./foo or ../foo
    r"(?:[\w_-]+\.(?:py|ts|tsx|js|jsx|json|yaml|yml|toml|md|txt|html|css|sh|sql))"
    r")",
    re.MULTILINE,
)


def _extract_decisions(messages: List[Dict[str, Any]]) -> List[str]:
    """Extract short decision snippets from assistant messages."""
    decisions: List[str] = []
    for msg in messages:
        if msg.get("role") != "assistant":
            continue
        content = str(msg.get("content") or "")
        for line in content.splitlines():
            if _DECISION_PATTERNS.search(line):
                snippet = line.strip()[:200]
                if snippet and snippet not in decisions:
                    decisions.append(snippet)
        if len(decisions) >= 10:
            break
    return decisions[:10]


def _extract_file_paths(messages: List[Dict[str, Any]]) -> List[str]:
    """Extract file path mentions from all messages."""
    seen: set = set()
    paths: List[str] = []
    for msg in messages:
        content = str(msg.get("content") or "")
        for m in _FILE_PATH_PATTERNS.finditer(content):
            candidate = m.group(1).strip().strip("'\"` ")
            if candidate and candidate not in seen:
                seen.add(candidate)
                paths.append(candidate)
    return paths[:30]


def _extract_errors(messages: List[Dict[str, Any]]) -> List[str]:
    """Extract error snippets from messages."""
    errors: List[str] = []
    for msg in messages:
        content = str(msg.get("content") or "")
        for line in content.splitlines():
            if _ERROR_PATTERNS.search(line):
                snippet = line.strip()[:250]
                if snippet and snippet not in errors:
                    errors.append(snippet)
        if len(errors) >= 8:
            break
    return errors[:8]


def _extract_active_task(messages: List[Dict[str, Any]]) -> str:
    """Return the last user message (first 300 chars) as the active task."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = str(msg.get("content") or "").strip()
            if content:
                return content[:300]
    return ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def capture_precompact_context(shell_state: dict) -> PreCompactContext:
    """Extract a PreCompactContext snapshot from the current shell state dict.

    Parameters
    ----------
    shell_state:
        ``shell.__dict__`` or any dict with keys: ``messages``, ``model``,
        ``turn_count``, ``cost_total``, ``session_id``, ``files_touched``.

    Returns
    -------
    PreCompactContext
        A fully-populated snapshot ready for persistence.
    """
    messages: List[Dict[str, Any]] = list(shell_state.get("messages") or [])
    model = str(shell_state.get("model") or "")
    turn_count = int(shell_state.get("turn_count") or 0)
    cost_so_far = float(shell_state.get("cost_total") or 0.0)
    session_id = str(shell_state.get("session_id") or "")

    # Files touched tracked explicitly by shell (dedup)
    files_touched: List[str] = list(shell_state.get("files_touched") or [])
    # Also mine messages for any file path mentions
    extracted_paths = _extract_file_paths(messages)
    all_files: List[str] = list(dict.fromkeys(files_touched + extracted_paths))[:30]

    return PreCompactContext(
        decisions_made=_extract_decisions(messages),
        files_modified=all_files,
        active_task=_extract_active_task(messages),
        errors_encountered=_extract_errors(messages),
        model_used=model,
        turn_count=turn_count,
        cost_so_far=cost_so_far,
        captured_at=time.time(),
        session_id=session_id,
    )


def _ensure_precompact_dir() -> None:
    _PRECOMPACT_DIR.mkdir(parents=True, exist_ok=True)
    try:
        _PRECOMPACT_DIR.chmod(0o700)
    except OSError:
        pass  # Windows doesn't support Unix permissions


def persist_precompact_context(ctx: PreCompactContext, session_id: str) -> Path:
    """Write a precompact context snapshot to disk.

    The file is written to:
        ``~/.msapling/precompact/<session_id>_<unix_timestamp_ms>.json``

    Parameters
    ----------
    ctx:
        The PreCompactContext to persist.
    session_id:
        The session identifier (used as the filename prefix).

    Returns
    -------
    Path
        Absolute path to the written file.
    """
    _ensure_precompact_dir()
    # Use millisecond timestamp so rapid successive calls don't collide
    ts_ms = int(time.time() * 1000)
    filename = f"{session_id}_{ts_ms}.json"
    path = _PRECOMPACT_DIR / filename

    # Stamp the session_id into the context before writing
    data = ctx.to_dict()
    data["session_id"] = session_id

    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path.resolve()


def load_latest_precompact(session_id: str) -> Optional[PreCompactContext]:
    """Load the most recent precompact snapshot for a session.

    Returns ``None`` if no precompact files exist for the given session.

    Parameters
    ----------
    session_id:
        The session identifier to look up.

    Returns
    -------
    PreCompactContext or None
    """
    if not _PRECOMPACT_DIR.exists():
        return None
    prefix = f"{session_id}_"
    candidates = sorted(
        [f for f in _PRECOMPACT_DIR.glob(f"{prefix}*.json")],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        return None
    latest = candidates[0]
    try:
        data = json.loads(latest.read_text(encoding="utf-8"))
        return PreCompactContext.from_dict(data)
    except Exception:
        return None


def format_for_injection(ctx: PreCompactContext) -> str:
    """Format a PreCompactContext as a system-prompt-ready string.

    The output is a plain-text block prefixed with
    "Context from before compaction:" intended for injection into the
    system prompt so the LLM retains critical context across compaction.

    Parameters
    ----------
    ctx:
        The snapshot to format.

    Returns
    -------
    str
        Non-empty formatted context string.
    """
    lines: List[str] = ["Context from before compaction:"]
    lines.append("")

    if ctx.active_task:
        lines.append(f"Active task: {ctx.active_task}")
        lines.append("")

    if ctx.model_used:
        cost_note = f", ${ctx.cost_so_far:.4f} spent" if ctx.cost_so_far > 0 else ""
        lines.append(f"Model: {ctx.model_used} ({ctx.turn_count} turns{cost_note})")
        lines.append("")

    if ctx.decisions_made:
        lines.append("Key decisions made:")
        for d in ctx.decisions_made:
            lines.append(f"  - {d}")
        lines.append("")

    if ctx.files_modified:
        lines.append("Files touched:")
        for f in ctx.files_modified[:15]:
            lines.append(f"  - {f}")
        lines.append("")

    if ctx.errors_encountered:
        lines.append("Errors/issues encountered:")
        for e in ctx.errors_encountered[:5]:
            lines.append(f"  - {e}")
        lines.append("")

    captured_ts = ""
    if ctx.captured_at:
        try:
            from datetime import datetime, timezone
            captured_ts = datetime.fromtimestamp(ctx.captured_at, tz=timezone.utc).strftime(
                "%Y-%m-%d %H:%M UTC"
            )
        except Exception:
            pass
    if captured_ts:
        lines.append(f"Snapshot captured: {captured_ts}")

    return "\n".join(lines).strip()
