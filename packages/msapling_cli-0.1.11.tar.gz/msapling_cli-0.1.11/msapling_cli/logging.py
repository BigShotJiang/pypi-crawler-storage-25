"""Structured logging for MSapling CLI.

Provides machine-parseable JSON logs alongside human-readable console output.
Logs written to ~/.msapling/logs/cli.jsonl (append-only, auto-rotated).

Usage:
    from msapling_cli.logging import cli_logger
    cli_logger.info("TOOL_EXECUTED", tool="read_file", path="src/main.py", duration_ms=12)
    cli_logger.error("API_FAILED", status=502, endpoint="/chat/message")
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, Optional

_LOG_DIR = Path.home() / ".msapling" / "logs"
_LOG_FILE = _LOG_DIR / "cli.jsonl"
_MAX_LOG_SIZE = 5 * 1024 * 1024  # 5MB, then rotate
_SESSION_ID: Optional[str] = None

# Sensitive key redaction
_REDACT_KEYS = frozenset({
    "password", "secret", "token", "api_key", "apikey",
    "authorization", "cookie", "credential", "key",
})


def _redact(data: Dict[str, Any]) -> Dict[str, Any]:
    """Redact sensitive keys from log data."""
    out = {}
    for k, v in data.items():
        if any(s in k.lower() for s in _REDACT_KEYS):
            out[k] = "[REDACTED]"
        elif isinstance(v, dict):
            out[k] = _redact(v)
        else:
            out[k] = v
    return out


def set_session_id(sid: str) -> None:
    global _SESSION_ID
    _SESSION_ID = sid


class CLILogger:
    """Structured JSON logger with auto-rotation."""

    def __init__(self):
        self._ensure_dir()

    def _ensure_dir(self):
        try:
            _LOG_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def _rotate_if_needed(self):
        try:
            if _LOG_FILE.exists() and _LOG_FILE.stat().st_size > _MAX_LOG_SIZE:
                rotated = _LOG_DIR / "cli.jsonl.1"
                if rotated.exists():
                    rotated.unlink()
                _LOG_FILE.rename(rotated)
        except Exception:
            pass

    def _write(self, level: str, event: str, **data: Any):
        record = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "level": level,
            "event": event,
            "session": _SESSION_ID,
        }
        if data:
            record["data"] = _redact(data)
        try:
            self._rotate_if_needed()
            with open(_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")
        except Exception:
            pass  # Never crash the CLI due to logging

    def info(self, event: str, **data: Any):
        self._write("INFO", event, **data)

    def warning(self, event: str, **data: Any):
        self._write("WARN", event, **data)

    def error(self, event: str, **data: Any):
        self._write("ERROR", event, **data)

    def debug(self, event: str, **data: Any):
        if os.getenv("MSAPLING_DEBUG"):
            self._write("DEBUG", event, **data)

    def tool(self, name: str, args: Dict[str, Any], result_len: int, duration_ms: float):
        """Log a tool execution with timing."""
        self._write("INFO", "TOOL_EXEC", tool=name,
                     args_keys=list(args.keys()), result_len=result_len,
                     duration_ms=round(duration_ms, 1))

    def api_call(self, method: str, endpoint: str, status: int, duration_ms: float):
        """Log an API call."""
        self._write("INFO", "API_CALL", method=method, endpoint=endpoint,
                     status=status, duration_ms=round(duration_ms, 1))

    def cost(self, tokens: int, cost_usd: float, model: str):
        """Log a cost event."""
        self._write("INFO", "COST", tokens=tokens, cost_usd=cost_usd, model=model)


cli_logger = CLILogger()
