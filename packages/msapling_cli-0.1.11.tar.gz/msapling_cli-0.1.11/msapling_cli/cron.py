"""MSapling CLI - Cron Mode: schedule and run MSapling prompts automatically."""
from __future__ import annotations

import json
import os
import platform
import re
import sched
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from .tui import console

# ---------------------------------------------------------------------------
# Constants / storage
# ---------------------------------------------------------------------------

CRON_FILE = Path.home() / ".msapling" / "cron.json"

SHORTHANDS = {
    "@yearly":   "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
    "@monthly":  "0 0 1 * *",
    "@weekly":   "0 0 * * 0",
    "@daily":    "0 0 * * *",
    "@midnight": "0 0 * * *",
    "@hourly":   "0 * * * *",
}

# Minimal cron expression validation: 5 space-separated fields
_CRON_RE = re.compile(
    r"^(\*|(\*/\d+)|\d+(-\d+)?(,\d+(-\d+)?)*)\s+"
    r"(\*|(\*/\d+)|\d+(-\d+)?(,\d+(-\d+)?)*)\s+"
    r"(\*|(\*/\d+)|\d+(-\d+)?(,\d+(-\d+)?)*)\s+"
    r"(\*|(\*/\d+)|\d+(-\d+)?(,\d+(-\d+)?)*)\s+"
    r"(\*|(\*/\d+)|\d+(-\d+)?(,\d+(-\d+)?)*)$"
)

# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

cron_app = typer.Typer(help="Schedule and run MSapling prompts via cron.", no_args_is_help=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load() -> list[dict]:
    if not CRON_FILE.exists():
        return []
    try:
        return json.loads(CRON_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []


def _save(jobs: list[dict]) -> None:
    CRON_FILE.parent.mkdir(parents=True, exist_ok=True)
    CRON_FILE.write_text(json.dumps(jobs, indent=2), encoding="utf-8")


def _resolve_schedule(schedule: str) -> str:
    """Expand shorthand (@daily etc.) to a full 5-field cron expression."""
    lower = schedule.strip().lower()
    if lower in SHORTHANDS:
        return SHORTHANDS[lower]
    return schedule.strip()


def _validate_schedule(schedule: str) -> str:
    """Return the resolved schedule or raise typer.BadParameter."""
    resolved = _resolve_schedule(schedule)
    if not _CRON_RE.match(resolved):
        raise typer.BadParameter(
            f"Invalid cron expression: '{schedule}'. "
            "Use 5-field cron syntax (e.g. '0 9 * * 1-5') or a shorthand like @daily."
        )
    return resolved


def _cron_fields(expr: str) -> tuple[list, list, list, list, list]:
    """Split a 5-field cron expression into parsed field sets."""
    parts = expr.split()
    assert len(parts) == 5

    def _parse_field(s: str, lo: int, hi: int) -> list[int]:
        if s == "*":
            return list(range(lo, hi + 1))
        result: set[int] = set()
        for tok in s.split(","):
            if "/" in tok:
                base, step_s = tok.split("/", 1)
                step = int(step_s)
                r = range(lo, hi + 1) if base == "*" else range(*[int(x) for x in base.split("-")] + [hi + 1])
                result.update(r[::step])
            elif "-" in tok:
                a, b = tok.split("-", 1)
                result.update(range(int(a), int(b) + 1))
            else:
                result.add(int(tok))
        return sorted(result)

    minute  = _parse_field(parts[0], 0, 59)
    hour    = _parse_field(parts[1], 0, 23)
    dom     = _parse_field(parts[2], 1, 31)
    month   = _parse_field(parts[3], 1, 12)
    dow     = _parse_field(parts[4], 0, 6)
    return minute, hour, dom, month, dow


def _next_run(expr: str, after: datetime | None = None) -> datetime | None:
    """Return the next datetime (UTC, second=0) when expr fires after `after`."""
    try:
        minute, hour, dom, month, dow = _cron_fields(expr)
    except Exception:
        return None

    base = after or datetime.now(tz=timezone.utc)
    # Start search from the next minute
    t = base.replace(second=0, microsecond=0)
    t = t.replace(minute=t.minute + 1) if t.second > 0 or t.microsecond > 0 else t

    # Brute-force search up to ~366 days ahead
    for _ in range(366 * 24 * 60):
        if (
            t.month  in month
            and t.day    in dom
            and t.weekday() % 7 in dow   # Python: Mon=0; cron: Sun=0
            and t.hour   in hour
            and t.minute in minute
        ):
            return t
        t = t.replace(
            minute=t.minute + 1 if t.minute < 59 else 0,
            hour=t.hour if t.minute < 59 else (t.hour + 1 if t.hour < 23 else 0),
        )
        if t.minute == 0 and t.hour == 0:
            # crossed midnight — bump the day using timedelta
            from datetime import timedelta
            t = (t - t.replace(hour=0, minute=0, second=0, microsecond=0) +
                 t.replace(hour=0, minute=0, second=0, microsecond=0).replace(
                     day=t.day + 1 if t.day < 28 else 1,
                     month=t.month if t.day < 28 else (t.month + 1 if t.month < 12 else 1),
                     year=t.year if not (t.month == 12 and t.day >= 28) else t.year + 1,
                 ))
    return None


def _run_job(job: dict) -> None:
    """Execute a cron job by calling the msapling CLI non-interactively."""
    prompt = job["prompt"]
    model_args = ["--model", job["model"]] if job.get("model") else []
    project_args = ["--project", job["project"]] if job.get("project") else []

    cmd = [sys.executable, "-m", "msapling_cli", "chat", *model_args, *project_args, prompt]
    console.print(f"[dim]Running cron job '{job['name']}': {prompt[:60]}…[/dim]")
    try:
        result = subprocess.run(cmd, capture_output=False, text=True)
        if result.returncode != 0:
            console.print(f"[red]Job '{job['name']}' exited with code {result.returncode}[/red]")
    except Exception as exc:
        console.print(f"[red]Job '{job['name']}' failed: {exc}[/red]")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@cron_app.command("add")
def cron_add(
    name: str = typer.Argument(..., help="Unique job name"),
    schedule: str = typer.Argument(..., help="Cron expression or shorthand (@daily, @hourly…)"),
    prompt: str = typer.Argument(..., help="Prompt to send to MSapling"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model ID"),
) -> None:
    """Add a new cron job."""
    resolved = _validate_schedule(schedule)
    jobs = _load()
    if any(j["name"] == name for j in jobs):
        console.print(f"[yellow]Job '{name}' already exists. Remove it first.[/yellow]")
        raise typer.Exit(1)
    job: dict = {
        "name": name,
        "schedule": resolved,
        "prompt": prompt,
        "project": project,
        "model": model,
        "created_at": datetime.now(tz=timezone.utc).isoformat(),
    }
    jobs.append(job)
    _save(jobs)
    nxt = _next_run(resolved)
    nxt_str = nxt.strftime("%Y-%m-%d %H:%M UTC") if nxt else "unknown"
    console.print(f"[green]Cron job '[bold]{name}[/bold]' added. Next run: {nxt_str}[/green]")


@cron_app.command("list")
def cron_list() -> None:
    """List all cron jobs with next-run times."""
    jobs = _load()
    if not jobs:
        console.print("[dim]No cron jobs configured. Use `msapling cron add` to create one.[/dim]")
        return
    tbl = Table(title="MSapling Cron Jobs", show_lines=True)
    tbl.add_column("Name", style="bold cyan")
    tbl.add_column("Schedule")
    tbl.add_column("Next Run (UTC)")
    tbl.add_column("Prompt")
    for j in jobs:
        nxt = _next_run(j["schedule"])
        nxt_str = nxt.strftime("%Y-%m-%d %H:%M") if nxt else "—"
        tbl.add_row(j["name"], j["schedule"], nxt_str, j["prompt"][:60] + ("…" if len(j["prompt"]) > 60 else ""))
    console.print(tbl)


@cron_app.command("remove")
def cron_remove(
    name: str = typer.Argument(..., help="Job name to remove"),
) -> None:
    """Remove a cron job by name."""
    jobs = _load()
    before = len(jobs)
    jobs = [j for j in jobs if j["name"] != name]
    if len(jobs) == before:
        console.print(f"[red]No job named '{name}' found.[/red]")
        raise typer.Exit(1)
    _save(jobs)
    console.print(f"[green]Cron job '[bold]{name}[/bold]' removed.[/green]")


@cron_app.command("run")
def cron_run(
    name: str = typer.Argument(..., help="Job name to run immediately"),
) -> None:
    """Run a cron job immediately (for testing)."""
    jobs = _load()
    match = next((j for j in jobs if j["name"] == name), None)
    if not match:
        console.print(f"[red]No job named '{name}' found.[/red]")
        raise typer.Exit(1)
    console.print(f"[bold]Running job '[cyan]{name}[/cyan]' now…[/bold]")
    _run_job(match)


@cron_app.command("daemon")
def cron_daemon(
    interval: int = typer.Option(30, "--interval", "-i", help="Poll interval in seconds"),
) -> None:
    """Start the cron daemon (foreground process that fires jobs at scheduled times)."""
    console.print("[bold green]MSapling cron daemon starting…[/bold green]")
    console.print(f"[dim]Poll interval: {interval}s  |  Cron file: {CRON_FILE}[/dim]")
    console.print("[dim]Press Ctrl+C to stop.[/dim]")

    last_fired: dict[str, str] = {}  # name -> last fired minute string

    try:
        while True:
            now = datetime.now(tz=timezone.utc).replace(second=0, microsecond=0)
            now_key = now.strftime("%Y-%m-%d %H:%M")
            jobs = _load()
            for job in jobs:
                # Avoid firing twice in the same minute
                if last_fired.get(job["name"]) == now_key:
                    continue
                try:
                    minute, hour, dom, month, dow = _cron_fields(job["schedule"])
                except Exception:
                    continue
                if (
                    now.month   in month
                    and now.day     in dom
                    and now.weekday() % 7 in dow
                    and now.hour    in hour
                    and now.minute  in minute
                ):
                    last_fired[job["name"]] = now_key
                    console.print(f"[bold cyan][{now_key}] Firing job '{job['name']}'[/bold cyan]")
                    _run_job(job)
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\n[yellow]Cron daemon stopped.[/yellow]")


@cron_app.command("install")
def cron_install() -> None:
    """Install the cron daemon as a background service."""
    exe = sys.executable
    script = f"{exe} -m msapling_cli cron daemon"
    system = platform.system()

    if system == "Windows":
        task_name = "MSaplingCronDaemon"
        console.print(f"[bold]Installing Windows Task Scheduler entry '[cyan]{task_name}[/cyan]'…[/bold]")
        schtasks_cmd = (
            f'schtasks /Create /SC ONLOGON /TN "{task_name}" '
            f'/TR "{script}" /F /RL HIGHEST'
        )
        try:
            result = subprocess.run(schtasks_cmd, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                console.print(f"[green]Task '{task_name}' registered in Windows Task Scheduler.[/green]")
                console.print("[dim]It will start on next login. To start now:[/dim]")
                console.print(f"[dim]  schtasks /Run /TN \"{task_name}\"[/dim]")
            else:
                console.print(f"[red]Failed to register task: {result.stderr.strip()}[/red]")
                console.print(f"[dim]Run manually as Administrator: {schtasks_cmd}[/dim]")
        except Exception as exc:
            console.print(f"[red]Error: {exc}[/red]")
    else:
        console.print("[bold]To install on Linux/macOS, add this line to your crontab:[/bold]")
        console.print(f"[cyan]* * * * * {script}[/cyan]")
        console.print()
        console.print("[dim]Open your crontab with:[/dim]")
        console.print("[dim]  crontab -e[/dim]")
        console.print()
        console.print("[dim]Or for systemd (Linux):[/dim]")
        unit = f"""[Unit]
Description=MSapling Cron Daemon

[Service]
ExecStart={script}
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
"""
        unit_path = "~/.config/systemd/user/msapling-cron.service"
        console.print(f"[dim]  Write to {unit_path}:[/dim]")
        console.print(f"[dim]{unit}[/dim]")
        console.print("[dim]  Then: systemctl --user enable --now msapling-cron[/dim]")
