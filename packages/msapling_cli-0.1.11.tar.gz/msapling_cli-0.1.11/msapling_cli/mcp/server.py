"""
MSapling MCP Server

Exposes MSapling capabilities as MCP tools that Claude Code, Cursor,
Windsurf, and other MCP-compatible AI tools can call.

Tools exposed:
  - msapling_chat: Send a message to any LLM via MSapling (multi-model)
  - msapling_diff: Generate unified diff between two texts
  - msapling_apply_diff: Apply a unified diff to file content
  - msapling_search_files: Semantic search across MDrive files
  - msapling_read_file: Read a file from MDrive
  - msapling_write_file: Write a file to MDrive with versioning
  - msapling_project_context: Scan local project and build LLM context
  - msapling_cost_check: Check remaining fuel credits and usage
  - msapling_models: List available models with pricing

Usage in Claude Code:
  Add to ~/.claude/settings.json:
  {
    "mcpServers": {
      "msapling": {
        "command": "msapling",
        "args": ["mcp-serve"],
        "env": {
          "MSAPLING_TOKEN": "your-jwt-token",
          "MSAPLING_API_URL": "https://api.msapling.com"
        }
      }
    }
  }

Usage in Cursor:
  Add to .cursor/mcp.json:
  {
    "msapling": {
      "command": "msapling",
      "args": ["mcp-serve"]
    }
  }
"""
from __future__ import annotations

import asyncio
import io
import json
import os
import sys
import uuid
from collections import OrderedDict
from typing import Any, Dict, List, Optional

from .. import __version__

# ─── Per-Client Session Isolation ─────────────────────────────────────
# Each connected client gets an isolated session context keyed by client_id.
# This prevents msapling_chat tool calls from interleaving state across
# simultaneous connections.

_CLIENT_SESSIONS_MAX: int = 50
_CLIENT_SESSIONS: "OrderedDict[str, Dict[str, Any]]" = OrderedDict()


def _create_client_session(client_id: str) -> Dict[str, Any]:
    """Create a new isolated session for *client_id*.

    Enforces the ``_CLIENT_SESSIONS_MAX`` cap via LRU eviction: when the dict
    is at capacity the oldest (least-recently-used) entry is dropped before
    inserting the new one.
    """
    while len(_CLIENT_SESSIONS) >= _CLIENT_SESSIONS_MAX:
        _CLIENT_SESSIONS.popitem(last=False)  # evict LRU (oldest) entry
    session: Dict[str, Any] = {
        "client_id": client_id,
        "chat_id": None,
        "project_id": None,
        "message_history": [],
    }
    _CLIENT_SESSIONS[client_id] = session
    return session


def _get_client_session(client_id: str) -> Dict[str, Any]:
    """Return the session for *client_id*, creating one if it doesn't exist.

    Moves the entry to the MRU (most-recently-used) end on access.
    """
    if client_id not in _CLIENT_SESSIONS:
        return _create_client_session(client_id)
    # Move to MRU end.
    _CLIENT_SESSIONS.move_to_end(client_id)
    return _CLIENT_SESSIONS[client_id]


def _destroy_client_session(client_id: str) -> None:
    """Remove and clean up the session associated with *client_id*."""
    _CLIENT_SESSIONS.pop(client_id, None)

# ─── Multi-Transport Config ───────────────────────────────────────────
# Documents the transport roadmap without breaking existing stdio behaviour.
# Pass --transport <name> to the mcp-serve entry point to select.

try:
    from enum import Enum

    class MCPTransport(str, Enum):
        STDIO = "stdio"
        SSE = "sse"
        HTTP = "http"

except Exception:  # pragma: no cover
    pass  # fallback: enum unavailable (shouldn't happen on Python 3.9+)

TRANSPORT_CONFIG = {
    "stdio": {"description": "Standard I/O (default, for CLI integration)"},
    "sse":   {"description": "Server-Sent Events (for web integration)", "default_port": 8765},
    "http":  {"description": "HTTP polling (for legacy clients)", "default_port": 8766},
}

_active_transport: str = "stdio"


def _select_transport(transport: str) -> str:
    """Validate and activate the requested transport. Returns the active transport name."""
    global _active_transport
    t = transport.lower().strip()
    if t not in TRANSPORT_CONFIG:
        sys.stderr.write(
            f"[msapling-mcp] Unknown transport '{transport}'. "
            f"Valid options: {', '.join(TRANSPORT_CONFIG)}. Falling back to stdio.\n"
        )
        t = "stdio"
    _active_transport = t
    return t


# ─── SSE/HTTP Transport ───────────────────────────────────────────────
# Real minimal SSE transport using aiohttp.
# Falls back to stdio with a clear warning if aiohttp is not installed.
#
# Endpoints:
#   GET  /events  — SSE stream; sends JSON-RPC notifications as SSE data frames
#   POST /rpc     — Receive a JSON-RPC request; dispatch to tool handler; return JSON
#
# Port: MCP_SSE_PORT env var (default 3001)

_MCP_SSE_PORT_DEFAULT = 3001

try:
    import aiohttp  # type: ignore
    import aiohttp.web  # type: ignore
    _AIOHTTP_AVAILABLE = True
except ImportError:
    _AIOHTTP_AVAILABLE = False


async def _sse_rpc_handler(request: "aiohttp.web.Request") -> "aiohttp.web.Response":  # type: ignore
    """POST /rpc — receive a JSON-RPC request, dispatch, return JSON response.

    Each SSE session is identified by an ``X-Client-ID`` header that the
    ``/events`` endpoint stamps on creation.  The client_id is used to look up
    (or create) the per-client session context so that concurrent connections
    cannot interleave their state.
    """
    try:
        body = await request.json()
    except Exception:
        return aiohttp.web.Response(
            status=400,
            content_type="application/json",
            text=json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}),
        )

    # Resolve the client_id for this request.  Clients that opened an /events
    # stream will have been told their assigned client_id via the connected
    # notification.  Stateless callers get a fresh ephemeral session.
    client_id: str = request.headers.get("X-Client-ID") or str(uuid.uuid4())
    session = _get_client_session(client_id)

    method = body.get("method", "")
    msg_id = body.get("id")
    params = body.get("params") or {}

    if method == "initialize":
        result = {
            "protocolVersion": str(params.get("protocolVersion") or "2024-11-05"),
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "msapling", "version": __version__},
        }
        return aiohttp.web.Response(
            content_type="application/json",
            text=json.dumps({"jsonrpc": "2.0", "id": msg_id, "result": result}),
        )

    if method == "tools/list":
        return aiohttp.web.Response(
            content_type="application/json",
            text=json.dumps({"jsonrpc": "2.0", "id": msg_id, "result": {"tools": TOOLS}}),
        )

    if method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments") or {}

        validation_error = validate_tool_params(tool_name, tool_args)
        if validation_error is not None:
            payload = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": f"invalid_params: {validation_error.get('details', '')}"}],
                    "isError": True,
                    **validation_error,
                },
            }
            return aiohttp.web.Response(
                content_type="application/json",
                text=json.dumps(payload),
            )

        try:
            result = await _handle_tool(tool_name, tool_args, client_id=client_id, session=session)
            return aiohttp.web.Response(
                content_type="application/json",
                text=json.dumps({"jsonrpc": "2.0", "id": msg_id, "result": result}),
            )
        except Exception as exc:
            sys.stderr.write(f"[msapling-mcp/sse] Tool error: {exc}\n")
            payload = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": f"Tool execution failed: {type(exc).__name__}"}],
                    "isError": True,
                },
            }
            return aiohttp.web.Response(
                content_type="application/json",
                text=json.dumps(payload),
            )

    if msg_id is not None:
        return aiohttp.web.Response(
            content_type="application/json",
            text=json.dumps({"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}),
        )

    return aiohttp.web.Response(status=204)


async def _sse_events_handler(request: "aiohttp.web.Request") -> "aiohttp.web.StreamResponse":  # type: ignore
    """GET /events — SSE stream that forwards JSON-RPC notification messages.

    A new ``client_id`` (UUID4) is generated for every connection.  It is
    sent to the client in the initial ``notifications/connected`` payload so
    subsequent ``POST /rpc`` calls can include it via the ``X-Client-ID``
    header to look up the correct per-client session context.

    Session state is cleaned up when the client disconnects (normal EOF,
    CancelledError, or ConnectionResetError).
    """
    # Generate a unique id for this connection and allocate its session.
    client_id: str = str(uuid.uuid4())
    _create_client_session(client_id)

    response = aiohttp.web.StreamResponse()
    response.headers["Content-Type"] = "text/event-stream"
    response.headers["Cache-Control"] = "no-cache"
    response.headers["Connection"] = "keep-alive"
    response.headers["Access-Control-Allow-Origin"] = "*"
    await response.prepare(request)

    # Announce the client_id so the caller can echo it back in X-Client-ID.
    connected_msg = json.dumps({
        "jsonrpc": "2.0",
        "method": "notifications/connected",
        "params": {"client_id": client_id},
    })
    # SSE data frame format: "data: <payload>\n\n"
    await response.write(f"data: {connected_msg}\n\n".encode("utf-8"))

    # Keep the connection alive; push heartbeats until client disconnects.
    try:
        while True:
            await asyncio.sleep(15)
            if request.transport is None or request.transport.is_closing():
                break
            ping = json.dumps({"jsonrpc": "2.0", "method": "notifications/ping", "params": {}})
            await response.write(f"data: {ping}\n\n".encode("utf-8"))
    except (asyncio.CancelledError, ConnectionResetError):
        pass
    finally:
        # Clean up session state when the client disconnects.
        _destroy_client_session(client_id)

    return response


def _serve_sse(port: int) -> None:
    """Start the aiohttp-based SSE/HTTP MCP transport on the given port.

    Blocks until KeyboardInterrupt or process termination.
    Falls back to stdio if aiohttp is not available (handled by the caller).
    """
    if not _AIOHTTP_AVAILABLE:  # pragma: no cover
        raise RuntimeError("aiohttp not available")

    app = aiohttp.web.Application()
    app.router.add_get("/events", _sse_events_handler)
    app.router.add_post("/rpc", _sse_rpc_handler)

    sys.stderr.write(
        f"[msapling-mcp] SSE transport listening on http://0.0.0.0:{port}\n"
        f"  GET  /events  — SSE notification stream\n"
        f"  POST /rpc     — JSON-RPC dispatcher\n"
    )

    aiohttp.web.run_app(app, host="0.0.0.0", port=port, print=None, access_log=None)


# MCP protocol: communicate over stdin/stdout with JSON-RPC 2.0
# MUST use binary mode on Windows to avoid \r\n translation breaking Content-Length

_stdin_bin: io.BufferedReader = None  # type: ignore
_stdout_bin: io.BufferedWriter = None  # type: ignore
_transport_mode = "framed"


def _init_binary_io() -> None:
    """Switch stdin/stdout to binary mode (critical on Windows)."""
    global _stdin_bin, _stdout_bin
    if sys.platform == "win32":
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
    _stdin_bin = sys.stdin.buffer
    _stdout_bin = sys.stdout.buffer


def _write_message(msg: dict) -> None:
    """Write a JSON-RPC message to stdout using the active transport mode."""
    raw = json.dumps(msg).encode("utf-8")
    if _transport_mode == "raw_line":
        data = raw + b"\n"
    else:
        header = f"Content-Length: {len(raw)}\r\n\r\n".encode("ascii")
        data = header + raw
    fd = sys.stdout.fileno()
    while data:
        n = os.write(fd, data)
        data = data[n:]


def _read_message() -> Optional[dict]:
    """Read a JSON-RPC message from stdin using low-level os.read for Windows pipe compat."""
    global _transport_mode
    fd = sys.stdin.fileno()

    # Support both standard MCP Content-Length framing and Claude Code's
    # newline-delimited JSON startup messages on Windows.
    buffer = b""
    separator = None
    while True:
        try:
            b = os.read(fd, 1)
        except OSError:
            return None
        if not b:
            stripped = buffer.strip()
            if stripped:
                try:
                    _transport_mode = "raw_line"
                    return json.loads(stripped.decode("utf-8"))
                except Exception:
                    pass
            return None
        buffer += b
        if buffer.endswith(b"\r\n\r\n"):
            separator = b"\r\n\r\n"
            break
        if buffer.endswith(b"\n\n"):
            separator = b"\n\n"
            break
        if buffer.endswith(b"\n"):
            stripped = buffer.strip()
            if stripped.startswith((b"{", b"[")):
                try:
                    _transport_mode = "raw_line"
                    return json.loads(stripped.decode("utf-8"))
                except json.JSONDecodeError:
                    pass

    # Parse Content-Length from headers
    _transport_mode = "framed"
    content_length = 0
    header_text = buffer[:-len(separator)].decode("ascii", errors="ignore")
    for line in header_text.replace("\r\n", "\n").split("\n"):
        if line.lower().startswith("content-length:"):
            try:
                content_length = int(line.split(":", 1)[1].strip())
            except ValueError:
                return None  # malformed Content-Length header
    if content_length == 0:
        return None
    if content_length > 50 * 1024 * 1024:
        return None  # cap at 50 MB to prevent DoS

    body = b""
    remaining = content_length
    while remaining > 0:
        chunk = os.read(fd, remaining)
        if not chunk:
            return None
        body += chunk
        remaining -= len(chunk)

    return json.loads(body.decode("utf-8"))


# ─── Tool Definitions ─────────────────────────────────────────────────

TOOLS = [
    {
        "name": "msapling_chat",
        "description": "Send a message to any LLM through MSapling. Supports 200+ models via OpenRouter, OpenAI, Anthropic, Google, Ollama. Tracks costs automatically.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The message to send"},
                "model": {"type": "string", "description": "Model ID (e.g. 'google/gemini-flash-1.5', 'anthropic/claude-3.5-sonnet')", "default": "google/gemini-2.0-flash-001"},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "msapling_diff",
        "description": "Generate a unified diff between old and new content. Uses MSapling's MLineage engine for validated, structured diffs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "old_content": {"type": "string", "description": "Original file content"},
                "new_content": {"type": "string", "description": "Modified file content"},
                "filename": {"type": "string", "description": "Filename for diff headers", "default": "file"},
            },
            "required": ["old_content", "new_content"],
        },
    },
    {
        "name": "msapling_apply_diff",
        "description": "Apply a unified diff to original content. Returns the patched content. Safe: validates diff format before applying.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "original_content": {"type": "string", "description": "Original file content"},
                "diff_text": {"type": "string", "description": "Unified diff to apply"},
            },
            "required": ["original_content", "diff_text"],
        },
    },
    {
        "name": "msapling_search_files",
        "description": "Search files in an MDrive project by keyword relevance. Returns ranked results with content previews.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results", "default": 5},
            },
            "required": ["project_id", "query"],
        },
    },
    {
        "name": "msapling_read_file",
        "description": "Read a file from MDrive storage. Returns file content with version info.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "file_path": {"type": "string", "description": "Path to file"},
            },
            "required": ["project_id", "file_path"],
        },
    },
    {
        "name": "msapling_write_file",
        "description": "Write a file to MDrive storage with automatic versioning and conflict detection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "MDrive project ID"},
                "file_path": {"type": "string", "description": "Path to file"},
                "content": {"type": "string", "description": "File content to write"},
            },
            "required": ["project_id", "file_path", "content"],
        },
    },
    {
        "name": "msapling_project_context",
        "description": "Scan a local directory and build an LLM-ready context block with file tree and contents. Works offline, no server needed.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Project directory path", "default": "."},
                "max_files": {"type": "integer", "description": "Maximum files to include", "default": 30},
                "max_file_size_kb": {"type": "integer", "description": "Skip files larger than this (KB)", "default": 50},
            },
        },
    },
    {
        "name": "msapling_cost_check",
        "description": "Check your MSapling account: remaining fuel credits, tier, and usage stats.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "msapling_models",
        "description": "List available LLM models with pricing info. Includes OpenRouter, OpenAI, Anthropic, Google, Ollama models.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "msapling_multi_chat",
        "description": "Send the same prompt to multiple LLM models IN PARALLEL. Returns all responses for comparison. Useful for getting diverse perspectives or benchmarking models.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The prompt to send to all models"},
                "models": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of model IDs to query in parallel",
                    "default": ["google/gemini-2.0-flash-001", "anthropic/claude-3-haiku", "openai/gpt-4o-mini"],
                },
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "msapling_swarm",
        "description": "Run a multi-model swarm: sends prompt to N models in parallel, then a judge model synthesizes the best answer. Returns both individual responses and the synthesis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The task for the swarm"},
                "models": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Models to run in parallel (default: gemini, claude, gpt)",
                },
                "judge_model": {"type": "string", "description": "Model to synthesize final answer"},
            },
            "required": ["prompt"],
        },
    },
]


# ─── Tool Param Schemas ───────────────────────────────────────────────
# JSON Schema definitions for validating incoming params before handler dispatch.
# Keys match the tool names in TOOLS list above.

TOOL_SCHEMAS: Dict[str, Dict] = {
    "msapling_chat": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "model": {"type": "string"},
        },
        "required": ["prompt"],
    },
    "msapling_diff": {
        "type": "object",
        "properties": {
            "old_content": {"type": "string"},
            "new_content": {"type": "string"},
            "filename": {"type": "string"},
        },
        "required": ["old_content", "new_content"],
    },
    "msapling_apply_diff": {
        "type": "object",
        "properties": {
            "original_content": {"type": "string"},
            "diff_text": {"type": "string"},
        },
        "required": ["original_content", "diff_text"],
    },
    "msapling_search_files": {
        "type": "object",
        "properties": {
            "project_id": {"type": "string"},
            "query": {"type": "string"},
            "limit": {"type": "integer", "minimum": 1, "maximum": 50},
        },
        "required": ["project_id", "query"],
    },
    "msapling_read_file": {
        "type": "object",
        "properties": {
            "project_id": {"type": "string"},
            "file_path": {"type": "string"},
        },
        "required": ["project_id", "file_path"],
    },
    "msapling_write_file": {
        "type": "object",
        "properties": {
            "project_id": {"type": "string"},
            "file_path": {"type": "string"},
            "content": {"type": "string"},
        },
        "required": ["project_id", "file_path", "content"],
    },
    "msapling_project_context": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "max_files": {"type": "integer", "minimum": 1},
            "max_file_size_kb": {"type": "integer", "minimum": 1},
        },
    },
    "msapling_cost_check": {
        "type": "object",
        "properties": {},
    },
    "msapling_models": {
        "type": "object",
        "properties": {},
    },
    "msapling_multi_chat": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "models": {
                "type": "array",
                "items": {"type": "string"},
            },
        },
        "required": ["prompt"],
    },
    "msapling_swarm": {
        "type": "object",
        "properties": {
            "prompt": {"type": "string"},
            "models": {
                "type": "array",
                "items": {"type": "string"},
            },
            "judge_model": {"type": "string"},
        },
        "required": ["prompt"],
    },
}


def validate_tool_params(tool_name: str, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Validate MCP tool params against TOOL_SCHEMAS.

    Returns None if valid (or jsonschema not available — logs a warning and skips).
    Returns {"error": "invalid_params", "details": <message>} if invalid.
    """
    schema = TOOL_SCHEMAS.get(tool_name)
    if schema is None:
        # Unknown tool — let the handler raise its own error.
        return None
    try:
        import jsonschema  # type: ignore
        try:
            jsonschema.validate(instance=params, schema=schema)
        except jsonschema.ValidationError as exc:
            return {"error": "invalid_params", "details": exc.message}
        except jsonschema.SchemaError as exc:
            # Our schema is malformed — log and skip validation.
            sys.stderr.write(f"[msapling-mcp] TOOL_SCHEMAS entry for '{tool_name}' is invalid: {exc.message}\n")
            return None
    except ImportError:
        sys.stderr.write(
            "[msapling-mcp] jsonschema not installed — skipping param validation. "
            "Install with: pip install jsonschema\n"
        )
        return None
    return None


# ─── Tool Handlers ────────────────────────────────────────────────────

def _validate_mcp_path(file_path: str, project_root: str | None = None) -> str:
    """Validate file_path from MCP args — block traversal attempts including symlinks."""
    from pathlib import Path

    path = str(file_path or "").strip()
    if ".." in path or path.startswith("/") or path.startswith("\\"):
        raise ValueError("Invalid file path: traversal or absolute paths not allowed")

    # Resolve symlinks and verify the real path stays inside the project root.
    if project_root:
        root = Path(project_root).resolve()
        resolved = (root / path).resolve()
        if not resolved.is_relative_to(root):
            raise ValueError("Invalid file path: resolved path escapes project root")

    return path


def _validate_mcp_id(value: str, label: str = "id") -> str:
    """Validate IDs from MCP args — block injection and whitespace-only/embedded-whitespace values."""
    raw = str(value or "")
    val = raw.strip()
    # Reject empty string, whitespace-only (raw != val after strip), embedded
    # whitespace, and path traversal/separator characters.
    if not val or raw != val or any(c.isspace() for c in val) or ".." in val or "/" in val or "\\" in val:
        raise ValueError(f"Invalid {label}")
    return val


async def _handle_tool(
    name: str,
    args: Dict[str, Any],
    *,
    client_id: Optional[str] = None,
    session: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Dispatch a tool call to the appropriate handler.

    ``client_id`` and ``session`` are injected by the transport layer so that
    stateful tools (e.g. ``msapling_chat``) operate on isolated per-client
    context rather than shared global state.  When not provided (e.g. during
    unit tests) a transient anonymous session is used automatically.
    """
    # Ensure we always have a session object for the duration of this call.
    if client_id is None:
        client_id = str(uuid.uuid4())
    if session is None:
        session = _get_client_session(client_id)

    from ..api import MSaplingClient
    from ..local import detect_project_root, build_file_tree, read_files_as_context

    if name == "msapling_project_context":
        # Local only — no server needed
        path = args.get("path", ".")
        root, info = detect_project_root(path)
        files = build_file_tree(root, max_files=args.get("max_files", 30))
        context = read_files_as_context(root, files, max_size_kb=args.get("max_file_size_kb", 50))
        return {
            "content": [{"type": "text", "text": context}],
            "metadata": {"root": root, "type": info["type"], "files": len(files), "tokens_est": len(context) // 4},
        }

    # All other tools need the API client
    client = MSaplingClient()
    try:
        if name == "msapling_chat":
            # Use per-client session context so concurrent connections don't
            # share or overwrite each other's chat_id / message_history.
            response = await client.chat_once(
                args["prompt"],
                args.get("model", "google/gemini-2.0-flash-001"),
            )
            # Persist the exchange into the client's isolated session.
            session["message_history"].append({
                "role": "user",
                "content": args["prompt"],
            })
            session["message_history"].append({
                "role": "assistant",
                "content": response,
            })
            return {"content": [{"type": "text", "text": response}]}

        elif name == "msapling_diff":
            result = await client.generate_diff(
                args["old_content"], args["new_content"], args.get("filename", "file"),
            )
            diff_text = result.get("diff", result.get("unified_diff", ""))
            return {"content": [{"type": "text", "text": diff_text}]}

        elif name == "msapling_apply_diff":
            result = await client.apply_diff(args["original_content"], args["diff_text"])
            applied = result.get("applied_content", result.get("content", ""))
            return {"content": [{"type": "text", "text": applied}]}

        elif name == "msapling_search_files":
            project_id = _validate_mcp_id(args["project_id"], "project_id")
            http_client = await client._get_client()
            resp = await http_client.post("/api/mdrive/search", json={
                "project_id": project_id,
                "query": str(args.get("query", ""))[:500],
                "limit": min(int(args.get("limit", 5)), 20),
            })
            resp.raise_for_status()
            return {"content": [{"type": "text", "text": json.dumps(resp.json(), indent=2)}]}

        elif name == "msapling_read_file":
            project_id = _validate_mcp_id(args["project_id"], "project_id")
            proj_root, _ = detect_project_root(".")
            file_path = _validate_mcp_path(args["file_path"], project_root=proj_root)
            content = await client.read_file(project_id, file_path)
            return {"content": [{"type": "text", "text": content}]}

        elif name == "msapling_write_file":
            project_id = _validate_mcp_id(args["project_id"], "project_id")
            proj_root, _ = detect_project_root(".")
            file_path = _validate_mcp_path(args["file_path"], project_root=proj_root)
            result = await client.write_file(project_id, file_path, args["content"])
            return {"content": [{"type": "text", "text": json.dumps(result)}]}

        elif name == "msapling_cost_check":
            user = await client.me()
            fuel = user.get("fuel_credits") or 0.0
            text = (
                f"Tier: {user.get('tier', 'free')}\n"
                f"Fuel Credits: ${fuel:.4f}\n"
                f"Pro: {user.get('is_pro', False)}"
            )
            return {"content": [{"type": "text", "text": text}]}

        elif name == "msapling_models":
            models = await client.get_models()
            lines = [f"{m.get('id', '?')} (ctx: {m.get('context_length', '?')})" for m in models[:30]]
            return {"content": [{"type": "text", "text": "\n".join(lines)}]}

        elif name == "msapling_multi_chat":
            # Tier check: multi requires pro
            user = await client.me()
            tier = str(user.get("tier", "free")).lower()
            if tier not in ("pro", "monthly", "lifetime", "enterprise") and not user.get("is_pro"):
                return {"content": [{"type": "text", "text": "multi_chat requires Pro subscription. Upgrade at https://msapling.com/pricing"}], "isError": True}
            default_models = ["google/gemini-2.0-flash-001", "anthropic/claude-3-haiku", "openai/gpt-4o-mini"]
            models = args.get("models", default_models)
            results = await client.multi_chat(args["prompt"], models)
            lines = []
            for r in results:
                status = "OK" if r.get("status") == "ok" else f"FAILED: {r.get('error', '')}"
                lines.append(f"### {r.get('model', '?')} ({status})\n{r.get('response', '')[:2000]}")
            return {"content": [{"type": "text", "text": "\n\n---\n\n".join(lines)}]}

        elif name == "msapling_swarm":
            # Tier check: swarm requires pro
            user = await client.me()
            tier = str(user.get("tier", "free")).lower()
            if tier not in ("pro", "monthly", "lifetime", "enterprise") and not user.get("is_pro"):
                return {"content": [{"type": "text", "text": "swarm requires Pro subscription. Upgrade at https://msapling.com/pricing"}], "isError": True}
            models = args.get("models")
            judge = args.get("judge_model")
            result = await client.swarm(args["prompt"], models=models, synthesize_model=judge)
            parts = []
            for r in result["agent_responses"]:
                parts.append(f"**{r['model']}**: {r['response'][:1000]}")
            parts.append(f"\n---\n## Synthesis ({result['judge_model']})\n{result['synthesis']}")
            return {"content": [{"type": "text", "text": "\n\n".join(parts)}]}

        else:
            return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}

    finally:
        await client.close()


# ─── MCP Protocol Handler ─────────────────────────────────────────────

def serve(transport: str = "stdio"):
    """Run the MCP server.

    Args:
        transport: Transport to use. One of 'stdio' (default), 'sse', 'http'.
                   - stdio: standard JSON-RPC over stdin/stdout (default, works everywhere)
                   - sse:   aiohttp HTTP server with GET /events (SSE) + POST /rpc
                            Requires ``pip install aiohttp``. Falls back to stdio if missing.
                   - http:  alias for sse (reserved for future polling transport)
    """
    import sys
    _select_transport(transport)
    sys.stderr.write(f"MSapling MCP Server starting (transport={_active_transport})...\n")

    # ── SSE transport ──────────────────────────────────────────────────
    if _active_transport == "sse":
        if not _AIOHTTP_AVAILABLE:
            sys.stderr.write(
                "[msapling-mcp] WARNING: aiohttp is not installed — SSE transport unavailable.\n"
                "  Install with: pip install aiohttp\n"
                "  Falling back to stdio transport.\n"
            )
            # Fall back to stdio
        else:
            port = int(os.environ.get("MCP_SSE_PORT", _MCP_SSE_PORT_DEFAULT))
            _serve_sse(port)
            return  # _serve_sse blocks; we're done when it returns

    # ── stdio transport (default + fallback) ───────────────────────────
    # MUST init binary I/O before any reads/writes (Windows \r\n fix)
    _init_binary_io()

    # Single event loop for the entire server lifetime
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    # Each stdio connection is a single client — generate an isolated session
    # for the lifetime of this process so tool calls are not affected by any
    # concurrent SSE sessions sharing the same _CLIENT_SESSIONS dict.
    stdio_client_id: str = str(uuid.uuid4())
    stdio_session = _create_client_session(stdio_client_id)

    try:
        while True:
            msg = _read_message()
            if msg is None:
                break

            method = msg.get("method", "")
            msg_id = msg.get("id")
            params = msg.get("params", {})

            if method == "initialize":
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {
                        "protocolVersion": str(params.get("protocolVersion") or "2024-11-05"),
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "msapling", "version": __version__},
                    },
                })

            elif method == "notifications/initialized":
                pass  # No response needed

            elif method == "tools/list":
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": {"tools": TOOLS},
                })

            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})

                # Validate params before dispatch
                validation_error = validate_tool_params(tool_name, tool_args)
                if validation_error is not None:
                    _write_message({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": {
                            "content": [{"type": "text", "text": f"invalid_params: {validation_error.get('details', '')}"}],
                            "isError": True,
                            **validation_error,
                        },
                    })
                    continue

                try:
                    result = loop.run_until_complete(
                        _handle_tool(
                            tool_name,
                            tool_args,
                            client_id=stdio_client_id,
                            session=stdio_session,
                        )
                    )
                    _write_message({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": result,
                    })
                except Exception as e:
                    # Log full error to stderr, return generic message to client
                    sys.stderr.write(f"MCP tool error: {e}\n")
                    _write_message({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": {
                            "content": [{"type": "text", "text": f"Tool execution failed: {type(e).__name__}"}],
                            "isError": True,
                        },
                    })

            elif msg_id is not None:
                _write_message({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {"code": -32601, "message": f"Method not found: {method}"},
                })
    finally:
        # Clean up the stdio session on disconnect.
        _destroy_client_session(stdio_client_id)
        loop.close()
