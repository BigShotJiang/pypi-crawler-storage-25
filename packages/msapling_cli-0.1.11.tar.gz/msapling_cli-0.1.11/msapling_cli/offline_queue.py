"""Offline Token Accumulator — local billing parity during backend failover.

Records token usage generated while the backend is unreachable (e.g., Ollama
failover) to a local JSON file and reports them back via
``POST /api/usage/offline-sync`` upon reconnection.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

_log = logging.getLogger(__name__)

# ─── Canonical log key used by guardrails ─────────────────────────────
OFFLINE_HANDOVER_KEY = "OFFLINE_HANDOVER"
ONLINE_RESTORE_KEY = "ONLINE_RESTORE"


class OfflineTokenAccumulator:
    """Accumulates token usage during offline/Ollama failover.

    Records are appended to ``~/.msapling/offline_tokens.json`` and drained
    (reported + cleared) once the backend becomes reachable again.

    Thread / async safety: file mutations are wrapped in an asyncio lock so
    concurrent callers within the same process do not corrupt the log.
    """

    _file: Path = Path("~/.msapling/offline_tokens.json").expanduser()
    _lock: asyncio.Lock = asyncio.Lock()

    # ── Construction ──────────────────────────────────────────────────

    def __init__(self, file: Optional[Path] = None):
        if file is not None:
            self._file = file
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        try:
            self._file.parent.mkdir(parents=True, exist_ok=True)
        except Exception as exc:  # pragma: no cover
            _log.debug("offline_queue: mkdir failed: %s", exc)

    # ── File helpers ──────────────────────────────────────────────────

    def _load(self) -> List[Dict[str, Any]]:
        """Load existing records from disk (returns empty list on any error)."""
        try:
            if not self._file.exists():
                return []
            raw = self._file.read_text(encoding="utf-8").strip()
            if not raw:
                return []
            data = json.loads(raw)
            if isinstance(data, list):
                return data
            return []
        except Exception as exc:
            _log.debug("offline_queue: load failed: %s", exc)
            return []

    def _save(self, records: List[Dict[str, Any]]) -> None:
        """Persist records list to disk (best-effort)."""
        try:
            self._file.write_text(
                json.dumps(records, indent=2, default=str),
                encoding="utf-8",
            )
        except Exception as exc:
            _log.debug("offline_queue: save failed: %s", exc)

    # ── Public API ────────────────────────────────────────────────────

    def record(
        self,
        model_id: str,
        tokens_in: int,
        tokens_out: int,
        cost_estimate: float,
    ) -> None:
        """Append a token-usage record to the local JSON log.

        This is intentionally synchronous — callers inside a streaming handler
        can fire-and-forget without ``await``.  The asyncio lock is NOT held
        here; use ``arecord()`` when you need strict ordering guarantees.
        """
        entry: Dict[str, Any] = {
            "model_id": str(model_id),
            "tokens_in": int(tokens_in),
            "tokens_out": int(tokens_out),
            "cost_estimate": float(cost_estimate),
            "recorded_at": datetime.now(timezone.utc).isoformat(),
        }
        try:
            records = self._load()
            records.append(entry)
            self._save(records)
            _log.debug(
                "offline_queue: recorded %s in=%d out=%d cost=%.6f",
                model_id,
                tokens_in,
                tokens_out,
                cost_estimate,
            )
        except Exception as exc:
            _log.debug("offline_queue: record failed: %s", exc)

    async def arecord(
        self,
        model_id: str,
        tokens_in: int,
        tokens_out: int,
        cost_estimate: float,
    ) -> None:
        """Async-safe variant of :meth:`record`."""
        async with self._lock:
            self.record(model_id, tokens_in, tokens_out, cost_estimate)

    def pending_count(self) -> int:
        """Return number of unsynced records in the local log."""
        return len(self._load())

    async def drain_and_report(self, client: Any) -> int:
        """POST /api/usage/offline-sync with accumulated records.

        Returns the count of records successfully reported to the server.
        Clears the local file on success.  On partial or full failure the
        local file is left intact so records can be retried later.

        Args:
            client: An :class:`~msapling_cli.api.MSaplingClient` instance
                    (or any object with a ``post(path, json=...)`` method).
        """
        async with self._lock:
            records = self._load()
            if not records:
                return 0

            try:
                response = await client.post(
                    "/api/usage/offline-sync",
                    json={"records": records},
                )
                # Accept both dict-like and attribute-based response objects.
                status = (
                    response.get("status")
                    if isinstance(response, dict)
                    else getattr(response, "status", None)
                )
                reported = (
                    response.get("reported", len(records))
                    if isinstance(response, dict)
                    else getattr(response, "reported", len(records))
                )
                if status in ("ok", "accepted"):
                    self._save([])  # clear on success
                    _log.info(
                        "offline_queue: drained %d record(s) to server", reported
                    )
                    return int(reported)
                _log.warning(
                    "offline_queue: server rejected sync: %s", response
                )
            except Exception as exc:
                _log.warning("offline_queue: drain failed: %s", exc)

            return 0

    def clear(self) -> None:
        """Forcibly clear the local log (use with caution)."""
        self._save([])
