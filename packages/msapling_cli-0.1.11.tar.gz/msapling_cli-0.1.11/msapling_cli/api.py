"""HTTP client for MSapling backend API with retry logic and offline detection."""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
import uuid
from contextlib import suppress
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

import httpx

from .agent_registry import default_models_from_registry
from .config import get_settings, get_token
from .logging import cli_logger
from .transcript_hygiene import sanitize_transcript_messages

DEFAULT_PROJECT_NAME = "Default Project"
CLI_UTILITY_PROJECT_NAME = "CLI Utility"
PAID_PROJECT_LIMIT = 10
FREE_PROJECT_LIMIT = 3
PAID_PROJECT_CHAT_LIMIT = 6
FREE_PROJECT_CHAT_LIMIT = 2
PAID_DEFAULT_CHAT_LIMIT = 10
FREE_DEFAULT_CHAT_LIMIT = 5


def _is_ollama_model(model_id: str) -> bool:
    mid = str(model_id or "").strip().lower()
    return mid.startswith("ollama/") or mid.startswith("ollama:")


def _normalize_ollama_model_id(model_id: str) -> str:
    raw = str(model_id or "").strip()
    low = raw.lower()
    if low.startswith("ollama:"):
        return "ollama/" + raw.split(":", 1)[1].strip()
    return raw


def _extract_ollama_model_name(model_id: str) -> str:
    normalized = _normalize_ollama_model_id(model_id)
    if normalized.lower().startswith("ollama/"):
        return normalized.split("/", 1)[1].strip()
    return normalized.strip()


def _mdrive_scoped_path(project_id: str, file_path: str = "") -> str:
    project = str(project_id or "").strip().strip("/")
    rel = str(file_path or "").strip().strip("/")
    if project and rel:
        return f"{project}/{rel}"
    return project or rel or "."


def _is_paid_user(user: Optional[Dict[str, Any]]) -> bool:
    tier = str((user or {}).get("tier", "free")).lower()
    return bool((user or {}).get("is_pro", False)) or tier in ("lifetime", "monthly", "pro", "enterprise")


def _project_limit_for_user(user: Optional[Dict[str, Any]]) -> int:
    return PAID_PROJECT_LIMIT if _is_paid_user(user) else FREE_PROJECT_LIMIT


def _chat_limit_for_project(user: Optional[Dict[str, Any]], project_name: str) -> int:
    is_default = project_name == DEFAULT_PROJECT_NAME
    if _is_paid_user(user):
        return PAID_DEFAULT_CHAT_LIMIT if is_default else PAID_PROJECT_CHAT_LIMIT
    return FREE_DEFAULT_CHAT_LIMIT if is_default else FREE_PROJECT_CHAT_LIMIT


async def fetch_limits_from_backend(client: "MSaplingClient") -> Dict[str, int]:
    """Fetch tier-derived limits from the backend.

    Hits /api/projects/overview for project_limit (server-authoritative) and
    /api/users/me for is_paid (to derive chat limits). Falls back to hardcoded
    defaults if the server is unreachable.
    """
    defaults = {
        "project_limit": FREE_PROJECT_LIMIT,
        "paid_project_limit": PAID_PROJECT_LIMIT,
        "chat_limit_default": FREE_DEFAULT_CHAT_LIMIT,
        "paid_chat_limit_default": PAID_DEFAULT_CHAT_LIMIT,
        "chat_limit_project": FREE_PROJECT_CHAT_LIMIT,
        "paid_chat_limit_project": PAID_PROJECT_CHAT_LIMIT,
    }
    try:
        user, overview = await asyncio.gather(
            client.me(),
            client.get("/api/projects/overview"),
            return_exceptions=True,
        )
        is_paid = _is_paid_user(user) if not isinstance(user, Exception) else False
        limits = dict(defaults)
        # Use server-authoritative project limit if available
        if not isinstance(overview, Exception) and isinstance(overview, dict):
            server_limit = overview.get("project_limit")
            if isinstance(server_limit, int) and server_limit > 0:
                limits["project_limit"] = server_limit
                limits["paid_project_limit"] = server_limit
        # Chat limits still derived from tier until backend exposes them
        limits["chat_limit_default"] = PAID_DEFAULT_CHAT_LIMIT if is_paid else FREE_DEFAULT_CHAT_LIMIT
        limits["chat_limit_project"] = PAID_PROJECT_CHAT_LIMIT if is_paid else FREE_PROJECT_CHAT_LIMIT
        return limits
    except Exception as exc:  # noqa: BLE001
        cli_logger.warning(
            "LIMITS_USING_HARDCODED_FALLBACK: failed to fetch tier limits from backend (%s). "
            "Using hardcoded defaults: project_limit=%d, chat_limit_default=%d.",
            exc,
            defaults["project_limit"],
            defaults["chat_limit_default"],
        )
        return defaults


async def get_project_limit(client: "MSaplingClient") -> int:
    """Return the server-authoritative project limit for the authenticated user.

    Calls ``fetch_limits_from_backend()`` first; if the backend is reachable the
    server value is returned.  When the backend is unreachable the function falls
    back to the hardcoded tier constants (``FREE_PROJECT_LIMIT`` /
    ``PAID_PROJECT_LIMIT``) and logs a ``LIMITS_USING_HARDCODED_FALLBACK``
    warning so operators can detect misconfigured environments.
    """
    limits = await fetch_limits_from_backend(client)
    return limits["project_limit"]


def _normalize_legacy_projects_overview(payload: Dict[str, Any], user: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    project_map = payload.get("projects", {}) if isinstance(payload, dict) else {}
    projects = []
    for name, raw in project_map.items():
        chats = raw.get("chats", []) if isinstance(raw, dict) else []
        chat_count = len(chats)
        chat_limit = _chat_limit_for_project(user, name)
        projects.append({
            "name": name,
            "chat_count": chat_count,
            "chat_limit": chat_limit,
            "is_full": chat_count >= chat_limit,
            "chats": chats,
        })
    project_limit = _project_limit_for_user(user)
    return {
        "projects": projects,
        "project_count": len(projects),
        "project_limit": project_limit,
        "can_create_project": len(projects) < project_limit,
    }


def _normalize_legacy_projects_list(payload: Dict[str, Any], user: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Normalize legacy /api/projects payloads into a list of project rows."""
    project_map = payload.get("projects", payload) if isinstance(payload, dict) else {}
    if not isinstance(project_map, dict):
        return []

    rows: List[Dict[str, Any]] = []
    for name, raw in project_map.items():
        raw = raw if isinstance(raw, dict) else {}
        chats = raw.get("chats", []) if isinstance(raw.get("chats", []), list) else []
        chat_limit = _chat_limit_for_project(user, name)
        rows.append({
            "name": name,
            "chat_count": len(chats),
            "chat_limit": chat_limit,
            "is_full": len(chats) >= chat_limit,
            "tokens_used": raw.get("tokens_used", 0),
            "cost_used": raw.get("cost_used", 0),
            "chats": chats,
        })
    return rows


def extract_usage_metrics(chunk: Dict[str, Any]) -> Tuple[int, float]:
    """Extract total tokens and cost from a streamed usage chunk."""
    usage = chunk.get("usage", {}) if isinstance(chunk, dict) else {}
    total_tokens = int(usage.get("total_tokens") or 0)
    if total_tokens <= 0:
        total_tokens = int(usage.get("prompt_tokens") or 0) + int(usage.get("completion_tokens") or 0)

    cost_value = usage.get("cost")
    if cost_value is None:
        cost_value = chunk.get("cost")
    if cost_value is None and isinstance(usage.get("cost_details"), dict):
        details = usage.get("cost_details") or {}
        cost_value = details.get("upstream_inference_cost") or details.get("cost") or details.get("total_cost")

    try:
        cost = float(cost_value or 0.0)
    except (TypeError, ValueError):
        cost = 0.0
    return total_tokens, cost


def _to_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _to_float(value: Any) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _normalize_usage_schema(raw: Any) -> Dict[str, Any]:
    """Normalize provider-specific usage payloads into a stable CLI schema."""
    usage = raw if isinstance(raw, dict) else {}
    prompt_tokens = _to_int(
        usage.get("prompt_tokens")
        or usage.get("input_tokens")
        or usage.get("input")
        or usage.get("prompt")
    )
    completion_tokens = _to_int(
        usage.get("completion_tokens")
        or usage.get("output_tokens")
        or usage.get("output")
        or usage.get("completion")
    )
    cache_read = _to_int(
        usage.get("cache_read_tokens")
        or usage.get("cache_read")
        or usage.get("cacheRead")
    )
    cache_write = _to_int(
        usage.get("cache_write_tokens")
        or usage.get("cache_write")
        or usage.get("cacheWrite")
    )
    total = _to_int(usage.get("total_tokens") or usage.get("total"))
    if total <= 0:
        total = prompt_tokens + completion_tokens
    cost = _to_float(
        usage.get("cost_usd")
        or usage.get("costUsd")
        or usage.get("cost")
        or usage.get("total_cost")
    )
    if cost <= 0.0 and isinstance(usage.get("cost_details"), dict):
        details = usage.get("cost_details") or {}
        cost = _to_float(
            details.get("upstream_inference_cost")
            or details.get("cost")
            or details.get("total_cost")
        )
    return {
        "input": prompt_tokens,
        "output": completion_tokens,
        "cacheRead": cache_read,
        "cacheWrite": cache_write,
        "total": total,
        "costUsd": round(cost, 8),
    }


def _sum_usage_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0, "total": 0, "costUsd": 0.0}
    for row in rows:
        usage = row.get("usage")
        if not isinstance(usage, dict):
            continue
        total["input"] += _to_int(usage.get("input"))
        total["output"] += _to_int(usage.get("output"))
        total["cacheRead"] += _to_int(usage.get("cacheRead"))
        total["cacheWrite"] += _to_int(usage.get("cacheWrite"))
        total["total"] += _to_int(usage.get("total"))
        total["costUsd"] += _to_float(usage.get("costUsd"))
    total["costUsd"] = round(total["costUsd"], 8)
    return total


def _status_code_from_exception(exc: Exception) -> Optional[int]:
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code
    response = getattr(exc, "response", None)
    response_code = getattr(response, "status_code", None)
    if isinstance(response_code, int):
        return response_code
    return None


def _extract_error_detail(resp: httpx.Response) -> str:
    """Best-effort extraction of a human-readable error detail from an HTTP response."""
    try:
        payload = resp.json()
    except Exception:
        payload = None

    if isinstance(payload, dict):
        detail = payload.get("detail")
        if isinstance(detail, dict):
            msg = detail.get("message") or detail.get("reason") or detail.get("error")
            if msg:
                return str(msg)
            return str(detail)
        if detail is not None:
            return str(detail)
        err = payload.get("error")
        if isinstance(err, dict):
            msg = err.get("message") or err.get("detail") or err.get("raw")
            if msg:
                return str(msg)
            return str(err)
        if err is not None:
            return str(err)
        msg = payload.get("message")
        if msg is not None:
            return str(msg)
    elif payload is not None:
        return str(payload)

    text = getattr(resp, "text", "") or ""
    return str(text).strip()[:500]


def _extract_error_contract(error: Any, *, status_code: Optional[int] = None) -> Dict[str, Any]:
    """Normalize heterogeneous provider errors into a stable contract."""
    message = ""
    provider = ""
    error_code = ""
    status: Optional[int] = status_code
    retryable: Optional[bool] = None

    if isinstance(error, dict):
        message = str(
            error.get("error")
            or error.get("message")
            or error.get("detail")
            or ""
        )
        provider = str(error.get("provider") or error.get("provider_name") or "")
        error_code = str(error.get("error_code") or error.get("code") or "")
        status_val = error.get("http_status") or error.get("status_code") or error.get("status")
        try:
            if status_val is not None:
                status = int(status_val)
        except (TypeError, ValueError):
            pass
        if "retryable" in error:
            retryable = bool(error.get("retryable"))
    elif isinstance(error, Exception):
        message = str(error)
        if status is None:
            status = _status_code_from_exception(error)
    else:
        message = str(error or "")

    if not message:
        message = "Unknown model failure"

    if status is None:
        m = re.search(r"\b(?:error code|http)\s*[:=]?\s*(\d{3})\b", message, re.IGNORECASE)
        if m:
            try:
                status = int(m.group(1))
            except (TypeError, ValueError):
                status = None

    if not provider:
        m = re.search(
            r"(?:provider_name|provider)[\"']?\s*[:=]\s*[\"']([^\"'}\],]+)",
            message,
            re.IGNORECASE,
        )
        if m:
            provider = m.group(1).strip()

    low = message.lower()
    if retryable is None:
        retryable = False
        if status in RETRYABLE_STATUS_CODES or status == 423:
            retryable = True
        elif any(
            token in low
            for token in (
                "timeout",
                "timed out",
                "temporarily",
                "rate-limited",
                "rate limited",
                "server error",
                "internal server error",
                "connection failed",
                "stream interrupted",
                "already streaming",
            )
        ):
            retryable = True

    if not error_code:
        if status is not None:
            error_code = f"http_{status}"
        elif retryable:
            error_code = "transient_error"
        else:
            error_code = "unknown_error"

    return {
        "error": message,
        "error_code": error_code,
        "http_status": status,
        "provider": provider or None,
        "retryable": bool(retryable),
    }


def _is_endpoint_not_deployed_error(exc: Exception) -> bool:
    """Return True when an API exception indicates missing endpoint support."""
    status = _status_code_from_exception(exc)
    return status in {404, 405}


def _sanitize_history(history: Optional[list]) -> List[Dict[str, str]]:
    """Normalize and repair outgoing transcript history before API calls."""
    cleaned, _ = sanitize_transcript_messages(list(history or []))
    return cleaned


_DIFF_SYSTEM_PROMPT = (
    "You are a code assistant running in a CLI terminal. "
    "When the user asks you to modify, edit, fix, refactor, or write code, "
    "ALWAYS respond with a unified diff (--- / +++ / @@ format). "
    "Do NOT output the full file — only the diff of what changed. "
    "For non-code questions (explanations, debugging help, general questions), "
    "respond normally but keep answers concise and terminal-friendly."
)

# Retry configuration
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds (legacy, kept for any callers)
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _backoff_delay(attempt: int, base_ms: int = 200, max_ms: int = 2000) -> float:
    """Base 200ms, doubles each attempt, caps at 2s, jitter ±10%."""
    import random
    delay = min(base_ms * (2 ** attempt), max_ms) / 1000
    return delay * (0.9 + random.random() * 0.2)


def _is_retryable(status_code: int) -> bool:
    return status_code in RETRYABLE_STATUS_CODES


class APIError(Exception):
    """Raised when an API call fails after all retries."""

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class OfflineError(Exception):
    """Raised when the API is unreachable."""
    pass


class ChatLockedError(APIError):
    """Raised when a chat is already streaming in another session."""

    def __init__(self, chat_id: str, message: str = "Chat is already streaming in another session."):
        super().__init__(message, status_code=423)
        self.chat_id = chat_id


class ModelUnavailableError(APIError):
    """Raised when a chosen model is invalid or currently unroutable."""

    def __init__(self, model: str, message: str, status_code: int):
        super().__init__(message, status_code=status_code)
        self.model = model


async def _retry_request(
    fn,
    *,
    retries: int = MAX_RETRIES,
    backoff: float = RETRY_BACKOFF_BASE,
) -> httpx.Response:
    """Execute an HTTP request with exponential backoff retry on transient errors.

    Retries up to 2 times (3 total attempts) on retryable status codes
    (429, 500, 502, 503, 504).  Non-retryable errors (400, 401, 403, 404, etc.)
    fail immediately without retrying.  Backoff starts at 200ms, doubles each
    attempt, caps at 2s, with ±10% jitter to spread thundering-herd load.
    """
    last_exc = None
    for attempt in range(retries):
        try:
            resp = await fn()
            if not _is_retryable(resp.status_code):
                # Non-retryable (includes 4xx client errors) — return immediately
                return resp
            # Retryable status — wait and try again (or raise on last attempt)
            if attempt < retries - 1:
                wait = _backoff_delay(attempt)
                if resp.status_code == 429:
                    # Respect Retry-After header if present
                    retry_after = resp.headers.get("retry-after")
                    if retry_after and retry_after.isdigit():
                        wait = max(wait, int(retry_after))
                await asyncio.sleep(wait)
            else:
                resp.raise_for_status()
        except httpx.ConnectError as e:
            last_exc = OfflineError(f"Cannot connect to API: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(_backoff_delay(attempt))
            else:
                raise last_exc
        except httpx.TimeoutException as e:
            last_exc = OfflineError(f"API request timed out: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(_backoff_delay(attempt))
            else:
                raise last_exc
        except httpx.HTTPStatusError:
            raise
    raise last_exc or APIError("Request failed after retries")


CSRF_COOKIE_NAME = "msapling_csrftoken"
CSRF_HEADER_NAME = "X-CSRF-Token"
CSRF_EXEMPT_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}


def _is_csrf_error(resp: httpx.Response) -> bool:
    """Return True when a 403 response is a CSRF validation failure (not a permissions error)."""
    if resp.status_code != 403:
        return False
    try:
        detail = str(resp.json().get("detail", "")).lower()
        return "csrf" in detail
    except Exception:
        reason = resp.headers.get("x-ms-debug-reason", "").lower()
        return "csrf" in reason


class MSaplingClient:
    """Async HTTP client for MSapling backend with retry and offline support."""

    def __init__(self, api_url: Optional[str] = None, token: Optional[str] = None, diff_mode: bool = False):
        settings = get_settings()
        self.api_url = (api_url or settings.api_url).rstrip("/")
        self.token = token or get_token()
        self.diff_mode = diff_mode  # Only inject diff system prompt when explicitly enabled
        self._client: Optional[httpx.AsyncClient] = None
        self._chat_cache: Dict[Tuple[str, str, str], str] = {}
        self._client_type: str = self._normalize_client_type(os.environ.get("MSAPLING_CLIENT_TYPE"))
        _env_session_id = self._normalize_session_id(os.environ.get("MSAPLING_SESSION_ID"))
        self._session_id: str = _env_session_id or uuid.uuid4().hex[:16]

    @staticmethod
    def _normalize_client_type(raw: Optional[str]) -> str:
        value = str(raw or "").strip().lower()
        if value in {"cli", "web", "app"}:
            return value
        return "cli"

    @staticmethod
    def _normalize_session_id(raw: Optional[str]) -> str:
        return str(raw or "").strip()[:128]

    def set_session_id(self, session_id: Optional[str]) -> None:
        normalized = self._normalize_session_id(session_id)
        if normalized:
            self._session_id = normalized

    def _surface_headers(self) -> Dict[str, str]:
        client_type = self._normalize_client_type(getattr(self, "_client_type", None))
        session_id = self._normalize_session_id(getattr(self, "_session_id", None))
        if not session_id:
            session_id = uuid.uuid4().hex[:16]
            self._session_id = session_id
        self._client_type = client_type
        return {
            "X-Client-Type": client_type,
            "X-Session-ID": session_id,
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers = {"Content-Type": "application/json", **self._surface_headers()}
            cookies = {}
            if self.token:
                cookies["msaplingauth"] = self.token
            self._client = httpx.AsyncClient(
                base_url=self.api_url,
                headers=headers,
                cookies=cookies,
                timeout=httpx.Timeout(
                    connect=10.0,
                    read=180.0,   # Long reads for streaming (3 min)
                    write=10.0,
                    pool=10.0,
                ),
            )
            # Bootstrap CSRF token from /health endpoint (double-submit cookie pattern)
            await self._refresh_csrf_token()
            # Apply any pending CSRF token from a prior login response
            pending = getattr(self, "_pending_csrf", None)
            if pending:
                self._client.headers[CSRF_HEADER_NAME] = pending
                self._pending_csrf = None
        return self._client

    async def _refresh_csrf_token(self) -> Optional[str]:
        """Fetch a fresh CSRF token from /health and store it on the client headers and cookies.

        Backend uses double-submit cookie pattern:
          - Cookie name: msapling_csrftoken
          - Header name: X-CSRF-Token
          Both must match for POST/PUT/DELETE to succeed.
        Returns the token string, or None if the server is unreachable.
        """
        if self._client is None or self._client.is_closed:
            return None
        try:
            health = await self._client.get("/health")
            # Token may appear in the response cookie or the X-CSRF-Token header
            csrf = (
                health.cookies.get(CSRF_COOKIE_NAME)
                or self._client.cookies.get(CSRF_COOKIE_NAME)
                or health.headers.get(CSRF_HEADER_NAME)
            )
            if csrf:
                self._client.headers[CSRF_HEADER_NAME] = csrf
                return csrf
        except Exception:
            pass  # Offline — CSRF will be missing but local read-only commands still work
        return None

    async def _request(self, method: str, path: str, **kwargs) -> "httpx.Response":
        """Generic authenticated request."""
        client = await self._get_client()
        settings = get_settings()
        base = (settings.api_url or "https://api.msapling.com").rstrip("/")
        url = f"{base}{path}"
        token = get_token()
        headers = {**self._surface_headers(), **kwargs.pop("headers", {})}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        csrf = await self._refresh_csrf_token()
        if csrf and method.upper() not in ("GET", "HEAD"):
            headers["X-CSRF-Token"] = csrf
        resp = await client.request(method, url, headers=headers, **kwargs)
        return resp

    async def _request_with_csrf_retry(self, fn) -> httpx.Response:
        """Execute a mutating request (POST/PUT/DELETE) with automatic CSRF retry.

        If the server returns 403 with a CSRF-related detail, re-fetches the
        CSRF token from /health and retries the request exactly once.  This
        covers the case where the cookie was missing or expired on the first try.
        """
        resp = await _retry_request(fn)
        if _is_csrf_error(resp):
            cli_logger.debug("CSRF token rejected — refreshing and retrying")
            await self._refresh_csrf_token()
            resp = await _retry_request(fn)
        return resp

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def create_temporary_chat(
        self,
        model: str,
        *,
        project_name: str = DEFAULT_PROJECT_NAME,
        title: str = "CLI Temp Chat",
        client_type: str = "cli-temp",
    ) -> Optional[str]:
        """Create a best-effort server-side chat for flows that need a valid chat id."""
        if not self.token:
            return None
        try:
            return await self.ensure_server_chat(
                project_name=project_name,
                title=title,
                model=model,
                client_type=client_type,
                reuse=False,
            )
        except Exception:
            return None

    async def ensure_server_chat(
        self,
        *,
        project_name: str = DEFAULT_PROJECT_NAME,
        title: str = "CLI Chat",
        model: str = "",
        client_type: str = "cli",
        reuse: bool = True,
    ) -> str:
        """Create or reuse a real server-side chat id for CLI flows.

        Falls back to any existing chat in the project if the project is at chat limit.
        """
        resolved_project = str(project_name or DEFAULT_PROJECT_NAME).strip() or DEFAULT_PROJECT_NAME
        cache_key = (resolved_project, title, client_type)
        if reuse:
            cached = self._chat_cache.get(cache_key)
            if cached:
                return cached
            with suppress(Exception):
                existing_chats = await self.list_project_chats(resolved_project)
                # Check both "title" and "slot_label" — backend returns slot_label
                exact_match = next(
                    (
                        chat for chat in existing_chats
                        if (
                            str(chat.get("title") or chat.get("slot_label") or "").strip() == title
                            and str(chat.get("id") or "").strip()
                        )
                    ),
                    None,
                )
                if exact_match:
                    chat_id = str(exact_match.get("id") or "").strip()
                    if chat_id:
                        self._chat_cache[cache_key] = chat_id
                        return chat_id
        try:
            result = await self.create_chat(
                project_name=resolved_project,
                title=title,
                model=model,
                client_type=client_type,
            )
            chat_id = str(result.get("chat_id") or "").strip()
            if not chat_id:
                raise APIError(f"Backend did not return a chat_id for project '{resolved_project}'.")
            if reuse:
                self._chat_cache[cache_key] = chat_id
            return chat_id
        except Exception as create_err:
            # If project cap blocks a non-default project (e.g. CLI Utility),
            # fall back to Default Project so one-shot CLI commands still work.
            err_str = str(create_err).lower()
            status_code = (
                create_err.response.status_code
                if isinstance(create_err, httpx.HTTPStatusError) and create_err.response is not None
                else None
            )
            if (
                resolved_project != DEFAULT_PROJECT_NAME
                and (
                    "project limit" in err_str
                    or "project limit reached" in err_str
                    or status_code == 403
                )
            ):
                with suppress(Exception):
                    return await self.ensure_server_chat(
                        project_name=DEFAULT_PROJECT_NAME,
                        title=title,
                        model=model,
                        client_type=client_type,
                        reuse=reuse,
                    )
            # If chat limit reached, fall back to an existing chat.
            # Use a round-robin index so concurrent callers get different chats.
            if "chat limit" in err_str or "403" in err_str:
                with suppress(Exception):
                    existing_chats = await self.list_project_chats(resolved_project)
                    valid_ids = [
                        str(c.get("id") or "").strip()
                        for c in existing_chats
                        if str(c.get("id") or "").strip()
                    ]
                    if valid_ids:
                        # Pick a slot based on how many fallbacks have already been assigned
                        already_assigned = set(self._chat_cache.values())
                        # Prefer a chat not yet assigned to another active key
                        for cid in valid_ids:
                            if cid not in already_assigned:
                                self._chat_cache[cache_key] = cid
                                return cid
                        # All assigned — pick by index derived from cache_key hash
                        idx = hash(cache_key) % len(valid_ids)
                        fallback_id = valid_ids[idx]
                        self._chat_cache[cache_key] = fallback_id
                        return fallback_id
            raise

    async def ensure_utility_chat(self, model: Optional[str] = None) -> str:
        """Get or create the reusable CLI utility chat for one-shot commands.

        Uses a dedicated 'CLI Utility' project separate from user-visible projects.
        All headless/one-shot flows share this chat to avoid polluting Default Project.
        """
        resolved_model = str(model or get_settings().default_model or "").strip()
        if not resolved_model:
            resolved_model = "google/gemini-2.0-flash-001"
        model_short = resolved_model.split("/")[-1] if "/" in resolved_model else resolved_model
        title = f"CLI Utility — {model_short}"
        return await self.ensure_server_chat(
            project_name=CLI_UTILITY_PROJECT_NAME,
            title=title,
            model=resolved_model,
            client_type="cli-utility",
            reuse=True,
        )

    async def ensure_ollama_chat(self, model: str, ollama_url: Optional[str] = None) -> str:
        """Prepare an Ollama-specific chat session identifier.

        For Ollama (local inference), no server-side ChatSession is needed —
        the CLI streams directly to the Ollama API.  This method returns a
        synthetic chat ID and records the Ollama URL in the environment so
        ``stream_chat`` can forward ``X-Ollama-Url`` if the flow routes through
        the MSapling backend.

        Args:
            model:      Model identifier (with or without ``ollama/`` prefix).
            ollama_url: Optional Ollama base URL override.

        Returns:
            A synthetic Ollama chat ID string (``"ollama-local-<model_name>"``).
        """
        bare = model.replace("ollama/", "").strip()
        if ollama_url:
            import os as _os
            _os.environ["MSAPLING_OLLAMA_URL"] = str(ollama_url).rstrip("/")
        model_id = f"ollama/{bare}" if not model.lower().startswith("ollama/") else model
        return f"ollama-local-{bare}"

    async def health_check(self) -> bool:
        """Check if API is reachable. Returns False if offline."""
        try:
            client = await self._get_client()
            resp = await asyncio.wait_for(client.get("/health"), timeout=15.0)
            return resp.status_code == 200
        except Exception:
            return False

    # --- Auth ---

    async def login(self, email: str, password: str) -> Dict[str, Any]:
        client = await self._get_client()
        # Step 1: GET /health to obtain CSRF cookie (double-submit pattern)
        csrf_token = await self._refresh_csrf_token()
        if not csrf_token:
            csrf_token = client.cookies.get(CSRF_COOKIE_NAME)
        # Step 2: POST /auth/login with CSRF header
        # /auth/login is CSRF-exempt on the backend but we include the header
        # anyway to stay consistent with the double-submit contract.
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        if csrf_token:
            headers[CSRF_HEADER_NAME] = csrf_token
        resp = await _retry_request(lambda: client.post(
            "/auth/login",
            data={"username": email, "password": password},
            headers=headers,
        ))
        resp.raise_for_status()
        # Extract auth cookie from login response
        token = resp.cookies.get("msaplingauth") or client.cookies.get("msaplingauth")
        # Extract CSRF token from login response BEFORE nulling _client,
        # so we can apply it to the newly-created client after reconnect.
        new_csrf = (
            resp.cookies.get(CSRF_COOKIE_NAME)
            or resp.headers.get(CSRF_HEADER_NAME)
        )
        if token:
            self.token = token
            self._client = None  # Force reconnect so new auth cookie is picked up
        # Apply the new CSRF token to the (possibly-new) client
        if new_csrf:
            self._pending_csrf = new_csrf  # Applied in _get_client() on next call
        return resp.json()

    async def get(self, path: str) -> Dict[str, Any]:
        """Generic authenticated GET — returns parsed JSON dict.

        Useful for one-off reads of any backend endpoint without needing a
        dedicated wrapper method.  Raises on non-2xx status.
        """
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(path))
        resp.raise_for_status()
        return resp.json()

    async def me(self) -> Dict[str, Any]:
        return await self.get("/users/me")

    async def get_active_streams(self) -> Dict[str, Any]:
        """Return account-wide active stream state for the authenticated user."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/chat/active-streams"))
        resp.raise_for_status()
        data = resp.json()
        if not isinstance(data, dict):
            raise APIError("Malformed /api/chat/active-streams response.", status_code=500)
        if not isinstance(data.get("active_streams"), list):
            data["active_streams"] = []
        if not isinstance(data.get("active_chat_ids"), list):
            data["active_chat_ids"] = []
        return data

    async def get_project_settings(self, project_name: str) -> Dict[str, Any]:
        """Fetch server-side project settings (mdrive_enabled, tools_web_research, etc.).

        Returns the ``settings`` dict from ``GET /api/projects/{name}/settings``.
        Falls back to an empty dict if the endpoint is unreachable so callers can
        apply their own defaults without crashing.
        """
        try:
            client = await self._get_client()
            from urllib.parse import quote
            encoded = quote(str(project_name), safe="")
            resp = await _retry_request(lambda: client.get(f"/api/projects/{encoded}/settings"))
            resp.raise_for_status()
            data = resp.json()
            return data.get("settings", data) if isinstance(data, dict) else {}
        except Exception:
            return {}

    # --- Local Ollama ---

    def _ollama_base_url(self, override: Optional[str] = None) -> str:
        if override:
            return str(override).rstrip("/")
        settings = get_settings()
        return str(getattr(settings, "ollama_base_url", "http://127.0.0.1:11434")).rstrip("/")

    async def ollama_status(self, base_url: Optional[str] = None) -> Dict[str, Any]:
        url = self._ollama_base_url(base_url)
        timeout = httpx.Timeout(connect=5.0, read=20.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(base_url=url, timeout=timeout) as client:
            try:
                version_resp = await client.get("/api/version")
                version_resp.raise_for_status()
                version_data = version_resp.json() if isinstance(version_resp.json(), dict) else {}
            except Exception as exc:
                raise OfflineError(f"Ollama unavailable at {url}: {exc}") from exc
            tags_resp = await client.get("/api/tags")
            tags_resp.raise_for_status()
            tags_data = tags_resp.json() if isinstance(tags_resp.json(), dict) else {}
            models = tags_data.get("models", []) if isinstance(tags_data.get("models", []), list) else []
            return {
                "connected": True,
                "base_url": url,
                "version": str(version_data.get("version", "unknown")),
                "models": models,
            }

    async def ollama_models(self, base_url: Optional[str] = None) -> List[Dict[str, Any]]:
        status = await self.ollama_status(base_url=base_url)
        rows: List[Dict[str, Any]] = []
        for row in status.get("models", []):
            name = str(row.get("name", "")).strip()
            if not name:
                continue
            details = row.get("details", {}) if isinstance(row.get("details"), dict) else {}
            rows.append({
                "id": f"ollama/{name}",
                "name": name,
                "provider": "ollama",
                "context_length": details.get("parameter_size", "local"),
                "size": row.get("size", 0),
                "modified_at": row.get("modified_at", ""),
                "price_in": 0.0,
                "price_out": 0.0,
            })
        return rows

    async def ollama_pull(self, model_name: str, base_url: Optional[str] = None) -> Dict[str, Any]:
        url = self._ollama_base_url(base_url)
        timeout = httpx.Timeout(connect=5.0, read=3600.0, write=30.0, pool=10.0)
        payload = {"name": model_name, "stream": False}
        async with httpx.AsyncClient(base_url=url, timeout=timeout) as client:
            resp = await client.post("/api/pull", json=payload)
            resp.raise_for_status()
            data = resp.json() if isinstance(resp.json(), dict) else {}
            return data

    async def _stream_chat_ollama(
        self,
        *,
        prompt: str,
        model: str,
        history: Optional[list] = None,
        temperature: Optional[float] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        url = self._ollama_base_url()
        model_name = _extract_ollama_model_name(model)
        if not model_name:
            raise APIError("Invalid Ollama model id. Use ollama/<model-name>.")

        messages: List[Dict[str, str]] = []
        for msg in _sanitize_history(history):
            role = str(msg.get("role") or "user").strip().lower()
            if role not in {"system", "user", "assistant"}:
                role = "user"
            content = str(msg.get("content") or "")
            if content:
                messages.append({"role": role, "content": content})
        messages.append({"role": "user", "content": prompt})

        payload: Dict[str, Any] = {"model": model_name, "messages": messages, "stream": True}
        if temperature is not None:
            payload["options"] = {"temperature": float(temperature)}

        timeout = httpx.Timeout(connect=5.0, read=3600.0, write=30.0, pool=10.0)
        async with httpx.AsyncClient(base_url=url, timeout=timeout) as local:
            async with local.stream("POST", "/api/chat", json=payload) as resp:
                if resp.status_code >= 400:
                    body = await resp.aread()
                    detail = body.decode("utf-8", errors="ignore")[:400]
                    raise APIError(f"Ollama chat failed ({resp.status_code}): {detail}", status_code=resp.status_code)

                buffer = ""
                async for chunk in resp.aiter_text():
                    buffer += chunk
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                        except json.JSONDecodeError:
                            continue

                        if isinstance(data, dict) and data.get("error"):
                            raise APIError(f"Ollama error: {data.get('error')}")

                        message_obj = data.get("message", {}) if isinstance(data, dict) else {}
                        content = message_obj.get("content", "") if isinstance(message_obj, dict) else ""
                        if content:
                            yield {"content": str(content)}

                        if bool(data.get("done")):
                            prompt_tokens = int(data.get("prompt_eval_count") or 0)
                            completion_tokens = int(data.get("eval_count") or 0)
                            usage = {
                                "prompt_tokens": prompt_tokens,
                                "completion_tokens": completion_tokens,
                                "total_tokens": prompt_tokens + completion_tokens,
                            }
                            yield {"type": "usage", "usage": usage, "cost": 0.0}

                if buffer.strip():
                    try:
                        data = json.loads(buffer.strip())
                        if isinstance(data, dict):
                            message_obj = data.get("message", {}) if isinstance(data.get("message"), dict) else {}
                            content = message_obj.get("content", "")
                            if content:
                                yield {"content": str(content)}
                    except json.JSONDecodeError:
                        pass

    # --- Chat ---

    async def stream_chat(
        self,
        chat_id: str,
        prompt: str,
        model: str,
        *,
        project_name: Optional[str] = None,
        history: Optional[list] = None,
        agent_mode: bool = False,
        attached_files: Optional[List[Dict[str, Any]]] = None,
        temperature: Optional[float] = None,
        history_enabled: bool = True,
        transient: bool = False,
        bypass_diff_mode: bool = False,
        permission_context: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Stream chat response as NDJSON chunks."""
        normalized_model = _normalize_ollama_model_id(model)
        if _is_ollama_model(normalized_model):
            async for chunk in self._stream_chat_ollama(
                prompt=prompt,
                model=normalized_model,
                history=history,
                temperature=temperature,
            ):
                yield chunk
            return

        client = await self._get_client()
        messages = _sanitize_history(history)
        # diff_mode is now handled server-side (backend/routers/chat.py:1287-1292)
        # from User.diff_mode_enabled. Do NOT inject client-side to avoid double injection.
        payload = {
            "chat_id": chat_id,
            "prompt": prompt,
            "model": normalized_model,
            "project_name": project_name or "",
            "messages": messages,
            "agent_mode": agent_mode,
            "history_enabled": history_enabled,
            "permission_context": permission_context,
        }
        if transient:
            payload["transient"] = True
        if bypass_diff_mode:
            payload["bypass_diff_mode"] = True
        if attached_files:
            payload["attached_files"] = attached_files
        if temperature is not None:
            payload["temperature"] = temperature
        # When provider=ollama, pass X-Ollama-Url so the backend OllamaProvider
        # can resolve the correct local endpoint (from --ollama-url CLI flag).
        _extra_headers: Dict[str, str] = self._surface_headers()
        _ollama_url_env = os.environ.get("MSAPLING_OLLAMA_URL", "")
        _provider_env = os.environ.get("MSAPLING_PROVIDER", "")
        if _provider_env == "ollama" and _ollama_url_env:
            _extra_headers["X-Ollama-Url"] = _ollama_url_env
        async with client.stream(
            "POST", "/api/chat/message", json=payload, headers=_extra_headers
        ) as resp:
            if resp.status_code == 423:
                detail = "Chat is already streaming in another session."
                try:
                    raw = await resp.aread()
                    if raw:
                        parsed = json.loads(raw.decode("utf-8", errors="ignore"))
                        if isinstance(parsed, dict):
                            parsed_detail = parsed.get("detail")
                            if isinstance(parsed_detail, dict):
                                detail = str(parsed_detail.get("message") or parsed_detail.get("reason") or detail)
                            elif parsed_detail:
                                detail = str(parsed_detail)
                except Exception:
                    pass
                raise ChatLockedError(chat_id, detail)
            if resp.status_code == 402:
                # Preserve response body so the caller can distinguish
                # tier-gated model (free plan) from credit exhaustion.
                detail = ""
                try:
                    raw = await resp.aread()
                    if raw:
                        parsed = json.loads(raw.decode("utf-8", errors="ignore"))
                        if isinstance(parsed, dict):
                            detail = str(parsed.get("detail") or parsed.get("message") or "")
                except Exception:
                    pass
                # Raise a typed exception so _handle_api_error can choose the
                # right message without re-parsing a generic HTTPStatusError string.
                raise APIError(
                    f"402:{detail}" if detail else "402",
                    status_code=402,
                )
            if resp.status_code == 429:
                detail = ""
                try:
                    raw = await resp.aread()
                    if raw:
                        parsed = json.loads(raw.decode("utf-8", errors="ignore"))
                        if isinstance(parsed, dict):
                            parsed_detail = parsed.get("detail")
                            if isinstance(parsed_detail, dict):
                                detail = str(parsed_detail.get("message") or parsed_detail.get("reason") or "")
                            elif parsed_detail:
                                detail = str(parsed_detail)
                            elif parsed.get("message"):
                                detail = str(parsed.get("message"))
                except Exception:
                    detail = ""
                raise APIError(
                    f"429:{detail}" if detail else "429",
                    status_code=429,
                )
            if resp.status_code in (400, 404):
                detail = ""
                try:
                    raw = await resp.aread()
                    if raw:
                        parsed = json.loads(raw.decode("utf-8", errors="ignore"))
                        if isinstance(parsed, dict):
                            error_obj = parsed.get("error") if isinstance(parsed.get("error"), dict) else {}
                            detail = str(error_obj.get("message") or parsed.get("detail") or "")
                except Exception:
                    detail = ""
                lowered = detail.lower()
                if "not a valid model id" in lowered or "no endpoints found" in lowered:
                    raise ModelUnavailableError(normalized_model, detail or f"Model unavailable: {normalized_model}", resp.status_code)
            resp.raise_for_status()
            buffer = ""
            try:
                async for chunk in resp.aiter_text():
                    if len(buffer) > 10 * 1024 * 1024:  # 10MB limit
                        raise RuntimeError("Stream buffer exceeded 10MB limit")
                    buffer += chunk
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if line:
                            try:
                                yield json.loads(line)
                            except json.JSONDecodeError:
                                continue
            except (httpx.RemoteProtocolError, httpx.ReadError, RuntimeError) as e:
                # Stream interrupted or buffer exceeded - yield error so caller can show partial content
                yield {"type": "error", "error": f"Stream interrupted: {e}", "partial": True}
            if buffer.strip():
                try:
                    yield json.loads(buffer.strip())
                except json.JSONDecodeError:
                    pass

    async def get_models(self) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/chat/models"))
        resp.raise_for_status()
        data = resp.json()
        models = data if isinstance(data, list) else data.get("models", data.get("data", []))
        if not isinstance(models, list):
            models = []

        # Merge local Ollama models when configured so CLI can surface local
        # model IDs in the same list as cloud models.
        settings = get_settings()
        if bool(getattr(settings, "ollama_enabled", True)):
            try:
                local_models = await self.ollama_models()
                seen = {str(m.get("id", "")).strip() for m in models if isinstance(m, dict)}
                for m in local_models:
                    mid = str(m.get("id", "")).strip()
                    if mid and mid not in seen:
                        models.append(m)
                        seen.add(mid)
            except Exception:
                pass
        return models

    # --- Projects ---

    async def list_projects(self) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/"))
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            projects = data.get("projects", data)
            if isinstance(projects, list):
                return projects
            if isinstance(projects, dict):
                return _normalize_legacy_projects_list(data)
        return []

    async def projects_overview(self, user: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Get projects with chat counts and limits. Used by CLI startup."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/overview"))
        if resp.status_code in (404, 405):
            current_user = user
            if current_user is None:
                try:
                    current_user = await self.me()
                except Exception:
                    current_user = {}
            legacy_resp = await _retry_request(lambda: client.get("/api/projects/"))
            legacy_resp.raise_for_status()
            return _normalize_legacy_projects_overview(legacy_resp.json(), current_user)
        resp.raise_for_status()
        return resp.json()

    async def create_project(self, name: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/projects/", json={
            "project_name": name,
        }))
        resp.raise_for_status()
        return resp.json()

    async def create_chat(
        self, project_name: str, title: str = "CLI Chat",
        model: str = "", client_type: str = "cli",
        hidden: bool = False,
    ) -> Dict[str, Any]:
        client = await self._get_client()
        payload: Dict[str, Any] = {
            "project_name": project_name,
            "slot_label": title,
            "model": model or get_settings().default_model,
            "client_type": client_type,
        }
        if hidden:
            payload["hidden"] = True
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/projects/chat/new", json=payload))
        resp.raise_for_status()
        return resp.json()

    async def list_project_chats(self, project_name: str) -> List[Dict[str, Any]]:
        """Get chats for a specific project."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/projects/", params={
            "limit": 100,
        }))
        resp.raise_for_status()
        data = resp.json()
        projects = data if isinstance(data, dict) else {}
        if isinstance(data, dict) and "projects" in data:
            projects = data["projects"]
        proj_data = projects.get(project_name, {})
        return proj_data.get("chats", [])

    async def delete_chat(self, chat_id: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(
            lambda: client.request("DELETE", f"/api/projects/chat/{chat_id}")
        )
        resp.raise_for_status()
        # Invalidate _chat_cache entries that point to the deleted chat
        self._chat_cache = {
            k: v for k, v in self._chat_cache.items() if v != chat_id
        }
        return resp.json()

    # --- Multi-Chat / Swarm ---

    async def chat_once(
        self,
        prompt: str,
        model: str,
        history: Optional[list] = None,
        history_enabled: bool = True,
        project_name: str = CLI_UTILITY_PROJECT_NAME,
        permission_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Non-streaming single-shot chat. Returns full response text.

        Pass history_enabled=False to ignore any server-side chat history
        (useful for isolated one-shot requests like file edits).
        """
        parts = []
        normalized_model = _normalize_ollama_model_id(model)
        if _is_ollama_model(normalized_model):
            async for chunk in self.stream_chat(
                chat_id="ollama-local",
                prompt=prompt,
                model=normalized_model,
                history=history,
                project_name=project_name or DEFAULT_PROJECT_NAME,
                history_enabled=history_enabled,
                permission_context=permission_context,
            ):
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
            return "".join(parts)

        resolved_project = str(project_name or "").strip() or DEFAULT_PROJECT_NAME
        temp_chat_id = await self.create_temporary_chat(
            normalized_model,
            project_name=resolved_project,
        )
        if not temp_chat_id:
            raise APIError("Failed to create a server chat for this request.")
        try:
            async for chunk in self.stream_chat(
                chat_id=temp_chat_id,
                prompt=prompt,
                model=normalized_model,
                history=history,
                project_name=resolved_project,
                history_enabled=history_enabled,
            ):
                content = chunk.get("content", "")
                if content:
                    parts.append(content)
            return "".join(parts)
        finally:
            if temp_chat_id:
                with suppress(Exception):
                    await self.delete_chat(temp_chat_id)

    async def multi_chat(
        self,
        prompt: str,
        models: List[str],
        history: Optional[list] = None,
        permission_context: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Send the same prompt to multiple models using backend fanout endpoint."""
        normalized_models = [_normalize_ollama_model_id(str(m).strip()) for m in models if str(m).strip()]
        if not normalized_models:
            return []

        payload: Dict[str, Any] = {
            "prompt": prompt,
            "models": normalized_models,
            "max_models": min(max(len(normalized_models), 1), 8),
            "permission_context": permission_context,
        }
        cleaned_history = _sanitize_history(history)
        if cleaned_history:
            payload["history"] = cleaned_history

        try:
            start_ts = time.monotonic()
            resp = await self._request_with_csrf_retry(
                lambda: self._request("POST", "/api/chat/multi", json=payload)
            )
            latency_ms = int((time.monotonic() - start_ts) * 1000)
            if resp.status_code >= 400:
                detail = _extract_error_detail(resp)
                raise APIError(
                    f"{resp.status_code}:{detail}" if detail else f"HTTP {resp.status_code}",
                    status_code=resp.status_code,
                )
            data = resp.json() if resp.content else {}
            raw_results = data.get("responses", []) if isinstance(data, dict) else []
            out: List[Dict[str, Any]] = []
            for item in raw_results:
                if not isinstance(item, dict):
                    continue
                model_id = str(item.get("model") or "")
                err = item.get("error")
                content = str(item.get("content") or item.get("response") or "")
                usage_row = _normalize_usage_schema(
                    item.get("usage")
                    if isinstance(item.get("usage"), dict)
                    else item
                )
                if not err and content.lstrip().startswith("[Provider]"):
                    err = content
                
                res = {
                    "model": model_id,
                    "latency_ms": latency_ms,
                    "attempts": 1,  # Backend currently doesn't surface per-worker attempts
                    "usage": usage_row,
                }
                if err:
                    contract = _extract_error_contract(err)
                    res.update({
                        "response": "",
                        "status": "error",
                        "error": contract["error"],
                        "error_code": contract["error_code"],
                        "http_status": contract["http_status"],
                        "provider": contract["provider"],
                        "retryable": contract["retryable"],
                    })
                else:
                    res.update({
                        "response": content,
                        "status": "ok",
                    })
                out.append(res)
            return out
        except Exception as exc:
            if not _is_endpoint_not_deployed_error(exc):
                raise
            # Backward-compatible fallback for older servers without /api/chat/multi.
            async def _single(model: str) -> Dict[str, Any]:
                worker = MSaplingClient(api_url=self.api_url, token=self.token, diff_mode=self.diff_mode)
                started = time.monotonic()
                try:
                    text = await worker.chat_once(prompt, model, cleaned_history)
                    return {
                        "model": model,
                        "response": text,
                        "status": "ok",
                        "latency_ms": int((time.monotonic() - started) * 1000),
                        "attempts": 1,
                        "usage": _normalize_usage_schema({}),
                    }
                except Exception as e:
                    contract = _extract_error_contract(e)
                    return {
                        "model": model,
                        "response": "",
                        "status": "error",
                        "latency_ms": int((time.monotonic() - started) * 1000),
                        "attempts": 1,
                        "error": contract["error"],
                        "error_code": contract["error_code"],
                        "http_status": contract["http_status"],
                        "provider": contract["provider"],
                        "retryable": contract["retryable"],
                        "usage": _normalize_usage_schema({}),
                    }
                finally:
                    await worker.close()

            results = await asyncio.gather(*[_single(m) for m in normalized_models])
            return list(results)

    async def swarm(
        self,
        prompt: str,
        models: Optional[List[str]] = None,
        synthesize_model: Optional[str] = None,
        permission_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run swarm using backend orchestration endpoint."""
        if models:
            use_models = [_normalize_ollama_model_id(m) for m in models]
        else:
            use_models = [
                _normalize_ollama_model_id(m)
                for m in default_models_from_registry(limit=3)
            ]
        payload: Dict[str, Any] = {
            "prompt": prompt,
            "models": use_models,
            "max_agents": min(max(len(use_models), 1), 8),
            "permission_context": permission_context,
        }
        if synthesize_model:
            payload["judge_model"] = _normalize_ollama_model_id(synthesize_model)

        try:
            start_ts = time.monotonic()
            resp = await self._request_with_csrf_retry(
                lambda: self._request("POST", "/api/chat/swarm", json=payload)
            )
            latency_ms = int((time.monotonic() - start_ts) * 1000)
            if resp.status_code >= 400:
                detail = _extract_error_detail(resp)
                raise APIError(
                    f"{resp.status_code}:{detail}" if detail else f"HTTP {resp.status_code}",
                    status_code=resp.status_code,
                )
            data = resp.json() if resp.content else {}
            raw_agents = data.get("agent_responses", []) if isinstance(data, dict) else []
            formatted_agents: List[Dict[str, Any]] = []
            for item in raw_agents:
                if not isinstance(item, dict):
                    continue
                model_id = str(item.get("model") or "")
                err = item.get("error")
                content = str(item.get("content") or item.get("response") or "")
                usage_row = _normalize_usage_schema(
                    item.get("usage")
                    if isinstance(item.get("usage"), dict)
                    else item
                )
                if not err and content.lstrip().startswith("[Provider]"):
                    err = content
                
                res = {
                    "model": model_id,
                    "latency_ms": latency_ms,
                    "attempts": 1,
                    "usage": usage_row,
                }
                if err:
                    contract = _extract_error_contract(err)
                    res.update({
                        "response": "",
                        "status": "error",
                        "error": contract["error"],
                        "error_code": contract["error_code"],
                        "http_status": contract["http_status"],
                        "provider": contract["provider"],
                        "retryable": contract["retryable"],
                    })
                else:
                    res.update({
                        "response": content,
                        "status": "ok",
                    })
                formatted_agents.append(res)
            
            judge_model = (
                str(data.get("judge_model") or "")
                if isinstance(data, dict)
                else ""
            ) or (synthesize_model or (use_models[0] if use_models else ""))
            models_used = [a.get("model", "") for a in formatted_agents if a.get("model")] or use_models
            return {
                "agent_responses": formatted_agents,
                "synthesis": str(data.get("synthesis") or "") if isinstance(data, dict) else "",
                "judge_model": judge_model,
                "models_used": models_used,
                "latency_ms": latency_ms,
                "usage": _sum_usage_rows(formatted_agents),
            }
        except Exception as exc:
            if not _is_endpoint_not_deployed_error(exc):
                raise
            # Backward-compatible fallback path for older servers.
            start_ts = time.monotonic()
            judge = synthesize_model or use_models[0]
            responses = await self.multi_chat(
                prompt,
                use_models,
                permission_context=permission_context,
            )
            agent_outputs = []
            for r in responses:
                status = "OK" if r["status"] == "ok" else "FAILED"
                agent_outputs.append(f"[{r['model']} - {status}]:\n{r['response'][:2000]}")
            synthesis_prompt = (
                f"You are a synthesis judge. Multiple AI models were asked the same question.\n\n"
                f"Original question: {prompt}\n\n"
                f"Their responses:\n\n" + "\n\n---\n\n".join(agent_outputs) + "\n\n"
                f"Synthesize the best answer. Combine strengths, note disagreements, give a final answer."
            )
            synthesis = await self.chat_once(synthesis_prompt, judge)
            return {
                "agent_responses": responses,
                "synthesis": synthesis,
                "judge_model": judge,
                "models_used": use_models,
                "latency_ms": int((time.monotonic() - start_ts) * 1000),
                "usage": _sum_usage_rows(responses),
            }

    # --- MLineage ---

    async def generate_diff(self, old_content: str, new_content: str, filename: str = "file") -> Dict[str, Any]:
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/mlineage/generate-diff", json={
            "old_content": old_content,
            "new_content": new_content,
            "file_path": filename,
        }))
        resp.raise_for_status()
        return resp.json()

    async def apply_diff(self, original: str, diff_text: str, file_path: str = "file") -> Dict[str, Any]:
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/mlineage/apply-diff", json={
            "original_content": original,
            "diff_text": diff_text,
            "file_path": file_path,
        }))
        resp.raise_for_status()
        return resp.json()

    # --- MDrive ---

    async def list_files(self, project_id: str, path: str = "/") -> list:
        client = await self._get_client()
        scoped_path = _mdrive_scoped_path(project_id, "" if path in ("", "/", ".") else path)
        resp = await _retry_request(lambda: client.get("/api/mdrive/list", params={"path": scoped_path}))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("files", [])

    async def mdrive_read(self, project_id: str, file_path: str) -> str:
        client = await self._get_client()
        payload = {"path": _mdrive_scoped_path(project_id, file_path)}
        resp = await _retry_request(lambda: client.post("/api/mdrive/read", json=payload))
        resp.raise_for_status()
        try:
            return resp.json().get("content", "")
        except Exception:
            raise RuntimeError(
                f"mdrive_read: expected JSON but got {resp.status_code} "
                f"{resp.headers.get('content-type','')}: {resp.text[:200]}"
            )

    # Keep old name as alias
    async def read_file(self, project_id: str, file_path: str) -> str:
        return await self.mdrive_read(project_id, file_path)

    async def mdrive_write(
        self, project_id: str, file_path: str, content: str,
        agent_id: str = "", change_summary: str = "",
    ) -> Dict[str, Any]:
        client = await self._get_client()
        payload: Dict[str, Any] = {
            "path": _mdrive_scoped_path(project_id, file_path),
            "content": content,
        }
        if agent_id:
            payload["agent_id"] = agent_id
        if change_summary:
            payload["change_summary"] = change_summary
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/mdrive/write", json=payload))
        resp.raise_for_status()
        return resp.json()

    # Keep old name as alias
    async def write_file(self, project_id: str, file_path: str, content: str) -> Dict[str, Any]:
        return await self.mdrive_write(project_id, file_path, content)

    async def mdrive_delete(self, project_id: str, file_path: str) -> Dict[str, Any]:
        client = await self._get_client()
        payload = {"path": _mdrive_scoped_path(project_id, file_path)}
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/mdrive/delete", json=payload))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_versions(self, project_id: str, file_path: str) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(
            f"/api/mdrive/versions/{project_id}/{file_path}",
        ))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("versions", [])

    async def mdrive_restore(self, project_id: str, file_path: str, version_id: str = "") -> Dict[str, Any]:
        client = await self._get_client()
        payload: Dict[str, Any] = {"project_id": project_id, "file_path": file_path}
        if version_id:
            payload["version_id"] = version_id
        resp = await self._request_with_csrf_retry(lambda: client.post(
            f"/api/mdrive/restore/{project_id}/{file_path}", json=payload,
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_trash(self, project_id: str) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(f"/api/mdrive/trash/{project_id}"))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("files", [])

    async def mdrive_undelete(self, project_id: str, file_path: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post(
            f"/api/mdrive/undelete/{project_id}/{file_path}",
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_usage(self) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/mdrive/usage"))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_detect_conflict(
        self, project_id: str, file_path: str, base_version: str, content: str,
    ) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post(
            f"/api/mdrive/detect-conflict/{project_id}/{file_path}",
            json={"base_version": base_version, "content": content},
        ))
        resp.raise_for_status()
        return resp.json()

    async def mdrive_search(self, project_id: str, query: str, limit: int = 10) -> list:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.post("/api/mdrive/search", json={
            "project_id": project_id, "query": query, "limit": limit,
        }))
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("results", [])

    # --- MDrive CLI helpers (drive_commands.py) ---

    async def drive_push(self, project: str, files: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Upload a batch of files to a MDrive project.

        ``files`` is a list of dicts: ``{path, content, size?, sha256?}``.
        Returns a summary: ``{uploaded, skipped, errors}``.
        """
        client = await self._get_client()
        payload = {"project": project, "files": files}
        resp = await self._request_with_csrf_retry(
            lambda: client.post("/api/mdrive/push", json=payload)
        )
        if resp.status_code == 404:
            # Endpoint not yet live — fall back to individual writes
            uploaded = 0
            errors = 0
            for f in files:
                try:
                    await self.mdrive_write(project, f["path"], f.get("content", ""))
                    uploaded += 1
                except Exception:
                    errors += 1
            return {"uploaded": uploaded, "skipped": 0, "errors": errors}
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, dict) else {"uploaded": len(files), "skipped": 0, "errors": 0}

    async def drive_pull(self, project: str) -> List[Dict[str, Any]]:
        """Download all files from a MDrive project.

        Returns a list of file dicts: ``{path, content, size, sha256, ...}``.
        Falls back to listing + reading individually if the bulk endpoint is absent.
        """
        client = await self._get_client()
        resp = await _retry_request(
            lambda: client.get("/api/mdrive/pull", params={"project": project})
        )
        if resp.status_code == 404:
            # Fallback: list then read each file
            files_meta = await self.list_files(project)
            result: List[Dict[str, Any]] = []
            for f in files_meta:
                fpath = f.get("path", f.get("name", ""))
                if not fpath:
                    continue
                try:
                    content = await self.mdrive_read(project, fpath)
                    result.append({**f, "content": content})
                except Exception:
                    result.append({**f, "content": ""})
            return result
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("files", [])

    async def drive_ls(self, project: str) -> List[Dict[str, Any]]:
        """List files in a MDrive project with metadata.

        Returns a list of dicts: ``{path, size, updated_at, version, sha256, ...}``.
        """
        return await self.list_files(project)

    async def drive_share(self, project: str, file_path: str, expires_hours: int = 24) -> Any:
        """Create an expiring public share link for a file.

        Returns the share URL string, or a dict with ``{url, token, expires_at}``.
        Raises ``APIError`` on failure.
        """
        client = await self._get_client()
        payload = {
            "project_id": project,
            "file_path": file_path,
            "expires_hours": max(1, min(int(expires_hours), 168)),
        }
        resp = await self._request_with_csrf_retry(
            lambda: client.post("/api/mdrive/share", json=payload)
        )
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, dict):
            token = data.get("token", "")
            share_path = data.get("share_path", f"/api/mdrive/share/{token}")
            # Construct absolute URL from api_url
            base = self.api_url.rstrip("/")
            url = f"{base}{share_path}" if share_path.startswith("/") else share_path
            return {
                "url": url,
                "token": token,
                "expires_at": data.get("expires_at", ""),
                "expires_hours": data.get("expires_hours", expires_hours),
            }
        return str(data)

    # --- Chat Context / Summary ---

    async def get_chat_history(self, chat_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Fetch server-side chat history (includes Layer 0/1/2 compressed context)."""
        client = await self._get_client()
        routes = [
            f"/api/projects/chat/{chat_id}/history",
            f"/api/chat/history/{chat_id}",
        ]
        last_error: Optional[Exception] = None
        for route in routes:
            try:
                resp = await _retry_request(lambda route=route: client.get(route, params={"limit": limit}))
                if resp.status_code == 404:
                    continue
                resp.raise_for_status()
                data = resp.json()
                return data if isinstance(data, list) else data.get("messages", data.get("history", []))
            except httpx.HTTPStatusError as exc:
                if exc.response is not None and exc.response.status_code == 404:
                    last_error = exc
                    continue
                raise
        if last_error:
            raise last_error
        return []

    async def set_chat_model(self, chat_id: str, model: str) -> Dict[str, Any]:
        """Persist a model switch to an existing project chat when supported."""
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(
            lambda: client.patch(f"/api/projects/chat/{chat_id}/model", json={"model": model})
        )
        resp.raise_for_status()
        return resp.json()

    async def get_chat_settings(self, chat_id: str) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(f"/api/chat/settings/{chat_id}"))
        resp.raise_for_status()
        return resp.json()

    async def get_context_stats(self, chat_id: str) -> Dict[str, Any]:
        """Fetch summary layer stats for a chat (blocks, sagas, token estimates)."""
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get(
            f"/api/chat/settings/{chat_id}/token-usage",
        ))
        resp.raise_for_status()
        return resp.json()

    async def force_release_lock(self, chat_id: str) -> bool:
        """Force-release a stuck stream lock.

        Tries the dedicated ``/force-unlock`` endpoint first (cleaner semantics),
        then falls back to the legacy ``/cancel`` endpoint for older server
        versions.  Returns True if the server confirmed the lock was released.
        """
        try:
            client = await self._get_client()
            # Try the dedicated force-unlock endpoint first.
            resp = await self._request_with_csrf_retry(
                lambda: client.post(f"/api/chat/{chat_id}/force-unlock")
            )
            if resp.status_code == 200:
                data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
                return bool(data.get("lock_released", data.get("released", True)))
            if resp.status_code == 404:
                # Endpoint not present on older deployments — fall through to cancel.
                pass
        except Exception:
            pass

        # Fallback: legacy cancel endpoint.
        try:
            client = await self._get_client()
            resp = await self._request_with_csrf_retry(
                lambda: client.post(f"/api/chat/{chat_id}/cancel")
            )
            if resp.status_code == 200:
                data = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
                return bool(data.get("lock_released", data.get("released", True)))
            return False
        except Exception:
            return False

    # --- Load Project Context ---

    async def load_project(self, chat_id: str, project_path: str = "", patterns: Optional[list] = None) -> Dict[str, Any]:
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(lambda: client.post("/api/chat/load-project", json={
            "chat_id": chat_id,
            "project_path": project_path,
            "file_patterns": patterns or ["*.py", "*.ts", "*.tsx", "*.js", "*.md"],
            "max_files": 30,
        }))
        resp.raise_for_status()
        return resp.json()

    # --- Server-Side Session Snapshots (legacy /api/sessions endpoints) ---

    async def create_session_snapshot(
        self,
        session_id: str,
        snapshot_data: Dict[str, Any],
        description: str = "",
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """POST /api/sessions/snapshot — persist a workspace snapshot server-side."""
        client = await self._get_client()
        resp = await self._request_with_csrf_retry(
            lambda: client.post(
                "/api/sessions/snapshot",
                json={
                    "session_id": session_id,
                    "project_id": project_id,
                    "snapshot_data": snapshot_data,
                    "description": description,
                },
            )
        )
        resp.raise_for_status()
        return resp.json()

    async def list_session_snapshots(self, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """GET /api/sessions/snapshots — list snapshots for the authenticated user."""
        client = await self._get_client()
        resp = await _retry_request(
            lambda: client.get(
                f"/api/sessions/snapshots?limit={limit}&offset={offset}"
            )
        )
        resp.raise_for_status()
        return resp.json()

    async def get_session_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """GET /api/sessions/snapshot/{id} — retrieve a snapshot including full data."""
        client = await self._get_client()
        resp = await _retry_request(
            lambda: client.get(f"/api/sessions/snapshot/{snapshot_id}")
        )
        resp.raise_for_status()
        return resp.json()

    # --- Instructions ---

    async def get_instructions(self, project: Optional[str] = None) -> Dict[str, Any]:
        """GET /api/instructions/global or /api/instructions/project/{name}.

        Returns ``{"instructions": "<text>"}`` — empty string when not set.
        """
        client = await self._get_client()
        if project:
            from urllib.parse import quote
            encoded = quote(str(project), safe="")
            resp = await _retry_request(lambda: client.get(f"/api/instructions/project/{encoded}"))
        else:
            resp = await _retry_request(lambda: client.get("/api/instructions/global"))
        resp.raise_for_status()
        return resp.json()

    async def set_instructions(self, text: str, project: Optional[str] = None) -> Dict[str, Any]:
        """PATCH /api/instructions/global or /api/instructions/project/{name}.

        Pass empty string to clear instructions.  Returns ``{"status": "ok"}``.
        """
        client = await self._get_client()
        payload = {"instructions": str(text).strip()}
        if project:
            from urllib.parse import quote
            encoded = quote(str(project), safe="")
            resp = await self._request_with_csrf_retry(
                lambda: client.patch(f"/api/instructions/project/{encoded}", json=payload)
            )
        else:
            resp = await self._request_with_csrf_retry(
                lambda: client.patch("/api/instructions/global", json=payload)
            )
        resp.raise_for_status()
        return resp.json()

    # --- Provider / Circuit ---

    async def get_provider_circuit_summary(self) -> List[Dict[str, Any]]:
        """GET /api/provider/circuit-summary — circuit breaker state for all tracked providers.

        Returns a list of provider state dicts: provider, state, consecutive_failures, last_failure_at.
        Falls back to ``[]`` when the endpoint is not yet deployed (404).
        """
        client = await self._get_client()
        # Try both possible URL patterns (routed under /api/provider or /api/models)
        for path in ("/api/provider/circuit-summary", "/api/models/circuit-summary"):
            try:
                resp = await _retry_request(lambda p=path: client.get(p))
                if resp.status_code == 404:
                    continue
                resp.raise_for_status()
                data = resp.json()
                if isinstance(data, list):
                    return data
                return data.get("providers", data.get("circuits", []))
            except Exception:
                continue
        return []

    # --- Developer Dashboard ---

    async def get_developer_dashboard(self) -> Dict[str, Any]:
        """GET /api/developer/dashboard — combined developer portal overview.

        Returns account info, API key list, 30-day usage stats, and rate limits.
        """
        client = await self._get_client()
        resp = await _retry_request(lambda: client.get("/api/developer/dashboard"))
        resp.raise_for_status()
        return resp.json()

    # --- Sessions / Snapshots / Flow-Links / Swarm (new surface) ---

    async def list_all_sessions(self, limit: int = 20, project: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all chat sessions across all surfaces."""
        params: Dict[str, Any] = {"limit": limit}
        if project:
            params["project"] = project
        try:
            resp = await self._request("GET", "/api/chat/sessions", params=params)
            data = resp.json() if resp.status_code == 200 else {}
            return data.get("sessions", [])
        except Exception:
            return []

    async def create_snapshot(self, session_id: str, project_name: str, model: str,
                              messages: List[Dict], tokens_total: int = 0, cost_total: float = 0.0) -> Dict[str, Any]:
        """Save a server-side session snapshot."""
        payload = {
            "session_id": session_id,
            "project_name": project_name,
            "model": model,
            "messages": messages[-50:],
            "tokens_total": tokens_total,
            "cost_total": cost_total,
            "message_count": len(messages),
        }
        try:
            resp = await self._request("POST", "/api/snapshots", json=payload)
            return resp.json() if resp.status_code in (200, 201) else {}
        except Exception:
            return {}

    async def list_snapshots(self) -> List[Dict[str, Any]]:
        """List available server-side snapshots for current user."""
        try:
            resp = await self._request("GET", "/api/snapshots")
            data = resp.json() if resp.status_code == 200 else {}
            return data.get("snapshots", [])
        except Exception:
            return []

    async def get_snapshot(self, snapshot_id: str) -> Dict[str, Any]:
        """Fetch a specific snapshot by ID."""
        try:
            resp = await self._request("GET", f"/api/snapshots/{snapshot_id}")
            return resp.json() if resp.status_code == 200 else {}
        except Exception:
            return {}

    async def create_flow_link(self, source_chat_id: str, target_chat_id: str, max_fires: int = 1) -> Dict[str, Any]:
        """Create a flow link between two chats."""
        payload = {"source_chat_id": source_chat_id, "target_chat_id": target_chat_id, "max_fires": max_fires}
        try:
            resp = await self._request("POST", "/api/chat/flow-links", json=payload)
            return resp.json() if resp.status_code in (200, 201) else {}
        except Exception as e:
            return {"error": str(e)}

    async def list_flow_links(self, chat_id: str) -> List[Dict[str, Any]]:
        """List flow links for a chat."""
        try:
            resp = await self._request("GET", f"/api/chat/{chat_id}/flow-links")
            data = resp.json() if resp.status_code == 200 else {}
            return data.get("flow_links", [])
        except Exception:
            return []

    async def stream_swarm_rich(self, prompt: str, models: Optional[List[str]] = None,
                                judge_model: Optional[str] = None,
                                permission_context: Optional[Dict[str, Any]] = None) -> AsyncGenerator[Dict[str, Any], None]:
        """Swarm with streaming synthesis chunks."""
        payload: Dict[str, Any] = {
            "prompt": prompt,
            "models": models or [],
            "max_agents": len(models) if models else 3,
            "permission_context": permission_context,
        }

        if judge_model:
            payload["judge_model"] = judge_model
        try:
            resp = await self._request("POST", "/api/chat/swarm", json=payload)
            data = resp.json() if resp.status_code == 200 else {}
            # Yield agent responses first, then synthesis
            for agent in data.get("agent_responses", []):
                yield {"type": "agent", "agent": agent.get("agent", ""), "model": agent.get("model", ""),
                       "content": agent.get("content", ""), "error": agent.get("error")}
            yield {"type": "synthesis", "content": data.get("synthesis", "")}
        except Exception as e:
            yield {"type": "error", "content": str(e)}

    async def multi_chat_streaming(self, prompt: str, models: List[str],
                                   temperature: Optional[float] = None,
                                   permission_context: Optional[Dict[str, Any]] = None) -> AsyncGenerator[Dict[str, Any], None]:
        """Multi-model chat with per-model result streaming."""
        payload = {
            "prompt": prompt,
            "models": models,
            "temperature": temperature,
            "max_models": len(models),
            "permission_context": permission_context,
        }
        try:
            resp = await self._request("POST", "/api/chat/multi", json=payload)
            results = resp.json() if resp.status_code == 200 else {"responses": []}
            for r in results.get("responses", []):
                yield {"model": r.get("model", ""), "content": (r.get("content") or r.get("response") or ""), "error": r.get("error"),
                       "usage": r.get("usage", {})}
        except Exception as e:
            yield {"model": "error", "content": str(e), "error": str(e), "usage": {}}
