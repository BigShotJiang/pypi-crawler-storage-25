"""Worktree Commands — parallel git worktree management for MSapling CLI.

Enables first-class support for running parallel agent instances in separate
git worktrees, keeping file-system state isolated and preventing split-brain
code modifications.

Security / safety policy:
- Worktree removal is refused when a live MSapling session is detected for
  that path, unless --force is passed.
- Branch names are validated to reject spaces and special characters that
  would break git commands.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from .tui import console as tui_console

worktree_app = typer.Typer(
    name="worktree",
    help="Manage isolated git worktrees for parallel work",
)

_console = tui_console

# Path where active worktree session state is stored per-worktree
_MSAPLING_STATE_DIR = Path.home() / ".msapling" / "worktrees"

# Regex: valid git branch name component (no spaces, no special shell chars)
_BRANCH_RE = re.compile(r"^[a-zA-Z0-9_.\-/]+$")


# ── Validation helpers ────────────────────────────────────────────────────────


def _validate_branch_name(branch: str) -> None:
    """Raise typer.BadParameter if *branch* contains unsafe characters."""
    if not branch or not _BRANCH_RE.match(branch):
        raise typer.BadParameter(
            f"Invalid branch name '{branch}'. "
            "Branch names may only contain letters, digits, underscores, "
            "hyphens, dots, and forward slashes."
        )


def _require_git() -> str:
    """Return the path to git, or abort with a friendly error if not found."""
    git_exe = shutil.which("git")
    if not git_exe:
        _console.print(
            "[red]Error: git executable not found on PATH. "
            "Install git and ensure it is in your PATH.[/red]"
        )
        raise typer.Exit(1)
    return git_exe


def _require_git_repo(cwd: str = ".") -> None:
    """Abort with a friendly error if cwd is not inside a git repository."""
    git_exe = _require_git()
    result = subprocess.run(
        [git_exe, "rev-parse", "--is-inside-work-tree"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        _console.print(
            f"[red]Error: '{cwd}' is not inside a git repository.[/red]"
        )
        raise typer.Exit(1)


# ── Worktree state persistence ────────────────────────────────────────────────


def _state_file(worktree_path: str) -> Path:
    """Return the JSON state file path for a worktree."""
    _MSAPLING_STATE_DIR.mkdir(parents=True, exist_ok=True)
    # Use a hash of the path to create a safe filename
    import hashlib
    key = hashlib.sha256(str(Path(worktree_path).resolve()).encode()).hexdigest()[:16]
    return _MSAPLING_STATE_DIR / f"{key}.json"


def _load_state(worktree_path: str) -> dict:
    """Load persisted state for *worktree_path*. Returns empty dict if absent."""
    sf = _state_file(worktree_path)
    if sf.exists():
        try:
            return json.loads(sf.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_state(worktree_path: str, state: dict) -> None:
    """Persist state dict for *worktree_path*."""
    sf = _state_file(worktree_path)
    _MSAPLING_STATE_DIR.mkdir(parents=True, exist_ok=True)
    sf.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _is_session_active(worktree_path: str) -> bool:
    """Return True if a live MSapling session is registered for *worktree_path*."""
    state = _load_state(worktree_path)
    return bool(state.get("session_active", False))


# ── Raw git helpers ───────────────────────────────────────────────────────────


def _git_worktree_list_raw(cwd: str = ".") -> List[dict]:
    """Return parsed output of `git worktree list --porcelain`.

    Each entry dict has keys: path, HEAD (sha), branch, bare, detached, dirty.
    """
    git_exe = _require_git()
    result = subprocess.run(
        [git_exe, "worktree", "list", "--porcelain"],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return []

    worktrees: List[dict] = []
    current: dict = {}
    for line in result.stdout.splitlines():
        line = line.rstrip()
        if line.startswith("worktree "):
            if current:
                worktrees.append(current)
            current = {"path": line[len("worktree "):], "HEAD": "", "branch": "", "bare": False, "detached": False}
        elif line.startswith("HEAD "):
            current["HEAD"] = line[len("HEAD "):]
        elif line.startswith("branch "):
            # branch refs/heads/main -> main
            ref = line[len("branch "):]
            current["branch"] = ref.removeprefix("refs/heads/")
        elif line == "bare":
            current["bare"] = True
        elif line == "detached":
            current["detached"] = True
    if current:
        worktrees.append(current)
    return worktrees


def _git_is_dirty(worktree_path: str) -> bool:
    """Return True if the worktree at *path* has uncommitted changes."""
    git_exe = shutil.which("git") or "git"
    result = subprocess.run(
        [git_exe, "status", "--porcelain"],
        cwd=worktree_path,
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def _worktree_age_str(worktree_path: str) -> str:
    """Return human-readable age of *path* based on filesystem mtime."""
    try:
        mtime = Path(worktree_path).stat().st_mtime
        age_sec = int(time.time() - mtime)
        if age_sec < 60:
            return f"{age_sec}s"
        elif age_sec < 3600:
            return f"{age_sec // 60}m"
        elif age_sec < 86400:
            return f"{age_sec // 3600}h"
        else:
            return f"{age_sec // 86400}d"
    except Exception:
        return "?"


# ── Commands ──────────────────────────────────────────────────────────────────


@worktree_app.command("create")
def worktree_create(
    branch: str = typer.Argument(..., help="New branch name for the worktree"),
    base: str = typer.Option("main", "--base", "-b", help="Base branch to create from"),
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Directory for the new worktree (default: ../repo-<branch>)"),
):
    """Create a new isolated git worktree and open an MSapling session scoped to it.

    Creates a fresh branch from BASE, checks it out into PATH, then records
    the worktree in MSapling session state so agents stay isolated.

    Examples:
        msapling worktree create feature/my-task
        msapling worktree create feature/search --base develop
        msapling worktree create fix/bug-42 --path /tmp/fix-bug-42
    """
    _validate_branch_name(branch)
    git_exe = _require_git()
    _require_git_repo()

    # Determine the worktree path
    if path:
        wt_path = str(Path(path).resolve())
    else:
        # Default: sibling directory named after the branch leaf
        branch_leaf = branch.replace("/", "-").replace("\\", "-")
        repo_root_result = subprocess.run(
            [git_exe, "rev-parse", "--show-toplevel"],
            capture_output=True, text=True,
        )
        repo_root = repo_root_result.stdout.strip() if repo_root_result.returncode == 0 else "."
        wt_path = str(Path(repo_root).parent / f"{Path(repo_root).name}-{branch_leaf}")

    # Run: git worktree add --track -b <branch> <path> <base>
    cmd = [git_exe, "worktree", "add", "--track", "-b", branch, wt_path, base]
    _console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        _console.print(f"[red]git worktree add failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Persist worktree path in session state
    state = {
        "worktree_path": wt_path,
        "branch": branch,
        "base": base,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "session_active": False,
    }
    _save_state(wt_path, state)

    _console.print(f"[green]Worktree created at[/green] [bold]{wt_path}[/bold]")
    _console.print(f"  Branch: [cyan]{branch}[/cyan] (from [dim]{base}[/dim])")
    _console.print(f"\n[dim]Run:[/dim] [bold]msapling chat --cwd {wt_path}[/bold]")


@worktree_app.command("list")
def worktree_list():
    """List all git worktrees with branch, HEAD SHA, dirty status, age, and MSapling session state.

    Examples:
        msapling worktree list
    """
    git_exe = _require_git()
    _require_git_repo()

    worktrees = _git_worktree_list_raw()

    if not worktrees:
        _console.print("[yellow]No worktrees found.[/yellow]")
        return

    table = Table(title="Git Worktrees", show_header=True, header_style="bold cyan")
    table.add_column("Path", style="cyan")
    table.add_column("Branch", style="green")
    table.add_column("HEAD SHA")
    table.add_column("Dirty", style="yellow")
    table.add_column("Age")
    table.add_column("MSapling Session", style="magenta")

    for wt in worktrees:
        wt_path = wt.get("path", "")
        branch = wt.get("branch", "") or ("[dim]detached[/dim]" if wt.get("detached") else "")
        head_sha = wt.get("HEAD", "")[:8]
        dirty = "yes" if _git_is_dirty(wt_path) else "no"
        age = _worktree_age_str(wt_path)
        session_state = _load_state(wt_path)
        session_label = "[green]active[/green]" if session_state.get("session_active") else "[dim]idle[/dim]"
        table.add_row(wt_path, branch, head_sha, dirty, age, session_label)

    _console.print(table)


@worktree_app.command("remove")
def worktree_remove(
    branch: str = typer.Argument(..., help="Branch name of the worktree to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Remove even if a session is active on this worktree"),
):
    """Remove a git worktree by branch name.

    Refuses removal when a live MSapling session is detected for that worktree
    path unless --force is passed.

    Examples:
        msapling worktree remove feature/my-task
        msapling worktree remove feature/my-task --force
    """
    _validate_branch_name(branch)
    git_exe = _require_git()
    _require_git_repo()

    # Find the worktree matching the branch
    worktrees = _git_worktree_list_raw()
    target = None
    for wt in worktrees:
        if wt.get("branch") == branch:
            target = wt
            break

    if not target:
        _console.print(f"[red]No worktree found for branch '[bold]{branch}[/bold]'.[/red]")
        _console.print("[dim]Use: msapling worktree list[/dim]")
        raise typer.Exit(1)

    wt_path = target["path"]

    # Guard: refuse if session is active on this worktree
    if not force and _is_session_active(wt_path):
        _console.print(
            f"[red]Cannot remove worktree:[/red] A MSapling session is active at [bold]{wt_path}[/bold].\n"
            "  Either detach the session first, or use [bold]--force[/bold] to override."
        )
        raise typer.Exit(1)

    # Run: git worktree remove <path>
    cmd = [git_exe, "worktree", "remove", wt_path]
    if force:
        cmd.append("--force")

    _console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        _console.print(f"[red]git worktree remove failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Clean up MSapling state file
    sf = _state_file(wt_path)
    if sf.exists():
        try:
            sf.unlink()
        except Exception:
            pass

    _console.print(f"[green]Removed worktree:[/green] [bold]{wt_path}[/bold] (branch: {branch})")


@worktree_app.command("status")
def worktree_status():
    """Show all worktrees with their MSapling session state.

    Displays a detailed view including which worktrees have active MSapling
    sessions and their current git status.

    Examples:
        msapling worktree status
    """
    git_exe = _require_git()
    _require_git_repo()

    worktrees = _git_worktree_list_raw()

    if not worktrees:
        _console.print("[yellow]No worktrees found.[/yellow]")
        return

    for wt in worktrees:
        wt_path = wt.get("path", "")
        branch = wt.get("branch", "detached")
        head_sha = wt.get("HEAD", "")[:12]
        dirty = _git_is_dirty(wt_path)
        state = _load_state(wt_path)
        session_active = state.get("session_active", False)
        created_at = state.get("created_at", "")
        base = state.get("base", "")

        status_color = "green" if session_active else "dim"
        status_label = "ACTIVE" if session_active else "idle"

        _console.print(f"[bold]{wt_path}[/bold]")
        _console.print(f"  Branch:  [cyan]{branch}[/cyan]  HEAD: [dim]{head_sha}[/dim]")
        _console.print(f"  Dirty:   {'[yellow]yes[/yellow]' if dirty else '[dim]no[/dim]'}")
        _console.print(f"  Session: [{status_color}]{status_label}[/{status_color}]")
        if base:
            _console.print(f"  Base:    [dim]{base}[/dim]")
        if created_at:
            _console.print(f"  Created: [dim]{created_at[:19]}[/dim]")
        _console.print()


# ── Public helpers for session integration ────────────────────────────────────


def mark_session_active(worktree_path: str, active: bool = True) -> None:
    """Mark the MSapling session state for *worktree_path* as active/idle.

    Called by the shell on session start/end so worktree remove can guard
    against accidentally deleting a live workspace.
    """
    state = _load_state(worktree_path)
    state["session_active"] = active
    state["worktree_path"] = str(Path(worktree_path).resolve())
    if active:
        state["session_started_at"] = datetime.now(timezone.utc).isoformat()
    _save_state(worktree_path, state)
