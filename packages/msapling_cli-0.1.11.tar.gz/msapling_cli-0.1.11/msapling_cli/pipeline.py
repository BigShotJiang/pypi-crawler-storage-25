"""MSapling Pipeline — named multi-step AI pipelines and parallel chat execution.

Pipelines are YAML/JSON configs that chain multiple chat steps:
  - Sequential: output of step N feeds as input to step N+1
  - Parallel: fire all steps simultaneously, collect results
  - Fan-out/Fan-in: broadcast one prompt to N models, synthesize with a judge

Usage:
    msapling pipeline create coding-review  # interactive wizard
    msapling pipeline run coding-review "review my PR"
    msapling pipeline list
    msapling pipeline show coding-review
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

console = Console()

# Default location for pipeline definitions
PIPELINE_DIR = Path.home() / ".msapling" / "pipelines"


def _ensure_dir() -> Path:
    PIPELINE_DIR.mkdir(parents=True, exist_ok=True)
    return PIPELINE_DIR


def list_pipelines() -> List[Dict[str, Any]]:
    """Return all saved pipeline definitions."""
    d = _ensure_dir()
    result = []
    for f in sorted(d.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            result.append(data)
        except Exception:
            pass
    return result


def load_pipeline(name: str) -> Optional[Dict[str, Any]]:
    """Load a pipeline by name."""
    d = _ensure_dir()
    path = d / f"{name}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_pipeline(pipeline: Dict[str, Any]) -> Path:
    """Save pipeline definition to disk."""
    d = _ensure_dir()
    name = pipeline.get("name", "unnamed")
    # Sanitize name for filename
    safe_name = "".join(c for c in name if c.isalnum() or c in "-_").lower()
    path = d / f"{safe_name}.json"
    path.write_text(json.dumps(pipeline, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def delete_pipeline(name: str) -> bool:
    """Delete a pipeline by name. Returns True if deleted."""
    d = _ensure_dir()
    path = d / f"{name}.json"
    if path.exists():
        path.unlink()
        return True
    return False


def create_pipeline_wizard() -> Optional[Dict[str, Any]]:
    """Interactive wizard to create a new pipeline definition."""
    from rich.prompt import Prompt, Confirm

    console.print("\n[bold cyan]Pipeline Builder[/bold cyan]\n")
    name = Prompt.ask("Pipeline name (e.g. 'code-review', 'research-and-summarize')")
    if not name.strip():
        console.print("[red]Name required.[/red]")
        return None

    description = Prompt.ask("Description (optional)", default="")

    mode = Prompt.ask("Mode", choices=["sequential", "parallel", "fan-out"], default="sequential")

    steps = []
    console.print(f"\n[dim]Add steps to your {mode} pipeline. Empty name = done.[/dim]")
    step_num = 1
    while True:
        console.print(f"\n[bold]Step {step_num}[/bold]")
        step_name = Prompt.ask("  Step name (or Enter to finish)", default="")
        if not step_name:
            break
        model = Prompt.ask("  Model (e.g. openai/gpt-4o, anthropic/claude-3-5-sonnet)", default="")
        system_prompt = Prompt.ask("  System prompt (optional)", default="")
        inject_prev = False
        if mode == "sequential" and step_num > 1:
            inject_prev = Confirm.ask("  Inject previous step output as context?", default=True)
        steps.append({
            "name": step_name,
            "model": model or None,
            "system_prompt": system_prompt or None,
            "inject_previous_output": inject_prev,
        })
        step_num += 1

    if not steps:
        console.print("[yellow]No steps added — pipeline not saved.[/yellow]")
        return None

    judge_model = None
    if mode == "fan-out":
        judge_model = Prompt.ask("  Judge/synthesis model", default="google/gemini-2.0-flash-001")

    pipeline = {
        "name": name.strip(),
        "description": description.strip(),
        "mode": mode,
        "steps": steps,
        "judge_model": judge_model,
        "version": "1.0",
    }

    console.print(f"\n[bold]Pipeline:[/bold] {json.dumps(pipeline, indent=2)}")
    if Confirm.ask("\nSave this pipeline?", default=True):
        path = save_pipeline(pipeline)
        console.print(f"[green]Saved to {path}[/green]")
        return pipeline
    return None


async def run_pipeline(
    pipeline: Dict[str, Any],
    prompt: str,
    client: Any,
    verbose: bool = True,
) -> Dict[str, Any]:
    """Execute a pipeline against a prompt. Returns results dict."""
    mode = pipeline.get("mode", "sequential")
    steps = pipeline.get("steps", [])
    results: List[Dict[str, Any]] = []

    if verbose:
        console.print(f"\n[bold cyan]Running pipeline:[/bold cyan] [white]{pipeline['name']}[/white] [dim]({mode}, {len(steps)} steps)[/dim]\n")

    if mode == "sequential":
        current_input = prompt
        for i, step in enumerate(steps):
            step_name = step.get("name", f"Step {i+1}")
            model = step.get("model") or ""
            system = step.get("system_prompt") or ""
            inject_prev = step.get("inject_previous_output", False)

            full_prompt = current_input
            if inject_prev and results:
                prev_output = results[-1].get("output", "")
                full_prompt = f"Previous step output:\n{prev_output}\n\nCurrent task:\n{current_input}"

            if verbose:
                console.print(f"[bold]→ {step_name}[/bold] [dim]({model or 'default'})[/dim]")

            try:
                with console.status(f"[cyan]{step_name} thinking...[/cyan]"):
                    content = await client.chat_once(
                        prompt=full_prompt,
                        model=model,
                        history=[{"role": "system", "content": system}] if system else None,
                    )
                if verbose:
                    preview = str(content)[:300].replace("\n", " ")
                    console.print(f"  [dim]{preview}{'...' if len(str(content)) > 300 else ''}[/dim]")
                results.append({"step": step_name, "model": model, "output": content, "usage": {}})
                current_input = str(content)
            except Exception as e:
                console.print(f"  [red]Step failed: {e}[/red]")
                results.append({"step": step_name, "model": model, "output": None, "error": str(e)})

    elif mode in ("parallel", "fan-out"):
        if verbose:
            console.print(f"[dim]Firing {len(steps)} steps in parallel...[/dim]")

        async def _run_step(step: Dict[str, Any]) -> Dict[str, Any]:
            step_name = step.get("name", "step")
            model = step.get("model") or ""
            system = step.get("system_prompt") or ""
            try:
                content = await client.chat_once(
                    prompt=prompt,
                    model=model,
                    history=[{"role": "system", "content": system}] if system else None,
                )
                return {"step": step_name, "model": model, "output": content, "usage": {}}
            except Exception as e:
                return {"step": step_name, "model": model, "output": None, "error": str(e)}

        raw = await asyncio.gather(*[_run_step(s) for s in steps], return_exceptions=True)
        for item in raw:
            if isinstance(item, BaseException):
                results.append({"step": "unknown", "output": None, "error": str(item)})
            else:
                results.append(item)
                if verbose:
                    console.print(f"  [green]✓[/green] {item['step']} [dim]({item.get('model','')})[/dim]")

        # Fan-out synthesis
        if mode == "fan-out" and pipeline.get("judge_model"):
            judge = pipeline["judge_model"]
            outputs = "\n\n".join(
                f"### {r['step']}\n{r.get('output','(no output)')}"
                for r in results if r.get("output")
            )
            synthesis_prompt = f"Synthesize these expert responses into one best answer:\n\n{outputs}\n\nOriginal question: {prompt}"
            if verbose:
                console.print(f"\n[bold]→ Synthesis[/bold] [dim]({judge})[/dim]")
            try:
                with console.status("[cyan]Synthesizing...[/cyan]"):
                    synthesis = await client.chat_once(
                        prompt=synthesis_prompt,
                        model=judge,
                        history=None,
                    )
                results.append({"step": "synthesis", "model": judge, "output": synthesis, "usage": {}})
                if verbose:
                    console.print(Panel(str(synthesis)[:2000], title="Synthesis", border_style="green"))
            except Exception as e:
                results.append({"step": "synthesis", "model": judge, "output": None, "error": str(e)})

    return {"pipeline": pipeline["name"], "mode": mode, "prompt": prompt, "results": results}


async def run_parallel_chats(
    prompt: str,
    n: int,
    model: str,
    client: Any,
    *,
    project_name: Optional[str] = None,
    max_attempts: int = 4,
    backoff_s: float = 0.35,
    stagger_s: float = 0.12,
) -> List[Dict[str, Any]]:
    """Fire N parallel chat requests with the same prompt and model."""

    max_attempts = max(1, int(max_attempts))
    backoff_s = max(0.0, float(backoff_s))
    stagger_s = max(0.0, float(stagger_s))

    def _status_code_from_error(err: Exception) -> Optional[int]:
        code = getattr(err, "status_code", None)
        if isinstance(code, int):
            return code
        resp = getattr(err, "response", None)
        resp_code = getattr(resp, "status_code", None)
        return int(resp_code) if isinstance(resp_code, int) else None

    def _is_transient_error(err: Exception) -> bool:
        code = _status_code_from_error(err)
        if code in {423, 429, 500, 502, 503, 504}:
            return True
        if code in {400, 401, 402, 403, 404, 422}:
            return False

        low = str(err).lower()
        hard_no = (
            "403 forbidden",
            "401 unauthorized",
            "402",
            "404",
            "payment required",
            "model unavailable",
            "not a valid model id",
        )
        if any(token in low for token in hard_no):
            return False

        transient_tokens = (
            "500",
            "502",
            "503",
            "504",
            "internal server error",
            "temporarily unavailable",
            "timeout",
            "timed out",
            "connection failed",
            "all connection attempts failed",
            "remoteprotocolerror",
            "connecterror",
            "readerror",
            "stream interrupted",
            "server disconnected",
            "already streaming",
        )
        return any(token in low for token in transient_tokens)

    def _looks_like_error_content(content: str) -> bool:
        low = str(content or "").strip().lower()
        if not low:
            return True
        if low.startswith("[error:") or low.startswith("error:"):
            return True
        if low.startswith("[provider]"):
            return True
        if "not a valid model id" in low:
            return True
        if "for more information check: https://developer.mozilla.org/en-us/docs/web/http/status/" in low:
            return True
        return False

    async def _one(idx: int) -> Dict[str, Any]:
        if stagger_s > 0 and idx > 0:
            await asyncio.sleep(stagger_s * idx)
        for attempt in range(1, max_attempts + 1):
            try:
                kwargs: Dict[str, Any] = {
                    "prompt": prompt,
                    "model": model,
                    "history": None,
                }
                if project_name:
                    kwargs["project_name"] = project_name
                try:
                    content = await client.chat_once(**kwargs)
                except TypeError:
                    # Backward-compatible fallback for stubs/older clients that
                    # don't yet accept project_name in chat_once().
                    kwargs.pop("project_name", None)
                    content = await client.chat_once(**kwargs)
                if not str(content or "").strip():
                    raise RuntimeError("No response received")
                if _looks_like_error_content(str(content)):
                    raise RuntimeError(str(content).strip())
                return {
                    "idx": idx + 1,
                    "content": content,
                    "usage": {},
                    "error": None,
                    "attempts": attempt,
                    "retried": attempt > 1,
                    "transient_error": False,
                }
            except Exception as e:
                is_transient = _is_transient_error(e)
                if is_transient and attempt < max_attempts:
                    next_attempt = attempt + 1
                    console.print(
                        f"[yellow]Run {idx + 1}: transient error, retrying ({next_attempt}/{max_attempts})[/yellow]"
                    )
                    wait_s = backoff_s * (2 ** (attempt - 1))
                    if wait_s > 0:
                        await asyncio.sleep(wait_s)
                    continue
                return {
                    "idx": idx + 1,
                    "content": None,
                    "usage": {},
                    "error": str(e),
                    "attempts": attempt,
                    "retried": attempt > 1,
                    "transient_error": bool(is_transient),
                }
        return {
            "idx": idx + 1,
            "content": None,
            "usage": {},
            "error": "Unknown parallel execution failure",
            "attempts": max_attempts,
            "retried": max_attempts > 1,
            "transient_error": False,
        }

    console.print(f"[cyan]Firing {n} parallel chats with {model}...[/cyan]")
    raw = list(await asyncio.gather(*[_one(i) for i in range(n)], return_exceptions=True))
    normalized: List[Dict[str, Any]] = []
    for idx, item in enumerate(raw, start=1):
        if isinstance(item, BaseException):
            normalized.append(
                {
                    "idx": idx,
                    "content": None,
                    "usage": {},
                    "error": str(item),
                    "attempts": 1,
                    "retried": False,
                    "transient_error": False,
                }
            )
            continue
        if not isinstance(item, dict):
            normalized.append(
                {
                    "idx": idx,
                    "content": None,
                    "usage": {},
                    "error": str(item),
                    "attempts": 1,
                    "retried": False,
                    "transient_error": False,
                }
            )
            continue
        item.setdefault("idx", idx)
        item.setdefault("usage", {})
        item.setdefault("content", None)
        item.setdefault("error", None)
        item.setdefault("attempts", 1)
        item.setdefault("retried", False)
        item.setdefault("transient_error", False)
        normalized.append(item)
    return normalized
