"""MSapling CLI Toast Notification System.

Provides non-blocking terminal toast messages for background events
(summary updates, auto-save completions, stream lock releases, etc.).

Usage::

    from msapling_cli.toast import toast

    toast("Summary updated in background")
    toast("Session saved", level="info")
    toast("Low fuel credits", level="warning")
    toast("Stream error", level="error")

The toast is printed immediately to stderr (to avoid corrupting stdout
pipelines) and a :class:`threading.Timer` schedules a blank line after
*duration* seconds to visually clear the notification area.

Thread safety: a module-level :class:`threading.Lock` prevents interleaved
output when multiple toasts fire concurrently.
"""
from __future__ import annotations

import sys
import threading
from typing import Literal

# ---------------------------------------------------------------------------
# Internal state
# ---------------------------------------------------------------------------

_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Toast level icons
# ---------------------------------------------------------------------------

_LEVEL_ICONS: dict[str, str] = {
    "info":    "✓",
    "warning": "⚠",
    "error":   "✗",
}

_LEVEL_COLORS: dict[str, str] = {
    "info":    "\033[92m",   # bright green
    "warning": "\033[93m",   # bright yellow
    "error":   "\033[91m",   # bright red
}

_RESET = "\033[0m"

# Respect NO_COLOR / dumb terminals
import os as _os
_use_color = (
    _os.environ.get("NO_COLOR") is None
    and _os.environ.get("TERM", "") != "dumb"
)

ToastLevel = Literal["info", "warning", "error"]


def toast(
    message: str,
    level: ToastLevel = "info",
    duration: float = 3.0,
    *,
    file=None,
) -> None:
    """Print a non-blocking toast notification.

    Parameters
    ----------
    message:
        The text to display.
    level:
        Severity: ``"info"`` (default), ``"warning"``, or ``"error"``.
    duration:
        Seconds until a blank line is printed to clear the notification area.
        Pass ``0`` to suppress the auto-clear timer.
    file:
        Output stream; defaults to ``sys.stderr`` so it doesn't corrupt
        stdout pipelines.  Pass ``sys.stdout`` in interactive shells where
        stderr is captured.
    """
    if file is None:
        file = sys.stderr

    icon = _LEVEL_ICONS.get(level, _LEVEL_ICONS["info"])
    color = _LEVEL_COLORS.get(level, _LEVEL_COLORS["info"]) if _use_color else ""
    reset = _RESET if _use_color else ""

    formatted = f"{color}[{icon} Toast] {message}{reset}"

    with _lock:
        print(formatted, file=file, flush=True)

    if duration > 0:
        def _clear():
            with _lock:
                print("", file=file, flush=True)

        timer = threading.Timer(duration, _clear)
        timer.daemon = True  # don't block process exit
        timer.start()
