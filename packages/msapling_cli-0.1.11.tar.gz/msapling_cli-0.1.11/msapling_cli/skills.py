"""Skill versioning system for MSapling CLI."""
import json
import re
from pathlib import Path
from typing import Optional, Dict, Any, List

_SKILLS_DIR = Path.home() / ".msapling" / "skills"
_INSTINCTS_BASE = Path.home() / ".msapling" / "instincts"


def save_skill(
    name: str,
    content: str,
    version: int = 1,
    metadata: Optional[Dict[str, Any]] = None,
) -> Path:
    """Save a skill with version tracking.

    Writes a versioned file ``{name}_v{version}.json`` and updates
    ``{name}.json`` (the "latest" symlink via file copy on Windows).

    Returns the path of the versioned file written.
    """
    _SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    skill_data = {
        "name": name,
        "version": version,
        "content": content,
        "metadata": metadata or {},
    }
    payload = json.dumps(skill_data, indent=2)
    versioned = _SKILLS_DIR / f"{name}_v{version}.json"
    versioned.write_text(payload, encoding="utf-8")
    # Update the "latest" pointer (plain file copy — works on all platforms).
    latest = _SKILLS_DIR / f"{name}.json"
    latest.write_text(payload, encoding="utf-8")
    return versioned


def load_skill(name: str, version: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """Load a skill by name, optionally at a specific version.

    If ``version`` is None, loads the latest (``{name}.json``).
    Returns the parsed dict or None if not found.
    """
    if version is not None:
        path = _SKILLS_DIR / f"{name}_v{version}.json"
    else:
        path = _SKILLS_DIR / f"{name}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def list_skills() -> List[Dict[str, Any]]:
    """Return a list of all latest-version skills.

    Each entry is ``{"name": str, "version": int, "content": str,
    "metadata": dict}``.  Only the ``{name}.json`` (latest) files are
    enumerated so duplicates are avoided.
    """
    if not _SKILLS_DIR.exists():
        return []
    results: List[Dict[str, Any]] = []
    for path in sorted(_SKILLS_DIR.glob("*.json")):
        # Skip versioned files — we only want the "latest" pointers.
        stem = path.stem
        if "_v" in stem and stem.rsplit("_v", 1)[-1].isdigit():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "name" in data:
                results.append(data)
        except Exception:
            continue
    return results


def _instinct_slug(observation: str) -> str:
    """Derive a filesystem-safe slug from an observation string."""
    return re.sub(r"[^a-z0-9]+", "_", observation[:40].lower()).strip("_") or "instinct"


def save_instinct(observation: str, confidence: float, project: str) -> Path:
    """Save a project-scoped instinct to ``.msapling/instincts/{project}/{slug}.json``.

    After saving, auto-promotion is checked: if confidence >= 0.8 and the same
    observation slug exists in at least 2 projects it is promoted to global
    (``~/.msapling/skills/``).

    Returns the path of the instinct file written.
    """
    confidence = max(0.0, min(1.0, float(confidence)))
    slug = _instinct_slug(observation)
    project_dir = _INSTINCTS_BASE / project
    project_dir.mkdir(parents=True, exist_ok=True)
    instinct_path = project_dir / f"{slug}.json"
    data = {
        "slug": slug,
        "observation": observation,
        "confidence": confidence,
        "project": project,
    }
    instinct_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # Auto-promote if confidence >= 0.8 and observed in >= 2 projects
    if confidence >= 0.8:
        _maybe_auto_promote(slug, observation, confidence)

    return instinct_path


def _maybe_auto_promote(slug: str, observation: str, confidence: float) -> bool:
    """Promote an instinct to global skills if it appears in 2+ projects."""
    if not _INSTINCTS_BASE.exists():
        return False
    project_count = sum(
        1 for project_dir in _INSTINCTS_BASE.iterdir()
        if project_dir.is_dir() and (project_dir / f"{slug}.json").exists()
    )
    if project_count >= 2:
        promote_to_global(slug)
        return True
    return False


def promote_to_global(instinct_name: str) -> Optional[Path]:
    """Copy an instinct from any project directory to the global skills store.

    Searches all project directories for ``{instinct_name}.json``.  Returns the
    path of the global skill file written, or None if the instinct was not found.
    """
    if not _INSTINCTS_BASE.exists():
        return None
    # Find the first matching instinct across all project dirs
    source_data: Optional[Dict[str, Any]] = None
    for project_dir in _INSTINCTS_BASE.iterdir():
        if not project_dir.is_dir():
            continue
        candidate = project_dir / f"{instinct_name}.json"
        if candidate.exists():
            try:
                source_data = json.loads(candidate.read_text(encoding="utf-8"))
                break
            except Exception:
                continue
    if source_data is None:
        return None

    # Save as a global skill
    observation = source_data.get("observation", instinct_name)
    existing = load_skill(instinct_name)
    version = (existing.get("version", 0) + 1) if existing else 1
    return save_skill(instinct_name, observation, version=version, metadata={"source": "instinct"})


def inject_skills_at_startup(shell: Any) -> List[str]:
    """Load all skills and inject into shell context.

    Appends each skill's content to the shell's system prompt so the AI
    is aware of all learned rules at startup.

    Returns the list of skill names loaded.
    """
    skills = list_skills()
    if not skills:
        return []
    loaded: List[str] = []
    skill_lines = []
    for skill in skills:
        name = skill.get("name", "unknown")
        content = skill.get("content", "").strip()
        if content:
            skill_lines.append(f"[Skill: {name}]\n{content}")
            loaded.append(name)
    if skill_lines and hasattr(shell, "system_prompt_extra"):
        existing = getattr(shell, "system_prompt_extra", "") or ""
        shell.system_prompt_extra = (
            existing + "\n\n[Learned Skills]\n" + "\n\n".join(skill_lines)
        ).strip()
    return loaded
