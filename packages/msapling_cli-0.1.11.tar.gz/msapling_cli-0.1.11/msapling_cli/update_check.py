"""Auto-update check for msapling-cli.

Checks PyPI once per day and prints a notice if a newer version is available.
All network I/O is cached and all errors are swallowed — never crashes the CLI.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Tuple

PYPI_URL = "https://pypi.org/pypi/msapling-cli/json"
CACHE_FILE = Path.home() / ".msapling" / "update_check_cache.json"
CHECK_INTERVAL_HOURS = 24


# ---------------------------------------------------------------------------
# Version helpers
# ---------------------------------------------------------------------------

def _parse_version(v: str) -> Tuple[int, ...]:
    """Parse a version string like '1.2.3' into a tuple of ints for comparison.

    Falls back to (0,) on any parse error so comparisons always succeed.
    """
    try:
        # Try packaging first (already in the Python ecosystem)
        from packaging.version import Version  # type: ignore
        pv = Version(v)
        return tuple(pv.release)
    except Exception:
        pass
    try:
        parts = v.strip().lstrip("v").split(".")
        return tuple(int(p) for p in parts if p.isdigit())
    except Exception:
        return (0,)


def get_current_version() -> str:
    """Return the installed version of msapling-cli."""
    try:
        from importlib.metadata import version
        return version("msapling-cli")
    except Exception:
        pass
    try:
        from . import __version__
        return __version__
    except Exception:
        return "0.0.0"


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

def _read_cache() -> Optional[dict]:
    """Return the parsed cache dict, or None if missing/corrupt."""
    try:
        if CACHE_FILE.exists():
            return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return None


def _write_cache(latest: str) -> None:
    """Write the cache file with the latest version and current timestamp."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "latest": latest,
            "checked_at": datetime.now(tz=timezone.utc).isoformat(),
        }
        CACHE_FILE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def _cache_is_fresh(cache: dict) -> bool:
    """Return True if the cache was written within CHECK_INTERVAL_HOURS."""
    try:
        checked_at_str = cache.get("checked_at", "")
        if not checked_at_str:
            return False
        checked_at = datetime.fromisoformat(checked_at_str)
        # Make offset-aware if needed
        if checked_at.tzinfo is None:
            checked_at = checked_at.replace(tzinfo=timezone.utc)
        now = datetime.now(tz=timezone.utc)
        return (now - checked_at) < timedelta(hours=CHECK_INTERVAL_HOURS)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_latest_version() -> Optional[str]:
    """Fetch the latest msapling-cli version from PyPI (or cache).

    Returns None on any network or parse error — never raises.
    """
    try:
        cache = _read_cache()
        if cache and _cache_is_fresh(cache):
            latest = cache.get("latest")
            if latest and isinstance(latest, str):
                return latest

        import httpx  # already a project dependency
        resp = httpx.get(PYPI_URL, timeout=5.0)
        resp.raise_for_status()
        data = resp.json()
        latest = data["info"]["version"]
        if not isinstance(latest, str) or not latest:
            return None
        _write_cache(latest)
        return latest
    except Exception:
        return None


def is_update_available() -> Tuple[bool, str, str]:
    """Return (available, current, latest).

    Returns (False, current, current) on any error — never raises.
    """
    current = get_current_version()
    try:
        latest = get_latest_version()
        if not latest:
            return False, current, current
        if _parse_version(latest) > _parse_version(current):
            return True, current, latest
        return False, current, latest
    except Exception:
        return False, current, current


def print_update_notice(current: str, latest: str) -> None:
    """Print a one-line update notice.  Never raises."""
    try:
        import typer
        typer.echo(
            f"  [update] msapling-cli {latest} available "
            f"(current: {current}) — pip install -U msapling-cli"
        )
    except Exception:
        try:
            print(
                f"  [update] msapling-cli {latest} available "
                f"(current: {current}) — pip install -U msapling-cli"
            )
        except Exception:
            pass


def check_and_notify() -> None:
    """Check for an update and print a notice if one is available.

    Swallows all exceptions — safe to call unconditionally at startup.
    """
    try:
        available, current, latest = is_update_available()
        if available:
            print_update_notice(current, latest)
    except Exception:
        pass
