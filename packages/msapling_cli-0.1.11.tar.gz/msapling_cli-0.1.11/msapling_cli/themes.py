"""MSapling CLI Theme Engine.

Provides three built-in color themes (diamond, onyx, lab) and helpers for
accessing the active theme at runtime.  The active theme is read from the
user's config (``~/.msapling/config.json``) via :func:`get_active_theme`.

Usage::

    from msapling_cli.themes import get_theme, theme_color, get_active_theme

    t = get_theme("diamond")      # dict of color keys
    color = theme_color("primary")  # resolves from active theme
"""
from __future__ import annotations

from typing import Dict, Any, Optional

# ---------------------------------------------------------------------------
# Theme definitions
# ---------------------------------------------------------------------------

THEMES: Dict[str, Dict[str, Any]] = {
    "diamond": {
        "primary": "bright_cyan",
        "secondary": "cyan",
        "accent": "white",
        "error": "bright_red",
        "success": "bright_green",
        "warning": "yellow",
        "prompt": "bright_cyan",
        "user_prefix": "◆",
        "ai_prefix": "◈",
        "description": "Clean, vibrant cyan tones — the classic MSapling look.",
    },
    "onyx": {
        "primary": "bright_white",
        "secondary": "white",
        "accent": "grey82",
        "error": "red",
        "success": "green",
        "warning": "yellow",
        "prompt": "white",
        "user_prefix": "●",
        "ai_prefix": "○",
        "description": "Monochromatic grayscale — minimal and distraction-free.",
    },
    "lab": {
        "primary": "bright_green",
        "secondary": "green",
        "accent": "bright_white",
        "error": "red",
        "success": "bright_green",
        "warning": "bright_yellow",
        "prompt": "bright_green",
        "user_prefix": "λ",
        "ai_prefix": "⊕",
        "description": "High-contrast green terminal — inspired by classic hacker terminals.",
    },
}

DEFAULT_THEME = "diamond"

# Required keys every theme must contain.
REQUIRED_KEYS = frozenset({
    "primary",
    "secondary",
    "accent",
    "error",
    "success",
    "warning",
    "prompt",
    "user_prefix",
    "ai_prefix",
})

# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def get_theme(name: str) -> Dict[str, Any]:
    """Return the theme dict for *name*.

    Raises
    ------
    ValueError
        If *name* is not a registered theme.
    """
    key = name.strip().lower() if name else ""
    if key not in THEMES:
        valid = ", ".join(sorted(THEMES))
        raise ValueError(
            f"Unknown theme {name!r}. Valid themes: {valid}"
        )
    return THEMES[key]


def get_active_theme() -> Dict[str, Any]:
    """Return the currently configured theme dict.

    Reads ``theme`` from ``~/.msapling/config.json``.  Falls back to
    ``DEFAULT_THEME`` on any error.
    """
    try:
        from .config import get_settings
        settings = get_settings()
        theme_name: str = getattr(settings, "theme", DEFAULT_THEME) or DEFAULT_THEME
        # Normalise legacy values (old default was "dark")
        if theme_name not in THEMES:
            theme_name = DEFAULT_THEME
        return THEMES[theme_name]
    except Exception:
        return THEMES[DEFAULT_THEME]


def theme_color(key: str, theme_name: Optional[str] = None) -> str:
    """Return the Rich color string for *key* from the active (or named) theme.

    Parameters
    ----------
    key:
        A REQUIRED_KEYS member (e.g. ``"primary"``, ``"error"``).
    theme_name:
        Optional explicit theme name; if *None* the active theme is used.

    Returns
    -------
    str
        A Rich-compatible color/style string (e.g. ``"bright_cyan"``).

    Raises
    ------
    KeyError
        If *key* is not present in the theme.
    ValueError
        If *theme_name* is provided but unknown.
    """
    theme = get_theme(theme_name) if theme_name else get_active_theme()
    if key not in theme:
        raise KeyError(f"Theme key {key!r} not found in theme.")
    value = theme[key]
    return str(value)


def list_themes() -> Dict[str, str]:
    """Return a mapping of theme name -> description."""
    return {name: data.get("description", "") for name, data in THEMES.items()}
