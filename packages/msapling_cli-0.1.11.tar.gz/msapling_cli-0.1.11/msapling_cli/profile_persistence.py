"""Workspace context profile persistence for msapling-cli.

Saves/loads the active context profile (dev, research, review, security) per
project so the CLI doesn't re-detect on every message.

Profiles are stored as plain JSON files under:
    ~/.msapling/profiles/<project_id>.json
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

PROFILES_DIR = Path.home() / ".msapling" / "profiles"

VALID_PROFILES = {"dev", "research", "review", "security"}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def save_profile(project_id: str, profile_name: str) -> None:
    """Save the active profile for *project_id*.

    Creates the profiles directory if it does not exist.

    Raises
    ------
    ValueError
        When *profile_name* is not a recognised profile.
    """
    if profile_name not in VALID_PROFILES:
        raise ValueError(
            f"Invalid profile '{profile_name}'. "
            f"Must be one of: {', '.join(sorted(VALID_PROFILES))}"
        )
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    profile_file = PROFILES_DIR / f"{project_id}.json"
    data = {"profile": profile_name}
    profile_file.write_text(json.dumps(data), encoding="utf-8")


def load_profile(project_id: str) -> Optional[str]:
    """Return the saved profile name for *project_id*, or None if not set."""
    profile_file = PROFILES_DIR / f"{project_id}.json"
    try:
        if profile_file.exists():
            data = json.loads(profile_file.read_text(encoding="utf-8"))
            profile = data.get("profile")
            if isinstance(profile, str) and profile in VALID_PROFILES:
                return profile
    except Exception:
        pass
    return None


def clear_profile(project_id: str) -> None:
    """Remove the saved profile for *project_id* (reset to auto-detect)."""
    profile_file = PROFILES_DIR / f"{project_id}.json"
    try:
        if profile_file.exists():
            profile_file.unlink()
    except Exception:
        pass


def list_profiles() -> dict[str, str]:
    """Return a mapping of {project_id: profile_name} for all saved profiles."""
    result: dict[str, str] = {}
    try:
        if not PROFILES_DIR.exists():
            return result
        for path in PROFILES_DIR.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                profile = data.get("profile")
                if isinstance(profile, str) and profile in VALID_PROFILES:
                    project_id = path.stem
                    result[project_id] = profile
            except Exception:
                pass
    except Exception:
        pass
    return result
