"""Optional bridge from MSapling CLI runtime to MLineage events.

This module is intentionally soft-fail and opt-in:
- Disabled by default.
- Does nothing when MLineage is not installed/importable.
- Never raises into the interactive shell path.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

_log = logging.getLogger(__name__)

_ENABLE_ENV = "MSAPLING_MLINEAGE_ENABLE"
_PROJECT_ID_ENV = "MSAPLING_MLINEAGE_PROJECT_ID"


def _is_enabled() -> bool:
    raw = os.getenv(_ENABLE_ENV, "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _project_id(project_name: Optional[str]) -> str:
    override = os.getenv(_PROJECT_ID_ENV, "").strip()
    if override:
        return override
    fallback = str(project_name or "").strip()
    return fallback or "global"


async def record_conversation_turn(
    *,
    session_id: str,
    role: str,
    content: str,
    project_name: Optional[str],
    source: str = "msapling_cli",
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """Record one user/assistant turn to MLineage when enabled."""
    if not _is_enabled():
        return False
    try:
        from mlineage.engine import record_conversation_turn as _record  # type: ignore
    except Exception as exc:
        _log.debug("MLineage unavailable for conversation tracking: %s", exc)
        return False
    try:
        await _record(
            session_id=session_id,
            role=role,
            content=content,
            project_id=_project_id(project_name),
            source=source,
            metadata=metadata,
        )
        return True
    except Exception as exc:
        _log.debug("Failed to write MLineage conversation turn: %s", exc)
        return False


async def record_shell_command(
    *,
    session_id: str,
    command: str,
    exit_code: Optional[int],
    stdout: Optional[str],
    stderr: Optional[str],
    project_name: Optional[str],
    source: str = "msapling_cli_shell",
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """Record one shell command execution to MLineage when enabled."""
    if not _is_enabled():
        return False
    try:
        from mlineage.engine import record_shell_command as _record  # type: ignore
    except Exception as exc:
        _log.debug("MLineage unavailable for shell tracking: %s", exc)
        return False
    try:
        await _record(
            session_id=session_id,
            command=command,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            project_id=_project_id(project_name),
            source=source,
            metadata=metadata,
        )
        return True
    except Exception as exc:
        _log.debug("Failed to write MLineage shell command: %s", exc)
        return False
