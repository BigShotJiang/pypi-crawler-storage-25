"""LOOP-32: Doctor auth probe fix guardrail tests.

Source-scan tests — no app startup required.
Verifies that _doctor_api_check uses cookie-based auth (msaplingauth)
instead of only Bearer token, matching MSaplingClient._get_client() behavior.

Root cause of auth_check_failed despite valid auth:
- /users/me uses FastAPI Users JWT cookie transport (msaplingauth cookie)
- The old probe only sent Authorization: Bearer <token>
- Bearer header alone is rejected; cookie is required
"""
from pathlib import Path

_CLI = Path(__file__).resolve().parents[1] / "msapling_cli" / "main.py"
_MAIN_SRC = _CLI.read_text(encoding="utf-8") if _CLI.exists() else ""


class TestDoctorAuthProbe:
    def test_doctor_api_check_sets_cookie(self):
        """_doctor_api_check must set msaplingauth cookie for /users/me auth."""
        assert 'cookies["msaplingauth"]' in _MAIN_SRC or '"msaplingauth": token' in _MAIN_SRC, (
            "_doctor_api_check must set msaplingauth cookie — "
            "/users/me uses JWT cookie transport, not Bearer header"
        )

    def test_doctor_api_check_passes_cookies_to_client(self):
        """httpx.AsyncClient in _doctor_api_check must receive cookies kwarg."""
        assert "cookies=cookies" in _MAIN_SRC, (
            "httpx.AsyncClient in _doctor_api_check must receive cookies= kwarg "
            "so the JWT cookie is sent to /users/me"
        )

    def test_doctor_api_check_still_sends_bearer(self):
        """_doctor_api_check should still send Bearer header as fallback."""
        assert "Authorization" in _MAIN_SRC and "Bearer" in _MAIN_SRC, (
            "_doctor_api_check should still include Authorization: Bearer header "
            "as fallback for endpoints that support it"
        )


class TestDoctorAuthComment:
    def test_cookie_auth_comment_explains_why(self):
        """_doctor_api_check should explain why cookie is needed (prevents re-introduction of bug)."""
        assert "msaplingauth" in _MAIN_SRC, (
            "main.py must reference msaplingauth cookie in _doctor_api_check context"
        )
