from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from msapling_cli import main


runner = CliRunner()
_FIXTURES = Path(__file__).parent / "parity_demo"


def _load_fixture(name: str):
    return json.loads((_FIXTURES / name).read_text(encoding="utf-8"))


def test_multi_json_output_matches_golden_snapshot(monkeypatch):
    expected = _load_fixture("golden_multi_output.json")

    class StubClient:
        async def multi_chat(self, prompt, models, history=None, permission_context=None):
            assert models == ["m1", "m2"]
            return [
                {"model": "m1", "response": "answer one", "status": "ok"},
                {
                    "model": "m2",
                    "response": "",
                    "status": "error",
                    "error": "rate limited",
                    "error_code": "http_429",
                    "http_status": 429,
                    "provider": "TestProvider",
                    "retryable": True,
                },
            ]

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)
    monkeypatch.setattr(main, "runtime_fanout_budget", lambda **kwargs: {"recommended_cap": 8})

    result = runner.invoke(main.app, ["multi", "hello", "-m", "m1,m2", "--output", "json", "--max-attempts", "1"])
    assert result.exit_code == 0
    actual = json.loads(result.stdout)
    assert actual == expected


def test_swarm_json_output_matches_golden_snapshot(monkeypatch):
    expected = _load_fixture("golden_swarm_output.json")

    class StubClient:
        async def swarm(self, prompt, models=None, synthesize_model=None, permission_context=None):
            assert models == ["m1", "m2"]
            return {
                "agent_responses": [
                    {
                        "model": "m1",
                        "response": "answer one",
                        "status": "ok",
                        "usage": {
                            "input": 10,
                            "output": 5,
                            "cacheRead": 1,
                            "cacheWrite": 0,
                            "total": 15,
                            "costUsd": 0.01,
                        },
                    },
                    {
                        "model": "m2",
                        "response": "",
                        "status": "error",
                        "error": "timeout",
                        "error_code": "transient_timeout",
                        "http_status": 504,
                        "provider": "TestProvider",
                        "retryable": True,
                        "usage": {
                            "input": 0,
                            "output": 0,
                            "cacheRead": 0,
                            "cacheWrite": 0,
                            "total": 0,
                            "costUsd": 0.0,
                        },
                    },
                ],
                "synthesis": "best merged answer",
                "judge_model": "m1",
                "models_used": ["m1", "m2"],
                "latency_ms": 12,
                "usage": {
                    "input": 10,
                    "output": 5,
                    "cacheRead": 1,
                    "cacheWrite": 0,
                    "total": 15,
                    "costUsd": 0.01,
                },
            }

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)
    monkeypatch.setattr(main, "runtime_fanout_budget", lambda **kwargs: {"recommended_cap": 8})

    result = runner.invoke(main.app, ["swarm", "hello", "-m", "m1,m2", "--output", "json", "--max-attempts", "1"])
    assert result.exit_code == 0
    actual = json.loads(result.stdout)
    assert actual == expected
