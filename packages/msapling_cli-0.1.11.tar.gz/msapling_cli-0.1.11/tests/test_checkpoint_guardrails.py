"""Guardrail tests for the CheckpointManager and shell checkpoint commands.

Run with:
    python -m pytest cli/tests/test_checkpoint_guardrails.py -q
"""
from __future__ import annotations

import importlib
import importlib.util
import inspect
import os
import sys
import tempfile
from pathlib import Path

import pytest

# ---- helpers ---------------------------------------------------------------

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_SHELL_PATH = _PKG_DIR / "shell.py"


def _import_checkpoint():
    """Import checkpoint.py from the msapling_cli package."""
    mod_path = _PKG_DIR / "checkpoint.py"
    spec = importlib.util.spec_from_file_location("msapling_cli.checkpoint", str(mod_path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ---- Test 1: Module imports without error ----------------------------------


def test_checkpoint_module_imports():
    """checkpoint.py must import cleanly with no side effects."""
    mod = _import_checkpoint()
    assert mod is not None


# ---- Test 2: CheckpointManager class exists --------------------------------


def test_checkpoint_manager_class_exists():
    """CheckpointManager class must be defined."""
    mod = _import_checkpoint()
    assert hasattr(mod, "CheckpointManager")
    assert inspect.isclass(mod.CheckpointManager)


# ---- Test 3: create() exists and accepts label -----------------------------


def test_create_method_exists_and_accepts_label():
    """create() must exist and accept a 'label' parameter."""
    mod = _import_checkpoint()
    mgr = mod.CheckpointManager(repo_root=".")
    assert hasattr(mgr, "create")
    sig = inspect.signature(mgr.create)
    assert "label" in sig.parameters


# ---- Test 4: compare() exists and accepts checkpoint_tag -------------------


def test_compare_method_exists_and_accepts_checkpoint_tag():
    """compare() must exist and accept a 'checkpoint_tag' parameter."""
    mod = _import_checkpoint()
    mgr = mod.CheckpointManager(repo_root=".")
    assert hasattr(mgr, "compare")
    sig = inspect.signature(mgr.compare)
    assert "checkpoint_tag" in sig.parameters


# ---- Test 5: restore() requires confirmed=True -----------------------------


def test_restore_requires_confirmed_true():
    """restore() must refuse to proceed when confirmed=False (default)."""
    mod = _import_checkpoint()
    mgr = mod.CheckpointManager(repo_root=".")
    result = mgr.restore("ms-checkpoint-fake-tag", confirmed=False)
    assert isinstance(result, dict)
    assert result.get("ok") is False
    error = result.get("error", "")
    assert error
    assert "confirm" in error.lower(), f"error should mention confirmation, got: {error!r}"


# ---- Test 6: /checkpoint handler registered in shell ----------------------


def test_checkpoint_handler_registered_in_shell():
    """shell.py must contain all four checkpoint command branches."""
    content = _SHELL_PATH.read_text(encoding="utf-8")
    assert 'command == "/checkpoint"' in content
    assert 'command == "/checkpoint-compare"' in content
    assert 'command == "/checkpoint-restore"' in content
    assert 'command == "/checkpoints"' in content


# ---- Test 7: /checkpoint-restore prompts for confirmation before restore --


def test_checkpoint_restore_prompts_for_confirmation():
    """The /checkpoint-restore handler must ask the user to confirm."""
    content = _SHELL_PATH.read_text(encoding="utf-8")
    assert "Confirm? [yes/no]" in content, (
        "/checkpoint-restore must prompt 'Confirm? [yes/no]' before restoring"
    )
    assert "confirmed=True" in content, (
        "restore() must be called with confirmed=True after confirmation"
    )


# ---- Test 8: create() dict shape for non-git directory --------------------


def test_create_returns_dict_shape_no_git():
    """create() must return correct dict shape even when not in a git repo."""
    mod = _import_checkpoint()
    with tempfile.TemporaryDirectory() as tmp:
        # Confirm the temp dir is NOT a git repo
        import subprocess
        rc = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=tmp, capture_output=True
        ).returncode
        if rc == 0:
            pytest.skip("temp dir is inside a git repo (nested), skipping non-git test")
        mgr = mod.CheckpointManager(repo_root=tmp)
        result = mgr.create("test-label")
    assert isinstance(result, dict)
    for key in ("ok", "tag", "stash", "error"):
        assert key in result, f"missing key: {key}"
    assert result["ok"] is False
    assert "not a git repository" in (result.get("error") or "")


# ---- Test 9: compare() dict shape for non-git directory -------------------


def test_compare_returns_dict_shape_no_git():
    """compare() must return correct dict shape even when not in a git repo."""
    mod = _import_checkpoint()
    with tempfile.TemporaryDirectory() as tmp:
        import subprocess
        rc = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=tmp, capture_output=True
        ).returncode
        if rc == 0:
            pytest.skip("temp dir is inside a git repo, skipping non-git test")
        mgr = mod.CheckpointManager(repo_root=tmp)
        result = mgr.compare("ms-checkpoint-fake")
    assert isinstance(result, dict)
    for key in ("files_changed", "lines_added", "lines_removed"):
        assert key in result, f"missing key: {key}"


# ---- Test 10: list_checkpoints() returns a list ----------------------------


def test_list_checkpoints_returns_list():
    """list_checkpoints() must always return a list."""
    mod = _import_checkpoint()
    with tempfile.TemporaryDirectory() as tmp:
        mgr = mod.CheckpointManager(repo_root=tmp)
        result = mgr.list_checkpoints()
    assert isinstance(result, list)


# ---- Test 11: auto-checkpoint code exists in shell._chat ------------------


def test_auto_checkpoint_in_chat_method():
    """shell.py _chat method must include auto-checkpoint logic."""
    content = _SHELL_PATH.read_text(encoding="utf-8")
    assert "implement" in content
    assert "auto_label" in content or "auto-checkpoint" in content.lower()


# ---- Test 12: _run_git() helper returns tuple of (int, str) ---------------


def test_run_git_helper():
    """_run_git() must return (returncode: int, output: str)."""
    mod = _import_checkpoint()
    mgr = mod.CheckpointManager(repo_root=".")
    assert hasattr(mgr, "_run_git")
    rc, out = mgr._run_git(["--version"])
    assert isinstance(rc, int)
    assert isinstance(out, str)


# ---- Test 13: checkpoint.py file exists on disk ----------------------------


def test_checkpoint_py_exists():
    """checkpoint.py must exist at the expected path."""
    checkpoint_path = _PKG_DIR / "checkpoint.py"
    assert checkpoint_path.exists(), f"checkpoint.py not found at {checkpoint_path}"
    assert checkpoint_path.is_file()


# ---- Test 14: create() tag name contains ms-checkpoint prefix in source ----


def test_create_makes_ms_checkpoint_tag():
    """Source must construct tag names with the 'ms-checkpoint' prefix."""
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    assert "ms-checkpoint-" in source, (
        "create() must build tag names with 'ms-checkpoint-' prefix"
    )


# ---- Test 15: create() tag name includes a timestamp -----------------------


def test_create_includes_timestamp():
    """Source must incorporate a timestamp (time.time or int(time)) in tag names."""
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    assert "time.time()" in source or "int(time" in source, (
        "create() must embed a unix timestamp in the tag name"
    )


# ---- Test 16: create() uses annotated git tags (git tag -a or -m) ----------


def test_create_uses_annotated_tags():
    """Source must use 'git tag -a' or include '-m' for annotated tags."""
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    has_annotated = '"tag", "-a"' in source or "tag -a" in source or '"-a"' in source
    assert has_annotated, (
        "create() must use annotated git tags ('git tag -a ... -m ...')"
    )


# ---- Test 17: restore() confirmed=False does not call git reset -------------


def test_restore_false_blocks_action():
    """restore(confirmed=False) must return ok=False without touching git reset."""
    mod = _import_checkpoint()
    mgr = mod.CheckpointManager(repo_root=".")

    # Patch _run_git to track calls
    calls = []
    original = mgr._run_git

    def recording_run_git(args):
        calls.append(args)
        return original(args)

    mgr._run_git = recording_run_git
    result = mgr.restore("ms-checkpoint-fake", confirmed=False)

    # Safety guard must fire before any git call
    assert result["ok"] is False
    reset_calls = [c for c in calls if "reset" in c]
    assert len(reset_calls) == 0, (
        f"restore(confirmed=False) must NOT call 'git reset', but got: {reset_calls}"
    )


# ---- Test 18: list_checkpoints() only returns ms-checkpoint-* tags ---------


def test_list_checkpoints_filters_ms_prefix():
    """TAG_PREFIX must be 'ms-checkpoint-' so list only returns ms-checkpoint-* entries."""
    mod = _import_checkpoint()
    assert hasattr(mod.CheckpointManager, "TAG_PREFIX")
    assert mod.CheckpointManager.TAG_PREFIX == "ms-checkpoint-", (
        f"TAG_PREFIX must be 'ms-checkpoint-', got {mod.CheckpointManager.TAG_PREFIX!r}"
    )
    # list_checkpoints source must filter by that prefix
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    assert "TAG_PREFIX" in source or "ms-checkpoint-*" in source


# ---- Test 19: restore(confirmed=True) calls git reset in source ------------


def test_restore_confirmed_true_executes():
    """Source must invoke 'git reset' when confirmed=True."""
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    assert "reset" in source and "--hard" in source, (
        "restore() must call 'git reset --hard' when confirmed=True"
    )


# ---- Test 20: CheckpointManager.__init__ accepts repo_root param -----------


def test_checkpoint_manager_init_takes_repo_root():
    """CheckpointManager constructor must accept a repo_root parameter."""
    mod = _import_checkpoint()
    sig = inspect.signature(mod.CheckpointManager.__init__)
    assert "repo_root" in sig.parameters, (
        "CheckpointManager.__init__ must have a 'repo_root' parameter"
    )
    # Instantiation with a path must not raise
    mgr = mod.CheckpointManager(repo_root=".")
    assert mgr.repo_root is not None


# ---- Test 21: no restore without confirmed — safety contract ---------------


def test_no_restore_without_confirmed():
    """restore() default must be confirmed=False, blocking accidental restores."""
    mod = _import_checkpoint()
    sig = inspect.signature(mod.CheckpointManager.restore)
    param = sig.parameters.get("confirmed")
    assert param is not None, "restore() must have a 'confirmed' parameter"
    assert param.default is False, (
        f"confirmed default must be False (got {param.default!r}), preventing accidental restores"
    )


# ---- Test 22: source file has substantial content --------------------------


def test_source_not_empty():
    """checkpoint.py must have substantial content (>100 lines)."""
    source = (_PKG_DIR / "checkpoint.py").read_text(encoding="utf-8")
    lines = [l for l in source.splitlines() if l.strip()]
    assert len(lines) > 100, (
        f"checkpoint.py appears too small ({len(lines)} non-empty lines); "
        "expected a fully implemented module"
    )
