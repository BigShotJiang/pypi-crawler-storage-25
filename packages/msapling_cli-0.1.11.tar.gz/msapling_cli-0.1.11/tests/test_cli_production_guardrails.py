"""Guardrail tests for CLI production readiness (P0/P1 items).
All tests are source-scan or import-only — no network, no auth required.
"""
from __future__ import annotations
import ast
import importlib
import inspect
import sys
from pathlib import Path
import pytest

CLI_ROOT = Path(__file__).parent.parent / "msapling_cli"
MAIN_PY = CLI_ROOT / "main.py"
SHELL_PY = CLI_ROOT / "shell.py"
AGENT_PY = CLI_ROOT / "agent.py"
API_PY = CLI_ROOT / "api.py"
PIPELINE_PY = CLI_ROOT / "pipeline.py"


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


# ── Pipeline module ────────────────────────────────────────────────────────

def test_pipeline_module_exists():
    assert PIPELINE_PY.exists(), "pipeline.py not found"

def test_pipeline_module_importable():
    spec = importlib.util.spec_from_file_location("msapling_cli.pipeline", PIPELINE_PY)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert hasattr(mod, "run_pipeline")
    assert hasattr(mod, "create_pipeline_wizard")
    assert hasattr(mod, "list_pipelines")
    assert hasattr(mod, "save_pipeline")
    assert hasattr(mod, "load_pipeline")

def test_pipeline_has_parallel_mode():
    src = _read(PIPELINE_PY)
    assert "parallel" in src
    assert "sequential" in src
    assert "fan-out" in src or "fan_out" in src

def test_pipeline_has_run_parallel_chats():
    src = _read(PIPELINE_PY)
    assert "run_parallel_chats" in src

def test_pipeline_wizard_uses_rich_prompt():
    src = _read(PIPELINE_PY)
    assert "Prompt.ask" in src or "Confirm.ask" in src


# ── API client new methods ────────────────────────────────────────────────

def test_api_has_create_snapshot():
    src = _read(API_PY)
    assert "create_snapshot" in src

def test_api_has_list_snapshots():
    src = _read(API_PY)
    assert "list_snapshots" in src

def test_api_has_create_flow_link():
    src = _read(API_PY)
    assert "create_flow_link" in src

def test_api_has_list_all_sessions():
    src = _read(API_PY)
    assert "list_all_sessions" in src

def test_api_has_generic_request():
    src = _read(API_PY)
    assert "_request" in src and "async def _request" in src


# ── main.py new commands ──────────────────────────────────────────────────

def test_main_has_sessions_command():
    src = _read(MAIN_PY)
    assert "def sessions" in src or "sessions" in src

def test_main_has_resume_command():
    src = _read(MAIN_PY)
    assert "def resume" in src

def test_main_has_swarm_command():
    src = _read(MAIN_PY)
    assert "def swarm" in src

def test_main_has_multi_command():
    src = _read(MAIN_PY)
    assert "def multi" in src

def test_main_has_parallel_command():
    src = _read(MAIN_PY)
    assert "def parallel" in src

def test_main_has_pipeline_commands():
    src = _read(MAIN_PY)
    assert "pipeline" in src.lower()

def test_main_has_handle_api_error():
    src = _read(MAIN_PY)
    assert "_handle_api_error" in src

def test_main_logout_has_confirmation():
    src = _read(MAIN_PY)
    # Find logout function and check for Confirm
    assert "Confirm" in src or "confirm" in src.lower()

def test_main_models_has_limit_flag():
    src = _read(MAIN_PY)
    assert "--all" in src or "limit" in src


# ── shell.py UX fixes ──────────────────────────────────────────────────────

def test_shell_clear_has_confirmation():
    src = _read(SHELL_PY)
    # /clear should have a confirmation step
    assert "Confirm" in src

def test_shell_has_rewind_buffer():
    src = _read(SHELL_PY)
    assert "_rewind_buffer" in src

def test_shell_has_undo_command():
    src = _read(SHELL_PY)
    assert "/undo" in src or "undo" in src

def test_shell_resume_has_search():
    src = _read(SHELL_PY)
    assert "--search" in src or "search" in src.lower()


# ── agent.py live output ────────────────────────────────────────────────────

def test_agent_announces_tool_execution():
    src = _read(AGENT_PY)
    # Should print tool name before executing
    assert "Tool:" in src or "tool_name" in src

def test_agent_shows_step_counter():
    src = _read(AGENT_PY)
    assert "Step" in src and ("step" in src or "MAX_AGENT_STEPS" in src)

def test_agent_shows_completion_summary():
    src = _read(AGENT_PY)
    assert "complete" in src.lower() or "steps" in src.lower()


# ── Wave AF new features ──────────────────────────────────────────────────────

STATUS_BAR_PY = CLI_ROOT / "status_bar.py"

def test_status_bar_shows_credits():
    src = _read(STATUS_BAR_PY)
    assert "fuel_credits" in src or "_credits" in src, "StatusBar must show fuel credits"

def test_status_bar_credits_update():
    src = _read(STATUS_BAR_PY)
    assert "credits" in src and "update" in src, "StatusBar.update() must accept credits param"

def test_main_projects_has_watch():
    src = _read(MAIN_PY)
    assert "--watch" in src or "watch" in src, "projects command must have --watch flag"

def test_main_chat_has_ephemeral():
    src = _read(MAIN_PY)
    assert "ephemeral" in src, "chat command must have --ephemeral flag"

def test_shell_ephemeral_sets_hidden():
    src = _read(SHELL_PY)
    assert "hidden" in src and "ephemeral" in src, "shell must pass hidden=True for ephemeral chats"

def test_api_create_chat_has_hidden_param():
    src = _read(API_PY)
    assert "hidden" in src, "api.create_chat() must support hidden=True parameter"


# ── Startup tips + status bar UX ─────────────────────────────────────────────

TUI_PY = CLI_ROOT / "tui.py"

def test_tui_has_tips_list():
    src = _read(TUI_PY)
    assert "_TIPS" in src, "tui.py must define _TIPS list for startup tips"

def test_tui_has_get_random_tip():
    src = _read(TUI_PY)
    assert "get_random_tip" in src, "tui.py must export get_random_tip()"

def test_tui_tips_count():
    """Must have at least 20 tips."""
    src = _read(TUI_PY)
    count = src.count('"💡') + src.count('"🔥') + src.count('"⚡') + src.count('"😤') + src.count('"☕') + src.count('"🧪') + src.count('"🌱')
    assert count >= 20, f"Expected 20+ tips, found {count}"

def test_tui_tips_shown_at_startup():
    src = _read(TUI_PY)
    assert "get_random_tip" in src and "render_session_header" in src, (
        "get_random_tip() must be called inside render_session_header()"
    )

def test_status_bar_shows_context_pct():
    src = _read(STATUS_BAR_PY)
    assert "_model_context_size" in src or "ctx_size" in src, (
        "status_bar.py must display context window usage %"
    )

def test_status_bar_shows_cwd():
    src = _read(STATUS_BAR_PY)
    assert "_short_cwd" in src or "project_root" in src, (
        "status_bar.py must display current working directory"
    )

def test_status_bar_context_bar_fn():
    src = _read(STATUS_BAR_PY)
    assert "_context_bar" in src, "status_bar.py must define _context_bar() helper"

def test_status_bar_model_context_map():
    src = _read(STATUS_BAR_PY)
    assert "_MODEL_CONTEXT" in src, "status_bar.py must define _MODEL_CONTEXT size map"

def test_model_context_covers_key_models():
    src = _read(STATUS_BAR_PY)
    for model in ("claude", "gpt-4o", "gemini", "llama"):
        assert model in src, f"_MODEL_CONTEXT must include {model} family"

def test_get_random_tip_returns_string():
    """Functional: get_random_tip() must return a non-empty string."""
    from msapling_cli.tui import get_random_tip
    tip = get_random_tip()
    assert isinstance(tip, str) and len(tip) > 10, f"Bad tip: {tip!r}"

def test_context_bar_color_coding():
    """_context_bar must return red for >75%, green for <25%."""
    from msapling_cli.status_bar import _context_bar
    _, high_color = _context_bar(90)
    _, low_color = _context_bar(10)
    assert "#ef4444" in high_color, "high ctx % must be red"
    assert "#22c55e" in low_color, "low ctx % must be green"
