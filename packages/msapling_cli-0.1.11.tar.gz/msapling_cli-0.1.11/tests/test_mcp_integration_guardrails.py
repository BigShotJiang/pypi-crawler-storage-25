"""
Source-scan guardrail tests for cli/msapling_cli/mcp/server.py

All tests are source-scan only — they read the server source file and
assert structural invariants without importing or executing server code
that touches OS file descriptors.
"""

from __future__ import annotations

import ast
import inspect
import pathlib
import re
import sys

import pytest

# ─── Resolve server source path ──────────────────────────────────────────────

_SERVER_FILE = pathlib.Path(__file__).parent.parent / "msapling_cli" / "mcp" / "server.py"
assert _SERVER_FILE.exists(), f"Server file not found: {_SERVER_FILE}"

_SOURCE = _SERVER_FILE.read_text(encoding="utf-8")

# ─── Expected tool names (11 tools) ──────────────────────────────────────────

EXPECTED_TOOL_NAMES = {
    "msapling_chat",
    "msapling_diff",
    "msapling_apply_diff",
    "msapling_search_files",
    "msapling_read_file",
    "msapling_write_file",
    "msapling_project_context",
    "msapling_cost_check",
    "msapling_models",
    "msapling_multi_chat",
    "msapling_swarm",
}

# ─── Tests ────────────────────────────────────────────────────────────────────


class TestToolDispatcher:
    """The server must expose a single dispatcher function for all tool calls."""

    def test_tool_dispatcher_function_exists(self):
        """A central async dispatcher function must exist (not just per-tool handlers)."""
        # _handle_tool is the dispatcher; confirm it is present as an async def
        assert "async def _handle_tool" in _SOURCE, (
            "Expected an async def _handle_tool() dispatcher in server.py"
        )

    def test_dispatcher_accepts_name_and_args(self):
        """_handle_tool must accept (name, args) parameters."""
        match = re.search(r"async def _handle_tool\s*\(([^)]*)\)", _SOURCE)
        assert match, "_handle_tool signature not found"
        params_raw = match.group(1)
        assert "name" in params_raw, "_handle_tool must have a 'name' parameter"
        assert "args" in params_raw, "_handle_tool must have an 'args' parameter"

    def test_dispatcher_handles_unknown_tool(self):
        """Dispatcher must have a fallback branch for unknown tool names."""
        assert '"Unknown tool:' in _SOURCE or "'Unknown tool:" in _SOURCE, (
            "Dispatcher must return an error for unknown tool names"
        )


class TestToolRegistration:
    """All 11 expected tool names must be registered in the TOOLS list."""

    def test_tools_list_constant_exists(self):
        """A module-level TOOLS constant must be present."""
        assert re.search(r"^TOOLS\s*=\s*\[", _SOURCE, re.MULTILINE), (
            "Module-level TOOLS = [...] list not found"
        )

    def test_all_11_tool_names_registered(self):
        """All 11 tool names must appear in the source as string literals."""
        missing = []
        for name in sorted(EXPECTED_TOOL_NAMES):
            # Each tool name should appear in the TOOLS list as a quoted string
            if f'"{name}"' not in _SOURCE and f"'{name}'" not in _SOURCE:
                missing.append(name)
        assert not missing, f"Tool names missing from source: {missing}"

    def test_exact_11_tools_count(self):
        """TOOLS list must contain exactly 11 entries (one per tool name)."""
        # Import only the TOOLS constant — avoids executing OS-level code
        import importlib.util
        spec = importlib.util.spec_from_file_location("_mcp_server_scan", _SERVER_FILE)
        mod = importlib.util.module_from_spec(spec)
        # Stub out the relative imports that touch the network/FS
        sys.modules.setdefault("msapling_cli", type(sys)("msapling_cli"))
        sys.modules["msapling_cli"].__version__ = "0.0.0-test"
        try:
            spec.loader.exec_module(mod)
        except Exception:
            # If the module cannot be fully loaded (missing deps), fall back to
            # counting "name": occurrences inside the TOOLS block.
            tool_names_in_source = re.findall(r'"name":\s*"(msapling_\w+)"', _SOURCE)
            assert len(tool_names_in_source) == 11, (
                f"Expected 11 tool registrations, found {len(tool_names_in_source)}: "
                f"{tool_names_in_source}"
            )
            return
        assert len(mod.TOOLS) == 11, (
            f"Expected 11 tools in TOOLS list, found {len(mod.TOOLS)}"
        )

    def test_msapling_chat_is_registered(self):
        """msapling_chat must be explicitly registered in TOOLS."""
        assert '"msapling_chat"' in _SOURCE or "'msapling_chat'" in _SOURCE, (
            "msapling_chat not found in source"
        )

    def test_each_registered_tool_has_name_description_inputschema(self):
        """Every tool dict in TOOLS must contain name, description, and inputSchema keys."""
        name_count = len(re.findall(r'"name":\s*"msapling_\w+"', _SOURCE))
        desc_count = len(re.findall(r'"description":\s*"', _SOURCE))
        schema_count = len(re.findall(r'"inputSchema"', _SOURCE))
        assert name_count >= 11, f"Expected >= 11 name fields, found {name_count}"
        assert desc_count >= 11, f"Expected >= 11 description fields, found {desc_count}"
        assert schema_count >= 11, f"Expected >= 11 inputSchema fields, found {schema_count}"


class TestStdioTransport:
    """stdio transport must be fully implemented."""

    def test_stdio_transport_handler_exists(self):
        """A serve() function implementing the stdio message loop must exist."""
        assert "def serve(" in _SOURCE, "serve() function not found in server.py"

    def test_serve_reads_messages_in_loop(self):
        """serve() must call _read_message in a loop."""
        assert "_read_message" in _SOURCE, (
            "_read_message() not referenced in server.py"
        )

    def test_serve_writes_messages(self):
        """serve() must call _write_message to respond."""
        assert "_write_message" in _SOURCE, (
            "_write_message() not referenced in server.py"
        )

    def test_stdio_is_listed_as_valid_transport(self):
        """'stdio' must appear in the TRANSPORT_CONFIG dict."""
        assert '"stdio"' in _SOURCE or "'stdio'" in _SOURCE, (
            "'stdio' not found in source"
        )

    def test_windows_raw_line_mode_handled(self):
        """Windows raw-line mode must be either implemented or explicitly mentioned."""
        has_raw_line_impl = "raw_line" in _SOURCE
        has_win32_note = "win32" in _SOURCE or "windows" in _SOURCE.lower()
        assert has_raw_line_impl or has_win32_note, (
            "Server must handle or explicitly note Windows raw-line mode "
            "(look for 'raw_line' or 'win32' in source)"
        )

    def test_windows_binary_mode_init(self):
        """Binary I/O init for Windows must be present (_init_binary_io or msvcrt)."""
        assert "_init_binary_io" in _SOURCE or "msvcrt" in _SOURCE, (
            "Windows binary mode init not found. Expected _init_binary_io() or msvcrt usage."
        )


class TestSSETransport:
    """SSE transport path must exist, even if currently a stub."""

    def test_sse_transport_path_exists(self):
        """'sse' must appear as a recognised transport string."""
        assert '"sse"' in _SOURCE or "'sse'" in _SOURCE, (
            "'sse' transport string not found in server.py"
        )

    def test_sse_in_transport_config(self):
        """TRANSPORT_CONFIG must document the sse transport."""
        assert re.search(r'["\']sse["\']', _SOURCE), (
            "TRANSPORT_CONFIG must have an 'sse' entry"
        )

    def test_sse_port_configured(self):
        """An SSE port constant or default port must be defined."""
        has_env_port = "MCP_SSE_PORT" in _SOURCE
        has_default_port = re.search(r"(sse.*port|port.*sse|3001|8765)", _SOURCE, re.IGNORECASE)
        assert has_env_port or has_default_port, (
            "SSE transport must define a port (MCP_SSE_PORT env var or numeric default)"
        )

    def test_sse_events_endpoint_defined(self):
        """An SSE /events endpoint path must be present in the source."""
        assert "/events" in _SOURCE, (
            "SSE transport must define a /events endpoint path"
        )

    def test_sse_rpc_endpoint_defined(self):
        """A POST /rpc endpoint path must be present in the source."""
        assert "/rpc" in _SOURCE, (
            "SSE transport must define a /rpc endpoint path"
        )

    def test_sse_content_type_defined(self):
        """SSE content type (text/event-stream) must be referenced."""
        assert "text/event-stream" in _SOURCE, (
            "SSE transport must set Content-Type: text/event-stream"
        )

    def test_sse_data_frame_format(self):
        """SSE data frames must use 'data: ' prefix per SSE spec."""
        assert "data: " in _SOURCE or 'b"data: "' in _SOURCE or "b'data: '" in _SOURCE, (
            "SSE frames must use 'data: ' prefix per SSE specification"
        )

    def test_graceful_fallback_if_aiohttp_missing(self):
        """If aiohttp is not installed, the server must fall back gracefully."""
        # The source should try to import aiohttp and handle ImportError
        has_try_import = re.search(
            r"(import aiohttp|from aiohttp|ImportError.*aiohttp|aiohttp.*ImportError)",
            _SOURCE, re.IGNORECASE
        )
        has_fallback_note = re.search(
            r"(fall\s*back|fallback|stdio)",
            _SOURCE, re.IGNORECASE
        )
        assert has_try_import and has_fallback_note, (
            "Server must attempt to import aiohttp and fall back to stdio on ImportError"
        )


class TestCleanDisconnect:
    """Server must have a clean disconnect / shutdown path."""

    def test_clean_disconnect_on_none_message(self):
        """serve() must break the read loop when _read_message() returns None."""
        # The pattern: if msg is None: break (or equivalent)
        assert re.search(r"if msg is None", _SOURCE) or re.search(r"break", _SOURCE), (
            "serve() must exit cleanly when _read_message returns None"
        )

    def test_loop_close_called_on_exit(self):
        """The asyncio event loop must be closed in a finally block."""
        assert "loop.close()" in _SOURCE, (
            "asyncio event loop must be closed via loop.close() in a finally block"
        )

    def test_serve_has_finally_block(self):
        """serve() must have a finally block for cleanup."""
        assert "finally:" in _SOURCE, (
            "serve() must have a finally: block for teardown"
        )
