"""Guardrail tests for precompact_hook.py.

Run with:
    python -m pytest cli/tests/test_precompact_hook_guardrails.py -q
"""
from __future__ import annotations

import importlib.util
import inspect
import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import patch

import pytest

# ── Helpers ─────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_MODULE_PATH = _PKG_DIR / "precompact_hook.py"


def _import_module():
    _mod_name = "msapling_cli.precompact_hook"
    if _mod_name in sys.modules:
        return sys.modules[_mod_name]
    spec = importlib.util.spec_from_file_location(_mod_name, str(_MODULE_PATH))
    mod = importlib.util.module_from_spec(spec)
    # Register before exec so dataclass type resolution works in Python 3.13+
    sys.modules[_mod_name] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def _make_shell_state(
    messages: Optional[List[Dict[str, str]]] = None,
    model: str = "claude-3-5-sonnet",
    turn_count: int = 5,
    cost_total: float = 0.012,
    session_id: str = "sess-test-001",
    files_touched: Optional[List[str]] = None,
) -> Dict[str, Any]:
    if messages is None:
        messages = [
            {"role": "user", "content": "Let's refactor the auth module."},
            {
                "role": "assistant",
                "content": (
                    "I decided to use JWT tokens for session management. "
                    "Will use auth_service.py as the central auth point. "
                    "The approach: decompose into sub-services."
                ),
            },
            {
                "role": "user",
                "content": "Getting error: ImportError: cannot import 'jwt' from 'jose'",
            },
            {
                "role": "assistant",
                "content": "The error is because python-jose is not installed. Run pip install python-jose.",
            },
        ]
    return {
        "messages": messages,
        "model": model,
        "turn_count": turn_count,
        "cost_total": cost_total,
        "session_id": session_id,
        "files_touched": files_touched or ["backend/auth_service.py", "backend/routers/auth.py"],
    }


# ── Test 1: Module imports cleanly ───────────────────────────────────────────

def test_module_imports():
    """precompact_hook.py must import cleanly with no side effects."""
    mod = _import_module()
    assert mod is not None


# ── Test 2: PreCompactContext dataclass exists ────────────────────────────────

def test_precompact_context_class_exists():
    """PreCompactContext must be a dataclass."""
    mod = _import_module()
    import dataclasses
    assert hasattr(mod, "PreCompactContext")
    assert dataclasses.is_dataclass(mod.PreCompactContext)


# ── Test 3: PreCompactContext has all required fields ────────────────────────

def test_precompact_context_has_required_fields():
    """PreCompactContext must have all spec-required fields."""
    mod = _import_module()
    ctx = mod.PreCompactContext()
    required = [
        "decisions_made",
        "files_modified",
        "active_task",
        "errors_encountered",
        "model_used",
        "turn_count",
        "cost_so_far",
    ]
    for field in required:
        assert hasattr(ctx, field), f"Missing field: {field}"


# ── Test 4: capture_precompact_context extracts decisions ─────────────────────

def test_capture_extracts_decisions():
    """capture_precompact_context() must extract decision-indicating phrases."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    assert isinstance(ctx.decisions_made, list)
    # The test messages contain "decided", "will use", "approach"
    assert len(ctx.decisions_made) > 0, (
        "Should have extracted at least one decision from messages containing "
        "'decided', 'will use', 'approach'"
    )


# ── Test 5: capture extracts errors from messages ────────────────────────────

def test_capture_extracts_errors():
    """capture_precompact_context() must extract error-related lines."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    assert isinstance(ctx.errors_encountered, list)
    # Messages contain "ImportError" and "error"
    assert len(ctx.errors_encountered) > 0, (
        "Should have extracted error lines from messages containing 'ImportError'"
    )


# ── Test 6: capture extracts active_task from last user message ───────────────

def test_capture_extracts_active_task():
    """capture_precompact_context() must set active_task to the last user message."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    assert isinstance(ctx.active_task, str)
    assert len(ctx.active_task) > 0
    # Last user message is "Getting error: ImportError..."
    assert "error" in ctx.active_task.lower() or "ImportError" in ctx.active_task


# ── Test 7: capture extracts files from shell_state.files_touched ─────────────

def test_capture_includes_files_touched():
    """capture_precompact_context() must include files from shell_state['files_touched']."""
    mod = _import_module()
    state = _make_shell_state(files_touched=["backend/auth_service.py", "frontend/App.tsx"])
    ctx = mod.capture_precompact_context(state)
    assert "backend/auth_service.py" in ctx.files_modified
    assert "frontend/App.tsx" in ctx.files_modified


# ── Test 8: persist writes to correct path ───────────────────────────────────

def test_persist_writes_to_correct_path():
    """persist_precompact_context() must write to ~/.msapling/precompact/<sid>_<ts>.json."""
    mod = _import_module()
    state = _make_shell_state(session_id="test-persist-001")
    ctx = mod.capture_precompact_context(state)

    with tempfile.TemporaryDirectory() as tmp:
        fake_dir = Path(tmp) / "precompact"
        # Patch the module-level _PRECOMPACT_DIR
        with patch.object(mod, "_PRECOMPACT_DIR", fake_dir):
            result_path = mod.persist_precompact_context(ctx, "test-persist-001")

        assert result_path.exists()
        assert "test-persist-001" in result_path.name
        assert result_path.suffix == ".json"


# ── Test 9: persist output is valid JSON ─────────────────────────────────────

def test_persist_output_is_valid_json():
    """persist_precompact_context() must write valid JSON."""
    mod = _import_module()
    state = _make_shell_state(session_id="test-json-001")
    ctx = mod.capture_precompact_context(state)

    with tempfile.TemporaryDirectory() as tmp:
        fake_dir = Path(tmp) / "precompact"
        with patch.object(mod, "_PRECOMPACT_DIR", fake_dir):
            result_path = mod.persist_precompact_context(ctx, "test-json-001")
        data = json.loads(result_path.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    assert "decisions_made" in data
    assert "files_modified" in data
    assert "active_task" in data


# ── Test 10: load_latest returns most recent file ─────────────────────────────

def test_load_latest_returns_newest():
    """load_latest_precompact() must return the newest snapshot when multiple exist."""
    mod = _import_module()

    with tempfile.TemporaryDirectory() as tmp:
        fake_dir = Path(tmp) / "precompact"
        fake_dir.mkdir(parents=True)

        # Write two files with different timestamps
        sid = "multi-test"
        data_old = {"decisions_made": ["old decision"], "files_modified": [], "active_task": "old",
                    "errors_encountered": [], "model_used": "old-model", "turn_count": 1,
                    "cost_so_far": 0.001, "captured_at": 1000.0, "session_id": sid}
        data_new = {"decisions_made": ["new decision"], "files_modified": [], "active_task": "new",
                    "errors_encountered": [], "model_used": "new-model", "turn_count": 5,
                    "cost_so_far": 0.01, "captured_at": 9999.0, "session_id": sid}

        old_file = fake_dir / f"{sid}_1000000.json"
        new_file = fake_dir / f"{sid}_9999000.json"
        old_file.write_text(json.dumps(data_old), encoding="utf-8")
        time.sleep(0.02)  # Ensure mtime differs
        new_file.write_text(json.dumps(data_new), encoding="utf-8")

        with patch.object(mod, "_PRECOMPACT_DIR", fake_dir):
            result = mod.load_latest_precompact(sid)

    assert result is not None
    assert result.active_task == "new"
    assert result.model_used == "new-model"


# ── Test 11: load_latest returns None when no files exist ─────────────────────

def test_load_latest_returns_none_when_missing():
    """load_latest_precompact() must return None when no snapshots exist for a session."""
    mod = _import_module()
    with tempfile.TemporaryDirectory() as tmp:
        fake_dir = Path(tmp) / "precompact"
        # Don't create the dir at all
        with patch.object(mod, "_PRECOMPACT_DIR", fake_dir):
            result = mod.load_latest_precompact("nonexistent-session")
    assert result is None


# ── Test 12: format_for_injection returns non-empty string ───────────────────

def test_format_for_injection_returns_non_empty():
    """format_for_injection() must return a non-empty string."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    result = mod.format_for_injection(ctx)
    assert isinstance(result, str)
    assert len(result) > 20


# ── Test 13: format_for_injection includes key sentinel text ─────────────────

def test_format_for_injection_contains_sentinel():
    """format_for_injection() output must contain 'Context from before compaction:'."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    result = mod.format_for_injection(ctx)
    assert "Context from before compaction:" in result


# ── Test 14: format_for_injection includes model and cost ─────────────────────

def test_format_for_injection_includes_model_cost():
    """format_for_injection() must include model name and cost."""
    mod = _import_module()
    state = _make_shell_state(model="claude-opus-4", cost_total=0.555)
    ctx = mod.capture_precompact_context(state)
    result = mod.format_for_injection(ctx)
    assert "claude-opus-4" in result
    assert "0.5550" in result or "0.555" in result


# ── Test 15: Empty session produces valid empty PreCompactContext ─────────────

def test_empty_session_produces_valid_context():
    """capture_precompact_context() must not crash on an empty session."""
    mod = _import_module()
    empty_state: Dict[str, Any] = {
        "messages": [],
        "model": "",
        "turn_count": 0,
        "cost_total": 0.0,
        "session_id": "empty-session",
        "files_touched": [],
    }
    ctx = mod.capture_precompact_context(empty_state)
    assert isinstance(ctx, mod.PreCompactContext)
    assert isinstance(ctx.decisions_made, list)
    assert isinstance(ctx.files_modified, list)
    assert isinstance(ctx.errors_encountered, list)
    assert ctx.active_task == ""


# ── Test 16: PreCompactContext is JSON-serializable ───────────────────────────

def test_precompact_context_is_json_serializable():
    """PreCompactContext.to_dict() must produce a JSON-serializable structure."""
    mod = _import_module()
    state = _make_shell_state()
    ctx = mod.capture_precompact_context(state)
    d = ctx.to_dict()
    # Must not raise
    encoded = json.dumps(d)
    assert isinstance(encoded, str)
    # Must round-trip
    decoded = json.loads(encoded)
    assert isinstance(decoded, dict)


# ── Test 17: from_dict tolerates missing keys ─────────────────────────────────

def test_from_dict_tolerates_missing_keys():
    """PreCompactContext.from_dict({}) must succeed with all defaults."""
    mod = _import_module()
    ctx = mod.PreCompactContext.from_dict({})
    assert isinstance(ctx, mod.PreCompactContext)
    assert ctx.decisions_made == []
    assert ctx.files_modified == []
    assert ctx.active_task == ""
    assert ctx.model_used == ""
    assert ctx.turn_count == 0
    assert ctx.cost_so_far == 0.0


# ── Test 18: precompact_hook.py file exists and has substantial content ───────

def test_module_file_exists_and_substantial():
    """precompact_hook.py must exist and have >100 non-empty lines."""
    assert _MODULE_PATH.exists(), f"precompact_hook.py not found at {_MODULE_PATH}"
    lines = [l for l in _MODULE_PATH.read_text(encoding="utf-8").splitlines() if l.strip()]
    assert len(lines) > 100, f"precompact_hook.py too small ({len(lines)} lines)"


# ── Test 19: All public functions are callable ─────────────────────────────────

def test_all_public_functions_exist():
    """All four public functions must be importable and callable."""
    mod = _import_module()
    for name in (
        "capture_precompact_context",
        "persist_precompact_context",
        "load_latest_precompact",
        "format_for_injection",
    ):
        assert hasattr(mod, name), f"Missing function: {name}"
        assert callable(getattr(mod, name))


# ── Test 20: shell.py wires precompact into _compact_context ─────────────────

def test_shell_wires_precompact_into_compact():
    """shell.py must call precompact_hook in _compact_context."""
    shell_path = _PKG_DIR / "shell.py"
    content = shell_path.read_text(encoding="utf-8")
    assert "precompact_hook" in content, (
        "shell.py must import or reference precompact_hook"
    )
    assert "capture_precompact_context" in content
    assert "persist_precompact_context" in content


# ── Test 21: shell.py wires load_latest_precompact on session start ───────────

def test_shell_loads_precompact_on_start():
    """shell.py must call load_latest_precompact during session start."""
    shell_path = _PKG_DIR / "shell.py"
    content = shell_path.read_text(encoding="utf-8")
    assert "load_latest_precompact" in content
    assert "format_for_injection" in content


# ── Test 22: persist_precompact_context accepts str session_id ────────────────

def test_persist_accepts_str_session_id():
    """persist_precompact_context() signature must accept a session_id str param."""
    mod = _import_module()
    sig = inspect.signature(mod.persist_precompact_context)
    assert "session_id" in sig.parameters


# ── Test 23: to_dict() / from_dict() round-trip preserves values ─────────────

def test_roundtrip_serialization():
    """PreCompactContext to_dict() → from_dict() must preserve all values."""
    mod = _import_module()
    original = mod.PreCompactContext(
        decisions_made=["use JWT", "refactor auth"],
        files_modified=["backend/auth.py"],
        active_task="fix login bug",
        errors_encountered=["ImportError: jwt"],
        model_used="claude-3-5-sonnet",
        turn_count=7,
        cost_so_far=0.0123,
        captured_at=1713360000.0,
        session_id="rt-test",
    )
    d = original.to_dict()
    restored = mod.PreCompactContext.from_dict(d)
    assert restored.decisions_made == original.decisions_made
    assert restored.files_modified == original.files_modified
    assert restored.active_task == original.active_task
    assert restored.model_used == original.model_used
    assert restored.turn_count == original.turn_count
    assert abs(restored.cost_so_far - original.cost_so_far) < 1e-9
    assert restored.session_id == original.session_id
