"""Guardrail tests for the non-interactive agent session (msapling run).

Covers:
 1.  `run` command is registered on the app
 2.  --json flag outputs valid JSON
 3.  --stream flag enables streaming
 4.  --project flag sets project context
 5.  --model flag overrides model
 6.  Exit code 0 on success
 7.  Exit code 1 on API error
 8.  Exit code 2 on auth error (no token)
 9.  Exit code 3 on quota exceeded (402)
10.  --timeout flag is respected
11.  Stdin piped input works
12.  --file reads prompt from file
"""
from __future__ import annotations

import asyncio
import io
import json
import sys
import tempfile
from pathlib import Path
from typing import AsyncGenerator, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

# ─── App under test ─────────────────────────────────────────────────────────

from msapling_cli import main
from msapling_cli.config import Settings

runner = CliRunner()

# ─── Helpers / stubs ────────────────────────────────────────────────────────

_SETTINGS = Settings(
    api_url="https://api.msapling.com",
    default_model="google/gemini-2.0-flash-001",
)

_USAGE_CHUNK = {"type": "usage", "usage": {"total_tokens": 42}, "cost": 0.0001}
_CONTENT_CHUNKS = [
    {"content": "Hello "},
    {"content": "world"},
    _USAGE_CHUNK,
]


async def _fake_stream(*args, **kwargs) -> AsyncGenerator[dict, None]:
    """Yield a minimal valid stream sequence."""
    for chunk in _CONTENT_CHUNKS:
        yield chunk


async def _fake_ensure_utility_chat(self, *, model: str) -> str:
    return "test-chat-id"


async def _fake_ensure_server_chat(self, **kwargs) -> str:
    return "project-chat-id"


async def _fake_close(self) -> None:
    return None


def _make_client(
    stream_chunks=None,
    raise_on_stream: Optional[Exception] = None,
    project_chat: bool = False,
):
    """Build a stub MSaplingClient class."""
    chunks = stream_chunks if stream_chunks is not None else _CONTENT_CHUNKS

    class _StubClient:
        def __init__(self, *a, **kw):
            pass

        async def ensure_utility_chat(self, *, model: str) -> str:
            return "util-chat-id"

        async def ensure_server_chat(self, **kw) -> str:
            return "proj-chat-id"

        async def stream_chat(self, chat_id, prompt, model, **kwargs):
            if raise_on_stream is not None:
                raise raise_on_stream
            for chunk in chunks:
                yield chunk

        async def close(self) -> None:
            return None

    return _StubClient


# ─── 1. `run` command is registered ─────────────────────────────────────────

def test_run_command_registered():
    """'run' subcommand must be present in the Typer app.

    Typer derives the CLI name from the callback function name when @app.command()
    is used without an explicit name= argument, so we check both the explicit
    ``name`` attribute *and* the callback ``__name__`` to handle both cases.
    """
    registered = main.app.registered_commands
    # Check by explicit name or by callback function name
    found = any(
        (cmd.name == "run") or (cmd.callback and cmd.callback.__name__ == "run")
        for cmd in registered
    )
    names_info = [(cmd.name, cmd.callback.__name__ if cmd.callback else None) for cmd in registered]
    assert found, f"'run' command not found in app. Registered: {names_info}"


# ─── 2. --json flag outputs valid JSON ───────────────────────────────────────

def test_run_json_flag_outputs_valid_json(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "get_token", lambda: "fake-token")
    monkeypatch.setattr(main, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(main, "MSaplingClient", _make_client())

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--json", "Hello world"])
    assert result.exit_code == 0, f"stdout={result.stdout!r} stderr={result.stderr!r}"
    output = result.stdout.strip()
    # Output may contain multiple JSON lines (streaming); parse the last non-empty line
    lines = [ln for ln in output.splitlines() if ln.strip()]
    assert lines, "Expected at least one JSON line"
    data = json.loads(lines[-1])
    assert "response" in data or "type" in data, f"Unexpected JSON shape: {data}"


# ─── 3. --stream flag enables streaming ──────────────────────────────────────

def test_run_stream_flag_produces_output(monkeypatch):
    monkeypatch.setattr(main, "get_token", lambda: "fake-token")
    monkeypatch.setattr(main, "get_settings", lambda: _SETTINGS)

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--stream", "Stream me"])
    assert result.exit_code == 0, f"exit={result.exit_code} stdout={result.stdout!r}"
    assert "Hello" in result.stdout or "world" in result.stdout


def test_run_stream_json_emits_content_type_chunks(monkeypatch):
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--stream", "--json", "Stream JSON"])
    assert result.exit_code == 0
    lines = [ln for ln in result.stdout.splitlines() if ln.strip()]
    assert len(lines) >= 1
    # At least one line should be a content or done chunk
    types_seen = set()
    for ln in lines:
        try:
            obj = json.loads(ln)
            types_seen.add(obj.get("type"))
        except json.JSONDecodeError:
            pass
    assert "content" in types_seen or "done" in types_seen, (
        f"Expected 'content' or 'done' type chunks. Got: {types_seen}"
    )


# ─── 4. --project flag sets project context ──────────────────────────────────

def test_run_project_flag_uses_ensure_server_chat(monkeypatch):
    """When --project is given, ensure_server_chat must be called (not ensure_utility_chat)."""
    called_with: dict = {}

    class _ProjectClient:
        def __init__(self, *a, **kw):
            pass

        async def ensure_server_chat(self, **kw):
            called_with.update(kw)
            return "proj-id"

        async def ensure_utility_chat(self, **kw):
            raise AssertionError("ensure_utility_chat should NOT be called when --project is given")

        async def stream_chat(self, chat_id, prompt, model, **kwargs):
            for chunk in _CONTENT_CHUNKS:
                yield chunk

        async def close(self):
            return None

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _ProjectClient)

    result = runner.invoke(main.app, ["run", "--project", "DevTeam", "Do something"])
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"
    assert called_with.get("project_name") == "DevTeam"


# ─── 5. --model flag overrides model ─────────────────────────────────────────

def test_run_model_flag_overrides_default(monkeypatch):
    used_model: dict = {}

    class _ModelClient:
        def __init__(self, *a, **kw):
            pass

        async def ensure_utility_chat(self, *, model: str) -> str:
            used_model["model"] = model
            return "m-chat"

        async def stream_chat(self, chat_id, prompt, model, **kwargs):
            for chunk in _CONTENT_CHUNKS:
                yield chunk

        async def close(self):
            return None

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _ModelClient)

    result = runner.invoke(
        main.app,
        ["run", "--model", "anthropic/claude-3-haiku", "test prompt"],
    )
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"
    assert used_model.get("model") == "anthropic/claude-3-haiku"


# ─── 6. Exit code 0 on success ───────────────────────────────────────────────

def test_run_exit_code_0_on_success(monkeypatch):
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "Hello"])
    assert result.exit_code == 0, f"Expected exit 0, got {result.exit_code}. out={result.stdout!r}"


# ─── 7. Exit code 1 on API error ─────────────────────────────────────────────

def test_run_exit_code_1_on_api_error(monkeypatch):
    from msapling_cli.api import APIError
    from msapling_cli import noninteractive_session as nis

    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(
        nis, "MSaplingClient",
        _make_client(raise_on_stream=APIError("Internal server error", status_code=500)),
    )

    result = runner.invoke(main.app, ["run", "Test"])
    assert result.exit_code == 1, f"Expected exit 1, got {result.exit_code}. out={result.stdout!r}"


# ─── 8. Exit code 2 on auth error ────────────────────────────────────────────

def test_run_exit_code_2_on_auth_error_no_token(monkeypatch):
    """When no token is present, run must exit with code 2."""
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: None)
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)

    result = runner.invoke(main.app, ["run", "Hello"])
    assert result.exit_code == 2, f"Expected exit 2, got {result.exit_code}. out={result.stdout!r}"


def test_run_exit_code_2_on_401_response(monkeypatch):
    """A 401 APIError must map to exit code 2."""
    from msapling_cli.api import APIError
    from msapling_cli import noninteractive_session as nis

    monkeypatch.setattr(nis, "get_token", lambda: "stale-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(
        nis, "MSaplingClient",
        _make_client(raise_on_stream=APIError("Unauthorized", status_code=401)),
    )

    result = runner.invoke(main.app, ["run", "Test"])
    assert result.exit_code == 2, f"Expected exit 2, got {result.exit_code}. out={result.stdout!r}"


# ─── 9. Exit code 3 on quota exceeded ────────────────────────────────────────

def test_run_exit_code_3_on_402(monkeypatch):
    """HTTP 402 (insufficient credits) must map to exit code 3."""
    from msapling_cli.api import APIError
    from msapling_cli import noninteractive_session as nis

    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(
        nis, "MSaplingClient",
        _make_client(raise_on_stream=APIError("No fuel", status_code=402)),
    )

    result = runner.invoke(main.app, ["run", "Test"])
    assert result.exit_code == 3, f"Expected exit 3, got {result.exit_code}. out={result.stdout!r}"


def test_run_exit_code_3_on_429(monkeypatch):
    """HTTP 429 (rate limited) must map to exit code 3."""
    from msapling_cli.api import APIError
    from msapling_cli import noninteractive_session as nis

    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(
        nis, "MSaplingClient",
        _make_client(raise_on_stream=APIError("Rate limited", status_code=429)),
    )

    result = runner.invoke(main.app, ["run", "Test"])
    assert result.exit_code == 3, f"Expected exit 3, got {result.exit_code}. out={result.stdout!r}"


# ─── 10. --timeout flag is respected ─────────────────────────────────────────

def test_run_timeout_flag_accepted(monkeypatch):
    """--timeout must be accepted as a valid option (no parse error)."""
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--timeout", "60", "Hello"])
    # Should not produce a "No such option" error
    assert "No such option" not in result.stdout
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"


def test_run_timeout_triggers_exit_1(monkeypatch):
    """When the coroutine times out, exit code must be 1."""
    import asyncio as _asyncio

    async def _slow_stream(*args, **kwargs):
        await _asyncio.sleep(9999)
        yield {"content": "never"}

    class _SlowClient:
        def __init__(self, *a, **kw):
            pass

        async def ensure_utility_chat(self, **kw):
            return "slow-chat"

        async def stream_chat(self, *a, **kw):
            async for chunk in _slow_stream(*a, **kw):
                yield chunk

        async def close(self):
            return None

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _SlowClient)

    # Use a very short timeout so the test doesn't stall
    result = runner.invoke(main.app, ["run", "--timeout", "0.01", "Slow prompt"])
    assert result.exit_code == 1, f"Expected exit 1 on timeout, got {result.exit_code}"


# ─── 11. Stdin piped input works ─────────────────────────────────────────────

def test_run_stdin_piped_input(monkeypatch):
    """When prompt argument is absent and stdin is piped, read from stdin."""
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    # CliRunner with input= simulates piped stdin
    result = runner.invoke(main.app, ["run"], input="Analyze this code\n")
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"


def test_run_stdin_flag_reads_stdin(monkeypatch):
    """--stdin flag should explicitly read from stdin even when no prompt arg given."""
    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--stdin"], input="piped content\n")
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"


# ─── 12. --file reads prompt from file ───────────────────────────────────────

def test_run_file_reads_prompt(monkeypatch, tmp_path):
    """--file must read the prompt from the given file path."""
    prompt_file = tmp_path / "prompt.txt"
    prompt_file.write_text("Review this code for bugs", encoding="utf-8")

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _make_client())

    result = runner.invoke(main.app, ["run", "--file", str(prompt_file)])
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"


def test_run_file_missing_exits_with_error(monkeypatch, tmp_path):
    """--file pointing to a non-existent file must produce a non-zero exit."""
    result = runner.invoke(main.app, ["run", "--file", str(tmp_path / "nonexistent.txt")])
    assert result.exit_code != 0


# ─── Module structure guardrails ──────────────────────────────────────────────

def test_noninteractive_session_module_importable():
    """noninteractive_session.py must be importable."""
    import msapling_cli.noninteractive_session  # noqa: F401


def test_exit_code_constants_defined():
    """EXIT_SUCCESS / EXIT_API_ERROR / EXIT_AUTH_ERROR / EXIT_QUOTA_EXCEEDED must exist."""
    from msapling_cli.noninteractive_session import (
        EXIT_API_ERROR,
        EXIT_AUTH_ERROR,
        EXIT_QUOTA_EXCEEDED,
        EXIT_SUCCESS,
    )
    assert EXIT_SUCCESS == 0
    assert EXIT_API_ERROR == 1
    assert EXIT_AUTH_ERROR == 2
    assert EXIT_QUOTA_EXCEEDED == 3


def test_run_noninteractive_function_exists():
    """run_noninteractive async function must be exported from the module."""
    import asyncio
    from msapling_cli.noninteractive_session import run_noninteractive
    assert asyncio.iscoroutinefunction(run_noninteractive)


def test_resolve_prompt_function_exists():
    """_resolve_prompt helper must be present."""
    from msapling_cli.noninteractive_session import _resolve_prompt
    assert callable(_resolve_prompt)


def test_resolve_prompt_from_arg():
    from msapling_cli.noninteractive_session import _resolve_prompt
    assert _resolve_prompt("hello", None, False) == "hello"


def test_resolve_prompt_from_file(tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("file prompt", encoding="utf-8")
    from msapling_cli.noninteractive_session import _resolve_prompt
    assert _resolve_prompt(None, f, False) == "file prompt"


def test_resolve_prompt_stdin_appended_to_file(tmp_path):
    f = tmp_path / "p.txt"
    f.write_text("base", encoding="utf-8")
    from msapling_cli.noninteractive_session import _resolve_prompt
    result = _resolve_prompt(None, f, False, extra_stdin="appended")
    assert "base" in result and "appended" in result


def test_classify_http_error_maps_correctly():
    from msapling_cli.noninteractive_session import (
        EXIT_API_ERROR,
        EXIT_AUTH_ERROR,
        EXIT_QUOTA_EXCEEDED,
        _classify_http_error,
    )
    assert _classify_http_error(401) == EXIT_AUTH_ERROR
    assert _classify_http_error(403) == EXIT_AUTH_ERROR
    assert _classify_http_error(402) == EXIT_QUOTA_EXCEEDED
    assert _classify_http_error(429) == EXIT_QUOTA_EXCEEDED
    assert _classify_http_error(500) == EXIT_API_ERROR
    assert _classify_http_error(503) == EXIT_API_ERROR


def test_resolve_noninteractive_model_falls_back_from_ollama_default(monkeypatch):
    from msapling_cli.noninteractive_session import _resolve_noninteractive_model
    monkeypatch.delenv("MSAPLING_PROVIDER", raising=False)
    monkeypatch.delenv("MSAPLING_OLLAMA_URL", raising=False)
    resolved = _resolve_noninteractive_model(None, "ollama/qwen2.5-coder:3b")
    assert resolved == "google/gemini-2.0-flash-001"


def test_resolve_noninteractive_model_keeps_explicit_model(monkeypatch):
    from msapling_cli.noninteractive_session import _resolve_noninteractive_model
    monkeypatch.delenv("MSAPLING_PROVIDER", raising=False)
    monkeypatch.delenv("MSAPLING_OLLAMA_URL", raising=False)
    resolved = _resolve_noninteractive_model("ollama/qwen2.5-coder:3b", "google/gemini-2.0-flash-001")
    assert resolved == "ollama/qwen2.5-coder:3b"


def test_run_disables_history_and_releases_stale_lock(monkeypatch):
    calls = {"force_unlock": 0, "history_flags": []}

    class _LockAwareClient:
        def __init__(self, *a, **kw):
            pass

        async def ensure_utility_chat(self, *, model: str) -> str:
            return "util-chat-id"

        async def force_release_lock(self, chat_id: str) -> bool:
            calls["force_unlock"] += 1
            return True

        async def stream_chat(self, chat_id, prompt, model, **kwargs):
            calls["history_flags"].append(kwargs.get("history_enabled"))
            for chunk in _CONTENT_CHUNKS:
                yield chunk

        async def close(self):
            return None

    from msapling_cli import noninteractive_session as nis
    monkeypatch.setattr(nis, "get_token", lambda: "fake-token")
    monkeypatch.setattr(nis, "get_settings", lambda: _SETTINGS)
    monkeypatch.setattr(nis, "MSaplingClient", _LockAwareClient)

    result = runner.invoke(main.app, ["run", "lock + history check"])
    assert result.exit_code == 0, f"exit={result.exit_code} out={result.stdout!r}"
    # One best-effort release before the request + one in finally cleanup.
    assert calls["force_unlock"] == 2
    assert calls["history_flags"] == [False]
