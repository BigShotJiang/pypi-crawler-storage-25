"""Guardrail tests for CLI context building commands: scan and summarize.

Test strategy:
  - Source-level: assert key identifiers exist in main.py so accidental deletions
    are caught immediately.
  - Functional: exercise the scan command logic directly via temp directories and
    mocked MSapling/Ollama clients so no external services are required.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_CLI_ROOT = Path(__file__).parent.parent / "msapling_cli"
_MAIN_PY = _CLI_ROOT / "main.py"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SOURCE: str = ""


def _src() -> str:
    global _SOURCE
    if not _SOURCE:
        _SOURCE = _MAIN_PY.read_text(encoding="utf-8")
    return _SOURCE


# ---------------------------------------------------------------------------
# SOURCE-LEVEL GUARDRAILS
# ---------------------------------------------------------------------------


class TestSourceGuardrails:
    """Assert that key identifiers exist in main.py."""

    def test_scan_command_registered(self):
        """scan command must be registered on the app."""
        src = _src()
        assert "def scan(" in src, "scan() function not found in main.py"

    def test_max_files_option_present(self):
        """--max-files option must be present in the scan command."""
        src = _src()
        assert "--max-files" in src, "--max-files option missing from scan command"

    def test_exclude_option_present(self):
        """--exclude option must be present in the scan command."""
        src = _src()
        assert "--exclude" in src, "--exclude option missing from scan command"

    def test_token_estimation_in_scan(self):
        """Token estimation using len/3.3 must be present in scan command."""
        src = _src()
        assert "3.3" in src, "Token estimation (len/3.3) not found in main.py"

    def test_summarize_command_registered(self):
        """summarize command must be registered on the app."""
        src = _src()
        assert "def summarize(" in src, "summarize() function not found in main.py"

    def test_msapling_ollama_url_used(self):
        """MSAPLING_OLLAMA_URL environment variable must be used in summarize."""
        src = _src()
        assert "MSAPLING_OLLAMA_URL" in src, "MSAPLING_OLLAMA_URL not referenced in main.py"

    def test_rich_progress_used_in_scan(self):
        """rich.progress must be imported/used inside the scan command."""
        src = _src()
        assert "rich.progress" in src or "from rich.progress" in src or "Progress" in src, (
            "rich.progress not used in main.py"
        )

    def test_stdout_output_mode_present(self):
        """--output - stdout mode must be handled in scan command."""
        src = _src()
        assert 'output == "-"' in src or "output == '-'" in src, (
            "stdout output mode (--output -) not found in scan command"
        )

    def test_include_option_present(self):
        """--include option must be present in the scan command."""
        src = _src()
        assert "--include" in src, "--include option missing from scan command"

    def test_max_size_kb_option_present(self):
        """--max-size-kb option must be present in the scan command."""
        src = _src()
        assert "--max-size-kb" in src, "--max-size-kb option missing from scan command"

    def test_summary_prompt_defined_in_summarize(self):
        """SUMMARY_PROMPT constant must exist in summarize command body."""
        src = _src()
        assert "SUMMARY_PROMPT" in src, "SUMMARY_PROMPT not found in main.py"

    def test_scan_output_option_present(self):
        """--output/-o option must be present in the scan command."""
        src = _src()
        # Verify output option is defined for scan (not just summarize)
        assert '"--output"' in src or "'--output'" in src, (
            "--output option missing from main.py"
        )

    def test_token_total_printed(self):
        """Token total should be printed at end of scan."""
        src = _src()
        assert "total_tokens" in src, "total_tokens variable not found in scan"

    def test_ollama_api_generate_endpoint_used(self):
        """Ollama /api/generate endpoint must be used in summarize."""
        src = _src()
        assert "/api/generate" in src, "Ollama /api/generate endpoint not found in summarize"


# ---------------------------------------------------------------------------
# FUNCTIONAL TESTS
# ---------------------------------------------------------------------------


class TestScanFunctional:
    """Functional tests for scan command logic."""

    @pytest.fixture()
    def runner(self):
        return CliRunner()

    @pytest.fixture()
    def sample_project(self, tmp_path: Path) -> Path:
        """Create a sample project structure."""
        (tmp_path / "main.py").write_text("def hello():\n    return 'world'\n", encoding="utf-8")
        (tmp_path / "utils.py").write_text("import os\n\ndef get_path():\n    return os.getcwd()\n", encoding="utf-8")
        subdir = tmp_path / "src"
        subdir.mkdir()
        (subdir / "app.ts").write_text("export const app = 'msapling';\n", encoding="utf-8")
        ignored = tmp_path / "__pycache__"
        ignored.mkdir()
        (ignored / "main.cpython-311.pyc").write_bytes(b"\x00\x01\x02")
        return tmp_path

    def test_scan_produces_context_blocks(self, runner, sample_project, tmp_path):
        """scan command should produce markdown context blocks for each file."""
        from msapling_cli.main import app

        out_file = tmp_path / "context.md"
        result = runner.invoke(app, [
            "scan", str(sample_project),
            "--output", str(out_file),
            "--include", "*.py",
        ])
        assert result.exit_code == 0, f"scan failed: {result.output}\n{result.exception}"
        content = out_file.read_text(encoding="utf-8")
        assert "# File:" in content, "No file header blocks in output"
        assert "tokens)" in content, "Token count not included in file header"
        assert "def hello" in content, "Python file content not included"

    def test_scan_excludes_pycache(self, runner, sample_project, tmp_path):
        """scan command should exclude __pycache__ directories."""
        from msapling_cli.main import app

        out_file = tmp_path / "context.md"
        result = runner.invoke(app, [
            "scan", str(sample_project),
            "--output", str(out_file),
        ])
        assert result.exit_code == 0, f"scan failed: {result.output}"
        content = out_file.read_text(encoding="utf-8")
        assert "cpython" not in content, "__pycache__ file should be excluded"

    def test_scan_respects_max_files(self, runner, tmp_path):
        """scan command should not exceed --max-files limit."""
        from msapling_cli.main import app

        # Create 10 python files
        for i in range(10):
            (tmp_path / f"file_{i}.py").write_text(f"x = {i}\n", encoding="utf-8")

        out_file = tmp_path / "out.md"
        result = runner.invoke(app, [
            "scan", str(tmp_path),
            "--output", str(out_file),
            "--max-files", "3",
        ])
        assert result.exit_code == 0, f"scan failed: {result.output}"
        content = out_file.read_text(encoding="utf-8")
        file_headers = [line for line in content.splitlines() if line.startswith("# File:")]
        assert len(file_headers) <= 3, f"Expected at most 3 files, got {len(file_headers)}"

    def test_scan_token_estimation(self):
        """Token estimation must use len(content)/3.3."""
        content = "a" * 330  # 330 chars / 3.3 = 100 tokens
        token_est = int(len(content) / 3.3)
        assert token_est == 100

    def test_scan_stdout_mode(self, runner, sample_project):
        """scan --output - should write to stdout."""
        from msapling_cli.main import app

        result = runner.invoke(app, [
            "scan", str(sample_project),
            "--output", "-",
            "--include", "*.py",
        ])
        assert result.exit_code == 0, f"scan stdout mode failed: {result.output}"
        # In stdout mode the context blocks go to stdout
        assert "# File:" in result.output or len(result.output) > 0

    def test_scan_include_filter(self, runner, sample_project, tmp_path):
        """--include should filter to only matching file types."""
        from msapling_cli.main import app

        out_file = tmp_path / "py_only.md"
        result = runner.invoke(app, [
            "scan", str(sample_project),
            "--output", str(out_file),
            "--include", "*.py",
        ])
        assert result.exit_code == 0
        content = out_file.read_text(encoding="utf-8")
        # Should contain .py files
        assert ".py" in content
        # Should NOT contain .ts files (filtered out)
        ts_headers = [l for l in content.splitlines() if "# File:" in l and ".ts" in l]
        assert len(ts_headers) == 0, "TypeScript files should be excluded by --include *.py"

    def test_scan_max_size_kb_skips_large_files(self, runner, tmp_path):
        """--max-size-kb should skip files larger than the limit."""
        from msapling_cli.main import app

        small = tmp_path / "small.py"
        large = tmp_path / "large.py"
        small.write_text("x = 1\n", encoding="utf-8")
        # Write ~10KB file
        large.write_text("# " + "x" * 10240, encoding="utf-8")

        out_file = tmp_path / "out.md"
        result = runner.invoke(app, [
            "scan", str(tmp_path),
            "--output", str(out_file),
            "--max-size-kb", "1",
        ])
        assert result.exit_code == 0
        content = out_file.read_text(encoding="utf-8")
        headers = [l for l in content.splitlines() if l.startswith("# File:")]
        # large.py should be skipped
        large_headers = [h for h in headers if "large" in h]
        assert len(large_headers) == 0, "Large file should be skipped by --max-size-kb"

    def test_scan_missing_path_exits_nonzero(self, runner, tmp_path):
        """scan on a nonexistent path should exit with code 1."""
        from msapling_cli.main import app

        missing = str(tmp_path / "does_not_exist")
        result = runner.invoke(app, ["scan", missing])
        assert result.exit_code != 0, "scan should fail on missing path"

    def test_scan_prints_token_total(self, runner, tmp_path):
        """scan should print the total token count when not streaming to stdout."""
        from msapling_cli.main import app

        (tmp_path / "demo.py").write_text("def foo(): pass\n", encoding="utf-8")
        out_file = tmp_path / "out.md"
        result = runner.invoke(app, [
            "scan", str(tmp_path),
            "--output", str(out_file),
        ])
        assert result.exit_code == 0
        assert "token" in result.output.lower(), "Token count not printed after scan"


class TestSummarizeFunctional:
    """Functional tests for summarize command."""

    @pytest.fixture()
    def runner(self):
        return CliRunner()

    def test_summarize_uses_ollama_url_when_set(self, runner, tmp_path):
        """summarize should call Ollama when MSAPLING_OLLAMA_URL is set."""
        from msapling_cli.main import app
        import httpx

        sample = tmp_path / "notes.txt"
        sample.write_text("Line 1\nLine 2\n", encoding="utf-8")

        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"response": "This is the summary."}

        with patch.dict(os.environ, {"MSAPLING_OLLAMA_URL": "http://localhost:11434"}):
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_http = AsyncMock()
                mock_http.__aenter__ = AsyncMock(return_value=mock_http)
                mock_http.__aexit__ = AsyncMock(return_value=False)
                mock_http.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_http

                result = runner.invoke(app, ["summarize", str(sample)])

        # Should not crash and should call Ollama
        assert result.exit_code == 0 or "error" not in result.output.lower(), (
            f"summarize failed unexpectedly: {result.output}"
        )

    def test_summarize_output_file(self, runner, tmp_path):
        """summarize --output should write result to file."""
        from msapling_cli.main import app

        sample = tmp_path / "notes.txt"
        sample.write_text("Content to summarize.\n", encoding="utf-8")
        out_file = tmp_path / "summary.md"

        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"response": "Summarized content."}

        with patch.dict(os.environ, {"MSAPLING_OLLAMA_URL": "http://localhost:11434"}):
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_http = AsyncMock()
                mock_http.__aenter__ = AsyncMock(return_value=mock_http)
                mock_http.__aexit__ = AsyncMock(return_value=False)
                mock_http.post = AsyncMock(return_value=mock_resp)
                mock_client_cls.return_value = mock_http

                result = runner.invoke(app, ["summarize", str(sample), "--output", str(out_file)])

        if result.exit_code == 0:
            assert out_file.exists(), "--output file should be created"

    def test_summarize_missing_file_exits(self, runner, tmp_path):
        """summarize on a nonexistent file should exit with an error."""
        from msapling_cli.main import app

        missing = str(tmp_path / "ghost.txt")
        result = runner.invoke(app, ["summarize", missing])
        assert result.exit_code != 0, "summarize should fail on missing file"
