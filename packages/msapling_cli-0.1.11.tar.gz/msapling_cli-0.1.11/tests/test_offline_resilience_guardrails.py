"""Guardrail tests for offline resilience features.

Covers:
- OfflineTokenAccumulator class and its core methods (source scan + functional)
- /api/usage/offline-sync backend endpoint registration (source scan)
- Fraud guard cost cap in the backend endpoint (source scan)
- OFFLINE_HANDOVER log key in shell.py (source scan)
- Functional: record(), drain_and_report(), file path, pending_count()

Run with:
    cd cli && python -m pytest tests/test_offline_resilience_guardrails.py -v
"""
from __future__ import annotations

import asyncio
import importlib.util
import inspect
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

# ── Path helpers ──────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_BACKEND_ROOT = _CLI_ROOT.parent / "backend"

_OFFLINE_QUEUE_PATH = _PKG_DIR / "offline_queue.py"
_SHELL_PATH = _PKG_DIR / "shell.py"
_TELEMETRY_PATH = _BACKEND_ROOT / "routers" / "telemetry.py"


# ── Source-scan helpers ───────────────────────────────────────────────────────

def _read_source(path: Path) -> str:
    assert path.exists(), f"File not found: {path}"
    return path.read_text(encoding="utf-8")


def _import_offline_queue():
    """Import offline_queue.py directly without triggering CLI deps."""
    spec = importlib.util.spec_from_file_location(
        "msapling_cli.offline_queue", str(_OFFLINE_QUEUE_PATH)
    )
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


# ── Guardrail 1: OfflineTokenAccumulator class exists ────────────────────────

def test_offline_token_accumulator_class_exists():
    """OfflineTokenAccumulator must be defined in offline_queue.py."""
    src = _read_source(_OFFLINE_QUEUE_PATH)
    assert "class OfflineTokenAccumulator" in src, (
        "OfflineTokenAccumulator class not found in offline_queue.py"
    )


# ── Guardrail 2: record() method exists ──────────────────────────────────────

def test_record_method_exists():
    """OfflineTokenAccumulator must have a record() method."""
    src = _read_source(_OFFLINE_QUEUE_PATH)
    assert "def record(" in src, "record() method not found in offline_queue.py"


# ── Guardrail 3: drain_and_report() method exists ────────────────────────────

def test_drain_and_report_method_exists():
    """OfflineTokenAccumulator must have a drain_and_report() method."""
    src = _read_source(_OFFLINE_QUEUE_PATH)
    assert "async def drain_and_report(" in src, (
        "drain_and_report() async method not found in offline_queue.py"
    )


# ── Guardrail 4: offline_tokens.json path defined ────────────────────────────

def test_offline_tokens_json_path_defined():
    """The canonical path ~/.msapling/offline_tokens.json must be referenced."""
    src = _read_source(_OFFLINE_QUEUE_PATH)
    assert "offline_tokens.json" in src, (
        "offline_tokens.json path not defined in offline_queue.py"
    )
    assert ".msapling" in src, (
        "~/.msapling directory not referenced in offline_queue.py"
    )


# ── Guardrail 5: /api/usage/offline-sync endpoint registered in backend ───────

def test_offline_sync_endpoint_registered():
    """/api/usage/offline-sync must be present in backend telemetry router."""
    src = _read_source(_TELEMETRY_PATH)
    assert "/usage/offline-sync" in src, (
        "POST /api/usage/offline-sync endpoint not found in backend/routers/telemetry.py"
    )


# ── Guardrail 6: fraud guard cost cap present ────────────────────────────────

def test_fraud_guard_cost_cap_present():
    """The backend endpoint must include a fraud guard comparing cost vs credits."""
    src = _read_source(_TELEMETRY_PATH)
    # Look for the multiplier constant or the comparison logic
    assert "OFFLINE_SYNC_COST_CAP_MULTIPLIER" in src or "cost_cap" in src, (
        "Fraud guard cost cap not found in telemetry.py"
    )
    assert "total_claimed_cost" in src or "claimed_cost" in src, (
        "Total cost accumulation for fraud guard not found in telemetry.py"
    )


# ── Guardrail 7: OFFLINE_HANDOVER log key in shell ───────────────────────────

def test_offline_handover_log_key_in_shell():
    """OFFLINE_HANDOVER log key must appear in shell.py (or offline_queue.py)."""
    shell_src = _read_source(_SHELL_PATH)
    queue_src = _read_source(_OFFLINE_QUEUE_PATH)
    assert "OFFLINE_HANDOVER" in shell_src or "OFFLINE_HANDOVER" in queue_src, (
        "OFFLINE_HANDOVER log key not found in shell.py or offline_queue.py"
    )


# ── Guardrail 8: functional — record() writes to file ────────────────────────

def test_record_writes_to_file(tmp_path):
    """record() must append a JSON entry to the local file."""
    mod = _import_offline_queue()
    log_file = tmp_path / "offline_tokens.json"
    acc = mod.OfflineTokenAccumulator(file=log_file)

    acc.record(
        model_id="ollama/llama3",
        tokens_in=100,
        tokens_out=200,
        cost_estimate=0.0005,
    )

    assert log_file.exists(), "offline_tokens.json not created after record()"
    data = json.loads(log_file.read_text())
    assert isinstance(data, list), "File content should be a list"
    assert len(data) == 1, "Expected exactly one record"
    entry = data[0]
    assert entry["model_id"] == "ollama/llama3"
    assert entry["tokens_in"] == 100
    assert entry["tokens_out"] == 200
    assert abs(entry["cost_estimate"] - 0.0005) < 1e-9


# ── Guardrail 9: functional — drain_and_report() clears file on success ───────

def test_drain_and_report_clears_file_on_success(tmp_path):
    """drain_and_report() must clear the file when server returns ok."""
    mod = _import_offline_queue()
    log_file = tmp_path / "offline_tokens.json"
    acc = mod.OfflineTokenAccumulator(file=log_file)

    acc.record("ollama/llama3", 50, 100, 0.001)
    acc.record("ollama/llama3", 80, 160, 0.002)
    assert acc.pending_count() == 2

    # Mock client that returns success
    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value={"status": "ok", "reported": 2})

    reported = asyncio.run(acc.drain_and_report(mock_client))
    assert reported == 2, f"Expected 2 reported, got {reported}"
    assert acc.pending_count() == 0, "File should be cleared after successful drain"


# ── Guardrail 10: functional — drain_and_report() retains file on failure ─────

def test_drain_and_report_retains_file_on_failure(tmp_path):
    """drain_and_report() must NOT clear the file when server call fails."""
    mod = _import_offline_queue()
    log_file = tmp_path / "offline_tokens.json"
    acc = mod.OfflineTokenAccumulator(file=log_file)

    acc.record("ollama/llama3", 50, 100, 0.001)
    assert acc.pending_count() == 1

    # Mock client that raises an exception
    mock_client = AsyncMock()
    mock_client.post = AsyncMock(side_effect=ConnectionError("backend down"))

    reported = asyncio.run(acc.drain_and_report(mock_client))
    assert reported == 0, "Should report 0 on failure"
    assert acc.pending_count() == 1, "File should be retained on failure"


# ── Guardrail 11: functional — multiple records accumulate ────────────────────

def test_record_accumulates_multiple_entries(tmp_path):
    """Multiple record() calls must accumulate without overwriting."""
    mod = _import_offline_queue()
    log_file = tmp_path / "offline_tokens.json"
    acc = mod.OfflineTokenAccumulator(file=log_file)

    for i in range(5):
        acc.record(f"model/{i}", i * 10, i * 20, i * 0.001)

    assert acc.pending_count() == 5
    data = json.loads(log_file.read_text())
    assert len(data) == 5
    assert data[3]["model_id"] == "model/3"


# ── Guardrail 12: _engage_ollama_failover uses OFFLINE_HANDOVER key ───────────

def test_engage_ollama_failover_logs_offline_handover_key():
    """_engage_ollama_failover() must reference OFFLINE_HANDOVER_KEY from offline_queue."""
    shell_src = _read_source(_SHELL_PATH)
    assert "_engage_ollama_failover" in shell_src, (
        "_engage_ollama_failover method not found in shell.py"
    )
    assert "OFFLINE_HANDOVER_KEY" in shell_src or "OFFLINE_HANDOVER" in shell_src, (
        "OFFLINE_HANDOVER key not referenced in shell.py failover method"
    )
