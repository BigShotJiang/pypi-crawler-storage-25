"""Tests for local file operations."""
import os
from pathlib import Path

from msapling_cli.local import detect_project_root, build_file_tree, _count_lines, read_files_as_context


def test_detect_python_project(tmp_path):
    (tmp_path / "requirements.txt").write_text("flask\n")
    (tmp_path / "app.py").write_text("print('hello')\n")
    root, info = detect_project_root(str(tmp_path))
    assert root == str(tmp_path)
    assert info["type"] == "python"
    assert "requirements.txt" in info["markers"]


def test_detect_node_project(tmp_path):
    (tmp_path / "package.json").write_text('{"name": "test"}\n')
    root, info = detect_project_root(str(tmp_path))
    assert info["type"] == "node"


def test_detect_git_project(tmp_path):
    (tmp_path / ".git").mkdir()
    root, info = detect_project_root(str(tmp_path))
    assert "git" in info["type"] or ".git" in info["markers"]


def test_detect_unknown_project(tmp_path):
    # Create a nested dir with no markers so it walks up and may find parent markers
    nested = tmp_path / "deep" / "empty"
    nested.mkdir(parents=True)
    root, info = detect_project_root(str(nested))
    # Either finds a parent marker or returns unknown
    assert info["type"] in ("unknown", "python", "node", "git")


def test_build_file_tree(tmp_path):
    (tmp_path / "main.py").write_text("x = 1\ny = 2\n")
    (tmp_path / "utils.py").write_text("def foo(): pass\n")
    (tmp_path / "README.md").write_text("# Hello\n")
    (tmp_path / "image.png").write_bytes(b"\x89PNG\r\n")

    files = build_file_tree(str(tmp_path), patterns=["*.py", "*.md"])
    paths = [f["path"] for f in files]
    assert "main.py" in paths
    assert "utils.py" in paths
    assert "README.md" in paths
    assert "image.png" not in paths


def test_build_file_tree_skips_venv(tmp_path):
    venv = tmp_path / "venv" / "lib"
    venv.mkdir(parents=True)
    (venv / "site.py").write_text("# venv\n")
    (tmp_path / "app.py").write_text("# app\n")

    files = build_file_tree(str(tmp_path), patterns=["*.py"])
    paths = [f["path"] for f in files]
    assert "app.py" in paths
    assert any("venv" in p for p in paths) is False


def test_build_file_tree_skips_pytest_tmp_and_probe_dirs(tmp_path):
    pytest_tmp = tmp_path / ".pytest_tmp" / "case"
    pytest_tmp.mkdir(parents=True)
    (pytest_tmp / "junk.py").write_text("x = 1\n")
    probe = tmp_path / "tmp_cli_probe"
    probe.mkdir()
    (probe / "noise.py").write_text("y = 2\n")
    (tmp_path / "real.py").write_text("z = 3\n")

    files = build_file_tree(str(tmp_path), patterns=["*.py"])
    paths = [f["path"] for f in files]
    assert "real.py" in paths
    assert all(not p.startswith('.pytest_tmp/') for p in paths)
    assert all(not p.startswith('tmp_cli_probe/') for p in paths)


def test_build_file_tree_max_files(tmp_path):
    for i in range(20):
        (tmp_path / f"file_{i}.py").write_text(f"x = {i}\n")

    files = build_file_tree(str(tmp_path), patterns=["*.py"], max_files=5)
    assert len(files) == 5


def test_count_lines(tmp_path):
    f = tmp_path / "test.py"
    f.write_text("line1\nline2\nline3\n")
    assert _count_lines(f) == 3


def test_count_lines_binary(tmp_path):
    f = tmp_path / "test.bin"
    f.write_bytes(b"\x00\x01\x02\x03")
    result = _count_lines(f)
    assert isinstance(result, int)


def test_read_files_as_context(tmp_path):
    (tmp_path / "main.py").write_text("def hello():\n    print('hi')\n")
    files = build_file_tree(str(tmp_path), patterns=["*.py"])
    context = read_files_as_context(str(tmp_path), files)
    assert "## Project Structure" in context
    assert "main.py" in context
    assert "def hello" in context
    assert "```python" in context
