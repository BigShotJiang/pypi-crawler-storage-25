"""Tests for agent.py tool handler implementations.

Covers grep_search, list_directory, todo_list, model_switch, and
search_replace_all — the 5 tools least exercised by existing tests.

Uses tempfile.mkdtemp instead of tmp_path to avoid Windows file-lock
cleanup errors that can occur when prior tests leave processes running.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
import shutil
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import msapling_cli.agent as agent_mod
from msapling_cli.agent import (
    _execute_tool,
    _permissions,
    set_permission_mode,
    get_permission_mode,
)


@pytest.fixture(autouse=True)
def _full_permission_mode():
    """Set permission mode to 'full' for each test; restore afterwards."""
    previous = get_permission_mode()
    set_permission_mode("full")
    yield
    set_permission_mode(previous)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _TmpDir:
    """Context manager that creates and removes a real temp directory."""

    def __enter__(self):
        self.path = tempfile.mkdtemp(prefix="ms_test_")
        return Path(self.path)

    def __exit__(self, *_):
        shutil.rmtree(self.path, ignore_errors=True)


# ---------------------------------------------------------------------------
# 1. test_grep_basic
# ---------------------------------------------------------------------------

def test_grep_basic():
    """grep_search returns a match when the pattern is present in a tmp file."""
    with _TmpDir() as tmp:
        target = tmp / "sample.txt"
        target.write_text("hello world\nfoo bar\nbaz\n", encoding="utf-8")

        fake_result = MagicMock()
        fake_result.stdout = "sample.txt:1:hello world\n"
        fake_result.returncode = 0

        with patch("subprocess.run", return_value=fake_result) as mock_run:
            result = _execute_tool(
                "grep_search",
                {"pattern": "hello", "path": str(tmp)},
                str(tmp),
            )

    assert "hello" in result
    assert mock_run.called


def test_grep_no_match():
    """grep_search returns 'No matches found' when subprocess returns no output."""
    with _TmpDir() as tmp:
        fake_result = MagicMock()
        fake_result.stdout = ""
        fake_result.returncode = 1

        with patch("subprocess.run", return_value=fake_result):
            result = _execute_tool(
                "grep_search",
                {"pattern": "zzznomatch", "path": str(tmp)},
                str(tmp),
            )

    assert "no matches" in result.lower()


# ---------------------------------------------------------------------------
# 2. test_list_directory
# ---------------------------------------------------------------------------

def test_list_directory():
    """list_directory returns both filenames when the tmp dir has two files."""
    with _TmpDir() as tmp:
        (tmp / "alpha.py").write_text("# alpha\n", encoding="utf-8")
        (tmp / "beta.txt").write_text("hello\n", encoding="utf-8")

        result = _execute_tool("list_directory", {"path": "."}, str(tmp))

    assert "alpha.py" in result
    assert "beta.txt" in result


def test_list_directory_shows_subdirs():
    """list_directory marks subdirectories with a trailing slash."""
    with _TmpDir() as tmp:
        (tmp / "subdir").mkdir()
        (tmp / "file.py").write_text("", encoding="utf-8")

        result = _execute_tool("list_directory", {"path": "."}, str(tmp))

    assert "subdir/" in result


def test_list_directory_empty():
    """list_directory reports empty on an empty directory."""
    with _TmpDir() as tmp:
        result = _execute_tool("list_directory", {"path": "."}, str(tmp))

    assert "empty" in result.lower()


def test_list_directory_path_outside_root():
    """list_directory rejects paths that escape the project root."""
    with _TmpDir() as tmp:
        result = _execute_tool("list_directory", {"path": "../../etc"}, str(tmp))

    assert "outside project root" in result or "Error" in result


# ---------------------------------------------------------------------------
# 3. test_todo_list_empty
# ---------------------------------------------------------------------------

def test_todo_list_empty():
    """todo_list 'list' reports empty when no items exist."""
    agent_mod._agent_todos.clear()

    result = _execute_tool("todo_list", {"action": "list"}, ".")

    assert "empty" in result.lower()


def test_todo_list_add_and_list():
    """todo_list 'add' stores an item; 'list' returns it."""
    agent_mod._agent_todos.clear()

    _execute_tool("todo_list", {"action": "add", "item": "Write unit tests"}, ".")
    result = _execute_tool("todo_list", {"action": "list"}, ".")

    assert "Write unit tests" in result
    assert "[ ]" in result  # not yet done


def test_todo_list_done():
    """todo_list 'done' marks an item completed."""
    agent_mod._agent_todos.clear()

    _execute_tool("todo_list", {"action": "add", "item": "Deploy service"}, ".")
    result = _execute_tool("todo_list", {"action": "done", "item": "Deploy"}, ".")

    assert "Completed" in result or "Deploy service" in result


def test_todo_list_clear():
    """todo_list 'clear' empties the list."""
    agent_mod._agent_todos.clear()

    _execute_tool("todo_list", {"action": "add", "item": "Task A"}, ".")
    _execute_tool("todo_list", {"action": "clear"}, ".")

    assert agent_mod._agent_todos == []


# ---------------------------------------------------------------------------
# 4. test_model_switch
# ---------------------------------------------------------------------------

def test_model_switch_valid():
    """model_switch stores the new model in _switched_model."""
    agent_mod._switched_model = None

    result = _execute_tool(
        "model_switch",
        {"model": "openai/gpt-4o"},
        ".",
    )

    assert agent_mod._switched_model == "openai/gpt-4o"
    assert "openai/gpt-4o" in result


def test_model_switch_flash():
    """model_switch works with a Gemini Flash model ID."""
    agent_mod._switched_model = None

    result = _execute_tool(
        "model_switch",
        {"model": "google/gemini-2.0-flash-001"},
        ".",
    )

    assert agent_mod._switched_model == "google/gemini-2.0-flash-001"
    assert "switched" in result.lower() or "google/gemini-2.0-flash-001" in result


def test_model_switch_no_model():
    """model_switch with missing model arg returns an error message."""
    result = _execute_tool("model_switch", {}, ".")

    assert "Error" in result or "provide" in result.lower()


# ---------------------------------------------------------------------------
# 5. test_search_replace_all
# ---------------------------------------------------------------------------

def test_search_replace_all_basic():
    """search_replace_all replaces all occurrences in a file."""
    with _TmpDir() as tmp:
        f = tmp / "code.py"
        f.write_text("foo = 1\nfoo = 2\nbar = foo\n", encoding="utf-8")

        with patch("msapling_cli.agent._show_diff"), \
             patch("msapling_cli.agent._mdrive_auto_push"):
            result = _execute_tool(
                "search_replace_all",
                {"path": "code.py", "old_string": "foo", "new_string": "qux"},
                str(tmp),
            )

        new_content = f.read_text(encoding="utf-8")

    assert "foo" not in new_content
    assert new_content.count("qux") == 3
    assert "Replaced" in result
    assert "3" in result  # 3 occurrences


def test_search_replace_all_string_not_found():
    """search_replace_all returns an error when the old_string is absent."""
    with _TmpDir() as tmp:
        f = tmp / "code.py"
        f.write_text("x = 1\n", encoding="utf-8")

        result = _execute_tool(
            "search_replace_all",
            {"path": "code.py", "old_string": "NOT_HERE", "new_string": "anything"},
            str(tmp),
        )

    assert "Error" in result or "not found" in result.lower()


def test_search_replace_all_protected_file():
    """search_replace_all blocks writes to .env files."""
    with _TmpDir() as tmp:
        env_file = tmp / ".env"
        env_file.write_text("SECRET=abc\n", encoding="utf-8")

        result = _execute_tool(
            "search_replace_all",
            {"path": ".env", "old_string": "abc", "new_string": "xyz"},
            str(tmp),
        )

        assert "Blocked" in result or "protected" in result.lower()
        # File must be unmodified
        assert env_file.read_text() == "SECRET=abc\n"


def test_search_replace_all_file_not_found():
    """search_replace_all returns an error for missing files."""
    with _TmpDir() as tmp:
        result = _execute_tool(
            "search_replace_all",
            {"path": "nonexistent.py", "old_string": "x", "new_string": "y"},
            str(tmp),
        )

    assert "Error" in result or "not found" in result.lower()
