"""Guardrail tests: CLI Sidebar mode + Local Credential Encryption.

All tests are source-scan guardrails — they verify that the required
symbols, patterns, and wiring exist in the source files without
executing the runtime code (no network, no keyring, no filesystem side
effects needed).
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────────────
CLI_ROOT = Path(__file__).resolve().parent.parent
SHELL_PY = CLI_ROOT / "msapling_cli" / "shell.py"
MAIN_PY = CLI_ROOT / "msapling_cli" / "main.py"

_shell_src = SHELL_PY.read_text(encoding="utf-8")
_main_src = MAIN_PY.read_text(encoding="utf-8")


# ──────────────────────────────────────────────────────────────────────────────
# TASK 1 — Sidebar
# ──────────────────────────────────────────────────────────────────────────────


def test_sidebar_command_registered_in_slash_handler():
    """/sidebar must be handled inside InteractiveShell._handle_slash."""
    assert '"/sidebar"' in _shell_src or "'/sidebar'" in _shell_src, (
        "/sidebar command not found in shell.py"
    )


def test_sidebar_visible_attribute_on_shell():
    """InteractiveShell.__init__ must set _sidebar_visible: bool = False."""
    assert "_sidebar_visible" in _shell_src, (
        "_sidebar_visible attribute not found in shell.py"
    )


def test_sidebar_visible_default_false():
    """_sidebar_visible must be initialised to False."""
    # Accept both annotated and plain assignment forms.
    assert re.search(r"_sidebar_visible\s*(?::\s*bool\s*)?=\s*False", _shell_src), (
        "_sidebar_visible is not initialised to False in shell.py"
    )


def test_render_sidebar_method_exists():
    """InteractiveShell must define a _render_sidebar method."""
    assert "def _render_sidebar(" in _shell_src, (
        "_render_sidebar method not found in shell.py"
    )


def test_render_sidebar_uses_rich_table():
    """_render_sidebar must construct a rich.table.Table."""
    assert "Table(" in _shell_src, (
        "_render_sidebar does not use rich Table in shell.py"
    )


def test_width_below_80_fallback_present():
    """shell.py must have explicit width < 80 guard for narrow-terminal fallback."""
    assert re.search(r"term_width\s*<\s*80|width\s*<\s*80", _shell_src), (
        "Width < 80 fallback not found in shell.py"
    )


def test_sidebar_toggles_visibility():
    """_sidebar_visible must be toggled (negation assignment) when /sidebar runs."""
    # The handler must flip _sidebar_visible via 'not self._sidebar_visible'.
    assert "not self._sidebar_visible" in _shell_src, (
        "_sidebar_visible toggle not found in shell.py"
    )


def test_layout_import_in_render_sidebar():
    """_render_sidebar must import or reference rich.layout.Layout."""
    assert "Layout" in _shell_src, (
        "rich.layout.Layout not referenced in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────────────
# TASK 2 — Credential Encryption
# ──────────────────────────────────────────────────────────────────────────────


def test_credentials_encrypt_command_registered():
    """main.py must define the 'encrypt' command under credentials_app."""
    assert '@credentials_app.command("encrypt")' in _main_src or \
           "@credentials_app.command('encrypt')" in _main_src, (
        "credentials_app 'encrypt' command not found in main.py"
    )


def test_credentials_unlock_command_registered():
    """main.py must define the 'unlock' command under credentials_app."""
    assert '@credentials_app.command("unlock")' in _main_src or \
           "@credentials_app.command('unlock')" in _main_src, (
        "credentials_app 'unlock' command not found in main.py"
    )


def test_fernet_import_present():
    """main.py must import or reference cryptography.fernet.Fernet."""
    assert "Fernet" in _main_src, (
        "Fernet not referenced in main.py"
    )


def test_keyring_referenced_in_credentials():
    """main.py must reference keyring inside the credentials encryption logic."""
    assert "keyring" in _main_src, (
        "keyring not referenced in main.py"
    )


def test_salt_file_path_present():
    """main.py must define the salt file path constant."""
    assert "_CREDENTIALS_SALT_FILE" in _main_src, (
        "_CREDENTIALS_SALT_FILE path constant not found in main.py"
    )


def test_pbkdf2_key_derivation_present():
    """main.py must use PBKDF2 (or PBKDF2HMAC) for key derivation."""
    assert "PBKDF2" in _main_src, (
        "PBKDF2 key derivation not found in main.py"
    )


def test_credentials_app_added_to_typer():
    """credentials_app must be registered on the main Typer app."""
    assert 'app.add_typer(credentials_app' in _main_src, (
        "credentials_app not added to main typer app in main.py"
    )


def test_derive_fernet_key_function_exists():
    """main.py must define a helper function that derives a Fernet key."""
    assert "def _derive_fernet_key(" in _main_src, (
        "_derive_fernet_key function not found in main.py"
    )


def test_encrypted_credentials_file_path_defined():
    """main.py must define the path for the encrypted credentials file."""
    assert "_CREDENTIALS_ENCRYPTED_FILE" in _main_src, (
        "_CREDENTIALS_ENCRYPTED_FILE path not defined in main.py"
    )
