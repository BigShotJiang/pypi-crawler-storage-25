"""Tests for CLI configuration."""
import json
import os
from pathlib import Path
from unittest.mock import patch

from msapling_cli.config import Settings, get_settings, save_settings, get_token, save_token, clear_token


def test_default_settings():
    s = Settings()
    assert s.api_url == "https://api.msapling.com"
    assert s.default_model == "google/gemini-2.0-flash-001"
    assert s.temperature == 0.7
    assert s.theme == "diamond"


def test_settings_env_override():
    with patch.dict(os.environ, {"MSAPLING_API_URL": "http://localhost:9999"}):
        s = Settings()
        assert s.api_url == "http://localhost:9999"


def test_settings_accepts_legacy_ollama_and_ignores_unknown_keys():
    s = Settings(
        api_url="https://api.msapling.com",
        ollama_base_url="http://127.0.0.1:11434",
        ollama_enabled=True,
        legacy_flag=True,  # unknown key from older/newer config files
    )
    assert s.ollama_base_url == "http://127.0.0.1:11434"
    assert s.ollama_enabled is True


def test_save_and_load_settings(tmp_path):
    config_file = tmp_path / "config.json"
    with patch("msapling_cli.config._CONFIG_FILE", config_file):
        s = Settings(api_url="http://test:8000", default_model="test-model")
        save_settings(s)
        assert config_file.exists()
        loaded = get_settings()
        assert loaded.api_url == "http://test:8000"
        assert loaded.default_model == "test-model"


def test_token_save_load_clear(tmp_path):
    enc_file = tmp_path / "token.enc"
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
         patch("msapling_cli.config._KEYFILE", tmp_path / ".keyfile"), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
        save_token("test-jwt-token-123")
        assert enc_file.exists()
        assert get_token() == "test-jwt-token-123"
        clear_token()
        assert not enc_file.exists()


def test_save_token_accepts_force_insecure_kwarg(tmp_path):
    enc_file = tmp_path / "token.enc"
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
         patch("msapling_cli.config._KEYFILE", tmp_path / ".keyfile"), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None):
        save_token("compat-token-123", force_insecure=True)
        assert enc_file.exists()


def test_get_token_from_env():
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent")), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", Path("/nonexistent.enc")), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": "env-token-456"}):
        assert get_token() == "env-token-456"


def test_get_token_none_when_missing():
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent")), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", Path("/nonexistent.enc")), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {}, clear=True):
        # Remove MSAPLING_TOKEN if set
        os.environ.pop("MSAPLING_TOKEN", None)
        assert get_token() is None
