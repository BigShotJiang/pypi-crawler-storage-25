"""Robust tests for tab completion and fuzzy model resolution."""
from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from msapling_cli.completer import (
    DEFAULT_MODELS,
    FILE_PATH_COMMANDS,
    MODEL_ALIASES,
    MSaplingCompleter,
    SLASH_COMMANDS,
    _SKIP_DIRS,
    resolve_model,
    setup_completion,
    validate_model_choice,
)


# ---- Fixtures ----

@pytest.fixture
def project_dir(tmp_path):
    """Create a project directory with test files and directories."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("# main", encoding="utf-8")
    (tmp_path / "src" / "utils.py").write_text("# utils", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_main.py").write_text("# test", encoding="utf-8")
    (tmp_path / "README.md").write_text("# readme", encoding="utf-8")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "pkg.json").write_text("{}", encoding="utf-8")
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "__pycache__" / "main.cpython-312.pyc").write_bytes(b"cache")
    (tmp_path / ".git").mkdir()
    (tmp_path / ".git" / "config").write_text("[core]", encoding="utf-8")
    return tmp_path


@pytest.fixture
def completer(project_dir):
    """Create an MSaplingCompleter with the test project root."""
    return MSaplingCompleter(project_root=str(project_dir))


# ---- Slash command completion ----


def test_slash_completion_basic(completer):
    """Typing '/he' completes to '/help '."""
    matches = completer._compute_matches("/he", "/he")
    assert "/help " in matches


def test_slash_completion_multiple_matches(completer):
    """Typing '/m' returns multiple /m* commands."""
    matches = completer._compute_matches("/m", "/m")
    cmds = {m.strip() for m in matches}
    assert "/model" in cmds or "/models" in cmds
    assert "/multi" in cmds or "/memory" in cmds


def test_slash_completion_no_match(completer):
    """Typing '/zzz' returns no matches."""
    matches = completer._compute_matches("/zzz", "/zzz")
    assert matches == []


def test_slash_completion_exact(completer):
    """Typing '/quit' returns '/quit '."""
    matches = completer._compute_matches("/quit", "/quit")
    assert "/quit " in matches


def test_slash_completion_after_space_goes_to_subcommand(completer):
    """After '/model ', completion shifts to model names."""
    matches = completer._compute_matches("", "/model ")
    # Should return model completions (from DEFAULT_MODELS)
    assert len(matches) > 0


def test_slash_commands_list_not_empty():
    """SLASH_COMMANDS list contains expected commands."""
    assert "/help" in SLASH_COMMANDS
    assert "/quit" in SLASH_COMMANDS
    assert "/model" in SLASH_COMMANDS
    assert "/agent" in SLASH_COMMANDS
    assert "/mdrive" in SLASH_COMMANDS


# ---- File path completion ----


def test_file_path_completion_root(completer, project_dir):
    """File path completion lists top-level files and dirs."""
    matches = completer._compute_matches("", "/read ")
    names = [m.replace("\\", "/") for m in matches]
    found_readme = any("README.md" in n for n in names)
    found_src = any("src/" in n for n in names)
    assert found_readme or found_src


def test_file_path_completion_subdir(completer, project_dir):
    """File path completion lists files inside a subdirectory."""
    matches = completer._compute_matches("src/", "/read src/")
    names = [m.replace("\\", "/") for m in matches]
    assert any("main.py" in n for n in names)


def test_file_path_completion_skips_node_modules(completer, project_dir):
    """File path completion skips node_modules directory."""
    matches = completer._compute_matches("node", "/read node")
    names = [m.replace("\\", "/") for m in matches]
    assert not any("node_modules" in n for n in names)


def test_file_path_completion_skips_pycache(completer, project_dir):
    """File path completion skips __pycache__ directory."""
    matches = completer._compute_matches("__py", "/read __py")
    assert len(matches) == 0


def test_file_path_completion_skips_git(completer, project_dir):
    """File path completion skips .git directory."""
    matches = completer._compute_matches(".git", "/read .git")
    names = [m.replace("\\", "/") for m in matches]
    assert not any(".git" in n for n in names)


def test_file_path_commands_set():
    """FILE_PATH_COMMANDS contains all expected commands."""
    assert "/read" in FILE_PATH_COMMANDS
    assert "/edit" in FILE_PATH_COMMANDS
    assert "/write" in FILE_PATH_COMMANDS
    assert "/mention" in FILE_PATH_COMMANDS
    assert "/attach" in FILE_PATH_COMMANDS
    assert "/image" in FILE_PATH_COMMANDS


# ---- Model completion ----


def test_model_completion_partial(completer):
    """Typing '/model goo' suggests google/* models."""
    matches = completer._compute_matches("goo", "/model goo")
    assert len(matches) > 0
    assert all("google/" in m for m in matches)


def test_model_completion_empty_shows_all(completer):
    """Typing '/model ' with no partial shows all models."""
    matches = completer._compute_matches("", "/model ")
    assert len(matches) >= len(DEFAULT_MODELS)


def test_model_completion_anthropic(completer):
    """Typing '/model anth' suggests anthropic/* models."""
    matches = completer._compute_matches("anth", "/model anth")
    assert len(matches) > 0
    assert all("anthropic/" in m for m in matches)


# ---- Subcommand completion ----


def test_effort_subcommand_completion(completer):
    """Typing '/effort ' completes with low/medium/high."""
    matches = completer._compute_matches("", "/effort ")
    levels = {m.strip() for m in matches}
    assert "low" in levels
    assert "medium" in levels
    assert "high" in levels


def test_hooks_subcommand_completion(completer):
    """Typing '/hooks ' completes with add/remove/clear."""
    matches = completer._compute_matches("", "/hooks ")
    subs = {m.strip() for m in matches}
    assert "add" in subs
    assert "remove" in subs
    assert "clear" in subs


def test_mdrive_subcommand_completion(completer):
    """Typing '/mdrive ' completes with status/ls/push/pull."""
    matches = completer._compute_matches("", "/mdrive ")
    subs = {m.strip() for m in matches}
    assert "status" in subs
    assert "ls" in subs
    assert "push" in subs
    assert "pull" in subs


def test_memory_subcommand_completion(completer):
    """Typing '/memory ' completes with add/clear."""
    matches = completer._compute_matches("", "/memory ")
    subs = {m.strip() for m in matches}
    assert "add" in subs
    assert "clear" in subs


# ---- Fuzzy model resolver ----


def test_resolve_empty_returns_default():
    """Empty input resolves to default model."""
    model, fuzzy = resolve_model("")
    assert model == "google/gemini-2.0-flash-001"
    assert fuzzy is True


def test_resolve_exact_id_passthrough():
    """Full model ID with / is returned as-is."""
    model, fuzzy = resolve_model("openai/gpt-4o")
    assert model == "openai/gpt-4o"
    assert fuzzy is False


def test_resolve_alias_gemini_flash():
    """'gemini flash' resolves to gemini-2.0-flash-001."""
    model, _ = resolve_model("gemini flash")
    assert model == "google/gemini-2.0-flash-001"


def test_resolve_alias_claude():
    """'claude' resolves to claude-sonnet-4."""
    model, _ = resolve_model("claude")
    assert model == "anthropic/claude-sonnet-4"


def test_resolve_alias_claude_haiku():
    """'claude haiku' resolves to claude-haiku-4.5."""
    model, _ = resolve_model("claude haiku")
    assert model == "anthropic/claude-haiku-4.5"


def test_resolve_alias_claude_opus():
    """'claude opus' resolves to claude-opus-4."""
    model, _ = resolve_model("claude opus")
    assert model == "anthropic/claude-opus-4"


def test_resolve_alias_gpt4():
    """'gpt4' resolves to gpt-4o."""
    model, _ = resolve_model("gpt4")
    assert model == "openai/gpt-4o"


def test_resolve_alias_gpt4o():
    """'gpt4o' resolves to gpt-4o."""
    model, _ = resolve_model("gpt4o")
    assert model == "openai/gpt-4o"


def test_resolve_alias_gpt_mini():
    """'gpt mini' resolves to gpt-4o-mini."""
    model, _ = resolve_model("gpt mini")
    assert model == "openai/gpt-4o-mini"


def test_resolve_alias_llama():
    """'llama' resolves to llama-3.1-70b-instruct."""
    model, _ = resolve_model("llama")
    assert model == "meta-llama/llama-3.1-70b-instruct"


def test_resolve_alias_mistral():
    """'mistral' resolves to mistral-large."""
    model, _ = resolve_model("mistral")
    assert model == "mistralai/mistral-large"


def test_resolve_alias_deepseek():
    """'deepseek' resolves to deepseek-chat."""
    model, _ = resolve_model("deepseek")
    assert model == "deepseek/deepseek-chat"


def test_resolve_alias_qwen():
    """'qwen' resolves to qwen-2.5-72b-instruct."""
    model, _ = resolve_model("qwen")
    assert model == "qwen/qwen-2.5-72b-instruct"


def test_resolve_alias_o1():
    """'o1' resolves to openai/o1."""
    model, _ = resolve_model("o1")
    assert model == "openai/o1"


def test_resolve_alias_o3_mini():
    """'o3 mini' resolves to openai/o3-mini."""
    model, _ = resolve_model("o3 mini")
    assert model == "openai/o3-mini"


def test_resolve_alias_gemini_pro():
    """'gemini pro' resolves to gemini-2.0-pro-exp."""
    model, _ = resolve_model("gemini pro")
    assert model == "google/gemini-2.0-pro-exp-02-05"


def test_resolve_alias_case_insensitive():
    """Alias resolution is case-insensitive."""
    model, _ = resolve_model("CLAUDE")
    assert model == "anthropic/claude-sonnet-4"


def test_resolve_partial_match():
    """Partial alias with enough word overlap still resolves."""
    model, fuzzy = resolve_model("gemini 2.0 flash")
    assert model == "google/gemini-2.0-flash-001"
    assert fuzzy is True


def test_resolve_available_models_substring():
    """Resolver searches available_models list by substring."""
    available = ["custom/my-finetuned-llama-7b"]
    model, fuzzy = resolve_model("finetuned", available_models=available)
    assert model == "custom/my-finetuned-llama-7b"
    assert fuzzy is True


def test_resolve_unknown_returns_as_is():
    """Unknown model name is returned as-is when no match found."""
    model, fuzzy = resolve_model("totally-unknown-model")
    assert model == "totally-unknown-model"
    assert fuzzy is False


# ---- Skip dirs filtering ----


def test_skip_dirs_set():
    """_SKIP_DIRS contains expected directories."""
    assert ".git" in _SKIP_DIRS
    assert "node_modules" in _SKIP_DIRS
    assert "__pycache__" in _SKIP_DIRS
    assert "venv" in _SKIP_DIRS
    assert ".venv" in _SKIP_DIRS
    assert "dist" in _SKIP_DIRS
    assert "build" in _SKIP_DIRS


# ---- Deep directory prevention ----


def test_complete_path_skips_deep_skip_dirs(completer, project_dir):
    """_complete_path filters out paths containing skip directories."""
    matches = completer._complete_path("node_modules/")
    assert len(matches) == 0


def test_complete_path_limits_results(completer, project_dir):
    """_complete_path returns at most 30 matches."""
    # Create many files
    many_dir = project_dir / "many"
    many_dir.mkdir()
    for i in range(50):
        (many_dir / f"file_{i:03d}.txt").write_text(f"content {i}", encoding="utf-8")
    matches = completer._complete_path("many/")
    assert len(matches) <= 30


# ---- readline interface ----


def test_complete_state_cycling(completer):
    """complete() returns matches cycling through state indices."""
    with patch.object(completer, "_compute_matches", return_value=["/help ", "/hooks "]):
        # state=0 computes matches, state=1+ returns next
        assert completer.complete("/h", 0) == "/help "
        assert completer.complete("/h", 1) == "/hooks "
        assert completer.complete("/h", 2) is None


def test_set_models_merges_with_defaults(completer):
    """set_models merges server models with DEFAULT_MODELS."""
    completer.set_models(["custom/model-a", "custom/model-b"])
    assert "custom/model-a" in completer.models
    assert "custom/model-b" in completer.models
    # Defaults should still be there
    for m in DEFAULT_MODELS:
        assert m in completer.models


# ---- setup_completion ----


def test_setup_completion_returns_none_without_readline():
    """setup_completion returns None when readline is not available."""
    with patch.dict("sys.modules", {"readline": None}), \
         patch("builtins.__import__", side_effect=ImportError("no readline")):
        # This may or may not return None depending on pyreadline3 availability
        # The important thing is it does not raise
        try:
            result = setup_completion()
        except Exception:
            pytest.fail("setup_completion should not raise")


# ---- MODEL_ALIASES completeness ----


def test_model_aliases_all_resolve_to_slash_id():
    """All MODEL_ALIASES values contain a '/' (provider/model format)."""
    for alias, model_id in MODEL_ALIASES.items():
        assert "/" in model_id, f"Alias '{alias}' maps to '{model_id}' which has no /"


def test_validate_model_choice_maps_claude_4_5_haiku():
    model, fuzzy = validate_model_choice(
        "claude-4.5-haiku",
        [
            "anthropic/claude-haiku-4.5",
            "anthropic/claude-sonnet-4.5",
            "anthropic/claude-opus-4.5",
        ],
    )
    assert model == "anthropic/claude-haiku-4.5"
    assert fuzzy is True


def test_validate_model_choice_rejects_ambiguous_claude_4_5():
    with pytest.raises(ValueError, match="Ambiguous model"):
        validate_model_choice(
            "claude 4.5",
            [
                "anthropic/claude-haiku-4.5",
                "anthropic/claude-sonnet-4.5",
                "anthropic/claude-opus-4.5",
            ],
        )


def test_validate_model_choice_rejects_ambiguous_jamba():
    with pytest.raises(ValueError, match="Ambiguous model"):
        validate_model_choice(
            "jamba",
            ["ai21/jamba-large-1.7", "ai21/jamba-mini-1.7"],
        )
