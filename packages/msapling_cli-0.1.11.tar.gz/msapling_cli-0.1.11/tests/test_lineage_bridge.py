from __future__ import annotations

import asyncio
import types
import sys

from msapling_cli import lineage_bridge as bridge


def test_bridge_disabled_by_default(monkeypatch):
    monkeypatch.delenv("MSAPLING_MLINEAGE_ENABLE", raising=False)
    ok = asyncio.run(
        bridge.record_conversation_turn(
            session_id="S1",
            role="user",
            content="hello",
            project_name="proj",
        )
    )
    assert ok is False


def test_bridge_records_when_enabled(monkeypatch):
    calls = {"conversation": 0, "shell": 0}

    async def _fake_record_conversation_turn(**kwargs):
        calls["conversation"] += 1
        assert kwargs["session_id"] == "S2"
        assert kwargs["project_id"] == "proj-bridge"

    async def _fake_record_shell_command(**kwargs):
        calls["shell"] += 1
        assert kwargs["command"] == "git status"
        assert kwargs["project_id"] == "proj-bridge"

    fake_engine = types.ModuleType("mlineage.engine")
    fake_engine.record_conversation_turn = _fake_record_conversation_turn
    fake_engine.record_shell_command = _fake_record_shell_command
    fake_pkg = types.ModuleType("mlineage")
    fake_pkg.engine = fake_engine

    monkeypatch.setenv("MSAPLING_MLINEAGE_ENABLE", "1")
    monkeypatch.setenv("MSAPLING_MLINEAGE_PROJECT_ID", "proj-bridge")
    monkeypatch.setitem(sys.modules, "mlineage", fake_pkg)
    monkeypatch.setitem(sys.modules, "mlineage.engine", fake_engine)

    ok_turn = asyncio.run(
        bridge.record_conversation_turn(
            session_id="S2",
            role="assistant",
            content="hi",
            project_name="ignored-project-name",
        )
    )
    ok_shell = asyncio.run(
        bridge.record_shell_command(
            session_id="S2",
            command="git status",
            exit_code=0,
            stdout="clean",
            stderr="",
            project_name="ignored-project-name",
        )
    )

    assert ok_turn is True
    assert ok_shell is True
    assert calls["conversation"] == 1
    assert calls["shell"] == 1
