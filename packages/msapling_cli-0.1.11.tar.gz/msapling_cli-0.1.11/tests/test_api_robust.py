"""Robust tests for MSaplingClient: init, retry, streaming, CSRF, offline."""
from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import httpx
import pytest

from msapling_cli.api import (
    APIError,
    DEFAULT_PROJECT_NAME,
    FREE_DEFAULT_CHAT_LIMIT,
    FREE_PROJECT_CHAT_LIMIT,
    FREE_PROJECT_LIMIT,
    MSaplingClient,
    OfflineError,
    PAID_DEFAULT_CHAT_LIMIT,
    PAID_PROJECT_CHAT_LIMIT,
    PAID_PROJECT_LIMIT,
    RETRYABLE_STATUS_CODES,
    _is_paid_user,
    _mdrive_scoped_path,
    _normalize_legacy_projects_overview,
    _retry_request,
)


# ---- Helper builders ----

def _mock_response(status_code=200, json_data=None, headers=None, cookies=None):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.headers = headers or {}
    resp.cookies = cookies or {}
    resp.raise_for_status = MagicMock()
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            "error", request=MagicMock(), response=resp,
        )
    return resp


# ---- MSaplingClient init ----


def test_client_init_defaults():
    """Client uses default api_url and token from config."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok-123"):
        gs.return_value = MagicMock(api_url="https://api.msapling.com")
        client = MSaplingClient()
        assert client.api_url == "https://api.msapling.com"
        assert client.token == "tok-123"
        assert client.diff_mode is False


def test_client_init_custom_url_and_token():
    """Client accepts explicit api_url and token overrides."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value=None):
        gs.return_value = MagicMock(api_url="https://default.com")
        client = MSaplingClient(api_url="http://custom:8000", token="override-tok")
        assert client.api_url == "http://custom:8000"
        assert client.token == "override-tok"


def test_client_init_strips_trailing_slash():
    """Client strips trailing slash from api_url."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value=None):
        gs.return_value = MagicMock(api_url="https://api.example.com/")
        client = MSaplingClient()
        assert client.api_url == "https://api.example.com"


def test_client_diff_mode_flag():
    """Client stores diff_mode flag for system prompt injection."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value=None):
        gs.return_value = MagicMock(api_url="http://x")
        client = MSaplingClient(diff_mode=True)
        assert client.diff_mode is True


# ---- Retry logic ----


@pytest.mark.asyncio
async def test_retry_succeeds_on_first_attempt():
    """Retry returns immediately when first call succeeds."""
    fn = AsyncMock(return_value=_mock_response(200, {"ok": True}))
    resp = await _retry_request(fn, retries=3, backoff=0.001)
    assert resp.status_code == 200
    fn.assert_awaited_once()


@pytest.mark.asyncio
async def test_retry_retries_on_429():
    """Retry retries on 429 status code."""
    resp_429 = _mock_response(429)
    resp_429.raise_for_status = MagicMock()  # Don't raise on intermediate
    resp_200 = _mock_response(200, {"ok": True})
    fn = AsyncMock(side_effect=[resp_429, resp_200])
    resp = await _retry_request(fn, retries=3, backoff=0.001)
    assert resp.status_code == 200
    assert fn.await_count == 2


@pytest.mark.asyncio
async def test_retry_retries_on_500():
    """Retry retries on 500 status code."""
    resp_500 = _mock_response(500)
    resp_500.raise_for_status = MagicMock()
    resp_200 = _mock_response(200)
    fn = AsyncMock(side_effect=[resp_500, resp_200])
    resp = await _retry_request(fn, retries=3, backoff=0.001)
    assert resp.status_code == 200


@pytest.mark.asyncio
async def test_retry_respects_retry_after_header():
    """Retry uses Retry-After header value from 429 response."""
    resp_429 = _mock_response(429, headers={"retry-after": "1"})
    resp_429.raise_for_status = MagicMock()
    resp_200 = _mock_response(200)
    fn = AsyncMock(side_effect=[resp_429, resp_200])
    with patch("msapling_cli.api.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        await _retry_request(fn, retries=3, backoff=0.5)
        # Should sleep at least 1 second (the retry-after value)
        if mock_sleep.call_count > 0:
            sleep_val = mock_sleep.call_args_list[0][0][0]
            assert sleep_val >= 1.0


@pytest.mark.asyncio
async def test_retry_raises_after_exhausting_retries():
    """Retry raises HTTPStatusError after all retries exhausted on 500."""
    resp_500 = _mock_response(500)
    fn = AsyncMock(return_value=resp_500)
    with pytest.raises(httpx.HTTPStatusError):
        await _retry_request(fn, retries=2, backoff=0.001)


@pytest.mark.asyncio
async def test_retry_raises_offline_on_connect_error():
    """Retry raises OfflineError when all retries fail with ConnectError."""
    fn = AsyncMock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(OfflineError, match="Cannot connect"):
        await _retry_request(fn, retries=2, backoff=0.001)


@pytest.mark.asyncio
async def test_retry_raises_offline_on_timeout():
    """Retry raises OfflineError when all retries fail with TimeoutException."""
    fn = AsyncMock(side_effect=httpx.TimeoutException("timed out"))
    with pytest.raises(OfflineError, match="timed out"):
        await _retry_request(fn, retries=2, backoff=0.001)


@pytest.mark.asyncio
async def test_retry_does_not_retry_on_400():
    """Retry does not retry on non-retryable status like 400."""
    resp_400 = _mock_response(400)
    resp_400.raise_for_status = MagicMock()  # 400 is not in retryable set
    fn = AsyncMock(return_value=resp_400)
    resp = await _retry_request(fn, retries=3, backoff=0.001)
    assert resp.status_code == 400
    fn.assert_awaited_once()


@pytest.mark.asyncio
async def test_retry_does_not_retry_on_403():
    """Retry does not retry on 403 Forbidden."""
    resp_403 = _mock_response(403)
    resp_403.raise_for_status = MagicMock()
    fn = AsyncMock(return_value=resp_403)
    resp = await _retry_request(fn, retries=3, backoff=0.001)
    assert resp.status_code == 403
    fn.assert_awaited_once()


# ---- CSRF bootstrap ----


@pytest.mark.asyncio
async def test_get_client_bootstraps_csrf():
    """_get_client fetches CSRF token from /health on first call."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.is_closed = False
        health_resp = MagicMock()
        health_resp.cookies = {"msapling_csrftoken": "csrf-abc"}
        mock_http.get = AsyncMock(return_value=health_resp)
        mock_http.cookies = {}
        mock_http.headers = {}

        with patch("msapling_cli.api.httpx.AsyncClient", return_value=mock_http):
            result = await client._get_client()
            mock_http.get.assert_awaited_with("/health")


@pytest.mark.asyncio
async def test_get_client_handles_offline_csrf_gracefully():
    """_get_client does not crash if /health fails (offline mode)."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_http = AsyncMock(spec=httpx.AsyncClient)
        mock_http.is_closed = False
        mock_http.get = AsyncMock(side_effect=httpx.ConnectError("offline"))
        mock_http.cookies = {}
        mock_http.headers = {}

        with patch("msapling_cli.api.httpx.AsyncClient", return_value=mock_http):
            result = await client._get_client()
            # Should not raise, just silently skip CSRF


# ---- health_check ----


@pytest.mark.asyncio
async def test_health_check_returns_true_on_200():
    """health_check returns True when server responds 200."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value=None):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()
        mock_http = AsyncMock()
        mock_http.is_closed = False
        mock_http.get = AsyncMock(return_value=_mock_response(200))
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http
        assert await client.health_check() is True


@pytest.mark.asyncio
async def test_health_check_returns_false_on_error():
    """health_check returns False when server is unreachable."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value=None):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()
        mock_http = AsyncMock()
        mock_http.is_closed = False
        mock_http.get = AsyncMock(side_effect=httpx.ConnectError("refused"))
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http
        assert await client.health_check() is False


# ---- stream_chat NDJSON parsing ----


@pytest.mark.asyncio
async def test_stream_chat_parses_ndjson_chunks():
    """stream_chat yields parsed JSON objects from NDJSON lines."""
    lines = [
        '{"content": "Hello"}\n',
        '{"content": " world"}\n',
        '{"type": "usage", "tokens": 10}\n',
    ]

    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        async def fake_iter():
            for line in lines:
                yield line

        mock_resp.aiter_text = fake_iter

        mock_http = AsyncMock()
        mock_http.stream = MagicMock(return_value=mock_resp)
        mock_http.is_closed = False
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http

        chunks = []
        async for chunk in client.stream_chat("chat-1", "Hi", "model/x"):
            chunks.append(chunk)

        assert len(chunks) == 3
        assert chunks[0]["content"] == "Hello"
        assert chunks[1]["content"] == " world"
        assert chunks[2]["type"] == "usage"


@pytest.mark.asyncio
async def test_stream_chat_skips_invalid_json():
    """stream_chat silently skips lines that are not valid JSON."""
    lines = [
        '{"content": "ok"}\n',
        'NOT VALID JSON\n',
        '{"content": "still ok"}\n',
    ]

    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        async def fake_iter():
            for line in lines:
                yield line

        mock_resp.aiter_text = fake_iter

        mock_http = AsyncMock()
        mock_http.stream = MagicMock(return_value=mock_resp)
        mock_http.is_closed = False
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http

        chunks = []
        async for chunk in client.stream_chat("chat-1", "Hi", "model/x"):
            chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0]["content"] == "ok"
        assert chunks[1]["content"] == "still ok"


@pytest.mark.asyncio
async def test_stream_chat_handles_partial_buffer():
    """stream_chat handles partial JSON that arrives split across chunks."""
    # Data arrives as fragments not aligned to newlines
    raw_chunks = ['{"content": "H', 'ello"}\n{"content": "W', 'orld"}\n']

    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        async def fake_iter():
            for chunk in raw_chunks:
                yield chunk

        mock_resp.aiter_text = fake_iter

        mock_http = AsyncMock()
        mock_http.stream = MagicMock(return_value=mock_resp)
        mock_http.is_closed = False
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http

        chunks = []
        async for chunk in client.stream_chat("chat-1", "Hi", "model/x"):
            chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0]["content"] == "Hello"
        assert chunks[1]["content"] == "World"


@pytest.mark.asyncio
async def test_stream_chat_stream_disconnect_yields_error():
    """stream_chat yields partial error when stream is interrupted."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        async def fake_iter():
            yield '{"content": "partial"}\n'
            raise httpx.RemoteProtocolError("peer closed connection")

        mock_resp.aiter_text = fake_iter

        mock_http = AsyncMock()
        mock_http.stream = MagicMock(return_value=mock_resp)
        mock_http.is_closed = False
        mock_http.cookies = {}
        mock_http.headers = {}
        client._client = mock_http

        chunks = []
        async for chunk in client.stream_chat("chat-1", "Hi", "model/x"):
            chunks.append(chunk)

        assert len(chunks) == 2
        assert chunks[0]["content"] == "partial"
        assert chunks[1]["type"] == "error"
        assert chunks[1]["partial"] is True


@pytest.mark.asyncio
async def test_stream_chat_diff_mode_injects_system_prompt():
    """stream_chat prepends diff system prompt when diff_mode is True."""
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient(diff_mode=True)

        mock_resp = AsyncMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
        mock_resp.__aexit__ = AsyncMock(return_value=False)

        async def fake_iter():
            yield '{"content": "done"}\n'

        mock_resp.aiter_text = fake_iter

        mock_http = AsyncMock()
        mock_http.is_closed = False
        mock_http.cookies = {}
        mock_http.headers = {}

        captured_payload = {}

        def capture_stream(method, url, **kwargs):
            captured_payload.update(kwargs.get("json", {}))
            return mock_resp

        mock_http.stream = MagicMock(side_effect=capture_stream)
        client._client = mock_http

        async for _ in client.stream_chat("c1", "fix this", "model/x"):
            pass

        # diff_mode is now handled server-side (backend injects from User.diff_mode_enabled)
        # CLI should NOT inject client-side diff prompt anymore
        msgs = captured_payload.get("messages", [])
        # No client-side diff system prompt should be injected
        if msgs:
            assert "unified diff" not in (msgs[0].get("content", "") if msgs[0].get("role") == "system" else "")


# ---- Helper function tests ----


def test_is_paid_user_free():
    """_is_paid_user returns False for free tier."""
    assert _is_paid_user({"tier": "free", "is_pro": False}) is False


def test_is_paid_user_pro():
    """_is_paid_user returns True for pro tier."""
    assert _is_paid_user({"tier": "monthly", "is_pro": True}) is True


def test_is_paid_user_lifetime():
    """_is_paid_user returns True for lifetime tier."""
    assert _is_paid_user({"tier": "lifetime", "is_pro": False}) is True


def test_is_paid_user_none():
    """_is_paid_user returns False for None user."""
    assert _is_paid_user(None) is False


def test_mdrive_scoped_path_project_and_file():
    """_mdrive_scoped_path joins project and file path."""
    assert _mdrive_scoped_path("proj1", "src/main.py") == "proj1/src/main.py"


def test_mdrive_scoped_path_project_only():
    """_mdrive_scoped_path returns project when file is empty."""
    assert _mdrive_scoped_path("proj1", "") == "proj1"


def test_mdrive_scoped_path_strips_slashes():
    """_mdrive_scoped_path strips leading/trailing slashes."""
    assert _mdrive_scoped_path("/proj/", "/file.py/") == "proj/file.py"


def test_normalize_legacy_projects_overview():
    """_normalize_legacy_projects_overview transforms legacy API format."""
    payload = {
        "projects": {
            "Default Project": {"chats": [{"id": "c1"}, {"id": "c2"}]},
            "Side Project": {"chats": [{"id": "c3"}]},
        }
    }
    user = {"tier": "free", "is_pro": False}
    result = _normalize_legacy_projects_overview(payload, user)
    assert result["project_count"] == 2
    assert result["project_limit"] == FREE_PROJECT_LIMIT
    names = {p["name"] for p in result["projects"]}
    assert "Default Project" in names
    assert "Side Project" in names


# ---- Retryable status codes set ----


def test_retryable_status_codes():
    """All expected transient HTTP codes are in the retryable set."""
    assert 429 in RETRYABLE_STATUS_CODES
    assert 500 in RETRYABLE_STATUS_CODES
    assert 502 in RETRYABLE_STATUS_CODES
    assert 503 in RETRYABLE_STATUS_CODES
    assert 504 in RETRYABLE_STATUS_CODES
    assert 400 not in RETRYABLE_STATUS_CODES
    assert 401 not in RETRYABLE_STATUS_CODES

@pytest.mark.asyncio
async def test_multi_chat_uses_isolated_clients(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        root = MSaplingClient()

    seen_ids = []
    seen_clients = []

    async def fake_chat_once(self, prompt, model, history=None):
        seen_ids.append(id(self))
        seen_clients.append(self)
        return f"ok:{model}"

    async def fake_close(self):
        return None

    monkeypatch.setattr(MSaplingClient, "chat_once", fake_chat_once)
    monkeypatch.setattr(MSaplingClient, "close", fake_close)

    results = await root.multi_chat("hello", ["m1", "m2"])
    assert [r["status"] for r in results] == ["ok", "ok"]
    assert len(set(seen_ids)) == 2
    assert all(client is not root for client in seen_clients)


@pytest.mark.asyncio
async def test_generate_diff_uses_file_path_field():
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    mock_http = AsyncMock()
    mock_http.is_closed = False
    mock_http.cookies = {}
    mock_http.headers = {}
    mock_http.post = AsyncMock(return_value=_mock_response(200, {"diff": "--- a\n+++ b"}))
    client._client = mock_http

    await client.generate_diff("old", "new", "demo.py")
    payload = mock_http.post.call_args.kwargs["json"]
    assert payload["file_path"] == "demo.py"
    assert "filename" not in payload


@pytest.mark.asyncio
async def test_apply_diff_uses_file_path_field():
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    mock_http = AsyncMock()
    mock_http.is_closed = False
    mock_http.cookies = {}
    mock_http.headers = {}
    mock_http.post = AsyncMock(return_value=_mock_response(200, {"success": True, "new_content": "x"}))
    client._client = mock_http

    await client.apply_diff("orig", "diff", "demo.py")
    payload = mock_http.post.call_args.kwargs["json"]
    assert payload["file_path"] == "demo.py"


@pytest.mark.asyncio
async def test_ensure_server_chat_caches_by_project_title_and_type(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    create_calls = []

    async def fake_create_chat(project_name, title="CLI Chat", model="", client_type="cli"):
        create_calls.append((project_name, title, model, client_type))
        return {"chat_id": "chat-123"}

    monkeypatch.setattr(client, "create_chat", fake_create_chat)

    first = await client.ensure_server_chat(project_name="Default Project", title="CLI Quick Chat", model="m1", client_type="cli")
    second = await client.ensure_server_chat(project_name="Default Project", title="CLI Quick Chat", model="m1", client_type="cli")

    assert first == "chat-123"
    assert second == "chat-123"
    assert create_calls == [("Default Project", "CLI Quick Chat", "m1", "cli")]


@pytest.mark.asyncio
async def test_chat_once_requires_server_chat(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    async def fake_create_temporary_chat(model, **kwargs):
        return None

    monkeypatch.setattr(client, "create_temporary_chat", fake_create_temporary_chat)

    with pytest.raises(APIError, match="server chat"):
        await client.chat_once("hello", "m1")


@pytest.mark.asyncio
async def test_stream_chat_includes_attached_files():
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    class _StreamResponse:
        status_code = 200
        headers = {"content-type": "application/x-ndjson"}

        def raise_for_status(self):
            return None

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def aiter_text(self):
            yield json.dumps({"content": "ok"}) + "\n"

    mock_http = AsyncMock()
    mock_http.is_closed = False
    mock_http.cookies = {}
    mock_http.headers = {}
    mock_http.stream = MagicMock(return_value=_StreamResponse())
    client._client = mock_http

    chunks = []
    async for chunk in client.stream_chat(
        chat_id="chat-1",
        prompt="describe this image",
        model="m1",
        project_name="Default Project",
        attached_files=[{"filename": "cat.png", "data_url": "data:image/png;base64,abc"}],
    ):
        chunks.append(chunk)

    payload = mock_http.stream.call_args.kwargs["json"]
    assert payload["attached_files"] == [{"filename": "cat.png", "data_url": "data:image/png;base64,abc"}]
    assert chunks == [{"content": "ok"}]


@pytest.mark.asyncio
async def test_ensure_server_chat_reuses_existing_project_chat(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    async def fake_list_project_chats(project_name):
        assert project_name == "Default Project"
        return [
            {"id": "chat-existing", "title": "CLI Quick Chat", "model": "m1"},
            {"id": "chat-other", "title": "Something Else", "model": "m2"},
        ]

    async def fake_create_chat(*args, **kwargs):
        raise AssertionError("create_chat should not be called when a reusable chat exists")

    monkeypatch.setattr(client, "list_project_chats", fake_list_project_chats)
    monkeypatch.setattr(client, "create_chat", fake_create_chat)

    chat_id = await client.ensure_server_chat(
        project_name="Default Project",
        title="CLI Quick Chat",
        model="m1",
        client_type="cli",
    )

    assert chat_id == "chat-existing"


@pytest.mark.asyncio
async def test_ensure_server_chat_falls_back_to_default_project_on_project_limit(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    create_calls = []

    async def fake_list_project_chats(project_name):
        # No reusable chats: force create_chat path for both projects.
        return []

    async def fake_create_chat(project_name, title="CLI Chat", model="", client_type="cli"):
        create_calls.append((project_name, title, model, client_type))
        if project_name == "CLI Utility":
            raise APIError("Project limit reached (10 max).", status_code=403)
        if project_name == DEFAULT_PROJECT_NAME:
            return {"chat_id": "chat-default-fallback"}
        raise AssertionError(f"Unexpected project_name: {project_name}")

    monkeypatch.setattr(client, "list_project_chats", fake_list_project_chats)
    monkeypatch.setattr(client, "create_chat", fake_create_chat)

    chat_id = await client.ensure_server_chat(
        project_name="CLI Utility",
        title="CLI Utility â€” gemini-2.0-flash-001",
        model="google/gemini-2.0-flash-001",
        client_type="cli-utility",
        reuse=True,
    )

    assert chat_id == "chat-default-fallback"
    assert create_calls == [
        ("CLI Utility", "CLI Utility â€” gemini-2.0-flash-001", "google/gemini-2.0-flash-001", "cli-utility"),
        (DEFAULT_PROJECT_NAME, "CLI Utility â€” gemini-2.0-flash-001", "google/gemini-2.0-flash-001", "cli-utility"),
    ]


@pytest.mark.asyncio
async def test_ensure_server_chat_falls_back_to_default_project_on_raw_403(monkeypatch):
    with patch("msapling_cli.api.get_settings") as gs, \
         patch("msapling_cli.api.get_token", return_value="tok"):
        gs.return_value = MagicMock(api_url="http://test:8000")
        client = MSaplingClient()

    create_calls = []
    forbidden_resp = _mock_response(403, {"detail": "Project limit reached (10 max)."})

    async def fake_list_project_chats(project_name):
        return []

    async def fake_create_chat(project_name, title="CLI Chat", model="", client_type="cli"):
        create_calls.append((project_name, title, model, client_type))
        if project_name == "CLI Utility":
            raise httpx.HTTPStatusError("403 Forbidden", request=MagicMock(), response=forbidden_resp)
        return {"chat_id": "chat-default-fallback-403"}

    monkeypatch.setattr(client, "list_project_chats", fake_list_project_chats)
    monkeypatch.setattr(client, "create_chat", fake_create_chat)

    chat_id = await client.ensure_server_chat(
        project_name="CLI Utility",
        title="CLI Utility â€” gpt-5",
        model="openai/gpt-5",
        client_type="cli-utility",
        reuse=True,
    )

    assert chat_id == "chat-default-fallback-403"
    assert create_calls == [
        ("CLI Utility", "CLI Utility â€” gpt-5", "openai/gpt-5", "cli-utility"),
        (DEFAULT_PROJECT_NAME, "CLI Utility â€” gpt-5", "openai/gpt-5", "cli-utility"),
    ]
