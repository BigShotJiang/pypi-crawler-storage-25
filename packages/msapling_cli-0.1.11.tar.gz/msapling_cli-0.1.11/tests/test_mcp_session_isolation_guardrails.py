"""
Guardrail tests for MCP per-client session isolation.

All tests are source-scan / unit level — no network calls, no subprocess.
They verify the structural properties promised by the INBOX task:

  1. _CLIENT_SESSIONS dict exists
  2. client_id generated as uuid4 per connection
  3. Session cleanup on disconnect (_destroy_client_session)
  4. _CLIENT_SESSIONS_MAX cap present
  5. LRU eviction when at capacity
  6. client_id passed to _handle_tool (signature / source scan)
  7. stdio serve() allocates a new client_id and session
  8. SSE events handler allocates a client_id per connection
  9. Concurrent sessions are truly isolated (no shared state bleed)
 10. _get_client_session moves entry to MRU on access
"""
from __future__ import annotations

import importlib
import inspect
import re
import sys
import types
import uuid
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

SERVER_PATH = Path(__file__).parent.parent / "msapling_cli" / "mcp" / "server.py"
SERVER_SRC: str = SERVER_PATH.read_text(encoding="utf-8")


def _import_server() -> types.ModuleType:
    """Import the server module, skipping heavy optional deps."""
    # Stub out aiohttp so the module loads without it installed.
    if "aiohttp" not in sys.modules:
        aiohttp_stub = types.ModuleType("aiohttp")
        aiohttp_stub.web = types.ModuleType("aiohttp.web")
        sys.modules["aiohttp"] = aiohttp_stub
        sys.modules["aiohttp.web"] = aiohttp_stub.web

    spec = importlib.util.spec_from_file_location(
        "msapling_cli.mcp.server_test_copy", str(SERVER_PATH)
    )
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    # Stub relative imports so we don't need the full package installed.
    parent = types.ModuleType("msapling_cli")
    parent.__version__ = "test"
    parent.__path__ = []  # type: ignore[assignment]
    sys.modules.setdefault("msapling_cli", parent)
    sys.modules.setdefault("msapling_cli.mcp", types.ModuleType("msapling_cli.mcp"))
    # The __version__ attr is imported from the package __init__.
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestClientSessionsDictExists:
    """1. _CLIENT_SESSIONS dict is defined at module level."""

    def test_dict_in_source(self):
        assert "_CLIENT_SESSIONS" in SERVER_SRC, (
            "_CLIENT_SESSIONS not found in server.py source"
        )

    def test_dict_is_ordered_dict_in_source(self):
        # Must use OrderedDict for LRU semantics.
        assert "OrderedDict" in SERVER_SRC, (
            "OrderedDict not used in server.py — required for LRU eviction"
        )

    def test_dict_accessible_on_module(self):
        mod = _import_server()
        assert hasattr(mod, "_CLIENT_SESSIONS"), "_CLIENT_SESSIONS not exposed on module"
        assert isinstance(mod._CLIENT_SESSIONS, OrderedDict), (
            "_CLIENT_SESSIONS must be an OrderedDict"
        )


class TestClientIdGeneratedPerConnection:
    """2. client_id is generated as a UUID4 per connection."""

    def test_uuid_import_present(self):
        assert "import uuid" in SERVER_SRC, "uuid module not imported in server.py"

    def test_uuid4_call_present(self):
        assert "uuid.uuid4()" in SERVER_SRC, (
            "uuid.uuid4() call not found in server.py — client_id must be generated per connection"
        )

    def test_create_session_returns_unique_ids(self):
        mod = _import_server()
        # Reset shared state for test isolation.
        mod._CLIENT_SESSIONS.clear()
        id1 = str(uuid.uuid4())
        id2 = str(uuid.uuid4())
        s1 = mod._create_client_session(id1)
        s2 = mod._create_client_session(id2)
        assert s1["client_id"] != s2["client_id"], (
            "Two sessions must have distinct client_ids"
        )
        mod._CLIENT_SESSIONS.clear()


class TestSessionCleanupOnDisconnect:
    """3. Sessions are removed when a client disconnects."""

    def test_destroy_function_in_source(self):
        assert "_destroy_client_session" in SERVER_SRC, (
            "_destroy_client_session not found in server.py"
        )

    def test_destroy_called_in_sse_events_handler(self):
        # The SSE events handler must call _destroy_client_session in a finally
        # block so cleanup happens on disconnect.
        assert re.search(
            r"_destroy_client_session\(client_id\)",
            SERVER_SRC,
        ), "_destroy_client_session(client_id) not called in server.py"

    def test_destroy_removes_session_from_dict(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()
        cid = str(uuid.uuid4())
        mod._create_client_session(cid)
        assert cid in mod._CLIENT_SESSIONS
        mod._destroy_client_session(cid)
        assert cid not in mod._CLIENT_SESSIONS, (
            "_destroy_client_session did not remove the session"
        )
        mod._CLIENT_SESSIONS.clear()

    def test_destroy_of_nonexistent_id_is_safe(self):
        mod = _import_server()
        # Should not raise.
        mod._destroy_client_session("nonexistent-id-that-was-never-created")

    def test_stdio_serve_cleans_up_on_exit(self):
        # Source scan: the stdio path must call _destroy_client_session in its
        # finally block.
        assert "_destroy_client_session(stdio_client_id)" in SERVER_SRC, (
            "stdio serve() does not call _destroy_client_session in its finally block"
        )


class TestClientSessionsMaxCap:
    """4. _CLIENT_SESSIONS_MAX cap is defined."""

    def test_max_constant_in_source(self):
        assert "_CLIENT_SESSIONS_MAX" in SERVER_SRC, (
            "_CLIENT_SESSIONS_MAX constant not found in server.py"
        )

    def test_max_value_is_50(self):
        mod = _import_server()
        assert hasattr(mod, "_CLIENT_SESSIONS_MAX"), (
            "_CLIENT_SESSIONS_MAX not accessible on module"
        )
        assert mod._CLIENT_SESSIONS_MAX == 50, (
            f"_CLIENT_SESSIONS_MAX should be 50, got {mod._CLIENT_SESSIONS_MAX}"
        )


class TestLRUEviction:
    """5. LRU eviction fires when the dict reaches capacity."""

    def test_eviction_logic_in_source(self):
        # popitem(last=False) evicts the oldest (LRU) entry in an OrderedDict.
        assert "popitem(last=False)" in SERVER_SRC, (
            "LRU eviction via popitem(last=False) not found in server.py"
        )

    def test_eviction_removes_oldest_entry(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()
        original_max = mod._CLIENT_SESSIONS_MAX
        mod._CLIENT_SESSIONS_MAX = 3

        ids = [str(uuid.uuid4()) for _ in range(3)]
        for cid in ids:
            mod._create_client_session(cid)

        # At capacity — next insert must evict the oldest.
        new_id = str(uuid.uuid4())
        mod._create_client_session(new_id)

        assert len(mod._CLIENT_SESSIONS) == 3, (
            f"Expected 3 sessions after LRU eviction, got {len(mod._CLIENT_SESSIONS)}"
        )
        assert ids[0] not in mod._CLIENT_SESSIONS, (
            "Oldest session was not evicted when cap was reached"
        )
        assert new_id in mod._CLIENT_SESSIONS, (
            "New session was not added after eviction"
        )

        # Restore.
        mod._CLIENT_SESSIONS_MAX = original_max
        mod._CLIENT_SESSIONS.clear()

    def test_eviction_never_exceeds_max(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()
        original_max = mod._CLIENT_SESSIONS_MAX
        mod._CLIENT_SESSIONS_MAX = 5

        for _ in range(20):
            mod._create_client_session(str(uuid.uuid4()))

        assert len(mod._CLIENT_SESSIONS) <= 5, (
            f"Sessions exceeded _CLIENT_SESSIONS_MAX: {len(mod._CLIENT_SESSIONS)}"
        )

        mod._CLIENT_SESSIONS_MAX = original_max
        mod._CLIENT_SESSIONS.clear()


class TestClientIdPassedToHandleTool:
    """6. client_id is passed through to _handle_tool."""

    def test_handle_tool_accepts_client_id_kwarg(self):
        mod = _import_server()
        sig = inspect.signature(mod._handle_tool)
        assert "client_id" in sig.parameters, (
            "_handle_tool does not accept a client_id parameter"
        )

    def test_handle_tool_accepts_session_kwarg(self):
        mod = _import_server()
        sig = inspect.signature(mod._handle_tool)
        assert "session" in sig.parameters, (
            "_handle_tool does not accept a session parameter"
        )

    def test_client_id_passed_in_stdio_serve(self):
        # The stdio loop must pass client_id= to _handle_tool.
        assert "client_id=stdio_client_id" in SERVER_SRC, (
            "stdio serve() does not pass client_id to _handle_tool"
        )

    def test_client_id_passed_in_sse_rpc_handler(self):
        # The SSE RPC handler must pass client_id= to _handle_tool.
        assert "client_id=client_id" in SERVER_SRC, (
            "_sse_rpc_handler does not pass client_id to _handle_tool"
        )


class TestConcurrentSessionIsolation:
    """9. Two concurrent clients have separate, non-interfering session state."""

    def test_separate_message_histories(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()

        id_a = str(uuid.uuid4())
        id_b = str(uuid.uuid4())
        sess_a = mod._create_client_session(id_a)
        sess_b = mod._create_client_session(id_b)

        sess_a["message_history"].append({"role": "user", "content": "hello from A"})

        assert len(sess_b["message_history"]) == 0, (
            "Client B's message_history was polluted by Client A's writes"
        )
        assert len(sess_a["message_history"]) == 1

        mod._CLIENT_SESSIONS.clear()

    def test_separate_chat_ids(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()

        id_a = str(uuid.uuid4())
        id_b = str(uuid.uuid4())
        sess_a = mod._create_client_session(id_a)
        sess_b = mod._create_client_session(id_b)

        sess_a["chat_id"] = "chat-for-a-only"
        assert sess_b["chat_id"] is None, (
            "Client B inherited Client A's chat_id — sessions are not isolated"
        )

        mod._CLIENT_SESSIONS.clear()


class TestGetClientSessionMRUBehavior:
    """10. _get_client_session moves the entry to MRU on access."""

    def test_get_moves_to_mru(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()

        id1 = str(uuid.uuid4())
        id2 = str(uuid.uuid4())
        mod._create_client_session(id1)
        mod._create_client_session(id2)

        # Access id1 — it should move to the MRU end.
        mod._get_client_session(id1)

        keys = list(mod._CLIENT_SESSIONS.keys())
        assert keys[-1] == id1, (
            "_get_client_session did not move accessed entry to MRU end"
        )

        mod._CLIENT_SESSIONS.clear()

    def test_get_creates_session_if_missing(self):
        mod = _import_server()
        mod._CLIENT_SESSIONS.clear()

        fresh_id = str(uuid.uuid4())
        assert fresh_id not in mod._CLIENT_SESSIONS
        sess = mod._get_client_session(fresh_id)
        assert fresh_id in mod._CLIENT_SESSIONS
        assert sess["client_id"] == fresh_id

        mod._CLIENT_SESSIONS.clear()
