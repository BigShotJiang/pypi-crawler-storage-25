"""Guardrail tests for SES CLI commands (ses run/results/leaderboard/status).

All HTTP calls are mocked — no real network required.
Each test prints a one-line validation summary.
"""
from __future__ import annotations

import json
import types
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from typer.testing import CliRunner

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(status_code: int, body: object) -> MagicMock:
    """Build a fake httpx.Response-like mock."""
    mock = MagicMock(spec=httpx.Response)
    mock.status_code = status_code
    mock.json.return_value = body
    if status_code >= 400:
        mock.raise_for_status.side_effect = httpx.HTTPStatusError(
            f"HTTP {status_code}", request=MagicMock(), response=mock
        )
    else:
        mock.raise_for_status.return_value = None
    return mock


async def _fake_retry(fn):
    """Async side_effect for _retry_request: just call fn() and return its result."""
    result = fn()
    # If it's a coroutine, await it
    if hasattr(result, "__await__"):
        return await result
    return result


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def ses_app():
    from msapling_cli.ses_commands import ses_app as app
    return app


# ---------------------------------------------------------------------------
# Test 1: --dry-run prints config, makes no HTTP call
# ---------------------------------------------------------------------------

def test_ses_run_dry_run_no_api_call(runner, ses_app):
    """--dry-run must print config and exit 0 without any HTTP call."""
    with patch("msapling_cli.ses_commands.MSaplingClient") as MockClient:
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o", "--dry-run"])
    print(f"[PASS] test_ses_run_dry_run_no_api_call: exit={result.exit_code}, has model={'openai/gpt-4o' in result.output}")
    assert result.exit_code == 0, result.output
    assert "openai/gpt-4o" in result.output
    assert "Dry-run" in result.output
    # MSaplingClient was never instantiated (no API call)
    MockClient.assert_not_called()


# ---------------------------------------------------------------------------
# Test 2: ses run calls correct endpoint
# ---------------------------------------------------------------------------

def test_ses_run_calls_correct_endpoint(runner, ses_app):
    """ses run must POST to /api/benchmark/ses/run."""
    queued_body = {"run_id": "abc-123", "model_id": "openai/gpt-4o", "status": "queued", "estimated_minutes": 3}
    status_body = {"run_id": "abc-123", "status": "completed", "progress_pct": 100, "model_id": "openai/gpt-4o", "started_at": None, "error": None}

    posted_paths = []

    def fake_post(path, json=None, **kw):
        posted_paths.append(path)
        return _make_response(200, queued_body)

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post
    mock_http_client.get = MagicMock(return_value=_make_response(200, status_body))

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o"])

    print(f"[PASS] test_ses_run_calls_correct_endpoint: exit={result.exit_code}, paths={posted_paths}")
    assert "/api/benchmark/ses/run" in posted_paths, f"Expected POST to /api/benchmark/ses/run, got {posted_paths}"


# ---------------------------------------------------------------------------
# Test 3: ses leaderboard does NOT require auth token in payload
# ---------------------------------------------------------------------------

def test_ses_leaderboard_no_auth_required(runner, ses_app):
    """ses leaderboard calls GET; no auth token required in the request body."""
    lb_body = {"leaderboard": [{"model_id": "openai/gpt-4o", "avg_score": 0.95, "run_count": 10}], "subject": "overall"}

    def fake_get(path, params=None, **kw):
        return _make_response(200, lb_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["leaderboard"])

    print(f"[PASS] test_ses_leaderboard_no_auth_required: exit={result.exit_code}, has model={'openai/gpt-4o' in result.output}")
    assert result.exit_code == 0, result.output
    assert "openai/gpt-4o" in result.output


# ---------------------------------------------------------------------------
# Test 4: ses results --model passes model_id as query param
# ---------------------------------------------------------------------------

def test_ses_results_filters_by_model(runner, ses_app):
    """--model flag must be forwarded as ?model_id= query param."""
    results_body = [
        {"run_id": "run-1", "model_id": "anthropic/claude-3-haiku", "subject": "code",
         "score": 0.88, "latency_p50_ms": 450, "cost_usd": 0.001, "completed_at": "2026-04-18T00:00:00Z"}
    ]
    captured_params = {}

    def fake_get(path, params=None, **kw):
        captured_params.update(params or {})
        return _make_response(200, results_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["results", "--model", "anthropic/claude-3-haiku"])

    print(f"[PASS] test_ses_results_filters_by_model: params={captured_params}")
    assert result.exit_code == 0, result.output
    assert captured_params.get("model_id") == "anthropic/claude-3-haiku"


# ---------------------------------------------------------------------------
# Test 5: ses status displays progress_pct
# ---------------------------------------------------------------------------

def test_ses_status_shows_progress(runner, ses_app):
    """ses status must display progress_pct from the status response."""
    status_body = {
        "run_id": "run-xyz",
        "status": "running",
        "progress_pct": 42,
        "model_id": "openai/gpt-4o",
        "started_at": "2026-04-18T10:00:00Z",
        "error": None,
    }

    def fake_get(path, **kw):
        return _make_response(200, status_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["status", "run-xyz"])

    print(f"[PASS] test_ses_status_shows_progress: output={result.output!r}")
    assert result.exit_code == 0, result.output
    assert "42" in result.output
    assert "running" in result.output


# ---------------------------------------------------------------------------
# Test 6: ses run handles 402 out-of-fuel gracefully
# ---------------------------------------------------------------------------

def test_ses_run_handles_402(runner, ses_app):
    """ses run with 402 response must print fuel-credit message and exit 1."""
    def fake_post(path, json=None, **kw):
        return _make_response(402, {"detail": "Insufficient credits"})

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o"])

    print(f"[PASS] test_ses_run_handles_402: exit={result.exit_code}, output={result.output!r}")
    assert result.exit_code != 0
    assert "credits" in result.output.lower() or "fuel" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 7: ses run handles 401 auth error
# ---------------------------------------------------------------------------

def test_ses_run_handles_401(runner, ses_app):
    """ses run with 401 must prompt the user to login."""
    def fake_post(path, json=None, **kw):
        return _make_response(401, {"detail": "Unauthorized"})

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o"])

    print(f"[PASS] test_ses_run_handles_401: exit={result.exit_code}, mentions login={'login' in result.output.lower()}")
    assert result.exit_code != 0
    assert "login" in result.output.lower() or "auth" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 8: ses status 404 shows clear error
# ---------------------------------------------------------------------------

def test_ses_status_404_shows_error(runner, ses_app):
    """ses status with 404 must print error and exit 1."""
    def fake_get(path, **kw):
        return _make_response(404, {"detail": "Not found"})

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["status", "nonexistent-run-id"])

    print(f"[PASS] test_ses_status_404_shows_error: exit={result.exit_code}")
    assert result.exit_code != 0
    assert "not found" in result.output.lower() or "nonexistent" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 9: ses run --subject passes subject_filter in payload
# ---------------------------------------------------------------------------

def test_ses_run_subject_in_payload(runner, ses_app):
    """--subject flag must be included as subject_filter in POST body."""
    queued_body = {"run_id": "sub-run-1", "model_id": "openai/gpt-4o", "status": "queued", "estimated_minutes": 3}
    status_body = {"run_id": "sub-run-1", "status": "completed", "progress_pct": 100, "model_id": "openai/gpt-4o", "started_at": None, "error": None}
    captured_payload = {}

    def fake_post(path, json=None, **kw):
        captured_payload.update(json or {})
        return _make_response(200, queued_body)

    def fake_get(path, **kw):
        return _make_response(200, status_body)

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o", "--subject", "math"])

    print(f"[PASS] test_ses_run_subject_in_payload: payload={captured_payload}")
    assert captured_payload.get("subject_filter") == "math"


# ---------------------------------------------------------------------------
# Test 10: ses results renders a Rich table
# ---------------------------------------------------------------------------

def test_ses_results_renders_table(runner, ses_app):
    """ses results must render a table with model column."""
    results_body = [
        {"run_id": "r1", "model_id": "openai/gpt-4o", "subject": "all",
         "score": 0.91, "latency_p50_ms": 300, "cost_usd": 0.002, "completed_at": "2026-04-18T00:00:00Z"}
    ]

    def fake_get(path, params=None, **kw):
        return _make_response(200, results_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["results"])

    # Rich truncates long model names in narrow columns; check for partial match
    has_model = "openai" in result.output or "gpt-4o" in result.output
    print(f"[PASS] test_ses_results_renders_table: exit={result.exit_code}, has model={has_model}")
    assert result.exit_code == 0, result.output
    # Table is present (has box-drawing chars or column headers)
    assert "SES Results" in result.output or "Model" in result.output
    assert has_model


# ---------------------------------------------------------------------------
# Test 11: ses leaderboard --top limits rows displayed
# ---------------------------------------------------------------------------

def test_ses_leaderboard_top_flag(runner, ses_app):
    """--top flag must be forwarded to the API as query param."""
    lb_body = {"leaderboard": [
        {"model_id": f"model/{i}", "avg_score": 1.0 - i * 0.05, "run_count": 5}
        for i in range(25)
    ], "subject": "overall"}
    captured_params = {}

    def fake_get(path, params=None, **kw):
        captured_params.update(params or {})
        return _make_response(200, lb_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["leaderboard", "--top", "5"])

    print(f"[PASS] test_ses_leaderboard_top_flag: params={captured_params}")
    assert result.exit_code == 0, result.output
    assert captured_params.get("top") == 5


# ---------------------------------------------------------------------------
# Test 12: ses run --output saves JSON to file
# ---------------------------------------------------------------------------

def test_ses_run_output_file(runner, ses_app, tmp_path):
    """--output saves the result JSON to a file."""
    out_file = str(tmp_path / "result.json")
    queued_body = {"run_id": "out-run", "model_id": "openai/gpt-4o", "status": "queued", "estimated_minutes": 3}
    status_body = {"run_id": "out-run", "status": "completed", "progress_pct": 100, "model_id": "openai/gpt-4o", "started_at": None, "error": None}

    def fake_post(path, json=None, **kw):
        return _make_response(200, queued_body)

    def fake_get(path, **kw):
        return _make_response(200, status_body)

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o", "--output", out_file])

    import pathlib
    saved = pathlib.Path(out_file).read_text(encoding="utf-8")
    saved_data = json.loads(saved)
    print(f"[PASS] test_ses_run_output_file: run_id={saved_data.get('run_id')}")
    assert result.exit_code == 0, result.output
    assert saved_data.get("run_id") == "out-run"


# ---------------------------------------------------------------------------
# Test 13: ses results shows empty message when no results
# ---------------------------------------------------------------------------

def test_ses_results_empty(runner, ses_app):
    """ses results with no data must print a message, not crash."""
    def fake_get(path, params=None, **kw):
        return _make_response(200, [])

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["results"])

    print(f"[PASS] test_ses_results_empty: exit={result.exit_code}, output={result.output!r}")
    assert result.exit_code == 0, result.output
    assert "no ses" in result.output.lower() or "no" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 14: ses leaderboard empty
# ---------------------------------------------------------------------------

def test_ses_leaderboard_empty(runner, ses_app):
    """ses leaderboard with empty data must print message, not crash."""
    def fake_get(path, params=None, **kw):
        return _make_response(200, {"leaderboard": [], "subject": "overall"})

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["leaderboard"])

    print(f"[PASS] test_ses_leaderboard_empty: exit={result.exit_code}")
    assert result.exit_code == 0, result.output
    assert "empty" in result.output.lower() or "no" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 15: ses status completed shows expected output
# ---------------------------------------------------------------------------

def test_ses_status_completed(runner, ses_app):
    """ses status for a completed run must display 'completed'."""
    status_body = {
        "run_id": "done-run",
        "status": "completed",
        "progress_pct": 100,
        "model_id": "anthropic/claude-3-sonnet",
        "started_at": "2026-04-18T10:00:00Z",
        "error": None,
    }

    def fake_get(path, **kw):
        return _make_response(200, status_body)

    mock_http_client = MagicMock()
    mock_http_client.get = fake_get

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["status", "done-run"])

    print(f"[PASS] test_ses_status_completed: exit={result.exit_code}, has 'completed'={'completed' in result.output}")
    assert result.exit_code == 0, result.output
    assert "completed" in result.output
    assert "100" in result.output


# ---------------------------------------------------------------------------
# Test 16: ses run network error shows friendly message
# ---------------------------------------------------------------------------

def test_ses_run_network_error(runner, ses_app):
    """ses run on network error must show a friendly message and exit 1."""
    def fake_post(path, **kw):
        raise httpx.ConnectError("connection refused")

    mock_http_client = MagicMock()
    mock_http_client.post = fake_post

    mock_client = MagicMock()
    mock_client._get_client = AsyncMock(return_value=mock_http_client)
    mock_client.close = AsyncMock()

    with patch("msapling_cli.ses_commands.MSaplingClient", return_value=mock_client), \
         patch("msapling_cli.ses_commands._retry_request", side_effect=_fake_retry):
        result = runner.invoke(ses_app, ["run", "openai/gpt-4o"])

    print(f"[PASS] test_ses_run_network_error: exit={result.exit_code}")
    assert result.exit_code != 0
