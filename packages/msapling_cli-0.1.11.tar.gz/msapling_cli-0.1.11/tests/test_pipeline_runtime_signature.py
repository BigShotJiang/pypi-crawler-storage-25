from __future__ import annotations

from typing import Any, Dict, List, Optional

from msapling_cli.pipeline import run_parallel_chats, run_pipeline


class _StubClient:
    def __init__(self) -> None:
        self.calls: List[Dict[str, Any]] = []

    async def chat_once(
        self,
        prompt: str,
        model: str,
        history: Optional[list] = None,
        history_enabled: bool = True,
    ) -> str:
        self.calls.append(
            {
                "prompt": prompt,
                "model": model,
                "history": history,
                "history_enabled": history_enabled,
            }
        )
        return f"OUT[{model}]"


async def test_run_parallel_chats_uses_current_chat_once_signature():
    """Regression: parallel should call chat_once(prompt/model/history) only."""
    client = _StubClient()

    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=2,
        model="openai/gpt-4o-mini",
        client=client,
    )

    assert len(results) == 2
    assert all(r.get("error") is None for r in results)
    assert all(r.get("content") == "OUT[openai/gpt-4o-mini]" for r in results)
    assert len(client.calls) == 2
    assert all(c["prompt"] == "Return exactly: OK" for c in client.calls)
    assert all(c["model"] == "openai/gpt-4o-mini" for c in client.calls)
    assert all(c["history"] is None for c in client.calls)


async def test_run_pipeline_sequential_works_with_chat_once_str_return():
    client = _StubClient()
    pipeline = {
        "name": "seq-smoke",
        "mode": "sequential",
        "steps": [
            {"name": "s1", "model": "m1"},
            {"name": "s2", "model": "m2", "inject_previous_output": True},
        ],
    }

    out = await run_pipeline(pipeline=pipeline, prompt="hello", client=client, verbose=False)

    assert out["pipeline"] == "seq-smoke"
    assert len(out["results"]) == 2
    assert out["results"][0]["output"] == "OUT[m1]"
    assert out["results"][1]["output"] == "OUT[m2]"
    assert out["results"][0]["usage"] == {}
    assert out["results"][1]["usage"] == {}

    assert client.calls[0]["prompt"] == "hello"
    assert "Previous step output:\nOUT[m1]\n\nCurrent task:\nOUT[m1]" == client.calls[1]["prompt"]


async def test_run_parallel_chats_retries_transient_500():
    class _FlakyClient:
        def __init__(self) -> None:
            self.calls = 0

        async def chat_once(
            self,
            prompt: str,
            model: str,
            history: Optional[list] = None,
            history_enabled: bool = True,
        ) -> str:
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("500 Internal Server Error")
            return "RECOVERED"

    client = _FlakyClient()
    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=1,
        model="openai/gpt-4o-mini",
        client=client,
        max_attempts=3,
        backoff_s=0.0,
    )

    assert len(results) == 1
    assert results[0]["error"] is None
    assert results[0]["content"] == "RECOVERED"
    assert results[0]["attempts"] == 2
    assert results[0]["retried"] is True
    assert client.calls == 2


async def test_run_parallel_chats_does_not_retry_non_transient_403():
    class _AuthFailClient:
        def __init__(self) -> None:
            self.calls = 0

        async def chat_once(
            self,
            prompt: str,
            model: str,
            history: Optional[list] = None,
            history_enabled: bool = True,
        ) -> str:
            self.calls += 1
            raise RuntimeError("403 Forbidden")

    client = _AuthFailClient()
    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=1,
        model="openai/gpt-4o-mini",
        client=client,
        max_attempts=3,
        backoff_s=0.0,
    )

    assert len(results) == 1
    assert "403" in str(results[0]["error"])
    assert results[0]["attempts"] == 1
    assert results[0]["retried"] is False
    assert client.calls == 1


async def test_run_parallel_chats_treats_error_content_as_failure():
    class _ErrorStringClient:
        async def chat_once(
            self,
            prompt: str,
            model: str,
            history: Optional[list] = None,
            history_enabled: bool = True,
        ) -> str:
            return "[Error: not-a-real-model is not a valid model ID]"

    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=1,
        model="not-a-real-model",
        client=_ErrorStringClient(),
        max_attempts=1,
        backoff_s=0.0,
    )

    assert len(results) == 1
    assert results[0]["content"] is None
    assert "not a valid model id" in str(results[0]["error"]).lower()


async def test_run_parallel_chats_passes_project_name_when_supported():
    class _ProjectAwareClient:
        def __init__(self) -> None:
            self.calls: List[Dict[str, Any]] = []

        async def chat_once(
            self,
            prompt: str,
            model: str,
            history: Optional[list] = None,
            history_enabled: bool = True,
            project_name: str = "",
        ) -> str:
            self.calls.append(
                {
                    "prompt": prompt,
                    "model": model,
                    "project_name": project_name,
                }
            )
            return "OK"

    client = _ProjectAwareClient()
    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=1,
        model="openai/gpt-4o-mini",
        client=client,
        project_name="CLI Utility",
        max_attempts=1,
        backoff_s=0.0,
        stagger_s=0.0,
    )

    assert len(results) == 1
    assert results[0]["error"] is None
    assert client.calls[0]["project_name"] == "CLI Utility"


async def test_run_parallel_chats_project_name_fallback_for_legacy_client():
    class _LegacyClient:
        def __init__(self) -> None:
            self.calls = 0

        async def chat_once(
            self,
            prompt: str,
            model: str,
            history: Optional[list] = None,
            history_enabled: bool = True,
        ) -> str:
            self.calls += 1
            return "OK"

    client = _LegacyClient()
    results = await run_parallel_chats(
        prompt="Return exactly: OK",
        n=1,
        model="openai/gpt-4o-mini",
        client=client,
        project_name="CLI Utility",
        max_attempts=1,
        backoff_s=0.0,
        stagger_s=0.0,
    )

    assert len(results) == 1
    assert results[0]["error"] is None
    assert client.calls == 1
