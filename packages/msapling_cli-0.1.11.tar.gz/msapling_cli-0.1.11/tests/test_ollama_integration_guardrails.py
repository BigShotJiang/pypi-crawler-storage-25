"""
test_ollama_integration_guardrails.py

Source-scan guardrail tests for the Ollama CLI --provider integration.

Covers:
1.  --provider option is defined in the chat command (source scan)
2.  'ollama' is listed as a valid provider value in the help text (source scan)
3.  MSAPLING_OLLAMA_URL env var is referenced in main.py (source scan)
4.  Direct Ollama routing when provider=ollama (source scan: MSAPLING_PROVIDER set)
5.  ollama/ prefix forced when --provider ollama is used (source scan)
6.  MSAPLING_PROVIDER env var is set to 'ollama' when provider arg is ollama (source scan)
7.  _stream_chat_ollama is invoked for ollama/ models in api.py (source scan)
8.  --provider and -m (model) options are independent and both present in chat() (source scan)
"""
from __future__ import annotations

from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Source paths
# ---------------------------------------------------------------------------

_CLI_ROOT = Path(__file__).resolve().parents[1]  # cli/
_MAIN_PY = _CLI_ROOT / "msapling_cli" / "main.py"
_API_PY = _CLI_ROOT / "msapling_cli" / "api.py"


def _main_src() -> str:
    return _MAIN_PY.read_text(encoding="utf-8")


def _api_src() -> str:
    return _API_PY.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Test 1: --provider option exists in chat()
# ---------------------------------------------------------------------------

def test_provider_option_defined_in_chat():
    """chat() must declare a --provider typer.Option."""
    src = _main_src()
    assert "--provider" in src, (
        "chat() must have a --provider option "
        "(typer.Option(None, '--provider', ...))"
    )


# ---------------------------------------------------------------------------
# Test 2: 'ollama' is a valid provider value
# ---------------------------------------------------------------------------

def test_ollama_is_valid_provider_value():
    """Source must reference 'ollama' as a valid provider in the chat command."""
    src = _main_src()
    # The help text or comment should list "ollama" as a valid provider.
    assert "ollama" in src.lower(), (
        "main.py must reference 'ollama' as a valid --provider value."
    )
    # The provider help string should mention ollama explicitly.
    assert "Provider: ollama" in src or "provider: ollama" in src.lower(), (
        "The --provider help text must list 'ollama' as a valid value."
    )


# ---------------------------------------------------------------------------
# Test 3: MSAPLING_OLLAMA_URL env var is used
# ---------------------------------------------------------------------------

def test_msapling_ollama_url_env_var_used():
    """MSAPLING_OLLAMA_URL must be set/read in main.py when --provider ollama."""
    src = _main_src()
    assert "MSAPLING_OLLAMA_URL" in src, (
        "main.py must reference MSAPLING_OLLAMA_URL env var "
        "to allow override of the Ollama base URL."
    )


# ---------------------------------------------------------------------------
# Test 4: Direct Ollama routing when provider=ollama
# ---------------------------------------------------------------------------

def test_direct_ollama_routing_when_provider_ollama():
    """When --provider ollama, MSAPLING_PROVIDER must be set to 'ollama'."""
    src = _main_src()
    assert 'MSAPLING_PROVIDER' in src, (
        "main.py must set os.environ['MSAPLING_PROVIDER'] = 'ollama' "
        "when --provider ollama is used."
    )
    assert '"ollama"' in src or "'ollama'" in src, (
        "The string 'ollama' must be assigned to MSAPLING_PROVIDER."
    )


# ---------------------------------------------------------------------------
# Test 5: ollama/ prefix forced when --provider ollama given without prefix
# ---------------------------------------------------------------------------

def test_ollama_prefix_forced_on_provider_flag():
    """When --provider ollama with a bare model name, prefix must be forced to 'ollama/'."""
    src = _main_src()
    # The code must build the prefixed model ID.
    assert "ollama/" in src, (
        "main.py must prepend 'ollama/' to the model name when --provider ollama is used."
    )


# ---------------------------------------------------------------------------
# Test 6: MSAPLING_PROVIDER set to 'ollama' string literal
# ---------------------------------------------------------------------------

def test_msapling_provider_set_to_ollama_literal():
    """os.environ['MSAPLING_PROVIDER'] must be assigned the literal value 'ollama'."""
    src = _main_src()
    assert "MSAPLING_PROVIDER" in src, "MSAPLING_PROVIDER must be set in main.py"
    # Check the assignment exists
    assert "= \"ollama\"" in src or "= 'ollama'" in src, (
        "MSAPLING_PROVIDER must be explicitly set to the string 'ollama'."
    )


# ---------------------------------------------------------------------------
# Test 7: _stream_chat_ollama invoked for ollama/ models in api.py
# ---------------------------------------------------------------------------

def test_stream_chat_ollama_invoked_for_ollama_models():
    """api.py must call _stream_chat_ollama when model is an ollama/ model."""
    src = _api_src()
    assert "_stream_chat_ollama" in src, (
        "api.py must define/invoke _stream_chat_ollama for local Ollama routing."
    )
    assert "_is_ollama_model" in src, (
        "api.py must use _is_ollama_model() to detect Ollama models."
    )


# ---------------------------------------------------------------------------
# Test 8: --provider and -m are both independent options in chat()
# ---------------------------------------------------------------------------

def test_provider_and_model_options_are_independent():
    """chat() must have both --provider and -m/-model options defined separately."""
    src = _main_src()
    assert "--provider" in src, "chat() must have --provider option"
    assert '"-m"' in src or "'-m'" in src, "chat() must have -m/--model option"
    # Both should be in the chat() function definition (within ~80 lines of each other)
    chat_start = src.find("def chat(")
    assert chat_start != -1, "chat() function must exist"
    chat_body_end = src.find("def ", chat_start + 1)
    chat_def = src[chat_start:chat_body_end] if chat_body_end > chat_start else src[chat_start:]
    assert "--provider" in chat_def, "--provider must be in chat() signature"
    assert '"-m"' in chat_def or "'-m'" in chat_def, "-m must be in chat() signature"
