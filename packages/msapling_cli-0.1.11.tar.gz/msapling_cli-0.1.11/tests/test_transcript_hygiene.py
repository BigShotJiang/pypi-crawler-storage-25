from __future__ import annotations

import json
from pathlib import Path

from msapling_cli.transcript_hygiene import repair_session_file, sanitize_transcript_messages

_TEST_DIR = Path(__file__).parent / "tmp_cli_workaround"


def test_sanitize_transcript_messages_normalizes_and_dedupes():
    cleaned, report = sanitize_transcript_messages(
        [
            {"role": "human", "content": " hello "},
            {"role": "ai", "content": "same"},
            {"role": "assistant", "content": "same"},
            {"role": "tool_result", "content": "tool_call_id=abc-123"},
            "bad",
            {"role": "user", "content": ""},
        ]
    )
    assert cleaned == [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "same"},
        {"role": "tool", "content": "tool_call_id=toolcall-001"},
    ]
    assert report.dropped_messages >= 2
    assert report.rewritten_roles >= 2
    assert report.deduped_messages == 1
    assert report.normalized_tool_call_ids >= 1


def test_sanitize_transcript_repairs_out_of_order_tool_results():
    cleaned, report = sanitize_transcript_messages(
        [
            {"role": "tool", "content": "tool_call_id=abc result=early"},
            {"role": "assistant", "content": "planning tool_call_id=abc"},
            {"role": "tool", "content": "result-without-id"},
        ]
    )
    assert cleaned == [
        {"role": "assistant", "content": "planning tool_call_id=toolcall-001"},
        {"role": "tool", "content": "tool_call_id=toolcall-001 result=early"},
        {"role": "tool", "content": "result-without-id"},
    ]
    assert report.ordering_fixups >= 1
    assert report.paired_tool_results >= 1
    assert report.dropped_unpaired_tool_results == 0


def test_repair_session_file_dry_run_does_not_write():
    _TEST_DIR.mkdir(parents=True, exist_ok=True)
    session_path = _TEST_DIR / "hygiene_s1.json"
    session_path.write_text(
        json.dumps(
            {
                "id": "s1",
                "messages": [
                    {"role": "human", "content": " hi "},
                    {"role": "assistant", "content": "ok"},
                    {"role": "assistant", "content": "ok"},
                ],
            }
        ),
        encoding="utf-8",
    )

    result = repair_session_file(session_path, dry_run=True)
    assert result["changed"] is True
    assert result["backup_path"] is None
    assert result["diff_line_count"] > 0
    assert "messages.before" in result["diff_preview"]

    raw = json.loads(session_path.read_text(encoding="utf-8"))
    assert raw["messages"][0]["role"] == "human"


def test_repair_session_file_writes_backup_and_metadata():
    _TEST_DIR.mkdir(parents=True, exist_ok=True)
    session_path = _TEST_DIR / "hygiene_s2.json"
    session_path.write_text(
        json.dumps(
            {
                "id": "s2",
                "messages": [
                    {"role": "human", "content": " hi "},
                    {"role": "assistant", "content": "ok"},
                    {"role": "assistant", "content": "ok"},
                ],
                "metadata": {},
            }
        ),
        encoding="utf-8",
    )

    result = repair_session_file(session_path, dry_run=False)
    assert result["changed"] is True
    assert result["backup_path"]
    assert Path(result["backup_path"]).exists()

    updated = json.loads(session_path.read_text(encoding="utf-8"))
    assert updated["messages"] == [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "ok"},
    ]
    assert "transcript_hygiene" in updated["metadata"]
