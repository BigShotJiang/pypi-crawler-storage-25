"""Guardrail tests for cli/msapling_cli/quality_gate.py and
backend/hooks/stop_quality_gate.py.

Test strategy:
  - Unit-level: exercise run_session_quality_gate() with real temp files and
    mocked subprocesses so no external tools are required.
  - Source-level: assert key identifiers exist in the source files so that
    accidental deletions are caught immediately.
  - Integration smoke: the dataclass fields, the dirty flag, and the
    duration_ms timing are all validated without needing ruff or tsc.
"""
from __future__ import annotations

import subprocess
import sys
import textwrap
import time
from pathlib import Path
from typing import List
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_CLI_ROOT = Path(__file__).parent.parent / "msapling_cli"
_BACKEND_HOOKS = Path(__file__).parent.parent.parent / "backend" / "hooks"
_QUALITY_GATE_PY = _CLI_ROOT / "quality_gate.py"
_STOP_GATE_PY = _BACKEND_HOOKS / "stop_quality_gate.py"
_SHELL_PY = _CLI_ROOT / "shell.py"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_py_file(tmp_path: Path, name: str, content: str) -> Path:
    f = tmp_path / name
    f.write_text(content, encoding="utf-8")
    return f


def _make_ts_file(tmp_path: Path, name: str, content: str) -> Path:
    f = tmp_path / name
    f.write_text(content, encoding="utf-8")
    return f


# ---------------------------------------------------------------------------
# Source-level guardrails
# ---------------------------------------------------------------------------


class TestSourceGuardrails:
    """Assert that key identifiers exist in the source files."""

    def test_quality_gate_py_exists(self):
        assert _QUALITY_GATE_PY.is_file(), f"Missing: {_QUALITY_GATE_PY}"

    def test_stop_quality_gate_py_exists(self):
        assert _STOP_GATE_PY.is_file(), f"Missing: {_STOP_GATE_PY}"

    def test_quality_gate_dataclass_defined(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "QualityGateResult" in src, "QualityGateResult dataclass not found"

    def test_run_session_quality_gate_defined(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "run_session_quality_gate" in src

    def test_print_quality_gate_result_defined(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "print_quality_gate_result" in src

    def test_dirty_flag_in_dataclass(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "dirty" in src, "'dirty' field not found in quality_gate.py"

    def test_duration_ms_field_present(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "duration_ms" in src

    def test_ruff_format_check_called(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "ruff" in src and "format" in src and "--check" in src

    def test_ruff_lint_check_called(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "ruff" in src and "check" in src

    def test_tsc_noEmit_called(self):
        src = _QUALITY_GATE_PY.read_text(encoding="utf-8")
        assert "tsc" in src and "--noEmit" in src

    def test_shell_imports_quality_gate(self):
        src = _SHELL_PY.read_text(encoding="utf-8")
        assert "run_session_quality_gate" in src, (
            "shell.py does not import run_session_quality_gate"
        )

    def test_shell_calls_quality_gate_on_exit(self):
        src = _SHELL_PY.read_text(encoding="utf-8")
        assert "run_session_quality_gate" in src and "_touched" in src, (
            "shell.py session-end block does not call run_session_quality_gate"
        )

    def test_shell_dirty_banner(self):
        src = _SHELL_PY.read_text(encoding="utf-8")
        assert "DIRTY" in src, (
            "shell.py does not print the DIRTY warning banner"
        )

    def test_backend_hooks_init_exports_run_quality_gate(self):
        init = (_BACKEND_HOOKS / "__init__.py").read_text(encoding="utf-8")
        assert "run_quality_gate" in init

    def test_backend_stop_gate_has_new_public_api(self):
        src = _STOP_GATE_PY.read_text(encoding="utf-8")
        # The new public API must accept (modified_files, session_id) and return dict
        assert "def run_quality_gate(" in src
        assert "modified_files" in src
        assert "session_id" in src
        assert '"passed"' in src or "'passed'" in src


# ---------------------------------------------------------------------------
# Functional tests — run_session_quality_gate()
# ---------------------------------------------------------------------------


class TestRunSessionQualityGate:
    """Functional tests exercising run_session_quality_gate()."""

    # Import lazily inside tests to avoid module-level import failures during
    # collection if the file doesn't exist yet.
    @pytest.fixture(autouse=True)
    def _import_module(self):
        from msapling_cli import quality_gate as qg
        self.qg = qg

    # ── 1. Empty list → passes ───────────────────────────────────────────

    def test_empty_file_list_passes(self):
        result = self.qg.run_session_quality_gate([])
        assert result.passed is True
        assert result.dirty is False
        assert result.failures == []
        assert result.files_checked == 0

    # ── 2. Duration measured ──────────────────────────────────────────────

    def test_duration_measured(self, tmp_path):
        f = _make_py_file(tmp_path, "ok.py", "x = 1\n")
        with patch.object(self.qg, "_tool_available", return_value=False):
            result = self.qg.run_session_quality_gate([str(f)])
        # Duration is at least 0 and is an int
        assert isinstance(result.duration_ms, int)
        assert result.duration_ms >= 0

    # ── 3. Non-existent file ignored ─────────────────────────────────────

    def test_nonexistent_file_ignored(self, tmp_path):
        missing = str(tmp_path / "ghost.py")
        result = self.qg.run_session_quality_gate([missing])
        assert result.passed is True
        assert result.files_checked == 0

    # ── 4. Non-code file ignored ─────────────────────────────────────────

    def test_non_code_files_ignored(self, tmp_path):
        md = tmp_path / "README.md"
        md.write_text("# hello\n")
        result = self.qg.run_session_quality_gate([str(md)])
        assert result.passed is True
        assert result.files_checked == 0

    # ── 5. Clean .py file with ruff absent → passes (warning) ───────────

    def test_clean_py_no_ruff_returns_warning(self, tmp_path):
        f = _make_py_file(tmp_path, "clean.py", "x = 1\n")
        with patch.object(self.qg, "_tool_available", return_value=False):
            result = self.qg.run_session_quality_gate([str(f)])
        assert result.passed is True
        assert result.dirty is False
        assert any("[SKIP]" in w for w in result.warnings), (
            "Expected a SKIP warning when ruff is missing"
        )

    # ── 6. Missing ruff → warning, not crash ─────────────────────────────

    def test_missing_ruff_no_crash(self, tmp_path):
        f = _make_py_file(tmp_path, "a.py", "def foo(): pass\n")
        with patch.object(self.qg, "_tool_available", return_value=False):
            result = self.qg.run_session_quality_gate([str(f)])
        # Must not raise; result is a QualityGateResult
        assert isinstance(result, self.qg.QualityGateResult)
        assert result.passed is True

    # ── 7. Ruff format failure → dirty=True, failure listed ──────────────

    def test_ruff_format_failure_sets_dirty(self, tmp_path):
        f = _make_py_file(tmp_path, "bad_fmt.py", "x=1\n")

        def fake_tool_available(name: str) -> bool:
            return name == "ruff"

        def fake_run(cmd, cwd=None):
            # Simulate ruff format --check failing
            if "format" in cmd and "--check" in cmd:
                return 1, "Would reformat bad_fmt.py"
            # ruff check passes
            if "check" in cmd and "format" not in cmd:
                return 0, ""
            # ruff --version
            if "--version" in cmd:
                return 0, "ruff 0.4.0"
            return 0, ""

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
        ):
            result = self.qg.run_session_quality_gate([str(f)])

        assert result.dirty is True
        assert result.passed is False
        assert any("FORMAT" in fail for fail in result.failures), (
            f"Expected 'FORMAT' in failures, got: {result.failures}"
        )

    # ── 8. Ruff lint failure → dirty=True, failure listed ────────────────

    def test_ruff_lint_failure_sets_dirty(self, tmp_path):
        f = _make_py_file(tmp_path, "lint_fail.py", "import os\n")

        def fake_tool_available(name: str) -> bool:
            return name == "ruff"

        def fake_run(cmd, cwd=None):
            if "format" in cmd and "--check" in cmd:
                return 0, ""  # format passes
            if "check" in cmd and "format" not in cmd:
                return 1, "lint_fail.py:1:1: F401 'os' imported but unused"
            if "--version" in cmd:
                return 0, "ruff 0.4.0"
            return 0, ""

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
        ):
            result = self.qg.run_session_quality_gate([str(f)])

        assert result.dirty is True
        assert any("LINT" in fail for fail in result.failures)

    # ── 9. .ts file present → tsc attempted ─────────────────────────────

    def test_ts_files_trigger_tsc(self, tmp_path):
        ts_file = _make_ts_file(tmp_path, "comp.tsx", "export const x = 1;\n")

        # Fake a tsconfig.json so the tsc path is reachable
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "tsconfig.json").write_text("{}", encoding="utf-8")

        tsc_called: List[bool] = []

        def fake_tool_available(name: str) -> bool:
            return name == "tsc"

        def fake_run(cmd, cwd=None):
            if "tsc" in cmd[0] or (len(cmd) > 1 and "tsc" in cmd[1]):
                tsc_called.append(True)
                return 0, ""
            return 0, ""

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
            patch.object(self.qg, "_project_root", return_value=tmp_path),
        ):
            result = self.qg.run_session_quality_gate([str(ts_file)])

        assert tsc_called, "tsc was not called when a .tsx file was present"
        assert result.passed is True

    # ── 10. No .ts files → tsc skipped ───────────────────────────────────

    def test_no_ts_files_skips_tsc(self, tmp_path):
        f = _make_py_file(tmp_path, "only_python.py", "x = 1\n")

        tsc_called: List[bool] = []

        def fake_run(cmd, cwd=None):
            if "tsc" in " ".join(cmd):
                tsc_called.append(True)
            return 0, ""

        with (
            patch.object(self.qg, "_tool_available", return_value=False),
            patch.object(self.qg, "_run", side_effect=fake_run),
        ):
            result = self.qg.run_session_quality_gate([str(f)])

        assert not tsc_called, "tsc was called even though no .ts/.tsx files were given"

    # ── 11. Missing tsc → warning, not crash ─────────────────────────────

    def test_missing_tsc_no_crash(self, tmp_path):
        ts_file = _make_ts_file(tmp_path, "x.ts", "const y = 1;\n")

        def fake_tool_available(name: str) -> bool:
            return False  # nothing available

        def fake_run(cmd, cwd=None):
            return -1, f"[SKIP] Command not found: {cmd[0]}"

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
        ):
            result = self.qg.run_session_quality_gate([str(ts_file)])

        assert isinstance(result, self.qg.QualityGateResult)
        assert result.passed is True
        assert any("[SKIP]" in w for w in result.warnings)

    # ── 12. tsc failure → dirty=True ─────────────────────────────────────

    def test_tsc_failure_sets_dirty(self, tmp_path):
        ts_file = _make_ts_file(tmp_path, "broken.ts", "const x: number = 'hello';\n")
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "tsconfig.json").write_text("{}", encoding="utf-8")

        def fake_tool_available(name: str) -> bool:
            return name == "tsc"

        def fake_run(cmd, cwd=None):
            if "--noEmit" in cmd:
                return 1, "broken.ts(1,7): error TS2322: Type 'string' not assignable to 'number'."
            return 0, "tsc 5.0.0"

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
            patch.object(self.qg, "_project_root", return_value=tmp_path),
        ):
            result = self.qg.run_session_quality_gate([str(ts_file)])

        assert result.dirty is True
        assert any("TSC" in fail for fail in result.failures)

    # ── 13. files_checked count is accurate ──────────────────────────────

    def test_files_checked_count(self, tmp_path):
        py1 = _make_py_file(tmp_path, "a.py", "x = 1\n")
        py2 = _make_py_file(tmp_path, "b.py", "y = 2\n")
        md = tmp_path / "notes.md"
        md.write_text("# notes\n")

        with patch.object(self.qg, "_tool_available", return_value=False):
            result = self.qg.run_session_quality_gate(
                [str(py1), str(py2), str(md)]
            )
        # Only .py files count; .md is skipped
        assert result.files_checked == 2

    # ── 14. dirty flag is always negation of passed ───────────────────────

    def test_dirty_is_negation_of_passed(self, tmp_path):
        f = _make_py_file(tmp_path, "any.py", "z = 99\n")
        with patch.object(self.qg, "_tool_available", return_value=False):
            result = self.qg.run_session_quality_gate([str(f)])
        assert result.dirty == (not result.passed)

    # ── 15. both ruff and tsc fail → all failures aggregated ─────────────

    def test_multiple_failures_aggregated(self, tmp_path):
        py_file = _make_py_file(tmp_path, "multi.py", "import os\n")
        ts_file = _make_ts_file(tmp_path, "multi.ts", "const x: number = 'bad';\n")
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "tsconfig.json").write_text("{}", encoding="utf-8")

        def fake_tool_available(name: str) -> bool:
            return name in ("ruff", "tsc")

        def fake_run(cmd, cwd=None):
            if "--version" in cmd:
                return 0, "tool 1.0"
            if "format" in cmd and "--check" in cmd:
                return 1, "Would reformat multi.py"
            if "check" in cmd and "format" not in cmd:
                return 1, "multi.py:1:1: F401 imported but unused"
            if "--noEmit" in cmd:
                return 1, "multi.ts(1,7): error TS2322"
            return 0, ""

        with (
            patch.object(self.qg, "_tool_available", side_effect=fake_tool_available),
            patch.object(self.qg, "_run", side_effect=fake_run),
            patch.object(self.qg, "_project_root", return_value=tmp_path),
        ):
            result = self.qg.run_session_quality_gate(
                [str(py_file), str(ts_file)]
            )

        assert result.dirty is True
        # We should have failures from both Python (FORMAT/LINT) and TS (TSC)
        has_py_fail = any("FORMAT" in f or "LINT" in f for f in result.failures)
        has_ts_fail = any("TSC" in f for f in result.failures)
        assert has_py_fail, f"No Python failure in: {result.failures}"
        assert has_ts_fail, f"No TSC failure in: {result.failures}"

    # ── 16. QualityGateResult __post_init__ keeps dirty in sync ──────────

    def test_quality_gate_result_post_init_sync(self):
        QGR = self.qg.QualityGateResult
        r_pass = QGR(passed=True)
        assert r_pass.dirty is False
        r_fail = QGR(passed=False)
        assert r_fail.dirty is True

    # ── 17. backend run_quality_gate public API shape ─────────────────────

    def test_backend_run_quality_gate_returns_dict(self):
        """backend/hooks/stop_quality_gate.run_quality_gate() must return dict with expected keys."""
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "stop_quality_gate", str(_STOP_GATE_PY)
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]

        result = mod.run_quality_gate([], session_id="test-session")
        assert isinstance(result, dict)
        for key in ("passed", "dirty", "failures", "duration_ms"):
            assert key in result, f"Key '{key}' missing from run_quality_gate() result"
        assert result["passed"] is True
        assert result["dirty"] is False
        assert result["files_checked"] == 0

    # ── 18. Relative paths resolved against project root ─────────────────

    def test_relative_paths_resolved(self, tmp_path):
        f = _make_py_file(tmp_path, "rel.py", "x = 1\n")
        relative = f.name  # just "rel.py"

        with (
            patch.object(self.qg, "_tool_available", return_value=False),
            patch.object(self.qg, "_project_root", return_value=tmp_path),
        ):
            result = self.qg.run_session_quality_gate([relative])

        # File exists relative to project root → should be counted
        assert result.files_checked == 1
