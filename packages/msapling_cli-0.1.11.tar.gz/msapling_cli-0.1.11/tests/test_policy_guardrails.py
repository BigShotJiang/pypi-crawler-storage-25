from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

import msapling_cli.main as main
import msapling_cli.agent as agent_mod
import msapling_cli.policy as policy
from msapling_cli.agent import _check_approval, reset_permissions, set_permission_mode


runner = CliRunner()


def _isolate_policy_paths(monkeypatch, tmp_path: Path) -> tuple[Path, Path]:
    home = tmp_path / "home"
    workspace = tmp_path / "workspace"
    (home / ".msapling" / "policies").mkdir(parents=True)
    (workspace / ".msapling" / "policies").mkdir(parents=True)
    monkeypatch.setattr(policy.Path, "home", classmethod(lambda cls: home))
    monkeypatch.setenv("MSAPLING_POLICY_PATHS", "")
    monkeypatch.setenv("MSAPLING_ADMIN_POLICY_PATHS", "")
    return home, workspace


def test_policy_user_tier_overrides_workspace_tier(monkeypatch, tmp_path):
    home, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    (workspace / ".msapling" / "policies" / "workspace.toml").write_text(
        """
[[rule]]
toolName = "run_command"
decision = "allow"
priority = 999
""",
        encoding="utf-8",
    )
    (home / ".msapling" / "policies" / "user.toml").write_text(
        """
[[rule]]
toolName = "run_command"
commandPrefix = "git push"
decision = "deny"
priority = 1
""",
        encoding="utf-8",
    )

    denied = policy.evaluate_policy(
        "run_command",
        {"command": "git push --force"},
        workspace=workspace,
    )
    allowed = policy.evaluate_policy(
        "run_command",
        {"command": "git status"},
        workspace=workspace,
    )

    assert denied is not None
    assert denied.decision == "deny"
    assert denied.rule.tier == "user"
    assert allowed is not None
    assert allowed.decision == "allow"
    assert allowed.rule.tier == "workspace"


def test_policy_supports_args_pattern_and_mode_scope(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    (workspace / ".msapling" / "policies" / "rules.toml").write_text(
        """
[[rule]]
toolName = "read_file"
argsPattern = "secret"
decision = "deny"
priority = 200

[[rule]]
toolName = "write_file"
modes = ["plan"]
decision = "deny"
priority = 100
""",
        encoding="utf-8",
    )

    secret = policy.evaluate_policy("read_file", {"path": "secret.txt"}, workspace=workspace)
    default_write = policy.evaluate_policy("write_file", {"path": "x.py"}, mode="default", workspace=workspace)
    plan_write = policy.evaluate_policy("write_file", {"path": "x.py"}, mode="plan", workspace=workspace)

    assert secret is not None
    assert secret.decision == "deny"
    assert default_write is None
    assert plan_write is not None
    assert plan_write.decision == "deny"


def test_policy_ask_user_denies_in_noninteractive_mode(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    (workspace / ".msapling" / "policies" / "rules.toml").write_text(
        """
[[rule]]
toolName = "run_command"
decision = "ask_user"
priority = 100
""",
        encoding="utf-8",
    )

    decision = policy.evaluate_policy(
        "run_command",
        {"command": "pytest"},
        interactive=False,
        workspace=workspace,
    )

    assert decision is not None
    assert decision.decision == "deny"


def test_agent_policy_deny_beats_full_mode(monkeypatch):
    reset_permissions()
    agent_mod._permission_context_set({"role": "coordinator", "project_root": str(Path.cwd())})
    set_permission_mode("full")

    monkeypatch.setattr(
        policy,
        "evaluate_policy",
        lambda *args, **kwargs: policy.PolicyDecision(
            decision="deny",
            reason="test policy",
            rule=policy.PolicyRule(tool_name="run_command", decision="deny"),
        ),
    )

    result = _check_approval("run_command", {"command": "echo hi"})

    assert result is not None
    assert "Blocked by policy" in result


def test_agent_policy_allow_does_not_bypass_plan_mode(monkeypatch):
    reset_permissions()
    agent_mod._permission_context_set({"role": "coordinator", "project_root": str(Path.cwd())})
    set_permission_mode("plan")

    monkeypatch.setattr(
        policy,
        "evaluate_policy",
        lambda *args, **kwargs: policy.PolicyDecision(
            decision="allow",
            reason="test policy",
            rule=policy.PolicyRule(tool_name="write_file", decision="allow"),
        ),
    )

    result = _check_approval("write_file", {"path": "x.py", "content": ""})

    assert result is not None
    assert "not allowed in plan mode" in result


def test_config_policy_commands_render(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    (workspace / ".msapling" / "policies" / "rules.toml").write_text(
        """
[[rule]]
toolName = "run_command"
decision = "deny"
priority = 100
""",
        encoding="utf-8",
    )

    help_result = runner.invoke(main.app, ["policy", "--help"])
    legacy_help_result = runner.invoke(main.app, ["config", "policy", "--help"])
    legacy_status_result = runner.invoke(main.app, ["config", "policy", "status"])
    status_result = runner.invoke(main.app, ["policy", "status", "--workspace", str(workspace)])
    paths_result = runner.invoke(main.app, ["policy", "paths", "--workspace", str(workspace)])

    assert help_result.exit_code == 0
    assert "Inspect MSapling tool policy rules." in help_result.stdout
    assert legacy_help_result.exit_code == 0
    assert "Usage: msapling config policy" in legacy_help_result.stdout
    assert legacy_status_result.exit_code == 0
    assert status_result.exit_code == 0
    assert "MSapling Tool Policies" in status_result.stdout
    assert "run_command" in status_result.stdout
    assert paths_result.exit_code == 0
    assert "MSapling Policy Paths" in paths_result.stdout


def test_generated_policy_trusted_path_lifecycle(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    trusted_dir = workspace / "src"
    trusted_dir.mkdir(parents=True, exist_ok=True)

    resolved, added = policy.add_trusted_path("src", workspace=workspace)
    listed = policy.list_trusted_paths(workspace=workspace)
    removed = policy.remove_trusted_path("1", workspace=workspace)
    listed_after = policy.list_trusted_paths(workspace=workspace)

    assert added is True
    assert resolved == trusted_dir.resolve()
    assert trusted_dir.resolve() in listed
    assert removed == trusted_dir.resolve()
    assert listed_after == []


def test_agent_always_answer_persists_generated_policy(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    monkeypatch.chdir(workspace)
    reset_permissions()
    agent_mod._permission_context_set({"role": "coordinator", "project_root": str(workspace)})
    set_permission_mode("ask")
    monkeypatch.setattr("msapling_cli.agent.render_approval_prompt", lambda *_args, **_kwargs: "always")

    result = _check_approval("run_command", {"command": "pytest -q"})
    generated = policy.generated_policy_path(workspace)
    payload = generated.read_text(encoding="utf-8")

    assert result is None
    assert generated.exists()
    assert "approval:default:run_command:pytest--q" in payload


def test_trusted_folder_gate_blocks_untrusted_writes_and_network(monkeypatch, tmp_path):
    _, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    (workspace / "trusted").mkdir(parents=True, exist_ok=True)
    policy.add_trusted_path("trusted", workspace=workspace)
    monkeypatch.chdir(workspace)
    reset_permissions()
    agent_mod._permission_context_set({"role": "coordinator", "project_root": str(workspace)})
    set_permission_mode("auto")

    allowed = _check_approval("write_file", {"path": "trusted/new.py", "content": "x = 1\n"})
    blocked = _check_approval("write_file", {"path": "other/new.py", "content": "x = 1\n"})
    blocked_net = _check_approval("run_command", {"command": "curl https://example.com"})

    assert allowed is None
    assert blocked is not None
    assert "outside trusted folders" in blocked
    assert blocked_net is not None
    assert "network fetch commands" in blocked_net or "deny run_command" in blocked_net


def test_persist_permanent_approval_supports_user_scope(monkeypatch, tmp_path):
    home, workspace = _isolate_policy_paths(monkeypatch, tmp_path)

    path = policy.persist_permanent_approval(
        "run_command",
        {"command": "pytest -q"},
        mode="ask",
        workspace=workspace,
        scope="user",
    )

    expected = home / ".msapling" / "policies" / "generated.rules.json"
    assert path == expected
    assert expected.exists()
    assert "approval:default:run_command:pytest--q" in expected.read_text(encoding="utf-8")


def test_policy_log_command_reads_permission_decisions(monkeypatch, tmp_path):
    home, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    logs_dir = home / ".msapling" / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_file = logs_dir / "cli.jsonl"
    log_file.write_text(
        "\n".join(
            [
                json.dumps({"ts": "2026-04-24T10:00:00", "event": "OTHER_EVENT", "data": {}}),
                json.dumps(
                    {
                        "ts": "2026-04-24T10:00:01",
                        "event": "PERMISSION_DECISION",
                        "session": "abc123",
                        "data": {
                            "decision": "deny",
                            "tool": "run_command",
                            "mode": "ask",
                            "source": "policy",
                            "reason": "Blocked by policy",
                            "permission_role": "worker",
                            "permission_name": "worker-1",
                            "correlation_id": "corr-1",
                        },
                    }
                ),
            ]
        ),
        encoding="utf-8",
    )

    text_result = runner.invoke(main.app, ["policy", "log", "--limit", "5"])
    json_result = runner.invoke(main.app, ["policy", "log", "--output", "json", "--decision", "deny"])

    assert text_result.exit_code == 0
    assert "Permission Decisions" in text_result.stdout
    assert "run_command" in text_result.stdout
    assert json_result.exit_code == 0
    assert '"tool": "run_command"' in json_result.stdout


def test_policy_file_world_writable_is_skipped(tmp_path, monkeypatch):
    import sys
    if sys.platform == "win32":
        import pytest
        pytest.skip("st_mode world-writable check is POSIX-only in current implementation")
    
    home, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    policy_file = workspace / ".msapling" / "policies" / "insecure.toml"
    policy_file.write_text("[[rule]]\\ntoolName = 'run_command'\\ndecision = 'deny'\\n", encoding="utf-8")
    
    # Make it world-writable
    policy_file.chmod(0o666)
    
    rules = policy.load_policy_rules(workspace=workspace)
    # The insecure rule should NOT be in the rules list.
    assert not any(r.tool_name == "run_command" for r in rules)


def test_permission_context_propagation_in_multi_and_swarm(monkeypatch, tmp_path):
    from msapling_cli.shell import InteractiveShell
    from unittest.mock import AsyncMock, MagicMock
    
    home, workspace = _isolate_policy_paths(monkeypatch, tmp_path)
    monkeypatch.chdir(workspace)
    
    shell = InteractiveShell(project=str(workspace))
    shell.user = {"email": "test@example.com", "tier": "pro"}
    shell.client = MagicMock()
    shell.client.multi_chat = AsyncMock(return_value=[])
    shell.client.swarm = AsyncMock(return_value={})
    
    # Run /multi
    import asyncio
    asyncio.run(shell._handle_slash("/multi test prompt"))
    
    # Verify multi_chat was called with permission_context
    args, kwargs = shell.client.multi_chat.call_args
    assert "permission_context" in kwargs
    assert kwargs["permission_context"]["role"] == "coordinator"
    assert "correlation_id" in kwargs["permission_context"]
    
    # Run /swarm
    asyncio.run(shell._handle_slash("/swarm test prompt"))
    
    # Verify swarm was called with permission_context
    args, kwargs = shell.client.swarm.call_args
    assert "permission_context" in kwargs
    assert kwargs["permission_context"]["role"] == "coordinator"
    assert "correlation_id" in kwargs["permission_context"]
