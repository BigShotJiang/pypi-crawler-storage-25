"""Robust tests for CLI configuration: Settings, token management, chmod handling."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

from msapling_cli.config import (
    Settings,
    clear_token,
    get_settings,
    get_token,
    save_settings,
    save_token,
)


# ---- Settings defaults ----


def test_settings_defaults_all_fields():
    """Settings() without arguments uses documented defaults."""
    s = Settings()
    assert s.api_url == "https://api.msapling.com"
    assert s.default_model == "google/gemini-2.0-flash-001"
    assert s.max_tokens == 4096
    assert s.temperature == 0.7
    assert s.theme == "diamond"


def test_settings_env_prefix_api_url():
    """MSAPLING_API_URL env var overrides default api_url."""
    with patch.dict(os.environ, {"MSAPLING_API_URL": "http://localhost:9999"}):
        s = Settings()
        assert s.api_url == "http://localhost:9999"


def test_settings_env_prefix_default_model():
    """MSAPLING_DEFAULT_MODEL env var overrides default_model."""
    with patch.dict(os.environ, {"MSAPLING_DEFAULT_MODEL": "openai/gpt-4o"}):
        s = Settings()
        assert s.default_model == "openai/gpt-4o"


def test_settings_env_prefix_max_tokens():
    """MSAPLING_MAX_TOKENS env var overrides max_tokens as int."""
    with patch.dict(os.environ, {"MSAPLING_MAX_TOKENS": "8192"}):
        s = Settings()
        assert s.max_tokens == 8192


def test_settings_env_prefix_temperature():
    """MSAPLING_TEMPERATURE env var overrides temperature as float."""
    with patch.dict(os.environ, {"MSAPLING_TEMPERATURE": "0.3"}):
        s = Settings()
        assert s.temperature == 0.3


def test_settings_env_prefix_theme():
    """MSAPLING_THEME env var overrides theme."""
    with patch.dict(os.environ, {"MSAPLING_THEME": "light"}):
        s = Settings()
        assert s.theme == "light"


# ---- save_settings / get_settings round-trip ----


def test_save_and_load_roundtrip(tmp_path):
    """Settings saved with save_settings can be loaded with get_settings."""
    config_file = tmp_path / "config.json"
    with patch("msapling_cli.config._CONFIG_FILE", config_file), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path):
        original = Settings(api_url="http://test:8000", default_model="test/model", max_tokens=2048)
        save_settings(original)
        assert config_file.exists()
        loaded = get_settings()
        assert loaded.api_url == "http://test:8000"
        assert loaded.default_model == "test/model"
        assert loaded.max_tokens == 2048


def test_get_settings_returns_defaults_if_config_missing():
    """get_settings returns default Settings when config file does not exist."""
    with patch("msapling_cli.config._CONFIG_FILE", Path("/nonexistent/config.json")):
        s = get_settings()
        assert s.api_url == "https://api.msapling.com"


def test_get_settings_returns_defaults_on_corrupt_json(tmp_path):
    """get_settings returns defaults if config file contains invalid JSON."""
    config_file = tmp_path / "config.json"
    config_file.write_text("{invalid json!!!", encoding="utf-8")
    with patch("msapling_cli.config._CONFIG_FILE", config_file):
        s = get_settings()
        assert s.api_url == "https://api.msapling.com"


def test_save_settings_creates_parent_dir(tmp_path):
    """save_settings creates the .msapling directory if it does not exist."""
    nested = tmp_path / "sub" / "dir"
    config_file = nested / "config.json"
    with patch("msapling_cli.config._CONFIG_FILE", config_file), \
         patch("msapling_cli.config._CONFIG_DIR", nested):
        save_settings(Settings())
        assert config_file.exists()


# ---- Token management ----


def test_save_token_and_get_token(tmp_path):
    """save_token writes encrypted token that get_token can read back."""
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", tmp_path / "token.enc"), \
         patch("msapling_cli.config._KEYFILE", tmp_path / ".keyfile"), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
        save_token("jwt-abc-123")
        assert get_token() == "jwt-abc-123"


def test_get_token_strips_whitespace(tmp_path):
    """get_token strips trailing newlines/spaces from token file (via legacy migration)."""
    token_file = tmp_path / "token"
    token_file.write_text("  my-token  \n\n")
    with patch("msapling_cli.config._TOKEN_FILE", token_file), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", tmp_path / "token.enc"), \
         patch("msapling_cli.config._KEYFILE", tmp_path / ".keyfile"), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
        # Legacy plaintext file is auto-migrated and its content stripped.
        assert get_token() == "my-token"


def test_get_token_falls_back_to_env_var():
    """get_token uses MSAPLING_TOKEN env var when no token file."""
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent/token")), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": "env-tok-42"}):
        assert get_token() == "env-tok-42"


def test_get_token_returns_none_when_nothing_available():
    """get_token returns None when no token file and no env var."""
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent/token")), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", Path("/nonexistent/token.enc")), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None):
        env = os.environ.copy()
        env.pop("MSAPLING_TOKEN", None)
        with patch.dict(os.environ, env, clear=True):
            assert get_token() is None


def test_clear_token_removes_file(tmp_path):
    """clear_token deletes the encrypted token file."""
    enc_file = tmp_path / "token.enc"
    enc_file.write_bytes(b"fake-encrypted-data")
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None):
        clear_token()
        assert not enc_file.exists()


def test_clear_token_noop_if_no_file():
    """clear_token does not raise if no token files exist."""
    with patch("msapling_cli.config._TOKEN_FILE", Path("/nonexistent/token")), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", Path("/nonexistent/token.enc")), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None):
        clear_token()  # Should not raise


# ---- chmod / Windows handling ----


def test_save_token_chmod_oserror_handled(tmp_path):
    """save_token gracefully handles OSError from os.open on Windows enc file path."""
    enc_file = tmp_path / "token.enc"
    keyfile = tmp_path / ".keyfile"
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
         patch("msapling_cli.config._KEYFILE", keyfile), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
        save_token("my-secret-token")
        # Token must be stored in encrypted form — enc file must exist.
        assert enc_file.exists()
        # Round-trip verify
        assert get_token() == "my-secret-token"


def test_save_token_windows_icacls_called(tmp_path, monkeypatch):
    """On Windows, _save_to_enc_file falls back to icacls when os.open raises OSError."""
    enc_file = tmp_path / "token.enc"
    keyfile = tmp_path / ".keyfile"
    monkeypatch.setattr("msapling_cli.config._TOKEN_FILE", tmp_path / "token")
    monkeypatch.setattr("msapling_cli.config._TOKEN_ENC_FILE", enc_file)
    monkeypatch.setattr("msapling_cli.config._KEYFILE", keyfile)
    monkeypatch.setattr("msapling_cli.config._CONFIG_DIR", tmp_path)
    monkeypatch.setattr("msapling_cli.config._get_keyring_backend", lambda: None)
    monkeypatch.setattr("msapling_cli.config.sys.platform", "win32")
    monkeypatch.setenv("USERNAME", "TestUser")

    def os_open_fail(*args, **kwargs):
        raise OSError("not supported")

    mock_sp = MagicMock()
    monkeypatch.setattr("msapling_cli.config.os.open", os_open_fail)
    with patch("msapling_cli.config._sp", mock_sp, create=True):
        save_token("test-token")

    # Enc file must be written even when os.open fails (write_bytes fallback).
    assert enc_file.exists()
    # icacls must be called at least once (for the enc file)
    mock_sp.run.assert_called()
    all_run_args = [str(c) for c in mock_sp.run.call_args_list]
    assert any("token.enc" in a for a in all_run_args), \
        "icacls must be invoked for the encrypted token file"


def test_save_token_windows_no_username_skips_icacls(tmp_path, monkeypatch):
    """On Windows with empty USERNAME, icacls is not called for enc file."""
    enc_file = tmp_path / "token.enc"
    keyfile = tmp_path / ".keyfile"
    monkeypatch.setattr("msapling_cli.config._TOKEN_FILE", tmp_path / "token")
    monkeypatch.setattr("msapling_cli.config._TOKEN_ENC_FILE", enc_file)
    monkeypatch.setattr("msapling_cli.config._KEYFILE", keyfile)
    monkeypatch.setattr("msapling_cli.config._CONFIG_DIR", tmp_path)
    monkeypatch.setattr("msapling_cli.config._get_keyring_backend", lambda: None)

    def os_open_fail(*args, **kwargs):
        raise OSError("not supported")

    monkeypatch.setattr("msapling_cli.config.os.open", os_open_fail)
    monkeypatch.setattr("msapling_cli.config.sys.platform", "win32")
    monkeypatch.delenv("USERNAME", raising=False)
    monkeypatch.delenv("USER", raising=False)
    mock_sp = MagicMock()
    with patch("msapling_cli.config._sp", mock_sp):
        save_token("test-token")
    assert enc_file.exists()
    # No icacls should be called when USERNAME is empty
    icacls_calls = [c for c in mock_sp.run.call_args_list if "icacls" in str(c)]
    assert not icacls_calls, "icacls must not be called when USERNAME is empty"


# ---- Edge cases ----


def test_settings_model_dump_is_json_serializable():
    """Settings.model_dump() produces a JSON-serializable dict."""
    s = Settings()
    dumped = s.model_dump()
    # Should not raise
    json.dumps(dumped)
    assert "api_url" in dumped
    assert "default_model" in dumped


def test_save_token_overwrites_existing(tmp_path):
    """save_token overwrites a previous encrypted token."""
    with patch("msapling_cli.config._TOKEN_FILE", tmp_path / "token"), \
         patch("msapling_cli.config._TOKEN_ENC_FILE", tmp_path / "token.enc"), \
         patch("msapling_cli.config._KEYFILE", tmp_path / ".keyfile"), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path), \
         patch("msapling_cli.config._get_keyring_backend", return_value=None), \
         patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
        save_token("first-token")
        save_token("second-token")
        assert get_token() == "second-token"


def test_save_settings_overwrites_existing(tmp_path):
    """save_settings overwrites previous config."""
    config_file = tmp_path / "config.json"
    with patch("msapling_cli.config._CONFIG_FILE", config_file), \
         patch("msapling_cli.config._CONFIG_DIR", tmp_path):
        save_settings(Settings(theme="dark"))
        save_settings(Settings(theme="light"))
        loaded = get_settings()
        assert loaded.theme == "light"


class _FakeKeyring:
    def __init__(self):
        self.store = {}

    def get_password(self, service, username):
        return self.store.get((service, username))

    def set_password(self, service, username, password):
        self.store[(service, username)] = password

    def delete_password(self, service, username):
        self.store.pop((service, username), None)


def test_save_token_uses_keyring_when_available(tmp_path):
    fake = _FakeKeyring()
    token_file = tmp_path / 'token'
    with patch('msapling_cli.config._CONFIG_DIR', tmp_path), \
         patch('msapling_cli.config._TOKEN_FILE', token_file), \
         patch('msapling_cli.config._TOKEN_ENC_FILE', tmp_path / 'token.enc'), \
         patch('msapling_cli.config._KEYFILE', tmp_path / '.keyfile'), \
         patch('msapling_cli.config._get_keyring_backend', return_value=fake):
        save_token('secret-token')
        assert token_file.exists() is False
        assert get_token() == 'secret-token'


def test_clear_token_removes_keyring_value(tmp_path):
    fake = _FakeKeyring()
    token_file = tmp_path / 'token'
    with patch('msapling_cli.config._CONFIG_DIR', tmp_path), \
         patch('msapling_cli.config._TOKEN_FILE', token_file), \
         patch('msapling_cli.config._TOKEN_ENC_FILE', tmp_path / 'token.enc'), \
         patch('msapling_cli.config._KEYFILE', tmp_path / '.keyfile'), \
         patch('msapling_cli.config._get_keyring_backend', return_value=fake):
        save_token('secret-token')
        clear_token()
        assert get_token() is None


def test_get_token_prefers_file_over_keyring(tmp_path):
    """Plaintext legacy token file is migrated and returned even when keyring has a value."""
    fake = _FakeKeyring()
    fake.set_password('msapling-cli', 'auth_token', 'stale-keyring-token')
    token_file = tmp_path / 'token'
    token_file.write_text('fresh-file-token', encoding='utf-8')
    with patch('msapling_cli.config._TOKEN_FILE', token_file), \
         patch('msapling_cli.config._TOKEN_ENC_FILE', tmp_path / 'token.enc'), \
         patch('msapling_cli.config._KEYFILE', tmp_path / '.keyfile'), \
         patch('msapling_cli.config._CONFIG_DIR', tmp_path), \
         patch('msapling_cli.config._get_keyring_backend', return_value=fake):
        assert get_token() == 'fresh-file-token'


def test_get_token_prefers_env_over_file_and_keyring(tmp_path):
    """MSAPLING_TOKEN env var wins over plaintext legacy file and keyring."""
    fake = _FakeKeyring()
    fake.set_password('msapling-cli', 'auth_token', 'stale-keyring-token')
    token_file = tmp_path / 'token'
    token_file.write_text('fresh-file-token', encoding='utf-8')
    with patch('msapling_cli.config._TOKEN_FILE', token_file), \
         patch('msapling_cli.config._TOKEN_ENC_FILE', tmp_path / 'token.enc'), \
         patch('msapling_cli.config._KEYFILE', tmp_path / '.keyfile'), \
         patch('msapling_cli.config._CONFIG_DIR', tmp_path), \
         patch('msapling_cli.config._get_keyring_backend', return_value=fake), \
         patch.dict(os.environ, {'MSAPLING_TOKEN': 'env-token'}):
        assert get_token() == 'env-token'
