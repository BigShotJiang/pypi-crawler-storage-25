"""Guardrail tests for `msapling doctor` exhaustive health-check command.

These tests verify structural invariants — that the command and all required
check functions exist and are callable.  They do NOT make real network calls.
"""
from __future__ import annotations

import asyncio
import inspect
import unittest.mock as mock

import pytest


# ---------------------------------------------------------------------------
# 1. Command is registered in the CLI app
# ---------------------------------------------------------------------------

def test_doctor_command_registered():
    """The 'doctor' command must be registered in the typer app."""
    from msapling_cli import main
    command_names = [cmd.name or cmd.callback.__name__ for cmd in main.app.registered_commands]
    assert "doctor" in command_names, (
        f"'doctor' not found in registered commands: {command_names}"
    )


# ---------------------------------------------------------------------------
# 2. doctor module is importable and exposes required symbols
# ---------------------------------------------------------------------------

def test_doctor_module_importable():
    """msapling_cli.doctor must be importable without error."""
    import msapling_cli.doctor as _doctor  # noqa: F401


def test_check_api_ping_exists():
    """check_api_ping must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_api_ping"), "check_api_ping not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_api_ping), "check_api_ping must be async"


def test_check_auth_token_exists():
    """check_auth_token must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_auth_token"), "check_auth_token not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_auth_token), "check_auth_token must be async"


def test_check_dependencies_exists():
    """check_dependencies must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_dependencies"), "check_dependencies not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_dependencies), "check_dependencies must be async"


def test_check_state_drift_exists():
    """check_state_drift must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_state_drift"), "check_state_drift not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_state_drift), "check_state_drift must be async"


# ---------------------------------------------------------------------------
# 3. Additional check functions required by the spec
# ---------------------------------------------------------------------------

def test_check_backend_version_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "check_backend_version")
    assert asyncio.iscoroutinefunction(d.check_backend_version)


def test_check_model_list_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "check_model_list")
    assert asyncio.iscoroutinefunction(d.check_model_list)


def test_check_ws_endpoint_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "check_ws_endpoint")
    assert asyncio.iscoroutinefunction(d.check_ws_endpoint)


def test_check_cli_version_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "check_cli_version")
    assert asyncio.iscoroutinefunction(d.check_cli_version)


# ---------------------------------------------------------------------------
# 4. run_all_checks and print_report exist
# ---------------------------------------------------------------------------

def test_run_all_checks_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "run_all_checks")
    assert asyncio.iscoroutinefunction(d.run_all_checks)


def test_print_report_exists():
    from msapling_cli import doctor as d
    assert hasattr(d, "print_report")
    assert callable(d.print_report)


def test_checks_registry_has_14_items():
    from msapling_cli import doctor as d
    assert hasattr(d, "CHECKS"), "CHECKS registry not found in doctor module"
    assert len(d.CHECKS) == 16, f"Expected 16 checks, got {len(d.CHECKS)}: {d.CHECKS}"


# ---------------------------------------------------------------------------
# 5. New diagnostic check functions (6 additions → 14 total)
# ---------------------------------------------------------------------------

def test_check_auth_source_exists():
    """check_auth_source must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_auth_source"), "check_auth_source not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_auth_source), "check_auth_source must be async"


def test_check_active_project_exists():
    """check_active_project must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_active_project"), "check_active_project not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_active_project), "check_active_project must be async"


def test_check_model_source_exists():
    """check_model_source must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_model_source"), "check_model_source not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_model_source), "check_model_source must be async"


def test_check_history_source_exists():
    """check_history_source must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_history_source"), "check_history_source not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_history_source), "check_history_source must be async"


def test_check_lock_state_exists():
    """check_lock_state must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_lock_state"), "check_lock_state not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_lock_state), "check_lock_state must be async"


def test_check_worker_state_exists():
    """check_worker_state must exist in the doctor module and be async."""
    from msapling_cli import doctor as d
    assert hasattr(d, "check_worker_state"), "check_worker_state not found in doctor module"
    assert asyncio.iscoroutinefunction(d.check_worker_state), "check_worker_state must be async"


# ---------------------------------------------------------------------------
# 6. Functional: check functions return (status, detail) tuples
# ---------------------------------------------------------------------------

def test_check_auth_token_no_token(monkeypatch):
    """check_auth_token returns ('warn', ...) when no token is present."""
    from msapling_cli import doctor as d
    monkeypatch.setattr("msapling_cli.config.get_token", lambda: None)
    status, detail = asyncio.run(d.check_auth_token())
    assert status == "warn"
    assert "no token" in detail.lower() or "login" in detail.lower()


def test_check_dependencies_returns_ok():
    """check_dependencies returns ('ok', ...) when httpx and rich are installed."""
    from msapling_cli import doctor as d
    status, detail = asyncio.run(d.check_dependencies())
    # httpx and rich are required by the CLI so they should always be present
    assert status in ("ok", "warn"), f"Unexpected status: {status}"
    assert "httpx" in detail


def test_check_api_ping_on_failure(monkeypatch):
    """check_api_ping returns ('fail', ...) when the server is unreachable."""
    import httpx
    from msapling_cli import doctor as d

    async def _mock_get(*args, **kwargs):
        raise httpx.ConnectError("connection refused")

    with mock.patch("httpx.AsyncClient.get", side_effect=httpx.ConnectError("refused")):
        status, detail = asyncio.run(d.check_api_ping("http://localhost:1"))
    assert status == "fail"


def test_check_state_drift_server_unreachable(monkeypatch, tmp_path):
    """check_state_drift returns ('warn', ...) when the server is unreachable."""
    import httpx
    from msapling_cli import doctor as d

    # Patch home dir to a tmp dir with no local projects
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    with mock.patch("httpx.AsyncClient.get", side_effect=httpx.ConnectError("refused")):
        status, detail = asyncio.run(d.check_state_drift("http://localhost:1", None))
    assert status == "warn"
    assert "server unreachable" in detail or "unreachable" in detail


# ---------------------------------------------------------------------------
# 6. Exhaustive flag wires through to doctor module in CLI
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 7. Behavioral: new extended checks
# ---------------------------------------------------------------------------

def test_check_auth_source_no_token(monkeypatch):
    """check_auth_source returns ('warn', ...) when no token exists in any source."""
    from msapling_cli import doctor as d
    monkeypatch.setattr(
        "msapling_cli.config.inspect_token_sources",
        lambda: {"env": None, "file": None, "keyring": None},
    )
    status, detail = asyncio.run(d.check_auth_source())
    assert status == "warn"
    assert "no token" in detail.lower() or "login" in detail.lower()


def test_check_auth_source_env_active(monkeypatch):
    """check_auth_source returns ('ok', ...) mentioning env var when only env token exists."""
    from msapling_cli import doctor as d
    monkeypatch.setattr(
        "msapling_cli.config.inspect_token_sources",
        lambda: {"env": "tok_env_abc", "file": None, "keyring": None},
    )
    status, detail = asyncio.run(d.check_auth_source())
    assert status == "ok"
    assert "env" in detail.lower()


def test_check_auth_source_conflict_detected(monkeypatch):
    """check_auth_source returns ('warn', ...) when env and keyring tokens differ."""
    from msapling_cli import doctor as d
    monkeypatch.setattr(
        "msapling_cli.config.inspect_token_sources",
        lambda: {"env": "tok_a", "file": None, "keyring": "tok_b"},
    )
    status, detail = asyncio.run(d.check_auth_source())
    assert status == "warn"
    assert "conflict" in detail.lower()


def test_check_active_project_no_config(monkeypatch, tmp_path):
    """check_active_project returns ('warn', ...) when no config file exists."""
    from msapling_cli import doctor as d
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    status, detail = asyncio.run(d.check_active_project())
    assert status == "warn"
    assert "config" in detail.lower() or "no" in detail.lower()


def test_check_active_project_with_project(monkeypatch, tmp_path):
    """check_active_project returns ('ok', ...) with project name when config has it."""
    import json
    from msapling_cli import doctor as d
    msapling_dir = tmp_path / ".msapling"
    msapling_dir.mkdir()
    (msapling_dir / "config.json").write_text(
        json.dumps({"active_project": "My Test Project", "active_chat_id": "chat-xyz"}),
        encoding="utf-8",
    )
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    status, detail = asyncio.run(d.check_active_project())
    assert status == "ok"
    assert "My Test Project" in detail


def test_check_model_source_env(monkeypatch):
    """check_model_source returns ('ok', ...) mentioning env var when MSAPLING_MODEL is set."""
    import os
    from msapling_cli import doctor as d
    monkeypatch.setenv("MSAPLING_MODEL", "anthropic/claude-3-opus")
    status, detail = asyncio.run(d.check_model_source())
    assert status == "ok"
    assert "MSAPLING_MODEL" in detail or "env" in detail.lower()


def test_check_history_source_no_sessions(monkeypatch, tmp_path):
    """check_history_source returns ('ok', 'server only ...') when sessions dir is empty."""
    from msapling_cli import doctor as d
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    status, detail = asyncio.run(d.check_history_source())
    assert status == "ok"
    assert "server" in detail.lower()


def test_check_history_source_with_local_cache(monkeypatch, tmp_path):
    """check_history_source returns session count when local cache exists."""
    from msapling_cli import doctor as d
    sessions_dir = tmp_path / ".msapling" / "sessions"
    sessions_dir.mkdir(parents=True)
    for i in range(3):
        (sessions_dir / f"session_{i}.json").write_text("{}", encoding="utf-8")
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    status, detail = asyncio.run(d.check_history_source())
    assert status == "ok"
    assert "3" in detail


def test_check_lock_state_server_unreachable():
    """check_lock_state returns ('warn', ...) when server is unreachable."""
    import httpx
    from msapling_cli import doctor as d
    with mock.patch("httpx.AsyncClient.get", side_effect=httpx.ConnectError("refused")):
        status, detail = asyncio.run(d.check_lock_state("http://localhost:1", None))
    assert status == "warn"
    assert "unreachable" in detail.lower()


def test_check_worker_state_server_unreachable():
    """check_worker_state returns ('warn', ...) when server is unreachable."""
    import httpx
    from msapling_cli import doctor as d
    with mock.patch("httpx.AsyncClient.get", side_effect=httpx.ConnectError("refused")):
        status, detail = asyncio.run(d.check_worker_state("http://localhost:1", None))
    assert status == "warn"
    assert "unreachable" in detail.lower()


def test_run_all_checks_returns_14_results():
    """run_all_checks must return exactly 14 (name, status, detail) tuples."""
    from msapling_cli import doctor as d
    import httpx

    with mock.patch("httpx.AsyncClient.get", side_effect=httpx.ConnectError("refused")), \
         mock.patch("msapling_cli.config.get_token", return_value=None), \
         mock.patch("msapling_cli.config.inspect_token_sources",
                    return_value={"env": None, "file": None, "keyring": None}):
        results = asyncio.run(d.run_all_checks("http://localhost:1", None))

    assert len(results) == 16, f"Expected 16 results, got {len(results)}"
    for name, status, detail in results:
        assert isinstance(name, str) and name
        assert status in ("ok", "warn", "fail"), f"Invalid status '{status}' for check '{name}'"
        assert isinstance(detail, str)


# ---------------------------------------------------------------------------
# 8. Exhaustive flag wires through to doctor module in CLI
# ---------------------------------------------------------------------------

def test_doctor_exhaustive_flag_calls_run_all_checks(monkeypatch):
    """--exhaustive flag must invoke run_all_checks from the doctor module."""
    from typer.testing import CliRunner
    from msapling_cli import main

    called = []

    async def _fake_run_all(api_url, token):
        called.append((api_url, token))
        return [
            ("API connectivity", "ok", "5ms"),
            ("Authentication", "warn", "no token"),
            ("Backend version", "ok", "v7.7.0"),
            ("Model availability", "ok", "100 models"),
            ("Redis/WebSocket", "ok", "connected"),
            ("CLI version", "ok", "0.1.9 (up to date)"),
            ("Dependency versions", "ok", "httpx=0.27, rich=13.7"),
            ("Local state drift", "warn", "server:5, local:5 (in sync)"),
        ]

    monkeypatch.setattr("msapling_cli.doctor.run_all_checks", _fake_run_all)
    monkeypatch.setattr(main, "get_token", lambda: None)
    monkeypatch.setattr(main, "get_token_source", lambda: None)
    monkeypatch.setattr(main, "inspect_token_sources", lambda: {"env": None, "file": None, "keyring": None})
    monkeypatch.setattr(main, "get_settings", lambda: main.Settings(
        api_url="https://api.msapling.com",
        default_model="google/gemini-2.0-flash-001",
    ))

    runner = CliRunner()
    result = runner.invoke(main.app, ["doctor", "--exhaustive"])
    assert result.exit_code == 0, f"exit_code={result.exit_code}, output={result.output}"
    assert len(called) == 1, "run_all_checks should have been called once"
