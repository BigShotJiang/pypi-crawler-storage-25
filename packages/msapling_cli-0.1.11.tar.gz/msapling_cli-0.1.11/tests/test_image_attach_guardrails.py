"""Guardrail tests for clipboard image support and file attachment features.

Tests:
1. /paste-image command is registered in shell dispatch
2. /attach command is registered in shell dispatch
3. Clipboard read failure shows helpful message (not traceback)
4. Missing Pillow shows install hint
5. /attach with non-existent path suggests fuzzy alternatives
6. /attach list shows pending count
7. /attach clear empties list
8. Image encoded to base64 (not raw bytes)
9. Text files attached as context (not image)
10. Vision preview prints dimensions at minimum
"""
from __future__ import annotations

import asyncio
import base64
import io
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from msapling_cli.shell import (
    InteractiveShell,
    _fuzzy_suggest_paths,
    _vision_preview,
    _IMAGE_EXTS,
    _TEXT_EXTS,
)


# ─── Fixtures ────────────────────────────────────────────────────────


def _make_shell(tmp_path: Path) -> InteractiveShell:
    """Create a minimal InteractiveShell for testing."""
    with patch("msapling_cli.shell.MSaplingClient", return_value=AsyncMock()):
        shell = InteractiveShell()
    shell.project_root = str(tmp_path)
    shell.messages = []
    shell.pending_attachments = []
    shell.hooks = {}
    shell.user = {"tier": "free", "fuel_credits": 1.0, "is_pro": False}
    shell.client = AsyncMock()
    return shell


def _run(coro):
    return asyncio.run(coro)


# ─── Test 1: /paste-image registered ─────────────────────────────────


def test_paste_image_command_registered(tmp_path):
    """/paste-image must be handled by _handle_slash (not fall through to chat)."""
    shell = _make_shell(tmp_path)

    with (
        patch("msapling_cli.shell._grab_clipboard_image", return_value=None),
        patch("msapling_cli.shell.console.print") as mock_print,
    ):
        result = _run(shell._handle_slash("/paste-image"))

    # Command must return True (handled), not None/False
    assert result is True, "/paste-image must be handled and return True"
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    # Should show "no image" message, not a "unknown command" fallback
    assert "No image" in printed or "clipboard" in printed.lower()


# ─── Test 2: /attach registered ──────────────────────────────────────


def test_attach_command_registered(tmp_path):
    """/attach must be handled by _handle_slash."""
    shell = _make_shell(tmp_path)

    with patch("msapling_cli.shell.console.print") as mock_print:
        result = _run(shell._handle_slash("/attach"))

    assert result is True, "/attach must be handled and return True"
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    assert "Usage" in printed or "attach" in printed.lower()


# ─── Test 3: Clipboard failure shows helpful message ─────────────────


def test_clipboard_failure_shows_helpful_message(tmp_path):
    """Clipboard errors must produce a friendly message, not raise."""
    shell = _make_shell(tmp_path)

    with (
        patch(
            "msapling_cli.shell._grab_clipboard_image",
            side_effect=RuntimeError("xclip not found"),
        ),
        patch("msapling_cli.shell.console.print") as mock_print,
    ):
        result = _run(shell._handle_slash("/paste-image"))

    assert result is True
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    # Must show error message, must NOT propagate exception
    assert "error" in printed.lower() or "clipboard" in printed.lower()


# ─── Test 4: Missing Pillow shows install hint ────────────────────────


def test_missing_pillow_shows_install_hint(tmp_path):
    """When Pillow is not installed, /paste-image must hint at pip install."""
    shell = _make_shell(tmp_path)

    with (
        patch(
            "msapling_cli.shell._grab_clipboard_image",
            side_effect=ImportError("No module named 'PIL'"),
        ),
        patch("msapling_cli.shell.console.print") as mock_print,
    ):
        result = _run(shell._handle_slash("/paste-image"))

    assert result is True
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    assert "Pillow" in printed or "pip install" in printed.lower()


# ─── Test 5: /attach non-existent path suggests fuzzy alternatives ────


def test_attach_nonexistent_path_suggests_alternatives(tmp_path):
    """If path is not found, fuzzy alternatives from project root are shown."""
    # Create a real file with a similar name
    (tmp_path / "README.md").write_text("# README")
    (tmp_path / "requirements.txt").write_text("requests")

    shell = _make_shell(tmp_path)

    with patch("msapling_cli.shell.console.print") as mock_print:
        result = _run(shell._handle_slash("/attach REDME.md"))  # typo

    assert result is True
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    # Must say file not found
    assert "not found" in printed.lower() or "File not found" in printed


def test_fuzzy_suggest_paths_returns_close_match(tmp_path):
    """_fuzzy_suggest_paths must return similar filenames."""
    (tmp_path / "README.md").write_text("hi")
    (tmp_path / "requirements.txt").write_text("requests")
    results = _fuzzy_suggest_paths(str(tmp_path), "REDME.md")
    # README.md should be among suggestions
    assert any("README" in r for r in results)


def test_fuzzy_suggest_paths_no_match_returns_empty(tmp_path):
    """When nothing is close, returns empty list (no crash)."""
    (tmp_path / "main.py").write_text("pass")
    results = _fuzzy_suggest_paths(str(tmp_path), "zzz_totally_wrong.xyz")
    assert isinstance(results, list)


# ─── Test 6: /attach list shows pending count ─────────────────────────


def test_attach_list_shows_pending_count(tmp_path):
    """/attach list prints count and names of pending attachments."""
    shell = _make_shell(tmp_path)
    shell.pending_attachments = [
        {"name": "file1.txt", "content": "hello"},
        {"name": "image.png", "content": "data:image/png;base64,abc"},
    ]

    with patch("msapling_cli.shell.console.print") as mock_print:
        result = _run(shell._handle_slash("/attach list"))

    assert result is True
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    assert "2" in printed or "file1.txt" in printed or "image.png" in printed


def test_attach_list_empty(tmp_path):
    """/attach list with no pending attachments shows empty message."""
    shell = _make_shell(tmp_path)
    shell.pending_attachments = []

    with patch("msapling_cli.shell.console.print") as mock_print:
        result = _run(shell._handle_slash("/attach list"))

    assert result is True
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    assert "No pending" in printed or "0" in printed or "no" in printed.lower()


# ─── Test 7: /attach clear empties list ──────────────────────────────


def test_attach_clear_empties_list(tmp_path):
    """/attach clear must empty pending_attachments."""
    shell = _make_shell(tmp_path)
    shell.pending_attachments = [
        {"name": "a.txt", "content": "hello"},
        {"name": "b.txt", "content": "world"},
    ]

    with patch("msapling_cli.shell.console.print"):
        result = _run(shell._handle_slash("/attach clear"))

    assert result is True
    assert shell.pending_attachments == [], "pending_attachments must be empty after /attach clear"


# ─── Test 8: Image encoded to base64 ─────────────────────────────────


def test_image_attach_encodes_to_base64(tmp_path):
    """Attaching a PNG file must produce a data URI with base64-encoded content."""
    # Create a minimal valid 1x1 PNG (89 bytes)
    png_bytes = (
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00"
        b"\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
    )
    img_path = tmp_path / "test.png"
    img_path.write_bytes(png_bytes)

    shell = _make_shell(tmp_path)

    with (
        patch("msapling_cli.shell._vision_preview"),  # Skip rendering
        patch("msapling_cli.shell.console.print"),
    ):
        result = _run(shell._handle_slash(f"/attach test.png"))

    assert result is True
    assert len(shell.pending_attachments) == 1, "One attachment expected"
    att = shell.pending_attachments[0]
    content = att["content"]
    assert content.startswith("data:image/"), f"Expected data URI, got: {content[:50]}"
    assert ";base64," in content, "Must be base64-encoded"
    # Verify the base64 portion is valid
    b64_part = content.split(";base64,", 1)[1]
    decoded = base64.b64decode(b64_part)
    assert decoded == png_bytes, "Decoded bytes must match original"


def test_clipboard_image_encodes_to_base64(tmp_path):
    """Pasted clipboard image must be stored as base64 data URI."""
    # Create a mock PIL Image
    mock_img = MagicMock()
    mock_img.size = (100, 80)

    def fake_save(buf, format):  # noqa: A002
        buf.write(b"fake_png_data")

    mock_img.save.side_effect = fake_save

    shell = _make_shell(tmp_path)

    with (
        patch("msapling_cli.shell._grab_clipboard_image", return_value=mock_img),
        patch("msapling_cli.shell._vision_preview"),
        patch("msapling_cli.shell.console.print"),
    ):
        result = _run(shell._handle_slash("/paste-image"))

    assert result is True
    assert len(shell.pending_attachments) == 1
    att = shell.pending_attachments[0]
    assert att["content"].startswith("data:image/png;base64,")
    b64_part = att["content"].split(";base64,", 1)[1]
    decoded = base64.b64decode(b64_part)
    assert decoded == b"fake_png_data"


# ─── Test 9: Text files attached as context (not image) ──────────────


def test_text_file_attached_as_context(tmp_path):
    """Text/code files must be attached as plain text context, not image data URIs."""
    py_file = tmp_path / "script.py"
    py_file.write_text("print('hello world')")

    shell = _make_shell(tmp_path)

    with patch("msapling_cli.shell.console.print"):
        result = _run(shell._handle_slash("/attach script.py"))

    assert result is True
    assert len(shell.pending_attachments) == 1
    att = shell.pending_attachments[0]
    # Must be plain text, NOT a data URI
    assert not att["content"].startswith("data:image"), "Text file must not be base64 image"
    assert "print('hello world')" in att["content"]


def test_md_file_attached_as_context(tmp_path):
    """Markdown files must be attached as text context."""
    md_file = tmp_path / "notes.md"
    md_file.write_text("# Notes\nSome content here.")

    shell = _make_shell(tmp_path)

    with patch("msapling_cli.shell.console.print"):
        result = _run(shell._handle_slash("/attach notes.md"))

    assert result is True
    assert len(shell.pending_attachments) == 1
    content = shell.pending_attachments[0]["content"]
    assert "# Notes" in content
    assert not content.startswith("data:image")


# ─── Test 10: Vision preview prints dimensions at minimum ─────────────


def test_vision_preview_prints_dimensions():
    """_vision_preview must at minimum print [Image: WxHpx] when Pillow is available."""
    mock_img = MagicMock()
    mock_img.size = (320, 240)

    # Simulate PIL available but rich.image not available
    with (
        patch("msapling_cli.shell.console.print") as mock_print,
        patch.dict(sys.modules, {"rich.image": None}),
    ):
        # Inject PIL Image mock
        import msapling_cli.shell as shell_mod
        real_pil = sys.modules.get("PIL")
        try:
            mock_pil = MagicMock()
            mock_pil.Image.open.return_value = mock_img
            sys.modules["PIL"] = mock_pil
            sys.modules["PIL.Image"] = mock_pil.Image
            _vision_preview(mock_img)
        finally:
            if real_pil is not None:
                sys.modules["PIL"] = real_pil
            elif "PIL" in sys.modules:
                del sys.modules["PIL"]

    # Must have printed something containing the dimensions
    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    assert "320" in printed and "240" in printed, (
        f"Expected dimensions in output, got: {printed}"
    )


def test_vision_preview_no_pillow(tmp_path):
    """_vision_preview must not raise when PIL is not installed."""
    with (
        patch("msapling_cli.shell.console.print") as mock_print,
        patch.dict(sys.modules, {"PIL": None, "PIL.Image": None}),
    ):
        # Should not raise
        try:
            _vision_preview(Path(tmp_path / "nonexistent.png"))
        except Exception as exc:
            pytest.fail(f"_vision_preview raised unexpectedly: {exc}")

    printed = "\n".join(str(c.args[0]) for c in mock_print.call_args_list if c.args)
    # Should print some fallback message
    assert len(printed) > 0


# ─── Extra: image extension and text extension sets ────────────────────


def test_image_exts_contains_common_formats():
    assert ".png" in _IMAGE_EXTS
    assert ".jpg" in _IMAGE_EXTS
    assert ".jpeg" in _IMAGE_EXTS
    assert ".gif" in _IMAGE_EXTS
    assert ".webp" in _IMAGE_EXTS


def test_text_exts_contains_common_formats():
    assert ".py" in _TEXT_EXTS
    assert ".md" in _TEXT_EXTS
    assert ".txt" in _TEXT_EXTS
    assert ".json" in _TEXT_EXTS
