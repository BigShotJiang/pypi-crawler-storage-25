"""Guardrail tests for rich session metadata tracking.

These tests validate the SessionMetadata dataclass in session.py, the
tracking fields and helper methods added to InteractiveShell in shell.py,
and the /session-info slash command.  The suite operates in three layers:

1. **Import / construction tests** — import the real module and exercise
   SessionMetadata directly without needing a running shell or server.

2. **Source-scan tests** — read shell.py and session.py as text to assert
   that key identifiers and patterns are present.  These tests cannot fail
   due to import-side-effects and are deliberately conservative.

3. **Integration contract tests** — instantiate InteractiveShell with mocked
   dependencies and verify runtime behaviour (accumulation, dedup, etc.).

All tests are expected to PASS on the feature branch.  Any test marked
``xfail`` documents something not yet implemented and will auto-promote to
a pass once the feature lands.
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest

# ── Path constants ────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent / "msapling_cli"
_SHELL_PY = _CLI_ROOT / "shell.py"
_SESSION_PY = _CLI_ROOT / "session.py"


# ── Source text fixtures ──────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def shell_src() -> str:
    """Raw text of shell.py — loaded once for the whole test module."""
    return _SHELL_PY.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def session_src() -> str:
    """Raw text of session.py — loaded once for the whole test module."""
    return _SESSION_PY.read_text(encoding="utf-8")


# ── 1. SessionMetadata dataclass existence ────────────────────────────────────

def test_session_metadata_class_in_session_py(session_src: str):
    """session.py must define a SessionMetadata class (or dataclass)."""
    assert "class SessionMetadata" in session_src, (
        "SessionMetadata class not found in session.py"
    )


def test_session_metadata_importable():
    """SessionMetadata must be importable from msapling_cli.session without error."""
    from msapling_cli.session import SessionMetadata  # noqa: F401 — import test


# ── 2. SessionMetadata serialises to / from dict ──────────────────────────────

def test_session_metadata_to_dict_round_trip():
    """SessionMetadata.to_dict() / from_dict() must produce identical objects.

    This verifies that the dataclass can be stored as JSON (via to_dict) and
    restored (via from_dict) with no field loss or type coercion issues.
    """
    from msapling_cli.session import SessionMetadata

    original = SessionMetadata(
        session_id="abc123",
        project_name="my-project",
        models_used=["anthropic/claude-3-5-sonnet", "google/gemini-2.0-flash-001"],
        files_touched=["src/main.py", "README.md"],
        slash_commands_used=["/save", "/model"],
        total_cost_usd=0.0042,
        total_tokens_in=1500,
        total_tokens_out=800,
        started_at="2026-04-17T10:00:00+00:00",
        ended_at="2026-04-17T10:30:00+00:00",
        duration_seconds=1800.0,
        turn_count=5,
        summary="Implemented the new billing endpoint",
    )
    d = original.to_dict()
    restored = SessionMetadata.from_dict(d)

    assert restored.session_id == original.session_id
    assert restored.project_name == original.project_name
    assert restored.models_used == original.models_used
    assert restored.files_touched == original.files_touched
    assert restored.slash_commands_used == original.slash_commands_used
    assert abs(restored.total_cost_usd - original.total_cost_usd) < 1e-9
    assert restored.total_tokens_in == original.total_tokens_in
    assert restored.total_tokens_out == original.total_tokens_out
    assert restored.turn_count == original.turn_count
    assert restored.summary == original.summary
    assert restored.duration_seconds == original.duration_seconds


def test_session_metadata_json_serialisable():
    """SessionMetadata.to_dict() must produce a JSON-serialisable payload.

    This ensures the dict can be written to a .json session file without
    raising a TypeError for non-serialisable types.
    """
    from msapling_cli.session import SessionMetadata

    meta = SessionMetadata(session_id="xyz", project_name="proj")
    payload = json.dumps(meta.to_dict())
    assert "xyz" in payload


# ── 3. Backward compatibility: old session without metadata key ───────────────

def test_from_dict_empty_dict_uses_defaults():
    """SessionMetadata.from_dict({}) must succeed and return safe default values.

    Old session files that predate the metadata schema have no 'metadata' key.
    Loading them must not raise an exception and all fields must be their
    zero / empty defaults.
    """
    from msapling_cli.session import SessionMetadata

    meta = SessionMetadata.from_dict({})

    assert meta.session_id == ""
    assert meta.project_name is None
    assert meta.models_used == []
    assert meta.files_touched == []
    assert meta.slash_commands_used == []
    assert meta.total_cost_usd == 0.0
    assert meta.total_tokens_in == 0
    assert meta.total_tokens_out == 0
    assert meta.turn_count == 0
    assert meta.summary is None
    assert meta.duration_seconds is None


def test_from_dict_ignores_unknown_keys():
    """from_dict must silently ignore keys that are not SessionMetadata fields.

    This guarantees forward-compatibility: if a future version adds new keys
    they will not break older code that calls from_dict on a newer file.
    """
    from msapling_cli.session import SessionMetadata

    meta = SessionMetadata.from_dict({"session_id": "s1", "unknown_future_key": True})
    assert meta.session_id == "s1"


# ── 4. models_used deduplication ─────────────────────────────────────────────

def test_models_used_deduplication_in_shell(shell_src: str):
    """shell.py must contain _track_model with a deduplication guard."""
    import re
    # Look for the function definition and "not in self.models_used" pattern
    assert "_track_model" in shell_src, "_track_model method not found in shell.py"
    # The dedup check must be present
    assert "not in self.models_used" in shell_src, (
        "Deduplication guard 'not in self.models_used' not found in shell.py"
    )


# ── 5. _track_file helper ─────────────────────────────────────────────────────

def test_track_file_helper_exists(shell_src: str):
    """shell.py must define a _track_file method for recording touched files."""
    assert "_track_file" in shell_src, "_track_file method not found in shell.py"


def test_track_file_deduplication_in_shell(shell_src: str):
    """_track_file must contain a deduplication guard (not in self.files_touched)."""
    assert "not in self.files_touched" in shell_src, (
        "Deduplication guard not found in _track_file in shell.py"
    )


# ── 6. _track_file called on /read, /write, /edit ────────────────────────────

def test_read_command_calls_track_file(shell_src: str):
    """The /read command handler must call self._track_file after a successful read."""
    import re
    # Find the /read section and look for _track_file nearby
    read_match = re.search(r'command == "/read"(.+?)(?=elif command ==)', shell_src, re.DOTALL)
    assert read_match, "Could not locate /read handler in shell.py"
    assert "_track_file" in read_match.group(1), (
        "_track_file not called in the /read handler"
    )


def test_write_command_calls_track_file(shell_src: str):
    """The /write command handler must call self._track_file after writing."""
    import re
    write_match = re.search(r'command == "/write"(.+?)(?=elif command ==)', shell_src, re.DOTALL)
    assert write_match, "Could not locate /write handler in shell.py"
    assert "_track_file" in write_match.group(1), (
        "_track_file not called in the /write handler"
    )


def test_edit_command_calls_track_file(shell_src: str):
    """The /edit command handler must call self._track_file after a successful edit."""
    import re
    edit_match = re.search(r'command == "/edit"(.+?)(?=elif command in)', shell_src, re.DOTALL)
    assert edit_match, "Could not locate /edit handler in shell.py"
    assert "_track_file" in edit_match.group(1), (
        "_track_file not called in the /edit handler"
    )


# ── 7. slash_commands_used tracking ──────────────────────────────────────────

def test_slash_commands_used_field_in_init(shell_src: str):
    """InteractiveShell.__init__ must initialise self.slash_commands_used."""
    assert "slash_commands_used" in shell_src, (
        "slash_commands_used not found in shell.py"
    )


def test_slash_commands_tracked_in_handle_slash(shell_src: str):
    """_handle_slash must append to self.slash_commands_used."""
    import re
    # Look for the append call specifically within _handle_slash context
    assert "slash_commands_used.append" in shell_src, (
        "slash_commands_used.append not found in shell.py — slash tracking missing"
    )


# ── 8. turn_count tracking ───────────────────────────────────────────────────

def test_turn_count_field_in_init(shell_src: str):
    """InteractiveShell.__init__ must initialise self.turn_count."""
    assert "self.turn_count" in shell_src, "turn_count field not found in shell.py"


def test_turn_count_incremented_in_chat(shell_src: str):
    """_chat() must increment turn_count on every call."""
    import re
    chat_match = re.search(r'async def _chat\((.+?)(?=async def )', shell_src, re.DOTALL)
    assert chat_match, "Could not locate _chat method in shell.py"
    assert "turn_count" in chat_match.group(1), (
        "turn_count not incremented inside _chat in shell.py"
    )


# ── 9. cost accumulated in _save ─────────────────────────────────────────────

def test_save_includes_total_cost_usd(shell_src: str):
    """_save() must include total_cost_usd in the persisted metadata."""
    import re
    save_match = re.search(r'def _save\((.+?)(?=def _build_snapshot)', shell_src, re.DOTALL)
    assert save_match, "Could not locate _save method in shell.py"
    block = save_match.group(1)
    assert "total_cost_usd" in block, (
        "total_cost_usd not found in _save metadata payload"
    )


def test_save_includes_turn_count(shell_src: str):
    """_save() must persist turn_count in session metadata."""
    import re
    save_match = re.search(r'def _save\((.+?)(?=def _build_snapshot)', shell_src, re.DOTALL)
    assert save_match, "Could not locate _save method in shell.py"
    assert "turn_count" in save_match.group(1), (
        "turn_count not found in _save metadata payload"
    )


def test_save_includes_slash_commands_used(shell_src: str):
    """_save() must persist slash_commands_used in session metadata."""
    import re
    save_match = re.search(r'def _save\((.+?)(?=def _build_snapshot)', shell_src, re.DOTALL)
    assert save_match, "Could not locate _save method in shell.py"
    assert "slash_commands_used" in save_match.group(1), (
        "slash_commands_used not found in _save metadata payload"
    )


# ── 10. /session-info command ─────────────────────────────────────────────────

def test_session_info_command_in_handle_slash(shell_src: str):
    """shell.py must handle '/session-info' as a slash command."""
    assert "/session-info" in shell_src, (
        "'/session-info' command not found in shell.py"
    )


def test_session_info_shows_models_used(shell_src: str):
    """The /session-info handler must display models_used."""
    import re
    info_match = re.search(
        r'command == "/session-info"(.+?)(?=elif command ==)', shell_src, re.DOTALL
    )
    assert info_match, "Could not locate /session-info handler in shell.py"
    block = info_match.group(1)
    assert "models_used" in block, "models_used not shown in /session-info output"


def test_session_info_shows_files_touched(shell_src: str):
    """The /session-info handler must display files_touched."""
    import re
    info_match = re.search(
        r'command == "/session-info"(.+?)(?=elif command ==)', shell_src, re.DOTALL
    )
    assert info_match, "Could not locate /session-info handler in shell.py"
    assert "files_touched" in info_match.group(1) or "Files touched" in info_match.group(1), (
        "files_touched / 'Files touched' not shown in /session-info output"
    )


def test_session_info_shows_cost(shell_src: str):
    """The /session-info handler must display cost information."""
    import re
    info_match = re.search(
        r'command == "/session-info"(.+?)(?=elif command ==)', shell_src, re.DOTALL
    )
    assert info_match, "Could not locate /session-info handler in shell.py"
    block = info_match.group(1)
    assert "cost" in block.lower(), "Cost not shown in /session-info output"


def test_session_info_shows_turn_count(shell_src: str):
    """The /session-info handler must display turn_count."""
    import re
    info_match = re.search(
        r'command == "/session-info"(.+?)(?=elif command ==)', shell_src, re.DOTALL
    )
    assert info_match, "Could not locate /session-info handler in shell.py"
    block = info_match.group(1)
    assert "turn_count" in block or "Turn count" in block, (
        "turn_count not shown in /session-info output"
    )


# ── 11. /sessions listing shows metadata ─────────────────────────────────────

def test_sessions_listing_shows_project(shell_src: str):
    """The enhanced /sessions list must display the project name column."""
    import re
    sessions_match = re.search(
        r'command == "/sessions"(.+?)(?=elif command == "/session-info")', shell_src, re.DOTALL
    )
    assert sessions_match, "Could not locate /sessions handler in shell.py"
    block = sessions_match.group(1)
    assert "project" in block.lower(), "Project column not shown in /sessions listing"


def test_sessions_listing_shows_cost(shell_src: str):
    """The enhanced /sessions list must display the cost column."""
    import re
    sessions_match = re.search(
        r'command == "/sessions"(.+?)(?=elif command == "/session-info")', shell_src, re.DOTALL
    )
    assert sessions_match, "Could not locate /sessions handler in shell.py"
    block = sessions_match.group(1)
    assert "cost" in block.lower() or "Cost" in block, (
        "Cost column not shown in /sessions listing"
    )


def test_sessions_listing_shows_duration(shell_src: str):
    """The enhanced /sessions list must display the duration column."""
    import re
    sessions_match = re.search(
        r'command == "/sessions"(.+?)(?=elif command == "/session-info")', shell_src, re.DOTALL
    )
    assert sessions_match, "Could not locate /sessions handler in shell.py"
    block = sessions_match.group(1)
    assert "duration" in block.lower() or "Duration" in block, (
        "Duration column not shown in /sessions listing"
    )


# ── 12. save_session backward compat ─────────────────────────────────────────

def test_save_session_accepts_plain_dict(tmp_path: Path):
    """save_session must accept a plain dict for metadata (backward-compatible).

    Callers that pass ``metadata={"key": "value"}`` (old style) must not get
    an error — the dict is stored as-is under the ``"metadata"`` key.
    """
    from unittest.mock import patch
    from msapling_cli import session as session_mod

    fake_dir = tmp_path / "sessions"
    fake_dir.mkdir()

    with patch.object(session_mod, "_SESSION_DIR", fake_dir):
        path = session_mod.save_session(
            session_id="test-plain-dict",
            messages=[{"role": "user", "content": "hello"}],
            model="test/model",
            metadata={"project_name": "legacy-project"},
        )
        assert path.exists()
        saved = json.loads(path.read_text(encoding="utf-8"))
        assert saved["metadata"]["project_name"] == "legacy-project"


def test_save_session_accepts_session_metadata_object(tmp_path: Path):
    """save_session must accept a SessionMetadata instance directly.

    This is the preferred new calling convention — the object is serialised
    via ``to_dict()`` before being written to disk.
    """
    from unittest.mock import patch
    from msapling_cli import session as session_mod
    from msapling_cli.session import SessionMetadata

    fake_dir = tmp_path / "sessions"
    fake_dir.mkdir()

    meta = SessionMetadata(
        session_id="rich-meta",
        project_name="my-proj",
        turn_count=7,
        total_cost_usd=0.012,
    )

    with patch.object(session_mod, "_SESSION_DIR", fake_dir):
        path = session_mod.save_session(
            session_id="rich-meta",
            messages=[],
            model="test/model",
            metadata=meta,
        )
        saved = json.loads(path.read_text(encoding="utf-8"))
        assert saved["metadata"]["project_name"] == "my-proj"
        assert saved["metadata"]["turn_count"] == 7
        assert abs(saved["metadata"]["total_cost_usd"] - 0.012) < 1e-9


def test_load_session_old_format_no_metadata_key(tmp_path: Path):
    """load_session must succeed for old JSON files that have no 'metadata' key.

    This is the core backward-compatibility contract: any session file created
    before SessionMetadata was introduced must still load without error.
    """
    from unittest.mock import patch
    from msapling_cli import session as session_mod

    fake_dir = tmp_path / "sessions"
    fake_dir.mkdir()
    old_session = {
        "_schema_version": 1,
        "id": "old-session",
        "messages": [{"role": "user", "content": "hi"}],
        "model": "gpt-4",
        "project_root": "/tmp/proj",
        "cost_total": 0.001,
        "tokens_total": 500,
        "updated_at": time.time(),
        # NOTE: no "metadata" key — this is the old format
    }
    (fake_dir / "old-session.json").write_text(json.dumps(old_session), encoding="utf-8")

    with patch.object(session_mod, "_SESSION_DIR", fake_dir):
        loaded = session_mod.load_session("old-session")
        assert loaded is not None
        assert loaded["id"] == "old-session"
        # metadata key is absent — caller must handle gracefully
        # (list_sessions normalises this; load_session returns raw data)


def test_list_sessions_normalises_missing_metadata(tmp_path: Path):
    """list_sessions must ensure every returned entry has a 'metadata' dict.

    Even when the stored file has no 'metadata' key, list_sessions must inject
    an empty dict so callers can always do ``session["metadata"]["project_name"]``
    without a KeyError.
    """
    from unittest.mock import patch
    from msapling_cli import session as session_mod

    fake_dir = tmp_path / "sessions"
    fake_dir.mkdir()
    old_session = {
        "_schema_version": 1,
        "id": "no-meta",
        "messages": [],
        "model": "gpt-4",
        "updated_at": time.time(),
    }
    (fake_dir / "no-meta.json").write_text(json.dumps(old_session), encoding="utf-8")

    with patch.object(session_mod, "_SESSION_DIR", fake_dir):
        sessions = session_mod.list_sessions()
        assert sessions, "Expected at least one session"
        for s in sessions:
            assert "metadata" in s, "list_sessions failed to normalise missing metadata key"
            assert isinstance(s["metadata"], dict), "metadata must be a dict"


# ── 13. duration_seconds calculated on _save ──────────────────────────────────

def test_duration_seconds_in_session_py(session_src: str):
    """session.py must reference 'duration_seconds' as a SessionMetadata field."""
    assert "duration_seconds" in session_src, (
        "duration_seconds field not found in session.py"
    )


def test_duration_seconds_in_save_method(shell_src: str):
    """shell.py _save() must compute and store duration_seconds."""
    import re
    save_match = re.search(r'def _save\((.+?)(?=def _build_snapshot)', shell_src, re.DOTALL)
    assert save_match, "Could not locate _save method in shell.py"
    block = save_match.group(1)
    assert "duration_seconds" in block, (
        "duration_seconds not computed / stored in _save()"
    )
