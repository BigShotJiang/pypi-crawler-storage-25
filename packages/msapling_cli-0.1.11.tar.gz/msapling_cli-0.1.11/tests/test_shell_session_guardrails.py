"""Guardrail tests for shell.py BM25 session search and related features.

These tests scan shell.py and session.py source text to assert the presence
of specific functions, constants, and patterns. Tests marked xfail document
features that are *not yet implemented* — they will fail if the feature is
absent (expected) and automatically upgrade to a pass once the feature lands.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

# ──────────────────────────────────────────────────────────────────────
# Fixture: load source files once per session
# ──────────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent / "msapling_cli"
_SHELL_PY = _CLI_ROOT / "shell.py"
_SESSION_PY = _CLI_ROOT / "session.py"


@pytest.fixture(scope="module")
def shell_src() -> str:
    return _SHELL_PY.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def session_src() -> str:
    return _SESSION_PY.read_text(encoding="utf-8")


# ──────────────────────────────────────────────────────────────────────
# 1. shell.py exists
# ──────────────────────────────────────────────────────────────────────

def test_shell_py_exists():
    """shell.py must exist at the expected path."""
    assert _SHELL_PY.is_file(), f"Expected shell.py at {_SHELL_PY}"


# ──────────────────────────────────────────────────────────────────────
# 2. /sessions search command
# ──────────────────────────────────────────────────────────────────────

def test_sessions_search_command_defined(shell_src: str):
    """'/sessions search' or 'sessions_search' must appear in shell.py."""
    assert (
        "sessions search" in shell_src or "sessions_search" in shell_src
    ), "No 'sessions search' or 'sessions_search' found in shell.py"


# ──────────────────────────────────────────────────────────────────────
# 3–5. Extended session metadata fields
# ──────────────────────────────────────────────────────────────────────

def test_session_metadata_has_models_used(shell_src: str):
    """'models_used' must appear in shell.py."""
    assert "models_used" in shell_src, "'models_used' not found in shell.py"


def test_session_metadata_has_files_touched(shell_src: str):
    """'files_touched' must appear in shell.py."""
    assert "files_touched" in shell_src, "'files_touched' not found in shell.py"


def test_session_metadata_has_cost_usd(shell_src: str):
    """'cost_usd' must appear in shell.py (separate from cost_total)."""
    assert "cost_usd" in shell_src, "'cost_usd' not found in shell.py"


# ──────────────────────────────────────────────────────────────────────
# 6. _classify_complexity auto-routing
# ──────────────────────────────────────────────────────────────────────

def test_classify_complexity_function_exists(shell_src: str):
    """'_classify_complexity' function must be defined in shell.py."""
    assert "_classify_complexity" in shell_src, (
        "'_classify_complexity' not found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 7. _get_routed_model
# ──────────────────────────────────────────────────────────────────────

def test_get_routed_model_function_exists(shell_src: str):
    """'_get_routed_model' must be defined in shell.py."""
    assert "_get_routed_model" in shell_src, (
        "'_get_routed_model' not found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 8. AUTO_ROUTE_MODEL env kill-switch
# ──────────────────────────────────────────────────────────────────────

def test_auto_route_model_env_killswitch(shell_src: str):
    """'AUTO_ROUTE_MODEL' env-var kill-switch must appear in shell.py."""
    assert "AUTO_ROUTE_MODEL" in shell_src, (
        "'AUTO_ROUTE_MODEL' not found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 9. Auto-routing prints message
# ──────────────────────────────────────────────────────────────────────

def test_auto_routing_prints_message(shell_src: str):
    """'Auto-routing to' message must appear in shell.py when routing fires."""
    assert "Auto-routing to" in shell_src, (
        "'Auto-routing to' not found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 10. _write_session_state function
# ──────────────────────────────────────────────────────────────────────

def test_write_session_state_function_exists(shell_src: str):
    """'_write_session_state' must be defined in shell.py."""
    assert "_write_session_state" in shell_src, (
        "'_write_session_state' not found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 11. Session state written to ~/.msapling/sessions
#     — The path lives in session.py (imported by shell.py)
# ──────────────────────────────────────────────────────────────────────

def test_session_state_written_to_msapling_sessions(session_src: str):
    """session.py must define ~/.msapling/sessions as the storage path."""
    assert ".msapling" in session_src and "sessions" in session_src, (
        "'~/.msapling/sessions' path pattern not found in session.py"
    )
    # More precise: the _SESSION_DIR assignment must reference both parts
    assert re.search(r'\.msapling["\'/].*sessions', session_src) or (
        '".msapling"' in session_src or "'.msapling'" in session_src
    ), "Expected '.msapling/.../sessions' directory constant in session.py"


# ──────────────────────────────────────────────────────────────────────
# 12. /resume-session command
#     NOTE: The shell implements _resume_session() and /resume, not
#     /resume-session as a slash command. This test checks either form.
# ──────────────────────────────────────────────────────────────────────

def test_resume_session_command_defined(shell_src: str):
    """'_resume_session' method or 'resume-session' slash command must exist."""
    assert "_resume_session" in shell_src or "resume-session" in shell_src, (
        "No resume-session capability found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 13. 50% context usage warning
# ──────────────────────────────────────────────────────────────────────

def test_context_usage_tracker_50_percent(shell_src: str):
    """A 50% context-window *usage warning* must appear in shell.py.

    The check requires the percentage to be adjacent to context-related
    keywords so that incidental matches (e.g. /budget 0.50 help text) do
    not produce a false pass.
    """
    # Must find "50%" or "0.50" within 120 chars of a context-tracking keyword
    context_keywords = re.compile(
        r"(context|ctx|token.*limit|window.*used|usage.*warn)", re.IGNORECASE
    )
    # Slide a window: find every occurrence of 50% / 0.50 and check proximity
    for m in re.finditer(r"50%|0\.50", shell_src):
        start = max(0, m.start() - 120)
        end = min(len(shell_src), m.end() + 120)
        snippet = shell_src[start:end]
        if context_keywords.search(snippet):
            return  # found a valid context-usage reference — test passes
    raise AssertionError(
        "No 50% context-usage warning found near context/token keywords in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 14. 90% context usage threshold
# ──────────────────────────────────────────────────────────────────────

def test_context_usage_tracker_90_percent(shell_src: str):
    """A 90% context-window threshold must appear in shell.py."""
    assert "90%" in shell_src or "0.90" in shell_src or "90 %" in shell_src, (
        "No 90% context usage threshold found in shell.py"
    )


# ──────────────────────────────────────────────────────────────────────
# 15. Session auto-summary on exit
# ──────────────────────────────────────────────────────────────────────

def test_session_auto_summary_on_exit(shell_src: str):
    """An auto-summary mechanism on exit must appear in shell.py."""
    patterns = [
        "auto_summary",
        "auto-summary",
        "summarize.*exit",
        "exit.*summar",
        "on_exit.*summar",
        "summar.*session.*exit",
    ]
    found = any(
        re.search(p, shell_src, re.IGNORECASE) for p in patterns
    )
    assert found, (
        "No auto-summary-on-exit pattern found in shell.py. "
        "Expected one of: " + ", ".join(f"'{p}'" for p in patterns)
    )
