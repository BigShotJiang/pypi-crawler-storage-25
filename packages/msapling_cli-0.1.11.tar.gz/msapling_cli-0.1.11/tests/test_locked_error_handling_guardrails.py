"""Guardrail tests for enhanced 423 Locked error handling in InteractiveShell.

Verifies:
1. HTTP 423 response triggers specific lock message (not a generic error)
2. Retry countdown message includes attempt number
3. After 3 retries the /unlock + /new suggestion appears in shell source
4. /unlock command is registered in the shell
5. Lock wait time tracking (_lock_wait_start / _reset_lock_wait)
6. Ctrl+C during lock wait cancels cleanly
"""
from __future__ import annotations

import asyncio
import inspect
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helper to get the shell class
# ---------------------------------------------------------------------------

def _get_shell_cls():
    from msapling_cli import shell as shell_mod
    cls = (
        getattr(shell_mod, "InteractiveShell", None)
        or getattr(shell_mod, "MSaplingShell", None)
        or getattr(shell_mod, "Shell", None)
    )
    assert cls is not None, "Shell class not found in shell module"
    return cls


def _make_shell_instance():
    """Return a minimal shell instance without running __init__."""
    cls = _get_shell_cls()
    inst = object.__new__(cls)
    inst._lock_wait_start = None
    return inst


# ---------------------------------------------------------------------------
# 1. 423 response triggers lock-specific message (not generic error)
# ---------------------------------------------------------------------------

def test_shell_source_contains_stream_locked_message():
    """Shell source must contain the '[Stream Locked]' prefix for 423 errors."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "[Stream Locked]" in src, (
        "Shell must display '[Stream Locked]' on HTTP 423, not a generic error message"
    )


def test_stream_locked_message_mentions_another_session():
    """Lock message must explain the chat is active in another session."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "another session" in src, (
        "Lock message must tell the user the chat is active in another session"
    )


def test_stream_locked_message_mentions_ctrl_c():
    """Lock message must tell users Ctrl+C cancels the wait."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "Ctrl+C" in src or "ctrl+c" in src.lower(), (
        "Lock message must mention Ctrl+C so users know they can cancel"
    )


# ---------------------------------------------------------------------------
# 2. Retry countdown includes attempt number
# ---------------------------------------------------------------------------

def test_wait_for_lock_retry_method_exists():
    """Shell must expose _wait_for_lock_retry method."""
    cls = _get_shell_cls()
    assert hasattr(cls, "_wait_for_lock_retry"), (
        "Shell must have _wait_for_lock_retry method for countdown UI"
    )


def test_wait_for_lock_retry_is_async():
    cls = _get_shell_cls()
    assert asyncio.iscoroutinefunction(cls._wait_for_lock_retry), (
        "_wait_for_lock_retry must be an async method"
    )


@pytest.mark.asyncio
async def test_wait_for_lock_retry_shows_attempt_number(capsys):
    """_wait_for_lock_retry must show a 1-based attempt counter in the message."""
    from msapling_cli import shell as shell_mod

    printed_messages: list[str] = []

    shell = _make_shell_instance()
    # Patch console.print to capture output
    with patch.object(shell_mod.console, "print", side_effect=lambda m, **kw: printed_messages.append(str(m))):
        # Patch asyncio.sleep to be instant
        with patch("asyncio.sleep", new=AsyncMock()):
            await shell._wait_for_lock_retry(attempt=0, wait_seconds=1)

    assert any("1/3" in m or "attempt 1" in m.lower() for m in printed_messages), (
        f"Retry message must show '1/3' or 'attempt 1'. Got: {printed_messages}"
    )


@pytest.mark.asyncio
async def test_wait_for_lock_retry_second_attempt_shows_2(capsys):
    """_wait_for_lock_retry on attempt=1 must show attempt 2."""
    from msapling_cli import shell as shell_mod

    printed_messages: list[str] = []

    shell = _make_shell_instance()
    with patch.object(shell_mod.console, "print", side_effect=lambda m, **kw: printed_messages.append(str(m))):
        with patch("asyncio.sleep", new=AsyncMock()):
            await shell._wait_for_lock_retry(attempt=1, wait_seconds=1)

    assert any("2/3" in m or "attempt 2" in m.lower() for m in printed_messages), (
        f"Retry message must show '2/3' or 'attempt 2'. Got: {printed_messages}"
    )


# ---------------------------------------------------------------------------
# 3. After 3 retries, /unlock + /new suggestion appears
# ---------------------------------------------------------------------------

def test_shell_source_contains_stuck_after_retries_message():
    """Shell must print an 'appears stuck' message and suggest /unlock after exhausting retries."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "appears stuck" in src, (
        "Shell must say 'Chat appears stuck' after exhausting lock retries"
    )


def test_shell_source_suggests_slash_new_after_stuck():
    """Shell must suggest '/new' as an alternative after 3 lock retries."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "'/new'" in src or "/new" in src, (
        "Shell must suggest '/new' to start a fresh chat after repeated lock failures"
    )


def test_shell_source_suggests_unlock_after_stuck():
    """Shell must suggest '/unlock' in the stuck-chat message."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    # Count occurrences — /unlock should appear multiple times (help, handler, and stuck message)
    count = src.count("/unlock")
    assert count >= 3, (
        f"'/unlock' must appear at least 3 times in shell source; found {count}"
    )


# ---------------------------------------------------------------------------
# 4. /unlock command is registered in the shell
# ---------------------------------------------------------------------------

def test_unlock_command_registered():
    """Shell must handle the /unlock slash command."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert 'command == "/unlock"' in src or "'/unlock'" in src, (
        "Shell must register /unlock as a slash command"
    )


def test_unlock_command_calls_force_release_lock():
    """The /unlock handler must call client.force_release_lock."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "force_release_lock" in src, (
        "/unlock handler must call client.force_release_lock"
    )


# ---------------------------------------------------------------------------
# 5. Lock wait time tracking
# ---------------------------------------------------------------------------

def test_reset_lock_wait_method_exists():
    """Shell must have _reset_lock_wait method."""
    cls = _get_shell_cls()
    assert hasattr(cls, "_reset_lock_wait"), (
        "Shell must have _reset_lock_wait to clear the wait timer after success"
    )


def test_reset_lock_wait_clears_start_time():
    """_reset_lock_wait must set _lock_wait_start to None."""
    shell = _make_shell_instance()
    shell._lock_wait_start = time.monotonic()
    shell._reset_lock_wait()
    assert shell._lock_wait_start is None, (
        "_reset_lock_wait must clear _lock_wait_start to None"
    )


@pytest.mark.asyncio
async def test_wait_for_lock_retry_sets_lock_wait_start():
    """_wait_for_lock_retry must initialise _lock_wait_start on first call."""
    from msapling_cli import shell as shell_mod

    shell = _make_shell_instance()
    assert shell._lock_wait_start is None

    with patch.object(shell_mod.console, "print"):
        with patch("asyncio.sleep", new=AsyncMock()):
            await shell._wait_for_lock_retry(attempt=0, wait_seconds=1)

    assert shell._lock_wait_start is not None, (
        "_wait_for_lock_retry must set _lock_wait_start so elapsed time can be tracked"
    )


@pytest.mark.asyncio
async def test_wait_for_lock_retry_does_not_reset_existing_start_time():
    """_wait_for_lock_retry must NOT overwrite an existing _lock_wait_start."""
    from msapling_cli import shell as shell_mod

    shell = _make_shell_instance()
    early_start = time.monotonic() - 50  # simulate 50 s already elapsed
    shell._lock_wait_start = early_start

    with patch.object(shell_mod.console, "print"):
        with patch("asyncio.sleep", new=AsyncMock()):
            await shell._wait_for_lock_retry(attempt=1, wait_seconds=1)

    assert shell._lock_wait_start == early_start, (
        "_wait_for_lock_retry must preserve the original start time across retries"
    )


# ---------------------------------------------------------------------------
# 6. Ctrl+C during lock wait cancels cleanly
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_keyboard_interrupt_during_lock_wait_propagates():
    """A KeyboardInterrupt raised during _wait_for_lock_retry must propagate."""
    from msapling_cli import shell as shell_mod

    shell = _make_shell_instance()

    async def _interrupt_sleep(secs):
        raise KeyboardInterrupt

    with patch.object(shell_mod.console, "print"):
        with patch("asyncio.sleep", new=_interrupt_sleep):
            with pytest.raises(KeyboardInterrupt):
                await shell._wait_for_lock_retry(attempt=0, wait_seconds=5)


@pytest.mark.asyncio
async def test_cancelled_error_during_lock_wait_propagates():
    """asyncio.CancelledError raised during _wait_for_lock_retry must propagate."""
    from msapling_cli import shell as shell_mod

    shell = _make_shell_instance()

    async def _cancel_sleep(secs):
        raise asyncio.CancelledError

    with patch.object(shell_mod.console, "print"):
        with patch("asyncio.sleep", new=_cancel_sleep):
            with pytest.raises(asyncio.CancelledError):
                await shell._wait_for_lock_retry(attempt=0, wait_seconds=5)
