"""Guardrail tests for CLI Theme Engine and Toast Notification system.

Tests:
 1. themes.py file exists and is importable
 2. THEMES dict has diamond, onyx, lab keys
 3. Each theme has all required color keys
 4. get_theme() returns the correct theme dict
 5. Unknown theme name raises ValueError
 6. theme_color() returns a non-empty string
 7. config_theme command is registered on config_app
 8. toast.py file exists and is importable
 9. toast() function accepts level argument (info / warning / error)
10. Toast format lines use ✓ / ⚠ / ✗ prefix icons
11. Shell uses theme for prompt styling (render_prompt references active theme)
"""
from __future__ import annotations

import importlib
import io
import sys
import threading
import types
from pathlib import Path
from unittest.mock import patch, MagicMock


# ---------------------------------------------------------------------------
# Test 1: themes.py exists and is importable
# ---------------------------------------------------------------------------

def test_themes_module_exists():
    """themes.py must be importable from msapling_cli."""
    import msapling_cli.themes as themes_mod
    assert isinstance(themes_mod, types.ModuleType)


# ---------------------------------------------------------------------------
# Test 2: THEMES dict has diamond, onyx, lab keys
# ---------------------------------------------------------------------------

def test_themes_dict_has_required_keys():
    from msapling_cli.themes import THEMES
    assert "diamond" in THEMES, "THEMES must have 'diamond'"
    assert "onyx" in THEMES, "THEMES must have 'onyx'"
    assert "lab" in THEMES, "THEMES must have 'lab'"


# ---------------------------------------------------------------------------
# Test 3: Each theme has all required color keys
# ---------------------------------------------------------------------------

REQUIRED_THEME_KEYS = {
    "primary", "secondary", "accent",
    "error", "success", "warning",
    "prompt", "user_prefix", "ai_prefix",
}


def test_diamond_theme_has_required_keys():
    from msapling_cli.themes import THEMES
    missing = REQUIRED_THEME_KEYS - set(THEMES["diamond"])
    assert not missing, f"diamond theme missing keys: {missing}"


def test_onyx_theme_has_required_keys():
    from msapling_cli.themes import THEMES
    missing = REQUIRED_THEME_KEYS - set(THEMES["onyx"])
    assert not missing, f"onyx theme missing keys: {missing}"


def test_lab_theme_has_required_keys():
    from msapling_cli.themes import THEMES
    missing = REQUIRED_THEME_KEYS - set(THEMES["lab"])
    assert not missing, f"lab theme missing keys: {missing}"


# ---------------------------------------------------------------------------
# Test 4: get_theme() returns the correct theme dict
# ---------------------------------------------------------------------------

def test_get_theme_returns_correct_dict():
    from msapling_cli.themes import get_theme, THEMES
    assert get_theme("diamond") is THEMES["diamond"]
    assert get_theme("onyx") is THEMES["onyx"]
    assert get_theme("lab") is THEMES["lab"]


def test_get_theme_case_insensitive():
    from msapling_cli.themes import get_theme
    # Should work with uppercase or mixed case
    result = get_theme("Diamond")
    assert result["user_prefix"] == "◆"


# ---------------------------------------------------------------------------
# Test 5: Unknown theme raises ValueError
# ---------------------------------------------------------------------------

def test_get_theme_unknown_raises_value_error():
    from msapling_cli.themes import get_theme
    import pytest
    with pytest.raises(ValueError, match="Unknown theme"):
        get_theme("neon")


def test_get_theme_empty_raises_value_error():
    from msapling_cli.themes import get_theme
    import pytest
    with pytest.raises(ValueError):
        get_theme("")


# ---------------------------------------------------------------------------
# Test 6: theme_color() returns a non-empty string
# ---------------------------------------------------------------------------

def test_theme_color_returns_string():
    from msapling_cli.themes import theme_color
    with patch("msapling_cli.themes.get_active_theme") as mock_active:
        mock_active.return_value = {
            "primary": "bright_cyan",
            "secondary": "cyan",
            "accent": "white",
            "error": "bright_red",
            "success": "bright_green",
            "warning": "yellow",
            "prompt": "bright_cyan",
            "user_prefix": "◆",
            "ai_prefix": "◈",
        }
        color = theme_color("primary")
        assert isinstance(color, str)
        assert len(color) > 0


def test_theme_color_by_name():
    from msapling_cli.themes import theme_color
    color = theme_color("error", theme_name="lab")
    assert isinstance(color, str)
    assert color == "red"


# ---------------------------------------------------------------------------
# Test 7: config_theme command is registered on config_app
# ---------------------------------------------------------------------------

def test_config_theme_command_registered():
    """config_app must have a 'theme' sub-command registered."""
    from msapling_cli.main import config_app
    # Typer app commands are accessible via .registered_commands
    command_names = [cmd.name for cmd in config_app.registered_commands]
    assert "theme" in command_names, (
        f"'theme' not found in config_app commands. Found: {command_names}"
    )


# ---------------------------------------------------------------------------
# Test 8: toast.py file exists and is importable
# ---------------------------------------------------------------------------

def test_toast_module_exists():
    """toast.py must be importable from msapling_cli."""
    import msapling_cli.toast as toast_mod
    assert isinstance(toast_mod, types.ModuleType)


# ---------------------------------------------------------------------------
# Test 9: toast() function accepts level argument
# ---------------------------------------------------------------------------

def test_toast_accepts_level_info():
    from msapling_cli.toast import toast
    buf = io.StringIO()
    toast("hello", level="info", duration=0, file=buf)
    assert len(buf.getvalue()) > 0


def test_toast_accepts_level_warning():
    from msapling_cli.toast import toast
    buf = io.StringIO()
    toast("watch out", level="warning", duration=0, file=buf)
    assert len(buf.getvalue()) > 0


def test_toast_accepts_level_error():
    from msapling_cli.toast import toast
    buf = io.StringIO()
    toast("boom", level="error", duration=0, file=buf)
    assert len(buf.getvalue()) > 0


# ---------------------------------------------------------------------------
# Test 10: Toast format uses ✓ / ⚠ / ✗ prefix icons
# ---------------------------------------------------------------------------

def test_toast_info_uses_checkmark():
    from msapling_cli import toast as toast_mod
    # Disable color to get clean plain text
    with patch.object(toast_mod, "_use_color", False):
        buf = io.StringIO()
        toast_mod.toast("msg", level="info", duration=0, file=buf)
        output = buf.getvalue()
    assert "✓" in output, f"Expected ✓ in info toast, got: {output!r}"
    assert "Toast" in output


def test_toast_warning_uses_exclamation():
    from msapling_cli import toast as toast_mod
    with patch.object(toast_mod, "_use_color", False):
        buf = io.StringIO()
        toast_mod.toast("msg", level="warning", duration=0, file=buf)
        output = buf.getvalue()
    assert "⚠" in output, f"Expected ⚠ in warning toast, got: {output!r}"


def test_toast_error_uses_cross():
    from msapling_cli import toast as toast_mod
    with patch.object(toast_mod, "_use_color", False):
        buf = io.StringIO()
        toast_mod.toast("msg", level="error", duration=0, file=buf)
        output = buf.getvalue()
    assert "✗" in output, f"Expected ✗ in error toast, got: {output!r}"


# ---------------------------------------------------------------------------
# Test 11: Shell uses theme for prompt styling
# ---------------------------------------------------------------------------

def test_render_prompt_uses_active_theme():
    """render_prompt() in tui.py must call get_active_theme for styling.

    tui.py uses a local import ``from .themes import get_active_theme`` so we
    patch at the themes module level where the function is defined.
    """
    from msapling_cli import tui
    fake_theme = {
        "primary": "bright_cyan",
        "secondary": "cyan",
        "accent": "white",
        "error": "bright_red",
        "success": "bright_green",
        "warning": "yellow",
        "prompt": "bright_green",
        "user_prefix": "λ",
        "ai_prefix": "⊕",
    }
    with patch("msapling_cli.themes.get_active_theme", return_value=fake_theme):
        prompt = tui.render_prompt()
    # The themed user_prefix λ and prompt color bright_green should appear
    assert "λ" in prompt, f"Expected theme user_prefix 'λ' in prompt, got: {prompt!r}"
    assert "bright_green" in prompt, (
        f"Expected theme prompt color 'bright_green' in prompt, got: {prompt!r}"
    )


def test_render_user_message_uses_theme_prefix():
    """render_user_message() must use the active theme's user_prefix.

    tui.py uses a local import so we patch at the themes module level.
    """
    from msapling_cli import tui
    from io import StringIO
    from rich.console import Console

    fake_theme = {
        "primary": "bright_cyan",
        "secondary": "cyan",
        "accent": "white",
        "error": "bright_red",
        "success": "bright_green",
        "warning": "yellow",
        "prompt": "bright_cyan",
        "user_prefix": "●",
        "ai_prefix": "○",
    }
    buf = StringIO()
    test_console = Console(file=buf, no_color=True)
    with patch("msapling_cli.themes.get_active_theme", return_value=fake_theme), \
         patch("msapling_cli.tui.console", test_console):
        tui.render_user_message("hello world")
    output = buf.getvalue()
    assert "●" in output, f"Expected '●' prefix in user message, got: {output!r}"
