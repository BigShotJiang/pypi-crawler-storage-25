"""Guardrail tests for cli/msapling_cli/mbrain_integration.py.

All tests are pure-unit (no network, no filesystem I/O, no CLI process
spawned).  External HTTP calls are patched out via unittest.mock.
"""
from __future__ import annotations

import json
import threading
import time
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest

from msapling_cli.mbrain_integration import (
    MBrainSessionSync,
    _has_recall_trigger,
    build_sync_from_config,
    should_inject_context,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

BASE_URL = "https://api.msapling.test"
TOKEN = "test-jwt-token"


def _make_sync(**kwargs) -> MBrainSessionSync:
    defaults = {"base_url": BASE_URL, "token": TOKEN}
    defaults.update(kwargs)
    return MBrainSessionSync(**defaults)


def _minimal_session(session_id: str = "sess-001") -> Dict[str, Any]:
    return {
        "id": session_id,
        "messages": [
            {"role": "user", "content": "How do I use async/await?"},
            {"role": "assistant", "content": "Use async def and await for coroutines."},
        ],
        "model": "claude-3-5-sonnet",
        "project_root": "/home/user/myproject",
        "cost_total": 0.0042,
        "tokens_total": 320,
        "metadata": {
            "session_id": session_id,
            "project_name": "myproject",
            "models_used": ["claude-3-5-sonnet"],
            "files_touched": ["src/main.py"],
            "slash_commands_used": ["/read", "/edit"],
            "total_cost_usd": 0.0042,
            "turn_count": 1,
            "started_at": "2026-04-17T10:00:00+00:00",
            "ended_at": "2026-04-17T10:05:00+00:00",
            "duration_seconds": 300.0,
            "summary": "Discussed async/await pattern for API layer",
        },
    }


# ---------------------------------------------------------------------------
# Test 1: Module and class importable
# ---------------------------------------------------------------------------

def test_module_importable():
    """MBrainSessionSync class is importable from mbrain_integration."""
    assert MBrainSessionSync is not None


# ---------------------------------------------------------------------------
# Test 2: Constructor accepts base_url and token
# ---------------------------------------------------------------------------

def test_constructor_stores_base_url_and_token():
    sync = _make_sync()
    assert sync.base_url == BASE_URL
    assert sync.token == TOKEN


# ---------------------------------------------------------------------------
# Test 3: base_url trailing slash is stripped
# ---------------------------------------------------------------------------

def test_constructor_strips_trailing_slash():
    sync = MBrainSessionSync(base_url="https://example.com/", token=TOKEN)
    assert not sync.base_url.endswith("/")


# ---------------------------------------------------------------------------
# Test 4: format_session_entry returns required keys
# ---------------------------------------------------------------------------

def test_format_session_entry_required_keys():
    sync = _make_sync()
    session = _minimal_session()
    entry = sync.format_session_entry(session)
    required = {"title", "content", "tags", "source", "source_id", "metadata"}
    assert required.issubset(entry.keys())


# ---------------------------------------------------------------------------
# Test 5: format_session_entry sets source = "cli_session"
# ---------------------------------------------------------------------------

def test_format_session_entry_source_is_cli_session():
    sync = _make_sync()
    entry = sync.format_session_entry(_minimal_session())
    assert entry["source"] == "cli_session"


# ---------------------------------------------------------------------------
# Test 6: format_session_entry title derived from summary
# ---------------------------------------------------------------------------

def test_format_session_entry_title_from_summary():
    sync = _make_sync()
    session = _minimal_session()
    entry = sync.format_session_entry(session)
    # summary = "Discussed async/await pattern for API layer"
    assert "async" in entry["title"].lower() or entry["title"] == session["metadata"]["summary"]


# ---------------------------------------------------------------------------
# Test 7: format_session_entry tags include project tag
# ---------------------------------------------------------------------------

def test_format_session_entry_tags_include_project():
    sync = _make_sync()
    entry = sync.format_session_entry(_minimal_session())
    assert any("project:myproject" in t for t in entry["tags"])


# ---------------------------------------------------------------------------
# Test 8: format_session_entry tags include cli_session
# ---------------------------------------------------------------------------

def test_format_session_entry_tags_include_cli_session():
    sync = _make_sync()
    entry = sync.format_session_entry(_minimal_session())
    assert "cli_session" in entry["tags"]


# ---------------------------------------------------------------------------
# Test 9: format_session_entry embeds metadata.session_id
# ---------------------------------------------------------------------------

def test_format_session_entry_metadata_session_id():
    sync = _make_sync()
    entry = sync.format_session_entry(_minimal_session("sess-xyz"))
    assert entry["metadata"]["session_id"] == "sess-xyz"
    assert entry["source_id"] == "sess-xyz"


# ---------------------------------------------------------------------------
# Test 10: sync_session skips empty sessions (no messages)
# ---------------------------------------------------------------------------

def test_sync_session_skips_empty():
    sync = _make_sync()
    empty = {"id": "sess-empty", "messages": [], "metadata": {}}
    with patch.object(sync, "_post_entry") as mock_post:
        sync.sync_session(empty)
        time.sleep(0.05)
        mock_post.assert_not_called()


# ---------------------------------------------------------------------------
# Test 11: sync_session skips sessions without an id
# ---------------------------------------------------------------------------

def test_sync_session_skips_no_id():
    sync = _make_sync()
    no_id = {"messages": [{"role": "user", "content": "hello"}], "metadata": {}}
    with patch.object(sync, "_post_entry") as mock_post:
        sync.sync_session(no_id)
        time.sleep(0.05)
        mock_post.assert_not_called()


# ---------------------------------------------------------------------------
# Test 12: sync_session spawns a daemon thread and calls _post_entry
# ---------------------------------------------------------------------------

def test_sync_session_background_thread():
    sync = _make_sync()
    called = threading.Event()

    def _fake_post(entry):
        called.set()

    with patch.object(sync, "_post_entry", side_effect=_fake_post):
        sync.sync_session(_minimal_session())
        assert called.wait(timeout=2.0), "_post_entry was not called within 2 seconds"


# ---------------------------------------------------------------------------
# Test 13: search_sessions returns list on HTTP 200
# ---------------------------------------------------------------------------

def test_search_sessions_returns_list_on_success():
    sync = _make_sync()
    fake_response = {
        "results": [
            {
                "source_id": "sess-001",
                "title": "Async/await session",
                "score": 0.92,
                "snippet": "We decided to use async/await for the API layer.",
                "metadata": {"project": "myproject"},
            }
        ]
    }
    with patch("msapling_cli.mbrain_integration._http_get", return_value=fake_response):
        results = sync.search_sessions("async/await", limit=5)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0]["session_id"] == "sess-001"
    assert results[0]["score"] == 0.92


# ---------------------------------------------------------------------------
# Test 14: search_sessions returns empty list on HTTP failure
# ---------------------------------------------------------------------------

def test_search_sessions_returns_empty_on_failure():
    sync = _make_sync()
    with patch("msapling_cli.mbrain_integration._http_get", return_value=None):
        results = sync.search_sessions("something")
    assert results == []


# ---------------------------------------------------------------------------
# Test 15: search_sessions enforces limit ceiling
# ---------------------------------------------------------------------------

def test_search_sessions_limit_enforced():
    sync = _make_sync()
    many_results = {
        "results": [
            {"source_id": f"s-{i}", "title": f"Session {i}", "score": 0.5, "snippet": "", "metadata": {}}
            for i in range(30)
        ]
    }
    with patch("msapling_cli.mbrain_integration._http_get", return_value=many_results):
        results = sync.search_sessions("anything", limit=5)
    assert len(results) <= 5


# ---------------------------------------------------------------------------
# Test 16: get_session_context returns formatted block with citation
# ---------------------------------------------------------------------------

def test_get_session_context_formatted_block():
    sync = _make_sync()
    fake_results = [
        {
            "session_id": "sess-001",
            "title": "Async/await session",
            "project": "myproject",
            "score": 0.9,
            "snippet": "We decided to use async/await for the API layer.",
            "metadata": {},
        }
    ]
    with patch.object(sync, "search_sessions", return_value=fake_results):
        ctx = sync.get_session_context("async pattern")
    assert "[From past sessions" in ctx
    assert "async" in ctx.lower()
    assert "[End past sessions]" in ctx


# ---------------------------------------------------------------------------
# Test 17: get_session_context returns empty string when no results
# ---------------------------------------------------------------------------

def test_get_session_context_empty_on_no_results():
    sync = _make_sync()
    with patch.object(sync, "search_sessions", return_value=[]):
        ctx = sync.get_session_context("some query")
    assert ctx == ""


# ---------------------------------------------------------------------------
# Test 18: should_inject_context / _has_recall_trigger coverage
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("phrase,expected", [
    ("last time we used Redis", True),
    ("previously I mentioned the pattern", True),
    ("remember when you said to use async", True),
    ("we decided to refactor the router", True),
    ("you told me to avoid globals", True),
    ("session abc123 showed a different approach", True),
    ("as discussed earlier", True),
    ("how do I write a function?", False),
    ("list all files in the directory", False),
    ("", False),
])
def test_recall_trigger_detection(phrase, expected):
    assert should_inject_context(phrase) == expected
    assert _has_recall_trigger(phrase) == expected
