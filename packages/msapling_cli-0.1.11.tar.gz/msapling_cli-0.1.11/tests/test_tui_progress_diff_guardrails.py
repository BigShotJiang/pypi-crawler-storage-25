"""Guardrail tests: TUI progress bars and diff preview rendering.

Verifies (via source-scan):
1. _show_progress method exists on InteractiveShell
2. rich.progress.Progress is used inside _show_progress
3. MSAPLING_NO_PROGRESS env var is checked inside _show_progress
4. _render_diff method exists on InteractiveShell
5. _is_diff_block static method exists on InteractiveShell
6. rich.syntax.Syntax is used inside _render_diff
7. _is_diff_block returns False for plain text
8. _is_diff_block returns True for a real unified diff
9. _render_diff calls render_assistant_response for plain text (no diff)
10. _show_progress returns a no-op when MSAPLING_NO_PROGRESS=1
"""
from __future__ import annotations

import inspect
import os


# ---------------------------------------------------------------------------
# Helper: import shell module without running anything
# ---------------------------------------------------------------------------

def _get_shell_source() -> str:
    from msapling_cli import shell as shell_mod
    return inspect.getsource(shell_mod)


def _get_shell_cls():
    from msapling_cli.shell import InteractiveShell
    return InteractiveShell


# ---------------------------------------------------------------------------
# 1. _show_progress exists on InteractiveShell
# ---------------------------------------------------------------------------

def test_show_progress_method_exists():
    """InteractiveShell must expose a _show_progress method."""
    cls = _get_shell_cls()
    assert hasattr(cls, "_show_progress"), (
        "InteractiveShell._show_progress must exist"
    )
    assert callable(cls._show_progress), (
        "_show_progress must be callable"
    )


# ---------------------------------------------------------------------------
# 2. rich.progress.Progress used in _show_progress
# ---------------------------------------------------------------------------

def test_show_progress_uses_rich_progress():
    """_show_progress must instantiate rich.progress.Progress."""
    cls = _get_shell_cls()
    src = inspect.getsource(cls._show_progress)
    assert "Progress" in src, (
        "_show_progress must use rich.progress.Progress"
    )


# ---------------------------------------------------------------------------
# 3. MSAPLING_NO_PROGRESS env var checked in _show_progress
# ---------------------------------------------------------------------------

def test_show_progress_respects_no_progress_env():
    """_show_progress must check MSAPLING_NO_PROGRESS env variable."""
    cls = _get_shell_cls()
    src = inspect.getsource(cls._show_progress)
    assert "MSAPLING_NO_PROGRESS" in src, (
        "_show_progress must check the MSAPLING_NO_PROGRESS env var"
    )


# ---------------------------------------------------------------------------
# 4. _render_diff exists on InteractiveShell
# ---------------------------------------------------------------------------

def test_render_diff_method_exists():
    """InteractiveShell must expose a _render_diff method."""
    cls = _get_shell_cls()
    assert hasattr(cls, "_render_diff"), (
        "InteractiveShell._render_diff must exist"
    )
    assert callable(cls._render_diff), (
        "_render_diff must be callable"
    )


# ---------------------------------------------------------------------------
# 5. _is_diff_block exists on InteractiveShell
# ---------------------------------------------------------------------------

def test_is_diff_block_method_exists():
    """InteractiveShell must expose a _is_diff_block method."""
    cls = _get_shell_cls()
    assert hasattr(cls, "_is_diff_block"), (
        "InteractiveShell._is_diff_block must exist"
    )
    assert callable(cls._is_diff_block), (
        "_is_diff_block must be callable"
    )


# ---------------------------------------------------------------------------
# 6. rich.syntax.Syntax used in _render_diff
# ---------------------------------------------------------------------------

def test_render_diff_uses_rich_syntax():
    """_render_diff must use rich.syntax.Syntax for highlighting."""
    cls = _get_shell_cls()
    src = inspect.getsource(cls._render_diff)
    assert "Syntax" in src, (
        "_render_diff must use rich.syntax.Syntax"
    )


# ---------------------------------------------------------------------------
# 7. _is_diff_block returns False for plain text
# ---------------------------------------------------------------------------

def test_is_diff_block_false_for_plain_text():
    """`_is_diff_block` must return False for ordinary prose."""
    cls = _get_shell_cls()
    plain = "Hello, this is just a normal response with no diff content."
    assert cls._is_diff_block(plain) is False, (
        "_is_diff_block must return False for plain text"
    )


# ---------------------------------------------------------------------------
# 8. _is_diff_block returns True for unified diff
# ---------------------------------------------------------------------------

def test_is_diff_block_true_for_unified_diff():
    """`_is_diff_block` must return True for a real unified diff."""
    cls = _get_shell_cls()
    diff_text = (
        "--- a/foo.py\n"
        "+++ b/foo.py\n"
        "@@ -1,4 +1,5 @@\n"
        " def greet():\n"
        "-    return 'hello'\n"
        "+    return 'hello world'\n"
        "+    # greeting updated\n"
        " \n"
    )
    assert cls._is_diff_block(diff_text) is True, (
        "_is_diff_block must return True for unified diff text"
    )


# ---------------------------------------------------------------------------
# 9. _is_diff_block returns False for partial diff (no @@ hunk)
# ---------------------------------------------------------------------------

def test_is_diff_block_false_for_no_hunk_header():
    """`_is_diff_block` must require an @@ hunk header to classify as diff."""
    cls = _get_shell_cls()
    no_hunk = (
        "--- a/foo.py\n"
        "+++ b/foo.py\n"
        "+ some added line\n"
        "- some removed line\n"
    )
    # Without @@ the heuristic should not fire
    assert cls._is_diff_block(no_hunk) is False, (
        "_is_diff_block must require @@ hunk headers to return True"
    )


# ---------------------------------------------------------------------------
# 10. _show_progress returns a no-op context manager when env var set
# ---------------------------------------------------------------------------

def test_show_progress_noop_with_env_var(monkeypatch, tmp_path):
    """When MSAPLING_NO_PROGRESS=1 _show_progress must return a no-op object."""
    monkeypatch.setenv("MSAPLING_NO_PROGRESS", "1")

    # Construct a minimal shell-like object without running the full __init__.
    cls = _get_shell_cls()
    shell = object.__new__(cls)
    shell.no_tui = False

    result = shell._show_progress("Test operation")
    # Must be usable as a context manager.
    assert hasattr(result, "__enter__"), "no-op result must support __enter__"
    assert hasattr(result, "__exit__"), "no-op result must support __exit__"
    # Must have add_task (same API as real Progress).
    assert hasattr(result, "add_task"), "no-op result must have add_task method"
    # Must work as a context manager without raising.
    with result as p:
        task_id = p.add_task("doing something", total=None)
        p.update(task_id, advance=1)


# ---------------------------------------------------------------------------
# 11. _show_progress is imported/referenced in the stream section of _chat
# ---------------------------------------------------------------------------

def test_show_progress_used_in_chat():
    """_show_progress must be called inside the streaming section of _chat."""
    cls = _get_shell_cls()
    src = inspect.getsource(cls._chat)
    assert "_show_progress" in src, (
        "_show_progress must be called inside _chat to show pre-stream progress"
    )


# ---------------------------------------------------------------------------
# 12. _render_diff is called in the _chat response handling
# ---------------------------------------------------------------------------

def test_render_diff_called_in_chat():
    """_render_diff must be called in _chat when a response is received."""
    cls = _get_shell_cls()
    src = inspect.getsource(cls._chat)
    assert "_render_diff" in src, (
        "_render_diff must be called in _chat to handle diff responses"
    )
