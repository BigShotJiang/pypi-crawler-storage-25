"""Tests for memdir typed memory system.

Covers save, get, list, delete, search, backward compat, index management.
"""
import tempfile
from pathlib import Path

import pytest

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from msapling_cli.memdir import (
    save_memory,
    get_memory,
    list_memories,
    delete_memory,
    clear_memories,
    build_memory_context,
    add_memory,
    get_memories,
    _parse_frontmatter,
    _slugify,
    VALID_TYPES,
)


@pytest.fixture
def tmp_root(tmp_path):
    return str(tmp_path)


class TestSaveAndGet:
    def test_save_user_memory(self, tmp_root):
        result = save_memory("Python expert", "10 years experience", "user", project_root=tmp_root)
        assert "Saved" in result
        mem = get_memory("Python expert", project_root=tmp_root)
        assert mem is not None
        assert mem["type"] == "user"
        assert "10 years" in mem["content"]

    def test_save_feedback_memory(self, tmp_root):
        save_memory("No mocks", "Use real DB in tests", "feedback", project_root=tmp_root)
        mem = get_memory("No mocks", project_root=tmp_root)
        assert mem["type"] == "feedback"

    def test_save_project_memory(self, tmp_root):
        save_memory("Auth refactor", "Due Friday", "project", project_root=tmp_root)
        mem = get_memory("Auth refactor", project_root=tmp_root)
        assert mem["type"] == "project"

    def test_save_reference_memory(self, tmp_root):
        save_memory("API docs", "https://example.com/docs", "reference", project_root=tmp_root)
        mem = get_memory("API docs", project_root=tmp_root)
        assert mem["type"] == "reference"

    def test_invalid_type_rejected(self, tmp_root):
        result = save_memory("test", "content", "invalid_type", project_root=tmp_root)
        assert "Error" in result

    def test_get_nonexistent_returns_none(self, tmp_root):
        assert get_memory("nonexistent", project_root=tmp_root) is None


class TestListAndFilter:
    def test_list_all(self, tmp_root):
        save_memory("A", "content", "user", project_root=tmp_root)
        save_memory("B", "content", "feedback", project_root=tmp_root)
        save_memory("C", "content", "project", project_root=tmp_root)
        mems = list_memories(tmp_root)
        assert len(mems) == 3

    def test_list_by_type(self, tmp_root):
        save_memory("A", "content", "user", project_root=tmp_root)
        save_memory("B", "content", "feedback", project_root=tmp_root)
        users = list_memories(tmp_root, mem_type="user")
        assert len(users) == 1
        assert users[0]["type"] == "user"

    def test_list_empty(self, tmp_root):
        assert list_memories(tmp_root) == []


class TestDelete:
    def test_delete_existing(self, tmp_root):
        save_memory("To delete", "content", "user", project_root=tmp_root)
        result = delete_memory("To delete", project_root=tmp_root)
        assert "Deleted" in result
        assert get_memory("To delete", project_root=tmp_root) is None

    def test_delete_nonexistent(self, tmp_root):
        result = delete_memory("nope", project_root=tmp_root)
        assert "Not found" in result


class TestClear:
    def test_clear_all(self, tmp_root):
        save_memory("A", "c", "user", project_root=tmp_root)
        save_memory("B", "c", "feedback", project_root=tmp_root)
        clear_memories(tmp_root)
        assert list_memories(tmp_root) == []


class TestSearch:
    def test_search_finds_relevant(self, tmp_root):
        save_memory("Python expert", "async await experience", "user", project_root=tmp_root)
        save_memory("Deadline", "Auth module due Friday", "project", project_root=tmp_root)
        ctx = build_memory_context(tmp_root, query="async Python")
        assert "Python expert" in ctx
        assert "async" in ctx

    def test_search_no_results(self, tmp_root):
        save_memory("Unrelated", "cooking recipe", "project", project_root=tmp_root)
        ctx = build_memory_context(tmp_root, query="quantum physics")
        assert ctx == ""

    def test_context_without_query(self, tmp_root):
        save_memory("A", "content", "user", project_root=tmp_root)
        ctx = build_memory_context(tmp_root)
        assert "[Memories]" in ctx


class TestBackwardCompat:
    def test_add_memory_autodetects_feedback(self, tmp_root):
        result = add_memory("don't use mocks in tests", project_root=tmp_root)
        assert "feedback" in result.lower() or "Saved" in result

    def test_add_memory_autodetects_reference(self, tmp_root):
        result = add_memory("check https://docs.example.com for API info", project_root=tmp_root)
        assert "reference" in result.lower() or "Saved" in result

    def test_get_memories_returns_string(self, tmp_root):
        save_memory("Test", "content", "user", project_root=tmp_root)
        result = get_memories(tmp_root)
        assert isinstance(result, str)


class TestFrontmatter:
    def test_parse_valid(self):
        content = "---\nname: test\ntype: user\n---\nBody content"
        meta, body = _parse_frontmatter(content)
        assert meta["name"] == "test"
        assert meta["type"] == "user"
        assert body == "Body content"

    def test_parse_no_frontmatter(self):
        content = "Just plain text"
        meta, body = _parse_frontmatter(content)
        assert meta == {}
        assert body == content


class TestSlugify:
    def test_basic(self):
        assert _slugify("Hello World") == "hello_world"

    def test_special_chars(self):
        assert _slugify("Don't use mocks!") == "don_t_use_mocks"

    def test_long_string_truncated(self):
        result = _slugify("a" * 100)
        assert len(result) <= 60
