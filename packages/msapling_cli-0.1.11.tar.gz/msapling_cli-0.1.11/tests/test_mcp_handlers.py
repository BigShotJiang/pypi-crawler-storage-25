"""Tests for MCP server tool handler dispatch (_handle_tool).

Each test mocks MSaplingClient at the api module level (where server.py
imports it) so no real network calls are made.

The import inside _handle_tool is:  from ..api import MSaplingClient
so the correct patch target is:     msapling_cli.api.MSaplingClient
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from msapling_cli.mcp.server import _handle_tool

# Patch target: server.py does `from ..api import MSaplingClient`
# which binds the name into msapling_cli.api first, then server imports it.
# Patching the source module ensures the binding inside _handle_tool is replaced.
_PATCH_CLIENT = "msapling_cli.api.MSaplingClient"


# ---------------------------------------------------------------------------
# Helper: build a mock MSaplingClient instance
# ---------------------------------------------------------------------------

def _make_client(**methods):
    """Return an AsyncMock client with the given async methods pre-configured."""
    client = AsyncMock()
    client.close = AsyncMock()
    for name, return_value in methods.items():
        getattr(client, name).return_value = return_value
    return client


# ---------------------------------------------------------------------------
# 1. test_msapling_read_file
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_msapling_read_file():
    """msapling_read_file returns file content wrapped in MCP content list."""
    client = _make_client(read_file="def hello(): pass\n")

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool(
            "msapling_read_file",
            {"project_id": "proj1", "file_path": "src/main.py"},
        )

    assert result["content"][0]["type"] == "text"
    assert "def hello" in result["content"][0]["text"]
    client.close.assert_called_once()


@pytest.mark.asyncio
async def test_msapling_read_file_traversal_blocked():
    """msapling_read_file rejects path traversal attempts."""
    client = _make_client(read_file="should not reach")

    with patch(_PATCH_CLIENT, return_value=client):
        with pytest.raises(ValueError, match="Invalid file path"):
            await _handle_tool(
                "msapling_read_file",
                {"project_id": "proj1", "file_path": "../../etc/passwd"},
            )


# ---------------------------------------------------------------------------
# 2. test_msapling_write_file
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_msapling_write_file():
    """msapling_write_file returns a JSON success response."""
    write_response = {"status": "ok", "version": 2}
    client = _make_client(write_file=write_response)

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool(
            "msapling_write_file",
            {
                "project_id": "proj1",
                "file_path": "notes.md",
                "content": "# Notes\nHello world",
            },
        )

    text = result["content"][0]["text"]
    parsed = json.loads(text)
    assert parsed["status"] == "ok"
    client.write_file.assert_called_once_with("proj1", "notes.md", "# Notes\nHello world")
    client.close.assert_called_once()


@pytest.mark.asyncio
async def test_msapling_write_file_invalid_project_id():
    """msapling_write_file rejects project_id with embedded whitespace."""
    # Must be AsyncMock so `await client.close()` in the finally block works.
    client = AsyncMock()
    client.close = AsyncMock()

    with patch(_PATCH_CLIENT, return_value=client):
        with pytest.raises(ValueError, match="Invalid project_id"):
            await _handle_tool(
                "msapling_write_file",
                {
                    "project_id": "bad id here",
                    "file_path": "file.py",
                    "content": "x",
                },
            )


# ---------------------------------------------------------------------------
# 3. test_msapling_search_files
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_msapling_search_files():
    """msapling_search_files returns JSON-serialised search results."""
    search_results = [
        {"path": "README.md", "score": 0.95, "snippet": "Installation guide"},
        {"path": "docs/api.md", "score": 0.80, "snippet": "API reference"},
    ]
    mock_resp = MagicMock()
    mock_resp.json.return_value = search_results
    mock_resp.raise_for_status = MagicMock()

    mock_http = AsyncMock()
    mock_http.post = AsyncMock(return_value=mock_resp)

    client = AsyncMock()
    client._get_client = AsyncMock(return_value=mock_http)
    client.close = AsyncMock()

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool(
            "msapling_search_files",
            {"project_id": "proj1", "query": "installation", "limit": 5},
        )

    text = result["content"][0]["text"]
    parsed = json.loads(text)
    assert len(parsed) == 2
    assert parsed[0]["path"] == "README.md"
    client.close.assert_called_once()


@pytest.mark.asyncio
async def test_msapling_search_files_limit_clamped():
    """msapling_search_files clamps limit to 20 maximum."""
    mock_resp = MagicMock()
    mock_resp.json.return_value = []
    mock_resp.raise_for_status = MagicMock()

    mock_http = AsyncMock()
    mock_http.post = AsyncMock(return_value=mock_resp)

    client = AsyncMock()
    client._get_client = AsyncMock(return_value=mock_http)
    client.close = AsyncMock()

    with patch(_PATCH_CLIENT, return_value=client):
        await _handle_tool(
            "msapling_search_files",
            {"project_id": "proj1", "query": "test", "limit": 999},
        )

    # The post call must have received a limit <= 20
    call_kwargs = mock_http.post.call_args
    body = call_kwargs.kwargs.get("json") or call_kwargs.args[1] if call_kwargs.args else {}
    if not body:
        # Fallback: extract from positional args
        body = call_kwargs[1].get("json", {}) if len(call_kwargs) > 1 else {}
    assert body.get("limit", 999) <= 20


# ---------------------------------------------------------------------------
# 4. test_msapling_cost_check
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_msapling_cost_check():
    """msapling_cost_check returns tier, credits, and pro status."""
    user_data = {"tier": "monthly", "fuel_credits": 4.2500, "is_pro": True}
    client = _make_client(me=user_data)

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool("msapling_cost_check", {})

    text = result["content"][0]["text"]
    assert "monthly" in text
    assert "4.2500" in text
    assert "True" in text
    client.close.assert_called_once()


@pytest.mark.asyncio
async def test_msapling_cost_check_free_tier():
    """msapling_cost_check works for a free-tier user with zero credits."""
    user_data = {"tier": "free", "fuel_credits": 0.0, "is_pro": False}
    client = _make_client(me=user_data)

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool("msapling_cost_check", {})

    text = result["content"][0]["text"]
    assert "free" in text.lower()
    assert "0.0000" in text


# ---------------------------------------------------------------------------
# 5. test_msapling_models
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_msapling_models():
    """msapling_models returns a formatted list of model IDs."""
    models_data = [
        {"id": "google/gemini-2.0-flash-001", "context_length": 128000},
        {"id": "openai/gpt-4o", "context_length": 128000},
        {"id": "anthropic/claude-3.5-sonnet", "context_length": 200000},
    ]
    client = _make_client(get_models=models_data)

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool("msapling_models", {})

    text = result["content"][0]["text"]
    assert "google/gemini-2.0-flash-001" in text
    assert "openai/gpt-4o" in text
    assert "anthropic/claude-3.5-sonnet" in text
    client.close.assert_called_once()


@pytest.mark.asyncio
async def test_msapling_models_empty_list():
    """msapling_models handles an empty model list gracefully."""
    client = _make_client(get_models=[])

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool("msapling_models", {})

    text = result["content"][0]["text"]
    assert isinstance(text, str)


# ---------------------------------------------------------------------------
# 6. test_unknown_tool
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_unknown_tool_returns_error():
    """_handle_tool returns an isError response for unknown tool names."""
    client = AsyncMock()
    client.close = AsyncMock()

    with patch(_PATCH_CLIENT, return_value=client):
        result = await _handle_tool("nonexistent_tool", {})

    assert result.get("isError") is True
    assert "Unknown tool" in result["content"][0]["text"]
