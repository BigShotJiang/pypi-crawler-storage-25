"""Guardrail tests for CLI progress indicators (working_spinner).

Verifies that:
- working_spinner is importable and is an async context manager
- It is a no-op in CI/non-TTY environments
- main.py imports and uses it around blocking operations
- The _headless flow shows the spinner before streaming starts
"""
from __future__ import annotations

import asyncio
import inspect
import sys

import pytest


# ---------------------------------------------------------------------------
# 1. working_spinner existence and interface
# ---------------------------------------------------------------------------

def test_working_spinner_importable():
    from msapling_cli.tui import working_spinner
    assert callable(working_spinner)


def test_working_spinner_is_async_context_manager():
    """working_spinner must be usable as `async with working_spinner(...)`."""
    from msapling_cli.tui import working_spinner
    # asynccontextmanager produces a function; calling it returns an object
    # with __aenter__ and __aexit__
    ctx = working_spinner("Test")
    assert hasattr(ctx, "__aenter__"), "working_spinner() must return an async context manager"
    assert hasattr(ctx, "__aexit__"), "working_spinner() must return an async context manager"


def test_working_spinner_accepts_label():
    from msapling_cli.tui import working_spinner
    sig = inspect.signature(working_spinner)
    assert "label" in sig.parameters


def test_working_spinner_has_min_display_kwarg():
    from msapling_cli.tui import working_spinner
    sig = inspect.signature(working_spinner)
    assert "min_display_s" in sig.parameters


# ---------------------------------------------------------------------------
# 2. No-op in CI / non-TTY mode
# ---------------------------------------------------------------------------

def test_working_spinner_noop_in_ci(monkeypatch):
    """working_spinner must not start any background task when _no_color is True."""
    import msapling_cli.tui as tui_mod
    monkeypatch.setattr(tui_mod, "_no_color", True)

    ran = []

    async def _body():
        ran.append(True)

    async def _run():
        async with tui_mod.working_spinner("CI Test"):
            await asyncio.sleep(0)  # yield control
            ran.append("body")

    # Must complete without error and without starting background animation
    asyncio.run(_run())
    assert "body" in ran, "body must execute even in no_color / CI mode"


@pytest.mark.asyncio
async def test_working_spinner_yields_control():
    """working_spinner body must execute and its result must be reachable."""
    import msapling_cli.tui as tui_mod

    # Force no_color to avoid TTY dependency in test
    original = tui_mod._no_color
    tui_mod._no_color = True
    try:
        result = []
        async with tui_mod.working_spinner("Loading"):
            result.append(42)
        assert result == [42]
    finally:
        tui_mod._no_color = original



# ---------------------------------------------------------------------------
# 3. main.py imports and uses working_spinner
# ---------------------------------------------------------------------------

def test_main_imports_working_spinner():
    from msapling_cli import main
    assert hasattr(main, "working_spinner"), (
        "main.py must import working_spinner from tui"
    )


def test_headless_uses_working_spinner():
    """_headless must wrap its connection step in working_spinner."""
    import inspect as _inspect
    from msapling_cli import main
    source = _inspect.getsource(main._headless)
    assert "working_spinner" in source, (
        "_headless must use working_spinner to avoid silent connection wait"
    )


def test_headless_spinner_label_is_connecting():
    """The spinner in _headless should say 'Connecting' so users know what's happening."""
    import inspect as _inspect
    from msapling_cli import main
    source = _inspect.getsource(main._headless)
    assert "Connecting" in source, (
        "_headless spinner label must be 'Connecting' (or similar) — not silent"
    )
