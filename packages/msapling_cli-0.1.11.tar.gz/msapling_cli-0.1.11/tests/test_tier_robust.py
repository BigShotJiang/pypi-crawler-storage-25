"""Robust tests for tier gating: free/pro model access, command blocking, Ollama."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from msapling_cli.tier import (
    FREE_MODELS,
    PRO_COMMANDS,
    check_tier,
    is_free_model,
    require_auth,
    require_pro,
)


# ---- Helpers ----


def _free_user():
    return {"tier": "free", "is_pro": False}


def _pro_user():
    return {"tier": "monthly", "is_pro": True}


def _lifetime_user():
    return {"tier": "lifetime", "is_pro": False}


def _enterprise_user():
    return {"tier": "enterprise", "is_pro": True}


def _guest_user():
    return {"tier": "guest", "is_pro": False}


# ---- is_free_model ----


def test_is_free_model_gemini_flash():
    """Gemini Flash models are free."""
    assert is_free_model("google/gemini-flash-1.5") is True
    assert is_free_model("google/gemini-2.0-flash-001") is True


def test_is_free_model_haiku():
    """Claude Haiku is free."""
    assert is_free_model("anthropic/claude-3-haiku") is True


def test_is_free_model_mini():
    """GPT-4o-mini is free."""
    assert is_free_model("openai/gpt-4o-mini") is True


def test_is_free_model_llama():
    """LLama models are free."""
    assert is_free_model("meta-llama/llama-3.1-8b-instruct") is True
    assert is_free_model("meta-llama/llama-3-70b-instruct") is True


def test_is_free_model_mistral():
    """Mistral models are free."""
    assert is_free_model("mistralai/mistral-large") is True
    assert is_free_model("mistralai/mistral-small") is True


def test_is_free_model_gemma():
    """Gemma models are free."""
    assert is_free_model("google/gemma-7b-it") is True


def test_is_free_model_phi():
    """Phi models are free."""
    assert is_free_model("microsoft/phi-3-mini") is True


def test_is_free_model_qwen():
    """Qwen models are free."""
    assert is_free_model("qwen/qwen-2-72b-instruct") is True


def test_is_free_model_ollama_always_free():
    """All Ollama models are always free regardless of name."""
    assert is_free_model("ollama/codellama") is True
    assert is_free_model("ollama/gpt-4o-local") is True  # Even if name looks "pro"
    assert is_free_model("ollama/claude-local") is True
    assert is_free_model("ollama/my-custom-model") is True


def test_pro_model_gpt4o():
    """GPT-4o (not mini) is a pro model."""
    assert is_free_model("openai/gpt-4o") is False


def test_pro_model_claude_sonnet():
    """Claude 3.5 Sonnet is a pro model."""
    assert is_free_model("anthropic/claude-3.5-sonnet") is False


def test_pro_model_claude_opus():
    """Claude 3 Opus is a pro model."""
    assert is_free_model("anthropic/claude-3-opus") is False


def test_pro_model_gpt4_turbo():
    """GPT-4 Turbo is a pro model."""
    assert is_free_model("openai/gpt-4-turbo") is False


def test_pro_model_o1():
    """o1 models are pro."""
    assert is_free_model("openai/o1") is False
    assert is_free_model("openai/o1-preview") is False


def test_is_free_model_empty_string():
    """Empty string is not a free model."""
    assert is_free_model("") is False


def test_is_free_model_none_safe():
    """is_free_model handles None-ish input safely."""
    # The function does (model_id or "").lower(), so None would fail
    # but empty string works
    assert is_free_model("") is False


def test_is_free_model_case_insensitive():
    """is_free_model checks are case-insensitive."""
    assert is_free_model("Google/Gemini-FLASH-1.5") is True
    assert is_free_model("ANTHROPIC/CLAUDE-3-HAIKU") is True


# ---- check_tier: Pro user ----


def test_pro_user_all_commands_allowed():
    """Pro user can use all commands with any model."""
    user = _pro_user()
    for cmd in ("chat", "multi", "swarm", "edit", "benchmark", "scan", "context"):
        ok, msg = check_tier(user, cmd, "openai/gpt-4o")
        assert ok is True, f"Pro user blocked from {cmd}"
        assert msg == ""


def test_lifetime_user_all_commands_allowed():
    """Lifetime user can use all commands."""
    user = _lifetime_user()
    for cmd in ("chat", "multi", "swarm", "edit", "benchmark"):
        ok, msg = check_tier(user, cmd, "anthropic/claude-3-opus")
        assert ok is True, f"Lifetime user blocked from {cmd}"


def test_enterprise_user_all_commands_allowed():
    """Enterprise user can use all commands."""
    user = _enterprise_user()
    ok, msg = check_tier(user, "swarm", "openai/gpt-4o")
    assert ok is True


# ---- check_tier: Free user ----


def test_free_user_chat_free_model_allowed():
    """Free user can chat with free models."""
    ok, msg = check_tier(_free_user(), "chat", "google/gemini-flash-1.5")
    assert ok is True


def test_free_user_chat_pro_model_blocked():
    """Free user cannot chat with pro models."""
    ok, msg = check_tier(_free_user(), "chat", "openai/gpt-4o")
    assert ok is False
    assert "Pro" in msg
    assert "gpt-4o" in msg


def test_free_user_multi_blocked():
    """Free user cannot use /multi."""
    ok, msg = check_tier(_free_user(), "multi")
    assert ok is False
    assert "Pro" in msg


def test_free_user_swarm_blocked():
    """Free user cannot use /swarm."""
    ok, msg = check_tier(_free_user(), "swarm")
    assert ok is False


def test_free_user_edit_blocked():
    """Free user cannot use /edit."""
    ok, msg = check_tier(_free_user(), "edit")
    assert ok is False


def test_free_user_benchmark_blocked():
    """Free user cannot use /benchmark."""
    ok, msg = check_tier(_free_user(), "benchmark")
    assert ok is False


def test_free_user_scan_allowed():
    """Free user can use local commands like scan."""
    ok, msg = check_tier(_free_user(), "scan")
    assert ok is True


def test_free_user_context_allowed():
    """Free user can use /context."""
    ok, msg = check_tier(_free_user(), "context")
    assert ok is True


def test_free_user_models_allowed():
    """Free user can list models."""
    ok, msg = check_tier(_free_user(), "models")
    assert ok is True


def test_free_user_projects_allowed():
    """Free user can manage projects."""
    ok, msg = check_tier(_free_user(), "projects")
    assert ok is True


def test_free_user_chat_no_model_allowed():
    """Free user can chat when no model is specified (default is free)."""
    ok, msg = check_tier(_free_user(), "chat", None)
    assert ok is True


def test_free_user_chat_ollama_model_allowed():
    """Free user can chat with Ollama models."""
    ok, msg = check_tier(_free_user(), "chat", "ollama/codellama")
    assert ok is True


# ---- check_tier: Guest user ----


def test_guest_user_chat_free_model():
    """Guest user can chat with free models."""
    ok, msg = check_tier(_guest_user(), "chat", "google/gemini-flash-1.5")
    assert ok is True


def test_guest_user_multi_blocked():
    """Guest user cannot use /multi."""
    ok, msg = check_tier(_guest_user(), "multi")
    assert ok is False


# ---- PRO_COMMANDS set ----


def test_pro_commands_contains_expected():
    """PRO_COMMANDS contains all expected pro-only commands."""
    assert PRO_COMMANDS == {"multi", "swarm", "edit", "benchmark"}


def test_chat_not_in_pro_commands():
    """Chat is not a pro command (gated by model, not command)."""
    assert "chat" not in PRO_COMMANDS


def test_scan_not_in_pro_commands():
    """Local commands are not in PRO_COMMANDS."""
    assert "scan" not in PRO_COMMANDS
    assert "context" not in PRO_COMMANDS


# ---- FREE_MODELS tuple ----


def test_free_models_tuple():
    """FREE_MODELS contains all expected free model hints."""
    assert "flash" in FREE_MODELS
    assert "haiku" in FREE_MODELS
    assert "mini" in FREE_MODELS
    assert "gemma" in FREE_MODELS
    assert "phi" in FREE_MODELS
    assert "llama" in FREE_MODELS
    assert "mistral" in FREE_MODELS
    assert "qwen" in FREE_MODELS


# ---- require_pro ----


def test_require_pro_allows_pro_user():
    """require_pro does not raise for pro user."""
    require_pro(_pro_user(), "multi", "openai/gpt-4o")  # Should not raise


def test_require_pro_blocks_free_user():
    """require_pro raises SystemExit for free user on pro command."""
    with pytest.raises(SystemExit):
        require_pro(_free_user(), "swarm")


def test_require_pro_blocks_free_model():
    """require_pro raises SystemExit for free user with pro model."""
    with pytest.raises(SystemExit):
        require_pro(_free_user(), "chat", "openai/gpt-4o")


# ---- require_auth ----


def test_require_auth_passes_with_token():
    """require_auth does not raise when token is provided."""
    require_auth("valid-token-123")  # Should not raise


def test_require_auth_blocks_no_token():
    """require_auth raises SystemExit(1) when token is None."""
    with pytest.raises(SystemExit) as exc:
        require_auth(None)
    assert exc.value.code == 1


def test_require_auth_blocks_empty_token():
    """require_auth raises SystemExit when token is empty string."""
    with pytest.raises(SystemExit):
        require_auth("")


# ---- Edge cases ----


def test_check_tier_is_pro_flag_overrides_tier():
    """is_pro=True in user dict overrides tier='free'."""
    user = {"tier": "free", "is_pro": True}
    ok, msg = check_tier(user, "multi")
    assert ok is True


def test_check_tier_message_includes_upgrade_url():
    """Blocked tier message includes upgrade URL."""
    ok, msg = check_tier(_free_user(), "multi")
    assert "msapling.com/pricing" in msg


def test_check_tier_message_includes_free_alternative():
    """Blocked model message suggests free model alternative."""
    ok, msg = check_tier(_free_user(), "chat", "openai/gpt-4o")
    assert "gemini-flash" in msg.lower() or "free tier" in msg.lower() or "Flash" in msg
