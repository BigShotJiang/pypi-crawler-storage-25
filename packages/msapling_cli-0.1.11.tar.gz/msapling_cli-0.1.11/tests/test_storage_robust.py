"""Robust tests for cli/msapling_cli/storage.py."""
from __future__ import annotations

import json
import threading
from pathlib import Path
from unittest.mock import patch

import pytest

from msapling_cli import storage as _storage_mod


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_storage(tmp_path: Path):
    """Return a patched storage module whose _ROOT points at tmp_path."""
    return tmp_path


# ---------------------------------------------------------------------------
# Test 1: save_settings / load_settings round-trip
# ---------------------------------------------------------------------------

def test_save_and_load_settings(tmp_path: Path):
    """Save a settings dict, reload it, verify every key-value matches."""
    with patch.object(_storage_mod, "_ROOT", tmp_path):
        settings_in = {
            "model": "google/gemini-2.0-flash-001",
            "effortLevel": "high",
            "permissions": {"allow": ["read_file", "glob_files"]},
            "custom_int": 42,
            "custom_bool": True,
        }
        _storage_mod.save_settings(settings_in)
        settings_out = _storage_mod.load_settings()

    assert settings_out["model"] == settings_in["model"]
    assert settings_out["effortLevel"] == settings_in["effortLevel"]
    assert settings_out["permissions"] == settings_in["permissions"]
    assert settings_out["custom_int"] == 42
    assert settings_out["custom_bool"] is True


# ---------------------------------------------------------------------------
# Test 2: atomic write — no temp file persists after save
# ---------------------------------------------------------------------------

def test_atomic_save_no_corruption(tmp_path: Path):
    """After save_settings completes, no .tmp file should remain."""
    with patch.object(_storage_mod, "_ROOT", tmp_path):
        _storage_mod.save_settings({"key": "value"})

    # No leftover temp files
    leftover_tmps = list(tmp_path.glob("*.tmp"))
    assert leftover_tmps == [], f"Leftover temp files: {leftover_tmps}"

    # The real settings file exists and is valid JSON
    settings_path = tmp_path / "settings.json"
    assert settings_path.exists()
    data = json.loads(settings_path.read_text(encoding="utf-8"))
    assert data["key"] == "value"


# ---------------------------------------------------------------------------
# Test 3: append_history / load_history
# ---------------------------------------------------------------------------

def test_append_history(tmp_path: Path):
    """append_history adds entries; load_history retrieves them in order."""
    with patch.object(_storage_mod, "_ROOT", tmp_path):
        _storage_mod.append_history("first prompt", "proj-a", "session-1")
        _storage_mod.append_history("second prompt", "proj-b", "session-2")
        entries = _storage_mod.load_history()

    assert len(entries) >= 2
    texts = [e["display"] for e in entries]
    assert "first prompt" in texts
    assert "second prompt" in texts
    # Verify field schema
    for entry in entries:
        assert "timestamp" in entry
        assert "project" in entry
        assert "sessionId" in entry


# ---------------------------------------------------------------------------
# Test 4: load_history respects the limit parameter
# ---------------------------------------------------------------------------

def test_history_max_length(tmp_path: Path):
    """load_history(limit=N) returns at most N entries (oldest trimmed)."""
    with patch.object(_storage_mod, "_ROOT", tmp_path):
        for i in range(20):
            _storage_mod.append_history(f"prompt {i}", "proj", f"session-{i}")

        all_entries = _storage_mod.load_history(limit=100)
        limited_entries = _storage_mod.load_history(limit=5)

    assert len(all_entries) == 20
    assert len(limited_entries) == 5
    # Limit should return the *most recent* N entries
    limited_displays = [e["display"] for e in limited_entries]
    assert "prompt 19" in limited_displays
    assert "prompt 0" not in limited_displays


# ---------------------------------------------------------------------------
# Test 5: concurrent save_settings — file must be valid JSON after both writes
# ---------------------------------------------------------------------------

def test_concurrent_save_no_race(tmp_path: Path):
    """Two threads calling save_settings concurrently; file stays valid JSON."""
    errors: list = []

    def _save(payload: dict):
        try:
            with patch.object(_storage_mod, "_ROOT", tmp_path):
                _storage_mod.save_settings(payload)
        except Exception as exc:
            errors.append(exc)

    t1 = threading.Thread(target=_save, args=({"thread": 1, "value": "alpha"},))
    t2 = threading.Thread(target=_save, args=({"thread": 2, "value": "beta"},))

    t1.start()
    t2.start()
    t1.join(timeout=5)
    t2.join(timeout=5)

    assert not errors, f"Exceptions during concurrent save: {errors}"

    settings_path = tmp_path / "settings.json"
    assert settings_path.exists()

    # File must be parseable — not corrupt
    raw = settings_path.read_text(encoding="utf-8")
    data = json.loads(raw)  # raises if corrupt

    # One of the two threads must have won
    assert data.get("thread") in (1, 2)
    assert data.get("value") in ("alpha", "beta")
