"""Guardrail tests for CLI instructions and provider commands.

Verifies that all expected commands, API client methods, and structural
conventions are present and correctly wired.  These are static / import-level
guardrails — no live server required.
"""
from __future__ import annotations

import ast
import importlib
import inspect
import sys
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, List

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

CLI_ROOT = Path(__file__).resolve().parent.parent / "msapling_cli"


def _load(name: str) -> ModuleType:
    """Import a CLI module by name, adding CLI_ROOT to sys.path if needed."""
    parent = str(CLI_ROOT.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    return importlib.import_module(f"msapling_cli.{name}")


def _source(name: str) -> str:
    return (CLI_ROOT / f"{name}.py").read_text(encoding="utf-8")


def _has_function(source: str, func_name: str) -> bool:
    """Return True if `source` defines a function named `func_name`."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return False
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == func_name:
                return True
    return False


def _typer_commands(app) -> List[str]:
    """Return all registered Typer sub-command names for `app`."""
    try:
        return [c.name or c.callback.__name__ for c in app.registered_commands]
    except Exception:
        return []


# ===========================================================================
# Feature 1 — instructions_commands.py
# ===========================================================================

class TestInstructionsFileExists:
    def test_file_exists(self):
        assert (CLI_ROOT / "instructions_commands.py").is_file(), (
            "instructions_commands.py must exist in cli/msapling_cli/"
        )


class TestInstructionsModule:
    @pytest.fixture(autouse=True)
    def load(self):
        self.mod = _load("instructions_commands")

    def test_has_instructions_app(self):
        assert hasattr(self.mod, "instructions_app"), (
            "instructions_commands must export `instructions_app` (typer.Typer)"
        )

    def test_instructions_app_is_typer(self):
        import typer
        assert isinstance(self.mod.instructions_app, typer.Typer), (
            "`instructions_app` must be a typer.Typer instance"
        )

    def test_get_command_registered(self):
        cmds = _typer_commands(self.mod.instructions_app)
        assert "get" in cmds, "instructions_app must have a 'get' command"

    def test_set_command_registered(self):
        cmds = _typer_commands(self.mod.instructions_app)
        assert "set" in cmds, "instructions_app must have a 'set' command"

    def test_clear_command_registered(self):
        cmds = _typer_commands(self.mod.instructions_app)
        assert "clear" in cmds, "instructions_app must have a 'clear' command"

    def test_global_endpoint_referenced(self):
        src = _source("instructions_commands")
        assert "/api/instructions/global" in src, (
            "instructions_commands must reference /api/instructions/global"
        )

    def test_project_endpoint_referenced(self):
        src = _source("instructions_commands")
        assert "/api/instructions/project/" in src, (
            "instructions_commands must reference /api/instructions/project/"
        )

    def test_set_accepts_text_arg(self):
        src = _source("instructions_commands")
        assert "typer.Argument" in src, (
            "instructions 'set' command must use typer.Argument for the text parameter"
        )

    def test_project_option_present(self):
        src = _source("instructions_commands")
        assert "--project" in src, (
            "instructions commands must support --project option"
        )

    def test_clear_confirmation_guard(self):
        src = _source("instructions_commands")
        # Must have some kind of guard (either Confirm or --yes/-y)
        assert "Confirm" in src or "--yes" in src or '"-y"' in src, (
            "instructions 'clear' must have a confirmation guard"
        )

    def test_no_raw_get_session(self):
        src = _source("instructions_commands")
        assert "get_async_session" not in src, (
            "instructions_commands must not use raw get_async_session"
        )


# ===========================================================================
# Feature 1 — provider_commands.py
# ===========================================================================

class TestProviderFileExists:
    def test_file_exists(self):
        assert (CLI_ROOT / "provider_commands.py").is_file(), (
            "provider_commands.py must exist in cli/msapling_cli/"
        )


class TestProviderModule:
    @pytest.fixture(autouse=True)
    def load(self):
        self.mod = _load("provider_commands")

    def test_has_providers_app(self):
        assert hasattr(self.mod, "providers_app"), (
            "provider_commands must export `providers_app` (typer.Typer)"
        )

    def test_providers_app_is_typer(self):
        import typer
        assert isinstance(self.mod.providers_app, typer.Typer), (
            "`providers_app` must be a typer.Typer instance"
        )

    def test_status_command_registered(self):
        cmds = _typer_commands(self.mod.providers_app)
        assert "status" in cmds, "providers_app must have a 'status' command"

    def test_reset_command_registered(self):
        cmds = _typer_commands(self.mod.providers_app)
        assert "reset" in cmds, "providers_app must have a 'reset' command"

    def test_status_uses_rich_table(self):
        src = _source("provider_commands")
        assert "Table" in src, (
            "provider_commands 'status' must render a Rich Table"
        )

    def test_state_columns_in_source(self):
        src = _source("provider_commands")
        assert "State" in src or "state" in src.lower(), (
            "provider_commands must display circuit state"
        )

    def test_failures_column_in_source(self):
        src = _source("provider_commands")
        assert "Failures" in src or "failures" in src.lower(), (
            "provider_commands must display failure counts"
        )

    def test_reset_confirmation_guard(self):
        src = _source("provider_commands")
        assert "Confirm" in src or "--yes" in src, (
            "providers 'reset' must have a confirmation guard"
        )

    def test_circuit_endpoint_referenced(self):
        src = _source("provider_commands")
        assert "circuit" in src.lower(), (
            "provider_commands must reference circuit breaker endpoints"
        )


# ===========================================================================
# Feature 1 — api.py additions
# ===========================================================================

class TestApiClientMethods:
    @pytest.fixture(autouse=True)
    def load(self):
        self.mod = _load("api")
        self.client_cls = self.mod.MSaplingClient

    def test_get_instructions_method_exists(self):
        assert hasattr(self.client_cls, "get_instructions"), (
            "MSaplingClient must have get_instructions() method"
        )

    def test_get_instructions_is_coroutine(self):
        method = getattr(self.client_cls, "get_instructions")
        assert inspect.iscoroutinefunction(method), (
            "get_instructions must be an async method"
        )

    def test_get_instructions_project_param(self):
        sig = inspect.signature(self.client_cls.get_instructions)
        assert "project" in sig.parameters, (
            "get_instructions must accept a 'project' parameter"
        )

    def test_set_instructions_method_exists(self):
        assert hasattr(self.client_cls, "set_instructions"), (
            "MSaplingClient must have set_instructions() method"
        )

    def test_set_instructions_is_coroutine(self):
        method = getattr(self.client_cls, "set_instructions")
        assert inspect.iscoroutinefunction(method), (
            "set_instructions must be an async method"
        )

    def test_set_instructions_text_param(self):
        sig = inspect.signature(self.client_cls.set_instructions)
        assert "text" in sig.parameters, (
            "set_instructions must accept a 'text' parameter"
        )

    def test_get_provider_circuit_summary_exists(self):
        assert hasattr(self.client_cls, "get_provider_circuit_summary"), (
            "MSaplingClient must have get_provider_circuit_summary() method"
        )

    def test_get_provider_circuit_summary_is_coroutine(self):
        method = getattr(self.client_cls, "get_provider_circuit_summary")
        assert inspect.iscoroutinefunction(method), (
            "get_provider_circuit_summary must be an async method"
        )

    def test_get_developer_dashboard_exists(self):
        assert hasattr(self.client_cls, "get_developer_dashboard"), (
            "MSaplingClient must have get_developer_dashboard() method"
        )

    def test_get_developer_dashboard_is_coroutine(self):
        method = getattr(self.client_cls, "get_developer_dashboard")
        assert inspect.iscoroutinefunction(method), (
            "get_developer_dashboard must be an async method"
        )


# ===========================================================================
# Feature 1 — main.py wiring
# ===========================================================================

class TestMainWiring:
    def test_instructions_app_registered(self):
        src = _source("main")
        assert "instructions_app" in src, (
            "main.py must import and register instructions_app"
        )

    def test_providers_app_registered(self):
        src = _source("main")
        assert "providers_app" in src, (
            "main.py must import and register providers_app"
        )

    def test_dev_app_registered(self):
        src = _source("main")
        assert "dev_app" in src, (
            "main.py must import and register dev_app"
        )

    def test_instructions_import_statement(self):
        src = _source("main")
        assert "instructions_commands" in src, (
            "main.py must import from instructions_commands"
        )

    def test_provider_import_statement(self):
        src = _source("main")
        assert "provider_commands" in src, (
            "main.py must import from provider_commands"
        )


# ===========================================================================
# Feature 1 — dev_commands.py
# ===========================================================================

class TestDevCommandsFile:
    def test_file_exists(self):
        assert (CLI_ROOT / "dev_commands.py").is_file(), (
            "dev_commands.py must exist in cli/msapling_cli/"
        )

    def test_dev_app_exported(self):
        mod = _load("dev_commands")
        assert hasattr(mod, "dev_app"), (
            "dev_commands must export `dev_app`"
        )

    def test_dashboard_command_registered(self):
        mod = _load("dev_commands")
        cmds = _typer_commands(mod.dev_app)
        assert "dashboard" in cmds, (
            "dev_app must have a 'dashboard' command"
        )

    def test_developer_dashboard_endpoint_referenced(self):
        src = _source("dev_commands")
        assert "developer/dashboard" in src or "get_developer_dashboard" in src, (
            "dev_commands must call the developer dashboard endpoint"
        )
