"""Guardrail tests for msapling cron mode (Task 1)."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_cron(tmp_path, monkeypatch):
    """Redirect CRON_FILE to a temp directory."""
    cron_file = tmp_path / ".msapling" / "cron.json"
    import msapling_cli.cron as cron_mod
    monkeypatch.setattr(cron_mod, "CRON_FILE", cron_file)
    return cron_file


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def cron_app():
    from msapling_cli.cron import cron_app as app
    return app


# ---------------------------------------------------------------------------
# Test 1: cron add stores job to cron.json
# ---------------------------------------------------------------------------

def test_cron_add_stores_to_file(runner, cron_app, tmp_cron):
    result = runner.invoke(cron_app, ["add", "test-job", "0 9 * * *", "Say hello"])
    assert result.exit_code == 0, result.output
    assert tmp_cron.exists(), "cron.json was not created"
    jobs = json.loads(tmp_cron.read_text())
    assert len(jobs) == 1
    assert jobs[0]["name"] == "test-job"


# ---------------------------------------------------------------------------
# Test 2: cron list shows jobs
# ---------------------------------------------------------------------------

def test_cron_list_shows_jobs(runner, cron_app, tmp_cron):
    # Seed cron file
    tmp_cron.parent.mkdir(parents=True, exist_ok=True)
    tmp_cron.write_text(json.dumps([
        {"name": "standup", "schedule": "0 9 * * 1-5", "prompt": "Daily standup",
         "project": None, "model": None, "created_at": "2026-01-01T09:00:00+00:00"}
    ]))
    result = runner.invoke(cron_app, ["list"])
    assert result.exit_code == 0, result.output
    assert "standup" in result.output


# ---------------------------------------------------------------------------
# Test 3: cron remove deletes job
# ---------------------------------------------------------------------------

def test_cron_remove_deletes_job(runner, cron_app, tmp_cron):
    tmp_cron.parent.mkdir(parents=True, exist_ok=True)
    tmp_cron.write_text(json.dumps([
        {"name": "old-job", "schedule": "0 0 * * *", "prompt": "Delete me",
         "project": None, "model": None, "created_at": "2026-01-01T00:00:00+00:00"}
    ]))
    result = runner.invoke(cron_app, ["remove", "old-job"])
    assert result.exit_code == 0, result.output
    remaining = json.loads(tmp_cron.read_text())
    assert len(remaining) == 0


# ---------------------------------------------------------------------------
# Test 4: Invalid cron expression rejected
# ---------------------------------------------------------------------------

def test_invalid_cron_expression_rejected(runner, cron_app, tmp_cron):
    result = runner.invoke(cron_app, ["add", "bad-job", "not-a-cron", "Some prompt"])
    # Should fail with non-zero exit or contain error message
    assert result.exit_code != 0 or "invalid" in result.output.lower() or "Invalid" in result.output


# ---------------------------------------------------------------------------
# Test 5: @daily shorthand is parsed correctly
# ---------------------------------------------------------------------------

def test_daily_shorthand_parsed(runner, cron_app, tmp_cron):
    from msapling_cli.cron import _resolve_schedule, SHORTHANDS
    resolved = _resolve_schedule("@daily")
    assert resolved == SHORTHANDS["@daily"]
    assert resolved == "0 0 * * *"


# ---------------------------------------------------------------------------
# Test 6: daemon command exists and is registered
# ---------------------------------------------------------------------------

def test_daemon_command_exists(cron_app):
    commands = [cmd.name for cmd in cron_app.registered_commands]
    assert "daemon" in commands, f"'daemon' not found in: {commands}"


# ---------------------------------------------------------------------------
# Test 7: install command exists and is registered
# ---------------------------------------------------------------------------

def test_install_command_exists(cron_app):
    commands = [cmd.name for cmd in cron_app.registered_commands]
    assert "install" in commands, f"'install' not found in: {commands}"


# ---------------------------------------------------------------------------
# Test 8: Cron JSON schema has required fields
# ---------------------------------------------------------------------------

def test_cron_json_schema_has_required_fields(runner, cron_app, tmp_cron):
    runner.invoke(cron_app, ["add", "schema-job", "@weekly", "Check schema"])
    assert tmp_cron.exists()
    jobs = json.loads(tmp_cron.read_text())
    assert jobs, "Expected at least one job"
    job = jobs[0]
    required_fields = {"name", "schedule", "prompt", "project", "model", "created_at"}
    missing = required_fields - set(job.keys())
    assert not missing, f"Missing required fields: {missing}"
