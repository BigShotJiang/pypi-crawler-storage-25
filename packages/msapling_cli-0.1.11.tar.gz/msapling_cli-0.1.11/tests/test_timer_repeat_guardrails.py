"""Guardrail tests for /timer and /repeat CLI commands.

Tests the scheduling / repeat infrastructure added to InteractiveShell
without requiring a live MSapling backend.

Coverage:
  1.  /timer command is registered in _handle_slash dispatch
  2.  /repeat command is registered in _handle_slash dispatch
  3.  Duration parser: 30s, 5m, 1h, 2h30m, bare integers
  4.  /timer list shows scheduled timers
  5.  /timer cancel cancels a specific timer
  6.  /timer clear empties all timers
  7.  /repeat --every parses the interval
  8.  /repeat --count limits repetitions
  9.  /repeat --until parses a wall-clock time
  10. /repeat stop cancels the active repeat
  11. Timer fires and executes the prompt
  12. Only one active repeat at a time
"""
from __future__ import annotations

import asyncio
import time
import types
import unittest
from unittest.mock import AsyncMock, MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers — build a minimal shell instance without touching the network
# ---------------------------------------------------------------------------

def _make_shell():
    """Return an InteractiveShell with all network/IO dependencies stubbed out."""
    from msapling_cli.shell import InteractiveShell

    with patch("msapling_cli.shell.get_settings") as mock_settings, \
         patch("msapling_cli.shell.detect_project_root") as mock_root, \
         patch("msapling_cli.shell.MSaplingClient") as mock_client, \
         patch("msapling_cli.shell._load_hooks", return_value={}):

        mock_settings.return_value = MagicMock(default_model="test-model")
        mock_root.return_value = ("/tmp", {"type": "unknown"})
        mock_client.return_value = MagicMock()

        shell = InteractiveShell.__new__(InteractiveShell)
        # Minimal attribute init that mirrors __init__ without side-effects
        shell.model = "test-model"
        shell.project_root = "/tmp"
        shell.project_info = {}
        shell.project_name = "test-project"
        shell.session_id = "test-session"
        shell.chat_id = None
        shell.messages = []
        shell._rewind_buffer = []
        shell.cost_total = 0.0
        shell.tokens_total = 0
        shell.plan_mode = False
        shell.vim_mode = False
        shell.fast_mode = False
        shell.effort = "high"
        shell.pending_attachments = []
        shell.hooks = {}
        shell.workers = []
        shell.subagents = []
        shell.cost_ceiling = None
        shell.agent_mode = True
        shell.client = MagicMock()
        shell.user = {}
        shell._completer = None
        shell._resume_id = None
        shell._mcp_manager = None
        shell._session_start_time = time.time()
        shell.models_used = []
        shell.files_touched = []
        shell.commands_run = []
        # Timer / repeat state
        shell._scheduled_timers = {}
        shell._timer_meta = {}
        shell._active_repeats = []
        shell.slash_commands_used = []
        return shell


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

class TestTimerRepeatRegistration(unittest.IsolatedAsyncioTestCase):
    """Tests 1-2: Commands must be recognised by _handle_slash."""

    def setUp(self):
        self.shell = _make_shell()

    async def test_timer_command_registered(self):
        """/timer is handled — _cmd_timer is called, not the 'unknown command' fallback."""
        calls = []

        async def fake_cmd_timer(args):
            calls.append(args)

        self.shell._cmd_timer = fake_cmd_timer
        await self.shell._handle_slash("/timer list")
        self.assertEqual(calls, ["list"])

    async def test_repeat_command_registered(self):
        """/repeat is handled — _cmd_repeat is called."""
        calls = []

        async def fake_cmd_repeat(args):
            calls.append(args)

        self.shell._cmd_repeat = fake_cmd_repeat
        await self.shell._handle_slash("/repeat stop")
        self.assertEqual(calls, ["stop"])


class TestDurationParser(unittest.TestCase):
    """Test 3: Duration parsing edge-cases."""

    def _p(self, s):
        from msapling_cli.shell import InteractiveShell
        return InteractiveShell._parse_duration(s)

    def test_seconds(self):
        self.assertAlmostEqual(self._p("30s"), 30.0)

    def test_minutes(self):
        self.assertAlmostEqual(self._p("5m"), 300.0)

    def test_hours(self):
        self.assertAlmostEqual(self._p("1h"), 3600.0)

    def test_hours_and_minutes(self):
        self.assertAlmostEqual(self._p("2h30m"), 9000.0)

    def test_bare_integer(self):
        self.assertAlmostEqual(self._p("90"), 90.0)

    def test_complex_hms(self):
        self.assertAlmostEqual(self._p("1h15m30s"), 4530.0)

    def test_invalid_returns_none(self):
        self.assertIsNone(self._p("abc"))
        self.assertIsNone(self._p(""))
        self.assertIsNone(self._p("1x"))


class TestTimerList(unittest.IsolatedAsyncioTestCase):
    """Test 4: /timer list shows pending timers."""

    async def test_timer_list_shows_entries(self):
        shell = _make_shell()
        printed = []

        # Pre-load a fake timer entry
        import asyncio as _aio

        async def _noop():
            await asyncio.sleep(9999)

        task = asyncio.create_task(_noop())
        tid = "abc12345"
        shell._scheduled_timers[tid] = task
        shell._timer_meta[tid] = {
            "prompt": "Check deployment",
            "delay": 1800.0,
            "fire_at": time.time() + 1800.0,
        }

        with patch("msapling_cli.shell.console") as mock_console:
            await shell._cmd_timer("list")
            # The table should have been printed
            mock_console.print.assert_called()

        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


class TestTimerCancel(unittest.IsolatedAsyncioTestCase):
    """Test 5: /timer cancel removes a specific timer."""

    async def test_cancel_removes_timer(self):
        shell = _make_shell()

        async def _noop():
            await asyncio.sleep(9999)

        task = asyncio.create_task(_noop())
        tid = "cancel01"
        shell._scheduled_timers[tid] = task
        shell._timer_meta[tid] = {
            "prompt": "Test prompt",
            "delay": 600.0,
            "fire_at": time.time() + 600.0,
        }

        with patch("msapling_cli.shell.console"):
            await shell._cmd_timer(f"cancel {tid}")

        # Give the event loop a tick so the cancellation propagates
        await asyncio.sleep(0)

        self.assertNotIn(tid, shell._scheduled_timers)
        self.assertNotIn(tid, shell._timer_meta)
        self.assertTrue(task.cancelled() or task.done())


class TestTimerClear(unittest.IsolatedAsyncioTestCase):
    """Test 6: /timer clear cancels ALL timers."""

    async def test_clear_empties_all_timers(self):
        shell = _make_shell()

        tasks = []
        for i in range(3):
            async def _noop():
                await asyncio.sleep(9999)

            task = asyncio.create_task(_noop())
            tid = f"t{i:04d}"
            shell._scheduled_timers[tid] = task
            shell._timer_meta[tid] = {
                "prompt": f"prompt{i}",
                "delay": 60.0,
                "fire_at": time.time() + 60.0,
            }
            tasks.append(task)

        with patch("msapling_cli.shell.console"):
            await shell._cmd_timer("clear")

        # Give the event loop a tick so cancellations propagate
        await asyncio.sleep(0)

        self.assertEqual(len(shell._scheduled_timers), 0)
        self.assertEqual(len(shell._timer_meta), 0)
        for task in tasks:
            self.assertTrue(task.cancelled() or task.done())


class TestRepeatEvery(unittest.IsolatedAsyncioTestCase):
    """Test 7: /repeat --every parses the interval correctly."""

    async def test_every_interval_parsed(self):
        shell = _make_shell()
        captured = {}

        async def fake_run_repeat(prompt, interval, max_count, until_ts):
            captured["interval"] = interval
            captured["prompt"] = prompt

        shell._run_repeat = fake_run_repeat

        with patch("msapling_cli.shell.console"), \
             patch("asyncio.create_task") as mock_create:
            # create_task should receive a coroutine; capture the args
            mock_create.side_effect = lambda coro: (asyncio.ensure_future(coro))
            await shell._cmd_repeat("'Check status' --every 5m")

        # Give event loop a tick to run the coroutine
        await asyncio.sleep(0)
        self.assertAlmostEqual(captured.get("interval", 0), 300.0, places=0)


class TestRepeatCount(unittest.IsolatedAsyncioTestCase):
    """Test 8: /repeat --count limits iterations."""

    async def test_repeat_count_10(self):
        shell = _make_shell()
        chat_calls = []

        async def fake_chat(prompt):
            chat_calls.append(prompt)

        shell._chat = fake_chat

        with patch("msapling_cli.shell.console"):
            task = asyncio.create_task(
                shell._run_repeat("ping", interval=0.01, max_count=3, until_ts=None)
            )
            await asyncio.wait_for(task, timeout=5.0)

        self.assertEqual(len(chat_calls), 3)


class TestRepeatUntilParsing(unittest.TestCase):
    """Test 9: --until time string is parsed to an epoch timestamp."""

    def _p(self, s):
        from msapling_cli.shell import InteractiveShell
        return InteractiveShell._parse_until_time(s)

    def test_5pm_returns_future_epoch(self):
        ts = self._p("5pm")
        self.assertIsNotNone(ts)
        # Must be in the future (or very soon past if run at exactly 5pm)
        self.assertGreater(ts, time.time() - 86400)

    def test_1700_returns_future_epoch(self):
        ts = self._p("17:00")
        self.assertIsNotNone(ts)
        self.assertIsInstance(ts, float)

    def test_530pm_returns_future_epoch(self):
        ts = self._p("5:30pm")
        self.assertIsNotNone(ts)

    def test_invalid_returns_none(self):
        self.assertIsNone(self._p("not-a-time"))
        self.assertIsNone(self._p(""))
        self.assertIsNone(self._p("25:00"))


class TestRepeatStop(unittest.IsolatedAsyncioTestCase):
    """Test 10: /repeat stop cancels the active repeat."""

    async def test_stop_cancels_active_repeat(self):
        shell = _make_shell()

        async def _long():
            await asyncio.sleep(9999)

        task = asyncio.create_task(_long())
        shell._active_repeats.append(task)

        with patch("msapling_cli.shell.console"):
            await shell._cmd_repeat("stop")

        # Give the event loop a tick so cancellations propagate
        await asyncio.sleep(0)

        self.assertEqual(len(shell._active_repeats), 0)
        self.assertTrue(task.cancelled() or task.done())


class TestTimerFires(unittest.IsolatedAsyncioTestCase):
    """Test 11: Timer actually fires and executes the prompt."""

    async def test_timer_fires_execute_prompt(self):
        shell = _make_shell()
        executed = []

        async def fake_chat(p):
            executed.append(p)

        shell._chat = fake_chat

        with patch("msapling_cli.shell.console"):
            # Use a very short delay (0.05s) to keep test fast
            await shell._cmd_timer("0.05s 'My auto prompt'")

        # Wait for timer to fire
        await asyncio.sleep(0.2)

        self.assertIn("My auto prompt", executed)


class TestRepeatOnlyOne(unittest.IsolatedAsyncioTestCase):
    """Test 12: Only one active repeat at a time."""

    async def test_second_repeat_blocked(self):
        shell = _make_shell()
        printed_messages = []

        async def _long():
            await asyncio.sleep(9999)

        task = asyncio.create_task(_long())
        shell._active_repeats.append(task)

        with patch("msapling_cli.shell.console") as mock_console:
            mock_console.print.side_effect = lambda msg, **kw: printed_messages.append(str(msg))
            await shell._cmd_repeat("'Second prompt' --every 1m --count 1")

        # Should warn the user
        self.assertTrue(
            any("already running" in m.lower() or "repeat" in m.lower() for m in printed_messages),
            f"Expected 'already running' warning. Got: {printed_messages}",
        )
        # Task count must remain 1
        live = [t for t in shell._active_repeats if not t.done()]
        self.assertEqual(len(live), 1)

        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


if __name__ == "__main__":
    unittest.main()
