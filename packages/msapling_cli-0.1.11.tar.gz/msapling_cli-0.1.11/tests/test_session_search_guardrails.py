"""Guardrail tests for msapling_cli/session_search.py — BM25 full-text search.

20 tests covering:
- Empty index returns no results
- Single document, query matches -> score > 0
- Non-matching query -> empty results
- BM25 ranks more-relevant doc higher than less-relevant
- IDF boosts rare terms over common ones
- Index cache hit (mtime check)
- Search snippet contains matched term
- Top-k limits results
- Query tokenization lowercases and splits correctly
- Search across title + content
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import List

import pytest

from msapling_cli.session_search import (
    BM25Index,
    SearchResult,
    _tokenize,
    _parse_session_file,
    build_default_index,
    _CACHE_FILE,
    _SESSION_DIR,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_session(dir_: Path, session_id: str, messages: list, metadata: dict = None) -> Path:
    """Write a minimal session JSON file compatible with session_search parser."""
    data = {
        "_schema_version": 2,
        "id": session_id,
        "model": "google/gemini-flash",
        "messages": messages,
        "metadata": metadata or {},
    }
    path = dir_ / f"{session_id}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def _build_index_from_dir(session_dir: Path, monkeypatch, tmp_path) -> BM25Index:
    """Build a fresh BM25Index from *session_dir*, bypassing cache."""
    cache_file = tmp_path / "search_index.json"
    monkeypatch.setattr("msapling_cli.session_search._CACHE_FILE", cache_file)
    monkeypatch.setattr("msapling_cli.session_search._SESSION_DIR", session_dir)
    files = list(session_dir.glob("*.json"))
    return BM25Index.index_sessions(files)


# ---------------------------------------------------------------------------
# 1. Empty index returns no results
# ---------------------------------------------------------------------------

def test_empty_index_returns_no_results():
    idx = BM25Index()
    results = idx.search("anything")
    assert results == []


def test_empty_query_returns_no_results(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [{"role": "user", "content": "hello"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    assert idx.search("") == []
    assert idx.search("   ") == []


# ---------------------------------------------------------------------------
# 2. Single document, query matches -> score > 0
# ---------------------------------------------------------------------------

def test_single_doc_matching_query_positive_score(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [{"role": "user", "content": "async fastapi endpoint"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("fastapi")
    assert len(results) == 1
    assert results[0].score > 0.0


def test_single_doc_score_type_is_float(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [{"role": "user", "content": "billing invoice CAD"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("billing")
    assert isinstance(results[0].score, float)


# ---------------------------------------------------------------------------
# 3. Non-matching query -> empty results
# ---------------------------------------------------------------------------

def test_non_matching_query_empty_results(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [{"role": "user", "content": "database schema migration"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("zyxwvutsrqponmlkjihgfedcba")
    assert results == []


# ---------------------------------------------------------------------------
# 4. BM25 ranks more-relevant doc higher than less-relevant
# ---------------------------------------------------------------------------

def test_more_relevant_doc_ranked_higher(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    # High-relevance: mentions "docker" many times
    _write_session(session_dir, "high", [
        {"role": "user", "content": "docker docker docker container docker compose"},
    ])
    # Low-relevance: mentions "docker" once among many other words
    _write_session(session_dir, "low", [
        {"role": "user", "content": "kubernetes helm nginx redis postgres docker grafana"},
    ])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("docker", top_k=10)
    assert len(results) == 2
    ids = [r.session_id for r in results]
    assert ids[0] == "high", f"Expected 'high' ranked first, got order {ids}"


# ---------------------------------------------------------------------------
# 5. IDF boosts rare terms over common ones
# ---------------------------------------------------------------------------

def test_idf_boosts_rare_term(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    # common_term "api" appears in all 5 sessions; rare_term "xyzzy" in only one
    for i in range(4):
        _write_session(session_dir, f"common_{i}", [
            {"role": "user", "content": "api endpoint api call"},
        ])
    _write_session(session_dir, "rare_doc", [
        {"role": "user", "content": "api xyzzy unique term"},
    ])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)

    results_rare = idx.search("xyzzy")
    results_common = idx.search("api")

    # xyzzy should have a higher score for rare_doc than common term "api" for same doc
    rare_doc_rare_score = next((r.score for r in results_rare if r.session_id == "rare_doc"), 0.0)
    rare_doc_api_score = next((r.score for r in results_common if r.session_id == "rare_doc"), 0.0)
    assert rare_doc_rare_score > rare_doc_api_score, (
        f"Rare term score {rare_doc_rare_score} should exceed common term score {rare_doc_api_score}"
    )


# ---------------------------------------------------------------------------
# 6. Index cache hit (mtime check)
# ---------------------------------------------------------------------------

def test_cache_is_used_when_files_not_newer(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    cache_file = tmp_path / "search_index.json"
    monkeypatch.setattr("msapling_cli.session_search._CACHE_FILE", cache_file)
    monkeypatch.setattr("msapling_cli.session_search._SESSION_DIR", session_dir)

    path = _write_session(session_dir, "s001", [{"role": "user", "content": "cache test content"}])
    files = [path]

    # First build — writes cache
    idx1 = BM25Index.index_sessions(files)
    assert cache_file.exists(), "Cache file should be written after first build"

    # Ensure cache mtime > file mtime
    cache_mtime = cache_file.stat().st_mtime
    assert cache_mtime > 0

    # Second build — should hit cache (no need to re-parse files)
    idx2 = BM25Index.index_sessions(files)
    assert len(idx2._docs) == len(idx1._docs), "Cache should restore the same docs"


def test_cache_rebuilt_when_file_is_newer(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    cache_file = tmp_path / "search_index_new.json"
    monkeypatch.setattr("msapling_cli.session_search._CACHE_FILE", cache_file)
    monkeypatch.setattr("msapling_cli.session_search._SESSION_DIR", session_dir)

    # Write session file FIRST with new content
    path = _write_session(session_dir, "s001", [{"role": "user", "content": "updated xyzzy content"}])

    # Backdate the cache file mtime to well before the session file
    old_cache = {
        "built_at": 0.0,
        "avg_dl": 5.0,
        "df": {},
        "docs": [],  # empty — so any search result proves it was rebuilt
    }
    cache_file.write_text(json.dumps(old_cache), encoding="utf-8")
    # Set cache mtime to epoch (clearly older than session file)
    os.utime(str(cache_file), (0, 0))

    # Build — should detect session file mtime > cache mtime and rebuild
    idx2 = BM25Index.index_sessions([path])
    results = idx2.search("xyzzy")
    assert len(results) == 1, "Rebuilt index should reflect updated file content"


# ---------------------------------------------------------------------------
# 7. Search snippet contains matched term
# ---------------------------------------------------------------------------

def test_snippet_contains_matched_term(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [
        {"role": "user", "content": "the quick brown fox jumped over the lazy dog"},
    ])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("fox")
    assert results, "Expected at least one result"
    assert "fox" in results[0].matched_snippet.lower(), (
        f"Snippet should contain 'fox': {results[0].matched_snippet}"
    )


# ---------------------------------------------------------------------------
# 8. Top-k limits results
# ---------------------------------------------------------------------------

def test_top_k_limits_results(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    # 10 sessions all containing "python"
    for i in range(10):
        _write_session(session_dir, f"s{i:03d}", [
            {"role": "user", "content": f"python code session number {i}"},
        ])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)

    results_5 = idx.search("python", top_k=5)
    results_3 = idx.search("python", top_k=3)
    assert len(results_5) <= 5
    assert len(results_3) <= 3


# ---------------------------------------------------------------------------
# 9. Query tokenization lowercases and splits correctly
# ---------------------------------------------------------------------------

def test_tokenize_lowercases():
    tokens = _tokenize("Hello WORLD")
    assert tokens == ["hello", "world"]


def test_tokenize_splits_on_punctuation():
    tokens = _tokenize("foo.bar,baz;qux")
    assert "foo" in tokens
    assert "bar" in tokens
    assert "baz" in tokens
    assert "qux" in tokens


def test_tokenize_handles_empty_string():
    assert _tokenize("") == []


def test_tokenize_handles_numbers():
    tokens = _tokenize("Python 3.11 rocks")
    assert "python" in tokens
    assert "3" in tokens
    assert "11" in tokens
    assert "rocks" in tokens


# ---------------------------------------------------------------------------
# 10. Search across title + content
# ---------------------------------------------------------------------------

def test_search_matches_in_summary_title(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(
        session_dir, "s001",
        messages=[{"role": "user", "content": "unrelated content here"}],
        metadata={"summary": "BillingInvoiceProcessor refactor"},
    )
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("billinginvoiceprocessor")
    assert len(results) == 1, "Should find document via summary/title field"


def test_search_matches_project_name(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(
        session_dir, "s002",
        messages=[{"role": "user", "content": "some chat content"}],
        metadata={"project_name": "MSapling-billing"},
    )
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("msapling")
    assert any(r.session_id == "s002" for r in results), "Should find via project_name"


def test_search_matches_models_used(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(
        session_dir, "s003",
        messages=[{"role": "user", "content": "nothing special"}],
        metadata={"models_used": ["anthropic/claude-opus-4-5"]},
    )
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("claude")
    assert any(r.session_id == "s003" for r in results), "Should find via models_used"


# ---------------------------------------------------------------------------
# SearchResult shape validation
# ---------------------------------------------------------------------------

def test_search_result_fields_present(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "s001", [{"role": "user", "content": "websocket stream reconnect"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("websocket")
    assert results
    r = results[0]
    assert hasattr(r, "session_id")
    assert hasattr(r, "title")
    assert hasattr(r, "project")
    assert hasattr(r, "score")
    assert hasattr(r, "matched_snippet")
    assert isinstance(r, SearchResult)


# ---------------------------------------------------------------------------
# 11. Multiple sessions — only matching ones returned
# ---------------------------------------------------------------------------

def test_only_matching_sessions_returned(tmp_path, monkeypatch):
    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    _write_session(session_dir, "match", [{"role": "user", "content": "kubernetes deployment helm chart"}])
    _write_session(session_dir, "nomatch", [{"role": "user", "content": "breakfast pancakes syrup maple"}])
    idx = _build_index_from_dir(session_dir, monkeypatch, tmp_path)
    results = idx.search("kubernetes")
    ids = [r.session_id for r in results]
    assert "match" in ids
    assert "nomatch" not in ids
