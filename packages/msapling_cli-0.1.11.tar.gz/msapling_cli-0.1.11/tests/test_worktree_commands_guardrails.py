"""Guardrail tests for the Parallel Git Worktree feature (worktree_commands.py).

Run with:
    python -m pytest cli/tests/test_worktree_commands_guardrails.py -q
"""
from __future__ import annotations

import importlib
import importlib.util
import inspect
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import List
from unittest.mock import MagicMock, patch, call

import pytest

# ── Helpers ───────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_MODULE_PATH = _PKG_DIR / "worktree_commands.py"


def _import_wt():
    """Import worktree_commands.py without triggering CLI side effects."""
    spec = importlib.util.spec_from_file_location(
        "msapling_cli.worktree_commands", str(_MODULE_PATH)
    )
    mod = importlib.util.module_from_spec(spec)
    # Stub tui dependency so import doesn't need the full package
    fake_tui = MagicMock()
    fake_tui.console = MagicMock()
    sys.modules.setdefault("msapling_cli.tui", fake_tui)
    spec.loader.exec_module(mod)
    return mod


# ── Test 1: Module exists ─────────────────────────────────────────────────────

def test_worktree_module_exists():
    """worktree_commands.py must exist in the msapling_cli package."""
    assert _MODULE_PATH.exists(), f"Expected {_MODULE_PATH} to exist"


# ── Test 2: Module imports cleanly ────────────────────────────────────────────

def test_worktree_module_imports():
    """worktree_commands.py must import without raising."""
    mod = _import_wt()
    assert mod is not None


# ── Test 3: worktree_app typer is defined ─────────────────────────────────────

def test_worktree_app_typer_defined():
    """worktree_commands.py must expose a `worktree_app` Typer instance."""
    mod = _import_wt()
    import typer
    assert hasattr(mod, "worktree_app"), "worktree_app must be defined"
    assert isinstance(mod.worktree_app, typer.Typer)


# ── Test 4: worktree create calls git worktree add ────────────────────────────

def test_worktree_create_calls_git_worktree_add(tmp_path, monkeypatch):
    """worktree create must invoke `git worktree add --track -b <branch> <path> <base>`."""
    mod = _import_wt()
    monkeypatch.chdir(tmp_path)

    called_cmds: list = []

    def _fake_run(cmd, **kwargs):
        called_cmds.append(cmd)
        result = MagicMock()
        result.returncode = 0
        result.stdout = str(tmp_path) + "\n"
        result.stderr = ""
        return result

    with patch("subprocess.run", side_effect=_fake_run):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod, "_require_git_repo"):
                with patch.object(mod, "_save_state"):
                    import typer
                    with pytest.raises((SystemExit, typer.Exit), match="0") if False else \
                         patch.object(mod._console, "print"):
                        try:
                            mod.worktree_create(
                                branch="feature/test",
                                base="main",
                                path=str(tmp_path / "wt"),
                            )
                        except SystemExit:
                            pass

    # Find the git worktree add call
    wt_add_calls = [c for c in called_cmds if "worktree" in c and "add" in c]
    assert len(wt_add_calls) >= 1, "Expected git worktree add to be called"
    wt_cmd = wt_add_calls[0]
    assert "--track" in wt_cmd, "Expected --track flag"
    assert "-b" in wt_cmd, "Expected -b flag"
    assert "feature/test" in wt_cmd, "Expected branch name in command"


# ── Test 5: worktree list shows branch/path/HEAD ──────────────────────────────

def test_worktree_list_shows_branch_path_head():
    """worktree list must call _git_worktree_list_raw and render a table."""
    mod = _import_wt()

    fake_worktrees = [
        {"path": "/repo/main", "HEAD": "abc1234567890", "branch": "main", "bare": False, "detached": False},
        {"path": "/repo/feature-x", "HEAD": "def4567890123", "branch": "feature/x", "bare": False, "detached": False},
    ]

    printed_tables: list = []

    def _fake_print(obj, *args, **kwargs):
        printed_tables.append(str(obj))

    with patch.object(mod, "_git_worktree_list_raw", return_value=fake_worktrees):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod, "_require_git_repo"):
                with patch.object(mod, "_git_is_dirty", return_value=False):
                    with patch.object(mod, "_load_state", return_value={}):
                        with patch.object(mod._console, "print", side_effect=_fake_print):
                            mod.worktree_list()

    # At least one table should have been rendered (rich Table object)
    assert len(printed_tables) >= 1, "Expected table to be printed"


# ── Test 6: worktree remove calls git worktree remove ────────────────────────

def test_worktree_remove_calls_git_worktree_remove(tmp_path):
    """worktree remove must invoke `git worktree remove <path>`."""
    mod = _import_wt()

    called_cmds: list = []

    def _fake_run(cmd, **kwargs):
        called_cmds.append(list(cmd))
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        return result

    fake_worktrees = [
        {"path": str(tmp_path / "wt"), "HEAD": "abc123", "branch": "feature/test"}
    ]

    with patch("subprocess.run", side_effect=_fake_run):
        with patch.object(mod, "_git_worktree_list_raw", return_value=fake_worktrees):
            with patch.object(mod, "_require_git", return_value="git"):
                with patch.object(mod, "_require_git_repo"):
                    with patch.object(mod, "_is_session_active", return_value=False):
                        with patch.object(mod, "_state_file", return_value=tmp_path / "state.json"):
                            with patch.object(mod._console, "print"):
                                mod.worktree_remove(branch="feature/test", force=False)

    remove_calls = [c for c in called_cmds if "worktree" in c and "remove" in c]
    assert len(remove_calls) >= 1, "Expected git worktree remove to be called"


# ── Test 7: --force bypasses session-active guard ────────────────────────────

def test_worktree_remove_force_bypasses_session_guard(tmp_path):
    """worktree remove --force must proceed even when session is active."""
    mod = _import_wt()

    remove_called = []

    def _fake_run(cmd, **kwargs):
        remove_called.append(list(cmd))
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""
        result.stderr = ""
        return result

    fake_worktrees = [
        {"path": str(tmp_path / "wt"), "HEAD": "abc123", "branch": "feature/active"}
    ]

    with patch("subprocess.run", side_effect=_fake_run):
        with patch.object(mod, "_git_worktree_list_raw", return_value=fake_worktrees):
            with patch.object(mod, "_require_git", return_value="git"):
                with patch.object(mod, "_require_git_repo"):
                    with patch.object(mod, "_is_session_active", return_value=True):
                        with patch.object(mod, "_state_file", return_value=tmp_path / "state.json"):
                            with patch.object(mod._console, "print"):
                                # With force=True, should NOT raise or exit
                                mod.worktree_remove(branch="feature/active", force=True)

    remove_calls = [c for c in remove_called if "worktree" in c and "remove" in c]
    assert len(remove_calls) >= 1, "git worktree remove must still be called with --force"


# ── Test 8: worktree remove refuses when session active (no force) ────────────

def test_worktree_remove_refuses_when_session_active(tmp_path):
    """worktree remove without --force must abort when a session is active."""
    import typer as _typer
    mod = _import_wt()

    fake_worktrees = [
        {"path": str(tmp_path / "wt"), "HEAD": "abc123", "branch": "feature/active"}
    ]

    with patch.object(mod, "_git_worktree_list_raw", return_value=fake_worktrees):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod, "_require_git_repo"):
                with patch.object(mod, "_is_session_active", return_value=True):
                    with patch.object(mod._console, "print"):
                        with pytest.raises((_typer.Exit, SystemExit)):
                            mod.worktree_remove(branch="feature/active", force=False)


# ── Test 9: worktree status shows MSapling session state ─────────────────────

def test_worktree_status_shows_session_state():
    """worktree status must display MSapling session state for each worktree."""
    mod = _import_wt()

    fake_worktrees = [
        {"path": "/repo/main", "HEAD": "abc123456789", "branch": "main", "detached": False},
    ]
    fake_state = {"session_active": True, "created_at": "2026-04-17T10:00:00+00:00", "base": "main"}

    printed_lines: list = []

    def _fake_print(*args, **kwargs):
        printed_lines.append(" ".join(str(a) for a in args))

    with patch.object(mod, "_git_worktree_list_raw", return_value=fake_worktrees):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod, "_require_git_repo"):
                with patch.object(mod, "_git_is_dirty", return_value=False):
                    with patch.object(mod, "_load_state", return_value=fake_state):
                        with patch.object(mod._console, "print", side_effect=_fake_print):
                            mod.worktree_status()

    combined = " ".join(printed_lines)
    assert "ACTIVE" in combined or "active" in combined.lower(), \
        "Expected session state 'ACTIVE' in status output"


# ── Test 10: branch name validated — no spaces allowed ────────────────────────

def test_branch_name_rejects_spaces():
    """_validate_branch_name must raise BadParameter on branch names with spaces."""
    import typer
    mod = _import_wt()

    with pytest.raises(typer.BadParameter):
        mod._validate_branch_name("feature branch with spaces")


# ── Test 11: branch name validated — special chars rejected ──────────────────

def test_branch_name_rejects_special_chars():
    """_validate_branch_name must reject shell-unsafe characters."""
    import typer
    mod = _import_wt()

    for bad_name in ("feat;drop", "feat$(evil)", "feat&bad", "feat|pipe"):
        with pytest.raises(typer.BadParameter, match="Invalid branch name"):
            mod._validate_branch_name(bad_name)


# ── Test 12: valid branch names accepted ─────────────────────────────────────

def test_branch_name_accepts_valid_names():
    """_validate_branch_name must accept standard git branch name formats."""
    mod = _import_wt()

    valid_names = [
        "main", "develop", "feature/my-task", "fix/bug-42",
        "release/v2.0.0", "hotfix/critical_patch", "feat.new-thing",
    ]
    for name in valid_names:
        # Must not raise
        mod._validate_branch_name(name)


# ── Test 13: git not found → clear error ──────────────────────────────────────

def test_require_git_aborts_when_git_not_found():
    """_require_git must print a clear error and exit when git is not on PATH."""
    import typer
    mod = _import_wt()

    with patch("shutil.which", return_value=None):
        with patch.object(mod._console, "print"):
            with pytest.raises((typer.Exit, SystemExit)):
                mod._require_git()


# ── Test 14: not a git repo → clear error ────────────────────────────────────

def test_require_git_repo_aborts_outside_git(tmp_path):
    """_require_git_repo must abort with a clear error when cwd is not a git repo."""
    import typer
    mod = _import_wt()

    fake_result = MagicMock()
    fake_result.returncode = 128
    fake_result.stdout = ""
    fake_result.stderr = "not a git repository"

    with patch("subprocess.run", return_value=fake_result):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod._console, "print"):
                with pytest.raises((typer.Exit, SystemExit)):
                    mod._require_git_repo(str(tmp_path))


# ── Test 15: created worktree path written to session state ──────────────────

def test_create_writes_state(tmp_path):
    """worktree create must persist the worktree path to session state."""
    mod = _import_wt()

    saved_states: list = []

    def _fake_run(cmd, **kwargs):
        r = MagicMock()
        r.returncode = 0
        r.stdout = str(tmp_path) + "\n"
        r.stderr = ""
        return r

    def _fake_save_state(path, state):
        saved_states.append((path, state))

    with patch("subprocess.run", side_effect=_fake_run):
        with patch.object(mod, "_require_git", return_value="git"):
            with patch.object(mod, "_require_git_repo"):
                with patch.object(mod, "_save_state", side_effect=_fake_save_state):
                    with patch.object(mod._console, "print"):
                        wt_path = str(tmp_path / "new-wt")
                        mod.worktree_create(
                            branch="feature/state-test",
                            base="main",
                            path=wt_path,
                        )

    assert len(saved_states) >= 1, "Expected _save_state to be called once"
    _path, state = saved_states[0]
    assert state.get("branch") == "feature/state-test"
    assert state.get("worktree_path") == wt_path or state.get("worktree_path") is None  # path may be resolved


# ── Test 16: worktree app registered in main.py ──────────────────────────────

def test_worktree_app_registered_in_main():
    """worktree_app must be added to the CLI app in main.py."""
    main_path = _PKG_DIR / "main.py"
    source = main_path.read_text(encoding="utf-8")
    assert "worktree_app" in source, "worktree_app must be referenced in main.py"
    assert 'app.add_typer(worktree_app, name="worktree")' in source, \
        "worktree_app must be registered with app.add_typer"


# ── Test 17: --cwd flag exists on chat command ────────────────────────────────

def test_chat_cwd_flag_defined_in_main():
    """The --cwd flag must be defined on the chat command in main.py."""
    main_path = _PKG_DIR / "main.py"
    source = main_path.read_text(encoding="utf-8")
    assert '"--cwd"' in source or "'--cwd'" in source, \
        "--cwd option must be defined in the chat command"


# ── Test 18: mark_session_active updates state ────────────────────────────────

def test_mark_session_active_updates_state(tmp_path):
    """mark_session_active must persist session_active=True/False in state."""
    mod = _import_wt()

    states: list = []

    def _fake_load(path):
        return {}

    def _fake_save(path, state):
        states.append((path, dict(state)))

    with patch.object(mod, "_load_state", side_effect=_fake_load):
        with patch.object(mod, "_save_state", side_effect=_fake_save):
            mod.mark_session_active(str(tmp_path / "wt"), active=True)

    assert len(states) == 1, "Expected _save_state called once"
    saved_state = states[0][1]
    assert saved_state["session_active"] is True, "session_active must be True"

    states.clear()
    with patch.object(mod, "_load_state", side_effect=_fake_load):
        with patch.object(mod, "_save_state", side_effect=_fake_save):
            mod.mark_session_active(str(tmp_path / "wt"), active=False)

    assert states[0][1]["session_active"] is False, "session_active must be set to False"
