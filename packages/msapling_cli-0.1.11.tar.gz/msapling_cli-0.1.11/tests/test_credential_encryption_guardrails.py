"""Guardrail tests for CLI credential encryption (config.py).

Verifies:
- Keyring save/load round-trip
- Fernet-encrypted fallback when keyring unavailable
- Legacy plaintext token auto-migration
- delete_token / clear_token removes all stores
- Machine key stability and uniqueness
- .keyfile permissions
- Encrypted file is not plaintext
- None returned when no token exists
- Corrupted enc file handled gracefully
- is_keyring_available probe logic
- Token rotation, concurrent idempotency, cross-platform naming
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _TmpHome:
    """Context manager: patches _CONFIG_DIR, _TOKEN_FILE, _TOKEN_ENC_FILE,
    _KEYFILE to a fresh temp directory so tests are hermetically isolated."""

    def __enter__(self) -> Path:
        self._dir = Path(tempfile.mkdtemp(prefix="ms_enc_test_"))
        config_dir = self._dir / ".msapling"
        config_dir.mkdir(parents=True, exist_ok=True)
        self._patches = [
            patch("msapling_cli.config._CONFIG_DIR", config_dir),
            patch("msapling_cli.config._TOKEN_FILE", config_dir / "token"),
            patch("msapling_cli.config._TOKEN_ENC_FILE", config_dir / "token.enc"),
            patch("msapling_cli.config._KEYFILE", config_dir / ".keyfile"),
        ]
        for p in self._patches:
            p.start()
        return config_dir

    def __exit__(self, *_):
        for p in self._patches:
            p.stop()
        shutil.rmtree(self._dir, ignore_errors=True)


def _mock_keyring_store():
    """Return (mock_keyring, backing_dict) — a fully functional in-memory keyring mock."""
    store: dict = {}
    kb = MagicMock()
    kb.set_password.side_effect = lambda svc, user, val: store.update({(svc, user): val})
    kb.get_password.side_effect = lambda svc, user: store.get((svc, user))
    kb.delete_password.side_effect = lambda svc, user: store.pop((svc, user), None)
    return kb, store


def _no_keyring():
    """Patch that disables keyring entirely (returns None from _get_keyring_backend)."""
    return patch("msapling_cli.config._get_keyring_backend", return_value=None)


# ---------------------------------------------------------------------------
# 1. Keyring save/load round-trip
# ---------------------------------------------------------------------------

def test_save_and_load_token_keyring():
    """save_token stores in keyring; get_token retrieves from keyring."""
    kb, store = _mock_keyring_store()
    with _TmpHome() as cfg:
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token, get_token
            save_token("jwt-keyring-abc123")
            kb.set_password.assert_called_once()
            result = get_token()
    assert result == "jwt-keyring-abc123"


# ---------------------------------------------------------------------------
# 2. Keyring failure falls back to encrypted file
# ---------------------------------------------------------------------------

def test_keyring_failure_falls_back_to_encrypted_file():
    """When keyring.set_password raises, token is Fernet-encrypted to token.enc."""
    kb = MagicMock()
    kb.set_password.side_effect = Exception("no keyring backend")
    kb.get_password.return_value = None  # explicit None to prevent MagicMock truthy
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token, get_token
            save_token("fallback-secret-999")
            assert enc_file.exists(), "token.enc must be created on keyring failure"
            result = get_token()
            assert result == "fallback-secret-999"


def test_keyring_get_failure_falls_back_to_encrypted_file():
    """When keyring.get_password raises, get_token falls back to enc file."""
    kb = MagicMock()
    kb.get_password.side_effect = Exception("keyring read broken")
    with _TmpHome() as cfg:
        # Pre-populate enc file using no-keyring path
        with _no_keyring():
            from msapling_cli.config import save_token
            save_token("enc-only-token")
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import get_token
            result = get_token()
    assert result == "enc-only-token"


# ---------------------------------------------------------------------------
# 3. Legacy plaintext migration
# ---------------------------------------------------------------------------

def test_legacy_plaintext_migrated_on_load():
    """If legacy plaintext 'token' file exists, load_token migrates and deletes it."""
    with _TmpHome() as cfg:
        plaintext_file = cfg / "token"
        enc_file = cfg / "token.enc"
        plaintext_file.write_text("legacy-plain-token\n", encoding="utf-8")
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import load_token
            result = load_token()
            # Assertions must be inside the _TmpHome context while the temp dir still exists.
            assert result == "legacy-plain-token"
            assert not plaintext_file.exists(), "plaintext file must be deleted after migration"
            assert enc_file.exists(), "encrypted file must be created after migration"


def test_legacy_migration_does_not_run_twice():
    """After migration, calling load_token again still returns the token."""
    with _TmpHome() as cfg:
        plaintext_file = cfg / "token"
        plaintext_file.write_text("once-migrated", encoding="utf-8")
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import load_token
            first = load_token()
            second = load_token()  # plaintext file gone; reads from enc file
            assert first == "once-migrated"
            assert second == "once-migrated"


def test_save_token_removes_legacy_plaintext_immediately():
    """Calling save_token deletes any residual plaintext token file."""
    with _TmpHome() as cfg:
        plaintext_file = cfg / "token"
        plaintext_file.write_text("old-plaintext", encoding="utf-8")
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token
            save_token("new-encrypted-token")
            assert not plaintext_file.exists()


# ---------------------------------------------------------------------------
# 4. delete_token / clear_token clears all stores
# ---------------------------------------------------------------------------

def test_delete_clears_all_stores():
    """delete_token removes token from keyring, enc file, and plaintext file."""
    kb, store = _mock_keyring_store()
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        plaintext_file = cfg / "token"
        # Seed all three stores manually
        store[("msapling-cli", "auth_token")] = "stored-token"
        enc_file.write_bytes(b"garbage-encrypted")
        plaintext_file.write_text("stale-plaintext", encoding="utf-8")
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb):
            from msapling_cli.config import delete_token
            delete_token()
        # Assertions inside _TmpHome context so temp dir is still alive.
        assert ("msapling-cli", "auth_token") not in store
        assert not enc_file.exists()
        assert not plaintext_file.exists()


def test_clear_token_is_idempotent():
    """clear_token does not raise when no token exists."""
    with _TmpHome():
        with _no_keyring():
            from msapling_cli.config import clear_token
            clear_token()  # nothing to clear — must not raise
            clear_token()  # second call also safe


# ---------------------------------------------------------------------------
# 5. Machine key stability
# ---------------------------------------------------------------------------

def test_machine_key_stable_across_calls():
    """Same hostname, username, and salt file produce the same key on each call."""
    with _TmpHome():
        with patch("socket.gethostname", return_value="test-host"), \
             patch.dict(os.environ, {"USER": "test-user", "USERNAME": "test-user"}):
            from msapling_cli.config import _get_machine_key
            key1 = _get_machine_key()
            key2 = _get_machine_key()
    assert key1 == key2


def test_machine_key_different_salt():
    """Different salt files produce different keys."""
    import importlib
    import msapling_cli.config as cfg_mod

    key_a: bytes = b""
    key_b: bytes = b""

    # First temp dir: generate a key (creates .keyfile)
    with _TmpHome() as cfg_a:
        with patch("socket.gethostname", return_value="same-host"), \
             patch.dict(os.environ, {"USER": "same-user", "USERNAME": "same-user"}):
            key_a = cfg_mod._get_machine_key()

    # Second temp dir: fresh .keyfile → different salt
    with _TmpHome() as cfg_b:
        with patch("socket.gethostname", return_value="same-host"), \
             patch.dict(os.environ, {"USER": "same-user", "USERNAME": "same-user"}):
            key_b = cfg_mod._get_machine_key()

    assert key_a != key_b


# ---------------------------------------------------------------------------
# 6. .keyfile permissions (Unix only)
# ---------------------------------------------------------------------------

@pytest.mark.skipif(sys.platform == "win32", reason="chmod not meaningful on Windows")
def test_keyfile_created_chmod_600():
    """.keyfile is created with mode 0o600 on Unix."""
    with _TmpHome() as cfg:
        keyfile = cfg / ".keyfile"
        from msapling_cli.config import _get_machine_key
        _get_machine_key()
        assert keyfile.exists()
        mode = keyfile.stat().st_mode & 0o777
        assert mode == 0o600, f"Expected 0o600, got 0o{mode:o}"


# ---------------------------------------------------------------------------
# 7. Encrypted file does not contain plaintext token
# ---------------------------------------------------------------------------

def test_encrypted_file_not_plaintext():
    """Raw bytes in token.enc must not contain the token string."""
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token
            save_token("super-secret-jwt-9876")
        raw = enc_file.read_bytes()
    assert b"super-secret-jwt-9876" not in raw


# ---------------------------------------------------------------------------
# 8. None when no token
# ---------------------------------------------------------------------------

def test_load_returns_none_when_empty():
    """get_token returns None when keyring is empty, no enc file, no plaintext."""
    with _TmpHome():
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import get_token
            result = get_token()
    assert result is None


def test_load_token_alias_returns_none_when_empty():
    """load_token() (alias) also returns None when nothing is stored."""
    with _TmpHome():
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import load_token
            result = load_token()
    assert result is None


# ---------------------------------------------------------------------------
# 9. Corrupted enc file
# ---------------------------------------------------------------------------

def test_no_crash_on_corrupted_enc_file():
    """Corrupted token.enc silently returns None instead of raising."""
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        enc_file.write_bytes(b"this-is-not-valid-fernet-ciphertext!!!")
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import get_token
            result = get_token()
    assert result is None


def test_no_crash_on_empty_enc_file():
    """Empty token.enc returns None without crashing."""
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        enc_file.write_bytes(b"")
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import get_token
            result = get_token()
    assert result is None


# ---------------------------------------------------------------------------
# 10. is_keyring_available probe
# ---------------------------------------------------------------------------

def test_is_keyring_available_true():
    """is_keyring_available returns True when the probe set/get/delete succeeds."""
    kb, store = _mock_keyring_store()
    with patch("msapling_cli.config._get_keyring_backend", return_value=kb):
        from msapling_cli.config import is_keyring_available
        result = is_keyring_available()
    assert result is True


def test_is_keyring_available_false_no_backend():
    """is_keyring_available returns False when keyring module is not installed."""
    with _no_keyring():
        from msapling_cli.config import is_keyring_available
        result = is_keyring_available()
    assert result is False


def test_is_keyring_available_false_raises():
    """is_keyring_available returns False when set_password raises."""
    kb = MagicMock()
    kb.set_password.side_effect = Exception("no usable keyring")
    with patch("msapling_cli.config._get_keyring_backend", return_value=kb):
        from msapling_cli.config import is_keyring_available
        result = is_keyring_available()
    assert result is False


def test_is_keyring_available_false_get_mismatch():
    """is_keyring_available returns False if get returns unexpected value."""
    kb = MagicMock()
    kb.set_password.return_value = None
    kb.get_password.return_value = "wrong-value"
    kb.delete_password.return_value = None
    with patch("msapling_cli.config._get_keyring_backend", return_value=kb):
        from msapling_cli.config import is_keyring_available
        result = is_keyring_available()
    assert result is False


# ---------------------------------------------------------------------------
# 11. Token rotation
# ---------------------------------------------------------------------------

def test_token_rotation_overwrites_previous():
    """Saving a new token replaces the old one in the enc file."""
    with _TmpHome():
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token, get_token
            save_token("first-token")
            save_token("second-token")
            result = get_token()
    assert result == "second-token"


def test_keyring_token_rotation():
    """save_token called twice updates keyring entry to the new value."""
    kb, store = _mock_keyring_store()
    with _TmpHome():
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token, get_token
            save_token("token-v1")
            save_token("token-v2")
            result = get_token()
    assert result == "token-v2"


# ---------------------------------------------------------------------------
# 12. Keyring service name used on Windows / Linux / macOS
# ---------------------------------------------------------------------------

def test_keyring_uses_correct_service_name():
    """save_token calls keyring.set_password with service 'msapling-cli'."""
    kb, store = _mock_keyring_store()
    with _TmpHome():
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token
            save_token("svc-name-test")
    called_svc = kb.set_password.call_args[0][0]
    assert called_svc == "msapling-cli"


def test_keyring_uses_correct_username():
    """save_token calls keyring.set_password with username 'auth_token'."""
    kb, store = _mock_keyring_store()
    with _TmpHome():
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token
            save_token("username-test")
    called_user = kb.set_password.call_args[0][1]
    assert called_user == "auth_token"


# ---------------------------------------------------------------------------
# 13. Concurrent / idempotent fallback saves
# ---------------------------------------------------------------------------

def test_concurrent_save_load_same_value():
    """Multiple save_token calls with the same value all produce the same get_token result."""
    with _TmpHome():
        with _no_keyring(), patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token, get_token
            for _ in range(5):
                save_token("idempotent-token")
            result = get_token()
    assert result == "idempotent-token"


# ---------------------------------------------------------------------------
# 14. env var takes priority over all stored tokens
# ---------------------------------------------------------------------------

def test_env_var_takes_priority_over_keyring_and_file():
    """MSAPLING_TOKEN env var always wins over keyring and enc file."""
    kb, store = _mock_keyring_store()
    store[("msapling-cli", "auth_token")] = "keyring-stored"
    with _TmpHome() as cfg:
        (cfg / "token.enc").write_bytes(b"enc-garbage")
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": "env-wins"}):
            from msapling_cli.config import get_token
            result = get_token()
    assert result == "env-wins"


# ---------------------------------------------------------------------------
# 15. Keyring success removes stale enc file
# ---------------------------------------------------------------------------

def test_keyring_success_removes_stale_enc_file():
    """When save_token succeeds via keyring, any stale token.enc is removed."""
    kb, store = _mock_keyring_store()
    with _TmpHome() as cfg:
        enc_file = cfg / "token.enc"
        enc_file.write_bytes(b"stale-data")
        with patch("msapling_cli.config._get_keyring_backend", return_value=kb), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            from msapling_cli.config import save_token
            save_token("clean-token")
    assert not enc_file.exists(), "stale token.enc should be deleted when keyring succeeds"
