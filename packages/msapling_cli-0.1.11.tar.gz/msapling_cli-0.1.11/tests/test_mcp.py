"""Tests for MCP server tool definitions and protocol handling."""

from msapling_cli import __version__
from msapling_cli.mcp import server as mcp_server
from msapling_cli.mcp.server import TOOLS


def test_tool_count():
    assert len(TOOLS) >= 9, f"Expected 9+ tools, got {len(TOOLS)}"


def test_all_tools_have_required_fields():
    for tool in TOOLS:
        assert "name" in tool, f"Tool missing 'name': {tool}"
        assert "description" in tool, f"Tool missing 'description': {tool.get('name')}"
        assert "inputSchema" in tool, f"Tool missing 'inputSchema': {tool.get('name')}"


def test_all_tools_have_unique_names():
    names = [t["name"] for t in TOOLS]
    assert len(names) == len(set(names)), f"Duplicate tool names: {names}"


def test_tool_schemas_valid():
    for tool in TOOLS:
        schema = tool["inputSchema"]
        assert schema.get("type") == "object", f"Tool {tool['name']} schema not object type"
        assert "properties" in schema, f"Tool {tool['name']} missing properties"


def test_required_tools_present():
    names = {t["name"] for t in TOOLS}
    expected = {
        "msapling_chat",
        "msapling_diff",
        "msapling_apply_diff",
        "msapling_search_files",
        "msapling_read_file",
        "msapling_write_file",
        "msapling_project_context",
        "msapling_cost_check",
        "msapling_models",
        "msapling_multi_chat",
        "msapling_swarm",
    }
    missing = expected - names
    assert not missing, f"Missing tools: {missing}"


def test_chat_tool_schema():
    chat = next(t for t in TOOLS if t["name"] == "msapling_chat")
    props = chat["inputSchema"]["properties"]
    assert "prompt" in props
    required = chat["inputSchema"].get("required", [])
    assert "prompt" in required


def test_swarm_tool_schema():
    swarm = next(t for t in TOOLS if t["name"] == "msapling_swarm")
    props = swarm["inputSchema"]["properties"]
    assert "prompt" in props
    assert "models" in props


def test_serve_initialize_and_tools_list(monkeypatch):
    messages = iter([
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-11-25"}},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
        None,
    ])
    written = []

    monkeypatch.setattr(mcp_server, "_init_binary_io", lambda: None)
    monkeypatch.setattr(mcp_server, "_read_message", lambda: next(messages))
    monkeypatch.setattr(mcp_server, "_write_message", lambda msg: written.append(msg))

    mcp_server.serve()

    assert written[0]["id"] == 1
    assert written[0]["result"]["protocolVersion"] == "2025-11-25"
    assert written[0]["result"]["serverInfo"]["version"] == __version__
    assert written[1] == {
        "jsonrpc": "2.0",
        "id": 2,
        "result": {"tools": TOOLS},
    }


def test_serve_tools_call_dispatch(monkeypatch):
    messages = iter([
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "msapling_project_context", "arguments": {"path": "."}},
        },
        None,
    ])
    written = []
    seen = {}

    async def fake_handle_tool(name, args, **kwargs):
        seen["name"] = name
        seen["args"] = args
        return {"content": [{"type": "text", "text": "ok"}]}

    monkeypatch.setattr(mcp_server, "_init_binary_io", lambda: None)
    monkeypatch.setattr(mcp_server, "_read_message", lambda: next(messages))
    monkeypatch.setattr(mcp_server, "_write_message", lambda msg: written.append(msg))
    monkeypatch.setattr(mcp_server, "_handle_tool", fake_handle_tool)

    mcp_server.serve()

    assert seen == {"name": "msapling_project_context", "args": {"path": "."}}
    assert written == [
        {
            "jsonrpc": "2.0",
            "id": 3,
            "result": {"content": [{"type": "text", "text": "ok"}]},
        }
    ]


def test_serve_unknown_method_returns_jsonrpc_error(monkeypatch):
    messages = iter([
        {"jsonrpc": "2.0", "id": 9, "method": "bogus/method", "params": {}},
        None,
    ])
    written = []

    monkeypatch.setattr(mcp_server, "_init_binary_io", lambda: None)
    monkeypatch.setattr(mcp_server, "_read_message", lambda: next(messages))
    monkeypatch.setattr(mcp_server, "_write_message", lambda msg: written.append(msg))

    mcp_server.serve()

    assert written == [
        {
            "jsonrpc": "2.0",
            "id": 9,
            "error": {"code": -32601, "message": "Method not found: bogus/method"},
        }
    ]



def test_read_message_accepts_lf_only_headers(monkeypatch):
    body = b'{"jsonrpc":"2.0","id":1,"method":"ping"}'
    payload = f"Content-Length: {len(body)}\n\n".encode("ascii") + body
    chunks = [bytes([b]) for b in payload]

    class DummyStdin:
        def fileno(self):
            return 123

    def fake_read(fd, n):
        assert fd == 123
        if not chunks:
            return b''
        out = b''
        while chunks and len(out) < n:
            out += chunks.pop(0)
        return out

    monkeypatch.setattr(mcp_server.sys, 'stdin', DummyStdin())
    monkeypatch.setattr(mcp_server.os, 'read', fake_read)

    msg = mcp_server._read_message()
    assert msg == {"jsonrpc": "2.0", "id": 1, "method": "ping"}


def test_read_message_accepts_newline_delimited_json(monkeypatch):
    payload = b'{"jsonrpc":"2.0","id":2,"method":"initialize"}\n'
    chunks = [bytes([b]) for b in payload]

    class DummyStdin:
        def fileno(self):
            return 456

    def fake_read(fd, n):
        assert fd == 456
        if not chunks:
            return b''
        out = b''
        while chunks and len(out) < n:
            out += chunks.pop(0)
        return out

    monkeypatch.setattr(mcp_server.sys, 'stdin', DummyStdin())
    monkeypatch.setattr(mcp_server.os, 'read', fake_read)

    msg = mcp_server._read_message()
    assert msg == {"jsonrpc": "2.0", "id": 2, "method": "initialize"}


def test_write_message_uses_raw_line_transport(monkeypatch):
    written = []

    class DummyStdout:
        def fileno(self):
            return 789

    def fake_write(fd, data):
        assert fd == 789
        written.append(data)
        return len(data)

    monkeypatch.setattr(mcp_server.sys, 'stdout', DummyStdout())
    monkeypatch.setattr(mcp_server.os, 'write', fake_write)
    monkeypatch.setattr(mcp_server, '_transport_mode', 'raw_line')

    mcp_server._write_message({"jsonrpc": "2.0", "id": 7, "result": {"ok": True}})

    assert written == [b'{"jsonrpc": "2.0", "id": 7, "result": {"ok": true}}\n']
