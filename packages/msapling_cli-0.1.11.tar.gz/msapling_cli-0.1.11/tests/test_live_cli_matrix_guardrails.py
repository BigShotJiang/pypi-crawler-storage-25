from __future__ import annotations

import importlib.util
from pathlib import Path
import sys


CLI_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = CLI_ROOT / "scripts" / "live_cli_matrix.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("live_cli_matrix", SCRIPT_PATH)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_live_cli_matrix_script_exists():
    assert SCRIPT_PATH.exists(), "scripts/live_cli_matrix.py must exist"


def test_collect_command_paths_covers_surface():
    mod = _load_module()
    paths = mod.collect_command_paths()
    names = {" ".join(p) for p in paths}
    assert len(names) >= 100, "Expected broad command-surface inventory"
    assert "parallel" in names
    assert "drive status" in names
    assert "pipeline run" in names
    assert "worktree status" in names


def test_parser_supports_tier_and_skip_flags():
    mod = _load_module()
    parser = mod.build_parser()
    help_text = parser.format_help()
    assert "--tier" in help_text
    assert "--ses-run-id" in help_text
    assert "--skip-help-surface" in help_text
    assert "--skip-live" in help_text
    assert "--skip-demo" in help_text


def test_flashlight_demo_includes_1_2_6_chat_modes():
    src = SCRIPT_PATH.read_text(encoding="utf-8")
    assert "flashlight_1_chat" in src
    assert "flashlight_2_chats" in src
    assert "flashlight_6_chats" in src
    assert "\"parallel\", \"-n\", \"2\"" in src
    assert "\"parallel\", \"-n\", \"6\"" in src


def test_matrix_has_env_skip_policy_for_ollama_and_ses():
    src = SCRIPT_PATH.read_text(encoding="utf-8")
    assert "expect_ollama_or_skip" in src
    assert "skipped_result(\"ses_status\"" in src


def test_expect_ollama_or_skip_accepts_offline_wrapped_message():
    mod = _load_module()
    text = "[red]OfflineError: Ollama unavailable: All connection\nattempts failed[/red]"
    assert mod.expect_ollama_or_skip(1, text) is True
