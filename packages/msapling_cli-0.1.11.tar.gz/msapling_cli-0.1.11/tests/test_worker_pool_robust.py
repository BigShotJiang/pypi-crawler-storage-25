"""Robust tests for WorkerPool: add/remove, cost ceiling, events, conflicts, tasks."""
from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from msapling_cli.worker_pool import (
    MAX_WORKERS,
    Worker,
    WorkerEvent,
    WorkerPool,
)


# ---- Worker basics ----


def test_worker_init():
    """Worker initializes with correct fields."""
    w = Worker("alpha", "chat-1", "google/gemini-flash-1.5")
    assert w.name == "alpha"
    assert w.chat_id == "chat-1"
    assert w.model == "google/gemini-flash-1.5"
    assert w.status == "ready"
    assert w.cost == 0.0
    assert w.tokens == 0
    assert w.task is None


def test_worker_to_dict():
    """Worker.to_dict() returns a serializable dictionary."""
    w = Worker("beta", "chat-2", "openai/gpt-4o")
    w.cost = 0.05
    w.tokens = 100
    w.task = "Fix tests"
    d = w.to_dict()
    assert d["name"] == "beta"
    assert d["cost"] == 0.05
    assert d["tokens"] == 100
    assert d["task"] == "Fix tests"


def test_worker_receive_event_from_other():
    """Worker receives events from other workers."""
    w = Worker("alpha", "c1", "m1")
    event = WorkerEvent("beta", "file_written", {"path": "main.py"})
    w.receive_event(event)
    assert len(w._pending_events) == 1


def test_worker_ignores_own_events():
    """Worker ignores events from itself."""
    w = Worker("alpha", "c1", "m1")
    event = WorkerEvent("alpha", "file_written", {"path": "main.py"})
    w.receive_event(event)
    assert len(w._pending_events) == 0


def test_worker_drain_events():
    """drain_events returns formatted context string and clears queue."""
    w = Worker("alpha", "c1", "m1")
    w.receive_event(WorkerEvent("beta", "file_written", {"path": "src/main.py"}))
    w.receive_event(WorkerEvent("gamma", "task_done", {"summary": "Tests pass"}))
    text = w.drain_events()
    assert "beta" in text
    assert "src/main.py" in text
    assert "gamma" in text
    assert "Tests pass" in text
    # Events should be cleared
    assert w.drain_events() == ""


def test_worker_drain_events_empty():
    """drain_events returns empty string when no pending events."""
    w = Worker("alpha", "c1", "m1")
    assert w.drain_events() == ""


# ---- WorkerEvent ----


def test_worker_event_timestamp():
    """WorkerEvent records a timestamp on creation."""
    before = time.time()
    ev = WorkerEvent("src", "file_written", {"path": "x.py"})
    after = time.time()
    assert before <= ev.timestamp <= after


def test_worker_event_fields():
    """WorkerEvent stores source, event_type, and data."""
    ev = WorkerEvent("worker-1", "task_done", {"summary": "done"})
    assert ev.source == "worker-1"
    assert ev.event_type == "task_done"
    assert ev.data["summary"] == "done"


# ---- WorkerPool: add/remove/get ----


def test_pool_add_worker():
    """WorkerPool.add_worker creates and stores a worker."""
    pool = WorkerPool("TestProject")
    w = pool.add_worker("alpha", "chat-1", "google/gemini-flash-1.5")
    assert w.name == "alpha"
    assert len(pool.workers) == 1


def test_pool_add_max_workers():
    """WorkerPool enforces MAX_WORKERS limit."""
    pool = WorkerPool("TestProject")
    for i in range(MAX_WORKERS):
        pool.add_worker(f"w{i}", f"c{i}", "m")
    with pytest.raises(ValueError, match=f"Max {MAX_WORKERS}"):
        pool.add_worker("extra", "cx", "m")


def test_pool_get_worker_by_name():
    """WorkerPool.get_worker finds worker by name (case-insensitive)."""
    pool = WorkerPool("P")
    pool.add_worker("Alpha", "c1", "m")
    w = pool.get_worker("alpha")
    assert w is not None
    assert w.name == "Alpha"


def test_pool_get_worker_by_index():
    """WorkerPool.get_worker finds worker by 1-based index."""
    pool = WorkerPool("P")
    pool.add_worker("first", "c1", "m")
    pool.add_worker("second", "c2", "m")
    w = pool.get_worker("2")
    assert w is not None
    assert w.name == "second"


def test_pool_get_worker_not_found():
    """WorkerPool.get_worker returns None for unknown name."""
    pool = WorkerPool("P")
    pool.add_worker("alpha", "c1", "m")
    assert pool.get_worker("nonexistent") is None


def test_pool_get_worker_index_out_of_range():
    """WorkerPool.get_worker returns None for out-of-range index."""
    pool = WorkerPool("P")
    pool.add_worker("alpha", "c1", "m")
    assert pool.get_worker("5") is None
    assert pool.get_worker("0") is None  # 1-based


def test_pool_remove_worker():
    """WorkerPool.remove_worker removes and returns the worker."""
    pool = WorkerPool("P")
    pool.add_worker("alpha", "c1", "m")
    pool.add_worker("beta", "c2", "m")
    removed = pool.remove_worker("alpha")
    assert removed is not None
    assert removed.name == "alpha"
    assert len(pool.workers) == 1


def test_pool_remove_worker_not_found():
    """WorkerPool.remove_worker returns None for unknown worker."""
    pool = WorkerPool("P")
    assert pool.remove_worker("ghost") is None


def test_pool_remove_by_index():
    """WorkerPool.remove_worker works with 1-based index."""
    pool = WorkerPool("P")
    pool.add_worker("alpha", "c1", "m")
    removed = pool.remove_worker("1")
    assert removed is not None
    assert removed.name == "alpha"
    assert len(pool.workers) == 0


# ---- Cost ceiling ----


def test_pool_total_cost():
    """total_cost sums all worker costs."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w1.cost = 0.10
    w2.cost = 0.20
    assert pool.total_cost == pytest.approx(0.30)


def test_pool_total_tokens():
    """total_tokens sums all worker tokens."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w1.tokens = 100
    w2.tokens = 200
    assert pool.total_tokens == 300


def test_pool_is_over_budget_no_ceiling():
    """is_over_budget returns False when no ceiling set."""
    pool = WorkerPool("P", cost_ceiling=None)
    w = pool.add_worker("a", "c1", "m")
    w.cost = 999.0
    assert pool.is_over_budget() is False


def test_pool_is_over_budget_under():
    """is_over_budget returns False when under ceiling."""
    pool = WorkerPool("P", cost_ceiling=1.0)
    w = pool.add_worker("a", "c1", "m")
    w.cost = 0.50
    assert pool.is_over_budget() is False


def test_pool_is_over_budget_at_ceiling():
    """is_over_budget returns True when exactly at ceiling."""
    pool = WorkerPool("P", cost_ceiling=1.0)
    w = pool.add_worker("a", "c1", "m")
    w.cost = 1.0
    assert pool.is_over_budget() is True


def test_pool_is_over_budget_over():
    """is_over_budget returns True when over ceiling."""
    pool = WorkerPool("P", cost_ceiling=0.5)
    w = pool.add_worker("a", "c1", "m")
    w.cost = 0.6
    assert pool.is_over_budget() is True


# ---- Event broadcasting ----


def test_broadcast_event_to_all_workers():
    """broadcast_event delivers event to all workers except source."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("alpha", "c1", "m")
    w2 = pool.add_worker("beta", "c2", "m")
    w3 = pool.add_worker("gamma", "c3", "m")

    event = WorkerEvent("alpha", "file_written", {"path": "x.py"})
    pool.broadcast_event(event)

    # alpha should not receive its own event
    assert len(w1._pending_events) == 0
    # beta and gamma should
    assert len(w2._pending_events) == 1
    assert len(w3._pending_events) == 1


def test_notify_file_written():
    """notify_file_written records file and broadcasts event."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("alpha", "c1", "m")
    w2 = pool.add_worker("beta", "c2", "m")

    pool.notify_file_written("alpha", "src/main.py")

    assert "src/main.py" in w1.files_written
    assert len(w2._pending_events) == 1
    assert w2._pending_events[0].event_type == "file_written"


def test_notify_task_done():
    """notify_task_done sets worker status and broadcasts."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("alpha", "c1", "m")
    w2 = pool.add_worker("beta", "c2", "m")
    w1.status = "running"

    pool.notify_task_done("alpha", "Tests pass")

    assert w1.status == "done"
    assert len(w2._pending_events) == 1
    assert w2._pending_events[0].data["summary"] == "Tests pass"


# ---- Conflict detection ----


def test_check_conflicts_none():
    """check_conflicts returns empty list when no overlapping files."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("alpha", "c1", "m")
    w2 = pool.add_worker("beta", "c2", "m")
    w1.files_written.add("a.py")
    w2.files_written.add("b.py")
    assert pool.check_conflicts() == []


def test_check_conflicts_detected():
    """check_conflicts detects two workers writing the same file."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("alpha", "c1", "m")
    w2 = pool.add_worker("beta", "c2", "m")
    w1.files_written.add("shared.py")
    w2.files_written.add("shared.py")

    conflicts = pool.check_conflicts()
    assert len(conflicts) == 1
    assert conflicts[0]["file"] == "shared.py"
    assert set(conflicts[0]["workers"]) == {"alpha", "beta"}


def test_check_conflicts_three_workers():
    """check_conflicts detects when three workers write the same file."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w3 = pool.add_worker("c", "c3", "m")
    for w in (w1, w2, w3):
        w.files_written.add("config.json")

    conflicts = pool.check_conflicts()
    assert len(conflicts) == 1
    assert len(conflicts[0]["workers"]) == 3


def test_check_conflicts_multiple_files():
    """check_conflicts reports conflicts per file."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w1.files_written = {"x.py", "y.py"}
    w2.files_written = {"x.py", "y.py"}

    conflicts = pool.check_conflicts()
    assert len(conflicts) == 2
    files = {c["file"] for c in conflicts}
    assert files == {"x.py", "y.py"}


def test_conflict_log_accumulates():
    """check_conflicts appends to _conflict_log each call."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w1.files_written.add("f.py")
    w2.files_written.add("f.py")

    pool.check_conflicts()
    pool.check_conflicts()
    assert len(pool._conflict_log) == 2


# ---- Task distribution ----


def test_distribute_tasks_round_robin():
    """distribute_tasks assigns subtasks round-robin to available workers."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")

    pool.distribute_tasks(["T1", "T2", "T3", "T4"])

    assert w1.task == "T3"  # T1 -> a, T3 -> a (round-robin)
    assert w2.task == "T4"  # T2 -> b, T4 -> b


def test_distribute_tasks_skips_running_workers():
    """distribute_tasks only assigns to workers with status ready/done."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w2 = pool.add_worker("b", "c2", "m")
    w2.status = "running"

    pool.distribute_tasks(["T1", "T2"])

    assert w1.task == "T2"  # Both go to w1 since w2 is running
    assert w2.task is None


def test_distribute_tasks_no_available_workers():
    """distribute_tasks does nothing when all workers are running."""
    pool = WorkerPool("P")
    w1 = pool.add_worker("a", "c1", "m")
    w1.status = "running"

    pool.distribute_tasks(["T1"])
    assert w1.task is None


def test_distribute_tasks_empty_list():
    """distribute_tasks with empty subtasks does nothing."""
    pool = WorkerPool("P")
    pool.add_worker("a", "c1", "m")
    pool.distribute_tasks([])
    assert pool.workers[0].task is None


# ---- Render status ----


def test_render_status_returns_table():
    """render_status returns a Rich Table object."""
    pool = WorkerPool("TestProject", cost_ceiling=1.0)
    pool.add_worker("alpha", "c1", "google/gemini-flash-1.5")
    table = pool.render_status()
    assert table is not None
    assert "TestProject" in table.title


def test_render_status_with_budget_caption():
    """render_status includes budget caption when cost_ceiling is set."""
    pool = WorkerPool("P", cost_ceiling=2.0)
    w = pool.add_worker("alpha", "c1", "m")
    w.cost = 0.5
    table = pool.render_status()
    assert table.caption is not None
    assert "$" in table.caption


def test_render_status_no_budget_caption():
    """render_status has no caption when cost_ceiling is None."""
    pool = WorkerPool("P", cost_ceiling=None)
    pool.add_worker("alpha", "c1", "m")
    table = pool.render_status()
    assert table.caption is None


# ---- MAX_WORKERS constant ----


def test_max_workers_is_6():
    """MAX_WORKERS matches the web's 6-panel grid."""
    assert MAX_WORKERS == 6
