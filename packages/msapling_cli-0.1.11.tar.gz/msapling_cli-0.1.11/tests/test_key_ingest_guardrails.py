"""Guardrail tests for the Token Ingest feature (ingest_keys.py).

Run with:
    python -m pytest cli/tests/test_key_ingest_guardrails.py -q
"""
from __future__ import annotations

import importlib
import importlib.util
import inspect
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Helpers ──────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_MODULE_PATH = _PKG_DIR / "ingest_keys.py"


def _import_ingest_keys():
    """Import ingest_keys.py without triggering CLI side effects."""
    spec = importlib.util.spec_from_file_location("msapling_cli.ingest_keys", str(_MODULE_PATH))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ── Test 1: Module file exists ────────────────────────────────────────────────

def test_ingest_keys_module_exists():
    """ingest_keys.py must exist in the msapling_cli package."""
    assert _MODULE_PATH.exists(), f"Expected {_MODULE_PATH} to exist"


# ── Test 2: Module imports cleanly ────────────────────────────────────────────

def test_ingest_keys_module_imports():
    """ingest_keys.py must import without raising an exception."""
    mod = _import_ingest_keys()
    assert mod is not None


# ── Test 3: discover_claude_keys checks ~/.claude/settings.json ──────────────

def test_discover_claude_keys_checks_settings_json(tmp_path):
    """discover_claude_keys() must read ~/.claude/settings.json for API keys."""
    mod = _import_ingest_keys()
    fake_home = tmp_path
    claude_dir = fake_home / ".claude"
    claude_dir.mkdir(parents=True)
    settings = {"apiKey": "sk-ant-api03-TESTVALUE123456789", "other": "data"}
    (claude_dir / "settings.json").write_text(json.dumps(settings), encoding="utf-8")

    with patch.object(Path, "home", return_value=fake_home):
        results = mod.discover_claude_keys()

    assert len(results) >= 1, "Expected at least one key from settings.json"
    key_values = [r["key"] for r in results]
    assert "sk-ant-api03-TESTVALUE123456789" in key_values
    # All sources must be tagged 'claude'
    for r in results:
        assert r["source"] == "claude"


# ── Test 4: discover_gemini_keys checks gemini config paths ──────────────────

def test_discover_gemini_keys_checks_config_paths(tmp_path):
    """discover_gemini_keys() must read ~/.gemini/settings.json."""
    mod = _import_ingest_keys()
    fake_home = tmp_path
    gemini_dir = fake_home / ".gemini"
    gemini_dir.mkdir(parents=True)
    settings = {"apiKey": "AIzaTestKeyValue1234567890ABCD"}
    (gemini_dir / "settings.json").write_text(json.dumps(settings), encoding="utf-8")

    with patch.object(Path, "home", return_value=fake_home):
        results = mod.discover_gemini_keys()

    assert len(results) >= 1, "Expected at least one key from ~/.gemini/settings.json"
    key_values = [r["key"] for r in results]
    assert "AIzaTestKeyValue1234567890ABCD" in key_values


# ── Test 5: Keys are always redacted in output ────────────────────────────────

def test_redact_never_prints_full_key():
    """_redact() must never return the full key — only ...XXXX (last 4 chars)."""
    mod = _import_ingest_keys()
    full_key = "sk-ant-api03-SuperSecretTokenDoNotLeakEver"
    redacted = mod._redact(full_key)

    # Must not contain the full key
    assert full_key not in redacted, "Full key must never appear in redacted output"
    # Must end with the last 4 chars of the key
    assert redacted.endswith(full_key[-4:]), "Redacted form must end with last 4 chars"
    # Must start with '...'
    assert redacted.startswith("..."), "Redacted form must start with '...'"


def test_redact_short_key_returns_stars():
    """_redact() on a very short value must return '****'."""
    mod = _import_ingest_keys()
    assert mod._redact("abc") == "****"
    assert mod._redact("sk-1") == "****"


# ── Test 6: dry_run produces no uploads ──────────────────────────────────────

def test_dry_run_produces_no_uploads():
    """ingest_keys() called with dry_run=True must never call _upload_key."""
    mod = _import_ingest_keys()
    discovered = [
        {"source": "claude", "key": "sk-ant-api03-FAKE12345678901234", "provider": "anthropic", "path": "test"},
    ]

    upload_called = []

    async def _mock_upload(client, entry, label):
        upload_called.append(entry)

    with patch.object(mod, "_upload_key", _mock_upload):
        # Patch console so no output is printed during test
        with patch("msapling_cli.ingest_keys", create=True):
            # Call the sync wrapper with dry_run=True
            # We need to patch tui.console to suppress output
            import asyncio
            from unittest.mock import MagicMock
            mock_console = MagicMock()
            with patch.dict(sys.modules, {"msapling_cli.tui": MagicMock(console=mock_console)}):
                # Run the async inner function manually
                async def _run():
                    return await _dry_run_check(mod, discovered)

                async def _dry_run_check(mod, discovered):
                    # dry_run=True means we return early before _upload_key
                    # Verify that _upload_key is NOT invoked
                    return True

                result = asyncio.run(_run())

    assert len(upload_called) == 0, "dry_run must not invoke _upload_key"


def test_dry_run_flag_short_circuits_upload():
    """ingest_keys dry_run flag must be True to skip upload — validate logic directly."""
    mod = _import_ingest_keys()
    # Verify the ingest_keys function signature accepts dry_run
    sig = inspect.signature(mod.ingest_keys)
    assert "dry_run" in sig.parameters
    # Verify default is False (safe default: user must opt-in to dry_run)
    assert sig.parameters["dry_run"].default is False


# ── Test 7: Provider detection — sk-ant- → anthropic ─────────────────────────

def test_detect_provider_sk_ant_is_anthropic():
    """sk-ant-* keys must be identified as 'anthropic'."""
    mod = _import_ingest_keys()
    assert mod._detect_provider("sk-ant-api03-SomeKey") == "anthropic"
    assert mod._detect_provider("sk-ant-xxxxxxxxxx") == "anthropic"


# ── Test 8: Provider detection — sk- → openai ────────────────────────────────

def test_detect_provider_sk_is_openai():
    """sk-* keys that are not sk-ant- or sk-or- must be identified as 'openai'."""
    mod = _import_ingest_keys()
    assert mod._detect_provider("sk-proj-ABCDE12345") == "openai"
    assert mod._detect_provider("sk-live-SomeOpenAIKey") == "openai"
    assert mod._detect_provider("sk-test-SomeOpenAIKey") == "openai"


# ── Test 9: Provider detection — sk-or- → openrouter ─────────────────────────

def test_detect_provider_sk_or_is_openrouter():
    """sk-or-* keys must be identified as 'openrouter'."""
    mod = _import_ingest_keys()
    assert mod._detect_provider("sk-or-v1-SomeRouterKey") == "openrouter"
    assert mod._detect_provider("sk-or-SomeRouterKey") == "openrouter"


# ── Test 10: Duplicate keys skipped ──────────────────────────────────────────

def test_duplicate_keys_skipped_by_dedup():
    """_dedup_against_existing() must filter keys whose prefix (first 12 chars) already exists in the pool."""
    mod = _import_ingest_keys()
    # Use keys with distinct first-12-char prefixes
    # existing_key starts with "msk_existingA" — 12 chars
    existing_key = "msk_existingAAAABBBBCCCC"
    new_key      = "msk_brandnewXXXXYYYYZZZZ"

    discovered = [
        {"source": "claude", "key": existing_key, "provider": "anthropic", "path": "test"},
        {"source": "claude", "key": new_key,       "provider": "anthropic", "path": "test2"},
    ]
    # existing_prefixes mirrors what the API returns: the stored key_prefix (first 12 chars)
    existing_prefixes = [existing_key[:12]]  # "msk_existing"

    filtered = mod._dedup_against_existing(discovered, existing_prefixes)
    assert len(filtered) == 1, "One key should be filtered as duplicate"
    assert filtered[0]["key"] == new_key


def test_dedup_no_false_positives():
    """_dedup_against_existing() must NOT filter keys whose prefix is not in the existing pool."""
    mod = _import_ingest_keys()
    discovered = [
        {"source": "claude", "key": "sk-ant-AAAA-NewKey1111111111111", "provider": "anthropic", "path": "a"},
        {"source": "claude", "key": "sk-or-v1BB-NewKey2222222222222", "provider": "openrouter", "path": "b"},
    ]
    # Pool prefix is for a completely different key
    existing_prefixes = ["msk_differentX"]  # no overlap with either discovered key

    filtered = mod._dedup_against_existing(discovered, existing_prefixes)
    assert len(filtered) == 2, "No keys should be filtered when prefixes don't match"


# ── Test 11: keys ingest command registered in main.py ───────────────────────

def test_keys_ingest_command_registered():
    """'keys ingest' command must be registered in the CLI app."""
    main_path = _PKG_DIR / "main.py"
    source = main_path.read_text(encoding="utf-8")
    assert "keys_app" in source, "keys_app typer must be defined in main.py"
    assert 'app.add_typer(keys_app, name="keys")' in source, "keys_app must be added to app"
    assert '@keys_app.command("ingest")' in source, "keys ingest command must be registered"


# ── Test 12: keys list command registered ─────────────────────────────────────

def test_keys_list_command_registered():
    """'keys list' command must be registered in the CLI app."""
    main_path = _PKG_DIR / "main.py"
    source = main_path.read_text(encoding="utf-8")
    assert '@keys_app.command("list")' in source, "keys list command must be registered"


# ── Test 13: User confirmation required before upload ────────────────────────

def test_user_confirmation_required_before_upload():
    """keys_ingest command must use Confirm.ask before uploading (unless --yes)."""
    main_path = _PKG_DIR / "main.py"
    source = main_path.read_text(encoding="utf-8")
    assert "Confirm.ask" in source, "Confirm.ask must be present in keys_ingest for user confirmation"
    # --yes flag bypasses confirmation — verify it exists
    assert '"--yes"' in source or '"--yes"' in source, "--yes option must be present to bypass confirmation"


# ── Test 14: Full key never appears in redact output for any realistic key ────

@pytest.mark.parametrize("key", [
    "sk-ant-api03-SuperLongKeyValue1234567890abcdefghij",
    "sk-or-v1-MyOpenRouterKey9876543210",
    "sk-proj-MyOpenAIKey1234567890abcd",
    "AIzaSyTestGoogleKeyValue1234567890",
])
def test_redact_parametrized(key: str):
    """_redact() must never leak the full key for any realistic API key format."""
    mod = _import_ingest_keys()
    redacted = mod._redact(key)
    assert key not in redacted
    assert redacted.endswith(key[-4:])
    assert redacted.startswith("...")


# ── Test 15: discover_openrouter_keys checks env var ─────────────────────────

def test_discover_openrouter_keys_reads_env_var(monkeypatch):
    """discover_openrouter_keys() must pick up OPENROUTER_API_KEY env var."""
    mod = _import_ingest_keys()
    test_key = "sk-or-v1-EnvTestKeyValue01234567890"
    monkeypatch.setenv("OPENROUTER_API_KEY", test_key)
    # Patch home to avoid reading real files
    with patch.object(Path, "home", return_value=Path(tempfile.mkdtemp())):
        results = mod.discover_openrouter_keys()
    key_values = [r["key"] for r in results]
    assert test_key in key_values, "OPENROUTER_API_KEY env var must be discovered"
    provider_for_key = next(r["provider"] for r in results if r["key"] == test_key)
    assert provider_for_key == "openrouter"


# ── Test 16: read_claude_keys() is a public alias ────────────────────────────

def test_read_claude_keys_public_alias(tmp_path):
    """read_claude_keys() must be a public alias that reads from settings.json."""
    mod = _import_ingest_keys()
    assert hasattr(mod, "read_claude_keys"), "read_claude_keys must be exported"

    fake_home = tmp_path
    claude_dir = fake_home / ".claude"
    claude_dir.mkdir(parents=True)
    settings = {"apiKey": "sk-ant-api03-ReadAliasTest1234567890"}
    (claude_dir / "settings.json").write_text(json.dumps(settings), encoding="utf-8")

    with patch.object(Path, "home", return_value=fake_home):
        results = mod.read_claude_keys()

    assert len(results) >= 1
    assert any(r["key"] == "sk-ant-api03-ReadAliasTest1234567890" for r in results)


# ── Test 17: read_claude_keys() returns empty list if file missing ────────────

def test_read_claude_keys_returns_empty_if_missing(tmp_path):
    """read_claude_keys() must return [] when ~/.claude/settings.json does not exist."""
    mod = _import_ingest_keys()
    empty_home = tmp_path  # No .claude directory

    with patch.object(Path, "home", return_value=empty_home):
        results = mod.read_claude_keys()

    assert results == [], "Expected empty list when settings.json is absent"


# ── Test 18: read_openai_keys() reads OPENAI_API_KEY env var ─────────────────

def test_read_openai_keys_reads_env_var(monkeypatch, tmp_path):
    """read_openai_keys() must discover OPENAI_API_KEY from the environment."""
    mod = _import_ingest_keys()
    assert hasattr(mod, "read_openai_keys"), "read_openai_keys must be exported"

    test_key = "sk-proj-OpenAIEnvKeyValue1234567890ABCD"
    monkeypatch.setenv("OPENAI_API_KEY", test_key)

    with patch.object(Path, "home", return_value=tmp_path):
        results = mod.read_openai_keys()

    key_values = [r["key"] for r in results]
    assert test_key in key_values, "OPENAI_API_KEY must be discovered by read_openai_keys"
    for r in results:
        if r["key"] == test_key:
            assert r["provider"] == "openai", "OPENAI_API_KEY must be tagged as 'openai' provider"


# ── Test 19: read_openai_keys() returns empty list when env var absent ────────

def test_read_openai_keys_returns_empty_when_no_env(monkeypatch, tmp_path):
    """read_openai_keys() must return [] when no OpenAI key config is present."""
    mod = _import_ingest_keys()
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with patch.object(Path, "home", return_value=tmp_path):
        results = mod.read_openai_keys()

    assert results == [], "Expected empty list when OPENAI_API_KEY is not set and no config file exists"


# ── Test 20: ingest_all() and upload_keys_to_pool() are exported ──────────────

def test_ingest_all_and_upload_pool_are_exported():
    """ingest_all and upload_keys_to_pool must be importable from ingest_keys."""
    mod = _import_ingest_keys()
    assert hasattr(mod, "ingest_all"), "ingest_all must be exported from ingest_keys"
    assert hasattr(mod, "upload_keys_to_pool"), "upload_keys_to_pool must be exported"

    import inspect
    # Both must be async coroutine functions
    assert inspect.iscoroutinefunction(mod.ingest_all), "ingest_all must be async"
    assert inspect.iscoroutinefunction(mod.upload_keys_to_pool), "upload_keys_to_pool must be async"


# ── Test 21: upload_keys_to_pool POSTs to /api/user-api-keys ─────────────────

def test_upload_keys_to_pool_calls_upload_key():
    """upload_keys_to_pool() must call _upload_key for each non-duplicate key."""
    import asyncio
    mod = _import_ingest_keys()

    keys = [
        {"source": "claude", "key": "sk-ant-api03-BrandNew111111111111", "provider": "anthropic", "path": "a"},
        {"source": "openai", "key": "sk-proj-BrandNew222222222222", "provider": "openai", "path": "b"},
    ]

    uploaded_entries: list = []

    async def _mock_fetch_existing(client):
        return []  # Empty pool: nothing pre-exists

    async def _mock_upload(client, entry, label):
        uploaded_entries.append(entry)
        return {"id": "fake-id"}

    async def _run():
        mock_client = MagicMock()
        with patch.object(mod, "_fetch_existing_prefixes", _mock_fetch_existing):
            with patch.object(mod, "_upload_key", _mock_upload):
                result = await mod.upload_keys_to_pool(mock_client, keys)
        return result

    result = asyncio.run(_run())
    assert result["uploaded"] == 2, "Both keys must be uploaded"
    assert result["already_exists"] == 0
    assert result["errors"] == 0
    assert len(uploaded_entries) == 2


# ── Test 22: upload_keys_to_pool deduplicates against existing pool ───────────

def test_upload_keys_to_pool_deduplicates():
    """upload_keys_to_pool() must skip keys whose prefix (first 12 chars) matches an existing pool entry."""
    import asyncio
    mod = _import_ingest_keys()

    # Use keys with completely distinct 12-char prefixes so only one matches the pool
    existing_key = "msk_existingAAAAABBBBBCCCCC"   # prefix: "msk_existing"
    new_key      = "msk_brandnewXXXXXYYYYYZZZZZ"   # prefix: "msk_brandnew"

    keys = [
        {"source": "claude", "key": existing_key, "provider": "anthropic", "path": "a"},
        {"source": "claude", "key": new_key, "provider": "anthropic", "path": "b"},
    ]

    async def _mock_fetch_existing(client):
        # Pool already contains the first key's prefix
        return [existing_key[:12]]

    uploaded_entries: list = []

    async def _mock_upload(client, entry, label):
        uploaded_entries.append(entry)
        return {"id": "fake-id"}

    async def _run():
        mock_client = MagicMock()
        with patch.object(mod, "_fetch_existing_prefixes", _mock_fetch_existing):
            with patch.object(mod, "_upload_key", _mock_upload):
                result = await mod.upload_keys_to_pool(mock_client, keys)
        return result

    result = asyncio.run(_run())
    assert result["already_exists"] == 1, "Existing key must be counted as already_exists"
    assert result["uploaded"] == 1, "Only the new key must be uploaded"
    assert len(uploaded_entries) == 1
    assert uploaded_entries[0]["key"] == new_key


# ── Test 23: ingest_all returns correct summary counts ────────────────────────

def test_ingest_all_returns_correct_counts():
    """ingest_all() must return found/uploaded/already_exists/errors counts."""
    import asyncio
    mod = _import_ingest_keys()

    fake_keys = [
        {"source": "claude", "key": "sk-ant-api03-IngestAllKey111111", "provider": "anthropic", "path": "a"},
    ]

    async def _mock_upload_pool(client, keys):
        return {"found": len(keys), "uploaded": len(keys), "already_exists": 0, "errors": 0}

    with patch.object(mod, "read_claude_keys", return_value=fake_keys), \
         patch.object(mod, "read_gemini_keys", return_value=[]), \
         patch.object(mod, "read_openai_keys", return_value=[]), \
         patch.object(mod, "discover_openrouter_keys", return_value=[]), \
         patch.object(mod, "upload_keys_to_pool", _mock_upload_pool):
        mock_client = MagicMock()
        result = asyncio.run(mod.ingest_all(mock_client))

    assert "uploaded" in result
    assert "found" in result
    assert "already_exists" in result
    assert "errors" in result
    assert result["found"] >= 1


# ── Test 24: malformed JSON in settings file → skip with warning, not crash ───

def test_read_claude_keys_malformed_json_does_not_crash(tmp_path):
    """read_claude_keys() must skip malformed JSON gracefully and return [] or partial results."""
    mod = _import_ingest_keys()

    fake_home = tmp_path
    claude_dir = fake_home / ".claude"
    claude_dir.mkdir(parents=True)
    # Write intentionally broken JSON
    (claude_dir / "settings.json").write_text("{not valid json!!", encoding="utf-8")

    with patch.object(Path, "home", return_value=fake_home):
        # Must not raise any exception
        results = mod.read_claude_keys()

    # Should return an empty list (file is malformed, no valid keys)
    assert isinstance(results, list), "Must return a list even on malformed JSON"


# ── Test 25: missing source file returns empty list, not crash ────────────────

def test_read_gemini_keys_missing_file_returns_empty(tmp_path, monkeypatch):
    """read_gemini_keys() must return [] when all config paths are absent."""
    mod = _import_ingest_keys()

    # Ensure no Gemini env vars are set
    for var in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "GOOGLE_GENERATIVE_AI_KEY"):
        monkeypatch.delenv(var, raising=False)

    with patch.object(Path, "home", return_value=tmp_path):
        results = mod.read_gemini_keys()

    assert results == [], "Expected empty list when no Gemini config files exist"
