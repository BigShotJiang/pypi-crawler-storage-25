"""Guardrail tests for CLI Windows PATH detection and upgrade flow.

Verifies:
- _get_scripts_dir() returns a Path
- _print_path_guidance() is callable and handles in-PATH and out-of-PATH cases
- path-check command is registered
- upgrade command exists and shows pip spinner
- ses_commands module is importable and registers ses_app
"""
from __future__ import annotations

import asyncio
import inspect
import os
import sys

import pytest


# ---------------------------------------------------------------------------
# 1. _get_scripts_dir helper
# ---------------------------------------------------------------------------

def test_get_scripts_dir_exists():
    from msapling_cli import main
    assert hasattr(main, "_get_scripts_dir"), "_get_scripts_dir must exist in main"


def test_get_scripts_dir_returns_path():
    from msapling_cli import main
    from pathlib import Path
    result = main._get_scripts_dir()
    assert isinstance(result, Path)


def test_get_scripts_dir_returns_directory():
    from msapling_cli import main
    result = main._get_scripts_dir()
    # The returned path should be a real directory (pip scripts live somewhere)
    assert result.exists() or result.parent.exists(), (
        f"_get_scripts_dir returned {result} which has no existing parent"
    )


# ---------------------------------------------------------------------------
# 2. _print_path_guidance helper
# ---------------------------------------------------------------------------

def test_print_path_guidance_exists():
    from msapling_cli import main
    assert hasattr(main, "_print_path_guidance"), "_print_path_guidance must exist in main"


def test_print_path_guidance_callable():
    from msapling_cli import main
    assert callable(main._print_path_guidance)


def test_print_path_guidance_runs_when_in_path(monkeypatch, capsys):
    """_print_path_guidance must not crash and print restart hint when scripts dir is in PATH."""
    from msapling_cli import main
    from pathlib import Path

    fake_scripts = Path("/fake/scripts")
    monkeypatch.setattr(main, "_get_scripts_dir", lambda: fake_scripts)
    monkeypatch.setenv("PATH", f"/usr/bin:{fake_scripts}")

    # Must not raise
    main._print_path_guidance()


def test_print_path_guidance_runs_when_not_in_path(monkeypatch):
    """_print_path_guidance must not crash when scripts dir is NOT in PATH."""
    from msapling_cli import main
    from pathlib import Path

    fake_scripts = Path("/not/in/path/Scripts")
    monkeypatch.setattr(main, "_get_scripts_dir", lambda: fake_scripts)
    monkeypatch.setenv("PATH", "/usr/bin:/usr/local/bin")

    # Must not raise
    main._print_path_guidance()


def test_print_path_guidance_windows_hint(monkeypatch):
    """On Windows, _print_path_guidance must include PowerShell $env:PATH instruction."""
    if sys.platform != "win32":
        pytest.skip("Windows-specific test")

    from msapling_cli import main
    from pathlib import Path

    fake_scripts = Path("C:/Python313/Scripts")
    monkeypatch.setattr(main, "_get_scripts_dir", lambda: fake_scripts)
    monkeypatch.setenv("PATH", "C:/Windows/System32")

    output_lines: list = []
    from msapling_cli.tui import console as tui_console
    monkeypatch.setattr(tui_console, "print", lambda *a, **kw: output_lines.append(str(a)))

    main._print_path_guidance()
    combined = " ".join(output_lines)
    assert "PATH" in combined or "env" in combined.lower(), (
        "_print_path_guidance must mention PATH when scripts dir is missing from it"
    )


# ---------------------------------------------------------------------------
# 3. path-check command
# ---------------------------------------------------------------------------

def test_path_check_command_registered():
    """path-check command must be registered in the typer app."""
    from msapling_cli import main
    command_names = [cmd.name or (cmd.callback.__name__ if cmd.callback else "") for cmd in main.app.registered_commands]
    assert "path-check" in command_names, f"path-check not found in commands: {command_names}"


def test_path_check_command_callable():
    from msapling_cli import main
    assert hasattr(main, "path_check")
    assert callable(main.path_check)


def test_path_check_runs_successfully(monkeypatch):
    """path-check must exit 0 when msapling is in PATH."""
    from typer.testing import CliRunner
    from msapling_cli import main
    from pathlib import Path
    import shutil

    fake_scripts = Path(sys.executable).parent
    monkeypatch.setattr(main, "_get_scripts_dir", lambda: fake_scripts)
    # Make shutil.which find something
    monkeypatch.setattr(shutil, "which", lambda name: str(fake_scripts / name))

    runner = CliRunner()
    result = runner.invoke(main.app, ["path-check"])
    # Should exit 0 (success) since we patched which to find msapling
    assert result.exit_code == 0, f"path-check failed: {result.output}"


def test_path_check_shows_scripts_dir(monkeypatch):
    """path-check output must show the scripts directory path."""
    from typer.testing import CliRunner
    from msapling_cli import main
    from pathlib import Path
    import shutil

    fake_scripts = Path("/fake/scripts/dir")
    monkeypatch.setattr(main, "_get_scripts_dir", lambda: fake_scripts)
    monkeypatch.setattr(shutil, "which", lambda name: str(fake_scripts / name))

    runner = CliRunner()
    result = runner.invoke(main.app, ["path-check"])
    assert "fake" in result.output or "scripts" in result.output.lower(), (
        "path-check must display the scripts directory"
    )


# ---------------------------------------------------------------------------
# 4. upgrade command with spinner
# ---------------------------------------------------------------------------

def test_upgrade_command_registered():
    from msapling_cli import main
    command_names = [cmd.name or (cmd.callback.__name__ if cmd.callback else "") for cmd in main.app.registered_commands]
    assert "upgrade" in command_names


def test_upgrade_calls_print_path_guidance():
    """upgrade command source must call _print_path_guidance after success."""
    import inspect as _inspect
    from msapling_cli import main
    src = _inspect.getsource(main.upgrade)
    assert "_print_path_guidance" in src, (
        "upgrade must call _print_path_guidance() after successful pip install"
    )


def test_upgrade_shows_spinner_during_install():
    """upgrade must use console.status or working_spinner during pip install subprocess."""
    import inspect as _inspect
    from msapling_cli import main
    src = _inspect.getsource(main.upgrade)
    assert "status" in src or "working_spinner" in src, (
        "upgrade must show a spinner/status during pip install to avoid silent waiting"
    )


# ---------------------------------------------------------------------------
# 5. ses_commands module
# ---------------------------------------------------------------------------

def test_ses_commands_importable():
    from msapling_cli import ses_commands
    assert ses_commands is not None


def test_ses_app_is_typer():
    import typer
    from msapling_cli.ses_commands import ses_app
    assert isinstance(ses_app, typer.Typer)


def test_ses_score_command_registered():
    from msapling_cli.ses_commands import ses_app
    names = [cmd.name or "" for cmd in ses_app.registered_commands]
    assert "score" in names, f"ses score not found: {names}"


def test_ses_top_command_registered():
    from msapling_cli.ses_commands import ses_app
    names = [cmd.name or "" for cmd in ses_app.registered_commands]
    assert "top" in names, f"ses top not found: {names}"


def test_ses_compare_command_registered():
    from msapling_cli.ses_commands import ses_app
    names = [cmd.name or "" for cmd in ses_app.registered_commands]
    assert "compare" in names, f"ses compare not found: {names}"


def test_ses_app_mounted_in_main():
    """ses sub-app must be mounted as 'ses' in the main app."""
    from msapling_cli import main
    # Typer groups appear as registered_groups
    group_names = [g.name for g in getattr(main.app, "registered_groups", [])]
    assert "ses" in group_names, f"ses group not mounted in main app: {group_names}"


# ---------------------------------------------------------------------------
# 6. spinner added to other commands (source assertions)
# ---------------------------------------------------------------------------

def test_models_command_uses_spinner():
    import inspect as _inspect
    from msapling_cli import main
    src = _inspect.getsource(main.models)
    assert "working_spinner" in src, "models command must use working_spinner"


def test_projects_command_uses_spinner():
    import inspect as _inspect
    from msapling_cli import main
    src = _inspect.getsource(main.projects)
    assert "working_spinner" in src, "projects command must use working_spinner"


def test_whoami_command_uses_spinner():
    import inspect as _inspect
    from msapling_cli import main
    src = _inspect.getsource(main.whoami)
    assert "working_spinner" in src, "whoami command must use working_spinner"
