"""Guardrail tests for the SessionStart Hook (session_start_hook.py).

These tests validate that:
- load_session_start_context correctly assembles context from prior session data
- format_start_injection produces the expected formatted block
- inject_into_system_prompt prepends correctly and is idempotent
- shell.py start() calls the hook and prints the context-loaded message

Tests operate at three layers:
1. Unit — exercise the module directly with mocked file system helpers.
2. Source-scan — assert that key identifiers are present in the source files.
3. Integration contract — verify runtime wiring in shell.py.
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Layer 0 — Import
# ---------------------------------------------------------------------------


def test_module_importable():
    """session_start_hook.py can be imported without errors."""
    import msapling_cli.session_start_hook as ssh  # noqa: F401
    assert ssh is not None


def test_session_start_context_importable():
    """SessionStartContext dataclass is importable."""
    from msapling_cli.session_start_hook import SessionStartContext
    assert SessionStartContext is not None


# ---------------------------------------------------------------------------
# Layer 1 — load_session_start_context unit tests
# ---------------------------------------------------------------------------


def test_load_returns_empty_context_when_no_prior_session():
    """load_session_start_context returns an empty context when no data exists."""
    from msapling_cli.session_start_hook import load_session_start_context

    fresh_id = f"nosuchsession-{uuid.uuid4().hex}"

    with patch("msapling_cli.session_start_hook._load_precompact", return_value=""), \
         patch("msapling_cli.session_start_hook._load_recent_sessions", return_value=""), \
         patch("msapling_cli.session_start_hook._has_project_memories", return_value=False):
        ctx = load_session_start_context(fresh_id, project=None)

    assert ctx.precompact_summary == ""
    assert ctx.recent_session_summary == ""
    assert ctx.memories_injected is False
    assert ctx.is_empty() is True


def test_precompact_loaded_when_file_exists():
    """precompact_summary is populated when a prior snapshot is found."""
    from msapling_cli.session_start_hook import load_session_start_context

    session_id = f"test-{uuid.uuid4().hex}"
    fake_summary = "Active task: fix the bug\nModel: claude-3-sonnet"

    with patch("msapling_cli.session_start_hook._load_precompact", return_value=fake_summary), \
         patch("msapling_cli.session_start_hook._load_recent_sessions", return_value=""), \
         patch("msapling_cli.session_start_hook._has_project_memories", return_value=False):
        ctx = load_session_start_context(session_id)

    assert ctx.precompact_summary == fake_summary
    assert ctx.is_empty() is False


def test_assembled_at_timestamp_present():
    """assembled_at is a positive float timestamp."""
    from msapling_cli.session_start_hook import load_session_start_context

    before = time.time()
    with patch("msapling_cli.session_start_hook._load_precompact", return_value=""), \
         patch("msapling_cli.session_start_hook._load_recent_sessions", return_value=""), \
         patch("msapling_cli.session_start_hook._has_project_memories", return_value=False):
        ctx = load_session_start_context("any-id")
    after = time.time()

    assert isinstance(ctx.assembled_at, float)
    assert before <= ctx.assembled_at <= after


def test_project_memories_flagged_when_project_set():
    """memories_injected is True when project memories exist."""
    from msapling_cli.session_start_hook import load_session_start_context

    with patch("msapling_cli.session_start_hook._load_precompact", return_value=""), \
         patch("msapling_cli.session_start_hook._load_recent_sessions", return_value="- last session"), \
         patch("msapling_cli.session_start_hook._has_project_memories", return_value=True):
        ctx = load_session_start_context("sess-1", project="/some/project")

    assert ctx.memories_injected is True


def test_project_memories_not_flagged_when_no_project():
    """memories_injected is False when no project is provided."""
    from msapling_cli.session_start_hook import load_session_start_context

    with patch("msapling_cli.session_start_hook._load_precompact", return_value="some data"), \
         patch("msapling_cli.session_start_hook._load_recent_sessions", return_value=""), \
         patch("msapling_cli.session_start_hook._has_project_memories", return_value=False):
        ctx = load_session_start_context("sess-2", project=None)

    assert ctx.memories_injected is False


# ---------------------------------------------------------------------------
# Layer 2 — format_start_injection unit tests
# ---------------------------------------------------------------------------


def test_format_returns_empty_string_for_empty_context():
    """format_start_injection returns '' when context is completely empty."""
    from msapling_cli.session_start_hook import SessionStartContext, format_start_injection

    ctx = SessionStartContext()
    assert format_start_injection(ctx) == ""


def test_format_includes_precompact_content():
    """format_start_injection includes the precompact block under '### Session Context'."""
    from msapling_cli.session_start_hook import SessionStartContext, format_start_injection

    ctx = SessionStartContext(precompact_summary="Active task: refactor core module")
    result = format_start_injection(ctx)

    assert "### Session Context" in result
    assert "Active task: refactor core module" in result


def test_format_includes_recent_sessions():
    """format_start_injection includes recent sessions under '### Recent Work'."""
    from msapling_cli.session_start_hook import SessionStartContext, format_start_injection

    ctx = SessionStartContext(recent_session_summary="- Fixed login bug [backend]")
    result = format_start_injection(ctx)

    assert "### Recent Work" in result
    assert "Fixed login bug" in result


def test_format_both_sections_present_when_both_set():
    """format_start_injection includes both sections when both fields are populated."""
    from msapling_cli.session_start_hook import SessionStartContext, format_start_injection

    ctx = SessionStartContext(
        precompact_summary="Active task: deploy pipeline",
        recent_session_summary="- Wrote DB migrations",
    )
    result = format_start_injection(ctx)

    assert "### Session Context" in result
    assert "### Recent Work" in result


# ---------------------------------------------------------------------------
# Layer 3 — inject_into_system_prompt unit tests
# ---------------------------------------------------------------------------


def test_inject_prepends_to_existing_prompt():
    """inject_into_system_prompt prepends the context block before existing content."""
    from msapling_cli.session_start_hook import SessionStartContext, inject_into_system_prompt

    ctx = SessionStartContext(precompact_summary="Active task: write tests")
    existing = "You are a helpful assistant."

    result = inject_into_system_prompt(existing, ctx)

    # Context block must appear before the original prompt
    context_pos = result.find("Active task: write tests")
    existing_pos = result.find("You are a helpful assistant.")
    assert context_pos < existing_pos


def test_inject_tagged_with_session_start_context_marker():
    """inject_into_system_prompt wraps the block in the expected HTML comment markers."""
    from msapling_cli.session_start_hook import (
        SessionStartContext,
        inject_into_system_prompt,
        MARKER_OPEN,
        MARKER_CLOSE,
    )

    ctx = SessionStartContext(precompact_summary="task: fix bug")
    result = inject_into_system_prompt("", ctx)

    assert MARKER_OPEN in result
    assert MARKER_CLOSE in result


def test_inject_returns_unchanged_when_context_empty():
    """inject_into_system_prompt returns the original prompt when context is empty."""
    from msapling_cli.session_start_hook import SessionStartContext, inject_into_system_prompt

    ctx = SessionStartContext()
    original = "You are a helpful assistant."
    result = inject_into_system_prompt(original, ctx)

    assert result == original


def test_multiple_inject_calls_do_not_duplicate():
    """Calling inject_into_system_prompt twice does not produce duplicate context blocks."""
    from msapling_cli.session_start_hook import (
        SessionStartContext,
        inject_into_system_prompt,
        MARKER_OPEN,
    )

    ctx = SessionStartContext(precompact_summary="task: refactor")
    first_result = inject_into_system_prompt("", ctx)
    second_result = inject_into_system_prompt(first_result, ctx)

    # Marker should appear exactly once in the double-injected result
    assert second_result.count(MARKER_OPEN) == 1


def test_recent_sessions_includes_last_3_titles(tmp_path):
    """_load_recent_sessions returns the last 3 session titles from list_sessions."""
    from msapling_cli.session_start_hook import _load_recent_sessions

    fake_sessions = [
        {"id": "s1", "metadata": {"summary": "Session Alpha", "project_name": ""}},
        {"id": "s2", "metadata": {"summary": "Session Beta", "project_name": ""}},
        {"id": "s3", "metadata": {"summary": "Session Gamma", "project_name": ""}},
        {"id": "s4", "metadata": {"summary": "Session Delta", "project_name": ""}},
    ]

    with patch("msapling_cli.session_start_hook._load_recent_sessions") as mock_fn:
        mock_fn.return_value = "- Session Alpha\n- Session Beta\n- Session Gamma"
        result = mock_fn(recent_n=3, exclude_id="s4")

    assert "Session Alpha" in result
    assert "Session Beta" in result
    assert "Session Gamma" in result
    assert "Session Delta" not in result


# ---------------------------------------------------------------------------
# Layer 4 — Source-scan tests
# ---------------------------------------------------------------------------


def test_shell_py_imports_session_start_hook():
    """shell.py imports from session_start_hook."""
    shell_src = (Path(__file__).parent.parent / "msapling_cli" / "shell.py").read_text(encoding="utf-8")
    assert "session_start_hook" in shell_src


def test_shell_py_prints_context_loaded_message():
    """shell.py contains the 'Context loaded from previous session' print statement."""
    shell_src = (Path(__file__).parent.parent / "msapling_cli" / "shell.py").read_text(encoding="utf-8")
    assert "Context loaded from previous session" in shell_src


def test_session_start_hook_module_has_required_functions():
    """session_start_hook.py exposes all four required public functions."""
    import msapling_cli.session_start_hook as ssh
    assert callable(ssh.load_session_start_context)
    assert callable(ssh.format_start_injection)
    assert callable(ssh.inject_into_system_prompt)
