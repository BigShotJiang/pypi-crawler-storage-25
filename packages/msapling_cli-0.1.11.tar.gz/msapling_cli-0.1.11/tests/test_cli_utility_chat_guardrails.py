"""Guardrail tests for CLI utility chat isolation.

Verifies that one-shot headless invocations route to a dedicated
'CLI Utility' project instead of polluting Default Project.
"""
from __future__ import annotations

import asyncio
import inspect
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# 1. Constants
# ---------------------------------------------------------------------------

def test_cli_utility_project_name_constant_exists():
    from msapling_cli.api import CLI_UTILITY_PROJECT_NAME
    assert isinstance(CLI_UTILITY_PROJECT_NAME, str)
    assert CLI_UTILITY_PROJECT_NAME != ""


def test_cli_utility_project_name_is_not_default_project():
    from msapling_cli.api import CLI_UTILITY_PROJECT_NAME, DEFAULT_PROJECT_NAME
    assert CLI_UTILITY_PROJECT_NAME != DEFAULT_PROJECT_NAME, (
        "CLI utility chats must use a separate project from Default Project"
    )


def test_cli_utility_project_name_value():
    from msapling_cli.api import CLI_UTILITY_PROJECT_NAME
    assert CLI_UTILITY_PROJECT_NAME == "CLI Utility"


# ---------------------------------------------------------------------------
# 2. ensure_utility_chat method structure
# ---------------------------------------------------------------------------

def test_ensure_utility_chat_exists_on_client():
    from msapling_cli.api import MSaplingClient
    assert hasattr(MSaplingClient, "ensure_utility_chat"), (
        "MSaplingClient must have ensure_utility_chat method"
    )


def test_ensure_utility_chat_is_async():
    from msapling_cli.api import MSaplingClient
    assert asyncio.iscoroutinefunction(MSaplingClient.ensure_utility_chat)


def test_ensure_utility_chat_accepts_model_param():
    from msapling_cli.api import MSaplingClient
    sig = inspect.signature(MSaplingClient.ensure_utility_chat)
    assert "model" in sig.parameters


# ---------------------------------------------------------------------------
# 3. ensure_utility_chat delegates to ensure_server_chat correctly
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ensure_utility_chat_uses_utility_project():
    """ensure_utility_chat must pass CLI_UTILITY_PROJECT_NAME to ensure_server_chat."""
    from msapling_cli.api import MSaplingClient, CLI_UTILITY_PROJECT_NAME

    called_with: dict = {}

    async def fake_ensure(*, project_name, title, model, client_type, reuse):
        called_with["project_name"] = project_name
        called_with["client_type"] = client_type
        called_with["reuse"] = reuse
        called_with["title"] = title
        return "fake-chat-id"

    client = MSaplingClient.__new__(MSaplingClient)
    client.ensure_server_chat = fake_ensure

    result = await client.ensure_utility_chat(model="google/gemini-2.0-flash-001")

    assert result == "fake-chat-id"
    assert called_with["project_name"] == CLI_UTILITY_PROJECT_NAME
    assert called_with["reuse"] is True


@pytest.mark.asyncio
async def test_ensure_utility_chat_uses_cli_utility_client_type():
    from msapling_cli.api import MSaplingClient

    called_with: dict = {}

    async def fake_ensure(*, project_name, title, model, client_type, reuse):
        called_with["client_type"] = client_type
        return "fake-chat-id"

    client = MSaplingClient.__new__(MSaplingClient)
    client.ensure_server_chat = fake_ensure

    await client.ensure_utility_chat(model="openai/gpt-4o")
    assert called_with["client_type"] == "cli-utility"


@pytest.mark.asyncio
async def test_ensure_utility_chat_title_includes_model_short_name():
    """Title should include the short model name (after last '/') for readability."""
    from msapling_cli.api import MSaplingClient

    called_with: dict = {}

    async def fake_ensure(*, project_name, title, model, client_type, reuse):
        called_with["title"] = title
        return "chat-id"

    client = MSaplingClient.__new__(MSaplingClient)
    client.ensure_server_chat = fake_ensure

    await client.ensure_utility_chat(model="google/gemini-2.0-flash-001")
    assert "gemini-2.0-flash-001" in called_with["title"]


@pytest.mark.asyncio
async def test_ensure_utility_chat_reuse_true():
    """ensure_utility_chat must always set reuse=True (prevents new chat per invocation)."""
    from msapling_cli.api import MSaplingClient

    called_with: dict = {}

    async def fake_ensure(*, project_name, title, model, client_type, reuse):
        called_with["reuse"] = reuse
        return "chat-id"

    client = MSaplingClient.__new__(MSaplingClient)
    client.ensure_server_chat = fake_ensure

    await client.ensure_utility_chat(model="anthropic/claude-3-opus")
    assert called_with["reuse"] is True, "reuse must be True to prevent chat proliferation"


# ---------------------------------------------------------------------------
# 4. _headless uses ensure_utility_chat (not bare ensure_server_chat)
# ---------------------------------------------------------------------------

def test_headless_source_uses_ensure_utility_chat():
    """_headless() must call ensure_utility_chat, not create a raw 'CLI Headless' chat."""
    import inspect as _inspect
    from msapling_cli import main
    source = _inspect.getsource(main._headless)
    assert "ensure_utility_chat" in source, (
        "_headless must call ensure_utility_chat to avoid Default Project pollution"
    )


def test_headless_source_does_not_use_cli_headless_title():
    """_headless() must not create a 'CLI Headless' chat in Default Project."""
    import inspect as _inspect
    from msapling_cli import main
    source = _inspect.getsource(main._headless)
    assert "CLI Headless" not in source, (
        "CLI Headless title creates chats in Default Project — use ensure_utility_chat instead"
    )


def test_headless_source_does_not_use_cli_headless_client_type():
    """_headless() must not use client_type='cli-headless' which creates Default Project chats."""
    import inspect as _inspect
    from msapling_cli import main
    source = _inspect.getsource(main._headless)
    assert "cli-headless" not in source, (
        "cli-headless client_type creates chats in Default Project — use ensure_utility_chat"
    )
