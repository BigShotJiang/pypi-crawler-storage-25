"""Guardrail tests for TUI footer (StatusBar) and rich.table listing commands.

10 tests covering:
1. status_bar.py module exists
2. StatusBar class defined
3. render() returns Rich Text
4. Active model shown in status bar
5. Token count shown in status bar
6. Connection status shown in status bar
7. Environment field shown in status bar
8. Status bar not started when non-TTY
9. /projects listing uses rich.table
10. /chats listing uses rich.table
"""
from __future__ import annotations

import importlib
import inspect
import sys
import types
import unittest.mock as mock

import pytest
from rich.text import Text


# ── Test 1: status_bar.py module exists ──────────────────────────���───────────

def test_status_bar_module_exists():
    """status_bar.py must be importable from msapling_cli."""
    mod = importlib.import_module("msapling_cli.status_bar")
    assert mod is not None


# ── Test 2: StatusBar class is defined ───────────────────────────────────────

def test_status_bar_class_defined():
    """StatusBar class must be defined in the status_bar module."""
    from msapling_cli.status_bar import StatusBar
    assert inspect.isclass(StatusBar)


# ── Helper: build a minimal shell stub ──────────────────────────────��────────

def _make_shell_stub(model: str = "anthropic/claude-3-haiku", tokens: int = 0) -> mock.MagicMock:
    shell = mock.MagicMock()
    shell.model = model
    shell.tokens_total = tokens
    shell.no_tui = True  # disable Live in unit tests
    return shell


# ── Test 3: render() returns Rich Text ───────────────────────────────────────

def test_status_bar_render_returns_rich_text():
    """StatusBar.render() must return a rich.text.Text instance."""
    from msapling_cli.status_bar import StatusBar
    bar = StatusBar(_make_shell_stub())
    result = bar.render()
    assert isinstance(result, Text), f"Expected Text, got {type(result)}"


# ── Test 4: Active model shown in status bar ─────────────────────────────────

def test_status_bar_shows_active_model():
    """The rendered bar must include (the short form of) the active model."""
    from msapling_cli.status_bar import StatusBar
    bar = StatusBar(_make_shell_stub(model="anthropic/claude-3-haiku"))
    rendered = bar.render()
    plain = rendered.plain
    assert "claude-3-haiku" in plain, f"Model not found in: {plain!r}"


# ── Test 5: Token count shown in status bar ──────────────────────────────────

def test_status_bar_shows_token_count():
    """The rendered bar must display the session token count."""
    from msapling_cli.status_bar import StatusBar
    bar = StatusBar(_make_shell_stub(tokens=1247))
    rendered = bar.render()
    plain = rendered.plain
    # "1,247 tokens" or "1247 tokens" — either formatting is acceptable
    assert "1,247" in plain or "1247" in plain, f"Token count not found in: {plain!r}"


# ── Test 6: Connection status shown in status bar ────────────────────────────

def test_status_bar_shows_connection_status():
    """Rendered bar must contain a connection status indicator."""
    from msapling_cli.status_bar import StatusBar, CONN_CONNECTED, CONN_DISCONNECTED, CONN_CHECKING
    bar = StatusBar(_make_shell_stub())

    bar.update(connected=CONN_CONNECTED)
    plain_conn = bar.render().plain
    assert "Connected" in plain_conn, f"Connected not in: {plain_conn!r}"

    bar.update(connected=CONN_DISCONNECTED)
    plain_disc = bar.render().plain
    assert "Disconnected" in plain_disc, f"Disconnected not in: {plain_disc!r}"

    bar.update(connected=CONN_CHECKING)
    plain_check = bar.render().plain
    assert "Checking" in plain_check, f"Checking not in: {plain_check!r}"


# ── Test 7: Environment field shown in status bar ────────────────────────────

def test_status_bar_shows_environment():
    """Rendered bar must include the environment label."""
    from msapling_cli.status_bar import StatusBar
    bar = StatusBar(_make_shell_stub())
    bar.update(environment="lab")
    plain = bar.render().plain
    assert "lab" in plain, f"Environment 'lab' not in: {plain!r}"

    bar.update(environment="prod")
    plain2 = bar.render().plain
    assert "prod" in plain2, f"Environment 'prod' not in: {plain2!r}"


# ── Test 8: Status bar not started when non-TTY ──────────────────────────────

def test_status_bar_not_started_when_non_tty():
    """StatusBar.start() must not activate when stdout is not a TTY."""
    from msapling_cli.status_bar import StatusBar
    bar = StatusBar(_make_shell_stub())
    # Patch _is_tty to return False
    with mock.patch("msapling_cli.status_bar._is_tty", return_value=False):
        bar.start(force=False)
    # The bar should not be active
    assert not bar._active, "StatusBar should not start in non-TTY mode"


# ── Test 9: /projects uses rich.table ────────────────────────────────────────

@pytest.mark.asyncio
async def test_projects_listing_uses_rich_table():
    """_cmd_list_projects must render output using rich.table.Table."""
    import rich.table as _rt
    from msapling_cli.shell import InteractiveShell

    # Build a shell without connecting to the server
    shell = InteractiveShell.__new__(InteractiveShell)
    shell.user = {"tier": "free", "fuel_credits": 5.0}
    shell.project_name = "test-project"

    # Stub client.projects_overview
    async def _fake_overview(_user):
        return {
            "projects": [
                {
                    "name": "alpha",
                    "chat_count": 2,
                    "chat_limit": 6,
                    "is_full": False,
                    "model": "anthropic/claude-3-haiku",
                    "updated_at": "2025-01-01T00:00:00Z",
                },
                {
                    "name": "beta",
                    "chat_count": 6,
                    "chat_limit": 6,
                    "is_full": True,
                    "model": "",
                    "updated_at": "",
                },
            ],
            "project_limit": 10,
            "can_create_project": True,
        }

    shell.client = mock.MagicMock()
    shell.client.projects_overview = _fake_overview

    tables_printed: list = []

    import rich.console as _rc
    original_print = _rc.Console.print

    def _capture_print(self_console, *args, **kwargs):
        for a in args:
            if isinstance(a, _rt.Table):
                tables_printed.append(a)
        return original_print(self_console, *args, **kwargs)

    with mock.patch.object(_rc.Console, "print", _capture_print):
        await shell._cmd_list_projects()

    assert tables_printed, "/projects must print at least one rich.table.Table"


# ── Test 10: /chats uses rich.table ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_chats_listing_uses_rich_table():
    """/chats (_cmd_list_chats) must render output using rich.table.Table."""
    import rich.table as _rt
    from msapling_cli.shell import InteractiveShell

    shell = InteractiveShell.__new__(InteractiveShell)
    shell.user = {"tier": "free", "fuel_credits": 5.0}
    shell.project_name = "test-project"

    async def _fake_list_chats(_project):
        return [
            {
                "id": "chat-1",
                "title": "My Chat",
                "model": "anthropic/claude-3-haiku",
                "message_count": 12,
                "cost_usd": 0.0034,
                "updated_at": "2025-01-01T00:00:00Z",
            }
        ]

    shell.client = mock.MagicMock()
    shell.client.list_project_chats = _fake_list_chats

    tables_printed: list = []

    import rich.console as _rc
    original_print = _rc.Console.print

    def _capture_print(self_console, *args, **kwargs):
        for a in args:
            if isinstance(a, _rt.Table):
                tables_printed.append(a)
        return original_print(self_console, *args, **kwargs)

    with mock.patch.object(_rc.Console, "print", _capture_print):
        await shell._cmd_list_chats()

    assert tables_printed, "/chats must print at least one rich.table.Table"
