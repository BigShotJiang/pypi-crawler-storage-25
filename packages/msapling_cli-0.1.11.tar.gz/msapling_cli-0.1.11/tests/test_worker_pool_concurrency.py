"""Concurrency stress tests for WorkerPool.

Tests verify that WorkerPool is thread-safe under concurrent access:
- notify_file_written from many threads
- drain_events while events are being added concurrently
- task_done notifies all waiting threads
"""
from __future__ import annotations

import threading
import time
from typing import List

import pytest

from msapling_cli.worker_pool import Worker, WorkerEvent, WorkerPool


# ---------------------------------------------------------------------------
# 1. test_concurrent_notify_file_written
# ---------------------------------------------------------------------------

def test_concurrent_notify_file_written():
    """10 threads calling notify_file_written concurrently produce no exceptions."""
    pool = WorkerPool("test-project")
    pool.add_worker("w1", "c1", "m1")
    pool.add_worker("w2", "c2", "m2")

    errors: List[Exception] = []

    def _write(i: int):
        try:
            pool.notify_file_written("w1", f"file_{i}.py")
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=_write, args=(i,)) for i in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5)

    assert errors == [], f"Exceptions raised during concurrent writes: {errors}"
    # w1 should have all 10 file paths recorded
    assert len(pool.workers[0].files_written) == 10


def test_concurrent_notify_file_written_event_count():
    """Events from notify_file_written are received by other workers, not self."""
    pool = WorkerPool("project")
    pool.add_worker("alpha", "c1", "m1")
    pool.add_worker("beta", "c2", "m2")

    n = 8

    def _notify(i: int):
        pool.notify_file_written("alpha", f"file_{i}.py")

    threads = [threading.Thread(target=_notify, args=(i,)) for i in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5)

    # beta should have received n events (one per file write from alpha)
    beta = pool.get_worker("beta")
    with beta._events_lock:
        event_count = len(beta._pending_events)
    assert event_count == n

    # alpha should NOT have received its own events
    alpha = pool.get_worker("alpha")
    with alpha._events_lock:
        self_event_count = sum(
            1 for e in alpha._pending_events if e.source == "alpha"
        )
    assert self_event_count == 0


# ---------------------------------------------------------------------------
# 2. test_drain_events_atomic
# ---------------------------------------------------------------------------

def test_drain_events_atomic():
    """While draining, concurrent additions don't cause event loss."""
    pool = WorkerPool("project")
    pool.add_worker("producer", "c1", "m1")
    pool.add_worker("consumer", "c2", "m2")

    consumer = pool.get_worker("consumer")
    all_events_seen: List[str] = []
    stop_flag = threading.Event()
    n_produce = 50

    def _produce():
        """Continuously add events until stopped."""
        for i in range(n_produce):
            pool.notify_file_written("producer", f"gen_{i}.py")
            time.sleep(0.0005)  # ~0.5 ms gap to interleave with drainer

    def _drain():
        """Drain events repeatedly until stop_flag is set."""
        while not stop_flag.is_set():
            events_text = consumer.drain_events()
            if events_text:
                all_events_seen.append(events_text)
            time.sleep(0.001)
        # Final drain to catch any remaining events
        events_text = consumer.drain_events()
        if events_text:
            all_events_seen.append(events_text)

    producer_thread = threading.Thread(target=_produce)
    drainer_thread = threading.Thread(target=_drain)

    drainer_thread.start()
    producer_thread.start()
    producer_thread.join(timeout=10)
    stop_flag.set()
    drainer_thread.join(timeout=5)

    # Count total events by summing lines across all drain results
    total_seen = sum(chunk.count("\n") + 1 for chunk in all_events_seen if chunk.strip())

    # All 50 events must be accounted for (no loss)
    assert total_seen == n_produce, (
        f"Expected {n_produce} events, got {total_seen}. "
        "Possible race condition in drain_events."
    )

    # After everything, consumer's queue must be empty
    assert consumer.drain_events() == ""


# ---------------------------------------------------------------------------
# 3. test_task_done_signals_all_waiters
# ---------------------------------------------------------------------------

def test_task_done_signals_all_waiters():
    """notify_task_done broadcasts to all workers and sets status to 'done'."""
    pool = WorkerPool("project")
    pool.add_worker("builder", "c1", "m1")
    pool.add_worker("tester", "c2", "m2")
    pool.add_worker("reviewer", "c3", "m3")

    received: List[str] = []
    lock = threading.Lock()

    def _notify():
        pool.notify_task_done("builder", "Build complete")

    # Run notify_task_done from multiple threads simultaneously
    threads = [threading.Thread(target=_notify) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5)

    # builder status should be "done"
    builder = pool.get_worker("builder")
    assert builder.status == "done"

    # Each other worker should have received task_done events
    tester = pool.get_worker("tester")
    reviewer = pool.get_worker("reviewer")

    with tester._events_lock:
        tester_types = [e.event_type for e in tester._pending_events]
    with reviewer._events_lock:
        reviewer_types = [e.event_type for e in reviewer._pending_events]

    assert all(t == "task_done" for t in tester_types)
    assert all(t == "task_done" for t in reviewer_types)
    # 5 broadcasts * 1 event each
    assert len(tester_types) == 5
    assert len(reviewer_types) == 5


def test_concurrent_add_worker_is_thread_safe():
    """Concurrent add_worker calls do not exceed MAX_WORKERS and don't crash."""
    from msapling_cli.worker_pool import MAX_WORKERS

    pool = WorkerPool("project")
    errors: List[Exception] = []

    def _add(i: int):
        try:
            pool.add_worker(f"w{i}", f"c{i}", "model")
        except ValueError:
            pass  # Expected when pool is full
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=_add, args=(i,)) for i in range(MAX_WORKERS + 4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5)

    assert errors == [], f"Unexpected exceptions: {errors}"
    assert len(pool.workers) <= MAX_WORKERS
