"""Guardrail tests for export_formats.py.

Run with:
    python -m pytest cli/tests/test_export_formats_guardrails.py -q
"""
from __future__ import annotations

import importlib.util
import inspect
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import patch, MagicMock

import pytest

# ── Helpers ─────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_MODULE_PATH = _PKG_DIR / "export_formats.py"


def _import_module():
    spec = importlib.util.spec_from_file_location(
        "msapling_cli.export_formats", str(_MODULE_PATH)
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[union-attr]
    return mod


def _make_session(
    messages: Optional[List[Dict[str, str]]] = None,
    project_name: str = "test-project",
    model: str = "claude-3-5-sonnet",
    cost: float = 0.0042,
    session_id: str = "abc123",
    duration: Optional[float] = 120.0,
) -> Dict[str, Any]:
    msgs = messages if messages is not None else [
        {"role": "user", "content": "Hello, explain this code."},
        {"role": "assistant", "content": "Sure! Here is an explanation."},
        {"role": "user", "content": "Can you refactor it?"},
        {"role": "assistant", "content": "```python\ndef foo():\n    return 42\n```"},
    ]
    return {
        "id": session_id,
        "messages": msgs,
        "model": model,
        "project_root": f"/projects/{project_name}",
        "cost_total": cost,
        "tokens_total": 500,
        "metadata": {
            "session_id": session_id,
            "project_name": project_name,
            "models_used": [model],
            "files_touched": ["src/main.py"],
            "total_cost_usd": cost,
            "total_tokens_in": 300,
            "total_tokens_out": 200,
            "started_at": "2026-04-17T10:00:00Z",
            "ended_at": "2026-04-17T10:02:00Z",
            "duration_seconds": duration,
            "turn_count": 2,
            "summary": None,
        },
    }


# ── Test 1: Module imports without error ─────────────────────────────────────

def test_module_imports():
    """export_formats.py must import cleanly."""
    mod = _import_module()
    assert mod is not None


# ── Test 2: HTML export produces valid HTML structure ────────────────────────

def test_html_export_produces_valid_html():
    """export_html() must produce a document containing <html>, <head>, <body>."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "<html" in content.lower()
    assert "<head>" in content.lower() or "<head " in content.lower()
    assert "<body>" in content.lower() or "<body " in content.lower()


# ── Test 3: HTML export contains session messages ────────────────────────────

def test_html_export_contains_messages():
    """export_html() must embed message content in the output."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "Hello, explain this code." in content
    assert "Sure! Here is an explanation." in content


# ── Test 4: HTML is self-contained (no external script/link tags) ────────────

def test_html_self_contained_no_external_deps():
    """export_html() must not include external <script src=...> or <link href=...> tags."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8").lower()
    # No external script src
    import re
    external_script = re.search(r'<script[^>]+src=["\']https?://', content)
    assert external_script is None, "HTML must not contain external script tags"
    # No external link stylesheet
    external_link = re.search(r'<link[^>]+href=["\']https?://', content)
    assert external_link is None, "HTML must not contain external link/stylesheet tags"


# ── Test 5: HTML contains session metadata (project, cost) ───────────────────

def test_html_contains_metadata():
    """export_html() must embed project name and cost in the document."""
    mod = _import_module()
    session = _make_session(project_name="my-cool-project", cost=0.1234)
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "my-cool-project" in content
    assert "0.1234" in content


# ── Test 6: HTML code blocks wrapped in <pre><code> ──────────────────────────

def test_html_code_blocks_use_pre_code():
    """export_html() must wrap fenced code blocks with <pre><code>...</code></pre>."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "<pre>" in content
    assert "<code" in content


# ── Test 7: Markdown export produces # headers and ** bold ───────────────────

def test_markdown_export_structure():
    """export_markdown() must produce lines starting with # and ** in the output."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.md"
        result = mod.export_markdown(session, out)
        content = result.read_text(encoding="utf-8")
    assert any(line.startswith("#") for line in content.splitlines())
    assert "**" in content


# ── Test 8: Markdown export contains messages ────────────────────────────────

def test_markdown_export_contains_messages():
    """export_markdown() must include user and assistant message content."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.md"
        result = mod.export_markdown(session, out)
        content = result.read_text(encoding="utf-8")
    assert "Hello, explain this code." in content
    assert "Sure! Here is an explanation." in content


# ── Test 9: PDF falls back gracefully when weasyprint absent ─────────────────

def test_pdf_fallback_when_weasyprint_missing():
    """export_pdf() must produce an HTML fallback when weasyprint is not installed."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.pdf"
        with patch.dict("sys.modules", {"weasyprint": None}):
            result = mod.export_pdf(session, out)
        # Fallback should produce an HTML file (not crash)
        assert result.exists()
        assert result.suffix in (".html", ".pdf")


# ── Test 10: PDF fallback HTML contains print note ───────────────────────────

def test_pdf_fallback_html_has_print_note():
    """export_pdf() fallback HTML must include a note about printing to PDF."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.pdf"
        with patch.dict("sys.modules", {"weasyprint": None}):
            result = mod.export_pdf(session, out)
        content = result.read_text(encoding="utf-8")
    assert "print" in content.lower() or "pdf" in content.lower()


# ── Test 11: auto_generate_summary produces 1-3 sentences ────────────────────

def test_auto_generate_summary_length():
    """auto_generate_summary() must return 1-3 sentences."""
    mod = _import_module()
    session = _make_session()
    summary = mod.auto_generate_summary(session)
    assert isinstance(summary, str)
    assert len(summary) > 10
    # Count sentence-ending punctuation
    import re
    sentences = re.split(r"[.!?]+\s*", summary.strip())
    non_empty = [s for s in sentences if s.strip()]
    assert 1 <= len(non_empty) <= 5, f"Expected 1-3 sentences, got {len(non_empty)}: {summary!r}"


# ── Test 12: auto_generate_summary includes date and model ───────────────────

def test_auto_generate_summary_includes_key_fields():
    """auto_generate_summary() must include date, model, and cost."""
    mod = _import_module()
    session = _make_session(cost=0.0042, model="claude-3-5-sonnet")
    summary = mod.auto_generate_summary(session)
    assert "2026-04-17" in summary or "2026" in summary
    assert "claude-3-5-sonnet" in summary
    assert "0.0042" in summary


# ── Test 13: export creates parent directories ────────────────────────────────

def test_export_creates_parent_dirs():
    """All export functions must create parent directories if they don't exist."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        # Deeply nested path that does not exist
        out = Path(tmp) / "a" / "b" / "c" / "export.html"
        result = mod.export_html(session, out)
        assert result.exists()


# ── Test 14: Empty session exports without crash ─────────────────────────────

def test_empty_session_exports_without_crash():
    """All export functions must handle an empty session dict without crashing."""
    mod = _import_module()
    empty_session: Dict[str, Any] = {
        "id": "empty",
        "messages": [],
        "model": "",
        "metadata": {},
    }
    with tempfile.TemporaryDirectory() as tmp:
        html_out = mod.export_html(empty_session, Path(tmp) / "e.html")
        md_out = mod.export_markdown(empty_session, Path(tmp) / "e.md")
        assert html_out.exists()
        assert md_out.exists()


# ── Test 15: Empty session summary is valid ──────────────────────────────────

def test_empty_session_summary_is_valid():
    """auto_generate_summary() on an empty session must return a non-empty string."""
    mod = _import_module()
    empty_session: Dict[str, Any] = {"id": "empty", "messages": [], "metadata": {}}
    summary = mod.auto_generate_summary(empty_session)
    assert isinstance(summary, str)
    assert len(summary) > 5


# ── Test 16: export_markdown returns a Path object ───────────────────────────

def test_export_markdown_returns_path():
    """export_markdown() must return the absolute path to the written file."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "result.md"
        result = mod.export_markdown(session, out)
    assert isinstance(result, Path)
    assert result.is_absolute()


# ── Test 17: export_html returns a Path object ───────────────────────────────

def test_export_html_returns_path():
    """export_html() must return the absolute path to the written file."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "result.html"
        result = mod.export_html(session, out)
    assert isinstance(result, Path)
    assert result.is_absolute()


# ── Test 18: HTML user messages right-aligned class ─────────────────────────

def test_html_user_messages_have_user_class():
    """export_html() must mark user messages with CSS class 'user'."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert 'class="message user"' in content


# ── Test 19: HTML assistant messages have assistant class ────────────────────

def test_html_assistant_messages_have_assistant_class():
    """export_html() must mark assistant messages with CSS class 'assistant'."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert 'class="message assistant"' in content


# ── Test 20: System messages excluded from HTML output ───────────────────────

def test_html_system_messages_excluded():
    """export_html() must not render system-role messages as visible bubbles."""
    mod = _import_module()
    msgs = [
        {"role": "system", "content": "SECRET_SYSTEM_CONTEXT_12345"},
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi there"},
    ]
    session = _make_session(messages=msgs)
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "SECRET_SYSTEM_CONTEXT_12345" not in content


# ── Test 21: HTML file has DOCTYPE declaration ────────────────────────────────

def test_html_has_doctype():
    """export_html() output must start with <!DOCTYPE html>."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert content.strip().lower().startswith("<!doctype html>")


# ── Test 22: export_formats.py file exists and has substantial content ────────

def test_module_file_exists_and_substantial():
    """export_formats.py must exist and have >100 non-empty lines."""
    assert _MODULE_PATH.exists(), f"export_formats.py not found at {_MODULE_PATH}"
    lines = [l for l in _MODULE_PATH.read_text(encoding="utf-8").splitlines() if l.strip()]
    assert len(lines) > 100, f"export_formats.py too small ({len(lines)} lines)"


# ── Test 23: export functions are importable by name ─────────────────────────

def test_all_public_functions_exist():
    """export_formats module must export all four public functions."""
    mod = _import_module()
    for name in ("export_markdown", "export_html", "export_pdf", "auto_generate_summary"):
        assert hasattr(mod, name), f"Missing function: {name}"
        assert callable(getattr(mod, name))


# ── Test 24: HTML has inline <style> block, not <link rel=stylesheet> ─────────

def test_html_uses_inline_style_not_link():
    """export_html() must use an inline <style> block for CSS (self-contained)."""
    mod = _import_module()
    session = _make_session()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "export.html"
        result = mod.export_html(session, out)
        content = result.read_text(encoding="utf-8")
    assert "<style>" in content or "<style " in content
    # No external stylesheet link
    import re
    external_css = re.search(r'<link[^>]+rel=["\']stylesheet["\'][^>]+href=["\']https?://', content)
    assert external_css is None
