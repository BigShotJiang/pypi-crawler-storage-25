"""
Guardrail tests: MCP doctor diagnostics + MCP tool schema validation.

All tests are source-scan based — they verify that the required constructs
exist in the implementation files without importing or executing them.
"""
from __future__ import annotations

import ast
import pathlib
import re

MAIN_PY = pathlib.Path(__file__).parent.parent / "msapling_cli" / "main.py"
SERVER_PY = pathlib.Path(__file__).parent.parent / "msapling_cli" / "mcp" / "server.py"


def _source(path: pathlib.Path) -> str:
    return path.read_text(encoding="utf-8")


# ─── Task 1: doctor command MCP section ──────────────────────────────


def test_doctor_mcp_section_exists():
    """doctor command must reference an 'mcp' key in its report dict."""
    src = _source(MAIN_PY)
    assert '"mcp"' in src or "'mcp'" in src, (
        "doctor command must add an 'mcp' section to the report"
    )


def test_doctor_checks_MCP_TRANSPORT_env():
    """doctor command must read the MCP_TRANSPORT environment variable."""
    src = _source(MAIN_PY)
    assert "MCP_TRANSPORT" in src, (
        "doctor command must check os.environ for MCP_TRANSPORT"
    )


def test_doctor_reports_transport_source():
    """doctor command must distinguish env vs default transport source."""
    src = _source(MAIN_PY)
    assert "transport_source" in src, (
        "doctor command must track whether transport came from env or default"
    )


def test_doctor_checks_mcp_startable():
    """doctor command must check whether the mcp-serve module is importable."""
    src = _source(MAIN_PY)
    assert "mcp_startable" in src, (
        "doctor command must check if mcp module is startable"
    )
    assert "importlib" in src, (
        "doctor command must use importlib to check mcp module availability"
    )


def test_doctor_reads_mcp_last_handshake():
    """doctor command must read mcp_last_handshake from ~/.msapling/."""
    src = _source(MAIN_PY)
    assert "mcp_last_handshake" in src, (
        "doctor command must report last_handshake from ~/.msapling/mcp_last_handshake"
    )
    assert "never" in src, (
        "doctor command must default last_handshake to 'never' when file is absent"
    )


def test_doctor_reads_mcp_error_log():
    """doctor command must check ~/.msapling/mcp_error.log for transport errors."""
    src = _source(MAIN_PY)
    assert "mcp_error.log" in src, (
        "doctor command must read transport errors from ~/.msapling/mcp_error.log"
    )
    assert "mcp_transport_error" in src, (
        "doctor command must expose mcp_transport_error in the report"
    )


def test_doctor_prints_mcp_row():
    """doctor command must include an MCP row in the print_report call."""
    src = _source(MAIN_PY)
    # Verify the MCP label appears in a print_report tuple
    assert '"MCP"' in src or "'MCP'" in src, (
        "doctor command must pass an 'MCP' row to print_report"
    )


# ─── Task 2: MCP tool schema validation ──────────────────────────────


def test_tool_schemas_dict_exists():
    """TOOL_SCHEMAS must be defined as a dict in server.py."""
    src = _source(SERVER_PY)
    assert "TOOL_SCHEMAS" in src, (
        "server.py must define a TOOL_SCHEMAS dict"
    )
    assert "TOOL_SCHEMAS:" in src or "TOOL_SCHEMAS =" in src, (
        "TOOL_SCHEMAS must be a module-level assignment"
    )


def test_tool_schemas_covers_all_tools():
    """TOOL_SCHEMAS must have entries for all 11 registered tool names."""
    src = _source(SERVER_PY)
    tool_names = [
        "msapling_chat",
        "msapling_diff",
        "msapling_apply_diff",
        "msapling_search_files",
        "msapling_read_file",
        "msapling_write_file",
        "msapling_project_context",
        "msapling_cost_check",
        "msapling_models",
        "msapling_multi_chat",
        "msapling_swarm",
    ]
    for name in tool_names:
        assert f'"{name}"' in src or f"'{name}'" in src, (
            f"TOOL_SCHEMAS must contain an entry for tool '{name}'"
        )


def test_validate_tool_params_function_exists():
    """validate_tool_params function must be defined in server.py."""
    src = _source(SERVER_PY)
    assert "def validate_tool_params(" in src, (
        "server.py must define a validate_tool_params() function"
    )


def test_invalid_params_error_key():
    """validate_tool_params must return {'error': 'invalid_params', ...} on failure."""
    src = _source(SERVER_PY)
    assert "invalid_params" in src, (
        "validate_tool_params must use 'invalid_params' as the error key"
    )
    assert '"error"' in src or "'error'" in src, (
        "validate_tool_params must return a dict with an 'error' key"
    )


def test_jsonschema_fallback_present():
    """validate_tool_params must handle ImportError when jsonschema is not installed."""
    src = _source(SERVER_PY)
    assert "ImportError" in src, (
        "validate_tool_params must catch ImportError for jsonschema"
    )
    assert "jsonschema not installed" in src or "jsonschema" in src, (
        "validate_tool_params must log a warning when jsonschema is unavailable"
    )


def test_validate_wired_into_dispatch():
    """validate_tool_params must be called inside the tools/call dispatch block."""
    src = _source(SERVER_PY)
    assert "validate_tool_params(tool_name" in src, (
        "validate_tool_params must be called in the tools/call dispatch path"
    )


def test_validation_error_short_circuits_handler():
    """When validation fails the response must be sent and the handler must NOT run."""
    src = _source(SERVER_PY)
    # The guard block writes the error result and then continues/returns
    # so the handler code is never reached.
    assert "validation_error is not None" in src or "if validation_error" in src, (
        "dispatch must check validation_error before calling _handle_tool"
    )


def test_validate_tool_params_returns_none_on_success():
    """validate_tool_params must return None when params are valid."""
    src = _source(SERVER_PY)
    # The function returns None for the success path
    assert "return None" in src, (
        "validate_tool_params must return None when validation passes"
    )
