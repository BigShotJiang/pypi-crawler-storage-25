"""Guardrail tests for AgentShield — client-side hard gate for tool execution.

Run with:
    python -m pytest cli/tests/test_agentshield_guardrails.py -q

All tests run offline (no network, no backend required).
"""
from __future__ import annotations

import importlib
import importlib.util
import inspect
import json
import os
import sys
import tempfile
from pathlib import Path
from unittest import mock

import pytest

# ── Helpers ──────────────────────────────────────────────────────────────────

_CLI_ROOT = Path(__file__).parent.parent
_PKG_DIR = _CLI_ROOT / "msapling_cli"
_SHIELD_PATH = _PKG_DIR / "agentshield.py"
_SHELL_PATH = _PKG_DIR / "shell.py"
_MAIN_PATH = _PKG_DIR / "main.py"
_AGENT_PATH = _PKG_DIR / "agent.py"


def _import_shield():
    """Import agentshield.py directly to avoid heavyweight CLI side-effects."""
    mod_name = "msapling_cli.agentshield"
    spec = importlib.util.spec_from_file_location(mod_name, str(_SHIELD_PATH))
    mod = importlib.util.module_from_spec(spec)
    # Register in sys.modules before exec so dataclasses/typing can resolve
    # the module's __name__ during class decoration on Python 3.13+.
    sys.modules[mod_name] = mod
    try:
        spec.loader.exec_module(mod)
    except Exception:
        del sys.modules[mod_name]
        raise
    return mod


# ── Test 1: agentshield.py exists on disk ────────────────────────────────────


def test_agentshield_py_exists():
    """agentshield.py must exist at the expected path."""
    assert _SHIELD_PATH.exists(), f"agentshield.py not found at {_SHIELD_PATH}"
    assert _SHIELD_PATH.is_file()


# ── Test 2: AgentShield class is importable ───────────────────────────────────


def test_agentshield_class_importable():
    """AgentShield class must be importable without error."""
    mod = _import_shield()
    assert hasattr(mod, "AgentShield"), "AgentShield class not found in agentshield.py"
    assert inspect.isclass(mod.AgentShield)


# ── Test 3: check() method exists ────────────────────────────────────────────


def test_check_method_exists():
    """AgentShield.check() must exist and accept tool_name + command."""
    mod = _import_shield()
    shield = mod.AgentShield()
    assert hasattr(shield, "check"), "AgentShield must have a check() method"
    sig = inspect.signature(shield.check)
    assert "tool_name" in sig.parameters
    assert "command" in sig.parameters


# ── Test 4: rm -rf / → verdict=block ─────────────────────────────────────────


def test_rm_rf_root_is_blocked():
    """rm -rf / must return verdict='block' — this is permanently forbidden."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "rm -rf /")
    assert result.verdict == "block", (
        f"rm -rf / must be blocked, got verdict={result.verdict!r}"
    )


# ── Test 5: DROP DATABASE → verdict=block ────────────────────────────────────


def test_drop_database_is_blocked():
    """DROP DATABASE must return verdict='block'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "DROP DATABASE mydb")
    assert result.verdict == "block", (
        f"DROP DATABASE must be blocked, got verdict={result.verdict!r}"
    )


# ── Test 6: rm -rf ./tmp → verdict=confirm ────────────────────────────────────


def test_rm_rf_relative_requires_confirm():
    """rm -rf ./tmp must require confirmation (not a hard block)."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "rm -rf ./tmp")
    assert result.verdict == "confirm", (
        f"rm -rf ./tmp must require confirmation, got verdict={result.verdict!r}"
    )


# ── Test 7: ls -la → verdict=allow ───────────────────────────────────────────


def test_safe_command_is_allowed():
    """ls -la must pass all checks and return verdict='allow'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "ls -la")
    assert result.verdict == "allow", (
        f"ls -la must be allowed, got verdict={result.verdict!r}"
    )


# ── Test 8: DROP TABLE users → verdict=confirm ───────────────────────────────


def test_drop_table_requires_confirm():
    """DROP TABLE must require confirmation (not a hard block)."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "DROP TABLE users")
    assert result.verdict == "confirm", (
        f"DROP TABLE must require confirmation, got verdict={result.verdict!r}"
    )


# ── Test 9: Shield disabled → all return allow ───────────────────────────────


def test_disabled_shield_allows_everything():
    """When shield is disabled, even dangerous commands must return verdict='allow'."""
    mod = _import_shield()
    shield = mod.AgentShield()

    # Patch is_enabled to return False — avoids touching real config file
    with mock.patch.object(shield, "is_enabled", return_value=False):
        for cmd in ("rm -rf /", "DROP DATABASE x", "dd if=/dev/zero of=/dev/sda"):
            result = shield.check("run_command", cmd)
            assert result.verdict == "allow", (
                f"Disabled shield must allow {cmd!r}, got verdict={result.verdict!r}"
            )


# ── Test 10: ShieldResult.reason is non-empty for blocks ─────────────────────


def test_block_result_has_non_empty_reason():
    """ShieldResult.reason must be a non-empty string when verdict='block'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    # Use a command that is always hard-blocked (root rm -rf /)
    result = shield.check("run_command", "rm -rf /")
    assert result.verdict == "block"
    assert isinstance(result.reason, str), "reason must be a string"
    assert result.reason.strip(), "reason must not be empty"


# ── Test 11: ShieldResult.blocked_pattern is set on match ────────────────────


def test_blocked_pattern_set_on_match():
    """ShieldResult.blocked_pattern must be populated when a pattern triggers."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "DROP DATABASE prod")
    assert result.verdict == "block"
    assert result.blocked_pattern is not None, (
        "ShieldResult.blocked_pattern must be set when a rule triggers"
    )
    assert isinstance(result.blocked_pattern, str)
    assert result.blocked_pattern.strip()


# ── Test 12: BLOCKED_ALWAYS has 4+ patterns ──────────────────────────────────


def test_blocked_always_has_minimum_patterns():
    """BLOCKED_ALWAYS class attribute must contain at least 4 patterns."""
    mod = _import_shield()
    count = len(mod.AgentShield.BLOCKED_ALWAYS)
    assert count >= 4, (
        f"AgentShield.BLOCKED_ALWAYS must have >= 4 patterns, found {count}"
    )


# ── Test 13: REQUIRES_CONFIRMATION has 4+ patterns ───────────────────────────


def test_requires_confirmation_has_minimum_patterns():
    """REQUIRES_CONFIRMATION class attribute must contain at least 4 patterns."""
    mod = _import_shield()
    count = len(mod.AgentShield.REQUIRES_CONFIRMATION)
    assert count >= 4, (
        f"AgentShield.REQUIRES_CONFIRMATION must have >= 4 patterns, found {count}"
    )


# ── Test 14: is_enabled() reads from config ───────────────────────────────────


def test_is_enabled_reads_from_config():
    """is_enabled() must reflect config key 'agentshield_enabled'."""
    mod = _import_shield()
    shield = mod.AgentShield()

    with tempfile.TemporaryDirectory() as tmp:
        fake_config = Path(tmp) / "config.json"
        fake_config.write_text(json.dumps({"agentshield_enabled": False}), encoding="utf-8")

        # Patch the module-level _CONFIG_FILE to point to our temp config
        with mock.patch.object(mod, "_CONFIG_FILE", fake_config):
            # Also patch the internal helper to use same fake path
            disabled = shield.is_enabled()
        # We can't guarantee the test env config differs, so just confirm
        # the function is callable and returns a bool
    assert isinstance(shield.is_enabled(), bool), "is_enabled() must return a bool"


# ── Test 15: Config shield subcommand registered in main.py ──────────────────


def test_config_shield_command_registered():
    """main.py must register 'config shield' with enable/disable/status subcommands."""
    source = _MAIN_PATH.read_text(encoding="utf-8")
    assert "shield_app" in source, (
        "main.py must define shield_app typer sub-application"
    )
    assert "shield enable" in source or 'name="enable"' in source or '"enable"' in source, (
        "shield enable command must be registered"
    )
    assert "shield disable" in source or 'name="disable"' in source or '"disable"' in source, (
        "shield disable command must be registered"
    )
    assert "shield status" in source or 'name="status"' in source or '"status"' in source, (
        "shield status command must be registered"
    )


# ── Test 16: AgentShield is called in agent.py run_command handler ────────────


def test_agentshield_integrated_in_agent():
    """agent.py run_command handler must invoke AgentShield before execution."""
    source = _AGENT_PATH.read_text(encoding="utf-8")
    assert "AgentShield" in source or "agentshield" in source, (
        "agent.py must import and use AgentShield in the run_command handler"
    )
    assert "_shield_result" in source or "shield_result" in source or ".check(" in source, (
        "agent.py must call AgentShield.check() in the run_command handler"
    )


# ── Test 17: [AgentShield] BLOCKED printed on block verdict ──────────────────


def test_block_verdict_message_in_agent():
    """agent.py must print '[AgentShield] BLOCKED:' when verdict=block."""
    source = _AGENT_PATH.read_text(encoding="utf-8")
    assert "[AgentShield] BLOCKED" in source, (
        "agent.py run_command must print '[AgentShield] BLOCKED:' on block verdict"
    )


# ── Test 18: confirm verdict triggers user prompt ─────────────────────────────


def test_confirm_verdict_prompts_user_in_agent():
    """agent.py must ask 'Run? [y/N]' when verdict=confirm."""
    source = _AGENT_PATH.read_text(encoding="utf-8")
    assert "Run? [y/N]" in source, (
        "agent.py must prompt 'Run? [y/N]' when AgentShield returns verdict=confirm"
    )


# ── Test 19: dd disk overwrite is hard-blocked ───────────────────────────────


def test_dd_disk_overwrite_is_blocked():
    """dd if=... of=/dev/... must return verdict='block'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "dd if=/dev/zero of=/dev/sda")
    assert result.verdict == "block", (
        f"dd disk overwrite must be blocked, got verdict={result.verdict!r}"
    )


# ── Test 20: format C: is hard-blocked ───────────────────────────────────────


def test_format_disk_is_blocked():
    """format C: must return verdict='block'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    result = shield.check("run_command", "format C:")
    assert result.verdict == "block", (
        f"format C: must be blocked, got verdict={result.verdict!r}"
    )


# ── Test 21: ShieldResult dataclass has required fields ──────────────────────


def test_shield_result_has_required_fields():
    """ShieldResult must have verdict, reason, and blocked_pattern fields."""
    mod = _import_shield()
    assert hasattr(mod, "ShieldResult"), "ShieldResult must be exported from agentshield.py"
    # Instantiate with required fields
    sr = mod.ShieldResult(verdict="allow", reason="test")
    assert sr.verdict == "allow"
    assert sr.reason == "test"
    assert sr.blocked_pattern is None  # default


# ── Test 22: git reset/clean --force requires confirmation ───────────────────


def test_git_force_requires_confirm():
    """git reset --hard and git clean -f must require confirmation."""
    mod = _import_shield()
    shield = mod.AgentShield()
    for cmd in ("git reset --hard HEAD~1", "git clean -f"):
        result = shield.check("run_command", cmd)
        assert result.verdict == "confirm", (
            f"'{cmd}' must require confirmation, got verdict={result.verdict!r}"
        )


# ── Test 23: set_enabled persists to config ──────────────────────────────────


def test_set_enabled_writes_to_config():
    """set_enabled() must persist the value to ~/.msapling/config.json."""
    mod = _import_shield()

    with tempfile.TemporaryDirectory() as tmp:
        fake_config = Path(tmp) / "config.json"
        fake_config.write_text("{}", encoding="utf-8")

        with mock.patch.object(mod, "_CONFIG_FILE", fake_config), \
             mock.patch.object(mod, "_CONFIG_DIR", Path(tmp)):
            shield = mod.AgentShield()
            shield.set_enabled(False)
            saved = json.loads(fake_config.read_text(encoding="utf-8"))
            assert "agentshield_enabled" in saved
            assert saved["agentshield_enabled"] is False

            shield.set_enabled(True)
            saved2 = json.loads(fake_config.read_text(encoding="utf-8"))
            assert saved2["agentshield_enabled"] is True


# ── Test 24: safe commands (cat, echo, python) pass through ─────────────────


def test_common_safe_commands_pass():
    """Routine commands like cat, echo, python must return verdict='allow'."""
    mod = _import_shield()
    shield = mod.AgentShield()
    for cmd in ("cat README.md", "echo hello", "python --version", "pip list", "git status"):
        result = shield.check("run_command", cmd)
        assert result.verdict == "allow", (
            f"Safe command '{cmd}' must return allow, got {result.verdict!r}"
        )


# ── Test 25: check() works for non-run_command tool names ────────────────────


def test_check_works_for_any_tool_name():
    """check() must accept arbitrary tool_name values without error."""
    mod = _import_shield()
    shield = mod.AgentShield()
    # Even for non-command tools, if the command string matches a pattern it
    # should still be caught (defensive check).
    result = shield.check("write_file", "rm -rf /")
    assert result.verdict == "block"

    result2 = shield.check("read_file", "ls -la /tmp")
    assert result2.verdict == "allow"
