"""Tests for shell utilities."""
import asyncio
import subprocess
from unittest.mock import AsyncMock, patch

from msapling_cli.shell import (
    INSTRUCTION_FILES,
    _load_hooks,
    _load_project_instructions,
    _parse_menu_number,
    _safe_path,
    _normalize_local_path_arg,
    _run_hooks,
    _save_hooks,
    InteractiveShell,
)


def test_safe_path_normal(tmp_path):
    (tmp_path / "file.py").write_text("x = 1")
    result = _safe_path(str(tmp_path), "file.py")
    assert result is not None
    assert result.name == "file.py"


def test_safe_path_blocks_traversal(tmp_path):
    result = _safe_path(str(tmp_path), "../../etc/passwd")
    assert result is None


def test_safe_path_blocks_absolute(tmp_path):
    result = _safe_path(str(tmp_path), "/etc/passwd")
    if result is not None:
        assert str(result).startswith(str(tmp_path))


def test_safe_path_subdirectory(tmp_path):
    sub = tmp_path / "src"
    sub.mkdir()
    (sub / "main.py").write_text("pass")
    result = _safe_path(str(tmp_path), "src/main.py")
    assert result is not None
    assert "src" in str(result)


def test_safe_path_blocks_prefixed_sibling(tmp_path):
    sibling = tmp_path.parent / f"{tmp_path.name}-evil"
    sibling.mkdir()
    target = sibling / "secret.py"
    target.write_text("pass")
    assert _safe_path(str(tmp_path), str(target)) is None


def test_safe_path_strips_wrapping_quotes(tmp_path):
    target = tmp_path / "quoted.py"
    target.write_text("pass")
    result = _safe_path(str(tmp_path), f"\"{target}\"")
    assert result == target.resolve()


def test_normalize_local_path_arg_strips_wrapping_quotes():
    assert _normalize_local_path_arg('  "D:\\Projects\\MSapling_LAB\\INBOX.md"  ') == r"D:\Projects\MSapling_LAB\INBOX.md"


def test_load_project_instructions_msapling(tmp_path):
    (tmp_path / ".msapling.md").write_text("# Project Rules\nUse Python 3.10+")
    result = _load_project_instructions(str(tmp_path))
    assert "Project Rules" in result
    assert ".msapling.md" in result


def test_load_project_instructions_claude(tmp_path):
    (tmp_path / "CLAUDE.md").write_text("# Claude Instructions\nBe concise")
    result = _load_project_instructions(str(tmp_path))
    assert "Claude Instructions" in result


def test_load_project_instructions_none(tmp_path):
    result = _load_project_instructions(str(tmp_path))
    assert result == ""


def test_load_project_instructions_priority(tmp_path):
    (tmp_path / ".msapling.md").write_text("msapling rules")
    (tmp_path / "CLAUDE.md").write_text("claude rules")
    result = _load_project_instructions(str(tmp_path))
    assert "msapling rules" in result


def test_hooks_save_load(tmp_path):
    hooks_file = tmp_path / "hooks.json"
    with patch("msapling_cli.shell.HOOKS_FILE", hooks_file):
        _save_hooks({"on_session_start": ["echo hello"]})
        loaded = _load_hooks()
        assert "on_session_start" in loaded
        assert loaded["on_session_start"] == ["echo hello"]


def test_hooks_load_empty(tmp_path):
    with patch("msapling_cli.shell.HOOKS_FILE", tmp_path / "nonexistent.json"):
        loaded = _load_hooks()
        assert loaded == {}


def test_run_hooks_windows_shell_builtin_fallback():
    hooks = {"on_session_start": ["echo hello"]}
    calls = []

    def _fake_run(args, **kwargs):
        calls.append(args)
        if len(calls) == 1:
            raise FileNotFoundError("[WinError 2] The system cannot find the file specified")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="hello\n", stderr="")

    with patch("msapling_cli.shell.subprocess.run", side_effect=_fake_run), \
         patch("msapling_cli.shell.sys.platform", "win32"):
        out = _run_hooks("on_session_start", hooks, cwd=".")

    assert out == ["hello"]
    assert calls[0] == ["echo", "hello"]
    assert calls[1] == ["cmd", "/c", "echo hello"]


def test_run_command_windows_shell_builtin_fallback():
    calls = []

    def _fake_run(args, **kwargs):
        calls.append(args)
        if len(calls) == 1:
            raise FileNotFoundError("[WinError 2] The system cannot find the file specified")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="hello\n", stderr="")

    with patch("msapling_cli.shell.MSaplingClient", return_value=AsyncMock()):
        shell = InteractiveShell()
    shell.project_root = "."
    shell.project_name = "MSapling"

    with patch("msapling_cli.shell.subprocess.run", side_effect=_fake_run), \
         patch("msapling_cli.shell.sys.platform", "win32"), \
         patch("msapling_cli.shell.console.print"):
        asyncio.run(shell._handle_slash("/run echo hello"))

    assert calls[0] == ["echo", "hello"]
    assert calls[1] == ["cmd", "/c", "echo hello"]


def test_instruction_files_list():
    assert ".msapling.md" in INSTRUCTION_FILES
    assert "CLAUDE.md" in INSTRUCTION_FILES
    assert "GEMINI.md" in INSTRUCTION_FILES
    assert "AGENTS.md" in INSTRUCTION_FILES

def test_parse_menu_number_resume_variants():
    assert _parse_menu_number("1", "R", allow_bare_number=True) == 1
    assert _parse_menu_number("r 1", "R", allow_bare_number=True) == 1
    assert _parse_menu_number("R1", "R", allow_bare_number=True) == 1
    assert _parse_menu_number("R<1>", "R", allow_bare_number=True) == 1
    assert _parse_menu_number("R <2>", "R", allow_bare_number=True) == 2


def test_parse_menu_number_delete_and_multi_variants():
    assert _parse_menu_number("D1", "D") == 1
    assert _parse_menu_number("D <3>", "D") == 3
    assert _parse_menu_number("M2", "M") == 2
    assert _parse_menu_number("M <4>", "M") == 4
    assert _parse_menu_number("R", "R", allow_bare_number=True) is None
    assert _parse_menu_number("", "R", allow_bare_number=True) is None


def test_read_directory_message(tmp_path):
    with patch("msapling_cli.shell.MSaplingClient", return_value=object()):
        shell = InteractiveShell()
    shell.project_root = str(tmp_path)
    shell.messages = []

    with patch("msapling_cli.shell.console.print") as mock_print:
        asyncio.run(shell._handle_slash("/read ."))

    printed = "\n".join(str(call.args[0]) for call in mock_print.call_args_list if call.args)
    assert "Path is a directory" in printed


def test_files_absolute_directory_lists_files(tmp_path):
    (tmp_path / "INBOX.md").write_text("hello")
    with patch("msapling_cli.shell.MSaplingClient", return_value=AsyncMock()):
        shell = InteractiveShell()
    shell.project_root = str(tmp_path)
    shell.messages = []

    with patch("msapling_cli.shell.console.print") as mock_print:
        asyncio.run(shell._handle_slash(f"/files \"{tmp_path}\""))

    printed = "\n".join(str(call.args[0]) for call in mock_print.call_args_list if call.args)
    assert "INBOX.md" in printed


def test_chat_locked_recovery_switches_to_default_project(tmp_path):
    with patch("msapling_cli.shell.MSaplingClient", return_value=AsyncMock()):
        shell = InteractiveShell()
    shell.project_root = str(tmp_path)
    shell.session_id = "sess-1"
    shell.project_name = "Standalone"
    shell.chat_id = "locked-chat"
    shell.model = "anthropic/claude-3.5-sonnet"
    shell.agent_mode = True
    shell.messages = []
    shell.hooks = {}
    shell.user = {"tier": "monthly", "fuel_credits": 1.0, "is_pro": True}
    shell.client = AsyncMock()
    shell.client.create_chat = AsyncMock(side_effect=[Exception("full"), {"chat_id": "new-chat"}])

    import httpx
    req = httpx.Request("POST", "https://api.msapling.com/api/chat/message")
    resp = httpx.Response(423, request=req)
    locked_exc = httpx.HTTPStatusError("locked", request=req, response=resp)

    with patch("msapling_cli.shell.append_history"), patch("msapling_cli.shell.append_conversation"), patch("msapling_cli.shell.render_assistant_response"), patch("msapling_cli.shell.render_cost_footer"), patch("msapling_cli.shell.console.print") as mock_print, patch("msapling_cli.shell.asyncio.sleep", new=AsyncMock()) as mock_sleep, patch("msapling_cli.agent.run_agent_loop", side_effect=[locked_exc, locked_exc, locked_exc]), patch("msapling_cli.agent.get_and_clear_switched_model", return_value=None):
        asyncio.run(shell._chat(r"read files at D:\Projects\MSapling_LAB"))

    assert shell.project_name == "Default Project"
    assert shell.chat_id == "new-chat"
    assert mock_sleep.await_count >= 1
    printed = "\n".join(str(call.args[0]) for call in mock_print.call_args_list if call.args)
    assert "switched to Default Project" in printed
