"""Verify CLI shell resource-limit constants match the backend config.

The CLI ``MSaplingShell`` class defines ``MAX_CHATS_PER_PROJECT`` and
``FREE_MAX_CHATS`` with comments saying "must match backend config.py".
This test enforces that contract so a change on one side is caught
immediately by CI.
"""

from __future__ import annotations

import ast
from pathlib import Path


def _read_backend_constants() -> dict[str, int]:
    """Parse backend/config.py with AST to extract limit constants.

    We use AST instead of importing the module because the backend
    config performs env-var validation (e.g. MSAPLING_SECRET) that
    would fail in a pure CLI test environment.
    """
    config_path = (
        Path(__file__).resolve().parents[2]  # repo root
        / "MSapling_EC2"
        / "backend"
        / "config.py"
    )
    tree = ast.parse(config_path.read_text(encoding="utf-8"), filename=str(config_path))

    constants: dict[str, int] = {}
    target_names = {"MAX_CHATS_PER_PROJECT", "FREE_MAX_CHATS_PER_PROJECT"}

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in target_names
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, int)
        ):
            constants[node.targets[0].id] = node.value.value

    missing = target_names - constants.keys()
    assert not missing, (
        f"Could not find constants {missing} in {config_path}. "
        "Has the backend config.py structure changed?"
    )
    return constants


def _get_cli_shell_class():
    """Return the MSaplingShell class from the CLI package."""
    from msapling_cli.shell import InteractiveShell
    return InteractiveShell


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_max_chats_per_project_matches_backend():
    """CLI MAX_CHATS_PER_PROJECT must equal backend MAX_CHATS_PER_PROJECT."""
    backend = _read_backend_constants()
    shell_cls = _get_cli_shell_class()

    assert shell_cls.MAX_CHATS_PER_PROJECT == backend["MAX_CHATS_PER_PROJECT"], (
        f"CLI MAX_CHATS_PER_PROJECT ({shell_cls.MAX_CHATS_PER_PROJECT}) "
        f"!= backend MAX_CHATS_PER_PROJECT ({backend['MAX_CHATS_PER_PROJECT']}). "
        "Update one side to match the other."
    )


def test_free_max_chats_matches_backend():
    """CLI FREE_MAX_CHATS must equal backend FREE_MAX_CHATS_PER_PROJECT."""
    backend = _read_backend_constants()
    shell_cls = _get_cli_shell_class()

    assert shell_cls.FREE_MAX_CHATS == backend["FREE_MAX_CHATS_PER_PROJECT"], (
        f"CLI FREE_MAX_CHATS ({shell_cls.FREE_MAX_CHATS}) "
        f"!= backend FREE_MAX_CHATS_PER_PROJECT ({backend['FREE_MAX_CHATS_PER_PROJECT']}). "
        "Update one side to match the other."
    )
