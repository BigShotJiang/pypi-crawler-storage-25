"""Guardrail tests for NDJSON chunk parity, 402 tier split, and process stream lock.

Covers:
  Task 1 — cap_status, vision_usage, artifact, tool_use, error chunk handling
  Task 2 — 402 tier split (_is_tier_402, _handle_error, _handle_api_error)
  Task 3 — stream_lock acquire / release / stale PID detection
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Task 2 — 402 tier split helpers
# ---------------------------------------------------------------------------

def test_is_tier_402_model_keyword():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("Model not allowed on this tier") is True


def test_is_tier_402_plan_keyword():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("Upgrade your plan") is True


def test_is_tier_402_pro_keyword():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("Pro feature only") is True


def test_is_tier_402_tier_keyword():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("tier restriction applies") is True


def test_is_tier_402_allowlist_keyword():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("not in allowlist") is True


def test_is_tier_402_credits_message():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("Insufficient credits") is False


def test_is_tier_402_empty():
    from msapling_cli.main import _is_tier_402
    assert _is_tier_402("") is False


def test_handle_api_error_402_credits(capsys):
    """Generic 402 with no tier keywords → credits message."""
    from msapling_cli.main import _handle_api_error
    err = Exception("402 Insufficient fuel credits")
    _handle_api_error(err)
    out = capsys.readouterr().out
    assert "msapling.com" in out
    # Must NOT show the pro-upgrade message
    assert "Upgrade to Pro" not in out


def test_handle_api_error_402_model_tier(capsys):
    """402 with 'model' in detail → tier upgrade message."""
    from msapling_cli.main import _handle_api_error
    err = Exception("402 model not available on this plan")
    _handle_api_error(err)
    out = capsys.readouterr().out
    assert "Upgrade to Pro" in out
    assert "msapling.com/pricing" in out


def test_handle_error_402_credits(capsys):
    """_handle_error with plain 402 → credits message."""
    from msapling_cli.main import _handle_error

    class Fake402(Exception):
        status_code = 402
        response = None

    _handle_error(Fake402("402"))
    out = capsys.readouterr().out
    assert "credits" in out.lower() or "fuel" in out.lower()
    assert "Upgrade to Pro" not in out


def test_handle_error_402_tier_via_response(capsys):
    """_handle_error with 402 response body containing 'tier' → upgrade message."""
    from msapling_cli.main import _handle_error

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"detail": "model not available on this tier"}

    class Fake402(Exception):
        status_code = 402
        response = mock_resp

    _handle_error(Fake402("402"))
    out = capsys.readouterr().out
    assert "Upgrade to Pro" in out


# ---------------------------------------------------------------------------
# Task 3 — stream_lock module
# ---------------------------------------------------------------------------

def test_stream_lock_module_importable():
    import msapling_cli.stream_lock  # noqa: F401


def test_acquire_and_release(tmp_path):
    """Acquire succeeds for a fresh chat_id, release cleans up."""
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    try:
        err = sl.acquire_stream_lock("chat-abc")
        assert err is None
        lock_file = sl._lock_path("chat-abc")
        assert lock_file.exists()
        assert lock_file.read_text().strip() == str(os.getpid())
        sl.release_stream_lock("chat-abc")
        assert not lock_file.exists()
    finally:
        sl._LOCKS_DIR = original_dir


def test_acquire_reentrant_same_pid(tmp_path):
    """Same-process re-entrant acquire removes own stale lock and returns None."""
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    try:
        lock_file = sl._lock_path("chat-live")
        lock_file.parent.mkdir(parents=True, exist_ok=True)
        lock_file.write_text(str(os.getpid()))
        # Same process: treated as re-entrant, not a conflict.
        err = sl.acquire_stream_lock("chat-live")
        assert err is None
    finally:
        sl.release_stream_lock("chat-live")
        sl._LOCKS_DIR = original_dir


def test_acquire_returns_error_for_different_live_pid(tmp_path):
    """Acquiring a lock held by a different live PID returns an error string."""
    import subprocess
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    # Spawn a subprocess that stays alive long enough for our check.
    proc = subprocess.Popen(
        [sys.executable, "-c", "import time; time.sleep(10)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        lock_file = sl._lock_path("chat-live-other")
        lock_file.parent.mkdir(parents=True, exist_ok=True)
        lock_file.write_text(str(proc.pid))
        err = sl.acquire_stream_lock("chat-live-other")
        assert err is not None
        assert "already streaming" in err
        assert str(proc.pid) in err
    finally:
        proc.terminate()
        proc.wait(timeout=5)
        lock_file.unlink(missing_ok=True)
        sl._LOCKS_DIR = original_dir


def test_stale_lock_is_cleaned_up(tmp_path):
    """A lock file whose PID is no longer alive is silently removed."""
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    try:
        lock_file = sl._lock_path("chat-stale")
        lock_file.parent.mkdir(parents=True, exist_ok=True)
        # PID 0 is never a valid running process PID reachable by kill().
        lock_file.write_text("9999999")  # absurdly high PID — almost certainly dead
        # Patch _pid_alive so we don't depend on system state.
        with patch.object(sl, "_pid_alive", return_value=False):
            err = sl.acquire_stream_lock("chat-stale")
        assert err is None  # stale — lock acquired
    finally:
        sl.release_stream_lock("chat-stale")
        sl._LOCKS_DIR = original_dir


def test_release_is_idempotent(tmp_path):
    """Releasing a non-existent lock does not raise."""
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    try:
        sl.release_stream_lock("nonexistent-chat")  # must not raise
    finally:
        sl._LOCKS_DIR = original_dir


def test_lock_path_sanitises_special_chars(tmp_path):
    """Chat IDs with special characters produce safe filenames."""
    from msapling_cli import stream_lock as sl
    original_dir = sl._LOCKS_DIR
    sl._LOCKS_DIR = tmp_path / "locks"
    try:
        p = sl._lock_path("chat/with/slashes?and=equals")
        assert "/" not in p.name
        assert "\\" not in p.name
        assert "?" not in p.name
        assert "=" not in p.name
    finally:
        sl._LOCKS_DIR = original_dir


# ---------------------------------------------------------------------------
# Task 1 — cap_status / vision_usage / artifact / tool_use chunk handling
# The _do_stream_inner() closure is embedded in _chat(). We test it by
# verifying that the relevant accumulators are populated correctly via
# a lightweight simulation of the chunk dispatcher logic.
# ---------------------------------------------------------------------------

def _make_chunk_dispatcher():
    """Return a standalone dispatcher that mirrors the shell.py chunk logic."""
    cap_status_holder = [None]
    vision_tokens_holder = [0]
    vision_images_holder = [0]
    artifacts_holder: list = []
    parts: list = []
    thinking_parts: list = []
    logged_debug: list = []
    printed_dim: list = []

    def dispatch(chunk: dict) -> None:
        content = chunk.get("content", "")
        chunk_type = chunk.get("type", "")

        if chunk_type == "thinking" or chunk.get("thinking"):
            thinking_text = chunk.get("thinking", content)
            if thinking_text:
                thinking_parts.append(thinking_text)
            return
        if chunk_type == "usage" or chunk.get("usage"):
            return  # tokens tracked separately; not relevant here
        if chunk_type == "cap_status":
            cap_status_holder[0] = chunk
            return
        if chunk_type == "vision_usage":
            vision_tokens_holder[0] += int(chunk.get("vision_tokens", 0))
            vision_images_holder[0] += int(chunk.get("image_count", 0))
            return
        if chunk_type == "artifact":
            artifacts_holder.append(chunk)
            return
        if chunk_type == "tool_use":
            name = chunk.get("name", "unknown")
            status = chunk.get("status", "")
            logged_debug.append((name, status))
            if status == "running":
                printed_dim.append(f"⚡ {name} running…")
            return
        if chunk_type == "error":
            return  # handled but not accumulated
        if content:
            parts.append(content)
        # unknown types silently dropped

    return dispatch, cap_status_holder, vision_tokens_holder, vision_images_holder, artifacts_holder, parts, printed_dim


def test_cap_status_chunk_accumulated():
    dispatch, cap_status_holder, *_ = _make_chunk_dispatcher()
    chunk = {
        "type": "cap_status",
        "messages_used": 10,
        "messages_limit": 100,
        "messages_remaining": 90,
        "tokens_used_today": 50000,
        "tokens_limit_daily": 200000,
        "credits_remaining": 4.20,
        "tier": "free",
    }
    dispatch(chunk)
    assert cap_status_holder[0] is chunk


def test_vision_usage_chunk_accumulated():
    dispatch, _, vision_tokens_holder, vision_images_holder, *_ = _make_chunk_dispatcher()
    dispatch({"type": "vision_usage", "vision_tokens": 1600, "image_count": 2})
    dispatch({"type": "vision_usage", "vision_tokens": 1000, "image_count": 1})
    assert vision_tokens_holder[0] == 2600
    assert vision_images_holder[0] == 3


def test_artifact_chunk_accumulated():
    dispatch, _, _, _, artifacts_holder, *_ = _make_chunk_dispatcher()
    dispatch({"type": "artifact", "path": "/tmp/out.py", "content": "print('hi')"})
    dispatch({"type": "artifact", "path": "/tmp/out2.py"})
    assert len(artifacts_holder) == 2


def test_tool_use_running_printed():
    dispatch, _, _, _, _, _, printed_dim = _make_chunk_dispatcher()
    dispatch({"type": "tool_use", "name": "read_file", "status": "running"})
    assert any("read_file" in m for m in printed_dim)


def test_tool_use_done_not_printed():
    dispatch, _, _, _, _, _, printed_dim = _make_chunk_dispatcher()
    dispatch({"type": "tool_use", "name": "read_file", "status": "done"})
    assert not printed_dim


def test_unknown_chunk_type_silently_dropped():
    dispatch, cap, _, _, artifacts, parts, dim = _make_chunk_dispatcher()
    # Should not raise and should not pollute any accumulator.
    dispatch({"type": "future_type_v99", "data": "xyz"})
    assert cap[0] is None
    assert not artifacts
    assert not parts
    assert not dim


def test_content_chunk_accumulated():
    dispatch, _, _, _, _, parts, _ = _make_chunk_dispatcher()
    dispatch({"content": "Hello "})
    dispatch({"content": "world"})
    assert "".join(parts) == "Hello world"


def test_error_chunk_does_not_crash():
    dispatch, *_ = _make_chunk_dispatcher()
    # Must not raise
    dispatch({"type": "error", "error": "stream interrupted"})
