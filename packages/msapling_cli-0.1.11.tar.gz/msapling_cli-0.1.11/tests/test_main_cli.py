from __future__ import annotations

import json
import unittest.mock as mock
from pathlib import Path
from types import SimpleNamespace

from typer.testing import CliRunner

from msapling_cli import main
from msapling_cli.config import Settings


runner = CliRunner()


def _stub_run(result):
    def _inner(coro):
        coro.close()
        return result
    return _inner


def test_doctor_json_reports_auth_conflict(monkeypatch):
    monkeypatch.setattr(main, "_run", _stub_run((True, "user@example.com", None)))
    monkeypatch.setattr(main, "_package_version", lambda pkg: "1.0")
    monkeypatch.setattr(main, "get_token", lambda: "file-token")
    monkeypatch.setattr(main, "get_token_source", lambda: "file")
    monkeypatch.setattr(main, "inspect_token_sources", lambda: {"env": None, "file": "file-token", "keyring": "stale-keyring-token"})
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="google/gemini-2.0-flash-001"))
    monkeypatch.setattr("shutil.which", lambda name: {"git": "C:/git.exe", "rg": "C:/rg.exe"}.get(name))

    result = runner.invoke(main.app, ["doctor", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["version"] == main.__version__
    assert data["auth"]["present"] is True
    assert data["auth"]["source"] == "file"
    assert data["auth"]["conflict"] is True
    assert data["api"]["reachable"] is True
    assert data["api"]["auth_check_ok"] is True
    assert data["api"]["identity"] == "user@example.com"
    assert "auth_conflict" in data["warnings"]


def test_projects_command_handles_dict_payload(monkeypatch):
    class StubClient:
        async def list_projects(self):
            return {
                "projects": {
                    "Default Project": {"tokens_used": 12, "cost_used": 0.34},
                    "Standalone": {"tokens_used": 5, "cost_used": 0.12},
                }
            }

        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", StubClient)

    result = runner.invoke(main.app, ["projects"])
    assert result.exit_code == 0
    assert "Default Project" in result.stdout
    assert "Standalone" in result.stdout


def test_doctor_strict_exits_nonzero_on_auth_failure(monkeypatch):
    monkeypatch.setattr(main, "_run", _stub_run((True, None, "401 Unauthorized")))
    monkeypatch.setattr(main, "_package_version", lambda pkg: "1.0")
    monkeypatch.setattr(main, "get_token", lambda: "file-token")
    monkeypatch.setattr(main, "get_token_source", lambda: "file")
    monkeypatch.setattr(main, "inspect_token_sources", lambda: {"env": None, "file": "file-token", "keyring": None})
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="google/gemini-2.0-flash-001"))
    monkeypatch.setattr("shutil.which", lambda name: None)

    result = runner.invoke(main.app, ["doctor", "--json", "--strict"])
    assert result.exit_code == 1
    data = json.loads(result.stdout)
    assert "auth_check_failed" in data["failures"]
    assert data["api"]["auth_check_ok"] is False


def test_doctor_json_reports_missing_tool_warnings(monkeypatch):
    monkeypatch.setattr(main, "_run", _stub_run((True, "user@example.com", None)))
    monkeypatch.setattr(main, "_package_version", lambda pkg: "1.0")
    monkeypatch.setattr(main, "get_token", lambda: None)
    monkeypatch.setattr(main, "get_token_source", lambda: None)
    monkeypatch.setattr(main, "inspect_token_sources", lambda: {"env": None, "file": None, "keyring": None})
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="google/gemini-2.0-flash-001"))
    monkeypatch.setattr("shutil.which", lambda name: None)

    result = runner.invoke(main.app, ["doctor", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert "git_not_found" in data["warnings"]
    assert "ripgrep_not_found" in data["warnings"]


def test_console_safe_text_strips_bom_and_replaces_unencodable(monkeypatch):
    monkeypatch.setattr(main.sys, "stdout", SimpleNamespace(encoding="cp1252"))
    value = main._console_safe_text("\ufeff-- snowman \u2603")
    assert not value.startswith("\ufeff")
    assert value.startswith("-- snowman ")


def test_edit_dry_run_handles_bom_diff(monkeypatch, tmp_path):
    target = tmp_path / "demo.py"
    target.write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")

    class StubClient:
        async def chat_once(self, prompt_text, model_id, **kwargs):
            return "\ufeff--- demo.py\n+++ demo.py\n@@ -1,2 +1,3 @@\n+\"\"\"doc\"\"\"\n def add(a, b):\n     return a + b\n"

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="anthropic/claude-3-haiku"))

    result = runner.invoke(main.app, ["edit", "--dry-run", "Add a docstring.", str(target)])
    assert result.exit_code == 0
    assert "Dry run - no changes applied" in result.stdout


def test_swarm_uses_ascii_separator(monkeypatch):
    class StubClient:
        async def swarm(self, prompt, models=None, synthesize_model=None):
            return {
                "agent_responses": [
                    {"model": "model-a", "status": "ok", "response": "alpha"},
                    {"model": "model-b", "status": "error", "response": "", "error": "boom"},
                ],
                "synthesis": "final answer",
                "judge_model": "model-a",
                "models_used": ["model-a", "model-b"],
            }

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)

    result = runner.invoke(main.app, ["swarm", "Explain tests.", "-m", "model-a,model-b"])
    assert result.exit_code == 0
    assert "-- model-a" in result.stdout
    assert "boom" in result.stdout

def test_extract_unified_diff_strips_wrapper_text():
    wrapped = "Here is the unified diff:\n\n```diff\n--- demo.py\n+++ demo.py\n@@ -1 +1 @@\n-old\n+new\n```"
    diff_text = main._extract_unified_diff(wrapped)
    assert diff_text.startswith("--- demo.py")
    assert "```" not in diff_text


def test_edit_apply_normalizes_wrapped_diff(monkeypatch, tmp_path):
    target = tmp_path / "demo_apply.py"
    target.write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    captured = {}

    class StubClient:
        async def chat_once(self, prompt_text, model_id, **kwargs):
            return "Here is the unified diff:\n\n```diff\n--- demo_apply.py\n+++ demo_apply.py\n@@ -1,2 +1,3 @@\n+\"\"\"doc\"\"\"\n def add(a, b):\n     return a + b\n```"

        async def apply_diff(self, original, diff_text, file_path):
            captured["diff_text"] = diff_text
            captured["file_path"] = file_path
            return {"success": True, "new_content": "\"\"\"doc\"\"\"\ndef add(a, b):\n    return a + b\n"}

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="anthropic/claude-3-haiku"))

    result = runner.invoke(main.app, ["edit", "Add a docstring.", str(target)])
    assert result.exit_code == 0
    assert "--- " in captured["diff_text"] and "demo_apply.py" in captured["diff_text"]
    assert captured["file_path"] == str(target)
    assert target.read_text(encoding="utf-8").startswith('"""doc"""')

def test_edit_apply_fallbacks_to_regenerated_backend_diff(monkeypatch, tmp_path):
    target = tmp_path / "demo_fallback.py"
    target.write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    calls = {"apply": [], "generate": []}

    class StubClient:
        async def chat_once(self, prompt_text, model_id, **kwargs):
            return "Here is the unified diff:\n\n---\ndef add(a, b):\n    return a + b\n\n+++\ndef add(a: int, b: int) -> int:\n    \"\"\"Add two integers.\"\"\"\n    return a + b\n"

        async def apply_diff(self, original, diff_text, file_path):
            calls["apply"].append(diff_text)
            if "@@" not in diff_text:
                return {"success": False, "error": "Invalid diff format"}
            return {"success": True, "new_content": '"""Add two integers."""\ndef add(a: int, b: int) -> int:\n    return a + b\n'}

        async def generate_diff(self, old_content, new_content, filename):
            calls["generate"].append((old_content, new_content, filename))
            return {"diff": "--- demo_fallback.py\n+++ demo_fallback.py\n@@ -1,2 +1,3 @@\n-def add(a, b):\n+def add(a: int, b: int) -> int:\n+    \"\"\"Add two integers.\"\"\"\n     return a + b\n"}

        async def close(self):
            return None

    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(main, "MSaplingClient", StubClient)
    monkeypatch.setattr(main, "get_settings", lambda: Settings(api_url="https://api.msapling.com", default_model="anthropic/claude-3-haiku"))

    result = runner.invoke(main.app, ["edit", "Add a docstring.", str(target)])
    assert result.exit_code == 0
    assert len(calls["apply"]) == 2
    assert len(calls["generate"]) == 1
    assert target.read_text(encoding="utf-8").startswith('"""Add two integers."""')

# ─── P1 tests: models --all, auth conflict, logout confirmation, diff summary ──


def test_models_all_flag_returns_full_list(monkeypatch):
    """--all flag must bypass the default 30-model limit."""
    model_list = [{"id": f"provider/model-{i}", "context_length": 8192} for i in range(50)]

    class StubClient:
        async def get_models(self):
            return model_list
        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())

    result = runner.invoke(main.app, ["models", "--all"])
    assert result.exit_code == 0
    # All 50 models should appear; "Showing N of M" hint should NOT appear.
    assert "Showing" not in result.stdout or "50 of 50" not in result.stdout
    # Spot-check first and last model appear
    assert "model-0" in result.stdout
    assert "model-49" in result.stdout


def test_models_limit_shows_truncation_hint(monkeypatch):
    """Default limit=30 should show truncation hint when list exceeds it."""
    model_list = [{"id": f"provider/model-{i}", "context_length": 8192} for i in range(50)]

    class StubClient:
        async def get_models(self):
            return model_list
        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())

    result = runner.invoke(main.app, ["models"])
    assert result.exit_code == 0
    assert "30 of 50" in result.stdout


def test_login_returns_nonzero_on_failure(monkeypatch):
    class StubClient:
        token = None

        def __init__(self, api_url=None):
            self.api_url = api_url

        async def login(self, email, password):
            raise RuntimeError("bad credentials")

        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", StubClient)

    result = runner.invoke(
        main.app,
        ["login", "--email", "bad@example.com", "--password", "bad"],
    )
    assert result.exit_code == 1
    assert "Login failed" in result.stdout


def test_logout_requires_confirmation_and_cancels(monkeypatch, tmp_path):
    """logout without --force should prompt and cancel when user declines."""
    token_file = tmp_path / "token"
    token_file.write_text("secret", encoding="utf-8")

    cleared = []

    def _fake_clear():
        cleared.append(True)

    monkeypatch.setattr(main, "clear_token", _fake_clear)

    # CliRunner with input="n\n" simulates user declining.
    result = runner.invoke(main.app, ["logout"], input="n\n")
    assert result.exit_code == 0
    assert len(cleared) == 0, "clear_token should NOT have been called"
    assert "Cancelled" in result.stdout or "cancelled" in result.stdout.lower()


def test_logout_force_skips_confirmation(monkeypatch):
    """logout --force must skip the confirmation prompt and clear credentials."""
    cleared = []

    def _fake_clear():
        cleared.append(True)

    monkeypatch.setattr(main, "clear_token", _fake_clear)

    result = runner.invoke(main.app, ["logout", "--force"])
    assert result.exit_code == 0
    assert len(cleared) == 1, "clear_token should have been called exactly once"


def test_diff_command_shows_stat_summary(monkeypatch, tmp_path):
    """diff command must print +added / -removed line summary on success."""
    old_f = tmp_path / "old.py"
    new_f = tmp_path / "new.py"
    old_f.write_text("line1\nline2\n", encoding="utf-8")
    new_f.write_text("line1\nline3\n", encoding="utf-8")

    diff_output = "--- old.py\n+++ new.py\n@@ -1,2 +1,2 @@\n line1\n-line2\n+line3\n"

    class StubClient:
        async def generate_diff(self, **kwargs):
            return {"diff": diff_output}
        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())

    result = runner.invoke(main.app, ["diff", str(old_f), str(new_f)])
    assert result.exit_code == 0
    # Summary line must appear (contains +N and -N)
    assert "+1" in result.stdout
    assert "-1" in result.stdout


def test_diff_command_falls_back_to_local_diff_when_api_fails(monkeypatch, tmp_path):
    """diff command should still produce output when backend diff endpoint fails."""
    old_f = tmp_path / "old.py"
    new_f = tmp_path / "new.py"
    old_f.write_text("line1\nline2\n", encoding="utf-8")
    new_f.write_text("line1\nline3\n", encoding="utf-8")

    class StubClient:
        async def generate_diff(self, **kwargs):
            raise RuntimeError("backend unavailable")
        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())

    result = runner.invoke(main.app, ["diff", str(old_f), str(new_f)])
    assert result.exit_code == 0
    assert "API diff unavailable; used local fallback" in result.stdout
    assert "+1" in result.stdout
    assert "-1" in result.stdout


def test_chat_save_flag_writes_response_to_file(monkeypatch, tmp_path):
    """chat --save must persist the streamed response to the specified file."""
    out_file = tmp_path / "response.md"
    response_text = "Hello from the model!"

    class StubClient:
        async def ensure_server_chat(self, **kwargs):
            return "chat-123"
        async def stream_chat(self, **kwargs):
            yield {"content": response_text, "type": "token"}
        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())
    monkeypatch.setattr(main, "_get_user_or_exit", lambda: SimpleNamespace(tier="free", is_pro=False))
    monkeypatch.setattr(main, "require_pro", lambda *a, **kw: None)

    try:
        runner.invoke(main.app, ["chat", "Say hello", "--save", str(out_file)])
    except ValueError:
        # Click 8.2+ StreamMixer.__del__ race: asyncio GC can collect stream_mixer
        # while outstreams[0] is still live, causing getvalue() to raise ValueError.
        # The file write happens before this cleanup path, so the assertion below
        # still verifies the actual feature.
        pass
    # Exit code 0 or runner-level issue; check file was written
    assert out_file.exists(), "chat --save must create the output file"
    assert response_text in out_file.read_text(encoding="utf-8")


def test_config_theme_help_routes_to_subcommand(monkeypatch):
    saved = []

    def _save(settings):
        saved.append(settings)

    monkeypatch.setattr(main, "save_settings", _save)

    result = runner.invoke(main.app, ["config", "theme", "--help"])
    assert result.exit_code == 0
    assert "Get or set the CLI color theme." in result.stdout
    assert not saved, "config theme --help must not mutate settings"


def test_config_shield_help_routes_to_subcommand():
    result = runner.invoke(main.app, ["config", "shield", "--help"])
    assert result.exit_code == 0
    assert "Manage AgentShield client-side safety gate." in result.stdout
    assert "enable" in result.stdout
    assert "disable" in result.stdout


def test_config_legacy_positional_set_still_works(monkeypatch):
    settings = Settings(api_url="https://api.msapling.com", default_model="google/gemini-2.0-flash-001")
    saved_values = []

    monkeypatch.setattr(main, "get_settings", lambda: settings)
    monkeypatch.setattr(main, "save_settings", lambda s: saved_values.append(s.default_model))

    result = runner.invoke(main.app, ["config", "default_model", "openai/gpt-4o-mini"])
    assert result.exit_code == 0
    assert settings.default_model == "openai/gpt-4o-mini"
    assert saved_values == ["openai/gpt-4o-mini"]


def test_config_theme_list_handles_cp1252_encoding(monkeypatch):
    class FakeStdout:
        encoding = "cp1252"

        def __init__(self):
            self.writes = []

        def write(self, text):
            text.encode(self.encoding, errors="strict")
            self.writes.append(text)

        def flush(self):
            return None

    fake_stdout = FakeStdout()
    monkeypatch.setattr(main.sys, "stdout", fake_stdout)

    main.config_theme(name=None, list_themes=True)
    assert fake_stdout.writes


def test_models_returns_nonzero_on_failure(monkeypatch):
    class StubClient:
        async def get_models(self):
            raise RuntimeError("offline")

        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())

    result = runner.invoke(main.app, ["models"])
    assert result.exit_code == 1
    assert "RuntimeError: offline" in result.stdout


def test_scan_stdout_mode_handles_cp1252_encoding(monkeypatch, tmp_path):
    sample = tmp_path / "emoji.py"
    sample.write_text("\ufeffprint('hi😀')\n", encoding="utf-8")

    class FakeStdout:
        encoding = "cp1252"

        def __init__(self):
            self.writes = []

        def write(self, text):
            text.encode(self.encoding, errors="strict")
            self.writes.append(text)

        def flush(self):
            return None

    fake_stdout = FakeStdout()
    monkeypatch.setattr(main.sys, "stdout", fake_stdout)

    main.scan(
        path=str(tmp_path),
        output="-",
        include="*.py",
        exclude="__pycache__,*.pyc,.git,node_modules,venv,.venv,dist,build",
        max_files=100,
        max_size_kb=512,
    )
    emitted = "".join(fake_stdout.writes)
    assert "# File:" in emitted
    assert "\ufeff" not in emitted


def test_chat_noninteractive_exits_nonzero_on_error(monkeypatch, tmp_path):
    class StubClient:
        async def ensure_server_chat(self, **kwargs):
            return "chat-123"

        async def stream_chat(self, **kwargs):
            if False:  # pragma: no cover - keeps this as an async generator
                yield {}
            raise RuntimeError("stream failed")

        async def close(self):
            return None

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())
    monkeypatch.setattr(main, "_get_user_or_exit", lambda: {"tier": "monthly", "is_pro": True})
    monkeypatch.setattr(main, "require_pro", lambda *args, **kwargs: None)
    monkeypatch.setattr(
        main,
        "get_settings",
        lambda: Settings(api_url="https://api.msapling.com", default_model="openai/gpt-4o-mini"),
    )

    out_file = tmp_path / "resp.txt"
    result = runner.invoke(main.app, ["chat", "hello", "--save", str(out_file)])
    assert result.exit_code == 1


def test_parallel_partial_success_returns_zero(monkeypatch):
    import msapling_cli.pipeline as pipeline_mod

    class StubClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_parallel(prompt, n, model, client, **kwargs):
        return [
            {"idx": 1, "content": "ok-1", "error": None, "attempts": 1, "retried": False},
            {"idx": 2, "content": None, "error": "500 Internal Server Error", "attempts": 2, "retried": True},
        ]

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())
    monkeypatch.setattr(main, "get_token", lambda: "token")
    monkeypatch.setattr(pipeline_mod, "run_parallel_chats", _fake_parallel)

    result = runner.invoke(main.app, ["parallel", "hello", "-n", "2", "-m", "openai/gpt-4o-mini"])
    assert result.exit_code == 0
    assert "Parallel summary:" in result.stdout
    assert "Partial success" in result.stdout


def test_parallel_all_failures_return_nonzero(monkeypatch):
    import msapling_cli.pipeline as pipeline_mod

    class StubClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_parallel(prompt, n, model, client, **kwargs):
        return [
            {"idx": 1, "content": None, "error": "500 Internal Server Error", "attempts": 3, "retried": True},
            {"idx": 2, "content": None, "error": "503 Service Unavailable", "attempts": 3, "retried": True},
        ]

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())
    monkeypatch.setattr(main, "get_token", lambda: "token")
    monkeypatch.setattr(pipeline_mod, "run_parallel_chats", _fake_parallel)

    result = runner.invoke(main.app, ["parallel", "hello", "-n", "2", "-m", "openai/gpt-4o-mini"])
    assert result.exit_code == 1
    assert "Parallel summary:" in result.stdout


def test_parallel_strict_mode_fails_on_partial(monkeypatch):
    import msapling_cli.pipeline as pipeline_mod

    class StubClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    async def _fake_parallel(prompt, n, model, client, **kwargs):
        return [
            {"idx": 1, "content": "ok-1", "error": None, "attempts": 1, "retried": False},
            {"idx": 2, "content": None, "error": "500 Internal Server Error", "attempts": 2, "retried": True},
        ]

    monkeypatch.setattr(main, "MSaplingClient", lambda: StubClient())
    monkeypatch.setattr(main, "get_token", lambda: "token")
    monkeypatch.setattr(pipeline_mod, "run_parallel_chats", _fake_parallel)

    result = runner.invoke(
        main.app,
        ["parallel", "hello", "-n", "2", "-m", "openai/gpt-4o-mini", "--strict"],
    )
    assert result.exit_code == 1
    assert "Strict mode" in result.stdout


def test_git_command_accepts_split_args_with_dashes(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()

    import subprocess

    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True, text=True)
    (repo / "a.txt").write_text("x\n", encoding="utf-8")
    subprocess.run(["git", "add", "a.txt"], cwd=repo, check=True, capture_output=True, text=True)

    result = runner.invoke(main.app, ["git", "status", "--short", "--cwd", str(repo)])
    assert result.exit_code == 0
    assert "a.txt" in result.stdout
