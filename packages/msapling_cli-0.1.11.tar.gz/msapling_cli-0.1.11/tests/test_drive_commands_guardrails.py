"""Guardrail tests for `msapling drive` commands.

Covers: push, pull, sync, ls, share, status — happy paths, edge cases,
.mdriveignore, dry-run, auth errors, empty-project, progress bar, registration.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import pytest
from typer.testing import CliRunner

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def drive_app():
    from msapling_cli.drive_commands import drive_app as app
    return app


@pytest.fixture
def fake_token(monkeypatch):
    """Inject a fake auth token so _require_auth() passes."""
    monkeypatch.setenv("MSAPLING_TOKEN", "fake-test-token")
    import msapling_cli.config as cfg_mod
    monkeypatch.setattr(cfg_mod, "get_token", lambda: "fake-test-token")
    import msapling_cli.drive_commands as dc
    monkeypatch.setattr(dc, "get_token", lambda: "fake-test-token")


@pytest.fixture
def tmp_project(tmp_path: Path) -> Path:
    """Create a small local project tree for push/sync tests."""
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("print('hello')")
    (tmp_path / "src" / "utils.py").write_text("def add(a, b): return a + b")
    (tmp_path / "README.md").write_text("# Project")
    # Should be ignored
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "lodash.js").write_text("// lodash")
    (tmp_path / ".git").mkdir()
    (tmp_path / ".git" / "HEAD").write_text("ref: refs/heads/main")
    return tmp_path


@pytest.fixture
def tmp_project_with_mdriveignore(tmp_project: Path) -> Path:
    """Add a .mdriveignore that excludes 'dist/' and '*.log'."""
    (tmp_project / "dist").mkdir()
    (tmp_project / "dist" / "bundle.js").write_text("// bundled")
    (tmp_project / "debug.log").write_text("some log")
    (tmp_project / _MDRIVEIGNORE).write_text("dist/\n*.log\n# comment line\n")
    return tmp_project


_MDRIVEIGNORE = ".mdriveignore"

# ---------------------------------------------------------------------------
# Helper: build a mock MSaplingClient context manager
# ---------------------------------------------------------------------------


def _make_mock_client(**overrides):
    """Return a (mock_instance, mock_class_patch) pair."""
    mock = AsyncMock()
    mock.__aenter__ = AsyncMock(return_value=mock)
    mock.__aexit__ = AsyncMock(return_value=False)
    # Default method return values
    mock.drive_push.return_value = {"uploaded": 3, "skipped": 0, "errors": 0}
    mock.drive_pull.return_value = [
        {"path": "src/main.py", "content": "print('hello')", "size": 14},
        {"path": "README.md", "content": "# Project", "size": 9},
    ]
    mock.drive_ls.return_value = [
        {"path": "src/main.py", "size": 14, "updated_at": "2026-04-10T09:00:00", "version": "v3"},
        {"path": "README.md", "size": 9, "updated_at": "2026-04-09T12:00:00", "version": "v1"},
    ]
    mock.drive_share.return_value = {
        "url": "https://api.msapling.com/api/mdrive/share/abc123",
        "token": "abc123",
        "expires_at": "2026-04-18T09:00:00Z",
        "expires_hours": 24,
    }
    mock.mdrive_usage.return_value = {
        "storage_used_bytes": 1024 * 1024 * 5,
        "storage_limit_bytes": 1024 * 1024 * 100,
        "file_count": 2,
        "project_count": 1,
        "last_sync": "2026-04-17T08:00:00",
    }
    for attr, val in overrides.items():
        setattr(mock, attr, val)
    return mock


# ===========================================================================
# Test 1: drive_app is registered in main.py
# ===========================================================================


def test_drive_app_registered_in_main():
    """drive_app must be added to the top-level app in main.py."""
    from msapling_cli import main as main_mod
    # Typer stores added typers in app.registered_groups
    group_names = [g.typer_instance.info.name for g in main_mod.app.registered_groups]
    assert "drive" in group_names, f"'drive' not in registered groups: {group_names}"


# ===========================================================================
# Test 2: drive push — mocked API succeeds, reports file count
# ===========================================================================


def test_drive_push_success(runner, drive_app, fake_token, tmp_project):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", str(tmp_project), "--project", "myproj"])
    assert result.exit_code == 0, result.output
    # Should report files uploaded
    assert "uploaded" in result.output.lower() or "push complete" in result.output.lower()


# ===========================================================================
# Test 3: drive push --dry-run skips upload, shows diff
# ===========================================================================


def test_drive_push_dry_run(runner, drive_app, fake_token, tmp_project):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", str(tmp_project), "--dry-run"])
    assert result.exit_code == 0, result.output
    # drive_push should NOT have been called
    mock_client.drive_push.assert_not_called()
    assert "dry run" in result.output.lower()


# ===========================================================================
# Test 4: .mdriveignore patterns are respected — node_modules/ excluded
# ===========================================================================


def test_drive_push_ignores_node_modules(runner, drive_app, fake_token, tmp_project):
    captured_files: List[List[dict]] = []

    async def _capture_push(project, files):
        captured_files.extend(files)
        return {"uploaded": len(files), "skipped": 0, "errors": 0}

    mock_client = _make_mock_client()
    mock_client.drive_push = _capture_push

    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", str(tmp_project), "--project", "p"])

    assert result.exit_code == 0, result.output
    paths = [f["path"] for f in captured_files]
    assert not any("node_modules" in p for p in paths), f"node_modules leaked into upload: {paths}"
    assert not any(".git" in p for p in paths), f".git leaked into upload: {paths}"


# ===========================================================================
# Test 5: .mdriveignore — custom patterns respected (dist/, *.log)
# ===========================================================================


def test_drive_push_respects_mdriveignore(runner, drive_app, fake_token, tmp_project_with_mdriveignore):
    captured_files: List[dict] = []

    async def _capture_push(project, files):
        captured_files.extend(files)
        return {"uploaded": len(files), "skipped": 0, "errors": 0}

    mock_client = _make_mock_client()
    mock_client.drive_push = _capture_push

    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", str(tmp_project_with_mdriveignore), "--project", "p"])

    assert result.exit_code == 0, result.output
    paths = [f["path"] for f in captured_files]
    assert not any("bundle.js" in p for p in paths), "dist/ should be ignored"
    assert not any(".log" in p for p in paths), "*.log should be ignored"


# ===========================================================================
# Test 6: drive ls shows table with correct columns
# ===========================================================================


def test_drive_ls_shows_table(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["ls", "myproj"])
    assert result.exit_code == 0, result.output
    assert "main.py" in result.output
    assert "README.md" in result.output


def test_drive_ls_long_shows_columns(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["ls", "myproj", "--long"])
    assert result.exit_code == 0, result.output
    # Long mode should include size and version
    assert "v3" in result.output or "14" in result.output  # version or size


# ===========================================================================
# Test 7: drive ls — empty project gives graceful "no files" message
# ===========================================================================


def test_drive_ls_empty_project(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    mock_client.drive_ls.return_value = []
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["ls", "empty-proj"])
    assert result.exit_code == 0, result.output
    assert "no files" in result.output.lower()


# ===========================================================================
# Test 8: drive sync — detects local_only vs remote_only vs same
# ===========================================================================


def test_drive_sync_classifies_files(runner, drive_app, fake_token, tmp_project):
    # Remote has README.md (same hash won't match, so conflict), plus remote-only file
    from msapling_cli import drive_commands as dc

    remote_files = [
        {"path": "README.md", "size": 9, "sha256": "deadbeef"},  # different hash -> conflict
        {"path": "remote_only.txt", "size": 5, "sha256": "aaaa"},
    ]
    mock_client = _make_mock_client()
    mock_client.drive_ls.return_value = remote_files

    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["sync", str(tmp_project), "--project", "p"])

    assert result.exit_code == 0, result.output
    output = result.output
    assert "local_only" in output.lower()
    assert "remote_only" in output.lower()


# ===========================================================================
# Test 9: drive sync — same files correctly classified
# ===========================================================================


def test_drive_sync_same_files(runner, drive_app, fake_token, tmp_project):
    """Files whose SHA256 matches remote should show as 'same'."""
    import hashlib

    readme = (tmp_project / "README.md")
    content = readme.read_bytes()
    sha = hashlib.sha256(content).hexdigest()

    remote_files = [{"path": "README.md", "size": len(content), "sha256": sha}]
    mock_client = _make_mock_client()
    mock_client.drive_ls.return_value = remote_files

    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["sync", str(tmp_project), "--project", "p"])

    assert result.exit_code == 0, result.output
    assert "same" in result.output.lower()


# ===========================================================================
# Test 10: drive share — returns URL
# ===========================================================================


def test_drive_share_returns_url(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["share", "myproj", "--file", "src/main.py"])
    assert result.exit_code == 0, result.output
    assert "https://" in result.output or "share" in result.output.lower()
    assert "abc123" in result.output


# ===========================================================================
# Test 11: drive share — missing --file exits with error
# ===========================================================================


def test_drive_share_missing_file_arg(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["share", "myproj"])
    assert result.exit_code != 0 or "file" in result.output.lower()


# ===========================================================================
# Test 12: Missing auth → clear error on push
# ===========================================================================


def test_drive_push_no_auth(runner, drive_app, monkeypatch, tmp_project):
    import msapling_cli.config as cfg_mod
    monkeypatch.setattr(cfg_mod, "get_token", lambda: None)
    import msapling_cli.drive_commands as dc
    monkeypatch.setattr(dc, "get_token", lambda: None)
    monkeypatch.delenv("MSAPLING_TOKEN", raising=False)

    result = runner.invoke(drive_app, ["push", str(tmp_project)])
    assert result.exit_code != 0
    output = result.output.lower()
    assert "login" in output or "auth" in output or "not authenticated" in output


# ===========================================================================
# Test 13: Missing auth → clear error on ls
# ===========================================================================


def test_drive_ls_no_auth(runner, drive_app, monkeypatch):
    import msapling_cli.config as cfg_mod
    monkeypatch.setattr(cfg_mod, "get_token", lambda: None)
    import msapling_cli.drive_commands as dc
    monkeypatch.setattr(dc, "get_token", lambda: None)
    monkeypatch.delenv("MSAPLING_TOKEN", raising=False)

    result = runner.invoke(drive_app, ["ls", "someproj"])
    assert result.exit_code != 0
    output = result.output.lower()
    assert "login" in output or "auth" in output or "not authenticated" in output


# ===========================================================================
# Test 14: drive pull — downloads files to dest
# ===========================================================================


def test_drive_pull_writes_files(runner, drive_app, fake_token, tmp_path):
    dest = tmp_path / "pulled"
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["pull", "myproj", "--dest", str(dest)])
    assert result.exit_code == 0, result.output
    assert (dest / "src" / "main.py").exists()
    assert (dest / "README.md").exists()


# ===========================================================================
# Test 15: drive pull --dry-run shows files but doesn't write
# ===========================================================================


def test_drive_pull_dry_run(runner, drive_app, fake_token, tmp_path):
    dest = tmp_path / "dry"
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["pull", "myproj", "--dest", str(dest), "--dry-run"])
    assert result.exit_code == 0, result.output
    assert "dry run" in result.output.lower()
    # Nothing should have been written
    assert not dest.exists() or not any(dest.iterdir())


# ===========================================================================
# Test 16: drive pull — empty project graceful message
# ===========================================================================


def test_drive_pull_empty_project(runner, drive_app, fake_token, tmp_path):
    dest = tmp_path / "empty"
    mock_client = _make_mock_client()
    mock_client.drive_pull.return_value = []
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["pull", "empty-proj", "--dest", str(dest)])
    assert result.exit_code == 0, result.output
    assert "no files" in result.output.lower()


# ===========================================================================
# Test 17: drive status shows usage
# ===========================================================================


def test_drive_status_shows_usage(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["status"])
    assert result.exit_code == 0, result.output
    # Should show storage used or "MDrive Status"
    assert "5.0 MB" in result.output or "status" in result.output.lower() or "storage" in result.output.lower()


# ===========================================================================
# Test 18: Progress bar shown for large uploads
# ===========================================================================


def test_drive_push_progress_bar_invoked(runner, drive_app, fake_token, tmp_project, monkeypatch):
    """Progress.add_task should be called during a push."""
    from rich.progress import Progress as RichProgress

    add_task_calls = []
    original_add_task = RichProgress.add_task

    def spy_add_task(self, description, *args, **kwargs):
        add_task_calls.append(description)
        return original_add_task(self, description, *args, **kwargs)

    mock_client = _make_mock_client()
    monkeypatch.setattr(RichProgress, "add_task", spy_add_task)
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", str(tmp_project), "--project", "p"])

    assert result.exit_code == 0, result.output
    assert any("upload" in str(desc).lower() for desc in add_task_calls), (
        f"Expected an 'upload' progress task, got: {add_task_calls}"
    )


# ===========================================================================
# Test 19: drive push — non-existent path exits with error
# ===========================================================================


def test_drive_push_nonexistent_path(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["push", "/nonexistent/path/xyz123"])
    assert result.exit_code != 0
    assert "not exist" in result.output.lower() or "error" in result.output.lower()


# ===========================================================================
# Test 20: drive_push API method added to MSaplingClient
# ===========================================================================


def test_api_drive_push_method_exists():
    from msapling_cli.api import MSaplingClient
    client = MSaplingClient(api_url="http://localhost:8000", token="tok")
    assert hasattr(client, "drive_push"), "MSaplingClient.drive_push not found"
    assert hasattr(client, "drive_pull"), "MSaplingClient.drive_pull not found"
    assert hasattr(client, "drive_ls"), "MSaplingClient.drive_ls not found"
    assert hasattr(client, "drive_share"), "MSaplingClient.drive_share not found"


# ===========================================================================
# Test 21: drive ls — API 401 shows auth error
# ===========================================================================


def test_drive_ls_api_401(runner, drive_app, fake_token):
    from msapling_cli.api import APIError

    mock_client = _make_mock_client()
    mock_client.drive_ls.side_effect = APIError("Unauthorized", status_code=401)
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["ls", "myproj"])
    assert result.exit_code != 0
    assert "auth" in result.output.lower() or "login" in result.output.lower()


# ===========================================================================
# Test 22: drive pull — project name used as dest directory when --dest omitted
# ===========================================================================


def test_drive_pull_default_dest(runner, drive_app, fake_token, tmp_path, monkeypatch):
    """Without --dest, files land in cwd/<project>."""
    monkeypatch.chdir(tmp_path)
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["pull", "proj123"])
    assert result.exit_code == 0, result.output
    expected_dir = tmp_path / "proj123"
    assert expected_dir.exists()


# ===========================================================================
# Test 23: drive sync — empty local dir handles gracefully
# ===========================================================================


def test_drive_sync_empty_local(runner, drive_app, fake_token, tmp_path):
    """Sync with empty local directory shows remote-only files."""
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()
    mock_client = _make_mock_client()
    mock_client.drive_ls.return_value = [{"path": "remote.txt", "size": 5, "sha256": "abc"}]
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["sync", str(empty_dir), "--project", "p"])
    assert result.exit_code == 0, result.output
    assert "remote_only" in result.output.lower()


# ===========================================================================
# Test 24: drive share -- expires flag passed through
# ===========================================================================


def test_drive_share_expires_flag(runner, drive_app, fake_token):
    mock_client = _make_mock_client()
    with patch("msapling_cli.drive_commands.MSaplingClient", return_value=mock_client):
        result = runner.invoke(drive_app, ["share", "proj", "--file", "f.py", "--expires", "48"])
    assert result.exit_code == 0, result.output
    # Verify drive_share was called with expires=48
    call_args = mock_client.drive_share.call_args
    assert call_args is not None
    args = call_args[0] if call_args[0] else []
    kwargs = call_args[1] if call_args[1] else {}
    expires_val = args[2] if len(args) > 2 else kwargs.get("expires_hours", None)
    assert int(expires_val) == 48, f"Expected expires_hours=48, got {expires_val}"
