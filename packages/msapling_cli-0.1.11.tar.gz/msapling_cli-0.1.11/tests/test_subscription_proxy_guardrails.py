"""
test_subscription_proxy_guardrails.py
Subscription Proxy CLI (Ollama provider routing) guardrail tests.
Zero real network calls — all HTTP interactions are mocked.
All domain logic is re-implemented or imported from the CLI modules directly.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import types
from typing import Any, AsyncGenerator, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run(coro):
    return asyncio.run(coro)


def _make_ollama_stream_lines(content_parts: List[str]) -> List[str]:
    """Build Ollama NDJSON stream lines for mocking."""
    lines = []
    for part in content_parts:
        lines.append(json.dumps({"message": {"role": "assistant", "content": part}, "done": False}))
    # Final done chunk with stats
    lines.append(json.dumps({
        "done": True,
        "prompt_eval_count": 50,
        "eval_count": 30,
    }))
    return lines


# ---------------------------------------------------------------------------
# Inline domain re-implementation — mirrors cli/msapling_cli/api.py helpers
# ---------------------------------------------------------------------------

def _is_ollama_model(model_id: str) -> bool:
    mid = str(model_id or "").strip().lower()
    return mid.startswith("ollama/") or mid.startswith("ollama:")


def _normalize_ollama_model_id(model_id: str) -> str:
    raw = str(model_id or "").strip()
    low = raw.lower()
    if low.startswith("ollama:"):
        return "ollama/" + raw.split(":", 1)[1].strip()
    return raw


def _extract_ollama_model_name(model_id: str) -> str:
    normalized = _normalize_ollama_model_id(model_id)
    if normalized.lower().startswith("ollama/"):
        return normalized.split("/", 1)[1].strip()
    return normalized.strip()


# Inline OllamaProvider re-implementation (mirrors backend/services/provider_router.py)
class OllamaProvider:
    DEFAULT_BASE_URL = "http://localhost:11434"

    def __init__(self, ollama_url: Optional[str] = None) -> None:
        self.ollama_url = (
            str(ollama_url or "").strip()
            or os.environ.get("MSAPLING_OLLAMA_URL", "")
            or os.environ.get("OLLAMA_BASE_URL", "")
            or self.DEFAULT_BASE_URL
        ).rstrip("/")

    @classmethod
    def for_request(cls, request_header_url: Optional[str] = None) -> "OllamaProvider":
        return cls(ollama_url=request_header_url)

    @staticmethod
    def handles(model_id: str, provider: Optional[str] = None) -> bool:
        if provider == "ollama":
            return True
        return str(model_id or "").lower().startswith("ollama/")

    @staticmethod
    def extract_model_name(model_id: str) -> str:
        raw = str(model_id or "").strip()
        if raw.lower().startswith("ollama/"):
            return raw[7:].strip()
        return raw

    async def list_models(self) -> List[Dict[str, Any]]:
        import httpx
        url = f"{self.ollama_url}/api/tags"
        timeout = httpx.Timeout(connect=5.0, read=20.0, write=5.0, pool=5.0)
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json() if isinstance(resp.json(), dict) else {}
        except httpx.ConnectError as exc:
            raise RuntimeError(
                f"Ollama not reachable at {self.ollama_url}. "
                "Ensure Ollama is running: https://ollama.com"
            ) from exc
        rows: List[Dict[str, Any]] = []
        for m in (data.get("models") or []):
            name = str(m.get("name", "")).strip()
            if not name:
                continue
            rows.append({
                "id": f"ollama/{name}",
                "name": name,
                "provider": "ollama",
            })
        return rows

    async def stream(
        self,
        *,
        model_id: str,
        messages: List[Dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> AsyncGenerator[str, None]:
        import httpx
        bare_model = self.extract_model_name(model_id)
        payload: Dict[str, Any] = {
            "model": bare_model,
            "messages": messages,
            "stream": True,
        }
        chat_url = f"{self.ollama_url}/api/chat"
        timeout = httpx.Timeout(connect=5.0, read=3600.0, write=30.0, pool=10.0)
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream("POST", chat_url, json=payload) as resp:
                    if resp.status_code >= 400:
                        body = await resp.aread()
                        detail = body.decode("utf-8", errors="ignore")[:400]
                        raise RuntimeError(f"Ollama chat failed (HTTP {resp.status_code}): {detail}")
                    buffer = ""
                    prompt_tokens = 0
                    completion_tokens = 0
                    async for chunk in resp.aiter_text():
                        buffer += chunk
                        while "\n" in buffer:
                            line, buffer = buffer.split("\n", 1)
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                data = json.loads(line)
                            except json.JSONDecodeError:
                                continue
                            if isinstance(data, dict) and data.get("error"):
                                raise RuntimeError(f"Ollama error: {data.get('error')}")
                            message_obj = data.get("message", {}) if isinstance(data, dict) else {}
                            content = message_obj.get("content", "") if isinstance(message_obj, dict) else ""
                            if content:
                                yield json.dumps({"content": content}) + "\n"
                            if bool(data.get("done")):
                                prompt_tokens = int(data.get("prompt_eval_count") or 0)
                                completion_tokens = int(data.get("eval_count") or 0)
                    usage_chunk: Dict[str, Any] = {
                        "type": "usage",
                        "usage": {
                            "prompt_tokens": prompt_tokens,
                            "completion_tokens": completion_tokens,
                            "total_tokens": prompt_tokens + completion_tokens,
                        },
                        "cost": 0.0,
                    }
                    yield json.dumps(usage_chunk) + "\n"
        except httpx.ConnectError as exc:
            raise RuntimeError(
                f"Ollama not reachable at {self.ollama_url}. Start Ollama with: ollama serve"
            ) from exc


# ---------------------------------------------------------------------------
# Tests 1-2: CLI flags accepted
# ---------------------------------------------------------------------------

class TestCLIFlags:
    """Tests 1-2: --provider and --ollama-url flags are recognised by the chat command."""

    def test_01_provider_flag_accepted_by_chat_command(self):
        """chat command signature must have a 'provider' parameter."""
        from msapling_cli.main import chat as _chat_cmd
        import inspect
        sig = inspect.signature(_chat_cmd)
        assert "provider" in sig.parameters, "chat command missing --provider flag"

    def test_02_ollama_url_flag_accepted_by_chat_command(self):
        """chat command signature must have an 'ollama_url' parameter."""
        from msapling_cli.main import chat as _chat_cmd
        import inspect
        sig = inspect.signature(_chat_cmd)
        assert "ollama_url" in sig.parameters, "chat command missing --ollama-url flag"


# ---------------------------------------------------------------------------
# Tests 3-4: Model prefix routing
# ---------------------------------------------------------------------------

class TestModelPrefixRouting:
    """Tests 3-4: ollama/ prefix triggers OllamaProvider routing."""

    def test_03_ollama_prefix_handled_by_ollama_provider(self):
        """OllamaProvider.handles() must return True for ollama/ prefix."""
        assert OllamaProvider.handles("ollama/llama3") is True

    def test_04_provider_param_ollama_triggers_handler(self):
        """OllamaProvider.handles() must return True when provider='ollama' regardless of model."""
        assert OllamaProvider.handles("anthropic/claude", provider="ollama") is True
        assert OllamaProvider.handles("gpt-4o", provider="ollama") is True

    def test_03b_non_ollama_prefix_not_handled(self):
        """Non-ollama models are not handled by OllamaProvider."""
        assert OllamaProvider.handles("openai/gpt-4o") is False
        assert OllamaProvider.handles("anthropic/claude-3") is False


# ---------------------------------------------------------------------------
# Test 5: X-Ollama-Url header sent when provider=ollama
# ---------------------------------------------------------------------------

class TestXOllamaUrlHeader:
    """Test 5: X-Ollama-Url header is sent when MSAPLING_PROVIDER=ollama is set.

    The header forwarding applies to the backend HTTP path.  When the model ID
    starts with ``ollama/``, stream_chat routes locally without any backend
    HTTP call.  This test verifies the header injection logic in the HTTP path
    by calling ``stream_chat`` with a non-ollama model ID while
    ``MSAPLING_PROVIDER=ollama`` is set in the environment.
    """

    @pytest.mark.asyncio
    async def test_05_x_ollama_url_header_forwarded(self):
        """stream_chat must attach X-Ollama-Url when MSAPLING_PROVIDER=ollama is set."""
        captured_headers: Dict[str, str] = {}

        class _FakeStreamCtx:
            status_code = 200

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

            async def aiter_text(self):
                for line in _make_ollama_stream_lines(["Hello"]):
                    yield line + "\n"

            async def aread(self):
                return b""

        async def _fake_stream(method, path, json=None, headers=None, **kwargs):
            captured_headers.update(headers or {})
            return _FakeStreamCtx()

        from msapling_cli.api import MSaplingClient

        old_provider = os.environ.pop("MSAPLING_PROVIDER", None)
        old_url = os.environ.pop("MSAPLING_OLLAMA_URL", None)
        try:
            os.environ["MSAPLING_PROVIDER"] = "ollama"
            os.environ["MSAPLING_OLLAMA_URL"] = "http://localhost:11434"

            client = MSaplingClient.__new__(MSaplingClient)
            client.api_url = "http://test"
            client.token = "tok"
            client.diff_mode = False
            client._chat_cache = {}
            client._client = None

            # Build a context-manager-style mock that records headers.
            # httpx.AsyncClient.stream() returns an async context manager (not a coro).
            class _FakeStreamCtxMgr:
                """Mimics httpx.AsyncClient.stream() — a sync call returning an async CM."""
                def __init__(self, method, path, json=None, headers=None, **kwargs):
                    captured_headers.update(headers or {})
                    self.status_code = 200

                async def __aenter__(self):
                    return self

                async def __aexit__(self, *a):
                    pass

                async def aiter_text(self):
                    for line in _make_ollama_stream_lines(["Hello"]):
                        yield line + "\n"

                async def aread(self):
                    return b""

            mock_http = MagicMock()
            mock_http.is_closed = False
            mock_http.stream = _FakeStreamCtxMgr  # sync call -> returns CM instance

            async def _get():
                return mock_http

            client._get_client = _get

            # Use a cloud model ID (not ollama/) so that stream_chat routes to
            # the backend HTTP path where the header injection code runs.
            collected = []
            try:
                async for chunk in client.stream_chat(
                    chat_id="chat-1",
                    prompt="Hi",
                    model="openai/gpt-4o",  # non-ollama model hits HTTP backend path
                ):
                    collected.append(chunk)
            except Exception:
                pass  # stream may error on mock; headers are already captured

            assert "X-Ollama-Url" in captured_headers, (
                "X-Ollama-Url header missing — stream_chat must forward it when "
                "MSAPLING_PROVIDER=ollama and MSAPLING_OLLAMA_URL are set"
            )
            assert captured_headers["X-Ollama-Url"] == "http://localhost:11434"
        finally:
            if old_provider is not None:
                os.environ["MSAPLING_PROVIDER"] = old_provider
            else:
                os.environ.pop("MSAPLING_PROVIDER", None)
            if old_url is not None:
                os.environ["MSAPLING_OLLAMA_URL"] = old_url
            else:
                os.environ.pop("MSAPLING_OLLAMA_URL", None)


# ---------------------------------------------------------------------------
# Test 6: msapling models --provider ollama calls /api/tags
# ---------------------------------------------------------------------------

class TestModelsOllamaProvider:
    """Test 6: models --provider ollama lists from GET /api/tags."""

    @pytest.mark.asyncio
    async def test_06_ollama_provider_calls_api_tags(self):
        """OllamaProvider.list_models() must call GET <ollama_url>/api/tags."""
        import httpx

        fake_tags_response = {
            "models": [
                {"name": "llama3", "size": 4000000000},
                {"name": "mistral", "size": 3500000000},
            ]
        }

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=None)

            mock_resp = MagicMock()
            mock_resp.json.return_value = fake_tags_response
            mock_resp.raise_for_status = MagicMock()
            mock_client.get = AsyncMock(return_value=mock_resp)

            provider = OllamaProvider("http://localhost:11434")
            models = await provider.list_models()

        assert len(models) == 2
        assert any(m["id"] == "ollama/llama3" for m in models)
        assert any(m["id"] == "ollama/mistral" for m in models)


# ---------------------------------------------------------------------------
# Test 7: OllamaProvider exists in provider_router
# ---------------------------------------------------------------------------

class TestOllamaProviderInBackend:
    """Test 7: OllamaProvider class exists in backend services/provider_router.py."""

    def test_07_ollama_provider_class_exists(self):
        """OllamaProvider must be importable from services.provider_router."""
        # We can't import the full backend without a running app, but we can
        # verify the class was appended to the module via source inspection.
        import ast
        router_path = (
            __file__.replace("cli/tests", "backend/services")
            .replace("test_subscription_proxy_guardrails.py", "provider_router.py")
            .replace("cli\\tests", "backend\\services")
            .replace("test_subscription_proxy_guardrails.py", "provider_router.py")
        )
        # Use the known absolute path
        import pathlib
        project_root = pathlib.Path(__file__).resolve().parent.parent.parent
        router_file = project_root / "backend" / "services" / "provider_router.py"
        if router_file.exists():
            source = router_file.read_text(encoding="utf-8")
            assert "class OllamaProvider" in source, (
                "OllamaProvider class not found in provider_router.py"
            )
        else:
            pytest.skip("provider_router.py not found — backend not in expected path")


# ---------------------------------------------------------------------------
# Test 8: Ollama API format — POST /api/chat with {model, messages, stream}
# ---------------------------------------------------------------------------

class TestOllamaAPIFormat:
    """Test 8: OllamaProvider.stream() sends correct Ollama API payload format."""

    @pytest.mark.asyncio
    async def test_08_stream_posts_to_api_chat_with_correct_payload(self):
        """stream() must POST to /api/chat with {model, messages, stream: true}."""
        captured_payloads: list = []

        class _FakeStreamCtx:
            def __init__(self):
                self.status_code = 200

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

            async def aiter_text(self):
                for line in _make_ollama_stream_lines(["Hello!"]):
                    yield line + "\n"

            async def aread(self):
                return b""

        class _FakeHttpClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

            def stream(self, method, url, json=None, **kwargs):
                captured_payloads.append({"method": method, "url": url, "json": json})
                return _FakeStreamCtx()

        with patch("httpx.AsyncClient", return_value=_FakeHttpClient()):
            provider = OllamaProvider("http://localhost:11434")
            chunks = []
            async for chunk in provider.stream(
                model_id="ollama/llama3",
                messages=[{"role": "user", "content": "Hello"}],
            ):
                chunks.append(json.loads(chunk))

        assert len(captured_payloads) == 1
        payload = captured_payloads[0]["json"]
        assert payload["model"] == "llama3"  # bare name, not ollama/llama3
        assert payload["stream"] is True
        assert isinstance(payload["messages"], list)
        assert "POST" in [p["method"] for p in captured_payloads]
        url = captured_payloads[0]["url"]
        assert "/api/chat" in url


# ---------------------------------------------------------------------------
# Test 9: Response streaming in OpenAI-compat format
# ---------------------------------------------------------------------------

class TestResponseStreamingFormat:
    """Test 9: OllamaProvider output is OpenAI-compat NDJSON."""

    @pytest.mark.asyncio
    async def test_09_response_chunks_are_openai_compat_ndjson(self):
        """Each content chunk must be JSON with a 'content' key."""
        class _FakeStreamCtx:
            def __init__(self):
                self.status_code = 200

            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

            async def aiter_text(self):
                for line in _make_ollama_stream_lines(["Hello", " world"]):
                    yield line + "\n"

            async def aread(self):
                return b""

        class _FakeHttpClient:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *a):
                pass

            def stream(self, method, url, json=None, **kwargs):
                return _FakeStreamCtx()

        with patch("httpx.AsyncClient", return_value=_FakeHttpClient()):
            provider = OllamaProvider("http://localhost:11434")
            chunks = []
            async for raw in provider.stream(
                model_id="ollama/llama3",
                messages=[{"role": "user", "content": "Hi"}],
            ):
                chunks.append(json.loads(raw))

        content_chunks = [c for c in chunks if "content" in c]
        usage_chunks = [c for c in chunks if c.get("type") == "usage"]

        assert len(content_chunks) >= 1, "No content chunks yielded"
        assert len(usage_chunks) == 1, "Expected exactly one usage chunk"
        assert "usage" in usage_chunks[0]
        assert "cost" in usage_chunks[0]
        assert usage_chunks[0]["cost"] == 0.0  # local inference is free


# ---------------------------------------------------------------------------
# Test 10: Fallback — Ollama not running
# ---------------------------------------------------------------------------

class TestOllamaNotRunning:
    """Test 10: clear user-facing error when Ollama is not reachable."""

    @pytest.mark.asyncio
    async def test_10_ollama_not_reachable_raises_clear_error(self):
        """RuntimeError message must contain 'Ollama not reachable' when connect fails."""
        import httpx

        with patch("httpx.AsyncClient") as mock_cls:
            mock_instance = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=None)
            mock_instance.get = AsyncMock(
                side_effect=httpx.ConnectError("Connection refused")
            )

            provider = OllamaProvider("http://localhost:11434")
            with pytest.raises(RuntimeError) as exc_info:
                await provider.list_models()

        assert "Ollama not reachable" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Test 11: --provider auto uses existing routing (non-ollama)
# ---------------------------------------------------------------------------

class TestProviderAutoRouting:
    """Test 11: --provider auto / None does not force ollama routing."""

    def test_11_provider_auto_does_not_trigger_ollama(self):
        """OllamaProvider.handles() with provider='auto' returns False."""
        assert OllamaProvider.handles("openai/gpt-4o", provider="auto") is False
        assert OllamaProvider.handles("openai/gpt-4o", provider=None) is False

    def test_11b_provider_none_non_ollama_model(self):
        """No provider arg and non-ollama model ID does not trigger OllamaProvider."""
        assert OllamaProvider.handles("anthropic/claude-3-opus") is False


# ---------------------------------------------------------------------------
# Tests 12-14: ensure_ollama_chat in MSaplingClient
# ---------------------------------------------------------------------------

class TestEnsureOllamaChat:
    """Tests 12-14: ensure_ollama_chat() returns correct chat ID and sets env."""

    @pytest.mark.asyncio
    async def test_12_ensure_ollama_chat_returns_synthetic_id(self):
        """ensure_ollama_chat must return a synthetic ID string for local inference."""
        from msapling_cli.api import MSaplingClient

        client = MSaplingClient.__new__(MSaplingClient)
        client.api_url = "http://test"
        client.token = "tok"
        client.diff_mode = False
        client._chat_cache = {}
        client._client = None

        chat_id = await client.ensure_ollama_chat("llama3")
        assert "llama3" in chat_id
        assert chat_id.startswith("ollama-local-")

    @pytest.mark.asyncio
    async def test_13_ensure_ollama_chat_sets_env_url(self):
        """ensure_ollama_chat must set MSAPLING_OLLAMA_URL env when ollama_url supplied."""
        from msapling_cli.api import MSaplingClient

        client = MSaplingClient.__new__(MSaplingClient)
        client.api_url = "http://test"
        client.token = "tok"
        client.diff_mode = False
        client._chat_cache = {}
        client._client = None

        old = os.environ.pop("MSAPLING_OLLAMA_URL", None)
        try:
            await client.ensure_ollama_chat("llama3", ollama_url="http://192.168.1.10:11434")
            assert os.environ.get("MSAPLING_OLLAMA_URL") == "http://192.168.1.10:11434"
        finally:
            if old is not None:
                os.environ["MSAPLING_OLLAMA_URL"] = old
            else:
                os.environ.pop("MSAPLING_OLLAMA_URL", None)

    @pytest.mark.asyncio
    async def test_14_ensure_ollama_chat_strips_prefix(self):
        """ensure_ollama_chat works with both 'llama3' and 'ollama/llama3' input."""
        from msapling_cli.api import MSaplingClient

        client = MSaplingClient.__new__(MSaplingClient)
        client.api_url = "http://test"
        client.token = "tok"
        client.diff_mode = False
        client._chat_cache = {}
        client._client = None

        chat_id_bare = await client.ensure_ollama_chat("llama3")
        chat_id_prefixed = await client.ensure_ollama_chat("ollama/llama3")
        assert "llama3" in chat_id_bare
        assert "llama3" in chat_id_prefixed


# ---------------------------------------------------------------------------
# Tests 15-17: OllamaProvider.extract_model_name
# ---------------------------------------------------------------------------

class TestExtractModelName:
    """Tests 15-17: extract_model_name strips prefix correctly."""

    def test_15_strips_ollama_prefix(self):
        assert OllamaProvider.extract_model_name("ollama/llama3") == "llama3"

    def test_16_bare_name_unchanged(self):
        assert OllamaProvider.extract_model_name("llama3") == "llama3"

    def test_17_nested_path_stripped(self):
        assert OllamaProvider.extract_model_name("ollama/qwen2.5:3b") == "qwen2.5:3b"


# ---------------------------------------------------------------------------
# Tests 18-20: URL resolution priority
# ---------------------------------------------------------------------------

class TestURLResolution:
    """Tests 18-20: Ollama URL resolved in correct priority order."""

    def test_18_constructor_arg_takes_priority_over_env(self):
        """Explicit ollama_url arg overrides MSAPLING_OLLAMA_URL env."""
        old = os.environ.pop("MSAPLING_OLLAMA_URL", None)
        try:
            os.environ["MSAPLING_OLLAMA_URL"] = "http://env:11434"
            p = OllamaProvider("http://explicit:11434")
            assert p.ollama_url == "http://explicit:11434"
        finally:
            if old is not None:
                os.environ["MSAPLING_OLLAMA_URL"] = old
            else:
                os.environ.pop("MSAPLING_OLLAMA_URL", None)

    def test_19_env_var_used_when_no_arg(self):
        """MSAPLING_OLLAMA_URL env is used when no constructor arg is given."""
        old = os.environ.pop("MSAPLING_OLLAMA_URL", None)
        old_base = os.environ.pop("OLLAMA_BASE_URL", None)
        try:
            os.environ["MSAPLING_OLLAMA_URL"] = "http://envonly:11434"
            p = OllamaProvider()
            assert p.ollama_url == "http://envonly:11434"
        finally:
            if old is not None:
                os.environ["MSAPLING_OLLAMA_URL"] = old
            else:
                os.environ.pop("MSAPLING_OLLAMA_URL", None)
            if old_base is not None:
                os.environ["OLLAMA_BASE_URL"] = old_base

    def test_20_default_localhost_when_no_env(self):
        """Fallback to localhost:11434 when no env or arg provided."""
        old = os.environ.pop("MSAPLING_OLLAMA_URL", None)
        old_base = os.environ.pop("OLLAMA_BASE_URL", None)
        try:
            p = OllamaProvider()
            assert "localhost" in p.ollama_url or "127.0.0.1" in p.ollama_url
        finally:
            if old is not None:
                os.environ["MSAPLING_OLLAMA_URL"] = old
            if old_base is not None:
                os.environ["OLLAMA_BASE_URL"] = old_base
