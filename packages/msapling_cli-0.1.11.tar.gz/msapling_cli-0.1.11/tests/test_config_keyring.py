"""Keyring integration tests for config.py.

Tests verify that:
1. save_token/get_token round-trip via keyring
2. KeyError/exception from keyring falls back to the token file
3. Profile switching changes the active configuration

Uses tempfile.mkdtemp instead of tmp_path to avoid Windows file-lock
cleanup errors caused by the --basetemp=.pytest_tmp pytest setting when
a previous test run left a locked directory.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from msapling_cli.config import (
    Settings,
    clear_token,
    get_settings,
    get_token,
    list_profiles,
    save_profile,
    save_settings,
    save_token,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _TmpDir:
    """Context manager: creates a real temp directory; removes it on exit."""

    def __enter__(self) -> Path:
        self.path = Path(tempfile.mkdtemp(prefix="ms_cfg_test_"))
        return self.path

    def __exit__(self, *_):
        shutil.rmtree(self.path, ignore_errors=True)


# ---------------------------------------------------------------------------
# 1. test_save_and_load_token — via keyring
# ---------------------------------------------------------------------------

def test_save_and_load_token_via_keyring():
    """Token saved to keyring can be retrieved by get_token."""
    _store: dict = {}

    mock_keyring = MagicMock()
    mock_keyring.set_password.side_effect = lambda svc, user, tok: _store.update({(svc, user): tok})
    mock_keyring.get_password.side_effect = lambda svc, user: _store.get((svc, user))
    mock_keyring.delete_password.side_effect = lambda svc, user: _store.pop((svc, user), None)

    with _TmpDir() as tmp:
        token_file = tmp / "token"
        enc_file = tmp / "token.enc"

        with patch("msapling_cli.config._get_keyring_backend", return_value=mock_keyring), \
             patch("msapling_cli.config._TOKEN_FILE", token_file), \
             patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
             patch("msapling_cli.config._KEYFILE", tmp / ".keyfile"), \
             patch("msapling_cli.config._CONFIG_DIR", tmp), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            # Empty string MSAPLING_TOKEN → _token_from_env returns None
            save_token("keyring-token-abc123")

            mock_keyring.set_password.assert_called()

            retrieved = get_token()
            assert retrieved == "keyring-token-abc123"

            # File should NOT exist (keyring succeeded → file skipped)
            assert not token_file.exists()


def test_clear_token_removes_from_keyring():
    """clear_token calls keyring.delete_password."""
    _store: dict = {"stored": "old-token"}

    mock_keyring = MagicMock()
    mock_keyring.delete_password.side_effect = lambda svc, user: _store.pop("stored", None)

    with _TmpDir() as tmp:
        with patch("msapling_cli.config._get_keyring_backend", return_value=mock_keyring), \
             patch("msapling_cli.config._TOKEN_FILE", tmp / "token"), \
             patch("msapling_cli.config._TOKEN_ENC_FILE", tmp / "token.enc"):
            clear_token()

    mock_keyring.delete_password.assert_called_once()


# ---------------------------------------------------------------------------
# 2. test_missing_keyring_falls_back_to_file
# ---------------------------------------------------------------------------

def test_missing_keyring_falls_back_to_file():
    """When keyring.set_password raises, token is Fernet-encrypted to token.enc."""
    mock_keyring = MagicMock()
    mock_keyring.set_password.side_effect = Exception("keyring unavailable")
    mock_keyring.get_password.return_value = None  # explicit None to avoid MagicMock truthy

    with _TmpDir() as tmp:
        enc_file = tmp / "token.enc"

        with patch("msapling_cli.config._get_keyring_backend", return_value=mock_keyring), \
             patch("msapling_cli.config._TOKEN_FILE", tmp / "token"), \
             patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
             patch("msapling_cli.config._KEYFILE", tmp / ".keyfile"), \
             patch("msapling_cli.config._CONFIG_DIR", tmp), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            save_token("fallback-token-xyz")

            assert enc_file.exists()
            # Verify round-trip decryption (not plaintext check)
            assert get_token() == "fallback-token-xyz"


def test_get_token_keyring_error_falls_back_to_file():
    """If keyring.get_password raises, get_token falls back to the encrypted file.

    The plaintext legacy token is first migrated to encrypted storage.
    """
    mock_keyring = MagicMock()
    # set_password must succeed for migration; get_password raises to force enc file fallback.
    mock_keyring.set_password.return_value = None
    mock_keyring.get_password.side_effect = Exception("keyring broken")

    with _TmpDir() as tmp:
        token_file = tmp / "token"
        enc_file = tmp / "token.enc"
        token_file.write_text("file-token-789\n", encoding="utf-8")

        with patch("msapling_cli.config._get_keyring_backend", return_value=mock_keyring), \
             patch("msapling_cli.config._TOKEN_FILE", token_file), \
             patch("msapling_cli.config._TOKEN_ENC_FILE", enc_file), \
             patch("msapling_cli.config._KEYFILE", tmp / ".keyfile"), \
             patch("msapling_cli.config._CONFIG_DIR", tmp), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            result = get_token()

    # The migration path via set_password succeeds (mock), returning "file-token-789"
    assert result == "file-token-789"


def test_no_keyring_no_file_returns_none():
    """get_token returns None when there is no env var, no keyring, and no file."""
    with _TmpDir() as tmp:
        with patch("msapling_cli.config._get_keyring_backend", return_value=None), \
             patch("msapling_cli.config._TOKEN_FILE", tmp / "token_missing"), \
             patch("msapling_cli.config._TOKEN_ENC_FILE", tmp / "token_missing.enc"), \
             patch.dict(os.environ, {"MSAPLING_TOKEN": ""}):
            result = get_token()

    assert result is None


# ---------------------------------------------------------------------------
# 3. test_profile_switching
# ---------------------------------------------------------------------------

def test_profile_switching_changes_active_config():
    """get_settings with a named profile returns that profile's settings."""
    with _TmpDir() as tmp:
        profiles_dir = tmp / "profiles"
        profiles_dir.mkdir()

        work_data = {"api_url": "https://work.example.com", "default_model": "openai/gpt-4o"}
        (profiles_dir / "work.json").write_text(json.dumps(work_data), encoding="utf-8")

        personal_data = {
            "api_url": "http://localhost:8000",
            "default_model": "google/gemini-2.0-flash-001",
        }
        (profiles_dir / "personal.json").write_text(json.dumps(personal_data), encoding="utf-8")

        with patch("msapling_cli.config._PROFILES_DIR", profiles_dir), \
             patch("msapling_cli.config._CONFIG_FILE", tmp / "config.json"), \
             patch.dict(os.environ, {"MSAPLING_PROFILE": ""}):

            work_settings = get_settings(profile="work")
            assert work_settings.api_url == "https://work.example.com"
            assert work_settings.default_model == "openai/gpt-4o"

            personal_settings = get_settings(profile="personal")
            assert personal_settings.api_url == "http://localhost:8000"

            # No profile + no config file → defaults
            default_settings = get_settings()
            assert default_settings.api_url == "https://api.msapling.com"


def test_list_profiles_returns_profile_names():
    """list_profiles() returns the names of saved profiles."""
    with _TmpDir() as tmp:
        profiles_dir = tmp / "profiles"
        profiles_dir.mkdir()
        (profiles_dir / "alpha.json").write_text("{}", encoding="utf-8")
        (profiles_dir / "beta.json").write_text("{}", encoding="utf-8")

        with patch("msapling_cli.config._PROFILES_DIR", profiles_dir):
            names = list_profiles()

    assert set(names) == {"alpha", "beta"}


def test_save_profile_and_retrieve():
    """save_profile stores settings; get_settings with that profile returns them."""
    with _TmpDir() as tmp:
        profiles_dir = tmp / "profiles"

        with patch("msapling_cli.config._PROFILES_DIR", profiles_dir), \
             patch("msapling_cli.config._CONFIG_FILE", tmp / "config.json"), \
             patch.dict(os.environ, {"MSAPLING_PROFILE": ""}):

            s = Settings(
                api_url="https://staging.msapling.com",
                default_model="anthropic/claude-3-haiku",
            )
            save_profile("staging", s)

            loaded = get_settings(profile="staging")

    assert loaded.api_url == "https://staging.msapling.com"
    assert loaded.default_model == "anthropic/claude-3-haiku"


def test_profile_env_var_selects_profile():
    """MSAPLING_PROFILE env var selects the active profile."""
    with _TmpDir() as tmp:
        profiles_dir = tmp / "profiles"
        profiles_dir.mkdir()
        data = {"api_url": "https://env-selected.example.com"}
        (profiles_dir / "ci.json").write_text(json.dumps(data), encoding="utf-8")

        with patch("msapling_cli.config._PROFILES_DIR", profiles_dir), \
             patch("msapling_cli.config._CONFIG_FILE", tmp / "config.json"), \
             patch.dict(os.environ, {"MSAPLING_PROFILE": "ci"}):

            settings = get_settings()

    assert settings.api_url == "https://env-selected.example.com"
