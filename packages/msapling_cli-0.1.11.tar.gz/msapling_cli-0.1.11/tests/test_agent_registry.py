from __future__ import annotations

from pathlib import Path

from msapling_cli import agent_registry as ar

_TEST_DIR = Path(__file__).parent / "tmp_cli_workaround"


def _registry_file(name: str) -> Path:
    _TEST_DIR.mkdir(parents=True, exist_ok=True)
    return _TEST_DIR / name


def test_registry_bootstraps_defaults(monkeypatch):
    reg_file = _registry_file("agent_registry_test_bootstrap.json")
    reg_file.write_text("{}", encoding="utf-8")
    monkeypatch.setattr(ar, "REGISTRY_FILE", reg_file)

    agents = ar.load_agent_registry()
    assert len(agents) >= 3
    assert reg_file.exists()
    assert any(a.id == "gemini-fast" for a in agents)


def test_set_agent_enabled_and_configure(monkeypatch):
    reg_file = _registry_file("agent_registry_test_config.json")
    reg_file.write_text("{}", encoding="utf-8")
    monkeypatch.setattr(ar, "REGISTRY_FILE", reg_file)
    ar.load_agent_registry()

    disabled = ar.set_agent_enabled("gemini-fast", False)
    assert disabled.enabled is False

    updated = ar.configure_agent(
        "gemini-fast",
        model="openai/gpt-4o-mini",
        name="Gemini Fast Updated",
        max_parallel=4,
        tags=["fast", "updated"],
    )
    assert updated.model == "openai/gpt-4o-mini"
    assert updated.name == "Gemini Fast Updated"
    assert updated.max_parallel == 4
    assert updated.tags == ["fast", "updated"]


def test_default_models_respects_enabled_only(monkeypatch):
    reg_file = _registry_file("agent_registry_test_defaults.json")
    reg_file.write_text("{}", encoding="utf-8")
    monkeypatch.setattr(ar, "REGISTRY_FILE", reg_file)
    ar.load_agent_registry()
    ar.set_agent_enabled("gemini-fast", False)

    models = ar.default_models_from_registry(limit=3)
    assert models
    assert "google/gemini-2.0-flash-001" not in models
