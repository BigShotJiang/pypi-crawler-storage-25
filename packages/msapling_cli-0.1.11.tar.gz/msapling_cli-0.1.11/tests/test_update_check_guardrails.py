"""Guardrail tests for cli/msapling_cli/update_check.py (18 tests).

All HTTP calls are mocked — no real network traffic.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_cache(latest: str, age_hours: float = 0, *, tmpdir: Path) -> Path:
    """Write a cache file and return its path."""
    checked_at = datetime.now(tz=timezone.utc) - timedelta(hours=age_hours)
    data = {"latest": latest, "checked_at": checked_at.isoformat()}
    cache_path = tmpdir / "update_check_cache.json"
    cache_path.write_text(json.dumps(data), encoding="utf-8")
    return cache_path


def _pypi_response(version: str) -> MagicMock:
    """Return a mock httpx Response for a given PyPI version string."""
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_resp.json.return_value = {"info": {"version": version}}
    return mock_resp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestCachePreventsDoubleCheck:
    def test_cache_prevents_double_check(self, tmp_path):
        """Second call within the cache interval must NOT hit the network."""
        print("[test_cache_prevents_double_check] validating cache hit skips HTTP")
        cache_file = _make_cache("2.0.0", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("httpx.get") as mock_get:
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        mock_get.assert_not_called()
        assert result == "2.0.0"
        print(f"  PASS — returned cached '{result}', no HTTP call made")


class TestNetworkErrorReturnsFalse:
    def test_network_error_returns_false(self, tmp_path):
        """httpx error must return (False, current, current) and not raise."""
        print("[test_network_error_returns_false] validating graceful network failure")
        import httpx
        stale_cache = _make_cache("99.0.0", age_hours=48, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", stale_cache), \
             patch("httpx.get", side_effect=httpx.ConnectError("refused")), \
             patch("msapling_cli.update_check.get_current_version", return_value="0.1.9"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is False
        assert current == "0.1.9"
        assert latest == "0.1.9"
        print(f"  PASS — (False, {current}, {latest}) returned on network error")


class TestOlderVersionTriggersNotice:
    def test_older_version_triggers_notice(self, tmp_path):
        """current < latest should return available=True."""
        print("[test_older_version_triggers_notice] validating update detection")
        cache_file = _make_cache("9.9.9", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("msapling_cli.update_check.get_current_version", return_value="0.1.9"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is True
        assert current == "0.1.9"
        assert latest == "9.9.9"
        print(f"  PASS — available={available}, current={current}, latest={latest}")


class TestSameVersionNoNotice:
    def test_same_version_no_notice(self, tmp_path):
        """current == latest → available=False."""
        print("[test_same_version_no_notice] validating same-version returns False")
        cache_file = _make_cache("0.1.9", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("msapling_cli.update_check.get_current_version", return_value="0.1.9"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is False
        print(f"  PASS — same version, available={available}")


class TestNewerCurrentNoNotice:
    def test_newer_current_no_notice(self, tmp_path):
        """current > latest (dev build) → available=False."""
        print("[test_newer_current_no_notice] validating dev-build does not show update")
        cache_file = _make_cache("0.1.0", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("msapling_cli.update_check.get_current_version", return_value="9.9.9"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is False
        print(f"  PASS — current {current} > latest {latest}, available={available}")


class TestCacheExpiresAfterInterval:
    def test_cache_expires_after_interval(self, tmp_path):
        """Expired cache should trigger a new HTTP call."""
        print("[test_cache_expires_after_interval] validating cache expiry")
        stale_cache = _make_cache("1.0.0", age_hours=25, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", stale_cache), \
             patch("httpx.get", return_value=_pypi_response("2.5.0")) as mock_get, \
             patch("msapling_cli.update_check._write_cache"):
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        mock_get.assert_called_once()
        assert result == "2.5.0"
        print(f"  PASS — expired cache triggered HTTP, got '{result}'")


class TestNoUpdateCheckEnvSkips:
    def test_no_update_check_env_skips(self, monkeypatch):
        """MSAPLING_NO_UPDATE_CHECK=1 → check_and_notify should not be called."""
        print("[test_no_update_check_env_skips] validating env var disables check")
        monkeypatch.setenv("MSAPLING_NO_UPDATE_CHECK", "1")

        called = []

        def _fake_check_and_notify():
            called.append(True)

        # Simulate what main.py's _default_callback does
        if not os.getenv("MSAPLING_NO_UPDATE_CHECK"):
            _fake_check_and_notify()

        assert called == [], "check_and_notify must not be called when env var is set"
        print("  PASS — check_and_notify was not invoked")


class TestMalformedCacheHandled:
    def test_malformed_cache_handled(self, tmp_path):
        """Corrupted cache JSON must fall back gracefully (no crash)."""
        print("[test_malformed_cache_handled] validating corrupt cache tolerance")
        cache_file = tmp_path / "update_check_cache.json"
        cache_file.write_text("{not valid json!!!", encoding="utf-8")

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("httpx.get", return_value=_pypi_response("1.2.3")), \
             patch("msapling_cli.update_check._write_cache"):
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        # Should have fallen through to HTTP and returned the PyPI version
        assert result == "1.2.3"
        print(f"  PASS — malformed cache handled, result={result}")


class TestPypiMalformedResponse:
    def test_pypi_malformed_response(self, tmp_path):
        """Non-JSON PyPI response → returns None, never raises."""
        print("[test_pypi_malformed_response] validating malformed PyPI response tolerance")
        empty_cache = tmp_path / "no_cache.json"  # does not exist

        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.side_effect = ValueError("not json")

        with patch("msapling_cli.update_check.CACHE_FILE", empty_cache), \
             patch("httpx.get", return_value=mock_resp):
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        assert result is None
        print(f"  PASS — malformed PyPI JSON returned None (result={result})")


class TestWriteCacheCreatesDir:
    def test_write_cache_creates_dir(self, tmp_path):
        """_write_cache must create parent directories if missing."""
        print("[test_write_cache_creates_dir] validating dir creation on write")
        nested = tmp_path / "deep" / "nested" / "update_check_cache.json"

        with patch("msapling_cli.update_check.CACHE_FILE", nested):
            from msapling_cli.update_check import _write_cache
            _write_cache("3.0.0")

        assert nested.exists()
        data = json.loads(nested.read_text(encoding="utf-8"))
        assert data["latest"] == "3.0.0"
        print(f"  PASS — cache written to {nested}")


class TestCheckAndNotifySwallowsExceptions:
    def test_check_and_notify_swallows_all_exceptions(self, tmp_path):
        """check_and_notify must not raise even when is_update_available raises."""
        print("[test_check_and_notify_swallows_all_exceptions] validating top-level exception guard")
        with patch("msapling_cli.update_check.is_update_available", side_effect=RuntimeError("boom")):
            from msapling_cli.update_check import check_and_notify
            # Must not raise
            check_and_notify()
        print("  PASS — RuntimeError swallowed by check_and_notify")


class TestPrintUpdateNoticePrintsCorrectly:
    def test_print_update_notice_output(self, capsys):
        """print_update_notice must output the expected one-liner."""
        print("[test_print_update_notice_output] validating notice message format")
        with patch("typer.echo") as mock_echo:
            from msapling_cli.update_check import print_update_notice
            print_update_notice("0.1.9", "2.0.0")
            mock_echo.assert_called_once()
            msg = mock_echo.call_args[0][0]
            assert "2.0.0" in msg
            assert "0.1.9" in msg
            assert "pip install -U msapling-cli" in msg
        print(f"  PASS — notice message contains expected content: {msg!r}")


class TestGetCurrentVersionFallback:
    def test_get_current_version_fallback(self):
        """get_current_version falls back to __version__ when importlib fails."""
        print("[test_get_current_version_fallback] validating __version__ fallback")
        from importlib.metadata import PackageNotFoundError

        with patch("importlib.metadata.version", side_effect=PackageNotFoundError("not found")):
            from msapling_cli.update_check import get_current_version
            ver = get_current_version()

        assert isinstance(ver, str)
        assert len(ver) > 0
        print(f"  PASS — fallback version returned: '{ver}'")


class TestVersionComparisonEdgeCases:
    def test_version_major_bump_detected(self, tmp_path):
        """Major version bump (1.0.0 -> 2.0.0) should be detected."""
        print("[test_version_major_bump_detected] validating major bump detection")
        cache_file = _make_cache("2.0.0", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("msapling_cli.update_check.get_current_version", return_value="1.0.0"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is True
        print(f"  PASS — major bump detected: {current} -> {latest}")

    def test_version_patch_bump_detected(self, tmp_path):
        """Patch bump (0.1.8 -> 0.1.9) should be detected."""
        print("[test_version_patch_bump_detected] validating patch bump detection")
        cache_file = _make_cache("0.1.9", age_hours=1, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("msapling_cli.update_check.get_current_version", return_value="0.1.8"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is True
        print(f"  PASS — patch bump detected: {current} -> {latest}")

    def test_empty_latest_returns_false(self, tmp_path):
        """Empty string from PyPI returns (False, current, current)."""
        print("[test_empty_latest_returns_false] validating empty latest string")
        empty_cache = tmp_path / "no_cache.json"

        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"info": {"version": ""}}

        with patch("msapling_cli.update_check.CACHE_FILE", empty_cache), \
             patch("httpx.get", return_value=mock_resp), \
             patch("msapling_cli.update_check.get_current_version", return_value="0.1.9"):
            from msapling_cli.update_check import is_update_available
            available, current, latest = is_update_available()

        assert available is False
        print(f"  PASS — empty latest string returned available={available}")


class TestCacheFreshnessBoundary:
    def test_cache_exactly_at_boundary_is_fresh(self, tmp_path):
        """Cache at exactly 23h 59m should still be treated as fresh."""
        print("[test_cache_exactly_at_boundary_is_fresh] validating boundary freshness")
        cache_file = _make_cache("5.0.0", age_hours=23.98, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", cache_file), \
             patch("httpx.get") as mock_get:
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        mock_get.assert_not_called()
        assert result == "5.0.0"
        print(f"  PASS — 23h58m cache treated as fresh, no HTTP call")

    def test_cache_just_expired_triggers_http(self, tmp_path):
        """Cache at 24h 1m should be treated as stale."""
        print("[test_cache_just_expired_triggers_http] validating stale cache triggers HTTP")
        stale_cache = _make_cache("1.0.0", age_hours=24.02, tmpdir=tmp_path)

        with patch("msapling_cli.update_check.CACHE_FILE", stale_cache), \
             patch("httpx.get", return_value=_pypi_response("1.5.0")) as mock_get, \
             patch("msapling_cli.update_check._write_cache"):
            from msapling_cli.update_check import get_latest_version
            result = get_latest_version()

        mock_get.assert_called_once()
        assert result == "1.5.0"
        print(f"  PASS — stale cache triggered HTTP call, result={result}")


class TestPrintUpdateNoticeSwallowsError:
    def test_print_update_notice_swallows_error(self):
        """print_update_notice must not raise even when typer.echo fails."""
        print("[test_print_update_notice_swallows_error] validating print exception safety")
        with patch("typer.echo", side_effect=Exception("echo broken")):
            from msapling_cli.update_check import print_update_notice
            # Must not raise
            print_update_notice("0.1.0", "2.0.0")
        print("  PASS — typer.echo exception swallowed")
