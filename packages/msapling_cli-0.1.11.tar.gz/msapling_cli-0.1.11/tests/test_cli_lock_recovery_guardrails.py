"""Guardrail tests for CLI stream lock failure recovery.

Verifies:
- force_release_lock() exists and calls the correct backend endpoint
- /unlock shell command is registered and functional
- 423 error messages include actionable tips
- Session resume clears stale lock state
"""
from __future__ import annotations

import asyncio
import inspect
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# 1. force_release_lock method
# ---------------------------------------------------------------------------

def test_force_release_lock_exists_on_client():
    from msapling_cli.api import MSaplingClient
    assert hasattr(MSaplingClient, "force_release_lock"), (
        "MSaplingClient must have force_release_lock method"
    )


def test_force_release_lock_is_async():
    from msapling_cli.api import MSaplingClient
    assert asyncio.iscoroutinefunction(MSaplingClient.force_release_lock)


def test_force_release_lock_accepts_chat_id():
    from msapling_cli.api import MSaplingClient
    sig = inspect.signature(MSaplingClient.force_release_lock)
    assert "chat_id" in sig.parameters


@pytest.mark.asyncio
async def test_force_release_lock_posts_to_cancel_endpoint():
    """force_release_lock must POST to /api/chat/{chat_id}/cancel."""
    from msapling_cli.api import MSaplingClient

    posted_to: list = []

    async def fake_csrf_retry(fn):
        # Call the lambda to capture the URL it would post to
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json = lambda: {"released": True}
        posted_to.append("called")
        return mock_resp

    client = MSaplingClient.__new__(MSaplingClient)
    client._request_with_csrf_retry = fake_csrf_retry
    client._client = None

    # Patch _get_client so it returns a mock http client
    mock_http = MagicMock()
    mock_http.post = MagicMock(return_value=MagicMock())
    client._get_client = AsyncMock(return_value=mock_http)

    result = await client.force_release_lock("test-chat-id-123")

    assert result is True
    assert len(posted_to) == 1


@pytest.mark.asyncio
async def test_force_release_lock_returns_false_on_non_200():
    """force_release_lock must return False when the server returns a non-200 status."""
    from msapling_cli.api import MSaplingClient

    async def fake_csrf_retry(fn):
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json = lambda: {}
        return mock_resp

    client = MSaplingClient.__new__(MSaplingClient)
    client._request_with_csrf_retry = fake_csrf_retry
    client._get_client = AsyncMock(return_value=MagicMock())

    result = await client.force_release_lock("missing-chat")
    assert result is False


@pytest.mark.asyncio
async def test_force_release_lock_returns_false_on_exception():
    """force_release_lock must not raise — swallow exceptions and return False."""
    from msapling_cli.api import MSaplingClient

    async def fake_csrf_retry(fn):
        raise ConnectionError("network down")

    client = MSaplingClient.__new__(MSaplingClient)
    client._request_with_csrf_retry = fake_csrf_retry
    client._get_client = AsyncMock(return_value=MagicMock())

    result = await client.force_release_lock("any-chat")
    assert result is False


# ---------------------------------------------------------------------------
# 2. /unlock shell command
# ---------------------------------------------------------------------------

def test_shell_handles_unlock_command():
    """Shell must have a handler for the /unlock command."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "/unlock" in src, "Shell must handle /unlock command"


def test_shell_unlock_calls_force_release_lock():
    """Shell /unlock handler must call force_release_lock."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "force_release_lock" in src, (
        "/unlock command must call client.force_release_lock"
    )


def test_shell_unlock_accepts_chat_id_argument():
    """Shell /unlock handler must accept an optional chat_id argument."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    # Should use args.strip() or similar to accept optional chat_id
    unlock_idx = src.index("/unlock")
    unlock_section = src[unlock_idx:unlock_idx + 600]
    assert "args" in unlock_section or "chat_id" in unlock_section, (
        "/unlock must accept an optional chat_id argument"
    )


# ---------------------------------------------------------------------------
# 3. 423 error messages include actionable tips
# ---------------------------------------------------------------------------

def test_shell_423_message_mentions_unlock():
    """423 recovery messages must mention /unlock so users know how to fix it."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    # Count how many times /unlock appears in lock-related messages
    assert src.count("/unlock") >= 3, (
        "Shell must mention /unlock in at least 3 places (recovery + both loops)"
    )


def test_shell_423_message_mentions_doctor():
    """423 auto-recovery failure message must mention msapling doctor."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "doctor" in src, (
        "Lock failure message must mention `msapling doctor` as a diagnostic tool"
    )


def test_shell_lock_message_explains_http_423():
    """Lock messages must reference HTTP 423 so users understand the error code."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    assert "423" in src, (
        "Lock failure message must mention HTTP 423 to be diagnosable"
    )


# ---------------------------------------------------------------------------
# 4. Session resume clears stale lock
# ---------------------------------------------------------------------------

def test_shell_session_resume_clears_stale_lock():
    """Shell must call force_release_lock after loading a saved session."""
    from msapling_cli import shell as shell_mod
    src = inspect.getsource(shell_mod)
    # ensure_future is used for fire-and-forget stale lock clear
    assert "ensure_future" in src and "force_release_lock" in src, (
        "Shell must use asyncio.ensure_future(force_release_lock(...)) on session resume"
    )


def test_is_chat_locked_error_detects_423_status_code():
    """_is_chat_locked_error must detect HTTP 423 status code on the exception."""
    from msapling_cli.api import ChatLockedError
    from msapling_cli import shell as shell_mod

    # Find the Shell class
    shell_cls = getattr(shell_mod, "InteractiveShell", None) or getattr(shell_mod, "MSaplingShell", None) or getattr(shell_mod, "Shell", None)
    assert shell_cls is not None, "Shell class not found in shell module"

    exc = ChatLockedError("chat-abc")
    # Must not raise
    shell_instance = object.__new__(shell_cls)
    result = shell_instance._is_chat_locked_error(exc)
    assert result is True


def test_is_chat_locked_error_false_for_normal_exception():
    """_is_chat_locked_error must return False for non-423 exceptions."""
    from msapling_cli import shell as shell_mod

    shell_cls = getattr(shell_mod, "InteractiveShell", None) or getattr(shell_mod, "MSaplingShell", None) or getattr(shell_mod, "Shell", None)
    assert shell_cls is not None

    shell_instance = object.__new__(shell_cls)
    result = shell_instance._is_chat_locked_error(ValueError("not a lock"))
    assert result is False


# ---------------------------------------------------------------------------
# 5. ChatLockedError has correct status_code
# ---------------------------------------------------------------------------

def test_chat_locked_error_has_423_status():
    from msapling_cli.api import ChatLockedError
    exc = ChatLockedError("chat-id-xyz")
    assert exc.status_code == 423


def test_chat_locked_error_carries_chat_id():
    from msapling_cli.api import ChatLockedError
    exc = ChatLockedError("my-chat-999")
    assert exc.chat_id == "my-chat-999"
