from __future__ import annotations

from msapling_cli import fanout_governance as fg


def test_runtime_fanout_budget_honors_env_cap(monkeypatch):
    monkeypatch.setenv("MSAPLING_FANOUT_CAP", "2")
    monkeypatch.setattr(fg.os, "cpu_count", lambda: 16)
    monkeypatch.setattr(fg, "_detect_memory_gb", lambda: 64.0)
    budget = fg.runtime_fanout_budget()
    assert budget["recommended_cap"] == 2
    assert budget["cpu_cap"] >= 2
    assert budget["memory_cap"] >= 2


def test_runtime_fanout_budget_uses_provider_hint(monkeypatch):
    monkeypatch.delenv("MSAPLING_FANOUT_CAP", raising=False)
    monkeypatch.setenv("MSAPLING_PROVIDER_CONCURRENCY_HINT", "1")
    monkeypatch.setattr(fg.os, "cpu_count", lambda: 32)
    monkeypatch.setattr(fg, "_detect_memory_gb", lambda: 64.0)
    budget = fg.runtime_fanout_budget()
    assert budget["recommended_cap"] == 1
    assert budget["provider_hint_cap"] == 1


def test_fanout_budget_detail_includes_all_inputs():
    detail = fg.fanout_budget_detail(
        {
            "recommended_cap": 3,
            "cpu_count": 8,
            "cpu_cap": 4,
            "memory_gb": 12.5,
            "memory_cap": 4,
            "provider_hint_cap": 2,
            "env_cap": 3,
        }
    )
    assert "recommended=3" in detail
    assert "cpu=8->4" in detail
    assert "memory=12.5GB->4" in detail
