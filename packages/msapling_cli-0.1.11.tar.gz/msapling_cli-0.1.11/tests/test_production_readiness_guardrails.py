"""Guardrail tests for production readiness gap fixes.

Covers:
  1 — Sandbox env-var stripping (agent.py safe_env)
  2 — credentials rotate command exists and validates password mismatch
  3 — prompt_toolkit scroll session initialises without error
  4 — PyPI publish workflow file exists and is well-formed
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# 1 — Sandbox env-var stripping
# ---------------------------------------------------------------------------

def test_sandbox_strips_ld_preload():
    """make_safe_env() must exclude library-injection env vars."""
    from msapling_cli.agent import make_safe_env

    injected = {
        "LD_PRELOAD": "/evil/lib.so",
        "LD_LIBRARY_PATH": "/evil",
        "DYLD_INSERT_LIBRARIES": "/evil/mac.dylib",
        "PYTHONPATH": "/evil/py",
        "NODE_OPTIONS": "--require /evil/hook",
        "JAVA_TOOL_OPTIONS": "-javaagent:/evil.jar",
        "PATH": os.environ.get("PATH", "/usr/bin"),
        "HOME": os.path.expanduser("~"),
    }
    with patch.dict(os.environ, injected, clear=False):
        safe = make_safe_env()

    assert "LD_PRELOAD" not in safe
    assert "LD_LIBRARY_PATH" not in safe
    assert "DYLD_INSERT_LIBRARIES" not in safe
    assert "PYTHONPATH" not in safe
    assert "NODE_OPTIONS" not in safe
    assert "JAVA_TOOL_OPTIONS" not in safe
    assert "PATH" in safe
    assert "HOME" in safe


def test_sandbox_preserves_path():
    """make_safe_env() keeps PATH intact so project tools remain discoverable."""
    from msapling_cli.agent import make_safe_env

    original_path = "/custom/usr/bin:/usr/local/bin"
    with patch.dict(os.environ, {"PATH": original_path}, clear=False):
        safe = make_safe_env()

    assert safe.get("PATH") == original_path


def test_sandbox_strips_all_declared_keys():
    """Every key in _STRIP_ENV_KEYS must be absent from make_safe_env() output."""
    from msapling_cli.agent import make_safe_env, _STRIP_ENV_KEYS

    injected = {k: "evil" for k in _STRIP_ENV_KEYS}
    with patch.dict(os.environ, injected, clear=False):
        safe = make_safe_env()

    for key in _STRIP_ENV_KEYS:
        assert key not in safe, f"{key} was not stripped from safe_env"


# ---------------------------------------------------------------------------
# 2 — credentials rotate command
# ---------------------------------------------------------------------------

def test_credentials_rotate_command_registered():
    """credentials rotate must be a registered Typer command."""
    from msapling_cli import main
    # Walk the registered commands on credentials_app
    cmd_names = [cmd.name for cmd in main.credentials_app.registered_commands]
    assert "rotate" in cmd_names, f"'rotate' not in credentials commands: {cmd_names}"


def test_credentials_rotate_password_mismatch(tmp_path, capsys):
    """credentials rotate must abort when new passwords don't match."""
    from msapling_cli import main
    import getpass

    # Create a fake encrypted credentials setup
    salt = os.urandom(32)
    key = main._derive_fernet_key("oldpass", salt)
    from cryptography.fernet import Fernet
    ciphertext = Fernet(key).encrypt(b'{"token":"abc"}')

    enc_file = tmp_path / "credentials.enc"
    salt_file = tmp_path / ".credentials_salt"
    enc_file.write_bytes(ciphertext)
    salt_file.write_bytes(salt)

    passwords = iter(["oldpass", "newpass1", "newpass2_different"])

    import click

    with (
        patch.object(main, "_CREDENTIALS_ENCRYPTED_FILE", enc_file),
        patch.object(main, "_CREDENTIALS_SALT_FILE", salt_file),
        patch("getpass.getpass", side_effect=passwords),
    ):
        try:
            main.credentials_rotate()
        except (SystemExit, click.exceptions.Exit):
            pass

    out = capsys.readouterr().out
    assert "do not match" in out.lower() or "mismatch" in out.lower() or "Passwords do not match" in out


# ---------------------------------------------------------------------------
# 3 — prompt_toolkit scroll session
# ---------------------------------------------------------------------------

def test_pt_session_initialises(tmp_path):
    """_get_pt_session() must return a non-None session when prompt_toolkit is installed."""
    import msapling_cli.shell as sh
    # Reset module-level cache so we get a fresh attempt
    sh._pt_session = None
    # Redirect history file to tmp_path
    with patch("msapling_cli.shell.Path") as mock_path_cls:
        # Only intercept the history path construction
        real_path = Path
        def path_side(*args, **kwargs):
            p = real_path(*args, **kwargs)
            if ".msapling" in str(p) and "chat_history" in str(p):
                return tmp_path / "chat_history"
            return p
        mock_path_cls.home.return_value = tmp_path
        mock_path_cls.side_effect = path_side

        # Don't mock — just call it and see if prompt_toolkit works
        sh._pt_session = None

    try:
        import prompt_toolkit  # noqa: F401
        pt_available = True
    except ImportError:
        pt_available = False

    sh._pt_session = None
    result = sh._get_pt_session()
    if pt_available:
        assert result is not None, "_get_pt_session() returned None despite prompt_toolkit being installed"
    else:
        assert result is None, "_get_pt_session() should return None when prompt_toolkit is absent"


def test_pt_session_cached():
    """_get_pt_session() must return the same object on repeated calls."""
    import msapling_cli.shell as sh
    sh._pt_session = None
    first = sh._get_pt_session()
    second = sh._get_pt_session()
    assert first is second


# ---------------------------------------------------------------------------
# 4 — PyPI publish workflow
# ---------------------------------------------------------------------------

def test_publish_cli_workflow_exists():
    """publish_cli.yml must exist in .github/workflows."""
    repo_root = Path(__file__).parent.parent.parent  # cli/tests/../../..
    workflow = repo_root / ".github" / "workflows" / "publish_cli.yml"
    assert workflow.exists(), f"publish_cli.yml not found at {workflow}"


def test_publish_cli_workflow_has_pypi_publish():
    """publish_cli.yml must reference the pypa/gh-action-pypi-publish action."""
    repo_root = Path(__file__).parent.parent.parent
    workflow = repo_root / ".github" / "workflows" / "publish_cli.yml"
    content = workflow.read_text(encoding="utf-8")
    assert "pypa/gh-action-pypi-publish" in content
    assert "cli/v" in content  # tag filter


def test_publish_cli_workflow_runs_tests():
    """publish_cli.yml must run pytest before publishing."""
    repo_root = Path(__file__).parent.parent.parent
    workflow = repo_root / ".github" / "workflows" / "publish_cli.yml"
    content = workflow.read_text(encoding="utf-8")
    assert "pytest" in content
    assert "needs: test" in content
