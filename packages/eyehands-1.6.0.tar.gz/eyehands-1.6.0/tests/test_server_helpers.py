"""Unit tests for pure helpers in eyehands.server.

These test side-effect-free pure functions and one filesystem function
(_install_skill) against a temporary HOME directory. No server is started,
no real token file is touched, no network calls are made.

Run with either pytest or plain unittest — tests are all TestCase-based so
both discover them:

    python -m unittest discover tests
    python -m pytest tests/

Importing eyehands.server has module-level side effects (mss CAPTUREBLT
patch, SetProcessDpiAwarenessContext, virtual-desktop metrics) but they are
all idempotent and Windows-guarded with try/except.
"""

import contextlib
import io
import os
import tempfile
import unittest

import numpy as np

from eyehands import server as S


class TestVersionTuple(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(S._version_tuple("1.2.3"), (1, 2, 3))

    def test_two_parts(self):
        self.assertEqual(S._version_tuple("1.2"), (1, 2))

    def test_four_parts(self):
        self.assertEqual(S._version_tuple("1.2.3.4"), (1, 2, 3, 4))

    def test_empty_string(self):
        self.assertEqual(S._version_tuple(""), (0,))

    def test_none(self):
        self.assertEqual(S._version_tuple(None), (0,))

    def test_non_numeric_component_falls_back(self):
        self.assertEqual(S._version_tuple("1.2.beta"), (0,))

    def test_ordering_that_string_compare_would_break(self):
        # The whole reason this helper exists: string compare thinks
        # "1.2.10" < "1.2.9". Tuple compare does not.
        self.assertLess(S._version_tuple("1.2.9"), S._version_tuple("1.2.10"))
        self.assertGreater(S._version_tuple("1.10.0"), S._version_tuple("1.9.9"))
        self.assertEqual(S._version_tuple("1.4.0"), S._version_tuple("1.4.0"))


class TestNormalizeFormat(unittest.TestCase):
    def test_default_is_jpeg(self):
        self.assertEqual(S._normalize_format(None), "jpeg")
        self.assertEqual(S._normalize_format(""), "jpeg")

    def test_jpg_alias(self):
        self.assertEqual(S._normalize_format("jpg"), "jpeg")
        self.assertEqual(S._normalize_format("JPG"), "jpeg")

    def test_case_insensitive(self):
        self.assertEqual(S._normalize_format("PNG"), "png")
        self.assertEqual(S._normalize_format("WebP"), "webp")

    def test_unknown_falls_back_to_jpeg(self):
        self.assertEqual(S._normalize_format("tiff"), "jpeg")
        self.assertEqual(S._normalize_format("bmp"), "jpeg")


class TestFormatExtension(unittest.TestCase):
    def test_jpeg(self):
        self.assertEqual(S._format_extension("jpeg"), "jpg")
        self.assertEqual(S._format_extension("jpg"), "jpg")

    def test_png(self):
        self.assertEqual(S._format_extension("png"), "png")

    def test_webp(self):
        self.assertEqual(S._format_extension("webp"), "webp")

    def test_unknown_falls_back_to_jpg(self):
        # Via _normalize_format falling back to jpeg
        self.assertEqual(S._format_extension("tiff"), "jpg")


class TestIsProEndpoint(unittest.TestCase):
    def test_free_endpoints(self):
        self.assertFalse(S._is_pro_endpoint("/ping"))
        self.assertFalse(S._is_pro_endpoint("/click"))
        self.assertFalse(S._is_pro_endpoint("/move"))
        self.assertFalse(S._is_pro_endpoint("/screenshot"))
        self.assertFalse(S._is_pro_endpoint("/type_text"))

    def test_pro_endpoints(self):
        self.assertTrue(S._is_pro_endpoint("/batch"))
        self.assertTrue(S._is_pro_endpoint("/click_at"))
        self.assertTrue(S._is_pro_endpoint("/click_and_wait"))
        self.assertTrue(S._is_pro_endpoint("/type_and_enter"))
        self.assertTrue(S._is_pro_endpoint("/smooth_move"))
        self.assertTrue(S._is_pro_endpoint("/ui/click_element"))

    def test_query_string_is_stripped(self):
        self.assertTrue(S._is_pro_endpoint("/batch?x=1"))
        self.assertFalse(S._is_pro_endpoint("/ping?token=abc"))


class TestResizeRgbFast(unittest.TestCase):
    def test_no_downscale_when_already_small(self):
        arr = np.zeros((100, 200, 3), dtype=np.uint8)
        out, scale = S._resize_rgb_fast(arr, 400)
        self.assertIs(out, arr)  # no copy
        self.assertEqual(scale, 1.0)

    def test_exact_width_skips_resize(self):
        arr = np.zeros((100, 400, 3), dtype=np.uint8)
        out, scale = S._resize_rgb_fast(arr, 400)
        self.assertIs(out, arr)
        self.assertEqual(scale, 1.0)

    def test_downscale_halves(self):
        arr = np.zeros((200, 800, 3), dtype=np.uint8)
        out, scale = S._resize_rgb_fast(arr, 400)
        self.assertEqual(out.shape[1], 400)
        self.assertEqual(out.shape[0], 100)  # 200 * 0.5
        self.assertAlmostEqual(scale, 0.5, places=5)

    def test_preserves_channels_and_dtype(self):
        arr = np.zeros((150, 600, 3), dtype=np.uint8)
        out, _ = S._resize_rgb_fast(arr, 300)
        self.assertEqual(out.shape[2], 3)
        self.assertEqual(out.dtype, np.uint8)


class TestEncodeRgb(unittest.TestCase):
    def _gradient(self, w=64, h=48):
        arr = np.zeros((h, w, 3), dtype=np.uint8)
        for y in range(h):
            arr[y, :, 0] = (y * 255) // max(h - 1, 1)
        for x in range(w):
            arr[:, x, 1] = (x * 255) // max(w - 1, 1)
        arr[:, :, 2] = 128
        return arr

    def test_jpeg_magic_and_content_type(self):
        data, ct = S._encode_rgb(self._gradient(), "jpeg")
        self.assertEqual(ct, "image/jpeg")
        self.assertTrue(data.startswith(b"\xff\xd8\xff"))

    def test_jpg_alias(self):
        data, ct = S._encode_rgb(self._gradient(), "jpg")
        self.assertEqual(ct, "image/jpeg")
        self.assertTrue(data.startswith(b"\xff\xd8\xff"))

    def test_png_is_lossless_roundtrip(self):
        from PIL import Image
        arr = self._gradient()
        data, ct = S._encode_rgb(arr, "png")
        self.assertEqual(ct, "image/png")
        self.assertTrue(data.startswith(b"\x89PNG\r\n\x1a\n"))
        decoded = np.asarray(Image.open(io.BytesIO(data)).convert("RGB"))
        self.assertTrue(np.array_equal(decoded, arr))

    def test_webp_riff_container(self):
        data, ct = S._encode_rgb(self._gradient(), "webp")
        self.assertEqual(ct, "image/webp")
        self.assertEqual(data[0:4], b"RIFF")
        self.assertEqual(data[8:12], b"WEBP")

    def test_default_format_is_jpeg(self):
        data, ct = S._encode_rgb(self._gradient())
        self.assertEqual(ct, "image/jpeg")

    def test_unknown_format_falls_back_to_jpeg(self):
        data, ct = S._encode_rgb(self._gradient(), "tiff")
        self.assertEqual(ct, "image/jpeg")


class TestHostHeaderOk(unittest.TestCase):
    """Regression tests for the Host-header DNS-rebinding check.

    The original implementation used `host.startswith(("127.0.0.1", "localhost"))`
    which (1) matched anything with a loopback-prefixed hostname like
    `127.0.0.1.attacker.com` and (2) silently passed an empty Host header
    because `if host and not startswith(...)` short-circuits to False when
    host is empty. These tests pin both fixes.
    """

    def test_loopback_ipv4(self):
        self.assertTrue(S._host_header_ok("127.0.0.1"))
        self.assertTrue(S._host_header_ok("127.0.0.1:7331"))

    def test_loopback_name(self):
        self.assertTrue(S._host_header_ok("localhost"))
        self.assertTrue(S._host_header_ok("localhost:7331"))

    def test_loopback_ipv6(self):
        self.assertTrue(S._host_header_ok("[::1]"))
        self.assertTrue(S._host_header_ok("[::1]:7331"))
        self.assertTrue(S._host_header_ok("::1"))

    def test_empty_host_rejected(self):
        # The old `host and startswith(...)` path accepted this silently.
        self.assertFalse(S._host_header_ok(""))
        self.assertFalse(S._host_header_ok(None))

    def test_prefix_attack_rejected(self):
        # The old startswith check accepted these because they start with
        # "127.0.0.1" / "localhost". Exact-match rejects them.
        self.assertFalse(S._host_header_ok("127.0.0.1.attacker.com"))
        self.assertFalse(S._host_header_ok("127.0.0.1.attacker.com:80"))
        self.assertFalse(S._host_header_ok("localhost.attacker.com"))

    def test_malformed_ipv6_bracket_rejected(self):
        self.assertFalse(S._host_header_ok("[::1"))

    def test_other_hosts_rejected(self):
        self.assertFalse(S._host_header_ok("example.com"))
        self.assertFalse(S._host_header_ok("192.168.1.1:7331"))


class TestInstallSkill(unittest.TestCase):
    """_install_skill() writes a rendered SKILL.md into HOME. Sandbox HOME
    so we don't touch the user's real ~/.claude directory."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self._saved_env = {k: os.environ.get(k) for k in ("USERPROFILE", "HOME")}
        os.environ["USERPROFILE"] = self.tmp.name
        os.environ["HOME"] = self.tmp.name
        self._saved_token = S._TOKEN_FILE
        S._TOKEN_FILE = r"C:\Fake\eyehands\.eyehands-token"

    def tearDown(self):
        S._TOKEN_FILE = self._saved_token
        for k, v in self._saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        self.tmp.cleanup()

    def _dest(self):
        return os.path.join(self.tmp.name, ".claude", "skills", "eyehands", "SKILL.md")

    def _silent_install(self):
        """_install_skill prints status to stdout. Swallow it in tests."""
        with contextlib.redirect_stdout(io.StringIO()):
            return S._install_skill()

    def test_writes_rendered_skill(self):
        rc = self._silent_install()
        self.assertEqual(rc, 0)
        self.assertTrue(os.path.exists(self._dest()))
        with open(self._dest(), encoding="utf-8") as f:
            content = f.read()
        self.assertNotIn("{{TOKEN_FILE}}", content)
        # Backslashes are rewritten to forward slashes for git-bash curl
        self.assertIn("C:/Fake/eyehands/.eyehands-token", content)
        self.assertNotIn(r"C:\Fake", content)

    def test_second_call_is_idempotent_noop(self):
        self.assertEqual(self._silent_install(), 0)
        self.assertEqual(self._silent_install(), 0)
        with open(self._dest(), encoding="utf-8") as f:
            content = f.read()
        self.assertIn("C:/Fake/eyehands/.eyehands-token", content)
        self.assertNotIn("{{TOKEN_FILE}}", content)

    def test_overwrites_when_token_path_changes(self):
        self.assertEqual(self._silent_install(), 0)
        with open(self._dest(), encoding="utf-8") as f:
            self.assertIn("C:/Fake/eyehands/.eyehands-token", f.read())

        # Pretend eyehands was reinstalled somewhere else
        S._TOKEN_FILE = r"D:\Other\eyehands\.eyehands-token"
        self.assertEqual(self._silent_install(), 0)
        with open(self._dest(), encoding="utf-8") as f:
            content = f.read()
        self.assertIn("D:/Other/eyehands/.eyehands-token", content)
        self.assertNotIn("C:/Fake/eyehands/.eyehands-token", content)


class TestFreeTelemetry(unittest.TestCase):
    """Install-token generation and --no-telemetry opt-out. Uses a temp dir
    for the token file so the real .install_token in _DATA_DIR is untouched."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self._saved_token_file = S._INSTALL_TOKEN_FILE
        self._saved_marker_file = S._NO_TELEMETRY_FILE
        self._saved_cli_flag = S._telemetry_disabled_cli
        S._INSTALL_TOKEN_FILE = os.path.join(self.tmp.name, ".install_token")
        S._NO_TELEMETRY_FILE = os.path.join(self.tmp.name, ".no-telemetry")

    def tearDown(self):
        S._INSTALL_TOKEN_FILE = self._saved_token_file
        S._NO_TELEMETRY_FILE = self._saved_marker_file
        S._telemetry_disabled_cli = self._saved_cli_flag
        self.tmp.cleanup()

    def test_first_call_generates_persistent_token(self):
        tok = S._get_install_token()
        self.assertEqual(len(tok), 32)
        self.assertTrue(os.path.exists(S._INSTALL_TOKEN_FILE))
        with open(S._INSTALL_TOKEN_FILE, "rb") as f:
            self.assertEqual(f.read(), tok)

    def test_second_call_returns_same_token(self):
        tok1 = S._get_install_token()
        tok2 = S._get_install_token()
        self.assertEqual(tok1, tok2)

    def test_corrupt_token_file_regenerates(self):
        with open(S._INSTALL_TOKEN_FILE, "wb") as f:
            f.write(b"too short")
        tok = S._get_install_token()
        self.assertEqual(len(tok), 32)
        self.assertNotEqual(tok, b"too short")

    def test_install_id_is_first_32_hex_of_sha256(self):
        import hashlib
        tok = S._get_install_token()
        expected = hashlib.sha256(tok).hexdigest()[:32]
        # Length + charset sanity check
        self.assertEqual(len(expected), 32)
        self.assertTrue(all(c in "0123456789abcdef" for c in expected))

    def test_cli_flag_disables_telemetry(self):
        S._telemetry_disabled_cli = True
        self.assertTrue(S._telemetry_disabled())
        S._telemetry_disabled_cli = False
        self.assertFalse(S._telemetry_disabled())

    def test_marker_file_disables_telemetry(self):
        self.assertFalse(S._telemetry_disabled())
        with open(S._NO_TELEMETRY_FILE, "w") as f:
            f.write("")
        self.assertTrue(S._telemetry_disabled())

    def test_free_checkin_is_noop_when_disabled(self):
        """When disabled, _free_checkin must not touch the filesystem at all
        (no token file created, no ping cache written). This guarantees
        --no-telemetry stops *everything*, not just the network call."""
        S._telemetry_disabled_cli = True
        S._free_checkin()
        self.assertFalse(os.path.exists(S._INSTALL_TOKEN_FILE))


if __name__ == "__main__":
    unittest.main()
