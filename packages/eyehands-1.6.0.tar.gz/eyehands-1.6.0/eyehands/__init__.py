"""eyehands — give AI agents eyes and hands on Windows.

Local HTTP server on port 7331 for screen capture, mouse/keyboard input,
Windows UI Automation, and license-gated Pro features.

This __init__ runs the two process-level Windows setup steps that MUST
happen before any of the sibling modules (input.py, capture.py) import,
because those modules read display metrics at module-load time:

1. Per-Monitor v2 DPI awareness — so Win32 APIs return physical pixels
   matching mss/DXcam captures on high-DPI displays.
2. mss CAPTUREBLT flag clear — the default BitBlt flag forces Windows to
   hide the cursor before every GDI capture, causing visible blink. SRCCOPY
   alone captures without touching the cursor.

Both are idempotent and Windows-guarded so importing on other platforms
(e.g. to run the test suite under coverage in CI) is a no-op.
"""

# ── Per-Monitor v2 DPI awareness ──────────────────────────────────────────────
try:
    import ctypes as _ctypes
    _ctypes.windll.user32.SetProcessDpiAwarenessContext(_ctypes.c_void_p(-4))
except Exception:
    pass  # Not Windows, or Windows < 8.1 without the API

# ── mss CAPTUREBLT patch ──────────────────────────────────────────────────────
try:
    import mss.windows as _mss_win
    _mss_win.CAPTUREBLT = 0
except Exception:
    pass

from .server import __version__

__all__ = ["__version__"]
