"""Screen capture, image encoding, window-scoped capture, and FrameBuffer.

Image helpers are shared between the background `FrameBuffer` loop and the
on-demand `/screenshot` path in `server.Handler._grab`, so both produce
identical resize quality and format negotiation. JPEG goes through
`simplejpeg` (libturbojpeg) when available for a 2-6x speedup over Pillow.

The `FrameBuffer` picks a capture backend at startup in priority order:
BetterCam (DXGI, ~120fps) → DXcam (DXGI, ~39fps) → mss (GDI fallback). The
name of the winning backend lands in the module-level `_capture_backend`
global and is surfaced on `/ping` so Claude can nudge the user toward
bettercam when they're stuck on the slow GDI path.

`_tips_enabled` / `_build_tips()` live here too — the tips are mostly about
capture performance, and keeping them next to `_capture_backend` means
`_build_tips()` can read state directly instead of through an import dance.
`main()` in server.py flips the flag via `capture._tips_enabled = ...`.
"""

import ctypes
import ctypes.wintypes as wintypes
import base64
import io
import threading
import time

import mss

from .input import get_cursor_pos


# ── Image format helpers ──────────────────────────────────────────────────────

_VALID_IMAGE_FORMATS = ("jpeg", "png", "webp")


def _normalize_format(fmt):
    """Lowercase + accept 'jpg' as 'jpeg'. Unknown values fall back to jpeg."""
    f = (fmt or "jpeg").lower()
    if f == "jpg":
        f = "jpeg"
    if f not in _VALID_IMAGE_FORMATS:
        f = "jpeg"
    return f


def _resize_rgb_fast(arr, max_w):
    """Downscale a numpy RGB uint8 array to max_w. Returns (resized_arr, scale).

    Uses cv2.INTER_AREA (the recommended interpolation for downscaling) when
    cv2 is available, Pillow LANCZOS otherwise — both are higher quality than
    BILINEAR at the same CPU budget and match what FrameBuffer already uses.
    """
    h, w = arr.shape[:2]
    if w <= max_w:
        return arr, 1.0
    scale = max_w / w
    new_w = max_w
    new_h = int(h * scale)
    try:
        import cv2
        return cv2.resize(arr, (new_w, new_h), interpolation=cv2.INTER_AREA), scale
    except ImportError:
        from PIL import Image
        import numpy as np
        pil = Image.fromarray(arr).resize((new_w, new_h), Image.LANCZOS)
        return np.asarray(pil), scale


def _encode_rgb(arr, fmt="jpeg", quality=70):
    """Encode a numpy RGB uint8 array into the requested image format.

    Returns (bytes, content_type). Accepts 'jpeg', 'png', 'webp' (and 'jpg').
    JPEG uses simplejpeg when available (2-6x faster) and falls back to Pillow.
    PNG and WebP always go through Pillow.
    """
    fmt = _normalize_format(fmt)
    if fmt == "jpeg":
        try:
            import simplejpeg
            return simplejpeg.encode_jpeg(arr, quality=quality, colorspace="RGB"), "image/jpeg"
        except ImportError:
            from PIL import Image
            buf = io.BytesIO()
            Image.fromarray(arr).save(buf, format="JPEG", quality=quality, optimize=False)
            return buf.getvalue(), "image/jpeg"
    from PIL import Image
    buf = io.BytesIO()
    if fmt == "png":
        # compress_level=1 trades a bit of size for much faster encoding. PNG
        # is still lossless at any level.
        Image.fromarray(arr).save(buf, format="PNG", optimize=False, compress_level=1)
        return buf.getvalue(), "image/png"
    if fmt == "webp":
        # WebP quality uses the same 1-100 scale. Lossy by default; method=4 is
        # a reasonable speed/quality tradeoff.
        Image.fromarray(arr).save(buf, format="WEBP", quality=quality, method=4)
        return buf.getvalue(), "image/webp"
    # Unreachable — _normalize_format already constrained the value
    raise ValueError(f"unknown format: {fmt}")


def _format_extension(fmt):
    """Return filename extension for a format string (for logging/debug only)."""
    fmt = _normalize_format(fmt)
    return {"jpeg": "jpg", "png": "png", "webp": "webp"}[fmt]


# ── Window-scoped capture (PrintWindow) ───────────────────────────────────────

class _RECT(ctypes.Structure):
    _fields_ = [("left",   wintypes.LONG),
                ("top",    wintypes.LONG),
                ("right",  wintypes.LONG),
                ("bottom", wintypes.LONG)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize",          wintypes.DWORD),
        ("biWidth",         wintypes.LONG),
        ("biHeight",        wintypes.LONG),
        ("biPlanes",        wintypes.WORD),
        ("biBitCount",      wintypes.WORD),
        ("biCompression",   wintypes.DWORD),
        ("biSizeImage",     wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed",       wintypes.DWORD),
        ("biClrImportant",  wintypes.DWORD),
    ]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER),
                ("bmiColors", wintypes.DWORD * 3)]


# Declare argtypes/restype on the Win32 functions _grab_hwnd uses so pointer-
# sized handles round-trip correctly on 64-bit Windows — without this, ctypes
# defaults to `int` for return values and truncates handle values. Guarded in
# try/except so importing the module on non-Windows (CI, tests) is a no-op.
try:
    _user32 = ctypes.windll.user32
    _gdi32  = ctypes.windll.gdi32
    _user32.GetWindowRect.argtypes        = [wintypes.HWND, ctypes.POINTER(_RECT)]
    _user32.GetWindowRect.restype         = wintypes.BOOL
    _user32.GetWindowDC.argtypes          = [wintypes.HWND]
    _user32.GetWindowDC.restype           = wintypes.HDC
    _user32.ReleaseDC.argtypes            = [wintypes.HWND, wintypes.HDC]
    _user32.ReleaseDC.restype             = ctypes.c_int
    _user32.PrintWindow.argtypes          = [wintypes.HWND, wintypes.HDC, wintypes.UINT]
    _user32.PrintWindow.restype           = wintypes.BOOL
    _gdi32.CreateCompatibleDC.argtypes    = [wintypes.HDC]
    _gdi32.CreateCompatibleDC.restype     = wintypes.HDC
    _gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
    _gdi32.CreateCompatibleBitmap.restype  = wintypes.HBITMAP
    _gdi32.SelectObject.argtypes          = [wintypes.HDC, wintypes.HGDIOBJ]
    _gdi32.SelectObject.restype           = wintypes.HGDIOBJ
    _gdi32.GetDIBits.argtypes             = [
        wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT,
        ctypes.c_void_p, ctypes.POINTER(_BITMAPINFO), wintypes.UINT,
    ]
    _gdi32.GetDIBits.restype              = ctypes.c_int
    _gdi32.DeleteObject.argtypes          = [wintypes.HGDIOBJ]
    _gdi32.DeleteObject.restype           = wintypes.BOOL
    _gdi32.DeleteDC.argtypes              = [wintypes.HDC]
    _gdi32.DeleteDC.restype               = wintypes.BOOL
except (OSError, AttributeError):
    pass


def _grab_hwnd(hwnd):
    """Capture a specific window by HWND using the Win32 PrintWindow API.

    Returns (rgb_ndarray, left, top) in physical screen pixels. Works even
    when the target window is partially occluded or fully covered — unlike
    mss/DXGI desktop capture, which only sees what's composited on screen.
    Uses PW_RENDERFULLCONTENT (0x2) so hardware-composited windows (Chrome,
    Electron, games using DWM) render correctly; falls back to flags=0 for
    older windows that don't support the flag.
    """
    import numpy as np
    user32 = ctypes.windll.user32
    gdi32  = ctypes.windll.gdi32

    rect = _RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        raise OSError(f"GetWindowRect failed for hwnd={hwnd}")

    left, top = rect.left, rect.top
    width  = rect.right - rect.left
    height = rect.bottom - rect.top
    if width <= 0 or height <= 0:
        raise OSError(f"invalid window dimensions {width}x{height} for hwnd={hwnd}")

    hdc_window = user32.GetWindowDC(hwnd)
    if not hdc_window:
        raise OSError(f"GetWindowDC failed for hwnd={hwnd}")

    hdc_mem = None
    hbitmap = None
    old_bitmap = None
    try:
        hdc_mem = gdi32.CreateCompatibleDC(hdc_window)
        if not hdc_mem:
            raise OSError("CreateCompatibleDC failed")
        hbitmap = gdi32.CreateCompatibleBitmap(hdc_window, width, height)
        if not hbitmap:
            raise OSError("CreateCompatibleBitmap failed")
        old_bitmap = gdi32.SelectObject(hdc_mem, hbitmap)

        PW_RENDERFULLCONTENT = 0x00000002
        ok = user32.PrintWindow(hwnd, hdc_mem, PW_RENDERFULLCONTENT)
        if not ok:
            ok = user32.PrintWindow(hwnd, hdc_mem, 0)
        if not ok:
            raise OSError(f"PrintWindow failed for hwnd={hwnd}")

        bmi = _BITMAPINFO()
        bmi.bmiHeader.biSize        = ctypes.sizeof(_BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth       = width
        bmi.bmiHeader.biHeight      = -height   # negative = top-down DIB
        bmi.bmiHeader.biPlanes      = 1
        bmi.bmiHeader.biBitCount    = 32
        bmi.bmiHeader.biCompression = 0         # BI_RGB

        raw = (ctypes.c_ubyte * (width * height * 4))()
        DIB_RGB_COLORS = 0
        gdi32.GetDIBits(hdc_mem, hbitmap, 0, height, raw, ctypes.byref(bmi),
                        DIB_RGB_COLORS)

        arr = np.frombuffer(raw, dtype=np.uint8).reshape((height, width, 4))
        # BGRX → RGB, drop alpha
        arr = arr[:, :, [2, 1, 0]]
        return np.ascontiguousarray(arr), left, top
    finally:
        # Restore the DC's original bitmap before deleting ours — otherwise
        # the GDI bitmap we created stays selected into hdc_mem and GDI
        # refuses to delete it, leaking the handle.
        if hdc_mem and old_bitmap:
            gdi32.SelectObject(hdc_mem, old_bitmap)
        if hbitmap:
            gdi32.DeleteObject(hbitmap)
        if hdc_mem:
            gdi32.DeleteDC(hdc_mem)
        user32.ReleaseDC(hwnd, hdc_window)


# ── Cursor overlay ────────────────────────────────────────────────────────────

def draw_cursor_overlay(pil_img, screen_x, screen_y, capture_left, capture_top, scale):
    """Draw a red crosshair on pil_img at the given screen cursor position."""
    from PIL import ImageDraw
    ix = int((screen_x - capture_left) * scale)
    iy = int((screen_y - capture_top)  * scale)
    w, h = pil_img.width, pil_img.height
    if 0 <= ix < w and 0 <= iy < h:
        d = ImageDraw.Draw(pil_img)
        r = 10
        d.line([(max(0, ix - r), iy), (min(w - 1, ix + r), iy)], fill=(255, 0, 0), width=2)
        d.line([(ix, max(0, iy - r)), (ix, min(h - 1, iy + r))], fill=(255, 0, 0), width=2)
        d.ellipse([(ix - 3, iy - 3), (ix + 3, iy + 3)], outline=(255, 255, 0), width=1)
    return pil_img


# ── Background frame capture ──────────────────────────────────────────────────

# Name of the capture backend that won FrameBuffer's startup race. Set by
# whichever _loop_* method successfully starts. Surfaced via /ping so Claude
# and the user can tell whether they're on the fast DXGI path or the slow
# GDI fallback and suggest the fix if it matters.
_capture_backend = "unknown"

# Startup tips are ambient recommendations surfaced on /ping and in the CLI
# banner. They're deduplicated on the client by id. Flipped by server.main()
# based on --no-tips.
_tips_enabled = True


def _build_tips():
    """Return the current tip list based on runtime state. Empty if disabled."""
    if not _tips_enabled:
        return []
    tips = []
    # Chrome MCP is the most ergonomic transport for Claude's screenshot pipeline:
    # a single tool call per capture vs curl → file → read. We surface it on /ping
    # so the SKILL can hint the user to install the extension if they haven't.
    tips.append({
        "id":  "chrome_mcp",
        "msg": ("For the smoothest screenshot workflow, install Claude's Chrome "
                "extension. eyehands will then be viewable via Chrome MCP with one "
                "tool call per capture instead of curl -> save -> read."),
    })
    # Nudge users on the slow GDI path toward DXGI capture. bettercam gives
    # roughly 6x the throughput of mss on a typical desktop.
    if _capture_backend == "mss":
        tips.append({
            "id":  "fast_capture",
            "msg": ("You're on the GDI (mss) capture fallback. Install bettercam "
                    "for DXGI capture (~120fps vs ~20fps): pip install bettercam"),
        })
    return tips


class FrameBuffer:
    """Continuously captures the primary monitor into a rolling buffer."""

    def __init__(self, monitor_idx=1, max_w=1920, quality=70, fps=20):
        self.monitor_idx = monitor_idx
        self.max_w       = max_w
        self.quality     = quality
        self.fps         = fps
        self.interval    = 1.0 / fps
        self._lock       = threading.Lock()
        self._frame      = None   # latest JPEG bytes
        self._b64        = None   # latest base64 string
        self._arr        = None   # latest numpy RGB array (for re-encoding to non-JPEG formats)
        self._ts         = 0.0    # capture timestamp
        self._cx         = 0      # cursor x at capture time
        self._cy         = 0      # cursor y at capture time
        self._scale      = 1.0    # downscale factor applied
        self._mon        = {}     # monitor rect used
        self._img_w      = 0      # output image width  (after downscale)
        self._img_h      = 0      # output image height (after downscale)
        self._err_count  = 0      # consecutive capture errors
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()

    def _loop(self):
        """Try BetterCam first, then DXcam, then mss — fastest available wins."""
        try:
            import bettercam
            self._loop_bettercam(bettercam)
            return
        except Exception as exc:
            print(f"[FrameBuffer] BetterCam unavailable ({exc}), trying DXcam")
        try:
            import dxcam
            self._loop_dxcam(dxcam)
            return
        except Exception as exc:
            print(f"[FrameBuffer] DXcam unavailable ({exc}), falling back to mss")
        self._loop_mss()

    def _encode(self, arr):
        """Encode a numpy RGB uint8 array to JPEG bytes at the buffer quality.

        Delegates to the module-level _encode_rgb helper, which uses simplejpeg
        (libturbojpeg) when available and falls back to Pillow on import error.
        """
        data, _ = _encode_rgb(arr, fmt="jpeg", quality=self.quality)
        return data

    def _resize(self, arr):
        """Downscale numpy RGB array to self.max_w, returns (resized_arr, scale).

        Delegates to the module-level _resize_rgb_fast helper (cv2.INTER_AREA
        when available, Pillow LANCZOS otherwise) so FrameBuffer and the
        on-demand /screenshot path share the exact same resize quality.
        """
        return _resize_rgb_fast(arr, self.max_w)

    def _commit(self, arr, scale, mon, cx, cy):
        """Encode and store a frame. Called from each capture backend.

        The base64 string is NOT computed here — most frames never make it to
        /latest_b64, so eagerly base64-encoding them wastes CPU on every
        capture tick. latest_b64() lazily fills it on first access.
        """
        data = self._encode(arr)
        h, w = arr.shape[:2]
        with self._lock:
            self._frame     = data
            self._b64       = None  # lazy — see latest_b64()
            self._arr       = arr   # raw numpy kept for re-encoding at other formats
            self._ts        = time.monotonic()
            self._cx        = cx
            self._cy        = cy
            self._scale     = scale
            self._mon       = mon
            self._img_w     = w
            self._img_h     = h
            self._err_count = 0

    def _get_monitor_origin(self):
        """Return (left, top) of the capture monitor for coordinate mapping."""
        try:
            with mss.mss() as sct:
                mon = sct.monitors[self.monitor_idx]
                return mon["left"], mon["top"]
        except Exception:
            return 0, 0

    def _loop_bettercam(self, bettercam):
        """BetterCam: DXcam fork with high-resolution waitable timer scheduling
        (~120fps avg vs DXcam's ~39fps). Numpy RGB output, no PIL needed."""
        global _capture_backend
        camera = bettercam.create(output_idx=self.monitor_idx - 1, output_color="RGB")
        target = min(self.fps, 60)
        camera.start(target_fps=target, video_mode=True)
        mon_left, mon_top = self._get_monitor_origin()
        _capture_backend = "bettercam"
        print(f"[FrameBuffer] BetterCam started at {target}fps (monitor {self.monitor_idx})")
        try:
            while True:
                try:
                    frame = camera.get_latest_frame()
                    if frame is None:
                        time.sleep(0.001)
                        continue
                    cx, cy    = get_cursor_pos()
                    arr, scale = self._resize(frame)
                    h, w       = arr.shape[:2]
                    mon        = {"left": mon_left, "top": mon_top, "width": w, "height": h}
                    self._commit(arr, scale, mon, cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/bettercam] error ({self._err_count}): {exc}")
                time.sleep(self.interval)
        finally:
            camera.stop()
            del camera

    def _loop_dxcam(self, dxcam):
        """DXcam: DirectX Desktop Duplication API. Numpy RGB output, no PIL needed."""
        global _capture_backend
        camera = dxcam.create(output_idx=self.monitor_idx - 1, output_color="RGB")
        target = min(self.fps, 60)
        camera.start(target_fps=target, video_mode=True)
        mon_left, mon_top = self._get_monitor_origin()
        _capture_backend = "dxcam"
        print(f"[FrameBuffer] DXcam started at {target}fps (monitor {self.monitor_idx})")
        try:
            while True:
                try:
                    frame = camera.get_latest_frame()
                    if frame is None:
                        time.sleep(0.001)
                        continue
                    cx, cy    = get_cursor_pos()
                    arr, scale = self._resize(frame)
                    h, w       = arr.shape[:2]
                    mon        = {"left": mon_left, "top": mon_top, "width": w, "height": h}
                    self._commit(arr, scale, mon, cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/dxcam] error ({self._err_count}): {exc}")
                time.sleep(self.interval)
        finally:
            camera.stop()
            del camera

    def _loop_mss(self):
        """Fallback: GDI-based mss with persistent context. Compatible with all setups."""
        global _capture_backend
        import numpy as np
        _capture_backend = "mss"
        with mss.mss() as sct:
            while True:
                t0 = time.monotonic()
                try:
                    cx, cy = get_cursor_pos()
                    mon    = sct.monitors[self.monitor_idx]
                    img    = sct.grab(mon)
                    # Convert BGRA → RGB numpy array without PIL Image overhead
                    arr    = np.frombuffer(img.bgra, dtype=np.uint8)
                    arr    = arr.reshape((img.height, img.width, 4))[:, :, [2, 1, 0]]
                    arr, scale = self._resize(arr)
                    h, w   = arr.shape[:2]
                    self._commit(arr, scale, dict(mon), cx, cy)
                except Exception as exc:
                    with self._lock:
                        self._err_count += 1
                    print(f"[FrameBuffer/mss] error ({self._err_count}): {exc}")
                elapsed = time.monotonic() - t0
                time.sleep(max(0, self.interval - elapsed))

    def latest_b64(self):
        """Return the latest frame as a base64 string plus metadata.

        Computes base64 on first access and caches it under the lock, so
        repeated /latest_b64 calls against the same frame don't re-encode.
        """
        with self._lock:
            if self._b64 is None and self._frame is not None:
                self._b64 = base64.b64encode(self._frame).decode()
            return (self._b64, self._ts, self._cx, self._cy,
                    self._scale, dict(self._mon), self._img_w, self._img_h,
                    self._err_count)

    def latest_bytes(self):
        with self._lock:
            return self._frame, self._ts

    def latest_array(self):
        """Return the latest captured numpy RGB array plus metadata.

        The array reference is shared — callers must treat it as read-only.
        Used by /latest and /latest_b64 when the caller asks for a format
        other than cached JPEG (PNG, WebP, custom quality), to avoid paying
        the JPEG decode-and-re-encode roundtrip.
        """
        with self._lock:
            return (self._arr, self._ts, self._cx, self._cy,
                    self._scale, dict(self._mon), self._img_w, self._img_h,
                    self._err_count)

    def frame_hash(self):
        """Return a cheap identity hash of the current frame for change detection."""
        with self._lock:
            return self._ts  # timestamp changes every new frame
