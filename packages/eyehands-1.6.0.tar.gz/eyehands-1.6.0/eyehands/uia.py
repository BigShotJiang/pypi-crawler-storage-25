"""Windows UI Automation wrappers.

All `/ui/*` endpoints dispatch into this module. `uiautomation` is lazy-
loaded on first use so the package stays importable in environments without
the `ui` extra installed — the endpoint returns a clean ImportError payload
instead of crashing at startup.
"""

import threading

_uia_module = None
_uia_lock   = threading.Lock()


def _load_uia():
    global _uia_module
    if _uia_module is not None:
        return _uia_module
    with _uia_lock:
        if _uia_module is None:
            try:
                import uiautomation as uia
                _uia_module = uia
            except ImportError:
                raise ImportError("Run: pip install uiautomation")
    return _uia_module


def _rect_dict(rect):
    l, t, r, b = rect.left, rect.top, rect.right, rect.bottom
    return {"left": l, "top": t, "right": r, "bottom": b,
            "width": r - l, "height": b - t,
            "center_x": (l + r) // 2, "center_y": (t + b) // 2}


def _ctrl_dict(ctrl):
    try:
        rd = _rect_dict(ctrl.BoundingRectangle)
    except Exception:
        rd = {}
    try:
        value = ctrl.GetValuePattern().Value
    except Exception:
        value = None
    return {
        "name":          ctrl.Name,
        "type":          ctrl.ControlTypeName,
        "automation_id": ctrl.AutomationId,
        "center_x":      rd.get("center_x"),
        "center_y":      rd.get("center_y"),
        "rect":          rd,
        "value":         value,
    }


def ui_list_windows():
    uia = _load_uia()
    out = []
    for win in uia.GetRootControl().GetChildren():
        try:
            out.append({"title": win.Name, "type": win.ControlTypeName,
                        "rect": _rect_dict(win.BoundingRectangle)})
        except Exception:
            pass
    return out


def ui_element_at(x, y):
    uia = _load_uia()
    ctrl = uia.ControlFromPoint(x, y)
    return _ctrl_dict(ctrl) if ctrl else None


def ui_find(window_title=None, name=None, control_type=None, depth=6, max_results=20):
    uia = _load_uia()
    if window_title:
        root = uia.WindowControl(searchDepth=1, SubName=window_title)
        root = root if root.Exists(0) else uia.GetRootControl()
    else:
        root = uia.GetRootControl()
    results = []
    def search(ctrl, d):
        if d < 0 or len(results) >= max_results:
            return
        try:
            ok = True
            if name and name.lower() not in ctrl.Name.lower():
                ok = False
            if control_type and control_type.lower() not in ctrl.ControlTypeName.lower():
                ok = False
            if ok and (name or control_type):
                results.append(_ctrl_dict(ctrl))
        except Exception:
            pass
        try:
            for child in ctrl.GetChildren():
                search(child, d - 1)
        except Exception:
            pass
    search(root, depth)
    return results


def ui_tree(window_title=None, depth=3):
    uia = _load_uia()
    if window_title:
        root = uia.WindowControl(searchDepth=1, SubName=window_title)
        if not root.Exists(0):
            return {"error": f"Window '{window_title}' not found"}
    else:
        root = uia.GetRootControl()
    def build(ctrl, d):
        node = _ctrl_dict(ctrl)
        if d > 0:
            try:
                node["children"] = [build(c, d - 1) for c in ctrl.GetChildren()]
            except Exception:
                node["children"] = []
        return node
    return build(root, depth)
