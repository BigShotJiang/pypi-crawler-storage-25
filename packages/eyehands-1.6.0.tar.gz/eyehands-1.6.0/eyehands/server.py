"""
eyehands - Local HTTP server
Gives Claude eyes (screen capture) and hands (mouse + keyboard control)
via Windows SendInput. SendInput goes through the Raw Input pipeline that
pointer lock reads from.

Usage: `python -m eyehands`  (or `python server.py` from a repo checkout)
Then Claude sends: curl -X POST http://localhost:7331/move -d "{\"dx\":10,\"dy\":0}"
"""

# Hardcoded fallback version. The real value is read from package metadata
# below when the package is pip-installed. Keep these in sync with pyproject.toml
# for dev runs from a source checkout without `pip install -e .`.
__version__ = "1.6.0"

import argparse
import atexit
import base64
import ctypes
import hashlib
import json
import os
import secrets
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import mss

# Pull the installed version from package metadata when available so the
# single source of truth is pyproject.toml. The hardcoded value above is the
# fallback for source-checkout dev runs without `pip install -e .`.
try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("eyehands")
except Exception:
    pass


def _get_data_dir():
    """Return the directory for runtime data files (.license, .eyehands-token, etc.).

    For source checkouts (detected by pyproject.toml next to the package dir)
    we use the repo root, keeping existing dev workflows intact. For installed
    packages we use %APPDATA%/eyehands on Windows (or $HOME/eyehands elsewhere),
    which gives each user a stable per-install data location decoupled from
    the site-packages path.
    """
    module_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(module_dir)
    if os.path.exists(os.path.join(parent_dir, "pyproject.toml")):
        return parent_dir
    appdata = os.environ.get("APPDATA") or os.environ.get("HOME")
    if appdata:
        data_dir = os.path.join(appdata, "eyehands")
        try:
            os.makedirs(data_dir, exist_ok=True)
            return data_dir
        except Exception:
            pass
    return module_dir


_DATA_DIR = _get_data_dir()

# ── Auth token ────────────────────────────────────────────────────────────────
# A random bearer token is generated on first run and saved to .eyehands-token.
# All endpoints except /ping require Authorization: Bearer <token>.
# This prevents any rogue local process from controlling the desktop.

_TOKEN_FILE = os.path.join(_DATA_DIR, ".eyehands-token")

def _load_or_create_token():
    """Load existing token or generate a new one. Returns the token string."""
    if os.path.exists(_TOKEN_FILE):
        with open(_TOKEN_FILE) as f:
            token = f.read().strip()
            if token:
                return token
    token = secrets.token_urlsafe(32)
    with open(_TOKEN_FILE, "w") as f:
        f.write(token)
    return token

_auth_token = _load_or_create_token()

# Endpoints that skip auth (health check only)
_NO_AUTH_ENDPOINTS = {"/ping"}

# When True (--no-auth), all requests bypass the bearer-token check. Intentionally
# separate from the `_auth_token is None` fallback so the Host-header check can
# still run even when auth is disabled.
_AUTH_DISABLED = False

# When True, incoming requests must carry a loopback Host header. Disabled only
# when the server is explicitly bound to a non-loopback interface via --host.
_host_check_enabled = True

# Max accepted request body size (10 MiB). Keeps a rogue caller from OOM'ing
# the server with a huge JSON blob.
_MAX_BODY_BYTES = 10 * 1024 * 1024

# Caps on user-supplied step/depth values that feed into smooth_move or UIA
# tree traversal — prevents a single request from tying up the server indefinitely.
_MAX_SMOOTH_STEPS = 1000
_MAX_UI_DEPTH = 20


def _host_header_ok(host):
    """True if `host` names a loopback literal (with optional port).

    Module-level so tests can exercise the parsing without spinning up a
    Handler. Empty host is rejected so DNS-rebinding clients that send
    `Host:` can't bypass the check.
    """
    if not host:
        return False
    if host.startswith("["):
        end = host.find("]")
        if end == -1:
            return False
        host_only = host[: end + 1]
    elif host.count(":") == 1:
        host_only = host.rsplit(":", 1)[0]
    else:
        host_only = host
    return host_only in ("127.0.0.1", "localhost", "[::1]", "::1")


def _install_skill():
    """Copy the packaged SKILL.md to ~/.claude/skills/eyehands/SKILL.md.

    The packaged SKILL.md contains a {{TOKEN_FILE}} placeholder; we substitute
    it with the absolute path to this installation's token file (forward-slash
    form, so git-bash/MSYS curl calls work without escaping) so Claude's Bash
    tool reads the right file regardless of whether eyehands lives in a source
    checkout or %APPDATA%.

    Returns 0 on success, 1 on failure.
    """
    try:
        from importlib.resources import files as _res_files
    except Exception as e:
        print(f"[skill] importlib.resources unavailable: {e}")
        return 1

    try:
        packaged = _res_files("eyehands").joinpath("SKILL.md").read_text(encoding="utf-8")
    except Exception as e:
        print(f"[skill] packaged SKILL.md not found: {e}")
        print("[skill] is this a development checkout without 'pip install -e .'?")
        # Dev-checkout fallback: read SKILL.md from next to this file.
        fallback = os.path.join(os.path.dirname(os.path.abspath(__file__)), "SKILL.md")
        if not os.path.exists(fallback):
            return 1
        try:
            with open(fallback, encoding="utf-8") as f:
                packaged = f.read()
            print(f"[skill] using dev-checkout copy at {fallback}")
        except Exception as e2:
            print(f"[skill] failed to read dev copy: {e2}")
            return 1

    token_path = _TOKEN_FILE.replace("\\", "/")
    rendered = packaged.replace("{{TOKEN_FILE}}", token_path)

    home = os.environ.get("USERPROFILE") or os.environ.get("HOME")
    if not home:
        print("[skill] no USERPROFILE/HOME in environment — don't know where to install")
        return 1
    dest = os.path.join(home, ".claude", "skills", "eyehands", "SKILL.md")

    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        try:
            if os.path.exists(dest):
                with open(dest, encoding="utf-8") as f:
                    if f.read() == rendered:
                        print(f"[skill] already up to date: {dest}")
                        return 0
        except Exception:
            pass
        with open(dest, "w", encoding="utf-8") as f:
            f.write(rendered)
        print(f"[skill] installed: {dest}")
        print(f"[skill] token path: {token_path}")
        return 0
    except Exception as e:
        print(f"[skill] failed to write {dest}: {e}")
        return 1

# ── License validation ────────────────────────────────────────────────────────
# Pro features: /ui/*, /batch, /click_at, /click_and_wait, /type_and_enter,
#               /ui/click_element, /smooth_move, multi-monitor, FrameBuffer config
# Free: /move, /click, /double_click, /mousedown, /mouseup, /scroll, /key,
#       /type_text, /move_absolute, /screenshot*, /latest*, /ping, /cursor_pos,
#       /view, /find

_LICENSE_API   = "https://portal.fireal.dev/api/licenses"
_PRODUCT_CODE  = "eyehands"
_LICENSE_FILE  = os.path.join(_DATA_DIR, ".license")
_pro_active    = False

# ── Update check ──────────────────────────────────────────────────────────────
# On startup the server hits portal.fireal.dev to learn the latest published
# version. The result is cached in .update_check for 6 hours and surfaced on
# /ping and /latest_b64 so Claude can tell the user when an update exists.
# POST /update will pull the wheel from the portal and self-restart.

_UPDATE_CHECK_URL     = "https://portal.fireal.dev/api/updates/eyehands/check"
_UPDATE_CHECK_FILE    = os.path.join(_DATA_DIR, ".update_check")
_UPDATE_CHECK_TTL     = 6 * 3600  # 6 hours
_UPDATE_HELPER_FILE   = os.path.join(_DATA_DIR, ".update_helper.py")
_UPDATE_LOG_FILE      = os.path.join(_DATA_DIR, ".update_log.txt")
_update_available     = None  # dict {current, latest} or None

def _machine_id():
    """Stable machine fingerprint from hostname + OS install path."""
    raw = os.environ.get("COMPUTERNAME", "") + os.environ.get("SystemRoot", "")
    return hashlib.sha256(raw.encode()).hexdigest()[:32]

def _activate_license(key):
    """Activate a license key with the portal. Returns (success, message)."""
    import urllib.request
    device = _machine_id()
    import platform
    hostname = platform.node() or os.environ.get("COMPUTERNAME", "unknown")
    payload = json.dumps({"licenseKey": key, "deviceId": device, "deviceName": hostname}).encode()
    req = urllib.request.Request(
        f"{_LICENSE_API}/activate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        if data.get("success"):
            # Save activation locally
            with open(_LICENSE_FILE, "w") as f:
                json.dump({
                    "key": key,
                    "deviceId": device,
                    "activationToken": data.get("activationToken", ""),
                    "productCode": data.get("productCode", _PRODUCT_CODE),
                }, f)
            return True, "License activated"
        return False, data.get("message", "Activation failed")
    except Exception as exc:
        return False, str(exc)

def _validate_license():
    """Check saved license against the portal. Returns True if Pro is active."""
    if not os.path.exists(_LICENSE_FILE):
        return False
    try:
        with open(_LICENSE_FILE) as f:
            lic = json.load(f)
    except Exception:
        return False
    import urllib.request
    payload = json.dumps({
        "licenseKey": lic.get("key", ""),
        "deviceId": lic.get("deviceId", ""),
        "activationToken": lic.get("activationToken", ""),
    }).encode()
    req = urllib.request.Request(
        f"{_LICENSE_API}/validate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        return data.get("success", False)
    except Exception:
        # Offline grace: trust saved license if validation server is unreachable
        return True

def _check_pro():
    """Run license validation and set global _pro_active flag."""
    global _pro_active
    _pro_active = _validate_license()
    tier = "Pro" if _pro_active else "Free"
    print(f"[license] {tier} tier active")
    return _pro_active

def _load_update_cache():
    """Return cached update info if still fresh, else None.
    Invalidates the cache if the running version no longer matches the
    one captured at cache write time (e.g. just after a pip upgrade).
    """
    if not os.path.exists(_UPDATE_CHECK_FILE):
        return None
    try:
        with open(_UPDATE_CHECK_FILE) as f:
            data = json.load(f)
    except Exception:
        return None
    if time.time() - data.get("checked_at", 0) >= _UPDATE_CHECK_TTL:
        return None
    # Stale cache: written by an older running version. Invalidate so the
    # next call hits the portal and we don't keep showing "update available"
    # after the user has already upgraded.
    if data.get("current_version") != __version__:
        try:
            os.remove(_UPDATE_CHECK_FILE)
        except Exception:
            pass
        return None
    return data.get("result")

def _save_update_cache(result):
    """Persist the latest update check result with a timestamp + running version."""
    try:
        with open(_UPDATE_CHECK_FILE, "w") as f:
            json.dump({
                "checked_at": time.time(),
                "current_version": __version__,
                "result": result,
            }, f)
    except Exception:
        pass

def _version_tuple(v):
    """Parse 'X.Y.Z' → (X, Y, Z) for ordered comparison. Non-numeric parts
    compare as 0 so malformed strings sort as oldest."""
    if not v:
        return (0,)
    try:
        return tuple(int(p) for p in v.split("."))
    except (ValueError, AttributeError):
        return (0,)

def _check_for_updates():
    """Hit the portal /check endpoint and return update info dict (or None).
    5-second timeout — must not block startup if portal is slow/down.
    """
    cached = _load_update_cache()
    if cached is not None:
        return cached
    if not os.path.exists(_LICENSE_FILE):
        return None
    try:
        with open(_LICENSE_FILE) as f:
            lic = json.load(f)
    except Exception:
        return None
    payload = json.dumps({
        "licenseKey": lic.get("key", ""),
        "deviceId": lic.get("deviceId", ""),
        "activationToken": lic.get("activationToken", ""),
        "currentVersion": __version__,
    }).encode()
    import urllib.request
    req = urllib.request.Request(
        _UPDATE_CHECK_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
    except Exception:
        return None
    latest = data.get("latestVersion")
    # Only report "update available" when the portal's latest is strictly
    # newer than the running version. Proper tuple compare (not ==) so a
    # stale portal cache reporting an older version doesn't spuriously
    # trigger the update banner right after a release.
    if not latest or _version_tuple(latest) <= _version_tuple(__version__):
        result = None
    else:
        result = {
            "current": __version__,
            "latest": latest,
        }
    _save_update_cache(result)
    return result

# ── Free-tier telemetry (added in 1.6.0) ──────────────────────────────────────
# Licensed installs are counted via the /check call above. Free-tier installs
# never hit /check (it returns early without a license file), so the portal
# has no way to count them. This second heartbeat phones home anonymously
# with a random install token — the token is never stored on the server in
# plaintext, only SHA-256(token). Used solely for knowing how many people
# actually run the tool, feeding directly into /api/admin/eyehands/stats.
#
# Opt-out: --no-telemetry flag on the CLI, or presence of .no-telemetry in
# _DATA_DIR. Both are checked before ever generating an install token.
#
# Deliberately independent from _check_for_updates so:
#   - the same 6h cache prevents double-pings
#   - but a free user on .no-telemetry still gets update checks if they ever
#     activate a license later (the two paths are unrelated after the flag)

_FREE_PING_URL    = "https://portal.fireal.dev/api/updates/eyehands/ping"
_INSTALL_TOKEN_FILE  = os.path.join(_DATA_DIR, ".install_token")
_NO_TELEMETRY_FILE   = os.path.join(_DATA_DIR, ".no-telemetry")
_telemetry_disabled_cli = False  # set by main() if --no-telemetry given

def _telemetry_disabled():
    """Return True if telemetry should be skipped entirely."""
    if _telemetry_disabled_cli:
        return True
    return os.path.exists(_NO_TELEMETRY_FILE)

def _get_install_token():
    """Load the 32-byte install token, generating it on first run.

    Stored as raw binary in .install_token inside _DATA_DIR. Returns the
    raw bytes. Never log, never include in URLs — the portal uses its
    SHA-256 as the stable install identifier.
    """
    if os.path.exists(_INSTALL_TOKEN_FILE):
        try:
            with open(_INSTALL_TOKEN_FILE, "rb") as f:
                data = f.read()
            if len(data) == 32:
                return data
        except Exception:
            pass  # fall through and regenerate
    token = secrets.token_bytes(32)
    try:
        with open(_INSTALL_TOKEN_FILE, "wb") as f:
            f.write(token)
        # Best-effort restrict to owner on POSIX; on Windows the default
        # ACL is already user-scoped.
        try:
            os.chmod(_INSTALL_TOKEN_FILE, 0o600)
        except Exception:
            pass
    except Exception:
        pass
    return token

def _free_checkin():
    """Send an anonymous heartbeat to the portal. Silent on all failures.

    Reuses the existing _load_update_cache() TTL via a tag so this doesn't
    spam the portal on every server start — the licensed /check cache and
    this cache are stored under different keys (licensed = update_available
    dict, free-tier = separate file below) so one can expire without the
    other.
    """
    if _telemetry_disabled():
        return
    # Cached "we already pinged in the last 6h"?
    cache_path = os.path.join(_DATA_DIR, ".free_ping_cache")
    try:
        if os.path.exists(cache_path):
            with open(cache_path) as f:
                cached = json.load(f)
            if time.time() - cached.get("checked_at", 0) < _UPDATE_CHECK_TTL:
                return
    except Exception:
        pass  # corrupt cache file → re-ping, no harm

    token = _get_install_token()
    install_id = hashlib.sha256(token).hexdigest()[:32]
    payload = json.dumps({
        "installId":    install_id,
        "installToken": token.hex(),
        "deviceId":     _machine_id(),
        "version":      __version__,
    }).encode()
    import urllib.request
    req = urllib.request.Request(
        _FREE_PING_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            resp.read()  # drain; we don't consume the latestVersion response
    except Exception:
        return  # silent — telemetry must never break startup

    try:
        with open(cache_path, "w") as f:
            json.dump({"checked_at": time.time()}, f)
    except Exception:
        pass

def _write_update_helper():
    """Write the embedded restart helper script to disk. Returns its path."""
    with open(_UPDATE_HELPER_FILE, "w") as f:
        f.write(_UPDATE_HELPER_PY)
    return _UPDATE_HELPER_FILE

# Helper script that the /update endpoint spawns as a detached process. It
# waits for the parent server to exit, runs `pip install --upgrade eyehands`
# (pulling from PyPI), and relaunches the server via `python -m eyehands`.
# All output goes to .update_log.txt for debugging. `--upgrade` (not
# `--force-reinstall`) is deliberate: a failed install leaves the previous
# version intact so the user can manually relaunch.
_UPDATE_HELPER_PY = '''
import sys, os, time, subprocess

PARENT_PID = int(sys.argv[1])
LOG = sys.argv[2]

def log(msg):
    with open(LOG, "a") as f:
        f.write(f"[helper] {msg}\\n")

# Wait up to 10s for parent to exit on its own
for _ in range(20):
    try:
        os.kill(PARENT_PID, 0)
        time.sleep(0.5)
    except OSError:
        break
else:
    log("parent still alive after 10s, force-killing")
    subprocess.run(["taskkill", "/F", "/PID", str(PARENT_PID)], capture_output=True)
    time.sleep(0.5)

log("running: pip install --upgrade eyehands")
result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "--upgrade", "eyehands"],
    capture_output=True, text=True,
)
log(f"pip return code: {result.returncode}")
if result.stdout: log(f"stdout: {result.stdout}")
if result.stderr: log(f"stderr: {result.stderr}")

if result.returncode != 0:
    log("install failed; not restarting server")
    sys.exit(1)

log("starting new server via python -m eyehands")
subprocess.Popen(
    [sys.executable, "-m", "eyehands"],
    close_fds=True,
    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
)
log("done")
'''.lstrip()

_PRO_ENDPOINTS = {
    "/ui/windows", "/ui/find", "/ui/at", "/ui/tree",
    "/ui/click_element",
    "/batch", "/click_at", "/click_and_wait", "/type_and_enter",
    "/smooth_move",
}

def _is_pro_endpoint(path):
    return path.split("?")[0] in _PRO_ENDPOINTS

# ── Single-instance enforcement ────────────────────────────────────────────────
_PID_FILE = os.path.join(_DATA_DIR, "server.pid")

def _kill_existing_instance():
    """Kill any previously running server instance recorded in the PID file.

    Safety: before taskkill we verify the PID still belongs to a python /
    eyehands process. The OS reuses PIDs, so an old/stale PID file could name
    a process we have no business killing (e.g. a browser or IDE that
    happened to grab the slot). If tasklist doesn't recognize the pid or the
    name doesn't match, the PID file is simply removed.
    """
    if not os.path.exists(_PID_FILE):
        return
    try:
        with open(_PID_FILE) as f:
            old_pid = int(f.read().strip())
        if old_pid == os.getpid():
            return
        try:
            out = subprocess.run(
                ["tasklist", "/FI", f"PID eq {old_pid}", "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=3,
            ).stdout.lower()
        except Exception:
            out = ""
        if "python" in out or "eyehands" in out:
            print(f"[startup] Killing existing instance (PID {old_pid})...")
            subprocess.run(["taskkill", "/F", "/PID", str(old_pid)],
                           capture_output=True)
            time.sleep(0.5)
        else:
            print(f"[startup] Stale PID file (PID {old_pid} is not a python/eyehands process)")
    except Exception:
        pass
    try:
        os.remove(_PID_FILE)
    except Exception:
        pass

def _write_pid():
    with open(_PID_FILE, "w") as f:
        f.write(str(os.getpid()))

def _remove_pid():
    try:
        os.remove(_PID_FILE)
    except Exception:
        pass

atexit.register(_remove_pid)

# ── Threaded HTTP server ───────────────────────────────────────────────────────

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle each request in its own thread so slow ops don't block others."""
    daemon_threads = True
    # Disable address reuse — on Windows, allow_reuse_address lets multiple
    # processes bind to the same port simultaneously, causing instance pile-up.
    allow_reuse_address = False

# ── Sibling modules (input, capture, uia) ─────────────────────────────────────
# DPI awareness and the mss CAPTUREBLT patch run in eyehands/__init__.py so
# they are both in effect before these modules import — input.py reads
# virtual-desktop metrics at module load and needs physical pixels.
from . import capture as _capture  # noqa: E402
from . import input as _input  # noqa: E402
from .capture import (  # noqa: E402
    FrameBuffer,
    _normalize_format,
    _resize_rgb_fast,
    _encode_rgb,
    _format_extension,
    _grab_hwnd,
    draw_cursor_overlay,
)
from .input import (  # noqa: E402
    move,
    click,
    double_click,
    mousedown,
    mouseup,
    scroll,
    move_absolute,
    keypress,
    type_text,
    _smooth_move,
    get_cursor_pos,
    primary_monitor_idx,
)
from .uia import (  # noqa: E402
    ui_list_windows,
    ui_element_at,
    ui_find,
    ui_tree,
)

# ── Runtime globals (FrameBuffer lives in eyehands.capture) ──────────────────

# Global buffer — started in main(); lives here because Handler references
# it as a module-level name and main() assigns to it.
_frame_buf: "FrameBuffer | None" = None

# Lazy-loaded EasyOCR reader — initialized on first /find request
_ocr_reader = None
# Cached OCR results keyed by frame timestamp
_ocr_cache_ts = 0.0
_ocr_cache_results = []
_ocr_lock = threading.Lock()

# ── HTTP server ────────────────────────────────────────────────────────────────

_VIEW_HTML = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eyehands</title>
<style>
*{margin:0;padding:0}
html,body{width:100%;height:100%;background:#000;overflow:hidden;cursor:crosshair}
img{display:block;width:100vw;height:100vh;object-fit:contain;image-rendering:pixelated}
</style></head><body>
<img id="s" src="/latest?t=0" draggable="false">
<script>
// Auth rides on the eyehands_session cookie (planted by /view after the
// initial ?token= auth). All fetches below are same-origin so the cookie
// flows automatically — no need to embed the token in URLs.
const img=document.getElementById('s');
function refresh(){img.src='/latest?t='+Date.now()}
setInterval(refresh,%%INTERVAL%%);
// Click math accounts for object-fit:contain letterboxing: the displayed
// image may be smaller than the img element box, centered with black bars.
img.addEventListener('click',async e=>{
  const r=img.getBoundingClientRect();
  const nW=img.naturalWidth, nH=img.naturalHeight;
  if(!nW||!nH) return;
  const bR=r.width/r.height, iR=nW/nH;
  let dW,dH,dL,dT;
  if(iR>bR){dW=r.width; dH=r.width/iR; dL=0;           dT=(r.height-dH)/2;}
  else     {dH=r.height;dW=r.height*iR;dL=(r.width-dW)/2; dT=0;}
  const rX=(e.clientX-r.left-dL)/dW;
  const rY=(e.clientY-r.top-dT)/dH;
  if(rX<0||rX>1||rY<0||rY>1) return;  // click in letterbox → ignore
  const x=Math.round(rX*nW);
  const y=Math.round(rY*nH);
  const meta=await(await fetch('/latest_b64')).json();
  const sx=Math.round(meta.cap_left+x/meta.scale);
  const sy=Math.round(meta.cap_top+y/meta.scale);
  await fetch('/click_at',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({x:sx,y:sy,button:e.button===2?'right':'left'})});
  setTimeout(refresh,150);
});
img.addEventListener('contextmenu',e=>e.preventDefault());
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        # Each request thread needs its own COM apartment for uiautomation.
        # Track success so finish() only calls CoUninitialize when the init
        # actually happened — an unbalanced Uninitialize leaks apartment refs.
        try:
            ctypes.windll.ole32.CoInitialize(None)
            self._com_initialized = True
        except Exception:
            self._com_initialized = False

    def finish(self):
        try:
            if getattr(self, "_com_initialized", False):
                ctypes.windll.ole32.CoUninitialize()
        finally:
            super().finish()

    def log_message(self, fmt, *args):
        msg = fmt % args
        # Scrub any ?token=<value> or &token=<value> so the bearer token
        # doesn't end up in stdout logs when browser access is used.
        if "token=" in msg:
            import re
            msg = re.sub(r'([?&]token=)[^ &"\'\s]+', r'\1<scrubbed>', msg)
        print(f"[{self.address_string()}] {msg}")

    def _check_auth(self):
        """Validate Host header and bearer token. Returns True if request is allowed.

        Order of checks (the Host header check runs first, unconditionally, so
        --no-auth does not also silently disable DNS-rebinding protection):
          1. Host header — must be a loopback literal when _host_check_enabled.
          2. Path in _NO_AUTH_ENDPOINTS, or _AUTH_DISABLED — short-circuit to OK.
          3. Bearer token (constant-time comparison).
          4. ?token=<token> query parameter fallback for browser address-bar access.
          5. eyehands_session cookie fallback (set by /view after initial auth).
        """
        if _host_check_enabled and not self._host_header_ok():
            self._reject(403, "invalid host header")
            return False
        path = self.path.split("?")[0]
        if _AUTH_DISABLED or path in _NO_AUTH_ENDPOINTS:
            return True
        if _auth_token is None:
            return True
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer ") and secrets.compare_digest(auth[7:], _auth_token):
            return True
        # Browser address-bar fallback — Chrome can't inject custom headers
        # when you type a URL into the bar, so /view and /screenshot accept
        # ?token=<token> instead.
        try:
            query = urllib.parse.urlparse(self.path).query
            qt = urllib.parse.parse_qs(query).get("token", [""])[0]
        except Exception:
            qt = ""
        if qt and secrets.compare_digest(qt, _auth_token):
            return True
        # Cookie fallback — /view plants `eyehands_session=<token>` as HttpOnly
        # after initial bearer auth so subsequent same-origin fetches (img src,
        # /latest_b64, /click_at) don't need to embed the token in the URL.
        if self._session_cookie_ok():
            return True
        self._reject(401,
            "unauthorized — include 'Authorization: Bearer <token>' header or ?token=<token> query param")
        return False

    def _host_header_ok(self):
        """True if the Host header names a loopback literal. Rejects empty Host."""
        return _host_header_ok(self.headers.get("Host", ""))

    def _session_cookie_ok(self):
        """True if an eyehands_session cookie carries the current auth token."""
        if _auth_token is None:
            return False
        for part in self.headers.get("Cookie", "").split(";"):
            part = part.strip()
            if part.startswith("eyehands_session="):
                v = part[len("eyehands_session="):]
                if v and secrets.compare_digest(v, _auth_token):
                    return True
        return False

    def _reject(self, code, error):
        """Send a small JSON error response."""
        data = json.dumps({"ok": False, "error": error}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def read_body(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            raise ValueError("invalid Content-Length")
        if length < 0 or length > _MAX_BODY_BYTES:
            raise ValueError(f"body too large: {length}")
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON body: {exc}") from exc

    def _exec_action(self, action):
        """Execute a single action dict. Returns a result dict."""
        t = action.get("action") or action.get("type")
        if t == "move":
            move(action.get("dx", 0), action.get("dy", 0))
        elif t == "move_absolute":
            move_absolute(action.get("x", 0), action.get("y", 0))
        elif t == "click":
            click(action.get("button", "left"))
        elif t == "double_click":
            double_click(action.get("button", "left"))
        elif t == "mousedown":
            mousedown(action.get("button", "left"))
        elif t == "mouseup":
            mouseup(action.get("button", "left"))
        elif t == "scroll":
            scroll(action.get("dy", 0))
        elif t == "key":
            keypress(action.get("vk", 0), action.get("modifiers"))
        elif t == "type_text":
            type_text(action.get("text", ""))
        elif t == "sleep":
            time.sleep(action.get("ms", 0) / 1000.0)
        elif t == "ui_click":
            try:
                results = ui_find(
                    window_title=action.get("window"),
                    name=action.get("name"),
                    control_type=action.get("type"),
                    depth=min(_MAX_UI_DEPTH, int(action.get("depth", 6))),
                    max_results=1,
                )
            except ImportError as exc:
                return {"ok": False, "error": str(exc)}
            if results:
                el = results[0]
                cx, cy = el.get("center_x"), el.get("center_y")
                if cx is not None and cy is not None:
                    move_absolute(cx, cy)
                    time.sleep(0.05)
                    click(action.get("button", "left"))
                    return {"ok": True, "clicked": el}
            return {"ok": False, "error": "element not found"}
        elif t == "smooth_move":
            _smooth_move(
                action.get("dx", 0),
                action.get("dy", 0),
                max(1, min(_MAX_SMOOTH_STEPS, int(action.get("steps", 10)))),
                action.get("delay_ms", 4) / 1000.0,
            )
        else:
            return {"ok": False, "error": f"unknown action: {t}"}
        return {"ok": True}

    def _require_pro(self, path):
        """Return True (and send 402) if path needs Pro and user doesn't have it."""
        if _is_pro_endpoint(path) and not _pro_active:
            self.send_json(402, {
                "ok": False,
                "error": "Pro license required",
                "endpoint": path,
                "upgrade": "https://portal.fireal.dev",
                "activate": "POST /activate {\"key\": \"YOUR-LICENSE-KEY\"}",
            })
            return True
        return False

    def do_POST(self):
        if not self._check_auth():
            return
        try:
            body = self.read_body()
            path = self.path.split("?")[0]

            if path == "/activate":
                key = body.get("key", "").strip()
                if not key:
                    self.send_json(400, {"ok": False, "error": "key is required"})
                else:
                    ok, msg = _activate_license(key)
                    if ok:
                        _check_pro()
                    self.send_json(200 if ok else 400, {"ok": ok, "message": msg,
                                                         "tier": "Pro" if _pro_active else "Free"})
                return

            if path == "/update":
                # Self-update: spawn a detached helper that waits for us to
                # exit, runs `pip install --upgrade eyehands` (pulling from
                # PyPI), and relaunches via `python -m eyehands`.
                # Refuse if we're running from a git checkout — pip install
                # would install eyehands globally as a side effect but the
                # helper would relaunch via `python -m eyehands` which, from a
                # checkout cwd, picks up the in-tree copy that pip never touches,
                # so the "update" is silently a no-op. Detect checkouts by the
                # presence of pyproject.toml in _DATA_DIR (set by _get_data_dir).
                if os.path.exists(os.path.join(_DATA_DIR, "pyproject.toml")):
                    self.send_json(409, {
                        "ok": False,
                        "error": "running from source checkout — use 'git pull && python -m eyehands' to upgrade",
                    })
                    return
                if not _update_available:
                    self.send_json(409, {"ok": False, "error": "no update available"})
                    return

                helper_path = _write_update_helper()
                target_version = _update_available["latest"]

                subprocess.Popen(
                    [sys.executable, helper_path, str(os.getpid()), _UPDATE_LOG_FILE],
                    close_fds=True,
                    creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                )

                self.send_json(200, {
                    "ok": True,
                    "message": f"Installing eyehands {target_version}. Server will restart in a few seconds.",
                    "log_file": ".update_log.txt",
                })
                try:
                    self.wfile.flush()
                except Exception:
                    pass

                # Hard-exit on a delay so the response makes it onto the wire.
                # os._exit skips finally/atexit, which is what we want — the
                # new server's _kill_existing_instance will overwrite the PID
                # file. The helper waits for us to exit before pip install.
                def _exit_soon():
                    time.sleep(1)
                    os._exit(0)
                threading.Thread(target=_exit_soon, daemon=True).start()
                return

            if self._require_pro(path):
                return

            if path == "/move":
                move(body.get("dx", 0), body.get("dy", 0))
                self.send_json(200, {"ok": True})

            elif path == "/click":
                click(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/double_click":
                double_click(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/mousedown":
                mousedown(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/mouseup":
                mouseup(body.get("button", "left"))
                self.send_json(200, {"ok": True})

            elif path == "/scroll":
                scroll(body.get("dy", 0))
                self.send_json(200, {"ok": True})

            elif path == "/key":
                keypress(body.get("vk", 0), body.get("modifiers"))
                self.send_json(200, {"ok": True})

            elif path == "/type_text":
                type_text(body.get("text", ""))
                self.send_json(200, {"ok": True})

            elif path == "/move_absolute":
                move_absolute(body.get("x", 0), body.get("y", 0))
                self.send_json(200, {"ok": True})

            elif path == "/smooth_move":
                _smooth_move(
                    body.get("dx", 0),
                    body.get("dy", 0),
                    max(1, min(_MAX_SMOOTH_STEPS, int(body.get("steps", 10)))),
                    body.get("delay_ms", 4) / 1000.0,
                )
                self.send_json(200, {"ok": True})

            elif path == "/ui/click_element":
                results = ui_find(
                    window_title=body.get("window"),
                    name=body.get("name"),
                    control_type=body.get("type"),
                    depth=min(_MAX_UI_DEPTH, int(body.get("depth", 6))),
                    max_results=1,
                )
                if not results:
                    self.send_json(404, {"ok": False, "error": "element not found"})
                else:
                    el = results[0]
                    cx, cy = el.get("center_x"), el.get("center_y")
                    if cx is None or cy is None:
                        self.send_json(400, {"ok": False, "error": "element has no bounding rect"})
                    else:
                        move_absolute(cx, cy)
                        time.sleep(0.05)
                        click(body.get("button", "left"))
                        self.send_json(200, {"ok": True, "clicked": el})

            elif path == "/click_at":
                x, y = body.get("x", 0), body.get("y", 0)
                move_absolute(x, y)
                time.sleep(0.05)
                click(body.get("button", "left"))
                self.send_json(200, {"ok": True, "x": x, "y": y})

            elif path == "/click_and_wait":
                x, y = body.get("x", 0), body.get("y", 0)
                timeout_ms = body.get("timeout_ms", 2000)
                move_absolute(x, y)
                time.sleep(0.05)
                click(body.get("button", "left"))
                # Wait until the frame changes or timeout
                ts_before = _frame_buf.frame_hash()
                deadline = time.monotonic() + timeout_ms / 1000.0
                changed = False
                while time.monotonic() < deadline:
                    time.sleep(0.05)
                    if _frame_buf.frame_hash() != ts_before:
                        # Frame changed — wait a bit more for UI to settle
                        time.sleep(0.15)
                        changed = True
                        break
                self.send_json(200, {"ok": True, "x": x, "y": y, "changed": changed})

            elif path == "/type_and_enter":
                txt = body.get("text", "")
                type_text(txt)
                time.sleep(0.03)
                keypress(0x0D)  # VK_RETURN
                self.send_json(200, {"ok": True, "text": txt})

            elif path == "/batch":
                actions    = body.get("actions", [])
                if len(actions) > 100:
                    self.send_json(400, {"ok": False, "error": f"batch limited to 100 actions, got {len(actions)}"})
                    return
                between_ms = body.get("delay_ms", 0) / 1000.0
                results = []
                for act in actions:
                    res = self._exec_action(act)
                    results.append(res)
                    if between_ms > 0:
                        time.sleep(between_ms)
                self.send_json(200, {"ok": True, "results": results})

            else:
                self.send_json(404, {"ok": False, "error": "unknown endpoint"})

        except Exception as e:
            self.send_json(500, {"ok": False, "error": str(e)})

    def _parse_qs(self, path):
        qs = {}
        if "?" in path:
            for part in path.split("?", 1)[1].split("&"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    qs[urllib.parse.unquote(k)] = urllib.parse.unquote(v)
        return qs

    def _grab(self, qs, want_array=False):
        """Capture a screen region (or window) and encode it in the requested format.

        Returns (image_bytes, metadata_dict), or (numpy_rgb_array, metadata_dict)
        when want_array=True — in that case encoding is skipped entirely and
        the meta has no `format`/`content_type`. Used by /find to avoid the
        JPEG decode-and-re-encode roundtrip that OCR doesn't need.

        Metadata always contains cursor_x/y, scale, cap_left/top, img_w/h.

        Query params:
          monitor=N      (1-based, default = primary monitor)
          hwnd=HANDLE    (window handle; takes precedence over monitor/region,
                          captures the window via PrintWindow regardless of z-order)
          x, y, w, h    (region in physical screen pixels; optional, default = full monitor)
          raw=1          (bypass max_w downscale and return physical pixels)
          max_w          (max output width in pixels, default 1920; ignored if raw=1)
          quality        (JPEG/WebP quality 1-95, default 70; ignored for PNG)
          format         (jpeg|png|webp; default jpeg)
          cursor=1       (overlay a red crosshair at the current cursor position)
        """
        import numpy as np
        monitor_idx = int(qs.get("monitor", primary_monitor_idx()))
        max_w       = int(qs.get("max_w", 1920))
        quality     = int(qs.get("quality", 70))
        show_cursor = qs.get("cursor", "0") == "1"
        raw_mode    = qs.get("raw", "0") == "1"
        fmt         = _normalize_format(qs.get("format", "jpeg"))

        cx, cy = get_cursor_pos()

        hwnd_str = qs.get("hwnd")
        if hwnd_str:
            arr, cap_left, cap_top = _grab_hwnd(int(hwnd_str))
        else:
            with mss.mss() as sct:
                monitors = sct.monitors
                mon = monitors[monitor_idx] if monitor_idx < len(monitors) else monitors[1]
                if "x" in qs and "y" in qs and "w" in qs and "h" in qs:
                    region = {
                        "left":   mon["left"] + int(qs["x"]),
                        "top":    mon["top"]  + int(qs["y"]),
                        "width":  int(qs["w"]),
                        "height": int(qs["h"]),
                    }
                else:
                    region = mon
                img = sct.grab(region)
                # BGRA → RGB via numpy, no PIL Image roundtrip.
                buf = np.frombuffer(img.bgra, dtype=np.uint8)
                arr = buf.reshape((img.height, img.width, 4))[:, :, [2, 1, 0]]
                arr = np.ascontiguousarray(arr)
                cap_left = region["left"]
                cap_top  = region["top"]

        scale = 1.0
        if not raw_mode:
            arr, scale = _resize_rgb_fast(arr, max_w)

        if show_cursor:
            # Cursor overlay goes through PIL because ImageDraw is easier than
            # hand-rolled numpy slicing. Only paid when explicitly requested.
            from PIL import Image
            pil_img = draw_cursor_overlay(
                Image.fromarray(arr), cx, cy, cap_left, cap_top, scale
            )
            arr = np.asarray(pil_img)

        h, w = arr.shape[:2]
        meta = {
            "cursor_x":     cx,
            "cursor_y":     cy,
            "scale":        scale,
            "cap_left":     cap_left,
            "cap_top":      cap_top,
            "img_w":        w,
            "img_h":        h,
        }

        if want_array:
            return arr, meta

        data, content_type = _encode_rgb(arr, fmt=fmt, quality=quality)
        meta["format"]       = fmt
        meta["content_type"] = content_type
        return data, meta

    def do_GET(self):
        if not self._check_auth():
            return
        base = self.path.split("?")[0]

        if base == "/license":
            self.send_json(200, {
                "ok": True,
                "tier": "Pro" if _pro_active else "Free",
                "version": __version__,
                "pro_endpoints": sorted(_PRO_ENDPOINTS),
                "upgrade": "https://portal.fireal.dev",
            })
            return

        if self._require_pro(base):
            return

        if base == "/ping":
            self.send_json(200, {
                "ok": True,
                "status": "running",
                "version": __version__,
                "tier": "Pro" if _pro_active else "Free",
                "update_available": _update_available,
                "capture_backend": _capture._capture_backend,
                "tips": _capture._build_tips(),
            })

        elif base == "/cursor_pos":
            x, y = get_cursor_pos()
            self.send_json(200, {"ok": True, "x": x, "y": y})

        elif base == "/screenshot":
            qs = self._parse_qs(self.path)
            try:
                data, meta = self._grab(qs)
                self.send_response(200)
                self.send_header("Content-Type", meta.get("content_type", "image/jpeg"))
                self.send_header("Content-Length", len(data))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/screenshot_b64":
            qs = self._parse_qs(self.path)
            try:
                data, meta = self._grab(qs)
                self.send_json(200, {"ok": True, "image": base64.b64encode(data).decode(), **meta})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/latest":
            qs = self._parse_qs(self.path)
            fmt = _normalize_format(qs.get("format", "jpeg"))
            cur_ts = _frame_buf.frame_hash() if _frame_buf else 0.0
            etag = f'"{cur_ts}"'

            # Client-side caching: 304 Not Modified when the caller already has
            # the current frame. Accept either HTTP ETag (If-None-Match) or a
            # ?since=<float> query param so browser-style address-bar polling
            # can participate too.
            since_param = qs.get("since")
            try:
                since_f = float(since_param) if since_param is not None else None
            except ValueError:
                since_f = None
            if_none_match = self.headers.get("If-None-Match", "")
            already_has = (
                (if_none_match and if_none_match == etag) or
                (since_f is not None and cur_ts <= since_f)
            )
            if already_has and cur_ts > 0:
                self.send_response(304)
                self.send_header("ETag", etag)
                self.send_header("X-Frame-Hash", str(cur_ts))
                self.end_headers()
                return

            # Fast path: default JPEG with buffer-native quality → ship cached bytes.
            quality_override = qs.get("quality")
            if fmt == "jpeg" and quality_override is None:
                data, ts = _frame_buf.latest_bytes()
                if data is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                content_type = "image/jpeg"
            else:
                arr, ts, _cx, _cy, _sc, _mon, _iw, _ih, _err = _frame_buf.latest_array()
                if arr is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                q = int(quality_override) if quality_override is not None else _frame_buf.quality
                data, content_type = _encode_rgb(arr, fmt=fmt, quality=q)

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", len(data))
            self.send_header("X-Timestamp", str(ts))
            self.send_header("X-Frame-Hash", str(ts))
            self.send_header("ETag", f'"{ts}"')
            self.end_headers()
            self.wfile.write(data)

        elif base == "/latest_b64":
            qs = self._parse_qs(self.path)
            fmt = _normalize_format(qs.get("format", "jpeg"))
            quality_override = qs.get("quality")

            if fmt == "jpeg" and quality_override is None:
                b64, ts, cx, cy, scale, mon, img_w, img_h, err = _frame_buf.latest_b64()
                content_type = "image/jpeg"
            else:
                arr, ts, cx, cy, scale, mon, img_w, img_h, err = _frame_buf.latest_array()
                if arr is None:
                    self.send_json(503, {"ok": False, "error": "no frame yet"})
                    return
                q = int(quality_override) if quality_override is not None else _frame_buf.quality
                data, content_type = _encode_rgb(arr, fmt=fmt, quality=q)
                b64 = base64.b64encode(data).decode()

            if b64 is None:
                self.send_json(503, {"ok": False, "error": "no frame yet"})
                return

            resp = {
                "ok":           True,
                "image":        b64,
                "ts":           ts,
                "age_ms":       round((time.monotonic() - ts) * 1000, 1),
                "cursor_x":     cx,
                "cursor_y":     cy,
                "scale":        scale,
                "cap_left":     mon.get("left", 0),
                "cap_top":      mon.get("top", 0),
                "img_w":        img_w,
                "img_h":        img_h,
                "format":       fmt,
                "content_type": content_type,
                "frame_hash":   ts,
            }
            if err:
                resp["capture_errors"] = err
            resp["update_available"] = _update_available
            self.send_json(200, resp)

        elif base == "/ui/windows":
            try:
                self.send_json(200, {"ok": True, "windows": ui_list_windows()})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/at":
            qs = self._parse_qs(self.path)
            try:
                x = int(qs.get("x", 0))
                y = int(qs.get("y", 0))
                el = ui_element_at(x, y)
                self.send_json(200, {"ok": True, "element": el})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/find":
            qs = self._parse_qs(self.path)
            try:
                results = ui_find(
                    window_title=qs.get("window"),
                    name=qs.get("name"),
                    control_type=qs.get("type"),
                    depth=min(_MAX_UI_DEPTH, int(qs.get("depth", 6))),
                    max_results=int(qs.get("max", 20)),
                )
                self.send_json(200, {"ok": True, "elements": results, "count": len(results)})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/ui/tree":
            qs = self._parse_qs(self.path)
            try:
                tree = ui_tree(
                    window_title=qs.get("window"),
                    depth=min(_MAX_UI_DEPTH, int(qs.get("depth", 3))),
                )
                self.send_json(200, {"ok": True, "tree": tree})
            except Exception as e:
                self.send_json(500, {"ok": False, "error": str(e)})

        elif base == "/view":
            qs = self._parse_qs(self.path)
            # If the request came in with ?token=<token>, _check_auth already
            # validated it. Redirect to a clean URL (no token in browser
            # history) and plant the session cookie so subsequent same-origin
            # fetches from the page authenticate without the token in the URL.
            if "token" in qs:
                location = "/view"
                if "fps" in qs:
                    location += f"?fps={urllib.parse.quote(qs['fps'])}"
                self.send_response(302)
                self.send_header("Location", location)
                if _auth_token:
                    self.send_header("Set-Cookie",
                        f"eyehands_session={_auth_token}; HttpOnly; SameSite=Strict; "
                        f"Path=/; Max-Age=3600")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            interval = int(qs.get("fps", 2))
            interval_ms = max(100, 1000 // max(1, interval))
            html = _VIEW_HTML.replace("%%INTERVAL%%", str(interval_ms)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", len(html))
            # Re-plant the session cookie if the client reached /view without
            # one (e.g. direct bearer-header navigation) so in-page fetches
            # still authenticate.
            if _auth_token and not self._session_cookie_ok():
                self.send_header("Set-Cookie",
                    f"eyehands_session={_auth_token}; HttpOnly; SameSite=Strict; "
                    f"Path=/; Max-Age=3600")
            self.end_headers()
            self.wfile.write(html)

        elif base == "/find":
            # OCR-based text search — returns exact screen coordinates.
            # Usage: /find?text=Generate
            #        /find?text=Generate&x=140&y=100&w=400&h=300
            # Returns: {"ok": true, "found": true, "matches": [{"label":"...", "x":382, "y":237, "conf":0.9}]}
            # This is the PRIMARY way to locate UI elements in non-UIA apps (games, Godot, Electron).
            qs = self._parse_qs(self.path)
            text = qs.get("text", "")
            if not text:
                self.send_json(400, {"ok": False, "error": "text parameter required"})
            else:
                try:
                    # Grab the region (or full screen) as a raw numpy array —
                    # skip the JPEG encode/decode roundtrip, OCR doesn't need it.
                    grab_qs = {k: v for k, v in qs.items() if k in ("x", "y", "w", "h")}
                    arr, meta = self._grab(grab_qs, want_array=True)
                    cap_left = meta["cap_left"]
                    cap_top  = meta["cap_top"]
                    scale    = meta["scale"]

                    # Lazy-load EasyOCR — cached after first call
                    global _ocr_reader, _ocr_cache_ts, _ocr_cache_results
                    with _ocr_lock:
                        if _ocr_reader is None:
                            import easyocr
                            _ocr_reader = easyocr.Reader(["en"], gpu=False, verbose=False)

                        # Reuse cached OCR results if frame hasn't changed (full-screen only)
                        cur_ts = _frame_buf.frame_hash() if _frame_buf else 0
                        if not grab_qs and cur_ts == _ocr_cache_ts and _ocr_cache_results:
                            results = _ocr_cache_results
                        else:
                            results = _ocr_reader.readtext(arr)
                            if not grab_qs:
                                _ocr_cache_ts = cur_ts
                                _ocr_cache_results = results
                    query_l = text.lower()
                    matches = []
                    for (bbox, t, conf) in results:
                        if query_l in t.lower():
                            xs = [p[0] for p in bbox]
                            ys = [p[1] for p in bbox]
                            cx = int((min(xs) + max(xs)) / 2)
                            cy = int((min(ys) + max(ys)) / 2)
                            sx = int(cap_left + cx / scale)
                            sy = int(cap_top  + cy / scale)
                            matches.append({"label": t, "x": sx, "y": sy, "conf": round(conf, 3)})

                    self.send_json(200, {"ok": True, "found": len(matches) > 0, "matches": matches})
                except Exception as e:
                    self.send_json(500, {"ok": False, "error": str(e)})

        else:
            self.send_json(404, {"ok": False})


def main():
    """CLI entry point. Parses args, starts the HTTP server, blocks until Ctrl+C."""
    global _auth_token, _update_available, _frame_buf, _AUTH_DISABLED, _host_check_enabled
    global _telemetry_disabled_cli

    parser = argparse.ArgumentParser(description="eyehands — give AI agents eyes and hands on Windows")
    parser.add_argument("--host", default="127.0.0.1", help="bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=7331, help="listen port (default: 7331)")
    parser.add_argument("--max-w", type=int, default=1920, help="max capture width in pixels (default: 1920)")
    parser.add_argument("--quality", type=int, default=70, help="JPEG quality 1-95 (default: 70)")
    parser.add_argument("--fps", type=int, default=20, help="background capture FPS (default: 20)")
    parser.add_argument("--no-auth", action="store_true", help="disable bearer token auth (not recommended)")
    parser.add_argument("--no-tips", action="store_true", help="suppress startup tips and /ping tips field")
    parser.add_argument("--no-telemetry", action="store_true",
                        help="disable anonymous install count heartbeat (free-tier only; licensed "
                             "installs still phone home for update checks)")
    parser.add_argument("--install-skill", action="store_true",
                        help="install the eyehands skill into ~/.claude/skills/ and exit")
    parser.add_argument("--version", action="version", version=f"eyehands v{__version__}")
    args = parser.parse_args()

    if args.fps <= 0:
        parser.error("--fps must be positive")
    if args.max_w < 64:
        parser.error("--max-w must be at least 64")
    if not 1 <= args.quality <= 100:
        parser.error("--quality must be 1-100")
    if not 1 <= args.port <= 65535:
        parser.error("--port must be 1-65535")

    if args.install_skill:
        raise SystemExit(_install_skill())

    _capture._tips_enabled = not args.no_tips

    # Kill any existing instance before binding — prevents port pile-up.
    _kill_existing_instance()

    host, port = args.host, args.port
    print(f"eyehands v{__version__}")
    print(f"Virtual desktop: left={_input._vdesk_left} top={_input._vdesk_top} "
          f"{_input._vdesk_w}x{_input._vdesk_h} (spans all monitors)")

    # Auth
    if args.no_auth:
        _AUTH_DISABLED = True
        _auth_token = None
        print("[auth] DISABLED (--no-auth)")
    else:
        print(f"[auth] Token saved to: {_TOKEN_FILE}")
        print(f"[auth] Usage: curl -H \"Authorization: Bearer $(cat '{_TOKEN_FILE}')\" http://{host}:{port}/screenshot")

    # Host header check is a DNS-rebinding defense that only makes sense when
    # bound to loopback. When the user explicitly binds to something else they
    # own the risk; auth leans entirely on the bearer token.
    if args.host not in ("127.0.0.1", "localhost", "::1"):
        _host_check_enabled = False
        print("[warn] Bound to non-loopback — Host header check disabled; "
              "auth leans entirely on the bearer token.")

    # Validate license (non-blocking — falls back to Free tier on timeout)
    _check_pro()

    # Telemetry opt-out: --no-telemetry or .no-telemetry marker file in _DATA_DIR.
    # Only affects the anonymous free-tier heartbeat below. Licensed installs
    # still hit /check unconditionally because that call carries the update
    # notification the user actually wants.
    _telemetry_disabled_cli = args.no_telemetry

    # Check for an available update (5s timeout — must not block startup)
    _update_available = _check_for_updates()

    # Free-tier anonymous heartbeat. No-op when a license exists (licensed
    # installs are already counted via /check), when --no-telemetry is set,
    # or when the 6h cache says we pinged recently. Runs on a daemon thread
    # so a slow portal response can't block the first /screenshot.
    if not os.path.exists(_LICENSE_FILE) and not _telemetry_disabled():
        threading.Thread(target=_free_checkin, daemon=True).start()
    if _update_available:
        print(f"[update] eyehands {_update_available['latest']} is available "
              f"(you're on {_update_available['current']}).")
        print("[update] Run: pip install -U eyehands")
        print(f"[update] Or:  curl -X POST http://{host}:{port}/update -H \"Authorization: Bearer $(cat .eyehands-token)\"")

    print(f"Starting background frame capture ({args.fps} fps)...")
    _frame_buf = FrameBuffer(monitor_idx=primary_monitor_idx(), max_w=args.max_w, quality=args.quality, fps=args.fps)

    try:
        server = ThreadingHTTPServer((host, port), Handler)
    except OSError as e:
        print(f"[error] Could not bind to {host}:{port} — {e}")
        print("[error] Another process may still hold the port.")
        print(f"[error] Run: netstat -ano | findstr {port}  then taskkill /F /PID <pid>")
        raise SystemExit(1)

    _write_pid()
    print(f"eyehands listening on http://{host}:{port}  (PID {os.getpid()})")
    print("Free endpoints:")
    print("  POST: /move  /move_absolute  /click  /double_click  /mousedown  /mouseup")
    print("        /scroll  /key  /type_text")
    print("  GET:  /ping  /cursor_pos  /screenshot  /screenshot_b64  /latest  /latest_b64")
    print("        /view  /find  /license")
    print("Pro endpoints:" + (" [active]" if _pro_active else " [locked — upgrade at portal.fireal.dev]"))
    print("  POST: /smooth_move  /batch  /click_at  /click_and_wait  /type_and_enter")
    print("        /ui/click_element")
    print("  GET:  /ui/windows  /ui/find  /ui/at  /ui/tree")
    if not _pro_active:
        print(f"\nActivate Pro: curl -X POST http://{host}:{port}/activate "
              "-H 'Content-Type: application/json' -d '{\"key\":\"YOUR-KEY\"}'")
    print(f"\nCoordinate mapping: screen_x = cap_left + (img_pixel_x / scale)")

    if _capture._tips_enabled:
        print()
        print("Tip: For the smoothest screenshot workflow, install Claude's Chrome")
        print("     extension. The eyehands skill will then use Chrome MCP + /view")
        print("     for one-tool-call captures instead of curl -> save -> read.")
        print()
        print("Tip: Run 'eyehands --install-skill' once to drop the eyehands skill")
        print("     into ~/.claude/skills/ with this install's token path baked in.")
        print("     (suppress both with --no-tips)")

    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        _remove_pid()


if __name__ == "__main__":
    main()
