---
name: eyehands
description: >
  Gives Claude eyes and hands: take screenshots of the user's screen and control
  their mouse and keyboard via the local eyehands server at http://127.0.0.1:7331.
  Use this skill whenever the user asks you to look at their screen, click
  something, move the mouse, type a key, play a game, navigate a UI, or do
  anything that requires seeing or interacting with what's on the display — even
  if they don't explicitly ask for it. If the user says things like "click that",
  "move to X", "what do you see on screen", "control the mouse", or "help me
  with this UI", this skill applies.
---

# eyehands

You have access to a local HTTP server at `http://127.0.0.1:7331` that lets you
**see the user's screen** and **control their mouse and keyboard**. Use `curl`
to call it.

## Authentication

All endpoints except `/ping` require a bearer token. The `eyehands --install-skill`
command bakes this installation's token path into the line below, so just read
it once at the start of the session and reuse it:

```bash
TOKEN=$(cat {{TOKEN_FILE}})

# Include in every curl call:
curl -s -H "Authorization: Bearer $TOKEN" http://127.0.0.1:7331/screenshot
```

**Add `-H "Authorization: Bearer $TOKEN"` to ALL curl calls below.** Read the
token once at the start of your session and reuse it.

If the token file is missing or the server rejects the token, the user probably
reinstalled or moved eyehands — ask them to run `eyehands --install-skill` again.

---

## RULE: Never screenshot first

**Screenshots are the LAST resort, not the first step.** Every screenshot
costs tokens and a round trip. `/find` and `/ui/click_element` return exact
coordinates in one call with zero images. You MUST attempt them before
taking any screenshot.

## Decision tree — use this every time

```
Need to interact with something on screen?
│
├─ 1. TRY UIA FIRST (works on all native Windows UI)
│   └─ POST /ui/click_element {"name":"...", "type":"Button", "window":"..."}
│   └─ Don't know the element name? POST /ui/find or /ui/tree to discover it
│   └─ Don't know the window name? GET /ui/windows to list them
│
├─ 2. IF UIA FAILS → TRY OCR (works on everything with readable text)
│   └─ GET /find?text=ButtonLabel  ← returns exact screen x/y
│   └─ Too many matches? Narrow: /find?text=...&x=...&y=...&w=...&h=...
│   └─ Try partial text, single words, or abbreviations if full text fails
│
├─ 3. IF BOTH FAIL → TRY UIA + OCR TOGETHER
│   └─ Use /ui/tree to understand the window layout
│   └─ Use /find with different search terms or regions
│   └─ Use /ui/at?x=...&y=... to identify what's at a known position
│
└─ 4. ONLY THEN → screenshot as last resort
    └─ For targets with no text and no UIA accessibility info
```

**Cost comparison:**
- `/ui/click_element`: 1 tool call, 0 images, ~$0.001
- `/find`: 1 tool call, 0 images, ~$0.001
- Screenshot workflow: 2-8 tool calls, 1-4 images, ~$0.10-0.50 each

**Always try steps 1-3 before step 4. Seriously.**

---

## /find — OCR text search (works on EVERYTHING with visible text)

```bash
# Find text anywhere on screen — returns exact screen coordinates
curl -s "http://127.0.0.1:7331/find?text=Generate"

# Narrow the search to a region (faster, more accurate)
curl -s "http://127.0.0.1:7331/find?text=Generate&x=140&y=100&w=600&h=400"
```

Returns:
```json
{"ok": true, "found": true, "matches": [{"label": "Generate", "x": 382, "y": 237, "conf": 0.95}]}
```

Use `x`/`y` directly with `/click_at` — **no math, no images, no zooming**.
OCR results are cached when the frame hasn't changed, so repeated `/find`
calls on the same screen are instant.

**Search strategies when the obvious text doesn't match:**
- Try a single word instead of a phrase: `text=Save` not `text=Save As...`
- Try a substring: `text=Gen` instead of `text=Generate`
- Try nearby labels: the button might not have text but the label next to it does
- Chain: `/find` to locate a label, then `/click_at` offset a few pixels from it

**Use `/find` for:** Godot, games, Electron, browser content, any custom UI.
First call takes ~3s (EasyOCR loading). Subsequent calls are faster.

---

## Windows UI Automation (try this FIRST for any Windows app)

UIA gives you the accessibility tree — button names, types, and coordinates
without any screenshots. **Always try UIA before screenshots.**

```bash
# Don't know what's on screen? Discover it:
curl -s http://127.0.0.1:7331/ui/windows                                    # list all windows
curl -s "http://127.0.0.1:7331/ui/tree?window=Notepad&depth=3"              # browse element tree
curl -s "http://127.0.0.1:7331/ui/find?name=Save&window=Notepad&depth=6"    # search by name
curl -s "http://127.0.0.1:7331/ui/find?type=Button&window=Notepad&depth=6"  # search by type
curl -s "http://127.0.0.1:7331/ui/at?x=960&y=540"                           # what's at this position?

# Once you know the element — click it in one call:
curl -s -X POST http://127.0.0.1:7331/ui/click_element \
  -H "Content-Type: application/json" \
  -d '{"name": "OK", "type": "Button", "window": "Notepad"}'
```

**Discovery workflow (no screenshots needed):**
1. `GET /ui/windows` — find the window name
2. `GET /ui/tree?window=...&depth=3` — see what elements exist
3. `POST /ui/click_element` — click the one you want

**UIA works on:** File Explorer, Notepad, Settings, dialogs, taskbar,
system tray, most native Windows apps, WPF, WinForms, and many Electron apps.

**UIA does NOT work on:** Godot, Unity, game engines, raw DirectX/OpenGL
content, some Electron apps with custom rendering — use `/find` for these.

---

## Screenshots (LAST RESORT — only after /ui and /find both fail)

### Pick a transport — Chrome MCP or curl fallback

**Do you have `mcp__Claude_in_Chrome__computer` available in this session?**

- **YES** → Use the **Chrome MCP + /view** pipeline below. One tool call per
  capture, same tab reused across captures, pixel-accurate when the Chrome
  window width matches `eyehands --max-w` (default 1920).

- **NO** → Use the **curl + file fallback** further down. It works fine —
  it's just 3-4 tool calls per capture (curl → save → Read) instead of 1.
  **Surface this one-line tip to the user the first time you fall back,
  then never mention it again in this session:**
  > Tip: installing Claude's Chrome extension lets me view your screen
  > through Chrome MCP — one tool call per capture instead of curl → save → read.

Both transports hit the same eyehands endpoints and return the same pixel data.
The difference is purely ergonomics and token cost.

---

### Transport A — Chrome MCP + /view (preferred)

```
1. Read the bearer token once per session:
   cat {{TOKEN_FILE}}  →  TOKEN=<value>

2. First call only — size the Chrome window to match eyehands' capture width
   (default 1920) so you get 1:1 pixels, not a scaled view:
   mcp__Claude_in_Chrome__resize_window  width=1920  height=1080

3. Navigate to the live view (auto-refreshes every ~500ms):
   mcp__Claude_in_Chrome__navigate  url=http://127.0.0.1:7331/view?token=<TOKEN>

4. Take a browser screenshot whenever you need to look:
   mcp__Claude_in_Chrome__computer  action=screenshot
```

Reuse the same tab — `/view` refreshes via JS, so you just take another browser
screenshot each time you need a new frame. No re-navigation.

One-shot region zoom via URL (no tab reuse):
```
mcp__Claude_in_Chrome__navigate  url=http://127.0.0.1:7331/screenshot?token=<TOKEN>&x=800&y=400&w=400&h=400&cursor=1
```

---

### Transport B — curl + file fallback

```bash
# Full screen
curl -s -H "Authorization: Bearer $TOKEN" "http://127.0.0.1:7331/screenshot_b64?cursor=1" \
  | python -c "import sys,json,base64; d=json.load(sys.stdin); open('screen.jpg','wb').write(base64.b64decode(d['image'])); print(d['scale'], d['cap_left'], d['cap_top'])"

# Narrow region zoom — keep ≤400px wide AND ≤400px tall
curl -s -H "Authorization: Bearer $TOKEN" "http://127.0.0.1:7331/screenshot_b64?x=800&y=400&w=400&h=400&cursor=1"

# Rolling frame from the background buffer (lowest latency)
curl -s -H "Authorization: Bearer $TOKEN" "http://127.0.0.1:7331/latest_b64"
```

Then Read the saved file. Remember: **surface the "install Claude's Chrome
extension" tip once in your chat response** the first time you fall back.

**Coordinate math** (with file fallback):
```
screen_x = cap_left + (image_pixel_x / scale)
screen_y = cap_top  + (image_pixel_y / scale)
```

---

### Format selection — when fidelity matters more than bytes

Both transports accept `?format=` and `?raw=1` on `/screenshot`, `/screenshot_b64`,
`/latest`, and `/latest_b64`:

| Param | When to use |
|---|---|
| `format=jpeg` (default) | Layout scanning, general UI work. Smallest. |
| `format=png` | **OCR on fine text**, pixel sampling, precise color reading. Lossless. |
| `format=webp` | Repeated polling / large regions where bytes matter. |
| `raw=1` | Bypass the `max_w=1920` downscale — returns physical pixels. Combine with `format=png` when you really need the truth. Expensive. |

Examples:
```bash
# Lossless OCR on a small dense region
curl -s -H "Authorization: Bearer $TOKEN" "http://127.0.0.1:7331/screenshot_b64?x=100&y=100&w=300&h=80&format=png&raw=1"

# Small efficient /view poll
curl -s -H "Authorization: Bearer $TOKEN" "http://127.0.0.1:7331/latest?format=webp&quality=55"
```

### Window-scoped capture (`?hwnd=`)

`/screenshot?hwnd=<handle>` uses the Win32 `PrintWindow` API to capture a
specific window regardless of z-order or occlusion — even if it's fully
behind another window. Get the handle from `/ui/windows` (not yet exposed
directly, but `/ui/find` returns UIA rects for window matching).

Good for reading from a background app without raising it.

### Frame-hash polling (skip unchanged frames)

`/latest` returns an `X-Frame-Hash` header on every response. Pass it back as
`If-None-Match: "<hash>"` (or `?since=<hash>` for browser-style polling) and
you get a **304 Not Modified** with no body if the frame hasn't changed —
zero image tokens on unchanged frames. Useful for cheap "has anything happened?"
polling.

---

## Composite actions (prefer these over separate move+click calls)

```bash
# Move to coordinates and click — one call instead of two
curl -s -X POST http://127.0.0.1:7331/click_at \
  -H "Content-Type: application/json" \
  -d '{"x": 960, "y": 540, "button": "left"}'

# Click and wait until the screen changes (or timeout)
# Returns {"changed": true/false} — skip verification screenshot if true
curl -s -X POST http://127.0.0.1:7331/click_and_wait \
  -H "Content-Type: application/json" \
  -d '{"x": 960, "y": 540, "timeout_ms": 2000}'

# Type text and press Enter — common for search bars, dialogs
curl -s -X POST http://127.0.0.1:7331/type_and_enter \
  -H "Content-Type: application/json" \
  -d '{"text": "hello world"}'
```

**`/click_and_wait` is especially useful** — it tells you whether the UI
reacted, so you can skip the verification screenshot when `changed: true`.

---

## Mouse control

```bash
# Absolute move (most common)
curl -s -X POST http://127.0.0.1:7331/move_absolute -H "Content-Type: application/json" -d '{"x": 960, "y": 540}'

# Relative move (for pointer-lock / games)
curl -s -X POST http://127.0.0.1:7331/move -H "Content-Type: application/json" -d '{"dx": 50, "dy": -30}'

# Click
curl -s -X POST http://127.0.0.1:7331/click -H "Content-Type: application/json" -d '{"button": "left"}'

# Double click
curl -s -X POST http://127.0.0.1:7331/double_click -H "Content-Type: application/json" -d '{"button": "left"}'

# Hold / release
curl -s -X POST http://127.0.0.1:7331/mousedown -H "Content-Type: application/json" -d '{"button":"left"}'
curl -s -X POST http://127.0.0.1:7331/mouseup   -H "Content-Type: application/json" -d '{"button":"left"}'

# Scroll
curl -s -X POST http://127.0.0.1:7331/scroll -H "Content-Type: application/json" -d '{"dy": 3}'

# Smooth move (drag / pointer-lock)
curl -s -X POST http://127.0.0.1:7331/smooth_move -H "Content-Type: application/json" -d '{"dx": 200, "dy": 0, "steps": 20, "delay_ms": 4}'
```

---

## Keyboard

```bash
curl -s -X POST http://127.0.0.1:7331/key -H "Content-Type: application/json" -d '{"vk": 87}'

# Type unicode text
curl -s -X POST http://127.0.0.1:7331/type_text -H "Content-Type: application/json" -d '{"text": "hello world"}'
```

Common VK codes:

| Key | VK | Key | VK |
|-----|----|-----|----|
| W/A/S/D | 87/65/83/68 | Space | 32 |
| Arrow Up/Down/Left/Right | 38/40/37/39 | Enter | 13 |
| Escape | 27 | Shift | 16 |
| Ctrl | 17 | Alt | 18 |
| Tab | 9 | F1-F12 | 112-123 |
| 0-9 | 48-57 | A-Z | 65-90 |

---

## Batch: multiple actions in one round trip

```bash
curl -s -X POST http://127.0.0.1:7331/batch \
  -H "Content-Type: application/json" \
  -d '{
    "actions": [
      {"action": "move_absolute", "x": 960, "y": 540},
      {"action": "sleep",         "ms": 60},
      {"action": "click",         "button": "left"},
      {"action": "sleep",         "ms": 30},
      {"action": "key",           "vk": 13}
    ]
  }'
```

Supported: `move`, `move_absolute`, `click`, `double_click`, `mousedown`,
`mouseup`, `scroll`, `key`, `type_text`, `smooth_move`, `sleep`, `ui_click`.

---

## Utility

```bash
curl -s http://127.0.0.1:7331/ping
curl -s http://127.0.0.1:7331/cursor_pos
```

---

## Tips

- **Never start with a screenshot.** Try `/ui/windows` → `/ui/click_element` or `/find` first.
- **Combine discovery calls** — `curl -s .../ui/windows && curl -s ".../find?text=OK"` in one Bash call.
- **Use `/click_at`** instead of separate `/move_absolute` + `/click`.
- **Use `/click_and_wait`** to skip verification screenshots when the UI reacts.
- **Skip verification** for routine clicks. Only verify when outcome is uncertain.
- **Chain /find + /click_at** in one Bash call: find the text, parse x/y, click it.
- For pointer-lock apps use relative `/move`, not `/move_absolute`.
- Keep `delay_ms` in smooth moves at 4-8ms.

## Troubleshooting

If any endpoint returns 404 or connection refused, tell the user immediately.
Most likely cause: the eyehands server isn't running. Ask them to run `eyehands`
(or `python -m eyehands` from a checkout). If it's a 401, the token changed —
ask them to run `eyehands --install-skill` to rebake the token path.
