"""Windows mouse + keyboard input via SendInput.

SendInput routes through the Raw Input pipeline, which is what pointer-lock
apps and games actually read. All multi-event sequences (modifier+key chords,
text typing) are bundled into a single SendInput call so the OS processes
them atomically — no other input can interleave mid-sequence.

Coordinates are physical screen pixels. Per-Monitor v2 DPI awareness must be
set in eyehands/__init__.py before this module is imported so the virtual-
desktop metrics cached below are physical, not DPI-scaled.
"""

import ctypes
import ctypes.wintypes as wintypes
import time

# ── Win32 input constants ─────────────────────────────────────────────────────

INPUT_MOUSE    = 0
INPUT_KEYBOARD = 1

MOUSEEVENTF_MOVE        = 0x0001
MOUSEEVENTF_LEFTDOWN    = 0x0002
MOUSEEVENTF_LEFTUP      = 0x0004
MOUSEEVENTF_RIGHTDOWN   = 0x0008
MOUSEEVENTF_RIGHTUP     = 0x0010
MOUSEEVENTF_MIDDLEDOWN  = 0x0020
MOUSEEVENTF_MIDDLEUP    = 0x0040
MOUSEEVENTF_WHEEL       = 0x0800
MOUSEEVENTF_VIRTUALDESK = 0x4000   # normalize across entire virtual desktop
MOUSEEVENTF_ABSOLUTE    = 0x8000

KEYEVENTF_KEYUP   = 0x0002
KEYEVENTF_UNICODE = 0x0004

_MODIFIER_VK = {
    "ctrl":  0x11,  # VK_CONTROL
    "shift": 0x10,  # VK_SHIFT
    "alt":   0x12,  # VK_MENU
    "win":   0x5B,  # VK_LWIN
}

# ── Input structs ─────────────────────────────────────────────────────────────

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx",          wintypes.LONG),
        ("dy",          wintypes.LONG),
        ("mouseData",   wintypes.DWORD),
        ("dwFlags",     wintypes.DWORD),
        ("time",        wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk",         wintypes.WORD),
        ("wScan",       wintypes.WORD),
        ("dwFlags",     wintypes.DWORD),
        ("time",        wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class _INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("_input", _INPUT_UNION)]

# SendInput binding — guarded so the module can be imported on non-Windows
# (CI, tests). Actual input calls raise OSError below when SendInput is None.
try:
    SendInput = ctypes.windll.user32.SendInput
    SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    SendInput.restype  = wintypes.UINT
except (OSError, AttributeError):
    SendInput = None


def _send_mouse(flags, dx=0, dy=0, mouse_data=0):
    if SendInput is None:
        raise OSError("SendInput unavailable (non-Windows)")
    inp = INPUT(type=INPUT_MOUSE)
    inp._input.mi = MOUSEINPUT(dx=int(dx), dy=int(dy), mouseData=mouse_data,
                               dwFlags=flags, time=0, dwExtraInfo=None)
    SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


# ── Virtual-desktop metrics ───────────────────────────────────────────────────
# Cached at import time — these are properties of the current display layout,
# not process state, so reading once is fine. DPI awareness MUST be set before
# this module imports (eyehands/__init__.py handles that) so the values are
# physical pixels rather than DPI-scaled.
# SM_XVIRTUALSCREEN=76, SM_YVIRTUALSCREEN=77 can be negative on multi-monitor.
# SM_CXVIRTUALSCREEN=78, SM_CYVIRTUALSCREEN=79 span all displays.
try:
    _vdesk_left = ctypes.windll.user32.GetSystemMetrics(76)
    _vdesk_top  = ctypes.windll.user32.GetSystemMetrics(77)
    _vdesk_w    = ctypes.windll.user32.GetSystemMetrics(78)
    _vdesk_h    = ctypes.windll.user32.GetSystemMetrics(79)
except (OSError, AttributeError):
    # Non-Windows fallback so `import eyehands.server` works under pytest/CI.
    # Never actually consulted on Windows — the _send_mouse guard above trips
    # first, so move_absolute() can't reach the normalization math.
    _vdesk_left, _vdesk_top, _vdesk_w, _vdesk_h = 0, 0, 1920, 1080


# ── Mouse ─────────────────────────────────────────────────────────────────────

def move(dx, dy):
    """Relative mouse movement — works through pointer lock."""
    _send_mouse(MOUSEEVENTF_MOVE, dx, dy)


def click(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTDOWN)
        _send_mouse(MOUSEEVENTF_RIGHTUP)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEDOWN)
        _send_mouse(MOUSEEVENTF_MIDDLEUP)
    else:
        _send_mouse(MOUSEEVENTF_LEFTDOWN)
        _send_mouse(MOUSEEVENTF_LEFTUP)


def double_click(button="left"):
    click(button)
    time.sleep(0.05)
    click(button)


def mousedown(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTDOWN)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEDOWN)
    else:
        _send_mouse(MOUSEEVENTF_LEFTDOWN)


def mouseup(button="left"):
    if button == "right":
        _send_mouse(MOUSEEVENTF_RIGHTUP)
    elif button == "middle":
        _send_mouse(MOUSEEVENTF_MIDDLEUP)
    else:
        _send_mouse(MOUSEEVENTF_LEFTUP)


def scroll(dy):
    """dy > 0 = scroll up, dy < 0 = scroll down (Windows WHEEL_DELTA = 120)."""
    _send_mouse(MOUSEEVENTF_WHEEL, mouse_data=int(dy * 120))


def move_absolute(x, y):
    """Move to absolute screen coords — multi-monitor safe via MOUSEEVENTF_VIRTUALDESK.

    Normalises (x, y) across the full virtual desktop (all monitors) to the
    0-65535 range that SendInput requires, then sends ABSOLUTE | VIRTUALDESK
    so the OS maps it correctly even on secondary displays.
    """
    norm_x = int((int(x) - _vdesk_left) * 65535 / max(_vdesk_w - 1, 1))
    norm_y = int((int(y) - _vdesk_top)  * 65535 / max(_vdesk_h - 1, 1))
    norm_x = max(0, min(65535, norm_x))
    norm_y = max(0, min(65535, norm_y))
    _send_mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK,
                norm_x, norm_y)


def _smooth_move(dx, dy, steps, delay_s):
    """Relative smooth move with Bresenham-style integer accumulation.

    The naive approach of int(dx/steps) per step loses sub-pixel remainders and
    produces zero motion when dx < steps. Accumulating the error ensures the
    total displacement exactly equals (dx, dy) regardless of step count.
    """
    err_x = err_y = 0.0
    for _ in range(steps):
        err_x += dx / steps
        err_y += dy / steps
        sx = int(err_x); err_x -= sx
        sy = int(err_y); err_y -= sy
        move(sx, sy)
        if delay_s > 0:
            time.sleep(delay_s)


# ── Keyboard ──────────────────────────────────────────────────────────────────

def keypress(vk_code, modifiers=None):
    """Press and release a virtual key using SendInput (replaces deprecated keybd_event).

    modifiers: optional list of modifier name strings, e.g. ["ctrl", "shift"].
    Modifier keys are held down for the duration of the main key press, then released.
    """
    if SendInput is None:
        raise OSError("SendInput unavailable (non-Windows)")
    mods = [_MODIFIER_VK[m.lower()] for m in (modifiers or []) if m.lower() in _MODIFIER_VK]
    # Build: mod_down... + key_down + key_up + mod_up...
    n = len(mods) * 2 + 2
    arr = (INPUT * n)()
    idx = 0
    for mvk in mods:
        arr[idx].type = INPUT_KEYBOARD
        arr[idx]._input.ki = KEYBDINPUT(wVk=mvk, wScan=0, dwFlags=0, time=0, dwExtraInfo=None)
        idx += 1
    arr[idx].type = INPUT_KEYBOARD
    arr[idx]._input.ki = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=0, time=0, dwExtraInfo=None)
    idx += 1
    arr[idx].type = INPUT_KEYBOARD
    arr[idx]._input.ki = KEYBDINPUT(wVk=vk_code, wScan=0, dwFlags=KEYEVENTF_KEYUP, time=0, dwExtraInfo=None)
    idx += 1
    for mvk in reversed(mods):
        arr[idx].type = INPUT_KEYBOARD
        arr[idx]._input.ki = KEYBDINPUT(wVk=mvk, wScan=0, dwFlags=KEYEVENTF_KEYUP, time=0, dwExtraInfo=None)
        idx += 1
    SendInput(n, arr, ctypes.sizeof(INPUT))


def type_text(text):
    """Type a unicode string via SendInput KEYEVENTF_UNICODE — handles any character.

    All key-down/key-up events are sent in a single SendInput call so they
    are processed atomically by the OS (no other process can interleave input).
    """
    if not text:
        return
    if SendInput is None:
        raise OSError("SendInput unavailable (non-Windows)")
    n = len(text)
    arr = (INPUT * (n * 2))()
    for i, ch in enumerate(text):
        ucode = ord(ch)
        arr[i * 2].type = INPUT_KEYBOARD
        arr[i * 2]._input.ki = KEYBDINPUT(
            wVk=0, wScan=ucode, dwFlags=KEYEVENTF_UNICODE,
            time=0, dwExtraInfo=None)
        arr[i * 2 + 1].type = INPUT_KEYBOARD
        arr[i * 2 + 1]._input.ki = KEYBDINPUT(
            wVk=0, wScan=ucode, dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
            time=0, dwExtraInfo=None)
    SendInput(n * 2, arr, ctypes.sizeof(INPUT))


# ── Cursor / display helpers ──────────────────────────────────────────────────

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def get_cursor_pos():
    """Return current cursor position as (x, y) in screen pixels."""
    try:
        pt = POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y
    except (OSError, AttributeError):
        return 0, 0


def primary_monitor_idx():
    """Return the mss monitor index (1-based) whose origin is (0, 0) — the Windows primary monitor.
    Falls back to 1 if no such monitor is found."""
    try:
        import mss as _mss
        with _mss.mss() as sct:
            for i, m in enumerate(sct.monitors):
                if i == 0:
                    continue  # index 0 is the virtual desktop spanning all monitors
                if m.get("left", -1) == 0 and m.get("top", -1) == 0:
                    return i
    except Exception:
        pass
    return 1
