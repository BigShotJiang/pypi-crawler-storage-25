"""Tests for CLI entry point."""

from click.testing import CliRunner

from codeprobe import __version__
from codeprobe.cli import main


def test_cli_version():
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "codeprobe" in result.output
    assert __version__ in result.output


def test_cli_help():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "Benchmark AI coding agents" in result.output


def test_cli_commands_registered():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    for cmd in ("init", "mine", "run", "interpret", "assess"):
        assert cmd in result.output, f"Command '{cmd}' not found in help output"


def test_main_module_runnable():
    """Verify `python -m codeprobe --version` works (needed for pipx run)."""
    import subprocess
    import sys

    result = subprocess.run(
        [sys.executable, "-m", "codeprobe", "--version"],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert result.returncode == 0
    assert __version__ in result.stdout


def test_cli_run_has_max_cost_option():
    runner = CliRunner()
    result = runner.invoke(main, ["run", "--help"])
    assert result.exit_code == 0
    assert "--max-cost-usd" in result.output
    assert "CODEPROBE_MAX_COST_USD" in result.output
