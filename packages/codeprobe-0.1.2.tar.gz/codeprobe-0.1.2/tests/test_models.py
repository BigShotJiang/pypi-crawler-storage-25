"""Tests for core data models."""

from codeprobe.models.experiment import (
    CompletedTask,
    ConfigResults,
    Experiment,
    ExperimentConfig,
)
from codeprobe.models.task import Task, TaskMetadata, TaskVerification


def test_task_is_frozen():
    meta = TaskMetadata(name="test-task", difficulty="medium")
    task = Task(id="t-001", repo="org/repo", metadata=meta)
    assert task.id == "t-001"
    assert task.metadata.difficulty == "medium"


def test_experiment_config_defaults():
    config = ExperimentConfig(label="baseline")
    assert config.agent == "claude"
    assert config.model is None
    assert config.permission_mode == "default"
    assert config.mcp_config is None


def test_experiment_config_permission_mode():
    config = ExperimentConfig(label="safe", permission_mode="plan")
    assert config.permission_mode == "plan"


def test_completed_task_score():
    task = CompletedTask(task_id="t-001", automated_score=0.75)
    assert task.automated_score == 0.75
    assert task.status == "completed"


def test_completed_task_error_category_default():
    task = CompletedTask(task_id="t-001", automated_score=1.0)
    assert task.error_category is None


def test_completed_task_error_category_values():
    for category in ("agent", "system", "timeout", "resource"):
        task = CompletedTask(
            task_id="t-001", automated_score=0.0, error_category=category
        )
        assert task.error_category == category


def test_completed_task_repeat_index_default():
    task = CompletedTask(task_id="t-001", automated_score=1.0)
    assert task.repeat_index == 0


def test_completed_task_repeat_index_explicit():
    task = CompletedTask(task_id="t-001", automated_score=1.0, repeat_index=3)
    assert task.repeat_index == 3


def test_config_results():
    results = ConfigResults(
        config="baseline",
        completed=[
            CompletedTask(task_id="t-001", automated_score=1.0),
            CompletedTask(task_id="t-002", automated_score=0.0),
        ],
    )
    assert len(results.completed) == 2
    avg = sum(t.automated_score for t in results.completed) / len(results.completed)
    assert avg == 0.5


def test_task_verification_defaults():
    v = TaskVerification()
    assert v.type == "test_script"
    assert v.command == "bash tests/test.sh"
    assert v.reward_type == "binary"


def test_experiment():
    exp = Experiment(
        name="test-exp",
        configs=[
            ExperimentConfig(label="baseline"),
            ExperimentConfig(label="with-mcp", mcp_config={"tools": ["search"]}),
        ],
    )
    assert len(exp.configs) == 2
    assert exp.configs[1].label == "with-mcp"
