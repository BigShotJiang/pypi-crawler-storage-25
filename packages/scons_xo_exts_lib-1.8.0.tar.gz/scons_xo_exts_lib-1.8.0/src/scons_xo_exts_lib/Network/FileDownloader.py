#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import os
import stat

from typing import List, Optional

from .INetworkDownloader import INetworkDownloader, PostprocessFunction


class FileDownloader(INetworkDownloader):
    def __init__(
        self,
        src_uris: List[str],
        checksum: Optional[str],
        outputs: List[str],
        postprocess_function: Optional[PostprocessFunction] = None,
        is_executable: bool = False,
    ):

        super().__init__(src_uris, checksum, outputs, postprocess_function)

        self._is_executable = is_executable

    def download(self):

        downloaded_path = self._download_to_temp()

        if self._is_executable:
            os.chmod(downloaded_path, os.stat(downloaded_path).st_mode | stat.S_IXUSR)

        final_output = self._get_first_output()

        self._move_to_output(downloaded_path, final_output)
        self._run_postprocess()
