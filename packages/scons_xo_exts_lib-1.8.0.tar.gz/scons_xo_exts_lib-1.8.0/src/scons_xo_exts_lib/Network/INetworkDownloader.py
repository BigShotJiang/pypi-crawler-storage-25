#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import hashlib
import os
import shutil
import tempfile
import urllib.request

from abc import ABC, abstractmethod
from typing import Callable, List, Optional

PostprocessFunction = Callable[[str], None]


class INetworkDownloader(ABC):
    def __init__(
        self,
        src_uris: List[str],
        checksum: Optional[str],
        outputs: List[str],
        postprocess_function: Optional[PostprocessFunction] = None,
    ):

        self._src_uris = src_uris
        self._checksum = checksum
        self._outputs = outputs
        self._postprocess_function = postprocess_function

    @abstractmethod
    def download(self):

        raise NotImplementedError

    def _get_first_output(self) -> str:

        return self._outputs[0]

    def _get_output_dir(self) -> str:

        return os.path.dirname(self._get_first_output())

    def _run_postprocess(self):

        func = self._postprocess_function

        if func is not None:
            func(self._outputs)

    def _try_download(self, uri: str) -> Optional[str]:

        request = urllib.request.Request(uri)

        with urllib.request.urlopen(request) as response:
            if response.status >= 400:
                return None

            content_length = response.headers.get("Content-Length")
            expected_size = int(content_length) if content_length else None

            with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
                downloaded_size = 0

                while True:
                    chunk = response.read(8192)

                    if not chunk:
                        break

                    tmp_file.write(chunk)

                    downloaded_size += len(chunk)

                    if expected_size and downloaded_size > expected_size:
                        os.unlink(tmp_file.name)

                        return None

                return tmp_file.name

    def _download_to_temp(self) -> str:

        downloaded_path = None

        for uri in self._src_uris:
            try:
                downloaded_path = self._try_download(uri)
                if downloaded_path:
                    break
            except Exception:
                continue

        if downloaded_path is None:
            raise RuntimeError("Failed to download from any provided URI")

        checksum = self._checksum

        if checksum is not None:
            self._verify_checksum(downloaded_path, checksum)

        return downloaded_path

    def _verify_checksum(self, file_path: str, expected: str):

        hash_value = self._compute_hash(file_path)

        if hash_value != expected:
            raise RuntimeError(
                f"Checksum mismatch: expected {expected}, got {hash_value}"
            )

    def _compute_hash(self, file_path: str) -> str:

        sha256_hash = hashlib.sha256()

        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256_hash.update(chunk)

        return sha256_hash.hexdigest()

    def _move_to_output(self, src: str, final_output: str):

        output_dir = os.path.dirname(final_output)

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        if os.path.isdir(src):
            if os.path.exists(final_output):
                shutil.rmtree(final_output)

            shutil.copytree(src, final_output)
            shutil.rmtree(src)
        else:
            shutil.move(src, final_output)
