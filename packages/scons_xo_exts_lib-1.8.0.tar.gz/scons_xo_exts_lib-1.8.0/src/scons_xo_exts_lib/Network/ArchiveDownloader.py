#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import os
import shutil
import tarfile
import tempfile
import zipfile

from typing import List, Optional

from .INetworkDownloader import INetworkDownloader, PostprocessFunction


class ArchiveDownloader(INetworkDownloader):
    def __init__(
        self,
        src_uris: List[str],
        checksum: Optional[str],
        outputs: List[str],
        postprocess_function: Optional[PostprocessFunction] = None,
        exact_outputs: bool = False,
    ):

        super().__init__(src_uris, checksum, outputs, postprocess_function)

        self._exact_outputs = exact_outputs

    def download(self):

        first_output = self._get_first_output()
        output_dir = os.path.dirname(first_output)

        downloaded_path = self._download_to_temp()

        self._extract(downloaded_path, output_dir)

        os.unlink(downloaded_path)

        entries = os.listdir(output_dir)

        if not entries:
            raise RuntimeError("No files extracted")

        self._run_postprocess()

    def _extract(self, archive_path: str, output_dir: str):

        if zipfile.is_zipfile(archive_path):
            self._extract_zip(archive_path, output_dir)
        elif tarfile.is_tarfile(archive_path):
            self._extract_tar(archive_path, output_dir)
        else:
            raise RuntimeError("Unsupported archive format")

    def _extract_zip(self, archive_path: str, output_dir: str):

        with tempfile.TemporaryDirectory() as tmp_dir:
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extractall(tmp_dir)

            self._handle_single_top_level_dir(tmp_dir, output_dir)

    def _extract_tar(self, archive_path: str, output_dir: str):

        with tempfile.TemporaryDirectory() as tmp_dir:
            with tarfile.open(archive_path, "r:*") as tf:
                tf.extractall(tmp_dir, filter="data")

            self._handle_single_top_level_dir(tmp_dir, output_dir)

    def _handle_single_top_level_dir(self, tmp_dir: str, output_dir: str):

        os.makedirs(output_dir, exist_ok=True)

        entries = os.listdir(tmp_dir)

        if not entries:
            return

        top_level_dirs = [e for e in entries if os.path.isdir(os.path.join(tmp_dir, e))]
        top_level_files = [
            e for e in entries if os.path.isfile(os.path.join(tmp_dir, e))
        ]

        if len(top_level_dirs) == 1 and not top_level_files:
            single_dir = os.path.join(tmp_dir, top_level_dirs[0])
            for item in os.listdir(single_dir):
                src = os.path.join(single_dir, item)
                dst = os.path.join(output_dir, item)
                self._copy_item(src, dst)
        else:
            for item in entries:
                src = os.path.join(tmp_dir, item)
                dst = os.path.join(output_dir, item)
                self._copy_item(src, dst)

    def _copy_item(self, src: str, dst: str) -> None:
        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            if os.path.exists(dst):
                os.unlink(dst)
            shutil.copy2(src, dst)
