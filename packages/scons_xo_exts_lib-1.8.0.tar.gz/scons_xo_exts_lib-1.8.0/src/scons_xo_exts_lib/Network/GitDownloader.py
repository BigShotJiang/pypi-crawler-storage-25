#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import os
import shutil
import subprocess
import tempfile

from typing import List, Optional

from .INetworkDownloader import INetworkDownloader, PostprocessFunction


class GitDownloader(INetworkDownloader):
    def __init__(
        self,
        src_uris: List[str],
        checksum: Optional[str],
        outputs: List[str],
        postprocess_function: Optional[PostprocessFunction] = None,
        branch: Optional[str] = None,
        commit: Optional[str] = None,
    ):

        super().__init__(src_uris, checksum, outputs, postprocess_function)

        self._branch = branch
        self._commit = commit

    def download(self):

        first_output = self._get_first_output()
        output_dir = os.path.dirname(first_output)

        cloned_path = self._try_clone()

        if cloned_path is None:
            raise RuntimeError("Failed to clone from any provided URI")

        os.makedirs(output_dir, exist_ok=True)

        target_git_dir = os.path.join(output_dir, ".git")

        if os.path.isdir(target_git_dir):
            shutil.rmtree(target_git_dir)

        for item in os.listdir(cloned_path):
            src = os.path.join(cloned_path, item)
            dst = os.path.join(output_dir, item)

            if os.path.exists(dst):
                if os.path.isdir(dst):
                    shutil.rmtree(dst)
                else:
                    os.unlink(dst)

            shutil.move(src, dst)

        os.rmdir(cloned_path)

        if self._checksum is not None and os.path.isfile(first_output):
            self._verify_checksum(first_output, self._checksum)

        self._run_postprocess()

    def _try_clone(self) -> Optional[str]:

        ref = self._commit if self._commit else self._branch

        for uri in self._src_uris:
            tmp_dir = tempfile.mkdtemp()
            repo_dir = os.path.join(tmp_dir, "repo")
            os.makedirs(repo_dir)

            try:
                subprocess.run(
                    ["git", "init", "--quiet"],
                    cwd=repo_dir,
                    check=True,
                )

                subprocess.run(
                    ["git", "remote", "add", "origin", uri],
                    cwd=repo_dir,
                    check=True,
                )

                if ref:
                    self._fetch_ref(ref, repo_dir)

                    subprocess.run(
                        ["git", "checkout", "--quiet", ref],
                        cwd=repo_dir,
                        check=True,
                    )
                else:
                    subprocess.run(
                        ["git", "fetch", "--quiet", "--depth=1", "origin"],
                        cwd=repo_dir,
                        check=True,
                    )

                    subprocess.run(
                        ["git", "checkout", "--quiet", "origin/HEAD"],
                        cwd=repo_dir,
                        check=True,
                    )

                subprocess.run(
                    [
                        "git",
                        "submodule",
                        "update",
                        "--quiet",
                        "--depth=1",
                        "--init",
                        "--recursive",
                    ],
                    cwd=repo_dir,
                    check=True,
                )

                return repo_dir

            except subprocess.CalledProcessError:
                shutil.rmtree(tmp_dir)
                continue

        return None

    def _fetch_ref(self, ref: str, repo_dir: str) -> None:

        if self._commit:
            subprocess.run(
                ["git", "fetch", "--quiet", "origin", ref],
                cwd=repo_dir,
                check=True,
            )
        else:
            subprocess.run(
                ["git", "fetch", "--quiet", "--depth=1", "origin", ref],
                cwd=repo_dir,
                check=True,
            )
