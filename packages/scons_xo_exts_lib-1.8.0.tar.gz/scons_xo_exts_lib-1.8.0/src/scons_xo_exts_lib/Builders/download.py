#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import json

from SCons.Script import Builder
from SCons.Script import Environment

from scons_xo_exts_lib.Network.ArchiveDownloader import ArchiveDownloader
from scons_xo_exts_lib.Network.FileDownloader import FileDownloader
from scons_xo_exts_lib.Network.GitDownloader import GitDownloader

DOWNLOAD_FILE_KEYS = (
    "src_uris",
    "checksum",
    "postprocess_function",
    "is_executable",
)

DOWNLOAD_ARCHIVE_KEYS = (
    "src_uris",
    "checksum",
    "postprocess_function",
    "exact_outputs",
)

DOWNLOAD_GIT_KEYS = (
    "src_uris",
    "checksum",
    "postprocess_function",
    "branch",
    "commit",
)


def _extract_kwargs(env: Environment, keys: tuple) -> dict:

    kwargs = {}

    for key in keys:
        if key in env:
            kwargs[key] = env[key]

    env["DOWNLOAD_KWARGS"] = json.dumps(kwargs)

    for key in keys:
        if key in env:
            del env[key]

    return kwargs


def download_file_emitter(target, source, env: Environment):

    _extract_kwargs(env, DOWNLOAD_FILE_KEYS)

    return (target, source)


def download_file_action(target, source, env: Environment) -> int:

    kwargs_json = env.get("DOWNLOAD_KWARGS", "{}")
    kwargs = json.loads(kwargs_json)

    src_uris = kwargs.get("src_uris", [])
    checksum = kwargs.get("checksum", None)

    postprocess_function = kwargs.get("postprocess_function", None)
    is_executable = kwargs.get("is_executable", False)

    target_path = str(target[0].abspath)

    downloader = FileDownloader(
        src_uris=src_uris,
        checksum=checksum,
        outputs=[target_path],
        postprocess_function=postprocess_function,
        is_executable=is_executable,
    )

    downloader.download()

    return 0


def download_archive_emitter(target, source, env: Environment):

    _extract_kwargs(env, DOWNLOAD_ARCHIVE_KEYS)

    return (target, source)


def download_archive_action(target, source, env: Environment) -> int:

    kwargs_json = env.get("DOWNLOAD_KWARGS", "{}")
    kwargs = json.loads(kwargs_json)

    src_uris = kwargs.get("src_uris", [])
    checksum = kwargs.get("checksum", None)

    postprocess_function = kwargs.get("postprocess_function", None)
    exact_outputs = kwargs.get("exact_outputs", False)

    target_path = str(target[0].abspath)

    downloader = ArchiveDownloader(
        src_uris=src_uris,
        checksum=checksum,
        outputs=[target_path],
        postprocess_function=postprocess_function,
        exact_outputs=exact_outputs,
    )

    downloader.download()

    return 0


def download_git_emitter(target, source, env: Environment):

    _extract_kwargs(env, DOWNLOAD_GIT_KEYS)

    return (target, source)


def download_git_action(target, source, env: Environment) -> int:

    kwargs_json = env.get("DOWNLOAD_KWARGS", "{}")
    kwargs = json.loads(kwargs_json)

    src_uris = kwargs.get("src_uris", [])
    checksum = kwargs.get("checksum", None)

    postprocess_function = kwargs.get("postprocess_function", None)
    branch = kwargs.get("branch", None)
    commit = kwargs.get("commit", None)

    target_path = str(target[0].abspath)

    downloader = GitDownloader(
        src_uris=src_uris,
        checksum=checksum,
        outputs=[target_path],
        postprocess_function=postprocess_function,
        branch=branch,
        commit=commit,
    )

    downloader.download()

    return 0


def generate(env) -> None:

    download_file_builder = Builder(
        action=download_file_action,
        emitter=download_file_emitter,
    )
    download_archive_builder = Builder(
        action=download_archive_action,
        emitter=download_archive_emitter,
    )
    download_git_builder = Builder(
        action=download_git_action,
        emitter=download_git_emitter,
    )

    env.Append(
        BUILDERS={
            "DownloadedFile": download_file_builder,
            "DownloadedArchive": download_archive_builder,
            "DownloadedGit": download_git_builder,
        }
    )


def exists(env) -> bool:

    return env.Detect("download")
