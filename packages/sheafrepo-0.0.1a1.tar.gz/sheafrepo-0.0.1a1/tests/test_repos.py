import unittest

from sheafrepo import RepoRecord, group_by_owner, inventory_summary, normalize_remote


class RepoTests(unittest.TestCase):
    def setUp(self) -> None:
        self.records = [
            RepoRecord("SheafLab", "SheafLab", "git@github.com:SheafLab/SheafLab.git", "main", "/repos/SheafLab"),
            RepoRecord("sheafview-python", "SheafLab", "https://github.com/SheafLab/sheafview-python.git", "main", "/repos/sheafview-python"),
            RepoRecord("demo", "pakkinlau", "https://github.com/pakkinlau/demo.git", "main", "/repos/demo"),
        ]

    def test_normalize_remote(self) -> None:
        self.assertEqual(normalize_remote(self.records[0].remote), "https://github.com/SheafLab/SheafLab")

    def test_group_by_owner(self) -> None:
        grouped = group_by_owner(self.records)
        self.assertEqual(sorted(grouped), ["SheafLab", "pakkinlau"])
        self.assertEqual([record.name for record in grouped["SheafLab"]], ["SheafLab", "sheafview-python"])

    def test_inventory_summary(self) -> None:
        summary = inventory_summary(self.records)
        self.assertEqual(summary["repo_count"], 3)
        self.assertEqual(summary["owner_count"], 2)


if __name__ == "__main__":
    unittest.main()

