# sheafrepo

`sheafrepo` is the official Python package namespace for lightweight repository
inventory helpers used by the SheafLab project.

This initial public release provides a focused surface: normalizing Git remotes,
describing repo records, grouping them by owner, and computing compact
inventory summaries for small repo sets.

## Install

```bash
pip install sheafrepo
```

## Usage

```python
from sheafrepo import RepoRecord, inventory_summary, normalize_remote

records = [
    RepoRecord("SheafLab", "SheafLab", "git@github.com:SheafLab/SheafLab.git", "main", "/repos/SheafLab"),
]

remote = normalize_remote(records[0].remote)
summary = inventory_summary(records)
```

## Status

- Project stage: pre-alpha
- Package scope: bootstrap repository-inventory utilities only
- Main project site: https://sheaflab.com

