from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RepoRecord:
    name: str
    owner: str
    remote: str
    branch: str
    path: str


def normalize_remote(remote: str) -> str:
    remote = remote.strip()
    if remote.startswith("git@github.com:"):
        remote = remote.replace("git@github.com:", "https://github.com/", 1)
    if remote.endswith(".git"):
        remote = remote[:-4]
    return remote


def group_by_owner(records: list[RepoRecord]) -> dict[str, list[RepoRecord]]:
    grouped: dict[str, list[RepoRecord]] = {}
    for record in records:
        grouped.setdefault(record.owner, []).append(record)
    for owner in grouped:
        grouped[owner] = sorted(grouped[owner], key=lambda record: record.name.lower())
    return grouped


def inventory_summary(records: list[RepoRecord]) -> dict[str, object]:
    grouped = group_by_owner(records)
    return {
        "repo_count": len(records),
        "owner_count": len(grouped),
        "owners": sorted(grouped),
        "normalized_remotes": [normalize_remote(record.remote) for record in records],
    }

