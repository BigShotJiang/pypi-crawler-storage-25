def project_info() -> dict[str, str]:
    return {
        "name": "sheafrepo",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafrepo-python",
    }

