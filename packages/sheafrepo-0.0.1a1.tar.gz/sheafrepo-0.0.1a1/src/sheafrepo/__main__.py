import json

from . import __version__
from .info import project_info


def main() -> None:
    print(json.dumps(project_info() | {"version": __version__}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

