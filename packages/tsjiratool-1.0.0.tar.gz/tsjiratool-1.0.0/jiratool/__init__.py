"""JiraTool — JIRA 变更监控与报告导出工具。"""

__version__ = "1.0.0"
__author__ = "hemin0721"
