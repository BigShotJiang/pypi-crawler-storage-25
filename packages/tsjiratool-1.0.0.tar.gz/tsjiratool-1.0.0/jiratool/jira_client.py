"""JIRA REST API 客户端，负责轮询 issues 并检测变更。"""
from __future__ import annotations

import json
import hashlib
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class JiraClient:
    def __init__(self, base_url: str, api_token: str, username: str = ""):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
        })
        self.session.verify = True
        self.username = username or self._fetch_current_user()

    def _fetch_current_user(self) -> str:
        try:
            r = self.session.get(f"{self.base_url}/rest/api/2/myself", timeout=15)
            r.raise_for_status()
            name = r.json().get("name", "")
            logger.info("JIRA 当前用户: %s", name)
            return name
        except Exception as e:
            logger.error("获取当前用户失败: %s", e)
            return ""

    def search_issues(self, jql: str, max_results: int = 50) -> List[Dict[str, Any]]:
        jql = jql.replace("%USERNAME%", self.username)
        try:
            r = self.session.get(
                f"{self.base_url}/rest/api/2/search",
                params={
                    "jql": jql,
                    "maxResults": max_results,
                    "fields": "summary,status,updated,assignee,reporter,priority,"
                              "issuetype,comment,resolution,labels",
                },
                timeout=30,
            )
            r.raise_for_status()
            return r.json().get("issues", [])
        except Exception as e:
            logger.error("JQL 查询失败: %s | %s", jql, e)
            return []

    def search_issues_by_date(self, start_date: str, end_date: str, max_results: int = 100) -> List[Dict[str, Any]]:
        """按日期范围搜索 (格式: YYYY-MM-DD)。"""
        jql = (
            '(assignee = "%s" OR reporter = "%s") '
            'AND updated >= "%s" AND updated <= "%s 23:59" '
            "ORDER BY updated DESC"
        ) % (self.username, self.username, start_date, end_date)
        return self._search_with_changelog(jql, max_results)

    def search_my_activity(self, start_date: str, end_date: str, max_results: int = 100) -> List[Dict[str, Any]]:
        """搜索我主动操作过的 issues（可能已不在我名下）。

        通过 status changed BY / assignee changed BY 查找操作记录。
        """
        jql_variants = [
            'status changed BY "%s" DURING ("%s", "%s 23:59") ORDER BY updated DESC'
            % (self.username, start_date, end_date),
            'assignee changed BY "%s" DURING ("%s", "%s 23:59") ORDER BY updated DESC'
            % (self.username, start_date, end_date),
        ]

        all_issues: Dict[str, Dict[str, Any]] = {}
        for jql in jql_variants:
            for iss in self._search_with_changelog(jql, max_results):
                all_issues.setdefault(iss["key"], iss)
        return list(all_issues.values())

    def _search_with_changelog(self, jql: str, max_results: int) -> List[Dict[str, Any]]:
        try:
            r = self.session.get(
                f"{self.base_url}/rest/api/2/search",
                params={
                    "jql": jql,
                    "maxResults": max_results,
                    "fields": "summary,status,updated,created,assignee,reporter,priority,"
                              "issuetype,comment,resolution,labels",
                    "expand": "changelog",
                },
                timeout=60,
            )
            r.raise_for_status()
            return r.json().get("issues", [])
        except Exception as e:
            logger.error("JQL 查询失败: %s | %s", jql[:120], e)
            return []

    def search_week_tasks(self, max_results: int = 100) -> List[Dict[str, Any]]:
        """搜索本周相关的所有 issues (分配给我 + 我操作过的)。"""
        jql_my = (
            '(assignee = "%s" OR reporter = "%s") '
            'AND updated >= startOfWeek() '
            'ORDER BY updated DESC'
        ) % (self.username, self.username)

        jql_activity = (
            '(status changed BY "%s" DURING (startOfWeek(), now()) '
            'OR assignee changed BY "%s" DURING (startOfWeek(), now())) '
            'ORDER BY updated DESC'
        ) % (self.username, self.username)

        all_issues: Dict[str, Dict[str, Any]] = {}
        for iss in self._search_with_changelog(jql_my, max_results):
            all_issues.setdefault(iss["key"], iss)
        for iss in self._search_with_changelog(jql_activity, max_results):
            all_issues.setdefault(iss["key"], iss)
        return list(all_issues.values())

    def get_issue(self, key: str) -> Optional[Dict[str, Any]]:
        try:
            r = self.session.get(
                f"{self.base_url}/rest/api/2/issue/{key}",
                params={"fields": "summary,status,updated,assignee,priority,comment,issuetype"},
                timeout=15,
            )
            r.raise_for_status()
            return r.json()
        except Exception as e:
            logger.error("获取 issue %s 失败: %s", key, e)
            return None


class ChangeDetector:
    """对比 JIRA issues 的快照，检测变更。"""

    def __init__(self, state_file: str):
        self.state_file = os.path.expanduser(state_file)
        self.prev_state: Dict[str, Dict[str, Any]] = self._load_state()

    def _load_state(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_state(self) -> None:
        Path(self.state_file).parent.mkdir(parents=True, exist_ok=True)
        with open(self.state_file, "w", encoding="utf-8") as f:
            json.dump(self.prev_state, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _snapshot(issue: Dict[str, Any]) -> Dict[str, Any]:
        f = issue.get("fields", {})
        comments = f.get("comment", {}).get("comments", [])
        last_comment_id = comments[-1]["id"] if comments else ""
        return {
            "status": f.get("status", {}).get("name", ""),
            "assignee": (f.get("assignee") or {}).get("name", ""),
            "priority": (f.get("priority") or {}).get("name", ""),
            "updated": f.get("updated", ""),
            "comment_count": len(comments),
            "last_comment_id": last_comment_id,
            "summary": f.get("summary", ""),
        }

    def detect_changes(self, issues: List[Dict[str, Any]], rules: dict) -> List[Dict[str, Any]]:
        changes: List[Dict[str, Any]] = []
        current_state: Dict[str, Dict[str, Any]] = {}

        for issue in issues:
            key = issue.get("key", "")
            snap = self._snapshot(issue)
            current_state[key] = snap
            prev = self.prev_state.get(key)

            if prev is None:
                changes.append({
                    "key": key,
                    "type": "new_issue",
                    "summary": snap["summary"],
                    "status": snap["status"],
                    "detail": "新 issue 出现在监控范围",
                })
                continue

            if rules.get("notify_on_status_change") and snap["status"] != prev.get("status"):
                changes.append({
                    "key": key,
                    "type": "status_change",
                    "summary": snap["summary"],
                    "status": snap["status"],
                    "detail": "%s → %s" % (prev.get("status", "?"), snap["status"]),
                })

            if rules.get("notify_on_new_comment") and snap["comment_count"] > prev.get("comment_count", 0):
                new_count = snap["comment_count"] - prev.get("comment_count", 0)
                changes.append({
                    "key": key,
                    "type": "new_comment",
                    "summary": snap["summary"],
                    "status": snap["status"],
                    "detail": "新增 %d 条评论" % new_count,
                })

            if rules.get("notify_on_assignee_change") and snap["assignee"] != prev.get("assignee"):
                changes.append({
                    "key": key,
                    "type": "assignee_change",
                    "summary": snap["summary"],
                    "status": snap["status"],
                    "detail": "指派人: %s → %s" % (prev.get("assignee", "?"), snap["assignee"]),
                })

            if rules.get("notify_on_priority_change") and snap["priority"] != prev.get("priority"):
                changes.append({
                    "key": key,
                    "type": "priority_change",
                    "summary": snap["summary"],
                    "status": snap["status"],
                    "detail": "优先级: %s → %s" % (prev.get("priority", "?"), snap["priority"]),
                })

        self.prev_state = current_state
        self._save_state()
        return changes
