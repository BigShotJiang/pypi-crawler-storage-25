"""CLI 模式：无界面后台轮询（可用于 crontab / systemd）。"""
from __future__ import annotations

import logging
import signal
import sys
import time
from pathlib import Path

import yaml

from .jira_client import JiraClient, ChangeDetector
from .notifiers import DesktopNotifier, FeishuNotifier, WechatNotifier

logger = logging.getLogger(__name__)
_running = True


def _sig_handler(signum, frame):
    global _running
    _running = False
    logger.info("收到退出信号，正在停止…")


def run_cli(config_path: str) -> None:
    global _running
    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)

    p = Path(config_path)
    if not p.is_file():
        print("配置文件不存在: %s" % config_path, file=sys.stderr)
        sys.exit(1)
    with open(p, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    log_cfg = cfg.get("logging", {})
    logging.basicConfig(
        level=getattr(logging, log_cfg.get("level", "INFO").upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_cfg.get("file", "jiratool.log"), encoding="utf-8"),
        ],
    )

    j = cfg.get("jira", {})
    client = JiraClient(j.get("base_url", ""), j.get("api_token", ""), j.get("username", ""))
    if not client.username:
        logger.error("无法连接 JIRA，请检查配置")
        sys.exit(1)

    detector = ChangeDetector(cfg.get("state_file", "~/.jiratool_state.json"))
    interval = int(j.get("poll_interval", 120))

    logger.info("CLI 模式启动, 用户=%s, 间隔=%ds", client.username, interval)

    while _running:
        try:
            jql_list = j.get("jql_filters", [])
            all_issues: dict = {}
            for jql in jql_list:
                for iss in client.search_issues(jql):
                    all_issues[iss["key"]] = iss

            rules = cfg.get("rules", {})
            changes = detector.detect_changes(list(all_issues.values()), rules)

            if changes:
                logger.info("检测到 %d 条变更", len(changes))
                base_url = j.get("base_url", "")
                n_cfg = cfg.get("notifications", {})
                if n_cfg.get("desktop", {}).get("enabled"):
                    DesktopNotifier().send_changes(changes, base_url)
                fs = n_cfg.get("feishu", {})
                if fs.get("enabled") and fs.get("webhook_url"):
                    FeishuNotifier(fs["webhook_url"], fs.get("secret", "")).send_changes(changes, base_url)
                wc = n_cfg.get("wechat", {})
                if wc.get("enabled") and wc.get("webhook_url"):
                    WechatNotifier(wc["webhook_url"]).send_changes(changes, base_url)
            else:
                logger.info("无新变更 (%d issues)", len(all_issues))
        except Exception:
            logger.exception("轮询异常")

        for _ in range(interval):
            if not _running:
                break
            time.sleep(1)

    logger.info("已停止")
