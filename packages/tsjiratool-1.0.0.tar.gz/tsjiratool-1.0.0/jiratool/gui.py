"""JIRA 变更监控工具 — PyQt GUI（托盘常驻 + 主窗口）。"""
from __future__ import annotations

import logging
import os
import queue
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import yaml
from PySide6 import QtCore, QtGui, QtWidgets

from .jira_client import JiraClient, ChangeDetector
from .notifiers import DesktopNotifier, FeishuNotifier, WechatNotifier
from .report_export import (
    generate_markdown_report,
    generate_csv_report,
    get_week_range,
    get_today,
)

logger = logging.getLogger(__name__)

CONFIG_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CFG = CONFIG_DIR / "config.yaml"


def _load_config(path: str | Path) -> dict:
    p = Path(path)
    if p.is_file():
        with open(p, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


def _save_config(path: str | Path, cfg: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(cfg, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


# ── Tray icon (SVG 内联避免外部文件依赖) ──────────────────────────
_TRAY_SVG = b"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
<rect rx="12" width="64" height="64" fill="#2563eb"/>
<text x="32" y="44" text-anchor="middle" fill="white"
  font-family="Arial" font-size="32" font-weight="bold">J</text>
</svg>"""


def _tray_icon() -> QtGui.QIcon:
    pm = QtGui.QPixmap(64, 64)
    pm.loadFromData(_TRAY_SVG, "SVG")
    return QtGui.QIcon(pm)


class MonitorWorker(QtCore.QObject):
    """后台轮询线程信号桥。"""
    changes_detected = QtCore.Signal(list)
    status_update = QtCore.Signal(str)
    issues_fetched = QtCore.Signal(list)


def _get_instances(cfg: dict) -> list:
    """从配置中获取 JIRA 实例列表（兼容旧单实例格式）。"""
    instances = cfg.get("jira_instances")
    if instances and isinstance(instances, list) and len(instances) > 0:
        return instances
    j = cfg.get("jira", {})
    if j and j.get("base_url"):
        inst = dict(j)
        inst.setdefault("name", _instance_label(j))
        return [inst]
    return []


def _instance_label(inst: dict) -> str:
    if inst.get("name"):
        return inst["name"]
    url = inst.get("base_url", "")
    from urllib.parse import urlparse
    host = urlparse(url).hostname or url
    return host


class JiraToolWindow(QtWidgets.QMainWindow):
    def __init__(self, config_path: str = ""):
        super().__init__()
        self.config_path = config_path or str(DEFAULT_CFG)
        self.cfg = _load_config(self.config_path)
        self.setWindowTitle("JIRA 变更监控工具")
        self.resize(960, 660)

        self._instances = _get_instances(self.cfg)
        self._jira_map: dict[str, JiraClient] = {}
        self._detector_map: dict[str, ChangeDetector] = {}
        self._jira: Optional[JiraClient] = None
        self._detector: Optional[ChangeDetector] = None
        self._poll_thread: Optional[threading.Thread] = None
        self._poll_running = False
        self._last_check_date: Optional[str] = None

        self._worker = MonitorWorker()
        self._worker.changes_detected.connect(self._on_changes)
        self._worker.status_update.connect(self._on_status)
        self._worker.issues_fetched.connect(self._on_issues_fetched)

        self._notifiers_cache: dict = {}

        self._build_ui()
        self._build_tray()
        self._apply_style()
        self._load_config_to_ui()

    # ── UI 构建 ──────────────────────────────────────────────────
    def _build_ui(self) -> None:
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)

        self.tabs = QtWidgets.QTabWidget()
        root.addWidget(self.tabs)

        # TAB 1: 监控面板
        self._build_monitor_tab()
        # TAB 2: 报告导出
        self._build_report_tab()
        # TAB 3: 设置
        self._build_settings_tab()

        self.lb_status = QtWidgets.QLabel("就绪")
        root.addWidget(self.lb_status)

    def _build_monitor_tab(self) -> None:
        w = QtWidgets.QWidget()
        self.tabs.addTab(w, "监控面板")
        lay = QtWidgets.QVBoxLayout(w)

        # 实例选择行
        inst_row = QtWidgets.QHBoxLayout()
        lay.addLayout(inst_row)
        inst_row.addWidget(QtWidgets.QLabel("JIRA 实例:"))
        self.cmb_instance = QtWidgets.QComboBox()
        self.cmb_instance.setMinimumWidth(180)
        self._refresh_instance_combo()
        inst_row.addWidget(self.cmb_instance)
        inst_row.addStretch()

        toolbar = QtWidgets.QHBoxLayout()
        lay.addLayout(toolbar)
        self.btn_start = QtWidgets.QPushButton("启动监控")
        self.btn_start.clicked.connect(self._toggle_monitor)
        toolbar.addWidget(self.btn_start)
        self.btn_refresh = QtWidgets.QPushButton("立即刷新")
        self.btn_refresh.clicked.connect(self._manual_refresh)
        toolbar.addWidget(self.btn_refresh)
        self.btn_week_tasks = QtWidgets.QPushButton("本周任务")
        self.btn_week_tasks.setToolTip("查询本周所有相关 Issue（包含我操作过的）")
        self.btn_week_tasks.clicked.connect(self._query_week_tasks)
        toolbar.addWidget(self.btn_week_tasks)
        self.btn_clear = QtWidgets.QPushButton("清空记录")
        self.btn_clear.setToolTip("清空当前的 Issue 列表和变更记录")
        self.btn_clear.clicked.connect(self._clear_all)
        toolbar.addWidget(self.btn_clear)
        toolbar.addStretch()
        self.lb_last_check = QtWidgets.QLabel("上次检查: -")
        toolbar.addWidget(self.lb_last_check)

        splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        lay.addWidget(splitter, 1)

        self.tbl_issues = QtWidgets.QTableWidget(0, 7)
        self.tbl_issues.setHorizontalHeaderLabels(["Issue", "类型", "标题", "状态", "优先级", "指派人", "更新时间"])
        self.tbl_issues.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.tbl_issues.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.tbl_issues.setAlternatingRowColors(True)
        self.tbl_issues.horizontalHeader().setStretchLastSection(True)
        self.tbl_issues.verticalHeader().setVisible(False)
        self.tbl_issues.doubleClicked.connect(self._on_issue_double_click)
        self.tbl_issues.setToolTip("双击 Issue 在浏览器中打开")
        splitter.addWidget(self.tbl_issues)

        self.txt_changes = QtWidgets.QPlainTextEdit()
        self.txt_changes.setReadOnly(True)
        self.txt_changes.setPlaceholderText("变更记录会显示在这里…")
        splitter.addWidget(self.txt_changes)
        splitter.setSizes([380, 200])

    def _build_report_tab(self) -> None:
        w = QtWidgets.QWidget()
        self.tabs.addTab(w, "报告导出")
        lay = QtWidgets.QVBoxLayout(w)

        form = QtWidgets.QFormLayout()
        lay.addLayout(form)

        self.cmb_report_type = QtWidgets.QComboBox()
        self.cmb_report_type.addItems(["日报", "周报", "自定义范围"])
        self.cmb_report_type.currentIndexChanged.connect(self._on_report_type_changed)
        form.addRow("报告类型:", self.cmb_report_type)

        today = QtCore.QDate.currentDate()
        min_date = today.addYears(-2)

        self.de_start = QtWidgets.QDateEdit(today)
        self.de_start.setCalendarPopup(True)
        self.de_start.setDisplayFormat("yyyy-MM-dd")
        self.de_start.setMinimumDate(min_date)
        self.de_start.setMaximumDate(today)
        form.addRow("开始日期:", self.de_start)

        self.de_end = QtWidgets.QDateEdit(today)
        self.de_end.setCalendarPopup(True)
        self.de_end.setDisplayFormat("yyyy-MM-dd")
        self.de_end.setMinimumDate(min_date)
        self.de_end.setMaximumDate(today)
        form.addRow("结束日期:", self.de_end)

        btn_row = QtWidgets.QHBoxLayout()
        lay.addLayout(btn_row)
        self.btn_gen_md = QtWidgets.QPushButton("生成 Markdown")
        self.btn_gen_md.clicked.connect(lambda: self._export_report("md"))
        btn_row.addWidget(self.btn_gen_md)
        self.btn_gen_csv = QtWidgets.QPushButton("生成 CSV")
        self.btn_gen_csv.clicked.connect(lambda: self._export_report("csv"))
        btn_row.addWidget(self.btn_gen_csv)
        btn_row.addStretch()

        self.txt_report = QtWidgets.QPlainTextEdit()
        self.txt_report.setReadOnly(True)
        self.txt_report.setPlaceholderText("报告内容将显示在这里，支持复制或另存…")
        lay.addWidget(self.txt_report, 1)

        self.btn_save_report = QtWidgets.QPushButton("另存为文件…")
        self.btn_save_report.clicked.connect(self._save_report_file)
        lay.addWidget(self.btn_save_report)

        self._on_report_type_changed(0)

    def _build_settings_tab(self) -> None:
        w = QtWidgets.QWidget()
        self.tabs.addTab(w, "设置")
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QtWidgets.QWidget()
        scroll.setWidget(inner)
        form = QtWidgets.QFormLayout(inner)

        vl = QtWidgets.QVBoxLayout(w)
        vl.addWidget(scroll)

        # JIRA 实例管理
        form.addRow(QtWidgets.QLabel("<b>JIRA 实例管理</b>"))
        inst_mgr = QtWidgets.QHBoxLayout()
        self.cmb_cfg_instance = QtWidgets.QComboBox()
        self.cmb_cfg_instance.setMinimumWidth(200)
        self.cmb_cfg_instance.currentIndexChanged.connect(self._on_cfg_instance_changed)
        inst_mgr.addWidget(self.cmb_cfg_instance)
        self.btn_add_inst = QtWidgets.QPushButton("+ 新增")
        self.btn_add_inst.setMaximumWidth(60)
        self.btn_add_inst.clicked.connect(self._add_instance)
        inst_mgr.addWidget(self.btn_add_inst)
        self.btn_del_inst = QtWidgets.QPushButton("- 删除")
        self.btn_del_inst.setMaximumWidth(60)
        self.btn_del_inst.clicked.connect(self._del_instance)
        inst_mgr.addWidget(self.btn_del_inst)
        form.addRow("实例:", inst_mgr)

        form.addRow(QtWidgets.QLabel(""))
        form.addRow(QtWidgets.QLabel("<b>JIRA 连接</b>"))
        self.ed_inst_name = QtWidgets.QLineEdit()
        self.ed_inst_name.setPlaceholderText("实例名称，如: ThunderX")
        form.addRow("名称:", self.ed_inst_name)
        self.ed_url = QtWidgets.QLineEdit()
        self.ed_url.setPlaceholderText("https://jira.example.com")
        form.addRow("Base URL:", self.ed_url)
        self.ed_token = QtWidgets.QLineEdit()
        self.ed_token.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ed_token.setPlaceholderText("Personal Access Token")
        form.addRow("API Token:", self.ed_token)
        self.ed_username = QtWidgets.QLineEdit()
        self.ed_username.setPlaceholderText("留空自动获取")
        form.addRow("用户名:", self.ed_username)
        self.sp_interval = QtWidgets.QSpinBox()
        self.sp_interval.setRange(30, 3600)
        self.sp_interval.setSuffix(" 秒")
        form.addRow("轮询间隔:", self.sp_interval)

        form.addRow(QtWidgets.QLabel(""))
        form.addRow(QtWidgets.QLabel("<b>桌面通知</b>"))
        self.chk_desktop = QtWidgets.QCheckBox("启用桌面通知")
        form.addRow(self.chk_desktop)

        form.addRow(QtWidgets.QLabel(""))
        form.addRow(QtWidgets.QLabel("<b>飞书通知</b>"))
        self.chk_feishu = QtWidgets.QCheckBox("启用飞书通知")
        form.addRow(self.chk_feishu)
        self.ed_feishu_url = QtWidgets.QLineEdit()
        self.ed_feishu_url.setPlaceholderText("飞书 Webhook URL")
        form.addRow("Webhook:", self.ed_feishu_url)
        self.ed_feishu_secret = QtWidgets.QLineEdit()
        self.ed_feishu_secret.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("签名密钥:", self.ed_feishu_secret)

        form.addRow(QtWidgets.QLabel(""))
        form.addRow(QtWidgets.QLabel("<b>企业微信通知</b>"))
        self.chk_wechat = QtWidgets.QCheckBox("启用企业微信通知")
        form.addRow(self.chk_wechat)
        self.ed_wechat_url = QtWidgets.QLineEdit()
        self.ed_wechat_url.setPlaceholderText("企业微信 Webhook URL")
        form.addRow("Webhook:", self.ed_wechat_url)

        form.addRow(QtWidgets.QLabel(""))
        form.addRow(QtWidgets.QLabel("<b>通知规则</b>"))
        self.chk_status = QtWidgets.QCheckBox("状态变更")
        self.chk_status.setChecked(True)
        form.addRow(self.chk_status)
        self.chk_comment = QtWidgets.QCheckBox("新评论")
        self.chk_comment.setChecked(True)
        form.addRow(self.chk_comment)
        self.chk_assignee = QtWidgets.QCheckBox("指派变更")
        self.chk_assignee.setChecked(True)
        form.addRow(self.chk_assignee)
        self.chk_priority = QtWidgets.QCheckBox("优先级变更")
        self.chk_priority.setChecked(True)
        form.addRow(self.chk_priority)

        btn_row = QtWidgets.QHBoxLayout()
        form.addRow(btn_row)
        self.btn_save_cfg = QtWidgets.QPushButton("保存配置")
        self.btn_save_cfg.clicked.connect(self._save_config)
        btn_row.addWidget(self.btn_save_cfg)
        self.btn_test_conn = QtWidgets.QPushButton("测试连接")
        self.btn_test_conn.clicked.connect(self._test_connection)
        btn_row.addWidget(self.btn_test_conn)

    # ── 系统托盘 ─────────────────────────────────────────────────
    def _build_tray(self) -> None:
        self.tray = QtWidgets.QSystemTrayIcon(_tray_icon(), self)
        menu = QtWidgets.QMenu()
        act_show = menu.addAction("显示主窗口")
        act_show.triggered.connect(self._show_from_tray)
        act_refresh = menu.addAction("立即刷新")
        act_refresh.triggered.connect(self._manual_refresh)
        menu.addSeparator()
        act_quit = menu.addAction("退出")
        act_quit.triggered.connect(self._quit_app)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _on_tray_activated(self, reason) -> None:
        if reason == QtWidgets.QSystemTrayIcon.Trigger:
            self._show_from_tray()

    def _show_from_tray(self) -> None:
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def _quit_app(self) -> None:
        self._poll_running = False
        self.tray.hide()
        QtWidgets.QApplication.quit()

    # ── 样式 ─────────────────────────────────────────────────────
    def _apply_style(self) -> None:
        self.setStyleSheet("""
            QMainWindow, QWidget { background-color: #f5f7fa; color: #1f2937; font-size: 13px; }
            QTabWidget::pane { border: 1px solid #d1d5db; top: -1px; }
            QTabBar::tab { background: #e5e7eb; border: 1px solid #d1d5db; padding: 6px 14px; margin-right: 2px; }
            QTabBar::tab:selected { background: #ffffff; font-weight: 600; }
            QPushButton { background-color: #2563eb; color: white; border: none; border-radius: 4px; padding: 6px 16px; }
            QPushButton:hover { background-color: #1d4ed8; }
            QPushButton:disabled { background-color: #93c5fd; }
            QLineEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit {
                background-color: #ffffff; border: 1px solid #d1d5db; border-radius: 4px; padding: 4px 8px; color: #1f2937;
            }
            QTableWidget { background-color: #ffffff; border: 1px solid #d1d5db; gridline-color: #e5e7eb; }
            QTableWidget::item { padding: 4px 8px; }
            QTableWidget::item:alternate { background-color: #f9fafb; }
            QTableWidget::item:selected { background-color: #dbeafe; color: #1e3a5f; }
            QHeaderView::section { background-color: #f3f4f6; color: #374151; padding: 5px; border: 1px solid #e5e7eb; font-weight: 600; }
            QCheckBox { spacing: 6px; }
            QLabel { color: #374151; }
            QGroupBox { border: 1px solid #d1d5db; border-radius: 6px; margin-top: 8px; padding-top: 6px; font-weight: 600; }
            QScrollArea { border: none; }
        """)

    # ── 实例管理 ─────────────────────────────────────────────────
    def _refresh_instance_combo(self) -> None:
        self.cmb_instance.blockSignals(True)
        self.cmb_instance.clear()
        for inst in self._instances:
            self.cmb_instance.addItem(_instance_label(inst))
        if not self._instances:
            self.cmb_instance.addItem("(未配置)")
        self.cmb_instance.blockSignals(False)

    def _refresh_cfg_instance_combo(self) -> None:
        self.cmb_cfg_instance.blockSignals(True)
        self.cmb_cfg_instance.clear()
        for inst in self._instances:
            self.cmb_cfg_instance.addItem(_instance_label(inst))
        if not self._instances:
            self.cmb_cfg_instance.addItem("(未配置)")
        self.cmb_cfg_instance.blockSignals(False)

    def _on_cfg_instance_changed(self, idx: int) -> None:
        if 0 <= idx < len(self._instances):
            inst = self._instances[idx]
            self.ed_inst_name.setText(inst.get("name", ""))
            self.ed_url.setText(inst.get("base_url", ""))
            self.ed_token.setText(inst.get("api_token", ""))
            self.ed_username.setText(inst.get("username", ""))
            self.sp_interval.setValue(int(inst.get("poll_interval", 120)))

    def _add_instance(self) -> None:
        name, ok = QtWidgets.QInputDialog.getText(self, "新增 JIRA 实例", "实例名称:")
        if ok and name.strip():
            new_inst = {
                "name": name.strip(),
                "base_url": "",
                "api_token": "",
                "username": "",
                "poll_interval": 120,
                "jql_filters": [
                    "assignee = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
                    "reporter = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
                ],
            }
            self._instances.append(new_inst)
            self._refresh_cfg_instance_combo()
            self._refresh_instance_combo()
            self.cmb_cfg_instance.setCurrentIndex(len(self._instances) - 1)

    def _del_instance(self) -> None:
        idx = self.cmb_cfg_instance.currentIndex()
        if 0 <= idx < len(self._instances):
            name = _instance_label(self._instances[idx])
            ret = QtWidgets.QMessageBox.question(
                self, "确认删除", "确定删除实例 \"%s\" 吗？" % name,
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            )
            if ret == QtWidgets.QMessageBox.Yes:
                self._instances.pop(idx)
                self._refresh_cfg_instance_combo()
                self._refresh_instance_combo()
                if self._instances:
                    self._on_cfg_instance_changed(0)

    def _save_instance_from_ui(self) -> None:
        """将当前 UI 的实例设置写回 self._instances。"""
        idx = self.cmb_cfg_instance.currentIndex()
        if 0 <= idx < len(self._instances):
            inst = self._instances[idx]
            inst["name"] = self.ed_inst_name.text().strip() or _instance_label(inst)
            inst["base_url"] = self.ed_url.text().strip()
            inst["api_token"] = self.ed_token.text().strip()
            inst["username"] = self.ed_username.text().strip()
            inst["poll_interval"] = self.sp_interval.value()
            inst.setdefault("jql_filters", [
                "assignee = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
                "reporter = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
            ])
            self._refresh_cfg_instance_combo()
            self._refresh_instance_combo()

    def _get_selected_instance(self) -> Optional[dict]:
        idx = self.cmb_instance.currentIndex()
        if 0 <= idx < len(self._instances):
            return self._instances[idx]
        return None

    # ── 配置读写 ─────────────────────────────────────────────────
    def _load_config_to_ui(self) -> None:
        self._instances = _get_instances(self.cfg)
        self._refresh_cfg_instance_combo()
        self._refresh_instance_combo()
        if self._instances:
            self._on_cfg_instance_changed(0)

        n = self.cfg.get("notifications", {})
        self.chk_desktop.setChecked(n.get("desktop", {}).get("enabled", True))
        fs = n.get("feishu", {})
        self.chk_feishu.setChecked(fs.get("enabled", False))
        self.ed_feishu_url.setText(fs.get("webhook_url", ""))
        self.ed_feishu_secret.setText(fs.get("secret", ""))
        wc = n.get("wechat", {})
        self.chk_wechat.setChecked(wc.get("enabled", False))
        self.ed_wechat_url.setText(wc.get("webhook_url", ""))

        r = self.cfg.get("rules", {})
        self.chk_status.setChecked(r.get("notify_on_status_change", True))
        self.chk_comment.setChecked(r.get("notify_on_new_comment", True))
        self.chk_assignee.setChecked(r.get("notify_on_assignee_change", True))
        self.chk_priority.setChecked(r.get("notify_on_priority_change", True))

    def _ui_to_config(self) -> dict:
        self._save_instance_from_ui()
        first_inst = self._instances[0] if self._instances else {}
        return {
            "jira_instances": self._instances,
            "jira": {
                "base_url": first_inst.get("base_url", ""),
                "api_token": first_inst.get("api_token", ""),
                "username": first_inst.get("username", ""),
                "poll_interval": first_inst.get("poll_interval", 120),
                "jql_filters": first_inst.get("jql_filters", [
                    "assignee = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
                    "reporter = %USERNAME% AND updated >= -1d ORDER BY updated DESC",
                ]),
            },
            "notifications": {
                "desktop": {"enabled": self.chk_desktop.isChecked(), "sound": True},
                "feishu": {
                    "enabled": self.chk_feishu.isChecked(),
                    "webhook_url": self.ed_feishu_url.text().strip(),
                    "secret": self.ed_feishu_secret.text().strip(),
                },
                "wechat": {
                    "enabled": self.chk_wechat.isChecked(),
                    "webhook_url": self.ed_wechat_url.text().strip(),
                },
            },
            "rules": {
                "notify_on_status_change": self.chk_status.isChecked(),
                "notify_on_new_comment": self.chk_comment.isChecked(),
                "notify_on_assignee_change": self.chk_assignee.isChecked(),
                "notify_on_priority_change": self.chk_priority.isChecked(),
                "ignore_issue_types": self.cfg.get("rules", {}).get("ignore_issue_types", []),
                "ignore_projects": self.cfg.get("rules", {}).get("ignore_projects", []),
            },
            "state_file": self.cfg.get("state_file", "~/.jiratool_state.json"),
            "logging": self.cfg.get("logging", {"level": "INFO", "file": "jiratool.log"}),
        }

    def _save_config(self) -> None:
        self.cfg = self._ui_to_config()
        try:
            _save_config(self.config_path, self.cfg)
            self.lb_status.setText("配置已保存")
            QtWidgets.QMessageBox.information(self, "成功", "配置已保存到:\n%s" % self.config_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "保存失败", str(e))

    def _test_connection(self) -> None:
        url = self.ed_url.text().strip()
        token = self.ed_token.text().strip()
        name = self.ed_inst_name.text().strip() or "?"
        if not url or not token:
            QtWidgets.QMessageBox.warning(self, "提示", "请填写 JIRA URL 和 Token")
            return
        self.btn_test_conn.setEnabled(False)
        self.btn_test_conn.setText("测试中…")

        def job():
            try:
                client = JiraClient(url, token, self.ed_username.text().strip())
                if client.username:
                    self._worker.status_update.emit("[%s] 连接成功! 用户: %s" % (name, client.username))
                else:
                    self._worker.status_update.emit("[%s] 连接失败: 无法获取用户信息" % name)
            except Exception as e:
                self._worker.status_update.emit("[%s] 连接失败: %s" % (name, e))

        threading.Thread(target=job, daemon=True).start()

    # ── 监控逻辑 ─────────────────────────────────────────────────
    def _ensure_jira(self, inst: Optional[dict] = None) -> bool:
        """确保当前选中的 JIRA 实例已连接。"""
        if inst is None:
            inst = self._get_selected_instance()
        if not inst:
            QtWidgets.QMessageBox.warning(self, "提示", "请先在设置中配置 JIRA 实例")
            self.tabs.setCurrentIndex(2)
            return False
        url = inst.get("base_url", "")
        token = inst.get("api_token", "")
        if not url or not token:
            QtWidgets.QMessageBox.warning(self, "提示", "当前实例缺少 URL 或 Token，请检查设置")
            self.tabs.setCurrentIndex(2)
            return False
        inst_key = url
        if inst_key not in self._jira_map:
            self._jira_map[inst_key] = JiraClient(url, token, inst.get("username", ""))
            state_base = self.cfg.get("state_file", "~/.jiratool_state.json")
            state_file = state_base.replace(".json", f"_{inst.get('name', 'default')}.json") if len(self._instances) > 1 else state_base
            self._detector_map[inst_key] = ChangeDetector(state_file)
        self._jira = self._jira_map[inst_key]
        self._detector = self._detector_map[inst_key]
        return True

    def _toggle_monitor(self) -> None:
        if self._poll_running:
            self._poll_running = False
            self.btn_start.setText("启动监控")
            self.lb_status.setText("监控已停止")
            return
        self.cfg = self._ui_to_config()
        if not self._ensure_jira():
            return
        self._poll_running = True
        self.btn_start.setText("停止监控")
        self.lb_status.setText("监控运行中…")
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()

    def _poll_loop(self) -> None:
        interval = self.cfg.get("jira", {}).get("poll_interval", 120)
        while self._poll_running:
            self._do_check()
            for _ in range(interval):
                if not self._poll_running:
                    return
                time.sleep(1)

    def _manual_refresh(self) -> None:
        self.cfg = self._ui_to_config()
        if not self._ensure_jira():
            return
        threading.Thread(target=self._do_check, daemon=True).start()

    def _do_check(self) -> None:
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            if self._last_check_date and self._last_check_date != today:
                QtCore.QMetaObject.invokeMethod(
                    self, "_clear_all", QtCore.Qt.QueuedConnection)
            self._last_check_date = today

            inst = self._get_selected_instance()
            inst_name = _instance_label(inst) if inst else "?"
            self._worker.status_update.emit("[%s] 正在检查…" % inst_name)
            jql_list = (inst or {}).get("jql_filters", self.cfg.get("jira", {}).get("jql_filters", []))
            all_issues: dict = {}
            for jql in jql_list:
                for iss in self._jira.search_issues(jql):
                    all_issues[iss["key"]] = iss
            issues = list(all_issues.values())

            self._worker.issues_fetched.emit(issues)

            rules = self.cfg.get("rules", {})
            changes = self._detector.detect_changes(issues, rules)

            now = datetime.now().strftime("%H:%M:%S")
            self._worker.status_update.emit("[%s] 检查完成 (%s), %d issues, %d 变更" % (inst_name, now, len(issues), len(changes)))

            if changes:
                self._worker.changes_detected.emit(changes)
                self._send_notifications(changes)
        except Exception as e:
            self._worker.status_update.emit("检查失败: %s" % e)
            logger.exception("检查异常")

    def _query_week_tasks(self) -> None:
        """查询本周所有相关 Issue。"""
        self.cfg = self._ui_to_config()
        if not self._ensure_jira():
            return
        inst = self._get_selected_instance()
        inst_name = _instance_label(inst) if inst else "?"
        self.btn_week_tasks.setEnabled(False)
        self.btn_week_tasks.setText("查询中…")

        def job():
            try:
                self._worker.status_update.emit("[%s] 正在查询本周任务…" % inst_name)
                issues = self._jira.search_week_tasks()
                self._worker.issues_fetched.emit(issues)
                now = datetime.now().strftime("%H:%M:%S")
                self._worker.status_update.emit(
                    "[%s] 本周任务: %d issues (%s)" % (inst_name, len(issues), now)
                )
            except Exception as e:
                self._worker.status_update.emit("查询本周任务失败: %s" % e)
                logger.exception("本周任务查询异常")

        threading.Thread(target=job, daemon=True).start()
        QtCore.QTimer.singleShot(800, lambda: (
            self.btn_week_tasks.setEnabled(True),
            self.btn_week_tasks.setText("本周任务"),
        ))

    def _send_notifications(self, changes: list) -> None:
        inst = self._get_selected_instance()
        base_url = (inst or {}).get("base_url", self.cfg.get("jira", {}).get("base_url", ""))
        n_cfg = self.cfg.get("notifications", {})

        if n_cfg.get("desktop", {}).get("enabled"):
            DesktopNotifier(sound=n_cfg.get("desktop", {}).get("sound", True)).send_changes(changes, base_url)

        fs = n_cfg.get("feishu", {})
        if fs.get("enabled") and fs.get("webhook_url"):
            FeishuNotifier(fs["webhook_url"], fs.get("secret", "")).send_changes(changes, base_url)

        wc = n_cfg.get("wechat", {})
        if wc.get("enabled") and wc.get("webhook_url"):
            WechatNotifier(wc["webhook_url"]).send_changes(changes, base_url)

    # ── UI 更新槽函数 ────────────────────────────────────────────
    def _on_status(self, msg: str) -> None:
        self.lb_status.setText(msg)
        self.lb_last_check.setText("上次: %s" % datetime.now().strftime("%H:%M:%S"))
        self.btn_test_conn.setEnabled(True)
        self.btn_test_conn.setText("测试连接")

    def _on_changes(self, changes: list) -> None:
        type_label = {
            "new_issue": "新 Issue",
            "status_change": "状态变更",
            "new_comment": "新评论",
            "assignee_change": "指派变更",
            "priority_change": "优先级变更",
        }
        ts = datetime.now().strftime("%H:%M:%S")
        for c in changes:
            label = type_label.get(c["type"], c["type"])
            line = "[%s] [%s] %s: %s — %s" % (ts, label, c["key"], c["summary"][:40], c["detail"])
            self.txt_changes.appendPlainText(line)
        bar = self.txt_changes.verticalScrollBar()
        bar.setValue(bar.maximum())

        self.tray.showMessage(
            "JIRA 变更 (%d)" % len(changes),
            "\n".join("[%s] %s" % (c["key"], c["detail"]) for c in changes[:5]),
            QtWidgets.QSystemTrayIcon.Information,
            5000,
        )

    def _on_issues_fetched(self, issues: list) -> None:
        self.tbl_issues.setRowCount(len(issues))
        for i, iss in enumerate(issues):
            key = iss.get("key", "")
            f = iss.get("fields", {})
            vals = [
                key,
                f.get("issuetype", {}).get("name", ""),
                f.get("summary", "")[:60],
                f.get("status", {}).get("name", ""),
                (f.get("priority") or {}).get("name", ""),
                (f.get("assignee") or {}).get("displayName", ""),
                f.get("updated", "")[:16],
            ]
            for j, v in enumerate(vals):
                item = QtWidgets.QTableWidgetItem(str(v))
                if j == 0:
                    item.setForeground(QtGui.QColor("#2563eb"))
                    font = item.font()
                    font.setUnderline(True)
                    item.setFont(font)
                elif j == 3:
                    status = str(v).lower()
                    if status in ("done", "closed", "resolved"):
                        item.setForeground(QtGui.QColor("#16a34a"))
                    elif status in ("in progress", "进行中"):
                        item.setForeground(QtGui.QColor("#2563eb"))
                self.tbl_issues.setItem(i, j, item)
        self.tbl_issues.resizeColumnsToContents()

    def _on_issue_double_click(self, index) -> None:
        """双击 Issue 行 → 在浏览器中打开。"""
        row = index.row()
        key_item = self.tbl_issues.item(row, 0)
        if not key_item:
            return
        key = key_item.text().strip()
        if not key:
            return
        inst = self._get_selected_instance()
        base_url = (inst or {}).get("base_url", self.cfg.get("jira", {}).get("base_url", "")).rstrip("/")
        if base_url:
            import webbrowser
            url = f"{base_url}/browse/{key}"
            webbrowser.open(url)
            self.lb_status.setText("已在浏览器中打开: %s" % key)
        else:
            self.lb_status.setText("未配置 JIRA URL，无法打开")

    @QtCore.Slot()
    def _clear_all(self) -> None:
        """清空 Issue 列表和变更记录。"""
        self.tbl_issues.setRowCount(0)
        self.txt_changes.clear()
        self.lb_status.setText("列表已清空")

    # ── 报告导出 ─────────────────────────────────────────────────
    def _on_report_type_changed(self, idx: int) -> None:
        today = QtCore.QDate.currentDate()
        self.de_start.setMaximumDate(today)
        self.de_end.setMaximumDate(today)
        if idx == 0:
            self.de_start.setDate(today)
            self.de_end.setDate(today)
            self.de_start.setEnabled(False)
            self.de_end.setEnabled(False)
        elif idx == 1:
            monday = today.addDays(-today.dayOfWeek() + 1)
            end = min(monday.addDays(6), today)
            self.de_start.setDate(monday)
            self.de_end.setDate(end)
            self.de_start.setEnabled(False)
            self.de_end.setEnabled(False)
        else:
            self.de_start.setDate(today.addDays(-6))
            self.de_end.setDate(today)
            self.de_start.setEnabled(True)
            self.de_end.setEnabled(True)

    def _export_report(self, fmt: str) -> None:
        self.cfg = self._ui_to_config()
        if not self._ensure_jira():
            return
        start_qd = self.de_start.date()
        end_qd = self.de_end.date()
        if start_qd > end_qd:
            QtWidgets.QMessageBox.warning(self, "日期错误", "开始日期不能晚于结束日期")
            return
        start = start_qd.toString("yyyy-MM-dd")
        end = end_qd.toString("yyyy-MM-dd")
        self.btn_gen_md.setEnabled(False)
        self.btn_gen_csv.setEnabled(False)
        inst = self._get_selected_instance()
        inst_name = _instance_label(inst) if inst else "?"
        self.txt_report.setPlainText("[%s] 正在查询 JIRA 数据 (%s ~ %s)…" % (inst_name, start, end))

        def job():
            try:
                issues = self._jira.search_issues_by_date(start, end)
                my_activity = self._jira.search_my_activity(start, end)
                base_url = (inst or {}).get("base_url", "")
                username = self._jira.username
                rtype = self.cmb_report_type.currentText()
                if fmt == "md":
                    text = generate_markdown_report(
                        issues, start, end, username, rtype, base_url,
                        my_activity_issues=my_activity,
                    )
                else:
                    all_issues = list({iss["key"]: iss for iss in issues + my_activity}.values())
                    text = generate_csv_report(all_issues, start, end)
                total = len(issues) + len([i for i in my_activity if i["key"] not in {x["key"] for x in issues}])
                self._worker.status_update.emit("[%s] 报告完成: %d issues (名下%d + 参与%d)" % (inst_name, total, len(issues), total - len(issues)))
                QtCore.QMetaObject.invokeMethod(
                    self.txt_report, "setPlainText", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, text)
                )
            except Exception as e:
                QtCore.QMetaObject.invokeMethod(
                    self.txt_report, "setPlainText", QtCore.Qt.QueuedConnection, QtCore.Q_ARG(str, "错误: %s" % e)
                )
            finally:
                self._worker.status_update.emit("就绪")

        threading.Thread(target=job, daemon=True).start()
        QtCore.QTimer.singleShot(500, lambda: (self.btn_gen_md.setEnabled(True), self.btn_gen_csv.setEnabled(True)))

    def _save_report_file(self) -> None:
        text = self.txt_report.toPlainText()
        if not text.strip():
            QtWidgets.QMessageBox.information(self, "提示", "请先生成报告")
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "另存报告", "", "Markdown (*.md);;CSV (*.csv);;All Files (*)"
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            self.lb_status.setText("报告已保存: %s" % path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "保存失败", str(e))

    # ── 关闭行为：最小化到托盘 ───────────────────────────────────
    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        event.ignore()
        self.hide()
        self.tray.showMessage("JIRA 监控", "已最小化到系统托盘，继续运行中", QtWidgets.QSystemTrayIcon.Information, 2000)


def run_gui(config_path: str = "") -> None:
    app = QtWidgets.QApplication.instance()
    owns = app is None
    if app is None:
        app = QtWidgets.QApplication([])
    app.setQuitOnLastWindowClosed(False)
    win = JiraToolWindow(config_path)
    win.show()
    if owns:
        app.exec()
