"""通知模块：飞书、企业微信、桌面通知。"""
from __future__ import annotations

import hashlib
import hmac
import base64
import json
import logging
import platform
import subprocess
import time
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

TYPE_LABEL = {
    "new_issue": "新 Issue",
    "status_change": "状态变更",
    "new_comment": "新评论",
    "assignee_change": "指派变更",
    "priority_change": "优先级变更",
}


def _format_changes_text(changes: List[Dict[str, Any]], jira_base_url: str) -> str:
    lines = ["JIRA 变更通知 (%d 条)\n" % len(changes)]
    for c in changes:
        key = c["key"]
        label = TYPE_LABEL.get(c["type"], c["type"])
        url = f"{jira_base_url}/browse/{key}"
        lines.append(f"[{label}] {key}: {c['summary']}")
        lines.append(f"  {c['detail']}")
        lines.append(f"  {url}\n")
    return "\n".join(lines)


class DesktopNotifier:
    def __init__(self, sound: bool = True):
        self.sound = sound
        self.system = platform.system()

    def notify(self, title: str, body: str) -> bool:
        try:
            if self.system == "Linux":
                cmd = ["notify-send", "-u", "normal", title, body]
                if self.sound:
                    cmd.extend(["-h", "string:sound-name:message-new-instant"])
                subprocess.run(cmd, timeout=5, check=False)
                return True
            elif self.system == "Darwin":
                script = 'display notification "%s" with title "%s"%s' % (
                    body.replace('"', '\\"'),
                    title.replace('"', '\\"'),
                    ' sound name "default"' if self.sound else "",
                )
                subprocess.run(["osascript", "-e", script], timeout=5, check=False)
                return True
            else:
                logger.warning("桌面通知不支持当前系统: %s", self.system)
                return False
        except Exception as e:
            logger.error("桌面通知发送失败: %s", e)
            return False

    def send_changes(self, changes: List[Dict[str, Any]], jira_base_url: str) -> None:
        if not changes:
            return
        for c in changes:
            label = TYPE_LABEL.get(c["type"], c["type"])
            title = f"JIRA {label}"
            body = f"[{c['key']}] {c['summary']}\n{c['detail']}"
            self.notify(title, body)


class FeishuNotifier:
    def __init__(self, webhook_url: str, secret: str = ""):
        self.webhook_url = webhook_url
        self.secret = secret

    def _gen_sign(self) -> dict:
        if not self.secret:
            return {}
        timestamp = str(int(time.time()))
        string_to_sign = f"{timestamp}\n{self.secret}"
        hmac_code = hmac.new(
            string_to_sign.encode("utf-8"), b"", digestmod=hashlib.sha256
        ).digest()
        sign = base64.b64encode(hmac_code).decode("utf-8")
        return {"timestamp": timestamp, "sign": sign}

    def send_changes(self, changes: List[Dict[str, Any]], jira_base_url: str) -> bool:
        if not self.webhook_url or not changes:
            return False
        text = _format_changes_text(changes, jira_base_url)
        payload = {"msg_type": "text", "content": {"text": text}}
        payload.update(self._gen_sign())
        try:
            r = requests.post(self.webhook_url, json=payload, timeout=10)
            if r.status_code == 200:
                resp = r.json()
                if resp.get("code") == 0 or resp.get("StatusCode") == 0:
                    logger.info("飞书通知发送成功 (%d 条变更)", len(changes))
                    return True
                logger.warning("飞书通知响应异常: %s", resp)
            else:
                logger.error("飞书通知 HTTP %d: %s", r.status_code, r.text[:200])
            return False
        except Exception as e:
            logger.error("飞书通知发送失败: %s", e)
            return False


class WechatNotifier:
    def __init__(self, webhook_url: str):
        self.webhook_url = webhook_url

    def send_changes(self, changes: List[Dict[str, Any]], jira_base_url: str) -> bool:
        if not self.webhook_url or not changes:
            return False
        text = _format_changes_text(changes, jira_base_url)
        payload = {"msgtype": "text", "text": {"content": text}}
        try:
            r = requests.post(self.webhook_url, json=payload, timeout=10)
            if r.status_code == 200:
                resp = r.json()
                if resp.get("errcode") == 0:
                    logger.info("企业微信通知发送成功 (%d 条变更)", len(changes))
                    return True
                logger.warning("企业微信响应异常: %s", resp)
            else:
                logger.error("企业微信通知 HTTP %d: %s", r.status_code, r.text[:200])
            return False
        except Exception as e:
            logger.error("企业微信通知发送失败: %s", e)
            return False
