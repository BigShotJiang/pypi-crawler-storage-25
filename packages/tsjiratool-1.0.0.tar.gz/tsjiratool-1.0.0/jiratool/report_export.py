"""JIRA 日报/周报导出模块：Markdown + CSV 格式。"""
from __future__ import annotations

import csv
import io
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

TYPE_CN = {
    "Bug": "缺陷",
    "Story": "需求",
    "Task": "任务",
    "Feature": "功能",
    "Development": "开发",
    "Sub-task": "子任务",
}


def _safe(v: Any, default: str = "") -> str:
    return str(v) if v else default


def _parse_changes_in_range(issue: dict, start: str, end: str) -> List[Dict[str, str]]:
    """从 issue 的 changelog 中提取指定日期范围内的变更记录。"""
    records = []
    changelog = issue.get("changelog", {}).get("histories", [])
    for hist in changelog:
        created = hist.get("created", "")[:10]
        if start <= created <= end:
            author = hist.get("author", {}).get("displayName", "")
            for item in hist.get("items", []):
                records.append({
                    "time": hist.get("created", "")[:16],
                    "author": author,
                    "field": item.get("field", ""),
                    "from": _safe(item.get("fromString")),
                    "to": _safe(item.get("toString")),
                })
    return records


def _extract_comments_in_range(issue: dict, start: str, end: str) -> List[Dict[str, str]]:
    """提取日期范围内的评论。"""
    records = []
    comments = issue.get("fields", {}).get("comment", {}).get("comments", [])
    for c in comments:
        created = c.get("created", "")[:10]
        if start <= created <= end:
            records.append({
                "time": c.get("created", "")[:16],
                "author": c.get("author", {}).get("displayName", ""),
                "body": c.get("body", "")[:200].replace("\n", " ").replace("|", "/"),
            })
    return records


def _render_issue_table(
    issues: List[Dict[str, Any]], jira_base_url: str, start_idx: int = 1,
) -> List[str]:
    lines = [
        "| # | Issue | 类型 | 标题 | 状态 | 优先级 | 最后更新 |",
        "|---|---|---|---|---|---|---|",
    ]
    for idx, iss in enumerate(issues, start_idx):
        key = iss.get("key", "")
        f = iss.get("fields", {})
        summary = f.get("summary", "").replace("|", "/")
        itype = f.get("issuetype", {}).get("name", "")
        status = f.get("status", {}).get("name", "")
        priority = (f.get("priority") or {}).get("name", "")
        updated = f.get("updated", "")[:16]
        link = f"[{key}]({jira_base_url}/browse/{key})" if jira_base_url else key
        lines.append(
            f"| {idx} | {link} | {TYPE_CN.get(itype, itype)} | {summary[:50]} | {status} | {priority} | {updated} |"
        )
    return lines


def _render_issue_details(
    issues: List[Dict[str, Any]], start_date: str, end_date: str,
) -> List[str]:
    lines = []
    for iss in issues:
        key = iss.get("key", "")
        f = iss.get("fields", {})
        summary = f.get("summary", "")
        lines.append(f"### {key}: {summary}")
        lines.append("")

        changes = _parse_changes_in_range(iss, start_date, end_date)
        if changes:
            lines.append("**操作记录:**")
            lines.append("")
            lines.append("| 时间 | 操作人 | 字段 | 变更前 | 变更后 |")
            lines.append("|---|---|---|---|---|")
            for c in changes:
                lines.append(
                    "| %s | %s | %s | %s | %s |"
                    % (c["time"], c["author"], c["field"], c["from"][:30], c["to"][:30])
                )
            lines.append("")

        comments = _extract_comments_in_range(iss, start_date, end_date)
        if comments:
            lines.append("**评论:**")
            lines.append("")
            for c in comments:
                lines.append(f"- [{c['time']}] **{c['author']}**: {c['body'][:150]}")
            lines.append("")

        if not changes and not comments:
            lines.append("_该周期内无变更记录_")
            lines.append("")
    return lines


def generate_markdown_report(
    issues: List[Dict[str, Any]],
    start_date: str,
    end_date: str,
    username: str = "",
    report_type: str = "日报",
    jira_base_url: str = "",
    my_activity_issues: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """生成 Markdown 格式的 JIRA 工作报告。

    Args:
        issues: 分配给我的 / 我报告的 issues
        my_activity_issues: 我主动操作过但可能已不在我名下的 issues（可选）
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    assigned_keys = {iss.get("key") for iss in issues}
    extra = [iss for iss in (my_activity_issues or []) if iss.get("key") not in assigned_keys]
    total = len(issues) + len(extra)

    lines = [
        f"# JIRA {report_type}",
        "",
        "| 项目 | 内容 |",
        "|---|---|",
        f"| **报告人** | {username} |",
        f"| **报告周期** | {start_date} ~ {end_date} |",
        f"| **生成时间** | {now} |",
        f"| **Issue 总数** | {total} (名下 {len(issues)} + 参与 {len(extra)}) |",
        "",
    ]

    lines.append("## 一、分配给我的 Issue (%d)" % len(issues))
    lines.append("")
    lines.extend(_render_issue_table(issues, jira_base_url, 1))
    lines.append("")

    if extra:
        lines.append("## 二、我主动操作 / 参与的 Issue (%d)" % len(extra))
        lines.append("")
        lines.append("> 以下 issue 不在我名下，但我在该周期内有状态变更、评论等操作记录。")
        lines.append("")
        lines.extend(_render_issue_table(extra, jira_base_url, len(issues) + 1))
        lines.append("")

    lines.append("## %s、变更详情 — 名下 Issue" % ("二" if not extra else "三"))
    lines.append("")
    lines.extend(_render_issue_details(issues, start_date, end_date))

    if extra:
        lines.append("## 四、变更详情 — 参与的 Issue")
        lines.append("")
        lines.extend(_render_issue_details(extra, start_date, end_date))

    lines.append("---")
    lines.append(f"_由 JiraTool 自动生成 | {now}_")
    return "\n".join(lines)


def generate_csv_report(
    issues: List[Dict[str, Any]],
    start_date: str,
    end_date: str,
) -> str:
    """生成 CSV 格式的 JIRA 工作报告。"""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Issue", "类型", "标题", "状态", "优先级", "指派人", "创建时间", "最后更新", "变更数", "评论数"])

    for iss in issues:
        key = iss.get("key", "")
        f = iss.get("fields", {})
        changes = _parse_changes_in_range(iss, start_date, end_date)
        comments = _extract_comments_in_range(iss, start_date, end_date)
        writer.writerow([
            key,
            f.get("issuetype", {}).get("name", ""),
            f.get("summary", ""),
            f.get("status", {}).get("name", ""),
            (f.get("priority") or {}).get("name", ""),
            (f.get("assignee") or {}).get("displayName", ""),
            f.get("created", "")[:10],
            f.get("updated", "")[:16],
            len(changes),
            len(comments),
        ])

    return output.getvalue()


def get_week_range(dt: Optional[datetime] = None) -> tuple:
    """返回给定日期所在周的周一和周日日期字符串。"""
    dt = dt or datetime.now()
    monday = dt - timedelta(days=dt.weekday())
    sunday = monday + timedelta(days=6)
    return monday.strftime("%Y-%m-%d"), sunday.strftime("%Y-%m-%d")


def get_today() -> str:
    return datetime.now().strftime("%Y-%m-%d")
