"""支持 `python -m jiratool` 方式启动。"""
import argparse
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(
        prog="jiratool",
        description="JIRA 变更监控与报告导出工具",
    )
    parser.add_argument(
        "-c", "--config", default="",
        help="配置文件路径 (默认: 当前目录下的 config.yaml)",
    )
    parser.add_argument(
        "--no-gui", action="store_true",
        help="CLI 模式运行（无界面，适合 crontab/systemd）",
    )
    parser.add_argument(
        "--version", action="store_true",
        help="显示版本号",
    )
    args = parser.parse_args()

    if args.version:
        from jiratool import __version__
        print("jiratool %s" % __version__)
        sys.exit(0)

    config_path = args.config or str(Path.cwd() / "config.yaml")

    if args.no_gui:
        from jiratool.cli import run_cli
        run_cli(config_path)
    else:
        from jiratool.gui import run_gui
        run_gui(config_path)


if __name__ == "__main__":
    main()
