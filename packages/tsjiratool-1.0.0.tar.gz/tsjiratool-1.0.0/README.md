# JiraTool

JIRA 变更监控与报告导出工具。支持多实例管理、飞书/企业微信/桌面通知、日报/周报 Markdown/CSV 导出。

## 安装

```bash
pip install jiratool
```

从源码安装:

```bash
git clone <repo-url>
cd jiratool
pip install .
```

## 使用

### GUI 模式（默认）

```bash
jiratool
# 或
python -m jiratool
```

### CLI 模式（无界面后台轮询）

```bash
jiratool --no-gui -c /path/to/config.yaml
```

### 配置

首次运行前，在工作目录创建 `config.yaml`（参考 `config.yaml.example`）:

```yaml
jira_instances:
  - name: "MyJira"
    base_url: "https://jira.example.com"
    api_token: "YOUR_TOKEN"
    username: "your_username"
    poll_interval: 120
    jql_filters:
      - "assignee = %USERNAME% AND updated >= -1d ORDER BY updated DESC"
```

## 功能

- 多 JIRA 实例管理
- 实时变更监控（状态、评论、指派、优先级）
- 桌面通知 (Linux notify-send / macOS osascript)
- 飞书 Webhook 通知
- 企业微信 Webhook 通知
- 日报/周报/自定义范围报告导出（Markdown / CSV）
- 本周任务一键查询
- 双击 Issue 直接跳转浏览器
- 系统托盘常驻

## 依赖

- Python >= 3.9
- PySide6 >= 6.5.0
- requests >= 2.28.0
- PyYAML >= 6.0
- schedule >= 1.2.0

## License

MIT
