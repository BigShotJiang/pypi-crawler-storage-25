"""Health check endpoint."""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path

from fastapi import APIRouter, Request

router = APIRouter(tags=["health"])
log = logging.getLogger(__name__)

# Cached PyPI version check (refreshed at most every 6 hours)
_pypi_cache: dict[str, object] = {"version": None, "checked_at": 0.0}
_PYPI_CHECK_INTERVAL = 6 * 3600  # seconds


def _get_version() -> str:
    # Installed package metadata (works from pip install)
    try:
        from importlib.metadata import version
        return version("agntspace")
    except Exception:
        pass
    # Dev repo fallback (works from source checkout)
    try:
        pyproject = Path(__file__).resolve().parents[4] / "pyproject.toml"
        text = pyproject.read_text(encoding="utf-8")
        m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "dev"


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse '1.12.0' into (1, 12, 0) for comparison."""
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


async def _check_pypi_latest() -> str | None:
    """Check PyPI for the latest agntspace version (cached)."""
    now = time.time()
    if (
        _pypi_cache["version"] is not None
        and now - float(_pypi_cache["checked_at"]) < _PYPI_CHECK_INTERVAL
    ):
        return _pypi_cache["version"]  # type: ignore[return-value]

    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get("https://pypi.org/pypi/agntspace/json")
            if resp.status_code == 200:
                data = resp.json()
                latest = data.get("info", {}).get("version")
                if latest:
                    _pypi_cache["version"] = latest
                    _pypi_cache["checked_at"] = now
                    return latest
    except Exception:
        pass
    return _pypi_cache.get("version")  # type: ignore[return-value]


@router.get("/health")
async def health(request: Request) -> dict:
    setup_mode = getattr(request.app.state, "setup_mode", False)
    return {"status": "ok", "version": _get_version(), "setup_mode": setup_mode}


@router.get("/version")
async def version_check() -> dict:
    """Check if a newer version is available on PyPI."""
    current = _get_version()
    latest = await _check_pypi_latest()

    update_available = False
    if latest and current != "dev":
        update_available = _parse_version(latest) > _parse_version(current)

    return {
        "current": current,
        "latest": latest,
        "update_available": update_available,
    }
