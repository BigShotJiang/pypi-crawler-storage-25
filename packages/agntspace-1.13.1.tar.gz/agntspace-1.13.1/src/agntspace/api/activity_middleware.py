"""Activity awareness middleware — logs every successful mutating user action.

Implements Architectural Requirement #13 (AGENT AWARENESS OF MANUAL USER ACTIONS).

Anything a user can do by hand through the REST API (which the UI and CLI both
call) must emit a structured event through ActivityLogger so the agent's world
model stays complete. This middleware catches every successful write request
(POST/PUT/PATCH/DELETE with 2xx response) and records it.

Categories:
    user            — generic manual action (creates, edits, settings changes)
    user_override   — user corrected or reversed an agent decision (rejections,
                      unapprovals, contract edits, emergency stops)

Exempt paths: health checks, polling endpoints, webhooks, and anything already
logged by a dedicated service hook (chat, journal writes, memory generation).
"""

from __future__ import annotations

import logging

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

log = logging.getLogger(__name__)


# Path-prefix classification: (method, prefix) → (category, action, summary, importance)
# Longest prefix match wins. First match used.
_CLASSIFICATION: list[tuple[str, str, str, str, str, str]] = [
    # ── Critical identity / safety — always high importance, user_override ──
    ("PUT",    "/api/contract",                        "user_override", "contract_edited",   "User edited CONTRACT.md",            "high"),
    ("PUT",    "/api/vault/file/system/identity/SOUL", "user_override", "soul_edited",       "User edited SOUL.md",                "high"),
    ("PUT",    "/api/vault/file/system/identity/USER", "user_override", "user_profile_edited","User edited USER.md",                "high"),
    ("POST",   "/api/emergency",                       "user_override", "emergency_stop",    "User triggered emergency stop",      "high"),
    ("PUT",    "/api/relationship",                    "user_override", "relationship_edited","User edited RELATIONSHIP.md",       "high"),
    ("POST",   "/api/relationship/insight",            "user_override", "relationship_insight","User added/removed relationship insight","medium"),
    ("POST",   "/api/relationship/pending/approve",   "user_override", "relationship_approved","User approved weekly relationship evolution","high"),
    ("POST",   "/api/relationship/pending/reject",    "user_override", "relationship_rejected","User rejected weekly relationship evolution","medium"),

    # ── Memory / reflection overrides ──
    ("POST",   "/api/memory/reject",                   "user_override", "memory_rejected",   "User rejected a memory entry",       "high"),
    ("POST",   "/api/memory/unapprove",                "user_override", "memory_unapproved", "User unapproved a memory entry",     "high"),
    ("POST",   "/api/memory/approve",                  "user",          "memory_approved",   "User approved a memory entry",       "medium"),
    ("POST",   "/api/memory/correction",               "user_override", "memory_corrected",  "User corrected a memory fact",       "high"),
    ("POST",   "/api/memory/generate",                 "user",          "memory_generated",  "User triggered memory generation",   "medium"),
    ("POST",   "/api/memory/compact",                  "user",          "memory_compacted",  "User triggered memory compaction",   "medium"),
    ("POST",   "/api/memory/dream-review/",            "user",          "dream_review",      "User reviewed a dream-extracted belief","medium"),
    ("POST",   "/api/memory/counterfactual/",          "user",          "hypothesis_restored","User restored a rejected hypothesis","medium"),
    ("POST",   "/api/memory/dream",                    "user",          "dream_phase_run",   "User triggered a dream phase",       "medium"),
    ("POST",   "/api/reflection/reject",               "user_override", "reflection_rejected","User rejected a reflection",         "high"),
    ("POST",   "/api/reflection/unapprove",            "user_override", "reflection_unapproved","User unapproved a reflection",     "high"),
    ("POST",   "/api/reflections",                     "user",          "reflection_created","User requested a reflection",        "medium"),

    # ── Action plan / heal proposals ──
    ("POST",   "/api/orchestrator/plan/approve",       "user",          "plan_approved",     "User approved action plan items",    "medium"),
    ("POST",   "/api/orchestrator/plan/reject",        "user_override", "plan_rejected",     "User rejected action plan items",    "high"),
    ("POST",   "/api/orchestrator/proposals/approve",  "user",          "heal_approved",     "User approved a heal proposal",      "medium"),
    ("POST",   "/api/orchestrator/proposals/reject",   "user_override", "heal_rejected",     "User rejected a heal proposal",      "medium"),

    # ── Guardian / security ──
    ("POST",   "/api/guardian",                        "user_override", "guardian_updated",  "User edited Guardian blacklist",     "high"),
    ("DELETE", "/api/guardian",                        "user_override", "guardian_cleared",  "User removed a Guardian entry",      "medium"),

    # ── Pairing / security (user approves/rejects unknown senders) ──
    ("POST",   "/api/security/pairing/approve",        "user",          "pairing_approved",  "User approved a pairing request",    "medium"),
    ("POST",   "/api/security/pairing/reject",         "user_override", "pairing_rejected",  "User rejected a pairing request",    "medium"),
    ("POST",   "/api/security/allowlist",              "user",          "allowlist_added",   "User added to allowlist",            "medium"),
    ("DELETE", "/api/security/allowlist",              "user",          "allowlist_removed", "User removed from allowlist",        "medium"),
    ("PUT",    "/api/security/dm-policy",              "user",          "dm_policy_changed", "User changed DM policy",             "medium"),

    # ── Wiki CRUD (user curation) ──
    # Sub-action POSTs like `/rename`, `/verify`, `/reject`, `/consolidate`,
    # `/repair` are resolved by the suffix-override branch in `_classify()`,
    # so the base `/api/wiki/article` only needs the "create" entry.
    ("POST",   "/api/wiki/article",                    "user",          "wiki_created",      "User created a wiki article",        "medium"),
    ("PUT",    "/api/wiki/article",                    "user",          "wiki_edited",       "User edited a wiki article",         "medium"),
    ("DELETE", "/api/wiki/article",                    "user",          "wiki_deleted",      "User deleted a wiki article",        "medium"),
    ("DELETE", "/api/wiki/reset",                      "user_override", "wiki_reset",        "User reset a wiki",                  "high"),

    # ── Knowledge bases (structural user actions) ──
    ("POST",   "/api/kb",                              "user",          "kb_created",        "User created a knowledge base",      "medium"),
    ("PUT",    "/api/kb",                              "user",          "kb_renamed",        "User renamed a knowledge base",      "medium"),
    ("DELETE", "/api/kb",                              "user_override", "kb_deleted",        "User deleted a knowledge base",      "high"),
    # Ingest / compile / reflect are user-triggered pipeline runs. They
    # show up as knowledge-category events on the backend side too via
    # KnowledgeBaseService.ingest(), but the middleware entry records
    # that a USER specifically asked for it vs. watcher auto-ingest.
    ("POST",   "/api/kb/inbox/ingest",                 "user",          "kb_inbox_ingested", "User triggered inbox ingest",        "medium"),
    ("POST",   "/api/kb/job/all",                      "user",          "kb_wiki_job_all",   "User ran wiki job across all KBs",   "medium"),

    # ── Projects / tasks / goals ──
    ("POST",   "/api/projects",                        "user",          "project_created",   "User created a project",             "medium"),
    ("PUT",    "/api/projects",                        "user",          "project_updated",   "User updated a project",             "medium"),
    ("PATCH",  "/api/projects",                        "user",          "project_patched",   "User patched a project",             "medium"),
    ("DELETE", "/api/projects",                        "user",          "project_deleted",   "User deleted a project",             "medium"),
    ("POST",   "/api/tasks",                           "user",          "task_created",      "User created a task",                "medium"),
    ("PATCH",  "/api/tasks",                           "user",          "task_updated",      "User updated a task",                "low"),
    ("PUT",    "/api/tasks",                           "user",          "task_reassigned",   "User reassigned a task",             "medium"),
    ("DELETE", "/api/tasks",                           "user",          "task_deleted",      "User deleted a task",                "medium"),
    ("POST",   "/api/goals",                           "user",          "goal_created",      "User created a goal",                "medium"),
    ("PATCH",  "/api/goals",                           "user",          "goal_updated",      "User updated a goal",                "medium"),
    ("DELETE", "/api/goals",                           "user",          "goal_detached",     "User detached a goal from project",  "medium"),

    # ── Journal ──
    ("POST",   "/api/journal",                         "user",          "journal_written",   "User wrote a journal entry",         "medium"),

    # ── Settings / integrations ──
    ("PUT",    "/api/settings/llm",                    "user",          "llm_settings",      "User changed LLM settings",          "medium"),
    ("PUT",    "/api/settings/locale",                 "user",          "locale_changed",    "User changed locale",                "low"),
    ("PUT",    "/api/settings",                        "user",          "settings_updated",  "User updated settings",              "medium"),
    ("POST",   "/api/settings/credentials",            "user",          "credentials_set",   "User set credentials",               "medium"),
    ("DELETE", "/api/settings/credentials",            "user",          "credentials_removed","User removed credentials",          "medium"),
    ("POST",   "/api/settings/ollama/pull",            "user",          "ollama_pull",       "User pulled an Ollama model",        "medium"),
    ("DELETE", "/api/settings/ollama",                 "user",          "ollama_deleted",    "User deleted an Ollama model",       "medium"),
    ("POST",   "/api/integrations",                    "user",          "integration_added", "User added an integration",          "medium"),

    # ── Channels (connect/disconnect is user-initiated) ──
    ("POST",   "/api/channels/whatsapp/connect",       "user",          "whatsapp_connect",  "User connected WhatsApp",            "medium"),
    ("POST",   "/api/channels/whatsapp/disconnect",    "user",          "whatsapp_disconnect","User disconnected WhatsApp",        "medium"),
    ("POST",   "/api/channels/whatsapp/mode",          "user",          "whatsapp_mode",     "User changed WhatsApp mode",         "medium"),
    ("POST",   "/api/channels",                        "user",          "channel_connect",   "User connected a channel",           "medium"),

    # ── Email ──
    ("POST",   "/api/email/connect",                   "user",          "email_connect",     "User connected email",               "medium"),
    ("POST",   "/api/email/disconnect",                "user",          "email_disconnect",  "User disconnected email",            "medium"),

    # ── Orchestrator / subagents ──
    ("POST",   "/api/orchestrator/agents",             "user",          "agent_created",     "User created a subagent",            "medium"),
    ("PUT",    "/api/orchestrator/agents",             "user",          "agent_edited",      "User edited a subagent",             "medium"),
    ("DELETE", "/api/orchestrator/agents",             "user",          "agent_deleted",     "User deleted a subagent",            "medium"),

    # ── Skills ──
    ("POST",   "/api/skills/create",                   "user",          "skill_created",     "User created a skill",               "medium"),
    ("PUT",    "/api/skills",                          "user",          "skill_edited",      "User edited a skill",                "medium"),

    # ── MCP ──
    ("POST",   "/api/mcp/servers/add",                 "user",          "mcp_added",         "User added an MCP server",           "medium"),
    ("POST",   "/api/mcp/servers",                     "user",          "mcp_toggled",       "User connected/disconnected an MCP server","medium"),
    ("DELETE", "/api/mcp/servers",                     "user",          "mcp_removed",       "User removed an MCP server",         "medium"),

    # ── Graph / memory health ──
    ("POST",   "/api/graph/build",                     "user",          "graph_rebuilt",     "User rebuilt the knowledge graph",   "medium"),
    ("POST",   "/api/graph/triples",                   "user",          "triple_edited",     "User edited a triple",               "medium"),
    ("POST",   "/api/graph/decay",                     "user",          "graph_decay_run",   "User ran graph decay",               "low"),
    ("POST",   "/api/memory/health/repair",            "user",          "memory_repaired",   "User ran memory auto-repair",        "medium"),

    # ── Sync / vault location ──
    ("POST",   "/api/sync",                            "user",          "sync_configured",   "User changed vault sync",            "high"),

    # ── Plugins ──
    ("POST",   "/api/plugins",                         "user",          "plugin_toggled",    "User enabled/disabled a plugin",     "medium"),

    # ── Budget ──
    ("PUT",    "/api/costs/budget",                    "user",          "budget_changed",    "User updated cost budget",           "low"),

    # ── Search ──
    ("POST",   "/api/search/reindex",                  "user",          "search_reindexed",  "User triggered search reindex",      "low"),

    # ── Domains ──
    ("PUT",    "/api/domains",                         "user",          "domain_edited",     "User edited a domain module",        "medium"),

    # ── Canvas ──
    ("POST",   "/api/canvas",                          "user",          "canvas_action",     "User took a canvas action",          "low"),
    ("DELETE", "/api/canvas",                          "user",          "canvas_cleared",    "User cleared canvas items",          "low"),

    # ── Cron / autopilot / daily ──
    ("POST",   "/api/cron",                            "user",          "cron_added",        "User added a cron job",              "medium"),
    ("DELETE", "/api/cron",                            "user",          "cron_removed",      "User removed a cron job",            "medium"),
    ("POST",   "/api/autopilot",                       "user",          "autopilot_ran",     "User triggered autopilot",           "medium"),
    ("POST",   "/api/daily",                           "user",          "daily_cycle_ran",   "User triggered daily cycle",         "medium"),

    # ── Work queue ──
    ("POST",   "/api/work-queue/retry",                "user",          "queue_retried",     "User retried work queue jobs",       "medium"),

    # ── Logs (archive/resolve are user curation) ──
    ("POST",   "/api/logs",                            "user",          "log_resolved",      "User resolved an error log",         "low"),
    ("PATCH",  "/api/logs",                            "user",          "log_archived",      "User archived a report",             "low"),
    ("DELETE", "/api/logs",                            "user",          "log_deleted",       "User deleted a log",                 "low"),

    # ── Bibliography ──
    ("POST",   "/api/bibliography",                    "user",          "bib_added",         "User added a bibliography entry",    "low"),
    ("PUT",    "/api/bibliography",                    "user",          "bib_edited",        "User edited a bibliography entry",   "low"),
    ("DELETE", "/api/bibliography",                    "user",          "bib_removed",       "User removed a bibliography entry",  "low"),

    # ── Trust ──
    ("POST",   "/api/trust",                           "user_override", "trust_changed",     "User changed a trust level",         "high"),
    ("PUT",    "/api/trust",                           "user_override", "trust_changed",     "User changed a trust level",         "high"),
    ("PATCH",  "/api/trust",                           "user_override", "trust_changed",     "User changed a trust level",         "high"),

    # ── Vault generic file operations ──
    ("PUT",    "/api/vault/file",                      "user",          "vault_file_edited", "User edited a vault file",           "medium"),
    ("POST",   "/api/vault/file",                      "user",          "vault_file_created","User created a vault file",          "medium"),
    ("DELETE", "/api/vault/file",                      "user",          "vault_file_deleted","User deleted a vault file",          "medium"),

    # ── Watcher quarantine (user triage of failed ingests) ──
    ("POST",   "/api/watcher/scan",                    "user",          "watcher_scanned",   "User triggered an inbox scan",       "low"),
    ("POST",   "/api/watcher/quarantine/restore",      "user",          "quarantine_restored","User restored a quarantined file",  "medium"),
    ("POST",   "/api/watcher/quarantine/delete",       "user_override", "quarantine_deleted","User deleted a quarantined file",    "medium"),
    ("POST",   "/api/watcher/quarantine",              "user",          "quarantine_action", "User acted on quarantine",           "medium"),

    # ── Audit purge ──
    ("POST",   "/api/audit/purge",                     "user_override", "audit_purged",      "User purged the audit log",          "high"),
    ("DELETE", "/api/audit",                           "user_override", "audit_purged",      "User deleted audit entries",         "high"),

    # ── Search reclassify / stale cleanup ──
    ("POST",   "/api/search/reclassify",               "user",          "search_reclassified","User reclassified search index",    "low"),
    ("DELETE", "/api/search/stale",                    "user",          "search_cleanup",    "User cleaned stale search entries",  "low"),

    # ── Onboarding completion ──
    ("POST",   "/api/onboarding/complete",             "user",          "onboarding_done",   "User completed onboarding",          "high"),
    ("POST",   "/api/onboarding",                      "user",          "onboarding_step",   "User advanced onboarding",           "low"),

    # ── Conversation archive/delete (user curation) ──
    ("PATCH",  "/api/conversations",                   "user",          "conversation_archived","User archived a conversation",    "low"),
    ("DELETE", "/api/conversations",                   "user",          "conversation_deleted","User deleted a conversation",      "medium"),

    # ── Settings model tiers ──
    ("PUT",    "/api/settings/model-tiers",            "user",          "model_tiers_changed","User changed model tier routing",   "medium"),

    # ── Canvas snapshots ──
    ("POST",   "/api/canvas/snapshot",                 "user",          "canvas_snapshot",   "User saved a canvas snapshot",       "low"),
    ("DELETE", "/api/canvas/snapshot",                 "user",          "canvas_snap_removed","User deleted a canvas snapshot",    "low"),

    # ── LLM reconcile ──
    ("POST",   "/api/llm/reconcile-tiers",             "user",          "llm_reconciled",    "User reconciled LLM tiers",          "medium"),

    # ── Orchestrator plan (generic catch-all, suffix routes above take priority) ──
    ("POST",   "/api/orchestrator/plan",               "user",          "plan_action",       "User acted on the action plan",      "medium"),
    ("DELETE", "/api/orchestrator/plan",               "user",          "plan_cleared",      "User cleared the action plan",       "low"),

    # ── Canvas item sub-actions ──
    ("PATCH",  "/api/canvas/items",                    "user",          "canvas_item_edited","User edited a canvas item",          "low"),
    ("DELETE", "/api/canvas/items",                    "user",          "canvas_item_removed","User removed a canvas item",        "low"),

    # ── Email (user-triggered read/send/triage) ──
    ("POST",   "/api/email/send",                      "user",          "email_sent",        "User sent an email",                 "high"),
    ("POST",   "/api/email/draft",                     "user",          "email_drafted",     "User drafted an email",              "medium"),
    ("POST",   "/api/email/sync",                      "user",          "email_synced",      "User triggered email sync",          "low"),
    ("POST",   "/api/email/message",                   "user",          "email_triaged",     "User triaged an email message",      "low"),

    # ── Emergency resume (after freeze) ──
    ("POST",   "/api/resume",                          "user_override", "emergency_resumed", "User resumed after emergency stop",  "high"),

    # ── Launch (start background services) ──
    ("POST",   "/api/launch",                          "user",          "systems_launched",  "User launched background services",   "high"),

    # ── Goals (PUT missing) ──
    ("PUT",    "/api/goals",                           "user",          "goal_updated",      "User updated a goal",                "medium"),

    # ── Graph admin actions ──
    ("POST",   "/api/graph/rebuild-registry",          "user",          "graph_registry_rebuilt","User rebuilt the entity registry","medium"),
    ("POST",   "/api/graph/ontology/reload",           "user",          "ontology_reloaded", "User reloaded the ontology",         "medium"),
    ("POST",   "/api/graph/registry/merge",            "user",          "entities_merged",   "User merged entities",               "medium"),
    ("POST",   "/api/graph/propagate",                 "user",          "triple_propagated", "User propagated a triple change",    "medium"),

    # ── Memory pending approve/reject/unapprove (dated paths) ──
    ("POST",   "/api/memory/pending",                  "user",          "memory_pending_action","User acted on pending memory",    "medium"),

    # ── Orchestrator dispatch / workflow (user-initiated subagent runs) ──
    ("POST",   "/api/orchestrator/dispatch",           "user",          "subagent_dispatched","User dispatched a subagent",        "medium"),
    ("POST",   "/api/orchestrator/workflow",           "user",          "workflow_ran",      "User ran a workflow",                "medium"),

    # ── Settings destructive / migration ──
    ("POST",   "/api/settings/migrate-frontmatter",    "user",          "frontmatter_migrated","User migrated frontmatter",        "medium"),
    ("POST",   "/api/settings/reset",                  "user_override", "settings_reset",    "User reset settings",                "high"),
    ("POST",   "/api/settings/reset-file",             "user_override", "settings_file_reset","User reset a settings file",        "high"),

    # ── Skills admin ──
    ("POST",   "/api/skills/analyze",                  "user",          "skills_analyzed",   "User analyzed skills",               "low"),

    # ── Trust domain delete ──
    ("DELETE", "/api/trust",                           "user_override", "trust_removed",     "User removed a trust entry",         "high"),

    # ── Wiki reclassify / stale cleanup ──
    ("POST",   "/api/wiki/reclassify",                 "user",          "wiki_reclassified", "User reclassified wiki content",     "medium"),
    ("DELETE", "/api/wiki/stale",                      "user",          "wiki_stale_cleaned","User cleaned stale wiki entries",    "low"),

    # ── Work queue admin ──
    ("DELETE", "/api/work-queue",                      "user",          "queue_job_removed", "User removed a queue job",           "low"),

    # ── Language drift batch re-ingest (spec v1.1 item 3) ──
    ("POST",   "/api/kb/language-drift",               "user",          "drift_reingested",  "User re-ingested drifted sources",   "medium"),

    # ── Privacy (right-to-erasure / portability) ──
    ("POST",   "/api/privacy/forget",                  "user_override", "privacy_forget",    "User invoked right-to-erasure",      "high"),

    # ── Decision log admin ──
    ("POST",   "/api/decisions/prune",                 "user",          "decisions_pruned",  "User ran decision-log retention",    "low"),
    ("PUT",    "/api/decisions/retention",             "user",          "retention_changed", "User changed retention policy",      "medium"),

    # ── Admin endpoints ──
    ("POST",   "/api/admin/rate-limits/reset",         "user_override", "rate_limit_reset",  "User reset a rate-limit bucket",     "medium"),
]

# Exempt: noisy, automated, or webhook paths that should never log activity.
_EXEMPT_PREFIXES: tuple[str, ...] = (  # arch:deterministic — routes that self-log via dedicated service hooks; protected by tests/e2e/test_classification_coverage.py which enforces justification per entry
    "/api/health",
    "/api/chat",              # has its own logging via Agent
    "/api/transcribe",        # speech-to-text utility, no persistent state
    "/api/onboarding/chat",
    "/api/costs/track",       # cost telemetry — noisy
    "/api/heartbeat",         # background pulse
    "/api/simulate",          # simulation reports are agent-initiated
    "/api/orchestrator/simulate",
)


def _classify(method: str, path: str) -> tuple[str, str, str, str] | None:
    """Match method+path to (category, action, summary, importance).

    Longest prefix match wins so more-specific sub-routes (e.g. /wiki/article/{slug}/rename)
    can override the generic /wiki/article entry by ordering in the classification list.
    """
    # Sub-action match first: inspect trailing path segment for known verbs
    suffix_overrides = {
        "/rename": ("user", "wiki_renamed", "User renamed a wiki article", "medium"),
        "/verify": ("user", "wiki_verified", "User verified a wiki article", "low"),
        "/reject": ("user", "wiki_rejected", "User rejected a wiki article", "medium"),
        "/consolidate": ("user", "wiki_consolidated", "User consolidated a wiki article", "medium"),
        "/repair": ("user", "wiki_repaired", "User ran wiki auto-repair", "low"),
    }
    if method == "POST" and path.startswith("/api/wiki/article"):
        for suffix, override in suffix_overrides.items():
            if path.endswith(suffix):
                return override

    # KB pipeline sub-actions: /api/kb/{slug}/{verb}. We want these to
    # register as specific knowledge events, not inherit the generic
    # "kb_created" classification from the /api/kb prefix row.
    kb_verb_overrides = {
        "/ingest":      ("knowledge", "kb_ingest_requested",  "User triggered ingest",       "medium"),
        "/compile":     ("knowledge", "kb_compile_requested", "User triggered compile",      "medium"),
        "/reflect":     ("knowledge", "kb_reflect_requested", "User triggered reflect",      "medium"),
        "/lint":        ("knowledge", "kb_lint_requested",    "User triggered lint",         "low"),
        "/job":         ("knowledge", "kb_wiki_job",          "User ran wiki job",           "medium"),
        "/snapshot":    ("knowledge", "kb_snapshot",          "User snapshotted KB",         "low"),
        "/repair":      ("knowledge", "kb_repaired",          "User ran KB repair",          "low"),
        "/scrape":      ("knowledge", "kb_scrape_requested",  "User triggered scrape",       "medium"),
        "/synthesize":  ("knowledge", "kb_synthesize",        "User triggered synthesis",    "medium"),
        "/sync-projects": ("knowledge", "kb_sync_projects",   "User synced KB with projects","low"),
    }
    if method == "POST" and path.startswith("/api/kb/") and not path.startswith("/api/kb/inbox"):
        for suffix, override in kb_verb_overrides.items():
            if path.endswith(suffix):
                return override

    best: tuple[int, tuple[str, str, str, str]] | None = None
    for m, prefix, category, action, summary, importance in _CLASSIFICATION:
        if m != method or not path.startswith(prefix):
            continue
        score = len(prefix)
        if best is None or score > best[0]:
            best = (score, (category, action, summary, importance))
    return best[1] if best else None


class ActivityMiddleware(BaseHTTPMiddleware):
    """Log every successful mutating user action to ActivityLogger.

    Runs AFTER the request handler so we only log successful (2xx) outcomes.
    Non-mutating methods (GET/HEAD/OPTIONS) are bypassed immediately. Webhooks,
    exempt paths, and unclassified routes pass through without logging.
    """

    async def dispatch(self, request: Request, call_next) -> Response:  # noqa: ANN001
        method = request.method

        # Only mutating methods
        if method not in ("POST", "PUT", "PATCH", "DELETE"):
            return await call_next(request)

        path = request.url.path

        # Exempt prefixes
        if any(path.startswith(p) for p in _EXEMPT_PREFIXES):
            return await call_next(request)

        # Webhooks / incoming channel traffic — not user actions
        if "/webhook" in path or "/incoming" in path:
            return await call_next(request)

        # Run the handler first — we only log successful outcomes
        response = await call_next(request)

        if response.status_code >= 300:
            return response

        activity = getattr(request.app.state, "activity_logger", None)
        if activity is None:
            return response

        classification = _classify(method, path)
        if classification is None:
            return response

        category, action, summary, importance = classification
        try:
            activity.log(
                category=category,
                action=action,
                summary=summary,
                details={"method": method, "path": path, "status": response.status_code},
                importance=importance,
            )
            activity.record_user_activity("api")
        except Exception:
            log.debug("Failed to record activity for %s %s", method, path, exc_info=True)

        return response
