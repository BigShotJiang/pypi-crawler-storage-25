"""JAX port of PROSPECT-D + 4SAIL (a.k.a. PROSAIL).

A drop-in differentiable replacement for the forward call in jgomezdans/prosail
(`run_prosail` with `prospect_version="D"` and SDR factor). All operations are
JAX-traceable, jittable, and vmap-able. Gradients via `jax.grad` work for every
biophysical parameter and every geometry angle.

Validated against jgomezdans/prosail across randomised crop-realistic
parameter ranges:
    PROSPECT-D:    max abs reflectance diff ~9e-13 (vs ~5e-15 with full expi)
    Full PROSAIL:  max abs reflectance diff ~5e-13
The small (10^-13) regression vs jgomezdans is the price of replacing
`jax.scipy.special.expi` with a custom 30-term series + Lentz CF approximation
(~5e-11 relative on E1). The trade is worth it: jax's expi is ~10000x slower
than jnp.sin on CPU and dominates total runtime.

Reference:
    PROSPECT-D: Féret et al. (2017), Remote Sensing of Environment, 193:204-215.
    4SAIL:      Verhoef et al. (2007), IEEE TGRS, 45(6):1808-1822.

Notes on the port:
    * Numba JIT decorators are stripped — JAX's tracer handles compilation.
    * In-place updates (`tau[mask] = ...`) become `jnp.where`.
    * Boolean-mask branches that gate `expi`, `1/r`, `arccos`, `arcsin`, and
      sqrt of conditionally-negative arguments are protected with the "double
      where" trick so gradients are finite at all the branch boundaries.
    * The hotspot Simpson integration is fully vectorised over its 21 sample
      points (cumsum-style) — no sequential dependency, no `lax.scan`.
    * The Verhoef-bimodal LIDF's iterative fixed-point solver uses
      `lax.while_loop` with a 200-iteration cap so the closed-form branch
      (a > 1) terminates safely under tracing.
    * The Python-level loop over leaf-angle bins becomes an inner vmap.
    * `lai <= 0` and `r + t >= 1` branches are merged via `jnp.where` instead
      of early-return / boolean indexing, so the function is shape-stable
      under tracing.
"""

from __future__ import annotations

from pathlib import Path
from typing import NamedTuple

import jax
import jax.numpy as jnp
from jax import lax


# ---------------------------------------------------------------------------
# Fast E1 (and hence expi(-x) for x>0)
# ---------------------------------------------------------------------------
# jax.scipy.special.expi runs as an expensive series approximation that is
# ~10000x slower than jnp.sin on CPU. PROSPECT only ever evaluates expi at
# negative arguments via tau = (1-k)*exp(-k) + k^2 * (-Ei(-k)) for k >= 0,
# which is the regime expi(-k) = -E1(k). We use a fixed-iteration combination
# of the Abramowitz-Stegun 5.1.11 series for k <= 1.5 and a fixed-iteration
# Lentz continued fraction for k > 1.5. Max relative error ~5e-11 across
# the realistic kall range (~0 to ~50 in PROSPECT applications).

_EULER_GAMMA = 0.5772156649015329


def _e1_series(x: jnp.ndarray, n_terms: int = 30) -> jnp.ndarray:
    """Power series for E1(x), 0 < x <~ 1.5. Fully vectorised."""
    s = jnp.zeros_like(x)
    fact = 1.0
    sign = -1.0
    xp = jnp.ones_like(x)  # x^k will be built up
    for k in range(1, n_terms + 1):
        fact = fact * k
        sign = -sign
        xp = xp * x
        s = s + sign * xp / (k * fact)
    return -_EULER_GAMMA - jnp.log(x) + s


def _e1_lentz(x: jnp.ndarray, n_terms: int = 30) -> jnp.ndarray:
    """Fixed-iteration Lentz continued fraction for E1(x), x > 1.5."""
    b = x + 1.0
    d = 1.0 / b
    c = jnp.full_like(x, 1e30)
    h = d
    for i in range(1, n_terms + 1):
        a = -float(i * i)
        b = b + 2.0
        d = 1.0 / (a * d + b)
        c = b + a / c
        h = h * c * d
    return h * jnp.exp(-x)


def _expi_neg(k: jnp.ndarray) -> jnp.ndarray:
    """Compute expi(-k) for k >= 0, returning -E1(k).

    Vectorisable, JIT-friendly, ~5e-11 relative accuracy.
    """
    # Guard log(0) on the series branch and div-by-zero on Lentz; double-where
    # protects gradients.
    k_safe = jnp.where(k > 0.0, k, 1.0)
    series = _e1_series(jnp.where(k <= 1.5, k_safe, 1.0))
    lentz = _e1_lentz(jnp.where(k > 1.5, k_safe, 2.0))
    e1 = jnp.where(k <= 1.5, series, lentz)
    # expi(-k) = -E1(k); at k=0, expi(0) = -inf, but PROSPECT masks that case
    # via the kall>0 guard, so the value here is overwritten downstream.
    return -e1


# ---------------------------------------------------------------------------
# Spectral library loader (NumPy at load-time, frozen jnp arrays at use-time)
# ---------------------------------------------------------------------------


class ProspectDCoeffs(NamedTuple):
    nr: jnp.ndarray
    kab: jnp.ndarray
    kcar: jnp.ndarray
    kbrown: jnp.ndarray
    kw: jnp.ndarray
    km: jnp.ndarray
    kant: jnp.ndarray


class SoilCoeffs(NamedTuple):
    rsoil1: jnp.ndarray
    rsoil2: jnp.ndarray


def load_coeffs(prosail_data_dir: str | Path) -> tuple[ProspectDCoeffs, SoilCoeffs]:
    """Load spectral coefficients from the data files shipped with `prosail`.

    Pass the path to the directory containing `prospect_d_spectra.txt` and
    `soil_reflectance.txt` (i.e. the `prosail/` package directory of
    jgomezdans/prosail).
    """
    import numpy as np  # only at load-time; kept out of the hot path

    p = Path(prosail_data_dir)
    _, nr, kab, kcar, kant, kbrown, kw, km = np.loadtxt(
        p / "prospect_d_spectra.txt", unpack=True
    )
    rsoil1, rsoil2 = np.loadtxt(p / "soil_reflectance.txt", unpack=True)
    return (
        ProspectDCoeffs(
            nr=jnp.asarray(nr),
            kab=jnp.asarray(kab),
            kcar=jnp.asarray(kcar),
            kbrown=jnp.asarray(kbrown),
            kw=jnp.asarray(kw),
            km=jnp.asarray(km),
            kant=jnp.asarray(kant),
        ),
        SoilCoeffs(rsoil1=jnp.asarray(rsoil1), rsoil2=jnp.asarray(rsoil2)),
    )


# ---------------------------------------------------------------------------
# PROSPECT-D
# ---------------------------------------------------------------------------


def _calctav(alpha_deg: jnp.ndarray, nr: jnp.ndarray) -> jnp.ndarray:
    """Stern/Allen average transmissivity at a given incidence angle.

    Vectorised over `nr` (per-wavelength).
    """
    n2 = nr * nr
    npx = n2 + 1.0
    nm = n2 - 1.0
    a = (nr + 1.0) ** 2 / 2.0
    k = -((n2 - 1.0) ** 2) / 4.0
    sa = jnp.sin(jnp.deg2rad(alpha_deg))

    # Original code branches on alpha == 90; b1 collapses to 0 there. Use where.
    b1_full = jnp.sqrt(jnp.maximum((sa * sa - npx / 2.0) ** 2 + k, 0.0))
    b1 = jnp.where(alpha_deg == 90.0, 0.0, b1_full)
    b2 = sa * sa - npx / 2.0
    b = b1 - b2
    b3 = b ** 3
    a3 = a ** 3

    ts = (k ** 2 / (6.0 * b3) + k / b - b / 2.0) - (k ** 2 / (6.0 * a3) + k / a - a / 2.0)
    tp1 = -2.0 * n2 * (b - a) / (npx ** 2)
    tp2 = -2.0 * n2 * npx * jnp.log(b / a) / (nm ** 2)
    tp3 = n2 * (1.0 / b - 1.0 / a) / 2.0
    tp4 = (
        16.0
        * n2 ** 2
        * (n2 ** 2 + 1.0)
        * jnp.log((2.0 * npx * b - nm ** 2) / (2.0 * npx * a - nm ** 2))
        / (npx ** 3 * nm ** 2)
    )
    tp5 = (
        16.0
        * n2 ** 3
        * (1.0 / (2.0 * npx * b - nm ** 2) - 1.0 / (2.0 * npx * a - nm ** 2))
        / (npx ** 3)
    )
    tp = tp1 + tp2 + tp3 + tp4 + tp5
    return (ts + tp) / (2.0 * sa ** 2)


def _refl_trans_one_layer(alpha_deg, nr, tau):
    talf = _calctav(alpha_deg, nr)
    ralf = 1.0 - talf
    t12 = _calctav(jnp.asarray(90.0), nr)
    r12 = 1.0 - t12
    t21 = t12 / (nr * nr)
    r21 = 1.0 - t21

    denom = 1.0 - r21 * r21 * tau * tau
    Ta = talf * tau * t21 / denom
    Ra = ralf + r21 * tau * Ta
    t = t12 * tau * t21 / denom
    r = r12 + r21 * tau * t
    return r, t, Ra, Ta


def prospect_d(
    N: jnp.ndarray,
    cab: jnp.ndarray,
    car: jnp.ndarray,
    cbrown: jnp.ndarray,
    cw: jnp.ndarray,
    cm: jnp.ndarray,
    ant: jnp.ndarray,
    coeffs: ProspectDCoeffs,
    alpha: float = 40.0,
):
    """PROSPECT-D forward model. Returns leaf reflectance and transmittance.

    All scalar parameters may be jax tracers. Returns two (2101,) arrays
    covering 400-2500 nm at 1 nm.
    """
    nr = coeffs.nr
    kall = (
        cab * coeffs.kab
        + car * coeffs.kcar
        + ant * coeffs.kant
        + cbrown * coeffs.kbrown
        + cw * coeffs.kw
        + cm * coeffs.km
    ) / N

    # tau via the (1-k)*exp(-k) + k^2 * (-Ei(-k)) expansion. expi(0) is -inf;
    # original code masks with `kall > 0` and leaves tau=1 elsewhere. The
    # double-where pattern keeps gradients finite at the masked points.
    safe_kall = jnp.where(kall > 0.0, kall, 1.0)
    t1 = (1.0 - safe_kall) * jnp.exp(-safe_kall)
    # _expi_neg(k) = expi(-k) for k > 0, ~5e-11 relative accuracy. Replaces
    # jax.scipy.special.expi which is ~10000x slower than jnp.sin on CPU.
    t2 = safe_kall ** 2 * (-_expi_neg(safe_kall))
    tau = jnp.where(kall > 0.0, t1 + t2, 1.0)

    r, t, Ra, Ta = _refl_trans_one_layer(jnp.asarray(alpha), nr, tau)

    # N-layer Stokes
    D = jnp.sqrt(
        jnp.maximum((1.0 + r + t) * (1.0 + r - t) * (1.0 - r + t) * (1.0 - r - t), 0.0)
    )
    rq = r * r
    tq = t * t

    # Guard 1/(2r) and 1/(2t) at zero absorption. The values produced under
    # the guarded branch are immediately overwritten by the `r+t >= 1` case
    # below, but they must be finite so jax.grad doesn't see NaN.
    safe_r = jnp.where(r > 1e-12, r, 1.0)
    safe_t = jnp.where(t > 1e-12, t, 1.0)
    a_coef = (1.0 + rq - tq + D) / (2.0 * safe_r)
    b_coef = (1.0 - rq + tq + D) / (2.0 * safe_t)

    bNm1 = jnp.power(b_coef, N - 1.0)
    bN2 = bNm1 * bNm1
    a2 = a_coef * a_coef
    denom2 = a2 * bN2 - 1.0
    Rsub_normal = a_coef * (bN2 - 1.0) / denom2
    Tsub_normal = bNm1 * (a2 - 1.0) / denom2

    # Zero-absorption case
    zero_abs = (r + t) >= 1.0
    safe_inner = t + (1.0 - t) * (N - 1.0)
    Tsub_zero = t / jnp.where(zero_abs, safe_inner, 1.0)
    Rsub = jnp.where(zero_abs, 1.0 - Tsub_zero, Rsub_normal)
    Tsub = jnp.where(zero_abs, Tsub_zero, Tsub_normal)

    denom3 = 1.0 - Rsub * r
    tran = Ta * Tsub / denom3
    refl = Ra + Ta * Rsub * t / denom3
    return refl, tran


# ---------------------------------------------------------------------------
# 4SAIL
# ---------------------------------------------------------------------------


def _verhoef_bimodal(a: jnp.ndarray, b: jnp.ndarray, n_elements: int = 18):
    """Verhoef bimodal LIDF.

    Faithful port of the reference iterative solver: for each upper-edge angle
    we solve y = a*sin(x) + 0.5*b*sin(2x) with x converging via dx=(y-x+p)/2
    until |dx| < 1e-8. We use `lax.while_loop` so this is jittable. The
    `a > 1` short-circuit (where f := 1 - cos(theta)) is handled with a
    masked initial value plus an early-exit predicate.
    """
    eps = 1e-8
    step = 90.0 / n_elements
    angles_desc = (jnp.arange(n_elements) * step)[::-1]  # 90-step, ..., step, 0

    def solve_f(angle_deg):
        tl1 = jnp.deg2rad(angle_deg)
        p = 2.0 * tl1

        # Iterative branch (a <= 1). Cap at 200 iterations to guarantee
        # termination even for the unused-branch trace when a > 1, where the
        # fixed-point iteration may not converge.
        def cond(state):
            x, delx, it = state
            return jnp.logical_and(delx >= eps, it < 200)

        def body(state):
            x, _, it = state
            y = a * jnp.sin(x) + 0.5 * b * jnp.sin(2.0 * x)
            dx = 0.5 * (y - x + p)
            return (x + dx, jnp.abs(dx), it + 1)

        x_iter, _, _ = lax.while_loop(cond, body, (p, 1.0, 0))
        y_iter = a * jnp.sin(x_iter) + 0.5 * b * jnp.sin(2.0 * x_iter)
        f_iter = (2.0 * y_iter + p) / jnp.pi

        # Closed-form branch (a > 1).
        f_closed = 1.0 - jnp.cos(tl1)
        return jnp.where(a > 1.0, f_closed, f_iter)

    # Reference computes lidf[i] = freq_prev - f_curr where freq accumulates
    # across the descending sweep. We replicate via a scan.
    f_vals = jax.vmap(solve_f)(angles_desc)  # f at each upper edge in descending order

    def scan_body(freq_prev, f):
        lidf_i = freq_prev - f
        return f, lidf_i

    _, lidf_desc = lax.scan(scan_body, 1.0, f_vals)
    return lidf_desc[::-1]


def _campbell(alpha_deg: jnp.ndarray, n_elements: int = 18):
    """Campbell (1990) ellipsoidal LIDF, parametrised by mean leaf angle.

    Faithful port: closed-form integral with a branch on `excent > 1` vs
    `< 1`. The two branches use sqrt(α²+x²) (real) vs sqrt(α²-x²) (real
    when |x| ≤ α), so we double-where the sqrt argument so neither branch
    NaNs the gradient on its inactive side.
    """
    excent = jnp.exp(
        -1.6184e-5 * alpha_deg ** 3
        + 2.1145e-3 * alpha_deg ** 2
        - 1.2390e-1 * alpha_deg
        + 3.2491
    )
    step = 90.0 / n_elements
    i = jnp.arange(n_elements)
    tl1 = jnp.deg2rad(i * step)
    tl2 = jnp.deg2rad((i + 1.0) * step)
    x1 = excent / jnp.sqrt(1.0 + excent ** 2 * jnp.tan(tl1) ** 2)
    x2 = excent / jnp.sqrt(1.0 + excent ** 2 * jnp.tan(tl2) ** 2)

    # Branch indicator. Avoid divide-by-zero in alph at excent=1 by guarding;
    # the result there is overwritten by the equality branch below anyway.
    is_eq = excent == 1.0
    safe_one_minus = jnp.where(is_eq, 1.0, jnp.abs(1.0 - excent ** 2))
    alph = excent / jnp.sqrt(safe_one_minus)
    alph2 = alph ** 2
    x12 = x1 ** 2
    x22 = x2 ** 2

    # Branch A: excent > 1 — sqrt(alph² + x²) is real and positive.
    alpx1_a = jnp.sqrt(alph2 + x12)
    alpx2_a = jnp.sqrt(alph2 + x22)
    dum_a = x1 * alpx1_a + alph2 * jnp.log(x1 + alpx1_a)
    freq_a = jnp.abs(dum_a - (x2 * alpx2_a + alph2 * jnp.log(x2 + alpx2_a)))

    # Branch B: excent < 1 — sqrt(alph² - x²). Guard arg with abs so the
    # inactive branch doesn't NaN; double-where keeps gradient through.
    inner1 = jnp.where(excent < 1.0, alph2 - x12, 1.0)
    inner2 = jnp.where(excent < 1.0, alph2 - x22, 1.0)
    almx1_b = jnp.sqrt(jnp.maximum(inner1, 0.0))
    almx2_b = jnp.sqrt(jnp.maximum(inner2, 0.0))
    safe_alph = jnp.where(excent < 1.0, alph, 1.0)
    # arcsin'(x) = 1/sqrt(1-x²) is infinite at x=+/-1. The reference only
    # evaluates this branch when excent < 1, where x/alph stays inside
    # (-1, 1). Keep that interior; on the inactive branch (excent >= 1)
    # clip to a safe constant so the gradient through arcsin is finite.
    arg1 = jnp.where(excent < 1.0, x1 / safe_alph, 0.0)
    arg2 = jnp.where(excent < 1.0, x2 / safe_alph, 0.0)
    dum_b = x1 * almx1_b + alph2 * jnp.arcsin(arg1)
    freq_b = jnp.abs(dum_b - (x2 * almx2_b + alph2 * jnp.arcsin(arg2)))

    # Branch C: excent == 1 — degenerate.
    freq_c = jnp.abs(jnp.cos(tl1) - jnp.cos(tl2))

    freq = jnp.where(is_eq, freq_c, jnp.where(excent > 1.0, freq_a, freq_b))
    return freq / jnp.sum(freq)


def _volscatt(tts, tto, psi, ttl):
    """Volume scattering function for a single leaf inclination."""
    cts = jnp.cos(jnp.deg2rad(tts))
    cto = jnp.cos(jnp.deg2rad(tto))
    sts = jnp.sin(jnp.deg2rad(tts))
    sto = jnp.sin(jnp.deg2rad(tto))
    cospsi = jnp.cos(jnp.deg2rad(psi))
    psir = jnp.deg2rad(psi)
    cttl = jnp.cos(jnp.deg2rad(ttl))
    sttl = jnp.sin(jnp.deg2rad(ttl))
    cs = cttl * cts
    co = cttl * cto
    ss = sttl * sts
    so = sttl * sto

    cosbts = jnp.where(jnp.abs(ss) > 1e-6, -cs / jnp.where(jnp.abs(ss) > 1e-6, ss, 1.0), 5.0)
    cosbto = jnp.where(jnp.abs(so) > 1e-6, -co / jnp.where(jnp.abs(so) > 1e-6, so, 1.0), 5.0)

    # arccos is differentiable on (-1, 1) but its derivative -1/sqrt(1-x^2)
    # blows up at the endpoints. The reference code only computes arccos when
    # |cosbts| < 1; here we feed arccos a guarded value and rely on the outer
    # where to overwrite the gradient. Using safe = clip(x, -0.9999, 0.9999)
    # inside the unused branch keeps both forward and reverse paths finite.
    bts_inrange = jnp.abs(cosbts) < 1.0
    safe_cosbts = jnp.where(bts_inrange, cosbts, 0.0)
    bts = jnp.where(bts_inrange, jnp.arccos(safe_cosbts), jnp.pi)
    ds = jnp.where(bts_inrange, ss, cs)

    bto_inrange = jnp.abs(cosbto) < 1.0
    safe_cosbto = jnp.where(bto_inrange, cosbto, 0.0)
    # When out of range and tto < 90: bto=pi, do_=co; else bto=0, do_=-co
    bto_oor = jnp.where(tto < 90.0, jnp.pi, 0.0)
    do_oor = jnp.where(tto < 90.0, co, -co)
    bto = jnp.where(bto_inrange, jnp.arccos(safe_cosbto), bto_oor)
    do_ = jnp.where(bto_inrange, so, do_oor)

    chi_s = 2.0 / jnp.pi * ((bts - jnp.pi * 0.5) * cs + jnp.sin(bts) * ss)
    chi_o = 2.0 / jnp.pi * ((bto - jnp.pi * 0.5) * co + jnp.sin(bto) * so)

    btran1 = jnp.abs(bts - bto)
    btran2 = jnp.pi - jnp.abs(bts + bto - jnp.pi)

    # Cascaded if/elif from the original — translate as nested where.
    case_a = psir <= btran1
    case_b = jnp.logical_and(jnp.logical_not(case_a), psir <= btran2)
    bt1 = jnp.where(case_a, psir, btran1)
    bt2 = jnp.where(case_a, btran1, jnp.where(case_b, psir, btran2))
    bt3 = jnp.where(case_a, btran2, jnp.where(case_b, btran2, psir))

    t1 = 2.0 * cs * co + ss * so * cospsi
    t2 = jnp.where(
        bt2 > 0.0,
        jnp.sin(bt2) * (2.0 * ds * do_ + ss * so * jnp.cos(bt1) * jnp.cos(bt3)),
        0.0,
    )
    denom = 2.0 * jnp.pi ** 2
    frho = jnp.maximum(((jnp.pi - bt2) * t1 + t2) / denom, 0.0)
    ftau = jnp.maximum((-bt2 * t1 + t2) / denom, 0.0)
    return chi_s, chi_o, frho, ftau


def _weighted_sum_over_lidf(lidf, tts, tto, psi):
    """Vectorise the LIDF reduction over all inclination bins at once."""
    n = lidf.shape[0]
    angle_step = 90.0 / n
    litab = jnp.arange(n) * angle_step + (angle_step * 0.5)
    cts = jnp.cos(jnp.deg2rad(tts))
    cto = jnp.cos(jnp.deg2rad(tto))
    ctscto = cts * cto

    # vmap over the inclination bins.
    chi_s, chi_o, frho, ftau = jax.vmap(_volscatt, in_axes=(None, None, None, 0))(
        tts, tto, psi, litab
    )
    ksli = chi_s / cts
    koli = chi_o / cto
    sobli = frho * jnp.pi / ctscto
    sofli = ftau * jnp.pi / ctscto
    cttl = jnp.cos(jnp.deg2rad(litab))
    bfli = cttl ** 2

    ks = jnp.sum(ksli * lidf)
    ko = jnp.sum(koli * lidf)
    bf = jnp.sum(bfli * lidf)
    sob = jnp.sum(sobli * lidf)
    sof = jnp.sum(sofli * lidf)
    return ks, ko, bf, sob, sof


def _Jfunc1(k, l, t):
    """J1 with the small-(k-l)*t Taylor regularisation.

    `k` is scalar, `l` is per-wavelength.
    """
    del_ = (k - l) * t
    big = jnp.abs(del_) > 1e-3
    safe_diff = jnp.where(big, k - l, 1.0)
    big_branch = (jnp.exp(-l * t) - jnp.exp(-k * t)) / safe_diff
    small_branch = (
        0.5 * t * (jnp.exp(-k * t) + jnp.exp(-l * t)) * (1.0 - (del_ ** 2) / 12.0)
    )
    return jnp.where(big, big_branch, small_branch)


def _Jfunc2(k, l, t):
    return (1.0 - jnp.exp(-(k + l) * t)) / (k + l)


def _hotspot_simpson(alf, lai, ko, ks):
    """Vectorised 20-step hotspot integration.

    The reference uses a serial loop with a running sumint. Each step's
    contribution depends only on (x_i, y_i, f_i) and (x_{i-1}, y_{i-1}, f_{i-1}),
    so we compute all 21 points in parallel and reduce.
    """
    fhot = lai * jnp.sqrt(ko * ks)
    fint = (1.0 - jnp.exp(-alf)) * 0.05

    # x at steps 0..20: x_0 = 0, x_i = -log(1 - i*fint)/alf for 1<=i<20, x_20 = 1.
    i = jnp.arange(21)  # 0..20 inclusive
    arg = jnp.maximum(1.0 - i * fint, 1e-12)
    x_pre = -jnp.log(arg) / alf
    x = jnp.where(i == 0, 0.0, jnp.where(i < 20, x_pre, 1.0))
    y = -(ko + ks) * lai * x + fhot * (1.0 - jnp.exp(-alf * x)) / alf
    # y_0 = 0 by construction; enforce explicitly to avoid log/exp drift.
    y = y.at[0].set(0.0)
    f = jnp.exp(y)
    # Per-segment contribution (i = 1..20): (f_i - f_{i-1}) * (x_i - x_{i-1}) / (y_i - y_{i-1}).
    df = f[1:] - f[:-1]
    dx = x[1:] - x[:-1]
    dy = y[1:] - y[:-1]
    contrib = jnp.where(jnp.abs(dy) > 1e-12, df * dx / dy, 0.0)
    sumint = jnp.sum(contrib)
    sumint = jnp.where(jnp.isnan(sumint), 0.0, sumint)
    tsstoo = f[-1]
    return tsstoo, sumint


def four_sail(
    rho: jnp.ndarray,
    tau: jnp.ndarray,
    lidfa: jnp.ndarray,
    lidfb: jnp.ndarray,
    typelidf: int,
    lai: jnp.ndarray,
    hotspot: jnp.ndarray,
    tts: jnp.ndarray,
    tto: jnp.ndarray,
    psi: jnp.ndarray,
    rsoil: jnp.ndarray,
):
    """4SAIL forward model. `typelidf` is a Python int (compile-time)."""
    cts = jnp.cos(jnp.deg2rad(tts))
    cto = jnp.cos(jnp.deg2rad(tto))
    ctscto = cts * cto
    tants = jnp.tan(jnp.deg2rad(tts))
    tanto = jnp.tan(jnp.deg2rad(tto))
    cospsi = jnp.cos(jnp.deg2rad(psi))
    dso = jnp.sqrt(tants ** 2 + tanto ** 2 - 2.0 * tants * tanto * cospsi)

    if typelidf == 1:
        lidf = _verhoef_bimodal(lidfa, lidfb, n_elements=18)
    elif typelidf == 2:
        lidf = _campbell(lidfa, n_elements=18)
    else:
        raise ValueError("typelidf must be 1 (Verhoef bimodal) or 2 (ellipsoidal)")

    ks, ko, bf, sob, sof = _weighted_sum_over_lidf(lidf, tts, tto, psi)

    sdb = 0.5 * (ks + bf)
    sdf = 0.5 * (ks - bf)
    dob = 0.5 * (ko + bf)
    dof = 0.5 * (ko - bf)
    ddb = 0.5 * (1.0 + bf)
    ddf = 0.5 * (1.0 - bf)

    sigb = ddb * rho + ddf * tau
    sigf = ddf * rho + ddb * tau
    # Numerical floor matches reference NumPy implementation.
    sigf = jnp.where(sigf == 0.0, 1e-36, sigf)
    sigb = jnp.where(sigb == 0.0, 1e-36, sigb)

    att = 1.0 - sigf
    m = jnp.sqrt(jnp.maximum(att ** 2 - sigb ** 2, 0.0))
    sb = sdb * rho + sdf * tau
    sf = sdf * rho + sdb * tau
    vb = dob * rho + dof * tau
    vf = dof * rho + dob * tau
    w = sob * rho + sof * tau

    # ---- canopy with vegetation (lai > 0) ----
    e1 = jnp.exp(-m * lai)
    e2 = e1 ** 2
    rinf = (att - m) / sigb
    rinf2 = rinf ** 2
    re = rinf * e1
    denom = 1.0 - rinf2 * e2

    J1ks = _Jfunc1(ks, m, lai)
    J2ks = _Jfunc2(ks, m, lai)
    J1ko = _Jfunc1(ko, m, lai)
    J2ko = _Jfunc2(ko, m, lai)

    Pss = (sf + sb * rinf) * J1ks
    Qss = (sf * rinf + sb) * J2ks
    Pv = (vf + vb * rinf) * J1ko
    Qv = (vf * rinf + vb) * J2ko

    tdd_v = (1.0 - rinf2) * e1 / denom
    rdd_v = rinf * (1.0 - e2) / denom
    tsd_v = (Pss - re * Qss) / denom
    rsd_v = (Qss - re * Pss) / denom
    tdo_v = (Pv - re * Qv) / denom
    rdo_v = (Qv - re * Pv) / denom

    # Thermal sd gamma factors (Verhoef et al. 2007, Eq. for gammasdf/gammasdb).
    gammasdf_v = (1.0 + rinf) * (J1ks - re * J2ks) / denom
    gammasdb_v = (1.0 + rinf) * (J2ks - re * J1ks) / denom

    tss_v = jnp.exp(-ks * lai)
    too_v = jnp.exp(-ko * lai)
    z = _Jfunc2(ks, ko, lai)
    g1 = (z - J1ks * too_v) / (ko + m)
    g2 = (z - J1ko * tss_v) / (ks + m)
    Tv1 = (vf * rinf + vb) * g1
    Tv2 = (vf + vb * rinf) * g2
    T1 = Tv1 * (sf + sb * rinf)
    T2 = Tv2 * (sf * rinf + sb)
    T3 = (rdo_v * Qss + tdo_v * Pss) * rinf
    rsod_v = (T1 + T2 - T3) / (1.0 - rinf2)

    # Thermal multiple-scattering gamma factor.
    T4 = Tv1 * (1.0 + rinf)
    T5 = Tv2 * (1.0 + rinf)
    T6 = (rdo_v * J2ks + tdo_v * J1ks) * (1.0 + rinf) * rinf
    gammasod_v = (T4 + T5 - T6) / (1.0 - rinf2)

    # Hotspot.
    alf_pre = jnp.where(hotspot > 0.0, (dso / jnp.maximum(hotspot, 1e-12)) * 2.0 / (ks + ko), 1e36)
    # alf == 0 limit: pure hotspot.
    is_pure = alf_pre == 0.0
    safe_alf = jnp.where(is_pure, 1.0, alf_pre)
    tsstoo_simp, sumint_simp = _hotspot_simpson(safe_alf, lai, ko, ks)
    tsstoo_v = jnp.where(is_pure, tss_v, tsstoo_simp)
    sumint_v = jnp.where(is_pure, (1.0 - tss_v) / (ks * lai), sumint_simp)

    rsos_v = w * lai * sumint_v
    gammasos_v = ko * lai * sumint_v
    gammaso_v = gammasos_v + gammasod_v
    rso_v = rsos_v + rsod_v

    # ---- LAI <= 0 fallback (no canopy: everything passes to soil) ----
    no_canopy = lai <= 0.0
    tss = jnp.where(no_canopy, 1.0, tss_v)
    too = jnp.where(no_canopy, 1.0, too_v)
    tsstoo = jnp.where(no_canopy, 1.0, tsstoo_v)
    rdd = jnp.where(no_canopy, 0.0, rdd_v)
    tdd = jnp.where(no_canopy, 1.0, tdd_v)
    rsd = jnp.where(no_canopy, 0.0, rsd_v)
    tsd = jnp.where(no_canopy, 0.0, tsd_v)
    rdo = jnp.where(no_canopy, 0.0, rdo_v)
    tdo = jnp.where(no_canopy, 0.0, tdo_v)
    rso = jnp.where(no_canopy, 0.0, rso_v)
    gammasdf = jnp.where(no_canopy, 0.0, gammasdf_v)
    gammasdb = jnp.where(no_canopy, 0.0, gammasdb_v)
    gammaso = jnp.where(no_canopy, 0.0, gammaso_v)

    # Soil interaction.
    dn = jnp.maximum(1.0 - rsoil * rdd, 1e-36)
    rddt = rdd + tdd * rsoil * tdd / dn
    rsdt = rsd + (tsd + tss) * rsoil * tdd / dn
    rdot = rdo + tdd * rsoil * (tdo + too) / dn
    rsodt = ((tss + tsd) * tdo + (tsd + tss * rsoil * rdd) * too) * rsoil / dn
    rsost = rso + tsstoo * rsoil
    rsot = rsost + rsodt

    return {
        "rsot": rsot,       # bidirectional surface reflectance (SDR)
        "rddt": rddt,       # bi-hemispherical (BHR)
        "rsdt": rsdt,       # directional-hemispherical (DHR)
        "rdot": rdot,       # hemispherical-directional (HDR)
        "tss": tss,         # beam transmittance (sun path)
        "too": too,         # beam transmittance (observer path)
        "tdd": tdd,         # canopy bi-hemispherical transmittance
        "rdd": rdd,         # canopy bi-hemispherical reflectance
        "rdo": rdo,         # canopy hemispherical-directional reflectance
        "tdo": tdo,         # canopy hemispherical-directional transmittance
        "gammasdf": gammasdf,  # thermal forward-scattering sd factor
        "gammasdb": gammasdb,  # thermal backward-scattering sd factor
        "gammaso": gammaso,    # thermal so factor (single + multiple scattering)
    }


# ---------------------------------------------------------------------------
# Thermal SAIL
# ---------------------------------------------------------------------------


def run_thermal_sail(
    lam: jnp.ndarray,
    tveg: jnp.ndarray,
    tsoil: jnp.ndarray,
    tveg_sunlit: jnp.ndarray,
    tsoil_sunlit: jnp.ndarray,
    t_atm: jnp.ndarray,
    lai: jnp.ndarray,
    lidfa: jnp.ndarray,
    hspot: jnp.ndarray,
    tts: jnp.ndarray,
    tto: jnp.ndarray,
    psi: jnp.ndarray,
    *,
    refl: jnp.ndarray,
    rsoil: jnp.ndarray,
    typelidf: int = 2,
    lidfb: jnp.ndarray = 0.0,
):
    """Thermal SAIL forward model (Verhoef et al. 2007).

    Computes directional thermal radiance, brightness temperature, and
    directional emissivity for a single wavelength (or broadband array).

    Parameters
    ----------
    lam : wavelength in µm.
    tveg : shade leaf temperature (K).
    tsoil : shade soil temperature (K).
    tveg_sunlit : sunlit leaf temperature (K).
    tsoil_sunlit : sunlit soil temperature (K).
    t_atm : effective sky temperature (K).
    refl : leaf reflectance at `lam` (scalar or wavelength array).
    rsoil : soil reflectance at `lam`.

    Returns
    -------
    Lw : directional radiance (W m⁻² sr⁻¹ µm⁻¹).
    Tbright : directional brightness temperature (K).
    dir_em : directional emissivity (= 1 − rdot).
    """
    _C1 = 3.741856e-16   # W⋅m²  (first radiation constant)
    _C2 = 14388.0         # µm⋅K  (second radiation constant)

    top = 1e-6 * _C1 * (lam * 1e-6) ** (-5.0)

    def _planck(T):
        return top / (jnp.exp(_C2 / (lam * T)) - 1.0)

    Hc = _planck(tveg)          # shade leaves
    Hh = _planck(tveg_sunlit)   # sunlit leaves
    Hd = _planck(tsoil)         # shade soil
    Hs = _planck(tsoil_sunlit)  # sunlit soil
    Hsky = _planck(t_atm)       # sky emission

    emv = 1.0 - refl
    ems = 1.0 - rsoil

    # Thermal leaves are opaque: transmittance = 0.
    tau_thermal = jnp.zeros_like(refl)
    out = four_sail(refl, tau_thermal, lidfa, lidfb, typelidf, lai, hspot,
                    tts, tto, psi, rsoil)

    rdd = out["rdd"]
    tdd = out["tdd"]
    rdo = out["rdo"]
    tdo = out["tdo"]
    too = out["too"]
    tss = out["tss"]
    rdot = out["rdot"]
    gammasdf = out["gammasdf"]
    gammaso = out["gammaso"]

    gammad = 1.0 - rdd - tdd
    gammao = 1.0 - rdo - tdo - too

    dn = jnp.maximum(1.0 - rsoil * rdd, 1e-36)
    tso = tss * too + tss * (tdo + rsoil * rdd * too) / dn
    ttot = (too + tdo) / dn
    gammaot = gammao + ttot * rsoil * gammad
    gammasot = gammaso + ttot * rsoil * gammasdf

    aeev = gammaot
    aees = ttot * ems

    Lw = (
        rdot * Hsky
        + aeev * Hc
        + gammasot * emv * (Hh - Hc)
        + aees * Hd
        + tso * ems * (Hs - Hd)
    ) / jnp.pi

    dnoem1 = top / (Lw * jnp.pi)
    Tbright = _C2 / (lam * jnp.log(dnoem1 + 1.0))
    dir_em = 1.0 - rdot

    return Lw, Tbright, dir_em


# ---------------------------------------------------------------------------
# Convenience top-level
# ---------------------------------------------------------------------------


def run_prosail(
    n: jnp.ndarray,
    cab: jnp.ndarray,
    car: jnp.ndarray,
    cbrown: jnp.ndarray,
    cw: jnp.ndarray,
    cm: jnp.ndarray,
    lai: jnp.ndarray,
    lidfa: jnp.ndarray,
    hspot: jnp.ndarray,
    tts: jnp.ndarray,
    tto: jnp.ndarray,
    psi: jnp.ndarray,
    *,
    ant: jnp.ndarray = 0.0,
    coeffs: ProspectDCoeffs,
    soil: SoilCoeffs,
    rsoil: jnp.ndarray = 1.0,
    psoil: jnp.ndarray = 0.5,
    typelidf: int = 2,
    lidfb: jnp.ndarray = 0.0,
    factor: str = "SDR",
    alpha: float = 40.0,
):
    """PROSPECT-D + 4SAIL forward call. Returns the chosen reflectance factor
    over 400-2500 nm (2101 channels).

    `factor` ∈ {"SDR", "BHR", "DHR", "HDR"}.
    """
    refl, trans = prospect_d(n, cab, car, cbrown, cw, cm, ant, coeffs, alpha=alpha)
    rsoil_spec = rsoil * (psoil * soil.rsoil1 + (1.0 - psoil) * soil.rsoil2)
    out = four_sail(refl, trans, lidfa, lidfb, typelidf, lai, hspot, tts, tto, psi, rsoil_spec)
    return out[{"SDR": "rsot", "BHR": "rddt", "DHR": "rsdt", "HDR": "rdot"}[factor]]
