"""Verify the JAX features: jit, vmap, grad, plus edge cases."""

import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

import prosail as ref
import prosail_jax as pj

jax.config.update("jax_enable_x64", True)
data_dir = Path(ref.__file__).parent
coeffs, soil = pj.load_coeffs(data_dir)


def forward(n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi):
    return pj.run_prosail(
        n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi,
        coeffs=coeffs, soil=soil, typelidf=2, factor="SDR",
    )


# === JIT ===
print("=== JIT ===")
jforward = jax.jit(forward)
params = (1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, 60.0, 0.1, 30.0, 10.0, 90.0)
# Warmup
out = jforward(*params).block_until_ready()
t0 = time.perf_counter()
for _ in range(100):
    out = jforward(*params).block_until_ready()
t_jit = (time.perf_counter() - t0) / 100
print(f"  jit forward (mean over 100): {t_jit*1000:.2f} ms")

t0 = time.perf_counter()
for _ in range(10):
    ref.run_prosail(*params, prospect_version="D", typelidf=2, factor="SDR",
                    rsoil=1.0, psoil=0.5)
t_ref = (time.perf_counter() - t0) / 10
print(f"  reference numpy/numba (mean over 10): {t_ref*1000:.2f} ms")

# === VMAP — batched forward over 1000 parameter sets ===
print()
print("=== VMAP (batch of 1000) ===")
rng = np.random.default_rng(0)
B = 1000
batch = {
    "n": rng.uniform(1.2, 2.5, B), "cab": rng.uniform(20, 80, B),
    "car": rng.uniform(5, 20, B), "cbrown": rng.uniform(0, 0.5, B),
    "cw": rng.uniform(0.005, 0.04, B), "cm": rng.uniform(0.003, 0.02, B),
    "lai": rng.uniform(0.5, 6, B), "lidfa": rng.uniform(30, 70, B),
    "hspot": rng.uniform(0.05, 0.2, B), "tts": rng.uniform(20, 60, B),
    "tto": rng.uniform(0, 30, B), "psi": rng.uniform(0, 180, B),
}
batch = {k: jnp.asarray(v) for k, v in batch.items()}

vforward = jax.jit(jax.vmap(forward))
out = vforward(**batch).block_until_ready()  # warmup
t0 = time.perf_counter()
for _ in range(10):
    out = vforward(**batch).block_until_ready()
t_vmap = (time.perf_counter() - t0) / 10
print(f"  vmap forward (B={B}, mean over 10): {t_vmap*1000:.2f} ms")
print(f"  output shape: {out.shape}")
print(f"  per-sample: {t_vmap/B*1e6:.1f} us")
print(f"  speedup over reference per-call: {t_ref/(t_vmap/B):.1f}x")

# === GRAD ===
print()
print("=== GRAD ===")

def loss(n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi, target):
    pred = forward(n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi)
    return jnp.mean((pred - target) ** 2)

target = forward(*params)
gradfn = jax.jit(jax.grad(loss, argnums=tuple(range(12))))
g = gradfn(*params, target)
print(f"  grad at solution (should be ~0): max|g|={max(float(jnp.abs(gi)) for gi in g):.2e}")

# Off-target gradient should be finite and non-zero.
off = (1.7, 50.0, 12.0, 0.05, 0.012, 0.008, 2.5, 55.0, 0.08, 35.0, 5.0, 80.0)
g_off = gradfn(*off, target)
finite = all(jnp.isfinite(gi).all() for gi in g_off)
nonzero = any(float(jnp.abs(gi)) > 0 for gi in g_off)
print(f"  off-target grad finite={finite}  nonzero={nonzero}")
print(f"  d/d_lai = {float(g_off[6]):.4e}")
print(f"  d/d_cab = {float(g_off[1]):.4e}")
print(f"  d/d_tts = {float(g_off[9]):.4e}")

# === Edge cases ===
print()
print("=== Edge cases ===")

# LAI = 0 (no canopy) → output should equal soil reflectance at all bands.
out_lai0 = forward(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 0.0, 60.0, 0.1, 30.0, 10.0, 90.0)
ref_lai0 = ref.run_prosail(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 0.0, 60.0, 0.1, 30.0, 10.0, 90.0,
                           prospect_version="D", typelidf=2, factor="SDR", rsoil=1.0, psoil=0.5)
d_lai0 = float(np.max(np.abs(np.asarray(out_lai0) - ref_lai0)))
print(f"  LAI=0:    max|d|={d_lai0:.2e}")

# Hotspot = 0 (pure hotspot limit)
out_h0 = forward(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, 60.0, 0.0, 30.0, 10.0, 90.0)
ref_h0 = ref.run_prosail(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, 60.0, 0.0, 30.0, 10.0, 90.0,
                         prospect_version="D", typelidf=2, factor="SDR", rsoil=1.0, psoil=0.5)
d_h0 = float(np.max(np.abs(np.asarray(out_h0) - ref_h0)))
print(f"  hspot=0:  max|d|={d_h0:.2e}")

# typelidf=1 (Verhoef bimodal). Reference values: spherical (-0.35,-0.15).
out_v = pj.run_prosail(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, -0.35, 0.1, 30.0, 10.0, 90.0,
                       coeffs=coeffs, soil=soil, typelidf=1, lidfb=-0.15, factor="SDR")
ref_v = ref.run_prosail(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, -0.35, 0.1, 30.0, 10.0, 90.0,
                        prospect_version="D", typelidf=1, lidfb=-0.15, factor="SDR",
                        rsoil=1.0, psoil=0.5)
d_v = float(np.max(np.abs(np.asarray(out_v) - ref_v)))
print(f"  Verhoef:  max|d|={d_v:.2e}")

# Nadir view
out_n = forward(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, 60.0, 0.1, 30.0, 0.0, 0.0)
ref_n = ref.run_prosail(1.5, 40.0, 10.0, 0.1, 0.015, 0.009, 3.0, 60.0, 0.1, 30.0, 0.0, 0.0,
                        prospect_version="D", typelidf=2, factor="SDR", rsoil=1.0, psoil=0.5)
d_n = float(np.max(np.abs(np.asarray(out_n) - ref_n)))
print(f"  nadir:    max|d|={d_n:.2e}")
