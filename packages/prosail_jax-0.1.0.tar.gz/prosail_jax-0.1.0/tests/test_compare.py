"""Compare prosail_jax against jgomezdans/prosail on a parameter grid."""

from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

import prosail as ref  # the reference NumPy implementation
import prosail_jax as pj

jax.config.update("jax_enable_x64", True)

# Load coefficients for the JAX port from the reference package's data files.
data_dir = Path(ref.__file__).parent
coeffs, soil = pj.load_coeffs(data_dir)


def _ref_call(params):
    n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi = params
    return ref.run_prosail(
        n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi,
        prospect_version="D", typelidf=2, factor="SDR",
        rsoil=1.0, psoil=0.5,
    )


def _jax_call(params):
    n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi = params
    return pj.run_prosail(
        n, cab, car, cbrown, cw, cm, lai, lidfa, hspot, tts, tto, psi,
        coeffs=coeffs, soil=soil, typelidf=2, factor="SDR",
    )


# === Test 1: PROSPECT-D in isolation ============================================
def test_prospect():
    rng = np.random.default_rng(0)
    diffs = []
    for _ in range(5):
        n = float(rng.uniform(1.2, 2.5))
        cab = float(rng.uniform(20, 80))
        car = float(rng.uniform(5, 20))
        cbrown = float(rng.uniform(0, 0.5))
        cw = float(rng.uniform(0.005, 0.04))
        cm = float(rng.uniform(0.003, 0.02))
        ant = float(rng.uniform(0, 5))

        # Reference uses ant in PROSPECT-D
        _, ref_refl, ref_tran = ref.prospect_d.run_prospect(
            n, cab, car, cbrown, cw, cm, ant=ant, prospect_version="D"
        )
        jax_refl, jax_tran = pj.prospect_d(
            n, cab, car, cbrown, cw, cm, ant, coeffs, alpha=40.0
        )
        d_refl = float(np.max(np.abs(np.asarray(jax_refl) - ref_refl)))
        d_tran = float(np.max(np.abs(np.asarray(jax_tran) - ref_tran)))
        diffs.append((d_refl, d_tran))
        print(f"  prospect: max|d_refl|={d_refl:.2e}  max|d_tran|={d_tran:.2e}")
    return diffs


# === Test 2: full PROSAIL on realistic crop parameter ranges ====================
def test_full_prosail():
    rng = np.random.default_rng(42)
    diffs = []
    for _ in range(5):
        params = (
            float(rng.uniform(1.2, 2.5)),    # n
            float(rng.uniform(20, 80)),       # cab
            float(rng.uniform(5, 20)),        # car
            float(rng.uniform(0, 0.5)),       # cbrown
            float(rng.uniform(0.005, 0.04)),  # cw
            float(rng.uniform(0.003, 0.02)),  # cm
            float(rng.uniform(0.5, 6.0)),     # lai
            float(rng.uniform(30, 70)),       # lidfa (mean leaf angle for typelidf=2)
            float(rng.uniform(0.05, 0.2)),    # hspot
            float(rng.uniform(20, 60)),       # tts
            float(rng.uniform(0, 30)),        # tto
            float(rng.uniform(0, 180)),       # psi
        )
        ref_out = _ref_call(params)
        jax_out = np.asarray(_jax_call(params))
        d = float(np.max(np.abs(jax_out - ref_out)))
        med = float(np.median(np.abs(jax_out - ref_out)))
        diffs.append(d)
        print(f"  prosail: max|d|={d:.2e}  median|d|={med:.2e}  "
              f"(lai={params[6]:.2f}, mla={params[7]:.1f})")
    return diffs


print("=== PROSPECT-D ===")
test_prospect()
print()
print("=== Full PROSAIL ===")
test_full_prosail()
