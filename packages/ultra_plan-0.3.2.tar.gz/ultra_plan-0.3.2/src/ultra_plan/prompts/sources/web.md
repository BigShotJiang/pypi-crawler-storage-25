## Source: web

General web fallback for items the other sources miss — niche libraries, vendor docs, SaaS API references.

### How to query

- WebSearch with the task plus disambiguators: `<task> library`, `<task> cli`, `<task> python sdk`, `<task> documentation`. Include the current year when looking for "latest" or recency-sensitive results (Claude's knowledge cutoff is older than the user's working date).
- For each promising hit, WebFetch the page to confirm the project still exists, is maintained, and matches the task (don't trust titles alone — link-rot and abandoned repos are common).
- Prefer official vendor docs and primary-source repos over blog aggregators, "top 10" listicles, and content farms.

### What to skip

- Don't use this source for MCP servers — that's the `mcp` source.
- Don't use this source for Claude Skills — that's `anthropic` (first-party) or `github` (community).
- Don't cite a blog post as `source_url` when the underlying project has its own repo or docs page; cite the canonical source.

### How to record matches

- Set `kind` = `lib` (importable package), `cli` (command-line tool), or omit if it's pure documentation/reference.
- `install` should be the actual install command from the project's README (`pip install …`, `npm i …`, `brew install …`, etc.) — verbatim, not paraphrased.
- `source_url` should be the project's homepage, official docs, or canonical repo — whichever a user would land on first when verifying the recommendation.
