## Source: anthropic

First-party Anthropic resources. Prefer these over community alternatives when they cover the task.

### Where to look

- **Skills docs**: WebFetch `https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview` for the canonical Skill format (SKILL.md + YAML frontmatter), progressive-disclosure model, and security rules.
- **Claude Code docs**: WebFetch under `https://code.claude.com/docs/en/` for skills, plugins, hooks, slash-commands, and settings.json schemas. Use this when the task requires Claude Code-specific extensibility.
- **Official skills repo**: `https://github.com/anthropics/skills` — reference Skills (creative, technical, enterprise) plus the `skills/skill-creator/` authoring guide. Use the path `https://github.com/anthropics/skills/tree/main/skills/<name>` as `source_url` when citing a specific skill.
- **Skills cookbook**: `https://platform.claude.com/cookbook/skills-notebooks-01-skills-introduction` for end-to-end authoring examples.
- **Anthropic GitHub orgs**: `https://github.com/anthropics` and `https://github.com/anthropic-experimental` for reference agents, prompt libraries, and SDK samples.

### How to record matches

- For Skills from `anthropics/skills`, set `origin` = `anthropic`. For everything else (community awesome-lists, third-party plugins), set `origin` = `github`.
- For an `anthropics/skills` install, prefer the plugin-marketplace form: `install` = `/plugin marketplace add anthropics/skills && /plugin install <skill>@anthropic-agent-skills`. The manual fallback is to copy the skill folder into `~/.claude/skills/<name>/` (must contain `SKILL.md`).
- A valid Skill `name` is lowercase-kebab, ≤64 chars, and must not contain "anthropic" or "claude" — flag any candidate that violates this in the `rationale`.
- If a first-party Skill covers the task, list it first in `skills[]` and note "first-party" in `rationale`.
