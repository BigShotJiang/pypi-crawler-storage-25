## Source: github

Search GitHub for Skills, agents, plugins, and tools that match the task.

### Where to look

- **Claude Code ecosystem**: `https://github.com/hesreallyhim/awesome-claude-code` (skills, hooks, slash-commands, orchestrators, plugins) and `https://github.com/VoltAgent/awesome-agent-skills` (1000+ skills compatible with Claude Code, Codex, Gemini CLI).
- **MCP ecosystem** (overlaps with the `mcp` source — use it for richer coverage): `https://github.com/wong2/awesome-mcp-servers`, `https://github.com/punkpeye/awesome-mcp-servers`, `https://github.com/tolkonepiu/best-of-mcp-servers`.
- **Repo topics**: Search `https://github.com/topics/<topic>` for `claude-skill`, `claude-code`, `claude-code-plugin`, `agent-skills`, `mcp-server`, plus task-specific keywords (e.g. `postgres`, `kubernetes`).
- **Code search**: For SKILL.md / plugin scaffolds, use GitHub code search like `path:SKILL.md <keyword>` or `filename:.claude-plugin/marketplace.json`.

### Ranking and filtering

- Prefer repos with ≥50 stars and a commit in the last 6 months. Drop archived repos and forks-without-divergence.
- Prefer repos whose README explicitly documents Claude Code / MCP integration over generic LLM tooling.
- When two repos cover the same need, pick the one with clearer install instructions in its README.

### How to record matches

- `source_url`: canonical repo URL (`https://github.com/<owner>/<repo>` or a subpath like `/tree/main/skills/<name>`).
- For Skills: set `origin` = `github` and put the install command in `install` (typically a Claude Code `/plugin install` form, a `git clone … && cp -r … ~/.claude/skills/`, or a marketplace add).
- For CLIs/libraries found on GitHub: set `kind` accordingly (`cli` or `lib`), not `mcp` — that source owns MCP servers.
- Briefly note stars and last-commit month in `rationale` so the user can audit the recency call.
