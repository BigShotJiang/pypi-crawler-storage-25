## Source: mcp

Find MCP servers that give Claude direct access to the task's data or systems.

### Where to look (in priority order)

1. **Official MCP Registry** — `https://registry.modelcontextprotocol.io` (API frozen at v0.1 since Oct 2025). This is the authoritative directory. Browse the web UI or hit the REST API at `https://registry.modelcontextprotocol.io/v0/servers?search=<keyword>` to filter. Live API docs at `/docs`.
2. **Reference servers** — `https://github.com/modelcontextprotocol/servers` for the canonical first-party implementations (filesystem, fetch, git, memory, etc.) and the broader community list in its README.
3. **Ranked community catalog** — `https://github.com/tolkonepiu/best-of-mcp-servers` is updated weekly with star/recency ranking across ~400 servers in 34 categories. Good for quick triage.
4. **Curated awesome-lists** — `https://github.com/wong2/awesome-mcp-servers` and `https://github.com/punkpeye/awesome-mcp-servers` for additional community entries.
5. **Hosted directories** — `https://mcp.so` and `https://glama.ai/mcp` when you need a one-line description plus install snippet.

### How to record matches

- Set `kind` = `mcp`.
- `source_url` must point at the server's canonical repo (or registry entry), not a blog post or aggregator.
- `install` should be the exact invocation the user runs. Common forms:
  - Reference servers: `npx -y @modelcontextprotocol/server-<name>`
  - Python servers: `uvx <package>` or `pipx run <package>`
  - Docker: `docker run --rm -i <image>`
  - Vendor-specific: copy from the server's README verbatim.
- `auth` should name the required credentials (env var names, OAuth flow, or "none"). Do not invent variable names — copy from the server's README.
- Prefer servers with recent commits (<6 months) and >100 stars unless a first-party vendor server exists, in which case prefer the vendor's.
