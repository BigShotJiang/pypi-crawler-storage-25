"""Comprehensive security test coverage for critical attack vectors.

This test suite extends the existing security tests to cover:
1. CSRF token validation (timing-safe comparison, header vs query param)
2. Origin validation (same-origin enforcement, IPv6 origins)
3. Path traversal attacks (../, symlinks, absolute paths)
4. Request body size limits (MAX_BODY enforcement, 413 responses)
5. JSON Schema validation attacks (deeply nested, huge strings)
6. IPv6 dual-stack binding (loopback-only, graceful fallback)

These tests target the threat model defined in SECURITY.md:
- Prompt injection via web sources
- Escape from preflight sandbox
- CSRF against local review server
- Sandbox escape via execute working directory
- Local DoS against review server
"""
from __future__ import annotations

import json
import secrets
import socket
import threading
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

import pytest

from tests.fixtures import valid_bundle
from ultra_plan._io import atomic_write_text
from ultra_plan.review import server as srv
from ultra_plan.validate import format_validation_error, validate_bundle

# ============================================================================
# CSRF Token Validation Tests
# ============================================================================


def _start_server_with_token(out_dir: Path, token: str = ""):
    """Helper to start server with a specific token."""
    handler = type(
        "T",
        (srv._Handler,),
        {"out_dir": out_dir, "token": token, "ratelimiter": None, "all_servers": []},
    )
    s = srv.BoundedThreadingHTTPServer(("127.0.0.1", 0), handler)
    t = threading.Thread(target=s.serve_forever, daemon=True)
    t.start()
    return s, t


def _http_put_with_headers(host: str, port: int, path: str, body: bytes, headers: dict):
    """Helper for PUT requests with custom headers."""
    req = urllib.request.Request(
        f"http://{host}:{port}{path}", data=body, method="PUT", headers=headers
    )
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def _http_post_with_headers(host: str, port: int, path: str, body: bytes, headers: dict):
    """Helper for POST requests with custom headers."""
    req = urllib.request.Request(
        f"http://{host}:{port}{path}", data=body, method="POST", headers=headers
    )
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def test_csrf_token_required_on_put_bundle(tmp_path: Path) -> None:
    """PUT /bundle requires valid X-Ultra-Plan-Token header."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # Without token - should be rejected
        status, resp = _http_put_with_headers(host, port, "/bundle", body, {})
        assert status == 403
        assert b"forbidden token" in resp

        # With correct token - should succeed
        status, resp = _http_put_with_headers(
            host, port, "/bundle", body, {"X-Ultra-Plan-Token": token}
        )
        assert status == 200
        assert b'"ok":true' in resp
    finally:
        s.shutdown()
        s.server_close()


def test_csrf_token_rejects_wrong_token(tmp_path: Path) -> None:
    """PUT /bundle rejects incorrect tokens."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    correct_token = secrets.token_urlsafe(32)
    wrong_token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, correct_token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        status, resp = _http_put_with_headers(
            host, port, "/bundle", body, {"X-Ultra-Plan-Token": wrong_token}
        )
        assert status == 403
        assert b"forbidden token" in resp
    finally:
        s.shutdown()
        s.server_close()


def test_csrf_token_fallback_to_query_param(tmp_path: Path) -> None:
    """PUT /bundle accepts token via ?token= query parameter as fallback."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # Token in query param - should succeed
        req = urllib.request.Request(
            f"http://{host}:{port}/bundle?token={token}",
            data=body,
            method="PUT",
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            assert resp.status == 200
    finally:
        s.shutdown()
        s.server_close()


def test_csrf_token_required_on_post_confirm(tmp_path: Path) -> None:
    """POST /confirm requires valid CSRF token."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # Without token - should be rejected
        status, resp = _http_post_with_headers(host, port, "/confirm", body, {})
        assert status == 403
        assert b"forbidden token" in resp

        # With token - should succeed
        status, resp = _http_post_with_headers(
            host, port, "/confirm", body, {"X-Ultra-Plan-Token": token}
        )
        assert status == 200
    finally:
        s.shutdown()
        s.server_close()


# ============================================================================
# Origin Validation Tests
# ============================================================================


def test_origin_same_origin_allowed(tmp_path: Path) -> None:
    """PUT /bundle accepts same-origin requests."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # Same-origin header
        headers = {
            "X-Ultra-Plan-Token": token,
            "Origin": f"http://127.0.0.1:{port}",
        }
        status, resp = _http_put_with_headers(host, port, "/bundle", body, headers)
        assert status == 200
    finally:
        s.shutdown()
        s.server_close()


def test_origin_cross_origin_rejected(tmp_path: Path) -> None:
    """PUT /bundle rejects cross-origin requests."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # Cross-origin header
        headers = {
            "X-Ultra-Plan-Token": token,
            "Origin": "http://evil.com:8080",
        }
        status, resp = _http_put_with_headers(host, port, "/bundle", body, headers)
        assert status == 403
        assert b"forbidden origin" in resp
    finally:
        s.shutdown()
        s.server_close()


def test_origin_missing_header_allowed(tmp_path: Path) -> None:
    """PUT /bundle allows requests without Origin header (same-origin form posts)."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        # No Origin header (typical for same-origin form posts)
        headers = {"X-Ultra-Plan-Token": token}
        status, resp = _http_put_with_headers(host, port, "/bundle", body, headers)
        assert status == 200
    finally:
        s.shutdown()
        s.server_close()


def test_origin_localhost_variants_accepted(tmp_path: Path) -> None:
    """PUT /bundle accepts localhost and [::1] as valid same-origin."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address
        body = json.dumps(valid_bundle()).encode()

        for origin in [
            f"http://localhost:{port}",
            f"http://[::1]:{port}",
        ]:
            headers = {"X-Ultra-Plan-Token": token, "Origin": origin}
            status, resp = _http_put_with_headers(host, port, "/bundle", body, headers)
            assert status == 200, f"Origin {origin} should be accepted"
    finally:
        s.shutdown()
        s.server_close()


# ============================================================================
# Request Body Size Limit Tests
# ============================================================================


def test_put_bundle_rejects_oversized_body(tmp_path: Path) -> None:
    """PUT /bundle returns 413 for bodies exceeding MAX_BODY (10 MiB)."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address

        # Create body just over 10 MiB limit
        oversized = b"x" * (srv.MAX_BODY + 1)
        headers = {"X-Ultra-Plan-Token": token, "Content-Length": str(len(oversized))}

        # Server closes connection before reading full body - this is correct behavior
        # Client may see BrokenPipeError or get 413 response depending on timing
        try:
            status, resp = _http_put_with_headers(host, port, "/bundle", oversized, headers)
            assert status == 413
            assert b"request body too large" in resp
        except (BrokenPipeError, ConnectionAbortedError, urllib.error.URLError) as e:
            # Server closed connection early - expected for oversized body
            if isinstance(e, urllib.error.URLError):
                assert "Broken pipe" in str(e) or "Connection" in str(e)
    finally:
        s.shutdown()
        s.server_close()


def test_put_bundle_accepts_body_at_limit(tmp_path: Path) -> None:
    """PUT /bundle accepts bodies at exactly MAX_BODY size."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address

        # Create valid JSON bundle that's large but under limit
        # (We won't actually test 10MiB due to test performance, but verify the logic)
        bundle = valid_bundle()
        bundle["plan_markdown"] = "x" * 1000  # Small test payload
        body = json.dumps(bundle).encode()

        headers = {"X-Ultra-Plan-Token": token}
        status, resp = _http_put_with_headers(host, port, "/bundle", body, headers)
        assert status == 200
    finally:
        s.shutdown()
        s.server_close()


def test_post_confirm_rejects_oversized_body(tmp_path: Path) -> None:
    """POST /confirm returns 413 for oversized bodies."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address

        oversized = b"x" * (srv.MAX_BODY + 1)
        headers = {"X-Ultra-Plan-Token": token}

        # Server closes connection before reading full body - expected behavior
        try:
            status, resp = _http_post_with_headers(host, port, "/confirm", oversized, headers)
            assert status == 413
        except (BrokenPipeError, ConnectionAbortedError, urllib.error.URLError) as e:
            # Server closed connection early - expected for oversized body
            if isinstance(e, urllib.error.URLError):
                assert "Broken pipe" in str(e) or "Connection" in str(e)
    finally:
        s.shutdown()
        s.server_close()


def test_malformed_content_length_rejected(tmp_path: Path) -> None:
    """PUT /bundle handles malformed Content-Length gracefully."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    token = secrets.token_urlsafe(32)
    s, _ = _start_server_with_token(tmp_path, token)
    try:
        host, port = s.server_address

        # Malformed Content-Length should be treated as 0 or rejected
        # The implementation treats invalid length as None, triggering 413
        body = json.dumps(valid_bundle()).encode()
        headers = {"X-Ultra-Plan-Token": token, "Content-Length": "invalid"}

        # This will fail at urllib level or be rejected by _read_body
        # Just verify the server doesn't crash
        try:
            _http_put_with_headers(host, port, "/bundle", body, headers)
        except (urllib.error.HTTPError, urllib.error.URLError):
            pass  # Expected
    finally:
        s.shutdown()
        s.server_close()


# ============================================================================
# JSON Schema Validation Tests
# ============================================================================


def test_validate_bundle_rejects_deeply_nested_json(tmp_path: Path) -> None:
    """Validate bundle handles deeply nested JSON without crashing."""
    # Create deeply nested structure (potential parser DoS)
    nested = {"a": None}
    current = nested
    for _ in range(100):
        current["a"] = {"a": None}
        current = current["a"]

    bundle = valid_bundle()
    bundle["plan_markdown"] = json.dumps(nested) if isinstance(nested, dict) else nested

    # Should validate without crashing (nesting is in a string field)
    validate_bundle(bundle)


def test_validate_bundle_rejects_missing_required_fields() -> None:
    """Validate bundle rejects bundles missing required fields."""
    from jsonschema import ValidationError

    incomplete = {"task": "test"}

    with pytest.raises(ValidationError) as exc_info:
        validate_bundle(incomplete)

    err_msg = format_validation_error(exc_info.value)
    assert "required" in err_msg.lower()


def test_validate_bundle_rejects_additional_properties() -> None:
    """Validate bundle rejects bundles with unexpected top-level fields."""
    from jsonschema import ValidationError

    bundle = valid_bundle()
    bundle["unexpected_field"] = "should fail"

    with pytest.raises(ValidationError) as exc_info:
        validate_bundle(bundle)

    err_msg = format_validation_error(exc_info.value)
    assert "additional" in err_msg.lower() or "unexpected" in err_msg.lower()


def test_format_validation_error_truncates_large_values() -> None:
    """Format validation error truncates large offending values."""
    from jsonschema import ValidationError

    bundle = valid_bundle()
    bundle["task"] = "x" * 500  # Large value
    bundle["skills"] = "not an array"  # Wrong type

    try:
        validate_bundle(bundle)
    except ValidationError as e:
        formatted = format_validation_error(e)
        # Should contain truncated value (max 200 chars + "...")
        assert len(formatted) < 1000
        assert "..." in formatted or len(str(e.instance)) <= 200


# ============================================================================
# Path Traversal and Symlink Attack Tests
# ============================================================================


def test_atomic_write_text_does_not_follow_symlinks(tmp_path: Path) -> None:
    """atomic_write_text does not follow symlinks - provides symlink attack protection.

    The atomic rename approach (write to .tmp, then os.replace) replaces the symlink
    itself rather than following it to overwrite the target. This is excellent
    security behavior that prevents symlink-based attacks.
    """
    target = tmp_path / "target.txt"
    target.write_text("original")

    link = tmp_path / "link.txt"
    link.symlink_to(target)

    # Write through the symlink path
    atomic_write_text(link, "updated")

    # Target file should be unchanged (symlink was NOT followed)
    assert target.read_text() == "original"

    # Link should now be a regular file containing "updated"
    assert not link.is_symlink()
    assert link.read_text() == "updated"


def test_atomic_write_text_cleanup_on_failure(tmp_path: Path) -> None:
    """atomic_write_text cleans up .tmp file on write failure."""
    dest = tmp_path / "dest.txt"

    # Simulate write failure by making parent read-only after tmp creation
    with patch.object(Path, "write_text") as mock_write:
        mock_write.side_effect = PermissionError("simulated failure")

        with pytest.raises(PermissionError):
            atomic_write_text(dest, "content")

        # Verify .tmp file is cleaned up
        tmp_file = dest.with_suffix(dest.suffix + ".tmp")
        assert not tmp_file.exists()


def test_cwd_guard_rejects_path_traversal(tmp_path: Path, monkeypatch) -> None:
    """Execute command rejects ../../../ path traversal attempts."""
    from ultra_plan.cli import main

    bundle_dir = tmp_path / "bundle"
    bundle_dir.mkdir()
    (bundle_dir / "bundle.json").write_text(json.dumps(valid_bundle()))

    # Attempt path traversal
    evil_cwd = str(bundle_dir / ".." / ".." / ".." / "etc")

    rc = main([
        "execute", str(bundle_dir),
        "--agent", "claude", "--headless", "--yes",
        "--cwd", evil_cwd,
    ])

    # Should be rejected (exits 1) unless path happens to be inside bundle_dir
    assert rc == 1


def test_cwd_guard_rejects_absolute_paths_outside_bundle(tmp_path: Path) -> None:
    """Execute command rejects absolute paths outside bundle directory."""
    from ultra_plan.cli import main

    bundle_dir = tmp_path / "bundle"
    bundle_dir.mkdir()
    (bundle_dir / "bundle.json").write_text(json.dumps(valid_bundle()))

    # Absolute path outside bundle
    evil_cwd = "/tmp"

    rc = main([
        "execute", str(bundle_dir),
        "--agent", "claude", "--headless", "--yes",
        "--cwd", evil_cwd,
    ])

    assert rc == 1


# ============================================================================
# IPv6 Dual-Stack Binding Tests
# ============================================================================


def test_bind_server_creates_ipv4_and_ipv6_servers(tmp_path: Path) -> None:
    """_bind_server creates both IPv4 and IPv6 servers when available."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    handler = type(
        "T",
        (srv._Handler,),
        {"out_dir": tmp_path, "token": "", "ratelimiter": None, "all_servers": []},
    )

    servers = srv._bind_server(0, handler)
    try:
        # Should have at least IPv4 server
        assert len(servers) >= 1
        assert servers[0].address_family == socket.AF_INET

        # IPv4 should be bound to 127.0.0.1 (loopback only)
        ipv4_host = servers[0].server_address[0]
        assert ipv4_host == "127.0.0.1"

        # May have IPv6 server if system supports it
        if len(servers) == 2:
            assert servers[1].address_family == socket.AF_INET6

            # Both should be on same port
            ipv4_port = servers[0].server_address[1]
            ipv6_port = servers[1].server_address[1]
            assert ipv4_port == ipv6_port

            # IPv6 should be bound to ::1 (loopback only)
            ipv6_host = servers[1].server_address[0]
            assert ipv6_host == "::1"
    finally:
        for s in servers:
            try:
                s.server_close()
            except Exception:
                pass


def test_bind_server_ipv4_only_fallback_when_ipv6_unavailable(tmp_path: Path) -> None:
    """_bind_server gracefully falls back to IPv4-only when IPv6 is unavailable."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    handler = type(
        "T",
        (srv._Handler,),
        {"out_dir": tmp_path, "token": "", "ratelimiter": None, "all_servers": []},
    )

    # Mock IPv6 server creation to fail
    with patch.object(srv, "BoundedThreadingHTTPServerIPv6") as mock_ipv6:
        mock_ipv6.side_effect = OSError("IPv6 not available")

        servers = srv._bind_server(0, handler)
        try:
            # Should still have IPv4 server
            assert len(servers) == 1
            assert servers[0].address_family == socket.AF_INET

            # IPv4 should be bound to 127.0.0.1
            assert servers[0].server_address[0] == "127.0.0.1"
        finally:
            for s in servers:
                try:
                    s.server_close()
                except Exception:
                    pass


def test_ipv6_loopback_only_binding(tmp_path: Path) -> None:
    """IPv6 server binds only to ::1 loopback, not external interfaces."""
    (tmp_path / "bundle.json").write_text(json.dumps(valid_bundle()))
    handler = type(
        "T",
        (srv._Handler,),
        {"out_dir": tmp_path, "token": "", "ratelimiter": None, "all_servers": []},
    )

    try:
        # Create IPv6 server directly
        s = srv.BoundedThreadingHTTPServerIPv6(("::1", 0), handler)
        # IPv6 server_address is a 4-tuple: (host, port, flowinfo, scopeid)
        addr = s.server_address
        host = addr[0]
        port = addr[1]

        # Should be bound to ::1 only
        assert host == "::1"
        assert port > 0

        # Verify it's loopback only (no external access)
        # This is implicit in the bind address, but we verify the address
        assert host in ("::1", "0000:0000:0000:0000:0000:0000:0000:0001")
    except OSError:
        pytest.skip("IPv6 not available on this system")
    finally:
        try:
            s.server_close()
        except Exception:
            pass
