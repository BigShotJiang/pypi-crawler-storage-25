"""Tests that the preflight agents carry the documented deny lists.

These lock in the static, defense-in-depth config that wraps the planning
phase. A regression here would silently re-enable Read/Write/Edit/Bash for
the planning agent or open SSRF paths via WebFetch.
"""
from __future__ import annotations

from ultra_plan.agents.claude import _PREFLIGHT_SETTINGS
from ultra_plan.agents.opencode import _PREFLIGHT_CONFIG


class TestClaudePreflightSettings:
    def test_permissions_deny_block_present(self):
        deny = _PREFLIGHT_SETTINGS.get("permissions", {}).get("deny", [])
        # Core tool denials
        for entry in (
            "Read",
            "Write",
            "Edit",
            "NotebookEdit",
            "Bash",
        ):
            assert entry in deny, f"{entry!r} missing from preflight deny list"

        # SSRF protections - verify comprehensive coverage
        # File system
        assert "WebFetch(file://*)" in deny

        # Localhost (named)
        assert "WebFetch(http://localhost*)" in deny
        assert "WebFetch(https://localhost*)" in deny

        # IPv4 loopback (127.0.0.0/8)
        assert "WebFetch(http://127.*)" in deny
        assert "WebFetch(https://127.*)" in deny

        # IPv6 loopback
        assert any("::1" in e for e in deny), "IPv6 loopback (::1) missing"

        # IPv6 link-local
        assert any("fe80::" in e for e in deny), "IPv6 link-local (fe80::) missing"

        # IPv6 unique local addresses
        assert any("fc00::" in e for e in deny), "IPv6 ULA (fc00::) missing"
        assert any("fd00::" in e for e in deny), "IPv6 ULA (fd00::) missing"

        # AWS metadata
        assert "WebFetch(http://169.254.169.254*)" in deny
        assert "WebFetch(https://169.254.169.254*)" in deny

        # GCP metadata
        assert any("metadata.google.internal" in e for e in deny), "GCP metadata missing"
        assert any("metadata.internal" in e for e in deny), "GCP metadata variant missing"


class TestOpencodePreflightConfig:
    def test_permission_block(self):
        perm = _PREFLIGHT_CONFIG.get("permission", {})
        assert perm.get("read") == "deny"
        assert perm.get("edit") == "deny"
        assert perm.get("write") == "deny"
        assert perm.get("bash") == "deny"
        assert perm.get("external_directory") == "deny"
        assert perm.get("webfetch") == "allow"
        assert perm.get("websearch") == "allow"
