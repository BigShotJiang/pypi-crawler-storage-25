
from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def sf(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = sf(user_prompt)
    print("\nLLM:", answer, "\n")