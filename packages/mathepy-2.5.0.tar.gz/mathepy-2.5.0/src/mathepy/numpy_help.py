from IPython.display import display, Markdown

_CONTENT = r"""
# 🔢 NumPy Complete Help — DVA Exam Reference
> `from mathepy import numpyhelp` | Works best in Jupyter Notebook

---

## 📦 1. Import Convention
```python
import numpy as np
```

---

## 🏗️ 2. Array Creation

| Function | Description | Example |
|---|---|---|
| `np.array([1,2,3])` | From list | `np.array([[1,2],[3,4]])` → 2D |
| `np.zeros((r,c))` | All zeros | `np.zeros((3,4))` |
| `np.ones((r,c))` | All ones | `np.ones((2,3))` |
| `np.full((r,c), val)` | Fill with val | `np.full((2,2), 7)` |
| `np.eye(n)` | Identity matrix | `np.eye(3)` |
| `np.arange(s,e,step)` | Range array | `np.arange(0,10,2)` → [0,2,4,6,8] |
| `np.linspace(s,e,n)` | n evenly spaced | `np.linspace(0,1,5)` → [0,.25,.5,.75,1] |
| `np.random.rand(r,c)` | Uniform [0,1) | `np.random.rand(3,3)` |
| `np.random.randn(r,c)` | Standard normal | `np.random.randn(2,4)` |
| `np.random.randint(lo,hi,size)` | Random ints | `np.random.randint(0,10,(3,3))` |
| `np.random.seed(n)` | Fix randomness | `np.random.seed(42)` |

---

## 📐 3. Array Attributes

```python
a = np.array([[1,2,3],[4,5,6]])
a.shape    # (2, 3)  — (rows, cols)
a.ndim     # 2       — number of dimensions
a.size     # 6       — total elements
a.dtype    # dtype('int64')
a.T        # Transpose
```

---

## ✂️ 4. Indexing & Slicing

### 1D Array
```python
a = np.array([10, 20, 30, 40, 50])
a[0]       # 10   (first)
a[-1]      # 50   (last)
a[1:4]     # [20, 30, 40]
a[::2]     # [10, 30, 50]  (every 2nd)
a[::-1]    # [50, 40, 30, 20, 10]  (reversed)
```

### 2D Array
```python
b = np.arange(1,10).reshape(3,3)
# [[1,2,3],[4,5,6],[7,8,9]]

b[1, 2]      # 6  (row1, col2)
b[0, :]      # [1,2,3]  (entire row 0)
b[:, 1]      # [2,5,8]  (entire col 1)
b[0:2, 1:]   # [[2,3],[5,6]]
b[-1, :]     # [7,8,9]  (last row)
```

---

## 🎭 5. Boolean Masking

```python
a = np.array([5, 15, 25, 35, 45])

# Basic mask
a[a > 20]                    # [25, 35, 45]
a[a % 2 == 0]                # [] (none are even)

# Compound conditions
a[(a > 10) & (a < 40)]      # [15, 25, 35]   — AND
a[(a < 10) | (a > 40)]      # [5, 45]         — OR
a[~(a > 20)]                 # [5, 15]         — NOT

# Fancy indexing
idx = np.where(a > 20)       # indices where True
a[idx]                       # [25, 35, 45]
np.where(a > 20, a, 0)       # Replace False with 0 → [0,0,25,35,45]
```

---

## ⚡ 6. Vector & Element-wise Operations

```python
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])

a + b        # [5, 7, 9]
a - b        # [-3,-3,-3]
a * b        # [4,10,18]
a / b        # [0.25, 0.4, 0.5]
a ** 2       # [1, 4, 9]
a + 10       # [11,12,13]  — broadcasting scalar
a * 3        # [3, 6, 9]
np.sqrt(a)   # [1., 1.41, 1.73]
np.abs(a)    # [1, 2, 3]
np.log(a)    # natural log
np.exp(a)    # e^x
```

---

## 📊 7. Numerical / Aggregate Operations

```python
a = np.array([[4,7,2],[3,8,1],[6,5,9]])

np.sum(a)         # 45  (all elements)
np.sum(a, axis=0) # [13,20,12]  — column sums
np.sum(a, axis=1) # [13,12,20]  — row sums

np.mean(a)        # 5.0
np.mean(a, axis=0)# column means
np.mean(a, axis=1)# row means

np.min(a)         # 1
np.max(a)         # 9
np.min(a, axis=0) # column-wise min
np.max(a, axis=1) # row-wise max

np.argmin(a)      # flat index of min
np.argmax(a, axis=1)  # row-wise index of max

np.std(a)         # standard deviation
np.var(a)         # variance
np.median(a)      # median (flat)
np.cumsum(a)      # cumulative sum (flattened)
np.cumsum(a, axis=1)  # row-wise cumulative sum
np.sort(a, axis=1)    # sort each row
np.argsort(a, axis=0) # sort indices column-wise
np.unique(a)      # unique elements sorted
```

---

## 🔢 8. Matrix Operations

```python
A = np.array([[1,2],[3,4]])
B = np.array([[5,6],[7,8]])

A @ B                   # Matrix multiply (dot product)
np.dot(A, B)            # Same as A @ B
np.linalg.inv(A)        # Inverse of A
np.linalg.det(A)        # Determinant: -2.0
np.linalg.eig(A)        # Eigenvalues & eigenvectors
np.linalg.norm(A)       # Frobenius norm
A.T                     # Transpose

# Solving Ax = b
b = np.array([1, 2])
x = np.linalg.solve(A, b)   # solution vector
```

---

## 🔄 9. Shape Manipulation

```python
a = np.arange(12)

a.reshape(3, 4)     # 3 rows, 4 cols
a.reshape(2, -1)    # auto-calculate cols (-1)
a.reshape(2,2,3)    # 3D

a.flatten()         # always returns copy
a.ravel()           # returns view if possible

np.vstack([A, B])   # stack vertically (row-wise)
np.hstack([A, B])   # stack horizontally (col-wise)
np.concatenate([A,B], axis=0)
np.split(a, 3)      # split into 3 equal parts
np.hsplit(a, 3)     # horizontal split
```

---

## 🏋️ 10. HARD Exam-Style Problems

### ⭐ Problem 1 — Multi-Step Filter & Stats
```python
# You are given a 2D array. Remove rows where row sum < 10,
# replace values < 3 with 0, transpose, keep columns with
# mean > 4, then return col_mean + col_sum rounded to 2 dp.

import numpy as np

def hard_filter(arr):
    arr = np.array(arr, dtype=float)

    # Step 1: Remove rows where row sum < 10
    row_mask = arr.sum(axis=1) >= 10
    arr = arr[row_mask]

    # Step 2: Replace values < 3 with 0
    arr = np.where(arr < 3, 0, arr)

    # Step 3: Transpose
    arr = arr.T

    # Step 4: Keep columns (original rows) where col mean > 4
    col_mask = arr.mean(axis=0) > 4
    arr = arr[:, col_mask]

    # Step 5 & 6: col_mean + col_sum
    col_mean = arr.mean(axis=0)
    col_sum  = arr.sum(axis=0)
    result   = col_mean + col_sum

    # Step 7: Round to 2 dp
    return np.round(result, 2)

data = [[1, 5, 6, 2],
        [3, 4, 0, 1],
        [7, 8, 9, 5],
        [2, 1, 3, 4]]
print(hard_filter(data))
```

### ⭐ Problem 2 — Boolean Masking + Broadcasting
```python
# Normalise each row to [0,1], then zero out values
# below the global mean of the normalised matrix.
def normalise_and_mask(arr):
    arr = arr.astype(float)
    row_min = arr.min(axis=1, keepdims=True)
    row_max = arr.max(axis=1, keepdims=True)
    norm = (arr - row_min) / (row_max - row_min + 1e-8)
    global_mean = norm.mean()
    norm[norm < global_mean] = 0
    return np.round(norm, 4)

A = np.random.randint(1, 20, (4, 5))
print(normalise_and_mask(A))
```

### ⭐ Problem 3 — Sliding Window Statistics
```python
# Given a 1D array compute a manual rolling mean of window size k
def rolling_mean(arr, k):
    result = np.full(len(arr), np.nan)
    for i in range(k - 1, len(arr)):
        result[i] = arr[i-k+1:i+1].mean()
    return np.round(result, 3)

data = np.array([3, 7, 2, 9, 4, 6, 8, 1, 5, 10])
print(rolling_mean(data, 3))
```

### ⭐ Problem 4 — Matrix Chain Operations
```python
# Build correlation-like matrix manually without np.corrcoef
def manual_corr(arr):
    arr = arr.astype(float)
    mean = arr.mean(axis=0)
    std  = arr.std(axis=0)
    z    = (arr - mean) / std          # z-score each column
    corr = (z.T @ z) / len(arr)       # correlation matrix
    return np.round(corr, 4)

data = np.random.randint(1, 100, (50, 4))
print(manual_corr(data))
```

### ⭐ Problem 5 — Top-K per Row
```python
# For each row, zero out all values except the top-k largest
def topk_mask(arr, k):
    result = np.zeros_like(arr)
    top_idx = np.argsort(arr, axis=1)[:, -k:]   # indices of top-k per row
    for i, row_idx in enumerate(top_idx):
        result[i, row_idx] = arr[i, row_idx]
    return result

M = np.random.randint(0, 20, (4, 6))
print("Original:\n", M)
print("Top-2 per row:\n", topk_mask(M, 2))
```

---

## 📋 Quick-Reference Cheatsheet

| Task | Code |
|---|---|
| Row sums | `arr.sum(axis=1)` |
| Col means | `arr.mean(axis=0)` |
| Filter rows | `arr[arr.sum(axis=1) >= 10]` |
| Filter cols | `arr[:, arr.mean(axis=0) > 4]` |
| Replace vals | `np.where(arr < 3, 0, arr)` |
| Transpose | `arr.T` |
| Flatten | `arr.flatten()` |
| Stack rows | `np.vstack([a,b])` |
| Stack cols | `np.hstack([a,b])` |
| Unique vals | `np.unique(arr)` |
| Sort rows | `np.sort(arr, axis=1)` |
| Argsort | `np.argsort(arr, axis=0)` |
| Cumsum | `np.cumsum(arr, axis=1)` |
| Clip values | `np.clip(arr, lo, hi)` |
| Round | `np.round(arr, 2)` |

---
*mathepy · numpyhelp — DVA Endterm Edition*
"""

class _Help:
    def __repr__(self):
        return _CONTENT
    def _repr_markdown_(self):
        return _CONTENT

numpyhelp = _Help()