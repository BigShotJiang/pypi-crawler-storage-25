from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-120b"   # change here if needed



def bcd(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = bcd(user_prompt)
    print("\nLLM:", answer, "\n")