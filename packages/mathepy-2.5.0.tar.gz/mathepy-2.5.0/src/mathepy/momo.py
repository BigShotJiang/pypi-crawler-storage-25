from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def momo(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = momo(user_prompt)
    print("\nLLM:", answer, "\n")