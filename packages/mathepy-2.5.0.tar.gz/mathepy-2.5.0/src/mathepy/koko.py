from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def koko(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = koko(user_prompt)
    print("\nLLM:", answer, "\n")