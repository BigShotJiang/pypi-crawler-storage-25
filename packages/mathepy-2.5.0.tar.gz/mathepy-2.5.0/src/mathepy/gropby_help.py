from IPython.display import display, Markdown

_CONTENT = r"""
# 🔗 GroupBy, Merge, Pivot & Analysis — DVA Exam Reference
> `from mathepy import groupbyhelp` | Works best in Jupyter Notebook

---

## 📦 1. Imports
```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```

---

## 🗂️ 2. GroupBy — Complete Guide

### Basic Syntax
```python
df.groupby('col')                          # GroupBy object
df.groupby('col')['target'].mean()         # mean of target per group
df.groupby('col')['target'].sum()
df.groupby('col')['target'].count()
df.groupby('col')['target'].max()
df.groupby('col')['target'].min()
df.groupby('col')['target'].std()
df.groupby('col')['target'].median()
df.groupby('col')['target'].nunique()      # count of unique values
df.groupby('col')['target'].first()        # first value per group
df.groupby('col')['target'].last()
```

### Multi-column GroupBy
```python
df.groupby(['dept','gender'])['salary'].mean()
df.groupby(['dept','gender'])[['salary','age']].mean()
```

### .agg() — Multiple Aggregations
```python
# Named aggregations (Pandas >= 0.25)
df.groupby('dept').agg(
    avg_salary    = ('salary',     'mean'),
    total_salary  = ('salary',     'sum'),
    headcount     = ('id',         'count'),
    max_exp       = ('experience', 'max'),
    min_age       = ('age',        'min'),
    unique_cities = ('city',       'nunique')
)

# Dict style
df.groupby('dept').agg({'salary': ['mean','sum','std'], 'age': 'median'})

# Lambda in agg
df.groupby('dept').agg(
    salary_range = ('salary', lambda x: x.max() - x.min())
)
```

### .transform() — Broadcast Result Back
```python
# Add group mean back to every row (same shape as df)
df['dept_avg_salary'] = df.groupby('dept')['salary'].transform('mean')
df['dept_rank']       = df.groupby('dept')['salary'].transform('rank')

# Z-score within group
df['salary_z_dept'] = df.groupby('dept')['salary'].transform(
    lambda x: (x - x.mean()) / x.std()
)

# Percentile rank within group
df['pct_rank_dept'] = df.groupby('dept')['salary'].transform(
    lambda x: x.rank(pct=True)
)
```

### .filter() — Keep Groups Matching Condition
```python
# Keep only departments with >= 50 employees
df_large = df.groupby('dept').filter(lambda x: len(x) >= 50)

# Keep departments where mean salary > 60000
df_rich = df.groupby('dept').filter(lambda x: x['salary'].mean() > 60000)
```

### .apply() — Custom Logic per Group
```python
# Apply any function to each group
def top_earners(group, n=3):
    return group.nlargest(n, 'salary')

df.groupby('dept').apply(top_earners, n=5).reset_index(drop=True)
```

### Iteration over Groups
```python
for name, group in df.groupby('dept'):
    print(f"\n--- {name} ({len(group)} rows) ---")
    print(group['salary'].describe())
```

---

## 🔗 3. Merging DataFrames

### pd.merge — All Join Types
```python
# Inner join (only matching rows)
pd.merge(df1, df2, on='id', how='inner')

# Left join (all from left, NaN for non-matching right)
pd.merge(df1, df2, on='id', how='left')

# Right join
pd.merge(df1, df2, on='id', how='right')

# Full outer join (all rows from both)
pd.merge(df1, df2, on='id', how='outer')

# Different key names
pd.merge(df1, df2, left_on='emp_id', right_on='employee_id')

# Multiple keys
pd.merge(df1, df2, on=['dept','month'], how='inner')

# Merge on index
pd.merge(df1, df2, left_index=True, right_index=True)

# Suffix for overlapping column names
pd.merge(df1, df2, on='id', suffixes=('_left','_right'))
```

### pd.concat — Stack DataFrames
```python
pd.concat([df1, df2], axis=0, ignore_index=True)     # stack rows
pd.concat([df1, df2], axis=1)                         # stack cols
pd.concat([df1,df2,df3], axis=0, ignore_index=True)  # multiple
pd.concat([df1, df2], axis=0, join='inner')           # only shared cols
```

### DataFrame.join — Index-based
```python
df1.join(df2, how='left', lsuffix='_l', rsuffix='_r')
```

---

## 🔄 4. Pivot & Reshape

### pivot_table (with aggregation)
```python
pd.pivot_table(
    df,
    values  = 'sales',
    index   = 'region',          # rows
    columns = 'product',         # columns
    aggfunc = 'sum',             # or 'mean', 'count', np.mean, list
    fill_value = 0,
    margins = True,              # add row/col totals
    margins_name = 'Total'
)

# Multiple values
pd.pivot_table(df, values=['sales','profit'],
               index='region', columns='product',
               aggfunc={'sales':'sum', 'profit':'mean'})
```

### pivot (no aggregation, must be unique)
```python
df.pivot(index='date', columns='product', values='sales')
```

### melt — Wide to Long
```python
pd.melt(
    df,
    id_vars    = ['id','name'],        # columns to keep
    value_vars = ['q1','q2','q3','q4'],# columns to unpivot
    var_name   = 'quarter',
    value_name = 'revenue'
)
```

### stack / unstack
```python
df.stack()     # columns → rows (wide → long)
df.unstack()   # rows → columns (long → wide)
```

---

## 📊 5. Descriptive Stats & Correlation (Analysis)

```python
# Full summary
df.describe()
df.describe(include='all')

# Single column
df['salary'].agg(['mean','median','std','skew','kurt'])

# Pairwise correlation
df.corr()                              # Pearson (default)
df.corr(method='spearman')            # Spearman rank correlation
df.corr(method='kendall')

# Top correlated pairs
corr = df.corr().abs()
upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
top_pairs = upper.stack().sort_values(ascending=False).head(10)

# Correlation with target
df.corr()['salary'].sort_values(ascending=False)
```

---

## 🏋️ 6. HARD Exam-Style Problems

### ⭐ Problem 1 — Full GroupBy + Ranking + Viz
```python
# For each department: compute mean salary, headcount, salary std,
# then rank departments by mean salary and plot.
def dept_summary_ranked(df):
    summary = df.groupby('dept').agg(
        mean_salary = ('salary', 'mean'),
        headcount   = ('id',     'count'),
        salary_std  = ('salary', 'std'),
        max_salary  = ('salary', 'max'),
    ).reset_index()

    summary['rank'] = summary['mean_salary'].rank(ascending=False).astype(int)
    summary = summary.sort_values('rank')

    print(summary.to_string(index=False))

    fig, ax = plt.subplots(figsize=(10,5))
    colors = plt.cm.RdYlGn(np.linspace(0.2, 0.9, len(summary)))
    bars = ax.bar(summary['dept'], summary['mean_salary'],
                  color=colors, edgecolor='black', linewidth=0.7)
    for bar, hc in zip(bars, summary['headcount']):
        ax.text(bar.get_x() + bar.get_width()/2,
                bar.get_height() + 500,
                f"n={hc}", ha='center', fontsize=9)
    ax.set_title('Mean Salary by Department (Ranked)', fontsize=14)
    ax.set_ylabel('Mean Salary')
    ax.set_xlabel('Department')
    ax.axhline(df['salary'].mean(), color='red', linestyle='--', label='Company Mean')
    ax.legend()
    plt.tight_layout()
    plt.show()
    return summary
```

### ⭐ Problem 2 — Multi-Level GroupBy + Pivot Heatmap
```python
# Build a salary heatmap: rows = dept, columns = gender, values = mean salary
def salary_heatmap(df):
    pivot = df.groupby(['dept','gender'])['salary'].mean().unstack(fill_value=0)

    fig, ax = plt.subplots(figsize=(8,5))
    sns.heatmap(pivot, annot=True, fmt='.0f', cmap='YlOrRd',
                linewidths=0.5, ax=ax, cbar_kws={'label':'Mean Salary'})
    ax.set_title('Mean Salary by Dept × Gender')
    plt.tight_layout()
    plt.show()
    return pivot
```

### ⭐ Problem 3 — Merge + Computed Column + Analysis
```python
# Merge employees with department budget, compute salary-to-budget ratio
# Flag employees where ratio > 0.02 (taking up > 2% of budget)
def budget_analysis(emp_df, budget_df):
    merged = pd.merge(emp_df, budget_df, on='dept', how='left')
    merged['salary_ratio'] = merged['salary'] / merged['budget']
    merged['over_budget']  = merged['salary_ratio'] > 0.02

    print("Over-budget employees per dept:")
    print(merged.groupby('dept')['over_budget'].sum().sort_values(ascending=False))

    fig, axes = plt.subplots(1, 2, figsize=(13,5))
    sns.boxplot(x='dept', y='salary_ratio', data=merged,
                palette='coolwarm', ax=axes[0])
    axes[0].axhline(0.02, color='red', linestyle='--', label='2% threshold')
    axes[0].legend()
    axes[0].set_title('Salary-to-Budget Ratio by Dept')

    merged.groupby('dept')['over_budget'].sum().sort_values().plot(
        kind='barh', ax=axes[1], color='tomato', edgecolor='black')
    axes[1].set_title('Count of Over-Budget Employees')
    plt.tight_layout()
    plt.show()
    return merged
```

### ⭐ Problem 4 — transform + filter + apply chain
```python
# Keep only depts with >= 10 employees.
# Within those, flag employees earning below 80th percentile of their dept.
# Add dept-normalised salary. Return summary.
def advanced_groupby_chain(df):
    # Step 1: filter depts with >= 10 employees
    df = df.groupby('dept').filter(lambda x: len(x) >= 10).copy()

    # Step 2: dept 80th percentile
    df['dept_p80'] = df.groupby('dept')['salary'].transform(
        lambda x: x.quantile(0.80)
    )

    # Step 3: flag below p80
    df['below_p80'] = df['salary'] < df['dept_p80']

    # Step 4: z-score within dept
    df['salary_z'] = df.groupby('dept')['salary'].transform(
        lambda x: (x - x.mean()) / x.std()
    )

    # Step 5: percentile rank within dept
    df['dept_pct_rank'] = df.groupby('dept')['salary'].transform(
        lambda x: x.rank(pct=True)
    )

    summary = df.groupby('dept').agg(
        count         = ('salary','count'),
        below_p80_cnt = ('below_p80','sum'),
        mean_salary   = ('salary','mean'),
        mean_z        = ('salary_z','mean')
    )
    print(summary)
    return df
```

### ⭐ Problem 5 — Melt + GroupBy + Trend Analysis
```python
# Wide quarterly sales → long format → compute QoQ growth per product
def quarterly_trend(df):
    # df has: product, q1, q2, q3, q4
    long = pd.melt(df, id_vars=['product'],
                   value_vars=['q1','q2','q3','q4'],
                   var_name='quarter', value_name='sales')

    long = long.sort_values(['product','quarter'])
    long['qoq_growth'] = long.groupby('product')['sales'].pct_change() * 100

    print("\nMean QoQ Growth per Product:")
    print(long.groupby('product')['qoq_growth'].mean().round(2))

    fig, axes = plt.subplots(1, 2, figsize=(14,5))

    for prod, grp in long.groupby('product'):
        axes[0].plot(grp['quarter'], grp['sales'], marker='o', label=prod)
    axes[0].set_title('Quarterly Sales by Product')
    axes[0].legend()

    for prod, grp in long.groupby('product'):
        axes[1].plot(grp['quarter'], grp['qoq_growth'], marker='s', label=prod)
    axes[1].axhline(0, color='black', linewidth=0.8, linestyle='--')
    axes[1].set_title('QoQ Growth % by Product')
    axes[1].legend()

    plt.tight_layout()
    plt.show()
    return long

# Example data
sample = pd.DataFrame({
    'product': ['Laptop','Phone','Tablet','Watch'],
    'q1': [50000, 30000, 12000, 8000],
    'q2': [55000, 28000, 15000, 9500],
    'q3': [48000, 32000, 14000, 11000],
    'q4': [62000, 40000, 18000, 13000]
})
# quarterly_trend(sample)
```

### ⭐ Problem 6 — Full Analysis Pipeline (Exam Boss)
```python
# Complete: load → clean → groupby → merge budget → melt quarterly
# → detect outliers → visualise dashboard
def exam_boss_pipeline(df, budget_df):
    # 1. Clean
    df.columns = df.columns.str.strip().str.lower()
    df.drop_duplicates(inplace=True)
    for c in ['salary','age']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
        df[c].fillna(df[c].median(), inplace=True)

    # 2. Feature engineering
    df['seniority'] = pd.cut(df['experience'],
                              bins=[0,2,5,10,np.inf],
                              labels=['Junior','Mid','Senior','Lead'])

    # 3. Outlier flag
    Q1,Q3 = df['salary'].quantile([0.25,0.75])
    IQR   = Q3 - Q1
    df['salary_outlier'] = ~df['salary'].between(Q1-1.5*IQR, Q3+1.5*IQR)

    # 4. GroupBy summary
    dept_summary = df.groupby('dept').agg(
        n             = ('salary','count'),
        mean_sal      = ('salary','mean'),
        outlier_count = ('salary_outlier','sum')
    ).reset_index()

    # 5. Merge budget
    merged = pd.merge(dept_summary, budget_df, on='dept', how='left')
    merged['utilisation'] = merged['mean_sal'] * merged['n'] / merged['budget']

    # 6. Dashboard
    fig, axes = plt.subplots(2, 2, figsize=(14,10))
    fig.suptitle('Full Pipeline Dashboard', fontsize=16)

    sns.barplot(x='dept', y='mean_sal', data=dept_summary,
                palette='muted', ax=axes[0,0])
    axes[0,0].set_title('Mean Salary by Dept')

    sns.histplot(df['salary'], kde=True, ax=axes[0,1], bins=30)
    axes[0,1].axvline(df['salary'].mean(), color='red', linestyle='--')
    axes[0,1].set_title('Salary Distribution')

    sns.countplot(x='seniority', data=df,
                  order=['Junior','Mid','Senior','Lead'],
                  palette='viridis', ax=axes[1,0])
    axes[1,0].set_title('Seniority Distribution')

    sns.barplot(x='dept', y='utilisation', data=merged,
                palette='RdYlGn_r', ax=axes[1,1])
    axes[1,1].axhline(1.0, color='red', linestyle='--', label='100% budget')
    axes[1,1].legend()
    axes[1,1].set_title('Budget Utilisation by Dept')

    plt.tight_layout()
    plt.show()
    return merged
```

---

## 📋 Quick Reference Cheatsheet

| Task | Code |
|---|---|
| GroupBy single | `df.groupby('col')['val'].mean()` |
| GroupBy multi-key | `df.groupby(['a','b'])['val'].sum()` |
| Named agg | `df.groupby('col').agg(new=('val','mean'))` |
| Broadcast back | `df.groupby('col')['val'].transform('mean')` |
| Z-score per group | `.transform(lambda x: (x-x.mean())/x.std())` |
| Filter groups | `.filter(lambda x: len(x) >= 50)` |
| Apply custom | `.apply(my_func).reset_index(drop=True)` |
| Inner join | `pd.merge(a,b,on='key',how='inner')` |
| Left join | `pd.merge(a,b,on='key',how='left')` |
| Stack rows | `pd.concat([a,b], axis=0, ignore_index=True)` |
| Stack cols | `pd.concat([a,b], axis=1)` |
| Pivot (with agg) | `pd.pivot_table(df, values, index, columns, aggfunc)` |
| Wide to long | `pd.melt(df, id_vars, value_vars, var_name, value_name)` |
| Correlation matrix | `df.corr()` |
| Top corr with target | `df.corr()['target'].sort_values(ascending=False)` |

---
*mathepy · groupbyhelp — DVA Endterm Edition*
"""

class _Help:
    def __repr__(self):
        return _CONTENT
    def _repr_markdown_(self):
        return _CONTENT

groupbyhelp = _Help()