from IPython.display import display, Markdown

_CONTENT = r"""
# 📊 Matplotlib & Seaborn Visualisation — DVA Exam Reference
> `from mathepy import vizhelp` | Works best in Jupyter Notebook

---

## 📦 1. Imports & Setup
```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

# Recommended Jupyter setup
%matplotlib inline
plt.rcParams['figure.figsize'] = (10, 5)
plt.rcParams['axes.grid'] = True
sns.set_theme(style='whitegrid', palette='muted')
```

---

## 🗺️ 2. Matplotlib Anatomy

```
Figure  →  the entire canvas
  └─ Axes  →  one plot area (has x-axis, y-axis, title, etc.)
       ├─ Title     (ax.set_title)
       ├─ X-label   (ax.set_xlabel)
       ├─ Y-label   (ax.set_ylabel)
       ├─ Legend    (ax.legend)
       └─ Grid      (ax.grid)
```

### Creating figures
```python
# Single plot
fig, ax = plt.subplots()
ax.plot([1,2,3],[4,5,6])
plt.show()

# Multiple subplots
fig, axes = plt.subplots(2, 3, figsize=(15, 8))
axes[0,0].plot(...)   # row 0, col 0
axes[1,2].bar(...)    # row 1, col 2
plt.tight_layout()
plt.show()
```

---

## 📈 3. Matplotlib Plot Types

### Line Plot
```python
x = [1,2,3,4,5]
y = [2,4,6,8,10]
ax.plot(x, y, color='steelblue', linewidth=2,
        linestyle='--', marker='o', label='Trend')
ax.set_title('Line Plot')
ax.legend()
```

### Bar Chart
```python
categories = ['A','B','C','D']
values     = [10, 25, 15, 30]
ax.bar(categories, values, color='coral', edgecolor='black', width=0.6)
ax.set_xlabel('Category')
ax.set_ylabel('Count')
```

### Horizontal Bar
```python
ax.barh(categories, values, color='teal')
```

### Scatter Plot
```python
ax.scatter(df['experience'], df['salary'],
           c='steelblue', s=60, alpha=0.6, edgecolors='white')
```

### Histogram
```python
ax.hist(df['salary'], bins=20, color='mediumpurple',
        edgecolor='black', density=False)
ax.set_xlabel('Salary')
ax.set_ylabel('Frequency')
```

### Pie Chart
```python
sizes  = [30, 20, 25, 15, 10]
labels = ['IT','HR','Finance','Ops','Legal']
ax.pie(sizes, labels=labels, autopct='%1.1f%%',
       startangle=90, explode=[0.05]*5)
ax.set_title('Department Distribution')
```

### Box Plot (Matplotlib)
```python
data = [df[df['dept']==d]['salary'].dropna().values for d in df['dept'].unique()]
ax.boxplot(data, labels=df['dept'].unique(), patch_artist=True)
```

### Fill between (area)
```python
ax.fill_between(x, y1, y2, alpha=0.3, color='skyblue', label='Range')
```

---

## 🌊 4. Seaborn Plot Types

### Distribution Plots (Univariate)
```python
# Histogram + KDE
sns.histplot(df['salary'], kde=True, bins=30, color='steelblue', ax=ax)

# KDE only
sns.kdeplot(df['salary'], fill=True, color='coral')

# Box plot
sns.boxplot(x='dept', y='salary', data=df, palette='muted')

# Violin plot (distribution shape + box)
sns.violinplot(x='dept', y='salary', data=df, inner='box', palette='pastel')

# Stripplot (all points)
sns.stripplot(x='dept', y='salary', data=df, alpha=0.5, jitter=True)

# Combine violin + strip
fig, ax = plt.subplots()
sns.violinplot(x='dept', y='salary', data=df, inner=None, palette='pastel', ax=ax)
sns.stripplot(x='dept', y='salary', data=df, color='black', alpha=0.4, size=3, ax=ax)
plt.show()
```

### Bivariate Plots
```python
# Scatter
sns.scatterplot(x='experience', y='salary', hue='dept',
                size='age', data=df, palette='tab10')

# Regression line
sns.regplot(x='experience', y='salary', data=df,
            scatter_kws={'alpha':0.5}, line_kws={'color':'red'})

# LM plot (faceted regression)
sns.lmplot(x='experience', y='salary', hue='gender', data=df, height=5)
```

### Categorical Plots
```python
# Count plot (bar chart for categories)
sns.countplot(x='dept', data=df, order=df['dept'].value_counts().index)

# Bar plot (mean + CI by default)
sns.barplot(x='dept', y='salary', data=df, estimator=np.mean, ci=95)

# Point plot (mean with lines)
sns.pointplot(x='dept', y='salary', hue='gender', data=df)
```

### Heatmap
```python
corr = df.select_dtypes('number').corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, linewidths=0.5, square=True)
plt.title('Correlation Heatmap')
```

### Pair Plot (Multivariate)
```python
sns.pairplot(df[['age','salary','experience','score']], hue='dept',
             diag_kind='kde', plot_kws={'alpha':0.5})
plt.suptitle('Pairplot', y=1.02)
```

### Facet Grid
```python
g = sns.FacetGrid(df, col='dept', row='gender', height=3)
g.map(sns.histplot, 'salary', kde=True)
g.add_legend()
```

---

## 🧩 5. Customisation Essentials

```python
# Titles & Labels
ax.set_title('My Chart', fontsize=16, fontweight='bold')
ax.set_xlabel('X Label', fontsize=12)
ax.set_ylabel('Y Label', fontsize=12)

# Ticks
ax.set_xticks([0,1,2,3])
ax.set_xticklabels(['A','B','C','D'], rotation=45, ha='right')
ax.tick_params(axis='x', labelsize=10)

# Limits
ax.set_xlim(0, 100)
ax.set_ylim(0, 50000)

# Grid
ax.grid(True, linestyle='--', alpha=0.5)
ax.grid(False)

# Legend
ax.legend(loc='upper right', fontsize=10, framealpha=0.8)

# Annotations
ax.annotate('Peak', xy=(3, 9), xytext=(3.5, 8),
            arrowprops=dict(arrowstyle='->'), fontsize=11)
ax.text(2, 5, 'note here', fontsize=9, color='red')

# Reference line
ax.axhline(y=df['salary'].mean(), color='red', linestyle='--', label='Mean')
ax.axvline(x=0, color='grey', linewidth=0.8)

# Save
plt.savefig('chart.png', dpi=150, bbox_inches='tight')
```

---

## 🏋️ 6. HARD Exam-Style Problems

### ⭐ Problem 1 — Dashboard: 4-Panel EDA
```python
def eda_dashboard(df, num_col, cat_col):
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(f'EDA Dashboard: {num_col}', fontsize=16, fontweight='bold')

    # Panel 1: Distribution
    sns.histplot(df[num_col], kde=True, ax=axes[0,0], color='steelblue')
    axes[0,0].axvline(df[num_col].mean(),   color='red',    linestyle='--', label='Mean')
    axes[0,0].axvline(df[num_col].median(), color='orange', linestyle='-.', label='Median')
    axes[0,0].legend()
    axes[0,0].set_title('Distribution')

    # Panel 2: Box by category
    sns.boxplot(x=cat_col, y=num_col, data=df, palette='muted', ax=axes[0,1])
    axes[0,1].set_xticklabels(axes[0,1].get_xticklabels(), rotation=30)
    axes[0,1].set_title(f'{num_col} by {cat_col}')

    # Panel 3: Correlation heatmap
    corr = df.select_dtypes('number').corr()
    sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm',
                center=0, ax=axes[1,0], linewidths=0.5)
    axes[1,0].set_title('Correlation Matrix')

    # Panel 4: Count of categories
    order = df[cat_col].value_counts().index
    sns.countplot(x=cat_col, data=df, order=order,
                  palette='viridis', ax=axes[1,1])
    axes[1,1].set_xticklabels(axes[1,1].get_xticklabels(), rotation=30)
    axes[1,1].set_title(f'Count of {cat_col}')

    plt.tight_layout()
    plt.show()

# eda_dashboard(df, 'salary', 'dept')
```

### ⭐ Problem 2 — Outlier Visualisation
```python
def outlier_plot(df, col):
    Q1, Q3 = df[col].quantile([0.25, 0.75])
    IQR    = Q3 - Q1
    lo, hi = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    # Box plot
    sns.boxplot(x=df[col], ax=ax1, color='lightblue', flierprops=dict(markerfacecolor='red', marker='D'))
    ax1.set_title(f'Boxplot — {col}')

    # Histogram with fence lines
    sns.histplot(df[col], kde=True, ax=ax2, color='steelblue', bins=30)
    ax2.axvline(lo, color='red',    linestyle='--', label=f'Lower fence ({lo:.0f})')
    ax2.axvline(hi, color='green',  linestyle='--', label=f'Upper fence ({hi:.0f})')
    ax2.axvline(df[col].mean(), color='orange', linewidth=2, label='Mean')
    ax2.legend()
    ax2.set_title(f'Histogram + IQR Fences — {col}')

    plt.tight_layout()
    plt.show()
    print(f"Outliers: {((df[col] < lo) | (df[col] > hi)).sum()} rows")
```

### ⭐ Problem 3 — Rolling Trend with Anomaly Overlay
```python
def rolling_trend_plot(df, date_col, val_col, window=7):
    df = df.copy().sort_values(date_col)
    df['roll_mean'] = df[val_col].rolling(window, min_periods=1).mean()
    df['roll_std']  = df[val_col].rolling(window, min_periods=1).std().fillna(0)
    df['upper']     = df['roll_mean'] + 2 * df['roll_std']
    df['lower']     = df['roll_mean'] - 2 * df['roll_std']
    df['anomaly']   = (df[val_col] > df['upper']) | (df[val_col] < df['lower'])

    fig, ax = plt.subplots(figsize=(14, 5))
    ax.plot(df[date_col], df[val_col], alpha=0.5, label='Actual', color='steelblue')
    ax.plot(df[date_col], df['roll_mean'], color='orange', linewidth=2, label=f'{window}-day Rolling Mean')
    ax.fill_between(df[date_col], df['lower'], df['upper'], alpha=0.2, color='orange', label='±2 STD Band')
    ax.scatter(df.loc[df['anomaly'], date_col],
               df.loc[df['anomaly'], val_col],
               color='red', zorder=5, s=60, label='Anomaly')
    ax.legend()
    ax.set_title(f'Rolling Trend + Anomaly Detection ({val_col})')
    plt.tight_layout()
    plt.show()
```

### ⭐ Problem 4 — Multi-variable Grouped Comparison
```python
def grouped_comparison(df, group_col, metrics):
    """Bar chart for multiple metrics across groups."""
    summary = df.groupby(group_col)[metrics].mean()
    x = np.arange(len(summary))
    width = 0.8 / len(metrics)

    fig, ax = plt.subplots(figsize=(12, 6))
    for i, m in enumerate(metrics):
        ax.bar(x + i * width, summary[m], width, label=m, alpha=0.85)

    ax.set_xticks(x + width * (len(metrics)-1) / 2)
    ax.set_xticklabels(summary.index, rotation=30)
    ax.legend()
    ax.set_title(f'Mean Metrics by {group_col}')
    plt.tight_layout()
    plt.show()

# grouped_comparison(df, 'dept', ['salary','experience','age'])
```

### ⭐ Problem 5 — Annotated Pair Grid (Multivariate)
```python
def annotated_pairplot(df, cols, hue_col):
    g = sns.PairGrid(df[cols + [hue_col]], hue=hue_col, palette='tab10')
    g.map_upper(sns.scatterplot, alpha=0.5, s=30)
    g.map_lower(sns.kdeplot, fill=True, alpha=0.3)
    g.map_diag(sns.histplot, kde=True)
    g.add_legend()
    plt.suptitle('Annotated Pair Grid', y=1.02, fontsize=14)
    plt.show()

# annotated_pairplot(df, ['salary','age','experience'], 'dept')
```

---

## 📋 Quick Reference Table

| Chart | Best For | Seaborn | Matplotlib |
|---|---|---|---|
| Histogram | Distribution | `histplot` | `ax.hist` |
| KDE | Smooth distribution | `kdeplot` | via `scipy` |
| Box | Spread + outliers | `boxplot` | `ax.boxplot` |
| Violin | Distribution shape | `violinplot` | — |
| Bar | Category comparison | `barplot` | `ax.bar` |
| Count | Category frequency | `countplot` | `ax.bar` |
| Scatter | Correlation 2-var | `scatterplot` | `ax.scatter` |
| Line | Trends over time | `lineplot` | `ax.plot` |
| Heatmap | Correlation matrix | `heatmap` | — |
| Pair plot | All pairwise | `pairplot` | — |
| FacetGrid | Conditional subplots | `FacetGrid` | `subplots` |

---
*mathepy · vizhelp — DVA Endterm Edition*
"""

class _Help:
    def __repr__(self):
        return _CONTENT
    def _repr_markdown_(self):
        return _CONTENT

vizhelp = _Help()