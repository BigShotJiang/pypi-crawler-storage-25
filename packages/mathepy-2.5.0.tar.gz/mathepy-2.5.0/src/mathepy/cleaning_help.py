from IPython.display import display, Markdown

_CONTENT = r"""
# 🧹 Pandas Cleaning & Analysis — DVA Exam Reference
> `from mathepy import cleaninghelp` | Works best in Jupyter Notebook

---

## 📦 1. Imports
```python
import pandas as pd
import numpy as np
```

---

## 📂 2. Loading Data

```python
df = pd.read_csv("file.csv")
df = pd.read_csv("file.csv", index_col=0, parse_dates=["date"])
df = pd.read_csv("file.csv", na_values=["NA","?","-"])  # custom nulls
df = pd.read_excel("file.xlsx", sheet_name="Sheet1")
df = pd.read_json("file.json")

# First look
df.head(5)          # first 5 rows
df.tail(3)          # last 3 rows
df.sample(5)        # 5 random rows
df.shape            # (rows, cols)
df.info()           # dtypes + non-null counts
df.describe()       # numeric summary statistics
df.describe(include="all")   # include categoricals too
df.columns.tolist() # list of column names
df.dtypes           # per-column dtype
df.index            # row index info
```

---

## 🩹 3. Handling Missing Values

```python
# Detect
df.isnull()                    # boolean DataFrame
df.isnull().sum()              # count NaN per column
df.isnull().sum() / len(df)    # proportion missing
df.notnull().sum()             # count non-null

# Drop
df.dropna()                            # drop ANY row with NaN
df.dropna(how='all')                   # drop row only if ALL values NaN
df.dropna(subset=['age', 'salary'])    # drop if NaN in these cols
df.dropna(thresh=3)                    # keep rows with at least 3 non-NaN

# Fill
df.fillna(0)                           # fill all NaN with 0
df['col'].fillna(df['col'].mean())     # fill with mean
df['col'].fillna(df['col'].median())   # fill with median
df['col'].fillna(df['col'].mode()[0])  # fill with mode
df['col'].fillna(method='ffill')       # forward fill (carry forward)
df['col'].fillna(method='bfill')       # backward fill

# Replace specific values with NaN
df.replace(-1, np.nan)
df.replace({'col': {999: np.nan, -1: np.nan}})
```

---

## 🔁 4. Handling Duplicates

```python
df.duplicated()                        # bool Series
df.duplicated().sum()                  # count duplicates
df[df.duplicated(keep=False)]          # show ALL duplicates

df.drop_duplicates()                   # remove dups (keep first)
df.drop_duplicates(keep='last')        # keep last occurrence
df.drop_duplicates(keep=False)         # remove ALL duplicates
df.drop_duplicates(subset=['id'])      # based on column(s)
df.drop_duplicates(subset=['a','b'], keep='first')
```

---

## 🔡 5. Data Types & Conversion

```python
df.dtypes                              # check current types
df['price'] = df['price'].astype(float)
df['qty']   = df['qty'].astype(int)
df['date']  = pd.to_datetime(df['date'])
df['date']  = pd.to_datetime(df['date'], format='%d-%m-%Y')
df['cat']   = df['cat'].astype('category')

# Numeric conversion (coerce errors → NaN)
df['col'] = pd.to_numeric(df['col'], errors='coerce')

# Check if conversion worked
df.dtypes
df['col'].dtype
```

---

## 🔤 6. String / Text Cleaning

```python
df['city'] = df['city'].str.strip()           # remove whitespace
df['city'] = df['city'].str.lower()           # lowercase
df['city'] = df['city'].str.upper()
df['city'] = df['city'].str.title()           # Title Case
df['city'] = df['city'].str.replace(" ","_") # replace spaces

# Replace using dict (standardise values)
df['city'].replace({'NY': 'New York', 'Mum': 'Mumbai'}, inplace=True)

# Check contains / starts / ends
df[df['name'].str.contains('Kumar', na=False)]
df[df['code'].str.startswith('IN')]
df[df['code'].str.endswith('01')]

# Extract substring
df['year'] = df['date_str'].str[:4]           # first 4 chars
df['domain'] = df['email'].str.split('@').str[1]
df[['first','last']] = df['name'].str.split(' ', expand=True)

# String length
df['name_len'] = df['name'].str.len()
```

---

## 🗂️ 7. Column Operations

```python
# Rename
df.rename(columns={'old_name': 'new_name'}, inplace=True)
df.columns = df.columns.str.strip().str.lower().str.replace(' ','_')

# Drop columns
df.drop(columns=['col1','col2'], inplace=True)

# Add column
df['profit'] = df['revenue'] - df['cost']
df['is_senior'] = df['age'].apply(lambda x: x >= 60)

# Reorder columns
df = df[['id','name','age','salary']]

# Select dtypes
df.select_dtypes(include='number')
df.select_dtypes(include='object')
```

---

## 🔍 8. Filtering Data

```python
# Boolean
df[df['age'] > 25]
df[(df['age'] > 18) & (df['city'] == 'Delhi')]
df[(df['dept'] == 'IT') | (df['dept'] == 'HR')]
df[~(df['status'] == 'Inactive')]                  # NOT

# isin / ~isin
df[df['dept'].isin(['IT','Finance','HR'])]
df[~df['dept'].isin(['IT'])]

# between
df[df['age'].between(25, 40)]

# loc / iloc
df.loc[df['age'] > 25, ['name','salary']]
df.iloc[0:10, 0:3]                                  # first 10 rows, 3 cols

# query (clean syntax)
df.query("age > 25 and dept == 'IT'")
df.query("salary > @threshold", threshold_=50000)   # use local var
```

---

## 📊 9. Descriptive Statistics

```python
df['salary'].mean()
df['salary'].median()
df['salary'].mode()[0]
df['salary'].std()
df['salary'].var()
df['salary'].min()
df['salary'].max()
df['salary'].quantile(0.25)                   # Q1
df['salary'].quantile([0.25, 0.5, 0.75])     # Q1, median, Q3

# IQR
Q1 = df['salary'].quantile(0.25)
Q3 = df['salary'].quantile(0.75)
IQR = Q3 - Q1

# Full stats
df.describe()
df.describe(percentiles=[.1, .25, .5, .75, .9])

# Correlation matrix
df.corr()
df['salary'].corr(df['experience'])
```

---

## 🎯 10. Outlier Detection

```python
# ── IQR Method ──────────────────────────────────────────────────
Q1  = df['salary'].quantile(0.25)
Q3  = df['salary'].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

outliers   = df[(df['salary'] < lower) | (df['salary'] > upper)]
clean      = df[(df['salary'] >= lower) & (df['salary'] <= upper)]
df['salary_capped'] = df['salary'].clip(lower, upper)  # Winsorise

# ── Z-Score Method ───────────────────────────────────────────────
from scipy import stats
z = np.abs(stats.zscore(df['salary'].dropna()))
outliers_z = df[z > 3]
clean_z    = df[z <= 3]

# ── Flag rather than drop ────────────────────────────────────────
df['is_outlier'] = (df['salary'] < lower) | (df['salary'] > upper)
```

---

## 📈 11. Frequency Analysis

```python
df['dept'].value_counts()                          # absolute
df['dept'].value_counts(normalize=True)            # relative (proportions)
df['dept'].value_counts(ascending=True)            # ascending order
df['dept'].value_counts().head(5)                  # top 5

# Cross-tabulation (categorical vs categorical)
pd.crosstab(df['gender'], df['dept'])
pd.crosstab(df['gender'], df['dept'], margins=True)         # add totals
pd.crosstab(df['gender'], df['dept'], normalize='index')    # row %
pd.crosstab(df['gender'], df['dept'], normalize='columns')  # col %
```

---

## 🪟 12. Window Functions

```python
df['rolling_mean']  = df['sales'].rolling(window=7).mean()
df['rolling_sum']   = df['sales'].rolling(window=3).sum()
df['rolling_std']   = df['sales'].rolling(window=7).std()
df['expanding_sum'] = df['sales'].expanding().sum()      # cumulative
df['cumsum']        = df['sales'].cumsum()
df['pct_change']    = df['sales'].pct_change()           # MoM growth %
df['lag_1']         = df['sales'].shift(1)               # lag by 1 period
df['lead_1']        = df['sales'].shift(-1)              # lead by 1
df['rank']          = df['sales'].rank(method='dense', ascending=False)
```

---

## 🏋️ 13. HARD Exam-Style Problems

### ⭐ Problem 1 — Complete Pipeline
```python
# Load, clean, flag outliers, and compute dept-wise summary
import pandas as pd
import numpy as np

def full_pipeline(filepath):
    df = pd.read_csv(filepath)

    # Standardise columns
    df.columns = df.columns.str.strip().str.lower().str.replace(' ','_')

    # Drop full-duplicate rows
    df.drop_duplicates(inplace=True)

    # Numeric coercion
    for col in ['salary','age','experience']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Fill NaN: numeric → median, text → mode
    for col in df.select_dtypes(include='number').columns:
        df[col].fillna(df[col].median(), inplace=True)
    for col in df.select_dtypes(include='object').columns:
        df[col].fillna(df[col].mode()[0], inplace=True)

    # Outlier flag (IQR) on salary
    Q1, Q3 = df['salary'].quantile([0.25, 0.75])
    IQR = Q3 - Q1
    df['salary_outlier'] = ~df['salary'].between(Q1 - 1.5*IQR, Q3 + 1.5*IQR)

    # Standardise city column
    df['city'] = df['city'].str.strip().str.title()

    return df

# df = full_pipeline("employees.csv")
```

### ⭐ Problem 2 — Multi-condition Replacement
```python
# Replace salary: if age < 25 and experience < 2, set salary = salary * 0.8
# if dept == 'IT' and salary > 80000, cap at 80000
def conditional_update(df):
    df = df.copy()
    mask1 = (df['age'] < 25) & (df['experience'] < 2)
    df.loc[mask1, 'salary'] *= 0.8

    mask2 = (df['dept'] == 'IT') & (df['salary'] > 80000)
    df.loc[mask2, 'salary'] = 80000
    return df
```

### ⭐ Problem 3 — Z-score Normalisation per Group
```python
# Z-score normalise salary WITHIN each department
def zscore_per_group(df):
    df['salary_z'] = (
        df.groupby('dept')['salary']
          .transform(lambda x: (x - x.mean()) / x.std())
    )
    return df
```

### ⭐ Problem 4 — Categorical Encoding + Correlation
```python
# One-hot encode 'dept', drop original, find top-3 correlated features
def encode_and_correlate(df, target='salary'):
    df_enc = pd.get_dummies(df, columns=['dept'], drop_first=False)
    corr = df_enc.corr()[target].drop(target).abs().sort_values(ascending=False)
    print("Top 3 correlated features:\n", corr.head(3))
    return df_enc
```

### ⭐ Problem 5 — Rolling + Anomaly Detection
```python
# Flag rows where value deviates > 2 std from its 7-period rolling mean
def rolling_anomaly(df, col, window=7, threshold=2):
    df = df.copy()
    roll_mean = df[col].rolling(window, min_periods=1).mean()
    roll_std  = df[col].rolling(window, min_periods=1).std().fillna(1)
    df['z_roll'] = (df[col] - roll_mean) / roll_std
    df['anomaly'] = df['z_roll'].abs() > threshold
    return df
```

---

## 📋 Quick-Reference Cheatsheet

| Task | Code |
|---|---|
| Count nulls | `df.isnull().sum()` |
| Drop null rows | `df.dropna()` |
| Fill with median | `df['c'].fillna(df['c'].median())` |
| Drop duplicates | `df.drop_duplicates()` |
| Convert to float | `df['c'].astype(float)` |
| Parse dates | `pd.to_datetime(df['d'])` |
| IQR fences | `Q1-1.5*IQR`, `Q3+1.5*IQR` |
| Clip outliers | `df['c'].clip(lower, upper)` |
| String strip | `df['c'].str.strip().str.title()` |
| Rename cols | `df.rename(columns={'old':'new'})` |
| Filter rows | `df.query("age > 25")` |
| Value counts | `df['c'].value_counts(normalize=True)` |
| Cross-tab | `pd.crosstab(df['a'], df['b'])` |
| Rolling mean | `df['c'].rolling(7).mean()` |
| Cumulative sum | `df['c'].cumsum()` |

---
*mathepy · cleaninghelp — DVA Endterm Edition*
"""

class _Help:
    def __repr__(self):
        return _CONTENT
    def _repr_markdown_(self):
        return _CONTENT

cleaninghelp = _Help()