from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def hellp(password, prompt):
    if password != "hi":
        return "Incorrect password. Access denied."
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = hellp(user_prompt)
    print("\nLLM:", answer, "\n")