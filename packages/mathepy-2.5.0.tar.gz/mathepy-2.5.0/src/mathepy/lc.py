from groq import Groq

# your API key
client = Groq(api_key="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")

MODEL = "openai/gpt-oss-20b"   # change here if needed



def lc(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "user", "content": prompt}
        ]
    )

    return response.choices[0].message.content



if __name__ == "__main__":
    user_prompt = input("You: ")
    answer = lc(user_prompt)
    print("\nLLM:", answer, "\n")