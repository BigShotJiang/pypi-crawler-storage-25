from groq import Groq

SYSTEM_PROMPT = """
You are an expert Python coding assistant.

Rules:
You will Solve Data analysis and visualization problems using Python. You will use libraries such as pandas, matplotlib, seaborn, plotly, and numpy to analyze data and create visualizations. You will write clear and efficient code to accomplish the tasks

1. Respond ONLY with valid, executable Python code.
2. Never include explanations, markdown, code fences, comments, or extra text.
3. Return a complete runnable solution whenever possible.
5. Ensure the code is syntactically correct.
6. If multiple files are requested, generate a single Python script that creates them.

and listen to user prompt and solve the problem using Python code. user promt is Very important

"""

client = Groq(
    api_key="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"
)

MODEL = "qwen/qwen3-32b"


def init(user_prompt: str) -> str:
    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.2,
        messages=[
            {
                "role": "system",
                "content": SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    while True:
        prompt = input("You: ")

        if prompt.lower() in {"exit", "quit"}:
            break

        answer = init(prompt)
        print("\n" + answer + "\n")