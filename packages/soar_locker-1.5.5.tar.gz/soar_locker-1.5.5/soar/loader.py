# soar/loader.py
import importlib.abc
import importlib.util
import linecache
import os
import sys

from soar.core_manager import ensure_core

MAGIC = b"SOAR0001"
FP_LEN = 64
IV_LEN = 16


class SoarLoader(importlib.abc.Loader):
    def __init__(self, fullname, path):
        self.fullname = fullname
        self.path = path

    def _read_blob(self):
        with open(self.path, "rb") as f:
            data = f.read()

        if not data.startswith(MAGIC):
            raise RuntimeError("Invalid SOAR archive header")

        idx = len(MAGIC)
        fp = data[idx:idx + FP_LEN].decode()
        if len(fp) != 64:
            raise RuntimeError("Corrupted SOAR fingerprint")

        idx += FP_LEN
        iv = data[idx:idx + IV_LEN]
        if len(iv) != IV_LEN:
            raise RuntimeError("Corrupted SOAR IV")

        cipher = data[idx + IV_LEN:]
        if len(cipher) == 0:
            raise RuntimeError("Corrupted SOAR archive payload")

        return fp, iv, cipher

    def exec_module(self, module):
        fp, iv, cipher = self._read_blob()

        core = ensure_core(auto_install=True)
        core.verify_fingerprint(fp)

        plain = core.decrypt_blob(cipher, iv)
        source = plain.decode()

        # Keep inspect/linecache users from reopening the binary .soa file.
        linecache.cache[self.path] = (
            len(plain),
            None,
            source.splitlines(keepends=True),
            self.path,
        )

        module.__file__ = self.path
        module.__loader__ = self

        code = compile(source, self.path, "exec")
        exec(code, module.__dict__)


class SoarFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if path is None:
            path = sys.path
        name = fullname.split(".")[-1]

        for base in path:
            p = os.path.join(base, name + ".soa")
            if os.path.exists(p):
                loader = SoarLoader(fullname, p)
                return importlib.util.spec_from_loader(fullname, loader)

        return None


def enable_loader() -> None:
    if not any(isinstance(finder, SoarFinder) for finder in sys.meta_path):
        sys.meta_path.insert(0, SoarFinder())
