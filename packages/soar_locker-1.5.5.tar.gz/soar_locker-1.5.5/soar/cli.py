import argparse
import json
import os
import sys
import time
import types
import unicodedata
from pathlib import Path

from soar import check_version, get_version, get_version_report_lines
from soar.core_manager import get_installed_core_status, install_matching_core
from soar.loader import SoarLoader, enable_loader

RED = "\033[91m"
GRN = "\033[92m"
YLW = "\033[93m"
BLU = "\033[94m"
RST = "\033[0m"
CYA = "\033[96m"

VERSION = get_version()
CONFIG_DIR_ENV = "SOAR_CONFIG_DIR"
CONFIG_FILE_NAME = "config.json"


def _disp_len(text: str) -> int:
    length = 0
    for ch in text:
        length += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return length


def _pad_disp(text: str, width: int) -> str:
    current = _disp_len(text)
    if current >= width:
        return text
    return text + " " * (width - current)


def print_warning() -> None:
    left_width = 38
    right_width = 40
    left_lines = [
        "[警告] SOAR 不是军事级或商业级保护系统",
        "",
        "适用于：",
        "- 基础代码混淆",
        "- 防止随意复制",
        "- 绑定单台设备",
        "- 教学/轻量级保护",
        "",
        "限制：",
        "- 无法抵御专业逆向",
        "- 不适合高价值算法",
        "- 不能阻止强攻击者",
        "- 不应作为唯一保护手段",
        "",
        "[SOAR] 风险自担",
    ]
    right_lines = [
        "[WARNING] SOAR is NOT a military /",
        "commercial-grade protection system.",
        "",
        "Intended for:",
        "- Simple code obfuscation",
        "- Preventing casual copying",
        "- Binding to one machine",
        "- Education / light protection",
        "",
        "Limitations:",
        "- Cannot resist professionals",
        "- Not for high-value algorithms",
        "- Cannot stop strong attackers",
        "- Not sole protection in products",
        "",
        "[SOAR] Use at your own risk",
    ]

    max_rows = max(len(left_lines), len(right_lines))
    left_lines += [""] * (max_rows - len(left_lines))
    right_lines += [""] * (max_rows - len(right_lines))

    print()
    print(f"{YLW}╔{'═' * (left_width + 2)}╦{'═' * (right_width + 2)}╗{RST}")
    for left, right in zip(left_lines, right_lines):
        print(
            f"{YLW}║ {_pad_disp(left, left_width)} ║ {_pad_disp(right, right_width)} ║{RST}"
        )
    print(f"{YLW}╚{'═' * (left_width + 2)}╩{'═' * (right_width + 2)}╝{RST}")
    print(
        f"{YLW}[SOAR] Tip: use --ignore-waring to hide this warning, "
        f"--show-waring to show it once, or --reset-waring to restore it.{RST}"
    )
    print()


def _config_dir() -> Path:
    override = os.environ.get(CONFIG_DIR_ENV)
    if override:
        return Path(override).expanduser()

    if os.name == "nt":
        root = os.environ.get("APPDATA")
        if root:
            return Path(root) / "soar"

    return Path.home() / ".soar"


def _config_path() -> Path:
    return _config_dir() / CONFIG_FILE_NAME


def _load_config() -> dict:
    path = _config_path()
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as fp:
            data = json.load(fp)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _save_config(config: dict) -> None:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fp:
        json.dump(config, fp, indent=2, sort_keys=True)
        fp.write("\n")


def set_warning_ignored(ignored: bool) -> None:
    config = _load_config()
    config["ignore_warning"] = ignored
    _save_config(config)


def is_warning_ignored() -> bool:
    return bool(_load_config().get("ignore_warning"))


def should_print_warning(args) -> bool:
    if args.show_warning:
        return True
    return not is_warning_ignored()


def print_logo() -> None:
    print(
        f"""{BLU}
╔══════════════════════════════════════════════════════════════╗
║  SOAR - Secure Obfuscated Archives Repository v{VERSION:<10} ║
╚══════════════════════════════════════════════════════════════╝
{RST}""".rstrip()
    )


def loading_animation(duration: float, message: str = "Loading") -> None:
    frames = ["|", "/", "-", "\\"]
    end = time.time() + duration
    idx = 0
    while time.time() < end:
        print(f"\r{CYA}{message} {frames[idx]}{RST}", end="", flush=True)
        idx = (idx + 1) % len(frames)
        time.sleep(0.08)
    print(f"\r{GRN}{message} OK{RST}")


def is_in_bak(path: str) -> bool:
    abs_path = os.path.abspath(path).lower()
    return (
        "\\bak\\" in abs_path
        or "/bak/" in abs_path
        or abs_path.endswith("\\bak")
        or abs_path.endswith("/bak")
    )


def _run_soa(target: str) -> None:
    enable_loader()

    current_dir = os.path.dirname(target)
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)

    module = types.ModuleType("__main__")
    module.__file__ = target
    module.__package__ = None
    loader = SoarLoader("__main__", target)
    loader.exec_module(module)


def _encrypt_file(target: str) -> None:
    from soar.encryptor import encrypt_file

    loading_animation(0.8, "Deriving key")
    print(f"{BLU}[SOAR] Encrypting file...{RST}")
    encrypt_file(target)
    print(f"{GRN}[SOAR] Encryption complete.{RST}")


def _encrypt_directory(target: str) -> None:
    from soar.encryptor import encrypt_file

    loading_animation(0.8, "Deriving key")
    py_files = []
    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d.lower() != "bak"]
        for filename in files:
            if filename.endswith(".py"):
                py_files.append(os.path.join(root, filename))

    if not py_files:
        print(f"{YLW}[SOAR] No Python files found.{RST}")
        return

    print(f"{BLU}[SOAR] Encrypting {len(py_files)} files...{RST}")
    for path in py_files:
        encrypt_file(path)

    print(f"{GRN}[SOAR] Directory encryption complete.{RST}")
    check_version()


def cmd_auto(args) -> None:
    target = os.path.abspath(args.target)

    if os.path.isfile(target) and target.endswith(".soa"):
        _run_soa(target)
        return

    print_logo()
    loading_animation(0.8, "Checking environment")
    if should_print_warning(args):
        print_warning()

    if is_in_bak(target):
        print(f"{RED}[SOAR] ERROR: target is inside bak/.{RST}")
        return

    if os.path.isfile(target) and target.endswith(".py"):
        _encrypt_file(target)
        return

    if os.path.isdir(target):
        _encrypt_directory(target)
        return

    print(f"{RED}[SOAR] Unsupported target:{RST} {target}")


def ensure_runtime_core() -> bool:
    status = get_installed_core_status()
    if status["compatible"]:
        return True

    print(f"{YLW}[SOAR] Native core repair required: {status['reason']}{RST}")
    try:
        install_matching_core(force=status["installed"])
    except RuntimeError as exc:
        print(f"{RED}[SOAR] core repair failed:{RST} {exc}", file=sys.stderr)
        return False
    print(f"{GRN}[SOAR] Native core is ready.{RST}")
    return True


def build():
    parser = argparse.ArgumentParser(
        prog="soar",
        description="SOAR - Secure Obfuscated Archives Repository",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=None,
        help="input file or directory: file.py / file.soa / directory",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="store_true",
        help="show SOAR and soar_core version details",
    )
    parser.add_argument(
        "--repair-core",
        action="store_true",
        help="install or replace soar_core with the wheel matching this OS/architecture",
    )
    parser.add_argument(
        "--core-wheel-dir",
        help="optional local directory containing soar_core wheels for --repair-core",
    )
    parser.add_argument(
        "--ignore-waring",
        "--ignore-warning",
        action="store_true",
        dest="ignore_warning",
        help="persistently hide the SOAR warning banner",
    )
    parser.add_argument(
        "--show-waring",
        "--show-warning",
        action="store_true",
        dest="show_warning",
        help="show the SOAR warning banner once without changing saved preferences",
    )
    parser.add_argument(
        "--reset-waring",
        "--reset-warning",
        action="store_true",
        dest="reset_warning",
        help="persistently re-enable the SOAR warning banner",
    )
    return parser


def main():
    parser = build()
    args = parser.parse_args()
    has_target = args.target is not None

    if args.ignore_warning:
        set_warning_ignored(True)
        print(f"{GRN}[SOAR] Warning banner will be hidden for future commands.{RST}")
        if not has_target:
            return

    if args.reset_warning:
        set_warning_ignored(False)
        print(f"{GRN}[SOAR] Warning banner will be shown for future commands.{RST}")
        if not has_target:
            return

    if args.show_warning and not has_target and not args.repair_core and not args.version:
        print_warning()
        return

    if args.target is None:
        args.target = "."

    if args.repair_core:
        try:
            install_matching_core(force=True, find_links=args.core_wheel_dir)
        except RuntimeError as exc:
            print(f"{RED}[SOAR] core repair failed:{RST} {exc}", file=sys.stderr)
            return 1
        for line in get_version_report_lines():
            print(line)
        return
    if args.version:
        for line in get_version_report_lines():
            print(line)
        return
    if not ensure_runtime_core():
        return 1
    cmd_auto(args)


if __name__ == "__main__":
    main()
