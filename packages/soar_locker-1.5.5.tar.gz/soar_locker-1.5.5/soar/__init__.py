from typing import Dict, List, Optional

from soar.core_manager import get_current_target, get_installed_core_status
from soar.loader import enable_loader


CURRENT_VERSION = "1.5.5"
PACKAGE_NAME = "soar_locker"


def get_version() -> str:
    return CURRENT_VERSION


def _normalize_platform_tag(tag: str) -> str:
    platform_tag = tag.split("-")[-1]
    mapping = {
        "win_amd64": "Windows / amd64",
        "win32": "Windows / x86",
        "win_arm64": "Windows / arm64",
        "linux_x86_64": "Linux / x86_64",
        "linux_aarch64": "Linux / aarch64",
        "manylinux2014_x86_64": "Linux / x86_64",
        "manylinux2014_aarch64": "Linux / aarch64",
        "manylinux_2_17_x86_64": "Linux / x86_64",
        "manylinux_2_17_aarch64": "Linux / aarch64",
        "musllinux_1_1_x86_64": "Linux musl / x86_64",
        "musllinux_1_1_aarch64": "Linux musl / aarch64",
        "macosx_10_9_x86_64": "macOS / x86_64",
        "macosx_11_0_arm64": "macOS / arm64",
    }
    return mapping.get(platform_tag, platform_tag)


def get_soar_core_info() -> Dict[str, object]:
    status = get_installed_core_status()
    if not status["installed"]:
        return {
            "installed": False,
            "name": "soar_core",
            "version": None,
            "compatible": False,
            "target": get_current_target()["label"],
            "reason": status["reason"],
            "platforms": [],
            "tags": [],
        }

    tags: List[str] = []
    platforms: List[str] = []
    for tag in status["tags"]:
        tags.append(tag)
        normalized = _normalize_platform_tag(tag)
        if normalized not in platforms:
            platforms.append(normalized)

    return {
        "installed": True,
        "name": "soar_core",
        "version": status["version"],
        "compatible": status["compatible"],
        "target": get_current_target()["label"],
        "reason": status["reason"],
        "tags": tags,
        "platforms": platforms,
    }


def get_version_report_lines() -> List[str]:
    lines = [f"SOAR-Locker version {get_version()}"]
    lines.append(f"runtime target: {get_current_target()['label']}")
    core_info = get_soar_core_info()
    if not core_info["installed"]:
        lines.append(f"soar_core: not installed ({core_info['reason']})")
        return lines

    state = "compatible" if core_info["compatible"] else "incompatible"
    lines.append(f"soar_core: installed ({core_info['version']}, {state})")
    if not core_info["compatible"]:
        lines.append(f"soar_core issue: {core_info['reason']}")
    if core_info["platforms"]:
        lines.append("soar_core wheel targets:")
        for platform in core_info["platforms"]:
            lines.append(f"  - {platform}")
    if core_info["tags"]:
        lines.append("soar_core wheel tags:")
        for tag in core_info["tags"]:
            lines.append(f"  - {tag}")
    return lines


def check_version() -> None:
    try:
        import requests

        latest = requests.get("https://pypi.org/pypi/soar_locker/json", timeout=5).json()
        latest_ver = latest["info"]["version"]
        if latest_ver != get_version():
            print(f"[SOAR-Locker] A new version ({latest_ver}) is available. Please upgrade.")
    except Exception:
        pass
