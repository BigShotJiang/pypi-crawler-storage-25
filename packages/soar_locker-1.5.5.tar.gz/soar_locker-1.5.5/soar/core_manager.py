import importlib
import os
import platform
import subprocess
import sys
from importlib import metadata
from typing import Dict, List, Optional


CORE_IMPORT_NAME = "soar_core"
CORE_PACKAGE_NAME = "soar-core"
CORE_VERSION = "1.5.0"
CORE_REQUIREMENT = f"{CORE_PACKAGE_NAME}=={CORE_VERSION}"

SUPPORTED_TARGETS = {
    ("windows", "amd64"): {
        "label": "Windows / amd64",
        "wheel_platform_suffix": "amd64",
        "wheel_platforms": {"win_amd64"},
    },
    ("linux", "x86_64"): {
        "label": "Linux / x86_64",
        "wheel_platform_suffix": "x86_64",
        "wheel_platforms": {"linux_x86_64"},
    },
    ("linux", "aarch64"): {
        "label": "Linux / aarch64",
        "wheel_platform_suffix": "aarch64",
        "wheel_platforms": {"linux_aarch64"},
    },
}


def _normalized_os() -> str:
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform.startswith("linux"):
        return "linux"
    return sys.platform


def _normalized_arch() -> str:
    machine = platform.machine().lower().replace("-", "_")
    mapping = {
        "amd64": "amd64",
        "x86_64": "x86_64",
        "aarch64": "aarch64",
        "arm64": "aarch64",
    }
    return mapping.get(machine, machine)


def get_current_target() -> Dict[str, object]:
    os_name = _normalized_os()
    arch = _normalized_arch()
    target = SUPPORTED_TARGETS.get((os_name, arch))
    if target is None:
        return {
            "supported": False,
            "os": os_name,
            "arch": arch,
            "label": f"{os_name} / {arch}",
            "wheel_platform_suffix": "",
            "wheel_platforms": set(),
        }
    return {
        "supported": True,
        "os": os_name,
        "arch": arch,
        "label": target["label"],
        "wheel_platform_suffix": target["wheel_platform_suffix"],
        "wheel_platforms": set(target["wheel_platforms"]),
    }


def _find_core_distribution():
    for candidate in ("soar_core", "soar-core"):
        try:
            return metadata.distribution(candidate)
        except metadata.PackageNotFoundError:
            continue
    return None


def _wheel_tags(dist) -> List[str]:
    tags: List[str] = []
    for file in dist.files or []:
        if str(file).endswith("WHEEL"):
            wheel_text = dist.locate_file(file).read_text(encoding="utf-8", errors="replace")
            for line in wheel_text.splitlines():
                if line.startswith("Tag: "):
                    tags.append(line.split("Tag: ", 1)[1].strip())
            break
    return tags


def _platform_from_tag(tag: str) -> str:
    return tag.rsplit("-", 1)[-1]


def _platform_matches_target(platform_tag: str, target: Dict[str, object]) -> bool:
    if platform_tag in target["wheel_platforms"]:
        return True

    suffix = str(target["wheel_platform_suffix"])
    if target["os"] == "linux" and suffix:
        return platform_tag.endswith(f"_{suffix}") and (
            platform_tag.startswith("manylinux") or platform_tag.startswith("musllinux")
        )

    return False


def _is_core_compatible(dist) -> bool:
    if dist.version != CORE_VERSION:
        return False

    target = get_current_target()
    if not target["supported"]:
        return False

    tags = _wheel_tags(dist)
    if not tags:
        # Editable/local installs may not expose a WHEEL file. If the import works,
        # accept the installed core instead of forcing a reinstall loop.
        try:
            importlib.import_module(CORE_IMPORT_NAME)
            return True
        except Exception:
            return False

    return any(_platform_matches_target(_platform_from_tag(tag), target) for tag in tags)


def get_installed_core_status() -> Dict[str, object]:
    dist = _find_core_distribution()
    if dist is None:
        return {
            "installed": False,
            "compatible": False,
            "version": None,
            "tags": [],
            "reason": "soar_core is not installed",
        }

    compatible = _is_core_compatible(dist)
    tags = _wheel_tags(dist)
    return {
        "installed": True,
        "compatible": compatible,
        "version": dist.version,
        "tags": tags,
        "reason": "compatible" if compatible else "installed soar_core does not match this OS/architecture/version",
    }


def _run_pip(args: List[str]) -> None:
    cmd = [sys.executable, "-m", "pip", *args]
    result = subprocess.run(cmd, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"pip command failed: {' '.join(cmd)}")


def install_matching_core(force: bool = False, find_links: Optional[str] = None) -> None:
    target = get_current_target()
    if not target["supported"]:
        raise RuntimeError(
            f"Unsupported platform for soar_core: {target['label']}. "
            "Supported targets are Windows/amd64, Linux/x86_64 and Linux/aarch64."
        )

    status = get_installed_core_status()
    if status["compatible"] and not force:
        return

    if status["installed"]:
        _run_pip(["uninstall", "-y", CORE_PACKAGE_NAME])

    wheel_dir = find_links or os.environ.get("SOAR_CORE_FIND_LINKS")
    install_args = ["install", "--upgrade", "--only-binary", ":all:"]
    if wheel_dir:
        install_args.extend(["--find-links", wheel_dir])
    install_args.append(CORE_REQUIREMENT)
    try:
        _run_pip(install_args)
    except RuntimeError:
        if wheel_dir:
            raise
        # Some configured package mirrors lag behind PyPI for platform wheels.
        # Retry against the canonical index before reporting that no core exists.
        _run_pip(
            [
                "install",
                "--upgrade",
                "--only-binary",
                ":all:",
                "--no-cache-dir",
                "--index-url",
                "https://pypi.org/simple",
                CORE_REQUIREMENT,
            ]
        )

    importlib.invalidate_caches()
    status = get_installed_core_status()
    if not status["compatible"]:
        raise RuntimeError(
            f"Installed soar_core is still not compatible with {target['label']}. "
            f"Detected status: {status['reason']}"
        )


def ensure_core(auto_install: bool = True):
    status = get_installed_core_status()
    if status["compatible"]:
        return importlib.import_module(CORE_IMPORT_NAME)

    if not auto_install:
        raise RuntimeError(status["reason"])

    install_matching_core(force=status["installed"])
    return importlib.import_module(CORE_IMPORT_NAME)
