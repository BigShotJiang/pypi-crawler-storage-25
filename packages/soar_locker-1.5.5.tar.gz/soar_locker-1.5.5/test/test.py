from soar import enable_loader

enable_loader()

from hello import hello


def main() -> None:
    print(hello("SOAR"))


if __name__ == "__main__":
    main()
