import datetime
import logging
import warnings
from pathlib import Path

import pandas as pd
from django.db import transaction
from django.db.models import Count, Q, QuerySet
from django.db.models.functions import TruncDate, TruncHour
from django.utils.translation import gettext_lazy as _

from quant_tick.constants import FileData, Frequency
from quant_tick.lib import (
    aggregate_candle,
    get_existing,
    get_min_time,
    get_next_time,
    has_timestamps,
    is_decimal_close,
    iter_timeframe,
    merge_cache,
)
from quant_tick.models import Candle, CandleCache, Symbol, TradeData
from quant_tick.models.trades import (
    upload_aggregated_data_to,
    upload_filtered_data_to,
    upload_raw_data_to,
)

logger = logging.getLogger(__name__)


def convert_candle_cache_to_daily(candle: Candle) -> None:
    """Convert candle cache, by minute or hour, to daily.

    * Convert, from past to present, in order.
    """
    candle_cache = CandleCache.objects.filter(candle=candle)
    last_daily_cache = (
        candle_cache.filter(frequency=Frequency.DAY)
        .only("timestamp")
        .order_by("-timestamp")
        .first()
    )
    if last_daily_cache:
        hourly_or_minute_cache = candle_cache.filter(
            timestamp__lt=last_daily_cache.timestamp, frequency__lt=Frequency.DAY
        )
        unique_dates = (
            hourly_or_minute_cache.annotate(date=TruncDate("timestamp"))
            .values("date")
            .annotate(unique=Count("date"))
        )
        if unique_dates.count() <= 1:
            timestamp_from = last_daily_cache.timestamp
        else:
            timestamp_from = hourly_or_minute_cache.only("timestamp").first().timestamp
    else:
        any_cache = candle_cache.only("timestamp").first()
        if any_cache:
            timestamp_from = any_cache.timestamp
        else:
            timestamp_from = None
    if timestamp_from:
        timestamp_to = candle_cache.only("timestamp").last().timestamp
        for daily_ts_from, daily_ts_to in iter_timeframe(
            get_min_time(timestamp_from, value="1d"),
            get_next_time(timestamp_to, value="1d"),
            value="1d",
        ):
            delta = daily_ts_to - daily_ts_from
            total_minutes = delta.total_seconds() / Frequency.HOUR
            if total_minutes == Frequency.DAY:
                target_cache = CandleCache.objects.filter(
                    candle=candle,
                    timestamp__gte=daily_ts_from,
                    timestamp__lt=daily_ts_to,
                    frequency__lt=Frequency.DAY,
                )
                existing = get_existing(target_cache.values("timestamp", "frequency"))
                if has_timestamps(daily_ts_from, daily_ts_to, existing):
                    with transaction.atomic():
                        daily_cache, created = CandleCache.objects.get_or_create(
                            candle=candle,
                            timestamp=daily_ts_from,
                            frequency=Frequency.DAY,
                        )
                        daily_cache.json_data = (
                            target_cache.order_by("-timestamp").first().json_data
                        )
                        daily_cache.save()
                        target_cache.delete()
                    logging.info(
                        _("Converted {date} to daily").format(
                            **{"date": daily_ts_from.date()}
                        )
                    )


def convert_trade_data_to_daily(
    symbol: Symbol, timestamp_from: datetime.datetime, timestamp_to: datetime.datetime
) -> None:
    """Convert trade data by minute, or hourly, to daily.

    * Convert any order.
    """
    queryset = TradeData.objects.filter(
        symbol=symbol, frequency__in=(Frequency.MINUTE, Frequency.HOUR)
    )
    trade_data = queryset.filter(
        timestamp__gte=timestamp_from, timestamp__lte=timestamp_to
    )
    if trade_data.exists():
        first = trade_data.first()
        last = trade_data.last()
        min_timestamp_from = first.timestamp
        if timestamp_from < min_timestamp_from:
            timestamp_from = min_timestamp_from
        max_timestamp_to = last.timestamp + pd.Timedelta(f"{last.frequency}min")
        if timestamp_to > max_timestamp_to:
            timestamp_to = max_timestamp_to
        for daily_ts_from, daily_ts_to in iter_timeframe(
            timestamp_from, timestamp_to, value="1d", reverse=True
        ):
            # First, convert any complete hours of minute data to hourly.
            minute_trade_data = queryset.filter(
                timestamp__gte=daily_ts_from,
                timestamp__lt=daily_ts_to,
                frequency=Frequency.MINUTE,
            )
            if minute_trade_data.exists():
                complete_hours = (
                    minute_trade_data.annotate(hour=TruncHour("timestamp"))
                    .values("hour")
                    .annotate(count=Count("id"))
                    .filter(count=Frequency.HOUR)
                    .order_by("-hour")
                )
                for item in complete_hours:
                    hourly_ts_from = item["hour"]
                    hourly_ts_to = hourly_ts_from + pd.Timedelta("1h")
                    hour_minute_data = minute_trade_data.filter(
                        timestamp__gte=hourly_ts_from,
                        timestamp__lt=hourly_ts_to,
                    )
                    convert_trade_data(symbol, hour_minute_data, hourly_ts_from, hourly_ts_to)

            # Then, convert hourly to daily if complete.
            hourly_trade_data = queryset.filter(
                timestamp__gte=daily_ts_from,
                timestamp__lt=daily_ts_to,
                frequency=Frequency.HOUR,
            )
            is_complete_day = (
                daily_ts_from == get_min_time(daily_ts_from, "1d")
                and daily_ts_to == daily_ts_from + pd.Timedelta("1d")
            )
            hourly_values = list(hourly_trade_data.values("timestamp", "frequency"))
            hourly_existing = get_existing(hourly_values)
            if (
                is_complete_day
                and len(hourly_values) == Frequency.DAY // Frequency.HOUR
                and has_timestamps(daily_ts_from, daily_ts_to, hourly_existing)
            ):
                convert_trade_data(symbol, hourly_trade_data, daily_ts_from, daily_ts_to)
    logger.info("{symbol}: done".format(symbol=str(symbol)))


def convert_trade_data(
    symbol: Symbol,
    trade_data: QuerySet,
    timestamp_from: datetime.datetime,
    timestamp_to: datetime.datetime,
) -> None:
    """Convert trade data."""
    objs = list(trade_data)
    delta = timestamp_to - timestamp_from
    frequency = delta.total_seconds() / 60
    assert frequency in (Frequency.HOUR, Frequency.DAY)
    first = objs[0]

    prepared_files = {}
    candle_df = None
    trade_candles = [
        dict(obj.json_data["candle"])
        for obj in objs
        if obj.json_data is not None and "candle" in obj.json_data
    ]
    for file_data in symbol.trade_data_fields:
        data_frames = {
            t: t.get_data_frame(file_data)
            for t in objs
            if getattr(t, file_data).name
        }

        if len(data_frames):
            # Ignore: The behavior of DataFrame concatenation with empty or
            # all-NA entries is deprecated.
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=FutureWarning)
                data_frame = pd.concat(data_frames.values())

            key = (
                "notional"
                if file_data in (FileData.RAW, FileData.AGGREGATED)
                else "totalNotional"
            )
            expected = sum([getattr(df, key).sum() for df in data_frames.values()])
            actual = data_frame[key].sum()
            assert is_decimal_close(expected, actual)

            # Next, create hourly or daily.
            data_frame.reset_index(inplace=True)

            if len(data_frame):
                prepared_files[file_data] = TradeData.prepare_data(data_frame)
                if file_data in (
                    FileData.RAW,
                    FileData.AGGREGATED,
                    FileData.FILTERED,
                ):
                    candle_df = data_frame

    json_data = None
    if len(trade_candles) == len(objs) and trade_candles:
        candle = trade_candles[0]
        for payload in trade_candles[1:]:
            candle = merge_cache(candle, dict(payload))
        json_data = {"candle": candle}
    elif candle_df is not None:
        candle = aggregate_candle(
            candle_df,
            min_volume_exponent=1,
            min_notional_exponent=1,
        )
        json_data = {"candle": candle}

    for obj in objs:
        obj.delete()

    t = TradeData(
        symbol=symbol,
        timestamp=first.timestamp,
        uid=first.uid,
        frequency=frequency,
        ok=all(obj.ok for obj in objs),
        json_data=json_data,
    )
    for file_data, prepared in prepared_files.items():
        setattr(t, file_data, prepared)
    t.save()

    logging.info(
        _("Converted {timestamp_from} {timestamp_to} to {frequency}").format(
            **{
                "timestamp_from": timestamp_from,
                "timestamp_to": timestamp_to,
                "frequency": "daily" if frequency == Frequency.DAY else "hourly",
            }
        )
    )


def clean_trade_data_with_non_existing_files(
    symbol: Symbol, timestamp_from: datetime.datetime, timestamp_to: datetime.datetime
) -> None:
    """Clean trade data with non-existing files."""
    logging.info(_("Checking objects with non existent files"))

    fields = symbol.trade_data_fields
    if not fields:
        return

    exclude = Q()
    for f in fields:
        exclude |= Q(**{f: ""})

    trade_data = (
        TradeData.objects.filter(symbol=symbol)
        .exclude(exclude)
        .filter(
            timestamp__gte=timestamp_from,
            timestamp__lte=timestamp_to,
        )
        .only(*fields)
    )
    count = 0
    deleted = 0
    total = trade_data.count()
    for obj in trade_data:
        count += 1
        for field in fields:
            if getattr(obj, field):
                f = getattr(obj, field)
                if not f.storage.exists(f.name):
                    deleted += 1
                    obj.delete()
                    break

        logging.info(
            _("Checked {count}/{total} objects").format(
                **{"count": count, "total": total}
            )
        )

    logging.info(_("Deleted {deleted} objects").format(**{"deleted": deleted}))


def clean_unlinked_trade_data_files(
    symbol: Symbol, timestamp_from: datetime.datetime, timestamp_to: datetime.datetime
) -> None:
    """Clean unlinked trade data files."""
    logging.info(_("Checking unlinked trade data files"))

    fields = symbol.trade_data_fields
    if not fields:
        return

    exclude = Q()
    for f in fields:
        exclude |= Q(**{f: ""})

    trade_data = TradeData.objects.filter(symbol=symbol).exclude(exclude).only(*fields)
    t = trade_data.filter(
        timestamp__gte=timestamp_from,
        timestamp__lte=timestamp_to,
    )

    deleted = 0
    mapping = {
        k: v
        for k, v in {
            FileData.RAW: upload_raw_data_to,
            FileData.AGGREGATED: upload_aggregated_data_to,
            FileData.FILTERED: upload_filtered_data_to,
        }.items()
        if k in fields
    }
    if t.exists():
        min_timestamp_from = t.first().timestamp
        if timestamp_from < min_timestamp_from:
            timestamp_from = min_timestamp_from
        max_timestamp_to = t.last().timestamp
        if timestamp_to > max_timestamp_to:
            timestamp_to = max_timestamp_to
        for daily_timestamp_from, daily_timestamp_to in iter_timeframe(
            timestamp_from, timestamp_to, value="1d"
        ):
            for file_data, upload_to in mapping.items():
                expected_files = [
                    Path(getattr(obj, file_data).name).name
                    for obj in trade_data.filter(
                        timestamp__gte=daily_timestamp_from,
                        timestamp__lte=daily_timestamp_to,
                    )
                ]

                dummy = TradeData(symbol=symbol, timestamp=daily_timestamp_from)
                storage = getattr(dummy, file_data).storage
                directory = Path(upload_to(dummy, "dummy.parquet")).stem
                __, filenames = storage.listdir(directory)

                should_delete = [
                    filename for filename in filenames if filename not in expected_files
                ]
                for filename in should_delete:
                    storage.delete(Path(directory) / filename)
                    deleted += 1

            logging.info(
                _("Checked {date}").format(**{"date": daily_timestamp_from.date()})
            )

        logging.info(
            _("Deleted {deleted} unlinked files").format(**{"deleted": deleted})
        )
    logger.info("{symbol}: done".format(symbol=str(symbol)))


def clean_trade_data_overlaps(
    symbol: Symbol, timestamp_from: datetime.datetime, timestamp_to: datetime.datetime
) -> int:
    """Delete lower-frequency rows already covered by higher-frequency TradeData."""
    deleted = 0

    daily_rows = list(
        TradeData.objects.overlapping(
            symbol, timestamp_from, timestamp_to, Frequency.DAY
        ).only("timestamp")
    )
    for row in daily_rows:
        deleted += TradeData.objects.cleanup(
            symbol,
            row.timestamp,
            row.timestamp + pd.Timedelta("1d"),
            (Frequency.HOUR, Frequency.MINUTE),
        )

    hourly_rows = list(
        TradeData.objects.overlapping(
            symbol, timestamp_from, timestamp_to, Frequency.HOUR
        ).only("timestamp")
    )
    for row in hourly_rows:
        deleted += TradeData.objects.cleanup(
            symbol,
            row.timestamp,
            row.timestamp + pd.Timedelta("1h"),
            Frequency.MINUTE,
        )

    if deleted:
        logger.info(
            _("{symbol}: deleted {deleted} overlapping trade-data rows").format(
                symbol=str(symbol), deleted=deleted
            )
        )
    else:
        logger.info("{symbol}: no overlapping trade-data rows".format(symbol=str(symbol)))
    return deleted
