API_URL = "https://api.exchange.coinbase.com"
TRADE_MAX_RESULTS = 100
CANDLE_MAX_RESULTS = 300
MIN_ELAPSED_PER_REQUEST = 1 / 3.0  # 3 req/s

# Symbols for trade verification
BTCUSD = "BTC-USD"
ETHUSD = "ETH-USD"
