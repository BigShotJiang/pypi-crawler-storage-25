from datetime import datetime
from functools import partial

from quant_tick.controllers import iter_api

from .api import (
    get_bitfinex_api_pagination_id,
    get_bitfinex_api_response,
    get_bitfinex_api_timestamp,
    get_bitfinex_api_url,
)
from .constants import API_URL, MIN_ELAPSED_PER_REQUEST, TRADE_MAX_RESULTS


def get_trades(
    symbol: str,
    timestamp_from: datetime,
    pagination_id: int,
    log_format: str | None = None,
) -> list[dict]:
    # No start query param
    # Specifying start, end returns TRADE_MAX_RESULTS
    url = f"{API_URL}/trades/{symbol}/hist?limit={TRADE_MAX_RESULTS}"
    return iter_api(
        url,
        get_bitfinex_api_pagination_id,
        get_bitfinex_api_timestamp,
        partial(get_bitfinex_api_response, get_bitfinex_api_url),
        TRADE_MAX_RESULTS,
        MIN_ELAPSED_PER_REQUEST,
        timestamp_from=timestamp_from,
        pagination_id=pagination_id,
        log_format=log_format,
    )
