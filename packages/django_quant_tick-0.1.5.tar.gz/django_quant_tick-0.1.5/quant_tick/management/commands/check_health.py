import json
from datetime import datetime

import pandas as pd
from django.core.management.base import BaseCommand, CommandParser
from django.utils import timezone

from quant_tick.constants import Exchange, SymbolType
from quant_tick.models import (
    Candle,
    CandleCache,
    CandleData,
    ExchangeCandleData,
    FundingData,
    Symbol,
    TaskState,
    TradeData,
)


def isoformat(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


def coverage_end(timestamp: datetime, frequency: int) -> datetime:
    return timestamp + pd.Timedelta(f"{frequency}min")


def lag_minutes(now: datetime, value: datetime | None) -> int | None:
    if value is None:
        return None
    return int((now - value).total_seconds() // 60)


class Command(BaseCommand):
    help = "Report read-only Quant Tick ingestion and aggregation health."

    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument(
            "--exchange",
            type=Exchange,
            choices=Exchange.values,
            nargs="+",
        )
        parser.add_argument("--api-symbol", nargs="+")
        parser.add_argument(
            "--symbol-type",
            type=SymbolType,
            choices=SymbolType.values,
            nargs="+",
        )
        parser.add_argument("--json", action="store_true")

    def handle(self, *args, **options) -> None:
        now = timezone.now()
        report = {
            "generated_at": isoformat(now),
            "tasks": self.get_task_state(now),
            "symbols": self.get_symbols(now, options),
        }
        if options["json"]:
            self.stdout.write(json.dumps(report, indent=2))
        else:
            self.write_text(report)

    def get_task_state(self, now: datetime) -> list[dict]:
        return [
            {
                "task_type": task_state.task_type,
                "exchange": task_state.exchange,
                "recent_error_count": task_state.recent_error_count,
                "recent_error_at": isoformat(task_state.recent_error_at),
                "next_fetch_at": isoformat(task_state.next_fetch_at),
                "locked_until": isoformat(task_state.locked_until),
                "backoff": (
                    task_state.next_fetch_at is not None
                    and task_state.next_fetch_at > now
                ),
                "locked": (
                    task_state.locked_until is not None
                    and task_state.locked_until > now
                ),
            }
            for task_state in TaskState.objects.all()
        ]

    def get_symbols(self, now: datetime, options: dict) -> list[dict]:
        symbols = Symbol.objects.filter(is_active=True)
        exchanges = options.get("exchange")
        api_symbols = options.get("api_symbol")
        symbol_types = options.get("symbol_type")
        if exchanges:
            symbols = symbols.filter(exchange__in=exchanges)
        if api_symbols:
            symbols = symbols.filter(api_symbol__in=api_symbols)
        if symbol_types:
            symbols = symbols.filter(symbol_type__in=symbol_types)
        return [self.get_symbol_health(symbol, now) for symbol in symbols]

    def get_symbol_health(self, symbol: Symbol, now: datetime) -> dict:
        latest_trade_data = (
            TradeData.objects.filter(symbol=symbol)
            .only("timestamp", "frequency", "ok")
            .order_by("-timestamp")
            .first()
        )
        trade_data_until = None
        if latest_trade_data:
            trade_data_until = coverage_end(
                latest_trade_data.timestamp,
                latest_trade_data.frequency,
            )
        latest_funding = (
            FundingData.objects.filter(symbol=symbol).only("timestamp").last()
        )
        latest_exchange_candle = (
            ExchangeCandleData.objects.filter(symbol=symbol)
            .only("timestamp", "frequency")
            .order_by("-timestamp")
            .first()
        )
        exchange_candle_until = None
        if latest_exchange_candle:
            exchange_candle_until = latest_exchange_candle.coverage_end()
        return {
            "exchange": symbol.exchange,
            "api_symbol": symbol.api_symbol,
            "symbol_type": symbol.symbol_type,
            "code_name": symbol.code_name,
            "trade_data_count": TradeData.objects.filter(symbol=symbol).count(),
            "trade_data_until": isoformat(trade_data_until),
            "trade_data_lag_minutes": lag_minutes(now, trade_data_until),
            "trade_data_latest_timestamp": isoformat(
                latest_trade_data.timestamp if latest_trade_data else None
            ),
            "trade_data_latest_frequency": (
                latest_trade_data.frequency if latest_trade_data else None
            ),
            "trade_data_latest_ok": latest_trade_data.ok if latest_trade_data else None,
            "funding_data_count": FundingData.objects.filter(symbol=symbol).count(),
            "funding_data_latest_timestamp": isoformat(
                latest_funding.timestamp if latest_funding else None
            ),
            "funding_data_lag_minutes": lag_minutes(
                now,
                latest_funding.timestamp if latest_funding else None,
            ),
            "exchange_candle_data_count": ExchangeCandleData.objects.filter(
                symbol=symbol
            ).count(),
            "exchange_candle_data_until": isoformat(exchange_candle_until),
            "exchange_candle_data_lag_minutes": lag_minutes(
                now,
                exchange_candle_until,
            ),
            "exchange_candle_data_latest_timestamp": isoformat(
                latest_exchange_candle.timestamp if latest_exchange_candle else None
            ),
            "exchange_candle_data_latest_frequency": (
                latest_exchange_candle.frequency if latest_exchange_candle else None
            ),
            "candles": [
                self.get_candle_health(candle, now)
                for candle in Candle.objects.filter(symbol=symbol, is_active=True)
            ],
        }

    def get_candle_health(self, candle: Candle, now: datetime) -> dict:
        latest_cache = (
            CandleCache.objects.filter(candle=candle)
            .only("timestamp", "frequency")
            .order_by("-timestamp")
            .first()
        )
        latest_data = (
            CandleData.objects.filter(candle=candle)
            .only("timestamp")
            .order_by("-timestamp")
            .first()
        )
        cache_until = None
        if latest_cache:
            cache_until = coverage_end(latest_cache.timestamp, latest_cache.frequency)
        return {
            "code_name": candle.code_name,
            "model": candle.__class__.__name__,
            "candle_cache_count": CandleCache.objects.filter(candle=candle).count(),
            "candle_cache_until": isoformat(cache_until),
            "candle_cache_lag_minutes": lag_minutes(now, cache_until),
            "candle_cache_latest_timestamp": isoformat(
                latest_cache.timestamp if latest_cache else None
            ),
            "candle_cache_latest_frequency": (
                latest_cache.frequency if latest_cache else None
            ),
            "candle_data_count": CandleData.objects.filter(candle=candle).count(),
            "candle_data_latest_timestamp": isoformat(
                latest_data.timestamp if latest_data else None
            ),
        }

    def write_text(self, report: dict) -> None:
        self.stdout.write(f"generated_at={report['generated_at']}")
        self.stdout.write("tasks:")
        for task in report["tasks"]:
            exchange = task["exchange"] or "-"
            self.stdout.write(
                "  "
                f"{task['task_type']} {exchange} "
                f"errors={task['recent_error_count']} "
                f"backoff={task['backoff']} "
                f"locked={task['locked']} "
                f"next_fetch_at={task['next_fetch_at'] or '-'} "
                f"locked_until={task['locked_until'] or '-'}"
            )
        self.stdout.write("symbols:")
        for symbol in report["symbols"]:
            self.stdout.write(
                "  "
                f"{symbol['exchange']} {symbol['api_symbol']} "
                f"{symbol['symbol_type']} {symbol['code_name']} "
                f"trade_until={symbol['trade_data_until'] or '-'} "
                f"trade_lag_min={symbol['trade_data_lag_minutes']} "
                f"trade_rows={symbol['trade_data_count']} "
                f"funding_latest={symbol['funding_data_latest_timestamp'] or '-'} "
                f"funding_rows={symbol['funding_data_count']} "
                f"exchange_candle_until={symbol['exchange_candle_data_until'] or '-'} "
                f"exchange_candle_rows={symbol['exchange_candle_data_count']}"
            )
            for candle in symbol["candles"]:
                self.stdout.write(
                    "    "
                    f"{candle['code_name']} {candle['model']} "
                    f"cache_until={candle['candle_cache_until'] or '-'} "
                    f"cache_lag_min={candle['candle_cache_lag_minutes']} "
                    f"cache_rows={candle['candle_cache_count']} "
                    f"data_latest={candle['candle_data_latest_timestamp'] or '-'} "
                    f"data_rows={candle['candle_data_count']}"
                )
