import json
from datetime import UTC, datetime
from decimal import Decimal
from io import StringIO

import pandas as pd
import time_machine
from django.core.management import call_command
from django.test import TestCase

from quant_tick.constants import Frequency, SymbolType, TaskType
from quant_tick.models import (
    Candle,
    CandleCache,
    CandleData,
    ExchangeCandleData,
    FundingData,
    TaskState,
    TradeData,
)

from ..base import BaseSymbolTest


@time_machine.travel(datetime(2026, 4, 29, 12, tzinfo=UTC), tick=False)
class CheckHealthCommandTest(BaseSymbolTest, TestCase):
    def test_check_health_reports_trade_and_candle_freshness(self):
        symbol = self.get_symbol(api_symbol="BTC-USD")
        trade_timestamp = self.timestamp_from + pd.Timedelta("1h")
        TradeData.objects.create(
            symbol=symbol,
            timestamp=trade_timestamp,
            frequency=Frequency.HOUR,
            ok=True,
        )
        candle = Candle.objects.create(symbol=symbol, json_data={})
        cache_timestamp = self.timestamp_from + pd.Timedelta("2h")
        CandleCache.objects.create(
            candle=candle,
            timestamp=cache_timestamp,
            frequency=Frequency.HOUR,
            json_data={},
        )
        CandleData.objects.create(
            candle=candle,
            timestamp=cache_timestamp,
            open=Decimal("1"),
            high=Decimal("2"),
            low=Decimal("0.5"),
            close=Decimal("1.5"),
            volume=Decimal("10"),
            buy_volume=Decimal("5"),
            notional=Decimal("100"),
            buy_notional=Decimal("50"),
            ticks=2,
            buy_ticks=1,
            realized_variance=Decimal("0.1"),
        )
        FundingData.objects.create(
            symbol=symbol,
            timestamp=cache_timestamp,
            funding_rate=Decimal("0.0001"),
        )
        ExchangeCandleData.objects.create(
            symbol=symbol,
            timestamp=cache_timestamp,
            frequency=Frequency.HOUR,
            open=Decimal("1"),
            high=Decimal("2"),
            low=Decimal("0.5"),
            close=Decimal("1.5"),
            notional=Decimal("10"),
        )
        TaskState.objects.create(
            task_type=TaskType.AGGREGATE_TRADES,
            exchange=symbol.exchange,
        )
        stdout = StringIO()

        call_command("check_health", "--json", stdout=stdout)

        report = json.loads(stdout.getvalue())
        self.assertEqual(report["tasks"][0]["task_type"], TaskType.AGGREGATE_TRADES)
        self.assertEqual(report["symbols"][0]["api_symbol"], "BTC-USD")
        self.assertEqual(report["symbols"][0]["symbol_type"], SymbolType.SPOT)
        self.assertEqual(
            report["symbols"][0]["trade_data_until"],
            (trade_timestamp + pd.Timedelta("1h")).isoformat(),
        )
        self.assertEqual(
            report["symbols"][0]["candles"][0]["candle_cache_until"],
            (cache_timestamp + pd.Timedelta("1h")).isoformat(),
        )
        self.assertEqual(
            report["symbols"][0]["candles"][0]["candle_data_latest_timestamp"],
            cache_timestamp.isoformat(),
        )
        self.assertEqual(
            report["symbols"][0]["funding_data_latest_timestamp"],
            cache_timestamp.isoformat(),
        )
        self.assertEqual(
            report["symbols"][0]["exchange_candle_data_until"],
            (cache_timestamp + pd.Timedelta("1h")).isoformat(),
        )

    def test_check_health_filters_by_api_symbol(self):
        self.get_symbol(api_symbol="BTC-USD")
        self.get_symbol(api_symbol="ETH-USD")
        stdout = StringIO()

        call_command("check_health", "--json", "--api-symbol", "ETH-USD", stdout=stdout)

        report = json.loads(stdout.getvalue())
        self.assertEqual(len(report["symbols"]), 1)
        self.assertEqual(report["symbols"][0]["api_symbol"], "ETH-USD")

    def test_check_health_filters_by_symbol_type(self):
        self.get_symbol(api_symbol="BTC-USD", symbol_type=SymbolType.SPOT)
        self.get_symbol(api_symbol="BTC-PERP", symbol_type=SymbolType.PERPETUAL)
        stdout = StringIO()

        call_command(
            "check_health",
            "--json",
            "--symbol-type",
            SymbolType.PERPETUAL,
            stdout=stdout,
        )

        report = json.loads(stdout.getvalue())
        self.assertEqual(len(report["symbols"]), 1)
        self.assertEqual(report["symbols"][0]["api_symbol"], "BTC-PERP")
        self.assertEqual(report["symbols"][0]["symbol_type"], SymbolType.PERPETUAL)
