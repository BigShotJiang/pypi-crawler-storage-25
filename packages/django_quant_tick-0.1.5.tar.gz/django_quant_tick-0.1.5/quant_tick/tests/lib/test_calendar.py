from datetime import UTC, datetime, time

import pandas as pd
from django.test import SimpleTestCase

from quant_tick.lib import (
    get_complete_interval_end,
    get_current_time,
    get_min_time,
    get_next_time,
    get_range,
    iter_chunks,
    iter_missing,
    iter_timeframe,
    iter_window,
    parse_period_from_to,
)


class GetMinTimeTest(SimpleTestCase):
    def test_get_min_time_1d(self):
        now = get_current_time()
        min_time = get_min_time(now, value="1d")
        self.assertEqual(
            min_time,
            datetime.combine(min_time.date(), time.min).replace(tzinfo=UTC),
        )


class GetNexttimeTest(SimpleTestCase):
    def test_get_next_minute(self):
        now = get_current_time()
        tomorrow = get_next_time(now, value="1d")
        self.assertEqual(
            tomorrow,
            datetime.combine(tomorrow.date(), time.min).replace(tzinfo=UTC),
        )


class GetCompleteIntervalEndTest(SimpleTestCase):
    def test_get_complete_interval_end_uses_full_interval(self):
        timestamp = datetime(2026, 4, 25, 10, 53, tzinfo=UTC)

        result = get_complete_interval_end(timestamp, "90m")

        self.assertEqual(result, datetime(2026, 4, 25, 10, 30, tzinfo=UTC))


class GetRangeTest(SimpleTestCase):
    def setUp(self):
        now = get_current_time()
        self.timestamp_from = get_min_time(now, value="1d")

    def test_get_range_1m(self):
        one_minute = pd.Timedelta("1min")
        timestamp_to = get_next_time(self.timestamp_from, value="1d") - one_minute
        values = get_range(self.timestamp_from, timestamp_to)
        self.assertEqual(len(values), 1440)
        self.assertEqual(values[0], self.timestamp_from)
        self.assertEqual(values[-1], timestamp_to)

    def test_get_range_1d(self):
        values = get_range(self.timestamp_from, self.timestamp_from, value="1d")
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0], self.timestamp_from)


class IterWindowTest(SimpleTestCase):
    def setUp(self):
        one_day = pd.Timedelta("1d")
        self.now = get_current_time()
        self.yesterday = self.now - one_day
        self.two_days_ago = self.yesterday - one_day

    def test_iter_window(self):
        values = [
            value for value in iter_window(self.two_days_ago, self.now, value="1d")
        ]
        self.assertEqual(len(values), 2)
        self.assertEqual(values[0][0], get_min_time(self.two_days_ago, value="1d"))
        self.assertEqual(values[1][1], get_min_time(self.now, value="1d"))

    def test_iter_window_reverse(self):
        values = [
            value
            for value in iter_window(
                self.two_days_ago, self.now, value="1d", reverse=True
            )
        ]
        self.assertEqual(len(values), 2)
        self.assertEqual(values[0][1], get_min_time(self.now, value="1d"))
        self.assertEqual(values[1][0], get_min_time(self.two_days_ago, value="1d"))


class IterChunksTest(SimpleTestCase):
    def test_iter_chunks_reverse_keeps_partial_newest_window(self):
        timestamp_from = datetime(2026, 1, 1, tzinfo=UTC)
        timestamp_to = datetime(2026, 2, 1, tzinfo=UTC)

        values = list(
            iter_chunks(
                timestamp_from,
                timestamp_to,
                value="14d",
                reverse=True,
            )
        )

        self.assertEqual(
            values,
            [
                (
                    datetime(2026, 1, 18, tzinfo=UTC),
                    datetime(2026, 2, 1, tzinfo=UTC),
                ),
                (
                    datetime(2026, 1, 4, tzinfo=UTC),
                    datetime(2026, 1, 18, tzinfo=UTC),
                ),
                (
                    datetime(2026, 1, 1, tzinfo=UTC),
                    datetime(2026, 1, 4, tzinfo=UTC),
                ),
            ],
        )


class IterTimeframeTest(SimpleTestCase):
    def setUp(self):
        self.now = get_current_time()

    def get_values(
        self, timestamp_from: datetime, timestamp_to: datetime, value: str = "1d"
    ) -> list[tuple]:
        return [
            value
            for value in iter_timeframe(
                timestamp_from, timestamp_to, value=value, reverse=True
            )
        ]

    def test_iter_timeframe_with_head_and_no_body(self):
        date_from = self.now.date().isoformat()
        time_from = self.now.time().isoformat()
        timestamp_from, timestamp_to = parse_period_from_to(
            date_from=date_from, time_from=time_from
        )
        values = self.get_values(timestamp_from, timestamp_to)
        self.assertEqual(len(values), 1)
        ts_from, ts_to = values[0]
        self.assertEqual(ts_from, get_min_time(timestamp_from, "1min"))
        self.assertEqual(ts_to, get_min_time(timestamp_to, "1min"))

    def test_iter_timeframe_with_tail_only(self):
        yesterday = self.now - pd.Timedelta("1d")
        date_from = yesterday.date().isoformat()
        time_from = yesterday.time().isoformat()
        date_to = self.now.date().isoformat()
        timestamp_from, timestamp_to = parse_period_from_to(
            date_from=date_from, time_from=time_from, date_to=date_to
        )
        values = self.get_values(timestamp_from, timestamp_to)
        self.assertEqual(len(values), 1)

    def test_iter_timeframe_with_head(self):
        yesterday = get_min_time(self.now, "2d") + pd.Timedelta("1m")
        today = get_min_time(self.now, "1d")
        timestamp_from, timestamp_to = parse_period_from_to(
            date_from=yesterday.date().isoformat(),
            time_from=yesterday.time().isoformat(),
            date_to=today.date().isoformat(),
            time_to=today.time().isoformat(),
        )
        values = self.get_values(timestamp_from, timestamp_to)
        target = len(values) - 1
        for index, value in enumerate(values):
            ts_from, ts_to = value
            if index != target:
                self.assertEqual(ts_from + pd.Timedelta("1d"), ts_to)
            else:
                self.assertEqual(ts_from, timestamp_from)
                self.assertEqual(ts_to, get_min_time(ts_to, value="1d"))

    def test_iter_timeframe_with_neither_head_nor_tail(self):
        yesterday = self.now - pd.Timedelta("1d")
        two_days_ago = self.now - pd.Timedelta("2d")
        timestamp_from, timestamp_to = parse_period_from_to(
            date_from=two_days_ago.date().isoformat(),
            date_to=yesterday.date().isoformat(),
        )
        values = self.get_values(timestamp_from, timestamp_to)
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0][0], timestamp_from)
        self.assertEqual(values[0][1], timestamp_to)

    def test_iter_timeframe_with_tail(self):
        timestamp = get_min_time(self.now, "1d") - pd.Timedelta("1m")
        timestamp_from, timestamp_to = parse_period_from_to(
            date_to=timestamp.date().isoformat(), time_to=timestamp.time().isoformat()
        )
        values = self.get_values(timestamp_from, timestamp_to)
        for index, value in enumerate(values):
            ts_from, ts_to = value
            if index == 0:
                self.assertEqual(ts_from, get_min_time(ts_from, value="1d"))
                self.assertEqual(ts_to, timestamp_to)
            else:
                self.assertEqual(ts_from + pd.Timedelta("1d"), ts_to)


class IterMissingTest(SimpleTestCase):
    def setUp(self):
        self.one_minute = pd.Timedelta("1min")
        self.timestamp_from = get_min_time(get_current_time(), "1d")
        self.timestamp_to = self.timestamp_from + (self.one_minute * 5)
        self.timestamps = get_range(self.timestamp_from, self.timestamp_to)

    def test_iter_missing_with_no_missing(self):
        values = [
            value for value in iter_missing(self.timestamp_from, self.timestamp_to, [])
        ]
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0][0], self.timestamp_from)
        self.assertEqual(values[-1][1], self.timestamp_to)

    def test_iter_missing_with_head(self):
        existing = self.timestamps[0]
        values = [
            value
            for value in iter_missing(
                self.timestamp_from, self.timestamp_to, [existing]
            )
        ]
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0][0], self.timestamp_from + self.one_minute)
        self.assertEqual(values[-1][1], self.timestamp_to)

    def test_iter_missing_with_one_timestamp_ok(self):
        existing = self.timestamps[1]
        values = [
            value
            for value in iter_missing(
                self.timestamp_from, self.timestamp_to, [existing]
            )
        ]
        self.assertEqual(len(values), 2)
        self.assertEqual(values[0][0], self.timestamp_from)
        self.assertEqual(values[0][1], existing)
        self.assertEqual(values[-1][0], existing + self.one_minute)
        self.assertEqual(values[-1][1], self.timestamp_to)

    def test_iter_missing_with_two_timestamps_ok(self):
        existing_one = self.timestamps[1]
        existing_two = self.timestamps[3]
        values = [
            value
            for value in iter_missing(
                self.timestamp_from, self.timestamp_to, [existing_one, existing_two]
            )
        ]
        self.assertEqual(len(values), 3)
        self.assertEqual(values[0][0], self.timestamp_from)
        self.assertEqual(values[0][1], existing_one)
        self.assertEqual(values[1][0], existing_one + self.one_minute)
        self.assertEqual(values[1][1], existing_two)
        self.assertEqual(values[-1][0], existing_two + self.one_minute)
        self.assertEqual(values[-1][1], self.timestamp_to)

    def test_iter_missing_with_tail(self):
        existing = self.timestamps[-1]
        values = [
            value
            for value in iter_missing(
                self.timestamp_from, self.timestamp_to, [existing]
            )
        ]
        self.assertEqual(len(values), 1)
        self.assertEqual(values[0][0], self.timestamp_from)
        self.assertEqual(values[0][1], self.timestamp_to)

    def test_iter_missing_with_custom_timestamps_and_interval(self):
        timestamp_from = datetime(2026, 4, 25, tzinfo=UTC)
        timestamp_to = datetime(2026, 4, 25, 4, tzinfo=UTC)
        timestamps = [
            timestamp_from,
            timestamp_from + pd.Timedelta("1h"),
            timestamp_from + pd.Timedelta("2h"),
        ]

        values = iter_missing(
            timestamp_from,
            timestamp_to,
            [timestamps[0], timestamps[2]],
            reverse=True,
            value=pd.Timedelta("1h"),
            timestamps=timestamps,
        )

        self.assertEqual(values, [(timestamps[1], timestamps[2])])
