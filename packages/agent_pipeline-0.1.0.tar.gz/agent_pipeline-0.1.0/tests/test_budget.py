"""Tests for the BudgetTracker."""

import pytest

from agent_pipeline.budget import BudgetTracker
from agent_pipeline.exceptions import BudgetExceededError


def test_budget_tracker_initial_spend_is_zero():
    bt = BudgetTracker(daily_usd=10.0)
    assert bt.current_spend() == 0.0


def test_budget_tracker_records_spend():
    bt = BudgetTracker(daily_usd=10.0)
    bt.record(0.5)
    bt.record(1.0)
    assert abs(bt.current_spend() - 1.5) < 1e-9


def test_budget_tracker_raises_when_exceeded():
    bt = BudgetTracker(daily_usd=1.0)
    bt.record(0.8)
    with pytest.raises(BudgetExceededError):
        bt.record(0.5)


def test_budget_tracker_check_raises_when_at_limit():
    bt = BudgetTracker(daily_usd=1.0)
    bt.record(1.0)
    with pytest.raises(BudgetExceededError):
        bt.check()


def test_budget_tracker_check_passes_under_limit():
    bt = BudgetTracker(daily_usd=5.0)
    bt.record(1.0)
    bt.check()  # should not raise


def test_budget_tracker_invalid_daily_usd():
    with pytest.raises(ValueError):
        BudgetTracker(daily_usd=0.0)
    with pytest.raises(ValueError):
        BudgetTracker(daily_usd=-1.0)


def test_budget_as_step_func_no_cost_in_ctx():
    bt = BudgetTracker(daily_usd=5.0)
    step_fn = bt.as_step_func()
    ctx = {"task": "t"}
    result = step_fn(ctx)
    assert "budget_remaining_usd" in result
    assert result["budget_remaining_usd"] == 5.0


def test_budget_as_step_func_deducts_cost():
    bt = BudgetTracker(daily_usd=5.0)
    step_fn = bt.as_step_func()
    ctx = {"task": "t", "cost_usd": 0.25}
    result = step_fn(ctx)
    assert abs(result["budget_remaining_usd"] - 4.75) < 1e-9
