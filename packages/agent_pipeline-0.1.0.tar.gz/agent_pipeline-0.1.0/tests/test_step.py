"""Tests for the Step class."""

import pytest

from agent_pipeline import Step


# ---------------------------------------------------------------------------
# Happy-path tests
# ---------------------------------------------------------------------------


def test_step_name():
    step = Step("my-step", lambda ctx: ctx)
    assert step.name == "my-step"


def test_step_execute_returns_updated_context():
    def add_x(ctx):
        ctx["x"] = 42
        return ctx

    step = Step("add-x", add_x)
    result = step.execute({"task": "hello"})
    assert result["x"] == 42
    assert result["task"] == "hello"


def test_step_execute_with_none_return_keeps_context():
    """If the step func returns None the original context is forwarded."""
    original = {"task": "t", "value": 1}

    def noop(ctx):
        return None

    step = Step("noop", noop)
    result = step.execute(original)
    assert result["task"] == "t"
    assert result["value"] == 1


def test_step_execute_does_not_mutate_caller_dict():
    """Step should work on a copy so the caller's dict is unaffected."""
    caller_ctx = {"task": "t"}

    def mutator(ctx):
        ctx["injected"] = True
        return ctx

    step = Step("mutator", mutator)
    step.execute(caller_ctx)
    # caller's dict should NOT have been mutated
    assert "injected" not in caller_ctx


def test_step_repr():
    step = Step("router", lambda c: c)
    assert "router" in repr(step)


# ---------------------------------------------------------------------------
# Error / validation tests
# ---------------------------------------------------------------------------


def test_step_requires_non_empty_name():
    with pytest.raises(ValueError):
        Step("", lambda c: c)


def test_step_requires_callable():
    with pytest.raises(TypeError):
        Step("bad", "not-a-function")  # type: ignore[arg-type]


def test_step_raises_if_func_returns_non_dict():
    step = Step("bad-return", lambda ctx: "oops")  # type: ignore[return-value]
    with pytest.raises(TypeError, match="must return a dict or None"):
        step.execute({"task": "t"})
