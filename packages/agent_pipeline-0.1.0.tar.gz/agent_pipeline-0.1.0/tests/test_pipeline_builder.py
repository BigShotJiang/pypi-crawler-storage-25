"""Tests for the Pipeline fluent builder."""

import pytest

from agent_pipeline import Pipeline
from agent_pipeline.runner import PipelineRunner


def identity(ctx):
    return ctx


# ---------------------------------------------------------------------------
# Builder happy-path
# ---------------------------------------------------------------------------


def test_pipeline_name():
    p = Pipeline("my-pipe")
    assert p.name == "my-pipe"


def test_pipeline_build_returns_runner():
    runner = Pipeline("p").build()
    assert isinstance(runner, PipelineRunner)


def test_pipeline_with_router_adds_step():
    p = Pipeline("p").with_router(identity)
    assert any(s.name == "router" for s in p._steps)


def test_pipeline_with_budget_adds_step():
    p = Pipeline("p").with_budget(daily_usd=1.0)
    assert any(s.name == "budget" for s in p._steps)


def test_pipeline_with_guard_adds_step():
    p = Pipeline("p").with_guard(identity)
    assert any(s.name.startswith("guard") for s in p._steps)


def test_pipeline_multiple_guards_unique_names():
    p = Pipeline("p").with_guard(identity).with_guard(identity)
    guard_names = [s.name for s in p._steps if s.name.startswith("guard")]
    assert len(guard_names) == 2
    assert len(set(guard_names)) == 2, "guard step names must be unique"


def test_pipeline_with_memory_callable():
    def mem_fn(ctx):
        ctx["memory_context"] = ["prev answer"]
        return ctx

    p = Pipeline("p").with_memory(mem_fn)
    assert any(s.name == "memory" for s in p._steps)


def test_pipeline_with_memory_object():
    class FakeStore:
        def retrieve(self, task):
            return [f"memory for {task}"]

    p = Pipeline("p").with_memory(FakeStore())
    assert any(s.name == "memory" for s in p._steps)


def test_pipeline_with_observer_registers():
    observations = []
    p = Pipeline("p").with_observer(lambda ctx: observations.append(ctx))
    runner = p.build()
    runner.run("test task")
    # observer should have been called (even with no steps it fires 0 times)
    # Just check the attribute is set
    assert runner._observers  # noqa: SLF001


def test_pipeline_with_retry_sets_attempts():
    p = Pipeline("p").with_retry(max_attempts=5)
    assert p._max_retry_attempts == 5


def test_pipeline_fluent_chaining_returns_same_pipeline():
    p = Pipeline("p")
    result = p.with_router(identity).with_retry(2)
    assert result is p


def test_pipeline_repr_contains_name():
    p = Pipeline("my-pipe")
    assert "my-pipe" in repr(p)


# ---------------------------------------------------------------------------
# Validation errors
# ---------------------------------------------------------------------------


def test_pipeline_empty_name_raises():
    with pytest.raises(ValueError):
        Pipeline("")


def test_pipeline_retry_zero_raises():
    with pytest.raises(ValueError):
        Pipeline("p").with_retry(max_attempts=0)
