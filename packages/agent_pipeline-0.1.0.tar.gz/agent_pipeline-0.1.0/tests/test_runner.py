"""Tests for PipelineRunner — run, run_batch, get_stats, retry, observers."""

import pytest

from agent_pipeline import Pipeline, PipelineResult
from agent_pipeline.exceptions import (
    BudgetExceededError,
    GuardRejectedError,
    MaxRetriesExceededError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_output_step(value):
    """Return a step func that sets context['output'] = value."""
    def step(ctx):
        ctx["output"] = value
        return ctx
    return step


# ---------------------------------------------------------------------------
# Basic run
# ---------------------------------------------------------------------------


def test_run_returns_pipeline_result():
    runner = Pipeline("p").build()
    result = runner.run("hello")
    assert isinstance(result, PipelineResult)


def test_run_success_flag():
    runner = Pipeline("p").with_router(make_output_step("ok")).build()
    result = runner.run("hello")
    assert result.success is True
    assert result.output == "ok"
    assert result.error is None


def test_run_records_steps_executed():
    runner = Pipeline("p").with_router(lambda c: c).with_guard(lambda c: c).build()
    result = runner.run("task")
    assert "router" in result.steps_executed
    assert "guard_0" in result.steps_executed


def test_run_duration_positive():
    runner = Pipeline("p").build()
    result = runner.run("task")
    assert result.duration_ms >= 0.0


def test_run_passes_task_in_context():
    captured = {}

    def capture(ctx):
        captured.update(ctx)
        return ctx

    Pipeline("p").with_router(capture).build().run("my-task")
    assert captured["task"] == "my-task"


def test_run_initial_context_forwarded():
    runner = Pipeline("p").with_router(lambda c: c).build()
    result = runner.run("t", context={"extra": 99})
    # extra key should be available (accessible via steps_executed / metadata not directly)
    # We just verify no crash and success
    assert result.success


def test_run_empty_pipeline_succeeds():
    runner = Pipeline("p").build()
    result = runner.run("task")
    assert result.success is True
    assert result.steps_executed == []


# ---------------------------------------------------------------------------
# run_batch
# ---------------------------------------------------------------------------


def test_run_batch_returns_list():
    runner = Pipeline("p").build()
    results = runner.run_batch(["a", "b", "c"])
    assert len(results) == 3
    assert all(isinstance(r, PipelineResult) for r in results)


def test_run_batch_order_preserved():
    outputs = []

    def capture(ctx):
        outputs.append(ctx["task"])
        return ctx

    Pipeline("p").with_router(capture).build().run_batch(["x", "y", "z"])
    assert outputs == ["x", "y", "z"]


def test_run_batch_empty_list():
    runner = Pipeline("p").build()
    assert runner.run_batch([]) == []


# ---------------------------------------------------------------------------
# get_stats
# ---------------------------------------------------------------------------


def test_get_stats_initial():
    runner = Pipeline("p").build()
    stats = runner.get_stats()
    assert stats["total_runs"] == 0
    assert stats["success_rate"] == 0.0
    assert stats["avg_duration_ms"] == 0.0
    assert stats["total_cost_usd"] == 0.0


def test_get_stats_after_runs():
    runner = Pipeline("p").build()
    runner.run("t1")
    runner.run("t2")
    stats = runner.get_stats()
    assert stats["total_runs"] == 2
    assert stats["success_rate"] == 1.0


def test_get_stats_counts_failures():
    def boom(ctx):
        raise RuntimeError("oops")

    runner = Pipeline("p").with_router(boom).build()
    runner.run("t")  # will fail after retry
    stats = runner.get_stats()
    assert stats["total_runs"] == 1
    assert stats["success_rate"] == 0.0


# ---------------------------------------------------------------------------
# Retry behaviour
# ---------------------------------------------------------------------------


def test_retry_eventually_succeeds():
    call_count = [0]

    def flaky(ctx):
        call_count[0] += 1
        if call_count[0] < 3:
            raise RuntimeError("transient")
        ctx["output"] = "recovered"
        return ctx

    runner = Pipeline("p").with_router(flaky).with_retry(max_attempts=3).build()
    result = runner.run("t")
    assert result.success is True
    assert result.output == "recovered"
    assert call_count[0] == 3


def test_retry_exhausted_returns_failure():
    def always_fails(ctx):
        raise RuntimeError("permanent")

    runner = Pipeline("p").with_router(always_fails).with_retry(max_attempts=2).build()
    result = runner.run("t")
    assert result.success is False
    assert "Max retries" in result.error


# ---------------------------------------------------------------------------
# Guard rejection (non-retryable)
# ---------------------------------------------------------------------------


def test_guard_rejection_not_retried():
    call_count = [0]

    def rejecting_guard(ctx):
        call_count[0] += 1
        raise GuardRejectedError("safety", "blocked content")

    runner = Pipeline("p").with_guard(rejecting_guard).with_retry(max_attempts=3).build()
    result = runner.run("bad task")
    assert result.success is False
    assert "Guard" in result.error
    assert call_count[0] == 1  # not retried


# ---------------------------------------------------------------------------
# Budget enforcement (non-retryable)
# ---------------------------------------------------------------------------


def test_budget_exceeded_not_retried():
    call_count = [0]

    def expensive_step(ctx):
        call_count[0] += 1
        ctx["cost_usd"] = 100.0  # exceeds any reasonable daily budget
        return ctx

    runner = (
        Pipeline("p")
        .with_router(expensive_step)
        .with_budget(daily_usd=0.01)
        .with_retry(max_attempts=3)
        .build()
    )
    result = runner.run("t")
    assert result.success is False
    assert call_count[0] == 1  # not retried


# ---------------------------------------------------------------------------
# Observer
# ---------------------------------------------------------------------------


def test_observer_called_after_each_step():
    events = []
    runner = (
        Pipeline("p")
        .with_router(lambda c: c)
        .with_observer(lambda ctx: events.append(ctx.get("task")))
        .build()
    )
    runner.run("observed-task")
    assert "observed-task" in events


def test_observer_crash_does_not_kill_pipeline():
    def bad_observer(ctx):
        raise RuntimeError("observer crash")

    runner = Pipeline("p").with_router(lambda c: c).with_observer(bad_observer).build()
    result = runner.run("t")
    assert result.success is True  # pipeline must survive observer crash
