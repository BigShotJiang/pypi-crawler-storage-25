"""Tests for custom exception types."""

import pytest

from agent_pipeline.exceptions import (
    BudgetExceededError,
    GuardRejectedError,
    MaxRetriesExceededError,
    PipelineError,
)


def test_budget_exceeded_error_is_pipeline_error():
    exc = BudgetExceededError(5.0, 5.01)
    assert isinstance(exc, PipelineError)
    assert exc.daily_limit == 5.0
    assert exc.current_spend == 5.01
    assert "5.0" in str(exc)


def test_guard_rejected_error_with_reason():
    exc = GuardRejectedError("safety-guard", "contains PII")
    assert isinstance(exc, PipelineError)
    assert exc.guard_name == "safety-guard"
    assert "contains PII" in str(exc)


def test_guard_rejected_error_without_reason():
    exc = GuardRejectedError("guard")
    assert "guard" in str(exc)
    assert exc.reason == ""


def test_max_retries_exceeded_wraps_last_error():
    original = ValueError("root cause")
    exc = MaxRetriesExceededError(3, original)
    assert isinstance(exc, PipelineError)
    assert exc.max_attempts == 3
    assert exc.last_error is original
    assert "3" in str(exc)
    assert "root cause" in str(exc)
