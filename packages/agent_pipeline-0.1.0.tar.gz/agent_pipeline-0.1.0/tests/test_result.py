"""Tests for the PipelineResult dataclass."""

import pytest

from agent_pipeline import PipelineResult


def test_result_ok_fields():
    r = PipelineResult.ok(
        output="hello",
        duration_ms=12.5,
        steps_executed=["router", "guard_0"],
        metadata={"model": "gpt-4"},
    )
    assert r.success is True
    assert r.output == "hello"
    assert r.error is None
    assert r.duration_ms == 12.5
    assert r.steps_executed == ["router", "guard_0"]
    assert r.metadata["model"] == "gpt-4"


def test_result_fail_fields():
    r = PipelineResult.fail(
        error="something went wrong",
        duration_ms=5.0,
        steps_executed=["router"],
    )
    assert r.success is False
    assert r.error == "something went wrong"
    assert r.output is None
    assert r.duration_ms == 5.0
    assert r.steps_executed == ["router"]


def test_result_to_dict_ok():
    r = PipelineResult.ok(output=42, duration_ms=1.0)
    d = r.to_dict()
    assert d["success"] is True
    assert d["output"] == 42
    assert d["error"] is None
    assert isinstance(d["steps_executed"], list)
    assert isinstance(d["metadata"], dict)


def test_result_to_dict_fail():
    r = PipelineResult.fail(error="boom", duration_ms=2.0)
    d = r.to_dict()
    assert d["success"] is False
    assert d["error"] == "boom"


def test_result_to_dict_is_json_serialisable():
    import json

    r = PipelineResult.ok(output="text", duration_ms=3.3, steps_executed=["a", "b"])
    json.dumps(r.to_dict())  # must not raise


def test_result_is_immutable():
    r = PipelineResult.ok(output=1, duration_ms=1.0)
    with pytest.raises((AttributeError, TypeError)):
        r.success = False  # type: ignore[misc]


def test_result_repr_contains_status():
    ok = PipelineResult.ok(output=None, duration_ms=1.0)
    assert "OK" in repr(ok)

    fail = PipelineResult.fail(error="x", duration_ms=1.0)
    assert "FAIL" in repr(fail)


def test_result_defaults_empty_steps_and_metadata():
    r = PipelineResult.ok(output=None, duration_ms=0.0)
    assert r.steps_executed == []
    assert r.metadata == {}
