"""
agent-pipeline — unified pipeline orchestrator for agent execution.

Provides a fluent builder API to compose agent execution pipelines
from independent components (routing, budgeting, guards, memory,
observability, retry, etc.)
"""

from .pipeline import Pipeline
from .runner import PipelineRunner
from .result import PipelineResult
from .step import Step
from .exceptions import (
    PipelineError,
    BudgetExceededError,
    GuardRejectedError,
    MaxRetriesExceededError,
)

__all__ = [
    "Pipeline",
    "PipelineRunner",
    "PipelineResult",
    "Step",
    "PipelineError",
    "BudgetExceededError",
    "GuardRejectedError",
    "MaxRetriesExceededError",
]

__version__ = "0.1.0"
