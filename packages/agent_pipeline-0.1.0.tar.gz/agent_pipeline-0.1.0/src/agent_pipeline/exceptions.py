"""Custom exceptions for agent-pipeline."""


class PipelineError(Exception):
    """Base exception for all pipeline errors."""


class BudgetExceededError(PipelineError):
    """Raised when daily USD budget is exceeded."""

    def __init__(self, daily_limit: float, current_spend: float) -> None:
        self.daily_limit = daily_limit
        self.current_spend = current_spend
        super().__init__(
            f"Daily budget exceeded: spent ${current_spend:.4f} / limit ${daily_limit:.4f}"
        )


class GuardRejectedError(PipelineError):
    """Raised when a guard function rejects the task."""

    def __init__(self, guard_name: str, reason: str = "") -> None:
        self.guard_name = guard_name
        self.reason = reason
        msg = f"Guard '{guard_name}' rejected task"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class MaxRetriesExceededError(PipelineError):
    """Raised when maximum retry attempts are exhausted."""

    def __init__(self, max_attempts: int, last_error: Exception) -> None:
        self.max_attempts = max_attempts
        self.last_error = last_error
        super().__init__(
            f"Max retries ({max_attempts}) exceeded. Last error: {last_error}"
        )
