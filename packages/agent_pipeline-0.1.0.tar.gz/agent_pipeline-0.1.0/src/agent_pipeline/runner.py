"""PipelineRunner — executes a built pipeline."""

from __future__ import annotations

import time
from typing import Any, Callable

from .budget import BudgetTracker
from .exceptions import BudgetExceededError, GuardRejectedError, MaxRetriesExceededError, PipelineError
from .result import PipelineResult
from .step import Step


class PipelineRunner:
    """Executes a fully-built pipeline.

    You should not instantiate this directly — use ``Pipeline(...).build()``.

    Parameters
    ----------
    name:
        Pipeline name (used in stats / logging).
    steps:
        Ordered list of ``Step`` objects to execute.
    observers:
        List of observer callables (called after each step).
    max_retry_attempts:
        How many times to attempt the full step sequence on transient errors.
    budget_tracker:
        Optional ``BudgetTracker`` attached to this pipeline (used for stats).
    """

    def __init__(
        self,
        name: str,
        steps: list[Step],
        observers: list[Callable[[dict[str, Any]], None]],
        max_retry_attempts: int,
        budget_tracker: BudgetTracker | None,
    ) -> None:
        self._name = name
        self._steps = steps
        self._observers = observers
        self._max_retry_attempts = max_retry_attempts
        self._budget_tracker = budget_tracker

        # Cumulative stats
        self._total_runs: int = 0
        self._successful_runs: int = 0
        self._total_duration_ms: float = 0.0

    # ------------------------------------------------------------------ #
    #  Public API                                                           #
    # ------------------------------------------------------------------ #

    def run(self, task: str, context: dict[str, Any] | None = None) -> PipelineResult:
        """Execute the pipeline for a single *task*.

        Parameters
        ----------
        task:
            The task string passed into the pipeline context as
            ``context["task"]``.
        context:
            Optional initial context dict.  A copy is made so the
            caller's dict is never mutated.

        Returns
        -------
        PipelineResult
        """
        ctx: dict[str, Any] = dict(context or {})
        ctx["task"] = task
        ctx.setdefault("metadata", {})

        attempt = 0
        last_exc: Exception | None = None
        start = time.perf_counter()

        while attempt < self._max_retry_attempts:
            attempt += 1
            steps_executed: list[str] = []
            run_ctx = dict(ctx)  # fresh copy for each attempt

            try:
                for step in self._steps:
                    run_ctx = step.execute(run_ctx)
                    steps_executed.append(step.name)
                    self._notify_observers(run_ctx)

                duration_ms = (time.perf_counter() - start) * 1000
                self._record_run(success=True, duration_ms=duration_ms)

                return PipelineResult.ok(
                    output=run_ctx.get("output"),
                    duration_ms=duration_ms,
                    steps_executed=steps_executed,
                    metadata=run_ctx.get("metadata", {}),
                )

            except (BudgetExceededError, GuardRejectedError) as exc:
                # Non-retryable: surface immediately
                duration_ms = (time.perf_counter() - start) * 1000
                self._record_run(success=False, duration_ms=duration_ms)
                return PipelineResult.fail(
                    error=str(exc),
                    duration_ms=duration_ms,
                    steps_executed=steps_executed,
                    metadata=run_ctx.get("metadata", {}),
                )

            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if attempt < self._max_retry_attempts:
                    continue  # retry

        # All retry attempts exhausted
        duration_ms = (time.perf_counter() - start) * 1000
        self._record_run(success=False, duration_ms=duration_ms)
        wrapped = MaxRetriesExceededError(self._max_retry_attempts, last_exc)  # type: ignore[arg-type]
        return PipelineResult.fail(
            error=str(wrapped),
            duration_ms=duration_ms,
            steps_executed=[],
            metadata=ctx.get("metadata", {}),
        )

    def run_batch(self, tasks: list[str]) -> list[PipelineResult]:
        """Run the pipeline for each task in *tasks* sequentially.

        Parameters
        ----------
        tasks:
            List of task strings.

        Returns
        -------
        list[PipelineResult]
            One result per task, in the same order.
        """
        return [self.run(task) for task in tasks]

    def get_stats(self) -> dict[str, Any]:
        """Return accumulated runtime statistics.

        Returns
        -------
        dict with keys:
            - ``total_runs``       — int
            - ``success_rate``     — float (0.0 – 1.0)
            - ``avg_duration_ms``  — float
            - ``total_cost_usd``   — float (from budget tracker, if present)
        """
        success_rate = (
            self._successful_runs / self._total_runs if self._total_runs > 0 else 0.0
        )
        avg_duration = (
            self._total_duration_ms / self._total_runs if self._total_runs > 0 else 0.0
        )
        total_cost = (
            self._budget_tracker.current_spend() if self._budget_tracker else 0.0
        )
        return {
            "total_runs": self._total_runs,
            "success_rate": success_rate,
            "avg_duration_ms": avg_duration,
            "total_cost_usd": total_cost,
        }

    # ------------------------------------------------------------------ #
    #  Private helpers                                                      #
    # ------------------------------------------------------------------ #

    def _notify_observers(self, ctx: dict[str, Any]) -> None:
        snapshot = dict(ctx)
        for obs in self._observers:
            try:
                obs(snapshot)
            except Exception:  # noqa: BLE001
                pass  # Observers must never crash the pipeline

    def _record_run(self, *, success: bool, duration_ms: float) -> None:
        self._total_runs += 1
        if success:
            self._successful_runs += 1
        self._total_duration_ms += duration_ms

    # ------------------------------------------------------------------ #
    #  Dunder helpers                                                       #
    # ------------------------------------------------------------------ #

    @property
    def name(self) -> str:
        return self._name

    def __repr__(self) -> str:
        return (
            f"PipelineRunner(name={self._name!r}, "
            f"steps={[s.name for s in self._steps]}, "
            f"retry={self._max_retry_attempts})"
        )
