"""Pipeline — fluent builder for agent execution pipelines."""

from __future__ import annotations

from typing import Any, Callable

from .budget import BudgetTracker
from .step import Step


class Pipeline:
    """Fluent builder for an agent execution pipeline.

    Usage::

        runner = (
            Pipeline("my-agent")
            .with_router(my_router)
            .with_budget(daily_usd=5.0)
            .with_guard(safety_check)
            .with_memory(my_store)
            .with_observer(log_observer)
            .with_retry(max_attempts=3)
            .build()
        )

    Parameters
    ----------
    name:
        Human-readable name for the pipeline (used in logs/stats).
    """

    def __init__(self, name: str) -> None:
        if not name or not isinstance(name, str):
            raise ValueError("Pipeline name must be a non-empty string.")
        self._name = name
        self._steps: list[Step] = []
        self._observers: list[Callable[[dict[str, Any]], None]] = []
        self._max_retry_attempts: int = 1  # 1 = no retry
        self._budget_tracker: BudgetTracker | None = None

    # ------------------------------------------------------------------ #
    #  Fluent builder methods                                               #
    # ------------------------------------------------------------------ #

    def with_router(self, router_func: Callable[[dict[str, Any]], dict[str, Any] | None]) -> "Pipeline":
        """Add a routing step.

        *router_func* receives the current context and may update it
        (e.g. set ``context["route"]``).
        """
        self._steps.append(Step("router", router_func))
        return self

    def with_budget(self, daily_usd: float) -> "Pipeline":
        """Add a budget-enforcement step.

        Raises ``BudgetExceededError`` if the daily USD limit is hit.
        """
        self._budget_tracker = BudgetTracker(daily_usd)
        self._steps.append(Step("budget", self._budget_tracker.as_step_func()))
        return self

    def with_guard(self, guard_func: Callable[[dict[str, Any]], dict[str, Any] | None]) -> "Pipeline":
        """Add a guard step.

        *guard_func* should raise ``GuardRejectedError`` (or any exception)
        to block execution, or return the (possibly mutated) context to
        allow it through.
        """
        # count existing guards to give each a unique step name
        guard_n = sum(1 for s in self._steps if s.name.startswith("guard"))
        self._steps.append(Step(f"guard_{guard_n}", guard_func))
        return self

    def with_memory(self, memory_store: Any) -> "Pipeline":
        """Add a memory-context-injection step.

        Accepts any object that implements:
        - ``retrieve(task: str) -> list[str]`` — returns relevant memories
        - ``store(task: str, output: Any) -> None`` — persists new memories

        If *memory_store* is callable it is used directly as a step function.
        """
        if callable(memory_store):
            self._steps.append(Step("memory", memory_store))
        else:
            def _memory_step(ctx: dict[str, Any]) -> dict[str, Any]:
                task = ctx.get("task", "")
                if hasattr(memory_store, "retrieve"):
                    ctx["memory_context"] = memory_store.retrieve(task)
                return ctx

            self._steps.append(Step("memory", _memory_step))
        return self

    def with_observer(self, observer_func: Callable[[dict[str, Any]], None]) -> "Pipeline":
        """Register an observability hook.

        *observer_func* is called after every step with the current
        context snapshot.  It must not mutate the context.
        """
        self._observers.append(observer_func)
        return self

    def with_retry(self, max_attempts: int = 3) -> "Pipeline":
        """Configure retry behaviour.

        The entire pipeline will be retried up to *max_attempts* times on
        any exception that is **not** a ``BudgetExceededError`` or
        ``GuardRejectedError``.
        """
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1.")
        self._max_retry_attempts = max_attempts
        return self

    def build(self) -> "PipelineRunner":  # noqa: F821
        """Finalise the pipeline and return a ``PipelineRunner``.

        Imports ``PipelineRunner`` lazily to avoid circular imports.
        """
        from .runner import PipelineRunner

        return PipelineRunner(
            name=self._name,
            steps=list(self._steps),
            observers=list(self._observers),
            max_retry_attempts=self._max_retry_attempts,
            budget_tracker=self._budget_tracker,
        )

    # ------------------------------------------------------------------ #
    #  Properties                                                           #
    # ------------------------------------------------------------------ #

    @property
    def name(self) -> str:
        return self._name

    def __repr__(self) -> str:
        return (
            f"Pipeline(name={self._name!r}, steps={[s.name for s in self._steps]}, "
            f"retry={self._max_retry_attempts})"
        )
