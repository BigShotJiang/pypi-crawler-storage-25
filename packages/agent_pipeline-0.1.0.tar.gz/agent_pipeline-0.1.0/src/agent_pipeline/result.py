"""PipelineResult — immutable result of a single pipeline run."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class PipelineResult:
    """Result of a single pipeline execution.

    Attributes:
        success:         Whether the pipeline completed without errors.
        output:          Final output produced by the pipeline.
        error:           Human-readable error message, or None on success.
        duration_ms:     Wall-clock duration in milliseconds.
        steps_executed:  Names of steps that were executed (in order).
        metadata:        Arbitrary key-value metadata accumulated during the run.
    """

    success: bool
    output: Any
    error: str | None
    duration_ms: float
    steps_executed: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------ #
    #  Serialisation                                                        #
    # ------------------------------------------------------------------ #

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable representation of this result."""
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "steps_executed": list(self.steps_executed),
            "metadata": dict(self.metadata),
        }

    # ------------------------------------------------------------------ #
    #  Convenience constructors                                             #
    # ------------------------------------------------------------------ #

    @classmethod
    def ok(
        cls,
        output: Any,
        *,
        duration_ms: float,
        steps_executed: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "PipelineResult":
        return cls(
            success=True,
            output=output,
            error=None,
            duration_ms=duration_ms,
            steps_executed=steps_executed or [],
            metadata=metadata or {},
        )

    @classmethod
    def fail(
        cls,
        error: str,
        *,
        duration_ms: float,
        output: Any = None,
        steps_executed: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "PipelineResult":
        return cls(
            success=False,
            output=output,
            error=error,
            duration_ms=duration_ms,
            steps_executed=steps_executed or [],
            metadata=metadata or {},
        )

    def __repr__(self) -> str:
        status = "OK" if self.success else "FAIL"
        return (
            f"PipelineResult({status}, duration={self.duration_ms:.1f}ms, "
            f"steps={self.steps_executed})"
        )
