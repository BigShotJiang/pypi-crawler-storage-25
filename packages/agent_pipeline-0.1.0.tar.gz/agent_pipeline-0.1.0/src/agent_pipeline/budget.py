"""Budget tracking for agent-pipeline.

Tracks cumulative USD spend within a rolling 24-hour window and raises
``BudgetExceededError`` when the configured daily limit is breached.
"""

from __future__ import annotations

import threading
import time
from typing import Any

from .exceptions import BudgetExceededError


class BudgetTracker:
    """Thread-safe daily-USD budget tracker.

    Parameters
    ----------
    daily_usd:
        Maximum USD that may be spent in any rolling 24-hour window.
    """

    _WINDOW_SECONDS: float = 86_400.0  # 24 hours

    def __init__(self, daily_usd: float) -> None:
        if daily_usd <= 0:
            raise ValueError(f"daily_usd must be positive; got {daily_usd}")
        self.daily_usd = daily_usd
        self._lock = threading.Lock()
        # list of (timestamp, cost_usd) tuples
        self._ledger: list[tuple[float, float]] = []

    # ------------------------------------------------------------------ #
    #  Public helpers                                                       #
    # ------------------------------------------------------------------ #

    def current_spend(self) -> float:
        """Return the total spend within the current 24-hour window."""
        cutoff = time.time() - self._WINDOW_SECONDS
        with self._lock:
            self._prune(cutoff)
            return sum(c for _, c in self._ledger)

    def record(self, cost_usd: float) -> None:
        """Record *cost_usd* and raise if budget is now exceeded."""
        cutoff = time.time() - self._WINDOW_SECONDS
        with self._lock:
            self._prune(cutoff)
            projected = sum(c for _, c in self._ledger) + cost_usd
            if projected > self.daily_usd:
                raise BudgetExceededError(self.daily_usd, projected)
            self._ledger.append((time.time(), cost_usd))

    def check(self) -> None:
        """Raise ``BudgetExceededError`` if the budget is already exceeded."""
        spend = self.current_spend()
        if spend >= self.daily_usd:
            raise BudgetExceededError(self.daily_usd, spend)

    def as_step_func(self) -> Any:
        """Return a step-compatible callable that performs a budget check."""

        def _step(ctx: dict[str, Any]) -> dict[str, Any]:
            # Deduct cost_usd from context if present; otherwise just check.
            cost = ctx.get("cost_usd", 0.0)
            if cost:
                self.record(cost)
            else:
                self.check()
            ctx["budget_remaining_usd"] = self.daily_usd - self.current_spend()
            return ctx

        return _step

    # ------------------------------------------------------------------ #
    #  Private helpers                                                      #
    # ------------------------------------------------------------------ #

    def _prune(self, cutoff: float) -> None:
        self._ledger = [(ts, c) for ts, c in self._ledger if ts >= cutoff]
