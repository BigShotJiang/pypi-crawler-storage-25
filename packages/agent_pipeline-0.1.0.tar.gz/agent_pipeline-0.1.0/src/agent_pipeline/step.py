"""Step — base class for all pipeline steps."""

from __future__ import annotations

from typing import Any, Callable


class Step:
    """A single named, executable unit in a pipeline.

    Parameters
    ----------
    name:
        Human-readable identifier for this step (used in ``steps_executed``).
    func:
        Callable that receives the current execution context (dict) and
        returns an updated context (dict).  The callable may also return
        ``None``, in which case the original context is passed forward
        unchanged.
    """

    def __init__(self, name: str, func: Callable[[dict[str, Any]], dict[str, Any] | None]) -> None:
        if not name or not isinstance(name, str):
            raise ValueError("Step name must be a non-empty string.")
        if not callable(func):
            raise TypeError(f"Step '{name}': func must be callable.")
        self._name = name
        self._func = func

    # ------------------------------------------------------------------ #
    #  Public interface                                                     #
    # ------------------------------------------------------------------ #

    @property
    def name(self) -> str:
        """The human-readable name of this step."""
        return self._name

    def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """Run *func* on *context* and return the updated context.

        If *func* returns ``None``, the original context is returned
        unchanged.  The context dict is shallow-copied before being
        passed to *func* to prevent accidental mutations of the
        caller's object.
        """
        ctx = dict(context)
        result = self._func(ctx)
        if result is None:
            return ctx
        if not isinstance(result, dict):
            raise TypeError(
                f"Step '{self._name}' must return a dict or None; got {type(result).__name__}."
            )
        return result

    # ------------------------------------------------------------------ #
    #  Dunder helpers                                                       #
    # ------------------------------------------------------------------ #

    def __repr__(self) -> str:
        return f"Step(name={self._name!r})"
