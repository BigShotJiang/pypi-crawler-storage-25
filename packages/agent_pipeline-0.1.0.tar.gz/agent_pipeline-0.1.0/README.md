<div align="center">

<img src="assets/yajna-hero.png" alt="यज्ञ — yajna by Darshankumar Joshi" width="100%" />

# ⚡ यज्ञ
## `yajna`

> *Rigveda / Bhagavad Gita 3.9*

### Sacred Ritual — the fire of transformation

**Composable pipeline builder for LLM agent workflows. Chain, branch, merge, retry stages. Zero dependencies.**

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue?style=flat-square&logo=python)](https://python.org)
[![Zero Dependencies](https://img.shields.io/badge/Dependencies-Zero-brightgreen?style=flat-square)](https://github.com/darshjme/yajna)
[![Vedic Arsenal](https://img.shields.io/badge/Vedic%20Arsenal-100%20libs-yellow?style=flat-square)](https://github.com/darshjme/arsenal)
[![License](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)](LICENSE)

*Formerly `agent-pipeline` — Part of the [**Vedic Arsenal**](https://github.com/darshjme/arsenal): 100 production-grade Python libraries for LLM agents, each named from the Vedas, Puranas, and Mahakavyas.*

</div>

---

## The Vedic Principle

The Rigveda describes *Yajna* as the sacred fire ritual that connects the human to the divine — each offering transforms, each stage purifies, the output more refined than the input.

`yajna` is the LLM pipeline as sacred transformation. Raw data enters the fire. Each stage — validate, transform, call, parse, output — is an offering. The pipeline is not a machine. It is a ritual. Each step has its dharma, its place, its function.

*"Yajna is born from action"* says the Gita (3.14). The pipeline is born from the sequence of intentional acts. Run it with awareness and every token becomes an offering to intelligence itself.

---

## How It Works

```mermaid
flowchart LR
    A[Input] --> B[Stage 1: Validate]
    B --> C[Stage 2: Transform]
    C --> D[Stage 3: LLM Call]
    D --> E[Stage 4: Parse]
    E --> F[Output]
    B -- Error --> G[Retry]
    style D fill:#10b981,color:#fff
```

---

## Installation

```bash
pip install yajna
```

Or from source:
```bash
git clone https://github.com/darshjme/yajna.git
cd yajna && pip install -e .
```

## Quick Start

```python
from yajna import *

# See examples/ for full usage
```

---

## The Vedic Arsenal

`yajna` is one of 100 libraries in **[darshjme/arsenal](https://github.com/darshjme/arsenal)** — each named from sacred Indian literature:

| Sanskrit Name | Source | Technical Function |
|---|---|---|
| `yajna` | Rigveda / Bhagavad Gita 3.9 | Sacred Ritual — the fire of transformation |

Each library solves one problem. Zero external dependencies. Pure Python 3.8+.

---

## Contributing

1. Fork the repo
2. Create feature branch (`git checkout -b fix/your-fix`)  
3. Add tests — zero dependencies only
4. Open a PR

---

<div align="center">

**⚡ Built by [Darshankumar Joshi](https://github.com/darshjme)** · [@thedarshanjoshi](https://twitter.com/thedarshanjoshi)

*"कर्मण्येवाधिकारस्ते मा फलेषु कदाचन"*
*Your right is to action alone, never to its fruits. — Bhagavad Gita 2.47*

[Vedic Arsenal](https://github.com/darshjme/arsenal) · [GitHub](https://github.com/darshjme) · [Twitter](https://twitter.com/thedarshanjoshi)

</div>
