# napari-spam

[![License GNU GPL v3.0](https://img.shields.io/pypi/l/napari-spam.svg?color=green)](https://github.com/jules-vanaret/napari-spam/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/napari-spam.svg?color=green)](https://pypi.org/project/napari-spam)
[![Python Version](https://img.shields.io/pypi/pyversions/napari-spam.svg?color=green)](https://python.org)
[![napari hub](https://img.shields.io/endpoint?url=https://api.napari-hub.org/shields/napari-spam)](https://napari-hub.org/plugins/napari-spam)
[![npe2](https://img.shields.io/badge/plugin-npe2-blue?link=https://napari.org/stable/plugins/index.html)](https://napari.org/stable/plugins/index.html)

A simple plugin to load results from Spam in Napari

----------------------------------

## Installation

The plugin obviously requires [napari] to run. If you don't have it yet, follow the instructions [here](https://napari.org/stable/tutorials/fundamentals/installation.html).

The simplest way to install `napari-spam` is via the [napari] plugin manager. Open Napari, go to `Plugins > Install/Uninstall Packages...` and search for `napari-spam`. Click on the install button and you are ready to go!

You can install `napari-spam` via [pip]:

```bash
pip install napari-spam
```

If napari is not already installed, you can install `napari-spam` with napari and Qt via:

```bash
pip install "napari-spam[all]"
```



## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [GNU GPL v3.0] license,
"napari-spam" is free and open source software.

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
