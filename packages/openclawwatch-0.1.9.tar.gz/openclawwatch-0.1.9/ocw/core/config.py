from __future__ import annotations
import sys
from dataclasses import dataclass, field, fields
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[no-redef]

import tomli_w


# -- Nested config dataclasses --

@dataclass
class SensitiveAction:
    name:     str
    severity: str = "warning"   # critical | warning | info


@dataclass
class BudgetConfig:
    daily_usd:   float | None = None
    session_usd: float | None = None


@dataclass
class DriftConfig:
    enabled:            bool  = True
    baseline_sessions:  int   = 10
    token_threshold:    float = 2.0
    tool_sequence_diff: float = 0.4


@dataclass
class AgentConfig:
    description:      str                  = ""
    budget:           BudgetConfig         = field(default_factory=BudgetConfig)
    sensitive_actions: list[SensitiveAction] = field(default_factory=list)
    output_schema:    str | None           = None
    drift:            DriftConfig          = field(default_factory=DriftConfig)


@dataclass
class DefaultsConfig:
    budget: BudgetConfig = field(default_factory=BudgetConfig)


@dataclass
class StorageConfig:
    path:           str = "~/.ocw/telemetry.duckdb"
    retention_days: int = 90


@dataclass
class OtlpConfig:
    enabled:  bool        = False
    endpoint: str         = "http://localhost:4318"
    protocol: str         = "http"   # http | grpc
    headers:  dict        = field(default_factory=dict)
    insecure: bool        = True


@dataclass
class PrometheusConfig:
    enabled: bool = True
    port:    int  = 9464
    path:    str  = "/metrics"


@dataclass
class ExportConfig:
    otlp:       OtlpConfig       = field(default_factory=OtlpConfig)
    prometheus: PrometheusConfig = field(default_factory=PrometheusConfig)


@dataclass
class AlertChannelConfig:
    type: str
    # stdout / file
    path: str | None = None
    # ntfy
    topic:        str | None = None
    server:       str        = "https://ntfy.sh"
    token:        str        = ""
    # webhook
    url:     str | None = None
    method:  str        = "POST"
    headers: dict       = field(default_factory=dict)
    # discord
    webhook_url: str | None = None
    # telegram
    bot_token: str | None = None
    chat_id:   str | None = None
    # shared
    min_severity: str = "info"


@dataclass
class AlertsConfig:
    cooldown_seconds:        int  = 60
    include_captured_content: bool = False
    channels: list[AlertChannelConfig] = field(default_factory=lambda: [
        AlertChannelConfig(type="stdout"),
    ])


@dataclass
class SecurityConfig:
    ingest_secret:          str = ""
    max_attribute_bytes:    int = 65536
    max_attributes_per_span: int = 256
    max_attribute_depth:    int = 10
    webhook_allowed_domains: list[str] = field(default_factory=list)


@dataclass
class ApiAuthConfig:
    enabled: bool = False
    api_key: str  = ""


@dataclass
class ApiConfig:
    enabled: bool         = True
    host:    str          = "127.0.0.1"
    port:    int          = 7391
    auth:    ApiAuthConfig = field(default_factory=ApiAuthConfig)


@dataclass
class CaptureConfig:
    prompts:      bool = False
    completions:  bool = False
    tool_inputs:  bool = False
    tool_outputs: bool = False


@dataclass
class OcwConfig:
    version:  str
    defaults: DefaultsConfig          = field(default_factory=DefaultsConfig)
    agents:   dict[str, AgentConfig]  = field(default_factory=dict)
    storage:  StorageConfig           = field(default_factory=StorageConfig)
    export:   ExportConfig            = field(default_factory=ExportConfig)
    alerts:   AlertsConfig            = field(default_factory=AlertsConfig)
    security: SecurityConfig          = field(default_factory=SecurityConfig)
    api:      ApiConfig               = field(default_factory=ApiConfig)
    capture:  CaptureConfig           = field(default_factory=CaptureConfig)
    # Path to the config file on disk; set by load_config() so that relative
    # paths in the config (e.g. output_schema) can be resolved correctly.
    config_path: Path | None          = field(default=None, repr=False, compare=False)


# -- File discovery --

SEARCH_PATHS = [
    Path("ocw.toml"),
    Path(".ocw/config.toml"),
    Path.home() / ".config" / "ocw" / "config.toml",
]


def find_config_file(override: str | None = None) -> Path | None:
    if override:
        p = Path(override)
        if p.exists():
            return p
        raise FileNotFoundError(f"Config file not found: {override}")
    for path in SEARCH_PATHS:
        if path.exists():
            return path
    return None


def load_config(path: str | None = None) -> OcwConfig:
    """
    Load config from file, merge with defaults, return OcwConfig.

    IMPORTANT: tomllib requires binary mode "rb" -- not text mode "r".
    Using "r" raises TypeError at runtime.
    """
    config_path = find_config_file(path)
    if config_path is None:
        return OcwConfig(version="1")

    with open(config_path, "rb") as f:   # "rb" is REQUIRED
        raw = tomllib.load(f)

    cfg = _parse(raw)
    cfg.config_path = config_path.resolve()
    return cfg


def write_config(config: OcwConfig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        tomli_w.dump(_serialise(config), f)


def _parse(raw: dict) -> OcwConfig:
    """Convert raw TOML dict to OcwConfig, applying defaults for missing keys."""
    agents = {}
    for agent_id, agent_raw in raw.get("agents", {}).items():
        budget = BudgetConfig(**agent_raw.get("budget", {}))
        sensitive_actions = [
            SensitiveAction(**sa) for sa in agent_raw.get("sensitive_actions", [])
        ]
        drift = DriftConfig(**agent_raw.get("drift", {}))
        agents[agent_id] = AgentConfig(
            description=agent_raw.get("description", ""),
            budget=budget,
            sensitive_actions=sensitive_actions,
            output_schema=agent_raw.get("output_schema"),
            drift=drift,
        )

    storage_raw = raw.get("storage", {})
    storage = StorageConfig(
        path=storage_raw.get("path", StorageConfig.path),
        retention_days=storage_raw.get("retention_days", StorageConfig.retention_days),
    )

    export_raw = raw.get("export", {})
    otlp_raw = export_raw.get("otlp", {})
    otlp = OtlpConfig(
        enabled=otlp_raw.get("enabled", False),
        endpoint=otlp_raw.get("endpoint", OtlpConfig.endpoint),
        protocol=otlp_raw.get("protocol", OtlpConfig.protocol),
        headers=otlp_raw.get("headers", {}),
        insecure=otlp_raw.get("insecure", True),
    )
    prom_raw = export_raw.get("prometheus", {})
    prometheus = PrometheusConfig(
        enabled=prom_raw.get("enabled", True),
        port=prom_raw.get("port", PrometheusConfig.port),
        path=prom_raw.get("path", PrometheusConfig.path),
    )
    export = ExportConfig(otlp=otlp, prometheus=prometheus)

    alerts_raw = raw.get("alerts", {})
    channels = []
    for ch_raw in alerts_raw.get("channels", []):
        channels.append(AlertChannelConfig(**ch_raw))
    alerts = AlertsConfig(
        cooldown_seconds=alerts_raw.get("cooldown_seconds", AlertsConfig.cooldown_seconds),
        include_captured_content=alerts_raw.get("include_captured_content", False),
        channels=channels if channels else [AlertChannelConfig(type="stdout")],
    )

    security_raw = raw.get("security", {})
    security = SecurityConfig(
        ingest_secret=security_raw.get("ingest_secret", ""),
        max_attribute_bytes=security_raw.get("max_attribute_bytes", 65536),
        max_attributes_per_span=security_raw.get("max_attributes_per_span", 256),
        max_attribute_depth=security_raw.get("max_attribute_depth", 10),
        webhook_allowed_domains=security_raw.get("webhook_allowed_domains", []),
    )

    api_raw = raw.get("api", {})
    api_auth_raw = api_raw.get("auth", {})
    api_auth = ApiAuthConfig(
        enabled=api_auth_raw.get("enabled", False),
        api_key=api_auth_raw.get("api_key", ""),
    )
    api = ApiConfig(
        enabled=api_raw.get("enabled", True),
        host=api_raw.get("host", ApiConfig.host),
        port=api_raw.get("port", ApiConfig.port),
        auth=api_auth,
    )

    capture_raw = raw.get("capture", {})
    capture = CaptureConfig(
        prompts=capture_raw.get("prompts", False),
        completions=capture_raw.get("completions", False),
        tool_inputs=capture_raw.get("tool_inputs", False),
        tool_outputs=capture_raw.get("tool_outputs", False),
    )

    defaults_raw = raw.get("defaults", {})
    defaults_budget_raw = defaults_raw.get("budget", {})
    defaults = DefaultsConfig(budget=BudgetConfig(**defaults_budget_raw))

    return OcwConfig(
        version=raw.get("version", "1"),
        defaults=defaults,
        agents=agents,
        storage=storage,
        export=export,
        alerts=alerts,
        security=security,
        api=api,
        capture=capture,
    )


def _serialise(config: OcwConfig) -> dict:
    """Convert OcwConfig back to a plain dict suitable for tomli_w."""
    def _dc_to_dict(obj: object) -> dict:
        result = {}
        for f in fields(obj):  # type: ignore[arg-type]
            val = getattr(obj, f.name)
            if isinstance(val, dict):
                result[f.name] = val
            elif isinstance(val, list):
                result[f.name] = [
                    _dc_to_dict(item) if hasattr(item, "__dataclass_fields__") else item
                    for item in val
                ]
            elif hasattr(val, "__dataclass_fields__"):
                result[f.name] = _dc_to_dict(val)
            elif val is not None and not isinstance(val, Path):
                result[f.name] = val
        return result

    d = _dc_to_dict(config)

    # agents is a dict of str -> AgentConfig, handle specially
    agents_out = {}
    for agent_id, agent_cfg in config.agents.items():
        agents_out[agent_id] = _dc_to_dict(agent_cfg)
    d["agents"] = agents_out

    return d


def resolve_effective_budget(agent_id: str, config: OcwConfig) -> BudgetConfig:
    """
    Return the effective budget for an agent, merging per-agent overrides
    with global defaults on a per-field basis.

    Each field (daily_usd, session_usd) independently uses the agent value
    if set, otherwise falls back to the defaults value.
    """
    defaults = config.defaults.budget
    agent_cfg = config.agents.get(agent_id)
    if agent_cfg is None:
        return BudgetConfig(
            daily_usd=defaults.daily_usd,
            session_usd=defaults.session_usd,
        )
    ab = agent_cfg.budget
    return BudgetConfig(
        daily_usd=ab.daily_usd if ab.daily_usd is not None else defaults.daily_usd,
        session_usd=ab.session_usd if ab.session_usd is not None else defaults.session_usd,
    )


def validate_budget_value(value: float, field_name: str) -> float | None:
    """
    Validate and normalise a budget value from user input.

    Positive values are returned as-is. Zero means 'remove limit' (returns None).
    Negative values raise ValueError.
    """
    if value < 0:
        raise ValueError(f"Budget {field_name} must be non-negative, got {value}")
    return value if value > 0 else None
