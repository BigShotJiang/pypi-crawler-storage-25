#!/usr/bin/env python3
"""Unit tests for memory_viewer module."""

from __future__ import annotations

import io
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

_SCRIPTS_DIR = str(Path(__file__).resolve().parent)
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)

import memory_viewer  # noqa: E402
from memory_viewer import Handler, _json_bytes, _maybe_sync_index, _qs_int  # noqa: E402

# ---------------------------------------------------------------------------
# Helpers — minimal fake HTTP handler plumbing
# ---------------------------------------------------------------------------


def _make_handler(
    method: str = "GET",
    path: str = "/api/health",
    headers: dict[str, str] | None = None,
    body: bytes = b"",
    token: str = "",
) -> tuple[Handler, io.BytesIO]:
    """Create a Handler instance wired to in-memory buffers."""
    wfile = io.BytesIO()
    rfile = io.BytesIO(body)

    h = Handler.__new__(Handler)
    h.command = method
    h.path = path
    h.headers = {**(headers or {})}
    if token:
        h.headers["X-Context-Token"] = token
    h.rfile = rfile
    h.wfile = wfile
    h.request = MagicMock()
    h.client_address = ("127.0.0.1", 12345)
    h.server = MagicMock()

    # Monkey-patch send_response / send_header / end_headers to write to wfile
    h._response_lines: list[bytes] = []

    def _send_response(code: int, message: str = "") -> None:
        h._status_code = code

    def _send_header(key: str, value: str) -> None:
        pass

    def _end_headers() -> None:
        pass

    h.send_response = _send_response  # type: ignore[method-assign]
    h.send_header = _send_header  # type: ignore[method-assign]
    h.end_headers = _end_headers  # type: ignore[method-assign]
    h._status_code = 200

    return h, wfile


def _parse_json_response(wfile: io.BytesIO) -> dict:
    wfile.seek(0)
    return json.loads(wfile.read().decode("utf-8"))


# ---------------------------------------------------------------------------
# Tests: _json_bytes
# ---------------------------------------------------------------------------


class TestJsonBytes(unittest.TestCase):
    def test_serialises_dict(self) -> None:
        result = _json_bytes({"ok": True, "count": 3})
        parsed = json.loads(result.decode("utf-8"))
        self.assertEqual(parsed, {"ok": True, "count": 3})

    def test_unicode_not_escaped(self) -> None:
        result = _json_bytes({"msg": "你好"})
        self.assertIn("你好", result.decode("utf-8"))

    def test_returns_bytes(self) -> None:
        result = _json_bytes({})
        self.assertIsInstance(result, bytes)


# ---------------------------------------------------------------------------
# Tests: _maybe_sync_index
# ---------------------------------------------------------------------------


class TestMaybeSyncIndex(unittest.TestCase):
    def setUp(self) -> None:
        # Reset sync state before each test
        memory_viewer._sync_at = 0.0
        memory_viewer._sync_payload = None

    def test_calls_sync_when_cache_empty(self) -> None:
        fake_payload = {"total_observations": 5}
        with patch("memory_viewer.sync_index_from_storage", return_value=fake_payload) as m:
            result = _maybe_sync_index()
        m.assert_called_once()
        self.assertEqual(result, fake_payload)

    def test_returns_cached_when_fresh(self) -> None:
        import time

        fake_payload = {"total_observations": 7}
        memory_viewer._sync_at = time.monotonic()  # very fresh
        memory_viewer._sync_payload = dict(fake_payload)
        with patch("memory_viewer.sync_index_from_storage") as m:
            result = _maybe_sync_index()
        m.assert_not_called()
        self.assertEqual(result, fake_payload)

    def test_refreshes_when_stale(self) -> None:
        fresh_payload = {"total_observations": 99}
        memory_viewer._sync_at = 0.0  # definitely stale
        memory_viewer._sync_payload = {"total_observations": 1}
        with patch("memory_viewer.sync_index_from_storage", return_value=fresh_payload):
            result = _maybe_sync_index()
        self.assertEqual(result["total_observations"], 99)


# ---------------------------------------------------------------------------
# Tests: _qs_int (module-level query string integer parser)
# ---------------------------------------------------------------------------


class TestQsInt(unittest.TestCase):
    def test_valid_int(self) -> None:
        qs = {"limit": ["10"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 1, 100), 10)

    def test_invalid_falls_back_to_default(self) -> None:
        qs = {"limit": ["abc"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 1, 100), 5)

    def test_clamps_to_min(self) -> None:
        qs = {"limit": ["0"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 2, 100), 2)

    def test_clamps_to_max(self) -> None:
        qs = {"limit": ["999"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 1, 50), 50)

    def test_exact_min(self) -> None:
        qs = {"limit": ["1"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 1, 100), 1)

    def test_exact_max(self) -> None:
        qs = {"limit": ["100"]}
        self.assertEqual(_qs_int(qs, "limit", 5, 1, 100), 100)


# ---------------------------------------------------------------------------
# Tests: Handler._authorized
# ---------------------------------------------------------------------------


class TestHandlerAuthorized(unittest.TestCase):
    def test_no_token_configured_always_authorized(self) -> None:
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = ""
            h, _ = _make_handler()
            self.assertTrue(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_with_correct_token_authorized(self) -> None:
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "mysecret"
            h, _ = _make_handler(headers={"X-Context-Token": "mysecret"})
            self.assertTrue(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_with_wrong_token_not_authorized(self) -> None:
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "correct"
            h, _ = _make_handler(headers={"X-Context-Token": "wrong"})
            self.assertFalse(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_missing_token_header_not_authorized(self) -> None:
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "required"
            h, _ = _make_handler()
            self.assertFalse(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original


# ---------------------------------------------------------------------------
# Tests: Handler._send_json
# ---------------------------------------------------------------------------


class TestHandlerSendJson(unittest.TestCase):
    def test_writes_json_body(self) -> None:
        h, wfile = _make_handler()
        h._send_json(200, {"ok": True, "value": 42})
        payload = _parse_json_response(wfile)
        self.assertEqual(payload, {"ok": True, "value": 42})

    def test_status_code_set(self) -> None:
        h, _ = _make_handler()
        h._send_json(404, {"ok": False, "error": "not found"})
        self.assertEqual(h._status_code, 404)

    def test_error_response(self) -> None:
        h, wfile = _make_handler()
        h._send_json(500, {"ok": False, "error": "internal error"})
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"], "internal error")


# ---------------------------------------------------------------------------
# Tests: Handler._handle_health
# ---------------------------------------------------------------------------


class TestHandlerHealth(unittest.TestCase):
    def test_health_ok(self) -> None:
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={"synced": True}),
            patch("memory_viewer.index_stats", return_value={"total_observations": 10}),
        ):
            h._handle_health()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["total_observations"], 10)

    def test_health_returns_500_on_exception(self) -> None:
        h, wfile = _make_handler()
        with patch("memory_viewer._maybe_sync_index", side_effect=RuntimeError("boom")):
            h._handle_health()
        self.assertEqual(h._status_code, 500)
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])
        # detail field was removed to prevent internal info leakage
        self.assertNotIn("detail", payload)


# ---------------------------------------------------------------------------
# Tests: Handler._handle_search
# ---------------------------------------------------------------------------


class TestHandlerSearch(unittest.TestCase):
    def test_search_returns_results(self) -> None:
        h, wfile = _make_handler()
        fake_rows = [{"id": 1, "text": "hello"}]
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=fake_rows) as m,
        ):
            h._handle_search("query=hello&limit=10")
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["count"], 1)
        self.assertEqual(payload["results"], fake_rows)
        m.assert_called_once_with(query="hello", limit=10, offset=0, source_type="all")

    def test_search_returns_500_on_exception(self) -> None:
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", side_effect=RuntimeError("db error")),
        ):
            h._handle_search("query=fail")
        self.assertEqual(h._status_code, 500)
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])

    def test_search_default_params(self) -> None:
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("")
        m.assert_called_once_with(query="", limit=20, offset=0, source_type="all")


# ---------------------------------------------------------------------------
# Tests: Handler._handle_timeline
# ---------------------------------------------------------------------------


class TestHandlerTimeline(unittest.TestCase):
    def test_timeline_with_anchor_zero_returns_empty(self) -> None:
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=[]) as m,
        ):
            h._handle_timeline("anchor=0")
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["timeline"], [])
        m.assert_not_called()

    def test_timeline_with_anchor_calls_timeline_index(self) -> None:
        h, wfile = _make_handler()
        fake_rows = [{"id": 5, "text": "context"}]
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=fake_rows) as m,
        ):
            h._handle_timeline("anchor=5&depth_before=2&depth_after=2")
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["timeline"], fake_rows)
        m.assert_called_once_with(anchor_id=5, depth_before=2, depth_after=2)

    def test_timeline_returns_500_on_exception(self) -> None:
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", side_effect=RuntimeError("fail")),
        ):
            h._handle_timeline("anchor=1")
        self.assertEqual(h._status_code, 500)


# ---------------------------------------------------------------------------
# Tests: Handler._handle_batch_fetch
# ---------------------------------------------------------------------------


class TestHandlerBatchFetch(unittest.TestCase):
    def _make_post_handler(self, body: bytes, content_length: int | None = None) -> tuple[Handler, io.BytesIO]:
        cl = str(content_length if content_length is not None else len(body))
        return _make_handler(
            method="POST",
            path="/api/observations/batch",
            headers={"Content-Length": cl},
            body=body,
        )

    def test_valid_batch_returns_observations(self) -> None:
        body = json.dumps({"ids": [1, 2, 3]}).encode()
        h, wfile = self._make_post_handler(body)
        fake_rows = [{"id": 1}, {"id": 2}, {"id": 3}]
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.get_observations_by_ids", return_value=fake_rows),
        ):
            h._handle_batch_fetch()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["count"], 3)

    def test_empty_body_returns_400(self) -> None:
        h, wfile = self._make_post_handler(b"", content_length=0)
        h._handle_batch_fetch()
        self.assertEqual(h._status_code, 400)

    def test_invalid_content_length_returns_400(self) -> None:
        h, wfile = self._make_post_handler(b"{}", content_length=-1)
        # Override Content-Length header to invalid value
        h.headers["Content-Length"] = "not_a_number"
        h._handle_batch_fetch()
        self.assertEqual(h._status_code, 400)

    def test_ids_not_array_returns_400(self) -> None:
        body = json.dumps({"ids": "not_array"}).encode()
        h, wfile = self._make_post_handler(body)
        with patch("memory_viewer._maybe_sync_index", return_value={}):
            h._handle_batch_fetch()
        self.assertEqual(h._status_code, 400)

    def test_too_many_ids_returns_400(self) -> None:
        original_max = memory_viewer._MAX_BATCH_IDS
        try:
            memory_viewer._MAX_BATCH_IDS = 3
            body = json.dumps({"ids": [1, 2, 3, 4, 5]}).encode()
            h, wfile = self._make_post_handler(body)
            with patch("memory_viewer._maybe_sync_index", return_value={}):
                h._handle_batch_fetch()
            self.assertEqual(h._status_code, 400)
        finally:
            memory_viewer._MAX_BATCH_IDS = original_max

    def test_invalid_json_returns_400(self) -> None:
        body = b"not json at all"
        h, wfile = self._make_post_handler(body)
        with patch("memory_viewer._maybe_sync_index", return_value={}):
            h._handle_batch_fetch()
        self.assertEqual(h._status_code, 400)


# ---------------------------------------------------------------------------
# Tests: Handler.do_GET routing
# ---------------------------------------------------------------------------


class TestHandlerDoGet(unittest.TestCase):
    def test_root_path_returns_html(self) -> None:
        h, wfile = _make_handler(path="/")
        # Track what content-type was set
        sent_headers: list[tuple[str, str]] = []
        h.send_header = lambda k, v: sent_headers.append((k, v))  # type: ignore[method-assign]

        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.index_stats", return_value={}),
        ):
            h.do_GET()

        wfile.seek(0)
        content = wfile.read()
        self.assertIn(b"ContextGO", content)

    def test_api_not_found_returns_404(self) -> None:
        h, wfile = _make_handler(path="/api/nonexistent")
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = ""  # no auth required
            h.do_GET()
        finally:
            memory_viewer.VIEWER_TOKEN = original_token
        self.assertEqual(h._status_code, 404)
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])

    def test_api_unauthorized_when_token_required(self) -> None:
        h, wfile = _make_handler(path="/api/health")
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "required_token"
            # No token in request headers
            h.do_GET()
        finally:
            memory_viewer.VIEWER_TOKEN = original_token
        self.assertEqual(h._status_code, 401)


# ---------------------------------------------------------------------------
# Tests: Handler.do_POST routing
# ---------------------------------------------------------------------------


class TestHandlerDoPost(unittest.TestCase):
    def test_post_to_nonexistent_returns_404(self) -> None:
        h, wfile = _make_handler(method="POST", path="/api/nonexistent")
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = ""
            h.do_POST()
        finally:
            memory_viewer.VIEWER_TOKEN = original_token
        self.assertEqual(h._status_code, 404)

    def test_post_unauthorized_when_token_required(self) -> None:
        h, wfile = _make_handler(method="POST", path="/api/observations/batch")
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "required_token"
            h.do_POST()
        finally:
            memory_viewer.VIEWER_TOKEN = original_token
        self.assertEqual(h._status_code, 401)


# ---------------------------------------------------------------------------
# Tests: Handler.do_OPTIONS
# ---------------------------------------------------------------------------


class TestHandlerDoOptions(unittest.TestCase):
    def test_options_returns_204(self) -> None:
        h, _ = _make_handler(method="OPTIONS", path="/api/health")
        h.do_OPTIONS()
        self.assertEqual(h._status_code, 204)


# ---------------------------------------------------------------------------
# Tests: CORS headers
# ---------------------------------------------------------------------------


class TestHandlerCors(unittest.TestCase):
    def test_cors_header_for_localhost_origin(self) -> None:
        h, _ = _make_handler(headers={"Origin": "http://localhost:3000"})
        sent: list[tuple[str, str]] = []
        h.send_header = lambda k, v: sent.append((k, v))  # type: ignore[method-assign]
        h._add_cors_headers()
        header_names = [k for k, _ in sent]
        self.assertIn("Access-Control-Allow-Origin", header_names)

    def test_no_cors_header_for_external_origin(self) -> None:
        h, _ = _make_handler(headers={"Origin": "http://evil.com"})
        sent: list[tuple[str, str]] = []
        h.send_header = lambda k, v: sent.append((k, v))  # type: ignore[method-assign]
        h._add_cors_headers()
        header_names = [k for k, _ in sent]
        self.assertNotIn("Access-Control-Allow-Origin", header_names)

    def test_no_cors_header_when_no_origin(self) -> None:
        h, _ = _make_handler()
        sent: list[tuple[str, str]] = []
        h.send_header = lambda k, v: sent.append((k, v))  # type: ignore[method-assign]
        h._add_cors_headers()
        self.assertEqual(sent, [])


# ---------------------------------------------------------------------------
# Tests: Handler.log_message (line 297 - silenced logger)
# ---------------------------------------------------------------------------


class TestHandlerLogMessage(unittest.TestCase):
    def test_log_message_returns_none(self) -> None:
        h, _ = _make_handler()
        result = h.log_message("%s %s", "GET", "/api/health")
        self.assertIsNone(result)


# ---------------------------------------------------------------------------
# Tests: _maybe_sync_index double-checked locking (line 98)
# ---------------------------------------------------------------------------


class TestMaybeSyncIndexDoubleLock(unittest.TestCase):
    def test_double_checked_locking_returns_cached_after_lock(self) -> None:
        """Exercise line 98: second check inside the lock when another thread
        has already refreshed the cache between our stale read and lock acquire."""
        import time

        fresh_payload = {"total_observations": 42}
        # Mark cache as stale initially so we enter the slow path.
        memory_viewer._sync_at = 0.0
        memory_viewer._sync_payload = {"total_observations": 1}

        call_count = [0]

        def fake_sync_that_refreshes_first():
            # Simulate another thread having refreshed just before us by
            # updating the module-level state before we can.
            call_count[0] += 1
            return {"total_observations": 99}

        # Prime the module state so the inner lock check succeeds:
        # set _sync_at to "now" and _sync_payload to fresh_payload so the
        # re-check inside the lock (line 97) returns True and we hit line 98.
        memory_viewer._sync_payload = dict(fresh_payload)
        memory_viewer._sync_at = time.monotonic() + 10_000  # very far in future

        # Reset stale read conditions so we enter the lock (bypass fast path)
        # by temporarily setting _SYNC_MIN_INTERVAL_SEC to 0 so fast path is skipped.
        orig_interval = memory_viewer._SYNC_MIN_INTERVAL_SEC
        try:
            memory_viewer._SYNC_MIN_INTERVAL_SEC = 0.0  # skip fast path
            # With interval=0, inner check `_sync_at + 0 > now` is True (since _sync_at is future)
            with patch("memory_viewer.sync_index_from_storage", side_effect=fake_sync_that_refreshes_first):
                result = memory_viewer._maybe_sync_index()
            # We should get the cached value back (line 98 was hit)
            self.assertEqual(result["total_observations"], 42)
            self.assertEqual(call_count[0], 0)  # sync_index_from_storage was NOT called
        finally:
            memory_viewer._SYNC_MIN_INTERVAL_SEC = orig_interval
            memory_viewer._sync_at = 0.0
            memory_viewer._sync_payload = None


# ---------------------------------------------------------------------------
# Tests: CORS exception path (lines 334-335)
# ---------------------------------------------------------------------------


class TestHandlerCorsException(unittest.TestCase):
    def test_cors_exception_treated_as_non_loopback(self) -> None:
        """Exercise lines 334-335: urlparse raises, origin_host becomes ''."""
        h, _ = _make_handler(headers={"Origin": "http://localhost"})
        sent: list[tuple[str, str]] = []
        h.send_header = lambda k, v: sent.append((k, v))  # type: ignore[method-assign]

        with patch("memory_viewer.urlparse", side_effect=Exception("parse error")):
            h._add_cors_headers()

        header_names = [k for k, _ in sent]
        # Vary should still be sent (before the try/except), but no ACAO
        self.assertNotIn("Access-Control-Allow-Origin", header_names)


# ---------------------------------------------------------------------------
# Tests: do_GET routing to all API handlers (lines 398, 400, 402, 404)
# ---------------------------------------------------------------------------


class TestHandlerDoGetRouting(unittest.TestCase):
    def _setup_no_token(self):
        memory_viewer.VIEWER_TOKEN = ""

    def tearDown(self):
        memory_viewer.VIEWER_TOKEN = ""

    def test_do_get_health_route(self) -> None:
        """Line 398: /api/health dispatched via do_GET."""
        h, wfile = _make_handler(path="/api/health")
        self._setup_no_token()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.index_stats", return_value={"total_observations": 5}),
        ):
            h.do_GET()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])

    def test_do_get_search_route(self) -> None:
        """Line 400: /api/search dispatched via do_GET."""
        h, wfile = _make_handler(path="/api/search?query=test")
        self._setup_no_token()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]),
        ):
            h.do_GET()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])

    def test_do_get_timeline_route(self) -> None:
        """Line 402: /api/timeline dispatched via do_GET."""
        h, wfile = _make_handler(path="/api/timeline?anchor=0")
        self._setup_no_token()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=[]),
        ):
            h.do_GET()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])

    def test_do_get_events_route(self) -> None:
        """Line 404: /api/events dispatched via do_GET, runs SSE for 1 tick."""
        h, wfile = _make_handler(path="/api/events")
        self._setup_no_token()
        original_ticks = memory_viewer._SSE_MAX_TICKS
        original_interval = memory_viewer._SSE_INTERVAL_SEC
        try:
            memory_viewer._SSE_MAX_TICKS = 1
            memory_viewer._SSE_INTERVAL_SEC = 0.0
            with (
                patch("memory_viewer._maybe_sync_index", return_value={"synced": True}),
                patch("memory_viewer.index_stats", return_value={"total_observations": 3}),
                patch("memory_viewer.time.sleep"),
            ):
                h.do_GET()
        finally:
            memory_viewer._SSE_MAX_TICKS = original_ticks
            memory_viewer._SSE_INTERVAL_SEC = original_interval
        wfile.seek(0)
        content = wfile.read().decode()
        self.assertIn("data:", content)

    def test_do_get_index_html_route(self) -> None:
        """/index.html also returns HTML."""
        h, wfile = _make_handler(path="/index.html")
        h.do_GET()
        wfile.seek(0)
        content = wfile.read()
        self.assertIn(b"ContextGO", content)


# ---------------------------------------------------------------------------
# Tests: do_POST routing to batch handler (line 419)
# ---------------------------------------------------------------------------


class TestHandlerDoPostRouting(unittest.TestCase):
    def test_do_post_batch_route(self) -> None:
        """Line 419: /api/observations/batch dispatched via do_POST."""
        body = json.dumps({"ids": [1, 2]}).encode()
        h, wfile = _make_handler(
            method="POST",
            path="/api/observations/batch",
            headers={"Content-Length": str(len(body))},
            body=body,
        )
        memory_viewer.VIEWER_TOKEN = ""
        try:
            with (
                patch("memory_viewer._maybe_sync_index", return_value={}),
                patch("memory_viewer.get_observations_by_ids", return_value=[{"id": 1}, {"id": 2}]),
            ):
                h.do_POST()
        finally:
            memory_viewer.VIEWER_TOKEN = ""
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["count"], 2)


# ---------------------------------------------------------------------------
# Tests: _handle_sse (lines 481-502)
# ---------------------------------------------------------------------------


class TestHandlerSse(unittest.TestCase):
    def test_sse_emits_data_lines(self) -> None:
        """Lines 481-499: SSE emits JSON data lines."""
        h, wfile = _make_handler(path="/api/events")
        original_ticks = memory_viewer._SSE_MAX_TICKS
        original_interval = memory_viewer._SSE_INTERVAL_SEC
        try:
            memory_viewer._SSE_MAX_TICKS = 2
            memory_viewer._SSE_INTERVAL_SEC = 0.0
            with (
                patch("memory_viewer._maybe_sync_index", return_value={"total": 1}),
                patch("memory_viewer.index_stats", return_value={"total_observations": 7}),
                patch("memory_viewer.time.sleep"),
            ):
                h._handle_sse()
        finally:
            memory_viewer._SSE_MAX_TICKS = original_ticks
            memory_viewer._SSE_INTERVAL_SEC = original_interval
        wfile.seek(0)
        content = wfile.read().decode()
        lines = [l for l in content.split("\n") if l.startswith("data:")]
        self.assertEqual(len(lines), 2)
        parsed = json.loads(lines[0][len("data: ") :])
        self.assertIn("total_observations", parsed)
        self.assertIn("at", parsed)

    def test_sse_stops_on_broken_pipe(self) -> None:
        """Lines 501-502: BrokenPipeError breaks the loop."""
        h, wfile = _make_handler(path="/api/events")
        original_ticks = memory_viewer._SSE_MAX_TICKS
        try:
            memory_viewer._SSE_MAX_TICKS = 5
            with (
                patch("memory_viewer._maybe_sync_index", return_value={}),
                patch("memory_viewer.index_stats", return_value={"total_observations": 0}),
            ):
                # Make wfile.write raise BrokenPipeError after headers are done
                write_calls = [0]
                original_write = wfile.write

                def failing_write(data):
                    write_calls[0] += 1
                    if write_calls[0] > 1:  # let headers pass, fail on first data
                        raise BrokenPipeError("pipe broken")
                    return original_write(data)

                h.wfile.write = failing_write
                h._handle_sse()
        finally:
            memory_viewer._SSE_MAX_TICKS = original_ticks
        # Should have exited loop early (only 1 data write attempted)
        self.assertLess(write_calls[0], 5)

    def test_sse_stops_on_connection_reset(self) -> None:
        """Lines 501-502: ConnectionResetError also breaks the loop."""
        h, wfile = _make_handler(path="/api/events")
        original_ticks = memory_viewer._SSE_MAX_TICKS
        try:
            memory_viewer._SSE_MAX_TICKS = 5
            with (
                patch("memory_viewer._maybe_sync_index", return_value={}),
                patch("memory_viewer.index_stats", return_value={"total_observations": 0}),
            ):
                write_calls = [0]

                def failing_write(data):
                    write_calls[0] += 1
                    if write_calls[0] > 1:
                        raise ConnectionResetError("reset")
                    return len(data)

                h.wfile.write = failing_write
                h._handle_sse()
        finally:
            memory_viewer._SSE_MAX_TICKS = original_ticks
        self.assertLess(write_calls[0], 5)


# ---------------------------------------------------------------------------
# Tests: _handle_batch_fetch non-integer IDs and exception (lines 548-549, 556-558)
# ---------------------------------------------------------------------------


class TestHandlerBatchFetchExtended(unittest.TestCase):
    def _make_post_handler(self, body: bytes, content_length: int | None = None) -> tuple[Handler, io.BytesIO]:
        cl = str(content_length if content_length is not None else len(body))
        return _make_handler(
            method="POST",
            path="/api/observations/batch",
            headers={"Content-Length": cl},
            body=body,
        )

    def test_non_integer_ids_are_skipped(self) -> None:
        """Lines 548-549: non-int IDs are silently skipped."""
        body = json.dumps({"ids": [1, "bad", None, 3, "also_bad"]}).encode()
        h, wfile = self._make_post_handler(body)
        captured_ids = []

        def fake_get(ids, limit):
            captured_ids.extend(ids)
            return [{"id": i} for i in ids]

        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.get_observations_by_ids", side_effect=fake_get),
        ):
            h._handle_batch_fetch()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        # Only integer-parseable IDs should pass through
        self.assertEqual(sorted(captured_ids), [1, 3])

    def test_get_observations_exception_returns_500(self) -> None:
        """Lines 556-558: exception from get_observations_by_ids returns 500."""
        body = json.dumps({"ids": [1, 2]}).encode()
        h, wfile = self._make_post_handler(body)
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.get_observations_by_ids", side_effect=RuntimeError("db exploded")),
        ):
            h._handle_batch_fetch()
        self.assertEqual(h._status_code, 500)
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])
        # detail field was removed to prevent internal info leakage
        self.assertNotIn("detail", payload)

    def test_batch_with_all_invalid_ids(self) -> None:
        """All IDs are non-integer; parsed_ids is empty list."""
        body = json.dumps({"ids": ["x", "y", None]}).encode()
        h, wfile = self._make_post_handler(body)
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.get_observations_by_ids", return_value=[]) as m,
        ):
            h._handle_batch_fetch()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["count"], 0)
        m.assert_called_once_with([], limit=100)


# ---------------------------------------------------------------------------
# Tests: main() function (lines 574-583, 587)
# ---------------------------------------------------------------------------


class TestMainFunction(unittest.TestCase):
    def test_main_exits_for_non_loopback_without_token(self) -> None:
        """Line 574-575: raises SystemExit when binding non-loopback without token."""
        original_host = memory_viewer.HOST
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.HOST = "0.0.0.0"
            memory_viewer.VIEWER_TOKEN = ""
            with self.assertRaises(SystemExit):
                memory_viewer.main()
        finally:
            memory_viewer.HOST = original_host
            memory_viewer.VIEWER_TOKEN = original_token

    def test_main_starts_and_stops_server(self) -> None:
        """Lines 576-583: server is started and stopped on KeyboardInterrupt."""
        original_host = memory_viewer.HOST
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.HOST = "127.0.0.1"
            memory_viewer.VIEWER_TOKEN = ""
            mock_server = MagicMock()
            mock_server.serve_forever.side_effect = KeyboardInterrupt

            with patch("memory_viewer.ThreadingHTTPServer", return_value=mock_server):
                memory_viewer.main()  # should not raise

            mock_server.serve_forever.assert_called_once()
            mock_server.server_close.assert_called_once()
        finally:
            memory_viewer.HOST = original_host
            memory_viewer.VIEWER_TOKEN = original_token

    def test_main_with_token_on_non_loopback_starts_server(self) -> None:
        """Lines 576-583: non-loopback with token does not exit."""
        original_host = memory_viewer.HOST
        original_token = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.HOST = "0.0.0.0"
            memory_viewer.VIEWER_TOKEN = "securetoken"
            mock_server = MagicMock()
            mock_server.serve_forever.side_effect = KeyboardInterrupt

            with patch("memory_viewer.ThreadingHTTPServer", return_value=mock_server):
                memory_viewer.main()

            mock_server.server_close.assert_called_once()
        finally:
            memory_viewer.HOST = original_host
            memory_viewer.VIEWER_TOKEN = original_token


# ---------------------------------------------------------------------------
# Edge-case Tests: R6 hardening
# ---------------------------------------------------------------------------


class TestHandlerSearchEdgeCases(unittest.TestCase):
    """Edge cases for _handle_search: empty query, XSS, large page numbers."""

    def setUp(self) -> None:
        memory_viewer.VIEWER_TOKEN = ""

    def tearDown(self) -> None:
        memory_viewer.VIEWER_TOKEN = ""

    def test_empty_query_returns_ok(self) -> None:
        """Empty search query string should be forwarded to search_index unchanged."""
        h, wfile = _make_handler(path="/api/search?query=")
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("query=")
        m.assert_called_once_with(query="", limit=20, offset=0, source_type="all")
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["count"], 0)

    def test_blank_query_whitespace_only_treated_as_empty(self) -> None:
        """Whitespace-only query is stripped to empty string."""
        h, wfile = _make_handler(path="/api/search?query=+++")
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]),
        ):
            h._handle_search("query=+++")
        # _qs_str strips whitespace; URL-encoded spaces become empty after strip
        # The query is passed through; it will be stripped to "" or remain spaces
        # depending on URL decoding — the key assertion is no exception was raised.
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])

    def test_xss_attempt_in_query_not_reflected_as_html(self) -> None:
        """XSS payload in query is treated as plain text; response is JSON, not HTML."""
        xss = "<script>alert('xss')</script>"
        h, wfile = _make_handler(path=f"/api/search?query={xss}")
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]),
        ):
            h._handle_search(f"query={xss}")
        payload = _parse_json_response(wfile)
        # Response must be valid JSON (no raw HTML injection in the response body)
        self.assertTrue(payload["ok"])
        # The XSS string must NOT appear verbatim in the JSON response body
        wfile.seek(0)
        raw = wfile.read().decode("utf-8")
        self.assertNotIn("<script>", raw)

    def test_xss_in_query_forwarded_safely_to_search_index(self) -> None:
        """The XSS string is forwarded to search_index as a plain string (not executed)."""
        xss = "<img src=x onerror=alert(1)>"
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search(f"query={xss}")
        # search_index received the raw query string (URL-decoded) as text
        self.assertTrue(m.called)

    def test_very_large_offset_clamped_to_max(self) -> None:
        """An extremely large offset value is clamped to max_v=100_000."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("query=hello&offset=999999999")
        call_offset = m.call_args[1]["offset"]
        self.assertEqual(call_offset, 100_000)

    def test_very_large_limit_clamped_to_max(self) -> None:
        """An extremely large limit value is clamped to max_v=200."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("query=hello&limit=99999")
        call_limit = m.call_args[1]["limit"]
        self.assertEqual(call_limit, 200)

    def test_negative_offset_clamped_to_zero(self) -> None:
        """Negative offset is clamped to min_v=0."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("query=test&offset=-50")
        call_offset = m.call_args[1]["offset"]
        self.assertEqual(call_offset, 0)

    def test_non_numeric_limit_falls_back_to_default(self) -> None:
        """Non-numeric limit falls back to default=20."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]) as m,
        ):
            h._handle_search("query=test&limit=abc")
        call_limit = m.call_args[1]["limit"]
        self.assertEqual(call_limit, 20)


class TestHandlerAuthEdgeCases(unittest.TestCase):
    """Edge cases for auth token handling."""

    def test_empty_token_header_value_is_not_authorized(self) -> None:
        """An empty string X-Context-Token header is rejected when token is set."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "mysecret"
            h, _ = _make_handler(headers={"X-Context-Token": ""})
            self.assertFalse(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_whitespace_only_token_is_not_authorized(self) -> None:
        """Whitespace-only token header is rejected."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "mysecret"
            h, _ = _make_handler(headers={"X-Context-Token": "   "})
            self.assertFalse(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_token_with_extra_whitespace_is_compared_after_strip(self) -> None:
        """Token header with surrounding whitespace is stripped before comparison."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "mysecret"
            # Token in header has surrounding whitespace — strip() normalises it
            h, _ = _make_handler(headers={"X-Context-Token": "  mysecret  "})
            # After strip the token is "mysecret" which matches VIEWER_TOKEN
            self.assertTrue(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original

    def test_invalid_auth_token_returns_401_on_api_endpoint(self) -> None:
        """An invalid auth token causes the API endpoint to return 401."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "correcttoken"
            h, wfile = _make_handler(
                method="GET",
                path="/api/health",
                headers={"X-Context-Token": "wrongtoken"},
            )
            h.do_GET()
        finally:
            memory_viewer.VIEWER_TOKEN = original
        self.assertEqual(h._status_code, 401)
        payload = _parse_json_response(wfile)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["error"], "unauthorized")

    def test_no_token_header_returns_401_on_post_endpoint(self) -> None:
        """Missing auth token on POST returns 401."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "required"
            h, wfile = _make_handler(
                method="POST",
                path="/api/observations/batch",
            )
            h.do_POST()
        finally:
            memory_viewer.VIEWER_TOKEN = original
        self.assertEqual(h._status_code, 401)

    def test_sql_injection_like_token_rejected(self) -> None:
        """A SQL-injection-style token string is treated as a plain string comparison."""
        original = memory_viewer.VIEWER_TOKEN
        try:
            memory_viewer.VIEWER_TOKEN = "correcttoken"
            h, _ = _make_handler(headers={"X-Context-Token": "' OR '1'='1"})
            self.assertFalse(h._authorized())
        finally:
            memory_viewer.VIEWER_TOKEN = original


class TestHandlerTimelineEdgeCases(unittest.TestCase):
    """Edge cases for _handle_timeline: large anchor values."""

    def test_very_large_anchor_clamped_to_max(self) -> None:
        """Anchor value exceeding max_v=10_000_000 is clamped."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=[]) as m,
        ):
            h._handle_timeline("anchor=999999999")
        # Should be clamped to 10_000_000 and timeline_index called (anchor > 0)
        m.assert_called_once_with(anchor_id=10_000_000, depth_before=3, depth_after=3)

    def test_negative_anchor_treated_as_zero(self) -> None:
        """Negative anchor is clamped to 0, so timeline_index is NOT called."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=[]) as m,
        ):
            h._handle_timeline("anchor=-1")
        m.assert_not_called()
        payload = _parse_json_response(wfile)
        self.assertEqual(payload["timeline"], [])

    def test_depth_values_clamped_to_range(self) -> None:
        """depth_before and depth_after values beyond 20 are clamped to 20."""
        h, wfile = _make_handler()
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.timeline_index", return_value=[]) as m,
        ):
            h._handle_timeline("anchor=5&depth_before=999&depth_after=999")
        m.assert_called_once_with(anchor_id=5, depth_before=20, depth_after=20)


class TestHandlerSearchDoGetXss(unittest.TestCase):
    """Integration: XSS query routed through do_GET pipeline."""

    def setUp(self) -> None:
        memory_viewer.VIEWER_TOKEN = ""

    def tearDown(self) -> None:
        memory_viewer.VIEWER_TOKEN = ""

    def test_xss_via_do_get_search_route(self) -> None:
        """XSS payload in the full do_GET /api/search path produces valid JSON."""
        import urllib.parse

        xss = "<script>alert('xss')</script>"
        encoded = urllib.parse.quote(xss)
        h, wfile = _make_handler(path=f"/api/search?query={encoded}")
        with (
            patch("memory_viewer._maybe_sync_index", return_value={}),
            patch("memory_viewer.search_index", return_value=[]),
        ):
            h.do_GET()
        payload = _parse_json_response(wfile)
        self.assertTrue(payload["ok"])
        # Response body must not contain a raw <script> tag
        wfile.seek(0)
        raw = wfile.read().decode("utf-8")
        self.assertNotIn("<script>", raw)


if __name__ == "__main__":
    unittest.main()
