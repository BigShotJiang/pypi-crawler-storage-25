import{j as e,r as u,a as P,c as S,d as W,e as O,f as w,L as y,I as j,B as C,t as E}from"./index-Blzl7Rje.js";import{D as _,d as x,i as M,b as T}from"./workflowDraft-DKH-cU0S.js";const B=`version: '1.0'
id: research-review
kind: workflow
tools:
  - file_io
# REQUIRED BEFORE RUNNING:
# - Replace every PLACEHOLDER_PROVIDER_ID with one of your configured provider ids.
# - Replace every PLACEHOLDER_MODEL_NAME with a model that belongs to that provider.
# - Temperature defaults to 1 below. If your chosen model does not support temperature,
#   remove the temperature line for that soul.
souls:
  researcher:
    id: researcher
    kind: soul
    name: Researcher
    role: Research File Writer
    system_prompt: >
      You are a fast research assistant.
      Use the user's task as the topic. If the task is blank or too generic,
      default to "Runsight onboarding starter workflow".
      Produce a concise markdown research note with a title, 3 to 5 concrete bullets,
      and a short "Next steps" section.
      If previous_round_context appears in the provided context, use it to improve the draft.
      Before finishing, you MUST call the file_io tool to write the markdown to
      custom/outputs/onboarding-research-brief.md.
      After the tool call succeeds, return the same markdown.
    tools:
      - file_io
    required_tool_calls:
      - file_io
    max_tool_iterations: 4
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: info
  reviewer:
    id: reviewer
    kind: soul
    name: Reviewer
    role: Quality Gate Reviewer
    system_prompt: >
      Review the draft research note.
      Return PASS if it is specific, structured, and actionable.
      Return FAIL: followed by one short paragraph of concrete fixes if it is too vague,
      generic, or missing the required structure.
    max_tool_iterations: 3
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: accent
  error_writer:
    id: error_writer
    kind: soul
    name: Error Writer
    role: Error Stub Writer
    system_prompt: >
      This block only runs after the review flow fails or errors.
      Write a short markdown stub to custom/outputs/onboarding-research-error.md.
      The stub should explain that the workflow did not produce a verified report yet
      and that the operator should inspect the latest run details.
      Before finishing, you MUST call the file_io tool to write the stub file.
      After the tool call succeeds, return one sentence with the file path.
    tools:
      - file_io
    required_tool_calls:
      - file_io
    max_tool_iterations: 3
    provider: PLACEHOLDER_PROVIDER_ID
    model_name: PLACEHOLDER_MODEL_NAME
    temperature: 1
    avatar_color: warning
blocks:
  draft_report:
    type: linear
    soul_ref: researcher
  quality_gate:
    type: gate
    soul_ref: reviewer
    eval_key: draft_report
  review_loop:
    type: loop
    inner_block_refs:
      - draft_report
      - quality_gate
    max_rounds: 2
    break_on_exit: pass
    retry_on_exit: fail
    carry_context:
      enabled: true
      mode: all
      source_blocks:
        - draft_report
        - quality_gate
      inject_as: previous_round_context
    error_route: write_error_stub
  check_review_status:
    type: code
    timeout_seconds: 10
    inputs:
      loop_status:
        from: shared_memory.__loop__review_loop
    code: |
      def main(data):
          loop_meta = data.get("loop_status", {}) or {}
          break_reason = str(loop_meta.get("break_reason", ""))
          passed = "pass" in break_reason
          return {
              "status": "pass" if passed else "fail",
              "break_reason": break_reason,
              "exit_handle": "pass" if passed else "fail",
          }
  write_error_stub:
    type: linear
    soul_ref: error_writer
  finish_success:
    type: code
    timeout_seconds: 10
    inputs:
      review_status_result:
        from: check_review_status
    code: |
      import json

      def _normalize(raw):
          if isinstance(raw, dict):
              return raw
          if isinstance(raw, str):
              try:
                  return json.loads(raw)
              except Exception:
                  return {"raw": raw}
          return {"raw": raw}

      def main(data):
          return {
              "status": "completed",
              "report_path": "custom/outputs/onboarding-research-brief.md",
              "error_stub_path": "custom/outputs/onboarding-research-error.md",
              "review_status": _normalize(data.get("review_status_result", "")),
              "error_stub": {"raw": ""},
          }
  finish_error:
    type: code
    timeout_seconds: 10
    inputs:
      review_status_result:
        from: check_review_status
      error_stub_result:
        from: write_error_stub
    code: |
      import json

      def _normalize(raw):
          if isinstance(raw, dict):
              return raw
          if isinstance(raw, str):
              try:
                  return json.loads(raw)
              except Exception:
                  return {"raw": raw}
          return {"raw": raw}

      def main(data):
          return {
              "status": "completed",
              "report_path": "custom/outputs/onboarding-research-brief.md",
              "error_stub_path": "custom/outputs/onboarding-research-error.md",
              "review_status": _normalize(data.get("review_status_result", "")),
              "error_stub": _normalize(data.get("error_stub_result", "")),
          }
workflow:
  name: Research & Review
  entry: review_loop
  transitions:
    - from: review_loop
      to: check_review_status
    - from: write_error_stub
      to: finish_error
  conditional_transitions:
    - from: check_review_status
      pass: finish_success
      fail: write_error_stub
      default: write_error_stub
`;function H(r){return B.replace(/^id: research-review$/m,`id: ${r}`)}function N({selected:r,onSelect:t,children:i,label:m,title:o,badge:n,description:l,footer:p}){return e.jsxs("div",{role:"radio","aria-checked":r,"aria-label":m,tabIndex:0,onClick:t,onKeyDown:s=>{(s.key==="Enter"||s.key===" ")&&(s.preventDefault(),t())},className:["flex flex-col gap-4 rounded-xl border p-5 cursor-pointer text-left","transition-[border-color,box-shadow] duration-200 ease-default",r?"border-accent-9 shadow-[0_0_0_1px_hsla(38,92%,55%,0.3)]":"border-border-subtle bg-surface-secondary hover:border-border-hover"].join(" "),children:[o&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-lg font-semibold text-heading",children:o}),n]}),l&&e.jsx("p",{className:"text-sm text-secondary leading-relaxed",children:l}),i,p]})}const z=[{label:"Research",category:"agent"},{label:"Write",category:"agent"},{label:"Review",category:"logic"}],F={agent:"bg-block-agent",logic:"bg-block-logic"};function U({label:r,category:t}){return e.jsxs("div",{className:"flex flex-col items-center gap-0.5 w-16 node-mini",children:[e.jsx("div",{className:"relative w-14 h-8 rounded-sm border border-border-subtle bg-surface-secondary overflow-hidden",children:e.jsx("div",{className:`absolute top-0 left-0 right-0 h-[3px] ${F[t]}`})}),e.jsx("span",{className:"font-mono text-[9px] text-muted uppercase tracking-wide",children:r})]})}function $(){return e.jsx("div",{className:"relative w-4 h-px bg-neutral-7 -mt-2.5",children:e.jsx("div",{className:"absolute -right-px -top-[3px] w-0 h-0",style:{borderLeft:"4px solid var(--neutral-7)",borderTop:"3px solid transparent",borderBottom:"3px solid transparent"}})})}function q(){return e.jsx("div",{className:"flex items-center justify-center gap-1.5 py-4 px-2 bg-surface-primary rounded-md border border-neutral-3","aria-hidden":"true",children:z.map((r,t)=>e.jsxs("div",{className:"contents",children:[t>0&&e.jsx($,{}),e.jsx(U,{label:r.label,category:r.category})]},r.label))})}function V(){return e.jsx("div",{className:"flex items-center justify-center py-6 px-4 bg-surface-primary rounded-md border border-neutral-3","aria-hidden":"true",children:e.jsx("div",{className:"flex items-center justify-center w-[100px] h-14 rounded-md border-[1.5px] border-dashed border-border-subtle text-neutral-7",children:e.jsx("span",{className:"text-xl font-light text-neutral-9",children:"+"})})})}function Q(){const[r,t]=u.useState("template"),[i,m]=u.useState(_),[o,n]=u.useState(x(_)),[l,p]=u.useState(!1),s=P(),b=S(),g=W(),{data:f}=O(),h=((f==null?void 0:f.items)??[]).filter(a=>a.is_active??!0).length>0,v=b.isPending||g.isPending,R=i.trim()||_,k=o.trim(),d=M(k),D=r==="template"||d;async function L(){try{const a=r==="template"?"Research & Review":R;if(r==="blank"&&!d){E.error("Please enter a valid workflow id.");return}const c=`${x(a)}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,A=r==="template"?H(c):T(k,a),I=await b.mutateAsync({name:a,yaml:A,commit:!1});await g.mutateAsync({onboarding_completed:!0}),s(`/workflows/${I.id}/edit`,{replace:!0})}catch{E.error("Something went wrong. Please try again.")}}return e.jsx("main",{className:"flex items-center justify-center min-h-screen bg-surface-primary",children:e.jsxs("div",{className:"w-full max-w-[540px] px-4 py-12 flex flex-col gap-8 text-center",children:[e.jsxs("div",{className:"flex flex-col gap-2",children:[e.jsx("h1",{className:"text-3xl font-semibold text-heading tracking-tight",children:"How do you want to start?"}),e.jsx("p",{className:"text-md text-secondary",children:"You can always create more workflows later."})]}),e.jsxs("div",{role:"radiogroup","aria-label":"Starting point",className:"grid grid-cols-2 gap-3",children:[e.jsxs(N,{selected:r==="template",onSelect:()=>t("template"),label:"Start with a template",title:"Tutorial Template",badge:e.jsx(w,{variant:"accent",children:"Recommended"}),description:"A looped starter workflow with inline souls. It drafts a research brief, writes it to custom/outputs, and emits an error stub if review still fails.",footer:e.jsxs("div",{className:"flex items-center gap-1 font-mono text-2xs text-muted pt-3 border-t border-neutral-3",children:[e.jsx("span",{className:`inline-block w-1.5 h-1.5 rounded-full shrink-0 ${h?"bg-success":"bg-info"}`}),h?e.jsx("span",{children:"Ready to run"}):e.jsx("span",{children:"Add an API key in Settings to run this workflow"})]}),children:[h?e.jsx(w,{variant:"success",children:"Ready to run"}):e.jsx(w,{variant:"warning",children:"Explore mode"}),e.jsx(q,{})]}),e.jsx(N,{selected:r==="blank",onSelect:()=>t("blank"),label:"Start with a blank canvas",title:"Blank Canvas",description:"Start from scratch. Drag blocks from the palette to build your own workflow.",footer:e.jsxs("div",{className:"flex items-center gap-1 font-mono text-2xs text-muted pt-3 border-t border-neutral-3",children:[e.jsx("span",{className:"inline-block w-1.5 h-1.5 rounded-full shrink-0 bg-neutral-9"}),e.jsx("span",{children:"Full block palette available"})]}),children:e.jsx(V,{})})]}),r==="blank"?e.jsx("section",{className:"rounded-xl border border-border-subtle bg-surface-secondary p-4 text-left",children:e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsx(y,{htmlFor:"workflow-name",children:"Workflow name"}),e.jsx(j,{id:"workflow-name",value:i,onChange:a=>{const c=a.currentTarget.value;m(c),l||n(x(c))},placeholder:"Untitled Workflow"})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx(y,{htmlFor:"workflow-id",children:"Workflow id"}),e.jsx(j,{id:"workflow-id",value:o,onChange:a=>{n(a.currentTarget.value),p(!0)},placeholder:"untitled-workflow","aria-invalid":r==="blank"&&!d}),r==="blank"&&!d?e.jsx("p",{className:"text-xs text-danger",children:"Workflow ids must be lowercase, 3 to 100 characters, start with a letter, and end with a letter or digit."}):null]})]})}):null,e.jsx(C,{variant:"primary",size:"lg",loading:v,disabled:v||!D,onClick:L,className:"w-full",children:"Start Building"})]})})}export{Q as Component};
