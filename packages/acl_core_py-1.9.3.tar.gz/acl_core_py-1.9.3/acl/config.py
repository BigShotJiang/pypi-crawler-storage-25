"""
ACL SDK Configuration

This module contains configuration constants and settings for the ACL Python SDK.
"""

from typing import Dict, Any, Optional


import os

DEFAULT_BASE_URL = os.getenv("ACL_BASE_URL", "http://backend.fridayaicore.in")
DEFAULT_TIMEOUT = 5
DEFAULT_MAX_RETRIES = 0
DEFAULT_RETRY_DELAY = 1.0

API_VERSION = "v1"
USER_AGENT = "acl-core-py/1.9.3"

# API Endpoints
ENDPOINTS = {
    "analyze": "/v1/analyze",
    "adaptive_window": f"/api/{API_VERSION}/adaptive/window",
    "health": f"/api/{API_VERSION}/health",
    "batch": f"/api/{API_VERSION}/adaptive/batch",
    "events_log": f"/api/{API_VERSION}/events/log",
}

# Headers
REQUEST_ID_HEADER = "X-ACL-Request-ID"
API_KEY_HEADER = "Authorization"

# Error mapping from HTTP status codes to SDK exceptions
HTTP_ERROR_MAP = {
    401: "ACLAuthError",
    403: "ACLPermissionError",
    429: "ACLRateLimitError",
}


class ACLConfiguration:
    """Configuration class for ACL SDK client."""

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout_ms: Optional[int] = None,
    ):
        self.api_key = api_key
        # Phase 2 — Production default (https://acl.fridayaicore.in)
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout_ms = timeout_ms or (DEFAULT_TIMEOUT * 1000)

    def get_base_url(self) -> str:
        """Get the base URL for ACL API."""
        return self.base_url

    def get_headers(self) -> Dict[str, str]:
        """Get default headers for ACL API requests."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
        }


# Default request parameters
DEFAULT_REQUEST_PARAMS = {
    "semantic_strictness": 0.23,
}

