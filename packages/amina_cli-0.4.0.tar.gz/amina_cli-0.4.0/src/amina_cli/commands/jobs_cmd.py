"""
Jobs command group for managing background jobs.

Commands:
- list: Show recent jobs
- status: Check status of one or more jobs
- wait: Wait for jobs to complete (for scripting/Claude Code)
- download: Download artifacts for a completed job
"""

import json
import re
import time
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(no_args_is_help=True)
console = Console()
err_console = Console(stderr=True)

TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})


def _persist_terminal_status(job_info: dict, status_result: dict) -> None:
    """Write authoritative terminal status back to local cache.

    Without this, `jobs list` keeps showing "submitted" for jobs that
    `status`/`wait`/`download` have already observed in a terminal state.

    Three guards:
    - Status must be in TERMINAL_STATUSES (completed/failed/cancelled).
    - The result must be marked terminal=True. Modal 404s come back as
      ``status="failed"`` but ``terminal=False`` (transient — Modal sometimes
      can't find a freshly-spawned call_id); writing those would create the
      same staleness this helper exists to fix, just inverted.
    - "cancelled" is sticky: once the user has cancelled a job, don't
      downgrade the local entry to "failed" just because Modal reports the
      cancelled call as a failure ("Function call was cancelled by user.").
    """
    status = status_result.get("status")
    if status not in TERMINAL_STATUSES:
        return
    if status_result.get("terminal") is False:
        return
    job_id = job_info.get("job_id", "")
    if not job_id:
        return
    if job_info.get("status") == "cancelled" and status == "failed":
        return
    from amina_cli.auth import update_job_status

    update_job_status(job_id, status)


_DURATION_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([smhdwy])\s*$", re.IGNORECASE)


def _parse_since(value: str) -> str:
    """Resolve a --since value into an ISO-8601 UTC timestamp the server's
    ``gte('created_at', ...)`` filter understands.

    Accepts:
      - shorthand durations: ``2h``, ``3d``, ``45m``, ``1w``, ``30s``, ``1y``,
        and fractional values like ``1.5h`` or ``0.5d`` → relative to now (UTC).
        Years use the conventional 365-day approximation; the use case is
        coarse "last year"-style filtering, not legal accounting.
      - ISO timestamps: ``2026-04-27T00:00:00Z``, ``2026-04-27`` →
        passed through (after normalising to ISO with timezone).

    Raises ``typer.BadParameter`` with a clear message on garbage input
    so the user gets actionable feedback instead of a 422 from the gateway.
    """
    from datetime import datetime, timedelta, timezone

    raw = (value or "").strip()
    if not raw:
        raise typer.BadParameter("--since cannot be empty")

    match = _DURATION_RE.match(raw)
    if match:
        n = float(match.group(1))
        unit = match.group(2).lower()
        delta = {
            "s": timedelta(seconds=n),
            "m": timedelta(minutes=n),
            "h": timedelta(hours=n),
            "d": timedelta(days=n),
            "w": timedelta(weeks=n),
            "y": timedelta(days=365 * n),  # approximate; coarse filtering only
        }[unit]
        return (datetime.now(timezone.utc) - delta).isoformat()

    # Try ISO. datetime.fromisoformat accepts both "2026-04-27" and full timestamps.
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as e:
        raise typer.BadParameter(
            f"--since must be a duration like '2h', '3d', '1w' or an ISO timestamp; got {raw!r} ({e})"
        )
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.isoformat()


def _filter_local_jobs(
    jobs: list[dict],
    *,
    statuses: Optional[list[str]] = None,
    tools: Optional[list[str]] = None,
    name_prefix: Optional[str] = None,
    since_iso: Optional[str] = None,
) -> list[dict]:
    """Apply the same filters as ``GET /list_jobs`` to a local-cache list.

    Used when ``--no-refresh`` is set or when the refresh fell back to
    cached data, so the agent gets consistent semantics either way.
    """
    out = jobs
    if statuses:
        s = set(statuses)
        out = [j for j in out if j.get("status") in s]
    if tools:
        t = set(tools)
        out = [j for j in out if j.get("tool_name") in t]
    if name_prefix:
        out = [j for j in out if (j.get("job_name") or "").startswith(name_prefix)]
    if since_iso:
        out = [j for j in out if (j.get("submitted_at") or "") >= since_iso]
    return out


def _resolve_job_status(job_info: dict) -> dict:
    """
    Resolve the current status of a job, handling both spawned and queued jobs.

    If call_id is present, polls Modal directly. If missing (queued job),
    checks the queue first and resolves call_id when available.

    Args:
        job_info: Full job info dict from local history

    Returns:
        Dict with status info (same shape as check_job_status_sync)
    """
    from amina_cli.client import check_job_status_sync, check_queued_job_status_sync
    from amina_cli.auth import update_job_info

    call_id = job_info.get("call_id", "")
    job_id = job_info.get("job_id", "")

    if call_id:
        # Normal path: job was spawned, poll Modal directly
        return check_job_status_sync(
            call_id=call_id,
            job_id=job_id,
            user_id=job_info.get("user_id", ""),
            tool_name=job_info.get("tool_name", ""),
            reserved_cost=job_info.get("reserved_cost", 0.0),
            compute_type=job_info.get("compute_type", "cpu"),
        )

    # Queued path: no call_id yet, check queue status
    queue_result = check_queued_job_status_sync(job_id)
    queue_status = queue_result.get("status", "")

    if queue_status in ("queued", "not_found"):
        return queue_result

    if queue_status == "failed":
        return queue_result

    # Job has been spawned (submitted/running/completed) — try to get call_id
    resolved_call_id = queue_result.get("call_id", "")
    if not resolved_call_id:
        # Race condition: status changed but call_id not yet written.
        # Treat as still-queued (non-terminal) so wait keeps polling.
        return {
            "status": "queued",
            "terminal": False,
            "message": "Job is being spawned",
        }

    # Persist call_id so future polls skip the queue check
    update_job_info(job_id, {"call_id": resolved_call_id})

    return check_job_status_sync(
        call_id=resolved_call_id,
        job_id=job_id,
        user_id=job_info.get("user_id", ""),
        tool_name=job_info.get("tool_name", ""),
        reserved_cost=job_info.get("reserved_cost", 0.0),
        compute_type=job_info.get("compute_type", "cpu"),
    )


@app.command("list")
def list_jobs(
    limit: int = typer.Option(
        20,
        "--limit",
        "-n",
        help="Maximum number of jobs to show",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
    no_refresh: bool = typer.Option(
        False,
        "--no-refresh",
        help="Skip the server refresh and render only the local cache",
    ),
    status_filter: Optional[str] = typer.Option(
        None,
        "--status",
        help="Comma-separated status values to keep (e.g. 'running,queued')",
    ),
    tool_filter: Optional[str] = typer.Option(
        None,
        "--tool",
        help="Comma-separated tool names to keep (e.g. 'esmfold,boltz2')",
    ),
    name_prefix: Optional[str] = typer.Option(
        None,
        "--name-prefix",
        help="Keep only jobs whose job_name starts with this prefix",
    ),
    since: Optional[str] = typer.Option(
        None,
        "--since",
        help="Keep only jobs created at/after this point. Accepts '2h', '3d', '1w' or an ISO timestamp.",
    ),
):
    """
    List recent jobs.

    By default this refreshes from the server so statuses are authoritative,
    then renders the local cache (which is updated in place). Filters are
    applied server-side when refreshing, locally otherwise — same semantics
    either way.

    If the gateway is unreachable, falls back to the local cache and prints a
    one-line warning to stderr (exit code stays 0). Pass --no-refresh to skip
    the network call entirely.

    Examples:
        amina jobs list
        amina jobs list --limit 50
        amina jobs list --json
        amina jobs list --no-refresh
        amina jobs list --status running,queued
        amina jobs list --tool esmfold --since 2h
        amina jobs list --name-prefix her2-r1
    """
    from amina_cli.auth import get_job_history, merge_server_jobs

    # Reject negative --limit explicitly: Python's negative-slice semantics
    # would silently drop rows from the end of the list otherwise.
    if limit < 0:
        raise typer.BadParameter("--limit must be non-negative")

    # Resolve --since once; raises typer.BadParameter on bad input.
    since_iso = _parse_since(since) if since else None
    statuses = [s.strip() for s in status_filter.split(",") if s.strip()] if status_filter else None
    tools = [t.strip() for t in tool_filter.split(",") if t.strip()] if tool_filter else None
    have_filter = any([statuses, tools, name_prefix, since_iso])

    truncation_warning: Optional[str] = None
    refresh_failed = False
    if not no_refresh:
        try:
            from amina_cli.client import (
                list_jobs_sync,
                AuthenticationError,
                ToolExecutionError,
            )

            # Fetch enough rows to fill the requested view; cap at server max.
            fetch_limit = max(limit, 100)
            server_response = list_jobs_sync(
                limit=fetch_limit,
                status=status_filter,
                tool=tool_filter,
                name_prefix=name_prefix,
                since=since_iso,
            )
            server_rows = server_response.get("jobs", [])
            total_unfiltered = server_response.get("total_unfiltered_count")
            merge_server_jobs(server_rows, total_unfiltered_count=total_unfiltered)

            # Truncation hint compares against the unfiltered total: if the
            # user has more CLI jobs server-side than we fetched, tell them.
            if total_unfiltered is not None and total_unfiltered > len(server_rows):
                hint_extra = "" if have_filter else " — refine with --status / --tool / --since"
                truncation_warning = f"showing {len(server_rows)} of {total_unfiltered} CLI jobs{hint_extra}"
        except AuthenticationError as auth_err:
            refresh_failed = True
            err_console.print(
                f"[yellow]warning:[/yellow] could not refresh from server: {auth_err}; showing cached data"
            )
        except ToolExecutionError as net_err:
            refresh_failed = True
            err_console.print(
                f"[yellow]warning:[/yellow] could not refresh from server: {net_err}; showing cached data"
            )
        except Exception as unexpected:
            # Defensive: never let refresh failure break list rendering.
            refresh_failed = True
            err_console.print(
                f"[yellow]warning:[/yellow] could not refresh from server: "
                f"{type(unexpected).__name__}: {unexpected}; showing cached data"
            )

    try:
        # Pull a wider slice of the cache when filters are active so we have
        # something to filter against. Without this, --status running on a
        # 20-row default could return zero rows even when there are matches
        # further back.
        cache_limit = 10_000 if have_filter else limit
        jobs = get_job_history(limit=cache_limit)
    except Exception:
        jobs = []

    # Apply filters locally when:
    #   - we skipped refresh, or
    #   - refresh failed (the server never saw our filters), or
    #   - filters are active (server pre-filtered, but the LOCAL CACHE may
    #     still hold older non-matching rows the renderer would otherwise
    #     show on top after merge).
    if no_refresh or refresh_failed or have_filter:
        jobs = _filter_local_jobs(
            jobs,
            statuses=statuses,
            tools=tools,
            name_prefix=name_prefix,
            since_iso=since_iso,
        )

    # Trim to the user's requested limit AFTER filtering.
    jobs = jobs[:limit]

    # JSON output runs BEFORE the empty-state branch so that an empty result
    # is `[]` (valid JSON) rather than a Rich-formatted "no jobs" string —
    # otherwise `amina jobs list --status nonexistent --json | jq` blows up.
    if json_output:
        # Use stdlib print so Rich's terminal-width wrapping doesn't insert
        # newlines inside string values (breaks `jq`/agent parsing for long
        # sequences in request_params).
        print(json.dumps(jobs, indent=2, default=str))
        return

    if not jobs:
        if have_filter:
            console.print("[dim]No jobs match the supplied filters.[/dim]")
        else:
            console.print("[dim]No jobs found. Submit jobs with --background flag.[/dim]")
        return

    table = Table(title="Recent Jobs")
    table.add_column("Job ID", style="cyan", no_wrap=True)
    table.add_column("Tool", style="green")
    table.add_column("Job Name", style="magenta")
    table.add_column("Status", style="yellow")
    table.add_column("Submitted", style="dim")

    for job in jobs:
        table.add_row(
            job.get("job_id", "")[:8] + "...",
            job.get("tool_name", "unknown"),
            job.get("job_name", ""),
            job.get("status", "unknown"),
            job.get("submitted_at", ""),
        )

    console.print(table)
    if truncation_warning:
        err_console.print(f"[dim]{truncation_warning}[/dim]")


@app.command("status")
def status(
    job_ids: list[str] = typer.Argument(
        ...,
        help="Job ID(s) to check status for",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (useful for scripting)",
    ),
):
    """
    Check status of one or more jobs.

    Accepts full or partial job IDs. Queries the server for current status.

    Examples:
        amina jobs status abc123
        amina jobs status abc123 def456 ghi789
        amina jobs status abc123 --json
    """
    from amina_cli.auth import get_job_info
    from amina_cli.client import ToolExecutionError

    results = []

    for job_id in job_ids:
        # Look up job info from local storage
        job_info = get_job_info(job_id)

        if not job_info:
            results.append(
                {
                    "job_id": job_id,
                    "status": "not_found",
                    "error": "Job not found in local history. Use full job ID.",
                }
            )
            continue

        # Query server for current status
        try:
            status_result = _resolve_job_status(job_info)
            _persist_terminal_status(job_info, status_result)
            results.append(
                {
                    "job_id": job_info.get("job_id", job_id),
                    "tool_name": job_info.get("tool_name", ""),
                    **status_result,
                }
            )
        except ToolExecutionError as e:
            results.append(
                {
                    "job_id": job_id,
                    "status": "error",
                    "error": str(e),
                }
            )

    if json_output:
        print(json.dumps(results, indent=2, default=str))
        return

    # Display as table
    for result in results:
        job_id = result.get("job_id", "")[:8]
        status_str = result.get("status", "unknown")
        tool_name = result.get("tool_name", "")

        if status_str == "running":
            console.print(f"[yellow]\u23f3[/yellow] {job_id}... ({tool_name}): [yellow]running[/yellow]")
        elif status_str == "completed":
            console.print(f"[green]\u2713[/green] {job_id}... ({tool_name}): [green]completed[/green]")
            # Display tool response data for completed jobs
            tool_result = result.get("result", {})
            if tool_result.get("data"):
                from amina_cli.commands.tools import get_tool
                from amina_cli.commands.tools.display import render_tool_output

                tool_metadata = get_tool(tool_name)
                render_tool_output(tool_result, tool_metadata)
        elif status_str == "failed":
            error = result.get("error", "Unknown error")
            console.print(f"[red]\u2717[/red] {job_id}... ({tool_name}): [red]failed[/red] - {error}")
        elif status_str == "not_found":
            console.print(f"[dim]?[/dim] {job_id}...: [dim]not found[/dim]")
        else:
            console.print(f"[dim]?[/dim] {job_id}... ({tool_name}): [dim]{status_str}[/dim]")


@app.command("wait")
def wait(
    job_ids: list[str] = typer.Argument(
        ...,
        help="Job ID(s) to wait for",
    ),
    output_json: Optional[Path] = typer.Option(
        None,
        "--output-json",
        "-o",
        help="Write results to JSON file when complete",
    ),
    poll_interval: int = typer.Option(
        10,
        "--poll-interval",
        help="Seconds between status checks",
    ),
    timeout: int = typer.Option(
        3600,
        "--timeout",
        "-t",
        help="Maximum seconds to wait (default: 1 hour)",
    ),
    no_poll_until_terminal: bool = typer.Option(
        False,
        "--no-poll-until-terminal",
        help=(
            "Old behaviour: resolve as soon as the server returns failed, even "
            "if the failure looks transient (Modal 404 mid-spawn, etc.). The "
            "default polls until each job is genuinely terminal or the timeout fires."
        ),
    ),
):
    """
    Wait for jobs to reach a terminal state.

    By default this polls until the server reports a *terminal* outcome \u2014 so
    transient signals like a Modal 404 during the queued\u2192running spawn race
    do not cause an early bail (which previously made agents abandon
    successful runs). Pass --no-poll-until-terminal to revert to the old
    "first failed wins" behaviour.

    Exit codes (machine-readable contract):
        0 \u2014 every requested job completed successfully
        2 \u2014 at least one job ended in a terminal failure or was cancelled
        3 \u2014 at least one job was still running / pending at timeout

    Examples:
        amina jobs wait abc123
        amina jobs wait abc123 def456 --output-json /tmp/results.json
        amina jobs wait abc123 --timeout 7200 --poll-interval 30
    """
    from amina_cli.auth import get_job_info
    from amina_cli.client import ToolExecutionError

    start_time = time.time()
    pending_jobs = set(job_ids)
    results: dict = {}

    console.print(f"Waiting for {len(job_ids)} job(s)...")

    while pending_jobs:
        elapsed = time.time() - start_time
        if elapsed > timeout:
            for job_id in pending_jobs:
                results[job_id] = {
                    "status": "timeout",
                    "terminal": False,
                    "error": "Timed out waiting for terminal state",
                }
            console.print(f"\n[yellow]Timeout after {timeout}s. {len(pending_jobs)} job(s) still pending.[/yellow]")
            break

        for job_id in list(pending_jobs):
            job_info = get_job_info(job_id)

            if not job_info:
                # Local history lookup failed \u2014 treat as terminal so we don't
                # spin forever on a typo'd job_id.
                results[job_id] = {
                    "status": "not_found",
                    "terminal": True,
                    "reason": "local_not_found",
                    "error": "Job not found in local history",
                }
                pending_jobs.discard(job_id)
                continue

            try:
                status_result = _resolve_job_status(job_info)
                _persist_terminal_status(job_info, status_result)

                status_str = status_result.get("status")
                is_terminal = status_result.get("terminal", False)

                if no_poll_until_terminal and status_str in ("completed", "failed"):
                    is_terminal = True
                    # Mirror the override into status_result so the summary
                    # counter (which keys off result["terminal"]) agrees.
                    status_result = {**status_result, "terminal": True}

                if not is_terminal:
                    continue

                results[job_id] = {
                    "job_id": job_info.get("job_id", job_id),
                    "tool_name": job_info.get("tool_name", ""),
                    **status_result,
                }
                pending_jobs.discard(job_id)

                if status_str == "completed":
                    console.print(f"[green]\u2713[/green] {job_id[:8]}... completed")
                    tool_result = status_result.get("result", {})
                    if tool_result.get("data"):
                        from amina_cli.commands.tools import get_tool
                        from amina_cli.commands.tools.display import render_tool_output

                        tool_metadata = get_tool(job_info.get("tool_name", ""))
                        render_tool_output(tool_result, tool_metadata)
                else:
                    reason = status_result.get("reason", "")
                    suffix = f" ({reason})" if reason else ""
                    console.print(f"[red]\u2717[/red] {job_id[:8]}... {status_str}{suffix}")

            except ToolExecutionError as e:
                # Network-level error talking to the gateway \u2014 treat as
                # terminal so wait doesn't loop forever on a broken setup.
                results[job_id] = {
                    "status": "error",
                    "terminal": True,
                    "reason": "network",
                    "error": str(e),
                }
                pending_jobs.discard(job_id)

        if pending_jobs:
            time.sleep(poll_interval)

    if output_json:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(results, indent=2, default=str))
        console.print(f"\n[dim]Results written to {output_json}[/dim]")

    completed = sum(1 for r in results.values() if r.get("status") == "completed")
    terminal_failed = sum(
        1
        for r in results.values()
        if r.get("status") in ("failed", "cancelled", "error", "not_found") and r.get("terminal", True)
    )
    timed_out = sum(1 for r in results.values() if r.get("status") == "timeout")
    console.print(f"\n{completed} completed, {terminal_failed} terminal failed, {timed_out} timed out")

    if timed_out > 0:
        raise typer.Exit(3)
    if terminal_failed > 0:
        raise typer.Exit(2)


@app.command("cancel")
def cancel(
    job_ids: list[str] = typer.Argument(
        ...,
        help="Job ID(s) to cancel",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """
    Cancel one or more queued or running jobs.

    Sends a cancellation request to the server. Credits are fully refunded.

    Examples:
        amina jobs cancel abc123
        amina jobs cancel abc123 def456
        amina jobs cancel abc123 --json
    """
    from amina_cli.auth import get_job_info, update_job_status
    from amina_cli.client import cancel_job_sync, ToolExecutionError

    results = []

    for job_id in job_ids:
        job_info = get_job_info(job_id)

        if not job_info:
            results.append({"job_id": job_id, "status": "not_found", "error": "Job not found in local history"})
            continue

        full_job_id = job_info.get("job_id", job_id)

        try:
            cancel_result = cancel_job_sync(full_job_id)
            status = cancel_result.get("status", "error")

            if status == "cancelled":
                update_job_status(full_job_id, "cancelled")

            results.append(
                {
                    "job_id": full_job_id,
                    "tool_name": job_info.get("tool_name", ""),
                    **cancel_result,
                }
            )
        except ToolExecutionError as e:
            results.append({"job_id": full_job_id, "status": "error", "error": str(e)})

    if json_output:
        print(json.dumps(results, indent=2, default=str))
        return

    for result in results:
        job_id_short = result.get("job_id", "")[:8]
        status_str = result.get("status", "error")
        tool_name = result.get("tool_name", "")
        label = f" ({tool_name})" if tool_name else ""

        if status_str == "cancelled":
            console.print(f"[green]\u2713[/green] {job_id_short}...{label}: [green]cancelled[/green]")
        elif status_str == "already_finished":
            console.print(f"[yellow]\u2717[/yellow] {job_id_short}...{label}: [yellow]already finished[/yellow]")
        elif status_str == "not_found":
            console.print(f"[dim]?[/dim] {job_id_short}...: [dim]not found[/dim]")
        else:
            error = result.get("error", "")
            console.print(f"[red]\u2717[/red] {job_id_short}...{label}: [red]{status_str}[/red] - {error}")


@app.command("download")
def download(
    job_id: str = typer.Argument(
        ...,
        help="Job ID to download artifacts from",
    ),
    output: Path = typer.Option(
        ...,
        "--output",
        "-o",
        help="Output directory for downloaded files",
    ),
):
    """
    Download artifacts for a completed job.

    Fetches output files from a completed job and saves them locally.

    Examples:
        amina jobs download abc123 -o ./results/
    """
    from amina_cli.auth import get_job_info
    from amina_cli.client import ToolExecutionError
    from amina_cli.storage import download_results, StorageError

    # Look up job info
    job_info = get_job_info(job_id)

    if not job_info:
        console.print(f"[red]Error:[/red] Job '{job_id}' not found in local history.")
        raise typer.Exit(1)

    # Check status
    try:
        status_result = _resolve_job_status(job_info)
        _persist_terminal_status(job_info, status_result)
    except ToolExecutionError as e:
        console.print(f"[red]Error checking job status:[/red] {e}")
        raise typer.Exit(1)

    if status_result.get("status") == "queued":
        console.print("[yellow]Job is still queued.[/yellow] Wait for completion first:")
        console.print(f"  amina jobs wait {job_id}")
        raise typer.Exit(1)

    if status_result.get("status") == "running":
        console.print("[yellow]Job is still running.[/yellow] Wait for completion first:")
        console.print(f"  amina jobs wait {job_id}")
        raise typer.Exit(1)

    if status_result.get("status") == "failed":
        console.print(f"[red]Job failed:[/red] {status_result.get('error', 'Unknown error')}")
        raise typer.Exit(1)

    if status_result.get("status") != "completed":
        console.print(f"[red]Unexpected job status:[/red] {status_result.get('status')}")
        raise typer.Exit(1)

    # Download results
    result = status_result.get("result", {})

    # Persist the structured response payload so it matches the on-disk layout
    # produced by `amina run <tool> -o <dir>` (response.json alongside artifacts).
    output.mkdir(parents=True, exist_ok=True)
    response_path = output / "response.json"
    response_path.write_text(json.dumps(result, indent=2, default=str))

    try:
        downloaded = download_results(result, output)
        if downloaded:
            console.print(f"[green]\u2713[/green] Downloaded {len(downloaded)} file(s) to {output}/")
            for path in downloaded:
                console.print(f"  - {path.name}")
            console.print(f"  - {response_path.name}")
            # Also display tool response data alongside files
            if result.get("data"):
                from amina_cli.commands.tools import get_tool
                from amina_cli.commands.tools.display import render_tool_output

                tool_metadata = get_tool(job_info.get("tool_name", ""))
                render_tool_output(result, tool_metadata)
        else:
            console.print(f"[green]\u2713[/green] Saved response to {response_path}")
            # Show tool response data even when there are no files
            if result.get("data"):
                from amina_cli.commands.tools import get_tool
                from amina_cli.commands.tools.display import render_tool_output

                tool_metadata = get_tool(job_info.get("tool_name", ""))
                render_tool_output(result, tool_metadata)
            else:
                console.print("[dim]No output files to download.[/dim]")
    except StorageError as e:
        # Show signed URLs as fallback
        signed_urls = result.get("signed_urls", {})
        if signed_urls:
            console.print(f"[yellow]Warning:[/yellow] Could not download automatically: {e}")
            console.print(f"[dim]Response saved to {response_path}[/dim]")
            console.print("\n[bold]Files available at:[/bold]")
            for file_type, url in signed_urls.items():
                if url:
                    console.print(f"  {file_type}: {url}")
        else:
            console.print(f"[red]Download failed:[/red] {e}")
            raise typer.Exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# RECONCILE: walk a campaign tree and refresh per-job state
# ═══════════════════════════════════════════════════════════════════════════════


def _find_submission_files(root: Path, recursive: bool) -> list[tuple[str, Path]]:
    """Walk ``root`` for ``submission.json`` files and extract job_id from each.

    Returns a list of ``(job_id, dir_containing_submission)`` tuples. Files
    that fail to parse or lack a ``job_id`` field are skipped silently — they
    weren't written by ``amina run --background``.
    """
    pattern = "**/submission.json" if recursive else "*/submission.json"
    found: list[tuple[str, Path]] = []
    for submission_path in sorted(root.glob(pattern)):
        try:
            data = json.loads(submission_path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        job_id = data.get("job_id")
        if not job_id:
            continue
        found.append((job_id, submission_path.parent))
    # Top-level submission.json (root/submission.json) when not recursive
    # is also worth picking up.
    if not recursive:
        top = root / "submission.json"
        if top.exists():
            try:
                data = json.loads(top.read_text())
                job_id = data.get("job_id")
                if job_id and not any(j == job_id for j, _ in found):
                    found.append((job_id, top.parent))
            except (OSError, json.JSONDecodeError):
                pass
    return found


@app.command("reconcile")
def reconcile(
    directory: Path = typer.Argument(
        ...,
        help="Directory to walk for submission.json files",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    recursive: bool = typer.Option(
        True,
        "--recurse/--no-recurse",
        help="Recurse into subdirectories (default) or only scan top-level",
    ),
    download: bool = typer.Option(
        True,
        "--download/--no-download",
        help="Download artifact files for newly-completed jobs (default: yes)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit a structured summary on stdout (machine-readable)",
    ),
):
    """
    Reconcile a campaign directory against the server.

    Walks ``directory`` (recursively by default) for ``submission.json``
    files, refreshes every found job's state from the server, and writes
    ``response.json`` next to any job that has reached a terminal state but
    doesn't yet have one. Artefacts are optionally downloaded for newly
    completed jobs.

    Idempotent: re-running on the same directory after every job has a
    response.json is a no-op (everything is reported as ``already_done``).

    Examples:
        amina jobs reconcile /tmp/campaign
        amina jobs reconcile /tmp/campaign --no-recurse
        amina jobs reconcile /tmp/campaign --no-download
        amina jobs reconcile /tmp/campaign --json
    """
    from amina_cli.auth import get_job_info, merge_server_jobs
    from amina_cli.client import (
        AuthenticationError,
        ToolExecutionError,
        list_jobs_sync,
    )
    from amina_cli.storage import StorageError, download_results

    submissions = _find_submission_files(directory, recursive=recursive)
    if not submissions:
        msg = f"No submission.json files found under {directory}"
        if json_output:
            print(json.dumps({"directory": str(directory), "summary": {"found": 0}, "jobs": []}))
        else:
            console.print(f"[dim]{msg}[/dim]")
        return

    # Refresh once so the local cache reflects everything the server knows
    # about. We swallow refresh failures so reconcile is still useful offline.
    fetch_limit = max(len(submissions), 100)
    try:
        server_response = list_jobs_sync(limit=min(fetch_limit, 5000))
        merge_server_jobs(
            server_response.get("jobs", []),
            total_unfiltered_count=server_response.get("total_unfiltered_count"),
        )
    except (AuthenticationError, ToolExecutionError) as refresh_err:
        err_console.print(
            f"[yellow]warning:[/yellow] could not refresh from server: {refresh_err}; "
            f"reconciling against local cache only"
        )

    summary = {
        "found": len(submissions),
        "already_done": 0,
        "newly_completed": 0,
        "newly_failed": 0,
        "still_running": 0,
        "missing_locally": 0,
        "download_failed": 0,
    }
    per_job: list[dict] = []

    for job_id, dir_path in submissions:
        response_path = dir_path / "response.json"
        entry: dict = {"job_id": job_id, "dir": str(dir_path)}

        if response_path.exists():
            summary["already_done"] += 1
            entry["action"] = "skipped_response_json_exists"
            per_job.append(entry)
            continue

        job_info = get_job_info(job_id)
        if not job_info:
            summary["missing_locally"] += 1
            entry["action"] = "missing_locally"
            per_job.append(entry)
            continue

        local_status = job_info.get("status", "")
        if local_status not in TERMINAL_STATUSES:
            # Local cache (now fresh) says this job hasn't terminated yet.
            # Don't waste a per-job HTTP roundtrip just to confirm.
            summary["still_running"] += 1
            entry["action"] = "still_running"
            entry["status"] = local_status
            per_job.append(entry)
            continue

        # Terminal: fetch the full payload (signed_urls, output_files) so the
        # response.json we write matches the shape `amina jobs download`
        # produces.
        try:
            status_result = _resolve_job_status(job_info)
        except ToolExecutionError as fetch_err:
            entry["action"] = "fetch_failed"
            entry["error"] = str(fetch_err)
            summary["missing_locally"] += 1
            per_job.append(entry)
            continue
        _persist_terminal_status(job_info, status_result)

        # Build the response payload. For completed jobs the gateway hands us
        # a full `result` dict (output_files, signed_urls, data, ...). For
        # failed/cancelled jobs Modal often returns only an error string with
        # no `result` — synthesise a small object so the agent has SOMETHING
        # parseable to reason about instead of an empty {}.
        result_payload = status_result.get("result") or {}
        if not result_payload and status_result.get("status") != "completed":
            result_payload = {
                "status": "error",
                "error": status_result.get("error", "Job did not produce a result"),
            }
            if status_result.get("reason"):
                result_payload["reason"] = status_result["reason"]
        response_path.write_text(json.dumps(result_payload, indent=2, default=str))

        if status_result.get("status") == "completed":
            summary["newly_completed"] += 1
            entry["status"] = "completed"
            entry["action"] = "wrote_response_json"
            if download:
                try:
                    downloaded = download_results(result_payload, dir_path)
                    entry["downloaded_files"] = [p.name for p in downloaded]
                except StorageError as dl_err:
                    summary["download_failed"] += 1
                    entry["download_error"] = str(dl_err)
        else:
            summary["newly_failed"] += 1
            entry["status"] = status_result.get("status", "failed")
            entry["action"] = "wrote_response_json"
            if status_result.get("reason"):
                entry["reason"] = status_result["reason"]

        per_job.append(entry)

    if json_output:
        print(
            json.dumps(
                {
                    "directory": str(directory),
                    "summary": summary,
                    "jobs": per_job,
                },
                indent=2,
                default=str,
            )
        )
        return

    console.print(f"\n[bold]Reconciled {summary['found']} job(s) in {directory}[/bold]")
    console.print(f"  [dim]{summary['already_done']:>4} already had response.json[/dim]")
    console.print(f"  [green]{summary['newly_completed']:>4} completed (new response.json)[/green]")
    if summary["newly_failed"]:
        console.print(f"  [red]{summary['newly_failed']:>4} failed (new response.json)[/red]")
    if summary["still_running"]:
        console.print(f"  [yellow]{summary['still_running']:>4} still running[/yellow]")
    if summary["missing_locally"]:
        console.print(f"  [dim]{summary['missing_locally']:>4} missing from local cache[/dim]")
    if summary["download_failed"]:
        console.print(
            f"  [yellow]{summary['download_failed']:>4} downloads failed (response.json saved; rerun later)[/yellow]"
        )
