"""
Doccard loader for tool documentation.

Loads per-tool YAML doccards from {category}/docs/{tool}.yaml,
validates required fields, caches results, and falls back gracefully
when files are missing or malformed.

CONSTRAINT: This module must have zero imports from the tools package
to avoid circular imports (tool .py files import from here).
"""

import warnings
from pathlib import Path
from typing import Optional

import yaml

# In-memory cache: (category, name) -> parsed dict or None
_doccard_cache: dict[tuple[str, str], Optional[dict]] = {}

REQUIRED_FIELDS = {
    "name",
    "display_name",
    "category",
    "status",
    "modal_app_name",
    "modal_function_name",
    "description",
}


def _resolve_doccard_path(category: str, name: str) -> Path:
    """Resolve the filesystem path for a doccard YAML file."""
    tools_dir = Path(__file__).parent
    return tools_dir / category / "docs" / f"{name}.yaml"


def load_doccard(category: str, name: str) -> Optional[dict]:
    """
    Load a tool doccard from YAML.

    Args:
        category: Tool category (e.g., "folding", "analysis")
        name: Tool name (e.g., "boltz2", "sasa")

    Returns:
        Parsed doccard dict if valid, None if file missing/malformed/invalid.
        Result is cached — subsequent calls return the same object.
    """
    cache_key = (category, name)
    if cache_key in _doccard_cache:
        return _doccard_cache[cache_key]

    path = _resolve_doccard_path(category, name)

    if not path.exists():
        _doccard_cache[cache_key] = None
        return None

    try:
        with open(path) as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        warnings.warn(f"Malformed doccard YAML at {path}: {e}", stacklevel=2)
        _doccard_cache[cache_key] = None
        return None

    if not isinstance(data, dict):
        warnings.warn(f"Doccard at {path} is not a YAML mapping", stacklevel=2)
        _doccard_cache[cache_key] = None
        return None

    # Validate required fields
    missing = REQUIRED_FIELDS - set(data.keys())
    if missing:
        warnings.warn(
            f"Doccard at {path} missing required fields: {', '.join(sorted(missing))}",
            stacklevel=2,
        )
        _doccard_cache[cache_key] = None
        return None

    _doccard_cache[cache_key] = data
    return data


def clear_cache() -> None:
    """Clear the doccard cache. Useful for testing."""
    _doccard_cache.clear()
