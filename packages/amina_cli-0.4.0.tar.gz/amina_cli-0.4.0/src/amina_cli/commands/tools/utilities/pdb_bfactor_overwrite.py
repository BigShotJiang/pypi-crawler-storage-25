"""PDB B-factor Overwrite tool for the Amina CLI."""

import typer
import json
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/pdb_bfactor_overwrite.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("utilities", "pdb_bfactor_overwrite")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("pdb-bfactor-overwrite")
    def run_pdb_bfactor_overwrite(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file to modify",
            exists=True,
        ),
        bfactor_json: Path = typer.Option(
            ...,
            "--bfactor-json",
            "-b",
            help="JSON file with B-factor mappings (e.g., {'A:10': 85.5, 'A:11': 92.3})",
            exists=True,
        ),
        description: str = typer.Option(
            "modified",
            "--description",
            "-d",
            help="Description suffix for output filename (e.g., 'plddt', 'confidence')",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools pdb-bfactor-overwrite"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()

        # Parse B-factor JSON file
        try:
            bfactor_text = bfactor_json.read_text()
            bfactor_dict = json.loads(bfactor_text)

            if not isinstance(bfactor_dict, dict):
                console.print("[red]Error:[/red] B-factor JSON must be a dictionary")
                raise typer.Exit(1)

            if not bfactor_dict:
                console.print("[red]Error:[/red] B-factor dictionary cannot be empty")
                raise typer.Exit(1)

            # Validate all values are numeric
            for key, value in bfactor_dict.items():
                if not isinstance(value, (int, float)):
                    console.print(
                        f"[red]Error:[/red] B-factor value for '{key}' must be numeric, got {type(value).__name__}"
                    )
                    raise typer.Exit(1)

        except json.JSONDecodeError as e:
            console.print(f"[red]Error:[/red] Invalid JSON in B-factor file: {e}")
            raise typer.Exit(1)

        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,  # Include extension for output naming
            "bfactor_dict": bfactor_dict,
            "bfactor_description": description,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("pdb-bfactor-overwrite", params, output, background=background)
