"""Active Site Verifier tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional, List
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/activesite_verifier.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("utilities", "activesite_verifier")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("activesite-verifier")
    def run_activesite_verifier(
        sequence: Optional[str] = typer.Option(
            None,
            "--sequence",
            "-s",
            help="Direct protein sequence (standard amino acid letters A-Y)",
        ),
        fasta: Optional[Path] = typer.Option(
            None,
            "--fasta",
            "-f",
            help="Path to FASTA file containing protein sequence",
            exists=True,
        ),
        pdb: Optional[Path] = typer.Option(
            None,
            "--pdb",
            "-p",
            help="Path to PDB file containing protein structure",
            exists=True,
        ),
        active_sites: List[str] = typer.Option(
            ...,
            "--active-site",
            "-a",
            help="Active site position to verify (can be specified multiple times). "
            "Formats: 'HIS57', 'H57', 'A:CYS30', 'CYS30:A', 'C:30'",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (verification results saved as JSON) (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for tracking (default: auto-generated)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools activesite-verifier"""
        # Validate that exactly one input source is provided
        input_count = sum([sequence is not None, fasta is not None, pdb is not None])
        if input_count == 0:
            console.print("[red]Error:[/red] Must provide one of: --sequence, --fasta, or --pdb")
            raise typer.Exit(1)
        if input_count > 1:
            console.print("[red]Error:[/red] Only one input source allowed. Provide --sequence, --fasta, OR --pdb")
            raise typer.Exit(1)

        # Validate active sites are provided
        if not active_sites:
            console.print("[red]Error:[/red] At least one --active-site / -a is required")
            raise typer.Exit(1)

        # Build params dict
        params = {
            "active_site_list": list(active_sites),
        }

        # Add the input source
        if sequence:
            params["sequence"] = sequence
        elif fasta:
            params["fasta_content"] = fasta.read_text()
            params["fasta_filename"] = fasta.name
        elif pdb:
            params["pdb_content"] = pdb.read_text()
            params["pdb_filename"] = pdb.name

        if job_name:
            params["job_name"] = job_name

        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        run_tool_with_progress("activesite-verifier", params, output, background=background)
