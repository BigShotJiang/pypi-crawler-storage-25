"""Open Babel file converter tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional, List
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/obabel_convert.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("utilities", "obabel_convert")

console = Console()

# Supported output formats
SUPPORTED_FORMATS = [
    "sdf",
    "mol",
    "mol2",
    "pdb",
    "xyz",
    "cif",
    "mmcif",
    "pdbqt",
    "smiles",
    "smi",
    "can",
    "inchi",
    "inchikey",
]


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("obabel-convert")
    def run_obabel_convert(
        input_files: List[Path] = typer.Option(
            ...,
            "--input",
            "-i",
            help="Input molecular file(s) to convert (can specify multiple)",
            exists=True,
        ),
        convert_to: str = typer.Option(
            ...,
            "--format",
            "-f",
            help=f"Target format ({', '.join(SUPPORTED_FORMATS)})",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for converted files (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools obabel-convert"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate format
        format_lower = convert_to.lower()
        if format_lower not in SUPPORTED_FORMATS:
            console.print(
                f"[red]Error:[/red] Unsupported format '{convert_to}'. Supported: {', '.join(SUPPORTED_FORMATS)}"
            )
            raise typer.Exit(1)

        # Read file contents
        file_contents = []
        filenames = []
        for input_file in input_files:
            try:
                content = input_file.read_text()
                file_contents.append(content)
                filenames.append(input_file.name)
            except Exception as e:
                console.print(f"[red]Error:[/red] Failed to read {input_file}: {e}")
                raise typer.Exit(1)

        # Build params
        params = {
            "file_contents": file_contents,
            "filenames": filenames,
            "convert_to": format_lower,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("obabel-convert", params, output, background=background)
