"""Molecule Size Calculator tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/mol_size_calculator.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("utilities", "mol_size_calculator")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("mol-size-calculator")
    def run_mol_size_calculator(
        input_file: Path = typer.Option(
            ...,
            "--input",
            "-i",
            help="Path to molecule file (PDB, SDF, MOL, XYZ)",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools mol-size-calculator"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read file content
        mol_content = input_file.read_text()

        params = {
            "mol_content": mol_content,
            "mol_filename": input_file.name,  # e.g., "ligand.sdf"
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("mol-size-calculator", params, output, background=background)
