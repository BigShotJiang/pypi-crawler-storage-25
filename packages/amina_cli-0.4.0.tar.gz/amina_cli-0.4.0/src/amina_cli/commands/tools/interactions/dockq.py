"""DockQ complex quality assessment tool for the Amina CLI."""

import typer
import json
from pathlib import Path
from typing import Optional, List
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/dockq.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "dockq")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("dockq")
    def run_dockq(
        model: Path = typer.Option(
            ...,
            "--model",
            "-m",
            help="Path to model/predicted complex structure (PDB file)",
            exists=True,
        ),
        reference: Path = typer.Option(
            ...,
            "--reference",
            "-r",
            help="Path to native/reference complex structure (PDB file)",
            exists=True,
        ),
        interface_pairs: Optional[str] = typer.Option(
            None,
            "--interfaces",
            "-i",
            help="Specific chain pairs to evaluate (e.g., 'A:B,A:C' for interfaces A-B and A-C)",
        ),
        chain_mapping: Optional[str] = typer.Option(
            None,
            "--chain-mapping",
            "-c",
            help="Chain mapping from native to model (e.g., 'A:A,B:X' maps native A to model A, native B to model X)",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for tracking (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools dockq"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read file contents
        model_content = model.read_text()
        reference_content = reference.read_text()
        console.print(f"Read model structure from {model}")
        console.print(f"Read reference structure from {reference}")

        # Build params
        params = {
            "model_pdb_content": model_content,
            "model_pdb_filename": model.stem,
            "reference_pdb_content": reference_content,
            "reference_pdb_filename": reference.stem,
        }

        # Parse interface pairs: "A:B,A:C" -> [["A","B"], ["A","C"]]
        if interface_pairs:
            parsed_pairs = []
            for pair in interface_pairs.split(","):
                pair = pair.strip()
                if ":" not in pair:
                    console.print(
                        f"[red]Error:[/red] Invalid interface pair format '{pair}'. Use 'CHAIN1:CHAIN2' (e.g., 'A:B')"
                    )
                    raise typer.Exit(1)
                chains = pair.split(":")
                if len(chains) != 2:
                    console.print(
                        f"[red]Error:[/red] Invalid interface pair '{pair}'. Expected 'CHAIN1:CHAIN2' format."
                    )
                    raise typer.Exit(1)
                parsed_pairs.append([chains[0].strip().upper(), chains[1].strip().upper()])
            params["interface_pairs"] = parsed_pairs
            console.print(f"Evaluating interfaces: {parsed_pairs}")

        # Parse chain mapping: "A:A,B:X" -> {"A": "A", "B": "X"}
        if chain_mapping:
            mapping = {}
            for pair in chain_mapping.split(","):
                pair = pair.strip()
                if ":" not in pair:
                    console.print(
                        f"[red]Error:[/red] Invalid chain mapping '{pair}'. Use 'NATIVE:MODEL' (e.g., 'A:A' or 'B:X')"
                    )
                    raise typer.Exit(1)
                chains = pair.split(":")
                if len(chains) != 2:
                    console.print(f"[red]Error:[/red] Invalid chain mapping '{pair}'. Expected 'NATIVE:MODEL' format.")
                    raise typer.Exit(1)
                mapping[chains[0].strip().upper()] = chains[1].strip().upper()
            params["chain_mapping"] = mapping
            console.print(f"Using chain mapping: {mapping}")

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("dockq", params, output, background=background)
