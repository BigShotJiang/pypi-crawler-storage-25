"""LMNgly N-linked glycosylation prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/lmngly.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "lmngly")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("lmngly")
    def run_lmngly(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB structure file",
            exists=True,
        ),
        threshold: float = typer.Option(
            0.5,
            "--threshold",
            "-t",
            help="Prediction threshold (0.0-1.0, higher = more stringent)",
            min=0.0,
            max=1.0,
        ),
        ensemble_method: str = typer.Option(
            "average",
            "--ensemble-method",
            "-e",
            help="Ensemble method: 'average', 'max', or 'weighted'",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools lmngly"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate ensemble method
        valid_methods = {"average", "max", "weighted"}
        if ensemble_method not in valid_methods:
            console.print(
                f"[red]Error:[/red] Invalid ensemble method '{ensemble_method}'. "
                f"Valid options: {', '.join(sorted(valid_methods))}"
            )
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()

        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,  # e.g., "1A2J.pdb"
            "threshold": threshold,
            "ensemble_method": ensemble_method,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("lmngly", params, output, background=background)
