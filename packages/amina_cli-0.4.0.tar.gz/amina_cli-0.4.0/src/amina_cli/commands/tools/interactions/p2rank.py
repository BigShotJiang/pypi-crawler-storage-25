"""P2Rank binding site prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/p2rank.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "p2rank")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("p2rank")
    def run_p2rank(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools p2rank"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read PDB content
        pdb_content = pdb.read_text()
        console.print(f"Read structure from {pdb}")

        # Build params - use pdb_content for CLI mode
        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,
        }

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress("p2rank", params, output, background=background)
