"""PeSTo binding interface prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/pesto.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "pesto")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("pesto")
    def run_pesto(
        # Input options
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to input PDB file",
            exists=True,
        ),
        # PeSTo parameters
        model_version: str = typer.Option(
            "i_v4_1",
            "--model-version",
            "-m",
            help="Model version (i_v3_0, i_v3_1, i_v4_0, i_v4_1)",
        ),
        binding_threshold: float = typer.Option(
            0.5,
            "--threshold",
            "-t",
            help="Probability threshold for classifying binding residues (0-1)",
            min=0.0,
            max=1.0,
        ),
        save_interfaces: bool = typer.Option(
            True,
            "--save-interfaces/--no-save-interfaces",
            help="Save separate PDB files per interface type",
        ),
        # Standard options
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools pesto"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate model version
        valid_versions = ["i_v3_0", "i_v3_1", "i_v4_0", "i_v4_1"]
        if model_version not in valid_versions:
            console.print(f"[red]Error:[/red] Invalid model version. Choose from: {', '.join(valid_versions)}")
            raise typer.Exit(1)

        # Read PDB content (CLI mode sends content, not path)
        pdb_content = pdb.read_text()

        # Build params
        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,
            "model_version": model_version,
            "binding_threshold": binding_threshold,
            "save_individual_interfaces": save_interfaces,
        }

        if job_name:
            params["job_name"] = job_name

        console.print(f"Input: {pdb.name}")
        console.print(f"Model: {model_version}, Threshold: {binding_threshold}")

        # Execute
        run_tool_with_progress("pesto", params, output, background=background)
