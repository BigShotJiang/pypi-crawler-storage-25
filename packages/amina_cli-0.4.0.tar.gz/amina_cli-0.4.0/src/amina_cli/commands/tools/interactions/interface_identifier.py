"""Interface Identifier tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/interface_identifier.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "interface_identifier")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("interface-identifier")
    def run_interface_identifier(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to protein complex structure (PDB or CIF file with multiple chains)",
            exists=True,
        ),
        distance_cutoff: float = typer.Option(
            8.0,
            "--distance",
            "-d",
            help="Distance cutoff in Angstroms for interface detection (default: 8.0)",
            min=3.0,
            max=15.0,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for tracking (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools interface-identifier"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read file content
        pdb_content = pdb.read_text()
        console.print(f"Read structure from {pdb} ({len(pdb_content)} bytes)")

        # Build params
        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,
            "distance_cutoff": distance_cutoff,
        }

        if job_name:
            params["job_name"] = job_name

        console.print(f"Distance cutoff: {distance_cutoff}Å")

        run_tool_with_progress("interface-identifier", params, output, background=background)
