"""Glycosylation Ensemble prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/glycosylation_ensemble.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("interactions", "glycosylation_ensemble")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("glycosylation-ensemble")
    def run_glycosylation_ensemble(
        # Input option
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file for glycosylation analysis",
            exists=True,
        ),
        # N-linked method options
        emngly_threshold: float = typer.Option(
            0.5,
            "--emngly-threshold",
            help="EMNgly prediction threshold (0.0-1.0)",
            min=0.0,
            max=1.0,
        ),
        lmngly_threshold: float = typer.Option(
            0.5,
            "--lmngly-threshold",
            help="LMNglyPred prediction threshold (0.0-1.0)",
            min=0.0,
            max=1.0,
        ),
        lmngly_ensemble_method: str = typer.Option(
            "average",
            "--lmngly-ensemble-method",
            help="LMNglyPred ensemble method: average or voting",
        ),
        # O-linked method options
        isoglyp_analysis_mode: str = typer.Option(
            "comprehensive",
            "--isoglyp-analysis-mode",
            help="ISOGlyP analysis mode: comprehensive, initiating_only, fill_in_only, high_confidence",
        ),
        isoglyp_context_window: str = typer.Option(
            "standard",
            "--isoglyp-context-window",
            help="ISOGlyP context window: minimal, standard, focused, extended",
        ),
        isoglyp_threshold: float = typer.Option(
            0.7,
            "--isoglyp-threshold",
            help="ISOGlyP prediction threshold (0.0-1.0)",
            min=0.0,
            max=1.0,
        ),
        # B-factor annotation
        create_bfactor_pdb: bool = typer.Option(
            True,
            "--create-bfactor-pdb/--no-bfactor-pdb",
            help="Create B-factor annotated PDB with glycosylation site scores",
        ),
        # Output options
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools glycosylation-ensemble"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()

        # Build params dict
        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,
            # N-linked method configurations
            "emngly_threshold": emngly_threshold,
            "lmngly_threshold": lmngly_threshold,
            "lmngly_ensemble_method": lmngly_ensemble_method,
            # O-linked method configuration
            "isoglyp_analysis_mode": isoglyp_analysis_mode,
            "isoglyp_context_window": isoglyp_context_window,
            "isoglyp_threshold": isoglyp_threshold,
            # B-factor annotation
            "create_bfactor_pdb": create_bfactor_pdb,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("glycosylation-ensemble", params, output, background=background)
