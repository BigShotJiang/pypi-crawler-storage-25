"""ESM-1v variant effect prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/esm1v.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("properties", "esm1v")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("esm1v")
    def run_esm1v(
        mode: str = typer.Option(
            ...,
            "--mode",
            "-m",
            help="Scoring mode: single, batch, or dms (deep mutational scan)",
        ),
        sequence: Optional[str] = typer.Option(
            None,
            "--sequence",
            "-s",
            help="Protein sequence (amino acid letters, max 1022 residues)",
        ),
        fasta: Optional[Path] = typer.Option(
            None,
            "--fasta",
            "-f",
            help="Path to FASTA file containing the protein sequence",
            exists=True,
        ),
        mutations: Optional[str] = typer.Option(
            None,
            "--mutations",
            help="Comma-separated mutations in XposY format, e.g. 'A56L,D78G'",
        ),
        mutations_csv: Optional[Path] = typer.Option(
            None,
            "--mutations-csv",
            help="Path to CSV file with mutations (column: mutation)",
            exists=True,
        ),
        num_models: int = typer.Option(
            5,
            "--num-models",
            "-n",
            help="Number of ESM-1v ensemble checkpoints (1-5)",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools esm1v"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate mode
        valid_modes = ["single", "batch", "dms"]
        if mode.lower() not in valid_modes:
            console.print(f"[red]Error:[/red] Invalid mode '{mode}'. Choose from: {', '.join(valid_modes)}")
            raise typer.Exit(1)
        mode = mode.lower()

        # Validate num_models
        if num_models < 1 or num_models > 5:
            console.print("[red]Error:[/red] --num-models must be between 1 and 5")
            raise typer.Exit(1)

        # Validate sequence input (exactly one)
        if sequence is None and fasta is None:
            console.print("[red]Error:[/red] Provide --sequence or --fasta")
            raise typer.Exit(1)
        if sequence is not None and fasta is not None:
            console.print("[red]Error:[/red] Provide only one of --sequence or --fasta")
            raise typer.Exit(1)

        # Validate mutation input based on mode
        if mode in ("single", "batch"):
            if mutations is None and mutations_csv is None:
                console.print(f"[red]Error:[/red] Mode '{mode}' requires --mutations or --mutations-csv")
                raise typer.Exit(1)
            if mutations is not None and mutations_csv is not None:
                console.print("[red]Error:[/red] Provide only one of --mutations or --mutations-csv")
                raise typer.Exit(1)
        elif mode == "dms":
            if mutations is not None or mutations_csv is not None:
                console.print("[red]Error:[/red] Mode 'dms' does not accept mutations input")
                raise typer.Exit(1)

        # Build params
        params = {
            "mode": mode,
            "num_models": num_models,
        }

        # Sequence input
        if sequence:
            params["sequence"] = sequence.upper()
            console.print(f"Sequence: {len(sequence)} residues")
        elif fasta:
            fasta_content = fasta.read_text()
            if not fasta_content.strip().startswith(">"):
                console.print("[red]Error:[/red] File does not appear to be in FASTA format")
                raise typer.Exit(1)
            params["fasta_content"] = fasta_content
            console.print(f"Read sequence from {fasta}")

        # Mutation input
        if mutations:
            params["mutations"] = mutations
            num_muts = len([m for m in mutations.split(",") if m.strip()])
            console.print(f"Mutations: {num_muts} specified")
        elif mutations_csv:
            params["mutations_csv_content"] = mutations_csv.read_text()
            console.print(f"Read mutations from {mutations_csv}")

        if job_name:
            params["job_name"] = job_name

        console.print(f"Mode: {mode} | Ensemble: {num_models} model(s)")

        # Execute
        run_tool_with_progress(METADATA["name"], params, output, background=background)
