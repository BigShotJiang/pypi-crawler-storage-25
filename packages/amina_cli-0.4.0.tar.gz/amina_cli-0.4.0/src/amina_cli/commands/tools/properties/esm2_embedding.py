"""ESM2 embedding extraction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/esm2_embedding.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("properties", "esm2_embedding")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("esm2-embedding")
    def run_esm2_embedding(
        fasta: Path = typer.Option(
            ...,
            "--fasta",
            "-f",
            help="Path to FASTA file containing protein sequences",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        esm_variant: str = typer.Option(
            "650M",
            "--model",
            "-m",
            help="ESM2 model variant: 650M (best), 150M, 35M, or 8M (fastest)",
        ),
        batch_size: int = typer.Option(
            8,
            "--batch-size",
            "-b",
            help="Batch size for processing (1-32)",
        ),
        no_tsne: bool = typer.Option(
            False,
            "--no-tsne",
            help="Skip t-SNE visualization generation",
        ),
        no_cluster: bool = typer.Option(
            False,
            "--no-cluster",
            help="Disable HDBSCAN clustering (clustering is ON by default)",
        ),
        cluster_min_size: Optional[int] = typer.Option(
            None,
            "--cluster-min-size",
            help="Minimum cluster size (auto-tuned via DBCV if not specified)",
        ),
        cluster_min_samples: Optional[int] = typer.Option(
            None,
            "--cluster-min-samples",
            help="Min samples for density estimation (auto-tuned if not specified)",
        ),
        embedding_mode: str = typer.Option(
            "sequence",
            "--mode",
            "-M",
            help="Embedding mode: 'sequence' (default) for mean-pooled embeddings, 'residue' for per-residue embeddings",
        ),
        include_special_tokens: bool = typer.Option(
            False,
            "--include-special-tokens",
            help="Include BOS/EOS tokens in residue embeddings (residue mode only)",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools esm2-embedding"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate ESM variant
        valid_variants = ["650M", "150M", "35M", "8M"]
        if esm_variant.upper() not in valid_variants:
            console.print(
                f"[red]Error:[/red] Invalid model variant '{esm_variant}'. Choose from: {', '.join(valid_variants)}"
            )
            raise typer.Exit(1)

        # Validate batch size
        if batch_size < 1 or batch_size > 32:
            console.print("[red]Error:[/red] Batch size must be between 1 and 32")
            raise typer.Exit(1)

        # Validate embedding mode
        valid_modes = ["sequence", "residue"]
        if embedding_mode.lower() not in valid_modes:
            console.print(f"[red]Error:[/red] Invalid mode '{embedding_mode}'. Choose from: {', '.join(valid_modes)}")
            raise typer.Exit(1)
        embedding_mode = embedding_mode.lower()

        # Validate mode-specific options
        if embedding_mode == "sequence" and include_special_tokens:
            console.print("[red]Error:[/red] --include-special-tokens only applies to residue mode")
            raise typer.Exit(1)

        if embedding_mode == "residue":
            if not no_tsne:
                console.print("[yellow]Note:[/yellow] t-SNE visualization is not available in residue mode (skipping)")
                no_tsne = True
            if not no_cluster:
                console.print("[yellow]Note:[/yellow] Clustering is not available in residue mode (skipping)")
                no_cluster = True

        # Read FASTA content
        fasta_content = fasta.read_text()
        if not fasta_content.strip().startswith(">"):
            console.print("[red]Error:[/red] File does not appear to be in FASTA format")
            raise typer.Exit(1)

        # Count sequences for display
        num_sequences = fasta_content.count(">")
        console.print(f"Read {num_sequences} sequence(s) from {fasta}")

        # Build params
        params = {
            "fasta_content": fasta_content,
            "fasta_filename": fasta.name,
            "esm_variant": esm_variant.upper(),
            "batch_size": batch_size,
            "generate_tsne": not no_tsne,
            "cluster_by_embeddings": not no_cluster,
            "cluster_min_size": cluster_min_size,
            "cluster_min_samples": cluster_min_samples,
            "embedding_mode": embedding_mode,
            "include_special_tokens": include_special_tokens,
        }

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress(METADATA["name"], params, output, background=background)
