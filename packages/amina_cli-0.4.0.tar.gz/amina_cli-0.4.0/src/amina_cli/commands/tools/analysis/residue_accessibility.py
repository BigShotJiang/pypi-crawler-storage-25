"""Residue Accessibility analysis tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/residue_accessibility.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("analysis", "residue_accessibility")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("residue-accessibility")
    def run_residue_accessibility(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file containing protein structure",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        residues: Optional[str] = typer.Option(
            None,
            "--residues",
            "-r",
            help="Residues to score in CHAIN:RESNUM format (e.g., 'A:42,A:43,B:10'). "
            "If omitted, all surface-exposed residues are scored.",
        ),
        rsa_threshold: float = typer.Option(
            0.20,
            "--rsa-threshold",
            help="RSA cutoff for the exposure gate (0.0-1.0). Residues below this are excluded.",
        ),
        n_rays: int = typer.Option(
            200,
            "--n-rays",
            help="Number of hemisphere rays per residue for visibility scoring (10-1000).",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools residue-accessibility"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate residue format if provided
        if residues:
            for token in residues.split(","):
                token = token.strip()
                if ":" not in token:
                    console.print(
                        f"[red]Error:[/red] Invalid residue format '{token}'. Expected CHAIN:RESNUM (e.g., 'A:42')."
                    )
                    raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()
        console.print(f"Read PDB file: {pdb.name}")

        # Build params dict matching worker's expected fields
        params = {
            "pdb_content": pdb_content,
            "rsa_threshold": rsa_threshold,
            "n_rays": n_rays,
        }

        if residues:
            params["residues"] = residues

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress("residue_accessibility", params, output, background=background)
