"""Structure analysis tools."""
