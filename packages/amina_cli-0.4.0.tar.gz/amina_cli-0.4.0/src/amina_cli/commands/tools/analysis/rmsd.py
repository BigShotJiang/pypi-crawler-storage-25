"""RMSD Analysis tool for the Amina CLI."""

import json
import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/rmsd.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("analysis", "rmsd")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("rmsd-analysis")
    def run_rmsd(
        main: Path = typer.Option(
            ...,
            "--main",
            "-m",
            help="Path to main/query structure (PDB file)",
            exists=True,
        ),
        reference: Path = typer.Option(
            ...,
            "--reference",
            "-r",
            help="Path to reference structure (PDB file)",
            exists=True,
        ),
        active_main: Optional[str] = typer.Option(
            None,
            "--active-main",
            "--active-residues-main",
            help="Active site residues in main structure (e.g., 'A:30,A:105,B:42')",
        ),
        active_ref: Optional[str] = typer.Option(
            None,
            "--active-ref",
            "--active-residues-reference",
            help="Active site residues in reference structure (if numbering differs)",
        ),
        chain_mapping: Optional[str] = typer.Option(
            None,
            "--chain-mapping",
            help='Map reference chains to main chains as JSON (e.g., \'{"A": "C", "B": "D"}\')',
        ),
        save_plot: bool = typer.Option(
            True,
            "--save-plot/--no-plot",
            help="Generate RMSD histogram plots",
        ),
        save_csv: bool = typer.Option(
            True,
            "--save-csv/--no-csv",
            help="Save CSV with per-residue RMSD",
        ),
        verbose: bool = typer.Option(
            False,
            "--verbose/--quiet",
            help="Print detailed calculation info",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools rmsd-analysis"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read file contents
        main_content = main.read_text()
        reference_content = reference.read_text()
        console.print(f"Read main structure from {main}")
        console.print(f"Read reference structure from {reference}")

        # Build params matching the worker's expected fields
        params = {
            "main_pdb_content": main_content,
            "main_filename": main.name,
            "reference_pdb_content": reference_content,
            "reference_filename": reference.name,
            "save_plot": save_plot,
            "save_csv": save_csv,
            "verbose": verbose,
        }

        # Add active site residues if provided
        if active_main:
            params["active_residues_main"] = active_main
            console.print(f"Active site residues (main): {active_main}")

        if active_ref:
            params["active_residues_reference"] = active_ref
            console.print(f"Active site residues (reference): {active_ref}")

        # Parse and validate chain mapping
        if chain_mapping:
            try:
                mapping = json.loads(chain_mapping)
                if not isinstance(mapping, dict):
                    console.print("[red]Error:[/red] --chain-mapping must be a JSON object")
                    raise typer.Exit(1)
                params["chain_mapping"] = mapping
                console.print(f"Chain mapping: {mapping}")
            except json.JSONDecodeError as e:
                console.print(f"[red]Error:[/red] Invalid JSON in --chain-mapping: {e}")
                raise typer.Exit(1)

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("rmsd-analysis", params, output, background=background)
