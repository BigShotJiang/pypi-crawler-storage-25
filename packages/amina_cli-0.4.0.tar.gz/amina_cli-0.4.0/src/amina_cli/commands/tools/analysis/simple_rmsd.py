"""Simple RMSD backbone analysis tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/simple_rmsd.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("analysis", "simple_rmsd")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("simple-rmsd")
    def run_simple_rmsd(
        mobile: Path = typer.Option(
            ...,
            "--mobile",
            "-m",
            help="Path to mobile/designed structure (PDB file to be aligned)",
            exists=True,
        ),
        reference: Path = typer.Option(
            ...,
            "--reference",
            "-r",
            help="Path to reference structure (PDB file to align against)",
            exists=True,
        ),
        mobile_chains: Optional[str] = typer.Option(
            None,
            "--mobile-chains",
            help="Chains to use from mobile structure (e.g., 'A' or 'A,B'). Default: all chains",
        ),
        ref_chains: Optional[str] = typer.Option(
            None,
            "--ref-chains",
            help="Chains to use from reference structure (e.g., 'A' or 'A,B'). Default: all chains",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for tracking (default: random 4-letter code)",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools simple-rmsd"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read file contents
        mobile_content = mobile.read_text()
        reference_content = reference.read_text()
        console.print(f"Read mobile structure from {mobile}")
        console.print(f"Read reference structure from {reference}")

        # Build params
        params = {
            "mobile_pdb_content": mobile_content,
            "mobile_pdb_filename": mobile.name,
            "reference_pdb_content": reference_content,
            "reference_pdb_filename": reference.name,
        }

        # Parse chain selections
        if mobile_chains:
            # Split on comma and uppercase
            chains = [c.strip().upper() for c in mobile_chains.split(",") if c.strip()]
            params["mobile_chains"] = chains
            console.print(f"Using chains from mobile structure: {chains}")

        if ref_chains:
            # Split on comma and uppercase
            chains = [c.strip().upper() for c in ref_chains.split(",") if c.strip()]
            params["ref_chains"] = chains
            console.print(f"Using chains from reference structure: {chains}")

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("simple-rmsd", params, output, background=background)
