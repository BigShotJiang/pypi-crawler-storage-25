"""MMseqs2 sequence clustering tool for the Amina CLI."""

from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/mmseqs2_cluster.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("analysis", "mmseqs2_cluster")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("mmseqs2-cluster")
    def run_mmseqs2_cluster(
        fasta: List[Path] = typer.Option(
            ...,
            "--fasta",
            "-f",
            help="Path to FASTA file(s). Can be specified multiple times for multiple files.",
            exists=True,
        ),
        identity: float = typer.Option(
            0.5,
            "--identity",
            "-i",
            help="Sequence identity threshold (0.0-1.0). Common values: 0.3 (30%), 0.5 (50%), 0.7 (70%)",
            min=0.0,
            max=1.0,
        ),
        coverage: float = typer.Option(
            0.8,
            "--coverage",
            "-c",
            help="Coverage threshold (0.0-1.0). Default 0.8 means 80% of shorter sequence must align",
            min=0.0,
            max=1.0,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for tracking (default: random 4-letter code)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools mmseqs2-cluster"""
        # Validate output
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Validate at least one FASTA file
        if not fasta or len(fasta) == 0:
            console.print("[red]Error:[/red] At least one --fasta / -f file is required")
            raise typer.Exit(1)

        # Read file contents and track filenames
        fasta_contents = []
        fasta_filenames = []

        for fasta_path in fasta:
            try:
                content = fasta_path.read_text()
                fasta_contents.append(content)
                fasta_filenames.append(fasta_path.name)
                console.print(f"Read FASTA from {fasta_path}")
            except Exception as e:
                console.print(f"[red]Error:[/red] Failed to read {fasta_path}: {e}")
                raise typer.Exit(1)

        # Count sequences
        total_seqs = sum(content.count(">") for content in fasta_contents)
        console.print(f"Total sequences: {total_seqs} from {len(fasta)} file(s)")
        console.print(f"Clustering at {identity * 100:.0f}% identity, {coverage * 100:.0f}% coverage")

        # Build params
        params = {
            "fasta_contents": fasta_contents,
            "fasta_filenames": fasta_filenames,
            "seq_identity": identity,
            "coverage": coverage,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("mmseqs2-cluster", params, output, background=background)
