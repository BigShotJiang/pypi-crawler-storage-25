"""SASA (Solvent Accessible Surface Area) analysis tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/sasa.yaml — keep in sync with Typer options below.
from amina_cli.commands.tools.doccard import load_doccard

METADATA = load_doccard("analysis", "sasa")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("sasa")
    def run_sasa(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file containing protein structure",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        no_csv: bool = typer.Option(
            False,
            "--no-csv",
            help="Skip generating CSV output files",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools sasa"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()
        console.print(f"Read PDB file: {pdb.name}")

        # Build params dict matching worker's expected fields
        params = {
            "pdb_content": pdb_content,
            "savecsv": not no_csv,
        }

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress("sasa", params, output, background=background)
