"""Boltz-2 structure prediction tool for the Amina CLI.

Boltz-2 is a diffusion-based model for predicting 3D structures of biomolecular complexes.
It supports proteins, DNA, RNA, and small molecule ligands.
"""

import typer
from pathlib import Path
from typing import List, Optional, Set, Tuple
from rich.console import Console
from amina_cli.commands.tools.doccard import load_doccard


def parse_sequence_with_chain_id(value: str, used_chains: Set[str]) -> Tuple[Optional[str], str, bool]:
    """
    Parse '[CHAIN_ID:]SEQUENCE[:no-msa]' format.

    Supports explicit chain ID assignment via the X:SEQ format:
    - "A:MVLSPAD..." -> chain_id="A", sequence="MVLSPAD...", skip_msa=False
    - "MVLSPAD..." -> chain_id=None (auto-assign), sequence="MVLSPAD...", skip_msa=False
    - "B:MKFLIL:no-msa" -> chain_id="B", sequence="MKFLIL", skip_msa=True
    - "MKFLIL:no-msa" -> chain_id=None, sequence="MKFLIL", skip_msa=True

    Args:
        value: Input string, either "CHAIN_ID:SEQUENCE[:no-msa]" or just "SEQUENCE[:no-msa]"
        used_chains: Set of already-used chain IDs (for duplicate detection)

    Returns:
        Tuple of (chain_id or None, sequence, skip_msa)

    Raises:
        typer.Exit: If duplicate chain ID is detected
    """
    skip_msa = False

    # Check for :no-msa suffix (case insensitive)
    if value.lower().endswith(":no-msa"):
        skip_msa = True
        value = value[:-7]  # Remove ":no-msa"

    # Check for X:SEQ format (chain ID is 1-2 characters before colon)
    if ":" in value:
        parts = value.split(":", 1)
        potential_chain = parts[0].strip()
        # Only treat as chain ID if it's 1-2 characters (not a long prefix)
        if len(potential_chain) <= 2 and len(potential_chain) >= 1:
            chain_id = potential_chain.upper()
            if chain_id in used_chains:
                Console().print(f"[red]Error:[/red] Duplicate chain ID: {chain_id}")
                raise typer.Exit(1)
            used_chains.add(chain_id)
            sequence = parts[1].strip().upper()
            return chain_id, sequence, skip_msa
    # No chain ID specified - auto-assign
    return None, value.strip().upper(), skip_msa


# METADATA loaded from doccard YAML — the single source of truth for tool documentation.
# Parameter definitions are canonical in docs/boltz2.yaml — keep in sync with Typer options below.
METADATA = load_doccard("folding", "boltz2")

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("boltz2")
    def run_boltz2(
        sequences: List[str] = typer.Option(
            [],
            "--sequence",
            "-s",
            help="Protein sequence. Format: [CHAIN_ID:]SEQUENCE[:no-msa]. Examples: 'MVLSPAD', 'A:MVLSPAD', 'B:MVLSPAD:no-msa'. Add :no-msa suffix to skip MSA alignment.",
        ),
        fasta_files: List[Path] = typer.Option(
            [],
            "--fasta",
            "-f",
            help="Path to FASTA file with single protein sequence (repeatable)",
        ),
        yaml_file: Optional[Path] = typer.Option(
            None,
            "--yaml",
            "-y",
            help="Path to Boltz-2 YAML input file (for complex inputs)",
            exists=True,
        ),
        ligands: List[str] = typer.Option(
            [],
            "--ligand",
            "-l",
            help="Ligand SMILES. Prefix with X: to set chain ID (e.g., 'L:CCO'), or omit for auto. Repeatable.",
        ),
        ligand_ccds: List[str] = typer.Option(
            [],
            "--ligand-ccd",
            help="Ligand CCD code (e.g., ATP, NAD). Prefix with X: for chain ID (e.g., 'L:ATP'), or omit for auto. Repeatable.",
        ),
        dna_sequences: List[str] = typer.Option(
            [],
            "--dna",
            help="DNA sequence. Prefix with X: to set chain ID (e.g., 'D:ATGC'), or omit for auto. Repeatable.",
        ),
        rna_sequences: List[str] = typer.Option(
            [],
            "--rna",
            help="RNA sequence. Prefix with X: to set chain ID (e.g., 'R:AUGC'), or omit for auto. Repeatable.",
        ),
        output: Path = typer.Option(
            ...,
            "--output",
            "-o",
            help="Output directory for results",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
        recycling_steps: int = typer.Option(
            3,
            "--recycling-steps",
            "-r",
            help="Number of recycling iterations (1-20)",
            min=1,
            max=20,
        ),
        sampling_steps: int = typer.Option(
            200,
            "--sampling-steps",
            help="Number of diffusion sampling steps (1-1000)",
            min=1,
            max=1000,
        ),
        diffusion_samples: int = typer.Option(
            1,
            "--samples",
            "-n",
            help="Number of independent structure samples (1-50)",
            min=1,
            max=50,
        ),
        enable_affinity: bool = typer.Option(
            False,
            "--affinity",
            help="Enable binding affinity prediction (protein-ligand complexes only)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
    ):
        """For full documentation including parameters, metrics, and usage: amina tools boltz2"""
        # Validate required options
        if output is None:
            console.print("[red]Error:[/red] --output / -o is required")
            raise typer.Exit(1)

        # Helper function for auto chain ID assignment
        def _auto_chain_id(used: set) -> str:
            """Get next available chain ID (A, B, C, ...)."""
            for i in range(26):
                chain = chr(65 + i)
                if chain not in used:
                    used.add(chain)
                    return chain
            raise ValueError("Exceeded 26 chains")

        # Count total entities from flags
        total_entities = (
            len(sequences)
            + len(fasta_files)
            + len(ligands)
            + len(ligand_ccds)
            + len(dna_sequences)
            + len(rna_sequences)
        )

        # Validate input: need either YAML file or at least one entity
        if not yaml_file and total_entities == 0:
            console.print(
                "[red]Error:[/red] Provide at least one entity "
                "(--sequence, --fasta, --ligand, --ligand-ccd, --dna, --rna) or use --yaml"
            )
            raise typer.Exit(1)

        # Build YAML content
        yaml_content = None

        if yaml_file:
            # Load YAML directly (ignores other entity flags if YAML provided)
            import yaml

            try:
                with open(yaml_file) as f:
                    yaml_content = yaml.safe_load(f)
                console.print(f"Loaded complex definition from {yaml_file}")
            except Exception as e:
                console.print(f"[red]Error:[/red] Failed to parse YAML file: {e}")
                raise typer.Exit(1)
        else:
            # Build YAML from entity flags
            used_chains: set = set()
            sequences_list = []

            # Add proteins from --sequence flags (supports X:SEQ format)
            for seq in sequences:
                parsed_chain_id, sequence, skip_msa = parse_sequence_with_chain_id(seq, used_chains)
                chain_id = parsed_chain_id if parsed_chain_id else _auto_chain_id(used_chains)
                protein_def = {"id": chain_id, "sequence": sequence}
                if skip_msa:
                    protein_def["msa"] = "empty"
                sequences_list.append({"protein": protein_def})
                # Note: Rich interprets [] as markup, use \\[ to escape
                msa_note = " \\[no MSA]" if skip_msa else ""
                console.print(f"Added protein chain {chain_id} ({len(sequence)} residues){msa_note}")

            # Add proteins from --fasta flags (auto-assign chain ID)
            for fasta_path in fasta_files:
                if not fasta_path.exists():
                    console.print(f"[red]Error:[/red] FASTA file not found: {fasta_path}")
                    raise typer.Exit(1)
                content = fasta_path.read_text()
                seq = "".join(
                    line.strip() for line in content.splitlines() if line.strip() and not line.startswith(">")
                )
                chain_id = _auto_chain_id(used_chains)
                sequences_list.append({"protein": {"id": chain_id, "sequence": seq.upper()}})
                console.print(f"Added protein chain {chain_id} from {fasta_path.name} ({len(seq)} residues)")

            # Track ligand chain IDs for affinity prediction
            ligand_chain_ids: list = []

            # Add ligands from --ligand flags (SMILES, supports X:SMILES format)
            for smiles in ligands:
                parsed_chain_id, smiles_clean, _ = parse_sequence_with_chain_id(smiles, used_chains)
                chain_id = parsed_chain_id if parsed_chain_id else _auto_chain_id(used_chains)
                ligand_chain_ids.append(chain_id)
                sequences_list.append({"ligand": {"id": chain_id, "smiles": smiles_clean}})
                smiles_preview = smiles_clean[:40] + "..." if len(smiles_clean) > 40 else smiles_clean
                console.print(f"Added ligand chain {chain_id} (SMILES: {smiles_preview})")

            # Add ligands from --ligand-ccd flags (supports X:CCD format)
            for ccd in ligand_ccds:
                parsed_chain_id, ccd_clean, _ = parse_sequence_with_chain_id(ccd, used_chains)
                chain_id = parsed_chain_id if parsed_chain_id else _auto_chain_id(used_chains)
                ligand_chain_ids.append(chain_id)
                sequences_list.append({"ligand": {"id": chain_id, "ccd": ccd_clean.upper()}})
                console.print(f"Added ligand chain {chain_id} (CCD: {ccd_clean.upper()})")

            # Add DNA from --dna flags (supports X:SEQ format)
            for dna in dna_sequences:
                parsed_chain_id, sequence, _ = parse_sequence_with_chain_id(dna, used_chains)
                chain_id = parsed_chain_id if parsed_chain_id else _auto_chain_id(used_chains)
                sequences_list.append({"dna": {"id": chain_id, "sequence": sequence}})
                console.print(f"Added DNA chain {chain_id} ({len(sequence)} bases)")

            # Add RNA from --rna flags (supports X:SEQ format)
            for rna in rna_sequences:
                parsed_chain_id, sequence, _ = parse_sequence_with_chain_id(rna, used_chains)
                chain_id = parsed_chain_id if parsed_chain_id else _auto_chain_id(used_chains)
                sequences_list.append({"rna": {"id": chain_id, "sequence": sequence}})
                console.print(f"Added RNA chain {chain_id} ({len(sequence)} bases)")

            yaml_content = {"version": 1, "sequences": sequences_list}

            # Add properties section for affinity prediction
            if enable_affinity:
                if not ligand_chain_ids:
                    console.print(
                        "[red]Error:[/red] --affinity requires at least one ligand (use --ligand or --ligand-ccd)"
                    )
                    raise typer.Exit(1)
                # Use first ligand as binder
                binder_chain = ligand_chain_ids[0]
                yaml_content["properties"] = [{"affinity": {"binder": binder_chain}}]
                console.print(f"Enabled affinity prediction (binder: chain {binder_chain})")

        # Build params for gateway
        params = {
            "yaml_content": yaml_content,
            "recycling_steps": recycling_steps,
            "sampling_steps": sampling_steps,
            "diffusion_samples": diffusion_samples,
            "step_scale": 1.638,
            "use_potentials": False,
            "enable_affinity_prediction": enable_affinity,
        }

        if job_name:
            params["job_name"] = job_name

        # Execute
        run_tool_with_progress("boltz2", params, output, background=background)
