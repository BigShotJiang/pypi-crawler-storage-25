import os
import torch
from copy import deepcopy
from contextlib import nullcontext
from omegaconf import DictConfig, ListConfig
from hydra import compose, initialize
from hydra.utils import instantiate

import logging
from collections.abc import Iterable
import yaml

from typing import List, Dict, Optional, Union, Callable, Any, Tuple

from .utils import get_input_variable_names
from .utils import get_output_variable_names
from .utils import shared_dict
from .utils import validate_io_keys
from .utils import get_module_input


class Scheduler:

    def __init__(
            self,
            scheduler,
            frequency=1,
            interval='epoch'
            ):
        self.scheduler = scheduler
        self.frequency = frequency
        self.interval = interval

        self.steps_since_update = 0
        self.epochs_since_update = 0

    def state_dict(self):
        return {
            'scheduler': self.scheduler.state_dict(),
            'steps_since_update': self.steps_since_update,
            'epochs_since_update': self.epochs_since_update,
        }

    def load_state_dict(self, state_dict):
        self.scheduler.load_state_dict(state_dict['scheduler'])
        self.steps_since_update = state_dict.get('steps_since_update', 0)
        self.epochs_since_update = state_dict.get('epochs_since_update', 0)

    def step_done(self):
        if self.interval != 'step':
            return
        
        self.steps_since_update += 1
        if self.steps_since_update >= self.frequency:
            self.scheduler.step()
            self.steps_since_update = 0

    def epoch_done(self):
        if self.interval != 'epoch':
            return
        
        self.epochs_since_update += 1
        if self.epochs_since_update >= self.frequency:
            self.scheduler.step()
            self.epochs_since_update = 0


class Model( torch.nn.Module ):
    def __init__(
            self,
            # core functionality
            submodules: Union[
                Dict[ str, str ],
                Dict[ str, torch.nn.Module ],
                ],
            operations: List[ List[ Dict[ str, Dict ] ] ],

            # training related
            submodules_eval: Optional[ List[str] ] = None,
            exclude_from_checkpoint: Optional[ List[str] ] = None,
            checkpoints: Optional[ List[ Dict[ str, str ] ] ] = None,
            ):
        
        super().__init__()
        
        # Processing modules and core functionality
        self.submodule_names = list( submodules.keys() )

        for sm_name, sm in submodules.items():
            if isinstance( sm, str ):
                # load yaml file from string and instantiate its content
                # TODO: this may only work with absolute paths, make it work with relative paths
                y = yaml.load( sm, safe_load = True )
                sm = instantiate( y )

            if not isinstance( sm, torch.nn.Module ):
                raise ValueError(
                    f"""
                    The submodule {sm_name} must be a torch.nn.Module 
                    or a file path to a yaml file that can be instantiated
                    into a torch.nn.Module. However, the passed submodule
                    is of type {type(sm)}.
                    """
                    )

            setattr( self, sm_name, sm )

        logging.info(
            f"""
            Created a hypaTorch model from the following submodules:
            {self.submodule_names}
            """
            )

        self.operations = operations
        self.mappings = self._get_content( 'mappings' )

        self.logging = self._get_content( 'logging' )


        ## Losses and metrics
        self.losses = self._get_content( 'losses' )
        self.metrics = self._get_content( 'metrics' )


        # Checkpoints
        self.checkpoints = checkpoints if checkpoints is not None else []

        # Freeze submodules if specified
        optimized_sm_list = []
        for x in self._get_content(
            'optimize_submodules',
            return_on_failure = {},
            ).values():
            optimized_sm_list.extend( x )
        optimized_sm_set = set( optimized_sm_list )
        logging.info(
            f"""
            All submodules that get optimized by at least
            one optimizer: {optimized_sm_set}
            """
            )

        # self frozen is the disjoin of the optimized submodules and submodule_names
        self.frozen = list( set( self.submodule_names ) - optimized_sm_set )
        logging.info(
            f"""
            All submodules that get optimized by at least
            one optimizer: {optimized_sm_set}
            """
            )
        self._freeze_submodules( self )

        # Exclude from checkpoint
        if exclude_from_checkpoint is None:
            exclude_from_checkpoint = []
        self.exclude_from_checkpoint = exclude_from_checkpoint

        # List for submodules that require eval mode in training
        if submodules_eval is None:
            submodules_eval = []
        self.submodules_eval = submodules_eval

        return
    
    @classmethod
    def from_config(
            cls,
            config_path: str,
            ):
        with initialize(
            version_base=None,
            config_path="conf",
            job_name="test_app",
            ):
            cfg = compose( config_name=config_path )
        
        # Instantiate the model
        if 'model' in cfg:
            model = instantiate( cfg.model )
        else:
            model = instantiate( cfg )

        model._load_checkpoints(
            checkpoints_dict = cfg.checkpoints,
            )
        
        return model
    
    def _load_checkpoints(
            self,
            checkpoints_dict = None,
            ):
        checkpoints = self.checkpoints if checkpoints_dict is None else checkpoints_dict
        for ckpt_dict in checkpoints:

            ckpt =torch.load( ckpt_dict[ 'path' ] )[ 'state_dict' ]
            if 'prefix_rm' in ckpt_dict:
                prefix_rm = ckpt_dict[ 'prefix_rm' ]
                if prefix_rm.endswith( '.' ):
                    # delete all trailing dots
                    prefix_rm = prefix_rm.rstrip( '.' )
                ckpt = {
                    k[ len( prefix_rm ) + 1: ]: v 
                    for k, v in ckpt.items()
                    if k.startswith( prefix_rm )
                    }
            if 'prefix_add' in ckpt_dict:
                prefix_add = ckpt_dict[ 'prefix_add' ]
                if prefix_add.endswith( '.' ):
                    prefix_add = prefix_add.rstrip( '.' )
                prefix_add = prefix_add + '.'
                ckpt = {
                    prefix_add + k: v 
                    for k, v in ckpt.items()
                    }
            try:
                self.load_state_dict(
                    ckpt,
                    strict = True,
                    )
            except Exception as e:
                logging.warning(
                    f"""
                    Could not load the checkpoint {ckpt_dict[ 'path' ]}
                    in 'strict' mode. Trying again with 'strict = False'.
                    Enable logging.DEBUG level for more information.
                    """
                    ) 
                logging.debug( f'Due to the following error: {e}.' )
                self.load_state_dict(
                    ckpt,
                    strict = False,
                    )
        return
    
    def _get_content(
            self,
            key,
            return_on_failure = [],
            ):
        x = {}

        for op_name, op in self.operations.items():
            if key in op:
                x[ op_name ] = op[ key ]
            else:
                x[ op_name ] = return_on_failure
        return x
    
    def _collect_trainable_parameters(
            self,
            submodule_names,
            ):
        parameters = []
        
        for submodule_name in submodule_names:
            submodule = getattr(self, submodule_name)
            if submodule_name not in self.frozen:
                parameters.extend( submodule.parameters() )

        return parameters
    
    def _compute_assessments(
            self,
            data_dict,
            assessments,
            mode,
            ):
        x = {}
        
        for fn in assessments:
            if fn.apply is None or mode in fn.apply:
                y = fn(
                    data_dict = data_dict,
                    model = self
                    )
                x[ fn.name ] = y

        return x
    
    def _check_if_submodule_gets_applied(
            self,
            mode,
            mapping_dict,
            ):
        if 'apply' in mapping_dict:
            if mode in mapping_dict[ 'apply' ]:
                return True
            else:
                return False
        else:
            return True
    
    def _freeze_submodules(
            self,
            module,
            ):
        for x in self.frozen:
            module = getattr(self, x)
            for param in module.parameters():
                param.requires_grad = False
        return
    
    def configure_optimizers(self):
        optimizers = {}
        schedulers = {}

        gradient_clipping = {}

        for op_name, opt in self.operations.items():
            # List of parameters to optimize for this operation
            parameters = self._collect_trainable_parameters(
                submodule_names = opt[ 'optimize_submodules' ],
            )

            optimizer = opt[ 'optimizer' ](parameters)

            optimizers[op_name] = optimizer

            if 'lr_scheduler' in opt and opt[ 'lr_scheduler' ] is not None:
                # Instantiate the partially instantiated LR scheduler
                scheduler_cfg = deepcopy(opt[ 'lr_scheduler' ])
                scheduler_factory = scheduler_cfg.pop( 'scheduler' )
                scheduler = scheduler_factory(optimizer)

                # Wrap the scheduler in the hypatorch scheduler to handle the frequency and interval
                schedulers[op_name] = Scheduler(
                    scheduler = scheduler,
                    **scheduler_cfg,
                )

            if 'gradient_clipping' in opt and opt[ 'gradient_clipping' ] is not None:
                def gradient_clipping_fn(opt, parameters):
                    return lambda: opt['gradient_clipping'](parameters)
                gradient_clipping[op_name] = gradient_clipping_fn(opt, parameters)

        return optimizers, schedulers, gradient_clipping

    def _run_submodule(
            self,
            submodule,
            submodule_name,
            mapping,
            data_dict,
            mode
            ):
        
        frozen = submodule_name in self.frozen
        calculate_grad = mapping[ submodule_name ][ 'calculate_grad' ]
        if not calculate_grad or ( frozen and not calculate_grad ) or mode != 'train':
            context = torch.no_grad()
        else:
            context = nullcontext()
        with context:
            if 'fn' in mapping[ submodule_name ]:
                fn = getattr( submodule, mapping[ submodule_name ][ 'fn' ] )
                fn_to_inspect = fn
            else:
                fn_to_inspect = submodule.forward
                fn = submodule.__call__

            output_key_map = mapping[ submodule_name ][ 'outputs' ]
            inputs = mapping[ submodule_name][ 'inputs' ]

            expected_inputs = get_input_variable_names( fn_to_inspect )
            expected_outputs = list(output_key_map.keys())

            validate_io_keys(
                module_name = submodule_name,
                module_object_name = submodule.__class__.__name__,
                input_key_map = inputs,
                output_key_map = output_key_map,
                expected_inputs = expected_inputs,
                expected_outputs = expected_outputs,
                )
            
            submodule_in = get_module_input(
                inputs = inputs,
                data_dict = data_dict,
                )

            if 'fn' in mapping[ submodule_name ]:
                submodule_out = fn( **submodule_in )
            else:
                submodule_out = submodule( **submodule_in )

            # if submodule is not a tuple, make it a tuple of length 1
            if not isinstance( submodule_out, tuple ):
                submodule_out = ( submodule_out, )

            if len( submodule_out ) != len( expected_outputs ):
                raise ValueError(
                    f"""
                    Error with output of {submodule_name}.
                    Expected {len( expected_outputs )} outputs,
                    but got {len( submodule_out )} outputs.
                    """
                    )
            
            sm_out_dict = { key: value for key, value in zip( expected_outputs, submodule_out ) }
            #x = { key_map: sm_out_dict[ key ] for key, key_map in output_key_map.items() }
            x = {}
            for key, key_map in output_key_map.items():
                if isinstance( key_map, str ):
                    x[ key_map ] = sm_out_dict[ key ]
                elif isinstance( key_map, List ) or isinstance( key_map, ListConfig ):
                    for idx, km in enumerate( key_map ):
                        x[ km ] = sm_out_dict[ key ][ idx ]
                else:
                    raise ValueError(
                        f"""
                        Error with output key mapping of {submodule_name}.
                        Expected a string or a list, but got {type(key_map)}.
                        """
                        )

        return x
    
    def forward(
            self,
            input_dict,
            operation_name,
            mode,
            ):

        output_dict = {}

        for mapping in self.mappings[ operation_name ]:
            for submodule_name in mapping.keys():
                submodule = getattr(self, submodule_name)
                if submodule is not None:
                    apply_submodule = self._check_if_submodule_gets_applied(
                        mode = mode,
                        mapping_dict = mapping[ submodule_name ],
                        )
                    if apply_submodule:
                        data_dict = shared_dict(
                            input_dict,
                            output_dict,
                            )
                        x = self._run_submodule(
                            submodule = submodule,
                            submodule_name = submodule_name,
                            mapping = mapping,
                            data_dict = data_dict,
                            mode=mode,
                        )
                        # check that x.keys do not overlap with output_dict.keys
                        if not any( x in output_dict.keys() for x in x.keys() ):
                            output_dict.update( x )
                        else:
                            raise ValueError(
                                f"""
                                Error with output_dict of {submodule_name}.
                                Submodules are not allowed to overwrite existing keys.
                                However, {submodule_name} has the following keys: {x.keys()}
                                and the output_dict has the following keys: {output_dict.keys()}.
                                """
                                )
                    #else:
                    #    print( f'module {submodule_name} not applied')
                else:
                    raise ValueError(
                        f'No submodule {submodule_name} found. Forgot to define it?'
                        )

        return output_dict
    
    def train(self, mode=True):
        super().train(mode)
        if mode:
            for submodule_name in self.submodules_eval:
                getattr(self, submodule_name).eval()
        return self

    
    def log_data(self, logger, step, data_dict):

        for operation_name in self.operations.keys():
            if self.logging:
                loggings = self.logging[ operation_name ]
                if loggings:
                    if not isinstance( loggings, list ) and not isinstance( loggings, ListConfig ):
                        loggings = [ loggings ]
                    
                    for log in loggings:

                        fn_name = log[ 'fn' ]
                        fn_args = { k: v for k, v in log.items() if k != 'fn' }

                        log_fn = getattr(
                            logger,
                            fn_name,
                        )
                        log_fn(
                            data_dict = data_dict,
                            global_step = step,
                            **fn_args,
                            )        

    def validation_step(self, batch, batch_idx):

        mode = 'val'
        
        input_dict = batch
        output_dict = {}

        for operation_name in self.operations.keys():
            # Forward Pass
            with torch.no_grad():
                operation_out, loss = self._forward_pass(
                    input_dict = shared_dict(
                        input_dict,
                        output_dict,
                        ),
                    operation_name = operation_name,
                    mode = mode,
                    )
                
            output_dict = self._handle_operation_output(
                x = operation_out,
                output_dict = output_dict,
                operation_name = operation_name,
                )
            
            # handle metrics
            self._handle_assessments(
                assessments = self.metrics,
                data_dict = shared_dict(
                    input_dict,
                    output_dict,
                    ),
                operation_name = operation_name,
                mode = mode,
                )
            
            # Once per epoch, log the first batch
            if batch_idx == 0 and self.logging:
                loggings = self.logging[ operation_name ]
                if loggings:
                    if not isinstance( loggings, list ) and not isinstance( loggings, ListConfig ):
                        loggings = [ loggings ]
                    for logging in loggings:

                        fn_name = logging[ 'fn' ]
                        fn_args = { k: v for k, v in logging.items() if k != 'fn' }

                        log_fn = getattr(
                            self.logger,
                            fn_name,
                        )
                        log_fn(
                            data_dict = shared_dict(
                                input_dict,
                                output_dict,
                                ),
                            global_step = self.global_step,
                            **fn_args,
                            )
        
        return loss
    
    def compute_loss(self, x, operation_name, mode, logger=None):
        loss_dict = self._handle_assessments(
            assessments = self.losses,
            data_dict = x,
            operation_name = operation_name,
            mode = mode,
            logger = logger,
            )

        if loss_dict:
            loss = sum( loss_dict.values() )
        else:
            loss = None


        return loss
        
    def compute_metrics(self, x, operation_name, mode, logger=None):
        metric_dict = self._handle_assessments(
            assessments = self.metrics,
            data_dict = x,
            operation_name = operation_name,
            mode = mode,
            logger = logger,
            )
        return metric_dict

    def _handle_assessments(
            self,
            assessments,
            data_dict,
            operation_name,
            mode,
            logger=None
            ):
        if assessments:
            assessments_dict = self._compute_assessments(
                data_dict = data_dict,
                assessments = assessments[ operation_name ],
                mode = mode,
                )
            if logger:
                for k, v in assessments_dict.items():
                    logger.log_value(
                        f'{mode}_{k}',
                        v.item(),
                    )
        else:
            assessments_dict = None
        return assessments_dict
    
    def _handle_operation_output(
            self,
            x,
            output_dict,
            operation_name,
            ):
        if not any( x in output_dict.keys() for x in x.keys() ):
            output_dict.update( x )
        else:
            raise ValueError(
                f"""
                Error with output_dict of {operation_name}.
                Operations are not allowed to overwrite existing keys.
                However, {operation_name} has the following keys: {x.keys()}
                and the output_dict has the following keys: {output_dict.keys()}.
                """
                )
        return output_dict
    
    def predict_step(self, batch, batch_idx):
        data_dict = self.test_step(
            batch = batch,
            batch_idx = batch_idx,
            mode = 'predict',
            )
        return data_dict

    def test_step(
            self,
            batch,
            batch_idx,
            mode = 'test',
            ):

        input_dict = batch
        output_dict = {}

        for operation_name in self.operations.keys():
            # Forward Pass
            with torch.no_grad():
                operation_out, loss = self._forward_pass(
                    input_dict = shared_dict(
                        input_dict,
                        output_dict,
                        ),
                    operation_name = operation_name,
                    mode = mode,
                    )
            
            detached_loss_dict = {}
            if loss is not None:
                detached_loss_dict = { k: v.detach() for k, v in loss.items() }
                
            output_dict = self._handle_operation_output(
                x = shared_dict(
                    operation_out,
                    detached_loss_dict,
                    ),
                output_dict = output_dict,
                operation_name = operation_name,
                )
            
            # handle metrics
            metric_dict = self._handle_assessments(
                assessments = self.metrics,
                data_dict = shared_dict(
                    input_dict,
                    output_dict,
                    ),
                operation_name = operation_name,
                mode = mode,
                )
            
            if metric_dict:
                output_dict = self._handle_operation_output(
                    x = metric_dict,
                    output_dict = output_dict,
                    operation_name = operation_name,
                    )
            
            
        data_dict = shared_dict(
            input_dict,
            output_dict,
            )
            
        return data_dict
    
    def checkpoint_state_dict(self):
        state_dict = self.state_dict()

        for submodule in self.exclude_from_checkpoint:
            keys_to_remove = [
                k for k in state_dict.keys() if k.startswith(submodule + '.')
                ]
            for key in keys_to_remove:
                state_dict.pop(key, None)

        return state_dict

            
    def load_checkpoint_state_dict(self, state_dict, strict=True):
        # Try to load all submoduless that are no in the exclude_from_checkpoint list
        submodules_with_parameters = set((p.split('.')[0] for p in  self.state_dict().keys()))

        # Remove the submodules that are in the exclude_from_checkpoint list
        submodules_to_load = submodules_with_parameters - set(self.exclude_from_checkpoint)

        for submodule in submodules_to_load:
            module_state_dict = {'.'.join(k.split('.')[1:]): v for k, v in state_dict.items() if k.startswith(submodule + '.')}
            if len(module_state_dict) == 0:
                raise ValueError(f"Submodule {submodule} not found in the checkpoint.")
            

            getattr(self, submodule).load_state_dict(module_state_dict, strict=strict)
