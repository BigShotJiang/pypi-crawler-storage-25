"""pentest-ai CLI — Beautiful command-line interface"""

import json
import os
from importlib.metadata import PackageNotFoundError, version as _pkg_version

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table


def _ptai_version() -> str:
    try:
        return _pkg_version("ptai")
    except PackageNotFoundError:
        return "0.0.0+unknown"


def _version_callback(value: bool) -> None:
    if value:
        print(f"ptai {_ptai_version()}")
        raise typer.Exit()


app = typer.Typer(
    name="pentest-ai",
    help="The most autonomous pentesting AI on the market",
    add_completion=False,
)
console = Console()


@app.callback()
def _root(
    version: bool = typer.Option(
        False, "--version", "-V", callback=_version_callback, is_eager=True, help="Show version and exit."
    ),
) -> None:
    pass


def _llm_key_present() -> bool:
    """True if an LLM provider is configured enough to run a scan.

    - provider=ollama needs no key (local model).
    - otherwise one of PENTEST_AI_API_KEY / OPENAI_API_KEY / ANTHROPIC_API_KEY must be set.
    """
    provider = os.getenv("PENTEST_AI_LLM_PROVIDER", "openai").lower()
    if provider == "ollama":
        return True
    return bool(
        os.getenv("PENTEST_AI_API_KEY")
        or os.getenv("OPENAI_API_KEY")
        or os.getenv("ANTHROPIC_API_KEY")
    )


def _ci_print(message: str, data: dict | None = None) -> None:
    if data:
        print(json.dumps({"message": message, **data}))
    else:
        print(json.dumps({"message": message}))


# ============================================================================
# Dashboard sync — turns a completed local engagement into an upload payload
# and POSTs it to /api/cli/ingest. Best-effort: never raises, never breaks a
# scan. Called from every command that completes an engagement.
# ============================================================================
_SEVERITY_ALLOWED = {"critical", "high", "medium", "low", "info"}


def _build_ingest_payload(engagement: dict, summary: dict, findings: list[dict], chains: list[dict] | None = None) -> dict:
    """Shape a local engagement into the /api/cli/ingest schema."""
    # Normalize severities + cap string sizes the server will trim anyway.
    out_findings: list[dict] = []
    for f in findings or []:
        sev = (f.get("severity") or "").lower()
        if sev not in _SEVERITY_ALLOWED:
            continue
        out_findings.append({
            "external_id": f.get("id"),
            "title":       (f.get("title") or "Untitled")[:500],
            "severity":    sev,
            "description": (f.get("description") or "")[:20000],
            "category":    (f.get("category") or "general")[:100],
            "target":      (f.get("target") or engagement.get("target") or "")[:500],
            "tool_source": (f.get("tool_source") or f.get("source") or "")[:200],
            "evidence":    (f.get("evidence") or "")[:20000],
            "poc":         (f.get("poc") or "")[:20000],
            "cvss":        f.get("cvss_score") or f.get("cvss"),
            "cwe":         f.get("cwe"),
            "remediation": (f.get("remediation") or "")[:20000],
        })

    out_chains: list[dict] = []
    for c in chains or []:
        out_chains.append({
            "external_id": c.get("id"),
            "name":        (c.get("name") or "")[:500],
            "severity":    (c.get("severity") or "").lower(),
            "narrative":   (c.get("description") or "")[:10000],
        })

    return {
        "engagement": {
            "external_id":  engagement.get("id"),
            "name":         (engagement.get("name") or f"Scan {engagement.get('target', '')}")[:500],
            "target":       (engagement.get("target") or "")[:500],
            "status":       engagement.get("status") or "completed",
            "cli_version":  _ptai_version(),
            "started_at":   engagement.get("started_at"),
            "completed_at": engagement.get("completed_at"),
        },
        "findings": out_findings,
        "chains":   out_chains,
        "scan_metadata": {
            "scope":     engagement.get("scope"),
            "intensity": engagement.get("intensity"),
            "totals":    summary.get("by_severity") if summary else {},
        },
    }


def _maybe_sync_to_cloud(
    engagement: dict,
    summary: dict,
    findings: list[dict],
    chains: list[dict] | None = None,
    *,
    skip: bool = False,
    ci: bool = False,
) -> None:
    """Upload engagement + findings to app.pentestai.xyz if a key is configured.

    Prints a one-line result (or nothing in CI mode — we emit JSON there).
    Never raises. Never changes exit code.
    """
    if skip:
        if not ci:
            console.print("[dim]Skipped dashboard sync (--no-sync).[/dim]")
        return

    try:
        from cli.auth import ingest_engagement, load_api_key, api_base
    except Exception:
        return

    key = load_api_key()
    if not key:
        if not ci:
            console.print(
                "[dim]Tip:[/dim] run [cyan]pentest-ai auth login[/cyan] to sync findings to your dashboard."
            )
        return

    payload = _build_ingest_payload(engagement, summary, findings, chains)
    resp = ingest_engagement(payload, api_key=key)

    if ci:
        if resp:
            _ci_print("sync_ok", {
                "dashboard_engagement_id": resp.get("engagement_id"),
                "findings_created": resp.get("findings_created", 0),
                "findings_skipped": resp.get("findings_skipped", 0),
            })
        else:
            _ci_print("sync_failed", {"host": api_base()})
        return

    if not resp:
        console.print(
            f"[yellow]Dashboard sync failed[/yellow] (host {api_base()}). "
            "Your local scan is safe; findings remain in "
            f"[dim]{os.getenv('PENTEST_DB_PATH', 'pentest_findings.db')}[/dim]."
        )
        return

    if resp.get("quota_exceeded"):
        console.print(
            Panel.fit(
                f"[yellow]Free-tier quota reached[/yellow] — "
                f"{resp.get('used', '?')}/{resp.get('limit', '?')} engagements this month.\n"
                f"Your local scan is safe and all findings are in the local DB.\n"
                f"[dim]Upgrade at[/dim] [cyan]{resp.get('upgrade_url', api_base())}[/cyan] "
                f"[dim]— quota resets {resp.get('resets_at', 'next month')}[/dim]",
                title="Plan limit",
                border_style="yellow",
            )
        )
        return

    url = resp.get("dashboard_url") or api_base()
    console.print(
        f"[green]✓ Synced to dashboard.[/green] "
        f"{resp.get('findings_created', 0)} new, {resp.get('findings_skipped', 0)} already on file. "
        f"[link]{url}[/link]"
    )


@app.command()
def start(
    target: str = typer.Argument("", help="Target hostname, IP, URL, CIDR, or comma-separated list"),
    targets_file: str = typer.Option("", "--targets", help="Path to file with one target per line"),
    scope: str = typer.Option("full", "--scope", "-s", help="Scope: recon, web, ad, cloud, full"),
    intensity: str = typer.Option("normal", "--intensity", "-i", help="Scan intensity: stealth, normal, aggressive"),
    cookie: str = typer.Option("", "--cookie", help="Cookie string for authenticated scanning"),
    header: str = typer.Option("", "--header", help="Custom header (e.g. 'Authorization: Bearer token')"),
    basic_auth: str = typer.Option("", "--basic-auth", help="Basic auth credentials (user:pass)"),
    login_url: str = typer.Option("", "--login-url", help="Login form URL (enables authenticated scanner, no LLM needed)"),
    login_user: str = typer.Option("", "--login-user", help="Username for form login"),
    login_password_env: str = typer.Option(
        "", "--login-password-env", help="Env var holding the password (e.g. DVWA_PASS)"
    ),
    login_username_field: str = typer.Option("username", "--login-username-field"),
    login_password_field: str = typer.Option("password", "--login-password-field"),
    login_success_marker: str = typer.Option(
        "", "--login-success-marker", help="Substring that must appear in login response"
    ),
    login_max_pages: int = typer.Option(40, "--login-max-pages", help="Max pages for authenticated crawl"),
    ci: bool = typer.Option(False, "--ci", help="CI/CD mode: JSON output, exit code = critical+high count"),
    fail_threshold: str = typer.Option("high", "--fail-threshold", help="CI exit threshold: critical, high, medium"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Bypass tool result cache for this run"),
    no_sync: bool = typer.Option(False, "--no-sync", help="Skip auto-upload to dashboard even if authenticated."),
):
    """Start a pentest engagement against a target.

    Multi-target inputs (CIDR, comma list, --targets file) create a campaign.
    """
    from engine.cache import ToolResultCache
    from engine.target_expander import resolve_targets
    from tools.registry import configure_cache

    configure_cache(ToolResultCache(), intensity=intensity, disabled=no_cache)

    if not target and not targets_file:
        console.print("[red]Provide a TARGET argument or --targets <file>.[/red]")
        raise typer.Exit(2)

    try:
        expanded = resolve_targets(target or None, targets_file or None)
    except (ValueError, FileNotFoundError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(2) from e

    if not expanded:
        console.print("[red]No targets resolved from input.[/red]")
        raise typer.Exit(2)

    if len(expanded) > 1:
        _start_campaign_run(expanded, scope, intensity, ci)
        return

    single = expanded[0]
    if ci:
        _ci_print("engagement_starting", {"target": single, "scope": scope})

    if login_url:
        _run_authenticated_scan_cli(
            target=single,
            login_url=login_url,
            login_user=login_user,
            login_password_env=login_password_env,
            username_field=login_username_field,
            password_field=login_password_field,
            success_marker=login_success_marker,
            max_pages=login_max_pages,
            ci=ci,
        )
        return

    if not _llm_key_present():
        console.print(
            "[red]No LLM provider configured.[/red] Set one of:\n"
            "  [cyan]OPENAI_API_KEY[/cyan], [cyan]ANTHROPIC_API_KEY[/cyan], "
            "or [cyan]PENTEST_AI_LLM_PROVIDER=ollama[/cyan] for a local model.\n"
            "See [cyan]ptai setup --init[/cyan] to scaffold a config file."
        )
        raise typer.Exit(2)

    console.print(
        Panel.fit(
            f"[bold green]pentest-ai v{_ptai_version()}[/bold green]\n"
            f"Target: [cyan]{single}[/cyan]\n"
            f"Scope: [yellow]{scope}[/yellow]\n"
            f"Intensity: [yellow]{intensity}[/yellow]",
            title="Starting Engagement",
        )
    )

    import asyncio as _asyncio

    from engine.findings_db import FindingsDB
    from engine.orchestrator import AgentOrchestrator

    async def _run_engagement() -> dict:
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            engagement = await db.create_engagement(
                target=single,
                scope=scope,
                intensity=intensity,
            )
            orch = AgentOrchestrator(db=db)
            await orch.start_engagement(engagement)
            summary = await db.get_engagement_summary(engagement["id"])
            findings = await db.get_findings(engagement_id=engagement["id"])
            chains = await db.get_attack_chains(engagement["id"])
            return {"engagement": engagement, "summary": summary, "findings": findings, "chains": chains}
        finally:
            await db.close()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(f"[green]Scanning {single}...", total=None)
        result = _asyncio.run(_run_engagement())

    engagement = result["engagement"]
    summary = result["summary"]
    findings_list = result.get("findings", []) or []
    chains_list = result.get("chains", []) or []
    sev = summary.get("by_severity", {})

    if ci:
        _ci_print(
            "engagement_complete",
            {
                "engagement_id": engagement["id"],
                "target": single,
                "total_findings": summary.get("total_findings", 0),
                "by_severity": sev,
            },
        )
        _maybe_sync_to_cloud(engagement, summary, findings_list, chains_list, skip=no_sync, ci=True)
        return

    sev_line = "  ".join(
        f"[{'red' if s == 'critical' else 'yellow' if s == 'high' else 'blue' if s == 'medium' else 'dim'}]"
        f"{s.upper()}: {c}[/]"
        for s, c in sev.items()
    )
    console.print(
        Panel.fit(
            f"[bold green]Engagement complete[/bold green]\n"
            f"ID: [cyan]{engagement['id']}[/cyan]\n"
            f"Findings: {summary.get('total_findings', 0)}  {sev_line}\n"
            f"Next: [dim]ptai findings {engagement['id']}[/dim] or "
            f"[dim]ptai report {engagement['id']}[/dim]",
            title="Done",
        )
    )

    _maybe_sync_to_cloud(engagement, summary, findings_list, chains_list, skip=no_sync, ci=False)


def _start_campaign_run(targets: list[str], scope: str, intensity: str, ci: bool) -> None:
    """Create a campaign with one engagement per target. Does not auto-run scans."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _create() -> dict:
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            campaign_id = await db.create_campaign(
                name=f"Campaign ({len(targets)} targets)",
                targets=targets,
            )
            engagement_ids: list[str] = []
            for t in targets:
                eng = await db.create_engagement(
                    target=t,
                    scope=scope,
                    intensity=intensity,
                    campaign_id=campaign_id,
                )
                engagement_ids.append(eng["id"])
            return {"campaign_id": campaign_id, "engagement_ids": engagement_ids}
        finally:
            await db.close()

    result = asyncio.run(_create())

    if ci:
        _ci_print("campaign_created", {
            "campaign_id": result["campaign_id"],
            "targets": len(targets),
            "engagement_ids": result["engagement_ids"],
        })
        return

    console.print(
        Panel.fit(
            f"[bold green]Campaign created[/bold green]\n"
            f"ID: [cyan]{result['campaign_id']}[/cyan]\n"
            f"Targets: [yellow]{len(targets)}[/yellow]\n"
            f"Scope: [yellow]{scope}[/yellow]  Intensity: [yellow]{intensity}[/yellow]\n\n"
            f"Run via MCP: call start_campaign or step through engagements.\n"
            f"Inspect: [dim]ptai campaign {result['campaign_id']}[/dim]",
            title="Multi-Target Campaign",
        )
    )


def _run_authenticated_scan_cli(
    *,
    target: str,
    login_url: str,
    login_user: str,
    login_password_env: str,
    username_field: str,
    password_field: str,
    success_marker: str,
    max_pages: int,
    ci: bool,
) -> None:
    """Deterministic authenticated scan: log in, crawl, probe SQLi/XSS/cmdi.

    Stores findings in a fresh engagement. No LLM key required.
    """
    import asyncio as _asyncio

    from engine.auth_session import AuthError, WebAuthenticator
    from engine.authenticated_scan import run_authenticated_scan
    from engine.findings_db import FindingsDB

    if not login_user:
        console.print("[red]--login-user is required with --login-url.[/red]")
        raise typer.Exit(2)
    if not login_password_env:
        console.print(
            "[red]--login-password-env is required with --login-url[/red] "
            "(set e.g. [cyan]export DVWA_PASS=password[/cyan] and pass [cyan]--login-password-env DVWA_PASS[/cyan])."
        )
        raise typer.Exit(2)

    password = os.environ.get(login_password_env, "")
    if not password:
        console.print(f"[red]env var {login_password_env} is empty; set it before running.[/red]")
        raise typer.Exit(2)

    authenticator = WebAuthenticator(
        flow="form_post",
        login_url=login_url,
        username=login_user,
        password=password,
        username_field=username_field,
        password_field=password_field,
        success_marker=success_marker,
    )

    async def _run() -> dict:
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            engagement = await db.create_engagement(
                target=target, scope="web", intensity="normal"
            )
            result = await run_authenticated_scan(
                target=target,
                authenticator=authenticator,
                max_pages=max_pages,
            )
            for f in result.get("findings", []):
                f["engagement_id"] = engagement["id"]
                await db.add_finding(f)
            summary = await db.get_engagement_summary(engagement["id"])
            return {"engagement": engagement, "result": result, "summary": summary}
        finally:
            await db.close()

    if not ci:
        console.print(
            Panel.fit(
                f"[bold green]pentest-ai v{_ptai_version()}[/bold green]\n"
                f"Target: [cyan]{target}[/cyan]\n"
                f"Mode: [yellow]authenticated scan (deterministic, no LLM)[/yellow]\n"
                f"Login: [cyan]{login_url}[/cyan] as [cyan]{login_user}[/cyan]",
                title="Starting Authenticated Scan",
            )
        )

    try:
        payload = _asyncio.run(_run())
    except AuthError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        raise typer.Exit(2) from e

    engagement = payload["engagement"]
    result = payload["result"]
    summary = payload["summary"]
    sev = summary.get("by_severity", {})

    if ci:
        _ci_print(
            "engagement_complete",
            {
                "engagement_id": engagement["id"],
                "target": target,
                "endpoints_tested": result.get("endpoints_tested", 0),
                "total_findings": result.get("findings_count", 0),
                "by_severity": sev,
            },
        )
        return

    sev_line = "  ".join(
        f"[{'red' if s == 'critical' else 'yellow' if s == 'high' else 'blue' if s == 'medium' else 'dim'}]"
        f"{s.upper()}: {c}[/]"
        for s, c in sev.items()
    )
    console.print(
        Panel.fit(
            f"[bold green]Authenticated scan complete[/bold green]\n"
            f"ID: [cyan]{engagement['id']}[/cyan]\n"
            f"Endpoints tested: {result.get('endpoints_tested', 0)}\n"
            f"Findings: {result.get('findings_count', 0)}  {sev_line}\n"
            f"Next: [dim]ptai findings {engagement['id']}[/dim]",
            title="Done",
        )
    )


@app.command()
def mcp(
    transport: str = typer.Option("stdio", "--transport", help="MCP transport: stdio, sse"),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host for sse transport"),
    port: int = typer.Option(8765, "--port", help="Bind port for sse transport"),
) -> None:
    """Run the pentest-ai MCP server.

    Point any MCP-compatible client (Claude Code, Claude Desktop, Cursor,
    VS Code Copilot, Windsurf) at this command to expose pentest-ai's tools
    to your AI assistant.

    Quick registration with Claude Code:

        claude mcp add pentest-ai -- ptai mcp

    Or run `ptai setup --mcp` for an interactive wizard that configures
    Claude Desktop, Cursor, and VS Code automatically.
    """
    from mcp_server.server import run_server

    run_server(transport=transport, host=host, port=port)


@app.command(name="list")
def list_engagements(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of engagements to show"),
    status_filter: str | None = typer.Option(None, "--status", help="Filter by status"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """List all pentest engagements."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _fetch():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            return await db.list_engagements(limit=limit, status_filter=status_filter)
        finally:
            await db.close()

    engagements = asyncio.run(_fetch())

    if ci:
        print(json.dumps(engagements, default=str))
        return

    if not engagements:
        console.print("[dim]No engagements found.[/dim]")
        return

    table = Table(title=f"Engagements ({len(engagements)})")
    table.add_column("ID", style="cyan")
    table.add_column("Target")
    table.add_column("Scope")
    table.add_column("Status")
    table.add_column("Findings")
    table.add_column("Started")

    status_colors = {"running": "yellow", "completed": "green", "failed": "red", "paused": "dim"}

    for eng in engagements:
        eng_status = eng.get("status", "unknown")
        color = status_colors.get(eng_status, "dim")
        sev = eng.get("by_severity", {})
        finding_str = str(eng.get("total_findings", 0))
        if sev.get("critical"):
            finding_str += f" [red]({sev['critical']}C)[/red]"
        if sev.get("high"):
            finding_str += f" [yellow]({sev['high']}H)[/yellow]"
        table.add_row(
            eng["id"],
            eng.get("target", ""),
            eng.get("scope", ""),
            f"[{color}]{eng_status}[/{color}]",
            finding_str,
            eng.get("created_at", "")[:19],
        )

    console.print(table)


@app.command()
def resume(
    engagement_id: str = typer.Argument(..., help="Engagement ID to resume"),
):
    """Resume an interrupted engagement from its last checkpoint."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB
    from engine.orchestrator import AgentOrchestrator

    async def _resume():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            eng = await db.get_engagement(engagement_id)
            if not eng:
                return None, None
            checkpoint = await db.get_checkpoint(engagement_id)
            orch = AgentOrchestrator(db=db)
            await orch.resume_engagement(eng)
            return eng, checkpoint
        finally:
            await db.close()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(f"[green]Resuming engagement {engagement_id}...", total=None)
        eng, checkpoint = asyncio.run(_resume())

    if not eng:
        console.print(f"[red]Engagement not found: {engagement_id}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]Engagement {engagement_id} resumed and completed.[/green]")


# ============================================================================
# AUTH — link the CLI to an app.pentestai.xyz workspace for findings sync.
# pentest-ai works fully locally without this; auth is opt-in.
# ============================================================================
auth_app = typer.Typer(
    name="auth",
    help="Link the CLI to your pentest-ai dashboard (optional · Pro/Team/Enterprise)",
    no_args_is_help=True,
)
app.add_typer(auth_app, name="auth")


def _auth_status_panel() -> None:
    from cli.auth import CREDENTIALS_FILE, ENV_VAR_NAME, key_source, load_api_key, mask_key, api_base
    key = load_api_key()
    if not key:
        console.print(
            "[dim]Not linked to any dashboard.[/dim] "
            "[cyan]pentest-ai auth login[/cyan] to connect one.\n"
            "All CLI features run fully offline without a dashboard."
        )
        return
    src = key_source()
    src_line = {
        "env":  f"[cyan]{ENV_VAR_NAME}[/cyan] environment variable",
        "file": f"[cyan]{CREDENTIALS_FILE}[/cyan] (0600)",
    }.get(src or "", "(unknown)")
    console.print(
        Panel.fit(
            f"Key:    [green]{mask_key(key)}[/green]\n"
            f"Source: {src_line}\n"
            f"Host:   [cyan]{api_base()}[/cyan]",
            title="Dashboard link",
            border_style="green",
        )
    )


@auth_app.command("login")
def auth_login(
    api_key: str | None = typer.Argument(
        None,
        help="API key from app.pentestai.xyz (leave blank to be prompted securely)",
    ),
    no_verify: bool = typer.Option(
        False,
        "--no-verify",
        help="Skip the remote validation round-trip (store the key blindly).",
    ),
):
    """Link this CLI to your dashboard workspace.

    Get a key at https://app.pentestai.xyz/dashboard → API Keys → Generate.
    If no key is passed as an argument, you'll be prompted (hidden input).
    """
    from cli.auth import store_api_key, validate_key_remote, api_base

    if not api_key:
        api_key = typer.prompt("API key (pasted, hidden)", hide_input=True).strip()

    if not api_key.startswith("ptai_"):
        console.print("[red]Key must start with [bold]ptai_[/bold][/red]")
        raise typer.Exit(1)

    if no_verify:
        store_api_key(api_key)
        console.print("[yellow]Stored key without remote validation.[/yellow]")
        _auth_status_panel()
        return

    console.print("[dim]Validating against[/dim] " + api_base())
    result = validate_key_remote(api_key)
    if not result:
        console.print(
            "[red]Key rejected.[/red] Check that you pasted the full key and that "
            "your dashboard user still has access to this key."
        )
        raise typer.Exit(1)

    store_api_key(api_key)
    plan = str(result.get("plan", "")).upper() or "LINKED"
    console.print(
        Panel.fit(
            f"Plan:  [bold green]{plan}[/bold green]\n"
            f"Org:   [cyan]{result.get('organization_id', '—')}[/cyan]\n"
            "Your future scans will auto-sync findings to the dashboard.",
            title="Linked to pentest-ai",
            border_style="green",
        )
    )


@auth_app.command("status")
def auth_status_cmd():
    """Show current dashboard link."""
    _auth_status_panel()


@auth_app.command("whoami")
def auth_whoami():
    """Re-validate the current key and show the workspace it belongs to."""
    from cli.auth import load_api_key, validate_key_remote, mask_key
    key = load_api_key()
    if not key:
        console.print("[dim]Not linked.[/dim] Run [cyan]pentest-ai auth login[/cyan] first.")
        raise typer.Exit(1)
    result = validate_key_remote(key)
    if not result:
        console.print(
            "[red]Key is no longer valid.[/red] It may have been revoked in the dashboard. "
            "Run [cyan]pentest-ai auth logout[/cyan] then [cyan]auth login[/cyan] with a fresh key."
        )
        raise typer.Exit(1)
    console.print(
        Panel.fit(
            f"Key:   [green]{mask_key(key)}[/green]\n"
            f"Plan:  [bold green]{str(result.get('plan', '')).upper()}[/bold green]\n"
            f"Org:   [cyan]{result.get('organization_id', '—')}[/cyan]\n"
            f"Features: {', '.join(result.get('features', [])) or '(free tier)'}",
            title="Workspace",
            border_style="green",
        )
    )


@auth_app.command("logout")
def auth_logout(
    confirm: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the confirmation prompt.",
    ),
):
    """Remove the stored API key from this machine."""
    from cli.auth import CREDENTIALS_FILE, ENV_VAR_NAME, key_source, remove_credentials

    src = key_source()
    if src is None:
        console.print("[dim]No stored key — nothing to remove.[/dim]")
        return

    if src == "env":
        console.print(
            f"[yellow]Your key lives in the [cyan]{ENV_VAR_NAME}[/cyan] env var, "
            "not in a file. Unset it in your shell instead:[/yellow]\n"
            f"  [dim]unset {ENV_VAR_NAME}[/dim]"
        )
        return

    if not confirm:
        if not typer.confirm(f"Remove {CREDENTIALS_FILE}?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    remove_credentials()
    console.print("[green]Unlinked from dashboard.[/green] All local features still work.")


@app.command()
def status(
    engagement_id: str = typer.Argument(..., help="Engagement ID"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """Check the status of an engagement."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _fetch():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            eng = await db.get_engagement(engagement_id)
            summary = await db.get_engagement_summary(engagement_id)
            checkpoint = await db.get_checkpoint(engagement_id)
            return eng, summary, checkpoint
        finally:
            await db.close()

    eng, summary, checkpoint = asyncio.run(_fetch())

    if not eng:
        if ci:
            _ci_print("not_found", {"engagement_id": engagement_id})
            raise typer.Exit(1)
        console.print(f"[red]Engagement not found: {engagement_id}[/red]")
        raise typer.Exit(1)

    if ci:
        print(json.dumps({"engagement": eng, "summary": summary, "checkpoint": checkpoint}, default=str))
        return

    sev = summary.get("by_severity", {})
    sev_line = "  ".join(
        f"[{'red' if s == 'critical' else 'yellow' if s == 'high' else 'blue' if s == 'medium' else 'dim'}]{s.upper()}: {c}[/]"
        for s, c in sev.items()
    )

    phase_info = ""
    if checkpoint and checkpoint.get("current_phase"):
        completed = checkpoint.get("completed_phases", [])
        phase_info = f"\n[bold]Current Phase:[/bold] {checkpoint['current_phase']}\n[bold]Completed:[/bold] {', '.join(completed) if completed else 'none'}"

    console.print(
        Panel.fit(
            f"[bold]Target:[/bold] [cyan]{eng['target']}[/cyan]\n"
            f"[bold]Status:[/bold] {eng['status']}\n"
            f"[bold]Scope:[/bold] {eng.get('scope', 'full')}\n"
            f"[bold]Started:[/bold] {eng['created_at']}\n"
            f"[bold]Findings:[/bold] {summary['total_findings']}  {sev_line}\n"
            f"[bold]Attack Chains:[/bold] {summary.get('attack_chains', 0)}\n"
            f"[bold]Detection Rules:[/bold] {summary.get('detection_rules', 0)}"
            f"{phase_info}",
            title=f"Engagement {engagement_id}",
        )
    )


@app.command()
def findings(
    engagement_id: str = typer.Argument(..., help="Engagement ID"),
    severity: str = typer.Option(None, "--severity", "-s", help="Filter by severity (critical, high, medium, low, info)"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """List findings from an engagement."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _fetch():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            return await db.get_findings(engagement_id=engagement_id, severity=severity)
        finally:
            await db.close()

    rows = asyncio.run(_fetch())

    if ci:
        print(json.dumps(rows, default=str))
        return

    if not rows:
        console.print("[dim]No findings found.[/dim]")
        return

    severity_colors = {"critical": "red", "high": "yellow", "medium": "blue", "low": "dim", "info": "dim"}
    label = f"Findings for {engagement_id}"
    if severity:
        label += f" [{severity}]"

    table = Table(title=label)
    table.add_column("Severity", style="bold")
    table.add_column("Title", max_width=50)
    table.add_column("CVSS", justify="right")
    table.add_column("Target")
    table.add_column("Category")
    table.add_column("CWE")
    table.add_column("Status")

    for r in rows:
        sev = r.get("severity", "info").lower()
        color = severity_colors.get(sev, "dim")
        cvss = r.get("cvss_score", 0.0)
        cvss_str = f"{cvss:.1f}" if cvss else "-"
        table.add_row(
            f"[{color}]{sev.upper()}[/{color}]",
            r.get("title", ""),
            cvss_str,
            r.get("target", ""),
            r.get("category", ""),
            r.get("cwe_id", "") or "-",
            r.get("status", ""),
        )

    console.print(table)


@app.command()
def tools(
    category: str = typer.Option(None, "--category", "-c", help="Filter by category"),
    source: str = typer.Option(None, "--source", help="Filter by source: builtin, plugin"),
):
    """List available security tools and their install status."""
    from tools.registry import ToolRegistry

    registry = ToolRegistry()
    all_tools = registry.list_tools()

    table = Table(title=f"Security Tools ({len(all_tools)} registered)")
    table.add_column("Tool", style="cyan")
    table.add_column("Category")
    table.add_column("Description", max_width=50)
    table.add_column("Source")
    table.add_column("Installed")

    for tool in sorted(all_tools, key=lambda t: (t.category, t.name)):
        if category and tool.category != category:
            continue
        tool_source = getattr(tool, "source", "builtin")
        if source and tool_source != source:
            continue
        installed = "[green]Yes[/green]" if tool.is_installed() else "[red]No[/red]"
        table.add_row(tool.name, tool.category, tool.description[:50], tool_source, installed)

    console.print(table)


@app.command()
def report(
    engagement_id: str = typer.Argument(..., help="Engagement ID"),
    format: str = typer.Option("markdown", "--format", "-f", help="Report format: markdown, html, pdf, json, sarif, junit"),
    output: str = typer.Option(None, "--output", "-o", help="Output file path (overrides default)"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """Generate a pentest report."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    if format in ("sarif", "junit"):
        async def _export():
            db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
            try:
                eng = await db.get_engagement(engagement_id)
                if not eng:
                    return None
                findings_list = await db.get_findings(engagement_id=engagement_id)
                return eng, findings_list
            finally:
                await db.close()

        result = asyncio.run(_export())
        if not result:
            console.print(f"[red]Engagement not found: {engagement_id}[/red]")
            raise typer.Exit(1)

        eng, findings_list = result

        if format == "sarif":
            from engine.sarif import findings_to_sarif
            export_data = findings_to_sarif(findings_list, eng)
            out_path = output or f"reports/{engagement_id}.sarif.json"
        else:
            from engine.junit_xml import findings_to_junit
            export_data = findings_to_junit(findings_list, eng)
            out_path = output or f"reports/{engagement_id}.junit.xml"

        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w") as f:
            if isinstance(export_data, dict):
                json.dump(export_data, f, indent=2)
            else:
                f.write(export_data)

        if ci:
            print(json.dumps({"format": format, "path": out_path, "findings": len(findings_list)}))
        else:
            console.print(f"[green]Exported {format.upper()} to:[/green] [cyan]{out_path}[/cyan]")
        return

    from agents.report.report_agent import ReportAgent

    async def _generate():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            eng = await db.get_engagement(engagement_id)
            if not eng:
                return None
            agent = ReportAgent(db=db)
            return await agent.generate_report(engagement_id, format=format)
        finally:
            await db.close()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task(f"[green]Generating {format} report...", total=None)
        result = asyncio.run(_generate())

    if not result:
        console.print(f"[red]Engagement not found: {engagement_id}[/red]")
        raise typer.Exit(1)

    path = output or result.get("output_path", "")

    if ci:
        print(json.dumps({"format": format, "path": path, "findings": result.get("total_findings", 0)}))
    else:
        console.print(
            Panel.fit(
                f"[bold]Format:[/bold] {format}\n"
                f"[bold]Findings:[/bold] {result.get('total_findings', 0)}\n"
                f"[bold]Attack Chains:[/bold] {result.get('attack_chains', 0)}\n"
                f"[bold]Saved to:[/bold] [cyan]{path}[/cyan]",
                title="Report Generated",
            )
        )


@app.command()
def setup(
    tier: str = typer.Option("recommended", "--tier", "-t", help="Install tier: core, recommended, full, skip"),
    list_tools: bool = typer.Option(False, "--list", "-l", help="List tool status without installing"),
    mcp: bool = typer.Option(False, "--mcp", help="Configure MCP clients (Claude Desktop, Cursor, VS Code)"),
    auto_inject: bool = typer.Option(False, "--auto-inject", help="Auto-write MCP config without prompting"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what MCP config changes would be made"),
    plugins: bool = typer.Option(False, "--plugins", help="List installed plugins"),
    init: bool = typer.Option(False, "--init", help="Generate default config file at ~/.pentest-ai/config.yaml"),
    show_config: bool = typer.Option(False, "--show-config", help="Show resolved configuration (secrets masked)"),
):
    """Install external security tools or configure MCP clients.

    Tool tiers control how many tools to install:
      core (~200MB): nmap, nuclei, nikto, sqlmap, whatweb, sslscan
      recommended (~500MB): core + gobuster, ffuf, httpx, subfinder, hydra, etc.
      full (~2GB+): everything including metasploit, aircrack-ng, AD tools
      skip: install nothing, use only built-in scanners

    MCP setup (--mcp) detects installed AI clients and configures them
    to use pentest-ai as an MCP server.
    """
    if init:
        from config.settings import generate_default_config

        path = generate_default_config()
        console.print(f"[green]Config file created:[/green] [cyan]{path}[/cyan]")
        return

    if show_config:
        from config.settings import load_config

        config = load_config()
        console.print_json(data=config.to_dict(mask_secrets=True))
        return

    if mcp:
        from cli.mcp_setup import run_mcp_setup

        run_mcp_setup(auto_inject=auto_inject, dry_run=dry_run)
        return

    if plugins:
        from tools.plugin_loader import load_plugins

        loaded = load_plugins()
        if not loaded:
            console.print("[dim]No plugins found in ~/.pentest-ai/plugins/[/dim]")
            console.print("Create YAML plugin files to extend pentest-ai with custom tools.")
            return

        table = Table(title=f"Installed Plugins ({len(loaded)})")
        table.add_column("Name", style="cyan")
        table.add_column("Category")
        table.add_column("Command")
        table.add_column("Description", max_width=50)

        for p in loaded:
            table.add_row(p["name"], p["category"], p["command"], p["description"][:50])

        console.print(table)
        return

    from engine.tool_installer import (
        InstallTier,
        audit_tools,
        install_tier,
        print_audit,
    )

    if list_tools:
        audit = audit_tools()
        print_audit(audit)
        return

    if tier == "skip":
        console.print("[dim]Skipping tool installation. Built-in scanners are always available.[/dim]")
        return

    tier_map = {"core": InstallTier.CORE, "recommended": InstallTier.RECOMMENDED, "full": InstallTier.FULL}
    if tier not in tier_map:
        console.print(f"[red]Unknown tier: {tier}. Choose: core, recommended, full, skip[/red]")
        raise typer.Exit(1)

    install_tier(tier_map[tier])


@app.command()
def campaign(
    campaign_id: str = typer.Argument(..., help="Campaign ID"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """Show summary for a multi-target campaign."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _fetch():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            return await db.get_campaign_summary(campaign_id)
        finally:
            await db.close()

    summary = asyncio.run(_fetch())

    if "error" in summary:
        console.print(f"[red]{summary['error']}[/red]")
        raise typer.Exit(1)

    if ci:
        print(json.dumps(summary, default=str))
        return

    console.print(
        Panel.fit(
            f"[bold]Name:[/bold] {summary['name']}\n"
            f"[bold]Targets:[/bold] {summary['target_count']}\n"
            f"[bold]Total Findings:[/bold] {summary['total_findings']}\n"
            f"[bold]Status:[/bold] {summary['status']}",
            title=f"Campaign {campaign_id}",
        )
    )

    if summary.get("engagements"):
        table = Table(title="Engagements")
        table.add_column("ID", style="cyan")
        table.add_column("Target")
        table.add_column("Status")

        for eng in summary["engagements"]:
            table.add_row(eng["id"], eng.get("target", ""), eng.get("status", ""))

        console.print(table)


@app.command()
def diff(
    prev_id: str = typer.Argument(..., help="Previous engagement ID"),
    curr_id: str = typer.Argument(..., help="Current engagement ID"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """Show new / resolved / unchanged findings between two engagements."""
    import asyncio
    import os

    from engine.diff import compute_diff
    from engine.findings_db import FindingsDB

    async def _fetch():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            prev = await db.get_findings(engagement_id=prev_id)
            curr = await db.get_findings(engagement_id=curr_id)
            return prev, curr
        finally:
            await db.close()

    prev, curr = asyncio.run(_fetch())
    diff_result = compute_diff(prev_id, curr_id, prev, curr)

    if ci:
        print(json.dumps(diff_result.to_dict(), default=str))
        return

    console.print(
        Panel.fit(
            f"[bold red]New:[/bold red] {diff_result.total_new}\n"
            f"[bold green]Resolved:[/bold green] {diff_result.total_resolved}\n"
            f"[bold yellow]Unchanged:[/bold yellow] {diff_result.total_unchanged}",
            title=f"Diff {prev_id} → {curr_id}",
        )
    )

    for bucket, color in (("new", "red"), ("resolved", "green"), ("unchanged", "yellow")):
        items = getattr(diff_result, bucket)
        if not items:
            continue
        table = Table(title=f"[{color}]{bucket.title()}[/{color}]")
        table.add_column("Severity", style="bold")
        table.add_column("Title")
        table.add_column("Target", style="cyan")
        for f in items[:50]:
            table.add_row(f.get("severity", "info"), f.get("title", ""), f.get("target", ""))
        console.print(table)


@app.command()
def retest(
    engagement_id: str = typer.Argument(..., help="Engagement to re-test (clones target/scope/intensity)"),
    ci: bool = typer.Option(False, "--ci", help="JSON output for CI/CD"),
):
    """Create a new engagement linked to an existing one for re-testing."""
    import asyncio
    import os

    from engine.findings_db import FindingsDB

    async def _retest():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            prev = await db.get_engagement(engagement_id)
            if not prev:
                return None
            new = await db.create_engagement(
                target=prev["target"],
                scope=prev.get("scope", "full"),
                rules_of_engment=prev.get("rules_of_engment", ""),
                intensity=prev.get("intensity", "normal"),
                parent_engagement_id=engagement_id,
            )
            return new
        finally:
            await db.close()

    result = asyncio.run(_retest())

    if result is None:
        console.print(f"[red]Engagement {engagement_id} not found.[/red]")
        raise typer.Exit(1)

    if ci:
        print(json.dumps(result, default=str))
        return

    console.print(
        Panel.fit(
            f"[bold green]Retest engagement created[/bold green]\n"
            f"ID: [cyan]{result['id']}[/cyan]\n"
            f"Parent: [dim]{engagement_id}[/dim]\n"
            f"Target: [cyan]{result['target']}[/cyan]\n"
            f"Run scans, then: [dim]ptai diff {engagement_id} {result['id']}[/dim]",
            title="Retest",
        )
    )


ci_app = typer.Typer(help="CI/CD integration (SARIF, severity gates, PR comments).")
app.add_typer(ci_app, name="ci")


@ci_app.command("report")
def ci_report(
    engagement_id: str = typer.Argument(..., help="Engagement ID to report on"),
    fail_on: str = typer.Option("high", "--fail-on", help="Gate severity: critical|high|medium|low|info"),
    sarif: str = typer.Option("", "--sarif", help="Write SARIF output to this path"),
    comment: bool = typer.Option(
        False, "--comment", help="Post a PR comment (needs GITHUB_TOKEN + GITHUB_REPOSITORY + PR context)"
    ),
    json_out: bool = typer.Option(True, "--json/--no-json", help="Print JSON summary to stdout"),
):
    """Turn an engagement into a CI gate: SARIF + severity threshold + exit code."""
    import asyncio
    import os

    from cli.ci import build_report, post_pr_comment, write_github_output
    from engine.findings_db import FindingsDB

    async def _run():
        db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            engagement = await db.get_engagement(engagement_id)
            if not engagement:
                return None, None
            findings = await db.get_findings(engagement_id=engagement_id)
            report = build_report(
                engagement,
                findings,
                threshold=fail_on,
                sarif_output=sarif or None,
            )
            posted = False
            if comment:
                posted = await post_pr_comment(report)
            return report, posted
        finally:
            await db.close()

    report, posted = asyncio.run(_run())

    if report is None:
        console.print(f"[red]Engagement {engagement_id} not found.[/red]")
        raise typer.Exit(2)

    write_github_output(report)

    if json_out:
        print(json.dumps({**report.to_dict(), "pr_comment_posted": posted}, default=str))

    raise typer.Exit(report.exit_code)


webauth_app = typer.Typer(help="Authenticated/stateful scanning helpers.")
app.add_typer(webauth_app, name="webauth")


@webauth_app.command("login")
def auth_login(
    flow: str = typer.Option(..., "--flow", help="Flow type: form_post, bearer_static"),
    login_url: str = typer.Option("", "--login-url", help="Login endpoint (form_post)"),
    username: str = typer.Option("", "--username", help="Username (form_post)"),
    password_env: str = typer.Option(
        "", "--password-env", help="Environment variable holding the password"
    ),
    username_field: str = typer.Option("username", "--username-field"),
    password_field: str = typer.Option("password", "--password-field"),
    success_marker: str = typer.Option(
        "", "--success-marker", help="Substring that must appear in the login response body"
    ),
    bearer_token_env: str = typer.Option(
        "", "--bearer-token-env", help="Env var holding the static bearer token"
    ),
    ci: bool = typer.Option(False, "--ci"),
):
    """Perform an auth flow and print the resulting session credentials."""
    import asyncio
    import os

    from engine.auth_session import AuthError, WebAuthenticator

    password = os.environ.get(password_env, "") if password_env else ""
    bearer = os.environ.get(bearer_token_env, "") if bearer_token_env else ""

    auth = WebAuthenticator(
        flow=flow,
        login_url=login_url,
        username=username,
        password=password,
        username_field=username_field,
        password_field=password_field,
        success_marker=success_marker,
        bearer_token=bearer,
    )

    try:
        session = asyncio.run(auth.login())
    except AuthError as e:
        console.print(f"[red]Auth failed:[/red] {e}")
        raise typer.Exit(1) from e

    if ci:
        print(json.dumps(session.to_dict(), default=str))
        return

    cookie_str = session.cookie_string() or "(none)"
    console.print(
        Panel.fit(
            f"[bold green]Authenticated[/bold green] via {session.flow}\n"
            f"Cookies: [cyan]{cookie_str}[/cyan]\n"
            f"Bearer: [cyan]{'set' if session.bearer_token else 'none'}[/cyan]\n"
            f"Expires in: [yellow]"
            f"{int((session.expires_at or 0) - session.created_at)}s[/yellow]",
            title="Auth Session",
        )
    )


cache_app = typer.Typer(help="Inspect or manage the tool-result cache.")
app.add_typer(cache_app, name="cache")


@cache_app.command("stats")
def cache_stats():
    """Show cache size, live entries, and per-tool breakdown."""
    import asyncio

    from engine.cache import ToolResultCache

    async def _run():
        c = ToolResultCache()
        try:
            return await c.stats()
        finally:
            await c.close()

    s = asyncio.run(_run())
    console.print(
        Panel.fit(
            f"[bold]DB:[/bold] {s['db_path']}\n"
            f"[bold]Size:[/bold] {s['db_size_bytes']:,} bytes\n"
            f"[bold]Live entries:[/bold] {s['live_entries']}\n"
            f"[bold]Expired entries:[/bold] {s['expired_entries']}",
            title="Cache Stats",
        )
    )
    if s["by_tool"]:
        table = Table(title="Live entries by tool")
        table.add_column("Tool", style="cyan")
        table.add_column("Count", justify="right")
        for tool, n in s["by_tool"]:
            table.add_row(tool, str(n))
        console.print(table)


@cache_app.command("clear")
def cache_clear():
    """Drop every cached entry."""
    import asyncio

    from engine.cache import ToolResultCache

    async def _run():
        c = ToolResultCache()
        try:
            return await c.clear()
        finally:
            await c.close()

    removed = asyncio.run(_run())
    console.print(f"[green]Cleared {removed} cache entr{'y' if removed == 1 else 'ies'}.[/green]")


@cache_app.command("expire")
def cache_expire():
    """Drop only expired entries."""
    import asyncio

    from engine.cache import ToolResultCache

    async def _run():
        c = ToolResultCache()
        try:
            return await c.expire()
        finally:
            await c.close()

    removed = asyncio.run(_run())
    console.print(f"[green]Removed {removed} expired entr{'y' if removed == 1 else 'ies'}.[/green]")


llm_app = typer.Typer(help="LLM red-team probes (OWASP LLM Top 10).")
app.add_typer(llm_app, name="llm-redteam")


@llm_app.command("run")
def llm_redteam_run(
    target: str = typer.Argument(..., help="LLM endpoint URL"),
    engagement_id: str = typer.Option("", "--engagement-id", help="Engagement to record findings against"),
    schema: str = typer.Option("openai", "--schema", help="openai|simple|custom"),
    model: str = typer.Option("gpt-3.5-turbo", "--model"),
    header: list[str] = typer.Option([], "--header", "-H", help="Extra header; repeatable (e.g. 'Authorization: Bearer x')"),
    concurrency: int = typer.Option(4, "--concurrency"),
    corpus: str = typer.Option("", "--corpus", help="Custom YAML corpus path"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Run the LLM red-team probe corpus against an LLM target."""
    import asyncio
    import os

    from agents.llm_redteam import LLMRedTeamAgent, LLMTargetAdapter
    from engine.findings_db import FindingsDB

    headers = {}
    for h in header:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()

    adapter = LLMTargetAdapter(url=target, schema=schema, model=model, headers=headers)

    async def _run():
        db = None
        if engagement_id:
            db = FindingsDB(os.getenv("PENTEST_DB_PATH", "pentest_findings.db"))
        try:
            agent = LLMRedTeamAgent(adapter=adapter, db=db, corpus_path=corpus or None, concurrency=concurrency)
            return await agent.run(engagement_id=engagement_id)
        finally:
            if db:
                await db.close()

    report = asyncio.run(_run())

    if json_out:
        print(json.dumps(report.to_dict(), default=str))
    else:
        console.print(
            Panel.fit(
                f"[bold]LLM Red-Team[/bold]\n"
                f"Target: [cyan]{report.target}[/cyan]\n"
                f"Probes run: [yellow]{report.total}[/yellow]\n"
                f"Findings fired: [red]{report.fired}[/red]\n"
                f"Recorded: [green]{report.findings_recorded}[/green]",
                title="LLM Red-Team Report",
            )
        )
        for r in report.results:
            if r.fired:
                console.print(f"[red]✗[/red] {r.probe_id} ({r.category}, {r.severity}) — matched: {r.matched}")


playbook_app = typer.Typer(help="Manage and run YAML playbooks (methodology-as-code).")
app.add_typer(playbook_app, name="playbook")


@playbook_app.command("list")
def playbook_list():
    """List all discoverable playbooks (builtin + user)."""
    from engine.playbook import discover_playbooks

    pbs = discover_playbooks()
    if not pbs:
        console.print("[yellow]No playbooks found.[/yellow]")
        return

    table = Table(title="Playbooks")
    table.add_column("Name", style="cyan")
    table.add_column("Version")
    table.add_column("Intensity")
    table.add_column("Phases", justify="right")
    table.add_column("Description")
    for pb in pbs:
        table.add_row(pb.name, pb.version, pb.intensity, str(len(pb.phases)), pb.description)
    console.print(table)


@playbook_app.command("show")
def playbook_show(name_or_path: str = typer.Argument(..., help="Playbook name or path")):
    """Show a playbook's phases, inputs, and execution plan."""
    from engine.playbook import find_playbook, plan_phases

    pb = find_playbook(name_or_path)
    console.print(
        Panel.fit(
            f"[bold]{pb.name}[/bold]  v{pb.version}  ({pb.intensity})\n"
            f"{pb.description}\n"
            f"Authors: {', '.join(pb.authors) or '-'}\n"
            f"Source:  {pb.path}",
            title="Playbook",
        )
    )

    if pb.inputs:
        inp_tbl = Table(title="Inputs")
        inp_tbl.add_column("Name", style="cyan")
        inp_tbl.add_column("Required")
        inp_tbl.add_column("Default")
        inp_tbl.add_column("Prompt")
        for n, spec in pb.inputs.items():
            inp_tbl.add_row(n, "yes" if spec.required else "no", spec.default or "-", spec.prompt or "-")
        console.print(inp_tbl)

    plan = plan_phases(pb, findings=[])
    ph_tbl = Table(title="Phases")
    ph_tbl.add_column("#", justify="right")
    ph_tbl.add_column("Phase", style="cyan")
    ph_tbl.add_column("Tools")
    ph_tbl.add_column("Depends on")
    ph_tbl.add_column("Condition")
    ph_tbl.add_column("Manual")
    for i, (phase, _will, _reason) in enumerate(plan, 1):
        ph_tbl.add_row(
            str(i),
            phase.id,
            ", ".join(phase.tools) or "-",
            ", ".join(phase.depends_on) or "-",
            phase.condition or "-",
            "yes" if phase.manual else "no",
        )
    console.print(ph_tbl)


@playbook_app.command("validate")
def playbook_validate(path: str = typer.Argument(..., help="Path to YAML playbook")):
    """Lint a playbook file against the schema."""
    from engine.playbook import PlaybookError, load_playbook

    try:
        pb = load_playbook(path)
    except PlaybookError as e:
        console.print(f"[red]invalid:[/red] {e}")
        raise typer.Exit(1) from e
    console.print(f"[green]OK {pb.name} (v{pb.version}) - {len(pb.phases)} phases[/green]")


@playbook_app.command("run")
def playbook_run(
    name_or_path: str = typer.Argument(..., help="Playbook name or path"),
    inputs: list[str] = typer.Option([], "--input", "-i", help="key=value; repeatable"),
    dry_run: bool = typer.Option(True, "--dry-run/--execute", help="Plan only (default) or execute"),
):
    """Plan (default) or execute a playbook.

    Execution is not yet wired to the orchestrator; dry-run prints the phase
    order and gating decisions that would be applied at runtime.
    """
    from engine.playbook import find_playbook, plan_phases, resolve_inputs

    pb = find_playbook(name_or_path)

    provided = {}
    for item in inputs:
        if "=" not in item:
            console.print(f"[yellow]skipping malformed input: {item}[/yellow]")
            continue
        k, v = item.split("=", 1)
        provided[k.strip()] = v.strip()

    resolved = resolve_inputs(pb, provided)
    console.print(Panel.fit(f"[bold]{pb.name}[/bold] - inputs: {resolved}", title="Playbook Run"))

    plan = plan_phases(pb, findings=[])
    for phase, will_run, reason in plan:
        status = "[green]RUN[/green]" if will_run else f"[yellow]SKIP[/yellow] ({reason})"
        console.print(f"  {status}  {phase.id}  tools={phase.tools or '-'}")

    if not dry_run:
        console.print(
            "[yellow]--execute is not yet wired to the orchestrator; "
            "playbook execution lands in the next sub-phase.[/yellow]"
        )


if __name__ == "__main__":
    app()
