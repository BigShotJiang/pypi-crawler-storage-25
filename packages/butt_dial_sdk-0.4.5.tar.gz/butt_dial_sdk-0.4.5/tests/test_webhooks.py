"""Tests for buttdial.webhooks — HMAC signature verification."""

from __future__ import annotations

import hashlib
import hmac
import time

from buttdial.webhooks import verify_webhook_signature

SECRET = "wh_secret_64chars_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"


def _sign(secret: str, ts: int, body: bytes) -> str:
    """Compute the same signature BD would emit, for fixture construction."""
    payload = f"{ts}.{body.decode('utf-8')}".encode()
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def test_valid_signature_passes() -> None:
    body = b'{"event":"account.verified","orgId":"org-1"}'
    ts = int(time.time())
    sig = _sign(SECRET, ts, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
        )
        is True
    )


def test_wrong_secret_fails() -> None:
    body = b'{"event":"account.verified"}'
    ts = int(time.time())
    sig = _sign(SECRET, ts, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret="not-the-real-secret",
        )
        is False
    )


def test_tampered_body_fails() -> None:
    """Re-serializing the parsed body must fail — body bytes are canonical."""
    body = b'{"event":"account.verified","orgId":"org-1"}'
    ts = int(time.time())
    sig = _sign(SECRET, ts, body)
    tampered = b'{"event":"account.verified","orgId":"org-2"}'  # one char diff
    assert (
        verify_webhook_signature(
            tampered,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
        )
        is False
    )


def test_stale_timestamp_fails() -> None:
    body = b'{"event":"account.verified"}'
    now = 1_700_000_000
    ts_old = now - 600  # 10 min stale, default tolerance is 5 min
    sig = _sign(SECRET, ts_old, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts_old),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
            now=float(now),
        )
        is False
    )


def test_future_timestamp_fails() -> None:
    """Replay-protection rejects far-future timestamps too (defends against clock skew abuse)."""
    body = b'{"event":"account.verified"}'
    now = 1_700_000_000
    ts_future = now + 600  # 10 min in the future
    sig = _sign(SECRET, ts_future, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts_future),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
            now=float(now),
        )
        is False
    )


def test_within_tolerance_passes() -> None:
    body = b'{"event":"account.verified"}'
    now = 1_700_000_000
    ts = now - 200  # 200s old, default 300s tolerance — OK
    sig = _sign(SECRET, ts, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
            now=float(now),
        )
        is True
    )


def test_custom_tolerance_zero_only_now() -> None:
    body = b'{"event":"x"}'
    now = 1_700_000_000
    ts = now - 1
    sig = _sign(SECRET, ts, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
            tolerance_seconds=0,
            now=float(now),
        )
        is False
    )


def test_missing_signature_header_fails() -> None:
    body = b"{}"
    ts = int(time.time())
    assert (
        verify_webhook_signature(
            body, timestamp_header=str(ts), signature_header=None, secret=SECRET
        )
        is False
    )
    assert (
        verify_webhook_signature(body, timestamp_header=str(ts), signature_header="", secret=SECRET)
        is False
    )


def test_missing_timestamp_header_fails() -> None:
    body = b"{}"
    sig = _sign(SECRET, 1_700_000_000, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=None,
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
        )
        is False
    )


def test_malformed_signature_prefix_fails() -> None:
    body = b"{}"
    ts = int(time.time())
    sig = _sign(SECRET, ts, body)
    # Missing or wrong algorithm prefix
    for header in [sig, f"sha256={sig}", f"md5={sig}", "hmac-sha256=", "hmac-sha256"]:
        assert (
            verify_webhook_signature(
                body,
                timestamp_header=str(ts),
                signature_header=header,
                secret=SECRET,
            )
            is False
        )


def test_non_integer_timestamp_fails() -> None:
    body = b"{}"
    sig = _sign(SECRET, int(time.time()), body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header="not-a-number",
            signature_header=f"hmac-sha256={sig}",
            secret=SECRET,
        )
        is False
    )


def test_empty_secret_fails() -> None:
    body = b"{}"
    ts = int(time.time())
    sig = _sign(SECRET, ts, body)
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={sig}",
            secret="",
        )
        is False
    )


def test_uses_constant_time_compare() -> None:
    """Ensure the result is identical for off-by-one signatures (defense against timing attacks).

    We don't try to time it; we just confirm the function uses hmac.compare_digest
    by checking that two near-equal signatures both fail without surprise success.
    """
    body = b'{"x":1}'
    ts = int(time.time())
    correct = _sign(SECRET, ts, body)
    # Flip one hex char
    near_miss = correct[:-1] + ("0" if correct[-1] != "0" else "1")
    assert (
        verify_webhook_signature(
            body,
            timestamp_header=str(ts),
            signature_header=f"hmac-sha256={near_miss}",
            secret=SECRET,
        )
        is False
    )
