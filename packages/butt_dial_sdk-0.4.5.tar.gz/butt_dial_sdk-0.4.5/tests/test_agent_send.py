"""Unit tests for `buttdial.agent.Agent.send_message`.

Tests use monkeypatch on `Agent._call_tool` to avoid hitting the real
MCP/SSE transport. Transport-level behavior (real SSE handshake, tool list)
is covered by the fake server.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from buttdial import Agent, SendResult


def _make_agent(**kwargs: Any) -> Agent:
    defaults: dict[str, Any] = {
        "base_url": "https://fake.test",
        "agent_id": "agt-1",
        "agent_token": "agent-tok",
    }
    defaults.update(kwargs)
    return Agent(**defaults)


@pytest.mark.asyncio
async def test_no_token_returns_config_error() -> None:
    a = Agent(base_url="https://fake.test", agent_id="agt-1")  # no token
    result = await a.send_message(to="+1", body="hi")
    assert isinstance(result, SendResult)
    assert result.failed is True
    assert result.stage_failed == "config"
    assert result.message_sid is None
    assert result.error is not None
    assert "token" in result.error.lower()
    assert result.remediation  # non-empty guidance


@pytest.mark.asyncio
async def test_successful_send_returns_sid(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent()
    captured: dict[str, Any] = {}

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        captured["args"] = args
        return {"messageId": "SM123"}, object()

    monkeypatch.setattr(a, "_call_tool", fake_call)

    result = await a.send_message(to="+972501234567", body="hi", sender_name="Sara")

    assert result.message_sid == "SM123"
    assert result.failed is False
    assert result.ok is True
    assert result.delivered is True
    assert captured["token"] == "agent-tok"
    assert captured["args"]["to"] == "+972501234567"
    assert captured["args"]["body"] == "hi"
    assert captured["args"]["channel"] == "whatsapp"
    assert captured["args"]["senderName"] == "Sara"
    assert "idempotencyKey" in captured["args"]


@pytest.mark.asyncio
async def test_call_site_token_overrides_default(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent(agent_token="default-tok")
    captured: dict[str, Any] = {}

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        return {"messageId": "SM1"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    await a.send_message(to="+1", body="x", agent_token="override-tok")
    assert captured["token"] == "override-tok"


@pytest.mark.asyncio
async def test_default_token_used_when_no_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """Without a per-call agent_token, the agent's stored token is used."""
    a = _make_agent(agent_token="stored-tok")
    captured: dict[str, Any] = {}

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["token"] = token
        return {"messageId": "SM1"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    await a.send_message(to="+1", body="x")
    assert captured["token"] == "stored-tok"


@pytest.mark.asyncio
async def test_retry_three_times_on_transport_error(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent(max_send_attempts=3)
    calls = {"n": 0}

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        calls["n"] += 1
        raise ConnectionError("SSE connection refused")

    async def no_sleep(_delay: float) -> None:
        return None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    monkeypatch.setattr(asyncio, "sleep", no_sleep)

    result = await a.send_message(to="+1", body="x")
    assert calls["n"] == 3
    assert result.failed is True
    assert result.stage_failed == "transport"
    assert result.error is not None
    assert "refused" in result.error.lower()


@pytest.mark.asyncio
async def test_extracts_sid_from_alternate_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    """Responses in the wild use `messageId`, `sid`, or `message_sid` interchangeably."""
    a = _make_agent()

    async def fake_call_sid(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"sid": "SMabc"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call_sid)
    r = await a.send_message(to="+1", body="hi")
    assert r.message_sid == "SMabc"

    async def fake_call_snake(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"message_sid": "SMxyz"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call_snake)
    r = await a.send_message(to="+1", body="hi")
    assert r.message_sid == "SMxyz"


@pytest.mark.asyncio
async def test_missing_sid_returns_failed_like_result(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent()

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"ok": True}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    result = await a.send_message(to="+1", body="hi")
    assert result.message_sid is None
    assert result.ok is False
    assert result.failed is True
    assert result.stage_failed == "parse"


@pytest.mark.asyncio
async def test_server_error_surfaced_in_send_result(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent()

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"error": "agentId is required (or use a client token)"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    result = await a.send_message(to="+1", body="hi")
    assert result.failed is True
    assert result.stage_failed == "server"
    assert "agentid is required" in (result.error or "").lower()
    assert result.remediation is not None
    assert "agent_token" in result.remediation.lower()


@pytest.mark.asyncio
async def test_server_errors_list_variant_is_surfaced(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent()

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        return {"errors": ["bad recipient", "over quota"]}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    result = await a.send_message(to="+1", body="hi")
    assert result.failed is True
    assert "bad recipient" in (result.error or "")
    assert "over quota" in (result.error or "")


@pytest.mark.asyncio
async def test_optional_fields_mapped_to_camel_case(monkeypatch: pytest.MonkeyPatch) -> None:
    a = _make_agent()
    captured: dict[str, Any] = {}

    async def fake_call(token: str, tool_name: str, args: dict[str, Any]) -> tuple[Any, Any]:
        captured["args"] = args
        return {"messageId": "S1"}, None

    monkeypatch.setattr(a, "_call_tool", fake_call)
    await a.send_message(
        to="+1",
        body="hi",
        language="en",
        thread_id="T-1",
        entity_id="E-1",
        reply_msg_id="M-1",
        fallback_channels=["sms"],
        scheduled_at="2026-12-31T00:00:00Z",
        idempotency_key="idem-1",
        extra={"customField": 42},
    )
    args = captured["args"]
    assert args["language"] == "en"
    assert args["threadId"] == "T-1"
    assert args["entityId"] == "E-1"
    assert args["replyMsgId"] == "M-1"
    assert args["fallbackChannels"] == ["sms"]
    assert args["scheduledAt"] == "2026-12-31T00:00:00Z"
    assert args["idempotencyKey"] == "idem-1"
    assert args["customField"] == 42


def test_agent_requires_base_url() -> None:
    with pytest.raises(ValueError, match="base_url"):
        Agent(agent_id="agt-1", agent_token="t")


def test_base_url_synthesises_sse_url() -> None:
    a = Agent(base_url="https://x.test/", agent_id="agt-1", agent_token="t")
    assert a.base_url == "https://x.test"
    assert a.sse_url == "https://x.test/sse"


def test_base_url_with_sse_suffix_is_normalised() -> None:
    """Tolerant: `base_url` may be the full SSE URL (legacy callers)."""
    a = Agent(base_url="https://x.test/sse", agent_id="agt-1", agent_token="t")
    assert a.base_url == "https://x.test"
    assert a.sse_url == "https://x.test/sse"


def test_from_env_reads_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("BUTT_DIAL_BASE_URL", "https://env.test")
    monkeypatch.setenv("BUTT_DIAL_AGENT_ID", "agt-env")
    monkeypatch.setenv("BUTT_DIAL_AGENT_TOKEN", "env-agent-tok")
    monkeypatch.delenv("BUTT_DIAL_URL", raising=False)
    a = Agent.from_env()
    assert a.base_url == "https://env.test"
    assert a.sse_url == "https://env.test/sse"
    assert a.agent_id == "agt-env"
    assert a.agent_token == "env-agent-tok"
