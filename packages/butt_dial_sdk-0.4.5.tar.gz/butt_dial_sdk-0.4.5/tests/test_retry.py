"""Unit tests for `buttdial.retry`."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from typing import Any

import pytest

from buttdial import Agent, FailedMessage, RetryWorker
from buttdial.retry import default_backoff


class FakeRepo:
    """In-memory FailedMessageRepository for tests.

    Records all mutations so tests can assert on them. `fetch_due()` returns a
    queue; tests prime it per-test.
    """

    def __init__(self, due: list[FailedMessage] | None = None) -> None:
        self.due_queue: list[list[FailedMessage]] = [due] if due is not None else []
        self.fetch_calls: list[int] = []
        self.delivered: list[tuple[str, str, int]] = []
        self.incremented: list[tuple[str, int, str, datetime]] = []
        self.dead: list[tuple[str, int, str]] = []

    async def fetch_due(self, limit: int) -> list[FailedMessage]:
        self.fetch_calls.append(limit)
        if not self.due_queue:
            return []
        return self.due_queue.pop(0)

    async def mark_delivered(self, msg_id: str, message_sid: str, retry_count: int) -> None:
        self.delivered.append((msg_id, message_sid, retry_count))

    async def increment_retry(
        self,
        msg_id: str,
        retry_count: int,
        error: str,
        next_retry_at: datetime,
    ) -> None:
        self.incremented.append((msg_id, retry_count, error, next_retry_at))

    async def mark_dead(self, msg_id: str, retry_count: int, error: str) -> None:
        self.dead.append((msg_id, retry_count, error))


def _make_client(send_impl: Any) -> Agent:
    """Build an Agent whose `_call_tool` is replaced with `send_impl`.

    Accepts both ``async (token, args)`` (legacy 2-arg stubs) and
    ``async (token, tool_name, args)`` (current 3-arg shape). The
    legacy form is wrapped so the test bodies can stay terse.
    """
    import inspect

    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    nparams = len(inspect.signature(send_impl).parameters)
    if nparams == 2:

        async def _adapter(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
            return await send_impl(_token, _args)

        c._call_tool = _adapter  # type: ignore[method-assign]
    else:
        c._call_tool = send_impl  # type: ignore[method-assign]
    return c


def _msg(**kwargs: Any) -> FailedMessage:
    defaults: dict[str, Any] = {
        "id": "msg-1",
        "recipient": "+972501234567",
        "body": "hi",
        "channel": "whatsapp",
        "agent_name": "maya",
        "agent_token": "t-1",
        "thread_id": "T-1",
        "entity_id": "E-1",
        "reply_msg_id": "cm-1",
        "retry_count": 0,
        "max_retries": 5,
        "last_error": "timeout",
    }
    defaults.update(kwargs)
    return FailedMessage(**defaults)


# ----- default_backoff ---------------------------------------------------


def test_default_backoff_doubles() -> None:
    assert default_backoff(1) == timedelta(minutes=2)
    assert default_backoff(2) == timedelta(minutes=4)
    assert default_backoff(3) == timedelta(minutes=8)
    assert default_backoff(5) == timedelta(minutes=32)


# ----- run_once: empty ---------------------------------------------------


@pytest.mark.asyncio
async def test_run_once_empty_queue_returns_zero() -> None:
    repo = FakeRepo(due=[])

    async def fail_if_called(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
        raise AssertionError("client should not be called when queue is empty")

    client = _make_client(fail_if_called)
    worker = RetryWorker(repo=repo, client=client)

    count = await worker.run_once()

    assert count == 0
    assert repo.fetch_calls == [20]  # default batch_size
    assert repo.delivered == repo.incremented == repo.dead == []


# ----- run_once: success -------------------------------------------------


@pytest.mark.asyncio
async def test_successful_retry_marks_delivered() -> None:
    repo = FakeRepo(due=[_msg(id="msg-ok", retry_count=0)])

    async def send_ok(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
        return {"messageId": "SM-ok"}, None

    client = _make_client(send_ok)
    worker = RetryWorker(repo=repo, client=client)

    count = await worker.run_once()

    assert count == 1
    assert repo.delivered == [("msg-ok", "SM-ok", 1)]
    assert repo.incremented == []
    assert repo.dead == []


@pytest.mark.asyncio
async def test_send_args_forwarded_from_failed_message() -> None:
    """Fields from FailedMessage flow through to Agent.send_message."""
    repo = FakeRepo(
        due=[
            _msg(
                id="msg-x",
                recipient="+100",
                body="retry me",
                channel="sms",
                agent_token="tok",
                agent_name="alice",
                thread_id="T",
                entity_id="E",
                reply_msg_id="R",
            )
        ]
    )
    captured: dict[str, Any] = {}

    async def capture(token: str, _tool: str, args: dict[str, Any]) -> Any:
        captured["token"] = token
        captured["args"] = args
        return {"messageId": "SM1"}, None

    client = _make_client(capture)
    worker = RetryWorker(repo=repo, client=client)

    await worker.run_once()

    assert captured["token"] == "tok"  # agent_token wins
    args = captured["args"]
    assert args["to"] == "+100"
    assert args["body"] == "retry me"
    assert args["channel"] == "sms"
    assert args["senderName"] == "alice"
    assert args["threadId"] == "T"
    assert args["entityId"] == "E"
    assert args["replyMsgId"] == "R"


# ----- run_once: backoff -------------------------------------------------


@pytest.mark.asyncio
async def test_failure_below_max_increments_retry_with_backoff() -> None:
    repo = FakeRepo(due=[_msg(id="msg-b", retry_count=1, max_retries=5)])

    async def send_fail(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
        raise ConnectionError("still broken")

    client = _make_client(send_fail)
    client.max_send_attempts = 1  # skip client-level retries for this test

    worker = RetryWorker(repo=repo, client=client)

    before = datetime.now(UTC)
    await worker.run_once()
    after = datetime.now(UTC)

    assert repo.delivered == repo.dead == []
    assert len(repo.incremented) == 1
    msg_id, retry_count, error, next_at = repo.incremented[0]
    assert msg_id == "msg-b"
    assert retry_count == 2  # incremented from 1
    assert "broken" in error.lower() or "connection" in error.lower()

    # next_at should be roughly `before + 2^2 = 4 minutes`
    expected_min = before + timedelta(minutes=4)
    expected_max = after + timedelta(minutes=4, seconds=5)
    assert expected_min <= next_at <= expected_max


@pytest.mark.asyncio
async def test_custom_backoff_function_is_used() -> None:
    repo = FakeRepo(due=[_msg(id="msg-c", retry_count=1, max_retries=5)])

    async def send_fail(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
        raise ConnectionError("nope")

    client = _make_client(send_fail)
    client.max_send_attempts = 1
    worker = RetryWorker(
        repo=repo,
        client=client,
        backoff=lambda n: timedelta(seconds=n),  # linear, seconds
    )

    before = datetime.now(UTC)
    await worker.run_once()
    after = datetime.now(UTC)

    _, _, _, next_at = repo.incremented[0]
    assert before + timedelta(seconds=2) <= next_at <= after + timedelta(seconds=3)


# ----- run_once: dead-letter --------------------------------------------


@pytest.mark.asyncio
async def test_max_retries_transitions_to_dead() -> None:
    repo = FakeRepo(
        due=[_msg(id="msg-dead", retry_count=4, max_retries=5)]
    )  # next_count will be 5 → >= max_retries

    async def send_fail(_token: str, _tool: str, _args: dict[str, Any]) -> Any:
        raise ConnectionError("permanently broken")

    client = _make_client(send_fail)
    client.max_send_attempts = 1

    hook_calls: list[tuple[str, str]] = []

    async def hook(msg: FailedMessage, error: str) -> None:
        hook_calls.append((msg.id, error))

    worker = RetryWorker(repo=repo, client=client, on_dead_letter=hook)

    count = await worker.run_once()

    assert count == 1
    assert repo.delivered == repo.incremented == []
    assert len(repo.dead) == 1
    msg_id, retry_count, _error = repo.dead[0]
    assert msg_id == "msg-dead"
    assert retry_count == 5
    assert hook_calls == [("msg-dead", hook_calls[0][1])]
    assert "broken" in hook_calls[0][1].lower()


@pytest.mark.asyncio
async def test_dead_letter_hook_error_is_isolated() -> None:
    repo = FakeRepo(due=[_msg(id="msg-h", retry_count=4, max_retries=5)])

    async def send_fail(_t: str, _a: dict[str, Any]) -> Any:
        raise ConnectionError("gone")

    client = _make_client(send_fail)
    client.max_send_attempts = 1

    async def bad_hook(_msg: FailedMessage, _error: str) -> None:
        raise RuntimeError("alerting pipeline broken")

    worker = RetryWorker(repo=repo, client=client, on_dead_letter=bad_hook)

    count = await worker.run_once()

    assert count == 1  # processed even though hook raised
    assert len(repo.dead) == 1


# ----- poison-row isolation ---------------------------------------------


@pytest.mark.asyncio
async def test_one_bad_row_does_not_stop_batch() -> None:
    """If processing message A raises, message B still gets processed."""
    repo = FakeRepo(due=[_msg(id="bad"), _msg(id="good", retry_count=0)])

    async def send_ok(_t: str, _tool: str, _a: dict[str, Any]) -> Any:
        return {"messageId": "SM-good"}, None

    client = _make_client(send_ok)

    # Make repo.mark_delivered raise only for the "bad" id
    original_md = repo.mark_delivered

    async def flaky_md(mid: str, sid: str, n: int) -> None:
        if mid == "bad":
            raise RuntimeError("transient DB error")
        await original_md(mid, sid, n)

    repo.mark_delivered = flaky_md  # type: ignore[method-assign]

    worker = RetryWorker(repo=repo, client=client)
    count = await worker.run_once()

    assert count == 1  # only the good one completed
    assert repo.delivered == [("good", "SM-good", 1)]


@pytest.mark.asyncio
async def test_fetch_failure_returns_zero() -> None:
    class BadRepo(FakeRepo):
        async def fetch_due(self, limit: int) -> list[FailedMessage]:
            raise RuntimeError("db down")

    worker = RetryWorker(repo=BadRepo(), client=_make_client(lambda t, a: None))
    assert await worker.run_once() == 0


# ----- start / stop lifecycle -------------------------------------------


@pytest.mark.asyncio
async def test_start_stop_runs_pass_then_terminates() -> None:
    repo = FakeRepo(due=[_msg(id="msg-loop")])

    async def send_ok(_t: str, _tool: str, _a: dict[str, Any]) -> Any:
        return {"messageId": "SM-loop"}, None

    client = _make_client(send_ok)
    worker = RetryWorker(repo=repo, client=client)

    await worker.start(interval_seconds=0.01, warmup_seconds=0)

    # Give the loop time to run at least one pass.
    for _ in range(50):
        if repo.delivered:
            break
        await asyncio.sleep(0.01)

    await worker.stop()

    assert len(repo.delivered) >= 1
    assert worker._task is None
    # A subsequent stop is a no-op
    await worker.stop()


@pytest.mark.asyncio
async def test_double_start_is_idempotent() -> None:
    repo = FakeRepo(due=[])

    async def no_send(_t: str, _a: dict[str, Any]) -> Any:
        return {}, None

    client = _make_client(no_send)
    worker = RetryWorker(repo=repo, client=client)

    await worker.start(interval_seconds=0.01, warmup_seconds=0)
    first_task = worker._task
    await worker.start(interval_seconds=0.01, warmup_seconds=0)  # no-op
    assert worker._task is first_task

    await worker.stop()


# ----- protocol check ---------------------------------------------------


def test_fake_repo_conforms_to_protocol() -> None:
    from buttdial import FailedMessageRepository

    assert isinstance(FakeRepo(), FailedMessageRepository)
