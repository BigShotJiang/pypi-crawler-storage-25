"""WhatsApp action surface on `Agent` — typed helpers + provider-capability errors.

These tests stub out `Agent._call_tool` directly so the full WhatsApp
action surface can be validated without a live BD server. Each typed
helper (typing, react, edit, …) just delegates to ``whatsapp_action``,
so we lock in (a) the right MCP tool name and args land on the wire
and (b) provider rejection turns into a typed ``ProviderCapabilityError``.
"""

from __future__ import annotations

from typing import Any

import pytest

from buttdial import Agent, ProviderCapabilityError


def _agent_with_stub(stub: Any) -> Agent:
    """Build an Agent whose `_call_tool` returns whatever `stub(token, tool, args)` returns."""
    a = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="tok")
    a._call_tool = stub  # type: ignore[method-assign]
    return a


@pytest.mark.asyncio
async def test_typing_dispatches_to_comms_whatsapp_action() -> None:
    captured: list[tuple[str, str, dict[str, Any]]] = []

    async def stub(token: str, tool: str, args: dict[str, Any]) -> Any:
        captured.append((token, tool, args))
        return {"ok": True}, None

    agent = _agent_with_stub(stub)
    result = await agent.typing(to="+1")
    assert result == {"ok": True}
    assert captured[0][1] == "comms_whatsapp_action"
    assert captured[0][2]["action"] == "typing"
    assert captured[0][2]["to"] == "+1"


@pytest.mark.asyncio
async def test_react_passes_message_id_and_emoji() -> None:
    captured: list[dict[str, Any]] = []

    async def stub(_t: str, _tool: str, args: dict[str, Any]) -> Any:
        captured.append(args)
        return {"ok": True}, None

    agent = _agent_with_stub(stub)
    await agent.react(messageId="wamid.X", emoji="🎉")
    assert captured[0]["messageId"] == "wamid.X"
    assert captured[0]["emoji"] == "🎉"


@pytest.mark.asyncio
async def test_send_buttons_serialises_button_list() -> None:
    captured: list[dict[str, Any]] = []

    async def stub(_t: str, _tool: str, args: dict[str, Any]) -> Any:
        captured.append(args)
        return {"messageId": "SM-buttons"}, None

    agent = _agent_with_stub(stub)
    result = await agent.send_buttons(
        to="+1",
        body="pick one",
        buttons=[{"id": "yes", "label": "Yes"}, {"id": "no", "label": "No"}],
    )
    assert result["messageId"] == "SM-buttons"
    assert captured[0]["buttons"] == [
        {"id": "yes", "label": "Yes"},
        {"id": "no", "label": "No"},
    ]


@pytest.mark.asyncio
async def test_send_location_includes_lat_lng_and_optional_name() -> None:
    captured: list[dict[str, Any]] = []

    async def stub(_t: str, _tool: str, args: dict[str, Any]) -> Any:
        captured.append(args)
        return {"messageId": "SM-loc"}, None

    agent = _agent_with_stub(stub)
    await agent.send_location(to="+1", lat=37.7749, lng=-122.4194, name="SF")
    assert captured[0]["lat"] == 37.7749
    assert captured[0]["lng"] == -122.4194
    assert captured[0]["name"] == "SF"


@pytest.mark.asyncio
async def test_send_view_once_omits_body_when_none() -> None:
    captured: list[dict[str, Any]] = []

    async def stub(_t: str, _tool: str, args: dict[str, Any]) -> Any:
        captured.append(args)
        return {"messageId": "SM-vo"}, None

    agent = _agent_with_stub(stub)
    await agent.send_view_once(to="+1", mediaUrl="https://cdn/x.jpg")
    assert "body" not in captured[0]
    assert captured[0]["mediaUrl"] == "https://cdn/x.jpg"


@pytest.mark.asyncio
async def test_unknown_action_rejected_before_wire() -> None:
    """Forward-compat guard: typo'd action name fails fast, doesn't hit BD."""
    agent = _agent_with_stub(lambda t, n, a: pytest.fail("should not have been called"))
    with pytest.raises(ValueError, match="Unknown WhatsApp action"):
        await agent.whatsapp_action("not_a_real_action")


@pytest.mark.asyncio
async def test_provider_capability_rejection_raises_typed_error() -> None:
    """BD's PROVIDER_UNSUPPORTED → ProviderCapabilityError with channel/action/provider."""

    async def stub(_t: str, _tool: str, _args: dict[str, Any]) -> Any:
        body = {
            "code": "PROVIDER_UNSUPPORTED",
            "error": "greenapi cannot post status",
            "channel": "whatsapp",
            "provider": "greenapi",
            "action": "post_status",
        }
        return body, None

    agent = _agent_with_stub(stub)
    with pytest.raises(ProviderCapabilityError) as exc:
        await agent.post_status(body="my latest")
    assert exc.value.code == "PROVIDER_UNSUPPORTED"
    assert exc.value.channel == "whatsapp"
    assert exc.value.provider == "greenapi"
    assert exc.value.action == "post_status"
    # Body is preserved for callers that want to inspect provider-specific fields.
    assert exc.value.body["error"] == "greenapi cannot post status"


@pytest.mark.asyncio
async def test_send_message_accepts_media_url_and_sender_sid() -> None:
    """spec section 7: comms_send_message takes mediaUrl + senderSid."""
    captured: list[dict[str, Any]] = []

    async def stub(_t: str, _tool: str, args: dict[str, Any]) -> Any:
        captured.append(args)
        return {"messageId": "SM-x"}, None

    agent = _agent_with_stub(stub)
    result = await agent.send_message(
        to="+1",
        body=None,
        media_url="https://cdn/img.jpg",
        sender_sid="snd-greenapi-1",
    )
    assert result.message_sid == "SM-x"
    assert captured[0]["mediaUrl"] == "https://cdn/img.jpg"
    assert captured[0]["senderSid"] == "snd-greenapi-1"
    # Body absent from the wire when not provided.
    assert "body" not in captured[0]


@pytest.mark.asyncio
async def test_send_message_requires_body_or_media_url() -> None:
    """Empty send → SendResult(failed=True, stage_failed=config). No wire call."""
    agent = _agent_with_stub(lambda t, n, a: pytest.fail("should not have been called"))
    result = await agent.send_message(to="+1")
    assert result.failed is True
    assert result.stage_failed == "config"


@pytest.mark.asyncio
async def test_whatsapp_action_requires_agent_token() -> None:
    """Forwards the per-call token; raises if neither set nor passed."""
    agent = Agent(base_url="https://fake.test", agent_id="agt-1")  # no agent_token
    with pytest.raises(ValueError, match="agent_token"):
        await agent.typing(to="+1")
