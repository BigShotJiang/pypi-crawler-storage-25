"""Unit tests for `buttdial.errors`."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from buttdial import (
    AgentNotFound,
    AgentNotProvisioned,
    AuthError,
    AuthInvalidTokenError,
    AuthLockedOutError,
    AuthMissingHeaderError,
    AuthTokenRevokedError,
    ButtDialError,
    ChannelError,
    ConfigError,
    RateLimitError,
    TransportError,
    parse_error_response,
)


def test_base_error_carries_optional_metadata() -> None:
    e = ButtDialError(
        "bad config",
        code="NO_TOKEN",
        stage="config",
        remediation="Set BUTT_DIAL_TOKEN.",
    )
    assert str(e) == "bad config"
    assert e.code == "NO_TOKEN"
    assert e.stage == "config"
    assert e.remediation == "Set BUTT_DIAL_TOKEN."


def test_base_error_without_metadata() -> None:
    e = ButtDialError("something broke")
    assert e.code is None
    assert e.stage is None
    assert e.remediation is None


def test_config_error_is_buttdial_error() -> None:
    assert issubclass(ConfigError, ButtDialError)
    with pytest.raises(ButtDialError):
        raise ConfigError("boom")


def test_transport_error_is_buttdial_error() -> None:
    assert issubclass(TransportError, ButtDialError)
    with pytest.raises(ButtDialError):
        raise TransportError("boom")


def test_agent_not_found_dual_inheritance() -> None:
    """Catchable via ButtDialError OR the plain KeyError idiom."""
    e = AgentNotFound("A-1")
    assert isinstance(e, ButtDialError)
    assert isinstance(e, KeyError)

    with pytest.raises(ButtDialError):
        raise AgentNotFound("A-1")

    with pytest.raises(KeyError):
        raise AgentNotFound("A-1")


def test_agent_not_provisioned_dual_inheritance() -> None:
    e = AgentNotProvisioned("A-2")
    assert isinstance(e, ButtDialError)
    assert isinstance(e, ValueError)

    with pytest.raises(ButtDialError):
        raise AgentNotProvisioned("A-2")

    with pytest.raises(ValueError, match="A-2"):
        raise AgentNotProvisioned("A-2")


# ----- Auth error family ----------------------------------------------------


def test_auth_invalid_token_carries_remaining_attempts() -> None:
    """The 401 contract: code, retryable=False, remainingAttempts countdown."""
    err = parse_error_response(
        status_code=401,
        body={
            "error": "Invalid or revoked token",
            "code": "AUTH_INVALID_TOKEN",
            "retryable": False,
            "remainingAttempts": 7,
        },
    )
    assert isinstance(err, AuthInvalidTokenError)
    assert isinstance(err, AuthError)
    assert isinstance(err, ButtDialError)
    assert err.code == "AUTH_INVALID_TOKEN"
    assert err.retryable is False
    assert err.remaining_attempts == 7
    assert err.status_code == 401
    assert "Invalid or revoked token" in str(err)


def test_auth_token_revoked_maps_to_subclass() -> None:
    err = parse_error_response(
        status_code=401,
        body={
            "error": "Token revoked",
            "code": "AUTH_TOKEN_REVOKED",
            "retryable": False,
            "remainingAttempts": 9,
        },
    )
    assert isinstance(err, AuthTokenRevokedError)
    assert err.code == "AUTH_TOKEN_REVOKED"


def test_auth_missing_header_maps_to_subclass() -> None:
    err = parse_error_response(
        status_code=401,
        body={
            "error": "Missing Authorization header",
            "code": "AUTH_MISSING_HEADER",
            "retryable": False,
            "remainingAttempts": 9,
        },
    )
    assert isinstance(err, AuthMissingHeaderError)


def test_auth_unknown_code_falls_back_to_base_auth_error() -> None:
    """Forward-compat: unknown 401 code maps to the base AuthError, not raises."""
    err = parse_error_response(
        status_code=401,
        body={"error": "Whatever", "code": "AUTH_FUTURE_CODE", "retryable": False},
    )
    assert type(err) is AuthError
    assert err.code == "AUTH_FUTURE_CODE"


def test_auth_locked_out_carries_retry_after_and_locked_until() -> None:
    """429 with AUTH_LOCKED_OUT: retryable=true, but only after lockedUntil."""
    err = parse_error_response(
        status_code=429,
        body={
            "error": "Too many failed attempts. Try again later.",
            "code": "AUTH_LOCKED_OUT",
            "retryable": True,
            "lockedUntil": "2026-04-25T11:42:13Z",
            "retryAfterSeconds": 873,
        },
        headers={"Retry-After": "873"},
    )
    assert isinstance(err, AuthLockedOutError)
    assert isinstance(err, AuthError)
    assert err.retryable is True
    assert err.retry_after_seconds == 873
    assert err.locked_until == datetime(2026, 4, 25, 11, 42, 13, tzinfo=UTC)


def test_retry_after_header_wins_over_body() -> None:
    """When both are present, Retry-After header is the authoritative signal."""
    err = parse_error_response(
        status_code=429,
        body={"code": "AUTH_LOCKED_OUT", "retryAfterSeconds": 100},
        headers={"Retry-After": "873"},
    )
    assert isinstance(err, AuthLockedOutError)
    assert err.retry_after_seconds == 873  # header, not body


def test_generic_429_without_lockout_code_maps_to_rate_limit_error() -> None:
    """429 without AUTH_LOCKED_OUT → RateLimitError, not AuthError."""
    err = parse_error_response(
        status_code=429,
        body={"error": "Too many requests", "code": "RATE_LIMITED"},
        headers={"Retry-After": "30"},
    )
    assert isinstance(err, RateLimitError)
    assert not isinstance(err, AuthError)
    assert err.retry_after_seconds == 30
    assert err.code == "RATE_LIMITED"


def test_429_no_retry_after_header_falls_back_to_body() -> None:
    err = parse_error_response(
        status_code=429,
        body={"code": "RATE_LIMITED", "retryAfterSeconds": 60},
    )
    assert isinstance(err, RateLimitError)
    assert err.retry_after_seconds == 60


def test_parse_error_other_4xx_returns_buttdial_error() -> None:
    """400/404/etc fall through to a generic ButtDialError so callers can branch."""
    err = parse_error_response(
        status_code=400,
        body={"error": "Bad request", "code": "BAD_INPUT"},
    )
    assert type(err) is ButtDialError
    assert err.code == "BAD_INPUT"


def test_parse_error_handles_non_dict_body() -> None:
    """A 401 with a stringly-typed body still produces an AuthError."""
    err = parse_error_response(status_code=401, body="not json")
    assert isinstance(err, AuthError)
    # Without a `code` we get the base class, not a subclass.
    assert type(err) is AuthError


def test_parse_error_handles_invalid_locked_until() -> None:
    """Garbage in `lockedUntil` doesn't crash — it just stays None."""
    err = parse_error_response(
        status_code=429,
        body={"code": "AUTH_LOCKED_OUT", "lockedUntil": "not-a-date"},
    )
    assert isinstance(err, AuthLockedOutError)
    assert err.locked_until is None


def test_channel_error_carries_routing_context() -> None:
    """ChannelError exposes channel + action + provider for fallback decisions."""
    err = ChannelError(
        "greenapi cannot post status",
        channel="whatsapp",
        action="post_status",
        provider="greenapi",
        code="CHANNEL_UNSUPPORTED",
    )
    assert isinstance(err, ButtDialError)
    assert err.channel == "whatsapp"
    assert err.action == "post_status"
    assert err.provider == "greenapi"
    assert err.code == "CHANNEL_UNSUPPORTED"
    assert err.stage == "channel"
