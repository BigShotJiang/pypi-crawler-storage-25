"""Unit tests for `buttdial.router.make_router` — the admin API."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from buttdial import (
    AdminFailedMessageRepository,
    Agent,
    AgentDirectory,
    AgentInfo,
    AgentNotFound,
    AgentNotProvisioned,
    FailedMessage,
    OverviewSnapshot,
    make_router,
)

# ----- Fakes ------------------------------------------------------------


class FakeDirectory:
    def __init__(self) -> None:
        self.agents: dict[str, AgentInfo] = {
            "A-1": AgentInfo(
                id="A-1",
                name="Sara",
                has_token=True,
                whatsapp_number="+972501111111",
                email="sara@example.test",
                status="active",
                message_count=42,
                failed_count=1,
            ),
            "A-2": AgentInfo(id="A-2", name="NoToken", has_token=False, status="paused"),
        }
        self.snap = OverviewSnapshot(
            agents_provisioned=1,
            total_messages_sent=100,
            total_messages_failed=3,
            total_messages_received=55,
        )

    async def list_agents(self) -> list[AgentInfo]:
        return list(self.agents.values())

    async def overview_snapshot(self) -> OverviewSnapshot:
        return self.snap

    async def activate(self, agent_id: str) -> AgentInfo:
        if agent_id not in self.agents:
            raise AgentNotFound(agent_id)
        a = self.agents[agent_id]
        if not a.has_token:
            raise AgentNotProvisioned(agent_id)
        updated = a.model_copy(update={"status": "active"})
        self.agents[agent_id] = updated
        return updated

    async def deactivate(self, agent_id: str) -> AgentInfo:
        if agent_id not in self.agents:
            raise AgentNotFound(agent_id)
        a = self.agents[agent_id]
        updated = a.model_copy(update={"status": "paused"})
        self.agents[agent_id] = updated
        return updated


class FakeAdminRepo:
    def __init__(self) -> None:
        self.queue: list[FailedMessage] = [
            FailedMessage(
                id="msg-1",
                recipient="+1",
                body="failed once",
                retry_count=1,
                last_error="timeout",
                created_at=datetime(2026, 4, 22, 8, 0, 0),
            ),
            FailedMessage(
                id="msg-2",
                recipient="+2",
                body="failed twice",
                retry_count=2,
                last_error="auth",
                status="dead",
            ),
        ]

    # worker methods (unused in router tests, but satisfy Protocol)
    async def fetch_due(self, limit: int) -> list[FailedMessage]:
        return []

    async def mark_delivered(self, msg_id: str, message_sid: str, retry_count: int) -> None:
        pass

    async def increment_retry(
        self, msg_id: str, retry_count: int, error: str, next_retry_at: datetime
    ) -> None:
        pass

    async def mark_dead(self, msg_id: str, retry_count: int, error: str) -> None:
        pass

    # admin methods
    async def list(self, status: str = "pending", limit: int = 50) -> list[FailedMessage]:
        return [m for m in self.queue if m.status == status][:limit]

    async def count_pending(self) -> int:
        return sum(1 for m in self.queue if m.status == "pending")

    async def force_retry(self, msg_id: str) -> bool:
        return any(m.id == msg_id and m.status == "pending" for m in self.queue)

    async def dismiss(self, msg_id: str) -> bool:
        for i, m in enumerate(self.queue):
            if m.id == msg_id:
                self.queue[i] = m.model_copy(update={"status": "dismissed"})
                return True
        return False


@pytest.fixture
def client_under_test():
    """TestClient wired up with fake directory + repo + monkeypatchable Agent."""
    client = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    directory = FakeDirectory()
    repo = FakeAdminRepo()
    app = FastAPI()
    app.include_router(
        make_router(client=client, repo=repo, directory=directory),
        prefix="/api/butt-dial",
    )
    return TestClient(app), client, directory, repo


# ----- Protocol conformance --------------------------------------------


def test_fake_directory_satisfies_protocol() -> None:
    assert isinstance(FakeDirectory(), AgentDirectory)


def test_fake_admin_repo_satisfies_protocol() -> None:
    assert isinstance(FakeAdminRepo(), AdminFailedMessageRepository)


# ----- /overview --------------------------------------------------------


def test_overview_connected(monkeypatch: pytest.MonkeyPatch, client_under_test) -> None:
    tc, client, _directory, _repo = client_under_test

    async def fake_list_tools() -> list[str]:
        return ["comms_send_message", "comms_ping"]

    async def fake_ping() -> bool:
        return True

    async def fake_usage() -> dict[str, Any]:
        return {"totalCost": 4.20}

    monkeypatch.setattr(client, "list_tools", fake_list_tools)
    monkeypatch.setattr(client, "ping", fake_ping)
    monkeypatch.setattr(client, "fetch_usage_summary", fake_usage)

    resp = tc.get("/api/butt-dial/overview")
    assert resp.status_code == 200
    body = resp.json()
    assert body["connection_status"] == "connected"
    assert body["tool_count"] == 2
    assert body["agents_provisioned"] == 1
    assert body["total_messages_sent"] == 100
    assert body["total_messages_failed"] == 3
    assert body["failed_queue_size"] == 1  # msg-1 is pending, msg-2 is dead
    assert body["cost_summary"] == {"totalCost": 4.20}
    assert body["last_ping"] == "ok"


def test_overview_disconnected(monkeypatch: pytest.MonkeyPatch, client_under_test) -> None:
    tc, client, _, _ = client_under_test

    async def no_tools() -> list[str]:
        return []

    async def no_ping() -> bool:
        return False

    async def no_usage() -> dict | None:
        return None

    monkeypatch.setattr(client, "list_tools", no_tools)
    monkeypatch.setattr(client, "ping", no_ping)
    monkeypatch.setattr(client, "fetch_usage_summary", no_usage)

    resp = tc.get("/api/butt-dial/overview")
    assert resp.status_code == 200
    body = resp.json()
    assert body["connection_status"] == "disconnected"
    assert body["tool_count"] == 0
    assert body["last_ping"] is None
    assert body["cost_summary"] is None


def test_overview_degraded_when_tools_but_no_ping(
    monkeypatch: pytest.MonkeyPatch, client_under_test
) -> None:
    tc, client, _, _ = client_under_test

    async def some_tools() -> list[str]:
        return ["comms_send_message"]

    async def no_ping() -> bool:
        return False

    async def no_usage() -> dict | None:
        return None

    monkeypatch.setattr(client, "list_tools", some_tools)
    monkeypatch.setattr(client, "ping", no_ping)
    monkeypatch.setattr(client, "fetch_usage_summary", no_usage)

    resp = tc.get("/api/butt-dial/overview")
    body = resp.json()
    assert body["connection_status"] == "degraded"
    assert body["last_ping"] is None


# ----- /agents ----------------------------------------------------------


def test_agents_list(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.get("/api/butt-dial/agents")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 2
    assert body[0]["id"] == "A-1"
    assert body[0]["has_token"] is True
    assert body[0]["message_count"] == 42
    assert body[1]["id"] == "A-2"
    assert body[1]["has_token"] is False


# ----- activate / deactivate -------------------------------------------


def test_activate_success(client_under_test) -> None:
    tc, _, directory, _ = client_under_test
    directory.agents["A-1"] = directory.agents["A-1"].model_copy(update={"status": "paused"})

    resp = tc.post("/api/butt-dial/agents/A-1/activate")
    assert resp.status_code == 200
    assert resp.json() == {"status": "active", "agent": "Sara", "id": "A-1"}


def test_activate_not_found(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/agents/NOPE/activate")
    assert resp.status_code == 404


def test_activate_no_token(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/agents/A-2/activate")
    assert resp.status_code == 400
    assert "token" in resp.json()["detail"].lower()


def test_deactivate_success(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/agents/A-1/deactivate")
    assert resp.status_code == 200
    assert resp.json()["status"] == "paused"


def test_deactivate_not_found(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/agents/NOPE/deactivate")
    assert resp.status_code == 404


# ----- failed-messages -------------------------------------------------


def test_failed_messages_default_status_pending(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.get("/api/butt-dial/failed-messages")
    assert resp.status_code == 200
    rows = resp.json()
    assert len(rows) == 1
    assert rows[0]["id"] == "msg-1"
    assert rows[0]["status"] == "pending"


def test_failed_messages_filter_by_status(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.get("/api/butt-dial/failed-messages?status=dead")
    rows = resp.json()
    assert len(rows) == 1
    assert rows[0]["id"] == "msg-2"


def test_force_retry_success(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/failed-messages/msg-1/retry")
    assert resp.status_code == 200
    assert resp.json() == {"queued": True, "id": "msg-1"}


def test_force_retry_unknown_or_not_pending(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    # msg-2 is dead, not pending
    resp = tc.post("/api/butt-dial/failed-messages/msg-2/retry")
    assert resp.status_code == 404


def test_dismiss_success(client_under_test) -> None:
    tc, _, _, repo = client_under_test
    resp = tc.post("/api/butt-dial/failed-messages/msg-1/dismiss")
    assert resp.status_code == 200
    assert resp.json() == {"dismissed": True, "id": "msg-1"}
    # verify state change
    assert repo.queue[0].status == "dismissed"


def test_dismiss_unknown(client_under_test) -> None:
    tc, _, _, _ = client_under_test
    resp = tc.post("/api/butt-dial/failed-messages/NOPE/dismiss")
    assert resp.status_code == 404


# ----- Agent helpers: light smoke-tests --------------------------------


@pytest.mark.asyncio
async def test_agent_list_tools_no_token_returns_empty() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1")  # no token
    assert await c.list_tools() == []


@pytest.mark.asyncio
async def test_agent_ping_no_token_returns_false() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1")
    assert await c.ping() is False


@pytest.mark.asyncio
async def test_agent_fetch_usage_no_token_returns_none() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1")
    assert await c.fetch_usage_summary() is None
