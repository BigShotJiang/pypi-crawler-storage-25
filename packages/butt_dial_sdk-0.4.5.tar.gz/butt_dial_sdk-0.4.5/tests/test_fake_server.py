"""Unit + integration tests for `buttdial.testing.FakeButtDialServer`.

These are the first tests that exercise the full Agent → MCP → server round
trip without monkeypatching every stage. They validate (a) that the fake
itself behaves correctly and (b) that the real Agent wiring works.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from buttdial import (
    Agent,
    DeliveryReceipt,
    InboundHandler,
    InboundMessage,
    SendResult,
    run_diagnostic,
)
from buttdial.testing import FakeButtDialServer, fake_server  # noqa: F401 (fixture)


def _make_client(**kwargs: Any) -> Agent:
    defaults: dict[str, Any] = {
        "base_url": "https://fake.test",
        "agent_id": "agt-1",
        "agent_token": "t-org",
    }
    defaults.update(kwargs)
    return Agent(**defaults)


# ----- send_message via the fake ----------------------------------------


@pytest.mark.asyncio
async def test_fake_records_sent_args(fake_server: FakeButtDialServer) -> None:
    fake_server.on_send(sid="SM-recorded")
    c = _make_client()
    result = await c.send_message(to="+1", body="hello", sender_name="Sara")

    assert isinstance(result, SendResult)
    assert result.message_sid == "SM-recorded"
    assert result.ok is True
    assert len(fake_server.sent_messages) == 1

    call = fake_server.sent_messages[0]
    assert call.tool == "comms_send_message"
    assert call.token == "t-org"
    assert call.args["to"] == "+1"
    assert call.args["body"] == "hello"
    assert call.args["senderName"] == "Sara"
    assert "idempotencyKey" in call.args


@pytest.mark.asyncio
async def test_fake_default_response_auto_sid(fake_server: FakeButtDialServer) -> None:
    """If no response is queued, fake returns a fresh SID."""
    c = _make_client()
    result = await c.send_message(to="+1", body="x")
    assert result.message_sid is not None
    assert result.message_sid.startswith("SM-")


@pytest.mark.asyncio
async def test_fake_error_triggers_client_retry(fake_server: FakeButtDialServer) -> None:
    """Three programmed errors exhaust Agent.max_send_attempts → failed result."""
    fake_server.on_send(error="connection refused", count=3)
    c = _make_client()

    async def no_sleep(_d: float) -> None:
        return None

    # Patch the retry sleep so the test is fast
    import buttdial.agent as client_mod

    original_sleep = client_mod.asyncio.sleep
    client_mod.asyncio.sleep = no_sleep  # type: ignore[assignment]
    try:
        result = await c.send_message(to="+1", body="x")
    finally:
        client_mod.asyncio.sleep = original_sleep  # type: ignore[assignment]

    assert result.failed is True
    assert result.stage_failed == "transport"
    assert "refused" in (result.error or "").lower()
    assert len(fake_server.sent_messages) == 3  # 3 attempts


@pytest.mark.asyncio
async def test_fake_error_then_success_recovers(fake_server: FakeButtDialServer) -> None:
    """2 errors then 1 success within Agent's 3 attempts → success."""
    fake_server.on_send(error="transient glitch", count=2)
    fake_server.on_send(sid="SM-recovered")

    import buttdial.agent as client_mod

    async def no_sleep(_d: float) -> None:
        return None

    original_sleep = client_mod.asyncio.sleep
    client_mod.asyncio.sleep = no_sleep  # type: ignore[assignment]
    try:
        c = _make_client()
        result = await c.send_message(to="+1", body="x")
    finally:
        client_mod.asyncio.sleep = original_sleep  # type: ignore[assignment]

    assert result.message_sid == "SM-recovered"
    assert len(fake_server.sent_messages) == 3


@pytest.mark.asyncio
async def test_fake_raw_text_non_json(fake_server: FakeButtDialServer) -> None:
    """Malformed server response → no SID, failed=False (Agent's existing behavior)."""
    fake_server.on_send(raw_text="not json at all")
    c = _make_client()
    result = await c.send_message(to="+1", body="x")
    assert result.message_sid is None
    assert result.ok is False


# ----- list_tools / ping via the fake -----------------------------------


@pytest.mark.asyncio
async def test_fake_list_tools(fake_server: FakeButtDialServer) -> None:
    c = _make_client()
    tools = await c.list_tools()
    assert "comms_send_message" in tools
    assert "comms_ping" in tools


@pytest.mark.asyncio
async def test_fake_set_tools(fake_server: FakeButtDialServer) -> None:
    fake_server.set_tools(["only_one_tool"])
    c = _make_client()
    tools = await c.list_tools()
    assert tools == ["only_one_tool"]


@pytest.mark.asyncio
async def test_fake_ping_succeeds(fake_server: FakeButtDialServer) -> None:
    c = _make_client()
    assert await c.ping() is True


# ----- token capture ---------------------------------------------------


@pytest.mark.asyncio
async def test_fake_captures_default_agent_token(
    fake_server: FakeButtDialServer,
) -> None:
    """The agent_token set on Agent() is the default for sends."""
    c = _make_client(agent_token="DEFAULT-TOK")
    await c.send_message(to="+1", body="x")
    assert fake_server.last_token == "DEFAULT-TOK"


@pytest.mark.asyncio
async def test_fake_captures_per_call_agent_token_override(
    fake_server: FakeButtDialServer,
) -> None:
    """Per-call agent_token overrides the instance default (multi-tenant pattern)."""
    c = _make_client(agent_token="DEFAULT-TOK")
    await c.send_message(to="+1", body="x", agent_token="OVERRIDE-TOK")
    assert fake_server.last_token == "OVERRIDE-TOK"


# ----- inbound simulation ---------------------------------------------


@pytest.mark.asyncio
async def test_simulate_inbound_fires_handler(fake_server: FakeButtDialServer) -> None:
    inbound = InboundHandler()
    captured: list[InboundMessage] = []

    @inbound.on_message()
    async def on_msg(m: InboundMessage) -> None:
        captured.append(m)

    msg = await fake_server.simulate_inbound(
        inbound, sender="+1", text="hello from user", channel="whatsapp"
    )

    assert len(captured) == 1
    assert captured[0].sender == "+1"
    assert captured[0].text == "hello from user"
    assert msg.channel == "whatsapp"


@pytest.mark.asyncio
async def test_simulate_receipt_fires_handler(fake_server: FakeButtDialServer) -> None:
    inbound = InboundHandler()
    captured: list[DeliveryReceipt] = []

    @inbound.on_delivery_receipt()
    async def on_r(r: DeliveryReceipt) -> None:
        captured.append(r)

    await fake_server.simulate_receipt(inbound, message_sid="SM-xyz", status="delivered")

    assert len(captured) == 1
    assert captured[0].message_sid == "SM-xyz"
    assert captured[0].status == "delivered"


# ----- install / uninstall lifecycle ----------------------------------


@pytest.mark.asyncio
async def test_manual_install_uninstall() -> None:
    """Exercise the non-context-manager path."""
    fake = FakeButtDialServer()
    fake.install()
    try:
        fake.on_send(sid="SM-manual")
        c = _make_client()
        result = await c.send_message(to="+1", body="x")
        assert result.message_sid == "SM-manual"
    finally:
        fake.uninstall()

    # After uninstall, the real mcp.client.sse.sse_client should be gone
    # (was not installed before the test), so a second send would fail.
    assert not fake._installed


def test_double_install_is_idempotent() -> None:
    fake = FakeButtDialServer()
    fake.install()
    fake.install()  # should not raise
    fake.uninstall()


def test_double_uninstall_is_idempotent() -> None:
    fake = FakeButtDialServer()
    fake.uninstall()  # not installed → no-op
    fake.install()
    fake.uninstall()
    fake.uninstall()  # no-op


# ----- reset -----------------------------------------------------------


@pytest.mark.asyncio
async def test_reset_clears_state(fake_server: FakeButtDialServer) -> None:
    fake_server.on_send(sid="SM-1")
    c = _make_client()
    await c.send_message(to="+1", body="x")

    assert len(fake_server.sent_messages) == 1

    fake_server.reset()
    assert fake_server.sent_messages == []
    assert fake_server.last_token == ""


# ----- doctor integration (end-to-end without monkeypatching) ----------


@pytest.mark.asyncio
async def test_doctor_stages_1_through_4_against_fake(
    fake_server: FakeButtDialServer, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Full diagnostic, stages 1-4, against the fake. No per-stage monkeypatching."""
    # Stage 2 hits httpx — stub that one since the fake only covers MCP.
    import httpx

    class _FakeResp:
        status_code = 200

    class _FakeAsyncClient:
        def __init__(self, *_a: Any, **_k: Any) -> None:
            pass

        async def __aenter__(self) -> _FakeAsyncClient:
            return self

        async def __aexit__(self, *_a: Any) -> None:
            return None

        async def get(self, _url: str) -> _FakeResp:
            return _FakeResp()

    monkeypatch.setattr(httpx, "AsyncClient", _FakeAsyncClient)

    c = _make_client()
    report = await run_diagnostic(c)  # no `to` → stages 5-7 skip

    stage_names = [s.name for s in report.stages]
    assert stage_names == [
        "Config loaded",
        "Server reachable",
        "SSE handshake",
        "Tool list",
        "send_message accepted",
        "Delivery receipt",
        "Human ack loopback",
    ]
    # Stages 1-4 all ok
    for s in report.stages[:4]:
        assert s.ok is True, f"stage {s.name!r} failed: {s.detail}"
    # Stages 5-7 skipped
    for s in report.stages[4:]:
        assert "skipped" in (s.detail or "")


@pytest.mark.asyncio
async def test_doctor_full_flow_with_inbound(
    fake_server: FakeButtDialServer, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Stages 1-6 against fake + simulated receipt."""
    import httpx

    class _FakeResp:
        status_code = 200

    class _FakeAsyncClient:
        def __init__(self, *_a: Any, **_k: Any) -> None:
            pass

        async def __aenter__(self) -> _FakeAsyncClient:
            return self

        async def __aexit__(self, *_a: Any) -> None:
            return None

        async def get(self, _url: str) -> _FakeResp:
            return _FakeResp()

    monkeypatch.setattr(httpx, "AsyncClient", _FakeAsyncClient)

    fake_server.on_send(sid="SM-doctor")
    c = _make_client()
    inbound = InboundHandler()

    # Fire the matching receipt shortly after stage 6 starts
    async def deliver_receipt() -> None:
        await asyncio.sleep(0.05)
        await fake_server.simulate_receipt(inbound, message_sid="SM-doctor", status="delivered")

    task = asyncio.create_task(deliver_receipt())
    report = await run_diagnostic(
        c,
        to="+1",
        inbound_handler=inbound,
        receipt_timeout=1.0,
    )
    await task

    assert report.ok is True
    assert report.stages[4].name == "send_message accepted"
    assert report.stages[4].ok is True
    assert report.stages[5].name == "Delivery receipt"
    assert report.stages[5].ok is True
    # Stage 7 skipped because expect_ack=False
    assert "skipped" in (report.stages[6].detail or "")
