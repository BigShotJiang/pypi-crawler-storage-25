"""Unit tests for `buttdial.inbound.InboundHandler`."""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any

import pytest

from buttdial import DeliveryReceipt, InboundHandler, InboundMessage

WA_TEXT_PAYLOAD: dict[str, Any] = {
    "entry": [
        {
            "changes": [
                {
                    "value": {
                        "messages": [
                            {
                                "from": "+972501234567",
                                "id": "wamid.ABC",
                                "type": "text",
                                "text": {"body": "Hi there"},
                                "timestamp": "1745308800",  # 2025-04-22T08:00:00Z
                            }
                        ]
                    }
                }
            ]
        }
    ]
}

WA_STATUSES_PAYLOAD: dict[str, Any] = {
    "entry": [
        {
            "changes": [
                {
                    "value": {
                        "statuses": [
                            {
                                "id": "SM123",
                                "status": "delivered",
                                "timestamp": "1745308900",
                            },
                            {
                                "id": "SM124",
                                "status": "failed",
                                "timestamp": "1745308901",
                                "errors": [{"code": 131053, "title": "Media upload error"}],
                            },
                        ]
                    }
                }
            ]
        }
    ]
}


# ----- decorator registration + dispatch --------------------------------


@pytest.mark.asyncio
async def test_on_message_decorator_fires_for_matching_channel() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message(channel="whatsapp")
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    result = await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)

    assert result["messages"] == 1
    assert len(captured) == 1
    assert captured[0].sender == "+972501234567"
    assert captured[0].text == "Hi there"
    assert captured[0].channel == "whatsapp"
    assert captured[0].received_at is not None


@pytest.mark.asyncio
async def test_on_message_wildcard_gets_all_channels() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()  # no channel → wildcard
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)
    await h.handle_generic_payload({"from": "+1", "body": "sms hi", "channel": "sms"})

    assert len(captured) == 2
    assert captured[0].channel == "whatsapp"
    assert captured[1].channel == "sms"


@pytest.mark.asyncio
async def test_channel_scoped_handler_does_not_fire_for_other_channels() -> None:
    h = InboundHandler()
    wa: list[InboundMessage] = []

    @h.on_message(channel="whatsapp")
    async def handle_wa(msg: InboundMessage) -> None:
        wa.append(msg)

    await h.handle_generic_payload({"from": "+1", "body": "sms hi", "channel": "sms"})

    assert wa == []  # SMS should not trigger WA-scoped handler


@pytest.mark.asyncio
async def test_handler_error_is_isolated() -> None:
    """If one handler raises, other handlers still run."""
    h = InboundHandler()
    successes: list[str] = []

    @h.on_message()
    async def bad(_msg: InboundMessage) -> None:
        raise RuntimeError("boom")

    @h.on_message()
    async def good(msg: InboundMessage) -> None:
        successes.append(msg.text)

    result = await h.handle_whatsapp_payload(WA_TEXT_PAYLOAD)

    assert result["messages"] == 1
    assert successes == ["Hi there"]


# ----- WhatsApp message parsing ----------------------------------------


@pytest.mark.asyncio
async def test_whatsapp_interactive_message_json_serialized() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "type": "interactive",
                                    "interactive": {"type": "button_reply", "id": "yes"},
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    assert len(captured) == 1
    parsed = json.loads(captured[0].text)
    assert parsed["id"] == "yes"


@pytest.mark.asyncio
async def test_whatsapp_skips_message_with_no_sender() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {"value": {"messages": [{"type": "text", "text": {"body": "hi"}}]}}  # no "from"
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    assert captured == []


# ----- WhatsApp statuses → DeliveryReceipt -----------------------------


@pytest.mark.asyncio
async def test_whatsapp_statuses_dispatched_as_delivery_receipts() -> None:
    h = InboundHandler()
    captured: list[DeliveryReceipt] = []

    @h.on_delivery_receipt()
    async def handle(r: DeliveryReceipt) -> None:
        captured.append(r)

    result = await h.handle_whatsapp_payload(WA_STATUSES_PAYLOAD)

    assert result["receipts"] == 2
    assert captured[0].message_sid == "SM123"
    assert captured[0].status == "delivered"
    assert captured[1].message_sid == "SM124"
    assert captured[1].status == "failed"
    assert captured[1].error_code == "131053"


@pytest.mark.asyncio
async def test_whatsapp_statuses_with_unknown_status_skipped() -> None:
    h = InboundHandler()
    captured: list[DeliveryReceipt] = []

    @h.on_delivery_receipt()
    async def handle(r: DeliveryReceipt) -> None:
        captured.append(r)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "statuses": [
                                {"id": "SM1", "status": "unknown_new_state"},
                                {"status": "delivered"},  # no id
                            ]
                        }
                    }
                ]
            }
        ]
    }
    result = await h.handle_whatsapp_payload(payload)
    assert result["receipts"] == 0
    assert captured == []


# ----- Generic butt-dial payload ---------------------------------------


@pytest.mark.asyncio
async def test_generic_payload_parsed() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    result = await h.handle_generic_payload(
        {"from": "+1555", "body": "text me back", "channel": "sms", "thread_id": "T-9"}
    )
    assert result["messages"] == 1
    assert captured[0].channel == "sms"
    assert captured[0].thread_id == "T-9"


@pytest.mark.asyncio
async def test_generic_payload_missing_fields_ignored() -> None:
    h = InboundHandler()
    result = await h.handle_generic_payload({"from": "+1"})  # no body
    assert result["status"] == "ignored"


# ----- Normalized fields (canonical inbound shape) ---------------------


@pytest.mark.asyncio
async def test_whatsapp_text_populates_id_and_body_alias() -> None:
    """Text messages: id, body alias, sender_name, to are populated from envelope."""
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+972501234567",
                                    "to": "+15550000",
                                    "id": "wamid.ABC",
                                    "type": "text",
                                    "text": {"body": "Hi"},
                                    "timestamp": "1745308800",
                                    "senderName": "Alice",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    msg = captured[0]
    assert msg.id == "wamid.ABC"
    assert msg.to == "+15550000"
    assert msg.body == "Hi"  # alias of .text
    assert msg.text == "Hi"
    assert msg.sender_name == "Alice"
    assert msg.is_voice_message is False
    assert msg.media_url is None


@pytest.mark.asyncio
async def test_whatsapp_image_populates_media_fields() -> None:
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+972501234567",
                                    "id": "wamid.IMG",
                                    "type": "image",
                                    "image": {
                                        "id": "media-789",
                                        "link": "https://cdn.bd/image.jpg",
                                        "mime_type": "image/jpeg",
                                        "caption": "look at this",
                                    },
                                    "timestamp": "1745308800",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    msg = captured[0]
    assert msg.media_url == "https://cdn.bd/image.jpg"
    assert msg.media_type == "image/jpeg"
    assert msg.text == "look at this"  # caption used as body


@pytest.mark.asyncio
async def test_whatsapp_voice_note_with_transcription() -> None:
    """Audio with voice=true → is_voice_message + voice_transcription."""
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "id": "wamid.VN",
                                    "type": "audio",
                                    "audio": {
                                        "id": "media-vn",
                                        "url": "https://cdn.bd/vn.ogg",
                                        "mime_type": "audio/ogg",
                                        "voice": True,
                                        "voiceTranscription": "Call me back",
                                    },
                                    "timestamp": "1745308800",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    msg = captured[0]
    assert msg.is_voice_message is True
    assert msg.voice_transcription == "Call me back"
    assert msg.media_type == "audio/ogg"


@pytest.mark.asyncio
async def test_whatsapp_group_context_propagated() -> None:
    """BD-normalized envelopes carry groupId/groupName on the message."""
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "id": "wamid.G",
                                    "type": "text",
                                    "text": {"body": "Group chat"},
                                    "timestamp": "1745308800",
                                    "groupId": "G-42",
                                    "groupName": "Project Falcon",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    await h.handle_whatsapp_payload(payload)
    msg = captured[0]
    assert msg.group_id == "G-42"
    assert msg.group_name == "Project Falcon"


@pytest.mark.asyncio
async def test_generic_payload_forwards_all_normalized_fields() -> None:
    """BD generic envelope (SMS/email/voice) carries the same canonical fields."""
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    await h.handle_generic_payload(
        {
            "id": "M-1",
            "from": "+1555",
            "to": "+15551112222",
            "body": "hello",
            "channel": "sms",
            "mediaUrl": "https://cdn.bd/file.pdf",
            "mediaType": "application/pdf",
            "isVoiceMessage": False,
            "groupId": None,
            "senderName": "Bob",
            "thread_id": "T-1",
        }
    )
    msg = captured[0]
    assert msg.id == "M-1"
    assert msg.to == "+15551112222"
    assert msg.media_url == "https://cdn.bd/file.pdf"
    assert msg.media_type == "application/pdf"
    assert msg.sender_name == "Bob"
    assert msg.body == "hello"


@pytest.mark.asyncio
async def test_generic_payload_voice_with_no_body_uses_placeholder() -> None:
    """A voice note with empty transcription but a media URL is still a real message."""
    h = InboundHandler()
    captured: list[InboundMessage] = []

    @h.on_message()
    async def handle(msg: InboundMessage) -> None:
        captured.append(msg)

    result = await h.handle_generic_payload(
        {
            "from": "+1",
            "channel": "whatsapp",
            "mediaUrl": "https://cdn.bd/vn.ogg",
            "mediaType": "audio/ogg",
            "isVoiceMessage": True,
        }
    )
    assert result["messages"] == 1
    assert captured[0].is_voice_message is True
    assert captured[0].media_url == "https://cdn.bd/vn.ogg"


# ----- Verification ----------------------------------------------------


def test_whatsapp_signature_valid() -> None:
    secret = "s3cr3t"
    h = InboundHandler(whatsapp_webhook_secret=secret)
    body = b'{"hello":"world"}'
    sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    assert h.verify_whatsapp_signature(body, sig) is True


def test_whatsapp_signature_invalid() -> None:
    h = InboundHandler(whatsapp_webhook_secret="s3cr3t")
    assert h.verify_whatsapp_signature(b'{"hello":"world"}', "sha256=deadbeef") is False


def test_whatsapp_signature_skipped_when_no_secret() -> None:
    """Dev mode: no secret configured → signature check passes."""
    h = InboundHandler()
    assert h.verify_whatsapp_signature(b"anything", "") is True


def test_whatsapp_subscription_verify_ok() -> None:
    h = InboundHandler(whatsapp_verify_token="secret-verify")
    assert h.verify_whatsapp_subscription("subscribe", "secret-verify") is True


def test_whatsapp_subscription_verify_bad_token() -> None:
    h = InboundHandler(whatsapp_verify_token="secret-verify")
    assert h.verify_whatsapp_subscription("subscribe", "wrong") is False


def test_whatsapp_subscription_verify_no_config() -> None:
    h = InboundHandler()  # no verify_token
    assert h.verify_whatsapp_subscription("subscribe", "anything") is False


# ----- FastAPI router (integration) ------------------------------------


@pytest.fixture
def app_with_handler():
    """FastAPI app wrapping an InboundHandler, returned with TestClient."""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    handler = InboundHandler(
        whatsapp_verify_token="verify-me",
        whatsapp_webhook_secret="",  # no sig check → simpler test
    )
    captured: dict[str, list] = {"msgs": [], "receipts": []}

    @handler.on_message(channel="whatsapp")
    async def on_msg(m: InboundMessage) -> None:
        captured["msgs"].append(m)

    @handler.on_delivery_receipt()
    async def on_r(r: DeliveryReceipt) -> None:
        captured["receipts"].append(r)

    app = FastAPI()
    app.include_router(handler.router, prefix="/api/buttdial/webhook")
    return TestClient(app), captured


def test_router_get_verify_success(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get(
        "/api/buttdial/webhook/whatsapp/verify",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "verify-me",
            "hub.challenge": "12345",
        },
    )
    assert resp.status_code == 200
    assert resp.json() == 12345


def test_router_get_verify_wrong_token(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get(
        "/api/buttdial/webhook/whatsapp/verify",
        params={"hub.mode": "subscribe", "hub.verify_token": "wrong"},
    )
    assert resp.status_code == 403


def test_router_get_verify_unknown_channel(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.get("/api/buttdial/webhook/fax/verify")
    assert resp.status_code == 400


def test_router_post_whatsapp_dispatches(app_with_handler) -> None:
    client, captured = app_with_handler
    resp = client.post("/api/buttdial/webhook/whatsapp", json=WA_TEXT_PAYLOAD)
    assert resp.status_code == 200
    body = resp.json()
    assert body["messages"] == 1
    assert len(captured["msgs"]) == 1


def test_router_post_signature_invalid_rejected() -> None:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    handler = InboundHandler(whatsapp_webhook_secret="s3cr3t")
    app = FastAPI()
    app.include_router(handler.router, prefix="/api/buttdial/webhook")
    client = TestClient(app)

    resp = client.post(
        "/api/buttdial/webhook/whatsapp",
        json=WA_TEXT_PAYLOAD,
        headers={"X-Hub-Signature-256": "sha256=bad"},
    )
    assert resp.status_code == 403


def test_router_post_butt_dial_generic(app_with_handler) -> None:
    client, _captured = app_with_handler
    resp = client.post(
        "/api/buttdial/webhook/butt-dial",
        json={"from": "+1", "body": "sms arrived", "channel": "sms"},
    )
    assert resp.status_code == 200
    assert resp.json()["messages"] == 1


def test_router_post_unknown_channel_ignored(app_with_handler) -> None:
    client, _ = app_with_handler
    resp = client.post("/api/buttdial/webhook/fax", json={"x": 1})
    assert resp.status_code == 200
    assert resp.json()["status"] == "ignored"


# ----- InboundHandler.parse() — unified canonical-dict entry point ------


def test_parse_text_only_whatsapp_message() -> None:
    """Text envelope → canonical dict with id, from, body."""
    out = InboundHandler.parse(WA_TEXT_PAYLOAD)
    assert out is not None
    assert out["type"] == "message"
    assert out["id"] == "wamid.ABC"
    assert out["from"] == "+972501234567"
    assert out["body"] == "Hi there"
    assert out["channel"] == "whatsapp"
    assert out["mediaUrl"] is None
    assert out["isVoiceMessage"] is False


def test_parse_message_with_media_url() -> None:
    """Image envelope → canonical dict with mediaUrl + mediaType."""
    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "id": "wamid.IMG",
                                    "type": "image",
                                    "image": {
                                        "link": "https://cdn.bd/x.jpg",
                                        "mime_type": "image/jpeg",
                                        "caption": "look",
                                    },
                                    "timestamp": "1745308800",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    out = InboundHandler.parse(payload)
    assert out is not None
    assert out["mediaUrl"] == "https://cdn.bd/x.jpg"
    assert out["mediaType"] == "image/jpeg"
    assert out["body"] == "look"


def test_parse_voice_note_with_transcription() -> None:
    """Audio with voice=true → isVoiceMessage + voiceTranscription."""
    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "id": "wamid.VN",
                                    "type": "audio",
                                    "audio": {
                                        "url": "https://cdn.bd/vn.ogg",
                                        "mime_type": "audio/ogg",
                                        "voice": True,
                                        "voiceTranscription": "Call me back",
                                    },
                                    "timestamp": "1745308800",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    out = InboundHandler.parse(payload)
    assert out is not None
    assert out["isVoiceMessage"] is True
    assert out["voiceTranscription"] == "Call me back"


def test_parse_group_message() -> None:
    """Group context fields surface in canonical output."""
    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "messages": [
                                {
                                    "from": "+1",
                                    "id": "wamid.G",
                                    "type": "text",
                                    "text": {"body": "in the group"},
                                    "timestamp": "1745308800",
                                    "groupId": "G-42",
                                    "groupName": "Project Falcon",
                                    "senderName": "Alice",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    out = InboundHandler.parse(payload)
    assert out is not None
    assert out["groupId"] == "G-42"
    assert out["groupName"] == "Project Falcon"
    assert out["senderName"] == "Alice"


def test_parse_delivery_receipt_from_wa_envelope() -> None:
    """WA statuses envelope → canonical dict with type=delivery_receipt."""
    payload = {
        "entry": [
            {
                "changes": [
                    {
                        "value": {
                            "statuses": [
                                {
                                    "id": "SM-123",
                                    "status": "delivered",
                                    "timestamp": "1745308900",
                                }
                            ]
                        }
                    }
                ]
            }
        ]
    }
    out = InboundHandler.parse(payload)
    assert out is not None
    assert out["type"] == "delivery_receipt"
    assert out["id"] == "SM-123"
    assert out["deliveryStatus"] == "delivered"


def test_parse_delivery_receipt_from_generic_envelope() -> None:
    """BD-normalized receipt (no WA wrapper) also classified."""
    out = InboundHandler.parse(
        {
            "messageId": "SM-456",
            "status": "read",
            "channel": "whatsapp",
        }
    )
    assert out is not None
    assert out["type"] == "delivery_receipt"
    assert out["id"] == "SM-456"
    assert out["deliveryStatus"] == "read"


def test_parse_echo_of_outbound_classified_as_echo() -> None:
    """BD's echo of an SDK-sent outbound is flagged so hosts can ignore it."""
    out = InboundHandler.parse(
        {
            "echo": True,
            "id": "M-out-1",
            "from": "+15551234",
            "to": "+15555678",
            "channel": "whatsapp",
            "body": "hello",
        }
    )
    assert out is not None
    assert out["type"] == "echo"
    assert out["body"] == "hello"


def test_parse_generic_message_canonical_keys() -> None:
    """Plain BD-normalized inbound (SMS) hits the canonical shape."""
    out = InboundHandler.parse(
        {
            "id": "M-1",
            "from": "+1555",
            "to": "+15551111",
            "body": "sms hi",
            "channel": "sms",
            "senderName": "Bob",
        }
    )
    assert out is not None
    assert out["type"] == "message"
    assert out["id"] == "M-1"
    assert out["from"] == "+1555"
    assert out["body"] == "sms hi"
    assert out["senderName"] == "Bob"


def test_parse_returns_none_for_unrecognized_envelope() -> None:
    assert InboundHandler.parse({"random": "shape"}) is None
    assert InboundHandler.parse({}) is None
