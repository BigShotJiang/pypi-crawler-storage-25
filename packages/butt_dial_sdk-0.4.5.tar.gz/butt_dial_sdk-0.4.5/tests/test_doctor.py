"""Unit tests for `buttdial.doctor` — staged diagnostic + remediation."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from buttdial import (
    Agent,
    DeliveryReceipt,
    InboundHandler,
    SendResult,
    find_remediation,
    run_diagnostic,
)
from buttdial.doctor import (
    REMEDIATIONS,
    _probe_session,
    stage_ack,
    stage_config,
    stage_reachability,
    stage_receipt,
    stage_send,
)

# ----- remediation map --------------------------------------------------


def test_find_remediation_exact_substring() -> None:
    assert find_remediation("HTTP 401 Unauthorized") is not None
    assert "token" in find_remediation("HTTP 401 Unauthorized").lower()  # type: ignore[union-attr]


def test_find_remediation_connection_refused() -> None:
    remedy = find_remediation("connection refused")
    assert remedy is not None
    assert "butt_dial_url" in remedy.lower() or "server" in remedy.lower()


def test_find_remediation_unknown_returns_none() -> None:
    assert find_remediation("some totally unknown error") is None


def test_find_remediation_empty_input() -> None:
    assert find_remediation("") is None
    assert find_remediation(None) is None


def test_remediation_map_not_empty() -> None:
    assert len(REMEDIATIONS) >= 10  # sanity


# ----- stage_config -----------------------------------------------------


@pytest.mark.asyncio
async def test_stage_config_ok() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    s = await stage_config(c)
    assert s.ok is True


@pytest.mark.asyncio
async def test_stage_config_no_token() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1")
    s = await stage_config(c)
    assert s.ok is False
    assert s.remediation is not None


# ----- stage_reachability ----------------------------------------------


@pytest.mark.asyncio
async def test_stage_reachability_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    import httpx

    class _FakeResp:
        status_code = 404  # any response means reachable

    class _FakeAsyncClient:
        def __init__(self, *_a: Any, **_k: Any) -> None:
            pass

        async def __aenter__(self) -> _FakeAsyncClient:
            return self

        async def __aexit__(self, *_a: Any) -> None:
            return None

        async def get(self, _url: str) -> _FakeResp:
            return _FakeResp()

    monkeypatch.setattr(httpx, "AsyncClient", _FakeAsyncClient)
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    s = await stage_reachability(c)
    assert s.ok is True
    assert "404" in (s.detail or "")


@pytest.mark.asyncio
async def test_stage_reachability_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    import httpx

    class _FakeAsyncClient:
        def __init__(self, *_a: Any, **_k: Any) -> None:
            pass

        async def __aenter__(self) -> _FakeAsyncClient:
            return self

        async def __aexit__(self, *_a: Any) -> None:
            return None

        async def get(self, _url: str) -> Any:
            raise ConnectionError("connection refused")

    monkeypatch.setattr(httpx, "AsyncClient", _FakeAsyncClient)
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    s = await stage_reachability(c)
    assert s.ok is False
    assert s.remediation is not None  # matched by the connection-refused rule


# ----- _probe_session (stages 3+4) --------------------------------------


@pytest.mark.asyncio
async def test_probe_session_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    """Fake mcp SSE + ClientSession so we can exercise stages 3-4 without a real server."""
    import sys
    import types

    fake_session = types.SimpleNamespace()

    async def _init() -> None:
        return None

    async def _list_tools() -> Any:
        return types.SimpleNamespace(
            tools=[
                types.SimpleNamespace(name="comms_send_message"),
                types.SimpleNamespace(name="comms_ping"),
            ]
        )

    fake_session.initialize = _init
    fake_session.list_tools = _list_tools

    class _FakeSessionCtx:
        async def __aenter__(self) -> Any:
            return fake_session

        async def __aexit__(self, *_a: Any) -> None:
            return None

    class _FakeSseCtx:
        async def __aenter__(self) -> Any:
            return (object(), object())

        async def __aexit__(self, *_a: Any) -> None:
            return None

    mcp_mod = types.ModuleType("mcp")
    mcp_mod.ClientSession = lambda *_a, **_k: _FakeSessionCtx()  # type: ignore[attr-defined]
    sys.modules["mcp"] = mcp_mod

    mcp_sse_mod = types.ModuleType("mcp.client.sse")
    mcp_sse_mod.sse_client = lambda *_a, **_k: _FakeSseCtx()  # type: ignore[attr-defined]
    sys.modules.setdefault("mcp.client", types.ModuleType("mcp.client"))
    sys.modules["mcp.client.sse"] = mcp_sse_mod

    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    s3, s4 = await _probe_session(c)
    assert s3.ok is True
    assert s4.ok is True
    assert "comms_send_message" in (s4.detail or "")


@pytest.mark.asyncio
async def test_probe_session_handshake_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    import sys
    import types

    class _FakeSseCtx:
        async def __aenter__(self) -> Any:
            raise ConnectionError("connection refused")

        async def __aexit__(self, *_a: Any) -> None:
            return None

    mcp_sse_mod = types.ModuleType("mcp.client.sse")
    mcp_sse_mod.sse_client = lambda *_a, **_k: _FakeSseCtx()  # type: ignore[attr-defined]
    sys.modules["mcp.client.sse"] = mcp_sse_mod

    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    s3, s4 = await _probe_session(c)
    assert s3.ok is False
    assert s4.ok is False
    assert "skipped" in (s4.detail or "")


# ----- stage_send -------------------------------------------------------


def test_unwrap_unnests_exception_group() -> None:
    """ExceptionGroup → innermost error. Regression test for v0.1.0's TaskGroup wrapper."""
    from buttdial.doctor import _unwrap_exception

    inner = RuntimeError("401 Unauthorized")
    group = BaseExceptionGroup("unhandled errors in a TaskGroup", [inner])
    unwrapped = _unwrap_exception(group)
    assert "401" in unwrapped
    assert "TaskGroup" not in unwrapped


def test_unwrap_handles_doubly_nested_groups() -> None:
    """Nested TaskGroups (mcp library has them) → dig all the way down."""
    from buttdial.doctor import _unwrap_exception

    inner = ConnectionError("connection refused")
    middle = BaseExceptionGroup("inner group", [inner])
    outer = BaseExceptionGroup("outer group", [middle])
    unwrapped = _unwrap_exception(outer)
    assert "refused" in unwrapped
    assert "group" not in unwrapped.lower()


def test_unwrap_plain_exception_passthrough() -> None:
    from buttdial.doctor import _unwrap_exception

    assert "boom" in _unwrap_exception(RuntimeError("boom"))


def test_stdout_unicode_detection_returns_bool() -> None:
    from buttdial.doctor import _stdout_supports_unicode

    assert isinstance(_stdout_supports_unicode(), bool)


def test_format_stage_ascii_mode() -> None:
    from buttdial.doctor import _format_stage
    from buttdial.models import DoctorStage

    s_ok = DoctorStage(name="Config", ok=True, detail="ok")
    s_bad = DoctorStage(name="SSE", ok=False, detail="401 Unauthorized")

    assert _format_stage(s_ok, ascii_only=True).startswith("[OK]")
    assert _format_stage(s_bad, ascii_only=True).startswith("[FAIL]")
    # No Unicode characters in ASCII output
    line = _format_stage(s_bad, ascii_only=True)
    assert "✗" not in line
    assert "→" not in line
    assert "--" in line  # em-dash replaced


def test_format_stage_unicode_mode() -> None:
    from buttdial.doctor import _format_stage
    from buttdial.models import DoctorStage

    s_ok = DoctorStage(name="Config", ok=True)
    s_bad = DoctorStage(name="SSE", ok=False)

    assert _format_stage(s_ok).startswith("[✓]")
    assert _format_stage(s_bad).startswith("[✗]")


def test_format_stage_renders_skipped_distinctly() -> None:
    """Skipped stages should not show as [FAIL] — they didn't fail (F91)."""
    from buttdial.doctor import _format_stage
    from buttdial.models import DoctorStage

    s_skip = DoctorStage(name="Send", ok=False, detail="skipped: no --to recipient provided")

    ascii_line = _format_stage(s_skip, ascii_only=True)
    assert ascii_line.startswith("[SKIP]")
    assert "[FAIL]" not in ascii_line

    unicode_line = _format_stage(s_skip, ascii_only=False)
    assert unicode_line.startswith("[○]")
    assert "[✗]" not in unicode_line


@pytest.mark.asyncio
async def test_stage_send_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")

    async def fake_send(**_: Any) -> SendResult:
        return SendResult(message_sid="SMok")

    monkeypatch.setattr(c, "send_message", fake_send)
    s, result = await stage_send(c, to="+1")
    assert s.ok is True
    assert result.message_sid == "SMok"


@pytest.mark.asyncio
async def test_stage_send_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")

    async def fake_send(**_: Any) -> SendResult:
        return SendResult(failed=True, error="401 unauthorized")

    monkeypatch.setattr(c, "send_message", fake_send)
    s, _ = await stage_send(c, to="+1")
    assert s.ok is False
    assert s.remediation is not None


# ----- stage_receipt ----------------------------------------------------


@pytest.mark.asyncio
async def test_stage_receipt_ok_when_dispatched() -> None:
    inbound = InboundHandler()

    async def _run() -> Any:
        return await stage_receipt(inbound, expected_sid="SM-abc", timeout=1.0)

    task = asyncio.create_task(_run())
    await asyncio.sleep(0.05)  # let stage_receipt register its capture handler
    receipt = DeliveryReceipt(message_sid="SM-abc", status="delivered")
    await inbound._dispatch_receipt(receipt)
    stage = await task
    assert stage.ok is True
    assert "delivered" in (stage.detail or "")
    # handler cleaned up
    assert len(inbound._receipt_handlers) == 0


@pytest.mark.asyncio
async def test_stage_receipt_timeout() -> None:
    inbound = InboundHandler()
    stage = await stage_receipt(inbound, expected_sid="SM-never", timeout=0.1)
    assert stage.ok is False
    assert "no receipt" in (stage.detail or "").lower()
    assert len(inbound._receipt_handlers) == 0


@pytest.mark.asyncio
async def test_stage_receipt_ignores_wrong_sid() -> None:
    inbound = InboundHandler()

    async def _run() -> Any:
        return await stage_receipt(inbound, expected_sid="SM-target", timeout=0.2)

    task = asyncio.create_task(_run())
    await asyncio.sleep(0.05)
    # Dispatch an unrelated SID — should be ignored, stage should time out.
    await inbound._dispatch_receipt(DeliveryReceipt(message_sid="SM-other", status="sent"))
    stage = await task
    assert stage.ok is False


# ----- stage_ack --------------------------------------------------------


@pytest.mark.asyncio
async def test_stage_ack_ok() -> None:
    from buttdial.models import InboundMessage

    inbound = InboundHandler()

    async def _run() -> Any:
        return await stage_ack(inbound, from_sender="+1", timeout=1.0)

    task = asyncio.create_task(_run())
    await asyncio.sleep(0.05)
    await inbound._dispatch_message(InboundMessage(sender="+1", channel="whatsapp", text="got it"))
    stage = await task
    assert stage.ok is True
    assert "got it" in (stage.detail or "")


@pytest.mark.asyncio
async def test_stage_ack_timeout() -> None:
    inbound = InboundHandler()
    stage = await stage_ack(inbound, from_sender="+1", timeout=0.1)
    assert stage.ok is False


# ----- orchestration (run_diagnostic) -----------------------------------


@pytest.mark.asyncio
async def test_run_diagnostic_fails_fast_on_config() -> None:
    c = Agent(base_url="https://fake.test", agent_id="agt-1")  # no token
    report = await run_diagnostic(c)
    assert report.ok is False
    assert report.stages[0].name == "Config loaded"
    assert report.stages[0].ok is False
    # All 6 subsequent stages marked skipped
    assert len(report.stages) == 7
    assert all(s.detail and "skipped" in s.detail for s in report.stages[1:])


@pytest.mark.asyncio
async def test_run_diagnostic_skips_send_without_to(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stages 1-4 can pass without `to`; stages 5-7 skip."""
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")

    async def fake_reach(_c: Agent, *, timeout: float = 10.0) -> Any:
        from buttdial.models import DoctorStage

        return DoctorStage(name="Server reachable", ok=True)

    async def fake_probe(_c: Agent) -> Any:
        from buttdial.models import DoctorStage

        return (
            DoctorStage(name="SSE handshake", ok=True),
            DoctorStage(name="Tool list", ok=True),
        )

    monkeypatch.setattr("buttdial.doctor.stage_reachability", fake_reach)
    monkeypatch.setattr("buttdial.doctor._probe_session", fake_probe)

    report = await run_diagnostic(c)  # no to, no inbound_handler

    assert report.ok is True  # first 4 passed, later 3 are skipped
    assert len(report.stages) == 7
    stage_names = [s.name for s in report.stages]
    assert stage_names == [
        "Config loaded",
        "Server reachable",
        "SSE handshake",
        "Tool list",
        "send_message accepted",
        "Delivery receipt",
        "Human ack loopback",
    ]
    # Last three should be skipped
    for s in report.stages[-3:]:
        assert "skipped" in (s.detail or "")


@pytest.mark.asyncio
async def test_run_diagnostic_full_flow(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stages 1-6 succeed; stage 7 skipped (expect_ack=False)."""
    c = Agent(base_url="https://fake.test", agent_id="agt-1", agent_token="t")
    inbound = InboundHandler()

    from buttdial.models import DoctorStage

    async def ok_reach(_c: Agent, *, timeout: float = 10.0) -> Any:
        return DoctorStage(name="Server reachable", ok=True)

    async def ok_probe(_c: Agent) -> Any:
        return (
            DoctorStage(name="SSE handshake", ok=True),
            DoctorStage(name="Tool list", ok=True),
        )

    async def ok_send(**_: Any) -> SendResult:
        return SendResult(message_sid="SM-loop")

    monkeypatch.setattr("buttdial.doctor.stage_reachability", ok_reach)
    monkeypatch.setattr("buttdial.doctor._probe_session", ok_probe)
    monkeypatch.setattr(c, "send_message", ok_send)

    # Schedule a receipt to arrive shortly after stage 6 begins
    async def scheduled_receipt() -> None:
        await asyncio.sleep(0.05)
        await inbound._dispatch_receipt(DeliveryReceipt(message_sid="SM-loop", status="delivered"))

    task = asyncio.create_task(scheduled_receipt())
    report = await run_diagnostic(c, to="+1", inbound_handler=inbound, receipt_timeout=1.0)
    await task

    assert report.ok is True
    names = [s.name for s in report.stages]
    assert names[-1] == "Human ack loopback"
    # 7th stage skipped because expect_ack=False
    assert "skipped" in (report.stages[-1].detail or "")
    # Stages 1-6 all ok
    for s in report.stages[:-1]:
        assert s.ok is True


# ----- CLI --------------------------------------------------------------


def test_cli_doctor_runs_and_exits_non_zero(monkeypatch: pytest.MonkeyPatch) -> None:
    """CLI entry point loads, runs, and exits non-zero when config is missing."""
    from click.testing import CliRunner

    from buttdial.doctor import cli as buttdial_cli

    # Wipe env so config stage fails.
    monkeypatch.delenv("BUTT_DIAL_URL", raising=False)
    monkeypatch.delenv("BUTT_DIAL_BASE_URL", raising=False)
    monkeypatch.delenv("BUTT_DIAL_AGENT_TOKEN", raising=False)
    monkeypatch.delenv("BUTT_DIAL_AGENT_ID", raising=False)
    monkeypatch.delenv("BUTT_DIAL_TEAM_TOKEN", raising=False)

    runner = CliRunner()
    # Agent.from_env requires base_url — will ValueError before run_diagnostic.
    # We accept either exit 1 (diagnostic failed) or 2 (crashed) — both are
    # "the CLI did not claim success", which is what we're testing.
    result = runner.invoke(buttdial_cli, ["doctor", "--to", "+1"])
    assert result.exit_code != 0


def test_cli_doctor_has_expected_options() -> None:
    from click.testing import CliRunner

    from buttdial.doctor import cli as buttdial_cli

    runner = CliRunner()
    result = runner.invoke(buttdial_cli, ["doctor", "--help"])
    assert result.exit_code == 0
    assert "--to" in result.output
    assert "--expect-ack" in result.output
