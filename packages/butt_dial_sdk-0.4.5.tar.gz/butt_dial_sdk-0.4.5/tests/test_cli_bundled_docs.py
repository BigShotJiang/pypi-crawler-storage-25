"""Tests for `buttdial guide`, `buttdial example`, `buttdial errors`.

These commands ship in 0.4.3 to make the SDK self-reliant for agentic
integrators — `pip install butt-dial-sdk` should be enough; no GitHub
round-trip needed.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from buttdial.doctor import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def test_guide_prints_agents_md(runner: CliRunner) -> None:
    """`buttdial guide` should print the bundled AGENTS.md to stdout."""
    result = runner.invoke(cli, ["guide"])
    assert result.exit_code == 0
    # Sanity-check it's actually AGENTS.md content, not an error.
    assert "AGENTS.md" in result.output or "agent-readable contract" in result.output
    assert "register" in result.output  # at least one of the recipes
    assert len(result.output) > 1000  # full doc, not a stub


def test_example_list_shows_all_four(runner: CliRunner) -> None:
    """`buttdial example list` must show all four canonical examples."""
    result = runner.invoke(cli, ["example", "list"])
    assert result.exit_code == 0
    for name in ("with-onboarding-handshake", "with-inbound", "with-retry", "minimal"):
        assert name in result.output, f"missing {name} from list output"
    assert "buttdial example show" in result.output  # usage hint
    assert "buttdial example extract" in result.output


def test_example_show_prints_files(runner: CliRunner) -> None:
    """`buttdial example show with-onboarding-handshake` prints app.py + README.md."""
    result = runner.invoke(cli, ["example", "show", "with-onboarding-handshake"])
    assert result.exit_code == 0
    assert "app.py" in result.output
    assert "README.md" in result.output
    # Content sanity checks
    assert "register" in result.output
    assert "verify_webhook_signature" in result.output


def test_example_show_unknown_returns_error(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["example", "show", "does-not-exist"])
    assert result.exit_code == 2
    assert "unknown example" in result.output


def test_example_extract_copies_directory(runner: CliRunner, tmp_path: Path) -> None:
    """`buttdial example extract` must copy a real example to the destination."""
    result = runner.invoke(cli, ["example", "extract", "minimal", str(tmp_path)])
    assert result.exit_code == 0
    extracted = tmp_path / "minimal"
    assert extracted.is_dir()
    assert (extracted / "send_one.py").is_file()
    assert "Hello from butt-dial-sdk" in (extracted / "send_one.py").read_text(encoding="utf-8")


def test_example_extract_refuses_overwrite(runner: CliRunner, tmp_path: Path) -> None:
    """Refuse to overwrite an existing destination, even if it's just a stub."""
    (tmp_path / "minimal").mkdir()
    result = runner.invoke(cli, ["example", "extract", "minimal", str(tmp_path)])
    assert result.exit_code == 2
    assert "already exists" in result.output


def test_errors_prints_typed_reference(runner: CliRunner) -> None:
    """`buttdial errors` prints the typed-exception reference table."""
    result = runner.invoke(cli, ["errors"])
    assert result.exit_code == 0
    # A few representative entries should be present.
    for cls in ("AuthInvalidTokenError", "AuthLockedOutError", "NotProvisioned",
                "ProviderCapabilityError", "OTPInvalid", "EmailAlreadyRegistered"):
        assert cls in result.output, f"missing {cls} from errors output"


def test_bundled_files_present_in_package() -> None:
    """The wheel must include _docs/AGENTS.md and _examples/* (verified at install time)."""
    import buttdial

    pkg_root = Path(buttdial.__file__).resolve().parent
    assert (pkg_root / "_docs" / "AGENTS.md").is_file(), \
        "AGENTS.md must be bundled in the package — run scripts/sync_docs_to_package.py before build"

    examples_root = pkg_root / "_examples"
    assert examples_root.is_dir(), "_examples directory must be bundled"
    for name in ("with-onboarding-handshake", "with-inbound", "with-retry", "minimal"):
        assert (examples_root / name).is_dir(), f"missing _examples/{name}"
