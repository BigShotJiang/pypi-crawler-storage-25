<!-- version: 2.0 | updated: 2026-04-29 -->

# Butt-Dial Server — What's Not Done + New Findings

**Status as of:** server commit `10e4439` (sprint 10), SDK commit reflecting sprint-10 verification
**Source:** `docs/BD_SERVER_FEEDBACK_5.md` v2.0 filtered to open items
**Audience:** BD server team — actionable backlog ready for sprint planning

> **v2.0 update:** Sprint 10 closed 7 items: F04, F11, F12, F43, F56, F63, F80, F82. F89 still open. Counts and sections below reflect post-sprint-10 state.

## Headline

```
✅ FIXED:                  46 / 89  (52%)   +7 sprint 10
⚠️ PARTIAL:                10 / 89  (11%)   -4
❌ OPEN:                   28 / 89  (31%)   -3
🚫 WONTFIX-BY-DESIGN:       1 / 89   (1%)   F77 (closed by F04 precedence)
ℹ️ INFO / architectural:   4 / 89   (4%)
```

**38 items still need attention** (28 OPEN + 10 PARTIAL). F89 remains the highest-priority new finding from round 5. Recommended sprint sequencing at the bottom.

---

## A. NEW FINDING — F89 [HIGH] — webhookSecret presence reintroduces F04 oracle

### Observed live on `65fee63`

```bash
# T1 — pending email + webhookUrl
POST /api/orgs/register
  body: {orgName, ownerEmail: "<NEW>", webhookUrl: "..."}
→ 200 {orgId, verificationSent: true, webhookSecret: "<64 hex chars>"}

# T3 — verified email + webhookUrl  (asymmetric!)
POST /api/orgs/register
  body: {orgName, ownerEmail: "<VERIFIED>", webhookUrl: "..."}
→ 200 {orgId, verificationSent: true}     ← no webhookSecret
```

### Why it matters

An attacker probing `register({email: target, webhookUrl: <anything>})` can branch on the **presence** of `webhookSecret` in the response to confirm whether `target` is a verified customer. This reintroduces the F04 enumeration oracle through a different field, despite the F04 protector test in the server suite.

### Recommended fix

**Option A (preferred, low effort):** Always emit a `webhookSecret` value when `webhookUrl` is provided, regardless of email-verification state. For verified-email cases, return a randomized dummy that's never used (no webhook fires for that path anyway). Response shape becomes constant from the attacker's perspective.

**Option B (Stripe-style, more invasive):** Caller pre-generates the secret and passes it in the request body; BD never echoes it back. Eliminates the leak entirely.

### Severity

**HIGH.** Mitigated for now by F02 rate-limit (5/min per IP), but a determined attacker can still enumerate at low rates. Recommended for next sprint.

### Reproducer

`scripts/probe_round3.py` plus the live curl probes in `BD_SERVER_FEEDBACK_5.md` Section B/T1+T3.

---

## B. OPEN — sorted by priority

### B.1 — Quick wins (≤ 1 hour each)

| ID | Title | Fix |
|---|---|---|
| **F71** | `X-Powered-By: Express` still leaks framework | One-liner: `app.disable('x-powered-by')` |
| **F89** | webhookSecret presence asymmetry | Section A above |
| **F73** | OpenAPI not at root path | Mount `/openapi.json` (root) in addition to `/api/v1/openapi.json` |
| ~~**F80**~~ | ~~verification-status works without auth~~ | ✅ **CLOSED in sprint 10** — Bearer + `?poll_token=` paths work, 401 without auth |
| ~~**F82**~~ | ~~`channelHealth` string-encoded~~ | ✅ **CLOSED in sprint 10** — `channelsDown: 6, channelsTotal: 12` (top-level int) |
| **F81** | docs/API drift: `maxCallsPerDaySameNumber` | docs say 2, API says 10 — pick one, sync the other |

### B.2 — Casing & naming migration (mostly done in sprint 10!)

| ID | Title | Status |
|---|---|---|
| ~~**F11**~~ | ~~4+ token names~~ | ✅ **sprint 10**: `teamToken` canonical; aliases deprecated |
| ~~**F12**~~ | ~~verify response triple-hedge~~ | ✅ **sprint 10**: snake_case marked deprecated (still emitted, sunset 90d) |
| ~~**F43**~~ | ~~agent record dual casing~~ | ✅ **sprint 10**: snake_case marked deprecated |
| ~~**F56**~~ | ~~REST snake vs MCP camel~~ | ✅ **sprint 10**: REST snake_case marked deprecated |
| **F75** | `retryAfter` + `retry_after` hedge on RATE_LIMITED | OPEN — likely covered by next sweep alongside snake_case removal |
| **F55** | docs use mixed "client"/"agent"/"provider" vocab | OPEN — needs separate doc-update pass |

**Verification gap on the sprint-10 deprecation headers:** I observed the `Deprecation:` + `Sunset:` headers on the legacy `GET /api/orgs/verify?token=...` route (per F33), but did NOT see them on `/api/orgs/me` or `/api/v1/agents/{id}` despite those endpoints emitting both casings. **Worth confirming with BD which endpoints/responses get the headers.** Doesn't block adoption — programmatic detection still works on the deprecated route — but the per-response signaling claim deserves verification.

### B.3 — MCP tool surface improvements

| ID | Title | Recommended fix |
|---|---|---|
| **F58** | `comms_whatsapp_action` is a 13-action mega-dispatcher | Split into 13 separate tools, OR use JSON Schema `oneOf` discriminator |
| **F59** | `comms_make_call.orchestrator` enum leaks internal IDs (`conversation-relay`, `gemini-live`, etc.) | Either remove from public schema, or rename to abstract names (`fast`, `multimodal`, etc.) |
| **F61** | MCP validation errors are Zod-stringified inside JSON-RPC error message | Return structured Zod output via JSON-RPC `data` field |
| **F67** | `country` field in `comms_provision_channels` is ambiguous | Rename to `purchaseRegion` and clarify description |
| **F68** | `comms_send_message.body` is required-conditional, schema marks optional | Use `oneOf` with discriminator on `body`/`media`/`templateId` |
| **F40** | `comms_` prefix on every tool (now 60/60) | Drop prefix or split into sub-namespaces |
| **F21** | MCP `serverInfo.version` stuck at `0.1.0` | Bump on every breaking change (or every release) |
| ~~**F63**~~ | ~~scope prefix audit~~ | ✅ **sprint 10**: 60/60 tools, refined to `[scope: agent\|org-admin\|super-admin\|any]` |

### B.4 — Lifecycle & observability

| ID | Title | Recommended fix |
|---|---|---|
| **F05** | `verificationSent: true` is sync-optimism | Wire mailer webhook (SES/Postmark/SendGrid) to track delivery state |
| **F27** | No explicit `lifecycleState` field on agent/org | Add documented enum: `unverified, verified, phone_pending, phone_confirmed, ready, suspended` |
| **F34** | No lifecycle-event webhook (token rotated, channel suspended) | Extend the F26 webhook with more event types |
| **F31** | No `RateLimit-*` HTTP headers on success responses | Add IETF-draft `RateLimit-Limit / -Remaining / -Reset` headers |
| **F24** | No emergency token-revocation endpoint | `DELETE /api/orgs/me/tokens/{id}` (auth via the token itself) |

### B.5 — Endpoint completeness

| ID | Title | Recommended fix |
|---|---|---|
| **F15** | No DELETE org endpoint (currently 405) | `DELETE /api/orgs/{id}` (auth via team_token, requires phone confirmation) |
| **F16** | No "list orgs I own" endpoint (404) | `GET /api/users/me/orgs` |
| **F29** | "is not provisioned" vs "not found in this org" wording divergence | Pick one phrase + one code (`AGENT_NOT_FOUND` or `NO_AGENT_FOR_ORG`) |
| **F39** | Redundant `success: true` flag on provision response (untested in r5) | Drop — HTTP 2xx already means success |

### B.6 — Information architecture

| ID | Title | Recommended fix |
|---|---|---|
| **F79** | System agent (`Butt-Dial System`) undocumented | Add to `/docs/mcp-tools` or `/docs/architecture` — what it is, what messages it accepts, does it count toward `maxAgents`? |
| **F83** | `/api/v1/agents` paths NOT in OpenAPI (uses `/clients/{agentId}` instead) | Either include `/agents` paths or document the migration plan from `/agents` → `/clients/{agentId}` |
| **F84** | Brand inconsistency — OpenAPI title is "VOS Communication Platform"; MCP says `butt-dial-mcp`; emails/docs say "Butt-Dial" | Pick one product name, apply to OpenAPI `info.title`, MCP `serverInfo.name`, all docs, email copy |
| **F86** | Three parallel surfaces (admin REST + customer REST + MCP) | Pick one canonical mapping; expose others as thin proxies; document which is the source of truth for each operation |

### B.7 — Larger / strategic

| ID | Title | Notes |
|---|---|---|
| **F06** | Org-name squatting (`orgName: "Microsoft"`) | Needs product decision — display-only string with DNS-verification path for enterprise tier |
| **F13** | SDK `verify()` docstring drift — claims `mode`, server returns `scopes` | SDK-side fix; will land when next SDK release goes out |
| **F57** | SDK `provision_channels` accepts list-shape that server doesn't accept | SDK-side cleanup |
| **F77** | 🚫 WONTFIX-BY-DESIGN — `EmailAlreadyRegistered` 409 was proposed but rejected | F04 takes precedence; closed |

---

## C. PARTIAL — work has started, needs finishing

| ID | Status | What's done | What's left |
|---|---|---|---|
| **F04** | ⚠️ | Same shape for new vs verified email when no `webhookUrl` | Deterministic orgId still leaks existence; F89 introduces a second leak |
| **F10** | ⚠️ | Subsumed by F43/F56 | See casing-migration cluster (B.2) |
| **F20** | ⚠️ | OpenAPI 3.1 published | Only at `/api/v1/openapi.json`, only 19 paths (see F73, F83) |
| **F30** | ⚠️ | All 57 tools have `[scope:]` prefix; descriptions improved | Some tool descriptions still reference internal vocabulary (e.g. `HX...` Twilio Content SIDs) |
| **F36** | ⚠️ | Aware of REST + MCP duplication | Decision pending — see F86 |
| **F42** | ⚠️ | Agent record now has `createdAt` + `provisioned_at` | Still `status: "active"` despite no channels — see F27 lifecycleState |
| **F43** | ⚠️ | Both casings emitted | Pick canonical, sunset duplicates — see B.2 |
| **F54** | ⚠️ | `pool` removed from ping; agent `status="active"` still vague | Same as F42 |
| **F56** | ⚠️ | Same as F43 | See B.2 |
| **F57** | ⚠️ | SDK-side cleanup | SDK side will land in next release |
| **F66** | ⚠️ | Tool descriptions improved with `[scope:]` prefix | Some still reference internal vocab |
| **F73** | ⚠️ | OpenAPI exists | Mount at root `/openapi.json` too — see B.1 |
| **F78** | ⚠️ | Honest `_unverified: true`, `_source: "mock-telephony-no-lookup"` | Still claims `valid: true` without real lookup. Either wire to Twilio Lookup, or drop `valid: true` claim |
| **F85** | ⚠️ | No 502s observed in round 5 (likely zero-downtime now) | Leave as flag; revisit if 502s recur |

---

## D. Recommended sprint sequencing

### Sprint 10 (next sprint — quick wins + casing decision)

**Goal: tighten the surface, decide on canonical names.**

1. **F89** (HIGH) — randomized webhookSecret on verified-email register
2. **F71** (LOW) — disable X-Powered-By
3. **F73** (MEDIUM) — `/openapi.json` at root
4. **F80** (HIGH) — auth-gate `/verification-status` endpoint
5. **F82** (LOW) — numeric `channelHealth`
6. **F81** (LOW) — sync `maxCallsPerDaySameNumber` between docs and API
7. **Decision:** pick canonical token name (recommend `teamToken` + `agentToken`) and casing (recommend camelCase)

**Estimate:** 2–3 dev-days for items 1–6; the canonical-names decision is a 30-min meeting.

### Sprint 11 (casing + naming migration)

**Goal: stop hedging.**

8. **F11** — apply canonical token name everywhere (docs, email copy, response fields, error messages)
9. **F43, F56, F75, F12** — drop snake_case duplicates from REST responses; emit `Deprecation:` headers on the legacy form (90-day sunset window starts here)
10. **F55** — pick canonical "agent" vs "client" vocabulary in docs

**Estimate:** 1 sprint. Mechanical work but lots of touch points.

### Sprint 12 (MCP improvements)

**Goal: better LLM-agent ergonomics.**

11. **F58** — split `comms_whatsapp_action` into per-action tools (or `oneOf` schema)
12. **F61** — structured Zod errors via JSON-RPC `data` field
13. **F68** — `oneOf` schema for `comms_send_message.body` conditional
14. **F67** — rename `country` → `purchaseRegion` and clarify
15. **F59** — abstract `orchestrator` enum or remove from public schema
16. **F40, F21** — drop `comms_` prefix; bump MCP `serverInfo.version` per release

**Estimate:** 1 sprint. F58 is the bulk of the work.

### Sprint 13+ (strategic)

17. **F05** — mailer-delivery webhook lifecycle
18. **F27, F34, F42, F54** — explicit `lifecycleState` field + lifecycle-event webhooks
19. **F84, F86** — brand consolidation + REST surface unification
20. **F06** — org-name squatting protection (product decision needed)

---

## E. Items the SDK side will handle

These don't need server work; they're for the SDK release queue:

- **F13** — SDK `verify()` docstring drift (`mode` → `scopes`)
- **F57** — SDK `provision_channels` list-shape cleanup
- **F77** — `EmailAlreadyRegistered` documented as intentionally unreachable (already done at `90d90ad`)

---

## F. References

- Round-5 audit (full F-list): `docs/BD_SERVER_FEEDBACK_5.md`
- Sprint 9 BD doc: `docs/BD_SERVER_HANDSHAKE_SHIPPED.md`
- Audit trail (rounds 1–4): `docs/BD_SERVER_FEEDBACK.md`, `_2.md`, `_3.md`, `_4.md`
- Onboarding instructions (history): `docs/BD_SERVER_INSTRUCTIONS_onboarding.md` (v1.1)
- SDK side: `src/buttdial/accounts.py`, `src/buttdial/webhooks.py`
- Probe scripts: `scripts/probe_*.py`
