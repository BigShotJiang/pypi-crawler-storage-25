<!-- version: 1.0 | updated: 2026-04-28 -->

# Butt-Dial Server — API & Contract Review (Round 3)

**To:** Butt-Dial server team
**From:** SDK side review (continued)
**Date generated:** 2026-04-28
**SDK version:** 0.3.0
**Server probed:** `https://call.95percent.ai`
**Org / agent under test:** `28bf35dd-995f-46ac-96da-1f99ac9d9b52` / `d51b0eb9-0a27-4225-bb55-9c9355935f87`

## What this document is

Third-round review, building on `BD_SERVER_FEEDBACK.md` and `BD_SERVER_FEEDBACK_2.md`. This round closed out the schema-mismatch tools from round 2 (using correct field names this time), tested HTTP discoverability (HEAD, OPTIONS, version paths, malformed bodies), and inspected the `/docs` website.

Findings continue with stable IDs **F70–F83**. Status updates on prior rounds are at the top.

---

## CRITICAL — read this first

### F70 [CRITICAL] [open] — `comms_rotate_token` rotates with NO confirmation flag

**Observed.** Calling the MCP tool with an **empty argument object** rotated the production agent's auth credential immediately:

```python
await session.call_tool("comms_rotate_token", arguments={})
# ↓ response:
{
  "accepted": true,
  "action": "rotate_token",
  "newToken": "6ce1d93e...",
  "gracePeriodSeconds": 30,
  "instructions": "Store this token. Reconnect to /sse with Authorization: Bearer <newToken> within 30 seconds. The old token will be revoked after the grace period."
}
```

This happened to me **by accident** during round-3 probing. I called `rotate_token({})` expecting a Zod validation error (since I assumed something like `confirm: true` would be required). Instead the token rotated, the 30s grace window elapsed before I could react, and the old token now returns `AUTH_INVALID_TOKEN`.

**Why it matters.**

For agentic systems this is a **footgun of the worst kind**:
- An LLM agent reading the tool list sees `comms_rotate_token` and `description: "Rotate your security token. Returns a new token."` That description doesn't say "destructive, requires explicit intent."
- An agent debugging an auth issue might call this tool exploratorily ("let me rotate to see if a fresh token fixes it") — and **immediately invalidate every other process using the old token**, including itself if it doesn't catch the response.
- Tool calls are how agents probe. Probing should not have permanent destructive consequences without explicit opt-in.
- An LLM hallucinating this tool name and calling it with empty args ALSO rotates the token. There is zero protection.

**Recommended fix.** Require an explicit confirmation parameter to actually execute:

```json
"inputSchema": {
  "type": "object",
  "required": ["confirm"],
  "properties": {
    "confirm": {
      "const": true,
      "description": "MUST be true. Required to prevent accidental rotation. Old token is revoked after gracePeriodSeconds (default 30s) and cannot be recovered."
    }
  }
}
```

With `confirm` not passed → return preview-mode response: `{"wouldRotate": true, "currentTokenLastFour": "ac91", "instructions": "Pass confirm=true to actually rotate."}`

Apply the same pattern to every destructive tool: `comms_deprovision_channels`, `comms_revoke_consent`, `comms_revoke_trust`, `comms_close_session`, `comms_expand_client_pool` (admin), `comms_set_client_limits` (admin).

---

## Status updates on prior rounds

| ID | Status | Notes |
|---|---|---|
| F08 (error envelope inconsistent) | **partial-pattern-exists in MORE places than thought** | Structured envelope (`{error, code, fields, retryable}`) appears on auth errors (round 2), 404-route errors (this round), and `MISSING_FIELDS` errors (this round). Only the validation-after-parse path uses the unstructured form. The pattern is everywhere; the gap is one code path. |
| F19/F20 (no /healthz, /version, /openapi.json) | unchanged | Still 404. But `/docs` website is real with sections for "Getting Started", "Reference: MCP Tools / API Reference / Providers", "Guides: Architecture / Security / Monitoring", "Help: Troubleshooting". Just no machine-readable schema. |
| F37 (non-ISO timestamp) | **partial-fix observed** | REST `/api/v1/agents/me` now returns `"provisioned_at": "2026-04-28T14:38:49Z"` (proper ISO 8601). But MCP `comms_get_channel_status` returned the non-ISO form (`"2026-04-28 14:38:49"`) in round 2. Either fix landed only on REST, or formats differ across surfaces for the same field. See F80. |
| F61 (Zod-stringified validation errors on MCP) | unchanged + corroborated | Confirmed across `comms_send_otp`, `comms_verify_otp`, `comms_create_session`, `comms_subscribe_inbound`, `comms_set_callback_url`, `comms_set_voice_callback`, `comms_get_message_status`. All use the same MCP-error-message-prefix-with-stringified-Zod pattern. |
| F69 (`.env` file mentioned in `comms_register_provider`) | unchanged | Still present in tool description. |

---

## TL;DR — round 3

1. **F70** [CRITICAL] — `comms_rotate_token({})` rotates immediately with no confirm flag. Destructive tool with zero guardrails.
2. **F71** [HIGH] — No CORS headers on OPTIONS responses. Browser-based clients (web playground, browser-extension agents) cannot call this API.
3. **F72/F73** [HIGH] — HEAD and unsupported-methods both return 404 (should be 405 Method Not Allowed). Misleads clients.
4. **F74** [MEDIUM] — `comms_validate_number` returns `"Mock Carrier"` in production. Mocked provider not switched off, OR carrier-lookup integration is broken.
5. **F77** [MEDIUM] — `comms_find_agent` shows a system agent but **excludes the actual provisioned agent**. Directory is broken or has undocumented filters.
6. **F78** [MEDIUM] — Server silently accepts unknown fields despite `additionalProperties: false`. Hides typos for agents.

**Positive:** the 404-route error envelope is the **best on this server** — `{error, message, path, method, docs}`. Strong template for F08 fix.

---

## A. Critical / contract bugs

### F71 [HIGH] [open] — No CORS headers; browser clients cannot use this API

**Observed.** OPTIONS preflight on both `/api/orgs/register` and `/sse`:

```
HTTP/1.1 204 No Content
Server: nginx/1.24.0
X-Frame-Options: DENY
Strict-Transport-Security: max-age=31536000
Content-Security-Policy: default-src 'none'

(no Access-Control-Allow-Origin, -Methods, -Headers)
```

**Why it matters.**
- A browser-based MCP client (web-based admin dashboard, in-browser agent UI, browser-extension agent) sends a CORS preflight before any cross-origin call. With no `Access-Control-Allow-*` headers in the response, the browser refuses the actual request.
- The server architecture appears intended to support direct browser SSE connections (the `/sse` MCP transport is browser-native), but CORS misconfiguration blocks them.
- For agentic systems running in browsers (e.g., Claude.ai's browser tools, OpenAI's web UI agents): they need to either proxy through a backend or be locked out.

**Recommended fix.** Configure CORS:
- For public endpoints (e.g. `/api/orgs/register`, `/api/orgs/verify`): consider `Access-Control-Allow-Origin: *` if no credentials, or a specific allow-list of trusted origins.
- For authenticated endpoints: `Access-Control-Allow-Origin: <reflect-from-Origin-if-allowlisted>` + `Access-Control-Allow-Credentials: true`.
- Set `Access-Control-Allow-Methods: GET, POST, OPTIONS` and `Access-Control-Allow-Headers: Authorization, Content-Type, Idempotency-Key`.
- Or document explicitly that this API is server-to-server only and browsers must proxy.

### F72 [HIGH] [open] — HEAD returns 404 instead of mirroring GET / 405 instead of POST-only

**Observed.** `HEAD /api/orgs/register` → 404 Not Found.

**Why it matters.** RFC 9110 §9.3.2: HEAD must return the same headers GET would (or 405 if the resource only supports other methods). Returning 404 tells a probing client that the endpoint *doesn't exist* — which leads to wasted retry cycles and incorrect alerting from monitors that use HEAD-based probes.

**Recommended fix.**
- For POST-only endpoints: HEAD returns 405 with `Allow: POST` header.
- For endpoints that have a GET surface: HEAD returns the same status + headers as GET, with empty body.

### F73 [HIGH] [open] — Unsupported method returns 404 instead of 405

**Observed.** `PUT /api/orgs/me` (an existing resource) returns:

```json
{
  "error": "not_found",
  "message": "No endpoint matches PUT /api/orgs/me. Check the API docs or your client version.",
  "path": "/api/orgs/me",
  "method": "PUT",
  "docs": "https://call.95percent.ai/docs"
}
```

**Why it matters.** The resource `/api/orgs/me` exists. PUT just isn't implemented for it. RFC 9110 §15.5.6: this is a 405 Method Not Allowed condition, not a 404. Returning 404 misleads clients into believing the resource is missing.

The error envelope here is excellent (the best on this server, see Positive Findings) — just the wrong status code.

**Recommended fix.** When the path matches an existing route but the method isn't implemented for it: return 405 + `Allow: GET, POST` header listing the methods that *are* allowed.

---

## B. Tool / API correctness

### F74 [MEDIUM] [open] — Production `comms_validate_number` returns "Mock Carrier"

**Observed.** Real, valid phone numbers (US `+15555550123`, IL `+972526557547`) return:

```json
{
  "valid": true,
  "phoneNumber": "+15555550123",
  "countryCode": "US",
  "lineType": "mobile",
  "carrier": {"name": "Mock Carrier", "type": "mobile"},
  "callerName": null,
  "canReceiveSms": true,
  "canReceiveCall": true
}
```

**Why it matters.**
- An agent that validates a number before sending will believe `Mock Carrier` is the actual carrier name — and may store/log/display it.
- `canReceiveSms: true` and `canReceiveCall: true` for `+15555550123` (a non-routable test range) means the validation isn't actually checking carrier records; it's just returning canned data.
- For an agentic system that decides whether to route via SMS or voice based on carrier type — this is unreliable.

**Recommended fix.** Either:
- Wire the production server to a real carrier lookup (Twilio Lookup API, NeustarTRA, etc.), OR
- If carrier lookup is genuinely unavailable, return `{"carrier": null, "_source": "unverified"}` and document that explicitly. Don't return fake data labeled as truth.

### F75 [MEDIUM] [open] — `check_consent` and `check_trust` have inconsistent response shapes

**Observed.**

```json
// comms_check_consent({contactAddress, channel})
{"hasConsent": false, "status": "none", "message": "No consent record found"}

// comms_check_trust({contactAddress})
{"trusted": false}
```

**Why it matters.** Both tools answer "is this contact OK to communicate with on dimension X?" — but their responses are shaped completely differently. `check_consent` has `hasConsent`, `status` enum, and explanatory `message`. `check_trust` has only a single boolean.

For agents reasoning about consent + trust as a unified policy gate: they have to maintain different parsing logic per tool.

**Recommended fix.** Unify on the richer shape:

```json
// check_trust should return:
{
  "trusted": false,
  "status": "none",          // or "active", "expired", "revoked"
  "expiresAt": null,
  "message": "No trust session for this contact"
}
```

Then both tools use the same `{<flag>, status, message, expiresAt}` template.

### F76 [MEDIUM] [open] — `send_otp` uses `to`, `verify_otp` uses `contactAddress`

**Observed.** From the round-3 Zod errors:

```
comms_send_otp:    required fields: ["to", "channel"]
comms_verify_otp:  required fields: ["contactAddress", "code"]
```

Same conceptual recipient, two field names within a tightly-coupled tool pair.

**Why it matters.** Hardens F55 (vocabulary chaos). An agent using these as a pair — send_otp followed by verify_otp — has to remember to translate `to` ↔ `contactAddress`. Trivial bug source.

Also: `comms_send_message` uses `to`, `comms_make_call` uses `to`, `comms_validate_number` uses `phoneNumber`, `comms_check_consent` uses `contactAddress`, `comms_check_trust` uses `contactAddress`, `comms_get_contact_profile` likely uses something else again. Six different conventions for "the recipient".

**Recommended fix.** Pick one. Recommendation: `to` for "send-this-thing-to" tools and `contact` for "look-up-info-about" tools. Then audit and migrate.

### F77 [MEDIUM] [open] — `comms_find_agent` returns system agent but not provisioned agent

**Observed.** Empty-args call to `comms_find_agent({})`:

```json
{
  "agents": [
    {
      "agentId": "system-butt-dial-28bf35dd-995f-46ac-96da-1f99ac9d9b52",
      "name": "Butt-Dial System",
      "channels": {"sms": false, "email": true, "whatsapp": false}
    }
  ],
  "count": 1
}
```

The agent we registered (`d51b0eb9-...`, `display_name: "elradts-probe-agent"`, `status: "active"`) **does not appear** in the directory.

**Why it matters.** Either:
- The directory has an undocumented filter (e.g. "must have at least one provisioned channel" — our agent has none).
- It's a bug — provisioned agents aren't being indexed.

For the agent-to-agent communication feature advertised on `/docs` ("AI clients find and message each other. Multi-agent workflows"), this is a critical correctness issue. An agent that calls `comms_find_agent` to look for collaborators will see an incomplete picture.

Bonus issue: the system agent's `agentId` is `system-butt-dial-<orgId>` — embedding the orgId in an opaque-looking identifier leaks structure and risks confusion with real agent IDs.

**Recommended fix.**
- Document the directory filter explicitly (in tool description and `/docs/api-reference`).
- If filter is "channels provisioned" — show un-provisioned agents too with a `state: "draft"` flag. Or expose a separate `comms_list_org_agents` admin tool that returns all agents regardless of state.
- Use opaque UUIDs for system agents — don't embed the orgId.

### F78 [MEDIUM] [open] — Server silently accepts unknown fields despite `additionalProperties: false`

**Observed.**

```python
result = await session.call_tool("comms_ping", {"unknownField": "should-be-rejected"})
# → succeeds, returns normal ping response
```

But the `comms_ping` schema declares `"additionalProperties": false` (verified in round 2 probe). Server doesn't enforce it.

**Why it matters.**
- For agents: an LLM that hallucinates a field name (`recipient` instead of `to`, or `phoneNumber` instead of `phone`) gets silent acceptance and the field is ignored — but the agent thinks it succeeded. A subsequent call with the *correct* field then fails differently because the agent's expectation diverged from server reality.
- For schema fidelity: `additionalProperties: false` is a contract. Either remove the declaration (it's a lie) or enforce it. Mixed mode is the worst option.

**Recommended fix.** Enforce strict mode on tools that declare it. Reject extra fields with a Zod-style error. Better yet: enforce on ALL tools as a default — agents that submit extra fields are usually malfunctioning.

### F79 [MEDIUM] [open] — `comms_send_message` error envelope differs from other tool errors

**Observed.** Send_message failure (no SMS-capable phone):

```json
{
  "error": "SMS is not available for this client — no SMS-capable phone number found in the number pool.",
  "suggestion": "No alternative channels are available for this client.",
  "availableChannels": []
}
```

Other tool errors are typically just `{"error": "..."}`.

**Why it matters.** `suggestion` and `availableChannels` are **good** additions for agentic consumers (an agent learns what alternatives to try). But:
- Still no `code` field.
- Per-tool ad-hoc envelope shapes mean every agent has to handle each tool's shape separately.

**Recommended fix.** Standardize:

```json
{
  "error": {
    "code": "CHANNEL_UNAVAILABLE",
    "message": "SMS is not available for this client...",
    "suggestion": "No alternative channels are available for this client.",
    "availableChannels": [],
    "retryable": false
  }
}
```

Promote the `suggestion` and `availableChannels` fields up to the standard envelope as optional metadata fields. Other tools that have similar info can populate them too.

### F80 [MEDIUM] [open] — Timestamp format inconsistency between REST and MCP for the same field

**Observed.**

```
REST:  GET /api/v1/agents/me  → "provisioned_at": "2026-04-28T14:38:49Z"     (ISO 8601 ✓)
MCP:   comms_get_channel_status (round 2) → "provisionedAt": "2026-04-28 14:38:49"  (non-ISO ✗)
```

Same field, same record, two different formats depending on which surface you ask.

**Why it matters.** Agents that hit both surfaces (REST for admin, MCP for runtime) have to reason about which surface returned which format. Date-parsing logic that works on one surface fails on the other.

**Recommended fix.** Single canonical formatter for timestamps, applied at the response-serialization layer. Always ISO 8601 / RFC 3339 with `Z` suffix.

---

## C. Documentation drift

### F81 [LOW] [open] — `/docs` claims "10 WhatsApp actions"; schema enum has 13

**Observed.** `/docs/home` page lists:

> WhatsApp Rich Actions — 10 actions: location, contact, typing, read receipts, reactions, edit, delete, forward, polls, buttons

But `comms_whatsapp_action.action` enum (verified in round 2) has 13 entries:
`send_location, send_contact, typing, mark_read, react, edit, delete, forward, send_poll, send_buttons, post_status, set_chat_ttl, send_view_once`.

Missing from the docs page: `post_status`, `set_chat_ttl`, `send_view_once`.

**Why it matters.** Doc-vs-schema drift is a chronic problem. An agent reading the docs page first decides "I have 10 capabilities" and never tries `set_chat_ttl` or `send_view_once`. Fix once; drift again.

**Recommended fix.** Generate doc pages from the live schema. If `/openapi.json` (F20) and per-tool MCP schemas can be the source of truth, the doc page is just a renderer.

### F82 [LOW] — BD source repo at `https://github.com/elrad/butt-dial-mcp.git`

**Observed.** `/docs/home` quick-start: `git clone https://github.com/elrad/butt-dial-mcp.git`.

**Why it matters.** Just an observation — the BD server is open-source on `elrad`'s personal GitHub account. Not a finding per se, but might be relevant to the SDK ↔ server relationship (both repos under the same owner now: `elradts/butt-dial-sdk` + `elrad/butt-dial-mcp`).

### F83 [LOW] [open] — Malformed JSON error message lacks `code`

**Observed.**

```bash
POST /api/orgs/register, body: 'not valid json {'
→ 400 {"error":"Invalid JSON in request body. Check for missing commas or brackets."}
```

Friendly message, no `code` field.

**Recommended fix.** Add `"code": "INVALID_JSON"`. Hardens F07.

---

## D. Positive findings (round 3)

### POS1 — 404-route error envelope is the best on the server

```json
{
  "error": "not_found",
  "message": "No endpoint matches GET /api/v1/agents. Check the API docs or your client version.",
  "path": "/api/v1/agents",
  "method": "GET",
  "docs": "https://call.95percent.ai/docs"
}
```

This has everything you'd want for agent debugging: stable string code (`"not_found"`), human message with helpful prompt ("check your client version"), structured `path`/`method` for log correlation, **link to docs**. Use this as the template for F08 and propagate.

### POS2 — `MISSING_FIELDS` envelope already exists on register-without-content-type path

```bash
POST /api/orgs/register (no Content-Type, valid JSON body)
→ {"error":"...","code":"MISSING_FIELDS","fields":["orgName","ownerEmail"],"retryable":false}
```

The structured envelope with `code`, `fields`, and `retryable` is **already implemented** somewhere in the request pipeline. The pattern is in three places now: auth middleware (round 2), 404 router (POS1), and this no-content-type path. The gap is the validation-after-parse path. Extract a shared error helper and propagate.

### POS3 — `/docs` is a real documentation site

Not just a placeholder. Sections include:
- Getting Started (Home, Features, Getting Started, Registration)
- Reference (MCP Tools, API Reference, Providers)
- Guides (Integration, Channel Setup, Voice Calls, Architecture, Security, Monitoring)
- Help (Troubleshooting)

Most concerns about discoverability (F19/F20) become "machine-readable schema is missing" rather than "no docs at all."

### POS4 — Malformed JSON returns helpful prose

`"Invalid JSON in request body. Check for missing commas or brackets."` — friendlier than most 400s. Just needs `code: "INVALID_JSON"` (F83) for machine consumption.

### POS5 — Security headers consistent across every response

Every response carries: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `X-XSS-Protection: 1; mode=block`, `Referrer-Policy: strict-origin-when-cross-origin`, `Strict-Transport-Security: max-age=31536000; includeSubDomains`, `Content-Security-Policy: default-src 'none'`. Strong baseline.

### POS6 — `comms_send_message` exposes useful metadata in errors

The `suggestion` and `availableChannels` fields on the channel-unavailable error are exactly what agents need to recover. Generalize the pattern (F79) and the error envelope becomes valuable signal, not just failure noise.

---

## E. Cleanup requests (cumulative)

| What | Why |
|---|---|
| Delete orphan org `646bbace-0a01-45d6-b571-137b54413a66` | Round-1 probe artifact, fake email |
| Delete orphan org `b5d31db6-394c-41bc-8d2a-972f7d152264` | Round-1 probe artifact, expired token |
| Keep org `28bf35dd-995f-46ac-96da-1f99ac9d9b52` and agent `d51b0eb9-...` for verifying fixes | Active probing target |
| Note: agent token rotated to `6ce1d93e...` during round 3 (F70 incident) | Old token `1cc057aa...` is revoked |

---

## F. What we'd like to verify next

Held off on these. Each requires explicit go-ahead before mutation.

1. **`POST /api/v1/provision` with `{phone: true}`** — actually allocates a number. Confirms response shape, channel-allocation contract. Likely incurs cost.
2. **`comms_send_message` real send** — picks a friendly recipient (e.g. user's phone or a Twilio test number) and confirms idempotency-key replay semantics.
3. **`POST /api/orgs/me/phone/set` + `confirm`** — full OTP round-trip. Confirms `OTP_INVALID`, `OTP_EXPIRED`, `OTP_MAX_ATTEMPTS` codes from the SDK's typed-error table. Sends a real SMS.
4. **`comms_create_session` with participants array** — exercise the session lifecycle (sessions are sandboxed; likely safe).
5. **`comms_subscribe_inbound` with `{operation: "status"}`** — inspect inbound subscription state without modifying it.

---

## Appendix — round 3 reproducers

```bash
# F70 — accidental rotation (DO NOT REPRODUCE on a token you care about)
# (This is the call that did it. Use a throwaway agent token.)
# python -c "
# import asyncio; from mcp import ClientSession; from mcp.client.sse import sse_client
# async def main():
#     async with sse_client('https://call.95percent.ai/sse', headers={'Authorization': 'Bearer <THROWAWAY>'}) as (r,w):
#         async with ClientSession(r,w) as s:
#             await s.initialize()
#             res = await s.call_tool('comms_rotate_token', arguments={})
#             print(res)
# asyncio.run(main())
# "

# F71 — no CORS headers
curl -sS -i -X OPTIONS https://call.95percent.ai/api/orgs/register \
  -H "Origin: https://example.com" -H "Access-Control-Request-Method: POST"
# 204 No Content — but no Access-Control-Allow-* headers

# F72 — HEAD returns 404
curl -sS -I https://call.95percent.ai/api/orgs/register
# HTTP/1.1 404 Not Found

# F73 — PUT returns 404 instead of 405
curl -sS -X PUT https://call.95percent.ai/api/orgs/me \
  -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{}'
# 404 (should be 405)

# F74 — Mock Carrier in production
# (via probe_round3.py)
# comms_validate_number({"phoneNumber": "+15555550123"})
# → carrier: {name: "Mock Carrier", type: "mobile"}

# F77 — find_agent excludes provisioned agent
# comms_find_agent({}) returns 1 system agent; our d51b0eb9-... is missing

# F78 — additionalProperties: false not enforced
# comms_ping({"unknownField": "x"}) → succeeds despite schema strictness

# POS1 — best-on-server 404 envelope
curl -sS https://call.95percent.ai/api/v1/agents \
  -H "Authorization: Bearer $TOK"
# {"error":"not_found","message":"...","path":"...","method":"GET","docs":"..."}

# POS2 — MISSING_FIELDS envelope from no-content-type path
curl -sS -X POST https://call.95percent.ai/api/orgs/register \
  --data-binary '{"orgName":"x","ownerEmail":"x@example.com"}'
# Note: NO -H Content-Type header
# {"error":"...","code":"MISSING_FIELDS","fields":[...],"retryable":false}
```

---

*This document is the third in a series. Read with `BD_SERVER_FEEDBACK.md` and `BD_SERVER_FEEDBACK_2.md`. Status updates flow forward — most-recent file has latest status.*
