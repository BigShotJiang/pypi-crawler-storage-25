<!-- version: 1.0 | updated: 2026-04-28 -->

# Butt-Dial Server — API & Contract Review (Round 4)

**To:** Butt-Dial server team
**From:** SDK side review (continued)
**Date generated:** 2026-04-28
**SDK version:** 0.3.0
**Server probed:** `https://call.95percent.ai`
**Server build:** commit `83b1099`, build time `2026-04-28T17:18:39.425Z`, apiVersion `1.0`

## What this document is

A **verification round** — not net-new findings. The SDK side re-probed 32 specific findings from rounds 1–3 to confirm whether the server-side fixes shipped match the SDK's expectations. Three new findings (F80–F82) appended.

**Net result:** out of 32 findings tested, **25 are FIXED, 4 are PARTIAL, 3 remain OPEN**. The server team has shipped a meaningful slice of work — multiple critical findings (F01, F02, F03, F22) and most of the high/medium contract items are now closed.

---

## A. Status table

| ID | Status | Where verified |
|----|--------|----------------|
| **F01** | ✅ **FIXED** | `register` with same email → returns existing orgId |
| **F02** | ✅ **FIXED** | rate limit active; 429 with `{code:"RATE_LIMITED", retryAfter, retryable, scope:"per_ip"}` |
| **F03** | ✅ **FIXED** | new `/verify` page reads token from URL fragment + `history.replaceState`; legacy `/api/orgs/verify?token=...` carries `Deprecation:` + `Sunset:` headers |
| **F04** | ⚠️ PARTIAL | response shape identical for new vs existing emails, but the deterministic `orgId` value still leaks existence (call twice with same email → same orgId twice) |
| **F09** | ✅ **FIXED** | new verify page has code-specific error messaging (`VERIFICATION_TOKEN_EXPIRED` → "Request a fresh one"; `VERIFICATION_TOKEN_INVALID` → "Try registering again"); "Back to sign in" button on error path |
| **F11** | ❌ OPEN | still 4+ names: email/UI says "API key"/"owner API key"; `/docs/registration` says "team token"; `/docs/mcp-tools` says "client token"; verify response emits all of `teamToken`/`team_token`/`ownerToken`/`owner_token` |
| **F12** | ❌ OPEN | hedge is *spreading*: round-3 introduced `retryAfter`+`retry_after` on rate limits; round-4 agent record adds `agentId`+`agent_id`, `displayName`+`display_name`, `callbackUrl`+`callback_url` |
| **F14** | ✅ **FIXED** | round-1 orphan `646bbace-…` is gone; old fake email `sdkprobe-DO-NOT-CREATE@example.invalid` now returns a new orgId |
| **F17** | ✅ **FIXED** | `GET /api/orgs/{id}/verification-status` returns `{orgId, state, expiresAt}` (caveat: works without auth — see [F80](#f80)) |
| **F18** | ✅ **FIXED** | `POST /api/orgs/{id}/resend-verification` exists with `per_min` rate limit (`{code:"RATE_LIMITED", retryAfter:4, scope:"per_min"}`) |
| **F19** | ✅ **FIXED+** | `/healthz` (basic), `/health` (alias), `/health/ready` (deep readiness probe with provider state), `/metrics` (Prometheus format), `/version` (apiVersion + commit + buildTime) — exceeds the original ask |
| **F22** | ✅ **FIXED** | SSE handshake unauth → **401** (was 200). Authenticated handshake also sends a capabilities welcome message — bonus agent ergonomics |
| **F25** | ✅ **FIXED** | `Idempotency-Key` on `POST /api/v1/agents` returns identical response on retry (same `agent_id` AND same `token`) |
| **F37** | ✅ **FIXED** | ISO 8601 (`2026-04-28T13:24:07Z`) on REST. Note: MCP layer hasn't been migrated — see [F80](#f80) |
| **F38** | ✅ **FIXED** | example phone in `phone/set` validation error is now `+15555550123` (NANP non-routable test range); no more `+972526557547` PII |
| **F41** | ✅ **FIXED** | server returns `{error:"...", code:"AUTH_WRONG_SCOPE", retryable:false}` with clear remediation: *"Use it to call /api/v1/agents/:id directly, or POST /api/v1/agents to register an agent first."* No more orgId echoed where agent_id should be (F28 also closed) |
| **F43** | ⚠️ PARTIAL | server hedges by emitting BOTH casings on agent records (`agentId`+`agent_id`, etc.) — adjacent to F12. Not unified, just doubled |
| **F44** | ✅ **FIXED** | `provisioned_at` is now `null` until channels are actually provisioned; new `createdAt` field carries the agent creation timestamp. Field name now matches reality |
| **F45** | ✅ **FIXED** | `/api/v1/usage` includes top-level `currency: "USD"` |
| **F46** | ✅ **FIXED** | `period: {name:"today", start:"2026-04-28T00:00:00.000Z", end:"2026-04-29T00:00:00.000Z", timezone:"UTC"}` — fully structured |
| **F47** | ✅ **FIXED** | `actions` and `costsByChannel` now ship with all known keys populated (zeros for unused channels: `sms, whatsapp, email, voice, telegram, line`) |
| **F48** | ✅ **FIXED (docs)** | limits documented in `/docs/security`. ⚠️ See [F81](#f81) — docs value (`2`) drifts from live API (`10`) |
| **F49** | ✅ **FIXED** | bogus token across `/api/orgs/me` AND `/api/v1/agents/me` now consistently returns `AUTH_INVALID_TOKEN` (was `AUTH_TOKEN_REVOKED` vs `AUTH_INVALID_TOKEN`) |
| **F50** | ✅ **FIXED** | structured envelope `{error, code, retryable, [fields], [retryAfter]}` verified on register, verify, agents POST, provision POST — all consistent |
| **F51** | ✅ **FIXED** | `comms_ping` no longer leaks `providers` or `pool`. Response now: `{status, server, version, echo}` only |
| **F53** | ✅ **FIXED** | `maxAgents` documented in `/docs/mcp-tools` under `comms_expand_client_pool` |
| **F56** | ⚠️ PARTIAL | REST hedges both casings; MCP layer stays camel-only. Same data exposed via two surfaces with different conventions still |
| **F60** | ✅ **FIXED** | `Idempotency-Key` honored on `/api/orgs/register` AND `/api/v1/agents`. Other mutating endpoints unverified |
| **F62** | ✅ **FIXED** | `pool` block removed from both `comms_ping` and `comms_get_channel_status` |
| **F63** | ⚠️ PARTIAL | `comms_register_provider` description now starts with `[scope: admin]` — convention is emerging. Recommend auditing all 47 tools to apply consistently |
| **F65** | ✅ **FIXED** | `comms_get_income` now includes `currency: "USD"` and structured `byChannel: {sms: {providerCost, billedCost, income, count}, ...}` |
| **F69** | ✅ **FIXED** | `.env file` mention removed; new description: *"Register third-party provider credentials. Credentials are stored encrypted at rest, scoped to the calling org."* |

---

## B. Tally

```
✅ FIXED:    25 / 32  (78%)
⚠️ PARTIAL:   4 / 32  (12%)
❌ OPEN:      3 / 32  (10%)
```

**Critical findings (round 1) closed:** F01, F02, F03, F22 — 4 of 5 critical items. **F25 (idempotency)** also closed.

**Open clusters:**

1. **Naming and casing** (F11, F12, F43, F56) — the server is shipping camelCase consistently for new fields, hedging old fields (emitting both forms), but hasn't started removing snake_case duplicates. The migration path is half-done.
2. **Email-existence oracle** (F04) — fixing this requires randomizing the orgId returned to register-with-existing-email, OR not returning orgId at all from register (per round-1 recommendation).
3. **MCP scope documentation** (F63) — pattern is established (`[scope: admin]` prefix), needs to be applied across the remaining ~46 tools.

---

## C. New round-4 findings

### F80 — `/api/orgs/{id}/verification-status` is unauthenticated

**Observed.** The new verification-status endpoint (F17 fix) returns 200 without an `Authorization` header:

```bash
$ curl -i https://call.95percent.ai/api/orgs/<orgId>/verification-status
HTTP/1.1 200 OK
{"orgId":"<orgId>","state":"verified","expiresAt":null}
```

**Why it matters.** Anyone who knows or guesses an orgId can probe verification status. Combined with F04 (deterministic orgId on register), an attacker can:
1. Register with a target email → get orgId
2. Poll verification-status → see when human clicks (state goes `pending` → `verified`)

This is a side-channel attack on user behavior.

**Recommended fix.** Either:
- Require auth on the endpoint (the verification flow already has the token; pass it as `?probe-token=` or use a separate verification probe token), OR
- Make the endpoint responses constant-time and the data never enumerable (return a generic "verification flow exists" without state distinction)

The host's email-link click handler may not have the team_token when calling this — but it does have the verification token. Accept that as auth.

### F81 — Docs vs API drift on `maxCallsPerDaySameNumber`

**Observed.**

| Source | Value |
|---|---|
| `/docs/security` | `2 calls/day to same number` |
| `/api/v1/usage` (live) | `"maxCallsPerDaySameNumber": 10` |

**Why it matters.** Customers reading the docs will plan against `2` and be surprised by `10` (or vice versa if the docs are right and the API is the bug). Either way, a host or agent that wants to enforce client-side awareness of the cap can't trust either source.

**Recommended fix.** Pick the right value, sync docs and live config. Run a one-off sync check between `/docs/*` content and the constants in `/api/v1/usage`'s `limits` block — likely worth a CI gate so docs can't drift again.

### F82 — `/health/ready` returns string-encoded count for `channelHealth`

**Observed.**

```json
{
  "status": "degraded",
  "providers": {
    "database": "ok",
    "telephony": "configured",
    "email": "configured",
    "whatsapp": "configured",
    "line": "not_configured",
    "channelHealth": "6 channel(s) down"
  }
}
```

**Why it matters.** `"channelHealth": "6 channel(s) down"` is a number wrapped in English. Monitoring agents (`prometheus_alertmanager`, `datadog`, etc.) and operations dashboards expect numeric counts. To extract `6`, callers have to regex-parse the string. Brittle.

**Recommended fix.**

```json
"channelHealth": {"down": 6, "total": 7}
```

…or split into separate fields:

```json
"channelsDown": 6,
"channelsTotal": 7
```

Bonus: alongside `database/telephony/email/whatsapp/line` per-provider statuses, return a `channels[]` array with each channel's identity and last-seen state, so callers can drill into which 6 are down.

---

## D. Bonus observations

Things the server team is doing well, not in any prior list:

1. **Capabilities welcome message on SSE connect.** When the agent_token authenticates and opens SSE, the server sends a notifications/message event with a structured tool inventory and behavioral guidance:
   ```
   "You are connected to Butt-Dial, a communication server. Here is what you can do:
    MESSAGING (comms_send_message): ... WHATSAPP ACTIONS (comms_whatsapp_action): ... VOICE: ..."
   ```
   This is **excellent** for LLM-driven agents — it's the equivalent of a system prompt that orients the agent on first connect. Class-A move.

2. **`/metrics` is real Prometheus.** Currently lean (`mcp_alerts_total{severity="HIGH"} 8`, `mcp_uptime_seconds`), but the surface is correct content-type (`text/plain; version=0.0.4`) and parseable by stock Prometheus scrapers.

3. **Lockout protection is working.** During this round, my IP got locked out after ~10 bad-token probes — exactly what the docs claim ("10 failed auth attempts → 15-minute IP lockout"). All locked responses carry `code:"AUTH_LOCKED_OUT"`, `retryAfterSeconds`, `lockedUntil` ISO timestamp. Recovery is automatic; no support ticket needed.

4. **Deprecation contract works in practice.** Round 3 verified F33; round 4 confirms the legacy `GET /api/orgs/verify?token=...` *still works* (with deprecation headers) while the new `/verify` route is preferred. Real backward-compat instead of breaking changes.

5. **F47 fix is rich.** The `actions` object now lists all known channels with zero-counts when unused, plus one I haven't seen before: `telegram`. Suggests Telegram is on the roadmap; the channel keys are pre-allocated.

---

## E. Cleanup requests (carryover + new)

| What | Status |
|---|---|
| Delete orphan `b5d31db6-394c-41bc-8d2a-972f7d152264` (round 1) | open |
| Delete or keep agent `d51b0eb9-…` (round 2 probe artifact) | your call |
| **NEW:** delete throwaway orgs from this round | F04 oracle test created `e2dcca40-…` and `5566809e-…` (sdkprobe email); F25 idempotency test created agent `da7f75c5-…` |
| Optional: rotate team_token on `28bf35dd-…` after this review | open |
| Note: `646bbace-…` (round-1 orphan) confirmed deleted by F14 verification ✓ | done |

---

## F. What's still worth verifying

1. **F11 / F12 final shape.** Once the server team picks canonical names and removes the snake_case hedges, re-probe to confirm.
2. **F60 completeness audit.** `/api/v1/provision`, `/api/orgs/me/phone/set`, `/api/orgs/me/rotate-token/request` — does Idempotency-Key work on each?
3. **F63 audit of remaining ~46 tools.** Apply `[scope: ...]` prefix consistently.
4. **F03 end-to-end.** Trigger a real verification email in 2026 and click via the new `/verify#token=...` flow to confirm prefetcher resistance in the real world.
5. **F77** — register with verified email → does the server return `code:"EMAIL_ALREADY_REGISTERED"` (vs. silently resending verification)?
6. **OTP round-trip** — `phone/set` → confirm flow → verify SDK's `OTP_INVALID` / `OTP_EXPIRED` / `OTP_MAX_ATTEMPTS` / `CHALLENGE_NOT_FOUND` codes are emitted as expected.
7. **F22 + capabilities welcome message** — verify the welcome event is documented somewhere and stable.

---

## Appendix — round 4 reproducers

```bash
# F01 dedup
curl -sS -X POST .../api/orgs/register -H 'Content-Type: application/json' \
  -d '{"orgName":"x","ownerEmail":"<existing-email>"}'
# → returns existing orgId

# F02 rate limit
for i in 1 2 3 4 5; do
  curl -sS -X POST .../api/orgs/register -d '{"orgName":"x","ownerEmail":"u-'$i'@example.invalid"}'
done
# → 429s with {code:RATE_LIMITED, retryAfter, scope:per_ip}

# F03 + F09 verify page
curl -sS https://call.95percent.ai/verify
# Inspect the JS — token comes from location.hash, never from server query

# F17 verification-status
curl -sS https://call.95percent.ai/api/orgs/<orgId>/verification-status
# → {orgId, state:"verified"|"pending"|..., expiresAt}

# F18 resend-verification
curl -sS -X POST https://call.95percent.ai/api/orgs/<orgId>/resend-verification
# → 429 with code:RATE_LIMITED scope:per_min if too soon

# F19 health/version/metrics
curl -sS https://call.95percent.ai/healthz
curl -sS https://call.95percent.ai/health/ready
curl -sS https://call.95percent.ai/version
curl -sS https://call.95percent.ai/metrics

# F22 SSE unauth
curl -i --max-time 3 https://call.95percent.ai/sse
# → 401 (was 200 in rounds 1-3)

# F25 / F60 idempotency
KEY="my-attempt-$(date +%s)"
curl -X POST .../api/v1/agents -H "Idempotency-Key: $KEY" -H "Authorization: Bearer $TEAM" \
  -d '{"agent_id":"<uuid>","display_name":"x"}'
# call twice; responses are byte-identical (same agent_id AND same token)

# F38 PII
curl -X POST .../api/orgs/me/phone/set -H "Authorization: Bearer $TEAM" \
  -d '{"phone":"not-e164"}'
# → "phone must be E.164 format (e.g. +15555550123)" — no more +972...

# F41 wrong scope
curl .../api/v1/agents/me -H "Authorization: Bearer $TEAM"
# → 401 {code:AUTH_WRONG_SCOPE, ...} with helpful remediation

# F45 / F46 / F47 usage
curl .../api/v1/usage -H "Authorization: Bearer $AGENT" | python -m json.tool
# → currency:"USD"; period as object; actions/costsByChannel populated

# F49 bogus token consistency
curl .../api/orgs/me      -H "Authorization: Bearer bogus" | head -c 200
curl .../api/v1/agents/me -H "Authorization: Bearer bogus" | head -c 200
# both → code:AUTH_INVALID_TOKEN

# F50 envelope
curl -X POST .../api/v1/provision -H "Authorization: Bearer $TEAM" -d '{}'
# → {code:MISSING_FIELDS, fields:[...], retryable:false}

# F51 / F62 ping clean
BD_AGENT_TOKEN=<...> python scripts/probe_ping.py
# → no providers, no pool

# F63 scope prefix
BD_AGENT_TOKEN=<...> python scripts/probe_tools.py | grep -A 1 "comms_register_provider"
# → "[scope: admin] Register third-party provider credentials..."

# F80 unauth verification-status
curl https://call.95percent.ai/api/orgs/<orgId>/verification-status
# → 200 (no auth required)
```

---

*Cumulative findings: F01–F82. Status of every finding tracked across `BD_SERVER_FEEDBACK.md` (round 1), `BD_SERVER_FEEDBACK_2.md` (round 2), `BD_SERVER_FEEDBACK_3.md` (round 3), and this file.*
