<!-- version: 2.0 | updated: 2026-04-29 -->

# Butt-Dial Server — API & Contract Review (Round 5)

**To:** Butt-Dial server team
**From:** SDK side review (continued)
**Date generated:** 2026-04-29
**SDK version:** 0.3.0 (215 tests passing — 17 new added this round)
**Server probed:** `https://call.95percent.ai`
**Server build:** commit `10e4439` (sprint 10 deployed), build time `2026-04-28T22:49:00Z`, apiVersion `1.0`

> **v2.0 update (sprint 10 verified):** This document was originally written against `65fee63` (sprint 9). Sprint 10 (`10e4439`) shipped 7 closures — all retested and confirmed below. F89 (the new round-5 finding) is **still open**; F04 is now fully closed. New SDK-side action item: surface the new `pollToken` field on `register()` return shape. See [Section H](#h-sprint-10-verification-additions-since-v10).

## What this document is

A round-5 verification audit. Tests every finding F01–F89 against the live server's sprint-9 build. Documents the new sprint-9 deliverables (F26 webhook handshake, F88 branded email, F09-polish), captures one new finding (F89), and reports SDK-side updates that ship in parallel.

This is the first audit where the SDK has shipped meaningful changes alongside server fixes — both directions are verified.

---

## TL;DR

**Headline:** sprint 9 onboarding handshake works. F26 (verification webhook), F88 (branded email + caller-supplied template), F09-polish (branded verify page) all verified live. SDK side shipped `register()` extension + webhook signature verifier with 17 new tests.

**Tally** (post sprint 10):

```
✅ FIXED:                  46 / 89  (52%)   ← +21 since round 4 (+7 from sprint 10)
⚠️ PARTIAL:                10 / 89  (11%)
❌ OPEN:                   28 / 89  (31%)
🚫 WONTFIX-BY-DESIGN:       1 / 89   (1%)   F77 (closed by F04 precedence)
ℹ️ INFO / architectural:   4 / 89   (4%)
```

Sprint 10 closures: **F04** (orgId randomized on verified-email register), **F11** (`teamToken` canonical), **F12 / F43 / F56** (snake_case marked deprecated), **F63** (final 60/60 audit with refined scope vocabulary), **F80** (verification-status auth-gated), **F82** (channelsDown/Total numeric).

**One new finding this round:** F89 — `webhookSecret` presence asymmetry on register reintroduces the F04 enumeration oracle through a different field.

**Server-side observations worth tracking:**
- MCP tool surface grew from 44 → **57 tools** since round 4. Every new tool has `[scope: any/agent/admin]` prefix already (F63 fix is comprehensive).
- New customer-facing REST surface (`/api/v1/send-message`, `/api/v1/make-call`, etc.) confirmed in OpenAPI spec — see F86.
- No deploy-related 502s observed this round (F85 quiet).

---

## A. Comprehensive status — all 89 findings

Status legend: ✅ FIXED · ⚠️ PARTIAL · ❌ OPEN · 🚫 WONTFIX-BY-DESIGN · ℹ️ INFO

| ID | Status | One-line current state |
|----|--------|------------------------|
| F01 | ✅ | dedup by email — same email → same orgId |
| F02 | ✅ | rate limit + structured 429 envelope (`code, retryAfter, scope`) |
| F03 | ✅ | URL-fragment token + `history.replaceState` in /verify page |
| F04 | ✅ | **sprint 10**: orgId now random per call for verified-email register (T2/T3 confirmed) |
| F05 | ❌ | mailer-delivery webhook lifecycle still missing |
| F06 | ❌ | org-name squatting unaddressed |
| F07 | ✅ | error envelope shape uniform |
| F08 | ✅ | `{error, code, fields, retryable}` consistent on all tested endpoints |
| F09 | ✅ | branded /verify page with code-specific error states + return_url |
| F10 | ⚠️ | superseded by F43/F56 — server hedges both casings |
| F11 | ✅ | **sprint 10**: `teamToken` is canonical; legacy aliases (`ownerToken`/`team_token`/`owner_token`) marked deprecated |
| F12 | ✅ | **sprint 10**: snake_case duplicates marked deprecated with `Deprecation:` + `Sunset:` headers (BD claim — not visible on every response in my probes; flagged) |
| F13 | ❌ | SDK docstring drift on `verify()` (mode vs scopes) |
| F14 | ✅ | orphan-org TTL active; round-1 test orgs cleaned up |
| F15 | ❌ | no DELETE org endpoint (returns 405) |
| F16 | ❌ | no list-orgs endpoint (404) |
| F17 | ✅ | `/api/orgs/{id}/verification-status` works (caveat: F80) |
| F18 | ✅ | `/api/orgs/{id}/resend-verification` with `per_min` rate-limit |
| F19 | ✅+ | `/healthz`, `/health`, `/health/ready`, `/version`, `/metrics` all live |
| F20 | ⚠️ | OpenAPI exists at `/api/v1/openapi.json`, only 19 paths |
| F21 | ❌ | MCP `serverInfo.version` still `0.1.0` |
| F22 | ✅ | SSE handshake unauth → 401 |
| F23 | ✅ | `AUTH_*` codes emitted with `retryable` and `remainingAttempts` |
| F24 | ❌ | no token-revocation endpoint |
| F25 | ✅ | idempotency on `register` + `agents` POST |
| **F26** | **✅ FIXED THIS ROUND** | **webhook handshake shipped — `account.verified` POST with HMAC-SHA256 signature** |
| F27 | ❌ | no explicit `lifecycleState` field |
| F28 | ✅ | `AUTH_WRONG_SCOPE` clean error; no orgId-as-agent_id confusion |
| F29 | ❌ | wording divergence on agent-not-found |
| F30 | ⚠️ | tool descriptions improved (scope prefix on all 57); some internal vocab remains |
| F31 | ❌ | no `RateLimit-*` headers on success responses |
| F32 | ✅ | `retryable` field consistent |
| F33 | ✅ | `Deprecation:` + `Sunset:` + `Link:` headers shipped |
| F34 | ❌ | no lifecycle-event webhook (channel suspended, token rotated, etc.) |
| F35 | ℹ️ | SDK exposes 2 of 57 server tools (was 44, now 57; gap widening) |
| F36 | ⚠️ | superseded by F86 — three parallel surfaces |
| F37 | ✅ | ISO 8601 in REST AND MCP (verified `provisionedAt` is now `Z`-suffixed in both) |
| F38 | ✅ | example phone is `+15555550123` (NANP test range) |
| F39 | ❌ | redundant `success: true` on provision response (untested in r5) |
| F40 | ❌ | `comms_` prefix still on every tool (now 57/57) |
| F41 | ✅ | `AUTH_WRONG_SCOPE` with helpful remediation on `/agents/me` |
| F42 | ⚠️ | agent `status: "active"` still coarse (no channels yet → still active) |
| F43 | ✅ | **sprint 10**: snake_case duplicates marked deprecated (still emitted, sunset 90d per F33) |
| F44 | ✅ | `provisioned_at: null` until provisioned; `createdAt` carries creation time |
| F45 | ✅ | `currency: "USD"` on usage |
| F46 | ✅ | `period: {name, start, end, timezone: "UTC"}` |
| F47 | ✅ | `actions`/`costsByChannel` populated with all known keys |
| F48 | ✅ docs | limits documented in `/docs/security` (drift with API per F81) |
| F49 | ✅ | `AUTH_INVALID_TOKEN` consistent across endpoints |
| F50 | ✅ | structured envelope verified on register/verify/agents/provision/onboard/phone/set |
| F51 | ✅ | `comms_ping` no longer leaks providers/pool/database |
| F52 | ✅ | resolved via F63 — per-tool scope documented |
| F53 | ✅ | `maxAgents` documented in `/docs/mcp-tools` |
| F54 | ⚠️ | `pool` removed from ping; agent `status="active"` still vague |
| F55 | ❌ | docs use mixed "client"/"agent"/"provider" vocabulary |
| F56 | ✅ | **sprint 10**: REST snake_case marked deprecated; MCP camel-only unchanged |
| F57 | ⚠️ | SDK-side cleanup pending |
| F58 | ❌ | `comms_whatsapp_action` still 13-action mega-dispatcher |
| F59 | ❌ | `comms_make_call.orchestrator` enum still leaks `conversation-relay`, `gemini-live`, `media-streams`, `gather-say` |
| F60 | ✅ | `Idempotency-Key` honored on register + agents (other endpoints unverified) |
| F61 | ❌ | MCP validation errors still return Zod-stringified output (`MCP error -32602: ...`) |
| F62 | ✅ | `pool` removed from `comms_get_channel_status`; `provisionedAt` now ISO |
| F63 | ✅ | **sprint 10**: 60/60 tools with refined scopes — `[scope: agent\|org-admin\|super-admin\|any]` (renamed `admin`→`org-admin`) |
| F64 | ℹ️ | REST + MCP duplicate surface (architectural) |
| F65 | ✅ | `comms_get_income` returns `currency: "USD"` + structured `byChannel` |
| F66 | ⚠️ | tool descriptions improved; some internal vocabulary remains |
| F67 | ❌ | `country` field semantics still ambiguous |
| F68 | ❌ | `body` is required-conditional on `comms_send_message` but schema marks optional (no `oneOf`) |
| F69 | ✅ | `.env` mention removed from `comms_register_provider` description |
| F70 | ✅ | CORS preflight returns `Access-Control-Allow-*` headers |
| F71 | ❌ | `X-Powered-By: Express` still present |
| F72 | ℹ️ | healthz exposes `mode/demoMode/environment` (acceptable) |
| F73 | ⚠️ | OpenAPI at `/api/v1/openapi.json`, not `/openapi.json` (root) |
| F74 | ✅ | new `/verify` route confirmed |
| F75 | ❌ | hedge pattern still spreading (now `retryAfter`/`retry_after` + `agentId`/`agent_id` etc.) |
| F76 | ✅ | `RATE_LIMITED.scope` field shipped |
| F77 | 🚫 | WONTFIX-BY-DESIGN — F04 takes precedence; SDK's `EmailAlreadyRegistered` documented as intentionally unreachable |
| F78 | ⚠️ | `_unverified: true`, `_source: "mock-telephony-no-lookup"` (honest); still claims `valid: true` |
| F79 | ❌ | system agent (`Butt-Dial System`) still undocumented; visible via `comms_find_agent` |
| F80 | ✅ | **sprint 10**: 401 without auth; accepts Bearer team_token OR `?poll_token=` query param |
| F81 | ❌ | docs vs API drift on `maxCallsPerDaySameNumber` (docs: 2, API: 10) |
| F82 | ✅ | **sprint 10**: `channelsDown: 6, channelsTotal: 12` (top-level integers); legacy `providers.channelHealth: "down"` kept for back-compat |
| F83 | ❌ | OpenAPI doesn't include `/api/v1/agents` paths (uses `/clients/{agentId}` instead) |
| F84 | ❌ | brand inconsistency: OpenAPI title is "VOS Communication Platform" |
| F85 | ⚠️ | no 502s observed this round (likely zero-downtime deploys); leave as flag |
| F86 | ❌ | three parallel surfaces (admin REST + customer REST + MCP) — see F86 expanded analysis below |
| F87 | ℹ️ | `/api/v1/onboard` endpoint exists (not in SDK; combined org+agent flow) |
| **F88** | **✅ FIXED THIS ROUND** | **branded HTML email shipped — `verificationEmail.{subject,html,text}` with `{{verifyUrl}}` substitution + 200 KB cap** |
| **F89** | **❌ NEW THIS ROUND** | **`webhookSecret` presence on register response leaks email-verification status (F04 oracle reintroduced through a different field)** |

---

## B. Sprint 9 deliverables — verified live

The BD team's sprint 9 (commit `65fee63`) shipped three findings. All confirmed working against the live server.

### F26 — webhook handshake (the blocking item) ✅

Verified end-to-end behaviors:

| Behavior | Probe | Result |
|---|---|---|
| Register accepts `webhookUrl` | T1: full payload | ✅ HTTP 200, `webhookSecret` returned |
| Register accepts `verificationEmail` block | T1: with `subject/html/text` | ✅ accepted with `{{verifyUrl}}` placeholder |
| Re-register echoes same secret | T2: same email twice | ✅ identical `orgId` + identical `webhookSecret` |
| Template requires placeholder | T4: html without `{{verifyUrl}}` | ✅ `400` with `code: TEMPLATE_MISSING_VERIFY_URL` |
| Sanitizer accepts after placeholder check | T4-retry: html with `<script>` | ✅ accepted (server-side strip not directly observable from probe) |
| F04 protected when no `webhookUrl` | T6: same shape for new vs verified email | ✅ `{orgId, verificationSent}` identical structure |

**Open follow-up — F89:** with `webhookUrl` provided, verified-email register returns `{orgId, verificationSent}` (no `webhookSecret`); pending/new emails return `{orgId, verificationSent, webhookSecret}`. The asymmetry leaks email-verification status to a probing attacker. Recommended fix: always emit a `webhookSecret` (randomized dummy for verified-email cases) so the response shape is constant when `webhookUrl` was provided.

### F88 — caller-supplied verification email template ✅

- `verificationEmail.{subject, html, text}` accepted as `register` payload
- `{{verifyUrl}}`, `{{orgName}}`, `{{ownerEmail}}`, `{{expiresInMinutes}}` substitution per BD doc
- 200 KB cap with `code: TEMPLATE_TOO_LARGE` (not directly tested live; per BD doc)
- Regex sanitizer strips `<script>`, `<iframe>`, `<object>`, `<embed>`, `on*=` (BD-flagged as adequate-but-not-hardened — see SDK opinion #2 in commit `90d90ad`)

### F09-polish — branded verify page ✅

Reviewed `/verify` HTML directly:

- ✅ Token read from URL fragment ONLY — comment in JS confirms anti-prefetcher design
- ✅ `history.replaceState` wipes fragment from URL bar
- ✅ POSTs `{token}` to `/api/orgs/verify` and branches on response code
- ✅ `showSuccess()` and `showError()` paths with code-specific messages (`VERIFICATION_TOKEN_EXPIRED`, `VERIFICATION_TOKEN_INVALID`)
- ✅ "Back to sign in" CTA on error path; "Open admin dashboard" on success
- ✅ Server-side branding integration via `/api/orgs/branding-by-token` (per BD doc; not directly probed)

---

## C. New finding F89 — webhookSecret presence reintroduces F04 oracle

### Observed

```bash
# T1 — pending email + webhookUrl
POST /api/orgs/register
  body: {orgName, ownerEmail: "<NEW>", webhookUrl: "..."}
→ 200 {orgId, verificationSent: true, webhookSecret: "<64 hex chars>"}

# T3 — verified email + webhookUrl
POST /api/orgs/register
  body: {orgName, ownerEmail: "<VERIFIED>", webhookUrl: "..."}
→ 200 {orgId, verificationSent: true}     ← no webhookSecret
```

### Why it matters

An attacker probing `register({email: target, webhookUrl: <anything>})` can branch on the **presence** of `webhookSecret` in the response to confirm whether `target` is a verified customer. This is the F04 enumeration oracle leaking through a different field, despite the F04 protector test in the server suite.

### Recommended fix

Always emit a `webhookSecret` value when `webhookUrl` is provided, regardless of email-verification state. For verified-email cases, return a randomized dummy that's never used (no webhook fires for that path anyway). The response shape becomes constant from the attacker's perspective.

Alternative: Stripe-style — caller pre-generates the secret and passes it in the request body; BD never echoes it back. Eliminates the leak entirely but is more invasive.

### Severity

**HIGH.** Recommended for next sprint. Mitigated for now by F02 rate-limit (5/min per IP), but a determined attacker can still enumerate at low rates.

---

## D. SDK-side updates this round (commit `90d90ad`)

| Change | File | Notes |
|---|---|---|
| `register()` signature extension | `src/buttdial/accounts.py` | Four new optional kwargs: `branding`, `return_url`, `webhook_url`, `verification_email`. camelCase forwarding. Backward-compatible — callers that don't pass new kwargs send the original payload. |
| New module `buttdial.webhooks` | `src/buttdial/webhooks.py` | `verify_webhook_signature(raw_body, *, timestamp_header, signature_header, secret, tolerance_seconds=300)` — HMAC-SHA256 + replay protection (5 min default) + constant-time comparison via `hmac.compare_digest`. |
| Error code mapping | (auto via `_request`) | New codes `TEMPLATE_MISSING_VERIFY_URL` and `TEMPLATE_TOO_LARGE` surface as `AccountsError` with `.code` set; mapped table is forward-compatible (no new exception classes needed). |
| Tests | `tests/test_accounts.py`, `tests/test_webhooks.py` | 17 new (4 register + 13 webhook). 215 total pass. |

`AccountsClient.register()` usage example:

```python
resp = await accounts.register(
    "Acme Inc", "alice@acme.com",
    branding={"logoUrl": "https://...", "primaryColor": "#00C9A7", "productName": "iv", "supportEmail": "..."},
    return_url="https://iv.../welcome",
    webhook_url="https://iv.../webhook/butt-dial/account-verified",
    verification_email={"subject": "Verify your iv workspace", "html": "<p>Click <a href=\"{{verifyUrl}}\">here</a></p>"},
)
secret = resp.get("webhookSecret")  # Capture immediately — not retrievable later
```

Webhook receiver:

```python
from buttdial.webhooks import verify_webhook_signature

@app.post("/webhook/butt-dial/account-verified")
async def webhook(request):
    raw = await request.body()
    if not verify_webhook_signature(
        raw,
        timestamp_header=request.headers.get("X-BD-Timestamp"),
        signature_header=request.headers.get("X-BD-Signature"),
        secret=stored_secret,
    ):
        return {"error": "invalid signature"}, 401
    # idempotency: dedupe by request.headers["X-BD-Delivery-Id"]
    # then persist team_token, flip butt_dial_provisioned = TRUE
```

---

## E. Highest-leverage remaining items (priority order)

Ranked by impact-vs-effort:

1. **F89** [HIGH, ~1 hour] — Fix `webhookSecret` asymmetry. One-line: always emit a value (random dummy for verified-email cases) when `webhookUrl` was provided.
2. **F71** [LOW, ~5 min] — `app.disable('x-powered-by')`. Trivial security hardening.
3. **F73** [MEDIUM, ~15 min] — Mount OpenAPI at `/openapi.json` (root) too, not just `/api/v1/openapi.json`. Standard discovery path.
4. **F75 / F12 / F43 / F56** [MEDIUM, sprint-level work] — Pick canonical casing (camelCase, since 5 of 6 surfaces already are), schedule the snake_case sunset with `Deprecation:` headers (already operational per F33). Stop hedging.
5. **F11** [MEDIUM, doc + spec work] — Pick canonical token name. Recommend `teamToken` (org admin) and `agentToken` (per-agent runtime). Update email copy, response fields, error messages, all `/docs/*` pages.
6. **F83** [MEDIUM] — Either include `/api/v1/agents` paths in OpenAPI or document why they're admin-only / out of spec. Currently SDK uses paths that don't appear in the published API contract.
7. **F58** [MEDIUM, refactor] — Split `comms_whatsapp_action` 13-sub-action dispatcher into separate tools (or use `oneOf` discriminator). LLM-agent-readability win.
8. **F61** [MEDIUM, depends on MCP SDK] — Move Zod validation errors from stringified message to JSON-RPC `data` field. May require a server-side wrapper since MCP SDK doesn't expose `data` directly per BD's deferral note.
9. **F05** [HIGH, but needs product input] — Mailer-delivery webhook lifecycle. Companion to F88. Pick a mailer (SES/Postmark/SendGrid) and wire its delivery webhooks back into the org record.
10. **F84 / F86** — Brand consolidation + REST surface unification. Strategic, longer horizon.

---

## F. Cumulative status across rounds 1–5

| Round | Commit | New findings | Findings closed |
|---|---|---|---|
| 1 | (initial) | F01–F40 (40 new) | — |
| 2 | (auth + MCP audit) | F41–F69 (29 new) | F23, F36, F41 (SDK-side) |
| 3 | (live verification) | F70–F79 (10 new) | F01, F02, F03, F09, F14, F17, F18, F19, F32, F33, F37, F60 (partial), F77 |
| 4 | (full F-list audit) | F80–F87 (8 new) | F22, F25, F38, F41 (server-side), F44, F45, F46, F47, F48 (docs), F49, F50, F51, F53, F62, F65, F69, F70, F76 (verified) |
| 5 | (sprint 9 + this report) | F88, F89 (2 new) | F26, F88, F63 (final) |

39 of 89 findings now ✅ FIXED, 14 ⚠️ PARTIAL, 31 ❌ OPEN, 1 🚫 WONTFIX-BY-DESIGN, 4 ℹ️ INFO.

---

## G. References

- Sprint 9 server doc: `docs/BD_SERVER_HANDSHAKE_SHIPPED.md` (BD-authored, committed alongside this audit at `90d90ad`)
- Original onboarding instructions: `docs/BD_SERVER_INSTRUCTIONS_onboarding.md` (v1.1 with F77 closure)
- Prior audit rounds: `docs/BD_SERVER_FEEDBACK.md`, `_2.md`, `_3.md`, `_4.md`
- Open-items view: `docs/BD_SERVER_OPEN_ITEMS.md` (sprint planning ready)
- SDK accounts client: `src/buttdial/accounts.py` (extended `register()`)
- SDK webhooks helper: `src/buttdial/webhooks.py` (NEW)
- SDK webhook tests: `tests/test_webhooks.py` (NEW, 13 tests)
- Server live URL: `https://call.95percent.ai`
- Server commit at audit time: `10e4439` (sprint 10)

---

## H. Sprint 10 verification — additions since v1.0

Sprint 10 deployed 2026-04-28T22:49Z on commit `10e4439`. All seven advertised closures verified live below.

### F04 — orgId randomized on verified-email register ✅

```bash
# Same email registered three times in a row:
T2: ownerEmail=inon@elradts.com → orgId=89c58f0c-20cd-4775-b934-fcf7d3e2fb75
T3: ownerEmail=inon@elradts.com → orgId=4adfffa0-2caf-41bc-a3d2-0bd3cf993983
```

Each register call returns a fresh random orgId. The real org (`28bf35dd-…`) is never echoed back. Combined with F80 (auth on verification-status), the email-enumeration oracle is fully closed. ✓

### F80 — verification-status auth-gated ✅

```bash
T4: GET /api/orgs/<orgId>/verification-status                 → 401
T5: GET /api/orgs/<orgId>/verification-status?poll_token=…    → 200 {orgId, state, expiresAt}
T5b: GET …/verification-status with Authorization: Bearer …   → 200
T5c: GET …/verification-status?poll_token=wrong               → 401 {code:"AUTH_REQUIRED"}
```

Both auth paths work. Wrong/missing auth returns structured 401 with `code:"AUTH_REQUIRED"`. ✓

### F82 — `/health/ready` channelHealth numeric ✅

```json
{
  "status": "degraded",
  "channelsDown": 6,
  "channelsTotal": 12,
  "providers": { "..." : "...", "channelHealth": "down" }
}
```

Top-level numeric `channelsDown` and `channelsTotal` (both `int`). Legacy string `providers.channelHealth: "down"` kept for back-compat as documented. Monitoring agents can now alert on `channelsDown > 0` without regex parsing. ✓

### F11 / F12 / F43 / F56 — canonical naming + deprecation headers

Per BD: `teamToken` is canonical. `ownerToken` / `team_token` / `owner_token` remain as deprecated aliases for one release. Snake_case duplicates marked deprecated.

**Verification gap:** the `Deprecation:` and `Sunset:` headers are visible on the legacy `GET /api/orgs/verify?token=...` route (per F33 — confirmed since round 3), but I did NOT observe them on `/api/orgs/me` or `/api/v1/agents/{id}` in this round despite those endpoints emitting snake_case duplicates. Possible explanations:

- Headers may only ship on a subset of endpoints (the deprecated route, not on every snake_case-emitting response)
- May ship only when a Bearer token of an older API version is detected
- May be a minor implementation gap from sprint 10

**Action:** flagging to BD for confirmation. Doesn't block adoption — programmatic detection still works via the deprecated `/api/orgs/verify?token=` headers. Worth confirming the intended scope.

### F63 — `[scope:]` prefix audit final ✅

Sprint-10 retest (after rate-limit clear):

```
60 tools total
[scope: agent]:        49
[scope: org-admin]:    10  (was 'admin' — renamed)
[scope: super-admin]:   2  (NEW)
[scope: any]:           1
```

Refinement from round 5's `admin/agent/any` to `org-admin/super-admin/agent/any`. Two new super-admin tools added. ✓

### NEW field: `pollToken` (verified live)

Every `POST /api/orgs/register` response now includes `pollToken` (24 bytes / 48 hex chars):

```json
{
  "orgId": "236c7989-…",
  "verificationSent": true,
  "pollToken": "b79a1cd13d18b20e548fb0d9eff4fa989a7f5a1cd2b2acee",
  "webhookSecret": "8d3fce…(64 chars)"   // when webhookUrl supplied AND email is pending
}
```

Per BD: rotated on every register call, invalidated on verify. Pass as `?poll_token=<…>` query when polling `/verification-status` (the recommended flow during signup, since the team token isn't available yet).

**SDK action:** updating `AccountsClient.register()` docstring to surface `pollToken` in the return-shape documentation. The dict already passes through verbatim — no signature change needed. See SDK update commit alongside this v2.0 doc bump.

### F89 — STILL OPEN after sprint 10

```
Sprint-10 register response keys:
  pending email + webhookUrl  → {orgId, verificationSent, pollToken, webhookSecret}
  verified email + webhookUrl → {orgId, verificationSent, pollToken}     ← no webhookSecret
```

The asymmetry on `webhookSecret` persists. F04 randomization closed the orgId leak; the webhookSecret leak is independent and still observable. Recommended fix unchanged: always emit a `webhookSecret` value when `webhookUrl` is provided (randomized dummy for verified-email cases).

### Updated tally after sprint 10

```
✅ FIXED:    46 / 89   (52%)   +7 vs round-5 v1.0
⚠️ PARTIAL:  10 / 89   (11%)   -4
❌ OPEN:     28 / 89   (31%)   -3
🚫 WONTFIX:   1 / 89    (1%)
ℹ️ INFO:      4 / 89    (4%)
```

Cumulative: ~60 findings shipped across 10 sprints.

### Remaining critical/high open

- **F89** [HIGH] — webhookSecret asymmetry (carried from round 5; not addressed in sprint 10)
- **F71** [LOW] — `X-Powered-By: Express` (1-line fix; opportunistic)
- **F73** [MEDIUM] — `/openapi.json` at root (not just `/api/v1/`)
- **F75** [LOW] — `retryAfter` + `retry_after` hedge on RATE_LIMITED responses (per F12 cluster, may need separate sweep)
- **F58** [MEDIUM] — `comms_whatsapp_action` 13-action mega-dispatcher
- **F61** [MEDIUM] — Zod-stringified MCP errors (BD deferred per their own doc)
- **F05** [HIGH] — mailer-delivery webhook lifecycle (BD: needs mailer-provider decision)
- **F06** [CRITICAL] — org-name DNS verification (BD: needs product decision)
- **F08-full** [HIGH] — top-level `error` as object refactor (BD: breaking change, needs sign-off)

See `docs/BD_SERVER_OPEN_ITEMS.md` for the full prioritized backlog.
