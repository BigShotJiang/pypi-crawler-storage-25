<!-- version: 1.0 | updated: 2026-04-28 -->

# Butt-Dial Server — API & Contract Review (Round 2)

**To:** Butt-Dial server team
**From:** SDK side review (continued)
**Date generated:** 2026-04-28
**SDK version:** 0.3.0
**Server probed:** `https://call.95percent.ai`
**Agent created during this round:** `d51b0eb9-0a27-4225-bb55-9c9355935f87` (org `28bf35dd-995f-46ac-96da-1f99ac9d9b52`)

## What this document is

This is the second-round review, building on `docs/BD_SERVER_FEEDBACK.md`. It contains:

1. **Status updates** on round-1 findings (F08, F22, F23, F32, F36 — some verified, some upgraded, some good news).
2. **New findings F41–F69** discovered while authenticated, after registering an agent and probing the full MCP tool surface (44 tools).
3. **One SDK-side fix already shipped** — F41, see status table.
4. **Updated cleanup requests** — one agent + three orgs.

Same numbering convention as round 1 — finding IDs are stable, never renumber. Status flips: `[open]` → `[in-progress]` → `[fixed]` → `[verified]`.

---

## Status updates on round-1 findings

| ID | Status | Notes |
|---|---|---|
| F08 (error envelope inconsistent) | **partial-pattern-exists** | Server *does* emit structured envelopes on auth errors: `{error, code, retryable, remainingAttempts}`. Pattern is implemented; just needs propagation to application errors. Cheaper fix than originally estimated. |
| F22 (SSE handshake unauth then 401 on POST) | unchanged | Confirmed again — `/sse` opens unauth, first `/messages` POST 401s with `AUTH_MISSING_HEADER`. |
| F23 (verify AUTH_* codes are emitted) | **VERIFIED** ✓ | Bogus token → `AUTH_TOKEN_REVOKED` (on `/api/orgs/me`) and `AUTH_INVALID_TOKEN` (on `/api/v1/agents/me`). No header → `AUTH_MISSING_HEADER`. Lockout counter is active (`remainingAttempts: 9`). The SDK's auth-middleware error decoding works. *But:* see F49 (different code for the same scenario across endpoints). |
| F32 (retryable distinction in errors) | **partial-pattern-exists** | Auth errors carry `retryable: false`. Application errors don't. Same fix path as F08. |
| F36 (REST + MCP duplicate surfaces) | **VERIFIED** ✓ | `comms_get_usage_dashboard` MCP tool returns identical shape to `GET /api/v1/usage` REST. Two implementations to keep in sync; same casing (camelCase) on both, so at least they don't drift in shape. |
| F09 (verify-failed dead-end UX) | unchanged | Still no resend link. |
| F31 (no rate-limit headers) | unchanged | Confirmed — limits returned in `/api/v1/usage` body, not in HTTP response headers. |

---

## TL;DR — round 2

**The single biggest insight:** the server's auth-middleware emits a fully structured error envelope (`{error, code, retryable, remainingAttempts}`). **The pattern exists.** Application-level error responses don't use it. F09 (consistent `code` field) just got cheaper — extend the existing middleware pattern to application errors.

Highest-impact new findings:

1. **F41** [HIGH] [fixed] — `AccountsClient.get_agent_self()` always 404s on the live server. Method removed from SDK; tests updated.
2. **F45** [HIGH] — `/api/v1/usage` and `comms_get_usage_dashboard` return spend caps (`spendDayLimit: 10`) without a `currency` field. Meaningless number.
3. **F55** [HIGH] — Tool descriptions use "client" / "agent" / "provider" interchangeably for the same concept. The SDK calls it "agent", most tool descriptions say "client", and a few say "agent" or "provider". Vocabulary is unstable across the server's own surface.
4. **F56** [HIGH] — Casing now confirmed at every layer: REST `/api/v1/agents` uses snake_case; REST `/api/v1/usage` uses camelCase; MCP tool inputSchemas are uniformly camelCase. Different rules for adjacent endpoints in the same `/api/v1/*` namespace.
5. **F63** [HIGH] — MCP authorization is per-tool and inconsistent. `comms_list_available_numbers` requires admin (team_token); `comms_ping` accepts either token. Undocumented authorization model.

---

## A. Critical / contract bugs

### F41 [HIGH] [fixed] — SDK's `AccountsClient.get_agent_self()` always 404s on live server

**Observed.** SDK method `AccountsClient.get_agent_self()` (`accounts.py:339-347`) called `GET /api/v1/agents/me` using the `team_token`. Live server requires `agent_token` for this endpoint — with `team_token` it returned `{"error":"Agent \"<orgId>\" is not provisioned."}` (404), where the UUID in the error is the **orgId**, not an agent_id (this part is finding F28 from round 1).

**Why it matters.** The method has been broken since written. Test fixture used a mocked snake_case response that never matched reality, so all tests passed while production calls would always fail.

**SDK fix shipped this round.** Method removed from `AccountsClient`. Hosts already have the host-supplied `agent_id` and can use `get_agent(agent_id)` (which works with `team_token` per round-1 findings). Test for the dead method removed. Docstrings in `errors.py` updated to reference the right endpoints. Full pytest suite passes (198 tests).

**Server-side request.** Decide what `/api/v1/agents/me` *should* do when called with `team_token`:
- Option A: 400 + `code: "WRONG_TOKEN_TYPE"` (matches the pattern from `/api/v1/usage`).
- Option B: route is intended only for `agent_token` — return 401 + `code: "AUTH_WRONG_SCOPE"` (cleaner).
- Either way, **don't echo the orgId in an error message that says "Agent <X>"** (F28).

### F45 [HIGH] [open] — Spend caps shipped without currency

**Observed.** `GET /api/v1/usage` and `comms_get_usage_dashboard` return:

```json
{
  "currentUsage": {
    "spendToday": 0,
    "spendDayLimit": 10,
    "spendMonth": 0,
    "spendMonthLimit": 100
  },
  "limits": {
    "maxSpendPerDay": 10,
    "maxSpendPerMonth": 100
  }
}
```

No `currency` field. `comms_get_income` similarly:
```json
{"providerCost": 0, "billedCost": 0, "income": 0}
```

**Why it matters.** $10/day, ₪10/day, €10/day, and 10 cents/day are very different limits. An agent reading "spendDayLimit: 10" cannot tell what unit it's in, can't translate, can't display, can't budget. For a payments-adjacent service this is unsafe.

**Recommended fix.** Always include `currency: "USD"` (or `"ILS"`, `"EUR"`, ISO 4217) on every monetary field. Or wrap money fields as objects: `{spendDayLimit: {amount: 10, currency: "USD"}}`. Document a single canonical unit in API docs.

### F49 [HIGH] [open] — Different AUTH_* codes for the same scenario across endpoints

**Observed.** Same bogus Bearer token, two endpoints, two different codes:

```
GET /api/orgs/me          → {"code":"AUTH_TOKEN_REVOKED",  "remainingAttempts": absent}
GET /api/v1/agents/me     → {"code":"AUTH_INVALID_TOKEN",  "remainingAttempts": 9}
```

**Why it matters.** SDK's typed-error decoder maps `AUTH_TOKEN_REVOKED` to `AuthTokenRevokedError` and `AUTH_INVALID_TOKEN` to `AuthInvalidTokenError`. Hosts that catch one or the other now see different exceptions for what is *the same situation* (a bogus token). Agents reasoning about which fault occurred get inconsistent signals.

Bonus inconsistency: `remainingAttempts` is present on one path, absent on the other. Lockout protection is enforced *somewhere*, but the visibility into it varies.

**Recommended fix.** Pick one code per scenario:
- `AUTH_TOKEN_REVOKED` — token was once valid, has been revoked (rotation, manual revoke).
- `AUTH_INVALID_TOKEN` — token never existed or fails signature/format check.
- `AUTH_LOCKED_OUT` — too many bad attempts; backed off.

Currently the server appears to conflate "revoked" with "invalid". Fix: emit `AUTH_INVALID_TOKEN` for unknown/bogus tokens at every endpoint. Reserve `AUTH_TOKEN_REVOKED` for tokens that are in the system but disabled. And include `remainingAttempts` consistently.

### F50 [HIGH] [open] — Structured error envelope exists for auth, not app errors

**Observed.** Auth errors:

```json
{"error":"Invalid or revoked token","code":"AUTH_INVALID_TOKEN","retryable":false,"remainingAttempts":9}
```

Application errors:

```json
{"error":"orgName and ownerEmail are required"}
```

**Why it matters.** This is great news for the server team — the structured-envelope pattern (top-level `error`, `code`, `retryable`, optional metadata) is already implemented for auth errors via the auth middleware. F08's recommendation just got cheaper: extend the same envelope to application errors. There's a working template; copy it.

**Recommended fix.** Move the envelope construction into a shared helper used by every endpoint, not just the auth middleware. Standard shape:

```json
{
  "error": {
    "code": "STABLE_CODE",
    "message": "Human-readable string.",
    "retryable": false,
    "retryAfter": null,
    "fields": [{"name": "ownerEmail", "issue": "missing"}],
    "metadata": {"remainingAttempts": 9, "limit": 100}
  }
}
```

(Recommend nesting under `error` to keep top-level body free for legitimate response data.)

### F51 [MEDIUM] [open] — `comms_ping` leaks internal infrastructure stack

**Observed.** Authenticated `comms_ping` response:

```json
{
  "status": "ok",
  "server": "butt-dial-mcp",
  "version": "0.1.0",
  "echo": null,
  "pool": {"maxAgents": 20, "activeAgents": 0, "slotsRemaining": 20},
  "providers": {
    "telephony": "twilio",
    "email": "resend",
    "whatsapp": "twilio",
    "tts": "edge-tts",
    "database": "sqlite"
  }
}
```

**Why it matters.** Several issues:
- **Vendor disclosure.** Any authenticated client (potentially every paying customer) now knows you use Twilio for telephony, Resend for email, edge-tts for TTS, etc. This narrows the attack surface for someone hunting credentials and gives competitors competitive intelligence for free.
- **`database: "sqlite"`** is a particularly concerning leak — it tells a curious party that the production data layer is SQLite. Either that's a misreport, or it's a real durability/concurrency concern that shouldn't be advertised.
- **Pool capacity** (`maxAgents`, `activeAgents`, `slotsRemaining`) is operational data that probably shouldn't be in a ping response. It belongs in admin endpoints, not in a tool that any agent can call.
- **`activeAgents: 0`** while my agent has `status: "active"` (F54) is also a vocabulary collision — see below.

**Recommended fix.**
- Strip `providers` and `database` from `comms_ping`. Or split: keep a public ping (`{status, version}`) and a private admin diagnostics tool.
- Strip `pool` from the public ping; expose it via `comms_get_admin_dashboard` (admin-token only) instead.

### F58 [MEDIUM] [open] — `comms_whatsapp_action` is a 13-action mega-dispatcher

**Observed.** A single tool dispatches 13 sub-actions: `send_location`, `send_contact`, `typing`, `mark_read`, `react`, `edit`, `delete`, `forward`, `send_poll`, `send_buttons`, `post_status`, `set_chat_ttl`, `send_view_once`. Each requires different fields. The schema can't express conditional requirements ("if `action=send_poll`, require `title` and `options`") — fields are described per-action in plain text.

**Why it matters.** For an LLM agent reading the schema to decide how to call this tool: it has to read 13 conditional descriptions, infer which fields go with which action, and assemble a valid call. High failure rate. The MCP `description` field for each "tool" is what an agent uses to choose; one mega-tool with 13 sub-behaviors hides 12 of them.

**Recommended fix.**
- Split into 13 separate tools: `whatsapp_send_location`, `whatsapp_send_poll`, `whatsapp_react`, etc. Each has a clean per-tool schema.
- OR use JSON Schema `oneOf` with discriminator on `action`. MCP supports it; LLMs handle it better than free-text "if ... then" rules.

The SDK currently models each sub-action as a separate Python method (`whatsapp_typing`, `whatsapp_mark_read`, ...) but funnels them all through the one tool. The Python surface is fine; the MCP surface is not.

---

## B. New casing & vocabulary findings

### F43 [HIGH] [open] — Within `/api/v1/*`, agents endpoints use snake_case but usage uses camelCase

**Observed.** This round confirmed the response casings:

```bash
# /api/v1/agents — snake_case in BOTH request and response
POST /api/v1/agents       request:  {"agent_id": "...", "display_name": "..."}
                          response: {"agent_id": "...", "token": "..."}
GET  /api/v1/agents/me    response: {"agent_id":"...", "display_name":"...",
                                     "callback_url": null, "provisioned_at": "..."}

# /api/v1/usage — camelCase response
GET  /api/v1/usage        response: {"agentId":"...", "totalActions": 0,
                                     "costsByChannel": {}, "currentUsage": {...}}

# MCP tool schemas — uniformly camelCase
comms_send_message inputSchema: agentId, templateId, fallbackChannels, idempotencyKey
comms_provision_channels inputSchema: agentId, agentName, capabilities (object with phone, whatsapp, voiceAi)
```

**Why it matters.** Adjacent endpoints in the same `/api/v1/*` namespace require opposite request-body conventions. Hosts can't write "everything is camelCase" or "everything is snake_case" code paths.

**Recommended fix.** Standardize on camelCase across REST and MCP (4 of 5 already are; matches Express idiom and MCP tool schemas). Migrate `/api/v1/agents` to accept and return camelCase. Use `Deprecation:` HTTP headers for the snake_case grace period.

### F44 [LOW] [open] — `provisioned_at` is non-ISO + misleadingly named

**Observed.** Agent response includes `"provisioned_at": "2026-04-28 14:38:49"`. The agent has zero channels provisioned (`phone: null, whatsapp: null, email: null`) — the timestamp is the **creation** time, not a provisioning time.

**Why it matters.** Two bugs:
- Format is non-ISO (space-separated, no T, no Z). Same as F37 from round 1.
- Field name lies — there's no provisioning yet, but the field claims provisioning happened.

**Recommended fix.**
- Rename to `created_at` (or `createdAt` once F43 is fixed).
- Add a separate `provisioned_at` that's set only when channels are actually provisioned (or stays `null` until then).
- Fix format to `2026-04-28T14:38:49Z` per F37.

### F55 [HIGH] [open] — Tool descriptions use "client" / "agent" / "provider" interchangeably

**Observed.** Vocabulary used in MCP tool descriptions (sample):

| Tool | Description vocabulary |
|---|---|
| `comms_send_message` | "from a **client** to a recipient" |
| `comms_provision_channels` | "Provision a new **client**" |
| `comms_get_channel_status` | "for a **client**" |
| `comms_set_client_limits` | "**client**" (in tool name too) |
| `comms_get_usage_dashboard` | "Admin sees all **clients**; **clients** see only their own" |
| `comms_make_call` | "AI **client**" |
| `comms_find_agent` | "Find other **agents** in the directory" |
| `comms_message_agent` | "another **agent** in your organization" |
| `comms_register_provider` | "third-party **provider** credentials" |
| `comms_check_trust` | "**contact**" |

Server-side error messages also use "client": *"Use your **client token**, not the org API key. The **client token** was returned when you provisioned."*

The SDK's terminology: `Agent` class, `agent_id`, `BUTT_DIAL_AGENT_TOKEN`, `register_agent()`. The server-side terminology: `client`, `agentId` (in field names), `clients` (in pool descriptions). The verification email says "**API key**".

**Why it matters.** A consumer building against this surface — especially an LLM agent — has to decide whether "client" and "agent" refer to the same thing on every read. They do, but only sometimes (`comms_register_provider` uses "provider" for an external integration; `comms_check_trust` uses "contact" for the recipient phone).

**Recommended fix.** Single canonical glossary. Recommendation:
- **Agent**: the BD-provisioned entity that sends/receives messages. (SDK already uses this.)
- **Contact**: the external party an agent communicates with.
- **Provider**: external third-party credential (Twilio, Resend, ElevenLabs).

Then audit every tool description, error message, and field name to use exactly these. Drop "client" everywhere. It collides with HTTP-client and TCP-client and Slack-client meanings.

### F56 [HIGH] [open] — Three different casing rules across REST and MCP layers

**Observed.** Continuing F43:

| Layer | Endpoint | Casing |
|---|---|---|
| REST | `/api/v1/agents` (POST + GET) | snake_case (req + resp) |
| REST | `/api/v1/usage` | camelCase (resp) |
| REST | `/api/orgs/me` | camelCase (resp) |
| REST | `/api/orgs/register` | camelCase (req + resp) |
| REST | `/api/orgs/verify` | snake + camel + alias hedge (resp) |
| REST | `/api/orgs/me/phone/set` | snake (req: `phone`), camel error code (`PHONE_INVALID`) |
| REST | `/api/v1/provision` | camelCase (req: `agentName`, `capabilities.voiceAi`) |
| MCP | all 44 tool inputSchemas | uniform camelCase |
| MCP | tool responses | uniform camelCase |

**Why it matters.** MCP is consistent (camelCase throughout). REST is the chaotic layer. The discrepancy means the SDK's REST module and MCP module have to model the same underlying data with different field names. Hosts that round-trip data between REST and MCP have to translate.

**Recommended fix.** Migrate the snake_case REST endpoints (`/api/v1/agents`, `phone/set` request body) to camelCase. Then SDK can drop its case-translation layer entirely.

---

## C. Agent ergonomics & contract clarity (new)

### F42 [MEDIUM] [open] — Agent `status: "active"` despite zero provisioned channels

**Observed.** Right after `register_agent` and before any `provision`:

```json
{
  "agent_id": "d51b0eb9-...",
  "display_name": "elradts-probe-agent",
  "status": "active",
  "channels": {"phone": null, "whatsapp": null, "email": null},
  "callback_url": null,
  "provisioned_at": "2026-04-28 14:38:49"
}
```

**Why it matters.** "Active" implies the agent can do something. In reality this agent can't communicate at all — no phone, no WA, no email channel allocated. The `status` field is too coarse to describe agent reality.

**Recommended fix.** Replace coarse `status` with explicit `lifecycleState`:

```
agent.lifecycleState ∈ {
  "registered",      // record exists, no channels
  "provisioning",    // channels being allocated
  "ready",           // at least one channel allocated and operable
  "suspended",       // admin-disabled
  "deregistered"     // soft-deleted
}
```

Or compute `status` from the channel state — if all channels are `null`, `status: "no_channels"` not `"active"`.

### F46 [MEDIUM] [open] — Usage `period: "today"` without start/end timestamps or timezone

**Observed.** Usage response contains `"period": "today"` with no `start` or `end` fields, no timezone declaration.

**Why it matters.** What's "today"? UTC? Server timezone? Org's timezone? Agent's timezone? An agent in Tokyo and an agent in NYC cannot compare their daily totals without knowing the boundary.

**Recommended fix.**
```json
"period": {
  "name": "today",
  "start": "2026-04-28T00:00:00Z",
  "end": "2026-04-29T00:00:00Z",
  "timezone": "UTC"
}
```

### F47 [MEDIUM] [open] — Opaque empty-object shapes (`actions: {}`, `costsByChannel: {}`, `byChannel: {}`)

**Observed.** When usage is zero, several fields are `{}`. The schema doesn't hint what keys to expect when populated.

**Why it matters.** Agents (and SDK code-gen tools) cannot model these shapes from observation alone. We have to guess that `actions` keys might be `"send_message"`, `"make_call"` etc. and that `costsByChannel` keys might be `"sms"`, `"whatsapp"`, `"email"`, `"voice"`. Guessing is fragile.

**Recommended fix.**
- Document the union of possible keys in API docs.
- Or always emit known keys with zero values: `{"sms": 0, "whatsapp": 0, "email": 0, "voice": 0}`.

### F48 [MEDIUM] [open] — `maxCallsPerDaySameNumber: 10` is undocumented

**Observed.** Usage response includes `"limits": { ..., "maxCallsPerDaySameNumber": 10}`. Important business rule (anti-abuse), exposed via API but not in any docs page we found.

**Why it matters.** An agent that hits this limit gets a 429 (presumably) with no understanding of why. "Why can't I call this number 11 times today?" An LLM debugging this would burn a lot of attempts before realizing.

**Recommended fix.** Document every limit field in `/openapi.json` (once F20 lands), or as MCP-tool description text on `comms_get_usage_dashboard`.

### F53 [MEDIUM] [open] — `maxAgents: 20` cap is undocumented

**Observed.** `comms_ping` exposes `pool: { maxAgents: 20, activeAgents: 0, slotsRemaining: 20 }`. What's the scope? Per org? Per server? Per plan tier?

**Why it matters.** A scaling org will hit this cap and the response will be opaque. Knowing the cap exists is half the battle; knowing what it scopes to is the other half.

**Recommended fix.** Document in tool description and in API docs. Add `pool.scope: "org" | "instance" | "plan"` to make it explicit.

### F54 [MEDIUM] [open] — Vocabulary collision: `agent.status="active"` vs `pool.activeAgents=0`

**Observed.** My agent's `status: "active"` (per `/api/v1/agents/me`). But `comms_ping`'s `pool.activeAgents: 0`. The same word "active" means two different things on the same authenticated session.

**Why it matters.** An agent reading both responses would conclude something is broken. The `pool.activeAgents` likely means "agents currently engaged in a call/conversation" while `agent.status: "active"` means "agent record is in the active state" — but those meanings are not labeled.

**Recommended fix.**
- Rename `pool.activeAgents` to `pool.busyAgents` or `pool.inCallAgents`.
- Per F42, replace agent's `status` with explicit `lifecycleState`.

### F60 [HIGH] [open] — `idempotencyKey` is per-tool, not server-wide

**Observed.** `comms_send_message` schema includes:
```json
"idempotencyKey": {
  "type": "string",
  "description": "Optional unique key to prevent duplicate sends on retry. If the same key was already used, the previous result is returned instead of sending again."
}
```

This is **excellent** — exactly what F25 from round 1 asked for. But it's only on this one tool. `comms_provision_channels`, `comms_make_call`, `comms_send_voice_message`, `register_agent` (REST) — none expose it. And REST endpoints don't accept `Idempotency-Key` HTTP header either.

**Why it matters.** Agents retry on transient failures. Without idempotency on every mutating endpoint, retry duplicates state (the duplicate-org bug from round 1's F01 is the same class of issue).

**Recommended fix.** Standardize: every mutating REST endpoint accepts `Idempotency-Key` HTTP header. Every mutating MCP tool accepts an `idempotencyKey` field. Server stores `(key → response)` for ≥24h. The send_message implementation is the template.

### F61 [MEDIUM] [open] — MCP validation errors return Zod's stringified output inside an MCP error

**Observed.** Calling `comms_validate_number` with wrong field name returned:

```
MCP error -32602: Input validation error: Invalid arguments for tool comms_validate_number:
[{"code":"invalid_type","expected":"string","received":"undefined","path":["phoneNumber"],"message":"Required"}]
```

**Why it matters.** The Zod validator output is rich and structured (`code`, `path`, `expected`, `received`, `message`) but it's serialized as a JSON string concatenated to an English prefix. An LLM agent has to (a) recognize the prefix, (b) extract the JSON tail, (c) parse it. That's three steps where one would do.

**Recommended fix.** Pass the Zod errors as MCP error `data` field (JSON-RPC supports it):

```json
{
  "code": -32602,
  "message": "Invalid arguments for comms_validate_number",
  "data": {
    "tool": "comms_validate_number",
    "errors": [
      {"path": "phoneNumber", "issue": "required", "expected": "string", "received": "undefined"}
    ]
  }
}
```

### F62 [LOW] [open] — `pool` info duplicated across `comms_ping` and `comms_get_channel_status`

**Observed.** Both tools include the same `pool: {maxAgents, activeAgents, slotsRemaining}` block.

**Why it matters.** Either it's intentional (and now there are two sources of truth that can drift) or it's a leak in `comms_ping`.

**Recommended fix.** Single canonical source — admin-only, behind a separate tool. Strip from both `comms_ping` and `comms_get_channel_status`.

### F63 [HIGH] [open] — MCP authorization is per-tool and inconsistent

**Observed.**

| Tool | Token type | Result |
|---|---|---|
| `comms_ping` | agent_token | OK |
| `comms_ping` | team_token | OK (no scope check) |
| `comms_get_channel_status` | agent_token | OK (returns this agent) |
| `comms_get_usage_dashboard` | agent_token | OK |
| `comms_list_available_numbers` | agent_token | **403** — `{"error":"Admin access required. Client tokens cannot perform this action."}` |

**Why it matters.** Some tools enforce scope (admin-only), some accept either token, some are agent-context-only. There's no documented authorization model. An agent calling tools blindly will hit some, fail others, with no way to predict which is which.

**Recommended fix.** Document each tool's required scope in its description (or in a structured `x-mcp-scope` annotation). One of:
- `public` (no auth)
- `agent` (any agent_token)
- `agent-self` (agent_token, scoped to that agent's data)
- `admin` (team_token only)
- `either` (both work)

LLM agents need this in the schema, not buried in error messages.

### F64 [INFO] — `comms_get_usage_dashboard` MCP tool returns identical shape to `/api/v1/usage`

**Observed.** Same JSON shape, same data. F36 confirmed.

**Why it matters.** Two implementations to keep in sync. They currently match; they may drift.

**Recommended fix (per F36).** Pick one as canonical. Have the other be a thin proxy.

### F65 [LOW] [open] — `comms_get_income` ships costs without currency

**Observed.** `{providerCost: 0, billedCost: 0, income: 0}`. Same currency-omission as F45.

**Recommended fix.** Same as F45 — add `currency` field.

### F67 [MEDIUM] [open] — `comms_make_call.country` field is ambiguous

**Observed.** `comms_provision_channels` has `country: "US"` (default). `comms_make_call` doesn't have one. The semantics aren't documented:

> "country": {"type": "string", "default": "US", "description": "Country code for phone number (default: US)"}

**Why it matters.** Is `country` the country to buy a phone number FROM? The country to call? The country to use for routing? An LLM has no way to choose correctly.

**Recommended fix.** Rename to clarify, e.g., `purchaseRegion` for provisioning. Add explicit description: "ISO 3166-1 alpha-2; the country where the new number will be allocated (e.g. US, IL, DE)."

### F68 [MEDIUM] [open] — `comms_send_message.body` is required-conditional but schema says optional

**Observed.** `comms_send_message` schema marks only `to` as required. `body` has a default of `""`. But the description says "*The message text to send (required unless media is provided)*". The conditional requirement isn't expressible in the schema.

**Why it matters.** Agents reading the schema think `body` is optional. Server enforces conditional requirement at runtime. Validation errors then say "body required" or similar — which contradicts the schema.

**Recommended fix.** Use JSON Schema `oneOf`:

```json
{
  "oneOf": [
    {"required": ["to", "body"]},
    {"required": ["to", "media"]},
    {"required": ["to", "templateId"]}
  ]
}
```

Or split: `comms_send_text_message`, `comms_send_media_message`, `comms_send_template_message`.

### F69 [LOW] [open] — `comms_register_provider` description mentions saving to a `.env` file

**Observed.** Description: "Register and verify third-party provider credentials (Twilio, Resend, ElevenLabs). Saves to .env file."

**Why it matters.** Either the production server stores credentials in a `.env` file (concerning — file-based credential storage is a smell), or this description is leftover from dev/prototype mode. Either way, exposing the storage backend in a public tool description is unnecessary.

**Recommended fix.** Drop the implementation detail from the description. Replace with: "Register third-party provider credentials. Stored encrypted at rest."

---

## D. Positive findings (worth noting)

1. **Auth middleware is well-built.** `AUTH_*` codes, `retryable: false`, `remainingAttempts`, lockout protection — all working. Good template for application errors (F50).
2. **Send-message has `idempotencyKey`.** Best-in-class on this one tool. Roll it out to the rest (F60).
3. **Send-message has `targetGender` for gendered languages.** Surprisingly thoughtful for international support.
4. **Send-message has `fallbackChannels` for multi-channel failover.** Strong primitive for reliable delivery.
5. **Server-side response caching** — `ETag` and `Strict-Transport-Security` headers are present on REST responses. CSP is locked down (`default-src 'none'`). Good security headers.
6. **Async-style verification email arrived in <2 min** on the second attempt. Mailing pipeline works; just needs delivery state visibility (F05/F26).
7. **MCP serverInfo + protocolVersion both reported.** SDK can introspect protocol version. (Just bump the version field on contract changes — F21.)

---

## Cleanup requests

| What | Why |
|---|---|
| Delete orphan org `646bbace-0a01-45d6-b571-137b54413a66` (still pending from round 1) | Test artifact from round-1 probing |
| Delete orphan org `b5d31db6-394c-41bc-8d2a-972f7d152264` (still pending from round 1) | Real-email probe with expired token |
| Delete agent `d51b0eb9-0a27-4225-bb55-9c9355935f87` and its team_token | Probe artifact in org `28bf35dd-…`. Or keep the org+agent active for verifying fixes — your call. |
| Optional: rotate `team_token` on org `28bf35dd-…` (`5e95...c27b48`) | Token in chat history during probing |

---

## What we'd like to verify next

Mutating endpoints we haven't touched. Each requires explicit go-ahead.

1. **`POST /api/orgs/me/phone/set` + `confirm`** — full OTP round-trip. Confirms `OTP_INVALID`, `OTP_EXPIRED`, `OTP_MAX_ATTEMPTS`, `CHALLENGE_NOT_FOUND` codes from the SDK's typed-error table. Will send a real SMS to a real phone.
2. **`POST /api/v1/provision` with `{phone: true}` capability** — actually allocates a number. May incur cost. Confirms response shape for `provision`, channel allocation contract, and what `agent.channels.phone` looks like when populated.
3. **`comms_send_message`** with our agent's number to a friendly recipient — actually sends a message. Confirms `idempotencyKey` round-trip semantics.
4. **`comms_validate_number` with the corrected `phoneNumber` field** — read-only; missed it this round.
5. **`comms_check_consent` with all required fields** (`contactAddress`, `channel`) — read-only; missed it this round.
6. **`POST /api/orgs/me/rotate-token/request` + `confirm`** — full token rotation, confirms `TOKEN_REVOKED` emission on the old token.

---

## Appendix — round 2 reproducers

All commands assume `bash` and `curl`; substitute `$TOK` (team_token) and `$AGT` (agent_token).

### F23 / F49 / F50 — auth error codes

```bash
curl -sS -i https://call.95percent.ai/api/orgs/me -H "Authorization: Bearer bogus"
# 401 {"error":"Invalid or revoked token","code":"AUTH_TOKEN_REVOKED","retryable":false}

curl -sS -i https://call.95percent.ai/api/v1/agents/me -H "Authorization: Bearer bogus"
# 401 {"error":"Invalid or revoked token","code":"AUTH_INVALID_TOKEN","retryable":false,"remainingAttempts":9}

curl -sS -i https://call.95percent.ai/api/orgs/me
# 401 {"error":"Bearer token or session cookie required","code":"AUTH_MISSING_HEADER","retryable":false}
```

### F41 — agents/me with team_token (the SDK bug)

```bash
curl -sS https://call.95percent.ai/api/v1/agents/me -H "Authorization: Bearer $TOK"
# 404 {"error":"Agent \"<orgId>\" is not provisioned."}
# Note the UUID is the orgId, NOT an agent_id.
```

### F43 — request casing per endpoint

```bash
# /api/v1/agents — snake_case
curl -sS -X POST https://call.95percent.ai/api/v1/agents \
  -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d '{"agent_id":"<uuid>","display_name":"x"}'
# 201 {"agent_id":"<uuid>","token":"..."}

# /api/v1/usage — camelCase
curl -sS https://call.95percent.ai/api/v1/usage -H "Authorization: Bearer $AGT"
# 200 {"agentId":"...","totalActions":0,"costsByChannel":{},"currentUsage":{...},"limits":{...}}

# /api/v1/provision — camelCase
curl -sS -X POST https://call.95percent.ai/api/v1/provision \
  -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{}'
# 400 {"error":"Missing required field 'agentName'..."}
```

### F45 / F46 / F47 — usage shape

```bash
curl -sS https://call.95percent.ai/api/v1/usage -H "Authorization: Bearer $AGT" | python -m json.tool
# Note the absence of `currency` field in spendDayLimit, spendMonthLimit
# Note `period: "today"` with no start/end/timezone
# Note `actions: {}` and `costsByChannel: {}` opaque
```

### F51 — comms_ping leaks

```bash
# Use the SDK's MCP probe — see scripts/probe_ping.py in this repo
BD_AGENT_TOKEN="$AGT" python scripts/probe_ping.py
# Note: providers (twilio, resend, edge-tts, sqlite), pool, version
```

### F55 / F56 — tool surface vocabulary + casing

```bash
# Lists all 44 tools with descriptions and shows full schema for 8 representative tools
BD_AGENT_TOKEN="$AGT" python scripts/probe_tools.py
# Note "client" vs "agent" vs "provider" vocabulary
# Note all MCP schemas use camelCase
```

### F58 — whatsapp_action mega-dispatcher

```bash
# Look at the comms_whatsapp_action schema in probe_tools.py output
# 13 actions in the action enum, conditional fields described in plain English
```

### F60 — idempotencyKey only on send_message

```bash
# Look at probe_tools.py output for comms_send_message inputSchema → idempotencyKey present
# Compare with comms_make_call, comms_provision_channels — no idempotencyKey
```

### F63 — MCP authorization is per-tool

```python
# From probe_tools.py call results:
# comms_ping(agent_token)                     → OK
# comms_get_channel_status(agent_token)       → OK
# comms_list_available_numbers(agent_token)   → 403 "Admin access required. Client tokens cannot perform this action."
```

---

*This document supersedes nothing in `BD_SERVER_FEEDBACK.md`. Both documents should be read together. Status updates on round-1 findings are the table at the top of this file.*
