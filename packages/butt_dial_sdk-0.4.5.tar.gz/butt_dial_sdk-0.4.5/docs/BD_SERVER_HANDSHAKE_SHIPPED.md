<!-- version: 1.0 | updated: 2026-04-29 -->

# BD Server — Onboarding Handshake (SHIPPED)

**Status:** Shipped on `https://call.95percent.ai`, commit `65fee63`
**Tracks:** F26 (webhook), F88 (caller-supplied template), F09-polish (branded verify page)
**Companion to:** `BD_SERVER_INSTRUCTIONS_onboarding.md` (the request)

---

## TL;DR

`POST /api/orgs/register` now accepts four optional blocks: `branding`, `returnUrl`, `webhookUrl`, `verificationEmail`. After the user verifies, BD either:

1. POSTs a signed `account.verified` event to `webhookUrl` (preferred), **or**
2. Redirects the verify page to `<returnUrl>#bd_token=…&org_id=…&verified_at=…` if no `webhookUrl` was given but `returnUrl` was.

Item 4 (`EMAIL_ALREADY_REGISTERED` 409) was **dropped** to preserve F04 anti-enumeration. `EmailAlreadyRegistered` in `accounts.py` stays dormant.

---

## 1. `AccountsClient.register()` signature extension

```python
# src/buttdial/accounts.py

async def register(
    self,
    org_name: str,
    owner_email: str,
    *,
    branding: dict | None = None,
    return_url: str | None = None,
    webhook_url: str | None = None,
    verification_email: dict | None = None,
) -> dict[str, Any]:
    """Start signup.

    Returns ``{org_id, verification_sent, webhook_secret?}``.

    ``webhook_secret`` is returned **once** — only on the first register call
    that supplies ``webhook_url``. Capture it immediately and store alongside
    the org record; it cannot be retrieved later. Re-registering the same
    pending org echoes the same secret (idempotent recovery), but once the
    org is verified the secret is no longer surfaced.

    All optional blocks are forwarded to the server:

    - ``branding``: ``{logoUrl, primaryColor, productName, supportEmail}``
      Stored on the org record. Read by the verify page (logo + accent
      color + "Return to <productName>" CTA).

    - ``return_url``: where the verify page redirects after success. If
      ``webhook_url`` is omitted, the redirect carries the team token in
      the URL fragment: ``#bd_token=…&org_id=…&verified_at=…``.

    - ``webhook_url``: BD will POST ``account.verified`` here after verify.
      See :func:`verify_webhook_signature` below.

    - ``verification_email``: ``{subject?, html?, text?}`` — caller-supplied
      verification email body. Substituted variables: ``{{verifyUrl}}``
      (required if ``html`` or ``text`` is provided), ``{{orgName}}``,
      ``{{ownerEmail}}``, ``{{expiresInMinutes}}``. HTML is sanitized
      (script/iframe/object/embed/on*= stripped). 200 KB cap.
    """
    body: dict[str, Any] = {"orgName": org_name, "ownerEmail": owner_email}
    if branding is not None:
        body["branding"] = branding
    if return_url is not None:
        body["returnUrl"] = return_url
    if webhook_url is not None:
        body["webhookUrl"] = webhook_url
    if verification_email is not None:
        body["verificationEmail"] = verification_email
    return await self._request(
        "POST", "/api/orgs/register",
        body=body,
        authenticated=False,
    )
```

### New error codes (raise as `AccountsError` with `code=`)

| Server `code` | Meaning |
|---|---|
| `TEMPLATE_MISSING_VERIFY_URL` | `verificationEmail.html` or `.text` was provided without `{{verifyUrl}}` |
| `TEMPLATE_TOO_LARGE` | HTML or text body > 200 KB raw |

`EmailAlreadyRegistered` remains intentionally unreachable per F04. Don't catch it.

---

## 2. Verifying the webhook signature

```python
# Reference implementation — drop into iv-bknd or expose as
# buttdial.webhooks.verify_account_verified()

import hmac, hashlib, time

def verify_webhook_signature(
    raw_body: bytes,
    *,
    timestamp_header: str,        # X-BD-Timestamp
    signature_header: str,        # X-BD-Signature  (e.g. "hmac-sha256=abc...")
    secret: str,                  # webhook_secret captured at register time
    tolerance_seconds: int = 300,
) -> bool:
    """Return True if the signature is valid AND fresh.

    Signature scheme (Stripe-style):
        signed_payload = f"{timestamp}.{raw_body.decode()}"
        sig = HMAC_SHA256(secret, signed_payload).hex()

    Reject if the timestamp is older than ``tolerance_seconds`` to defeat
    replay attacks. Reject if the signature header is malformed.
    """
    if not signature_header.startswith("hmac-sha256="):
        return False
    received = signature_header.split("=", 1)[1].strip()

    try:
        ts = int(timestamp_header)
    except (TypeError, ValueError):
        return False
    if abs(time.time() - ts) > tolerance_seconds:
        return False

    signed_payload = f"{ts}.{raw_body.decode('utf-8')}".encode("utf-8")
    expected = hmac.new(
        secret.encode("utf-8"), signed_payload, hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(expected, received)
```

### Webhook payload contract

```http
POST {webhookUrl}
Content-Type: application/json
X-BD-Event: account.verified
X-BD-Timestamp: 1730145000
X-BD-Signature: hmac-sha256=<hex>
X-BD-Delivery-Id: <uuid>

{
  "event": "account.verified",
  "orgId": "<uuid>",
  "ownerEmail": "<email>",
  "teamToken": "<token>",
  "scopes": "org-admin",
  "verifiedAt": "2026-04-28T18:30:00.000Z"
}
```

### Delivery semantics iv must handle

- **Idempotency.** Dedupe by `X-BD-Delivery-Id`. Same ID arrives across retries.
- **Retries.** Up to 5 attempts, backoff 1s / 5s / 25s / 2m / 10m. After 5 failures BD writes `status=dead` and stops.
- **Response window.** iv must respond `2xx` within 10s. Any `4xx`/`5xx` triggers retry.
- **Replay protection.** Reject deliveries with timestamp > ~5min stale (the helper above does this).
- **Token handling.** `teamToken` is the org's bearer credential — store it in the same vault `verify()`'s `team_token` would land in. Treat with the same secrecy.

---

## 3. Fragment-redirect fallback (no webhook)

When iv passes `return_url` but not `webhook_url`, the verify page redirects after success to:

```
<return_url>#bd_token=<teamToken>&org_id=<orgId>&verified_at=<iso>
```

The fragment never reaches a server. iv's frontend route consumes it:

```javascript
// iv frontend — on /api/workspace/butt-dial/verify-callback (or wherever returnUrl points)
const fragment = new URLSearchParams(window.location.hash.slice(1));
const teamToken = fragment.get("bd_token");
const orgId = fragment.get("org_id");
const verifiedAt = fragment.get("verified_at");

if (teamToken) {
  // POST to your own bknd to persist; never log the token
  await fetch("/api/workspace/butt-dial/persist-token", {
    method: "POST",
    body: JSON.stringify({ teamToken, orgId, verifiedAt }),
  });
  // Wipe the fragment so it doesn't sit in browser history
  history.replaceState(null, "", window.location.pathname);
}
```

**Webhook is strongly preferred** (see SDK's own `BD_SERVER_INSTRUCTIONS_onboarding.md`). Use the fragment fallback only when running the webhook receiver isn't viable.

---

## 4. Branded verify page — branding endpoint

The verify page fetches branding before consuming the token:

```http
GET /api/orgs/branding-by-token?token=<verificationToken>
→ 200 {logoUrl, primaryColor, productName, supportEmail, returnUrl, orgName}
   OR
→ 200 {} (unknown/expired tokens — no enumeration leak)
```

This endpoint is read-only — it does NOT consume the token. Only the verify POST consumes it. iv doesn't need to call this; it's an internal helper for the verify page UI. Documented here for transparency.

---

## 5. Email template — variable substitution

When `verificationEmail.html` or `.text` is provided, BD substitutes:

| Variable | Source |
|---|---|
| `{{verifyUrl}}` | Verification URL — **required** if `html` or `text` is provided |
| `{{orgName}}` | The `orgName` from the register call |
| `{{ownerEmail}}` | The `ownerEmail` from the register call |
| `{{expiresInMinutes}}` | `15` (the verification token TTL) |

**Sanitization** (HTML only): `<script>`, `<iframe>`, `<object>`, `<embed>` tags and `on*=` event handler attributes are stripped. Regex-based — adequate for marketing-grade templates, not a hardened sanitizer.

**Caps:** raw HTML or text > 200 KB → `400 TEMPLATE_TOO_LARGE`.

**Default behavior:** when `verificationEmail` is omitted, BD uses its existing plain-text template. Existing callers see no behavior change.

**Recovery emails:** intentionally NOT customizable (security-sensitive flow). The `/api/orgs/recover` endpoint always uses the BD-controlled template.

---

## 6. Server-side gotchas iv should know

These are the assumptions the server team flagged for sanity-check:

1. **Webhook secret idempotence.** Re-registering a pending org with the same email returns the **same** `webhook_secret`. New secrets are NOT minted on re-register. So if iv loses the secret before persisting, a retry with identical args recovers it — but only while the org is still pending. After verify, the secret is sealed.

2. **Sanitizer is regex-based.** A motivated attacker could craft pathological HTML the regex misses. iv should still pass templates iv itself controls (don't accept arbitrary user input for `verificationEmail.html`).

3. **F04 protector test exists.** The server suite has an explicit test that fails if anyone reintroduces email-enumeration leak. iv can rely on the silent-treatment behavior staying.

4. **No live HTTP integration test was run.** The server's webhook unit tests use mocked `fetchImpl`. **iv should run their actual flow once** against `https://call.95percent.ai` end-to-end to confirm before declaring victory.

5. **`mode` on verify response is unchanged.** The `verify()` method still returns `{team_token, org_id, mode}` — the new fields (`fragmentRedirectUrl`, etc.) are additive, not replacing existing keys.

---

## 7. Probe / smoke test

A minimal end-to-end probe (run from a host with internet access):

```python
# scripts/probe_handshake.py
import asyncio, hmac, hashlib, time, json
from aiohttp import web
from buttdial.accounts import AccountsClient

CAPTURED: list[dict] = []

async def hook_handler(req: web.Request) -> web.Response:
    raw = await req.read()
    CAPTURED.append({
        "headers": dict(req.headers),
        "body": json.loads(raw),
        "raw": raw,
    })
    return web.json_response({"ok": True})

async def main() -> None:
    app = web.Application()
    app.router.add_post("/hook", hook_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8765)
    await site.start()

    accounts = AccountsClient("https://call.95percent.ai")
    resp = await accounts.register(
        org_name="probe-handshake",
        owner_email="probe+handshake@example.com",
        webhook_url="https://YOUR-PUBLIC-TUNNEL.example/hook",
        return_url="https://YOUR-PUBLIC-TUNNEL.example/welcome",
        branding={
            "logoUrl": "https://placehold.co/120x40",
            "primaryColor": "#00C9A7",
            "productName": "probe",
            "supportEmail": "probe@example.com",
        },
        verification_email={
            "subject": "Verify your probe workspace",
            "html": "<p>Click <a href=\"{{verifyUrl}}\">here</a> to verify {{orgName}}.</p>",
        },
    )
    print("register response:", resp)
    secret = resp.get("webhook_secret")
    print("webhook_secret captured:", bool(secret))
    print("Click the verification link in the inbox; webhook will fire.")

    # Loop until first delivery
    deadline = time.time() + 120
    while time.time() < deadline and not CAPTURED:
        await asyncio.sleep(2)

    if CAPTURED:
        d = CAPTURED[0]
        print("delivery received, headers:", {k: d["headers"][k] for k in d["headers"] if k.startswith("X-BD-")})
        print("body:", d["body"])
        # Verify the signature
        from your_module import verify_webhook_signature  # see Section 2
        ok = verify_webhook_signature(
            d["raw"],
            timestamp_header=d["headers"]["X-BD-Timestamp"],
            signature_header=d["headers"]["X-BD-Signature"],
            secret=secret,
        )
        print("signature ok:", ok)

asyncio.run(main())
```

Use `ngrok http 8765` (or similar) to give BD a public URL to POST to.

---

## 8. Cumulative status

| Sprint | Commit | Findings |
|---|---|---|
| 1 | 073e86a | F01 F02 F09(focused) F11 F12 F19 F37 F38 |
| 2 | 4d72ce0 | F03 F04 F09(rest) F14 F17 F18 F25 |
| 3 | 773adb4 | F41 F44 F45 F46 F47 F49 F50 F51 F65 F69 |
| 4 | 7931a83 | F22 F43 F56 F60(billing) |
| 5 | 83b1099 | F60(REST) F62 F63 F09(auth-api) F48 F53 |
| 6 | 3a8b78c | F70 F71 F72 F73 F74 F77 F80 F83 |
| 7 | cd52012 | F09(admin) F75 F76 F78 F79 F81 |
| 8 | d9f3b4a | F55 F42 F54 F58 |
| **9** | **65fee63** | **F26 F88 F09-polish** |

**Open / known-gaps after sprint 9:**

- **F61** — MCP error `data` field. Deferred (SDK-version-fragile, needs monkey-patch).
- **F05** — mailer-delivery webhook lifecycle (queued → dispatched → delivered/bounced). Out of scope for sprint 9; companion to F88. Recommend a small follow-up sprint when iv decides which mailer provider's webhook to wire (SES / Postmark / SendGrid all expose one).
- **F06** — org-name DNS verification. Needs product decision.
- **F08-full** — top-level `error` as object refactor. Breaking change, needs explicit sign-off.

---

## References

- Server commit: `65fee63` — `git@github-inon95:95percent-ai/butt-dial.git`
- Server live URL: `https://call.95percent.ai`
- Server-side decision: `butt-dial/docs/DECISIONS.md` DEC-029
- Server-side spec: `butt-dial/docs/SPEC.md` (registration flow section)
- SDK accounts client: `src/buttdial/accounts.py`
- Original request: `docs/BD_SERVER_INSTRUCTIONS_onboarding.md` (v1.1)
