<!-- version: 1.0 | updated: 2026-04-28 -->

# Butt-Dial Server — API & Contract Review

**To:** Butt-Dial server team
**From:** SDK side review (using `butt-dial-sdk` as a client-side validator)
**Date generated:** 2026-04-28
**SDK version:** 0.3.0 (`github.com/elradts/butt-dial-sdk`)
**Server probed:** `https://call.95percent.ai`
**MCP server reported:** `butt-dial-mcp v0.1.0` / protocolVersion `2025-11-25`

## What this is

The Butt-Dial SDK is being prepared for use by **agentic systems** (LLM-driven agents that integrate with the Butt-Dial server). This review walks the SDK end-to-end against the live server and surfaces every place the contract is unclear, unsafe, inconsistent, or unfriendly to a non-human consumer.

The findings below are not (mostly) SDK bugs to be patched silently. They are signals the SDK has surfaced about server-side rough edges that should be smoothed before the SDK ships to agentic consumers, who cannot debug subtle inconsistencies the way human developers can.

## How findings were obtained

1. SDK code review — read every endpoint path, request body shape, and expected response in `src/buttdial/`, plus the SDK's typed-error machinery in `src/buttdial/accounts.py`.
2. Live unauth probes — curl against every public route to enumerate behavior without credentials.
3. Live auth probes — registered an org (`28bf35dd-995f-46ac-96da-1f99ac9d9b52`) with email `inon@elradts.com`, completed verify, then probed every authenticated endpoint with the resulting `team_token`.
4. MCP probe — opened an authenticated SSE session against `/sse`, ran `initialize` + `list_tools`, captured the full tool surface (44 tools).

Reproducer commands are in the [Appendix](#appendix-reproducers) — every finding can be re-checked from a terminal.

## How to read this document

Each finding has:

- **ID** — stable identifier (`F01`, `F02`, …) for tracking. Don't renumber when items are fixed; mark status instead.
- **Severity** — `CRITICAL` / `HIGH` / `MEDIUM` / `LOW`.
- **Status** — `open` initially. Server team flips to `in-progress` / `fixed`. SDK side flips to `verified` after re-probe.
- **Observed** — what we saw on the live server.
- **Why it matters** — especially for agentic-system consumers.
- **Recommended fix** — concrete server-side change.

Severity rubric:

| Label | Meaning |
|---|---|
| CRITICAL | Security issue, data integrity, or production-broken contract. Fix before any agentic-system rollout. |
| HIGH | SDK contract silently broken, or abuse vector exists. Fix in the next sprint. |
| MEDIUM | Friction, inconsistency, but workable today. Fix opportunistically. |
| LOW | Nits, cosmetic, hygiene. Fix when touching adjacent code. |

## TL;DR — top 5

The single highest-leverage thing the server team can do this week is **F09 (add a `code` field to every error response)** — that one change brings the SDK's entire typed-error system online for free.

Beyond that, the most impactful items:

1. **F01** [CRITICAL] — `register` does not dedup by email; creates duplicate orgs every call. Three orgs now exist for `inon@elradts.com`.
2. **F02** [CRITICAL] — No rate limiting on `register`. Anyone can flood any inbox with verification emails.
3. **F03** [CRITICAL] — Verification token is in URL query string, consumed on GET, very likely being burned by Gmail/Outlook link prefetchers before the human can click.
4. **F09** [HIGH] — Server emits `{"error": "string"}` with no `code` field on most endpoints. SDK's typed-error machinery (8 classes, fully wired) is dead code as a result.
5. **F11** [HIGH] — Server is internally inconsistent on casing within `/api/v1/*`: `POST /agents` wants `agent_id` (snake), `POST /provision` wants `agentName` (camel). Plus `verify` hedges by emitting all 3 variants. There's no contract; there's compatibility scaffolding.

---

## A. Critical contract & security

### F01 [CRITICAL] [open] — `POST /api/orgs/register` does not deduplicate by email

**Observed.** Calling `register` three times with `ownerEmail=inon@elradts.com` (one with org name `__sdk_probe__`, two with `elradts`) created **three separate orgs**: `646bbace-0a01-45d6-b571-137b54413a66`, `b5d31db6-394c-41bc-8d2a-972f7d152264`, `28bf35dd-995f-46ac-96da-1f99ac9d9b52`. No dedup, no error.

**Why it matters.** SDK has a typed `EmailAlreadyRegistered` exception (`accounts.py:111`) and the docstring on `register()` (line 265) promises it will be raised. It currently never fires. Hosts that wrote `except EmailAlreadyRegistered: show_signin_ui()` will silently never reach that branch. For agents, this becomes "I retried after a transient error and now I have two organizations, which one is mine?"

**Recommended fix.**
- If `ownerEmail` already has a verified org → return `{"error": "...", "code": "EMAIL_ALREADY_REGISTERED"}` (HTTP 409). Optionally email a sign-in link to the address (Slack pattern).
- If `ownerEmail` already has an unverified org → reuse the existing `orgId`, reissue a fresh verification token, return the same response shape as a fresh registration. Idempotent from the host's perspective.

### F02 [CRITICAL] [open] — No rate-limit on registration; spam vector

**Observed.** Two real verification emails were sent to `inon@elradts.com` from the same IP within ~5 minutes with no friction (no CAPTCHA, no proof-of-work, no throttle).

**Why it matters.** Anyone can write a 3-line script to flood `victim@somecorp.com` with verification emails until the inbox is unusable, the BD sending domain is reputation-blacklisted, or both.

**Recommended fix.**
- Per-source-IP rate limit (e.g. 5 register calls / minute, 50 / hour).
- Per-destination-email rate limit (e.g. 3 verification emails / hour / email).
- hCaptcha or proof-of-work for unauthenticated `register` calls from new IPs.
- Pair with F01 fix: if email has unverified org and a recent token was already sent, refuse to send a new one until the rate-limit cool-down.

### F03 [CRITICAL] [open] — Verification token in URL query string, consumed on GET → prefetcher-burn risk

**Observed.** Email link is `https://call.95percent.ai/api/orgs/verify?token=...`. The route handles **both GET (HTML response) and POST (JSON response)**, and the GET path appears to consume the token on first hit. First test token expired before the human could click, despite a 15-minute documented TTL — strong evidence that Gmail's link scanner / Outlook Safe Links / corporate email gateways pre-fetched the URL and consumed it.

**Why it matters.**
- Token persistence: lands in user's email message body forever, browser history, server access logs (nginx logs queries by default), referrer headers from any external resource on the verification page.
- Prefetcher consumption: in practice, business inboxes (Microsoft 365, Google Workspace) almost always have a security gateway that GETs URLs in inbound email. If the server consumes the token on GET, **the user can never verify** — every token is burned before they click.
- For agentic systems: the agent gets `verificationSent: true` from register, the human attempts to verify, fails because of prefetch, the agent has no signal, and the human has to start over.

**Recommended fix (preferred).**
- Email link goes to `https://call.95percent.ai/verify` (no token in URL).
- Token is delivered via URL fragment: `https://call.95percent.ai/verify#token=...`. Fragments are *not* sent to servers and *not* logged. Prefetchers see only `/verify`.
- Landing page reads `location.hash`, POSTs `{token}` to `/api/orgs/verify`, then `history.replaceState(null, '', location.pathname)` to clear the fragment.

**Alternative.** Keep `?token=` but make GET render a "Click to verify" page that requires a real button click. The button POSTs the token. Prefetchers don't click buttons.

### F04 [CRITICAL] [open] — Email-existence enumeration oracle

**Observed.** Latent — currently no distinct response for new vs existing email (because of F01), but the SDK's `EmailAlreadyRegistered` class implies the server intends to add one. If implemented naively, becomes an enumeration oracle.

**Why it matters.** Attacker probes "is `target@victimcorp.com` an existing customer?" by registering with that email and reading the response. Lets an attacker enumerate the customer base.

**Recommended fix.** Same response (`{"verificationSent": true}`) regardless of new vs existing email. Differentiate behavior in email content: new email → verification link, existing email → "you already have an org, here's a sign-in link." This is the Slack/Stripe/Notion pattern.

### F05 [CRITICAL] [open] — `verificationSent: true` is synchronous optimism, not delivery confirmation

**Observed.** Server returns `verificationSent: true` synchronously on register. In one test, the email took >1 minute to actually arrive (or possibly didn't, until a later attempt). There's no way to tell queued / dispatched / delivered / bounced / spam-foldered apart.

**Why it matters.** For an agentic system: the agent gets `verificationSent: true`, tells its caller "check your inbox", and there's nothing to check. No way to retry, escalate, or diagnose.

**Recommended fix.**
- Wire your mailer's webhooks (SES, Postmark, SendGrid all expose them) into the BD server, update org record with delivery state.
- Replace boolean with `mail: {state: "queued"|"dispatched"|"delivered"|"bounced"|"spam_complaint"|"unknown"}`.
- Expose `GET /api/orgs/{orgId}/verification-status` (rate-limited) so a host or agent can poll for the real state.
- Set up DKIM + SPF + DMARC on the sending domain so first-time-sender mail to Gmail/M365 doesn't land in spam.

### F06 [CRITICAL] [open] — Org-name squatting / phishing surface

**Observed.** Nothing prevents `orgName: "Microsoft"`, `orgName: "Stripe Inc"`, etc. The slug is server-generated (`elradts-211f` for our org — good), but `name` is whatever the registrant supplies.

**Why it matters.** If `orgName` ever appears in user-facing surfaces (transactional emails, OAuth consent screens, invoices, support chats), it's a phishing kit waiting to happen. "Microsoft Support" sending "from Butt-Dial".

**Recommended fix.**
- Treat `orgName` as a display-only string; never use it as a unique handle, URL component, or sender name.
- For enterprise tier: optional DNS-based domain verification (TXT record proof) to claim exclusivity over an email domain. Display a verified badge.

---

## B. Error contract gaps

### F07 [HIGH] [open] — Most error responses lack a `code` field

**Observed.**

| Endpoint | Error response shape | Has `code`? |
|---|---|---|
| `POST /api/orgs/register` (empty body) | `{"error":"orgName and ownerEmail are required"}` | no |
| `POST /api/orgs/verify` (expired token) | `{"error":"Token has expired"}` | no |
| `POST /api/v1/agents` (empty body) | `{"error":"agent_id is required (host-supplied UUID)."}` | no |
| `POST /api/v1/provision` (empty body) | `{"error":"Missing required field 'agentName'..."}` | no |
| `GET /api/v1/agents/me` (no agent) | `{"error":"Agent \"<orgId>\" is not provisioned."}` | no |
| `GET /api/v1/agents/{id}` (not found) | `{"error":"Agent \"...\" not found in this org."}` | no |
| `GET /api/v1/usage` (wrong token type) | `{"error":"Use your client token, not the org API key..."}` | no |
| `POST /api/orgs/me/phone/set` (bad phone) | `{"error":"phone must be E.164 format (...)", "code":"PHONE_INVALID"}` | **YES** |

**Why it matters.** The SDK has a complete typed-error system (`accounts.py:111-178`):

```python
_ERROR_BY_CODE = {
    "EMAIL_ALREADY_REGISTERED": EmailAlreadyRegistered,
    "VERIFICATION_TOKEN_EXPIRED": VerificationTokenExpired,
    "PHONE_NOT_CONFIGURED": PhoneNotConfigured,
    "OTP_INVALID": OTPInvalid,
    "OTP_EXPIRED": OTPExpired,
    "OTP_MAX_ATTEMPTS": OTPMaxAttempts,
    "CHALLENGE_NOT_FOUND": ChallengeNotFound,
    "TOKEN_REVOKED": TokenRevoked,
}
```

The SDK looks up the exception class by `body["code"]` (line 184). Currently `code = ""` for almost every error response → falls through to generic `AccountsError`. **The entire typed-error machinery is dead code on the live server**, except for `PHONE_INVALID`.

For agentic systems: agents need to branch on stable codes, not natural-language `error` strings (which can change with no migration path). Today an agent has to regex-match on the message to recover a code.

**Recommended fix.** Apply the `code` field consistently — the pattern is already implemented for `PHONE_INVALID`, just propagate. Suggested code names matching the SDK's expectations:

- `EMAIL_ALREADY_REGISTERED` (409 on register with verified email)
- `VERIFICATION_TOKEN_EXPIRED` (400 on verify with expired token)
- `VERIFICATION_TOKEN_INVALID` (400 on verify with unknown/burned token)
- `MISSING_FIELDS` with `fields: ["agent_id"]` (400)
- `AGENT_NOT_FOUND` / `AGENT_NOT_PROVISIONED` / `NO_AGENT_FOR_ORG` (404)
- `WRONG_TOKEN_TYPE` (400 on `/usage` with team_token instead of agent_token)
- `OTP_INVALID`, `OTP_EXPIRED`, `OTP_MAX_ATTEMPTS`, `CHALLENGE_NOT_FOUND`, `TOKEN_REVOKED`, `PHONE_NOT_CONFIGURED`

### F08 [HIGH] [open] — Error envelope shape is inconsistent

**Observed.** Three different shapes seen:

```json
{"error": "string"}
{"error": "string", "code": "STABLE_CODE"}
{"error": "Missing required field 'agentName'. Provide a human-readable name for the client.\n\nExample: { \"agentName\": \"Support Bot\", \"capabilities\": { \"phone\": true, \"voiceAi\": true } }"}
```

**Why it matters.** Agents and SDKs need a stable envelope. The third form has embedded JSON examples in the message string, which is friendly to a human reading curl output but useless to a machine. (And an LLM will hallucinate that the example is part of the contract.)

**Recommended fix.** Standardize on one envelope across all 4xx/5xx:

```json
{
  "error": {
    "code": "STABLE_MACHINE_CODE",
    "message": "Human-friendly description.",
    "fields": [{"name": "agentName", "issue": "missing"}],
    "retryable": false,
    "retryAfter": null,
    "docs": "https://docs.../errors/STABLE_MACHINE_CODE"
  }
}
```

Top-level `error` as object, not string. `retryable` lets agents decide whether to retry. `retryAfter` (seconds) for rate limits.

### F09 [HIGH] [open] — Verification-failed HTML page is a dead end

**Observed.** Email-link GET returns:

```html
<!DOCTYPE html><html><body style="font-family:system-ui;max-width:520px;margin:4rem auto;color:#eee;background:#111;">
<h1>Verification failed</h1><p>Token has expired</p>
</body></html>
```

No "Resend verification email" button. No "Go back to register". No support contact.

**Why it matters.** First-time user hits this and has no recovery action. Combined with F03 (prefetcher consumption), most users will see this page even when they click their link within seconds.

**Recommended fix.** Add a "Resend verification email" button on the failed-verify page that POSTs to a new `/api/orgs/{orgId}/resend-verification` endpoint (rate-limited). Token / orgId can come from the URL fragment.

---

## C. Casing & naming

### F10 [HIGH] [open] — Casing varies across endpoints in both directions

**Observed.**

| Endpoint | Request body | Response body |
|---|---|---|
| `POST /api/orgs/register` | camel (`orgName`, `ownerEmail`) | camel only (`orgId`, `verificationSent`) |
| `POST /api/orgs/verify` | snake (`token`) | **all three: camel + snake + alias** (`orgId` + `org_id`, `ownerToken` + `owner_token` + `team_token`) |
| `GET /api/orgs/me` | n/a | camel only (`orgId`, `ownerEmail`, `createdAt`, `mode`, `slug`, `status`) |
| `POST /api/v1/agents` | **snake** (`agent_id`) | unknown |
| `POST /api/v1/provision` | **camel** (`agentName`, `capabilities.phone`) | unknown |
| `POST /api/orgs/me/phone/set` | unknown — accepted `phone` but rejected with `PHONE_INVALID` | n/a |

This is **server-internal inconsistency**, not just SDK drift. Within the same `/api/v1/*` namespace, request bodies mix snake (`agent_id`) and camel (`agentName`, `capabilities.voiceAi`).

**Why it matters.** Hosts and agents must remember per-endpoint casing rules. SDK ships with a fictional snake_case-everywhere mock (the test fixtures pass) but real hosts get camelCase responses they have to handle. The triple-hedge in `verify` is a tell that the team knows about it but is papering over rather than choosing.

**Recommended fix.**
- Pick **camelCase** (4 of 5 already are; matches Express/JS server idiom; matches MCP protocol idiom).
- Migration: emit both for one minor version, log usage of the deprecated form, then remove. Use `Deprecation:` header (RFC 8594) to signal which keys are sunsetting.
- Update `POST /api/v1/agents` to accept `agentId` (and reject `agent_id` after the migration window).
- Drop the triple-hedge in `verify` to a single canonical name (camelCase).

### F11 [HIGH] [open] — At least 4 names for the per-agent runtime token

**Observed.**

| Surface | Name |
|---|---|
| Verification email body | "API key" |
| `POST /api/orgs/verify` response | `teamToken` + `team_token` + `ownerToken` + `owner_token` (all four for the same value) |
| `GET /api/v1/usage` 400 message | "client token" |
| SDK env var | `BUTT_DIAL_AGENT_TOKEN` |
| SDK internal | `team_token` (org admin) and `agent_token` (per-agent runtime) — these are *different* tokens |

A new user reads "API key" in the email, the SDK tells them `BUTT_DIAL_AGENT_TOKEN`, the server error tells them "client token". Same thing. Different names.

**Why it matters.** Agents reading documentation or error messages have to maintain a mental glossary. Hosts open support tickets confused about whether they should use their "API key" or their "owner token" or their "team token" or their "client token".

**Recommended fix.**
- Pick one canonical name. Recommendation: **`teamToken`** for org-admin scope, **`agentToken`** for per-agent runtime scope (these are two different tokens with different scopes; they need distinct names).
- Use *only* those names in: email copy, response fields, error messages, REST docs, MCP tool descriptions, support docs.
- The "API key" wording in the verification email is the most user-visible — fix that first.

### F12 [HIGH] [open] — `verify` response emits same data 3 times under different keys

**Observed.**

```json
{
  "orgId": "28bf35dd-...",
  "ownerToken": "5e95...",
  "scopes": "org-admin",
  "org_id": "28bf35dd-...",
  "owner_token": "5e95...",
  "team_token": "5e95..."
}
```

The same `orgId` value appears as both `orgId` and `org_id`. The same token appears as `ownerToken`, `owner_token`, and `team_token`.

**Why it matters.** Agents and hosts can't tell which key is canonical. SDK's `verify()` does a normalization (`if "owner_token" in resp and "team_token" not in resp: ...`) that's now pure no-op, but no one has noticed because the test fixtures use a different shape than the live server.

**Recommended fix.** Pick the canonical key per F11. Drop the others. Migrate via `Deprecation:` header.

### F13 [MEDIUM] [open] — SDK docstring claims `verify` returns `mode`; server returns `scopes`

**Observed.** SDK `accounts.py:276-277` docstring says `verify()` returns `{team_token, org_id, mode}`. Live server returns `{..., scopes: "org-admin"}` — no `mode` field. (`mode` does appear on `GET /api/orgs/me`, where it's `"sandbox"`.)

**Why it matters.** SDK was written from a spec that no longer matches reality. There's no source of truth a server dev can update once and have the SDK adopt automatically.

**Recommended fix.** Publish a versioned API contract — OpenAPI 3.1 spec at `/openapi.json` (see F18). SDK can consume it for code-gen and validation.

---

## D. Lifecycle & resource hygiene

### F14 [HIGH] [open] — Unverified orgs persist forever

**Observed.** Three orgs created in this session, two of them unverified (`646bbace-…`, `b5d31db6-…`). No TTL — they will live in the DB indefinitely.

**Why it matters.** Probe traffic, typos, and abandoned signups accumulate forever. Combined with F02 (no rate limit), this is unbounded DB growth.

**Recommended fix.** TTL of 24h on unverified orgs. Background job deletes expired records.

### F15 [HIGH] [open] — No org-delete endpoint

**Observed.** Once an org exists, there's no public API to delete it. SDK has no delete method either.

**Why it matters.**
- Operationally: the orphan orgs from this session can't be cleaned up by the SDK side.
- For users: an abandoned org or a typo-org has no recovery path until F14's TTL kicks in.

**Recommended fix.** `DELETE /api/orgs/{orgId}` (auth via `teamToken`, requires phone confirmation if F46 is implemented). Or `DELETE /api/orgs/me` for the current org.

### F16 [MEDIUM] [open] — No "list orgs I own" endpoint

**Observed.** Owner with same email + multiple orgs has no way to list them.

**Why it matters.** Combined with F01, an owner can end up with multiple orgs they didn't realize they created (e.g. retried registration during a transient error).

**Recommended fix.** `GET /api/users/me/orgs` returning all orgs whose ownerEmail matches the authenticated user.

### F17 [MEDIUM] [open] — No verification-status query endpoint

**Observed.** After `register`, host has no way to ask "did the user click yet? what's the state?"

**Why it matters.** Agents can't complete onboarding without polling — and there's nothing to poll. They have to wait for an out-of-band signal (the host calling `verify` from the email-click handler).

**Recommended fix.** `GET /api/orgs/{orgId}/verification-status` (rate-limited) returning `{state: "pending"|"verified"|"expired", mailDeliveryState: "queued"|"delivered"|"bounced"|...}`.

### F18 [MEDIUM] [open] — No resend-verification-email endpoint

**Observed.** Once the verification email is lost / spam-foldered / its token expires, the only recovery is registering again — which (per F01) creates a duplicate org.

**Why it matters.** Real users hit this. Bounce + resend is a normal SaaS flow.

**Recommended fix.** `POST /api/orgs/{orgId}/resend-verification`, rate-limited (e.g. 1 per minute, 5 per hour per orgId), invalidates any prior outstanding token, issues a fresh one.

---

## E. Discoverability & observability

### F19 [HIGH] [open] — No `/healthz` or equivalent

**Observed.** `GET /healthz` → 404. The server exposes no liveness/readiness endpoint we found.

**Why it matters.** SDK doctor's stage 2 ("server reachable") wants this. Operations teams want this for monitoring. Load balancers and Kubernetes want this.

**Recommended fix.** `GET /healthz` returning `{"status": "ok", "uptime": ..., "version": "..."}`. Cheap; standard.

### F20 [HIGH] [open] — No `/version` or `/openapi.json`

**Observed.** Both 404. The only doc surface we found is `/docs` (HTML).

**Why it matters.** SDK can't detect when it's running against a server it wasn't built for. Agents can't introspect the API contract. Without OpenAPI, the SDK has to be hand-written and drift is invisible until production.

**Recommended fix.**
- `GET /version` returning `{"apiVersion": "1.x", "serverCommit": "...", "buildTime": "..."}`.
- `GET /openapi.json` returning the full OpenAPI 3.1 spec. Most server frameworks (FastAPI, NestJS, Hono, Fastify) emit this automatically with light annotation.

### F21 [MEDIUM] [open] — MCP `serverInfo.version` stuck at `0.1.0`

**Observed.** MCP `initialize` returns `serverInfo: {name: "butt-dial-mcp", version: "0.1.0"}`. SDK is at v0.3.0; the SDK has had multiple releases against this server. Server version field has not bumped.

**Why it matters.** This is the only programmatic version signal an MCP-consuming agent gets. If it never changes, agents can't detect contract evolution. They keep calling tools with the old assumed shape until something silently breaks.

**Recommended fix.** Bump `serverInfo.version` on every breaking change (or every release). Adopt SemVer for the MCP layer specifically.

---

## F. Auth contract

### F22 [HIGH] [open] — SSE handshake opens unauthenticated; `/messages` POSTs 401

**Observed.** `GET /sse` accepts the connection without any auth header and returns `event: endpoint` with a fresh `sessionId`. The first `POST /messages?sessionId=...` then 401s.

**Why it matters.** An MCP client thinks it connected, then dies silently 100ms later. For agents that retry on transient failures, this looks like a flaky network rather than an auth misconfiguration. The SSE handshake is *lying* about connectivity.

**Recommended fix.** Refuse the SSE handshake itself with 401 if no/invalid Bearer header is present. Don't allocate a sessionId for unauthenticated callers.

### F23 [MEDIUM] [open] — Confirm `AUTH_*` codes are emitted on 401 / 429

**Observed.** SDK's `errors.py` decodes `AUTH_INVALID_TOKEN`, `AUTH_TOKEN_REVOKED`, `AUTH_LOCKED_OUT`, `AUTH_MISSING_HEADER` from 401/429 responses. We didn't reach a path that exercises these. (Need to send a known-bad / revoked token to confirm.)

**Why it matters.** SDK has typed handling for these. If the server returns generic 401 with no `code`, the typed-error path silently degrades.

**Recommended fix.** Server team: confirm these are emitted with the documented code names. If not, add them. Same fix as F09.

### F24 [MEDIUM] [open] — No documented token-revocation flow

**Observed.** SDK has rotation via `rotate_token_request` + `rotate_token_confirm`. No emergency-revoke endpoint visible — i.e. "this token leaked, kill it now without the OTP dance".

**Why it matters.** Token leaks happen (chat history, log capture, env var dumped to a public PR). Recovery needs to be possible without coordinating an OTP from the admin's phone.

**Recommended fix.** `POST /api/orgs/me/tokens/revoke` (auth via the token itself, single use, no OTP required). Or accept revocation via a verified backup channel.

---

## G. Agent ergonomics

### F25 [CRITICAL] [open] — No idempotency on mutating endpoints

**Observed.** `POST /api/orgs/register` is not idempotent (F01). `POST /api/v1/agents`, `POST /api/v1/provision`, `POST /api/orgs/me/phone/set` — none accept an idempotency key.

**Why it matters.** Agents retry on transient errors. Without idempotency, every network blip can corrupt state (duplicate orgs, duplicate agents, duplicate provisioning charges, duplicate OTP sends).

**Recommended fix.**
- Accept `Idempotency-Key: <client-supplied-uuid>` header on every mutating endpoint.
- Server stores `(idempotency-key → response)` for ≥24h.
- Same key + same body within window → return cached response.
- Same key + different body within window → 409 Conflict.

### F26 [HIGH] [open] — No verification-completion webhook

**Observed.** Email verification is a human-in-the-loop step. After `register`, the host has to wait for the human to click. There's no way for the server to push a "verification completed" event back to the host's webhook URL.

**Why it matters.** Agentic onboarding can't be programmatic without polling (F17) or webhooks. Polling is wasteful and the agent has no idea when to stop.

**Recommended fix.** Accept `notifyUrl` parameter on `POST /api/orgs/register`. On verify, POST `{orgId, teamToken, verifiedAt}` to `notifyUrl` with HMAC signature.

### F27 [HIGH] [open] — Lifecycle states aren't explicit

**Observed.** `GET /api/orgs/me` returns `status: "active"` but the SDK has multiple lifecycle exceptions (`PhoneNotConfigured`, etc.) suggesting onboarding has substates: registered → email-verified → phone-set → phone-confirmed → agent-registered → channels-provisioned → production. None of these are observable as a single field.

**Why it matters.** An agent that wants to self-diagnose "where am I in onboarding?" has to call 4-5 endpoints and reason about 401/404/200 distinctions. That's brittle.

**Recommended fix.** Add explicit `lifecycleState` field on `/api/orgs/me` and `/api/v1/agents/me` with a documented enum:

```
org.lifecycleState ∈ {"unverified", "verified", "phone_pending", "phone_confirmed", "ready", "suspended"}
agent.lifecycleState ∈ {"draft", "registered", "provisioning", "provisioned", "suspended", "deregistered"}
```

### F28 [MEDIUM] [open] — `agents/me` confuses orgId with agent_id

**Observed.** `GET /api/v1/agents/me` with no agent registered returns `{"error":"Agent \"28bf35dd-995f-46ac-96da-1f99ac9d9b52\" is not provisioned."}`. The UUID in the message is the **orgId**, not an agent_id.

**Why it matters.** Misleading error during onboarding debugging. Suggests internal confusion between org and agent identity.

**Recommended fix.** When no agent is registered yet for an org, return `{"error": "No agent is registered for this org. POST /api/v1/agents to register one.", "code": "NO_AGENT_FOR_ORG"}` (404).

### F29 [MEDIUM] [open] — Two semantic vocabularies for "agent missing"

**Observed.** `/api/v1/agents/me` says "is not provisioned"; `/api/v1/agents/{id}` says "not found in this org". Same situation, different wording, no `code`.

**Why it matters.** Agents have to handle both wordings if they ever string-match (which they shouldn't, but they do because of F07). Consolidating to one code (`AGENT_NOT_FOUND` or `NO_AGENT_FOR_ORG`) makes the contract simpler.

**Recommended fix.** Pick one. Consider distinguishing: `AGENT_NOT_FOUND` (the requested agent_id doesn't exist for this org) vs `NO_AGENT_FOR_ORG` (no agent registered yet, called `agents/me`).

### F30 [MEDIUM] [open] — MCP tool descriptions audit for agent-readability

**Observed.** Server exposes 44 MCP tools, all prefixed `comms_`. The `description` field of each tool is what an LLM agent reads to decide how to call it. We didn't audit each one.

**Why it matters.** For agentic systems, tool descriptions ARE the API surface. A tool with an ambiguous description leads to an agent calling it wrong, or not calling it when it should.

**Recommended fix.** Server team review for every tool:
- `description` is a single, declarative sentence.
- Parameters have clear types, examples, and constraints.
- Failure modes documented inline ("returns code=`RECIPIENT_INVALID` if `to` is not E.164").
- Inputs and outputs use a consistent vocabulary.

### F31 [MEDIUM] [open] — No rate-limit headers on responses

**Observed.** No `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` headers (also no `RateLimit-*` per IETF draft).

**Why it matters.** Agents need to know when they're approaching a limit so they can back off proactively, not just react to 429s.

**Recommended fix.** Add IETF-draft `RateLimit-Limit` / `RateLimit-Remaining` / `RateLimit-Reset` headers on every response. Add `Retry-After` on 429 responses.

### F32 [MEDIUM] [open] — No retryable/permanent distinction in error envelopes

**Observed.** Today every 4xx looks the same to a client — agents can't tell whether to retry, back off, or give up.

**Why it matters.** Agents that retry blindly hammer the server. Agents that don't retry give up on transient failures.

**Recommended fix.** Include `retryable: bool` and `retryAfter: int|null` in every error envelope (per F08).

### F33 [MEDIUM] [open] — No deprecation contract

**Observed.** `verify` response includes legacy `owner_token` alongside `team_token` (and now also `ownerToken` and `teamToken`). The migration is happening silently in the response body.

**Why it matters.** Hosts and agents can't see deprecation coming. No log warnings; no alerts; just "one day my code stops working."

**Recommended fix.** RFC 8594 `Deprecation:` and `Sunset:` HTTP headers on responses that emit legacy field names. SDK can log a one-time warning. Plus a `/deprecations` doc page listing what's sunsetting and when.

### F34 [MEDIUM] [open] — No webhook for lifecycle state changes

**Observed.** SDK has an inbound handler (`buttdial.inbound`) for messages and delivery receipts. No equivalent for org/agent state changes (token rotated, phone reconfirmed, channel suspended, agent deregistered).

**Why it matters.** Long-running agents need to learn about state changes via push, not poll. Without lifecycle webhooks, an agent's view of its own state can be silently stale.

**Recommended fix.** Extend the inbound webhook to include lifecycle events: `org.suspended`, `agent.token_rotated`, `agent.deregistered`, `channel.suspended`, etc.

---

## H. SDK roadmap (out of server team scope, but relevant)

### F35 [INFO] — SDK exposes 2 of 44 server MCP tools

**Observed.** SDK uses `comms_send_message` and `comms_whatsapp_action`. Server exposes 42 more (voice, OTP, trust, consent, sessions, lifecycle, profile, TTS, etc.).

**Why it matters.** For agentic systems, the SDK is the layer agents talk to. If the SDK doesn't surface a capability, agents can't use it (without dropping into raw MCP).

**Recommended action (SDK side, not server).** Either roadmap typed methods for the missing tools, or expose `Agent.call_tool(name, args)` as a raw escape so agents aren't gated by SDK release cadence.

### F36 [INFO] — Two surfaces for the same operation (REST + MCP)

**Observed.** Provisioning exists as both `POST /api/v1/provision` (REST, team_token) and `comms_provision_channels` (MCP tool, agent_token presumably).

**Why it matters.** Two implementations to keep in sync. Will drift. SDK uses REST for this; agents using the MCP layer would use the tool. Inconsistent behavior between the two is a near-certainty.

**Recommended fix.** Pick one canonical surface. Expose the other as a thin proxy that delegates internally.

---

## I. Cosmetic / nits

### F37 [LOW] [open] — `createdAt` is non-ISO 8601

**Observed.** `GET /api/orgs/me` returns `"createdAt": "2026-04-28 13:24:07"` — space-separated, no `T`, no timezone.

**Why it matters.** RFC 3339 / ISO 8601 is `"2026-04-28T13:24:07Z"`. Modern Python and JS handle either, but Go's `time.Parse(time.RFC3339, ...)` and many other parsers don't. Cheap to fix; saves future grief.

**Recommended fix.** Always emit `YYYY-MM-DDTHH:MM:SS.sssZ` (UTC) for timestamps.

### F38 [LOW] [open] — Possible PII in error message example

**Observed.** `POST /api/orgs/me/phone/set` with bad phone returns `"phone must be E.164 format (e.g. +972526557547)"`. That's an Israeli mobile number, possibly a real one belonging to a developer.

**Why it matters.** If it's a real number, it's PII leaking from production error responses. If it's a placeholder, it's at minimum confusing.

**Recommended fix.** Use a documented test range: `+15555550123` (NANP, non-routable) or `+12025550100` (US +1-202-555-01XX, reserved for fiction). Document this convention internally.

### F39 [LOW] [open] — Redundant `success: true` on provision response (per SDK fixture)

**Observed.** SDK test fixture for `provision` shows `{"success": true, "agentId": "x", "token": "t", "channels": {}}`. Not yet verified against live server.

**Why it matters.** HTTP 2xx already means success. A `success: true` field invites the question "what does `success: false` with HTTP 200 mean?" — and is a footgun if the answer is ever "the request succeeded HTTP-wise but the operation failed".

**Recommended fix.** If server emits this, drop it. Use HTTP status for success/failure; use `error.code` for failure reasons.

### F40 [LOW] [open] — MCP `comms_` prefix on every tool

**Observed.** All 44 MCP tools start with `comms_`. The MCP server's name is already `butt-dial-mcp` — namespacing is implicit.

**Why it matters.** An LLM agent reading 44 tool descriptions sees `comms_` 44 times. Wastes attention. Marginally inflates token usage.

**Recommended fix.** Drop the prefix, or split into multiple sub-namespaces (`messaging.send`, `voice.make_call`) if you do want grouping.

---

## Cleanup requests

| What | Why |
|---|---|
| Delete orphan org `646bbace-0a01-45d6-b571-137b54413a66` | Created during probing with fake `.invalid` email; will never verify; can't be deleted via public API (F15) |
| Delete orphan org `b5d31db6-394c-41bc-8d2a-972f7d152264` | Created during real probe; expired token (probably prefetcher-burned, F03); replaced by `28bf35dd-…` |
| Optional: rotate the `team_token` on `28bf35dd-995f-46ac-96da-1f99ac9d9b52` | Token leaked into our chat history during diagnostic work. Low blast radius (chat is private), but hygienic to rotate after this review wraps |

---

## What we'd like to verify next (with explicit go-ahead)

These would mutate state and so haven't been called yet. Listed in case the server team wants to hand-craft test responses, or in case a sandbox env becomes available:

1. `POST /api/v1/agents` with valid body → confirm response shape (do request and response casings match? Is there a `code` field on errors?)
2. `POST /api/v1/provision` with valid body → confirm shape and the channel-allocation contract; verify F39 about `success: true`
3. `POST /api/orgs/me/phone/set` followed by `confirm` → confirm OTP flow, error codes (`OTP_INVALID`, `OTP_EXPIRED`, `OTP_MAX_ATTEMPTS`)
4. `POST /api/orgs/me/rotate-token/request` + `confirm` → confirm rotation flow and `TOKEN_REVOKED` emission on the old token
5. Authenticated MCP tool calls (`comms_send_message`, `comms_ping`, `comms_get_channel_status`) → confirm MCP-side contract (tool argument shapes, error shapes, response shapes)
6. Hit an endpoint with a deliberately revoked / invalid token → confirm `AUTH_*` codes per F23
7. Hit `register` with an *already-verified* email → confirm whether a different code path exists (related to F01 fix)

---

## Status tracking

When the server team fixes an item, please update its `[open]` to `[in-progress]` or `[fixed]` (with a commit/PR link). The SDK side will flip to `[verified]` after re-probing.

```
[open]         — not yet acknowledged or worked on
[in-progress]  — server team is on it
[fixed]        — server change deployed; awaiting SDK verification
[verified]     — SDK side has re-probed and the fix matches expectations
[wontfix]      — server team has decided not to address; SDK will work around
```

---

## Appendix — reproducers

All commands assume `bash` and `curl` available; substitute `$TOK` with the org's `teamToken` from `verify`.

### Setup

```bash
# Register an org
curl -sS -X POST https://call.95percent.ai/api/orgs/register \
  -H "Content-Type: application/json" \
  -d '{"orgName":"<name>","ownerEmail":"<email>"}'
# → {"orgId":"...","verificationSent":true}
# Click email link, then:
curl -sS -X POST https://call.95percent.ai/api/orgs/verify \
  -H "Content-Type: application/json" \
  -d '{"token":"<token-from-email-link>"}'
# → {"orgId":"...","ownerToken":"...","scopes":"org-admin","org_id":"...","owner_token":"...","team_token":"..."}
TOK="<team_token from above>"
```

### F01 — duplicate org creation

```bash
# Run this twice with same email; observe two different orgIds returned
curl -sS -X POST https://call.95percent.ai/api/orgs/register -H 'Content-Type: application/json' -d '{"orgName":"x","ownerEmail":"same@example.com"}'
curl -sS -X POST https://call.95percent.ai/api/orgs/register -H 'Content-Type: application/json' -d '{"orgName":"x","ownerEmail":"same@example.com"}'
```

### F02 — no rate limit

```bash
# Five register calls in quick succession; observe none are throttled
for i in 1 2 3 4 5; do
  curl -sS -X POST https://call.95percent.ai/api/orgs/register -H 'Content-Type: application/json' \
    -d "{\"orgName\":\"probe$i\",\"ownerEmail\":\"probe$i@example.com\"}"
  echo
done
```

### F03 — verify GET vs POST behavior

```bash
# GET path (HTML response, what email link uses)
curl -sSI 'https://call.95percent.ai/api/orgs/verify?token=any'
# POST path (JSON response, what SDK uses)
curl -sS -X POST https://call.95percent.ai/api/orgs/verify -H 'Content-Type: application/json' -d '{"token":"any"}'
```

### F07 / F08 — error envelope inspection

```bash
curl -sS -X POST https://call.95percent.ai/api/orgs/register -H 'Content-Type: application/json' -d '{}'
# {"error":"orgName and ownerEmail are required"}    ← no code
curl -sS -X POST "https://call.95percent.ai/api/orgs/me/phone/set" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{"phone":"not-e164"}'
# {"error":"phone must be E.164 format (e.g. ...)","code":"PHONE_INVALID"}    ← has code
```

### F10 — casing inspection

```bash
# camelCase response
curl -sS https://call.95percent.ai/api/orgs/me -H "Authorization: Bearer $TOK"
# triple-hedged response
curl -sS -X POST https://call.95percent.ai/api/orgs/verify -H 'Content-Type: application/json' -d '{"token":"<live token>"}'
# snake_case request body required
curl -sS -X POST https://call.95percent.ai/api/v1/agents -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{}'
# {"error":"agent_id is required (host-supplied UUID)."}
# camelCase request body required
curl -sS -X POST https://call.95percent.ai/api/v1/provision -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{}'
# {"error":"Missing required field 'agentName'..."}
```

### F19 / F20 — discoverability

```bash
curl -sSI https://call.95percent.ai/healthz       # 404
curl -sSI https://call.95percent.ai/version       # 404
curl -sSI https://call.95percent.ai/openapi.json  # 404
```

### F22 — SSE handshake auth asymmetry

```bash
# Open SSE without auth — succeeds, returns endpoint event
timeout 3 curl -sSN https://call.95percent.ai/sse 2>&1 | head -5
# event: endpoint
# data: /messages?sessionId=<uuid>
# Then any POST to /messages?sessionId=... with no Bearer → 401
```

### F28 / F29 — agent-not-found wording

```bash
curl -sS https://call.95percent.ai/api/v1/agents/me -H "Authorization: Bearer $TOK"
# {"error":"Agent \"<orgId>\" is not provisioned."}    ← orgId, not agent_id
curl -sS https://call.95percent.ai/api/v1/agents/00000000-0000-0000-0000-000000000000 -H "Authorization: Bearer $TOK"
# {"error":"Agent \"...\" not found in this org."}
```

### MCP tool surface (F21)

```bash
# Run scripts/probe_live.py (in this repo) with BD_TEAM_TOKEN env set
BD_TEAM_TOKEN="$TOK" python scripts/probe_live.py
# Prints serverInfo and full list of 44 tool names
```

---

*This document is a living artifact. As the server team addresses items, status will be updated. As the SDK side mines further, new findings will be appended (F41, F42, …) without renumbering.*
