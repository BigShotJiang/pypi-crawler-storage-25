<!-- version: 1.3 | updated: 2026-04-25 -->

# Decisions

## 2026-04-21 — Separate repo, not in-repo package
**What:** butt-dial-sdk is a standalone git repository at `C:\Users\inon\Documents\work\butt-dial-sdk\`, developed alongside iv-bknd via editable install.
**Why:** Open-source story requires clean boundaries — own versioning, README, issues, release cadence. iv-bknd becomes the *reference consumer*, not the host. Third parties install from PyPI without ever seeing iv-bknd.
**Alternatives:** In-repo `packages/buttdial/` (muddies OSS story); hybrid in-repo-then-split (postpones the hard boundary work).

## 2026-04-21 — MIT license
**What:** MIT.
**Why:** Most permissive, standard OSS default, no friction for commercial adoption.

## 2026-04-21 — Package name `butt-dial-sdk`
**What:** PyPI name `butt-dial-sdk`, Python import `buttdial`, CLI entry point `buttdial`.
**Why:** PyPI prefers lowercase + hyphens; Python imports can't have hyphens. `-sdk` suffix signals this is the client library, distinct from any future server package.

## 2026-04-21 — Scope boundary: agent identity stays in iv-bknd
**What:** iv-bknd's `agent_leaders.butt_dial_client_id` / `butt_dial_client_token` columns stay in iv-bknd. The SDK consumes a token at runtime; it does not own agent identity storage.
**Why:** Agent identity is a host-app concern. Embedding it would force every consumer to adopt iv-bknd's data model. SDK stays focused on protocol + resilience + diagnostic layers.

## 2026-04-21 — SDK is stateless; host owns the database (reversed from v1.0)
**What:** The SDK does not ship migrations, does not open DB connections, does not import any ORM. It defines two protocols — `FailedMessageRepository` and `AgentDirectory` — and the host implements them against its own DB.
**Why:** Developer framed the SDK as a "client-side tunnel." A tunnel has no state. This also prevents every consumer from inheriting iv-bknd's schema choices. Hosts on any stack (SQLAlchemy, Tortoise, Django ORM, raw asyncpg) can integrate.
**Alternatives:** Ship `buttdial.migrations` with `[retry]` extra (v1.0 decision) — rejected for coupling.

## 2026-04-21 — Callbacks are a first-class SDK surface
**What:** SDK includes `InboundHandler` — decorator-based registration for inbound messages, delivery receipts, and status updates. Ships channel-specific payload parsers (WhatsApp first) and a FastAPI router for `POST /{channel}` + `GET /{channel}/verify`.
**Why:** Developer explicitly included callbacks in scope ("yes also callback"). iv-bknd already has inbound webhook handling at `POST /api/webhook/{channel}` — that logic is part of the "knowledge wrapped in the SDK." A tunnel without a return path isn't a tunnel.

## 2026-04-21 — Retry backoff: `2^n` minutes, pluggable
**What:** Default backoff is `timedelta(minutes=2 ** retry_count)`, matching iv-bknd's current algorithm. `RetryWorker` accepts a `backoff: Callable[[int], timedelta]` override.
**Why:** Preserve iv-bknd behavior by default (no semantic regression during extraction). Pluggable because different hosts will want different policies.

## 2026-04-22 — Extraction source is iv-bknd, not v95
**What:** The real `engine/comms.py`, `config/settings.py`, and `storage/schema.py` all live in `C:\Users\inon\Documents\work\iv\iv-bknd\` (shared backend). v95 has no `engine/` directory at all — it's a downstream consumer of iv-bknd. SDK extraction pulls from iv-bknd; Phase 10 integration targets iv-bknd as the first consumer. v95 benefits transitively.
**Why:** Initial session assumption was that v95 was the host. Discovered during Phase 2 code review that the tests I'd been reading in v95 actually reference iv-bknd modules (v95 imports from iv-bknd). Fixing the extraction target now — before any code is ported — prevents us from building against a downstream consumer instead of the real owner.

## 2026-04-21 — Diagnostic (`buttdial doctor`) is a staged, remediation-mapped end-to-end test
**What:** Seven-stage diagnostic: config → reachability → SSE → tool list → send → delivery → optional human ack. Each stage emits a typed result with a remediation string on failure. Runnable as CLI, Python function, and pytest fixture.
**Why:** Developer's core ask for the testing surface — "pinpoint where the error is with information how to resolve." First-class product feature, not an afterthought. Stage 7 (human ack loopback) directly tests the callback path end-to-end.

## 2026-04-25 — Host owns the agent UUID (0.3.0 breaking change)
**What:** `AccountsClient.register_agent(agent_id, display_name)` requires a host-supplied UUID. BD does not generate it — the host picks the value (typically the same UUID its own DB uses for the agent row) and tells BD on registration. BD echoes it back with a freshly-minted per-agent runtime token. Three credential tiers crystallised: `team_token` (workspace admin → `AccountsClient`), `agent_token` (per-agent runtime → `Agent`), `agent_id` (host-supplied UUID identifies the agent across both surfaces).
**Why:** With BD-generated IDs the host had to read it back from the response and store both its own UUID *and* BD's. That broke the "your DB is the source of truth" contract every other host integration follows. Letting the host be authoritative means: (1) one UUID, lived in one place; (2) the host can pre-register all its agents from a migration script; (3) BD's role narrows to credentials + channels, not identity. Required a matching BD-server change (`POST /api/v1/agents` accepting `agent_id` from the request body) — shipped in lockstep with SDK 0.3.0.
**Alternatives:** Keep BD-generated, expose a `host_external_id` foreign key. Rejected — duplicates state, costs a join everywhere, and the SDK would still need to translate between IDs at every API boundary.

## 2026-04-25 — Two-step onboarding: `register_agent` then `provision_channels`
**What:** Identity (`POST /api/v1/agents`) and channels (`POST /api/v1/provision`) are two separate calls, not one mega-endpoint. `AccountsClient.register_agent` mints identity + token; `AccountsClient.provision_channels` attaches phone / WA / email / voiceAi to the same `agent_id`. The token returned by `provision_channels` supersedes the one from `register_agent` — store the new one and discard the old.
**Why:** Hosts often need to register all their agents up front (during a tenant migration, for example) and then provision channels piecemeal as numbers become available in the pool. Forcing channels at registration time means: (a) you can't register a Maya without already knowing her phone number; (b) failing channel allocation kills the registration, leaving the host's UUID without a token. Splitting them lets the host adapt to channel availability over time. The token-supersession quirk is documented on `provision_channels`.

## 2026-04-25 — Symbol rename `Client` → `Agent`, `client_token` → `agent_token` (0.3.0)
**What:** The per-agent runtime class is `Agent` (was `Client`). File moved to `src/buttdial/agent.py`. `client_token` parameter / attribute renamed to `agent_token` everywhere. Env var `BUTT_DIAL_CLIENT_TOKEN` → `BUTT_DIAL_AGENT_TOKEN`. New env vars `BUTT_DIAL_BASE_URL`, `BUTT_DIAL_AGENT_ID`, `BUTT_DIAL_TEAM_TOKEN`.
**Why:** "Client" was overloaded — meant both an HTTP client class (the SDK side) and the human user / tenant (in BD's older terminology). After BD's 2026-04-20 rename of "client" → "agent" everywhere on the server, the SDK had to follow or callers would be reading two contradictory vocabularies. `Agent` matches what the BD admin UI shows, what the API routes are named, and what the SDK actually represents in code. Renamed in lockstep with sections 1-2 above.
**Alternatives:** Keep `Client` and add `Agent` as an alias. Rejected — keeps the old terminology forever and lets callers drift between both names. No backwards-compat shims (host pins SDK and BD versions together).

## 2026-04-25 — WhatsApp action surface lives on `Agent`, capability errors are typed
**What:** `Agent.whatsapp_action(action, ...)` plus 13 typed helpers (`react`, `edit`, `forward`, `delete`, `typing`, `mark_read`, `send_poll`, `send_buttons`, `send_location`, `send_contact`, `post_status`, `set_chat_ttl`, `send_view_once`) wrap BD's `comms_whatsapp_action` MCP tool. When BD returns `code: PROVIDER_UNSUPPORTED` or `CHANNEL_UNSUPPORTED`, the SDK raises `ProviderCapabilityError` with `.code`, `.action`, `.channel`, `.provider`, `.body` so the host can fall back instead of retrying.
**Why:** A flat `dict` response with a magic error key would force every caller to remember which actions are provider-gated (e.g. only WAHA implements `post_status`). A typed exception with structured fields means the host's fallback logic can read `.provider` and `.action` directly — and `except ProviderCapabilityError:` is an obvious place to put "switch to the other WA sender" code. Sits in the existing error hierarchy under `ChannelError` so callers that catch the broader class still work.

## 2026-04-25 — Auth-error contract from BD: typed exceptions, not retry-fodder
**What:** SDK reads BD's machine-readable error envelope (`code`, `retryable`, `remainingAttempts` on 401; `Retry-After` header + `retryAfterSeconds` + `lockedUntil` on 429). Surfaces as `AuthInvalidTokenError`, `AuthTokenRevokedError` (alias `RevokedToken`), `AuthMissingHeaderError`, `AuthLockedOutError`. `Agent._call_tool` re-raises these immediately instead of wrapping in retry — naive 401-retry walks straight into BD's per-IP brute-force lockout (10 fails → 15 min). On `remaining_attempts <= 3` the SDK warns the integrator before the lockout fires.
**Why:** A real production 429 was hit during integration testing because the SDK's retry loop kept hammering bad credentials. The lockout response said "Try again later" without `Retry-After`, so the SDK had nothing to honor. Both ends of the contract had to change: BD now emits machine-readable codes, SDK reads them and stops the loop. `retryable: false` is **terminal** in SDK code — no caller-side retry is ever correct on those.
