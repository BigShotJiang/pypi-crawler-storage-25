<!-- version: 1.1 | updated: 2026-04-28 -->

# BD Server — Onboarding Handshake Instructions

**To:** Butt-Dial server team
**From:** SDK side (this audit)
**On behalf of:** iv-bknd (`iv-bknd/docs/requests/butt-dial-onboarding-ux.md`)
**Status:** Blocking — iv's `/auth/register` flow currently never completes the BD round-trip; `organizations.butt_dial_provisioned` stays `FALSE` forever after the user clicks the verification link
**Tracks:** F09 (verify UX), **F26 (verification webhook)**, F88 (NEW — email branding)

> **Update v1.1 (2026-04-28):** Removed Item 4 (F77 — return 409 EMAIL_ALREADY_REGISTERED). F04's silent-treatment-for-verified-emails takes precedence; the proposed 409 would have regressed F04 by reintroducing the email-enumeration oracle. F77 is closed WONTFIX-BY-DESIGN. iv's flow works without it because the webhook (Item 3) delivers the team_token regardless of new-vs-existing email.

---

## What this document is

A consolidated implementation request that translates iv's three product gaps into concrete server-side changes. Each section has:
- The exact behavior expected
- A reproducer that should pass once shipped
- Cross-references to existing findings so the BD team can re-use any work already in flight

---

## TL;DR — what's blocking iv right now

> iv's onboarding banner stays "pending" forever after the user clicks the verification link, because BD never tells iv that verification completed.

**Single most important fix:** ship a webhook callback (Item 3 below) that POSTs `{event:"account.verified", orgId, teamToken, ownerEmail, verifiedAt}` to a host-registered URL after successful verify. Everything else (branding, return_url, redirect UX) is polish around this core handshake.

**Second:** the verify page already has loading/success/failure states (F09 fix shipped in round 4) but is NOT branded per-tenant and has no `return_url`. iv's report says the page appears "stuck on loading" — please double-check that the JS path is actually firing for iv's flow.

---

## Cross-reference with existing findings

| ID | Status | Relation to this request |
|---|---|---|
| **F26** [HIGH] [open] | No verification-completion webhook | **This is exactly what iv needs.** Item 3 below is the explicit spec |
| F09 [PARTIAL fixed in round 4] | Verify page UX | Page has states but no branding override + no `return_url` (Item 2) |
| F77 [closed WONTFIX-BY-DESIGN] | Verified-email register returns existing orgId silently | F04 takes precedence — see header note above. SDK's `EmailAlreadyRegistered` class kept as forward-compatibility hook |
| F05 [CRITICAL] [open] | `verificationSent: true` synchronous optimism | Branded email won't help if mail delivery itself is unreliable. Recommend wiring mailer webhook for delivery state |
| F88 (NEW) | Email is plain-text, unbranded | Item 1 below |

---

## Item 1 — Branded HTML email template (new finding F88)

### Behavior

`POST /api/orgs/register` accepts an optional `branding` object. When provided, the verification email uses an HTML template populated with the tenant's logo, accent color, product name, and support contact.

### Request shape extension

```json
POST /api/orgs/register
{
  "orgName": "<workspace name>",
  "ownerEmail": "<admin email>",
  "branding": {                         // NEW — optional
    "logoUrl": "https://iv.95percent.ai/logo-mark.svg",
    "primaryColor": "#00C9A7",
    "productName": "iv",
    "supportEmail": "support@95percent.ai"
  },
  "returnUrl": "https://iv.95percent.ai/"  // NEW — optional, see item 3
}
```

camelCase to match the rest of the (newer) REST surface. Snake_case alias acceptable during migration window.

### Email template requirements

- Logo (from `logoUrl`) and accent color (from `primaryColor`) in the header.
- Greeting addresses `orgName`.
- Single prominent button: "Verify your workspace" — uses `primaryColor`.
- Fallback plain-text link below the button (for clients that strip CSS).
- Footer: "Sent on behalf of `<productName>`. Need help? `<supportEmail>`."
- Defaults: when `branding` is omitted, fall back to BD's own brand.

### Email deliverability (cross-link to F05)

While here: please wire the mailer's webhook (SES / Postmark / SendGrid all expose one) into the org record so `verificationSent` becomes a real lifecycle state (`queued` → `dispatched` → `delivered` / `bounced`). iv has no way to retry intelligently if delivery silently fails.

### Reproducer

```bash
curl -X POST https://call.95percent.ai/api/orgs/register \
  -H 'Content-Type: application/json' \
  -d '{
    "orgName":"iv test org",
    "ownerEmail":"someone@example.com",
    "branding":{
      "logoUrl":"https://iv.95percent.ai/logo-mark.svg",
      "primaryColor":"#00C9A7",
      "productName":"iv",
      "supportEmail":"support@95percent.ai"
    },
    "returnUrl":"https://iv.95percent.ai/"
  }'
# → email lands in inbox; HTML is iv-branded; button + fallback link both work
```

---

## Item 2 — Branded verify landing page

### Behavior

The `/verify` page reads the same `branding` block stored at registration time and renders accordingly:

- Logo + accent color in header.
- Loading state still shows briefly while the POST to `/api/orgs/verify` is in flight (current behavior is correct — leave as-is).
- **Distinct success state:** "Your workspace is verified. You can close this tab and return to `<productName>`." + button labeled "Return to `<productName>`" linking to the registered `returnUrl`.
- **Distinct failure state:** branded error card with the same code-specific messages currently shipping (`VERIFICATION_TOKEN_EXPIRED`, `VERIFICATION_TOKEN_INVALID`) plus a "Try again" CTA pointing back to the originating product (`returnUrl`/registration).
- **Auto-redirect on success:** ~3 second countdown then `window.location = returnUrl`.

### Important: do not regress F03

Token must continue to be read from `location.hash` only. The existing implementation (`scripts/probe_round3.py` reproducer for F03) is correct — verify page POSTs `{token}` to `/api/orgs/verify` from the URL fragment, then `history.replaceState` to wipe it. Branding additions must not move the token back into a query string.

### Reproducer

After registering with `branding` + `returnUrl`, click the verification link from the email. Verify:

1. Page shows iv's logo and accent color.
2. On success: "Return to iv" button is present and links to `https://iv.95percent.ai/`.
3. After ~3 seconds with no interaction: browser auto-redirects to `https://iv.95percent.ai/`.
4. On failure (use an expired token): error card shows iv branding + a CTA back to `https://iv.95percent.ai/`.

---

## Item 3 — Webhook handshake (F26 — the blocking item)

This is the single most important deliverable. Without it, iv cannot complete onboarding.

### Behavior

`POST /api/orgs/register` accepts a `webhookUrl` field. After a successful `verify`, BD POSTs to that URL with HMAC signature.

### Request shape extension

```json
POST /api/orgs/register
{
  "orgName": "...",
  "ownerEmail": "...",
  "branding": {...},
  "returnUrl": "...",
  "webhookUrl": "https://iv.95percent.ai/api/webhook/butt-dial/account-verified"
}
```

### Webhook payload

```http
POST https://iv.95percent.ai/api/webhook/butt-dial/account-verified
Content-Type: application/json
X-BD-Signature: hmac-sha256=<hex>
X-BD-Event: account.verified
X-BD-Timestamp: 1730145000

{
  "event": "account.verified",
  "orgId": "<uuid>",
  "ownerEmail": "<email>",
  "teamToken": "<token>",
  "scopes": "org-admin",
  "verifiedAt": "2026-04-28T18:30:00.000Z"
}
```

### Signature scheme

HMAC-SHA256 over the canonical payload. Recommended:

```
signed_payload = "{X-BD-Timestamp}.{raw body}"
signature = HMAC_SHA256(BUTT_DIAL_WEBHOOK_SECRET, signed_payload)
```

iv's bknd will compute the same signature and reject mismatches. Stripe-style scheme — well-understood, easy to test.

### Retry / delivery semantics

- 5 retry attempts with exponential backoff (1s / 5s / 25s / 2m / 10m), then dead-letter.
- Idempotency: include `X-BD-Delivery-Id: <uuid>` header so iv can dedupe replays.
- iv must respond 2xx within 10s; any 4xx/5xx triggers retry.

### Fallback (Option B)

If implementing the webhook is too heavy for this sprint, BD can instead redirect after successful verify to:

```
<returnUrl>#bd_token=<teamToken>&org_id=<orgId>&verified_at=<iso>
```

Fragment-only, never sent to a server, consumed by iv's frontend. iv has the route `/api/workspace/butt-dial/verify-callback` ready for this.

**Webhook is strongly preferred** because:
- Token never enters any URL bar / browser history / referrer
- Works even if user closes the verify tab before the redirect fires
- iv can complete onboarding even if the user verified on a different device than where they started signup

### Reproducer

```bash
# 1. iv-bknd registers a workspace with webhookUrl
# 2. User clicks email link, verify succeeds
# 3. BD posts to webhookUrl within ~1s
# 4. iv-bknd verifies signature, persists teamToken, flips butt_dial_provisioned = TRUE
# 5. iv onboarding banner flips from "pending" → "ready" within 60s (next poll cycle)
```

---

## SDK-side changes (we will ship these once the server is ready)

`AccountsClient.register()` signature extension:

```python
async def register(
    self,
    org_name: str,
    owner_email: str,
    *,
    branding: dict | None = None,        # NEW
    return_url: str | None = None,       # NEW
    webhook_url: str | None = None,      # NEW
) -> dict[str, Any]:
    body = {"orgName": org_name, "ownerEmail": owner_email}
    if branding is not None:
        body["branding"] = branding
    if return_url is not None:
        body["returnUrl"] = return_url
    if webhook_url is not None:
        body["webhookUrl"] = webhook_url
    return await self._request("POST", "/api/orgs/register", body=body, authenticated=False)
```

`EmailAlreadyRegistered` exception class (`src/buttdial/accounts.py:111`) is intentionally unreachable today — F04 silent-treatment is intentional. The class is kept as a forward-compatibility hook for a future proof-of-ownership 409 pattern.

---

## Acceptance criteria

- [ ] `POST /api/orgs/register` accepts optional `branding`, `returnUrl`, `webhookUrl`
- [ ] Verification email is HTML with the supplied branding; falls back to BD brand when none supplied
- [ ] Verify page (`/verify`) reads branding from registration record; renders distinct loading/success/failure states; respects `returnUrl` with a CTA + auto-redirect countdown
- [ ] After successful verify, BD posts the `account.verified` event to `webhookUrl` with HMAC signature
- [ ] If `webhookUrl` is omitted, BD redirects to `<returnUrl>#bd_token=...&org_id=...` instead
- [ ] Token continues to be transported via URL fragment only (F03 not regressed)
- [ ] No regression on existing F-list fixes (F02 rate-limit, F04 silent-treatment, F22 SSE auth, F50 envelope, F60 idempotency)

## Priority

**Item 3 (webhook handshake) is the blocking gap.** Items 1 and 2 are unblocking polish that iv would prefer in the same sprint, but Item 3 alone is what's keeping `organizations.butt_dial_provisioned = FALSE` forever today.

If the BD team can ship only one thing this week: **Item 3, option (a) webhook**.

---

## Reference

- iv's request doc: `iv-bknd/docs/requests/butt-dial-onboarding-ux.md`
- Audit findings: `docs/BD_SERVER_FEEDBACK.md`, `_2.md`, `_3.md`, `_4.md` (this repo)
- SDK accounts client: `src/buttdial/accounts.py` (lines 256–293 for the `register`/`verify` methods)
- Probe scripts: `scripts/probe_live.py`, `scripts/probe_ping.py`, `scripts/probe_tools.py`, `scripts/probe_round3.py`
