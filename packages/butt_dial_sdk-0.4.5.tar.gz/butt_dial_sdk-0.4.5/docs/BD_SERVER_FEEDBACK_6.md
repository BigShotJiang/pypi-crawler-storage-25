# BD Server Feedback — Round 6 (Live Validation)

<!-- version: 1.0 | updated: 2026-04-29 -->

**Date:** 2026-04-29
**Server:** `https://call.95percent.ai`
**SDK version under test:** `butt-dial-sdk==0.4.1`
**Driver:** `scripts/probe_round6.py` + `buttdial doctor`
**Test data:** stored team_token (org `28bf35dd-995f-46ac-96da-1f99ac9d9b52`), stored agent (`d51b0eb9-…`)

This round is a **broad sweep** rather than a deep audit — every SDK surface
exercised against the live server, one call each, to confirm the post-sprint-10
state matches the SDK contract. New findings are filed as F90+.

---

## Headline

**8 of 8 functional checks PASS.** No new server bugs found. The SDK and the
`call.95percent.ai` deployment are in agreement on every wire shape the SDK
exercises. v0.4.1 is the right version to recommend to host integrators.

| Surface | Endpoint | Status |
|---|---|---|
| `AccountsClient.get_account` | `GET /api/orgs/me` | ✅ |
| `AccountsClient.get_agent` | `GET /api/v1/agents/{id}` | ✅ |
| `AccountsClient.register` (branded) | `POST /api/orgs/register` | ✅ — `webhookSecret` + `pollToken` returned |
| verification-status (pollToken auth) | `GET /api/orgs/{id}/verification-status` | ✅ — 200, `status=null` (correct for pending) |
| `AccountsClient.register` (template error) | `POST /api/orgs/register` | ✅ — raised `TEMPLATE_MISSING_VERIFY_URL` |
| `Agent.list_tools` | `GET /sse` + `list_tools` | ✅ — 57 tools |
| `Agent.ping` | MCP `comms_ping` | ✅ |
| `Agent.send_message` | MCP `comms_send_message` | ✅ — correctly returned `SendResult.failed` (see F90) |

**Skipped** (would charge SMS or be destructive): `set_phone`, `confirm_phone`,
`rotate_token_request`, `rotate_token_confirm`. SMS-touching stages of
`buttdial doctor` (5–7) likewise skipped (no `--to`).

---

## What was confirmed working at the wire level

### Onboarding handshake (sprint-9 / 0.4.0)

`POST /api/orgs/register` with `branding`, `returnUrl`, `webhookUrl`,
`verificationEmail` returned all four expected fields:

```json
{
  "orgId": "...",
  "verificationSent": true,
  "webhookSecret": "<32-byte hex>",
  "pollToken": "<32-byte hex>"
}
```

`webhookSecret` only appears on **pending** registers with a `webhookUrl`
present — matches the F89 capture-once contract. `pollToken` appears on every
register (sprint-10 universal). Both confirmed live.

### Verification status with pollToken

`GET /api/orgs/{orgId}/verification-status?poll_token=<…>` returned HTTP 200
with `status=null` for a freshly-registered, not-yet-clicked org. Server
auth-by-pollToken path is shipped and the SDK doesn't need to change.

### Template validation

A `verificationEmail.html` body without `{{verifyUrl}}` was rejected with
`code=TEMPLATE_MISSING_VERIFY_URL` — matches the SDK's mapped
`AccountsError`. F31/F32 closed.

### Camel/snake dual-emission visible

`GET /api/v1/agents/{id}` returns **both** `agentId` and `agent_id`,
`callbackUrl` and `callback_url`, etc. This is the F84 sunset path in flight
(camelCase canonical, snake_case legacy with `Sunset: 2026-07-27`). Behavior
matches what we documented in `AGENTS.md`.

---

## New findings

### F90 — `comms_send_message` says "no WhatsApp sender" even when phone capability is provisioned

**Severity:** Medium (host UX)
**Where:** MCP `comms_send_message` against agent `d51b0eb9-…`
**Symptom:**

```
SendResult.failed=True
SendResult.stage_failed='server'
SendResult.error='Client "d51b0eb9-…" has no WhatsApp sender assigned'
```

This agent was registered but never had channels provisioned (no
`POST /api/v1/provision` call). The error is correct **in spirit** — there's
no sender — but the wording ("WhatsApp sender") is too narrow:

1. The same error fires for SMS-only sends. A host using `to=+1…` with no
   intent to use WhatsApp will see "no WhatsApp sender" and be confused.
2. The error doesn't surface a `code` (e.g. `NO_CHANNEL_ASSIGNED`), so the
   SDK can't map it to a typed exception or an actionable `remediation`
   string.
3. There's no hint of the fix ("call `/provision` to assign channels").

**Ask:** Either generalize the message ("no sender assigned for this agent
— call `/provision` first") or add a machine-readable `code` so the SDK
can render the remediation. Prefer both.

**SDK side:** I'll add a `NoChannelAssigned` typed error mapping if BD
supplies the code.

---

### F91 — `buttdial doctor` skipped stages render as `[FAIL]` *(FIXED in this round)*

**Severity:** Cosmetic (SDK-side, not server)
**Where:** `buttdial doctor` (no `--to` provided)
**Symptom (before):**

```
[FAIL] send_message accepted -- skipped: no --to recipient provided
[FAIL] Delivery receipt   -- skipped: no --to recipient provided
[FAIL] Human ack loopback -- skipped: no --to recipient provided

All stages passed.
```

**Status:** FIXED in `src/buttdial/doctor.py:_format_stage` (this round).
Skipped stages now render as `[SKIP]` (or `[○]` in Unicode), distinct from
both `[OK]` and `[FAIL]`. New regression test
`test_format_stage_renders_skipped_distinctly` covers it. Will ship in
0.4.2.

---

## Status of prior findings (spot checks)

These were verified shipped in round 5; this round confirms they're still
behaving correctly post-sprint-10:

| Finding | Status |
|---|---|
| F04 (anti-enumeration on existing email) | ✅ still in force — silent re-send |
| F26 (account.verified webhook + HMAC) | ✅ contract intact, SDK helper works |
| F31/F32 (template error codes) | ✅ live |
| F41 (`/api/v1/agents/me` removed) | ✅ confirmed gone — SDK no longer calls it |
| F84 (camelCase canonical + Sunset header path) | ✅ dual-emit observed |
| F89 (webhookSecret capture-once on pending only) | ✅ confirmed |

Items still **OPEN** from round 5 that this round did not specifically
re-test (because they need fresh data or destructive flows): F49 (auth
lockout backoff curve), F77 (intentional WONTFIX), and the rest of the
sprint-11 backlog.

---

## SDK actions

1. **F90 mapping** — wait for BD to add `code=NO_CHANNEL_ASSIGNED` (or similar),
   then add a typed `NoChannelAssigned(AccountsError)` subclass. Until then
   the bare message lands in `SendResult.error` and that's acceptable.
2. **F91 doctor cosmetics** — ✅ fixed in this round. Tests green (219 pass).
3. **0.4.2 patch release** — bundle F91 fix; no API changes, no breaking diff.
   Optional; can ride along with the next functional change.

---

## Test artifacts

- `scripts/probe_round6.py` — re-runnable validation driver
- `docs/round6_live_results.json` — machine-readable per-call result list

Reproduce with:

```bash
PYTHONIOENCODING=utf-8 python scripts/probe_round6.py
```

(Requires `.bd_token`, `.bd_agent_token`, `.bd_agent_id` in repo root.)
