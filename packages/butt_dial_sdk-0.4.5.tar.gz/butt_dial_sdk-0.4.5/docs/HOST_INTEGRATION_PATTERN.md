# Host integration pattern — wrapping butt-dial-sdk in your own admin API

<!-- version: 1.0 | updated: 2026-04-29 -->

When a third-party product (e.g. iv-bknd) integrates Butt-Dial as a feature
its own customers can use, the SDK is **not** the public contract. The host
wraps the SDK behind its own admin endpoints, owns its own database, and
exposes only what its UI needs. This document explains the recommended shape
of that wrapper and why each field is there. The worked example throughout is
iv-bknd's `POST /api/workspace/butt-dial/register`, but the pattern applies to
any host wrapping either SDK (Python or Node).

> **Companion docs:**
> - The canonical onboarding example is in `examples/with-onboarding-handshake/`.
> - The contract for what the SDK call must look like is in `AGENTS.md` § Onboarding.
> - This document covers the layer **above** the SDK call — the host's own admin endpoint.

> **In-sync rule.** Everything documented here as a BD-server behavior is either (a) directly verified by `scripts/probe_round*.py` or (b) documented by BD in `docs/BD_SERVER_HANDSHAKE_SHIPPED.md`. **Do not add features or behaviors that haven't been verified or specced by BD.** If you're tempted to write "BD will do X" without evidence, write a probe first or ask. Patterns the host invents (URL validation, persistence schema, admin UI) belong here freely; assumptions about how BD responds to specific inputs do not.

---

## The mental model

```
┌─────────────────┐        ┌────────────────────┐        ┌─────────────────────────┐
│  Admin UI       │  HTTPS │  Host backend      │  HTTPS │  call.95percent.ai      │
│  (browser)      │ ─────▶ │  (iv-bknd, etc.)   │ ─────▶ │  (Butt-Dial REST + MCP) │
│                 │  +JWT  │  + butt-dial-sdk   │ +Bearer│                         │
└─────────────────┘        └────────────────────┘        └─────────────────────────┘
                                  │
                                  ▼
                           ┌─────────────────┐
                           │  host database  │
                           │  + secret vault │
                           └─────────────────┘
```

The host is the **fan-out + auth + validation wrapper**:
- All BD register params are exposed for admin configuration (frontend → host has the same shape as host → BD, with tenant defaults filled in for any field the admin left blank)
- Response **shrinks** coming left (BD → host → frontend keeps only what the UI needs)
- Secrets **stay sealed** in the host's vault — the frontend never sees `webhookSecret` or `teamToken`
- User-supplied URLs (`webhook_url`, `return_url`, `branding.logoUrl`) are validated against an HTTPS + no-private-IP + verified-domain allowlist before forwarding

If your host doesn't follow this pattern, three things break:
1. The end user sees BD-domain URLs in their browser (wrong product brand)
2. Per-tenant auth is missing — anyone hitting your domain can register BD workspaces
3. Sensitive secrets leak to the frontend

---

## The canonical endpoint shape — `POST /api/workspace/butt-dial/register`

Worked example using iv-bknd. Adapt names to your conventions; the **structure** is what to copy.

### Request — what the admin UI sends

| Field | Why |
|---|---|
| **Method:** `POST` | Creates a resource (a BD workspace tied to this iv tenant). |
| **URL:** `https://iv.95percent.ai/api/workspace/butt-dial/register` | iv-bknd's *own* route, not a passthrough. The host product owns the public surface; the BD URL never leaks to end users. Lets you swap providers, add caching, route per-tenant. |
| **Auth:** `Authorization: Bearer <iv-tenant-admin JWT>` | Two reasons. (a) **Authn:** which iv tenant is creating this? Without auth, anyone could trigger BD registrations on your domain. (b) **Authz:** only iv tenant *admins* — not regular users — should be able to register a BD workspace under their tenant. The JWT carries both `tenant_id` and `role=admin`. |
| **Body:** `{"org_name", "owner_email", "branding"?, "return_url"?, "webhook_url"?, "verification_email"?}` | The four required-by-BD fields plus the four optional handshake kwargs. **All configurable from the admin UI** — not silently derived. The host provides sensible defaults from tenant config (logos, branded return URL, default verification template) but the admin can override any of them per workspace. See [§ Configurable params](#configurable-params-not-derived) below. |

### Response — what the frontend gets back

| Field | Why |
|---|---|
| **Status:** `200 OK` | Workspace created and verification email queued. The handshake is **incomplete** at this point — the user still has to click. The frontend reflects this with a "check your email" banner. |
| **Body field `orgId`** | Lets the UI render "your BD workspace ID is `…`" and provides a stable handle for support. |
| **Body field `verificationSent: true`** | Confirms the email **actually went out**, not silently dropped. If you ever see `false` here, BD's mailer queue is stuck and the verification will not arrive — alert the user. |
| **Body field `pollToken`** | Lets the frontend poll `GET https://call.95percent.ai/api/orgs/{orgId}/verification-status?poll_token=…` every ~60s during signup. Flips the banner from "check your email" → "you're ready" without waiting on the webhook delivery (which is the source of truth, but slower if the user clicks then closes the tab). Single-purpose token: read-only, this workspace, verification-status only. |
| **Body field NOT exposed: `webhookSecret`** | The HMAC secret BD generated for this workspace. **Stays inside iv-bknd's vault.** Returning it to the frontend would defeat the whole signature scheme — anyone who saw it could forge `account.verified` webhooks. iv-bknd reads it only inside its webhook receiver. |
| **Body field NOT exposed: `teamToken`** | Doesn't exist yet at this stage (only minted after the user clicks). Even when it does, the frontend never sees it. |

---

## Configurable params, not derived

A previous version of this document said that `branding` / `return_url` / `webhook_url` / `verification_email` should be derived server-side from tenant config. That's **wrong** for any product where:

- one tenant runs **multiple BD workspaces** (e.g. dev + prod, or one workspace per sub-brand) with different branding or callback URLs
- per-workspace template overrides are needed (one product line wants a different email subject than another)
- multi-region deployments need different `return_url` per environment

The correct model: **all four optional params are configurable per workspace from the admin UI. Tenant config provides defaults, but the admin can override any of them at register time.**

### Recommended request schema

```jsonc
{
  // required
  "org_name":   "Aid Genomics ltd",
  "owner_email": "ops@aidg.com",

  // optional, all configurable; host fills in defaults from tenant settings
  // when the admin leaves a field blank.
  //
  // Branding fields reference the TENANT's domain (logo, support email) —
  // these are what the end user sees in the verification email. Brand
  // affinity belongs to the tenant.
  "branding": {
    "logoUrl":      "https://aidg.com/logo.svg",
    "primaryColor": "#00C9A7",
    "productName":  "Aid Genomics",
    "supportEmail": "support@aidg.com"
  },

  // return_url: where the user's BROWSER lands after clicking verify.
  // In the iv-bknd hosted model, the welcome / post-verify experience
  // lives at iv.95percent.ai too — the tenant doesn't host their own
  // BD-aware UI. BD redirects to this URL VERBATIM (no query strings
  // are added; whether existing query strings on the URL are preserved
  // is not documented as a contract — don't depend on it). For routing
  // to the right tenant's welcome view, look up by orgId from the
  // webhook (which fires server-to-server) rather than by URL params.
  "return_url":  "https://iv.95percent.ai/welcome",

  // webhook_url: where BD POSTs server-to-server with the team_token.
  // MUST point at iv-bknd's domain, because iv-bknd is the one tracking
  // workspace state. Override only if you run your own backend to receive
  // BD callbacks AND don't need iv-bknd's state tracking.
  "webhook_url": "https://iv.95percent.ai/api/webhooks/butt-dial/account-verified",

  "verification_email": {
    "subject": "Verify your Aid Genomics workspace",
    "html":    "<p>Click <a href=\"{{verifyUrl}}\">here</a>. Expires in {{expiresInMinutes}} minutes.</p>"
  }
}
```

**Two domains, two roles:**
- `iv.95percent.ai` — the host backend (iv-bknd). Handles `webhook_url`, `return_url`, all the integration plumbing. The tenant doesn't have their own BD-aware backend.
- `aidg.com` (tenant brand) — used **only** in the visual branding fields (logo, product name, support email). The verification email shown to end users says "Aid Genomics" with the AidG logo, but every clickable URL points at iv-bknd or BD.

The host backend resolves any missing field from tenant config (or hard-coded sensible defaults) before forwarding to the SDK. The admin UI shows pre-filled defaults but lets the admin override every field.

### `return_url` vs `webhook_url` — they go to different places

These two URLs have completely different jobs and should default to different domains in a hosted product like iv-bknd:

|  | `webhook_url` | `return_url` |
|---|---|---|
| Who calls it | BD's servers (HTTP POST) | The user's browser (HTTP 302) |
| Carries | `teamToken` in HMAC-signed JSON body | Nothing sensitive |
| Reliability | Retried 1s/5s/25s/2m/10m on failure | Fires once; lost if user closes tab |
| Default target in iv-bknd | `https://iv.95percent.ai/api/webhooks/butt-dial/account-verified` | `https://iv.95percent.ai/welcome` |
| Why iv-bknd's domain | iv-bknd needs the secret-carrying callback to update workspace state | iv-bknd hosts the post-verify UI for tenants (the tenant doesn't host their own BD-aware welcome page) |
| Override safe? | Only if the override target replicates iv-bknd's state tracking | Yes — pure UX. Override if the tenant maintains their own welcome page on their domain |

The two callbacks fire **in parallel** for the same user-click event:

```
user clicks verify in email
        ↓
BD's verify page processes the click
        ↓
   ┌────┴────┐
   ↓         ↓
webhook_url  return_url
(POST,       (302 redirect,
 signed)     no secrets)
   ↓         ↓
iv-bknd     tenant-branded
updates DB  "welcome" page
```

The admin UI should default `webhook_url` to iv-bknd's domain and only let the admin override if they explicitly want to run their own webhook receiver (and accept that iv-bknd's state tracking won't fire). `return_url` defaults to iv-bknd's `/welcome` page in the hosted model; admins can override to a tenant-controlled URL if they have one.

### Security: validating user-supplied `webhook_url`

This is the only field that needs careful validation. If you accept arbitrary URLs, an iv tenant admin could:
- Send the verification webhook to a server they don't own (data leakage)
- Send it to an internal-network IP (SSRF — leak the host backend's network shape)

**Mandatory checks on `webhook_url` before forwarding to BD:**

1. **HTTPS only.** Reject `http://`, `file://`, anything else.
2. **No private/loopback IPs.** Reject `127.0.0.0/8`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `169.254.0.0/16`, `::1`, IPv6 ULA. (BD itself probably enforces this too — but defense in depth.)
3. **Domain ownership verification (recommended).** Maintain a `verified_domains` table per iv tenant; reject `webhook_url`s on domains the tenant hasn't proven ownership of (DNS TXT record / .well-known file / similar).
4. **No port-scanning.** Reject ports outside `{80, 443, 8000-9999}` or your published allowlist.

Apply the same rules to `return_url` (lower stakes but still worth gating to avoid open-redirect abuse).

`branding.logoUrl`, `branding.supportEmail`, and `verification_email.html` need separate handling:
- `logoUrl`: HTTPS only; size cap when fetched at email-render time; reject SVG with embedded scripts (or sanitize).
- `supportEmail`: standard RFC 5322 validation.
- `verification_email.html`: BD validates and surfaces two error codes the SDK maps:
  - `code=TEMPLATE_MISSING_VERIFY_URL` — body lacks the `{{verifyUrl}}` substitution variable. (Verified live, round-7.)
  - `code=TEMPLATE_TOO_LARGE` — body exceeds BD's size limit. The exact limit is BD-side and may change; surface the error to the admin verbatim rather than hard-coding a byte budget.

  BD documented additional sanitization (stripping `script`/`iframe`/`on*=` etc.) in the sprint-9 handshake spec, but the SDK has not directly tested that behavior live. Rely on the error codes for what the SDK can verify; treat the sanitization claims as BD-side defense-in-depth.

### Pre-fill the admin UI from tenant config

Even though every field is configurable, the admin should see good defaults pre-populated. The host backend should expose a `GET /api/workspace/butt-dial/register-defaults` that returns:

```jsonc
{
  "branding": { /* tenant default branding */ },
  "return_url_suggestions": [
    "https://aidg.com/welcome",                    // tenant's primary domain
    "https://staging.aidg.com/welcome"             // verified secondary domains
  ],
  "webhook_url_suggestions": [
    "https://aidg.com/api/webhooks/butt-dial/account-verified"
  ],
  "verification_email_template_default": { /* ... */ }
}
```

The frontend uses this to pre-fill the create-workspace form. Anything the admin types into the form overrides the default at submit time.

---

## What the host persists in its own database

Each row scoped to one iv tenant. (For your host, replace "iv tenant" with the equivalent foreign key in your data model.)

| Column | Source | Why it's persisted |
|---|---|---|
| `butt_dial_owner_email` | request body | Render "we sent verification to `___@___`" in the UI. Dedupe re-register attempts. Reconcile a stuck-pending state without round-tripping BD. |
| `butt_dial_org_id` | response.`orgId` | Stable BD-side identifier for this workspace; keys all subsequent BD calls. |
| `butt_dial_webhook_secret` (encrypted, hidden) | response.`webhookSecret` | The HMAC secret BD signs every webhook delivery with. **Capture-once.** Lose it and you can never verify a webhook signature for this workspace again — every future delivery becomes unverifiable. |
| `butt_dial_poll_token` | response.`pollToken` | Auth token for `GET /verification-status`. Different from `webhook_secret`: this one is **single-purpose, read-only, this workspace, expires on verify**. |
| `butt_dial_team_token` (encrypted, set later) | webhook body.`teamToken` after user clicks | The bearer token for everything authenticated against BD on behalf of this workspace. Set by the webhook handler, not the register handler. |
| `butt_dial_provisioned: bool` (default `false`) | flipped by webhook handler | Frontend displays "ready" banner when `true`. |
| `butt_dial_verified_at: timestamp \| null` | webhook body.`verifiedAt` | Timestamp the user clicked the verification link. Nullable while pending. |
| `butt_dial_failure_counter: int` (default `0`) | incremented on 4xx/5xx from BD | Gates retries; alerts on stuck onboardings; reset to 0 when a class of upstream errors is fixed (e.g. BD's F06 squat-protection removal). |

### What breaks if you skip each one

| Skipped column | Failure mode |
|---|---|
| `butt_dial_owner_email` | Can't render the "check your email" message. Can't dedupe re-registers. Can't recover from a stuck pending state without re-deriving. |
| `butt_dial_org_id` | No way to address this BD workspace for any subsequent call (provisioning, polling, debugging). |
| `butt_dial_webhook_secret` | **Most security-critical.** Every signed webhook from BD becomes unverifiable forever — anyone who knows your webhook URL can forge `account.verified` events and provision arbitrary workspace tokens. |
| `butt_dial_poll_token` | Frontend can't show real-time "you're ready" transitions; falls back to waiting for the webhook. If the user closes the tab, no in-app feedback. |
| `butt_dial_team_token` | Workspace is verified but unusable — every authenticated BD call hits `AuthMissingHeaderError`. |
| `butt_dial_provisioned` | UI can't tell the difference between "still pending" and "ready"; same banner forever. |
| `butt_dial_failure_counter` reset | Resolved upstream errors (e.g. BD's F06 ORG_NAME_DOMAIN_MISMATCH after the gate was removed) keep firing alerts on resolved noise. Real future failures get lost in the false positives. **When BD ships a fix that removes a class of errors, reset the counter.** |

---

## The webhook receiver — `POST /api/webhooks/butt-dial/account-verified`

The other half of the contract. Mounted on the same iv-bknd:

| Field | Why |
|---|---|
| **Method:** `POST`, no auth | BD signs requests with the per-workspace `webhook_secret`. Auth is via signature, not bearer token — there's no caller identity to authenticate at this layer. |
| **Body:** raw bytes (Buffer / `bytes`) | Required for signature verification. **Don't** parse with `request.json()` first — re-serializing breaks the byte-for-byte HMAC match. |
| **Headers:** `X-BD-Timestamp`, `X-BD-Signature`, `X-BD-Delivery-Id` | Timestamp + signature gate the request; delivery-ID dedupes BD's retries. |
| **What the handler does** | (1) Look up workspace by body's `orgId`. (2) Verify signature via `verifyWebhookSignature` over **raw bytes** with the workspace's stored `webhook_secret`. (3) Check delivery-id against a dedup table. (4) Persist `teamToken` to the workspace row, flip `provisioned=true`, mark delivery-id as processed. (5) Return 2xx. |
| **Response: 2xx within 10s** | BD retries (1s/5s/25s/2m/10m) on any 4xx/5xx or timeout. Slow handlers cause duplicate deliveries. Queue long work. |

See `examples/with-onboarding-handshake/app.py` for the full receiver in Python; `examples/with-onboarding-handshake/app.ts` for the Node version.

---

## Why this pattern beats the alternatives

### ❌ "Just call BD directly from the frontend"

- Frontend never sees the `team_token` (good) but also can't store the `webhook_secret` (no signature verification possible).
- BD sees end-user IPs, not your tenant's IP — pool quotas, abuse signals, and rate limits shred your tenant boundary.
- End users see `call.95percent.ai` in their browser — wrong product brand.

### ❌ "Just pass through frontend → host → BD with no validation"

- `webhook_url` becomes a frontend-controlled string with no bounds — an iv tenant admin (or anyone who steals an admin JWT) can redirect callbacks to a server they control and capture the `team_token`.
- SSRF risk if BD's mailer/verify-page renderer fetches `branding.logoUrl` against an unsanitized URL pointing at internal infra.
- Branding leaks per-request without tenant-scoped guardrails.

### ✅ "Host wraps the SDK, accepts the configurable params, validates the URLs, persists the secrets"

- Every register field is configurable from the admin UI (multiple workspaces per tenant, per-environment overrides) — no rigid server-side derivation.
- `webhook_url` and `return_url` validated against an HTTPS + private-IP-deny + verified-domain allowlist before forwarding.
- Tenant config provides good defaults so admins rarely have to fill anything in unless they're customizing.
- Secrets stay sealed inside the host's vault.
- Resetting failure counters at upstream-fix time keeps alerts honest.

---

## Implementation checklist

When wrapping butt-dial-sdk in a host backend, verify all of these:

### Endpoint surface
- [ ] `POST /api/workspace/butt-dial/register` accepts `{org_name, owner_email, branding?, return_url?, webhook_url?, verification_email?}` — all four optional
- [ ] Auth: `Authorization: Bearer <admin JWT>`; rejects non-admin tokens with 403
- [ ] Tenant defaults filled in for any optional field the admin left blank (so the SDK call always has all four populated and never triggers DeprecationWarning)
- [ ] `webhook_url` validation: HTTPS-only, no private IPs, port allowlist, domain-ownership check
- [ ] `return_url` validation: HTTPS-only, no private IPs, port allowlist
- [ ] `verification_email.html` size cap (200 KB) and the `{{verifyUrl}}` requirement surfaced as 400 to the admin
- [ ] `GET /api/workspace/butt-dial/register-defaults` returns pre-fill values for the admin UI

### Persistence
- [ ] `butt_dial_owner_email` stored
- [ ] `butt_dial_org_id` stored
- [ ] `butt_dial_webhook_secret` stored, **encrypted at rest**, never returned by any API
- [ ] `butt_dial_poll_token` stored
- [ ] `butt_dial_team_token` column exists (populated by the webhook handler later)
- [ ] `butt_dial_provisioned` flag, default `false`
- [ ] `butt_dial_verified_at` timestamp, nullable
- [ ] `butt_dial_failure_counter`, with a documented "reset on upstream-fix" procedure

### Webhook receiver
- [ ] `POST /api/webhooks/butt-dial/account-verified` mounted at the URL passed to BD
- [ ] Signature verified over **raw bytes**
- [ ] Dedup table on `X-BD-Delivery-Id`
- [ ] 2xx response within 10s (queue long work)
- [ ] On success: persists `teamToken`, flips `provisioned=true`, sets `verifiedAt`

### Response shape
- [ ] Frontend gets `orgId`, `verificationSent`, `pollToken` only
- [ ] **Never** returns `webhookSecret` or `teamToken` in any response

If all 21 boxes are ticked, the integration follows the canonical pattern.

---

## See also

- [`AGENTS.md`](../AGENTS.md) — agent-readable contract for the SDK call itself
- [`examples/with-onboarding-handshake/`](../examples/with-onboarding-handshake/) — working FastAPI/Express implementation
- [`docs/BD_SERVER_STATUS_AS_OF_R6.md`](BD_SERVER_STATUS_AS_OF_R6.md) — current state of the BD server-side audit
