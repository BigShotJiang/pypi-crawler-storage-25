# BD Server — Consolidated Status (post-round-7)

<!-- version: 1.1 | updated: 2026-04-29 -->

**As of:** 2026-04-29, after round-7 live verification of BD sprint 11/12 closures
**Server:** `https://call.95percent.ai` (commit `59cbce8` per BD's round-6 follow-up)
**SDK:** `butt-dial-sdk==0.4.4`

This document consolidates the status of every finding (F01–F92) across rounds 1–7. Round 7 was a verification sweep against BD's round-6 follow-up claims, plus the SDK-side close of F90.

---

## Headline

```
✅ FIXED                  : 58 / 92   (63%)   +9 since v1.0
⚠️ PARTIAL                :  9 / 92   (10%)   no change
❌ OPEN                   : 21 / 92   (23%)   −7
🚫 WONTFIX-BY-DESIGN      :  2 / 92    (2%)   F77, F40
ℹ️ INFO / architectural   :  2 / 92    (2%)   −2 (resolved)
```

**Round 7 closed (verified live):** F21, F29, F40 (wontfix), F58 (audit error correction), F81, F84, F89, F90, F92.

**SDK-side closed today:** F90 (`SendResult.error_code` + `NoChannelAssigned` exception, shipped in 0.4.4).

**30 items still need attention** (21 OPEN + 9 PARTIAL).

---

## Round 7 verification — every BD claim confirmed live

Ran `scripts/probe_round7.py` against `call.95percent.ai`:

| ID | BD claim | r7 evidence | Status |
|---|---|---|---|
| **F21** | `serverInfo.version` 0.1.0 → 1.0.0 | MCP `initialize()` returned `version='1.0.0'` | ✅ |
| **F84** | OpenAPI title now `"Butt-Dial — REST API"`, VOS purged | `GET /openapi.json` → `info.title='Butt-Dial — REST API'` | ✅ |
| **F89** | `webhookSecret` symmetric across pending vs verified email | Both responses contain `webhookSecret`; same key set | ✅ |
| **F90** | `code: NO_CHANNEL_ASSIGNED` in send error envelope | Raw response: `{"error": "...", "code": "NO_CHANNEL_ASSIGNED", "channel": "whatsapp", "remediation": "..."}` | ✅ (server side) |
| **F92** | `/docs/mcp-tools` 4-tier scope vocabulary | All four labels present: `agent`, `org-admin`, `super-admin`, `any` | ✅ |
| **F29** | REST error strings swept `Client → Agent` | Probe error message: `'Agent "d51b0eb9-..." has no WhatsApp sender assigned'` | ✅ |

---

## SDK-side closures shipped in this round

### F90 — closed in 0.4.4

`SendResult` gained two new fields:
- `SendResult.error_code` — populated from BD's `code` field. Switch on this instead of substring-matching `error`.
- `SendResult.error_channel` — populated from BD's `channel` field.
- `SendResult.remediation` — server-supplied value preferred over SDK's curated map (when present).

New typed exception `buttdial.NoChannelAssigned(ChannelError)` raises from `AccountsClient` REST calls. For MCP sends, failures continue to report via `SendResult` (no raise). Wired into `parse_error_response` and `Agent._extract_error_envelope`. 8 new tests; 235 total passing.

### F40 — closed WONTFIX-BY-DESIGN

`comms_` prefix on all 57 MCP tools is the BD namespace (de-conflicts with other MCP servers an integrator might mount alongside). BD documented the convention in `/docs/mcp-tools`. No code change.

### F58 — closed (audit error correction)

The 13 typed WhatsApp tools were already shipped in BD sprint 8; the round-5 audit kept F58 open because the dispatcher (`comms_whatsapp_action`) still appeared in the tool list. The dispatcher is the [DEPRECATED] shim per BD's standard sunset policy. SDK-side TODO for 0.5.0: switch the 13 typed wrappers in `src/buttdial/agent.py` to call the per-action tools directly (frees the SDK from the deprecated shim before sunset).

---

## F04 strengthening (bonus from BD)

Silent-treatment dedup now resolves the email through `user_accounts` in addition to `organizations.owner_email`. Closed a duplicate-org leak that hit BD today: an old `user_accounts` row + a new register call with the same email used to produce two parallel orgs. F04 was already FIXED in sprint 10; this is an additional hardening.

---

## ❌ OPEN (21 items)

**Quick wins (≤ 1 hour):** F75 (`retryAfter`/`retry_after` snake_case sunset — calendar-driven, 2026-07-27), F73 (already FIXED in r6 — confirmed).

**Casing & naming:** F55 (mixed "client"/"agent"/"provider" vocab in docs — needs separate doc-update pass).

**MCP improvements:** F59 (`orchestrator` enum leaks internal IDs), F61 (Zod-stringified validation errors), F67 (`country` ambiguous), F68 (`body` required-conditional schema).

**Lifecycle:** F05 (`verificationSent` sync-optimism), F27 (no `lifecycleState` enum field), F34 (no lifecycle-event webhooks beyond `account.verified`), F31-headers (no `RateLimit-*` headers on success), F24 (no emergency token-revocation endpoint).

**Endpoint completeness:** F15 (DELETE org), F16 (list orgs I own), F39 (redundant `success: true`).

**Information architecture:** F79 (system agent undocumented), F83 (`/agents` not in OpenAPI — uses `/clients/{agentId}`), F86 (three parallel surfaces — admin REST + customer REST + MCP).

**Strategic:** F06 (org-name squatting — needs product decision), F13 (SDK `verify()` docstring drift — SDK side), F57 (SDK `provision_channels` list-shape — SDK side).

**Round 6:** F90 — closed today (this section).

---

## ⚠️ PARTIAL (9 items)

F04 (deterministic orgId still leaks pre-rate-limit; mitigated by F02 + the F04 strengthening above), F10, F20, F30, F36, F42, F54, F66, F78, F85.

---

## 🚫 WONTFIX-BY-DESIGN (2 items)

- **F77** — `EmailAlreadyRegistered` 409 closed by F04 anti-enumeration precedence.
- **F40** — `comms_` prefix is the BD namespace. Documented in `/docs/mcp-tools`.

---

## Recommended next BD work

Most remaining items are calendar-driven (F75 sunset window) or product-input-blocked (F06, F84-already-decided, F86). The "actionable now" subset:

1. **F61** — Zod errors via JSON-RPC `data` field (LLM-agent ergonomics)
2. **F27** — explicit `lifecycleState` enum on agent/org records
3. **F34** — extend the F26 webhook to additional event types (token rotated, channel suspended, billing alert)
4. **F83** — include `/api/v1/agents` paths in OpenAPI (or document `/clients/{agentId}` migration)

Everything else can wait for product input or a calendar trigger.

---

## SDK-side follow-ups for 0.5.0

- **F58 typed-tool migration** — rewrite the 13 typed WhatsApp wrappers in `src/buttdial/agent.py` to call `comms_whatsapp_react` etc directly instead of routing through the [DEPRECATED] dispatcher.
- **F21 connect-time logging** — log the negotiated `serverInfo.version` on first MCP connect so future regressions are visible.
- **F13** — SDK `verify()` docstring (`mode` → `scopes`).
- **F57** — SDK `provision_channels` list-shape cleanup.

---

## References

- Round 7: `scripts/probe_round7.py`, `docs/round7_live_results.json`, `docs/BD_SERVER_FEEDBACK_6.md` (round-6 baseline + F90/F91 filing)
- Round 6: `docs/BD_SERVER_FEEDBACK_6.md`
- Round 5 (full F-list): `docs/BD_SERVER_FEEDBACK_5.md`
- Sprint 9 BD response: `docs/BD_SERVER_HANDSHAKE_SHIPPED.md`
- Earlier rounds: `docs/BD_SERVER_FEEDBACK.md`, `_2.md`, `_3.md`, `_4.md`
- SDK live: `https://pypi.org/project/butt-dial-sdk/0.4.4/`
