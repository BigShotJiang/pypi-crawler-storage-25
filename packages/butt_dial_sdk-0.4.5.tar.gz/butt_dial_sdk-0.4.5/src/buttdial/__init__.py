"""butt-dial-sdk — client-side tunnel for the Butt-Dial communication service.

For agentic integrators (Claude Code / Cursor / Copilot / Codex / etc.):
    Run ``buttdial guide`` to print the full integration contract (AGENTS.md).
    Run ``buttdial example list`` to enumerate canonical patterns.
    Run ``buttdial example extract <name> <dir>`` to lift one into your project.
    Run ``buttdial errors`` for the typed-exception reference at debug time.
    Run ``buttdial doctor --to +1...`` for an end-to-end live integration check.

The integration guide ships inside this wheel — no internet round-trip
required. AGENTS.md lives at ``<this_module_path>/_docs/AGENTS.md``;
canonical examples at ``<this_module_path>/_examples/``.
"""

from buttdial.accounts import (
    AccountsClient,
    AccountsError,
    ChallengeNotFound,
    EmailAlreadyRegistered,
    OnboardingRequired,
    OTPExpired,
    OTPInvalid,
    OTPMaxAttempts,
    PhoneNotConfigured,
    TokenRevoked,
    VerificationTokenExpired,
)
from buttdial.agent import Agent
from buttdial.doctor import find_remediation, run_diagnostic
from buttdial.errors import (
    AuthError,
    AuthInvalidTokenError,
    AuthLockedOutError,
    AuthMissingHeaderError,
    AuthTokenRevokedError,
    ButtDialError,
    ChannelError,
    ConfigError,
    NoChannelAssigned,
    NotProvisioned,
    ProviderCapabilityError,
    RateLimitError,
    RevokedToken,
    TransportError,
    parse_error_response,
)
from buttdial.inbound import InboundHandler
from buttdial.models import (
    AgentInfo,
    Channel,
    DeliveryReceipt,
    DoctorReport,
    DoctorStage,
    FailedMessage,
    InboundMessage,
    OverviewSnapshot,
    SendResult,
    StatusUpdate,
)
from buttdial.retry import (
    FailedMessageRepository,
    RetryWorker,
    default_backoff,
)
from buttdial.router import (
    AdminFailedMessageRepository,
    AgentDirectory,
    AgentNotFound,
    AgentNotProvisioned,
    make_router,
)

__version__ = "0.4.5"

__all__ = [
    "Agent",
    "InboundHandler",
    "RetryWorker",
    "FailedMessageRepository",
    "default_backoff",
    "make_router",
    "AgentDirectory",
    "AdminFailedMessageRepository",
    "AgentNotFound",
    "AgentNotProvisioned",
    "ButtDialError",
    "ConfigError",
    "TransportError",
    # Auth + rate-limit + channel errors (parsed from BD's machine-readable
    # error envelope; see docs/SPEC.md "Auth error contract").
    "AuthError",
    "AuthInvalidTokenError",
    "AuthLockedOutError",
    "AuthMissingHeaderError",
    "AuthTokenRevokedError",
    "ChannelError",
    "ProviderCapabilityError",
    "NotProvisioned",
    "NoChannelAssigned",
    "RateLimitError",
    "RevokedToken",
    "parse_error_response",
    # Accounts (onboarding + token rotation)
    "AccountsClient",
    "AccountsError",
    "EmailAlreadyRegistered",
    "OnboardingRequired",
    "VerificationTokenExpired",
    "PhoneNotConfigured",
    "OTPInvalid",
    "OTPExpired",
    "OTPMaxAttempts",
    "ChallengeNotFound",
    "TokenRevoked",
    "Channel",
    "SendResult",
    "FailedMessage",
    "InboundMessage",
    "DeliveryReceipt",
    "StatusUpdate",
    "AgentInfo",
    "OverviewSnapshot",
    "DoctorReport",
    "DoctorStage",
    "run_diagnostic",
    "find_remediation",
    "__version__",
]
