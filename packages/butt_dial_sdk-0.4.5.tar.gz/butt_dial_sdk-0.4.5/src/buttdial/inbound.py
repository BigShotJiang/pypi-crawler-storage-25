"""Inbound callbacks — webhook parsing + dispatch.

Normalizes channel-specific webhook payloads (WhatsApp envelopes, Butt-Dial
generic format) into typed `InboundMessage`, `DeliveryReceipt`, and
`StatusUpdate` events, then dispatches to host-registered handlers.

Ported from iv-bknd/api/routes/webhook.py. Two behavioral upgrades over
iv-bknd:

- WhatsApp **statuses** envelope (delivery receipts) is parsed into
  `DeliveryReceipt` events. iv-bknd silently ignores it today — this is a
  documented TODO there. Hosts can register `@handler.on_delivery_receipt()`
  to consume them.
- Handler errors are isolated: one handler raising does not prevent the
  others from running. iv-bknd's single-path handler crashes the whole
  webhook on any error.

`fastapi` is an optional dependency — imported lazily when `.router` is
accessed. Core parsing + dispatch works without it.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any

from buttdial.models import Channel, DeliveryReceipt, InboundMessage, StatusUpdate

# `fastapi` is an optional dependency — required only when building the router.
# Imported at module top so type hints on the router's inner handlers resolve
# via `typing.get_type_hints()` (which uses function __globals__). Without this,
# `request: Request` inside `_build_router` is treated as a query parameter.
try:
    from fastapi import APIRouter, HTTPException, Query, Request  # noqa: F401

    _FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover - import-time fallback
    APIRouter = None  # type: ignore[assignment,misc]
    HTTPException = None  # type: ignore[assignment,misc]
    Query = None  # type: ignore[assignment,misc]
    Request = None  # type: ignore[assignment,misc]
    _FASTAPI_AVAILABLE = False

logger = logging.getLogger(__name__)

MessageHandler = Callable[[InboundMessage], Awaitable[None]]
ReceiptHandler = Callable[[DeliveryReceipt], Awaitable[None]]
StatusHandler = Callable[[StatusUpdate], Awaitable[None]]

_WILDCARD = "*"


def _to_canonical_dict(msg: InboundMessage, *, kind: str) -> dict[str, Any]:
    """Project an InboundMessage into the spec-section-6 canonical dict.

    Used by :meth:`InboundHandler.parse` so static/one-shot callers get a
    plain dict regardless of which parser produced the underlying typed
    object. The shape mirrors BD's wire vocabulary (camelCase) so the
    output drops straight into JSON if the host needs to forward it.
    """
    return {
        "type": kind,
        "id": msg.id,
        "from": msg.sender,
        "to": msg.to,
        "channel": msg.channel,
        "body": msg.text,
        "mediaUrl": msg.media_url,
        "mediaType": msg.media_type,
        "isVoiceMessage": msg.is_voice_message,
        "voiceTranscription": msg.voice_transcription,
        "groupId": msg.group_id,
        "groupName": msg.group_name,
        "senderName": msg.sender_name,
    }


def _receipt_to_canonical(receipt: DeliveryReceipt) -> dict[str, Any]:
    """Project a DeliveryReceipt into the canonical dict shape."""
    return {
        "type": "delivery_receipt",
        "id": receipt.message_sid,
        "from": None,
        "to": None,
        "channel": None,
        "body": None,
        "mediaUrl": None,
        "mediaType": None,
        "isVoiceMessage": False,
        "voiceTranscription": None,
        "groupId": None,
        "groupName": None,
        "senderName": None,
        "deliveryStatus": receipt.status,
        "errorCode": receipt.error_code,
    }


class InboundHandler:
    """Registry + dispatcher for inbound webhook events.

    Lifecycle: construct once, register handlers via decorators, mount
    `.router` on a FastAPI app, serve. One `InboundHandler` per host app.
    """

    def __init__(
        self,
        *,
        whatsapp_verify_token: str | None = None,
        whatsapp_webhook_secret: str | None = None,
    ) -> None:
        self.whatsapp_verify_token = whatsapp_verify_token or ""
        self.whatsapp_webhook_secret = whatsapp_webhook_secret or ""
        self._message_handlers: dict[str, list[MessageHandler]] = {}
        self._receipt_handlers: list[ReceiptHandler] = []
        self._status_handlers: list[StatusHandler] = []
        self._router: Any = None  # cached, built lazily

    # ----- decorator registration ---------------------------------------

    def on_message(
        self, channel: Channel | None = None
    ) -> Callable[[MessageHandler], MessageHandler]:
        """Register a handler for inbound messages.

        `channel=None` (default) receives messages on all channels.
        `channel="whatsapp"` receives only WhatsApp messages, etc.
        """

        key: str = channel if channel else _WILDCARD

        def decorator(fn: MessageHandler) -> MessageHandler:
            self._message_handlers.setdefault(key, []).append(fn)
            return fn

        return decorator

    def on_delivery_receipt(self) -> Callable[[ReceiptHandler], ReceiptHandler]:
        """Register a handler for delivery receipts (WhatsApp statuses, etc.)."""

        def decorator(fn: ReceiptHandler) -> ReceiptHandler:
            self._receipt_handlers.append(fn)
            return fn

        return decorator

    def on_status_update(self) -> Callable[[StatusHandler], StatusHandler]:
        """Register a handler for channel / connection status events."""

        def decorator(fn: StatusHandler) -> StatusHandler:
            self._status_handlers.append(fn)
            return fn

        return decorator

    # ----- dispatch (error-isolated) ------------------------------------

    async def _dispatch_message(self, msg: InboundMessage) -> None:
        handlers = [
            *self._message_handlers.get(msg.channel, []),
            *self._message_handlers.get(_WILDCARD, []),
        ]
        for fn in handlers:
            try:
                await fn(msg)
            except Exception:
                logger.exception("inbound message handler raised; continuing")

    async def _dispatch_receipt(self, receipt: DeliveryReceipt) -> None:
        for fn in self._receipt_handlers:
            try:
                await fn(receipt)
            except Exception:
                logger.exception("delivery receipt handler raised; continuing")

    async def _dispatch_status(self, status: StatusUpdate) -> None:
        for fn in self._status_handlers:
            try:
                await fn(status)
            except Exception:
                logger.exception("status update handler raised; continuing")

    # ----- verification -------------------------------------------------

    def verify_whatsapp_subscription(self, mode: str, token: str) -> bool:
        """True if Meta's subscription challenge is valid.

        Meta sends `GET /webhook?hub.mode=subscribe&hub.verify_token=...&hub.challenge=...`
        during webhook setup. The host echoes the challenge back on success.
        """
        if not self.whatsapp_verify_token:
            return False
        return mode == "subscribe" and token == self.whatsapp_verify_token

    def verify_whatsapp_signature(self, body: bytes, signature_header: str) -> bool:
        """Verify HMAC-SHA256 `X-Hub-Signature-256` header against the raw body.

        Returns True if the configured secret is empty (dev/test mode).
        Returns True on match. Returns False on mismatch.
        """
        if not self.whatsapp_webhook_secret:
            return True
        expected = (
            "sha256="
            + hmac.new(
                self.whatsapp_webhook_secret.encode(),
                body,
                hashlib.sha256,
            ).hexdigest()
        )
        return hmac.compare_digest(signature_header or "", expected)

    # ----- payload parsers ---------------------------------------------

    # ----- unified parse entry-point -----------------------------------

    @staticmethod
    def parse(envelope: dict[str, Any]) -> dict[str, Any] | None:
        """Normalize any inbound envelope into a single canonical dict.

        Auto-detects the shape (WhatsApp Cloud `messages` envelope, WA
        `statuses` envelope, BD-normalized generic, or echo of an
        outbound) and returns a dict with these keys (None when not
        applicable):

            id, from, to, channel, body, mediaUrl, mediaType,
            isVoiceMessage, voiceTranscription, groupId, groupName,
            senderName

        Plus the discriminator key:

            type — "message" | "delivery_receipt" | "status_update" | "echo"

        Returns None when the envelope cannot be classified.

        This is the static one-shot helper. Hosts that want event
        dispatch should keep using ``handle_whatsapp_payload`` /
        ``handle_generic_payload`` (they call into the same parsers).
        """
        # WhatsApp Cloud envelope (entry → changes → value).
        if isinstance(envelope.get("entry"), list):
            for entry in envelope.get("entry", []):
                for change in entry.get("changes", []) or []:
                    value = change.get("value") or {}
                    for raw_msg in value.get("messages") or []:
                        msg = InboundHandler._parse_whatsapp_message(raw_msg)
                        if msg is not None:
                            return _to_canonical_dict(msg, kind="message")
                    for raw_status in value.get("statuses") or []:
                        receipt = InboundHandler._parse_whatsapp_status(raw_status)
                        if receipt is not None:
                            return _receipt_to_canonical(receipt)
            return None

        # Echo of an outbound — BD includes "echo": true on its own
        # webhook re-emission so hosts can ignore loopbacks.
        if envelope.get("echo") is True or envelope.get("isEcho") is True:
            sender = envelope.get("from") or envelope.get("sender") or ""
            return {
                "type": "echo",
                "id": envelope.get("id"),
                "from": sender,
                "to": envelope.get("to"),
                "channel": envelope.get("channel", "whatsapp"),
                "body": envelope.get("body") or envelope.get("text"),
                "mediaUrl": envelope.get("mediaUrl") or envelope.get("media_url"),
                "mediaType": envelope.get("mediaType") or envelope.get("media_type"),
                "isVoiceMessage": bool(
                    envelope.get("isVoiceMessage") or envelope.get("is_voice_message")
                ),
                "voiceTranscription": envelope.get("voiceTranscription")
                or envelope.get("voice_transcription"),
                "groupId": envelope.get("groupId") or envelope.get("group_id"),
                "groupName": envelope.get("groupName") or envelope.get("group_name"),
                "senderName": envelope.get("senderName") or envelope.get("sender_name"),
            }

        # Delivery receipt in BD-normalized format (no WA wrapper).
        if envelope.get("status") in (
            "queued",
            "sent",
            "delivered",
            "read",
            "failed",
            "undelivered",
        ):
            sid = envelope.get("messageId") or envelope.get("message_sid") or envelope.get("id")
            if sid:
                return {
                    "type": "delivery_receipt",
                    "id": sid,
                    "from": envelope.get("from"),
                    "to": envelope.get("to"),
                    "channel": envelope.get("channel"),
                    "body": None,
                    "mediaUrl": None,
                    "mediaType": None,
                    "isVoiceMessage": False,
                    "voiceTranscription": None,
                    "groupId": None,
                    "groupName": None,
                    "senderName": None,
                    "deliveryStatus": envelope.get("status"),
                }

        # Generic BD-normalized message (SMS/email/voice/whatsapp without WA wrapper).
        sender = envelope.get("from") or envelope.get("sender")
        body = envelope.get("body") or envelope.get("text")
        media_url = envelope.get("mediaUrl") or envelope.get("media_url")
        if sender and (body or media_url):
            return {
                "type": "message",
                "id": envelope.get("id"),
                "from": sender,
                "to": envelope.get("to"),
                "channel": envelope.get("channel", "whatsapp"),
                "body": body,
                "mediaUrl": media_url,
                "mediaType": envelope.get("mediaType") or envelope.get("media_type"),
                "isVoiceMessage": bool(
                    envelope.get("isVoiceMessage") or envelope.get("is_voice_message")
                ),
                "voiceTranscription": envelope.get("voiceTranscription")
                or envelope.get("voice_transcription"),
                "groupId": envelope.get("groupId") or envelope.get("group_id"),
                "groupName": envelope.get("groupName") or envelope.get("group_name"),
                "senderName": envelope.get("senderName") or envelope.get("sender_name"),
            }

        return None

    async def handle_whatsapp_payload(self, payload: dict[str, Any]) -> dict[str, int | str]:
        """Parse WhatsApp Cloud API webhook envelope and dispatch events.

        Handles both `messages` (inbound chats) and `statuses` (delivery
        receipts). Returns a summary suitable for returning from an HTTP
        handler — matches iv-bknd's return shape (`{status, messages}`)
        with `receipts` added.
        """
        messages_processed = 0
        receipts_processed = 0
        for entry in payload.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value") or {}
                for raw_msg in value.get("messages") or []:
                    msg = self._parse_whatsapp_message(raw_msg)
                    if msg is not None:
                        await self._dispatch_message(msg)
                        messages_processed += 1
                for raw_status in value.get("statuses") or []:
                    receipt = self._parse_whatsapp_status(raw_status)
                    if receipt is not None:
                        await self._dispatch_receipt(receipt)
                        receipts_processed += 1
        return {
            "status": "processed",
            "messages": messages_processed,
            "receipts": receipts_processed,
        }

    @staticmethod
    def _parse_whatsapp_message(msg: dict[str, Any]) -> InboundMessage | None:
        sender = msg.get("from", "")
        if not sender:
            return None
        msg_type = msg.get("type", "text")

        # Pull the per-type media block. WA Cloud nests media metadata
        # under the type name (`image`, `audio`, `video`, `document`).
        media_block: dict[str, Any] = {}
        media_url: str | None = None
        media_type: str | None = None
        is_voice = False
        voice_transcription: str | None = None

        if msg_type == "text":
            text = (msg.get("text") or {}).get("body", "")
        elif msg_type == "interactive":
            text = json.dumps(msg.get("interactive") or {})
        elif msg_type in ("image", "audio", "video", "document", "sticker"):
            media_block = msg.get(msg_type) or {}
            # WA gives a media `id` you have to resolve via the Graph API
            # to get a real URL; some BD-side normalizations pre-resolve
            # to `link` / `url`. Try both. Fall back to id so callers can
            # resolve themselves.
            media_url = media_block.get("link") or media_block.get("url") or media_block.get("id")
            media_type = media_block.get("mime_type") or media_block.get("mimeType")
            if msg_type == "audio":
                is_voice = bool(media_block.get("voice", False))
                voice_transcription = (
                    media_block.get("voiceTranscription")
                    or media_block.get("voice_transcription")
                    or media_block.get("transcription")
                )
            text = media_block.get("caption") or f"[{msg_type} message]"
        else:
            text = f"[{msg_type} message]"
        if not text:
            return None

        ts_raw = msg.get("timestamp")
        received_at: datetime | None = None
        if ts_raw:
            try:
                received_at = datetime.fromtimestamp(int(ts_raw), tz=UTC)
            except (ValueError, TypeError):
                received_at = None

        # WA Cloud puts contact display name under `contacts[0].profile.name`
        # at the entry/value level — but BD-normalized envelopes often
        # carry it inline as `sender_name` / `senderName` on the message.
        sender_name = (
            msg.get("sender_name")
            or msg.get("senderName")
            or ((msg.get("contact") or {}).get("name"))
        )

        # Group context — BD adds these for messages that arrived via a
        # WA group. Native WA Cloud doesn't expose them on the message
        # itself (groups aren't supported on Cloud API at this writing).
        group_id = msg.get("group_id") or msg.get("groupId")
        group_name = msg.get("group_name") or msg.get("groupName")

        # Recipient — `to` is added by BD on inbound webhook so the host
        # knows which provisioned number was hit.
        to = msg.get("to")

        return InboundMessage(
            id=msg.get("id"),
            sender=sender,
            to=to,
            channel="whatsapp",
            text=text,
            media_url=media_url,
            media_type=media_type,
            is_voice_message=is_voice,
            voice_transcription=voice_transcription,
            group_id=group_id,
            group_name=group_name,
            sender_name=sender_name,
            received_at=received_at,
            raw=msg,
        )

    @staticmethod
    def _parse_whatsapp_status(st: dict[str, Any]) -> DeliveryReceipt | None:
        sid = st.get("id")
        status = st.get("status")
        if not sid or status not in ("sent", "delivered", "read", "failed"):
            return None
        ts_raw = st.get("timestamp")
        timestamp: datetime | None = None
        if ts_raw:
            try:
                timestamp = datetime.fromtimestamp(int(ts_raw), tz=UTC)
            except (ValueError, TypeError):
                timestamp = None
        errors = st.get("errors") or []
        error_code: str | None = None
        if errors and isinstance(errors, list) and isinstance(errors[0], dict):
            code = errors[0].get("code")
            error_code = str(code) if code is not None else None
        return DeliveryReceipt(
            message_sid=sid,
            status=status,
            timestamp=timestamp,
            error_code=error_code,
            raw=st,
        )

    async def handle_generic_payload(self, payload: dict[str, Any]) -> dict[str, int | str]:
        """Parse Butt-Dial's generic inbound format (SMS / email / voice).

        Expected shape (normalized by the Butt-Dial server before reaching the
        host): ``{"from": str, "body": str, "channel": str, ...}``. Unknown
        fields are forwarded on `.raw`.

        Honors the canonical normalized fields if BD provides them:
        ``id``, ``to``, ``mediaUrl`` / ``media_url``, ``mediaType`` / ``media_type``,
        ``isVoiceMessage`` / ``is_voice_message``, ``voiceTranscription`` /
        ``voice_transcription``, ``groupId`` / ``group_id``,
        ``groupName`` / ``group_name``, ``senderName`` / ``sender_name``.
        """
        sender = payload.get("from") or payload.get("sender") or ""
        channel = payload.get("channel", "sms")
        text = payload.get("body") or payload.get("text") or ""

        # Voice notes can arrive with no body if transcription is empty
        # but a media URL is present. Treat that as a real message — the
        # host can decide whether to download/transcribe.
        media_url = payload.get("mediaUrl") or payload.get("media_url")
        if not text and media_url:
            text = "[media message]"
        if not sender or not text:
            return {"status": "ignored", "messages": 0}

        msg = InboundMessage(
            id=payload.get("id"),
            sender=sender,
            to=payload.get("to"),
            channel=channel,
            text=text,
            media_url=media_url,
            media_type=payload.get("mediaType") or payload.get("media_type"),
            is_voice_message=bool(payload.get("isVoiceMessage") or payload.get("is_voice_message")),
            voice_transcription=(
                payload.get("voiceTranscription") or payload.get("voice_transcription")
            ),
            group_id=payload.get("groupId") or payload.get("group_id"),
            group_name=payload.get("groupName") or payload.get("group_name"),
            sender_name=payload.get("senderName") or payload.get("sender_name"),
            thread_id=payload.get("thread_id"),
            raw=payload,
        )
        await self._dispatch_message(msg)
        return {"status": "processed", "messages": 1}

    # ----- router (lazy fastapi import) --------------------------------

    @property
    def router(self) -> Any:
        """FastAPI router for mounting. Requires `butt-dial-sdk[router]`."""
        if self._router is None:
            self._router = self._build_router()
        return self._router

    def _build_router(self) -> Any:
        if not _FASTAPI_AVAILABLE:  # pragma: no cover - exercised at install time
            raise ImportError(
                "InboundHandler.router requires fastapi. "
                "Install with: pip install 'butt-dial-sdk[router]'"
            )

        router = APIRouter()

        @router.get("/{channel}/verify")
        async def verify(  # type: ignore[no-untyped-def]
            channel: str,
            hub_mode: str = Query("", alias="hub.mode"),
            hub_verify_token: str = Query("", alias="hub.verify_token"),
            hub_challenge: str = Query("", alias="hub.challenge"),
        ):
            if channel != "whatsapp":
                raise HTTPException(
                    status_code=400, detail=f"Verify not supported for channel {channel!r}"
                )
            if not self.verify_whatsapp_subscription(hub_mode, hub_verify_token):
                raise HTTPException(status_code=403, detail="Verification failed")
            # Meta expects the challenge echoed back; it's typically numeric.
            return int(hub_challenge) if hub_challenge.isdigit() else hub_challenge

        @router.post("/{channel}")
        async def receive(channel: str, request: Request):  # type: ignore[no-untyped-def]
            body = await request.body()
            if channel == "whatsapp":
                sig = request.headers.get("X-Hub-Signature-256", "")
                if not self.verify_whatsapp_signature(body, sig):
                    raise HTTPException(status_code=403, detail="Invalid signature")
                try:
                    payload = json.loads(body) if body else {}
                except json.JSONDecodeError as e:
                    raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}") from e
                return await self.handle_whatsapp_payload(payload)
            if channel == "butt-dial":
                try:
                    payload = json.loads(body) if body else {}
                except json.JSONDecodeError as e:
                    raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}") from e
                return await self.handle_generic_payload(payload)
            logger.warning("unhandled webhook channel: %s", channel)
            return {"status": "ignored", "channel": channel}

        return router
