"""Typed exceptions for explicit failure handling.

Most SDK failures are *reported*, not raised — `SendResult.failed/error/
stage_failed/remediation` is the primary surface for outbound send failures
since callers want structured data, not a blown-up stack. This module
exists for the few cases where raising is the right choice:

- `ButtDialError` — base class for every exception the SDK raises
  intentionally. Catch this to handle any SDK-raised error in one block.
- `ConfigError` — misconfiguration the caller must fix (missing URL/token).
- `TransportError` — low-level connectivity failures the SDK couldn't wrap
  into a `SendResult`.
- `AuthError` and subclasses — 401 responses parsed from BD's machine-
  readable error envelope. Hosts catch these to react to invalid /
  revoked tokens immediately instead of retrying into a lockout.
- `AuthLockedOutError` — 429 specifically from auth lockout. Carries
  `retry_after_seconds` / `locked_until` so callers can wait or fail fast.
- `RateLimitError` — generic 429 (non-lockout). Carries `retry_after_seconds`
  when the server provided a `Retry-After` header.
- `ChannelError` — base class for per-channel failures (greenapi vs
  twilio capability gaps, missing channel provisioning, etc.).
- `ProviderCapabilityError` — `ChannelError` subclass: this provider
  cannot perform this action (e.g. greenapi cannot `post_status`). Raise
  this rather than returning a fake success so callers fall back to a
  different channel/provider.
- `NotProvisioned` — 410/404 from agent lifecycle endpoints (e.g.
  `/api/v1/agents/{id}`) when the agent has not been registered yet,
  or has been deregistered.
- `RevokedToken` — alias of `AuthTokenRevokedError`. Hosts that only
  care about the rotation/revocation case can `except RevokedToken`
  without importing the longer name.
- `AgentNotFound` / `AgentNotProvisioned` — raised by `AgentDirectory`
  implementations; the admin router maps them to HTTP 404 / 400.

`AgentNotFound` and `AgentNotProvisioned` also inherit from `KeyError` and
`ValueError` respectively, so existing Python idioms continue to work
without needing to import buttdial-specific classes.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any


class ButtDialError(Exception):
    """Base class for every exception the SDK raises on purpose.

    Carries optional `code`, `stage`, `remediation`, `status_code`, and
    `body` attributes so host apps can use a single error-handling
    pattern everywhere:

        try:
            ...
        except ButtDialError as e:
            log(
                code=e.code,
                status=e.status_code,
                stage=e.stage,
                body=e.body,
                remediation=e.remediation,
            )

    `status_code` is the HTTP status when the error was parsed from a
    response (None for SDK-internal errors like ConfigError).
    `body` is the raw decoded response body the SDK saw — kept so hosts
    can inspect provider-specific fields the SDK didn't surface.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        stage: str | None = None,
        remediation: str | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.remediation = remediation
        self.status_code = status_code
        self.body = body


class ConfigError(ButtDialError):
    """Raised when the SDK is misconfigured (missing URL, missing token, etc.)."""


class TransportError(ButtDialError):
    """Raised for connectivity / auth failures the SDK can't wrap into a SendResult."""


# ---------------------------------------------------------------------------
# Auth errors (401) — parsed from BD's machine-readable error envelope
# ---------------------------------------------------------------------------


class AuthError(ButtDialError):
    """Base class for BD authentication errors (HTTP 401).

    BD returns a structured envelope on auth failure:

        {
          "error": "Invalid or revoked token",
          "code": "AUTH_INVALID_TOKEN",
          "retryable": false,
          "remainingAttempts": 7
        }

    `remaining_attempts` is the lockout countdown for THIS IP. Once
    exhausted (10 fails), the server returns 429 with `AUTH_LOCKED_OUT`
    and a `Retry-After` header — see :class:`AuthLockedOutError`.

    `retryable` is always `False` for AuthError subclasses (`True` would
    be `AuthLockedOutError` instead). Callers MUST NOT retry; they should
    surface the error to the operator and prompt for a fresh token.
    """

    #: Server-side `code` field this subclass maps to. Empty on the base.
    server_code: str = ""

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        retryable: bool = False,
        remaining_attempts: int | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            stage="auth",
            status_code=status_code,
            body=body,
        )
        self.retryable = retryable
        self.remaining_attempts = remaining_attempts


class AuthMissingHeaderError(AuthError):
    """No Authorization header was sent to BD. Caller misconfiguration."""

    server_code = "AUTH_MISSING_HEADER"


class AuthInvalidTokenError(AuthError):
    """Token doesn't match any org/agent/orchestrator on the BD server.

    Usually means a typo or a token from the wrong environment. Re-prompt
    the operator for a fresh value.
    """

    server_code = "AUTH_INVALID_TOKEN"


class AuthTokenRevokedError(AuthError):
    """Token existed but was explicitly revoked.

    Most often because a successful rotation invalidated the previous
    value. The host should refresh from its vault / prompt re-auth.

    Aliased as :class:`RevokedToken` for ergonomic ``except RevokedToken:``
    handlers — they're the same class.
    """

    server_code = "AUTH_TOKEN_REVOKED"


#: Ergonomic alias of :class:`AuthTokenRevokedError`. Use whichever name
#: reads better in your handler. ``isinstance(err, RevokedToken)`` works
#: identically because they reference the same class.
RevokedToken = AuthTokenRevokedError


class AuthLockedOutError(AuthError):
    """The IP is locked out of auth after too many failed attempts (429).

    Unlike its siblings, this one is `retryable=True` — but not before
    `locked_until`. Callers MUST honor `retry_after_seconds` (parsed from
    the `Retry-After` header or the body's `retryAfterSeconds`) before
    retrying. Don't naive-backoff a few seconds — the server enforces a
    15-minute lockout.
    """

    server_code = "AUTH_LOCKED_OUT"

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        retry_after_seconds: int | None = None,
        locked_until: datetime | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            retryable=True,
            status_code=status_code,
            body=body,
        )
        self.retry_after_seconds = retry_after_seconds
        self.locked_until = locked_until


# ---------------------------------------------------------------------------
# Generic 429 (non-lockout)
# ---------------------------------------------------------------------------


class RateLimitError(ButtDialError):
    """Raised on 429 Too Many Requests that is NOT an auth lockout.

    Carries `retry_after_seconds` (from the `Retry-After` header, or the
    body's `retryAfterSeconds`) so callers can sleep before retrying.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        retry_after_seconds: int | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            stage="rate_limit",
            status_code=status_code,
            body=body,
        )
        self.retry_after_seconds = retry_after_seconds


# ---------------------------------------------------------------------------
# Per-provider capability errors
# ---------------------------------------------------------------------------


class ChannelError(ButtDialError):
    """Base class for per-channel failures.

    Subclasses cover specific shapes:

    - :class:`ProviderCapabilityError` — provider X does not implement
      action Y (e.g. greenapi cannot `post_status`).
    - :class:`NotProvisioned` — the agent's number/channel is not
      provisioned on BD yet (404/410 from agent lifecycle endpoints
      such as `/api/v1/agents/{id}`).

    Use the subclasses when raising new errors; this base exists for
    `except ChannelError:` blanket handlers and forward-compat.
    """

    def __init__(
        self,
        message: str,
        *,
        channel: str | None = None,
        action: str | None = None,
        code: str | None = None,
        provider: str | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            stage="channel",
            status_code=status_code,
            body=body,
        )
        self.channel = channel
        self.action = action
        self.provider = provider


class ProviderCapabilityError(ChannelError):
    """Provider X cannot perform action Y on this channel.

    Example: greenapi rejects ``post_status``; only twilio supports it.
    Raise this rather than returning a fake success so callers can
    branch on ``(channel, action, provider)`` and pick a different
    sender.
    """


class NotProvisioned(ChannelError):
    """The agent / channel is not provisioned on BD yet.

    Raised on 404/410 from agent lifecycle endpoints
    (e.g. ``GET /api/v1/agents/{id}``) when the host has a
    ``team_token`` but the agent has not yet been registered (or was
    deregistered). Host should run the registration flow before retrying.
    """


class NoChannelAssigned(ChannelError):
    """The agent exists but has no provisioned channels (BD F90, sprint 12+).

    Server returns ``{"code": "NO_CHANNEL_ASSIGNED", "channel": "...",
    "remediation": "..."}`` when an agent registered via
    :meth:`AccountsClient.register_agent` tries to send before
    :meth:`AccountsClient.provision_channels` has assigned at least one
    sender. The remediation is "call /provision first".

    For ``Agent.send_message()`` this surfaces via
    ``SendResult(failed=True, error_code="NO_CHANNEL_ASSIGNED")`` rather
    than raising — sends report failure, they don't raise. Catch this
    class only on the REST/AccountsClient surface or when explicitly
    re-raising from a ``SendResult``.
    """

    server_code = "NO_CHANNEL_ASSIGNED"


# ---------------------------------------------------------------------------
# Accounts API base
# ---------------------------------------------------------------------------

# `AccountsError` is defined in `buttdial.accounts` so it can carry the
# accounts-specific `server_code` mapping. It also subclasses
# `ButtDialError`, so `except AccountsError:` and `except ButtDialError:`
# both work; tests in `tests/test_errors.py` lock that hierarchy.


# ---------------------------------------------------------------------------
# Code → exception mapping
# ---------------------------------------------------------------------------

# Lookup for `parse_error_response` to map server `code` to typed class.
_AUTH_ERROR_BY_CODE: dict[str, type[AuthError]] = {
    cls.server_code: cls
    for cls in (
        AuthMissingHeaderError,
        AuthInvalidTokenError,
        AuthTokenRevokedError,
        AuthLockedOutError,
    )
    if cls.server_code
}


def parse_error_response(
    *,
    status_code: int,
    body: Any,
    headers: dict[str, str] | None = None,
) -> ButtDialError:
    """Build the typed exception for a BD 4xx response.

    `body` is the parsed JSON dict (or anything else if parse failed —
    we tolerate that). `headers` is optional; when present, we honor
    `Retry-After` over `retryAfterSeconds` from the body since the
    HTTP-level header is the authoritative signal.

    Returns the exception. Caller decides whether to raise immediately
    or attach context first.
    """
    payload = body if isinstance(body, dict) else {}
    code = str(payload.get("code") or "")
    message = str(payload.get("error") or payload.get("message") or "") or (f"HTTP {status_code}")
    retryable = bool(payload.get("retryable"))

    # Retry-After header wins; fall back to body. Header is in seconds
    # (RFC 7231 also allows HTTP-date but BD always sends seconds).
    retry_after_seconds: int | None = None
    if headers:
        ra = headers.get("Retry-After") or headers.get("retry-after")
        if ra:
            try:
                retry_after_seconds = int(ra)
            except ValueError:
                retry_after_seconds = None
    if retry_after_seconds is None:
        body_ra = payload.get("retryAfterSeconds") or payload.get("retry_after_seconds")
        if body_ra is not None:
            try:
                retry_after_seconds = int(body_ra)
            except (ValueError, TypeError):
                retry_after_seconds = None

    locked_until: datetime | None = None
    raw_locked = payload.get("lockedUntil") or payload.get("locked_until")
    if raw_locked:
        try:
            # BD emits ISO-8601 with trailing Z; fromisoformat needs +00:00 on <3.11.
            locked_until = datetime.fromisoformat(str(raw_locked).replace("Z", "+00:00"))
        except ValueError:
            locked_until = None

    # 401 — auth error family. Pick subclass by `code`, else generic AuthError.
    if status_code == 401:
        cls = _AUTH_ERROR_BY_CODE.get(code, AuthError)
        if cls is AuthLockedOutError:  # pragma: no cover - server bug; lockout should be 429
            return AuthLockedOutError(
                message,
                code=code or None,
                retry_after_seconds=retry_after_seconds,
                locked_until=locked_until,
                status_code=status_code,
                body=body,
            )
        remaining = payload.get("remainingAttempts")
        try:
            remaining_int = int(remaining) if remaining is not None else None
        except (ValueError, TypeError):
            remaining_int = None
        return cls(
            message,
            code=code or None,
            retryable=retryable,
            remaining_attempts=remaining_int,
            status_code=status_code,
            body=body,
        )

    # 404/410 from /api/v1/agents lifecycle — agent not provisioned yet.
    # We can't tell from status alone whether this is a generic 404 or a
    # provisioning miss; the code field disambiguates: AGENT_NOT_PROVISIONED
    # / AGENT_NOT_FOUND / NOT_PROVISIONED.
    if status_code in (404, 410) and code in (
        "AGENT_NOT_PROVISIONED",
        "AGENT_NOT_FOUND",
        "NOT_PROVISIONED",
    ):
        return NotProvisioned(
            message,
            code=code or None,
            status_code=status_code,
            body=body,
        )

    # 429 — could be auth lockout (code=AUTH_LOCKED_OUT) or generic rate limit.
    if status_code == 429:
        if code == AuthLockedOutError.server_code:
            return AuthLockedOutError(
                message,
                code=code,
                retry_after_seconds=retry_after_seconds,
                locked_until=locked_until,
                status_code=status_code,
                body=body,
            )
        return RateLimitError(
            message,
            code=code or None,
            retry_after_seconds=retry_after_seconds,
            status_code=status_code,
            body=body,
        )

    # No channels assigned to this agent (BD F90, sprint 12+). Server returns
    # code=NO_CHANNEL_ASSIGNED with channel + remediation. Comes back on REST
    # send paths; the MCP send path surfaces this on SendResult instead of raising.
    if code == NoChannelAssigned.server_code:
        return NoChannelAssigned(
            message,
            code=code,
            channel=str(payload.get("channel") or "") or None,
            status_code=status_code,
            body=body,
        )

    # Provider capability rejection (e.g. greenapi cannot post_status).
    # BD signals this with code=PROVIDER_UNSUPPORTED or CHANNEL_UNSUPPORTED.
    if code in ("PROVIDER_UNSUPPORTED", "CHANNEL_UNSUPPORTED"):
        return ProviderCapabilityError(
            message,
            code=code or None,
            channel=str(payload.get("channel") or "") or None,
            action=str(payload.get("action") or "") or None,
            provider=str(payload.get("provider") or "") or None,
            status_code=status_code,
            body=body,
        )

    # Anything else 4xx/5xx — hand back a generic ButtDialError. The
    # accounts module overrides this for its own code mappings.
    return ButtDialError(
        message,
        code=code or None,
        status_code=status_code,
        body=body,
    )
