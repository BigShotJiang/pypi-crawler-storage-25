"""Pydantic models for the Butt-Dial SDK.

Typed data contract between the SDK and host apps. Wire-level (de)serialization
to Butt-Dial's MCP tools happens in `agent.py` and `inbound.py` — fields here
use Python-idiomatic snake_case; adapters translate to the server's camelCase.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

Channel = Literal["whatsapp", "sms", "email"]
SendStage = Literal["config", "transport", "session", "tool_call", "parse", "server"]
FailedStatus = Literal["pending", "delivered", "dead", "dismissed"]
ReceiptStatus = Literal["queued", "sent", "delivered", "read", "failed", "undelivered"]


class SendResult(BaseModel):
    """Outcome of a single `Agent.send_message()` call.

    `message_sid` is set when the Butt-Dial server acknowledged the send.
    `failed=True` means the SDK could not reach or be served by the server
    (after retries) or rejected the send before attempting it (e.g. missing
    token). Business-level delivery confirmation arrives separately via
    `DeliveryReceipt` on the inbound webhook.
    """

    model_config = ConfigDict(frozen=True)

    message_sid: str | None = None
    failed: bool = False
    error: str | None = None
    #: Machine-readable error code from BD's response envelope (0.4.4+).
    #: Populated when the server returns ``{"code": "...", ...}``. Use this
    #: for switching instead of substring-matching on ``error``. Common
    #: values: ``"NO_CHANNEL_ASSIGNED"`` (agent has no provisioned channels),
    #: ``"PROVIDER_CAPABILITY"``, ``"RATE_LIMITED"``.
    error_code: str | None = None
    #: Channel the failure happened on (when surfaced by the server).
    error_channel: str | None = None
    stage_failed: SendStage | None = None
    remediation: str | None = None
    raw: Any = None

    @property
    def ok(self) -> bool:
        """True if the server accepted the send. See class docstring on delivery."""
        return self.message_sid is not None and not self.failed

    @property
    def delivered(self) -> bool:
        """Alias for `.ok`. Kept for SPEC compatibility; use `.ok` in new code."""
        return self.ok


class FailedMessage(BaseModel):
    """A message in the host's dead-letter queue.

    `RetryWorker` fetches these from a `FailedMessageRepository` and retries
    them. Hosts convert to/from their ORM models at the repository boundary.
    """

    id: str
    recipient: str
    body: str
    channel: Channel = "whatsapp"
    agent_name: str = ""
    agent_token: str = ""
    thread_id: str | None = None
    entity_id: str | None = None
    reply_msg_id: str | None = None
    retry_count: int = 0
    max_retries: int = 5
    last_error: str | None = None
    status: FailedStatus = "pending"
    created_at: datetime | None = None
    next_retry_at: datetime | None = None
    resolved_at: datetime | None = None


class InboundMessage(BaseModel):
    """A message received from a human, normalized across channels.

    Fields beyond `sender / channel / text / thread_id / received_at` are
    optional and populated when the source webhook carries them. Hosts
    that previously read `text` continue to work; new code can rely on
    the canonical fields below.
    """

    # Server-assigned message ID. WhatsApp Cloud API sends this as `id`
    # on each inbound message; BD generic webhooks send it as `id` too.
    id: str | None = None

    sender: str = Field(..., description="Phone number / address of the human sender.")

    # Recipient (the org's number/email/etc). Useful when the host owns
    # multiple senders and needs to know which one was hit.
    to: str | None = None

    channel: Channel

    # Backward-compat: callers were reading `.text`. Keep it; `body` is
    # the canonical name going forward, populated alongside `text` so
    # both work.
    text: str

    @property
    def body(self) -> str:
        """Canonical alias for `text`. Use this in new code."""
        return self.text

    # Media attachments (image / audio / video / document).
    media_url: str | None = None
    media_type: str | None = None  # e.g. "image/jpeg", "audio/ogg", "video/mp4"

    # Voice notes — set when the inbound is an audio message that the
    # provider transcribed. `is_voice_message=True` even if the
    # transcription wasn't available, so callers can choose to download
    # the audio themselves.
    is_voice_message: bool = False
    voice_transcription: str | None = None

    # Group context (WhatsApp groups, future Discord/Slack channels).
    group_id: str | None = None
    group_name: str | None = None

    # Display name of the sender as their device reported it. Distinct
    # from `sender` (which is the phone/address).
    sender_name: str | None = None

    thread_id: str | None = None
    received_at: datetime | None = None
    raw: Any = None


class DeliveryReceipt(BaseModel):
    """Receipt from Butt-Dial for a previously sent message."""

    message_sid: str
    status: ReceiptStatus
    timestamp: datetime | None = None
    error_code: str | None = None
    raw: Any = None


class StatusUpdate(BaseModel):
    """Generic channel / connection status event (e.g. session expired, rate limited)."""

    kind: str
    detail: str | None = None
    timestamp: datetime | None = None
    raw: Any = None


class AgentInfo(BaseModel):
    """Per-agent summary returned by `AgentDirectory.list_agents()`."""

    id: str
    name: str
    has_token: bool
    whatsapp_number: str | None = None
    phone_number: str | None = None
    email: str | None = None
    status: Literal["active", "paused"] = "active"
    message_count: int = 0
    failed_count: int = 0
    last_activity: datetime | None = None


class OverviewSnapshot(BaseModel):
    """Counts the host provides for the `/overview` endpoint.

    SDK composes this with connection info (from `Agent`) and failed-queue
    size (from `AdminFailedMessageRepository.count_pending()`) to build the
    final dashboard response.
    """

    agents_provisioned: int = 0
    total_messages_sent: int = 0
    total_messages_failed: int = 0
    total_messages_received: int = 0


class DoctorStage(BaseModel):
    """One stage of a `buttdial doctor` diagnostic run."""

    name: str
    ok: bool
    detail: str | None = None
    remediation: str | None = None
    duration_ms: int | None = None


class DoctorReport(BaseModel):
    """Result of a full `buttdial doctor` end-to-end diagnostic run."""

    ok: bool = False
    stages: list[DoctorStage] = Field(default_factory=list)

    def summary(self) -> str:
        return "\n".join(
            f"[{'✓' if s.ok else '✗'}] {s.name}" + (f" — {s.detail}" if s.detail else "")
            for s in self.stages
        )
