"""Webhook signature verification for Butt-Dial server callbacks.

After a host registers via :meth:`buttdial.accounts.AccountsClient.register`
with a ``webhook_url``, BD POSTs ``account.verified`` (and other future
events) to that URL with these headers:

    X-BD-Event: account.verified
    X-BD-Timestamp: <unix-seconds>
    X-BD-Signature: hmac-sha256=<hex>
    X-BD-Delivery-Id: <uuid>

The signature is HMAC-SHA256 over ``f"{timestamp}.{raw_body}"`` keyed by
the ``webhook_secret`` returned in the register response. This module
exposes :func:`verify_webhook_signature` to validate the signature and
freshness in one call.

Idempotency / replay handling is the caller's responsibility — dedupe by
``X-BD-Delivery-Id``. Webhook events arriving more than ~5 minutes after
their signing timestamp are rejected by this verifier as stale.
"""

from __future__ import annotations

import hashlib
import hmac
import time

__all__ = ["verify_webhook_signature"]

_DEFAULT_TOLERANCE_SECONDS = 300


def verify_webhook_signature(
    raw_body: bytes,
    *,
    timestamp_header: str | None,
    signature_header: str | None,
    secret: str,
    tolerance_seconds: int = _DEFAULT_TOLERANCE_SECONDS,
    now: float | None = None,
) -> bool:
    """Return True iff the BD webhook signature is valid AND fresh.

    Signature scheme (Stripe-style)::

        signed_payload = f"{timestamp}.{raw_body.decode()}"
        sig = HMAC_SHA256(secret, signed_payload).hex()
        header = f"hmac-sha256={sig}"

    Args:
        raw_body: The raw HTTP request body bytes — exactly as received,
            before any JSON deserialization. Re-serializing the parsed
            body will not produce the same digest.
        timestamp_header: Value of the ``X-BD-Timestamp`` header (a
            unix-second integer as a string).
        signature_header: Value of the ``X-BD-Signature`` header
            (e.g. ``"hmac-sha256=abc123..."``).
        secret: The ``webhook_secret`` captured from the register call.
        tolerance_seconds: Max age before the timestamp is rejected as
            stale. Default 5 minutes; tighten for higher-stakes flows.
        now: Override the current time (testing only).

    Returns:
        True if the signature matches and the timestamp is within the
        tolerance window; False otherwise. Returns False rather than
        raising for any malformed / missing input — the caller should
        respond ``401`` (or simply ``200`` to ack-and-drop) on False.
    """
    if not signature_header or not timestamp_header or not secret:
        return False
    if not signature_header.startswith("hmac-sha256="):
        return False

    received = signature_header.split("=", 1)[1].strip()
    if not received:
        return False

    try:
        ts = int(timestamp_header)
    except (TypeError, ValueError):
        return False

    current = time.time() if now is None else now
    if abs(current - ts) > tolerance_seconds:
        return False

    try:
        body_text = raw_body.decode("utf-8")
    except UnicodeDecodeError:
        return False

    signed_payload = f"{ts}.{body_text}".encode()
    expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()

    return hmac.compare_digest(expected, received)
