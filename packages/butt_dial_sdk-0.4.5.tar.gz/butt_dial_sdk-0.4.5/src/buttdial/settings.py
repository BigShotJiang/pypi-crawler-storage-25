"""Env-var config loader.

Reads Butt-Dial connection parameters from the environment. Hosts can also
pass values directly to ``Agent(...)`` or ``AccountsClient(...)`` —
settings are a convenience, not required. Uses ``pydantic-settings`` so
hosts already using a ``.env`` file get free compatibility.
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Butt-Dial SDK settings — three credential tiers.

    Reads:

    - ``BUTT_DIAL_URL``        — MCP/SSE endpoint of the Butt-Dial server.
    - ``BUTT_DIAL_BASE_URL``   — REST base URL (no path). Falls back to
      ``BUTT_DIAL_URL`` with ``/sse`` stripped.
    - ``BUTT_DIAL_AGENT_ID``   — host-chosen agent UUID. The SDK does not
      generate this; the host picks it and tells BD at registration.
    - ``BUTT_DIAL_AGENT_TOKEN`` — per-agent runtime bearer token (used by
      ``Agent`` for sending/receiving on its own number).
    - ``BUTT_DIAL_TEAM_TOKEN`` — workspace/org admin token (used by
      ``AccountsClient`` for ``/api/orgs/*`` and ``/api/v1/agents``
      lifecycle: provisioning, billing, agent registration).

    Also reads from a ``.env`` file in the current working directory when present.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    url: str = Field(default="", validation_alias="BUTT_DIAL_URL")
    base_url: str = Field(default="", validation_alias="BUTT_DIAL_BASE_URL")
    agent_id: str = Field(default="", validation_alias="BUTT_DIAL_AGENT_ID")
    agent_token: str = Field(default="", validation_alias="BUTT_DIAL_AGENT_TOKEN")
    team_token: str = Field(default="", validation_alias="BUTT_DIAL_TEAM_TOKEN")


def load() -> Settings:
    """Load settings from the environment / ``.env``."""
    return Settings()
