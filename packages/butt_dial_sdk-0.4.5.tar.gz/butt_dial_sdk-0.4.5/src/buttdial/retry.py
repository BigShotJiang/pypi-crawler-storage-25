"""Retry worker for the Butt-Dial dead-letter queue.

Ported from iv-bknd/engine/comms_retry_worker.py. Preserves the three-state
transition logic (pending → delivered | dead | pending-with-backoff) and the
`2^n` minute backoff schedule. All persistence is delegated to a host-provided
`FailedMessageRepository` — the SDK never opens a DB connection.

Two upgrades over iv-bknd:

- **Pluggable backoff.** iv-bknd hardcodes `2^retry_count` minutes. SDK
  defaults to the same, but accepts a `backoff: Callable[[int], timedelta]`
  override.
- **`on_dead_letter` callback.** iv-bknd inlines `observability.event_log.emit`.
  SDK exposes a host-registered async callback; errors are isolated so a
  broken alerting path doesn't stall the worker.

Host responsibility:

- Implement `FailedMessageRepository` against its own DB.
- The host's `mark_delivered` impl is also where it should update any
  cross-reference tables (iv-bknd updates `conversation_messages.message_sid`
  there — the SDK does not know about that table).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta
from typing import Protocol, runtime_checkable

from buttdial.agent import Agent
from buttdial.models import FailedMessage

logger = logging.getLogger(__name__)

BackoffFn = Callable[[int], timedelta]
DeadLetterHook = Callable[[FailedMessage, str], Awaitable[None]]


def default_backoff(retry_count: int) -> timedelta:
    """`2^retry_count` minutes. Matches iv-bknd: 2m, 4m, 8m, 16m, 32m."""
    return timedelta(minutes=2**retry_count)


@runtime_checkable
class FailedMessageRepository(Protocol):
    """Host-owned persistence for the dead-letter queue.

    The SDK calls these methods in a strict order:

    1. `fetch_due(limit)` once per `run_once()` pass.
    2. For each returned message, exactly one of: `mark_delivered`,
       `increment_retry`, or `mark_dead`.

    Implementations should be transactional per call. The SDK does not
    coordinate across calls; concurrent workers must coordinate at the DB
    level (e.g. `SELECT ... FOR UPDATE SKIP LOCKED`) if deployed.
    """

    async def fetch_due(self, limit: int) -> list[FailedMessage]:
        """Return pending messages whose `next_retry_at` has passed.

        Ordered by `next_retry_at` ascending, up to `limit`.
        """
        ...

    async def mark_delivered(self, msg_id: str, message_sid: str, retry_count: int) -> None:
        """Mark the message as successfully delivered.

        Host implementations typically also update any cross-reference table
        (e.g. `conversation_messages.message_sid`) inside the same transaction.
        """
        ...

    async def increment_retry(
        self,
        msg_id: str,
        retry_count: int,
        error: str,
        next_retry_at: datetime,
    ) -> None:
        """Record a failed attempt; schedule the next try at `next_retry_at`."""
        ...

    async def mark_dead(self, msg_id: str, retry_count: int, error: str) -> None:
        """Transition the message to the terminal `dead` state."""
        ...


class RetryWorker:
    """Orchestrates retry attempts against a `FailedMessageRepository`."""

    def __init__(
        self,
        repo: FailedMessageRepository,
        client: Agent,
        *,
        backoff: BackoffFn = default_backoff,
        batch_size: int = 20,
        on_dead_letter: DeadLetterHook | None = None,
    ) -> None:
        self.repo = repo
        self.client = client
        self.backoff = backoff
        self.batch_size = batch_size
        self.on_dead_letter = on_dead_letter
        self._task: asyncio.Task[None] | None = None
        self._running: bool = False

    async def run_once(self) -> int:
        """One pass: fetch due messages, retry each, update via repo.

        Returns the count processed. Individual-message failures are logged
        but do not abort the pass — a poisonous row cannot block the queue.
        """
        try:
            due = await self.repo.fetch_due(self.batch_size)
        except Exception:
            logger.exception("fetch_due failed; skipping this pass")
            return 0

        processed = 0
        for msg in due:
            try:
                await self._process_one(msg)
                processed += 1
            except Exception:
                logger.exception("retry worker: failed to process message %s", msg.id)
        return processed

    async def _process_one(self, msg: FailedMessage) -> None:
        next_count = msg.retry_count + 1
        logger.info(
            "retry: msg=%s attempt=%d/%d to=%s",
            msg.id,
            next_count,
            msg.max_retries,
            msg.recipient,
        )

        result = await self.client.send_message(
            to=msg.recipient,
            body=msg.body,
            channel=msg.channel,
            agent_token=msg.agent_token or None,
            sender_name=msg.agent_name or None,
            thread_id=msg.thread_id,
            entity_id=msg.entity_id,
            reply_msg_id=msg.reply_msg_id,
        )

        if result.message_sid:
            await self.repo.mark_delivered(msg.id, result.message_sid, next_count)
            logger.info("retry ok: msg=%s sid=%s", msg.id, result.message_sid)
            return

        error = result.error or "unknown"
        if next_count >= msg.max_retries:
            await self.repo.mark_dead(msg.id, next_count, error)
            logger.error("retry dead: msg=%s retries=%d error=%s", msg.id, next_count, error)
            if self.on_dead_letter is not None:
                try:
                    await self.on_dead_letter(msg, error)
                except Exception:
                    logger.exception("on_dead_letter hook raised for msg=%s; continuing", msg.id)
            return

        next_at = datetime.now(UTC) + self.backoff(next_count)
        await self.repo.increment_retry(msg.id, next_count, error, next_at)
        logger.info("retry backoff: msg=%s next_count=%d next_at=%s", msg.id, next_count, next_at)

    async def start(
        self,
        *,
        interval_seconds: float = 60.0,
        warmup_seconds: float = 30.0,
    ) -> None:
        """Start the background loop (non-blocking).

        Calling start() when already running is a no-op.
        """
        if self._task is not None and not self._task.done():
            return
        self._task = asyncio.create_task(
            self._loop(interval_seconds, warmup_seconds),
            name="buttdial-retry-worker",
        )

    async def stop(self) -> None:
        """Stop the background loop and await cancellation."""
        self._running = False
        if self._task is None:
            return
        self._task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self._task
        self._task = None

    async def _loop(self, interval: float, warmup: float) -> None:
        self._running = True
        if warmup > 0:
            await asyncio.sleep(warmup)
        while self._running:
            try:
                count = await self.run_once()
                if count > 0:
                    logger.info("retry worker: processed %d messages", count)
            except Exception:
                logger.exception("retry worker loop error")
            try:
                await asyncio.sleep(interval)
            except asyncio.CancelledError:
                break
