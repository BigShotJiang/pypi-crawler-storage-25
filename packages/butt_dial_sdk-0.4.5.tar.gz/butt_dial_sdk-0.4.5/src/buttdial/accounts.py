"""Butt-Dial account lifecycle — register, verify, phone setup, token rotation.

This module wraps the REST endpoints a third-party platform needs to onboard
a tenant onto Butt-Dial and manage their owner bearer token. It is deliberately
**separate** from :class:`buttdial.agent.Agent` (which handles MCP/SSE tool
calls) — accounts are a plain HTTP surface with different auth semantics.

Scope
-----
This module covers the **first-bearer-token lifecycle plus agent registration**.
Once a tenant has a team token and a configured admin phone, agents are
registered via :meth:`AccountsClient.register_agent` (host owns the
``agent_id`` UUID; BD echoes it back with a runtime token). Ongoing send/
receive work goes through :class:`buttdial.Agent` — not this module.

Auth modes
----------
- ``register`` / ``verify`` run **unauthenticated**. The verification token
  returned via email is the only secret needed to claim the owner token.
- Everything else requires the owner bearer token returned by ``verify``.
  Stale or rotated-out tokens produce ``TokenRevoked``, which the host app
  should interpret as "refresh my stored value, prompt re-auth if I don't
  have a new one".

Error handling
--------------
The server returns machine-readable codes in the JSON body
(``{"code": "OTP_INVALID", "message": "..."}``). We map each documented
code to a dedicated exception subclass so hosts can react with
``except OTPInvalid: ...`` instead of matching on strings.

Example
-------

.. code-block:: python

    from buttdial import AccountsClient

    accounts = AccountsClient("https://call.95percent.ai")

    r = await accounts.register("Acme Inc", "alice@acme.com")
    # ... user clicks the email link, deep-links back to your app with
    # ?verification=<token> ...
    info = await accounts.verify(verification_token)
    team_token = info["team_token"]

    # Authenticated calls now. Register your first agent — host owns the UUID.
    import uuid
    authed = AccountsClient("https://call.95percent.ai", team_token=team_token)
    agent_id = str(uuid.uuid4())  # or whatever your DB uses
    agent = await authed.register_agent(agent_id, display_name="Yuna")
    save_to_vault(agent["token"])  # this is the agent_token

    # Set the admin phone, confirm via SMS-delivered OTP.
    challenge = await authed.set_phone("+14155550123")
    otp = prompt_user("Enter the 6-digit code")  # host app's UI
    await authed.confirm_phone(challenge["challenge_id"], otp)

    # Later: rotate the owner token. Old token is revoked atomically.
    new = await authed.rotate_token(otp_prompt=lambda hint: prompt_user(
        f"Enter the code sent to {hint}"
    ))
    save_to_vault(new["token"])
"""

from __future__ import annotations

import logging
import uuid
import warnings
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from buttdial._http import check_deprecation_headers, user_agent
from buttdial.errors import (
    AuthLockedOutError,
    ButtDialError,
    ConfigError,
    TransportError,
    parse_error_response,
)

_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Typed error hierarchy
# ---------------------------------------------------------------------------


class AccountsError(ButtDialError):
    """Base class for Butt-Dial accounts-API errors.

    Carries the server-returned ``code`` (e.g. ``OTP_INVALID``) and the HTTP
    status. Subclasses are raised for each documented code so host apps can
    use ``except OTPInvalid:`` style handlers instead of inspecting the code.
    """

    #: Server-side code this subclass maps to. Empty on the base class.
    server_code: str = ""

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message, code=code, status_code=status_code, body=body)


class OnboardingRequired(AccountsError):
    """Verification succeeded but the user must accept Terms & Conditions in the browser.

    Sprint-20+ servers can return ``{teamToken: null, requiresOnboarding: true,
    orgId, onboardingSessionId, onboardingExpiresAt}`` from ``verify()``. The
    user has to land on a hosted onboarding page, accept TOS, then BD mints
    the ``team_token`` server-side. The SDK cannot bypass the TOS step — it
    raises this exception so the integrator can redirect the user to
    :attr:`onboarding_url`.

    For server-driven flows (no human in the loop), call
    ``POST /api/orgs/onboarding/accept`` with the recorded TOS version
    instead — but the integrator is responsible for surfacing the TOS to the
    user separately for that to be lawful.

    Attributes
    ----------
    org_id:
        The BD orgId the verify call resolved to. Persist this; it identifies
        the workspace even before the team_token is minted.
    onboarding_url:
        Where to redirect the user's browser to complete TOS acceptance.
    expires_at:
        ISO-8601 timestamp after which the onboarding session is invalid.
        Treat this as opaque; the host should not parse and re-emit.
    onboarding_session_id:
        Server-supplied session token. Pass to
        ``POST /api/orgs/onboarding/accept`` if completing programmatically.
    """

    server_code = "REQUIRES_ONBOARDING"

    def __init__(
        self,
        message: str = "Workspace verified but onboarding (TOS acceptance) required",
        *,
        org_id: str,
        onboarding_url: str,
        expires_at: str | None = None,
        onboarding_session_id: str | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(
            message,
            code="REQUIRES_ONBOARDING",
            status_code=200,
            body=body,
        )
        self.org_id = org_id
        self.onboarding_url = onboarding_url
        self.expires_at = expires_at
        self.onboarding_session_id = onboarding_session_id


class EmailAlreadyRegistered(AccountsError):
    """The email used in ``register`` already owns a Butt-Dial org.

    Intentionally unreachable today: the BD server uses F04 silent-treatment
    (same response shape for new vs existing email) to prevent email-existence
    enumeration. This class is preserved as a forward-compatibility hook for a
    future proof-of-ownership 409 pattern. See
    ``docs/BD_SERVER_INSTRUCTIONS_onboarding.md`` (v1.1) for the rationale.
    """

    server_code = "EMAIL_ALREADY_REGISTERED"


class VerificationTokenExpired(AccountsError):
    """The email-link verification token passed to ``verify`` is too old."""

    server_code = "VERIFICATION_TOKEN_EXPIRED"


class PhoneNotConfigured(AccountsError):
    """Rotate was requested but no admin phone has been set + confirmed yet.

    The host UI should redirect the admin to the phone-setup screen
    (``set_phone`` → OTP → ``confirm_phone``) and retry the rotation after.
    """

    server_code = "PHONE_NOT_CONFIGURED"


class OTPInvalid(AccountsError):
    """The OTP entered didn't match the challenge."""

    server_code = "OTP_INVALID"


class OTPExpired(AccountsError):
    """The OTP challenge TTL elapsed before the user submitted the code."""

    server_code = "OTP_EXPIRED"


class OTPMaxAttempts(AccountsError):
    """Too many wrong OTP attempts on this challenge; request a fresh one."""

    server_code = "OTP_MAX_ATTEMPTS"


class ChallengeNotFound(AccountsError):
    """The ``challenge_id`` doesn't exist.

    Usually means another tab consumed it, or the server restarted.
    """

    server_code = "CHALLENGE_NOT_FOUND"


class TokenRevoked(AccountsError):
    """The owner token used was revoked (usually by a successful rotation)."""

    server_code = "TOKEN_REVOKED"


# Map server code → exception class. Lookup table for `_raise_for_code`.
_ERROR_BY_CODE: dict[str, type[AccountsError]] = {
    cls.server_code: cls
    for cls in (
        EmailAlreadyRegistered,
        VerificationTokenExpired,
        PhoneNotConfigured,
        OTPInvalid,
        OTPExpired,
        OTPMaxAttempts,
        ChallengeNotFound,
        TokenRevoked,
    )
}


def _raise_for_code(code: str, message: str, status: int) -> None:
    """Raise the mapped AccountsError subclass for `code`, or a generic one."""
    cls = _ERROR_BY_CODE.get(code, AccountsError)
    raise cls(message or code, code=code, status_code=status)


# Type for the OTP prompt callback — sync or async.
OtpPrompt = Callable[[str], str | Awaitable[str]]


# ---------------------------------------------------------------------------
# AccountsClient
# ---------------------------------------------------------------------------


class AccountsClient:
    """REST client for Butt-Dial account lifecycle endpoints.

    Parameters
    ----------
    base_url:
        Butt-Dial server base URL (no trailing ``/api/orgs/...``). Example:
        ``https://call.95percent.ai``. Required.
    team_token:
        Bearer token for authenticated calls. Can be ``None`` at construction
        if the first call will be ``register`` or ``verify`` (those are
        unauthenticated). Set via :meth:`with_token` after ``verify``.
    timeout:
        Per-request timeout in seconds. Default 15.
    transport:
        Optional ``httpx.AsyncBaseTransport`` — used by tests to inject
        ``respx``. Production leaves this ``None``.
    """

    def __init__(
        self,
        base_url: str,
        *,
        team_token: str | None = None,
        timeout: float = 15.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not base_url:
            raise ConfigError("base_url is required")
        self._base_url = base_url.rstrip("/")
        self._team_token = team_token
        self._timeout = timeout
        self._transport = transport

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def with_token(self, team_token: str) -> AccountsClient:
        """Return a copy of this client with a fresh owner token.

        Useful right after ``verify`` returns the first token, or after
        ``rotate_token`` returns a new one — keeps the existing instance
        immutable while the caller swaps its stored value.
        """
        return AccountsClient(
            self._base_url,
            team_token=team_token,
            timeout=self._timeout,
            transport=self._transport,
        )

    @property
    def team_token(self) -> str | None:
        return self._team_token

    # ------------------------------------------------------------------
    # Unauthenticated endpoints
    # ------------------------------------------------------------------

    async def register(
        self,
        org_name: str,
        owner_email: str,
        *,
        branding: dict[str, Any] | None = None,
        return_url: str | None = None,
        webhook_url: str | None = None,
        verification_email: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """Start signup. Returns ``{orgId, verificationSent, pollToken, webhookSecret?}``.

        The server sends a verification email to ``owner_email`` with a
        time-boxed link. The host app's deep-link handler must call
        :meth:`verify` with the token embedded in that link, OR (when
        ``webhook_url`` is supplied) BD posts ``account.verified`` to that
        URL after the user clicks.

        ``pollToken`` (sprint-10+) is included on every register response.
        Use it to poll ``GET /api/orgs/{orgId}/verification-status?poll_token=…``
        during signup, before the team_token is available. The token is
        rotated on every register call and invalidated on verify.

        ``webhookSecret`` is returned **once** — only on register calls that
        supply ``webhook_url`` AND target a not-yet-verified org. Capture it
        immediately and store alongside the org record; it cannot be retrieved
        later. Re-registering the same pending org echoes the same secret
        (idempotent recovery), but once the org is verified the secret is no
        longer surfaced. Verify with
        :func:`buttdial.webhooks.verify_webhook_signature`.

        Optional blocks (all forwarded to the server):

        - ``branding``: ``{logoUrl, primaryColor, productName, supportEmail}``
          stored on the org record. Read by the verify page (logo + accent
          color + "Return to <productName>" CTA).
        - ``return_url``: where the verify page redirects after success. If
          ``webhook_url`` is omitted, the redirect carries the team token in
          the URL fragment: ``#bd_token=…&org_id=…&verified_at=…``.
        - ``webhook_url``: BD will POST ``account.verified`` here after
          verify. Use :func:`buttdial.webhooks.verify_webhook_signature` to
          validate the HMAC signature on receipt.
        - ``verification_email``: ``{subject?, html?, text?}`` — caller-
          supplied verification email body. Substituted variables:
          ``{{verifyUrl}}`` (required if ``html`` or ``text`` is provided),
          ``{{orgName}}``, ``{{ownerEmail}}``, ``{{expiresInMinutes}}``.
          HTML is sanitized server-side (``script/iframe/object/embed/on*=``
          stripped). 200 KB cap. May raise :class:`AccountsError` with
          ``code='TEMPLATE_MISSING_VERIFY_URL'`` or ``'TEMPLATE_TOO_LARGE'``.

        ``idempotency_key`` (sprint-21+): the SDK auto-generates a UUIDv4
        per call and sends it as ``Idempotency-Key``. If your bknd is
        retrying register() because of a transient network failure and you
        already have a stable handle for that attempt (e.g. a request id),
        pass it explicitly so the server short-circuits the duplicate
        instead of cutting a fresh org.

        Note: :class:`EmailAlreadyRegistered` is intentionally unreachable
        per F04 (BD silently re-sends verification to existing-email
        registers; no enumeration oracle). Don't catch it.

        .. deprecated:: 0.4.1
            Calling ``register()`` with **none** of ``branding``,
            ``return_url``, ``webhook_url``, or ``verification_email``
            triggers a ``DeprecationWarning``. The bare form produces a
            BD-branded verification email and gives no completion signal
            to your bknd, which is rarely what production hosts want. See
            ``AGENTS.md`` and the ``examples/with-onboarding-handshake/``
            example for the recommended pattern.
        """
        if (
            branding is None
            and return_url is None
            and webhook_url is None
            and verification_email is None
        ):
            warnings.warn(
                "AccountsClient.register() called without branding, return_url, "
                "webhook_url, or verification_email. The verification email will "
                "use BD's default template (showing 'butt-dial' to your end-users) "
                "and BD will not post back to your bknd when the user clicks the "
                "link. To brand the email + verify page and receive a signed "
                "callback, pass branding={...}, return_url='...', and "
                "webhook_url='...'. See "
                "https://github.com/elradts/butt-dial-sdk#onboarding-handshake-040 "
                "or AGENTS.md for the recommended pattern.",
                DeprecationWarning,
                stacklevel=2,
            )
        body: dict[str, Any] = {"orgName": org_name, "ownerEmail": owner_email}
        if branding is not None:
            body["branding"] = branding
        if return_url is not None:
            body["returnUrl"] = return_url
        if webhook_url is not None:
            body["webhookUrl"] = webhook_url
        if verification_email is not None:
            body["verificationEmail"] = verification_email
        # Auto-generate an Idempotency-Key per call (UUIDv4) so accidental
        # retries within the server's idempotency window don't double-send
        # the verification email or create duplicate orgs. The caller can
        # override by passing ``idempotency_key=...``.
        key = idempotency_key or str(uuid.uuid4())
        return await self._request(
            "POST",
            "/api/orgs/register",
            body=body,
            authenticated=False,
            extra_headers={"Idempotency-Key": key},
        )

    async def verify(self, token: str) -> dict[str, Any]:
        """Exchange a verification token for the team bearer token.

        Returns ``{team_token, org_id, scopes}`` on the legacy success path.
        ``scopes`` is a string like ``"org-admin"`` describing the bearer's
        authority. Store ``team_token`` in your vault keyed by tenant id —
        everything authenticated uses it. (The workspace ``mode``,
        ``"sandbox"`` vs ``"live"``, lives on ``GET /api/orgs/me``, not
        on this response.)

        Raises ``VerificationTokenExpired`` if the link is too old.

        Raises :class:`OnboardingRequired` (sprint-20+) if the server
        responds with ``{teamToken: null, requiresOnboarding: true, ...}``.
        The user must accept TOS in a browser before the team_token is
        minted; the exception carries the URL to redirect to.

        The server still returns the bearer under the legacy key
        ``owner_token``; this method normalizes it to ``team_token`` so
        callers don't have to track the historical name.
        """
        resp = await self._request(
            "POST",
            "/api/orgs/verify",
            body={"token": token},
            authenticated=False,
        )

        # Sprint-20+: TOS acceptance gate. Server returns {teamToken: null,
        # requiresOnboarding: true, orgId, onboardingSessionId, onboardingExpiresAt}.
        # Accept either casing per the F84 sunset migration.
        requires = resp.get("requiresOnboarding")
        if requires is None:
            requires = resp.get("requires_onboarding")
        if requires:
            org_id = resp.get("orgId") or resp.get("org_id") or ""
            session_id = resp.get("onboardingSessionId") or resp.get("onboarding_session_id")
            expires_at = resp.get("onboardingExpiresAt") or resp.get("onboarding_expires_at")
            onboarding_url = (
                resp.get("onboardingUrl")
                or resp.get("onboarding_url")
                or (
                    f"{self._base_url}/onboarding?s={session_id}"
                    if session_id
                    else f"{self._base_url}/onboarding"
                )
            )
            raise OnboardingRequired(
                org_id=org_id,
                onboarding_url=onboarding_url,
                expires_at=expires_at,
                onboarding_session_id=session_id,
                body=resp,
            )

        # Normalize legacy `owner_token` → `team_token` for the SDK API.
        if "owner_token" in resp and "team_token" not in resp:
            resp["team_token"] = resp.pop("owner_token")
        return resp

    # ------------------------------------------------------------------
    # Agent lifecycle (host owns the UUID)
    # ------------------------------------------------------------------

    async def register_agent(
        self,
        agent_id: str,
        display_name: str,
        **extra: Any,
    ) -> dict[str, Any]:
        """Register a new agent with a host-supplied UUID.

        BD does **not** generate ``agent_id`` — the host picks the UUID
        (typically the same value its own DB uses for the agent row) and
        sends it on registration. BD echoes it back along with a fresh
        per-agent runtime bearer token.

        Wire shape::

            POST /api/v1/agents
            {"agent_id": "<uuid>", "display_name": "...", ...extra}
            → {"agent_id": "<echoed>", "token": "<bearer>"}

        Returns ``{"agent_id", "token"}``. Store ``token`` as the
        agent's ``agent_token`` (used by :class:`buttdial.Agent`).
        ``extra`` is forwarded as additional fields on the request body
        — useful for ``email``, ``phone``, or other identity fields BD
        accepts but the SDK doesn't model yet.

        Requires the ``team_token`` (set in the constructor).
        """
        if not agent_id:
            raise ConfigError("agent_id is required (host-supplied UUID)")
        body = {"agent_id": agent_id, "display_name": display_name, **extra}
        return await self._request("POST", "/api/v1/agents", body=body)

    async def get_agent(self, agent_id: str) -> dict[str, Any]:
        """Look up an agent by UUID. Returns the BD record.

        Use this with the host-supplied ``agent_id`` from
        :meth:`register_agent`. Works with the workspace ``team_token``
        held by ``AccountsClient``.

        Raises :class:`buttdial.errors.NotProvisioned` (404/410) if the
        agent has not been registered or has been deregistered.
        """
        return await self._request("GET", f"/api/v1/agents/{agent_id}")

    async def provision_channels(
        self,
        agent_id: str,
        *,
        display_name: str,
        callback_url: str,
        capabilities: dict[str, bool],
        country: str = "US",
        preferred_whatsapp_number: str | None = None,
        preferred_phone_number: str | None = None,
        identity_mode: str = "dedicated",
        language: str | None = None,
        gender: str | None = None,
        voice_id: str | None = None,
        greeting: str | None = None,
        system_prompt: str | None = None,
        email_domain: str | None = None,
    ) -> dict[str, Any]:
        """Assign channels (phone / WA / email / voiceAi) to a registered agent.

        Two-step onboarding: first :meth:`register_agent` mints the
        identity + agent_token, then this method assigns concrete
        channels (phone numbers, WA senders, email addresses).

        Wraps the existing ``POST /api/v1/provision`` endpoint, which is
        wider than ``/agents`` — it allocates pool resources, configures
        provider webhooks, and returns the full channel map. Re-using
        ``agent_id`` here is intentional: the host's UUID stays the
        single identifier across both calls.

        Args
        ----
        agent_id:
            UUID returned by :meth:`register_agent` (or whatever the host
            chose). The same value MUST be supplied here so the channels
            attach to the right identity.
        display_name:
            Human-readable label. ``/provision`` requires it; defaulting
            to whatever you used at registration is fine.
        callback_url:
            HTTPS endpoint BD will POST inbound messages and delivery
            receipts to. Must be reachable from BD's network.
        capabilities:
            Channels to enable, e.g.
            ``{"phone": True, "whatsapp": True, "voiceAi": False, "email": False}``.
            Server only accepts the dict shape — pass each channel as a
            boolean. (The list-of-strings convenience form was an SDK
            invention; F57 dropped it because the server rejected it.)
        country:
            Pool-selection hint when allocating numbers. Default ``"US"``.
        preferred_whatsapp_number / preferred_phone_number:
            Pin a specific number from the pool (must already be
            unassigned). Otherwise BD picks one.
        identity_mode:
            ``"dedicated"`` (default) assigns a number to this agent;
            ``"shared"`` lets the agent send through the org's pool at
            send time without a permanent assignment.
        language / gender / voice_id / greeting / system_prompt / email_domain:
            Voice + email config — forwarded verbatim to ``/provision``.

        Returns the full ``/provision`` response::

            {
              "success": true,
              "agentId": "<uuid>",
              "agentName": "...",
              "token": "<bearer>",   # NEW token if /provision regenerates one
              "channels": {
                "phone": {...}, "whatsapp": {...}, "email": {...}, "voice": {...}
              }
            }

        ``/provision`` mints its own per-agent token. If you already
        called :meth:`register_agent`, store the token from THIS response
        and discard the previous one — only one token per agent_id is
        active at a time.
        """
        if not agent_id:
            raise ConfigError("agent_id is required (host-supplied UUID)")
        body: dict[str, Any] = {
            "agentId": agent_id,
            "agentName": display_name,
            "callbackUrl": callback_url,
            "capabilities": capabilities,
            "country": country,
            "identityMode": identity_mode,
        }
        if preferred_whatsapp_number is not None:
            body["preferredWhatsappNumber"] = preferred_whatsapp_number
        if preferred_phone_number is not None:
            body["preferredPhoneNumber"] = preferred_phone_number
        if language is not None:
            body["language"] = language
        if gender is not None:
            body["gender"] = gender
        if voice_id is not None:
            body["voiceId"] = voice_id
        if greeting is not None:
            body["greeting"] = greeting
        if system_prompt is not None:
            body["systemPrompt"] = system_prompt
        if email_domain is not None:
            body["emailDomain"] = email_domain
        return await self._request("POST", "/api/v1/provision", body=body)

    # ------------------------------------------------------------------
    # Admin phone setup
    # ------------------------------------------------------------------

    async def set_phone(self, phone: str) -> dict[str, Any]:
        """Start an admin-phone challenge. Returns ``{challenge_id}``.

        Server sends a 6-digit OTP to ``phone`` via SMS. Follow up with
        :meth:`confirm_phone` passing the ``challenge_id`` and the code
        the admin enters.

        `phone` must be E.164 (e.g. ``+14155550123``).
        """
        return await self._request(
            "POST",
            "/api/orgs/me/phone/set",
            body={"phone": phone},
        )

    async def confirm_phone(
        self,
        challenge_id: str,
        otp: str,
    ) -> dict[str, Any]:
        """Confirm the admin-phone challenge. Returns ``{ok, phone_hint}``.

        On success the phone is officially registered as the admin phone
        for this org — future rotations deliver OTPs here.

        Raises ``OTPInvalid`` / ``OTPExpired`` / ``OTPMaxAttempts`` /
        ``ChallengeNotFound`` depending on the failure mode.
        """
        return await self._request(
            "POST",
            "/api/orgs/me/phone/confirm",
            body={"challengeId": challenge_id, "otp": otp},
        )

    # ------------------------------------------------------------------
    # Token rotation
    # ------------------------------------------------------------------

    async def rotate_token_request(self) -> dict[str, Any]:
        """Start a token-rotation challenge. Returns ``{challenge_id, phone_hint}``.

        Server sends a fresh OTP to the admin phone. Use the returned
        ``phone_hint`` (e.g. ``+1********23``) to remind the user which
        number to check.

        Raises ``PhoneNotConfigured`` if the admin phone was never set +
        confirmed; the host UI must run the phone-setup flow first.
        """
        return await self._request(
            "POST",
            "/api/orgs/me/rotate-token/request",
            body={},
        )

    async def rotate_token_confirm(
        self,
        challenge_id: str,
        otp: str,
    ) -> dict[str, Any]:
        """Confirm rotation. Returns ``{token}`` — a fresh owner bearer token.

        On success the **old token is revoked atomically** on the server
        side. The host app must replace its stored copy before the next
        authenticated request, otherwise stale holders will hit ``TokenRevoked``.

        Raises OTP errors on bad input or ``ChallengeNotFound`` if another
        tab consumed the challenge first.
        """
        return await self._request(
            "POST",
            "/api/orgs/me/rotate-token/confirm",
            body={"challengeId": challenge_id, "otp": otp},
        )

    async def rotate_token(
        self,
        otp_prompt: OtpPrompt,
    ) -> dict[str, Any]:
        """Convenience: request + confirm in one call.

        ``otp_prompt`` is a callable that takes ``phone_hint`` (str) and
        returns the 6-digit code the user entered. It can be sync or
        async; both are awaited uniformly.

        Returns the same shape as :meth:`rotate_token_confirm` — ``{token}``.

        Error semantics are identical to the individual calls. Callers
        still need to update their stored token value on success; this
        helper intentionally does **not** mutate ``self._team_token``
        because rotating and continuing to use the same client instance
        is often what hosts want *only* after they've persisted the new
        token (crash-safety).
        """
        challenge = await self.rotate_token_request()
        hint = challenge.get("phone_hint", "")
        maybe_otp = otp_prompt(hint)
        if hasattr(maybe_otp, "__await__"):
            otp: str = await maybe_otp  # type: ignore[misc,assignment]
        else:
            otp = maybe_otp  # type: ignore[assignment]
        return await self.rotate_token_confirm(challenge["challenge_id"], otp)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    async def get_account(self) -> dict[str, Any]:
        """Return the current owner's account state.

        ``{org_id, name, owner_email, owner_phone_hint, mode, created_at, status}``.

        Raises ``TokenRevoked`` if the stored token was rotated out (or
        otherwise revoked). This is the canonical self-heal check for a
        rotation that timed out mid-flight — a 200 here means the stored
        value is still good; a ``TokenRevoked`` means the rotation landed
        and the host must refresh its copy.
        """
        return await self._request(
            "GET",
            "/api/orgs/me",
        )

    # ------------------------------------------------------------------
    # Internal HTTP helper
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        authenticated: bool = True,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {"User-Agent": user_agent()}
        if authenticated:
            if not self._team_token:
                raise ConfigError(
                    f"{path} requires a team token. Construct AccountsClient "
                    "with team_token=..., or call verify() first."
                )
            headers["Authorization"] = f"Bearer {self._team_token}"
        if extra_headers:
            headers.update(extra_headers)

        url = f"{self._base_url}{path}"
        try:
            async with httpx.AsyncClient(
                timeout=self._timeout,
                transport=self._transport,
            ) as client:
                resp = await client.request(
                    method,
                    url,
                    headers=headers,
                    json=body if body is not None else None,
                )
        except (httpx.TransportError, httpx.TimeoutException) as e:
            raise TransportError(
                f"Butt-Dial accounts {method} {path}: {e}",
                stage="transport",
            ) from e

        check_deprecation_headers(method, path, dict(resp.headers))

        # Successful 2xx — return parsed JSON (or {} when body is empty).
        if 200 <= resp.status_code < 300:
            if not resp.content:
                return {}
            try:
                return resp.json()
            except ValueError:
                # Server sent 2xx with non-JSON body. Unusual but survivable —
                # treat as empty success so callers don't crash on missing keys.
                return {}

        # Error response — try parsing the body first.
        try:
            payload = resp.json()
        except ValueError:
            payload = {}
        body_dict: dict[str, Any] = payload if isinstance(payload, dict) else {}
        code = str(body_dict.get("code") or "")
        message = str(body_dict.get("message") or body_dict.get("error") or "")
        if not message:
            # Fall back to the HTTP reason phrase so the user gets something
            # human-readable even when the server didn't populate `message`.
            message = f"{resp.status_code} {resp.reason_phrase}"

        # The auth-middleware contract uses `AUTH_*` codes on 401/429
        # (AUTH_INVALID_TOKEN, AUTH_TOKEN_REVOKED, AUTH_MISSING_HEADER,
        # AUTH_LOCKED_OUT). These get typed exceptions from `errors.py`
        # that carry retryable / retry-after / remaining-attempts, which
        # the accounts-specific hierarchy doesn't model.
        #
        # The accounts API also uses `TOKEN_REVOKED` (no AUTH_ prefix)
        # which means "this owner token was rotated out" — semantically
        # the same outcome but a different layer's signal. That keeps
        # mapping to `accounts.TokenRevoked` for back-compat.
        is_auth_middleware = code.startswith("AUTH_") if code else False
        is_generic_429 = resp.status_code == 429 and not code  # no body code at all
        is_not_provisioned = resp.status_code in (404, 410) and code in (
            "AGENT_NOT_PROVISIONED",
            "AGENT_NOT_FOUND",
            "NOT_PROVISIONED",
        )
        if is_not_provisioned:
            raise parse_error_response(
                status_code=resp.status_code,
                body=body_dict,
                headers=dict(resp.headers),
            )
        if resp.status_code in (401, 429) and (is_auth_middleware or is_generic_429):
            err = parse_error_response(
                status_code=resp.status_code,
                body=body_dict,
                headers=dict(resp.headers),
            )
            # Early-warning log when the IP is approaching lockout. The
            # caller should read `remaining_attempts` themselves; this is
            # just a visibility hint so the issue doesn't surprise them.
            remaining = getattr(err, "remaining_attempts", None)
            if isinstance(remaining, int) and 0 < remaining <= 3:
                _logger.warning(
                    "Butt-Dial auth: %d attempts remaining before IP lockout — "
                    "token may be invalid (%s)",
                    remaining,
                    code or "no code",
                )
            if isinstance(err, AuthLockedOutError):
                _logger.warning(
                    "Butt-Dial IP locked out for %s seconds (until %s)",
                    err.retry_after_seconds,
                    err.locked_until.isoformat() if err.locked_until else "?",
                )
            raise err

        # Otherwise — fall back to the accounts-specific code mapping
        # (TOKEN_REVOKED, OTP_INVALID, EMAIL_ALREADY_REGISTERED, …).
        _raise_for_code(code, message, resp.status_code)
        # Unreachable — _raise_for_code always raises.
        raise AccountsError(message, code=code, status_code=resp.status_code)
