"""Shared HTTP helpers — User-Agent + Deprecation/Sunset header awareness.

Kept module-private (leading underscore). Both ``accounts.py`` (REST) and
``agent.py`` (SSE handshake + REST usage endpoint) import from here so the
SDK presents a single ``buttdial-python/<version>`` identity to BD and
honors RFC 8594 ``Sunset`` + the deprecation-header draft consistently.
"""

from __future__ import annotations

import logging

_logger = logging.getLogger("buttdial")


def user_agent() -> str:
    """Return ``buttdial-python/<version>``.

    Resolved at call time from the package's ``__version__`` so the value
    follows the wheel rather than freezing at import time.
    """
    try:
        from buttdial import __version__ as _v  # local to avoid import cycle
    except Exception:
        _v = "0.0.0"
    return f"buttdial-python/{_v}"


# Deduplicate Deprecation/Sunset warnings: once per (method, path, sunset)
# per process is enough — the first call already alerted the integrator.
_DEPRECATION_LOGGED: set[tuple[str, str, str]] = set()


def check_deprecation_headers(
    method: str,
    path: str,
    headers: dict[str, str],
) -> None:
    """Log a warning when BD returns ``Deprecation: true`` / ``Sunset: <date>``.

    Honors RFC 8594 (Sunset) + draft-ietf-httpapi-deprecation-header.
    Header lookup is case-insensitive — servers may send either casing.
    """
    lower = {k.lower(): v for k, v in headers.items()}
    deprecation = lower.get("deprecation")
    if not deprecation:
        return
    sunset = lower.get("sunset", "")
    key = (method.upper(), path, sunset)
    if key in _DEPRECATION_LOGGED:
        return
    _DEPRECATION_LOGGED.add(key)
    if sunset:
        _logger.warning(
            "Butt-Dial endpoint %s %s is deprecated (Sunset: %s). "
            "Upgrade to the replacement before that date — see CHANGELOG.",
            method.upper(),
            path,
            sunset,
        )
    else:
        _logger.warning(
            "Butt-Dial endpoint %s %s is deprecated. Check release notes " "for the replacement.",
            method.upper(),
            path,
        )
