"""`FakeButtDialServer` — programmable in-process fake for tests.

Monkey-patches `mcp.ClientSession` and `mcp.client.sse.sse_client` so any
code using `buttdial.Agent` (or iv-bknd's bare `engine.comms.send_message`
pattern) goes through the fake. Covers all three Agent methods that touch
MCP: `send_message`, `list_tools`, `ping`.

Typical use:

    from buttdial import Agent
    from buttdial.testing import FakeButtDialServer

    async def test_my_integration():
        with FakeButtDialServer() as fake:
            fake.on_send(sid="SM-123")
            c = Agent("https://fake.test", agent_token="t")
            result = await c.send_message(to="+1", body="hi")
            assert result.message_sid == "SM-123"
            assert fake.sent_messages[0]["args"]["to"] == "+1"

Or via the pytest fixture:

    from buttdial.testing import fake_server  # auto-used

    async def test_stuff(fake_server):
        fake_server.on_send(sid="SM-1")
        ...

Inbound simulation delegates to `InboundHandler._dispatch_*` so hosts can
cover the full round-trip (server → webhook → host handler) without
standing up an HTTP server.
"""

from __future__ import annotations

import json
import sys
import types
import uuid
from collections import deque
from dataclasses import dataclass
from typing import Any

from buttdial.inbound import InboundHandler
from buttdial.models import Channel, DeliveryReceipt, InboundMessage, ReceiptStatus


@dataclass
class _FakeResponse:
    sid: str | None = None
    error: str | None = None
    raw_text: str | None = None


@dataclass
class _SentCall:
    tool: str
    token: str
    args: dict[str, Any]


class FakeButtDialServer:
    """Programmable in-process Butt-Dial server for tests.

    Not a real SSE server — installs fakes at the MCP import boundary.
    Call `install()` / `uninstall()` or use as a context manager. The
    `fake_server` pytest fixture handles lifecycle automatically.
    """

    def __init__(self) -> None:
        self.sent_messages: list[_SentCall] = []
        self.tool_list: list[str] = ["comms_send_message", "comms_ping"]
        self.last_token: str = ""
        self._responses: deque[_FakeResponse] = deque()
        self._installed: bool = False
        self._saved_modules: dict[str, types.ModuleType | None] = {}

    # ----- programming the fake -------------------------------------------

    def on_send(
        self,
        *,
        sid: str | None = None,
        error: str | None = None,
        raw_text: str | None = None,
        count: int = 1,
    ) -> None:
        """Queue the next `count` send responses.

        Exactly one of (sid, error, raw_text) should be supplied:

        - `sid="SM-1"` — server returns `{"messageId": sid}`.
        - `error="connection refused"` — server raises the error.
        - `raw_text="not json"` — server returns the literal text (tests
          malformed-response handling).

        If none is supplied, auto-generates a success with a fresh SID.
        """
        response = _FakeResponse(sid=sid, error=error, raw_text=raw_text)
        for _ in range(count):
            self._responses.append(response)

    def set_tools(self, tools: list[str]) -> None:
        """Control what `Agent.list_tools()` returns."""
        self.tool_list = list(tools)

    def reset(self) -> None:
        """Clear recorded sends, queued responses, and token capture."""
        self.sent_messages.clear()
        self._responses.clear()
        self.last_token = ""

    def _next_response(self) -> _FakeResponse:
        if self._responses:
            return self._responses.popleft()
        return _FakeResponse(sid=f"SM-{uuid.uuid4().hex[:10]}")

    # ----- inbound simulation --------------------------------------------

    async def simulate_inbound(
        self,
        inbound: InboundHandler,
        *,
        sender: str,
        text: str,
        channel: Channel = "whatsapp",
        thread_id: str | None = None,
    ) -> InboundMessage:
        """Fire an inbound message into a host's `InboundHandler`.

        Returns the constructed `InboundMessage` so tests can assert on it.
        """
        msg = InboundMessage(
            sender=sender,
            channel=channel,
            text=text,
            thread_id=thread_id,
        )
        await inbound._dispatch_message(msg)
        return msg

    async def simulate_receipt(
        self,
        inbound: InboundHandler,
        *,
        message_sid: str,
        status: ReceiptStatus = "delivered",
    ) -> DeliveryReceipt:
        """Fire a delivery receipt into a host's `InboundHandler`."""
        receipt = DeliveryReceipt(message_sid=message_sid, status=status)
        await inbound._dispatch_receipt(receipt)
        return receipt

    # ----- install / uninstall -------------------------------------------

    def install(self) -> None:
        """Replace `mcp.ClientSession` and `mcp.client.sse.sse_client` with fakes."""
        if self._installed:
            return

        fake = self

        class _FakeSession:
            async def initialize(self) -> None:
                return None

            async def list_tools(self) -> Any:
                return types.SimpleNamespace(
                    tools=[
                        types.SimpleNamespace(name=n, description="", inputSchema={})
                        for n in fake.tool_list
                    ]
                )

            async def call_tool(
                self, tool_name: str, arguments: dict[str, Any] | None = None
            ) -> Any:
                arguments = arguments or {}
                fake.sent_messages.append(
                    _SentCall(tool=tool_name, token=fake.last_token, args=arguments)
                )
                if tool_name == "comms_send_message":
                    response = fake._next_response()
                    if response.error:
                        raise ConnectionError(response.error)
                    if response.raw_text is not None:
                        text = response.raw_text
                    else:
                        text = json.dumps({"messageId": response.sid})
                    return types.SimpleNamespace(content=[types.SimpleNamespace(text=text)])
                if tool_name == "comms_ping":
                    return types.SimpleNamespace(content=[types.SimpleNamespace(text="pong")])
                return types.SimpleNamespace(content=[])

        class _FakeSessionCtx:
            def __init__(self, *_a: Any, **_k: Any) -> None:
                self._session = _FakeSession()

            async def __aenter__(self) -> _FakeSession:
                return self._session

            async def __aexit__(self, *_a: Any) -> None:
                return None

        class _FakeSseCtx:
            def __init__(self, url: str, headers: dict[str, str] | None = None, **_k: Any) -> None:
                self.url = url
                token = ""
                if headers:
                    auth = headers.get("Authorization", "")
                    if auth.startswith("Bearer "):
                        token = auth[len("Bearer ") :]
                fake.last_token = token

            async def __aenter__(self) -> tuple[object, object]:
                return (object(), object())

            async def __aexit__(self, *_a: Any) -> None:
                return None

        self._saved_modules = {
            "mcp": sys.modules.get("mcp"),
            "mcp.client": sys.modules.get("mcp.client"),
            "mcp.client.sse": sys.modules.get("mcp.client.sse"),
        }

        mcp_mod = types.ModuleType("mcp")
        mcp_mod.ClientSession = _FakeSessionCtx  # type: ignore[attr-defined]
        sys.modules["mcp"] = mcp_mod

        sys.modules["mcp.client"] = types.ModuleType("mcp.client")

        sse_mod = types.ModuleType("mcp.client.sse")
        sse_mod.sse_client = lambda *a, **k: _FakeSseCtx(*a, **k)  # type: ignore[attr-defined]
        sys.modules["mcp.client.sse"] = sse_mod

        self._installed = True

    def uninstall(self) -> None:
        """Restore the real `mcp` modules (or remove them if they weren't loaded)."""
        if not self._installed:
            return
        for name, mod in self._saved_modules.items():
            if mod is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = mod
        self._saved_modules = {}
        self._installed = False

    def __enter__(self) -> FakeButtDialServer:
        self.install()
        return self

    def __exit__(self, *_a: Any) -> None:
        self.uninstall()
