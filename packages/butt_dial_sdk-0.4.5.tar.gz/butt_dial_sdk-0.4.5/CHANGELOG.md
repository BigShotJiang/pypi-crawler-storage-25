# Changelog

All notable changes to this project are documented here. Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.4] — 2026-04-29

### Added — F90 closed end-to-end

BD shipped server-side F90 in sprint 12 (`code: "NO_CHANNEL_ASSIGNED"` + `channel` + `remediation` in the error envelope when an agent without channels tries to send). 0.4.4 closes the SDK side: typed exception + structured fields on `SendResult`.

- `SendResult.error_code` — populated from the server's `code` field. Branch on this instead of substring-matching `error`.
- `SendResult.error_channel` — populated from the server's `channel` field.
- `SendResult.remediation` — when the server supplies one (BD F90+), it's preferred over the SDK's curated remediation map. Falls back to the legacy map for unknown error strings.
- New typed exception `buttdial.NoChannelAssigned(ChannelError)` — raised by `AccountsClient` REST calls on `code=NO_CHANNEL_ASSIGNED` 4xx. (For sends through MCP, the SDK reports failures via `SendResult` instead of raising — same convention as every other send error.)
- Wired into `parse_error_response` for the REST surface and into `Agent._extract_error_envelope` for the MCP send path.
- Updated `buttdial errors` reference table.
- Updated `AGENTS.md` error reference and version notes.

### Verification

- Round-7 live probe confirmed BD's claims: F21 (`serverInfo.version=1.0.0`), F84 (OpenAPI title now `"Butt-Dial — REST API"`), F89 (register response shape symmetric across pending/verified emails), F90 (server-side envelope shipping correctly), F92 (4-tier scope vocabulary). See `docs/round7_live_results.json` and `scripts/probe_round7.py`.

### Tests

- 235 tests passing (+8 new in `tests/test_f90_no_channel_assigned.py`): public-API export, parse_error_response routing, SendResult new fields, envelope extraction (top-level + nested + unknown shapes).

## [0.4.3] — 2026-04-29

### Added — self-reliant integration source

The 0.4.x line aimed to teach LLMs how to integrate via `AGENTS.md`, runtime `DeprecationWarning`s, and a canonical FastAPI example. But all of those lived in the GitHub repo, not the wheel. After `pip install butt-dial-sdk`, an LLM with no internet would only see source-file docstrings — decent, but not the full forcing-function design we shipped. 0.4.3 closes that gap: `pip install` is now sufficient.

- **`AGENTS.md` ships inside the wheel** at `<site-packages>/buttdial/_docs/AGENTS.md`. The 0.4.2 doc was onboarding-heavy; 0.4.3 expands to four new sections so the manual is integration-complete:
  - "Workspace setup after verification" — the `register_agent` → `provision_channels` flow that closes the F90 "no sender assigned" failure mode.
  - "Receiving inbound" — `InboundHandler` decorator pattern, signature verification, per-channel routing, delivery receipts, status updates, common pitfalls.
  - "Token rotation" — OTP-gated `rotate_token` flow, two-step variant for web UIs, `AuthTokenRevokedError` self-heal pattern.
  - "Error reference" — every typed exception (`AuthInvalidTokenError`, `NotProvisioned`, `ProviderCapabilityError`, `OTPInvalid`, etc.) with raise condition and remediation in a single table.
- **Canonical examples ship inside the wheel** at `<site-packages>/buttdial/_examples/{minimal,with-inbound,with-onboarding-handshake,with-retry}/`. Same content as repo-root `examples/`; mirrored at build time via `scripts/sync_docs_to_package.py`.
- **Four new CLI subcommands** for runtime discoverability:
  - `buttdial guide` — prints AGENTS.md to stdout (pipe to less, grep, clipboard).
  - `buttdial example list` — enumerates bundled patterns.
  - `buttdial example show <name>` — prints every file in the named example.
  - `buttdial example extract <name> <dir>` — copies the example into the caller's project tree.
  - `buttdial errors` — prints the typed-exception reference table for fast lookup at debug time.
- **Module docstring updated** so `python -c "import buttdial; help(buttdial)"` points at `buttdial guide` and the bundled `_docs/AGENTS.md` path.

### How discovery works

Four compounding signals — agentic systems hit at least one:
1. `AGENTS.md` is the convention: Claude Code, Cursor, and Codex look for it in workspace + dependency trees. Now bundled, so `<site-packages>/buttdial/_docs/AGENTS.md` is findable.
2. `buttdial` CLI exposes `guide` / `example` / `errors` — natural first steps when an agent asks "how do I use this".
3. Module docstring (`help(buttdial)`) points at the CLI commands and the bundled file path.
4. Runtime `DeprecationWarning` on bare `register()` (existing 0.4.1 behavior) — catches anything that bypassed 1–3.

### Changed

- `pyproject.toml` `[tool.hatch.build.targets.wheel]` now relies on the default behavior of `packages = ["src/buttdial"]` to include non-Python files. (An earlier draft used `force-include` and produced duplicate wheel entries.)

### Tests

- 227 tests passing (8 new in `tests/test_cli_bundled_docs.py`): each new CLI command exercised + a smoke test asserting `_docs/AGENTS.md` and `_examples/*` are present in the installed package.

## [0.4.2] — 2026-04-29

### Fixed

- **F91:** `buttdial doctor` was rendering skipped stages with a `[FAIL]` icon, visually contradicting the closing "All stages passed" line when the user ran the diagnostic without `--to`. Skipped stages now render as `[SKIP]` (or `[○]` in Unicode mode), distinct from both `[OK]` and `[FAIL]`. Detection is automatic: any `DoctorStage` whose `detail` begins with `"skipped:"` renders as skipped. No model migration; no API change. Found during the round-6 live validation against `call.95percent.ai`.

### Tests

- 219 tests passing (1 new): `test_format_stage_renders_skipped_distinctly` covers both ASCII and Unicode rendering of skipped stages.

### Added

- `scripts/probe_round6.py` — re-runnable broad-sweep validation driver that exercises every SDK surface (REST + onboarding handshake + MCP) against a live server. Reads tokens from `.bd_token` / `.bd_agent_token` / `.bd_agent_id` in repo root.
- `docs/BD_SERVER_FEEDBACK_6.md` — round-6 audit report. Headline: 8/8 SDK surfaces pass against `call.95percent.ai`. One open finding (F90 — `comms_send_message` error wording) filed for BD.

## [0.4.1] — 2026-04-29

### Added — agent-readable forcing functions

The 0.4.0 onboarding-handshake surface (`branding`, `return_url`, `webhook_url`, `verification_email`) was launching with a discoverability gap: hosts that auto-register BD workspaces (e.g. via LLM-generated code paths) kept calling the bare `register(org, email)` form because no signal told them the new kwargs existed. This release adds three forcing functions to nudge agents toward the canonical pattern:

- **DeprecationWarning on the bare `register()` form.** Calling `AccountsClient.register()` without any of `branding`, `return_url`, `webhook_url`, or `verification_email` now emits a `DeprecationWarning` pointing at `AGENTS.md` and the example. The warning shows up in pytest output, Sentry, and the agent's own logs — visible to anyone reviewing the code.
- **New `AGENTS.md` at the repo root** — agent-readable contract documenting the canonical patterns, anti-patterns, and version-specific notes. LLMs writing host code (Cursor / Claude / Copilot / Codex) read this on demand or via per-project rules. Mirrors the practical conventions of the `AGENTS.md` files some major projects already ship.
- **New `examples/with-onboarding-handshake/`** — complete FastAPI host: signup endpoint that auto-registers with all four kwargs + signed webhook receiver with signature verification, delivery-id dedupe, and idempotent ack. This is the canonical example for code-generation agents to lift from.

### Changed

- `README.md` reordered so the branded onboarding flow is the canonical "how to register a tenant" code block (was buried below the bare form). The bare form is now demoted to an explicit "smoke-test only" footnote.
- `pyproject.toml` adds a `pytest.filterwarnings` entry that suppresses the new `DeprecationWarning` from cluttering test output. The explicit positive test (`test_register_bare_form_emits_deprecation_warning`) uses `pytest.warns()` and still catches it.

### Tests

- 218 tests passing (3 new): one asserts the bare-form warning fires, one asserts each of `branding`/`webhook_url`/`return_url`/`verification_email` individually suppresses it, and the original "backward-compat" test now reflects the new warning gate.

## [0.4.0] — 2026-04-29

### Added — sprint-9 onboarding handshake support

- `AccountsClient.register()` accepts four new optional keyword args: `branding`, `return_url`, `webhook_url`, `verification_email`. All forwarded to the server as camelCase JSON. Backward-compatible — callers that don't pass new kwargs send the original payload.
- New module `buttdial.webhooks` with `verify_webhook_signature()` — HMAC-SHA256 (Stripe-style) signature verifier for the BD `account.verified` webhook callback. Includes replay protection (5-minute default tolerance) and constant-time comparison via `hmac.compare_digest`.
- `register()` response shape documented to include `pollToken` (sprint-10 server addition) and `webhookSecret` (when `webhook_url` is supplied and the org is pending).
- New error codes mapped: `TEMPLATE_MISSING_VERIFY_URL`, `TEMPLATE_TOO_LARGE` — surface as `AccountsError` with `.code` set when caller-supplied `verification_email` HTML/text is invalid.

### Removed — broken method (server-side never worked)

- `AccountsClient.get_agent_self()`. The method called `GET /api/v1/agents/me` with the workspace `team_token`, but the server requires the per-agent `agent_token` for that endpoint and returned 404. Production callers were always failing. Use `AccountsClient.get_agent(agent_id)` instead — it works with `team_token` and the host already has the agent's UUID from `register_agent`. Tracked as F41 in the audit reports.

### Documentation

- `EmailAlreadyRegistered` exception class (`accounts.py:111`) marked as intentionally unreachable. The BD server uses silent-treatment for verified-email re-registers (F04 anti-enumeration); the typed exception is preserved as a forward-compatibility hook for a future proof-of-ownership 409 pattern.
- Comprehensive BD server audit (5 rounds, F01–F89) and onboarding handshake instructions added under `docs/BD_SERVER_*.md`.

### Tests

- 17 new tests added (4 register-extension + 13 webhook-signature). Total: 216 tests passing.

## [0.3.0] — 2026-04-25

### Breaking — Agent identity model + symbol renames

- **Host owns the agent UUID.** BD no longer mints `agent_id` on register.
  The host generates the UUID and tells BD; BD echoes it back along with
  the per-agent runtime token. `AccountsClient.register_agent(agent_id=..., display_name=...)`
  is the new entry point.
- **`Client` → `Agent`.** Per-agent runtime class renamed. File moved from
  `src/buttdial/client.py` to `src/buttdial/agent.py`. Constructor reshaped
  from `Client(token, url, *, client_token, ...)` to
  `Agent(base_url, *, agent_id, agent_token, ...)`. The SDK appends
  `/sse` to `base_url` for MCP and uses it as-is for REST.
- **`client_token` → `agent_token`** everywhere: parameter names, attributes,
  the `BUTT_DIAL_CLIENT_TOKEN` env var (now `BUTT_DIAL_AGENT_TOKEN`).
- **Three credential tiers**: `team_token` (workspace admin, used by
  `AccountsClient`), `agent_token` (per-agent runtime), `agent_id`
  (host-supplied UUID). New env vars: `BUTT_DIAL_BASE_URL`,
  `BUTT_DIAL_AGENT_ID`, `BUTT_DIAL_AGENT_TOKEN`, `BUTT_DIAL_TEAM_TOKEN`.

### Added

- **`AccountsClient.provision_channels(agent_id, *, display_name, callback_url, capabilities, ...)`**
  wraps `POST /api/v1/provision` so the host can attach phone / WhatsApp /
  email / voiceAi channels to an agent it already registered via
  `register_agent`. Two-step onboarding (identity then channels) keeps
  `agent_id` as the single host-owned identifier. The token returned by
  `/provision` supersedes the one from `register_agent` — store the new
  one and discard the old.
- **WhatsApp action surface on `Agent`** — generic `whatsapp_action(action, ...)`
  dispatcher plus 13 typed helpers wrapping BD's `comms_whatsapp_action`:
  `typing`, `mark_read`, `react`, `edit`, `forward`, `delete`, `send_poll`,
  `send_buttons`, `send_location`, `send_contact`, `post_status`,
  `set_chat_ttl`, `send_view_once`. Provider-capability mismatches (e.g.
  greenapi rejecting `post_status`) raise `ProviderCapabilityError` with
  `.code`, `.action`, `.channel`, `.provider`, `.body` for fallback
  decisions.
- **`Agent.send_message`** now accepts `media_url` and `sender_sid` so
  callers can route through a specific provisioned number (provider
  failover pattern).
- **`Agent._call_tool(token, tool_name, args)`** generalises the old
  `_call_send_tool(token, args)` so the WhatsApp action surface and
  `send_message` share one code path.
- **Error aliases** — `RevokedToken` (= `AuthTokenRevokedError`),
  `ProviderCapabilityError` (`ChannelError` subclass), `NotProvisioned`
  (`ChannelError` subclass) re-exported from the top-level package for
  ergonomic `except` handlers.

### Compat

- No backwards-compat shims. iv-bknd is expected to bump 0.2.x → 0.3.0
  in lockstep with the API rename. `BUTT_DIAL_TOKEN` and
  `BUTT_DIAL_CLIENT_TOKEN` env vars are no longer read.

## [0.2.1] — 2026-04-25

### Added
- **Auth-error contract** (`errors.py`): `AuthError` base + `AuthInvalidTokenError`, `AuthTokenRevokedError`, `AuthMissingHeaderError`, `AuthLockedOutError` mapping to BD's machine-readable codes (`AUTH_INVALID_TOKEN`, `AUTH_TOKEN_REVOKED`, `AUTH_MISSING_HEADER`, `AUTH_LOCKED_OUT`). `AuthLockedOutError` carries `retry_after_seconds` (Retry-After header preferred over body) and `locked_until` so callers can wait or fail fast instead of naive-backing off into the per-IP brute-force lockout. `AuthError.remaining_attempts` exposes the lockout countdown so integrators can warn before they're locked.
- **`RateLimitError`** for non-auth 429s (carries `retry_after_seconds`) and **`ChannelError`** for per-provider capability failures (carries `channel`/`action`/`provider` for fallback decisions).
- **`parse_error_response(status_code, body, headers)`** — single helper that turns BD's 4xx envelope into the right typed exception. Used by `accounts._request` and the `Client._call_send_tool` MCP path.
- **`InboundMessage` canonical fields**: `id`, `to`, `body` (alias for `text`), `media_url`, `media_type`, `is_voice_message`, `voice_transcription`, `group_id`, `group_name`, `sender_name`. Old code reading `.text` keeps working; new code can rely on these.
- **`InboundHandler._parse_whatsapp_message`** populates the new fields from WA Cloud envelopes (image/audio/video/document/sticker, voice notes with transcription, sender display name, BD-injected group context and `to` recipient).
- **`InboundHandler.handle_generic_payload`** forwards the same canonical fields when BD provides them in normalized webhooks (camelCase or snake_case).

### Changed
- **`Client.send_message` no longer retries on `retryable: false` auth errors.** `AuthInvalidTokenError`, `AuthTokenRevokedError`, `AuthMissingHeaderError` propagate immediately as typed exceptions instead of being swallowed into `SendResult(failed=True, stage_failed="transport")`. Naive retry-on-401 was the failure mode that triggered the per-IP lockout — surfacing typed errors lets the integrator prompt for a fresh token instead of looping.
- **`AccountsClient._request`** routes 401/429 with `AUTH_*` codes through `parse_error_response` so callers see the new typed classes; non-`AUTH_*` codes (`TOKEN_REVOKED`, `OTP_INVALID`, etc.) still map to the existing `accounts.*` exceptions for back-compat. Logs a warning when `remaining_attempts <= 3` so the impending lockout is visible before it lands.

## [0.2.0] — 2026-04-24

### Added
- `buttdial.accounts` — onboarding + token-rotation REST wrapper. `AccountsClient(base_url, owner_token=...)` exposes `register(org_name, owner_email)`, `verify(token)`, `set_phone(phone)`, `confirm_phone(challenge_id, otp)`, `rotate_token_request()`, `rotate_token_confirm(challenge_id, otp)`, `rotate_token(otp_prompt)` convenience helper, and `get_account()`. Covers the "first bearer token" lifecycle — after onboarding, existing provisioning flows (channels, callbacks) continue through `Client`. Works with plain `httpx.AsyncClient` (no MCP/SSE needed), and accepts a `transport=` kwarg so hosts and tests can inject `httpx.MockTransport` without extra deps.
- Typed exception hierarchy mirroring the server's machine-readable codes: `AccountsError` base + `EmailAlreadyRegistered`, `VerificationTokenExpired`, `PhoneNotConfigured`, `OTPInvalid`, `OTPExpired`, `OTPMaxAttempts`, `ChallengeNotFound`, `TokenRevoked`. All re-exported from the top-level `buttdial` package so `from buttdial import OTPInvalid` works.
- 20 tests under `tests/test_accounts.py` using `httpx.MockTransport` — full onboarding cycle, both sync and async OTP prompts, every typed error code, unknown-code fallthrough, revoked-token self-heal on `get_account`, transport-error mapping.
- 20-line "Connect butt-dial" snippet in the README showing a full `register → verify → set_phone → rotate_token` cycle.

### Changed
- Version bumped to 0.2.0 (additive — no breaking changes to existing `Client`, `InboundHandler`, `RetryWorker`, or admin router APIs).

## [0.1.1] and earlier

### Added
- Initial repo scaffold: `pyproject.toml`, `LICENSE` (MIT), `README.md`, `.gitignore`, source skeleton under `src/buttdial/`, tests skeleton, docs (`SPEC.md`, `TODO.md`, `DECISIONS.md`).
- Phase 2 — core outbound extracted from iv-bknd: `buttdial.Client` with `send_message()`, `buttdial.settings` (env-var loader), `buttdial.models` (Pydantic types: `SendResult`, `FailedMessage`, `InboundMessage`, `DeliveryReceipt`, `StatusUpdate`, `AgentInfo`, `DoctorStage`, `DoctorReport`).
- `pydantic-settings` added as a dependency.
- Phase 3 — inbound callbacks: `buttdial.InboundHandler` with decorator-based registration (`on_message`, `on_delivery_receipt`, `on_status_update`), channel filtering + wildcard, error-isolated dispatch. Ported iv-bknd's WhatsApp parser and added delivery-receipt parsing (WA statuses) that iv-bknd lacks. HMAC-SHA256 signature verification + Meta subscription challenge verification. Lazy FastAPI router mounted via `handler.router`.
- `docs/ERRORS.md` + `docs/REASONING.md` — first entries, capturing the FastAPI 422 lazy-import bug.
- Phase 4 — retry worker: `buttdial.RetryWorker` orchestrates retries against a host-provided `FailedMessageRepository` protocol (`runtime_checkable`). Preserves iv-bknd's three-state transition (delivered / dead / pending-with-backoff) and default `2^n` minute backoff. Adds pluggable `backoff` function, optional `on_dead_letter` host hook (error-isolated), poison-row isolation (one failing message doesn't stall the batch), and proper `start()`/`stop()` lifecycle.
- Phase 5 — admin router: `buttdial.make_router(client, repo, directory)` mounts 7 operational endpoints (overview, agents list, activate/deactivate, failed-message list/retry/dismiss). New `AgentDirectory` and `AdminFailedMessageRepository` protocols let hosts plug in their own models. Typed exceptions `AgentNotFound` / `AgentNotProvisioned` (inherit from builtins). `Client.list_tools()`, `Client.ping()`, `Client.fetch_usage_summary()` helpers added for overview composition. `/usage` endpoint dropped vs iv-bknd (host-specific reporting, out of SDK scope). Activate/deactivate uses a clean protocol instead of iv-bknd's buggy `update(id, dict)` call.
- Phase 6 — `buttdial doctor` diagnostic: seven-stage end-to-end health check (config, reachability, SSE handshake, tool list, send contract, delivery receipt, human-ack loopback) with typed `DoctorStage` per stage (ok/detail/remediation/duration_ms). `REMEDIATIONS` map covers 11 known failure modes (401/403, connection refused, timeouts, DNS, SSL, invalid recipient, missing token). `run_diagnostic()` orchestrates with fail-fast short-circuit; stages 5-7 skip gracefully when prerequisites are missing. `buttdial doctor --to <phone> [--expect-ack]` CLI prints ✓/✗ per stage with remediation on failure and exits non-zero on any failure.
- Phase 7 — testing utilities: `buttdial.testing.FakeButtDialServer` is a programmable in-process fake that monkeypatches `mcp.ClientSession` + `mcp.client.sse.sse_client`. Covers `send_message`, `list_tools`, and `ping` through one mechanism. `on_send(sid=..., error=..., raw_text=..., count=N)` programs responses; `sent_messages` captures every call. `simulate_inbound()` / `simulate_receipt()` fire events into a host's `InboundHandler`. `fake_server` pytest fixture exports directly. Enables first end-to-end doctor integration tests (stages 1-6 against the fake with a scheduled simulated receipt).
- Phase 8 — typed errors: `buttdial.errors.ButtDialError` base with optional `code`/`stage`/`remediation` attributes; `ConfigError` + `TransportError` subclasses. `AgentNotFound` / `AgentNotProvisioned` now inherit from both `ButtDialError` and their builtin (`KeyError`/`ValueError`) — `except ButtDialError:` catches any SDK-raised error while existing Python idioms still work.
- Phase 9 — test coverage: added `pytest-cov` with coverage config. Current coverage **86%** overall; all items from the Phase 9 TODO were already delivered in Phases 2-8 (117 tests across 9 test files).
- Phase 10 — iv-bknd integration (first pass): `engine/comms.py send_message()` in iv-bknd now delegates MCP transport to `buttdial.Client` while preserving its original signature and return-dict shape exactly. All 28 existing callers (auth, routes, autonomy, scheduler, inbound_poller, etc.) work unchanged. Full iv-bknd test suite passes (187/187). Retry worker, admin router, and webhook handler intentionally left intact for a lower-risk follow-up swap.
- Phase 11 — OSS polish: README rewrite (10-minute quickstart, component table, design principles, full API walkthrough), three working examples (`minimal/send_one.py`, `with-retry/sqlalchemy_repo.py` reference implementation, `with-inbound/app.py` full round-trip FastAPI app), `CONTRIBUTING.md`, GitHub Actions CI (lint + format + mypy + pytest + coverage on Python 3.11/3.12/3.13), `docs/PUBLISHING.md` release checklist. Remaining work is external (GitHub repo creation, PyPI publish) — blocked on a repo-location decision.

### Changed
- Extraction source clarified: docs updated to reflect that iv-bknd (not v95) is the real source of `engine/comms.py` and the primary integration target. v95 is a downstream consumer of iv-bknd.
