# AGENTS.md — instructions for code-generating agents using butt-dial-sdk

You are an LLM (Claude / Cursor / Copilot / Codex / etc.) writing host-app code that integrates with the Butt-Dial communication service via this SDK. **Read this before generating any code that imports from `buttdial`.** It encodes the rules a human maintainer would otherwise have to keep telling you.

If you only have time for one thing: **never call `AccountsClient.register()` with just `(org_name, owner_email)`.** That form is a development smoke-test, not a production call. See [§ Onboarding](#onboarding) below.

> **In-sync rule (added 2026-04-29).** Every BD-server behavior described here is either (a) verified by `scripts/probe_round*.py` against `call.95percent.ai`, (b) specced by BD in `docs/BD_SERVER_HANDSHAKE_SHIPPED.md`, or (c) explicitly hedged as observed-but-not-contracted. Do not add new BD-server behaviors without one of those three sources. SDK-side patterns (typed exceptions, retry semantics, error mapping) are SDK choices and don't need BD evidence.

---

## SDK at a glance

```python
from buttdial import (
    AccountsClient,    # workspace admin REST surface — uses team_token
    Agent,             # per-agent runtime — uses agent_token
    InboundHandler,    # webhook receiver for inbound messages
    RetryWorker,       # background retry loop with pluggable repository
)
from buttdial.webhooks import verify_webhook_signature   # 0.4.0+
```

**Three tokens, three jobs:**
- `team_token` — workspace admin (provisioning, registration, billing)
- `agent_token` — per-agent runtime (sending/receiving on this agent's number)
- `agent_id` — host-supplied UUID; identifies the agent across both surfaces

The host owns `agent_id`. Generate UUIDs in your code; tell BD; persist them. Don't expect BD to give you an agent_id.

**0.4.5+ SDK-level behaviors you don't have to wire yourself:**
- `User-Agent: buttdial-python/<version>` on every HTTP/SSE request (REST + MCP). BD reads this to track adoption + flag clients hitting deprecated paths.
- `register()` auto-generates an `Idempotency-Key` (UUIDv4) per call. Pass `idempotency_key=...` only if your bknd already has a stable handle (e.g. internal request id) and you want to dedupe transient retries against it.
- BD `Deprecation: true` / `Sunset: <date>` response headers are detected and logged at `WARNING` (logger name `buttdial`). The warning fires once per `(method, path, sunset)` per process so it's safe to leave the logger on. Wire your monitoring to alert on these — they're how BD tells the SDK an endpoint is going away.
- `OnboardingRequired` (raised from `verify()`) — see [§ Onboarding](#onboarding) for the sprint-20+ TOS-gate flow.

---

## Onboarding

### ✅ DO — branded onboarding handshake

```python
resp = await accounts.register(
    org_name=workspace.name,
    owner_email=workspace.admin_email,
    branding={
        "logoUrl":      "https://acme.com/logo.svg",
        "primaryColor": "#00C9A7",
        "productName":  "Acme",
        "supportEmail": "support@acme.com",
    },
    return_url="https://acme.com/welcome",
    webhook_url="https://acme.com/api/webhooks/butt-dial/account-verified",
)
# Capture once — webhookSecret is not retrievable later.
workspace.bd_webhook_secret = resp["webhookSecret"]
workspace.bd_poll_token     = resp["pollToken"]
workspace.save()
```

Then build the webhook receiver (see [§ Webhook receivers](#webhook-receivers)).

### ❌ DON'T — bare smoke-test form

```python
# WRONG in any production host. Emits DeprecationWarning. End-users get a
# BD-branded email and your bknd never learns the user verified.
await accounts.register("Acme", "alice@acme.com")
```

The bare form is for `examples/minimal/` and the `buttdial doctor` CLI. If you're writing a host that runs in front of real customers, you must pass `branding`, `return_url`, and `webhook_url`.

### Why both `return_url` AND `webhook_url`

- `webhook_url` — server-to-server completion signal. Reliable; arrives even if the user closes the verify tab; carries the `team_token` securely.
- `return_url` — UX signal. Where the verify page sends the user after success ("Return to Acme"). Even with a webhook, this is what the user sees in their browser.

Skip `webhook_url` only if you genuinely cannot run a webhook receiver. BD's spec (`docs/BD_SERVER_HANDSHAKE_SHIPPED.md`) describes a fragment fallback (`<return_url>#bd_token=…&org_id=…&verified_at=…`) for this case. The SDK has not directly tested the fragment path — if you depend on it, run a probe first.

### Sprint-20+: handle `OnboardingRequired`

Newer servers route first-time signups through a hosted TOS page before minting `team_token`. When that's the path BD takes for a given org, `verify()` returns `{teamToken: null, requiresOnboarding: true, orgId, onboardingSessionId, onboardingExpiresAt}` and the SDK raises `OnboardingRequired`:

```python
from buttdial import OnboardingRequired

try:
    info = await accounts.verify(verification_token)
    workspace.bd_team_token = info["team_token"]
    workspace.save()
except OnboardingRequired as needs_tos:
    workspace.bd_org_id = needs_tos.org_id   # persist so the webhook ties back
    workspace.save()
    # Redirect the user's browser. After they accept TOS, BD posts the
    # account.verified webhook with the minted teamToken — same handler
    # you already wrote above receives it.
    return redirect(needs_tos.onboarding_url)
```

Persist `org_id` before the redirect — the webhook arrives keyed by `orgId` and you'll need it to find the right workspace row. The legacy success path (`team_token` returned directly) is unchanged for orgs that aren't on the TOS-gated rollout.

### Don't catch `EmailAlreadyRegistered`

```python
# WRONG — never fires. F04 anti-enumeration: BD silently re-sends
# verification to existing-email registers; same response shape as a
# fresh register. The exception class exists as a forward-compatibility
# hook for a future proof-of-ownership 409 pattern.
try:
    await accounts.register(...)
except EmailAlreadyRegistered:
    show_signin()
```

The webhook fires on completion regardless of whether the email was new or already-verified. Branch on the webhook arriving, not on a pre-emit error code.

---

## Webhook receivers

Always verify the signature. Always dedupe by `X-BD-Delivery-Id`. Always respond `2xx` within 10 seconds.

### ✅ DO

```python
from buttdial.webhooks import verify_webhook_signature

@app.post("/api/webhooks/butt-dial/account-verified")
async def bd_webhook(request):
    raw = await request.body()                          # raw bytes — NOT request.json()
    ok = verify_webhook_signature(
        raw,
        timestamp_header=request.headers.get("X-BD-Timestamp"),
        signature_header=request.headers.get("X-BD-Signature"),
        secret=stored_secret_for_this_workspace,
    )
    if not ok:
        return JSONResponse({"error": "invalid signature"}, status_code=401)

    delivery_id = request.headers.get("X-BD-Delivery-Id")
    if await already_processed(delivery_id):
        return {"ok": True}                             # idempotent ack

    body = json.loads(raw)
    workspace.bd_team_token = body["teamToken"]
    workspace.provisioned   = True
    workspace.save()
    await mark_processed(delivery_id)
    return {"ok": True}
```

### ❌ DON'T

```python
# WRONG — request.json() reads the body via decode + parse. The signature
# is over the RAW BYTES. Re-serialized JSON won't produce the same digest.
body = await request.json()
ok = verify_webhook_signature(
    json.dumps(body).encode(),    # ← different bytes; sig fails
    ...
)
```

```python
# WRONG — no signature check. Anyone who knows your URL can forge events.
@app.post("/api/webhooks/butt-dial/account-verified")
async def bd_webhook(request):
    body = await request.json()
    workspace.bd_team_token = body["teamToken"]
    return {"ok": True}
```

```python
# WRONG — no dedupe. BD retries 1s/5s/25s/2m/10m if you 4xx/5xx or time out.
# Without an idempotency check you'll provision the same workspace 5 times.
```

---

## Diagnosing stuck-pending orgs

A workspace stays in **pending** until the owner clicks the verification email. If your bknd shows orgs that have been pending for hours or days, work this decision tree before opening a BD ticket — most stuck-pending orgs are caused by host-side wiring, not BD.

### Step 1 — ask BD what state it's in

```python
import httpx

async def check_bd_state(org_id: str, poll_token: str) -> dict:
    """Returns {status: 'pending'|'verified', verifiedAt?: str}."""
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            f"https://call.95percent.ai/api/orgs/{org_id}/verification-status",
            params={"poll_token": poll_token},
        )
    r.raise_for_status()
    return r.json()
```

The `poll_token` is what BD returned on the original `register()` call. Persist it alongside the org record; it's invalidated once the user verifies.

### Step 2 — branch on the answer

```python
state = await check_bd_state(workspace.bd_org_id, workspace.bd_poll_token)

if state["status"] == "verified":
    # BD thinks verified, your bknd thinks pending → you missed the webhook.
    # Most likely causes (in order):
    #   a. You called register() WITHOUT webhook_url → no callback was ever made.
    #      Fix: upgrade to the canonical pattern (see § Onboarding) and re-register.
    #   b. Your webhook receiver returned 4xx/5xx on the original delivery.
    #      BD retried 5x (1s/5s/25s/2m/10m), then dead-lettered.
    #      Fix: tail your webhook logs around verifiedAt, find the failure,
    #      reconcile manually (set provisioned=True locally — BD won't redeliver).
    #   c. Webhook URL unreachable from BD's network at the time of delivery.
    #      Fix: same as (b).
    workspace.provisioned   = True
    workspace.bd_verified_at = state["verifiedAt"]
    workspace.save()

elif state["status"] is None or state["status"] == "pending":
    # BD also thinks pending → user hasn't clicked yet. Check elapsed time:
    age_minutes = (now() - workspace.created_at).total_seconds() / 60
    if age_minutes > workspace.bd_token_expires_in_minutes:
        # Token expired. Re-register the same email — BD treats this as
        # idempotent for pending orgs (F04 anti-enumeration), returning
        # the SAME webhookSecret + a fresh pollToken. No new orgId.
        resp = await accounts.register(
            org_name=workspace.name,
            owner_email=workspace.admin_email,
            branding=BRANDING,
            return_url=...,
            webhook_url=...,
        )
        workspace.bd_poll_token = resp["pollToken"]  # rotated; webhookSecret echoed unchanged
        workspace.save()
    else:
        # Still within token TTL → user hasn't clicked. Ping them or wait.
        # Common causes: spam folder, user opened it on phone w/ corp filter,
        # user is just slow.
        pass
```

### Step 3 — what NOT to do

- **Don't generate a new `org_id`.** Re-registering the same pending email returns the same `orgId`. Forcing a new one creates duplicate workspaces in BD that you can't merge.
- **Don't catch `EmailAlreadyRegistered`** to detect re-registration. It never fires (F04 anti-enumeration); BD silently re-sends.
- **Don't poll `verification-status` faster than every 60s.** The endpoint is rate-limited.
- **Don't trust your local `created_at` over BD's `verifiedAt`.** If BD says verified at T, that's the truth — your bknd was the late party.

### Why this happens

The single biggest cause of stuck-pending orgs is host code that called the **bare `register(org, email)` form** before 0.4.0. That form gives BD no `webhook_url`, so the user verifying never produced a server-to-server callback — your bknd has no way to learn about it short of polling. The 0.4.1 `DeprecationWarning` was added specifically to surface this pattern in CI / Sentry. If you see the warning anywhere in your logs, you have hosts at risk of this exact bug.

---

## Workspace setup after verification

Once the webhook fires and you have `team_token`, the workspace is verified but **has no agents and no channels yet**. Sending a message at this point fails with "no sender assigned" (no `code` field — see version notes). Three steps to a usable workspace:

```python
import uuid
from buttdial import AccountsClient

authed = AccountsClient("https://call.95percent.ai", team_token=workspace.bd_team_token)

# 1. Confirm an admin phone (required before token rotation works).
challenge = await authed.set_phone("+14155550123")
otp = prompt_user("Enter the 6-digit code")
await authed.confirm_phone(challenge["challenge_id"], otp)

# 2. Register an agent — host generates the UUID.
agent_id = str(uuid.uuid4())              # this is what your DB key should match
out = await authed.register_agent(agent_id=agent_id, display_name="Maya")
agent_token = out["token"]                # persist alongside agent_id

# 3. Provision channels — assigns a phone number / WA sender / email / voiceAi.
provisioned = await authed.provision_channels(
    agent_id=agent_id,
    display_name="Maya",
    callback_url="https://acme.example/api/webhook",
    capabilities={"phone": True, "whatsapp": True, "voiceAi": False, "email": False},
    country="US",
)
# Important: /provision MAY mint a fresh agent_token. If it does, store THIS one
# and discard the value from step 2 — only one token per agent_id is active.
agent_token = provisioned["token"]
```

### ❌ Common mistakes

```python
# WRONG — sending before provision_channels(). Result.failed=True with
# error="no sender assigned" (or in 0.4.3+, code=NO_CHANNEL_ASSIGNED).
maya = Agent(base_url=..., agent_id=agent_id, agent_token=agent_token)
await maya.send_message(to="+1...", body="hi")  # fails: no channels
```

```python
# WRONG — letting BD generate agent_id. BD doesn't generate one. The host
# owns the UUID. If you don't pass one, register_agent() raises ConfigError.
await authed.register_agent(display_name="Maya")  # missing agent_id
```

```python
# WRONG — keeping the register_agent token after a subsequent provision_channels
# call mints a fresh one. The old token is silently revoked on the server side.
out = await authed.register_agent(agent_id, "Maya")
old = out["token"]
new_resp = await authed.provision_channels(agent_id, ...)
# `old` is now invalid; `new_resp["token"]` is the live one.
```

The flow is: **verify → confirm phone → register_agent → provision_channels → send.** Skipping `provision_channels` is the most common cause of "no sender" errors.

---

## Sending messages

### ✅ DO

```python
maya = Agent(
    base_url="https://call.95percent.ai",
    agent_id=agent_id,                  # host-supplied UUID
    agent_token=agent_token,            # minted by BD at register_agent
)
result = await maya.send_message(
    to="+14155550123",
    body="Hello",
    idempotency_key=f"msg-{request_id}",  # use this on every send
)
if result.failed:
    log.warning("send failed: %s — %s", result.stage_failed, result.error)
    # SDK has already exhausted 3-attempt exponential backoff.
```

### ❌ DON'T

```python
# WRONG — no idempotency_key. If your retry handler re-fires this on a
# transient failure (network blip, your bknd crashed mid-handler), you'll
# send the message twice.
await maya.send_message(to="+14155550123", body="Hello")
```

```python
# WRONG — passing agent_token at the Agent level AND per-call. The
# per-call value silently overrides; intent unclear; bug-prone.
maya = Agent(..., agent_token="A")
await maya.send_message(..., agent_token="B")
```

`SendResult` is the source of truth — it carries `failed`, `error`, `stage_failed`, `remediation`, and `message_sid`. Don't catch exceptions for sends; check `.failed`. (Auth-class errors do raise — `AuthInvalidTokenError`, `AuthLockedOutError`, `AuthTokenRevokedError` — because retrying them walks straight into IP lockout.)

---

## Receiving inbound

Inbound messages, delivery receipts, and status updates arrive as webhooks at the URL you passed to `provision_channels(callback_url=…)`. The SDK ships a decorator-based handler + a FastAPI router that handles signature verification and subscription challenges for you.

### ✅ DO

```python
from buttdial import InboundHandler, InboundMessage, DeliveryReceipt

inbound = InboundHandler(
    whatsapp_verify_token=settings.WA_VERIFY,        # for the GET subscription challenge
    whatsapp_webhook_secret=settings.WA_SECRET,      # for HMAC-SHA256 signature verification
)

@inbound.on_message()
async def on_any_message(msg: InboundMessage) -> None:
    # Fires for every channel. Use this for cross-channel logging.
    log.info("inbound %s from %s: %r", msg.channel, msg.sender, msg.text)

@inbound.on_message(channel="whatsapp")
async def on_whatsapp(msg: InboundMessage) -> None:
    # Channel-specific. Both this AND on_any_message fire — handlers don't
    # exclude each other.
    await process_whatsapp(msg.sender, msg.text, msg.agent_id, msg.message_id)

@inbound.on_delivery_receipt()
async def on_receipt(r: DeliveryReceipt) -> None:
    # r.message_sid, r.status (sent/delivered/read/failed), r.error_code
    await reconcile(r.message_sid, r.status)

@inbound.on_status_update()
async def on_status(s) -> None:
    # Per-channel state changes (e.g. WhatsApp Business profile updates).
    pass

app.include_router(inbound.router, prefix="/api/webhook")
# Mounts:
#   GET  /api/webhook/whatsapp/verify   — Meta's subscription challenge
#   POST /api/webhook/whatsapp          — incoming messages + receipts
#   POST /api/webhook/{other_channel}   — same shape per channel
```

### Key guarantees

- **Handler errors are isolated.** One handler raising doesn't break the others or fail the webhook ack. Errors are logged; the route still returns 2xx.
- **Signature verification is automatic** for WhatsApp once you pass `whatsapp_webhook_secret`. The router rejects requests with bad signatures (401) without invoking your handlers.
- **Subscription challenges are automatic** — the GET `/whatsapp/verify` route compares `hub.verify_token` against `whatsapp_verify_token` and echoes `hub.challenge` on match. Configure Meta's dashboard with the same value you pass here.
- **`InboundMessage`** carries `sender`, `text`, `channel`, `message_id`, `agent_id`, `timestamp`, plus channel-specific `extra` dict. The `agent_id` lets multi-agent hosts route inbound to the right agent's logic.

### ❌ DON'T

```python
# WRONG — re-implementing the WhatsApp signature check yourself.
# The router already does it. Skipping this guard is what makes
# webhook URLs forge-able.
@app.post("/api/webhook/whatsapp")
async def my_handler(request):
    body = await request.json()
    # ... no signature check, no challenge handler
```

```python
# WRONG — running blocking I/O directly in the handler. The router awaits
# every handler before returning 2xx; long handlers cause BD/Meta retries.
@inbound.on_message(channel="whatsapp")
async def on_msg(msg):
    sync_call_to_external_api()      # blocks event loop
    big_blocking_db_query()          # same
```

```python
# WRONG — assuming `msg.text` is always set. Reactions, location messages,
# and status updates have empty text; check msg.channel + msg.extra instead.
@inbound.on_message()
async def on_msg(msg):
    process(msg.text.lower())        # AttributeError on text=None
```

For inbound work, do the long task in a background queue and return from the handler immediately:

```python
@inbound.on_message(channel="whatsapp")
async def on_whatsapp(msg):
    await queue.enqueue("process_inbound", msg.dict())   # fire-and-forget
```

---

## Retry orchestration

`Agent.send_message()` already retries 3 times with exponential backoff for transport failures. **Use `RetryWorker` only if** your host can crash *between* the SDK call and your DB write (so the retry must outlive the request) **OR** you want delivery-failure messages to retry over hours/days, not seconds.

### ✅ DO

```python
from buttdial import RetryWorker, FailedMessageRepository, FailedMessage

class MyRepo:
    """Implement the FailedMessageRepository protocol against your DB."""

    async def fetch_due(self, limit: int) -> list[FailedMessage]:
        # Return rows where status='pending' AND next_retry_at <= NOW(),
        # ordered by next_retry_at, LIMIT :limit. Each FailedMessage carries
        # recipient, body, channel, agent_id, agent_token, retry_count,
        # max_retries, last_error, etc.
        ...

    async def mark_delivered(self, msg_id, message_sid, retry_count): ...
    async def increment_retry(self, msg_id, retry_count, error, next_retry_at): ...
    async def mark_dead(self, msg_id, retry_count, error): ...

async def alert(msg: FailedMessage, error: str) -> None:
    await pagerduty.trigger(f"BD send dead-lettered: {msg.recipient} — {error}")

worker = RetryWorker(
    repo=MyRepo(),
    client=maya,                         # the Agent
    on_dead_letter=alert,                # called when mark_dead fires
)
await worker.start(interval_seconds=60.0)
```

Default backoff is `2^n` minutes (2, 4, 8, 16, 32). Max retries default to 5; override per-message via `FailedMessage.max_retries`. After exhausting attempts, `mark_dead` runs and `on_dead_letter` (if set) fires.

### ❌ DON'T

```python
# WRONG — re-using the same idempotency_key across retries. BD treats
# retries with the same key as duplicate-suppress, which is what you want
# for transport retries. But if your repo CHANGES the key on every fetch,
# the dedupe breaks. Generate the key once, persist it on the row, replay
# it on every retry attempt.
```

```python
# WRONG — putting the agent_token in fetch_due's WHERE clause. Tokens
# rotate; if a retry runs after a rotation, the persisted token is stale.
# Instead, look up the agent_token from the agent_id at retry time.
```

The reference SQLAlchemy implementation lives at `_examples/with-retry/sqlalchemy_repo.py` (or `examples/with-retry/sqlalchemy_repo.py` in the source tree).

---

## Token rotation

Hosts MUST rotate `team_token` periodically (compliance / personnel changes). The flow is OTP-gated through the admin phone you confirmed in setup.

```python
new = await authed.rotate_token(
    otp_prompt=lambda hint: input(f"Enter the code sent to {hint}: ")
)
# Old team_token is revoked atomically on the server. Update your vault BEFORE
# making any further authenticated calls — stale calls will hit AuthTokenRevokedError.
vault.put(workspace_id, "bd_team_token", new["token"])
authed = AccountsClient("https://call.95percent.ai", team_token=new["token"])
```

`otp_prompt` can be sync or async; both are awaited. `rotate_token()` is a convenience that wraps `rotate_token_request()` + `rotate_token_confirm()`. If you need to display a UI between request and confirm (typical web app), use the two-step form:

```python
challenge = await authed.rotate_token_request()
# challenge.phone_hint == "+1********23" — show this to the user
# render UI, get OTP from user...
new = await authed.rotate_token_confirm(challenge["challenge_id"], otp)
```

### Self-heal pattern

After a rotation, multiple holders of the workspace token might have stale copies. The canonical self-heal:

```python
try:
    await authed.get_account()             # any auth'd call works as a probe
except AuthTokenRevokedError:
    # Another tab / job rotated. Refresh from vault, retry.
    fresh = vault.get(workspace_id, "bd_team_token")
    authed = AccountsClient("https://call.95percent.ai", team_token=fresh)
```

`AuthTokenRevokedError` is aliased as `RevokedToken` for shorter `except RevokedToken:` blocks.

---

## Error reference

The SDK reports send failures via `SendResult.failed/error/stage_failed/remediation` (don't catch — branch on `.failed`). Auth-class errors and accounts-API errors **do raise**. Catalogue:

| Class | When it raises | What to do |
|---|---|---|
| `ConfigError` | Missing `base_url`, `agent_id`, or token at construct/call time | Fix the config; not retryable |
| `TransportError` | Network unreachable, DNS, TLS, timeout outside the per-call retry budget | Surface to user; retry at higher level only after sleeping |
| `AuthInvalidTokenError` | 401 `AUTH_INVALID_TOKEN` — token doesn't match any org/agent | Re-prompt operator; **do NOT retry** (each attempt counts toward IP lockout) |
| `AuthTokenRevokedError` (a.k.a. `RevokedToken`) | 401 `AUTH_TOKEN_REVOKED` — token was rotated out | Refresh from vault; retry |
| `AuthMissingHeaderError` | 401 `AUTH_MISSING_HEADER` — no Authorization header sent | Caller misconfiguration; fix headers |
| `AuthLockedOutError` | 429 `AUTH_LOCKED_OUT` — IP locked after BD's per-IP attempt threshold (we've observed it trip at ~10 consecutive failures) | Honor `retry_after_seconds` from the response — do NOT hard-code a duration. Observed lockout windows have ranged from ~5 to ~15 minutes; the server is the source of truth. |
| `RateLimitError` | 429 non-auth (regular rate limit) | Sleep `retry_after_seconds`, retry once |
| `NotProvisioned` | 404/410 from `/api/v1/agents/{id}` — agent never registered or deregistered | Run `register_agent` + `provision_channels` before retrying |
| `NoChannelAssigned` | `code=NO_CHANNEL_ASSIGNED` from REST or `SendResult.error_code="NO_CHANNEL_ASSIGNED"` from MCP — agent registered but `provision_channels` never ran | Call `provision_channels()`; for sends, branch on `result.error_code` (no exception raised on send path) |
| `ProviderCapabilityError` | Provider X doesn't implement action Y (e.g. greenapi can't `post_status`) | Branch on `(channel, action, provider)`; pick a different sender |
| `ChannelError` | Generic per-channel failure (base class for above two) | Use the subclasses; this exists for blanket `except` |
| `AccountsError` | Any error from REST accounts endpoints (register/verify/phone/rotate) | Read `.code` to switch — see subclasses below |
| `OTPInvalid` | `OTP_INVALID` from confirm_phone / rotate_token_confirm | Re-prompt; user mistyped |
| `OTPExpired` | `OTP_EXPIRED` — challenge older than its TTL | Restart with fresh `set_phone()` / `rotate_token_request()` |
| `OTPMaxAttempts` | `OTP_MAX_ATTEMPTS` — too many wrong codes for this challenge | Restart with fresh request |
| `ChallengeNotFound` | `CHALLENGE_NOT_FOUND` — another tab consumed the challenge | Restart with fresh request |
| `PhoneNotConfigured` | `PHONE_NOT_CONFIGURED` — tried to rotate before confirming admin phone | Run `set_phone` + `confirm_phone` first |
| `EmailAlreadyRegistered` | **Never raises** in current server (F04 anti-enumeration) | Don't catch — branch on the webhook arriving |
| `VerificationTokenExpired` | `VERIFICATION_TOKEN_EXPIRED` — verify link is too old | Re-register the same email (idempotent for pending orgs) |
| `TokenRevoked` (accounts variant) | Revoked workspace token | Same as `AuthTokenRevokedError` — refresh from vault |
| `AccountsError` with `code=TEMPLATE_MISSING_VERIFY_URL` | Custom email template body lacks `{{verifyUrl}}` | Add the variable to the template |
| `AccountsError` with `code=TEMPLATE_TOO_LARGE` | Custom email template exceeds BD's size limit (BD-side; exact byte budget is BD's prerogative) | Trim and retry; surface the error to the admin verbatim rather than hard-coding a byte budget |
| `ButtDialError` | Base class — never raised directly, used as the catch-all | `except ButtDialError:` for "any SDK error" handlers |

For send failures (most failures), don't catch — read `result.failed`, `result.stage_failed`, `result.error`, `result.remediation`. The auth/lockout exceptions raise specifically because retrying them digs the hole deeper.

Print this catalogue at runtime via `buttdial errors`.

---

## Diagnostic CLI

Before declaring an integration done, run:

```bash
buttdial doctor --to +1<your test number>
```

Seven staged checks — config / reachability / SSE handshake / tool list / send / receipt / human-ack — each with a curated remediation message. Wire it into your CI as a live integration canary; non-zero exit on any failure.

---

## Version-specific notes

### 0.4.4 (current)

- F90 closed (BD shipped sprint 12 + SDK closed today): `Agent.send_message()` now exposes `SendResult.error_code` and `SendResult.error_channel`, populated from BD's structured envelope (`{"code": "NO_CHANNEL_ASSIGNED", "channel": "whatsapp", "remediation": "..."}`). Server-supplied `remediation` is preferred over the SDK's curated map. Branch on `result.error_code` instead of substring-matching on `result.error`.
- New typed exception `buttdial.NoChannelAssigned(ChannelError)` for the REST surface (`AccountsClient` raises it on `code=NO_CHANNEL_ASSIGNED` 4xx). For sends, the MCP path returns `SendResult` instead of raising — same convention as every other send error.

### 0.4.3

- **AGENTS.md and canonical examples now ship inside the wheel.** Run `buttdial guide` to print this document. Run `buttdial example list / show / extract` to discover and lift canonical patterns. Run `buttdial errors` to print the typed-exception reference at runtime. No internet round-trip required.
- New CLI subcommands: `buttdial guide`, `buttdial example`, `buttdial errors` — alongside the existing `buttdial doctor`.

### 0.4.2

- F91: `buttdial doctor` skipped stages now render `[SKIP]` (not `[FAIL]`), matching the "All stages passed" summary.

### 0.4.1

- Bare `register()` form emits `DeprecationWarning`. Watch your CI / Sentry for it; if present, your code is at risk of the unbranded-email + no-callback gap.
- New positional kwargs on `register()`: `branding`, `return_url`, `webhook_url`, `verification_email`. All optional but strongly recommended for production hosts.
- New module `buttdial.webhooks` with `verify_webhook_signature()` (Stripe-style HMAC-SHA256 + 5-min replay window + constant-time compare).
- New error codes mapped: `TEMPLATE_MISSING_VERIFY_URL`, `TEMPLATE_TOO_LARGE`. Both raise as `AccountsError` with `.code` set.
- `AccountsClient.get_agent_self()` removed — was always 404ing on the live server. Use `get_agent(agent_id)` instead.

### Server contract notes (these don't depend on SDK version)

- Server uses **camelCase** in JSON wire keys: `agentId`, `messageId`, `templateId`, `idempotencyKey`. Some legacy endpoints emit both casings (`agent_id` + `agentId`); BD has marked snake_case as deprecated with `Sunset: 2026-07-27` headers. Read the camelCase form; don't depend on snake_case.
- BD silently re-sends verification on existing-email registers. If your code expects `EMAIL_ALREADY_REGISTERED`, you'll never see it. F04 anti-enumeration. (The `EmailAlreadyRegistered` exception class is preserved as a forward-compat hook only.)
- BD's `verify` response carries `team_token` (canonical), `ownerToken` and `owner_token` (deprecated aliases for one release). Read `team_token` first.
- `pollToken` (every register response, sprint-10+) is the auth path for `/api/orgs/{orgId}/verification-status?poll_token=...`. Use it during signup before you have a `team_token`.

---

## Where to look for canonical examples

These ship inside the wheel as of 0.4.3 — run `buttdial example list` to enumerate, `buttdial example show <name>` to print, `buttdial example extract <name> <dir>` to copy into your project.

- **`with-onboarding-handshake`** — complete FastAPI host: branded register + signed webhook + workspace persistence. **Lift from here when generating onboarding code.**
- **`with-inbound`** — full FastAPI app receiving inbound messages with the InboundHandler decorator pattern.
- **`with-retry`** — SQLAlchemy-backed `FailedMessageRepository` for the `RetryWorker`.
- **`minimal`** — bare-bones smoke test only. **Do not lift this for production code.**

---

## Reporting back

If you're an agent that just generated code using this SDK, the human reviewing your PR will want to see:

### Onboarding
1. Did you pass `branding`, `return_url`, `webhook_url` to every `register()` call site?
2. Did you build the webhook receiver with `verify_webhook_signature` + dedupe + signature check?
3. Did you persist `webhookSecret` (capture-once) and `pollToken` somewhere durable?
4. Did you avoid catching `EmailAlreadyRegistered`?

### Workspace setup
5. Did you call `set_phone` + `confirm_phone` before any `rotate_token` flow?
6. Did you generate the `agent_id` UUID host-side (not expecting BD to mint it)?
7. Did you call `provision_channels` after `register_agent` and store the **provision response's** token (not the registration token)?

### Send / receive
8. Did you pass `idempotency_key` on every `send_message` call?
9. Are you using `SendResult.failed` to branch, not exceptions, for sends?
10. Did you mount `InboundHandler.router` instead of writing your own webhook handlers?
11. Are inbound handlers non-blocking (queue work, return fast)?

### Errors
12. Did you import typed exceptions from `buttdial` (not catch generic `Exception`)?
13. For auth errors: did you avoid retrying `AuthInvalidTokenError` / `AuthMissingHeaderError`? (Both walk into IP lockout.)

If yes to all 13, the integration follows the canonical pattern. If no to any, link the line of this doc you missed.
