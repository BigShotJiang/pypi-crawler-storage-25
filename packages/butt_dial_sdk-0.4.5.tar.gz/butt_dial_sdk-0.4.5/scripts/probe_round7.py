"""Round 7 — verify BD's sprint-12+ claimed closures against call.95percent.ai.

Targets (per BD's round-6 follow-up message):
  - F89: webhookSecret presence symmetric across pending vs verified email
  - F90: comms_send_message returns code:NO_CHANNEL_ASSIGNED + remediation
  - F21: MCP serverInfo.version → 1.0.0
  - F84: OpenAPI info.title → "Butt-Dial — REST API" (no more "VOS")
  - F04 (strengthened): same email through user_accounts dedup also collapses
  - F92: /docs/mcp-tools scope vocabulary updated

Run:
    PYTHONIOENCODING=utf-8 python scripts/probe_round7.py
"""

from __future__ import annotations

import asyncio
import json
import sys
import uuid
from pathlib import Path
from typing import Any

import httpx
from mcp import ClientSession
from mcp.client.sse import sse_client

from buttdial import AccountsClient, Agent
from buttdial.errors import ButtDialError

BASE_URL = "https://call.95percent.ai"
ROOT = Path(__file__).resolve().parents[1]


def _load(name: str) -> str:
    p = ROOT / name
    return p.read_text().strip() if p.exists() else ""


TEAM_TOKEN = _load(".bd_token")
AGENT_TOKEN = _load(".bd_agent_token")
AGENT_ID = _load(".bd_agent_id")


results: list[dict[str, Any]] = []


def record(finding: str, surface: str, status: str, detail: str = "") -> None:
    results.append(
        {"finding": finding, "surface": surface, "status": status, "detail": detail}
    )
    icon = {"PASS": "[ok]", "FAIL": "[xx]", "SKIP": "[..]", "INFO": "[ii]"}[status]
    print(f"  {icon} {finding:<8} {surface:<55} {detail}")


# ---------------------------------------------------------------------------
# F84 — OpenAPI title purged of "VOS"
# ---------------------------------------------------------------------------


async def probe_f84() -> None:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(f"{BASE_URL}/openapi.json")
    if r.status_code != 200:
        record("F84", "GET /openapi.json", "FAIL", f"http {r.status_code}")
        return
    title = r.json().get("info", {}).get("title", "")
    contains_butt_dial = "Butt-Dial" in title
    contains_vos = "VOS" in title or "vos" in title.lower()
    if contains_butt_dial and not contains_vos:
        record("F84", "OpenAPI info.title", "PASS", f"title={title!r}")
    else:
        record("F84", "OpenAPI info.title", "FAIL",
               f"title={title!r} (butt-dial={contains_butt_dial}, vos={contains_vos})")


# ---------------------------------------------------------------------------
# F21 — MCP serverInfo.version 0.1.0 → 1.0.0
# ---------------------------------------------------------------------------


async def probe_f21() -> None:
    if not AGENT_TOKEN:
        record("F21", "MCP initialize", "SKIP", "no agent_token")
        return
    headers = {"Authorization": f"Bearer {AGENT_TOKEN}"}
    try:
        async with sse_client(f"{BASE_URL}/sse", headers=headers, timeout=15) as (read, write):
            async with ClientSession(read, write) as session:
                init = await session.initialize()
                version = init.serverInfo.version
                if version == "1.0.0":
                    record("F21", "MCP serverInfo.version", "PASS", f"version={version!r}")
                elif version.startswith("1."):
                    record("F21", "MCP serverInfo.version", "PASS",
                           f"version={version!r} (1.x family — accepted)")
                else:
                    record("F21", "MCP serverInfo.version", "FAIL",
                           f"version={version!r} (expected 1.0.0)")
    except Exception as e:  # noqa: BLE001
        record("F21", "MCP serverInfo.version", "FAIL", repr(e))


# ---------------------------------------------------------------------------
# F89 — webhookSecret symmetry across pending vs verified register
# ---------------------------------------------------------------------------


async def probe_f89() -> None:
    accounts = AccountsClient(BASE_URL)

    # Fresh email — should be pending after register, returns webhookSecret.
    fresh_email = f"r7-fresh-{uuid.uuid4().hex[:10]}@elradts.com"
    try:
        resp_pending = await accounts.register(
            org_name="Round7 F89 pending",
            owner_email=fresh_email,
            branding={"productName": "R7"},
            return_url="https://acme.example/welcome",
            webhook_url="https://acme.example/wh",
        )
    except ButtDialError as e:
        record("F89", "register(pending email)", "FAIL", repr(e))
        return

    pending_keys = sorted(resp_pending.keys())
    has_webhook_secret_pending = "webhookSecret" in resp_pending

    # Re-register the SAME email — for a pending org BD treats it as idempotent
    # (same shape). For F89 we want to verify webhookSecret presence is symmetric
    # across the verified-email path too. Without a verified email at hand, we
    # use the previously-known stored team_token's email.
    # The strongest test: register against `inon@elradts.com` which is verified.
    verified_email = "inon@elradts.com"
    try:
        resp_verified = await accounts.register(
            org_name="Round7 F89 verified",
            owner_email=verified_email,
            branding={"productName": "R7"},
            return_url="https://acme.example/welcome",
            webhook_url="https://acme.example/wh",
        )
    except ButtDialError as e:
        record("F89", "register(verified email)", "FAIL",
               f"unexpected error: {e!r} (expected silent re-send)")
        return

    verified_keys = sorted(resp_verified.keys())
    has_webhook_secret_verified = "webhookSecret" in resp_verified

    # Goal: BOTH responses include webhookSecret (BD now emits a random dummy
    # for the verified path so the response shape is constant).
    detail = (
        f"pending keys={pending_keys}, verified keys={verified_keys}; "
        f"webhookSecret present: pending={has_webhook_secret_pending} "
        f"verified={has_webhook_secret_verified}"
    )
    if has_webhook_secret_pending and has_webhook_secret_verified:
        record("F89", "register response shape symmetry", "PASS", detail)
    else:
        record("F89", "register response shape symmetry", "FAIL", detail)


# ---------------------------------------------------------------------------
# F90 — code:NO_CHANNEL_ASSIGNED on send to unprovisioned agent
# ---------------------------------------------------------------------------


async def probe_f90() -> None:
    if not (AGENT_TOKEN and AGENT_ID):
        record("F90", "comms_send_message error envelope", "SKIP",
               "no agent_token / agent_id")
        return

    agent = Agent(base_url=BASE_URL, agent_id=AGENT_ID, agent_token=AGENT_TOKEN)
    result = await agent.send_message(
        to="+15555550100",
        body="round7 probe — should fail on no channel",
        idempotency_key=f"r7-{uuid.uuid4().hex}",
    )

    if not result.failed:
        record("F90", "comms_send_message error envelope", "FAIL",
               f"unexpectedly succeeded sid={result.message_sid!r}")
        return

    raw = getattr(result, "raw", None)
    error_text = (result.error or "")
    found_code = None
    found_remediation = None
    # The SDK surfaces the body via .raw; dig for the 'code' field.
    if isinstance(raw, dict):
        found_code = raw.get("code") or (raw.get("error") or {}).get("code") if isinstance(raw.get("error"), dict) else raw.get("code")
        found_remediation = raw.get("remediation")
    # Fall back: maybe the SDK already lifted code into result
    code_attr = getattr(result, "error_code", None) or getattr(result, "code", None)
    if not found_code and code_attr:
        found_code = code_attr

    detail = (
        f"failed=True, error={error_text[:80]!r}, "
        f"code={found_code!r}, remediation={(found_remediation or '')[:60]!r}"
    )

    if found_code == "NO_CHANNEL_ASSIGNED":
        record("F90", "comms_send_message error envelope", "PASS", detail)
    elif "NO_CHANNEL_ASSIGNED" in error_text:
        record("F90", "comms_send_message error envelope", "PASS",
               f"{detail} (code in message text, not envelope field — partial)")
    else:
        record("F90", "comms_send_message error envelope", "INFO",
               f"{detail} — code field not surfaced via SDK; raw={str(raw)[:200]!r}")


# ---------------------------------------------------------------------------
# F92 — /docs/mcp-tools scope vocabulary updated
# ---------------------------------------------------------------------------


async def probe_f92() -> None:
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(f"{BASE_URL}/docs/mcp-tools", follow_redirects=True)
    if r.status_code != 200:
        record("F92", "/docs/mcp-tools", "INFO", f"http {r.status_code} (may be index path)")
        return
    body = r.text
    has_admin_set = all(s in body for s in ["org-admin", "super-admin", "agent", "any"])
    record("F92", "/docs/mcp-tools scope vocabulary",
           "PASS" if has_admin_set else "INFO",
           f"contains 4-tier set: {has_admin_set}")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


async def main() -> int:
    print(f"butt-dial-sdk — round-7 verification — {BASE_URL}")
    print(f"team_token  : {'set' if TEAM_TOKEN else 'MISSING'}")
    print(f"agent_token : {'set' if AGENT_TOKEN else 'MISSING'}")
    print(f"agent_id    : {AGENT_ID or 'MISSING'}")
    print()

    print("=== Probes (BD round-6 follow-up claims) ===")
    await probe_f21()
    await probe_f84()
    await probe_f89()
    await probe_f90()
    await probe_f92()

    print()
    print("=== Summary ===")
    counts: dict[str, int] = {"PASS": 0, "FAIL": 0, "SKIP": 0, "INFO": 0}
    for r in results:
        counts[r["status"]] += 1
    print(f"  PASS={counts['PASS']}  FAIL={counts['FAIL']}  "
          f"SKIP={counts['SKIP']}  INFO={counts['INFO']}")

    out = ROOT / "docs" / "round7_live_results.json"
    out.write_text(json.dumps(results, indent=2))
    print(f"  wrote {out.relative_to(ROOT)}")

    return 0 if counts["FAIL"] == 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
