"""Live probe of call.95percent.ai — open an unauthenticated MCP/SSE
session and try list_tools. Throwaway script, not committed."""

import asyncio
import sys

from mcp import ClientSession
from mcp.client.sse import sse_client

URL = "https://call.95percent.ai/sse"


async def main() -> int:
    import os
    token = os.environ.get("BD_TEAM_TOKEN", "")
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    print(f"opening SSE -> {URL} (auth={'yes' if token else 'no'})")
    try:
        async with sse_client(URL, headers=headers, timeout=10.0) as (read, write):
            async with ClientSession(read, write) as session:
                init = await session.initialize()
                print("initialize OK:")
                print(f"  server: {init.serverInfo.name} v{init.serverInfo.version}")
                print(f"  protocolVersion: {init.protocolVersion}")
                tools = await session.list_tools()
                names = [t.name for t in tools.tools]
                print(f"list_tools OK: {len(names)} tool(s)")
                for n in names:
                    print(f"  - {n}")
        return 0
    except BaseException as exc:  # noqa: BLE001
        print(f"FAILED: {type(exc).__name__}: {exc}")
        # Unwrap exception group / task group if present
        sub = getattr(exc, "exceptions", None)
        if sub:
            for e in sub:
                print(f"  sub: {type(e).__name__}: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
