"""Probe MCP tool surface: list all tool descriptions/schemas, then
call a curated read-only set. Reads agent token from BD_AGENT_TOKEN."""

import asyncio
import json
import os
import sys

from mcp import ClientSession
from mcp.client.sse import sse_client

URL = "https://call.95percent.ai/sse"

# Read-only-looking tools to invoke. Conservative: nothing that
# allocates phone numbers, sends messages, charges money, or mutates
# persistent state.
SAFE_CALLS = [
    ("comms_validate_number", {"phone": "+15555550123"}),
    ("comms_validate_number", {"phone": "not-a-number"}),
    ("comms_get_channel_status", {}),
    ("comms_check_consent", {"phone": "+15555550123"}),
    ("comms_check_trust", {"phone": "+15555550123"}),
    ("comms_list_sessions", {}),
    ("comms_get_usage_dashboard", {}),
    ("comms_get_income", {}),
    ("comms_list_available_numbers", {"countryCode": "US"}),
    ("comms_list_available_numbers", {"country": "US"}),  # in case key name differs
]


def short(text: str, n: int = 100) -> str:
    text = (text or "").replace("\n", " ").strip()
    return text if len(text) <= n else text[: n - 1] + "…"


async def main() -> int:
    token = os.environ.get("BD_AGENT_TOKEN", "")
    if not token:
        print("BD_AGENT_TOKEN not set", file=sys.stderr)
        return 2
    headers = {"Authorization": f"Bearer {token}"}

    async with sse_client(URL, headers=headers, timeout=15.0) as (read, write):
        async with ClientSession(read, write) as session:
            init = await session.initialize()
            print(f"server: {init.serverInfo.name} v{init.serverInfo.version}")
            print(f"protocolVersion: {init.protocolVersion}")
            print()

            tools = await session.list_tools()
            print(f"=== {len(tools.tools)} tools — name + description ===")
            for t in tools.tools:
                print(f"  {t.name}")
                print(f"    desc: {short(t.description, 140)}")
            print()

            print("=== full schema for a representative sample ===")
            sample_names = {
                "comms_ping",
                "comms_send_message",
                "comms_validate_number",
                "comms_check_consent",
                "comms_provision_channels",
                "comms_make_call",
                "comms_whatsapp_action",
                "comms_get_usage_dashboard",
            }
            for t in tools.tools:
                if t.name in sample_names:
                    print(f"--- {t.name} ---")
                    print(f"description: {t.description}")
                    print("inputSchema:")
                    print(json.dumps(t.inputSchema, indent=2))
                    print()

            print("=== safe read-only tool calls ===")
            for name, args in SAFE_CALLS:
                print(f"--- {name}({json.dumps(args)}) ---")
                try:
                    result = await session.call_tool(name, arguments=args)
                    is_err = getattr(result, "isError", False)
                    print(f"  isError: {is_err}")
                    for c in result.content:
                        text = getattr(c, "text", str(c))
                        try:
                            parsed = json.loads(text)
                            print("  parsed:")
                            print(json.dumps(parsed, indent=2))
                        except Exception:
                            print(f"  raw: {short(text, 400)}")
                except BaseException as exc:
                    print(f"  CALL FAILED: {type(exc).__name__}: {exc}")
                print()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
