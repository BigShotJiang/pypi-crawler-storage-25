"""Round 6 live validation — exercise every SDK surface against call.95percent.ai.

Maps each SDK call to its server endpoint and reports pass / fail / skip with
detail. Reads:
    .bd_token         — team_token (from earlier verify)
    .bd_agent_token   — agent_token (from earlier register_agent)

Run:
    python scripts/probe_round6.py
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
import uuid
from pathlib import Path
from typing import Any

import httpx

from buttdial import AccountsClient, Agent
from buttdial.errors import ButtDialError

BASE_URL = "https://call.95percent.ai"
ROOT = Path(__file__).resolve().parents[1]


def _load(name: str) -> str:
    p = ROOT / name
    return p.read_text().strip() if p.exists() else ""


TEAM_TOKEN = _load(".bd_token")
AGENT_TOKEN = _load(".bd_agent_token")
AGENT_ID = _load(".bd_agent_id")  # may be empty


# ------------- result accumulator -------------

results: list[dict[str, Any]] = []


def record(
    surface: str,
    endpoint: str,
    status: str,  # "PASS" | "FAIL" | "SKIP"
    detail: str = "",
) -> None:
    results.append(
        {"surface": surface, "endpoint": endpoint, "status": status, "detail": detail}
    )
    icon = {"PASS": "[ok]", "FAIL": "[xx]", "SKIP": "[..]"}[status]
    print(f"  {icon} {surface:<40} {endpoint:<45} {detail}")


# ------------- REST surface (AccountsClient) -------------


async def rest_surface() -> None:
    print("\n=== REST surface (AccountsClient) ===")
    if not TEAM_TOKEN:
        print("  no team_token; skipping authenticated REST calls")
        record("AccountsClient", "<authenticated>", "SKIP", "no .bd_token")
        return

    accounts = AccountsClient(BASE_URL, team_token=TEAM_TOKEN)

    # get_account ---------------------------------------------------------
    try:
        acct = await accounts.get_account()
        record(
            "AccountsClient.get_account",
            "GET /api/orgs/me",
            "PASS",
            f"orgId={acct.get('org_id') or acct.get('orgId')!r}",
        )
        org_id = acct.get("org_id") or acct.get("orgId")
    except ButtDialError as e:
        record("AccountsClient.get_account", "GET /api/orgs/me", "FAIL", repr(e))
        org_id = None

    # list / get_agent — try with stored agent_id first --------------------
    if AGENT_ID:
        try:
            ag = await accounts.get_agent(AGENT_ID)
            record(
                "AccountsClient.get_agent",
                f"GET /api/v1/agents/{AGENT_ID[:8]}…",
                "PASS",
                f"keys={sorted(ag.keys())[:5]}",
            )
        except ButtDialError as e:
            record(
                "AccountsClient.get_agent",
                "GET /api/v1/agents/{id}",
                "FAIL",
                repr(e),
            )
    else:
        record(
            "AccountsClient.get_agent",
            "GET /api/v1/agents/{id}",
            "SKIP",
            "no .bd_agent_id stored",
        )

    # set_phone — would consume an SMS, skip --------------------------------
    record(
        "AccountsClient.set_phone",
        "POST /api/orgs/me/phone/set",
        "SKIP",
        "would send SMS; not exercised",
    )
    record(
        "AccountsClient.confirm_phone",
        "POST /api/orgs/me/phone/confirm",
        "SKIP",
        "depends on set_phone",
    )

    # rotate_token_request — destructive on success, but request-only is safe
    record(
        "AccountsClient.rotate_token_request",
        "POST /api/orgs/me/rotate-token/request",
        "SKIP",
        "would send OTP SMS; not exercised",
    )
    record(
        "AccountsClient.rotate_token_confirm",
        "POST /api/orgs/me/rotate-token/confirm",
        "SKIP",
        "destructive — would revoke .bd_token",
    )


# ------------- Onboarding handshake (0.4.0 kwargs) -------------


async def onboarding_handshake() -> None:
    print("\n=== Onboarding handshake (0.4.0 kwargs) ===")
    accounts = AccountsClient(BASE_URL)

    # use a fresh, pending email so webhookSecret comes back
    fresh_email = f"r6-{uuid.uuid4().hex[:10]}@elradts.com"
    branding = {
        "logoUrl": "https://acme.example/logo.svg",
        "primaryColor": "#00C9A7",
        "productName": "Round6 Probe",
        "supportEmail": "support@acme.example",
    }
    try:
        resp = await accounts.register(
            org_name="Round6 Probe Inc",
            owner_email=fresh_email,
            branding=branding,
            return_url="https://acme.example/welcome",
            webhook_url="https://acme.example/api/webhooks/butt-dial/account-verified",
            verification_email={
                "subject": "Verify your Round6 workspace",
                "html": '<p>Click <a href="{{verifyUrl}}">verify</a> ({{orgName}}).</p>',
            },
        )
    except ButtDialError as e:
        record("register(branded)", "POST /api/orgs/register", "FAIL", repr(e))
        return

    keys = sorted(resp.keys())
    has_secret = "webhookSecret" in resp
    has_poll = "pollToken" in resp
    has_org = "orgId" in resp
    detail = f"orgId={has_org} webhookSecret={has_secret} pollToken={has_poll} keys={keys}"
    status = "PASS" if (has_org and has_secret and has_poll) else "FAIL"
    record("register(branded)", "POST /api/orgs/register", status, detail)

    if not has_poll:
        record(
            "verification-status (pollToken)",
            "GET /api/orgs/{id}/verification-status",
            "SKIP",
            "no pollToken",
        )
        return

    # poll verification-status with the pollToken
    org_id = resp["orgId"]
    poll = resp["pollToken"]
    url = f"{BASE_URL}/api/orgs/{org_id}/verification-status"
    try:
        async with httpx.AsyncClient(timeout=15.0) as c:
            r = await c.get(url, params={"poll_token": poll})
        if r.status_code == 200:
            body = r.json()
            record(
                "verification-status (pollToken)",
                "GET /api/orgs/{id}/verification-status",
                "PASS",
                f"status={body.get('status')!r}",
            )
        else:
            record(
                "verification-status (pollToken)",
                "GET /api/orgs/{id}/verification-status",
                "FAIL",
                f"http {r.status_code}: {r.text[:120]}",
            )
    except httpx.HTTPError as e:
        record(
            "verification-status (pollToken)",
            "GET /api/orgs/{id}/verification-status",
            "FAIL",
            repr(e),
        )

    # template error paths --------------------------------------------------
    try:
        await accounts.register(
            org_name="Bad Template Inc",
            owner_email=f"r6t-{uuid.uuid4().hex[:8]}@elradts.com",
            verification_email={"html": "<p>No verifyUrl variable here</p>"},
        )
        record(
            "register(missing verifyUrl)",
            "POST /api/orgs/register",
            "FAIL",
            "expected TEMPLATE_MISSING_VERIFY_URL",
        )
    except ButtDialError as e:
        code = getattr(e, "code", "")
        if code == "TEMPLATE_MISSING_VERIFY_URL":
            record(
                "register(missing verifyUrl)",
                "POST /api/orgs/register",
                "PASS",
                f"raised {code}",
            )
        else:
            record(
                "register(missing verifyUrl)",
                "POST /api/orgs/register",
                "FAIL",
                f"wrong code: {code!r} — {e}",
            )


# ------------- MCP surface (Agent) -------------


async def mcp_surface() -> None:
    print("\n=== MCP surface (Agent) ===")
    if not AGENT_TOKEN or not AGENT_ID:
        record("Agent.send_message", "MCP comms_send_message", "SKIP",
               "missing .bd_agent_token or .bd_agent_id")
        return

    agent = Agent(
        base_url=BASE_URL,
        agent_id=AGENT_ID,
        agent_token=AGENT_TOKEN,
    )

    # SSE handshake + tool listing
    try:
        names = await agent.list_tools()
        record("Agent.list_tools", "GET /sse + list_tools",
               "PASS", f"{len(names)} tools")
    except Exception as e:  # noqa: BLE001
        record("Agent.list_tools", "GET /sse + list_tools", "FAIL", repr(e))
        return

    # ping
    try:
        ok = await agent.ping()
        record("Agent.ping", "MCP comms_ping", "PASS" if ok else "FAIL",
               f"ok={ok}")
    except Exception as e:  # noqa: BLE001
        record("Agent.ping", "MCP comms_ping", "FAIL", repr(e))

    # comms_send_message — PASS only if to/idem path responds; we don't
    # actually want to charge an SMS, so we use an obviously-invalid number
    # and look for the validation error envelope.
    try:
        result = await agent.send_message(
            to="+15555550100",  # known unallocated TEST range
            body="round6 probe (should not deliver)",
            idempotency_key=f"r6-{uuid.uuid4().hex}",
        )
        if result.failed:
            record(
                "Agent.send_message",
                "MCP comms_send_message",
                "PASS",
                f"failed-as-expected stage={result.stage_failed} err={(result.error or '')[:60]}",
            )
        else:
            record(
                "Agent.send_message",
                "MCP comms_send_message",
                "PASS",
                f"unexpectedly succeeded sid={result.message_sid}",
            )
    except Exception as e:  # noqa: BLE001
        record("Agent.send_message", "MCP comms_send_message", "FAIL", repr(e))


# ------------- main -------------


async def main() -> int:
    print(f"butt-dial-sdk live validation — {BASE_URL}")
    print(f"team_token  : {'set' if TEAM_TOKEN else 'MISSING'}")
    print(f"agent_token : {'set' if AGENT_TOKEN else 'MISSING'}")
    print(f"agent_id    : {AGENT_ID or 'MISSING'}")

    await rest_surface()
    await onboarding_handshake()
    await mcp_surface()

    print("\n=== summary ===")
    by_status: dict[str, int] = {"PASS": 0, "FAIL": 0, "SKIP": 0}
    for r in results:
        by_status[r["status"]] += 1
    print(f"  PASS={by_status['PASS']}  FAIL={by_status['FAIL']}  SKIP={by_status['SKIP']}")

    out = ROOT / "docs" / "round6_live_results.json"
    out.write_text(json.dumps(results, indent=2))
    print(f"  wrote {out.relative_to(ROOT)}")

    return 0 if by_status["FAIL"] == 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
