"""Live probe of comms_ping over MCP. Reads token from BD_AGENT_TOKEN env."""

import asyncio
import json
import os
import sys

from mcp import ClientSession
from mcp.client.sse import sse_client

URL = "https://call.95percent.ai/sse"


async def probe(token_label: str, token: str) -> int:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    print(f"=== comms_ping with {token_label} ===")
    try:
        async with sse_client(URL, headers=headers, timeout=15.0) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool("comms_ping", arguments={})
                print(f"  call_tool OK")
                # Result has .content (list of TextContent) and .isError
                print(f"  isError: {getattr(result, 'isError', 'n/a')}")
                for c in result.content:
                    text = getattr(c, "text", str(c))
                    # Try to pretty-print JSON
                    try:
                        parsed = json.loads(text)
                        print(f"  parsed: {json.dumps(parsed, indent=2)}")
                    except Exception:
                        print(f"  raw: {text}")
        return 0
    except BaseException as exc:  # noqa: BLE001
        print(f"  FAILED: {type(exc).__name__}: {exc}")
        sub = getattr(exc, "exceptions", None)
        if sub:
            for e in sub:
                print(f"    sub: {type(e).__name__}: {e}")
        return 1


async def main() -> int:
    agent_tok = os.environ.get("BD_AGENT_TOKEN", "")
    team_tok = os.environ.get("BD_TEAM_TOKEN", "")
    rc = 0
    if agent_tok:
        rc |= await probe("agent_token", agent_tok)
    if team_tok:
        rc |= await probe("team_token", team_tok)
    return rc


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
