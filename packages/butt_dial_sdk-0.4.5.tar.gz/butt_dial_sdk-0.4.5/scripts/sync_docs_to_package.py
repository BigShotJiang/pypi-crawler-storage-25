"""Mirror AGENTS.md + examples/ into src/buttdial/_docs/ and src/buttdial/_examples/.

Run before every release / when AGENTS.md or examples/ change. Idempotent.
The destination is what ships in the wheel; the source at repo root is the
single source of truth a developer / GitHub reader sees.

Usage:
    python scripts/sync_docs_to_package.py
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "src" / "buttdial"

DOCS_SRC = ROOT / "AGENTS.md"
DOCS_DST = PKG / "_docs" / "AGENTS.md"

EXAMPLES_SRC = ROOT / "examples"
EXAMPLES_DST = PKG / "_examples"

# Map repo-root example dirs (with hyphens) → package example dirs (with hyphens
# preserved — directories are read at runtime, never imported as Python).
EXAMPLE_DIRS = [
    "minimal",
    "with-onboarding-handshake",
    "with-inbound",
    "with-retry",
]


def _copy_file(src: Path, dst: Path) -> bool:
    """Copy one file, creating parent dirs. Returns True if content changed."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.read_bytes() == src.read_bytes():
        return False
    shutil.copy2(src, dst)
    return True


def _copy_tree(src: Path, dst: Path) -> int:
    """Mirror a directory tree. Returns number of files changed."""
    changed = 0
    if dst.exists():
        # Drop stale files; recreate fresh.
        shutil.rmtree(dst)
    if not src.exists():
        print(f"WARN: source {src} does not exist; skipping", file=sys.stderr)
        return 0
    dst.mkdir(parents=True, exist_ok=True)
    for path in src.rglob("*"):
        if path.is_dir():
            continue
        if path.name in {".DS_Store", "__pycache__"} or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(src)
        if _copy_file(path, dst / rel):
            changed += 1
    return changed


def main() -> int:
    docs_changed = _copy_file(DOCS_SRC, DOCS_DST)
    print(f"AGENTS.md: {'updated' if docs_changed else 'unchanged'} -> {DOCS_DST.relative_to(ROOT)}")

    total_examples_changed = 0
    for name in EXAMPLE_DIRS:
        n = _copy_tree(EXAMPLES_SRC / name, EXAMPLES_DST / name)
        total_examples_changed += n
        if n:
            print(f"examples/{name}: {n} file(s) updated -> {(EXAMPLES_DST / name).relative_to(ROOT)}")
        else:
            print(f"examples/{name}: unchanged")

    print(f"\nDone. {1 if docs_changed else 0} doc + {total_examples_changed} example file(s) updated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
