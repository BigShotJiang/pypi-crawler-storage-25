"""Round 3 mining: close out schema-mismatch tools, test agent-creation
idempotency, and call the lifecycle / OTP / session tools we haven't
yet probed. Read-only-or-low-impact only."""

import asyncio
import json
import os
import sys

from mcp import ClientSession
from mcp.client.sse import sse_client

URL = "https://call.95percent.ai/sse"


def short(s: object, n: int = 500) -> str:
    s = str(s).replace("\n", " ").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


async def call(session: ClientSession, name: str, args: dict) -> None:
    print(f"--- {name}({json.dumps(args)}) ---")
    try:
        result = await session.call_tool(name, arguments=args)
        is_err = getattr(result, "isError", False)
        print(f"  isError: {is_err}")
        for c in result.content:
            text = getattr(c, "text", str(c))
            try:
                parsed = json.loads(text)
                print("  parsed:")
                print(json.dumps(parsed, indent=2))
            except Exception:
                print(f"  raw: {short(text, 600)}")
    except BaseException as exc:
        print(f"  CALL FAILED: {type(exc).__name__}: {short(exc, 200)}")
    print()


async def main() -> int:
    token = os.environ.get("BD_AGENT_TOKEN", "")
    if not token:
        print("BD_AGENT_TOKEN not set", file=sys.stderr)
        return 2
    headers = {"Authorization": f"Bearer {token}"}

    async with sse_client(URL, headers=headers, timeout=15.0) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            print("=== A. closing out schema-mismatch tools ===")
            await call(session, "comms_validate_number", {"phoneNumber": "+15555550123"})
            await call(session, "comms_validate_number", {"phoneNumber": "not-a-number"})
            await call(session, "comms_validate_number", {"phoneNumber": "+972526557547"})
            await call(session, "comms_check_consent", {"contactAddress": "+15555550123", "channel": "sms"})
            await call(session, "comms_check_consent", {"contactAddress": "+15555550123", "channel": "whatsapp"})
            await call(session, "comms_check_trust", {"contactAddress": "+15555550123"})
            await call(session, "comms_get_message_status", {"messageId": "fake-id-does-not-exist"})
            await call(session, "comms_get_session", {"sessionId": "fake-session-id"})
            await call(session, "comms_find_agent", {})

            print("=== B. agent dedup / idempotency ===")
            # The agent d51b0eb9-... already exists in this org.
            existing = "d51b0eb9-0a27-4225-bb55-9c9355935f87"
            print("--- register_agent with same agent_id (REST not MCP) — see bash probes ---")
            print()

            print("=== C. send_message validation order with idempotencyKey ===")
            # Use an obviously-invalid 'to' so nothing gets sent.
            # If idempotency is checked BEFORE validation, a repeat call
            # should return the cached error (not re-validate).
            await call(session, "comms_send_message", {
                "to": "not-a-real-recipient",
                "body": "round3 idempotency probe",
                "idempotencyKey": "round3-probe-key-1"
            })
            await call(session, "comms_send_message", {
                "to": "not-a-real-recipient",
                "body": "round3 idempotency probe",
                "idempotencyKey": "round3-probe-key-1"  # same key
            })

            print("=== D. lifecycle / OTP / session tool error shapes ===")
            await call(session, "comms_send_otp", {})
            await call(session, "comms_verify_otp", {})
            await call(session, "comms_create_session", {})
            await call(session, "comms_subscribe_inbound", {})
            await call(session, "comms_set_callback_url", {})
            await call(session, "comms_set_voice_callback", {})
            await call(session, "comms_rotate_token", {})  # don't pass any args; observe error

            print("=== E. extra-field strictness ===")
            await call(session, "comms_ping", {"unknownField": "should-be-rejected-or-ignored"})

    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
