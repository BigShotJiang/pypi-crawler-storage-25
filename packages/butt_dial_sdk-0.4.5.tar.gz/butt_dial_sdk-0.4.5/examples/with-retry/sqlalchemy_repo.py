"""Reference implementation of `FailedMessageRepository` using SQLAlchemy.

Assumes a `failed_messages` table matching this schema:

    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient       TEXT NOT NULL,
    body            TEXT NOT NULL,
    channel         TEXT DEFAULT 'whatsapp',
    agent_name      TEXT DEFAULT '',
    agent_token     TEXT DEFAULT '',
    thread_id       TEXT,
    entity_id       TEXT,
    reply_msg_id    TEXT,
    retry_count     INT DEFAULT 0,
    max_retries     INT DEFAULT 5,
    last_error      TEXT,
    status          TEXT DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    next_retry_at   TIMESTAMPTZ DEFAULT NOW() + INTERVAL '60 seconds',
    resolved_at     TIMESTAMPTZ

Wire it up:

    from buttdial import Agent, RetryWorker
    from examples.with_retry.sqlalchemy_repo import SqlAlchemyFailedMessageRepository

    bd = Agent.from_env()
    repo = SqlAlchemyFailedMessageRepository(async_session_factory=your_session_factory)
    worker = RetryWorker(repo=repo, client=bd)
    await worker.start(interval_seconds=60.0)
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime
from typing import Any

from sqlalchemy import text

from buttdial import FailedMessage


class SqlAlchemyFailedMessageRepository:
    """Implementation of `buttdial.FailedMessageRepository` against Postgres."""

    def __init__(self, async_session_factory: Callable[[], Any]) -> None:
        self._session_factory = async_session_factory

    async def fetch_due(self, limit: int) -> list[FailedMessage]:
        async with self._session_factory() as session:
            rows = (
                await session.execute(
                    text(
                        """
                        SELECT id, recipient, body, channel, agent_name, agent_token,
                               thread_id, entity_id, reply_msg_id, retry_count,
                               max_retries, last_error, status, created_at,
                               next_retry_at, resolved_at
                        FROM failed_messages
                        WHERE status = 'pending' AND next_retry_at <= NOW()
                        ORDER BY next_retry_at
                        LIMIT :limit
                        """
                    ),
                    {"limit": limit},
                )
            ).mappings().all()
        return [_row_to_failed_message(r) for r in rows]

    async def mark_delivered(
        self, msg_id: str, message_sid: str, retry_count: int
    ) -> None:
        async with self._session_factory() as session:
            await session.execute(
                text(
                    """
                    UPDATE failed_messages
                    SET status = 'delivered',
                        resolved_at = NOW(),
                        retry_count = :retry_count
                    WHERE id = :id
                    """
                ),
                {"id": msg_id, "retry_count": retry_count},
            )
            await session.commit()

    async def increment_retry(
        self,
        msg_id: str,
        retry_count: int,
        error: str,
        next_retry_at: datetime,
    ) -> None:
        async with self._session_factory() as session:
            await session.execute(
                text(
                    """
                    UPDATE failed_messages
                    SET retry_count = :retry_count,
                        last_error = :error,
                        next_retry_at = :next_at
                    WHERE id = :id
                    """
                ),
                {
                    "id": msg_id,
                    "retry_count": retry_count,
                    "error": error,
                    "next_at": next_retry_at,
                },
            )
            await session.commit()

    async def mark_dead(
        self, msg_id: str, retry_count: int, error: str
    ) -> None:
        async with self._session_factory() as session:
            await session.execute(
                text(
                    """
                    UPDATE failed_messages
                    SET status = 'dead',
                        retry_count = :retry_count,
                        last_error = :error,
                        resolved_at = NOW()
                    WHERE id = :id
                    """
                ),
                {"id": msg_id, "retry_count": retry_count, "error": error},
            )
            await session.commit()


def _row_to_failed_message(row: dict[str, Any]) -> FailedMessage:
    return FailedMessage(
        id=str(row["id"]),
        recipient=row["recipient"],
        body=row["body"],
        channel=row.get("channel") or "whatsapp",
        agent_name=row.get("agent_name") or "",
        agent_token=row.get("agent_token") or "",
        thread_id=row.get("thread_id"),
        entity_id=row.get("entity_id"),
        reply_msg_id=row.get("reply_msg_id"),
        retry_count=row.get("retry_count", 0),
        max_retries=row.get("max_retries", 5),
        last_error=row.get("last_error"),
        status=row.get("status", "pending"),
        created_at=row.get("created_at"),
        next_retry_at=row.get("next_retry_at"),
        resolved_at=row.get("resolved_at"),
    )
