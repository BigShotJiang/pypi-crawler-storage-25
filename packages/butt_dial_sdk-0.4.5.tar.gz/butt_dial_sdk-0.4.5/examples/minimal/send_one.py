"""Minimal example — send one message.

Run:
    export BUTT_DIAL_BASE_URL=https://your-server.example
    export BUTT_DIAL_AGENT_ID=<the UUID your host generated for this agent>
    export BUTT_DIAL_AGENT_TOKEN=<token BD minted at registration>
    python examples/minimal/send_one.py +14155550123
"""

from __future__ import annotations

import asyncio
import sys

from buttdial import Agent


async def main(recipient: str) -> int:
    bd = Agent.from_env()
    result = await bd.send_message(to=recipient, body="Hello from butt-dial-sdk 👋")
    if result.ok:
        print(f"sent: {result.message_sid}")
        return 0
    print(f"failed at stage {result.stage_failed}: {result.error}")
    if result.remediation:
        print(f"  fix: {result.remediation}")
    return 1


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: send_one.py <recipient E.164>")
        raise SystemExit(2)
    raise SystemExit(asyncio.run(main(sys.argv[1])))
