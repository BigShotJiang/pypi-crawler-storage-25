"""Full round-trip example — FastAPI app with outbound + inbound.

Run:
    export BUTT_DIAL_BASE_URL=https://your-server.example
    export BUTT_DIAL_AGENT_ID=<host-supplied UUID>
    export BUTT_DIAL_AGENT_TOKEN=<per-agent runtime token>
    export WA_VERIFY_TOKEN=pick-a-secret
    export WA_WEBHOOK_SECRET=from-meta-dashboard

    pip install 'butt-dial-sdk[router]' uvicorn
    uvicorn examples.with_inbound.app:app --reload --port 8000

Then configure your Butt-Dial server to POST inbound webhooks to
`http://localhost:8000/api/webhook/whatsapp`. Reply to a message from
your test phone; the `@handler.on_message` callback prints it.
"""

from __future__ import annotations

import os

from fastapi import FastAPI

from buttdial import Agent, DeliveryReceipt, InboundHandler, InboundMessage

app = FastAPI(title="butt-dial-sdk example — inbound round trip")

# Outbound agent
bd = Agent.from_env()

# Inbound handler with WhatsApp subscription + HMAC verification
handler = InboundHandler(
    whatsapp_verify_token=os.environ.get("WA_VERIFY_TOKEN", ""),
    whatsapp_webhook_secret=os.environ.get("WA_WEBHOOK_SECRET", ""),
)


@handler.on_message()
async def on_any_message(msg: InboundMessage) -> None:
    print(f"inbound {msg.channel}: {msg.sender} → {msg.text!r}")


@handler.on_message(channel="whatsapp")
async def on_whatsapp(msg: InboundMessage) -> None:
    # Echo back — demonstrates the full round trip.
    await bd.send_message(
        to=msg.sender,
        body=f"you said: {msg.text}",
        channel="whatsapp",
    )


@handler.on_delivery_receipt()
async def on_receipt(r: DeliveryReceipt) -> None:
    print(f"receipt: {r.message_sid} → {r.status}")


# Mount the inbound router — POST /api/webhook/{channel} + GET /{channel}/verify
app.include_router(handler.router, prefix="/api/webhook")


@app.get("/send")
async def send(to: str, body: str = "Hello from the example app") -> dict:
    """Outbound test: GET /send?to=+14155550123 sends a message."""
    result = await bd.send_message(to=to, body=body)
    return {
        "ok": result.ok,
        "message_sid": result.message_sid,
        "error": result.error,
        "remediation": result.remediation,
    }
