"""Reference host integration: auto-register + signed webhook receiver.

Run:
    uvicorn examples.with-onboarding-handshake.app:app --port 8000

Then POST /signup with {"name": "Acme", "email": "alice@acme.com"} to
fire a real register() call against https://call.95percent.ai. Or hit
GET /signup-and-fake-click for a self-contained smoke test that mocks a
verified webhook delivery.

Persistence is in-memory (dict) so this file stays self-contained. In a
real host: replace ``WORKSPACES`` with your DB / vault / row store and
the ``DELIVERED_IDS`` set with a Redis/DB-backed dedup table that
survives restart.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from buttdial import AccountsClient
from buttdial.webhooks import verify_webhook_signature

BD_BASE_URL = "https://call.95percent.ai"
PUBLIC_BASE_URL = "https://acme.example"  # the public URL your bknd is reachable at

# Production-shaped branding payload — replace with your own logo/colors/name.
BRANDING = {
    "logoUrl": "https://acme.example/logo-mark.svg",
    "primaryColor": "#00C9A7",
    "productName": "Acme",
    "supportEmail": "support@acme.example",
}


# ---------------------------------------------------------------------------
# In-memory persistence (replace in production)
# ---------------------------------------------------------------------------


@dataclass
class Workspace:
    workspace_id: str
    name: str
    admin_email: str
    bd_org_id: str | None = None
    bd_webhook_secret: str | None = None
    bd_poll_token: str | None = None
    bd_team_token: str | None = None
    provisioned: bool = False
    fields: dict[str, Any] = field(default_factory=dict)


WORKSPACES: dict[str, Workspace] = {}                 # workspace_id → Workspace
WORKSPACES_BY_BD_ORG_ID: dict[str, str] = {}          # bd_org_id → workspace_id
DELIVERED_IDS: set[str] = set()                       # X-BD-Delivery-Id dedup table


def _find_workspace_by_org_id(bd_org_id: str) -> Workspace | None:
    workspace_id = WORKSPACES_BY_BD_ORG_ID.get(bd_org_id)
    return WORKSPACES.get(workspace_id) if workspace_id else None


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(title="butt-dial-sdk onboarding-handshake example")


class SignupBody(BaseModel):
    name: str
    email: str


@app.post("/signup")
async def signup(body: SignupBody) -> dict[str, Any]:
    """Customer signed up via your /signup form. Auto-register their BD workspace.

    Returns the workspace record. The user has not clicked the verification
    link yet at this point — `provisioned=False`. Your frontend can poll
    `/api/workspace/{workspace_id}/onboarding-status` until the webhook flips
    it to True (or use the BD `pollToken` to poll BD's verification-status
    directly).
    """
    workspace_id = str(uuid.uuid4())
    ws = Workspace(workspace_id=workspace_id, name=body.name, admin_email=body.email)
    WORKSPACES[workspace_id] = ws

    accounts = AccountsClient(BD_BASE_URL)
    resp = await accounts.register(
        org_name=body.name,
        owner_email=body.email,
        branding=BRANDING,
        return_url=f"{PUBLIC_BASE_URL}/welcome?ws={workspace_id}",
        webhook_url=f"{PUBLIC_BASE_URL}/api/webhooks/butt-dial/account-verified",
        verification_email={
            "subject": f"Verify your {BRANDING['productName']} workspace",
            "html": (
                "<p>Hi! Click <a href=\"{{verifyUrl}}\">here</a> to activate "
                f"your {BRANDING['productName']} workspace "
                "({{orgName}}). Link expires in {{expiresInMinutes}} minutes.</p>"
            ),
        },
    )

    # Capture once — webhookSecret is NOT retrievable later. If you lose it
    # before persisting, re-registering the same email while the org is still
    # pending returns the same secret (idempotent recovery). After verify,
    # the secret is sealed.
    ws.bd_org_id = resp["orgId"]
    ws.bd_webhook_secret = resp.get("webhookSecret")  # may be absent on verified-email register
    ws.bd_poll_token = resp.get("pollToken")
    WORKSPACES_BY_BD_ORG_ID[resp["orgId"]] = workspace_id

    return {
        "workspace_id": workspace_id,
        "name": ws.name,
        "provisioned": ws.provisioned,
        "bd_org_id": ws.bd_org_id,
        "verification_sent": resp.get("verificationSent", False),
        # NEVER return the webhookSecret to the client. It stays server-side.
    }


@app.post("/api/webhooks/butt-dial/account-verified")
async def bd_webhook(
    request: Request,
    x_bd_signature: str | None = Header(None, alias="X-BD-Signature"),
    x_bd_timestamp: str | None = Header(None, alias="X-BD-Timestamp"),
    x_bd_delivery_id: str | None = Header(None, alias="X-BD-Delivery-Id"),
) -> dict[str, Any]:
    """Receive `account.verified` from BD after the user clicks the email link.

    Verification flow:
        1. Read raw body bytes (do NOT use request.json() — sig is over raw bytes).
        2. Look up the workspace by orgId from the parsed body to find the secret.
        3. Verify HMAC signature against the stored secret.
        4. Dedupe by X-BD-Delivery-Id.
        5. Persist team_token; flip provisioned=True; ack.

    Idempotency note: BD retries 1s/5s/25s/2m/10m on any 4xx/5xx or timeout.
    Same delivery_id arrives across retries.
    """
    raw = await request.body()

    try:
        body = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(400, "invalid json")

    bd_org_id = body.get("orgId")
    if not bd_org_id:
        raise HTTPException(400, "missing orgId")

    ws = _find_workspace_by_org_id(bd_org_id)
    if not ws or not ws.bd_webhook_secret:
        # 401 not 404 — don't reveal which orgIds exist on this host.
        raise HTTPException(401, "unknown workspace")

    if not verify_webhook_signature(
        raw,
        timestamp_header=x_bd_timestamp,
        signature_header=x_bd_signature,
        secret=ws.bd_webhook_secret,
    ):
        raise HTTPException(401, "invalid signature")

    if x_bd_delivery_id and x_bd_delivery_id in DELIVERED_IDS:
        return {"ok": True, "already_processed": True}

    ws.bd_team_token = body["teamToken"]
    ws.provisioned = True

    if x_bd_delivery_id:
        DELIVERED_IDS.add(x_bd_delivery_id)

    return {"ok": True, "workspace_id": ws.workspace_id}


@app.get("/api/workspace/{workspace_id}/onboarding-status")
async def onboarding_status(workspace_id: str) -> dict[str, Any]:
    """Frontend polls this every 60s while showing the 'check your email' banner."""
    ws = WORKSPACES.get(workspace_id)
    if not ws:
        raise HTTPException(404, "not found")
    return {
        "workspace_id": ws.workspace_id,
        "provisioned": ws.provisioned,
        "name": ws.name,
        "bd_org_id": ws.bd_org_id,
    }


# ---------------------------------------------------------------------------
# Smoke route — exercises the full flow without a real email click
# ---------------------------------------------------------------------------


@app.get("/signup-and-fake-click")
async def signup_and_fake_click() -> dict[str, Any]:
    """Self-contained smoke test: signup + simulate the webhook delivery.

    Useful for verifying your handler wiring locally before going live.
    """
    body = SignupBody(name="Smoke Test Inc", email=f"smoke-{uuid.uuid4()}@example.invalid")
    sign_resp = await signup(body)
    workspace_id = sign_resp["workspace_id"]
    ws = WORKSPACES[workspace_id]

    if not ws.bd_webhook_secret:
        return {"skipped": "no webhookSecret returned (verified-email path); rerun with a fresh email"}

    fake_body = {
        "event": "account.verified",
        "orgId": ws.bd_org_id,
        "ownerEmail": ws.admin_email,
        "teamToken": "fake_team_token_for_smoke_test",
        "scopes": "org-admin",
        "verifiedAt": "2026-04-29T00:00:00Z",
    }
    raw = json.dumps(fake_body, separators=(",", ":")).encode()
    ts = str(int(time.time()))
    signed_payload = f"{ts}.{raw.decode()}".encode()
    sig = hmac.new(ws.bd_webhook_secret.encode(), signed_payload, hashlib.sha256).hexdigest()

    from starlette.testclient import TestClient
    client = TestClient(app)
    resp = client.post(
        "/api/webhooks/butt-dial/account-verified",
        content=raw,
        headers={
            "Content-Type": "application/json",
            "X-BD-Signature": f"hmac-sha256={sig}",
            "X-BD-Timestamp": ts,
            "X-BD-Delivery-Id": str(uuid.uuid4()),
        },
    )

    return {
        "signup": sign_resp,
        "webhook_status": resp.status_code,
        "webhook_body": resp.json(),
        "workspace_after": {
            "workspace_id": ws.workspace_id,
            "provisioned": ws.provisioned,
            "team_token_present": bool(ws.bd_team_token),
        },
    }
