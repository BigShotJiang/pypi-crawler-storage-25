# with-onboarding-handshake — branded register + signed webhook

A complete FastAPI host that auto-registers a Butt-Dial workspace when a new
customer signs up, then receives the signed `account.verified` webhook and
flips the workspace to provisioned.

This is the **canonical pattern** for production host apps. If you're writing
host code that integrates with `butt-dial-sdk`, lift from here, not from
`examples/minimal/`.

## What it demonstrates

- Branded `register()` call with all four optional kwargs (`branding`,
  `return_url`, `webhook_url`, `verification_email`).
- Webhook receiver with **signature verification**, **delivery-id dedupe**,
  and **early ack**.
- `webhookSecret` captured at register time and persisted alongside the
  workspace (it's not retrievable later).
- `pollToken` captured for `verification-status` polling — the path your
  signup banner can use to ask "have they clicked yet?" before the
  `team_token` exists.

## Run it

```bash
pip install butt-dial-sdk fastapi uvicorn
uvicorn examples.with-onboarding-handshake.app:app --port 8000
```

Then either:

- POST to `http://localhost:8000/signup` with `{"name": "Acme", "email": "alice@acme.com"}` to fire a real `register()` against `https://call.95percent.ai`. Use a real inbox you control if you want to click through.
- Run the in-app smoke route `GET /signup-and-fake-click` (mocks a verified webhook delivery so you can see the wired-up handler fire end-to-end).

## What you'll see

1. `POST /signup` returns a workspace record with `provisioned=False` and `bd_org_id` populated.
2. BD emails the address with **your branding** (logo + accent color + "Acme" wording, not "butt-dial").
3. User clicks the verification link → BD's verify page redirects to your `return_url`.
4. Simultaneously, BD POSTs `account.verified` to your `webhook_url`. Your handler verifies the signature, dedupes, persists the `team_token`, flips `provisioned=True`.
5. Your signup banner / poll endpoint sees `provisioned=True` on the next read.
