from __future__ import annotations

from typing import Any, cast

from openai import OpenAI

from ...types import ComposeCacheError, ComposeCacheErrorCode
from .base import LLMAdapter, LLMCompletionRequest, LLMCompletionResponse, LLMMessage, LLMUsage


class OpenAIAdapter(LLMAdapter):
    def __init__(self, api_key: str) -> None:
        self._client = OpenAI(api_key=api_key)

    def complete(self, request: LLMCompletionRequest) -> LLMCompletionResponse:
        try:
            payload: dict[str, Any] = {
                "model": request.model,
                "messages": [self._to_openai_message(m) for m in request.messages],
                "temperature": request.temperature,
                "top_p": request.top_p,
                "max_tokens": request.max_tokens,
                "logprobs": True,
            }
            if request.response_format_json:
                payload["response_format"] = {"type": "json_object"}

            completion = cast(Any, self._client.chat.completions).create(**payload)
            choice = completion.choices[0]
            content = choice.message.content or ""

            usage = None
            if completion.usage:
                usage = LLMUsage(
                    prompt_tokens=completion.usage.prompt_tokens,
                    completion_tokens=completion.usage.completion_tokens,
                    total_tokens=completion.usage.total_tokens,
                )

            logprobs = None
            raw_logprobs = getattr(choice.logprobs, "content", None)
            if raw_logprobs:
                extracted: list[float] = []
                for item in raw_logprobs:
                    value = getattr(item, "logprob", None)
                    if isinstance(value, float):
                        extracted.append(value)
                logprobs = extracted or None

            return LLMCompletionResponse(content=content, usage=usage, logprobs=logprobs)
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.LLM_FAILED,
                "OpenAI completion failed",
                {"cause": str(exc)},
            ) from exc

    def _to_openai_message(self, message: LLMMessage) -> dict[str, str]:
        return {"role": message.role, "content": message.content}
