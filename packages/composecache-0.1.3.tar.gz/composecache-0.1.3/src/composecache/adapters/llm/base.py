from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(slots=True)
class LLMMessage:
    role: str
    content: str


@dataclass(slots=True)
class LLMCompletionRequest:
    model: str
    messages: list[LLMMessage]
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    response_format_json: bool = False


@dataclass(slots=True)
class LLMUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass(slots=True)
class LLMCompletionResponse:
    content: str
    usage: LLMUsage | None = None
    logprobs: list[float] | None = None


class LLMAdapter(Protocol):
    def complete(self, request: LLMCompletionRequest) -> LLMCompletionResponse:
        ...
