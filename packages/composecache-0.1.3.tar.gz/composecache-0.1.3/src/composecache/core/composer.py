from __future__ import annotations

from ..adapters.llm.base import LLMAdapter, LLMCompletionRequest, LLMMessage
from ..types import DecompositionType, SubQuery


class Composer:
    def __init__(self, llm: LLMAdapter, model: str) -> None:
        self._llm = llm
        self._model = model

    def compose(
        self,
        original_query: str,
        query_type: DecompositionType,
        sub_queries: list[SubQuery],
        answers: dict[int, str],
    ) -> str:
        if query_type is DecompositionType.ATOMIC:
            return next(iter(answers.values()), "")

        context_lines = []
        for sq in sub_queries:
            context_lines.append(f"Sub-query {sq.id}: {sq.text}\nAnswer {sq.id}: {answers.get(sq.id, '')}")

        response = self._llm.complete(
            LLMCompletionRequest(
                model=self._model,
                messages=[
                    LLMMessage(
                        role="system",
                        content="Compose a single final answer from sub-query answers. Keep factual consistency.",
                    ),
                    LLMMessage(
                        role="user",
                        content=f"Original query: {original_query}\nType: {query_type.value}\n\n" + "\n\n".join(context_lines),
                    ),
                ],
            )
        )
        return response.content
