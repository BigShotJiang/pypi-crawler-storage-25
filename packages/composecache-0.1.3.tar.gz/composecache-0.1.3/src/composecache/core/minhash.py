from __future__ import annotations

import hashlib
import struct

_SIGNATURE_SIZE = 64


class MinHash:
    @staticmethod
    def from_tokens(tokens: list[str], signature_size: int = _SIGNATURE_SIZE) -> bytes:
        unique_tokens = list(set(tokens))
        signature = [0xFFFFFFFF] * signature_size

        for seed in range(signature_size):
            for token in unique_tokens:
                value = MinHash._hash_token(token, seed)
                if value < signature[seed]:
                    signature[seed] = value

        return b"".join(struct.pack(">I", x) for x in signature)

    @staticmethod
    def from_document_ids(document_ids: list[str], signature_size: int = _SIGNATURE_SIZE) -> bytes:
        return MinHash.from_tokens(document_ids, signature_size)

    @staticmethod
    def jaccard_from_signatures(a: bytes, b: bytes) -> float:
        sig_a = MinHash._to_uint32_list(a)
        sig_b = MinHash._to_uint32_list(b)
        length = min(len(sig_a), len(sig_b))
        if length == 0:
            return 1.0

        equal = sum(1 for i in range(length) if sig_a[i] == sig_b[i])
        return equal / length

    @staticmethod
    def _to_uint32_list(payload: bytes) -> list[int]:
        if not payload:
            return []
        return [x[0] for x in struct.iter_unpack(">I", payload)]

    @staticmethod
    def _hash_token(token: str, seed: int) -> int:
        digest = hashlib.sha256(f"{seed}:{token}".encode("utf-8")).digest()
        return int.from_bytes(digest[:4], byteorder="big", signed=False)
