from __future__ import annotations

import hashlib
import json
from typing import Any


class Hasher:
    @staticmethod
    def hash(query: str, doc_fingerprint: bytes | None, params_hash: str) -> str:
        payload = f"{query}|{doc_fingerprint.hex() if doc_fingerprint else ''}|{params_hash}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def hash_params(params: dict[str, Any]) -> str:
        canonical = Hasher._sort_obj(params)
        payload = json.dumps(canonical, separators=(",", ":"), ensure_ascii=True)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _sort_obj(value: Any) -> Any:
        if isinstance(value, dict):
            return {k: Hasher._sort_obj(value[k]) for k in sorted(value.keys())}
        if isinstance(value, list):
            return [Hasher._sort_obj(v) for v in value]
        return value
