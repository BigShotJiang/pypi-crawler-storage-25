from __future__ import annotations

import hashlib
from typing import Any


class TransformerEmbedder:
    def __init__(self, dims: int = 384) -> None:
        self.dims = dims
        self._model: Any | None = None
        self._model_load_error: str | None = None

        # Try to use all-MiniLM-L6-v2 for paper-aligned embeddings.
        # If unavailable, keep a deterministic local fallback for portability.
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore[import-untyped]

            self._model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        except Exception as exc:
            self._model = None
            self._model_load_error = str(exc)

    def embed(self, text: str) -> list[float]:
        if self._model is not None:
            vector = self._model.encode(text, convert_to_numpy=True, normalize_embeddings=True)
            out = vector.tolist()
            return [float(v) for v in out]

        # Deterministic fallback embedding for environments without local transformer setup.
        output: list[float] = []
        for i in range(self.dims):
            digest = hashlib.sha256(f"{text}:{i}".encode("utf-8")).digest()
            value = int.from_bytes(digest[:4], byteorder="big", signed=False) / 0xFFFFFFFF
            output.append((value * 2) - 1)
        return output
