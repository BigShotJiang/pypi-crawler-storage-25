from __future__ import annotations

import math


class UncertaintyEstimator:
    def estimate(self, query: str, response: str, logprobs: list[float] | None = None) -> float:
        entropy_proxy = self._entropy_proxy(logprobs)
        drift_proxy = self._semantic_drift_proxy(query, response)
        return self._clamp((0.7 * entropy_proxy) + (0.3 * drift_proxy))

    def _entropy_proxy(self, logprobs: list[float] | None) -> float:
        if not logprobs:
            return 0.25

        # Approximate normalized token entropy using negative log-probability.
        # We normalize by ln(V) with V ~= 50k to map into [0,1].
        avg_nll = sum(-lp for lp in logprobs) / len(logprobs)
        normalized = avg_nll / math.log(50000)
        return self._clamp(normalized)

    def _semantic_drift_proxy(self, query: str, response: str) -> float:
        query_tokens = set(self._tokenize(query))
        response_tokens = set(self._tokenize(response))
        if not query_tokens or not response_tokens:
            return 1.0

        overlap = len(query_tokens & response_tokens)
        union = len(query_tokens | response_tokens)
        jaccard = overlap / union if union else 0.0
        return self._clamp(1 - jaccard)

    def _tokenize(self, text: str) -> list[str]:
        return [t for t in "".join(c.lower() if c.isalnum() else " " for c in text).split() if len(t) > 1]

    def _clamp(self, value: float) -> float:
        return max(0.0, min(1.0, value))
