from __future__ import annotations

import json

from ..adapters.llm.base import LLMAdapter, LLMCompletionRequest, LLMMessage
from ..core.hasher import Hasher
from ..types import DecompositionResult, DecompositionType, SubQuery


class Decomposer:
    def __init__(self, llm: LLMAdapter, enabled: bool = True, model: str = "gpt-4o-mini") -> None:
        self._llm = llm
        self._enabled = enabled
        self._model = model
        self._cache: dict[str, DecompositionResult] = {}

    def classify(self, query: str) -> DecompositionResult:
        if not self._enabled:
            return DecompositionResult(type=DecompositionType.ATOMIC, sub_queries=[])

        cache_key = Hasher.hash(query, None, "decomposition")
        if cache_key in self._cache:
            return self._cache[cache_key]

        response = self._llm.complete(
            LLMCompletionRequest(
                model=self._model,
                response_format_json=True,
                messages=[
                    LLMMessage(role="system", content=self._prompt_template()),
                    LLMMessage(role="user", content=query),
                ],
            )
        )

        parsed = self._parse(response.content)
        self._cache[cache_key] = parsed
        return parsed

    def _parse(self, content: str) -> DecompositionResult:
        raw_json = self._extract_json(content)
        payload = json.loads(raw_json)

        raw_type = str(payload.get("type", "atomic")).lower()
        if raw_type not in {"atomic", "comparison", "bridge"}:
            raw_type = "atomic"

        decomp_type = DecompositionType(raw_type)
        if decomp_type is DecompositionType.ATOMIC:
            return DecompositionResult(type=decomp_type, sub_queries=[])

        sub_queries: list[SubQuery] = []
        for sq in payload.get("sub_queries", []):
            sq_id = sq.get("id")
            text = sq.get("text")
            if not isinstance(sq_id, int) or not isinstance(text, str):
                continue
            depends_on = sq.get("depends_on", [])
            deps = [dep for dep in depends_on if isinstance(dep, int)] if isinstance(depends_on, list) else []
            sub_queries.append(SubQuery(id=sq_id, text=text, depends_on=deps))

        return DecompositionResult(type=decomp_type, sub_queries=sub_queries)

    def _extract_json(self, text: str) -> str:
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return '{"type":"atomic","sub_queries":[]}'
        return text[start : end + 1]

    def _prompt_template(self) -> str:
        return "\n".join(
            [
                "You classify questions as atomic or compositional and decompose them.",
                "Classification:",
                "- atomic: single-fact question.",
                "- comparison: compares entities independently.",
                "- bridge: multi-hop chain with dependencies.",
                "Return strict JSON with schema:",
                '{"type":"atomic|comparison|bridge","sub_queries":[{"id":0,"text":"...","depends_on":[]}]}',
                "Examples:",
                'Q: What is the capital of France? -> {"type":"atomic","sub_queries":[]}',
                'Q: Compare GDP of France and Germany -> {"type":"comparison","sub_queries":[{"id":0,"text":"What is GDP of France?","depends_on":[]},{"id":1,"text":"What is GDP of Germany?","depends_on":[]}]}',
                'Q: Who directed the movie that won Best Picture 2020? -> {"type":"bridge","sub_queries":[{"id":0,"text":"Which movie won Best Picture 2020?","depends_on":[]},{"id":1,"text":"Who directed {0}?","depends_on":[0]}]}',
            ]
        )
