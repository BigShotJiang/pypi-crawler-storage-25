from __future__ import annotations

import re
import unicodedata

_ZERO_WIDTH_PATTERN = re.compile("\u200B|\u200C|\u200D|\uFEFF")
_WHITESPACE_PATTERN = re.compile(r"\s+")


class Normalizer:
    @staticmethod
    def normalize(text: str) -> str:
        without_zero_width = _ZERO_WIDTH_PATTERN.sub("", text)
        nfc = unicodedata.normalize("NFC", without_zero_width)
        collapsed = _WHITESPACE_PATTERN.sub(" ", nfc)
        return collapsed.strip().lower()
