CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS llm_cache (
    id BIGSERIAL PRIMARY KEY,
    cache_key CHAR(64) NOT NULL UNIQUE,
    query_text TEXT NOT NULL,
    query_normalized TEXT NOT NULL,
    response TEXT NOT NULL,
    model VARCHAR(100) NOT NULL,
    params_hash CHAR(64) NOT NULL,
    query_embedding VECTOR(384),
    doc_fingerprint BYTEA,
    uncertainty REAL DEFAULT 0.0,
    is_sub_query BOOLEAN DEFAULT FALSE,
    parent_query_id BIGINT REFERENCES llm_cache(id) ON DELETE CASCADE,
    hit_count INTEGER DEFAULT 0,
    tokens_saved INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_hit_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

CREATE INDEX idx_cache_key ON llm_cache(cache_key);
CREATE INDEX idx_model_params ON llm_cache(model, params_hash);
CREATE INDEX idx_expires ON llm_cache(expires_at) WHERE expires_at IS NOT NULL;
CREATE INDEX idx_sub_queries ON llm_cache(is_sub_query, parent_query_id);
CREATE INDEX idx_embedding ON llm_cache USING hnsw (query_embedding vector_cosine_ops);

CREATE TABLE IF NOT EXISTS llm_cache_negative (
    id BIGSERIAL PRIMARY KEY,
    cache_key CHAR(64) NOT NULL UNIQUE,
    query_embedding VECTOR(384),
    refusal_reason TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

CREATE INDEX idx_neg_embedding ON llm_cache_negative USING hnsw (query_embedding vector_cosine_ops);
