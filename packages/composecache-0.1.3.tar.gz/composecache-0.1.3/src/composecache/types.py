from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class CacheType(str, Enum):
    EXACT = "exact"
    SEMANTIC = "semantic"
    PARTIAL = "partial"
    MISS = "miss"


class DecompositionType(str, Enum):
    ATOMIC = "atomic"
    COMPARISON = "comparison"
    BRIDGE = "bridge"


class ComposeCacheErrorCode(str, Enum):
    DB_CONNECTION_FAILED = "DB_CONNECTION_FAILED"
    DB_FAILED = "DB_FAILED"
    MIGRATION_FAILED = "MIGRATION_FAILED"
    INVALID_QUERY = "INVALID_QUERY"
    INVALID_CONFIG = "INVALID_CONFIG"
    LLM_FAILED = "LLM_FAILED"
    DECOMPOSITION_FAILED = "DECOMPOSITION_FAILED"
    UNKNOWN_ERROR = "UNKNOWN_ERROR"


class ComposeCacheError(Exception):
    def __init__(self, code: ComposeCacheErrorCode, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.details = details or {}


@dataclass(slots=True)
class Thresholds:
    query: float = 0.9
    document: float = 0.7
    uncertainty: float = 0.3


@dataclass(slots=True)
class DecompositionConfig:
    enabled: bool = True
    model: str = "gpt-4o-mini"


@dataclass(slots=True)
class ComposeCacheConfig:
    database_url: str
    openai_api_key: str
    thresholds: Thresholds = field(default_factory=Thresholds)
    decomposition: DecompositionConfig = field(default_factory=DecompositionConfig)
    ttl: str | None = "7d"
    table_name: str = "llm_cache"


@dataclass(slots=True)
class Message:
    role: str
    content: str


@dataclass(slots=True)
class DocumentLike:
    id: str
    content: str | None = None
    metadata: dict[str, str | int | float | bool | None] | None = None


@dataclass(slots=True)
class CompletionRequest:
    model: str
    messages: list[Message]
    documents: list[DocumentLike] | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None


@dataclass(slots=True)
class SubQueryHit:
    id: int
    query: str
    hit: bool
    from_cache: str


@dataclass(slots=True)
class CompletionResponse:
    content: str
    cache_type: CacheType
    sub_query_hits: list[SubQueryHit]
    tokens_saved: int
    latency_ms: int
    cost_saved: float


@dataclass(slots=True)
class CacheEntry:
    cache_key: str
    query_text: str
    query_normalized: str
    response: str
    model: str
    params_hash: str
    query_embedding: list[float] | None = None
    doc_fingerprint: bytes | None = None
    uncertainty: float = 0.0
    is_sub_query: bool = False
    parent_query_id: int | None = None
    hit_count: int = 0
    tokens_saved: int = 0
    created_at: datetime | None = None
    last_hit_at: datetime | None = None
    expires_at: datetime | None = None


@dataclass(slots=True)
class NegativeCacheEntry:
    cache_key: str
    query_embedding: list[float] | None = None
    refusal_reason: str | None = None
    created_at: datetime | None = None
    expires_at: datetime | None = None


@dataclass(slots=True)
class SubQuery:
    id: int
    text: str
    depends_on: list[int] = field(default_factory=list)


@dataclass(slots=True)
class DecompositionResult:
    type: DecompositionType
    sub_queries: list[SubQuery]
