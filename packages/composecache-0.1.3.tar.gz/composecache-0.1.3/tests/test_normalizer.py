from composecache.core.normalizer import Normalizer


def test_unicode_normalization() -> None:
    assert Normalizer.normalize("cafe\u0301") == Normalizer.normalize("café")


def test_whitespace_and_case_and_zero_width() -> None:
    assert Normalizer.normalize("  Hello\u200B   WORLD  ") == "hello world"
