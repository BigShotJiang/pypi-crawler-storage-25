from composecache.core.hasher import Hasher


def test_hash_is_deterministic() -> None:
    h1 = Hasher.hash("test", None, "params")
    h2 = Hasher.hash("test", None, "params")
    assert h1 == h2
    assert len(h1) == 64


def test_hash_changes_for_doc_fingerprint() -> None:
    h1 = Hasher.hash("test", None, "params")
    h2 = Hasher.hash("test", b"fingerprint", "params")
    assert h1 != h2


def test_hash_params_sorted() -> None:
    p1 = Hasher.hash_params({"model": "gpt", "temp": 0.2, "top_p": 0.9})
    p2 = Hasher.hash_params({"top_p": 0.9, "temp": 0.2, "model": "gpt"})
    assert p1 == p2
