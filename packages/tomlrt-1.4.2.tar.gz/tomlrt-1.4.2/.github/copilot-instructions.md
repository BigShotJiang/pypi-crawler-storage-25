# Instructions for AI coding agents

This file is read by GitHub Copilot, Copilot CLI, and similar agents
when they work in this repository. Humans are welcome to read it too —
it doubles as a high-signal contributor guide.

## What this project is

`tomlrt` is a **pure-Python, format-preserving** TOML parser and
writer. The non-negotiable invariant is:

> Parsing a document and dumping it again, with no mutations in
> between, must return the **exact same bytes** — including comments,
> whitespace, string style (literal vs basic, single vs multiline),
> number formatting, and line endings (LF vs CRLF).

If a change you are about to make could break that, stop and rethink.

## Toolchain

- **`uv`** is the only supported package/dependency manager. Do not
  introduce `pip`, `poetry`, `pipenv`, `tox`, `nox`, `setuptools`, or
  `requirements.txt`.
- Build backend is **`hatchling`**.
- Supported Python versions: **3.10 – 3.14**.

## Common commands

```bash
uv sync                          # install dev deps
uv run pytest -q                 # run the test suite (~10s)
uv run pytest --cov              # tests + branch coverage
uv run pytest -m slow            # property + bytes-level fuzz suite
uv run mypy                      # strict type-check src/ and tests/
uv run ruff check .              # lint
uv run ruff format .             # apply formatting
uv run ruff format --check .     # CI-style format check
```

A `Makefile` wraps the most common invocations (`make test`, `make
fuzz`, `make coverage`, `make lint`, `make docs`, `make docs-serve`,
`make bench`, `make clean`); use it if you prefer.

All four checks (`pytest`, `mypy`, `ruff check`, `ruff format --check`)
must pass before any commit. CI runs the same set on Python 3.10–3.14.

## Coding standards

- **`mypy --strict`** clean — no `# type: ignore` without a specific
  error code, and ideally no ignores at all. Prefer fixing the type.
- **`ruff` with `select = ["ALL"]`** clean — see `[tool.ruff.lint.ignore]`
  in `pyproject.toml` for the curated exceptions. Do not add new
  per-line `# noqa` without a strong reason.
- **`ruff format`** is the source of truth for formatting. Run it
  before committing.
- **No runtime dependencies beyond conditional stdlib backports.**
  The only declared runtime dep is `typing_extensions` on
  Python < 3.12 (for `Self` / `override`), behind a `python_version`
  marker. Don't add others. `dependency-groups.dev` and
  `dependency-groups.docs` may grow, but only with care.
- **No `cast()` in user-facing code paths.** Tests should not need
  `cast()` either; the typed accessors `Table.array(k)`,
  `Table.table(k)`, `Table.aot(k)`, `Array.array(i)`, `Array.table(i)`
  exist precisely to avoid this.
- **`from __future__ import annotations`** at the top of every module
  (enforced by ruff's isort `required-imports`).
- Do not add comments that merely restate the code. Comment intent and
  invariants, not mechanics.

## Architecture (in `src/tomlrt/`)

The codebase is layered: **physical slot stream** at the bottom,
**logical dict/list views** on top, **mutation primitives** between
them. Read roughly in this order:

### Foundation

- **`_errors.py`** — public exception hierarchy.
- **`_paths.py`** — key-path argument parsing and validation
  (the `t["a", "b"]` / `t[("a", "b")]` shapes used by the public
  API).
- **`_trivia.py`** — `Trivia` / `TriviaPiece` types and pure helpers
  over them (whitespace, newlines, comments). Depends only on
  `_errors`.
- **`_scanner.py`** — the `(src, end, pos)` cursor and the `scan_*`
  primitives the parser drives. String scanning is *semantic*:
  escapes are decoded, surrogate code points rejected, and the
  resulting node carries both the raw lexeme and the decoded value.
  Performance-sensitive: prefer bulk `str` scans over per-character
  loops.
- **`_values.py`** — the inline-value layer. Every TOML value
  (scalar, `ArrayValue`, `InlineTableValue`) carries enough source
  text to re-emit byte-exactly. Pure data; no slot-stream awareness.
  `ArrayValue` and `InlineTableValue` carry a pair of bracket-pad
  anchors — `header_trivia` (gap immediately after `[` / `{`) and
  `final_trivia` (gap before the closing bracket) — so that the
  above-item region of item 0 and the post-comma trivia of item -1
  have a single canonical owner; per-item `leading` only owns the
  region above items 1..n-1.
- **`_scalar.py`** — Python-to-TOML scalar predicates / coercion
  helpers (`is_scalar`, etc.). Depends on `_values` only.
- **`_slots.py`** — the **physical slot stream**:
  - `Slot` — base; carries `leading: Trivia`, `_prev` / `_next`
    intrusive linked-list pointers, `owner_aot_entry`, and a
    `_refs` back-pointer list (every `SlotRef` that targets the
    slot — bounded by path depth, used for O(depth) ref scrub on
    AoT removal).
  - `KVSlot` — one `key = value` line (`host_path`, `key_parts`,
    `key_seps`, `value`, `eol`).
  - `StructuralHeaderSlot` — one `[a.b]` / `[[a.b]]` header (`path`,
    `kind`, `entry`, `synthetic`).
  - `AoTEntry` — bookkeeping for an `[[a]]` entry (its
    `entry_slots`, the table view it backs).
  - `SlotRef` — a per-container *occurrence* of a slot.
    `local_key` is a derived `@property` of `(slot, container)`
    geometry — never store it. Registers itself on the target
    slot's `_refs` list at construction; `unfile_ref` unregisters.

### Parser

- **`_parser.py`** — hand-written recursive-descent parser,
  TOML 1.0 + 1.1, that drives `_Scanner` to produce a flat slot
  stream and feeds each header / `key = value` / inline-table key
  into `_Validator`.
- **`_validator.py`** — semantic validator for the cross-section /
  cross-line rules that the per-line slot stream cannot express on
  its own (a key bound as a value cannot later be opened as a
  table, `[H]` cannot redefine an already-opened table, dotted
  keys cannot extend an explicitly defined table / AoT, inline-
  table local key rules). Owned and invoked by `_parser.py`.

### Logical view construction & mutation

- **`_build.py`** — single linear pass over the parser's slot
  stream that constructs the `Document` body and all nested
  `Table` / `Array` / `AoT` views, populating dict storage in
  doc-stream-first-occurrence order. The *one* place that derives
  implicit containers from slot paths.
- **`_layout_ops.py`** — section-side mutation primitives: insert
  / delete on the doc-stream linked list; `_index` and `_refs`
  bookkeeping; KV / section / AoT-entry append; subtree rehome.
  By far the largest file. Internal hot-path conventions:
  - **Reverse-walks of `c._refs`** go through `_last_kv(c, predicate)`.
    The wrappers (`_last_direct_kv`, `_last_host_kv`,
    `_recompute_body_tail`) are *semantic* — they exist so the
    predicate is named once. Don't add a fourth ad-hoc walk.
  - **Bulk ref removal** goes through `_remove_owned_refs(c,
    candidate_keys, owned_ids)`. Callers own only the body-tail
    policy (clear vs recompute).
  - **`Container._body_tail`** is the cached doc-stream-tail of
    the container's region; treat it as ground truth for
    "what's the latest body slot of `c`?". `_last_direct_kv`
    uses it as an O(1) fast path before falling back to a
    reverse-walk.
- **`_inline_ops.py`** — inline-table mutation primitives. Inline
  tables are decoupled from the doc-stream linked list: a top-
  level inline table is one `KVSlot` whose `value` is an
  `InlineTableValue`, and mutation operates on
  `InlineTableValue.entries` directly. Owns the trivia fixups
  required to keep the result a valid, nicely-spaced inline table —
  including re-anchoring the bracket-pad (`header_trivia` /
  `final_trivia`) when the boundary entry changes. The same
  re-anchoring logic exists for inline arrays in `_array.py` /
  `_array_comments.py`; the helpers `split_above_block` /
  `join_above_block` in `_trivia.py` are the shared primitives.
- **`_render.py`** — pure linear walk of the doc-stream slot list
  + trailing trivia → source string. Byte-exact for any
  unmodified parse.

### Logical views

- **`_container.py`** — `Container` (the abstract base, a `dict`
  subclass), `Document`, and `Table`. Holds `_refs`, `_index`,
  `_path`, `_parent`, `_layout_root`, `_owner_aot_entry`,
  `_body_tail`, `_value`, `_header_ref`, `_inline`. Exposes
  `_wire(layout_root=, parent=, path=, owner=)` — every container
  construction site goes through it for the four common attachment
  fields; flavour-specific bits (`_inline`, `_value`, `_header_ref`,
  `_body_tail`) stay explicit at the call site so the table's kind
  is visible. `_doc_newline` is the canonical "newline of the
  owning document, or `\n` if detached" accessor — prefer it over
  reaching into `_layout_root._newline`. Public `Mapping` /
  `MutableMapping` API; mutation is delegated to `_layout_ops` /
  `_inline_ops`.
- **`_array.py`** — `Array(list)` (inline arrays) and
  `AoT(list[Table])` (array-of-tables) views, plus the `AoTEntry`
  glue that connects an entry's slots to its Table view.
- **`_comments.py`** — the `MutableMapping`-shaped EOL / leading-
  comment side-channel views over `Container` slot trivia
  (`Container.comments`, `Container.leading_comments`).
- **`_array_comments.py`** — the `MutableSequence`-shaped
  equivalents for `Array` items (`Array.comments`,
  `Array.leading_comments`). Shares encode/decode rules with
  `_comments`.

### Public API

- **`_public.py`** — top-level `loads` / `load` / `dumps` / `dump`.
  `load` / `dump` require **binary** file objects (`IO[bytes]`);
  text mode would silently translate newlines on Windows and
  break round-tripping.
- **`__init__.py`** — re-exports the public API; keep `__all__`
  alphabetised.

When in doubt: a change that touches only one of these layers is
usually right; a change that has to touch all of them is usually
wrong.

### Invariants worth knowing

- **Slot-stream linked list** is the single source of physical
  ordering. Mutation primitives splice exactly one slot at a time
  and update `_prev` / `_next`. Never rebuild the list.
- **`SlotRef.local_key` is derived** from `(slot, container)` —
  never assigned, never stored. The property asserts the
  geometric invariant on every read; an out-of-place ref fails
  fast at the property boundary rather than corrupting an
  `_index` bucket.
- **`Container._index[k]`** is the in-order list of refs in
  `_refs` whose `local_key == k`. Use `_rebuild_index_for_key`
  after any mid-stream insertion under `k`.
- **`Container._body_tail`** ≡ "the most recent slot in `_refs`
  belonging to the body region" (KV with matching owner; or, for
  a header-bearing container with no body, the header itself).
  Maintained eagerly on every body-region append, recomputed by
  `_recompute_body_tail` on body-affecting deletes.
- **`Slot.owner_aot_entry`** lives on the base `Slot`, not on the
  subclasses. Use direct attribute access — never `getattr(slot,
  "owner_aot_entry", None)`.
- **`Slot._refs`** is the back-pointer list from a slot to every
  `SlotRef` that targets it. Bounded by path depth + 1. Maintained
  by `SlotRef.__init__` (registers) and `unfile_ref`
  (unregisters). AoT removal uses it to scrub refs in O(depth) per
  slot instead of O(siblings) per container — don't bypass it
  with ad-hoc walks of ancestor `_index` buckets.
- **Container shape** is named explicitly by the `_Kind` enum in
  `_kind.py` and surfaced as `Container._kind`. The six kinds —
  `DOCUMENT`, `SECTION`, `IMPLICIT_SECTION`, `INLINE_ROOT`,
  `INLINE_FACTORY`, `INLINE_DOTTED_INNER` — pick out the
  combinations of `_inline` / `_value` / `_layout_root` /
  `_header_ref` that previously had to be re-derived at every
  call site. In particular, `INLINE_FACTORY` (a detached
  `Table.inline()` not yet assigned anywhere) and
  `INLINE_DOTTED_INNER` (the navigator view for the `a` in
  `{a.b = 1}`) share `_inline=True, _value=None` and differ only in
  `_layout_root`; dispatch on `_kind` rather than re-discovering
  the discriminator.

## Tests

- `tests/test_basic.py`, `test_spacing.py`, `test_edit_golden.py` —
  parser and writer regressions, including byte-exact round-trip
  fixtures.
- `tests/test_comments.py` — the comment manipulation API.
- `tests/test_compliance.py` — the official **`toml-test`** suite
  (vendored under `vendor/`). Do not edit fixtures there to make
  failures pass.
- `tests/test_dict_semantics.py` — pins the user-visible behaviours
  that come from `Table` actually being a `dict` subclass
  (`isinstance`, ``**t`` unpacking, identity stability of lookups).
- `tests/test_toml11.py` — TOML 1.1-specific coverage.
- `tests/test_hypothesis.py` — property-based round-trip tests. If you
  break round-tripping, this will usually catch it; add new strategies
  here when you add a new construct.
- `tests/test_fuzz.py` — bytes-level grammar fuzzer that feeds the
  parser arbitrary / near-valid input and asserts it either raises
  `TOMLParseError` or accepts and round-trips byte-exactly. Marked
  `slow`, so it is only picked up by `pytest -m slow` (`make fuzz`).
- `tests/test_mutation.py` — the dict/list mutation API.
- `tests/test_live_attach.py` — live-attach semantics for
  `Table.inline`, `Array`, and `AoT` when assigned into a document.
- `tests/test_synthesise_and_io.py` — value synthesis and binary I/O.
- `tests/test_scanner.py` — pins the cursor + diagnostics contract
  on `_Scanner` that the higher-level `scan_*` helpers build on.
- `tests/_toml_str.py` — internal `td(""" … """)` helper for writing
  TOML fixtures as indented triple-quoted literals; prefer it over
  walls of `\n`-escaped strings in new tests.

When adding behaviour, add a focused unit test in the relevant file
**and** consider whether the property tests should grow.

## Documentation

User-facing prose docs live under `docs/` and are published at
<https://dimbleby.github.io/tomlrt/>. The site is built with
[Zensical](https://zensical.org/) (a static site generator from the
creators of Material for MkDocs) plus the `mkdocstrings` Python
handler. Site config lives in `zensical.toml` (the nav lives there
too — update it when you add or rename a page). The dependency group
is `docs`:

```bash
uv run --group docs zensical serve     # preview locally
uv run --group docs zensical build     # what CI runs
```

The API reference page (`docs/api.md`) is generated from docstrings
via `mkdocstrings`, so docstring changes flow through automatically.
The task-oriented pages (`quickstart.md`, `building.md`, `reading.md`,
`editing.md`, `comments.md`, `errors.md`) are hand-written — update
them when you add, rename, or change behaviour of any public API.

## Things to avoid

- Adding an unconditional runtime dependency.
- Reaching into `_slots` / the doc-stream linked list from
  user-facing code instead of going through `_layout_ops` /
  `_inline_ops`.
- Storing data on a `SlotRef` other than `slot` and `container` —
  `local_key` is derived; if you need another piece of state,
  derive it too or push it onto the slot itself.
- Adding a fourth ad-hoc reverse-walk of `c._refs` instead of
  expressing the predicate to `_last_kv`.
- "Fixing" formatting differences in the writer's output without
  adding a round-trip test that proves it.
- Touching `vendor/` (it is third-party, vendored verbatim).
- Editing `uv.lock` by hand — let `uv` regenerate it.
- Bumping action versions in `.github/workflows/*.yml` to a tag instead
  of a 40-char commit SHA. The workflows are **`zizmor` clean** and
  must stay that way (`uv tool run zizmor .`).

## Commit conventions

- Subject line: imperative mood, ≤ ~70 chars, no trailing period.
- Body: wrap around 72 chars; explain *why* not *what*. Bullets are
  fine.
- One logical change per commit. Keep mechanical reformat passes
  separate from substantive changes.
- Append a `Co-authored-by` trailer when an AI agent did the work, e.g.
  `Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>`.
