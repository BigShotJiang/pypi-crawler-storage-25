"""Inline-table mutation primitives.

Inline tables are decoupled from the doc-stream linked list: a top-
level inline table is wrapped by a single `KVSlot` whose `value` is
an `InlineTableValue`. Mutation of the inline-table contents is a
local operation on the `InlineTableValue.entries` list, plus a
matching `dict.__setitem__` / `__delitem__` on the logical view.
This module owns the trivia fixups required to keep the result a
valid, nicely-spaced inline table:

* `append_entry` — splice a new entry at the end, transferring
  the prior closing space to the new entry's trailing and giving
  the previous entry a comma + a single space after it.
* `replace_entry_value` — overwrite the `value` field of the entry
  matching the given logical key (no spacing changes).
* `delete_entry` — remove the entry, then if the deleted entry was
  last, fold the prior entry's post-comma trivia into its trailing
  and clear its comma so we don't render a trailing comma (illegal
  in TOML 1.0; allowed in 1.1 but not what we want by default for a
  delete).

All entry lookups walk up the inline-table chain (via `_parent`) to
the outermost inline-table that owns the backing
`InlineTableValue` — entries for dotted keys like ``{a.b = 1}`` are
filed there, with multi-component `key_parts`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from tomlrt._kind import _Kind
from tomlrt._trivia import (
    Trivia,
    WhitespaceNode,
    clone_trivia,
    split_above_block,
    trivia_has_comment,
)
from tomlrt._values import InlineTableEntry, make_keyparts

if TYPE_CHECKING:
    from tomlrt._container import Container
    from tomlrt._values import InlineTableValue, Value


def _outermost_inline(t: Container) -> Container:
    """Walk up `_parent` until reaching the inline table that owns `_value`."""
    cur = t
    while cur._kind is _Kind.INLINE_DOTTED_INNER:  # noqa: SLF001
        parent = cur._parent  # noqa: SLF001
        if parent is None:
            msg = "internal: inline-dotted-inner without _parent"
            raise AssertionError(msg)
        cur = parent
    if cur._kind is not _Kind.INLINE_ROOT:  # noqa: SLF001
        msg = (
            f"internal: inline-table chain reached {cur._kind.name}; "  # noqa: SLF001
            "expected INLINE_ROOT"
        )
        raise AssertionError(msg)
    return cur


def _entry_key_path(t: Container, leaf: str) -> tuple[str, ...]:
    """Full dotted path used as `key_parts` in the outermost inline value."""
    root = _outermost_inline(t)
    suffix = t._path[len(root._path) :]  # noqa: SLF001
    return (*suffix, leaf)


def _find_entry(
    iv: InlineTableValue, key_path: tuple[str, ...]
) -> tuple[int, InlineTableEntry] | None:
    for i, e in enumerate(iv.entries):
        if tuple(p.value for p in e.key_parts) == key_path:
            return i, e
    return None


def _find_prefix_entries(iv: InlineTableValue, key_path: tuple[str, ...]) -> list[int]:
    """Indices of entries whose `key_parts` start with `key_path`.

    Used when deleting a synthetic dotted-prefix container — e.g.
    ``del obj["a"]`` for ``{a.b = 1, a.c = 2}`` removes both entries.
    """
    n = len(key_path)
    out: list[int] = []
    for i, e in enumerate(iv.entries):
        kp = tuple(p.value for p in e.key_parts)
        if len(kp) > n and kp[:n] == key_path:
            out.append(i)
    return out


def _ws(text: str) -> Trivia:
    return Trivia(pieces=[WhitespaceNode(text=text)])


# ---------------------------------------------------------------------------
# Public ops
# ---------------------------------------------------------------------------


def replace_entry_value(t: Container, key: str, new_value: Value) -> bool:
    """Replace the value of an existing entry in place.

    Returns True iff an entry was found and replaced. No trivia is
    altered.
    """
    root = _outermost_inline(t)
    iv = root._value  # noqa: SLF001
    assert iv is not None
    found = _find_entry(iv, _entry_key_path(t, key))
    if found is None:
        return False
    _, entry = found
    entry.value = new_value
    return True


def append_entry(t: Container, key: str, new_value: Value) -> None:
    """Append a fresh entry for `key` to the outermost inline table."""
    root = _outermost_inline(t)
    iv = root._value  # noqa: SLF001
    assert iv is not None
    key_path = _entry_key_path(t, key)

    # Sample `=` padding from any existing entry; default to ` = `.
    if iv.entries:
        sample = iv.entries[0]
        eq_pre = sample.pre_eq
        eq_post = sample.post_eq
    else:
        eq_pre = " "
        eq_post = " "
    new_entry = InlineTableEntry(
        leading=Trivia(),
        key_parts=make_keyparts(key_path),
        key_seps=["."] * (len(key_path) - 1),
        pre_eq=eq_pre,
        post_eq=eq_post,
        value=new_value,
        trailing=Trivia(),
        has_comma=False,
        post_comma_trivia=Trivia(),
    )

    if not iv.entries:
        # Empty {} → mirror the original inner padding (parser puts
        # the inner pad in `final_trivia`: "" for `{}`, " " for `{ }`).
        # Under the canonical model the pad before entries[0] lives on
        # `header_trivia`; promote final_trivia → header_trivia so the
        # new tail can keep the original bracket pad in `final_trivia`.
        bracket_pad = clone_trivia(iv.final_trivia) if iv.final_trivia.pieces else None
        if bracket_pad is not None:
            iv.header_trivia = bracket_pad
            # final_trivia stays as-is (the same bracket pad before `}`).
        iv.entries.append(new_entry)
        return

    # Inter-entry separator: structural pad portion of entries[1].leading
    # (mirrors :func:`_array._detect_style`). Cloning the full leading
    # would replicate any above-entry comment block onto the new entry.
    if len(iv.entries) >= 2:
        pad, _above = split_above_block(iv.entries[1].leading)
        inter_sep = pad if pad.pieces else clone_trivia(iv.entries[1].leading)
    else:
        inter_sep = _ws(" ")

    last = iv.entries[-1]
    keep_trailing_comma = last.has_comma
    if not last.has_comma:
        if trivia_has_comment(last.trailing):
            # Trailing carries a comment / newline — leave it where the
            # user put it; default the inter_sep to a single space.
            inter_sep = _ws(" ")
        else:
            # Promote `last`: take its (whitespace-only) trailing as the
            # bracket pad before the new entry's row.
            last.trailing = Trivia()
        last.has_comma = True
        last.post_comma_trivia = Trivia()
    new_entry.leading = inter_sep
    if keep_trailing_comma:
        new_entry.has_comma = True
        new_entry.post_comma_trivia = Trivia()
    iv.entries.append(new_entry)


def delete_entry(t: Container, key: str) -> bool:
    """Remove the entry (or all dotted-prefix entries) matching `key`.

    Returns True iff at least one entry was removed. When ``key`` names
    a synthetic dotted-prefix container (e.g. ``a`` in
    ``{a.b = 1, a.c = 2}``), every entry whose ``key_parts`` start with
    that prefix is removed.
    """
    root = _outermost_inline(t)
    iv = root._value  # noqa: SLF001
    assert iv is not None
    full_path = _entry_key_path(t, key)

    # Single exact match (the common, leaf-key case).
    found = _find_entry(iv, full_path)
    if found is not None:
        idx, removed = found
        iv.entries.pop(idx)
        _fix_tail_after_delete(iv, idx, removed)
        _fix_head_after_delete(iv, idx)
        return True

    # Prefix delete: dotted-prefix container.
    indices = _find_prefix_entries(iv, full_path)
    if not indices:
        return False
    original_len = len(iv.entries)
    last_removed_idx = indices[-1]
    last_removed_entry = iv.entries[last_removed_idx]
    first_removed_was_head = indices[0] == 0
    for i in reversed(indices):
        iv.entries.pop(i)
    # Tail fixup: only if the original tail was actually removed.
    if last_removed_idx == original_len - 1:
        _fix_tail_after_delete(iv, len(iv.entries), last_removed_entry)
    if first_removed_was_head:
        _fix_head_after_delete(iv, 0)
    return True


def _fix_tail_after_delete(
    iv: InlineTableValue, removed_idx: int, removed: InlineTableEntry
) -> None:
    """Promote a new tail after deleting the trailing entry.

    Under the canonical model, the bracket pad before ``}`` lives in
    ``final_trivia``, so the new tail keeps its ``has_comma`` /
    ``post_comma_trivia`` exactly as the previous-to-last entry had
    them — except when the *removed* entry had no trailing comma, in
    which case the new tail also drops its comma to avoid emitting a
    stray trailing one.
    """
    if not iv.entries or removed_idx != len(iv.entries):
        return
    new_last = iv.entries[-1]
    if removed.has_comma:
        # Trailing-comma style preserved; new_last keeps its comma.
        new_last.has_comma = True
        new_last.post_comma_trivia = removed.post_comma_trivia
    else:
        # Removed had no trailing comma → drop the new tail's comma.
        new_last.has_comma = False
        new_last.post_comma_trivia = Trivia()
        if removed.trailing.pieces and not new_last.trailing.pieces:
            new_last.trailing = removed.trailing


def _fix_head_after_delete(iv: InlineTableValue, removed_idx: int) -> None:
    """Restore canonical entries[0].leading == Trivia() after head delete.

    Under the canonical model, the bracket pad before entries[0] lives
    in ``header_trivia``; ``entries[0].leading`` is always empty. After
    deleting the head, the new head's ``leading`` (which used to be the
    inter-entry separator) becomes redundant — drop it.
    """
    if not iv.entries or removed_idx != 0:
        return
    iv.entries[0].leading = Trivia()


__all__ = ["append_entry", "delete_entry", "replace_entry_value"]
