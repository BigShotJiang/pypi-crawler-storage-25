"""Adapter control loop (§4.2 of architecture-decision.md, Python form).

Responsibilities per turn:

1. Drain inbox. Dispatch protocol messages (shutdown_request,
   plan_approval_request). Enqueue task_assignment references for claim.
2. Claim the next unblocked, unowned task assigned to us (or any pending
   unblocked task if none are explicitly assigned — prefer assigned).
3. Run Codex on the claimed task, mark completed, send task_complete.
4. When idle with no claimable tasks, send an idle_notification and sleep.

Safety properties:

- Shutdown is deterministic: approve unless mid-task; reject with
  `in-flight task #N` feedback otherwise.
- Exit-exit cleanup: on SIGTERM/SIGINT, if a task is in-flight it stays
  `in_progress` (lead can reclaim via reset_owner_tasks) but the loop
  deregisters before exiting.
- Every cs50victor call is wrapped so a transient FS race doesn't kill
  the loop — it logs and continues to next poll.
"""

from __future__ import annotations

import json
import signal
import time
from dataclasses import dataclass, field
from typing import Any

from . import codex as codex_mod
from . import logger, protocol_io as pio
from . import prompts as prompts_mod
from .config import Settings
from .messages import (
    PlanApprovalRequestIn,
    ShutdownRequestIn,
    parse_protocol_text,
)
from .registration import deregister, register


@dataclass
class LoopState:
    settings: Settings
    shutdown_requested: bool = False
    approved_shutdown: bool = False
    in_flight_task: str | None = None
    seen_shutdown_request_ids: set[str] = field(default_factory=set)
    # v7.2: most recent Codex session (`thread_id`) captured from a prior
    # task's JSONL event stream. First task for this adapter identity:
    # None → fresh `codex exec` (schema-constrained). Subsequent tasks:
    # invoke `codex exec resume <session_id>` so Codex carries prior-task
    # context forward. In-memory only; v7.2 doesn't persist across
    # adapter restarts.
    codex_session_id: str | None = None
    # v7.3 App Server lineage: threadId of the most recent `thread/start`
    # or `thread/fork` result. Passed to the next `app_server_invoke` as
    # `resume_thread_id` so that call uses `thread/fork` to inherit prior
    # conversational context. Same in-memory, same-process-lifetime scope
    # as codex_session_id.
    app_server_last_thread_id: str | None = None


def run(settings: Settings) -> int:
    """Run the adapter's main loop. Returns a process exit code."""
    codex_mod.feature_test(
        settings.codex_binary,
        mcp_probe=True,
        team=settings.team_name,
        agent_name=settings.agent_name,
    )
    register(settings)

    state = LoopState(settings=settings)

    def _sig_handler(signum: int, _frame: Any) -> None:
        logger.warn("signal.received", signum=signum)
        state.shutdown_requested = True

    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)

    exit_code = 0
    try:
        _main_loop(state)
    except Exception as e:
        logger.error("loop.crash", error=str(e))
        exit_code = 1
    finally:
        # Deregister on a clean approved shutdown. SIGTERM-mid-task is NOT
        # a zombie case: the signal handler sets shutdown_requested=True and
        # the loop drains the current task turn before setting approved_shutdown
        # and returning — so SIGTERM exits cleanly. Only uncaught exceptions
        # (loop.crash) skip deregistration and leave a zombie entry for the
        # lead to inspect.
        if state.approved_shutdown:
            deregister(settings)
            logger.info("loop.deregistered", name=settings.agent_name)
        else:
            logger.warn(
                "loop.exit_without_deregister",
                in_flight_task=state.in_flight_task,
            )
    return exit_code


def _main_loop(state: LoopState) -> None:
    s = state.settings
    logger.info(
        "loop.start",
        team=s.team_name,
        name=s.agent_name,
        poll_s=s.poll_interval_s,
    )

    idle_last_sent_at: float | None = None

    while not state.approved_shutdown:
        # 1. Drain inbox. Use read_own_inbox so the "self-only" invariant is
        # asserted at call time — cs50victor's mark_as_read rewrites the file,
        # and touching another teammate's inbox would corrupt its schema.
        messages = pio.read_own_inbox(s.team_name, s.agent_name, s.agent_name)
        for m in messages:
            _handle_message(state, m)
            if state.approved_shutdown:
                return

        # 2. Claim-and-execute.
        if not state.shutdown_requested:
            claimed = _find_and_claim(state)
            if claimed is not None:
                _execute_task(state, claimed)
                idle_last_sent_at = None
                continue  # loop again to drain inbox before idling

        # 3. Idle notification (rate-limited to once per 60s while idle).
        if not _has_claimable(state):
            now = time.monotonic()
            if idle_last_sent_at is None or (now - idle_last_sent_at) > 60.0:
                try:
                    pio.send_idle_notification(s.team_name, s.agent_name)
                    idle_last_sent_at = now
                    logger.info("idle.sent")
                except Exception as e:
                    logger.warn("idle.send_fail", error=str(e))

        # 4. Sleep.
        time.sleep(s.poll_interval_s)

        # 5. Honour SIGINT/SIGTERM if we haven't already agreed to shut down.
        if state.shutdown_requested and state.in_flight_task is None:
            logger.info("loop.signal_exit")
            state.codex_session_id = None
            state.app_server_last_thread_id = None
            state.approved_shutdown = True
            return


def _handle_message(state: LoopState, msg: Any) -> None:
    payload = parse_protocol_text(msg.text)
    if payload is None:
        _handle_prose(state, msg)
        return

    if isinstance(payload, ShutdownRequestIn):
        _handle_shutdown(state, payload)
        return
    if isinstance(payload, PlanApprovalRequestIn):
        _handle_plan_approval(state, payload)
        return
    # task_assignment, plan_approval_response — noted but not acted on here.
    # task_assignment messages are informational; the shared task list is the
    # source of truth. plan_approval_response is only meaningful if we sent a
    # request, handled in the opt-in branch.
    logger.debug("inbox.protocol_noop", type=payload.__class__.__name__)


def _handle_prose(state: LoopState, msg: Any) -> None:
    """Handle an inbound prose (non-protocol) message while idle.

    Invokes Codex once (schema-free) with the peer's message as the prompt so
    Codex can compose a natural reply. Codex is instructed to use the
    `send_message` MCP wrapper tool to deliver the reply directly to the
    sender, which gives the closest parity to how native Claude agents handle
    peer prose.

    On any Codex failure, falls back to a minimal acknowledgement sent directly
    via `pio.send_prose` so the sender is never left with total silence.

    The prose invocation is intentionally ephemeral — it does not update
    `state.codex_session_id` or `state.app_server_last_thread_id`, keeping
    the task-lineage slots clean for the next real task.
    """
    s = state.settings
    sender = getattr(msg, "from_", "unknown")
    logger.info("inbox.prose", sender=sender, summary=getattr(msg, "summary", None))

    prompt = prompts_mod.v7_prose_reply_prompt(
        sender=sender,
        body=msg.text,
        agent_name=s.agent_name,
        team_name=s.team_name,
    )

    reply: str | None = None
    result = None
    try:
        if s.app_server:
            result = codex_mod.app_server_invoke(
                task_prompt=prompt,
                cwd=s.cwd,
                schema=None,
                settings_team=s.team_name,
                settings_agent=s.agent_name,
                codex_binary=s.codex_binary,
                model=s.model,
                effort=s.effort,
                # No resume_thread_id — ephemeral, not chained to task lineage.
            )
        else:
            result = codex_mod.run(
                prompt=prompt,
                cwd=s.cwd,
                schema=None,
                codex_binary=s.codex_binary,
                extra_args=codex_mod.wrapper_mcp_config_args(s.team_name, s.agent_name),
                wrapper_identity=(s.team_name, s.agent_name),
                model=s.model,
                effort=s.effort,
            )
        if result.exit_code == 0 and result.last_message:
            reply = result.last_message
        else:
            logger.warn(
                "prose.codex_fail",
                sender=sender,
                exit_code=result.exit_code,
                error=result.error,
            )
    except Exception as e:
        logger.warn("prose.codex_crash", sender=sender, error=str(e))

    # If the model already delivered the reply via the send_message MCP tool,
    # last_message is empty by design (the model did everything in tools and
    # produced no trailing assistant text). Don't double-send a canned
    # fallback on top of the real reply.  Mirrors the Kimi adapter fix at
    # backends/kimi/loop.py (PR #11) — same bug, same shape, same guard.
    if reply is None and result is not None and result.exit_code == 0 and getattr(result, "tool_call_events", 0) > 0:
        logger.info("prose.delivered_via_tool", sender=sender, tool_calls=result.tool_call_events)
        return

    if reply is None:
        # Codex couldn't produce a reply — fall back to a minimal ack.
        reply = (
            f"I received your message. I am a Codex adapter and ran into a "
            f"problem generating a reply. Please contact team-lead if this "
            f"message requires a response."
        )

    try:
        pio.send_prose(s.team_name, s.agent_name, sender, reply, summary="prose_reply")
        logger.info("prose.reply_sent", sender=sender)
    except Exception as e:
        logger.warn("prose.reply_send_fail", sender=sender, error=str(e))


def _handle_shutdown(state: LoopState, payload: ShutdownRequestIn) -> None:
    s = state.settings
    req_id = payload.effective_request_id() or "shutdown-unknown"

    # Idempotent: never respond twice to the same request_id.
    if req_id in state.seen_shutdown_request_ids:
        logger.debug("shutdown.duplicate_ignored", request_id=req_id)
        return
    state.seen_shutdown_request_ids.add(req_id)

    if state.in_flight_task is not None:
        feedback = f"in-flight task #{state.in_flight_task}"
        logger.info("shutdown.reject", request_id=req_id, in_flight=state.in_flight_task)
        try:
            pio.send_shutdown_response(
                s.team_name, s.agent_name, req_id, approve=False, feedback=feedback
            )
        except Exception as e:
            logger.warn("shutdown.response_fail", error=str(e))
        state.shutdown_requested = True  # honour after current task finishes
        return

    logger.info("shutdown.approve", request_id=req_id)
    try:
        pio.send_shutdown_response(s.team_name, s.agent_name, req_id, approve=True)
    except Exception as e:
        logger.warn("shutdown.response_fail", error=str(e))
    state.codex_session_id = None
    state.app_server_last_thread_id = None
    state.approved_shutdown = True


def _handle_plan_approval(state: LoopState, payload: PlanApprovalRequestIn) -> None:
    """Opt-in plan-mode path (§4.5). Only active when planModeRequired=True.

    Invokes Codex once with `--output-schema plan.schema.json` to produce a
    structured plan for the task referenced by the request (or the
    adapter's current assigned/claimable task if no task_id was provided).
    On a schema-conformant success, sends the plan to the lead via
    `plan_approval_request`. On failure, retries once with a tightened
    prompt (per §5 failure-mode row); if the retry also fails, marks the
    task blocked. Never sends a canned stub.

    Default policy (planModeRequired=False) drops the message with a
    warning — we are not in the business of answering plan requests we
    didn't opt into.
    """
    s = state.settings
    if not s.plan_mode_required:
        logger.warn("plan.unexpected_request", request_id=payload.request_id)
        return

    req_id = payload.request_id
    if req_id is None:
        logger.warn("plan.missing_request_id")
        return

    target_task = _target_task_for_plan(state, payload)
    if target_task is None:
        logger.warn("plan.no_target_task", request_id=req_id)
        # No task to plan against — tell the lead explicitly rather than
        # silently drop. Use a plain-text status message (kind: plan_blocked)
        # so the lead can see why no plan was produced.
        try:
            pio.send_prose_to_lead(
                s.team_name,
                s.agent_name,
                json.dumps({
                    "kind": "plan_blocked",
                    "request_id": req_id,
                    "reason": "no task_id in plan_approval_request and no claimable task in flight",
                }),
                summary=f"plan_blocked:{req_id}",
            )
        except Exception as e:
            logger.warn("plan.block_msg_fail", error=str(e))
        return

    logger.info(
        "plan.request_received",
        request_id=req_id,
        task_id=target_task.id,
    )

    for attempt in (1, 2):
        plan = _generate_plan(state, target_task, tighten=(attempt == 2))
        if plan is not None:
            try:
                pio.send_plan_approval_request(
                    s.team_name,
                    s.agent_name,
                    request_id=req_id,
                    plan=plan,
                )
                logger.info(
                    "plan.sent",
                    request_id=req_id,
                    task_id=target_task.id,
                    steps=len(plan.get("steps", [])),
                )
            except Exception as e:
                logger.warn("plan.send_fail", error=str(e))
            return
        logger.warn("plan.attempt_failed", attempt=attempt, task_id=target_task.id)

    # Both attempts failed — block the task and tell the lead. No stub.
    _mark_blocked(
        state,
        target_task,
        reason="plan generation failed twice (codex --output-schema produced no schema-conformant result)",
    )


def _target_task_for_plan(state: LoopState, payload: PlanApprovalRequestIn):
    """Resolve which task a plan_approval_request refers to.

    Prefers an explicit payload.task_id. Falls back to the adapter's
    currently-owned in-progress task, then to its highest-priority pending
    assigned task, then to the first unblocked pending unassigned task.
    Returns None if nothing claimable exists.
    """
    s = state.settings
    try:
        all_tasks = pio.list_tasks(s.team_name)
    except Exception as e:
        logger.warn("plan.task_list_fail", error=str(e))
        return None
    by_id = {t.id: t for t in all_tasks}

    if payload.task_id and payload.task_id in by_id:
        return by_id[payload.task_id]

    # In-flight first.
    if state.in_flight_task and state.in_flight_task in by_id:
        return by_id[state.in_flight_task]

    # Assigned-to-us pending.
    for t in sorted(
        (t for t in all_tasks
         if t.owner == s.agent_name
         and t.status == "pending"
         and not _blocked(all_tasks, t)),
        key=lambda x: int(x.id),
    ):
        return t

    # Unassigned pending (empty-string tolerant).
    for t in sorted(
        (t for t in all_tasks
         if (t.owner is None or t.owner == "")
         and t.status == "pending"
         and not _blocked(all_tasks, t)),
        key=lambda x: int(x.id),
    ):
        return t

    return None


def _generate_plan(state: LoopState, task, *, tighten: bool) -> dict[str, Any] | None:
    """Run `codex exec --output-schema plan.schema.json` once and return the
    structured plan, or None on any failure.

    `tighten=True` appends a stricter instruction on the retry (per §5).
    """
    s = state.settings
    prompt = prompts_mod.v7_plan_prompt(
        task,
        tighten=tighten,
        agent_name=s.agent_name,
        team_name=s.team_name,
    )
    try:
        result = codex_mod.run(
            prompt=prompt,
            cwd=s.cwd,
            schema=codex_mod.PLAN_SCHEMA,
            codex_binary=s.codex_binary,
            extra_args=codex_mod.wrapper_mcp_config_args(s.team_name, s.agent_name),
            wrapper_identity=(s.team_name, s.agent_name),
            model=s.model,
            effort=s.effort,
        )
    except Exception as e:
        logger.error("plan.codex_crash", task_id=task.id, error=str(e))
        return None

    if result.exit_code != 0 or result.structured is None:
        logger.warn(
            "plan.codex_fail",
            task_id=task.id,
            exit_code=result.exit_code,
            error=result.error,
        )
        return None

    return result.structured


def _find_and_claim(state: LoopState):
    """Return a claimed task, or None if no claimable task is available."""
    s = state.settings
    try:
        all_tasks = pio.list_tasks(s.team_name)
    except Exception as e:
        logger.warn("tasks.list_fail", error=str(e))
        return None

    # Prefer tasks already assigned to us (`owner == agent_name`) in pending
    # state — this handles the case where the lead pre-assigned via
    # task_update owner=<us>. Fall back to unowned pending tasks. Some
    # task-list tools serialize "no owner" as an empty string instead of
    # null, so treat "" as unowned.
    assigned_pending = [
        t for t in all_tasks
        if t.owner == s.agent_name and t.status == "pending" and not _blocked(all_tasks, t)
    ]
    unassigned_pending = [
        t for t in all_tasks
        if (t.owner is None or t.owner == "") and t.status == "pending" and not _blocked(all_tasks, t)
    ]

    # Sort by numeric id ascending to honour the "lowest id first" convention.
    assigned_pending.sort(key=lambda t: int(t.id))
    unassigned_pending.sort(key=lambda t: int(t.id))

    candidates = assigned_pending + unassigned_pending
    for t in candidates:
        try:
            claimed = pio.claim_task(
                s.team_name,
                t.id,
                s.agent_name,
                active_form=f"Running codex on task #{t.id}",
            )
            state.in_flight_task = claimed.id
            logger.info("task.claimed", task_id=claimed.id, subject=claimed.subject)
            return claimed
        except ValueError as e:
            # e.g., someone else claimed in the race window; try the next.
            logger.debug("task.claim_race", task_id=t.id, error=str(e))
            continue
    return None


def _has_claimable(state: LoopState) -> bool:
    s = state.settings
    try:
        all_tasks = pio.list_tasks(s.team_name)
    except Exception:
        return False
    for t in all_tasks:
        if t.status != "pending":
            continue
        if _blocked(all_tasks, t):
            continue
        if t.owner is None or t.owner == s.agent_name:
            return True
    return False


def _blocked(all_tasks: list, t) -> bool:
    if not getattr(t, "blocked_by", None):
        return False
    by_id = {x.id: x for x in all_tasks}
    for bid in t.blocked_by:
        blocker = by_id.get(bid)
        if blocker is None:
            continue
        if blocker.status not in ("completed", "deleted"):
            return True
    return False


def _execute_task(state: LoopState, task) -> None:
    """Run Codex on a claimed task and update state accordingly.

    v7.2: when a prior task has captured a Codex session id for this
    agent identity, subsequent tasks invoke `codex exec resume` so
    Codex carries prior-task context forward. Because `resume` does
    not accept `--output-schema` on codex-cli 0.122.0, the resume path
    validates the final output in Python via `schema_validation`.
    Retry-once-with-firmer-prompt is the failure path.
    """
    s = state.settings
    result = _invoke_codex_for_task(state, task)
    if result is None:
        # _invoke_codex_for_task has already recorded the failure and
        # called `_mark_blocked`. Exit early.
        state.in_flight_task = None
        return

    # Capture session id for subsequent tasks. In CLI resume mode this is
    # only populated on the fresh-exec branch; in App Server mode the
    # current thread id is returned on every successful invocation.
    if result.session_id and state.codex_session_id is None:
        state.codex_session_id = result.session_id
        logger.info("task.session_captured", session_id=result.session_id)

    if result.structured is None or result.exit_code != 0:
        logger.warn(
            "task.codex_fail",
            task_id=task.id,
            exit_code=result.exit_code,
            error=result.error,
        )
        _mark_blocked(
            state,
            task,
            reason=(result.error or f"codex exited {result.exit_code} with no structured result"),
        )
        state.in_flight_task = None
        return

    # v7.3 App Server lineage: capture the thread id returned by
    # app_server_invoke (either the fresh thread/start or the forked
    # thread/fork) so the NEXT task can fork from it. Only overwrite on
    # success — failed turns must not poison the next fork parent.
    if s.app_server and result.session_id:
        state.app_server_last_thread_id = result.session_id
        logger.info(
            "task.app_server_thread_captured",
            thread_id=result.session_id,
        )

    files_changed = result.structured.get("files_changed") or []
    summary_text = result.structured.get("summary") or "(no summary)"

    try:
        pio.update_task(s.team_name, task.id, status="completed")
    except Exception as e:
        logger.error("task.complete_fail", task_id=task.id, error=str(e))
        state.in_flight_task = None
        return

    try:
        pio.send_task_complete(
            s.team_name,
            s.agent_name,
            task_id=task.id,
            files_changed=files_changed,
            summary_text=summary_text,
            codex_exit_code=result.exit_code,
        )
    except Exception as e:
        logger.warn("task.complete_msg_fail", task_id=task.id, error=str(e))

    logger.info("task.completed", task_id=task.id, files=len(files_changed))
    state.in_flight_task = None


def _invoke_codex_for_task(state: LoopState, task):
    """Dispatch to the right Codex invocation shape for this task.

    Branch order (first match wins):
    1. `settings.app_server` → v7.1 App Server path (handles streaming
       + turn/steer via `_execute_task_app_server`).
    2. `state.codex_session_id is not None` → v7.2 resume path (no
       `--output-schema`, Python-side validation, retry once on
       schema failure).
    3. Otherwise → v7 fresh-exec path (schema-constrained at CLI layer).

    Returns `None` if the invocation crashed so fundamentally that
    `_mark_blocked` was called here; otherwise returns a `CodexResult`
    (possibly with `.structured is None` for schema failures that the
    caller will handle).
    """
    import json as _json
    from . import schema_validation as _sv

    s = state.settings

    if s.app_server:
        prompt = prompts_mod.v7_task_prompt(
            task, agent_name=s.agent_name, team_name=s.team_name
        )
        try:
            return _execute_task_app_server(state, task, prompt)
        except Exception as e:
            logger.error("task.codex_crash", task_id=task.id, error=str(e))
            _mark_blocked(state, task, reason=f"codex invocation crashed: {e}")
            return None

    # v7.2: resume path if we have a session to carry forward.
    if state.codex_session_id is not None:
        schema = _sv.load_schema(codex_mod.TASK_COMPLETE_SCHEMA)
        inline = _sv.inline_schema_prompt_fragment(schema)
        for attempt in (1, 2):
            prompt = prompts_mod.v7_task_prompt(
                task,
                agent_name=s.agent_name,
                team_name=s.team_name,
            ) + "\n\n# Output contract (v7.2 resume)\n" + inline
            if attempt == 2:
                prompt += (
                    "\n\nPRIOR ATTEMPT FAILED: your previous response did "
                    "not match the schema above. Return ONLY the JSON object "
                    "with exactly the required fields. No markdown fences. "
                    "No prose before or after. No extra fields."
                )
            try:
                result = codex_mod.run(
                    prompt=prompt,
                    cwd=s.cwd,
                    schema=None,  # ignored on resume path; explicit for clarity
                    codex_binary=s.codex_binary,
                    extra_args=codex_mod.wrapper_mcp_config_args(
                        s.team_name, s.agent_name
                    ),
                    wrapper_identity=(s.team_name, s.agent_name),
                    resume_session_id=state.codex_session_id,
                    model=s.model,
                    effort=s.effort,
                )
            except Exception as e:
                logger.error(
                    "task.codex_crash",
                    task_id=task.id,
                    error=str(e),
                    attempt=attempt,
                )
                _mark_blocked(state, task, reason=f"codex invocation crashed: {e}")
                return None

            if result.exit_code != 0:
                logger.warn(
                    "task.resume_nonzero",
                    task_id=task.id,
                    exit_code=result.exit_code,
                    attempt=attempt,
                )
                if attempt == 2:
                    return result  # let the caller mark it blocked
                continue

            parsed, err = _sv.parse_and_validate(result.last_message, schema)
            if err is None and parsed is not None:
                # Return a new CodexResult with `structured` filled in so
                # the caller's happy path works identically to the fresh-exec
                # schema-constrained path. Session id is preserved.
                return codex_mod.CodexResult(
                    exit_code=result.exit_code,
                    structured=parsed,
                    last_message=result.last_message,
                    events=result.events,
                    error=None,
                    tool_call_events=result.tool_call_events,
                    session_id=result.session_id or state.codex_session_id,
                )

            logger.warn(
                "task.resume_schema_fail",
                task_id=task.id,
                attempt=attempt,
                reason=err,
            )
            if attempt == 2:
                # Two failures: mark the task blocked with the reason.
                _mark_blocked(
                    state,
                    task,
                    reason=f"codex resume output failed schema after retry: {err}",
                )
                return None

    # v7 fresh-exec path (also: first task of an adapter's lifetime,
    # before we've captured a session id).
    prompt = prompts_mod.v7_task_prompt(
        task, agent_name=s.agent_name, team_name=s.team_name
    )
    try:
        return codex_mod.run(
            prompt=prompt,
            cwd=s.cwd,
            schema=codex_mod.TASK_COMPLETE_SCHEMA,
            codex_binary=s.codex_binary,
            extra_args=codex_mod.wrapper_mcp_config_args(s.team_name, s.agent_name),
            wrapper_identity=(s.team_name, s.agent_name),
            model=s.model,
            effort=s.effort,
        )
    except Exception as e:
        logger.error("task.codex_crash", task_id=task.id, error=str(e))
        _mark_blocked(state, task, reason=f"codex invocation crashed: {e}")
        return None


def _execute_task_app_server(state: LoopState, task, prompt: str):
    """v7.1 path: run the task via `codex app-server`, with a mid-turn hook
    that drains our own inbox and forwards prose messages to Codex via
    `turn/steer`.

    Returns a `codex.CodexResult` in the same shape as the v7 exec path
    so the surrounding control flow in `_execute_task` is uniform.
    """
    import json as _json

    s = state.settings

    # Load the task-complete schema as a JSON dict (App Server wants it
    # inline in `turn/start` params, not as a file path).
    with open(codex_mod.TASK_COMPLETE_SCHEMA) as f:
        schema = _json.load(f)

    steer_queue = codex_mod.SteerQueue()

    def _mid_turn_hook() -> None:
        # Drain own inbox. Prose messages become steer fragments; shutdown
        # requests are snapshotted for the outer loop to handle after the
        # turn completes. Ignore everything else.
        try:
            messages = pio.read_own_inbox(s.team_name, s.agent_name, s.agent_name)
        except Exception:
            return
        for m in messages:
            payload = __import__(
                "claude_anyteam.messages", fromlist=["parse_protocol_text"]
            ).parse_protocol_text(m.text)
            if payload is None:
                steer_queue.push(
                    f"mid-task message from {m.from_}: {m.text}"
                )
                logger.info(
                    "task.steer_queued",
                    from_=m.from_,
                    text_head=m.text[:120],
                )
            elif isinstance(payload, ShutdownRequestIn):
                # Reuse the normal shutdown handler so mid-task requests get
                # the same immediate reject+feedback response, idempotency,
                # and post-task honor semantics as the idle path.
                _handle_shutdown(state, payload)
                logger.info(
                    "task.steer_saw_shutdown", request_id=payload.effective_request_id()
                )

    return codex_mod.app_server_invoke(
        task_prompt=prompt,
        cwd=s.cwd,
        schema=schema,
        settings_team=s.team_name,
        settings_agent=s.agent_name,
        codex_binary=s.codex_binary,
        steer_queue=steer_queue,
        mid_turn_hook=_mid_turn_hook,
        model=s.model,
        effort=s.effort,
        resume_thread_id=state.app_server_last_thread_id,
    )


def _mark_blocked(state: LoopState, task, reason: str) -> None:
    """On Codex failure: set activeForm to indicate blocking, annotate metadata,
    and notify the lead. Task stays `in_progress` so the lead can see it needs
    attention without reclaim logic.

    If another codepath has already marked the task `completed` (e.g., a
    plan-mode retry succeeded after this failure was scheduled but before
    it executed — the race reviewer observed on task #13), skip the
    mutation and the blocked-message so we don't overwrite legitimate
    completion state. Defensive re-read to catch the race as late as possible.
    """
    s = state.settings
    try:
        current = pio.get_task(s.team_name, task.id)
        if getattr(current, "status", None) == "completed":
            logger.info(
                "task.block_skip_already_completed",
                task_id=task.id,
                reason_would_have_been=reason[:120],
            )
            return
    except Exception as e:
        logger.warn("task.block_precheck_fail", task_id=task.id, error=str(e))
        # Fall through to the mutation; precheck failing is not reason enough
        # to silently abandon a real failure report.

    try:
        pio.update_task(
            s.team_name,
            task.id,
            active_form=f"blocked: {reason[:80]}",
            metadata={"blocked_reason": reason, "blocked_by": s.agent_name},
        )
    except Exception as e:
        logger.warn("task.block_update_fail", task_id=task.id, error=str(e))

    try:
        pio.send_task_blocked(
            s.team_name,
            s.agent_name,
            task_id=task.id,
            reason=reason,
        )
    except Exception as e:
        logger.warn("task.block_msg_fail", task_id=task.id, error=str(e))

