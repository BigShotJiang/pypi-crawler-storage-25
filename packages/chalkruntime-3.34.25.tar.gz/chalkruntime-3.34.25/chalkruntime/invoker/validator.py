from datetime import datetime
from typing import Any, Mapping, Sequence

import polars as pl
import pyarrow as pa
from chalk.client import ChalkError
from chalk.features import CacheStrategy, DataFrame, Feature, FeatureSetBase
from chalk.features.pseudofeatures import PSEUDONAMESPACE
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.df_utils import pa_array_to_pl_series, pa_table_to_pl_df
from chalk.utils.log_with_context import get_logger
from chalk.utils.pl_helpers import is_new_polars

from chalkruntime.exc.failed_argument import FailedArgument
from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureValidationsParsed,
    InputFeatureType,
    ScalarFeatureType,
    UnderlyingScalarFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    is_underlying_scalar,
)
from chalkruntime.graph.resolver import ResolverParsed
from chalkruntime.invoker.sample import Sample

_logger = get_logger(__name__)


def render_validations(feature: ScalarFeatureType | InputFeatureType[ScalarFeatureType], only_strict: bool) -> str:
    len_feature = f"len({feature.root_fqn})"
    cs: list[tuple[str, str]] = []

    for vs in feature.underlying.validations or []:
        if only_strict and not vs.strict:
            continue

        constraints = None
        name: str | None = None
        if vs.min_length is not None:
            name = "min_length"
            constraints = f"{vs.min_length} <= {len_feature}"

        if vs.max_length is not None:
            name = "max_length"
            if constraints is None:
                constraints = f"{len_feature} <= {vs.max_length}"
            else:
                constraints += f" <= {vs.max_length}"

        if constraints is not None:
            assert name is not None
            cs.append((name, constraints))

        size_constraints = None
        if vs.min is not None:
            name = "min"
            size_constraints = f"{vs.min} <= {feature.root_fqn}"

        if vs.max is not None:
            name = "max"
            if size_constraints is None:
                size_constraints = f"{feature.root_fqn} <= {vs.max}"
            else:
                size_constraints += f" <= {vs.max}"

        if size_constraints is not None:
            assert name is not None
            cs.append((name, size_constraints))

    # Canonical order to make error messages consistent / nicer to read
    def _get_order(name: str) -> tuple[int, str]:
        order = {
            "min": 0,
            "max": 1,
            "min_length": 2,
            "max_length": 3,
        }
        return order.get(name, 999), name

    cs.sort(key=lambda c: _get_order(c[0]))
    return " and ".join([x[1] for x in cs])


def _and_filters(filters: Sequence[pl.Expr]) -> pl.Expr | None:
    if len(filters) == 0:
        return None
    result = filters[0]
    for f in filters[1:]:
        result &= f
    return result


def validation_expression_for_feature(
    feature_col: pl.Expr,
    feature: ScalarFeatureType,
    only_strict: bool = False,
) -> pl.Expr | None:
    """Filters down to the valid rows"""
    filters = []
    require_non_null = False
    if (
        feature.cache_strategy.value == CacheStrategy.NO_NULLS.value
        or feature.cache_strategy.value == CacheStrategy.NO_NULLS_WITH_DEFAULTS_UNSET.value
        or feature.cache_strategy.value == CacheStrategy.NO_NULLS_OR_DEFAULTS.value
        or not feature.is_feature_nullable
    ):
        require_non_null = True
        filters.append(feature_col.is_not_null())

    if (
        feature.cache_strategy.value == CacheStrategy.NO_DEFAULTS.value
        or feature.cache_strategy.value == CacheStrategy.NO_DEFAULTS_WITH_NULLS_UNSET.value
        or feature.cache_strategy.value == CacheStrategy.NO_NULLS_OR_DEFAULTS.value
    ) and feature.primitive_converter.pyarrow_default is not ...:
        filters.append(feature_col != pa_array_to_pl_series(feature.primitive_converter.pyarrow_default))

    chalk_filter_expr = _and_filters(filters)
    del filters

    vss = feature.validations or ()
    custom_filters: list[pl.Expr] = []
    for vs in vss:
        if only_strict and not vs.strict:
            continue

        if pa.types.is_string(feature.pyarrow_dtype) or pa.types.is_large_string(feature.pyarrow_dtype):
            if vs.min_length is not None:
                if is_new_polars:
                    custom_filters.append(feature_col.str.len_chars() >= vs.min_length)  # pyright: ignore - polars backcompat
                else:
                    custom_filters.append(feature_col.str.n_chars() >= vs.min_length)  # pyright: ignore[reportAttributeAccessIssue] # ty:ignore[unresolved-attribute]

            if vs.max_length is not None:
                if is_new_polars:
                    custom_filters.append(feature_col.str.len_chars() <= vs.max_length)  # pyright: ignore - polars backcompat
                else:
                    custom_filters.append(feature_col.str.n_chars() <= vs.max_length)  # pyright: ignore[reportAttributeAccessIssue] # ty:ignore[unresolved-attribute]

        if vs.min is not None:
            custom_filters.append(feature_col >= vs.min)

        if vs.max is not None:
            custom_filters.append(feature_col <= vs.max)

    custom_filter_expr = _and_filters(custom_filters)
    custom_filter_expr = (
        (feature_col.is_null() | custom_filter_expr)
        if custom_filter_expr is not None and not require_non_null
        else custom_filter_expr
    )
    return _and_filters(tuple(x for x in (chalk_filter_expr, custom_filter_expr) if x is not None))


def validate_results(
    strict_validations: Mapping[UnderlyingScalarFeatureType, Sequence[FeatureValidationsParsed]],
    result: pa.Table | pl.DataFrame | ChalkRecordBatch,
    is_valid_mask: pa.ChunkedArray | pa.Array | pl.Series | None = None,
) -> ChalkError | None:
    if len(strict_validations) == 0:
        return
    if isinstance(result, ChalkRecordBatch):
        result = result.to_table()
    if isinstance(result, pa.Table):
        # Converting the result to a dataframe only if there are validations that we need to perform
        result = pa_table_to_pl_df(result)
    if isinstance(is_valid_mask, (pa.Array, pa.ChunkedArray)):
        is_valid_mask = pa_array_to_pl_series(is_valid_mask)
    if is_valid_mask is not None:
        result = result.filter(is_valid_mask)
    for f in strict_validations.keys():
        valid_expression = validation_expression_for_feature(
            feature_col=pl.col(f.root_fqn),
            feature=f.underlying,
            only_strict=True,
        )
        if valid_expression is not None:
            bad_rows = result.select(pl.col(f.root_fqn)).filter(~valid_expression).limit(1)
            if len(bad_rows) > 0:
                return ResolverErrors.failed_validation(
                    validation=render_validations(f, True),
                    example_value=str(bad_rows.slice(0, 1).rows()[0][0]),
                    feature=f.root_fqn,
                )
    return None


def validate_arguments(resolver: ResolverParsed, sample: Sample) -> tuple[list[FailedArgument], list[Any]]:
    """
    Our goal here is to figure out if we should skip this resolver or not.
    Point is that if the resolver requires non-optional inputs, we shouldn't invoke it with None.
    """
    errors: list[FailedArgument] = []
    rich_args: list[Any] = []

    for i, spec in enumerate(resolver.inputs):
        if spec.root_namespace == PSEUDONAMESPACE:
            continue
        if i in resolver.synthetic_inputs:
            rich_args.append(None)  # the synthetic inputs will be replaced later
            continue
        actual_arg = sample.values.get(spec, ...)
        if is_underlying_feature_time(spec):
            if not spec.underlying.primitive_converter.is_value_missing(actual_arg):
                assert isinstance(actual_arg, datetime)
                rich_args.append(spec.underlying.to_feature().converter.from_primitive_to_rich(actual_arg))
            elif sample.observed_at is not None:
                rich_args.append(sample.observed_at)
            else:
                assert sample.execution_timestamp is not None, (
                    "Samples should have the observed_at or the execution timestamp"
                )
                rich_args.append(sample.execution_timestamp)
            continue
        if is_underlying_scalar(spec):
            if spec.underlying.primitive_converter.is_value_missing(actual_arg):
                if i >= len(resolver.default_args):
                    _logger.warning(
                        f"Missing default argument for input '{spec.root_fqn}' to resolver '{resolver.fqn}'"
                    )
                if i < len(resolver.default_args) and (resolver_default := resolver.default_args[i]) is not None:
                    # First, prefer the default value specified in the resolver signature
                    # Assume that the default value is already "rich"
                    rich_args.append(resolver_default.default_value)
                elif spec.underlying.primitive_converter.has_default:
                    # Use the default from the feature class
                    rich_args.append(spec.underlying.to_feature().converter.rich_default)
                else:
                    # Appending a sentinel to maintain position ordering
                    rich_args.append(...)
                    errors.append(FailedArgument(value=actual_arg, expected_feature=spec.root_fqn))
            else:
                rich_args.append(spec.underlying.to_feature().converter.from_primitive_to_rich(actual_arg))
            continue
        if is_underlying_has_one(spec):
            kwargs: dict[str, Any] = {}
            for x in spec.flatten():
                feature = Feature.from_root_fqn(x.root_fqn)

                if is_underlying_feature_time(x):
                    sub_arg = sample.values.get(x, ...)
                    if not x.underlying.primitive_converter.is_value_missing(sub_arg):
                        assert isinstance(sub_arg, datetime)
                        kwargs[feature.attribute_name] = x.underlying.to_feature().converter.from_primitive_to_rich(
                            sub_arg
                        )
                    elif sample.observed_at is not None:
                        kwargs[feature.attribute_name] = sample.observed_at
                    else:
                        assert sample.execution_timestamp is not None, (
                            "Samples should have the observed_at or the execution timestamp"
                        )
                        kwargs[feature.attribute_name] = sample.execution_timestamp
                    continue
                elif is_underlying_scalar(x):
                    # Only directly-nested features are fetched when specifying an entire has-one. Relationships are not fetched.
                    sub_arg = sample.values.get(x, ...)
                    if not x.underlying.primitive_converter.is_value_missing(sub_arg):
                        kwargs[feature.attribute_name] = x.underlying.to_feature().converter.from_primitive_to_rich(
                            sub_arg
                        )
                    elif x.underlying.primitive_converter.has_default:
                        kwargs[feature.attribute_name] = x.underlying.to_feature().converter.rich_default
                    else:
                        kwargs[feature.attribute_name] = ...
            features_cls = FeatureSetBase.registry[spec.underlying.foreign_namespace()]
            instance = features_cls(**kwargs)
            rich_args.append(instance)
            continue
        if is_underlying_has_many(spec) or isinstance(spec, DataFrameType):
            assert spec is not ..., "DataFrame features should never be missing"
            if not isinstance(actual_arg, DataFrame):
                actual_arg = DataFrame(actual_arg, missing_value_strategy="default_or_allow")
            rich_args.append(actual_arg)
            continue
        raise RuntimeError(f"Unexpected argument type: {spec}")

    return errors, rich_args
