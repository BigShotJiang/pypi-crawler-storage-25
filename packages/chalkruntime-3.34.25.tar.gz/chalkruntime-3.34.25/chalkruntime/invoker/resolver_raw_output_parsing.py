from __future__ import annotations

import traceback
from dataclasses import dataclass
from typing import Any, Callable, Literal, Optional, overload

import polars as pl
import pyarrow as pa
from chalk.client import ChalkError, ChalkException, ErrorCode
from chalk.features import DataFrame, Features, MissingValueStrategy
from chalk.utils.collections import FrozenOrderedSet, get_unique_item
from chalk.utils.log_with_context import get_logger

from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.graph.feature import (
    FeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    is_underlying_scalar,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.resolver import ResolverParsed
from chalkruntime.graph.stream_resolver import StreamResolverParsed

_logger = get_logger(__name__)


def _handle_df_error(resolver_fqn: str, e: Exception) -> tuple[ChalkError, int]:
    stacktrace = "".join(traceback.format_tb(e.__traceback__)[1:])
    chalk_exc = ChalkException.create(
        kind=type(e).__name__,
        message=str(e),
        stacktrace=stacktrace,
    )
    if isinstance(e, TypeError) or isinstance(e, pl.exceptions.ComputeError):
        # Example messages:
        # 1.      Feature 'user.email' has missing values, but the feature does not have a default.
        #
        # 2.     'NotYetImplemented("Casting from LargeUtf8 to LargeList(Field
        #         { name: \\"item\\", data_type: LargeUtf8, is_nullable: true, metadata: {} }) not supported")'
        return (
            ChalkError.create(
                code=ErrorCode.VALIDATION_FAILED,
                message=str(e),
                resolver=resolver_fqn,
                exception=chalk_exc,
            ),
            0,
        )

    return ResolverErrors.failed_to_convert_to_dataframe(resolver_fqn=resolver_fqn, exception=chalk_exc), 0


def resolver_raw_output_to_data_frame(
    *,
    resolver: ResolverParsed,
    raw_result: Any,
    graph: ResolvedGraph,
    missing_value_strategy: MissingValueStrategy,
    pkey_values: Optional[list[Any]] = None,
    lazyframe_modifier: Callable[[pl.LazyFrame], pl.LazyFrame] | None = None,
) -> tuple[pl.LazyFrame | ChalkError, int]:
    """
    Resolvers can return almost any kind of raw output: here we are converting that anything to a LazyFrame.
    Parameters
    ----------
    resolver
        Our resolver, be aware that StreamResolvers are included
    raw_result
        Beware, can be almost anything
    graph
        ResolvedGraph
    missing_value_strategy
        default, error, etc.
    pkey_values
        just for error messages/debugging
    lazyframe_modifier
        At the end of this function, we do a validation that the expected columns == the actual columns.
        In some cases, we may return more columns than what is specified via the output of a resolver.
        In this case, we may need to modify the lazyframe before validating the columns.
    Returns
    -------
    A lazyframe or an error, and the number of rows if not error, else 0.
    """
    lazyframe_or_error, num_rows = _resolver_raw_output_to_data_frame_inner(
        resolver=resolver,
        raw_result=raw_result,
        graph=graph,
        return_type="polars_lazyframe",
        missing_value_strategy=missing_value_strategy,
        pkey_values=pkey_values,
    )
    if isinstance(lazyframe_or_error, ChalkError):
        return lazyframe_or_error, num_rows

    lazyframe: pl.LazyFrame = lazyframe_or_error
    if lazyframe_modifier is not None:
        lazyframe = lazyframe_modifier(lazyframe)

    actual_output_fqns = FrozenOrderedSet(fqn for fqn in lazyframe.columns)
    if error := validate_return_columns(
        resolver=resolver,
        graph=graph,
        actual_output_fqns=actual_output_fqns,
    ):
        return error, 0
    return lazyframe, num_rows


def _return_dataframe_as_type(
    df: DataFrame,
    return_type: Literal["polars_lazyframe", "pyarrow"],
    resolver: ResolverParsed,
) -> tuple[pl.LazyFrame | pa.Table | ChalkError, int]:
    if return_type == "polars_lazyframe":
        try:
            # Collect the dataframe now to catch any lazy compute errors that would occur later
            lazyframe = df.to_polars()
            lazyframe.collect()
            return lazyframe, len(df)
        except Exception as e:
            return _handle_df_error(resolver.fqn, e)
    elif return_type == "pyarrow":
        return df.to_pyarrow(), len(df)
    raise ValueError(f"Unsupported return type: {return_type}")


@overload
def _resolver_raw_output_to_data_frame_inner(
    *,
    resolver: ResolverParsed,
    raw_result: Any,
    graph: ResolvedGraph,
    missing_value_strategy: MissingValueStrategy,
    return_type: Literal["polars_lazyframe"],
    pkey_values: Optional[list[Any]] = None,
) -> tuple[pl.LazyFrame | ChalkError, int]: ...


@overload
def _resolver_raw_output_to_data_frame_inner(
    *,
    resolver: ResolverParsed,
    raw_result: Any,
    graph: ResolvedGraph,
    missing_value_strategy: MissingValueStrategy,
    return_type: Literal["pyarrow"],
    pkey_values: Optional[list[Any]] = None,
) -> tuple[pa.Table | ChalkError, int]: ...


def _resolver_raw_output_to_data_frame_inner(
    *,
    resolver: ResolverParsed,
    raw_result: Any,
    graph: ResolvedGraph,
    missing_value_strategy: MissingValueStrategy,
    return_type: Literal["polars_lazyframe", "pyarrow"],
    pkey_values: Optional[list[Any]] = None,
) -> tuple[pl.LazyFrame | pa.Table | ChalkError, int]:
    result = raw_result

    if resolver.output_is_df:
        # We didn't receive a dataframe despite saying that we should
        if not isinstance(result, DataFrame):
            try:
                # Allowing missing values here to stay because this is used by cron jobs,
                # and cron jobs filter out missing values later
                result = DataFrame(result, missing_value_strategy=missing_value_strategy)
            except Exception as e:
                return _handle_df_error(resolver.fqn, e)

        assert isinstance(result, DataFrame)
        return _return_dataframe_as_type(result, return_type, resolver)

    # Using string-based comparison to avoid importing pandas when it might not be installed
    if any(x.__name__ in ("DataFrame", "DataFrameImpl", "LazyFrame") for x in result.__class__.__mro__):
        if not isinstance(result, DataFrame):
            try:
                result = DataFrame(result, missing_value_strategy=missing_value_strategy)
            except Exception as e:
                return _handle_df_error(resolver.fqn, e)
        if len(result) == 0:
            # If returning an empty dataframe, treat it as empty for all feature values
            try:
                result = DataFrame(
                    {x.root_fqn: [None] for x in resolver.output_features},
                    missing_value_strategy=missing_value_strategy,
                )
            except Exception as e:
                # Possible that we raise if null is not supported for any of the features
                return _handle_df_error(resolver.fqn, e)

        if len(result) == 1:
            # Accept a DataFrame of 1 row as Feature Set
            if result.shape == (1, 1):
                # If it's a singleton, then ignore the column name of the dataframe
                result = result.item()
            else:
                return _return_dataframe_as_type(result, return_type, resolver)

        else:
            return (
                ResolverErrors.dataframe_instead_of_scalar(
                    resolver_fqn=resolver.fqn,
                    dataframe_shape=result.shape,
                    dataframe_columns=[ft.root_fqn for ft in result.columns],
                ),
                0,
            )

    # Resolver outputs a scalar, we have some kind of scalar thing
    if isinstance(result, Features):
        result_row: dict[FeatureType, list[Any]] = {}
        for f in result.features:
            if hasattr(result, f.attribute_name) and not f.no_display:
                feature_type = graph.feature_from_fqn(f.fqn)
                assert feature_type is not None
                if isinstance(feature_type, HasOneFeatureType):
                    # TODO: this only works for has-one features in the root namespace.
                    # If we need to support nested has-one features, we'll need to change this.
                    has_one_features = getattr(result, f.attribute_name)
                    for ho_ft in feature_type.flatten():
                        if hasattr(has_one_features, ho_ft.name):
                            result_row[ho_ft] = [getattr(has_one_features, ho_ft.name)]
                else:
                    result_row[feature_type] = [getattr(result, f.attribute_name)]
        try:
            result = DataFrame(result_row, missing_value_strategy=missing_value_strategy)
        except Exception as e:
            _logger.error(f"Failed to convert {result_row} to DataFrame", exc_info=e)
            return (
                ChalkError.create(
                    code=ErrorCode.RESOLVER_FAILED,
                    message=(
                        f"{e.__class__.__name__}: {e} The primary keys that led to this failure are {pkey_values}. "
                        if pkey_values is not None
                        else f"{e.__class__.__name__}: {e}"
                    ),
                    exception=ChalkException.create(
                        kind=type(e).__name__,
                        message=str(e),
                        # Not providing the stack as it happens outside the user's resolver
                        stacktrace="",
                        internal_stacktrace="".join(traceback.format_tb(e.__traceback__)),
                    ),
                    feature=None,
                    resolver=resolver.fqn,
                ),
                0,
            )
        return _return_dataframe_as_type(result, return_type, resolver)
    # We'd better have exactly one thing, which is your feature result
    if len(resolver.output_features) == 1:
        feature_type = get_unique_item(resolver.output_features, name="resolver output")
        try:
            result = DataFrame({feature_type: [result]}, missing_value_strategy=missing_value_strategy)
        except Exception as e:
            _logger.warning(f"Raw type error executing {resolver.fqn}: {e}")
            assert isinstance(feature_type, ScalarFeatureType)
            return (
                ResolverErrors.wrong_output_type(
                    expected_type_name=str(feature_type.to_feature().converter.rich_type),
                    result_type_name=type(result).__name__,
                    feature_fqn=feature_type.fqn,
                    resolver_fqn=resolver.fqn,
                ),
                0,
            )
        return _return_dataframe_as_type(result, return_type, resolver)

    if return_type == "polars_lazyframe":
        return pl.DataFrame().lazy(), 0
    elif return_type == "pyarrow":
        return pa.Table.from_pydict({}, schema=pa.schema([])), 0
    raise ValueError(f"Unsupported return type: {return_type}")


@dataclass(frozen=True)
class ImplicitKeyedColumn:
    feature_fqn: str
    column_value: Any


def resolver_raw_output_to_table(
    *,
    resolver: ResolverParsed,
    raw_result: Any,
    graph: ResolvedGraph,
    missing_value_strategy: MissingValueStrategy,
    pkey_values: Optional[list[Any]] = None,
    implicit_keyed_columns: list[ImplicitKeyedColumn] | None = None,
) -> tuple[pa.Table | ChalkError, int]:
    """
    Resolvers can return almost any kind of raw output: here we are converting that anything to a pa.Table.
    Related to resolver_raw_output_to_data_frame, but without polars

    Parameters
    ----------
    resolver
        Our resolver, be aware that StreamResolvers are included
    raw_result
        Beware, can be almost anything
    graph
        ResolvedGraph
    missing_value_strategy
        default, error, etc.
    pkey_values
        just for error messages/debugging
    implicit_keyed_columns
        column name and value for the implicit values supplied by resolver keys. Unused in mapping resolvers
    Returns
    -------
    A table or an error, and the number of rows if not error, else 0.
    """
    table_or_error, num_rows = _resolver_raw_output_to_data_frame_inner(
        resolver=resolver,
        raw_result=raw_result,
        graph=graph,
        missing_value_strategy=missing_value_strategy,
        return_type="pyarrow",
        pkey_values=pkey_values,
    )
    if isinstance(table_or_error, ChalkError):
        return table_or_error, num_rows

    table: pa.Table = table_or_error
    if implicit_keyed_columns is not None and len(table) > 0:
        # only for non-mapping resolvers
        for col in implicit_keyed_columns:
            if col.feature_fqn not in table.column_names:
                table = table.append_column(col.feature_fqn, pa.array([col.column_value] * len(table)))

    # Check early here if the resolver does not have a primary key
    found_pkey = False
    pkey_feature_fqn = None
    for ft in resolver.expected_output_columns.values():
        if (
            is_underlying_scalar(ft)
            and ft.underlying.primary
            and ft.underlying.root_namespace == resolver.output_root_ns
        ):
            # root namespace pkey found
            found_pkey = True
            pkey_feature_fqn = ft.underlying.fqn
            break
    if not found_pkey:
        return ResolverErrors.resolver_missing_pkey_output(resolver.fqn), 0

    # Validate that pkey values are not empty strings (only for string-typed pkeys)
    if pkey_feature_fqn is not None and len(table) > 0 and pkey_feature_fqn in table.column_names:
        import pyarrow.compute as pc

        pkey_column = table.column(pkey_feature_fqn)
        # Only check for empty strings if pkey is a string type
        if pa.types.is_string(pkey_column.type) or pa.types.is_large_string(pkey_column.type):
            has_empty_pkey = pc.any(pc.equal(pkey_column, pa.scalar(""))).as_py()  # ty:ignore[unresolved-attribute]

            if has_empty_pkey:
                return (
                    ChalkError.create(
                        code=ErrorCode.INVALID_QUERY,
                        message="Resolver returned feature set with empty primary key string. Empty pkeys are not valid.",
                        resolver=resolver.fqn,
                    ),
                    0,
                )

    actual_output_fqns = FrozenOrderedSet(fqn for fqn in table.column_names)
    if error := validate_return_columns(
        resolver=resolver,
        graph=graph,
        actual_output_fqns=actual_output_fqns,
    ):
        return error, 0
    return table, num_rows


def validate_return_columns(
    resolver: ResolverParsed,
    graph: ResolvedGraph,
    actual_output_fqns: FrozenOrderedSet[str],
) -> ChalkError | None:
    expected_output_fqns = FrozenOrderedSet(resolver.expected_output_columns.keys())
    input_feature_fqns = FrozenOrderedSet(
        r.root_fqn for r in resolver.expected_output_columns.values() if isinstance(r, InputFeatureType)
    )
    output_observed_at_feature = graph.ts_feature_for_namespace(resolver.output_root_ns)
    assert output_observed_at_feature is not None
    output_observed_at_feature_fqn = output_observed_at_feature.fqn
    if len(actual_output_fqns) == 0:
        return None
    if expected_output_fqns != actual_output_fqns and (actual_output_fqns - expected_output_fqns) != {
        output_observed_at_feature_fqn
    }:
        if isinstance(resolver, StreamResolverParsed):
            # maybe a bit hacky, but we don't need to check input features for stream resolvers, I've decided.
            missing_columns = expected_output_fqns - actual_output_fqns
            if missing_columns.issubset(input_feature_fqns):
                return None

        # If you return the timestamp, you do not need to declare it in the outputs
        return ResolverErrors.wrong_df_columns(
            resolver_fqn=resolver.fqn, expected=expected_output_fqns, actual=actual_output_fqns
        )
    return None
