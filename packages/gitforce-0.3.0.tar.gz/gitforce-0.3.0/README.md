# Gitforce (PyPI Wrapper)

This package exposes `gitforce` through `pip install` for users who prefer Python tooling.

## What It Installs

- `gitforce` command in your Python environment
- bundled Gitforce Node CLI artifact

## Runtime Requirements

- Node.js 20+ (recommended: 24+)
- Salesforce CLI (`sf`)
- GitHub CLI (`gh`)
- `git` available on `PATH`

## Install

```bash
pip install gitforce
gitforce --help
```

## Notes

- This package is a Python wrapper around the main Node CLI.
- If Node.js is missing, running `gitforce` will print an installation error.
