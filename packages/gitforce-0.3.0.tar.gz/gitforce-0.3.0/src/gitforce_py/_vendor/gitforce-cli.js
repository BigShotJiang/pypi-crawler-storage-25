#!/usr/bin/env node
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 509:
/***/ ((__unused_webpack_module, exports, __nccwpck_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.parseGitNameStatus = parseGitNameStatus;
exports.classifyMetadataPath = classifyMetadataPath;
exports.riskForMetadataType = riskForMetadataType;
exports.summarizeChangeImpact = summarizeChangeImpact;
const helpers_1 = __nccwpck_require__(565);
function normalizePath(filePath) {
    return filePath.trim().replace(/\\/g, "/");
}
function parseGitNameStatus(output) {
    const entries = [];
    for (const rawLine of output.split(/\r?\n/)) {
        const line = rawLine.trimEnd();
        if (!line) {
            continue;
        }
        const parts = line.split("\t");
        if (parts.length < 2) {
            continue;
        }
        const rawStatus = parts[0].trim();
        const status = rawStatus.charAt(0).toUpperCase() || "M";
        if ((status === "R" || status === "C") && parts.length >= 3) {
            entries.push({
                status,
                previousPath: normalizePath(parts[1]),
                path: normalizePath(parts[2])
            });
            continue;
        }
        entries.push({
            status,
            path: normalizePath(parts[1])
        });
    }
    return entries;
}
function classifyMetadataPath(filePath) {
    const normalized = normalizePath(filePath);
    let match = normalized.match(/\/classes\/([^/]+)\.cls(?:-meta\.xml)?$/i);
    if (match) {
        return { metadataType: "ApexClass", componentName: match[1] };
    }
    match = normalized.match(/\/triggers\/([^/]+)\.trigger(?:-meta\.xml)?$/i);
    if (match) {
        return { metadataType: "ApexTrigger", componentName: match[1] };
    }
    match = normalized.match(/\/lwc\/([^/]+)\//i);
    if (match) {
        return { metadataType: "LightningComponentBundle", componentName: match[1] };
    }
    match = normalized.match(/\/aura\/([^/]+)\//i);
    if (match) {
        return { metadataType: "AuraDefinitionBundle", componentName: match[1] };
    }
    match = normalized.match(/\/objects\/([^/]+)\/fields\/([^/]+)\.field-meta\.xml$/i);
    if (match) {
        return { metadataType: "CustomField", componentName: `${match[1]}.${match[2]}` };
    }
    match = normalized.match(/\/objects\/([^/]+)\/[^/]+\.object-meta\.xml$/i);
    if (match) {
        return { metadataType: "CustomObject", componentName: match[1] };
    }
    match = normalized.match(/\/layouts\/([^/]+)\.layout-meta\.xml$/i);
    if (match) {
        return { metadataType: "Layout", componentName: match[1] };
    }
    match = normalized.match(/\/permissionSets\/([^/]+)\.permissionset-meta\.xml$/i);
    if (match) {
        return { metadataType: "PermissionSet", componentName: match[1] };
    }
    match = normalized.match(/\/profiles\/([^/]+)\.profile-meta\.xml$/i);
    if (match) {
        return { metadataType: "Profile", componentName: match[1] };
    }
    match = normalized.match(/\/flows\/([^/]+)\.flow-meta\.xml$/i);
    if (match) {
        return { metadataType: "Flow", componentName: match[1] };
    }
    const fallback = normalized.split("/").pop() ?? normalized;
    return { metadataType: "Unknown", componentName: fallback };
}
function riskForMetadataType(metadataType) {
    const normalized = metadataType.trim();
    if (normalized === "CustomObject" ||
        normalized === "CustomField" ||
        normalized === "ApexTrigger" ||
        normalized === "Flow" ||
        normalized === "Profile" ||
        normalized === "PermissionSet") {
        return "high";
    }
    if (normalized === "ApexClass" ||
        normalized === "LightningComponentBundle" ||
        normalized === "AuraDefinitionBundle" ||
        normalized === "Layout") {
        return "medium";
    }
    return "low";
}
function riskRank(level) {
    if (level === "high") {
        return 3;
    }
    if (level === "medium") {
        return 2;
    }
    return 1;
}
function summarizeChangeImpact(entries, trackedPaths, riskThreshold) {
    const paths = entries.map((entry) => entry.path);
    const allowedPaths = new Set((0, helpers_1.filterSfdxPaths)(paths, trackedPaths));
    const thresholdRank = riskRank(riskThreshold);
    const items = [];
    const byRisk = { low: 0, medium: 0, high: 0 };
    const byMetadataType = new Map();
    const suggestedTests = new Set();
    for (const entry of entries) {
        if (!allowedPaths.has(entry.path)) {
            continue;
        }
        const classified = classifyMetadataPath(entry.path);
        const risk = riskForMetadataType(classified.metadataType);
        if (riskRank(risk) < thresholdRank) {
            continue;
        }
        const impactEntry = {
            status: entry.status,
            path: entry.path,
            previousPath: entry.previousPath,
            metadataType: classified.metadataType,
            componentName: classified.componentName,
            risk
        };
        items.push(impactEntry);
        byRisk[risk] += 1;
        byMetadataType.set(impactEntry.metadataType, (byMetadataType.get(impactEntry.metadataType) ?? 0) + 1);
        if (impactEntry.metadataType === "ApexClass" &&
            impactEntry.status !== "D" &&
            !/test$/i.test(impactEntry.componentName)) {
            suggestedTests.add(`${impactEntry.componentName}Test`);
        }
    }
    const sortedTypes = [...byMetadataType.entries()].sort((left, right) => {
        if (right[1] !== left[1]) {
            return right[1] - left[1];
        }
        return left[0].localeCompare(right[0]);
    });
    return {
        items,
        total: items.length,
        byRisk,
        byMetadataType: Object.fromEntries(sortedTypes),
        suggestedTests: [...suggestedTests]
    };
}
//# sourceMappingURL=changeIntelligence.js.map

/***/ }),

/***/ 917:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buildDeployMetadataCompletenessReport = buildDeployMetadataCompletenessReport;
const METADATA_FAMILIES = [
    {
        id: "apex-classes",
        label: "Apex Classes",
        matches: (path) => /\/classes\/[^/]+\.cls(?:-meta\.xml)?$/i.test(path)
    },
    {
        id: "apex-triggers",
        label: "Apex Triggers",
        matches: (path) => /\/triggers\/[^/]+\.trigger(?:-meta\.xml)?$/i.test(path)
    },
    {
        id: "lwc",
        label: "Lightning Web Components",
        matches: (path) => /\/lwc\/[^/]+\//i.test(path)
    },
    {
        id: "aura",
        label: "Aura Bundles",
        matches: (path) => /\/aura\/[^/]+\//i.test(path)
    },
    {
        id: "custom-objects",
        label: "Custom/Standard Object Metadata",
        matches: (path) => /\/objects\/[^/]+\//i.test(path)
    },
    {
        id: "custom-fields",
        label: "Custom Fields",
        matches: (path) => /\/objects\/[^/]+\/fields\/[^/]+\.field-meta\.xml$/i.test(path)
    },
    {
        id: "record-types",
        label: "Record Types",
        matches: (path) => /\/objects\/[^/]+\/recordTypes\/[^/]+\.recordType-meta\.xml$/i.test(path)
    },
    {
        id: "layouts",
        label: "Layouts",
        matches: (path) => /\/layouts\/[^/]+\.layout-meta\.xml$/i.test(path)
    },
    {
        id: "flows",
        label: "Flows",
        matches: (path) => /\/flows\/[^/]+\.flow-meta\.xml$/i.test(path)
    },
    {
        id: "permission-sets",
        label: "Permission Sets",
        matches: (path) => /\/permissionSets\/[^/]+\.permissionset-meta\.xml$/i.test(path)
    },
    {
        id: "profiles",
        label: "Profiles",
        matches: (path) => /\/profiles\/[^/]+\.profile-meta\.xml$/i.test(path)
    },
    {
        id: "custom-metadata",
        label: "Custom Metadata Records",
        matches: (path) => /\/customMetadata\/[^/]+\.md-meta\.xml$/i.test(path)
    },
    {
        id: "custom-labels",
        label: "Custom Labels",
        matches: (path) => /\/labels\/CustomLabels\.labels-meta\.xml$/i.test(path)
    },
    {
        id: "global-value-sets",
        label: "Global Value Sets",
        matches: (path) => /\/globalValueSets\/[^/]+\.globalValueSet-meta\.xml$/i.test(path)
    },
    {
        id: "validation-rules",
        label: "Validation Rules",
        matches: (path) => /\/objects\/[^/]+\/validationRules\/[^/]+\.validationRule-meta\.xml$/i.test(path)
    },
    {
        id: "flexipages",
        label: "FlexiPages",
        matches: (path) => /\/flexipages\/[^/]+\.flexipage-meta\.xml$/i.test(path)
    },
    {
        id: "static-resources",
        label: "Static Resources",
        matches: (path) => /\/staticresources\/[^/]+\.(resource|resource-meta\.xml)$/i.test(path)
    }
];
const REVENUE_OBJECT_DEFINITIONS = [
    { apiName: "Product2", label: "Products", required: true },
    { apiName: "Pricebook2", label: "Pricebooks", required: true },
    { apiName: "PricebookEntry", label: "Pricebook Entries", required: true },
    { apiName: "OpportunityLineItem", label: "Opportunity Products", required: false },
    { apiName: "Quote", label: "Quotes", required: false },
    { apiName: "QuoteLineItem", label: "Quote Line Items", required: false },
    { apiName: "Order", label: "Orders", required: false },
    { apiName: "OrderItem", label: "Order Products", required: false },
    { apiName: "Contract", label: "Contracts", required: false },
    { apiName: "Asset", label: "Assets", required: false }
];
function normalizePath(input) {
    return input.trim().replace(/\\/g, "/");
}
function toFileSet(repoFiles) {
    return new Set(repoFiles.map((entry) => normalizePath(entry)));
}
function hasObjectFolder(fileSet, apiName) {
    const objectPrefix = `/objects/${apiName}/`;
    for (const filePath of fileSet) {
        if (filePath.includes(objectPrefix)) {
            return true;
        }
    }
    return false;
}
function hasSourcePathPrefix(fileSet, sourcePath) {
    const prefix = `${normalizePath(sourcePath).replace(/\/+$/, "")}/`;
    for (const entry of fileSet) {
        if (entry.startsWith(prefix)) {
            return true;
        }
    }
    return false;
}
function hasSelectedMetadataType(selectedItems, metadataTypes) {
    const lookup = new Set(metadataTypes);
    return selectedItems.some((item) => lookup.has(item.metadataType));
}
function buildDeployMetadataCompletenessReport(repoFiles, selectedItems) {
    const fileSet = toFileSet(repoFiles);
    const requiredMissing = [];
    const recommendedMissing = [];
    const coverage = METADATA_FAMILIES.map((definition) => ({
        id: definition.id,
        label: definition.label,
        count: repoFiles.filter((entry) => definition.matches(normalizePath(entry))).length
    }));
    const selectedPaths = new Set(selectedItems.map((item) => normalizePath(item.sourcePath)));
    for (const sourcePath of selectedPaths) {
        if (/\/classes\/[^/]+\.cls$/i.test(sourcePath) && !fileSet.has(`${sourcePath}-meta.xml`)) {
            requiredMissing.push({
                id: `missing-companion:${sourcePath}`,
                label: "Missing Apex class companion metadata",
                severity: "required",
                reason: `${sourcePath}-meta.xml is required for deploy consistency.`,
                missingPaths: [`${sourcePath}-meta.xml`]
            });
        }
        else if (/\/classes\/[^/]+\.cls-meta\.xml$/i.test(sourcePath) &&
            !fileSet.has(sourcePath.replace(/-meta\.xml$/i, ""))) {
            requiredMissing.push({
                id: `missing-companion:${sourcePath}`,
                label: "Missing Apex class source file",
                severity: "required",
                reason: `${sourcePath} has no matching .cls file.`,
                missingPaths: [sourcePath.replace(/-meta\.xml$/i, "")]
            });
        }
        if (/\/triggers\/[^/]+\.trigger$/i.test(sourcePath) &&
            !fileSet.has(`${sourcePath}-meta.xml`)) {
            requiredMissing.push({
                id: `missing-companion:${sourcePath}`,
                label: "Missing Apex trigger companion metadata",
                severity: "required",
                reason: `${sourcePath}-meta.xml is required for deploy consistency.`,
                missingPaths: [`${sourcePath}-meta.xml`]
            });
        }
        else if (/\/triggers\/[^/]+\.trigger-meta\.xml$/i.test(sourcePath) &&
            !fileSet.has(sourcePath.replace(/-meta\.xml$/i, ""))) {
            requiredMissing.push({
                id: `missing-companion:${sourcePath}`,
                label: "Missing Apex trigger source file",
                severity: "required",
                reason: `${sourcePath} has no matching .trigger file.`,
                missingPaths: [sourcePath.replace(/-meta\.xml$/i, "")]
            });
        }
        const lwcMatch = sourcePath.match(/^(.*\/lwc\/([^/]+))$/i);
        if (lwcMatch) {
            const bundlePath = lwcMatch[1];
            const bundleName = lwcMatch[2];
            const scriptPath = `${bundlePath}/${bundleName}.js`;
            const metaPath = `${scriptPath}-meta.xml`;
            const missingPaths = [];
            if (!fileSet.has(scriptPath)) {
                missingPaths.push(scriptPath);
            }
            if (!fileSet.has(metaPath)) {
                missingPaths.push(metaPath);
            }
            if (missingPaths.length > 0) {
                requiredMissing.push({
                    id: `missing-lwc-bundle:${bundlePath}`,
                    label: "Missing LWC bundle entry files",
                    severity: "required",
                    reason: "Lightning Web Component bundles should include both <bundle>.js and <bundle>.js-meta.xml files.",
                    missingPaths
                });
            }
        }
        const auraMatch = sourcePath.match(/^(.*\/aura\/([^/]+))$/i);
        if (auraMatch && !hasSourcePathPrefix(fileSet, sourcePath)) {
            requiredMissing.push({
                id: `missing-aura-bundle:${sourcePath}`,
                label: "Missing Aura bundle files",
                severity: "required",
                reason: "Aura bundle folder was selected but no files were found under it.",
                missingPaths: [sourcePath]
            });
        }
    }
    const revenueObjectPresence = REVENUE_OBJECT_DEFINITIONS.map((definition) => ({
        ...definition,
        present: hasObjectFolder(fileSet, definition.apiName)
    }));
    const revenueSignal = revenueObjectPresence.some((entry) => entry.present) ||
        selectedItems.some((item) => /\/objects\/(Product2|Pricebook2|PricebookEntry)\//i.test(item.sourcePath));
    if (revenueSignal) {
        const missingRequiredRevenueObjects = revenueObjectPresence
            .filter((entry) => entry.required && !entry.present)
            .map((entry) => `objects/${entry.apiName}`);
        if (missingRequiredRevenueObjects.length > 0) {
            requiredMissing.push({
                id: "missing-revenue-baseline",
                label: "Missing revenue object metadata baseline",
                severity: "required",
                reason: "Revenue-style deployments should include Product2, Pricebook2, and PricebookEntry metadata folders.",
                missingPaths: missingRequiredRevenueObjects
            });
        }
        const missingRecommendedRevenueObjects = revenueObjectPresence
            .filter((entry) => !entry.required && !entry.present)
            .map((entry) => `objects/${entry.apiName}`);
        if (missingRecommendedRevenueObjects.length > 0) {
            recommendedMissing.push({
                id: "missing-revenue-recommended",
                label: "Recommended revenue object metadata is missing",
                severity: "recommended",
                reason: "Consider including additional standard object metadata used by sales/order flows to reduce deployment surprises.",
                missingPaths: missingRecommendedRevenueObjects
            });
        }
    }
    const accessSensitiveTypes = [
        "ApexClass",
        "ApexTrigger",
        "LightningComponentBundle",
        "AuraDefinitionBundle",
        "Flow",
        "CustomObject",
        "CustomField"
    ];
    const hasAccessMetadata = coverage.some((entry) => (entry.id === "permission-sets" || entry.id === "profiles") && entry.count > 0);
    if (hasSelectedMetadataType(selectedItems, accessSensitiveTypes) && !hasAccessMetadata) {
        recommendedMissing.push({
            id: "missing-access-metadata",
            label: "No profile/permission set metadata found",
            severity: "recommended",
            reason: "Deploying code or schema without access-control metadata can require post-deploy permission fixes.",
            missingPaths: ["permissionSets/", "profiles/"]
        });
    }
    if (hasSelectedMetadataType(selectedItems, ["CustomObject", "CustomField"]) &&
        !coverage.some((entry) => entry.id === "layouts" && entry.count > 0)) {
        recommendedMissing.push({
            id: "missing-layouts",
            label: "No layout metadata found",
            severity: "recommended",
            reason: "Schema changes often require Layout updates to expose fields to end users.",
            missingPaths: ["layouts/"]
        });
    }
    if (hasSelectedMetadataType(selectedItems, ["CustomObject", "CustomField"]) &&
        !coverage.some((entry) => entry.id === "record-types" && entry.count > 0)) {
        recommendedMissing.push({
            id: "missing-record-types",
            label: "No record type metadata found",
            severity: "recommended",
            reason: "Schema changes may also require Record Type updates to enforce page layouts and picklist behavior.",
            missingPaths: ["objects/*/recordTypes/"]
        });
    }
    return {
        familyCoverage: coverage,
        requiredMissing,
        recommendedMissing
    };
}
//# sourceMappingURL=deployMetadataChecks.js.map

/***/ }),

/***/ 342:
/***/ ((__unused_webpack_module, exports, __nccwpck_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolveDeployScopePaths = resolveDeployScopePaths;
exports.buildDeployPlan = buildDeployPlan;
const changeIntelligence_1 = __nccwpck_require__(509);
const helpers_1 = __nccwpck_require__(565);
function normalizePath(filePath) {
    return filePath.trim().replace(/\\/g, "/");
}
function resolveBundlePath(filePath, bundleType) {
    const normalized = normalizePath(filePath);
    const marker = `/${bundleType}/`;
    const markerIndex = normalized.toLowerCase().indexOf(marker);
    if (markerIndex < 0) {
        return undefined;
    }
    const suffix = normalized.slice(markerIndex + marker.length);
    const bundleName = suffix.split("/")[0]?.trim();
    if (!bundleName) {
        return undefined;
    }
    return `${normalized.slice(0, markerIndex)}${marker}${bundleName}`;
}
function resolveDeployScopePaths(filePath) {
    const normalized = normalizePath(filePath);
    const scope = new Set();
    const lwcBundle = resolveBundlePath(normalized, "lwc");
    if (lwcBundle) {
        scope.add(lwcBundle);
        return [...scope];
    }
    const auraBundle = resolveBundlePath(normalized, "aura");
    if (auraBundle) {
        scope.add(auraBundle);
        return [...scope];
    }
    scope.add(normalized);
    if (normalized.endsWith(".cls")) {
        scope.add(`${normalized}-meta.xml`);
    }
    else if (normalized.endsWith(".cls-meta.xml")) {
        scope.add(normalized.replace(/-meta\.xml$/i, ""));
    }
    if (normalized.endsWith(".trigger")) {
        scope.add(`${normalized}-meta.xml`);
    }
    else if (normalized.endsWith(".trigger-meta.xml")) {
        scope.add(normalized.replace(/-meta\.xml$/i, ""));
    }
    return [...scope];
}
function buildDeployPlan(entries, trackedPaths, trackedMetadataTypes) {
    const allowedPaths = new Set((0, helpers_1.filterSfdxPaths)(entries.map((entry) => entry.path), trackedPaths));
    const trackedTypes = new Set(trackedMetadataTypes.map((entry) => entry.trim()).filter(Boolean));
    const bySourcePath = new Map();
    const deleted = [];
    const skippedUnknown = new Set();
    for (const entry of entries) {
        const normalizedPath = normalizePath(entry.path);
        if (!allowedPaths.has(normalizedPath)) {
            continue;
        }
        const classified = (0, changeIntelligence_1.classifyMetadataPath)(normalizedPath);
        if (classified.metadataType === "Unknown") {
            skippedUnknown.add(normalizedPath);
            continue;
        }
        if (trackedTypes.size > 0 && !trackedTypes.has(classified.metadataType)) {
            continue;
        }
        if (entry.status === "D") {
            deleted.push({
                path: normalizedPath,
                metadataType: classified.metadataType,
                componentName: classified.componentName,
                status: entry.status
            });
            continue;
        }
        const scopes = resolveDeployScopePaths(normalizedPath);
        for (const scope of scopes) {
            const existing = bySourcePath.get(scope);
            if (!existing) {
                bySourcePath.set(scope, {
                    sourcePath: scope,
                    metadataType: classified.metadataType,
                    componentName: classified.componentName,
                    statuses: [entry.status],
                    files: [normalizedPath]
                });
                continue;
            }
            if (!existing.statuses.includes(entry.status)) {
                existing.statuses.push(entry.status);
            }
            if (!existing.files.includes(normalizedPath)) {
                existing.files.push(normalizedPath);
            }
        }
    }
    const items = [...bySourcePath.values()]
        .map((item) => ({
        ...item,
        statuses: [...item.statuses].sort(),
        files: [...item.files].sort()
    }))
        .sort((left, right) => left.sourcePath.localeCompare(right.sourcePath));
    const sortedDeleted = [...deleted].sort((left, right) => left.path.localeCompare(right.path));
    return {
        items,
        deleted: sortedDeleted,
        skippedUnknown: [...skippedUnknown].sort()
    };
}
//# sourceMappingURL=deployPlan.js.map

/***/ }),

/***/ 48:
/***/ ((__unused_webpack_module, exports, __nccwpck_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getRepoRoot = getRepoRoot;
exports.isGitRepository = isGitRepository;
exports.initRepository = initRepository;
exports.getRemoteUrl = getRemoteUrl;
exports.remoteExists = remoteExists;
exports.addRemote = addRemote;
exports.setRemoteUrl = setRemoteUrl;
exports.getCurrentBranch = getCurrentBranch;
exports.getChangedFiles = getChangedFiles;
exports.branchExists = branchExists;
exports.createBranch = createBranch;
exports.stageFiles = stageFiles;
exports.commit = commit;
exports.pushBranch = pushBranch;
exports.parseGitHubRemote = parseGitHubRemote;
const helpers_1 = __nccwpck_require__(565);
const shell_1 = __nccwpck_require__(274);
async function runGit(cwd, args) {
    const { stdout } = await (0, shell_1.runCommand)("git", args, cwd);
    return stdout;
}
async function getRepoRoot(cwd) {
    return runGit(cwd, ["rev-parse", "--show-toplevel"]);
}
async function isGitRepository(cwd) {
    try {
        await runGit(cwd, ["rev-parse", "--is-inside-work-tree"]);
        return true;
    }
    catch {
        return false;
    }
}
async function initRepository(cwd) {
    await runGit(cwd, ["init"]);
}
async function getRemoteUrl(cwd, remote) {
    return runGit(cwd, ["remote", "get-url", remote]);
}
async function remoteExists(cwd, remote) {
    try {
        await getRemoteUrl(cwd, remote);
        return true;
    }
    catch {
        return false;
    }
}
async function addRemote(cwd, remote, remoteUrl) {
    await runGit(cwd, ["remote", "add", remote, remoteUrl]);
}
async function setRemoteUrl(cwd, remote, remoteUrl) {
    await runGit(cwd, ["remote", "set-url", remote, remoteUrl]);
}
async function getCurrentBranch(cwd) {
    return runGit(cwd, ["rev-parse", "--abbrev-ref", "HEAD"]);
}
async function getChangedFiles(cwd) {
    const porcelain = await runGit(cwd, ["status", "--porcelain"]);
    return (0, helpers_1.parseGitStatusPorcelain)(porcelain);
}
async function branchExists(cwd, branch) {
    try {
        await runGit(cwd, ["show-ref", "--verify", `refs/heads/${branch}`]);
        return true;
    }
    catch {
        return false;
    }
}
async function createBranch(cwd, branch) {
    await runGit(cwd, ["checkout", "-b", branch]);
}
async function stageFiles(cwd, files) {
    if (files.length === 0) {
        return;
    }
    await runGit(cwd, ["add", "--", ...files]);
}
async function commit(cwd, message) {
    await runGit(cwd, ["commit", "-m", message]);
}
async function pushBranch(cwd, remote, branch) {
    await runGit(cwd, ["push", "-u", remote, branch]);
}
function parseGitHubRemote(url) {
    const trimmed = url.trim();
    const patterns = [
        /^git@github\.com:(?<owner>[^/]+)\/(?<repo>[^/]+?)(?:\.git)?$/,
        /^https:\/\/github\.com\/(?<owner>[^/]+)\/(?<repo>[^/]+?)(?:\.git)?$/,
        /^ssh:\/\/git@github\.com\/(?<owner>[^/]+)\/(?<repo>[^/]+?)(?:\.git)?$/
    ];
    for (const pattern of patterns) {
        const match = trimmed.match(pattern);
        if (match?.groups?.owner && match.groups.repo) {
            return {
                owner: match.groups.owner,
                repo: match.groups.repo
            };
        }
    }
    throw new Error(`Unsupported git remote URL: ${url}. Only GitHub remotes are supported.`);
}
//# sourceMappingURL=git.js.map

/***/ }),

/***/ 834:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buildDefaultBasicTestsConfig = buildDefaultBasicTestsConfig;
exports.normalizeBasicTestsConfig = normalizeBasicTestsConfig;
exports.getBasicTestsConfigPath = getBasicTestsConfigPath;
exports.readBasicTestsConfig = readBasicTestsConfig;
exports.writeBasicTestsConfig = writeBasicTestsConfig;
exports.bootstrapBasicTestsConfig = bootstrapBasicTestsConfig;
exports.renderBasicApexTest = renderBasicApexTest;
exports.writeGeneratedBasicApexTest = writeGeneratedBasicApexTest;
const fs_1 = __nccwpck_require__(896);
const path = __importStar(__nccwpck_require__(928));
const DEFAULT_CLASS_NAME = "GitforceDataQualityBuiltInTest";
function sanitizeIdentifier(value) {
    const cleaned = value.replace(/[^A-Za-z0-9_]/g, "_");
    if (!cleaned) {
        return "unnamed";
    }
    if (/^[0-9]/.test(cleaned)) {
        return `t_${cleaned}`;
    }
    return cleaned;
}
function escapeApexString(value) {
    return value.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}
function buildDefaultBasicTestsConfig() {
    return {
        version: 1,
        generatedClassName: DEFAULT_CLASS_NAME,
        tests: [
            {
                id: "account_name_not_null",
                enabled: false,
                type: "not_null",
                objectApiName: "Account",
                fieldApiName: "Name"
            },
            {
                id: "contact_email_unique",
                enabled: false,
                type: "unique",
                objectApiName: "Contact",
                fieldApiName: "Email"
            }
        ]
    };
}
function normalizeType(value) {
    if (value === "unique") {
        return "unique";
    }
    return "not_null";
}
function normalizeBasicTestsConfig(value) {
    const parsed = (typeof value === "object" && value ? value : {});
    const testsRaw = Array.isArray(parsed.tests) ? parsed.tests : [];
    const generatedClassName = typeof parsed.generatedClassName === "string" && parsed.generatedClassName.trim()
        ? sanitizeIdentifier(parsed.generatedClassName.trim())
        : DEFAULT_CLASS_NAME;
    const tests = testsRaw
        .filter((entry) => typeof entry === "object" && !!entry)
        .map((entry) => {
        const id = typeof entry.id === "string" && entry.id.trim()
            ? sanitizeIdentifier(entry.id.trim())
            : "";
        const objectApiName = typeof entry.objectApiName === "string" ? entry.objectApiName.trim() : "";
        const fieldApiName = typeof entry.fieldApiName === "string" ? entry.fieldApiName.trim() : "";
        const whereClause = typeof entry.whereClause === "string" && entry.whereClause.trim()
            ? entry.whereClause.trim()
            : undefined;
        return {
            id,
            enabled: entry.enabled === true,
            type: normalizeType(entry.type),
            objectApiName,
            fieldApiName,
            whereClause
        };
    })
        .filter((entry) => entry.id && entry.objectApiName && entry.fieldApiName);
    return {
        version: 1,
        generatedClassName,
        tests
    };
}
function parseConfig(raw) {
    return normalizeBasicTestsConfig(JSON.parse(raw));
}
function getBasicTestsConfigPath(workspacePath, relativePath) {
    return path.join(workspacePath, relativePath);
}
async function readBasicTestsConfig(workspacePath, relativePath) {
    const configPath = getBasicTestsConfigPath(workspacePath, relativePath);
    try {
        const raw = await fs_1.promises.readFile(configPath, "utf8");
        return parseConfig(raw);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (/enoent/i.test(message)) {
            return undefined;
        }
        throw new Error(`Failed to parse ${relativePath}: ${message}`);
    }
}
async function writeBasicTestsConfig(workspacePath, relativePath, config) {
    const configPath = getBasicTestsConfigPath(workspacePath, relativePath);
    await fs_1.promises.mkdir(path.dirname(configPath), { recursive: true });
    await fs_1.promises.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, "utf8");
    return configPath;
}
async function bootstrapBasicTestsConfig(workspacePath, relativePath) {
    const configPath = getBasicTestsConfigPath(workspacePath, relativePath);
    try {
        const raw = await fs_1.promises.readFile(configPath, "utf8");
        try {
            return parseConfig(raw);
        }
        catch {
            const defaults = buildDefaultBasicTestsConfig();
            await writeBasicTestsConfig(workspacePath, relativePath, defaults);
            return defaults;
        }
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (!/enoent/i.test(message)) {
            throw error;
        }
    }
    const defaults = buildDefaultBasicTestsConfig();
    await writeBasicTestsConfig(workspacePath, relativePath, defaults);
    return defaults;
}
function buildTestMethod(testCase) {
    const methodName = sanitizeIdentifier(`test_${testCase.id}`);
    const whereSuffix = testCase.whereClause ? ` AND (${testCase.whereClause})` : "";
    const objectName = testCase.objectApiName;
    const fieldName = testCase.fieldApiName;
    if (testCase.type === "unique") {
        const soql = `SELECT ${fieldName} value FROM ${objectName} WHERE ${fieldName} != null${whereSuffix} GROUP BY ${fieldName} HAVING COUNT(Id) > 1 LIMIT 1`;
        return [
            `    @IsTest`,
            `    static void ${methodName}() {`,
            `        List<AggregateResult> duplicates = Database.query('${escapeApexString(soql)}');`,
            `        System.assertEquals(0, duplicates.size(), 'Duplicate values found for ${objectName}.${fieldName}.');`,
            `    }`
        ].join("\n");
    }
    const soql = `SELECT COUNT() FROM ${objectName} WHERE ${fieldName} = null${whereSuffix}`;
    return [
        `    @IsTest`,
        `    static void ${methodName}() {`,
        `        Integer violations = Database.countQuery('${escapeApexString(soql)}');`,
        `        System.assertEquals(0, violations, 'Null values found for ${objectName}.${fieldName}.');`,
        `    }`
    ].join("\n");
}
function renderBasicApexTest(config) {
    const className = sanitizeIdentifier(config.generatedClassName || DEFAULT_CLASS_NAME);
    const enabledTests = config.tests.filter((entry) => entry.enabled);
    const methodBlocks = enabledTests.length > 0
        ? enabledTests.map((testCase) => buildTestMethod(testCase)).join("\n\n")
        : [
            "    @IsTest",
            "    static void test_no_enabled_basic_tests() {",
            "        System.assert(true, 'No enabled basic tests configured in gitforce-project.json basicTests.tests.');",
            "    }"
        ].join("\n");
    const apexClassSource = [
        "@IsTest",
        `private class ${className} {`,
        methodBlocks,
        "}"
    ].join("\n");
    const apexMetaSource = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<ApexClass xmlns="http://soap.sforce.com/2006/04/metadata">',
        "  <apiVersion>63.0</apiVersion>",
        "  <status>Active</status>",
        "</ApexClass>"
    ].join("\n");
    return {
        className,
        apexClassSource,
        apexMetaSource
    };
}
async function writeGeneratedBasicApexTest(workspacePath, config) {
    const rendered = renderBasicApexTest(config);
    const classesDir = path.join(workspacePath, "force-app", "main", "default", "classes");
    await fs_1.promises.mkdir(classesDir, { recursive: true });
    const classPath = path.join(classesDir, `${rendered.className}.cls`);
    const metaPath = path.join(classesDir, `${rendered.className}.cls-meta.xml`);
    await fs_1.promises.writeFile(classPath, `${rendered.apexClassSource}\n`, "utf8");
    await fs_1.promises.writeFile(metaPath, `${rendered.apexMetaSource}\n`, "utf8");
    return {
        classPath,
        metaPath,
        className: rendered.className
    };
}
//# sourceMappingURL=gitforceBasicTests.js.map

/***/ }),

/***/ 335:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
const child_process_1 = __nccwpck_require__(317);
const fs_1 = __nccwpck_require__(896);
const os = __importStar(__nccwpck_require__(857));
const path = __importStar(__nccwpck_require__(928));
const promises_1 = __nccwpck_require__(232);
const gitforceCore_1 = __nccwpck_require__(58);
const gitforceCoreWorkflows_1 = __nccwpck_require__(518);
const gitforceBasicTests_1 = __nccwpck_require__(834);
const gitforceLocalConfig_1 = __nccwpck_require__(932);
const gitforceValidation_1 = __nccwpck_require__(510);
const git_1 = __nccwpck_require__(48);
const repoSyncConfig_1 = __nccwpck_require__(59);
const shell_1 = __nccwpck_require__(274);
const changeIntelligence_1 = __nccwpck_require__(509);
const deployPlan_1 = __nccwpck_require__(342);
const deployMetadataChecks_1 = __nccwpck_require__(917);
const METADATA_TYPE_ALIASES = {
    apex: "ApexClass",
    apexclass: "ApexClass",
    classes: "ApexClass",
    trigger: "ApexTrigger",
    triggers: "ApexTrigger",
    lwc: "LightningComponentBundle",
    lwcs: "LightningComponentBundle",
    lightningcomponentbundle: "LightningComponentBundle",
    aura: "AuraDefinitionBundle",
    auradefinitionbundle: "AuraDefinitionBundle",
    object: "CustomObject",
    objects: "CustomObject",
    customobject: "CustomObject",
    field: "CustomField",
    fields: "CustomField",
    customfield: "CustomField",
    flow: "Flow",
    flows: "Flow",
    permissionset: "PermissionSet",
    permissionsets: "PermissionSet"
};
const CONFIG_PATH_ALIASES = {
    deploy: "deploy.mode",
    "deploy-mode": "deploy.mode",
    "drift-enabled": "drift.enabled",
    "drift-interval-minutes": "drift.intervalMinutes",
    "drift-mode": "drift.mode",
    "destructive-enabled": "destructiveChanges.enabled",
    "delete-intent-path": "destructiveChanges.intentPath",
    "analyzer-scope": "codeAnalyzer.scope",
    "analyzer-enabled": "codeAnalyzer.enabled",
    "analyzer-severity": "codeAnalyzer.failOnSeverity",
    "validation-scope": "validation.scope",
    "validate-scope": "validation.scope",
    "metadata-types": "tracked.metadataTypes",
    "tracked-paths": "tracked.paths",
    "target-org-alias": "environments.targetOrgAlias",
    "base-branch": "repository.baseBranch",
    "allow-auto-merge": "merge.allowAutoMerge",
    "auto-merge-on-checks-pass": "merge.autoMergeOnChecksPass",
    "require-pull-request": "merge.requirePullRequest",
    "change-intelligence-enabled": "changeIntelligence.enabled",
    "change-intelligence-risk-threshold": "changeIntelligence.riskThreshold",
    "change-intelligence-comment-on-pr": "changeIntelligence.commentOnPr",
    "change-intelligence-max-summary-items": "changeIntelligence.maxPrSummaryItems",
    "promotion-auto-promote": "promotion.autoPromote",
    "promotion-development-branch": "promotion.lanes.development.branch",
    "promotion-sandbox-branch": "promotion.lanes.sandbox.branch",
    "promotion-production-branch": "promotion.lanes.production.branch",
    "policy-default-profile": "policyProfiles.defaultProfile",
    "orchestration-enabled": "orchestration.enabled",
    "orchestration-max-concurrent-per-lane": "orchestration.maxConcurrentPerLane",
    "orchestration-publish-run-summary": "orchestration.publishRunSummary"
};
function parseOptions(args) {
    return {
        strict: args.includes("--strict")
    };
}
function parseArgs(args) {
    const flags = new Map();
    const positionals = [];
    for (let index = 0; index < args.length; index++) {
        const token = args[index];
        if (!token.startsWith("--")) {
            positionals.push(token);
            continue;
        }
        if (token.startsWith("--no-")) {
            flags.set(token.slice(5), false);
            continue;
        }
        const equalsIndex = token.indexOf("=");
        if (equalsIndex > 0) {
            const key = token.slice(2, equalsIndex);
            const value = token.slice(equalsIndex + 1);
            flags.set(key, value);
            continue;
        }
        const key = token.slice(2);
        const next = args[index + 1];
        if (next && !next.startsWith("--")) {
            flags.set(key, next);
            index += 1;
            continue;
        }
        flags.set(key, true);
    }
    return { flags, positionals };
}
function getFlagString(parsed, key) {
    const value = parsed.flags.get(key);
    if (typeof value !== "string") {
        return undefined;
    }
    const trimmed = value.trim();
    return trimmed || undefined;
}
function getFlagBoolean(parsed, key, defaultValue) {
    const value = parsed.flags.get(key);
    if (value === undefined) {
        return defaultValue;
    }
    if (typeof value === "boolean") {
        return value;
    }
    const normalized = value.trim().toLowerCase();
    if (["1", "true", "yes", "y", "on"].includes(normalized)) {
        return true;
    }
    if (["0", "false", "no", "n", "off"].includes(normalized)) {
        return false;
    }
    return defaultValue;
}
function getFlagNumber(parsed, key) {
    const value = getFlagString(parsed, key);
    if (!value) {
        return undefined;
    }
    const parsedNumber = Number(value);
    if (!Number.isFinite(parsedNumber)) {
        return undefined;
    }
    return parsedNumber;
}
function parseCsvList(input) {
    if (!input) {
        return [];
    }
    const values = input
        .split(",")
        .map((entry) => entry.trim())
        .filter(Boolean);
    return [...new Set(values)];
}
function normalizeMetadataTypes(input, fallback) {
    if (!input || input.length === 0) {
        return fallback;
    }
    const normalized = input
        .map((entry) => entry.trim())
        .filter(Boolean)
        .map((entry) => {
        const key = entry.toLowerCase();
        return METADATA_TYPE_ALIASES[key] ?? entry;
    });
    return [...new Set(normalized)];
}
function normalizeEnvironment(value) {
    if (value === "sandbox" || value === "production") {
        return value;
    }
    return "development";
}
function normalizeScopeModeFlag(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (["changed", "updates", "update", "delta"].includes(normalized)) {
        return "changed";
    }
    if (["full", "all"].includes(normalized)) {
        return "full";
    }
    return undefined;
}
function normalizeTestLevelFlag(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (["runlocaltests", "local", "run-local-tests"].includes(normalized)) {
        return "RunLocalTests";
    }
    if (["runalltestsinorg", "all", "org", "run-all-tests-in-org"].includes(normalized)) {
        return "RunAllTestsInOrg";
    }
    if (["runspecifiedtests", "specified", "run-specified-tests"].includes(normalized)) {
        return "RunSpecifiedTests";
    }
    return undefined;
}
function normalizeApexTestResultFormat(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === "human" || normalized === "tap" || normalized === "junit" || normalized === "json") {
        return normalized;
    }
    return undefined;
}
function normalizeDeploymentSuiteMode(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === "report" || normalized === "preview" || normalized === "plan") {
        return "report";
    }
    if (normalized === "validate" || normalized === "check") {
        return "validate";
    }
    if (normalized === "deploy" || normalized === "apply" || normalized === "start") {
        return "deploy";
    }
    return undefined;
}
function toObject(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return undefined;
    }
    return value;
}
function toArray(value) {
    return Array.isArray(value) ? value : [];
}
function parseNumber(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
        return value;
    }
    if (typeof value === "string") {
        const trimmed = value.trim();
        if (!trimmed) {
            return undefined;
        }
        const parsed = Number(trimmed);
        if (Number.isFinite(parsed)) {
            return parsed;
        }
    }
    return undefined;
}
function parseInteger(value, fallback = 0) {
    const parsed = parseNumber(value);
    if (parsed === undefined) {
        return fallback;
    }
    return Number.isInteger(parsed) ? parsed : Math.round(parsed);
}
function parseString(value) {
    if (typeof value !== "string") {
        return undefined;
    }
    const trimmed = value.trim();
    return trimmed || undefined;
}
function parsePercent(value) {
    if (typeof value === "number" && Number.isFinite(value)) {
        return value;
    }
    if (typeof value !== "string") {
        return undefined;
    }
    const normalized = value.replace(/%/g, "").trim();
    if (!normalized) {
        return undefined;
    }
    const parsed = Number(normalized);
    if (!Number.isFinite(parsed)) {
        return undefined;
    }
    return parsed;
}
function formatPercent(value) {
    const rounded = Math.round(value * 100) / 100;
    return `${rounded.toFixed(2).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1")}%`;
}
function formatTimestampShort(isoTimestamp) {
    const timestamp = new Date(isoTimestamp);
    if (Number.isNaN(timestamp.getTime())) {
        return isoTimestamp;
    }
    return timestamp.toISOString().replace("T", " ").replace(".000Z", "Z");
}
function tryParseJson(raw) {
    if (!raw) {
        return undefined;
    }
    const trimmed = raw.trim();
    if (!trimmed) {
        return undefined;
    }
    const candidates = [trimmed];
    const firstBrace = trimmed.indexOf("{");
    if (firstBrace > 0) {
        candidates.push(trimmed.slice(firstBrace));
    }
    for (const candidate of candidates) {
        if (!candidate.startsWith("{") && !candidate.startsWith("[")) {
            continue;
        }
        try {
            return JSON.parse(candidate);
        }
        catch {
            // continue
        }
    }
    return undefined;
}
function parseCoverageSnapshotFromSfPayload(payload, orgAlias) {
    const root = toObject(payload);
    if (!root) {
        return undefined;
    }
    const result = toObject(root.result) ?? root;
    const summary = toObject(result.summary);
    if (!summary) {
        return undefined;
    }
    const coverageRoot = toObject(result.coverage);
    const coverageSummary = toObject(coverageRoot?.summary);
    const coverageRowsRaw = coverageRoot !== undefined ? toArray(coverageRoot.coverage) : toArray(result.coverage);
    const classCoverage = [];
    for (const entry of coverageRowsRaw) {
        const row = toObject(entry);
        if (!row) {
            continue;
        }
        const name = parseString(row.name);
        if (!name) {
            continue;
        }
        const totalLines = Math.max(0, parseInteger(row.totalLines, 0));
        const totalCovered = Math.max(0, parseInteger(row.totalCovered, 0));
        const coveredPercentFromRow = parsePercent(row.coveredPercent);
        const coveredPercent = coveredPercentFromRow !== undefined
            ? coveredPercentFromRow
            : totalLines > 0
                ? (totalCovered / totalLines) * 100
                : 0;
        classCoverage.push({
            name,
            totalLines,
            totalCovered,
            coveredPercent
        });
    }
    classCoverage.sort((a, b) => a.coveredPercent - b.coveredPercent || a.name.localeCompare(b.name));
    const testRunId = parseString(summary.testRunId) || parseString(result.testRunId);
    const orgWideCoverage = parsePercent(coverageSummary?.orgWideCoverage) ??
        parsePercent(summary.orgWideCoverage) ??
        0;
    const testRunCoverage = parsePercent(coverageSummary?.testRunCoverage) ??
        parsePercent(summary.testRunCoverage) ??
        0;
    const totalLines = parseInteger(coverageSummary?.totalLines, 0) ||
        classCoverage.reduce((total, entry) => total + entry.totalLines, 0);
    const coveredLines = parseInteger(coverageSummary?.coveredLines, 0) ||
        classCoverage.reduce((total, entry) => total + entry.totalCovered, 0);
    return {
        timestamp: new Date().toISOString(),
        orgAlias,
        testRunId,
        outcome: parseString(summary.outcome) || "Completed",
        statusCode: parseNumber(root.status),
        testsRan: parseInteger(summary.testsRan, 0),
        passing: parseInteger(summary.passing, 0),
        failing: parseInteger(summary.failing, 0),
        skipped: parseInteger(summary.skipped, 0),
        orgWideCoverage,
        testRunCoverage,
        totalLines,
        coveredLines,
        classCoverage
    };
}
async function runSfJsonCommand(workspacePath, args, options) {
    const fullArgs = [...args, "--json"];
    try {
        const { stdout } = await (0, shell_1.runCommand)("sf", fullArgs, workspacePath, options);
        const parsed = tryParseJson(stdout);
        if (parsed !== undefined) {
            return parsed;
        }
        throw new Error(`Could not parse JSON output from: sf ${fullArgs.join(" ")}`);
    }
    catch (error) {
        if (error instanceof shell_1.CommandExecutionError) {
            const parsed = tryParseJson(error.stdout) ?? tryParseJson(error.stderr);
            if (parsed !== undefined) {
                return parsed;
            }
        }
        throw error;
    }
}
async function readCoverageHistory(historyPath) {
    try {
        const raw = await fs_1.promises.readFile(historyPath, "utf8");
        const parsed = JSON.parse(raw);
        const snapshotsRaw = toArray(parsed.snapshots);
        const snapshots = [];
        for (const entry of snapshotsRaw) {
            const typed = entry;
            if (!typed || typeof typed !== "object") {
                continue;
            }
            if (typeof typed.timestamp !== "string" || typeof typed.orgAlias !== "string") {
                continue;
            }
            snapshots.push(typed);
        }
        return {
            version: 1,
            snapshots
        };
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (/enoent/i.test(message)) {
            return {
                version: 1,
                snapshots: []
            };
        }
        throw new Error(`Failed to read coverage history file (${historyPath}): ${message}`);
    }
}
async function writeCoverageHistory(historyPath, history) {
    await fs_1.promises.mkdir(path.dirname(historyPath), { recursive: true });
    await fs_1.promises.writeFile(historyPath, `${JSON.stringify(history, null, 2)}\n`, "utf8");
}
function renderCoverageSnapshot(snapshot, classNameFilter, topCount) {
    const lines = [
        "Coverage summary",
        `- Org alias: ${snapshot.orgAlias}`,
        `- Test run ID: ${snapshot.testRunId || "<unknown>"}`,
        `- Outcome: ${snapshot.outcome}`,
        `- Tests: ${snapshot.testsRan} ran (${snapshot.passing} passing, ${snapshot.failing} failing, ${snapshot.skipped} skipped)`,
        `- Org-wide coverage: ${formatPercent(snapshot.orgWideCoverage)}`,
        `- Test-run coverage: ${formatPercent(snapshot.testRunCoverage)}`,
        `- Covered lines: ${snapshot.coveredLines}/${snapshot.totalLines}`,
        `- Classes in coverage result: ${snapshot.classCoverage.length}`
    ];
    if (classNameFilter) {
        const lookup = classNameFilter.trim().toLowerCase();
        const matched = snapshot.classCoverage.find((entry) => entry.name.toLowerCase() === lookup);
        lines.push("");
        lines.push(`Class coverage lookup: ${classNameFilter}`);
        if (!matched) {
            lines.push("- Not found in returned coverage payload.");
        }
        else {
            lines.push(`- ${matched.name}: ${formatPercent(matched.coveredPercent)} (${matched.totalCovered}/${matched.totalLines})`);
        }
        return lines;
    }
    if (snapshot.classCoverage.length > 0 && topCount > 0) {
        lines.push("");
        lines.push(`Lowest coverage classes (top ${Math.min(topCount, snapshot.classCoverage.length)}):`);
        for (const entry of snapshot.classCoverage.slice(0, topCount)) {
            lines.push(`- ${entry.name}: ${formatPercent(entry.coveredPercent)} (${entry.totalCovered}/${entry.totalLines})`);
        }
    }
    return lines;
}
function renderCoverageTrend(snapshots, last) {
    const rows = snapshots.slice(-last);
    const lines = [`Coverage trend (last ${rows.length} run${rows.length === 1 ? "" : "s"}):`];
    for (let index = 0; index < rows.length; index++) {
        const current = rows[index];
        const previous = index > 0 ? rows[index - 1] : undefined;
        const delta = previous !== undefined
            ? `${current.orgWideCoverage - previous.orgWideCoverage >= 0 ? "+" : ""}${(Math.round((current.orgWideCoverage - previous.orgWideCoverage) * 100) / 100).toFixed(2)}`
            : "n/a";
        lines.push(`- ${formatTimestampShort(current.timestamp)} | ${current.orgAlias} | org=${formatPercent(current.orgWideCoverage)} | run=${formatPercent(current.testRunCoverage)} | delta=${delta === "n/a" ? delta : `${delta}%`} | outcome=${current.outcome}`);
    }
    return lines;
}
function normalizeRiskThresholdFlag(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === "low" || normalized === "medium" || normalized === "high") {
        return normalized;
    }
    return undefined;
}
function normalizePolicyProfileNameFlag(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === "relaxed" || normalized === "balanced" || normalized === "strict") {
        return normalized;
    }
    return undefined;
}
function normalizePromotionLane(value) {
    if (!value) {
        return undefined;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === "development" || normalized === "sandbox" || normalized === "production") {
        return normalized;
    }
    return undefined;
}
function promotionLaneOrder(lane) {
    if (lane === "development") {
        return 1;
    }
    if (lane === "sandbox") {
        return 2;
    }
    return 3;
}
function normalizeConfigPath(input) {
    const raw = input.trim();
    if (!raw) {
        throw new Error("Config key path cannot be empty.");
    }
    const alias = CONFIG_PATH_ALIASES[raw.toLowerCase()];
    return alias ?? raw;
}
function parseConfigValue(raw) {
    const trimmed = raw.trim();
    if (!trimmed) {
        return "";
    }
    const lowered = trimmed.toLowerCase();
    if (lowered === "true") {
        return true;
    }
    if (lowered === "false") {
        return false;
    }
    if (lowered === "null") {
        return null;
    }
    if (/^-?\d+(\.\d+)?$/.test(trimmed)) {
        const parsedNumber = Number(trimmed);
        if (Number.isFinite(parsedNumber)) {
            return parsedNumber;
        }
    }
    if ((trimmed.startsWith("{") && trimmed.endsWith("}")) ||
        (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
        try {
            return JSON.parse(trimmed);
        }
        catch {
            // fall through to string value
        }
    }
    return trimmed;
}
function normalizeStringArrayInput(value, label, normalizeEntry) {
    let entries = [];
    if (Array.isArray(value)) {
        entries = value
            .filter((entry) => typeof entry === "string")
            .map((entry) => entry.trim())
            .filter(Boolean);
    }
    else if (typeof value === "string") {
        entries = parseCsvList(value);
    }
    else {
        throw new Error(`${label} must be a comma-separated string or JSON string array.`);
    }
    const normalized = normalizeEntry ? entries.map((entry) => normalizeEntry(entry)) : entries;
    return [...new Set(normalized.filter(Boolean))];
}
function validateConfigUpdate(path, value) {
    switch (path) {
        case "deploy.mode": {
            if (typeof value !== "string" ||
                !["manual-promote", "auto-integration", "auto-target"].includes(value)) {
                throw new Error('deploy.mode must be one of: "manual-promote", "auto-integration", "auto-target".');
            }
            return value;
        }
        case "drift.mode": {
            if (typeof value !== "string" || !["pr-only", "pr-automerge", "alert-only"].includes(value)) {
                throw new Error('drift.mode must be one of: "pr-only", "pr-automerge", "alert-only".');
            }
            return value;
        }
        case "drift.enabled":
        case "destructiveChanges.enabled":
        case "merge.allowAutoMerge":
        case "merge.autoMergeOnChecksPass":
        case "merge.requirePullRequest":
        case "codeAnalyzer.enabled":
        case "changeIntelligence.enabled":
        case "changeIntelligence.commentOnPr":
        case "promotion.autoPromote":
        case "orchestration.enabled":
        case "orchestration.publishRunSummary": {
            if (typeof value !== "boolean") {
                throw new Error(`${path} must be true or false.`);
            }
            return value;
        }
        case "drift.intervalMinutes": {
            if (typeof value !== "number" || !Number.isFinite(value)) {
                throw new Error("drift.intervalMinutes must be a number.");
            }
            return (0, repoSyncConfig_1.normalizeSyncIntervalMinutes)(value);
        }
        case "codeAnalyzer.failOnSeverity": {
            if (typeof value !== "number" ||
                !Number.isInteger(value) ||
                value < 1 ||
                value > 5) {
                throw new Error("codeAnalyzer.failOnSeverity must be an integer between 1 and 5.");
            }
            return value;
        }
        case "changeIntelligence.maxPrSummaryItems":
        case "orchestration.maxConcurrentPerLane": {
            if (typeof value !== "number" || !Number.isInteger(value) || value < 1) {
                throw new Error(`${path} must be a positive integer.`);
            }
            return value;
        }
        case "governance.requiredApprovingReviewCount": {
            if (typeof value !== "number" ||
                !Number.isInteger(value) ||
                value < 0 ||
                value > 6) {
                throw new Error("governance.requiredApprovingReviewCount must be an integer between 0 and 6.");
            }
            return value;
        }
        case "validation.scope":
        case "codeAnalyzer.scope": {
            if (typeof value !== "string") {
                throw new Error(`${path} must be "changed" or "full".`);
            }
            const normalized = normalizeScopeModeFlag(value);
            if (!normalized) {
                throw new Error(`${path} must be "changed" or "full".`);
            }
            return normalized;
        }
        case "changeIntelligence.riskThreshold": {
            const normalized = normalizeRiskThresholdFlag(typeof value === "string" ? value : undefined);
            if (!normalized) {
                throw new Error('changeIntelligence.riskThreshold must be one of: "low", "medium", "high".');
            }
            return normalized;
        }
        case "policyProfiles.defaultProfile":
        case "policyProfiles.environmentOverrides.development":
        case "policyProfiles.environmentOverrides.sandbox":
        case "policyProfiles.environmentOverrides.production": {
            const normalized = normalizePolicyProfileNameFlag(typeof value === "string" ? value : undefined);
            if (!normalized) {
                throw new Error(`${path} must be one of: "relaxed", "balanced", "strict".`);
            }
            return normalized;
        }
        case "promotion.lanes.development.branch":
        case "promotion.lanes.sandbox.branch":
        case "promotion.lanes.production.branch": {
            if (typeof value !== "string" || !value.trim()) {
                throw new Error(`${path} must be a non-empty branch name.`);
            }
            return value.trim();
        }
        case "policyProfiles.profiles.relaxed.analyzerSeverityGate":
        case "policyProfiles.profiles.balanced.analyzerSeverityGate":
        case "policyProfiles.profiles.strict.analyzerSeverityGate": {
            if (typeof value !== "number" ||
                !Number.isInteger(value) ||
                value < 1 ||
                value > 5) {
                throw new Error(`${path} must be an integer between 1 and 5.`);
            }
            return value;
        }
        case "policyProfiles.profiles.relaxed.validationScope":
        case "policyProfiles.profiles.balanced.validationScope":
        case "policyProfiles.profiles.strict.validationScope": {
            const normalized = normalizeScopeModeFlag(typeof value === "string" ? value : undefined);
            if (!normalized) {
                throw new Error(`${path} must be "changed" or "full".`);
            }
            return normalized;
        }
        case "policyProfiles.profiles.relaxed.deployTestLevel":
        case "policyProfiles.profiles.balanced.deployTestLevel":
        case "policyProfiles.profiles.strict.deployTestLevel": {
            if (typeof value !== "string" ||
                !["RunLocalTests", "RunSpecifiedTests", "RunAllTestsInOrg"].includes(value)) {
                throw new Error(`${path} must be one of: "RunLocalTests", "RunSpecifiedTests", "RunAllTestsInOrg".`);
            }
            return value;
        }
        case "policyProfiles.profiles.relaxed.requirePullRequest":
        case "policyProfiles.profiles.balanced.requirePullRequest":
        case "policyProfiles.profiles.strict.requirePullRequest":
        case "policyProfiles.profiles.relaxed.allowAutoMerge":
        case "policyProfiles.profiles.balanced.allowAutoMerge":
        case "policyProfiles.profiles.strict.allowAutoMerge":
        case "policyProfiles.profiles.relaxed.autoMergeOnChecksPass":
        case "policyProfiles.profiles.balanced.autoMergeOnChecksPass":
        case "policyProfiles.profiles.strict.autoMergeOnChecksPass": {
            if (typeof value !== "boolean") {
                throw new Error(`${path} must be true or false.`);
            }
            return value;
        }
        case "tracked.metadataTypes": {
            return normalizeStringArrayInput(value, "tracked.metadataTypes", (entry) => METADATA_TYPE_ALIASES[entry.toLowerCase()] ?? entry);
        }
        case "destructiveChanges.intentPath": {
            if (typeof value !== "string" || !value.trim()) {
                throw new Error("destructiveChanges.intentPath must be a non-empty string.");
            }
            let normalized = value
                .trim()
                .replace(/\\/g, "/")
                .replace(/\/{2,}/g, "/")
                .replace(/\/+$/, "");
            if (!normalized || normalized.includes("..")) {
                throw new Error("destructiveChanges.intentPath must not include parent directory segments.");
            }
            if (normalized.startsWith("./")) {
                normalized = normalized.slice(2);
            }
            normalized = normalized.replace(/^\/+/, "");
            if (!normalized) {
                throw new Error("destructiveChanges.intentPath must not resolve to project root.");
            }
            if (normalized === ".gitforce" || normalized === "gitforce") {
                return ".gitforce";
            }
            if (normalized.startsWith(".gitforce/")) {
                return normalized;
            }
            if (normalized.startsWith("gitforce/")) {
                return `.${normalized}`;
            }
            return `.gitforce/${normalized}`;
        }
        case "tracked.paths":
        case "merge.requiredChecks":
        case "policyProfiles.profiles.relaxed.requiredChecks":
        case "policyProfiles.profiles.balanced.requiredChecks":
        case "policyProfiles.profiles.strict.requiredChecks": {
            return normalizeStringArrayInput(value, path);
        }
        default:
            return value;
    }
}
function setConfigValueAtPath(target, keyPath, value) {
    const segments = keyPath
        .split(".")
        .map((entry) => entry.trim())
        .filter(Boolean);
    if (segments.length === 0) {
        throw new Error("Config key path cannot be empty.");
    }
    let cursor = target;
    for (let index = 0; index < segments.length - 1; index++) {
        const segment = segments[index];
        const existing = cursor[segment];
        if (existing === undefined || existing === null) {
            cursor[segment] = {};
        }
        else if (typeof existing !== "object" || Array.isArray(existing)) {
            throw new Error(`Cannot set "${keyPath}" because "${segments.slice(0, index + 1).join(".")}" is not an object.`);
        }
        cursor = cursor[segment];
    }
    cursor[segments[segments.length - 1]] = value;
}
function parseSetExpression(input) {
    const trimmed = input.trim();
    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex <= 0 || separatorIndex === trimmed.length - 1) {
        throw new Error('Invalid --set format. Expected "--set key.path=value".');
    }
    const path = normalizeConfigPath(trimmed.slice(0, separatorIndex));
    const rawValue = trimmed.slice(separatorIndex + 1);
    return {
        path,
        value: parseConfigValue(rawValue),
        source: "--set"
    };
}
function buildConfigSetOperations(parsed, allowEmpty = false) {
    const operations = [];
    const setValue = getFlagString(parsed, "set");
    if (setValue) {
        operations.push(parseSetExpression(setValue));
    }
    const keyFlag = getFlagString(parsed, "key");
    const valueFlag = getFlagString(parsed, "value");
    if (keyFlag || valueFlag) {
        if (!keyFlag || valueFlag === undefined) {
            throw new Error("Pass both --key and --value together.");
        }
        operations.push({
            path: normalizeConfigPath(keyFlag),
            value: parseConfigValue(valueFlag),
            source: "--key/--value"
        });
    }
    if (parsed.positionals.length > 0) {
        if (parsed.positionals.length < 2) {
            throw new Error("Usage: gitforce config:set <key.path> <value>");
        }
        const [pathToken, ...valueTokens] = parsed.positionals;
        operations.push({
            path: normalizeConfigPath(pathToken),
            value: parseConfigValue(valueTokens.join(" ")),
            source: "positionals"
        });
    }
    if (!allowEmpty && operations.length === 0) {
        throw new Error('No config updates provided. Use "gitforce config:set deploy.mode auto-target" or --set deploy.mode=auto-target.');
    }
    return operations;
}
function buildUpdateOperations(parsed) {
    const operations = buildConfigSetOperations({
        flags: new Map([...parsed.flags.entries()].filter(([key]) => ["set", "key", "value"].includes(key))),
        positionals: parsed.positionals
    }, true);
    const addOperation = (flagName, path, value) => {
        operations.push({
            path,
            value,
            source: `--${flagName}`
        });
    };
    const optionalStringFlag = (flagName, path, transform) => {
        const value = getFlagString(parsed, flagName);
        if (value === undefined) {
            return;
        }
        addOperation(flagName, path, transform ? transform(value) : parseConfigValue(value));
    };
    const optionalBooleanFlag = (flagName, path) => {
        if (!parsed.flags.has(flagName)) {
            return;
        }
        addOperation(flagName, path, getFlagBoolean(parsed, flagName, true));
    };
    optionalStringFlag("deploy", "deploy.mode");
    optionalStringFlag("deploy-mode", "deploy.mode");
    optionalBooleanFlag("drift-enabled", "drift.enabled");
    optionalStringFlag("drift-interval-minutes", "drift.intervalMinutes", (value) => {
        const parsedValue = Number(value);
        if (!Number.isFinite(parsedValue)) {
            throw new Error("drift-interval-minutes must be a number.");
        }
        return parsedValue;
    });
    optionalStringFlag("drift-mode", "drift.mode");
    optionalBooleanFlag("destructive-enabled", "destructiveChanges.enabled");
    optionalStringFlag("delete-intent-path", "destructiveChanges.intentPath");
    optionalStringFlag("analyzer-scope", "codeAnalyzer.scope");
    optionalBooleanFlag("analyzer-enabled", "codeAnalyzer.enabled");
    optionalStringFlag("analyzer-severity", "codeAnalyzer.failOnSeverity", (value) => {
        const parsedValue = Number(value);
        if (!Number.isFinite(parsedValue)) {
            throw new Error("analyzer-severity must be a number from 1 to 5.");
        }
        return parsedValue;
    });
    optionalStringFlag("validate-scope", "validation.scope");
    optionalStringFlag("validation-scope", "validation.scope");
    optionalStringFlag("metadata-types", "tracked.metadataTypes");
    optionalStringFlag("tracked-paths", "tracked.paths");
    optionalStringFlag("target-org-alias", "environments.targetOrgAlias");
    optionalStringFlag("base-branch", "repository.baseBranch");
    optionalBooleanFlag("allow-auto-merge", "merge.allowAutoMerge");
    optionalBooleanFlag("auto-merge", "merge.autoMergeOnChecksPass");
    optionalBooleanFlag("require-pr", "merge.requirePullRequest");
    optionalBooleanFlag("change-intelligence-enabled", "changeIntelligence.enabled");
    optionalStringFlag("change-intelligence-risk-threshold", "changeIntelligence.riskThreshold");
    optionalBooleanFlag("change-intelligence-comment-on-pr", "changeIntelligence.commentOnPr");
    optionalStringFlag("change-intelligence-max-summary-items", "changeIntelligence.maxPrSummaryItems", (value) => {
        const parsedValue = Number(value);
        if (!Number.isFinite(parsedValue)) {
            throw new Error("change-intelligence-max-summary-items must be a number.");
        }
        return parsedValue;
    });
    optionalBooleanFlag("promotion-auto-promote", "promotion.autoPromote");
    optionalStringFlag("promotion-development-branch", "promotion.lanes.development.branch");
    optionalStringFlag("promotion-sandbox-branch", "promotion.lanes.sandbox.branch");
    optionalStringFlag("promotion-production-branch", "promotion.lanes.production.branch");
    optionalStringFlag("policy-default-profile", "policyProfiles.defaultProfile");
    optionalBooleanFlag("orchestration-enabled", "orchestration.enabled");
    optionalStringFlag("orchestration-max-concurrent-per-lane", "orchestration.maxConcurrentPerLane", (value) => {
        const parsedValue = Number(value);
        if (!Number.isFinite(parsedValue)) {
            throw new Error("orchestration-max-concurrent-per-lane must be a number.");
        }
        return parsedValue;
    });
    optionalBooleanFlag("orchestration-publish-run-summary", "orchestration.publishRunSummary");
    if (operations.length === 0) {
        throw new Error("No update flags provided. Example: gitforce update --deploy auto-target --drift-interval-minutes 240.");
    }
    return operations;
}
function synchronizeDerivedCoreConfig(config) {
    config.drift.intervalMinutes = (0, repoSyncConfig_1.normalizeSyncIntervalMinutes)(config.drift.intervalMinutes);
    config.drift.cron = (0, repoSyncConfig_1.buildCronExpression)(config.drift.intervalMinutes);
    if (config.codeAnalyzer.scope === "full") {
        config.codeAnalyzer.changedFilesOnly = false;
    }
    else {
        config.codeAnalyzer.scope = "changed";
        config.codeAnalyzer.changedFilesOnly = true;
    }
    if (!config.merge.allowAutoMerge) {
        config.merge.autoMergeOnChecksPass = false;
    }
}
function setEnvironmentAlias(config, environment, alias) {
    if (environment === "production") {
        config.salesforce.productionOrgAlias = alias;
        return;
    }
    if (environment === "sandbox") {
        config.salesforce.sandboxOrgAlias = alias;
        return;
    }
    config.salesforce.developmentOrgAlias = alias;
}
function resolveAliasForEnvironment(localConfig, coreConfig, environment) {
    if (environment === "production") {
        return (localConfig.salesforce.productionOrgAlias ||
            coreConfig.environments.productionOrgAlias ||
            undefined);
    }
    if (environment === "sandbox") {
        return (localConfig.salesforce.sandboxOrgAlias ||
            coreConfig.environments.sandboxOrgAlias ||
            undefined);
    }
    return (localConfig.salesforce.developmentOrgAlias ||
        coreConfig.environments.developmentOrgAlias ||
        undefined);
}
function printUsage() {
    process.stdout.write([
        "Gitforce CLI",
        "",
        "Primary commands:",
        "  gitforce init",
        "  gitforce auth:github [--login]",
        "  gitforce auth:salesforce [--environment development|sandbox|production] [--alias <orgAlias>] [--login] [--customdomain <mydomain.my.salesforce.com>]",
        "  gitforce repo:create --owner <githubOwner> --repo <repoName> [--private|--public|--internal] [--publish]",
        "  gitforce repo:connect [--owner <githubOwner>] [--repo <repoName>] [--base-branch <branch>]",
        "  gitforce secrets:sync [--owner <githubOwner>] [--repo <repoName>] [--org-alias <orgAlias>]",
        "  gitforce repo:harden [--owner <githubOwner>] [--repo <repoName>] [--publish-codeowners]",
        "  gitforce config:set <key.path> <value> [--no-generate-workflows]",
        "  gitforce update --deploy auto-target [--drift-interval-minutes 240] [--metadata-types apex,lwcs] [--destructive-enabled true|false]",
        "  gitforce deploy:suite [--mode report|validate|deploy] [--select] [--apply] [--check-missing-metadata true|false]",
        "  gitforce impact [--base origin/main] [--head HEAD] [--format table|json]",
        "  gitforce status",
        "  gitforce drift:report [--last 5]",
        "  gitforce promote --from development --to sandbox [--yes]",
        "  gitforce rollback --ago \"2 hours\" [--yes]",
        "  gitforce rollback --at 2025-03-01 [--yes]",
        "  gitforce rollback --commit <sha> [--yes]",
        "  gitforce rollback --tag <tag> [--yes]",
        "  gitforce rollback:revert [--commit <rollbackSha>] [--yes]",
        "  gitforce push [--description <text>] [--base-branch <branch>] [--remote <remote>]",
        "  gitforce pull [--strategy merge|overwrite] [--base-branch <branch>] [--remote <remote>]",
        "  gitforce test|-test [--test-level RunLocalTests|RunAllTestsInOrg|RunSpecifiedTests] [--code-coverage]",
        "  gitforce coverage [--test-level RunLocalTests|RunAllTestsInOrg|RunSpecifiedTests] [--class <ApexClassName>]",
        "",
        "Project lifecycle examples:",
        "  gitforce init",
        "  gitforce auth:salesforce --environment sandbox --alias my-sandbox --login",
        "  gitforce auth:salesforce --environment sandbox --alias my-sandbox --login --customdomain mydomain--sandbox.sandbox.my.salesforce.com",
        "  gitforce auth:github --login",
        "  gitforce repo:create --owner tpizzle61 --repo my-sf-project --drift-enabled true --drift-interval-minutes 240 --metadata-types apex,triggers,lwcs,objects,fields --publish",
        "  gitforce repo:create --owner tpizzle61 --repo my-sf-project --analyzer-scope changed --validate-scope changed --publish",
        "  gitforce repo:connect --owner tpizzle61 --repo existing-sf-project --base-branch main",
        "  gitforce repo:create --owner tpizzle61 --repo local-dry-run --metadata-types apex,lwcs --no-create-remote --no-retrieve",
        "  gitforce secrets:sync --owner tpizzle61 --repo my-sf-project --org-alias my-sandbox",
        "  gitforce repo:harden --owner tpizzle61 --repo my-sf-project --publish-codeowners",
        "  gitforce config:set deploy.mode auto-target",
        "  gitforce config:set --set drift.intervalMinutes=240",
        "  gitforce config:set destructiveChanges.enabled true",
        "  gitforce update --deploy auto-target --drift-enabled true --drift-interval-minutes 240",
        "  gitforce update --destructive-enabled true --delete-intent-path .gitforce/deletes/pending",
        "  gitforce deploy:suite --mode report",
        "  gitforce deploy:suite --mode validate --check-coverage --check-conflicts",
        "  gitforce deploy:suite --mode deploy --apply --select --tests MyClassTest",
        "  gitforce deploy:suite --mode validate --check-missing-metadata --fail-on-missing-metadata",
        "  gitforce impact --base origin/main --head HEAD",
        "  gitforce status",
        "  gitforce drift:report --last 10",
        "  gitforce promote --from development --to sandbox --yes",
        "  gitforce rollback --ago \"2 hours\" --yes",
        "  gitforce rollback --at 2025-03-01 --yes",
        "  gitforce rollback --commit a1b2c3d --yes",
        "  gitforce rollback:revert --yes",
        "  gitforce push",
        "  gitforce pull",
        "  gitforce test --test-level RunLocalTests --code-coverage",
        "  gitforce -test --tests ExampleClass.testMethod --result-format human --wait 30",
        "  gitforce coverage --test-level RunLocalTests --top 15",
        "  gitforce coverage --class MyApexClass",
        "  gitforce coverage --history",
        "",
        "Other commands:",
        "  gitforce validate [--strict]",
        "  gitforce doctor",
        "  gitforce generate-workflows",
        "  gitforce deploy:suite",
        "  gitforce repo:connect [--harden] [--set-secrets]",
        "  gitforce repo:harden [--publish-codeowners]",
        "  gitforce push",
        "  gitforce pull",
        "  gitforce test",
        "  gitforce coverage",
        "  gitforce generate-basic-tests",
        "  gitforce profile:list",
        "  gitforce profile:apply --profile balanced",
        "  gitforce pipeline:run --lane sandbox",
        "  gitforce pipeline:status --last 5",
        "  gitforce status",
        "  gitforce drift:report --last 5",
        "  gitforce config:set <key.path> <value>",
        "  gitforce update [--deploy <mode>] [--drift-enabled <bool>] ...",
        "  gitforce rollback --ago \"2 hours\"",
        "  gitforce rollback:revert [--commit <rollbackSha>]",
        "  gitforce show-config",
        "  gitforce show-local-config",
        "  gitforce show-basic-tests",
        ""
    ].join("\n"));
}
function commandExists(command) {
    const output = (0, child_process_1.spawnSync)(command, ["--version"], {
        stdio: "ignore"
    });
    return output.status === 0;
}
function runInteractiveCommand(command, args, cwd) {
    const result = (0, child_process_1.spawnSync)(command, args, {
        cwd,
        env: process.env,
        stdio: "inherit"
    });
    if (result.status !== 0) {
        throw new Error(`Command failed (${result.status ?? "unknown"}): ${command} ${args.join(" ")}`);
    }
}
function printList(label, entries) {
    if (entries.length === 0) {
        return;
    }
    process.stdout.write(`${label}\n`);
    for (const entry of entries) {
        process.stdout.write(`- ${entry}\n`);
    }
}
function formatDuration(ms) {
    const seconds = Math.max(1, Math.round(ms / 1000));
    if (seconds < 60) {
        return `${seconds}s`;
    }
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds % 60;
    return remainder > 0 ? `${minutes}m ${remainder}s` : `${minutes}m`;
}
function logStep(message) {
    process.stdout.write(`[Gitforce] ${message}\n`);
}
function buildTimestampSuffix() {
    return new Date().toISOString().replace(/[:.]/g, "-").replace("T", "-").replace("Z", "");
}
function slugify(value, fallback) {
    const slug = value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 48);
    return slug || fallback;
}
function buildPushBranchName(description, prefix) {
    const base = slugify(description, "change");
    const normalizedPrefix = prefix.trim().replace(/^\/+/, "");
    return `${normalizedPrefix}${base}-${buildTimestampSuffix()}`;
}
function branchStartsWithPrefix(branch, prefix) {
    return branch.toLowerCase().startsWith(prefix.toLowerCase());
}
function enforceBranchPolicy(branch, baseBranch, autoBranchPrefix, reservedPrefixes, enforcePrefix, disallowDirectPushToBase) {
    if (disallowDirectPushToBase && branch === baseBranch) {
        throw new Error(`Direct pushes to base branch "${baseBranch}" are blocked by branchPolicy.disallowDirectPushToBase. Use gitforce push without --branch to auto-create a feature branch.`);
    }
    if (branch === baseBranch) {
        return;
    }
    for (const reserved of reservedPrefixes) {
        if (branchStartsWithPrefix(branch, reserved)) {
            throw new Error(`Branch "${branch}" is reserved by branchPolicy.reservedPrefixes (${reserved}). Use a feature branch.`);
        }
    }
    if (enforcePrefix && !branchStartsWithPrefix(branch, autoBranchPrefix)) {
        throw new Error(`Branch "${branch}" does not match required prefix "${autoBranchPrefix}" from branchPolicy.enforcePrefix.`);
    }
}
function buildPrTitle(description) {
    const normalized = description.trim().replace(/\s+/g, " ");
    if (!normalized) {
        return "Gitforce Change";
    }
    if (normalized.length <= 72) {
        return normalized;
    }
    return `${normalized.slice(0, 69).trimEnd()}...`;
}
function summarizeDiffFiles(files) {
    const unique = [...new Set(files.map((entry) => entry.trim()).filter(Boolean))];
    if (unique.length <= 20) {
        return unique;
    }
    return [...unique.slice(0, 20), `... and ${unique.length - 20} more`];
}
function buildPrBody(description, changedFiles) {
    const lines = ["## Summary", "", description.trim() || "No description provided.", ""];
    if (changedFiles.length > 0) {
        lines.push("## Changed Files", "");
        for (const file of summarizeDiffFiles(changedFiles)) {
            lines.push(`- ${file}`);
        }
        lines.push("");
    }
    lines.push("## Gitforce", "", "- Created via `gitforce push`");
    return lines.join("\n");
}
function formatRollbackCommits(commits, limit = 12) {
    if (commits.length <= limit) {
        return commits.map((entry) => `- ${entry.sha.slice(0, 7)} ${entry.subject}`);
    }
    return [
        ...commits.slice(0, limit).map((entry) => `- ${entry.sha.slice(0, 7)} ${entry.subject}`),
        `- ... and ${commits.length - limit} more`
    ];
}
function buildRollbackPrBody(plan, baseBranch) {
    const lines = [
        "## Summary",
        "",
        `Rollback to \`${plan.targetCommitSha.slice(0, 7)}\` based on selector \`${plan.targetExpression}\`.`,
        `Reverts ${plan.commitsToRevert.length} commit(s) on \`${baseBranch}\` after that point.`,
        "",
        "## Reverted Commits",
        "",
        ...formatRollbackCommits(plan.commitsToRevert, 30),
        "",
        "## Gitforce",
        "",
        "- Created via `gitforce rollback`"
    ];
    return lines.join("\n");
}
function buildRollbackRevertPrBody(baseBranch, rollbackCommitSha, rollbackCommitSubject) {
    const lines = [
        "## Summary",
        "",
        `Undo rollback commit \`${rollbackCommitSha.slice(0, 7)}\` on \`${baseBranch}\`.`,
        `Rollback commit subject: ${rollbackCommitSubject}`,
        "",
        "## Gitforce",
        "",
        "- Created via `gitforce rollback:revert`"
    ];
    return lines.join("\n");
}
function normalizeAgoExpression(value) {
    const trimmed = value.trim();
    if (!trimmed) {
        throw new Error("Rollback --ago value cannot be empty.");
    }
    if (/ago$/i.test(trimmed)) {
        return trimmed;
    }
    return `${trimmed} ago`;
}
function looksLikeIsoDate(value) {
    const trimmed = value.trim();
    return /^\d{4}-\d{2}-\d{2}(?:[Tt ][0-9:.+-Zz]+)?$/.test(trimmed);
}
function resolveRollbackTargetExpression(parsed) {
    const at = getFlagString(parsed, "at") || getFlagString(parsed, "date");
    if (at) {
        return at;
    }
    const ago = getFlagString(parsed, "ago");
    if (ago) {
        return normalizeAgoExpression(ago);
    }
    if (parsed.positionals.length > 0) {
        const positional = parsed.positionals.join(" ").trim();
        if (!positional) {
            throw new Error("Rollback target cannot be empty.");
        }
        if (/^\d+\s+[A-Za-z]+$/i.test(positional)) {
            return normalizeAgoExpression(positional);
        }
        return positional;
    }
    // Compatibility shortcuts:
    //  - gitforce rollback --2 hours
    //  - gitforce rollback --2025-03-01
    for (const [key, value] of parsed.flags.entries()) {
        if ([
            "yes",
            "remote",
            "base-branch",
            "branch",
            "no-pr",
            "pr",
            "title",
            "at",
            "date",
            "ago"
        ].includes(key)) {
            continue;
        }
        if (looksLikeIsoDate(key)) {
            return key;
        }
        if (/^\d+$/.test(key) && typeof value === "string") {
            return normalizeAgoExpression(`${key} ${value}`);
        }
    }
    throw new Error("Missing rollback target. Use --ago \"2 hours\", --at 2025-03-01, or positional value.");
}
function parsePullStrategyFlag(parsed) {
    const mergeExplicit = parsed.flags.has("merge") ? getFlagBoolean(parsed, "merge", true) : undefined;
    const overwriteExplicit = parsed.flags.has("overwrite")
        ? getFlagBoolean(parsed, "overwrite", true)
        : undefined;
    if (mergeExplicit === true && overwriteExplicit === true) {
        throw new Error('Choose only one pull strategy flag: --merge or --overwrite.');
    }
    if (mergeExplicit === true) {
        return "merge";
    }
    if (overwriteExplicit === true) {
        return "overwrite";
    }
    const strategy = getFlagString(parsed, "strategy");
    if (!strategy) {
        return undefined;
    }
    const normalized = strategy.trim().toLowerCase();
    if (["merge", "rebase"].includes(normalized)) {
        return "merge";
    }
    if (["overwrite", "reset", "hard-reset", "hard"].includes(normalized)) {
        return "overwrite";
    }
    throw new Error('Invalid --strategy value. Use "merge" or "overwrite".');
}
async function promptForDescription() {
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        return undefined;
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const response = await reader.question("Describe your changes: ");
        const trimmed = response.trim();
        return trimmed || undefined;
    }
    finally {
        reader.close();
    }
}
async function promptForDeployComponentSelection(items) {
    if (!process.stdin.isTTY || !process.stdout.isTTY || items.length === 0) {
        return items;
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        process.stdout.write("Deployable components:\n");
        for (let index = 0; index < items.length; index += 1) {
            const item = items[index];
            process.stdout.write(`${index + 1}. ${item.sourcePath} (${item.metadataType}:${item.componentName})\n`);
        }
        const response = await reader.question('Select components to deploy by number (e.g. "1,2,5"), or "all" (default all): ');
        const normalized = response.trim().toLowerCase();
        if (!normalized || normalized === "all" || normalized === "a") {
            return items;
        }
        const selectedIndexes = new Set();
        for (const token of normalized.split(",")) {
            const parsedNumber = Number(token.trim());
            if (!Number.isInteger(parsedNumber) || parsedNumber < 1 || parsedNumber > items.length) {
                throw new Error(`Invalid selection "${token.trim()}". Enter numbers between 1 and ${items.length}, or "all".`);
            }
            selectedIndexes.add(parsedNumber - 1);
        }
        return [...selectedIndexes].sort((left, right) => left - right).map((index) => items[index]);
    }
    finally {
        reader.close();
    }
}
async function promptForPullStrategy() {
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        return "merge";
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const response = await reader.question("Pull strategy: merge remote changes into local (m) or overwrite local from remote (o)? [m/o] (default m): ");
        const normalized = response.trim().toLowerCase();
        if (!normalized || normalized === "m" || normalized === "merge") {
            return "merge";
        }
        if (normalized === "o" || normalized === "overwrite") {
            return "overwrite";
        }
        throw new Error('Invalid pull strategy input. Enter "m" for merge or "o" for overwrite.');
    }
    finally {
        reader.close();
    }
}
async function confirmOverwritePull(remote, baseBranch, currentBranch, forceYes) {
    if (forceYes) {
        return true;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Overwrite pull requires confirmation. Re-run with --yes to allow non-interactive overwrite.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: overwrite pull will discard local uncommitted and unpushed changes.",
            `- Remote: ${remote}`,
            `- Base branch: ${baseBranch}`,
            `- Current branch: ${currentBranch}`,
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        return normalized === "yes" || normalized === "y";
    }
    finally {
        reader.close();
    }
}
async function confirmMergePullWithDirtyWorkspace(remote, baseBranch, currentBranch, forceYes) {
    if (forceYes) {
        return true;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Merge pull requires confirmation when local changes exist. Re-run with --yes to allow non-interactive merge pull.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: merge pull with local changes will stash your uncommitted/untracked files, pull + rebase, then re-apply the stash.",
            "If stash apply conflicts, you will need to resolve conflicts manually.",
            `- Remote: ${remote}`,
            `- Base branch: ${baseBranch}`,
            `- Current branch: ${currentBranch}`,
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        return normalized === "yes" || normalized === "y";
    }
    finally {
        reader.close();
    }
}
async function confirmBranchPolicyOverride(branch, baseBranch, policyMessage, forceYes) {
    if (forceYes) {
        return true;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Branch policy override requires confirmation. Re-run with --yes to allow non-interactive override.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: your current branch violates Gitforce branch policy.",
            `- Branch: ${branch}`,
            `- Base branch: ${baseBranch}`,
            `- Policy warning: ${policyMessage}`,
            "Proceeding may bypass team guardrails.",
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        return normalized === "yes" || normalized === "y";
    }
    finally {
        reader.close();
    }
}
async function confirmRollbackWorkspaceCleanup(remote, baseBranch, currentBranch, forceYes) {
    if (forceYes) {
        return true;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Rollback cleanup requires confirmation. Re-run with --yes to allow non-interactive rollback.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: rollback requires a clean working tree and will discard local uncommitted and untracked changes.",
            `- Remote: ${remote}`,
            `- Base branch: ${baseBranch}`,
            `- Current branch: ${currentBranch}`,
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        return normalized === "yes" || normalized === "y";
    }
    finally {
        reader.close();
    }
}
async function promptForPromotionLane(flagName, forceYes) {
    if (forceYes) {
        return undefined;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        return undefined;
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const response = await reader.question(`Enter --${flagName} lane (development/sandbox/production): `);
        return normalizePromotionLane(response);
    }
    finally {
        reader.close();
    }
}
async function confirmPromotionOverride(fromLane, toLane, warnings, forceYes) {
    if (forceYes) {
        return true;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Promotion override requires confirmation. Re-run with --yes for non-interactive execution.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: promotion settings are outside the default safe path.",
            `- From lane: ${fromLane}`,
            `- To lane: ${toLane}`,
            ...warnings.map((warning) => `- ${warning}`),
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        return normalized === "yes" || normalized === "y";
    }
    finally {
        reader.close();
    }
}
async function ensurePromotionLaneBranch(workspacePath, remote, lane, laneBranch, seedBranch, forceYes) {
    try {
        await (0, shell_1.runCommand)("git", ["rev-parse", "--verify", `${remote}/${laneBranch}`], workspacePath);
        return;
    }
    catch {
        const confirmed = await confirmPromotionOverride(lane, lane, [
            `${lane} lane branch "${laneBranch}" was not found on ${remote}.`,
            `Gitforce can create "${laneBranch}" from ${remote}/${seedBranch}.`
        ], forceYes);
        if (!confirmed) {
            throw new Error("Promotion canceled.");
        }
        logStep(`Creating missing ${lane} lane branch "${laneBranch}" from "${remote}/${seedBranch}"...`);
        await (0, shell_1.runCommand)("git", ["push", remote, `${remote}/${seedBranch}:refs/heads/${laneBranch}`], workspacePath);
        await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
        process.stdout.write(`Created branch "${laneBranch}" on ${remote}.\n`);
    }
}
async function promptForRollbackConfirmation(baseBranch, targetExpression, commitsToRevert, forceYes) {
    if (forceYes) {
        return;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Rollback confirmation is required. Re-run with --yes if you want non-interactive execution.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: Gitforce rollback will create a new branch and revert commits.",
            `- Base branch: ${baseBranch}`,
            `- Target selector: ${targetExpression}`,
            `- Commits to revert: ${commitsToRevert.length}`,
            ...formatRollbackCommits(commitsToRevert, 10),
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        if (normalized !== "yes" && normalized !== "y") {
            throw new Error("Rollback canceled.");
        }
    }
    finally {
        reader.close();
    }
}
async function promptForRollbackRevertConfirmation(baseBranch, rollbackCommitSha, rollbackCommitSubject, forceYes) {
    if (forceYes) {
        return;
    }
    if (!process.stdin.isTTY || !process.stdout.isTTY) {
        throw new Error("Rollback revert confirmation is required. Re-run with --yes if you want non-interactive execution.");
    }
    const reader = (0, promises_1.createInterface)({
        input: process.stdin,
        output: process.stdout
    });
    try {
        const confirmationQuestion = "Are you sure you want to proceed? (y/n)";
        process.stdout.write([
            "Warning: Gitforce rollback:revert will create a new branch and revert a rollback commit.",
            `- Base branch: ${baseBranch}`,
            `- Rollback commit: ${rollbackCommitSha.slice(0, 7)} ${rollbackCommitSubject}`,
            confirmationQuestion
        ].join("\n") + "\n");
        const response = await reader.question("> ");
        const normalized = response.trim().toLowerCase();
        if (normalized !== "yes" && normalized !== "y") {
            throw new Error("Rollback revert canceled.");
        }
    }
    finally {
        reader.close();
    }
}
async function resolveCurrentBranch(workspacePath) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["rev-parse", "--abbrev-ref", "HEAD"], workspacePath);
    return stdout.trim();
}
async function resolveLatestCommitSubject(workspacePath) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("git", ["log", "-1", "--pretty=%s"], workspacePath);
        const title = stdout.trim();
        return title || undefined;
    }
    catch {
        return undefined;
    }
}
async function resolveDiffFilesForPr(workspacePath, remote, baseBranch, branch) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("git", ["diff", "--name-only", `${remote}/${baseBranch}...${branch}`], workspacePath);
        const files = stdout
            .split("\n")
            .map((entry) => entry.trim())
            .filter(Boolean);
        if (files.length > 0) {
            return files;
        }
    }
    catch {
        // fall through to latest commit fallback
    }
    try {
        const { stdout } = await (0, shell_1.runCommand)("git", ["show", "--name-only", "--pretty=format:", "HEAD"], workspacePath);
        return stdout
            .split("\n")
            .map((entry) => entry.trim())
            .filter(Boolean);
    }
    catch {
        return [];
    }
}
async function hasCommitsToPush(workspacePath, remote, branch) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("git", ["rev-list", "--count", `${remote}/${branch}..HEAD`], workspacePath);
        return Number(stdout.trim()) > 0;
    }
    catch {
        return true;
    }
}
async function resolveCommitSummaries(workspacePath, revisionRange) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["log", "--pretty=format:%H%x09%s", revisionRange], workspacePath);
    if (!stdout.trim()) {
        return [];
    }
    return stdout
        .split("\n")
        .map((entry) => entry.trim())
        .filter(Boolean)
        .map((entry) => {
        const [sha, ...subjectParts] = entry.split("\t");
        return {
            sha: sha.trim(),
            subject: subjectParts.join("\t").trim() || "(no subject)"
        };
    });
}
async function resolveCommitSubjectBySha(workspacePath, sha) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["show", "-s", "--format=%s", sha], workspacePath);
    return stdout.trim() || "(no subject)";
}
async function resolveRollbackCommitForRevert(workspacePath, remoteRef, commitSelector) {
    if (commitSelector) {
        const { stdout } = await (0, shell_1.runCommand)("git", ["rev-parse", commitSelector], workspacePath);
        const sha = stdout.trim();
        const subject = await resolveCommitSubjectBySha(workspacePath, sha);
        await (0, shell_1.runCommand)("git", ["merge-base", "--is-ancestor", sha, remoteRef], workspacePath);
        return {
            sha,
            subject
        };
    }
    const { stdout } = await (0, shell_1.runCommand)("git", ["log", "--grep", "^Rollback to ", "--pretty=format:%H%x09%s", "-n", "1", remoteRef], workspacePath);
    const line = stdout.trim();
    if (!line) {
        throw new Error(`No rollback commits found on ${remoteRef}. Pass --commit <sha> to explicitly target a rollback commit.`);
    }
    const [sha, ...subjectParts] = line.split("\t");
    return {
        sha: sha.trim(),
        subject: subjectParts.join("\t").trim() || "(no subject)"
    };
}
async function resolveCommitParentCount(workspacePath, sha) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["rev-list", "--parents", "-n", "1", sha], workspacePath);
    const tokens = stdout
        .trim()
        .split(/\s+/)
        .filter(Boolean);
    return Math.max(0, tokens.length - 1);
}
async function resolveRollbackPlan(workspacePath, remoteRef, targetExpression) {
    const { stdout: targetShaStdout } = await (0, shell_1.runCommand)("git", ["rev-list", "-1", `--before=${targetExpression}`, remoteRef], workspacePath);
    const targetCommitSha = targetShaStdout.trim();
    if (!targetCommitSha) {
        throw new Error(`No commit found on ${remoteRef} before "${targetExpression}".`);
    }
    const { stdout: headShaStdout } = await (0, shell_1.runCommand)("git", ["rev-parse", remoteRef], workspacePath);
    const headCommitSha = headShaStdout.trim();
    if (!headCommitSha) {
        throw new Error(`Could not resolve head commit for ${remoteRef}.`);
    }
    if (headCommitSha === targetCommitSha) {
        return {
            remoteRef,
            targetCommitSha,
            headCommitSha,
            targetExpression,
            commitsToRevert: []
        };
    }
    const commitsToRevert = await resolveCommitSummaries(workspacePath, `${targetCommitSha}..${headCommitSha}`);
    return {
        remoteRef,
        targetCommitSha,
        headCommitSha,
        targetExpression,
        commitsToRevert
    };
}
async function getExistingPrUrl(workspacePath, branch, baseBranch) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("gh", [
            "pr",
            "list",
            "--state",
            "open",
            "--head",
            branch,
            "--base",
            baseBranch,
            "--json",
            "url",
            "--jq",
            ".[0].url // \"\""
        ], workspacePath);
        const url = stdout.trim();
        return url || undefined;
    }
    catch {
        return undefined;
    }
}
function extractPrUrl(value) {
    const match = value.match(/https:\/\/github\.com\/[^\s]+\/pull\/\d+/);
    return match?.[0];
}
async function enablePrAutoMerge(workspacePath, prRef) {
    await (0, shell_1.runCommand)("gh", ["pr", "merge", prRef, "--auto", "--merge"], workspacePath);
}
async function resolveRepoCoordinatesForPush(workspacePath, remote, coreConfig) {
    if (coreConfig.repository.owner && coreConfig.repository.repo) {
        return {
            owner: coreConfig.repository.owner,
            repo: coreConfig.repository.repo
        };
    }
    try {
        const remoteUrl = await (0, git_1.getRemoteUrl)(workspacePath, remote);
        return (0, git_1.parseGitHubRemote)(remoteUrl);
    }
    catch {
        return undefined;
    }
}
async function getProtectedRequiredChecks(workspacePath, owner, repo, baseBranch) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("gh", [
            "api",
            `repos/${owner}/${repo}/branches/${encodeURIComponent(baseBranch)}/protection`,
            "--jq",
            ".required_status_checks.contexts[]?"
        ], workspacePath);
        if (!stdout.trim()) {
            return [];
        }
        return stdout
            .split("\n")
            .map((entry) => entry.trim())
            .filter(Boolean);
    }
    catch {
        return undefined;
    }
}
async function evaluateAutoMergeSafety(workspacePath, remote, baseBranch, coreConfig) {
    if (!coreConfig.merge.allowAutoMerge || !coreConfig.merge.autoMergeOnChecksPass) {
        return {
            allowed: false,
            reason: "merge.autoMergeOnChecksPass is disabled."
        };
    }
    if (!coreConfig.merge.requirePullRequest) {
        return {
            allowed: false,
            reason: "merge.requirePullRequest is false."
        };
    }
    if (coreConfig.merge.requiredChecks.length === 0) {
        return {
            allowed: false,
            reason: "merge.requiredChecks is empty."
        };
    }
    const coordinates = await resolveRepoCoordinatesForPush(workspacePath, remote, coreConfig);
    if (!coordinates) {
        return {
            allowed: false,
            reason: "Could not resolve repository owner/repo for branch protection checks."
        };
    }
    const protectedChecks = await getProtectedRequiredChecks(workspacePath, coordinates.owner, coordinates.repo, baseBranch);
    if (protectedChecks === undefined) {
        return {
            allowed: false,
            reason: `Could not verify branch protection required checks on ${coordinates.owner}/${coordinates.repo} ` +
                `(base: ${baseBranch}). Run "gitforce repo:harden" and ensure branch protection is supported for this repo.`
        };
    }
    if (protectedChecks.length === 0) {
        return {
            allowed: false,
            reason: `Branch protection on ${coordinates.owner}/${coordinates.repo}:${baseBranch} has no required status checks.`
        };
    }
    const protectedSet = new Set(protectedChecks.map((entry) => entry.toLowerCase()));
    const missingChecks = coreConfig.merge.requiredChecks.filter((entry) => !protectedSet.has(entry.toLowerCase()));
    if (missingChecks.length > 0) {
        return {
            allowed: false,
            reason: `Required checks from config are not fully protected on ${baseBranch}. Missing: ${missingChecks.join(", ")}.`
        };
    }
    return { allowed: true };
}
function normalizeCodeOwnerHandle(value) {
    const trimmed = value.trim();
    if (!trimmed) {
        return "";
    }
    return trimmed.startsWith("@") ? trimmed : `@${trimmed}`;
}
function buildCodeOwnersContent(coreConfig, localConfig) {
    const lines = [];
    const ruleLines = coreConfig.governance.codeOwners
        .map((rule) => ({
        pattern: rule.pattern.trim(),
        owners: rule.owners.map((owner) => normalizeCodeOwnerHandle(owner)).filter(Boolean)
    }))
        .filter((rule) => rule.pattern && rule.owners.length > 0)
        .map((rule) => `${rule.pattern} ${rule.owners.join(" ")}`);
    lines.push(...ruleLines);
    if (lines.length === 0 && localConfig.github.user) {
        lines.push(`* @${localConfig.github.user}`);
    }
    if (lines.length === 0) {
        return undefined;
    }
    return ["# Managed by Gitforce", ...lines].join("\n") + "\n";
}
async function writeCodeOwnersFile(workspacePath, content) {
    const relativePath = ".github/CODEOWNERS";
    const absolutePath = path.join(workspacePath, relativePath);
    await fs_1.promises.mkdir(path.dirname(absolutePath), { recursive: true });
    let existing = "";
    try {
        existing = await fs_1.promises.readFile(absolutePath, "utf8");
    }
    catch {
        // ignore if missing
    }
    if (existing === content) {
        return false;
    }
    await fs_1.promises.writeFile(absolutePath, content, "utf8");
    return true;
}
async function publishCodeOwnersFile(workspacePath, baseBranch) {
    const relativePath = ".github/CODEOWNERS";
    const { stdout } = await (0, shell_1.runCommand)("git", ["status", "--porcelain", "--", relativePath], workspacePath);
    if (!stdout.trim()) {
        return false;
    }
    await (0, shell_1.runCommand)("git", ["add", relativePath], workspacePath);
    await (0, shell_1.runCommand)("git", ["commit", "-m", "chore: update CODEOWNERS via Gitforce", "--", relativePath], workspacePath);
    await (0, shell_1.runCommand)("git", ["push", "origin", baseBranch], workspacePath);
    return true;
}
async function applyGitHubRepositoryHardening(workspacePath, owner, repo, baseBranch, coreConfig) {
    const repoRef = `${owner}/${repo}`;
    const patchArgs = [
        "api",
        "-X",
        "PATCH",
        `repos/${repoRef}`,
        "-f",
        `delete_branch_on_merge=${coreConfig.governance.autoDeleteBranchOnMerge ? "true" : "false"}`,
        "-f",
        `allow_auto_merge=${coreConfig.merge.allowAutoMerge ? "true" : "false"}`
    ];
    await (0, shell_1.runCommand)("gh", patchArgs, workspacePath);
    const protectionPayload = {
        required_status_checks: coreConfig.merge.requiredChecks.length > 0
            ? {
                strict: true,
                contexts: coreConfig.merge.requiredChecks
            }
            : null,
        enforce_admins: coreConfig.governance.enforceAdmins,
        required_pull_request_reviews: coreConfig.merge.requirePullRequest
            ? {
                dismiss_stale_reviews: coreConfig.governance.dismissStaleReviews,
                require_code_owner_reviews: coreConfig.governance.requireCodeOwnerReviews,
                required_approving_review_count: coreConfig.governance.requiredApprovingReviewCount
            }
            : null,
        restrictions: null,
        required_conversation_resolution: coreConfig.governance.requireConversationResolution,
        allow_force_pushes: coreConfig.governance.allowForcePushes,
        allow_deletions: coreConfig.governance.allowDeletions
    };
    const tmpFilePath = path.join(os.tmpdir(), `gitforce-protection-${Date.now()}.json`);
    try {
        await fs_1.promises.writeFile(tmpFilePath, `${JSON.stringify(protectionPayload, null, 2)}\n`, "utf8");
        await (0, shell_1.runCommand)("gh", [
            "api",
            "-X",
            "PUT",
            `repos/${repoRef}/branches/${encodeURIComponent(baseBranch)}/protection`,
            "--input",
            tmpFilePath
        ], workspacePath);
    }
    finally {
        await fs_1.promises.rm(tmpFilePath, { force: true });
    }
}
function inferProjectNameFromPath(workspacePath) {
    const raw = path.basename(workspacePath).trim() || "gitforce-project";
    const normalized = raw.replace(/[^A-Za-z0-9_-]/g, "-");
    return normalized || "gitforce-project";
}
function normalizeInstanceUrl(value) {
    if (!value) {
        return undefined;
    }
    const trimmed = value.trim();
    if (!trimmed) {
        return undefined;
    }
    if (/^https?:\/\//i.test(trimmed)) {
        return trimmed.replace(/\/+$/, "");
    }
    const withoutSlashes = trimmed.replace(/^\/+/, "").replace(/\/+$/, "");
    if (!withoutSlashes) {
        return undefined;
    }
    return `https://${withoutSlashes}`;
}
function buildSfdxProjectJson(workspacePath, coreConfig) {
    const packageDirectories = coreConfig.sfdxProject.packageDirectories.length > 0
        ? coreConfig.sfdxProject.packageDirectories
        : [{ path: "force-app", default: true }];
    const defaultPath = packageDirectories.some((entry) => entry.default)
        ? packageDirectories
        : packageDirectories.map((entry, index) => ({
            path: entry.path,
            default: index === 0
        }));
    return {
        packageDirectories: defaultPath,
        name: coreConfig.sfdxProject.name || inferProjectNameFromPath(workspacePath),
        namespace: coreConfig.sfdxProject.namespace,
        sfdcLoginUrl: coreConfig.sfdxProject.sfdcLoginUrl,
        sourceApiVersion: coreConfig.sfdxProject.sourceApiVersion
    };
}
async function ensureSfdxProject(workspacePath, coreConfig, forceSync = false) {
    const projectFilePath = path.join(workspacePath, "sfdx-project.json");
    const desiredProject = buildSfdxProjectJson(workspacePath, coreConfig);
    const desiredSerialized = `${JSON.stringify(desiredProject, null, 2)}\n`;
    try {
        const raw = await fs_1.promises.readFile(projectFilePath, "utf8");
        if (!forceSync) {
            return false;
        }
        if (raw === desiredSerialized) {
            return false;
        }
    }
    catch {
        // continue
    }
    for (const packageDirectory of desiredProject.packageDirectories) {
        await fs_1.promises.mkdir(path.join(workspacePath, packageDirectory.path, "main", "default"), {
            recursive: true
        });
    }
    await fs_1.promises.writeFile(projectFilePath, desiredSerialized, "utf8");
    return true;
}
async function runInit(workspacePath) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    await (0, gitforceLocalConfig_1.ensureGitforceLocalConfigIgnored)(workspacePath);
    const createdSfdxProject = await ensureSfdxProject(workspacePath, coreConfig, true);
    const artifacts = await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, coreConfig);
    process.stdout.write("Gitforce initialized.\n");
    process.stdout.write(`- ${path.relative(workspacePath, (0, gitforceCore_1.getGitforceCoreConfigPath)(workspacePath))}\n`);
    process.stdout.write(`- ${path.relative(workspacePath, (0, gitforceLocalConfig_1.getGitforceLocalConfigPath)(workspacePath))}\n`);
    process.stdout.write(`- sfdx-project.json (${createdSfdxProject ? "created/updated" : "already up to date"})\n`);
    process.stdout.write("- .gitignore updated for local config safety\n");
    for (const artifact of artifacts) {
        process.stdout.write(`- ${artifact.relativePath}\n`);
    }
    const activeAlias = localConfig.salesforce.activeEnvironment === "production"
        ? localConfig.salesforce.productionOrgAlias
        : localConfig.salesforce.activeEnvironment === "sandbox"
            ? localConfig.salesforce.sandboxOrgAlias
            : localConfig.salesforce.developmentOrgAlias;
    process.stdout.write(`Active local environment: ${localConfig.salesforce.activeEnvironment} (${activeAlias || "org alias not set"})\n`);
}
async function runValidate(workspacePath, options) {
    const coreConfig = await (0, gitforceCore_1.readGitforceCoreConfig)(workspacePath);
    if (!coreConfig) {
        throw new Error("Missing gitforce-project.json. Run `gitforce init` first.");
    }
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    const result = (0, gitforceValidation_1.combineValidationResults)((0, gitforceValidation_1.validateGitforceCoreConfig)(coreConfig), (0, gitforceValidation_1.validateGitforceLocalConfig)(localConfig));
    printList("Errors:", result.errors);
    printList("Warnings:", result.warnings);
    if (result.errors.length > 0) {
        throw new Error(`Validation failed with ${result.errors.length} error(s).`);
    }
    if (options.strict && result.warnings.length > 0) {
        throw new Error(`Validation failed in strict mode with ${result.warnings.length} warning(s).`);
    }
    process.stdout.write("Validation passed.\n");
}
async function runDoctor(workspacePath) {
    const checks = [];
    checks.push({ name: "node", ok: commandExists("node") });
    checks.push({ name: "git", ok: commandExists("git") });
    checks.push({ name: "sf", ok: commandExists("sf") });
    checks.push({ name: "gh", ok: commandExists("gh") });
    const coreConfig = await (0, gitforceCore_1.readGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    checks.push({
        name: "gitforce-project.json",
        ok: Boolean(coreConfig),
        detail: coreConfig ? "found" : "missing"
    });
    checks.push({
        name: ".gitforce/local.config.json",
        ok: Boolean(localConfig),
        detail: localConfig ? "found" : "missing"
    });
    const sfdxProjectPath = path.join(workspacePath, "sfdx-project.json");
    try {
        await fs_1.promises.access(sfdxProjectPath);
        checks.push({ name: "sfdx-project.json", ok: true, detail: "found" });
    }
    catch {
        checks.push({ name: "sfdx-project.json", ok: false, detail: "missing" });
    }
    process.stdout.write("Gitforce doctor\n");
    for (const check of checks) {
        process.stdout.write(`- [${check.ok ? "ok" : "fail"}] ${check.name}${check.detail ? ` (${check.detail})` : ""}\n`);
    }
    const failures = checks.filter((check) => !check.ok);
    if (failures.length > 0) {
        throw new Error(`Doctor found ${failures.length} failing check(s).`);
    }
}
async function runGenerateBasicTests(workspacePath) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const generated = await (0, gitforceBasicTests_1.writeGeneratedBasicApexTest)(workspacePath, coreConfig.basicTests);
    coreConfig.tests.generatedApexClassName = generated.className;
    coreConfig.basicTests.generatedClassName = generated.className;
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    process.stdout.write("Generated Apex basic test class from catalog.\n");
    process.stdout.write(`- ${path.relative(workspacePath, generated.classPath)}\n`);
    process.stdout.write(`- ${path.relative(workspacePath, generated.metaPath)}\n`);
    process.stdout.write(`- Updated gitforce-project.json tests.generatedApexClassName=${generated.className}\n`);
}
async function runTest(workspacePath, parsed) {
    if (!commandExists("sf")) {
        throw new Error("Missing Salesforce CLI (`sf`). Install it and re-run `gitforce test`.");
    }
    const coreConfig = await (0, gitforceCore_1.readGitforceCoreConfig)(workspacePath);
    if (!coreConfig) {
        throw new Error("Missing gitforce-project.json. Run `gitforce init` first.");
    }
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    const environment = normalizeEnvironment(getFlagString(parsed, "environment") || localConfig?.salesforce.activeEnvironment);
    const explicitOrgAlias = getFlagString(parsed, "target-org") ||
        getFlagString(parsed, "targetorg") ||
        getFlagString(parsed, "org-alias") ||
        getFlagString(parsed, "alias");
    const aliasFromEnvironment = localConfig
        ? resolveAliasForEnvironment(localConfig, coreConfig, environment)
        : undefined;
    const targetAlias = [
        explicitOrgAlias,
        aliasFromEnvironment,
        coreConfig.environments.targetOrgAlias,
        (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(localConfig)
    ]
        .map((entry) => entry?.trim())
        .find(Boolean);
    if (!targetAlias) {
        throw new Error("No target Salesforce org alias found. Pass --target-org/--org-alias or run `gitforce auth:salesforce` first.");
    }
    const classNames = parseCsvList(getFlagString(parsed, "class-names") || getFlagString(parsed, "classes"));
    const suiteNames = parseCsvList(getFlagString(parsed, "suite-names") || getFlagString(parsed, "suites"));
    let tests = parseCsvList(getFlagString(parsed, "tests"));
    const selectorGroups = [
        { flag: "--class-names", values: classNames },
        { flag: "--suite-names", values: suiteNames },
        { flag: "--tests", values: tests }
    ].filter((entry) => entry.values.length > 0);
    if (selectorGroups.length > 1) {
        throw new Error("Choose only one test selector type: --class-names, --suite-names, or --tests.");
    }
    const testLevelInput = getFlagString(parsed, "test-level") || getFlagString(parsed, "level");
    const requestedTestLevel = normalizeTestLevelFlag(testLevelInput);
    if (testLevelInput && !requestedTestLevel) {
        throw new Error('Invalid --test-level value. Use "RunLocalTests", "RunAllTestsInOrg", or "RunSpecifiedTests".');
    }
    let resolvedTestLevel = requestedTestLevel ?? coreConfig.deploy.testLevel;
    if (selectorGroups.length > 0) {
        if (requestedTestLevel && requestedTestLevel !== "RunSpecifiedTests") {
            throw new Error("When using --class-names, --suite-names, or --tests, --test-level must be RunSpecifiedTests.");
        }
        resolvedTestLevel = "RunSpecifiedTests";
    }
    if (resolvedTestLevel === "RunSpecifiedTests" && selectorGroups.length === 0) {
        tests = [...new Set(coreConfig.deploy.specifiedTests.map((entry) => entry.trim()).filter(Boolean))];
        if (tests.length === 0) {
            throw new Error("RunSpecifiedTests requires selectors. Pass --tests/--class-names/--suite-names, or set deploy.specifiedTests in gitforce-project.json.");
        }
    }
    const resultFormatInput = getFlagString(parsed, "result-format") || getFlagString(parsed, "format");
    const resultFormat = normalizeApexTestResultFormat(resultFormatInput);
    if (resultFormatInput && !resultFormat) {
        throw new Error('Invalid --result-format value. Use "human", "tap", "junit", or "json".');
    }
    const codeCoverageRequested = getFlagBoolean(parsed, "code-coverage", false) || getFlagBoolean(parsed, "coverage", false);
    const detailedCoverageRequested = getFlagBoolean(parsed, "detailed-coverage", false) || getFlagBoolean(parsed, "detailed", false);
    const includeCodeCoverage = codeCoverageRequested || detailedCoverageRequested;
    const waitMinutes = getFlagNumber(parsed, "wait");
    if (waitMinutes !== undefined && (!Number.isFinite(waitMinutes) || waitMinutes < 0)) {
        throw new Error("--wait must be a non-negative number of minutes.");
    }
    const pollIntervalSeconds = getFlagNumber(parsed, "poll-interval");
    if (pollIntervalSeconds !== undefined && (!Number.isFinite(pollIntervalSeconds) || pollIntervalSeconds <= 0)) {
        throw new Error("--poll-interval must be a positive number of seconds.");
    }
    const outputDir = getFlagString(parsed, "output-dir");
    const apiVersion = getFlagString(parsed, "api-version");
    const synchronous = getFlagBoolean(parsed, "synchronous", false);
    const concise = getFlagBoolean(parsed, "concise", false);
    if (concise && (resultFormat ?? "human") !== "human") {
        process.stdout.write('Warning: --concise only applies to result format "human"; ignoring --concise.\n');
    }
    const sfArgs = [
        "apex",
        "run",
        "test",
        "--target-org",
        targetAlias,
        "--test-level",
        resolvedTestLevel,
        "--result-format",
        resultFormat ?? "human"
    ];
    for (const className of classNames) {
        sfArgs.push("--class-names", className);
    }
    for (const suiteName of suiteNames) {
        sfArgs.push("--suite-names", suiteName);
    }
    for (const testName of tests) {
        sfArgs.push("--tests", testName);
    }
    if (includeCodeCoverage) {
        sfArgs.push("--code-coverage");
    }
    if (detailedCoverageRequested) {
        sfArgs.push("--detailed-coverage");
    }
    if (waitMinutes !== undefined) {
        sfArgs.push("--wait", `${waitMinutes}`);
    }
    if (pollIntervalSeconds !== undefined) {
        sfArgs.push("--poll-interval", `${pollIntervalSeconds}`);
    }
    if (outputDir) {
        sfArgs.push("--output-dir", outputDir);
    }
    if (apiVersion) {
        sfArgs.push("--api-version", apiVersion);
    }
    if (synchronous) {
        sfArgs.push("--synchronous");
    }
    if (concise && (resultFormat ?? "human") === "human") {
        sfArgs.push("--concise");
    }
    const timeoutMinutes = Math.max(waitMinutes ?? 30, 10) + 5;
    logStep(`Running Apex tests on "${targetAlias}" (level: ${resolvedTestLevel})...`);
    const { stdout, stderr } = await (0, shell_1.runCommand)("sf", sfArgs, workspacePath, {
        timeoutMs: timeoutMinutes * 60 * 1000,
        maxBufferBytes: 50 * 1024 * 1024
    });
    if (stdout) {
        process.stdout.write(`${stdout}\n`);
    }
    if (stderr) {
        process.stdout.write(`${stderr}\n`);
    }
}
async function runCoverage(workspacePath, parsed) {
    if (!commandExists("sf")) {
        throw new Error("Missing Salesforce CLI (`sf`). Install it and re-run `gitforce coverage`.");
    }
    const coreConfig = await (0, gitforceCore_1.readGitforceCoreConfig)(workspacePath);
    if (!coreConfig) {
        throw new Error("Missing gitforce-project.json. Run `gitforce init` first.");
    }
    const outputFormat = (getFlagString(parsed, "format") || "table").trim().toLowerCase();
    if (!["table", "json"].includes(outputFormat)) {
        throw new Error('Invalid --format value. Use "table" or "json".');
    }
    const historyPath = path.resolve(workspacePath, getFlagString(parsed, "history-file") || ".gitforce/coverage-history.json");
    const saveHistory = getFlagBoolean(parsed, "save", true);
    const historyLimit = Math.max(1, Math.min(200, parseInteger(getFlagNumber(parsed, "history-limit"), 50)));
    const trendLast = Math.max(1, Math.min(100, parseInteger(getFlagNumber(parsed, "last"), 5)));
    const topCount = Math.max(1, Math.min(100, parseInteger(getFlagNumber(parsed, "top"), 10)));
    const classNameFilter = getFlagString(parsed, "class") || getFlagString(parsed, "class-name");
    const testRunIdFromFlag = getFlagString(parsed, "run-id") || getFlagString(parsed, "test-run-id");
    const hasRunArgs = [
        "test-level",
        "level",
        "class-names",
        "classes",
        "suite-names",
        "suites",
        "tests",
        "wait",
        "poll-interval",
        "api-version",
        "output-dir",
        "target-org",
        "targetorg",
        "org-alias",
        "alias",
        "environment",
        "synchronous",
        "concise"
    ].some((flag) => parsed.flags.has(flag));
    const historyOnly = getFlagBoolean(parsed, "history", false) && !testRunIdFromFlag && !hasRunArgs;
    if (historyOnly) {
        const history = await readCoverageHistory(historyPath);
        const snapshots = history.snapshots.slice(-trendLast);
        if (outputFormat === "json") {
            process.stdout.write(`${JSON.stringify({
                historyPath,
                count: history.snapshots.length,
                snapshots
            }, null, 2)}\n`);
            return;
        }
        if (history.snapshots.length === 0) {
            process.stdout.write(`No coverage history found at ${historyPath}.\n`);
            return;
        }
        process.stdout.write(`Coverage history file: ${historyPath}\n`);
        process.stdout.write(`${renderCoverageTrend(history.snapshots, trendLast).join("\n")}\n`);
        return;
    }
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    const environment = normalizeEnvironment(getFlagString(parsed, "environment") || localConfig?.salesforce.activeEnvironment);
    const explicitOrgAlias = getFlagString(parsed, "target-org") ||
        getFlagString(parsed, "targetorg") ||
        getFlagString(parsed, "org-alias") ||
        getFlagString(parsed, "alias");
    const aliasFromEnvironment = localConfig
        ? resolveAliasForEnvironment(localConfig, coreConfig, environment)
        : undefined;
    const targetAlias = [
        explicitOrgAlias,
        aliasFromEnvironment,
        coreConfig.environments.targetOrgAlias,
        (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(localConfig)
    ]
        .map((entry) => entry?.trim())
        .find(Boolean);
    if (!targetAlias) {
        throw new Error("No target Salesforce org alias found. Pass --target-org/--org-alias or run `gitforce auth:salesforce` first.");
    }
    const outputDir = getFlagString(parsed, "output-dir");
    const apiVersion = getFlagString(parsed, "api-version");
    const pollIntervalSeconds = getFlagNumber(parsed, "poll-interval");
    if (pollIntervalSeconds !== undefined && (!Number.isFinite(pollIntervalSeconds) || pollIntervalSeconds <= 0)) {
        throw new Error("--poll-interval must be a positive number of seconds.");
    }
    const concise = getFlagBoolean(parsed, "concise", false);
    const synchronous = getFlagBoolean(parsed, "synchronous", false);
    const waitMinutesRaw = getFlagNumber(parsed, "wait");
    if (waitMinutesRaw !== undefined && (!Number.isFinite(waitMinutesRaw) || waitMinutesRaw < 0)) {
        throw new Error("--wait must be a non-negative number of minutes.");
    }
    const waitMinutes = waitMinutesRaw ?? 30;
    let payload;
    if (testRunIdFromFlag) {
        const reportArgs = [
            "apex",
            "get",
            "test",
            "--target-org",
            targetAlias,
            "--test-run-id",
            testRunIdFromFlag,
            "--code-coverage",
            "--result-format",
            "json"
        ];
        if (outputDir) {
            reportArgs.push("--output-dir", outputDir);
        }
        if (apiVersion) {
            reportArgs.push("--api-version", apiVersion);
        }
        if (concise) {
            reportArgs.push("--concise");
        }
        logStep(`Fetching Apex coverage for test run "${testRunIdFromFlag}" on "${targetAlias}"...`);
        payload = await runSfJsonCommand(workspacePath, reportArgs, {
            timeoutMs: Math.max(waitMinutes, 10) * 60 * 1000,
            maxBufferBytes: 50 * 1024 * 1024
        });
    }
    else {
        const classNames = parseCsvList(getFlagString(parsed, "class-names") || getFlagString(parsed, "classes"));
        const suiteNames = parseCsvList(getFlagString(parsed, "suite-names") || getFlagString(parsed, "suites"));
        let tests = parseCsvList(getFlagString(parsed, "tests"));
        const selectorGroups = [
            { flag: "--class-names", values: classNames },
            { flag: "--suite-names", values: suiteNames },
            { flag: "--tests", values: tests }
        ].filter((entry) => entry.values.length > 0);
        if (selectorGroups.length > 1) {
            throw new Error("Choose only one test selector type: --class-names, --suite-names, or --tests.");
        }
        const testLevelInput = getFlagString(parsed, "test-level") || getFlagString(parsed, "level");
        const requestedTestLevel = normalizeTestLevelFlag(testLevelInput);
        if (testLevelInput && !requestedTestLevel) {
            throw new Error('Invalid --test-level value. Use "RunLocalTests", "RunAllTestsInOrg", or "RunSpecifiedTests".');
        }
        let resolvedTestLevel = requestedTestLevel ?? coreConfig.deploy.testLevel;
        if (selectorGroups.length > 0) {
            if (requestedTestLevel && requestedTestLevel !== "RunSpecifiedTests") {
                throw new Error("When using --class-names, --suite-names, or --tests, --test-level must be RunSpecifiedTests.");
            }
            resolvedTestLevel = "RunSpecifiedTests";
        }
        if (resolvedTestLevel === "RunSpecifiedTests" && selectorGroups.length === 0) {
            tests = [...new Set(coreConfig.deploy.specifiedTests.map((entry) => entry.trim()).filter(Boolean))];
            if (tests.length === 0) {
                throw new Error("RunSpecifiedTests requires selectors. Pass --tests/--class-names/--suite-names, or set deploy.specifiedTests in gitforce-project.json.");
            }
        }
        const sfArgs = [
            "apex",
            "run",
            "test",
            "--target-org",
            targetAlias,
            "--test-level",
            resolvedTestLevel,
            "--result-format",
            "json",
            "--code-coverage",
            "--wait",
            `${waitMinutes}`
        ];
        for (const className of classNames) {
            sfArgs.push("--class-names", className);
        }
        for (const suiteName of suiteNames) {
            sfArgs.push("--suite-names", suiteName);
        }
        for (const testName of tests) {
            sfArgs.push("--tests", testName);
        }
        if (pollIntervalSeconds !== undefined) {
            sfArgs.push("--poll-interval", `${pollIntervalSeconds}`);
        }
        if (outputDir) {
            sfArgs.push("--output-dir", outputDir);
        }
        if (apiVersion) {
            sfArgs.push("--api-version", apiVersion);
        }
        if (synchronous) {
            sfArgs.push("--synchronous");
        }
        if (concise) {
            sfArgs.push("--concise");
        }
        logStep(`Running Apex coverage tests on "${targetAlias}" (level: ${resolvedTestLevel})...`);
        payload = await runSfJsonCommand(workspacePath, sfArgs, {
            timeoutMs: Math.max(waitMinutes, 10) * 60 * 1000 + 5 * 60 * 1000,
            maxBufferBytes: 50 * 1024 * 1024
        });
    }
    let snapshot = parseCoverageSnapshotFromSfPayload(payload, targetAlias);
    if (!snapshot) {
        throw new Error("Could not parse coverage result payload from Salesforce CLI output.");
    }
    if (snapshot.classCoverage.length === 0 && snapshot.testRunId) {
        logStep(`Coverage class details were not returned in initial payload. Fetching full report for run "${snapshot.testRunId}"...`);
        const reportPayload = await runSfJsonCommand(workspacePath, [
            "apex",
            "get",
            "test",
            "--target-org",
            targetAlias,
            "--test-run-id",
            snapshot.testRunId,
            "--code-coverage",
            "--result-format",
            "json"
        ], {
            timeoutMs: Math.max(waitMinutes, 10) * 60 * 1000,
            maxBufferBytes: 50 * 1024 * 1024
        });
        const fallbackSnapshot = parseCoverageSnapshotFromSfPayload(reportPayload, targetAlias);
        if (fallbackSnapshot) {
            snapshot = fallbackSnapshot;
        }
    }
    const history = await readCoverageHistory(historyPath);
    if (saveHistory) {
        history.snapshots.push(snapshot);
        history.snapshots = history.snapshots.slice(-historyLimit);
        await writeCoverageHistory(historyPath, history);
    }
    if (outputFormat === "json") {
        process.stdout.write(`${JSON.stringify({
            saved: saveHistory,
            historyPath,
            snapshot,
            trend: history.snapshots.slice(-trendLast)
        }, null, 2)}\n`);
        return;
    }
    process.stdout.write(`${renderCoverageSnapshot(snapshot, classNameFilter, topCount).join("\n")}\n`);
    if (saveHistory) {
        process.stdout.write(`Coverage history saved: ${historyPath}\n`);
    }
    else {
        process.stdout.write("Coverage history save skipped (--no-save).\n");
    }
    if (history.snapshots.length > 0) {
        process.stdout.write(`${renderCoverageTrend(history.snapshots, trendLast).join("\n")}\n`);
    }
}
function resolveTargetAliasFromConfigs(parsed, coreConfig, localConfig) {
    const environment = normalizeEnvironment(getFlagString(parsed, "environment") || localConfig?.salesforce.activeEnvironment);
    const explicitOrgAlias = getFlagString(parsed, "target-org") ||
        getFlagString(parsed, "targetorg") ||
        getFlagString(parsed, "org-alias") ||
        getFlagString(parsed, "alias");
    const aliasFromEnvironment = localConfig
        ? resolveAliasForEnvironment(localConfig, coreConfig, environment)
        : undefined;
    const targetAlias = [
        explicitOrgAlias,
        aliasFromEnvironment,
        coreConfig.environments.targetOrgAlias,
        (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(localConfig)
    ]
        .map((entry) => entry?.trim())
        .find(Boolean);
    return { targetAlias, environment };
}
function resolveDeploySuiteTestConfig(parsed, coreConfig) {
    const testLevelInput = getFlagString(parsed, "test-level") || getFlagString(parsed, "level");
    const requestedTestLevel = normalizeTestLevelFlag(testLevelInput);
    if (testLevelInput && !requestedTestLevel) {
        throw new Error('Invalid --test-level value. Use "RunLocalTests", "RunAllTestsInOrg", or "RunSpecifiedTests".');
    }
    let tests = parseCsvList(getFlagString(parsed, "tests"));
    let testLevel = requestedTestLevel ?? coreConfig.deploy.testLevel;
    if (tests.length > 0 && testLevel !== "RunSpecifiedTests") {
        testLevel = "RunSpecifiedTests";
    }
    if (testLevel === "RunSpecifiedTests" && tests.length === 0) {
        tests = [...new Set(coreConfig.deploy.specifiedTests.map((entry) => entry.trim()).filter(Boolean))];
        if (tests.length === 0) {
            throw new Error("RunSpecifiedTests requires --tests or deploy.specifiedTests in gitforce-project.json.");
        }
    }
    return { testLevel, tests };
}
async function queryOrgWideCoveragePercent(workspacePath, targetAlias) {
    const payload = await runSfJsonCommand(workspacePath, [
        "data",
        "query",
        "--target-org",
        targetAlias,
        "--query",
        "SELECT PercentCovered FROM ApexOrgWideCoverage",
        "--use-tooling-api",
        "--result-format",
        "json"
    ], {
        timeoutMs: 5 * 60 * 1000,
        maxBufferBytes: 5 * 1024 * 1024
    });
    const root = toObject(payload);
    const result = toObject(root?.result);
    const records = toArray(result?.records);
    for (const record of records) {
        const typed = toObject(record);
        const value = parseNumber(typed?.PercentCovered);
        if (value !== undefined) {
            return value;
        }
    }
    return undefined;
}
async function resolveExistingDeploySourcePaths(workspacePath, sourcePaths) {
    const existing = [];
    const missing = [];
    for (const sourcePath of sourcePaths) {
        const absolutePath = path.resolve(workspacePath, sourcePath);
        try {
            await fs_1.promises.access(absolutePath);
            existing.push(sourcePath);
        }
        catch {
            missing.push(sourcePath);
        }
    }
    return { existing, missing };
}
async function listGitTrackedFiles(workspacePath) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["ls-files"], workspacePath, {
        timeoutMs: 2 * 60 * 1000,
        maxBufferBytes: 25 * 1024 * 1024
    });
    return stdout
        .split(/\r?\n/)
        .map((entry) => entry.trim())
        .filter(Boolean)
        .map((entry) => entry.replace(/\\/g, "/"));
}
function renderDeploySuiteSummary(selectedItems, deletedCount, unknownCount) {
    const lines = [];
    const byMetadataType = new Map();
    for (const item of selectedItems) {
        byMetadataType.set(item.metadataType, (byMetadataType.get(item.metadataType) ?? 0) + 1);
    }
    lines.push("Gitforce Deployment Suite");
    lines.push(`- Deployable components: ${selectedItems.length}`);
    lines.push(`- Deleted components in diff: ${deletedCount}`);
    lines.push(`- Unknown/unsupported changed files: ${unknownCount}`);
    if (byMetadataType.size > 0) {
        lines.push("- Components by metadata type:");
        for (const [metadataType, count] of [...byMetadataType.entries()].sort((l, r) => l[0].localeCompare(r[0]))) {
            lines.push(`  - ${metadataType}: ${count}`);
        }
    }
    const frontendTypes = new Set([
        "LightningComponentBundle",
        "AuraDefinitionBundle",
        "CustomObject",
        "CustomField",
        "Layout"
    ]);
    const frontendChanges = selectedItems.filter((item) => frontendTypes.has(item.metadataType));
    if (frontendChanges.length > 0) {
        lines.push("- Frontend-impact warning:");
        lines.push("  - This deployment includes UI/data-model metadata. Coordinate with frontend consumers before deploy.");
        lines.push(`  - Potentially impacted components: ${frontendChanges.slice(0, 8).map((item) => item.componentName).join(", ")}${frontendChanges.length > 8 ? " ..." : ""}`);
    }
    if (deletedCount > 0) {
        lines.push("- Delete warning:");
        lines.push("  - File deletions in tracked paths are not deployed destructively by default. Use delete-intent workflow for org deletes.");
    }
    return lines;
}
async function runDeploySuite(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    if (!commandExists("sf")) {
        throw new Error("Missing Salesforce CLI (`sf`). Install it and re-run `gitforce deploy:suite`.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    const aliasResolution = resolveTargetAliasFromConfigs(parsed, coreConfig, localConfig);
    const apply = getFlagBoolean(parsed, "apply", false);
    const dryRun = getFlagBoolean(parsed, "dry-run", false);
    if (apply && dryRun) {
        throw new Error("Choose only one execution mode: --apply or --dry-run.");
    }
    const modeFromFlag = normalizeDeploymentSuiteMode(getFlagString(parsed, "mode"));
    if (getFlagString(parsed, "mode") && !modeFromFlag) {
        throw new Error('Invalid --mode value. Use "report", "validate", or "deploy".');
    }
    const mode = modeFromFlag ?? (apply ? "deploy" : dryRun ? "validate" : "report");
    const remote = getFlagString(parsed, "remote") || "origin";
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const baseRef = getFlagString(parsed, "base") || `${remote}/${baseBranch}`;
    const headRef = getFlagString(parsed, "head") || "HEAD";
    if (await (0, git_1.remoteExists)(workspacePath, remote)) {
        await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    }
    const { stdout: diffOutput } = await (0, shell_1.runCommand)("git", ["diff", "--name-status", `${baseRef}...${headRef}`], workspacePath);
    const diffEntries = (0, changeIntelligence_1.parseGitNameStatus)(diffOutput);
    const plan = (0, deployPlan_1.buildDeployPlan)(diffEntries, coreConfig.tracked.paths, coreConfig.tracked.metadataTypes);
    let selectedItems = [...plan.items];
    const explicitComponents = parseCsvList(getFlagString(parsed, "components"));
    if (explicitComponents.length > 0) {
        const byPath = new Map(selectedItems.map((item) => [item.sourcePath, item]));
        selectedItems = explicitComponents
            .map((componentPath) => byPath.get(componentPath))
            .filter((entry) => Boolean(entry));
        if (selectedItems.length === 0) {
            throw new Error("None of the paths from --components matched deployable tracked components from the selected diff.");
        }
    }
    const selectRequested = parsed.flags.has("select")
        ? getFlagBoolean(parsed, "select", true)
        : mode !== "report" && process.stdin.isTTY && process.stdout.isTTY;
    if (selectRequested && explicitComponents.length === 0) {
        selectedItems = await promptForDeployComponentSelection(selectedItems);
    }
    const { existing: selectedSourcePaths, missing: missingSourcePaths } = await resolveExistingDeploySourcePaths(workspacePath, selectedItems.map((item) => item.sourcePath));
    const selectedExistingItems = selectedItems.filter((item) => selectedSourcePaths.includes(item.sourcePath));
    for (const line of renderDeploySuiteSummary(selectedExistingItems, plan.deleted.length, plan.skippedUnknown.length)) {
        process.stdout.write(`${line}\n`);
    }
    if (missingSourcePaths.length > 0) {
        process.stdout.write(`Warning: ${missingSourcePaths.length} selected path(s) were not found locally and were skipped.\n`);
    }
    if (selectedSourcePaths.length === 0) {
        if (mode === "report") {
            process.stdout.write("No deployable tracked source paths selected.\n");
            return;
        }
        throw new Error("No deployable tracked source paths selected.");
    }
    const strict = getFlagBoolean(parsed, "strict", false);
    const checkMissingMetadata = getFlagBoolean(parsed, "check-missing-metadata", true);
    const failOnMissingMetadata = getFlagBoolean(parsed, "fail-on-missing-metadata", strict);
    if (checkMissingMetadata) {
        logStep("Running metadata completeness checks...");
        const trackedFiles = await listGitTrackedFiles(workspacePath);
        const metadataCompletenessReport = (0, deployMetadataChecks_1.buildDeployMetadataCompletenessReport)(trackedFiles, selectedExistingItems);
        const presentFamilyCount = metadataCompletenessReport.familyCoverage.filter((entry) => entry.count > 0).length;
        process.stdout.write(`- Metadata family coverage: ${presentFamilyCount}/${metadataCompletenessReport.familyCoverage.length} present\n`);
        const missingFamilies = metadataCompletenessReport.familyCoverage
            .filter((entry) => entry.count === 0)
            .map((entry) => entry.label);
        if (missingFamilies.length > 0) {
            const preview = missingFamilies.slice(0, 8).join(", ");
            process.stdout.write(`- Missing metadata families: ${preview}${missingFamilies.length > 8 ? " ..." : ""}\n`);
        }
        if (metadataCompletenessReport.requiredMissing.length > 0) {
            process.stdout.write("- Required metadata gaps:\n");
            for (const issue of metadataCompletenessReport.requiredMissing) {
                process.stdout.write(`  - ${issue.label}: ${issue.reason}\n`);
                process.stdout.write(`    Missing: ${issue.missingPaths.join(", ")}\n`);
            }
        }
        if (metadataCompletenessReport.recommendedMissing.length > 0) {
            process.stdout.write("- Recommended metadata gaps:\n");
            for (const issue of metadataCompletenessReport.recommendedMissing) {
                process.stdout.write(`  - ${issue.label}: ${issue.reason}\n`);
                process.stdout.write(`    Missing: ${issue.missingPaths.join(", ")}\n`);
            }
        }
        if (failOnMissingMetadata && metadataCompletenessReport.requiredMissing.length > 0) {
            throw new Error("Deployment suite blocked because required metadata gaps were detected. Add missing metadata or re-run with --no-fail-on-missing-metadata.");
        }
    }
    const { testLevel, tests } = resolveDeploySuiteTestConfig(parsed, coreConfig);
    const checkCoverage = getFlagBoolean(parsed, "check-coverage", mode !== "report");
    const checkConflicts = getFlagBoolean(parsed, "check-conflicts", mode !== "report");
    const checkValidate = parsed.flags.has("check-validate")
        ? getFlagBoolean(parsed, "check-validate", true)
        : mode !== "report";
    const coverageThresholdRaw = getFlagNumber(parsed, "coverage-threshold");
    const coverageThreshold = coverageThresholdRaw !== undefined
        ? coverageThresholdRaw
        : 75;
    if (!Number.isFinite(coverageThreshold) || coverageThreshold < 0 || coverageThreshold > 100) {
        throw new Error("--coverage-threshold must be a number between 0 and 100.");
    }
    const requiresOrgAlias = checkCoverage || checkConflicts || checkValidate || mode !== "report";
    const targetAlias = aliasResolution.targetAlias;
    if (requiresOrgAlias && !targetAlias) {
        throw new Error("No target Salesforce org alias found. Pass --target-org/--org-alias or run `gitforce auth:salesforce` first.");
    }
    process.stdout.write(`- Target org alias: ${targetAlias ?? "(not required for report-only mode)"}\n`);
    process.stdout.write(`- Mode: ${mode}\n`);
    process.stdout.write(`- Test level: ${testLevel}\n`);
    if (tests.length > 0) {
        process.stdout.write(`- Tests: ${tests.join(", ")}\n`);
    }
    const resolvedTargetAlias = targetAlias ?? "";
    let coverageFailure = false;
    if (checkCoverage) {
        logStep("Checking org-wide Apex coverage...");
        try {
            const coveragePercent = await queryOrgWideCoveragePercent(workspacePath, resolvedTargetAlias);
            if (coveragePercent === undefined) {
                process.stdout.write("Warning: Could not determine org-wide Apex coverage.\n");
            }
            else {
                process.stdout.write(`- Org-wide Apex coverage: ${coveragePercent.toFixed(2)}% (threshold ${coverageThreshold.toFixed(2)}%)\n`);
                if (coveragePercent < coverageThreshold) {
                    coverageFailure = true;
                    process.stdout.write("Warning: Coverage is below threshold. Consider running targeted tests or increasing coverage before deploy.\n");
                }
            }
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            process.stdout.write(`Warning: Apex coverage check failed (${message}).\n`);
        }
    }
    if (checkConflicts) {
        logStep("Running Salesforce deploy preview for conflict detection...");
        const previewPayload = await runSfJsonCommand(workspacePath, [
            "project",
            "deploy",
            "preview",
            "--target-org",
            resolvedTargetAlias,
            ...selectedSourcePaths.flatMap((sourcePath) => ["--source-dir", sourcePath])
        ], {
            timeoutMs: 15 * 60 * 1000,
            maxBufferBytes: 25 * 1024 * 1024
        });
        const previewRoot = toObject(previewPayload);
        const previewStatus = parseNumber(previewRoot?.status) ?? 0;
        if (previewStatus !== 0) {
            const code = parseString(previewRoot?.code) || parseString(previewRoot?.name) || "PreviewError";
            const message = parseString(previewRoot?.message) || "Deploy preview returned an error.";
            if (code === "NonSourceTrackedOrgError") {
                process.stdout.write("Warning: Deploy preview conflict check is unavailable for this org (no source tracking).\n");
            }
            else if (strict) {
                throw new Error(`Deploy preview failed (${code}): ${message}`);
            }
            else {
                process.stdout.write(`Warning: Deploy preview failed (${code}): ${message}\n`);
            }
        }
        else {
            const previewResult = toObject(previewRoot?.result);
            const conflictCount = toArray(previewResult?.conflicts).length +
                toArray(previewResult?.conflictFiles).length;
            const ignoredCount = toArray(previewResult?.ignoredFiles).length +
                toArray(previewResult?.ignored).length;
            process.stdout.write(`- Deploy preview completed${conflictCount > 0 ? ` with ${conflictCount} potential conflict(s)` : " with no reported conflicts"}.\n`);
            if (ignoredCount > 0) {
                process.stdout.write(`- Preview ignored files: ${ignoredCount}\n`);
            }
            if (strict && conflictCount > 0) {
                throw new Error(`Strict mode blocked deployment because ${conflictCount} potential conflict(s) were detected.`);
            }
        }
    }
    if (strict && coverageFailure) {
        throw new Error("Strict mode blocked deployment because org-wide Apex coverage is below threshold.");
    }
    const shouldRunValidate = checkValidate || mode === "validate";
    if (shouldRunValidate) {
        logStep("Running Salesforce deployment validation...");
        const validateArgs = [
            "project",
            "deploy",
            "validate",
            "--target-org",
            resolvedTargetAlias,
            "--test-level",
            testLevel,
            ...selectedSourcePaths.flatMap((sourcePath) => ["--source-dir", sourcePath]),
            ...tests.flatMap((testName) => ["--tests", testName])
        ];
        const { stdout, stderr } = await (0, shell_1.runCommand)("sf", validateArgs, workspacePath, {
            timeoutMs: 60 * 60 * 1000,
            maxBufferBytes: 100 * 1024 * 1024
        });
        if (stdout) {
            process.stdout.write(`${stdout}\n`);
        }
        if (stderr) {
            process.stdout.write(`${stderr}\n`);
        }
    }
    if (mode === "deploy") {
        logStep("Executing Salesforce deployment...");
        const deployArgs = [
            "project",
            "deploy",
            "start",
            "--target-org",
            resolvedTargetAlias,
            "--test-level",
            testLevel,
            ...selectedSourcePaths.flatMap((sourcePath) => ["--source-dir", sourcePath]),
            ...tests.flatMap((testName) => ["--tests", testName])
        ];
        const { stdout, stderr } = await (0, shell_1.runCommand)("sf", deployArgs, workspacePath, {
            timeoutMs: 60 * 60 * 1000,
            maxBufferBytes: 100 * 1024 * 1024
        });
        if (stdout) {
            process.stdout.write(`${stdout}\n`);
        }
        if (stderr) {
            process.stdout.write(`${stderr}\n`);
        }
        process.stdout.write("Deployment complete.\n");
        return;
    }
    if (mode === "validate") {
        process.stdout.write("Validation complete. Use --apply or --mode deploy to deploy.\n");
        return;
    }
    process.stdout.write("Report complete. Re-run with `gitforce deploy:suite --mode validate` or `--mode deploy --apply` to execute.\n");
}
async function resolveDefaultSalesforceAlias(workspacePath) {
    const { stdout } = await (0, shell_1.runCommand)("sf", ["org", "list", "--json"], workspacePath);
    const parsed = JSON.parse(stdout);
    const orgs = parsed.result?.nonScratchOrgs ?? [];
    const defaultOrg = orgs.find((org) => org.isDefaultUsername);
    if (!defaultOrg) {
        return undefined;
    }
    return (defaultOrg.alias ?? defaultOrg.username ?? "").trim() || undefined;
}
async function runAuthSalesforce(workspacePath, parsed) {
    const environment = normalizeEnvironment(getFlagString(parsed, "environment"));
    let alias = getFlagString(parsed, "alias");
    const login = getFlagBoolean(parsed, "login", true);
    const customDomain = getFlagString(parsed, "customdomain") ?? getFlagString(parsed, "custom-domain");
    const instanceUrl = normalizeInstanceUrl(getFlagString(parsed, "instance-url") ?? customDomain);
    const sandbox = getFlagBoolean(parsed, "sandbox", environment === "sandbox");
    if (login) {
        const loginAlias = alias || `gitforce-${environment}`;
        const args = ["org", "login", "web", "--alias", loginAlias, "--set-default"];
        if (instanceUrl) {
            args.push("--instance-url", instanceUrl);
        }
        else if (sandbox) {
            args.push("--instance-url", "https://test.salesforce.com");
        }
        runInteractiveCommand("sf", args, workspacePath);
        alias = loginAlias;
    }
    if (!alias) {
        alias = await resolveDefaultSalesforceAlias(workspacePath);
    }
    if (!alias) {
        throw new Error("No Salesforce org alias found. Pass --alias or run with --login.");
    }
    await (0, shell_1.runCommand)("sf", ["org", "display", "--target-org", alias, "--json"], workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    localConfig.salesforce.activeEnvironment = environment;
    setEnvironmentAlias(localConfig, environment, alias);
    await (0, gitforceLocalConfig_1.writeGitforceLocalConfig)(workspacePath, localConfig);
    if (environment === "production") {
        coreConfig.environments.productionOrgAlias = alias;
    }
    else if (environment === "sandbox") {
        coreConfig.environments.sandboxOrgAlias = alias;
    }
    else {
        coreConfig.environments.developmentOrgAlias = alias;
    }
    if (instanceUrl) {
        coreConfig.sfdxProject.sfdcLoginUrl = instanceUrl;
    }
    coreConfig.environments.targetOrgAlias = alias;
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    await ensureSfdxProject(workspacePath, coreConfig, true);
    process.stdout.write(`Connected Salesforce org alias "${alias}" for environment "${environment}".\n`);
}
async function runAuthGitHub(workspacePath, parsed) {
    const login = getFlagBoolean(parsed, "login", true);
    let githubUser;
    try {
        const { stdout } = await (0, shell_1.runCommand)("gh", ["api", "user", "--jq", ".login"], workspacePath);
        githubUser = stdout.trim() || undefined;
    }
    catch (error) {
        if (!login) {
            throw error;
        }
        runInteractiveCommand("gh", [
            "auth",
            "login",
            "--hostname",
            "github.com",
            "--web",
            "--git-protocol",
            "https",
            "--scopes",
            "repo"
        ], workspacePath);
        const { stdout } = await (0, shell_1.runCommand)("gh", ["api", "user", "--jq", ".login"], workspacePath);
        githubUser = stdout.trim() || undefined;
    }
    if (!githubUser) {
        throw new Error("Unable to determine authenticated GitHub user.");
    }
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    localConfig.github.host = "github.com";
    localConfig.github.user = githubUser;
    await (0, gitforceLocalConfig_1.writeGitforceLocalConfig)(workspacePath, localConfig);
    process.stdout.write(`Connected GitHub user "${githubUser}".\n`);
}
async function ensureGitIdentity(workspacePath, userHint) {
    try {
        const { stdout } = await (0, shell_1.runCommand)("git", ["config", "--get", "user.email"], workspacePath);
        if (stdout.trim()) {
            return;
        }
    }
    catch {
        // configure below
    }
    const userName = userHint?.trim() || "gitforce-bot";
    const email = userHint?.trim()
        ? `${userHint.trim()}@users.noreply.github.com`
        : "gitforce-bot@users.noreply.github.com";
    await (0, shell_1.runCommand)("git", ["config", "user.name", userName], workspacePath);
    await (0, shell_1.runCommand)("git", ["config", "user.email", email], workspacePath);
}
async function hasLocalChanges(workspacePath) {
    const { stdout } = await (0, shell_1.runCommand)("git", ["status", "--porcelain"], workspacePath);
    return stdout.trim().length > 0;
}
async function resolveSfdxAuthUrl(workspacePath, orgAlias) {
    const { stdout } = await (0, shell_1.runCommand)("sf", ["org", "display", "--target-org", orgAlias, "--verbose", "--json"], workspacePath);
    const parsed = JSON.parse(stdout);
    const authUrl = parsed.result?.sfdxAuthUrl?.trim();
    if (!authUrl) {
        throw new Error(`Could not resolve sfdxAuthUrl for org alias "${orgAlias}".`);
    }
    return authUrl;
}
async function syncSalesforceAuthSecrets(workspacePath, owner, repo, targetOrgAlias, validateOrgAlias, integrationOrgAlias) {
    const repoRef = `${owner}/${repo}`;
    const authUrlByAlias = new Map();
    const resolveCachedAuthUrl = async (alias) => {
        const existing = authUrlByAlias.get(alias);
        if (existing) {
            return existing;
        }
        const resolved = await resolveSfdxAuthUrl(workspacePath, alias);
        authUrlByAlias.set(alias, resolved);
        return resolved;
    };
    const secretMappings = [
        { name: "GITFORCE_SF_AUTH_URL", orgAlias: targetOrgAlias },
        { name: "GITFORCE_TARGET_SF_AUTH_URL", orgAlias: targetOrgAlias },
        { name: "GITFORCE_VALIDATE_SF_AUTH_URL", orgAlias: validateOrgAlias }
    ];
    if (integrationOrgAlias) {
        secretMappings.push({
            name: "GITFORCE_INTEGRATION_SF_AUTH_URL",
            orgAlias: integrationOrgAlias
        });
    }
    for (const mapping of secretMappings) {
        const authUrl = await resolveCachedAuthUrl(mapping.orgAlias);
        await (0, shell_1.runCommand)("gh", ["secret", "set", mapping.name, "--repo", repoRef, "--body", authUrl], workspacePath);
    }
    return secretMappings;
}
async function runSecretsSync(workspacePath, parsed) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    const owner = getFlagString(parsed, "owner") ||
        coreConfig.repository.owner ||
        localConfig.github.user;
    const repo = getFlagString(parsed, "repo") ||
        getFlagString(parsed, "name") ||
        coreConfig.repository.repo;
    if (!owner || !repo) {
        throw new Error("Repository owner/repo are required. Pass --owner/--repo or set repository.* in gitforce-project.json.");
    }
    const environment = normalizeEnvironment(getFlagString(parsed, "environment") || localConfig.salesforce.activeEnvironment);
    const targetOrgAlias = getFlagString(parsed, "org-alias") ||
        resolveAliasForEnvironment(localConfig, coreConfig, environment) ||
        coreConfig.environments.targetOrgAlias;
    const validateOrgAlias = getFlagString(parsed, "validate-org-alias") || targetOrgAlias;
    const integrationOrgAlias = getFlagString(parsed, "integration-org-alias") ||
        coreConfig.environments.integrationOrgAlias;
    const includeIntegration = getFlagBoolean(parsed, "integration", Boolean(integrationOrgAlias));
    if (!targetOrgAlias) {
        throw new Error("No target Salesforce org alias found. Pass --org-alias or run `gitforce auth:salesforce` first.");
    }
    if (!validateOrgAlias) {
        throw new Error("No validation Salesforce org alias found. Pass --validate-org-alias or --org-alias.");
    }
    if (includeIntegration && !integrationOrgAlias) {
        throw new Error("Integration secret sync was requested but no integration alias is set. Pass --integration-org-alias or set environments.integrationOrgAlias.");
    }
    logStep(`Syncing Salesforce auth secrets to ${owner}/${repo}...`);
    const seededSecrets = await syncSalesforceAuthSecrets(workspacePath, owner, repo, targetOrgAlias, validateOrgAlias, includeIntegration ? integrationOrgAlias : undefined);
    process.stdout.write("Secrets synced:\n");
    for (const seeded of seededSecrets) {
        process.stdout.write(`- ${seeded.name} <= ${seeded.orgAlias}\n`);
    }
    try {
        await (0, shell_1.runCommand)("gh", [
            "api",
            "-X",
            "PATCH",
            `repos/${owner}/${repo}`,
            "-f",
            `delete_branch_on_merge=${coreConfig.governance.autoDeleteBranchOnMerge ? "true" : "false"}`,
            "-f",
            `allow_auto_merge=${coreConfig.merge.allowAutoMerge ? "true" : "false"}`
        ], workspacePath);
        process.stdout.write(`- Repository settings: delete_branch_on_merge=${coreConfig.governance.autoDeleteBranchOnMerge}, allow_auto_merge=${coreConfig.merge.allowAutoMerge}\n`);
    }
    catch {
        process.stdout.write("Warning: could not enable delete_branch_on_merge automatically.\n");
    }
}
async function runRepoConnect(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    await (0, gitforceLocalConfig_1.ensureGitforceLocalConfigIgnored)(workspacePath);
    const remoteName = getFlagString(parsed, "remote") || "origin";
    const syncWorkflows = getFlagBoolean(parsed, "sync-workflows", true);
    const setRemote = getFlagBoolean(parsed, "set-remote", true);
    const applyHardening = getFlagBoolean(parsed, "harden", true);
    const setSecrets = getFlagBoolean(parsed, "set-secrets", true);
    const publishCodeOwners = getFlagBoolean(parsed, "publish-codeowners", false);
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    let owner = getFlagString(parsed, "owner") ||
        coreConfig.repository.owner ||
        localConfig.github.user;
    let repo = getFlagString(parsed, "repo") ||
        getFlagString(parsed, "name") ||
        coreConfig.repository.repo;
    const hasRemote = await (0, git_1.remoteExists)(workspacePath, remoteName);
    if ((!owner || !repo) && hasRemote) {
        try {
            const remoteUrl = await (0, git_1.getRemoteUrl)(workspacePath, remoteName);
            const parsedRemote = (0, git_1.parseGitHubRemote)(remoteUrl);
            owner = owner || parsedRemote.owner;
            repo = repo || parsedRemote.repo;
        }
        catch {
            // ignore and validate below
        }
    }
    if (!owner || !repo) {
        throw new Error("Could not determine GitHub repository. Provide --owner and --repo, or configure a GitHub origin remote.");
    }
    logStep(`Validating GitHub access to ${owner}/${repo}...`);
    await (0, shell_1.runCommand)("gh", ["api", `repos/${owner}/${repo}`, "--jq", ".full_name"], workspacePath);
    const remoteUrl = `https://github.com/${owner}/${repo}.git`;
    if (setRemote) {
        if (hasRemote) {
            const currentRemote = (await (0, git_1.getRemoteUrl)(workspacePath, remoteName)).trim();
            if (currentRemote !== remoteUrl) {
                logStep(`Updating remote "${remoteName}" -> ${remoteUrl}`);
                await (0, git_1.setRemoteUrl)(workspacePath, remoteName, remoteUrl);
            }
            else {
                logStep(`Remote "${remoteName}" already points to ${owner}/${repo}.`);
            }
        }
        else {
            logStep(`Adding remote "${remoteName}" -> ${remoteUrl}`);
            await (0, git_1.addRemote)(workspacePath, remoteName, remoteUrl);
        }
    }
    else if (!hasRemote) {
        throw new Error(`Remote "${remoteName}" does not exist. Re-run with --set-remote.`);
    }
    const environment = normalizeEnvironment(getFlagString(parsed, "environment") || localConfig.salesforce.activeEnvironment);
    const orgAlias = getFlagString(parsed, "org-alias");
    if (orgAlias) {
        localConfig.salesforce.activeEnvironment = environment;
        setEnvironmentAlias(localConfig, environment, orgAlias);
        await (0, gitforceLocalConfig_1.writeGitforceLocalConfig)(workspacePath, localConfig);
        if (environment === "production") {
            coreConfig.environments.productionOrgAlias = orgAlias;
        }
        else if (environment === "sandbox") {
            coreConfig.environments.sandboxOrgAlias = orgAlias;
        }
        else {
            coreConfig.environments.developmentOrgAlias = orgAlias;
        }
        coreConfig.environments.targetOrgAlias = orgAlias;
    }
    coreConfig.repository.owner = owner;
    coreConfig.repository.repo = repo;
    coreConfig.repository.baseBranch = baseBranch;
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    await ensureSfdxProject(workspacePath, coreConfig, true);
    let generatedArtifacts = [];
    if (syncWorkflows) {
        generatedArtifacts = await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, coreConfig);
    }
    if (applyHardening) {
        await runRepoHarden(workspacePath, {
            flags: new Map([
                ["owner", owner],
                ["repo", repo],
                ["base-branch", baseBranch],
                ["publish-codeowners", publishCodeOwners]
            ]),
            positionals: []
        });
    }
    else {
        process.stdout.write("Skipping repository hardening (--no-harden).\n");
    }
    if (setSecrets) {
        const secretFlags = [
            ["owner", owner],
            ["repo", repo],
            ["environment", environment]
        ];
        if (orgAlias) {
            secretFlags.push(["org-alias", orgAlias]);
        }
        await runSecretsSync(workspacePath, {
            flags: new Map(secretFlags),
            positionals: []
        });
    }
    else {
        process.stdout.write("Skipping Salesforce auth secret sync (--no-set-secrets).\n");
    }
    process.stdout.write(`Repository connected: ${owner}/${repo}\n`);
    process.stdout.write(`- Base branch: ${baseBranch}\n`);
    process.stdout.write(`- Remote: ${remoteName}\n`);
    process.stdout.write(`- Workflows: ${syncWorkflows ? "synced" : "not changed"}\n`);
    if (syncWorkflows) {
        for (const artifact of generatedArtifacts) {
            process.stdout.write(`  - ${artifact.relativePath}\n`);
        }
    }
}
function isRepoAlreadyExistsError(error) {
    const message = error instanceof Error ? error.message : String(error);
    return /already exists|name already exists|repository .* already exists/i.test(message);
}
async function runRepoCreate(workspacePath, parsed) {
    const startedAt = Date.now();
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    await (0, gitforceLocalConfig_1.ensureGitforceLocalConfigIgnored)(workspacePath);
    const owner = getFlagString(parsed, "owner") ||
        localConfig.github.user ||
        coreConfig.repository.owner;
    const repoName = getFlagString(parsed, "repo") ||
        getFlagString(parsed, "name") ||
        coreConfig.repository.repo ||
        inferProjectNameFromPath(workspacePath);
    if (!owner) {
        throw new Error("Missing --owner and no GitHub user found in local config.");
    }
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const visibility = getFlagString(parsed, "visibility");
    const isPublic = getFlagBoolean(parsed, "public", visibility === "public");
    const isInternal = getFlagBoolean(parsed, "internal", visibility === "internal");
    const publish = getFlagBoolean(parsed, "publish", true);
    const createRemote = getFlagBoolean(parsed, "create-remote", true);
    const setSecrets = getFlagBoolean(parsed, "set-secrets", true);
    const retrieveFromSalesforce = getFlagBoolean(parsed, "retrieve", true);
    const driftEnabled = getFlagBoolean(parsed, "drift-enabled", coreConfig.drift.enabled);
    const driftIntervalCandidate = getFlagNumber(parsed, "drift-interval-minutes");
    const destructiveEnabled = getFlagBoolean(parsed, "destructive-enabled", coreConfig.destructiveChanges.enabled);
    const deleteIntentPathFlag = getFlagString(parsed, "delete-intent-path");
    const analyzerScope = normalizeScopeModeFlag(getFlagString(parsed, "analyzer-scope")) ||
        coreConfig.codeAnalyzer.scope;
    const validationScope = normalizeScopeModeFlag(getFlagString(parsed, "validate-scope") || getFlagString(parsed, "validation-scope")) || coreConfig.validation.scope;
    const metadataTypes = normalizeMetadataTypes(parseCsvList(getFlagString(parsed, "metadata-types") || getFlagString(parsed, "manifest-types")), coreConfig.tracked.metadataTypes);
    const includePaths = parseCsvList(getFlagString(parsed, "include-paths"));
    const environmentFlag = getFlagString(parsed, "environment");
    const environment = normalizeEnvironment(environmentFlag || localConfig.salesforce.activeEnvironment);
    let orgAlias = getFlagString(parsed, "org-alias");
    if (orgAlias) {
        setEnvironmentAlias(localConfig, environment, orgAlias);
        localConfig.salesforce.activeEnvironment = environment;
        await (0, gitforceLocalConfig_1.writeGitforceLocalConfig)(workspacePath, localConfig);
    }
    else {
        localConfig.salesforce.activeEnvironment = environment;
        await (0, gitforceLocalConfig_1.writeGitforceLocalConfig)(workspacePath, localConfig);
        orgAlias = (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(localConfig) || undefined;
    }
    coreConfig.repository.owner = owner;
    coreConfig.repository.repo = repoName;
    coreConfig.repository.baseBranch = baseBranch;
    coreConfig.drift.enabled = driftEnabled;
    coreConfig.drift.intervalMinutes = (0, repoSyncConfig_1.normalizeSyncIntervalMinutes)(driftIntervalCandidate ?? coreConfig.drift.intervalMinutes);
    coreConfig.drift.cron = (0, repoSyncConfig_1.buildCronExpression)(coreConfig.drift.intervalMinutes);
    coreConfig.destructiveChanges.enabled = destructiveEnabled;
    if (deleteIntentPathFlag) {
        coreConfig.destructiveChanges.intentPath = validateConfigUpdate("destructiveChanges.intentPath", deleteIntentPathFlag);
    }
    coreConfig.tracked.metadataTypes = metadataTypes;
    coreConfig.codeAnalyzer.scope = analyzerScope;
    coreConfig.codeAnalyzer.changedFilesOnly = analyzerScope === "changed";
    coreConfig.validation.scope = validationScope;
    if (includePaths.length > 0) {
        coreConfig.tracked.paths = includePaths;
    }
    if (orgAlias) {
        if (environment === "production") {
            coreConfig.environments.productionOrgAlias = orgAlias;
        }
        else if (environment === "sandbox") {
            coreConfig.environments.sandboxOrgAlias = orgAlias;
        }
        else {
            coreConfig.environments.developmentOrgAlias = orgAlias;
        }
        coreConfig.environments.targetOrgAlias = orgAlias;
    }
    logStep("Saving project configuration and generating workflows...");
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    await ensureSfdxProject(workspacePath, coreConfig, true);
    await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, coreConfig);
    const codeOwnersContent = buildCodeOwnersContent(coreConfig, localConfig);
    if (codeOwnersContent) {
        const updatedCodeOwners = await writeCodeOwnersFile(workspacePath, codeOwnersContent);
        logStep(`CODEOWNERS ${updatedCodeOwners ? "updated" : "already up to date"}.`);
    }
    else {
        logStep("Skipping CODEOWNERS generation (no owners configured and no authenticated GitHub user).");
    }
    if (retrieveFromSalesforce) {
        const aliasToUse = orgAlias || coreConfig.environments.targetOrgAlias;
        if (!aliasToUse) {
            throw new Error("No Salesforce org alias available for retrieve. Run `gitforce auth:salesforce` first or pass --org-alias.");
        }
        const retrieveArgs = ["project", "retrieve", "start", "--target-org", aliasToUse, "--ignore-conflicts"];
        if (coreConfig.tracked.metadataTypes.length > 0) {
            for (const metadataType of coreConfig.tracked.metadataTypes) {
                retrieveArgs.push("--metadata", metadataType);
            }
        }
        else if (coreConfig.tracked.paths.length > 0) {
            for (const trackedPath of coreConfig.tracked.paths) {
                retrieveArgs.push("--source-dir", trackedPath);
            }
        }
        const retrieveStartedAt = Date.now();
        logStep(`Pulling Salesforce metadata from "${aliasToUse}" (types: ${coreConfig.tracked.metadataTypes.join(", ")})...`);
        await (0, shell_1.runCommand)("sf", retrieveArgs, workspacePath, {
            timeoutMs: 20 * 60 * 1000,
            maxBufferBytes: 100 * 1024 * 1024
        });
        logStep(`Metadata pull complete in ${formatDuration(Date.now() - retrieveStartedAt)}.`);
    }
    else {
        logStep("Skipping Salesforce metadata pull (--no-retrieve).");
    }
    const isRepo = await (0, git_1.isGitRepository)(workspacePath);
    if (!isRepo) {
        logStep("Initializing local git repository...");
        await (0, git_1.initRepository)(workspacePath);
    }
    logStep(`Preparing git branch "${baseBranch}"...`);
    await (0, shell_1.runCommand)("git", ["checkout", "-B", baseBranch], workspacePath);
    await ensureGitIdentity(workspacePath, localConfig.github.user);
    await (0, shell_1.runCommand)("git", ["add", "-A"], workspacePath);
    if (await hasLocalChanges(workspacePath)) {
        logStep("Creating initial commit...");
        await (0, shell_1.runCommand)("git", ["commit", "-m", "Initialize Gitforce project"], workspacePath);
    }
    else {
        logStep("No new local changes to commit.");
    }
    const remoteName = getFlagString(parsed, "remote") || "origin";
    const repoRef = `${owner}/${repoName}`;
    if (createRemote) {
        const createArgs = ["repo", "create", repoRef];
        if (isInternal) {
            createArgs.push("--internal");
        }
        else if (isPublic) {
            createArgs.push("--public");
        }
        else {
            createArgs.push("--private");
        }
        logStep(`Creating GitHub repository "${repoRef}"...`);
        try {
            await (0, shell_1.runCommand)("gh", createArgs, workspacePath, {
                timeoutMs: 5 * 60 * 1000,
                maxBufferBytes: 20 * 1024 * 1024
            });
        }
        catch (error) {
            if (!isRepoAlreadyExistsError(error)) {
                throw error;
            }
            logStep(`GitHub repository "${repoRef}" already exists. Reusing it.`);
        }
        const remoteUrl = `https://github.com/${repoRef}.git`;
        const hasOrigin = await (0, git_1.remoteExists)(workspacePath, remoteName);
        if (hasOrigin) {
            logStep(`Updating remote "${remoteName}" -> ${remoteUrl}`);
            await (0, git_1.setRemoteUrl)(workspacePath, remoteName, remoteUrl);
        }
        else {
            logStep(`Adding remote "${remoteName}" -> ${remoteUrl}`);
            await (0, git_1.addRemote)(workspacePath, remoteName, remoteUrl);
        }
        if (publish) {
            logStep(`Pushing branch "${baseBranch}" to GitHub...`);
            await (0, shell_1.runCommand)("git", ["push", "-u", remoteName, baseBranch], workspacePath);
        }
        logStep("Configuring GitHub Actions settings...");
        try {
            await (0, shell_1.runCommand)("gh", [
                "api",
                "-X",
                "PUT",
                `repos/${repoRef}/actions/permissions`,
                "-f",
                "enabled=true",
                "-f",
                "allowed_actions=all"
            ], workspacePath);
        }
        catch {
            // non-fatal
        }
        logStep("Configuring GitHub Actions workflow permissions...");
        try {
            await (0, shell_1.runCommand)("gh", [
                "api",
                "-X",
                "PUT",
                `repos/${repoRef}/actions/permissions/workflow`,
                "-f",
                "default_workflow_permissions=write",
                "-f",
                "can_approve_pull_request_reviews=true"
            ], workspacePath);
        }
        catch {
            // non-fatal
        }
        if (coreConfig.governance.hardenRepository) {
            logStep("Applying GitHub repository hardening policy...");
            try {
                await applyGitHubRepositoryHardening(workspacePath, owner, repoName, baseBranch, coreConfig);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                process.stdout.write(`Warning: could not fully apply repository hardening (${message}).\n`);
            }
        }
        else {
            logStep("Repository hardening disabled in governance.hardenRepository.");
        }
        if (publish && setSecrets && orgAlias) {
            logStep(`Setting Salesforce auth secrets for "${repoRef}"...`);
            try {
                const seededSecrets = await syncSalesforceAuthSecrets(workspacePath, owner, repoName, orgAlias, orgAlias, coreConfig.environments.integrationOrgAlias);
                process.stdout.write(`- Seeded secrets: ${seededSecrets
                    .map((seeded) => `${seeded.name}<=${seeded.orgAlias}`)
                    .join(", ")}\n`);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                process.stdout.write(`Warning: could not set Salesforce secrets automatically (${message}).\n`);
            }
        }
        else if (publish && !orgAlias) {
            process.stdout.write("Warning: skipped Salesforce auth secret setup because no org alias is configured.\n");
        }
    }
    process.stdout.write(`Repository ready: ${repoRef}\n`);
    process.stdout.write(`- Setup time: ${formatDuration(Date.now() - startedAt)}\n`);
    process.stdout.write(`- Drift detection: ${coreConfig.drift.enabled ? "enabled" : "disabled"}\n`);
    process.stdout.write(`- Drift interval: ${coreConfig.drift.intervalMinutes} minute(s)\n`);
    process.stdout.write(`- Metadata scope: ${coreConfig.tracked.metadataTypes.join(", ")}\n`);
    process.stdout.write(`- Code Analyzer scope: ${coreConfig.codeAnalyzer.scope}\n`);
    process.stdout.write(`- Salesforce validate scope: ${coreConfig.validation.scope}\n`);
    if (createRemote && publish) {
        process.stdout.write("- Published to GitHub\n");
    }
    else if (createRemote) {
        process.stdout.write("- Remote repository created (local branch not pushed)\n");
    }
    else {
        process.stdout.write("- Remote repository creation skipped (--no-create-remote)\n");
    }
}
async function runRepoHarden(workspacePath, parsed) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    const owner = getFlagString(parsed, "owner") ||
        coreConfig.repository.owner ||
        localConfig.github.user;
    const repo = getFlagString(parsed, "repo") ||
        getFlagString(parsed, "name") ||
        coreConfig.repository.repo;
    const baseBranch = getFlagString(parsed, "base-branch") ||
        coreConfig.repository.baseBranch ||
        "main";
    const publishCodeOwners = getFlagBoolean(parsed, "publish-codeowners", false);
    if (!owner || !repo) {
        throw new Error("Repository owner/repo are required. Pass --owner/--repo or set repository.* in gitforce-project.json.");
    }
    if (!coreConfig.governance.hardenRepository) {
        process.stdout.write("Repository hardening is disabled in governance.hardenRepository. Nothing to apply.\n");
        return;
    }
    const codeOwnersContent = buildCodeOwnersContent(coreConfig, localConfig);
    if (codeOwnersContent) {
        const changed = await writeCodeOwnersFile(workspacePath, codeOwnersContent);
        process.stdout.write(`CODEOWNERS ${changed ? "updated" : "already up to date"} locally.\n`);
        if (publishCodeOwners && changed) {
            await ensureGitIdentity(workspacePath, localConfig.github.user);
            await (0, shell_1.runCommand)("git", ["checkout", baseBranch], workspacePath);
            const published = await publishCodeOwnersFile(workspacePath, baseBranch);
            process.stdout.write(published
                ? "CODEOWNERS committed and pushed.\n"
                : "CODEOWNERS publish skipped (no CODEOWNERS diff).\n");
        }
    }
    else {
        process.stdout.write("Skipping CODEOWNERS generation because no owners are configured and no GitHub user is connected.\n");
    }
    logStep(`Applying hardening policy to ${owner}/${repo} (${baseBranch})...`);
    await applyGitHubRepositoryHardening(workspacePath, owner, repo, baseBranch, coreConfig);
    process.stdout.write("Repository hardening applied.\n");
    process.stdout.write(`- Required checks: ${coreConfig.merge.requiredChecks.length > 0 ? coreConfig.merge.requiredChecks.join(", ") : "(none)"}\n`);
    process.stdout.write(`- Required approvals: ${coreConfig.governance.requiredApprovingReviewCount}\n`);
    process.stdout.write(`- Code owner reviews: ${coreConfig.governance.requireCodeOwnerReviews ? "enabled" : "disabled"}\n`);
    process.stdout.write(`- Require conversation resolution: ${coreConfig.governance.requireConversationResolution ? "enabled" : "disabled"}\n`);
}
async function runConfigUpdate(workspacePath, parsed, mode) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const operations = mode === "config:set" ? buildConfigSetOperations(parsed) : buildUpdateOperations(parsed);
    const applied = [];
    const root = coreConfig;
    for (const operation of operations) {
        const normalizedPath = normalizeConfigPath(operation.path);
        const normalizedValue = validateConfigUpdate(normalizedPath, operation.value);
        setConfigValueAtPath(root, normalizedPath, normalizedValue);
        applied.push({
            path: normalizedPath,
            value: normalizedValue,
            source: operation.source
        });
    }
    synchronizeDerivedCoreConfig(coreConfig);
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    const updatedSfdxProject = await ensureSfdxProject(workspacePath, coreConfig, true);
    const regenerateArtifacts = getFlagBoolean(parsed, "generate-workflows", true);
    let artifacts = [];
    if (regenerateArtifacts) {
        artifacts = await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, coreConfig);
    }
    process.stdout.write("Updated gitforce-project.json:\n");
    for (const operation of applied) {
        const value = typeof operation.value === "string" ? operation.value : JSON.stringify(operation.value);
        process.stdout.write(`- ${operation.path} = ${value} (${operation.source})\n`);
    }
    process.stdout.write(`- sfdx-project.json ${updatedSfdxProject ? "synced" : "already up to date"}\n`);
    if (regenerateArtifacts) {
        process.stdout.write("Regenerated Gitforce artifacts:\n");
        for (const artifact of artifacts) {
            process.stdout.write(`- ${artifact.relativePath}\n`);
        }
    }
    else {
        process.stdout.write("Skipped workflow/artifact regeneration (--no-generate-workflows).\n");
    }
}
async function runPush(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.bootstrapGitforceLocalConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const requestedBranch = getFlagString(parsed, "branch");
    const createPr = getFlagBoolean(parsed, "pr", true);
    const draft = getFlagBoolean(parsed, "draft", false);
    const allowBasePush = getFlagBoolean(parsed, "allow-base-push", false);
    const forceYes = getFlagBoolean(parsed, "yes", false);
    const autoBranchPrefix = coreConfig.branchPolicy.autoBranchPrefix;
    const reservedPrefixes = coreConfig.branchPolicy.reservedPrefixes;
    const shouldAttemptAutoMerge = !draft && coreConfig.merge.autoMergeOnChecksPass;
    if (!(await (0, git_1.remoteExists)(workspacePath, remote))) {
        throw new Error(`Remote "${remote}" was not found. Configure a remote before running gitforce push.`);
    }
    let branch = await resolveCurrentBranch(workspacePath);
    if (requestedBranch && requestedBranch !== branch) {
        try {
            await (0, shell_1.runCommand)("git", ["checkout", requestedBranch], workspacePath);
        }
        catch {
            await (0, shell_1.runCommand)("git", ["checkout", "-b", requestedBranch], workspacePath);
        }
        branch = requestedBranch;
    }
    else if (!requestedBranch && branch === baseBranch && coreConfig.branchPolicy.autoBranch) {
        const seed = getFlagString(parsed, "description") || getFlagString(parsed, "title") || "change";
        const newBranch = buildPushBranchName(seed, autoBranchPrefix);
        logStep(`Creating feature branch "${newBranch}" from "${baseBranch}"...`);
        await (0, shell_1.runCommand)("git", ["checkout", "-b", newBranch], workspacePath);
        branch = newBranch;
    }
    try {
        enforceBranchPolicy(branch, baseBranch, autoBranchPrefix, reservedPrefixes, coreConfig.branchPolicy.enforcePrefix, allowBasePush ? false : coreConfig.branchPolicy.disallowDirectPushToBase);
    }
    catch (error) {
        const policyMessage = error instanceof Error ? error.message : String(error);
        const confirmed = await confirmBranchPolicyOverride(branch, baseBranch, policyMessage, forceYes);
        if (!confirmed) {
            throw new Error("Push canceled.");
        }
        process.stdout.write("Warning: proceeding with push despite branch policy warning.\n");
    }
    const hasChanges = await hasLocalChanges(workspacePath);
    let description = getFlagString(parsed, "description");
    let title = getFlagString(parsed, "title");
    if (hasChanges) {
        if (!description) {
            description = await promptForDescription();
        }
        if (!description) {
            throw new Error("A change description is required to commit. Pass --description or provide it when prompted.");
        }
        title = title || buildPrTitle(description);
        await ensureGitIdentity(workspacePath, localConfig.github.user);
        logStep(`Committing local changes as "${title}"...`);
        await (0, shell_1.runCommand)("git", ["add", "-A"], workspacePath);
        await (0, shell_1.runCommand)("git", ["commit", "-m", title], workspacePath);
    }
    else {
        title = title || (await resolveLatestCommitSubject(workspacePath)) || "Gitforce Change";
        description = description || title;
    }
    const commitsToPush = await hasCommitsToPush(workspacePath, remote, branch);
    if (!commitsToPush) {
        process.stdout.write(`No commits to push on branch "${branch}".\n`);
        return;
    }
    logStep(`Pushing "${branch}" to "${remote}"...`);
    await (0, shell_1.runCommand)("git", ["push", "-u", remote, branch], workspacePath);
    process.stdout.write(`Branch pushed: ${branch}\n`);
    let autoMergeGate = { allowed: false };
    if (shouldAttemptAutoMerge) {
        autoMergeGate = await evaluateAutoMergeSafety(workspacePath, remote, baseBranch, coreConfig);
        if (!autoMergeGate.allowed && autoMergeGate.reason) {
            process.stdout.write(`Warning: auto-merge skipped (${autoMergeGate.reason})\n`);
        }
    }
    if (!createPr) {
        process.stdout.write("PR creation skipped (--no-pr).\n");
        return;
    }
    const existingPr = await getExistingPrUrl(workspacePath, branch, baseBranch);
    if (existingPr) {
        process.stdout.write(`PR already exists: ${existingPr}\n`);
        if (shouldAttemptAutoMerge && autoMergeGate.allowed) {
            try {
                await enablePrAutoMerge(workspacePath, existingPr);
                process.stdout.write("Auto-merge enabled for existing PR (merge when checks pass).\n");
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                process.stdout.write(`Warning: could not enable PR auto-merge (${message}).\n`);
            }
        }
        return;
    }
    const diffFiles = await resolveDiffFilesForPr(workspacePath, remote, baseBranch, branch);
    const prTitle = title || buildPrTitle(description || "Gitforce Change");
    const prBody = buildPrBody(description || prTitle, diffFiles);
    const createArgs = ["pr", "create", "--base", baseBranch, "--head", branch, "--title", prTitle, "--body", prBody];
    if (draft) {
        createArgs.push("--draft");
    }
    logStep(`Opening PR into "${baseBranch}"...`);
    const { stdout } = await (0, shell_1.runCommand)("gh", createArgs, workspacePath);
    const prUrl = extractPrUrl(stdout.trim()) || stdout.trim();
    process.stdout.write(prUrl ? `PR created: ${prUrl}\n` : "PR created.\n");
    if (shouldAttemptAutoMerge && autoMergeGate.allowed && prUrl) {
        try {
            await enablePrAutoMerge(workspacePath, prUrl);
            process.stdout.write("Auto-merge enabled (PR will merge when required checks pass).\n");
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            process.stdout.write(`Warning: could not enable PR auto-merge (${message}).\n`);
        }
    }
}
async function runPull(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const branch = await resolveCurrentBranch(workspacePath);
    const hasDirtyWorkingTree = await hasLocalChanges(workspacePath);
    const forceYes = getFlagBoolean(parsed, "yes", false);
    if (!(await (0, git_1.remoteExists)(workspacePath, remote))) {
        throw new Error(`Remote "${remote}" was not found. Configure a remote before running gitforce pull.`);
    }
    const strategy = parsePullStrategyFlag(parsed) || (await promptForPullStrategy());
    logStep(`Fetching latest refs from "${remote}"...`);
    await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    if (strategy === "overwrite") {
        const confirmed = await confirmOverwritePull(remote, baseBranch, branch, forceYes);
        if (!confirmed) {
            process.stdout.write("Pull canceled.\n");
            return;
        }
        let resetTarget = `${remote}/${baseBranch}`;
        try {
            const { stdout } = await (0, shell_1.runCommand)("git", ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], workspacePath);
            const upstream = stdout.trim();
            if (upstream) {
                resetTarget = upstream;
            }
        }
        catch {
            // fallback to base branch target
        }
        logStep(`Overwriting local branch "${branch}" with "${resetTarget}"...`);
        await (0, shell_1.runCommand)("git", ["reset", "--hard", resetTarget], workspacePath);
        await (0, shell_1.runCommand)("git", ["clean", "-fd"], workspacePath);
        process.stdout.write(`Local ${branch} overwritten from ${resetTarget}. Uncommitted changes were discarded.\n`);
        return;
    }
    let stashedForMergePull = false;
    if (hasDirtyWorkingTree) {
        const confirmed = await confirmMergePullWithDirtyWorkspace(remote, baseBranch, branch, forceYes);
        if (!confirmed) {
            process.stdout.write("Pull canceled.\n");
            return;
        }
        const stashLabel = `gitforce-pull-${Date.now()}`;
        logStep("Stashing local changes before merge pull...");
        await (0, shell_1.runCommand)("git", ["stash", "push", "--include-untracked", "-m", stashLabel], workspacePath);
        stashedForMergePull = true;
    }
    let finalMessage = "";
    let hasUpstream = false;
    if (branch === baseBranch) {
        hasUpstream = true;
    }
    else {
        try {
            await (0, shell_1.runCommand)("git", ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], workspacePath);
            hasUpstream = true;
        }
        catch {
            hasUpstream = false;
        }
    }
    if (branch === baseBranch) {
        try {
            logStep(`Merging latest changes into "${baseBranch}" with rebase pull...`);
            await (0, shell_1.runCommand)("git", ["pull", "--rebase", remote, baseBranch], workspacePath);
            finalMessage = `Local ${baseBranch} is up to date.`;
        }
        catch (error) {
            if (stashedForMergePull) {
                process.stdout.write("Warning: merge pull failed after stashing local changes. Resolve git pull/rebase errors, then run `git stash list`.\n");
            }
            throw error;
        }
    }
    else {
        try {
            if (hasUpstream) {
                logStep(`Updating feature branch "${branch}" from its upstream...`);
                await (0, shell_1.runCommand)("git", ["pull", "--rebase"], workspacePath);
            }
            logStep(`Rebasing "${branch}" onto "${remote}/${baseBranch}"...`);
            await (0, shell_1.runCommand)("git", ["rebase", `${remote}/${baseBranch}`], workspacePath);
            finalMessage = `Local ${branch} refreshed from ${remote}/${baseBranch}.`;
        }
        catch (error) {
            if (stashedForMergePull) {
                process.stdout.write("Warning: merge pull failed after stashing local changes. Resolve git pull/rebase errors, then run `git stash list`.\n");
            }
            throw error;
        }
    }
    if (stashedForMergePull) {
        try {
            logStep("Restoring stashed local changes...");
            await (0, shell_1.runCommand)("git", ["stash", "pop"], workspacePath);
            process.stdout.write("Local changes restored from stash.\n");
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            process.stdout.write(`Warning: pulled successfully, but Gitforce could not auto-restore stash (${message}). Run "git stash list" then "git stash pop".\n`);
        }
    }
    process.stdout.write(`${finalMessage}\n`);
}
function renderImpactSummary(summary, maxItems) {
    const lines = [];
    lines.push("Change Impact Summary");
    lines.push(`- Total impacted files: ${summary.total}`);
    lines.push(`- Risk counts: high=${summary.byRisk.high}, medium=${summary.byRisk.medium}, low=${summary.byRisk.low}`);
    const metadataTypes = Object.entries(summary.byMetadataType);
    if (metadataTypes.length > 0) {
        lines.push("- Metadata types:");
        for (const [metadataType, count] of metadataTypes) {
            lines.push(`  - ${metadataType}: ${count}`);
        }
    }
    if (summary.suggestedTests.length > 0) {
        lines.push(`- Suggested Apex tests: ${summary.suggestedTests.join(", ")}`);
    }
    lines.push("");
    lines.push("Top impacted files:");
    const display = summary.items.slice(0, maxItems);
    for (const item of display) {
        const renameSuffix = item.previousPath ? ` (from ${item.previousPath})` : "";
        lines.push(`- [${item.risk.toUpperCase()}] ${item.status} ${item.path} -> ${item.metadataType}:${item.componentName}${renameSuffix}`);
    }
    if (summary.items.length > display.length) {
        lines.push(`- ... and ${summary.items.length - display.length} more`);
    }
    return lines;
}
async function runImpact(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const baseRef = getFlagString(parsed, "base") || `${remote}/${baseBranch}`;
    const headRef = getFlagString(parsed, "head") || "HEAD";
    const outputFormat = (getFlagString(parsed, "format") || "table").toLowerCase();
    const thresholdFromFlag = normalizeRiskThresholdFlag(getFlagString(parsed, "risk-threshold"));
    const riskThreshold = thresholdFromFlag || coreConfig.changeIntelligence.riskThreshold;
    const maxItemsFlag = getFlagNumber(parsed, "max-items");
    const maxItems = typeof maxItemsFlag === "number" && Number.isFinite(maxItemsFlag) && maxItemsFlag > 0
        ? Math.floor(maxItemsFlag)
        : coreConfig.changeIntelligence.maxPrSummaryItems;
    if (remote && (await (0, git_1.remoteExists)(workspacePath, remote))) {
        await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    }
    const { stdout } = await (0, shell_1.runCommand)("git", ["diff", "--name-status", `${baseRef}...${headRef}`], workspacePath);
    const entries = (0, changeIntelligence_1.parseGitNameStatus)(stdout);
    const summary = (0, changeIntelligence_1.summarizeChangeImpact)(entries, coreConfig.tracked.paths, riskThreshold);
    if (outputFormat === "json") {
        process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
        return;
    }
    for (const line of renderImpactSummary(summary, maxItems)) {
        process.stdout.write(`${line}\n`);
    }
}
async function runPromote(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const forceYes = getFlagBoolean(parsed, "yes", false);
    if (!(await (0, git_1.remoteExists)(workspacePath, remote))) {
        throw new Error(`Remote "${remote}" was not found. Configure a remote before running promote.`);
    }
    let fromLane = normalizePromotionLane(getFlagString(parsed, "from"));
    let toLane = normalizePromotionLane(getFlagString(parsed, "to"));
    if (!fromLane) {
        fromLane = await promptForPromotionLane("from", forceYes);
    }
    if (!toLane) {
        toLane = await promptForPromotionLane("to", forceYes);
    }
    if (!fromLane || !toLane) {
        throw new Error('Promotion requires --from and --to lanes: development|sandbox|production.');
    }
    if (fromLane === toLane) {
        throw new Error("Promotion source and target lanes must be different.");
    }
    const fromOrder = promotionLaneOrder(fromLane);
    const toOrder = promotionLaneOrder(toLane);
    const allowSkip = getFlagBoolean(parsed, "allow-skip", false);
    const promotionWarnings = [];
    if (!allowSkip && toOrder !== fromOrder + 1) {
        promotionWarnings.push("Promotion lanes are non-adjacent. Default flow is development -> sandbox -> production.");
    }
    if (toOrder <= fromOrder) {
        promotionWarnings.push("Promotion target lane is not ahead of source lane.");
    }
    if (promotionWarnings.length > 0) {
        const confirmed = await confirmPromotionOverride(fromLane, toLane, promotionWarnings, forceYes);
        if (!confirmed) {
            throw new Error("Promotion canceled.");
        }
        process.stdout.write("Warning: proceeding with non-standard promotion lane configuration.\n");
    }
    const fromBranch = coreConfig.promotion.lanes[fromLane].branch;
    const toBranch = coreConfig.promotion.lanes[toLane].branch;
    const seedBranch = coreConfig.repository.baseBranch || "main";
    const draft = getFlagBoolean(parsed, "draft", false);
    await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    try {
        await (0, shell_1.runCommand)("git", ["rev-parse", "--verify", `${remote}/${seedBranch}`], workspacePath);
    }
    catch {
        throw new Error(`Base branch "${seedBranch}" was not found on ${remote}; cannot auto-create missing promotion lane branches.`);
    }
    await ensurePromotionLaneBranch(workspacePath, remote, fromLane, fromBranch, seedBranch, forceYes);
    await ensurePromotionLaneBranch(workspacePath, remote, toLane, toBranch, seedBranch, forceYes);
    const existingPr = await getExistingPrUrl(workspacePath, fromBranch, toBranch);
    if (existingPr) {
        process.stdout.write(`Promotion PR already exists: ${existingPr}\n`);
        return;
    }
    const { stdout: changedOutput } = await (0, shell_1.runCommand)("git", ["diff", "--name-only", `${remote}/${toBranch}...${remote}/${fromBranch}`], workspacePath);
    const changedFiles = changedOutput
        .split("\n")
        .map((entry) => entry.trim())
        .filter(Boolean);
    const preview = summarizeDiffFiles(changedFiles);
    const title = getFlagString(parsed, "title") ||
        `Promote ${fromLane} to ${toLane} (${new Date().toISOString().slice(0, 16)})`;
    const bodyLines = [
        "## Summary",
        "",
        `Promote changes from \`${fromLane}\` (\`${fromBranch}\`) into \`${toLane}\` (\`${toBranch}\`).`,
        "",
        `- Strategy: ${coreConfig.promotion.strategy}`,
        `- Auto promote: ${coreConfig.promotion.autoPromote ? "enabled" : "disabled"}`,
        "",
        "## Changed Files",
        "",
        ...(preview.length > 0 ? preview.map((file) => `- ${file}`) : ["- No file differences detected."]),
        "",
        "## Gitforce",
        "",
        "- Created via `gitforce promote`"
    ];
    const createArgs = [
        "pr",
        "create",
        "--base",
        toBranch,
        "--head",
        fromBranch,
        "--title",
        title,
        "--body",
        bodyLines.join("\n")
    ];
    if (draft) {
        createArgs.push("--draft");
    }
    const { stdout } = await (0, shell_1.runCommand)("gh", createArgs, workspacePath);
    const prUrl = extractPrUrl(stdout.trim()) || stdout.trim();
    process.stdout.write(prUrl ? `Promotion PR created: ${prUrl}\n` : "Promotion PR created.\n");
    if (!draft && coreConfig.promotion.autoPromote && prUrl) {
        const autoMergeGate = await evaluateAutoMergeSafety(workspacePath, remote, toBranch, coreConfig);
        if (autoMergeGate.allowed) {
            try {
                await enablePrAutoMerge(workspacePath, prUrl);
                process.stdout.write("Auto-merge enabled for promotion PR.\n");
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                process.stdout.write(`Warning: could not enable promotion PR auto-merge (${message}).\n`);
            }
        }
        else if (autoMergeGate.reason) {
            process.stdout.write(`Warning: promotion auto-merge skipped (${autoMergeGate.reason})\n`);
        }
    }
}
function applyPolicyProfileToRuntimeConfig(config, profileName) {
    const profile = config.policyProfiles.profiles[profileName];
    config.merge.requiredChecks = [...profile.requiredChecks];
    config.merge.requirePullRequest = profile.requirePullRequest;
    config.merge.allowAutoMerge = profile.allowAutoMerge;
    config.merge.autoMergeOnChecksPass = profile.autoMergeOnChecksPass;
    config.codeAnalyzer.failOnSeverity = profile.analyzerSeverityGate;
    config.validation.scope = profile.validationScope;
    config.deploy.testLevel = profile.deployTestLevel;
}
async function runProfileList(workspacePath) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    process.stdout.write("Gitforce policy profiles:\n");
    process.stdout.write(`- default: ${coreConfig.policyProfiles.defaultProfile}\n`);
    process.stdout.write(`- overrides: development=${coreConfig.policyProfiles.environmentOverrides.development ?? "(none)"}, ` +
        `sandbox=${coreConfig.policyProfiles.environmentOverrides.sandbox ?? "(none)"}, ` +
        `production=${coreConfig.policyProfiles.environmentOverrides.production ?? "(none)"}\n`);
    for (const profileName of ["relaxed", "balanced", "strict"]) {
        const profile = coreConfig.policyProfiles.profiles[profileName];
        process.stdout.write(`\n[${profileName}]\n`);
        process.stdout.write(`- requiredChecks: ${profile.requiredChecks.join(", ")}\n`);
        process.stdout.write(`- analyzerSeverityGate: ${profile.analyzerSeverityGate}\n`);
        process.stdout.write(`- validationScope: ${profile.validationScope}\n`);
        process.stdout.write(`- requirePullRequest: ${profile.requirePullRequest}\n`);
        process.stdout.write(`- allowAutoMerge: ${profile.allowAutoMerge}\n`);
        process.stdout.write(`- autoMergeOnChecksPass: ${profile.autoMergeOnChecksPass}\n`);
        process.stdout.write(`- deployTestLevel: ${profile.deployTestLevel}\n`);
    }
}
async function runProfileApply(workspacePath, parsed) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const targetProfile = normalizePolicyProfileNameFlag(getFlagString(parsed, "profile")) ||
        normalizePolicyProfileNameFlag(parsed.positionals[0]);
    if (!targetProfile) {
        throw new Error('Missing profile. Use --profile relaxed|balanced|strict.');
    }
    const environment = normalizePromotionLane(getFlagString(parsed, "env") || getFlagString(parsed, "environment"));
    const materialize = parsed.flags.has("materialize")
        ? getFlagBoolean(parsed, "materialize", true)
        : !environment;
    if (environment) {
        coreConfig.policyProfiles.environmentOverrides[environment] = targetProfile;
        process.stdout.write(`Set policy override for ${environment} -> ${targetProfile}.\n`);
    }
    else {
        coreConfig.policyProfiles.defaultProfile = targetProfile;
        process.stdout.write(`Set default policy profile -> ${targetProfile}.\n`);
    }
    if (materialize) {
        applyPolicyProfileToRuntimeConfig(coreConfig, targetProfile);
        process.stdout.write("Applied profile settings to merge/validation/analyzer/deploy config.\n");
    }
    else {
        process.stdout.write("Profile saved without materializing runtime config (--no-materialize behavior).\n");
    }
    synchronizeDerivedCoreConfig(coreConfig);
    await (0, gitforceCore_1.writeGitforceCoreConfig)(workspacePath, coreConfig);
    await ensureSfdxProject(workspacePath, coreConfig, true);
    const artifacts = await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, coreConfig);
    process.stdout.write("Regenerated Gitforce artifacts:\n");
    for (const artifact of artifacts) {
        process.stdout.write(`- ${artifact.relativePath}\n`);
    }
}
async function runPipelineRun(workspacePath, parsed) {
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const workflowExplicit = getFlagString(parsed, "workflow");
    const lane = normalizePromotionLane(getFlagString(parsed, "lane"));
    const drift = getFlagBoolean(parsed, "drift", false);
    const validate = getFlagBoolean(parsed, "validate", false);
    let workflow = workflowExplicit;
    if (!workflow) {
        if (drift) {
            workflow = "gitforce-drift-detect.yml";
        }
        else if (validate || lane === "development") {
            workflow = "gitforce-pr-validate.yml";
        }
        else {
            workflow = "gitforce-promote.yml";
        }
    }
    const runArgs = ["workflow", "run", workflow];
    if (lane === "sandbox" || lane === "production") {
        runArgs.push("--ref", coreConfig.promotion.lanes[lane].branch);
    }
    else {
        runArgs.push("--ref", coreConfig.repository.baseBranch || "main");
    }
    await (0, shell_1.runCommand)("gh", runArgs, workspacePath);
    process.stdout.write(`Triggered workflow ${workflow} on ${lane ? `${lane} lane` : "default branch ref"}.\n`);
}
async function listWorkflowRuns(workspacePath, workflow, limit) {
    const { stdout } = await (0, shell_1.runCommand)("gh", ["run", "list", "--workflow", workflow, "--limit", String(limit), "--json", "databaseId,status,conclusion,displayTitle,workflowName,event,createdAt,url"], workspacePath);
    const parsed = JSON.parse(stdout);
    return Array.isArray(parsed) ? parsed : [];
}
async function listOpenPullRequests(workspacePath, limit) {
    const { stdout } = await (0, shell_1.runCommand)("gh", [
        "pr",
        "list",
        "--state",
        "open",
        "--limit",
        String(limit),
        "--json",
        "number,title,url,headRefName,baseRefName,isDraft,createdAt,updatedAt"
    ], workspacePath);
    const parsed = JSON.parse(stdout);
    return Array.isArray(parsed) ? parsed : [];
}
async function runDriftReport(workspacePath, parsed) {
    const limit = Math.max(1, Math.min(20, getFlagNumber(parsed, "last") ?? 5));
    const driftRuns = await listWorkflowRuns(workspacePath, "gitforce-drift-detect.yml", limit);
    const openPrs = await listOpenPullRequests(workspacePath, 50);
    const driftPrs = openPrs.filter((row) => row.headRefName.startsWith("gitforce/drift-"));
    process.stdout.write("Gitforce Drift Report\n");
    process.stdout.write(`- Recent runs shown: ${limit}\n`);
    process.stdout.write(`- Open drift PRs: ${driftPrs.length}\n`);
    if (driftPrs.length > 0) {
        process.stdout.write("\nOpen drift PRs:\n");
        for (const pr of driftPrs.slice(0, limit)) {
            const draftLabel = pr.isDraft ? " [draft]" : "";
            process.stdout.write(`- #${pr.number}${draftLabel} ${pr.title} (${pr.headRefName}) ${pr.url}\n`);
        }
    }
    process.stdout.write("\nRecent drift workflow runs:\n");
    if (driftRuns.length === 0) {
        process.stdout.write("- No drift runs found.\n");
    }
    else {
        for (const run of driftRuns) {
            const status = run.conclusion || run.status;
            process.stdout.write(`- [${status}] ${run.createdAt} ${run.displayTitle} ${run.url}\n`);
        }
    }
}
async function runStatus(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const localConfig = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const baseBranch = getFlagString(parsed, "base-branch") || coreConfig.repository.baseBranch || "main";
    const branch = await resolveCurrentBranch(workspacePath);
    const dirty = await hasLocalChanges(workspacePath);
    process.stdout.write("Gitforce Status\n");
    process.stdout.write(`- Workspace: ${workspacePath}\n`);
    process.stdout.write(`- Branch: ${branch}\n`);
    process.stdout.write(`- Dirty working tree: ${dirty ? "yes" : "no"}\n`);
    process.stdout.write(`- Base branch: ${baseBranch}\n`);
    process.stdout.write(`- Drift: ${coreConfig.drift.enabled ? "enabled" : "disabled"} (${coreConfig.drift.intervalMinutes}m)\n`);
    process.stdout.write(`- Tracked metadata types: ${coreConfig.tracked.metadataTypes.length}\n`);
    const githubUser = localConfig?.github?.user?.trim() || "(not configured)";
    const sfTargetAlias = (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(localConfig) || coreConfig.environments.targetOrgAlias || "(not configured)";
    process.stdout.write(`- GitHub user: ${githubUser}\n`);
    process.stdout.write(`- Salesforce target org alias: ${sfTargetAlias}\n`);
    if (await (0, git_1.remoteExists)(workspacePath, remote)) {
        try {
            await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
            const { stdout } = await (0, shell_1.runCommand)("git", ["rev-list", "--left-right", "--count", `${remote}/${baseBranch}...HEAD`], workspacePath);
            const [behindRaw, aheadRaw] = stdout.trim().split(/\s+/);
            const behind = Number(behindRaw || "0");
            const ahead = Number(aheadRaw || "0");
            process.stdout.write(`- Ahead/behind ${remote}/${baseBranch}: +${ahead} / -${behind}\n`);
        }
        catch {
            process.stdout.write(`- Ahead/behind ${remote}/${baseBranch}: unavailable\n`);
        }
    }
    else {
        process.stdout.write(`- Remote "${remote}" not configured\n`);
    }
    const prUrl = await getExistingPrUrl(workspacePath, branch, baseBranch);
    process.stdout.write(`- Open PR for current branch: ${prUrl ?? "(none)"}\n`);
    try {
        const openPrs = await listOpenPullRequests(workspacePath, 50);
        const driftPrs = openPrs.filter((row) => row.headRefName.startsWith("gitforce/drift-"));
        process.stdout.write(`- Open drift PRs: ${driftPrs.length}\n`);
    }
    catch {
        process.stdout.write("- Open drift PRs: unavailable\n");
    }
    const workflowRows = [
        { id: "gitforce-pr-validate.yml", label: "validate" },
        { id: "gitforce-drift-detect.yml", label: "drift" },
        { id: "gitforce-promote.yml", label: "promote" }
    ];
    process.stdout.write("\nLatest workflow runs:\n");
    for (const workflow of workflowRows) {
        try {
            const rows = await listWorkflowRuns(workspacePath, workflow.id, 1);
            const latest = rows[0];
            if (!latest) {
                process.stdout.write(`- ${workflow.label}: no runs\n`);
                continue;
            }
            const status = latest.conclusion || latest.status;
            process.stdout.write(`- ${workflow.label}: [${status}] ${latest.createdAt} ${latest.url}\n`);
        }
        catch {
            process.stdout.write(`- ${workflow.label}: unavailable\n`);
        }
    }
}
async function runPipelineStatus(workspacePath, parsed) {
    const limit = Math.max(1, Math.min(20, getFlagNumber(parsed, "last") ?? 5));
    const workflow = getFlagString(parsed, "workflow");
    const workflows = workflow
        ? [workflow]
        : ["gitforce-promote.yml", "gitforce-drift-detect.yml", "gitforce-pr-validate.yml"];
    for (const workflowName of workflows) {
        const rows = await listWorkflowRuns(workspacePath, workflowName, limit);
        process.stdout.write(`\n${workflowName}\n`);
        if (rows.length === 0) {
            process.stdout.write("- No recent runs found.\n");
            continue;
        }
        for (const row of rows) {
            const status = row.conclusion || row.status;
            process.stdout.write(`- [${status}] ${row.createdAt} ${row.displayTitle} (${row.event}) ${row.url}\n`);
        }
    }
}
async function resolveRollbackPlanFromTargetCommit(workspacePath, remoteRef, targetCommitSha, targetExpression) {
    const { stdout: headShaStdout } = await (0, shell_1.runCommand)("git", ["rev-parse", remoteRef], workspacePath);
    const headCommitSha = headShaStdout.trim();
    if (!headCommitSha) {
        throw new Error(`Could not resolve head commit for ${remoteRef}.`);
    }
    await (0, shell_1.runCommand)("git", ["merge-base", "--is-ancestor", targetCommitSha, headCommitSha], workspacePath);
    if (headCommitSha === targetCommitSha) {
        return {
            remoteRef,
            targetCommitSha,
            headCommitSha,
            targetExpression,
            commitsToRevert: []
        };
    }
    const commitsToRevert = await resolveCommitSummaries(workspacePath, `${targetCommitSha}..${headCommitSha}`);
    return {
        remoteRef,
        targetCommitSha,
        headCommitSha,
        targetExpression,
        commitsToRevert
    };
}
async function runRollback(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const environmentLane = normalizePromotionLane(getFlagString(parsed, "env") || getFlagString(parsed, "environment"));
    const baseBranch = getFlagString(parsed, "base-branch") ||
        (environmentLane ? coreConfig.promotion.lanes[environmentLane].branch : undefined) ||
        coreConfig.repository.baseBranch ||
        "main";
    const createPr = getFlagBoolean(parsed, "pr", true);
    const forceYes = getFlagBoolean(parsed, "yes", false);
    const previewPlan = getFlagBoolean(parsed, "preview", true);
    const commitTargetRaw = getFlagString(parsed, "commit");
    const tagTargetRaw = getFlagString(parsed, "tag");
    const hasDateSelector = Boolean(getFlagString(parsed, "at")) ||
        Boolean(getFlagString(parsed, "date")) ||
        Boolean(getFlagString(parsed, "ago")) ||
        parsed.positionals.length > 0;
    const exactTargetOptions = [Boolean(commitTargetRaw), Boolean(tagTargetRaw), hasDateSelector].filter(Boolean).length;
    if (exactTargetOptions > 1) {
        throw new Error("Choose only one rollback selector: --commit, --tag, or --ago/--at.");
    }
    if (!(await (0, git_1.remoteExists)(workspacePath, remote))) {
        throw new Error(`Remote "${remote}" was not found. Configure a remote before running rollback.`);
    }
    if (await hasLocalChanges(workspacePath)) {
        const currentBranch = await resolveCurrentBranch(workspacePath);
        const confirmed = await confirmRollbackWorkspaceCleanup(remote, baseBranch, currentBranch, forceYes);
        if (!confirmed) {
            throw new Error("Rollback canceled.");
        }
        logStep("Discarding local uncommitted and untracked changes...");
        await (0, shell_1.runCommand)("git", ["reset", "--hard", "HEAD"], workspacePath);
        await (0, shell_1.runCommand)("git", ["clean", "-fd"], workspacePath);
    }
    logStep(`Fetching latest refs from "${remote}"...`);
    await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    const remoteRef = `${remote}/${baseBranch}`;
    let rollbackPlan;
    if (commitTargetRaw) {
        const { stdout } = await (0, shell_1.runCommand)("git", ["rev-parse", commitTargetRaw], workspacePath);
        const targetCommitSha = stdout.trim();
        rollbackPlan = await resolveRollbackPlanFromTargetCommit(workspacePath, remoteRef, targetCommitSha, `commit:${commitTargetRaw}`);
    }
    else if (tagTargetRaw) {
        const { stdout } = await (0, shell_1.runCommand)("git", ["rev-list", "-1", tagTargetRaw], workspacePath);
        const targetCommitSha = stdout.trim();
        if (!targetCommitSha) {
            throw new Error(`Could not resolve commit for tag "${tagTargetRaw}".`);
        }
        rollbackPlan = await resolveRollbackPlanFromTargetCommit(workspacePath, remoteRef, targetCommitSha, `tag:${tagTargetRaw}`);
    }
    else {
        const targetExpression = resolveRollbackTargetExpression(parsed);
        rollbackPlan = await resolveRollbackPlan(workspacePath, remoteRef, targetExpression);
    }
    if (rollbackPlan.commitsToRevert.length === 0) {
        process.stdout.write(`No commits to revert. ${remoteRef} is already at target commit ${rollbackPlan.targetCommitSha.slice(0, 7)}.\n`);
        return;
    }
    if (previewPlan) {
        process.stdout.write([
            "Rollback preview",
            `- Base branch: ${baseBranch}`,
            `- Target selector: ${rollbackPlan.targetExpression}`,
            `- Remote ref: ${remoteRef}`,
            `- Commits to revert: ${rollbackPlan.commitsToRevert.length}`,
            ...formatRollbackCommits(rollbackPlan.commitsToRevert, 12),
            ""
        ].join("\n"));
    }
    await promptForRollbackConfirmation(baseBranch, rollbackPlan.targetExpression, rollbackPlan.commitsToRevert, forceYes);
    const requestedBranch = getFlagString(parsed, "branch");
    const rollbackBranch = requestedBranch ||
        buildPushBranchName(`rollback-${rollbackPlan.targetCommitSha.slice(0, 7)}`, coreConfig.branchPolicy.autoBranchPrefix);
    if (await (0, git_1.branchExists)(workspacePath, rollbackBranch)) {
        throw new Error(`Rollback branch "${rollbackBranch}" already exists locally. Choose another with --branch.`);
    }
    logStep(`Creating rollback branch "${rollbackBranch}" from "${remoteRef}"...`);
    await (0, shell_1.runCommand)("git", ["checkout", "-b", rollbackBranch, remoteRef], workspacePath);
    logStep(`Reverting ${rollbackPlan.commitsToRevert.length} commit(s)...`);
    for (const commit of rollbackPlan.commitsToRevert) {
        const parentCount = await resolveCommitParentCount(workspacePath, commit.sha);
        const revertArgs = parentCount > 1
            ? ["revert", "--no-commit", "--mainline", "1", commit.sha]
            : ["revert", "--no-commit", commit.sha];
        try {
            await (0, shell_1.runCommand)("git", revertArgs, workspacePath);
        }
        catch (error) {
            try {
                await (0, shell_1.runCommand)("git", ["revert", "--abort"], workspacePath);
            }
            catch {
                // ignore abort failure
            }
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Rollback failed while reverting ${commit.sha.slice(0, 7)} (${commit.subject}). ${message}`);
        }
    }
    if (!(await hasLocalChanges(workspacePath))) {
        process.stdout.write("Rollback produced no net changes; nothing to commit.\n");
        return;
    }
    const commitTitle = getFlagString(parsed, "title") ||
        `Rollback to ${rollbackPlan.targetCommitSha.slice(0, 7)} (${rollbackPlan.targetExpression})`;
    const commitBody = [
        `Target selector: ${rollbackPlan.targetExpression}`,
        `Base branch: ${baseBranch}`,
        `Reverted commits: ${rollbackPlan.commitsToRevert.length}`
    ].join("\n");
    await ensureGitIdentity(workspacePath, undefined);
    await (0, shell_1.runCommand)("git", ["commit", "-m", commitTitle, "-m", commitBody], workspacePath);
    await (0, shell_1.runCommand)("git", ["push", "-u", remote, rollbackBranch], workspacePath);
    process.stdout.write(`Rollback branch pushed: ${rollbackBranch}\n`);
    if (!createPr) {
        process.stdout.write("PR creation skipped (--no-pr).\n");
        return;
    }
    const existingPr = await getExistingPrUrl(workspacePath, rollbackBranch, baseBranch);
    if (existingPr) {
        process.stdout.write(`PR already exists: ${existingPr}\n`);
        return;
    }
    const rollbackPrBody = buildRollbackPrBody(rollbackPlan, baseBranch);
    const { stdout } = await (0, shell_1.runCommand)("gh", [
        "pr",
        "create",
        "--base",
        baseBranch,
        "--head",
        rollbackBranch,
        "--title",
        commitTitle,
        "--body",
        rollbackPrBody
    ], workspacePath);
    const prUrl = extractPrUrl(stdout.trim()) || stdout.trim();
    process.stdout.write(prUrl ? `PR created: ${prUrl}\n` : "PR created.\n");
    const autoMergeGate = await evaluateAutoMergeSafety(workspacePath, remote, baseBranch, coreConfig);
    if (coreConfig.merge.autoMergeOnChecksPass && autoMergeGate.allowed && prUrl) {
        try {
            await enablePrAutoMerge(workspacePath, prUrl);
            process.stdout.write("Auto-merge enabled (rollback PR will merge when required checks pass).\n");
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            process.stdout.write(`Warning: could not enable PR auto-merge (${message}).\n`);
        }
    }
    else if (coreConfig.merge.autoMergeOnChecksPass && autoMergeGate.reason) {
        process.stdout.write(`Warning: auto-merge skipped (${autoMergeGate.reason})\n`);
    }
    const targetSubject = await resolveCommitSubjectBySha(workspacePath, rollbackPlan.targetCommitSha);
    process.stdout.write(`Rollback target resolved to ${rollbackPlan.targetCommitSha.slice(0, 7)} (${targetSubject}).\n`);
}
async function runRollbackRevert(workspacePath, parsed) {
    if (!(await (0, git_1.isGitRepository)(workspacePath))) {
        throw new Error("Current folder is not a git repository.");
    }
    const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    const remote = getFlagString(parsed, "remote") || "origin";
    const environmentLane = normalizePromotionLane(getFlagString(parsed, "env") || getFlagString(parsed, "environment"));
    const baseBranch = getFlagString(parsed, "base-branch") ||
        (environmentLane ? coreConfig.promotion.lanes[environmentLane].branch : undefined) ||
        coreConfig.repository.baseBranch ||
        "main";
    const createPr = getFlagBoolean(parsed, "pr", true);
    const forceYes = getFlagBoolean(parsed, "yes", false);
    const previewPlan = getFlagBoolean(parsed, "preview", true);
    const rollbackCommitSelector = getFlagString(parsed, "commit");
    if (!(await (0, git_1.remoteExists)(workspacePath, remote))) {
        throw new Error(`Remote "${remote}" was not found. Configure a remote before running rollback:revert.`);
    }
    if (await hasLocalChanges(workspacePath)) {
        const currentBranch = await resolveCurrentBranch(workspacePath);
        const confirmed = await confirmRollbackWorkspaceCleanup(remote, baseBranch, currentBranch, forceYes);
        if (!confirmed) {
            throw new Error("Rollback revert canceled.");
        }
        logStep("Discarding local uncommitted and untracked changes...");
        await (0, shell_1.runCommand)("git", ["reset", "--hard", "HEAD"], workspacePath);
        await (0, shell_1.runCommand)("git", ["clean", "-fd"], workspacePath);
    }
    logStep(`Fetching latest refs from "${remote}"...`);
    await (0, shell_1.runCommand)("git", ["fetch", remote, "--prune"], workspacePath);
    const remoteRef = `${remote}/${baseBranch}`;
    const rollbackCommit = await resolveRollbackCommitForRevert(workspacePath, remoteRef, rollbackCommitSelector);
    if (previewPlan) {
        process.stdout.write([
            "Rollback revert preview",
            `- Base branch: ${baseBranch}`,
            `- Remote ref: ${remoteRef}`,
            `- Rollback commit: ${rollbackCommit.sha.slice(0, 7)} ${rollbackCommit.subject}`,
            ""
        ].join("\n"));
    }
    await promptForRollbackRevertConfirmation(baseBranch, rollbackCommit.sha, rollbackCommit.subject, forceYes);
    const requestedBranch = getFlagString(parsed, "branch");
    const revertBranch = requestedBranch ||
        buildPushBranchName(`undo-rollback-${rollbackCommit.sha.slice(0, 7)}`, coreConfig.branchPolicy.autoBranchPrefix);
    if (await (0, git_1.branchExists)(workspacePath, revertBranch)) {
        throw new Error(`Rollback revert branch "${revertBranch}" already exists locally. Choose another with --branch.`);
    }
    logStep(`Creating rollback-revert branch "${revertBranch}" from "${remoteRef}"...`);
    await (0, shell_1.runCommand)("git", ["checkout", "-b", revertBranch, remoteRef], workspacePath);
    logStep(`Reverting rollback commit ${rollbackCommit.sha.slice(0, 7)}...`);
    const parentCount = await resolveCommitParentCount(workspacePath, rollbackCommit.sha);
    const revertArgs = parentCount > 1
        ? ["revert", "--no-commit", "--mainline", "1", rollbackCommit.sha]
        : ["revert", "--no-commit", rollbackCommit.sha];
    try {
        await (0, shell_1.runCommand)("git", revertArgs, workspacePath);
    }
    catch (error) {
        try {
            await (0, shell_1.runCommand)("git", ["revert", "--abort"], workspacePath);
        }
        catch {
            // ignore abort failure
        }
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(`Rollback revert failed while reverting ${rollbackCommit.sha.slice(0, 7)} (${rollbackCommit.subject}). ${message}`);
    }
    if (!(await hasLocalChanges(workspacePath))) {
        process.stdout.write("Rollback revert produced no net changes; nothing to commit.\n");
        return;
    }
    const commitTitle = getFlagString(parsed, "title") ||
        `Undo rollback ${rollbackCommit.sha.slice(0, 7)} (${rollbackCommit.subject})`;
    const commitBody = [
        `Rollback commit: ${rollbackCommit.sha}`,
        `Rollback subject: ${rollbackCommit.subject}`,
        `Base branch: ${baseBranch}`
    ].join("\n");
    await ensureGitIdentity(workspacePath, undefined);
    await (0, shell_1.runCommand)("git", ["commit", "-m", commitTitle, "-m", commitBody], workspacePath);
    await (0, shell_1.runCommand)("git", ["push", "-u", remote, revertBranch], workspacePath);
    process.stdout.write(`Rollback revert branch pushed: ${revertBranch}\n`);
    if (!createPr) {
        process.stdout.write("PR creation skipped (--no-pr).\n");
        return;
    }
    const existingPr = await getExistingPrUrl(workspacePath, revertBranch, baseBranch);
    if (existingPr) {
        process.stdout.write(`PR already exists: ${existingPr}\n`);
        return;
    }
    const rollbackRevertPrBody = buildRollbackRevertPrBody(baseBranch, rollbackCommit.sha, rollbackCommit.subject);
    const { stdout } = await (0, shell_1.runCommand)("gh", [
        "pr",
        "create",
        "--base",
        baseBranch,
        "--head",
        revertBranch,
        "--title",
        commitTitle,
        "--body",
        rollbackRevertPrBody
    ], workspacePath);
    const prUrl = extractPrUrl(stdout.trim()) || stdout.trim();
    process.stdout.write(prUrl ? `PR created: ${prUrl}\n` : "PR created.\n");
    const autoMergeGate = await evaluateAutoMergeSafety(workspacePath, remote, baseBranch, coreConfig);
    if (coreConfig.merge.autoMergeOnChecksPass && autoMergeGate.allowed && prUrl) {
        try {
            await enablePrAutoMerge(workspacePath, prUrl);
            process.stdout.write("Auto-merge enabled (rollback-revert PR will merge when required checks pass).\n");
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            process.stdout.write(`Warning: could not enable PR auto-merge (${message}).\n`);
        }
    }
    else if (coreConfig.merge.autoMergeOnChecksPass && autoMergeGate.reason) {
        process.stdout.write(`Warning: auto-merge skipped (${autoMergeGate.reason})\n`);
    }
    process.stdout.write(`Rollback revert target resolved to ${rollbackCommit.sha.slice(0, 7)} (${rollbackCommit.subject}).\n`);
}
async function run() {
    const command = (process.argv[2] ?? "help").trim().toLowerCase();
    const commandArgs = process.argv.slice(3);
    const options = parseOptions(commandArgs);
    const parsed = parseArgs(commandArgs);
    const workspacePath = process.cwd();
    if (["-h", "--help", "help"].includes(command)) {
        printUsage();
        return;
    }
    const supportedCommands = new Set([
        "bootstrap",
        "generate-workflows",
        "all",
        "show-config",
        "show-local-config",
        "show-basic-tests",
        "init",
        "validate",
        "doctor",
        "generate-basic-tests",
        "auth:github",
        "auth:salesforce",
        "repo:create",
        "repo:connect",
        "secrets:sync",
        "repo:harden",
        "config:set",
        "update",
        "deploy:suite",
        "deploy",
        "impact",
        "status",
        "drift:report",
        "promote",
        "profile:list",
        "profile:apply",
        "pipeline:run",
        "pipeline:status",
        "rollback",
        "rollback:revert",
        "push",
        "pull",
        "test",
        "-test",
        "--test",
        "coverage"
    ]);
    if (!supportedCommands.has(command)) {
        throw new Error(`Unknown command: ${command}`);
    }
    if (command === "init") {
        await runInit(workspacePath);
        return;
    }
    if (command === "validate") {
        await runValidate(workspacePath, options);
        return;
    }
    if (command === "doctor") {
        await runDoctor(workspacePath);
        return;
    }
    if (command === "generate-basic-tests") {
        await runGenerateBasicTests(workspacePath);
        return;
    }
    if (command === "auth:github") {
        await runAuthGitHub(workspacePath, parsed);
        return;
    }
    if (command === "auth:salesforce") {
        await runAuthSalesforce(workspacePath, parsed);
        return;
    }
    if (command === "repo:create") {
        await runRepoCreate(workspacePath, parsed);
        return;
    }
    if (command === "repo:connect") {
        await runRepoConnect(workspacePath, parsed);
        return;
    }
    if (command === "secrets:sync") {
        await runSecretsSync(workspacePath, parsed);
        return;
    }
    if (command === "repo:harden") {
        await runRepoHarden(workspacePath, parsed);
        return;
    }
    if (command === "config:set") {
        await runConfigUpdate(workspacePath, parsed, "config:set");
        return;
    }
    if (command === "update") {
        await runConfigUpdate(workspacePath, parsed, "update");
        return;
    }
    if (command === "deploy:suite" || command === "deploy") {
        await runDeploySuite(workspacePath, parsed);
        return;
    }
    if (command === "impact") {
        await runImpact(workspacePath, parsed);
        return;
    }
    if (command === "status") {
        await runStatus(workspacePath, parsed);
        return;
    }
    if (command === "drift:report") {
        await runDriftReport(workspacePath, parsed);
        return;
    }
    if (command === "promote") {
        await runPromote(workspacePath, parsed);
        return;
    }
    if (command === "profile:list") {
        await runProfileList(workspacePath);
        return;
    }
    if (command === "profile:apply") {
        await runProfileApply(workspacePath, parsed);
        return;
    }
    if (command === "pipeline:run") {
        await runPipelineRun(workspacePath, parsed);
        return;
    }
    if (command === "pipeline:status") {
        await runPipelineStatus(workspacePath, parsed);
        return;
    }
    if (command === "rollback") {
        await runRollback(workspacePath, parsed);
        return;
    }
    if (command === "rollback:revert") {
        await runRollbackRevert(workspacePath, parsed);
        return;
    }
    if (command === "push") {
        await runPush(workspacePath, parsed);
        return;
    }
    if (command === "pull") {
        await runPull(workspacePath, parsed);
        return;
    }
    if (command === "test" || command === "-test" || command === "--test") {
        await runTest(workspacePath, parsed);
        return;
    }
    if (command === "coverage") {
        await runCoverage(workspacePath, parsed);
        return;
    }
    if (command === "bootstrap") {
        const config = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
        const configPath = (0, gitforceCore_1.getGitforceCoreConfigPath)(workspacePath);
        process.stdout.write(`Bootstrapped ${path.relative(workspacePath, configPath)}\n`);
        process.stdout.write(`Repository: ${config.repository.owner || "<unset>"}/${config.repository.repo || "<unset>"}\n`);
        return;
    }
    if (command === "show-config") {
        const config = await (0, gitforceCore_1.readGitforceCoreConfig)(workspacePath);
        if (!config) {
            throw new Error("Missing gitforce-project.json. Run bootstrap first.");
        }
        process.stdout.write(`${JSON.stringify(config, null, 2)}\n`);
        return;
    }
    if (command === "show-local-config") {
        const config = await (0, gitforceLocalConfig_1.readGitforceLocalConfig)(workspacePath);
        if (!config) {
            throw new Error("Missing .gitforce/local.config.json. Run init first.");
        }
        process.stdout.write(`${JSON.stringify(config, null, 2)}\n`);
        return;
    }
    if (command === "show-basic-tests") {
        const coreConfig = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
        process.stdout.write(`${JSON.stringify(coreConfig.basicTests, null, 2)}\n`);
        return;
    }
    const config = await (0, gitforceCore_1.bootstrapGitforceCoreConfig)(workspacePath);
    await ensureSfdxProject(workspacePath, config, true);
    const artifacts = await (0, gitforceCoreWorkflows_1.writeGitforceCoreArtifacts)(workspacePath, config);
    if (command === "generate-workflows" || command === "all") {
        process.stdout.write("Generated Gitforce core artifacts:\n");
        for (const artifact of artifacts) {
            process.stdout.write(`- ${artifact.relativePath}\n`);
        }
    }
}
run().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Gitforce CLI failed: ${message}\n`);
    process.exit(1);
});
//# sourceMappingURL=gitforceCli.js.map

/***/ }),

/***/ 58:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getGitforceCoreConfigPath = getGitforceCoreConfigPath;
exports.getLegacyGitforceCoreConfigPath = getLegacyGitforceCoreConfigPath;
exports.buildDefaultCoreConfig = buildDefaultCoreConfig;
exports.readGitforceCoreConfig = readGitforceCoreConfig;
exports.writeGitforceCoreConfig = writeGitforceCoreConfig;
exports.bootstrapGitforceCoreConfig = bootstrapGitforceCoreConfig;
const fs_1 = __nccwpck_require__(896);
const path = __importStar(__nccwpck_require__(928));
const git_1 = __nccwpck_require__(48);
const gitforceBasicTests_1 = __nccwpck_require__(834);
const repoSyncConfig_1 = __nccwpck_require__(59);
const PROJECT_CONFIG_FILE = "gitforce-project.json";
const LEGACY_GITFORCE_DIR = ".gitforce";
const LEGACY_CORE_CONFIG_FILE = "core.config.json";
function normalizeStringArray(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    const output = [];
    for (const entry of value) {
        if (typeof entry !== "string") {
            continue;
        }
        const trimmed = entry.trim();
        if (!trimmed || output.includes(trimmed)) {
            continue;
        }
        output.push(trimmed);
    }
    return output;
}
function normalizeSfdxPackageDirectories(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    const output = [];
    const dedupe = new Set();
    for (const entry of value) {
        if (!entry || typeof entry !== "object") {
            continue;
        }
        const typed = entry;
        const rawPath = typeof typed.path === "string" ? typed.path.trim() : "";
        if (!rawPath) {
            continue;
        }
        const normalizedPath = rawPath.replace(/^\.\/+/, "").replace(/\/+$/, "");
        if (!normalizedPath) {
            continue;
        }
        const key = normalizedPath.toLowerCase();
        if (dedupe.has(key)) {
            continue;
        }
        dedupe.add(key);
        output.push({
            path: normalizedPath,
            default: typed.default === true
        });
    }
    return output;
}
function normalizeUserMappings(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    const seen = new Set();
    const output = [];
    for (const entry of value) {
        if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
            continue;
        }
        const typed = entry;
        const salesforceUsername = typeof typed.salesforceUsername === "string" ? typed.salesforceUsername.trim() : "";
        const githubUsername = typeof typed.githubUsername === "string" ? typed.githubUsername.trim() : "";
        if (!salesforceUsername || !githubUsername) {
            continue;
        }
        const key = `${salesforceUsername.toLowerCase()}::${githubUsername.toLowerCase()}`;
        if (seen.has(key)) {
            continue;
        }
        seen.add(key);
        output.push({ salesforceUsername, githubUsername });
    }
    return output;
}
function normalizeCodeOwnerRules(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    const dedupe = new Set();
    const output = [];
    for (const entry of value) {
        if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
            continue;
        }
        const typed = entry;
        const pattern = typeof typed.pattern === "string" ? typed.pattern.trim() : "";
        const owners = normalizeStringArray(typed.owners).map((owner) => owner.startsWith("@") ? owner : `@${owner}`);
        if (!pattern || owners.length === 0) {
            continue;
        }
        const key = `${pattern}::${owners.join(",").toLowerCase()}`;
        if (dedupe.has(key)) {
            continue;
        }
        dedupe.add(key);
        output.push({
            pattern,
            owners
        });
    }
    return output;
}
function normalizeBranchPrefix(value, fallback) {
    const raw = typeof value === "string" ? value.trim() : "";
    if (!raw) {
        return fallback;
    }
    const normalized = raw.replace(/^\/+/, "");
    if (!normalized) {
        return fallback;
    }
    return normalized.endsWith("/") ? normalized : `${normalized}/`;
}
function normalizeBranchReservedPrefixes(value) {
    const output = [];
    for (const entry of normalizeStringArray(value)) {
        const normalized = entry.replace(/^\/+/, "");
        if (!normalized) {
            continue;
        }
        if (!output.includes(normalized)) {
            output.push(normalized);
        }
    }
    return output;
}
function normalizeTestLevel(value) {
    const normalized = typeof value === "string" ? value.trim() : "";
    if (normalized === "RunSpecifiedTests" || normalized === "RunAllTestsInOrg") {
        return normalized;
    }
    return "RunLocalTests";
}
function normalizeDriftMode(value) {
    const normalized = typeof value === "string" ? value.trim() : "";
    if (normalized === "pr-automerge" || normalized === "alert-only") {
        return normalized;
    }
    return "pr-only";
}
function normalizeDeployMode(value) {
    const normalized = typeof value === "string" ? value.trim() : "";
    if (normalized === "auto-integration" || normalized === "auto-target") {
        return normalized;
    }
    return "manual-promote";
}
function normalizeScopeMode(value, fallback) {
    const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (normalized === "full") {
        return "full";
    }
    if (normalized === "changed") {
        return "changed";
    }
    return fallback;
}
function normalizeRiskThreshold(value, fallback) {
    const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (normalized === "medium" || normalized === "high") {
        return normalized;
    }
    if (normalized === "low") {
        return "low";
    }
    return fallback;
}
function normalizePromotionStrategy(value, fallback) {
    const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (normalized === "three-lane-fixed") {
        return "three-lane-fixed";
    }
    return fallback;
}
function normalizePolicyProfileName(value, fallback) {
    const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (normalized === "relaxed" || normalized === "strict") {
        return normalized;
    }
    if (normalized === "balanced") {
        return "balanced";
    }
    return fallback;
}
function normalizeOptionalPolicyProfileName(value) {
    const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (normalized === "relaxed" || normalized === "balanced" || normalized === "strict") {
        return normalized;
    }
    return undefined;
}
function normalizeBranchName(value, fallback) {
    if (typeof value !== "string") {
        return fallback;
    }
    const trimmed = value.trim();
    return trimmed || fallback;
}
function normalizeDestructiveIntentPath(value, fallback) {
    if (typeof value !== "string") {
        return fallback;
    }
    const trimmed = value.trim().replace(/\\/g, "/");
    if (!trimmed) {
        return fallback;
    }
    const compact = trimmed.replace(/\/{2,}/g, "/").replace(/\/+$/, "");
    let normalized = compact;
    if (normalized.startsWith("./")) {
        normalized = normalized.slice(2);
    }
    normalized = normalized.replace(/^\/+/, "");
    if (!normalized) {
        return fallback;
    }
    if (normalized === ".gitforce" || normalized === "gitforce") {
        return ".gitforce";
    }
    if (normalized.startsWith(".gitforce/")) {
        return normalized;
    }
    if (normalized.startsWith("gitforce/")) {
        return `.${normalized}`;
    }
    return `.gitforce/${normalized}`;
}
function buildDefaultPolicyProfiles() {
    return {
        defaultProfile: "balanced",
        environmentOverrides: {},
        profiles: {
            relaxed: {
                requiredChecks: ["validate"],
                analyzerSeverityGate: 3,
                validationScope: "changed",
                requirePullRequest: true,
                allowAutoMerge: true,
                autoMergeOnChecksPass: true,
                deployTestLevel: "RunLocalTests"
            },
            balanced: {
                requiredChecks: ["validate", "salesforce-code-analyzer", "salesforce-validate"],
                analyzerSeverityGate: 2,
                validationScope: "changed",
                requirePullRequest: true,
                allowAutoMerge: true,
                autoMergeOnChecksPass: true,
                deployTestLevel: "RunLocalTests"
            },
            strict: {
                requiredChecks: [
                    "validate",
                    "npm-test",
                    "salesforce-code-analyzer",
                    "salesforce-validate"
                ],
                analyzerSeverityGate: 1,
                validationScope: "full",
                requirePullRequest: true,
                allowAutoMerge: false,
                autoMergeOnChecksPass: false,
                deployTestLevel: "RunAllTestsInOrg"
            }
        }
    };
}
function normalizePolicyProfileConfig(value, fallback) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return fallback;
    }
    const typed = value;
    const analyzerSeverityGateRaw = Number(typed.analyzerSeverityGate);
    const analyzerSeverityGate = Number.isInteger(analyzerSeverityGateRaw) &&
        analyzerSeverityGateRaw >= 1 &&
        analyzerSeverityGateRaw <= 5
        ? analyzerSeverityGateRaw
        : fallback.analyzerSeverityGate;
    return {
        requiredChecks: normalizeStringArray(typed.requiredChecks).length > 0
            ? normalizeStringArray(typed.requiredChecks)
            : fallback.requiredChecks,
        analyzerSeverityGate,
        validationScope: normalizeScopeMode(typed.validationScope, fallback.validationScope),
        requirePullRequest: typeof typed.requirePullRequest === "boolean"
            ? typed.requirePullRequest
            : fallback.requirePullRequest,
        allowAutoMerge: typeof typed.allowAutoMerge === "boolean" ? typed.allowAutoMerge : fallback.allowAutoMerge,
        autoMergeOnChecksPass: typeof typed.autoMergeOnChecksPass === "boolean"
            ? typed.autoMergeOnChecksPass
            : fallback.autoMergeOnChecksPass,
        deployTestLevel: normalizeTestLevel(typed.deployTestLevel ?? fallback.deployTestLevel)
    };
}
function getGitforceCoreConfigPath(workspacePath) {
    return path.join(workspacePath, PROJECT_CONFIG_FILE);
}
function getLegacyGitforceCoreConfigPath(workspacePath) {
    return path.join(workspacePath, LEGACY_GITFORCE_DIR, LEGACY_CORE_CONFIG_FILE);
}
function buildDefaultCoreConfig() {
    const intervalMinutes = 1440;
    const policyProfiles = buildDefaultPolicyProfiles();
    return {
        version: 2,
        repository: {
            owner: "",
            repo: "",
            baseBranch: "main"
        },
        tracked: {
            paths: ["force-app"],
            metadataTypes: [
                "ApexClass",
                "ApexTrigger",
                "LightningComponentBundle",
                "AuraDefinitionBundle",
                "CustomObject",
                "CustomField"
            ]
        },
        environments: {
            developmentOrgAlias: undefined,
            sandboxOrgAlias: undefined,
            productionOrgAlias: undefined,
            targetOrgAlias: ""
        },
        drift: {
            enabled: true,
            intervalMinutes,
            cron: (0, repoSyncConfig_1.buildCronExpression)(intervalMinutes),
            mode: "pr-only"
        },
        destructiveChanges: {
            enabled: true,
            intentPath: ".gitforce/deletes/pending"
        },
        merge: {
            requirePullRequest: true,
            allowAutoMerge: true,
            autoMergeOnChecksPass: true,
            requiredChecks: ["validate"]
        },
        branchPolicy: {
            autoBranch: true,
            autoBranchPrefix: "feature/",
            enforcePrefix: true,
            disallowDirectPushToBase: true,
            reservedPrefixes: ["gitforce/drift-"]
        },
        governance: {
            hardenRepository: true,
            requiredApprovingReviewCount: 0,
            requireCodeOwnerReviews: false,
            requireConversationResolution: true,
            dismissStaleReviews: false,
            enforceAdmins: false,
            allowForcePushes: false,
            allowDeletions: false,
            autoDeleteBranchOnMerge: true,
            codeOwners: []
        },
        deploy: {
            mode: "manual-promote",
            testLevel: "RunLocalTests",
            specifiedTests: []
        },
        tests: {
            enableBasicDataTests: false,
            generatedApexClassName: "GitforceDataQualityBuiltInTest"
        },
        validation: {
            scope: "changed"
        },
        basicTests: (0, gitforceBasicTests_1.buildDefaultBasicTestsConfig)(),
        codeAnalyzer: {
            enabled: true,
            failOnSeverity: 2,
            scope: "changed",
            changedFilesOnly: true
        },
        changeIntelligence: {
            enabled: true,
            mode: "metadata-graph",
            riskThreshold: "medium",
            commentOnPr: true,
            maxPrSummaryItems: 200
        },
        promotion: {
            strategy: "three-lane-fixed",
            lanes: {
                development: { branch: "develop" },
                sandbox: { branch: "sandbox" },
                production: { branch: "main" }
            },
            autoPromote: false
        },
        policyProfiles,
        orchestration: {
            enabled: true,
            maxConcurrentPerLane: 1,
            publishRunSummary: true
        },
        sfdxProject: {
            name: "",
            namespace: "",
            sfdcLoginUrl: "https://login.salesforce.com",
            sourceApiVersion: "66.0",
            packageDirectories: [
                {
                    path: "force-app",
                    default: true
                }
            ]
        },
        users: []
    };
}
function parseCoreConfig(raw) {
    const defaults = buildDefaultCoreConfig();
    const parsed = JSON.parse(raw);
    const repository = (parsed.repository ?? {});
    const tracked = (parsed.tracked ?? {});
    const environments = (parsed.environments ?? {});
    const drift = (parsed.drift ?? {});
    const destructiveChanges = (parsed.destructiveChanges ?? {});
    const merge = (parsed.merge ?? {});
    const branchPolicy = (parsed.branchPolicy ?? {});
    const governance = (parsed.governance ?? {});
    const deploy = (parsed.deploy ?? {});
    const tests = (parsed.tests ?? {});
    const validation = (parsed.validation ?? {});
    const basicTests = parsed.basicTests !== undefined
        ? (0, gitforceBasicTests_1.normalizeBasicTestsConfig)(parsed.basicTests)
        : defaults.basicTests;
    const codeAnalyzer = (parsed.codeAnalyzer ?? {});
    const changeIntelligence = (parsed.changeIntelligence ?? {});
    const promotion = (parsed.promotion ?? {});
    const policyProfiles = (parsed.policyProfiles ?? {});
    const orchestration = (parsed.orchestration ?? {});
    const sfdxProject = (parsed.sfdxProject ?? {});
    const users = normalizeUserMappings(parsed.users);
    const intervalMinutes = (0, repoSyncConfig_1.normalizeSyncIntervalMinutes)(drift.intervalMinutes ?? defaults.drift.intervalMinutes);
    const failOnSeverityRaw = Number(codeAnalyzer.failOnSeverity);
    const failOnSeverity = Number.isInteger(failOnSeverityRaw) && failOnSeverityRaw >= 1 && failOnSeverityRaw <= 5
        ? failOnSeverityRaw
        : defaults.codeAnalyzer.failOnSeverity;
    const packageDirectories = normalizeSfdxPackageDirectories(sfdxProject.packageDirectories).length > 0
        ? normalizeSfdxPackageDirectories(sfdxProject.packageDirectories)
        : defaults.sfdxProject.packageDirectories;
    const requiredApprovingReviewCountRaw = Number(governance.requiredApprovingReviewCount);
    const requiredApprovingReviewCount = Number.isInteger(requiredApprovingReviewCountRaw) &&
        requiredApprovingReviewCountRaw >= 0 &&
        requiredApprovingReviewCountRaw <= 6
        ? requiredApprovingReviewCountRaw
        : defaults.governance.requiredApprovingReviewCount;
    const codeOwners = normalizeCodeOwnerRules(governance.codeOwners).length > 0
        ? normalizeCodeOwnerRules(governance.codeOwners)
        : defaults.governance.codeOwners;
    const allowAutoMerge = merge.allowAutoMerge !== false;
    const autoMergeOnChecksPass = merge.autoMergeOnChecksPass !== false && allowAutoMerge;
    const validationScope = normalizeScopeMode(validation.scope, defaults.validation.scope);
    const legacyChangedFilesOnly = typeof codeAnalyzer.changedFilesOnly === "boolean" ? codeAnalyzer.changedFilesOnly : undefined;
    const codeAnalyzerScope = normalizeScopeMode(codeAnalyzer.scope, legacyChangedFilesOnly === false ? "full" : defaults.codeAnalyzer.scope);
    const maxPrSummaryItemsRaw = Number(changeIntelligence.maxPrSummaryItems);
    const maxPrSummaryItems = Number.isInteger(maxPrSummaryItemsRaw) && maxPrSummaryItemsRaw >= 1
        ? maxPrSummaryItemsRaw
        : defaults.changeIntelligence.maxPrSummaryItems;
    const promotionLanes = (promotion.lanes ?? {});
    const defaultPolicyProfiles = defaults.policyProfiles;
    const profileOverrides = (policyProfiles.profiles ?? {});
    const normalizedPolicyProfiles = {
        relaxed: normalizePolicyProfileConfig(profileOverrides.relaxed, defaultPolicyProfiles.profiles.relaxed),
        balanced: normalizePolicyProfileConfig(profileOverrides.balanced, defaultPolicyProfiles.profiles.balanced),
        strict: normalizePolicyProfileConfig(profileOverrides.strict, defaultPolicyProfiles.profiles.strict)
    };
    const environmentOverrides = policyProfiles.environmentOverrides && typeof policyProfiles.environmentOverrides === "object"
        ? policyProfiles.environmentOverrides
        : {};
    const maxConcurrentPerLaneRaw = Number(orchestration.maxConcurrentPerLane);
    const maxConcurrentPerLane = Number.isInteger(maxConcurrentPerLaneRaw) && maxConcurrentPerLaneRaw > 0
        ? maxConcurrentPerLaneRaw
        : defaults.orchestration.maxConcurrentPerLane;
    const reservedPrefixes = normalizeBranchReservedPrefixes(branchPolicy.reservedPrefixes).length > 0
        ? normalizeBranchReservedPrefixes(branchPolicy.reservedPrefixes)
        : defaults.branchPolicy.reservedPrefixes;
    return {
        version: 2,
        repository: {
            owner: typeof repository.owner === "string" ? repository.owner.trim() : defaults.repository.owner,
            repo: typeof repository.repo === "string" ? repository.repo.trim() : defaults.repository.repo,
            baseBranch: typeof repository.baseBranch === "string" && repository.baseBranch.trim()
                ? repository.baseBranch.trim()
                : defaults.repository.baseBranch
        },
        tracked: {
            paths: normalizeStringArray(tracked.paths).length > 0 ? normalizeStringArray(tracked.paths) : defaults.tracked.paths,
            metadataTypes: normalizeStringArray(tracked.metadataTypes).length > 0
                ? normalizeStringArray(tracked.metadataTypes)
                : defaults.tracked.metadataTypes
        },
        environments: {
            integrationOrgAlias: typeof environments.integrationOrgAlias === "string" && environments.integrationOrgAlias.trim()
                ? environments.integrationOrgAlias.trim()
                : undefined,
            developmentOrgAlias: typeof environments.developmentOrgAlias === "string" && environments.developmentOrgAlias.trim()
                ? environments.developmentOrgAlias.trim()
                : undefined,
            sandboxOrgAlias: typeof environments.sandboxOrgAlias === "string" && environments.sandboxOrgAlias.trim()
                ? environments.sandboxOrgAlias.trim()
                : undefined,
            productionOrgAlias: typeof environments.productionOrgAlias === "string" && environments.productionOrgAlias.trim()
                ? environments.productionOrgAlias.trim()
                : undefined,
            targetOrgAlias: typeof environments.targetOrgAlias === "string"
                ? environments.targetOrgAlias.trim()
                : defaults.environments.targetOrgAlias
        },
        drift: {
            enabled: drift.enabled !== false,
            intervalMinutes,
            cron: typeof drift.cron === "string" && drift.cron.trim()
                ? drift.cron.trim()
                : (0, repoSyncConfig_1.buildCronExpression)(intervalMinutes),
            mode: normalizeDriftMode(drift.mode)
        },
        destructiveChanges: {
            enabled: typeof destructiveChanges.enabled === "boolean"
                ? destructiveChanges.enabled
                : defaults.destructiveChanges.enabled,
            intentPath: normalizeDestructiveIntentPath(destructiveChanges.intentPath, defaults.destructiveChanges.intentPath)
        },
        merge: {
            requirePullRequest: merge.requirePullRequest !== false,
            allowAutoMerge,
            autoMergeOnChecksPass,
            requiredChecks: normalizeStringArray(merge.requiredChecks).length > 0
                ? normalizeStringArray(merge.requiredChecks)
                : defaults.merge.requiredChecks
        },
        branchPolicy: {
            autoBranch: branchPolicy.autoBranch !== false,
            autoBranchPrefix: normalizeBranchPrefix(branchPolicy.autoBranchPrefix, defaults.branchPolicy.autoBranchPrefix),
            enforcePrefix: branchPolicy.enforcePrefix !== false,
            disallowDirectPushToBase: branchPolicy.disallowDirectPushToBase !== false,
            reservedPrefixes
        },
        governance: {
            hardenRepository: governance.hardenRepository !== false,
            requiredApprovingReviewCount,
            requireCodeOwnerReviews: governance.requireCodeOwnerReviews === true,
            requireConversationResolution: governance.requireConversationResolution !== false,
            dismissStaleReviews: governance.dismissStaleReviews === true,
            enforceAdmins: governance.enforceAdmins === true,
            allowForcePushes: governance.allowForcePushes === true,
            allowDeletions: governance.allowDeletions === true,
            autoDeleteBranchOnMerge: governance.autoDeleteBranchOnMerge !== false,
            codeOwners
        },
        deploy: {
            mode: normalizeDeployMode(deploy.mode),
            testLevel: normalizeTestLevel(deploy.testLevel),
            specifiedTests: normalizeStringArray(deploy.specifiedTests)
        },
        tests: {
            enableBasicDataTests: tests.enableBasicDataTests === true,
            generatedApexClassName: typeof tests.generatedApexClassName === "string" && tests.generatedApexClassName.trim()
                ? tests.generatedApexClassName.trim()
                : basicTests.generatedClassName
        },
        validation: {
            scope: validationScope
        },
        basicTests,
        codeAnalyzer: {
            enabled: codeAnalyzer.enabled !== false,
            failOnSeverity,
            scope: codeAnalyzerScope,
            changedFilesOnly: codeAnalyzerScope === "changed"
        },
        changeIntelligence: {
            enabled: changeIntelligence.enabled !== false,
            mode: "metadata-graph",
            riskThreshold: normalizeRiskThreshold(changeIntelligence.riskThreshold, defaults.changeIntelligence.riskThreshold),
            commentOnPr: typeof changeIntelligence.commentOnPr === "boolean"
                ? changeIntelligence.commentOnPr
                : defaults.changeIntelligence.commentOnPr,
            maxPrSummaryItems
        },
        promotion: {
            strategy: normalizePromotionStrategy(promotion.strategy, defaults.promotion.strategy),
            lanes: {
                development: {
                    branch: normalizeBranchName(promotionLanes.development?.branch, defaults.promotion.lanes.development.branch)
                },
                sandbox: {
                    branch: normalizeBranchName(promotionLanes.sandbox?.branch, defaults.promotion.lanes.sandbox.branch)
                },
                production: {
                    branch: normalizeBranchName(promotionLanes.production?.branch, defaults.promotion.lanes.production.branch)
                }
            },
            autoPromote: typeof promotion.autoPromote === "boolean"
                ? promotion.autoPromote
                : defaults.promotion.autoPromote
        },
        policyProfiles: {
            defaultProfile: normalizePolicyProfileName(policyProfiles.defaultProfile, defaults.policyProfiles.defaultProfile),
            environmentOverrides: {
                development: normalizeOptionalPolicyProfileName(environmentOverrides.development),
                sandbox: normalizeOptionalPolicyProfileName(environmentOverrides.sandbox),
                production: normalizeOptionalPolicyProfileName(environmentOverrides.production)
            },
            profiles: normalizedPolicyProfiles
        },
        orchestration: {
            enabled: typeof orchestration.enabled === "boolean"
                ? orchestration.enabled
                : defaults.orchestration.enabled,
            maxConcurrentPerLane,
            publishRunSummary: typeof orchestration.publishRunSummary === "boolean"
                ? orchestration.publishRunSummary
                : defaults.orchestration.publishRunSummary
        },
        sfdxProject: {
            name: typeof sfdxProject.name === "string" && sfdxProject.name.trim()
                ? sfdxProject.name.trim()
                : defaults.sfdxProject.name,
            namespace: typeof sfdxProject.namespace === "string"
                ? sfdxProject.namespace.trim()
                : defaults.sfdxProject.namespace,
            sfdcLoginUrl: typeof sfdxProject.sfdcLoginUrl === "string" && sfdxProject.sfdcLoginUrl.trim()
                ? sfdxProject.sfdcLoginUrl.trim()
                : defaults.sfdxProject.sfdcLoginUrl,
            sourceApiVersion: typeof sfdxProject.sourceApiVersion === "string" && sfdxProject.sourceApiVersion.trim()
                ? sfdxProject.sourceApiVersion.trim()
                : defaults.sfdxProject.sourceApiVersion,
            packageDirectories
        },
        users: users.length > 0 ? users : defaults.users
    };
}
async function readGitforceCoreConfig(workspacePath) {
    const projectConfigPath = getGitforceCoreConfigPath(workspacePath);
    const legacyConfigPath = getLegacyGitforceCoreConfigPath(workspacePath);
    try {
        const raw = await fs_1.promises.readFile(projectConfigPath, "utf8");
        return parseCoreConfig(raw);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (!/enoent/i.test(message)) {
            throw new Error(`Failed to parse ${PROJECT_CONFIG_FILE}: ${message}`);
        }
    }
    try {
        const raw = await fs_1.promises.readFile(legacyConfigPath, "utf8");
        return parseCoreConfig(raw);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (/enoent/i.test(message)) {
            return undefined;
        }
        throw new Error(`Failed to parse ${LEGACY_GITFORCE_DIR}/${LEGACY_CORE_CONFIG_FILE}: ${message}`);
    }
}
async function writeGitforceCoreConfig(workspacePath, config) {
    const configPath = getGitforceCoreConfigPath(workspacePath);
    await fs_1.promises.mkdir(path.dirname(configPath), { recursive: true });
    await fs_1.promises.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, "utf8");
    return configPath;
}
async function bootstrapGitforceCoreConfig(workspacePath) {
    const existing = await readGitforceCoreConfig(workspacePath);
    if (existing) {
        const projectConfigPath = getGitforceCoreConfigPath(workspacePath);
        try {
            await fs_1.promises.access(projectConfigPath);
        }
        catch {
            const legacyBasicTests = await (0, gitforceBasicTests_1.readBasicTestsConfig)(workspacePath, ".gitforce/basic-tests.json");
            if (legacyBasicTests) {
                existing.basicTests = legacyBasicTests;
                existing.tests.generatedApexClassName = legacyBasicTests.generatedClassName;
            }
            await writeGitforceCoreConfig(workspacePath, existing);
        }
        return existing;
    }
    const defaults = buildDefaultCoreConfig();
    const repoSyncConfig = await (0, repoSyncConfig_1.readRepoSyncConfig)(workspacePath);
    if (!repoSyncConfig) {
        try {
            const remoteUrl = await (0, git_1.getRemoteUrl)(workspacePath, "origin");
            const coordinates = (0, git_1.parseGitHubRemote)(remoteUrl);
            defaults.repository.owner = coordinates.owner;
            defaults.repository.repo = coordinates.repo;
        }
        catch {
            // ignore: bootstrap still succeeds with empty owner/repo
        }
        await writeGitforceCoreConfig(workspacePath, defaults);
        return defaults;
    }
    const intervalMinutes = (0, repoSyncConfig_1.normalizeSyncIntervalMinutes)(repoSyncConfig.sync.intervalMinutes);
    const merged = {
        ...defaults,
        repository: {
            owner: repoSyncConfig.repository.owner,
            repo: repoSyncConfig.repository.repo,
            baseBranch: repoSyncConfig.repository.baseBranch || defaults.repository.baseBranch
        },
        tracked: {
            paths: repoSyncConfig.metadata.includePaths.length > 0
                ? repoSyncConfig.metadata.includePaths
                : defaults.tracked.paths,
            metadataTypes: repoSyncConfig.metadata.includeTypes.length > 0
                ? repoSyncConfig.metadata.includeTypes
                : defaults.tracked.metadataTypes
        },
        environments: {
            integrationOrgAlias: undefined,
            developmentOrgAlias: undefined,
            sandboxOrgAlias: undefined,
            productionOrgAlias: repoSyncConfig.salesforce.orgAlias || undefined,
            targetOrgAlias: repoSyncConfig.salesforce.orgAlias || defaults.environments.targetOrgAlias
        },
        drift: {
            enabled: repoSyncConfig.sync.enabled,
            intervalMinutes,
            cron: (0, repoSyncConfig_1.buildCronExpression)(intervalMinutes),
            mode: repoSyncConfig.sync.autoMerge ? "pr-automerge" : "pr-only"
        },
        destructiveChanges: defaults.destructiveChanges,
        merge: {
            requirePullRequest: true,
            allowAutoMerge: repoSyncConfig.sync.autoMerge,
            autoMergeOnChecksPass: repoSyncConfig.sync.autoMerge,
            requiredChecks: defaults.merge.requiredChecks
        },
        branchPolicy: defaults.branchPolicy,
        deploy: {
            mode: defaults.deploy.mode,
            testLevel: defaults.deploy.testLevel,
            specifiedTests: defaults.deploy.specifiedTests
        },
        tests: {
            enableBasicDataTests: defaults.tests.enableBasicDataTests,
            generatedApexClassName: defaults.tests.generatedApexClassName
        },
        validation: defaults.validation,
        basicTests: defaults.basicTests,
        codeAnalyzer: {
            enabled: defaults.codeAnalyzer.enabled,
            failOnSeverity: defaults.codeAnalyzer.failOnSeverity,
            scope: defaults.codeAnalyzer.scope,
            changedFilesOnly: defaults.codeAnalyzer.changedFilesOnly
        },
        sfdxProject: defaults.sfdxProject,
        users: repoSyncConfig.users.map((mapping) => ({
            salesforceUsername: mapping.salesforceUsername,
            githubUsername: mapping.githubUsername
        }))
    };
    await writeGitforceCoreConfig(workspacePath, merged);
    return merged;
}
//# sourceMappingURL=gitforceCore.js.map

/***/ }),

/***/ 518:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buildGitforceCoreArtifacts = buildGitforceCoreArtifacts;
exports.writeGitforceCoreArtifacts = writeGitforceCoreArtifacts;
const fs_1 = __nccwpck_require__(896);
const path = __importStar(__nccwpck_require__(928));
const repoSyncConfig_1 = __nccwpck_require__(59);
const gitforceDriftScriptTemplate_1 = __nccwpck_require__(11);
function toShellSingleQuoted(value) {
    return `'${value.replace(/'/g, `'\"'\"'`)}'`;
}
function buildDestructiveIntentScriptLines(config) {
    const deleteIntentPath = config.destructiveChanges.intentPath || ".gitforce/deletes/pending";
    const includeTypeLiterals = config.tracked.metadataTypes
        .map((entry) => toShellSingleQuoted(entry))
        .join(" ");
    return [
        `          delete_intent_enabled=${config.destructiveChanges.enabled ? "true" : "false"}`,
        `          delete_intent_path=${toShellSingleQuoted(deleteIntentPath)}`,
        `          declare -a tracked_types=(${includeTypeLiterals})`,
        "          declare -A destructive_components=()",
        "          delete_intent_count=0",
        "          delete_package_manifest=\"$RUNNER_TEMP/gitforce-delete-package.xml\"",
        "          delete_manifest=\"$RUNNER_TEMP/gitforce-delete-post.xml\"",
        "",
        "          has_tracked_type() {",
        "            local candidate_type=\"$1\"",
        "            if [[ ${#tracked_types[@]} -eq 0 ]]; then",
        "              return 0",
        "            fi",
        "            for tracked_type in \"${tracked_types[@]}\"; do",
        "              if [[ \"$tracked_type\" == \"$candidate_type\" ]]; then",
        "                return 0",
        "              fi",
        "            done",
        "            return 1",
        "          }",
        "",
        "          add_destructive_component() {",
        "            local metadata_type=\"$1\"",
        "            local member_name=\"$2\"",
        "            [[ -z \"$metadata_type\" || -z \"$member_name\" ]] && return 0",
        "            has_tracked_type \"$metadata_type\" || return 0",
        "            destructive_components[\"${metadata_type}::${member_name}\"]=1",
        "          }",
        "",
        "          detect_destructive_component() {",
        "            local file_path=\"$1\"",
        "            local normalized=\"${file_path#./}\"",
        "            if [[ \"$normalized\" != \"$delete_intent_path/\"* ]]; then",
        "              return 0",
        "            fi",
        "",
        "            local relative_path=\"${normalized#${delete_intent_path}/}\"",
        "            local metadata_type=\"\"",
        "            local member_name=\"\"",
        "",
        "            if [[ \"$relative_path\" =~ (^|/)classes/([^/]+)\\.cls(-meta\\.xml)?$ ]]; then",
        "              metadata_type=\"ApexClass\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)triggers/([^/]+)\\.trigger(-meta\\.xml)?$ ]]; then",
        "              metadata_type=\"ApexTrigger\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)lwc/([^/]+)/ ]]; then",
        "              metadata_type=\"LightningComponentBundle\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)aura/([^/]+)/ ]]; then",
        "              metadata_type=\"AuraDefinitionBundle\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)objects/([^/]+)/fields/([^/]+)\\.field-meta\\.xml$ ]]; then",
        "              metadata_type=\"CustomField\"",
        "              member_name=\"${BASH_REMATCH[2]}.${BASH_REMATCH[3]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)objects/([^/]+)/[^/]+\\.object-meta\\.xml$ ]]; then",
        "              metadata_type=\"CustomObject\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)layouts/([^/]+)\\.layout-meta\\.xml$ ]]; then",
        "              metadata_type=\"Layout\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)permissionSets/([^/]+)\\.permissionset-meta\\.xml$ ]]; then",
        "              metadata_type=\"PermissionSet\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)profiles/([^/]+)\\.profile-meta\\.xml$ ]]; then",
        "              metadata_type=\"Profile\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            elif [[ \"$relative_path\" =~ (^|/)flows/([^/]+)\\.flow-meta\\.xml$ ]]; then",
        "              metadata_type=\"Flow\"",
        "              member_name=\"${BASH_REMATCH[2]}\"",
        "            fi",
        "",
        "            add_destructive_component \"$metadata_type\" \"$member_name\"",
        "          }",
        "",
        "          write_destructive_manifest() {",
        "            {",
        "              echo '<?xml version=\"1.0\" encoding=\"UTF-8\"?>'",
        "              echo '<Package xmlns=\"http://soap.sforce.com/2006/04/metadata\">'",
        "              echo '  <version>66.0</version>'",
        "              echo '</Package>'",
        "            } > \"$delete_package_manifest\"",
        "",
        "            mapfile -t destructive_types < <(",
        "              printf '%s\\n' \"${!destructive_components[@]}\" |",
        "              awk -F'::' '{print $1}' |",
        "              LC_ALL=C sort -u",
        "            )",
        "",
        "            {",
        "              echo '<?xml version=\"1.0\" encoding=\"UTF-8\"?>'",
        "              echo '<Package xmlns=\"http://soap.sforce.com/2006/04/metadata\">'",
        "              for destructive_type in \"${destructive_types[@]}\"; do",
        "                [[ -z \"$destructive_type\" ]] && continue",
        "                echo '  <types>'",
        "                mapfile -t destructive_members < <(",
        "                  printf '%s\\n' \"${!destructive_components[@]}\" |",
        "                  awk -F'::' -v current_type=\"$destructive_type\" '$1==current_type {print $2}' |",
        "                  LC_ALL=C sort -u",
        "                )",
        "                for destructive_member in \"${destructive_members[@]}\"; do",
        "                  [[ -z \"$destructive_member\" ]] && continue",
        "                  echo \"    <members>${destructive_member}</members>\"",
        "                done",
        "                echo \"    <name>${destructive_type}</name>\"",
        "                echo '  </types>'",
        "              done",
        "              echo '  <version>66.0</version>'",
        "              echo '</Package>'",
        "            } > \"$delete_manifest\"",
        "          }",
        "",
        "          collect_destructive_components() {",
        "            if [[ \"$delete_intent_enabled\" != \"true\" ]]; then",
        "              return 0",
        "            fi",
        "            if [[ ! -d \"$delete_intent_path\" ]]; then",
        "              return 0",
        "            fi",
        "",
        "            while IFS= read -r intent_file; do",
        "              [[ -z \"$intent_file\" ]] && continue",
        "              detect_destructive_component \"$intent_file\"",
        "            done < <(find \"$delete_intent_path\" -type f | LC_ALL=C sort)",
        "",
        "            delete_intent_count=${#destructive_components[@]}",
        "            if [[ $delete_intent_count -gt 0 ]]; then",
        "              write_destructive_manifest",
        "            fi",
        "          }",
        "",
        "          collect_destructive_components",
        "          echo \"delete_count=${delete_intent_count}\" >> \"$GITHUB_OUTPUT\"",
        "          if [[ $delete_intent_count -gt 0 ]]; then",
        "            {",
        "              echo 'delete_components<<EOF'",
        "              printf '%s\\n' \"${!destructive_components[@]}\" | LC_ALL=C sort",
        "              echo 'EOF'",
        "            } >> \"$GITHUB_OUTPUT\"",
        "          fi"
    ];
}
function buildCodeAnalyzerSteps(config, includeGitHubToken) {
    if (!config.codeAnalyzer.enabled) {
        return [];
    }
    const severity = config.codeAnalyzer.failOnSeverity;
    const changedFilesOnly = config.codeAnalyzer.scope === "changed";
    const severityOutput = `num-sev${severity}-violations`;
    const scopeLabel = changedFilesOnly ? "changed deployment files" : "entire workspace";
    const includePaths = config.tracked.paths.length > 0 ? config.tracked.paths : ["force-app"];
    const includePathLiterals = includePaths
        .map((entry) => `'${entry.replace(/'/g, `'\"'\"'`)}'`)
        .join(" ");
    return [
        "",
        "      - name: Setup Java",
        "        uses: actions/setup-java@v5",
        "        with:",
        "          distribution: zulu",
        "          java-version: \"21\"",
        "",
        "      - name: Setup Python",
        "        uses: actions/setup-python@v6",
        "        with:",
        "          python-version: \"3.11\"",
        "",
        "      - name: Install Salesforce Code Analyzer Plugin",
        "        run: sf plugins install code-analyzer@latest --force",
        ...(changedFilesOnly
            ? [
                "",
                "      - name: Build Code Analyzer target scope",
                "        id: analyzer-targets",
                "        shell: bash",
                "        run: |",
                "          set -euo pipefail",
                `          declare -a include_paths=(${includePathLiterals})`,
                "          declare -a targets=()",
                "",
                "          add_target() {",
                "            local candidate=\"$1\"",
                "            [[ -z \"$candidate\" ]] && return 0",
                "            [[ ! -e \"$candidate\" ]] && return 0",
                "",
                "            local allowed=0",
                "            for include_path in \"${include_paths[@]}\"; do",
                "              if [[ \"$candidate\" == \"$include_path\" || \"$candidate\" == \"$include_path\"/* ]]; then",
                "                allowed=1",
                "                break",
                "              fi",
                "            done",
                "            [[ $allowed -eq 0 ]] && return 0",
                "",
                "            candidate=\"${candidate%/}\"",
                "            for existing in \"${targets[@]}\"; do",
                "              [[ \"$existing\" == \"$candidate\" ]] && return 0",
                "            done",
                "            targets+=(\"$candidate\")",
                "          }",
                "",
                "          resolve_target_scope() {",
                "            local path=\"$1\"",
                "",
                "            if [[ \"$path\" =~ /lwc/([^/]+)/ ]]; then",
                "              local bundle=\"${BASH_REMATCH[1]}\"",
                "              add_target \"${path%%/lwc/*}/lwc/${bundle}\"",
                "              return 0",
                "            fi",
                "",
                "            if [[ \"$path\" =~ /aura/([^/]+)/ ]]; then",
                "              local bundle=\"${BASH_REMATCH[1]}\"",
                "              add_target \"${path%%/aura/*}/aura/${bundle}\"",
                "              return 0",
                "            fi",
                "",
                "            add_target \"$path\"",
                "            if [[ \"$path\" == *.cls ]]; then add_target \"${path}-meta.xml\"; fi",
                "            if [[ \"$path\" == *.cls-meta.xml ]]; then add_target \"${path%-meta.xml}\"; fi",
                "            if [[ \"$path\" == *.trigger ]]; then add_target \"${path}-meta.xml\"; fi",
                "            if [[ \"$path\" == *.trigger-meta.xml ]]; then add_target \"${path%-meta.xml}\"; fi",
                "          }",
                "",
                "          declare -a changed_files=()",
                "          if [[ \"${{ github.event_name }}\" == \"pull_request\" ]]; then",
                "            base_sha=\"${{ github.event.pull_request.base.sha }}\"",
                "            head_sha=\"${{ github.event.pull_request.head.sha }}\"",
                "            git fetch --no-tags --prune --depth=1 origin \"$base_sha\" \"$head_sha\" >/dev/null 2>&1 || true",
                "            mapfile -t changed_files < <(git diff --name-only \"$base_sha\" \"$head_sha\" --)",
                "            for changed in \"${changed_files[@]}\"; do",
                "              [[ -z \"$changed\" ]] && continue",
                "              resolve_target_scope \"$changed\"",
                "            done",
                "            if [[ ${#targets[@]} -eq 0 ]]; then",
                "              echo \"skip=true\" >> \"$GITHUB_OUTPUT\"",
                "              echo \"No changed source files matched tracked paths. Skipping Code Analyzer.\"",
                "              exit 0",
                "            fi",
                "          else",
                "            if git rev-parse HEAD~1 >/dev/null 2>&1; then",
                "              mapfile -t changed_files < <(git diff --name-only HEAD~1 HEAD --)",
                "              for changed in \"${changed_files[@]}\"; do",
                "                [[ -z \"$changed\" ]] && continue",
                "                resolve_target_scope \"$changed\"",
                "              done",
                "            fi",
                "            if [[ ${#targets[@]} -eq 0 ]]; then",
                "              for include_path in \"${include_paths[@]}\"; do add_target \"$include_path\"; done",
                "            fi",
                "          fi",
                "",
                "          echo \"skip=false\" >> \"$GITHUB_OUTPUT\"",
                "",
                "          run_args='--workspace . --view detail --output-file sfca_results.json'",
                "          for target in \"${targets[@]}\"; do",
                "            run_args+=\" --target $target\"",
                "          done",
                "",
                "          echo \"count=${#targets[@]}\" >> \"$GITHUB_OUTPUT\"",
                "          {",
                "            echo 'run_args<<EOF'",
                "            echo \"$run_args\"",
                "            echo 'EOF'",
                "          } >> \"$GITHUB_OUTPUT\"",
                "          echo \"Code Analyzer target scope built with ${#targets[@]} path(s).\""
            ]
            : []),
        "",
        "      - name: Run Salesforce Code Analyzer",
        "        id: run-code-analyzer",
        ...(changedFilesOnly
            ? ["        if: ${{ steps.analyzer-targets.outputs.skip != 'true' }}"]
            : []),
        "        uses: forcedotcom/run-code-analyzer@v2",
        "        with:",
        ...(changedFilesOnly
            ? ["          run-arguments: ${{ steps.analyzer-targets.outputs.run_args }}"]
            : ["          run-arguments: --workspace . --view detail --output-file sfca_results.json"]),
        "          results-artifact-name: salesforce-code-analyzer-results",
        ...(includeGitHubToken ? ["          github-token: ${{ github.token }}"] : []),
        "",
        `      - name: Fail on Code Analyzer Severity ${severity}+ (${scopeLabel})`,
        "        if: |",
        ...(changedFilesOnly ? ["          steps.analyzer-targets.outputs.skip != 'true' &&"] : []),
        "          (steps.run-code-analyzer.outputs.exit-code > 0 ||",
        `          steps.run-code-analyzer.outputs.${severityOutput} > 0)`,
        "        run: |",
        `          echo \"Salesforce Code Analyzer found severity ${severity}+ violations in ${scopeLabel}.\"`,
        "          exit 1"
    ];
}
function buildValidateWorkflow(config) {
    const baseBranch = config.repository.baseBranch || "main";
    const testLevel = config.deploy.testLevel;
    const validationScope = config.validation.scope === "full" ? "full" : "changed";
    const specifiedTestsSet = new Set(config.deploy.specifiedTests);
    if (config.tests.enableBasicDataTests && config.basicTests.generatedClassName.trim()) {
        specifiedTestsSet.add(config.basicTests.generatedClassName.trim());
    }
    const specifiedTests = [...specifiedTestsSet].join(",");
    const includePaths = config.tracked.paths.length > 0 ? config.tracked.paths : ["force-app"];
    const sourceDirArgs = includePaths.map((entry) => `--source-dir ${entry}`).join(" ");
    const includePathLiterals = includePaths
        .map((entry) => toShellSingleQuoted(entry))
        .join(" ");
    const specifiedTestsLiteral = specifiedTests.replace(/"/g, '\\"');
    const destructiveIntentLines = buildDestructiveIntentScriptLines(config);
    return [
        "name: Gitforce PR Validate",
        "",
        "on:",
        "  pull_request:",
        "    branches:",
        `      - ${baseBranch}`,
        "  workflow_dispatch:",
        "",
        "permissions:",
        "  contents: read",
        "  actions: read",
        "  pull-requests: write",
        "",
        "jobs:",
        "  validate:",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - name: Checkout",
        "        uses: actions/checkout@v6",
        "",
        "      - name: Setup Node",
        "        uses: actions/setup-node@v6",
        "        with:",
        "          node-version: \"24\"",
        "",
        "      - name: Install dependencies (if package.json exists)",
        "        shell: bash",
        "        run: |",
        "          set -euo pipefail",
        "          if [[ ! -f package.json ]]; then",
        "            echo \"Skipping npm install: package.json not found.\"",
        "            exit 0",
        "          fi",
        "          if [[ -f package-lock.json ]]; then",
        "            npm ci",
        "          else",
        "            echo \"package-lock.json not found. Falling back to npm install.\"",
        "            npm install --no-audit --no-fund",
        "          fi",
        "",
        "      - name: Run unit tests (if present)",
        "        shell: bash",
        "        run: |",
        "          set -euo pipefail",
        "          if [[ ! -f package.json ]]; then",
        "            echo \"Skipping npm tests: package.json not found.\"",
        "            exit 0",
        "          fi",
        "          npm run --if-present test",
        "",
        "      - name: Install Salesforce CLI",
        "        run: npm install --global @salesforce/cli@latest --prefer-offline --no-audit --no-fund",
        ...buildCodeAnalyzerSteps(config, true),
        "",
        "      - name: Validate metadata against Salesforce",
        "        shell: bash",
        "        env:",
        "          GITFORCE_VALIDATE_SF_AUTH_URL: ${{ secrets.GITFORCE_VALIDATE_SF_AUTH_URL }}",
        "        run: |",
        "          set -euo pipefail",
        "          if [[ -z \"${GITFORCE_VALIDATE_SF_AUTH_URL:-}\" ]]; then",
        "            echo \"Skipping Salesforce validation because GITFORCE_VALIDATE_SF_AUTH_URL is not configured.\"",
        "            exit 0",
        "          fi",
        "          AUTH_FILE=\"$RUNNER_TEMP/gitforce-validate-auth.txt\"",
        "          printf \"%s\" \"$GITFORCE_VALIDATE_SF_AUTH_URL\" > \"$AUTH_FILE\"",
        "          sf org login sfdx-url --sfdx-url-file \"$AUTH_FILE\" --alias gitforce-validate --set-default --no-prompt",
        ...(validationScope === "changed"
            ? [
                `          declare -a include_paths=(${includePathLiterals})`,
                "          declare -a validate_sources=()",
                "",
                "          add_source() {",
                "            local candidate=\"$1\"",
                "            [[ -z \"$candidate\" ]] && return 0",
                "            [[ ! -e \"$candidate\" ]] && return 0",
                "",
                "            local allowed=0",
                "            for include_path in \"${include_paths[@]}\"; do",
                "              if [[ \"$candidate\" == \"$include_path\" || \"$candidate\" == \"$include_path\"/* ]]; then",
                "                allowed=1",
                "                break",
                "              fi",
                "            done",
                "            [[ $allowed -eq 0 ]] && return 0",
                "",
                "            candidate=\"${candidate%/}\"",
                "            for existing in \"${validate_sources[@]}\"; do",
                "              [[ \"$existing\" == \"$candidate\" ]] && return 0",
                "            done",
                "            validate_sources+=(\"$candidate\")",
                "          }",
                "",
                "          resolve_source_scope() {",
                "            local path=\"$1\"",
                "",
                "            if [[ \"$path\" =~ /lwc/([^/]+)/ ]]; then",
                "              local bundle=\"${BASH_REMATCH[1]}\"",
                "              add_source \"${path%%/lwc/*}/lwc/${bundle}\"",
                "              return 0",
                "            fi",
                "",
                "            if [[ \"$path\" =~ /aura/([^/]+)/ ]]; then",
                "              local bundle=\"${BASH_REMATCH[1]}\"",
                "              add_source \"${path%%/aura/*}/aura/${bundle}\"",
                "              return 0",
                "            fi",
                "",
                "            add_source \"$path\"",
                "            if [[ \"$path\" == *.cls ]]; then add_source \"${path}-meta.xml\"; fi",
                "            if [[ \"$path\" == *.cls-meta.xml ]]; then add_source \"${path%-meta.xml}\"; fi",
                "            if [[ \"$path\" == *.trigger ]]; then add_source \"${path}-meta.xml\"; fi",
                "            if [[ \"$path\" == *.trigger-meta.xml ]]; then add_source \"${path%-meta.xml}\"; fi",
                "          }",
                "",
                "          declare -a changed_files=()",
                "          if [[ \"${{ github.event_name }}\" == \"pull_request\" ]]; then",
                "            base_sha=\"${{ github.event.pull_request.base.sha }}\"",
                "            head_sha=\"${{ github.event.pull_request.head.sha }}\"",
                "            git fetch --no-tags --prune --depth=1 origin \"$base_sha\" \"$head_sha\" >/dev/null 2>&1 || true",
                "            mapfile -t changed_files < <(git diff --name-only \"$base_sha\" \"$head_sha\" --)",
                "            for changed in \"${changed_files[@]}\"; do",
                "              [[ -z \"$changed\" ]] && continue",
                "              resolve_source_scope \"$changed\"",
                "            done",
                "          else",
                "            if git rev-parse HEAD~1 >/dev/null 2>&1; then",
                "              mapfile -t changed_files < <(git diff --name-only HEAD~1 HEAD --)",
                "              for changed in \"${changed_files[@]}\"; do",
                "                [[ -z \"$changed\" ]] && continue",
                "                resolve_source_scope \"$changed\"",
                "              done",
                "            fi",
                "            if [[ ${#validate_sources[@]} -eq 0 ]]; then",
                "              for include_path in \"${include_paths[@]}\"; do add_source \"$include_path\"; done",
                "            fi",
                "          fi",
                "",
                ...destructiveIntentLines,
                "",
                "          if [[ ${#validate_sources[@]} -eq 0 && ${delete_intent_count:-0} -eq 0 ]]; then",
                "            echo \"No source paths or delete intents available for Salesforce validation. Skipping.\"",
                "            exit 0",
                "          fi",
                "",
                "          if [[ ${#validate_sources[@]} -gt 0 ]]; then",
                "            echo \"Validating changed metadata only:\"",
                "            for source in \"${validate_sources[@]}\"; do echo \"- $source\"; done",
                "",
                `            deploy_args=(project deploy validate --target-org gitforce-validate --test-level ${testLevel})`,
                ...(testLevel === "RunSpecifiedTests" && specifiedTests
                    ? [`            deploy_args+=(--tests "${specifiedTestsLiteral}")`]
                    : []),
                "            for source in \"${validate_sources[@]}\"; do deploy_args+=(--source-dir \"$source\"); done",
                "            sf \"${deploy_args[@]}\"",
                "          else",
                "            echo \"No changed tracked source files matched. Source validation skipped.\"",
                "          fi",
                "",
                "          if [[ ${delete_intent_count:-0} -gt 0 ]]; then",
                "            echo \"Validating destructive delete intent metadata (${delete_intent_count} component(s)).\"",
                `            destructive_args=(project deploy validate --target-org gitforce-validate --manifest "$delete_package_manifest" --post-destructive-changes "$delete_manifest" --ignore-warnings --test-level ${testLevel})`,
                ...(testLevel === "RunSpecifiedTests" && specifiedTests
                    ? [`            destructive_args+=(--tests "${specifiedTestsLiteral}")`]
                    : []),
                "            sf \"${destructive_args[@]}\"",
                "          fi"
            ]
            : [
                "          echo \"Validating full tracked scope:\"",
                ...includePaths.map((entry) => `          echo \"- ${entry}\"`),
                `          sf project deploy validate --target-org gitforce-validate --test-level ${testLevel}${testLevel === "RunSpecifiedTests" && specifiedTests ? ` --tests "${specifiedTestsLiteral}"` : ""} ${sourceDirArgs}`,
                ...destructiveIntentLines,
                "          if [[ ${delete_intent_count:-0} -gt 0 ]]; then",
                "            echo \"Validating destructive delete intent metadata (${delete_intent_count} component(s)).\"",
                `            destructive_args=(project deploy validate --target-org gitforce-validate --manifest "$delete_package_manifest" --post-destructive-changes "$delete_manifest" --ignore-warnings --test-level ${testLevel})`,
                ...(testLevel === "RunSpecifiedTests" && specifiedTests
                    ? [`            destructive_args+=(--tests "${specifiedTestsLiteral}")`]
                    : []),
                "            sf \"${destructive_args[@]}\"",
                "          fi"
            ])
    ].join("\n");
}
function buildPromoteWorkflow(config) {
    const baseBranch = config.repository.baseBranch || "main";
    const testLevel = config.deploy.testLevel;
    const deployMode = config.deploy.mode;
    const autoDeploy = deployMode !== "manual-promote";
    const defaultDispatchEnvironment = deployMode === "auto-integration" ? "integration" : "target";
    const specifiedTestsSet = new Set(config.deploy.specifiedTests);
    if (config.tests.enableBasicDataTests && config.basicTests.generatedClassName.trim()) {
        specifiedTestsSet.add(config.basicTests.generatedClassName.trim());
    }
    const specifiedTests = [...specifiedTestsSet].join(",");
    const includePaths = config.tracked.paths.length > 0 ? config.tracked.paths : ["force-app"];
    const includePathLiterals = includePaths
        .map((entry) => toShellSingleQuoted(entry))
        .join(" ");
    const specifiedTestsLiteral = specifiedTests.replace(/"/g, '\\"');
    const destructiveIntentLines = buildDestructiveIntentScriptLines(config);
    const triggerLines = [
        "on:",
        ...(autoDeploy
            ? [
                "  push:",
                "    branches:",
                `      - ${baseBranch}`
            ]
            : []),
        "  workflow_dispatch:",
        "    inputs:",
        "      environment:",
        "        description: Target environment",
        "        type: choice",
        "        required: true",
        `        default: ${defaultDispatchEnvironment}`,
        "        options:",
        "          - integration",
        "          - target"
    ];
    const orchestrationLines = config.orchestration.enabled
        ? [
            "concurrency:",
            "  group: gitforce-promote-${{ github.ref_name }}",
            "  cancel-in-progress: false",
            ""
        ]
        : [];
    return [
        "name: Gitforce Promote",
        "",
        ...triggerLines,
        "",
        ...orchestrationLines,
        "permissions:",
        "  contents: read",
        "  actions: read",
        "",
        "jobs:",
        "  promote:",
        "    if: github.ref_name == '" + baseBranch + "' || github.event_name == 'workflow_dispatch'",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - name: Checkout",
        "        uses: actions/checkout@v6",
        "",
        "      - name: Install Salesforce CLI",
        "        run: npm install --global @salesforce/cli@latest --prefer-offline --no-audit --no-fund",
        ...buildCodeAnalyzerSteps(config, false),
        "",
        "      - name: Resolve auth secret",
        "        id: auth",
        "        shell: bash",
        "        run: |",
        "          set -euo pipefail",
        `          mode="${deployMode}"`,
        "          if [[ \"${{ github.event_name }}\" == \"workflow_dispatch\" ]]; then",
        "            if [[ \"${{ inputs.environment }}\" == \"integration\" ]]; then",
        "              echo \"value=${{ secrets.GITFORCE_INTEGRATION_SF_AUTH_URL }}\" >> \"$GITHUB_OUTPUT\"",
        "            else",
        "              echo \"value=${{ secrets.GITFORCE_TARGET_SF_AUTH_URL }}\" >> \"$GITHUB_OUTPUT\"",
        "            fi",
        "          elif [[ \"$mode\" == \"auto-integration\" ]]; then",
        "            echo \"value=${{ secrets.GITFORCE_INTEGRATION_SF_AUTH_URL }}\" >> \"$GITHUB_OUTPUT\"",
        "          else",
        "            echo \"value=${{ secrets.GITFORCE_TARGET_SF_AUTH_URL }}\" >> \"$GITHUB_OUTPUT\"",
        "          fi",
        "",
        "      - name: Require auth secret",
        "        if: ${{ steps.auth.outputs.value == '' }}",
        "        run: |",
        "          echo \"Missing Salesforce auth secret for promote workflow.\"",
        "          echo \"Set GITFORCE_TARGET_SF_AUTH_URL and/or GITFORCE_INTEGRATION_SF_AUTH_URL in repository secrets.\"",
        "          exit 1",
        "",
        "      - name: Deploy to Salesforce",
        "        id: deploy",
        "        shell: bash",
        "        run: |",
        "          set -euo pipefail",
        "          echo \"skipped=false\" >> \"$GITHUB_OUTPUT\"",
        "          echo \"source_count=0\" >> \"$GITHUB_OUTPUT\"",
        "          AUTH_FILE=\"$RUNNER_TEMP/gitforce-promote-auth.txt\"",
        "          printf \"%s\" \"${{ steps.auth.outputs.value }}\" > \"$AUTH_FILE\"",
        "          sf org login sfdx-url --sfdx-url-file \"$AUTH_FILE\" --alias gitforce-promote --set-default --no-prompt",
        `          declare -a include_paths=(${includePathLiterals})`,
        "          declare -a deploy_sources=()",
        "",
        "          add_source() {",
        "            local candidate=\"$1\"",
        "            [[ -z \"$candidate\" ]] && return 0",
        "            [[ ! -e \"$candidate\" ]] && return 0",
        "",
        "            local allowed=0",
        "            for include_path in \"${include_paths[@]}\"; do",
        "              if [[ \"$candidate\" == \"$include_path\" || \"$candidate\" == \"$include_path\"/* ]]; then",
        "                allowed=1",
        "                break",
        "              fi",
        "            done",
        "            [[ $allowed -eq 0 ]] && return 0",
        "",
        "            candidate=\"${candidate%/}\"",
        "            for existing in \"${deploy_sources[@]}\"; do",
        "              [[ \"$existing\" == \"$candidate\" ]] && return 0",
        "            done",
        "            deploy_sources+=(\"$candidate\")",
        "          }",
        "",
        "          resolve_source_scope() {",
        "            local path=\"$1\"",
        "",
        "            if [[ \"$path\" =~ /lwc/([^/]+)/ ]]; then",
        "              local bundle=\"${BASH_REMATCH[1]}\"",
        "              add_source \"${path%%/lwc/*}/lwc/${bundle}\"",
        "              return 0",
        "            fi",
        "",
        "            if [[ \"$path\" =~ /aura/([^/]+)/ ]]; then",
        "              local bundle=\"${BASH_REMATCH[1]}\"",
        "              add_source \"${path%%/aura/*}/aura/${bundle}\"",
        "              return 0",
        "            fi",
        "",
        "            add_source \"$path\"",
        "            if [[ \"$path\" == *.cls ]]; then add_source \"${path}-meta.xml\"; fi",
        "            if [[ \"$path\" == *.trigger ]]; then add_source \"${path}-meta.xml\"; fi",
        "          }",
        "",
        "          diff_base=\"\"",
        "          if [[ \"${{ github.event_name }}\" == \"push\" && \"${{ github.event.before }}\" != \"0000000000000000000000000000000000000000\" ]]; then",
        "            diff_base=\"${{ github.event.before }}\"",
        "          elif git rev-parse HEAD~1 >/dev/null 2>&1; then",
        "            diff_base=\"$(git rev-parse HEAD~1)\"",
        "          fi",
        "",
        "          if [[ -n \"$diff_base\" ]]; then",
        "            mapfile -t changed_files < <(git diff --name-only \"$diff_base\" \"${{ github.sha }}\" --)",
        "          else",
        "            changed_files=()",
        "          fi",
        "",
        "          if [[ ${#changed_files[@]} -eq 0 ]]; then",
        "            echo \"No diff scope available; falling back to configured source paths.\"",
        "            for include_path in \"${include_paths[@]}\"; do add_source \"$include_path\"; done",
        "          else",
        "            for changed in \"${changed_files[@]}\"; do",
        "              [[ -z \"$changed\" ]] && continue",
        "              resolve_source_scope \"$changed\"",
        "            done",
        "          fi",
        "",
        ...destructiveIntentLines,
        "",
        "          if [[ ${#deploy_sources[@]} -eq 0 && ${delete_intent_count:-0} -eq 0 ]]; then",
        "            echo \"No changed source files or delete intents matched tracked scope. Skipping deploy.\"",
        "            echo \"skipped=true\" >> \"$GITHUB_OUTPUT\"",
        "            exit 0",
        "          fi",
        "",
        "          if [[ ${#deploy_sources[@]} -gt 0 ]]; then",
        "            echo \"Deploying changed metadata only:\"",
        "            for source in \"${deploy_sources[@]}\"; do echo \"- $source\"; done",
        "            echo \"source_count=${#deploy_sources[@]}\" >> \"$GITHUB_OUTPUT\"",
        "            {",
        "              echo 'source_list<<EOF'",
        "              for source in \"${deploy_sources[@]}\"; do echo \"$source\"; done",
        "              echo 'EOF'",
        "            } >> \"$GITHUB_OUTPUT\"",
        "",
        `            deploy_args=(project deploy start --target-org gitforce-promote --test-level ${testLevel})`,
        ...(testLevel === "RunSpecifiedTests" && specifiedTests
            ? [`            deploy_args+=(--tests "${specifiedTestsLiteral}")`]
            : []),
        "            for source in \"${deploy_sources[@]}\"; do deploy_args+=(--source-dir \"$source\"); done",
        "            sf \"${deploy_args[@]}\"",
        "          else",
        "            echo \"No changed tracked source files matched. Source deploy skipped.\"",
        "          fi",
        "",
        "          if [[ ${delete_intent_count:-0} -gt 0 ]]; then",
        "            echo \"Deploying destructive delete intent metadata (${delete_intent_count} component(s)).\"",
        `            destructive_args=(project deploy start --target-org gitforce-promote --manifest "$delete_package_manifest" --post-destructive-changes "$delete_manifest" --purge-on-delete --ignore-warnings --test-level ${testLevel})`,
        ...(testLevel === "RunSpecifiedTests" && specifiedTests
            ? [`            destructive_args+=(--tests "${specifiedTestsLiteral}")`]
            : []),
        "            sf \"${destructive_args[@]}\"",
        "          fi",
        "",
        "      - name: Publish Salesforce promote summary",
        "        if: ${{ always() }}",
        "        shell: bash",
        "        run: |",
        "          set -euo pipefail",
        "          echo \"## Gitforce Salesforce Promote\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Workflow result: ${{ steps.deploy.outcome }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Trigger: ${{ github.event_name }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Branch: ${{ github.ref_name }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Metadata paths selected: ${{ steps.deploy.outputs.source_count }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Destructive delete intents selected: ${{ steps.deploy.outputs.delete_count }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          echo \"- Run: https://github.com/${{ github.repository }}/actions/runs/${{ github.run_id }}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "          if [[ \"${{ steps.deploy.outputs.skipped }}\" == \"true\" ]]; then",
        "            echo \"- Salesforce deploy: skipped (no changed tracked metadata)\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            exit 0",
        "          fi",
        "          if [[ -n \"${{ steps.deploy.outputs.source_list }}\" ]]; then",
        "            echo \"\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            echo \"### Deployed Paths\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            while IFS= read -r line; do",
        "              [[ -z \"$line\" ]] && continue",
        "              echo \"- $line\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            done <<< \"${{ steps.deploy.outputs.source_list }}\"",
        "          fi",
        "          if [[ -n \"${{ steps.deploy.outputs.delete_components }}\" ]]; then",
        "            echo \"\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            echo \"### Destructive Components\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            while IFS= read -r entry; do",
        "              [[ -z \"$entry\" ]] && continue",
        "              component_type=\"${entry%%::*}\"",
        "              component_name=\"${entry#*::}\"",
        "              echo \"- ${component_type}: ${component_name}\" >> \"$GITHUB_STEP_SUMMARY\"",
        "            done <<< \"${{ steps.deploy.outputs.delete_components }}\"",
        "          fi"
    ].join("\n");
}
function buildDriftWorkflow(config) {
    const cron = config.drift.cron || (0, repoSyncConfig_1.buildCronExpression)(config.drift.intervalMinutes);
    const triggerLines = config.drift.enabled
        ? [
            "on:",
            "  schedule:",
            `    - cron: \"${cron}\"`,
            "  workflow_dispatch:"
        ]
        : ["on:", "  workflow_dispatch:"];
    const orchestrationLines = config.orchestration.enabled
        ? [
            "concurrency:",
            "  group: gitforce-drift-${{ github.ref_name }}",
            "  cancel-in-progress: false",
            ""
        ]
        : [];
    return [
        "name: Gitforce Drift Detect",
        "",
        ...triggerLines,
        "",
        ...orchestrationLines,
        "permissions:",
        "  contents: write",
        "  pull-requests: write",
        "",
        "jobs:",
        "  drift:",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - name: Checkout",
        "        uses: actions/checkout@v6",
        "        with:",
        "          fetch-depth: 0",
        "",
        "      - name: Setup Node",
        "        uses: actions/setup-node@v6",
        "        with:",
        "          node-version: \"24\"",
        "",
        "      - name: Install Salesforce CLI",
        "        run: npm install --global @salesforce/cli@latest --prefer-offline --no-audit --no-fund",
        "",
        "      - name: Run drift detection",
        "        env:",
        "          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}",
        "          GITFORCE_BOT_TOKEN: ${{ secrets.GITFORCE_BOT_TOKEN }}",
        "          GITFORCE_SF_AUTH_URL: ${{ secrets.GITFORCE_SF_AUTH_URL }}",
        "        run: node .gitforce/drift.mjs"
    ].join("\n");
}
function buildDriftScript() {
    return (0, gitforceDriftScriptTemplate_1.buildDriftScriptTemplate)();
}
function buildOpsReadme(config) {
    const owner = config.repository.owner || "<owner>";
    const repo = config.repository.repo || "<repo>";
    const baseBranch = encodeURIComponent(config.repository.baseBranch || "main");
    const promoteBadge = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-promote.yml/badge.svg?branch=${baseBranch}`;
    const validateBadge = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-pr-validate.yml/badge.svg?branch=${baseBranch}`;
    const driftBadge = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-drift-detect.yml/badge.svg?branch=${baseBranch}`;
    const promoteWorkflow = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-promote.yml`;
    const validateWorkflow = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-pr-validate.yml`;
    const driftWorkflow = `https://github.com/${owner}/${repo}/actions/workflows/gitforce-drift-detect.yml`;
    return [
        "# Gitforce 2.0 Operations",
        "",
        "Generated by Gitforce core workflow generator.",
        "",
        "## Live Status",
        `- [![Gitforce Promote](${promoteBadge})](${promoteWorkflow})`,
        `- [![Gitforce PR Validate](${validateBadge})](${validateWorkflow})`,
        `- [![Gitforce Drift Detect](${driftBadge})](${driftWorkflow})`,
        "",
        "## Required GitHub Secrets",
        "- `GITFORCE_SF_AUTH_URL`: target org auth URL for drift detection.",
        "- `GITFORCE_BOT_TOKEN`: optional PAT/GitHub App token used by drift PR creation (recommended so PR validation triggers).",
        "- `GITFORCE_VALIDATE_SF_AUTH_URL`: optional validation org auth URL for PR validation.",
        "- `GITFORCE_TARGET_SF_AUTH_URL`: target org auth URL for promote workflow.",
        "- `GITFORCE_INTEGRATION_SF_AUTH_URL`: optional integration org auth URL for promote workflow.",
        "",
        "## Current Defaults",
        `- Base branch: ${config.repository.baseBranch || "main"}`,
        `- Drift mode: ${config.drift.mode}`,
        `- Drift schedule: ${config.drift.intervalMinutes} minute(s)`,
        `- Destructive delete intent mode: ${config.destructiveChanges.enabled ? "enabled" : "disabled"}`,
        `- Destructive delete intent path: ${config.destructiveChanges.intentPath}`,
        `- Deploy mode: ${config.deploy.mode}`,
        `- Test level: ${config.deploy.testLevel}`,
        `- PR auto-merge on checks pass: ${config.merge.autoMergeOnChecksPass ? "enabled" : "disabled"}`,
        `- Validation scope: ${config.validation.scope}`,
        `- Code Analyzer scope: ${config.codeAnalyzer.scope}`,
        `- Auto branch: ${config.branchPolicy.autoBranch ? "enabled" : "disabled"}`,
        `- Auto branch prefix: ${config.branchPolicy.autoBranchPrefix}`,
        `- Block direct pushes to base: ${config.branchPolicy.disallowDirectPushToBase ? "enabled" : "disabled"}`,
        `- Repository hardening: ${config.governance.hardenRepository ? "enabled" : "disabled"}`,
        `- Required approvals: ${config.governance.requiredApprovingReviewCount}`,
        `- Code owner reviews: ${config.governance.requireCodeOwnerReviews ? "enabled" : "disabled"}`,
        `- Code Analyzer: ${config.codeAnalyzer.enabled ? "enabled" : "disabled"}`,
        `- Code Analyzer severity gate: ${config.codeAnalyzer.failOnSeverity}+`,
        `- Code Analyzer target style: ${config.codeAnalyzer.scope === "changed" ? "changed deploy files only" : "entire workspace"}`,
        `- Change intelligence: ${config.changeIntelligence.enabled ? "enabled" : "disabled"} (${config.changeIntelligence.riskThreshold}+)`,
        `- Promotion lanes: development=${config.promotion.lanes.development.branch}, sandbox=${config.promotion.lanes.sandbox.branch}, production=${config.promotion.lanes.production.branch}`,
        `- Policy default profile: ${config.policyProfiles.defaultProfile}`,
        `- Orchestration: ${config.orchestration.enabled ? "enabled" : "disabled"} (maxConcurrentPerLane=${config.orchestration.maxConcurrentPerLane})`
    ].join("\n");
}
function buildGitforceCoreArtifacts(config) {
    return [
        {
            relativePath: ".github/workflows/gitforce-pr-validate.yml",
            content: buildValidateWorkflow(config)
        },
        {
            relativePath: ".github/workflows/gitforce-promote.yml",
            content: buildPromoteWorkflow(config)
        },
        {
            relativePath: ".github/workflows/gitforce-drift-detect.yml",
            content: buildDriftWorkflow(config)
        },
        {
            relativePath: ".gitforce/drift.mjs",
            content: buildDriftScript()
        },
        {
            relativePath: ".gitforce/README-ops.md",
            content: buildOpsReadme(config)
        }
    ];
}
async function writeGitforceCoreArtifacts(workspacePath, config) {
    const artifacts = buildGitforceCoreArtifacts(config);
    for (const artifact of artifacts) {
        const absolutePath = path.join(workspacePath, artifact.relativePath);
        await fs_1.promises.mkdir(path.dirname(absolutePath), { recursive: true });
        await fs_1.promises.writeFile(absolutePath, `${artifact.content}\n`, "utf8");
    }
    return artifacts;
}
//# sourceMappingURL=gitforceCoreWorkflows.js.map

/***/ }),

/***/ 11:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buildDriftScriptTemplate = buildDriftScriptTemplate;
function buildDriftScriptTemplate() {
    const lines = [
        "#!/usr/bin/env node",
        "import { promises as fs } from 'node:fs';",
        "import * as os from 'node:os';",
        "import * as path from 'node:path';",
        "import { execFileSync } from 'node:child_process';",
        "",
        "const CONFIG_PATH = path.join(process.cwd(), 'gitforce-project.json');",
        "const MAX_PR_BODY_LENGTH = 65000;",
        "const MAX_SUMMARY_ROWS = 200;",
        "const MAX_FILE_ROWS = 300;",
        "const MAX_AUDIT_ROWS = 300;",
        "const MAX_USER_ROWS = 120;",
        "const MAX_COMPONENTS_PER_USER = 10;",
        "",
        "function runCommand(command, args, cwd = process.cwd()) {",
        "  try {",
        "    const output = execFileSync(command, args, {",
        "      cwd,",
        "      encoding: 'utf8',",
        "      stdio: ['ignore', 'pipe', 'pipe'],",
        "      env: process.env,",
        "      maxBuffer: 100 * 1024 * 1024",
        "    });",
        "    return output.replace(/\\s+$/, '');",
        "  } catch (error) {",
        "    const stderr = error?.stderr?.toString?.() ?? '';",
        "    const stdout = error?.stdout?.toString?.() ?? '';",
        "    const message = stderr || stdout || error.message;",
        "    throw new Error('Command failed: ' + command + ' ' + args.join(' ') + '\\n' + message);",
        "  }",
        "}",
        "",
        "function parseJsonOutput(raw) {",
        "  try { return JSON.parse(raw); } catch { return {}; }",
        "}",
        "",
        "async function appendStepSummary(lines) {",
        "  const summaryPath = process.env.GITHUB_STEP_SUMMARY;",
        "  if (!summaryPath) return;",
        "  const content = lines.join('\\n') + '\\n';",
        "  await fs.appendFile(summaryPath, content, 'utf8');",
        "}",
        "",
        "function parseChangedFilesFromPorcelain(porcelain) {",
        "  return porcelain",
        "    .split(/\\r?\\n/)",
        "    .map((line) => line.trimEnd())",
        "    .filter(Boolean)",
        "    .map((line) => {",
        "      const statusMatch = line.match(/^(?:[ MADRCU?!]{1,2})\\s+(.*)$/);",
        "      const candidate = (statusMatch ? statusMatch[1] : line).trim();",
        "      if (candidate.includes(' -> ')) {",
        "        const parts = candidate.split(' -> ');",
        "        return parts[1].trim();",
        "      }",
        "      return candidate;",
        "    })",
        "    .filter(Boolean);",
        "}",
        "",
        "function classifyComponent(filePath) {",
        "  const normalized = filePath.replace(/\\\\/g, '/');",
        "  let match = normalized.match(/\\/classes\\/([^/]+)\\.cls(?:-meta\\.xml)?$/i);",
        "  if (match) return { metadataType: 'ApexClass', componentName: match[1] };",
        "  match = normalized.match(/\\/triggers\\/([^/]+)\\.trigger(?:-meta\\.xml)?$/i);",
        "  if (match) return { metadataType: 'ApexTrigger', componentName: match[1] };",
        "  match = normalized.match(/\\/lwc\\/([^/]+)\\//i);",
        "  if (match) return { metadataType: 'LightningComponentBundle', componentName: match[1] };",
        "  match = normalized.match(/\\/aura\\/([^/]+)\\//i);",
        "  if (match) return { metadataType: 'AuraDefinitionBundle', componentName: match[1] };",
        "  match = normalized.match(/\\/objects\\/([^/]+)\\/fields\\/([^/]+)\\.field-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'CustomField', componentName: match[1] + '.' + match[2] };",
        "  match = normalized.match(/\\/objects\\/([^/]+)\\/[^/]+\\.object-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'CustomObject', componentName: match[1] };",
        "  match = normalized.match(/\\/layouts\\/([^/]+)\\.layout-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Layout', componentName: match[1] };",
        "  match = normalized.match(/\\/permissionSets\\/([^/]+)\\.permissionset-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'PermissionSet', componentName: match[1] };",
        "  match = normalized.match(/\\/profiles\\/([^/]+)\\.profile-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Profile', componentName: match[1] };",
        "  match = normalized.match(/\\/flows\\/([^/]+)\\.flow-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Flow', componentName: match[1] };",
        "  const fallback = normalized.split('/').pop() ?? normalized;",
        "  return { metadataType: 'Unknown', componentName: fallback };",
        "}",
        "",
        "function chunk(items, size) {",
        "  const chunks = [];",
        "  for (let index = 0; index < items.length; index += size) chunks.push(items.slice(index, index + size));",
        "  return chunks;",
        "}",
        "",
        "function stageFilesForCommit(filePaths) {",
        "  for (const fileChunk of chunk(filePaths, 100)) {",
        "    runCommand('git', ['add', '-A', '--', ...fileChunk]);",
        "  }",
        "}",
        "",
        "async function githubRequest(token, method, apiPath, body) {",
        "  const response = await fetch('https://api.github.com' + apiPath, {",
        "    method,",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28',",
        "      'Content-Type': 'application/json'",
        "    },",
        "    body: body ? JSON.stringify(body) : undefined",
        "  });",
        "  if (response.status === 204) return null;",
        "  if (!response.ok) {",
        "    const errorText = await response.text();",
        "    throw new Error('GitHub API ' + method + ' ' + apiPath + ' failed (' + response.status + '): ' + errorText);",
        "  }",
        "  return response.json();",
        "}",
        "",
        "async function githubGraphql(token, query, variables) {",
        "  const response = await fetch('https://api.github.com/graphql', {",
        "    method: 'POST',",
        "    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },",
        "    body: JSON.stringify({ query, variables })",
        "  });",
        "  const json = await response.json();",
        "  if (!response.ok || json.errors) throw new Error('GitHub GraphQL failed: ' + JSON.stringify(json.errors ?? json));",
        "  return json.data;",
        "}",
        "",
        "function normalizeUserMappings(mappings) {",
        "  const map = new Map();",
        "  for (const entry of mappings ?? []) {",
        "    if (!entry || typeof entry !== 'object') continue;",
        "    const sf = String(entry.salesforceUsername ?? '').trim().toLowerCase();",
        "    const gh = String(entry.githubUsername ?? '').trim();",
        "    if (sf && gh) map.set(sf, gh);",
        "  }",
        "  return map;",
        "}",
        "",
        "function listMetadataForType(orgAlias, metadataType) {",
        "  try {",
        "    const output = runCommand('sf', ['org', 'list', 'metadata', '--target-org', orgAlias, '--metadata-type', metadataType, '--json']);",
        "    const parsed = parseJsonOutput(output);",
        "    return Array.isArray(parsed.result) ? parsed.result : [];",
        "  } catch {",
        "    return [];",
        "  }",
        "}",
        "",
        "function buildMetadataIndex(orgAlias, metadataTypes) {",
        "  const byType = new Map();",
        "  for (const metadataType of metadataTypes) {",
        "    const rows = listMetadataForType(orgAlias, metadataType);",
        "    const byFullName = new Map();",
        "    const byFileName = new Map();",
        "    for (const row of rows) {",
        "      const fullName = String(row.fullName ?? '').trim();",
        "      const fileName = String(row.fileName ?? '').trim();",
        "      if (fullName) byFullName.set(fullName, row);",
        "      if (fileName) byFileName.set(fileName, row);",
        "    }",
        "    byType.set(metadataType, { byFullName, byFileName });",
        "  }",
        "  return byType;",
        "}",
        "",
        "function getTrackedFiles(includePaths) {",
        "  if (!Array.isArray(includePaths) || includePaths.length === 0) return [];",
        "  try {",
        "    const output = runCommand('git', ['ls-files', '--', ...includePaths]);",
        "    return output.split(/\\r?\\n/).map((line) => line.trim()).filter(Boolean);",
        "  } catch {",
        "    return [];",
        "  }",
        "}",
        "",
        "function normalizeRepoPath(filePath) {",
        "  return String(filePath || '').replace(/\\\\/g, '/').replace(/^\\.\\//, '').trim();",
        "}",
        "",
        "function isPathInTrackedScope(filePath, includePaths) {",
        "  const normalized = normalizeRepoPath(filePath);",
        "  if (!normalized) return false;",
        "  if (!Array.isArray(includePaths) || includePaths.length === 0) return true;",
        "  return includePaths.some((includePath) => {",
        "    const normalizedIncludePath = normalizeRepoPath(includePath).replace(/\\/+$/, '');",
        "    if (!normalizedIncludePath) return false;",
        "    return normalized === normalizedIncludePath || normalized.startsWith(normalizedIncludePath + '/');",
        "  });",
        "}",
        "",
        "function buildPendingDeleteIntentSourceSet(intentPath) {",
        "  const sourceSet = new Set();",
        "  if (!intentPath || typeof intentPath !== 'string') return sourceSet;",
        "  const normalizedIntentPath = normalizeRepoPath(intentPath).replace(/\\/+$/, '');",
        "  if (!normalizedIntentPath) return sourceSet;",
        "  try {",
        "    const output = runCommand('git', ['ls-files', '--', normalizedIntentPath]);",
        "    const intentFiles = output.split(/\\r?\\n/).map((line) => line.trim()).filter(Boolean);",
        "    for (const intentFile of intentFiles) {",
        "      const normalizedIntentFile = normalizeRepoPath(intentFile);",
        "      if (!normalizedIntentFile.startsWith(normalizedIntentPath + '/')) continue;",
        "      const sourcePath = normalizedIntentFile.slice(normalizedIntentPath.length + 1);",
        "      if (sourcePath) sourceSet.add(sourcePath);",
        "    }",
        "  } catch {",
        "    // ignore if intent path is missing",
        "  }",
        "  return sourceSet;",
        "}",
        "",
        "function filterTrackedChangedFiles(changedFiles, includePaths, includeTypes, pendingDeleteSourceSet) {",
        "  const trackedTypeSet = new Set((includeTypes || []).map((entry) => String(entry).trim()).filter(Boolean));",
        "  const filtered = [];",
        "  const skippedByIntent = [];",
        "  for (const filePath of changedFiles) {",
        "    const normalizedPath = normalizeRepoPath(filePath);",
        "    if (!normalizedPath) continue;",
        "    if (pendingDeleteSourceSet.has(normalizedPath)) {",
        "      skippedByIntent.push(normalizedPath);",
        "      continue;",
        "    }",
        "    if (!isPathInTrackedScope(normalizedPath, includePaths)) continue;",
        "    if (trackedTypeSet.size > 0) {",
        "      const component = classifyComponent(normalizedPath);",
        "      if (component.metadataType === 'Unknown') continue;",
        "      if (!trackedTypeSet.has(component.metadataType)) continue;",
        "    }",
        "    filtered.push(normalizedPath);",
        "  }",
        "  return { filtered, skippedByIntent };",
        "}",
        "",
        "function metadataExistsInOrg(metadataIndex, metadataType, componentName, filePath) {",
        "  const bucket = metadataIndex.get(metadataType);",
        "  if (!bucket) return true;",
        "  if (bucket.byFullName.has(componentName)) return true;",
        "  const normalizedPath = filePath.replace(/\\\\/g, '/');",
        "  for (const fileName of bucket.byFileName.keys()) {",
        "    if (normalizedPath.endsWith(fileName)) return true;",
        "  }",
        "  return false;",
        "}",
        "",
        "function deriveDeletionTarget(filePath, metadataType) {",
        "  const normalized = filePath.replace(/\\\\/g, '/');",
        "  if (metadataType === 'LightningComponentBundle') {",
        "    const match = normalized.match(/^(.*\\/lwc\\/[^/]+)\\//i);",
        "    if (match) return match[1];",
        "  }",
        "  if (metadataType === 'AuraDefinitionBundle') {",
        "    const match = normalized.match(/^(.*\\/aura\\/[^/]+)\\//i);",
        "    if (match) return match[1];",
        "  }",
        "  if (metadataType === 'CustomObject') {",
        "    const match = normalized.match(/^(.*\\/objects\\/[^/]+)\\//i);",
        "    if (match) return match[1];",
        "  }",
        "  return filePath;",
        "}",
        "",
        "function detectOrgDeletedLocalTargets(includePaths, includeTypes, metadataIndex) {",
        "  const trackedTypeSet = new Set(includeTypes.map((entry) => String(entry).trim()).filter(Boolean));",
        "  if (trackedTypeSet.size === 0) return [];",
        "",
        "  const trackedFiles = getTrackedFiles(includePaths);",
        "  const deletionTargets = new Set();",
        "",
        "  for (const filePath of trackedFiles) {",
        "    const component = classifyComponent(filePath);",
        "    if (component.metadataType === 'Unknown') continue;",
        "    if (!trackedTypeSet.has(component.metadataType)) continue;",
        "",
        "    const existsInOrg = metadataExistsInOrg(",
        "      metadataIndex,",
        "      component.metadataType,",
        "      component.componentName,",
        "      filePath",
        "    );",
        "    if (existsInOrg) continue;",
        "",
        "    deletionTargets.add(deriveDeletionTarget(filePath, component.metadataType));",
        "  }",
        "",
        "  return [...deletionTargets];",
        "}",
        "",
        "function matchMetadataRow(metadataIndex, metadataType, componentName, filePath) {",
        "  const bucket = metadataIndex.get(metadataType);",
        "  if (!bucket) return undefined;",
        "  if (bucket.byFullName.has(componentName)) return bucket.byFullName.get(componentName);",
        "  const normalizedPath = filePath.replace(/\\\\/g, '/');",
        "  for (const [fileName, row] of bucket.byFileName.entries()) {",
        "    if (normalizedPath.endsWith(fileName)) return row;",
        "  }",
        "  return undefined;",
        "}",
        "",
        "function fetchUsernamesById(orgAlias, userIds) {",
        "  const results = new Map();",
        "  for (const idChunk of chunk(userIds, 100)) {",
        "    const query = 'SELECT Id, Username FROM User WHERE Id IN (' + idChunk.map((id) => \"'\" + id + \"'\").join(',') + ')';",
        "    try {",
        "      const output = runCommand('sf', ['data', 'query', '--target-org', orgAlias, '--query', query, '--result-format', 'json']);",
        "      const parsed = parseJsonOutput(output);",
        "      const records = parsed?.result?.records;",
        "      if (!Array.isArray(records)) continue;",
        "      for (const record of records) {",
        "        const id = String(record.Id ?? '').trim();",
        "        const username = String(record.Username ?? '').trim();",
        "        if (id && username) results.set(id, username);",
        "      }",
        "    } catch {",
        "      // ignore per-chunk failures",
        "    }",
        "  }",
        "  return results;",
        "}",
        "",
        "async function isRepoCollaborator(token, owner, repo, username, cache) {",
        "  const key = username.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  const response = await fetch('https://api.github.com/repos/' + owner + '/' + repo + '/collaborators/' + username, {",
        "    method: 'GET',",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28'",
        "    }",
        "  });",
        "  const isCollaborator = response.status === 204;",
        "  cache.set(key, isCollaborator);",
        "  return isCollaborator;",
        "}",
        "",
        "async function getGitHubOwnerType(token, owner, cache) {",
        "  const key = owner.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  try {",
        "    const ownerData = await githubRequest(token, 'GET', '/users/' + owner);",
        "    const ownerType = String(ownerData?.type ?? '').trim().toLowerCase();",
        "    cache.set(key, ownerType);",
        "    return ownerType;",
        "  } catch {",
        "    cache.set(key, '');",
        "    return '';",
        "  }",
        "}",
        "",
        "async function isOrganizationMember(token, org, username, cache) {",
        "  const key = org.toLowerCase() + '::' + username.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  const response = await fetch('https://api.github.com/orgs/' + org + '/members/' + username, {",
        "    method: 'GET',",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28'",
        "    }",
        "  });",
        "  if (response.status === 204) {",
        "    cache.set(key, true);",
        "    return true;",
        "  }",
        "  if (response.status === 404) {",
        "    cache.set(key, false);",
        "    return false;",
        "  }",
        "  cache.set(key, null);",
        "  return null;",
        "}",
        "",
        "async function buildSummaryRows(config, orgAlias, changedFiles, token) {",
        "  const components = changedFiles.map((filePath) => ({ filePath, ...classifyComponent(filePath) }));",
        "  const metadataTypes = [...new Set(components.map((entry) => entry.metadataType).filter((type) => type !== 'Unknown'))];",
        "  const metadataIndex = buildMetadataIndex(orgAlias, metadataTypes);",
        "  const rows = components.map((component) => ({",
        "    ...component,",
        "    metadataRow: matchMetadataRow(metadataIndex, component.metadataType, component.componentName, component.filePath)",
        "  }));",
        "  const userIds = [...new Set(rows.map((row) => String(row.metadataRow?.lastModifiedById ?? '').trim()).filter(Boolean))];",
        "  const usernamesById = fetchUsernamesById(orgAlias, userIds);",
        "  const userMapping = normalizeUserMappings(config.users);",
        "  const collaboratorCache = new Map();",
        "  const ownerTypeCache = new Map();",
        "  const orgMembershipCache = new Map();",
        "  const ownerType = await getGitHubOwnerType(token, config.repository.owner, ownerTypeCache);",
        "  const ownerIsOrganization = ownerType === 'organization';",
        "",
        "  for (const row of rows) {",
        "    const modifiedById = String(row.metadataRow?.lastModifiedById ?? '').trim();",
        "    const sfUsername = modifiedById ? usernamesById.get(modifiedById) : undefined;",
        "    row.lastModifiedDate = String(row.metadataRow?.lastModifiedDate ?? '').trim();",
        "    if (!sfUsername) {",
        "      row.displayUser = String(row.metadataRow?.lastModifiedByName ?? 'Unknown').trim() || 'Unknown';",
        "      continue;",
        "    }",
        "    const mappedGitHubUser = userMapping.get(sfUsername.toLowerCase());",
        "    if (!mappedGitHubUser) {",
        "      row.displayUser = sfUsername;",
        "      continue;",
        "    }",
        "",
        "    let mentionAllowed = false;",
        "    let mentionReason = '';",
        "",
        "    if (ownerIsOrganization) {",
        "      const memberStatus = await isOrganizationMember(token, config.repository.owner, mappedGitHubUser, orgMembershipCache);",
        "      if (memberStatus === true) {",
        "        mentionAllowed = true;",
        "      } else if (memberStatus === false) {",
        "        mentionReason = 'not a member of GitHub org ' + config.repository.owner;",
        "      } else {",
        "        const collaborator = await isRepoCollaborator(token, config.repository.owner, config.repository.repo, mappedGitHubUser, collaboratorCache);",
        "        mentionAllowed = collaborator;",
        "        mentionReason = collaborator ? '' : 'org membership unavailable and user is not a repo collaborator';",
        "      }",
        "    } else {",
        "      const collaborator = await isRepoCollaborator(token, config.repository.owner, config.repository.repo, mappedGitHubUser, collaboratorCache);",
        "      mentionAllowed = collaborator;",
        "      mentionReason = collaborator ? '' : 'not a repo collaborator';",
        "    }",
        "",
        "    row.displayUser = mentionAllowed",
        "      ? '@' + mappedGitHubUser",
        "      : sfUsername + ' (mapped to ' + mappedGitHubUser + ', ' + mentionReason + ')';",
        "  }",
        "",
        "  return rows;",
        "}",
        "",
        "function truncateRows(rows, limit) {",
        "  if (rows.length <= limit) return { visible: rows, hiddenCount: 0 };",
        "  return { visible: rows.slice(0, limit), hiddenCount: rows.length - limit };",
        "}",
        "",
        "function formatSummaryRow(row) {",
        "  const when = row.lastModifiedDate || 'Unknown';",
        "  const user = row.displayUser || 'Unknown';",
        "  return '- ' + row.metadataType + ': `' + row.componentName + '` | User: ' + user + ' | Time: ' + when;",
        "}",
        "",
        "function buildAuditRows(summaryRows) {",
        "  return summaryRows.map((row) => {",
        "    const when = row.lastModifiedDate || 'Unknown';",
        "    const user = row.displayUser || 'Unknown';",
        "    return '- `' + row.filePath + '` -> ' + row.metadataType + ' `' + row.componentName + '` | User: ' + user + ' | Time: ' + when;",
        "  });",
        "}",
        "",
        "function buildUserRollupRows(summaryRows) {",
        "  const byUser = new Map();",
        "  for (const row of summaryRows) {",
        "    const user = row.displayUser || 'Unknown';",
        "    if (!byUser.has(user)) byUser.set(user, { count: 0, metadataTypes: new Set(), components: new Set() });",
        "    const bucket = byUser.get(user);",
        "    bucket.count += 1;",
        "    bucket.metadataTypes.add(row.metadataType || 'Unknown');",
        "    bucket.components.add(row.componentName || row.filePath || 'Unknown');",
        "  }",
        "  const sorted = [...byUser.entries()].sort((left, right) => right[1].count - left[1].count);",
        "  return sorted.map(([user, bucket]) => {",
        "    const types = [...bucket.metadataTypes].slice(0, 4).join(', ') || 'Unknown';",
        "    const componentList = [...bucket.components].slice(0, MAX_COMPONENTS_PER_USER).map((name) => '`' + name + '`').join(', ');",
        "    const omitted = bucket.components.size > MAX_COMPONENTS_PER_USER ? bucket.components.size - MAX_COMPONENTS_PER_USER : 0;",
        "    const omittedSuffix = omitted > 0 ? ' +' + omitted + ' more' : '';",
        "    return '- ' + user + ': ' + bucket.count + ' file(s) | Types: ' + types + ' | Components: ' + componentList + omittedSuffix;",
        "  });",
        "}",
        "",
        "function buildPrBody(orgAlias, changedFiles, summaryRows, branchName) {",
        "  const summaryLines = summaryRows.map(formatSummaryRow);",
        "  const auditRows = buildAuditRows(summaryRows);",
        "  const userRollupRows = buildUserRollupRows(summaryRows);",
        "  const fileRows = changedFiles.map((filePath) => '- `' + filePath + '`');",
        "  const truncatedSummary = truncateRows(summaryLines, MAX_SUMMARY_ROWS);",
        "  const truncatedAudit = truncateRows(auditRows, MAX_AUDIT_ROWS);",
        "  const truncatedUsers = truncateRows(userRollupRows, MAX_USER_ROWS);",
        "  const truncatedFiles = truncateRows(fileRows, MAX_FILE_ROWS);",
        "  const notes = [];",
        "  if (truncatedUsers.hiddenCount > 0) notes.push('- Omitted ' + truncatedUsers.hiddenCount + ' user rollup row(s) due to size limits.');",
        "  if (truncatedSummary.hiddenCount > 0) notes.push('- Omitted ' + truncatedSummary.hiddenCount + ' summary row(s) due to size limits.');",
        "  if (truncatedAudit.hiddenCount > 0) notes.push('- Omitted ' + truncatedAudit.hiddenCount + ' file audit row(s) due to size limits.');",
        "  if (truncatedFiles.hiddenCount > 0) notes.push('- Omitted ' + truncatedFiles.hiddenCount + ' file row(s) due to size limits.');",
        "",
        "  const detailedBody = [",
        "    'Automated Gitforce drift pull from Salesforce org `' + orgAlias + '`.',",
        "    '',",
        "    'Detected ' + changedFiles.length + ' changed files.',",
        "    '',",
        "    '### Who Changed What (By User)',",
        "    ...(truncatedUsers.visible.length > 0 ? truncatedUsers.visible : ['- No user rollup rows available.']),",
        "    '',",
        "    '### Component Change Summary',",
        "    ...(truncatedSummary.visible.length > 0 ? truncatedSummary.visible : ['- No summary rows available.']),",
        "    '',",
        "    '### File-to-Component Audit',",
        "    ...(truncatedAudit.visible.length > 0 ? truncatedAudit.visible : ['- No audit rows available.']),",
        "    '',",
        "    '### Files',",
        "    ...(truncatedFiles.visible.length > 0 ? truncatedFiles.visible : ['- No file rows available.']),",
        "    ...(notes.length > 0 ? ['', '### Notes', ...notes] : [])",
        "  ].join('\\n');",
        "",
        "  if (detailedBody.length <= MAX_PR_BODY_LENGTH) return detailedBody;",
        "",
        "  const compactBody = [",
        "    'Automated Gitforce drift pull from Salesforce org `' + orgAlias + '`.',",
        "    '',",
        "    'Detected ' + changedFiles.length + ' changed files.',",
        "    '',",
        "    '### Who Changed What (By User)',",
        "    ...(truncatedUsers.visible.slice(0, 20).length > 0 ? truncatedUsers.visible.slice(0, 20) : ['- No user rollup rows available.']),",
        "    '',",
        "    'PR body was compacted because the generated summary exceeded GitHub limits.',",
        "    'See branch `' + branchName + '` for full file details and generated changes.'",
        "  ].join('\\n');",
        "",
        "  return compactBody.length <= MAX_PR_BODY_LENGTH",
        "    ? compactBody",
        "    : compactBody.slice(0, MAX_PR_BODY_LENGTH - 32) + '\\n(Truncated)';",
        "}",
        "",
        "function toIsoTimestamp() {",
        "  return new Date().toISOString();",
        "}",
        "",
        "function toBranchTimestamp() {",
        "  return toIsoTimestamp().replace(/[-:]/g, '').replace(/\\..+/, '').replace('T', '-');",
        "}",
        "",
        "async function main() {",
        "  const report = ['## Gitforce Drift Detect'];",
        "  const addReport = (line) => {",
        "    report.push(line);",
        "    console.log(line);",
        "  };",
        "",
        "  const configRaw = await fs.readFile(CONFIG_PATH, 'utf8');",
        "  const config = JSON.parse(configRaw);",
        "  if (config?.drift?.enabled === false) {",
        "    addReport('- Drift detection is disabled in gitforce-project.json.');",
        "    await appendStepSummary(report);",
        "    return;",
        "  }",
        "",
        "  const token = process.env.GITHUB_TOKEN;",
        "  if (!token) throw new Error('GITHUB_TOKEN is required.');",
        "  const apiToken = process.env.GITFORCE_BOT_TOKEN || token;",
        "  const usingBotToken = Boolean(process.env.GITFORCE_BOT_TOKEN);",
        "",
        "  const authUrl = process.env.GITFORCE_SF_AUTH_URL;",
        "  if (!authUrl) throw new Error('GITFORCE_SF_AUTH_URL secret is required.');",
        "",
        "  const orgAlias = String(config?.environments?.targetOrgAlias ?? '').trim();",
        "  if (!orgAlias) throw new Error('environments.targetOrgAlias is required in gitforce-project.json');",
        "",
        "  const owner = String(config?.repository?.owner ?? '').trim();",
        "  const repo = String(config?.repository?.repo ?? '').trim();",
        "  const baseBranch = String(config?.repository?.baseBranch ?? 'main').trim() || 'main';",
        "  if (!owner || !repo) throw new Error('repository.owner and repository.repo are required.');",
        "",
        "  addReport('- Target org alias: `' + orgAlias + '`.');",
        "  addReport('- GitHub API token mode: ' + (usingBotToken ? 'GITFORCE_BOT_TOKEN' : 'GITHUB_TOKEN fallback') + '.');",
        "  if (!usingBotToken) {",
        "    addReport('- Warning: set `GITFORCE_BOT_TOKEN` to ensure drift PR creation triggers PR validation workflows.');",
        "  }",
        "  const authFilePath = path.join(os.tmpdir(), 'gitforce-drift-auth-' + Date.now() + '.txt');",
        "  await fs.writeFile(authFilePath, authUrl.trim(), 'utf8');",
        "  try {",
        "    runCommand('sf', ['org', 'login', 'sfdx-url', '--sfdx-url-file', authFilePath, '--alias', orgAlias, '--set-default', '--no-prompt']);",
        "  } finally {",
        "    await fs.rm(authFilePath, { force: true });",
        "  }",
        "",
        "  const retrieveArgs = ['project', 'retrieve', 'start', '--target-org', orgAlias, '--ignore-conflicts'];",
        "  const includeTypes = Array.isArray(config?.tracked?.metadataTypes)",
        "    ? config.tracked.metadataTypes.filter((entry) => typeof entry === 'string' && entry.trim())",
        "    : [];",
        "  const includePaths = Array.isArray(config?.tracked?.paths)",
        "    ? config.tracked.paths.filter((entry) => typeof entry === 'string' && entry.trim())",
        "    : [];",
        "  const deleteIntentPath =",
        "    config?.destructiveChanges?.enabled === false",
        "      ? ''",
        "      : String(config?.destructiveChanges?.intentPath ?? '.gitforce/deletes/pending').trim();",
        "",
        "  if (includeTypes.length > 0) {",
        "    for (const metadataType of includeTypes) retrieveArgs.push('--metadata', metadataType.trim());",
        "  } else if (includePaths.length > 0) {",
        "    for (const includePath of includePaths) retrieveArgs.push('--source-dir', includePath.trim());",
        "  }",
        "",
        "  addReport('- Retrieving Salesforce metadata...');",
        "  runCommand('sf', retrieveArgs);",
        "",
        "  const metadataIndex = includeTypes.length > 0 ? buildMetadataIndex(orgAlias, includeTypes) : new Map();",
        "  const orgDeletedTargets = detectOrgDeletedLocalTargets(includePaths, includeTypes, metadataIndex);",
        "  if (orgDeletedTargets.length > 0) {",
        "    addReport('- Detected ' + orgDeletedTargets.length + ' component path(s) deleted from org; removing locally.');",
        "    for (const deletionTarget of orgDeletedTargets) {",
        "      try {",
        "        await fs.rm(deletionTarget, { recursive: true, force: true });",
        "      } catch {",
        "        // ignore per-path failures",
        "      }",
        "    }",
        "  }",
        "",
        "  const porcelain = runCommand('git', ['status', '--porcelain']);",
        "  if (!porcelain) {",
        "    addReport('- No drift detected.');",
        "    await appendStepSummary(report);",
        "    return;",
        "  }",
        "",
        "  const changedFiles = parseChangedFilesFromPorcelain(porcelain);",
        "  if (changedFiles.length === 0) {",
        "    addReport('- No changed files parsed from git status output.');",
        "    await appendStepSummary(report);",
        "    return;",
        "  }",
        "",
        "  const pendingDeleteSourceSet = buildPendingDeleteIntentSourceSet(deleteIntentPath);",
        "  const filteredResult = filterTrackedChangedFiles(",
        "    changedFiles,",
        "    includePaths,",
        "    includeTypes,",
        "    pendingDeleteSourceSet",
        "  );",
        "  const driftFiles = filteredResult.filtered;",
        "  if (filteredResult.skippedByIntent.length > 0) {",
        "    addReport('- Ignored ' + filteredResult.skippedByIntent.length + ' file(s) because matching delete intents are pending.');",
        "  }",
        "",
        "  if (driftFiles.length === 0) {",
        "    addReport('- Changes were detected but none matched tracked metadata path/type scope.');",
        "    await appendStepSummary(report);",
        "    return;",
        "  }",
        "",
        "  addReport('- Drift files detected: ' + driftFiles.length);",
        "  const branchName = 'gitforce/drift-' + toBranchTimestamp();",
        "  runCommand('git', ['config', 'user.name', 'gitforce[bot]']);",
        "  runCommand('git', ['config', 'user.email', 'gitforce-bot@users.noreply.github.com']);",
        "  runCommand('git', ['checkout', '-B', branchName]);",
        "  stageFilesForCommit(driftFiles);",
        "  runCommand('git', ['commit', '-m', 'Gitforce drift sync (' + driftFiles.length + ' files)']);",
        "  runCommand('git', ['push', '--force-with-lease', 'origin', branchName]);",
        "",
        "  const summaryRows = await buildSummaryRows(config, orgAlias, driftFiles, apiToken);",
        "  const uniqueUsers = new Set(summaryRows.map((row) => row.displayUser || 'Unknown'));",
        "  addReport('- Drift attribution resolved for ' + uniqueUsers.size + ' user(s).');",
        "",
        "  const prBody = buildPrBody(orgAlias, driftFiles, summaryRows, branchName);",
        "  const title = 'Gitforce Drift Sync ' + toIsoTimestamp();",
        "",
        "  const openPrs = await githubRequest(apiToken, 'GET', '/repos/' + owner + '/' + repo + '/pulls?state=open&head=' + owner + ':' + branchName);",
        "  let pr = Array.isArray(openPrs) ? openPrs[0] : null;",
        "",
        "  if (!pr) {",
        "    pr = await githubRequest(apiToken, 'POST', '/repos/' + owner + '/' + repo + '/pulls', {",
        "      title,",
        "      head: branchName,",
        "      base: baseBranch,",
        "      body: prBody,",
        "      draft: false",
        "    });",
        "  } else {",
        "    pr = await githubRequest(apiToken, 'PATCH', '/repos/' + owner + '/' + repo + '/pulls/' + pr.number, {",
        "      title,",
        "      body: prBody",
        "    });",
        "  }",
        "",
        "  const shouldAutoMerge =",
        "    String(config?.drift?.mode ?? '') !== 'alert-only' && config?.merge?.allowAutoMerge !== false;",
        "  if (shouldAutoMerge && pr?.node_id) {",
        "    try {",
        "      await githubGraphql(apiToken,",
        "        'mutation EnableAutoMerge($pullRequestId: ID!) { enablePullRequestAutoMerge(input: { pullRequestId: $pullRequestId, mergeMethod: SQUASH }) { pullRequest { number } } }',",
        "        { pullRequestId: pr.node_id }",
        "      );",
        "      addReport('- Auto-merge requested for PR #' + pr.number + '.');",
        "    } catch (error) {",
        "      console.warn('Auto-merge enable failed: ' + (error instanceof Error ? error.message : String(error)));",
        "      addReport('- Auto-merge request failed for PR #' + pr.number + '.');",
        "    }",
        "  } else {",
        "    addReport('- Auto-merge is disabled by config.');",
        "  }",
        "",
        "  addReport('- Drift PR ready: #' + pr.number + ' ' + pr.html_url);",
        "  addReport('- Branch `' + branchName + '` will be deleted after merge when repository setting `delete_branch_on_merge` is enabled.');",
        "  await appendStepSummary(report);",
        "}",
        "",
        "main().catch((error) => {",
        "  console.error(error instanceof Error ? error.stack ?? error.message : String(error));",
        "  process.exit(1);",
        "});",
        ""
    ];
    return lines.join("\n");
}
//# sourceMappingURL=gitforceDriftScriptTemplate.js.map

/***/ }),

/***/ 932:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createDefaultGitforceLocalConfig = createDefaultGitforceLocalConfig;
exports.getGitforceLocalConfigPath = getGitforceLocalConfigPath;
exports.readGitforceLocalConfig = readGitforceLocalConfig;
exports.writeGitforceLocalConfig = writeGitforceLocalConfig;
exports.bootstrapGitforceLocalConfig = bootstrapGitforceLocalConfig;
exports.ensureGitforceLocalConfigIgnored = ensureGitforceLocalConfigIgnored;
exports.resolveLocalEnvironmentAlias = resolveLocalEnvironmentAlias;
const fs_1 = __nccwpck_require__(896);
const path = __importStar(__nccwpck_require__(928));
const GITFORCE_DIR = ".gitforce";
const LOCAL_CONFIG_FILE = "local.config.json";
function normalizeAlias(value) {
    if (typeof value !== "string") {
        return undefined;
    }
    const trimmed = value.trim();
    return trimmed || undefined;
}
function normalizeEnvironment(value) {
    if (value === "sandbox" || value === "production") {
        return value;
    }
    return "development";
}
function buildDefaultLocalConfig() {
    return {
        version: 1,
        salesforce: {
            activeEnvironment: "development"
        },
        github: {
            host: "github.com"
        }
    };
}
function createDefaultGitforceLocalConfig() {
    return buildDefaultLocalConfig();
}
function parseLocalConfig(raw) {
    const defaults = buildDefaultLocalConfig();
    const parsed = JSON.parse(raw);
    const salesforce = (parsed.salesforce ?? {});
    const github = (parsed.github ?? {});
    return {
        version: 1,
        salesforce: {
            activeEnvironment: normalizeEnvironment(salesforce.activeEnvironment),
            developmentOrgAlias: normalizeAlias(salesforce.developmentOrgAlias),
            sandboxOrgAlias: normalizeAlias(salesforce.sandboxOrgAlias),
            productionOrgAlias: normalizeAlias(salesforce.productionOrgAlias)
        },
        github: {
            host: typeof github.host === "string" && github.host.trim()
                ? github.host.trim()
                : defaults.github.host,
            user: normalizeAlias(github.user)
        }
    };
}
function getGitforceLocalConfigPath(workspacePath) {
    return path.join(workspacePath, GITFORCE_DIR, LOCAL_CONFIG_FILE);
}
async function readGitforceLocalConfig(workspacePath) {
    const configPath = getGitforceLocalConfigPath(workspacePath);
    try {
        const raw = await fs_1.promises.readFile(configPath, "utf8");
        return parseLocalConfig(raw);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (/enoent/i.test(message)) {
            return undefined;
        }
        throw new Error(`Failed to parse ${GITFORCE_DIR}/${LOCAL_CONFIG_FILE}: ${message}`);
    }
}
async function writeGitforceLocalConfig(workspacePath, config) {
    const configPath = getGitforceLocalConfigPath(workspacePath);
    await fs_1.promises.mkdir(path.dirname(configPath), { recursive: true });
    await fs_1.promises.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, "utf8");
    return configPath;
}
async function bootstrapGitforceLocalConfig(workspacePath) {
    const existing = await readGitforceLocalConfig(workspacePath);
    if (existing) {
        return existing;
    }
    const defaults = buildDefaultLocalConfig();
    await writeGitforceLocalConfig(workspacePath, defaults);
    return defaults;
}
async function ensureGitforceLocalConfigIgnored(workspacePath) {
    const gitignorePath = path.join(workspacePath, ".gitignore");
    const ignoreEntries = [".gitforce/local.config.json", ".gitforce/coverage-history.json"];
    let existing = "";
    try {
        existing = await fs_1.promises.readFile(gitignorePath, "utf8");
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (!/enoent/i.test(message)) {
            throw error;
        }
    }
    const lines = existing
        .split(/\r?\n/)
        .map((line) => line.trim());
    const missingEntries = ignoreEntries.filter((entry) => !lines.includes(entry));
    if (missingEntries.length === 0) {
        return;
    }
    const suffix = existing && !existing.endsWith("\n") ? "\n" : "";
    const next = `${existing}${suffix}${missingEntries.join("\n")}\n`;
    await fs_1.promises.writeFile(gitignorePath, next, "utf8");
}
function resolveLocalEnvironmentAlias(config) {
    if (!config) {
        return undefined;
    }
    const salesforce = config.salesforce;
    if (salesforce.activeEnvironment === "production") {
        return salesforce.productionOrgAlias;
    }
    if (salesforce.activeEnvironment === "sandbox") {
        return salesforce.sandboxOrgAlias;
    }
    return salesforce.developmentOrgAlias;
}
//# sourceMappingURL=gitforceLocalConfig.js.map

/***/ }),

/***/ 510:
/***/ ((__unused_webpack_module, exports, __nccwpck_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.validateGitforceCoreConfig = validateGitforceCoreConfig;
exports.validateGitforceLocalConfig = validateGitforceLocalConfig;
exports.combineValidationResults = combineValidationResults;
const gitforceLocalConfig_1 = __nccwpck_require__(932);
function emptyResult() {
    return {
        errors: [],
        warnings: []
    };
}
function validateGitforceCoreConfig(config) {
    const result = emptyResult();
    if (!config.repository.owner.trim()) {
        result.errors.push("repository.owner is required.");
    }
    if (!config.repository.repo.trim()) {
        result.errors.push("repository.repo is required.");
    }
    if (!config.repository.baseBranch.trim()) {
        result.errors.push("repository.baseBranch is required.");
    }
    if (config.tracked.paths.length === 0) {
        result.errors.push("tracked.paths must include at least one path.");
    }
    if (config.tracked.metadataTypes.length === 0) {
        result.errors.push("tracked.metadataTypes must include at least one metadata type.");
    }
    if (config.drift.enabled && config.drift.intervalMinutes <= 0) {
        result.errors.push("drift.intervalMinutes must be greater than zero when drift is enabled.");
    }
    if (config.destructiveChanges.enabled && !config.destructiveChanges.intentPath.trim()) {
        result.errors.push("destructiveChanges.intentPath is required when destructiveChanges.enabled is true.");
    }
    if (config.destructiveChanges.intentPath.includes("..")) {
        result.errors.push("destructiveChanges.intentPath cannot include \"..\" path segments.");
    }
    if (config.merge.requirePullRequest && config.merge.requiredChecks.length === 0) {
        result.warnings.push("merge.requiredChecks is empty while requirePullRequest is enabled.");
    }
    if (!config.branchPolicy.autoBranchPrefix.trim()) {
        result.errors.push("branchPolicy.autoBranchPrefix is required.");
    }
    if (config.branchPolicy.disallowDirectPushToBase && !config.merge.requirePullRequest) {
        result.warnings.push("branchPolicy.disallowDirectPushToBase is true while merge.requirePullRequest is false.");
    }
    const reservedLower = new Set(config.branchPolicy.reservedPrefixes.map((entry) => entry.toLowerCase()));
    if (reservedLower.size !== config.branchPolicy.reservedPrefixes.length) {
        result.warnings.push("branchPolicy.reservedPrefixes contains duplicates.");
    }
    if (config.branchPolicy.reservedPrefixes.some((prefix) => !prefix.trim())) {
        result.errors.push("branchPolicy.reservedPrefixes cannot contain empty entries.");
    }
    if (config.governance.requiredApprovingReviewCount < 0 ||
        config.governance.requiredApprovingReviewCount > 6) {
        result.errors.push("governance.requiredApprovingReviewCount must be between 0 and 6.");
    }
    if (config.governance.requireCodeOwnerReviews && config.governance.codeOwners.length === 0) {
        result.warnings.push("governance.requireCodeOwnerReviews is true but governance.codeOwners is empty.");
    }
    const hasGeneratedBasicTestClass = config.tests.enableBasicDataTests && Boolean(config.basicTests.generatedClassName.trim());
    if (config.deploy.testLevel === "RunSpecifiedTests" &&
        config.deploy.specifiedTests.length === 0 &&
        !hasGeneratedBasicTestClass) {
        result.errors.push("deploy.specifiedTests must include at least one class when deploy.testLevel is RunSpecifiedTests (or enable tests.enableBasicDataTests with a generated Apex class name).");
    }
    if (config.tests.enableBasicDataTests && config.deploy.testLevel !== "RunSpecifiedTests") {
        result.warnings.push("tests.enableBasicDataTests is true but deploy.testLevel is not RunSpecifiedTests. Built-in generated Apex tests may not run in validation/deploy workflows.");
    }
    if (config.codeAnalyzer.failOnSeverity < 1 || config.codeAnalyzer.failOnSeverity > 5) {
        result.errors.push("codeAnalyzer.failOnSeverity must be an integer from 1 (Critical) to 5 (Info).");
    }
    if (config.changeIntelligence.maxPrSummaryItems < 1) {
        result.errors.push("changeIntelligence.maxPrSummaryItems must be greater than zero.");
    }
    const laneBranches = [
        config.promotion.lanes.development.branch,
        config.promotion.lanes.sandbox.branch,
        config.promotion.lanes.production.branch
    ].map((entry) => entry.trim());
    if (laneBranches.some((entry) => !entry)) {
        result.errors.push("promotion.lanes.*.branch values are required.");
    }
    if (new Set(laneBranches.map((entry) => entry.toLowerCase())).size !== laneBranches.length) {
        result.warnings.push("promotion.lanes.*.branch values should be distinct.");
    }
    const profileNames = Object.keys(config.policyProfiles.profiles);
    if (!profileNames.includes(config.policyProfiles.defaultProfile)) {
        result.errors.push(`policyProfiles.defaultProfile "${config.policyProfiles.defaultProfile}" must exist in policyProfiles.profiles.`);
    }
    for (const [profileName, profile] of Object.entries(config.policyProfiles.profiles)) {
        if (profile.requiredChecks.length === 0 && profile.requirePullRequest) {
            result.warnings.push(`policyProfiles.profiles.${profileName}.requiredChecks is empty while requirePullRequest is true.`);
        }
        if (!profile.allowAutoMerge && profile.autoMergeOnChecksPass) {
            result.warnings.push(`policyProfiles.profiles.${profileName}.autoMergeOnChecksPass is true while allowAutoMerge is false.`);
        }
    }
    if (config.orchestration.maxConcurrentPerLane < 1) {
        result.errors.push("orchestration.maxConcurrentPerLane must be greater than zero.");
    }
    const hasEnvironmentAlias = Boolean(config.environments.developmentOrgAlias) ||
        Boolean(config.environments.sandboxOrgAlias) ||
        Boolean(config.environments.productionOrgAlias) ||
        Boolean(config.environments.targetOrgAlias);
    if (!hasEnvironmentAlias) {
        result.warnings.push("No Salesforce org aliases are configured in environments.*. Set them before running deploy/drift automation.");
    }
    return result;
}
function validateGitforceLocalConfig(config) {
    const result = emptyResult();
    if (!config) {
        result.warnings.push("Missing .gitforce/local.config.json. Run `gitforce:core -- init` to create local auth mapping.");
        return result;
    }
    const activeAlias = (0, gitforceLocalConfig_1.resolveLocalEnvironmentAlias)(config);
    if (!activeAlias) {
        result.warnings.push(`No org alias mapped for active environment '${config.salesforce.activeEnvironment}' in local config.`);
    }
    const aliases = [
        config.salesforce.developmentOrgAlias,
        config.salesforce.sandboxOrgAlias,
        config.salesforce.productionOrgAlias
    ].filter((entry) => Boolean(entry && entry.trim()));
    const unique = new Set(aliases.map((entry) => entry.toLowerCase()));
    if (aliases.length > unique.size) {
        result.warnings.push("Duplicate org aliases found across local environment mappings.");
    }
    return result;
}
function combineValidationResults(...results) {
    const combined = emptyResult();
    for (const result of results) {
        combined.errors.push(...result.errors);
        combined.warnings.push(...result.warnings);
    }
    return combined;
}
//# sourceMappingURL=gitforceValidation.js.map

/***/ }),

/***/ 565:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.parseGitStatusPorcelain = parseGitStatusPorcelain;
exports.filterSfdxPaths = filterSfdxPaths;
exports.formatTimestamp = formatTimestamp;
exports.renderTemplate = renderTemplate;
function normalizePath(input) {
    const trimmed = input.trim();
    const withoutQuotes = trimmed.startsWith('"') && trimmed.endsWith('"')
        ? trimmed.slice(1, -1)
        : trimmed;
    return withoutQuotes
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, "\\")
        .replace(/\\/g, "/");
}
function parseGitStatusPorcelain(output) {
    const files = new Set();
    for (const line of output.split("\n")) {
        const trimmed = line.trimEnd();
        if (!trimmed) {
            continue;
        }
        const match = trimmed.match(/^(?:[ MADRCU?!]{1,2})\s+(.*)$/);
        const payload = (match ? match[1] : trimmed).trim();
        if (!payload) {
            continue;
        }
        const renamedPath = payload.includes(" -> ")
            ? payload.split(" -> ").at(-1) ?? payload
            : payload;
        files.add(normalizePath(renamedPath));
    }
    return [...files];
}
function filterSfdxPaths(files, includePaths) {
    const normalizedIncludes = includePaths
        .map((entry) => entry.trim().replace(/\\/g, "/").replace(/\/+$/, ""))
        .filter(Boolean);
    if (normalizedIncludes.length === 0) {
        return [...files];
    }
    return files.filter((file) => {
        const normalizedFile = file.replace(/\\/g, "/");
        return normalizedIncludes.some((include) => normalizedFile === include ||
            normalizedFile.startsWith(`${include}/`) ||
            normalizedFile.startsWith(`./${include}/`) ||
            normalizedFile.startsWith(`./${include}`));
    });
}
function formatTimestamp(date) {
    const pad = (value) => value.toString().padStart(2, "0");
    return [
        date.getFullYear().toString(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
    ].join("") +
        "-" +
        [pad(date.getHours()), pad(date.getMinutes()), pad(date.getSeconds())].join("");
}
function renderTemplate(template, variables) {
    return template.replace(/\{(\w+)\}/g, (fullMatch, key) => {
        if (!(key in variables)) {
            return fullMatch;
        }
        return String(variables[key]);
    });
}
//# sourceMappingURL=helpers.js.map

/***/ }),

/***/ 59:
/***/ (function(__unused_webpack_module, exports, __nccwpck_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.normalizeSyncIntervalMinutes = normalizeSyncIntervalMinutes;
exports.buildCronExpression = buildCronExpression;
exports.parseUserMappingsInput = parseUserMappingsInput;
exports.serializeUserMappings = serializeUserMappings;
exports.getRepoSyncConfigPath = getRepoSyncConfigPath;
exports.getSyncScriptPath = getSyncScriptPath;
exports.getWorkflowPath = getWorkflowPath;
exports.readRepoSyncConfig = readRepoSyncConfig;
exports.writeRepoSyncConfig = writeRepoSyncConfig;
exports.writeSyncWorkflowAndScript = writeSyncWorkflowAndScript;
const fs_1 = __nccwpck_require__(896);
const path = __importStar(__nccwpck_require__(928));
const CONFIG_DIR = ".gitforce";
const CONFIG_FILE = "config.json";
const WORKFLOW_DIR = ".github/workflows";
const WORKFLOW_FILE = "gitforce-sync.yml";
const SYNC_SCRIPT_FILE = "sync.mjs";
const ALLOWED_INTERVALS = new Set([15, 30, 60, 120, 240, 720, 1440]);
function ensureString(value) {
    return typeof value === "string" ? value.trim() : "";
}
function ensureStringArray(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return value
        .filter((entry) => typeof entry === "string")
        .map((entry) => entry.trim())
        .filter(Boolean);
}
function normalizeSyncIntervalMinutes(rawValue) {
    const parsed = Number(rawValue);
    if (!Number.isFinite(parsed)) {
        return 15;
    }
    const rounded = Math.round(parsed);
    if (ALLOWED_INTERVALS.has(rounded)) {
        return rounded;
    }
    return 15;
}
function buildCronExpression(intervalMinutes) {
    const normalized = normalizeSyncIntervalMinutes(intervalMinutes);
    switch (normalized) {
        case 15:
            return "*/15 * * * *";
        case 30:
            return "*/30 * * * *";
        case 60:
            return "0 * * * *";
        case 120:
            return "0 */2 * * *";
        case 240:
            return "0 */4 * * *";
        case 720:
            return "0 */12 * * *";
        case 1440:
            return "0 0 * * *";
        default:
            return "*/15 * * * *";
    }
}
function parseUserMappingsInput(input) {
    const seen = new Set();
    const mappings = [];
    for (const rawLine of input.split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line || line.startsWith("#")) {
            continue;
        }
        const match = line.match(/^([^=:\s]+)\s*(?:=|=>|:)\s*([A-Za-z0-9-]+)$/);
        if (!match) {
            continue;
        }
        const salesforceUsername = match[1].trim();
        const githubUsername = match[2].trim();
        const key = `${salesforceUsername.toLowerCase()}::${githubUsername.toLowerCase()}`;
        if (seen.has(key)) {
            continue;
        }
        seen.add(key);
        mappings.push({ salesforceUsername, githubUsername });
    }
    return mappings;
}
function serializeUserMappings(mappings) {
    return mappings
        .map((mapping) => `${mapping.salesforceUsername}=${mapping.githubUsername}`)
        .join("\n");
}
function parseRepoSyncConfig(rawJson) {
    const parsed = JSON.parse(rawJson);
    const repositoryValue = (parsed.repository ?? {});
    const salesforceValue = (parsed.salesforce ?? {});
    const syncValue = (parsed.sync ?? {});
    const metadataValue = (parsed.metadata ?? {});
    const usersRaw = Array.isArray(parsed.users)
        ? parsed.users
        : [];
    const users = usersRaw
        .filter((entry) => !!entry && typeof entry === "object" && !Array.isArray(entry))
        .map((entry) => ({
        salesforceUsername: ensureString(entry.salesforceUsername),
        githubUsername: ensureString(entry.githubUsername)
    }))
        .filter((entry) => entry.salesforceUsername && entry.githubUsername);
    const intervalMinutes = normalizeSyncIntervalMinutes(syncValue.intervalMinutes ?? 15);
    return {
        version: Number(parsed.version) || 1,
        repository: {
            owner: ensureString(repositoryValue.owner),
            repo: ensureString(repositoryValue.repo),
            baseBranch: ensureString(repositoryValue.baseBranch) || "main",
            label: ensureString(repositoryValue.label) || undefined
        },
        salesforce: {
            orgAlias: ensureString(salesforceValue.orgAlias),
            orgUsername: ensureString(salesforceValue.orgUsername) || undefined,
            orgId: ensureString(salesforceValue.orgId) || undefined,
            instanceUrl: ensureString(salesforceValue.instanceUrl) || undefined,
            environment: ensureString(salesforceValue.environment) || undefined,
            authMode: ensureString(salesforceValue.authMode) === "manual"
                ? "manual"
                : "authenticated"
        },
        sync: {
            enabled: syncValue.enabled !== false,
            intervalMinutes,
            cron: ensureString(syncValue.cron) || buildCronExpression(intervalMinutes),
            autoMerge: syncValue.autoMerge !== false
        },
        metadata: {
            includePaths: ensureStringArray(metadataValue.includePaths),
            includeTypes: ensureStringArray(metadataValue.includeTypes)
        },
        users
    };
}
function getRepoSyncConfigPath(workspacePath) {
    return path.join(workspacePath, CONFIG_DIR, CONFIG_FILE);
}
function getSyncScriptPath(workspacePath) {
    return path.join(workspacePath, CONFIG_DIR, SYNC_SCRIPT_FILE);
}
function getWorkflowPath(workspacePath) {
    return path.join(workspacePath, WORKFLOW_DIR, WORKFLOW_FILE);
}
async function readRepoSyncConfig(workspacePath) {
    const configPath = getRepoSyncConfigPath(workspacePath);
    try {
        const raw = await fs_1.promises.readFile(configPath, "utf8");
        return parseRepoSyncConfig(raw);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (message.toLowerCase().includes("enoent")) {
            return undefined;
        }
        throw new Error(`Failed to parse ${CONFIG_DIR}/${CONFIG_FILE}: ${message}`);
    }
}
async function writeRepoSyncConfig(workspacePath, config) {
    const configPath = getRepoSyncConfigPath(workspacePath);
    await fs_1.promises.mkdir(path.dirname(configPath), { recursive: true });
    await fs_1.promises.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, "utf8");
    return configPath;
}
function getWorkflowTemplate(config) {
    const cron = config.sync.cron || buildCronExpression(config.sync.intervalMinutes);
    const triggerLines = config.sync.enabled
        ? [
            "on:",
            "  schedule:",
            `    - cron: "${cron}"`,
            "  workflow_dispatch:"
        ]
        : ["on:", "  workflow_dispatch:"];
    return [
        "name: Gitforce Org Sync",
        "",
        ...triggerLines,
        "",
        "permissions:",
        "  contents: write",
        "  pull-requests: write",
        "",
        "concurrency:",
        "  group: gitforce-sync-${{ github.repository }}",
        "  cancel-in-progress: false",
        "",
        "jobs:",
        "  sync:",
        "    runs-on: ubuntu-latest",
        "    steps:",
        "      - name: Checkout",
        "        uses: actions/checkout@v6",
        "        with:",
        "          fetch-depth: 1",
        "",
        "      - name: Setup Node",
        "        uses: actions/setup-node@v6",
        "        with:",
        "          node-version: \"24\"",
        "",
        "      - name: Cache npm",
        "        uses: actions/cache@v5",
        "        with:",
        "          path: ~/.npm",
        "          key: ${{ runner.os }}-gitforce-sf-npm-v1",
        "          restore-keys: |",
        "            ${{ runner.os }}-gitforce-sf-npm-",
        "",
        "      - name: Install Salesforce CLI",
        "        run: npm install --global @salesforce/cli@latest --prefer-offline --no-audit --no-fund",
        "",
        "      - name: Run Gitforce Sync",
        "        env:",
        "          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}",
        "          GITFORCE_SF_AUTH_URL: ${{ secrets.GITFORCE_SF_AUTH_URL }}",
        "        run: node .gitforce/sync.mjs",
        ""
    ].join("\n");
}
function getSyncScriptTemplate() {
    const lines = [
        "#!/usr/bin/env node",
        "import { promises as fs } from 'node:fs';",
        "import * as os from 'node:os';",
        "import * as path from 'node:path';",
        "import { execFileSync } from 'node:child_process';",
        "",
        "const CONFIG_PATH = path.join(process.cwd(), '.gitforce', 'config.json');",
        "",
        "function runCommand(command, args, cwd = process.cwd()) {",
        "  try {",
        "    const output = execFileSync(command, args, {",
        "      cwd,",
        "      encoding: 'utf8',",
        "      stdio: ['ignore', 'pipe', 'pipe'],",
        "      env: process.env,",
        "      maxBuffer: 50 * 1024 * 1024",
        "    });",
        "    return output.replace(/\\s+$/, '');",
        "  } catch (error) {",
        "    const stderr = error?.stderr?.toString?.() ?? '';",
        "    const stdout = error?.stdout?.toString?.() ?? '';",
        "    const message = stderr || stdout || error.message;",
        "    throw new Error('Command failed: ' + command + ' ' + args.join(' ') + '\\n' + message);",
        "  }",
        "}",
        "",
        "function parseChangedFilesFromPorcelain(porcelain) {",
        "  return porcelain",
        "    .split(/\\r?\\n/)",
        "    .map((line) => line.trimEnd())",
        "    .filter(Boolean)",
        "    .map((line) => {",
        "      const statusMatch = line.match(/^(?:[ MADRCU?!]{1,2})\\s+(.*)$/);",
        "      const candidate = (statusMatch ? statusMatch[1] : line).trim();",
        "      if (candidate.includes(' -> ')) {",
        "        const parts = candidate.split(' -> ');",
        "        return parts[1].trim();",
        "      }",
        "      return candidate;",
        "    })",
        "    .filter(Boolean);",
        "}",
        "",
        "function classifyComponent(filePath) {",
        "  const normalized = filePath.replace(/\\\\/g, '/');",
        "  let match = normalized.match(/\\/classes\\/([^/]+)\\.cls$/i);",
        "  if (match) return { metadataType: 'ApexClass', componentName: match[1] };",
        "  match = normalized.match(/\\/triggers\\/([^/]+)\\.trigger$/i);",
        "  if (match) return { metadataType: 'ApexTrigger', componentName: match[1] };",
        "  match = normalized.match(/\\/lwc\\/([^/]+)\\//i);",
        "  if (match) return { metadataType: 'LightningComponentBundle', componentName: match[1] };",
        "  match = normalized.match(/\\/aura\\/([^/]+)\\//i);",
        "  if (match) return { metadataType: 'AuraDefinitionBundle', componentName: match[1] };",
        "  match = normalized.match(/\\/objects\\/([^/]+)\\/fields\\/([^/]+)\\.field-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'CustomField', componentName: match[1] + '.' + match[2] };",
        "  match = normalized.match(/\\/objects\\/([^/]+)\\/[^/]+\\.object-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'CustomObject', componentName: match[1] };",
        "  match = normalized.match(/\\/layouts\\/([^/]+)\\.layout-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Layout', componentName: match[1] };",
        "  match = normalized.match(/\\/permissionSets\\/([^/]+)\\.permissionset-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'PermissionSet', componentName: match[1] };",
        "  match = normalized.match(/\\/profiles\\/([^/]+)\\.profile-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Profile', componentName: match[1] };",
        "  match = normalized.match(/\\/flows\\/([^/]+)\\.flow-meta\\.xml$/i);",
        "  if (match) return { metadataType: 'Flow', componentName: match[1] };",
        "  const fallback = normalized.split('/').pop() ?? normalized;",
        "  return { metadataType: 'Unknown', componentName: fallback };",
        "}",
        "",
        "async function githubRequest(token, method, apiPath, body) {",
        "  const response = await fetch('https://api.github.com' + apiPath, {",
        "    method,",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28',",
        "      'Content-Type': 'application/json'",
        "    },",
        "    body: body ? JSON.stringify(body) : undefined",
        "  });",
        "  if (response.status === 204) return null;",
        "  if (!response.ok) {",
        "    const errorText = await response.text();",
        "    throw new Error('GitHub API ' + method + ' ' + apiPath + ' failed (' + response.status + '): ' + errorText);",
        "  }",
        "  return response.json();",
        "}",
        "",
        "async function githubGraphql(token, query, variables) {",
        "  const response = await fetch('https://api.github.com/graphql', {",
        "    method: 'POST',",
        "    headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },",
        "    body: JSON.stringify({ query, variables })",
        "  });",
        "  const json = await response.json();",
        "  if (!response.ok || json.errors) throw new Error('GitHub GraphQL failed: ' + JSON.stringify(json.errors ?? json));",
        "  return json.data;",
        "}",
        "",
        "function normalizeUserMappings(mappings) {",
        "  const map = new Map();",
        "  for (const entry of mappings ?? []) {",
        "    if (!entry || typeof entry !== 'object') continue;",
        "    const sf = String(entry.salesforceUsername ?? '').trim().toLowerCase();",
        "    const gh = String(entry.githubUsername ?? '').trim();",
        "    if (sf && gh) map.set(sf, gh);",
        "  }",
        "  return map;",
        "}",
        "",
        "function chunk(items, size) {",
        "  const chunks = [];",
        "  for (let index = 0; index < items.length; index += size) chunks.push(items.slice(index, index + size));",
        "  return chunks;",
        "}",
        "",
        "function stageFilesForCommit(filePaths) {",
        "  for (const fileChunk of chunk(filePaths, 100)) {",
        "    runCommand('git', ['add', '-A', '--', ...fileChunk]);",
        "  }",
        "}",
        "",
        "function parseJsonOutput(raw) {",
        "  try { return JSON.parse(raw); } catch { return {}; }",
        "}",
        "",
        "function listMetadataForType(orgAlias, metadataType) {",
        "  try {",
        "    const output = runCommand('sf', ['org', 'list', 'metadata', '--target-org', orgAlias, '--metadata-type', metadataType, '--json']);",
        "    const parsed = parseJsonOutput(output);",
        "    return Array.isArray(parsed.result) ? parsed.result : [];",
        "  } catch {",
        "    return [];",
        "  }",
        "}",
        "",
        "function buildMetadataIndex(orgAlias, metadataTypes) {",
        "  const byType = new Map();",
        "  for (const metadataType of metadataTypes) {",
        "    const rows = listMetadataForType(orgAlias, metadataType);",
        "    const byFullName = new Map();",
        "    const byFileName = new Map();",
        "    for (const row of rows) {",
        "      const fullName = String(row.fullName ?? '').trim();",
        "      const fileName = String(row.fileName ?? '').trim();",
        "      if (fullName) byFullName.set(fullName, row);",
        "      if (fileName) byFileName.set(fileName, row);",
        "    }",
        "    byType.set(metadataType, { byFullName, byFileName });",
        "  }",
        "  return byType;",
        "}",
        "",
        "function matchMetadataRow(metadataIndex, metadataType, componentName, filePath) {",
        "  const bucket = metadataIndex.get(metadataType);",
        "  if (!bucket) return undefined;",
        "  if (bucket.byFullName.has(componentName)) return bucket.byFullName.get(componentName);",
        "  const normalizedPath = filePath.replace(/\\\\/g, '/');",
        "  for (const [fileName, row] of bucket.byFileName.entries()) {",
        "    if (normalizedPath.endsWith(fileName)) return row;",
        "  }",
        "  return undefined;",
        "}",
        "",
        "function fetchUsernamesById(orgAlias, userIds) {",
        "  const results = new Map();",
        "  for (const idChunk of chunk(userIds, 100)) {",
        "    const query = 'SELECT Id, Username FROM User WHERE Id IN (' + idChunk.map((id) => \"'\" + id + \"'\").join(',') + ')';",
        "    try {",
        "      const output = runCommand('sf', ['data', 'query', '--target-org', orgAlias, '--query', query, '--result-format', 'json']);",
        "      const parsed = parseJsonOutput(output);",
        "      const records = parsed?.result?.records;",
        "      if (!Array.isArray(records)) continue;",
        "      for (const record of records) {",
        "        const id = String(record.Id ?? '').trim();",
        "        const username = String(record.Username ?? '').trim();",
        "        if (id && username) results.set(id, username);",
        "      }",
        "    } catch {",
        "      // ignore per-chunk failures",
        "    }",
        "  }",
        "  return results;",
        "}",
        "",
        "async function isRepoCollaborator(token, owner, repo, username, cache) {",
        "  const key = username.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  const response = await fetch('https://api.github.com/repos/' + owner + '/' + repo + '/collaborators/' + username, {",
        "    method: 'GET',",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28'",
        "    }",
        "  });",
        "  const isCollaborator = response.status === 204;",
        "  cache.set(key, isCollaborator);",
        "  return isCollaborator;",
        "}",
        "",
        "async function getGitHubOwnerType(token, owner, cache) {",
        "  const key = owner.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  try {",
        "    const ownerData = await githubRequest(token, 'GET', '/users/' + owner);",
        "    const ownerType = String(ownerData?.type ?? '').trim().toLowerCase();",
        "    cache.set(key, ownerType);",
        "    return ownerType;",
        "  } catch {",
        "    cache.set(key, '');",
        "    return '';",
        "  }",
        "}",
        "",
        "async function isOrganizationMember(token, org, username, cache) {",
        "  const key = org.toLowerCase() + '::' + username.toLowerCase();",
        "  if (cache.has(key)) return cache.get(key);",
        "  const response = await fetch('https://api.github.com/orgs/' + org + '/members/' + username, {",
        "    method: 'GET',",
        "    headers: {",
        "      Authorization: 'Bearer ' + token,",
        "      Accept: 'application/vnd.github+json',",
        "      'X-GitHub-Api-Version': '2022-11-28'",
        "    }",
        "  });",
        "",
        "  if (response.status === 204) {",
        "    cache.set(key, true);",
        "    return true;",
        "  }",
        "",
        "  if (response.status === 404) {",
        "    cache.set(key, false);",
        "    return false;",
        "  }",
        "",
        "  cache.set(key, null);",
        "  return null;",
        "}",
        "",
        "async function buildSummaryRows(config, orgAlias, changedFiles, token) {",
        "  const components = changedFiles.map((filePath) => ({ filePath, ...classifyComponent(filePath) }));",
        "  const metadataTypes = [...new Set(components.map((entry) => entry.metadataType).filter((type) => type !== 'Unknown'))];",
        "  const metadataIndex = buildMetadataIndex(orgAlias, metadataTypes);",
        "  const rows = components.map((component) => ({",
        "    ...component,",
        "    metadataRow: matchMetadataRow(metadataIndex, component.metadataType, component.componentName, component.filePath)",
        "  }));",
        "  const userIds = [...new Set(rows.map((row) => String(row.metadataRow?.lastModifiedById ?? '').trim()).filter(Boolean))];",
        "  const usernamesById = fetchUsernamesById(orgAlias, userIds);",
        "  const userMapping = normalizeUserMappings(config.users);",
        "  const collaboratorCache = new Map();",
        "  const ownerTypeCache = new Map();",
        "  const orgMembershipCache = new Map();",
        "  const ownerType = await getGitHubOwnerType(token, config.repository.owner, ownerTypeCache);",
        "  const ownerIsOrganization = ownerType === 'organization';",
        "",
        "  for (const row of rows) {",
        "    const modifiedById = String(row.metadataRow?.lastModifiedById ?? '').trim();",
        "    const sfUsername = modifiedById ? usernamesById.get(modifiedById) : undefined;",
        "    row.lastModifiedDate = String(row.metadataRow?.lastModifiedDate ?? '').trim();",
        "    if (!sfUsername) {",
        "      row.displayUser = String(row.metadataRow?.lastModifiedByName ?? 'Unknown').trim() || 'Unknown';",
        "      continue;",
        "    }",
        "    const mappedGitHubUser = userMapping.get(sfUsername.toLowerCase());",
        "    if (!mappedGitHubUser) {",
        "      row.displayUser = sfUsername;",
        "      continue;",
        "    }",
        "",
        "    let mentionAllowed = false;",
        "    let mentionReason = '';",
        "",
        "    if (ownerIsOrganization) {",
        "      const memberStatus = await isOrganizationMember(token, config.repository.owner, mappedGitHubUser, orgMembershipCache);",
        "      if (memberStatus === true) {",
        "        mentionAllowed = true;",
        "      } else if (memberStatus === false) {",
        "        mentionReason = 'not a member of GitHub org ' + config.repository.owner;",
        "      } else {",
        "        const collaborator = await isRepoCollaborator(token, config.repository.owner, config.repository.repo, mappedGitHubUser, collaboratorCache);",
        "        mentionAllowed = collaborator;",
        "        mentionReason = collaborator",
        "          ? ''",
        "          : 'org membership unavailable and user is not a repo collaborator';",
        "      }",
        "    } else {",
        "      const collaborator = await isRepoCollaborator(token, config.repository.owner, config.repository.repo, mappedGitHubUser, collaboratorCache);",
        "      mentionAllowed = collaborator;",
        "      mentionReason = collaborator ? '' : 'not a repo collaborator';",
        "    }",
        "",
        "    row.displayUser = mentionAllowed",
        "      ? '@' + mappedGitHubUser",
        "      : sfUsername + ' (mapped to ' + mappedGitHubUser + ', ' + mentionReason + ')';",
        "  }",
        "",
        "  return rows;",
        "}",
        "",
        "function toIsoTimestamp() {",
        "  return new Date().toISOString();",
        "}",
        "",
        "function toBranchTimestamp() {",
        "  return toIsoTimestamp().replace(/[-:]/g, '').replace(/\\..+/, '').replace('T', '-');",
        "}",
        "",
        "const MAX_PR_BODY_LENGTH = 65000;",
        "const MAX_SUMMARY_ROWS = 200;",
        "const MAX_FILE_ROWS = 300;",
        "",
        "function truncateRows(rows, limit) {",
        "  if (rows.length <= limit) return { visible: rows, hiddenCount: 0 };",
        "  return { visible: rows.slice(0, limit), hiddenCount: rows.length - limit };",
        "}",
        "",
        "function buildPrBody(orgAlias, changedFiles, summaryLines, branchName) {",
        "  const truncatedSummary = truncateRows(summaryLines, MAX_SUMMARY_ROWS);",
        "  const fileRows = changedFiles.map((filePath) => '- `' + filePath + '`');",
        "  const truncatedFiles = truncateRows(fileRows, MAX_FILE_ROWS);",
        "  const notes = [];",
        "  if (truncatedSummary.hiddenCount > 0) notes.push('- Omitted ' + truncatedSummary.hiddenCount + ' summary row(s) due to size limits.');",
        "  if (truncatedFiles.hiddenCount > 0) notes.push('- Omitted ' + truncatedFiles.hiddenCount + ' file row(s) due to size limits.');",
        "",
        "  const detailedBody = [",
        "    'Automated Gitforce scheduled sync from Salesforce org `' + orgAlias + '`.',",
        "    '',",
        "    'Detected ' + changedFiles.length + ' changed files.',",
        "    '',",
        "    '### Change Summary',",
        "    ...(truncatedSummary.visible.length > 0 ? truncatedSummary.visible : ['- No summary rows available.']),",
        "    '',",
        "    '### Files',",
        "    ...(truncatedFiles.visible.length > 0 ? truncatedFiles.visible : ['- No file rows available.']),",
        "    ...(notes.length > 0 ? ['', '### Notes', ...notes] : [])",
        "  ].join('\\n');",
        "",
        "  if (detailedBody.length <= MAX_PR_BODY_LENGTH) return detailedBody;",
        "",
        "  const compactBody = [",
        "    'Automated Gitforce scheduled sync from Salesforce org `' + orgAlias + '`.',",
        "    '',",
        "    'Detected ' + changedFiles.length + ' changed files.',",
        "    '',",
        "    'PR body was compacted because the generated summary exceeded GitHub limits.',",
        "    'See branch `' + branchName + '` for full file details.'",
        "  ].join('\\n');",
        "",
        "  return compactBody.length <= MAX_PR_BODY_LENGTH",
        "    ? compactBody",
        "    : compactBody.slice(0, MAX_PR_BODY_LENGTH - 32) + '\\n(Truncated)';",
        "}",
        "",
        "async function main() {",
        "  const configRaw = await fs.readFile(CONFIG_PATH, 'utf8');",
        "  const config = JSON.parse(configRaw);",
        "  if (config?.sync?.enabled === false) {",
        "    console.log('Gitforce sync is disabled in .gitforce/config.json. Exiting.');",
        "    return;",
        "  }",
        "  if (!config?.repository?.owner || !config?.repository?.repo) throw new Error('Missing repository owner/repo in .gitforce/config.json');",
        "",
        "  const token = process.env.GITHUB_TOKEN;",
        "  if (!token) throw new Error('GITHUB_TOKEN is required.');",
        "",
        "  const authUrl = process.env.GITFORCE_SF_AUTH_URL;",
        "  if (!authUrl) throw new Error('GITFORCE_SF_AUTH_URL secret is required.');",
        "",
        "  const orgAlias = String(config?.salesforce?.orgAlias ?? 'gitforce-sync').trim() || 'gitforce-sync';",
        "  const authFilePath = path.join(os.tmpdir(), 'gitforce-auth-' + Date.now() + '.txt');",
        "  await fs.writeFile(authFilePath, authUrl.trim(), 'utf8');",
        "  try {",
        "    runCommand('sf', ['org', 'login', 'sfdx-url', '--sfdx-url-file', authFilePath, '--alias', orgAlias, '--set-default', '--no-prompt']);",
        "  } finally {",
        "    await fs.rm(authFilePath, { force: true });",
        "  }",
        "",
        "  const retrieveArgs = ['project', 'retrieve', 'start', '--target-org', orgAlias, '--ignore-conflicts'];",
        "  const includeTypes = Array.isArray(config?.metadata?.includeTypes)",
        "    ? config.metadata.includeTypes.filter((entry) => typeof entry === 'string' && entry.trim())",
        "    : [];",
        "  const includePaths = Array.isArray(config?.metadata?.includePaths)",
        "    ? config.metadata.includePaths.filter((entry) => typeof entry === 'string' && entry.trim())",
        "    : [];",
        "",
        "  let packageDirectories = [];",
        "  try {",
        "    const projectConfigRaw = await fs.readFile(path.join(process.cwd(), 'sfdx-project.json'), 'utf8');",
        "    const projectConfig = JSON.parse(projectConfigRaw);",
        "    const configuredDirectories = Array.isArray(projectConfig?.packageDirectories)",
        "      ? projectConfig.packageDirectories",
        "      : [];",
        "    packageDirectories = configuredDirectories",
        "      .map((entry) => (entry && typeof entry === 'object' ? String(entry.path ?? '').trim() : ''))",
        "      .filter(Boolean);",
        "  } catch {",
        "    // fall back to configured include paths when sfdx-project.json is unavailable",
        "  }",
        "",
        "  const existingIncludePaths = [];",
        "  for (const includePath of includePaths) {",
        "    const normalizedPath = String(includePath).trim();",
        "    if (!normalizedPath) continue;",
        "",
        "    if (packageDirectories.length > 0) {",
        "      const packageMatch = packageDirectories.some((packageDir) =>",
        "        normalizedPath === packageDir || normalizedPath.startsWith(packageDir + '/')",
        "      );",
        "      if (!packageMatch) {",
        "        console.warn('Skipping includePath outside sfdx packageDirectories: ' + normalizedPath);",
        "        continue;",
        "      }",
        "    }",
        "",
        "    try {",
        "      const stat = await fs.stat(path.join(process.cwd(), normalizedPath));",
        "      if (stat.isDirectory()) existingIncludePaths.push(normalizedPath);",
        "    } catch {",
        "      console.warn('Skipping missing source-dir: ' + normalizedPath);",
        "    }",
        "  }",
        "",
        "  if (includeTypes.length > 0) {",
        "    for (const metadataType of includeTypes) retrieveArgs.push('--metadata', metadataType.trim());",
        "  } else if (existingIncludePaths.length > 0) {",
        "    for (const includePath of existingIncludePaths) retrieveArgs.push('--source-dir', includePath);",
        "  } else if (includePaths.length > 0) {",
        "    console.warn('No valid configured includePaths were found. Running retrieve without --source-dir filters.');",
        "  }",
        "",
        "  runCommand('sf', retrieveArgs);",
        "",
        "  const porcelain = runCommand('git', ['status', '--porcelain']);",
        "  if (!porcelain) {",
        "    console.log('No Salesforce changes detected. Exiting.');",
        "    return;",
        "  }",
        "",
        "  const changedFiles = parseChangedFilesFromPorcelain(porcelain);",
        "  if (changedFiles.length === 0) {",
        "    console.log('No changed files parsed from git status output. Exiting.');",
        "    return;",
        "  }",
        "",
        "  const includedSummaryTypes = new Set(includeTypes.map((entry) => String(entry).trim()).filter(Boolean));",
        "  const committableFiles = includedSummaryTypes.size > 0",
        "    ? changedFiles.filter((filePath) => includedSummaryTypes.has(classifyComponent(filePath).metadataType))",
        "    : changedFiles;",
        "",
        "  if (includedSummaryTypes.size > 0 && committableFiles.length !== changedFiles.length) {",
        "    console.log('Filtered out ' + (changedFiles.length - committableFiles.length) + ' changed file(s) outside selected metadata types.');",
        "  }",
        "",
        "  if (committableFiles.length === 0) {",
        "    console.log('No changed files matched selected metadata types. Exiting.');",
        "    return;",
        "  }",
        "",
        "  const branchName = 'gitforce/sync-' + toBranchTimestamp();",
        "  runCommand('git', ['config', 'user.name', 'gitforce[bot]']);",
        "  runCommand('git', ['config', 'user.email', 'gitforce-bot@users.noreply.github.com']);",
        "  runCommand('git', ['checkout', '-B', branchName]);",
        "  stageFilesForCommit(committableFiles);",
        "  runCommand('git', ['commit', '-m', 'Gitforce scheduled sync (' + committableFiles.length + ' files)']);",
        "  runCommand('git', ['push', '--force-with-lease', 'origin', branchName]);",
        "",
        "  const summarySourceFiles = committableFiles;",
        "",
        "  const summaryRows = await buildSummaryRows(config, orgAlias, summarySourceFiles, token);",
        "  const summaryLines = summaryRows.map((row) => {",
        "    const when = row.lastModifiedDate || 'Unknown';",
        "    const user = row.displayUser || 'Unknown';",
        "    return '- ' + row.metadataType + ': `' + row.componentName + '` | User: ' + user + ' | Time: ' + when;",
        "  });",
        "",
        "  const prBody = buildPrBody(orgAlias, committableFiles, summaryLines, branchName);",
        "",
        "  const baseBranch = String(config?.repository?.baseBranch ?? 'main').trim() || 'main';",
        "  const title = 'Gitforce Scheduled Sync ' + toIsoTimestamp();",
        "  const pr = await githubRequest(token, 'POST', '/repos/' + config.repository.owner + '/' + config.repository.repo + '/pulls', {",
        "    title,",
        "    head: branchName,",
        "    base: baseBranch,",
        "    body: prBody,",
        "    draft: false",
        "  });",
        "",
        "  if (config?.sync?.autoMerge) {",
        "    try {",
        "      await githubGraphql(token,",
        "        'mutation EnableAutoMerge($pullRequestId: ID!) { enablePullRequestAutoMerge(input: { pullRequestId: $pullRequestId, mergeMethod: SQUASH }) { pullRequest { number } } }',",
        "        { pullRequestId: pr.node_id }",
        "      );",
        "    } catch (error) {",
        "      console.warn('Auto-merge enable failed: ' + (error instanceof Error ? error.message : String(error)));",
        "    }",
        "  }",
        "",
        "  console.log('Created PR #' + pr.number + ': ' + pr.html_url);",
        "}",
        "",
        "main().catch((error) => {",
        "  console.error(error instanceof Error ? error.stack ?? error.message : String(error));",
        "  process.exit(1);",
        "});",
        ""
    ];
    return lines.join("\n");
}
async function writeSyncWorkflowAndScript(workspacePath, config) {
    const workflowPath = getWorkflowPath(workspacePath);
    const scriptPath = getSyncScriptPath(workspacePath);
    await fs_1.promises.mkdir(path.dirname(workflowPath), { recursive: true });
    await fs_1.promises.mkdir(path.dirname(scriptPath), { recursive: true });
    await fs_1.promises.writeFile(workflowPath, getWorkflowTemplate(config), "utf8");
    await fs_1.promises.writeFile(scriptPath, getSyncScriptTemplate(), "utf8");
    return {
        workflowPath,
        scriptPath
    };
}
//# sourceMappingURL=repoSyncConfig.js.map

/***/ }),

/***/ 274:
/***/ ((__unused_webpack_module, exports, __nccwpck_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CommandExecutionError = void 0;
exports.runCommand = runCommand;
exports.runShellCommand = runShellCommand;
const child_process_1 = __nccwpck_require__(317);
const util_1 = __nccwpck_require__(23);
const execFileAsync = (0, util_1.promisify)(child_process_1.execFile);
class CommandExecutionError extends Error {
    command;
    args;
    exitCode;
    stdout;
    stderr;
    constructor(params) {
        super(params.message ??
            [
                `Command failed: ${params.command} ${params.args.join(" ")}`,
                params.stdout?.trim() || "",
                params.stderr?.trim() || ""
            ]
                .filter(Boolean)
                .join("\n"));
        this.name = "CommandExecutionError";
        this.command = params.command;
        this.args = params.args;
        this.exitCode = params.exitCode;
        this.stdout = params.stdout;
        this.stderr = params.stderr;
    }
}
exports.CommandExecutionError = CommandExecutionError;
async function runCommand(command, args, cwd, options) {
    try {
        const { stdout, stderr } = await execFileAsync(command, args, {
            cwd,
            env: process.env,
            timeout: options?.timeoutMs,
            maxBuffer: options?.maxBufferBytes ?? 10 * 1024 * 1024
        });
        return {
            stdout: stdout.toString().trim(),
            stderr: stderr.toString().trim()
        };
    }
    catch (error) {
        const err = error;
        const timedOut = Boolean(options?.timeoutMs && err.killed && err.signal === "SIGTERM");
        const timeoutMessage = timedOut
            ? `Command timed out after ${Math.round((options?.timeoutMs ?? 0) / 1000)}s: ${command} ${args.join(" ")}`
            : undefined;
        throw new CommandExecutionError({
            command,
            args,
            exitCode: err.code,
            stdout: err.stdout?.toString(),
            stderr: err.stderr?.toString(),
            message: timeoutMessage ?? err.message,
        });
    }
}
function runShellCommand(commandLine, cwd) {
    return runCommand("/bin/zsh", ["-lc", commandLine], cwd);
}
//# sourceMappingURL=shell.js.map

/***/ }),

/***/ 317:
/***/ ((module) => {

module.exports = require("child_process");

/***/ }),

/***/ 896:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 857:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 928:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("readline/promises");

/***/ }),

/***/ 23:
/***/ ((module) => {

module.exports = require("util");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __nccwpck_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			__webpack_modules__[moduleId].call(module.exports, module, module.exports, __nccwpck_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete __webpack_module_cache__[moduleId];
/******/ 		}
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat */
/******/ 	
/******/ 	if (typeof __nccwpck_require__ !== 'undefined') __nccwpck_require__.ab = __dirname + "/";
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __nccwpck_require__(335);
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;