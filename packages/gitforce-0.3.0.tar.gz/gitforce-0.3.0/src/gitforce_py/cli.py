from __future__ import annotations

import os
import shutil
import subprocess
import sys
from importlib import resources
from pathlib import Path


def _find_node_executable() -> str | None:
    env_override = os.environ.get("GITFORCE_NODE_BIN", "").strip()
    if env_override:
        return env_override
    return shutil.which("node")


def _resolve_bundled_cli_path() -> Path | None:
    try:
        vendor_root = resources.files("gitforce_py").joinpath("_vendor")
    except Exception:
        return None

    for filename in ("gitforce-cli.js", "index.js"):
        candidate = vendor_root.joinpath(filename)
        try:
            if candidate.is_file():
                return Path(str(candidate))
        except Exception:
            continue
    return None


def _print_node_missing_error() -> None:
    message = (
        "Gitforce requires Node.js on PATH.\n"
        "Install Node.js (recommended LTS) and retry.\n"
        "https://nodejs.org/en/download\n"
    )
    print(message, file=sys.stderr, end="")


def _print_bundle_missing_error() -> None:
    message = (
        "Gitforce Python wrapper is missing the bundled CLI artifact.\n"
        "Reinstall the package, or rebuild the wrapper bundle before publishing.\n"
    )
    print(message, file=sys.stderr, end="")


def main() -> int:
    node_executable = _find_node_executable()
    if not node_executable:
        _print_node_missing_error()
        return 1

    bundled_cli_path = _resolve_bundled_cli_path()
    if not bundled_cli_path:
        _print_bundle_missing_error()
        return 1

    command = [node_executable, str(bundled_cli_path), *sys.argv[1:]]
    completed = subprocess.run(command, check=False)
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
