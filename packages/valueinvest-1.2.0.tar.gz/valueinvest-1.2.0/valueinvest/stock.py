from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional, Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .data.fetcher import BaseFetcher, HistoryResult
    import pandas as pd


@dataclass
class StockHistory:
    ticker: str
    df: Optional["pd.DataFrame"] = None
    df_hfq: Optional["pd.DataFrame"] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    cagr: float = 0.0
    cagr_hfq: float = 0.0
    volatility: float = 0.0
    max_drawdown: float = 0.0
    prices: List[float] = field(default_factory=list)
    prices_hfq: List[float] = field(default_factory=list)
    adjust_type: str = "qfq"

    @classmethod
    def from_history_result(
        cls, result: "HistoryResult", result_hfq: Optional["HistoryResult"] = None
    ) -> "StockHistory":
        history = cls(
            ticker=result.ticker,
            df=result.df,
            start_date=result.start_date,
            end_date=result.end_date,
            cagr=result.calculate_cagr(),
            volatility=result.calculate_volatility(),
            max_drawdown=result.calculate_max_drawdown(),
            prices=result.prices,
        )

        if result_hfq and result_hfq.df is not None:
            history.df_hfq = result_hfq.df
            history.prices_hfq = result_hfq.prices
            history.cagr_hfq = result_hfq.calculate_cagr()

        return history

    def get_recent_prices(self, days: int = 30, adjust: str = "qfq") -> List[dict]:
        df = self.df_hfq if adjust == "hfq" else self.df
        if df is None or df.empty:
            return []

        recent = df.tail(days)
        result = []
        for idx, row in recent.iterrows():
            date_str = idx.strftime("%Y-%m-%d") if hasattr(idx, "strftime") else str(idx)
            result.append(
                {
                    "date": date_str,
                    "open": float(row["open"]),
                    "high": float(row["high"]),
                    "low": float(row["low"]),
                    "close": float(row["close"]),
                    "volume": int(row["volume"]) if row["volume"] else 0,
                }
            )
        return result

    def get_price_stats(self, days: int = 30, adjust: str = "qfq") -> dict:
        df = self.df_hfq if adjust == "hfq" else self.df
        if df is None or df.empty:
            return {}

        recent = df.tail(days)
        closes = recent["close"]

        return {
            "period_days": len(recent),
            "high": float(closes.max()),
            "low": float(closes.min()),
            "avg": float(closes.mean()),
            "latest": float(closes.iloc[-1]),
            "change_pct": float((closes.iloc[-1] - closes.iloc[0]) / closes.iloc[0] * 100),
        }


@dataclass
class Stock:
    ticker: str
    name: str = ""
    current_price: float = 0.0
    shares_outstanding: float = 0.0

    eps: float = 0.0
    bvps: float = 0.0
    revenue: float = 0.0
    net_income: float = 0.0
    fcf: float = 0.0

    current_assets: float = 0.0
    total_liabilities: float = 0.0
    current_liabilities: float = 0.0
    total_assets: float = 0.0
    net_debt: float = 0.0

    # Debt structure details (for accurate EV, ROIC, interest coverage)
    short_term_debt: float = 0.0
    long_term_debt: float = 0.0
    interest_expense: float = 0.0

    # Working capital components (for Owner Earnings accuracy)
    accounts_receivable: float = 0.0
    inventory: float = 0.0
    accounts_payable: float = 0.0

    # Historical multiples (for relative valuation)
    historical_pe: List[float] = field(default_factory=list)
    historical_pb: List[float] = field(default_factory=list)
    # Detailed historical PE/PB data with year, eps/bvps, avg_price, ratio
    historical_pe_data: list = field(default_factory=list)
    historical_pb_data: list = field(default_factory=list)
    # SBC (Stock-Based Compensation) related fields
    sbc: float = 0.0  # Stock-Based Compensation (annual)
    shares_issued: float = 0.0  # Shares issued from SBC/options (annual)
    shares_repurchased: float = 0.0  # Shares repurchased (annual)
    depreciation: float = 0.0
    capex: float = 0.0
    net_working_capital: float = 0.0
    net_fixed_assets: float = 0.0
    ebit: float = 0.0
    ebitda: float = 0.0
    retained_earnings: float = 0.0

    operating_margin: float = 0.0
    tax_rate: float = 0.0
    roe: float = 0.0

    growth_rate: float = 0.0
    dividend_per_share: float = 0.0
    dividend_yield: float = 0.0
    dividend_growth_rate: float = 0.0

    china_10y_yield: float = 1.80
    aaa_corporate_yield: float = 5.30
    cost_of_capital: float = 10.0
    discount_rate: float = 10.0
    terminal_growth: float = 2.0

    growth_rate_1_5: float = 5.0
    growth_rate_6_10: float = 3.0

    npl_ratio: float = 0.0
    provision_coverage: float = 0.0
    capital_adequacy_ratio: float = 0.0

    sector: str = ""
    industry: str = ""
    earnings_growth: float = 0.0
    revenue_growth: float = 0.0

    # Cash flow detail fields
    operating_cash_flow: float = 0.0
    total_debt: float = 0.0
    cash_and_equivalents: float = 0.0

    # Analyst target prices
    target_mean_price: float = 0.0
    target_high_price: float = 0.0
    target_low_price: float = 0.0
    number_of_analysts: int = 0
    recommendation: str = ""  # e.g. "Buy", "Hold", "Sell"

    sectors: list = field(default_factory=list)
    exchange: str = "SH"
    currency: str = "CNY"

    # Prior year data for F-Score and trend analysis
    prior_roa: float = 0.0
    prior_debt_ratio: float = 0.0
    prior_current_ratio: float = 0.0
    prior_shares_outstanding: float = 0.0
    prior_gross_margin: float = 0.0
    prior_asset_turnover: float = 0.0

    extra: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    @property
    def pe_ratio(self) -> float:
        return self.current_price / self.eps if self.eps > 0 else 0

    @property
    def pb_ratio(self) -> float:
        return self.current_price / self.bvps if self.bvps > 0 else 0

    @property
    def market_cap(self) -> float:
        return self.current_price * self.shares_outstanding

    @property
    def enterprise_value(self) -> float:
        return self.market_cap + self.net_debt

    @property
    def payout_ratio(self) -> float:
        return (self.dividend_per_share / self.eps * 100) if self.eps > 0 else 0

    @property
    def true_fcf_payout_ratio(self) -> float:
        total_dividend = self.dividend_per_share * self.shares_outstanding
        return (total_dividend / self.true_fcf * 100) if self.true_fcf > 0 else 0

    @property
    def fcf_per_share(self) -> float:
        return self.fcf / self.shares_outstanding if self.shares_outstanding > 0 else 0

    @property
    def gross_margin(self) -> float:
        """Gross margin as percentage. Computed from extra if available."""
        if self.revenue <= 0:
            return 0.0
        gm = self.extra.get("_gross_margin", 0.0)
        return gm if gm else 0.0

    @property
    def asset_turnover(self) -> float:
        """Asset turnover ratio. Computed from extra if available."""
        if self.total_assets <= 0:
            return 0.0
        at = self.extra.get("_asset_turnover", 0.0)
        return at if at else 0.0

    @property
    def current_ratio(self) -> float:
        """Current ratio. Computed from extra if available."""
        cr = self.extra.get("_current_ratio", 0.0)
        return cr if cr else 0.0

    @property
    def roa(self) -> float:
        """Return on Assets as percentage. Computed from extra if available."""
        roa = self.extra.get("_roa", 0.0)
        return roa if roa else 0.0

    @property
    def debt_ratio(self) -> float:
        """Total liabilities / total assets as percentage. Computed from extra if available."""
        dr = self.extra.get("_debt_ratio", 0.0)
        return dr if dr else 0.0

    # === CAGR Properties ===

    @property
    def revenue_cagr_5y(self) -> float:
        """5-year revenue CAGR from historical financial data (stored in extra)."""
        cagr = self.extra.get("revenue_cagr_5y", 0.0)
        return cagr if cagr else 0.0

    @property
    def earnings_cagr_5y(self) -> float:
        """5-year earnings (net income) CAGR from historical financial data (stored in extra)."""
        cagr = self.extra.get("earnings_cagr_5y", 0.0)
        return cagr if cagr else 0.0

    # === SBC Related Properties ===

    @property
    def sbc_margin(self) -> float:
        """SBC as percentage of revenue"""
        return (self.sbc / self.revenue * 100) if self.revenue > 0 else 0

    @property
    def sbc_as_pct_of_fcf(self) -> float:
        """SBC as percentage of FCF"""
        return (self.sbc / self.fcf * 100) if self.fcf > 0 else 0

    @property
    def true_fcf(self) -> float:
        """SBC-adjusted true FCF"""
        return self.fcf - self.sbc

    @property
    def true_fcf_per_share(self) -> float:
        """SBC-adjusted FCF per share"""
        return self.true_fcf / self.shares_outstanding if self.shares_outstanding > 0 else 0

    @property
    def dilution_rate(self) -> float:
        """Annual dilution rate from share issuance"""
        return (
            (self.shares_issued / self.shares_outstanding * 100)
            if self.shares_outstanding > 0
            else 0
        )

    @property
    def buyback_yield(self) -> float:
        """Gross buyback yield"""
        return (
            (self.shares_repurchased * self.current_price / self.market_cap * 100)
            if self.market_cap > 0 and self.shares_repurchased > 0
            else 0
        )

    @property
    def true_buyback_yield(self) -> float:
        """True buyback yield (net of dilution)"""
        if self.shares_outstanding <= 0 or self.market_cap <= 0:
            return 0
        net_reduction = self.shares_repurchased - self.shares_issued
        return net_reduction * self.current_price / self.market_cap * 100

    def shareholder_yield(self) -> float:
        """Total shareholder yield (dividend + true buyback yield)"""
        return self.dividend_yield + self.true_buyback_yield

    def __repr__(self) -> str:
        parts = [f"Stock({self.ticker})"]
        if self.name:
            parts.append(f'"{self.name}"')
        if self.current_price > 0:
            parts.append(f"Price: {self.current_price}")
        if self.eps > 0:
            parts.append(f"PE: {self.pe_ratio:.1f}")
        return " | ".join(parts)

    def summary(self) -> str:
        """Return a structured data summary for quick inspection."""
        lines = [f"=== {self.ticker} {self.name} ==="]
        lines.append(f"Price: {self.current_price} | PE: {self.pe_ratio:.1f} | PB: {self.pb_ratio:.1f}")
        lines.append(f"Market Cap: {self.market_cap:,.0f} | EV: {self.enterprise_value:,.0f}")
        lines.append(f"EPS: {self.eps} | BVPS: {self.bvps} | Div Yield: {self.dividend_yield:.1f}%")
        lines.append(f"Revenue: {self.revenue:,.0f} | Net Income: {self.net_income:,.0f} | FCF: {self.fcf:,.0f}")
        lines.append(f"ROE: {self.roe:.1f}% | Growth: {self.growth_rate:.1f}%")
        if self.sector:
            lines.append(f"Sector: {self.sector} | Industry: {self.industry}")
        if self.warnings:
            lines.append(f"Warnings: {'; '.join(self.warnings)}")
        # Data quality hints
        zero_fields = []
        if self.eps == 0: zero_fields.append("eps")
        if self.bvps == 0: zero_fields.append("bvps")
        if self.fcf == 0: zero_fields.append("fcf")
        if self.revenue == 0: zero_fields.append("revenue")
        if zero_fields:
            lines.append(f"Missing data: {', '.join(zero_fields)}")
        return "\n".join(lines)

    @classmethod
    def from_api(
        cls,
        ticker: str,
        source: Optional[str] = None,
        fetcher: Optional["BaseFetcher"] = None,
        tushare_token: Optional[str] = None,
    ) -> "Stock":
        from .data.fetcher import get_fetcher

        fetcher = fetcher or get_fetcher(ticker, source, tushare_token)
        result = fetcher.fetch_all(ticker)

        if not result.success:
            raise ValueError(f"Failed to fetch {ticker}: {result.errors}")

        stock = cls.from_dict(result.data)

        # Collect warnings
        _warnings: List[str] = []

        # Check data freshness with differentiated checks
        market = "A-share" if ticker.isdigit() else "US"

        # Check price data freshness (tolerant: today or yesterday)
        if "data_timestamp" in result.data:
            from .data.freshness import check_price_data_freshness, format_price_freshness_warning

            status, days_old, message = check_price_data_freshness(
                result.data["data_timestamp"], market=market
            )

            # Collect warning for stale/old price data
            if status in ("stale", "old"):
                _warnings.append(format_price_freshness_warning(status, days_old, ticker))

        # Check fundamental data freshness (tolerant: up to 6 months)
        if "fundamental_report_date" in result.data and result.data["fundamental_report_date"]:
            from .data.freshness import (
                check_fundamental_data_freshness,
                format_fundamental_freshness_warning,
            )

            status, months_old, message = check_fundamental_data_freshness(
                result.data["fundamental_report_date"]
            )

            # Collect warning for old fundamental data
            if status in ("stale", "old"):
                _warnings.append(format_fundamental_freshness_warning(status, months_old, ticker))

        stock.warnings = _warnings
        return stock

    @classmethod
    def fetch_price_history(
        cls,
        ticker: str,
        source: Optional[str] = None,
        fetcher: Optional["BaseFetcher"] = None,
        tushare_token: Optional[str] = None,
        period: str = "5y",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        include_hfq: bool = True,
    ) -> StockHistory:
        from .data.fetcher import get_fetcher

        fetcher = fetcher or get_fetcher(ticker, source, tushare_token)

        qfq_result = fetcher.fetch_history(
            ticker,
            start_date=start_date,
            end_date=end_date,
            period=period,
            adjust="qfq",
        )

        hfq_result = None
        if include_hfq:
            hfq_result = fetcher.fetch_history(
                ticker,
                start_date=start_date,
                end_date=end_date,
                period=period,
                adjust="hfq",
            )

        return StockHistory.from_history_result(qfq_result, hfq_result)

    @classmethod
    def from_dict(cls, data: dict) -> "Stock":
        # Extract extra fields that don't map to Stock attributes
        extra_fields = {}
        reserved_fields = {
            "ticker",
            "name",
            "current_price",
            "shares_outstanding",
            "eps",
            "bvps",
            "revenue",
            "net_income",
            "fcf",
            "current_assets",
            "total_liabilities",
            "current_liabilities",
            "total_assets",
            "net_debt",
            "short_term_debt",
            "long_term_debt",
            "interest_expense",
            "accounts_receivable",
            "inventory",
            "accounts_payable",
            "historical_pe",
            "historical_pb",
            "historical_pe_data",
            "historical_pb_data",
            "sbc",
            "shares_issued",
            "shares_repurchased",
            "depreciation",
            "capex",
            "net_working_capital",
            "net_fixed_assets",
            "ebit",
            "ebitda",
            "retained_earnings",
            "operating_margin",
            "tax_rate",
            "roe",
            "growth_rate",
            "dividend_per_share",
            "dividend_yield",
            "dividend_growth_rate",
            "china_10y_yield",
            "aaa_corporate_yield",
            "cost_of_capital",
            "discount_rate",
            "terminal_growth",
            "growth_rate_1_5",
            "growth_rate_6_10",
            "npl_ratio",
            "provision_coverage",
            "capital_adequacy_ratio",
            "sectors",
            "exchange",
            "currency",
            "prior_roa",
            "prior_debt_ratio",
            "prior_current_ratio",
            "prior_shares_outstanding",
            "prior_gross_margin",
            "prior_asset_turnover",
            "pe_ratio",
            "pb_ratio",
            "shareholder_equity",
            "market_cap",
            "enterprise_value",
            "sector",
            "industry",
            "earnings_growth",
            "revenue_growth",
            "operating_cash_flow",
            "total_debt",
            "cash_and_equivalents",
            "target_mean_price",
            "target_high_price",
            "target_low_price",
            "number_of_analysts",
            "recommendation",
        }

        # Store non-reserved fields in extra
        for key, value in data.items():
            if key not in reserved_fields and value is not None:
                extra_fields[key] = value

        return cls(
            ticker=data.get("ticker", ""),
            name=data.get("name", ""),
            current_price=data.get("current_price", 0.0),
            shares_outstanding=data.get("shares_outstanding", 0.0),
            eps=data.get("eps", 0.0),
            bvps=data.get("bvps", 0.0),
            revenue=data.get("revenue", 0.0),
            net_income=data.get("net_income", 0.0),
            fcf=data.get("fcf", 0.0),
            current_assets=data.get("current_assets", 0.0),
            total_liabilities=data.get("total_liabilities", 0.0),
            current_liabilities=data.get("current_liabilities", 0.0),
            total_assets=data.get("total_assets", 0.0),
            net_debt=data.get("net_debt", 0.0),
            short_term_debt=data.get("short_term_debt", 0.0),
            long_term_debt=data.get("long_term_debt", 0.0),
            interest_expense=data.get("interest_expense", 0.0),
            accounts_receivable=data.get("accounts_receivable", 0.0),
            inventory=data.get("inventory", 0.0),
            accounts_payable=data.get("accounts_payable", 0.0),
            historical_pe=data.get("historical_pe", []),
            historical_pb=data.get("historical_pb", []),
            historical_pe_data=data.get("historical_pe_data", []),
            historical_pb_data=data.get("historical_pb_data", []),
            sbc=data.get("sbc", 0.0),
            shares_issued=data.get("shares_issued", 0.0),
            shares_repurchased=data.get("shares_repurchased", 0.0),
            depreciation=data.get("depreciation", 0.0),
            capex=data.get("capex", 0.0),
            net_working_capital=data.get("net_working_capital", 0.0),
            net_fixed_assets=data.get("net_fixed_assets", 0.0),
            ebit=data.get("ebit", 0.0),
            ebitda=data.get("ebitda", 0.0),
            retained_earnings=data.get("retained_earnings", 0.0),
            operating_margin=data.get("operating_margin", 0.0),
            tax_rate=data.get("tax_rate", 0.0),
            roe=data.get("roe", 0.0),
            growth_rate=data.get("growth_rate", 0.0),
            dividend_per_share=data.get("dividend_per_share", 0.0),
            dividend_yield=data.get("dividend_yield", 0.0),
            dividend_growth_rate=data.get("dividend_growth_rate", 0.0),
            china_10y_yield=data.get("china_10y_yield", 1.80),
            aaa_corporate_yield=data.get("aaa_corporate_yield", 5.30),
            cost_of_capital=data.get("cost_of_capital", 10.0),
            discount_rate=data.get("discount_rate", 10.0),
            terminal_growth=data.get("terminal_growth", 2.0),
            growth_rate_1_5=data.get("growth_rate_1_5", 5.0),
            growth_rate_6_10=data.get("growth_rate_6_10", 3.0),
            npl_ratio=data.get("npl_ratio", 0.0),
            provision_coverage=data.get("provision_coverage", 0.0),
            capital_adequacy_ratio=data.get("capital_adequacy_ratio", 0.0),
            sectors=data.get("sectors", []),
            exchange=data.get("exchange", "SH"),
            currency=data.get("currency", "CNY"),
            # Prior year data for F-Score
            prior_roa=data.get("prior_roa", 0.0),
            prior_debt_ratio=data.get("prior_debt_ratio", 0.0),
            prior_current_ratio=data.get("prior_current_ratio", 0.0),
            prior_shares_outstanding=data.get("prior_shares_outstanding", 0.0),
            prior_gross_margin=data.get("prior_gross_margin", 0.0),
            prior_asset_turnover=data.get("prior_asset_turnover", 0.0),
            # Sector/industry info
            sector=data.get("sector", ""),
            industry=data.get("industry", ""),
            earnings_growth=data.get("earnings_growth", 0.0),
            revenue_growth=data.get("revenue_growth", 0.0),
            # Cash flow detail
            operating_cash_flow=data.get("operating_cash_flow", 0.0),
            total_debt=data.get("total_debt", 0.0),
            cash_and_equivalents=data.get("cash_and_equivalents", 0.0),
            # Analyst target prices
            target_mean_price=data.get("target_mean_price", 0.0),
            target_high_price=data.get("target_high_price", 0.0),
            target_low_price=data.get("target_low_price", 0.0),
            number_of_analysts=data.get("number_of_analysts", 0),
            recommendation=data.get("recommendation", ""),
            extra=extra_fields,
        )

    def to_dict(self, full: bool = False) -> dict:
        base = {
            "ticker": self.ticker,
            "name": self.name,
            "current_price": self.current_price,
            "eps": self.eps,
            "bvps": self.bvps,
            "revenue": self.revenue,
            "net_income": self.net_income,
            "fcf": self.fcf,
            "pe_ratio": self.pe_ratio,
            "pb_ratio": self.pb_ratio,
            "dividend_yield": self.dividend_yield,
            "roe": self.roe,
            "market_cap": self.market_cap,
        }
        if full:
            base.update({
                "shares_outstanding": self.shares_outstanding,
                "enterprise_value": self.enterprise_value,
                "ebit": self.ebit,
                "ebitda": self.ebitda,
                "operating_margin": self.operating_margin,
                "tax_rate": self.tax_rate,
                "growth_rate": self.growth_rate,
                "dividend_per_share": self.dividend_per_share,
                "dividend_growth_rate": self.dividend_growth_rate,
                "depreciation": self.depreciation,
                "capex": self.capex,
                "sbc": self.sbc,
                "shares_issued": self.shares_issued,
                "shares_repurchased": self.shares_repurchased,
                "operating_cash_flow": self.operating_cash_flow,
                "total_debt": self.total_debt,
                "cash_and_equivalents": self.cash_and_equivalents,
                "net_debt": self.net_debt,
                "short_term_debt": self.short_term_debt,
                "long_term_debt": self.long_term_debt,
                "total_assets": self.total_assets,
                "total_liabilities": self.total_liabilities,
                "current_liabilities": self.current_liabilities,
                "current_assets": self.current_assets,
                "sector": self.sector,
                "industry": self.industry,
                "currency": self.currency,
                "historical_pe": self.historical_pe,
                "historical_pb": self.historical_pb,
                "historical_pe_data": self.historical_pe_data,
                "historical_pb_data": self.historical_pb_data,
                "target_mean_price": self.target_mean_price,
                "target_high_price": self.target_high_price,
                "target_low_price": self.target_low_price,
                "number_of_analysts": self.number_of_analysts,
                "recommendation": self.recommendation,
            })
            if self.extra:
                base["extra"] = self.extra
        return base
