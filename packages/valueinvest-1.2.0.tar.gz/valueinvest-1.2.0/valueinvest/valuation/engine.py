"""
Valuation Engine - Unified interface for all valuation methods.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from .base import ValuationResult
from .graham import GrahamNumber, GrahamFormula, NCAV
from .dcf import DCF, ReverseDCF
from .epv import EPV
from .ddm import DDM, TwoStageDDM
from .growth import PEG, GARP, RuleOf40, EVEBITDA
from .bank import PBValuation, ResidualIncome
from .magic_formula import MagicFormula
from .quality import OwnerEarnings, AltmanZScore, PiotroskiFScore
from .value_trap import ValueTrapDetector, detect_value_trap
from .sbc import SBCAnalysis
from .relative import PERelativeValuation, PBRelativeValuation
from .mscore import BeneishMScore
# Cyclical valuation methods
try:
    from ..cyclical.valuation import (
        CyclicalPBValuation,
        CyclicalPEValuation,
        CyclicalFCFValuation,
        CyclicalDividendValuation,
    )
    CYCLICAL_AVAILABLE = True
except ImportError:
    CYCLICAL_AVAILABLE = False


@dataclass
class StockAnalysis:
    """Single stock analysis result for batch processing."""
    ticker: str
    name: str
    current_price: float
    fair_value: float
    upside_pct: float
    assessment: str
    methods_count: int
    reliable_methods: int
    top_methods: List[str]  # Methods that agree on assessment
    warnings: List[str] = field(default_factory=list)


@dataclass
class BatchAnalysisResult:
    """Result of batch stock analysis."""
    stocks: List[StockAnalysis]
    summary: Dict[str, Any]
    errors: List[str] = field(default_factory=list)

    @property
    def ranked_by_upside(self) -> List[StockAnalysis]:
        """Stocks ranked by upside potential (highest first)."""
        return sorted(
            [s for s in self.stocks if s.fair_value > 0],
            key=lambda x: x.upside_pct,
            reverse=True
        )

    @property
    def undervalued(self) -> List[StockAnalysis]:
        return [s for s in self.stocks if s.upside_pct > 15]

    @property
    def overvalued(self) -> List[StockAnalysis]:
        return [s for s in self.stocks if s.upside_pct < -15]


class ValuationEngine:
    DEFAULT_METHODS = [
        "graham_number",
        "graham_formula",
        "ncav",
        "dcf",
        "reverse_dcf",
        "epv",
        "ddm",
        "two_stage_ddm",
        "peg",
        "garp",
        "magic_formula",
        "owner_earnings",
        "ev_ebitda",
        "altman_z",
        "value_trap",
        "sbc_analysis",
        "piotroski_f",
        "pe_relative",  # NEW
        "pb_relative",  # NEW
        "beneish_m",  # NEW
        # Cyclical methods
        "cyclical_pb",
        "cyclical_pe",
        "cyclical_fcf",
        "cyclical_dividend",
    ]

    BANK_METHODS = [
        "graham_number",
        "pb",
        "residual_income",
        "ddm",
        "two_stage_ddm",
    ]

    DIVIDEND_METHODS = [
        "ddm",
        "two_stage_ddm",
        "graham_number",
        "graham_formula",
        "epv",
        "owner_earnings",
    ]

    GROWTH_METHODS = [
        "dcf",
        "reverse_dcf",
        "peg",
        "garp",
        "rule_of_40",
        "graham_formula",
        "magic_formula",
        "ev_ebitda",
    ]

    VALUE_METHODS = [
        "graham_number",
        "ncav",
        "epv",
        "graham_formula",
        "owner_earnings",
        "altman_z",
        "value_trap",
        "piotroski_f",
    ]

    CYCLICAL_METHODS = [
        "cyclical_pb",
        "cyclical_pe",
        "cyclical_fcf",
        "cyclical_dividend",
    ]

    # Methods that require CyclicalStock (not compatible with regular Stock)
    _CYCLICAL_STOCK_METHODS = set(CYCLICAL_METHODS)

    def __init__(self):
        self._methods = {
            "graham_number": GrahamNumber(),
            "graham_formula": GrahamFormula(),
            "ncav": NCAV(),
            "dcf": DCF(),
            "reverse_dcf": ReverseDCF(),
            "epv": EPV(),
            "ddm": DDM(),
            "two_stage_ddm": TwoStageDDM(),
            "peg": PEG(),
            "garp": GARP(),
            "rule_of_40": RuleOf40(),
            "pb": PBValuation(),
            "residual_income": ResidualIncome(),
            "magic_formula": MagicFormula(),
            "owner_earnings": OwnerEarnings(),
            "ev_ebitda": EVEBITDA(),
            "altman_z": AltmanZScore(),
            "sbc_analysis": SBCAnalysis(),
            "value_trap": ValueTrapDetector(),
            "piotroski_f": PiotroskiFScore(),
            # New Phase 1 methods
            "pe_relative": PERelativeValuation(),
            "pb_relative": PBRelativeValuation(),
            "beneish_m": BeneishMScore(),
            # Cyclical methods (optional)
            **({
                "cyclical_pb": CyclicalPBValuation(),
                "cyclical_pe": CyclicalPEValuation(),
                "cyclical_fcf": CyclicalFCFValuation(),
                "cyclical_dividend": CyclicalDividendValuation(),
            } if CYCLICAL_AVAILABLE else {})
        }

    def run_single(self, stock, method: str, **kwargs) -> ValuationResult:
        if method not in self._methods:
            raise ValueError(f"Unknown method: {method}. Available: {list(self._methods.keys())}")

        # Cyclical methods require CyclicalStock, not regular Stock
        if method in self._CYCLICAL_STOCK_METHODS:
            from ..cyclical.base import CyclicalStock
            if not isinstance(stock, CyclicalStock):
                return ValuationResult(
                    method=method,
                    fair_value=0,
                    current_price=stock.current_price,
                    premium_discount=0,
                    assessment="Not Applicable - requires CyclicalStock with cycle data",
                    missing_fields=[],
                    confidence="N/A",
                    applicability="Not Applicable",
                    details={"note": "Use the cyclical module's engine for cyclical valuation"},
                )

        valuator = self._methods[method]

        if kwargs:
            valuator = self._create_custom_valuator(method, kwargs)

        return valuator.calculate(stock)

    def _create_custom_valuator(self, method: str, kwargs: Dict[str, Any]):
        if method == "dcf":
            return DCF(
                growth_1_5=kwargs.get("growth_1_5"),
                growth_6_10=kwargs.get("growth_6_10"),
                terminal_growth=kwargs.get("terminal_growth"),
                discount_rate=kwargs.get("discount_rate"),
            )
        elif method == "ddm":
            return DDM(required_return=kwargs.get("required_return"))
        elif method == "two_stage_ddm":
            return TwoStageDDM(
                growth_stage1=kwargs.get("growth_stage1", 5.0),
                stage1_years=kwargs.get("stage1_years", 5),
                growth_stage2=kwargs.get("growth_stage2", 2.0),
                required_return=kwargs.get("required_return"),
            )
        elif method == "pb":
            return PBValuation(
                cost_of_equity=kwargs.get("cost_of_equity", 10.0),
                sustainable_growth=kwargs.get("sustainable_growth", 2.0),
            )
        elif method == "residual_income":
            return ResidualIncome(
                cost_of_equity=kwargs.get("cost_of_equity", 10.0),
                years=kwargs.get("years", 10),
                terminal_roe=kwargs.get("terminal_roe", 8.0),
            )
        elif method == "epv":
            return EPV(
                maintenance_capex_pct=kwargs.get("maintenance_capex_pct"),
                cost_of_capital=kwargs.get("cost_of_capital"),
            )
        elif method == "garp":
            return GARP(
                target_pe=kwargs.get("target_pe", 18),
                years=kwargs.get("years", 5),
                required_return=kwargs.get("required_return", 12.0),
            )
        elif method == "peg":
            return PEG(fair_peg=kwargs.get("fair_peg", 1.0))
        elif method == "owner_earnings":
            return OwnerEarnings(
                maintenance_capex_pct=kwargs.get("maintenance_capex_pct"),
                cost_of_capital=kwargs.get("cost_of_capital"),
            )
        elif method == "ev_ebitda":
            return EVEBITDA(
                fair_multiple=kwargs.get("fair_multiple"),
                industry=kwargs.get("industry"),
            )
        elif method == "altman_z":
            return AltmanZScore(
                zone_safe=kwargs.get("zone_safe", 2.99),
                zone_distress=kwargs.get("zone_distress", 1.81),
            )
        elif method == "value_trap":
            return ValueTrapDetector(
                revenue_cagr_3y=kwargs.get("revenue_cagr_3y"),
                revenue_cagr_5y=kwargs.get("revenue_cagr_5y"),
                margin_trend=kwargs.get("margin_trend"),
                roe_trend=kwargs.get("roe_trend"),
                market_share_trend=kwargs.get("market_share_trend"),
                industry=kwargs.get("industry"),
                sector=kwargs.get("sector"),
                ai_vulnerability_override=kwargs.get("ai_vulnerability_override"),
            )
        elif method == "piotroski_f":
            return PiotroskiFScore(
                prior_roa=kwargs.get("prior_roa"),
                prior_debt_ratio=kwargs.get("prior_debt_ratio"),
                prior_current_ratio=kwargs.get("prior_current_ratio"),
                prior_shares_outstanding=kwargs.get("prior_shares_outstanding"),
                prior_gross_margin=kwargs.get("prior_gross_margin"),
                prior_asset_turnover=kwargs.get("prior_asset_turnover"),
            )
        return self._methods[method]

    def run_multiple(
        self, stock, methods: Optional[List[str]] = None, **kwargs
    ) -> List[ValuationResult]:
        if methods is None:
            methods = self.DEFAULT_METHODS

        results = []
        for method in methods:
            try:
                result = self.run_single(stock, method, **kwargs)
                results.append(result)
            except ValueError as e:
                results.append(
                    ValuationResult(
                        method=method,
                        fair_value=0,
                        current_price=stock.current_price,
                        premium_discount=0,
                        assessment=f"Error: {e}",
                        missing_fields=[],
                        confidence="N/A",
                        applicability="Not Applicable",
                        details={"error_type": "ValueError"},
                    )
                )
            except Exception as e:
                error_type = type(e).__name__
                results.append(
                    ValuationResult(
                        method=method,
                        fair_value=0,
                        current_price=stock.current_price,
                        premium_discount=0,
                        assessment=f"Error ({error_type}): {e}",
                        missing_fields=[],
                        confidence="N/A",
                        applicability="Not Applicable",
                        details={"error_type": error_type},
                    )
                )

        return results

    def run_bank(self, stock, **kwargs) -> List[ValuationResult]:
        return self.run_multiple(stock, self.BANK_METHODS, **kwargs)

    def run_dividend(self, stock, **kwargs) -> List[ValuationResult]:
        return self.run_multiple(stock, self.DIVIDEND_METHODS, **kwargs)

    def run_growth(self, stock, **kwargs) -> List[ValuationResult]:
        return self.run_multiple(stock, self.GROWTH_METHODS, **kwargs)

    def run_value(self, stock, **kwargs) -> List[ValuationResult]:
        return self.run_multiple(stock, self.VALUE_METHODS, **kwargs)

    def run_cyclical(self, stock, **kwargs) -> List[ValuationResult]:
        """Run cyclical stock valuation methods."""
        if not CYCLICAL_AVAILABLE:
            return []
        return self.run_multiple(stock, self.CYCLICAL_METHODS, **kwargs)

    def run_all(self, stock, **kwargs) -> List[ValuationResult]:
        return self.run_multiple(stock, list(self._methods.keys()), **kwargs)

    def get_recommended_methods(self, stock) -> Dict[str, List[str]]:
        recommendations = {
            "primary": [],
            "secondary": [],
            "not_recommended": [],
        }

        has_dividend = stock.dividend_per_share > 0 and stock.dividend_yield > 1.5
        has_fcf = stock.fcf > 0
        has_positive_earnings = stock.eps > 0
        is_growth = stock.growth_rate > 10 if stock.growth_rate else False
        is_bank = hasattr(stock, "sectors") and any(
            s in ["银行", "Bank", "Financial", "Insurance"] for s in (stock.sectors or [])
        )
        is_value = stock.pe_ratio < 15 if stock.pe_ratio else False

        if is_bank:
            recommendations["primary"] = ["pb", "residual_income", "ddm", "altman_z"]
            recommendations["secondary"] = ["graham_number", "two_stage_ddm"]
            recommendations["not_recommended"] = [
                "dcf",
                "reverse_dcf",
                "magic_formula",
                "rule_of_40",
            ]
        elif has_dividend and not is_growth:
            recommendations["primary"] = ["ddm", "two_stage_ddm", "graham_number", "owner_earnings"]
            recommendations["secondary"] = ["epv", "graham_formula"]
            recommendations["not_recommended"] = ["rule_of_40"]
        elif is_growth and has_fcf:
            recommendations["primary"] = ["dcf", "reverse_dcf", "peg", "garp", "ev_ebitda"]
            recommendations["secondary"] = ["graham_formula", "magic_formula"]
            recommendations["not_recommended"] = ["ncav", "ddm"]
        elif is_value and has_positive_earnings:
            recommendations["primary"] = [
                "graham_number",
                "graham_formula",
                "epv",
                "owner_earnings",
            ]
            recommendations["secondary"] = ["ncav", "magic_formula", "altman_z"]
            recommendations["not_recommended"] = ["rule_of_40", "peg"]
        else:
            recommendations["primary"] = ["graham_formula", "epv"]
            recommendations["secondary"] = ["dcf"] if has_fcf else ["graham_number"]
            recommendations["not_recommended"] = []

        return recommendations

    def run_recommended(self, stock, **kwargs) -> List[ValuationResult]:
        recommendations = self.get_recommended_methods(stock)
        methods = recommendations["primary"] + recommendations["secondary"]
        return self.run_multiple(stock, methods, **kwargs)

    def summary(self, results: List[ValuationResult]) -> Dict[str, Any]:
        valid_results = [r for r in results if r.fair_value > 0 and r.is_reliable]

        if not valid_results:
            return {
                "average_value": 0,
                "median_value": 0,
                "min_value": 0,
                "max_value": 0,
                "undervalued_count": 0,
                "overvalued_count": 0,
                "fair_count": 0,
                "reliable_count": 0,
                "total_methods": len(results),
            }

        values = [r.fair_value for r in valid_results]
        current_price = results[0].current_price if results else 0

        undervalued = sum(1 for r in valid_results if r.premium_discount > 15)
        overvalued = sum(1 for r in valid_results if r.premium_discount < -15)
        fair = len(valid_results) - undervalued - overvalued

        sorted_values = sorted(values)
        mid = len(sorted_values) // 2
        median = (
            sorted_values[mid]
            if len(sorted_values) % 2 == 1
            else (sorted_values[mid - 1] + sorted_values[mid]) / 2
        )

        avg_premium = sum(r.premium_discount for r in valid_results) / len(valid_results)

        return {
            "average_value": sum(values) / len(values),
            "median_value": median,
            "min_value": min(values),
            "max_value": max(values),
            "undervalued_count": undervalued,
            "overvalued_count": overvalued,
            "fair_count": fair,
            "reliable_count": len(valid_results),
            "total_methods": len(results),
            "current_price": current_price,
            "average_premium_discount": avg_premium,
        }

    def get_available_methods(self) -> List[str]:
        return list(self._methods.keys())

    def get_method_info(self, method: str) -> Dict[str, Any]:
        if method not in self._methods:
            raise ValueError(f"Unknown method: {method}")

        valuator = self._methods[method]
        return valuator.get_applicability_info()

    def analyze_batch(
        self,
        tickers: List[str],
        methods: Optional[List[str]] = None,
        **kwargs
    ) -> BatchAnalysisResult:
        """Analyze multiple stocks and return comparative results.

        Args:
            tickers: List of stock ticker symbols
            methods: Specific methods to run (default: run_recommended)
            **kwargs: Additional kwargs passed to valuation methods

        Returns:
            BatchAnalysisResult with individual stock analyses and summary
        """
        from ..stock import Stock

        stock_results = []
        errors = []

        for ticker in tickers:
            try:
                stock = Stock.from_api(ticker)

                if methods:
                    results = self.run_multiple(stock, methods, **kwargs)
                else:
                    results = self.run_recommended(stock, **kwargs)

                summary = self.summary(results)

                # Get top agreeing methods
                valid = [r for r in results if r.fair_value > 0 and r.is_reliable]
                if valid:
                    assessments = {}
                    for r in valid:
                        a = r.assessment
                        assessments[a] = assessments.get(a, 0) + 1
                    top_assessment = max(assessments, key=assessments.get)
                    top_methods = [r.method for r in valid if r.assessment == top_assessment]
                else:
                    top_assessment = "N/A"
                    top_methods = []

                stock_results.append(StockAnalysis(
                    ticker=ticker,
                    name=stock.name,
                    current_price=stock.current_price,
                    fair_value=round(summary.get("median_value", 0), 2),
                    upside_pct=round(summary.get("average_premium_discount", 0), 1),
                    assessment=top_assessment,
                    methods_count=summary.get("total_methods", 0),
                    reliable_methods=summary.get("reliable_count", 0),
                    top_methods=top_methods[:3],
                    warnings=stock.warnings if hasattr(stock, 'warnings') else [],
                ))
            except Exception as e:
                errors.append(f"{ticker}: {type(e).__name__}: {e}")

        # Batch summary
        undervalued = [s for s in stock_results if s.upside_pct > 15]
        overvalued = [s for s in stock_results if s.upside_pct < -15]
        fair = [s for s in stock_results if -15 <= s.upside_pct <= 15 and s.fair_value > 0]

        batch_summary = {
            "total_analyzed": len(stock_results),
            "undervalued_count": len(undervalued),
            "overvalued_count": len(overvalued),
            "fair_value_count": len(fair),
            "error_count": len(errors),
            "avg_upside_pct": round(
                sum(s.upside_pct for s in stock_results) / len(stock_results), 1
            ) if stock_results else 0,
        }

        return BatchAnalysisResult(
            stocks=stock_results,
            summary=batch_summary,
            errors=errors,
        )

    @staticmethod
    def format_batch_table(result: BatchAnalysisResult) -> str:
        """Format batch results as a readable table."""
        lines = []
        lines.append(
            f"{'Ticker':<8} {'Name':<25} {'Price':>8} "
            f"{'Fair Val':>10} {'Upside':>8} {'Assessment':<15} {'Methods':>8}"
        )
        lines.append("-" * 85)

        for s in result.ranked_by_upside:
            name = s.name[:23] if s.name else s.ticker
            lines.append(
                f"{s.ticker:<8} {name:<25} ${s.current_price:>7.2f} "
                f"${s.fair_value:>9.2f} {s.upside_pct:>+7.1f}% "
                f"{s.assessment:<15} {s.reliable_methods:>3}/{s.methods_count:<3}"
            )

        lines.append("")
        lines.append(
            f"Summary: {result.summary.get('total_analyzed', 0)} analyzed, "
            f"{result.summary.get('undervalued_count', 0)} undervalued, "
            f"{result.summary.get('overvalued_count', 0)} overvalued"
        )

        if result.errors:
            lines.append(f"Errors: {len(result.errors)}")
            for e in result.errors:
                lines.append(f"  {e}")

        return "\n".join(lines)
