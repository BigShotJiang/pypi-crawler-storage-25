"""Pre-built hook bundle for claude-agent-sdk's hooks system.

Where ``auto_record(ClaudeSDKClient)`` (in ``agent_sdk.py``) wraps the
response stream, this module instead provides ready-to-mount
``ClaudeAgentOptions(hooks=...)`` callbacks that fire synchronously at
event boundaries. Pick one or the other depending on which integration
shape suits your codebase. Mounting BOTH is harmless but causes
double-recording.

Quick start::

    from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
    from neruva_record.agent_sdk_hooks import make_hooks

    opts = ClaudeAgentOptions(
        model="claude-haiku-4-5-20251001",
        hooks=make_hooks(namespace="dev_agent", ttl_days=30),
    )
    client = ClaudeSDKClient(options=opts)
    # ... use client normally; tool calls + prompts auto-recorded.

Covers: ``PreToolUse``, ``PostToolUse``, ``PostToolUseFailure``,
``UserPromptSubmit``, ``Stop``, ``SubagentStart``, ``SubagentStop``,
``Notification``.

Recursion firewall: calls to ``mcp__neruva__*`` substrate tools are
skipped so the recorder never re-records its own writes.
"""
from __future__ import annotations

import threading
from typing import Any, Optional

from claude_agent_sdk.types import HookMatcher

from ._hook import _redact_obj, _redact_secrets, _short, _summarize_tool_input
from ._recorder import make_recorder, Recorder
from .agent_sdk import _should_skip_tool


_USER_PREVIEW = 600
_RESULT_PREVIEW = 1200


def _emit(rec: Recorder, **kw: Any) -> None:
    threading.Thread(
        target=lambda: rec.ingest_record(**kw), daemon=True,
    ).start()


def _tags(session_id: str, extra: Optional[list[str]] = None, *more: str) -> list[str]:
    out = ["claude-agent-sdk", f"session:{session_id}"]
    if extra:
        out.extend(extra)
    out.extend(more)
    return out


def make_hooks(
    namespace: str = "agent",
    *,
    ttl_days: Optional[int] = None,
    neruva_api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    tags: Optional[list[str]] = None,
) -> dict[str, list[HookMatcher]]:
    """Return a hooks dict ready to drop into ``ClaudeAgentOptions``.

    Args:
        namespace:        Records namespace to write to.
        ttl_days:         Optional auto-expire window per record.
        neruva_api_key:   Falls back to ``NERUVA_API_KEY`` env var.
        base_url:         Override the Neruva endpoint.
        tags:             Extra tags added to every record (e.g.
                          ``["env:prod", "agent:research-bot"]``).
    """
    recorder = make_recorder(
        api_key=neruva_api_key, namespace=namespace,
        ttl_days=ttl_days, base_url=base_url,
    )
    extra_tags = list(tags or [])

    async def _pre_tool(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        tool = str(hook_input.get("tool_name", ""))
        if _should_skip_tool(tool):
            return {}
        summary = _summarize_tool_input(tool, hook_input.get("tool_input"))
        _emit(
            recorder, kind="tool_use",
            text=f"TOOL_USE {tool}: {summary}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags, tool),
            meta={
                "vendor": "claude-agent-sdk",
                "hook": "PreToolUse",
                "tool": tool,
                "tool_use_id": str(hook_input.get("tool_use_id", "")),
                "agent_id": str(hook_input.get("agent_id", "")),
                "cwd": str(hook_input.get("cwd", "")),
            },
        )
        return {}

    async def _post_tool(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        tool = str(hook_input.get("tool_name", ""))
        if _should_skip_tool(tool):
            return {}
        resp = hook_input.get("tool_response")
        text = _short(_redact_secrets(str(resp) if resp is not None else ""),
                      _RESULT_PREVIEW)
        _emit(
            recorder, kind="tool_result",
            text=f"TOOL_RESULT {tool}: {text}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags, tool),
            meta={
                "vendor": "claude-agent-sdk",
                "hook": "PostToolUse",
                "tool": tool,
                "tool_use_id": str(hook_input.get("tool_use_id", "")),
            },
        )
        return {}

    async def _post_tool_failure(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        tool = str(hook_input.get("tool_name", ""))
        if _should_skip_tool(tool):
            return {}
        resp = hook_input.get("tool_response")
        text = _short(_redact_secrets(str(resp) if resp is not None else ""),
                      _RESULT_PREVIEW)
        _emit(
            recorder, kind="tool_failure",
            text=f"TOOL_FAILURE {tool}: {text}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags, tool, "error"),
            meta={
                "vendor": "claude-agent-sdk",
                "hook": "PostToolUseFailure",
                "tool": tool,
                "tool_use_id": str(hook_input.get("tool_use_id", "")),
            },
        )
        return {}

    async def _user_prompt(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        prompt = _redact_secrets(str(hook_input.get("prompt", "")))
        if not prompt:
            return {}
        _emit(
            recorder, kind="user_prompt",
            text=f"USER: {_short(prompt, _USER_PREVIEW)}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags),
            meta={"vendor": "claude-agent-sdk", "hook": "UserPromptSubmit"},
        )
        return {}

    async def _stop(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        _emit(
            recorder, kind="assistant_stop",
            text=f"session_stop",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags),
            meta={
                "vendor": "claude-agent-sdk", "hook": "Stop",
                "stop_hook_active": bool(hook_input.get("stop_hook_active", False)),
            },
        )
        return {}

    async def _subagent_start(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        _emit(
            recorder, kind="subagent_start",
            text=f"subagent_start type={hook_input.get('subagent_type', '?')}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags,
                       "subagent"),
            meta={
                "vendor": "claude-agent-sdk", "hook": "SubagentStart",
                "subagent_type": str(hook_input.get("subagent_type", "")),
                "agent_id": str(hook_input.get("agent_id", "")),
            },
        )
        return {}

    async def _subagent_stop(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        _emit(
            recorder, kind="subagent_stop",
            text=f"subagent_stop",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags,
                       "subagent"),
            meta={
                "vendor": "claude-agent-sdk", "hook": "SubagentStop",
                "agent_id": str(hook_input.get("agent_id", "")),
            },
        )
        return {}

    async def _notification(hook_input: Any, _tool_use_id: Any, _ctx: Any) -> dict:
        msg = _redact_secrets(str(hook_input.get("message", "")))
        _emit(
            recorder, kind="notification",
            text=f"NOTIFY: {_short(msg, _RESULT_PREVIEW)}",
            tags=_tags(str(hook_input.get("session_id", "")), extra_tags),
            meta={"vendor": "claude-agent-sdk", "hook": "Notification"},
        )
        return {}

    return {
        "PreToolUse":         [HookMatcher(hooks=[_pre_tool])],
        "PostToolUse":        [HookMatcher(hooks=[_post_tool])],
        "PostToolUseFailure": [HookMatcher(hooks=[_post_tool_failure])],
        "UserPromptSubmit":   [HookMatcher(hooks=[_user_prompt])],
        "Stop":               [HookMatcher(hooks=[_stop])],
        "SubagentStart":      [HookMatcher(hooks=[_subagent_start])],
        "SubagentStop":       [HookMatcher(hooks=[_subagent_stop])],
        "Notification":       [HookMatcher(hooks=[_notification])],
    }


__all__ = ["make_hooks"]
