"""claude-agent-sdk auto-record wrapper.

Drop-in observability for ``claude_agent_sdk.ClaudeSDKClient``. Every
user prompt, tool_use, tool_result, and assistant text block emitted
by the SDK is captured into a Neruva Records namespace as a typed
event, with secrets redacted client-side.

Quick start::

    import asyncio
    from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
    from neruva_record.agent_sdk import auto_record

    async def main():
        opts = ClaudeAgentOptions(model="claude-haiku-4-5-20251001")
        client = auto_record(
            ClaudeSDKClient(options=opts),
            namespace="dev_agent",   # one per agent
            ttl_days=30,             # optional
        )
        await client.connect()
        try:
            await client.query("Hi, what time is it?")
            async for msg in client.receive_response():
                pass   # do whatever you'd normally do; recording is a side-effect
        finally:
            await client.disconnect()

    asyncio.run(main())

Set ``NERUVA_API_KEY`` env var or pass ``neruva_api_key=...``.

The wrapper is **fire-and-forget**: every record POST is run in a
background thread; if the POST fails, your agent loop is unaffected.

Recursion firewall: tool calls to ``mcp__neruva__*`` (the substrate's
own tools) are skipped so the recorder never re-records its own
writes.
"""
from __future__ import annotations

import os
import threading
import time
import uuid
from typing import Any, Optional

from ._hook import _redact_obj, _redact_secrets, _short, _summarize_tool_input
from ._recorder import make_recorder, Recorder


_USER_PREVIEW = 600
_TEXT_PREVIEW = 1800
_TOOL_RESULT_PREVIEW = 1200

# Substrate tools we must never re-record (would create infinite loop
# since the recorder itself POSTs to the substrate).
_NO_RECORD_PREFIXES = (
    "mcp__neruva__memory_",
    "mcp__neruva__records_",
    "mcp__neruva__agent_remember",
    "mcp__neruva__agent_recall",
    "mcp__neruva__agent_context",
)


def _should_skip_tool(name: str) -> bool:
    if not name:
        return False
    return any(name.startswith(p) for p in _NO_RECORD_PREFIXES)


def _emit_async(recorder: Recorder, **kwargs: Any) -> None:
    """Fire-and-forget background POST. Never blocks the caller."""
    t = threading.Thread(
        target=lambda: recorder.ingest_record(**kwargs), daemon=True,
    )
    t.start()


class _RecordingClient:
    """Proxy around ClaudeSDKClient that records every emitted message.

    Forwards every attribute lookup to the wrapped client; overrides
    only ``query``, ``receive_response``, and ``receive_messages`` to
    inject recording side-effects.
    """

    def __init__(
        self,
        client: Any,
        *,
        recorder: Recorder,
        session_id: Optional[str] = None,
        extra_tags: Optional[list[str]] = None,
    ) -> None:
        self._client = client
        self._recorder = recorder
        self._session_id = session_id or uuid.uuid4().hex[:12]
        self._extra_tags = list(extra_tags or [])
        self._last_user_prompt: Optional[str] = None

    # ---- proxy ----
    def __getattr__(self, name: str) -> Any:
        # Called only when name is not found on self (proxy fallback).
        return getattr(self._client, name)

    # ---- recording side-effects ----
    def _tags(self, *extra: str) -> list[str]:
        return [
            "claude-agent-sdk",
            f"session:{self._session_id}",
            *self._extra_tags,
            *extra,
        ]

    def _record_user_prompt(self, text: str) -> None:
        text = _redact_secrets(str(text or ""))
        if not text:
            return
        self._last_user_prompt = text
        _emit_async(
            self._recorder,
            kind="user_prompt",
            text=f"USER: {_short(text, _USER_PREVIEW)}",
            tags=self._tags(),
            meta={"vendor": "claude-agent-sdk"},
        )

    def _record_block(self, block: Any) -> None:
        btype = type(block).__name__
        if btype == "TextBlock":
            text = _redact_secrets(str(getattr(block, "text", "")))
            if not text:
                return
            _emit_async(
                self._recorder,
                kind="assistant_turn",
                text=f"ASSISTANT: {_short(text, _TEXT_PREVIEW)}",
                tags=self._tags(),
                meta={"vendor": "claude-agent-sdk"},
            )
        elif btype == "ToolUseBlock":
            name = str(getattr(block, "name", ""))
            if _should_skip_tool(name):
                return
            inp = getattr(block, "input", None)
            summary = _summarize_tool_input(name, inp)
            tool_id = str(getattr(block, "id", ""))
            _emit_async(
                self._recorder,
                kind="tool_use",
                text=f"TOOL_USE {name}: {summary}",
                tags=self._tags(name),
                meta={
                    "vendor": "claude-agent-sdk",
                    "tool": name,
                    "tool_use_id": tool_id,
                },
            )
        elif btype == "ToolResultBlock":
            content = getattr(block, "content", None)
            content_str = str(content) if content is not None else ""
            content_str = _redact_secrets(content_str)
            tool_use_id = str(getattr(block, "tool_use_id", ""))
            is_error = bool(getattr(block, "is_error", False))
            _emit_async(
                self._recorder,
                kind="tool_failure" if is_error else "tool_result",
                text=f"TOOL_RESULT: {_short(content_str, _TOOL_RESULT_PREVIEW)}",
                tags=self._tags("error" if is_error else "ok"),
                meta={
                    "vendor": "claude-agent-sdk",
                    "tool_use_id": tool_use_id,
                    "is_error": is_error,
                },
            )

    def _record_message(self, msg: Any) -> None:
        cls = type(msg).__name__
        if cls in ("AssistantMessage", "UserMessage"):
            for b in getattr(msg, "content", []) or []:
                self._record_block(b)

    # ---- overridden methods ----
    async def query(self, prompt: Any, *args: Any, **kwargs: Any) -> Any:
        # Capture the user prompt synchronously so it's ordered before any
        # tool calls emitted in the response.
        if isinstance(prompt, str):
            self._record_user_prompt(prompt)
        return await self._client.query(prompt, *args, **kwargs)

    async def receive_response(self) -> Any:
        async for msg in self._client.receive_response():
            try:
                self._record_message(msg)
            except Exception:
                # Never let recording break the agent loop.
                pass
            yield msg

    async def receive_messages(self) -> Any:
        async for msg in self._client.receive_messages():
            try:
                self._record_message(msg)
            except Exception:
                pass
            yield msg


def auto_record(
    client: Any,
    *,
    namespace: str = "agent",
    ttl_days: Optional[int] = None,
    neruva_api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    session_id: Optional[str] = None,
    tags: Optional[list[str]] = None,
) -> Any:
    """Wrap a ``ClaudeSDKClient`` so every event is auto-recorded.

    Returns a proxy that behaves identically to the wrapped client; the
    only difference is the side-effect of POSTing each event to a
    Neruva Records namespace.

    Args:
        client:            A ``claude_agent_sdk.ClaudeSDKClient`` instance.
        namespace:         Records namespace to write to.
        ttl_days:          Optional auto-expire window for each record.
        neruva_api_key:    Falls back to ``NERUVA_API_KEY`` env var.
        base_url:          Override the Neruva endpoint (defaults to
                           ``https://api.neruva.io`` or ``NERUVA_URL``).
        session_id:        Optional session id; auto-minted if omitted.
                           Stored as a tag so all events from one
                           session can be queried together.
        tags:              Extra tags added to every record. Useful for
                           ``["env:prod", "agent:research-bot"]``.

    Returns:
        A proxy client. Use it exactly like the wrapped
        ``ClaudeSDKClient``.
    """
    recorder = make_recorder(
        api_key=neruva_api_key, namespace=namespace,
        ttl_days=ttl_days, base_url=base_url,
    )
    return _RecordingClient(
        client, recorder=recorder, session_id=session_id, extra_tags=tags,
    )
