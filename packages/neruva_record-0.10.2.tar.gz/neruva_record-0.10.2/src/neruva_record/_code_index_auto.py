"""neruva-record-code-index-auto -- SessionStart-hook wrapper.

Designed to be called on SessionStart (or manually) with no arguments.
Conditions for firing:
  - NERUVA_AUTO_CODE_INDEX is set to a non-empty truthy value
  - cwd contains a project marker file: pyproject.toml / setup.py /
    package.json / Cargo.toml / go.mod
  - The cwd hasn't been indexed in the last NERUVA_AUTO_CODE_INDEX_TTL
    seconds (default 3600 = 1 hour)

KG name is derived deterministically from the cwd absolute path:
  code-<basename>-<short_hash>

This lets Claude Code re-resolve the same KG across sessions without
the user remembering names. Marker file lives in
~/.neruva/code-index-cache/<hash>.last (mtime is the last-indexed
timestamp).

The wrapper invokes the standard `_code_index.main(...)` -- no
duplicated logic.
"""
from __future__ import annotations

import hashlib
import os
import sys
import time
from pathlib import Path


PROJECT_MARKERS = (
    "pyproject.toml", "setup.py", "setup.cfg",
    "package.json",
    "Cargo.toml", "go.mod",
)


def _truthy(val: str | None) -> bool:
    if not val:
        return False
    return val.strip().lower() not in ("", "0", "false", "no", "off")


def _cache_dir() -> Path:
    base = os.environ.get("NERUVA_CODE_INDEX_CACHE")
    if base:
        d = Path(base)
    else:
        d = Path.home() / ".neruva" / "code-index-cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _kg_name_for(cwd: Path) -> str:
    h = hashlib.sha1(str(cwd.resolve()).encode("utf-8")).hexdigest()[:10]
    name = cwd.resolve().name.lower() or "root"
    safe_name = "".join(c if c.isalnum() or c in "-_" else "-"
                        for c in name)[:32].strip("-") or "root"
    return f"code-{safe_name}-{h}"


def _has_marker(cwd: Path) -> str | None:
    for m in PROJECT_MARKERS:
        if (cwd / m).exists():
            return m
    return None


def _ttl_seconds() -> int:
    try:
        return int(os.environ.get("NERUVA_AUTO_CODE_INDEX_TTL", "3600"))
    except ValueError:
        return 3600


def _is_fresh(stamp_path: Path, ttl: int) -> bool:
    if not stamp_path.exists():
        return False
    age = time.time() - stamp_path.stat().st_mtime
    return age < ttl


def main(argv: list[str] | None = None) -> int:
    if not _truthy(os.environ.get("NERUVA_AUTO_CODE_INDEX")):
        # Silent no-op. Designed for SessionStart hook where chatter
        # would clutter the user's terminal.
        return 0

    cwd = Path.cwd().resolve()
    marker = _has_marker(cwd)
    if marker is None:
        return 0

    kg_name = _kg_name_for(cwd)
    cache = _cache_dir()
    stamp = cache / f"{kg_name}.last"
    ttl = _ttl_seconds()
    if _is_fresh(stamp, ttl):
        # Recently indexed -- skip.
        return 0

    # Defer import so the SessionStart fast-path (above) doesn't pay
    # the cost of loading httpx / argparse when conditions aren't met.
    from neruva_record._code_index import main as code_index_main

    engine = os.environ.get("NERUVA_AUTO_CODE_INDEX_ENGINE", "hadamard")
    api_url = os.environ.get("NERUVA_API_URL") or "https://api.neruva.io"
    api_key = os.environ.get("NERUVA_API_KEY")
    if not api_key:
        # No key -- silent no-op so we don't surprise users.
        return 0

    inner_args = [
        str(cwd),
        "--kg-name", kg_name,
        "--engine", engine,
        "--api-url", api_url,
        "--api-key", api_key,
    ]
    try:
        rc = code_index_main(inner_args)
    except Exception as e:
        # Never block the SessionStart hook on indexing failure.
        sys.stderr.write(f"neruva-auto-code-index: {e!r}\n")
        return 0
    # Update marker on success only.
    if rc == 0:
        stamp.touch()
        print(f"[neruva] auto code-index: kg={kg_name} (marker={marker})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
