"""Internal recorder: HTTP client + typed-record formatting.

Used by the per-vendor wrappers (anthropic, openai, ...) and the
Claude Code hook entry-point to ship captured events to a Neruva
Records namespace via fire-and-forget HTTP POSTs. Failures are
swallowed -- recording must never break the caller.

As of 0.5.0 the recorder writes to ``/v1/records/{namespace}`` (typed
substrate) rather than the older ``/v1/indexes/{i}/text/upsert``
Pinecone-compat endpoint.
"""
from __future__ import annotations

import os
import time
from typing import Any, Optional, Sequence
from urllib.parse import quote

import httpx


_DEFAULT_URL = "https://api.neruva.io"


class Recorder:
    """Holds connection state for a single Records namespace."""

    def __init__(
        self,
        api_key: str,
        namespace: str = "",
        ttl_days: Optional[int] = None,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError(
                "neruva-record requires NERUVA_API_KEY. "
                "Set the env var or pass neruva_api_key=... to auto_record()."
            )
        self.api_key = api_key
        self.namespace = namespace or ""
        self.ttl_days = ttl_days if (ttl_days and ttl_days > 0) else None
        self.base_url = (base_url or os.environ.get(
            "NERUVA_URL", _DEFAULT_URL,
        )).rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Api-Key": self.api_key,
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass

    def ingest_record(
        self,
        *,
        kind: str,
        text: str,
        tags: Optional[Sequence[str]] = None,
        ts: Optional[int] = None,
        meta: Optional[dict[str, Any]] = None,
        record_id: Optional[str] = None,
    ) -> None:
        """POST a single typed record. Swallows all errors silently."""
        item: dict[str, Any] = {
            "kind": kind,
            "text": text,
            "tags": list(tags or []),
            "ts": int(ts) if ts is not None else int(time.time() * 1000),
            "meta": dict(meta or {}),
        }
        if record_id:
            item["id"] = record_id
        if self.ttl_days:
            item["ttlDays"] = self.ttl_days
        path = f"/v1/records/{quote(self.namespace, safe='')}"
        try:
            self._client.post(path, json={"items": [item]})
        except Exception:
            # Never break the caller.
            pass


def make_recorder(
    *,
    api_key: Optional[str],
    namespace: str = "",
    ttl_days: Optional[int] = None,
    base_url: Optional[str] = None,
) -> Recorder:
    """Build a Recorder, resolving API key from env if not passed."""
    key = api_key or os.environ.get("NERUVA_API_KEY")
    return Recorder(
        api_key=key or "",
        namespace=namespace,
        ttl_days=ttl_days,
        base_url=base_url,
    )


def short(s: str, n: int) -> str:
    return s if len(s) <= n else s[:n] + "..."
