"""Anthropic Python SDK auto-record wrapper.

Drop-in: every ``client.messages.create()`` call captures both the user
message and the assistant response into a Neruva Memory namespace.

Synchronous and async (``AsyncAnthropic``) clients are both supported.
Streaming (``messages.stream()``) is not yet recorded -- coming in a
later release.
"""
from __future__ import annotations

import os
import time
import uuid
from typing import Any, Optional, TypeVar

from ._recorder import Recorder, make_recorder, short


C = TypeVar("C")


_USER_PREVIEW = 600
_ASSISTANT_PREVIEW = 1800


def _extract_user_text(messages: Any) -> str:
    """Pull the most recent user-role message text out of a messages list."""
    if not isinstance(messages, list):
        return ""
    for msg in reversed(messages):
        if not isinstance(msg, dict) or msg.get("role") != "user":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
            return " ".join(parts)
        return str(content) if content is not None else ""
    return ""


def _extract_assistant_text(response: Any) -> str:
    """Pull the assistant text out of an Anthropic Messages response."""
    content = getattr(response, "content", None)
    if not content:
        return ""
    parts = []
    for block in content:
        # Object form (anthropic SDK) or dict form (raw API).
        btype = getattr(block, "type", None) or (
            block.get("type") if isinstance(block, dict) else None
        )
        if btype == "text":
            text = getattr(block, "text", None) or (
                block.get("text") if isinstance(block, dict) else None
            )
            if text:
                parts.append(str(text))
    return "\n".join(parts)


def _build_typed_record(
    request_kwargs: dict[str, Any],
    response: Any,
    latency_ms: int,
) -> tuple[str, str, list[str], int, dict[str, Any]]:
    """Return (record_id, text, tags, ts, meta) for one llm_turn."""
    user_text = _extract_user_text(request_kwargs.get("messages"))
    asst_text = _extract_assistant_text(response)
    text = (
        f"USER: {short(user_text, _USER_PREVIEW)}\n\n"
        f"ASSISTANT: {short(asst_text, _ASSISTANT_PREVIEW)}"
    )

    usage = getattr(response, "usage", None)
    input_tokens = getattr(usage, "input_tokens", None) if usage else None
    output_tokens = getattr(usage, "output_tokens", None) if usage else None
    model = request_kwargs.get("model")

    meta: dict[str, Any] = {
        "vendor": "anthropic",
        "model": model,
        "stop_reason": getattr(response, "stop_reason", None),
        "input_tokens": int(input_tokens) if input_tokens is not None else None,
        "output_tokens": int(output_tokens) if output_tokens is not None else None,
        "latency_ms": int(latency_ms),
    }
    meta = {k: v for k, v in meta.items() if v is not None}

    tags = ["anthropic"]
    if model:
        tags.append(str(model))

    rid = f"llm-{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
    ts = int(time.time() * 1000)
    return rid, text, tags, ts, meta


def _wrap_messages_create(client: Any, recorder: Recorder) -> None:
    """Replace client.messages.create with a recording version."""
    original_create = client.messages.create

    def wrapped(**kwargs):
        t0 = time.perf_counter()
        response = original_create(**kwargs)
        latency_ms = int((time.perf_counter() - t0) * 1000)
        try:
            rid, text, tags, ts, meta = _build_typed_record(
                kwargs, response, latency_ms,
            )
            recorder.ingest_record(
                kind="llm_turn", text=text, tags=tags, ts=ts,
                meta=meta, record_id=rid,
            )
        except Exception:
            pass  # never break the caller
        return response

    client.messages.create = wrapped


def _wrap_messages_create_async(client: Any, recorder: Recorder) -> None:
    """Replace AsyncAnthropic client.messages.create with a recording version."""
    original_create = client.messages.create

    async def wrapped(**kwargs):
        t0 = time.perf_counter()
        response = await original_create(**kwargs)
        latency_ms = int((time.perf_counter() - t0) * 1000)
        try:
            rid, text, tags, ts, meta = _build_typed_record(
                kwargs, response, latency_ms,
            )
            recorder.ingest_record(
                kind="llm_turn", text=text, tags=tags, ts=ts,
                meta=meta, record_id=rid,
            )
        except Exception:
            pass
        return response

    client.messages.create = wrapped


def auto_record(
    client: C,
    *,
    namespace: str = "",
    ttl_days: Optional[int] = None,
    neruva_api_key: Optional[str] = None,
    neruva_url: Optional[str] = None,
    index: Optional[str] = None,  # ignored; kept for backwards-compat callers
) -> C:
    """Wrap an Anthropic ``Anthropic`` or ``AsyncAnthropic`` client so every
    ``messages.create()`` call upserts the turn into Neruva Memory.

    The wrapped client behaves identically to the original; recording
    happens as a side-effect via fire-and-forget HTTP POST. Errors in
    recording are swallowed silently and never propagate to the caller.

    Records are written to the typed Records substrate as ``kind="llm_turn"``
    with ``tags=["anthropic", "<model>"]`` and rich ``meta`` (model,
    stop_reason, input_tokens, output_tokens, latency_ms).

    Parameters
    ----------
    client : anthropic.Anthropic or anthropic.AsyncAnthropic
        The client to wrap. The instance is mutated in place; the same
        object is returned for chaining convenience.
    namespace : str, optional
        Neruva Records namespace. Use one per agent (e.g. "main",
        "support-bot", "research"). Defaults to empty string.
    ttl_days : int, optional
        If set, each recorded turn carries an auto-expire timestamp
        and the server-side decay sweep removes records older than N days.
    neruva_api_key : str, optional
        Neruva API key. Falls back to the ``NERUVA_API_KEY`` env var.
    neruva_url : str, optional
        Neruva API base URL. Falls back to the ``NERUVA_URL`` env var
        or ``https://api.neruva.io``.
    index : str, optional
        Ignored. Accepted for backwards compat with the 0.4.x signature
        (records have no concept of a Pinecone-style index).

    Returns
    -------
    The same client instance, with ``messages.create`` wrapped.

    Example
    -------
    >>> import anthropic
    >>> from neruva_record import auto_record
    >>> client = auto_record(
    ...     anthropic.Anthropic(),
    ...     namespace="main", ttl_days=30,
    ... )
    >>> response = client.messages.create(
    ...     model="claude-opus-4-7", max_tokens=200,
    ...     messages=[{"role": "user", "content": "Hi"}],
    ... )
    """
    recorder = make_recorder(
        api_key=neruva_api_key, namespace=namespace,
        ttl_days=ttl_days, base_url=neruva_url,
    )

    # Detect sync vs async by class name -- avoids requiring anthropic
    # to be installed at import time.
    cls_name = type(client).__name__
    if "Async" in cls_name:
        _wrap_messages_create_async(client, recorder)
    else:
        _wrap_messages_create(client, recorder)

    # Stash recorder on the client so users can introspect / close it.
    setattr(client, "_neruva_recorder", recorder)
    return client
