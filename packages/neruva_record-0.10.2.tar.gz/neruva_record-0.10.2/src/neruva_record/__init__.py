"""Neruva auto-record SDK wrappers.

Drop-in observability for LLM clients. Every turn is upserted to a
Neruva Memory namespace as a side-effect, with rich metadata so you
can recall, replay, and audit later.

Currently supported:

    auto_record(client, ...)   Anthropic Python SDK (sync + async)

More vendors (OpenAI, Google, xAI/Mistral) ship in subsequent releases.

Quick start:

    import anthropic
    from neruva_record import auto_record

    client = auto_record(
        anthropic.Anthropic(),
        index="brain",
        namespace="main",
        ttl_days=30,        # optional: auto-expire records after N days
    )

    # client behaves identically to bare Anthropic; recording is a side-effect
    response = client.messages.create(
        model="claude-opus-4-7",
        max_tokens=200,
        messages=[{"role": "user", "content": "Hi!"}],
    )

Set ``NERUVA_API_KEY`` in the environment, or pass ``neruva_api_key=...``.
"""
from __future__ import annotations

from .anthropic import auto_record

__all__ = ["auto_record"]
__version__ = "0.7.0"
