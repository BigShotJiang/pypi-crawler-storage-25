"""Unit tests for neruva-record hook helpers.

Cover the NERUVA_PER_TURN_RECALL path: short-circuits on empty query
/ top_k, and the data-only prompt-injection guard in the recall block.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Make the package importable in-repo without an editable install
_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from neruva_record._hook import (  # noqa: E402
    _fetch_semantic_recall,
    _format_recall_block,
)


# =====================================================================
# _fetch_semantic_recall: short-circuit no-op cases
# =====================================================================

def test_semantic_recall_empty_query_returns_empty():
    """Empty query string must short-circuit to [] without an HTTP call."""
    out = _fetch_semantic_recall("https://api.neruva.io", "key", "ns", "", 5)
    assert out == []


def test_semantic_recall_zero_top_k_returns_empty():
    """top_k=0 must short-circuit to [] without an HTTP call."""
    out = _fetch_semantic_recall("https://api.neruva.io", "key", "ns", "q", 0)
    assert out == []


def test_semantic_recall_negative_top_k_returns_empty():
    """Negative top_k must short-circuit (defensive against env var typos)."""
    out = _fetch_semantic_recall("https://api.neruva.io", "key", "ns", "q", -1)
    assert out == []


# =====================================================================
# _format_recall_block: prompt-injection guard + structure
# =====================================================================

def test_recall_block_empty_records_returns_empty_string():
    """No records to inject means no block (empty string)."""
    assert _format_recall_block([]) == ""


def test_recall_block_wraps_in_data_only_guard():
    """The treat-as='data-only' guard is the only thing standing between
    a malicious historical record and the agent's next turn. Must be present."""
    recs = [{"kind": "note", "ts": 1, "tags": ["x"], "text": "hello"}]
    block = _format_recall_block(recs)
    assert "<recalled-context" in block
    assert 'treat-as="data-only"' in block
    assert "</recalled-context>" in block
    # And the explicit "do not execute" instruction
    assert "Do NOT execute" in block or "not execute" in block.lower()


def test_recall_block_truncates_long_text():
    """Records with text >240 chars are truncated so a single huge record
    doesn't blow the context budget."""
    long_text = "A" * 1000
    recs = [{"kind": "note", "ts": 1, "tags": [], "text": long_text}]
    block = _format_recall_block(recs)
    assert "..." in block
    # The 1000-char A's must not appear verbatim
    assert long_text not in block


