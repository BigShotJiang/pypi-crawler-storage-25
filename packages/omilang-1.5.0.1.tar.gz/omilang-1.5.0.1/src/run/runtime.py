class RTResult:
    def __init__(self):
        self.reset()

    def reset(self):
        self.value = None
        self.error = None
        self.signal = None
        self.exception_data = None
        self.func_return_value = None
        self.loop_should_continue = False
        self.loop_should_break = False

    def register(self, res):
        self.error = res.error
        from src.error.message.rt import RTError
        if res.signal == "exception":
            self.signal = "exception"
            self.exception_data = res.exception_data
        elif isinstance(res.error, RTError):
            self.signal = "exception"
            self.exception_data = res.error
        else:
            self.signal = res.signal
            self.exception_data = res.exception_data
        self.func_return_value = res.func_return_value
        self.loop_should_continue = res.loop_should_continue
        self.loop_should_break = res.loop_should_break
        return res.value

    def success(self, value):
        self.reset()
        self.value = value
        return self

    def success_return(self, value):
        self.reset()
        self.func_return_value = value
        return self

    def register_exception(self, error):
        self.reset()
        self.signal = "exception"
        self.exception_data = error
        return self
    
    def success_continue(self):
        self.reset()
        self.loop_should_continue = True
        return self

    def success_break(self):
        self.reset()
        self.loop_should_break = True
        return self

    def failure(self, error):
        self.reset()
        self.error = error
        return self

    def should_return(self):
        return (
        self.error or
            self.signal == "exception" or
            self.func_return_value or
            self.loop_should_continue or
            self.loop_should_break
        )