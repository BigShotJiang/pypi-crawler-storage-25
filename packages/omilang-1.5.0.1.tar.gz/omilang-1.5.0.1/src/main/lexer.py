from src.var.token import *
from src.var.constant import LETTERS
from src.var.constant import *
from src.var.keyword import get_keywords_for_file
from src.tokens import Token
from src.error.message.invalidsyntax import InvalidSyntaxError
from src.error.message.illegalchar import IllegalCharError
from src.error.message.expectedchar import ExpectedCharError
from src.position import Position
from src.var.token import TT_QUESTION, TT_NULLCOAL


class Lexer():
    def __init__(self, fn, text):
        self.fn = fn
        self.text = text
        self.keywords = set(get_keywords_for_file(fn))
        self.pos = Position(-1, 0, -1, fn, text)
        self.current_char = None
        self.advance()

    def advance(self):
        self.pos.advance(self.current_char)
        self.current_char = self.text[self.pos.idx] if self.pos.idx < len(self.text) else None

    def make_tokens(self):
        tokens = []

        while self.current_char != None:
            if self.current_char in " \t":
                self.advance()
            elif self.current_char in ";\n":
                tokens.append(Token(TT_NEWLINE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "/" and self.pos.idx + 1 < len(self.text) and self.text[self.pos.idx + 1] == "/":
                self.skip_comment()
            elif self.current_char in DIGITS:
                tokens.append(self.make_number())
            elif self.current_char in LETTERS or self.current_char == "_":
                tokens.append(self.make_identifier())
            elif self.current_char == '"':
                string_tok, error = self.make_string()
                if error:
                    return [], error
                tokens.append(string_tok)
            elif self.current_char == "+":
                tokens.append(Token(TT_PLUS, pos_start=self.pos))
                self.advance()
            elif self.current_char == "-":
                tokens.append(self.make_minus_or_arrow())
            elif self.current_char == "*":
                tokens.append(Token(TT_MUL, pos_start=self.pos))
                self.advance()
            elif self.current_char == "/":
                tokens.append(Token(TT_DIV, pos_start=self.pos))
                self.advance()
            elif self.current_char == "^":
                tokens.append(Token(TT_POW, pos_start=self.pos))
                self.advance()
            elif self.current_char == "(":
                tokens.append(Token(TT_LPAREN, pos_start=self.pos))
                self.advance()
            elif self.current_char == ")":
                tokens.append(Token(TT_RPAREN, pos_start=self.pos))
                self.advance()
            elif self.current_char == "[":
                tokens.append(Token(TT_LSQUARE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "]":
                tokens.append(Token(TT_RSQUARE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "{":
                tokens.append(Token(TT_LBRACE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "}":
                tokens.append(Token(TT_RBRACE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "!":
                tok, error = self.make_not_equals()
                if error:
                    return [], error
                tokens.append(tok)
            elif self.current_char == "=":
                tokens.append(self.make_equals())
            elif self.current_char == "<":
                tokens.append(self.make_less_than())
            elif self.current_char == ">":
                tokens.append(self.make_greater_than())
            elif self.current_char == ",":
                tokens.append(Token(TT_COMMA, pos_start=self.pos))
                self.advance()
            elif self.current_char == "|":
                tokens.append(Token(TT_PIPE, pos_start=self.pos))
                self.advance()
            elif self.current_char == ":":
                tokens.append(Token(TT_COLON, pos_start=self.pos))
                self.advance()
            elif self.current_char == ".":
                tokens.append(Token(TT_DOT, pos_start=self.pos))
                self.advance()
            elif self.current_char == "@":
                tokens.append(Token(TT_AT, pos_start=self.pos))
                self.advance()
            elif self.current_char == "~":
                tokens.append(Token(TT_TILDE, pos_start=self.pos))
                self.advance()
            elif self.current_char == "?":
                tokens.append(self.make_question_or_nullcoal())
            else:
                pos_start = self.pos.copy()
                char = self.current_char
                self.advance()
                return [], IllegalCharError(pos_start, self.pos, f"Unsupported character {char!r}")

        tokens.append(Token(TT_E0F, pos_start=self.pos))
        return tokens, None

    def make_number(self):
        num_str = ""
        dot_count = 0
        pos_start = self.pos.copy()

        while self.current_char != None and self.current_char in DIGITS + ".":
            if self.current_char == ".":
                if dot_count == 1:
                    break
                dot_count += 1
                num_str += "."
            else:
                num_str += self.current_char
            self.advance()

        if dot_count == 0:
            return Token(TT_INT, int(num_str), pos_start, self.pos)
        return Token(TT_FLOAT, float(num_str), pos_start, self.pos)

    def make_string(self):
        string = ""
        pos_start = self.pos.copy()
        escape_character = False
        has_interp = False
        interp_depth = 0
        inner_str_quote = None
        inner_escape = False
        closed_quote = False
        self.advance()

        while self.current_char is not None:
            ch = self.current_char

            if inner_str_quote is not None:
                if inner_escape:
                    inner_escape = False
                    string += ch
                elif ch == '\\':
                    inner_escape = True
                    string += ch
                elif ch == inner_str_quote:
                    inner_str_quote = None
                    string += ch
                else:
                    string += ch
                self.advance()
                continue

            if interp_depth > 0:
                if ch == '(':
                    interp_depth += 1
                    string += ch
                elif ch == ')':
                    interp_depth -= 1
                    string += ch
                elif ch in ('"', "'"):
                    inner_str_quote = ch
                    string += ch
                else:
                    string += ch
                self.advance()
                continue

            if escape_character:
                if ch == '~':
                    string += "\x00TILDE\x00"
                elif ch == 'n':
                    string += '\n'
                elif ch == 't':
                    string += '\t'
                else:
                    string += ch
                escape_character = False
                self.advance()
            elif ch == '\\':
                escape_character = True
                self.advance()
            elif ch == '"':
                closed_quote = True
                break
            elif ch == '~':
                has_interp = True
                string += '~'
                self.advance()
                if self.current_char == '(':
                    string += '('
                    interp_depth = 1
                    self.advance()
            else:
                string += ch
                self.advance()

        if not closed_quote:
            return None, InvalidSyntaxError(
                pos_start,
                self.pos,
                'String literal is missing closing "',
            )

        self.advance()
        tok_type = TT_FSTRING if has_interp else TT_STRING
        return Token(tok_type, string, pos_start, self.pos), None

    def make_identifier(self):
        id_str = ""
        pos_start = self.pos.copy()

        while self.current_char != None and self.current_char in LETTERS_DIGITS + "_":
            id_str += self.current_char
            self.advance()

        tok_type = TT_KEYWORD if id_str in self.keywords else TT_IDENTIFIER
        return Token(tok_type, id_str, pos_start, self.pos)

    def make_not_equals(self):
        pos_start = self.pos.copy()
        self.advance()

        if self.current_char == "=":
            self.advance()
            return Token(TT_NE, pos_start=pos_start, pos_end=self.pos), None

        self.advance()
        return None, ExpectedCharError(pos_start, self.pos, "Expected '=' after '!' to form '!='")

    def make_minus_or_arrow(self):
        tok_type = TT_MINUS
        pos_start = self.pos.copy()
        self.advance()

        if self.current_char == ">":
            self.advance()
            tok_type = TT_ARROW

        return Token(tok_type, pos_start=pos_start, pos_end=self.pos)

    def make_question_or_nullcoal(self):
        pos_start = self.pos.copy()
        self.advance()
        if self.current_char == "?":
            self.advance()
            return Token(TT_NULLCOAL, pos_start=pos_start, pos_end=self.pos)
        return Token(TT_QUESTION, pos_start=pos_start, pos_end=self.pos)

    def make_equals(self):
        tok_type = TT_EQ
        pos_start = self.pos.copy()
        self.advance()

        if self.current_char == "=":
            self.advance()
            tok_type = TT_EE

        return Token(tok_type, pos_start=pos_start, pos_end=self.pos)

    def make_less_than(self):
        tok_type = TT_LT
        pos_start = self.pos.copy()
        self.advance()

        if self.current_char == "=":
            self.advance()
            tok_type = TT_LTE

        return Token(tok_type, pos_start=pos_start, pos_end=self.pos)

    def make_greater_than(self):
        tok_type = TT_GT
        pos_start = self.pos.copy()
        self.advance()

        if self.current_char == "=":
            self.advance()
            tok_type = TT_GTE

        return Token(tok_type, pos_start=pos_start, pos_end=self.pos)

    def skip_comment(self):
        self.advance()

        while self.current_char is not None and self.current_char != '\n':
            self.advance()

        if self.current_char == '\n':
            self.advance()
