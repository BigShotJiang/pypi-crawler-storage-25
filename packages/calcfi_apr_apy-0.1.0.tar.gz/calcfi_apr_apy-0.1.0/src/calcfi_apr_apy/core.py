"""calcfi-apr-apy — APR to APY conversion with any compounding frequency.

APY = (1 + APR/n)^n - 1
APR = n * [(1 + APY)^(1/n) - 1]
Continuous compounding: APY = e^APR - 1

License: MIT. Author: Jere Salmisto. https://calcfi.app
"""
import math
from typing import Union

__version__ = "0.1.0"
Number = Union[int, float]

def apr_to_apy(apr: Number, periods_per_year: int = 12) -> float:
    """Convert APR to APY for given compounding frequency.

    Args:
        apr: Annual Percentage Rate as decimal (e.g., 0.06 for 6%).
        periods_per_year: Compounding periods (12=monthly, 365=daily, 1=annual).

    Returns:
        APY as decimal.

    Examples:
        >>> round(apr_to_apy(0.06, 12), 6)
        0.061678
    """
    return (1 + apr / periods_per_year) ** periods_per_year - 1

def apy_to_apr(apy: Number, periods_per_year: int = 12) -> float:
    """Convert APY to APR for given compounding frequency."""
    return periods_per_year * ((1 + apy) ** (1 / periods_per_year) - 1)

def apr_to_apy_continuous(apr: Number) -> float:
    """Convert APR to APY assuming continuous compounding."""
    return math.exp(apr) - 1
