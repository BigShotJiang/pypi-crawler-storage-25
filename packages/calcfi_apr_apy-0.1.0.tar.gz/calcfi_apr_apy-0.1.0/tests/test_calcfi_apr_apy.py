from calcfi_apr_apy import apr_to_apy, apy_to_apr, apr_to_apy_continuous

def test_apr_to_apy_monthly():
    assert abs(apr_to_apy(0.06, 12) - 0.061678) < 0.0001

def test_apy_to_apr_monthly():
    assert abs(apy_to_apr(0.061678, 12) - 0.06) < 0.0001

def test_continuous():
    assert abs(apr_to_apy_continuous(0.06) - 0.0618365) < 0.0001
