#!/usr/bin/env python3
# vim: fileencoding=utf8
# SPDXVersion: SPDX-2.3
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: © Copyright 2023, 2024, 2026 by Christian Dönges
# SPDXID: SPDXRef-init-py

__title__ = "pymisclib"
__description__ = "Collection of helpful stuff."
__url__ = "https://rot.regenbogenkraut.de/cd/pymisclib"
__author__ = "Christian Dönges"
__author_email__ = "cd.pymisclib@platypus-projects.net"
__license__ = "Apache 2.0"
__copyright__ = "© Copyright 2012-2026 by Christian Dönges" +\
                " <cd.pymisclib@platypus-projects.net>"

from .__version__ import __version__ as __version__
from .__version__ import __version_tuple__ as __version_tuple__
