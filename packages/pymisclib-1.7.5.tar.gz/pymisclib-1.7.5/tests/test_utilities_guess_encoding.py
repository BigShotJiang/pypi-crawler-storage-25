#!/usr/bin/env python3
# vim: fileencoding=utf-8 ts=4
# SPDX-License-Identifier: AGPL-3.0-or-later
# SPDX-FileCopyrightText: © Copyright 2026 by Christian Dönges. All rights reserved.
# SPDXID: SPDXRef-test-utilities-guess-encoding-py
"""Test utilities.guess_encoding()."""

import pytest
from pymisclib.utilities import guess_encoding


encoding_test_vectors = [
    (None, b'\x3c\x3f\x78\x6d', 'utf8'),
    ('utf-8-sig', b'\xef\xbb\xbf\x3c', 'utf8_bom'),
    (None, b'\x00\x3c\x00\x3f', 'utf16_be'),
    ('utf-16-be', b'\xfe\xff\x00\x3c', 'utf16_be_bom'),
    (None, b'\x3c\x00\x3f\x00', 'utf16_le'),
    ('utf-16-le', b'\xff\xfe\x3c\x00', 'utf16_le_bom'),
    (None, b'\x00\x00\x00\x3c', 'utf32_be'),
    ('utf-32-be', b'\x00\x00\xfe\xff', 'utf32_be_bom'),
    (None, b'\x3c\x00\x00\x00', 'utf32_le'),
    ('utf-32-le', b'\xff\xfe\x00\x00', 'utf32_le_bom'),
    (None, b'abcd', 'ascii'),
]  # encoding_test_vectors


@pytest.mark.parametrize("expected_encoding,binary,comment", encoding_test_vectors)
def test_guess_encoding(expected_encoding, binary, comment):
    guessed_encoding = guess_encoding(binary)
    assert guessed_encoding == expected_encoding
