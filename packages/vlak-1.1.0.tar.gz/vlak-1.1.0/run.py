#!/usr/bin/env python3
from vlak.vlak import main

if __name__ == '__main__':
    main()
