import os
import arcade
from arcade.types import LBWH
from .constants import TILE_SIZE, GRID_W, GRID_H, is_collectible, Tile


class Renderer:
    def __init__(self, res_path: str, win_w: int, win_h: int, scale: int):
        self._win_w  = win_w
        self._win_h  = win_h
        self._scale  = scale
        self._T      = TILE_SIZE * scale
        self._cache: dict[tuple, arcade.Texture] = {}

        def sheet(name: str) -> arcade.SpriteSheet:
            return arcade.SpriteSheet(os.path.join(res_path, 'img', name))

        self._loko_sheet     = sheet('loko.png')
        self._loko_bum_sheet = sheet('loko-bum.png')
        self._stena_sheet    = sheet('stena.png')
        self._vrata_sheet    = sheet('vrata.png')
        self._veci_sheet     = sheet('veci-vagony.png')

        try:
            arcade.load_font(os.path.join(res_path, 'fonts', 'pixel.ttf'))
        except Exception:
            pass

        # Cached HUD Text objects — creating Text() each frame is expensive
        # (glyph layout + GPU buffer alloc). We update .text in place instead.
        s = scale
        font_size = 8 * s
        self._txt_password = arcade.Text(
            '', 33 * s, win_h - 17 * s, arcade.color.WHITE, font_size)
        self._txt_steps = arcade.Text(
            '', win_w - 37 * s, win_h - 17 * s, arcade.color.WHITE, font_size,
            anchor_x='right')
        self._txt_collected = arcade.Text(
            '', win_w - 37 * s, win_h - 29 * s, arcade.color.WHITE, font_size,
            anchor_x='right')
        self._txt_press_enter = arcade.Text(
            'STLAC ENTER', 33 * s, win_h - 29 * s,
            arcade.color.YELLOW, font_size)
        self._txt_input = arcade.Text(
            '', 33 * s, win_h - 29 * s, arcade.color.WHITE, font_size)

        # Map rendering: a single SpriteList replaces ~240 per-frame draw
        # calls. Sprites are kept in row-major order; we update textures
        # only when a tile value or animation frame actually changes.
        self._map_sprites: arcade.SpriteList = arcade.SpriteList()
        self._map_cells: list[list[arcade.Sprite]] = []
        self._cached_tiles: list[list[int]] = []
        self._mapa_id: int | None = None
        self._last_anim: int = -1
        self._last_door_anim: int = -1

        # Train rendering: single SpriteList holds wagons (in reverse
        # visual order) followed by the loko, so one draw call covers the
        # whole train with correct z-order. Rebuilt only when the wagon
        # count changes (collect or level load).
        self._train_sprites: arcade.SpriteList = arcade.SpriteList()
        self._wagon_refs: list[arcade.Sprite] = []
        self._loko_sprite: arcade.Sprite | None = None
        self._wagon_count: int = -1

    # ------------------------------------------------------------------
    # Texture cache
    # ------------------------------------------------------------------

    def _tex(self, sheet: arcade.SpriteSheet, col: int, row: int) -> arcade.Texture:
        key = (id(sheet), col, row)
        if key not in self._cache:
            T = TILE_SIZE
            self._cache[key] = sheet.get_texture(
                LBWH(col * T, row * T, T, T))
        return self._cache[key]

    # ------------------------------------------------------------------
    # Main draw
    # ------------------------------------------------------------------

    def draw(self, state: 'GameState') -> None:
        self._draw_map(state)
        self._draw_train(state)
        self._draw_hud(state)

    def _tile_texture(self, tile: int, anim: int,
                      door_anim: int) -> arcade.Texture:
        if tile == Tile.WALL:
            return self._tex(self._stena_sheet, 1, 0)
        if is_collectible(tile):
            return self._tex(self._veci_sheet, anim, tile - 100)
        if tile == Tile.DOOR:
            return self._tex(self._vrata_sheet, door_anim, 0)
        return self._tex(self._stena_sheet, 0, 0)

    def _build_map(self, state: 'GameState') -> None:
        self._map_sprites = arcade.SpriteList()
        self._map_cells = []
        self._cached_tiles = []
        T = self._T
        half = T / 2
        for j in range(GRID_H):
            row_sprites: list[arcade.Sprite] = []
            row_tiles: list[int] = []
            for i in range(GRID_W):
                v = state.mapa[j][i]
                tex = self._tile_texture(v, state.anim, state.door_anim)
                cx = i * T + half
                cy = self._win_h - j * T - half
                sprite = arcade.Sprite(
                    tex, scale=self._scale, center_x=cx, center_y=cy)
                self._map_sprites.append(sprite)
                row_sprites.append(sprite)
                row_tiles.append(v)
            self._map_cells.append(row_sprites)
            self._cached_tiles.append(row_tiles)
        self._mapa_id = id(state.mapa)
        self._last_anim = state.anim
        self._last_door_anim = state.door_anim

    def _draw_map(self, state: 'GameState') -> None:
        if id(state.mapa) != self._mapa_id:
            self._build_map(state)
        else:
            anim_changed = state.anim != self._last_anim
            door_changed = state.door_anim != self._last_door_anim
            anim = state.anim
            door_anim = state.door_anim
            for j in range(GRID_H):
                row = state.mapa[j]
                cached_row = self._cached_tiles[j]
                sprite_row = self._map_cells[j]
                for i in range(GRID_W):
                    v = row[i]
                    if v != cached_row[i]:
                        sprite_row[i].texture = self._tile_texture(
                            v, anim, door_anim)
                        cached_row[i] = v
                    elif anim_changed and is_collectible(v):
                        sprite_row[i].texture = self._tex(
                            self._veci_sheet, anim, v - 100)
                    elif door_changed and v == Tile.DOOR:
                        sprite_row[i].texture = self._tex(
                            self._vrata_sheet, door_anim, 0)
            self._last_anim = anim
            self._last_door_anim = door_anim
        self._map_sprites.draw(pixelated=True)

    def _loko_texture(self, state: 'GameState') -> arcade.Texture:
        if state.crash_anim >= 100:
            return self._tex(self._loko_sheet, state.anim, state.train.loko_dir)
        return self._tex(self._loko_bum_sheet, state.crash_anim, 0)

    def _build_train(self, state: 'GameState') -> None:
        self._train_sprites = arcade.SpriteList()
        self._wagon_refs = []
        train = state.train
        n = len(train.wagons)
        # Reverse order so spritelist[0] = wagon[n-1] (back),
        # spritelist[n-1] = wagon[0] (front near loko).
        for k in range(n):
            w = train.wagons[n - 1 - k]
            tex = self._tex(self._veci_sheet, w.direction + 3, w.cargo)
            sprite = arcade.Sprite(tex, scale=self._scale)
            self._train_sprites.append(sprite)
            self._wagon_refs.append(sprite)
        loko_tex = self._loko_texture(state)
        self._loko_sprite = arcade.Sprite(loko_tex, scale=self._scale)
        self._train_sprites.append(self._loko_sprite)
        self._wagon_count = n

    def _draw_train(self, state: 'GameState') -> None:
        train = state.train
        n = len(train.wagons)
        if n != self._wagon_count:
            self._build_train(state)
        T = self._T
        half = T / 2
        sub = state.sub_step
        win_h = self._win_h
        prev = train.prev_wagons
        prev_n = len(prev)
        veci = self._veci_sheet
        # Wagons
        for k in range(n):
            i = n - 1 - k
            w = train.wagons[i]
            if i < prev_n:
                pw = prev[i]
                px = (pw.x + (w.x - pw.x) * sub) * T
                py = (pw.y + (w.y - pw.y) * sub) * T
            else:
                px = w.x * T
                py = w.y * T
            sprite = self._wagon_refs[k]
            new_pos = (px + half, win_h - py - half)
            if sprite.position != new_pos:
                sprite.position = new_pos
            new_tex = self._tex(veci, w.direction + 3, w.cargo)
            if sprite.texture is not new_tex:
                sprite.texture = new_tex
        # Loko
        sprite = self._loko_sprite
        px = (train.prev_x + (train.loko_x - train.prev_x) * sub) * T
        py = (train.prev_y + (train.loko_y - train.prev_y) * sub) * T
        new_pos = (px + half, win_h - py - half)
        if sprite.position != new_pos:
            sprite.position = new_pos
        new_tex = self._loko_texture(state)
        if sprite.texture is not new_tex:
            sprite.texture = new_tex
        self._train_sprites.draw(pixelated=True)

    def _draw_hud(self, state: 'GameState') -> None:
        if state.current_level_password:
            new_text = f'HESLO: {state.current_level_password}'
            if self._txt_password.text != new_text:
                self._txt_password.text = new_text
            self._txt_password.draw()
        elif state.show_password:
            new_text = f'HESLO: {state.level_password}'
            if self._txt_password.text != new_text:
                self._txt_password.text = new_text
            self._txt_password.draw()

        if not state.auto_pilot:
            steps_text = f'{state.steps}'
            if self._txt_steps.text != steps_text:
                self._txt_steps.text = steps_text
            self._txt_steps.draw()
            if state.total_collectibles:
                col_text = f'{state.collected}/{state.total_collectibles}'
                if self._txt_collected.text != col_text:
                    self._txt_collected.text = col_text
                self._txt_collected.draw()

        if state.auto_pilot:
            self._txt_press_enter.draw()
        elif state.input_buffer:
            if self._txt_input.text != state.input_buffer:
                self._txt_input.text = state.input_buffer
            self._txt_input.draw()
