import os
import arcade


def main() -> None:
    res_path = os.path.join(os.path.dirname(__file__), 'res')
    res_path = os.path.abspath(res_path)

    from .game import Game
    game = Game(res_path)

    if os.environ.get('VLAK_PROFILE'):
        _run_profiled()
    else:
        arcade.run()


def _run_profiled() -> None:
    import cProfile
    import pstats

    out_path = os.environ.get('VLAK_PROFILE_OUT', 'vlak.prof')
    profiler = cProfile.Profile()
    profiler.enable()
    try:
        arcade.run()
    finally:
        profiler.disable()
        profiler.dump_stats(out_path)
        stats = pstats.Stats(profiler).strip_dirs()
        print(f'\n=== profile saved to {out_path} ===')
        print('\n--- top 30 by cumulative time ---')
        stats.sort_stats('cumulative').print_stats(30)
        print('\n--- top 30 by total time ---')
        stats.sort_stats('tottime').print_stats(30)


if __name__ == '__main__':
    main()
