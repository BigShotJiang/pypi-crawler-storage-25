from dataclasses import dataclass, field
from .constants import RIGHT, STOP


@dataclass
class Wagon:
    x: int
    y: int
    direction: int
    cargo: int


@dataclass
class Train:
    loko_x: int
    loko_y: int
    loko_dir: int = RIGHT
    direction: int = STOP
    wagons: list[Wagon] = field(default_factory=list)

    # previous positions for smooth interpolation
    prev_x: int = 0
    prev_y: int = 0
    prev_wagons: list[Wagon] = field(default_factory=list)

    def snapshot(self) -> None:
        self.prev_x = self.loko_x
        self.prev_y = self.loko_y
        self.prev_wagons = [Wagon(w.x, w.y, w.direction, w.cargo) for w in self.wagons]

    def collides_with_self(self, x: int, y: int) -> bool:
        if self.wagons and x == self.wagons[0].x and y == self.wagons[0].y:
            return True
        for i in range(2, len(self.wagons) - 1):
            if x == self.wagons[i].x and y == self.wagons[i].y:
                return True
        return False
