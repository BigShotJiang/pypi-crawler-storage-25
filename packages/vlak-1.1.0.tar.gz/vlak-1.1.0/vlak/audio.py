import os
import arcade


class AudioManager:
    LOKO  = 0
    BELL  = 1
    HORN  = 2
    CRASH = 3
    WAGON = 4

    def __init__(self, res_path: str):
        self._sounds: dict[int, arcade.Sound] = {}
        pairs = [
            (self.LOKO,  'sounds/loko.wav'),
            (self.BELL,  'sounds/bell.wav'),
            (self.HORN,  'sounds/horn.wav'),
            (self.CRASH, 'sounds/crash.wav'),
            (self.WAGON, 'sounds/vagon.wav'),
        ]
        for index, rel in pairs:
            path = os.path.join(res_path, rel)
            if os.path.exists(path):
                try:
                    self._sounds[index] = arcade.Sound(path)
                except Exception as e:
                    print(f'Sound load failed {path}: {e}')

    def play(self, index: int, silent: bool = False) -> None:
        if silent:
            return
        sound = self._sounds.get(index)
        if sound:
            try:
                sound.play()
            except Exception:
                pass
