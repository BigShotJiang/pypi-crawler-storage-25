import time
import arcade
from arcade import key as AKey
from .constants import (
    GRID_W, GRID_H, TILE_SIZE, BASE_W, BASE_H,
    STEP_MS, ANIM_MS,
    RIGHT, UP, LEFT, DOWN, STOP,
    Tile, is_collectible,
)
from .levels import LEVELS, PASSWORDS
from .train import Train, Wagon
from .audio import AudioManager
from .renderer import Renderer
from . import autopilot


class GameState:
    def __init__(self):
        self.mapa: list[list[int]] = []
        self.train: Train = Train(0, 0)
        self.anim: int = 0
        self.door_anim: int = 0
        self.crash_anim: int = 100
        self.sub_step: float = 1.0
        self.show_password: bool = False
        self.level_password: str = ''
        self.current_level_password: str = ''
        self.auto_pilot: bool = False
        self.input_buffer: str = ''
        self.steps: int = 0
        self.collected: int = 0
        self.total_collectibles: int = 0


class Game(arcade.Window):
    def __init__(self, res_path: str, scale: int = 2):
        win_w = BASE_W * scale
        win_h = BASE_H * scale
        super().__init__(win_w, win_h, 'Vlak',
                         antialiasing=False, vsync=True)
        self.set_mouse_visible(False)

        self._scale     = scale
        self._res_path  = res_path
        self._audio     = AudioManager(res_path)
        self._renderer  = Renderer(res_path, win_w, win_h, scale)
        self._state     = GameState()

        self._scene      = 0
        self._queued_dir = STOP
        self._last_step  = 0.0   # ms
        self._last_anim  = 0.0   # ms
        self._keys_held: set = set()

        self._load_scene(0)

    @staticmethod
    def _now() -> float:
        return time.perf_counter() * 1000.0

    # ------------------------------------------------------------------
    # Scene
    # ------------------------------------------------------------------

    def _load_scene(self, index: int) -> None:
        self._scene = index
        raw = LEVELS[index]
        state = self._state

        state.mapa = [row[:] for row in raw]
        state.anim = 0
        state.door_anim = 0
        state.crash_anim = 100
        current_pw = PASSWORDS[index - 1] if 0 < index <= len(PASSWORDS) else ''
        next_pw = PASSWORDS[index] if index < len(PASSWORDS) else ''
        state.auto_pilot = (index == 0)
        state.show_password = False
        state.level_password = next_pw
        state.current_level_password = current_pw
        state.input_buffer = ''
        state.steps = 0
        state.collected = 0
        state.total_collectibles = sum(
            is_collectible(state.mapa[j][i])
            for j in range(GRID_H) for i in range(GRID_W))

        lx, ly = 0, 0
        for j in range(GRID_H):
            for i in range(GRID_W):
                if state.mapa[j][i] == Tile.LOKO:
                    state.mapa[j][i] = Tile.EMPTY
                    lx, ly = i, j

        state.train = Train(loko_x=lx, loko_y=ly)
        state.train.prev_x = lx
        state.train.prev_y = ly
        state.sub_step = 1.0
        self._queued_dir = STOP
        self._last_step = 0.0
        self._last_anim = self._now()

    # ------------------------------------------------------------------
    # Arcade callbacks
    # ------------------------------------------------------------------

    def on_draw(self) -> None:
        self.clear((0, 0, 0))
        self._renderer.draw(self._state)

    def on_update(self, delta_time: float) -> None:
        self._update()

    def on_key_press(self, key: int, modifiers: int) -> None:
        state = self._state

        if state.auto_pilot and key in (AKey.SPACE, AKey.RETURN):
            self._load_scene(1)
            return

        if key == AKey.ESCAPE:
            self.close()
            return

        if modifiers & AKey.MOD_ALT:
            scale_map = {AKey.KEY_1: 1, AKey.KEY_2: 2, AKey.KEY_3: 3, AKey.KEY_4: 4}
            if key in scale_map:
                self._set_scale(scale_map[key])
            return

        dir_map = {
            AKey.RIGHT: RIGHT, AKey.LEFT: LEFT,
            AKey.UP:    UP,    AKey.DOWN: DOWN,
        }
        if key in dir_map:
            self._queued_dir = dir_map[key]
            return

        if key in (AKey.RETURN, AKey.SPACE):
            self._handle_confirm()
            return

        if key == AKey.BACKSPACE:
            if state.input_buffer:
                state.input_buffer = state.input_buffer[:-1]
            return

        if AKey.A <= key <= AKey.Z and key not in self._keys_held:
            self._keys_held.add(key)
            if len(state.input_buffer) >= 5:
                state.input_buffer = ''
            state.input_buffer += chr(key - AKey.A + ord('A'))

    def on_key_release(self, key: int, modifiers: int) -> None:
        self._keys_held.discard(key)

    # ------------------------------------------------------------------
    # Input helpers
    # ------------------------------------------------------------------

    def _handle_confirm(self) -> None:
        state = self._state
        buf = state.input_buffer
        if buf:
            for i, pw in enumerate(PASSWORDS):
                if buf == pw:
                    self._load_scene(i + 1)
                    break
            state.input_buffer = ''
        elif state.show_password and self._scene < len(LEVELS) - 1:
            self._load_scene(self._scene + 1)
        else:
            self._load_scene(self._scene)

    def _set_scale(self, scale: int) -> None:
        scale = max(1, min(4, scale))
        self._scale = scale
        self.set_size(BASE_W * scale, BASE_H * scale)
        self._renderer = Renderer(
            self._res_path, BASE_W * scale, BASE_H * scale, scale)

    # ------------------------------------------------------------------
    # Update loop
    # ------------------------------------------------------------------

    def _update(self) -> None:
        now   = self._now()
        state = self._state
        train = state.train

        # animation tick
        if now - self._last_anim >= ANIM_MS:
            self._last_anim += ANIM_MS
            state.anim = (state.anim + 1) % 3
            if state.door_anim and state.door_anim < 5:
                state.door_anim += 1
            if state.crash_anim < 100:
                state.crash_anim += 1
                if state.crash_anim == 10:
                    state.crash_anim = 7

        # auto-advance demo scene
        if state.auto_pilot and state.show_password and state.sub_step >= 1.0:
            self._load_scene(1)
            return

        crashed = state.crash_anim < 100

        if crashed or state.show_password:
            if state.show_password and state.sub_step < 1.0:
                state.sub_step = (now - self._last_step) / STEP_MS
                if state.sub_step > 1.0:
                    state.sub_step = 1.0
            else:
                self._last_step = now
                state.sub_step = 1.0
                train.prev_x = train.loko_x
                train.prev_y = train.loko_y
            return

        if state.auto_pilot:
            self._queued_dir = autopilot.auto_direction(
                train.loko_x, train.loko_y,
                state.mapa, train.wagons,
                bool(state.door_anim), train.direction)

        if train.direction == STOP:
            if self._queued_dir != STOP:
                train.direction = self._queued_dir
                self._queued_dir = STOP
                train.snapshot()
                self._step()
                state.sub_step = 0.0
                self._last_step = now
        else:
            state.sub_step = (now - self._last_step) / STEP_MS
            if state.sub_step >= 1.0:
                if self._queued_dir != STOP:
                    train.direction = self._queued_dir
                    self._queued_dir = STOP
                train.snapshot()
                self._step()
                self._last_step = now
                state.sub_step = 0.0

    # ------------------------------------------------------------------
    # Step (direct port of C control())
    # ------------------------------------------------------------------

    def _step(self) -> None:
        state = self._state
        train = state.train
        mute  = state.auto_pilot
        from .constants import DDX, DDY

        old_x, old_y = train.loko_x, train.loko_y
        new_x = old_x + DDX[train.direction]
        new_y = old_y + DDY[train.direction]
        tile  = state.mapa[new_y][new_x]

        if tile == Tile.DOOR:
            if state.door_anim:
                state.show_password = True
                self._audio.play(AudioManager.HORN, silent=mute)
            else:
                state.crash_anim = 0
                self._audio.play(AudioManager.CRASH, silent=mute)
                return
        elif tile == Tile.WALL:
            state.crash_anim = 0
            self._audio.play(AudioManager.CRASH, silent=mute)
            return
        elif train.collides_with_self(new_x, new_y):
            state.crash_anim = 0
            self._audio.play(AudioManager.CRASH, silent=mute)
            return

        train.loko_x = new_x
        train.loko_y = new_y
        state.steps += 1

        m = len(train.wagons)   # old count, saved before possible append

        if is_collectible(tile):
            state.collected += 1
            self._audio.play(AudioManager.WAGON, silent=mute)
            cargo = tile - 100
            if train.wagons:
                tail = train.wagons[-1]
                train.wagons.append(Wagon(tail.x, tail.y, 0, cargo))
            else:
                train.wagons.append(Wagon(old_x, old_y, 0, cargo))
            state.mapa[new_y][new_x] = Tile.EMPTY
            if state.collected >= state.total_collectibles:
                state.door_anim = 1
                self._audio.play(AudioManager.BELL, silent=mute)

        # C: while(m) { vagony[m]=vagony[m-1]; m-- }
        i = m
        while i > 0:
            if i < len(train.wagons):
                train.wagons[i].x         = train.wagons[i - 1].x
                train.wagons[i].y         = train.wagons[i - 1].y
                train.wagons[i].direction = train.wagons[i - 1].direction
            i -= 1
        if train.wagons:
            train.wagons[0].x         = old_x
            train.wagons[0].y         = old_y
            train.wagons[0].direction = train.loko_dir

        if train.direction != STOP:
            train.loko_dir = train.direction
            self._audio.play(AudioManager.LOKO, silent=mute)
