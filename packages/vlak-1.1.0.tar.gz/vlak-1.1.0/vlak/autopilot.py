from collections import deque
from .constants import GRID_W, GRID_H, DDX, DDY, RIGHT, LEFT, UP, DOWN, STOP, is_collectible
from .constants import Tile


def auto_direction(loko_x: int, loko_y: int, mapa: list[list[int]],
                   wagons: list, door_open: bool, current_dir: int) -> int:
    tx, ty = _find_target(loko_x, loko_y, mapa, door_open)
    if tx < 0:
        return current_dir

    blocked = _build_blocked(mapa, wagons)
    came_from = _bfs(loko_x, loko_y, tx, ty, blocked)

    if came_from is None:
        dxt = tx - loko_x
        dyt = ty - loko_y
        if abs(dxt) >= abs(dyt):
            return RIGHT if dxt > 0 else LEFT
        return DOWN if dyt > 0 else UP

    return _trace_first_step(loko_x, loko_y, tx, ty, came_from)


def _find_target(loko_x: int, loko_y: int, mapa: list[list[int]],
                 door_open: bool) -> tuple[int, int]:
    tx, ty = -1, -1
    best = 9999
    for j in range(GRID_H):
        for i in range(GRID_W):
            v = mapa[j][i]
            if is_collectible(v):
                d = abs(loko_x - i) + abs(loko_y - j)
                if d < best:
                    best = d
                    tx, ty = i, j

    if tx >= 0:
        return tx, ty

    if door_open:
        for j in range(GRID_H):
            for i in range(GRID_W):
                if mapa[j][i] == Tile.DOOR:
                    return i, j

    return -1, -1


def _build_blocked(mapa: list[list[int]], wagons: list) -> list[list[bool]]:
    blocked = [[False] * GRID_W for _ in range(GRID_H)]
    for j in range(GRID_H):
        for i in range(GRID_W):
            if mapa[j][i] == Tile.WALL:
                blocked[j][i] = True
    for w in wagons:
        if 0 <= w.y < GRID_H and 0 <= w.x < GRID_W:
            blocked[w.y][w.x] = True
    return blocked


def _bfs(sx: int, sy: int, tx: int, ty: int,
         blocked: list[list[bool]]) -> list[list[int]] | None:
    came_from = [[-1] * GRID_W for _ in range(GRID_H)]
    came_from[sy][sx] = 4  # sentinel: start
    q = deque([(sx, sy)])
    while q:
        cx, cy = q.popleft()
        for d in range(4):
            nx, ny = cx + DDX[d], cy + DDY[d]
            if nx < 0 or nx >= GRID_W or ny < 0 or ny >= GRID_H:
                continue
            if came_from[ny][nx] >= 0 or blocked[ny][nx]:
                continue
            came_from[ny][nx] = d
            if nx == tx and ny == ty:
                return came_from
            q.append((nx, ny))
    return None


def _trace_first_step(sx: int, sy: int, tx: int, ty: int,
                      came_from: list[list[int]]) -> int:
    cx, cy = tx, ty
    while True:
        d = came_from[cy][cx]
        px = cx + DDX[(d + 2) % 4]
        py = cy + DDY[(d + 2) % 4]
        if px == sx and py == sy:
            return d
        cx, cy = px, py
