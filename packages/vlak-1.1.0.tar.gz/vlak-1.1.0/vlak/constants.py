from enum import IntEnum

TILE_SIZE = 32
GRID_W = 20
GRID_H = 12
BASE_W = TILE_SIZE * GRID_W   # 640
BASE_H = TILE_SIZE * GRID_H   # 384

STEP_MS = 450
ANIM_MS = 150

RIGHT = 0
UP    = 1
LEFT  = 2
DOWN  = 3
STOP  = 4

DDX = [1,  0, -1, 0]
DDY = [0, -1,  0, 1]


class Tile(IntEnum):
    EMPTY = 0
    WALL  = 1
    # collectibles 100-118
    KRY = 100
    KOR = 101
    STO = 102
    JAB = 103
    KRA = 104
    TRE = 105
    RYB = 106
    ZIR = 107
    ZMR = 108
    DOR = 109
    POC = 110
    AUT = 111
    BAL = 112
    BUD = 113
    SLO = 114
    VIN = 115
    PEN = 116
    LET = 117
    LEM = 118
    # special
    DOOR  = 1000
    LOKO  = 10000


def is_collectible(v: int) -> bool:
    return 100 <= v < 1000
