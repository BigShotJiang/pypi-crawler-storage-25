# vlak

A train snake game for Linux/macOS built with Python + Arcade.

Port of the original DOS game by **Miroslav Němček (Panda381)**:
https://github.com/Panda381

![Python](https://img.shields.io/badge/python-3.13%2B-blue)
[![PyPI](https://img.shields.io/pypi/v/vlak)](https://pypi.org/project/vlak/)

## Installation

```bash
pip install vlak
```

## Running

```bash
vlak
```

## Controls

| Key | Action |
|-----|--------|
| **Arrow keys** | Change train direction |
| **Space / Enter** | Next scene / confirm password |
| **Escape** | Quit |
| **Alt+1 – Alt+4** | Window scale (1× – 4×) |

To skip to a specific scene, type its password using letter keys and confirm with **Enter**.

## Development

### Requirements

- Python 3.13+
- [arcade](https://api.arcade.academy/) 3.x

### Install from source

```bash
git clone https://github.com/cortexm/vlak
cd vlak
python -m venv .venv
.venv/bin/pip install -e .
.venv/bin/vlak
```

### Profiling

The game can be run under `cProfile` via an environment variable:

```bash
VLAK_PROFILE=1 vlak
```

On exit (Esc) it writes `vlak.prof` to the current directory and prints
the top 30 functions by cumulative and total time to stdout. Override the
output path with `VLAK_PROFILE_OUT=/path/to/file.prof`.
