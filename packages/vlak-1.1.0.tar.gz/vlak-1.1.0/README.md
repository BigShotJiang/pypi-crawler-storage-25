# vlak

Hra hadík s vlakom pre Linux/macOS postavená na Python + Arcade.

Port pôvodnej DOS hry od **Miroslav Němček (Panda381)**:
https://github.com/Panda381

![Python](https://img.shields.io/badge/python-3.13%2B-blue)
[![PyPI](https://img.shields.io/pypi/v/vlak)](https://pypi.org/project/vlak/)

## Inštalácia

```bash
pip install vlak
```

## Spustenie

```bash
vlak
```

## Ovládanie

| Kláves | Akcia |
|--------|-------|
| **Šípky** | Zmena smeru vlaku |
| **Medzerník / Enter** | Ďalšia scéna / potvrdenie hesla |
| **Escape** | Ukončenie hry |
| **Alt+1 – Alt+4** | Zmena veľkosti okna (1× – 4×) |

Heslo pre preskočenie na konkrétnu scénu zadaj písmenami a potvrď **Enter**.

## Vývoj

### Závislosti

- Python 3.13+
- [arcade](https://api.arcade.academy/) 3.x

### Inštalácia zo zdrojov

```bash
git clone https://github.com/cortexm/vlak
cd vlak
python -m venv .venv
.venv/bin/pip install -e .
.venv/bin/vlak
```

### Profilovanie

Hru je možné spustiť pod `cProfile` cez environment variable:

```bash
VLAK_PROFILE=1 vlak
```

Po ukončení (Esc) sa uloží `vlak.prof` v aktuálnom adresári a na stdout sa
vypíše top 30 funkcií podľa cumulative a total time. Cieľ profilu možno
zmeniť cez `VLAK_PROFILE_OUT=/cesta/k/suboru.prof`.
