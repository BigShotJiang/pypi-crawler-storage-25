"""
Config loading for Halton Meter daemon.

Reads ~/.halton-meter/config.toml on startup. Missing file is not an error —
defaults are applied. Config is validated with Pydantic and frozen after load.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


class DaemonConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    listen_host: str = Field(default="127.0.0.1")
    listen_port: int = Field(default=8080)
    log_path: str = Field(default="~/.halton-meter/daemon.log")
    # FastAPI HTTP API listener (Phase 2B.1+). The dashboard reads from this
    # over loopback. Kept on a separate port from the proxy listener so a
    # browser hitting the API never accidentally goes through mitmproxy.
    api_host: str = Field(default="127.0.0.1")
    api_port: int = Field(default=8765)


class StorageConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    db_path: str = Field(default="~/.halton-meter/db.sqlite")


class SyncConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    # Phase 1+: backend sync settings
    backend_url: str = Field(default="")
    batch_interval_seconds: int = Field(default=60)
    batch_size: int = Field(default=100, description="Records per POST batch")
    api_key: str = Field(default="")
    enabled: bool = Field(
        default=True,
        description="Set False to disable sync even if backend_url is set",
    )


class CorsConfig(BaseModel):
    """CORS settings for the daemon's FastAPI app (Phase 2B.1+)."""

    model_config = ConfigDict(frozen=True)

    allow_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000"])


class HaltonConfig(BaseModel):
    """Top-level config model. Loaded once at daemon startup."""

    model_config = ConfigDict(frozen=True)

    daemon: DaemonConfig = Field(default_factory=DaemonConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    sync: SyncConfig = Field(default_factory=SyncConfig)
    cors: CorsConfig = Field(default_factory=CorsConfig)


_DEFAULT_CONFIG_PATH = Path("~/.halton-meter/config.toml").expanduser()


def load_config(path: Path | None = None) -> HaltonConfig:
    """
    Load config from TOML file. Returns defaults if the file does not exist.

    Args:
        path: Override the config file path. Defaults to ~/.halton-meter/config.toml.

    Returns:
        Validated, frozen HaltonConfig instance.
    """
    config_path = path or _DEFAULT_CONFIG_PATH

    if not config_path.exists():
        return HaltonConfig()

    with config_path.open("rb") as fh:
        raw = tomllib.load(fh)

    return HaltonConfig.model_validate(raw)
