"""
Halton Meter CLI entry point.

Commands (Phase 0):
  daemon   — start the local proxy
  version  — print version
  report   — print cost report from local SQLite logs
  setup    — install CA cert, configure system proxy (Step 0.10)
"""

from __future__ import annotations

import asyncio
import os
import socket
import subprocess
import sys

import click
from rich.console import Console

from halton_meter import __version__
from halton_meter.config import load_config
from halton_meter.doctor import doctor_cmd as _doctor_cmd_impl

console = Console()

# Exit codes
_EXIT_DAEMON_ALREADY_RUNNING = 1


# --------------------------------------------------------------------------- #
# Pre-flight: refuse to start a second daemon instance (2B.12)                #
# --------------------------------------------------------------------------- #


def _launchctl_managed_pid(label: str = "com.haltonlabs.meter") -> int | None:
    """Return the PID launchctl reports for ``label``, or None.

    Lightweight mirror of :func:`halton_meter.lifecycle._launchctl_label_pid`
    duplicated here to keep the CLI module's imports cheap (cli.py is on the
    hot path for every ``halton-meter ...`` invocation; lifecycle.py pulls
    in rich tables, sqlite3, etc.).
    """
    if sys.platform != "darwin":
        return None
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if line.startswith('"PID"'):
            _, _, rhs = line.partition("=")
            value = rhs.strip().rstrip(";").strip()
            if value == "-" or not value:
                return None
            try:
                return int(value)
            except ValueError:
                return None
    return None


def _api_port_is_bound(host: str, port: int, timeout: float = 0.1) -> bool:
    """Return True if ``host:port`` accepts a TCP connection within ``timeout``.

    Used as the second pre-flight signal: even if launchctl doesn't report
    a managed daemon (e.g. user ran a foreground ``halton-meter daemon`` in
    another terminal, or a stray process holds the port), the bind would
    fail and crash uvicorn — which historically tripped the proxy-cleanup
    handler and clobbered a live install's system-proxy state.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, TimeoutError):
        return False


def _health_ok(api_host: str, api_port: int, timeout: float = 0.5) -> bool:
    """Return True iff GET ``/health`` on ``api_host:api_port`` returns 200 OK."""
    import json as _j
    import urllib.error
    import urllib.request

    url = f"http://{api_host}:{api_port}/health"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return False
            body = resp.read()
            try:
                payload = _j.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return False
            return isinstance(payload, dict) and payload.get("status") == "ok"
    except (urllib.error.URLError, TimeoutError, OSError):
        return False
    except Exception:
        return False


def _system_proxy_enabled(listen_host: str, listen_port: int) -> bool:
    """Return True iff the macOS system proxy on any active interface
    currently points at our listener.

    Linux / Windows: returns False (managed via env vars; we don't probe
    those from the CLI side here).
    """
    if sys.platform != "darwin":
        return False
    try:
        from halton_meter import system_proxy

        for iface in system_proxy._macos_interfaces():
            for secure in (True, False):
                enabled, host, port = system_proxy._read_macos_proxy(
                    iface, secure=secure
                )
                if not enabled:
                    continue
                if system_proxy._proxy_targets_us(host, port, listen_host, listen_port):
                    return True
    except Exception:
        return False
    return False


def _empty_records_hint(cfg: object) -> str:
    """Build a Rich-markup hint string for the empty-records branch of
    ``halton-meter report`` (and any future caller).

    Three branches based on actual daemon state — never recommend
    ``halton-meter daemon`` to the end user (that's a foreground/dev
    command). (2B.12.1)
    """
    daemon_up = _health_ok(cfg.daemon.api_host, cfg.daemon.api_port)
    proxy_on = (
        _system_proxy_enabled(cfg.daemon.listen_host, cfg.daemon.listen_port)
        if daemon_up
        else False
    )

    muted = "bright_black"
    if daemon_up and proxy_on:
        return (
            f"[{muted}]daemon is running and the system proxy is enabled. "
            f"Make an LLM API call through your client (Claude Code, an "
            f"SDK, curl with HTTPS_PROXY set, etc.) — captures will appear "
            f"here.[/]"
        )
    if daemon_up and not proxy_on:
        return (
            f"[{muted}]daemon is running but the system proxy is disabled. "
            f"Run[/] [bold]halton-meter start[/] [{muted}]to enable "
            f"metering, then make an LLM API call.[/]"
        )
    return (
        f"[{muted}]daemon is not running. Run[/] [bold]halton-meter start[/] "
        f"[{muted}]to begin metering. (Initial install:[/] "
        f"[bold]halton-meter init[/][{muted}].)[/]"
    )


def _preflight_or_exit(api_host: str, api_port: int) -> None:
    """Refuse to start the daemon if another instance is already running.

    Emits a clear hint message and exits with
    :data:`_EXIT_DAEMON_ALREADY_RUNNING` if launchctl reports a live
    ``com.haltonlabs.meter`` PID, OR if the configured API port is
    already bound. Crucially this runs BEFORE any cleanup handlers
    (atexit, signal) are registered, so a refusal does not touch the
    live install's system-proxy state. (2B.12)

    Self-recognition (v0.1.3 fix): if we ARE the launchd-spawned
    instance, the preflight must not refuse itself. launchd sets
    ``XPC_SERVICE_NAME`` to the plist label in our env, and
    ``launchctl list <label>`` reports OUR pid. Either signal means
    "the only instance launchctl knows about is us — proceed."
    Without this, the preflight ate its own tail: every launchd
    spawn refused itself, KeepAlive respawned, infinite loop.
    """
    if os.environ.get("XPC_SERVICE_NAME") == "com.haltonlabs.meter":
        return  # we are the launchd-spawned daemon; proceed.

    managed_pid = _launchctl_managed_pid()
    if managed_pid is not None and managed_pid == os.getpid():
        return  # launchctl reports us as the managed instance; proceed.

    port_busy = _api_port_is_bound(api_host, api_port)

    if managed_pid is None and not port_busy:
        return  # nothing else running; proceed.

    lines = ["halton-meter daemon: another instance is already running."]
    if managed_pid is not None:
        lines.append(
            f"  Managed by launchd: PID {managed_pid} "
            f"(label com.haltonlabs.meter)"
        )
    elif port_busy:
        lines.append(
            f"  Port {api_host}:{api_port} is bound by another process."
        )
    lines.append("")
    lines.append(
        "Use `halton-meter status` to inspect, `halton-meter stop` to halt the"
    )
    lines.append(
        "managed daemon, or `halton-meter uninstall` for full removal. The"
    )
    lines.append(
        "`halton-meter daemon` subcommand is for foreground/dev runs only."
    )
    # Plain stderr — no rich formatting so error-recovery scripts can grep.
    print("\n".join(lines), file=sys.stderr, flush=True)
    sys.exit(_EXIT_DAEMON_ALREADY_RUNNING)


@click.group()
def cli() -> None:
    """Halton Meter — local LLM API cost attribution proxy."""


@cli.command()
@click.option(
    "--host",
    default=None,
    help="Override listen host (default from config or 127.0.0.1).",
)
@click.option(
    "--port",
    default=None,
    type=int,
    help="Override listen port (default from config or 8080).",
)
@click.option(
    "--config",
    "config_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Path to config.toml (default: ~/.halton-meter/config.toml).",
)
def daemon(host: str | None, port: int | None, config_path: str | None) -> None:
    """Start the Halton Meter proxy daemon."""
    from pathlib import Path

    from halton_meter.port_alloc import (
        discover_and_persist_ports,
        load_effective_config,
    )

    # v0.1.3 P0-5: load the merged effective config (defaults < runtime <
    # config.toml), then run port discovery for whichever ports aren't
    # pinned, then re-load so the daemon binds to the chosen pair.
    cfg_path_obj = Path(config_path) if config_path else None
    if config_path is None:
        # Standard install path: do auto-fallback if needed.
        try:
            discover_and_persist_ports()
        except OSError:
            # Persistence is best-effort; continue with whatever was already
            # in runtime.toml + config.toml.
            pass
        cfg = load_effective_config()
    else:
        # Explicit --config: legacy path — honour the user-supplied file
        # exactly, no auto-fallback.
        cfg = load_config(cfg_path_obj)

    # CLI flags override config values. We reconstruct a new config rather than
    # mutating the frozen Pydantic model.
    if host is not None or port is not None:
        from halton_meter.config import DaemonConfig, HaltonConfig

        daemon_cfg = DaemonConfig(
            listen_host=host or cfg.daemon.listen_host,
            listen_port=port or cfg.daemon.listen_port,
            log_path=cfg.daemon.log_path,
        )
        cfg = HaltonConfig(
            daemon=daemon_cfg,
            storage=cfg.storage,
            sync=cfg.sync,
        )

    # 2B.12: refuse to start if another instance is already running. MUST run
    # before _run_daemon — which registers proxy-cleanup handlers — because
    # otherwise a uvicorn bind failure on the conflicting port triggers the
    # cleanup handler on this (failing) instance and disables the LIVE
    # install's system proxy.
    _preflight_or_exit(cfg.daemon.api_host, cfg.daemon.api_port)

    asyncio.run(_run_daemon(cfg))


async def _run_daemon(cfg: object) -> None:
    """Run proxy + FastAPI HTTP API + optional sync workers concurrently.

    The proxy hot path and the FastAPI app run in the same asyncio event
    loop, in the same Python process. mitmproxy listens on
    ``daemon.proxy_port``; uvicorn serves the FastAPI app on
    ``daemon.api_port``. The two are independent — if uvicorn crashes the
    proxy stays up, and vice versa. On Ctrl-C / SIGTERM, ``run_proxy``
    returns and we tear everything else down.
    """
    import sys

    import uvicorn

    from halton_meter.api import create_app
    from halton_meter.proxy import run_proxy
    from halton_meter.system_proxy import (
        enable_system_proxy_if_managed,
        install_proxy_cleanup,
    )

    # Layer 2 (Option 1): if the user has opted in to managed proxying
    # (sentinel file present), re-enable the macOS system proxy on
    # startup. This closes the loop with the watchdog: watchdog disables
    # the proxy when the daemon freezes; launchd revives the daemon;
    # daemon re-enables the proxy here so metering resumes. Without this,
    # the watchdog would silently leave metering off forever after a
    # freeze. Sentinel-gated and silent on non-macOS / if the user never
    # ran ``halton-meter setup``. Must run BEFORE install_proxy_cleanup
    # so the cleanup handler picks up the now-enabled state.
    # Note: the system proxy points at the *proxy listener* (mitmproxy,
    # default :8080), not the FastAPI HTTP API (default :8765). The
    # watchdog polls ``api_port`` for liveness but disables the proxy
    # that points at ``listen_port`` — same as install_proxy_cleanup
    # below. The brief specified ``api_port`` here; we use ``listen_port``
    # so the re-enable mirrors what layer 1's cleanup actually toggles.
    # (Reported back to the operator.)
    enable_system_proxy_if_managed(
        host=cfg.daemon.listen_host,
        port=cfg.daemon.listen_port,
    )

    # Best-effort: if the macOS system proxy is currently pointed at our
    # listener, register handlers that reset it on shutdown so a daemon
    # exit doesn't take the user's HTTPS traffic with it. Hard-coded to
    # macOS for now; Linux + Windows ports land in 2B.5/2B.6.
    proxy_cleanup = install_proxy_cleanup(
        cfg.daemon.listen_host,
        cfg.daemon.listen_port,
    )

    # Phase 2B.3 deletes the cloud-sync and policy-sync workers entirely:
    # SQLite is the canonical store in v1.0; there is no backend to push to
    # or to pull policies from. The legacy backend_url config key is kept
    # only so existing config.toml files don't blow up on load.

    # --- FastAPI app over uvicorn, alongside mitmproxy in this event loop ---
    app = create_app(cfg)
    uvicorn_config = uvicorn.Config(
        app,
        host=cfg.daemon.api_host,
        port=cfg.daemon.api_port,
        log_level="warning",
        lifespan="on",
        # Don't let uvicorn install signal handlers — the daemon process
        # already handles Ctrl-C through mitmproxy / asyncio.run.
        access_log=False,
    )
    uvicorn_server = uvicorn.Server(uvicorn_config)
    # uvicorn's default install_signal_handlers() conflicts with mitmproxy
    # in the same process; suppress it so Ctrl-C falls through to the
    # outer asyncio.run handler and shuts both servers down together.
    uvicorn_server.install_signal_handlers = lambda: None  # type: ignore[method-assign]

    api_task = asyncio.create_task(uvicorn_server.serve(), name="halton-api")

    print(
        f"[halton-meter] HTTP API listening on "
        f"http://{cfg.daemon.api_host}:{cfg.daemon.api_port}",
        file=sys.stderr,
        flush=True,
    )

    # macOS-only recovery hint. install_proxy_cleanup covers clean exit +
    # SIGINT/SIGTERM + atexit but not SIGKILL/segfault/OOM/power-loss; the
    # `halton-meter stop`/`uninstall` UX that closes that gap is scheduled
    # for 2B.6. Until then, the user needs the manual recovery one-liner
    # visible at daemon startup.
    if sys.platform == "darwin":
        print(
            "[halton-meter] First-time setup: run `halton-meter init` "
            "(one command does cert + proxy + supervisor)",
            file=sys.stderr,
            flush=True,
        )
        print(
            "[halton-meter] Status check anytime: `halton-meter status`",
            file=sys.stderr,
            flush=True,
        )
        print(
            "[halton-meter] If the daemon crashes hard, recover with:\n"
            "[halton-meter]   preferred:   halton-meter uninstall\n"
            "[halton-meter]   fallback:    unset HTTPS_PROXY HTTP_PROXY && "
            "networksetup -setsecurewebproxystate Wi-Fi off\n"
            "[halton-meter] Layer 2 watchdog: a sibling 'halton-meter watchdog' "
            "process polls /health every 1.5s and will disable the system\n"
            "[halton-meter]   proxy after ~7.5s of unresponsiveness so your "
            "traffic flows direct to providers (untracked, but flowing).",
            file=sys.stderr,
            flush=True,
        )

    try:
        await run_proxy(cfg)
    finally:
        # Signal uvicorn to shut down and wait for it to drain.
        uvicorn_server.should_exit = True
        try:
            # 2B.10.1: 30s (was 5s). Python 3.14 cold-start can push uvicorn's
            # serve()-task drain past the old 5s budget on first run, which
            # caused smoke runs to flake on /health probes immediately after
            # `halton-meter init`. 30s is the same grace window we give
            # launchd via `ExitTimeOut: 30` in build_macos_plist (2B.10).
            await asyncio.wait_for(api_task, timeout=30.0)
        except (TimeoutError, Exception):
            api_task.cancel()
        # Reset system proxy on the way out (idempotent — also runs via
        # atexit/signal handlers in case we don't reach this finally).
        if proxy_cleanup is not None:
            proxy_cleanup()


@cli.command()
def version() -> None:
    """Print the halton-meter version."""
    console.print(f"halton-meter {__version__}")


@cli.command()
@click.option(
    "--project",
    default=None,
    help="Filter to one project (default: all projects).",
)
@click.option(
    "--since",
    "since_days",
    default=30,
    type=int,
    show_default=True,
    help="Only show records from the last N days. 0 returns nothing.",
)
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Override DB path (default: from config).",
)
@click.option(
    "--config",
    "config_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Path to config.toml (default: ~/.halton-meter/config.toml).",
)
def report(
    project: str | None,
    since_days: int,
    db_path: str | None,
    config_path: str | None,
) -> None:
    """Print a formatted cost and token report from local SQLite logs."""
    from pathlib import Path

    from halton_meter.report import build_report_data, filter_records_by_days, render_report
    from halton_meter.storage import StorageManager

    cfg = load_config(Path(config_path) if config_path else None)
    resolved_db = db_path or cfg.storage.db_path

    async def _run() -> None:
        async with StorageManager(resolved_db) as storage:
            records = await storage.read_records(project=project, limit=10_000)

        filtered = filter_records_by_days(records, since_days)
        data = build_report_data(filtered)
        # 2B.12.1: tailor the empty-state hint to actual daemon state so
        # we never recommend `halton-meter daemon` (a dev-mode command)
        # to the end user.
        hint = _empty_records_hint(cfg) if data.total_requests == 0 else None
        render_report(data, console, empty_hint=hint)

    asyncio.run(_run())


@cli.command()
@click.option(
    "--once",
    is_flag=True,
    default=False,
    help="Run a single health poll and exit 0 (healthy) or 1 (unhealthy).",
)
@click.option(
    "--port",
    "port",
    default=None,
    type=int,
    help="Override api_port (default from config or 8765).",
)
@click.option(
    "--listen-port",
    "listen_port",
    default=None,
    type=int,
    help="Override the proxy listener port used to identify managed "
    "interfaces (default from config or 8080).",
)
def watchdog(once: bool, port: int | None, listen_port: int | None) -> None:
    """Layer 2 connectivity watchdog: poll /health, disable proxy on freeze.

    Runs as a separate launchd-supervised process. Polls the daemon's
    /health endpoint on ``api_port`` (default 8765) every 1.5s; after
    5 consecutive failures (~7.5s) it disables the macOS system proxy
    so the user's traffic flows direct to providers. Re-enable is the
    daemon's job on its next startup (gated on the ``proxy-managed``
    sentinel).

    Two distinct ports, two distinct purposes: ``api_port`` for
    ``/health`` polling, ``listen_port`` (default 8080) for matching
    interfaces in ``snapshot_interfaces``. The system proxy on each
    network service stores the mitmproxy listener address, not the
    HTTP API address. (2B.10.5)
    """
    import sys as _sys

    from halton_meter import watchdog as watchdog_module

    if port is None or listen_port is None:
        try:
            cfg = load_config()
            if port is None:
                port = cfg.daemon.api_port
            if listen_port is None:
                listen_port = cfg.daemon.listen_port
        except Exception:
            if port is None:
                port = 8765
            if listen_port is None:
                listen_port = 8080

    if once:
        _sys.exit(watchdog_module.poll_once(port))

    watchdog_module._install_signal_handlers()
    _sys.exit(watchdog_module.run_watchdog(port, listen_port=listen_port))


@cli.command()
def install() -> None:
    """Install the OS-level supervisor (launchd / systemd) for the daemon.

    Writes a launchd plist (macOS) or systemd user unit (Linux) so the
    daemon revives within ~1s of any exit, including SIGKILL / segfault.
    Layer 1 of the three-layer connectivity-on-crash fix.
    """
    import sys as _sys

    from halton_meter import install as install_module

    _sys.exit(install_module.install())


@cli.command()
@click.option(
    "--purge",
    is_flag=True,
    default=False,
    help=(
        "Also delete ~/.halton-meter/ (config, sentinel, runtime state). "
        "The SQLite database is preserved unless --include-logs is also given."
    ),
)
@click.option(
    "--include-logs",
    "include_logs",
    is_flag=True,
    default=False,
    help=(
        "With --purge, also delete db.sqlite and its WAL siblings. "
        "Logged usage data is permanently destroyed."
    ),
)
@click.option(
    "--yes",
    "assume_yes",
    is_flag=True,
    default=False,
    help="Skip interactive confirmation prompts. For scripted/CI uninstall.",
)
def uninstall(purge: bool, include_logs: bool, assume_yes: bool) -> None:
    """Remove the supervisor entry and restore the system proxy.

    The system-proxy step restores the captured pre-install state from
    ``~/.halton-meter/system_state.json`` (written by ``halton-meter
    init``). If no snapshot exists, falls back to disabling the system
    proxy on every active interface — the load-bearing one-command
    recovery path if a hard crash left the user's machine pointed at a
    dead daemon.

    Three-tier data removal (2B.11):

    \b
    * default:                supervisor + sentinel + proxy restore.
                              ~/.halton-meter/ preserved (config + logs).
    * --purge:                also delete ~/.halton-meter/ EXCEPT db.sqlite
                              (+ WAL siblings). Cost data is the product.
    * --purge --include-logs: also delete db.sqlite. Permanent.
    """
    import sys as _sys
    from pathlib import Path

    from halton_meter import install as install_module

    if include_logs and not purge:
        console.print(
            "[red]--include-logs requires --purge.[/red] "
            "Run [bold]halton-meter uninstall --purge --include-logs[/bold] to delete logs."
        )
        _sys.exit(2)

    if purge and not assume_yes:
        if include_logs:
            db_path = Path("~/.halton-meter/db.sqlite").expanduser()
            records, projects = install_module.count_request_records(db_path)
            console.print(
                f"[bold red]About to delete db.sqlite with {records:,} requests "
                f"across {projects:,} projects.[/bold red]"
            )
            try:
                response = console.input("Type 'delete' to confirm: ")
            except EOFError:
                response = ""
            if response.strip() != "delete":
                console.print("[yellow]Aborted.[/yellow] Nothing was changed.")
                _sys.exit(1)
        else:
            console.print(
                "[bold]About to delete ~/.halton-meter/ (config, sentinel, runtime state). "
                "db.sqlite will be preserved.[/bold]"
            )
            try:
                response = console.input("Type 'yes' to confirm: ")
            except EOFError:
                response = ""
            if response.strip().lower() != "yes":
                console.print("[yellow]Aborted.[/yellow] Nothing was changed.")
                _sys.exit(1)

    _sys.exit(install_module.uninstall(purge=purge, include_logs=include_logs))


@cli.command()
def start() -> None:
    """Start the halton-meter daemon + watchdog via launchd."""
    import sys as _sys

    from halton_meter.lifecycle import start as start_fn

    _sys.exit(start_fn(console=console))


@cli.command()
def stop() -> None:
    """Stop the halton-meter daemon + watchdog and reset the system proxy.

    Pauses metering. Plists stay installed; sentinel is preserved. Run
    `halton-meter start` to resume — the daemon's startup will re-enable
    the system proxy via the managed-mode sentinel.

    For full removal, use `halton-meter uninstall` instead.
    """
    import sys as _sys

    from halton_meter.lifecycle import stop as stop_fn

    _sys.exit(stop_fn(console=console))


@cli.command()
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Emit machine-readable JSON instead of a Rich table.",
)
def status(json_output: bool) -> None:
    """Show daemon, watchdog, system proxy, and capture state."""
    import sys as _sys

    from halton_meter.lifecycle import status as status_fn

    _sys.exit(status_fn(console=console, json_output=json_output))


@cli.command(name="reset-proxy")
def reset_proxy_cmd() -> None:
    """Layer-4 escape hatch: disable the system proxy unconditionally.

    Sentinel-blind, config-independent. Safe to run when the daemon has
    never been installed, when ``~/.halton-meter/config.toml`` is missing
    or corrupt, and when nothing is currently listening on the proxy
    port. Used by the launchd ``ExitTimeOut`` shutdown path and the
    systemd ``ExecStop=`` hook so a system reboot / logout / hard-stop
    leaves the user's network connectivity intact even if the daemon's
    in-process handlers never ran.
    """
    import sys as _sys

    from halton_meter.system_proxy import reset_proxy_minimal

    _sys.exit(reset_proxy_minimal())


cli.add_command(_doctor_cmd_impl)


@cli.command(
    name="run",
    context_settings={"ignore_unknown_options": True, "allow_interspersed_args": False},
)
@click.argument("cmd", nargs=-1, type=click.UNPROCESSED)
@click.option(
    "--shell",
    "use_shell",
    is_flag=True,
    default=False,
    help="Spawn the user's $SHELL with the metering env vars set "
    "(interactive subshell mode).",
)
@click.option(
    "--preflight-timeout",
    type=float,
    default=3.0,
    show_default=True,
    help="Seconds to wait for the daemon's /health endpoint before refusing.",
)
def run_cmd(cmd: tuple[str, ...], use_shell: bool, preflight_timeout: float) -> None:
    """Run an arbitrary command with the proxy + cert env vars set so it
    is metered through the local daemon.

    Examples:

      halton-meter run claude                  # meter Claude Code
      halton-meter run -- python my_script.py  # arbitrary command
      halton-meter run --shell                 # interactive subshell
    """
    import sys as _sys

    from halton_meter.run import run_cmd as _run

    rc = _run(cmd, use_shell=use_shell, preflight_timeout=preflight_timeout)
    # os.execvpe replaces this process on success; only refusal paths
    # return — _sys.exit propagates them cleanly.
    _sys.exit(rc)


@cli.command(name="init")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Skip the live-daemon prompt; assume yes. For CI / scripted installs.",
)
@click.option(
    "--apps",
    "apps",
    is_flag=True,
    default=False,
    help=(
        "v0.1.5 (2B.16): cert + plists + launchctl setenv user-domain + "
        "shell-rc append. NO system proxy. Covers Spotlight/Dock-spawned "
        "apps + new shells. Cannot break HSTS browsing because the "
        "system proxy is never flipped."
    ),
)
@click.option(
    "--full",
    "full",
    is_flag=True,
    default=False,
    help=(
        "Opt in to system-proxy + launchctl env + shell-rc mode. Broadest "
        "coverage — browsers, GUI apps, terminals. May break HSTS browser "
        "sites if the cert isn't trusted by SecTrust. Replaces the "
        "v0.1.3/v0.1.4 --gui flag."
    ),
)
@click.option(
    "--gui",
    "gui",
    is_flag=True,
    default=False,
    hidden=True,
    help="Deprecated alias for --full (kept for v0.1.3/v0.1.4 back-compat).",
)
@click.option(
    "--no-shell-rc",
    "no_shell_rc",
    is_flag=True,
    default=False,
    help=(
        "Skip the shell rc append step in --apps / --full modes. "
        "(No effect in env-var-only mode — that mode never edits shell rc.)"
    ),
)
def init_cmd(
    non_interactive: bool,
    apps: bool,
    full: bool,
    gui: bool,
    no_shell_rc: bool,
) -> None:
    """First-run setup. Three modes:

      * default (no flag): env-var-only. Safest. Use ``halton-meter run``
        to meter a CLI / SDK client.
      * ``--apps``: env vars set system-wide for terminals + Spotlight-
        spawned apps. NO system proxy.
      * ``--full``: env vars + system proxy. Broadest coverage; may
        break HSTS browser sites if cert isn't trusted by SecTrust.
    """
    if sum(1 for f in (apps, full, gui) if f) > 1:
        click.echo(
            "Error: pass at most one of --apps / --full "
            "(--gui is a deprecated alias for --full).",
            err=True,
        )
        raise click.exceptions.Exit(2)

    import sys as _sys

    from halton_meter.init import init as init_fn

    _sys.exit(
        init_fn(
            non_interactive=non_interactive,
            apps=apps,
            full=full,
            gui=gui,
            no_shell_rc=no_shell_rc,
            console=console,
        )
    )


@cli.command()
@click.option(
    "--check",
    "check_only",
    is_flag=True,
    default=False,
    help="Print current state of each setup step without modifying anything.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Re-run all steps even if already done.",
)
def setup(check_only: bool, force: bool) -> None:
    """One-time setup: generate CA cert, trust in keychain, patch certifi."""
    from halton_meter.setup import check_steps, render_result, run_setup

    if check_only:
        result = check_steps()
    else:
        result = run_setup(force=force, console=console)

    render_result(result, console)
