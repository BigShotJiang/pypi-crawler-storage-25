"""Layer 2 of the three-layer connectivity-on-crash fix: separate watchdog process.

See ``memory/decisions.md`` 2026-04-29 — "Three-layer connectivity-on-crash fix"
and "Layer 2 watchdog: Option-1 daemon-side proxy enable on startup".

What it does
------------

A second OS-supervised process (``halton-meter watchdog``) polls the
daemon's ``/health`` endpoint every 1.5s. After 5 consecutive failures
(~7.5s of unresponsiveness — covering the freeze-but-don't-die case
that layer 1 cannot catch alone), the watchdog runs ``networksetup
-setsecurewebproxystate <iface> off`` so the user's outbound HTTPS
traffic flows direct to providers (untracked, but flowing). When the
daemon comes back, the **daemon's own startup** (post-Option-1 patch)
re-enables the system proxy from the ``proxy-managed`` sentinel — the
watchdog never re-enables. One direction of state transition only.

Design constraints (do not violate without an ADR)
--------------------------------------------------

* Stdlib only — no new dependencies.
* Watchdog never raises out of the polling loop.
* Watchdog never re-enables the system proxy.
* The interface snapshot is taken once at startup and not refreshed.
* Hysteresis: 5 fails → disable; 3 successes → exit RECOVERING. Recovery
  never triggers re-enable; it only resolves the watchdog's internal
  state so a subsequent freeze gets a fresh failure budget.
* All state transitions logged via structlog with structured fields;
  individual polls are NOT logged.
"""

from __future__ import annotations

import enum
import json
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

import structlog

from halton_meter import system_proxy
from halton_meter.config import load_config

# --------------------------------------------------------------------------- #
# Constants                                                                    #
# --------------------------------------------------------------------------- #

_HEALTH_PATH = "/health"
_POLL_INTERVAL_SECONDS = 1.5
_FAILURE_THRESHOLD = 5
_RECOVERY_THRESHOLD = 3
_HEALTH_TIMEOUT_SECONDS = 1.0


log = structlog.get_logger("halton_meter.watchdog")


# --------------------------------------------------------------------------- #
# State machine (pure logic, no I/O)                                           #
# --------------------------------------------------------------------------- #


class WatchdogState(enum.Enum):
    HEALTHY = "healthy"
    DEGRADING = "degrading"
    PROXY_DISABLED = "proxy_disabled"
    RECOVERING = "recovering"


@dataclass(frozen=True)
class StateTransition:
    """The result of feeding one health-check observation into the machine.

    ``should_disable_proxy_now`` fires exactly once on the
    DEGRADING -> PROXY_DISABLED edge. Everything else is informational.
    """

    from_: WatchdogState
    to: WatchdogState
    fail_count: int
    success_count: int
    should_disable_proxy_now: bool


class WatchdogStateMachine:
    """Pure-logic four-state hysteresis machine.

    HEALTHY -> DEGRADING on first fail.
    DEGRADING -> HEALTHY on first success (resets fail_count).
    DEGRADING -> PROXY_DISABLED on fail_count == _FAILURE_THRESHOLD
        (signals disable on this transition only).
    PROXY_DISABLED -> RECOVERING on first success.
    RECOVERING -> PROXY_DISABLED on first fail (resets success_count).
    RECOVERING -> HEALTHY on success_count == _RECOVERY_THRESHOLD.

    No I/O. The caller is responsible for actually disabling the proxy
    when ``should_disable_proxy_now`` is True.
    """

    def __init__(
        self,
        *,
        failure_threshold: int = _FAILURE_THRESHOLD,
        recovery_threshold: int = _RECOVERY_THRESHOLD,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_threshold = recovery_threshold
        self._state = WatchdogState.HEALTHY
        self._fail_count = 0
        self._success_count = 0

    @property
    def state(self) -> WatchdogState:
        return self._state

    @property
    def fail_count(self) -> int:
        return self._fail_count

    @property
    def success_count(self) -> int:
        return self._success_count

    def record_health(self, success: bool) -> StateTransition:
        prev = self._state
        should_disable = False

        if self._state is WatchdogState.HEALTHY:
            if success:
                # Stay HEALTHY. Counters already zero.
                self._fail_count = 0
                self._success_count = 0
            else:
                self._fail_count = 1
                self._success_count = 0
                self._state = WatchdogState.DEGRADING

        elif self._state is WatchdogState.DEGRADING:
            if success:
                self._fail_count = 0
                self._success_count = 0
                self._state = WatchdogState.HEALTHY
            else:
                self._fail_count += 1
                if self._fail_count >= self._failure_threshold:
                    self._state = WatchdogState.PROXY_DISABLED
                    should_disable = True
                    # Reset success counter so RECOVERING starts fresh.
                    self._success_count = 0

        elif self._state is WatchdogState.PROXY_DISABLED:
            if success:
                self._success_count = 1
                self._state = WatchdogState.RECOVERING
            else:
                # Stay disabled. fail_count irrelevant here.
                self._success_count = 0

        elif self._state is WatchdogState.RECOVERING:
            if success:
                self._success_count += 1
                if self._success_count >= self._recovery_threshold:
                    self._state = WatchdogState.HEALTHY
                    self._fail_count = 0
                    self._success_count = 0
            else:
                self._success_count = 0
                self._state = WatchdogState.PROXY_DISABLED

        return StateTransition(
            from_=prev,
            to=self._state,
            fail_count=self._fail_count,
            success_count=self._success_count,
            should_disable_proxy_now=should_disable,
        )


# --------------------------------------------------------------------------- #
# Side-effecting helpers                                                       #
# --------------------------------------------------------------------------- #


def disable_system_proxy(interfaces: list[str]) -> None:
    """Best-effort ``networksetup -setsecurewebproxystate <iface> off`` loop.

    Mirrors :func:`system_proxy._disable_macos_proxy` but is the
    one-direction watchdog action — no atexit, no signal chaining.
    Each (interface, variant) failure is swallowed so one bad
    interface never stops the rest.
    """
    for iface in interfaces:
        for flag in ("-setsecurewebproxystate", "-setwebproxystate"):
            try:
                subprocess.run(
                    ["networksetup", flag, iface, "off"],
                    capture_output=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                # Best-effort; the next iteration may still succeed.
                pass


def poll_health(api_port: int, timeout: float = _HEALTH_TIMEOUT_SECONDS) -> bool:
    """Return True iff GET http://127.0.0.1:<api_port>/health returns 200 + ok body.

    Anything else (connection refused, timeout, 4xx, 5xx, malformed
    JSON, generic exception) returns False. The watchdog itself must
    never raise from this function — broad ``Exception`` catch at the
    boundary.
    """
    url = f"http://127.0.0.1:{api_port}{_HEALTH_PATH}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return False
            body = resp.read()
            try:
                payload = json.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return False
            return isinstance(payload, dict) and payload.get("status") == "ok"
    except (urllib.error.URLError, TimeoutError, OSError):
        return False
    except Exception:
        return False


def snapshot_interfaces(listen_port: int) -> list[str]:
    """Return the macOS interfaces currently routing through ``127.0.0.1:listen_port``.

    The system proxy on each interface points at the daemon's mitmproxy
    *listener* (``daemon.listen_port``, default 8080), NOT the FastAPI
    HTTP API port (``daemon.api_port``, default 8765). The watchdog
    polls ``/health`` on ``api_port`` for liveness but matches
    interfaces against ``listen_port`` because that's the address the
    OS actually has stored against each network service.

    (2B.10.5: prior to this fix, both used ``api_port``. With
    ``listen_port=8080`` and ``api_port=8765`` distinct, the snapshot
    always returned empty, so the watchdog logged
    ``no_interfaces_pointing_at_us`` and exited even on a fully-installed
    daemon. Combined with 2B.10.4's ``KeepAlive={SuccessfulExit: False}``,
    that meant smoke_init Step 4e correctly reported ``[FAIL] watchdog
    not running``.)

    Snapshot is taken once at watchdog startup and not refreshed for
    the lifetime of the process. If the user changes their network
    setup mid-session, restarting the watchdog (``launchctl unload/load``
    of the watchdog plist) picks up the new state.
    """
    if sys.platform != "darwin":
        return []

    matching: list[str] = []
    for iface in system_proxy._macos_interfaces():
        # We reach into the leading-underscore helper here intentionally:
        # the same module already exports a public alias for the read
        # helper, but the interface list is configuration-as-data
        # populated dynamically (2B.7.2) from
        # ``networksetup -listallnetworkservices``. Same precedent as
        # ``_log_audit_event`` callers in the api layer.
        for secure in (True, False):
            enabled, host, port = system_proxy.read_proxy_target(iface, secure=secure)
            if not enabled:
                continue
            if host in {"127.0.0.1", "localhost", "0.0.0.0"} and port == listen_port:
                if iface not in matching:
                    matching.append(iface)
    return matching


# --------------------------------------------------------------------------- #
# Run loop                                                                     #
# --------------------------------------------------------------------------- #


def _log_transition(transition: StateTransition) -> None:
    if transition.from_ is transition.to:
        return
    log.info(
        "watchdog.state_change",
        from_=transition.from_.value,
        to=transition.to.value,
        fail_count=transition.fail_count,
        success_count=transition.success_count,
        disabled_proxy=transition.should_disable_proxy_now,
    )


def run_watchdog(
    api_port: int,
    *,
    listen_port: int | None = None,
    max_polls: int | None = None,
) -> int:
    """Watchdog main loop.

    Two ports, two purposes:
    * ``api_port`` — FastAPI ``/health`` endpoint, polled every
      :data:`_POLL_INTERVAL_SECONDS` for liveness.
    * ``listen_port`` — mitmproxy listener address stored against each
      macOS network service; used to identify which interfaces are
      pointed at the daemon and therefore need their proxy disabled
      on a freeze.

    For backward compatibility, ``listen_port`` defaults to ``api_port``
    when not supplied. Production callers (``main()`` and the
    ``halton-meter watchdog`` Click command) always pass both.

    Snapshots the macOS interfaces currently pointed at the listener,
    then polls ``/health`` every :data:`_POLL_INTERVAL_SECONDS`.
    Disables the system proxy exactly on the DEGRADING -> PROXY_DISABLED
    edge. Never re-enables — the daemon's startup path handles re-enable
    via the ``proxy-managed`` sentinel.

    Cold-start tolerance (2B.10.8): the watchdog gates the actual
    ``disable_system_proxy`` call on having observed *at least one*
    successful ``/health`` response since process start. The launchd
    ``RunAtLoad`` semantics race the daemon and the watchdog at boot and
    after ``halton-meter start``; the watchdog typically wins. Without
    this gate, the watchdog's first 5 polls during the daemon's cold
    start (Python 3.14 + uv module imports take ~3-5s before
    ``/health`` answers 200) would tick the state machine straight to
    PROXY_DISABLED and tear down the user's system proxy seconds after
    they ran ``halton-meter start``. The gate is a *loop-level* I/O
    concern, not a state-machine concern: ``WatchdogState`` stays
    pure-logic (four states, no STARTING). The state machine still
    emits ``should_disable_proxy_now`` on the DEGRADING ->
    PROXY_DISABLED edge as before; we just refuse to act on it until
    the daemon has proven it can answer at least once. Once the first
    success has been seen, the watchdog behaves exactly as designed —
    the gate latches on for the lifetime of the process.

    ``max_polls`` is for tests only; if set, the loop exits after that
    many iterations regardless of state.

    Returns 0 on graceful shutdown, 0 if no interfaces point at us at
    startup (nothing to watch).
    """
    if listen_port is None:
        listen_port = api_port
    interfaces = snapshot_interfaces(listen_port)
    if not interfaces:
        log.warning(
            "watchdog.no_interfaces_pointing_at_us",
            api_port=api_port,
            listen_port=listen_port,
            note=(
                "no macOS network service has its system proxy pointed at "
                "127.0.0.1:<listen_port>; watchdog has nothing to do — exiting"
            ),
        )
        return 0

    log.info(
        "watchdog.start",
        api_port=api_port,
        listen_port=listen_port,
        interfaces=interfaces,
        poll_interval_seconds=_POLL_INTERVAL_SECONDS,
        failure_threshold=_FAILURE_THRESHOLD,
        recovery_threshold=_RECOVERY_THRESHOLD,
    )

    machine = WatchdogStateMachine()
    # 2B.10.8: STARTING gate. Until we have seen at least one
    # successful /health response, refuse to disable the system proxy
    # even if the state machine fires PROXY_DISABLED. See run_watchdog
    # docstring for the cold-start race rationale.
    seen_first_success = False
    polls = 0
    while True:
        if max_polls is not None and polls >= max_polls:
            return 0

        success = poll_health(api_port)
        if success:
            seen_first_success = True
        transition = machine.record_health(success)
        if transition.should_disable_proxy_now and seen_first_success:
            disable_system_proxy(interfaces)
        elif transition.should_disable_proxy_now and not seen_first_success:
            # The state machine moved to PROXY_DISABLED, but we have
            # never confirmed the daemon was alive. Most likely the
            # watchdog won the cold-start race; do not punish the user
            # for that. Log so we can spot it in field logs.
            log.warning(
                "watchdog.suppressed_disable_during_cold_start",
                fail_count=transition.fail_count,
                note=(
                    "state machine reached PROXY_DISABLED before any "
                    "successful /health response; suppressing proxy "
                    "disable until daemon has proven liveness at least "
                    "once"
                ),
            )
        _log_transition(transition)

        polls += 1
        time.sleep(_POLL_INTERVAL_SECONDS)


# --------------------------------------------------------------------------- #
# CLI entry point                                                              #
# --------------------------------------------------------------------------- #


def _install_signal_handlers() -> None:
    """SIGINT/SIGTERM trigger a clean exit; the watchdog never touches
    the system proxy on shutdown — that's the daemon's job."""

    def _exit(signum: int, _frame: Any) -> None:
        log.info("watchdog.shutdown", signal=signum)
        sys.exit(0)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _exit)
        except (OSError, ValueError):
            # Some environments forbid signal installation; best-effort.
            pass


def poll_once(api_port: int) -> int:
    """Run a single health check and return 0 (healthy) or 1 (unhealthy)."""
    return 0 if poll_health(api_port) else 1


def main(api_port: int | None = None, listen_port: int | None = None) -> int:
    """Watchdog process entry point.

    Reads ``daemon.api_port`` and ``daemon.listen_port`` from config
    when not supplied. Distinct ports because ``/health`` lives on the
    FastAPI app (``api_port``, default 8765) but the system proxy on
    each interface points at the mitmproxy listener (``listen_port``,
    default 8080).
    """
    if api_port is None or listen_port is None:
        try:
            cfg = load_config()
            if api_port is None:
                api_port = cfg.daemon.api_port
            if listen_port is None:
                listen_port = cfg.daemon.listen_port
        except Exception:
            if api_port is None:
                api_port = 8765
            if listen_port is None:
                listen_port = 8080

    _install_signal_handlers()
    return run_watchdog(api_port, listen_port=listen_port)
