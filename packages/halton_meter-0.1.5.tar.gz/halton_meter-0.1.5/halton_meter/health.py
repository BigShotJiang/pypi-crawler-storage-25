"""Shared health-check primitives (v0.1.3 P0-6).

Self-contained probes used by ``init``'s self-test phase and by
``halton-meter doctor``. Every probe is pure: it returns a result object
with a verdict + concrete next-action message; it never raises and never
mutates state.

Result shape: ``HealthCheck(name, ok, message, severity)``.

* ``severity == "fatal"`` — the check failure invalidates the install
  (init self-test will roll back).
* ``severity == "warn"`` — the check failed but the install is usable
  (init self-test will surface but not roll back).
* ``severity == "info"`` — purely informational; never fails.
"""

from __future__ import annotations

import os
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class HealthCheck:
    name: str
    ok: bool
    message: str
    severity: str = "fatal"  # "fatal" | "warn" | "info"


def check_daemon_health(api_host: str, api_port: int, timeout: float = 30.0) -> HealthCheck:
    """Daemon /health returns 200 within ``timeout`` seconds.

    Polls every 500ms until the daemon's HTTP API answers or the window
    elapses. A single ``urlopen`` is insufficient because the OS returns
    ``ECONNREFUSED`` instantly when the port is not yet bound, and Python
    3.14 cold-start can take 6-8s before uvicorn starts listening.
    """
    url = f"http://{api_host}:{api_port}/health"
    deadline = time.monotonic() + timeout
    last_exc: str = ""
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2.0) as resp:
                if 200 <= resp.status < 300:
                    return HealthCheck("Daemon /health", True, f"{url} -> 200")
                last_exc = f"non-2xx response: {resp.status}"
        except (urllib.error.URLError, OSError, ValueError) as exc:
            last_exc = str(exc)
        time.sleep(0.5)
    return HealthCheck(
        "Daemon /health",
        False,
        f"daemon /health did not respond on {url} within {timeout:.0f}s: {last_exc}",
    )


def check_cert_trusted_macos() -> HealthCheck:
    """``security verify-cert -p ssl`` rc=0 (P0-1)."""
    from halton_meter.setup import _is_cert_trusted_macos

    if _is_cert_trusted_macos():
        return HealthCheck(
            "Cert trust", True, "macOS SecTrust verifies the mitmproxy CA for SSL"
        )
    return HealthCheck(
        "Cert trust",
        False,
        "macOS SecTrust does NOT trust the mitmproxy CA for SSL "
        "(run `halton-meter setup --force` to retry)",
    )


def check_port_persisted(
    *,
    runtime_toml: Path | None = None,
    config_toml: Path | None = None,
) -> HealthCheck:
    """Either runtime.toml exists OR config.toml has an explicit listen_port pin."""
    from halton_meter.port_alloc import (
        CONFIG_TOML_PATH,
        RUNTIME_TOML_PATH,
        _read_explicit_keys_from_config_toml,
    )

    rt = runtime_toml or RUNTIME_TOML_PATH
    cfg = config_toml or CONFIG_TOML_PATH
    if rt.exists():
        return HealthCheck(
            "Port allocation persisted",
            True,
            f"runtime.toml present at {rt}",
        )
    listen_pinned, _api_pinned = _read_explicit_keys_from_config_toml(cfg)
    if listen_pinned:
        return HealthCheck(
            "Port allocation persisted",
            True,
            f"config.toml pins listen_port at {cfg}",
        )
    # Defaults are fine when both ports were free; absence of runtime.toml
    # is the expected state. Not fatal.
    return HealthCheck(
        "Port allocation persisted",
        True,
        "using defaults (8080 / 8765); no runtime.toml needed",
        severity="info",
    )


def check_install_mode_sentinel(
    *, sentinel_path: Path | None = None
) -> HealthCheck:
    """Install-mode sentinel present and parseable."""
    from halton_meter import init as init_module

    target = sentinel_path or init_module.INSTALL_MODE_PATH
    mode = init_module.read_install_mode()
    if mode is None:
        return HealthCheck(
            "Install-mode sentinel",
            False,
            f"sentinel missing or unparseable at {target}",
        )
    return HealthCheck(
        "Install-mode sentinel", True, f"{target} contains {mode!r}"
    )


def check_plists_loaded_macos(*, label: str = "com.haltonlabs.meter") -> HealthCheck:
    """``launchctl list <label>`` reports a live PID (not '-')."""
    from halton_meter.cli import _launchctl_managed_pid

    pid = _launchctl_managed_pid(label)
    if pid is None:
        return HealthCheck(
            "Daemon plist registered",
            False,
            f"launchctl reports no live PID for {label}",
        )
    return HealthCheck(
        "Daemon plist registered", True, f"PID {pid}"
    )


def check_system_proxy_points_at_us(
    *, listen_host: str, listen_port: int
) -> HealthCheck:
    """At least one macOS interface's system proxy points at our listener.

    Only meaningful in --gui mode; init's self-test calls this conditionally.
    """
    from halton_meter import system_proxy

    for iface in system_proxy._macos_interfaces():
        for secure in (True, False):
            enabled, host, port = system_proxy._read_macos_proxy(iface, secure=secure)
            if enabled and system_proxy._proxy_targets_us(
                host, port, listen_host, listen_port
            ):
                return HealthCheck(
                    "System proxy points at us",
                    True,
                    f"{iface} -> {host}:{port}",
                )
    return HealthCheck(
        "System proxy points at us",
        False,
        "no interface's system proxy points at the daemon "
        "(re-run `halton-meter init --gui`)",
    )


def check_launchctl_env_var(
    *, key: str = "HTTPS_PROXY", expected_substr: str | None = None
) -> HealthCheck:
    """``launchctl getenv <key>`` returns a value (optionally containing
    ``expected_substr``).

    Only meaningful in --gui mode.
    """
    from halton_meter.system_proxy import getenv_user_domain

    value = getenv_user_domain(key)
    if value is None:
        return HealthCheck(
            f"launchctl env: {key}",
            False,
            f"`launchctl getenv {key}` returned no value",
        )
    if expected_substr and expected_substr not in value:
        return HealthCheck(
            f"launchctl env: {key}",
            False,
            f"`launchctl getenv {key}` -> {value!r}, expected to contain "
            f"{expected_substr!r}",
        )
    return HealthCheck(f"launchctl env: {key}", True, f"{key}={value}")


def check_can_listen(host: str, port: int) -> HealthCheck:
    """Light TCP connect probe to confirm the proxy listener accepts."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2.0)
    try:
        sock.connect((host, port))
    except (TimeoutError, OSError) as exc:
        return HealthCheck(
            "Proxy listener reachable",
            False,
            f"connect({host}:{port}) failed: {exc}",
        )
    finally:
        sock.close()
    return HealthCheck(
        "Proxy listener reachable", True, f"{host}:{port} accepted TCP"
    )


def shell_env_present() -> dict[str, str | None]:
    """Snapshot the shell-level metering env vars from the current process.

    Returns a dict of ``{key: value or None}`` for diagnostic display.
    Used by ``halton-meter doctor`` to surface "did the user source the
    rc file" without requiring a clean subshell.
    """
    keys = (
        "HTTPS_PROXY",
        "HTTP_PROXY",
        "NO_PROXY",
        "NODE_EXTRA_CA_CERTS",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
    )
    return {k: os.environ.get(k) for k in keys}
