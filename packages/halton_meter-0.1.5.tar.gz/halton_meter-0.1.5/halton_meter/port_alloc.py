"""Auto-port-fallback (v0.1.3 P0-5).

The daemon can collide with another local service on its default ports
(8080 for the proxy listener, 8765 for the FastAPI HTTP API). v0.1.0/0.1.1
crashed on bind, and v0.1.2's preflight refused to start. v0.1.3 instead
auto-allocates the first free port in a small window when the user has
NOT explicitly pinned a port in ``~/.halton-meter/config.toml``.

Design:

* ``allocate_ports(cfg, *, listen_explicit, api_explicit)`` returns the
  ports the daemon should actually bind to. If a port is explicitly
  pinned in config.toml, it is honoured (and the daemon will fail-fast on
  bind clash with a clear error rather than silently re-binding). If a
  port is not pinned, we probe ``defaults..defaults+9`` and pick the first
  one that accepts a TCP listener bind on 127.0.0.1.
* The chosen ports are persisted to ``~/.halton-meter/runtime.toml``
  ONLY when discovery actually picked a non-default port. Re-reading the
  same persisted port across daemon restarts gives a stable identity
  (the dashboard's ``NEXT_PUBLIC_API_URL`` doesn't drift).
* ``load_effective_config()`` overlays sources in precedence:
  defaults < runtime.toml < config.toml. (User-written config beats
  runtime; runtime overrides defaults; runtime persists last-known-good.)

Stable identity contract: if the user pins ``listen_port = 8080`` in
config.toml AND the port is unavailable, the daemon will fail-fast with
a clear error. We do NOT silently relocate a pinned port — that would
break the user's mental model and any external clients pointing at the
pinned port.
"""

from __future__ import annotations

import socket
import tomllib
from pathlib import Path

from halton_meter.config import HaltonConfig

# Ports we are willing to probe when the default is busy.
# v0.1.4 (2B.15) P0-5: exposed publicly so status / doctor / init can
# compare the effective port to the default and surface a fallback hint
# without duplicating the constant.
LISTEN_PORT_DEFAULT = 8080
API_PORT_DEFAULT = 8765
# Private aliases preserved for back-compat with the v0.1.3 module
# internals.
_LISTEN_PORT_DEFAULT = LISTEN_PORT_DEFAULT
_LISTEN_PORT_PROBE_RANGE = 10  # 8080..8089 inclusive (10 ports)
_API_PORT_DEFAULT = API_PORT_DEFAULT
_API_PORT_PROBE_RANGE = 10  # 8765..8774 inclusive (10 ports)

RUNTIME_TOML_PATH = Path("~/.halton-meter/runtime.toml").expanduser()
CONFIG_TOML_PATH = Path("~/.halton-meter/config.toml").expanduser()


def _is_port_free(host: str, port: int) -> bool:
    """Return True iff a TCP listener bind on (host, port) succeeds.

    The probe binds and closes immediately; SO_REUSEADDR is not set so
    we observe the same EADDRINUSE the daemon would. macOS / Linux /
    Windows: same behaviour at the BSD socket layer.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((host, port))
    except OSError:
        return False
    finally:
        sock.close()
    return True


def _probe_port(host: str, default_port: int, probe_range: int) -> int | None:
    """Probe ``default_port .. default_port + probe_range - 1``. Returns the
    first free port, or ``None`` if every candidate is busy."""
    for offset in range(probe_range):
        candidate = default_port + offset
        if _is_port_free(host, candidate):
            return candidate
    return None


def _read_explicit_keys_from_config_toml(path: Path) -> tuple[bool, bool]:
    """Inspect raw config.toml; return (listen_pinned, api_pinned).

    A port is "pinned" when the user has written it explicitly under
    ``[daemon]``. Pydantic's defaults synthesise the same values into
    ``HaltonConfig`` regardless, so we can't tell from the model — we
    have to look at the raw TOML.
    """
    if not path.exists():
        return False, False
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return False, False
    daemon_tbl = raw.get("daemon", {}) or {}
    return ("listen_port" in daemon_tbl), ("api_port" in daemon_tbl)


def _read_runtime_toml(path: Path) -> dict[str, int]:
    """Return ``{"listen_port": ..., "api_port": ...}`` from runtime.toml,
    or an empty dict if the file is missing / unparseable."""
    if not path.exists():
        return {}
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except (tomllib.TOMLDecodeError, OSError):
        return {}
    daemon_tbl = raw.get("daemon", {}) or {}
    out: dict[str, int] = {}
    for key in ("listen_port", "api_port"):
        val = daemon_tbl.get(key)
        if isinstance(val, int):
            out[key] = val
    return out


def _write_runtime_toml(
    path: Path, *, listen_port: int, api_port: int
) -> None:
    """Atomically write ``runtime.toml`` with the chosen ports.

    Hand-rolled TOML — the file is tiny (one section, two int keys) so a
    full TOML emitter (tomli-w / tomlkit) would add a dependency we
    don't otherwise need. The format is human-readable and tomllib-
    parseable; covered by ``test_runtime_toml_round_trip``.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    body = (
        "# Halton Meter — runtime-discovered port allocation (P0-5).\n"
        "# Written by the daemon at startup; do not edit by hand.\n"
        "# To pin a port, edit ~/.halton-meter/config.toml instead.\n"
        "\n"
        "[daemon]\n"
        f"listen_port = {int(listen_port)}\n"
        f"api_port = {int(api_port)}\n"
    )
    tmp = path.with_suffix(".tmp")
    tmp.write_text(body, encoding="utf-8")
    tmp.replace(path)


def remove_runtime_toml(path: Path | None = None) -> None:
    """Remove ``runtime.toml``. Idempotent. Used by ``halton-meter
    uninstall``."""
    target = path or RUNTIME_TOML_PATH
    try:
        target.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def allocate_ports(
    cfg: HaltonConfig,
    *,
    listen_pinned: bool,
    api_pinned: bool,
    runtime_path: Path | None = None,
    persist: bool = True,
) -> tuple[int, int]:
    """Return ``(listen_port, api_port)`` honouring the precedence:

      1. config.toml pin (when ``listen_pinned`` / ``api_pinned`` is True)
      2. probe + first-free in ``default .. default + probe_range - 1``
         (defaults: 8080..8089 for listen, 8765..8774 for api)
      3. fall back to default if every candidate is busy (the daemon
         will then surface a clear bind error; we prefer noisy failure
         over silent confusion)

    When ``persist=True`` and discovery picked any non-default value,
    the chosen pair is written to ``runtime_path`` (default
    ``RUNTIME_TOML_PATH``) so subsequent daemon restarts converge on the
    same pair. When both ports are at their defaults, no write happens
    (avoids stamping a redundant runtime.toml on a clean default install).
    """
    runtime_target = runtime_path or RUNTIME_TOML_PATH
    host = cfg.daemon.listen_host

    if listen_pinned:
        listen_port = int(cfg.daemon.listen_port)
    else:
        candidate = _probe_port(host, _LISTEN_PORT_DEFAULT, _LISTEN_PORT_PROBE_RANGE)
        listen_port = candidate if candidate is not None else _LISTEN_PORT_DEFAULT

    api_host = cfg.daemon.api_host
    if api_pinned:
        api_port = int(cfg.daemon.api_port)
    else:
        candidate = _probe_port(api_host, _API_PORT_DEFAULT, _API_PORT_PROBE_RANGE)
        api_port = candidate if candidate is not None else _API_PORT_DEFAULT

    if persist and (
        listen_port != _LISTEN_PORT_DEFAULT
        or api_port != _API_PORT_DEFAULT
    ):
        try:
            _write_runtime_toml(
                runtime_target, listen_port=listen_port, api_port=api_port
            )
        except OSError:
            # Persistence is best-effort. A read-only home / disk-full case
            # falls through with the in-memory ports still correct.
            pass

    return listen_port, api_port


def load_effective_config(
    *,
    config_path: Path | None = None,
    runtime_path: Path | None = None,
) -> HaltonConfig:
    """Return a ``HaltonConfig`` whose daemon ports reflect the precedence:

        defaults < runtime.toml < config.toml

    This is what every read site (status, doctor, the run wrapper, the
    daemon's own startup) should call instead of ``load_config`` directly.
    The daemon's startup code path additionally calls ``allocate_ports``
    BEFORE this — discovering and persisting the runtime.toml pair when
    no user pin is in place — so the next call here picks them up.
    """
    cfg_path = config_path or CONFIG_TOML_PATH
    rt_path = runtime_path or RUNTIME_TOML_PATH

    # Start from defaults via HaltonConfig().
    base = HaltonConfig()

    # Overlay runtime.toml.
    rt = _read_runtime_toml(rt_path)
    listen_port = rt.get("listen_port", base.daemon.listen_port)
    api_port = rt.get("api_port", base.daemon.api_port)

    # Overlay config.toml (highest precedence).
    listen_pinned, api_pinned = _read_explicit_keys_from_config_toml(cfg_path)
    if cfg_path.exists():
        try:
            with cfg_path.open("rb") as fh:
                user_raw = tomllib.load(fh)
        except (tomllib.TOMLDecodeError, OSError):
            user_raw = {}
        user_daemon = user_raw.get("daemon", {}) or {}
        if listen_pinned:
            listen_port = int(user_daemon["listen_port"])
        if api_pinned:
            api_port = int(user_daemon["api_port"])

    # Fold into a fresh HaltonConfig. We rebuild the daemon section to
    # honour the resolved ports while preserving any other config.toml
    # keys we may have parsed.
    from halton_meter.config import (
        CorsConfig,
        DaemonConfig,
        StorageConfig,
        SyncConfig,
    )
    from halton_meter.config import HaltonConfig as _HC

    user_daemon_kw: dict[str, object] = {}
    if cfg_path.exists():
        try:
            with cfg_path.open("rb") as fh:
                full_raw = tomllib.load(fh)
        except (tomllib.TOMLDecodeError, OSError):
            full_raw = {}
        user_daemon_kw = dict(full_raw.get("daemon", {}) or {})
        # Strip listen_port / api_port from kwargs since we're injecting
        # the resolved values; everything else (host, log_path) flows
        # through.
        user_daemon_kw.pop("listen_port", None)
        user_daemon_kw.pop("api_port", None)

    daemon_cfg = DaemonConfig(
        **user_daemon_kw,
        listen_port=listen_port,
        api_port=api_port,
    )

    # Other sections come straight from load_config so we don't lose
    # storage / sync / cors keys.
    other_storage = base.storage
    other_sync = base.sync
    other_cors = base.cors
    if cfg_path.exists():
        try:
            with cfg_path.open("rb") as fh:
                full_raw = tomllib.load(fh)
            if "storage" in full_raw:
                other_storage = StorageConfig.model_validate(full_raw["storage"])
            if "sync" in full_raw:
                other_sync = SyncConfig.model_validate(full_raw["sync"])
            if "cors" in full_raw:
                other_cors = CorsConfig.model_validate(full_raw["cors"])
        except (tomllib.TOMLDecodeError, OSError):
            pass

    return _HC(
        daemon=daemon_cfg,
        storage=other_storage,
        sync=other_sync,
        cors=other_cors,
    )


def discover_and_persist_ports(
    *,
    config_path: Path | None = None,
    runtime_path: Path | None = None,
    persist: bool = True,
) -> tuple[int, int]:
    """Convenience wrapper used by the daemon's startup + by init.

    Reads the user's config.toml (to detect pins), probes the default
    range for whichever port isn't pinned, persists runtime.toml when
    appropriate, and returns the chosen ``(listen_port, api_port)``.
    """
    cfg_path = config_path or CONFIG_TOML_PATH
    rt_path = runtime_path or RUNTIME_TOML_PATH

    listen_pinned, api_pinned = _read_explicit_keys_from_config_toml(cfg_path)
    cfg = load_effective_config(config_path=cfg_path, runtime_path=rt_path)
    return allocate_ports(
        cfg,
        listen_pinned=listen_pinned,
        api_pinned=api_pinned,
        runtime_path=rt_path,
        persist=persist,
    )
