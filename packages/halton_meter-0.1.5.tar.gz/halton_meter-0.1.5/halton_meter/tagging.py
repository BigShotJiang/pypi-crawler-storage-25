"""
Project tagging for Halton Meter daemon.

Resolves a project name for a given mitmproxy flow using the following
precedence (first match wins):

  1. HALTON_PROJECT environment variable on the originating process
  2. .haltonrc file in the originating process's working directory or
     any parent directory (walk upward until filesystem root)
  3. Originating process's working directory basename
  4. Literal string "unknown"

The originating process's working directory is obtained via psutil
(looking up the PID of the connecting process from the flow).
If psutil lookup fails for any reason, we fall back to os.getcwd().

This function is intentionally synchronous — it runs in the mitmproxy
proxy hot path and must be fast. All I/O is filesystem-only (no network,
no DB writes).

Decision reference: memory/decisions.md 2026-04-28 — "Project tagging
precedence: env var over .haltonrc"
"""

from __future__ import annotations

import os
from pathlib import Path

import structlog

log = structlog.get_logger()

_RCFILE_NAME = ".haltonrc"
_ENV_VAR = "HALTON_PROJECT"


def _get_process_cwd(flow: object) -> str:
    """
    Attempt to resolve the working directory of the process that opened
    the connection represented by the given flow.

    Uses psutil to look up the client PID from the flow's client connection.
    Falls back to os.getcwd() on any failure.
    """
    try:
        import psutil  # type: ignore[import-untyped]
        from mitmproxy import http  # type: ignore[import-untyped]

        if not isinstance(flow, http.HTTPFlow):
            return os.getcwd()

        client_conn = flow.client_conn
        # client_conn.peername is (host, port) for the connecting client
        # For local processes this is the loopback address.
        # We look up by port to find the owning PID.
        client_port: int | None = None
        if client_conn.peername:
            client_port = client_conn.peername[1]

        if client_port is None:
            return os.getcwd()

        # Walk all connections to find the process owning this port.
        # psutil 6+ uses net_connections() as a method; older versions exposed
        # "connections" as a process_iter attr. Try both.
        for proc in psutil.process_iter(["pid"]):
            try:
                try:
                    conns = proc.net_connections()   # psutil >= 6.0
                except AttributeError:
                    conns = proc.connections()       # psutil < 6.0
                for conn in conns:
                    if hasattr(conn, "laddr") and conn.laddr and conn.laddr.port == client_port:
                        return proc.cwd()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

    except Exception as exc:
        log.debug("tagging.cwd_lookup_failed", error=str(exc))

    return os.getcwd()


def _read_haltonrc(start_dir: str) -> str | None:
    """
    Walk from start_dir upward, looking for a .haltonrc file.

    File format (simple line scan — no YAML parser dependency):
        project: my-project-name

    Returns the project name if found and non-empty, or None.
    """
    current = Path(start_dir).resolve()
    while True:
        rc_file = current / _RCFILE_NAME
        if rc_file.is_file():
            try:
                content = rc_file.read_text(encoding="utf-8")
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("project:"):
                        value = stripped[len("project:"):].strip()
                        if value:
                            log.debug(
                                "tagging.rcfile_found",
                                path=str(rc_file),
                                project=value,
                            )
                            return value
            except OSError as exc:
                log.debug("tagging.rcfile_read_error", path=str(rc_file), error=str(exc))

        parent = current.parent
        if parent == current:
            # Reached filesystem root
            break
        current = parent

    return None


def resolve_project(flow: object) -> str:
    """
    Resolve the project name for a given mitmproxy HTTPFlow.

    Precedence:
      1. HALTON_PROJECT environment variable on the originating process
         (read from os.environ — the daemon process's environment reflects
         the system environment at startup; for true per-process env lookup
         we would need psutil, but env var is typically set at daemon level
         or exported before starting the proxy client process)
      2. .haltonrc file found by walking upward from the originating
         process's working directory
      3. Basename of the originating process's working directory
      4. "unknown"

    The attribution method is logged so debugging is possible.
    """
    # Step 1 — HALTON_PROJECT env var
    env_project = os.environ.get(_ENV_VAR, "").strip()
    if env_project:
        log.debug("tagging.resolved", method="env", project=env_project)
        return env_project

    # Determine the originating process's working directory
    try:
        cwd = _get_process_cwd(flow)
    except Exception as exc:
        log.debug("tagging.cwd_error", error=str(exc))
        cwd = os.getcwd()

    # Step 2 — .haltonrc walk
    rc_project = _read_haltonrc(cwd)
    if rc_project:
        log.debug("tagging.resolved", method="rcfile", project=rc_project, cwd=cwd)
        return rc_project

    # Step 3 — workdir basename
    basename = Path(cwd).name
    if basename:
        log.debug("tagging.resolved", method="workdir", project=basename, cwd=cwd)
        return basename

    # Step 4 — unknown
    log.debug("tagging.resolved", method="unknown", cwd=cwd)
    return "unknown"
