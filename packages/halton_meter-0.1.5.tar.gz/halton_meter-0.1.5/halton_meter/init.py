"""First-run UX orchestrator: ``halton-meter init``.

Phase 2B.7. Closes the "I forgot to run setup after install" footgun
by chaining the existing :mod:`halton_meter.setup`,
:func:`halton_meter.system_proxy.enable_system_proxy_if_managed`, and
:func:`halton_meter.install.install` into a single command with proper
admin elevation and a Rich-rendered summary.

v0.1.3 mode pivot (P0-3): two install modes are supported.

* env-var-only (default — no flag): cert + certifi + plists. NO system-
  proxy enable, NO launchctl setenv, NO shell-rc append. Coverage is
  scoped to whatever the user explicitly routes via ``halton-meter run
  <command>``. Cannot break browsers / GUI apps because we never touch
  their proxy state.
* ``--gui``: env-var-only PLUS system-proxy enable PLUS launchctl
  setenv user-domain (so GUI apps spawned via Spotlight/Dock see the
  proxy + cert env vars) PLUS optional idempotent shell-rc append.
  Broader coverage; may break HSTS browser sites if the cert isn't
  trusted by SecTrust at TLS evaluation time (the P0-1 cert-trust
  invariant catches that and refuses to flip the system proxy on).

The single source of truth for which mode the user is on is
``~/.halton-meter/install-mode`` (file content: ``gui`` or ``env-only``).
``halton-meter uninstall`` reads it and only reverses what was set up.

Pure orchestrator — no new functionality lives here that isn't a thin
wrapper over the existing modules. Idempotent; each step independently
resumable. See ``memory/decisions.md`` 2026-04-29 entry "Phase 2B.7
first-run UX design" for the architectural decisions.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import structlog
from rich.console import Console
from rich.panel import Panel

log = structlog.get_logger()

# Exit codes
_EXIT_OK = 0
_EXIT_SETUP_FAILED = 1
_EXIT_PROXY_FAILED = 1
_EXIT_INSTALL_FAILED = 1
_EXIT_SUDO_NOT_PRECACHED = 2

_DAEMON_LABEL = "com.haltonlabs.meter"

# v0.1.3 P0-3 — install-mode sentinel.
# v0.1.5 (2B.16): three-mode model. ``apps`` is new (shell-rc +
# launchctl env, NO system proxy — covers terminals + apps spawned from
# them, but does NOT touch browser / GUI-app traffic). ``full`` is the
# new canonical name for what v0.1.3/v0.1.4 called ``gui`` (everything:
# system proxy + launchctl env + shell-rc). ``MODE_GUI`` is kept as a
# read-only legacy alias — the migration helper rewrites the sentinel
# from ``gui`` to ``full`` on next ``init``.
INSTALL_MODE_PATH = Path("~/.halton-meter/install-mode").expanduser()
MODE_ENV_ONLY = "env-only"
MODE_APPS = "apps"
MODE_FULL = "full"
MODE_GUI = "gui"  # legacy alias for ``full``; v0.1.3/v0.1.4 sentinel value.

# Canonical mode set (the only values ever WRITTEN to the sentinel).
_CANONICAL_MODES = (MODE_ENV_ONLY, MODE_APPS, MODE_FULL)
# Legacy mode set (read-tolerant; mapped onto a canonical mode).
_LEGACY_MODE_ALIASES = {MODE_GUI: MODE_FULL}

# v0.1.3 P0-3 — idempotent shell-rc append. Marker comments bracket the block
# we own; any block found between these markers is replaced when the user
# re-runs init, and removed when the user uninstalls.
SHELL_RC_BLOCK_BEGIN = "# >>> halton-meter env vars (managed) >>>"
SHELL_RC_BLOCK_END = "# <<< halton-meter env vars (managed) <<<"


def _detect_live_daemon() -> bool:
    """Return True if launchd reports a live ``com.haltonlabs.meter`` agent.

    Uses ``launchctl print gui/<uid>/<label>`` rather than
    ``launchctl list | grep`` — the print form returns a non-zero exit
    code when the label is unknown, which is more reliable than parsing
    list output. macOS-only; returns False on other platforms.
    """
    if sys.platform != "darwin":
        return False
    try:
        uid = os.getuid()
    except AttributeError:
        return False
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{_DAEMON_LABEL}"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _sudo_pre_cached() -> bool:
    """Return True if a non-interactive ``sudo -n true`` succeeds.

    Used in non-interactive mode to detect the keychain-trust footgun
    early: when osascript is unavailable, ``setup.run_setup`` falls
    back to ``sudo security ...`` which deadlocks on a sudo password
    prompt when there is no TTY.
    """
    try:
        result = subprocess.run(
            ["sudo", "-n", "true"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _osascript_available_for_init() -> bool:
    """Return True iff ``osascript`` is on PATH (macOS-only check).

    v0.1.4 (2B.15) P0-2: the cert-trust step prefers the osascript GUI
    admin dialog. When osascript is present (the normal case on every
    macOS install), the init flow can elevate without pre-cached
    sudo — so the preflight should not bail on
    ``not _sudo_pre_cached()`` alone.

    Test seam: separate from setup._osascript_available so init's
    fixtures don't have to monkey-patch the setup module.
    """
    import shutil

    return shutil.which("osascript") is not None


def _render_panel_success(
    console: Console,
    *,
    setup_done: bool,
    install_done: bool,
    mode: str,
    proxy_done: bool = False,
    setenv_done: bool = False,
    shell_rc_status: str | None = None,
    proxy_skipped_running_daemon: bool = False,
    listen_port: int | None = None,
    api_port: int | None = None,
) -> None:
    """Render the post-init success panel.

    v0.1.4 (2B.15) extras:
      * P0-5: when ``listen_port`` / ``api_port`` differ from the
        marketed defaults, surface the auto-fallback inline so the
        user knows their tools must target the actual port.
      * P0-6: env-var-only success footer now includes a
        copy-pasteable "Try it now" block — a smoke-test command and
        a follow-up report command — so a brand-new user can confirm
        end-to-end metering works in two commands.
    """
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    icon = lambda done: "[green]✓[/green]" if done else "[red]✗[/red]"  # noqa: E731
    install_label = "OS supervisor (launchd / systemd)"
    if proxy_skipped_running_daemon:
        install_label += " [yellow](skipped — live daemon running)[/yellow]"

    rows = [
        f"{icon(setup_done)}  [bold]Cert + keychain trust + certifi patched[/bold]",
        f"{icon(install_done)}  [bold]{install_label}[/bold]",
    ]

    # P0-5: surface auto-port-fallback when applicable. Always show the
    # row so the user knows which ports the daemon picked.
    if listen_port is not None and api_port is not None:
        listen_fallback = listen_port != LISTEN_PORT_DEFAULT
        api_fallback = api_port != API_PORT_DEFAULT
        if listen_fallback or api_fallback:
            rows.append(
                f"[yellow]~[/yellow]  [bold]Effective ports:[/bold] "
                f"proxy=:{listen_port}, api=:{api_port} "
                f"[yellow](fallback from busy default "
                f":{LISTEN_PORT_DEFAULT}/:{API_PORT_DEFAULT})[/yellow]"
            )
        else:
            rows.append(
                f"[green]✓[/green]  [bold]Effective ports:[/bold] "
                f"proxy=:{listen_port}, api=:{api_port}"
            )

    # v0.1.5 (2B.16): three-mode rendering. ``apps`` mode shows
    # launchctl env + shell-rc but not the system-proxy row;
    # ``full`` mode shows all three.
    if mode == MODE_FULL:
        rows.append(
            f"{icon(proxy_done)}  [bold]System proxy enabled (--full mode)[/bold]"
        )
    if mode in (MODE_APPS, MODE_FULL):
        rows.append(
            f"{icon(setenv_done)}  [bold]launchctl setenv user-domain "
            "(GUI/Spotlight app coverage)[/bold]"
        )
        if shell_rc_status is not None:
            rc_icon = "[green]✓[/green]" if shell_rc_status in (
                "appended", "replaced", "unchanged",
            ) else "[yellow]~[/yellow]"
            label = {
                "appended": "appended to shell rc",
                "replaced": "shell rc block updated",
                "unchanged": "shell rc already up to date",
                "missing-rc": "shell rc not found — skipped",
                "skipped": "skipped (--no-shell-rc / non-interactive)",
                "declined": "skipped (user declined)",
            }.get(shell_rc_status, shell_rc_status)
            rows.append(f"{rc_icon}  [bold]Shell rc: {label}[/bold]")

    if mode == MODE_ENV_ONLY:
        # P0-6: try-it-now block. Pick a smoke-test target the user is
        # likely to recognise and that doesn't make a real LLM call —
        # https://api.anthropic.com/v1/messages without an API key
        # returns a 401 from Anthropic, which is captured by the
        # daemon and shows up in the SQLite log. Even without
        # Anthropic auth, the captured row demonstrates "the daemon
        # is intercepting traffic for the right host".
        footer = (
            "\n[bold]env-var-only mode.[/bold] To meter a CLI / SDK client:\n"
            "  [dim]halton-meter run claude[/dim]                        "
            "# meter Claude Code\n"
            "  [dim]halton-meter run -- python my_script.py[/dim]        "
            "# meter an SDK script\n"
            "  [dim]halton-meter run --shell[/dim]                       "
            "# interactive subshell\n\n"
            "[bold]Try it now (smoke test):[/bold]\n"
            "  [dim]halton-meter run -- curl -sS https://api.anthropic.com/v1/messages "
            "-o /dev/null[/dim]\n"
            "  [dim]halton-meter report[/dim]                            "
            "# inspect captured rows\n\n"
            "For terminal + Spotlight-app coverage, re-run "
            "[bold]halton-meter init --apps[/bold].\n"
            "For broadest coverage (browsers + GUI apps), re-run "
            "[bold]halton-meter init --full[/bold]."
        )
    elif mode == MODE_APPS:
        footer = (
            "\n[bold]--apps mode.[/bold] launchctl env vars + shell-rc block are "
            "live; new shells and apps spawned from Spotlight/Dock will be "
            "metered. System proxy is NOT enabled — browser HTTPS traffic flows "
            "direct.\n"
            "  [dim]halton-meter status[/dim] reports daemon + watchdog health.\n"
            "For browser coverage (system proxy), re-run "
            "[bold]halton-meter init --full[/bold]."
        )
    else:  # MODE_FULL
        footer = (
            "\n[bold]--full mode.[/bold] System proxy + launchctl env + shell-rc "
            "are live; browsers and GUI apps spawned via Spotlight / Dock will "
            "be metered.\n"
            "  [dim]halton-meter status[/dim] reports daemon + watchdog health."
        )

    body = "\n".join(rows) + "\n" + footer
    border = "green" if (setup_done and install_done) else "yellow"
    console.print(
        Panel(
            body,
            title=f"halton-meter init ({mode})",
            border_style=border,
            expand=False,
        )
    )


def _render_panel_failure(console: Console, title: str, message: str) -> None:
    console.print(
        Panel(
            message,
            title=f"halton-meter init — {title}",
            border_style="red",
            expand=False,
        )
    )


# --------------------------------------------------------------------------- #
# Install-mode sentinel + GUI-only helpers (v0.1.3 P0-3)                       #
# --------------------------------------------------------------------------- #


def write_install_mode(mode: str) -> None:
    """Write the install-mode sentinel atomically.

    ``mode`` must be one of the canonical modes (``MODE_ENV_ONLY``,
    ``MODE_APPS``, ``MODE_FULL``). Legacy ``MODE_GUI`` is rejected here
    on write — the migration path is read-side only (see
    :func:`read_install_mode`). Best-effort: a write failure is logged
    but not raised — the daemon's ``proxy-managed`` sentinel (handled
    separately by ``setup.run_setup(managed=...)``) is the load-bearing
    gate. Install-mode is a hint for uninstall + doctor.
    """
    if mode not in _CANONICAL_MODES:
        raise ValueError(
            f"unknown install mode: {mode!r}; "
            f"expected one of {_CANONICAL_MODES}"
        )
    try:
        INSTALL_MODE_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = INSTALL_MODE_PATH.with_suffix(".tmp")
        tmp.write_text(mode + "\n", encoding="utf-8")
        os.replace(tmp, INSTALL_MODE_PATH)
    except OSError as exc:
        log.warning("init.install_mode.write_failed", mode=mode, error=str(exc))


def read_install_mode() -> str | None:
    """Read the install-mode sentinel. Returns ``None`` if absent / unreadable.

    v0.1.5 (2B.16) migration: a sentinel value of ``"gui"`` (the
    v0.1.3/v0.1.4 name) is read-tolerated and reported as the new
    canonical name ``"full"`` — without rewriting the file. The
    ``init`` flow calls :func:`migrate_legacy_mode_sentinel` on entry
    so the on-disk file is rewritten to ``"full"`` on the next init
    run; until that rewrite, every reader sees the canonical name.
    """
    try:
        if not INSTALL_MODE_PATH.exists():
            return None
        content = INSTALL_MODE_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if content in _CANONICAL_MODES:
        return content
    if content in _LEGACY_MODE_ALIASES:
        canonical = _LEGACY_MODE_ALIASES[content]
        log.info(
            "init.install_mode.legacy_alias_read",
            stored=content,
            reported=canonical,
        )
        return canonical
    return None


def migrate_legacy_mode_sentinel() -> str | None:
    """v0.1.5 (2B.16): rewrite a legacy ``gui`` sentinel to ``full``.

    Idempotent: a no-op when the on-disk sentinel is already canonical
    (or absent / unreadable). Returns the legacy value that was found
    (e.g. ``"gui"``) when a rewrite happened, or ``None`` otherwise —
    callers can use the return value to log a one-line deprecation
    notice in the init flow output.

    Best-effort: any write failure is logged and swallowed; the
    read path still maps the legacy alias to the canonical name on
    every read, so a rewrite failure here does not block correct
    behaviour downstream.
    """
    try:
        if not INSTALL_MODE_PATH.exists():
            return None
        content = INSTALL_MODE_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if content not in _LEGACY_MODE_ALIASES:
        return None
    canonical = _LEGACY_MODE_ALIASES[content]
    try:
        write_install_mode(canonical)
    except (OSError, ValueError) as exc:
        log.warning(
            "init.install_mode.migrate_failed",
            stored=content,
            error=str(exc),
        )
        return None
    log.info(
        "init.install_mode.migrated",
        stored=content,
        rewritten=canonical,
    )
    return content


def remove_install_mode() -> None:
    """Remove the install-mode sentinel. Idempotent."""
    try:
        INSTALL_MODE_PATH.unlink()
    except FileNotFoundError:
        pass
    except OSError as exc:
        log.warning("init.install_mode.remove_failed", error=str(exc))


def build_env_vars(listen_host: str, listen_port: int, certifi_bundle: Path) -> dict[str, str]:
    """Construct the proxy + cert env vars halton-meter wants in --apps/--full mode.

    ``NO_PROXY=localhost,127.0.0.1`` is critical: it prevents our own
    /health probes from tarpitting through the proxy at us. The certifi-
    patched bundle path covers Anthropic SDK + most Python tools.

    v0.1.5.1: extended set of CA env vars for tools that don't read
    SSL_CERT_FILE. Witnessed 2026-04-30: ``git push`` failed with
    "unable to get local issuer certificate" because git (Homebrew/
    OpenSSL build) reads ``GIT_SSL_CAINFO`` not ``SSL_CERT_FILE``.
    Same shape applies to ``CURL_CA_BUNDLE`` (curl) and
    ``AWS_CA_BUNDLE`` (AWS SDK).

    Per-tool env var mapping:
      * NODE_EXTRA_CA_CERTS — Node.js (claude code / windsurf / cursor)
      * SSL_CERT_FILE — OpenSSL CLI / Python ssl module
      * REQUESTS_CA_BUNDLE — Python `requests`
      * GIT_SSL_CAINFO — git (Homebrew OpenSSL build)
      * CURL_CA_BUNDLE — curl
      * AWS_CA_BUNDLE — AWS SDK / boto3
    """
    proxy_url = f"http://{listen_host}:{listen_port}"
    bundle = str(certifi_bundle)
    return {
        "HTTPS_PROXY": proxy_url,
        "HTTP_PROXY": proxy_url,
        "NO_PROXY": "localhost,127.0.0.1",
        "NODE_EXTRA_CA_CERTS": bundle,
        "SSL_CERT_FILE": bundle,
        "REQUESTS_CA_BUNDLE": bundle,
        "GIT_SSL_CAINFO": bundle,
        "CURL_CA_BUNDLE": bundle,
        "AWS_CA_BUNDLE": bundle,
    }


def detect_shell_rc() -> Path | None:
    """Return the path of the user's shell rc file, or ``None`` if undetected.

    Heuristic: read ``$SHELL`` and map ``zsh`` -> ``~/.zshrc``, ``bash`` ->
    ``~/.bashrc``. Anything else returns ``None`` (we never edit a fish /
    exotic-shell rc; the user can append the block manually).
    """
    shell = os.environ.get("SHELL", "")
    if shell.endswith("zsh"):
        return Path.home() / ".zshrc"
    if shell.endswith("bash"):
        return Path.home() / ".bashrc"
    return None


def _build_shell_rc_block(env_vars: dict[str, str]) -> str:
    """Build the marker-bracketed block of ``export KEY="VAL"`` lines."""
    lines = [SHELL_RC_BLOCK_BEGIN]
    for key in (
        "HTTPS_PROXY",
        "HTTP_PROXY",
        "NO_PROXY",
        "NODE_EXTRA_CA_CERTS",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
        "GIT_SSL_CAINFO",
        "CURL_CA_BUNDLE",
        "AWS_CA_BUNDLE",
    ):
        if key not in env_vars:
            continue
        # Use shlex.quote to handle paths with spaces.
        import shlex

        lines.append(f"export {key}={shlex.quote(env_vars[key])}")
    lines.append(SHELL_RC_BLOCK_END)
    return "\n".join(lines) + "\n"


def append_coverage_block_to_rc(rc_path: Path, env_vars: dict[str, str]) -> str:
    """Idempotently write the coverage block into the given shell rc file.

    Returns one of:
      * ``"appended"`` — block was not present; appended.
      * ``"replaced"`` — block was present; content replaced (env-var
        values may have drifted, e.g. port changed).
      * ``"unchanged"`` — block was present and content matches.
      * ``"missing-rc"`` — rc file does not exist; cannot append safely
        (we never create a shell rc that didn't exist — the user may
        have intentionally deleted it).
    """
    if not rc_path.exists():
        return "missing-rc"
    block = _build_shell_rc_block(env_vars)
    existing = rc_path.read_text(encoding="utf-8")

    if SHELL_RC_BLOCK_BEGIN in existing:
        # Replace the existing block.
        before, _sep, rest = existing.partition(SHELL_RC_BLOCK_BEGIN)
        _block_body, _sep2, after = rest.partition(SHELL_RC_BLOCK_END)
        # Handle both `MARKER\n` and `MARKER\n\n` after-states cleanly.
        after = after.lstrip("\n")
        new_content = before.rstrip() + ("\n\n" if before.strip() else "") + block
        if after:
            new_content = new_content.rstrip() + "\n\n" + after
        # Idempotency check: was the on-disk block already byte-identical?
        # Reconstruct what the block-only section would have been.
        old_block = SHELL_RC_BLOCK_BEGIN + _block_body + SHELL_RC_BLOCK_END + "\n"
        if old_block.strip() == block.strip():
            return "unchanged"
        rc_path.write_text(new_content, encoding="utf-8")
        return "replaced"

    # No block present; append at the end (preserve trailing newline norms).
    if not existing.endswith("\n"):
        existing += "\n"
    new_content = existing + "\n" + block
    rc_path.write_text(new_content, encoding="utf-8")
    return "appended"


def remove_coverage_block_from_rc(rc_path: Path) -> bool:
    """Remove every marker-bracketed block from ``rc_path``. Returns True
    iff at least one block was found and removed. Idempotent — missing
    block / missing file returns False without error.

    v0.1.4 (2B.15) loops until no marker remains. The pre-v0.1.3 install
    paths could append multiple blocks to ``~/.zshrc`` (one per
    ``init --gui`` invocation, before the marker-replace logic landed).
    Witnessed: 6 ``halton-meter`` mentions across multiple bracketed
    blocks. The earlier single-pass remove only stripped one of them —
    the rest of the stale blocks would survive uninstall and continue
    to set ``HTTPS_PROXY`` on every new shell.
    """
    try:
        if not rc_path.exists():
            return False
        existing = rc_path.read_text(encoding="utf-8")
    except OSError:
        return False
    if SHELL_RC_BLOCK_BEGIN not in existing:
        return False

    new_content = existing
    while SHELL_RC_BLOCK_BEGIN in new_content:
        before, _sep, rest = new_content.partition(SHELL_RC_BLOCK_BEGIN)
        _block_body, _sep2, after = rest.partition(SHELL_RC_BLOCK_END)
        after = after.lstrip("\n")
        # Collapse double newlines from the join boundary.
        rebuilt = before.rstrip() + ("\n" if after else "")
        if after:
            rebuilt += after
        # Defensive: a malformed block (BEGIN with no matching END) would
        # have ``_block_body`` swallow the rest of the file and ``after``
        # be empty. Detect that case and bail rather than infinite-loop:
        # if rebuilt still contains BEGIN, something is wrong with the
        # rc shape; just write what we have and stop.
        if SHELL_RC_BLOCK_BEGIN in rebuilt and rebuilt == new_content:
            break
        new_content = rebuilt

    rc_path.write_text(new_content, encoding="utf-8")
    return True


def init(
    *,
    non_interactive: bool = False,
    gui: bool = False,
    full: bool = False,
    apps: bool = False,
    no_shell_rc: bool = False,
    console: Console | None = None,
) -> int:
    """First-run setup. Three modes (v0.1.5 2B.16):

    * env-var-only (default — no flag): cert + certifi + plists. NO
      system-proxy enable, NO launchctl setenv, NO shell-rc append.
      Coverage = whatever the user explicitly routes via ``halton-meter
      run``.
    * ``--apps`` (NEW in v0.1.5): cert + certifi + plists + launchctl
      setenv user-domain + idempotent shell-rc append. NO system proxy.
      Covers Spotlight/Dock-spawned apps (which inherit launchctl env)
      and new terminals (which inherit the shell-rc block) — but does
      NOT touch browsers / GUI apps that don't inherit launchctl env.
      Cannot break HSTS browsing because we never flip the system
      proxy.
    * ``--full`` (was ``--gui`` in v0.1.3/v0.1.4): everything above
      PLUS system-proxy enable. Broadest coverage; the only mode that
      can break HSTS browser sites if cert isn't trusted by SecTrust.
      ``--gui`` is kept as a deprecated alias for ``--full``.

    Idempotent across all three modes; each step independently
    resumable. Returns a process exit code (0 = success).

    Linux: keychain step is skipped (platform-guarded inside ``run_setup``),
    system proxy is not auto-managed (we print a hint), systemd unit is
    installed via :func:`install.install`.

    Windows: prints "not yet supported" and exits 0.
    """
    if console is None:
        console = Console()

    platform = sys.platform

    # v0.1.5 (2B.16): three-mode pivot. ``gui`` is the legacy alias for
    # ``full``; both flags select the full mode. ``apps`` selects the
    # new env-only-but-with-apps-coverage mode. Mutual exclusion is
    # enforced at the CLI layer; defensive check here too.
    selected = sum(1 for f in (apps, full or gui) if f)
    if selected > 1:
        console.print(
            "[red]Pass at most one of --apps / --full (--gui is a "
            "deprecated alias for --full).[/red]"
        )
        return _EXIT_INSTALL_FAILED
    if full or gui:
        mode = MODE_FULL
        if gui and not full:
            console.print(
                "[yellow]--gui is deprecated; use --full. Continuing with "
                "--full semantics.[/yellow]"
            )
    elif apps:
        mode = MODE_APPS
    else:
        mode = MODE_ENV_ONLY

    # Migrate any legacy ``gui`` sentinel from a v0.1.3/v0.1.4 install
    # so downstream readers (this run, status, doctor) see the canonical
    # ``full`` value. Best-effort; never raises.
    migrated = migrate_legacy_mode_sentinel()
    if migrated is not None:
        console.print(
            f"[dim](migrated install-mode sentinel: {migrated!r} -> "
            f"{MODE_FULL!r})[/dim]"
        )

    # Windows stub.
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter init is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK

    # Non-interactive admin-rights check (macOS only).
    #
    # v0.1.4 (2B.15) P0-2: the cert-trust step now prefers the macOS GUI
    # admin dialog (osascript). The dialog works even when sudo is not
    # pre-cached, so the v0.1.3 preflight that bailed on
    # ``not _sudo_pre_cached()`` was hostile to new users.
    #
    # Bail-fast guard: only exit 2 when BOTH osascript is unavailable
    # (broken macOS install or non-macOS) AND sudo is not cached. In
    # that case the cert-trust step would deadlock on a password
    # prompt with no TTY. On every other configuration (osascript
    # present, interactive run, or sudo pre-cached) we proceed and
    # let the cert-trust step elevate via whichever path works.
    if (
        non_interactive
        and platform == "darwin"
        and not _osascript_available_for_init()
        and not _sudo_pre_cached()
    ):
        console.print(
            "[red]halton-meter init --non-interactive cannot elevate "
            "to install the CA cert: osascript is unavailable AND sudo "
            "is not pre-cached.[/red]\n"
            "Pre-cache sudo with [bold]sudo -v[/bold] before running, or "
            "run [bold]halton-meter init[/bold] interactively (the GUI "
            "admin dialog will appear)."
        )
        return _EXIT_SUDO_NOT_PRECACHED

    # Step 1 — detect a live daemon (macOS only). Refreshing the plist
    # via launchctl unload+load-w briefly restarts the process, which
    # severs any in-flight Claude Code stream.
    skip_install_due_to_running_daemon = False
    if platform == "darwin" and _detect_live_daemon():
        warning = (
            "[yellow]A halton-meter daemon is currently running under launchd.[/yellow]\n"
            "Refreshing the plist will restart it, briefly dropping any live API connection."
        )
        console.print(
            Panel(warning, title="halton-meter init — live daemon detected",
                  border_style="yellow", expand=False)
        )
        if non_interactive:
            console.print(
                "[dim]--non-interactive: proceeding with plist refresh.[/dim]"
            )
        else:
            try:
                proceed = console.input(
                    "Restarting the daemon will briefly drop your live API connection. "
                    "Continue? [y/N]: "
                )
            except EOFError:
                proceed = ""
            if proceed.strip().lower() not in {"y", "yes"}:
                console.print(
                    "[yellow]Skipped supervisor refresh.[/yellow] Cert and proxy "
                    "steps did not run because the user declined."
                )
                _render_panel_success(
                    console,
                    setup_done=True,
                    install_done=False,
                    mode=mode,
                    proxy_done=True,
                    proxy_skipped_running_daemon=True,
                )
                return _EXIT_OK

    # P0-5: probe + persist effective ports BEFORE setup / proxy / install
    # so every downstream caller (system proxy enable, env-var
    # construction, plist content if any) sees the discovered values.
    if platform == "darwin":
        try:
            from halton_meter.port_alloc import discover_and_persist_ports

            discover_and_persist_ports()
        except OSError:
            pass

    # Step 2 — cert + keychain + certifi. The ``managed`` kwarg gates the
    # ``proxy-managed`` sentinel write: only --full mode opts in to
    # daemon-side system-proxy management. ``apps`` mode does NOT
    # touch the system proxy (its coverage comes from launchctl env +
    # shell rc only), so its ``managed`` value matches env-only.
    from halton_meter.setup import render_result, run_setup

    setup_result = run_setup(
        force=False,
        managed=(mode == MODE_FULL),
        console=console,
    )
    render_result(setup_result, console)
    if not setup_result.all_done():
        if platform == "darwin":
            _render_panel_failure(
                console,
                "setup did not complete",
                "One or more setup steps failed; see the checklist above.\n"
                "The system proxy and OS supervisor were not touched.",
            )
            return _EXIT_SETUP_FAILED
        if not (
            setup_result.cert_generated.done and setup_result.certifi_patched.done
        ):
            _render_panel_failure(
                console,
                "setup did not complete",
                "Cert generation or certifi patching failed; see the checklist above.",
            )
            return _EXIT_SETUP_FAILED

    # Step 3 — system proxy enable. Skipped in env-var-only AND apps modes.
    proxy_done = False
    if mode == MODE_FULL:
        if platform == "darwin":
            try:
                _enable_system_proxy_for_init(console=console)
                proxy_done = True
            except RuntimeError as exc:
                _render_panel_failure(
                    console,
                    "system proxy enable failed",
                    f"{exc}\n\n"
                    "The OS supervisor was not installed. Re-run "
                    "[bold]halton-meter init --full[/bold] to retry, or run "
                    "[bold]halton-meter init --apps[/bold] for terminal+app "
                    "coverage without system proxy, or "
                    "[bold]halton-meter init[/bold] (no flag) for env-var-only "
                    "mode.",
                )
                return _EXIT_PROXY_FAILED
        else:
            console.print(
                "[yellow]Linux:[/yellow] --full system-proxy management is not "
                "yet implemented. Falling back to apps mode for this "
                "platform; the launchctl-equivalent env vars + shell-rc "
                "still cover terminals + most CLI tools."
            )
            mode = MODE_APPS  # downgrade for honest sentinel write below.

    # Step 4 — supervisor install (always — same in both modes).
    from halton_meter import install as install_module

    install_rc = install_module.install()
    if install_rc != 0:
        _render_panel_failure(
            console,
            "supervisor install failed",
            f"halton-meter install exited with code {install_rc}. "
            "See messages above.",
        )
        return _EXIT_INSTALL_FAILED

    # Step 5 — launchctl setenv + shell-rc (apps + full modes, macOS).
    # In apps mode we install the same launchctl/shell-rc surfaces as
    # full but skip system-proxy enable; in env-only mode we sweep
    # any stale state from a prior apps/full install. v0.1.5 (2B.16)
    # P0-1: the reconciliation invariant is now a SINGLE helper
    # (_reconcile_to_mode) so all 9 mode-transition cells get
    # symmetrical treatment.
    setenv_done = False
    shell_rc_status: str | None = None
    if mode in (MODE_APPS, MODE_FULL) and platform == "darwin":
        from halton_meter import system_proxy
        from halton_meter.port_alloc import load_effective_config
        from halton_meter.setup import _certifi_bundle_path

        cfg = load_effective_config()
        env_vars = build_env_vars(
            cfg.daemon.listen_host,
            cfg.daemon.listen_port,
            _certifi_bundle_path(),
        )
        rcs = system_proxy.setenv_user_domain(env_vars)
        # Treat all-zero rcs as success.
        setenv_done = bool(rcs) and all(rc == 0 for rc in rcs.values())

        # Shell-rc append: only in interactive sessions, only when the user
        # consents, and never in --no-shell-rc mode.
        if no_shell_rc:
            shell_rc_status = "skipped"
        elif non_interactive:
            shell_rc_status = "skipped"
        else:
            rc_path = detect_shell_rc()
            if rc_path is None:
                shell_rc_status = "missing-rc"
            else:
                try:
                    answer = console.input(
                        f"Append idempotent env-var block to "
                        f"[bold]{rc_path}[/bold]? "
                        "(y/N): "
                    )
                except EOFError:
                    answer = ""
                if answer.strip().lower() in {"y", "yes"}:
                    shell_rc_status = append_coverage_block_to_rc(rc_path, env_vars)
                else:
                    shell_rc_status = "declined"

    if platform == "darwin":
        # v0.1.5 (2B.16) P0-1: three-mode reconciliation invariant.
        # Whatever the requested mode is, ensure the four mode-specific
        # surfaces (proxy-managed sentinel, system proxy state,
        # launchctl env, shell-rc block) match it AT THE END of the
        # flow, sweeping any stale state from a prior install in a
        # different mode. The setenv/shell-rc step above is additive
        # (writes the desired state in apps/full); this call cleans up
        # surfaces that don't belong in the destination mode (e.g.
        # apps mode requires system proxy OFF; env-only requires
        # launchctl env unset + shell-rc removed).
        _reconcile_to_mode(mode, console)
        if mode == MODE_ENV_ONLY:
            shell_rc_status = "reconciled"

    # Step 6 — write install-mode sentinel as the last step on the success
    # path. Must follow setup + install + setenv so doctor sees a coherent
    # state.
    write_install_mode(mode)

    # Step 7 — self-test (P0-6). Run a battery of local-only health
    # checks; if any fatal check fails, roll back the install via
    # ``install_module.uninstall()`` and exit non-zero. We never declare
    # success on a broken state.
    failures = _run_self_test(mode=mode, platform=platform, console=console)
    if failures:
        _render_self_test_failure_panel(console, failures)
        _rollback_install(console)
        return _EXIT_INSTALL_FAILED

    # P0-5: load the effective ports so the success panel can mark
    # auto-fallback. Best-effort — fall back to (None, None) on any
    # error so the panel still renders (without the ports row).
    effective_listen_port: int | None = None
    effective_api_port: int | None = None
    try:
        from halton_meter.port_alloc import load_effective_config

        eff = load_effective_config()
        effective_listen_port = int(eff.daemon.listen_port)
        effective_api_port = int(eff.daemon.api_port)
    except Exception:
        pass

    _render_panel_success(
        console,
        setup_done=True,
        install_done=True,
        mode=mode,
        proxy_done=proxy_done,
        setenv_done=setenv_done,
        shell_rc_status=shell_rc_status,
        proxy_skipped_running_daemon=skip_install_due_to_running_daemon,
        listen_port=effective_listen_port,
        api_port=effective_api_port,
    )
    return _EXIT_OK


# --------------------------------------------------------------------------- #
# Self-test (P0-6) and rollback                                               #
# --------------------------------------------------------------------------- #


def _run_self_test(
    *, mode: str, platform: str, console: Console
) -> list[Any]:
    """Run the post-install self-test. Returns the list of FATAL failures
    (empty list = pass)."""
    from halton_meter import health
    from halton_meter.port_alloc import load_effective_config

    cfg = load_effective_config()
    api_host = cfg.daemon.api_host
    api_port = cfg.daemon.api_port
    listen_host = cfg.daemon.listen_host
    listen_port = cfg.daemon.listen_port

    checks: list[Any] = []

    # Universally applicable.
    checks.append(health.check_daemon_health(api_host, api_port))
    if platform == "darwin":
        checks.append(health.check_cert_trusted_macos())
        checks.append(health.check_plists_loaded_macos())
    checks.append(health.check_install_mode_sentinel())
    checks.append(health.check_port_persisted())

    # apps + full both require launchctl env. full additionally requires
    # the system proxy to point at us.
    if mode == MODE_FULL and platform == "darwin":
        checks.append(
            health.check_system_proxy_points_at_us(
                listen_host=listen_host, listen_port=listen_port
            )
        )
    if mode in (MODE_APPS, MODE_FULL) and platform == "darwin":
        checks.append(
            health.check_launchctl_env_var(
                key="HTTPS_PROXY",
                expected_substr=str(listen_port),
            )
        )

    # Filter to fatal failures only.
    return [c for c in checks if not c.ok and c.severity == "fatal"]


def _render_self_test_failure_panel(
    console: Console, failures: list[Any]
) -> None:
    body_lines = ["Self-test detected unrecoverable problems:"]
    for c in failures:
        body_lines.append(f"  [red]✗[/red] [bold]{c.name}[/bold] — {c.message}")
    body_lines.append(
        "\n[bold]Rolling back the install[/bold] so the system is left in a "
        "coherent state. After remediation, re-run [bold]halton-meter init[/bold]."
    )
    console.print(
        Panel(
            "\n".join(body_lines),
            title="halton-meter init — self-test failed",
            border_style="red",
            expand=False,
        )
    )


def _rollback_install(console: Console) -> None:
    """Best-effort uninstall used by P0-6 self-test rollback."""
    try:
        from halton_meter import install as install_module

        install_module.uninstall(purge=False, include_logs=False)
    except Exception as exc:
        console.print(
            "[red]warning:[/red] rollback uninstall raised "
            f"{type(exc).__name__}: {exc}\n"
            "  Run [bold]halton-meter uninstall[/bold] manually if needed."
        )


def _reconcile_to_mode(target_mode: str, console: Console) -> None:
    """v0.1.5 (2B.16) P0-1: idempotently bring four mode-specific surfaces
    into agreement with ``target_mode``, sweeping any stale state from a
    prior install in a different mode.

    The four surfaces:

    1. **proxy-managed sentinel** (``~/.halton-meter/system-proxy``).
       Present iff target is ``full``. Drives the daemon's startup
       ``enable_system_proxy_if_managed`` — leaving it set in a non-full
       mode causes the daemon to re-enable the system proxy on every
       launch.
    2. **system proxy state** (per-interface ``networksetup``). Pointing
       at us iff target is ``full``. Disabled (or restored from
       snapshot) for env-only and apps modes.
    3. **launchctl user-domain env vars** (HTTPS_PROXY et al). Set iff
       target is in ``(apps, full)``. Unset for env-only.
    4. **shell-rc block** (marker-bracketed export block in the user's
       shell rc). Present iff target is in ``(apps, full)``. Removed
       for env-only.

    The setenv/shell-rc step in :func:`init` is additive (writes the
    block) for apps/full; the calls below for those modes are no-ops on
    those two surfaces because the apps/full step already wrote the
    correct content. The non-trivial work is the sweeping in the OTHER
    direction (e.g. apps mode arrives with a stale system proxy from a
    prior full install — must be torn down).

    Each step swallows its own errors and logs — none of them blocks
    the rest. The function never raises.

    The 9-cell mode-transition matrix
    (env-only / apps / full -> env-only / apps / full) is covered by
    this single function: each cell is a (target_mode, current state)
    pair, and the function ensures the four surfaces match the target
    regardless of where they started.
    """
    from halton_meter import system_proxy
    from halton_meter.install import _proxy_managed_sentinel_path, _resolve_daemon_listener

    want_proxy = target_mode == MODE_FULL
    want_env = target_mode in (MODE_APPS, MODE_FULL)
    want_shell_rc = target_mode in (MODE_APPS, MODE_FULL)
    label = f"({target_mode})"

    # 1. Sentinel: present iff full. (env-only and apps both want it
    #    absent.)
    try:
        sentinel = _proxy_managed_sentinel_path()
        if not want_proxy and sentinel.exists():
            sentinel.unlink()
            console.print(
                f"[dim]{label}: removed proxy-managed sentinel from prior "
                f"--full install[/dim]"
            )
    except Exception as exc:
        log.warning("init.reconcile.sentinel_remove_failed", error=str(exc))

    # 2. System proxy. Disable on every interface currently pointing at
    #    us if the target mode doesn't want it.
    if not want_proxy:
        try:
            our_host, our_port = _resolve_daemon_listener()
            restored = system_proxy.restore_system_proxy(our_host, our_port)
            if not restored:
                # No snapshot. Still need to turn off any interface that
                # currently points at our listener.
                for iface in system_proxy._macos_interfaces():
                    for secure in (True, False):
                        enabled, host, port = system_proxy._read_macos_proxy(
                            iface, secure=secure
                        )
                        if enabled and system_proxy._proxy_targets_us(
                            host, port, our_host, our_port
                        ):
                            system_proxy._disable_macos_proxy(iface)
                            console.print(
                                f"[dim]{label}: disabled stale system proxy "
                                f"on {iface}[/dim]"
                            )
                            break
        except Exception as exc:
            log.warning("init.reconcile.proxy_disable_failed", error=str(exc))

    # 3. launchctl user-domain env vars. Sweep iff target doesn't want
    #    them. (apps / full set them in step 5 of init; the sweep here
    #    fires only in env-only mode.)
    if not want_env:
        try:
            system_proxy.unsetenv_user_domain(system_proxy.GUI_LAUNCHCTL_ENV_KEYS)
        except Exception as exc:
            log.warning("init.reconcile.unsetenv_failed", error=str(exc))

    # 4. Shell-rc block. Remove iff target doesn't want it. (apps / full
    #    write the block in step 5 of init; the removal here fires only
    #    in env-only mode.)
    if not want_shell_rc:
        try:
            rc_path = detect_shell_rc()
            if rc_path is not None and remove_coverage_block_from_rc(rc_path):
                console.print(
                    f"[dim]{label}: removed halton-meter env block from "
                    f"{rc_path}[/dim]"
                )
        except Exception as exc:
            log.warning("init.reconcile.rc_remove_failed", error=str(exc))


# Back-compat alias preserved so any out-of-tree callers (and the
# existing v0.1.4 tests until they're updated) continue to work.
def _reconcile_env_only_mode(console: Console) -> None:
    """Legacy alias from v0.1.4. v0.1.5 (2B.16): forwards to
    :func:`_reconcile_to_mode` with ``MODE_ENV_ONLY``."""
    _reconcile_to_mode(MODE_ENV_ONLY, console)


def _enable_system_proxy_for_init(*, console: Console) -> None:
    """Eagerly enable the macOS system proxy, elevating via osascript when needed.

    Reads the current address and only invokes the admin GUI prompt
    when the address actually differs from ``(daemon.listen_host,
    daemon.listen_port)``. The state-toggle is run un-elevated since it
    doesn't require admin.

    Reads the EFFECTIVE config (v0.1.3 P0-5) so a runtime.toml override
    is honoured — if 8080 was busy and the daemon allocated 8081, the
    system proxy is pointed at 8081.

    Raises :class:`RuntimeError` on any failure (matches the
    ``eager=True`` contract of
    :func:`halton_meter.system_proxy.enable_system_proxy_if_managed`).
    """
    from halton_meter import system_proxy
    from halton_meter.port_alloc import load_effective_config

    cfg = load_effective_config()
    host = cfg.daemon.listen_host
    port = cfg.daemon.listen_port

    # 2B.11: snapshot pre-install system-proxy state BEFORE the first
    # ``networksetup -setsecurewebproxy`` mutation so ``halton-meter
    # uninstall`` can restore it. Skipped silently if the snapshot file
    # already exists (the first capture wins — a re-run of ``init``
    # against a system whose proxy is already pointed at us must NOT
    # overwrite the original state). Best-effort: any failure during
    # the snapshot path is logged but does not block init.
    system_proxy.snapshot_system_proxy()

    # Iterate only the interfaces we know to set. If every iface either
    # already has the correct address or we successfully set it via
    # osascript, the eager call afterwards just toggles state and
    # returns without raising.
    address_was_set_via_admin = False
    for iface in system_proxy._macos_interfaces():
        for secure, set_target in (
            (True, "-setsecurewebproxy"),
            (False, "-setwebproxy"),
        ):
            _enabled, current_host, current_port = system_proxy._read_macos_proxy(
                iface, secure=secure
            )
            if system_proxy._proxy_targets_us(
                current_host, current_port, host, port
            ):
                continue
            # Try direct first — modern macOS allows networksetup without admin.
            # Fall back to osascript-wrapped admin only if the direct call fails
            # with a permission-flavoured error (older / MDM-locked machines).
            direct_argv = [
                "networksetup", set_target, iface, host, str(port)
            ]
            direct_result = subprocess.run(
                direct_argv, capture_output=True, text=True, check=False
            )
            if direct_result.returncode == 0:
                log.info(
                    "init.proxy.address_set",
                    iface=iface,
                    variant=set_target,
                    admin=False,
                )
                continue
            # Any non-zero rc warrants an elevation retry. The earlier
            # stderr-substring heuristic missed cases like rc=4 with
            # empty stderr (observed 2026-04-30 on modern macOS Ethernet
            # interfaces), so we now treat every networksetup failure as
            # a candidate for elevation. If the elevated retry also
            # fails, run_with_admin raises with the actual reason —
            # which is more useful than guessing here. See
            # decisions.md 2026-04-30 (2B.7.1).
            log.info(
                "init.proxy.elevation_retry_widened",
                iface=iface,
                variant=set_target,
                rc=direct_result.returncode,
                stderr_was_empty=not (direct_result.stderr or "").strip(),
            )
            # Escalate via osascript admin dialog.
            if not address_was_set_via_admin:
                console.print(
                    "[dim]The system proxy address could not be set without "
                    "admin rights on this macOS configuration. You'll see a "
                    "password dialog in a moment.[/dim]"
                )
                address_was_set_via_admin = True
            system_proxy.run_with_admin(
                direct_argv,
                prompt_reason=(
                    "halton-meter wants to point your system proxy at the "
                    "local metering daemon"
                ),
            )
            log.info(
                "init.proxy.address_set",
                iface=iface,
                variant=set_target,
                admin=True,
            )

    # Now run the eager pass: addresses are correct (either already or
    # just-set), so this should only toggle state-on, which doesn't need
    # admin. Any non-zero from the toggle raises.
    system_proxy.enable_system_proxy_if_managed(host, port, eager=True)
