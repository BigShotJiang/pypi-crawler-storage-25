"""
Stats service — aggregate queries for projects and requests.

Ported from halton-meter-cloud:backend/app/services/stats.py with one
SQLite-specific change: ``func.date_trunc('day', col)`` (Postgres) is
replaced by ``func.strftime('%Y-%m-%d', col)`` everywhere. Both produce
the same wire shape (an ISO date string in by_day rows).
"""

from __future__ import annotations

import base64
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from sqlalchemy import distinct, func, select, text

from halton_meter.api.schemas.projects import (
    GlobalStats,
    ProjectDetail,
    ProjectListItem,
    ProjectMonthStats,
    ProjectStats,
    RequestRecord,
    RequestsPage,
    StatsByDay,
    StatsByDayByProvider,
    StatsByModel,
    StatsByProvider,
    StatsSummary,
)
from halton_meter.storage.models import Project, Request

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession


def _now_utc() -> datetime:
    return datetime.now(tz=UTC)


def _month_start() -> datetime:
    now = _now_utc()
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def _prev_month_start() -> datetime:
    now = _now_utc()
    if now.month == 1:
        return now.replace(
            year=now.year - 1, month=12, day=1, hour=0, minute=0, second=0, microsecond=0
        )
    return now.replace(month=now.month - 1, day=1, hour=0, minute=0, second=0, microsecond=0)


def _day(col: object) -> object:
    """SQLite-friendly equivalent of ``func.date_trunc('day', col)``."""
    return func.strftime("%Y-%m-%d", col)


async def _month_stats_for_project(
    session: AsyncSession, project_id: str
) -> ProjectMonthStats:
    month_start = _month_start()
    prev_month_start = _prev_month_start()

    # This month
    result = await session.execute(
        select(
            func.count(Request.id).label("req_count"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
            func.max(Request.requested_at).label("last_active"),
        ).where(
            Request.project_id == project_id,
            Request.requested_at >= month_start,
        )
    )
    row = result.one()

    # Previous month cost
    prev_result = await session.execute(
        select(
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
        ).where(
            Request.project_id == project_id,
            Request.requested_at >= prev_month_start,
            Request.requested_at < month_start,
        )
    )
    prev_row = prev_result.one()

    # All-time
    all_time_result = await session.execute(
        select(
            func.count(Request.id).label("total_requests"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("total_cost"),
        ).where(Request.project_id == project_id)
    )
    all_time_row = all_time_result.one()

    # Primary model this month
    primary_model: str | None = None
    primary_provider: str | None = None
    model_result = await session.execute(
        select(
            Request.model,
            Request.provider,
            func.count(Request.id).label("req_count"),
        )
        .where(
            Request.project_id == project_id,
            Request.requested_at >= month_start,
        )
        .group_by(Request.model, Request.provider)
        .order_by(text("req_count DESC"))
        .limit(1)
    )
    model_row = model_result.one_or_none()
    if model_row is not None:
        primary_model = model_row.model
        primary_provider = model_row.provider

    last_active = row.last_active
    if last_active is not None and last_active.tzinfo is None:
        last_active = last_active.replace(tzinfo=UTC)

    return ProjectMonthStats(
        requests_this_month=row.req_count,
        cost_usd_this_month_minor_units=int(row.cost),
        previous_month_cost_usd_minor_units=int(prev_row.cost),
        all_time_cost_usd_minor_units=int(all_time_row.total_cost),
        all_time_requests=int(all_time_row.total_requests),
        last_active_at=last_active,
        primary_model=primary_model,
        primary_provider=primary_provider,
    )


def _ensure_utc(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


async def list_projects(session: AsyncSession) -> list[ProjectListItem]:
    result = await session.execute(
        select(Project).order_by(Project.created_at.desc())
    )
    projects = result.scalars().all()
    items: list[ProjectListItem] = []
    for project in projects:
        stats = await _month_stats_for_project(session, project.id)
        items.append(
            ProjectListItem(
                id=project.id,
                name=project.name,
                slug=project.slug,
                created_at=_ensure_utc(project.created_at),  # type: ignore[arg-type]
                archived_at=_ensure_utc(project.archived_at),
                stats=stats,
            )
        )
    return items


async def get_project_by_slug(
    session: AsyncSession, slug: str
) -> ProjectDetail | None:
    result = await session.execute(select(Project).where(Project.slug == slug))
    project = result.scalar_one_or_none()
    if project is None:
        return None
    stats = await _month_stats_for_project(session, project.id)
    return ProjectDetail(
        id=project.id,
        name=project.name,
        slug=project.slug,
        created_at=_ensure_utc(project.created_at),  # type: ignore[arg-type]
        archived_at=_ensure_utc(project.archived_at),
        stats=stats,
    )


async def get_project_stats(
    session: AsyncSession,
    slug: str,
    since: datetime | None,
    until: datetime | None,
    provider: str | None,
    cursor: str | None,
    limit: int,
) -> ProjectStats | None:
    result = await session.execute(select(Project).where(Project.slug == slug))
    project = result.scalar_one_or_none()
    if project is None:
        return None

    filters = [Request.project_id == project.id]
    if since:
        filters.append(Request.requested_at >= since)
    if until:
        filters.append(Request.requested_at <= until)
    if provider:
        filters.append(Request.provider == provider)

    summary = await _summary(session, filters)
    by_day = await _by_day(session, filters)
    by_day_by_provider = await _by_day_by_provider(session, filters)
    by_provider = await _by_provider(session, filters)
    by_model = await _by_model(session, filters)

    requests_page = await get_project_requests(
        session=session,
        slug=slug,
        since=since,
        until=until,
        provider=provider,
        cursor=cursor,
        limit=limit,
    )

    return ProjectStats(
        summary=summary,
        by_day=by_day,
        by_day_by_provider=by_day_by_provider,
        by_provider=by_provider,
        by_model=by_model,
        requests=requests_page,
    )


async def get_global_stats(
    session: AsyncSession,
    since: datetime | None,
    until: datetime | None,
    provider: str | None,
) -> GlobalStats:
    filters: list = []
    if since:
        filters.append(Request.requested_at >= since)
    if until:
        filters.append(Request.requested_at <= until)
    if provider:
        filters.append(Request.provider == provider)

    summary = await _summary(session, filters, include_global=True)
    by_day = await _by_day(session, filters)
    by_day_by_provider = await _by_day_by_provider(session, filters)
    by_provider = await _by_provider(session, filters)
    by_model = await _by_model(session, filters)

    return GlobalStats(
        summary=summary,
        by_day=by_day,
        by_day_by_provider=by_day_by_provider,
        by_provider=by_provider,
        by_model=by_model,
    )


# ── Internal aggregate helpers ─────────────────────────────────────────────


def _where_or_true(filters: list) -> list:
    return filters if filters else [text("1=1")]


async def _summary(
    session: AsyncSession, filters: list, include_global: bool = False
) -> StatsSummary:
    where = _where_or_true(filters)
    cols = [
        func.count(Request.id).label("total_requests"),
        func.coalesce(func.sum(Request.input_tokens), 0).label("total_input"),
        func.coalesce(func.sum(Request.output_tokens), 0).label("total_output"),
        func.coalesce(func.sum(Request.thinking_tokens), 0).label("total_thinking"),
        func.coalesce(func.sum(Request.cached_tokens), 0).label("total_cached"),
        func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("total_cost"),
    ]
    if include_global:
        cols += [
            func.count(distinct(Request.project_id)).label("active_projects"),
            func.count(distinct(Request.model)).label("models_in_use"),
            func.max(Request.requested_at).label("last_request_at"),
        ]
    summary_result = await session.execute(select(*cols).where(*where))
    sr = summary_result.one()
    total_input = int(sr.total_input)
    total_cached = int(sr.total_cached)
    cache_hit_rate = (
        total_cached / (total_input + total_cached)
        if (total_input + total_cached) > 0
        else 0.0
    )
    extras: dict = {}
    if include_global:
        extras = {
            "active_projects": int(sr.active_projects),
            "models_in_use": int(sr.models_in_use),
            "last_request_at": _ensure_utc(sr.last_request_at),
        }
    return StatsSummary(
        total_requests=sr.total_requests,
        total_input_tokens=total_input,
        total_output_tokens=int(sr.total_output),
        total_thinking_tokens=int(sr.total_thinking),
        total_cached_tokens=total_cached,
        total_cost_usd_minor_units=int(sr.total_cost),
        cache_hit_rate=round(cache_hit_rate, 4),
        **extras,
    )


async def _by_day(session: AsyncSession, filters: list) -> list[StatsByDay]:
    where = _where_or_true(filters)
    by_day_result = await session.execute(
        select(
            _day(Request.requested_at).label("day"),
            func.count(Request.id).label("requests"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
        )
        .where(*where)
        .group_by(text("day"))
        .order_by(text("day"))
    )
    return [
        StatsByDay(
            date=row.day,
            requests=row.requests,
            cost_usd_minor_units=int(row.cost),
        )
        for row in by_day_result
    ]


async def _by_day_by_provider(
    session: AsyncSession, filters: list
) -> list[StatsByDayByProvider]:
    where = _where_or_true(filters)
    result = await session.execute(
        select(
            _day(Request.requested_at).label("day"),
            Request.provider,
            func.count(Request.id).label("requests"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
        )
        .where(*where)
        .group_by(text("day"), Request.provider)
        .order_by(text("day"), Request.provider)
    )
    return [
        StatsByDayByProvider(
            date=row.day,
            provider=row.provider,
            requests=row.requests,
            cost_usd_minor_units=int(row.cost),
        )
        for row in result
    ]


async def _by_provider(session: AsyncSession, filters: list) -> list[StatsByProvider]:
    where = _where_or_true(filters)
    result = await session.execute(
        select(
            Request.provider,
            func.count(Request.id).label("requests"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
        )
        .where(*where)
        .group_by(Request.provider)
        .order_by(text("cost DESC"))
    )
    return [
        StatsByProvider(
            provider=row.provider,
            requests=row.requests,
            cost_usd_minor_units=int(row.cost),
        )
        for row in result
    ]


async def _by_model(session: AsyncSession, filters: list) -> list[StatsByModel]:
    where = _where_or_true(filters)
    result = await session.execute(
        select(
            Request.provider,
            Request.model,
            func.count(Request.id).label("requests"),
            func.coalesce(func.sum(Request.input_tokens), 0).label("input_tokens"),
            func.coalesce(func.sum(Request.output_tokens), 0).label("output_tokens"),
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("cost"),
        )
        .where(*where)
        .group_by(Request.provider, Request.model)
        .order_by(text("cost DESC"))
    )
    return [
        StatsByModel(
            provider=row.provider,
            model=row.model,
            requests=row.requests,
            input_tokens=int(row.input_tokens),
            output_tokens=int(row.output_tokens),
            cost_usd_minor_units=int(row.cost),
        )
        for row in result
    ]


async def get_project_requests(
    session: AsyncSession,
    slug: str,
    since: datetime | None,
    until: datetime | None,
    provider: str | None,
    cursor: str | None,
    limit: int,
) -> RequestsPage:
    result = await session.execute(select(Project).where(Project.slug == slug))
    project = result.scalar_one_or_none()
    if project is None:
        return RequestsPage(items=[], next_cursor=None, total=0)

    filters = [Request.project_id == project.id]
    if since:
        filters.append(Request.requested_at >= since)
    if until:
        filters.append(Request.requested_at <= until)
    if provider:
        filters.append(Request.provider == provider)

    if cursor:
        try:
            cursor_ts_str = base64.b64decode(cursor).decode()
            cursor_dt = datetime.fromisoformat(cursor_ts_str)
            filters.append(Request.requested_at < cursor_dt)
        except Exception:
            pass  # ignore malformed cursor

    count_filters = [Request.project_id == project.id]
    if since:
        count_filters.append(Request.requested_at >= since)
    if until:
        count_filters.append(Request.requested_at <= until)
    if provider:
        count_filters.append(Request.provider == provider)

    total_result = await session.execute(
        select(func.count(Request.id)).where(*count_filters)
    )
    total = total_result.scalar_one()

    rows = await session.execute(
        select(Request)
        .where(*filters)
        .order_by(Request.requested_at.desc())
        .limit(limit + 1)
    )
    requests = rows.scalars().all()

    has_next = len(requests) > limit
    items = requests[:limit]

    next_cursor = None
    if has_next and items:
        last_ts = items[-1].requested_at
        if last_ts.tzinfo is None:
            last_ts = last_ts.replace(tzinfo=UTC)
        next_cursor = base64.b64encode(last_ts.isoformat().encode()).decode()

    return RequestsPage(
        items=[
            RequestRecord(
                id=r.id,
                provider=r.provider,
                model=r.model,
                mode=r.mode,
                input_tokens=r.input_tokens,
                output_tokens=r.output_tokens,
                thinking_tokens=r.thinking_tokens,
                cached_tokens=r.cached_tokens,
                cost_usd_minor_units=r.cost_usd_minor_units,
                latency_ms=r.latency_ms,
                tokens_complete=bool(r.tokens_complete),
                requested_at=_ensure_utc(r.requested_at),  # type: ignore[arg-type]
                status=r.status,
            )
            for r in items
        ],
        next_cursor=next_cursor,
        total=total,
    )
