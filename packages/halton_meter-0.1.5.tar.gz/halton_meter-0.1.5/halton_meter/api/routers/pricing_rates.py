"""Pricing rates CRUD API.

Ported from halton-meter-cloud:backend/app/routers/pricing_rates.py.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.api.services.audit import log_event
from halton_meter.storage.models import PricingRate

router = APIRouter(prefix="/v1/pricing-rates", tags=["pricing-rates"])

_MILLICENTS_PER_USD_MILLION = 100_000


def _to_usd(minor_units: int) -> float:
    return minor_units / _MILLICENTS_PER_USD_MILLION


def _to_minor_units(usd_per_million: float) -> int:
    return round(usd_per_million * _MILLICENTS_PER_USD_MILLION)


class PricingRateResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    provider: str
    model: str
    mode: str
    effective_from: datetime
    effective_to: datetime | None
    input_rate: float = Field(description="USD per million tokens")
    output_rate: float = Field(description="USD per million tokens")
    thinking_rate: float = Field(description="USD per million tokens")
    cache_read_rate: float = Field(description="USD per million tokens")
    is_current: bool
    last_verified_at: datetime | None = None


class PricingRateUpdate(BaseModel):
    input_rate: float
    output_rate: float
    thinking_rate: float
    cache_read_rate: float


class PricingRateCreate(BaseModel):
    provider: str
    model: str
    mode: str = "standard"
    input_rate: float
    output_rate: float
    thinking_rate: float
    cache_read_rate: float


def _adapt(rate: PricingRate) -> PricingRateResponse:
    return PricingRateResponse(
        id=rate.id,
        provider=rate.provider,
        model=rate.model,
        mode=rate.mode,
        effective_from=rate.effective_from,
        effective_to=rate.effective_to,
        input_rate=_to_usd(rate.input_rate_per_million_minor_units),
        output_rate=_to_usd(rate.output_rate_per_million_minor_units),
        thinking_rate=_to_usd(rate.thinking_rate_per_million_minor_units),
        cache_read_rate=_to_usd(rate.cache_read_rate_per_million_minor_units),
        is_current=rate.effective_to is None,
        last_verified_at=rate.last_verified_at,
    )


@router.get("", response_model=list[PricingRateResponse])
async def list_pricing_rates(
    session: AsyncSession = Depends(get_session),
) -> list[PricingRateResponse]:
    result = await session.execute(
        select(PricingRate).order_by(
            PricingRate.provider,
            PricingRate.model,
            PricingRate.effective_from.desc(),
        )
    )
    return [_adapt(r) for r in result.scalars().all()]


@router.get("/current", response_model=list[PricingRateResponse])
async def get_current_pricing_rates(
    session: AsyncSession = Depends(get_session),
) -> list[PricingRateResponse]:
    result = await session.execute(
        select(PricingRate)
        .where(PricingRate.effective_to.is_(None))
        .order_by(PricingRate.provider, PricingRate.model)
    )
    return [_adapt(r) for r in result.scalars().all()]


@router.put("/{rate_id}", response_model=PricingRateResponse)
async def update_pricing_rate(
    rate_id: uuid.UUID,
    body: PricingRateUpdate,
    session: AsyncSession = Depends(get_session),
) -> PricingRateResponse:
    result = await session.execute(
        select(PricingRate).where(PricingRate.id == str(rate_id))
    )
    existing = result.scalar_one_or_none()
    if existing is None:
        raise HTTPException(status_code=404, detail=f"Pricing rate {rate_id} not found")

    now = datetime.now(tz=UTC)
    existing.effective_to = now

    new_rate = PricingRate(
        id=str(uuid.uuid4()),
        provider=existing.provider,
        model=existing.model,
        mode=existing.mode,
        effective_from=now,
        effective_to=None,
        input_rate_per_million_minor_units=_to_minor_units(body.input_rate),
        output_rate_per_million_minor_units=_to_minor_units(body.output_rate),
        thinking_rate_per_million_minor_units=_to_minor_units(body.thinking_rate),
        cache_read_rate_per_million_minor_units=_to_minor_units(body.cache_read_rate),
        last_verified_at=now,
    )
    session.add(new_rate)
    await session.flush()

    await log_event(
        session,
        action="rate.updated",
        metadata={
            "model": existing.model,
            "old_rate_id": str(existing.id),
            "new_rate_id": str(new_rate.id),
        },
    )
    return _adapt(new_rate)


@router.post("", response_model=PricingRateResponse, status_code=201)
async def create_pricing_rate(
    body: PricingRateCreate,
    session: AsyncSession = Depends(get_session),
) -> PricingRateResponse:
    now = datetime.now(tz=UTC)
    new_rate = PricingRate(
        id=str(uuid.uuid4()),
        provider=body.provider,
        model=body.model,
        mode=body.mode,
        effective_from=now,
        effective_to=None,
        input_rate_per_million_minor_units=_to_minor_units(body.input_rate),
        output_rate_per_million_minor_units=_to_minor_units(body.output_rate),
        thinking_rate_per_million_minor_units=_to_minor_units(body.thinking_rate),
        cache_read_rate_per_million_minor_units=_to_minor_units(body.cache_read_rate),
    )
    session.add(new_rate)
    await session.flush()
    return _adapt(new_rate)
