"""
Report formatting logic for Halton Meter CLI.

Reads LogRecords and produces a formatted rich console report:
  1. Header — product, version, date range
  2. Summary lines — totals as ✓-prefixed key facts
  3. Per-project breakdown — minimal rule-separated rows
  4. Per-model breakdown — minimal rule-separated rows

Money display: 1 USD = 100_000 millicents.  Always show 6dp so sub-cent
amounts (e.g. 4 millicents = 4/100_000 USD = $0.000040) are never rounded to zero.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import NamedTuple

from rich import box
from rich.console import Console
from rich.table import Table

from halton_meter import __version__
from halton_meter.models import LogRecord

# Brand palette — keep in sync with dashboard accent.
_BRAND = "#ff8c42"   # warm orange — product, totals, URLs
_OK = "#7fdb86"      # green — success ticks
_WARN = "#f0c674"    # amber — incomplete warnings
_MUTED = "bright_black"  # dim grey — labels, status verbs

# Conversion constant — see memory/patterns.md and decisions.md 2026-04-28
_MILLICENTS_PER_USD: int = 100_000


def format_usd(millicents: int | None) -> str:
    """
    Format millicents as a USD string with 6 decimal places.

    6dp is required so that tiny values (e.g. 4 millicents = $0.000040) are
    visible rather than rounded to $0.0000.

    Args:
        millicents: Cost in millicents, or None if unknown.

    Returns:
        USD string like "$0.000040", or "N/A" if millicents is None.
    """
    if millicents is None:
        return "N/A"
    dollars = millicents / _MILLICENTS_PER_USD
    return f"${dollars:.6f}"


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------


@dataclass
class ProjectStats:
    """Aggregated stats for a single project."""

    project: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int | None = 0  # None means at least one record had None cost
    latency_sum_ms: float = 0.0
    incomplete_count: int = 0

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if self.cost_millicents is not None:
            if record.cost_millicents is None:
                self.cost_millicents = None
            else:
                self.cost_millicents += record.cost_millicents
        self.latency_sum_ms += record.latency_ms
        if not record.tokens_complete:
            self.incomplete_count += 1

    @property
    def avg_latency_ms(self) -> float:
        """Average latency in milliseconds, or 0 if no requests."""
        return self.latency_sum_ms / self.requests if self.requests else 0.0


@dataclass
class ModelStats:
    """Aggregated stats for a single model."""

    model: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int | None = 0

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if self.cost_millicents is not None:
            if record.cost_millicents is None:
                self.cost_millicents = None
            else:
                self.cost_millicents += record.cost_millicents


class ReportData(NamedTuple):
    """
    Processed data ready to render into a report.

    Produced by :func:`build_report_data` from a list of LogRecords.
    """

    records: list[LogRecord]
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_cost_millicents: int | None
    date_from: str | None  # ISO 8601 string of oldest record
    date_to: str | None  # ISO 8601 string of newest record
    incomplete_count: int
    project_stats: list[ProjectStats]
    model_stats: list[ModelStats]


def build_report_data(records: list[LogRecord]) -> ReportData:
    """
    Aggregate a list of LogRecords into a ReportData summary.

    Args:
        records: LogRecords to aggregate (order does not matter).

    Returns:
        ReportData with totals, per-project, and per-model breakdowns.
    """
    if not records:
        return ReportData(
            records=[],
            total_requests=0,
            total_input_tokens=0,
            total_output_tokens=0,
            total_cost_millicents=0,
            date_from=None,
            date_to=None,
            incomplete_count=0,
            project_stats=[],
            model_stats=[],
        )

    project_map: dict[str, ProjectStats] = {}
    model_map: dict[str, ModelStats] = {}

    total_input = 0
    total_output = 0
    total_cost: int | None = 0
    incomplete_count = 0
    dates: list[str] = []

    for rec in records:
        # project bucket
        if rec.project not in project_map:
            project_map[rec.project] = ProjectStats(project=rec.project)
        project_map[rec.project].add(rec)

        # model bucket
        if rec.model not in model_map:
            model_map[rec.model] = ModelStats(model=rec.model)
        model_map[rec.model].add(rec)

        # totals
        total_input += rec.input_tokens
        total_output += rec.output_tokens
        if total_cost is not None:
            if rec.cost_millicents is None:
                total_cost = None
            else:
                total_cost += rec.cost_millicents
        if not rec.tokens_complete:
            incomplete_count += 1
        dates.append(rec.requested_at)

    dates_sorted = sorted(dates)
    date_from = dates_sorted[0] if dates_sorted else None
    date_to = dates_sorted[-1] if dates_sorted else None

    return ReportData(
        records=records,
        total_requests=len(records),
        total_input_tokens=total_input,
        total_output_tokens=total_output,
        total_cost_millicents=total_cost,
        date_from=date_from,
        date_to=date_to,
        incomplete_count=incomplete_count,
        project_stats=sorted(project_map.values(), key=lambda s: s.project),
        model_stats=sorted(model_map.values(), key=lambda s: s.model),
    )


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def _format_date(iso_str: str | None) -> str:
    """Render an ISO 8601 string as a short human-readable date."""
    if iso_str is None:
        return "—"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.astimezone(UTC).strftime("%Y-%m-%d %H:%M UTC")
    except ValueError:
        return iso_str


def render_report(
    data: ReportData,
    console: Console,
    *,
    empty_hint: str | None = None,
) -> None:
    """
    Print the full report to *console* using rich formatting.

    Visual language matches the dashboard accent: warm orange brand,
    green ✓ for affirmative summary lines, dim grey for status/labels.
    No heavy table borders — minimal rules, right-aligned numbers.

    Args:
        data: Pre-aggregated ReportData from :func:`build_report_data`.
        console: Rich Console to print to.
        empty_hint: Pre-rendered Rich markup string to show when there
            are no records. Callers (typically the CLI) are expected to
            tailor this to actual daemon state — see
            :func:`halton_meter.cli._empty_records_hint`. If None, falls
            back to a generic line. (2B.12.1)
    """
    _render_header(data, console)

    if data.total_requests == 0:
        if empty_hint is None:
            empty_hint = (
                f"[{_MUTED}]no records yet. Run[/] "
                f"[bold]halton-meter start[/] "
                f"[{_MUTED}]to begin metering, then route an LLM API "
                f"call through your client.[/]"
            )
        console.print(empty_hint + "\n")
        return

    _render_summary(data, console)
    _render_project_table(data, console)
    _render_model_table(data, console)


def _render_header(data: ReportData, console: Console) -> None:
    """Brand line + date range — matches the daemon startup aesthetic."""
    range_str = ""
    if data.date_from and data.date_to:
        range_str = (
            f" [{_MUTED}]· "
            f"{_format_date(data.date_from)} → {_format_date(data.date_to)}[/]"
        )
    console.print()
    console.print(
        f"[bold {_BRAND}]halton-meter[/] "
        f"[{_MUTED}]v{__version__} · cost report[/]{range_str}"
    )
    console.print()


def _render_summary(data: ReportData, console: Console) -> None:
    """Top-level totals as ✓-prefixed lines."""
    project_count = len(data.project_stats)
    model_count = len(data.model_stats)
    project_word = "project" if project_count == 1 else "projects"
    model_word = "model" if model_count == 1 else "models"

    console.print(
        f"  [{_OK}]✓[/] "
        f"[bold]{data.total_requests:,}[/] "
        f"[{_MUTED}]requests across[/] "
        f"[bold]{project_count}[/] [{_MUTED}]{project_word} ·[/] "
        f"[bold]{model_count}[/] [{_MUTED}]{model_word}[/]"
    )
    console.print(
        f"  [{_OK}]✓[/] "
        f"[{_MUTED}]Tokens:[/] "
        f"[bold]{data.total_input_tokens:,}[/] [{_MUTED}]in ·[/] "
        f"[bold]{data.total_output_tokens:,}[/] [{_MUTED}]out[/]"
    )
    console.print(
        f"  [{_OK}]✓[/] "
        f"[{_MUTED}]Total cost:[/] "
        f"[bold {_BRAND}]{format_usd(data.total_cost_millicents)}[/]"
    )
    if data.incomplete_count > 0:
        console.print(
            f"  [{_WARN}]⚠[/] "
            f"[{_WARN}]{data.incomplete_count} incomplete record(s) — "
            f"token counts may be partial[/]"
        )
    console.print()


def _render_project_table(data: ReportData, console: Console) -> None:
    """Minimal-rules table — single underline below header, no box."""
    table = Table(
        box=box.SIMPLE_HEAD,
        show_edge=False,
        padding=(0, 2),
        header_style=_MUTED,
    )
    table.add_column(
        f"[{_MUTED}]by project[/]",
        no_wrap=True,
        style="bold",
    )
    table.add_column("requests", justify="right", style=_MUTED)
    table.add_column("in", justify="right", style=_MUTED)
    table.add_column("out", justify="right", style=_MUTED)
    table.add_column("cost", justify="right")
    table.add_column("avg latency", justify="right", style=_MUTED)

    for s in data.project_stats:
        table.add_row(
            s.project,
            f"{s.requests:,}",
            f"{s.input_tokens:,}",
            f"{s.output_tokens:,}",
            f"[{_BRAND}]{format_usd(s.cost_millicents)}[/]",
            f"{s.avg_latency_ms:.0f}ms",
        )

    console.print(table)


def _render_model_table(data: ReportData, console: Console) -> None:
    """Minimal-rules table for the per-model breakdown."""
    table = Table(
        box=box.SIMPLE_HEAD,
        show_edge=False,
        padding=(0, 2),
        header_style=_MUTED,
    )
    table.add_column(
        f"[{_MUTED}]by model[/]",
        no_wrap=True,
        style="bold",
    )
    table.add_column("requests", justify="right", style=_MUTED)
    table.add_column("in", justify="right", style=_MUTED)
    table.add_column("out", justify="right", style=_MUTED)
    table.add_column("cost", justify="right")

    for s in data.model_stats:
        table.add_row(
            s.model,
            f"{s.requests:,}",
            f"{s.input_tokens:,}",
            f"{s.output_tokens:,}",
            f"[{_BRAND}]{format_usd(s.cost_millicents)}[/]",
        )

    console.print(table)
    console.print()


# ---------------------------------------------------------------------------
# Date filtering helper (used by CLI)
# ---------------------------------------------------------------------------


def filter_records_by_days(records: list[LogRecord], since_days: int) -> list[LogRecord]:
    """
    Return records whose requested_at is within the last *since_days* days.

    A value of 0 returns no records (nothing happened "0 days ago").
    A value of 30 returns records from the last 30 days (default).

    Args:
        records: Full list of LogRecords to filter.
        since_days: Number of days to look back. 0 returns empty list.

    Returns:
        Filtered list of LogRecords.
    """
    if since_days <= 0:
        return []

    now = datetime.now(UTC)
    cutoff_ts = now.timestamp() - (since_days * 86400)

    result: list[LogRecord] = []
    for rec in records:
        try:
            dt = datetime.fromisoformat(rec.requested_at.replace("Z", "+00:00"))
            if dt.timestamp() >= cutoff_ts:
                result.append(rec)
        except ValueError:
            # If we can't parse the date, include the record (safe default)
            result.append(rec)
    return result
