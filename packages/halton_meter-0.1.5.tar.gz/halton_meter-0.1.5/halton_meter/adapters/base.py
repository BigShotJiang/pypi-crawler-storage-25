"""
Base types for provider adapters.

Defines the ProviderAdapter Protocol and the Pydantic data models that
all adapters produce. Adding a new provider means implementing this Protocol —
nothing else in the codebase needs to change.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field


class RequestMetadata(BaseModel):
    """
    Structured metadata extracted from an outbound LLM API request.

    Populated by ProviderAdapter.parse_request() before the request is forwarded.
    Carried through the flow and passed to parse_response() so the adapter can
    compute latency without needing to re-read the flow.
    """

    model_config = ConfigDict(frozen=True)

    provider: str = Field(description="Provider name, e.g. 'anthropic'")
    model: str = Field(description="Model identifier as returned by the provider")
    stream: bool = Field(description="True if the client requested a streaming response")
    started_at: float = Field(
        description="time.monotonic() value at request parse time, for latency computation"
    )


class ResponseMetadata(BaseModel):
    """
    Structured metadata extracted from a completed LLM API response.

    Populated by ProviderAdapter.parse_response() after the full body is available.
    Token fields default to 0 when absent. tokens_complete=False signals that
    the body was truncated (e.g. client disconnected mid-stream) — stored record
    should be marked incomplete rather than silently showing wrong counts.
    """

    model_config = ConfigDict(frozen=True)

    input_tokens: int = Field(default=0, description="Prompt tokens including system and tools")
    output_tokens: int = Field(default=0, description="Completion tokens")
    thinking_tokens: int = Field(
        default=0,
        description="Extended thinking tokens (Anthropic) or reasoning tokens (OpenAI o-series)",
    )
    cached_tokens: int = Field(default=0, description="Cache read tokens, priced separately")
    tokens_complete: bool = Field(
        default=True,
        description="False if the response body was truncated and counts may be partial",
    )
    latency_ms: float = Field(default=0.0, description="End-to-end latency in milliseconds")


@runtime_checkable
class ProviderAdapter(Protocol):
    """
    Protocol for provider-specific request/response parsers.

    Implementations must be:
    - Stateless: no instance-level mutable state that depends on request flow.
    - Pure: no I/O, no network calls, no filesystem access, no side effects.
    - Safe: must not raise — callers wrap in try/except but prefer not to need it.

    To add a new provider: implement this Protocol, add an instance to
    ADAPTER_REGISTRY in proxy.py. No other changes required.
    """

    name: str
    """Short provider identifier, e.g. 'anthropic'. Used in log fields and DB records."""

    domains: list[str]
    """Canonical hostnames this adapter handles, e.g. ['api.anthropic.com']."""

    def matches(self, host: str) -> bool:
        """
        Return True if this adapter should handle the given request host.

        Host may include a port suffix (e.g. 'api.anthropic.com:443').
        Implementations should use startswith() to handle both forms.
        """
        ...

    def parse_request(self, flow: object) -> RequestMetadata:
        """
        Extract metadata from an outbound request.

        Called with the full mitmproxy HTTPFlow after the request headers and
        body are available. Must return a RequestMetadata even on parse failure
        (use defaults). Must not raise.
        """
        ...

    def parse_response(
        self,
        flow: object,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """
        Extract metadata from a completed response.

        Called after the full response body has been received and accumulated
        by mitmproxy (including streamed SSE bodies). Must return a
        ResponseMetadata even on parse failure. Must not raise.
        """
        ...
