"""
Repository layer — wraps SQLAlchemy ORM/core in the existing daemon storage API.

The proxy hot path's call signatures are preserved verbatim:

    async with StorageManager(db_path) as storage:
        await storage.write_record(record)
        records = await storage.read_records(project="my-project")
        await storage.replace_policies(...)
        await storage.get_policies("my-project")
        await storage.get_running_monthly_total("my-project")
        await storage.get_today_request_count("my-project")
        await storage.mark_synced(...)         # legacy no-op (no remote sync)

Internally we delegate to the SQLAlchemy models defined in
``halton_meter.storage.models``. This is the **single** writer/reader
abstraction that proxy.py uses; the FastAPI routers go through SQLAlchemy
sessions directly via ``halton_meter.api.deps.get_session``.
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import structlog
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from halton_meter.models import LogRecord
from halton_meter.storage.engine import (
    create_engine_for,
    migrate_legacy_db_if_present,
)
from halton_meter.storage.models import (
    Base,
    Policy,
    PricingRate,
    Project,
    Request,
)

log = structlog.get_logger()


def _parse_iso(s: str | datetime) -> datetime:
    """Parse an ISO-8601 string (with or without trailing Z) into a UTC datetime."""
    if isinstance(s, datetime):
        if s.tzinfo is None:
            return s.replace(tzinfo=UTC)
        return s
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return datetime.now(tz=UTC)


def _to_iso(dt: datetime | None) -> str | None:
    """Format a datetime as ISO-8601 UTC with a trailing ``Z`` suffix.

    The proxy hot path and the daemon's report CLI expect "...Z" rather
    than "...+00:00"; the cloud backend does the same.
    """
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    iso = dt.astimezone(UTC).isoformat()
    return iso.replace("+00:00", "Z")


async def init_db(engine: AsyncEngine) -> None:
    """Run ``metadata.create_all`` against ``engine``.

    Idempotent for greenfield databases. Detects the **legacy daemon schema**
    (Phase 1 ``requests`` table that uses ``project TEXT`` instead of
    ``project_id`` FK) and renames it to ``requests_legacy`` before creating
    the v1.0 tables, so the user can keep their old data on disk for
    inspection without it confusing the new schema. The legacy ``policies``
    table is similarly renamed.
    """
    from sqlalchemy import inspect, text

    def _rename_if_legacy(sync_conn: object) -> None:
        insp = inspect(sync_conn)  # type: ignore[arg-type]
        for table in ("requests", "policies"):
            if not insp.has_table(table):
                continue
            cols = {c["name"] for c in insp.get_columns(table)}
            # Legacy daemon `requests` lacks project_id; legacy `policies`
            # lacks created_at. v1.0 tables include both.
            is_legacy = (table == "requests" and "project_id" not in cols) or (
                table == "policies" and "created_at" not in cols
            )
            if is_legacy:
                sync_conn.exec_driver_sql(  # type: ignore[attr-defined]
                    f"ALTER TABLE {table} RENAME TO {table}_legacy"
                )
                log.info("storage.legacy_table_renamed", table=table)

    async with engine.begin() as conn:
        await conn.run_sync(_rename_if_legacy)
        await conn.run_sync(Base.metadata.create_all)
    del text  # quiet unused-import lint


async def seed_pricing_rates(session: AsyncSession) -> int:
    """
    Seed the ``pricing_rates`` table from the bundled local matrix when empty.

    Returns the number of rows inserted. No-op if the table already has rows.
    """
    existing = await session.execute(select(func.count(PricingRate.id)))
    if int(existing.scalar_one() or 0) > 0:
        return 0

    # Lazy import — avoids a runtime cycle between pricing/ and storage/.
    from halton_meter.pricing.matrix import ANTHROPIC_RATES

    # Seed rows are valid retroactively from epoch — the bundled matrix is
    # the daemon's "this is the price right now and has been all along"
    # snapshot. Without epoch-effective_from, request rows with a slightly
    # older `requested_at` (e.g. tests using a fixed date) would miss the
    # rate and fall back to a NULL cost.
    now = datetime(1970, 1, 1, tzinfo=UTC)
    inserted = 0
    seen: set[tuple[str, str, str]] = set()
    for model_name, rates in ANTHROPIC_RATES.items():
        # The bundled matrix doubles up dated and undated aliases for the
        # same prices; insert each unique (provider, model, mode) once for
        # both 'standard' and 'thinking' modes — the cloud's ingest service
        # selects per-mode and the dashboard expects per-mode rows.
        for mode in ("standard", "thinking"):
            key = ("anthropic", model_name, mode)
            if key in seen:
                continue
            seen.add(key)
            session.add(
                PricingRate(
                    id=str(uuid.uuid4()),
                    provider="anthropic",
                    model=model_name,
                    mode=mode,
                    effective_from=now,
                    effective_to=None,
                    input_rate_per_million_minor_units=rates.input,
                    output_rate_per_million_minor_units=(
                        rates.thinking if mode == "thinking" else rates.output
                    ),
                    thinking_rate_per_million_minor_units=rates.thinking,
                    cache_read_rate_per_million_minor_units=rates.cache_read,
                    last_verified_at=None,
                )
            )
            inserted += 1
    await session.commit()
    log.info("storage.pricing_rates_seeded", count=inserted)
    return inserted


async def backfill_legacy_requests(
    sessionmaker: async_sessionmaker[AsyncSession],
    *,
    batch_size: int = 500,
    migration_marker: str = "backfill_legacy_requests_v1",
) -> int:
    """
    Backfill rows from a renamed ``requests_legacy`` table into the v1.0
    ``requests`` table.

    Idempotent — checked against a row in ``_migrations`` keyed by
    ``migration_marker``. Skips silently when:

    * ``requests_legacy`` does not exist (greenfield install or already-pruned DB)
    * the migration marker is already present

    The function never raises: any failure is logged and the daemon continues
    booting. Wraps inserts in batches of ``batch_size`` so a mid-run failure
    doesn't lose everything already migrated.

    Returns the number of rows successfully inserted.
    """
    from sqlalchemy import text

    inserted_total = 0
    try:
        # 1. Ensure _migrations table exists, then check the marker.
        async with sessionmaker() as session, session.begin():
            await session.execute(
                text(
                    "CREATE TABLE IF NOT EXISTS _migrations ("
                    "name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)"
                )
            )
            marker = await session.execute(
                text("SELECT 1 FROM _migrations WHERE name = :n"),
                {"n": migration_marker},
            )
            if marker.scalar_one_or_none() is not None:
                return 0

            legacy_present = await session.execute(
                text(
                    "SELECT 1 FROM sqlite_master "
                    "WHERE type='table' AND name='requests_legacy'"
                )
            )
            if legacy_present.scalar_one_or_none() is None:
                return 0

        # 2. Stream rows in chunks. We use OFFSET/LIMIT keyed by primary
        #    key ordering for stability — the legacy table is small enough
        #    (low thousands) that this is cheaper than wiring up cursors.
        project_cache: dict[str, Project] = {}
        offset = 0
        # Note: we do NOT emit `request.captured` audit events for backfilled
        # rows. The original capture predates the new audit ledger; emitting
        # them now would muddy "this is what happened in real time" semantics.
        while True:
            async with sessionmaker() as session, session.begin():
                rows_result = await session.execute(
                    text(
                        "SELECT id, project, provider, model, "
                        "input_tokens, output_tokens, thinking_tokens, "
                        "cached_tokens, cost_millicents, tokens_complete, "
                        "latency_ms, requested_at, recorded_at, status "
                        "FROM requests_legacy ORDER BY id "
                        "LIMIT :lim OFFSET :off"
                    ),
                    {"lim": batch_size, "off": offset},
                )
                rows = rows_result.all()
                if not rows:
                    break

                # Pre-filter existing ids in this batch to avoid IntegrityError
                # poisoning the surrounding transaction.
                ids = [row.id for row in rows]
                existing_result = await session.execute(
                    select(Request.id).where(Request.id.in_(ids))
                )
                existing_ids = {r[0] for r in existing_result.all()}

                for row in rows:
                    if row.id in existing_ids:
                        continue
                    slug = row.project or "unknown"
                    project = project_cache.get(slug)
                    if project is None:
                        project = await _get_or_create_project(session, slug)
                        project_cache[slug] = project

                    thinking = int(row.thinking_tokens or 0)
                    mode = "thinking" if thinking > 0 else "standard"

                    req = Request(
                        id=row.id,
                        project_id=project.id,
                        provider=row.provider,
                        model=row.model,
                        mode=mode,
                        input_tokens=int(row.input_tokens or 0),
                        output_tokens=int(row.output_tokens or 0),
                        thinking_tokens=thinking,
                        cached_tokens=int(row.cached_tokens or 0),
                        # Naming changed (millicents → minor_units) but the
                        # value is the same.
                        cost_usd_minor_units=row.cost_millicents,
                        latency_ms=(
                            float(row.latency_ms)
                            if row.latency_ms is not None
                            else None
                        ),
                        tokens_complete=bool(row.tokens_complete),
                        requested_at=_parse_iso(row.requested_at),
                        recorded_at=_parse_iso(row.recorded_at),
                        status=row.status or "success",
                    )
                    session.add(req)
                    inserted_total += 1
            offset += batch_size

        # 3. Stamp the migration marker.
        async with sessionmaker() as session, session.begin():
            await session.execute(
                text(
                    "INSERT OR IGNORE INTO _migrations (name, applied_at) "
                    "VALUES (:n, :t)"
                ),
                {
                    "n": migration_marker,
                    "t": datetime.now(tz=UTC).isoformat().replace("+00:00", "Z"),
                },
            )
        log.info("storage.backfill_completed", count=inserted_total)
        return inserted_total
    except Exception as exc:
        log.error(
            "storage.backfill_failed",
            error=str(exc),
            inserted_so_far=inserted_total,
            exc_info=True,
        )
        return inserted_total


async def _get_or_create_project(session: AsyncSession, slug: str) -> Project:
    """Return existing project by slug, or auto-create it."""
    result = await session.execute(select(Project).where(Project.slug == slug))
    project = result.scalar_one_or_none()
    if project is not None:
        return project
    project = Project(id=str(uuid.uuid4()), name=slug, slug=slug)
    session.add(project)
    try:
        await session.flush()
    except IntegrityError:
        # A concurrent writer beat us to it; refetch.
        await session.rollback()
        result = await session.execute(select(Project).where(Project.slug == slug))
        project = result.scalar_one()
    return project


class StorageManager:
    """
    Async context manager wrapping the daemon's SQLite store.

    Exposes the same surface that the proxy hot path used in Phase 1 — see
    module docstring for the public method list. Internally everything is
    SQLAlchemy 2.0 async sessions; the connection pool is shared with the
    FastAPI app via the engine cache in ``storage.engine``.
    """

    def __init__(self, db_path: str | Path) -> None:
        if isinstance(db_path, str) and db_path.startswith("sqlite"):
            self._db_path: str | Path = db_path
        else:
            self._db_path = Path(db_path).expanduser()
        self._engine: AsyncEngine | None = None
        self._sessionmaker: async_sessionmaker[AsyncSession] | None = None
        self._initialised = False

    async def __aenter__(self) -> StorageManager:
        await self.initialise()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def initialise(self) -> None:
        """Open the engine, run create_all, seed pricing rates if empty."""
        # Best-effort migration of the legacy ~/.halton-meter/logs.db file
        # — only when the daemon is running against the default DB path.
        # Tests using tmp_path must not pull the user's real legacy DB in.
        from halton_meter.storage.engine import DEFAULT_DB_PATH

        if isinstance(self._db_path, Path) and self._db_path == DEFAULT_DB_PATH:
            try:
                migrate_legacy_db_if_present(new_path=self._db_path)
            except Exception as exc:  # pragma: no cover
                log.warning("storage.legacy_migration_failed", error=str(exc))

        self._engine, self._sessionmaker = create_engine_for(self._db_path)
        await init_db(self._engine)

        # Seed pricing rates on first run (one-time, idempotent).
        async with self._sessionmaker() as session:
            try:
                await seed_pricing_rates(session)
            except Exception as exc:
                log.warning("storage.seed_failed", error=str(exc))

        # Backfill any rows that init_db() pushed into requests_legacy on
        # an in-place upgrade. Idempotent (guarded by a _migrations marker)
        # and never raises — failure here must not block daemon boot.
        try:
            await backfill_legacy_requests(self._sessionmaker)
        except Exception as exc:  # pragma: no cover — defensive
            log.warning("storage.backfill_unhandled_error", error=str(exc))

        self._initialised = True
        log.info("storage.initialised", db_path=str(self._db_path))

    async def close(self) -> None:
        """Mark closed. Engine disposal happens at process shutdown."""
        # Note: we deliberately do NOT dispose the engine here — the same
        # engine is shared with the FastAPI app, and short-lived
        # `async with StorageManager(...)` blocks (e.g. `halton-meter
        # report`) must not tear down a long-lived dashboard process.
        # `storage.engine.dispose_engines()` is the explicit teardown.
        self._initialised = False
        log.info("storage.closed", db_path=str(self._db_path))

    # ── Helpers ────────────────────────────────────────────────────────────

    def _session(self) -> AsyncSession:
        if self._sessionmaker is None:
            msg = "StorageManager not initialised — call initialise() first"
            raise RuntimeError(msg)
        return self._sessionmaker()

    # ── Proxy hot-path API ─────────────────────────────────────────────────

    async def write_record(self, record: LogRecord) -> None:
        """
        Insert a single LogRecord row into ``requests``, auto-creating the
        project on first sighting. Never raises — errors are logged and
        swallowed so the proxy hot path is never disrupted.

        On duplicate primary key (re-insertion of the same UUID), the row is
        silently dropped — same semantics as the legacy ``INSERT OR IGNORE``.
        """
        if self._sessionmaker is None:
            log.error("storage.write.no_connection", record_id=record.id)
            return
        try:
            from halton_meter.api.services.audit import log_event
            from halton_meter.api.services.ingest import recompute_cost

            async with self._sessionmaker() as session, session.begin():
                project = await _get_or_create_project(session, record.project)
                requested_at = _parse_iso(record.requested_at)
                recorded_at = _parse_iso(record.recorded_at)
                mode = "thinking" if (record.thinking_tokens or 0) > 0 else "standard"

                # Recompute cost authoritatively against the pricing_rates
                # table. Falls back to the bundled-matrix value the proxy
                # passed in if no rate row matches.
                final_cost, matched_rate = await recompute_cost(
                    session=session,
                    provider=record.provider,
                    model=record.model,
                    mode=mode,
                    requested_at=requested_at,
                    input_tokens=record.input_tokens,
                    output_tokens=record.output_tokens,
                    thinking_tokens=record.thinking_tokens,
                    cached_tokens=record.cached_tokens,
                    fallback=record.cost_millicents,
                )

                req = Request(
                    id=record.id,
                    project_id=project.id,
                    provider=record.provider,
                    model=record.model,
                    mode=mode,
                    input_tokens=record.input_tokens,
                    output_tokens=record.output_tokens,
                    thinking_tokens=record.thinking_tokens,
                    cached_tokens=record.cached_tokens,
                    cost_usd_minor_units=final_cost,
                    latency_ms=record.latency_ms,
                    tokens_complete=record.tokens_complete,
                    requested_at=requested_at,
                    recorded_at=recorded_at,
                    status=record.status,
                )
                session.add(req)
                try:
                    await session.flush()
                except IntegrityError:
                    # Same UUID inserted twice — accept silently.
                    await session.rollback()
                    return

                # Audit: request captured (always), cost computed (when a rate matched)
                await log_event(
                    session,
                    action="request.captured",
                    project_id=project.id,
                    request_id=record.id,
                    metadata={
                        "provider": record.provider,
                        "model": record.model,
                        "cost_usd_minor_units": final_cost,
                    },
                )
                if matched_rate is not None and final_cost is not None:
                    await log_event(
                        session,
                        action="request.cost_computed",
                        project_id=project.id,
                        request_id=record.id,
                        metadata={
                            "model": record.model,
                            "rate_id": str(matched_rate.id),
                            "cost_usd_minor_units": final_cost,
                        },
                    )
            log.debug(
                "storage.write.ok",
                record_id=record.id,
                project=record.project,
                model=record.model,
            )
        except Exception as exc:
            log.error(
                "storage.write.failed",
                record_id=record.id,
                error=str(exc),
                exc_info=True,
            )

    async def mark_synced(self, record_ids: list[str], synced_at: str) -> None:
        """No-op preserved for backward compat — v1.0 has no remote sync target."""
        # The cloud-sync worker is gone in v1.0 (see decisions.md
        # 2026-04-29). We keep the method to avoid breaking callers that
        # haven't been refactored yet.
        del record_ids, synced_at

    async def replace_policies(self, policies: list[dict[str, Any]]) -> None:
        """
        Replace all rows in the policies table with the supplied list.

        Preserved for backward compat with the policy-sync worker, which is
        also gone in v1.0. The policy CRUD API is now the only writer; this
        method is kept so the existing tests still exercise the table.
        Never raises.
        """
        if self._sessionmaker is None:
            return
        try:
            async with self._sessionmaker() as session, session.begin():
                await session.execute(delete(Policy))
                for p in policies:
                    project_id: str | None = None
                    slug = p.get("project_slug") or ""
                    if slug:
                        result = await session.execute(
                            select(Project).where(Project.slug == slug)
                        )
                        proj = result.scalar_one_or_none()
                        if proj is None:
                            proj = Project(
                                id=str(uuid.uuid4()), name=slug, slug=slug
                            )
                            session.add(proj)
                            await session.flush()
                        project_id = proj.id

                    policy_id = p.get("id") or str(uuid.uuid4())
                    session.add(
                        Policy(
                            id=policy_id,
                            project_id=project_id,
                            type=p.get("type", ""),
                            config=p.get("config", {}) or {},
                            active=True,
                            warn_only=bool(p.get("warn_only", True)),
                        )
                    )
            log.debug("storage.policies_replaced", count=len(policies))
        except Exception as exc:
            log.error("storage.replace_policies.failed", error=str(exc), exc_info=True)

    async def get_policies(self, project: str) -> list[dict[str, Any]]:
        """Return all active policies for a project (and unscoped policies)."""
        if self._sessionmaker is None:
            return []
        try:
            async with self._sessionmaker() as session:
                # Resolve project id (may not exist yet).
                proj_result = await session.execute(
                    select(Project).where(Project.slug == project)
                )
                proj = proj_result.scalar_one_or_none()

                conditions = [Policy.active.is_(True)]
                if proj is not None:
                    conditions.append(
                        (Policy.project_id == proj.id) | (Policy.project_id.is_(None))
                    )
                else:
                    # No project row yet — only global policies apply.
                    conditions.append(Policy.project_id.is_(None))

                result = await session.execute(select(Policy).where(*conditions))
                rows = result.scalars().all()
                return [
                    {
                        "id": str(r.id),
                        "project_slug": project,
                        "type": r.type,
                        "config": r.config or {},
                        "warn_only": bool(r.warn_only),
                    }
                    for r in rows
                ]
        except Exception as exc:
            log.error("storage.get_policies.failed", error=str(exc))
            return []

    async def get_running_monthly_total(self, project: str) -> int:
        """Sum of cost for ``project`` since the first day of the current UTC month."""
        if self._sessionmaker is None:
            return 0
        first_of_month = datetime.now(tz=UTC).replace(
            day=1, hour=0, minute=0, second=0, microsecond=0
        )
        try:
            async with self._sessionmaker() as session:
                proj_result = await session.execute(
                    select(Project).where(Project.slug == project)
                )
                proj = proj_result.scalar_one_or_none()
                if proj is None:
                    return 0
                result = await session.execute(
                    select(func.coalesce(func.sum(Request.cost_usd_minor_units), 0))
                    .where(
                        Request.project_id == proj.id,
                        Request.requested_at >= first_of_month,
                        Request.cost_usd_minor_units.is_not(None),
                    )
                )
                return int(result.scalar_one() or 0)
        except Exception as exc:
            log.error("storage.get_running_monthly_total.failed", error=str(exc))
            return 0

    async def get_today_request_count(self, project: str) -> int:
        """Count of requests for ``project`` since midnight UTC today."""
        if self._sessionmaker is None:
            return 0
        today_midnight = datetime.now(tz=UTC).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        try:
            async with self._sessionmaker() as session:
                proj_result = await session.execute(
                    select(Project).where(Project.slug == project)
                )
                proj = proj_result.scalar_one_or_none()
                if proj is None:
                    return 0
                result = await session.execute(
                    select(func.count(Request.id)).where(
                        Request.project_id == proj.id,
                        Request.requested_at >= today_midnight,
                    )
                )
                return int(result.scalar_one() or 0)
        except Exception as exc:
            log.error("storage.get_today_request_count.failed", error=str(exc))
            return 0

    async def read_records(
        self,
        project: str | None = None,
        limit: int = 500,
        unsynced_only: bool = False,  # kept for compat — no-op in v1.0
    ) -> list[LogRecord]:
        """
        Read log records ordered by ``requested_at DESC``.

        ``unsynced_only`` is preserved for backward compat with the deleted
        sync worker; in v1.0 it always returns an empty list (there is no
        remote sync, so "unsynced" is undefined). Tests for the sync worker
        no longer exist.
        """
        if self._sessionmaker is None:
            msg = "StorageManager not initialised — call initialise() first"
            raise RuntimeError(msg)

        if unsynced_only:
            return []

        async with self._sessionmaker() as session:
            stmt = (
                select(Request, Project.slug)
                .join(Project, Request.project_id == Project.id)
                .order_by(Request.requested_at.desc())
                .limit(limit)
            )
            if project is not None:
                stmt = stmt.where(Project.slug == project)
            result = await session.execute(stmt)
            rows = result.all()
            return [
                LogRecord(
                    id=r.id,
                    project=slug,
                    provider=r.provider,
                    model=r.model,
                    input_tokens=r.input_tokens,
                    output_tokens=r.output_tokens,
                    thinking_tokens=r.thinking_tokens,
                    cached_tokens=r.cached_tokens,
                    cost_millicents=r.cost_usd_minor_units,
                    tokens_complete=bool(r.tokens_complete),
                    latency_ms=float(r.latency_ms) if r.latency_ms is not None else 0.0,
                    requested_at=_to_iso(r.requested_at) or "",
                    recorded_at=_to_iso(r.recorded_at) or "",
                    status=r.status or "success",
                )
                for r, slug in rows
            ]


# Make the JSON helper available to in-tests fixtures that want to encode
# config blobs the same way the worker does.
__all__ = [
    "StorageManager",
    "backfill_legacy_requests",
    "init_db",
    "json",
    "seed_pricing_rates",
]
