"""Request model — one row per captured LLM API call.

This is the union of:
  * the daemon's existing `requests` table (proxy hot-path writer)
  * the cloud backend's `requests` table (FK to projects, FastAPI reader)

The daemon's old `project TEXT` slug is replaced by `project_id` (FK to
projects). The proxy write path auto-creates the row in `projects` on first
sighting via `services.ingest._get_or_create_project`.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class Request(Base):
    __tablename__ = "requests"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    project_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("projects.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    model: Mapped[str] = mapped_column(String(255), nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="standard")

    input_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    thinking_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    cached_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Cost in millicents: 1 USD = 100_000 millicents. NULL if model unknown.
    cost_usd_minor_units: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    # Stored as REAL — daemon's existing schema has latency_ms as float, not int.
    latency_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    tokens_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    requested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    source_machine: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_workdir: Mapped[str | None] = mapped_column(Text, nullable=True)
    attribution_method: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="success")

    project: Mapped[Project] = relationship(  # noqa: F821 — forward ref
        "Project", back_populates="requests"
    )

    __table_args__ = (
        Index("idx_requests_project_requested_at", "project_id", "requested_at"),
        Index("idx_requests_provider_model_requested_at", "provider", "model", "requested_at"),
    )
