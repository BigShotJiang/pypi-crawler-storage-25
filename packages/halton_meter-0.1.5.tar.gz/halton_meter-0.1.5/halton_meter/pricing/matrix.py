"""
TEMP-PHASE-0: Hardcoded Anthropic pricing matrix for Phase 0 only.

This module will be removed when the backend takes over cost computation
in Phase 1. Tracked in memory/decisions.md 2026-04-28.

Rates are in millicents per million tokens (1 USD = 100_000 millicents,
so $3.00/MTok = 300_000 millicents/MTok).

Decision reference: memory/decisions.md 2026-04-28 — "Daemon Phase 0
computes cost locally"

Source: Anthropic published rates as of 2026-04-28.
  https://www.anthropic.com/api

Format per model entry:
  "model-id": ModelRates(
      input=<millicents per million input tokens>,
      output=<millicents per million output tokens>,
      thinking=<millicents per million thinking/reasoning tokens>,
      cache_read=<millicents per million cached-read tokens>,
  )
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelRates:
    """Pricing rates for a single model, in millicents per million tokens."""

    input: int
    """Millicents per million input tokens (prompt + system + tools)."""

    output: int
    """Millicents per million output tokens (completion)."""

    thinking: int
    """Millicents per million thinking/reasoning tokens (same as output for Anthropic)."""

    cache_read: int
    """Millicents per million cache-read tokens."""


# TEMP-PHASE-0: Anthropic rates as of 2026-04-28.
# $1 USD = 100_000 millicents.
# Rates in millicents per million tokens.
#
# Model                Input $/MTok  Output $/MTok  Thinking $/MTok  Cache read $/MTok
# claude-opus-4-7      $5.00         $25.00         $25.00           $0.50
# claude-opus-4-6      $5.00         $25.00         $25.00           $0.50
# claude-sonnet-4-6    $3.00         $15.00         $15.00           $0.30
# claude-haiku-4-5     $1.00         $5.00          $5.00            $0.10

_MILLICENTS_PER_DOLLAR = 100_000


def _usd(dollars_per_million: float) -> int:
    """Convert USD/MTok rate to millicents/MTok."""
    return round(dollars_per_million * _MILLICENTS_PER_DOLLAR)


ANTHROPIC_RATES: dict[str, ModelRates] = {
    # ----------------------------------------------------------------
    # Claude Opus 4.7 (latest Opus)
    # ----------------------------------------------------------------
    "claude-opus-4-7": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    # Dated snapshot alias
    "claude-opus-4-7-20260101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    # ----------------------------------------------------------------
    # Claude Opus 4.6
    # ----------------------------------------------------------------
    "claude-opus-4-6": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    "claude-opus-4-6-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    # ----------------------------------------------------------------
    # Claude Sonnet 4.6
    # ----------------------------------------------------------------
    "claude-sonnet-4-6": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
    "claude-sonnet-4-6-20251101": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
    # ----------------------------------------------------------------
    # Claude Haiku 4.5
    # ----------------------------------------------------------------
    "claude-haiku-4-5": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
    ),
    "claude-haiku-4-5-20251001": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
    ),
    # ----------------------------------------------------------------
    # Legacy Opus 4.5 / 4.1 / 4.0 (still in use on some machines)
    # ----------------------------------------------------------------
    "claude-opus-4-5": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    "claude-opus-4-5-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    "claude-opus-4-1": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    "claude-opus-4-1-20250805": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
    ),
    # ----------------------------------------------------------------
    # Legacy Sonnet 4.5 / 4.0
    # ----------------------------------------------------------------
    "claude-sonnet-4-5": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
    "claude-sonnet-4-5-20250929": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
    "claude-sonnet-4-0": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
    "claude-sonnet-4-20250514": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
    ),
}
