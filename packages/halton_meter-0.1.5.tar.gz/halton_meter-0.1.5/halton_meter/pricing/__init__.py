"""
Pricing module for Halton Meter daemon.

TEMP-PHASE-0: Local cost computation using a hardcoded matrix.
Will be removed when the backend takes over in Phase 1.
See memory/decisions.md 2026-04-28.

Public API:
    compute_cost_millicents(model, input_tokens, output_tokens,
                            thinking_tokens, cached_tokens) -> int | None
"""

from __future__ import annotations

from halton_meter.pricing.matrix import ANTHROPIC_RATES


def compute_cost_millicents(
    model: str,
    input_tokens: int,
    output_tokens: int,
    thinking_tokens: int,
    cached_tokens: int,
) -> int | None:
    """
    Compute the cost of a request in millicents (1 USD = 100_000 millicents).

    Returns None if the model is not in the pricing matrix (unknown model),
    so that cost_millicents can be stored as NULL in the DB rather than
    incorrectly as 0.

    Rates are per million tokens, so we divide by 1_000_000 and keep integer
    arithmetic throughout to avoid float precision issues.

    Args:
        model: The model identifier string (e.g. 'claude-sonnet-4-6').
        input_tokens: Prompt tokens including system and tools.
        output_tokens: Completion tokens.
        thinking_tokens: Extended thinking / reasoning tokens.
        cached_tokens: Cache-read tokens (priced lower than fresh input tokens).

    Returns:
        Cost in millicents as an integer, or None if model is unknown.
    """
    rates = ANTHROPIC_RATES.get(model)
    if rates is None:
        return None

    # Cost = tokens * (rate_per_million / 1_000_000)
    # We use integer arithmetic: cost_millicents = tokens * rate_per_million // 1_000_000
    # Integer division is fine here — the smallest representable unit is 1 millicent,
    # and rounding sub-millicent amounts is negligible over many requests.
    cost = (
        input_tokens * rates.input // 1_000_000
        + output_tokens * rates.output // 1_000_000
        + thinking_tokens * rates.thinking // 1_000_000
        + cached_tokens * rates.cache_read // 1_000_000
    )
    return cost
