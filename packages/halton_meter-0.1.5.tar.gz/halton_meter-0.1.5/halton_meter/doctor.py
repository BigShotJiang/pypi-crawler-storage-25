"""``halton-meter doctor`` — single-command install diagnostic (v0.1.3 P0-7).

Prints every signal that matters for "is metering working" with concrete
next-action guidance per row, plus a top-line BROKEN / INCONSISTENT /
HEALTHY verdict that's mode-aware (env-var-only vs --gui).

Designed to be copy-pasteable into a support ticket. The optional
``--curl`` probe targets ``https://example.com`` ONLY — never a provider
domain. Regression-tested.

``--json`` emits a structured report for scripted consumption.
"""

from __future__ import annotations

import json as _json
import platform as _platform
import shutil
import subprocess
import sys as _sys
from dataclasses import dataclass, field
from typing import Any

import click
from rich.console import Console
from rich.table import Table

from halton_meter import __version__

# Verdict constants. Order matters for severity comparisons.
VERDICT_HEALTHY = "HEALTHY"
VERDICT_INCONSISTENT = "INCONSISTENT"
VERDICT_BROKEN = "BROKEN"

# --curl probe target. Must NEVER be a provider domain. Tested by
# ``test_doctor_curl_target_is_safe``.
_CURL_PROBE_URL = "https://example.com"
# Substrings that must NEVER appear in _CURL_PROBE_URL.
_FORBIDDEN_HOST_FRAGMENTS = (
    "anthropic",
    "openai",
    "googleapis",
    "gemini",
    "groq",
    "x.ai",
    "cohere",
    "mistral",
    "deepseek",
)


@dataclass
class DoctorRow:
    """One row in the doctor report."""

    name: str
    icon: str  # "ok" / "warn" / "fail" — UI translates to glyph + colour
    summary: str
    next_action: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class DoctorReport:
    verdict: str  # HEALTHY / INCONSISTENT / BROKEN
    summary_message: str
    rows: list[DoctorRow]
    mode: str | None  # env-only / apps / full / unknown (legacy "gui" reads as "full")
    platform: str
    version: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "summary_message": self.summary_message,
            "mode": self.mode,
            "platform": self.platform,
            "version": self.version,
            "rows": [
                {
                    "name": r.name,
                    "icon": r.icon,
                    "summary": r.summary,
                    "next_action": r.next_action,
                    "raw": r.raw,
                }
                for r in self.rows
            ],
        }


def _icon_glyph(icon: str) -> str:
    return {"ok": "[green]✓[/green]", "warn": "[yellow]⚠[/yellow]", "fail": "[red]✗[/red]"}.get(
        icon, "·"
    )


def _icon_plain(icon: str) -> str:
    return {"ok": "OK", "warn": "WARN", "fail": "FAIL"}.get(icon, "??")


def _read_install_mode() -> str | None:
    """Best-effort read of the install-mode sentinel."""
    from halton_meter import init as init_module

    return init_module.read_install_mode()


def _build_rows(*, run_curl: bool) -> tuple[list[DoctorRow], str | None, str]:
    """Build the diagnostic rows. Returns ``(rows, mode, platform)``."""
    rows: list[DoctorRow] = []
    plat = _sys.platform

    # --- Platform info -----------------------------------------------------
    rows.append(
        DoctorRow(
            "Platform",
            "ok",
            f"{_platform.system()} {_platform.machine()} python={_platform.python_version()}",
            raw={
                "system": _platform.system(),
                "machine": _platform.machine(),
                "python": _platform.python_version(),
            },
        )
    )

    # --- Mode --------------------------------------------------------------
    mode = _read_install_mode()
    rows.append(
        DoctorRow(
            "Install mode",
            "ok" if mode is not None else "warn",
            mode if mode is not None else "unknown (older install / sentinel missing)",
            next_action=(
                "run `halton-meter init` to (re)write the install-mode sentinel"
                if mode is None
                else None
            ),
            raw={"mode": mode},
        )
    )

    # --- Effective config (ports) ------------------------------------------
    try:
        from halton_meter.port_alloc import load_effective_config

        cfg = load_effective_config()
        listen_host = cfg.daemon.listen_host
        listen_port = cfg.daemon.listen_port
        api_host = cfg.daemon.api_host
        api_port = cfg.daemon.api_port
    except Exception as exc:
        rows.append(
            DoctorRow(
                "Effective config",
                "fail",
                f"could not load: {exc}",
                next_action="check ~/.halton-meter/config.toml syntax",
            )
        )
        return rows, mode, plat
    # v0.1.4 (2B.15) P0-5: surface auto-port-fallback explicitly. When
    # the chosen port differs from the marketed default, append a
    # human-readable note so the user knows the daemon picked a
    # non-default port (and therefore their tool config must target
    # the actual one, not the default). Icon stays "ok" — a fallback
    # is informative, not a failure mode; the doctor verdict must not
    # downgrade to INCONSISTENT just because 8080 was busy.
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    fallback_notes: list[str] = []
    if listen_port != LISTEN_PORT_DEFAULT:
        fallback_notes.append(
            f"proxy fell back from busy default :{LISTEN_PORT_DEFAULT} to :{listen_port}"
        )
    if api_port != API_PORT_DEFAULT:
        fallback_notes.append(
            f"api fell back from busy default :{API_PORT_DEFAULT} to :{api_port}"
        )
    if fallback_notes:
        ports_summary = (
            f"listen={listen_host}:{listen_port}  api={api_host}:{api_port}  "
            f"({'; '.join(fallback_notes)})"
        )
    else:
        ports_summary = (
            f"listen={listen_host}:{listen_port}  api={api_host}:{api_port}"
        )
    rows.append(
        DoctorRow(
            "Effective ports",
            "ok",
            ports_summary,
            raw={
                "listen_host": listen_host,
                "listen_port": listen_port,
                "api_host": api_host,
                "api_port": api_port,
                "listen_default": LISTEN_PORT_DEFAULT,
                "api_default": API_PORT_DEFAULT,
                "fallback": bool(fallback_notes),
            },
        )
    )

    # --- Daemon /health ----------------------------------------------------
    from halton_meter.health import (
        check_daemon_health,
        check_install_mode_sentinel,
        check_plists_loaded_macos,
        check_port_persisted,
        shell_env_present,
    )

    h = check_daemon_health(api_host, api_port, timeout=2.0)
    rows.append(
        DoctorRow(
            "Daemon /health",
            "ok" if h.ok else "fail",
            h.message,
            next_action=None if h.ok else "run `halton-meter start`",
        )
    )

    # --- Cert trust (macOS only) -------------------------------------------
    cert_trusted: bool | None = None
    if plat == "darwin":
        from halton_meter.setup import (
            _is_cert_trusted_macos,
            _verify_cert_trust_macos_raw,
        )

        rc, stdout, stderr = _verify_cert_trust_macos_raw()
        cert_trusted = _is_cert_trusted_macos()
        rows.append(
            DoctorRow(
                "Cert trust (security verify-cert -p ssl)",
                "ok" if cert_trusted else "fail",
                f"rc={rc} (trusted={cert_trusted})",
                next_action=(
                    None
                    if cert_trusted
                    else "run `halton-meter setup --force` to re-add the CA cert. "
                    "If MDM blocks the trust setting, contact your IT admin."
                ),
                raw={
                    "verify_cert_rc": rc,
                    "verify_cert_stdout": stdout,
                    "verify_cert_stderr": stderr,
                },
            )
        )

        # Phase 1 secondary diagnostic: parse trust-settings-export for
        # the mitmproxy CA's SHA-1. Surface in raw so support tickets can
        # distinguish drift modes.
        admin_trust = _admin_trust_contains_mitmproxy_sha1()
        if admin_trust is not None:
            rows.append(
                DoctorRow(
                    "Admin trust contains mitmproxy SHA-1",
                    "ok" if admin_trust["matched"] else "warn",
                    f"matched={admin_trust['matched']}  sha1={admin_trust['sha1']}",
                    next_action=None,
                    raw=admin_trust,
                )
            )

    # --- System proxy state per interface (macOS) --------------------------
    if plat == "darwin":
        from halton_meter import system_proxy

        ifaces = system_proxy._macos_interfaces()
        any_points_at_us = False
        per_iface: dict[str, dict[str, dict[str, Any]]] = {}
        for iface in ifaces:
            per_iface[iface] = {}
            for kind, secure in (("https", True), ("http", False)):
                enabled, host, port = system_proxy._read_macos_proxy(
                    iface, secure=secure
                )
                per_iface[iface][kind] = {
                    "enabled": enabled,
                    "host": host,
                    "port": port,
                }
                if enabled and system_proxy._proxy_targets_us(
                    host, port, listen_host, listen_port
                ):
                    any_points_at_us = True

        # v0.1.5 (2B.16) three-mode verdict:
        # * env-only: SHOULD NOT point at us. ok if not, ok if so (we
        #   tolerate user-managed proxies — only flag if they target
        #   our daemon).
        # * apps: SHOULD NOT point at us. If it does, treat as DRIFT
        #   (fail) — the apps mode promise is "system proxy is left
        #   alone"; pointing at us means a stale full-mode install
        #   wasn't cleaned up.
        # * full: MUST point at us; failure is fatal.
        # * unknown mode (sentinel missing): warn so the verdict is
        #   INCONSISTENT.
        if mode == "env-only":
            icon = "ok"  # env-only never asserts on system proxy state
        elif mode == "apps":
            # apps mode REQUIRES system proxy NOT to point at us. Drift =
            # fail.
            icon = "fail" if any_points_at_us else "ok"
        elif mode == "full":
            icon = "ok" if any_points_at_us else "fail"
        else:
            icon = "ok" if any_points_at_us else "warn"
        msg_kind = "points-at-us" if any_points_at_us else "not-pointing-at-us"
        if mode == "apps" and any_points_at_us:
            next_action = (
                "stale full-mode state — re-run `halton-meter init --apps` to "
                "reconcile (or `halton-meter uninstall` then re-init)"
            )
        elif mode == "full" and not any_points_at_us:
            next_action = "run `halton-meter init --full` to enable system proxy"
        else:
            next_action = None
        rows.append(
            DoctorRow(
                "System proxy",
                icon,
                f"{msg_kind} across {len(ifaces)} interfaces",
                next_action=next_action,
                raw={"interfaces": per_iface},
            )
        )

    # --- launchctl env vars (macOS) ----------------------------------------
    if plat == "darwin":
        from halton_meter.system_proxy import (
            GUI_LAUNCHCTL_ENV_KEYS,
            getenv_user_domain,
        )

        launchctl_env: dict[str, str | None] = {
            k: getenv_user_domain(k) for k in GUI_LAUNCHCTL_ENV_KEYS
        }
        any_set = any(v is not None for v in launchctl_env.values())
        # v0.1.5 (2B.16) three-mode verdict:
        # * env-only: SHOULD be unset (drift = stale apps/full state).
        # * apps + full: MUST be set (it's how those modes deliver
        #   their coverage).
        if mode == "env-only":
            icon = "ok" if not any_set else "warn"
            summary = (
                "all unset (expected for env-only mode)"
                if not any_set
                else "some env vars are set despite env-only mode "
                "(stale apps/full state?)"
            )
            next_action = (
                None if not any_set
                else "run `halton-meter init` to reconcile env-only mode"
            )
        elif mode in ("apps", "full"):
            icon = "ok" if any_set else "fail"
            summary = (
                f"{sum(1 for v in launchctl_env.values() if v is not None)}/"
                f"{len(launchctl_env)} keys set"
            )
            next_action = (
                None if any_set
                else f"run `halton-meter init --{mode}` to (re)write "
                "launchctl env"
            )
        else:
            # Unknown mode — informational.
            icon = "warn" if not any_set else "ok"
            n_set = sum(1 for v in launchctl_env.values() if v is not None)
            summary = f"{n_set}/{len(launchctl_env)} keys set"
            next_action = None
        rows.append(
            DoctorRow(
                "launchctl env (user domain)",
                icon,
                summary,
                next_action=next_action,
                raw={"env": launchctl_env},
            )
        )

    # --- Shell rc marker --------------------------------------------------
    if plat == "darwin":
        from halton_meter.init import (
            SHELL_RC_BLOCK_BEGIN,
            detect_shell_rc,
        )

        rc_path = detect_shell_rc()
        marker_present = False
        if rc_path is not None and rc_path.exists():
            try:
                marker_present = SHELL_RC_BLOCK_BEGIN in rc_path.read_text(
                    encoding="utf-8"
                )
            except OSError:
                pass
        if mode == "env-only":
            icon = "ok"  # shell-rc is apps/full-only; not having it is correct
            summary = (
                "(env-only mode does not append shell rc)"
                if not marker_present
                else "marker present despite env-only mode (stale)"
            )
            if marker_present:
                next_action = (
                    "run `halton-meter init` to reconcile env-only mode"
                )
            else:
                next_action = None
        elif mode in ("apps", "full"):
            icon = "ok" if marker_present else "warn"
            summary = (
                f"marker present in {rc_path}"
                if marker_present and rc_path
                else "marker not found (user may have declined the prompt)"
            )
            next_action = (
                None if marker_present
                else f"re-run `halton-meter init --{mode}` and accept "
                "the shell rc prompt"
            )
        else:
            icon = "warn"
            summary = (
                f"marker present in {rc_path}"
                if marker_present and rc_path
                else "marker not found"
            )
            next_action = None
        rows.append(
            DoctorRow(
                "Shell rc marker",
                icon,
                summary,
                next_action=next_action,
                raw={
                    "rc_path": str(rc_path) if rc_path else None,
                    "marker_present": marker_present,
                },
            )
        )

    # --- Per-tool env presence in current shell ---------------------------
    snap = shell_env_present()
    set_count = sum(1 for v in snap.values() if v)
    rows.append(
        DoctorRow(
            "Shell env (this process)",
            "ok" if set_count > 0 else "warn",
            f"{set_count}/{len(snap)} keys set",
            next_action=(
                None if set_count > 0
                else "in --gui mode after rc append, open a new shell. "
                "in env-only mode, use `halton-meter run <cmd>`."
            ),
            raw={"env": snap},
        )
    )

    # --- Plist (macOS) ----------------------------------------------------
    if plat == "darwin":
        plist_check = check_plists_loaded_macos()
        rows.append(
            DoctorRow(
                "Daemon plist registered",
                "ok" if plist_check.ok else "fail",
                plist_check.message,
                next_action=(
                    None if plist_check.ok else "run `halton-meter start`"
                ),
            )
        )

    # --- Sentinel file ----------------------------------------------------
    sentinel_check = check_install_mode_sentinel()
    rows.append(
        DoctorRow(
            sentinel_check.name,
            "ok" if sentinel_check.ok else "warn",
            sentinel_check.message,
            next_action=(
                None if sentinel_check.ok else "run `halton-meter init`"
            ),
        )
    )

    port_persist_check = check_port_persisted()
    rows.append(
        DoctorRow(
            port_persist_check.name,
            "ok",
            port_persist_check.message,
            next_action=None,
        )
    )

    # --- Optional curl probe ----------------------------------------------
    if run_curl:
        # Safety guard: assert nothing in the URL points at a provider.
        for forbidden in _FORBIDDEN_HOST_FRAGMENTS:
            assert forbidden not in _CURL_PROBE_URL, (
                f"FATAL: doctor --curl target {_CURL_PROBE_URL!r} contains "
                f"forbidden fragment {forbidden!r}; refusing to run probe"
            )
        rows.append(_run_curl_probe(api_host=api_host, listen_port=listen_port))

    return rows, mode, plat


def _run_curl_probe(*, api_host: str, listen_port: int) -> DoctorRow:
    """Probe ``https://example.com`` via the proxy. Returns a DoctorRow."""
    from halton_meter.setup import _certifi_bundle_path

    if not shutil.which("curl"):
        return DoctorRow(
            "Curl probe",
            "warn",
            "curl not found on PATH",
            next_action="install curl or run `halton-meter doctor` without --curl",
        )

    try:
        bundle = _certifi_bundle_path()
    except Exception as exc:
        return DoctorRow(
            "Curl probe",
            "fail",
            f"certifi bundle missing: {exc}",
            next_action="run `halton-meter setup` to re-create the patched bundle",
        )

    proxy_url = f"http://{api_host}:{listen_port}"
    cmd = [
        "curl",
        "-sS",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "--max-time",
        "10",
        "-x",
        proxy_url,
        "--cacert",
        str(bundle),
        _CURL_PROBE_URL,
    ]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return DoctorRow(
            "Curl probe",
            "fail",
            f"curl failed: {exc}",
            next_action=None,
            raw={"cmd": cmd, "error": str(exc)},
        )
    code = (result.stdout or "").strip()
    ok = code.startswith("2") or code.startswith("3")
    return DoctorRow(
        "Curl probe",
        "ok" if ok else "fail",
        f"GET {_CURL_PROBE_URL} via {proxy_url} -> HTTP {code or 'unknown'}",
        next_action=(
            None if ok
            else "if cert trust failed, the daemon refuses to enable the system proxy. "
            "doctor's cert-trust row above explains."
        ),
        raw={
            "url": _CURL_PROBE_URL,
            "proxy": proxy_url,
            "rc": result.returncode,
            "http_code": code,
            "stderr": (result.stderr or "")[-2000:],
        },
    )


def _admin_trust_contains_mitmproxy_sha1() -> dict[str, Any] | None:
    """Phase 1 secondary diagnostic (Approach B): parse
    ``security trust-settings-export -d <plist>`` and check whether the
    mitmproxy CA's SHA-1 appears as an admin-domain trust entry.

    Returns ``{"matched": bool, "sha1": str | None}`` or ``None`` if the
    probe could not run (non-macOS / missing tools / parsing failure).
    """
    if _sys.platform != "darwin":
        return None
    from halton_meter.setup import MITMPROXY_CERT_PATH

    if not MITMPROXY_CERT_PATH.exists():
        return None
    if not shutil.which("security") or not shutil.which("openssl"):
        return None
    # Compute mitmproxy CA SHA-1.
    try:
        sha_proc = subprocess.run(
            ["openssl", "x509", "-in", str(MITMPROXY_CERT_PATH), "-noout", "-fingerprint", "-sha1"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if sha_proc.returncode != 0:
        return None
    sha_line = (sha_proc.stdout or "").strip()
    # Format: "SHA1 Fingerprint=AB:CD:..."
    sha1 = sha_line.split("=", 1)[-1].strip().replace(":", "").upper() if "=" in sha_line else None
    if sha1 is None or len(sha1) != 40:
        return None

    # Export trust settings to a temp plist and grep for the SHA-1. We
    # don't parse the plist properly — just check substring presence,
    # which is robust against schema variation.
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".plist", delete=False) as tf:
        tmp_path = tf.name
    try:
        export_proc = subprocess.run(
            ["security", "trust-settings-export", "-d", tmp_path],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if export_proc.returncode != 0:
            return {"matched": False, "sha1": sha1}
        try:
            with open(tmp_path, "rb") as fh:
                content = fh.read()
        except OSError:
            return {"matched": False, "sha1": sha1}
        # SHA-1 may appear as either uppercase or with colons stripped.
        # The plist uses the cert's DER bytes for the trust-settings key,
        # not necessarily the SHA-1 directly. Do a best-effort grep on
        # the human-readable key form.
        matched = sha1.encode("ascii") in content.upper()
        return {"matched": matched, "sha1": sha1}
    finally:
        try:
            import os

            os.unlink(tmp_path)
        except OSError:
            pass


# --------------------------------------------------------------------------- #
# Verdict computation                                                         #
# --------------------------------------------------------------------------- #


def _compute_verdict(rows: list[DoctorRow], mode: str | None) -> tuple[str, str]:
    """Return ``(verdict, summary_message)``.

    Mode-aware decision matrix:

    * Any "fail" icon in fatal rows -> BROKEN.
    * Any "warn" icon -> INCONSISTENT (only when mode is known and
      something is mismatched).
    * Otherwise -> HEALTHY.

    The summary message names the leading symptom for the user.
    """
    fails = [r for r in rows if r.icon == "fail"]
    if fails:
        first = fails[0]
        return (
            VERDICT_BROKEN,
            f"{first.name}: {first.summary}"
            + (f"  ({first.next_action})" if first.next_action else ""),
        )
    warns = [r for r in rows if r.icon == "warn"]
    if warns:
        first = warns[0]
        return (
            VERDICT_INCONSISTENT,
            f"{first.name}: {first.summary}"
            + (f"  ({first.next_action})" if first.next_action else ""),
        )
    if mode == "env-only":
        return (
            VERDICT_HEALTHY,
            "env-var-only mode is healthy. "
            "Use `halton-meter run <cmd>` to meter Claude Code, SDK clients, etc.",
        )
    if mode == "apps":
        return (
            VERDICT_HEALTHY,
            "--apps mode is healthy. New shells + Spotlight-spawned apps are "
            "metered; system proxy is intentionally unmanaged.",
        )
    if mode == "full":
        return (VERDICT_HEALTHY, "--full mode is healthy.")
    return (VERDICT_HEALTHY, "Install is healthy.")


# --------------------------------------------------------------------------- #
# Public entry points                                                         #
# --------------------------------------------------------------------------- #


def run_doctor(
    *, run_curl: bool = False, console: Console | None = None
) -> DoctorReport:
    """Run the doctor probe set; return a DoctorReport (no rendering)."""
    rows, mode, plat = _build_rows(run_curl=run_curl)
    verdict, msg = _compute_verdict(rows, mode)
    return DoctorReport(
        verdict=verdict,
        summary_message=msg,
        rows=rows,
        mode=mode,
        platform=plat,
        version=__version__,
    )


def render_report(report: DoctorReport, console: Console) -> None:
    """Plain-text render: top-line verdict, table of rows, footer hint."""
    color = {
        VERDICT_HEALTHY: "green",
        VERDICT_INCONSISTENT: "yellow",
        VERDICT_BROKEN: "red",
    }.get(report.verdict, "white")
    console.print(f"[bold {color}]{report.verdict}[/bold {color}] — {report.summary_message}")
    console.print(
        f"[dim]platform={report.platform}  mode={report.mode or 'unknown'}  "
        f"version={report.version}[/dim]"
    )
    table = Table(title="halton-meter doctor", show_header=True, header_style="bold")
    table.add_column("Status", width=8)
    table.add_column("Check")
    table.add_column("Detail")
    table.add_column("Next action")
    for r in report.rows:
        table.add_row(
            _icon_glyph(r.icon),
            r.name,
            r.summary,
            r.next_action or "—",
        )
    console.print(table)
    console.print(
        "\n[dim]Paste this output into a support ticket if you need help.[/dim]"
    )


@click.command(name="doctor")
@click.option(
    "--curl",
    "run_curl",
    is_flag=True,
    default=False,
    help=(
        "Probe https://example.com via the proxy as an end-to-end TLS "
        "smoke test. The probe target is hard-coded to a non-provider "
        "domain."
    ),
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Emit a structured JSON report on stdout instead of a Rich table.",
)
def doctor_cmd(run_curl: bool, as_json: bool) -> None:
    """Diagnose the halton-meter install and surface concrete next-actions."""
    console = Console()
    report = run_doctor(run_curl=run_curl, console=console)
    if as_json:
        click.echo(_json.dumps(report.to_dict(), indent=2))
    else:
        render_report(report, console)
    # Exit code: 0 if HEALTHY, 1 if INCONSISTENT, 2 if BROKEN.
    rc = {VERDICT_HEALTHY: 0, VERDICT_INCONSISTENT: 1, VERDICT_BROKEN: 2}.get(
        report.verdict, 1
    )
    _sys.exit(rc)
