"""
Tests for halton_meter.tagging — resolve_project().

Covers all four resolution paths:
  1. HALTON_PROJECT env var set and non-empty
  2. HALTON_PROJECT env var empty → falls through
  3. .haltonrc in CWD
  4. .haltonrc in a parent directory
  5. No .haltonrc → falls through to workdir basename
  6. psutil lookup failure → graceful fallback

Uses a simple sentinel object as the flow (resolve_project accepts any object;
the psutil path is mocked/bypassed via monkeypatching _get_process_cwd).
"""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest

import halton_meter.tagging as tagging_mod
from halton_meter.tagging import resolve_project


class _FakeFlow:
    """Minimal stand-in for an mitmproxy HTTPFlow."""
    pass


# ---------------------------------------------------------------------------
# Env var
# ---------------------------------------------------------------------------


def test_env_var_wins(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When HALTON_PROJECT is set, it wins regardless of .haltonrc or cwd."""
    monkeypatch.setenv("HALTON_PROJECT", "env-driven-project")
    # Even if there's a .haltonrc in CWD it should not be consulted
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "env-driven-project"


def test_env_var_empty_falls_through(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When HALTON_PROJECT is set but empty, we fall through to .haltonrc."""
    monkeypatch.setenv("HALTON_PROJECT", "")
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "rcfile-project"


def test_env_var_whitespace_only_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Whitespace-only HALTON_PROJECT must be treated as unset."""
    monkeypatch.setenv("HALTON_PROJECT", "   ")
    (tmp_path / ".haltonrc").write_text("project: rcfile-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "rcfile-project"


def test_env_var_unset_falls_through(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """When HALTON_PROJECT is not in the environment, fall through to .haltonrc."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: my-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "my-project"


# ---------------------------------------------------------------------------
# .haltonrc in CWD
# ---------------------------------------------------------------------------


def test_haltonrc_in_cwd(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A .haltonrc in the process's CWD must be found and used."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: invoice-app\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "invoice-app"


def test_haltonrc_strips_whitespace(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Leading/trailing whitespace around the project value is stripped."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project:   my project name   \n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "my project name"


def test_haltonrc_ignores_unrelated_lines(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Non-project lines in .haltonrc must be ignored."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text(
        "# comment\nfoo: bar\nproject: correct-project\nbaz: qux\n"
    )
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(tmp_path)):
        result = resolve_project(_FakeFlow())
    assert result == "correct-project"


# ---------------------------------------------------------------------------
# .haltonrc in a parent directory
# ---------------------------------------------------------------------------


def test_haltonrc_in_parent_dir(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A .haltonrc in a parent directory must be found by the walk."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    # Root RC file
    (tmp_path / ".haltonrc").write_text("project: parent-project\n")
    # CWD is a nested subdirectory
    nested = tmp_path / "src" / "module"
    nested.mkdir(parents=True)
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(nested)):
        result = resolve_project(_FakeFlow())
    assert result == "parent-project"


def test_haltonrc_nearest_wins(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When both CWD and a parent have .haltonrc, the CWD one wins."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    (tmp_path / ".haltonrc").write_text("project: parent-project\n")
    child_dir = tmp_path / "child"
    child_dir.mkdir()
    (child_dir / ".haltonrc").write_text("project: child-project\n")
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(child_dir)):
        result = resolve_project(_FakeFlow())
    assert result == "child-project"


# ---------------------------------------------------------------------------
# No .haltonrc — falls back to workdir basename
# ---------------------------------------------------------------------------


def test_no_haltonrc_falls_to_basename(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """With no .haltonrc, the CWD basename is used as the project name."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)
    project_dir = tmp_path / "my-cool-project"
    project_dir.mkdir()
    with patch.object(tagging_mod, "_get_process_cwd", return_value=str(project_dir)):
        result = resolve_project(_FakeFlow())
    assert result == "my-cool-project"


# ---------------------------------------------------------------------------
# psutil failure — graceful fallback
# ---------------------------------------------------------------------------


def test_psutil_failure_falls_through_gracefully(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """If _get_process_cwd raises, resolve_project must not propagate the error."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    def _raise(*args: object, **kwargs: object) -> str:
        raise RuntimeError("psutil not available")

    with patch.object(tagging_mod, "_get_process_cwd", side_effect=_raise):
        # Must not raise — falls through to "unknown"
        result = resolve_project(_FakeFlow())
    # We don't assert the exact value (it depends on real CWD), just no exception
    assert isinstance(result, str)


def test_get_process_cwd_psutil_exception_returns_cwd(monkeypatch: pytest.MonkeyPatch) -> None:
    """_get_process_cwd must return os.getcwd() when psutil raises."""
    # Patch psutil to raise on import
    with patch.dict("sys.modules", {"psutil": None}):
        cwd = tagging_mod._get_process_cwd(object())
    assert cwd == os.getcwd()


def test_get_process_cwd_non_http_flow_returns_cwd() -> None:
    """_get_process_cwd must return os.getcwd() for non-HTTPFlow objects."""
    # Pass a plain object — should not crash, returns os.getcwd()
    result = tagging_mod._get_process_cwd(object())
    assert result == os.getcwd()


# ---------------------------------------------------------------------------
# read_haltonrc unit tests
# ---------------------------------------------------------------------------


def test_read_haltonrc_returns_none_when_not_found(tmp_path: Path) -> None:
    """_read_haltonrc must return None when no .haltonrc exists in the tree."""
    # Use a tmp subdirectory whose parents definitely don't have a .haltonrc
    subdir = tmp_path / "a" / "b"
    subdir.mkdir(parents=True)
    # No .haltonrc anywhere under tmp_path
    result = tagging_mod._read_haltonrc(str(subdir))
    # We can't guarantee no .haltonrc exists in real parent dirs above tmp_path,
    # so just verify the return type is correct
    assert result is None or isinstance(result, str)


def test_read_haltonrc_empty_project_value_skipped(tmp_path: Path) -> None:
    """A .haltonrc with `project:` but no value must be skipped."""
    (tmp_path / ".haltonrc").write_text("project:\n")
    result = tagging_mod._read_haltonrc(str(tmp_path))
    # Empty value → falls through, so result is None (no parent rc)
    # We just verify it did not return empty string
    assert result != ""


def test_resolve_project_unknown_when_no_info(monkeypatch: pytest.MonkeyPatch) -> None:
    """When no env var, no .haltonrc, and basename is empty, return 'unknown'."""
    monkeypatch.delenv("HALTON_PROJECT", raising=False)

    # Patch _get_process_cwd to return "/" (root — basename is "")
    with patch.object(tagging_mod, "_get_process_cwd", return_value="/"):
        # On macOS/Linux, Path("/").name is "" so basename falls through to "unknown"
        result = resolve_project(_FakeFlow())

    # If there's a .haltonrc at / we'd get that, but in practice there won't be
    # Just verify it returns a non-empty string
    assert isinstance(result, str)
    assert len(result) > 0
