"""Tests for ``halton_meter.init`` (Phase 2B.7).

All OS-level subprocess calls are mocked. No real ``osascript``,
``launchctl``, ``networksetup``, or ``security`` invocations.
"""

from __future__ import annotations

import subprocess
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import init as init_module
from halton_meter import system_proxy
from halton_meter.cli import cli
from halton_meter.setup import SetupResult, StepStatus

# --------------------------------------------------------------------------- #
# Helpers                                                                     #
# --------------------------------------------------------------------------- #


def _all_done_setup_result() -> SetupResult:
    return SetupResult(
        cert_generated=StepStatus("Generate mitmproxy CA cert", True, "ok"),
        cert_trusted=StepStatus("Trust cert in macOS keychain", True, "ok"),
        certifi_patched=StepStatus("Patch certifi bundle", True, "ok"),
    )


def _failed_setup_result() -> SetupResult:
    return SetupResult(
        cert_generated=StepStatus("Generate mitmproxy CA cert", True, "ok"),
        cert_trusted=StepStatus(
            "Trust cert in macOS keychain", False, "sudo failed"
        ),
        certifi_patched=StepStatus("Patch certifi bundle", True, "ok"),
    )


@pytest.fixture(autouse=True)
def _redirect_system_state_path(
    tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Point ``_SYSTEM_STATE_PATH`` at the test's tmp dir so the snapshot
    written from ``_enable_system_proxy_for_init`` (2B.11) never lands in
    the developer's real ``~/.halton-meter/``. Also redirects
    ``INSTALL_MODE_PATH`` (P0-3) for the same reason."""
    from pathlib import Path

    target = Path(str(tmp_path)) / "halton" / "system_state.json"
    monkeypatch.setattr(system_proxy, "_SYSTEM_STATE_PATH", target)
    install_mode_target = Path(str(tmp_path)) / "halton" / "install-mode"
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode_target)


@pytest.fixture(autouse=True)
def _stub_self_test_pass(monkeypatch: pytest.MonkeyPatch) -> None:
    """v0.1.3 P0-6: stub the post-install self-test to ALWAYS pass by
    default. Tests that explicitly exercise self-test failure / rollback
    override this with their own monkeypatch."""
    monkeypatch.setattr(init_module, "_run_self_test", lambda **_kw: [])


@pytest.fixture
def macos(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    # Default: no live daemon, sudo pre-cached.
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)


@pytest.fixture
def patch_setup_all_done(monkeypatch: pytest.MonkeyPatch) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []

    def fake_run_setup(
        *,
        force: bool = False,
        managed: bool = True,
        console: Any = None,
    ) -> SetupResult:
        calls.append({"force": force, "managed": managed})
        return _all_done_setup_result()

    monkeypatch.setattr("halton_meter.setup.run_setup", fake_run_setup)
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)
    return calls


@pytest.fixture
def patch_setup_failed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _failed_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)


@pytest.fixture
def patch_install_ok(monkeypatch: pytest.MonkeyPatch) -> list[int]:
    counter: list[int] = []

    def fake_install() -> int:
        counter.append(1)
        return 0

    monkeypatch.setattr("halton_meter.install.install", fake_install)
    return counter


@pytest.fixture
def patch_install_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("halton_meter.install.install", lambda: 7)


@pytest.fixture
def patch_load_config_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """Stub ``halton_meter.config.load_config`` to return a default
    ``HaltonConfig`` instead of reading ``~/.halton-meter/config.toml``.

    Without this, ``_enable_system_proxy_for_init`` raises
    ``FileNotFoundError`` on any environment that hasn't run ``init``
    yet — the dev box without a config, the GitHub Actions runner with
    a clean ``$HOME``, etc. The stub returns the same defaults the
    real ``load_config`` would synthesise from an empty TOML, so the
    init flow sees ``listen_host=127.0.0.1`` and ``listen_port=8080``
    (the values these tests already implicitly assume via
    ``patch_proxy_already_correct``)."""
    from halton_meter import config as config_module

    monkeypatch.setattr(
        config_module, "load_config", lambda *a, **kw: config_module.HaltonConfig()
    )


@pytest.fixture
def patch_proxy_already_correct(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Any
) -> None:
    """All interfaces already point at us; no admin elevation needed.

    v0.1.5 (2B.16) P1-AUDIT-7 fix: previously this fixture patched
    ``Path.__class__.exists`` to return True for every Path — class-
    level patching leaks across test modules and was the cause of
    flakes in test_doctor / test_lifecycle when runs order put
    test_init before them. Replaced with a real touched file the
    fixture creates in tmp_path, so ``_PROXY_MANAGED_SENTINEL.exists()``
    returns True naturally without modifying ``Path``."""
    from pathlib import Path as _Path

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "8080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    sentinel = _Path(str(tmp_path)) / "halton-meter-test-sentinel"
    sentinel.touch()
    monkeypatch.setattr(system_proxy, "_PROXY_MANAGED_SENTINEL", sentinel)

    # State-toggle subprocess returns 0.
    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")


# --------------------------------------------------------------------------- #
# Scenario 1: macOS happy path — everything already configured                #
# --------------------------------------------------------------------------- #


def test_init_macos_all_done(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_already_correct: None,
    patch_load_config_default: None,
) -> None:
    """All three sub-systems already done → exit 0, no osascript invoked."""
    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    # install.install() was invoked (force-refresh is part of the contract).
    assert patch_install_ok == [1]


# --------------------------------------------------------------------------- #
# Scenario 2: cold start — full sequence wired                                #
# --------------------------------------------------------------------------- #


def test_init_macos_cold_start(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_already_correct: None,
    patch_load_config_default: None,
) -> None:
    """Mock the three steps; assert exit 0 and the three downstream
    callees were each invoked once. --gui mode used because this test
    asserts the proxy enable path is exercised."""
    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert len(patch_setup_all_done) == 1
    assert patch_install_ok == [1]
    # P0-3: --gui mode passes managed=True to run_setup.
    assert patch_setup_all_done[0]["managed"] is True


# --------------------------------------------------------------------------- #
# Scenario 3: setup fails → proxy + install never run                         #
# --------------------------------------------------------------------------- #


def test_init_macos_setup_fails_aborts(
    macos: None,
    patch_setup_failed: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    proxy_called: list[int] = []
    install_called: list[int] = []

    def fake_enable(*_a: Any, **_kw: Any) -> None:
        proxy_called.append(1)

    def fake_install() -> int:
        install_called.append(1)
        return 0

    monkeypatch.setattr(system_proxy, "enable_system_proxy_if_managed", fake_enable)
    monkeypatch.setattr("halton_meter.install.install", fake_install)

    rc = init_module.init(non_interactive=True)
    assert rc != 0
    assert proxy_called == []
    assert install_called == []


# --------------------------------------------------------------------------- #
# Scenario 4: proxy enable raises → install never runs                        #
# --------------------------------------------------------------------------- #


def test_init_macos_proxy_failure_aborts_install(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    install_called: list[int] = []

    def boom(*_a: Any, **_kw: Any) -> None:
        raise RuntimeError("simulated proxy failure")

    monkeypatch.setattr(init_module, "_enable_system_proxy_for_init", boom)

    def fake_install() -> int:
        install_called.append(1)
        return 0

    monkeypatch.setattr("halton_meter.install.install", fake_install)

    # --gui because the test exercises proxy-enable failure path; in
    # env-var-only mode proxy enable is skipped entirely so this test
    # would be vacuous.
    rc = init_module.init(non_interactive=True, gui=True)
    assert rc != 0
    assert install_called == []


# --------------------------------------------------------------------------- #
# Scenario 5: live daemon detected, interactive N → exit 0 with skipped       #
# --------------------------------------------------------------------------- #


def test_init_live_daemon_interactive_decline(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: True)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)

    proxy_called: list[int] = []
    install_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    monkeypatch.setattr(
        "halton_meter.install.install", lambda: install_called.append(1) or 0
    )
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _all_done_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["init"], input="n\n")

    assert result.exit_code == 0
    assert "Skipped supervisor refresh" in result.output or "skipped" in result.output.lower()
    # User declined: setup, proxy, install must not have run.
    assert proxy_called == []
    assert install_called == []


# --------------------------------------------------------------------------- #
# Scenario 6: --non-interactive with running daemon → no prompt, proceeds     #
# --------------------------------------------------------------------------- #


def test_init_live_daemon_non_interactive_proceeds(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: True)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)

    proxy_called: list[int] = []
    install_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    monkeypatch.setattr(
        "halton_meter.install.install", lambda: install_called.append(1) or 0
    )
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _all_done_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert proxy_called == [1]
    assert install_called == [1]


# --------------------------------------------------------------------------- #
# Scenario 7: Linux                                                           #
# --------------------------------------------------------------------------- #


def test_init_linux_skips_proxy_calls_install(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "linux")
    monkeypatch.setattr(init_module.os, "name", "posix")

    install_called: list[int] = []
    proxy_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    monkeypatch.setattr(
        "halton_meter.install.install", lambda: install_called.append(1) or 0
    )

    # On Linux setup.run_setup returns the keychain step as a "not
    # supported" stub (done=False). Cert + certifi succeed.
    def fake_run_setup(**_kw: Any) -> SetupResult:
        return SetupResult(
            cert_generated=StepStatus("Generate mitmproxy CA cert", True, "ok"),
            cert_trusted=StepStatus(
                "Trust cert in macOS keychain", False, "Not yet supported on Linux"
            ),
            certifi_patched=StepStatus("Patch certifi bundle", True, "ok"),
        )

    monkeypatch.setattr("halton_meter.setup.run_setup", fake_run_setup)
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)

    rc = init_module.init(non_interactive=True)
    assert rc == 0
    # macOS-only proxy step must be skipped on Linux.
    assert proxy_called == []
    # install.install() called for the systemd unit.
    assert install_called == [1]


# --------------------------------------------------------------------------- #
# Scenario 8: Windows                                                         #
# --------------------------------------------------------------------------- #


def test_init_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "win32")
    monkeypatch.setattr(init_module.os, "name", "nt")

    proxy_called: list[int] = []
    install_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    monkeypatch.setattr(
        "halton_meter.install.install", lambda: install_called.append(1) or 0
    )

    rc = init_module.init(non_interactive=True)
    assert rc == 0
    assert proxy_called == []
    assert install_called == []


# --------------------------------------------------------------------------- #
# Scenario 9: --non-interactive with sudo not pre-cached                      #
# --------------------------------------------------------------------------- #


def test_init_non_interactive_without_sudo_or_osascript_exits_2(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.4 (2B.15) P0-2: only bail with exit 2 when BOTH osascript is
    unavailable AND sudo is not pre-cached. Witnessed regression: the
    v0.1.3 form bailed on ``not _sudo_pre_cached()`` alone, even though
    the cert-trust step now prefers the osascript GUI admin dialog
    which works without pre-cached sudo."""
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: False)
    # Pretend osascript is also unavailable (e.g. broken macOS install).
    monkeypatch.setattr(
        init_module, "_osascript_available_for_init", lambda: False
    )

    setup_called: list[int] = []
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: setup_called.append(1) or _all_done_setup_result(),
    )

    rc = init_module.init(non_interactive=True)
    # Specific exit code per the brief.
    assert rc == 2
    # Setup must NOT have run — we abort before touching anything.
    assert setup_called == []


def test_init_non_interactive_without_sudo_but_with_osascript_proceeds(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.4 P0-2: if osascript is available, the init preflight no
    longer bails on ``not _sudo_pre_cached()``. The cert-trust step
    will use the GUI admin dialog instead of terminal sudo.

    This is the new-user-on-clean-Mac happy path: ``pipx install`` then
    ``halton-meter init`` succeeds without the user knowing what
    ``sudo -v`` is.
    """
    # Sudo is NOT pre-cached but osascript IS available.
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: False)
    monkeypatch.setattr(
        init_module, "_osascript_available_for_init", lambda: True
    )
    # Stub the env-only reconciliation so we focus on the preflight contract.
    monkeypatch.setattr(init_module, "_reconcile_env_only_mode", lambda _c: None)

    rc = init_module.init(non_interactive=True)
    # Init proceeds normally; cert-trust step (mocked via patch_setup_all_done)
    # is allowed to run and elevate via osascript when needed.
    assert rc == 0
    assert patch_setup_all_done, "run_setup must have run after preflight passed"


# --------------------------------------------------------------------------- #
# Bonus: integration via CliRunner (real Click command, mocked OS)            #
# --------------------------------------------------------------------------- #


def test_init_cli_runner_non_interactive_macos(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init", lambda **_kw: None
    )
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _all_done_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)
    monkeypatch.setattr("halton_meter.install.install", lambda: 0)

    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--non-interactive"])
    assert result.exit_code == 0


def test_init_cli_runner_install_failure_propagates(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init", lambda **_kw: None
    )
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _all_done_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)
    monkeypatch.setattr("halton_meter.install.install", lambda: 9)

    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--non-interactive"])
    assert result.exit_code != 0


# --------------------------------------------------------------------------- #
# Direct-first networksetup path (Sonoma+/Tahoe) — admin only on permission   #
# --------------------------------------------------------------------------- #


@pytest.fixture
def patch_proxy_address_differs(monkeypatch: pytest.MonkeyPatch) -> None:
    """Address differs from daemon target so the new direct/admin code path runs."""

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        # Returns a different address — _proxy_targets_us will be False.
        return (False, "10.0.0.1", "1234")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    # Stub the eager state-toggle pass — it doesn't matter for these tests.
    monkeypatch.setattr(
        system_proxy, "enable_system_proxy_if_managed",
        lambda *_a, **_kw: None,
    )


def _make_completed_proc(rc: int, stderr: str = "") -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(
        args=["networksetup"], returncode=rc, stdout="", stderr=stderr
    )


def test_init_proxy_set_succeeds_without_admin_on_modern_macos(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Direct networksetup rc=0 → run_with_admin NOT called, no admin prompt printed."""
    direct_calls: list[list[str]] = []

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        direct_calls.append(argv)
        return _make_completed_proc(0)

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    admin_calls: list[Any] = []
    monkeypatch.setattr(
        system_proxy, "run_with_admin",
        lambda *a, **kw: admin_calls.append((a, kw)),
    )

    from rich.console import Console
    captured = Console(record=True, width=120)
    rc = init_module.init(non_interactive=True, gui=True, console=captured)

    assert rc == 0
    # Direct call(s) made for at least one networksetup variant.
    assert any(c and c[0] == "networksetup" for c in direct_calls)
    # run_with_admin must NOT have been called.
    assert admin_calls == []
    # No admin password-dialog warning.
    output = captured.export_text()
    assert "password dialog" not in output.lower()
    # init proceeded to install.install().
    assert patch_install_ok == [1]


def test_init_proxy_set_falls_back_to_admin_on_permission_error(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Direct rc=1 with permission stderr → admin escalation + admin-dialog notice."""

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return _make_completed_proc(
            1, stderr="Permission denied: requires administrator rights."
        )

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    admin_calls: list[Any] = []
    monkeypatch.setattr(
        system_proxy, "run_with_admin",
        lambda *a, **kw: admin_calls.append((a, kw)),
    )

    from rich.console import Console
    captured = Console(record=True, width=120)
    rc = init_module.init(non_interactive=True, gui=True, console=captured)

    assert rc == 0
    assert len(admin_calls) >= 1
    output = captured.export_text()
    assert "password dialog" in output.lower()
    assert patch_install_ok == [1]


def test_init_proxy_set_escalates_on_unrelated_stderr(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.7.1: any non-zero rc escalates, even when stderr is unrelated.

    Replaces the narrow-heuristic regression test from 2B.7. The
    contract was deliberately widened on 2026-04-30 — see
    decisions.md.
    """

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return _make_completed_proc(1, stderr="unrecognized network service")

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    admin_calls: list[Any] = []
    monkeypatch.setattr(
        system_proxy, "run_with_admin",
        lambda *a, **kw: admin_calls.append((a, kw)),
    )

    rc = init_module.init(non_interactive=True, gui=True)
    # Widened contract: rc=1 + arbitrary stderr now escalates and proceeds.
    assert rc == 0
    assert len(admin_calls) >= 1
    assert patch_install_ok == [1]


def test_init_proxy_set_escalates_on_empty_stderr_rc4(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
    capfd: pytest.CaptureFixture[str],
) -> None:
    """2B.7.1 regression: rc=4 with empty stderr (modern macOS Ethernet)
    must escalate via run_with_admin and emit elevation_retry_widened.

    This is the exact failure observed on Vikrant's machine on
    2026-04-30 — the old heuristic missed it because it required a
    permission-flavoured substring in stderr.
    """

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return _make_completed_proc(4, stderr="")

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    admin_calls: list[Any] = []
    monkeypatch.setattr(
        system_proxy, "run_with_admin",
        lambda *a, **kw: admin_calls.append((a, kw)),
    )

    rc = init_module.init(non_interactive=True, gui=True)

    assert rc == 0
    assert len(admin_calls) >= 1
    assert patch_install_ok == [1]
    # The new structured event fires with stderr_was_empty=True and
    # rc=4. structlog's default renderer writes to stderr.
    out, err = capfd.readouterr()
    combined = out + err
    assert "init.proxy.elevation_retry_widened" in combined
    assert "stderr_was_empty=True" in combined
    assert "rc=4" in combined


def test_init_proxy_set_user_cancel_at_admin_dialog_raises(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Direct fails, user cancels the osascript admin dialog → init aborts.

    The widened contract relies on run_with_admin surfacing a
    meaningful error when elevation itself fails. Verify init turns
    that into a non-zero exit and skips install.
    """

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return _make_completed_proc(1, stderr="")

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    def fake_admin(*_a: Any, **_kw: Any) -> None:
        raise RuntimeError("user cancelled the admin password dialog")

    monkeypatch.setattr(system_proxy, "run_with_admin", fake_admin)

    install_called: list[int] = []
    monkeypatch.setattr(
        "halton_meter.install.install",
        lambda: install_called.append(1) or 0,
    )

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc != 0
    assert install_called == []


@pytest.mark.parametrize(
    "stderr_phrase",
    [
        "Permission denied for this operation.",
        "You must be root to do this.",
        "Operation not permitted",
        "This action requires administrator rights.",
        "Caller is not authorized to make this call.",
    ],
)
def test_init_proxy_set_recognises_multiple_permission_phrasings(
    stderr_phrase: str,
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """All five stderr trigger strings route to admin fallback."""

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return _make_completed_proc(1, stderr=stderr_phrase)

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    admin_calls: list[Any] = []
    monkeypatch.setattr(
        system_proxy, "run_with_admin",
        lambda *a, **kw: admin_calls.append((a, kw)),
    )

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert len(admin_calls) >= 1


def test_init_snapshot_called_before_first_networksetup_mutation(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_address_differs: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.11.1 regression: ``snapshot_system_proxy`` MUST run before the
    first ``networksetup -setsecurewebproxy`` / ``-setwebproxy`` mutation
    in ``_enable_system_proxy_for_init``. Otherwise the snapshot would
    capture our own daemon's listener instead of the user's pre-existing
    proxy config and lose it on uninstall.
    """
    call_order: list[str] = []

    def fake_snapshot() -> None:
        call_order.append("snapshot")

    monkeypatch.setattr(system_proxy, "snapshot_system_proxy", fake_snapshot)

    def fake_subprocess_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        # Only record networksetup MUTATION calls (set*), not reads.
        if (
            len(argv) >= 2
            and argv[0] == "networksetup"
            and argv[1] in ("-setsecurewebproxy", "-setwebproxy")
        ):
            call_order.append(f"mutation:{argv[1]}")
        return _make_completed_proc(0)

    monkeypatch.setattr(init_module.subprocess, "run", fake_subprocess_run)

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert call_order, "neither snapshot nor mutation ran — fixture broken"
    # Snapshot must be first; at least one mutation must follow.
    assert call_order[0] == "snapshot", (
        f"snapshot must run before any networksetup mutation; got {call_order}"
    )
    assert any(c.startswith("mutation:") for c in call_order[1:]), (
        f"expected at least one networksetup mutation after snapshot; got {call_order}"
    )


def test_init_live_daemon_interactive_accept(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """y at the prompt → proceeds through all steps."""
    monkeypatch.setattr(init_module.sys, "platform", "darwin")
    monkeypatch.setattr(init_module, "_detect_live_daemon", lambda: True)
    monkeypatch.setattr(init_module, "_sudo_pre_cached", lambda: True)

    proxy_called: list[int] = []
    install_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    monkeypatch.setattr(
        "halton_meter.install.install", lambda: install_called.append(1) or 0
    )
    monkeypatch.setattr(
        "halton_meter.setup.run_setup",
        lambda **_kw: _all_done_setup_result(),
    )
    monkeypatch.setattr("halton_meter.setup.render_result", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--gui"], input="y\n")
    assert result.exit_code == 0
    assert proxy_called == [1]
    assert install_called == [1]


# --------------------------------------------------------------------------- #
# v0.1.3 P0-3 — env-var-only default mode + --gui opt-in                       #
# --------------------------------------------------------------------------- #


def test_init_default_mode_is_env_var_only(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default invocation (no --gui) skips system-proxy enable, skips
    launchctl setenv, and writes install-mode=env-only."""
    proxy_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    setenv_calls: list[dict[str, str]] = []
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: setenv_calls.append(env_vars) or {k: 0 for k in env_vars},
    )
    # Stub the reconciliation helper so this test stays focused on the
    # core flow (it covers the steady-state default path; the
    # mode-reconciliation path has its own dedicated tests below).
    monkeypatch.setattr(init_module, "_reconcile_env_only_mode", lambda _c: None)

    rc = init_module.init(non_interactive=True)
    assert rc == 0
    # System-proxy enable did not run.
    assert proxy_called == []
    # launchctl setenv did not run.
    assert setenv_calls == []
    # run_setup was called with managed=False.
    assert patch_setup_all_done[0]["managed"] is False
    # install-mode sentinel says env-only.
    assert init_module.read_install_mode() == init_module.MODE_ENV_ONLY


# --------------------------------------------------------------------------- #
# v0.1.4 (2B.15) P0-1 — mode-reconciliation invariant                          #
# --------------------------------------------------------------------------- #


def test_init_default_mode_reconciles_after_prior_gui_install(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    """v0.1.4 P0-1 regression: ``init`` (default mode) must revert every
    --gui-mode side effect even when the install steps short-circuit
    on idempotency.

    Witnessed: user ran ``init --gui`` then later ``init`` (default).
    Install-mode sentinel still said "gui", system proxy was still
    enabled, shell-rc block was still in ~/.zshrc, status said "--gui
    mode is healthy". Default-mode init should reconcile all four:
        1. launchctl env vars unset
        2. proxy-managed sentinel removed
        3. system proxy disabled / restored
        4. shell-rc block removed

    The install-mode sentinel itself is overwritten unconditionally to
    "env-only" (already covered by other tests).
    """
    # --- Set up a "post --gui" state on disk ----------------------------------
    # 1. launchctl env vars: capture every unsetenv key.
    unsetenv_calls: list[tuple[str, ...]] = []
    monkeypatch.setattr(
        system_proxy, "unsetenv_user_domain",
        lambda keys: unsetenv_calls.append(tuple(keys)) or {k: 0 for k in keys},
    )
    # 2. proxy-managed sentinel: write one to a tmp dir.
    sentinel_dir = tmp_path / "halton-meter"
    sentinel_dir.mkdir(parents=True, exist_ok=True)
    sentinel_path = sentinel_dir / "proxy-managed"
    sentinel_path.touch()
    monkeypatch.setattr(
        "halton_meter.install._proxy_managed_sentinel_path",
        lambda: sentinel_path,
    )
    # 3. system proxy: pretend a snapshot exists and restore_system_proxy
    # returns True (the happy path).
    restore_calls: list[tuple[str, int]] = []
    monkeypatch.setattr(
        system_proxy, "restore_system_proxy",
        lambda host, port: restore_calls.append((host, port)) or True,
    )
    # 4. shell-rc block: prep a fake .zshrc with two stale halton-meter
    # marker blocks (multi-block coverage from the same v0.1.4 commit).
    fake_rc = tmp_path / ".zshrc"
    block_a = (
        f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
        "export HTTPS_PROXY=http://127.0.0.1:8080\n"
        f"{init_module.SHELL_RC_BLOCK_END}\n"
    )
    block_b = (
        f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
        "export HTTPS_PROXY=http://127.0.0.1:8081\n"
        f"{init_module.SHELL_RC_BLOCK_END}\n"
    )
    fake_rc.write_text(
        "# user line\n" + block_a + "alias x=y\n" + block_b + "# end\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(init_module, "detect_shell_rc", lambda: fake_rc)
    # 5. install-mode sentinel: pretend the prior state was "gui".
    sentinel_install_mode = tmp_path / "install-mode"
    sentinel_install_mode.write_text("gui\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", sentinel_install_mode)

    # --- Run init in env-only mode -------------------------------------------
    rc = init_module.init(non_interactive=True)
    assert rc == 0

    # --- Assert all four mode-specific surfaces reconciled --------------------
    # 1. launchctl unsetenv called with the full GUI key list.
    assert unsetenv_calls, "unsetenv_user_domain must be called in env-only reconcile"
    flat_keys = tuple(k for batch in unsetenv_calls for k in batch)
    for expected_key in system_proxy.GUI_LAUNCHCTL_ENV_KEYS:
        assert expected_key in flat_keys, (
            f"expected {expected_key} to be unsetenv'd; got {flat_keys}"
        )
    # 2. proxy-managed sentinel removed.
    assert not sentinel_path.exists(), (
        "proxy-managed sentinel must be removed in env-only reconcile"
    )
    # 3. restore_system_proxy was called (happy path).
    assert restore_calls, "restore_system_proxy must be invoked"
    # 4. shell-rc block removed entirely (no markers remain).
    body = fake_rc.read_text(encoding="utf-8")
    assert init_module.SHELL_RC_BLOCK_BEGIN not in body, (
        f"all marker blocks must be stripped; got:\n{body}"
    )
    assert init_module.SHELL_RC_BLOCK_END not in body
    # No leftover halton-meter exports.
    assert "127.0.0.1:8080" not in body
    assert "127.0.0.1:8081" not in body
    # User content preserved.
    assert "# user line" in body
    assert "alias x=y" in body
    assert "# end" in body
    # 5. install-mode sentinel was overwritten to env-only.
    assert sentinel_install_mode.read_text(encoding="utf-8").strip() == "env-only"


def test_init_default_mode_reconcile_no_snapshot_falls_back_to_disable(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.4 P0-1: when no system_state.json snapshot exists,
    reconcile falls back to disabling the system proxy on every
    interface that currently points at us — never leaves the user
    routed through a managed-but-disowned proxy."""
    monkeypatch.setattr(
        system_proxy, "unsetenv_user_domain",
        lambda keys: {k: 0 for k in keys},
    )
    # No snapshot (restore returns False).
    monkeypatch.setattr(
        system_proxy, "restore_system_proxy", lambda host, port: False,
    )
    # Pretend two interfaces both point at us; one doesn't.
    monkeypatch.setattr(
        system_proxy, "_macos_interfaces",
        lambda: ("Wi-Fi", "Ethernet", "USB Ethernet"),
    )

    def fake_read(iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        if iface == "Wi-Fi":
            return (True, "127.0.0.1", "8080")  # Points at us
        if iface == "Ethernet":
            return (False, None, None)
        if iface == "USB Ethernet":
            return (True, "10.0.0.1", "3128")  # Points elsewhere
        return (False, None, None)

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    disable_calls: list[str] = []
    monkeypatch.setattr(
        system_proxy, "_disable_macos_proxy",
        lambda iface: disable_calls.append(iface),
    )
    # detect_shell_rc → None so no rc edits.
    monkeypatch.setattr(init_module, "detect_shell_rc", lambda: None)

    rc = init_module.init(non_interactive=True)
    assert rc == 0
    # Only Wi-Fi (which points at us) was disabled. The other two are left alone.
    assert disable_calls == ["Wi-Fi"], (
        f"expected only Wi-Fi disabled; got {disable_calls}"
    )


def test_init_full_mode_reconciles_to_full(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16) P0-1: --full mode calls _reconcile_to_mode with
    MODE_FULL (the unified reconciler replaced the env-only-only helper).
    The reconciler is a no-op for surfaces the desired mode wants
    present; it only sweeps what's stale."""
    reconcile_calls: list[str] = []
    monkeypatch.setattr(
        init_module, "_reconcile_to_mode",
        lambda mode, _console: reconcile_calls.append(mode),
    )
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: {k: 0 for k in env_vars},
    )

    rc = init_module.init(non_interactive=True, full=True, no_shell_rc=True)
    assert rc == 0
    assert reconcile_calls == [init_module.MODE_FULL], (
        "_reconcile_to_mode must run with MODE_FULL in --full mode"
    )


def test_init_full_mode_runs_setenv_and_writes_full_sentinel(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """--full (with --no-shell-rc to avoid the prompt) runs proxy enable,
    runs launchctl setenv, writes install-mode=full."""
    setenv_calls: list[dict[str, str]] = []
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: setenv_calls.append(dict(env_vars)) or {k: 0 for k in env_vars},
    )

    rc = init_module.init(non_interactive=True, full=True, no_shell_rc=True)
    assert rc == 0
    # run_setup got managed=True.
    assert patch_setup_all_done[0]["managed"] is True
    # setenv ran with the expected keys.
    assert setenv_calls, "setenv_user_domain must run in --full mode"
    keys = set(setenv_calls[0].keys())
    assert {
        "HTTPS_PROXY",
        "HTTP_PROXY",
        "NO_PROXY",
        "NODE_EXTRA_CA_CERTS",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
    } <= keys
    # NO_PROXY contains localhost,127.0.0.1 (critical to avoid /health
    # tarpit through the proxy).
    assert setenv_calls[0]["NO_PROXY"] == "localhost,127.0.0.1"
    assert init_module.read_install_mode() == init_module.MODE_FULL


def test_init_gui_flag_is_deprecated_alias_for_full(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.5 (2B.16): passing --gui (legacy) writes the canonical
    install-mode=full sentinel and surfaces a deprecation notice."""
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: {k: 0 for k in env_vars},
    )
    rc = init_module.init(non_interactive=True, gui=True, no_shell_rc=True)
    assert rc == 0
    assert init_module.read_install_mode() == init_module.MODE_FULL
    out = capsys.readouterr().out
    assert "deprecated" in out.lower(), out


def test_init_no_shell_rc_flag_skips_rc_in_gui_mode(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    """--gui --no-shell-rc must not touch the shell rc even if one exists."""
    fake_rc = tmp_path / ".zshrc"
    fake_rc.write_text("# pristine\n", encoding="utf-8")
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr(
        init_module, "detect_shell_rc", lambda: fake_rc
    )
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: {k: 0 for k in env_vars},
    )

    rc = init_module.init(non_interactive=True, gui=True, no_shell_rc=True)
    assert rc == 0
    # rc file is byte-identical (no marker block).
    assert fake_rc.read_text(encoding="utf-8") == "# pristine\n"


def test_init_gui_non_interactive_skips_shell_rc_silently(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    """Non-interactive run must NEVER edit shell rc (silent edits forbidden)."""
    fake_rc = tmp_path / ".zshrc"
    fake_rc.write_text("# pristine\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "detect_shell_rc", lambda: fake_rc)
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: {k: 0 for k in env_vars},
    )

    rc = init_module.init(non_interactive=True, gui=True, no_shell_rc=False)
    assert rc == 0
    # Even though no_shell_rc=False, non_interactive=True suppresses the prompt.
    assert fake_rc.read_text(encoding="utf-8") == "# pristine\n"


# --------------------------------------------------------------------------- #
# Install-mode sentinel                                                       #
# --------------------------------------------------------------------------- #


class TestInstallModeSentinel:
    def test_write_read_round_trip_env_only(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        init_module.write_install_mode(init_module.MODE_ENV_ONLY)
        assert init_module.read_install_mode() == init_module.MODE_ENV_ONLY

    def test_write_read_round_trip_full(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        init_module.write_install_mode(init_module.MODE_FULL)
        assert init_module.read_install_mode() == init_module.MODE_FULL

    def test_write_read_round_trip_apps(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """v0.1.5 (2B.16): apps mode is the new third canonical mode."""
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        init_module.write_install_mode(init_module.MODE_APPS)
        assert init_module.read_install_mode() == init_module.MODE_APPS

    def test_legacy_gui_sentinel_reads_as_full(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """v0.1.5 (2B.16): a legacy ``gui`` sentinel value is read as the
        canonical ``full`` without rewriting the file. The migration helper
        is what rewrites — read alone is non-destructive."""
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("gui\n", encoding="utf-8")
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        assert init_module.read_install_mode() == init_module.MODE_FULL
        # File contents not touched by read.
        assert path.read_text(encoding="utf-8").strip() == "gui"

    def test_write_install_mode_rejects_legacy_gui(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """v0.1.5 (2B.16): write rejects ``gui`` — only canonical modes
        may be written. Legacy ``gui`` is read-tolerated only."""
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        with pytest.raises(ValueError):
            init_module.write_install_mode(init_module.MODE_GUI)

    def test_migrate_rewrites_legacy_gui_to_full(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """v0.1.5 (2B.16): the migration helper rewrites a stored ``gui``
        sentinel value to ``full`` and returns the legacy value found."""
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("gui\n", encoding="utf-8")
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        legacy = init_module.migrate_legacy_mode_sentinel()
        assert legacy == "gui"
        assert path.read_text(encoding="utf-8").strip() == "full"
        # Idempotent: second call is a no-op (None).
        assert init_module.migrate_legacy_mode_sentinel() is None

    def test_migrate_noop_when_already_canonical(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("env-only\n", encoding="utf-8")
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        assert init_module.migrate_legacy_mode_sentinel() is None
        assert path.read_text(encoding="utf-8").strip() == "env-only"

    def test_migrate_noop_when_absent(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        assert init_module.migrate_legacy_mode_sentinel() is None
        assert not path.exists()

    def test_invalid_mode_raises(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        with pytest.raises(ValueError):
            init_module.write_install_mode("not-a-valid-mode")

    def test_read_returns_none_when_absent(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        assert init_module.read_install_mode() is None

    def test_read_returns_none_for_garbage_content(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("bogus-mode\n", encoding="utf-8")
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        assert init_module.read_install_mode() is None

    def test_remove_idempotent(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        from pathlib import Path

        path = Path(str(tmp_path)) / "install-mode"
        monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", path)
        # Calling on missing file is fine.
        init_module.remove_install_mode()
        # After write + remove, gone.
        init_module.write_install_mode(init_module.MODE_FULL)
        assert path.exists()
        init_module.remove_install_mode()
        assert not path.exists()


# --------------------------------------------------------------------------- #
# Shell-rc append/remove                                                      #
# --------------------------------------------------------------------------- #


class TestShellRcAppend:
    def _vars(self) -> dict[str, str]:
        return {
            "HTTPS_PROXY": "http://127.0.0.1:8080",
            "HTTP_PROXY": "http://127.0.0.1:8080",
            "NO_PROXY": "localhost,127.0.0.1",
            "NODE_EXTRA_CA_CERTS": "/path/to/cabundle.pem",
            "SSL_CERT_FILE": "/path/to/cabundle.pem",
            "REQUESTS_CA_BUNDLE": "/path/to/cabundle.pem",
        }

    def test_append_to_clean_rc(self, tmp_path: Any) -> None:
        rc = tmp_path / ".zshrc"
        rc.write_text("# my zshrc\nalias ls='ls -la'\n", encoding="utf-8")
        result = init_module.append_coverage_block_to_rc(rc, self._vars())
        assert result == "appended"
        body = rc.read_text(encoding="utf-8")
        assert init_module.SHELL_RC_BLOCK_BEGIN in body
        assert init_module.SHELL_RC_BLOCK_END in body
        assert "export HTTPS_PROXY=" in body
        # Original content preserved.
        assert "alias ls='ls -la'" in body

    def test_append_idempotent_on_unchanged_block(self, tmp_path: Any) -> None:
        rc = tmp_path / ".zshrc"
        rc.write_text("# my zshrc\n", encoding="utf-8")
        env = self._vars()
        first = init_module.append_coverage_block_to_rc(rc, env)
        assert first == "appended"
        mtime_after_append = rc.stat().st_mtime_ns
        # Re-run with identical env -> "unchanged" (no rewrite).
        second = init_module.append_coverage_block_to_rc(rc, env)
        assert second == "unchanged"
        assert rc.stat().st_mtime_ns == mtime_after_append

    def test_append_replaces_drifted_block(self, tmp_path: Any) -> None:
        rc = tmp_path / ".zshrc"
        rc.write_text("# my zshrc\n", encoding="utf-8")
        env_v1 = self._vars()
        init_module.append_coverage_block_to_rc(rc, env_v1)
        # Port changed (P0-5 auto-fallback could change this).
        env_v2 = dict(env_v1)
        env_v2["HTTPS_PROXY"] = "http://127.0.0.1:8081"
        env_v2["HTTP_PROXY"] = "http://127.0.0.1:8081"
        result = init_module.append_coverage_block_to_rc(rc, env_v2)
        assert result == "replaced"
        body = rc.read_text(encoding="utf-8")
        assert "8081" in body
        # Old port should NOT linger inside the block.
        block_start = body.find(init_module.SHELL_RC_BLOCK_BEGIN)
        block_end = body.find(init_module.SHELL_RC_BLOCK_END)
        block_content = body[block_start:block_end]
        assert "8080" not in block_content

    def test_append_returns_missing_rc_when_file_does_not_exist(
        self, tmp_path: Any
    ) -> None:
        rc = tmp_path / ".doesnotexist"
        result = init_module.append_coverage_block_to_rc(rc, self._vars())
        assert result == "missing-rc"

    def test_remove_block(self, tmp_path: Any) -> None:
        rc = tmp_path / ".zshrc"
        rc.write_text("# pre\n", encoding="utf-8")
        init_module.append_coverage_block_to_rc(rc, self._vars())
        assert init_module.SHELL_RC_BLOCK_BEGIN in rc.read_text(encoding="utf-8")
        removed = init_module.remove_coverage_block_from_rc(rc)
        assert removed is True
        body = rc.read_text(encoding="utf-8")
        assert init_module.SHELL_RC_BLOCK_BEGIN not in body
        assert init_module.SHELL_RC_BLOCK_END not in body
        # Surrounding content survives.
        assert "# pre" in body

    def test_remove_block_idempotent(self, tmp_path: Any) -> None:
        rc = tmp_path / ".zshrc"
        rc.write_text("# pre\n", encoding="utf-8")
        # No block present.
        assert init_module.remove_coverage_block_from_rc(rc) is False
        # Missing file.
        rc.unlink()
        assert init_module.remove_coverage_block_from_rc(rc) is False

    def test_remove_block_strips_multiple_stale_blocks(self, tmp_path: Any) -> None:
        """v0.1.4 (2B.15) regression: pre-v0.1.3 installs could append
        the marker block multiple times (one per ``init --gui`` re-run,
        before the marker-replace logic landed). ``remove_coverage_block_from_rc``
        must loop until every block is gone — leaving any of them
        behind would continue to set HTTPS_PROXY on every new shell
        after uninstall.

        Witnessed on Vikrant's MacBook 2026-04-30: 6 ``halton-meter``
        mentions across multiple bracketed blocks in ``~/.zshrc``."""
        rc = tmp_path / ".zshrc"
        # Construct a rc file with three pre-existing marker blocks
        # interspersed with user content.
        block_a = (
            f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
            "export HTTPS_PROXY=http://127.0.0.1:8080\n"
            f"{init_module.SHELL_RC_BLOCK_END}\n"
        )
        block_b = (
            f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
            "export HTTPS_PROXY=http://127.0.0.1:8081\n"
            f"{init_module.SHELL_RC_BLOCK_END}\n"
        )
        block_c = (
            f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
            "export HTTPS_PROXY=http://127.0.0.1:8082\n"
            f"{init_module.SHELL_RC_BLOCK_END}\n"
        )
        rc.write_text(
            "# user line 1\n"
            f"{block_a}\n"
            "alias ls='ls -la'\n"
            f"{block_b}\n"
            "# user line 2\n"
            f"{block_c}\n"
            "# user line 3\n",
            encoding="utf-8",
        )
        # Sanity: pre-condition has three blocks.
        body = rc.read_text(encoding="utf-8")
        assert body.count(init_module.SHELL_RC_BLOCK_BEGIN) == 3
        assert body.count(init_module.SHELL_RC_BLOCK_END) == 3

        removed = init_module.remove_coverage_block_from_rc(rc)
        assert removed is True
        body = rc.read_text(encoding="utf-8")
        # All three blocks gone.
        assert init_module.SHELL_RC_BLOCK_BEGIN not in body
        assert init_module.SHELL_RC_BLOCK_END not in body
        # No leftover halton-meter exports.
        assert "127.0.0.1:8080" not in body
        assert "127.0.0.1:8081" not in body
        assert "127.0.0.1:8082" not in body
        # User content preserved (order + presence).
        assert "# user line 1" in body
        assert "alias ls='ls -la'" in body
        assert "# user line 2" in body
        assert "# user line 3" in body


def test_detect_shell_rc_zsh(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SHELL", "/bin/zsh")
    rc = init_module.detect_shell_rc()
    assert rc is not None
    assert rc.name == ".zshrc"


def test_detect_shell_rc_bash(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SHELL", "/usr/local/bin/bash")
    rc = init_module.detect_shell_rc()
    assert rc is not None
    assert rc.name == ".bashrc"


def test_detect_shell_rc_unknown(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SHELL", "/usr/bin/fish")
    assert init_module.detect_shell_rc() is None


# --------------------------------------------------------------------------- #
# v0.1.3 P0-6 — init self-test with rollback                                  #
# --------------------------------------------------------------------------- #


def test_init_self_test_failure_triggers_rollback(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_already_correct: None,
    patch_load_config_default: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the self-test reports a fatal failure, init must call
    install_module.uninstall() and exit non-zero. (Overrides the
    autouse stub.)"""
    from halton_meter.health import HealthCheck

    # Force the self-test to surface a single fatal failure.
    monkeypatch.setattr(
        init_module, "_run_self_test",
        lambda **_kw: [
            HealthCheck("Daemon /health", False, "no response", "fatal")
        ],
    )

    rollback_called: list[int] = []

    def fake_uninstall(*_a: Any, **_kw: Any) -> int:
        rollback_called.append(1)
        return 0

    monkeypatch.setattr("halton_meter.install.uninstall", fake_uninstall)

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc != 0
    assert rollback_called == [1]


def test_init_self_test_pass_does_not_roll_back(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_already_correct: None,
    patch_load_config_default: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the self-test passes (returns []), init must NOT call
    uninstall. (The autouse stub already returns [].)"""
    rollback_called: list[int] = []

    monkeypatch.setattr(
        "halton_meter.install.uninstall",
        lambda *a, **kw: rollback_called.append(1) or 0,
    )

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert rollback_called == []


def test_init_self_test_warn_does_not_trigger_rollback(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_proxy_already_correct: None,
    patch_load_config_default: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``severity=warn`` checks must NOT trigger rollback even if they
    fail. (``_run_self_test`` filters by severity=fatal.)"""
    from halton_meter.health import HealthCheck

    # Construct an init that calls the REAL _run_self_test but with all
    # underlying checks mocked to return warn-only failures.
    monkeypatch.setattr(
        "halton_meter.health.check_daemon_health",
        lambda *a, **kw: HealthCheck("Daemon /health", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_cert_trusted_macos",
        lambda: HealthCheck("Cert trust", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_plists_loaded_macos",
        lambda **kw: HealthCheck("plist", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_install_mode_sentinel",
        lambda **kw: HealthCheck("sentinel", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_port_persisted",
        lambda **kw: HealthCheck("ports", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_system_proxy_points_at_us",
        lambda **kw: HealthCheck("proxy", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_launchctl_env_var",
        lambda **kw: HealthCheck("launchctl", True, "ok"),
    )

    # Restore the real self-test (override the autouse stub).
    real_run_self_test = init_module._run_self_test
    monkeypatch.setattr(init_module, "_run_self_test", real_run_self_test)

    rollback_called: list[int] = []
    monkeypatch.setattr(
        "halton_meter.install.uninstall",
        lambda *a, **kw: rollback_called.append(1) or 0,
    )

    rc = init_module.init(non_interactive=True, gui=True)
    assert rc == 0
    assert rollback_called == []


# --------------------------------------------------------------------------- #
# v0.1.4 (2B.15) P0-5 + P0-6 — fallback messaging + try-it-now hint            #
# --------------------------------------------------------------------------- #


def test_render_panel_marks_fallback_when_listen_port_differs(tmp_path: Any) -> None:
    """v0.1.4 P0-5: when the resolved listen_port differs from the
    marketed default 8080, the success panel includes an explicit
    "(fallback from busy default :8080/:8765)" note so the user knows
    their tools must target the actual port."""
    from rich.console import Console

    captured = Console(record=True, width=120)
    init_module._render_panel_success(
        captured,
        setup_done=True,
        install_done=True,
        mode=init_module.MODE_ENV_ONLY,
        listen_port=8081,
        api_port=8765,
    )
    out = captured.export_text()
    assert "8081" in out
    assert "fallback" in out.lower()
    assert "8080" in out  # the marketed default it fell back from


def test_render_panel_marks_fallback_when_api_port_differs(tmp_path: Any) -> None:
    """v0.1.4 P0-5: same for api_port (8765 default)."""
    from rich.console import Console

    captured = Console(record=True, width=120)
    init_module._render_panel_success(
        captured,
        setup_done=True,
        install_done=True,
        mode=init_module.MODE_ENV_ONLY,
        listen_port=8080,
        api_port=8766,
    )
    out = captured.export_text()
    assert "8766" in out
    assert "fallback" in out.lower()
    assert "8765" in out  # the marketed default it fell back from


def test_render_panel_no_fallback_marker_when_ports_at_default() -> None:
    """v0.1.4 P0-5: when both ports are at the marketed defaults, the
    panel does NOT mention "fallback" (no false alarm)."""
    from rich.console import Console

    captured = Console(record=True, width=120)
    init_module._render_panel_success(
        captured,
        setup_done=True,
        install_done=True,
        mode=init_module.MODE_ENV_ONLY,
        listen_port=8080,
        api_port=8765,
    )
    out = captured.export_text()
    assert "fallback" not in out.lower()


def test_render_panel_env_only_includes_try_it_now_block() -> None:
    """v0.1.4 P0-6: env-only success panel includes a copy-pasteable
    "Try it now" block so a brand-new user can confirm end-to-end
    metering works in two commands."""
    from rich.console import Console

    captured = Console(record=True, width=160)
    init_module._render_panel_success(
        captured,
        setup_done=True,
        install_done=True,
        mode=init_module.MODE_ENV_ONLY,
        listen_port=8080,
        api_port=8765,
    )
    out = captured.export_text()
    # The try-it-now header.
    assert "try it now" in out.lower()
    # A halton-meter run command and a halton-meter report command.
    assert "halton-meter run" in out
    assert "halton-meter report" in out


def test_render_panel_gui_mode_does_not_include_try_it_now_block() -> None:
    """v0.1.4 P0-6: --gui mode panel does NOT include the try-it-now
    block. --gui already has the system proxy live; the user is
    expected to make a regular HTTPS call (browser, terminal) and
    observe captures, not invoke `halton-meter run` explicitly."""
    from rich.console import Console

    captured = Console(record=True, width=160)
    init_module._render_panel_success(
        captured,
        setup_done=True,
        install_done=True,
        mode=init_module.MODE_FULL,
        proxy_done=True,
        setenv_done=True,
        listen_port=8080,
        api_port=8765,
    )
    out = captured.export_text()
    assert "try it now" not in out.lower()


# --------------------------------------------------------------------------- #
# v0.1.5 (2B.16) — 9-cell mode-transition matrix                              #
#                                                                             #
# Each cell drives ``_reconcile_to_mode`` with a synthesised "current state"  #
# matching one of {env-only, apps, full} and a target mode in the same set.  #
# Asserts the four mode-specific surfaces (proxy-managed sentinel, system    #
# proxy state, launchctl env, shell-rc block) end up in the configuration   #
# the target mode requires — independent of where they started.             #
# --------------------------------------------------------------------------- #


class _ReconcileFixture:
    """Helper that assembles the on-disk + in-memory pre-state for a
    given current mode, runs ``_reconcile_to_mode`` for a target mode,
    and inspects the four surfaces at the end.

    Patches: launchctl unsetenv, restore_system_proxy, _macos_interfaces,
    _read_macos_proxy, _disable_macos_proxy, detect_shell_rc, the
    proxy-managed sentinel path, and SHELL_RC_BLOCK_BEGIN/END use.
    """

    def __init__(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Any,
        current: str,
    ) -> None:
        from pathlib import Path

        self.monkeypatch = monkeypatch
        self.tmp_path = Path(str(tmp_path))
        self.current = current

        # 1. proxy-managed sentinel — present iff current=full.
        self.sentinel_path = self.tmp_path / "halton-meter" / "proxy-managed"
        self.sentinel_path.parent.mkdir(parents=True, exist_ok=True)
        if current == init_module.MODE_FULL:
            self.sentinel_path.touch()
        monkeypatch.setattr(
            "halton_meter.install._proxy_managed_sentinel_path",
            lambda: self.sentinel_path,
        )

        # 2. system proxy — Wi-Fi points at us iff current=full;
        # Ethernet always external. _resolve_daemon_listener returns
        # 127.0.0.1:8080 (matches the synthetic _read_macos_proxy
        # below).
        monkeypatch.setattr(
            "halton_meter.install._resolve_daemon_listener",
            lambda: ("127.0.0.1", 8080),
        )
        # restore_system_proxy returns False so the disable-fallback
        # path runs — that's the more-instructive code path because it
        # exercises the per-interface scan + disable.
        self.restore_calls: list[tuple[str, int]] = []
        monkeypatch.setattr(
            system_proxy,
            "restore_system_proxy",
            lambda host, port: self.restore_calls.append((host, port)) or False,
        )
        monkeypatch.setattr(
            system_proxy, "_macos_interfaces", lambda: ("Wi-Fi", "Ethernet"),
        )
        self._proxy_state = {
            "Wi-Fi": (current == init_module.MODE_FULL, "127.0.0.1", "8080"),
            "Ethernet": (False, None, None),
        }

        def fake_read(iface: str, secure: bool):
            return self._proxy_state[iface]

        monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)
        self.disable_calls: list[str] = []

        def fake_disable(iface: str) -> None:
            self.disable_calls.append(iface)
            self._proxy_state[iface] = (False, None, None)

        monkeypatch.setattr(system_proxy, "_disable_macos_proxy", fake_disable)

        # 3. launchctl env — record unsetenv calls. setenv side is not
        # invoked from _reconcile_to_mode (that's the additive step in
        # init() proper); only sweep is in scope here.
        self.unsetenv_calls: list[tuple[str, ...]] = []
        monkeypatch.setattr(
            system_proxy,
            "unsetenv_user_domain",
            lambda keys: self.unsetenv_calls.append(tuple(keys))
            or {k: 0 for k in keys},
        )

        # 4. shell-rc block — synthesise prior state.
        self.rc_path = self.tmp_path / ".zshrc"
        self.rc_user_content = "# user line\nalias x=y\n"
        if current in (init_module.MODE_APPS, init_module.MODE_FULL):
            block = (
                f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
                "export HTTPS_PROXY=http://127.0.0.1:8080\n"
                f"{init_module.SHELL_RC_BLOCK_END}\n"
            )
            self.rc_path.write_text(self.rc_user_content + "\n" + block, encoding="utf-8")
        else:
            self.rc_path.write_text(self.rc_user_content, encoding="utf-8")
        monkeypatch.setattr(init_module, "detect_shell_rc", lambda: self.rc_path)

    def reconcile(self, target: str) -> None:
        from rich.console import Console

        console = Console(record=True, width=160)
        init_module._reconcile_to_mode(target, console)

    def assert_state_for(self, target: str) -> None:
        """Assert the four surfaces match what ``target`` requires."""
        want_proxy = target == init_module.MODE_FULL
        want_env = target in (init_module.MODE_APPS, init_module.MODE_FULL)

        # Sentinel: present iff full.
        if want_proxy:
            # The reconciler doesn't WRITE the sentinel — that's run_setup's
            # job. The sentinel state therefore depends on what was there
            # at start: the test seeds it iff current==full.
            pass
        else:
            assert not self.sentinel_path.exists(), (
                f"target={target}: sentinel must be removed"
            )

        # System proxy: when target != full, no interface should still
        # be enabled pointing at us.
        if not want_proxy:
            for iface, (enabled, host, port) in self._proxy_state.items():
                points_at_us = system_proxy._proxy_targets_us(
                    host, port, "127.0.0.1", 8080
                )
                assert not (enabled and points_at_us), (
                    f"target={target}: {iface} still points at us"
                )

        # launchctl env: a sweep is expected iff the target doesn't want
        # env vars set.
        if not want_env:
            assert self.unsetenv_calls, (
                f"target={target}: unsetenv must be called"
            )
        else:
            assert not self.unsetenv_calls, (
                f"target={target}: unsetenv must NOT be called "
                f"(would clobber the just-written env)"
            )

        # Shell-rc: block absent iff target doesn't want it.
        body = self.rc_path.read_text(encoding="utf-8")
        if not want_env:
            assert init_module.SHELL_RC_BLOCK_BEGIN not in body, (
                f"target={target}: shell-rc block must be removed"
            )
        # Otherwise, the additive step in init() would ensure it's
        # present; reconcile alone is a no-op on the rc when the block
        # is wanted.
        # User content always preserved.
        assert "# user line" in body
        assert "alias x=y" in body


@pytest.mark.parametrize(
    "current,target",
    [
        (cur, tgt)
        for cur in ("env-only", "apps", "full")
        for tgt in ("env-only", "apps", "full")
    ],
)
def test_reconcile_to_mode_matrix_9_cells(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
    current: str,
    target: str,
) -> None:
    """v0.1.5 (2B.16) P0-1: every cell in the 3x3 (current, target) mode
    transition matrix lands the four mode-specific surfaces in a state
    consistent with the target mode. Tests the unified
    ``_reconcile_to_mode`` directly so the assertions are surface-
    granular rather than going through the full init flow."""
    fx = _ReconcileFixture(monkeypatch, tmp_path, current)
    fx.reconcile(target)
    fx.assert_state_for(target)


# --------------------------------------------------------------------------- #
# Apps-mode integration tests                                                 #
# --------------------------------------------------------------------------- #


def test_init_apps_mode_writes_apps_sentinel_and_runs_setenv(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16): --apps mode writes install-mode=apps, runs
    launchctl setenv, and crucially does NOT call the system-proxy
    enabler."""
    proxy_called: list[int] = []
    monkeypatch.setattr(
        init_module, "_enable_system_proxy_for_init",
        lambda **_kw: proxy_called.append(1),
    )
    setenv_calls: list[dict[str, str]] = []
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: setenv_calls.append(dict(env_vars))
        or {k: 0 for k in env_vars},
    )

    rc = init_module.init(non_interactive=True, apps=True, no_shell_rc=True)
    assert rc == 0
    # System proxy was NOT enabled.
    assert proxy_called == [], (
        "apps mode must NOT enable the system proxy"
    )
    # launchctl setenv WAS called.
    assert setenv_calls, "apps mode must call setenv_user_domain"
    # Sentinel reflects apps mode.
    assert init_module.read_install_mode() == init_module.MODE_APPS
    # run_setup called with managed=False (apps doesn't manage system proxy).
    assert patch_setup_all_done[0]["managed"] is False


def test_init_apps_mode_reconciles_after_prior_full_install(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    """v0.1.5 (2B.16): switching from --full to --apps must disable the
    system proxy and remove the proxy-managed sentinel — but KEEP the
    launchctl env and shell-rc block (which apps mode also wants)."""
    from pathlib import Path

    # Pre-state: full install (sentinel present, proxy on Wi-Fi).
    sentinel_dir = tmp_path / "halton-meter"
    sentinel_dir.mkdir(parents=True, exist_ok=True)
    sentinel_path = sentinel_dir / "proxy-managed"
    sentinel_path.touch()
    monkeypatch.setattr(
        "halton_meter.install._proxy_managed_sentinel_path",
        lambda: sentinel_path,
    )
    monkeypatch.setattr(
        "halton_meter.install._resolve_daemon_listener",
        lambda: ("127.0.0.1", 8080),
    )

    monkeypatch.setattr(
        system_proxy, "restore_system_proxy", lambda host, port: True,
    )
    # setenv call records.
    setenv_calls: list[dict[str, str]] = []
    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: setenv_calls.append(dict(env_vars))
        or {k: 0 for k in env_vars},
    )
    # Pre-existing rc block (matches apps-target shape; reconcile should
    # leave it alone).
    fake_rc = Path(str(tmp_path)) / ".zshrc"
    fake_rc.write_text(
        "# user\n\n"
        f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
        "export HTTPS_PROXY=http://127.0.0.1:8080\n"
        f"{init_module.SHELL_RC_BLOCK_END}\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(init_module, "detect_shell_rc", lambda: fake_rc)
    # No unsetenv calls expected.
    unsetenv_calls: list[tuple[str, ...]] = []
    monkeypatch.setattr(
        system_proxy, "unsetenv_user_domain",
        lambda keys: unsetenv_calls.append(tuple(keys))
        or {k: 0 for k in keys},
    )

    # Pre-state: install-mode sentinel says full.
    install_mode_path = Path(str(tmp_path)) / "halton" / "install-mode"
    install_mode_path.parent.mkdir(parents=True, exist_ok=True)
    install_mode_path.write_text("full\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode_path)

    rc = init_module.init(non_interactive=True, apps=True, no_shell_rc=True)
    assert rc == 0

    # 1. Sentinel removed (apps doesn't want the proxy-managed flag).
    assert not sentinel_path.exists()
    # 2. System proxy was restored / disabled.
    # 3. launchctl env: setenv_user_domain ran (apps wants env), and
    #    unsetenv was NOT called (would have clobbered the just-set
    #    env).
    assert setenv_calls, "apps mode must run setenv"
    assert unsetenv_calls == [], (
        "unsetenv must NOT run in apps mode (would clobber what setenv "
        "just wrote)"
    )
    # 4. shell-rc block survives (apps wants it).
    body = fake_rc.read_text(encoding="utf-8")
    assert init_module.SHELL_RC_BLOCK_BEGIN in body
    # 5. Sentinel updated to apps.
    assert install_mode_path.read_text(encoding="utf-8").strip() == "apps"


def test_init_full_mode_after_prior_apps_install_enables_system_proxy(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    patch_load_config_default: None,
    patch_proxy_already_correct: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Any,
) -> None:
    """v0.1.5 (2B.16): switching from --apps to --full must enable the
    system proxy and write the proxy-managed sentinel — keeping the
    launchctl env + shell-rc that apps already wrote."""
    from pathlib import Path

    monkeypatch.setattr(
        system_proxy, "setenv_user_domain",
        lambda env_vars: {k: 0 for k in env_vars},
    )
    install_mode_path = Path(str(tmp_path)) / "halton" / "install-mode"
    install_mode_path.parent.mkdir(parents=True, exist_ok=True)
    install_mode_path.write_text("apps\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode_path)

    rc = init_module.init(non_interactive=True, full=True, no_shell_rc=True)
    assert rc == 0
    # run_setup got managed=True (full mode).
    assert patch_setup_all_done[0]["managed"] is True
    # Sentinel updated to full.
    assert install_mode_path.read_text(encoding="utf-8").strip() == "full"


# --------------------------------------------------------------------------- #
# CLI mutual-exclusion test                                                   #
# --------------------------------------------------------------------------- #


def test_cli_init_rejects_apps_and_full_together(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16): passing both --apps and --full is a usage error
    (the CLI rejects with exit 2 before any side effects)."""
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--apps", "--full"])
    assert result.exit_code != 0
    assert "at most one" in result.output.lower() or "at most one" in (
        result.stderr_bytes or b""
    ).decode("utf-8", "ignore").lower()


def test_cli_init_rejects_apps_and_gui_together(
    macos: None,
    patch_setup_all_done: list[dict[str, Any]],
    patch_install_ok: list[int],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16): --gui (legacy) + --apps is mutually exclusive too."""
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--apps", "--gui"])
    assert result.exit_code != 0

