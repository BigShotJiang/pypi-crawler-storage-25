"""Tests for ``halton_meter.port_alloc`` (v0.1.3 P0-5).

Auto-port-fallback: probe defaults; persist chosen pair to runtime.toml;
honour user-pinned values from config.toml. The merged effective config
overlays defaults < runtime < config.toml.
"""

from __future__ import annotations

import socket
import textwrap
from pathlib import Path

import pytest

from halton_meter import port_alloc
from halton_meter.config import HaltonConfig


def _make_busy_listener(host: str, port: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen(1)
    return sock


# --------------------------------------------------------------------------- #
# allocate_ports                                                               #
# --------------------------------------------------------------------------- #


class TestAllocatePorts:
    def test_returns_defaults_when_both_free(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        # Stub the probe so we don't actually bind 8080/8765 on the dev box.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)

        listen, api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=True,
        )
        assert listen == 8080
        assert api == 8765
        # When both are at default, we do NOT write runtime.toml (no need).
        assert not runtime.exists()

    def test_falls_back_when_listen_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # 8080 busy, 8081 free; 8765 free.
        def fake_probe(host: str, port: int) -> bool:
            return port not in (8080,)

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        listen, api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert listen == 8081
        assert api == 8765
        # runtime.toml persisted because listen drifted from default.
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "listen_port = 8081" in body
        assert "api_port = 8765" in body

    def test_falls_back_when_api_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8765

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        listen, api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert listen == 8080
        assert api == 8766
        assert runtime.exists()

    def test_pinned_listen_honoured_even_if_unavailable(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When user pinned listen_port=8080 in config.toml, we honour it
        regardless of availability — daemon will fail-fast on bind clash
        with a clear error rather than silently relocating."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()  # default listen_port=8080
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        listen, api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=True,  # pinned!
            api_pinned=False,
            runtime_path=runtime,
        )
        # Listen is honoured (no probe).
        assert listen == 8080
        # API still falls back to default since every probe returns False.
        assert api == 8765

    def test_falls_back_to_default_when_every_candidate_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When all 10 candidates busy: noisy fallback to default.
        Daemon will surface a clear bind error."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        listen, api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert listen == 8080
        assert api == 8765

    def test_persist_false_skips_write(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8080

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        listen, _api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=False,
        )
        assert listen == 8081
        assert not runtime.exists()


# --------------------------------------------------------------------------- #
# load_effective_config                                                       #
# --------------------------------------------------------------------------- #


class TestLoadEffectiveConfig:
    def test_returns_defaults_when_neither_file_exists(
        self, tmp_path: Path
    ) -> None:
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=tmp_path / "missing-runtime.toml",
        )
        assert cfg.daemon.listen_port == 8080
        assert cfg.daemon.api_port == 8765

    def test_runtime_overrides_defaults(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent("""
                [daemon]
                listen_port = 8081
                api_port = 8766
            """),
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.listen_port == 8081
        assert cfg.daemon.api_port == 8766

    def test_config_overrides_runtime(self, tmp_path: Path) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nlisten_port = 8081\napi_port = 8766\n",
            encoding="utf-8",
        )
        config.write_text(
            "[daemon]\nlisten_port = 9999\n",
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=config, runtime_path=runtime
        )
        # config.toml's listen_port wins.
        assert cfg.daemon.listen_port == 9999
        # api_port not in config.toml -> takes from runtime.
        assert cfg.daemon.api_port == 8766

    def test_partial_runtime_only_one_port(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nlisten_port = 8085\n", encoding="utf-8"
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.listen_port == 8085
        # api_port falls back to default because runtime didn't have it.
        assert cfg.daemon.api_port == 8765

    def test_garbage_runtime_ignored(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text("not valid toml = = = ", encoding="utf-8")
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        # Defaults preserved; garbage tomllib decode error swallowed.
        assert cfg.daemon.listen_port == 8080


# --------------------------------------------------------------------------- #
# discover_and_persist_ports                                                  #
# --------------------------------------------------------------------------- #


class TestDiscoverAndPersistPorts:
    def test_detects_user_pinned_and_persists_only_runtime_drift(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        # User pins listen_port; api_port is implicit.
        config.write_text(
            "[daemon]\nlisten_port = 9000\n",
            encoding="utf-8",
        )

        # 9000 (pinned -> not probed). 8765 busy; 8766 free.
        def fake_probe(host: str, port: int) -> bool:
            return port == 8766

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        listen, api = port_alloc.discover_and_persist_ports(
            config_path=config, runtime_path=runtime
        )
        assert listen == 9000  # pinned
        assert api == 8766  # auto-allocated
        # runtime.toml persists the auto-allocated api port; the pinned
        # listen port may also appear (since allocate_ports doesn't
        # distinguish on persistence — fine).
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "api_port = 8766" in body


def test_runtime_toml_round_trip(tmp_path: Path) -> None:
    runtime = tmp_path / "runtime.toml"
    port_alloc._write_runtime_toml(runtime, listen_port=8090, api_port=8770)
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt == {"listen_port": 8090, "api_port": 8770}


def test_remove_runtime_toml_idempotent(tmp_path: Path) -> None:
    target = tmp_path / "runtime.toml"
    # Missing -> no-op.
    port_alloc.remove_runtime_toml(target)
    # Exists -> removed.
    target.write_text("[daemon]\nlisten_port = 8080\n", encoding="utf-8")
    assert target.exists()
    port_alloc.remove_runtime_toml(target)
    assert not target.exists()


def test_is_port_free_against_real_socket(tmp_path: Path) -> None:
    """Real socket round-trip: 0 means OS picks free port; we then
    confirm the same port returns False once we hold the listener."""
    # Pick an arbitrary high port the test harness probably isn't using.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    bound_port = sock.getsockname()[1]
    sock.listen(1)
    try:
        # While the socket holds the port, our probe must say "not free".
        assert port_alloc._is_port_free("127.0.0.1", bound_port) is False
    finally:
        sock.close()
    # After the socket releases, probe says "free" again (fallible on
    # SO_LINGER timing; assert weakly).
    # (Not asserting the True branch here to avoid timing flake on CI.)
