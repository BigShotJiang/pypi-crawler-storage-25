"""Tests for /v1/projects and /v1/stats endpoints.

Exercises the SQLite stats-aggregation port (date_trunc → strftime).
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import Project, Request


@pytest.fixture
async def seed_one_project(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
        await session.flush()
        for i in range(3):
            session.add(
                Request(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    provider="anthropic",
                    model="claude-sonnet-4-6",
                    mode="standard",
                    input_tokens=100 * (i + 1),
                    output_tokens=50 * (i + 1),
                    thinking_tokens=0,
                    cached_tokens=0,
                    cost_usd_minor_units=1000 * (i + 1),
                    latency_ms=120.0,
                    tokens_complete=True,
                    requested_at=datetime(2026, 4, 28, 10, 0, 0, tzinfo=UTC),
                    recorded_at=datetime(2026, 4, 28, 10, 0, 1, tzinfo=UTC),
                    status="success",
                )
            )
    return proj


async def test_list_empty_projects(client):
    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_list_projects_returns_seeded(client, seed_one_project):
    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    p = data[0]
    assert p["slug"] == "alpha"
    assert p["stats"]["all_time_requests"] == 3
    assert p["stats"]["all_time_cost_usd_minor_units"] == 6000  # 1000+2000+3000


async def test_get_project_404(client):
    resp = await client.get("/v1/projects/nope")
    assert resp.status_code == 404


async def test_global_stats_with_data(client, seed_one_project):
    resp = await client.get("/v1/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["summary"]["total_requests"] == 3
    assert data["summary"]["active_projects"] == 1
    by_day = data["by_day"]
    assert len(by_day) == 1
    assert by_day[0]["date"] == "2026-04-28"
    assert by_day[0]["requests"] == 3


async def test_project_stats(client, seed_one_project):
    resp = await client.get("/v1/projects/alpha/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["summary"]["total_requests"] == 3
    assert len(data["by_day"]) == 1
    assert data["by_day"][0]["date"] == "2026-04-28"


async def test_csv_export(client, seed_one_project):
    resp = await client.get("/v1/projects/alpha/requests.csv")
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
    body = resp.text
    assert "timestamp" in body
    assert "claude-sonnet-4-6" in body
