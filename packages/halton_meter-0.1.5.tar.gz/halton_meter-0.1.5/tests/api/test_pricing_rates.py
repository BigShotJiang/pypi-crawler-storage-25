"""Tests for the pricing rates CRUD API (ported from halton-meter-cloud).

Adjusted for SQLite + the daemon's seed-on-init behaviour: the
``StorageManager.initialise()`` path seeds pricing rates from the bundled
matrix the first time the table is empty. Here we trigger the same seed
from the API conftest by running it manually.
"""

from __future__ import annotations

import pytest

from halton_meter.storage import seed_pricing_rates
from halton_meter.storage.engine import create_engine_for


@pytest.fixture(autouse=True)
async def _seed_rates(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session:
        await seed_pricing_rates(session)


async def test_list_returns_seeded_rates(client):
    resp = await client.get("/v1/pricing-rates")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert len(data) > 0
    providers = {r["provider"] for r in data}
    assert "anthropic" in providers
    for field in (
        "id",
        "provider",
        "model",
        "mode",
        "effective_from",
        "input_rate",
        "output_rate",
        "thinking_rate",
        "cache_read_rate",
        "is_current",
        "last_verified_at",
    ):
        assert field in data[0], f"Missing field: {field}"


async def test_current_only_returns_active_rates(client):
    resp = await client.get("/v1/pricing-rates/current")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) > 0
    for r in data:
        assert r["is_current"] is True
        assert r["effective_to"] is None


async def test_rate_units_are_usd_per_million(client):
    resp = await client.get("/v1/pricing-rates/current")
    assert resp.status_code == 200
    data = resp.json()
    sonnet = [
        r
        for r in data
        if r["model"] == "claude-sonnet-4-6" and r["mode"] == "standard"
    ]
    assert sonnet, "expected claude-sonnet-4-6 in seeded rates"
    rate = sonnet[0]
    assert abs(rate["input_rate"] - 3.0) < 1e-3
    assert abs(rate["output_rate"] - 15.0) < 1e-3
    assert abs(rate["cache_read_rate"] - 0.30) < 1e-3


async def test_update_rate_closes_old_and_inserts_new(client):
    resp = await client.get("/v1/pricing-rates/current")
    assert resp.status_code == 200
    target = resp.json()[0]
    rate_id = target["id"]

    update = {
        "input_rate": 1.50,
        "output_rate": 6.00,
        "thinking_rate": 6.00,
        "cache_read_rate": 0.20,
    }
    resp = await client.put(f"/v1/pricing-rates/{rate_id}", json=update)
    assert resp.status_code == 200, resp.text
    new = resp.json()
    assert new["id"] != rate_id
    assert abs(new["input_rate"] - 1.5) < 1e-3
    assert new["is_current"] is True

    # Old row is now closed
    resp = await client.get("/v1/pricing-rates")
    rows = resp.json()
    old = next(r for r in rows if r["id"] == rate_id)
    assert old["effective_to"] is not None
    assert old["is_current"] is False


async def test_create_pricing_rate(client):
    body = {
        "provider": "openai",
        "model": "gpt-test",
        "mode": "standard",
        "input_rate": 0.5,
        "output_rate": 1.5,
        "thinking_rate": 1.5,
        "cache_read_rate": 0.05,
    }
    resp = await client.post("/v1/pricing-rates", json=body)
    assert resp.status_code == 201, resp.text
    created = resp.json()
    assert created["provider"] == "openai"
    assert created["model"] == "gpt-test"
    assert created["is_current"] is True
