"""Tests for ``halton_meter.doctor`` (v0.1.3 P0-7).

Diagnostic verdict + per-row reporting. The --curl probe is mocked
end-to-end; we never actually hit example.com from a test.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import doctor as doctor_module
from halton_meter.cli import cli
from halton_meter.health import HealthCheck

# --------------------------------------------------------------------------- #
# Probe-target safety regression                                              #
# --------------------------------------------------------------------------- #


def test_doctor_curl_target_is_safe() -> None:
    """``halton-meter doctor --curl`` MUST NEVER probe a provider domain.

    Regression on Phase 1's contract: the probe URL is hard-coded and
    cannot be swapped by config / CLI flag for a provider host. This
    test enumerates the forbidden fragments and asserts they're absent.
    """
    target = doctor_module._CURL_PROBE_URL
    forbidden = doctor_module._FORBIDDEN_HOST_FRAGMENTS
    for fragment in forbidden:
        assert fragment not in target.lower(), (
            f"Probe URL {target!r} must not contain {fragment!r}"
        )


# --------------------------------------------------------------------------- #
# Row construction                                                            #
# --------------------------------------------------------------------------- #


@pytest.fixture(autouse=True)
def _redirect_install_mode_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Don't touch the developer's real install-mode sentinel."""
    from halton_meter import init as init_module

    monkeypatch.setattr(
        init_module, "INSTALL_MODE_PATH", tmp_path / "install-mode-shadow"
    )


@pytest.fixture
def stub_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    """Default-stub all the system probes used by doctor so a single test
    can override a single dimension at a time.

    v0.1.5 (2B.16) P1-AUDIT-flake: stub
    ``port_alloc.load_effective_config`` to return the marketed defaults
    so the doctor's effective-ports row doesn't observe the live
    daemon's auto-fallback (8081 instead of 8080). Without the stub,
    these tests are flaky on developer machines where 8080/8765 are
    held by a live daemon — exactly the case Vikrant runs in.
    """
    from halton_meter import config as _config_module
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc, "load_effective_config",
        lambda *a, **kw: _config_module.HaltonConfig(),
    )
    # Daemon /health: by default OK.
    monkeypatch.setattr(
        "halton_meter.health.check_daemon_health",
        lambda *_a, **_kw: HealthCheck("Daemon /health", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_install_mode_sentinel",
        lambda **_kw: HealthCheck("Install-mode sentinel", True, "ok"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_plists_loaded_macos",
        lambda **_kw: HealthCheck("Daemon plist registered", True, "PID 1"),
    )
    monkeypatch.setattr(
        "halton_meter.health.check_port_persisted",
        lambda **_kw: HealthCheck("Port allocation persisted", True, "ok"),
    )
    # Cert trust real check: True.
    monkeypatch.setattr(
        "halton_meter.setup._is_cert_trusted_macos", lambda: True
    )
    monkeypatch.setattr(
        "halton_meter.setup._verify_cert_trust_macos_raw",
        lambda: (0, "ok\n", ""),
    )
    # System proxy: nothing pointing at us.
    from halton_meter import system_proxy

    monkeypatch.setattr(system_proxy, "_macos_interfaces", lambda: ("Wi-Fi",))
    monkeypatch.setattr(
        system_proxy, "_read_macos_proxy",
        lambda iface, secure: (False, None, None),
    )
    # launchctl getenv: nothing set.
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain", lambda key: None
    )
    # admin-trust SHA-1 probe: skip.
    monkeypatch.setattr(
        doctor_module, "_admin_trust_contains_mitmproxy_sha1", lambda: None
    )


def test_doctor_env_only_mode_healthy(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    """env-only mode where daemon is healthy + cert trusted + nothing
    pointing at the proxy = HEALTHY."""
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    # Make platform look macOS-like for the rows that gate on it.
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    report = doctor_module.run_doctor(run_curl=False)
    assert report.mode == "env-only"
    assert report.verdict == doctor_module.VERDICT_HEALTHY


def test_doctor_full_mode_broken_when_proxy_not_pointing_at_us(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    """full mode + system proxy NOT pointing at us = fail row -> BROKEN."""
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "full")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    report = doctor_module.run_doctor(run_curl=False)
    assert report.verdict == doctor_module.VERDICT_BROKEN


def test_doctor_full_mode_healthy_when_all_signals_good(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "full")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    # System proxy points at us.
    from halton_meter import system_proxy

    monkeypatch.setattr(
        system_proxy, "_read_macos_proxy",
        lambda iface, secure: (True, "127.0.0.1", "8080"),
    )
    # launchctl env keys all set.
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain",
        lambda key: f"value-for-{key}",
    )
    # detect_shell_rc returns something with marker present.
    fake_rc = Path("/tmp/fake-zshrc-doctor-test")
    fake_rc.write_text(
        "before\n# >>> halton-meter env vars (managed) >>>\n"
        "export HTTPS_PROXY=x\n"
        "# <<< halton-meter env vars (managed) <<<\n"
        "after\n",
        encoding="utf-8",
    )
    try:
        monkeypatch.setattr(
            "halton_meter.init.detect_shell_rc", lambda: fake_rc
        )
        report = doctor_module.run_doctor(run_curl=False)
    finally:
        try:
            fake_rc.unlink()
        except OSError:
            pass
    assert report.verdict in (
        doctor_module.VERDICT_HEALTHY,
        doctor_module.VERDICT_INCONSISTENT,  # shell-env-this-process may warn
    )


def test_doctor_apps_mode_healthy_when_proxy_disabled_env_set(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    """v0.1.5 (2B.16): apps mode is HEALTHY when daemon + cert ok AND
    system proxy NOT pointing at us AND launchctl env keys set AND
    shell-rc marker present."""
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "apps")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    from halton_meter import system_proxy

    # System proxy disabled — exactly what apps mode requires.
    monkeypatch.setattr(
        system_proxy, "_read_macos_proxy",
        lambda iface, secure: (False, None, None),
    )
    # launchctl env vars set.
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain",
        lambda key: f"value-for-{key}",
    )
    fake_rc = Path("/tmp/fake-zshrc-apps-test")
    fake_rc.write_text(
        "before\n# >>> halton-meter env vars (managed) >>>\n"
        "export HTTPS_PROXY=x\n"
        "# <<< halton-meter env vars (managed) <<<\n"
        "after\n",
        encoding="utf-8",
    )
    try:
        monkeypatch.setattr(
            "halton_meter.init.detect_shell_rc", lambda: fake_rc
        )
        report = doctor_module.run_doctor(run_curl=False)
    finally:
        try:
            fake_rc.unlink()
        except OSError:
            pass
    # The shell-env-this-process row may still warn (since the test
    # process doesn't have the env vars set) — accept HEALTHY OR
    # INCONSISTENT but reject BROKEN.
    assert report.verdict != doctor_module.VERDICT_BROKEN, (
        f"apps mode with proxy disabled + env set should NOT be BROKEN; "
        f"got {report.verdict}: {report.summary_message}"
    )
    assert report.mode == "apps"


def test_doctor_apps_mode_broken_when_proxy_points_at_us(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    """v0.1.5 (2B.16): apps mode + system proxy pointing at us = BROKEN
    drift. apps mode promises NOT to manage system proxy."""
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "apps")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    from halton_meter import system_proxy

    # System proxy pointing at us — drift.
    monkeypatch.setattr(
        system_proxy, "_read_macos_proxy",
        lambda iface, secure: (True, "127.0.0.1", "8080"),
    )
    monkeypatch.setattr(
        "halton_meter.system_proxy.getenv_user_domain",
        lambda key: f"value-for-{key}",
    )
    report = doctor_module.run_doctor(run_curl=False)
    assert report.verdict == doctor_module.VERDICT_BROKEN
    assert report.mode == "apps"


def test_doctor_legacy_gui_sentinel_reads_as_full(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None, tmp_path: Any
) -> None:
    """v0.1.5 (2B.16): an on-disk legacy ``gui`` sentinel value is
    surfaced as the canonical ``full`` in the doctor report (the
    read-tolerant alias is applied at read time)."""
    from halton_meter import init as init_module

    sentinel = tmp_path / "install-mode"
    sentinel.write_text("gui\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", sentinel)
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    report = doctor_module.run_doctor(run_curl=False)
    assert report.mode == "full"


def test_doctor_broken_when_daemon_health_fails(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(
        "halton_meter.health.check_daemon_health",
        lambda *_a, **_kw: HealthCheck(
            "Daemon /health", False, "no response", "fatal"
        ),
    )
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    report = doctor_module.run_doctor(run_curl=False)
    assert report.verdict == doctor_module.VERDICT_BROKEN


def test_doctor_inconsistent_when_install_mode_unknown(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: None)
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    report = doctor_module.run_doctor(run_curl=False)
    # Mode unknown -> warn row -> INCONSISTENT.
    assert report.verdict == doctor_module.VERDICT_INCONSISTENT


# --------------------------------------------------------------------------- #
# Curl probe                                                                  #
# --------------------------------------------------------------------------- #


def test_doctor_curl_probe_uses_safe_target(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None, tmp_path: Path
) -> None:
    """The --curl probe argv must contain example.com and the patched
    bundle path, NEVER a provider domain."""
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    monkeypatch.setattr(doctor_module.shutil, "which", lambda _name: "/usr/bin/curl")

    bundle = tmp_path / "bundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )

    captured: dict[str, Any] = {}

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        captured["argv"] = list(argv)
        import subprocess

        return subprocess.CompletedProcess(argv, 0, stdout="200", stderr="")

    monkeypatch.setattr(doctor_module.subprocess, "run", fake_run)

    report = doctor_module.run_doctor(run_curl=True)
    # Find the curl row.
    rows = [r for r in report.rows if r.name == "Curl probe"]
    assert rows, "expected a curl probe row"
    assert rows[0].icon == "ok"
    # argv must NOT contain any provider host.
    argv_str = " ".join(captured["argv"]).lower()
    for forbidden in doctor_module._FORBIDDEN_HOST_FRAGMENTS:
        assert forbidden not in argv_str, (
            f"argv leaked forbidden host: {forbidden}"
        )
    assert "example.com" in argv_str
    assert str(bundle) in " ".join(captured["argv"])


# --------------------------------------------------------------------------- #
# JSON output                                                                 #
# --------------------------------------------------------------------------- #


def test_doctor_json_emits_structured_report(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--json"])
    assert result.exit_code in (0, 1, 2)  # depends on rows
    payload = json.loads(result.output)
    assert "verdict" in payload
    assert "rows" in payload
    assert "mode" in payload
    assert payload["mode"] == "env-only"


# --------------------------------------------------------------------------- #
# Exit code                                                                   #
# --------------------------------------------------------------------------- #


def test_doctor_exit_code_healthy(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    # env-only mode + all stubs ok -> HEALTHY -> exit 0.
    assert result.exit_code == 0


def test_doctor_exit_code_broken(
    monkeypatch: pytest.MonkeyPatch, stub_environment: None
) -> None:
    monkeypatch.setattr(
        "halton_meter.health.check_daemon_health",
        lambda *_a, **_kw: HealthCheck(
            "Daemon /health", False, "no response", "fatal"
        ),
    )
    monkeypatch.setattr(doctor_module, "_read_install_mode", lambda: "env-only")
    monkeypatch.setattr(doctor_module._sys, "platform", "darwin")
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    # BROKEN -> exit 2.
    assert result.exit_code == 2
