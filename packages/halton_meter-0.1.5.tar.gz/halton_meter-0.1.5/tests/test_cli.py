"""Tests for the ``halton-meter`` Click CLI surface.

Currently scoped to the Q1 layer-4 (2B.10) ``reset-proxy`` subcommand;
broader CLI smoke lives in ``test_lifecycle.py`` and ``test_init.py``.
"""

from __future__ import annotations

import subprocess
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import cli as cli_module
from halton_meter import system_proxy


def test_reset_proxy_command_exits_zero_on_macos(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #1: ``halton-meter reset-proxy`` exits 0."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    # Preset the dynamic-enumeration cache (2B.7.2) so we exercise the
    # original 4-interface fallback list and the call-count assertion
    # remains valid.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0
    # The networksetup loop ran (4 ifaces x 2 variants).
    assert len(calls) == 8


def test_reset_proxy_command_exits_zero_on_linux(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0


def test_reset_proxy_command_succeeds_without_admin_or_plists(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #1 corollary: works on a system without our plists.

    Simulates CI / a fresh machine: ``networksetup`` may exist but every
    invocation returns non-zero (no admin / no privileges). The command
    must still exit 0 — every per-interface failure is swallowed
    inside ``_disable_macos_proxy``.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            argv, 1, stdout="", stderr="needs admin"
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0


# --------------------------------------------------------------------------- #
# 2B.11: uninstall purge tier flow                                             #
# --------------------------------------------------------------------------- #


def test_uninstall_default_no_purge_runs_without_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Plain ``halton-meter uninstall`` does not prompt; just runs."""
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall"])
    assert result.exit_code == 0
    assert captured == {"purge": False, "include_logs": False}


def test_uninstall_purge_prompts_and_aborts_on_no(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    called: dict[str, bool] = {"called": False}

    def fake_uninstall(*, purge: bool, include_logs: bool) -> int:
        called["called"] = True
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--purge"], input="no\n")
    assert result.exit_code == 1
    assert called["called"] is False
    assert "Aborted" in result.output


def test_uninstall_purge_proceeds_on_yes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--purge"], input="yes\n")
    assert result.exit_code == 0
    assert captured == {"purge": True, "include_logs": False}


def test_uninstall_include_logs_prompt_shows_record_count(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--purge --include-logs`` prompt displays the request and project counts."""
    from halton_meter import install as install_module

    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (1234, 7)
    )

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs"],
        input="delete\n",
    )
    assert result.exit_code == 0
    assert "1,234 requests" in result.output
    assert "7 projects" in result.output
    assert captured == {"purge": True, "include_logs": True}


def test_uninstall_include_logs_aborts_when_response_not_delete(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (10, 2)
    )
    called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        install_module,
        "uninstall",
        lambda **_kw: (called.__setitem__("called", True) or 0),
    )

    runner = CliRunner()
    # User types 'yes' (the wrong word for include-logs); must abort.
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs"],
        input="yes\n",
    )
    assert result.exit_code == 1
    assert called["called"] is False


def test_uninstall_include_logs_without_purge_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        install_module,
        "uninstall",
        lambda **_kw: (called.__setitem__("called", True) or 0),
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--include-logs"])
    assert result.exit_code == 2
    assert called["called"] is False


# --------------------------------------------------------------------------- #
# 2B.12: daemon preflight refuses second instance                              #
# --------------------------------------------------------------------------- #


class _StubDaemonCfg:
    """Minimal duck-typed config for daemon preflight tests."""

    def __init__(
        self,
        api_host: str = "127.0.0.1",
        api_port: int = 8765,
        listen_host: str = "127.0.0.1",
        listen_port: int = 8080,
    ) -> None:
        from types import SimpleNamespace

        self.daemon = SimpleNamespace(
            api_host=api_host,
            api_port=api_port,
            listen_host=listen_host,
            listen_port=listen_port,
            log_path="/tmp/halton-meter.log",
        )
        self.storage = SimpleNamespace(db_path="/tmp/halton-test.db")
        self.sync = SimpleNamespace()


def _patch_daemon_cfg(monkeypatch: pytest.MonkeyPatch) -> None:
    """Patch load_config + load_effective_config + discover_and_persist_ports
    so the daemon command sees a deterministic ``8080/8765`` config
    regardless of which ports are actually bound on the host.

    v0.1.5 (2B.16) P1-AUDIT-flake fix: the v0.1.4 form patched only
    ``load_config`` and was flaky when the developer's real daemon
    held 8765 (port_alloc would auto-fallback to 8766 → assertions
    looking for ``8765`` in stderr broke). The cli's ``daemon``
    command uses ``load_effective_config`` from port_alloc, not
    ``load_config`` — so the prior patch was a no-op on the hot path.
    """
    monkeypatch.setattr(cli_module, "load_config", lambda *_a, **_kw: _StubDaemonCfg())
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc, "load_effective_config",
        lambda *_a, **_kw: _StubDaemonCfg(),
    )
    monkeypatch.setattr(
        _port_alloc, "discover_and_persist_ports", lambda *_a, **_kw: None,
    )


def test_daemon_refuses_when_launchctl_reports_live_pid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bug A: launchctl-managed daemon already running → exit 1, no asyncio.run."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: 12654)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: False)

    asyncio_called: dict[str, bool] = {"called": False}

    def fake_run(*_a: Any, **_kw: Any) -> None:
        asyncio_called["called"] = True

    monkeypatch.setattr(cli_module.asyncio, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 1
    # Pre-flight ran BEFORE asyncio.run.
    assert asyncio_called["called"] is False
    # Stderr (mix_stderr defaults vary) — assert via combined output.
    # CliRunner default mix_stderr=True merges stderr into result.output.
    combined = result.output or ""
    assert "another instance is already running" in combined
    assert "PID 12654" in combined
    assert "com.haltonlabs.meter" in combined
    # NEVER recommend `halton-meter daemon` to the user (Bug B sister fix);
    # it's mentioned here only as the offending command's name.
    assert "halton-meter status" in combined
    assert "halton-meter stop" in combined


def test_daemon_refuses_when_api_port_already_bound(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bug A: another process holds api_port (no launchctl entry) → exit 1."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: None)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: True)

    asyncio_called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        cli_module.asyncio,
        "run",
        lambda *_a, **_kw: asyncio_called.__setitem__("called", True),
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 1
    assert asyncio_called["called"] is False
    # CliRunner default mix_stderr=True merges stderr into result.output.
    combined = result.output or ""
    assert "another instance is already running" in combined
    assert "8765" in combined
    assert "halton-meter status" in combined


def test_daemon_proceeds_when_nothing_running(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Pre-flight regression: clear field → asyncio.run is invoked normally."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: None)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: False)

    captured: dict[str, Any] = {"ran": False}

    def fake_run(coro: Any) -> None:
        # Click expects a sync return; we don't actually run the coroutine.
        # Close it to avoid "coroutine never awaited" warnings.
        try:
            coro.close()
        except Exception:
            pass
        captured["ran"] = True

    monkeypatch.setattr(cli_module.asyncio, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 0
    assert captured["ran"] is True


# --------------------------------------------------------------------------- #
# 2B.12.1: empty-records messages do not recommend `halton-meter daemon`      #
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    ("daemon_up", "proxy_on", "expected_phrase", "forbidden_phrase"),
    [
        (
            True,
            True,
            "system proxy is enabled",
            "halton-meter daemon",
        ),
        (
            True,
            False,
            "system proxy is disabled",
            "halton-meter daemon",
        ),
        (
            False,
            False,
            "daemon is not running",
            "halton-meter daemon",
        ),
    ],
    ids=["healthy_proxy_on", "healthy_proxy_off", "daemon_down"],
)
def test_empty_records_hint_branches(
    monkeypatch: pytest.MonkeyPatch,
    daemon_up: bool,
    proxy_on: bool,
    expected_phrase: str,
    forbidden_phrase: str,
) -> None:
    """Each daemon-state branch yields the right user-facing message."""
    monkeypatch.setattr(cli_module, "_health_ok", lambda *_a, **_kw: daemon_up)
    monkeypatch.setattr(
        cli_module, "_system_proxy_enabled", lambda *_a, **_kw: proxy_on
    )

    cfg = _StubDaemonCfg()
    hint = cli_module._empty_records_hint(cfg)
    assert expected_phrase in hint
    # The dev-mode foreground command must never appear in any
    # empty-records hint we ship to end users.
    assert forbidden_phrase not in hint
    # The two non-healthy branches should recommend `halton-meter start`.
    # The fully-healthy branch needs no command — just tells the user to
    # make an API call.
    if not (daemon_up and proxy_on):
        assert "halton-meter start" in hint


def test_uninstall_yes_flag_skips_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--yes`` skips interactive confirmation entirely (CI/scripted use)."""
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)
    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (0, 0)
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs", "--yes"],
    )
    assert result.exit_code == 0
    assert captured == {"purge": True, "include_logs": True}
