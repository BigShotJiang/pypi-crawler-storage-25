---
title: Swival
emoji: "\U0001F501"
colorFrom: indigo
colorTo: blue
sdk: gradio
python_version: "3.13"
suggested_hardware: cpu-basic
hf_oauth: true
hf_oauth_scopes:
  - inference-api
tags:
  - coding-agent
  - developer-tools
short_description: "Swival AI coding agent"
---

# Swival

An AI coding agent that works with any OpenAI-compatible LLM. Bring your own API key
and start a multi-turn conversation where the agent can read, write, and edit files
in a sandboxed workspace.

## How it works

1. Pick a provider and paste your API key. Your key is used for the current session
   only and is never stored.
2. Type a coding question or upload source files for context.
3. The agent works through the problem, reading and editing files as needed, then
   returns an answer. You can download any files it created.

## Supported providers

| Provider | Key needed | Example model |
|---|---|---|
| HuggingFace Inference | `HF_TOKEN` | `meta-llama/Llama-3.1-70B-Instruct` |
| OpenRouter | `OPENROUTER_API_KEY` | `meta-llama/llama-4-scout` |
| Google Gemini | `GEMINI_API_KEY` | `gemini-2.5-flash` |
| Any OpenAI-compatible | `OPENAI_API_KEY` + base URL | Your model ID |

## Limitations

- No shell command execution (sandboxed).
- No MCP servers, subagents, or skill discovery.
- The agent can make outbound HTTP requests to read documentation. This is not
  a network sandbox.
- File operations are scoped to a per-session temp directory.
- Sessions are ephemeral. Closing the tab loses everything.
- Inference speed depends on your chosen provider. The Space itself runs on free
  CPU-only hardware.
