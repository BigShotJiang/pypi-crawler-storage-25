"""Main CLI entry point for Synapse"""

import os

# Load environment variables from .env files FIRST
# This must happen before any other imports that might use env vars
try:
    from dotenv import load_dotenv

    load_dotenv()  # Load .env from current working directory
except ImportError:
    pass

# Suppress gRPC/abseil logging warnings BEFORE any grpc imports
# These must be set before grpc is imported anywhere
os.environ["GRPC_VERBOSITY"] = "ERROR"
os.environ["GRPC_TRACE"] = ""
os.environ["GRPC_ENABLE_FORK_SUPPORT"] = "0"

import click  # noqa: E402

# Version
__version__ = "0.1.3"


@click.group()
@click.version_option(version=__version__)
def synapse():
    """
    🚀 Synapse - Agentic MCP Server Generator

    Automatically analyze your codebase and generate production-ready
    MCP servers for seamless AI integration.
    """
    pass


@synapse.command()
@click.option("--force", is_flag=True, help="Force re-initialization")
def init(force):
    """
    Initialize Synapse in the current directory.

    Creates ~/.synapse (global config) and PROJECT_ROOT/.synapse (project
    config). If no global API key exists, prompts for an API key (masked) and
    sets both project and global keys. If a global key exists, reuses it for
    this project.

    Examples:
        synapse init
        synapse init --force  # Re-initialize if already exists
    """
    from commands.init_command import run_init

    run_init(force)


@synapse.command()
@click.option(
    "--output", "-o", default=".synapse", help="Output directory for analysis"
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def analyze(output, verbose):
    """
    Analyze codebase and generate project schema

    This command scans your entire codebase and:
    - Identifies all modules, classes, and functions
    - Generates a detailed project schema
    - Creates statistics about your codebase

    Examples:
        synapse analyze
        synapse analyze --verbose
        synapse analyze --output ./custom_output
    """
    from commands.analyze_command import run_analyze

    run_analyze(output, verbose)


@synapse.command()
@click.option(
    "--update",
    is_flag=True,
    help="Update configuration interactively",
)
@click.option(
    "--key",
    "api_key",
    default=None,
    help="Set API key (project or global with --global)",
)
@click.option(
    "--global",
    "global_scope",
    is_flag=True,
    help="Apply --key to global config (~/.synapse)",
)
def config(update, api_key, global_scope):
    """
    View or update Synapse configuration.

    Without flags: Displays current configuration (API key shown as first 5
    chars + ****).

    Set API key:
      synapse config --key <API_KEY>           Set project API key (and global
                                               if global not set)
      synapse config --global --key <API_KEY> Set global API key only

    Examples:
        synapse config                    # View current config
        synapse config --key sk-xxx       # Set project key
        synapse config --global --key sk-xxx  # Set global key
    """
    from commands.config_command import run_config

    run_config(update=update, api_key=api_key, global_scope=global_scope)


@synapse.command()
@click.option(
    "--query",
    "-q",
    help="MCP server requirements (if not provided, will prompt)",
)
@click.option(
    "--output",
    "-o",
    default="mcp_server.py",
    help="Output file for generated server",
)
@click.option(
    "--no-validate",
    is_flag=True,
    default=False,
    help="Skip validation step",
)
@click.option(
    "--no-docs",
    is_flag=True,
    default=False,
    help="Skip documentation step",
)
@click.option(
    "--generate",
    "-g",
    is_flag=True,
    default=False,
    help="Skip planner and use existing todo_list.md",
)
def build(query, output, no_validate, no_docs, generate):
    """
    Build MCP server based on requirements

    This command generates a production-ready MCP server by:
    - Understanding your requirements
    - Analyzing your codebase
    - Generating MCP-compliant server code
    - Optionally validating the generated code
    - Optionally generating documentation

    Examples:
        synapse build
        synapse build --query "Create tools for database operations"
        synapse build --output custom_server.py
        synapse build --no-validate  # Skip validation
        synapse build --no-docs      # Skip documentation
        synapse build --no-validate --no-docs  # Skip both
        synapse build --generate     # Use existing todo_list.md, skip planner
    """
    from commands.build_command import run_build_command

    run_build_command(
        query,
        output,
        validate=not no_validate,
        docs=not no_docs,
        generate_only=generate,
    )


@synapse.command()
def info():
    """
    Show project status and account quota usage.

    Displays:
    - Project initialization and analysis status
    - API key info
    - MCP server quota (used / max)
    - Lines indexed quota (used / max)

    Examples:
        synapse info
    """
    from commands.info_command import run_info

    run_info()


def main():
    """Main entry point"""
    synapse()


if __name__ == "__main__":
    main()
