"""Query expander — used for the custom prompt path.

Expands a user query into multiple search terms, runs both semantic vector
search (Qdrant) and exact keyword search (ripgrep / Python fallback), then
re-ranks the merged candidates using three signals:

  1. Semantic similarity score (cosine, from Qdrant)
  2. Recency (file mtime — recently-modified files score higher)
  3. Public API membership (__init__.py exports get a boost)

Finally, a cheap LLM side-call (Haiku) selects the best candidates from the
ranked shortlist so only the most relevant functions reach the generator.
"""

import ast
import logging
import os
import re
import subprocess
import time
from typing import Optional

logger = logging.getLogger(__name__)

# Common English stopwords that add noise to code searches
_STOPWORDS = {
    "a", "an", "the", "and", "or", "for", "to", "in", "of", "with",
    "that", "this", "it", "is", "be", "are", "was", "were", "has",
    "have", "do", "does", "my", "me", "i", "we", "you", "your",
    "their", "from", "on", "at", "by", "as", "all", "some", "can",
    "will", "would", "should", "create", "make", "build", "generate",
    "get", "set",
}

# Maps domain keywords to relevant code-search terms
_DOMAIN_EXPANSIONS: dict[str, list[str]] = {
    "database": ["query", "execute", "fetch", "records", "table", "sql", "db"],
    "search":   ["find", "lookup", "query", "filter", "index", "retrieval"],
    "file":     ["read", "write", "open", "path", "directory", "filesystem"],
    "api":      ["endpoint", "request", "response", "http", "client", "rest"],
    "auth":     ["login", "token", "authenticate", "permission", "user"],
    "cache":    ["redis", "store", "expire", "hit", "miss", "invalidate"],
    "email":    ["send", "smtp", "message", "template", "notify"],
    "image":    ["process", "resize", "upload", "thumbnail", "transform"],
    "data":     ["process", "transform", "parse", "convert", "export", "import"],
    "vector":   ["embed", "similarity", "semantic", "qdrant", "index", "search"],
    "nlp":      ["text", "tokenize", "parse", "classify", "extract", "summarize"],
    "ml":       ["predict", "train", "model", "inference", "score", "feature"],
    "linkedin": ["post", "publish", "share", "profile", "connect", "message"],
    "social":   ["post", "share", "publish", "feed", "profile"],
    "post":     ["create", "publish", "write", "send", "submit"],
    "send":     ["post", "deliver", "transmit", "dispatch", "publish"],
}

# Score weight split: semantic similarity vs recency
_SEMANTIC_WEIGHT = 0.70
_RECENCY_WEIGHT  = 0.20
_EXPORT_BOOST    = 0.10   # Flat additive boost for __init__.py exported names


# =============================================================================
# Public exports scan — __init__.py exports as high-signal tier
# =============================================================================

def _scan_public_exports(working_dir: str) -> frozenset[str]:
    """Return all names exported via __init__.py __all__ lists in the project.

    Parses every __init__.py under working_dir using ast. Names that appear in
    __all__ are considered the public API — a function matching one of these is
    a much stronger candidate than one buried in an internal module.

    Returns a frozenset of lowercase names for fast lookup.
    """
    exported: set[str] = set()

    skip_dirs = {
        "__pycache__", ".git", ".venv", "venv", "node_modules",
        ".synapse", "env", ".env",
    }

    for dirpath, dirnames, filenames in os.walk(working_dir):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]

        if "__init__.py" not in filenames:
            continue

        init_path = os.path.join(dirpath, "__init__.py")
        try:
            with open(init_path, "r", encoding="utf-8") as f:
                source = f.read()
            tree = ast.parse(source, filename=init_path)
        except (OSError, SyntaxError):
            continue

        for node in tree.body:
            # __all__ = ["name1", "name2", ...]
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__":
                        if isinstance(node.value, (ast.List, ast.Tuple)):
                            for elt in node.value.elts:
                                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                    exported.add(elt.value.lower())
            # from .submodule import name  (re-exports in __init__)
            elif isinstance(node, ast.ImportFrom) and node.level > 0:
                for alias in node.names:
                    name = alias.asname if alias.asname else alias.name
                    if name != "*":
                        exported.add(name.lower())

    return frozenset(exported)


# =============================================================================
# Exact-match keyword search (ripgrep → Python fallback)
# =============================================================================

def _ripgrep_search(
    keywords: list[str],
    working_dir: str,
    max_results: int = 20,
) -> list[dict]:
    """Run ripgrep for each keyword; return unique matching function/class names.

    Matches lines that look like function or class definitions containing the
    keyword (def ..., async def ..., class ...).  Each result has:
      {"name": str, "file_path": str, "mtime": float}

    Falls back to Python grep if ripgrep is not available.
    """
    seen: set[str] = set()
    results: list[dict] = []

    # Build a combined pattern: match def/class lines containing any keyword
    if not keywords:
        return results

    kw_pattern = "|".join(re.escape(k) for k in keywords[:5])
    # Match definition lines that contain any keyword
    pattern = rf"(?:async\s+)?def\s+\w*(?:{kw_pattern})\w*\s*\(|class\s+\w*(?:{kw_pattern})\w*"

    def _parse_rg_line(line: str) -> Optional[dict]:
        """Parse a rg --line-number output line: path:lineno:content"""
        parts = line.split(":", 2)
        if len(parts) < 3:
            return None
        file_path, _lineno, content = parts[0], parts[1], parts[2]
        if not file_path.endswith(".py"):
            return None
        # Extract the name from the definition line
        m = re.search(r"(?:async\s+)?def\s+(\w+)|class\s+(\w+)", content)
        if not m:
            return None
        name = m.group(1) or m.group(2)
        key = f"{file_path}::{name}"
        if key in seen:
            return None
        seen.add(key)
        try:
            mtime = os.path.getmtime(file_path)
        except OSError:
            mtime = 0.0
        return {"name": name, "file_path": file_path, "mtime": mtime, "score": 0.0}

    # Try ripgrep first (fast)
    try:
        proc = subprocess.run(
            [
                "rg", "--line-number", "--no-heading", "--color=never",
                "--type", "py",
                "--ignore-case",
                "-e", pattern,
                working_dir,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        for line in proc.stdout.splitlines():
            if len(results) >= max_results:
                break
            r = _parse_rg_line(line)
            if r:
                results.append(r)
        return results
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass  # ripgrep not available — fall through to Python grep

    # Python fallback: walk files manually
    skip_dirs = {
        "__pycache__", ".git", ".venv", "venv", "node_modules",
        ".synapse", "env", ".env",
    }
    try:
        compiled = re.compile(pattern, re.IGNORECASE)
    except re.error:
        return results

    for dirpath, dirnames, filenames in os.walk(working_dir):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for filename in filenames:
            if not filename.endswith(".py"):
                continue
            fp = os.path.join(dirpath, filename)
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        if compiled.search(line):
                            m = re.search(r"(?:async\s+)?def\s+(\w+)|class\s+(\w+)", line)
                            if m:
                                name = m.group(1) or m.group(2)
                                key = f"{fp}::{name}"
                                if key not in seen:
                                    seen.add(key)
                                    try:
                                        mtime = os.path.getmtime(fp)
                                    except OSError:
                                        mtime = 0.0
                                    results.append({"name": name, "file_path": fp, "mtime": mtime, "score": 0.0})
                                    if len(results) >= max_results:
                                        return results
            except OSError:
                continue
    return results


# =============================================================================
# Recency normalisation
# =============================================================================

def _normalize_recency(chunks: list[dict]) -> list[dict]:
    """Add a normalised `recency_score` in [0, 1] to each chunk.

    The most recently modified file gets 1.0; the oldest gets 0.0.
    Files with mtime=0 (unknown) get 0.5 (neutral).
    """
    mtimes = [c.get("mtime", 0.0) for c in chunks]
    known = [m for m in mtimes if m > 0]

    if len(known) < 2:
        # Can't normalise with fewer than 2 known values
        for c in chunks:
            c["recency_score"] = 0.5
        return chunks

    min_t, max_t = min(known), max(known)
    span = max_t - min_t or 1.0

    for c in chunks:
        m = c.get("mtime", 0.0)
        if m <= 0:
            c["recency_score"] = 0.5
        else:
            c["recency_score"] = (m - min_t) / span

    return chunks


# =============================================================================
# Blended ranking
# =============================================================================

def _blend_and_rank(
    chunks: list[dict],
    exported_names: frozenset[str],
) -> list[dict]:
    """Compute a blended score and sort descending.

    blended = semantic_weight * semantic_score
            + recency_weight  * recency_score
            + export_boost    (if name is a public export)

    Chunks from ripgrep (score=0.0) get a semantic contribution of 0 but can
    still rank highly via recency + export boost.
    """
    chunks = _normalize_recency(chunks)

    for c in chunks:
        semantic = float(c.get("score", 0.0))
        recency  = float(c.get("recency_score", 0.5))
        export   = _EXPORT_BOOST if c.get("name", "").lower() in exported_names else 0.0
        c["blended_score"] = (
            _SEMANTIC_WEIGHT * semantic
            + _RECENCY_WEIGHT * recency
            + export
        )

    chunks.sort(key=lambda c: c["blended_score"], reverse=True)
    return chunks


# =============================================================================
# LLM side-call candidate selector
# =============================================================================

# =============================================================================
# Signature parsing for _ChunkProxy metadata
# =============================================================================

def _parse_signature_metadata(signature: str) -> tuple[bool, str]:
    """Extract is_async and return_type from a raw signature string.

    Examples:
      "async def post_to_linkedin(access_token: str) -> bool"
        → (True, "bool")
      "def create_post(text: str, title: str = None) -> dict"
        → (False, "dict")
      "def upload_Image(url, path)"
        → (False, "Any")

    Returns:
        (is_async, return_type)
    """
    sig = (signature or "").strip()

    is_async = sig.startswith("async ")

    # Extract return type annotation after "->"
    m = re.search(r"->\s*(.+?)(?:\s*:|$)", sig)
    if m:
        return_type = m.group(1).strip().rstrip(":")
    else:
        return_type = "Any"

    return is_async, return_type


# =============================================================================
# Query term expansion (keyword-based, no network)
# =============================================================================

def expand_query_for_search(user_query: str) -> list[str]:
    """Expand a natural language query into code-search terms.

    Stage 1 (always): keyword extraction — tokenise, remove stopwords,
    generate code-oriented variants.  No network calls.

    Args:
        user_query: The user's free-text build query.

    Returns:
        Deduplicated list of search terms, best first.
    """
    query_lower = user_query.lower()

    # Tokenise on non-alphanumeric boundaries
    raw_tokens = re.split(r"[^a-z0-9]+", query_lower)
    base_terms = [t for t in raw_tokens if t and t not in _STOPWORDS and len(t) > 2]

    # Domain expansion: check each token against the expansion map
    expanded: list[str] = list(base_terms)
    for token in base_terms:
        if token in _DOMAIN_EXPANSIONS:
            expanded.extend(_DOMAIN_EXPANSIONS[token])
        else:
            # Partial match (e.g. "databases" → "database")
            for domain, extras in _DOMAIN_EXPANSIONS.items():
                if domain in token or token in domain:
                    expanded.extend(extras[:3])  # top 3 expansions only
                    break

    # Deduplicate while preserving order
    seen: set[str] = set()
    result: list[str] = []
    for term in expanded:
        if term not in seen:
            seen.add(term)
            result.append(term)

    # Keep the full original query as the first/primary term
    result = [user_query] + [t for t in result if t != user_query]

    return result[:10]  # cap at 10 terms


# =============================================================================
# Cardinality inference
# =============================================================================

def _infer_max_candidates(user_query: str) -> int:
    """Infer how many candidates to fetch based on cardinality hints in the query.

    If the user says "one tool", "single tool", "just one", "a tool" etc., they
    want a focused result — fetch very few candidates so the generator doesn't
    receive irrelevant context and hallucinate extra tools.

    Returns a number between 3 and 10.
    """
    q = user_query.lower()
    # Explicit single-tool signals
    if any(phrase in q for phrase in [
        "one tool", "single tool", "just one", "one single", "only one",
        "a single", "one mcp", "1 tool",
    ]):
        return 3   # fetch top-3 so LLM can pick the best match
    # Small number hints
    if any(phrase in q for phrase in ["two tools", "three tools", "a few tools", "couple of"]):
        return 5
    # Default: fetch enough for a medium-sized server
    return 10


# =============================================================================
# Main entry point
# =============================================================================

def build_context_bundle_from_query(
    user_query: str,
    working_dir: str,
    synapse_dir: str,
    max_candidates: int = None,
) -> dict:
    """Build a context bundle for the custom prompt path.

    Retrieval pipeline (in order):
      1. Qdrant semantic search on each expanded term (vector similarity)
      2. Ripgrep / Python grep for exact keyword matches on function def lines
      3. __init__.py public-export scan for API-tier boost signal
      4. Recency-blended re-ranking (70% semantic + 20% recency + 10% export)

    Args:
        user_query:     The user's free-text build query.
        working_dir:    Absolute project root.
        synapse_dir:    Absolute path to the .synapse directory.
        max_candidates: Maximum endpoints in the bundle. Inferred from query if None.
        api_key:        Anthropic API key for the LLM selector step.
                        If None, the LLM step is skipped (blended ranking only).

    Returns:
        context_bundle dict suitable for JSON serialisation, or an empty bundle
        if the Qdrant index is not available.
    """
    if max_candidates is None:
        max_candidates = _infer_max_candidates(user_query)

    qdrant_path      = synapse_dir
    collection_name  = "code_context"
    search_terms     = expand_query_for_search(user_query)

    # ── Step 1: Qdrant semantic search ────────────────────────────────────────
    from utils.code_indexer import search_code

    seen_keys: set[str] = set()
    raw_chunks: list[dict] = []

    for term in search_terms:
        try:
            results = search_code(
                query=term,
                qdrant_path=qdrant_path,
                collection_name=collection_name,
                top_k=5,
            )
        except Exception:
            continue

        for chunk in results:
            key = f"{chunk.get('file_path', '')}::{chunk.get('name', '')}"
            if key not in seen_keys:
                seen_keys.add(key)
                # Attach file mtime for recency scoring
                try:
                    chunk["mtime"] = os.path.getmtime(chunk["file_path"])
                except OSError:
                    chunk["mtime"] = 0.0
                raw_chunks.append(chunk)

    # ── Step 2: Ripgrep / Python exact keyword search ─────────────────────────
    # Pull the most informative keywords (skip the full query sentence itself)
    kw_terms = [t for t in search_terms[1:] if len(t) > 3][:5]
    if kw_terms:
        grep_hits = _ripgrep_search(kw_terms, working_dir, max_results=20)
        for hit in grep_hits:
            key = f"{hit['file_path']}::{hit['name']}"
            if key not in seen_keys:
                seen_keys.add(key)
                raw_chunks.append(hit)

    if not raw_chunks:
        return {
            "endpoints": [],
            "project_name": os.path.basename(working_dir),
            "mode": "custom_prompt",
            "query": user_query,
        }

    # ── Step 3: Public export scan ────────────────────────────────────────────
    try:
        exported_names = _scan_public_exports(working_dir)
    except Exception:
        exported_names = frozenset()

    # ── Step 4: Recency-blended re-ranking ────────────────────────────────────
    ranked = _blend_and_rank(raw_chunks, exported_names)

    final_chunks = ranked[:max_candidates]

    # ── Build context bundle from selected chunks ──────────────────────────────
    endpoints = []
    for chunk in final_chunks:
        abs_path = chunk.get("file_path", "")
        name     = chunk.get("name", "")
        if not abs_path or not name:
            continue

        # Parse is_async and return_type from the stored signature string
        signature = chunk.get("signature", f"def {name}(...)")
        is_async, return_type = _parse_signature_metadata(signature)

        ep = _ChunkProxy(
            name=name,
            file_path=abs_path,
            signature=signature,
            docstring=chunk.get("docstring", ""),
            return_type=return_type,
            conversion_type="ready",
            client_dependency=None,
            is_async=is_async,
        )
        endpoints.append(ep)

    if not endpoints:
        return {
            "endpoints": [],
            "project_name": os.path.basename(working_dir),
            "mode": "custom_prompt",
            "query": user_query,
        }

    from utils.context_builder import build_context_bundle

    bundle = build_context_bundle(endpoints, working_dir, synapse_dir)
    bundle["mode"]  = "custom_prompt"
    bundle["query"] = user_query
    return bundle


# =============================================================================
# _ChunkProxy — minimal EndpointCandidate-compatible wrapper
# =============================================================================

class _ChunkProxy:
    """Minimal EndpointCandidate-compatible proxy wrapping a Qdrant/grep chunk."""

    def __init__(
        self,
        name: str,
        file_path: str,
        signature: str,
        docstring: str,
        return_type: str,
        conversion_type: str,
        client_dependency,
        is_async: bool = False,
    ) -> None:
        self.name             = name
        self.file_path        = file_path
        self.signature        = signature
        self.docstring        = docstring
        self.return_type      = return_type
        self.conversion_type  = conversion_type
        self.client_dependency = client_dependency
        self.is_async         = is_async
