"""Endpoint extractor — extracts Python functions for MCP tool candidate detection.

Sends functions to the backend's DetectEndpoints RPC for AI classification.
Pre-filters noise (tests, internals, utility decorators) so the backend sees
only plausible business-logic functions.

Filtering tiers (applied in order):
  1. Directory skip  — never descend into test/infra dirs
  2. File skip       — skip test files, config files, generated files
  3. Path-based skip — skip internal library paths, underscore dirs
  4. Function skip   — skip private/dunder, test functions
  5. Decorator skip  — skip validators, properties, fixtures, etc.
  6. Name-pattern skip — skip is_*/has_*/can_* helpers, lifecycle hooks

Functions excluded by tiers 5–6 are still discoverable via the custom prompt
path (Qdrant search), so the user can still reach them explicitly.
"""

import ast
import os
from typing import Optional

# ── Tier 1: Directory names to skip entirely ─────────────────────────────────
SKIP_DIRS: frozenset[str] = frozenset(
    {
        "__pycache__",
        ".git",
        ".venv",
        "venv",
        "node_modules",
        ".synapse",
        "env",
        ".env",
        "tests",
        "test",
        "testing",
        "dist",
        "build",
        ".egg-info",
        ".pytest_cache",
        ".mypy_cache",
        ".tox",
    }
)

# ── Tier 2: Exact filenames to skip ──────────────────────────────────────────
SKIP_FILENAMES: frozenset[str] = frozenset(
    {
        "mcp_server.py",
        "setup.py",
        "conftest.py",
        "noxfile.py",
        "__init__.py",
    }
)

# ── Tier 3: Path-segment patterns (normalised to forward-slash) ──────────────
# These identify internal library implementation directories, not public APIs.
SKIP_PATH_SEGMENTS: tuple[str, ...] = (
    "/tests/",
    "/test/",
    "/_tests/",
    "/testing/",
    "/test_",
    "\\tests\\",
    "\\test\\",
    "\\_tests\\",  # Windows variants
    "/_async/",
    "/_sync/",
    "/client/",
    "/clients/",
    "/plugins/",
    "/plugin/",
    "/transport/",
    "/transports/",
    "/connection/",
    "/connections/",
    "/compat/",
    "/serializer/",
    "/serializers/",
    "/exceptions/",
)

SKIP_FILE_NAMES_PARTIAL: tuple[str, ...] = (
    "test_",
    "_test.py",
    "tests.py",
    "fixtures.py",
    "test.py",
)

# ── Tier 5: Decorator names that mark non-tool functions ─────────────────────
SKIP_DECORATORS: frozenset[str] = frozenset(
    {
        "validator",
        "field_validator",
        "property",
        "cached_property",
        "staticmethod",
        "abstractmethod",
        "classmethod",
        "dataclass",
        "fixture",
        "mock",
        "patch",
        "pytest",
    }
)

# ── Tier 6: Name patterns that mark helper / lifecycle functions ──────────────
SKIP_NAME_PREFIXES: tuple[str, ...] = ("is_", "has_", "can_")
SKIP_NAME_EXACT: frozenset[str] = frozenset(
    {
        "setup",
        "teardown",
        "configure",
        "initialize",
        "setUp",
        "tearDown",
        "setUpClass",
        "tearDownClass",
        "setUpModule",
        "tearDownModule",
    }
)


# =============================================================================
# Public entry point
# =============================================================================


def extract_all_functions(working_dir: str) -> list[dict]:
    """Extract Python functions from a project as proto-compatible dicts.

    Uses pure AST analysis — no AI, no network calls.  The backend's
    DetectEndpoints RPC will classify which are good MCP tool candidates.

    Args:
        working_dir: Absolute path to the project root.

    Returns:
        List of FunctionInfo-compatible dicts, one per function/method found.
        Fields match the FunctionInfo proto message:
          name, file_path (relative), signature, docstring, return_type,
          is_async, line_number, param_names, param_types, endpoint_type.
    """
    results: list[dict] = []

    for root, dirs, files in os.walk(working_dir):
        # Tier 1: prune ignored directories in-place
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

        for filename in files:
            if not filename.endswith(".py"):
                continue

            # Tier 2: exact filename skip
            if filename in SKIP_FILENAMES:
                continue

            abs_path = os.path.join(root, filename)
            try:
                rel_path = os.path.relpath(abs_path, working_dir)
            except ValueError:
                rel_path = abs_path

            # Tier 2 (partial name) + Tier 3 (path segments)
            if _should_skip_file(filename, rel_path):
                continue

            functions = _extract_from_file(abs_path, rel_path)
            results.extend(functions)

    return results


# =============================================================================
# File-level filtering
# =============================================================================


def _should_skip_file(filename: str, rel_path: str) -> bool:
    """Return True if the file should be excluded from extraction."""
    fname_lower = filename.lower()

    # Tier 2 partial — test file name patterns
    if any(pat in fname_lower for pat in SKIP_FILE_NAMES_PARTIAL):
        return True

    # Tier 3 — path-segment patterns
    # Normalise separators for cross-platform matching
    norm = rel_path.replace("\\", "/").lower()
    # Wrap in slashes so leading/trailing segments are caught
    wrapped = f"/{norm}/"
    if any(seg in wrapped for seg in SKIP_PATH_SEGMENTS):
        return True

    # Tier 3 — underscore-prefixed directories (e.g. /_internal/, /_helpers/)
    # Check each directory component (not the filename itself)
    parts = norm.split("/")
    for part in parts[:-1]:
        if part.startswith("_") and part != "__pycache__":
            return True

    return False


# =============================================================================
# File parsing
# =============================================================================


def _extract_from_file(abs_path: str, rel_path: str) -> list[dict]:
    """Parse a single Python file and extract filtered function metadata."""
    try:
        with open(abs_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=abs_path)
    except (OSError, SyntaxError):
        return []

    results: list[dict] = []
    _walk_functions(tree, source, rel_path, results)
    return results


# =============================================================================
# Function-level filtering
# =============================================================================


def _should_skip_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Return True if this function should be excluded (tiers 4–6)."""
    name = node.name

    # Tier 4: private / dunder
    if name.startswith("_"):
        return True

    # Tier 4: test functions
    if name.lower().startswith("test") or name.startswith("Test"):
        return True

    # Tier 5: skip-decorator check
    for dec in node.decorator_list:
        dec_name = _decorator_name(dec)
        if dec_name and dec_name.lower() in SKIP_DECORATORS:
            return True

    # Tier 6: helper / lifecycle name patterns
    name_lower = name.lower()
    if any(name_lower.startswith(p) for p in SKIP_NAME_PREFIXES):
        return True
    if name in SKIP_NAME_EXACT or name_lower in SKIP_NAME_EXACT:
        return True

    return False


def _walk_functions(
    tree: ast.AST,
    source: str,
    rel_path: str,
    results: list[dict],
    _lines: Optional[list[str]] = None,
) -> None:
    """Recursively walk AST collecting function definitions."""
    if _lines is None:
        _lines = source.splitlines()

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        # Tiers 4–6
        if _should_skip_function(node):
            continue

        name = node.name
        is_async = isinstance(node, ast.AsyncFunctionDef)

        # Docstring
        docstring = (ast.get_docstring(node) or "")[:500]

        # Return type
        return_type = ""
        if node.returns:
            try:
                return_type = ast.unparse(node.returns)
            except Exception:
                return_type = ""

        # Parameters — collect names, types, and defaults
        param_names: list[str] = []
        param_types: list[str] = []
        param_defaults: list[Optional[str]] = []

        args = node.args
        n_pos = len(args.args)
        n_defaults = len(args.defaults)
        default_offset = n_pos - n_defaults

        for i, arg in enumerate(args.args):
            param_names.append(arg.arg)
            if arg.annotation:
                try:
                    param_types.append(ast.unparse(arg.annotation))
                except Exception:
                    param_types.append("")
            else:
                param_types.append("")
            d_idx = i - default_offset
            if d_idx >= 0:
                try:
                    param_defaults.append(ast.unparse(args.defaults[d_idx]))
                except Exception:
                    param_defaults.append(None)
            else:
                param_defaults.append(None)

        # Signature string — includes default values for accuracy
        sig_parts: list[str] = []
        for n, t, d in zip(param_names, param_types, param_defaults):
            if n in ("self", "cls"):
                continue
            if t and d is not None:
                sig_parts.append(f"{n}: {t} = {d}")
            elif t:
                sig_parts.append(f"{n}: {t}")
            elif d is not None:
                sig_parts.append(f"{n} = {d}")
            else:
                sig_parts.append(n)
        params_str = ", ".join(sig_parts)
        ret_str = f" -> {return_type}" if return_type else ""
        async_prefix = "async " if is_async else ""
        signature = f"{async_prefix}def {name}({params_str}){ret_str}"

        # Endpoint type (fastapi/flask vs plain function/method)
        endpoint_type = _detect_endpoint_type(node)

        results.append(
            {
                "name": name,
                "file_path": rel_path,
                "signature": signature,
                "docstring": docstring,
                "return_type": return_type,
                "is_async": is_async,
                "line_number": node.lineno,
                "param_names": param_names,
                "param_types": param_types,
                "param_defaults": param_defaults,
                "endpoint_type": endpoint_type,
            }
        )


def _detect_endpoint_type(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Classify the function as fastapi, flask, method, or function."""
    has_self = any(a.arg in ("self", "cls") for a in node.args.args)

    for decorator in node.decorator_list:
        name = _decorator_name(decorator)
        if name in {"get", "post", "put", "delete", "patch", "api_route"}:
            return "fastapi"
        if name == "route":
            return "flask"

    return "method" if has_self else "function"


def _decorator_name(decorator: ast.expr) -> str:
    """Extract the simple name of a decorator."""
    if isinstance(decorator, ast.Name):
        return decorator.id
    if isinstance(decorator, ast.Attribute):
        return decorator.attr
    if isinstance(decorator, ast.Call):
        return _decorator_name(decorator.func)
    return ""
