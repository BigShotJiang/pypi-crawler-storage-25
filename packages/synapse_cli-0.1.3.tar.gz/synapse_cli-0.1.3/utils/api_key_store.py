"""API key encryption at rest using Fernet with a machine-derived key."""

import base64
import getpass
import hashlib
import platform
import socket
from typing import Tuple

from cryptography.fernet import Fernet

# Salt and iteration count for PBKDF2 (fixed so decryption works across runs)
_PBKDF2_SALT = b"synapse-salt-v1"
_PBKDF2_ITERATIONS = 100_000
_VERSION_TAG = "synapse-cli-v1"

# Process-local cache so PBKDF2 runs once per session
_cached_fernet: Tuple[bytes, Fernet] | None = None


def _derive_machine_key() -> bytes:
    """Derive a Fernet key from machine-specific data. Config is useless on another machine."""
    user = getpass.getuser()
    hostname = socket.gethostname()
    node = getattr(platform, "node", lambda: hostname)()
    seed = f"{user}@{hostname}:{node}:{_VERSION_TAG}"
    raw = hashlib.pbkdf2_hmac(
        "sha256",
        seed.encode("utf-8"),
        _PBKDF2_SALT,
        _PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(raw)


def _get_fernet() -> Fernet:
    """Return a Fernet instance, caching the derived key for the process lifetime."""
    global _cached_fernet
    if _cached_fernet is not None:
        return _cached_fernet[1]
    key = _derive_machine_key()
    f = Fernet(key)
    _cached_fernet = (key, f)
    return f


def encrypt_api_key(raw_key: str) -> Tuple[str, str]:
    """
    Encrypt a raw API key for storage.

    Returns:
        (prefix, encrypted_blob) where prefix is the first 5 characters for display only.
    """
    raw_key = (raw_key or "").strip()
    if not raw_key:
        raise ValueError("API key cannot be empty")
    prefix = raw_key[:5] if len(raw_key) >= 5 else raw_key
    f = _get_fernet()
    encrypted = f.encrypt(raw_key.encode("utf-8")).decode("ascii")
    return prefix, encrypted


def decrypt_api_key(encrypted: str) -> str:
    """
    Decrypt an API key blob.

    Raises ValueError with a clear user-facing message if the key cannot be
    decrypted — for example when the config was copied from another machine
    or the machine identity has changed.

    Returns:
        The original raw API key.
    """
    if not encrypted or not encrypted.strip():
        raise ValueError("Encrypted key is empty")
    f = _get_fernet()
    try:
        return f.decrypt(encrypted.encode("ascii")).decode("utf-8")
    except Exception:
        raise ValueError(
            "API key could not be decrypted on this machine.\n"
            "This usually means the config was created on a different machine or "
            "your machine identity has changed (e.g. hostname, username, or "
            "container environment).\n"
            "Run `synapse init` to re-enter your API key."
        )


def format_api_key_display(prefix: str) -> str:
    """Format key for safe display: first 5 chars + asterisks."""
    if not prefix:
        return "(not set)"
    return f"{prefix}{'*' * (max(0, 20 - len(prefix)))}"
