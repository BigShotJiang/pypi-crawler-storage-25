"""Endpoint detection for MCP tool candidates

This module analyzes Python codebases to identify functions that can be converted
to MCP (Model Context Protocol) tools. It classifies functions into two categories:
- "ready": Functions that can be directly converted to MCP tools
- "requires_wrapper": Functions that need client/connection setup code
"""

import ast
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple, Union

# =============================================================================
# Constants for Detection
# =============================================================================

# Parameter names that indicate a client/connection dependency
CLIENT_PARAM_NAMES: Set[str] = {
    "client",
    "conn",
    "connection",
    "session",
    "db",
    "database",
    "cursor",
    "transport",
    "http",
    "http_client",
    "api_client",
    "redis",
    "mongo",
    "es",
    "opensearch",
}

# Keywords in type hints that indicate a client/connection type
CLIENT_TYPE_KEYWORDS: Set[str] = {
    "client",
    "connection",
    "session",
    "transport",
    "pool",
    "cursor",
    "channel",
    "socket",
    "redis",
    "mongo",
    "opensearch",
    "elasticsearch",
    "sqlalchemy",
    "asyncpg",
    "aiohttp",
    "httpx",
}

# Mapping of type keywords to human-readable client names and env var prefixes
CLIENT_TYPE_MAPPINGS: Dict[str, Tuple[str, str, List[str]]] = {
    "opensearch": (
        "OpenSearch client",
        "opensearchpy",
        [
            "OPENSEARCH_HOST",
            "OPENSEARCH_PORT",
            "OPENSEARCH_USERNAME",
            "OPENSEARCH_PASSWORD",
        ],
    ),
    "elasticsearch": (
        "Elasticsearch client",
        "elasticsearch",
        ["ES_HOST", "ES_PORT", "ES_USERNAME", "ES_PASSWORD"],
    ),
    "redis": ("Redis client", "redis", ["REDIS_HOST", "REDIS_PORT", "REDIS_PASSWORD"]),
    "session": ("Database session", "sqlalchemy", ["DATABASE_URL"]),
    "sqlalchemy": ("Database session", "sqlalchemy", ["DATABASE_URL"]),
    "mongo": ("MongoDB client", "pymongo", ["MONGO_URI"]),
    "mongodb": ("MongoDB client", "pymongo", ["MONGO_URI"]),
    "asyncpg": (
        "PostgreSQL connection",
        "asyncpg",
        [
            "POSTGRES_HOST",
            "POSTGRES_PORT",
            "POSTGRES_USER",
            "POSTGRES_PASSWORD",
            "POSTGRES_DB",
        ],
    ),
    "aiohttp": ("HTTP client", "aiohttp", []),
    "httpx": ("HTTP client", "httpx", []),
    "requests": ("HTTP client", "requests", []),
}

# Test-related decorator names to skip
TEST_DECORATORS: Set[str] = {
    "pytest",
    "fixture",
    "mark",
    "parametrize",
    "unittest",
    "mock",
    "patch",
    "skip",
    "skipif",
    "xfail",
}

# Non-tool function names to skip — only lifecycle/test hooks.
# Note: generic verbs like create/update/delete/execute/send are intentionally
# NOT excluded here — they are common names for prime MCP tool candidates.
SKIP_FUNCTION_NAMES: Set[str] = {
    "main",
    "setup",
    "teardown",
    "configure",
    "init",
    "setUp",
    "tearDown",
    "setUpClass",
    "tearDownClass",
    "setUpModule",
    "tearDownModule",
}


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class ClientDependency:
    """Information about client/connection required by a function"""

    param_name: str  # e.g., "client", "conn", "session"
    param_type: str  # e.g., "OpenSearch", "Session", "Any"
    client_name: str  # Human-readable: "OpenSearch client", "Database session"
    library: str  # e.g., "opensearchpy", "sqlalchemy"
    env_vars: List[str]  # e.g., ["OPENSEARCH_HOST", "OPENSEARCH_PORT", ...]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "param_name": self.param_name,
            "param_type": self.param_type,
            "client_name": self.client_name,
            "library": self.library,
            "env_vars": self.env_vars,
        }


@dataclass
class EndpointCandidate:
    """Represents a function/endpoint that can become an MCP tool"""

    # Identity
    name: str
    file_path: str
    line_number: int
    signature: str
    docstring: str

    # HTTP endpoint info (for FastAPI/Flask routes)
    endpoint_type: str  # 'fastapi', 'flask', 'function', 'method'
    http_method: str  # GET, POST, etc. or 'N/A' for regular functions
    route_path: str  # '/api/users' or 'N/A' for regular functions

    # Function details
    is_async: bool
    parameters: List[str]
    return_type: str

    # Scoring
    confidence: float  # 0.0-1.0 how likely this is a good MCP tool candidate
    reason: str  # Technical reason (kept for backward compatibility)
    score: int = 0  # AI's 1-10 value score (for sorting; 0 when from AST-only)

    # NEW: Classification
    conversion_type: str = "ready"  # "ready" | "requires_wrapper" | "not_suitable"

    # NEW: Human-readable metadata
    subcategory: str = ""  # Derived from file path (e.g., "helpers", "api")
    human_title: str = ""  # e.g., "Bulk index documents"
    human_description: str = ""  # e.g., "Send multiple documents in batches"

    # NEW: Security flags
    security_concern: bool = (
        False  # Whether function exposes credentials/sensitive data
    )
    security_note: Optional[str] = None  # Security warning message if applicable

    # NEW: Client dependency info (only if requires_wrapper)
    client_dependency: Optional[ClientDependency] = None

    def display_label(self) -> str:
        """User-friendly display label for checkbox (backward compatible)"""
        if self.http_method != "N/A":
            return f"[{self.http_method}] {self.route_path} → {self.name}()"
        async_prefix = "async " if self.is_async else ""
        return f"{async_prefix}{self.name}() - {self.reason}"

    def display_line1(self) -> str:
        """First line: function_name() - Human Title"""
        return f"{self.name}() - {self.human_title}"

    def display_line2(self) -> str:
        """Second line: Human-readable description"""
        return self.human_description

    def display_line3(self, working_dir: str = "") -> str:
        """Third line: file path, confidence, and wrapper info"""
        # Get relative path
        if working_dir and self.file_path.startswith(working_dir):
            rel_path = os.path.relpath(self.file_path, working_dir)
        else:
            rel_path = os.path.basename(self.file_path)

        # Confidence display
        if self.confidence >= 0.7:
            conf_display = "⭐⭐⭐ Recommended"
        elif self.confidence >= 0.5:
            conf_display = "⭐⭐ Good candidate"
        else:
            conf_display = "⭐ May need refinement"

        base = f"📁 {rel_path}  •  {conf_display}"

        # Add wrapper info if needed
        if self.conversion_type == "requires_wrapper" and self.client_dependency:
            base += f"  •  🔗 Needs: {self.client_dependency.client_name}"

        return base

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        result = {
            "name": self.name,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "signature": self.signature,
            "docstring": self.docstring,
            "endpoint_type": self.endpoint_type,
            "http_method": self.http_method,
            "route_path": self.route_path,
            "is_async": self.is_async,
            "parameters": self.parameters,
            "return_type": self.return_type,
            "confidence": self.confidence,
            "reason": self.reason,
            "score": self.score,
            "conversion_type": self.conversion_type,
            "subcategory": self.subcategory,
            "human_title": self.human_title,
            "human_description": self.human_description,
        }
        if self.client_dependency:
            result["client_dependency"] = self.client_dependency.to_dict()
        return result


# =============================================================================
# Filtering Functions
# =============================================================================


def _should_skip_file(file_path: str) -> bool:
    """
    Check if a file should be skipped (test files, config files, etc.)

    Args:
        file_path: Full path to the Python file

    Returns:
        True if the file should be skipped
    """
    path_lower = file_path.lower()
    filename = os.path.basename(path_lower)

    # Skip test files by name pattern
    test_file_patterns = [
        "test_",
        "_test.py",
        "tests.py",
        "conftest.py",
        "fixtures.py",
        "test.py",
    ]
    if any(pattern in filename for pattern in test_file_patterns):
        return True

    # Skip files in test directories
    test_dir_patterns = [
        "/tests/",
        "/test/",
        "/_tests/",
        "/testing/",
        "/test_",
        "\\tests\\",
        "\\test\\",
        "\\_tests\\",
    ]
    if any(pattern in path_lower for pattern in test_dir_patterns):
        return True

    # Skip common non-source files
    skip_filenames = {"setup.py", "conftest.py", "noxfile.py", "__init__.py"}
    if filename in skip_filenames:
        return True

    # Skip internal implementation directories (library internals, not public API)
    # Normalize path separators to forward slashes for consistent matching
    normalized_path = path_lower.replace("\\", "/")

    internal_dir_patterns = [
        "/_async/",
        "/_sync/",  # Internal async/sync implementations
        "/client/",
        "/clients/",  # Client implementation details
        "/plugins/",
        "/plugin/",  # Plugin internals
        "/transport/",
        "/transports/",  # Transport layer internals
        "/connection/",
        "/connections/",  # Connection internals
        "/compat/",  # Compatibility internals
        "/serializer/",
        "/serializers/",  # Serialization internals
        "/exceptions/",  # Exception definitions
    ]
    if any(pattern in normalized_path for pattern in internal_dir_patterns):
        return True

    # Also skip files that start with underscore directory (internal modules)
    path_parts = normalized_path.split("/")
    for part in path_parts[:-1]:  # Check directories, not filename
        if part.startswith("_") and part not in ("__pycache__",):
            return True

    return False


def _should_skip_function(node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> bool:
    """
    Check if a function should be skipped (test functions, fixtures, etc.)

    Args:
        node: AST node representing the function

    Returns:
        True if the function should be skipped
    """
    name = node.name
    name_lower = name.lower()

    # Skip private/dunder methods
    if name.startswith("_"):
        return True

    # Skip test functions
    if name_lower.startswith("test") or name.startswith("Test"):
        return True

    # Skip common non-tool function names
    if name_lower in SKIP_FUNCTION_NAMES or name in SKIP_FUNCTION_NAMES:
        return True

    # Skip functions with test-related decorators
    for decorator in node.decorator_list:
        decorator_name = _get_decorator_name(decorator)
        if decorator_name and decorator_name.lower() in TEST_DECORATORS:
            return True

    return False


def _get_decorator_name(decorator: ast.expr) -> Optional[str]:
    """Extract the name of a decorator"""
    if isinstance(decorator, ast.Name):
        return decorator.id
    elif isinstance(decorator, ast.Attribute):
        return decorator.attr
    elif isinstance(decorator, ast.Call):
        if isinstance(decorator.func, ast.Name):
            return decorator.func.id
        elif isinstance(decorator.func, ast.Attribute):
            return decorator.func.attr
    return None


# =============================================================================
# Client Dependency Detection
# =============================================================================


def _detect_client_dependency(
    node: Union[ast.FunctionDef, ast.AsyncFunctionDef], file_path: str
) -> Optional[ClientDependency]:
    """
    Detect if a function requires a client/connection object.

    Args:
        node: AST node representing the function
        file_path: Path to the file containing the function

    Returns:
        ClientDependency object if dependency detected, None otherwise
    """
    # Check if function has arguments
    if not node.args.args:
        return None

    # Get first non-self/cls argument
    first_param = None
    for arg in node.args.args:
        if arg.arg not in ("self", "cls"):
            first_param = arg
            break

    if not first_param:
        return None

    param_name = first_param.arg
    param_type = ""

    # Get type annotation if available
    if first_param.annotation:
        try:
            param_type = ast.unparse(first_param.annotation)
        except Exception:
            param_type = "Any"

    # Check if parameter name indicates a client
    is_client_by_name = param_name.lower() in CLIENT_PARAM_NAMES

    # Check if type hint indicates a client
    is_client_by_type = False
    if param_type:
        type_lower = param_type.lower()
        is_client_by_type = any(kw in type_lower for kw in CLIENT_TYPE_KEYWORDS)

    if not (is_client_by_name or is_client_by_type):
        return None

    # Determine client type and metadata
    client_name, library, env_vars = _resolve_client_type(
        param_name, param_type, file_path
    )

    return ClientDependency(
        param_name=param_name,
        param_type=param_type or "Any",
        client_name=client_name,
        library=library,
        env_vars=env_vars,
    )


def _resolve_client_type(
    param_name: str, param_type: str, file_path: str
) -> Tuple[str, str, List[str]]:
    """
    Resolve the client type to get human-readable name, library, and env vars.

    Args:
        param_name: Name of the parameter
        param_type: Type annotation string
        file_path: Path to the file (for import analysis)

    Returns:
        Tuple of (client_name, library, env_vars)
    """
    # Check type hint first for more specific matches
    if param_type:
        type_lower = param_type.lower()
        for keyword, (name, lib, env_vars) in CLIENT_TYPE_MAPPINGS.items():
            if keyword in type_lower:
                return name, lib, env_vars

    # Check parameter name
    param_lower = param_name.lower()
    for keyword, (name, lib, env_vars) in CLIENT_TYPE_MAPPINGS.items():
        if keyword in param_lower:
            return name, lib, env_vars

    # Generic fallback based on common patterns
    if param_lower in {"client", "api_client", "http_client"}:
        return "API client", "unknown", []
    if param_lower in {"conn", "connection", "db", "database"}:
        return "Database connection", "unknown", ["DATABASE_URL"]
    if param_lower in {"session"}:
        return "Database session", "sqlalchemy", ["DATABASE_URL"]

    # Default fallback
    return "External client", "unknown", []


# =============================================================================
# Classification Logic
# =============================================================================


def _classify_function(
    node: Union[ast.FunctionDef, ast.AsyncFunctionDef],
    client_dependency: Optional[ClientDependency],
) -> str:
    """
    Classify a function as 'ready' or 'requires_wrapper'.

    Args:
        node: AST node representing the function
        client_dependency: Detected client dependency or None

    Returns:
        "ready" or "requires_wrapper"
    """
    # If we detected a client dependency, it requires a wrapper
    if client_dependency:
        return "requires_wrapper"

    # Class methods with 'self' ALWAYS require wrapper
    # You need to instantiate the class first before calling the method
    has_self = any(arg.arg == "self" for arg in node.args.args)
    if has_self:
        return "requires_wrapper"

    # Class methods with 'cls' also require wrapper (need class context)
    has_cls = any(arg.arg == "cls" for arg in node.args.args)
    if has_cls:
        return "requires_wrapper"

    # Check all parameters for complex types
    for arg in node.args.args:
        if arg.arg in ("self", "cls"):
            continue
        if arg.annotation:
            try:
                type_str = ast.unparse(arg.annotation).lower()
                # Skip primitives
                primitives = {
                    "str",
                    "int",
                    "float",
                    "bool",
                    "none",
                    "any",
                    "list",
                    "dict",
                    "set",
                    "tuple",
                    "optional",
                }
                if not any(p in type_str for p in primitives):
                    # Could be a complex type - check for client keywords
                    if any(kw in type_str for kw in CLIENT_TYPE_KEYWORDS):
                        return "requires_wrapper"
            except Exception:
                pass

    return "ready"


# =============================================================================
# Human-Readable Metadata Generation
# =============================================================================


def _generate_human_title(name: str, docstring: str) -> str:
    """
    Generate a human-readable title for the function.

    Args:
        name: Function name
        docstring: Function docstring

    Returns:
        Human-readable title
    """
    # Try to extract from docstring first
    if docstring:
        # Get first line
        first_line = docstring.split("\n")[0].strip()
        # Remove trailing period
        first_line = first_line.rstrip(".")
        # Check if it's a reasonable title (not too long, not too short)
        if 10 <= len(first_line) <= 60:
            # Check it doesn't look like code or technical jargon
            if not first_line.startswith(
                ("Args:", "Returns:", "Raises:", ":param", "@")
            ):
                return first_line

    # Humanize the function name
    # bulk_index_documents -> "Bulk index documents"
    # getUserData -> "Get user data"

    # Handle snake_case
    words = name.replace("_", " ").split()

    # Handle camelCase within words
    result = []
    for word in words:
        # Split camelCase: getUserData -> get User Data
        humanized = re.sub(r"([a-z])([A-Z])", r"\1 \2", word)
        result.append(humanized)

    title = " ".join(result)
    return title.capitalize()


def _generate_human_description(docstring: str, name: str, signature: str) -> str:
    """
    Generate a human-readable description for the function.

    Args:
        docstring: Function docstring
        name: Function name
        signature: Function signature

    Returns:
        Human-readable description
    """
    if docstring:
        # Extract first 1-2 sentences
        lines = docstring.split("\n")
        description_lines = []

        for line in lines:
            line = line.strip()
            # Stop at Args:, Returns:, etc.
            if line.startswith(("Args:", "Returns:", "Raises:", ":param", "@", "---")):
                break
            if line:
                description_lines.append(line)
            # Get first 2 non-empty lines max
            if len(description_lines) >= 2:
                break

        if description_lines:
            description = " ".join(description_lines)
            # Truncate if too long
            if len(description) > 150:
                description = description[:147] + "..."
            return description

    # Generate from function name if no docstring
    title = _generate_human_title(name, "")
    return f"Performs {title.lower()} operation"


# =============================================================================
# Subcategory Derivation
# =============================================================================


def _derive_subcategory(file_path: str, working_dir: str) -> str:
    """
    Derive a subcategory from the file path.

    Args:
        file_path: Full path to the file
        working_dir: Working directory root

    Returns:
        Subcategory string (e.g., "helpers", "api", "utils")
    """
    # Get relative path
    try:
        rel_path = os.path.relpath(file_path, working_dir)
    except ValueError:
        rel_path = file_path

    # Get directory component
    dir_path = os.path.dirname(rel_path)

    if not dir_path or dir_path == ".":
        return "root"

    # Split path into parts
    parts = dir_path.replace("\\", "/").split("/")

    # Filter out common prefixes
    skip_prefixes = {"src", "lib", "app", "pkg", "packages", "modules"}
    filtered_parts = []
    skip_next = False

    for part in parts:
        if skip_next:
            skip_next = False
            continue
        if part.lower() in skip_prefixes:
            continue
        if part.startswith(".") or part.startswith("_"):
            continue
        filtered_parts.append(part)

    if not filtered_parts:
        return parts[0] if parts else "root"

    # Return first 1-2 meaningful parts
    return "/".join(filtered_parts[:2])


# =============================================================================
# Main Detection Functions
# =============================================================================


def detect_endpoints(working_dir: str) -> List[EndpointCandidate]:
    """
    Scans codebase for API endpoints and function candidates for MCP tools.

    Classifies each function into:
    - "ready": Can be directly converted to MCP tools
    - "requires_wrapper": Needs client/connection setup code

    Detects:
    - FastAPI routes (@app.get, @router.post, etc.)
    - Flask routes (@app.route, @blueprint.route)
    - Service layer functions (functions with docstrings, typed params)
    - Async functions with meaningful operations

    Filters out:
    - Test functions and test files
    - Private/dunder methods
    - Common non-tool functions (main, setup, etc.)

    Args:
        working_dir: Root project directory

    Returns:
        List of EndpointCandidate objects sorted by confidence
    """
    candidates = []

    # Directories to ignore
    ignore_dirs = {
        "__pycache__",
        ".git",
        ".synapse",
        "node_modules",
        "venv",
        "env",
        ".venv",
        "dist",
        "build",
        ".egg-info",
        ".pytest_cache",
        ".mypy_cache",
        ".tox",
        "tests",
        "test",
        "_tests",
        "testing",
        "benchmarks",
        "examples",
        "docs",
    }

    # Walk through Python files
    for root, dirs, files in os.walk(working_dir):
        # Filter out ignored directories
        dirs[:] = [d for d in dirs if d not in ignore_dirs and not d.startswith(".")]

        for file in files:
            if not file.endswith(".py"):
                continue

            file_path = os.path.join(root, file)

            # Skip test files
            if _should_skip_file(file_path):
                continue

            # Analyze file for candidates
            file_candidates = _analyze_file(file_path, working_dir)
            candidates.extend(file_candidates)

    # Sort by confidence score (highest first)
    candidates.sort(key=lambda x: x.confidence, reverse=True)

    # Limit to top 20 candidates to avoid overwhelming the user
    return candidates[:20]


def _analyze_file(file_path: str, working_dir: str) -> List[EndpointCandidate]:
    """
    Analyze a single Python file for endpoint candidates.

    Args:
        file_path: Path to the Python file
        working_dir: Root working directory

    Returns:
        List of EndpointCandidate objects found in the file
    """
    candidates = []

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        tree = ast.parse(content, filename=file_path)
    except (SyntaxError, UnicodeDecodeError, IOError):
        return candidates

    # Get all lines for decorator analysis
    lines = content.split("\n")

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            candidate = _analyze_function(node, file_path, lines, working_dir)
            if candidate:
                candidates.append(candidate)

    return candidates


def _analyze_function(
    node: Union[ast.FunctionDef, ast.AsyncFunctionDef],
    file_path: str,
    lines: List[str],
    working_dir: str,
) -> Optional[EndpointCandidate]:
    """
    Analyze a single function for MCP tool potential.

    Args:
        node: AST node representing the function
        file_path: Path to the file containing the function
        lines: All lines of the file (for decorator analysis)
        working_dir: Root working directory

    Returns:
        EndpointCandidate object or None if function should be skipped
    """
    # Apply function filters
    if _should_skip_function(node):
        return None

    # Get docstring
    docstring = ast.get_docstring(node) or ""

    # Detect HTTP endpoint from decorators
    endpoint_type, http_method, route_path = _detect_http_endpoint(node, lines)

    # Detect client dependency
    client_dependency = _detect_client_dependency(node, file_path)

    # Classify function
    conversion_type = _classify_function(node, client_dependency)

    # Calculate confidence score
    confidence, reason = _calculate_confidence(
        node, docstring, endpoint_type, client_dependency
    )

    # Skip low-confidence candidates
    if confidence < 0.35:
        return None

    # Extract parameters (skip 'self', 'cls', 'request', etc.)
    skip_params = {"self", "cls", "request", "req"}
    params = [arg.arg for arg in node.args.args if arg.arg not in skip_params]

    # Get return type
    return_type = ast.unparse(node.returns) if node.returns else "Any"

    # Build signature
    signature = _build_signature(node)

    # Generate human-readable metadata
    human_title = _generate_human_title(node.name, docstring)
    human_description = _generate_human_description(docstring, node.name, signature)
    subcategory = _derive_subcategory(file_path, working_dir)

    return EndpointCandidate(
        name=node.name,
        file_path=file_path,
        line_number=node.lineno,
        signature=signature,
        docstring=docstring[:150] + "..." if len(docstring) > 150 else docstring,
        endpoint_type=endpoint_type,
        http_method=http_method,
        route_path=route_path,
        is_async=isinstance(node, ast.AsyncFunctionDef),
        parameters=params,
        return_type=return_type,
        confidence=confidence,
        reason=reason,
        conversion_type=conversion_type,
        subcategory=subcategory,
        human_title=human_title,
        human_description=human_description,
        client_dependency=client_dependency,
    )


def _detect_http_endpoint(
    node: Union[ast.FunctionDef, ast.AsyncFunctionDef], lines: List[str]
) -> Tuple[str, str, str]:
    """
    Detect if function is an HTTP endpoint from decorators.

    Args:
        node: AST node representing the function
        lines: All lines of the file

    Returns:
        Tuple of (endpoint_type, http_method, route_path)
    """
    endpoint_type = "function"
    http_method = "N/A"
    route_path = "N/A"

    for decorator in node.decorator_list:
        decorator_str = ""

        # Get decorator as string
        if isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Attribute):
                decorator_str = decorator.func.attr.lower()
                # Extract route path from first argument
                if decorator.args:
                    try:
                        route_path = ast.literal_eval(decorator.args[0])
                    except Exception:
                        try:
                            route_path = ast.unparse(decorator.args[0])
                        except Exception:
                            route_path = "N/A"
            elif isinstance(decorator.func, ast.Name):
                decorator_str = decorator.func.id.lower()
        elif isinstance(decorator, ast.Attribute):
            decorator_str = decorator.attr.lower()
        elif isinstance(decorator, ast.Name):
            decorator_str = decorator.id.lower()

        # Check for FastAPI patterns
        if decorator_str in {"get", "post", "put", "delete", "patch", "api_route"}:
            endpoint_type = "fastapi"
            http_method = decorator_str.upper()
            if http_method == "API_ROUTE":
                http_method = "ANY"
            break

        # Check for Flask patterns
        if decorator_str == "route":
            endpoint_type = "flask"
            http_method = "ANY"
            break

    return endpoint_type, http_method, route_path


def _calculate_confidence(
    node: Union[ast.FunctionDef, ast.AsyncFunctionDef],
    docstring: str,
    endpoint_type: str,
    client_dependency: Optional[ClientDependency],
) -> Tuple[float, str]:
    """
    Calculate confidence score for MCP tool candidacy.

    Args:
        node: AST node representing the function
        docstring: Function docstring
        endpoint_type: Type of endpoint (fastapi, flask, function)
        client_dependency: Detected client dependency or None

    Returns:
        Tuple of (confidence_score, reason_string)
    """
    score = 0.0
    reasons = []

    # HTTP endpoint = high confidence
    if endpoint_type in ("fastapi", "flask"):
        score += 0.5
        reasons.append("API endpoint")

    # Has meaningful docstring = good candidate
    if docstring and len(docstring) > 20:
        score += 0.25
        reasons.append("Documented")

    # Has return type = better for MCP tools
    if node.returns:
        score += 0.1
        reasons.append("Typed return")

    # Has typed parameters
    typed_params = sum(
        1 for arg in node.args.args if arg.annotation and arg.arg not in ("self", "cls")
    )
    if typed_params > 0:
        score += 0.1
        reasons.append("Typed params")

    # Async function = often a good candidate for tools
    if isinstance(node, ast.AsyncFunctionDef):
        score += 0.1
        reasons.append("Async")

    # Function name suggests an action (verb-based names)
    action_prefixes = (
        "get",
        "fetch",
        "create",
        "update",
        "delete",
        "find",
        "search",
        "list",
        "read",
        "write",
        "process",
        "generate",
        "compute",
        "calculate",
        "send",
        "receive",
        "load",
        "save",
        "bulk",
        "scan",
        "reindex",
        "query",
        "execute",
        "run",
        "parse",
        "validate",
        "convert",
        "transform",
        "export",
        "import",
    )
    if any(node.name.lower().startswith(prefix) for prefix in action_prefixes):
        score += 0.15
        reasons.append("Action verb")

    # Client dependency - still valuable but needs wrapper
    if client_dependency:
        # Don't penalize, but note it
        if "Action verb" not in reasons:
            score += 0.05  # Small boost for being a real operation

    reason = ", ".join(reasons) if reasons else "Basic function"
    return min(score, 1.0), reason


def _build_signature(node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> str:
    """
    Build a clean function signature string.

    Args:
        node: AST node representing the function

    Returns:
        Signature string like "def func_name(param1: type, param2: type) -> return_type"
    """
    params = []
    for arg in node.args.args:
        if arg.arg in ("self", "cls"):
            continue
        param_str = arg.arg
        if arg.annotation:
            try:
                param_str += f": {ast.unparse(arg.annotation)}"
            except Exception:
                pass
        params.append(param_str)

    params_str = ", ".join(params)
    return_str = ""
    if node.returns:
        try:
            return_str = f" -> {ast.unparse(node.returns)}"
        except Exception:
            pass

    async_prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""

    return f"{async_prefix}def {node.name}({params_str}){return_str}"
