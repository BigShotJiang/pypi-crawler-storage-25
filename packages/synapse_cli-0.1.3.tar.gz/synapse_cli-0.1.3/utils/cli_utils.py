"""CLI interaction helper functions for Synapse"""

import getpass
import shutil
import sys
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

# Try to import questionary for interactive checkbox UI
try:
    import questionary
    from questionary import Style

    HAS_QUESTIONARY = True
except ImportError:
    HAS_QUESTIONARY = False
    questionary = None
    Style = None

# Try to import prompt_toolkit for styled input with placeholder
try:
    from prompt_toolkit import prompt as pt_prompt
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.styles import Style as PTStyle

    HAS_PROMPT_TOOLKIT = True
except ImportError:
    HAS_PROMPT_TOOLKIT = False

# ANSI color codes for banner
ORANGE = "\033[38;5;208m"
BLUE = "\033[94m"
WHITE = "\033[97m"
RESET = "\033[0m"

# Try to import Rich for beautiful terminal UI
try:
    from rich.box import DOUBLE, ROUNDED
    from rich.console import Console
    from rich.panel import Panel
    from rich.rule import Rule
    from rich.table import Table
    from rich.text import Text
    from rich.theme import Theme

    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    Console = None
    Panel = None
    Table = None
    Text = None
    Rule = None

# =============================================================================
# Sunset Harmony Theme for Rich
# =============================================================================

if HAS_RICH:
    SUNSET_THEME = Theme(
        {
            "sunset.border": "color(94)",  # Brown/Dark Orange
            "sunset.title": "bold color(214)",  # Bright Orange
            "sunset.subtitle": "color(208)",  # Orange
            "sunset.content": "color(230)",  # Cream/Light Yellow
            "sunset.highlight": "bold color(220)",  # Gold
            "sunset.muted": "color(180)",  # Tan
            "sunset.success": "bold color(70)",  # Green
            "sunset.warning": "color(214)",  # Orange
            "sunset.ready": "bold color(70)",  # Green for ready
            "sunset.wrapper": "bold color(214)",  # Orange for wrapper
            "sunset.file_path": "italic color(180)",  # Muted tan for paths
            # Colored Star Ranking (single star, color indicates confidence)
            "sunset.star_high": "bold color(220)",  # Gold - High confidence (0.7+)
            "sunset.star_medium": "color(214)",  # Orange - Medium confidence (0.5-0.7)
            "sunset.star_low": "color(180)",  # Tan/Muted - Lower confidence (0.35-0.5)
        }
    )

    # Console instance with Sunset theme
    sunset_console = Console(theme=SUNSET_THEME)
else:
    SUNSET_THEME = None
    sunset_console = None

# Maximum endpoints to display per category (top N by confidence)
MAX_ENDPOINTS_PER_CATEGORY = 50


def display_banner() -> None:
    """Display the SYNAPS3 ASCII art banner with the 3 in blue."""
    banner = f"""
{WHITE}███████╗██╗   ██╗███╗   ██╗ █████╗ ██████╗ ███████╗{BLUE}██████╗
{WHITE}██╔════╝╚██╗ ██╔╝████╗  ██║██╔══██╗██╔══██╗██╔════╝{BLUE}╚════██╗
{WHITE}███████╗ ╚████╔╝ ██╔██╗ ██║███████║██████╔╝███████╗{BLUE} █████╔╝
{WHITE}╚════██║  ╚██╔╝  ██║╚██╗██║██╔══██║██╔═══╝ ╚════██║{BLUE} ╚═══██╗
{WHITE}███████║   ██║   ██║ ╚████║██║  ██║██║     ███████║{BLUE}██████╔╝
{WHITE}╚══════╝   ╚═╝   ╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝     ╚══════╝{BLUE}╚═════╝ {RESET}
"""
    print(banner)


def display_numbered_list(items: List[str], title: str = "") -> None:
    """
    Displays a numbered selection menu

    Args:
        items: List of items to display
        title: Optional title for the list
    """
    if title:
        print(f"\n{title}")
    for idx, item in enumerate(items, 1):
        print(f"  {idx}. {item}")


def get_user_selection(options: List[str], prompt: str = "Your choice: ") -> int:
    """
    Gets validated user input from numbered list

    Args:
        options: List of options to choose from
        prompt: Prompt message to display

    Returns:
        Zero-based index of selected option
    """
    while True:
        try:
            choice = input(f"\n{prompt}")
            choice_idx = int(choice) - 1

            if 0 <= choice_idx < len(options):
                return choice_idx
            else:
                print(
                    f"❌ Invalid choice. Please enter a number between 1 and {len(options)}"
                )
        except ValueError:
            print("❌ Invalid input. Please enter a number")
        except KeyboardInterrupt:
            print("\n\n❌ Operation cancelled by user")
            exit(0)


def prompt_for_input(
    prompt: str,
    validator: Optional[Callable[[str], tuple[bool, str]]] = None,
    mask: bool = False,
) -> str:
    """
    Prompts for user input with optional validation and masking

    Args:
        prompt: Prompt message to display
        validator: Optional validation function that returns (is_valid, error_message)
        mask: Whether to mask input (for passwords/API keys)

    Returns:
        User input string
    """
    while True:
        try:
            if mask:
                user_input = getpass.getpass(f"\n{prompt}")
            else:
                user_input = input(f"\n{prompt}")

            # Validate input
            if validator:
                is_valid, error_msg = validator(user_input)
                if not is_valid:
                    print(f"❌ {error_msg}")
                    continue

            return user_input

        except KeyboardInterrupt:
            print("\n\n❌ Operation cancelled by user")
            exit(0)


# Sunset Harmony color palette for styled input
SUNSET_PROMPT = "\033[38;5;230m"  # Cream for prompt text
RESET_COLOR = "\033[0m"

# prompt_toolkit style for Sunset Harmony theme
PT_SUNSET_STYLE = None
if HAS_PROMPT_TOOLKIT:
    PT_SUNSET_STYLE = PTStyle.from_dict(
        {
            "": "#ffffff",  # Default white text
            "prompt": "#d7af00 bold",  # Orange arrow
        }
    )


def prompt_styled_input(
    prompt_text: str,
    placeholder: str = "Share your thoughts",
    validator: Optional[Callable[[str], tuple[bool, str]]] = None,
    allow_empty: bool = True,
) -> str:
    """
    Simple styled input prompt with Sunset Harmony colors.

    Features:
    - 💭 Thought bubble emoji before prompt
    - » Double angle arrow as input marker (bright orange)
    - Faded grey placeholder text

    Args:
        prompt_text: The prompt message to display
        placeholder: Placeholder text shown in faded grey
        validator: Optional validation function
        allow_empty: Whether empty input is allowed

    Returns:
        User input string
    """
    while True:
        try:
            # Print the prompt with thought bubble emoji (no indentation to align with Examples:)
            print(f"\n{SUNSET_PROMPT}💭 {prompt_text}{RESET_COLOR}")
            print()

            if HAS_PROMPT_TOOLKIT and PT_SUNSET_STYLE:
                # Use prompt_toolkit for styled input with placeholder
                user_input = _simple_prompt(placeholder)

                # Handle Ctrl+C (returns None)
                if user_input is None:
                    print("\n❌ Operation cancelled by user")
                    exit(0)
            else:
                # Fallback to basic input
                user_input = input("» ")

            # Validate if validator provided
            if validator:
                is_valid, error_msg = validator(user_input)
                if not is_valid:
                    print(f"  ❌ {error_msg}")
                    continue

            # Check if empty input is allowed
            if not allow_empty and not user_input.strip():
                print("  ❌ Input cannot be empty")
                continue

            return user_input

        except KeyboardInterrupt:
            print("\n❌ Operation cancelled by user")
            exit(0)


def _simple_prompt(placeholder: str = "Share your thoughts") -> Optional[str]:
    """
    Simple prompt using prompt_toolkit with styled double angle arrow and placeholder.

    Returns the user input or None if cancelled.
    """
    if not HAS_PROMPT_TOOLKIT:
        return input("» ")

    try:
        # Use prompt_toolkit's prompt() with simple styling
        # » = Double Right-Pointing Angle in bright orange (no indentation to align with Examples:)
        result = pt_prompt(
            [("class:prompt", "» ")],
            style=PT_SUNSET_STYLE,
            placeholder=HTML(f'<style fg="#555555">{placeholder}</style>'),
        )

        return result

    except KeyboardInterrupt:
        return None
    except EOFError:
        return ""
    except Exception:
        return input("» ")


def display_welcome_message(commands: Dict[str, str]) -> str:
    """Shows formatted welcome message with command list."""
    if HAS_RICH and sunset_console:
        content = Text()
        content.append("🎉  Welcome to Synapse!\n\n", style="bold color(214)")
        content.append("Available Commands\n\n", style="bold color(220)")
        for cmd, desc in commands.items():
            content.append(f"  {cmd:<26}", style="bold color(39)")
            content.append(f"{desc}\n", style="color(230)")
        content.append("\nGet started: ", style="color(180)")
        content.append("synapse analyze", style="bold color(220)")
        sunset_console.print()
        sunset_console.print(
            Panel(
                content,
                border_style="sunset.border",
                padding=(1, 2),
                box=ROUNDED,
                expand=False,
            )
        )
        sunset_console.print()
    else:
        message = "\n🎉 Welcome to Synapse!\n\nAvailable Commands:\n"
        for cmd, desc in commands.items():
            message += f"  {cmd:<26}{desc}\n"
        message += "\nGet started: synapse analyze\n"
        print(message)
    return ""


def display_success_box(message: str, details: Optional[str] = None) -> str:
    """Shows success message in a content-sized Rich panel."""
    if HAS_RICH and sunset_console:
        content = Text()
        content.append(f"✅  {message}", style="bold color(70)")
        if details:
            content.append(f"\n\n{details}", style="color(230)")
        sunset_console.print()
        sunset_console.print(
            Panel(
                content,
                border_style="color(70)",
                padding=(0, 2),
                box=ROUNDED,
                expand=False,
            )
        )
        sunset_console.print()
    else:
        output = f"\n✅ {message}\n"
        if details:
            output += f"\n{details}\n"
        print(output)
    return ""


def display_error_box(message: str, details: Optional[str] = None) -> str:
    """Shows error message in a content-sized Rich panel."""
    if HAS_RICH and sunset_console:
        content = Text()
        content.append(f"❌  {message}", style="bold color(196)")
        if details:
            content.append(f"\n\n{details}", style="color(230)")
        sunset_console.print()
        sunset_console.print(
            Panel(
                content,
                border_style="color(196)",
                padding=(0, 2),
                box=ROUNDED,
                expand=False,
            )
        )
        sunset_console.print()
    else:
        output = f"\n❌ {message}\n"
        if details:
            output += f"\n{details}\n"
        print(output)
    return ""


def display_header(title: str, icon: str = "🚀") -> None:
    """Displays a compact content-sized header (no full-width rule)."""
    if HAS_RICH and sunset_console:
        label = f"  {icon}  {title}"
        # Underline exactly as wide as the label text (strip emoji width approx)
        underline = "  " + "─" * (len(title) + 6)
        sunset_console.print()
        sunset_console.print(Text(label, style="bold color(220)"))
        sunset_console.print(Text(underline, style="color(94)"))
    else:
        print(f"\n{icon} {title}")
        print("─" * (len(title) + 4))


def _format_elapsed(seconds: float) -> str:
    """Format elapsed seconds as a human-readable timer string.

    Examples: 5s, 45s, 1m 3s, 2m 30s
    """
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    return f"{m}m {s}s"


class ProgressIndicator:
    """
    Animated progress indicator for CLI operations.

    Supports two animation styles:
    - "ellipsis": Simple dots animation (default)
    - "orbital": Rotating arcs in white + red

    Usage:
        progress = ProgressIndicator()
        progress.start("Planning")
        # ... do work ...
        progress.complete("Planning completed")

        progress.start("Generating code", style="orbital")
        # ... do work ...
        progress.complete("Code generation completed")
    """

    # ANSI color codes
    RED = "\033[91m"
    WHITE = "\033[97m"
    RESET = "\033[0m"

    # Animation styles
    STYLE_ELLIPSIS = "ellipsis"
    STYLE_ORBITAL = "orbital"

    def __init__(self):
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._current_message = ""
        self._current_style = self.STYLE_ELLIPSIS
        self._lock = threading.Lock()
        self._start_time: Optional[float] = None
        self._show_timer: bool = False

    def _animate(self):
        """Animation loop that runs in a separate thread."""
        # Orbital atom frames: two elliptical orbitals crossing perpendicular
        # White orbital + Red orbital rotating in opposite directions
        # No center dot - just the two interlocking ellipse curves
        orbital_frames = [
            f"{self.WHITE}╭{self.RED}╯{self.RESET}",  # ╭╯
            f"{self.WHITE}╮{self.RED}╰{self.RESET}",  # ╮╰
            f"{self.WHITE}╯{self.RED}╭{self.RESET}",  # ╯╭
            f"{self.WHITE}╰{self.RED}╮{self.RESET}",  # ╰╮
        ]
        ellipsis_frames = ["", ".", "..", "..."]
        frame_idx = 0

        while not self._stop_event.is_set():
            with self._lock:
                message = self._current_message
                style = self._current_style
                show_timer = self._show_timer
                start_time = self._start_time

            timer_str = ""
            if show_timer and start_time is not None:
                timer_str = "  " + _format_elapsed(time.time() - start_time)

            if style == self.STYLE_ORBITAL:
                frame = orbital_frames[frame_idx % len(orbital_frames)]
                sys.stdout.write(f"\r  {frame} {message}{timer_str}   ")
                sleep_time = 0.12  # Fast for smooth orbital rotation
            else:
                frame = ellipsis_frames[frame_idx % len(ellipsis_frames)]
                sys.stdout.write(f"\r  ⏳ {message}{frame}{timer_str}   ")
                sleep_time = 0.4  # Slower for ellipsis

            sys.stdout.flush()
            frame_idx += 1
            time.sleep(sleep_time)

    def start(self, message: str, style: str = "ellipsis", show_timer: bool = False):
        """
        Start showing an animated progress indicator.

        Args:
            message: The progress message (e.g., "Planning")
            style: Animation style - "ellipsis" (default) or "orbital"
            show_timer: If True, show a live elapsed-time counter on the same line.
                        The timer starts on the first call with show_timer=True and
                        persists across subsequent start() calls (so it reflects total
                        elapsed time for a multi-stage operation).
        """
        # Stop any existing animation
        self.stop()

        with self._lock:
            self._current_message = message
            self._current_style = style
            if show_timer:
                self._show_timer = True
                # Start the clock only once; keep it running across stage changes.
                if self._start_time is None:
                    self._start_time = time.time()

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._animate, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop the animation without showing completion."""
        if self._thread is not None and self._thread.is_alive():
            self._stop_event.set()
            self._thread.join(timeout=1.0)
            self._thread = None
            # Clear the line
            sys.stdout.write("\r" + " " * 80 + "\r")
            sys.stdout.flush()

    def complete(self, message: str):
        """
        Stop the animation and show completion message with checkmark.
        If a timer is running, the final elapsed time is appended.

        Args:
            message: The completion message (e.g., "Planning completed")
        """
        # Capture elapsed before stop() clears the line
        timer_str = ""
        with self._lock:
            if self._show_timer and self._start_time is not None:
                timer_str = "  " + _format_elapsed(time.time() - self._start_time)
        self.stop()
        print(f"  \033[92m✓\033[0m  {message}{timer_str}")

    def reset_timer(self):
        """Reset the elapsed timer (call after the full operation is done)."""
        with self._lock:
            self._start_time = None
            self._show_timer = False

    def fail(self, message: str):
        """
        Stop the animation and show failure message with X.

        Args:
            message: The failure message
        """
        self.stop()
        print(f"  {self.RED}✖{self.RESET} {message}")

    def update(self, message: str):
        """
        Update the current progress message without stopping animation.

        Args:
            message: New progress message
        """
        with self._lock:
            self._current_message = message


class CodeGenerationUI:
    """
    Animated UI for the code generation phase.

    Displays:
    - Animated orbital "Generating code" status line
    - Neon Info Box with "⚡ PRO TIP" and rotating tips (Sunset color palette)
    - Typewriter animation for each tip

    Usage:
        ui = CodeGenerationUI()
        ui.start()
        # ... code generation happens ...
        ui.complete()
    """

    # ANSI codes
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    WHITE = "\033[97m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_MAGENTA = "\033[95m"

    # Sunset color palette for Pro Tip box
    SUNSET_BORDER = "\033[38;5;94m"  # Brown/Dark Orange for borders
    SUNSET_TITLE = "\033[38;5;214m"  # Bright Orange for title
    SUNSET_CONTENT = "\033[38;5;230m"  # Cream/Light Yellow for content

    # Cursor control
    HIDE_CURSOR = "\033[?25l"
    SHOW_CURSOR = "\033[?25h"
    CLEAR_LINE = "\033[K"

    # Box width bounds (actual width is determined at runtime from terminal size)
    BOX_WIDTH_MAX = 100
    BOX_WIDTH_MIN = 50

    # Did you know tips (15 tips about MCP - supports multi-line wrapping)
    TIPS = [
        "Build your MCP server once and it works with any AI app. No need to rebuild the same thing over and over for different platforms.",
        "One standard connection for everything. Instead of custom cables for each device, MCP gives AI one universal way to plug into your tools.",
        "Your AI doesn't load every tool upfront. It grabs only what it needs, exactly when needed—saves money and runs faster.",
        "Python, JavaScript, Go, Rust—use whatever language your team already knows. MCP works with all of them.",
        "MCP servers keep your sensitive data behind your firewall. You control who sees what, with built-in security and permissions.",
        "When you add new features, your AI knows immediately. No restarts or manual updates needed—it just works.",
        "What used to take weeks now takes hours. Companies report finishing projects 40-70% faster with MCP servers.",
        "Switch between ChatGPT, Claude, or any AI without rebuilding. Your server works with all of them—you're never stuck.",
        "Best servers do one thing really well. A weather server does weather. A database server does databases. Simple beats complicated.",
        "Package your server once in Docker, run it anywhere—Mac, Windows, cloud. No more setup headaches.",
        "16,000+ ready-to-use servers for Gmail, Slack, GitHub, Google Drive, and more. Don't rebuild what's already there.",
        "28% of Fortune 500 companies now use MCP servers. In finance, it's 45%. This isn't experimental—it's becoming the standard.",
        "Your AI keeps context across conversations. It remembers your projects, preferences, and history—like talking to someone who actually knows you.",
        "MCP makes AI respond 40-60% faster by cutting out unnecessary steps. Your users notice the speed difference.",
        "Building MCP servers is the fastest way for enterprises to adopt AI and still leverage their existing software assets",
    ]

    def __init__(self):
        self._stop_event = threading.Event()
        self._initialized = threading.Event()
        self._animation_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._stdout_lock = threading.Lock()
        self._current_tip_index = 0
        self._current_tip_char_index = 0
        self._tip_display_complete = False
        self._tip_pause_counter = 0
        self._total_lines = 0
        self._start_time: Optional[float] = None

        # Compute box width from terminal size to prevent line wrapping
        cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        self.box_width = min(self.BOX_WIDTH_MAX, max(self.BOX_WIDTH_MIN, cols - 2))

    def _get_orbital_frame(self, frame_idx: int) -> str:
        """Get the orbital animation frame."""
        frames = [
            f"{self.WHITE}╭{self.RED}╯{self.RESET}",
            f"{self.WHITE}╮{self.RED}╰{self.RESET}",
            f"{self.WHITE}╯{self.RED}╭{self.RESET}",
            f"{self.WHITE}╰{self.RED}╮{self.RESET}",
        ]
        return frames[frame_idx % len(frames)]

    def _display_width(self, text: str) -> int:
        """Calculate the display width of text, accounting for wide characters like emojis."""
        width = 0
        for char in text:
            # Emojis and other wide characters (most are >= 0x1F300)
            if ord(char) >= 0x1F300 or ord(char) >= 0x2600:
                width += 2
            else:
                width += 1
        return width

    def _wrap_text(self, text: str, max_width: int) -> list:
        """Wrap text into multiple lines that fit within max_width (by display width)."""
        words = text.split(" ")
        lines = []
        current_line = ""
        current_width = 0

        for word in words:
            word_width = self._display_width(word)
            if not current_line:
                current_line = word
                current_width = word_width
            elif current_width + 1 + word_width <= max_width:
                current_line += " " + word
                current_width += 1 + word_width
            else:
                lines.append(current_line)
                current_line = word
                current_width = word_width

        if current_line:
            lines.append(current_line)

        return lines

    def _render_box(self, tip_text: str) -> list:
        """Render the PRO TIP box with current tip text (Neon Info Box + Sunset palette)."""
        lines = []
        inner_width = self.box_width - 2  # Account for ║ on each side
        tip_left_padding = 3  # Left/right padding for tip text
        max_tip_width = inner_width - (tip_left_padding * 2)

        # Top border - double line with Sunset brown/orange
        lines.append(f"{self.SUNSET_BORDER}╔{'═' * inner_width}╗{self.RESET}")

        # Empty line
        lines.append(
            f"{self.SUNSET_BORDER}║{self.RESET}{' ' * inner_width}{self.SUNSET_BORDER}║{self.RESET}"
        )

        # ⚡ PRO TIP centered - bright orange title
        title_text = f"{self.BOLD}{self.SUNSET_TITLE}⚡ PRO TIP{self.RESET}"
        title_plain = "⚡ PRO TIP"
        title_width = self._display_width(title_plain)
        left_padding = (inner_width - title_width) // 2
        right_padding = inner_width - left_padding - title_width
        lines.append(
            f"{self.SUNSET_BORDER}║{self.RESET}{' ' * left_padding}{title_text}{' ' * right_padding}{self.SUNSET_BORDER}║{self.RESET}"
        )

        # Empty line
        lines.append(
            f"{self.SUNSET_BORDER}║{self.RESET}{' ' * inner_width}{self.SUNSET_BORDER}║{self.RESET}"
        )

        # Wrap the tip text into multiple lines
        wrapped_lines = self._wrap_text(tip_text, max_tip_width)

        # Ensure we have exactly 2 lines for tips (pad with empty if needed)
        while len(wrapped_lines) < 2:
            wrapped_lines.append("")

        # Render each wrapped line (max 2 lines) - cream/light yellow content
        for wrapped_line in wrapped_lines[:2]:
            tip_display_width = self._display_width(wrapped_line)
            tip_right_padding = inner_width - tip_left_padding - tip_display_width
            if tip_right_padding < 0:
                tip_right_padding = 0
            lines.append(
                f"{self.SUNSET_BORDER}║{self.RESET}{' ' * tip_left_padding}{self.SUNSET_CONTENT}{wrapped_line}{self.RESET}{' ' * tip_right_padding}{self.SUNSET_BORDER}║{self.RESET}"
            )

        # Empty line
        lines.append(
            f"{self.SUNSET_BORDER}║{self.RESET}{' ' * inner_width}{self.SUNSET_BORDER}║{self.RESET}"
        )

        # Bottom border - double line with Sunset brown/orange
        lines.append(f"{self.SUNSET_BORDER}╚{'═' * inner_width}╝{self.RESET}")

        return lines

    def _move_cursor_up(self, n: int) -> str:
        """ANSI escape to move cursor up n lines."""
        return f"\033[{n}A" if n > 0 else ""

    def _animation_loop(self):
        """Main animation loop running in separate thread."""
        orbital_frame = 0
        tick = 0

        # Initial render - print empty lines to reserve space
        with self._stdout_lock:
            print()  # Status line
            box_lines = self._render_box("")
            for _ in box_lines:
                print()

            self._total_lines = 1 + len(box_lines)  # status + box
            self._initialized.set()

        while not self._stop_event.is_set():
            with self._lock:
                tip_idx = self._current_tip_index
                char_idx = self._current_tip_char_index

            current_tip = self.TIPS[tip_idx % len(self.TIPS)]
            visible_tip = current_tip[:char_idx]

            # Build frame
            orbital = self._get_orbital_frame(orbital_frame)
            elapsed_str = ""
            if self._start_time is not None:
                elapsed_str = "  " + _format_elapsed(time.time() - self._start_time)
            status_line = f"  {orbital} Generating MCP server{elapsed_str}"
            box_lines = self._render_box(visible_tip)

            # Render the entire frame atomically to prevent interleaving
            with self._stdout_lock:
                # Move cursor up to overwrite
                sys.stdout.write(self._move_cursor_up(self._total_lines))

                # Render status line
                sys.stdout.write(f"\r{self.CLEAR_LINE}{status_line}\n")

                # Render box lines
                for line in box_lines:
                    sys.stdout.write(f"\r{self.CLEAR_LINE}{line}\n")

                sys.stdout.flush()

            # Update animation state
            orbital_frame += 1

            # Typewriter logic (every tick = ~40ms per char - faster typing)
            if tick % 1 == 0:
                with self._lock:
                    if not self._tip_display_complete:
                        if self._current_tip_char_index < len(current_tip):
                            self._current_tip_char_index += 1
                        else:
                            self._tip_display_complete = True
                            self._tip_pause_counter = 0
                    else:
                        # Pause after complete tip
                        self._tip_pause_counter += 1
                        if self._tip_pause_counter > 50:  # ~2 seconds pause
                            # Move to next tip
                            self._current_tip_index = (
                                self._current_tip_index + 1
                            ) % len(self.TIPS)
                            self._current_tip_char_index = 0
                            self._tip_display_complete = False
                            self._tip_pause_counter = 0

            tick += 1
            time.sleep(0.04)  # 40ms per frame

    def start(self, start_time: Optional[float] = None):
        """Start the animated UI.

        Args:
            start_time: Optional epoch timestamp to use as the timer origin.
                        If None, the timer starts from now.
        """
        # Hide cursor for cleaner animation
        sys.stdout.write(self.HIDE_CURSOR)
        sys.stdout.flush()

        self._stop_event.clear()
        self._initialized.clear()
        self._current_tip_index = 0
        self._current_tip_char_index = 0
        self._tip_display_complete = False
        self._tip_pause_counter = 0
        self._total_lines = 0
        self._start_time = start_time if start_time is not None else time.time()

        self._animation_thread = threading.Thread(
            target=self._animation_loop, daemon=True
        )
        self._animation_thread.start()

    def stop(self):
        """Stop the animation without completion message."""
        if self._animation_thread and self._animation_thread.is_alive():
            self._stop_event.set()
            self._animation_thread.join(timeout=2.0)
            self._animation_thread = None

        # Show cursor again
        with self._stdout_lock:
            sys.stdout.write(self.SHOW_CURSOR)
            sys.stdout.flush()

    def complete(self):
        """Stop animation and show completion message."""
        # Wait for the animation thread to finish initialization so
        # _total_lines is set before we try to use it for cursor math.
        self._initialized.wait(timeout=3.0)

        self.stop()

        with self._stdout_lock:
            if self._total_lines > 0:
                # Move up and clear all lines
                sys.stdout.write(self._move_cursor_up(self._total_lines))
                for _ in range(self._total_lines):
                    sys.stdout.write(f"\r{self.CLEAR_LINE}\n")

                # Move back up and print completion
                sys.stdout.write(self._move_cursor_up(self._total_lines))

            elapsed_str = ""
            if self._start_time is not None:
                elapsed_str = "  " + _format_elapsed(time.time() - self._start_time)
            print(f"  \033[92m✓\033[0m  Generation complete{elapsed_str}")
            sys.stdout.flush()


# Custom style for questionary checkboxes
# Note: 'selected' applies to entire text line when checked, so we use 'noreverse'
# to prevent the white highlight. The checkbox marker (● vs ○) still indicates selection.
CHECKBOX_STYLE = (
    Style(
        [
            ("qmark", ""),  # Hide question mark
            ("question", "bold"),
            ("pointer", "fg:#673ab7 bold"),
            ("highlighted", "fg:#673ab7"),
            (
                "selected",
                "fg:#22c55e noreverse",
            ),  # Bright green for selected items, no reverse
            ("instruction", ""),  # Hide default instruction
        ]
    )
    if HAS_QUESTIONARY
    else None
)

# Custom style for single-choice selector (questionary.select)
# Green color scheme for selected/highlighted items
SELECTOR_STYLE = (
    Style(
        [
            ("qmark", "fg:cyan bold"),
            ("question", "bold"),
            ("pointer", "fg:#22c55e bold"),  # Green arrow pointer
            ("highlighted", "fg:#22c55e bold"),  # Green highlighted option
            ("selected", "fg:#22c55e bold"),  # Green selected item
            ("answer", "fg:#22c55e bold"),  # Green final answer
        ]
    )
    if HAS_QUESTIONARY
    else None
)


def display_tool_selection(
    candidates: List[Any],
    custom_label: str = "🔸 Custom (describe your own requirements) 🔸",
) -> Tuple[List[Any], bool]:
    """
    Display interactive checkbox selection for MCP tool candidates.

    Args:
        candidates: List of EndpointCandidate objects
        custom_label: Label for the custom option

    Returns:
        Tuple of (selected_candidates, custom_selected)
    """
    if not HAS_QUESTIONARY:
        return _fallback_selection(candidates, custom_label)

    print("\n" + "━" * 60)
    print("🔌 Select functions to convert to MCP tools:")
    print("━" * 60)
    print("💡 Use ↑/↓ to navigate, SPACE to toggle selection, ENTER to confirm\n")

    # Build choices list
    choices = []

    # Add endpoint candidates (not pre-selected)
    for candidate in candidates:
        choices.append(
            questionary.Choice(
                title=candidate.display_label(),
                value=("endpoint", candidate),
                checked=False,
            )
        )

    # Add separator and custom option
    choices.append(questionary.Separator("─" * 50))
    choices.append(
        questionary.Choice(title=custom_label, value=("custom", None), checked=False)
    )
    # Add margin below custom option for visibility on any screen size
    choices.append(questionary.Separator("─" * 50))
    choices.append(questionary.Separator(" "))
    choices.append(questionary.Separator(" "))
    choices.append(questionary.Separator(" "))
    choices.append(questionary.Separator(" "))
    choices.append(questionary.Separator(" "))

    try:
        selected = questionary.checkbox(
            "",
            choices=choices,
            style=CHECKBOX_STYLE,
            qmark="",  # Hide the question mark
            instruction="",  # Hide default instruction (we show our own above)
        ).ask()

        # Add space after selection
        print()

        if selected is None:  # User cancelled
            return [], False

        # Separate endpoint selections from custom
        selected_candidates = []
        custom_selected = False

        for item in selected:
            if item[0] == "custom":
                custom_selected = True
            else:
                selected_candidates.append(item[1])

        return selected_candidates, custom_selected

    except KeyboardInterrupt:
        print("\n❌ Selection cancelled")
        return [], False


def _fallback_selection(
    candidates: List[Any], custom_label: str
) -> Tuple[List[Any], bool]:
    """Fallback selection when questionary is not available"""
    print("\n" + "━" * 60)
    print("🔌 Available functions to convert to MCP tools:")
    print("━" * 60)

    for i, candidate in enumerate(candidates, 1):
        conf_indicator = "★" if candidate.confidence >= 0.6 else "☆"
        print(f"  {i}. {conf_indicator} {candidate.display_label()}")

    custom_idx = len(candidates) + 1
    print(f"  {custom_idx}. {custom_label}")
    print("━" * 60)

    print(
        "\nEnter numbers separated by commas (e.g., 1,3,5) or 'all' for all endpoints:"
    )
    print("Press Enter with no input to select only starred (★) items")

    try:
        user_input = input("> ").strip()
    except KeyboardInterrupt:
        print("\n❌ Selection cancelled")
        return [], False

    selected_candidates = []
    custom_selected = False

    if not user_input:
        # Select high confidence by default
        selected_candidates = [c for c in candidates if c.confidence >= 0.6]
    elif user_input.lower() == "all":
        selected_candidates = candidates[:]
    else:
        try:
            indices = [int(x.strip()) for x in user_input.split(",")]
            for idx in indices:
                if 1 <= idx <= len(candidates):
                    selected_candidates.append(candidates[idx - 1])
                elif idx == custom_idx:
                    custom_selected = True
        except ValueError:
            print("Invalid input, using default selection")
            selected_candidates = [c for c in candidates if c.confidence >= 0.6]

    return selected_candidates, custom_selected


def _group_candidates_by_category(
    candidates: List[Any],
) -> Dict[str, Dict[str, List[Any]]]:
    """
    Group candidates by conversion_type, then by subcategory.

    Args:
        candidates: List of EndpointCandidate objects

    Returns:
        Nested dict: {"ready": {"helpers": [...], "api": [...]}, "requires_wrapper": {...}}
    """
    from collections import defaultdict

    grouped: Dict[str, Dict[str, List[Any]]] = {
        "ready": defaultdict(list),
        "requires_wrapper": defaultdict(list),
    }

    for candidate in candidates:
        # Get conversion type, default to "ready" for backward compatibility
        conv_type = getattr(candidate, "conversion_type", "ready")
        if conv_type not in grouped:
            conv_type = "ready"

        # Get subcategory, default to "general" if not set
        subcategory = getattr(candidate, "subcategory", "") or "general"

        grouped[conv_type][subcategory].append(candidate)

    # Sort candidates within each subcategory by score (highest first), then confidence
    def sort_key(x):
        return (getattr(x, "score", 0), getattr(x, "confidence", 0))

    for conv_type in grouped:
        for subcategory in grouped[conv_type]:
            grouped[conv_type][subcategory].sort(key=sort_key, reverse=True)

    return grouped


def _get_candidate_description(candidate: Any) -> str:
    """
    Get the full description for a candidate.

    Args:
        candidate: EndpointCandidate object

    Returns:
        Full description string
    """
    description = ""

    # Try human_description first
    human_desc = getattr(candidate, "human_description", "")
    if human_desc and len(human_desc) > 10:
        description = human_desc

    # Fall back to docstring first line
    if not description and candidate.docstring:
        first_line = candidate.docstring.split("\n")[0].strip()
        if first_line and not first_line.startswith(
            (":param", "Args:", "Returns:", "@")
        ):
            description = first_line

    # Fall back to human_title
    if not description:
        human_title = getattr(candidate, "human_title", "")
        if human_title and candidate.name != human_title:
            description = human_title

    # Final fallback
    if not description:
        description = candidate.name.replace("_", " ").capitalize()

    return description.rstrip(".")


def _get_confidence_stars(confidence: float) -> str:
    """Get star rating based on confidence score."""
    if confidence >= 0.7:
        return "⭐⭐⭐"
    elif confidence >= 0.5:
        return "⭐⭐"
    else:
        return "⭐"


def _format_candidate_short(candidate: Any) -> str:
    """
    Format candidate for short list display (just name and stars).

    Args:
        candidate: EndpointCandidate object

    Returns:
        Short formatted string: "function_name()  ⭐⭐⭐"
    """
    name = candidate.name
    confidence = getattr(candidate, "confidence", 0.5)
    stars = _get_confidence_stars(confidence)
    return f"{name}()  {stars}"


def _format_candidate_display(candidate: Any, working_dir: str) -> str:
    """
    Format a single candidate for list display with truncated description.

    Format: function_name() - Short description  ⭐⭐⭐

    Args:
        candidate: EndpointCandidate object
        working_dir: Project working directory (unused, kept for compatibility)

    Returns:
        Formatted single-line string
    """
    name = candidate.name
    description = _get_candidate_description(candidate)
    confidence = getattr(candidate, "confidence", 0.5)
    stars = _get_confidence_stars(confidence)

    # Smart truncation at word boundaries (max 45 chars)
    max_desc_len = 45
    if len(description) > max_desc_len:
        truncate_at = description.rfind(" ", 0, max_desc_len)
        if truncate_at == -1 or truncate_at < 20:
            truncate_at = max_desc_len - 3
        description = description[:truncate_at].rstrip(",").rstrip() + "..."

    return f"{name}() - {description}  {stars}"


def _interactive_panel_selection(
    candidates: List[Any], working_dir: str, custom_label: str
) -> Tuple[List[Any], bool]:
    """
    Interactive selection with details panel using prompt_toolkit.

    Shows short function names in the list, with full description displayed
    in a panel below when navigating.
    """
    import textwrap

    from prompt_toolkit import Application
    from prompt_toolkit.formatted_text import FormattedText
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style

    try:
        from prompt_toolkit.layout.dimension import Dimension
    except ImportError:
        Dimension = None

    # Group and flatten candidates
    grouped = _group_candidates_by_category(candidates)

    # Build item list with section headers
    items = []  # List of (type, data) - type: 'header', 'candidate', 'custom'
    candidate_indices = []  # Track which items are selectable

    # Ready to Convert section
    ready_candidates = grouped.get("ready", {})
    if any(ready_candidates.values()):
        items.append(("header", "✅ Ready to Convert"))
        all_ready = []
        for subcat in sorted(ready_candidates.keys()):
            all_ready.extend(ready_candidates[subcat])
        for c in all_ready:
            candidate_indices.append(len(items))
            items.append(("candidate", c))

    # Requires Wrapper section
    wrapper_candidates = grouped.get("requires_wrapper", {})
    if any(wrapper_candidates.values()):
        items.append(("header", "🔧 Requires Wrapper"))
        all_wrapper = []
        for subcat in sorted(wrapper_candidates.keys()):
            all_wrapper.extend(wrapper_candidates[subcat])
        for c in all_wrapper:
            candidate_indices.append(len(items))
            items.append(("candidate", c))

    # Custom option
    items.append(("header", "───────────────────────────────────"))
    candidate_indices.append(len(items))
    items.append(("custom", custom_label))

    if not candidate_indices:
        return [], False

    # State
    current_idx = [0]  # Index into candidate_indices
    selected = set()  # Set of indices that are selected
    result = [None]  # Result holder
    list_display_start = [0]  # First item index in items[] to render (virtual scroll)

    def get_current_item_idx():
        return candidate_indices[current_idx[0]]

    def get_list_text():
        lines = []
        lines.append(
            ("class:hint", "💡 ↑/↓ navigate • SPACE select • ENTER confirm • q quit\n")
        )
        lines.append(("class:separator", "─" * 60 + "\n"))

        display_start = list_display_start[0]
        if display_start > 0:
            lines.append(("class:hint", "  ↑ more above\n"))

        for i, (item_type, data) in enumerate(items):
            if i < display_start:
                continue
            if item_type == "header":
                lines.append(("class:header", f"\n  {data}\n"))
            elif item_type == "candidate":
                is_current = i == get_current_item_idx()
                is_selected = i in selected

                checkbox = "☑" if is_selected else "○"
                name = data.name
                stars = _get_confidence_stars(getattr(data, "confidence", 0.5))

                prefix = "❯ " if is_current else "  "
                style = "class:selected" if is_current else ""

                lines.append((style, f"{prefix}{checkbox} {name}()  {stars}\n"))
            elif item_type == "custom":
                is_current = i == get_current_item_idx()
                is_selected = i in selected

                checkbox = "☑" if is_selected else "○"
                prefix = "❯ " if is_current else "  "
                style = "class:selected" if is_current else ""

                lines.append((style, f"{prefix}{checkbox} {data}\n"))

        return FormattedText(lines)

    def get_detail_text():
        idx = get_current_item_idx()
        item_type, data = items[idx]

        lines = []
        lines.append(("class:panel-border", "┌" + "─" * 58 + "┐\n"))

        if item_type == "candidate":
            # Title line
            name = data.name
            stars = _get_confidence_stars(getattr(data, "confidence", 0.5))
            title = f" {name}()  {stars}"
            padding = 58 - len(title)
            lines.append(("class:panel-border", "│"))
            lines.append(("class:panel-title", title))
            lines.append(("class:panel-border", " " * padding + "│\n"))

            lines.append(("class:panel-border", "├" + "─" * 58 + "┤\n"))

            # Description - wrap to fit panel
            desc = _get_candidate_description(data)
            wrapped = textwrap.wrap(desc, width=56)
            for line in wrapped[:4]:  # Max 4 lines
                padded = f" {line}"
                padding = 58 - len(padded)
                lines.append(("class:panel-border", "│"))
                lines.append(("class:panel-content", padded))
                lines.append(("class:panel-border", " " * padding + "│\n"))

            # File path
            if hasattr(data, "file_path") and data.file_path:
                import os

                rel_path = (
                    os.path.relpath(data.file_path, working_dir)
                    if working_dir
                    else data.file_path
                )
                file_line = f" 📁 {rel_path}"
                if len(file_line) > 57:
                    file_line = file_line[:54] + "..."
                padding = 58 - len(file_line)
                lines.append(("class:panel-border", "│"))
                lines.append(("class:panel-file", file_line))
                lines.append(("class:panel-border", " " * padding + "│\n"))

        elif item_type == "custom":
            title = " Custom Requirements"
            padding = 58 - len(title)
            lines.append(("class:panel-border", "│"))
            lines.append(("class:panel-title", title))
            lines.append(("class:panel-border", " " * padding + "│\n"))

            lines.append(("class:panel-border", "├" + "─" * 58 + "┤\n"))

            desc = " Describe your own tool requirements"
            padding = 58 - len(desc)
            lines.append(("class:panel-border", "│"))
            lines.append(("class:panel-content", desc))
            lines.append(("class:panel-border", " " * padding + "│\n"))

        lines.append(("class:panel-border", "└" + "─" * 58 + "┘\n"))

        return FormattedText(lines)

    def update_scroll():
        """Keep the focused item visible by adjusting list_display_start."""
        focused_item_idx = get_current_item_idx()
        try:
            rows = shutil.get_terminal_size(fallback=(80, 24)).lines
        except Exception:
            rows = 24
        detail_vis = min(8, max(3, rows // 5))
        # 2 fixed lines at top (hint + separator) plus optional scroll indicator
        list_visible = max(3, rows - detail_vis - 3)

        display_start = list_display_start[0]
        # Count display lines from display_start to focused item
        line_count = 0
        for i in range(display_start, focused_item_idx + 1):
            if i < len(items):
                line_count += 2 if items[i][0] == "header" else 1

        if line_count > list_visible:
            # Focused item below visible area — scroll down
            new_start = focused_item_idx
            if new_start > 0 and items[new_start - 1][0] == "header":
                new_start = max(0, new_start - 1)
            list_display_start[0] = new_start
        elif focused_item_idx < display_start:
            # Focused item above visible area — scroll up
            new_start = focused_item_idx
            if new_start > 0 and items[new_start - 1][0] == "header":
                new_start = max(0, new_start - 1)
            list_display_start[0] = new_start

    # Key bindings
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        if current_idx[0] > 0:
            current_idx[0] -= 1
            update_scroll()

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        if current_idx[0] < len(candidate_indices) - 1:
            current_idx[0] += 1
            update_scroll()

    @kb.add("space")
    def toggle_select(event):
        idx = get_current_item_idx()
        if idx in selected:
            selected.discard(idx)
        else:
            selected.add(idx)

    @kb.add("enter")
    def confirm(event):
        result[0] = "confirm"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    def cancel(event):
        result[0] = "cancel"
        event.app.exit()

    # Layout
    list_control = FormattedTextControl(get_list_text)
    detail_control = FormattedTextControl(get_detail_text)

    style = Style.from_dict(
        {
            "header": "bold cyan",
            "hint": "#d7af00",
            "separator": "#d7af00",
            "selected": "bold reverse",
            "panel-border": "cyan",
            "panel-title": "bold white",
            "panel-content": "white",
            "panel-file": "dim white",
        }
    )

    # Weight-based proportional sizing: prompt_toolkit distributes terminal rows
    # automatically. full_screen=True uses the alternate screen buffer so the layout
    # always fills the terminal and resize (SIGWINCH) is handled transparently.
    h_list = Dimension(weight=4) if Dimension else None
    h_detail = Dimension(min=5, max=10, preferred=8) if Dimension else None
    layout = Layout(
        HSplit(
            [
                Window(content=list_control, wrap_lines=False, height=h_list),
                Window(content=detail_control, height=h_detail),
            ]
        )
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=True,
        mouse_support=True,
    )

    try:
        app.run()
    except KeyboardInterrupt:
        return [], False

    if result[0] == "cancel" or result[0] is None:
        print("\n❌ Selection cancelled")
        return [], False

    # Build results
    selected_candidates = []
    custom_selected = False

    for idx in selected:
        item_type, data = items[idx]
        if item_type == "candidate":
            selected_candidates.append(data)
        elif item_type == "custom":
            custom_selected = True

    return selected_candidates, custom_selected


def display_categorized_tool_selection(
    candidates: List[Any],
    working_dir: str = "",
    custom_label: str = "◆ Custom (describe your own requirements)",
) -> Tuple[List[Any], bool]:
    """
    Display interactive checkbox selection with categorized MCP tool candidates.

    Shows a details panel when navigating items with full description.

    Groups candidates by:
    - "Ready to Convert" - functions that can be directly converted
    - "Requires Wrapper" - functions that need client/connection setup

    Args:
        candidates: List of EndpointCandidate objects
        working_dir: Project working directory for relative paths
        custom_label: Label for the custom option

    Returns:
        Tuple of (selected_candidates, custom_selected)
    """
    # Try interactive panel selection first
    if HAS_PROMPT_TOOLKIT:
        try:
            return _interactive_panel_selection(candidates, working_dir, custom_label)
        except Exception as e:
            # Fall back to questionary if prompt_toolkit fails
            print(f"Interactive mode unavailable, using standard selection: {e}")

    if not HAS_QUESTIONARY:
        return _fallback_categorized_selection(candidates, working_dir, custom_label)

    print("\n" + "━" * 65)
    print("🔌 Select functions to convert to MCP tools")
    print("━" * 65)
    print("💡 Use ↑/↓ to navigate, SPACE to select, ENTER to confirm\n")

    # Group candidates by category
    grouped = _group_candidates_by_category(candidates)

    # Build choices list with category headers
    choices = []

    # Section 1: Ready to Convert
    ready_candidates = grouped.get("ready", {})
    if any(ready_candidates.values()):
        choices.append(questionary.Separator(""))
        choices.append(questionary.Separator("✅ Ready to Convert"))
        choices.append(
            questionary.Separator(
                "───────────────────────────────────────────────────────"
            )
        )
        choices.append(questionary.Separator(""))

        # Flatten all ready candidates for clean display
        all_ready = []
        for subcategory in sorted(ready_candidates.keys()):
            all_ready.extend(ready_candidates[subcategory])

        # Add candidates with spacing between each
        for i, candidate in enumerate(all_ready):
            display_text = _format_candidate_display(candidate, working_dir)
            choices.append(
                questionary.Choice(
                    title=display_text, value=("endpoint", candidate), checked=False
                )
            )
            # Add empty line after each candidate for spacing
            choices.append(questionary.Separator(""))

    # Section 2: Requires Wrapper
    wrapper_candidates = grouped.get("requires_wrapper", {})
    if any(wrapper_candidates.values()):
        choices.append(
            questionary.Separator(
                "───────────────────────────────────────────────────────"
            )
        )
        choices.append(questionary.Separator("🔧 Requires Wrapper"))
        choices.append(
            questionary.Separator(
                "───────────────────────────────────────────────────────"
            )
        )
        choices.append(questionary.Separator(""))

        # Flatten all wrapper candidates for clean display
        all_wrapper = []
        for subcategory in sorted(wrapper_candidates.keys()):
            all_wrapper.extend(wrapper_candidates[subcategory])

        # Add candidates with spacing between each
        for i, candidate in enumerate(all_wrapper):
            display_text = _format_candidate_display(candidate, working_dir)
            choices.append(
                questionary.Choice(
                    title=display_text, value=("endpoint", candidate), checked=False
                )
            )
            # Add empty line after each candidate for spacing
            choices.append(questionary.Separator(""))

    # Add separator and custom option
    choices.append(questionary.Separator("─" * 55))
    choices.append(
        questionary.Choice(title=custom_label, value=("custom", None), checked=False)
    )

    # Add small margin below for visibility
    choices.append(questionary.Separator(" "))
    choices.append(questionary.Separator(" "))

    try:
        selected = questionary.checkbox(
            "",
            choices=choices,
            style=CHECKBOX_STYLE,
            qmark="",  # Hide the question mark
            instruction="",  # Hide default instruction (we show our own above)
        ).ask()

        # Add space after selection
        print()

        if selected is None:  # User cancelled
            return [], False

        # Separate endpoint selections from custom
        selected_candidates = []
        custom_selected = False

        for item in selected:
            if item[0] == "custom":
                custom_selected = True
            else:
                selected_candidates.append(item[1])

        return selected_candidates, custom_selected

    except KeyboardInterrupt:
        print("\n❌ Selection cancelled")
        return [], False


def _fallback_categorized_selection(
    candidates: List[Any], working_dir: str, custom_label: str
) -> Tuple[List[Any], bool]:
    """
    Fallback categorized selection when questionary is not available.

    Args:
        candidates: List of EndpointCandidate objects
        working_dir: Project working directory
        custom_label: Label for the custom option

    Returns:
        Tuple of (selected_candidates, custom_selected)
    """
    print("\n" + "━" * 65)
    print("🔌 Select functions to convert to MCP tools")
    print("━" * 65)

    # Group candidates
    grouped = _group_candidates_by_category(candidates)

    # Build indexed list for selection
    indexed_candidates = []
    idx = 1

    # Section 1: Ready to Convert
    ready_candidates = grouped.get("ready", {})
    if any(ready_candidates.values()):
        print("\n✅ Ready to Convert")
        print("─" * 60)

        for subcategory in sorted(ready_candidates.keys()):
            subcategory_candidates = ready_candidates[subcategory]
            if not subcategory_candidates:
                continue

            print(f"\n  📂 {subcategory}")

            for candidate in subcategory_candidates:
                # Get display info
                name = candidate.name
                human_title = getattr(candidate, "human_title", "") or name
                confidence = getattr(candidate, "confidence", 0.5)
                conf_star = "★" if confidence >= 0.6 else "☆"

                # Get relative path
                file_path = candidate.file_path
                if working_dir and file_path.startswith(working_dir):
                    rel_path = file_path[len(working_dir) :].lstrip("/\\")
                else:
                    rel_path = file_path.split("/")[-1]

                print(f"    {idx}. {conf_star} {name}() - {human_title}")
                print(f"       📁 {rel_path}")

                indexed_candidates.append(candidate)
                idx += 1

    # Section 2: Requires Wrapper
    wrapper_candidates = grouped.get("requires_wrapper", {})
    if any(wrapper_candidates.values()):
        print("\n🔧 Requires Wrapper (needs client setup)")
        print("─" * 60)

        for subcategory in sorted(wrapper_candidates.keys()):
            subcategory_candidates = wrapper_candidates[subcategory]
            if not subcategory_candidates:
                continue

            print(f"\n  📂 {subcategory}")

            for candidate in subcategory_candidates:
                # Get display info
                name = candidate.name
                human_title = getattr(candidate, "human_title", "") or name
                confidence = getattr(candidate, "confidence", 0.5)
                conf_star = "★" if confidence >= 0.6 else "☆"

                # Get relative path
                file_path = candidate.file_path
                if working_dir and file_path.startswith(working_dir):
                    rel_path = file_path[len(working_dir) :].lstrip("/\\")
                else:
                    rel_path = file_path.split("/")[-1]

                # Get client dependency
                client_dep = getattr(candidate, "client_dependency", None)
                client_info = ""
                if client_dep:
                    client_name = getattr(client_dep, "client_name", "External client")
                    client_info = f" 🔗 {client_name}"

                print(f"    {idx}. {conf_star} {name}() - {human_title}{client_info}")
                print(f"       📁 {rel_path}")

                indexed_candidates.append(candidate)
                idx += 1

    # Custom option
    custom_idx = idx
    print(f"\n    {custom_idx}. {custom_label}")
    print("━" * 65)

    print(
        "\nEnter numbers separated by commas (e.g., 1,3,5) or 'all' for all endpoints:"
    )
    print("Press Enter with no input to select only starred (★) items")

    try:
        user_input = input("> ").strip()
    except KeyboardInterrupt:
        print("\n❌ Selection cancelled")
        return [], False

    selected_candidates = []
    custom_selected = False

    if not user_input:
        # Select high confidence by default
        selected_candidates = [
            c for c in indexed_candidates if getattr(c, "confidence", 0) >= 0.6
        ]
    elif user_input.lower() == "all":
        selected_candidates = indexed_candidates[:]
    else:
        try:
            indices = [int(x.strip()) for x in user_input.split(",")]
            for i in indices:
                if 1 <= i <= len(indexed_candidates):
                    selected_candidates.append(indexed_candidates[i - 1])
                elif i == custom_idx:
                    custom_selected = True
        except ValueError:
            print("Invalid input, using default selection")
            selected_candidates = [
                c for c in indexed_candidates if getattr(c, "confidence", 0) >= 0.6
            ]

    return selected_candidates, custom_selected


def display_context_validation_ui(
    validation: Dict[str, Any], working_dir: str
) -> Tuple[bool, Optional[str]]:
    """
    Display interactive UI for query validation results.

    Handles three scenarios:
    - valid: Shows success message, returns (True, None)
    - insufficient: Shows error, offers to display available components
    - uncertain: Shows found items, presents options to continue/refine/cancel

    Args:
        validation: Result from validate_query_relevance()
        working_dir: Project working directory (for getting available components)

    Returns:
        Tuple of (should_proceed: bool, new_query: str or None)
        - (True, None) - proceed with current query
        - (True, new_query) - proceed with a new refined query
        - (False, None) - user cancelled
    """
    status = validation.get("status", "uncertain")
    results = validation.get("results", [])
    message = validation.get("message", "")
    query = validation.get("query", "")

    # Valid - proceed immediately (silently)
    if status == "valid":
        return (True, None)

    # Insufficient - no results found (hard stop - no continue option)
    if status == "insufficient":
        print("\n" + "━" * 60)
        print("❌ Cannot Proceed - No Relevant Code Found")
        print("━" * 60)
        print(f'\nYour query: "{query}"')
        print(f"\n{message}")
        print(
            "\nSynapse can only create MCP servers from code that EXISTS in your codebase."
        )
        print(
            "This query cannot be fulfilled because the codebase has no related functionality."
        )

        print("\n" + "━" * 60)
        print("\nWhat would you like to do?")

        try:
            if HAS_QUESTIONARY:
                print("💡 Use ↑/↓ to navigate, ENTER to confirm\n")
                selected = questionary.select(
                    "",
                    choices=[
                        questionary.Choice(
                            title="Refine query - see what's available in your codebase",
                            value="refine",
                        ),
                        questionary.Choice(title="Cancel build", value="cancel"),
                    ],
                    style=CHECKBOX_STYLE,
                    qmark="",
                    instruction="",
                ).ask()
                choice = selected if selected is not None else "cancel"
                if selected is None:
                    print("\n❌ Build cancelled.")
                    return (False, None)
            else:
                # Fallback to text input
                print("  [1] Refine query (see what's available in your codebase)")
                print("  [2] Cancel build")
                text_choice = input("\nYour choice (1/2): ").strip()
                choice = {"1": "refine", "2": "cancel"}.get(text_choice, "cancel")

            if choice == "refine":
                _display_available_components(working_dir)

                # Prompt for new query
                print("\n" + "━" * 60)
                new_query = input(
                    "Enter a new query (or 'cancel' to exit):\n> "
                ).strip()

                if new_query.lower() == "cancel" or not new_query:
                    print("\n❌ Build cancelled.")
                    return (False, None)

                return (True, new_query)

            else:  # choice == "cancel"
                print("\n❌ Build cancelled.")
                return (False, None)

        except KeyboardInterrupt:
            print("\n\n❌ Build cancelled.")
            return (False, None)

    # Uncertain - 1-2 results found
    if status == "uncertain":
        print("\n" + "━" * 60)
        print("⚠️ Limited Context Found")
        print("━" * 60)
        print(f'\nYour query: "{query}"')
        print(f"\n{message}:")

        # Display found items
        for item in results[:5]:
            name = item.get("name", "Unknown")
            item_type = item.get("type", "")
            file_path = item.get("file", "")

            # Make path relative for cleaner display
            if file_path.startswith(working_dir):
                file_path = file_path[len(working_dir) :].lstrip("/\\")

            type_icon = (
                "ƒ" if item_type == "function" else "◆" if item_type == "class" else "•"
            )
            print(f"  {type_icon} {name}() in {file_path}")

        print("\n" + "━" * 60)
        print("\nWhat would you like to do?")

        try:
            if HAS_QUESTIONARY:
                print("💡 Use ↑/↓ to navigate, ENTER to confirm\n")
                selected = questionary.select(
                    "",
                    choices=[
                        questionary.Choice(
                            title="Continue anyway - Synapse will do its best",
                            value="continue",
                        ),
                        questionary.Choice(
                            title="Refine query - see available code", value="refine"
                        ),
                        questionary.Choice(title="Cancel build", value="cancel"),
                    ],
                    style=CHECKBOX_STYLE,
                    qmark="",
                    instruction="",
                ).ask()
                if selected is None:
                    print("\n❌ Build cancelled.")
                    return (False, None)
                choice = selected
            else:
                # Fallback to text input
                print("  [1] Continue anyway (AI will do its best)")
                print("  [2] Refine query (see available code)")
                print("  [3] Cancel build")
                text_choice = input("\nYour choice (1/2/3): ").strip()
                choice = {"1": "continue", "2": "refine", "3": "cancel"}.get(
                    text_choice, "cancel"
                )

            if choice == "continue":
                print("\n⚡ Proceeding with limited context...")
                return (True, None)

            elif choice == "refine":
                _display_available_components(working_dir)

                # Prompt for new query
                print("\n" + "━" * 60)
                new_query = input(
                    "Enter a new query (or 'cancel' to exit):\n> "
                ).strip()

                if new_query.lower() == "cancel" or not new_query:
                    print("\n❌ Build cancelled.")
                    return (False, None)

                return (True, new_query)

            else:  # choice == "cancel"
                print("\n❌ Build cancelled.")
                return (False, None)

        except KeyboardInterrupt:
            print("\n\n❌ Build cancelled.")
            return (False, None)

    # Default: proceed (shouldn't reach here)
    return (True, None)


def _display_available_components(working_dir: str) -> None:
    """Display available code components from the codebase."""
    from utils.context_search import get_available_components

    print("\n" + "━" * 60)
    print("📚 Available Code in Your Codebase")
    print("━" * 60)

    components = get_available_components(working_dir, max_items=15)

    functions = components.get("functions", [])
    classes = components.get("classes", [])

    if not functions and not classes:
        print("\n  No indexed code found.")
        print("  Try running 'synapse analyze' to index your codebase.")
        return

    if functions:
        print(
            f"\nFunctions ({len(functions)} shown, {components.get('functions_total', 0)} total):"
        )
        for func in functions:
            name = func.get("name", "")
            file_path = func.get("file", "")
            print(f"  • {name}() — {file_path}")

    if classes:
        print(
            f"\nClasses ({len(classes)} shown, {components.get('classes_total', 0)} total):"
        )
        for cls in classes:
            name = cls.get("name", "")
            file_path = cls.get("file", "")
            print(f"  ◆ {name} — {file_path}")

    print("\n" + "━" * 60)
    print("💡 Tips:")
    print("  • Use function names like 'read_file' or 'parse_config'")
    print("  • Describe operations: 'file reading and writing'")
    print("  • Be specific: 'database query tools for user management'")


def display_insufficient_context_error(result: Dict[str, Any]) -> None:
    """
    Display a formatted error message when the planner agent reports insufficient context.

    This is called when the backend returns error="insufficient_context", meaning
    the planner agent determined the codebase doesn't have the functionality
    needed to fulfill the user's query.

    Args:
        result: Dictionary containing error details from the backend
    """
    error_type = result.get("error_type", "UNKNOWN")
    query = result.get("query", "Unknown query")
    reason = result.get(
        "reason", "The codebase does not contain relevant functionality."
    )
    available = result.get("available", "No information available")
    suggestion = result.get(
        "suggestion", "Please refine your query to match available functionality."
    )

    # Map error types to user-friendly titles
    error_titles = {
        "NO_RELEVANT_CODE": "No Relevant Code Found",
        "INSUFFICIENT_CONTEXT": "Insufficient Context",
        "MISSING_EXTERNAL_INTEGRATION": "Missing External Integration",
        "INVALID_CUSTOM_REQUIREMENTS": "Invalid Custom Requirements",
        "UNKNOWN": "Cannot Proceed",
    }

    title = error_titles.get(error_type, "Cannot Proceed")

    print("\n" + "━" * 60)
    print(f"❌ Build Failed - {title}")
    print("━" * 60)

    print(f'\nYour query: "{query}"')

    print(f"\nReason: {reason}")

    # For INVALID_CUSTOM_REQUIREMENTS, show what was found vs not found
    if error_type == "INVALID_CUSTOM_REQUIREMENTS":
        # Try to extract from crew_output if structured fields aren't available
        crew_output = result.get("crew_output", "")

        # Show selected endpoints that were found
        if "Selected Endpoints Found:" in crew_output:
            print("\n✓ Selected endpoints found in codebase")

        # Show custom requirements that weren't found
        if "Custom Requirements Not Found:" in crew_output:
            print("✗ Custom requirements have no matching code")

        print("\nThe selected endpoints exist, but your additional custom")
        print("requirements do not match any functionality in the codebase.")

    if available and available != "No information available":
        print("\nAvailable in your codebase:")
        # Format the available items nicely
        for line in available.split("\n"):
            line = line.strip()
            if line:
                if not line.startswith("-") and not line.startswith("•"):
                    line = f"  • {line}"
                else:
                    line = f"  {line}"
                print(line)

    print(f"\n💡 Suggestion: {suggestion}")

    # Add specific suggestion for INVALID_CUSTOM_REQUIREMENTS
    if error_type == "INVALID_CUSTOM_REQUIREMENTS":
        print("\n   Options:")
        print(
            "   1. Remove the custom requirements and build with just the selected endpoints"
        )
        print("   2. Refine your custom requirements to match available functionality")

    print("\n" + "━" * 60)
    print("Synapse can only create MCP servers from code that EXISTS in your codebase.")
    print("Try running 'synapse build' again with a refined query.")
    print("━" * 60)


# =============================================================================
# AI-Discovered Endpoints Display (Sunset Harmony Theme)
# =============================================================================


def get_colored_star(confidence: float) -> "Text":
    """
    Return a single star with color based on confidence level.

    Uses the Sunset Harmony color palette:
    - Gold star: High confidence (0.7+) - Excellent MCP candidate
    - Orange star: Medium confidence (0.5-0.7) - Good candidate
    - Tan star: Lower confidence (0.35-0.5) - Possible candidate

    Args:
        confidence: Confidence score between 0.0 and 1.0

    Returns:
        Rich Text object with colored star
    """
    if not HAS_RICH:
        # Fallback to plain text
        return "★"

    if confidence >= 0.7:
        return Text("★", style="sunset.star_high")
    elif confidence >= 0.5:
        return Text("★", style="sunset.star_medium")
    else:
        return Text("★", style="sunset.star_low")


def _get_star_for_print(confidence: float) -> str:
    """
    Return a star string with ANSI color for print statements.

    Args:
        confidence: Confidence score between 0.0 and 1.0

    Returns:
        String with ANSI-colored star
    """
    GOLD = "\033[38;5;220m"
    ORANGE = "\033[38;5;214m"
    TAN = "\033[38;5;180m"
    RESET = "\033[0m"

    if confidence >= 0.7:
        return f"{GOLD}★{RESET}"
    elif confidence >= 0.5:
        return f"{ORANGE}★{RESET}"
    else:
        return f"{TAN}★{RESET}"


def display_discovered_endpoints(
    endpoints: List[Any], working_dir: str, show_stats: bool = True
) -> None:
    """
    Display discovered endpoints preview with Rich panels using Sunset Harmony theme.

    Shows top 5 per category in the preview, with note about remaining endpoints.
    Users can browse ALL endpoints in the interactive selection that follows.

    Args:
        endpoints: List of EndpointCandidate objects
        working_dir: Working directory for relative path display
        show_stats: Whether to show statistics header
    """
    if not endpoints:
        print("\n⚠️  No MCP tool candidates discovered in codebase.")
        return

    # Group endpoints by category
    ready_endpoints = [
        ep for ep in endpoints if getattr(ep, "conversion_type", "ready") == "ready"
    ]
    wrapper_endpoints = [
        ep
        for ep in endpoints
        if getattr(ep, "conversion_type", "ready") == "requires_wrapper"
    ]

    # Sort by score (highest first) so top-rated endpoints appear first, then by confidence
    def sort_key(x):
        return (getattr(x, "score", 0), getattr(x, "confidence", 0.5))

    ready_endpoints.sort(key=sort_key, reverse=True)
    wrapper_endpoints.sort(key=sort_key, reverse=True)

    # Keep only top N per category for display
    top_ready = ready_endpoints[:MAX_ENDPOINTS_PER_CATEGORY]
    top_wrapper = wrapper_endpoints[:MAX_ENDPOINTS_PER_CATEGORY]

    total_count = len(top_ready) + len(top_wrapper)

    if HAS_RICH and sunset_console:
        _display_endpoints_rich(
            top_ready, top_wrapper, working_dir, total_count, show_stats
        )
    else:
        _display_endpoints_fallback(
            top_ready, top_wrapper, working_dir, total_count, show_stats
        )


def _display_endpoints_rich(
    ready_endpoints: List[Any],
    wrapper_endpoints: List[Any],
    working_dir: str,
    total_count: int,
    show_stats: bool,
) -> None:
    """Display endpoints using Rich panels with Sunset theme"""
    # Header
    if show_stats:
        header = Text()
        header.append("🔍 DISCOVERED ENDPOINTS\n", style="sunset.title")
        header.append(f"Found {total_count} potential tools", style="sunset.muted")

        sunset_console.print()
        sunset_console.print(
            Panel(header, box=DOUBLE, border_style="sunset.border", expand=False)
        )

    # Ready to Convert section
    if ready_endpoints:
        sunset_console.print()
        sunset_console.print(
            Text.assemble(
                ("✅ READY TO CONVERT ", "sunset.ready"),
                (f"(Top {len(ready_endpoints)})", "sunset.muted"),
            )
        )
        content = _build_preview_content(
            ready_endpoints, working_dir, show_wrapper_notes=False
        )
        sunset_console.print(content)

    # Requires Wrapper section
    if wrapper_endpoints:
        sunset_console.print()
        sunset_console.print(
            Text.assemble(
                ("🔧 REQUIRES WRAPPER ", "sunset.wrapper"),
                (f"(Top {len(wrapper_endpoints)})", "sunset.muted"),
            )
        )
        content = _build_preview_content(
            wrapper_endpoints, working_dir, show_wrapper_notes=True
        )
        sunset_console.print(content)

    # Navigation hint removed - shown in selection UI


def _build_preview_panel(
    endpoints: List[Any],
    title: str,
    working_dir: str,
    show_wrapper_notes: bool = False,
    limit: int = MAX_ENDPOINTS_PER_CATEGORY,
) -> "Panel":
    """
    Build a Rich Panel showing top N endpoints with checkboxes beside each tool.

    Args:
        endpoints: List of EndpointCandidate objects
        title: Panel title
        working_dir: Working directory for relative paths
        show_wrapper_notes: Whether to show wrapper notes
        limit: Maximum endpoints to display

    Returns:
        Rich Panel object
    """
    import os

    content = Table.grid(padding=(0, 2))
    content.add_column("checkbox", width=2)
    content.add_column("info", ratio=1)

    # Show only top 'limit' endpoints (already sorted by confidence)
    display_endpoints = endpoints[:limit]

    for ep in display_endpoints:
        # Row 1: Checkbox + Name
        name = getattr(ep, "name", "unknown")
        checkbox_text = Text("○", style="sunset.content")
        name_text = Text(f"{name}()", style="bold")

        content.add_row(checkbox_text, name_text)

        # Row 2: Description
        description = (
            getattr(ep, "human_description", "") or getattr(ep, "docstring", "")[:100]
        )
        if description:
            desc_text = Text(description, style="sunset.content")
            content.add_row("", desc_text)

        # Row 3: File path + complexity
        file_path = getattr(ep, "file_path", "")
        line_number = getattr(ep, "line_number", 0)

        if file_path:
            try:
                rel_path = os.path.relpath(file_path, working_dir)
            except ValueError:
                rel_path = os.path.basename(file_path)

            meta_text = Text(f"📁 {rel_path}:{line_number}", style="sunset.file_path")
            content.add_row("", meta_text)

        # Row 4: Wrapper notes (if applicable)
        if show_wrapper_notes:
            client_dep = getattr(ep, "client_dependency", None)
            if client_dep:
                client_name = getattr(client_dep, "client_name", "external client")
                wrapper_text = Text(f"🔗 Needs: {client_name}", style="sunset.muted")
                content.add_row("", wrapper_text)

        # Spacing between endpoints
        content.add_row("", "")

    # Show "... and N more" if there are more endpoints
    remaining = len(endpoints) - limit
    if remaining > 0:
        more_text = Text(
            f"... and {remaining} more (browse all in selection below)",
            style="sunset.muted",
        )
        content.add_row("", more_text)

    return Panel(
        content,
        title=title,
        title_align="left",
        border_style="sunset.border",
        box=ROUNDED,
        padding=(1, 2),
    )


def _build_preview_content(
    endpoints: List[Any],
    working_dir: str,
    show_wrapper_notes: bool = False,
    limit: int = MAX_ENDPOINTS_PER_CATEGORY,
) -> "Table":
    """Build endpoint list as a plain Table (no Panel border)."""
    import os

    content = Table.grid(padding=(0, 2))
    content.add_column("checkbox", width=2)
    content.add_column("info", ratio=1)

    for ep in endpoints[:limit]:
        name = getattr(ep, "name", "unknown")
        checkbox_text = Text("○", style="sunset.content")
        name_text = Text(f"{name}()", style="bold")
        content.add_row(checkbox_text, name_text)

        description = (
            getattr(ep, "human_description", "") or getattr(ep, "docstring", "")[:100]
        )
        if description:
            content.add_row("", Text(description, style="sunset.content"))

        file_path = getattr(ep, "file_path", "")
        line_number = getattr(ep, "line_number", 0)
        if file_path:
            try:
                rel_path = os.path.relpath(file_path, working_dir)
            except ValueError:
                rel_path = os.path.basename(file_path)
            content.add_row(
                "", Text(f"📁 {rel_path}:{line_number}", style="sunset.file_path")
            )

        if show_wrapper_notes:
            client_dep = getattr(ep, "client_dependency", None)
            if client_dep:
                client_name = (
                    client_dep.get("client_name", "external client")
                    if isinstance(client_dep, dict)
                    else getattr(client_dep, "client_name", "external client")
                )
                content.add_row(
                    "", Text(f"🔗 Needs: {client_name}", style="sunset.muted")
                )

        content.add_row("", "")

    remaining = len(endpoints) - limit
    if remaining > 0:
        content.add_row(
            "",
            Text(
                f"... and {remaining} more (browse all in selection below)",
                style="sunset.muted",
            ),
        )

    return content


def _get_complexity_from_confidence(confidence: float) -> str:
    """Derive complexity label from confidence score"""
    if confidence >= 0.7:
        return "Simple"
    elif confidence >= 0.5:
        return "Moderate"
    else:
        return "Complex"


def _display_endpoints_fallback(
    ready_endpoints: List[Any],
    wrapper_endpoints: List[Any],
    working_dir: str,
    total_count: int,
    show_stats: bool,
) -> None:
    """Fallback display without Rich library"""
    import os

    BORDER = "\033[38;5;94m"
    TITLE = "\033[38;5;214m"
    CONTENT = "\033[38;5;230m"
    MUTED = "\033[38;5;180m"
    RESET = "\033[0m"

    # Header
    if show_stats:
        print()
        print(f"{BORDER}╔{'═' * 65}╗{RESET}")
        print(f"{BORDER}║{RESET}  {TITLE}🔍 DISCOVERED ENDPOINTS{RESET}")
        print(f"{BORDER}║{RESET}  {MUTED}Found {total_count} potential tools{RESET}")
        print(f"{BORDER}╚{'═' * 65}╝{RESET}")

    # Ready to Convert section - already limited to top N
    if ready_endpoints:
        print()
        print(f"{BORDER}┌{'─' * 65}┐{RESET}")
        print(
            f"{BORDER}│{RESET}  {TITLE}✅ READY TO CONVERT (Top {len(ready_endpoints)}){RESET}"
        )
        print(f"{BORDER}├{'─' * 65}┤{RESET}")

        for ep in ready_endpoints:
            name = getattr(ep, "name", "unknown")
            description = (
                getattr(ep, "human_description", "")
                or getattr(ep, "docstring", "")[:80]
            )
            file_path = getattr(ep, "file_path", "")

            print(f"{BORDER}│{RESET}  ○ {name}()")
            if description:
                print(f"{BORDER}│{RESET}  {CONTENT}{description}{RESET}")
            if file_path:
                try:
                    rel_path = os.path.relpath(file_path, working_dir)
                except ValueError:
                    rel_path = os.path.basename(file_path)
                print(f"{BORDER}│{RESET}  {MUTED}📁 {rel_path}{RESET}")
            print(f"{BORDER}│{RESET}")

        print(f"{BORDER}└{'─' * 65}┘{RESET}")

    # Requires Wrapper section - already limited to top N
    if wrapper_endpoints:
        print()
        print(f"{BORDER}┌{'─' * 65}┐{RESET}")
        print(
            f"{BORDER}│{RESET}  {TITLE}🔧 REQUIRES WRAPPER (Top {len(wrapper_endpoints)}){RESET}"
        )
        print(f"{BORDER}├{'─' * 65}┤{RESET}")

        for ep in wrapper_endpoints:
            name = getattr(ep, "name", "unknown")
            description = (
                getattr(ep, "human_description", "")
                or getattr(ep, "docstring", "")[:80]
            )

            print(f"{BORDER}│{RESET}  ○ {name}()")
            if description:
                print(f"{BORDER}│{RESET}  {CONTENT}{description}{RESET}")

            client_dep = getattr(ep, "client_dependency", None)
            if client_dep:
                client_name = getattr(client_dep, "client_name", "external client")
                print(f"{BORDER}│{RESET}  {MUTED}🔗 Needs: {client_name}{RESET}")
            print(f"{BORDER}│{RESET}")

        print(f"{BORDER}└{'─' * 65}┘{RESET}")

    print()
    print(f"{MUTED}💡 Use ↑/↓ to navigate, SPACE to select, ENTER to confirm{RESET}")


def interactive_endpoint_selection(
    endpoints: List[Any],
    working_dir: str,
    custom_label: str = "🔸 Custom (describe your own requirements) 🔸",
) -> Tuple[List[Any], bool]:
    """
    Full interactive selection with scrollable list.
    Uses prompt_toolkit for keyboard navigation through ALL endpoints.

    Args:
        endpoints: List of EndpointCandidate objects
        working_dir: Working directory for relative paths
        custom_label: Label for custom option

    Returns:
        Tuple of (selected_endpoints, custom_selected)
    """
    # Group endpoints by category
    ready_endpoints = [
        ep for ep in endpoints if getattr(ep, "conversion_type", "ready") == "ready"
    ]
    wrapper_endpoints = [
        ep
        for ep in endpoints
        if getattr(ep, "conversion_type", "ready") == "requires_wrapper"
    ]

    # Sort by score (highest first) so top-rated endpoints appear first, then by confidence
    def sort_key(x):
        return (getattr(x, "score", 0), getattr(x, "confidence", 0.5))

    ready_endpoints.sort(key=sort_key, reverse=True)
    wrapper_endpoints.sort(key=sort_key, reverse=True)

    # Keep only top N per category for selection
    ready_endpoints = ready_endpoints[:MAX_ENDPOINTS_PER_CATEGORY]
    wrapper_endpoints = wrapper_endpoints[:MAX_ENDPOINTS_PER_CATEGORY]

    # Try interactive panel selection with prompt_toolkit
    if HAS_PROMPT_TOOLKIT:
        try:
            return _interactive_endpoint_panel_selection(
                ready_endpoints, wrapper_endpoints, working_dir, custom_label
            )
        except Exception as e:
            print(f"Interactive mode unavailable: {e}")

    # Try questionary fallback
    if HAS_QUESTIONARY:
        return _questionary_endpoint_selection(
            ready_endpoints, wrapper_endpoints, working_dir, custom_label
        )

    # Final fallback to numbered selection
    return _numbered_endpoint_selection(
        ready_endpoints, wrapper_endpoints, working_dir, custom_label
    )


def _interactive_endpoint_panel_selection(
    ready_endpoints: List[Any],
    wrapper_endpoints: List[Any],
    working_dir: str,
    custom_label: str,
) -> Tuple[List[Any], bool]:
    """
    Inline-description scrollable list with a bottom status bar.

    Layout (no fixed header — every row is list space):
      ─── ✅ READY TO CONVERT (9) ──────────────────────────────
    » ○ search_records()                            ← focused row
        Searches records using full-text matching   ← desc row
      ● fetch_all()                                 ← selected
        Returns all rows from the table
      ─── 🔧 REQUIRES WRAPPER (3) ──────────────────────────────
      ○ generate_embedding()
        Generates vector embeddings for text
      ──────────────────────────────────────────────────────────
      2 selected  │  ↑↓ navigate · SPACE select · ENTER confirm · Q cancel

    Each selectable item = 2 lines (name + description).
    Category headers = 1 line. Status bar = 2 lines (separator + hint).
    Virtual scroll ensures this works at any terminal height.
    """
    import os

    from prompt_toolkit import Application
    from prompt_toolkit.formatted_text import FormattedText
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.styles import Style

    # ── Build flat item list ──────────────────────────────────────────────────
    # Each entry: ('header', title_str) | ('custom', label_str) | ('candidate', ep)
    items: List[tuple] = []

    items.append(("custom", custom_label))

    if ready_endpoints:
        items.append(
            ("header", f"✅  READY TO CONVERT  ({len(ready_endpoints)} found)")
        )
        for ep in ready_endpoints:
            items.append(("candidate", ep))

    if wrapper_endpoints:
        items.append(
            ("header", f"🔧  REQUIRES WRAPPER  ({len(wrapper_endpoints)} found)")
        )
        for ep in wrapper_endpoints:
            items.append(("candidate", ep))

    candidate_indices = [i for i, (t, _) in enumerate(items) if t != "header"]

    if not candidate_indices:
        return [], False

    # ── State ─────────────────────────────────────────────────────────────────
    cand_pos = [0]  # index into candidate_indices
    selected: set = set()  # item-list indices that are checked
    scroll_top = [0]  # first rendered item index (virtual scroll)
    result = [None]

    def cur_item_idx() -> int:
        return candidate_indices[cand_pos[0]]

    # ── Line-height accounting ────────────────────────────────────────────────
    def item_lines(i: int) -> int:
        """How many terminal rows does item i consume?"""
        t, _ = items[i]
        if t == "header":
            return 1
        elif t == "custom":
            return 3  # name + desc + blank
        else:
            return 4  # name + desc + file:line + blank

    # ── List renderer ─────────────────────────────────────────────────────────
    def get_list_text() -> FormattedText:
        out = []
        focused = cur_item_idx()

        try:
            cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        except Exception:
            cols = 80
        max_text = max(20, cols - 6)

        for item_idx in range(scroll_top[0], len(items)):
            item_type, data = items[item_idx]

            if item_type == "header":
                out.append(("class:cat-sep", f"  ─── {data} "))
                out.append(("class:cat-sep", "─" * 20 + "\n"))
                continue

            is_focused = item_idx == focused
            is_checked = item_idx in selected
            prefix = "» " if is_focused else "  "
            row_style = "class:row-focused" if is_focused else "class:row-normal"
            desc_style = "class:desc-focused" if is_focused else "class:desc-normal"
            file_style = "class:file-focused" if is_focused else "class:file-normal"

            # ── Name line ──
            if item_type == "custom":
                name = data
                desc = "Describe your own tool requirements"
            else:
                name = f"{getattr(data, 'name', 'unknown')}()"
                desc = (
                    getattr(data, "human_description", "")
                    or getattr(data, "docstring", "")[:120]
                ).strip()
                if not desc:
                    desc = "No description available"

            if is_checked:
                out.append((row_style, prefix))
                out.append(("class:checked", "●"))
                out.append((row_style, f" {name}\n"))
            else:
                out.append((row_style, f"{prefix}○ {name}\n"))

            # ── Description line ──
            desc_trunc = desc if len(desc) <= max_text else desc[: max_text - 1] + "…"
            out.append((desc_style, f"    {desc_trunc}\n"))

            # ── File path + line number (candidates only) ──
            if item_type == "candidate":
                file_path = getattr(data, "file_path", "")
                line_num = getattr(data, "line_number", 0)
                if file_path:
                    try:
                        rel = os.path.relpath(file_path, working_dir)
                    except ValueError:
                        rel = os.path.basename(file_path)
                    file_info = f"{rel}:{line_num}" if line_num else rel
                    if len(file_info) > max_text - 4:
                        file_info = "…" + file_info[-(max_text - 5) :]
                    out.append((file_style, f"    📁 {file_info}\n"))

            # ── Blank separator between items ──
            out.append(("", "\n"))

        return FormattedText(out)

    # ── Status bar renderer ───────────────────────────────────────────────────
    def get_status_text() -> FormattedText:
        n = len(selected)
        noun = "selected" if n != 1 else "selected"
        count_str = f"  {n} {noun}"
        try:
            cols = shutil.get_terminal_size(fallback=(80, 24)).columns
        except Exception:
            cols = 80
        if cols >= 70:
            hint = "↑↓ navigate · SPACE select · ENTER confirm · Q cancel  "
        elif cols >= 45:
            hint = "↑↓ · SPACE · ENTER · Q  "
        else:
            hint = "↑↓ SPC ENT Q"
        sep_line = "─" * cols
        return FormattedText(
            [
                ("class:status-sep", sep_line + "\n"),
                ("class:status-count", count_str),
                ("class:status-div", "  │  "),
                ("class:status-hint", hint),
            ]
        )

    # ── Virtual scroll ────────────────────────────────────────────────────────
    def update_scroll():
        focused = cur_item_idx()
        try:
            rows = shutil.get_terminal_size(fallback=(80, 24)).lines
        except Exception:
            rows = 24
        list_height = max(2, rows - 2)  # 2 rows for status bar

        # Scroll up: focused scrolled above the window
        if focused < scroll_top[0]:
            scroll_top[0] = focused
            return

        # Count rendered lines from scroll_top down to focused (inclusive)
        used = sum(item_lines(i) for i in range(scroll_top[0], focused + 1))

        # Scroll down: push scroll_top forward until focused fits
        while used > list_height and scroll_top[0] < focused:
            used -= item_lines(scroll_top[0])
            scroll_top[0] += 1

    # ── Key bindings ──────────────────────────────────────────────────────────
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        if cand_pos[0] > 0:
            cand_pos[0] -= 1
            update_scroll()

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        if cand_pos[0] < len(candidate_indices) - 1:
            cand_pos[0] += 1
            update_scroll()

    @kb.add("space")
    def toggle_select(event):
        idx = cur_item_idx()
        if idx in selected:
            selected.discard(idx)
        else:
            selected.add(idx)

    @kb.add("enter")
    def confirm(event):
        result[0] = "confirm"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    def cancel(event):
        result[0] = "cancel"
        event.app.exit()

    # ── Layout ────────────────────────────────────────────────────────────────
    list_control = FormattedTextControl(get_list_text)
    status_control = FormattedTextControl(get_status_text)

    layout = Layout(
        HSplit(
            [
                Window(content=list_control),  # fills all available space
                Window(content=status_control, height=2),  # fixed 2-line status bar
            ]
        )
    )

    style = Style.from_dict(
        {
            "cat-sep": "#d7af00",  # gold category separator
            "row-focused": "bold #ff8c00",  # orange when focused
            "row-normal": "",  # default terminal colour
            "checked": "bold #ff8c00",  # orange filled circle
            "desc-focused": "#d2a679",  # warm tan description when focused
            "desc-normal": "#767676",  # dimmed description
            "file-focused": "italic #b8956a",  # warm muted tan file path when focused
            "file-normal": "italic #555555",  # dimmed italic file path
            "status-sep": "#d7af00",  # gold separator line
            "status-count": "bold #ff8c00",  # orange selected count
            "status-div": "#d7af00",  # gold divider │
            "status-hint": "#d7af00",  # gold key hints
        }
    )

    app = Application(layout=layout, key_bindings=kb, style=style, full_screen=True)
    app.run()

    print()  # newline after full-screen alt-buffer exits

    if result[0] == "cancel":
        return [], False

    selected_endpoints = []
    custom_selected = False
    for idx in selected:
        item_type, data = items[idx]
        if item_type == "candidate":
            selected_endpoints.append(data)
        elif item_type == "custom":
            custom_selected = True

    return selected_endpoints, custom_selected


def _questionary_endpoint_selection(
    ready_endpoints: List[Any],
    wrapper_endpoints: List[Any],
    working_dir: str,
    custom_label: str,
) -> Tuple[List[Any], bool]:
    """Questionary-based selection fallback"""
    print("\n" + "━" * 65)
    print("🔌 Select functions to convert to MCP tools")
    print("━" * 65)
    print("💡 Use ↑/↓ to navigate, SPACE to select, ENTER to confirm\n")

    choices = []

    # Ready to Convert section
    if ready_endpoints:
        choices.append(questionary.Separator(""))
        choices.append(questionary.Separator("✅ Ready to Convert"))
        choices.append(questionary.Separator("─" * 55))

        for ep in ready_endpoints:
            name = getattr(ep, "name", "unknown")
            display = f"{name}()"
            choices.append(
                questionary.Choice(title=display, value=("endpoint", ep), checked=False)
            )

    # Requires Wrapper section
    if wrapper_endpoints:
        choices.append(questionary.Separator(""))
        choices.append(questionary.Separator("🔧 Requires Wrapper"))
        choices.append(questionary.Separator("─" * 55))

        for ep in wrapper_endpoints:
            name = getattr(ep, "name", "unknown")
            display = f"{name}()"
            choices.append(
                questionary.Choice(title=display, value=("endpoint", ep), checked=False)
            )

    # Custom option
    choices.append(questionary.Separator("─" * 55))
    choices.append(
        questionary.Choice(title=custom_label, value=("custom", None), checked=False)
    )

    try:
        selected = questionary.checkbox(
            "", choices=choices, style=CHECKBOX_STYLE, qmark=""
        ).ask()

        if selected is None:
            return [], False

        selected_endpoints = []
        custom_selected = False

        for item in selected:
            if item[0] == "custom":
                custom_selected = True
            else:
                selected_endpoints.append(item[1])

        return selected_endpoints, custom_selected

    except KeyboardInterrupt:
        print("\n❌ Selection cancelled")
        return [], False


def _numbered_endpoint_selection(
    ready_endpoints: List[Any],
    wrapper_endpoints: List[Any],
    working_dir: str,
    custom_label: str,
) -> Tuple[List[Any], bool]:
    """Simple numbered selection fallback"""
    print("\n" + "━" * 65)
    print("🔌 Select functions to convert to MCP tools")
    print("━" * 65)
    print("Enter numbers separated by commas (e.g., 1,3,5) or 'q' to cancel\n")

    all_endpoints = []
    idx = 1

    if ready_endpoints:
        print("✅ Ready to Convert:")
        for ep in ready_endpoints:
            name = getattr(ep, "name", "unknown")
            print(f"  {idx}. {name}()")
            all_endpoints.append(ep)
            idx += 1

    if wrapper_endpoints:
        print("\n🔧 Requires Wrapper:")
        for ep in wrapper_endpoints:
            name = getattr(ep, "name", "unknown")
            print(f"  {idx}. {name}()")
            all_endpoints.append(ep)
            idx += 1

    print(f"\n  {idx}. {custom_label}")
    custom_idx = idx

    try:
        choice = input("\nYour selection: ").strip()

        if choice.lower() == "q":
            return [], False

        selected_indices = [int(x.strip()) for x in choice.split(",") if x.strip()]

        selected_endpoints = []
        custom_selected = False

        for i in selected_indices:
            if i == custom_idx:
                custom_selected = True
            elif 1 <= i < custom_idx:
                selected_endpoints.append(all_endpoints[i - 1])

        return selected_endpoints, custom_selected

    except (ValueError, KeyboardInterrupt):
        print("\n❌ Selection cancelled")
        return [], False
