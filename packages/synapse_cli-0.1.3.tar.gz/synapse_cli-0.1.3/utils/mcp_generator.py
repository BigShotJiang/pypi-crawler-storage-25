"""MCP Server Code Generation Utilities - Reference Boilerplate and Validation"""

from typing import List

# ============================================================================
# REFERENCE BOILERPLATE CODE PATTERNS
# These patterns are used by the LLM-based code generation system
# ============================================================================

# PART 1 - Server Initialization Pattern (lines 55-63 style)
SERVER_INITIALIZATION_TEMPLATE = """import logging
from mcp.server.fastmcp import FastMCP

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize MCP server using FastMCP
server = FastMCP("server_name")
"""

# PART 2 - Tool Definition Pattern (lines 113-114 style)
TOOL_DEFINITION_TEMPLATE = '''@server.tool()
async def tool_name(param1: type1, param2: type2) -> return_type:
    """Clear description of what this tool does."""
    # Input validation
    if invalid_condition:
        raise ValueError("Clear error message")
    # Implementation
    result = perform_operation(param1, param2)
    return result
'''

# PART 3 - Main Execution Pattern (lines 177-178 style)
MAIN_EXECUTION_TEMPLATE = """if __name__ == "__main__":
    server.run()
"""


def validate_mcp_schema(server_code: str) -> tuple[bool, List[str]]:
    """
    Validates generated code against FastMCP and latest MCP standards

    Checks:
    - Server uses FastMCP (not old Server class)
    - All tools use @server.tool() decorator
    - All tools are async functions
    - Tool parameters have type hints
    - Tool docstrings are present
    - Simple entry point with server.run()
    - No asyncio.run() or async main() (FastMCP handles this)

    Args:
        server_code: Generated server code to validate

    Returns:
        Tuple of (is_valid, list_of_issues)
    """
    issues = []

    # Check for FastMCP import (required)
    if "from mcp.server.fastmcp import FastMCP" not in server_code:
        issues.append("Missing required import: from mcp.server.fastmcp import FastMCP")

    # Check that old Server class is NOT used
    if "from mcp.server import Server" in server_code:
        issues.append("Should use FastMCP, not old Server class")

    if "server = Server(" in server_code:
        issues.append("Server should be initialized with FastMCP(), not Server()")

    # Check for FastMCP initialization
    if "server = FastMCP(" not in server_code:
        issues.append("Server not properly initialized with FastMCP()")

    # Check for @server.tool() decorator
    if "@server.tool()" in server_code:
        # Check that all tools are async
        lines = server_code.split("\n")
        for i, line in enumerate(lines):
            if "@server.tool()" in line:
                # Next non-empty line should be async def
                for j in range(i + 1, min(i + 5, len(lines))):
                    if lines[j].strip():
                        if not lines[j].strip().startswith("async def"):
                            issues.append(f"Tool at line {i+1} is not async")
                        break

    # Check for simple entry point (FastMCP style)
    if 'if __name__ == "__main__":' not in server_code:
        issues.append("Missing entry point: if __name__ == '__main__':")

    if "server.run()" not in server_code:
        issues.append("Missing server.run() in entry point")

    # Check that old patterns are NOT used
    if "asyncio.run(" in server_code:
        issues.append("Should use server.run() directly, not asyncio.run()")

    if "async def main()" in server_code:
        issues.append(
            "FastMCP doesn't need async main() function - use server.run() directly"
        )

    if "async with server:" in server_code:
        issues.append(
            "FastMCP doesn't need async context manager - use server.run() directly"
        )

    # Check for logging setup
    if "logging.basicConfig" not in server_code:
        issues.append("Missing logging configuration")

    is_valid = len(issues) == 0
    return is_valid, issues


# ============================================================================
# REMOVED FUNCTIONS
# The following functions have been removed in favor of LLM-based code generation:
# - generate_mcp_boilerplate() -> Now handled by LLM with templates
# - create_tool_implementation() -> Now handled by LLM with templates
# - create_resource_implementation() -> Now handled by LLM
# - generate_server_main() -> Now handled by LLM with templates
# - generate_complete_mcp_server() -> Replaced with call_llm() in generation_tools.py
# - add_error_handling() -> LLM generates with error handling
# - extract_functions_for_tools() -> Handled by architect agent
# - create_mcp_tool_from_function() -> Handled by architect agent
# - format_mcp_code() -> LLM generates formatted code
# ============================================================================
