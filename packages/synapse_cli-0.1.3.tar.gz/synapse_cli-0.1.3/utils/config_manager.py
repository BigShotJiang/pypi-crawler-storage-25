"""Configuration management for Synapse CLI"""

import json
import os
from datetime import datetime
from typing import Dict, Optional, Tuple

from cryptography.fernet import InvalidToken

# Path to CLI config.json (at synapse-cli project root)
_CLI_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLI_CONFIG_PATH = os.path.join(_CLI_ROOT, "config.json")

# Global config: ~/.synapse (cross-platform)
GLOBAL_SYNAPSE_DIR = os.path.expanduser("~/.synapse")
GLOBAL_CONFIG_PATH = os.path.join(GLOBAL_SYNAPSE_DIR, "config.json")

# Cached CLI config (loaded once)
_cli_config_cache: Optional[Dict] = None


def _load_cli_config() -> Dict:
    """Load config.json from synapse-cli root. Single source for backend URL and env vars."""
    global _cli_config_cache
    if _cli_config_cache is not None:
        return _cli_config_cache
    if not os.path.exists(CLI_CONFIG_PATH):
        _cli_config_cache = {
            "backend_url": "https://grpc.synaps3.ai",
            "backend_host": "localhost",
            "backend_port": "50051",
            "api_url": "https://api.synaps3.ai",
            "version": "0.1.3",
        }
        return _cli_config_cache
    with open(CLI_CONFIG_PATH, "r") as f:
        _cli_config_cache = json.load(f)
    return _cli_config_cache


def get_cli_config() -> Dict:
    """Get the CLI configuration. Edit config.json at synapse-cli root to change."""
    return _load_cli_config()


def load_config(working_dir: str) -> Dict:
    """
    Loads configuration from .synapse directory.

    Args:
        working_dir: Working directory path

    Returns:
        Configuration dictionary
    """
    synapse_dir = os.path.join(working_dir, ".synapse")
    config_path = os.path.join(synapse_dir, "config.json")

    if not os.path.exists(config_path):
        raise FileNotFoundError(
            "Configuration not found. Please run 'synapse init' first."
        )

    with open(config_path, "r") as f:
        config = json.load(f)

    return config


def save_config(working_dir: str, config: Dict) -> None:
    """
    Saves configuration to .synapse directory.

    Args:
        working_dir: Working directory path
        config: Configuration dictionary to save
    """
    synapse_dir = os.path.join(working_dir, ".synapse")
    config_path = os.path.join(synapse_dir, "config.json")

    # Ensure directory exists
    os.makedirs(synapse_dir, exist_ok=True)

    # Update timestamp
    config["last_updated"] = datetime.now().isoformat()

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def is_initialized(working_dir: str) -> bool:
    """
    Check if Synapse is initialized in the given directory.

    Args:
        working_dir: Working directory path

    Returns:
        True if initialized, False otherwise
    """
    synapse_dir = os.path.join(working_dir, ".synapse")
    config_path = os.path.join(synapse_dir, "config.json")

    return os.path.exists(config_path)


def get_api_url() -> str:
    """Get REST API URL for telemetry and lightweight calls.

    Precedence: SYNAPSE_API_URL env var > api_url from config.json > default.
    """
    env_url = os.environ.get("SYNAPSE_API_URL", "").strip()
    if env_url:
        return env_url.rstrip("/")
    config = _load_cli_config()
    url = config.get("api_url", "").strip()
    if url:
        return url.rstrip("/")
    return "https://api.synaps3.ai"


def get_backend_config(working_dir: Optional[str] = None) -> Dict[str, Optional[str]]:
    """
    Get backend connection configuration.

    Precedence: SYNAPSE_BACKEND_URL env var > config.json at synapse-cli root.

    Args:
        working_dir: Ignored (kept for API compatibility)

    Returns:
        Dictionary with url, host, and port (url takes precedence if set)
    """
    env_url = os.environ.get("SYNAPSE_BACKEND_URL", "").strip()
    if env_url:
        return {"url": env_url, "host": None, "port": None}

    config = _load_cli_config()
    backend_url = config.get("backend_url") or ""
    backend_host = config.get("backend_host", "localhost")
    backend_port = str(config.get("backend_port", "50051"))

    # If URL is set, return it (host/port will be parsed from URL)
    if backend_url:
        return {"url": backend_url, "host": None, "port": None}

    # Fall back to host:port configuration
    return {"url": None, "host": backend_host, "port": backend_port}


# ---------------------------------------------------------------------------
# API key storage (encrypted at rest): project + global
# ---------------------------------------------------------------------------


def ensure_global_synapse_dir() -> None:
    """Create ~/.synapse if it does not exist."""
    os.makedirs(GLOBAL_SYNAPSE_DIR, exist_ok=True)


def load_global_config() -> Dict:
    """Load global config from ~/.synapse/config.json. Returns {} if missing."""
    if not os.path.exists(GLOBAL_CONFIG_PATH):
        return {}
    try:
        with open(GLOBAL_CONFIG_PATH, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_global_config(config: Dict) -> None:
    """Save global config to ~/.synapse/config.json."""
    ensure_global_synapse_dir()
    with open(GLOBAL_CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)


def get_project_api_key_encrypted(
    working_dir: str,
) -> Tuple[Optional[str], Optional[str]]:
    """Get (api_key_prefix, api_key_encrypted) from project .synapse/config.json. (None, None) if absent."""
    try:
        config = load_config(working_dir)
        prefix = config.get("api_key_prefix")
        encrypted = config.get("api_key_encrypted")
        if prefix is not None and encrypted:
            return (prefix, encrypted)
    except FileNotFoundError:
        pass
    return (None, None)


def set_project_api_key(working_dir: str, raw_key: str) -> None:
    """Encrypt and save API key to project .synapse/config.json."""
    from utils.api_key_store import encrypt_api_key

    ensure_project_synapse_dir(working_dir)
    if is_initialized(working_dir):
        config = load_config(working_dir)
    else:
        config = {
            "initialized": True,
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        }
    prefix, encrypted = encrypt_api_key(raw_key)
    config["api_key_prefix"] = prefix
    config["api_key_encrypted"] = encrypted
    save_config(working_dir, config)


def ensure_project_synapse_dir(working_dir: str) -> None:
    """Create PROJECT_ROOT/.synapse if it does not exist."""
    synapse_dir = os.path.join(working_dir, ".synapse")
    os.makedirs(synapse_dir, exist_ok=True)


def get_global_api_key_encrypted() -> Tuple[Optional[str], Optional[str]]:
    """Get (api_key_prefix, api_key_encrypted) from ~/.synapse/config.json. (None, None) if absent."""
    config = load_global_config()
    prefix = config.get("api_key_prefix")
    encrypted = config.get("api_key_encrypted")
    if prefix is not None and encrypted:
        return (prefix, encrypted)
    return (None, None)


def set_global_api_key(raw_key: str) -> None:
    """Encrypt and save API key to ~/.synapse/config.json."""
    from utils.api_key_store import encrypt_api_key

    ensure_global_synapse_dir()
    config = load_global_config()
    prefix, encrypted = encrypt_api_key(raw_key)
    config["api_key_prefix"] = prefix
    config["api_key_encrypted"] = encrypted
    save_global_config(config)


def resolve_api_key(working_dir: Optional[str] = None) -> Optional[str]:
    """
    Resolve API key for gRPC metadata. Precedence: SYNAPSE_API_KEY env > project > global.

    Returns the raw key, or None if not set or decryption fails (e.g. config copied to another machine).
    """
    env_key = os.environ.get("SYNAPSE_API_KEY", "").strip()
    if env_key:
        return env_key

    from utils.api_key_store import decrypt_api_key

    if working_dir:
        _, encrypted = get_project_api_key_encrypted(working_dir)
        if encrypted:
            try:
                return decrypt_api_key(encrypted)
            except (InvalidToken, ValueError):
                pass

    prefix, encrypted = get_global_api_key_encrypted()
    if encrypted:
        try:
            return decrypt_api_key(encrypted)
        except (InvalidToken, ValueError):
            pass

    return None


def get_api_key_display(working_dir: Optional[str] = None) -> Tuple[str, str]:
    """
    Get safe display strings for project and global API key (prefix + asterisks).
    Returns (project_display, global_display).
    """
    from utils.api_key_store import format_api_key_display

    project_prefix, _ = (
        get_project_api_key_encrypted(working_dir or "")
        if working_dir
        else (None, None)
    )
    global_prefix, _ = get_global_api_key_encrypted()
    return (
        format_api_key_display(project_prefix or ""),
        format_api_key_display(global_prefix or ""),
    )


def has_global_api_key() -> bool:
    """True if global config has an encrypted API key."""
    _, enc = get_global_api_key_encrypted()
    return bool(enc)


def has_project_api_key(working_dir: str) -> bool:
    """True if project config has an encrypted API key."""
    _, enc = get_project_api_key_encrypted(working_dir)
    return bool(enc)


def display_config_safe(config: Dict, working_dir: Optional[str] = None) -> None:
    """
    Displays configuration in a safe, readable format.

    Args:
        config: Configuration dictionary
        working_dir: Optional working directory to load backend config from
    """
    print("\n📋 Current Synapse Configuration")
    print("━" * 60)
    print()
    print(f"Version:      {config.get('version', 'Unknown')}")
    print("Initialized:  ✓ Yes")
    print(f"Created:      {config.get('created_at', 'Unknown')}")
    print(f"Last Updated: {config.get('last_updated', 'Unknown')}")
    print()

    # Backend config
    backend = get_backend_config(working_dir)
    if backend.get("url"):
        print(f"Backend:      {backend['url']}")
    else:
        print(f"Backend:      {backend['host']}:{backend['port']}")
    print()
    print("━" * 60)
