"""Context builder — pre-gathers all generation context CLI-side.

Reads source code, resolves exact import paths, and extracts file-level imports
for each selected endpoint before the gRPC build call. Zero network calls.
"""

import ast
import os
from typing import Optional


def build_context_bundle(
    selected_endpoints: list,
    working_dir: str,
    synapse_dir: str,
) -> dict:
    """Build complete context bundle for the generator. Zero network calls.

    Args:
        selected_endpoints: List of EndpointCandidate objects chosen by the user.
        working_dir: Absolute path to the user's project root.
        synapse_dir: Absolute path to the .synapse directory.

    Returns:
        context_bundle dict ready for JSON serialisation and inclusion in
        BuildRequest.context_bundle.
    """
    endpoints = []
    for ep in selected_endpoints:
        source_code = _read_function_source(ep.file_path, ep.name)
        file_imports = _extract_file_level_imports(ep.file_path)

        # Detect whether the function is a class method by parsing the AST
        class_name_val: Optional[str] = None
        class_import_path: Optional[str] = None
        init_source: str = ""
        init_params: list[dict] = []
        wrapping_pattern: str = "direct_call"
        conversion_type: str = ep.conversion_type

        try:
            with open(ep.file_path, "r", encoding="utf-8") as f:
                raw_src = f.read()
            src_lines = raw_src.splitlines()
            tree = ast.parse(raw_src, filename=ep.file_path)
            parent = _find_parent_class(tree, ep.name)
            if parent is not None:
                class_name_val, class_node = parent
                class_import_path = _resolve_import_path(
                    ep.file_path, ep.name, working_dir, class_name=class_name_val
                )
                init_source = _extract_class_init_source(class_node, src_lines)
                init_params = _extract_init_param_manifest(class_node)
                wrapping_pattern = "class_method"
                conversion_type = "class_method"
        except (OSError, SyntaxError):
            pass

        if (
            wrapping_pattern != "class_method"
            and ep.conversion_type == "requires_wrapper"
        ):
            wrapping_pattern = "requires_wrapper"

        import_path = _resolve_import_path(
            ep.file_path, ep.name, working_dir, class_name=class_name_val
        )

        # Relative file path (used by the generator for display / comments)
        try:
            rel_path = os.path.relpath(ep.file_path, working_dir)
        except ValueError:
            rel_path = ep.file_path

        # client_dependency may be an EndpointCandidate ClientDependency object
        # (has .to_dict()) or a plain dict (from DetectedEndpoint deserialization).
        cd = getattr(ep, "client_dependency", None)
        if cd is None:
            client_dep = None
        elif hasattr(cd, "to_dict"):
            client_dep = cd.to_dict()
        elif isinstance(cd, dict):
            client_dep = cd
        else:
            client_dep = None

        used_names = _extract_used_names(ep.file_path, ep.name)
        resolved_imports = _resolve_needed_imports(ep.file_path, used_names)
        parameters = _extract_param_manifest(ep.file_path, ep.name)

        entry = {
            "name": ep.name,
            "class_name": class_name_val,
            "class_import_path": class_import_path,
            "init_source": init_source,
            "wrapping_pattern": wrapping_pattern,
            "signature": ep.signature,
            "source_code": source_code,
            "import_path": import_path,
            "docstring": ep.docstring or "",
            "return_type": ep.return_type or "Any",
            "file_path": rel_path,
            "conversion_type": conversion_type,
            "client_dependency": client_dep,
            "file_imports": file_imports,
            "used_names": used_names,
            "resolved_imports": resolved_imports,
            "parameters": parameters,
            "init_params": init_params,
        }
        endpoints.append(entry)

    return {
        "endpoints": endpoints,
        "project_name": os.path.basename(working_dir),
        "mode": "endpoint_selection",
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_function_source(file_path: str, func_name: str) -> str:
    """Extract the full source of a named function using AST line numbers.

    Walks FunctionDef / AsyncFunctionDef nodes, matches by name, then slices
    the original source lines using node.lineno / node.end_lineno.

    Returns the function source as a string, or an empty string on failure.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        lines = source.splitlines()
        tree = ast.parse(source, filename=file_path)
    except (OSError, SyntaxError):
        return ""

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == func_name:
                # end_lineno is available from Python 3.8+
                start = node.lineno - 1  # 0-indexed
                end = getattr(node, "end_lineno", None)
                if end is not None:
                    return "\n".join(lines[start:end])
                # Fallback: return from start to next top-level node
                return "\n".join(lines[start:])

    return ""


def _find_parent_class(tree: ast.Module, func_name: str) -> Optional[tuple]:
    """Walk all ClassDef nodes. If a method named func_name is found inside,
    return (class_name, class_node). Otherwise return None.
    """
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if item.name == func_name:
                        return node.name, node
    return None


def _extract_class_init_source(class_node: ast.ClassDef, lines: list) -> str:
    """Find __init__ inside the class; return its full source via lineno/end_lineno.
    Returns empty string if no __init__ found.
    """
    for item in class_node.body:
        if (
            isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            and item.name == "__init__"
        ):
            start = item.lineno - 1
            end = getattr(item, "end_lineno", None)
            if end:
                return "\n".join(lines[start:end])
    return ""


def _resolve_import_path(
    file_path: str,
    func_name: str,
    working_dir: str,
    class_name: Optional[str] = None,
) -> str:
    """Resolve the exact import statement for a function or class.

    Primary strategy: pure path arithmetic.
      e.g. working_dir=/proj, file_path=/proj/utils/db.py
        → rel = utils/db.py
        → module = utils.db
        → import_path = "from utils.db import func_name"

    If class_name is provided (method on a class), imports the class instead:
        → "from utils.db import ClassName"

    Handles __init__.py:
        → module = utils (strips trailing .__init__)

    Fallback: jedi (only if primary path contains "../" which means the file
    is outside the working directory, which shouldn't happen in practice but
    is handled gracefully).

    Returns:
        Import statement string, e.g. "from utils.database import search_records"
    """
    try:
        rel = os.path.relpath(file_path, working_dir)
    except ValueError:
        # Different drive on Windows — use basename
        rel = os.path.basename(file_path)

    # If the file is outside working_dir the relative path starts with ".."
    if rel.startswith(".."):
        return _jedi_import_path(file_path, func_name, working_dir)

    # Convert filesystem path to dotted module name
    module = rel.replace(os.sep, ".").removesuffix(".py")
    if module.endswith(".__init__"):
        module = module[: -len(".__init__")]

    import_name = class_name if class_name else func_name
    return f"from {module} import {import_name}"


def _jedi_import_path(
    file_path: str, func_name: str, working_dir: str, class_name: Optional[str] = None
) -> str:
    """Jedi-based fallback for resolving import paths.

    Only invoked when simple path arithmetic fails (file outside working_dir).
    """
    import_name = class_name if class_name else func_name
    try:
        import jedi

        script = jedi.Script(path=file_path, project=jedi.Project(working_dir))
        # Try to find the definition of func_name in the file
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=file_path)
        line_number = None
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name == func_name:
                    line_number = node.lineno
                    break
        if line_number is not None:
            # Use jedi to get the full module name
            names = script.goto(line_number, len(func_name))
            if names:
                module_path = names[0].module_path
                if module_path:
                    rel = os.path.relpath(str(module_path), working_dir)
                    module = rel.replace(os.sep, ".").removesuffix(".py")
                    if module.endswith(".__init__"):
                        module = module[: -len(".__init__")]
                    return f"from {module} import {import_name}"
    except Exception:
        pass

    # Last resort: use the file's basename without extension
    module = os.path.splitext(os.path.basename(file_path))[0]
    return f"from {module} import {import_name}"


def _extract_file_level_imports(file_path: str) -> list[str]:
    """Return module-level import statements from a Python file.

    Walks ast.Import and ast.ImportFrom nodes that are direct children of the
    module body (not nested inside functions or classes).  Returns them as
    source strings, limited to the first 15 to avoid bloating the prompt.

    Returns:
        List of import statement strings.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=file_path)
    except (OSError, SyntaxError):
        return []

    imports: list[str] = []
    for node in tree.body:  # top-level only
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    imports.append(f"import {alias.name} as {alias.asname}")
                else:
                    imports.append(f"import {alias.name}")
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            names = ", ".join(
                (f"{a.name} as {a.asname}" if a.asname else a.name) for a in node.names
            )
            dots = "." * (node.level or 0)
            imports.append(f"from {dots}{module} import {names}")
        if len(imports) >= 40:
            break

    return imports


def _extract_param_manifest(file_path: str, func_name: str) -> list[dict]:
    """Return one dict per parameter of the named function (excluding self/cls).

    Each dict has: name, type (str), has_default (bool), default (str or None).
    Includes both positional and keyword-only parameters.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=file_path)
    except (OSError, SyntaxError):
        return []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name != func_name:
                continue
            args = node.args
            n_pos = len(args.args)
            n_defaults = len(args.defaults)
            default_offset = n_pos - n_defaults

            params: list[dict] = []
            for i, arg in enumerate(args.args):
                if arg.arg in ("self", "cls"):
                    continue
                d_idx = i - default_offset
                has_default = d_idx >= 0
                default_val = ast.unparse(args.defaults[d_idx]) if has_default else None
                ann = ast.unparse(arg.annotation) if arg.annotation else ""
                params.append({
                    "name": arg.arg,
                    "type": ann,
                    "has_default": has_default,
                    "default": default_val,
                })

            # keyword-only args (after *)
            for arg, kw_default in zip(args.kwonlyargs, args.kw_defaults):
                ann = ast.unparse(arg.annotation) if arg.annotation else ""
                has_default = kw_default is not None
                params.append({
                    "name": arg.arg,
                    "type": ann,
                    "has_default": has_default,
                    "default": ast.unparse(kw_default) if has_default else None,
                    "kwonly": True,
                })

            return params
    return []


def _extract_init_param_manifest(class_node: ast.ClassDef) -> list[dict]:
    """Return param manifest for __init__ of the given class (excluding self)."""
    for item in class_node.body:
        if (
            isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            and item.name == "__init__"
        ):
            args = item.args
            n_pos = len(args.args)
            n_defaults = len(args.defaults)
            default_offset = n_pos - n_defaults

            params: list[dict] = []
            for i, arg in enumerate(args.args):
                if arg.arg in ("self", "cls"):
                    continue
                d_idx = i - default_offset
                has_default = d_idx >= 0
                default_val = ast.unparse(args.defaults[d_idx]) if has_default else None
                ann = ast.unparse(arg.annotation) if arg.annotation else ""
                params.append({
                    "name": arg.arg,
                    "type": ann,
                    "has_default": has_default,
                    "default": default_val,
                })
            return params
    return []


_PYTHON_BUILTINS: frozenset = frozenset(
    dir(__builtins__) if isinstance(__builtins__, dict) else dir(__builtins__)
) | {
    "Optional", "Any", "Union", "List", "Dict", "Tuple", "Set",
    "int", "str", "float", "bool", "bytes", "list", "dict", "tuple", "set",
    "type", "object", "super", "None", "True", "False",
}


def _extract_used_names(file_path: str, func_name: str) -> list[str]:
    """Return non-builtin names referenced inside the named function's body.

    Collects both direct Name references (e.g. `OpenSearch`) AND the root
    objects of attribute chains (e.g. `redis` from `redis.Redis()`, `os` from
    `os.environ`, `json` from `json.dumps`).  This ensures module-level imports
    used via dotted access are included in resolved_imports.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=file_path)
    except (OSError, SyntaxError):
        return []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name != func_name:
                continue
            names: set[str] = set()
            for child in ast.walk(node):
                if isinstance(child, ast.Name) and child.id not in _PYTHON_BUILTINS:
                    names.add(child.id)
                elif isinstance(child, ast.Attribute):
                    # Collect the root object of an attribute chain:
                    # json.dumps → root is ast.Name("json")
                    # os.environ.get → root is ast.Name("os")
                    root = child.value
                    while isinstance(root, ast.Attribute):
                        root = root.value
                    if isinstance(root, ast.Name) and root.id not in _PYTHON_BUILTINS:
                        names.add(root.id)
            return sorted(names)
    return []


def _resolve_needed_imports(file_path: str, used_names: list[str]) -> dict[str, str]:
    """Return {name: import_statement} for each used_name found in the file's imports."""
    if not used_names:
        return {}
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
        tree = ast.parse(source, filename=file_path)
    except (OSError, SyntaxError):
        return {}

    name_to_stmt: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                effective = alias.asname if alias.asname else alias.name.split(".")[0]
                stmt = f"import {alias.name}" + (f" as {alias.asname}" if alias.asname else "")
                name_to_stmt[effective] = stmt
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            dots = "." * (node.level or 0)
            for alias in node.names:
                effective = alias.asname if alias.asname else alias.name
                stmt = f"from {dots}{module} import {alias.name}" + (
                    f" as {alias.asname}" if alias.asname else ""
                )
                name_to_stmt[effective] = stmt

    used_set = set(used_names)
    return {name: name_to_stmt[name] for name in used_set if name in name_to_stmt}
