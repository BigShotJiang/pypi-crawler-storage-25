"""Codebase analysis utilities for scanning and parsing Python projects"""

import ast
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple


@dataclass
class FunctionInfo:
    """Information about a function or method"""

    name: str
    line_number: int
    signature: str
    docstring: str
    is_async: bool
    parameters: List[str]
    return_type: str


@dataclass
class ClassInfo:
    """Information about a class"""

    name: str
    line_number: int
    docstring: str
    methods: List[FunctionInfo]
    bases: List[str]


@dataclass
class ModuleInfo:
    """Information about a Python module"""

    file_path: str
    module_name: str
    imports: List[str]
    classes: List[ClassInfo]
    functions: List[FunctionInfo]


def scan_project_structure(
    working_dir: str, ignore_dirs: List[str] = None
) -> Dict[str, Any]:
    """
    Scans entire project and builds directory tree

    Args:
        working_dir: Root directory to scan
        ignore_dirs: List of directory names to ignore (default: common ignore patterns)

    Returns:
        Dictionary with directory tree and file lists
    """
    if ignore_dirs is None:
        ignore_dirs = [
            "__pycache__",
            ".git",
            ".synapse",
            "node_modules",
            "venv",
            "env",
            ".venv",
            "dist",
            "build",
            ".egg-info",
            ".pytest_cache",
            ".mypy_cache",
            ".tox",
        ]

    directories = []
    python_files = []
    tree_lines = []

    def should_ignore(path: str) -> bool:
        """Check if path should be ignored"""
        path_parts = Path(path).parts
        return any(ignore_dir in path_parts for ignore_dir in ignore_dirs)

    def build_tree(directory: str, prefix: str = "", is_last: bool = True):
        """Recursively build tree structure"""
        try:
            dir_path = Path(directory)

            # Get all entries and sort them
            entries = sorted(dir_path.iterdir(), key=lambda x: (not x.is_dir(), x.name))

            # Filter out ignored directories
            entries = [e for e in entries if not should_ignore(str(e))]

            for i, entry in enumerate(entries):
                is_last_entry = i == len(entries) - 1
                connector = "└── " if is_last_entry else "├── "

                rel_path = os.path.relpath(entry, working_dir)

                if entry.is_dir():
                    tree_lines.append(f"{prefix}{connector}{entry.name}/")
                    directories.append(rel_path)

                    # Recurse into subdirectory
                    extension = "    " if is_last_entry else "│   "
                    build_tree(str(entry), prefix + extension, is_last_entry)
                else:
                    tree_lines.append(f"{prefix}{connector}{entry.name}")

                    # Track Python files
                    if entry.suffix == ".py":
                        python_files.append(rel_path)

        except PermissionError:
            pass

    # Start building tree from root
    root_name = Path(working_dir).name
    tree_lines.append(f"{root_name}/")
    build_tree(working_dir)

    return {
        "tree_structure": "\n".join(tree_lines),
        "directories": directories,
        "python_files": python_files,
    }


def parse_python_file(file_path: str) -> ModuleInfo:
    """
    Parses a single Python file using AST

    Args:
        file_path: Path to Python file

    Returns:
        ModuleInfo object with parsed data
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        tree = ast.parse(content, filename=file_path)

        # Extract imports
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.append(node.module)

        # Extract classes
        classes = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_info = _extract_class_info(node)
                classes.append(class_info)

        # Extract top-level functions
        functions = []
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_info = _extract_function_info(node)
                functions.append(func_info)

        # Get module name from file path
        module_name = Path(file_path).stem

        return ModuleInfo(
            file_path=file_path,
            module_name=module_name,
            imports=list(set(imports)),  # Remove duplicates
            classes=classes,
            functions=functions,
        )

    except (SyntaxError, UnicodeDecodeError):
        # Return empty module info if file cannot be parsed
        return ModuleInfo(
            file_path=file_path,
            module_name=Path(file_path).stem,
            imports=[],
            classes=[],
            functions=[],
        )


def _extract_function_info(node: ast.FunctionDef) -> FunctionInfo:
    """Extracts function information from AST node"""
    # Get parameters
    params = []
    for arg in node.args.args:
        param_str = arg.arg
        if arg.annotation:
            param_str += f": {ast.unparse(arg.annotation)}"
        params.append(param_str)

    # Get return type
    return_type = "Any"
    if node.returns:
        return_type = ast.unparse(node.returns)

    # Build signature
    params_str = ", ".join(params)
    signature = f"def {node.name}({params_str}) -> {return_type}"

    # Get docstring
    docstring = ast.get_docstring(node) or ""

    is_async = isinstance(node, ast.AsyncFunctionDef)

    return FunctionInfo(
        name=node.name,
        line_number=node.lineno,
        signature=signature,
        docstring=docstring,
        is_async=is_async,
        parameters=[arg.arg for arg in node.args.args],
        return_type=return_type,
    )


def _extract_class_info(node: ast.ClassDef) -> ClassInfo:
    """Extracts class information from AST node"""
    # Get base classes
    bases = []
    for base in node.bases:
        bases.append(ast.unparse(base))

    # Get methods
    methods = []
    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            method_info = _extract_function_info(item)
            methods.append(method_info)

    # Get docstring
    docstring = ast.get_docstring(node) or ""

    return ClassInfo(
        name=node.name,
        line_number=node.lineno,
        docstring=docstring,
        methods=methods,
        bases=bases,
    )


def parse_python_files(working_dir: str, python_files: List[str]) -> List[ModuleInfo]:
    """
    Parses all Python files in the project

    Args:
        working_dir: Root directory of project
        python_files: List of relative paths to Python files

    Returns:
        List of ModuleInfo objects
    """
    modules = []

    for py_file in python_files:
        full_path = os.path.join(working_dir, py_file)
        module_info = parse_python_file(full_path)
        modules.append(module_info)

    return modules


def generate_project_schema(
    scan_results: Dict[str, Any], modules: List[ModuleInfo]
) -> str:
    """
    Generates formatted project schema text

    Args:
        scan_results: Results from scan_project_structure
        modules: List of parsed module information

    Returns:
        Formatted schema text
    """
    lines = []

    # Header
    lines.append("=" * 80)
    lines.append("PROJECT SCHEMA")
    lines.append("=" * 80)
    lines.append("")

    # Directory structure
    lines.append("DIRECTORY STRUCTURE:")
    lines.append("-" * 80)
    lines.append(scan_results["tree_structure"])
    lines.append("")

    # Module details
    lines.append("=" * 80)
    lines.append("MODULE DETAILS:")
    lines.append("=" * 80)
    lines.append("")

    for module in modules:
        if not module.classes and not module.functions:
            continue  # Skip empty modules

        lines.append(f"Module: {module.module_name}")
        lines.append(f"File: {module.file_path}")
        lines.append("-" * 80)

        # Imports
        if module.imports:
            lines.append(f"Imports: {', '.join(module.imports[:10])}")
            if len(module.imports) > 10:
                lines.append(f"  ... and {len(module.imports) - 10} more")
            lines.append("")

        # Classes
        if module.classes:
            lines.append(f"Classes ({len(module.classes)}):")
            for cls in module.classes:
                bases_str = f"({', '.join(cls.bases)})" if cls.bases else ""
                lines.append(f"  • {cls.name}{bases_str} [line {cls.line_number}]")
                if cls.docstring:
                    doc_preview = cls.docstring.split("\n")[0][:60]
                    lines.append(f"    {doc_preview}")
                if cls.methods:
                    lines.append(
                        f"    Methods: {', '.join([m.name for m in cls.methods])}"
                    )
            lines.append("")

        # Functions
        if module.functions:
            lines.append(f"Functions ({len(module.functions)}):")
            for func in module.functions:
                async_prefix = "async " if func.is_async else ""
                lines.append(
                    f"  • {async_prefix}{func.name}({', '.join(func.parameters)}) -> {func.return_type}"
                )
                if func.docstring:
                    doc_preview = func.docstring.split("\n")[0][:60]
                    lines.append(f"    {doc_preview}")
            lines.append("")

        lines.append("")

    return "\n".join(lines)


def generate_statistics_json(
    scan_results: Dict[str, Any], modules: List[ModuleInfo]
) -> Dict[str, Any]:
    """
    Creates JSON with module/file/class counts

    Args:
        scan_results: Results from scan_project_structure
        modules: List of parsed module information

    Returns:
        Statistics dictionary
    """
    total_classes = sum(len(module.classes) for module in modules)
    total_functions = sum(len(module.functions) for module in modules)
    total_methods = sum(
        sum(len(cls.methods) for cls in module.classes) for module in modules
    )

    # Count total lines in all Python files
    total_lines = 0
    for module in modules:
        try:
            with open(module.file_path, "r", encoding="utf-8") as f:
                total_lines += sum(1 for _ in f)
        except (IOError, OSError):
            pass  # Skip files that can't be read

    # Count non-empty modules (modules with classes or functions)
    non_empty_modules = [m for m in modules if m.classes or m.functions]

    statistics = {
        "project_name": (
            Path(scan_results.get("root_dir", "project")).name
            if "root_dir" in scan_results
            else "project"
        ),
        "directory_count": len(scan_results["directories"]) + 1,  # +1 for root
        "file_count": len(scan_results["python_files"]),
        "total_lines_analyzed": total_lines,
        "module_count": len(non_empty_modules),
        "class_count": total_classes,
        "function_count": total_functions,
        "method_count": total_methods,
        "total_callable_count": total_functions + total_methods,
        "modules": [
            {
                "name": module.module_name,
                "file": module.file_path,
                "classes": len(module.classes),
                "functions": len(module.functions),
                "imports": len(module.imports),
            }
            for module in non_empty_modules
        ],
    }

    return statistics


def analyze_codebase(working_dir: str) -> Tuple[str, Dict[str, Any]]:
    """
    Complete codebase analysis - main entry point

    Args:
        working_dir: Root directory of project to analyze

    Returns:
        Tuple of (schema_text, statistics_dict)
    """
    # Step 1: Scan project structure
    scan_results = scan_project_structure(working_dir)
    scan_results["root_dir"] = working_dir

    # Step 2: Parse all Python files
    modules = parse_python_files(working_dir, scan_results["python_files"])

    # Step 3: Generate schema
    schema_text = generate_project_schema(scan_results, modules)

    # Step 4: Generate statistics
    statistics = generate_statistics_json(scan_results, modules)

    return schema_text, statistics


def save_analysis_results(
    synapse_dir: str, schema_text: str, statistics: Dict[str, Any]
) -> None:
    """
    Saves analysis results to .synapse directory

    Args:
        synapse_dir: Path to .synapse directory
        schema_text: Project schema text
        statistics: Statistics dictionary
    """
    # Ensure synapse directory exists
    os.makedirs(synapse_dir, exist_ok=True)

    # Save schema
    schema_path = os.path.join(synapse_dir, "project_schema.txt")
    with open(schema_path, "w", encoding="utf-8") as f:
        f.write(schema_text)

    # Save statistics
    stats_path = os.path.join(synapse_dir, "statistics.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(statistics, f, indent=2)
