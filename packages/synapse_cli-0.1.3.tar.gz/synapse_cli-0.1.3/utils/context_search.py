"""Codebase context search utility for traversing codebase and gathering context"""

import os
import re
from typing import Any, Dict, List, Optional, Set

from utils.code_indexer import get_all_indexed_items, search_code
from utils.codebase_analyzer import ModuleInfo, parse_python_file
from utils.search_ops import grep_search


def search_codebase_context(
    query: str,
    working_dir: str,
    max_results: int = 5,
    max_depth: int = 3,
    include_pattern: Optional[str] = "*.py",
    exclude_pattern: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Search codebase for context related to a query using semantic search.

    Uses Qdrant vector database for semantic similarity search on code chunks.
    Falls back to grep-based search if vector database is not available.

    Args:
        query: Search query (keywords, function names, module names, etc.)
        working_dir: Root directory to search in
        max_results: Maximum number of results to return (default: 5)
        max_depth: Maximum depth for following imports/references (used in fallback)
        include_pattern: File pattern to include (default: "*.py") (used in fallback)
        exclude_pattern: File pattern to exclude (used in fallback)

    Returns:
        Dictionary with:
        - context_snippets: List of code snippets with file paths and line numbers
        - function_signatures: List of function signatures found
        - related_files: List of related file paths
        - query: The original query
        - total_results: Number of results found
    """
    synapse_dir = os.path.join(working_dir, ".synapse")

    # Try semantic search with Qdrant first
    # try:
    semantic_results = search_code(
        query=query,
        qdrant_path=synapse_dir,
        collection_name="code_context",
        top_k=max_results,
    )

    try:
        if semantic_results:
            # Convert semantic results to the expected format
            context_snippets = []
            function_signatures = []
            related_files = set()

            for result in semantic_results:
                related_files.add(result["file_path"])

                # Add to context snippets
                context_snippets.append(
                    {
                        "file": result["file_path"],
                        "content": result["code"],
                        "type": result["type"],
                        "name": result["name"],
                        "signature": result["signature"],
                        "start_line": result["start_line"],
                        "end_line": result["end_line"],
                        "line_number": result["start_line"],
                        "score": result.get("score", 0.0),
                    }
                )

                # Add function/class signatures
                if result["type"] in ("function", "class"):
                    function_signatures.append(
                        {
                            "name": result["name"],
                            "signature": result["signature"],
                            "file": result["file_path"],
                            "start_line": result["start_line"],
                            "end_line": result["end_line"],
                            "line_number": result["start_line"],
                            "code": result["code"],
                            "type": result["type"],
                            "score": result.get("score", 0.0),
                        }
                    )
            return {
                "context_snippets": context_snippets,
                "function_signatures": function_signatures,
                "related_files": list(related_files),
                "import_chain": [],
                "query": query,
                "total_results": len(context_snippets),
                "search_type": "semantic",
            }
    except Exception as e:
        # Fall back to grep-based search if semantic search fails
        print(e)
        print("Semantic search failed, falling back to grep-based search")
        # Fallback to grep-based search
        return _grep_based_search(
            query=query,
            working_dir=working_dir,
            max_results=max_results,
            max_depth=max_depth,
            include_pattern=include_pattern,
            exclude_pattern=exclude_pattern,
        )


def _grep_based_search(
    query: str,
    working_dir: str,
    max_results: int = 50,
    max_depth: int = 3,
    include_pattern: Optional[str] = "*.py",
    exclude_pattern: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Fallback grep-based search for codebase context.

    Used when semantic search is not available (e.g., before running synapse analyze).
    """
    visited_files: Set[str] = set()
    context_snippets: List[Dict[str, Any]] = []
    function_signatures: List[Dict[str, Any]] = []
    related_files: Set[str] = set()
    import_chain: List[str] = []

    # Step 1: Parse query to extract keywords, function names, module names
    keywords = _extract_keywords(query)

    # Step 2: Initial grep search
    grep_results, success = grep_search(
        query=keywords.get("pattern", query),
        case_sensitive=False,
        include_pattern=include_pattern,
        exclude_pattern=exclude_pattern,
        working_dir=working_dir,
    )

    if not success:
        return {
            "context_snippets": [],
            "function_signatures": [],
            "related_files": [],
            "import_chain": [],
            "error": "Grep search failed",
            "search_type": "grep",
        }

    # Step 3: Process grep results and extract context
    for result in grep_results[:max_results]:
        file_path = result["file"]
        line_number = result["line_number"]

        if file_path in visited_files:
            continue

        related_files.add(file_path)

        # Read file content around the match
        context = _get_file_context(file_path, line_number, working_dir)
        if context:
            context_snippets.append(
                {
                    "file": file_path,
                    "line_number": line_number,
                    "content": context["content"],
                    "surrounding_lines": context["surrounding"],
                    "relevance_score": _calculate_relevance(query, context["content"]),
                }
            )

        # Parse file to extract function signatures and imports
        if file_path.endswith(".py"):
            module_info = parse_python_file(file_path)

            # Extract function signatures
            for func in module_info.functions:
                if _is_relevant(func.name, query) or _is_relevant(
                    func.signature, query
                ):
                    function_signatures.append(
                        {
                            "name": func.name,
                            "signature": func.signature,
                            "file": file_path,
                            "line_number": func.line_number,
                            "parameters": func.parameters,
                            "return_type": func.return_type,
                            "docstring": func.docstring,
                            "is_async": func.is_async,
                        }
                    )

            # Extract class methods
            for cls in module_info.classes:
                for method in cls.methods:
                    if _is_relevant(method.name, query) or _is_relevant(
                        method.signature, query
                    ):
                        function_signatures.append(
                            {
                                "name": f"{cls.name}.{method.name}",
                                "signature": method.signature,
                                "file": file_path,
                                "line_number": method.line_number,
                                "parameters": method.parameters,
                                "return_type": method.return_type,
                                "docstring": method.docstring,
                                "is_async": method.is_async,
                                "class": cls.name,
                            }
                        )

            # Follow imports recursively
            if max_depth > 0:
                _follow_imports(
                    module_info,
                    file_path,
                    working_dir,
                    visited_files,
                    related_files,
                    import_chain,
                    max_depth - 1,
                    query,
                )

    # Step 4: Sort by relevance
    context_snippets.sort(key=lambda x: x["relevance_score"], reverse=True)
    function_signatures.sort(
        key=lambda x: _calculate_relevance(query, x["signature"]), reverse=True
    )

    return {
        "context_snippets": context_snippets[:max_results],
        "function_signatures": function_signatures[:max_results],
        "related_files": list(related_files),
        "import_chain": import_chain,
        "query": query,
        "total_results": len(context_snippets),
        "search_type": "grep",
    }


def _extract_keywords(query: str) -> Dict[str, Any]:
    """Extract keywords, function names, and module names from query."""
    # Extract potential function names (words followed by parentheses or camelCase)
    function_pattern = (
        r"\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(|([a-z][a-zA-Z0-9]*[A-Z][a-zA-Z0-9]*)"
    )
    function_matches = re.findall(function_pattern, query)
    function_names = [m[0] or m[1] for m in function_matches if m[0] or m[1]]

    # Extract module names (words with dots)
    module_pattern = r"\b([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)+)"
    module_names = re.findall(module_pattern, query)

    # Extract keywords (words that are not function/module names)
    words = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", query)
    keywords = [
        w
        for w in words
        if w not in function_names
        and w.lower()
        not in [
            "the",
            "a",
            "an",
            "and",
            "or",
            "in",
            "on",
            "at",
            "to",
            "for",
            "of",
            "with",
            "from",
            "as",
            "is",
            "are",
            "was",
            "were",
        ]
    ]

    # Create search pattern
    pattern_parts = []
    if function_names:
        pattern_parts.extend(function_names)
    if module_names:
        pattern_parts.extend(module_names)
    if keywords:
        pattern_parts.extend(keywords[:5])  # Limit to top 5 keywords

    pattern = (
        "|".join([re.escape(p) for p in pattern_parts]) if pattern_parts else query
    )

    return {
        "keywords": keywords,
        "function_names": function_names,
        "module_names": module_names,
        "pattern": pattern,
    }


def _get_file_context(
    file_path: str, line_number: int, working_dir: str, context_lines: int = 10
) -> Optional[Dict[str, Any]]:
    """Get context around a specific line in a file."""
    try:
        abs_path = (
            os.path.join(working_dir, file_path)
            if not os.path.isabs(file_path)
            else file_path
        )

        if not os.path.exists(abs_path):
            return None

        with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        if line_number < 1 or line_number > len(lines):
            return None

        # Get surrounding lines
        start = max(0, line_number - context_lines - 1)
        end = min(len(lines), line_number + context_lines)

        surrounding = "".join(lines[start:end])
        content = lines[line_number - 1].rstrip()

        return {
            "content": content,
            "surrounding": surrounding,
            "start_line": start + 1,
            "end_line": end,
        }
    except Exception:
        return None


def _calculate_relevance(query: str, text: str) -> float:
    """Calculate relevance score between query and text."""
    if not text:
        return 0.0

    query_lower = query.lower()
    text_lower = text.lower()

    # Exact match gets highest score
    if query_lower in text_lower:
        return 1.0

    # Count keyword matches
    query_words = set(re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", query_lower))
    text_words = set(re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", text_lower))

    if not query_words:
        return 0.0

    matches = len(query_words.intersection(text_words))
    return matches / len(query_words)


def _is_relevant(text: str, query: str) -> bool:
    """Check if text is relevant to query."""
    if not text or not query:
        return False

    text_lower = text.lower()
    query_lower = query.lower()

    # Check for exact match or keyword matches
    if query_lower in text_lower:
        return True

    query_words = set(re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", query_lower))
    text_words = set(re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", text_lower))

    return len(query_words.intersection(text_words)) > 0


def _follow_imports(
    module_info: ModuleInfo,
    current_file: str,
    working_dir: str,
    visited_files: Set[str],
    related_files: Set[str],
    import_chain: List[str],
    max_depth: int,
    query: str,
) -> None:
    """Recursively follow imports to gather related context."""
    if max_depth <= 0 or current_file in visited_files:
        return

    visited_files.add(current_file)
    import_chain.append(current_file)

    for import_name in module_info.imports:
        # Try to resolve import to file path
        import_file = _resolve_import(import_name, current_file, working_dir)

        if (
            import_file
            and import_file not in visited_files
            and os.path.exists(import_file)
        ):
            related_files.add(import_file)

            # Parse imported file
            imported_module = parse_python_file(import_file)

            # Check if imported module has relevant content
            if _module_is_relevant(imported_module, query):
                # Get context from imported file
                if imported_module.functions:
                    for func in imported_module.functions[
                        :3
                    ]:  # Limit to first 3 functions
                        if _is_relevant(func.name, query):
                            context = _get_file_context(
                                import_file, func.line_number, working_dir
                            )
                            if context:
                                related_files.add(import_file)

            # Recursively follow imports if depth allows
            if max_depth > 0:
                _follow_imports(
                    imported_module,
                    import_file,
                    working_dir,
                    visited_files,
                    related_files,
                    import_chain,
                    max_depth - 1,
                    query,
                )


def _resolve_import(
    import_name: str, current_file: str, working_dir: str
) -> Optional[str]:
    """Resolve import name to file path."""
    # Handle relative imports
    if import_name.startswith("."):
        current_dir = os.path.dirname(current_file)
        parts = import_name.split(".")
        # Count leading dots for relative depth
        depth = len([p for p in parts if not p])
        base_path = current_dir
        for _ in range(depth - 1):
            base_path = os.path.dirname(base_path)

        module_name = parts[-1] if parts[-1] else os.path.basename(current_dir)
        potential_paths = [
            os.path.join(base_path, f"{module_name}.py"),
            os.path.join(base_path, module_name, "__init__.py"),
        ]
    else:
        # Absolute import
        parts = import_name.split(".")
        module_name = parts[0]

        # Try to find in working directory
        potential_paths = [
            os.path.join(working_dir, f"{module_name}.py"),
            os.path.join(working_dir, module_name, "__init__.py"),
            (
                os.path.join(working_dir, *parts[:-1], f"{parts[-1]}.py")
                if len(parts) > 1
                else None
            ),
            os.path.join(working_dir, *parts, "__init__.py"),
        ]
        potential_paths = [p for p in potential_paths if p]

    # Check if any potential path exists
    for path in potential_paths:
        abs_path = os.path.abspath(path)
        if os.path.exists(abs_path):
            return abs_path

    return None


def _module_is_relevant(module_info: ModuleInfo, query: str) -> bool:
    """Check if module contains relevant content."""
    # Check functions
    for func in module_info.functions:
        if _is_relevant(func.name, query) or _is_relevant(func.signature, query):
            return True

    # Check classes
    for cls in module_info.classes:
        if _is_relevant(cls.name, query):
            return True
        for method in cls.methods:
            if _is_relevant(method.name, query):
                return True

    return False


def format_context_results(results: Dict[str, Any]) -> str:
    """Format context search results as a readable string."""
    output = []

    search_type = results.get("search_type", "unknown")
    output.append(f"Context Search Results for: {results.get('query', 'Unknown')}")
    output.append(f"Search Type: {search_type}")
    output.append("=" * 80)
    output.append("")

    # Function signatures (for semantic search, these include code)
    if results.get("function_signatures"):
        output.append(f"Relevant Code ({len(results['function_signatures'])}):")
        output.append("-" * 80)
        for sig in results["function_signatures"][:10]:  # Limit to top 10
            output.append(f"  File: {sig['file']}")
            output.append(f"  Line: {sig['line_number']}")
            output.append(f"  Type: {sig.get('type', 'unknown')}")
            if sig.get("score"):
                output.append(f"  Relevance: {sig['score']:.3f}")
            output.append(f"  Signature: {sig['signature']}")
            if sig.get("code"):
                # Include full code for better context
                output.append("  Code:")
                for line in sig["code"].split("\n")[:20]:  # Limit to 20 lines
                    output.append(f"    {line}")
                if len(sig["code"].split("\n")) > 20:
                    output.append("    ... (truncated)")
            elif sig.get("docstring"):
                doc_preview = sig["docstring"].split("\n")[0][:60]
                output.append(f"    {doc_preview}...")
            output.append("")

    # Context snippets (detailed view)
    if results.get("context_snippets") and not results.get("function_signatures"):
        output.append(f"Code Context ({len(results['context_snippets'])}):")
        output.append("-" * 80)
        for snippet in results["context_snippets"][:10]:  # Limit to top 10
            output.append(f"  File: {snippet['file']}")
            output.append(f"  Line: {snippet['line_number']}")
            if snippet.get("type"):
                output.append(f"  Type: {snippet['type']}")
            if snippet.get("name"):
                output.append(f"  Name: {snippet['name']}")
            if snippet.get("relevance_score"):
                output.append(f"  Relevance: {snippet['relevance_score']:.3f}")
            output.append(f"  Content: {snippet['content'][:200]}...")
            output.append("")

    # Related files
    if results.get("related_files"):
        output.append(f"Related Files ({len(results['related_files'])}):")
        output.append("-" * 80)
        for file_path in results["related_files"][:20]:  # Limit to top 20
            output.append(f"  {file_path}")

    return "\n".join(output)


def validate_query_relevance(
    query: str,
    working_dir: str,
    min_good_results: int = 3,
    min_score: float = 0.35,  # Minimum cosine similarity score threshold
) -> Dict[str, Any]:
    """
    Validate if the user query has sufficient context in the codebase.

    Uses semantic search to determine if the query can be meaningfully
    processed by the AI agents. Filters results by similarity score to
    ensure only truly relevant matches are counted.

    Args:
        query: User's query for MCP server generation
        working_dir: Project working directory
        min_good_results: Minimum HIGH-QUALITY results needed for "valid" status (default: 3)
        min_score: Minimum similarity score to consider a result relevant (default: 0.35)

    Returns:
        Dictionary with:
        - status: "valid" (3+), "insufficient" (0), or "uncertain" (1-2)
        - total_results: Number of results found
        - high_quality_results: Number of results above min_score threshold
        - results: List of search results for display
        - message: Human-readable status message
        - query: The original query
    """
    try:
        results = search_codebase_context(
            query=query, working_dir=working_dir, max_results=5
        )

        total_results = results.get("total_results", 0)
        context_snippets = results.get("context_snippets", [])
        function_signatures = results.get("function_signatures", [])

        # Use function_signatures if available, otherwise context_snippets
        display_results = (
            function_signatures if function_signatures else context_snippets
        )

        # Filter results by score - only count high-quality matches
        high_quality_results = [
            r for r in display_results if r.get("score", 0) >= min_score
        ]
        high_quality_count = len(high_quality_results)

        # Also track the best score for diagnostics
        best_score = max((r.get("score", 0) for r in display_results), default=0)

        if high_quality_count >= min_good_results:
            return {
                "status": "valid",
                "total_results": total_results,
                "high_quality_results": high_quality_count,
                "results": high_quality_results,
                "message": f"Found {high_quality_count} relevant code elements for your query",
                "query": query,
                "best_score": best_score,
            }
        elif high_quality_count == 0:
            # No high-quality results - either truly no results or all below threshold
            if total_results == 0:
                message = "No functions, classes, or code patterns match this query."
            else:
                message = "⚠️ No relevant code found. The codebase may not have functionality related to your query."

            return {
                "status": "insufficient",
                "total_results": total_results,
                "high_quality_results": 0,
                "results": display_results[
                    :3
                ],  # Show top 3 for context even if low quality
                "message": message,
                "query": query,
                "best_score": best_score,
            }
        else:
            # 1-2 high-quality results - uncertain
            return {
                "status": "uncertain",
                "total_results": total_results,
                "high_quality_results": high_quality_count,
                "results": high_quality_results,
                "message": f"Found {high_quality_count} potentially relevant element(s)",
                "query": query,
                "best_score": best_score,
            }

    except Exception as e:
        # If validation fails, return uncertain to let user decide
        return {
            "status": "uncertain",
            "total_results": 0,
            "high_quality_results": 0,
            "results": [],
            "message": f"Could not validate query: {str(e)}",
            "query": query,
            "error": str(e),
        }


def get_available_components(
    working_dir: str, max_items: int = 20
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Get available code components from the indexed codebase.

    Returns grouped lists of functions and classes that can be exposed as MCP tools.

    Args:
        working_dir: Project working directory
        max_items: Maximum number of items per category to return

    Returns:
        Dictionary with:
        - functions: List of function info dicts
        - classes: List of class info dicts
        - total_count: Total number of indexed items
    """
    synapse_dir = os.path.join(working_dir, ".synapse")

    try:
        all_items = get_all_indexed_items(
            qdrant_path=synapse_dir, collection_name="code_context", limit=100
        )

        functions = []
        classes = []

        for item in all_items:
            item_type = item.get("type", "")

            # Make file path relative for cleaner display
            file_path = item.get("file_path", "")
            if file_path.startswith(working_dir):
                file_path = os.path.relpath(file_path, working_dir)

            component = {
                "name": item.get("name", ""),
                "signature": item.get("signature", ""),
                "file": file_path,
                "line": item.get("start_line", 0),
            }

            if item_type == "function":
                functions.append(component)
            elif item_type == "class":
                classes.append(component)

        # Sort by name and limit
        functions.sort(key=lambda x: x["name"].lower())
        classes.sort(key=lambda x: x["name"].lower())

        return {
            "functions": functions[:max_items],
            "classes": classes[:max_items],
            "total_count": len(all_items),
            "functions_total": len(functions),
            "classes_total": len(classes),
        }

    except Exception as e:
        return {
            "functions": [],
            "classes": [],
            "total_count": 0,
            "functions_total": 0,
            "classes_total": 0,
            "error": str(e),
        }
