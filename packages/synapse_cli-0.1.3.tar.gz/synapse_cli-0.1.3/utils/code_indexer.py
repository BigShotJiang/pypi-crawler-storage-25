"""Code indexer for semantic search using tree-sitter and Qdrant"""

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import tree_sitter
import tree_sitter_python as tspython
from fastembed import TextEmbedding
from qdrant_client import QdrantClient, models
from qdrant_client.http.models import Distance, VectorParams
from tree_sitter import Parser

# Global embedding model (lazy loaded)
_embed_model = None


def get_embed_model() -> TextEmbedding:
    """Get or initialize the embedding model (lazy loading)"""
    global _embed_model
    if _embed_model is None:
        _embed_model = TextEmbedding(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
    return _embed_model


def setup_python_parser() -> Parser:
    """Initialize and return a configured tree-sitter parser for Python"""
    PY_LANGUAGE = tree_sitter.Language(tspython.language())
    parser = Parser(PY_LANGUAGE)
    return parser


def extract_signature(node, code_bytes: bytes) -> str:
    """Extract function/class signature (first line)"""
    code = code_bytes[node.start_byte : node.end_byte].decode("utf-8")
    return code.split("\n")[0]


def extract_chunks(
    node,
    code_bytes: bytes,
    file_path: str,
    chunks: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """
    Recursively extract chunks from AST

    Args:
        node: tree-sitter node
        code_bytes: Source code as bytes
        file_path: Path to the source file
        chunks: List to accumulate chunks (used for recursion)

    Returns:
        List of chunk dictionaries
    """
    if chunks is None:
        chunks = []

    file_name = Path(file_path).name

    if node.type == "function_definition":
        name_node = node.child_by_field_name("name")
        chunks.append(
            {
                "file_path": str(file_path),
                "file_name": file_name,
                "type": "function",
                "name": name_node.text.decode("utf-8") if name_node else "unknown",
                "signature": extract_signature(node, code_bytes),
                "code": code_bytes[node.start_byte : node.end_byte].decode("utf-8"),
                "start_line": node.start_point[0] + 1,
                "end_line": node.end_point[0] + 1,
            }
        )

    elif node.type == "class_definition":
        name_node = node.child_by_field_name("name")
        chunks.append(
            {
                "file_path": str(file_path),
                "file_name": file_name,
                "type": "class",
                "name": name_node.text.decode("utf-8") if name_node else "unknown",
                "signature": extract_signature(node, code_bytes),
                "code": code_bytes[node.start_byte : node.end_byte].decode("utf-8"),
                "start_line": node.start_point[0] + 1,
                "end_line": node.end_point[0] + 1,
            }
        )

    # elif node.type in ("import_statement", "import_from_statement"):
    #     chunks.append({
    #         "file_path": str(file_path),
    #         "file_name": file_name,
    #         "type": "import",
    #         "name": code_bytes[node.start_byte:node.end_byte].decode("utf-8"),
    #         "signature": code_bytes[node.start_byte:node.end_byte].decode("utf-8"),
    #         "code": code_bytes[node.start_byte:node.end_byte].decode("utf-8"),
    #         "start_line": node.start_point[0] + 1,
    #         "end_line": node.end_point[0] + 1,
    #     })

    # Recurse into children
    for child in node.children:
        extract_chunks(child, code_bytes, file_path, chunks)

    return chunks


def index_project(
    root_dir: str, skip_dirs: Optional[Set[str]] = None, verbose: bool = False
) -> List[Dict[str, Any]]:
    """
    Walk directory, parse Python files, return all chunks

    Args:
        root_dir: Root directory to index
        skip_dirs: Set of directory names to skip
        verbose: Whether to print progress

    Returns:
        List of all chunks from the project
    """
    if skip_dirs is None:
        skip_dirs = {
            "__pycache__",
            ".git",
            ".venv",
            "venv",
            "node_modules",
            ".synapse",
            "env",
            ".env",
        }

    parser = setup_python_parser()
    all_chunks = []

    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Skip unwanted directories
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]

        for filename in filenames:
            if filename.endswith(".py"):
                file_path = Path(dirpath) / filename
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        code_bytes = f.read().encode("utf-8")

                    tree = parser.parse(code_bytes)
                    chunks = extract_chunks(tree.root_node, code_bytes, str(file_path))
                    all_chunks.extend(chunks)

                    if verbose:
                        print(f"  ✓ {file_path}: {len(chunks)} chunks")
                except Exception as e:
                    if verbose:
                        print(f"  ✗ {file_path}: {e}")

    return all_chunks


def store_chunks(
    chunks: List[Dict[str, Any]],
    qdrant_path: str,
    collection_name: str = "code_context",
) -> int:
    """
    Generate embeddings and store chunks in Qdrant

    Args:
        chunks: List of code chunks to store
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection

    Returns:
        Number of chunks stored
    """
    if not chunks:
        return 0

    # Initialize Qdrant client
    client = QdrantClient(path=qdrant_path)

    # Recreate collection to ensure fresh index
    if client.collection_exists(collection_name):
        client.delete_collection(collection_name)

    client.create_collection(
        collection_name,
        vectors_config=VectorParams(size=384, distance=Distance.COSINE),
    )

    # Get embedding model
    embed_model = get_embed_model()

    # Generate embeddings (include code for semantic search)
    texts = [f"{c['type']} {c['name']}\n{c['code']}" for c in chunks]
    embeddings = list(embed_model.embed(texts))

    # Create points
    points = [
        models.PointStruct(
            id=i,
            vector=embeddings[i].tolist(),
            payload={
                "file_path": c["file_path"],
                "file_name": c["file_name"],
                "type": c["type"],
                "name": c["name"],
                "signature": c["signature"],
                "code": c["code"],
                "start_line": c["start_line"],
                "end_line": c["end_line"],
            },
        )
        for i, c in enumerate(chunks)
    ]

    # Upsert to Qdrant
    client.upsert(collection_name=collection_name, points=points)

    return len(points)


def search_code(
    query: str, qdrant_path: str, collection_name: str = "code_context", top_k: int = 5
) -> List[Dict[str, Any]]:
    """
    Search for code chunks by semantic similarity

    Args:
        query: Search query text
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection
        top_k: Number of results to return

    Returns:
        List of matching chunks with scores
    """
    # Initialize Qdrant client
    client = QdrantClient(path=qdrant_path)

    # Check if collection exists
    if not client.collection_exists(collection_name):
        return []

    # Get embedding model and encode query
    embed_model = get_embed_model()
    query_vector = list(embed_model.embed([query]))[0].tolist()

    # Request extra results to account for filtering
    request_limit = top_k * 3

    # Search
    results = client.query_points(
        collection_name=collection_name,
        query=query_vector,
        limit=request_limit,
        with_payload=True,
        with_vectors=False,
    )

    # Patterns that indicate MCP server code (to be excluded)
    # These are generated servers, not source code to wrap
    mcp_code_patterns = [
        "@server.tool()",
        "@server.resource(",
        "FastMCP(",
        "from mcp.server.fastmcp import FastMCP",
        "server.run()",
    ]

    # Format results, filtering out MCP server code
    matches = []
    for point in results.points:
        code = point.payload.get("code", "")

        # Skip MCP server code - these are generated, not source
        if any(pattern in code for pattern in mcp_code_patterns):
            continue

        matches.append(
            {
                "file_path": point.payload["file_path"],
                "file_name": point.payload["file_name"],
                "type": point.payload["type"],
                "name": point.payload["name"],
                "signature": point.payload["signature"],
                "code": point.payload["code"],
                "start_line": point.payload["start_line"],
                "end_line": point.payload["end_line"],
                "score": point.score,  # Cosine similarity score from Qdrant
            }
        )

        # Stop once we have enough results
        if len(matches) >= top_k:
            break

    return matches


def get_all_indexed_items(
    qdrant_path: str, collection_name: str = "code_context", limit: int = 100
) -> List[Dict[str, Any]]:
    """
    Get all indexed code items from Qdrant collection.

    Args:
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection
        limit: Maximum number of items to return

    Returns:
        List of all indexed items with their metadata
    """
    # Initialize Qdrant client
    client = QdrantClient(path=qdrant_path)

    # Check if collection exists
    if not client.collection_exists(collection_name):
        return []

    # Scroll through all points (no query, just get items)
    results = client.scroll(
        collection_name=collection_name,
        limit=limit,
        with_payload=True,
        with_vectors=False,
    )

    # Patterns that indicate MCP server code (to be excluded)
    mcp_code_patterns = [
        "@server.tool()",
        "@server.resource(",
        "FastMCP(",
        "from mcp.server.fastmcp import FastMCP",
        "server.run()",
    ]

    # Format results
    items = []
    for point in results[0]:  # results is (points, next_page_offset)
        code = point.payload.get("code", "")

        # Skip MCP server code
        if any(pattern in code for pattern in mcp_code_patterns):
            continue

        items.append(
            {
                "file_path": point.payload.get("file_path", ""),
                "file_name": point.payload.get("file_name", ""),
                "type": point.payload.get("type", ""),
                "name": point.payload.get("name", ""),
                "signature": point.payload.get("signature", ""),
                "start_line": point.payload.get("start_line", 0),
                "end_line": point.payload.get("end_line", 0),
            }
        )

    return items


def create_collection(qdrant_path: str, collection_name: str = "code_context") -> bool:
    """
    Create a Qdrant collection for code context

    Args:
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection

    Returns:
        True if created, False if already exists
    """
    client = QdrantClient(path=qdrant_path)

    if not client.collection_exists(collection_name):
        client.create_collection(
            collection_name,
            vectors_config=VectorParams(size=384, distance=Distance.COSINE),
        )
        return True

    return False


# =============================================================================
# Incremental ETL Functions - Metadata Management
# =============================================================================


def get_index_metadata_path(qdrant_path: str) -> str:
    """
    Get path to the index metadata JSON file.

    Args:
        qdrant_path: Path to Qdrant storage directory (.synapse)

    Returns:
        Path to index_metadata.json
    """
    return os.path.join(qdrant_path, "index_metadata.json")


def load_index_metadata(qdrant_path: str) -> Dict[str, float]:
    """
    Load metadata about when files were last indexed.

    Args:
        qdrant_path: Path to Qdrant storage directory

    Returns:
        Dictionary mapping file_path -> last_indexed_mtime
    """
    meta_path = get_index_metadata_path(qdrant_path)
    if os.path.exists(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def save_index_metadata(qdrant_path: str, metadata: Dict[str, float]) -> None:
    """
    Save index metadata to JSON file.

    Args:
        qdrant_path: Path to Qdrant storage directory
        metadata: Dictionary mapping file_path -> mtime
    """
    meta_path = get_index_metadata_path(qdrant_path)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)


# =============================================================================
# Incremental ETL Functions - Single File Operations
# =============================================================================


def index_single_file(file_path: str, verbose: bool = False) -> List[Dict[str, Any]]:
    """
    Index a single Python file and return its chunks.

    Args:
        file_path: Path to the Python file
        verbose: Whether to print progress

    Returns:
        List of chunks from the file
    """
    if not file_path.endswith(".py"):
        return []

    parser = setup_python_parser()
    chunks = []

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            code_bytes = f.read().encode("utf-8")

        tree = parser.parse(code_bytes)
        chunks = extract_chunks(tree.root_node, code_bytes, str(file_path))

        if verbose:
            print(f"    ✓ Parsed {file_path}: {len(chunks)} chunks")
    except Exception as e:
        if verbose:
            print(f"    ✗ {file_path}: {e}")

    return chunks


def update_file_in_index(
    file_path: str,
    qdrant_path: str,
    collection_name: str = "code_context",
    verbose: bool = False,
) -> int:
    """
    Update vectors for a single file (delete old vectors, add new ones).

    Args:
        file_path: Path to the file to update
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection
        verbose: Whether to print progress

    Returns:
        Number of chunks indexed for this file
    """
    client = QdrantClient(path=qdrant_path)

    # Ensure collection exists
    if not client.collection_exists(collection_name):
        create_collection(qdrant_path, collection_name)

    # Delete existing vectors for this file
    try:
        client.delete(
            collection_name=collection_name,
            points_selector=models.FilterSelector(
                filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="file_path",
                            match=models.MatchValue(value=str(file_path)),
                        )
                    ]
                )
            ),
        )
    except Exception:
        pass  # Collection might be empty or file not indexed yet

    # Index the file
    chunks = index_single_file(file_path, verbose=verbose)

    if not chunks:
        return 0

    # Get embedding model
    embed_model = get_embed_model()

    # Generate embeddings
    texts = [f"{c['type']} {c['name']}\n{c['code']}" for c in chunks]
    embeddings = list(embed_model.embed(texts))

    # Create points with UUID for unique IDs (allows multiple chunks per file)
    points = [
        models.PointStruct(
            id=str(uuid.uuid4()),
            vector=embeddings[i].tolist(),
            payload={
                "file_path": c["file_path"],
                "file_name": c["file_name"],
                "type": c["type"],
                "name": c["name"],
                "signature": c["signature"],
                "code": c["code"],
                "start_line": c["start_line"],
                "end_line": c["end_line"],
            },
        )
        for i, c in enumerate(chunks)
    ]

    # Upsert to Qdrant
    client.upsert(collection_name=collection_name, points=points)

    return len(points)


def delete_file_from_index(
    file_path: str,
    qdrant_path: str,
    collection_name: str = "code_context",
    verbose: bool = False,
) -> bool:
    """
    Remove all vectors for a deleted file.

    Args:
        file_path: Path to the file to remove
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection
        verbose: Whether to print progress

    Returns:
        True if deletion was successful
    """
    client = QdrantClient(path=qdrant_path)

    if not client.collection_exists(collection_name):
        return False

    try:
        client.delete(
            collection_name=collection_name,
            points_selector=models.FilterSelector(
                filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="file_path",
                            match=models.MatchValue(value=str(file_path)),
                        )
                    ]
                )
            ),
        )
        if verbose:
            print(f"    ✗ Removed: {file_path}")
        return True
    except Exception as e:
        if verbose:
            print(f"    ✗ Failed to remove {file_path}: {e}")
        return False


# =============================================================================
# Incremental ETL Functions - Sync Operations
# =============================================================================


def sync_index(
    root_dir: str,
    qdrant_path: str,
    collection_name: str = "code_context",
    skip_patterns: Optional[Set[str]] = None,
    skip_dirs: Optional[Set[str]] = None,
    verbose: bool = False,
) -> Dict[str, int]:
    """
    Sync index with current file state - only re-index modified/new files.

    This is called automatically before build to ensure the vector database
    is up-to-date with any file changes since the last indexing.

    Args:
        root_dir: Root directory to scan
        qdrant_path: Path to Qdrant storage directory
        collection_name: Name of the collection
        skip_patterns: Set of filename patterns to skip (default: {"mcp_server.py"})
        skip_dirs: Set of directory names to skip
        verbose: Whether to print progress

    Returns:
        Dict with counts: {"added": n, "updated": n, "deleted": n, "unchanged": n}
    """
    if skip_patterns is None:
        skip_patterns = {"mcp_server.py"}

    if skip_dirs is None:
        skip_dirs = {
            "__pycache__",
            ".git",
            ".venv",
            "venv",
            "node_modules",
            ".synapse",
            "env",
            ".env",
        }

    # Load last indexed times
    metadata = load_index_metadata(qdrant_path)

    # Find all current Python files
    current_files: Set[str] = set()
    files_to_update: List[str] = []

    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Skip unwanted directories
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]

        for filename in filenames:
            # Only process Python files
            if not filename.endswith(".py"):
                continue

            # Skip specified patterns (e.g., mcp_server.py)
            if filename in skip_patterns:
                continue

            file_path = str(Path(dirpath) / filename)
            current_files.add(file_path)

            # Check if file was modified since last index
            try:
                mtime = os.path.getmtime(file_path)
            except OSError:
                continue

            last_indexed = metadata.get(file_path, 0)

            if mtime > last_indexed:
                files_to_update.append(file_path)

    # Find deleted files (in metadata but not on disk)
    indexed_files = set(metadata.keys())
    deleted_files = indexed_files - current_files

    stats = {
        "added": 0,
        "updated": 0,
        "deleted": 0,
        "unchanged": len(current_files) - len(files_to_update),
    }

    # Early return if nothing to do
    if not files_to_update and not deleted_files:
        return stats

    if verbose and (files_to_update or deleted_files):
        print(
            f"\n  📦 Syncing index: {len(files_to_update)} modified, {len(deleted_files)} deleted"
        )

    # Update modified/new files
    for file_path in files_to_update:
        was_indexed = file_path in metadata
        try:
            count = update_file_in_index(
                file_path, qdrant_path, collection_name, verbose=verbose
            )
            if count > 0:
                metadata[file_path] = time.time()
                if was_indexed:
                    stats["updated"] += 1
                else:
                    stats["added"] += 1
        except Exception as e:
            if verbose:
                print(f"    ✗ Error indexing {file_path}: {e}")

    # Remove deleted files from index
    for file_path in deleted_files:
        try:
            delete_file_from_index(
                file_path, qdrant_path, collection_name, verbose=verbose
            )
            del metadata[file_path]
            stats["deleted"] += 1
        except Exception as e:
            if verbose:
                print(f"    ✗ Error removing {file_path}: {e}")

    # Save updated metadata
    save_index_metadata(qdrant_path, metadata)

    return stats


def initialize_index_metadata(
    root_dir: str,
    qdrant_path: str,
    skip_patterns: Optional[Set[str]] = None,
    skip_dirs: Optional[Set[str]] = None,
) -> None:
    """
    Initialize index metadata after a full index_project + store_chunks.
    Records the current mtime for all indexed files.

    Called after `synapse analyze` to set up tracking for future syncs.

    Args:
        root_dir: Root directory that was indexed
        qdrant_path: Path to Qdrant storage directory
        skip_patterns: Set of filename patterns to skip (default: {"mcp_server.py"})
        skip_dirs: Set of directory names to skip
    """
    if skip_patterns is None:
        skip_patterns = {"mcp_server.py"}

    if skip_dirs is None:
        skip_dirs = {
            "__pycache__",
            ".git",
            ".venv",
            "venv",
            "node_modules",
            ".synapse",
            "env",
            ".env",
        }

    metadata: Dict[str, float] = {}

    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Skip unwanted directories
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]

        for filename in filenames:
            if not filename.endswith(".py"):
                continue
            if filename in skip_patterns:
                continue

            file_path = str(Path(dirpath) / filename)
            try:
                metadata[file_path] = os.path.getmtime(file_path)
            except OSError:
                continue

    save_index_metadata(qdrant_path, metadata)
