"""Tool Executor for local tool execution on CLI side.

This module handles tool requests from the backend and executes them locally.
"""

import logging
from typing import Any, Callable, Dict

logger = logging.getLogger(__name__)


class ToolExecutor:
    """
    Executes tools locally on the CLI side.

    When the backend needs to read/write files or search the codebase,
    it sends a ToolCallRequest. This executor handles those requests
    and returns the results.
    """

    def __init__(self, working_dir: str):
        """
        Initialize the tool executor.

        Args:
            working_dir: Base working directory for file operations
        """
        self.working_dir = working_dir
        self._tools: Dict[str, Callable] = {}
        self._register_default_tools()

    def _register_default_tools(self):
        """Register default tools for file operations and search."""
        self._tools["read_file"] = self._execute_read_file
        self._tools["write_file"] = self._execute_write_file
        self._tools["replace_file"] = self._execute_replace_file
        self._tools["insert_file"] = self._execute_insert_file
        self._tools["codebase_context_search"] = self._execute_context_search

    def execute(self, tool_name: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool with the given parameters.

        Args:
            tool_name: Name of the tool to execute
            parameters: Tool parameters

        Returns:
            Tool execution result as a dictionary
        """
        tool_func = self._tools.get(tool_name)
        if tool_func is None:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}

        try:
            result = tool_func(parameters)
            return {"success": True, "result": result}
        except Exception as e:
            logger.exception(f"Error executing tool {tool_name}")
            return {"success": False, "error": str(e)}

    def _execute_read_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute read_file tool."""
        from utils.read_file import read_file

        target_file = params.get("target_file", "")
        start_line = params.get("start_line_one_indexed", 0) or None
        end_line = params.get("end_line_one_indexed_inclusive", 0) or None

        content, success = read_file(
            target_file=target_file,
            start_line_one_indexed=start_line,
            end_line_one_indexed_inclusive=end_line,
        )

        if not success:
            raise Exception(content)

        return {"content": content}

    def _execute_write_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute write_file tool."""
        import os

        target_file = params.get("target_file", "")
        content = params.get("content", "")

        # Create directories if needed
        os.makedirs(os.path.dirname(os.path.abspath(target_file)), exist_ok=True)

        file_exists = os.path.exists(target_file)

        with open(target_file, "w", encoding="utf-8") as f:
            f.write(content)

        operation = "updated" if file_exists else "created"
        return {"message": f"Successfully {operation} {target_file}"}

    def _execute_replace_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute replace_file tool."""
        from utils.replace_file import replace_file

        target_file = params.get("target_file", "")
        start_line = params.get("start_line", 1)
        end_line = params.get("end_line", 1)
        content = params.get("content", "")

        result, success = replace_file(
            target_file=target_file,
            start_line=start_line,
            end_line=end_line,
            content=content,
        )

        if not success:
            raise Exception(result)

        return {"message": result}

    def _execute_insert_file(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute insert_file tool."""
        from utils.insert_file import insert_file

        target_file = params.get("target_file", "")
        content = params.get("content", "")
        line_number = params.get("line_number", 0) or None

        result, success = insert_file(
            target_file=target_file, content=content, line_number=line_number
        )

        if not success:
            raise Exception(result)

        return {"message": result}

    def _execute_context_search(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute codebase_context_search tool."""
        from utils.context_search import format_context_results, search_codebase_context

        query = params.get("query", "")
        working_dir = params.get("working_dir", self.working_dir)
        max_results = params.get("max_results", 5)
        max_depth = params.get("max_depth", 3)

        results = search_codebase_context(
            query=query,
            working_dir=working_dir,
            max_results=max_results,
            max_depth=max_depth,
        )

        # Format for easier reading by the agent
        formatted = format_context_results(results)

        return {"results": results, "formatted_output": formatted}
