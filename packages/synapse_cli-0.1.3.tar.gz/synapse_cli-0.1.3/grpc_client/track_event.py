"""Fire-and-forget CLI telemetry via REST API + gRPC quota checks."""

import asyncio
import hashlib
import json
import logging
import urllib.request
import urllib.error
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)


def track_event(
    event_type: str,
    api_key: str = "",
    working_dir: str = "",
    lines_count: int = 0,
    tool_count: int = 0,
    candidate_count: int = 0,
    duration_ms: int = 0,
) -> None:
    """Send a telemetry event to the REST API. Returns immediately, never blocks.

    Safe to call from synchronous CLI commands (init, auth, analyze, build, detect).
    All failures are silently swallowed.
    """
    try:
        _send_http(
            event_type, api_key, working_dir,
            lines_count=lines_count,
            tool_count=tool_count,
            candidate_count=candidate_count,
            duration_ms=duration_ms,
        )
    except Exception as exc:
        logger.debug("TrackEvent silently failed: %s", exc)


def _send_http(
    event_type: str,
    api_key: str,
    working_dir: str = "",
    lines_count: int = 0,
    tool_count: int = 0,
    candidate_count: int = 0,
    duration_ms: int = 0,
) -> None:
    from utils.config_manager import get_api_url

    if not api_key:
        return

    api_url = get_api_url()
    dir_hash = hashlib.sha256(working_dir.encode()).hexdigest() if working_dir else ""

    payload = {
        "event_type": event_type,
        "working_dir_hash": dir_hash,
    }
    if lines_count:
        payload["lines_count"] = lines_count
    if tool_count:
        payload["tool_count"] = tool_count
    if candidate_count:
        payload["candidate_count"] = candidate_count
    if duration_ms:
        payload["duration_ms"] = duration_ms

    body = json.dumps(payload).encode()

    req = urllib.request.Request(
        f"{api_url}/telemetry/cli",
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    urllib.request.urlopen(req, timeout=3)


def check_quota(api_key: str) -> Tuple[bool, str]:
    """Check if user has exceeded any quota. Returns (exceeded, message).

    Calls TrackEvent with event_type="quota_check". The backend returns
    quota_exceeded=True and quota_message if any limit is reached.

    Fails open (returns False, "") on any error — never blocks CLI.
    """
    try:
        api_key_hash = hashlib.sha256(api_key.encode()).hexdigest() if api_key else ""
        return asyncio.run(_check_quota(api_key_hash))
    except Exception:
        return False, ""


def get_quota_info(api_key: str) -> Optional[Dict]:
    """Fetch quota details from backend. Returns dict or None on failure.

    Keys: mcp_servers_count, max_mcp_servers, lines_indexed, max_lines_indexed,
          quota_exceeded, quota_message.
    """
    try:
        api_key_hash = hashlib.sha256(api_key.encode()).hexdigest() if api_key else ""
        return asyncio.run(_get_quota_info(api_key_hash))
    except Exception:
        return None


async def _get_quota_info(api_key_hash: str) -> Optional[Dict]:
    try:
        import grpc
        from grpc import aio
        from .generated import synapse_pb2, synapse_pb2_grpc
        from .client import parse_backend_address

        host, port = parse_backend_address()
        use_secure = port == 443 or str(host).endswith(".run.app")
        address = f"{host}:{port}"

        if use_secure:
            channel = aio.secure_channel(address, grpc.ssl_channel_credentials())
        else:
            channel = aio.insecure_channel(address)

        async with channel:
            stub = synapse_pb2_grpc.SynapseServiceStub(channel)
            response = await stub.TrackEvent(
                synapse_pb2.TrackEventRequest(
                    event_type="quota_info",
                    api_key_hash=api_key_hash,
                ),
                timeout=5.0,
            )
            return {
                "mcp_servers_count": response.mcp_servers_count,
                "max_mcp_servers": response.max_mcp_servers,
                "lines_indexed": response.lines_indexed,
                "max_lines_indexed": response.max_lines_indexed,
                "quota_exceeded": response.quota_exceeded,
                "quota_message": response.quota_message,
            }
    except Exception:
        return None


async def _check_quota(api_key_hash: str) -> Tuple[bool, str]:
    try:
        import grpc
        from grpc import aio
        from .generated import synapse_pb2, synapse_pb2_grpc
        from .client import parse_backend_address

        host, port = parse_backend_address()
        use_secure = port == 443 or str(host).endswith(".run.app")
        address = f"{host}:{port}"

        if use_secure:
            channel = aio.secure_channel(address, grpc.ssl_channel_credentials())
        else:
            channel = aio.insecure_channel(address)

        async with channel:
            stub = synapse_pb2_grpc.SynapseServiceStub(channel)
            metadata = [("x-api-key-hash", api_key_hash)]
            response = await stub.TrackEvent(
                synapse_pb2.TrackEventRequest(
                    event_type="quota_check",
                    api_key_hash=api_key_hash,
                ),
                timeout=3.0,
                metadata=metadata,
            )
            return response.quota_exceeded, response.quota_message
    except Exception:
        return False, ""  # fail open
