"""gRPC Client for Synapse Backend API.

This client implements bidirectional streaming communication with the backend
for build and analyze workflows.
"""

import os

# Suppress gRPC/abseil logging warnings BEFORE importing grpc
os.environ.setdefault("GRPC_VERBOSITY", "ERROR")
os.environ.setdefault("GRPC_TRACE", "")
os.environ.setdefault("GRPC_ENABLE_FORK_SUPPORT", "0")

import asyncio  # noqa: E402
import json  # noqa: E402
import logging  # noqa: E402
import warnings  # noqa: E402
from typing import Any, AsyncIterator, Callable, Dict, Optional, Tuple  # noqa: E402
from urllib.parse import urlparse  # noqa: E402

# Suppress warnings from grpc
warnings.filterwarnings("ignore", category=DeprecationWarning, module="grpc")

import grpc  # noqa: E402
from grpc import aio  # noqa: E402

from .generated import synapse_pb2, synapse_pb2_grpc  # noqa: E402
from .tool_executor import ToolExecutor  # noqa: E402

logger = logging.getLogger(__name__)


# Backend config from config.json (synapse-cli root)
def _backend_cfg():
    from utils.config_manager import get_backend_config

    return get_backend_config()


MAX_MESSAGE_SIZE = 100 * 1024 * 1024  # 100MB


def parse_backend_address(
    url_or_host: Optional[str] = None, port: Optional[int] = None
) -> Tuple[str, int]:
    """
    Parse backend address from URL or host:port format.

    Supports:
    - Full URLs: https://service.run.app, http://localhost:50051
    - Host:port format: localhost:50051, service.run.app:443
    - Host only: localhost (uses default port 50051)

    Args:
        url_or_host: URL or host string
        port: Optional port number

    Returns:
        Tuple of (host, port)
    """
    # If no url_or_host provided, use config.json
    if url_or_host is None:
        cfg = _backend_cfg()
        if cfg.get("url"):
            url_or_host = cfg["url"]
        else:
            return (cfg["host"], int(cfg["port"]))

    # Check if it's a full URL
    if url_or_host.startswith(("http://", "https://")):
        parsed = urlparse(url_or_host)
        host = parsed.hostname
        if not host:
            raise ValueError(f"Invalid URL: {url_or_host}")
        # Use port from URL, or default based on scheme
        if parsed.port:
            parsed_port = parsed.port
        elif parsed.scheme == "https":
            parsed_port = 443
        elif parsed.scheme == "http":
            parsed_port = 80
        else:
            parsed_port = int(_backend_cfg().get("port", "50051"))
        return (host, parsed_port)

    # Check if it's host:port format
    if ":" in url_or_host and not url_or_host.startswith("["):
        # IPv6 addresses are handled differently, but for now assume host:port
        parts = url_or_host.rsplit(":", 1)
        if len(parts) == 2:
            try:
                host = parts[0]
                parsed_port = int(parts[1])
                return (host, parsed_port)
            except ValueError:
                # Not a valid port, treat as hostname
                pass

    # Just a hostname
    if port is not None:
        return (url_or_host, port)

    # Use default port from config
    return (url_or_host, int(_backend_cfg().get("port", "50051")))


class SynapseClient:
    """
    gRPC Client for Synapse Backend.

    Handles bidirectional streaming for build and analyze workflows.
    Executes local tools when requested by the backend.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        working_dir: Optional[str] = None,
        url: Optional[str] = None,
    ):
        """
        Initialize the Synapse client.

        Args:
            host: Backend server host (ignored if url is provided)
            port: Backend server port (ignored if url is provided)
            working_dir: Working directory for local tool execution
            url: Full backend URL (e.g., https://service.run.app or http://localhost:50051)
                 Takes precedence over host/port if provided
        """
        # Parse address from URL or host:port
        if url:
            self.host, self.port = parse_backend_address(url)
        elif host is not None or port is not None:
            self.host, self.port = parse_backend_address(host, port)
        else:
            # Use defaults from environment
            self.host, self.port = parse_backend_address()

        self.working_dir = working_dir or os.getcwd()
        self.address = f"{self.host}:{self.port}"
        self._channel: Optional[aio.Channel] = None
        self.tool_executor = ToolExecutor(self.working_dir)

    async def connect(self):
        """Establish connection to the backend."""
        if self._channel is not None:
            return

        # Determine if we need secure channel (HTTPS)
        use_secure = self.port == 443 or (self.port == 80 and self.host != "localhost")

        # For Cloud Run and other HTTPS endpoints, use secure channel
        # Check if host looks like a Cloud Run domain or uses HTTPS scheme
        if self.host.endswith(".run.app") or self.host.endswith(".cloudfunctions.net"):
            use_secure = True

        channel_options = [
            ("grpc.max_send_message_length", MAX_MESSAGE_SIZE),
            ("grpc.max_receive_message_length", MAX_MESSAGE_SIZE),
            # Keepalive settings - must be higher than server's min_time_between_pings_ms
            ("grpc.keepalive_time_ms", 60000),  # Send pings every 60 seconds
            ("grpc.keepalive_timeout_ms", 40000),  # Wait 40 seconds for ping ack
            (
                "grpc.keepalive_permit_without_calls",
                False,
            ),  # Only ping when there are active calls
        ]

        if use_secure:
            # Use secure channel with default credentials (for Cloud Run)
            credentials = grpc.ssl_channel_credentials()
            self._channel = aio.secure_channel(
                self.address, credentials, options=channel_options
            )
            logger.info(f"Connected to Synapse backend at {self.address} (secure)")
        else:
            # Use insecure channel for localhost
            self._channel = aio.insecure_channel(self.address, options=channel_options)
            logger.info(f"Connected to Synapse backend at {self.address}")

    async def close(self):
        """Close the connection."""
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            logger.info("Disconnected from Synapse backend")

    async def detect(
        self,
        functions: list,
        working_dir: str,
        project_schema: str = "",
    ) -> Dict[str, Any]:
        """Call DetectEndpoints unary RPC — AI classification of function candidates.

        Args:
            functions: List of FunctionInfo dicts (from endpoint_extractor.py).
            working_dir: Project root directory.
            project_schema: Optional project schema for context.

        Returns:
            {"candidates": [...DetectedEndpoint dicts...], "error": str}
        """
        await self.connect()

        # Build FunctionInfo proto messages
        fn_protos = []
        for fn in functions:
            fn_protos.append(
                synapse_pb2.FunctionInfo(
                    name=fn.get("name", ""),
                    file_path=fn.get("file_path", ""),
                    signature=fn.get("signature", ""),
                    docstring=fn.get("docstring", ""),
                    return_type=fn.get("return_type", ""),
                    is_async=bool(fn.get("is_async", False)),
                    line_number=int(fn.get("line_number", 0)),
                    param_names=fn.get("param_names", []),
                    param_types=fn.get("param_types", []),
                    endpoint_type=fn.get("endpoint_type", "function"),
                )
            )

        request = synapse_pb2.DetectRequest(
            working_dir=working_dir,
            functions=fn_protos,
            project_schema=project_schema,
        )

        from utils.config_manager import resolve_api_key

        api_key = resolve_api_key(self.working_dir)
        if not api_key:
            return {
                "candidates": [],
                "error": (
                    "Missing API key. Set one with: synapse init, synapse config --key <KEY>, "
                    "or set SYNAPSE_API_KEY in the environment."
                ),
            }
        metadata = [("x-api-key", api_key)]

        try:
            stub = synapse_pb2_grpc.SynapseServiceStub(self._channel)
            response = await stub.DetectEndpoints(request, metadata=metadata)
            candidates = []
            for ep in response.candidates:
                candidates.append(
                    {
                        "name": ep.name,
                        "file_path": ep.file_path,
                        "confidence": ep.confidence,
                        "human_title": ep.human_title,
                        "human_description": ep.human_description,
                        "conversion_type": ep.conversion_type,
                        "client_dependency_json": ep.client_dependency_json,
                        "subcategory": ep.subcategory,
                        "signature": ep.signature,
                        "docstring": ep.docstring,
                        "line_number": ep.line_number,
                    }
                )
            return {"candidates": candidates, "error": response.error}
        except grpc.RpcError as e:
            return {"candidates": [], "error": f"gRPC error: {e.code()}: {e.details()}"}
        except Exception as e:
            return {"candidates": [], "error": str(e)}

    async def build(
        self,
        query: str,
        project_schema: str,
        output_file: str = "mcp_server.py",
        validate: bool = True,
        docs: bool = True,
        generate_only: bool = False,
        todo_list_content: Optional[str] = None,
        context_bundle: Optional[Dict[str, Any]] = None,
        on_status: Optional[Callable[[str, str, float], None]] = None,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """
        Execute the build workflow via gRPC streaming.

        Args:
            query: User's MCP server requirements
            project_schema: Content of project_schema.txt
            output_file: Output filename for generated server
            validate: Whether to validate generated code
            docs: Whether to generate documentation
            generate_only: Skip planner, use existing todo_list.md
            todo_list_content: Content of todo_list.md (if generate_only)
            on_status: Callback for status updates (stage, message, progress)
            on_tool_call: Callback when a tool is executed (tool_name, result)

        Returns:
            Build result dictionary
        """
        await self.connect()

        # Prepare the initial request
        build_request = {
            "type": "build_request",
            "query": query,
            "project_schema": project_schema,
            "working_dir": self.working_dir,
            "output_file": output_file,
            "validate": validate,
            "docs": docs,
            "generate_only": generate_only,
            "todo_list_content": todo_list_content or "",
            "context_bundle": json.dumps(context_bundle) if context_bundle else "",
        }

        result = await self._run_bidirectional_stream(
            stream_type="build",
            initial_request=build_request,
            on_status=on_status,
            on_tool_call=on_tool_call,
        )

        return result

    async def analyze(
        self,
        use_ai: bool = True,
        verbose: bool = True,
        on_status: Optional[Callable[[str, str, float], None]] = None,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """
        Execute the analyze workflow via gRPC streaming.

        Args:
            use_ai: Use AI-powered analysis
            verbose: Enable verbose output
            on_status: Callback for status updates
            on_tool_call: Callback when a tool is executed

        Returns:
            Analysis result dictionary
        """
        await self.connect()

        analyze_request = {
            "type": "analyze_request",
            "working_dir": self.working_dir,
            "use_ai": use_ai,
            "verbose": verbose,
        }

        result = await self._run_bidirectional_stream(
            stream_type="analyze",
            initial_request=analyze_request,
            on_status=on_status,
            on_tool_call=on_tool_call,
        )

        return result

    async def _run_bidirectional_stream(
        self,
        stream_type: str,
        initial_request: Dict[str, Any],
        on_status: Optional[Callable[[str, str, float], None]] = None,
        on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """
        Run a bidirectional streaming workflow.

        Args:
            stream_type: "build" or "analyze"
            initial_request: Initial request message
            on_status: Status callback
            on_tool_call: Tool call callback

        Returns:
            Final result dictionary
        """
        # Queue for outgoing messages
        outgoing_queue = asyncio.Queue()

        # Put initial request
        await outgoing_queue.put(initial_request)

        # Result holder
        final_result: Dict[str, Any] = {
            "success": False,
            "error": "No response received",
        }

        async def request_generator() -> AsyncIterator[bytes]:
            """Generate outgoing messages."""
            while True:
                message = await outgoing_queue.get()
                if message is None:
                    break
                yield json.dumps(message).encode()

        async def process_responses(response_stream):
            """Process incoming messages from the server."""
            nonlocal final_result

            async for raw_response in response_stream:
                try:
                    if isinstance(raw_response, bytes):
                        message = json.loads(raw_response.decode())
                    elif isinstance(raw_response, str):
                        message = json.loads(raw_response)
                    else:
                        message = raw_response

                    msg_type = message.get("type")

                    if msg_type == "status_update":
                        stage = message.get("stage", "")
                        msg = message.get("message", "")
                        progress = message.get("progress", 0.0)

                        if on_status:
                            on_status(stage, msg, progress)
                        else:
                            logger.info(f"[{stage}] {msg} ({progress*100:.0f}%)")

                    elif msg_type == "tool_request":
                        # Execute the tool locally
                        request_id = message.get("request_id")
                        tool_name = message.get("tool_name")
                        parameters = message.get("parameters", {})

                        if isinstance(parameters, bytes):
                            parameters = json.loads(parameters.decode())
                        elif isinstance(parameters, str):
                            parameters = json.loads(parameters)

                        logger.debug(f"Executing tool: {tool_name}")
                        result = self.tool_executor.execute(tool_name, parameters)

                        if on_tool_call:
                            on_tool_call(tool_name, result)

                        # Send response back
                        response = {
                            "type": "tool_response",
                            "request_id": request_id,
                            "success": result.get("success", False),
                            "result": result.get("result"),
                            "error": result.get("error", ""),
                        }
                        await outgoing_queue.put(response)

                    elif msg_type == "build_result":
                        final_result = {
                            "success": message.get("success", False),
                            "output_file": message.get("output_file", ""),
                            "server_code": message.get("server_code", ""),
                            "tool_count": message.get("tool_count", 0),
                            "resource_count": message.get("resource_count", 0),
                            "documentation": message.get("documentation", ""),
                            "crew_output": message.get("crew_output", ""),
                        }
                        # Signal to stop sending
                        await outgoing_queue.put(None)

                    elif msg_type == "analyze_result":
                        final_result = {
                            "success": message.get("success", False),
                            "recommendations": message.get("recommendations", ""),
                            "crew_output": message.get("crew_output", ""),
                        }
                        await outgoing_queue.put(None)

                    elif msg_type == "error":
                        final_result = {
                            "success": False,
                            "error": message.get("message", "Unknown error"),
                            "error_code": message.get("code", "UNKNOWN"),
                        }
                        await outgoing_queue.put(None)

                except json.JSONDecodeError as e:
                    logger.error(f"Failed to decode response: {e}")
                except Exception as e:
                    logger.exception(f"Error processing response: {e}")

        try:
            stub = synapse_pb2_grpc.SynapseServiceStub(self._channel)

            async def proto_request_generator():
                """Generate protobuf messages for the stream."""
                while True:
                    message = await outgoing_queue.get()
                    if message is None:
                        break

                    msg_type = message.get("type")

                    if stream_type == "build":
                        proto_msg = synapse_pb2.BuildMessage()

                        if msg_type == "build_request":
                            req = synapse_pb2.BuildRequest(
                                request_id=message.get("request_id", ""),
                                query=message.get("query", ""),
                                project_schema=message.get("project_schema", ""),
                                working_dir=message.get("working_dir", ""),
                                output_file=message.get("output_file", ""),
                                validate=message.get("validate", True),
                                docs=message.get("docs", True),
                                generate_only=message.get("generate_only", False),
                                todo_list_content=message.get("todo_list_content", ""),
                                context_bundle=message.get("context_bundle", ""),
                            )
                            proto_msg.build_request.CopyFrom(req)

                        elif msg_type == "tool_response":
                            resp = synapse_pb2.ToolCallResponse(
                                request_id=message.get("request_id", ""),
                                success=message.get("success", False),
                                result=json.dumps(message.get("result", {})).encode(),
                                error=message.get("error", ""),
                            )
                            proto_msg.tool_response.CopyFrom(resp)

                        yield proto_msg

                    else:  # analyze
                        proto_msg = synapse_pb2.AnalyzeMessage()

                        if msg_type == "analyze_request":
                            req = synapse_pb2.AnalyzeRequest(
                                request_id=message.get("request_id", ""),
                                working_dir=message.get("working_dir", ""),
                                verbose=message.get("verbose", True),
                                use_ai=message.get("use_ai", True),
                            )
                            proto_msg.analyze_request.CopyFrom(req)

                        elif msg_type == "tool_response":
                            resp = synapse_pb2.ToolCallResponse(
                                request_id=message.get("request_id", ""),
                                success=message.get("success", False),
                                result=json.dumps(message.get("result", {})).encode(),
                                error=message.get("error", ""),
                            )
                            proto_msg.tool_response.CopyFrom(resp)

                        yield proto_msg

            async def process_proto_responses(response_stream):
                """Process protobuf responses from the server."""
                nonlocal final_result

                async for proto_msg in response_stream:
                    payload_type = proto_msg.WhichOneof("payload")

                    if payload_type == "status_update":
                        update = proto_msg.status_update
                        if on_status:
                            on_status(update.stage, update.message, update.progress)
                        else:
                            logger.info(
                                f"[{update.stage}] {update.message} ({update.progress*100:.0f}%)"
                            )

                    elif payload_type == "tool_request":
                        tool_req = proto_msg.tool_request
                        parameters = {}
                        if tool_req.parameters:
                            parameters = json.loads(tool_req.parameters.decode())

                        logger.debug(f"Executing tool: {tool_req.tool_name}")
                        result = self.tool_executor.execute(
                            tool_req.tool_name, parameters
                        )

                        if on_tool_call:
                            on_tool_call(tool_req.tool_name, result)

                        response = {
                            "type": "tool_response",
                            "request_id": tool_req.request_id,
                            "success": result.get("success", False),
                            "result": result.get("result"),
                            "error": result.get("error", ""),
                        }
                        await outgoing_queue.put(response)

                    elif payload_type == "build_result":
                        build_res = proto_msg.build_result
                        final_result = {
                            "success": build_res.success,
                            "server_code": build_res.server_code,
                            "tool_count": build_res.tool_count,
                            "resource_count": build_res.resource_count,
                            "documentation": build_res.documentation,
                            "todo_list": build_res.todo_list,
                        }
                        await outgoing_queue.put(None)

                    elif payload_type == "analyze_result":
                        analyze_res = proto_msg.analyze_result
                        final_result = {
                            "success": analyze_res.success,
                            "schema_content": analyze_res.schema_content,
                            "directory_count": analyze_res.directory_count,
                            "file_count": analyze_res.file_count,
                            "module_count": analyze_res.module_count,
                            "class_count": analyze_res.class_count,
                            "function_count": analyze_res.function_count,
                            "method_count": analyze_res.method_count,
                        }
                        await outgoing_queue.put(None)

                    elif payload_type == "error":
                        error = proto_msg.error
                        final_result = {
                            "success": False,
                            "error": error.message,
                            "error_code": error.code,
                            "recoverable": error.recoverable,
                        }
                        await outgoing_queue.put(None)

            # Resolve API key for auth metadata (precedence: env > project > global)
            from utils.config_manager import resolve_api_key

            api_key = resolve_api_key(self.working_dir)
            if not api_key:
                return {
                    "success": False,
                    "error": (
                        "Missing API key (x-api-key metadata). "
                        "Set one with: synapse init (prompt), synapse config --key <API_KEY>, "
                        "or synapse config --global --key <API_KEY>. "
                        "Or set SYNAPSE_API_KEY in the environment."
                    ),
                }
            metadata = [("x-api-key", api_key)]

            # Start the bidirectional stream
            if stream_type == "build":
                response_stream = stub.Build(
                    proto_request_generator(), metadata=metadata
                )
            else:
                response_stream = stub.Analyze(
                    proto_request_generator(), metadata=metadata
                )

            await process_proto_responses(response_stream)

        except grpc.RpcError as e:
            logger.error(f"gRPC error: {e}")
            return {"success": False, "error": f"gRPC error: {e.code()}: {e.details()}"}
        except Exception as e:
            logger.exception("Error in bidirectional stream")
            return {"success": False, "error": str(e)}

        return final_result


def run_build_sync(
    query: str,
    project_schema: str,
    working_dir: str,
    output_file: str = "mcp_server.py",
    validate: bool = True,
    docs: bool = True,
    generate_only: bool = False,
    todo_list_content: Optional[str] = None,
    context_bundle: Optional[Dict[str, Any]] = None,
    on_status: Optional[Callable[[str, str, float], None]] = None,
    on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    host: Optional[str] = None,
    port: Optional[int] = None,
    url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Synchronous wrapper for build workflow.

    Args:
        context_bundle: Pre-gathered context dict from context_builder.py.
        url: Full backend URL (e.g., https://service.run.app). Takes precedence over host/port.
        host: Backend server host (ignored if url is provided)
        port: Backend server port (ignored if url is provided)
    """

    async def _run():
        client = SynapseClient(host=host, port=port, url=url, working_dir=working_dir)
        try:
            result = await client.build(
                query=query,
                project_schema=project_schema,
                output_file=output_file,
                validate=validate,
                docs=docs,
                generate_only=generate_only,
                todo_list_content=todo_list_content,
                context_bundle=context_bundle,
                on_status=on_status,
                on_tool_call=on_tool_call,
            )
            return result
        finally:
            await client.close()

    return asyncio.run(_run())


def run_detect_sync(
    functions: list,
    working_dir: str,
    project_schema: str = "",
    host: Optional[str] = None,
    port: Optional[int] = None,
    url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Synchronous wrapper for the DetectEndpoints unary RPC.

    Args:
        functions: List of FunctionInfo dicts from endpoint_extractor.py.
        working_dir: Project root directory.
        project_schema: Optional project schema text for context.
        url: Full backend URL. Takes precedence over host/port.
        host: Backend host (ignored if url is provided).
        port: Backend port (ignored if url is provided).

    Returns:
        {"candidates": [...], "error": str}
    """

    async def _run():
        client = SynapseClient(host=host, port=port, url=url, working_dir=working_dir)
        try:
            return await client.detect(
                functions=functions,
                working_dir=working_dir,
                project_schema=project_schema,
            )
        finally:
            await client.close()

    return asyncio.run(_run())


def run_analyze_sync(
    working_dir: str,
    use_ai: bool = True,
    verbose: bool = True,
    on_status: Optional[Callable[[str, str, float], None]] = None,
    on_tool_call: Optional[Callable[[str, Dict[str, Any]], None]] = None,
    host: Optional[str] = None,
    port: Optional[int] = None,
    url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Synchronous wrapper for analyze workflow.

    Args:
        url: Full backend URL (e.g., https://service.run.app). Takes precedence over host/port.
        host: Backend server host (ignored if url is provided)
        port: Backend server port (ignored if url is provided)
    """

    async def _run():
        client = SynapseClient(host=host, port=port, url=url, working_dir=working_dir)
        try:
            result = await client.analyze(
                use_ai=use_ai,
                verbose=verbose,
                on_status=on_status,
                on_tool_call=on_tool_call,
            )
            return result
        finally:
            await client.close()

    return asyncio.run(_run())
