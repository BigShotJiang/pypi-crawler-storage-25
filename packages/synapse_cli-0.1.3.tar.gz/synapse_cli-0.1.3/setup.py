"""
Minimal setup.py for backward compatibility.
All configuration is now in pyproject.toml (PEP 621).
"""

from setuptools import setup

# All configuration is in pyproject.toml
# This file exists only for backward compatibility with older tools
setup()
