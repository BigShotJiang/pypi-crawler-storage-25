"""Implementation of 'synapse build' command using gRPC backend"""

import json
import os
import time

from rich import box

# Rich library for beautiful terminal output
from rich.console import Console
from rich.panel import Panel

from grpc_client import run_build_sync
from grpc_client.client import run_detect_sync
from utils.cli_utils import (
    CodeGenerationUI,
    ProgressIndicator,
    display_context_validation_ui,
    display_error_box,
    display_header,
    display_insufficient_context_error,
    display_success_box,
    interactive_endpoint_selection,
    prompt_styled_input,
    sunset_console,
)
from utils.code_indexer import sync_index
from utils.config_manager import get_backend_config, is_initialized
from utils.context_search import validate_query_relevance
from utils.endpoint_detector import detect_endpoints
from utils.endpoint_extractor import extract_all_functions

# ANSI color codes
BLUE = "\033[94m"
GREEN = "\033[92m"
RESET = "\033[0m"

# Initialize Rich console
console = Console()


def _format_endpoint_for_planner(ep, working_dir: str) -> str:
    """
    Format endpoint with full metadata for planner agent.

    Creates a structured description that includes conversion type,
    client dependencies, and all metadata needed for wrapper generation.

    Args:
        ep: EndpointCandidate object
        working_dir: Project working directory for relative paths

    Returns:
        Formatted multi-line string with endpoint metadata
    """
    rel_path = os.path.relpath(ep.file_path, working_dir)

    lines = [
        f"### Function: `{ep.name}`",
        f"- File: `{rel_path}`",
        f"- Signature: `{ep.signature}`",
    ]

    # Add conversion type (default to "ready" for backward compatibility)
    conversion_type = getattr(ep, "conversion_type", "ready")
    lines.append(f"- Conversion Type: {conversion_type.upper()}")

    # Add client dependency info for wrapper endpoints
    # client_dependency may be a ClientDependency object or a plain dict
    client_dep = getattr(ep, "client_dependency", None)
    if conversion_type == "requires_wrapper" and client_dep:
        if isinstance(client_dep, dict):
            client_name = client_dep.get("client_name", "")
            library = client_dep.get("library", "")
            env_vars = client_dep.get("env_vars", [])
        else:
            client_name = getattr(client_dep, "client_name", "")
            library = getattr(client_dep, "library", "")
            env_vars = getattr(client_dep, "env_vars", [])
        lines.extend(
            [
                f"- Client Required: {client_name}",
                f"- Library: {library}",
            ]
        )
        if env_vars:
            lines.append(f"- Environment Variables: {', '.join(env_vars)}")

    # Add description from docstring
    if ep.docstring:
        first_line = ep.docstring.split("\n")[0].strip()
        if first_line:
            lines.append(f"- Description: {first_line}")

    # Add return type if available
    if ep.return_type and ep.return_type != "Any":
        lines.append(f"- Return Type: `{ep.return_type}`")

    return "\n".join(lines)


def run_build_command(
    query: str = None,
    output: str = "mcp_server.py",
    validate: bool = True,
    docs: bool = True,
    generate_only: bool = False,
) -> None:
    """
    Handles 'synapse build' command execution via gRPC backend.

    New Flow:
    1. Check initialization & analysis
    2. Detect endpoints in codebase
    3. Display checkbox selection (endpoints + Custom option)
    4. If Custom selected -> prompt for query
    5. Generate MCP server based on selections

    Args:
        query: MCP server requirements (if not provided, will prompt or use
            selections)
        output: Output file for generated server (default: mcp_server.py)
        validate: Whether to validate generated code (default: True)
        docs: Whether to generate documentation (default: True)
        generate_only: Skip planner and use existing todo_list.md (default:
            False)
    """
    working_dir = os.getcwd()
    synapse_dir = os.path.join(working_dir, ".synapse")

    # Check if synapse is initialized
    if not is_initialized(working_dir):
        display_error_box(
            "Not Initialized",
            "Synapse is not initialized in this directory.\n"
            "Please run 'synapse init' first.",
        )
        return

    # Pre-flight quota check — fail fast before expensive work
    try:
        from utils.config_manager import resolve_api_key
        from grpc_client.track_event import check_quota

        _api_key = resolve_api_key(working_dir) or ""
        if _api_key:
            _exceeded, _msg = check_quota(_api_key)
            if _exceeded:
                print(f"\n  {_msg}")
                return
    except Exception:
        pass  # fail open if backend unreachable

    # Auto-sync index with any modified files before building
    progress = ProgressIndicator()
    progress.start(f"{BLUE}Indexing latest changes{RESET}", style="ellipsis")

    try:
        sync_stats = sync_index(
            root_dir=working_dir,
            qdrant_path=synapse_dir,
            collection_name="code_context",
            skip_patterns={"mcp_server.py"},
            verbose=False,
        )
    finally:
        progress.stop()

    added = sync_stats["added"]
    updated = sync_stats["updated"]
    deleted = sync_stats["deleted"]
    print(
        f"{GREEN}✓ Index synced:{RESET} +{added} new, "
        f"~{updated} updated, -{deleted} removed"
    )

    # Check if analysis has been run
    schema_path = os.path.join(synapse_dir, "project_schema.txt")
    if not os.path.exists(schema_path):
        display_error_box(
            "Analysis Required",
            "Project schema not found.\n\n"
            "Please run 'synapse analyze' first to analyze your codebase.\n"
            "The analysis generates the project schema needed for MCP server "
            "generation.",
        )

        # Ask if user wants to run analysis now
        print("\nWould you like to run analysis now? (y/n): ", end="")
        try:
            response = input().strip().lower()
            if response == "y":
                print("\nRunning analysis...")
                from commands.analyze_command import run_analyze

                run_analyze()

                # Check if analysis succeeded
                if not os.path.exists(schema_path):
                    display_error_box(
                        "Analysis Failed", "Could not generate project schema."
                    )
                    return

                print("\n✓ Analysis complete! Proceeding with build...\n")
            else:
                print("\n❌ Build cancelled. Run 'synapse analyze' first.")
                return
        except KeyboardInterrupt:
            print("\n\n❌ Build cancelled.")
            return

    # Handle generate_only mode (existing behavior - skip to generation)
    if generate_only:
        todo_list_path = os.path.join(synapse_dir, "todo_list.md")
        if not os.path.exists(todo_list_path):
            display_error_box(
                "To-Do List Not Found",
                f"Cannot use --generate flag: todo_list.md not found.\n\n"
                f"Expected path: {todo_list_path}\n\n"
                "Run 'synapse build' without --generate first to create the "
                "to-do list.",
            )
            return

        display_header("Generate Mode", "⚡")
        print(f"\n✓ Found existing todo_list.md at: {todo_list_path}")
        print("✓ Skipping planner agent, using generator agent directly...")
        print("━" * 60)

        # Read todo list content
        with open(todo_list_path, "r", encoding="utf-8") as f:
            todo_list_content = f.read()

        # Skip to generation (CrewAI fallback path — no context_bundle)
        return _run_generation(
            working_dir=working_dir,
            synapse_dir=synapse_dir,
            schema_path=schema_path,
            output=output,
            query="Generate from existing todo_list.md",
            validate=validate,
            docs=docs,
            generate_only=True,
            todo_list_content=todo_list_content,
            context_bundle=None,
        )

    # ===== Endpoint Detection & Selection =====
    display_header("Building MCP Server", "🏗️")

    if sunset_console:
        sunset_console.print()
        sunset_console.print(
            "\n🔭Synapse is discovering tool candidates...",
            style="sunset.content",
        )
    else:
        print("\n🔭Synapse is discovering tool candidates...")

    # Step 1: AST scan — extract ALL functions locally (no AI, no network)
    progress = ProgressIndicator()
    progress.start(
        f"{BLUE}Scanning codebase{RESET}",
        style="ellipsis",
        show_timer=True,
    )
    try:
        all_functions = extract_all_functions(working_dir)
    finally:
        progress.stop()

    n_fn = len(all_functions)
    print(f"{GREEN}✓ Scanned codebase:{RESET} {n_fn} function(s) found")

    # Step 2: Backend AI classifies them (single gRPC call, result is cached)
    backend_config = get_backend_config(working_dir)
    try:
        with open(schema_path, "r", encoding="utf-8") as _f:
            _schema_text = _f.read()

        progress.start(
            f"{BLUE}Discovering tool candidates{RESET}",
            style="ellipsis",
            show_timer=True,
        )
        try:
            raw_candidates, _new_detect_count = _detect_with_cache(
                all_functions=all_functions,
                working_dir=working_dir,
                project_schema=_schema_text,
                cache_path=os.path.join(synapse_dir, "endpoints_cache.json"),
                backend_config=backend_config,
            )
        finally:
            progress.complete("Discovered tool candidates")

        # Telemetry — only track newly detected endpoints (not cached ones)
        if _new_detect_count > 0:
            try:
                from utils.config_manager import resolve_api_key
                from grpc_client.track_event import track_event
                _detect_api_key = resolve_api_key(working_dir) or ""
                if _detect_api_key:
                    track_event(
                        "detect",
                        api_key=_detect_api_key,
                        working_dir=working_dir,
                        candidate_count=_new_detect_count,
                    )
            except Exception:
                pass

        # Wrap raw dicts in a proxy for display/selection helpers
        candidates = [_DetectedEndpointProxy(c, working_dir) for c in raw_candidates]
        print(f"{GREEN}✓ Found{RESET} {len(candidates)} tool candidate(s)")
    except Exception as e:
        print(f"\n  ⚠️  Discovery error: {e}")
        candidates = detect_endpoints(working_dir)  # AST fallback

    selected_endpoints = []
    custom_selected = False
    final_query = query

    if candidates:
        n_cand = len(candidates)
        print(f"{GREEN}✓{RESET} Found {n_cand} potential tool candidate(s)")

        # Interactive selection
        selected_endpoints, custom_selected = interactive_endpoint_selection(
            candidates, working_dir
        )

        if not selected_endpoints and not custom_selected:
            print("\n⚙️  No selection made. Defaulting to custom mode.")
            custom_selected = True
    else:
        print("\n⚠️  No MCP tool candidates detected in codebase.")
        print("   Switching to custom mode...")
        custom_selected = True

    # Build the query based on selections
    if selected_endpoints:
        # Build content lines for the box
        box_lines = []
        n_ep = len(selected_endpoints)
        sel_msg = f"[green]✓[/green] Selected {n_ep} " f"endpoint(s) for MCP tools:"
        box_lines.append(sel_msg)
        for ep in selected_endpoints:
            rel_path = os.path.relpath(ep.file_path, working_dir)
            if ep.http_method != "N/A":
                line = (
                    f"  • {ep.name} ({ep.http_method} {ep.route_path}) - " f"{rel_path}"
                )
                box_lines.append(line)
            else:
                box_lines.append(f"  • {ep.name} - {rel_path}")

        # Add custom selection notice inside the box if applicable
        if custom_selected and not query:
            box_lines.append("")
            box_lines.append("🔹 You also selected 'Custom Requirement'")

        # Display using Rich Panel for clean box rendering
        panel_content = "\n".join(box_lines)
        console.print()
        console.print(Panel(panel_content, box=box.SQUARE, expand=False))

        # Build query from selected endpoints with full metadata for planner
        endpoint_descriptions = []
        for ep in selected_endpoints:
            # Formatter includes conversion type and client dependency
            endpoint_descriptions.append(_format_endpoint_for_planner(ep, working_dir))

        header = "Create MCP tools for the following endpoints:\n\n"
        auto_query = header + "\n\n".join(endpoint_descriptions)

        if custom_selected and not query:
            # User wants both selected endpoints AND custom requirements
            additional = prompt_styled_input(
                "We'd appreciate your custom specifications here:",
                placeholder="Share your thoughts",
                validator=None,
                allow_empty=True,
            )
            if additional.strip():
                # Validate custom requirements SEPARATELY before combining
                print("\n✓ Validating custom requirements against codebase...")
                custom_validation = validate_query_relevance(additional, working_dir)

                if custom_validation.get("status") == "insufficient":
                    # Custom requirements have no matching code - exit build
                    print("\n" + "━" * 60)
                    print("❌ Custom Requirements Not Found in Codebase")
                    print("━" * 60)
                    print(f'\nYour custom requirement: "{additional}"')
                    print("\nNo matching code found for these requirements.")
                    print(
                        "The selected endpoints exist, but your custom " "requirements"
                    )
                    print("don't match any functionality in this codebase.")
                    print(
                        "\nSynapse can only create MCP tools from code that " "EXISTS."
                    )
                    print("\n" + "━" * 60)
                    print("\n💡 Suggestions:")
                    print(
                        "  • Run 'synapse build' again and select only the " "endpoints"
                    )
                    print(
                        "  • Or refine your custom requirements to match "
                        "available code"
                    )
                    print("━" * 60)
                    return
                elif custom_validation.get("status") == "uncertain":
                    # Limited matches found - warn but allow
                    hq = custom_validation.get("high_quality_results", 0)
                    print(
                        f"\n⚠️  Limited matches for custom requirements " f"({hq} found)"
                    )
                    print("Proceeding, but results may be limited.")
                    extra = "\n\nAdditional requirements:\n" + additional
                    final_query = auto_query + extra
                else:
                    # Valid - proceed with combined query
                    print("✓ Custom requirements validated")
                    extra = "\n\nAdditional requirements:\n" + additional
                    final_query = auto_query + extra
            else:
                final_query = auto_query
        else:
            final_query = auto_query

    elif custom_selected:
        # Only custom selected - prompt for query
        if not query:
            print("\nDescribe what you want your MCP server to do.")
            print("Be specific about the functionality you want to expose.")
            print("\nExamples:")
            print("  - 'Create tools for file operations and directory listing'")
            print("  - 'Expose database query tools and data retrieval " "functions'")
            print("  - 'Provide tools for code analysis and search operations'")

            def query_validator(q: str) -> tuple[bool, str]:
                """Validates query is not empty"""
                if not q or len(q.strip()) < 10:
                    msg = (
                        "Please provide a more detailed description (at least "
                        "10 characters)"
                    )
                    return (False, msg)
                return True, ""

            final_query = prompt_styled_input(
                "We'd appreciate your custom specifications here:",
                placeholder="Share your thoughts",
                validator=query_validator,
                allow_empty=False,
            )
        else:
            final_query = query

    # Validate query relevance before proceeding
    while True:
        validation = validate_query_relevance(final_query, working_dir)
        should_proceed, new_query = display_context_validation_ui(
            validation, working_dir
        )

        if not should_proceed:
            return  # User cancelled

        if new_query:
            final_query = new_query
            continue  # Re-validate with new query

        break  # Proceed with build

    # Build context bundle before the gRPC call
    context_bundle = None
    if selected_endpoints:
        try:
            from utils.context_builder import build_context_bundle

            context_bundle = build_context_bundle(
                selected_endpoints, working_dir, synapse_dir
            )
        except Exception as e:
            print(f"\n  ⚠️  Context bundle error: {e} — " "falling back to query mode")
    elif final_query:
        try:
            from utils.query_expander import build_context_bundle_from_query

            context_bundle = build_context_bundle_from_query(
                final_query, working_dir, synapse_dir
            )
        except Exception as e:
            print(
                f"\n  ⚠️  Query expansion error: {e} — proceeding without "
                "context bundle"
            )

    # Inject .synapse/CONTEXT.md project context if it exists
    if context_bundle is not None:
        context_md_path = os.path.join(synapse_dir, "CONTEXT.md")
        if os.path.exists(context_md_path):
            try:
                with open(context_md_path, "r", encoding="utf-8") as _f:
                    context_bundle["project_context"] = _f.read()
                print(f"\n  ✓ Loaded project context from .synapse/CONTEXT.md")
            except OSError:
                pass

    # Run generation
    return _run_generation(
        working_dir=working_dir,
        synapse_dir=synapse_dir,
        schema_path=schema_path,
        output=output,
        query=final_query,
        validate=validate,
        docs=docs,
        generate_only=False,
        todo_list_content=None,
        context_bundle=context_bundle,
    )


def _run_generation(
    working_dir: str,
    synapse_dir: str,
    schema_path: str,
    output: str,
    query: str,
    validate: bool,
    docs: bool,
    generate_only: bool,
    todo_list_content: str,
    context_bundle: dict = None,
) -> None:
    """
    Run the actual MCP generation via gRPC backend.

    Args:
        working_dir: Current working directory
        synapse_dir: Path to .synapse directory
        schema_path: Path to project_schema.txt
        output: Output file for generated server
        query: The query/requirements for MCP server
        validate: Whether to validate generated code
        docs: Whether to generate documentation
        generate_only: Whether to skip planner
        todo_list_content: Content of todo_list.md if generate_only
    """
    try:
        # Load project schema
        with open(schema_path, "r", encoding="utf-8") as f:
            project_schema = f.read()

        print()

        progress = ProgressIndicator()
        code_gen_ui = [None]
        current_stage = [None]
        gen_start_time = [None]

        # stage -> (spinner label, complete label, style)
        # "generating" is handled by CodeGenerationUI, not ProgressIndicator.
        stage_messages = {
            "initializing": ("Initializing", "Initialized", "ellipsis"),
            "planning": ("Planning", "Planning complete", "ellipsis"),
            "task_list": (
                "Compiling task list",
                "Task list compiled",
                "ellipsis",
            ),
        }

        def on_status(stage: str, message: str, progress_val: float):
            stage_lower = stage.lower()
            if stage_lower == current_stage[0]:
                return
            # Complete the outgoing stage
            if current_stage[0] == "generating" and code_gen_ui[0]:
                code_gen_ui[0].complete()
                code_gen_ui[0] = None
            elif current_stage[0] and current_stage[0] in stage_messages:
                _, complete_msg, _ = stage_messages[current_stage[0]]
                progress.complete(complete_msg)
            current_stage[0] = stage_lower
            if stage_lower == "generating":
                progress.stop()  # clear any ProgressIndicator line first
                if gen_start_time[0] is None:
                    gen_start_time[0] = time.time()
                code_gen_ui[0] = CodeGenerationUI()
                code_gen_ui[0].start(start_time=gen_start_time[0])
            elif stage_lower in stage_messages:
                start_msg, _, style = stage_messages[stage_lower]
                progress.start(start_msg, style=style)
            elif stage_lower == "complete":
                progress.stop()

        def on_tool_call(tool_name: str, result: dict):
            pass

        try:
            backend_config = get_backend_config(working_dir)
            result = run_build_sync(
                query=query,
                project_schema=project_schema,
                working_dir=working_dir,
                output_file=output,
                validate=validate,
                docs=docs,
                generate_only=generate_only,
                todo_list_content=todo_list_content,
                context_bundle=context_bundle,
                on_status=on_status,
                on_tool_call=on_tool_call,
                url=backend_config.get("url"),
                host=backend_config.get("host"),
                port=(
                    int(backend_config.get("port"))
                    if backend_config.get("port")
                    else None
                ),
            )
        finally:
            progress.stop()
            if code_gen_ui[0]:
                code_gen_ui[0].stop()
            progress.reset_timer()

        # Write generated server code to disk (new direct path)
        server_code = result.get("server_code", "")
        if result.get("success") and server_code:
            output_path = os.path.join(working_dir, output)
            with open(output_path, "w", encoding="utf-8") as _f:
                _f.write(server_code)

        if not result.get("success"):
            error_type = result.get("error", "Unknown error occurred")

            # Handle insufficient context error from planner agent
            if error_type == "insufficient_context":
                display_insufficient_context_error(result)
                return

            # Handle other errors
            display_error_box("Build Failed", str(error_type))
            return

        # Display success message
        tool_count = result.get("tool_count", 0)
        resource_count = result.get("resource_count", 0)
        output_file = result.get("output_file", output)

        # Create tools list for display
        tools_display = (
            f"✓ {tool_count} Tool(s) implemented"
            if tool_count > 0
            else "  (No specific tools - check output)"
        )
        resources_display = (
            f"✓ {resource_count} Resource(s) implemented"
            if resource_count > 0
            else "  (No resources defined)"
        )

        details = f"""Generated Components:
  {tools_display}
  {resources_display}

Output: {output_file}

Next Steps:
  1. Review the generated server code
  2. Install MCP dependencies: pip install mcp
  3. Run the server: python {output_file}
  4. Configure your MCP client (e.g., Claude Desktop) to use this server"""

        display_success_box("MCP Server Generated!", details)

        mcp_config = json.dumps({
            "mcpServers": {
                "custom-server": {
                    "command": "python",
                    "args": [os.path.abspath(output_file)]
                }
            }
        }, indent=2)
        print(f"\n🛠️  Add the following to your configuration file for Claude, Cursor Desktop,")
        print(f"   or any other MCP host:\n")
        print(mcp_config)

        # Telemetry — track successful build via REST API
        try:
            from utils.config_manager import resolve_api_key
            from grpc_client.track_event import track_event
            _build_api_key = resolve_api_key(working_dir) or ""
            if _build_api_key:
                track_event(
                    "build",
                    api_key=_build_api_key,
                    working_dir=working_dir,
                    tool_count=tool_count,
                )
        except Exception:
            pass

        # Show crew output summary if available
        crew_output = result.get("crew_output", "")
        if crew_output and len(crew_output) > 100:
            print("\n📋 Generation Summary:")
            print("━" * 60)
            # Show last part of crew output (final documentation)
            summary_lines = crew_output.split("\n")[-20:]
            for line in summary_lines:
                if line.strip():
                    print(line)
            print("━" * 60)

    except FileNotFoundError as e:
        display_error_box("Configuration Error", str(e))
        return

    except KeyboardInterrupt:
        print("\n\n❌ Build cancelled by user")
        return

    except Exception as e:
        display_error_box(
            "Build Failed",
            f"An error occurred during MCP server generation:\n{str(e)}\n\n"
            "Please check your configuration and project schema, then try "
            "again.",
        )
        import traceback

        print("\n" + traceback.format_exc())
        return


def _detect_with_cache(
    all_functions: list,
    working_dir: str,
    project_schema: str,
    cache_path: str,
    backend_config: dict,
) -> list:
    """Run DetectEndpoints RPC with a per-file mtime cache.

    Only sends functions from new or modified files to the backend.
    Candidates for unchanged files are returned from cache immediately.
    Candidates for deleted files are removed from cache.

    Cache structure (JSON):
    {
        "file_mtimes": {"relative/path.py": 1234567890.0, ...},
        "candidates": [... DetectedEndpoint dicts ...]
    }

    Returns:
        List of raw DetectedEndpoint dicts sorted by confidence desc.
    """
    # Build a map of relative_path -> [functions] from all_functions
    from collections import defaultdict

    funcs_by_file: dict[str, list] = defaultdict(list)
    for fn in all_functions:
        funcs_by_file[fn.get("file_path", "")].append(fn)

    # Get current mtimes for all files that have functions
    current_mtimes: dict[str, float] = {}
    for rel_path in funcs_by_file:
        abs_path = (
            os.path.join(working_dir, rel_path)
            if not os.path.isabs(rel_path)
            else rel_path
        )
        try:
            current_mtimes[rel_path] = os.path.getmtime(abs_path)
        except OSError:
            current_mtimes[rel_path] = 0.0

    # Load cache
    cached_mtimes: dict[str, float] = {}
    cached_candidates: list = []
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                cache = json.load(f)
            cached_mtimes = cache.get("file_mtimes", {})
            cached_candidates = cache.get("candidates", [])
        except (json.JSONDecodeError, OSError):
            pass

    # Identify changed/new files and deleted files
    changed_files = {
        rel
        for rel, mtime in current_mtimes.items()
        if abs(mtime - cached_mtimes.get(rel, -1)) > 0.001
    }
    deleted_files = set(cached_mtimes.keys()) - set(current_mtimes.keys())

    # If nothing changed and cache is populated, return immediately (no new detections)
    if not changed_files and not deleted_files and cached_candidates:
        return cached_candidates, 0

    # Prune candidates for deleted/changed files (re-detected below)
    stale_files = changed_files | deleted_files
    surviving_candidates = [
        c for c in cached_candidates if c.get("file_path", "") not in stale_files
    ]

    # Collect functions from changed/new files for backend classification
    functions_to_send = []
    for rel_path in changed_files:
        functions_to_send.extend(funcs_by_file[rel_path])

    new_candidates: list = []
    if functions_to_send:
        bc_port = backend_config.get("port")
        detect_result = run_detect_sync(
            functions=functions_to_send,
            working_dir=working_dir,
            project_schema=project_schema,
            url=backend_config.get("url"),
            host=backend_config.get("host"),
            port=int(bc_port) if bc_port else None,
        )
        if detect_result.get("error"):
            raise RuntimeError(detect_result["error"])
        new_candidates = detect_result.get("candidates", [])

    # Merge surviving cached candidates with newly detected ones
    merged = surviving_candidates + new_candidates
    merged.sort(key=lambda c: c.get("confidence", 0.0), reverse=True)

    # Persist updated cache
    try:
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(
                {"file_mtimes": current_mtimes, "candidates": merged},
                f,
                indent=2,
            )
    except OSError:
        pass

    return merged, len(new_candidates)


class _DetectedEndpointProxy:
    """Adapts a DetectedEndpoint dict to the EndpointCandidate interface.

    Used so that the existing display/selection UI helpers work without
    modification.
    """

    def __init__(self, raw: dict, working_dir: str) -> None:
        self.name = raw.get("name", "")
        # file_path from backend is relative; make it absolute
        rel = raw.get("file_path", "")
        if rel and not os.path.isabs(rel):
            self.file_path = os.path.join(working_dir, rel)
        else:
            self.file_path = rel
        self.signature = raw.get("signature", f"def {self.name}(...)")
        self.docstring = raw.get("docstring", "")
        self.return_type = (
            raw.get("return_type", "Any") if raw.get("return_type") else "Any"
        )
        self.confidence = float(raw.get("confidence", 0.5))
        self.reason = raw.get("subcategory", "")
        self.conversion_type = raw.get("conversion_type", "ready")
        self.subcategory = raw.get("subcategory", "")
        self.human_title = raw.get("human_title", self.name)
        self.human_description = raw.get("human_description", "")
        self.line_number = int(raw.get("line_number", 0))
        self.is_async = False
        self.parameters = []
        self.endpoint_type = "function"
        self.http_method = "N/A"
        self.route_path = "N/A"
        self.score = 0

        # Deserialise client_dependency from JSON string
        cd_json = raw.get("client_dependency_json", "")
        if cd_json:
            try:
                self.client_dependency = json.loads(cd_json)
            except (json.JSONDecodeError, TypeError):
                self.client_dependency = None
        else:
            self.client_dependency = None

    def display_line1(self) -> str:
        return f"{self.name}() - {self.human_title}"

    def display_line2(self) -> str:
        return self.human_description

    def display_line3(self, working_dir: str = "") -> str:
        rel = (
            os.path.relpath(self.file_path, working_dir)
            if working_dir
            else self.file_path
        )
        if self.confidence >= 0.7:
            conf = "Recommended"
        elif self.confidence >= 0.5:
            conf = "Good candidate"
        else:
            conf = "May need refinement"
        return f"{rel}  •  {conf}"


if __name__ == "__main__":
    # For testing
    import sys

    query_arg = None
    output_arg = "mcp_server.py"

    # Parse simple arguments
    for i, arg in enumerate(sys.argv[1:]):
        if arg in ["-q", "--query"] and i + 1 < len(sys.argv) - 1:
            query_arg = sys.argv[i + 2]
        elif arg in ["-o", "--output"] and i + 1 < len(sys.argv) - 1:
            output_arg = sys.argv[i + 2]

    run_build_command(query=query_arg, output=output_arg)
