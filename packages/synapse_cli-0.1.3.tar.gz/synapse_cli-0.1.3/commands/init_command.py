"""Implementation of 'synapse init' command"""

import json
import os
from datetime import datetime

from utils.cli_utils import (
    display_banner,
    display_error_box,
    display_success_box,
    display_welcome_message,
    prompt_for_input,
)
from utils.code_indexer import create_collection
from utils.config_manager import (
    ensure_global_synapse_dir,
    ensure_project_synapse_dir,
    get_global_api_key_encrypted,
    load_global_config,
    save_global_config,
)


def run_init(force: bool = False) -> None:
    """
    Handles 'synapse init' command execution.

    Initializes Synapse for the current directory:
    1. Ensure ~/.synapse and PROJECT_ROOT/.synapse exist
    2. Create basic config file (with API key if prompted or from global)
    3. Set up code context database (Qdrant)
    4. Display welcome message with commands

    API key: If global key exists, reuse for project. If not, prompt once and set both global and project.
    """
    working_dir = os.getcwd()
    synapse_dir = os.path.join(working_dir, ".synapse")

    if os.path.exists(synapse_dir) and not force:
        display_success_box(
            "Already Initialized",
            "Synapse is already initialized in this directory.\n"
            "Use 'synapse init --force' to re-initialize.",
        )
        return

    try:
        display_banner()

        # Ensure both global and project .synapse directories exist
        print("\n✓ Creating .synapse directory...")
        ensure_global_synapse_dir()
        ensure_project_synapse_dir(working_dir)

        config = {
            "initialized": True,
            "version": "1.0.0",
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        }

        # API key: global exists -> reuse for project; else prompt and set both
        global_prefix, global_encrypted = get_global_api_key_encrypted()
        if global_prefix is not None and global_encrypted:
            config["api_key_prefix"] = global_prefix
            config["api_key_encrypted"] = global_encrypted
            print("✓ Using existing global API key for this project.")
        else:

            def _key_validator(v: str):
                if not (v or "").strip():
                    return (False, "API key cannot be empty")
                return (True, "")

            raw_key = prompt_for_input(
                "Enter your API key:",
                mask=True,
                validator=_key_validator,
            )
            raw_key = (raw_key or "").strip()
            if not raw_key:
                print(
                    "❌ API key is required. Run 'synapse config --key <API_KEY>' later to set it."
                )
            else:
                from utils.api_key_store import encrypt_api_key

                prefix, encrypted = encrypt_api_key(raw_key)
                config["api_key_prefix"] = prefix
                config["api_key_encrypted"] = encrypted
                # Write global so future inits can reuse
                global_cfg = load_global_config()
                global_cfg["api_key_prefix"] = prefix
                global_cfg["api_key_encrypted"] = encrypted
                save_global_config(global_cfg)
                print("✓ Global API key is set.")
                print("✓ Project API key is set.")

        print("✓ Creating configuration...")
        config_path = os.path.join(synapse_dir, "config.json")
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        # Create Qdrant collection for code context
        print("✓ Setting up code context database...")
        try:
            create_collection(synapse_dir, "code_context")
        except Exception as e:
            print(f"  ⚠ Warning: Could not create code context database: {str(e)}")
            print("  Code indexing may not work until this is resolved.")

        print("✓ Initialization complete!")

        # Telemetry — fire and forget after init succeeds, never blocks
        try:
            _raw_key = ""
            if config.get("api_key_encrypted"):
                from utils.api_key_store import decrypt_api_key
                try:
                    _raw_key = decrypt_api_key(config["api_key_encrypted"])
                except Exception:
                    pass
            from grpc_client.track_event import track_event
            track_event("init", api_key=_raw_key, working_dir=working_dir)
        except Exception:
            pass

        commands = {
            "synapse analyze": "Scan & index your codebase",
            "synapse build": "Generate MCP server from your code",
            "synapse status": "Check project status",
            "synapse config": "View or update configuration",
            "synapse auth": "Manage API keys",
            "synapse help": "Show all commands and options",
        }
        display_welcome_message(commands)

    except KeyboardInterrupt:
        print("\n\n❌ Initialization cancelled by user")
        return
    except Exception as e:
        display_error_box("Initialization Failed", str(e))
        return


if __name__ == "__main__":
    # For testing
    run_init()
