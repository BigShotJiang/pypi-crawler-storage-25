"""Implementation of 'synapse analyze' command - Local analysis only"""

import os

from utils.cli_utils import (
    HAS_RICH,
    ProgressIndicator,
    display_error_box,
    display_header,
    sunset_console,
)
from utils.code_indexer import (
    index_project,
    initialize_index_metadata,
    store_chunks,
)
from utils.codebase_analyzer import analyze_codebase, save_analysis_results
from utils.config_manager import is_initialized

GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"


def _step_ok(label: str, detail: str = "") -> None:
    """Print a completed step line."""
    suffix = f"  {detail}" if detail else ""
    print(f"  {GREEN}✓{RESET}  {label}{suffix}")


def _step_warn(label: str) -> None:
    print(f"  {YELLOW}⚠{RESET}  {label}")


def run_analyze(output_dir: str = ".synapse", verbose: bool = False) -> None:
    """
    Handles 'synapse analyze' command execution.

    Performs LOCAL analysis only (no AI/LLM calls):
      1. Scan directory structure & parse Python files (AST)
      2. Generate project_schema.txt + statistics.json
      3. Index code for semantic search (Qdrant)

    Args:
        output_dir: Directory to output analysis results (default: .synapse)
        verbose: Whether to enable verbose output
    """
    working_dir = os.getcwd()
    synapse_dir = os.path.join(working_dir, output_dir)

    if not is_initialized(working_dir):
        display_error_box(
            "Not Initialized",
            "Synapse is not initialized in this directory.\n"
            "Run 'synapse init' first.",
        )
        return

    # Pre-flight quota check — fail fast before expensive indexing
    try:
        from utils.config_manager import resolve_api_key
        from grpc_client.track_event import check_quota

        _api_key = resolve_api_key(working_dir) or ""
        if _api_key:
            _exceeded, _msg = check_quota(_api_key)
            if _exceeded:
                print(f"\n  {_msg}")
                return
    except Exception:
        pass  # fail open if backend unreachable

    try:
        display_header("Analyzing Codebase", "🔍")
        print()

        progress = ProgressIndicator()

        # ── Step 1: AST scan ────────────────────────────────────────────────
        progress.start("Scanning codebase", style="ellipsis", show_timer=True)
        try:
            schema_text, statistics = analyze_codebase(working_dir)
        finally:
            progress.stop()

        n_files = statistics.get("file_count", 0)
        n_classes = statistics.get("class_count", 0)
        n_funcs = statistics.get("function_count", 0)
        _step_ok(
            "Scanned codebase",
            f"{n_files} files · {n_classes} classes · {n_funcs} functions",
        )

        # ── Step 2: Save results ────────────────────────────────────────────
        progress.start(
            "Saving analysis results",
            style="ellipsis",
            show_timer=True,
        )
        try:
            save_analysis_results(synapse_dir, schema_text, statistics)
        finally:
            progress.stop()
        _step_ok("Saved project schema and statistics")

        # ── Step 3: Embed + index ───────────────────────────────────────────
        progress.start(
            "Embedding code chunks",
            style="orbital",
            show_timer=True,
        )
        try:
            chunks = index_project(working_dir, verbose=verbose)
        finally:
            progress.stop()

        progress.start("Storing vectors", style="ellipsis", show_timer=True)
        try:
            chunk_count = store_chunks(chunks, synapse_dir, "code_context")
        finally:
            progress.complete("Analysis complete")

        if chunk_count > 0:
            initialize_index_metadata(working_dir, synapse_dir)
            _step_ok(
                "Indexed code for semantic search",
                f"{chunk_count} chunks",
            )
        else:
            _step_warn("Code indexing produced no chunks — check your project files")

        # ── Final results ───────────────────────────────────────────────────
        stats = statistics
        print()
        _render_results(stats, chunk_count, output_dir)

        # Verbose: top modules table
        if verbose and stats.get("modules"):
            _render_modules_table(stats["modules"])

        # ── Telemetry + quota reporting ───────────────────────────────────────
        # Only report newly analyzed lines (delta from previous run)
        try:
            from utils.config_manager import resolve_api_key
            from grpc_client.track_event import track_event
            import json as _json

            _api_key = resolve_api_key(working_dir) or ""
            _total_lines = stats.get("total_lines_analyzed", 0)

            _prev_lines = 0
            _prev_stats_path = os.path.join(synapse_dir, "statistics.prev.json")
            if os.path.exists(_prev_stats_path):
                try:
                    with open(_prev_stats_path, "r") as _f:
                        _prev_lines = _json.load(_f).get("total_lines_analyzed", 0)
                except Exception:
                    pass

            _delta = max(_total_lines - _prev_lines, 0)

            if _delta > 0 and _api_key:
                track_event(
                    "analyze",
                    api_key=_api_key,
                    working_dir=working_dir,
                    lines_count=_delta,
                )

            # Save current stats as previous for next run
            try:
                with open(_prev_stats_path, "w") as _f:
                    _json.dump({"total_lines_analyzed": _total_lines}, _f)
            except Exception:
                pass
        except Exception:
            pass

    except Exception as e:
        display_error_box("Analysis Failed", str(e))
        if verbose:
            import traceback

            print("\n" + traceback.format_exc())


def _render_results(stats: dict, chunk_count: int, output_dir: str) -> None:
    """Render the final analysis summary (Rich or plain text)."""
    if HAS_RICH and sunset_console:
        from rich.box import ROUNDED
        from rich.panel import Panel
        from rich.text import Text

        t = Text()
        t.append("✅  Analysis Complete\n\n", style="bold color(70)")

        t.append("Codebase Overview\n", style="bold color(220)")
        t.append("─" * 30 + "\n", style="color(94)")

        rows = [
            ("📁", "Directories", stats.get("directory_count", 0)),
            ("📄", "Python Files", stats.get("file_count", 0)),
            ("📝", "Lines", stats.get("total_lines_analyzed", 0)),
            ("📦", "Classes", stats.get("class_count", 0)),
            ("⚡", "Functions", stats.get("function_count", 0)),
            ("🔧", "Methods", stats.get("method_count", 0)),
            ("🔍", "Code Chunks", chunk_count),
        ]
        for icon, label, value in rows:
            t.append(f"  {icon}  {label:<18}", style="color(230)")
            t.append(f"{value:,}\n", style="bold color(220)")

        t.append("\nOutput Saved\n", style="bold color(220)")
        t.append("─" * 30 + "\n", style="color(94)")
        for fname in (
            f"{output_dir}/project_schema.txt",
            f"{output_dir}/statistics.json",
            f"{output_dir}/code_context",
        ):
            t.append(f"  ✓  {fname}\n", style="color(180)")

        t.append("\nNext step: ", style="color(180)")
        t.append("synapse build", style="bold color(39)")

        sunset_console.print(
            Panel(
                t,
                border_style="color(70)",
                padding=(1, 2),
                box=ROUNDED,
                expand=False,
            )
        )
        sunset_console.print()
    else:
        s = stats
        print("\n✅ Analysis Complete\n")
        print(f"  📁 Directories:  {s.get('directory_count', 0)}")
        print(f"  📄 Python Files: {s.get('file_count', 0)}")
        print(f"  📝 Lines:        {s.get('total_lines_analyzed', 0)}")
        print(f"  📦 Classes:      {s.get('class_count', 0)}")
        print(f"  ⚡ Functions:    {s.get('function_count', 0)}")
        print(f"  🔍 Code Chunks:  {chunk_count}")
        print("\nNext step: synapse build")


def _render_modules_table(modules: list) -> None:
    """Render top-10 modules by complexity as a Rich table or plain text."""
    sorted_mods = sorted(
        modules, key=lambda m: m["classes"] + m["functions"], reverse=True
    )[:10]

    if HAS_RICH and sunset_console:
        from rich.table import Table

        tbl = Table(
            title="Top Modules by Complexity",
            border_style="sunset.border",
            header_style="bold color(220)",
            show_lines=False,
        )
        tbl.add_column("#", style="color(180)", width=3)
        tbl.add_column("Module", style="color(230)")
        tbl.add_column("Classes", style="bold color(214)", justify="right")
        tbl.add_column("Functions", style="bold color(214)", justify="right")
        for i, m in enumerate(sorted_mods, 1):
            tbl.add_row(
                str(i),
                m["name"],
                str(m["classes"]),
                str(m["functions"]),
            )
        sunset_console.print()
        sunset_console.print(tbl)
        sunset_console.print()
    else:
        print("\n📊 Top Modules by Complexity:")
        for i, m in enumerate(sorted_mods, 1):
            line = (
                f"  {i}. {m['name']:<35} {m['classes']} classes, "
                f"{m['functions']} functions"
            )
            print(line)


if __name__ == "__main__":
    # For testing
    run_analyze(verbose=True)
