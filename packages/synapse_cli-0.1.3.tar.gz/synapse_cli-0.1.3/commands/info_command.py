"""synapse info — show project status and account quota usage."""

import json
import os
from datetime import datetime


def run_info() -> None:
    working_dir = os.getcwd()
    synapse_dir = os.path.join(working_dir, ".synapse")

    from utils.cli_utils import display_header

    display_header("Synapse Info", "📊")
    print()

    # ── Project status ─────────────────────────────────────────────
    _print_project_status(working_dir, synapse_dir)

    # ── Account quota ──────────────────────────────────────────────
    _print_quota(working_dir)

    print()


def _print_project_status(working_dir: str, synapse_dir: str) -> None:
    from utils.config_manager import is_initialized, load_config, get_api_key_display

    print("  Project")
    print("  " + "─" * 50)

    if not is_initialized(working_dir):
        print("  Status:          Not initialized")
        print("  Run 'synapse init' to get started.")
        print()
        return

    print("  Status:          Initialized")

    try:
        config = load_config(working_dir)
        print(f"  Version:         {config.get('version', '—')}")
        created = config.get("created_at", "")
        if created:
            try:
                dt = datetime.fromisoformat(created)
                print(f"  Created:         {dt.strftime('%Y-%m-%d %H:%M')}")
            except ValueError:
                print(f"  Created:         {created}")
    except FileNotFoundError:
        pass

    proj_display, global_display = get_api_key_display(working_dir)
    if proj_display:
        print(f"  API key:         {proj_display} (project)")
    elif global_display:
        print(f"  API key:         {global_display} (global)")
    else:
        print("  API key:         Not set")

    # Analysis stats
    schema_path = os.path.join(synapse_dir, "project_schema.txt")
    stats_path = os.path.join(synapse_dir, "statistics.json")
    if os.path.exists(stats_path):
        try:
            with open(stats_path, "r") as f:
                stats = json.load(f)
            files = stats.get("file_count", 0)
            classes = stats.get("class_count", 0)
            funcs = stats.get("function_count", 0)
            print(f"  Analyzed:        {files} files · {classes} classes · {funcs} functions")
        except (json.JSONDecodeError, OSError):
            pass
    elif os.path.exists(schema_path):
        print("  Analyzed:        Yes")
    else:
        print("  Analyzed:        Not yet  (run 'synapse analyze')")

    # Index metadata
    from utils.code_indexer import load_index_metadata

    meta = load_index_metadata(synapse_dir)
    if meta:
        print(f"  Indexed files:   {len(meta)}")

    print()


def _print_quota(working_dir: str) -> None:
    from utils.config_manager import resolve_api_key, get_api_url

    api_key = resolve_api_key(working_dir)
    if not api_key:
        print("  Account Quota")
        print("  " + "─" * 50)
        print("  Not available (no API key configured)")
        return

    import json as _json
    import urllib.request
    import urllib.error

    api_url = get_api_url()
    try:
        req = urllib.request.Request(
            f"{api_url}/quota",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            info = _json.loads(resp.read())
    except Exception:
        print("  Account Quota")
        print("  " + "─" * 50)
        print("  Could not reach backend — check your connection.")
        return

    print("  Account Quota")
    print("  " + "─" * 50)

    servers_used = info["mcp_servers_count"]
    servers_max = info["max_mcp_servers"]
    servers_remaining = max(0, servers_max - servers_used)
    print(f"  MCP servers:     {servers_used} / {servers_max} used  ({servers_remaining} remaining)")

    lines_used = info["lines_indexed"]
    lines_max = info["max_lines_indexed"]
    lines_remaining = max(0, lines_max - lines_used)
    print(f"  Lines indexed:   {_fmt_number(lines_used)} / {_fmt_number(lines_max)}  ({_fmt_number(lines_remaining)} remaining)")

    if info.get("quota_exceeded"):
        print()
        print(f"  ⚠  {info.get('quota_message', 'Quota exceeded.')}")


def _fmt_number(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)
