"""Implementation of 'synapse config' command"""

import json
import os
from typing import Optional

from utils.cli_utils import display_error_box, display_header
from utils.config_manager import (
    ensure_project_synapse_dir,
    get_api_key_display,
    get_backend_config,
    has_global_api_key,
    is_initialized,
    set_global_api_key,
    set_project_api_key,
)


def run_config(
    update: bool = False,
    api_key: Optional[str] = None,
    global_scope: bool = False,
) -> None:
    """
    Handles 'synapse config' command execution.

    Displays current configuration and optionally sets API key (project or global).
    API keys are shown as first 5 characters + ****.
    """
    working_dir = os.getcwd()
    synapse_dir = os.path.join(working_dir, ".synapse")

    # --key: set project and/or global key
    if api_key is not None:
        raw = (api_key or "").strip()
        if not raw:
            display_error_box("Invalid Input", "API key cannot be empty.")
            return
        if global_scope:
            set_global_api_key(raw)
            print("✓ Global API key is set.")
            return
        # Set project key; if no global key yet, set global too
        ensure_project_synapse_dir(working_dir)
        if not is_initialized(working_dir):
            # Create minimal project config with key only
            set_project_api_key(working_dir, raw)
        else:
            set_project_api_key(working_dir, raw)
        if not has_global_api_key():
            set_global_api_key(raw)
            print("✓ Global API key is set.")
        print("✓ Project API key is set.")
        return

    # View config: require initialized project
    if not os.path.exists(synapse_dir):
        display_error_box(
            "Not Initialized",
            "Synapse is not initialized in this directory.\n"
            "Please run 'synapse init' first.",
        )
        return

    config_path = os.path.join(synapse_dir, "config.json")
    if not os.path.exists(config_path):
        display_error_box(
            "Configuration Not Found",
            "Configuration file not found.\nPlease run 'synapse init' first.",
        )
        return

    try:
        with open(config_path, "r") as f:
            config = json.load(f)

        display_header("Synapse Configuration", "📋")

        project_key_display, global_key_display = get_api_key_display(working_dir)

        print("\n📁 Local Configuration:")
        print("━" * 60)
        print("  Initialized:    ✓ Yes")
        print(f"  Version:        {config.get('version', 'Unknown')}")
        print(f"  Created:        {config.get('created_at', 'Unknown')}")
        print(f"  Last Updated:   {config.get('last_updated', 'Unknown')}")
        print(f"  API Key:        {project_key_display}")
        print("━" * 60)

        print("\n🔑 Global Configuration (~/.synapse):")
        print("━" * 60)
        print(f"  API Key:        {global_key_display}")
        print("━" * 60)

        schema_path = os.path.join(synapse_dir, "project_schema.txt")
        stats_path = os.path.join(synapse_dir, "statistics.json")

        print("\n📊 Analysis Status:")
        print("━" * 60)
        if os.path.exists(schema_path):
            print("  Project Schema: ✓ Generated")
        else:
            print("  Project Schema: ✗ Not generated (run 'synapse analyze')")

        if os.path.exists(stats_path):
            with open(stats_path, "r") as f:
                stats = json.load(f)
            print(f"  Files Analyzed: {stats.get('file_count', 0)}")
            print(f"  Functions:      {stats.get('function_count', 0)}")
            print(f"  Classes:        {stats.get('class_count', 0)}")
        else:
            print("  Statistics:     ✗ Not available")
        print("━" * 60)

        backend_config = get_backend_config(working_dir)

        print("\n📡 Backend Connection:")
        print("━" * 60)
        if backend_config.get("url"):
            print(f"  URL:            {backend_config['url']}")
        else:
            print(f"  Host:           {backend_config['host']}")
            print(f"  Port:           {backend_config['port']}")
        print("\n💡 Set API key: synapse config --key <API_KEY>")
        print("   Set global key: synapse config --global --key <API_KEY>")
        print("━" * 60)

        if update:
            print("\n⚠️  Note: Synapse backend configuration is handled by the backend.")
            print(
                "   Contact your administrator to configure Synapse backend settings."
            )

    except FileNotFoundError as e:
        display_error_box("Configuration Error", str(e))
        return
    except Exception as e:
        display_error_box("Configuration Error", f"An error occurred:\n{str(e)}")
        return


if __name__ == "__main__":
    # For testing
    import sys

    update_flag = "--update" in sys.argv
    run_config(update=update_flag)
