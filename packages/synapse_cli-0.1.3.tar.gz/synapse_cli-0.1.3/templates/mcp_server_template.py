"""
MCP Server Template

This is a reference template showing the structure of an MCP server using FastMCP.
Generated servers follow this pattern and use the latest MCP standards.
"""

import logging

from mcp.server.fastmcp import FastMCP

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize MCP server using FastMCP
server = FastMCP("template_server")


# ============================================================================
# TOOL DEFINITIONS
# ============================================================================


@server.tool()
async def example_tool(param1: str, param2: int) -> str:
    """Example tool that demonstrates the structure."""
    if not param1:
        raise ValueError("param1 cannot be empty")
    if param2 < 0:
        raise ValueError("param2 must be non-negative")

    result = f"Processed: {param1} with value {param2}"
    logger.info(f"example_tool called with param1={param1}, param2={param2}")
    return result


# ============================================================================
# SIMPLE ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    server.run()
