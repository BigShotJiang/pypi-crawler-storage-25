"""MCP server templates"""
