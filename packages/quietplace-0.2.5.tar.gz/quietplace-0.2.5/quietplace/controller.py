from __future__ import annotations

import gc
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .audio import Event
from .config import DEFAULT_VLLM_API_KEY, DEFAULT_VLLM_BASE_URL, DEFAULT_VLLM_MODEL, DEFAULT_TRANSFORMERS_MODEL

DEFAULT_CONTROLLER_REDUCTION_DB = float(os.getenv("QP_CONTROLLER_REDUCTION_DB", "24"))
DEFAULT_CONTROLLER_NOTCH_Q = float(os.getenv("QP_CONTROLLER_NOTCH_Q", "45"))

SYSTEM_RULES = f"""
You are QuietPlace's local semantic audio policy controller.
Your job is to translate an event table and spectral features into a safe DSP plan.

Hard safety rules:
- Preserve safety-critical sounds: siren, alarm, speech/help, baby cry, knock, emergency vehicle.
- Suppress nuisance sounds only where safe: traffic, fan/engine hum, HVAC, generator, drilling.
- Use only whitelisted DSP actions: apply_notch, apply_semantic_spectral_gate, copy_original_for_segments.
- Do not invent events not present in the table.
- Prefer conservative reduction if labels are uncertain.

Executor-critical output rules:
- Always split suppress_segments_sec around preserve_segments_sec. Never suppress through a protected interval.
- Always include target_segments_sec in every suppression action.
- For sleep/noise-reduction demos, use reduction_db between 20 and 30. Default: {DEFAULT_CONTROLLER_REDUCTION_DB:g}.
- Always include apply_notch for dominant_freqs_hz in the 50-500 Hz range. Default quality_factor: {DEFAULT_CONTROLLER_NOTCH_Q:g}.
- Always include copy_original_for_segments for preserve_segments_sec.
Return one JSON object only. Never include markdown.
""".strip()


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _debug_log(stage: str, message: str, payload: Any | None = None) -> None:
    if not _env_bool("QP_DEBUG", False):
        return
    print(f"[quietplace][{stage}] {message}", flush=True)
    if payload is not None:
        try:
            print(json.dumps(payload, ensure_ascii=False, indent=2, default=str), flush=True)
        except Exception:
            print(repr(payload), flush=True)


def _clean_segments(raw: Any, duration: float) -> list[list[float]]:
    out: list[list[float]] = []
    if not isinstance(raw, list):
        return out
    for seg in raw:
        if not isinstance(seg, (list, tuple)) or len(seg) < 2:
            continue
        try:
            a = max(0.0, min(duration, float(seg[0])))
            b = max(0.0, min(duration, float(seg[1])))
        except Exception:
            continue
        if b - a > 0.03:
            out.append([round(a, 3), round(b, 3)])
    out.sort(key=lambda x: (x[0], x[1]))
    # Merge tiny overlaps/gaps.
    merged: list[list[float]] = []
    for a, b in out:
        if merged and a <= merged[-1][1] + 0.02:
            merged[-1][1] = round(max(merged[-1][1], b), 3)
        else:
            merged.append([a, b])
    return merged


def _policy_preserve_segments(events: list[Event], duration: float) -> list[list[float]]:
    preserve: list[list[float]] = []
    for e in events:
        label = (e.label or "").lower()
        hint = (e.policy_hint or "").lower()
        is_preserve = hint == "preserve" or any(k in label for k in ["siren", "alarm", "speech", "voice", "help", "baby", "cry", "knock"])
        if is_preserve:
            a = max(0.0, min(duration, float(e.start)))
            b = max(0.0, min(duration, float(e.end)))
            if b > a:
                preserve.append([round(a, 3), round(b, 3)])
    return _clean_segments(preserve, duration)


def complement_segments(duration: float, preserve: list[list[float]], eps: float = 0.05) -> list[list[float]]:
    duration = max(0.0, float(duration))
    preserve = _clean_segments(preserve, duration)
    if duration <= eps:
        return []
    boundaries = sorted({0.0, duration, *[x for seg in preserve for x in seg]})

    def mid_is_protected(a: float, b: float) -> bool:
        mid = (a + b) / 2.0
        return any(s <= mid <= t for s, t in preserve)

    return [
        [round(a, 3), round(b, 3)]
        for a, b in zip(boundaries[:-1], boundaries[1:])
        if b - a > eps and not mid_is_protected(a, b)
    ]


def _dominant_notches(features: dict[str, Any]) -> list[float]:
    raw = features.get("dominant_freqs_hz", []) or []
    out: list[float] = []
    for f in raw:
        try:
            f = float(f)
        except Exception:
            continue
        if 50 <= f <= 500:
            out.append(round(f, 3))
    # Stable synthetic-demo fallback.
    if not out:
        out = [120.0, 240.0, 360.0]
    return sorted(set(out))[:6]


def default_controller_plan(user_goal: str, events: list[Event], features: dict[str, Any], reason: str | None = None) -> dict[str, Any]:
    duration = float(features.get("duration_sec", max((e.end for e in events), default=0.0)))
    preserve = _policy_preserve_segments(events, duration)
    suppress = complement_segments(duration, preserve)
    notches = _dominant_notches(features)
    plan = {
        "controller_name": "QuietPlace high-gain safety controller",
        "goal": user_goal,
        "preserve_segments_sec": preserve,
        "suppress_segments_sec": suppress,
        "actions": [
            {
                "function": "apply_notch",
                "args": {
                    "frequencies_hz": notches,
                    "quality_factor": DEFAULT_CONTROLLER_NOTCH_Q,
                    "target_segments_sec": suppress,
                },
            },
            {
                "function": "apply_semantic_spectral_gate",
                "args": {
                    "target_segments_sec": suppress,
                    "preserve_segments_sec": preserve,
                    "reduction_db": DEFAULT_CONTROLLER_REDUCTION_DB,
                },
            },
            {"function": "copy_original_for_segments", "args": {"preserve_segments_sec": preserve}},
        ],
        "explanation": (
            "Tonal hum/engine components are notched and broadband nuisance intervals are gated. "
            "Safety-critical siren/speech intervals are copied back unchanged."
        ),
    }
    if reason:
        plan["fallback_reason"] = reason
    return plan


# Backwards-compatible name used by tests/older callers.
def fallback_plan(user_goal: str, events: list[Event], features: dict[str, Any], reason: str | None = None) -> dict[str, Any]:
    return default_controller_plan(user_goal, events, features, reason=reason)


def controller_payload(user_goal: str, events: list[Event], features: dict[str, Any]) -> dict[str, Any]:
    return {
        "user_goal": user_goal,
        "events": [e.as_dict() for e in events],
        "spectral_features": features,
        "required_output": {
            "preserve_segments_sec": "list of [start,end] safety intervals",
            "suppress_segments_sec": "list of [start,end] nuisance intervals split around preserved intervals",
            "actions": "ordered whitelist action calls with target_segments_sec and numeric reduction args",
            "explanation": "plain English safety rationale",
        },
    }


def controller_messages(user_goal: str, events: list[Event], features: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": SYSTEM_RULES},
        {
            "role": "user",
            "content": "Create one safe QuietPlace controller plan for this soundscape.\n" + json.dumps(controller_payload(user_goal, events, features), indent=2),
        },
    ]


def controller_tools() -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": "program_suppressor",
                "description": "Return the complete QuietPlace controller plan. The executor will run only whitelisted actions.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "controller_name": {"type": "string"},
                        "preserve_segments_sec": {
                            "type": "array",
                            "items": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2},
                        },
                        "suppress_segments_sec": {
                            "type": "array",
                            "items": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2},
                        },
                        "actions": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "function": {"type": "string", "enum": ["apply_notch", "apply_semantic_spectral_gate", "copy_original_for_segments"]},
                                    "args": {"type": "object"},
                                },
                                "required": ["function", "args"],
                            },
                        },
                        "explanation": {"type": "string"},
                    },
                    "required": ["preserve_segments_sec", "suppress_segments_sec", "actions", "explanation"],
                },
            },
        }
    ]


def parse_jsonish(text: str) -> dict[str, Any]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.strip("`").removeprefix("json").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if 0 <= start < end:
            return json.loads(text[start : end + 1])
        raise


def normalize_plan(plan: dict[str, Any], user_goal: str, events: list[Event], features: dict[str, Any]) -> dict[str, Any]:
    """Repair model JSON into an executor-safe high-gain plan.

    Gemma sometimes emits semantically correct but underspecified actions such as
    apply_semantic_spectral_gate({"mask_type": "traffic_noise"}). This function
    fills executor-critical args, splits target spans around preserved spans,
    adds a notch stage for detected hum, and always appends safety copy-back.
    """
    if not isinstance(plan, dict):
        raise ValueError("controller plan must be a JSON object")

    base = default_controller_plan(user_goal, events, features)
    duration = float(features.get("duration_sec", max((e.end for e in events), default=0.0)))

    preserve = _clean_segments(plan.get("preserve_segments_sec") or base["preserve_segments_sec"], duration)
    if not preserve:
        preserve = base["preserve_segments_sec"]

    # Always recompute suppress spans from preserved spans. This prevents model
    # outputs such as [[0, duration]] from suppressing through safety intervals.
    suppress = complement_segments(duration, preserve)
    notches = _dominant_notches(features)

    allowed = {"apply_notch", "apply_semantic_spectral_gate", "copy_original_for_segments", "apply_spectral_gate"}
    raw_actions = plan.get("actions") if isinstance(plan.get("actions"), list) else []
    repaired: list[dict[str, Any]] = []
    saw_notch = False
    saw_gate = False
    saw_copy = False

    for action in raw_actions:
        if not isinstance(action, dict):
            continue
        fn = action.get("function") or action.get("name")
        if fn == "apply_spectral_gate":
            fn = "apply_semantic_spectral_gate"
        if fn not in allowed:
            continue
        args = dict(action.get("args") or {})
        if fn == "apply_notch":
            saw_notch = True
            args["frequencies_hz"] = args.get("frequencies_hz") or notches
            args["quality_factor"] = float(args.get("quality_factor", DEFAULT_CONTROLLER_NOTCH_Q))
            args["target_segments_sec"] = suppress
        elif fn == "apply_semantic_spectral_gate":
            saw_gate = True
            args["target_segments_sec"] = suppress
            args["preserve_segments_sec"] = preserve
            args["reduction_db"] = float(args.get("reduction_db", DEFAULT_CONTROLLER_REDUCTION_DB))
        elif fn == "copy_original_for_segments":
            saw_copy = True
            args["preserve_segments_sec"] = preserve
        repaired.append({"function": fn, "args": args})

    if not saw_notch:
        repaired.insert(0, base["actions"][0])
    if not saw_gate:
        repaired.append(base["actions"][1])
    if not saw_copy:
        repaired.append(base["actions"][2])

    out = dict(plan)
    out.setdefault("controller_name", base["controller_name"])
    out.setdefault("goal", user_goal)
    out.setdefault("explanation", base["explanation"])
    out["preserve_segments_sec"] = preserve
    out["suppress_segments_sec"] = suppress
    out["actions"] = repaired
    out["normalization"] = {
        "filled_missing_gain_args": True,
        "recomputed_suppress_segments_around_preserve": True,
        "default_reduction_db": DEFAULT_CONTROLLER_REDUCTION_DB,
        "default_notch_q": DEFAULT_CONTROLLER_NOTCH_Q,
    }
    return out


def ask_vllm(
    user_goal: str,
    events: list[Event],
    features: dict[str, Any],
    base_url: str = DEFAULT_VLLM_BASE_URL,
    api_key: str = DEFAULT_VLLM_API_KEY,
    model: str = DEFAULT_VLLM_MODEL,
    timeout: float = 120.0,
    temperature: float = 0.1,
    use_tools: bool = True,
) -> dict[str, Any]:
    from openai import OpenAI

    client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": controller_messages(user_goal, events, features),
        "temperature": temperature,
    }
    if use_tools:
        kwargs["tools"] = controller_tools()
        kwargs["tool_choice"] = "auto"
    else:
        kwargs["response_format"] = {"type": "json_object"}

    response = client.chat.completions.create(**kwargs)
    msg = response.choices[0].message
    tool_calls = getattr(msg, "tool_calls", None) or []
    if tool_calls:
        args = tool_calls[0].function.arguments
        plan = json.loads(args)
    else:
        plan = parse_jsonish(msg.content or "{}")
    out = normalize_plan(plan, user_goal, events, features)
    out["controller_backend"] = "vllm"
    out["controller_model"] = model
    return out


def _json_plan_messages(user_goal: str, events: list[Event], features: dict[str, Any]) -> list[dict[str, str]]:
    messages = controller_messages(user_goal, events, features)
    schema = controller_tools()[0]["function"]["parameters"]
    messages[0]["content"] += (
        "\n\nOutput contract for Transformers backend:"
        "\n- Return ONLY one valid JSON object."
        "\n- Do not wrap it in markdown."
        "\n- Include numeric reduction_db, quality_factor, frequencies_hz, and target_segments_sec."
        "\n- JSON schema shape: " + json.dumps(schema, ensure_ascii=False)
    )
    messages[1]["content"] += "\n\nReturn only the controller JSON object now."
    return messages


def _format_chat(tokenizer_or_processor: Any, messages: list[dict[str, str]]) -> str:
    if hasattr(tokenizer_or_processor, "apply_chat_template"):
        try:
            return tokenizer_or_processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        except TypeError:
            pass
    return "\n\n".join(f"{m['role'].upper()}: {m['content']}" for m in messages) + "\n\nASSISTANT:"


@dataclass(frozen=True)
class TransformersControllerConfig:
    model: str = DEFAULT_TRANSFORMERS_MODEL
    max_new_tokens: int = int(os.getenv("QP_TRANSFORMERS_MAX_NEW_TOKENS", "768"))
    load_in_4bit: bool = _env_bool("QP_TRANSFORMERS_LOAD_IN_4BIT", False)
    device_map: str = os.getenv("QP_TRANSFORMERS_DEVICE_MAP", "auto")
    dtype: str = os.getenv("QP_TRANSFORMERS_DTYPE", "float16")
    attn_implementation: str | None = os.getenv("QP_TRANSFORMERS_ATTN", "eager") or None


class TransformersController:
    def __init__(self, config: TransformersControllerConfig | None = None):
        self.config = config or TransformersControllerConfig()
        self.model_obj = None
        self.tokenizer = None
        self.processor = None
        self.kind = None

    def _lazy_load(self) -> None:
        if self.model_obj is not None:
            return
        import torch
        from transformers import AutoProcessor, AutoTokenizer

        dtype = torch.float16 if self.config.dtype in {"float16", "fp16"} else torch.float32
        load_kwargs: dict[str, Any] = {
            "dtype": dtype,
            "device_map": self.config.device_map,
            "low_cpu_mem_usage": True,
        }
        if self.config.attn_implementation:
            load_kwargs["attn_implementation"] = self.config.attn_implementation
        if self.config.load_in_4bit:
            try:
                from transformers import BitsAndBytesConfig
            except Exception as exc:
                raise RuntimeError("QP_TRANSFORMERS_LOAD_IN_4BIT=1 requires bitsandbytes") from exc
            load_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=dtype,
            )
            load_kwargs.pop("dtype", None)

        candidates = []
        try:
            from transformers import AutoModelForImageTextToText
            candidates.append(("AutoModelForImageTextToText", AutoModelForImageTextToText, True))
        except Exception:
            pass
        try:
            from transformers import AutoModelForCausalLM
            candidates.append(("AutoModelForCausalLM", AutoModelForCausalLM, False))
        except Exception:
            pass

        errors: list[str] = []
        _debug_log("transformers", "loading Gemma controller model", {
            "model_id": self.config.model,
            "max_new_tokens": self.config.max_new_tokens,
            "load_in_4bit": self.config.load_in_4bit,
            "device_map": self.config.device_map,
            "attn_implementation": self.config.attn_implementation,
        })
        for name, model_cls, wants_processor in candidates:
            try:
                if wants_processor:
                    self.processor = AutoProcessor.from_pretrained(self.config.model)
                    self.tokenizer = getattr(self.processor, "tokenizer", None) or AutoTokenizer.from_pretrained(self.config.model)
                else:
                    self.processor = None
                    self.tokenizer = AutoTokenizer.from_pretrained(self.config.model)
                try:
                    self.model_obj = model_cls.from_pretrained(self.config.model, **load_kwargs)
                except TypeError:
                    retry_kwargs = dict(load_kwargs)
                    retry_kwargs["torch_dtype"] = retry_kwargs.pop("dtype", dtype)
                    self.model_obj = model_cls.from_pretrained(self.config.model, **retry_kwargs)
                self.model_obj.eval()
                self.kind = name
                _debug_log("transformers", "loaded Gemma controller model", {"model_class": name})
                return
            except Exception as exc:
                errors.append(f"{name}: {type(exc).__name__}: {exc}")
                self.model_obj = None
                self.processor = None
                self.tokenizer = None
                gc.collect()
                try:
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                except Exception:
                    pass
        raise RuntimeError("Could not load Transformers controller. Errors: " + " | ".join(errors))

    def ask(self, user_goal: str, events: list[Event], features: dict[str, Any]) -> dict[str, Any]:
        self._lazy_load()
        import torch

        assert self.model_obj is not None and self.tokenizer is not None
        formatter = self.processor or self.tokenizer
        prompt = _format_chat(formatter, _json_plan_messages(user_goal, events, features))

        if self.processor is not None:
            try:
                inputs = self.processor(text=prompt, return_tensors="pt")
            except Exception:
                inputs = self.tokenizer(prompt, return_tensors="pt")
        else:
            inputs = self.tokenizer(prompt, return_tensors="pt")

        device = getattr(self.model_obj, "device", None)
        if device is not None:
            inputs = {k: v.to(device) if hasattr(v, "to") else v for k, v in inputs.items()}

        input_len = int(inputs["input_ids"].shape[-1])
        gen_kwargs = {
            "max_new_tokens": int(self.config.max_new_tokens),
            "do_sample": False,
            "pad_token_id": getattr(self.tokenizer, "eos_token_id", None),
        }
        with torch.inference_mode():
            output = self.model_obj.generate(**inputs, **{k: v for k, v in gen_kwargs.items() if v is not None})
        text = self.tokenizer.decode(output[0][input_len:], skip_special_tokens=True).strip()
        _debug_log("transformers", "raw controller response", {"text_head": text[:2000]})
        plan = parse_jsonish(text)
        out = normalize_plan(plan, user_goal, events, features)
        out["controller_backend"] = "transformers"
        out["controller_model"] = self.config.model
        return out


_TRANSFORMERS_CONTROLLER: TransformersController | None = None


def ask_transformers(
    user_goal: str,
    events: list[Event],
    features: dict[str, Any],
    model: str = DEFAULT_TRANSFORMERS_MODEL,
) -> dict[str, Any]:
    global _TRANSFORMERS_CONTROLLER
    if _TRANSFORMERS_CONTROLLER is None or _TRANSFORMERS_CONTROLLER.config.model != model:
        _TRANSFORMERS_CONTROLLER = TransformersController(TransformersControllerConfig(model=model))
    return _TRANSFORMERS_CONTROLLER.ask(user_goal, events, features)


def get_controller_plan(
    user_goal: str,
    events: list[Event],
    features: dict[str, Any],
    backend: str = "auto",
    base_url: str = DEFAULT_VLLM_BASE_URL,
    api_key: str = DEFAULT_VLLM_API_KEY,
    model: str = DEFAULT_VLLM_MODEL,
) -> dict[str, Any]:
    backend = (backend or "auto").lower()
    if backend == "mock":
        return fallback_plan(user_goal, events, features)
    if backend == "transformers":
        try:
            return ask_transformers(user_goal, events, features, model=model or DEFAULT_TRANSFORMERS_MODEL)
        except Exception as exc:
            if _env_bool("QP_TRANSFORMERS_STRICT", False):
                raise
            return fallback_plan(user_goal, events, features, reason=repr(exc))
    try:
        return ask_vllm(user_goal, events, features, base_url=base_url, api_key=api_key, model=model)
    except Exception as exc:
        if backend == "vllm":
            raise
        return fallback_plan(user_goal, events, features, reason=repr(exc))


def save_plan(path: str | Path, plan: dict[str, Any]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(plan, indent=2))
