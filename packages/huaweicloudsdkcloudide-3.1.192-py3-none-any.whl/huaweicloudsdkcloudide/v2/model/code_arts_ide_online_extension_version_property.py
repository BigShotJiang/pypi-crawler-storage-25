# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CodeArtsIDEOnlineExtensionVersionProperty:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'int',
        'property_name': 'str',
        'property_value': 'str',
        'extension_version_id': 'str',
        'created_at': 'datetime',
        'updated_at': 'datetime'
    }

    attribute_map = {
        'id': 'id',
        'property_name': 'property_name',
        'property_value': 'property_value',
        'extension_version_id': 'extension_version_id',
        'created_at': 'created_at',
        'updated_at': 'updated_at'
    }

    def __init__(self, id=None, property_name=None, property_value=None, extension_version_id=None, created_at=None, updated_at=None):
        r"""CodeArtsIDEOnlineExtensionVersionProperty

        The model defined in huaweicloud sdk

        :param id: id
        :type id: int
        :param property_name: 参数名
        :type property_name: str
        :param property_value: 参数值
        :type property_value: str
        :param extension_version_id: 插件版本id
        :type extension_version_id: str
        :param created_at: 创建时间
        :type created_at: datetime
        :param updated_at: 更新时间
        :type updated_at: datetime
        """
        
        

        self._id = None
        self._property_name = None
        self._property_value = None
        self._extension_version_id = None
        self._created_at = None
        self._updated_at = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if property_name is not None:
            self.property_name = property_name
        if property_value is not None:
            self.property_value = property_value
        if extension_version_id is not None:
            self.extension_version_id = extension_version_id
        if created_at is not None:
            self.created_at = created_at
        if updated_at is not None:
            self.updated_at = updated_at

    @property
    def id(self):
        r"""Gets the id of this CodeArtsIDEOnlineExtensionVersionProperty.

        id

        :return: The id of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CodeArtsIDEOnlineExtensionVersionProperty.

        id

        :param id: The id of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type id: int
        """
        self._id = id

    @property
    def property_name(self):
        r"""Gets the property_name of this CodeArtsIDEOnlineExtensionVersionProperty.

        参数名

        :return: The property_name of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: str
        """
        return self._property_name

    @property_name.setter
    def property_name(self, property_name):
        r"""Sets the property_name of this CodeArtsIDEOnlineExtensionVersionProperty.

        参数名

        :param property_name: The property_name of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type property_name: str
        """
        self._property_name = property_name

    @property
    def property_value(self):
        r"""Gets the property_value of this CodeArtsIDEOnlineExtensionVersionProperty.

        参数值

        :return: The property_value of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: str
        """
        return self._property_value

    @property_value.setter
    def property_value(self, property_value):
        r"""Sets the property_value of this CodeArtsIDEOnlineExtensionVersionProperty.

        参数值

        :param property_value: The property_value of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type property_value: str
        """
        self._property_value = property_value

    @property
    def extension_version_id(self):
        r"""Gets the extension_version_id of this CodeArtsIDEOnlineExtensionVersionProperty.

        插件版本id

        :return: The extension_version_id of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: str
        """
        return self._extension_version_id

    @extension_version_id.setter
    def extension_version_id(self, extension_version_id):
        r"""Sets the extension_version_id of this CodeArtsIDEOnlineExtensionVersionProperty.

        插件版本id

        :param extension_version_id: The extension_version_id of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type extension_version_id: str
        """
        self._extension_version_id = extension_version_id

    @property
    def created_at(self):
        r"""Gets the created_at of this CodeArtsIDEOnlineExtensionVersionProperty.

        创建时间

        :return: The created_at of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: datetime
        """
        return self._created_at

    @created_at.setter
    def created_at(self, created_at):
        r"""Sets the created_at of this CodeArtsIDEOnlineExtensionVersionProperty.

        创建时间

        :param created_at: The created_at of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type created_at: datetime
        """
        self._created_at = created_at

    @property
    def updated_at(self):
        r"""Gets the updated_at of this CodeArtsIDEOnlineExtensionVersionProperty.

        更新时间

        :return: The updated_at of this CodeArtsIDEOnlineExtensionVersionProperty.
        :rtype: datetime
        """
        return self._updated_at

    @updated_at.setter
    def updated_at(self, updated_at):
        r"""Sets the updated_at of this CodeArtsIDEOnlineExtensionVersionProperty.

        更新时间

        :param updated_at: The updated_at of this CodeArtsIDEOnlineExtensionVersionProperty.
        :type updated_at: datetime
        """
        self._updated_at = updated_at

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CodeArtsIDEOnlineExtensionVersionProperty):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
