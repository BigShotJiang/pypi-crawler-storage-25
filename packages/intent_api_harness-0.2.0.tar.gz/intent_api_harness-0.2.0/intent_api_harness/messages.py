"""
Message types for the harness conversation.

All messages use `type` as the primary discriminated union discriminator
(matching the TypeScript harness pattern and SSE event convention).
`role` is retained as a convenience field for LLM message formatting.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field


# ── Role enum ─────────────────────────────────────────────────────────────────


class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


# ── Tool call / result ────────────────────────────────────────────────────────


class ToolCall(BaseModel):
    """A tool invocation requested by the model."""

    id: str
    tool_name: str
    input: dict[str, Any] = Field(default_factory=dict)


class ExecutionResult(BaseModel):
    """
    The outcome of a tool call dispatched through the Intent API.

    status values:
      - "success"          — handler returned normally
      - "denied"           — PermissionDenied from the runtime
      - "quota_exceeded"   — QuotaExceeded from the runtime
      - "upgrade_required" — PlanUpgradeRequired from the runtime
      - "error"            — any other exception
    """

    status: Literal["success", "denied", "quota_exceeded", "upgrade_required", "error"]
    data: Any | None = None
    message: str | None = None
    intent_id: str | None = None   # "{Model}.{action_or_command}" for correlation
    display: str | None = None     # human-readable label (from @custom_action or CRUD default)


# ── Base message ──────────────────────────────────────────────────────────────


class BaseMessage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=timezone.utc))


# ── Concrete message types ────────────────────────────────────────────────────


class UserMessage(BaseMessage):
    type: Literal["user"] = "user"
    role: Literal[MessageRole.USER] = MessageRole.USER
    content: str


class AssistantMessage(BaseMessage):
    type: Literal["assistant"] = "assistant"
    role: Literal[MessageRole.ASSISTANT] = MessageRole.ASSISTANT
    content: str | None = None
    tool_calls: list[ToolCall] | None = None
    thinking: str | None = None
    # Token usage reported by the model API for this response turn.
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0


class ToolResultMessage(BaseMessage):
    type: Literal["tool_result"] = "tool_result"
    role: Literal[MessageRole.TOOL] = MessageRole.TOOL
    tool_call_id: str
    result: ExecutionResult


class SystemMessage(BaseMessage):
    type: Literal["system"] = "system"
    role: Literal[MessageRole.SYSTEM] = MessageRole.SYSTEM
    subtype: str  # "init", "error", etc.
    content: str
    metadata: dict[str, Any] | None = None


class CompactBoundaryMessage(BaseMessage):
    """Injected into the message list after compaction to mark the boundary."""

    type: Literal["compact_boundary"] = "compact_boundary"
    role: Literal[MessageRole.SYSTEM] = MessageRole.SYSTEM
    subtype: Literal["compact_boundary"] = "compact_boundary"
    content: str = "Conversation compacted"
    pre_token_count: int = 0
    post_token_count: int = 0
    messages_summarized: int = 0


# ── Discriminated union ───────────────────────────────────────────────────────

Message = (
    UserMessage
    | AssistantMessage
    | ToolResultMessage
    | SystemMessage
    | CompactBoundaryMessage
)
