"""
HarnessHook Protocol — lifecycle hooks for observability and extensibility.

Hooks are fire-and-forget: the engine calls them without awaiting completion
serially. Errors are caught and logged — hooks cannot crash the loop or slow
it down (they run as background tasks).

Usage:
    class MyAuditHook:
        async def on_event(self, event: HookEvent, data: dict) -> None:
            if event == HookEvent.INTENT_CALL:
                await audit_log(data["intent_id"], data["model"], data["action"])

    engine = ChatEngine(..., hooks=[MyAuditHook()])
"""

from __future__ import annotations

import asyncio
import logging
from enum import Enum
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger("intent_api_harness")


class HookEvent(str, Enum):
    SESSION_START = "session_start"
    TURN_START = "turn_start"
    INTENT_CALL = "intent_call"
    INTENT_RESULT = "intent_result"
    COMPACT = "compact"
    SESSION_END = "session_end"
    ERROR = "error"


@runtime_checkable
class HarnessHook(Protocol):
    async def on_event(self, event: HookEvent, data: dict[str, Any]) -> None:
        """Called at each lifecycle point. Must not raise — errors are caught."""
        ...


async def fire_hooks(
    hooks: list[HarnessHook],
    event: HookEvent,
    data: dict[str, Any],
) -> None:
    """
    Fire all hooks for an event as background tasks (fire-and-forget).

    Each hook runs independently. A failure in one does not affect others
    and does not propagate to the caller.
    """
    if not hooks:
        return

    async def _call(hook: HarnessHook) -> None:
        try:
            await hook.on_event(event, data)
        except Exception as e:
            logger.warning(
                "Hook raised an exception",
                extra={
                    "hook": type(hook).__name__,
                    "event": event.value,
                    "error": str(e),
                },
            )

    # Run hooks concurrently as background tasks
    tasks = [asyncio.create_task(_call(h)) for h in hooks]
    # Gather with return_exceptions=True so one failure doesn't cancel others
    await asyncio.gather(*tasks, return_exceptions=True)
