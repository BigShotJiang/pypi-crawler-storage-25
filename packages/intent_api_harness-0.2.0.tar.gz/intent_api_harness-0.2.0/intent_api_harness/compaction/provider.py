"""CompactionProvider Protocol and result type."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field

from intent_api_harness.messages import CompactBoundaryMessage, UserMessage
from intent_api_harness.state import ToolSummary

if TYPE_CHECKING:
    from intent_api_harness.model_provider import ModelProvider


class CompactionResult(BaseModel):
    """Output of a compaction operation."""

    boundary: CompactBoundaryMessage
    summary_messages: list[UserMessage]
    pre_token_count: int = 0
    post_token_count: int = 0
    messages_summarized: int = 0


@runtime_checkable
class CompactionProvider(Protocol):
    async def compact(
        self,
        messages: list[Any],
        system_prompt: str,
        model_provider: "ModelProvider",
        tool_summaries: list[ToolSummary],
    ) -> CompactionResult:
        """Summarize messages and return a CompactionResult."""
        ...
