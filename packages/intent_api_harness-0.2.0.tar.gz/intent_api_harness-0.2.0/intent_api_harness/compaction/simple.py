"""
SimpleCompactionProvider — default compaction using the same model.

Calls ModelProvider.extract() with the adapted 7-section compact prompt
(derived from Claude Code's BASE_COMPACT_PROMPT, trimmed for the Intent API
context). Returns a CompactionResult with boundary + summary UserMessage.

Circuit breaker: the caller (query_loop) tracks consecutive_failures and
stops calling after MAX_CONSECUTIVE_COMPACT_FAILURES = 3.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from intent_api_harness.compaction.provider import CompactionProvider, CompactionResult
from intent_api_harness.messages import CompactBoundaryMessage, UserMessage
from intent_api_harness.model_provider import ModelProvider
from intent_api_harness.state import ToolSummary

logger = logging.getLogger("intent_api_harness")


class _CompactionSummary(BaseModel):
    """Structured output from the compaction LLM call."""

    primary_request: str
    key_concepts: list[str]
    actions_taken: list[str]
    errors_and_fixes: list[str]
    all_user_messages: list[str]
    pending_tasks: list[str]
    current_state: str


class SimpleCompactionProvider:
    """
    Default compaction provider.

    Uses the same ModelProvider as the main loop to summarize the
    conversation history into a structured summary injected as a
    UserMessage in the compacted context.
    """

    async def compact(
        self,
        messages: list[Any],
        system_prompt: str,
        model_provider: ModelProvider,
        tool_summaries: list[ToolSummary],
    ) -> CompactionResult:
        from intent_api_harness.prompts.compact import build_compact_prompt
        from intent_api_harness.prompts.constants import COMPACT_MAX_OUTPUT_TOKENS
        from intent_api_harness.utils.token_counter import estimate_token_count

        pre_token_count = estimate_token_count(messages)

        compact_messages = _format_messages_for_compact(messages)
        tool_summary_text = _format_tool_summaries(tool_summaries)
        compact_prompt = build_compact_prompt(tool_summary_text)

        summary: _CompactionSummary = await model_provider.extract(
            messages=compact_messages,
            response_model=_CompactionSummary,
            system_prompt=compact_prompt,
        )

        summary_text = _render_summary(summary)
        user_summary_msg = UserMessage(content=summary_text)

        boundary = CompactBoundaryMessage(
            pre_token_count=pre_token_count,
            messages_summarized=len(messages),
        )

        post_messages = [boundary, user_summary_msg]
        post_token_count = estimate_token_count(post_messages)
        boundary.post_token_count = post_token_count

        logger.info(
            "Compacted conversation",
            extra={
                "pre_tokens": pre_token_count,
                "post_tokens": post_token_count,
                "messages_summarized": len(messages),
            },
        )

        return CompactionResult(
            boundary=boundary,
            summary_messages=[user_summary_msg],
            pre_token_count=pre_token_count,
            post_token_count=post_token_count,
            messages_summarized=len(messages),
        )


# ── Helpers ───────────────────────────────────────────────────────────────────


def _format_messages_for_compact(messages: list[Any]) -> list[dict[str, Any]]:
    """Convert internal Message objects to LLM-format dicts for the summary call."""
    result = []
    for msg in messages:
        msg_type = getattr(msg, "type", None)
        if msg_type in ("compact_boundary", "system"):
            continue
        role = getattr(msg, "role", "user")
        if hasattr(role, "value"):
            role = role.value
        content = getattr(msg, "content", None)
        if content:
            result.append({"role": role, "content": str(content)})
    return result


def _format_tool_summaries(summaries: list[ToolSummary]) -> str:
    if not summaries:
        return "No tool calls were made."
    lines = []
    for s in summaries:
        label = s.display or s.intent_id or s.tool_name
        lines.append(f"  - {label} [{s.status}] (turn {s.turn})")
    return "\n".join(lines)


def _render_summary(summary: _CompactionSummary) -> str:
    """Render the structured summary as a user message."""
    sections = [
        "## Conversation Summary\n",
        f"**Primary Request:** {summary.primary_request}\n",
    ]
    if summary.key_concepts:
        sections.append("**Key Concepts:** " + ", ".join(summary.key_concepts) + "\n")
    if summary.actions_taken:
        sections.append("**Actions Taken:**\n" + "\n".join(f"- {a}" for a in summary.actions_taken) + "\n")
    if summary.errors_and_fixes:
        sections.append("**Errors & Fixes:**\n" + "\n".join(f"- {e}" for e in summary.errors_and_fixes) + "\n")
    if summary.all_user_messages:
        sections.append("**User Requests (verbatim):**\n" + "\n".join(f"- {m}" for m in summary.all_user_messages) + "\n")
    if summary.pending_tasks:
        sections.append("**Pending Tasks:**\n" + "\n".join(f"- {t}" for t in summary.pending_tasks) + "\n")
    sections.append(f"**Current State:** {summary.current_state}")
    return "\n".join(sections)
