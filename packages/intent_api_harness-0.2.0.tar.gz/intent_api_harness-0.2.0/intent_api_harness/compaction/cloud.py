"""
IntentAPICloudCompactionProvider and IntentAPICloudMemoryProvider.

Both call the Intent API Cloud backend via the machine-intent surface:
    POST https://api.intentapi.dev/api/machine-intent
    Authorization: Bearer {api_key}
    Body: IntentRequest JSON

Compaction:
    { model: "Harness", action: "custom", command: "compact", payload: {...} }

Memory load:
    { model: "Memory", action: "read", id: "{user_id}", payload: { team_id } }

Memory save:
    { model: "Memory", action: "update", id: "{user_id}", payload: { memory } }

The endpoint is hardwired to production but overridable for self-hosted
and testing scenarios.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from intent_api_harness.compaction.provider import CompactionProvider, CompactionResult
from intent_api_harness.memory.provider import Memory, MemoryProvider
from intent_api_harness.messages import CompactBoundaryMessage, UserMessage

logger = logging.getLogger("intent_api_harness")

_DEFAULT_CLOUD_ENDPOINT = "https://api.intentapi.dev"
_MACHINE_INTENT_PATH = "/api/machine-intent"
_REQUEST_TIMEOUT_SECONDS = 30.0


def _machine_intent_url(endpoint: str) -> str:
    return endpoint.rstrip("/") + _MACHINE_INTENT_PATH


# ── Cloud Compaction Provider ─────────────────────────────────────────────────


class IntentAPICloudCompactionProvider:
    """
    Compaction provider backed by Intent API Cloud.

    Sends the conversation to the cloud compaction service and receives
    an optimized structured summary. No local model call needed — the
    cloud handles summarization.

    Implements the same CompactionProvider Protocol as SimpleCompactionProvider.
    Drop-in replacement:

        compaction_provider = IntentAPICloudCompactionProvider(
            api_key=settings.INTENT_API_KEY,
        )

    Requires `pip install intent-api-harness` (httpx is a required dep).
    """

    def __init__(
        self,
        api_key: str,
        app_id: str | None = None,
        endpoint: str = _DEFAULT_CLOUD_ENDPOINT,
        timeout: float = _REQUEST_TIMEOUT_SECONDS,
    ) -> None:
        self.api_key = api_key
        self.app_id = app_id
        self.endpoint = endpoint
        self.timeout = timeout

    async def compact(
        self,
        messages: list[Any],
        system_prompt: str,
        model_provider: Any,
        tool_summaries: list[Any],
    ) -> CompactionResult:
        """
        Send conversation to Intent API Cloud for compaction.

        The cloud service runs the 7-section compact prompt and returns
        a structured summary.
        """
        from intent_api_harness.utils.token_counter import estimate_token_count

        pre_token_count = estimate_token_count(messages)

        # Serialize messages for the cloud payload
        serialized_messages = _serialize_messages(messages)
        serialized_tools = [
            {
                "tool_name": ts.tool_name,
                "intent_id": ts.intent_id,
                "display": ts.display,
                "status": ts.status,
                "turn": ts.turn,
            }
            for ts in (tool_summaries or [])
        ]

        payload = {
            "messages": serialized_messages,
            "system_prompt": system_prompt,
            "tool_summaries": serialized_tools,
            **({"app_id": self.app_id} if self.app_id else {}),
        }

        intent_request = {
            "model": "Harness",
            "action": "custom",
            "command": "compact",
            "payload": payload,
        }

        response_data = await _post_machine_intent(
            url=_machine_intent_url(self.endpoint),
            api_key=self.api_key,
            body=intent_request,
            timeout=self.timeout,
        )

        summary_text = response_data.get("summary", "")
        post_token_count = len(summary_text) // 4

        boundary = CompactBoundaryMessage(
            pre_token_count=pre_token_count,
            post_token_count=post_token_count,
            messages_summarized=len(messages),
        )
        summary_msg = UserMessage(content=summary_text)

        return CompactionResult(
            boundary=boundary,
            summary_messages=[summary_msg],
            pre_token_count=pre_token_count,
            post_token_count=post_token_count,
            messages_summarized=len(messages),
        )


# ── Cloud Memory Provider ─────────────────────────────────────────────────────


class IntentAPICloudMemoryProvider:
    """
    Memory provider backed by Intent API Cloud.

    Persists memory across server restarts, deployments, and horizontal scaling.
    Multi-tenant: keyed by (user_id, team_id, app_id).

    Drop-in replacement for SimpleMemoryProvider:

        memory_provider = IntentAPICloudMemoryProvider(
            api_key=settings.INTENT_API_KEY,
            app_id="my-saas-app",
        )

    Implements the MemoryProvider Protocol.
    """

    def __init__(
        self,
        api_key: str,
        app_id: str,
        endpoint: str = _DEFAULT_CLOUD_ENDPOINT,
        timeout: float = _REQUEST_TIMEOUT_SECONDS,
    ) -> None:
        self.api_key = api_key
        self.app_id = app_id
        self.endpoint = endpoint
        self.timeout = timeout

    async def load(self, user_id: str, team_id: str | None = None) -> Memory | None:
        """Load memory for a user/team from Intent API Cloud."""
        try:
            response_data = await _post_machine_intent(
                url=_machine_intent_url(self.endpoint),
                api_key=self.api_key,
                body={
                    "model": "Memory",
                    "action": "read",
                    "id": user_id,
                    "payload": {
                        "team_id": team_id,
                        "app_id": self.app_id,
                    },
                },
                timeout=self.timeout,
            )

            if not response_data:
                return None

            return Memory(
                user_id=user_id,
                team_id=team_id,
                summary=response_data.get("summary"),
                key_facts=response_data.get("key_facts", []),
                session_count=response_data.get("session_count", 0),
            )

        except _CloudNotFoundError:
            return None
        except Exception as e:
            logger.warning(
                "Cloud memory load failed",
                extra={"user_id": user_id, "error": str(e)},
            )
            return None

    async def save(self, memory: Memory) -> None:
        """Save memory for a user/team to Intent API Cloud."""
        from datetime import timezone

        try:
            await _post_machine_intent(
                url=_machine_intent_url(self.endpoint),
                api_key=self.api_key,
                body={
                    "model": "Memory",
                    "action": "update",
                    "id": memory.user_id,
                    "payload": {
                        "team_id": memory.team_id,
                        "app_id": self.app_id,
                        "summary": memory.summary,
                        "key_facts": memory.key_facts,
                        "session_count": memory.session_count,
                        "last_updated": memory.last_updated.isoformat() if memory.last_updated else None,
                    },
                },
                timeout=self.timeout,
            )
        except Exception as e:
            logger.warning(
                "Cloud memory save failed",
                extra={"user_id": memory.user_id, "error": str(e)},
            )
            raise


# ── Internal helpers ──────────────────────────────────────────────────────────


class _CloudNotFoundError(Exception):
    """Raised when the cloud API returns 404 (no data for this key)."""


async def _post_machine_intent(
    url: str,
    api_key: str,
    body: dict[str, Any],
    timeout: float,
) -> dict[str, Any]:
    """
    POST an IntentRequest to the machine-intent surface.

    Raises:
        _CloudNotFoundError: on 404
        httpx.HTTPStatusError: on other 4xx/5xx
        httpx.RequestError: on network failure
    """
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(
            url,
            json=body,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

        if response.status_code == 404:
            raise _CloudNotFoundError(f"Not found: {url}")

        response.raise_for_status()
        return response.json()


def _serialize_messages(messages: list[Any]) -> list[dict[str, Any]]:
    """Convert internal Message objects to serializable dicts."""
    result = []
    for msg in messages:
        msg_type = getattr(msg, "type", None)
        if msg_type in ("compact_boundary",):
            continue
        try:
            result.append(msg.model_dump(mode="json"))
        except Exception:
            pass
    return result
