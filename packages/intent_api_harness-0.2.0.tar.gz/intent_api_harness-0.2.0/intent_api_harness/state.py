"""
Loop state — carried across query_loop iterations.

Uses Pydantic models throughout (no dataclasses per WBS B3).
The state object is destructured at the top of each iteration and
written fresh at continue sites — same pattern as the TypeScript harness.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from intent_api_harness.messages import Message


class HarnessMode(str, Enum):
    """Operating mode of the agent loop."""
    EXECUTE = "execute"
    PLAN = "plan"


class CompactTracking(BaseModel):
    """Tracks compaction attempts across loop iterations."""

    consecutive_failures: int = 0
    last_compact_token_count: int | None = None
    last_compact_turn: int | None = None


class ToolSummary(BaseModel):
    """Summary of a single tool call — used by compaction to describe recent actions."""

    tool_name: str
    intent_id: str | None = None
    display: str | None = None
    status: str
    turn: int


class LoopState(BaseModel):
    """
    Mutable loop state carried across query_loop iterations.

    Created once per submit_message() call from engine's persisted fields,
    then synced back to the engine after the loop completes.

    Mode fields (mode, pre_plan_mode, needs_plan_attachment) are persisted
    on ChatEngine as _mode / _pre_plan_mode / _needs_plan_attachment and
    passed in here for the duration of each loop call.
    """

    model_config = {"arbitrary_types_allowed": True}

    messages: list[Any] = Field(default_factory=list)  # list[Message], typed loosely for forward ref
    turn_count: int = 0
    token_count: int = 0
    compact_tracking: CompactTracking = Field(default_factory=CompactTracking)
    pending_tool_summaries: list[ToolSummary] = Field(default_factory=list)
    last_transition: str | None = None

    # Mode — persisted on engine, copied here for loop-local access.
    # Tools and the loop check engine._mode directly (authoritative);
    # state.mode is for loop-internal use only.
    mode: HarnessMode = HarnessMode.EXECUTE
    pre_plan_mode: HarnessMode | None = None
    # Controls plan mode attachment injection. Set True on mode entry and
    # after each compaction (so mode reminder survives context replacement).
    needs_plan_attachment: bool = False
