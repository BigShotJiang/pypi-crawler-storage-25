"""
ModelProvider Protocol — the model abstraction layer.

One interface. One string changes the model. No per-provider implementations.
LiteLLM handles translation to Anthropic, OpenAI, Azure, Bedrock, etc.
"""

from __future__ import annotations

from typing import Any, AsyncGenerator, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel, Field

from intent_api_harness.messages import ToolCall
from intent_api_harness.events import TokenUsage

T = TypeVar("T", bound=BaseModel)


# ── Response types ────────────────────────────────────────────────────────────


class ModelResponse(BaseModel):
    """Complete (non-streaming) model response."""

    content: str | None = None
    tool_calls: list[ToolCall] | None = None
    thinking: str | None = None
    stop_reason: str | None = None
    usage: TokenUsage = Field(default_factory=TokenUsage)


class StreamChunk(BaseModel):
    """
    A single chunk from a streaming model response.

    type values:
      - "text"           — incremental text content
      - "thinking"       — incremental extended thinking content
      - "tool_call_start" — tool call beginning (id + name available, input empty)
      - "tool_call_delta" — incremental input JSON fragment
      - "tool_call_end"  — tool call complete (full ToolCall in tool_call field)
      - "usage"          — token usage update (typically final chunk)
    """

    type: str
    text: str | None = None
    tool_call: ToolCall | None = None     # populated on tool_call_end
    tool_call_id: str | None = None       # populated on tool_call_start / tool_call_delta
    tool_call_name: str | None = None     # populated on tool_call_start
    input_fragment: str | None = None     # populated on tool_call_delta (raw JSON fragment)
    usage: TokenUsage | None = None


# ── Protocol ──────────────────────────────────────────────────────────────────


@runtime_checkable
class ModelProvider(Protocol):
    """
    Protocol for model backends.

    Implement this to support any LLM provider. The default implementation
    is LiteLLMProvider, which supports all major providers via a model string.
    """

    async def complete(
        self,
        messages: list[dict[str, Any]],
        system_prompt: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelResponse:
        """Single-shot completion. Returns the full response at once."""
        ...

    async def stream(
        self,
        messages: list[dict[str, Any]],
        system_prompt: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
    ) -> AsyncGenerator[StreamChunk, None]:
        """Streaming completion. Yields StreamChunks as they arrive."""
        ...
    async def extract(
        self,
        messages: list[dict[str, Any]],
        response_model: type[T],
        system_prompt: str | None = None,
    ) -> T:
        """
        Structured extraction via Instructor.
        Returns a validated Pydantic model of the given type.
        Used for compaction summaries and memory updates.
        """
        ...
