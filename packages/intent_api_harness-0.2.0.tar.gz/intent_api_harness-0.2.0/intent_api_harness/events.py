"""
SSE event types emitted by the harness to the frontend.

All events use `type` as the discriminated union discriminator.
Events serialize to SSE `data: {json}\n\n` lines.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field

from intent_api_harness.messages import ExecutionResult


# ── Shared sub-models ─────────────────────────────────────────────────────────


class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    total_tokens: int = 0


class IntentSummary(BaseModel):
    """Compact description of the intent being executed — shown in the action log."""

    model: str
    action: str
    id: Any | None = None
    command: str | None = None


# ── Base event ────────────────────────────────────────────────────────────────


class BaseEvent(BaseModel):
    session_id: str
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=timezone.utc))


# ── Event variants ────────────────────────────────────────────────────────────


class SessionStartEvent(BaseEvent):
    type: Literal["session.start"] = "session.start"
    model: str
    tools: list[str]


class ThinkingDeltaEvent(BaseEvent):
    type: Literal["thinking.delta"] = "thinking.delta"
    text: str


class TextDeltaEvent(BaseEvent):
    type: Literal["text.delta"] = "text.delta"
    text: str


class ToolStartEvent(BaseEvent):
    type: Literal["tool.start"] = "tool.start"
    tool_call_id: str
    tool_name: str
    input: dict[str, Any] = Field(default_factory=dict)
    display: str | None = None
    intent: IntentSummary | None = None


class ToolResultEvent(BaseEvent):
    type: Literal["tool.result"] = "tool.result"
    tool_call_id: str
    result: ExecutionResult


class CompactEvent(BaseEvent):
    type: Literal["compact"] = "compact"
    pre_token_count: int
    post_token_count: int
    messages_summarized: int


class ErrorEvent(BaseEvent):
    type: Literal["error"] = "error"
    error_type: str
    message: str
    recoverable: bool = False


class ModeChangeEvent(BaseEvent):
    type: Literal["mode.change"] = "mode.change"
    mode: str
    previous_mode: str | None = None


class SessionEndEvent(BaseEvent):
    type: Literal["session.end"] = "session.end"
    reason: Literal["success", "max_turns", "max_budget", "abort", "error"]
    turn_count: int
    total_cost_usd: float | None = None
    usage: TokenUsage | None = None


# ── Discriminated union ───────────────────────────────────────────────────────

HarnessEvent = (
    SessionStartEvent
    | ThinkingDeltaEvent
    | TextDeltaEvent
    | ToolStartEvent
    | ToolResultEvent
    | CompactEvent
    | ErrorEvent
    | ModeChangeEvent
    | SessionEndEvent
)
