"""
ChatService — Intent API service that exposes the agent loop via SSE.

Register like any other IntentService. Returns a StreamingResponse.
Three lines of developer integration:

    model_provider = LiteLLMProvider(model="anthropic/claude-sonnet-4-20250514")
    chat_service = ChatService(model_provider=model_provider)
    router.register("Chat", chat_service)

Then POST /api/intent { "model": "Chat", "action": "custom", "command": "stream",
                        "payload": { "message": "..." } }
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from starlette.responses import StreamingResponse

from intent_api import IntentService, custom_action
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.model_provider import ModelProvider

logger = logging.getLogger("intent_api_harness")

# Session store constants
_DEFAULT_SESSION_TTL_SECONDS = 3600
_DEFAULT_MAX_SESSIONS = 1000


class ChatService(IntentService):
    """
    IntentService subclass that adds AI chat to any Intent API application.

    Manages a session store ({session_id: (ChatEngine, last_active)}) with
    TTL eviction and a max-sessions cap.

    The `db` session is NOT stored in the ChatEngine — it is passed fresh
    on each call, since HTTP database connections don't persist across requests.
    """

    def __init__(
        self,
        model_provider: ModelProvider,
        config: ChatEngineConfig | None = None,
        compaction_provider: Any = None,
        memory_provider: Any = None,
        session_ttl_seconds: int = _DEFAULT_SESSION_TTL_SECONDS,
        max_sessions: int = _DEFAULT_MAX_SESSIONS,
    ) -> None:
        self.model_provider = model_provider
        self.config = config or ChatEngineConfig()
        self.compaction_provider = compaction_provider
        self.memory_provider = memory_provider
        self.session_ttl_seconds = session_ttl_seconds
        self.max_sessions = max_sessions

        # {session_id: (ChatEngine, last_active_utc)}
        self._sessions: dict[str, tuple[ChatEngine, datetime]] = {}
        self._session_lock = asyncio.Lock()

    # ── Session store ──────────────────────────────────────────────────────

    async def _get_or_create_engine(
        self,
        session_id: str | None,
        user: Any,
        intent_context: Any,
        runtime: Any = None,
    ) -> ChatEngine:
        """
        Look up an existing engine by session_id or create a new one.
        Evicts expired sessions and enforces the cap on each call.
        """
        async with self._session_lock:
            self._evict_expired()

            if session_id and session_id in self._sessions:
                engine, _ = self._sessions[session_id]
                self._sessions[session_id] = (engine, _utcnow())
                return engine

            # Enforce max sessions cap — evict oldest if at limit
            if len(self._sessions) >= self.max_sessions:
                oldest_id = min(
                    self._sessions,
                    key=lambda sid: self._sessions[sid][1],
                )
                del self._sessions[oldest_id]
                logger.warning(
                    "Max sessions reached, evicted oldest",
                    extra={"evicted_session_id": oldest_id},
                )

            engine = ChatEngine(
                config=self.config,
                user=user,
                intent_context=intent_context,
                registry=self._registry,
                model_provider=self.model_provider,
                compaction_provider=self.compaction_provider,
                memory_provider=self.memory_provider,
                runtime=runtime,
            )
            self._sessions[engine.session_id] = (engine, _utcnow())
            return engine

    def _evict_expired(self) -> None:
        """Remove sessions that have exceeded the TTL. Call inside _session_lock."""
        now = _utcnow()
        expired = [
            sid
            for sid, (_, last_active) in self._sessions.items()
            if (now - last_active).total_seconds() > self.session_ttl_seconds
        ]
        for sid in expired:
            del self._sessions[sid]
        if expired:
            logger.debug("Evicted expired sessions", extra={"count": len(expired)})

    # ── Custom action ──────────────────────────────────────────────────────

    @custom_action(display="Chat", description="Stream an AI conversation turn")
    async def stream(self, *, db: Any, user: Any, context: Any, id: Any, payload: Any) -> StreamingResponse:
        """
        Handle a chat message. Returns a StreamingResponse (SSE).

        Payload:
            message (str): The user's message text.
            session_id (str, optional): Resume an existing session.
        """
        if payload is None:
            payload = {}

        message = payload.get("message", "")
        session_id = payload.get("session_id")

        if not message:
            from fastapi import HTTPException
            raise HTTPException(status_code=400, detail="Missing 'message' in payload.")

        # Retrieve runtime from registry's router if available
        runtime = getattr(self, "_runtime", None)

        engine = await self._get_or_create_engine(
            session_id=session_id,
            user=user,
            intent_context=context,
            runtime=runtime,
        )

        async def event_stream():
            try:
                async for event in engine.submit_message(content=message, db=db):
                    yield f"data: {event.model_dump_json()}\n\n"
            except Exception as e:
                logger.error("Error in chat stream", extra={"error": str(e)})
                from intent_api_harness.events import ErrorEvent
                error_event = ErrorEvent(
                    session_id=engine.session_id,
                    error_type=type(e).__name__,
                    message=str(e)[:500],
                    recoverable=False,
                )
                yield f"data: {error_event.model_dump_json()}\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Session-ID": engine.session_id,
                "X-Accel-Buffering": "no",
            },
        )

    # ── Metadata ───────────────────────────────────────────────────────────

    @property
    def active_session_count(self) -> int:
        """Number of currently active (non-expired) sessions."""
        return len(self._sessions)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)
