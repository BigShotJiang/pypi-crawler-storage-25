"""
SimpleMemoryProvider — in-process memory store.

Suitable for dev/testing and single-server deployments.
Process restart clears all memory (by design).
Thread-safe via asyncio.Lock.

Production replacement: IntentAPICloudMemoryProvider (Phase 3).
"""

from __future__ import annotations

import asyncio

from intent_api_harness.memory.provider import Memory


class SimpleMemoryProvider:
    """
    In-process memory dict keyed by (user_id, team_id).

    DEV/TESTING ONLY: memory is not shared across processes or
    server restarts. For production multi-server deployments, use
    IntentAPICloudMemoryProvider.
    """

    def __init__(self) -> None:
        self._store: dict[tuple[str, str | None], Memory] = {}
        self._lock = asyncio.Lock()

    async def load(self, user_id: str, team_id: str | None = None) -> Memory | None:
        async with self._lock:
            return self._store.get((user_id, team_id))

    async def save(self, memory: Memory) -> None:
        async with self._lock:
            self._store[(memory.user_id, memory.team_id)] = memory
