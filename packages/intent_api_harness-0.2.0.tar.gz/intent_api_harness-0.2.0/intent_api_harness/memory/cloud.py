"""Cloud memory provider — re-exported from compaction/cloud.py for cleaner imports."""

from intent_api_harness.compaction.cloud import IntentAPICloudMemoryProvider

__all__ = ["IntentAPICloudMemoryProvider"]
