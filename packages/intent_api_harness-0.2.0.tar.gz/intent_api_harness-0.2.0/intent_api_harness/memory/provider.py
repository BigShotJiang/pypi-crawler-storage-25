"""MemoryProvider Protocol and Memory model."""

from __future__ import annotations

from datetime import datetime
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, Field


class Memory(BaseModel):
    """Per-user/team memory that persists across sessions."""

    user_id: str
    team_id: str | None = None
    summary: str | None = None
    key_facts: list[str] = Field(default_factory=list)
    last_updated: datetime | None = None
    session_count: int = 0


@runtime_checkable
class MemoryProvider(Protocol):
    async def load(self, user_id: str, team_id: str | None = None) -> Memory | None:
        """Load memory for a user/team. Returns None if no memory exists yet."""
        ...

    async def save(self, memory: Memory) -> None:
        """Persist memory for a user/team."""
        ...
