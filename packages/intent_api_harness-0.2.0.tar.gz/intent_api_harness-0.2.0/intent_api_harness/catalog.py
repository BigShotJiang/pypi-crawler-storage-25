"""
Intent catalog — generated from the ServiceRegistry at startup.

The catalog is the searchable index of all available intents. It's used by:
  - ToolSearchTool (model discovers available intents)
  - System prompt builder (catalog summary injected into system prompt)
  - ChatEngine (auto-builds on construction)
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel


class CatalogEntry(BaseModel):
    """A single discoverable intent in the catalog."""

    model: str
    action: str
    command: str | None = None
    description: str | None = None
    display: str | None = None
    type: Literal["read", "write"]
    payload_schema: dict[str, Any] | None = None


class IntentCatalog:
    """
    Searchable index of all chat-visible intents.

    Built once from ServiceRegistry at ChatEngine construction time.
    Supports fuzzy (case-insensitive substring) search across model,
    action, command, and description fields.
    """

    def __init__(self, entries: list[CatalogEntry]) -> None:
        self.entries = entries

    @classmethod
    def from_registry(cls, registry: Any) -> "IntentCatalog":
        """
        Build a catalog from a ServiceRegistry instance.

        Iterates chat-exposed services (expose_chat=True), enumerates their
        CRUD actions and @custom_action commands, and produces one CatalogEntry
        per available intent.
        """
        from intent_api.service import IntentService

        _READ_ACTIONS = {"read", "list"}
        _CRUD_ACTIONS = ("create", "read", "update", "delete", "list")

        entries: list[CatalogEntry] = []

        for model_name in registry.chat_models:
            service = registry.get(model_name)
            if not service:
                continue

            display_prefix = (
                getattr(service.__class__, "__display_prefix__", None) or model_name
            )

            # CRUD / list actions — only add if the service actually overrides them
            for action in _CRUD_ACTIONS:
                method = getattr(service.__class__, action, None)
                base_method = getattr(IntentService, action, None)
                if method is None or method is base_method:
                    continue

                display = _crud_display(action, display_prefix)
                entries.append(
                    CatalogEntry(
                        model=model_name,
                        action=action,
                        display=display,
                        type="read" if action in _READ_ACTIONS else "write",
                    )
                )

            # @custom_action commands
            registered = getattr(service.__class__, "_registered_commands", {}) or {}
            for command_name, info in registered.items():
                cmd_display = info.get("display") or f"{command_name.replace('_', ' ').title()} {display_prefix}"
                entries.append(
                    CatalogEntry(
                        model=model_name,
                        action="custom",
                        command=command_name,
                        description=info.get("description"),
                        display=cmd_display,
                        type="write",
                        payload_schema=_simplified_schema(info.get("schema")),
                    )
                )

        return cls(entries)

    def search(
        self,
        query: str | None = None,
        model: str | None = None,
        action: str | None = None,
    ) -> list[CatalogEntry]:
        """
        Fuzzy search across catalog entries.

        All filters are case-insensitive substring matches.
        Multiple filters are ANDed.
        """
        results = self.entries

        if model:
            needle = model.lower()
            results = [e for e in results if needle in e.model.lower()]

        if action:
            needle = action.lower()
            results = [e for e in results if needle in e.action.lower()]

        if query:
            needle = query.lower()
            results = [
                e for e in results
                if needle in e.model.lower()
                or needle in e.action.lower()
                or (e.command and needle in e.command.lower())
                or (e.description and needle in e.description.lower())
                or (e.display and needle in e.display.lower())
            ]

        return results

    def to_compact_text(self, max_entries: int = 50) -> str:
        """
        Compact text representation for injection into the system prompt.

        Each entry renders as one line: "Model.action[/command] — description"
        """
        lines: list[str] = []
        for entry in self.entries[:max_entries]:
            key = f"{entry.model}.{entry.action}"
            if entry.command:
                key += f"/{entry.command}"
            desc = entry.description or entry.display or ""
            lines.append(f"  {key}" + (f" — {desc}" if desc else ""))
        if len(self.entries) > max_entries:
            lines.append(f"  ... and {len(self.entries) - max_entries} more (use ToolSearchTool to discover)")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self.entries)


# ── Helpers ───────────────────────────────────────────────────────────────────

_CRUD_DISPLAY_TEMPLATES = {
    "create": "Creating {prefix}",
    "read": "Loading {prefix}",
    "update": "Updating {prefix}",
    "delete": "Deleting {prefix}",
    "list": "Loading {prefix} list",
}


def _crud_display(action: str, prefix: str) -> str:
    template = _CRUD_DISPLAY_TEMPLATES.get(action, "{prefix}")
    return template.format(prefix=prefix)


def _simplified_schema(schema_model: Any) -> dict[str, Any] | None:
    """
    Produce a simplified field→type mapping from a Pydantic model.

    Returns None if schema is None or not a Pydantic model class.
    """
    if schema_model is None:
        return None
    try:
        fields = schema_model.model_fields
        return {name: str(info.annotation) for name, info in fields.items()}
    except AttributeError:
        return None
