"""
Compaction prompt — adapted from Claude Code's BASE_COMPACT_PROMPT.

The 7-section structure (trimmed from 9 for the Intent API context) has been
tuned over time in the TypeScript harness. Copy verbatim as advised in the WBS.
"""

from __future__ import annotations


_COMPACT_BASE = """\
You are summarizing a conversation between a user and an AI assistant.
The assistant has been executing real actions in a business application using typed intents.

Your task: produce a structured summary that preserves everything the next AI instance
needs to continue the conversation seamlessly.

Respond with a JSON object matching the provided schema. DO NOT call any tools.

The summary MUST include:

1. PRIMARY REQUEST AND INTENT
   What is the user fundamentally trying to accomplish? Be specific.

2. KEY CONCEPTS
   Domain terms, resource names, entity IDs, and technical details mentioned.

3. ACTIONS TAKEN
   Which intents were called (e.g. "Brand.list", "BlogPost.generate"),
   what the results were, and any errors encountered.

4. ERRORS AND FIXES
   What failed, why, and how it was resolved (if at all).

5. ALL USER MESSAGES
   Preserve EXACT quotes of every user message. This is critical.

6. PENDING TASKS
   Anything the assistant committed to but hasn't finished yet.

7. CURRENT STATE
   What was the last thing happening? Where are we in the task?
"""


def build_compact_prompt(tool_summary_text: str) -> str:
    """Build the full compaction system prompt, optionally including a tool summary."""
    if tool_summary_text and tool_summary_text != "No tool calls were made.":
        return f"{_COMPACT_BASE}\n\nRecent actions log:\n{tool_summary_text}"
    return _COMPACT_BASE
