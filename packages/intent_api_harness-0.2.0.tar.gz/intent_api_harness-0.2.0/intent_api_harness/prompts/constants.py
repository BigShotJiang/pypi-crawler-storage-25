"""
Prompt constants — buffer sizes and limits adapted from Claude Code.

These values are empirically tuned in the TypeScript harness and are
preserved here without modification (see WBS: "verify before reimplementing").
"""

AUTOCOMPACT_BUFFER_TOKENS: int = 13_000
WARNING_THRESHOLD_BUFFER_TOKENS: int = 20_000
COMPACT_MAX_OUTPUT_TOKENS: int = 20_000
CHARS_PER_TOKEN_ESTIMATE: int = 4
MAX_CONSECUTIVE_COMPACT_FAILURES: int = 3

# Default context window when not specified in ChatEngineConfig
MODEL_CONTEXT_WINDOW_DEFAULT: int = 200_000
