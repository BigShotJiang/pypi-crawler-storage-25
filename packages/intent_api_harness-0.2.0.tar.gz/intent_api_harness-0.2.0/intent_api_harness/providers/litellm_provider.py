"""
LiteLLMProvider — the default ModelProvider implementation.

Uses LiteLLM's unified acompletion() for tool calling and streaming.
One string changes the model:
  LiteLLMProvider(model="anthropic/claude-sonnet-4-20250514")
  LiteLLMProvider(model="openai/gpt-4o")
  LiteLLMProvider(model="azure/gpt-4o-deployment")

Instructor is used on top of LiteLLM for structured extraction
(compaction summaries, memory updates).

LiteLLM returns per-call usage (not cumulative like the raw Anthropic SDK),
so we sum across calls rather than merge with max-non-zero.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator, TypeVar

import instructor
import litellm
from pydantic import BaseModel

from intent_api_harness.events import TokenUsage
from intent_api_harness.messages import ToolCall
from intent_api_harness.model_provider import ModelResponse, StreamChunk

logger = logging.getLogger("intent_api_harness")

T = TypeVar("T", bound=BaseModel)

# Suppress litellm's verbose logging by default — it logs every API call at INFO.
litellm.suppress_debug_info = True


class LiteLLMProvider:
    """
    ModelProvider backed by LiteLLM.

    Args:
        model: LiteLLM model string, e.g. "anthropic/claude-sonnet-4-20250514".
            See https://docs.litellm.ai/docs/providers for the full list.
        api_key: Optional API key override. When None, LiteLLM reads from
            environment variables (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.).
        max_output_tokens: Default maximum tokens for model responses.
        temperature: Sampling temperature. Defaults to 0 for determinism.
    """

    def __init__(
        self,
        model: str = "anthropic/claude-sonnet-4-20250514",
        api_key: str | None = None,
        max_output_tokens: int = 16_000,
        temperature: float = 0.0,
    ) -> None:
        self.model = model
        self.api_key = api_key
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature

        # Instructor client — patched over litellm for structured extraction.
        self._instructor_client = instructor.from_litellm(litellm.acompletion)

    def _base_kwargs(self, max_output_tokens: int | None = None) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": max_output_tokens or self.max_output_tokens,
        }
        if self.api_key:
            kwargs["api_key"] = self.api_key
        return kwargs

    @staticmethod
    def _build_messages(
        messages: list[dict[str, Any]],
        system_prompt: str | None,
    ) -> list[dict[str, Any]]:
        """Prepend system prompt as the first system message if provided."""
        if not system_prompt:
            return messages
        return [{"role": "system", "content": system_prompt}, *messages]

    @staticmethod
    def _extract_usage(response: Any) -> TokenUsage:
        """Pull token counts from a LiteLLM response object."""
        usage = getattr(response, "usage", None)
        if not usage:
            return TokenUsage()
        return TokenUsage(
            input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            output_tokens=getattr(usage, "completion_tokens", 0) or 0,
            cache_read_tokens=getattr(usage, "prompt_tokens_details", None)
            and getattr(usage.prompt_tokens_details, "cached_tokens", 0) or 0,
            cache_write_tokens=0,
            total_tokens=getattr(usage, "total_tokens", 0) or 0,
        )

    @staticmethod
    def _parse_tool_calls(response: Any) -> list[ToolCall] | None:
        """Extract tool calls from a LiteLLM response message."""
        choice = response.choices[0] if response.choices else None
        if not choice:
            return None
        message = getattr(choice, "message", None)
        if not message:
            return None
        raw_calls = getattr(message, "tool_calls", None)
        if not raw_calls:
            return None
        result = []
        for tc in raw_calls:
            fn = getattr(tc, "function", None)
            if not fn:
                continue
            try:
                args = json.loads(fn.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            result.append(ToolCall(id=tc.id, tool_name=fn.name, input=args))
        return result or None

    # ── Public API ─────────────────────────────────────────────────────────

    async def complete(
        self,
        messages: list[dict[str, Any]],
        system_prompt: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
    ) -> ModelResponse:
        kwargs = self._base_kwargs(max_output_tokens)
        kwargs["messages"] = self._build_messages(messages, system_prompt)
        if tools:
            kwargs["tools"] = tools

        response = await litellm.acompletion(**kwargs)

        choice = response.choices[0] if response.choices else None
        content = None
        if choice:
            msg = getattr(choice, "message", None)
            content = getattr(msg, "content", None) if msg else None

        return ModelResponse(
            content=content,
            tool_calls=self._parse_tool_calls(response),
            stop_reason=getattr(choice, "finish_reason", None) if choice else None,
            usage=self._extract_usage(response),
        )

    async def stream(
        self,
        messages: list[dict[str, Any]],
        system_prompt: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        max_output_tokens: int | None = None,
    ) -> AsyncGenerator[StreamChunk, None]:
        kwargs = self._base_kwargs(max_output_tokens)
        kwargs["messages"] = self._build_messages(messages, system_prompt)
        kwargs["stream"] = True
        if tools:
            kwargs["tools"] = tools

        # Accumulate tool call inputs across deltas before yielding tool_call_end.
        tool_call_accumulators: dict[int, dict[str, Any]] = {}

        async for chunk in await litellm.acompletion(**kwargs):
            choice = chunk.choices[0] if chunk.choices else None
            if not choice:
                continue

            delta = getattr(choice, "delta", None)
            if not delta:
                continue

            # Text delta
            text = getattr(delta, "content", None)
            if text:
                yield StreamChunk(type="text", text=text)

            # Tool call deltas
            raw_tcs = getattr(delta, "tool_calls", None)
            if raw_tcs:
                for tc_delta in raw_tcs:
                    idx = tc_delta.index if hasattr(tc_delta, "index") else 0
                    fn = getattr(tc_delta, "function", None)

                    if idx not in tool_call_accumulators:
                        tool_call_accumulators[idx] = {
                            "id": getattr(tc_delta, "id", "") or "",
                            "name": getattr(fn, "name", "") or "" if fn else "",
                            "input_fragments": [],
                        }
                        yield StreamChunk(
                            type="tool_call_start",
                            tool_call_id=tool_call_accumulators[idx]["id"],
                            tool_call_name=tool_call_accumulators[idx]["name"],
                        )

                    fragment = getattr(fn, "arguments", None) if fn else None
                    if fragment:
                        tool_call_accumulators[idx]["input_fragments"].append(fragment)
                        yield StreamChunk(
                            type="tool_call_delta",
                            tool_call_id=tool_call_accumulators[idx]["id"],
                            input_fragment=fragment,
                        )

            # Usage (typically in the final chunk)
            usage_obj = getattr(chunk, "usage", None)
            if usage_obj and getattr(usage_obj, "total_tokens", 0):
                usage = TokenUsage(
                    input_tokens=getattr(usage_obj, "prompt_tokens", 0) or 0,
                    output_tokens=getattr(usage_obj, "completion_tokens", 0) or 0,
                    total_tokens=getattr(usage_obj, "total_tokens", 0) or 0,
                )
                yield StreamChunk(type="usage", usage=usage)

        # Yield complete tool calls after stream ends
        for idx, acc in sorted(tool_call_accumulators.items()):
            raw_input = "".join(acc["input_fragments"])
            try:
                parsed_input = json.loads(raw_input) if raw_input else {}
            except json.JSONDecodeError:
                parsed_input = {}
            yield StreamChunk(
                type="tool_call_end",
                tool_call=ToolCall(
                    id=acc["id"],
                    tool_name=acc["name"],
                    input=parsed_input,
                ),
            )

    async def extract(
        self,
        messages: list[dict[str, Any]],
        response_model: type[T],
        system_prompt: str | None = None,
    ) -> T:
        """
        Structured extraction via Instructor on top of LiteLLM.

        Returns a validated instance of response_model.
        Used for compaction summaries and memory updates — not for the main loop.
        """
        kwargs: dict[str, Any] = {
            "model": self.model,
            "temperature": self.temperature,
            "messages": self._build_messages(messages, system_prompt),
            "response_model": response_model,
        }
        if self.api_key:
            kwargs["api_key"] = self.api_key

        return await self._instructor_client(**kwargs)
