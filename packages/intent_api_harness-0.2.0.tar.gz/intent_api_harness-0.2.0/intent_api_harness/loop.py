"""
query_loop — the core agent loop.

while True with explicit return for termination — not while(has_tool_call).
State object pattern: destructure at top of each iteration, update in place.
Yields HarnessEvents that ChatEngine translates to SSE.
"""

from __future__ import annotations

import asyncio
import logging
from enum import Enum
from typing import TYPE_CHECKING, Any, AsyncGenerator

from intent_api_harness.events import (
    CompactEvent,
    ModeChangeEvent,
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolResultEvent,
    ToolStartEvent,
    IntentSummary,
)
from intent_api_harness.messages import (
    AssistantMessage,
    ExecutionResult,
    SystemMessage,
    ToolCall,
    ToolResultMessage,
)
from intent_api_harness.model_provider import StreamChunk
from intent_api_harness.state import HarnessMode, LoopState, ToolSummary
from intent_api_harness.tools.base import find_tool

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine

logger = logging.getLogger("intent_api_harness")

# ── Plan mode attachment ───────────────────────────────────────────────────────
# Adapted from messages.ts plan_mode attachment. Vocabulary adaptations only.

_PLAN_MODE_ATTACHMENT = (
    "Plan mode is active. The user indicated that they do not want you to execute yet — "
    "you MUST NOT execute any write actions (create, update, delete, or custom commands "
    "that modify data), or otherwise make any changes to the system. "
    "This supercedes any other instructions you have received.\n\n"
    "You are only allowed to take READ-ONLY actions (read, list) and use Think, "
    "TodoWrite, and ToolSearchTool to explore and plan.\n\n"
    "You should build your plan incrementally by using TodoWrite to outline tasks. "
    "When your plan is complete, use ExitPlanMode to present it for approval."
)


class TerminalReason(str, Enum):
    SUCCESS = "success"
    MAX_TURNS = "max_turns"
    MAX_BUDGET = "max_budget"
    ABORT = "abort"
    ERROR = "error"
    BLOCKING_LIMIT = "blocking_limit"


# ── Tool batch model for concurrent execution ─────────────────────────────────

class ToolBatch:
    """A group of tool calls to execute together."""

    def __init__(self, calls: list[ToolCall], is_concurrent: bool) -> None:
        self.calls = calls
        self.is_concurrent = is_concurrent


def _partition_tool_calls(
    tool_calls: list[ToolCall],
    tools: list[Any],
) -> list[ToolBatch]:
    """
    Partition consecutive tool calls into batches.

    Adjacent read-only calls form a concurrent batch.
    Any non-read-only call runs alone as a sequential batch.

    Adapted from toolOrchestration.ts partition pattern.
    Default is NOT concurrent (tools must opt in via is_read_only=True).
    """
    batches: list[ToolBatch] = []
    current_batch: list[ToolCall] = []
    current_is_concurrent = False

    for tc in tool_calls:
        tool = find_tool(tools, tc.tool_name)
        is_read_only = bool(tool and tool.is_read_only)

        if is_read_only:
            if current_is_concurrent:
                current_batch.append(tc)
            else:
                if current_batch:
                    batches.append(ToolBatch(current_batch, is_concurrent=False))
                current_batch = [tc]
                current_is_concurrent = True
        else:
            if current_batch:
                batches.append(ToolBatch(current_batch, is_concurrent=current_is_concurrent))
            current_batch = [tc]
            current_is_concurrent = False

    if current_batch:
        batches.append(ToolBatch(current_batch, is_concurrent=current_is_concurrent))

    return batches


async def query_loop(
    state: LoopState,
    engine: "ChatEngine",
) -> AsyncGenerator[Any, None]:
    """
    Core agent loop. Yields HarnessEvents to ChatEngine.

    Runs until:
    - Model produces text with no tool calls (SUCCESS)
    - Turn count reaches max_turns
    - Budget exceeded
    - Abort signaled
    - Compaction circuit breaker triggered (continues without compaction)
    """
    from intent_api_harness.prompts.constants import MAX_CONSECUTIVE_COMPACT_FAILURES
    from intent_api_harness.utils.token_counter import estimate_token_count, should_compact

    while True:
        # ── Pre-turn checks ────────────────────────────────────────────────

        if engine._aborted:
            return

        if state.turn_count >= engine.config.max_turns:
            return

        if (
            engine.config.max_budget_usd
            and engine.total_cost_usd >= engine.config.max_budget_usd
        ):
            return

        # ── Hook: TURN_START ───────────────────────────────────────────────
        if engine.hooks:
            from intent_api_harness.hooks import fire_hooks, HookEvent
            await fire_hooks(engine.hooks, HookEvent.TURN_START, {
                "session_id": engine.session_id,
                "turn": state.turn_count,
                "message_count": len(state.messages),
                "token_count": state.token_count,
            })

        # ── Dynamic tool schemas — rebuild based on current mode ───────────

        current_mode = engine._mode
        tool_schemas = engine._get_active_tool_schemas(current_mode)

        # ── Phase 2: Compaction (runs here, before model call) ─────────────

        if (
            engine.compaction_provider
            and state.compact_tracking.consecutive_failures < MAX_CONSECUTIVE_COMPACT_FAILURES
        ):
            token_count = estimate_token_count(state.messages)
            if should_compact(token_count, engine.config.context_window, engine.config.max_output_tokens):
                try:
                    result = await engine.compaction_provider.compact(
                        messages=state.messages,
                        system_prompt=engine.system_prompt,
                        model_provider=engine.model_provider,
                        tool_summaries=state.pending_tool_summaries,
                    )
                    state.messages = [result.boundary, *result.summary_messages]
                    engine.messages = state.messages
                    state.compact_tracking.consecutive_failures = 0
                    state.pending_tool_summaries = []
                    if result.summary_messages:
                        engine._last_compaction_summary = result.summary_messages[0].content
                    # Re-inject plan attachment after compaction so mode survives context replacement
                    if engine._mode == HarnessMode.PLAN:
                        engine._needs_plan_attachment = True
                    yield CompactEvent(
                        session_id=engine.session_id,
                        pre_token_count=result.pre_token_count,
                        post_token_count=result.post_token_count,
                        messages_summarized=result.messages_summarized,
                    )
                    if engine.hooks:
                        from intent_api_harness.hooks import fire_hooks, HookEvent
                        await fire_hooks(engine.hooks, HookEvent.COMPACT, {
                            "session_id": engine.session_id,
                            "pre_token_count": result.pre_token_count,
                            "post_token_count": result.post_token_count,
                            "messages_summarized": result.messages_summarized,
                        })
                except Exception as e:
                    state.compact_tracking.consecutive_failures += 1
                    logger.warning(
                        "Compaction failed",
                        extra={
                            "consecutive_failures": state.compact_tracking.consecutive_failures,
                            "error": str(e),
                        },
                    )

        # ── Plan mode attachment injection ────────────────────────────────
        # Injected once on mode entry, then re-injected after each compaction.
        # Uses the message list for the model call only — not stored in history.

        if engine._mode == HarnessMode.PLAN and engine._needs_plan_attachment:
            plan_attachment = SystemMessage(
                subtype="plan_mode",
                content=_PLAN_MODE_ATTACHMENT,
            )
            messages_for_model = state.messages + [plan_attachment]
            engine._needs_plan_attachment = False
        else:
            messages_for_model = state.messages

        # ── Format messages for model API ──────────────────────────────────

        model_messages = _format_for_model(messages_for_model)

        # ── Stream model response ──────────────────────────────────────────

        assistant_content = ""
        assistant_thinking = ""
        tool_calls: list[ToolCall] = []
        final_usage = None

        async for chunk in engine.model_provider.stream(
            messages=model_messages,
            system_prompt=engine.system_prompt,
            tools=tool_schemas,
            max_output_tokens=engine.config.max_output_tokens,
        ):
            if chunk.type == "text" and chunk.text:
                assistant_content += chunk.text
                yield TextDeltaEvent(session_id=engine.session_id, text=chunk.text)

            elif chunk.type == "thinking" and chunk.text:
                assistant_thinking += chunk.text
                yield ThinkingDeltaEvent(session_id=engine.session_id, text=chunk.text)

            elif chunk.type == "tool_call_end" and chunk.tool_call:
                tool_calls.append(chunk.tool_call)

            elif chunk.type == "usage" and chunk.usage:
                final_usage = chunk.usage

        # ── Update cost and usage ──────────────────────────────────────────

        if final_usage:
            engine.total_usage.input_tokens += final_usage.input_tokens
            engine.total_usage.output_tokens += final_usage.output_tokens
            engine.total_usage.total_tokens += final_usage.total_tokens
            state.token_count = (
                final_usage.input_tokens
                + final_usage.output_tokens
                + final_usage.cache_read_tokens
            )

        # ── Build and store assistant message ─────────────────────────────

        assistant_msg = AssistantMessage(
            content=assistant_content or None,
            tool_calls=tool_calls or None,
            thinking=assistant_thinking or None,
            input_tokens=getattr(final_usage, "input_tokens", 0) if final_usage else 0,
            output_tokens=getattr(final_usage, "output_tokens", 0) if final_usage else 0,
        )
        state.messages.append(assistant_msg)

        # ── No tool calls → done ───────────────────────────────────────────

        if not tool_calls:
            return

        # ── Execute tools (with concurrent batching) ───────────────────────

        batches = _partition_tool_calls(tool_calls, engine.tools)

        for batch in batches:
            if batch.is_concurrent and len(batch.calls) > 1:
                # ── Concurrent batch: emit all starts, gather, emit results ─

                for tc in batch.calls:
                    yield ToolStartEvent(
                        session_id=engine.session_id,
                        tool_call_id=tc.id,
                        tool_name=tc.tool_name,
                        input=tc.input,
                        display=_resolve_tool_display(tc, engine),
                        intent=_extract_intent_summary(tc),
                    )

                semaphore = asyncio.Semaphore(engine.config.max_tool_concurrency)

                async def _execute_one(tc: ToolCall) -> tuple[ToolCall, ExecutionResult]:
                    async with semaphore:
                        tool = find_tool(engine.tools, tc.tool_name)
                        if tool is None:
                            res = ExecutionResult(
                                status="error",
                                message=f"<tool_use_error>No such tool: {tc.tool_name}.</tool_use_error>",
                            )
                        else:
                            try:
                                res = await tool.call(tc.input, engine)
                            except Exception as e:
                                res = ExecutionResult(
                                    status="error",
                                    message=f"<tool_use_error>Error calling tool ({tc.tool_name}): {str(e)[:2000]}</tool_use_error>",
                                )
                        return tc, res

                pairs = await asyncio.gather(*[_execute_one(tc) for tc in batch.calls])

                # Emit results and append messages in original call order
                for tc, result in pairs:
                    yield ToolResultEvent(
                        session_id=engine.session_id,
                        tool_call_id=tc.id,
                        result=result,
                    )
                    state.messages.append(ToolResultMessage(tool_call_id=tc.id, result=result))
                    state.pending_tool_summaries.append(
                        ToolSummary(
                            tool_name=tc.tool_name,
                            intent_id=result.intent_id,
                            display=result.display,
                            status=result.status,
                            turn=state.turn_count,
                        )
                    )

            else:
                # ── Sequential batch ───────────────────────────────────────

                for tc in batch.calls:
                    pre_call_mode = engine._mode

                    intent_summary = _extract_intent_summary(tc)
                    display = _resolve_tool_display(tc, engine)
                    yield ToolStartEvent(
                        session_id=engine.session_id,
                        tool_call_id=tc.id,
                        tool_name=tc.tool_name,
                        input=tc.input,
                        display=display,
                        intent=intent_summary,
                    )

                    # Hook: INTENT_CALL
                    if engine.hooks and intent_summary:
                        from intent_api_harness.hooks import fire_hooks, HookEvent
                        await fire_hooks(engine.hooks, HookEvent.INTENT_CALL, {
                            "session_id": engine.session_id,
                            "tool_call_id": tc.id,
                            "tool_name": tc.tool_name,
                            "intent_model": intent_summary.model,
                            "intent_action": intent_summary.action,
                            "intent_command": intent_summary.command,
                            "intent_id": f"{intent_summary.model}.{intent_summary.command or intent_summary.action}",
                            "turn": state.turn_count,
                        })

                    tool = find_tool(engine.tools, tc.tool_name)

                    if tool is None:
                        result = ExecutionResult(
                            status="error",
                            message=(
                                f"<tool_use_error>No such tool available: {tc.tool_name}. "
                                f"Use ToolSearchTool to discover available tools.</tool_use_error>"
                            ),
                        )
                    else:
                        try:
                            result = await tool.call(tc.input, engine)
                        except Exception as e:
                            result = ExecutionResult(
                                status="error",
                                message=f"<tool_use_error>Error calling tool ({tc.tool_name}): {str(e)[:2000]}</tool_use_error>",
                            )

                    yield ToolResultEvent(
                        session_id=engine.session_id,
                        tool_call_id=tc.id,
                        result=result,
                    )

                    # ── Mode change detection → emit ModeChangeEvent ────────
                    post_call_mode = engine._mode
                    if post_call_mode != pre_call_mode:
                        yield ModeChangeEvent(
                            session_id=engine.session_id,
                            mode=post_call_mode.value,
                            previous_mode=pre_call_mode.value,
                        )

                    # Hook: INTENT_RESULT
                    if engine.hooks and intent_summary:
                        from intent_api_harness.hooks import fire_hooks, HookEvent
                        await fire_hooks(engine.hooks, HookEvent.INTENT_RESULT, {
                            "session_id": engine.session_id,
                            "tool_call_id": tc.id,
                            "intent_id": f"{intent_summary.model}.{intent_summary.command or intent_summary.action}",
                            "status": result.status,
                            "turn": state.turn_count,
                        })

                    state.messages.append(ToolResultMessage(tool_call_id=tc.id, result=result))
                    state.pending_tool_summaries.append(
                        ToolSummary(
                            tool_name=tc.tool_name,
                            intent_id=result.intent_id,
                            display=result.display,
                            status=result.status,
                            turn=state.turn_count,
                        )
                    )

        state.turn_count += 1
        state.last_transition = "tool_results"


# ── Helpers ───────────────────────────────────────────────────────────────────


def _format_for_model(messages: list[Any]) -> list[dict[str, Any]]:
    """
    Convert internal Message objects to LiteLLM-format dicts.

    LiteLLM expects OpenAI-compatible message format:
    - user: {"role": "user", "content": "..."}
    - assistant with tool calls: {"role": "assistant", "tool_calls": [...]}
    - tool result: {"role": "tool", "tool_call_id": "...", "content": "..."}
    """
    result = []
    for msg in messages:
        msg_type = getattr(msg, "type", None)

        if msg_type == "compact_boundary":
            continue

        elif msg_type == "system":
            # Plan mode attachment and other system messages injected as user
            # messages so they appear in the conversation flow
            result.append({"role": "user", "content": f"[System] {msg.content}"})

        elif msg_type == "user":
            result.append({"role": "user", "content": msg.content})

        elif msg_type == "assistant":
            entry: dict[str, Any] = {"role": "assistant"}
            if msg.content:
                entry["content"] = msg.content
            if msg.tool_calls:
                entry["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.tool_name, "arguments": str(tc.input)},
                    }
                    for tc in msg.tool_calls
                ]
            result.append(entry)

        elif msg_type == "tool_result":
            import json
            content = json.dumps(msg.result.model_dump()) if msg.result.data is not None else (msg.result.message or "")
            result.append({
                "role": "tool",
                "tool_call_id": msg.tool_call_id,
                "content": content,
            })

    return result


def _extract_intent_summary(tool_call: ToolCall) -> IntentSummary | None:
    """Extract IntentSummary from an execute_intent tool call."""
    if tool_call.tool_name != "execute_intent":
        return None
    inp = tool_call.input
    return IntentSummary(
        model=inp.get("model", ""),
        action=inp.get("action", ""),
        id=inp.get("id"),
        command=inp.get("command"),
    )


def _resolve_tool_display(tool_call: ToolCall, engine: "ChatEngine") -> str | None:
    """Get a human-readable display label for a tool call."""
    if tool_call.tool_name == "ToolSearchTool":
        query = tool_call.input.get("query", "")
        return f"Searching for '{query}'" if query else "Searching available tools"

    if tool_call.tool_name == "execute_intent":
        from intent_api_harness.tools.intent_tool import _resolve_display
        model = tool_call.input.get("model", "")
        action = tool_call.input.get("action", "")
        command = tool_call.input.get("command")
        service = engine.registry.get(model)
        return _resolve_display(service, model, action, command)

    if tool_call.tool_name == "Think":
        return "Thinking..."

    if tool_call.tool_name == "TodoWrite":
        todos = tool_call.input.get("todos", [])
        in_progress = [t for t in todos if t.get("status") == "in_progress"]
        if in_progress:
            return in_progress[0].get("active_form", "Updating tasks...")
        return "Updating tasks..."

    if tool_call.tool_name in ("EnterPlanMode", "ExitPlanMode"):
        return tool_call.tool_name.replace("PlanMode", " plan mode")

    if tool_call.tool_name == "spawn_task":
        mode = tool_call.input.get("mode", "general")
        return "Verifying work..." if mode == "verify" else "Spawning sub-agent..."

    return None
