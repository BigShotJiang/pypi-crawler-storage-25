"""
Hybrid token counting — adapted from the TypeScript harness.

Strategy: walk backward to find the last AssistantMessage with API-reported
usage. Use that as an anchor. Estimate (chars / 4) for all messages after it.

The chars/4 heuristic is a Claude-specific empirical value from the TS harness.
"""

from __future__ import annotations

from typing import Any

from intent_api_harness.prompts.constants import CHARS_PER_TOKEN_ESTIMATE


def estimate_token_count(messages: list[Any]) -> int:
    """
    Hybrid token count for a message list.

    Walks backward to find an AssistantMessage with reported API usage,
    uses that as the anchor, and estimates the remaining tail with chars/4.
    Falls back to pure estimation if no API usage is available.
    """
    # Walk backward to find the most recent message with API usage
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        msg_type = getattr(msg, "type", None)
        if msg_type != "assistant":
            continue

        input_tokens = getattr(msg, "input_tokens", 0) or 0
        output_tokens = getattr(msg, "output_tokens", 0) or 0
        if input_tokens == 0 and output_tokens == 0:
            continue

        # Found an anchor — add API count + estimate for everything after
        anchor_count = (
            input_tokens
            + output_tokens
            + (getattr(msg, "cache_read_tokens", 0) or 0)
            + (getattr(msg, "cache_write_tokens", 0) or 0)
        )
        tail_estimate = _rough_estimate(messages[i + 1:])
        return anchor_count + tail_estimate

    # No anchor — estimate everything
    return _rough_estimate(messages)


def _rough_estimate(messages: list[Any]) -> int:
    total_chars = 0
    for msg in messages:
        # Skip boundary markers — they're not part of the active context
        if getattr(msg, "type", None) == "compact_boundary":
            continue
        content = getattr(msg, "content", None)
        if content and isinstance(content, str):
            total_chars += len(content)
        tool_calls = getattr(msg, "tool_calls", None)
        if tool_calls:
            for tc in tool_calls:
                total_chars += len(str(getattr(tc, "input", "")))
    return max(0, total_chars // CHARS_PER_TOKEN_ESTIMATE)


def should_compact(
    token_count: int,
    context_window: int,
    max_output_tokens: int,
) -> bool:
    """
    Returns True when the token count has exceeded the autocompact threshold.

    threshold = context_window - reserved_summary_output - autocompact_buffer
    """
    from intent_api_harness.prompts.constants import (
        AUTOCOMPACT_BUFFER_TOKENS,
        COMPACT_MAX_OUTPUT_TOKENS,
    )

    reserved = min(max_output_tokens, COMPACT_MAX_OUTPUT_TOKENS)
    effective_window = context_window - reserved
    threshold = effective_window - AUTOCOMPACT_BUFFER_TOKENS
    return token_count >= threshold
