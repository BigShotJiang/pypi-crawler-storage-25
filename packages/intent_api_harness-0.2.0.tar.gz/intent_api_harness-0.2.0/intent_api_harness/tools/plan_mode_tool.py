"""
Plan mode tools — EnterPlanModeTool and ExitPlanModeTool.

Plan mode is a user-approved planning phase where the model explores
available intents and designs an approach before executing write actions.
It is the same query loop with a mode flag, an injected attachment that
reminds the model of its constraints, and a soft-block on write actions
in ExecuteIntentTool.

EnterPlanModeTool / ExitPlanModeTool descriptions adapted from
production-tuned source material. Vocabulary adaptations only:
software-engineering examples replaced with Intent API equivalents,
file/codebase references replaced with intent/resource equivalents.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from intent_api_harness.messages import ExecutionResult
from intent_api_harness.state import HarnessMode

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine

# ── EnterPlanModeTool ──────────────────────────────────────────────────────────
# Prompt adapted from EnterPlanModeTool/prompt.ts (external variant).
# Gated/ant-only sections omitted per B9.

_ENTER_PLAN_MODE_DESCRIPTION = """\
Use this tool when a task has genuine ambiguity about the right approach \
and getting user input before executing would prevent significant wasted work. \
This tool transitions you into plan mode where you can explore available \
intents and design an execution approach for user approval.

## When to Use This Tool

Plan mode is valuable when the execution approach is genuinely unclear. Use it when:

1. **Significant Approach Ambiguity**: Multiple reasonable approaches exist and \
the choice meaningfully affects the outcome
   - Example: "Set up my SEO content strategy" - which intents to call, in what order, with what parameters?
   - Example: "Migrate my brands to the new format" - what changes need to happen first?

2. **Unclear Requirements**: You need to explore and clarify before you can make progress
   - Example: "Clean up my content" - need to understand what exists before deciding what to change
   - Example: "Optimize my setup" - need to read current state before proposing changes

3. **High-Impact Sequences**: The task will execute multiple write actions (create, update, delete) \
and getting approval first reduces risk of unwanted changes

## When NOT to Use This Tool

Skip plan mode when you can reasonably infer the right approach:
 - The task is straightforward even if it touches multiple intents
 - The user's request is specific enough that the execution path is clear
 - Simple lookups or read-only exploration tasks
 - The user says something like "can we work on X" or "let's do X" — just get started

When in doubt, prefer starting work and using Think to reason through questions \
over entering a full planning phase.

## Examples

### Use EnterPlanMode:
User: "Set up a complete content strategy for my SaaS products"
 - Ambiguous: which brands? which keywords? what generation schedule?

User: "Restructure all my brands"
 - High impact: affects multiple resources; approval before execution prevents mistakes

### Do NOT use EnterPlanMode:
User: "What brands do I have?"
 - Simple read — just do it

User: "Generate a blog post for Acme"
 - Clear, specific request — execute directly

User: "Show me my subscription status"
 - Read-only, no planning needed\
"""

_ENTER_PLAN_MODE_RESPONSE = """\
Entered plan mode. You should now focus on exploring available intents \
and designing an execution approach.

In plan mode, you should:
1. Use ToolSearchTool to discover available intents and understand the system
2. Use execute_intent with action='read' or action='list' to inspect existing data
3. Use Think to reason about multiple approaches and their trade-offs
4. Use TodoWrite to outline your implementation plan as a task list
5. When your plan is complete, use ExitPlanMode to present it for approval

Remember: DO NOT execute any write actions yet (create, update, delete, or \
custom commands that modify data). This is a read-only exploration and \
planning phase.\
"""

# ── ExitPlanModeTool ──────────────────────────────────────────────────────────
# Prompt adapted from ExitPlanModeTool/ExitPlanModeV2Tool.ts.
# Plan-file references removed (no plan file in this harness).

_EXIT_PLAN_MODE_DESCRIPTION = """\
Use this tool when you are in plan mode and have finished designing your \
execution approach and are ready for user approval.

## How This Tool Works
 - You should have already outlined your plan using TodoWrite
 - This tool signals that you're done planning and ready for the user to review
 - The user will see your todo list and reasoning when they approve

## When to Use This Tool
Only use this tool when you have a complete, unambiguous plan ready. For \
research tasks where you're gathering information — do NOT use this tool yet.

## Before Using This Tool
Ensure your plan is complete:
 - All key decisions made (which intents to call, in what order, with what data)
 - Edge cases and failure scenarios considered
 - Todo list reflects the full execution sequence

## Examples

1. Task: "Show me what brands I have" — Do not use ExitPlanMode; just read directly.
2. Task: "Set up SEO content for all my brands" — Use ExitPlanMode after you've \
   explored what exists and planned the full generation sequence.
3. Task: "Update all brand descriptions" — Use ExitPlanMode after you've listed \
   all brands and designed the update approach.\
"""


# ── Tool implementations ───────────────────────────────────────────────────────


class EnterPlanModeTool:
    """
    Transitions the harness into plan mode.

    Cannot be used by sub-agents. Returns an error if already in plan mode.
    """

    @property
    def name(self) -> str:
        return "EnterPlanMode"

    @property
    def description(self) -> str:
        return _ENTER_PLAN_MODE_DESCRIPTION

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    @property
    def is_read_only(self) -> bool:
        return True

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        if engine.is_subagent:
            return ExecutionResult(
                status="error",
                message="EnterPlanMode cannot be used in sub-agent contexts.",
                display="Blocked",
            )

        if engine._mode == HarnessMode.PLAN:
            return ExecutionResult(
                status="error",
                message="Already in plan mode.",
                display="Already planning",
            )

        # Transition — tools access engine._mode; state.mode synced separately
        engine._pre_plan_mode = engine._mode
        engine._mode = HarnessMode.PLAN
        engine._needs_plan_attachment = True  # inject attachment on next turn

        return ExecutionResult(
            status="success",
            data={"mode": "plan"},
            message=_ENTER_PLAN_MODE_RESPONSE,
            display="Entering plan mode...",
        )


class ExitPlanModeTool:
    """
    Exits plan mode and restores the previous permission state.

    Returns an error if not currently in plan mode.
    """

    @property
    def name(self) -> str:
        return "ExitPlanMode"

    @property
    def description(self) -> str:
        return _EXIT_PLAN_MODE_DESCRIPTION

    @property
    def input_schema(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    @property
    def is_read_only(self) -> bool:
        return True

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        if engine._mode != HarnessMode.PLAN:
            return ExecutionResult(
                status="error",
                message=(
                    "You are not in plan mode. This tool is only for exiting plan mode "
                    "after writing a plan. If your plan was already approved, continue "
                    "with implementation."
                ),
                display="Not in plan mode",
            )

        restore_mode = engine._pre_plan_mode or HarnessMode.EXECUTE
        engine._mode = restore_mode
        engine._pre_plan_mode = None
        engine._needs_plan_attachment = False

        return ExecutionResult(
            status="success",
            data={"mode": restore_mode.value},
            message=(
                "Exited plan mode. You may now execute your plan. "
                "Proceed with the tasks you outlined — use TodoWrite to track progress."
            ),
            display="Exiting plan mode — ready to execute",
        )
