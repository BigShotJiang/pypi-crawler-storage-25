"""
TodoWriteTool — structured task tracking for multi-step sessions.

The model uses this to externalize its plan as a list of pending /
in_progress / completed items. Visible to the user in the SSE stream.
Helps maintain coherence across long multi-step sessions.

The tool description (below) is adapted from production-tuned source
material. Vocabulary adaptations only: coding examples replaced with
Intent API examples, tool names updated. Structure, rules, and example
count (7 when-to-use, 4 when-not-to-use) preserved verbatim.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field

from intent_api_harness.messages import ExecutionResult

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine


# ── Schemas ───────────────────────────────────────────────────────────────────


class TodoStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class TodoItem(BaseModel):
    content: str = Field(min_length=1)
    status: TodoStatus
    active_form: str = Field(min_length=1)


# ── Full adapted prompt (7 when-to-use + 4 when-not-to-use examples) ─────────
# Source: TodoWriteTool/prompt.ts — vocabulary adaptations only.
# Coding examples replaced with Intent API equivalents.
# Rules, structure, and example count preserved verbatim.

_DESCRIPTION = """\
Use this tool to create and manage a structured task list for your current \
session. This helps you track progress, organize complex tasks, and demonstrate \
thoroughness to the user.
It also helps the user understand the progress of the task and overall progress \
of their requests.

## When to Use This Tool
Use this tool proactively in these scenarios:

1. Complex multi-step tasks - When a task requires 3 or more distinct steps or actions
2. Non-trivial and complex tasks - Tasks that require careful planning or multiple operations
3. User explicitly requests todo list - When the user directly asks you to use the todo list
4. User provides multiple tasks - When users provide a list of things to be done (numbered or comma-separated)
5. After receiving new instructions - Immediately capture user requirements as todos
6. When you start working on a task - Mark it as in_progress BEFORE beginning work. Ideally you should only have one todo as in_progress at a time
7. After completing a task - Mark it as completed and add any new follow-up tasks discovered during execution

## When NOT to Use This Tool

Skip using this tool when:
1. There is only a single, straightforward task
2. The task is trivial and tracking it provides no organizational benefit
3. The task can be completed in less than 3 trivial steps
4. The task is purely conversational or informational

NOTE that you should not use this tool if there is only one trivial task to do. In this case you are better off just doing the task directly.

## Examples of When to Use the Todo List

<example>
User: I want to generate blog posts for all my brands and then publish the approved ones to GitHub.
Assistant: *Creates todo list with the following items:*
1. Loading all brands to identify which ones need content
2. Generating blog posts for each brand via the generate command
3. Checking which posts are in draft status and ready for review
4. Publishing approved posts to GitHub
5. Reporting summary of what was generated and published

*Begins working on the first task*

<reasoning>
The assistant used the todo list because:
1. This is a multi-step task spanning multiple intents across multiple models
2. The user explicitly wanted generation followed by publishing — a clear sequence
3. Each step depends on the previous, and the list tracks which brands are done
</reasoning>
</example>

<example>
User: Help me set up SEO content for my new brand
Assistant: *Uses ToolSearchTool to discover what brand setup involves*
I can see Brand CRUD and BlogPost generation are available.
*Creates todo list with specific items for the setup flow*

<reasoning>
The assistant used the todo list because:
1. First, the assistant searched to understand the scope of the task
2. Upon finding multiple steps (create brand, configure settings, generate first post), it determined this was complex
3. The todo list ensures each setup step is tracked and completed systematically
4. This approach prevents missing any step in the onboarding flow
</reasoning>
</example>

<example>
User: I need to do these things: update my brand description, generate 3 blog posts for the Acme brand, and check my subscription status.
Assistant: *Creates a todo list breaking down each request as a separate task*
Let's start with updating your brand description.

<reasoning>
The assistant used the todo list because:
1. The user provided multiple distinct tasks in a comma-separated list
2. The todo list helps organize these into trackable steps
3. This approach allows for tracking progress across the entire set of requests
</reasoning>
</example>

<example>
User: Can you audit my content strategy? I feel like I'm missing some opportunities.
Assistant: *Uses ToolSearchTool to discover what data is available, then lists brands and recent posts*
After reviewing your content, I've identified several gaps.
*Creates todo list: 1) Checking GSC suggestions for each brand, 2) Reviewing which brands have no posts in the last 30 days, 3) Looking at post statuses for any stuck drafts, 4) Summarizing recommendations by priority, 5) Creating any urgent posts identified*
Let's start by checking GSC suggestions to find high-opportunity keywords.

<reasoning>
The assistant used the todo list because:
1. First, the assistant explored available data to understand the scope
2. Based on the exploration, it identified multiple audit dimensions
3. A content audit is non-trivial and spans multiple models
4. The todo list helps methodically cover every area
5. This systematic approach ensures no gaps are missed
</reasoning>
</example>

<example>
User: What brands do I have?
Assistant: *Calls execute_intent(Brand, list)*
You have 3 brands: Acme Corp, Globex, and VenuePreview.

<reasoning>
The assistant did NOT use the todo list because this is a single, trivial lookup that completes in one step. No tracking needed.
</reasoning>
</example>

<example>
User: What is the execute_intent tool?
Assistant: The execute_intent tool lets you run any registered intent on the system...

<reasoning>
The assistant did NOT use the todo list because this is an informational question with no actions to take.
</reasoning>
</example>

<example>
User: Update the name of my Acme brand to "Acme Corp"
Assistant: *Calls execute_intent(Brand, update, id="acme", payload={name: "Acme Corp"})*

<reasoning>
The assistant did NOT use the todo list because this is a single, straightforward update confined to one intent call. No tracking needed.
</reasoning>
</example>

<example>
User: Generate a blog post for me.
Assistant: *Calls execute_intent(BlogPost, custom, command="generate")* 

<reasoning>
The assistant did NOT use the todo list because this is a single command execution with immediate results. There are no multiple steps to track or organize.
</reasoning>
</example>

## Task States and Management

1. **Task States**: Use these states to track progress:
   - pending: Task not yet started
   - in_progress: Currently working on (limit to ONE task at a time)
   - completed: Task finished successfully

   **IMPORTANT**: Task descriptions must have two forms:
   - content: The imperative form describing what needs to be done (e.g., "Load all brands", "Generate blog post for Acme")
   - active_form: The present continuous form shown during execution (e.g., "Loading all brands", "Generating blog post for Acme")

2. **Task Management**:
   - Update task status in real-time as you work
   - Mark tasks complete IMMEDIATELY after finishing (don't batch completions)
   - Exactly ONE task must be in_progress at any time (not less, not more)
   - Complete current tasks before starting new ones
   - Remove tasks that are no longer relevant from the list entirely

3. **Task Completion Requirements**:
   - ONLY mark a task as completed when you have FULLY accomplished it
   - If you encounter errors, blockers, or cannot finish, keep the task as in_progress
   - When blocked, create a new task describing what needs to be resolved
   - Never mark a task as completed if:
     - The intent returned an error, denied, or quota_exceeded status
     - Execution is partial
     - You encountered unresolved errors
     - You couldn't find a required resource

4. **Task Breakdown**:
   - Create specific, actionable items
   - Break complex tasks into smaller, manageable steps
   - Use clear, descriptive task names
   - Always provide both forms:
     - content: "Publish blog post to GitHub"
     - active_form: "Publishing blog post to GitHub"

When in doubt, use this tool. Being proactive with task management demonstrates attentiveness and ensures you complete all requirements successfully.\
"""

_SHORT_DESCRIPTION = (
    "Update the todo list for the current session. To be used proactively and "
    "often to track progress and pending tasks. Make sure that at least one "
    "task is in_progress at all times. Always provide both content (imperative) "
    "and active_form (present continuous) for each task."
)

_INPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "todos": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": (
                            "Task in imperative form "
                            "(e.g., 'Load all brands', 'Generate blog post for Acme')"
                        ),
                    },
                    "status": {
                        "type": "string",
                        "enum": ["pending", "in_progress", "completed"],
                    },
                    "active_form": {
                        "type": "string",
                        "description": (
                            "Task in continuous form for UI display "
                            "(e.g., 'Loading all brands', 'Generating blog post for Acme')"
                        ),
                    },
                },
                "required": ["content", "status", "active_form"],
            },
            "description": (
                "The complete todo list. Send the FULL list every time, "
                "not just changes."
            ),
        }
    },
    "required": ["todos"],
}


# ── Tool ──────────────────────────────────────────────────────────────────────


class TodoWriteTool:
    """
    Structured task tracking. Per-session state stored on the tool instance
    (one instance per ChatEngine session). Sub-agents with different engines
    have separate todo lists.
    """

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self._todos: list[TodoItem] = []

    @property
    def name(self) -> str:
        return "TodoWrite"

    @property
    def description(self) -> str:
        return _DESCRIPTION

    @property
    def input_schema(self) -> dict[str, Any]:
        return _INPUT_SCHEMA

    @property
    def is_read_only(self) -> bool:
        return True

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                # Use short description in the schema — full prompt is too long
                # for the tool schema field. The system prompt section provides
                # the when-to-use guidance; the full description above is
                # available as the tool's behavioral spec but the schema uses
                # the concise version to keep token cost reasonable.
                "description": _SHORT_DESCRIPTION,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        raw_todos = input.get("todos", [])
        try:
            new_todos = [TodoItem(**item) for item in raw_todos]
        except Exception as e:
            return ExecutionResult(
                status="error",
                message=f"Invalid todo item: {e}",
                display="Todo update failed",
            )

        old_todos = list(self._todos)
        all_done = (
            len(new_todos) > 0
            and all(t.status == TodoStatus.COMPLETED for t in new_todos)
        )

        # Auto-clear when all completed — forces explicit re-add for next phase
        self._todos = [] if all_done else new_todos

        # Build display label from in-progress item
        in_progress = [t for t in new_todos if t.status == TodoStatus.IN_PROGRESS]
        if in_progress:
            display = in_progress[0].active_form
        elif all_done:
            display = "All tasks completed"
        else:
            display = f"Updated task list ({len(new_todos)} items)"

        message = _build_response_message(new_todos, all_done)

        return ExecutionResult(
            status="success",
            data={
                "old_todos": [t.model_dump() for t in old_todos],
                "new_todos": [t.model_dump() for t in new_todos],
                "all_completed": all_done,
            },
            message=message,
            display=display,
        )

    @property
    def current_todos(self) -> list[TodoItem]:
        """Current todo list — readable by engine for observability."""
        return list(self._todos)


# ── Helpers ───────────────────────────────────────────────────────────────────


def _build_response_message(todos: list[TodoItem], all_done: bool) -> str:
    """
    Build the tool result message the model sees.
    Verbatim base text from source; review nudge adapted (no verification
    subagent in this version — nudge triggers self-review instead).
    """
    base = (
        "Todos have been modified successfully. Ensure that you continue to "
        "use the todo list to track your progress. Please proceed with the "
        "current tasks if applicable."
    )
    if all_done and len(todos) >= 3:
        base += (
            "\n\nNOTE: You just completed 3+ tasks. Before writing your final "
            "summary to the user, spawn a verification sub-agent using spawn_task "
            "with task describing what was done and mode='verify'. "
            "You cannot self-verify — only the verification agent issues a verdict. "
            "On FAIL: fix the issues, then re-verify. On PASS: report completion to the user."
        )
    return base
