"""
ThinkTool — a no-op reasoning tool.

Forces the model to externalize its reasoning as a tool call. The model
writes out its step-by-step plan, receives its own reasoning back as a
tool result, then executes. Works with every LLM provider via LiteLLM —
no provider-specific reasoning API required.

Listed first in the tool schema to encourage reasoning before action.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from intent_api_harness.messages import ExecutionResult

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine

_DESCRIPTION = """\
Use this tool to think through a problem step by step before taking action.

Use it to:
- Plan multi-step sequences before beginning execution
- Reason about which intents to call and in what order
- Analyze unexpected tool results before deciding what to do next
- Diagnose errors and figure out a focused fix before retrying
- Re-evaluate your approach when the current plan is not working

Your reasoning will be returned to you so you can reference it as you proceed.

Use this tool liberally — before complex tasks, after unexpected results, and \
when you need to re-evaluate your approach. Think first, then act. \
Do not guess at intent parameters — use Think to reason about what you know \
and what you need to find out, then use ToolSearchTool to discover the right \
intents, then execute.\
"""

_INPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "reasoning": {
            "type": "string",
            "description": (
                "Your step-by-step reasoning. Be specific: what do you know, "
                "what do you need to find out, what is your plan, what could go wrong."
            ),
        }
    },
    "required": ["reasoning"],
}


class ThinkTool:
    """No-op reasoning tool. Returns the model's own reasoning back to it."""

    @property
    def name(self) -> str:
        return "Think"

    @property
    def description(self) -> str:
        return _DESCRIPTION

    @property
    def input_schema(self) -> dict[str, Any]:
        return _INPUT_SCHEMA

    @property
    def is_read_only(self) -> bool:
        return True

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        reasoning = input.get("reasoning", "")
        return ExecutionResult(
            status="success",
            data={"reasoning": reasoning},
            # Option B: put reasoning in message so the action card can surface it
            message=reasoning,
            display="Thinking...",
        )
