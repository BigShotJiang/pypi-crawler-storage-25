"""
SpawnTaskTool — lets the model delegate work to a sub-agent.

The sub-agent:
  - Gets a clean conversation (just the task description)
  - Has execute_intent + ToolSearchTool but NOT spawn_task (prevents nesting)
  - Uses the same ModelProvider and registry as the parent
  - Returns only its final text summary to the parent
  - Has a lower turn limit (default 10)

Depth is controlled by tool exclusion, not a counter — same pattern as the
TypeScript harness. Removing spawn_task from the sub-agent's tool list is
what prevents recursive spawning. No "max depth" counter needed.

The full sub-agent conversation is NOT injected into the parent's context.
Parent only sees the summary in the tool_result block.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import TextDeltaEvent
from intent_api_harness.messages import ExecutionResult

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine as ParentEngine

logger = logging.getLogger("intent_api_harness")

_SPAWN_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "task": {
            "type": "string",
            "description": (
                "Clear description of what the sub-agent should do. "
                "Be specific — the sub-agent has no context from the current conversation."
            ),
        },
        "mode": {
            "type": "string",
            "enum": ["general", "verify"],
            "description": (
                "Sub-agent mode. Use 'verify' for verification tasks where the sub-agent "
                "should independently check that prior work is correct. "
                "Verification sub-agents are read-only."
            ),
        },
        "max_turns": {
            "type": "integer",
            "description": "Maximum turns for the sub-agent (default 10).",
            "default": 10,
        },
    },
    "required": ["task"],
}

_SUB_AGENT_MAX_TURNS_DEFAULT = 10


class SpawnTaskTool:
    """
    Spawns an isolated sub-agent to complete a focused task.

    The sub-agent uses the same intent registry and model provider as the
    parent but has a fresh conversation context (no history). Its tool set
    is restricted to execute_intent + ToolSearchTool — spawn_task is
    deliberately excluded to prevent recursive nesting.

    Only the sub-agent's final text summary is returned to the parent.
    The full sub-agent conversation stays isolated.
    """

    @property
    def name(self) -> str:
        return "spawn_task"

    @property
    def description(self) -> str:
        return (
            "Delegate a focused task to a sub-agent with fresh context. "
            "Use for exploration or work that shouldn't pollute the main conversation. "
            "Returns a summary of what the sub-agent did."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return _SPAWN_SCHEMA

    @property
    def is_read_only(self) -> bool:
        return False

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ParentEngine",
    ) -> ExecutionResult:
        from intent_api_harness.prompts.verification import VERIFICATION_PROMPT

        task = input.get("task", "").strip()
        mode = input.get("mode", "general")
        max_turns = int(input.get("max_turns") or _SUB_AGENT_MAX_TURNS_DEFAULT)

        if not task:
            return ExecutionResult(
                status="error",
                message="<tool_use_error>spawn_task requires a non-empty 'task' description.</tool_use_error>",
            )

        is_verify = mode == "verify"

        logger.info(
            "Spawning sub-agent",
            extra={"task_preview": task[:100], "max_turns": max_turns, "mode": mode},
        )

        # Build sub-agent config — lower turn limit, inherit app_name and model
        # Verification sub-agents: no todos, no plan mode
        sub_config = ChatEngineConfig(
            model=engine.config.model,
            app_name=engine.config.app_name,
            max_turns=max_turns,
            context_window=engine.config.context_window,
            max_output_tokens=engine.config.max_output_tokens,
            enable_thinking=engine.config.enable_thinking,
            enable_todos=False if is_verify else False,  # sub-agents never get todos
            enable_plan_mode=False,
            # No custom_instructions — sub-agent is task-focused
        )

        # Create sub-agent — NO compaction, NO memory, NO hooks, NO spawn, is_subagent=True
        sub_engine = ChatEngine(
            config=sub_config,
            user=engine.user,
            intent_context=engine.intent_context,
            registry=engine.registry,
            model_provider=engine.model_provider,
            compaction_provider=None,
            memory_provider=None,
            runtime=engine._runtime,
            is_subagent=True,
            verification_mode=is_verify,
        )

        # Build task prompt — verification gets the contract prepended
        if is_verify:
            task_prompt = f"{VERIFICATION_PROMPT}\n\n## Task to Verify\n{task}"
            display = "Verification complete"
        else:
            task_prompt = task
            display = "Sub-agent task complete"

        # Run sub-agent to completion, collect only text
        final_text_parts: list[str] = []
        turn_count = 0
        error_msg: str | None = None

        try:
            async for event in sub_engine.submit_message(task_prompt, db=engine.db):
                if isinstance(event, TextDeltaEvent):
                    final_text_parts.append(event.text)
                from intent_api_harness.events import SessionEndEvent
                if isinstance(event, SessionEndEvent):
                    turn_count = event.turn_count
        except Exception as e:
            error_msg = str(e)[:500]
            logger.warning(
                "Sub-agent raised exception",
                extra={"error": error_msg},
            )

        summary = "".join(final_text_parts).strip()

        if error_msg:
            return ExecutionResult(
                status="error",
                message=f"Sub-agent failed: {error_msg}",
                display="Sub-agent failed",
            )

        if not summary:
            return ExecutionResult(
                status="error",
                message="<tool_use_error>Sub-agent produced no output.</tool_use_error>",
                display="Sub-agent produced no output",
            )

        logger.info(
            "Sub-agent completed",
            extra={"turn_count": turn_count, "summary_len": len(summary), "mode": mode},
        )

        return ExecutionResult(
            status="success",
            data={"summary": summary, "turns": turn_count, "mode": mode},
            message=summary,
            display=display,
        )
