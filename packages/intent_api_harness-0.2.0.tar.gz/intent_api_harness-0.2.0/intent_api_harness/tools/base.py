"""HarnessTool Protocol — the interface for all harness tools."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from intent_api_harness.messages import ExecutionResult

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine


@runtime_checkable
class HarnessTool(Protocol):
    @property
    def name(self) -> str: ...

    @property
    def description(self) -> str: ...

    @property
    def input_schema(self) -> dict[str, Any]: ...

    @property
    def is_read_only(self) -> bool: ...

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult: ...

    def to_litellm_schema(self) -> dict[str, Any]:
        """Convert to LiteLLM/OpenAI tool schema format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }


def find_tool(tools: list[Any], name: str) -> Any | None:
    """Linear scan for a tool by name. O(n) — tools list is small (<10 items)."""
    for tool in tools:
        if getattr(tool, "name", None) == name:
            return tool
    return None
