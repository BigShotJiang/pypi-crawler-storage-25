"""
ToolSearchTool — lets the model discover available intents.

Searches the IntentCatalog by keyword, model, or action.
Read-only, no auth, no policy.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from intent_api_harness.messages import ExecutionResult

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine

_SEARCH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "query": {
            "type": "string",
            "description": "Keyword to search across model names, action types, and descriptions.",
        },
        "model": {
            "type": "string",
            "description": "Filter by model/resource name (partial match, e.g. 'brand', 'blog').",
        },
        "action": {
            "type": "string",
            "description": "Filter by action type: create, read, update, delete, list, or custom.",
        },
    },
    "required": ["query"],
}


class ToolSearchTool:
    """Searches the intent catalog. The model uses this to discover what's available."""

    @property
    def name(self) -> str:
        return "ToolSearchTool"

    @property
    def description(self) -> str:
        return (
            "Search available intents by keyword, model name, or action type. "
            "Always search here before calling execute_intent if you're unsure what's available."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return _SEARCH_SCHEMA

    @property
    def is_read_only(self) -> bool:
        return True

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        query = input.get("query", "")
        model_filter = input.get("model")
        action_filter = input.get("action")

        results = engine.catalog.search(
            query=query or None,
            model=model_filter,
            action=action_filter,
        )

        if not results:
            return ExecutionResult(
                status="success",
                data={"matches": [], "total": 0},
                message="No intents found matching your search. Try broader terms.",
            )

        matches = [
            {
                "model": e.model,
                "action": e.action,
                **({"command": e.command} if e.command else {}),
                **({"description": e.description} if e.description else {}),
                "display": e.display,
                "type": e.type,
                **({"payload_schema": e.payload_schema} if e.payload_schema else {}),
            }
            for e in results[:20]
        ]

        return ExecutionResult(
            status="success",
            data={"matches": matches, "total": len(results)},
        )
