"""
ExecuteIntentTool — dispatches intents through the Intent API runtime.

The model calls this to perform any business action. Auth, permissions,
quota, and audit all apply — same as any REST request.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from intent_api_harness.messages import ExecutionResult
from intent_api_harness.events import IntentSummary

if TYPE_CHECKING:
    from intent_api_harness.engine import ChatEngine

logger = logging.getLogger("intent_api_harness")

_INTENT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "model": {
            "type": "string",
            "description": "Target resource type (e.g. Brand, BlogPost, User).",
        },
        "action": {
            "type": "string",
            "enum": ["create", "read", "update", "delete", "list", "custom"],
            "description": "Action to perform on the model.",
        },
        "id": {
            "description": "Resource ID for read, update, or delete actions.",
        },
        "command": {
            "type": "string",
            "description": "Command name when action is 'custom' (e.g. 'generate', 'export').",
        },
        "payload": {
            "type": "object",
            "description": "Data for create, update, or custom actions.",
        },
    },
    "required": ["model", "action"],
}


class ExecuteIntentTool:
    """
    The primary harness tool. Lets the model execute any registered intent.

    Dispatches through the IntentService directly (not via HTTP), reusing
    the user/db/context from the ChatEngine. The IntentRuntime pipeline
    applies if the router was configured with one.
    """

    def __init__(self, tool_name: str = "execute_intent") -> None:
        self._name = tool_name

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return (
            "Execute an action in the system. "
            "Use ToolSearchTool first to discover available models and actions."
        )

    @property
    def input_schema(self) -> dict[str, Any]:
        return _INTENT_SCHEMA

    @property
    def is_read_only(self) -> bool:
        return False

    def to_litellm_schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema,
            },
        }

    async def call(
        self,
        input: dict[str, Any],
        engine: "ChatEngine",
    ) -> ExecutionResult:
        from intent_api.schemas import IntentRequest
        from intent_api.providers.errors import (
            PermissionDenied,
            PlanUpgradeRequired,
            QuotaExceeded,
        )
        from intent_api_harness.catalog import _crud_display
        from intent_api_harness.state import HarnessMode

        model = input.get("model", "")
        action = input.get("action", "")
        command = input.get("command")
        resource_id = input.get("id")
        payload = input.get("payload")

        # Derive intent_id and display label for correlation + UI
        intent_id = f"{model}.{command or action}"
        service = engine.registry.get(model)
        display = _resolve_display(service, model, action, command)

        # Plan mode soft-block: only read/list allowed during planning
        if engine._mode == HarnessMode.PLAN and action not in ("read", "list"):
            return ExecutionResult(
                status="error",
                message=(
                    f"Plan mode is active. Cannot execute '{action}' action on '{model}'. "
                    "Only read and list actions are allowed during planning. "
                    "Use ExitPlanMode when you are ready to execute your plan."
                ),
                display=f"Blocked: {action} not allowed in plan mode",
                intent_id=intent_id,
            )

        # Verification mode soft-block: only read/list allowed during verification
        if engine._verification_mode and action not in ("read", "list"):
            return ExecutionResult(
                status="error",
                message=(
                    f"Verification mode is active. Cannot execute '{action}' action on '{model}'. "
                    "Only read and list actions are allowed during verification."
                ),
                display=f"Blocked: {action} not allowed in verification mode",
                intent_id=intent_id,
            )

        if not service:
            return ExecutionResult(
                status="error",
                message=f"No service registered for model '{model}'. Use ToolSearchTool to see available models.",
                intent_id=intent_id,
                display=display,
            )

        if not engine.registry.is_chat_exposed(model):
            return ExecutionResult(
                status="denied",
                message=f"Model '{model}' is not available via chat.",
                intent_id=intent_id,
                display=display,
            )

        intent_req = IntentRequest(
            model=model,
            action=action,
            id=resource_id,
            command=command,
            payload=payload,
            context=engine.intent_context,
        )

        try:
            from intent_api.router import _dispatch

            result = await _dispatch(
                service=service,
                intent=intent_req,
                db=engine.db,
                user=engine.user,
                context=engine.intent_context,
                runtime=engine._runtime,
                model_name=model,
                surface="harness",
            )
            return ExecutionResult(
                status="success",
                data=result,
                intent_id=intent_id,
                display=display,
            )

        except PermissionDenied as e:
            return ExecutionResult(
                status="denied",
                message=str(e) or f"You don't have permission to {action} {model}.",
                intent_id=intent_id,
                display=display,
            )
        except PlanUpgradeRequired as e:
            return ExecutionResult(
                status="upgrade_required",
                message=str(e),
                intent_id=intent_id,
                display=display,
            )
        except QuotaExceeded as e:
            return ExecutionResult(
                status="quota_exceeded",
                message=str(e),
                intent_id=intent_id,
                display=display,
            )
        except Exception as e:
            logger.warning(
                "execute_intent error",
                extra={"intent_id": intent_id, "error": str(e)},
            )
            return ExecutionResult(
                status="error",
                message=str(e)[:2000],
                intent_id=intent_id,
                display=display,
            )


def _resolve_display(service: Any, model: str, action: str, command: str | None) -> str:
    """Derive a human-readable action label from service metadata."""
    if command and service:
        registered = getattr(service.__class__, "_registered_commands", {}) or {}
        cmd_info = registered.get(command, {})
        if cmd_info.get("display"):
            return cmd_info["display"]

    prefix = None
    if service:
        prefix = getattr(service.__class__, "__display_prefix__", None)
    prefix = prefix or model

    from intent_api_harness.catalog import _crud_display
    return _crud_display(action, prefix)
