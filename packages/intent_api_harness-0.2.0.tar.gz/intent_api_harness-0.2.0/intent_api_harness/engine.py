"""
ChatEngine — conversation-level orchestrator.

One instance per conversation. Owns the user session, database connection,
registry reference, and model provider. Exposes submit_message() as an
async generator that yields typed SSE events.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, AsyncGenerator
from uuid import uuid4

from pydantic import BaseModel, Field

from intent_api_harness.catalog import IntentCatalog
from intent_api_harness.events import (
    HarnessEvent,
    SessionEndEvent,
    SessionStartEvent,
    TokenUsage,
)
from intent_api_harness.messages import UserMessage
from intent_api_harness.model_provider import ModelProvider
from intent_api_harness.prompts.system import SystemPromptBuilder
from intent_api_harness.state import CompactTracking, HarnessMode, LoopState, ToolSummary
from intent_api_harness.tools.intent_tool import ExecuteIntentTool
from intent_api_harness.tools.search_tool import ToolSearchTool

if TYPE_CHECKING:
    from intent_api.registry import ServiceRegistry
    from intent_api.schemas import IntentContext
    from intent_api_harness.compaction.provider import CompactionProvider
    from intent_api_harness.memory.provider import Memory, MemoryProvider

logger = logging.getLogger("intent_api_harness")


class ChatEngineConfig(BaseModel):
    model: str = "anthropic/claude-sonnet-4-20250514"
    max_turns: int = 50
    max_budget_usd: float | None = None
    context_window: int = 200_000
    max_output_tokens: int = 16_000
    custom_instructions: str | None = None
    app_name: str = "Application"
    # Planning capabilities — both default True.
    # Set False for simple Q&A bots where the extra round-trips aren't needed.
    enable_thinking: bool = True
    enable_todos: bool = True
    # Plan mode — allows model to explore before executing write actions
    enable_plan_mode: bool = True
    # Parallel tool execution — max concurrent read-only tool calls per batch
    max_tool_concurrency: int = 5


class ChatEngine:
    """
    Stateful conversation engine. One instance per active session.

    The user, intent_context, and registry are stable across the session.
    The db dependency is refreshed on every submit_message() call (HTTP
    sessions don't persist across requests).
    """

    def __init__(
        self,
        config: ChatEngineConfig,
        user: Any,
        intent_context: "IntentContext",
        registry: "ServiceRegistry",
        model_provider: ModelProvider,
        compaction_provider: "CompactionProvider | None" = None,
        memory_provider: "MemoryProvider | None" = None,
        intent_tool_name: str = "execute_intent",
        enable_spawn: bool = False,
        hooks: "list[Any] | None" = None,
        runtime: Any = None,
        is_subagent: bool = False,
        verification_mode: bool = False,
    ) -> None:
        self.session_id = str(uuid4())
        self.config = config
        self.user = user
        self.intent_context = intent_context
        self.registry = registry
        self.model_provider = model_provider
        self.compaction_provider = compaction_provider
        self.memory_provider = memory_provider
        self.hooks: list[Any] = hooks or []
        self._runtime = runtime

        # Sub-agent / verification flags
        self.is_subagent: bool = is_subagent
        self._verification_mode: bool = verification_mode

        # db is set fresh on each submit_message call
        self.db: Any = None

        self.catalog = IntentCatalog.from_registry(registry)
        self._intent_tool_name = intent_tool_name
        self._enable_spawn = enable_spawn

        # Base tools (mode-independent, built once)
        self._base_tools: list[Any] = []
        if config.enable_thinking:
            from intent_api_harness.tools.think_tool import ThinkTool
            self._base_tools.append(ThinkTool())
        if config.enable_todos and not is_subagent:
            from intent_api_harness.tools.todo_tool import TodoWriteTool
            self._base_tools.append(TodoWriteTool(session_id=self.session_id))
        self._base_tools.append(ExecuteIntentTool(tool_name=intent_tool_name))
        self._base_tools.append(ToolSearchTool())

        # tools and tool_schemas are rebuilt dynamically per mode via
        # _get_active_tool_schemas() — this initial set covers execute mode
        self.tools = list(self._base_tools)
        if enable_spawn and not is_subagent:
            from intent_api_harness.tools.spawn_tool import SpawnTaskTool
            self.tools.append(SpawnTaskTool())
        if config.enable_plan_mode and not is_subagent:
            from intent_api_harness.tools.plan_mode_tool import EnterPlanModeTool
            self.tools.append(EnterPlanModeTool())
        self.tool_schemas = [t.to_litellm_schema() for t in self.tools]

        self._prompt_builder = SystemPromptBuilder()
        self.system_prompt: str = ""  # built on first submit_message

        self.messages: list[Any] = []
        self.total_cost_usd: float = 0.0
        self.total_usage = TokenUsage()
        self._session_started = False

        # Persisted across submit_message calls — loop state that must survive
        # HTTP request boundaries (each request creates a new LoopState, but
        # these fields are carried forward so they accumulate correctly).
        self._compact_tracking = CompactTracking()
        self._pending_tool_summaries: list[ToolSummary] = []
        self._last_compaction_summary: str | None = None

        # Plan mode state — persisted across HTTP calls, synced to/from LoopState
        self._mode: HarnessMode = HarnessMode.EXECUTE
        self._pre_plan_mode: HarnessMode | None = None
        self._needs_plan_attachment: bool = False

        # Abort support
        self._aborted: bool = False

    def abort(self) -> None:
        """Signal the loop to stop after the current iteration."""
        self._aborted = True

    def _get_active_tool_schemas(self, mode: HarnessMode) -> list[dict]:
        """
        Return the tool schemas for the current mode.

        Called at the top of each loop iteration so the model always receives
        the correct tool set based on current harness state.

        Execute mode: Think, TodoWrite, execute_intent, ToolSearchTool,
                      EnterPlanMode (if enabled), spawn_task (if enabled)
        Plan mode:    Think, TodoWrite, execute_intent, ToolSearchTool,
                      ExitPlanMode (instead of Enter)
        """
        tools: list[Any] = list(self._base_tools)

        if mode == HarnessMode.PLAN:
            from intent_api_harness.tools.plan_mode_tool import ExitPlanModeTool
            tools.append(ExitPlanModeTool())
        else:
            if self._enable_spawn and not self.is_subagent:
                from intent_api_harness.tools.spawn_tool import SpawnTaskTool
                tools.append(SpawnTaskTool())
            if self.config.enable_plan_mode and not self.is_subagent:
                from intent_api_harness.tools.plan_mode_tool import EnterPlanModeTool
                tools.append(EnterPlanModeTool())

        # Update self.tools for helpers that look up tools by name
        self.tools = tools
        return [t.to_litellm_schema() for t in tools]

    def _build_system_prompt(self, memory_summary: str | None = None) -> str:
        return self._prompt_builder.build(
            app_name=self.config.app_name,
            catalog=self.catalog,
            custom_instructions=self.config.custom_instructions,
            memory=memory_summary,
            enable_thinking=self.config.enable_thinking,
            enable_todos=self.config.enable_todos,
        )

    async def submit_message(
        self,
        content: str,
        db: Any = None,
    ) -> AsyncGenerator[HarnessEvent, None]:
        """
        Process a user message and yield typed SSE events.

        db is accepted here (not at construction time) so each HTTP request
        gets a fresh database session rather than a stale one from a prior
        request.
        """
        from intent_api_harness.loop import query_loop, TerminalReason

        # Refresh db on every call
        self.db = db
        self._aborted = False

        # Load memory on first message
        memory_summary: str | None = None
        if self.memory_provider and not self._session_started:
            user_id = _extract_user_id(self.user)
            team_id = _extract_team_id(self.intent_context)
            memory = await self.memory_provider.load(user_id, team_id)
            if memory:
                memory_summary = memory.summary

        # Build / rebuild system prompt
        self.system_prompt = self._build_system_prompt(memory_summary)

        # Append user message
        self.messages.append(UserMessage(content=content))

        # Emit session start on first call
        if not self._session_started:
            self._session_started = True
            yield SessionStartEvent(
                session_id=self.session_id,
                model=self.config.model,
                tools=[t.name for t in self.tools],
            )
            if self.hooks:
                from intent_api_harness.hooks import fire_hooks, HookEvent
                await fire_hooks(self.hooks, HookEvent.SESSION_START, {
                    "session_id": self.session_id,
                    "model": self.config.model,
                    "user_id": _extract_user_id(self.user),
                })

        # Run the loop — initialize state from engine's persisted tracking fields
        # so compaction circuit breaker and tool summaries survive across HTTP calls
        state = LoopState(
            messages=self.messages,  # same list object — appends are shared
            compact_tracking=self._compact_tracking.model_copy(),
            pending_tool_summaries=list(self._pending_tool_summaries),
            # Mode fields — persisted on engine, passed in for loop-local access
            mode=self._mode,
            pre_plan_mode=self._pre_plan_mode,
            needs_plan_attachment=self._needs_plan_attachment,
        )
        terminal_reason = TerminalReason.SUCCESS

        async for event in query_loop(state=state, engine=self):
            yield event

        # Sync persisted fields back from state after loop completes
        self._compact_tracking = state.compact_tracking
        self._pending_tool_summaries = state.pending_tool_summaries
        # Sync message list back (Pydantic may have copied it; compaction replaces it)
        self.messages = state.messages
        # Sync mode fields — tools may have mutated engine._mode directly;
        # state.mode reflects the canonical value at loop end
        self._mode = engine_mode_after_loop = self._mode  # engine._mode is authoritative

        # Update state.token_count on engine for observability
        from intent_api_harness.utils.token_counter import estimate_token_count
        state.token_count = estimate_token_count(self.messages)

        # Extract terminal reason from state after loop
        if self._aborted:
            terminal_reason = TerminalReason.ABORT
        elif state.turn_count >= self.config.max_turns:
            terminal_reason = TerminalReason.MAX_TURNS
        elif self.config.max_budget_usd and self.total_cost_usd >= self.config.max_budget_usd:
            terminal_reason = TerminalReason.MAX_BUDGET

        # Save memory after each stream call
        if self.memory_provider:
            await self._save_memory()

        yield SessionEndEvent(
            session_id=self.session_id,
            reason=terminal_reason.value,
            turn_count=state.turn_count,
            total_cost_usd=self.total_cost_usd or None,
            usage=self.total_usage if self.total_usage.total_tokens > 0 else None,
        )
        if self.hooks:
            from intent_api_harness.hooks import fire_hooks, HookEvent
            await fire_hooks(self.hooks, HookEvent.SESSION_END, {
                "session_id": self.session_id,
                "reason": terminal_reason.value,
                "turn_count": state.turn_count,
                "total_cost_usd": self.total_cost_usd,
            })

    async def _save_memory(self) -> None:
        """
        Persist memory after each session message.

        Uses the most recent compaction summary (set by query_loop when compaction
        fires) or preserves whatever summary was loaded at session start.
        """
        from intent_api_harness.memory.provider import Memory
        from datetime import datetime, timezone

        try:
            user_id = _extract_user_id(self.user)
            team_id = _extract_team_id(self.intent_context)

            # Load existing memory to preserve key_facts and session_count
            existing = await self.memory_provider.load(user_id, team_id)

            memory = Memory(
                user_id=user_id,
                team_id=team_id,
                summary=self._last_compaction_summary or (existing.summary if existing else None),
                key_facts=existing.key_facts if existing else [],
                last_updated=datetime.now(tz=timezone.utc),
                session_count=(existing.session_count if existing else 0) + 1,
            )
            await self.memory_provider.save(memory)
        except Exception as e:
            logger.warning("Failed to save memory", extra={"error": str(e)})


# ── Helpers ───────────────────────────────────────────────────────────────────


def _extract_user_id(user: Any) -> str:
    """Extract a stable user ID string from a dict or object user."""
    if isinstance(user, dict):
        return str(user.get("id", user))
    return str(getattr(user, "id", user))


def _extract_team_id(intent_context: Any) -> str | None:
    """Extract team_id from an IntentContext (or any object with team_id)."""
    val = getattr(intent_context, "team_id", None)
    return str(val) if val else None
