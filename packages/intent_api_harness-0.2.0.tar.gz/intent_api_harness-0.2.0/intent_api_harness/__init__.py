"""
intent-api-harness — AI agent loop for Intent API applications.

Add AI chat to any Intent API SaaS by registering one additional service.

Usage:
    from intent_api import IntentRouter
    from intent_api_harness import ChatService, LiteLLMProvider, ChatEngineConfig

    model_provider = LiteLLMProvider(model="anthropic/claude-sonnet-4-20250514")

    chat_config = ChatEngineConfig(
        max_turns=30,
        app_name="My App",
        custom_instructions="You help users manage their content.",
    )

    router = IntentRouter(runtime=runtime, debug=settings.is_dev)
    router.register("Brand", BrandService())
    router.register("Chat", ChatService(model_provider=model_provider, config=chat_config))

    # Chat is now available at:
    # POST /api/intent { "model": "Chat", "action": "custom", "command": "stream",
    #                    "payload": { "message": "...", "session_id": "..." } }
"""

from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import (
    HarnessEvent,
    SessionStartEvent,
    ThinkingDeltaEvent,
    TextDeltaEvent,
    ToolStartEvent,
    ToolResultEvent,
    CompactEvent,
    ErrorEvent,
    ModeChangeEvent,
    SessionEndEvent,
    TokenUsage,
    IntentSummary,
)
from intent_api_harness.messages import (
    Message,
    UserMessage,
    AssistantMessage,
    ToolResultMessage,
    SystemMessage,
    CompactBoundaryMessage,
    ToolCall,
    ExecutionResult,
    MessageRole,
)
from intent_api_harness.model_provider import ModelProvider, ModelResponse, StreamChunk
from intent_api_harness.providers.litellm_provider import LiteLLMProvider
from intent_api_harness.service import ChatService
from intent_api_harness.catalog import IntentCatalog, CatalogEntry
from intent_api_harness.state import LoopState, CompactTracking, ToolSummary
from intent_api_harness.compaction.provider import CompactionProvider, CompactionResult
from intent_api_harness.compaction.simple import SimpleCompactionProvider
from intent_api_harness.memory.provider import MemoryProvider, Memory
from intent_api_harness.memory.simple import SimpleMemoryProvider
from intent_api_harness.tools.base import HarnessTool
from intent_api_harness.tools.think_tool import ThinkTool
from intent_api_harness.tools.todo_tool import TodoWriteTool, TodoItem, TodoStatus
from intent_api_harness.tools.plan_mode_tool import EnterPlanModeTool, ExitPlanModeTool
from intent_api_harness.tools.spawn_tool import SpawnTaskTool
from intent_api_harness.hooks import HarnessHook, HookEvent, fire_hooks
from intent_api_harness.compaction.cloud import IntentAPICloudCompactionProvider
from intent_api_harness.compaction.cloud import IntentAPICloudMemoryProvider

__version__ = "0.2.0"

__all__ = [
    # Engine
    "ChatEngine",
    "ChatEngineConfig",
    # Service
    "ChatService",
    # Model provider
    "ModelProvider",
    "ModelResponse",
    "StreamChunk",
    "LiteLLMProvider",
    # Messages
    "Message",
    "UserMessage",
    "AssistantMessage",
    "ToolResultMessage",
    "SystemMessage",
    "CompactBoundaryMessage",
    "ToolCall",
    "ExecutionResult",
    "MessageRole",
    # Events
    "HarnessEvent",
    "SessionStartEvent",
    "ThinkingDeltaEvent",
    "TextDeltaEvent",
    "ToolStartEvent",
    "ToolResultEvent",
    "CompactEvent",
    "ErrorEvent",
    "ModeChangeEvent",
    "SessionEndEvent",
    "TokenUsage",
    "IntentSummary",
    # Catalog
    "IntentCatalog",
    "CatalogEntry",
    # State
    "LoopState",
    "CompactTracking",
    "ToolSummary",
    # Compaction
    "CompactionProvider",
    "CompactionResult",
    "SimpleCompactionProvider",
    # Memory
    "MemoryProvider",
    "Memory",
    "SimpleMemoryProvider",
    # Tools
    "HarnessTool",
    "ThinkTool",
    "TodoWriteTool",
    "TodoItem",
    "TodoStatus",
    "EnterPlanModeTool",
    "ExitPlanModeTool",
    "SpawnTaskTool",
    # Hooks
    "HarnessHook",
    "HookEvent",
    "fire_hooks",
    # Cloud providers
    "IntentAPICloudCompactionProvider",
    "IntentAPICloudMemoryProvider",
]
