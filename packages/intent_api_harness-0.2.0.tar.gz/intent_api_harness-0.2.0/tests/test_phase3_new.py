"""
P3.W8 — Tests for plan mode, verification, and parallel execution.

34 tests covering:
  Plan mode tools (10)
  Plan mode in loop (8)
  Verification (7)
  Parallel execution (9)
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from intent_api import IntentService
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.messages import ExecutionResult, ToolCall
from intent_api_harness.model_provider import StreamChunk
from intent_api_harness.state import HarnessMode, LoopState
from intent_api_harness.tools.plan_mode_tool import EnterPlanModeTool, ExitPlanModeTool
from intent_api_harness.loop import _partition_tool_calls
from intent_api_harness.tools.base import find_tool


# ── Fixtures ──────────────────────────────────────────────────────────────────


class DummyService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return []

    async def read(self, *, db, user, context, id):
        return {"id": id}

    async def create(self, *, db, user, context, payload):
        return {"created": True}


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Dummy", DummyService())
    return registry


def _make_context() -> IntentContext:
    return IntentContext(type="user")


def _make_engine(**kwargs) -> ChatEngine:
    config = ChatEngineConfig(app_name="TestApp", **kwargs)

    class MockProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            yield StreamChunk(type="text", text="Done.")

        async def complete(self, *a, **kw): raise NotImplementedError
        async def extract(self, *a, **kw): raise NotImplementedError

    return ChatEngine(
        config=config,
        user={"id": "u1"},
        intent_context=_make_context(),
        registry=_make_registry(),
        model_provider=MockProvider(),
    )


class ReadOnlyTool:
    name = "ReadOnlyTool"
    is_read_only = True

    def to_litellm_schema(self):
        return {"type": "function", "function": {"name": self.name, "description": "", "parameters": {"type": "object", "properties": {}}}}

    async def call(self, input, engine):
        return ExecutionResult(status="success")


class WriteTool:
    name = "WriteTool"
    is_read_only = False

    def to_litellm_schema(self):
        return {"type": "function", "function": {"name": self.name, "description": "", "parameters": {"type": "object", "properties": {}}}}

    async def call(self, input, engine):
        return ExecutionResult(status="success")


# ── Plan mode tools ───────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_enter_plan_mode_transitions_mode():
    engine = _make_engine()
    tool = EnterPlanModeTool()
    result = await tool.call({}, engine)
    assert result.status == "success"
    assert engine._mode == HarnessMode.PLAN


@pytest.mark.asyncio
async def test_enter_plan_mode_stores_pre_plan_mode():
    engine = _make_engine()
    assert engine._mode == HarnessMode.EXECUTE
    await EnterPlanModeTool().call({}, engine)
    assert engine._pre_plan_mode == HarnessMode.EXECUTE


@pytest.mark.asyncio
async def test_enter_plan_mode_blocks_subagents():
    engine = _make_engine()
    engine.is_subagent = True
    result = await EnterPlanModeTool().call({}, engine)
    assert result.status == "error"
    assert engine._mode == HarnessMode.EXECUTE  # unchanged


@pytest.mark.asyncio
async def test_enter_plan_mode_errors_when_already_in_plan():
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    result = await EnterPlanModeTool().call({}, engine)
    assert result.status == "error"
    assert "already" in result.message.lower()


@pytest.mark.asyncio
async def test_exit_plan_mode_restores_pre_plan_mode():
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    engine._pre_plan_mode = HarnessMode.EXECUTE
    result = await ExitPlanModeTool().call({}, engine)
    assert result.status == "success"
    assert engine._mode == HarnessMode.EXECUTE


@pytest.mark.asyncio
async def test_exit_plan_mode_errors_when_not_in_plan():
    engine = _make_engine()
    result = await ExitPlanModeTool().call({}, engine)
    assert result.status == "error"
    assert "not in plan mode" in result.message.lower()


@pytest.mark.asyncio
async def test_exit_plan_mode_clears_pre_plan_mode():
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    engine._pre_plan_mode = HarnessMode.EXECUTE
    await ExitPlanModeTool().call({}, engine)
    assert engine._pre_plan_mode is None


@pytest.mark.asyncio
async def test_exit_plan_mode_restores_execute_when_pre_plan_none():
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    engine._pre_plan_mode = None  # no stored mode
    result = await ExitPlanModeTool().call({}, engine)
    assert result.status == "success"
    assert engine._mode == HarnessMode.EXECUTE


def test_enter_plan_mode_available_in_execute_mode_tool_list():
    engine = _make_engine(enable_plan_mode=True)
    schemas = engine._get_active_tool_schemas(HarnessMode.EXECUTE)
    names = [s["function"]["name"] for s in schemas]
    assert "EnterPlanMode" in names
    assert "ExitPlanMode" not in names


def test_exit_plan_mode_available_in_plan_mode_tool_list():
    engine = _make_engine(enable_plan_mode=True)
    schemas = engine._get_active_tool_schemas(HarnessMode.PLAN)
    names = [s["function"]["name"] for s in schemas]
    assert "ExitPlanMode" in names
    assert "EnterPlanMode" not in names


# ── Plan mode in loop ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_execute_intent_allows_read_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "read", "id": "1"}, engine)
    assert result.status == "success"


@pytest.mark.asyncio
async def test_execute_intent_allows_list_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "list"}, engine)
    assert result.status == "success"


@pytest.mark.asyncio
async def test_execute_intent_blocks_create_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "create", "payload": {}}, engine)
    assert result.status == "error"
    assert "plan mode" in result.message.lower()


@pytest.mark.asyncio
async def test_execute_intent_blocks_update_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "update", "id": "1", "payload": {}}, engine)
    assert result.status == "error"
    assert "plan mode" in result.message.lower()


@pytest.mark.asyncio
async def test_execute_intent_blocks_delete_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "delete", "id": "1"}, engine)
    assert result.status == "error"


@pytest.mark.asyncio
async def test_execute_intent_blocks_custom_in_plan_mode():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "custom", "command": "generate"}, engine)
    assert result.status == "error"


def test_mode_persists_across_submit_message_calls():
    """Mode set by tools (engine._mode) persists to the next submit_message."""
    engine = _make_engine()
    engine._mode = HarnessMode.PLAN
    engine._pre_plan_mode = HarnessMode.EXECUTE
    # Mode should still be PLAN on next call
    assert engine._mode == HarnessMode.PLAN


def test_needs_plan_attachment_set_on_enter():
    """EnterPlanMode sets _needs_plan_attachment = True."""
    engine = _make_engine()

    async def _run():
        await EnterPlanModeTool().call({}, engine)

    asyncio.get_event_loop().run_until_complete(_run())
    assert engine._needs_plan_attachment is True


# ── Verification ───────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_spawn_task_verify_mode_creates_read_only_subagent():
    from intent_api_harness.tools.spawn_tool import SpawnTaskTool

    subagent_verification_mode = None

    class CapturingProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            nonlocal subagent_verification_mode
            # We can't easily check this from outside, but we can check via engine flags
            yield StreamChunk(type="text", text="PASS: All work verified.")

        async def complete(self, *a, **kw): raise NotImplementedError
        async def extract(self, *a, **kw): raise NotImplementedError

    engine = _make_engine()
    engine.model_provider = CapturingProvider()

    tool = SpawnTaskTool()
    result = await tool.call({"task": "Verify that Brand was created.", "mode": "verify"}, engine)

    assert result.status == "success"
    assert result.data["mode"] == "verify"
    assert "PASS" in result.message


@pytest.mark.asyncio
async def test_spawn_task_verify_blocks_writes():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._verification_mode = True
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "create", "payload": {}}, engine)
    assert result.status == "error"
    assert "verification mode" in result.message.lower()


@pytest.mark.asyncio
async def test_spawn_task_verify_allows_reads():
    from intent_api_harness.tools.intent_tool import ExecuteIntentTool
    engine = _make_engine()
    engine._verification_mode = True
    tool = ExecuteIntentTool()
    result = await tool.call({"model": "Dummy", "action": "list"}, engine)
    assert result.status == "success"


def test_spawn_task_verify_mode_display():
    from intent_api_harness.tools.spawn_tool import SpawnTaskTool as _SpawnTaskTool
    tool = _SpawnTaskTool()
    assert "mode" in tool.input_schema["properties"]
    # mode field has "verify" option
    assert "verify" in tool.input_schema["properties"]["mode"]["enum"]


def test_todo_write_3_plus_completion_nudge_references_spawn():
    from intent_api_harness.tools.todo_tool import _build_response_message, TodoItem, TodoStatus
    todos = [
        TodoItem(content="T1", status=TodoStatus.COMPLETED, active_form="Doing T1"),
        TodoItem(content="T2", status=TodoStatus.COMPLETED, active_form="Doing T2"),
        TodoItem(content="T3", status=TodoStatus.COMPLETED, active_form="Doing T3"),
    ]
    msg = _build_response_message(todos, all_done=True)
    assert "spawn_task" in msg.lower() or "verification" in msg.lower() or "verify" in msg.lower()


def test_todo_write_fewer_than_3_no_verification_nudge():
    from intent_api_harness.tools.todo_tool import _build_response_message, TodoItem, TodoStatus
    todos = [
        TodoItem(content="T1", status=TodoStatus.COMPLETED, active_form="Doing T1"),
        TodoItem(content="T2", status=TodoStatus.COMPLETED, active_form="Doing T2"),
    ]
    msg = _build_response_message(todos, all_done=True)
    assert "NOTE:" not in msg


def test_verification_prompt_contains_verdict_format():
    from intent_api_harness.prompts.verification import VERIFICATION_PROMPT
    assert "PASS" in VERIFICATION_PROMPT
    assert "FAIL" in VERIFICATION_PROMPT
    assert "read" in VERIFICATION_PROMPT.lower()


# ── Parallel execution ─────────────────────────────────────────────────────────


def _tc(name: str, tc_id: str = "tc1") -> ToolCall:
    return ToolCall(id=tc_id, tool_name=name, input={})


def test_single_tool_single_batch():
    tools = [WriteTool()]
    batches = _partition_tool_calls([_tc("WriteTool", "tc1")], tools)
    assert len(batches) == 1
    assert not batches[0].is_concurrent


def test_two_readonly_form_concurrent_batch():
    tools = [ReadOnlyTool()]
    batches = _partition_tool_calls(
        [_tc("ReadOnlyTool", "tc1"), _tc("ReadOnlyTool", "tc2")],
        tools,
    )
    assert len(batches) == 1
    assert batches[0].is_concurrent
    assert len(batches[0].calls) == 2


def test_write_breaks_concurrent_batch():
    tools = [ReadOnlyTool(), WriteTool()]
    batches = _partition_tool_calls(
        [_tc("ReadOnlyTool", "tc1"), _tc("ReadOnlyTool", "tc2"), _tc("WriteTool", "tc3"), _tc("ReadOnlyTool", "tc4")],
        tools,
    )
    # [read, read] concurrent | [write] sequential | [read] as single-item batch
    assert len(batches) == 3
    assert batches[0].is_concurrent
    assert len(batches[0].calls) == 2
    assert not batches[1].is_concurrent
    assert batches[1].calls[0].tool_name == "WriteTool"
    # Single read-only: partition sets is_concurrent=True (can run concurrently)
    # but loop only runs gather when len > 1, so it's effectively sequential
    assert len(batches[2].calls) == 1


def test_results_in_original_call_order():
    tools = [ReadOnlyTool(), WriteTool()]
    batches = _partition_tool_calls(
        [_tc("ReadOnlyTool", "A"), _tc("ReadOnlyTool", "B")],
        tools,
    )
    assert batches[0].calls[0].id == "A"
    assert batches[0].calls[1].id == "B"


def test_unknown_tool_is_not_concurrent():
    """Unknown tools (not in tools list) default to sequential."""
    tools: list[Any] = []
    batches = _partition_tool_calls(
        [_tc("UnknownTool", "tc1"), _tc("UnknownTool", "tc2")],
        tools,
    )
    # Unknown → is_read_only = False → sequential
    assert len(batches) == 2
    assert not batches[0].is_concurrent
    assert not batches[1].is_concurrent


@pytest.mark.asyncio
async def test_concurrent_tools_complete_faster():
    """Two concurrent read-only calls via asyncio.gather should be faster than sequential."""
    import time

    delay = 0.05  # 50ms per call
    call_count = 0

    class SlowReadProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                from intent_api_harness.messages import ToolCall as TC
                yield StreamChunk(type="tool_call_start", tool_call_id="tc1", tool_call_name="ReadOnlyTool")
                yield StreamChunk(type="tool_call_end", tool_call=TC(id="tc1", tool_name="ReadOnlyTool", input={}))
                yield StreamChunk(type="tool_call_start", tool_call_id="tc2", tool_call_name="ReadOnlyTool")
                yield StreamChunk(type="tool_call_end", tool_call=TC(id="tc2", tool_name="ReadOnlyTool", input={}))
            else:
                yield StreamChunk(type="text", text="Done.")

        async def complete(self, *a, **kw): raise NotImplementedError
        async def extract(self, *a, **kw): raise NotImplementedError

    class SlowReadOnlyTool:
        name = "ReadOnlyTool"
        is_read_only = True

        def to_litellm_schema(self):
            return {"type": "function", "function": {"name": self.name, "description": "", "parameters": {"type": "object", "properties": {}}}}

        async def call(self, input, engine):
            await asyncio.sleep(delay)
            return ExecutionResult(status="success")

    engine = _make_engine(max_tool_concurrency=5, enable_thinking=False, enable_todos=False, enable_plan_mode=False)
    engine.model_provider = SlowReadProvider()
    engine._base_tools = [SlowReadOnlyTool()]
    engine.tools = [SlowReadOnlyTool()]

    start = time.monotonic()
    events = []
    async for event in engine.submit_message("test"):
        events.append(event)
    elapsed = time.monotonic() - start

    # Two 50ms concurrent calls should finish in ~50ms, not ~100ms
    # Allow generous overhead buffer (1s)
    assert elapsed < delay * 2 + 1.0, f"Expected ~{delay}s, got {elapsed:.2f}s"


@pytest.mark.asyncio
async def test_mode_change_event_emitted_on_plan_entry():
    """ModeChangeEvent should be yielded when a tool changes the mode."""
    from intent_api_harness.events import ModeChangeEvent

    enter_call_count = 0

    class EnterPlanProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            nonlocal enter_call_count
            enter_call_count += 1
            if enter_call_count == 1:
                from intent_api_harness.messages import ToolCall as TC
                yield StreamChunk(type="tool_call_start", tool_call_id="tc1", tool_call_name="EnterPlanMode")
                yield StreamChunk(type="tool_call_end", tool_call=TC(id="tc1", tool_name="EnterPlanMode", input={}))
            else:
                yield StreamChunk(type="text", text="Now in plan mode.")

        async def complete(self, *a, **kw): raise NotImplementedError
        async def extract(self, *a, **kw): raise NotImplementedError

    engine = _make_engine(enable_plan_mode=True)
    engine.model_provider = EnterPlanProvider()

    events = []
    async for event in engine.submit_message("enter plan mode", db=None):
        events.append(event)

    mode_changes = [e for e in events if isinstance(e, ModeChangeEvent)]
    assert len(mode_changes) >= 1
    assert mode_changes[0].mode == "plan"
    assert mode_changes[0].previous_mode == "execute"
