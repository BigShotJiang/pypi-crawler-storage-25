"""
Phase 2 tests — token tracking, compaction, memory.

All tests use MockModelProvider (no live API calls).
Compaction tests use a very small context_window to force compaction
without needing a real model.
"""

from __future__ import annotations

import asyncio
from typing import Any
from uuid import uuid4

import pytest

from intent_api import IntentService, custom_action
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.compaction.provider import CompactionResult
from intent_api_harness.compaction.simple import SimpleCompactionProvider
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import CompactEvent, SessionEndEvent, TextDeltaEvent
from intent_api_harness.memory.provider import Memory
from intent_api_harness.memory.simple import SimpleMemoryProvider
from intent_api_harness.messages import (
    AssistantMessage,
    CompactBoundaryMessage,
    UserMessage,
)
from intent_api_harness.model_provider import StreamChunk
from intent_api_harness.state import CompactTracking, LoopState
from intent_api_harness.utils.token_counter import (
    estimate_token_count,
    should_compact,
)


# ── Shared fixtures ───────────────────────────────────────────────────────────


class NoteService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return [{"id": str(i), "text": f"Note {i}"} for i in range(5)]


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Note", NoteService())
    return registry


def _make_context() -> IntentContext:
    return IntentContext(type="user", team_id="team1")


class MockProvider:
    """Simple mock that always returns a fixed text response."""

    def __init__(self, responses: list[str] | None = None):
        self._responses = responses or ["Done."]
        self._call_count = 0

    async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
        idx = min(self._call_count, len(self._responses) - 1)
        text = self._responses[idx]
        self._call_count += 1
        yield StreamChunk(type="text", text=text)

    async def complete(self, *a, **kw):
        raise NotImplementedError

    async def extract(self, messages, response_model, system_prompt=None):
        # Return a minimal CompactionSummary for tests
        return response_model(
            primary_request="User asked something",
            key_concepts=["Note"],
            actions_taken=["Listed notes"],
            errors_and_fixes=[],
            all_user_messages=["list my notes"],
            pending_tasks=[],
            current_state="Listed 5 notes",
        )


# ── P2.W1 — Token tracking ────────────────────────────────────────────────────


class TestTokenCounter:
    def test_empty_messages(self):
        assert estimate_token_count([]) == 0

    def test_user_message_estimation(self):
        msg = UserMessage(content="a" * 400)  # 400 chars → ~100 tokens
        count = estimate_token_count([msg])
        assert count == 100

    def test_anchors_on_assistant_usage(self):
        """Uses API-reported usage as anchor when available."""
        msgs = [
            UserMessage(content="hello"),
            AssistantMessage(
                content="hi",
                input_tokens=500,
                output_tokens=50,
            ),
        ]
        count = estimate_token_count(msgs)
        # Should use anchor (550) + estimate for any messages after
        assert count == 550

    def test_anchor_plus_tail_estimation(self):
        """Anchor from last AssistantMessage + chars/4 for messages after."""
        msgs = [
            UserMessage(content="hello"),
            AssistantMessage(content="hi", input_tokens=200, output_tokens=20),
            UserMessage(content="a" * 400),  # 100 token tail estimate
        ]
        count = estimate_token_count(msgs)
        assert count == 220 + 100  # 220 anchor + 100 tail

    def test_compact_boundary_not_counted(self):
        """CompactBoundaryMessage has no content, contributes 0 to estimate."""
        msgs = [
            CompactBoundaryMessage(pre_token_count=1000),
            UserMessage(content="a" * 400),
        ]
        count = estimate_token_count(msgs)
        assert count == 100  # only the user message

    def test_should_compact_below_threshold(self):
        assert not should_compact(
            token_count=10_000,
            context_window=200_000,
            max_output_tokens=16_000,
        )

    def test_should_compact_above_threshold(self):
        # threshold = 200_000 - min(16_000, 20_000) - 13_000 = 171_000
        assert should_compact(
            token_count=175_000,
            context_window=200_000,
            max_output_tokens=16_000,
        )

    def test_should_compact_at_boundary(self):
        threshold = 200_000 - 16_000 - 13_000  # = 171_000
        assert not should_compact(threshold - 1, 200_000, 16_000)
        assert should_compact(threshold, 200_000, 16_000)

    def test_small_context_window(self):
        # context_window=10_000, max_output=1_000 → threshold = 10_000-1_000-13_000 = negative
        # should always compact
        assert should_compact(100, 10_000, 1_000)


class TestTokenTrackingInEngine:
    @pytest.mark.asyncio
    async def test_token_count_updates_after_loop(self):
        """Engine's state.token_count is set after submit_message."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
        )

        events = []
        async for event in engine.submit_message("hello", db=None):
            events.append(event)

        # After the loop, messages list has content
        assert len(engine.messages) >= 2  # user + assistant

    @pytest.mark.asyncio
    async def test_compact_tracking_persists_across_calls(self):
        """compact_tracking survives between submit_message calls."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(["Turn 1.", "Turn 2."]),
        )

        # Manually set failures to verify persistence
        engine._compact_tracking.consecutive_failures = 2

        async for _ in engine.submit_message("hello", db=None):
            pass

        # compact_tracking was passed into state and synced back
        assert engine._compact_tracking.consecutive_failures == 2  # no compaction happened

    @pytest.mark.asyncio
    async def test_messages_accumulate_across_calls(self):
        """engine.messages grows with each submit_message call."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(["Turn 1.", "Turn 2."]),
        )

        async for _ in engine.submit_message("first", db=None):
            pass
        after_first = len(engine.messages)

        async for _ in engine.submit_message("second", db=None):
            pass
        after_second = len(engine.messages)

        assert after_second > after_first  # messages accumulated


# ── P2.W2 — Compaction ────────────────────────────────────────────────────────


class MockCompactionProvider:
    """Compaction provider that returns a fixed summary without calling a model."""

    def __init__(self):
        self.was_called = False
        self.received_messages: list = []

    async def compact(self, messages, system_prompt, model_provider, tool_summaries):
        self.was_called = True
        self.received_messages = list(messages)

        boundary = CompactBoundaryMessage(
            pre_token_count=len(messages) * 100,
            post_token_count=200,
            messages_summarized=len(messages),
        )
        summary = UserMessage(content="## Summary\nUser listed notes. 5 notes found.")
        return CompactionResult(
            boundary=boundary,
            summary_messages=[summary],
            pre_token_count=len(messages) * 100,
            post_token_count=200,
            messages_summarized=len(messages),
        )


class TestCompaction:
    @pytest.mark.asyncio
    async def test_compaction_fires_when_over_threshold(self):
        """With a tiny context_window, compaction triggers on the second turn."""
        # Build a message list that exceeds the threshold for a 1000-token window
        # threshold = 1000 - min(100, 20000) - 13000 = negative → always compact
        compaction_provider = MockCompactionProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(
                app_name="Test",
                context_window=1000,   # tiny — threshold is effectively 0
                max_output_tokens=100,
            ),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            compaction_provider=compaction_provider,
        )

        # Pre-populate messages so token estimate exceeds threshold
        engine.messages = [
            UserMessage(content="a" * 400),   # ~100 tokens
            AssistantMessage(content="b" * 400, input_tokens=300, output_tokens=100),
            UserMessage(content="c" * 400),   # ~100 tail tokens
        ]

        events = []
        async for event in engine.submit_message("another message", db=None):
            events.append(event)

        assert compaction_provider.was_called, "Compaction should have fired"

        compact_events = [e for e in events if isinstance(e, CompactEvent)]
        assert len(compact_events) == 1

    @pytest.mark.asyncio
    async def test_compaction_replaces_messages(self):
        """After compaction, messages list is boundary + summary, not the originals."""
        compaction_provider = MockCompactionProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(
                app_name="Test",
                context_window=1000,
                max_output_tokens=100,
            ),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            compaction_provider=compaction_provider,
        )

        engine.messages = [
            UserMessage(content="x" * 400),
            AssistantMessage(content="y" * 400, input_tokens=300, output_tokens=100),
        ]

        async for _ in engine.submit_message("more", db=None):
            pass

        assert compaction_provider.was_called
        # engine.messages should now be the compacted list
        types = [type(m).__name__ for m in engine.messages]
        assert "CompactBoundaryMessage" in types
        assert "UserMessage" in types

    @pytest.mark.asyncio
    async def test_compaction_summary_stored_on_engine(self):
        """engine._last_compaction_summary is set after compaction fires."""
        compaction_provider = MockCompactionProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(
                app_name="Test",
                context_window=1000,
                max_output_tokens=100,
            ),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            compaction_provider=compaction_provider,
        )

        engine.messages = [
            UserMessage(content="x" * 400),
            AssistantMessage(content="y" * 400, input_tokens=300, output_tokens=100),
        ]

        async for _ in engine.submit_message("more", db=None):
            pass

        assert engine._last_compaction_summary is not None
        assert "Summary" in engine._last_compaction_summary

    @pytest.mark.asyncio
    async def test_circuit_breaker_stops_after_3_failures(self):
        """After 3 consecutive compaction failures, compaction stops being attempted."""
        class FailingCompactionProvider:
            call_count = 0

            async def compact(self, messages, system_prompt, model_provider, tool_summaries):
                self.call_count += 1
                raise RuntimeError("compaction broken")

        failing = FailingCompactionProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(
                app_name="Test",
                context_window=1000,
                max_output_tokens=100,
            ),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(["t1", "t2", "t3", "t4", "t5"]),
            compaction_provider=failing,
        )

        # Pre-fill to exceed threshold
        for i in range(5):
            engine.messages.append(UserMessage(content="x" * 400))

        # 4 separate calls — after 3 failures, 4th should skip compaction
        for msg in ["a", "b", "c", "d"]:
            async for _ in engine.submit_message(msg, db=None):
                pass

        # Should have been called exactly 3 times (circuit breaker stops at 3)
        assert failing.call_count == 3, f"Expected 3 calls, got {failing.call_count}"


# ── P2.W3 — Memory ────────────────────────────────────────────────────────────


class TestSimpleMemoryProvider:
    @pytest.mark.asyncio
    async def test_load_returns_none_when_empty(self):
        provider = SimpleMemoryProvider()
        result = await provider.load("user1")
        assert result is None

    @pytest.mark.asyncio
    async def test_save_and_load(self):
        provider = SimpleMemoryProvider()
        memory = Memory(user_id="user1", summary="User likes SEO content")
        await provider.save(memory)

        loaded = await provider.load("user1")
        assert loaded is not None
        assert loaded.summary == "User likes SEO content"

    @pytest.mark.asyncio
    async def test_team_scoped(self):
        provider = SimpleMemoryProvider()
        m1 = Memory(user_id="user1", team_id="teamA", summary="A memory")
        m2 = Memory(user_id="user1", team_id="teamB", summary="B memory")
        await provider.save(m1)
        await provider.save(m2)

        a = await provider.load("user1", "teamA")
        b = await provider.load("user1", "teamB")
        assert a.summary == "A memory"
        assert b.summary == "B memory"

    @pytest.mark.asyncio
    async def test_overwrite_on_save(self):
        provider = SimpleMemoryProvider()
        await provider.save(Memory(user_id="u", summary="old"))
        await provider.save(Memory(user_id="u", summary="new"))
        loaded = await provider.load("u")
        assert loaded.summary == "new"

    @pytest.mark.asyncio
    async def test_concurrent_writes_safe(self):
        """asyncio.Lock prevents races under concurrent saves."""
        provider = SimpleMemoryProvider()

        async def write(i):
            await provider.save(Memory(user_id=f"user{i}", summary=f"summary{i}"))

        await asyncio.gather(*[write(i) for i in range(20)])

        for i in range(20):
            m = await provider.load(f"user{i}")
            assert m.summary == f"summary{i}"


class TestMemoryIntegrationWithEngine:
    @pytest.mark.asyncio
    async def test_memory_saved_after_session(self):
        """Engine saves memory after submit_message completes."""
        memory_provider = SimpleMemoryProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "user_mem_test"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            memory_provider=memory_provider,
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        # Memory should have been saved
        memory = await memory_provider.load("user_mem_test", "team1")
        assert memory is not None
        assert memory.session_count >= 1

    @pytest.mark.asyncio
    async def test_memory_loaded_on_first_message(self):
        """Pre-existing memory summary is injected into system prompt."""
        memory_provider = SimpleMemoryProvider()
        await memory_provider.save(Memory(
            user_id="user_mem_load",
            team_id="team1",
            summary="User prefers short blog posts about SaaS.",
        ))

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "user_mem_load"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            memory_provider=memory_provider,
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        # System prompt should contain the memory summary
        assert "SaaS" in engine.system_prompt

    @pytest.mark.asyncio
    async def test_session_count_increments(self):
        """session_count increases with each submit_message call."""
        memory_provider = SimpleMemoryProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "user_count"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(["t1", "t2", "t3"]),
            memory_provider=memory_provider,
        )

        for _ in range(3):
            async for _ in engine.submit_message("ping", db=None):
                pass

        memory = await memory_provider.load("user_count", "team1")
        assert memory.session_count == 3

    @pytest.mark.asyncio
    async def test_compaction_summary_flows_to_memory(self):
        """When compaction fires, the summary text is saved to memory."""
        memory_provider = SimpleMemoryProvider()
        compaction_provider = MockCompactionProvider()

        engine = ChatEngine(
            config=ChatEngineConfig(
                app_name="Test",
                context_window=1000,
                max_output_tokens=100,
            ),
            user={"id": "user_compact_mem"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            compaction_provider=compaction_provider,
            memory_provider=memory_provider,
        )

        engine.messages = [
            UserMessage(content="x" * 400),
            AssistantMessage(content="y" * 400, input_tokens=300, output_tokens=100),
        ]

        async for _ in engine.submit_message("more", db=None):
            pass

        assert compaction_provider.was_called

        memory = await memory_provider.load("user_compact_mem", "team1")
        assert memory is not None
        assert memory.summary is not None
        assert "Summary" in memory.summary  # from MockCompactionProvider's fixed text

    @pytest.mark.asyncio
    async def test_memory_not_saved_when_no_provider(self):
        """Engine with no memory_provider completes without error."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            memory_provider=None,
        )

        events = []
        async for event in engine.submit_message("hello", db=None):
            events.append(event)

        end = next(e for e in events if isinstance(e, SessionEndEvent))
        assert end.reason == "success"
