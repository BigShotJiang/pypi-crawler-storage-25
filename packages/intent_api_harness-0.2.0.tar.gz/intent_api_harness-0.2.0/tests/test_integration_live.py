"""
P1.W11 — Live integration test against OpenAI gpt-4o.

Runs a real conversation through the full stack:
  User message → ChatEngine → LiteLLMProvider (gpt-4o) → query_loop
  → ToolSearchTool / ExecuteIntentTool → real IntentService handlers
  → SSE events

Uses the OPENAI_API_KEY from the .env file.
Run with: pytest tests/test_integration_live.py -v -s
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

# Load .env from repo root
_env_path = Path(__file__).parent.parent / ".env"
if _env_path.exists():
    for line in _env_path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

from intent_api import IntentService, custom_action
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import (
    SessionEndEvent,
    SessionStartEvent,
    TextDeltaEvent,
    ToolResultEvent,
    ToolStartEvent,
)
from intent_api_harness.providers.litellm_provider import LiteLLMProvider


# ── Test services ─────────────────────────────────────────────────────────────


class _BrandData:
    brands = [
        {"id": "1", "name": "Acme Corp", "niche": "SaaS"},
        {"id": "2", "name": "Globex", "niche": "Healthcare"},
    ]


class BrandService(IntentService):
    __display_prefix__ = "Brand"

    async def list(self, *, db, user, context, skip=0, limit=10):
        return _BrandData.brands

    async def read(self, *, db, user, context, id):
        return next((b for b in _BrandData.brands if b["id"] == str(id)), None)


class BlogPostService(IntentService):
    __display_prefix__ = "Blog Post"

    @custom_action(
        display="Generating blog posts",
        description="Generate blog posts for a brand",
    )
    async def generate(self, *, db, user, context, id, payload):
        return {
            "generated": 3,
            "brand_id": id,
            "titles": [
                "10 SaaS Growth Strategies",
                "Why Your SaaS Needs Better Onboarding",
                "The Future of SaaS in 2026",
            ],
        }


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Brand", BrandService())
    registry.register("BlogPost", BlogPostService())
    return registry


def _make_provider() -> LiteLLMProvider:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        pytest.skip("OPENAI_API_KEY not set")
    return LiteLLMProvider(
        model="openai/gpt-4o",
        api_key=api_key,
        max_output_tokens=2048,
        temperature=0.0,
    )


def _make_engine(config: ChatEngineConfig | None = None) -> ChatEngine:
    return ChatEngine(
        config=config or ChatEngineConfig(
            app_name="SEO Brew",
            max_turns=15,
            custom_instructions="You help users manage their SEO content strategy.",
        ),
        user={"id": "user_test_1"},
        intent_context=IntentContext(type="user", team_id="team_test"),
        registry=_make_registry(),
        model_provider=_make_provider(),
    )


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _collect(engine: ChatEngine, message: str) -> list:
    events = []
    async for event in engine.submit_message(message, db=None):
        _print_event(event)
        events.append(event)
    return events


def _print_event(event) -> None:
    name = type(event).__name__
    if hasattr(event, "text"):
        print(f"  [{name}] {event.text[:80]}", end="", flush=True)
    elif hasattr(event, "tool_name"):
        print(f"\n  [{name}] {event.tool_name} — {getattr(event, 'display', '')}", flush=True)
    elif hasattr(event, "result"):
        r = event.result
        print(f"  [{name}] status={r.status}", flush=True)
    elif hasattr(event, "reason"):
        print(f"\n  [{name}] reason={event.reason} turns={event.turn_count}", flush=True)
    else:
        print(f"\n  [{name}]", flush=True)


# ── Scenario 1: Simple query ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_scenario_1_list_brands():
    """
    Scenario 1: User asks 'What brands do I have?'
    Expected: model discovers Brand.list via ToolSearchTool or calls it directly,
              returns the list, responds with text.
    """
    print("\n\n=== Scenario 1: List brands ===")
    engine = _make_engine()
    events = await _collect(engine, "What brands do I have?")

    # Must produce a result
    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "success", f"Expected success, got {end.reason}"

    # Must have called at least one tool
    tool_calls = [e for e in events if isinstance(e, ToolStartEvent)]
    assert len(tool_calls) >= 1, "Expected at least one tool call"

    # At least one tool result must be success
    results = [e for e in events if isinstance(e, ToolResultEvent)]
    assert any(r.result.status == "success" for r in results), "Expected at least one success result"

    # Final text must mention brand names
    text = "".join(e.text for e in events if isinstance(e, TextDeltaEvent))
    assert any(name in text for name in ["Acme", "Globex", "brand", "Brand"]), \
        f"Expected brand names in response, got: {text[:200]}"

    print(f"\n  ✓ Tool calls: {len(tool_calls)}, Final text length: {len(text)}")


# ── Scenario 2: Multi-step intent ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_scenario_2_generate_blog_posts():
    """
    Scenario 2: User asks to generate blog posts for Acme.
    Expected: model reads Brand list or Brand.read, then calls BlogPost.generate.
    """
    print("\n\n=== Scenario 2: Generate blog posts for Acme ===")
    engine = _make_engine()
    events = await _collect(engine, "Generate blog posts for my brand Acme Corp (id: 1)")

    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "success", f"Expected success, got {end.reason}"

    # BlogPost.generate must have been called
    exec_calls = [
        e for e in events
        if isinstance(e, ToolStartEvent) and e.tool_name == "execute_intent"
    ]
    exec_results = [e for e in events if isinstance(e, ToolResultEvent)]

    called_models = set()
    for call in exec_calls:
        if call.intent:
            called_models.add(call.intent.model)

    assert "BlogPost" in called_models or len(exec_results) >= 1, \
        f"Expected BlogPost to be called. Called: {called_models}"

    # At least one success
    assert any(r.result.status == "success" for r in exec_results)

    text = "".join(e.text for e in events if isinstance(e, TextDeltaEvent))
    assert len(text) > 20, f"Expected meaningful response, got: {text[:200]}"

    print(f"\n  ✓ Called models: {called_models}")
    print(f"  ✓ Tool results: {[r.result.status for r in exec_results]}")


# ── Scenario 3: Error handling ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_scenario_3_nonexistent_model():
    """
    Scenario 3: Model tries to access a model not in registry.
    The tool should return an error and the model should explain gracefully.
    """
    print("\n\n=== Scenario 3: Nonexistent model error handling ===")
    engine = _make_engine()
    # Give it a task it can't complete cleanly
    events = await _collect(
        engine,
        "Please delete the Article with id 999. Note: if you can't, explain why."
    )

    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "success"  # Loop completes — model explains

    text = "".join(e.text for e in events if isinstance(e, TextDeltaEvent))
    assert len(text) > 10, "Expected the model to produce an explanation"

    print(f"\n  ✓ Model responded gracefully: {text[:150]}")


# ── Scenario 4: Multi-turn session ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_scenario_4_multi_turn():
    """
    Scenario 4: Two messages in the same session. Second message has context
    from the first.
    """
    print("\n\n=== Scenario 4: Multi-turn conversation ===")
    engine = _make_engine()

    print("\n--- Turn 1 ---")
    events1 = await _collect(engine, "List my brands")
    end1 = next(e for e in events1 if isinstance(e, SessionEndEvent))
    assert end1.reason == "success"

    # Session start only emitted once (first turn)
    starts = [e for e in events1 if isinstance(e, SessionStartEvent)]
    assert len(starts) == 1

    print("\n--- Turn 2 ---")
    events2 = await _collect(engine, "How many brands do I have in total?")
    end2 = next(e for e in events2 if isinstance(e, SessionEndEvent))
    assert end2.reason == "success"

    # Session start NOT emitted on second turn
    starts2 = [e for e in events2 if isinstance(e, SessionStartEvent)]
    assert len(starts2) == 0, "SessionStartEvent must not repeat on subsequent turns"

    text2 = "".join(e.text for e in events2 if isinstance(e, TextDeltaEvent))
    assert len(text2) > 10, f"Expected a response on turn 2, got: {text2[:200]}"

    print(f"\n  ✓ Turn 2 responded successfully with {len(text2)} chars")
    print(f"  ✓ Response: {text2[:150]}")


# ── Scenario 5: SSE event structure ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_scenario_5_event_stream_structure():
    """
    Scenario 5: Verify the SSE event stream has the right structure.
    - First event is SessionStartEvent
    - Last event is SessionEndEvent
    - All events share the same session_id
    - Events serialize to valid JSON
    """
    print("\n\n=== Scenario 5: Event stream structure ===")
    engine = _make_engine()
    events = await _collect(engine, "What can you do for me?")

    # First event
    assert isinstance(events[0], SessionStartEvent), \
        f"First event must be SessionStartEvent, got {type(events[0]).__name__}"

    # Last event
    assert isinstance(events[-1], SessionEndEvent), \
        f"Last event must be SessionEndEvent, got {type(events[-1]).__name__}"

    # All share session_id
    session_ids = {e.session_id for e in events}
    assert len(session_ids) == 1

    # All serialize to valid JSON with type field
    for event in events:
        data = json.loads(event.model_dump_json())
        assert "type" in data, f"Event missing type field: {data}"
        assert "session_id" in data

    print(f"\n  ✓ {len(events)} events, all valid, session_id={events[0].session_id}")
    print(f"  ✓ Event types: {[type(e).__name__ for e in events]}")
