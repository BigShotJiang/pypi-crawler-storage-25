"""
P1.W11 — Loop unit tests using a MockModelProvider.

Tests the full query_loop / ChatEngine pipeline without a live model.
The MockModelProvider returns scripted responses in sequence, letting us
prove multi-turn tool calling, error handling, max-turns, and abort.
"""

from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator
from unittest.mock import AsyncMock

import pytest

from intent_api import IntentService, custom_action
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import (
    SessionEndEvent,
    SessionStartEvent,
    TextDeltaEvent,
    ToolResultEvent,
    ToolStartEvent,
)
from intent_api_harness.messages import ExecutionResult
from intent_api_harness.model_provider import ModelResponse, StreamChunk
from intent_api_harness.events import TokenUsage


# ── Minimal test services ─────────────────────────────────────────────────────


class BrandService(IntentService):
    __display_prefix__ = "Brand"

    def __init__(self, brands: list[dict] | None = None):
        self._brands = brands or [
            {"id": "1", "name": "Acme"},
            {"id": "2", "name": "Globex"},
        ]

    async def list(self, *, db, user, context, skip=0, limit=10):
        return self._brands

    async def read(self, *, db, user, context, id):
        return next((b for b in self._brands if b["id"] == str(id)), None)


class BlogPostService(IntentService):
    __display_prefix__ = "Blog Post"

    @custom_action(display="Generating blog posts", description="Generate blog posts")
    async def generate(self, *, db, user, context, id, payload):
        return {"generated": 3, "brand_id": id}


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Brand", BrandService())
    registry.register("BlogPost", BlogPostService())
    return registry


def _make_context() -> IntentContext:
    return IntentContext(type="user", team_id="team1")


# ── MockModelProvider ─────────────────────────────────────────────────────────


class MockModelProvider:
    """
    Scripted model provider for testing.

    Takes a list of 'turns'. Each turn is either:
    - A string → text-only response (no tool calls, loop terminates)
    - A list of dicts → tool call(s) the model wants to make
      Each dict: {"tool_name": str, "id": str, "input": dict}
    """

    def __init__(self, turns: list[str | list[dict]]):
        self._turns = list(turns)
        self._call_count = 0

    async def complete(self, messages, system_prompt=None, tools=None, max_output_tokens=None) -> ModelResponse:
        raise NotImplementedError("Use stream()")

    async def stream(
        self,
        messages,
        system_prompt=None,
        tools=None,
        max_output_tokens=None,
    ) -> AsyncGenerator[StreamChunk, None]:
        from intent_api_harness.messages import ToolCall as TC

        if self._call_count >= len(self._turns):
            self._call_count += 1
            yield StreamChunk(type="text", text="Done.")
            return

        turn = self._turns[self._call_count]
        self._call_count += 1

        if isinstance(turn, str):
            yield StreamChunk(type="text", text=turn)
        else:
            for tc in turn:
                tc_id = tc.get("id", f"tc_{self._call_count}")
                yield StreamChunk(
                    type="tool_call_start",
                    tool_call_id=tc_id,
                    tool_call_name=tc["tool_name"],
                )
                yield StreamChunk(
                    type="tool_call_end",
                    tool_call=TC(
                        id=tc_id,
                        tool_name=tc["tool_name"],
                        input=tc.get("input", {}),
                    ),
                )

    async def extract(self, messages, response_model, system_prompt=None):
        raise NotImplementedError("Not needed for loop tests")


# ── Helpers ───────────────────────────────────────────────────────────────────


async def _run_engine(
    turns: list[str | list[dict]],
    message: str = "list my brands",
    config: ChatEngineConfig | None = None,
) -> tuple[list[Any], ChatEngine]:
    """Run a ChatEngine with scripted turns, collect all events."""
    registry = _make_registry()
    provider = MockModelProvider(turns)
    engine = ChatEngine(
        config=config or ChatEngineConfig(app_name="TestApp"),
        user={"id": "user1"},
        intent_context=_make_context(),
        registry=registry,
        model_provider=provider,
    )

    events = []
    async for event in engine.submit_message(message, db=None):
        events.append(event)

    return events, engine


# ── Tests ─────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_text_only_response_terminates():
    """Model responds with text, no tool calls → loop terminates cleanly."""
    events, engine = await _run_engine(["Hello! I can help with that."])

    types = [type(e).__name__ for e in events]
    assert "SessionStartEvent" in types
    assert "TextDeltaEvent" in types
    assert "SessionEndEvent" in types

    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "success"


@pytest.mark.asyncio
async def test_session_start_emitted_once():
    events, _ = await _run_engine(["Done."])
    starts = [e for e in events if isinstance(e, SessionStartEvent)]
    assert len(starts) == 1
    assert starts[0].session_id is not None
    assert "execute_intent" in starts[0].tools
    assert "ToolSearchTool" in starts[0].tools


@pytest.mark.asyncio
async def test_single_tool_call_then_text():
    """Model calls execute_intent once, gets result, then responds with text."""
    turns = [
        [{"tool_name": "execute_intent", "id": "tc1", "input": {"model": "Brand", "action": "list"}}],
        "You have 2 brands: Acme and Globex.",
    ]
    events, _ = await _run_engine(turns)

    tool_starts = [e for e in events if isinstance(e, ToolStartEvent)]
    tool_results = [e for e in events if isinstance(e, ToolResultEvent)]
    text_events = [e for e in events if isinstance(e, TextDeltaEvent)]
    end = next(e for e in events if isinstance(e, SessionEndEvent))

    assert len(tool_starts) == 1
    assert tool_starts[0].tool_name == "execute_intent"
    assert tool_starts[0].display is not None

    assert len(tool_results) == 1
    assert tool_results[0].result.status == "success"
    assert tool_results[0].result.data == [{"id": "1", "name": "Acme"}, {"id": "2", "name": "Globex"}]

    assert any("Acme" in e.text or "Globex" in e.text or len(e.text) > 0 for e in text_events)
    assert end.reason == "success"


@pytest.mark.asyncio
async def test_tool_search_then_execute():
    """Model searches tools first, then executes an intent."""
    turns = [
        [{"tool_name": "ToolSearchTool", "id": "tc1", "input": {"query": "brand"}}],
        [{"tool_name": "execute_intent", "id": "tc2", "input": {"model": "Brand", "action": "list"}}],
        "Here are your brands.",
    ]
    events, _ = await _run_engine(turns)

    tool_names = [e.tool_name for e in events if isinstance(e, ToolStartEvent)]
    assert "ToolSearchTool" in tool_names
    assert "execute_intent" in tool_names

    search_result = next(e for e in events if isinstance(e, ToolResultEvent))
    assert search_result.result.status == "success"


@pytest.mark.asyncio
async def test_unknown_tool_returns_error():
    """Model tries to call a nonexistent tool → error result, loop continues."""
    turns = [
        [{"tool_name": "nonexistent_tool", "id": "tc1", "input": {}}],
        "I'll try a different approach.",
    ]
    events, _ = await _run_engine(turns)

    results = [e for e in events if isinstance(e, ToolResultEvent)]
    assert len(results) == 1
    assert results[0].result.status == "error"
    assert "No such tool" in (results[0].result.message or "")

    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "success"


@pytest.mark.asyncio
async def test_unknown_model_in_execute_intent():
    """execute_intent targets a model that doesn't exist in the registry."""
    turns = [
        [{"tool_name": "execute_intent", "id": "tc1", "input": {"model": "Ghost", "action": "list"}}],
        "That model doesn't exist.",
    ]
    events, _ = await _run_engine(turns)

    results = [e for e in events if isinstance(e, ToolResultEvent)]
    assert results[0].result.status == "error"
    assert "Ghost" in (results[0].result.message or "")


@pytest.mark.asyncio
async def test_max_turns_terminates():
    """Loop terminates when max_turns is hit."""
    # 5 tool calls, no text → should stop at max_turns=2
    turns = [
        [{"tool_name": "execute_intent", "id": f"tc{i}", "input": {"model": "Brand", "action": "list"}}]
        for i in range(10)
    ]
    config = ChatEngineConfig(max_turns=2, app_name="TestApp")
    events, _ = await _run_engine(turns, config=config)

    end = next(e for e in events if isinstance(e, SessionEndEvent))
    assert end.reason == "max_turns"


@pytest.mark.asyncio
async def test_abort_terminates():
    """engine.abort() stops the loop cleanly."""
    registry = _make_registry()

    # Provider that blocks until we abort
    call_count = 0

    class SlowProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.1)
            yield StreamChunk(type="text", text="Done.")

        async def complete(self, *a, **kw):
            raise NotImplementedError

        async def extract(self, *a, **kw):
            raise NotImplementedError

    engine = ChatEngine(
        config=ChatEngineConfig(app_name="TestApp"),
        user={"id": "user1"},
        intent_context=_make_context(),
        registry=registry,
        model_provider=SlowProvider(),
    )

    events = []

    async def collect():
        async for event in engine.submit_message("hello", db=None):
            events.append(event)

    task = asyncio.create_task(collect())
    await asyncio.sleep(0.01)
    engine.abort()
    await task

    end = next((e for e in events if isinstance(e, SessionEndEvent)), None)
    # abort fires before the loop makes a call, so we get an immediate end
    assert end is not None


@pytest.mark.asyncio
async def test_multi_tool_calls_in_one_turn():
    """Model issues two tool calls in a single turn."""
    turns = [
        [
            {"tool_name": "execute_intent", "id": "tc1", "input": {"model": "Brand", "action": "read", "id": "1"}},
            {"tool_name": "execute_intent", "id": "tc2", "input": {"model": "Brand", "action": "read", "id": "2"}},
        ],
        "Got both brands.",
    ]
    events, _ = await _run_engine(turns)

    tool_starts = [e for e in events if isinstance(e, ToolStartEvent)]
    tool_results = [e for e in events if isinstance(e, ToolResultEvent)]

    assert len(tool_starts) == 2
    assert len(tool_results) == 2
    assert all(r.result.status == "success" for r in tool_results)


@pytest.mark.asyncio
async def test_session_id_consistent():
    """All events share the same session_id."""
    events, engine = await _run_engine(["Done."])
    session_ids = {e.session_id for e in events}
    assert len(session_ids) == 1
    assert list(session_ids)[0] == engine.session_id


@pytest.mark.asyncio
async def test_tool_display_label_resolved():
    """ToolStartEvent has a non-None display label for execute_intent."""
    turns = [
        [{"tool_name": "execute_intent", "id": "tc1", "input": {"model": "Brand", "action": "list"}}],
        "Done.",
    ]
    events, _ = await _run_engine(turns)

    tool_start = next(e for e in events if isinstance(e, ToolStartEvent))
    assert tool_start.display is not None
    assert len(tool_start.display) > 0


@pytest.mark.asyncio
async def test_custom_command_display_from_decorator():
    """execute_intent on a @custom_action uses the decorator's display label."""
    turns = [
        [{"tool_name": "execute_intent", "id": "tc1", "input": {
            "model": "BlogPost", "action": "custom", "command": "generate", "id": "1"
        }}],
        "Generated 3 posts.",
    ]
    events, _ = await _run_engine(turns)

    tool_start = next(e for e in events if isinstance(e, ToolStartEvent))
    assert tool_start.display == "Generating blog posts"


@pytest.mark.asyncio
async def test_intent_summary_populated_for_execute_intent():
    """ToolStartEvent.intent is populated for execute_intent calls."""
    turns = [
        [{"tool_name": "execute_intent", "id": "tc1", "input": {
            "model": "BlogPost", "action": "custom", "command": "generate", "id": "1"
        }}],
        "Done.",
    ]
    events, _ = await _run_engine(turns)

    tool_start = next(e for e in events if isinstance(e, ToolStartEvent))
    assert tool_start.intent is not None
    assert tool_start.intent.model == "BlogPost"
    assert tool_start.intent.command == "generate"


@pytest.mark.asyncio
async def test_session_store_reuses_engine():
    """ChatService reuses the same ChatEngine for a resumed session_id."""
    from intent_api_harness.service import ChatService

    provider = MockModelProvider(["Turn 1 done.", "Turn 2 done."])
    config = ChatEngineConfig(app_name="TestApp")
    service = ChatService(model_provider=provider, config=config)
    # Inject registry (normally done by IntentRouter.register)
    service._registry = _make_registry()

    # First message — no session_id
    r1 = await service.stream(
        db=None, user={"id": "u1"}, context=_make_context(), id=None,
        payload={"message": "hello"},
    )
    # Consume the stream to get session_id from response header
    events1 = []
    async for chunk in r1.body_iterator:
        events1.append(chunk)
    session_id = r1.headers.get("X-Session-ID")
    assert session_id is not None

    assert service.active_session_count == 1

    # Second message — resume same session
    r2 = await service.stream(
        db=None, user={"id": "u1"}, context=_make_context(), id=None,
        payload={"message": "follow up", "session_id": session_id},
    )
    events2 = []
    async for chunk in r2.body_iterator:
        events2.append(chunk)

    assert service.active_session_count == 1  # Still 1, not 2
