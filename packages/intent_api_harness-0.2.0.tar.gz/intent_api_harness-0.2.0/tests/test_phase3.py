"""
Phase 3 tests — sub-agents, hooks, cloud provider contracts.

All tests use MockModelProvider (no live API calls).
Cloud provider tests use httpx.MockTransport to verify request shape.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import httpx

from intent_api import IntentService, custom_action
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.compaction.cloud import (
    IntentAPICloudCompactionProvider,
    IntentAPICloudMemoryProvider,
)
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.events import (
    SessionEndEvent,
    TextDeltaEvent,
    ToolResultEvent,
    ToolStartEvent,
)
from intent_api_harness.hooks import HarnessHook, HookEvent, fire_hooks
from intent_api_harness.messages import (
    CompactBoundaryMessage,
    ExecutionResult,
    UserMessage,
)
from intent_api_harness.model_provider import StreamChunk
from intent_api_harness.tools.spawn_tool import SpawnTaskTool


# ── Shared fixtures ───────────────────────────────────────────────────────────


class NoteService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return [{"id": "1", "text": "Meeting notes"}]


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Note", NoteService())
    return registry


def _make_context() -> IntentContext:
    return IntentContext(type="user", team_id="team1")


class MockProvider:
    def __init__(self, responses: list[str] | None = None):
        self._responses = responses or ["Done."]
        self._call_count = 0

    async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
        idx = min(self._call_count, len(self._responses) - 1)
        text = self._responses[idx]
        self._call_count += 1
        yield StreamChunk(type="text", text=text)

    async def complete(self, *a, **kw):
        raise NotImplementedError

    async def extract(self, *a, **kw):
        raise NotImplementedError


# ── P3.W1 — SpawnTaskTool ─────────────────────────────────────────────────────


class TestSpawnTaskTool:
    @pytest.mark.asyncio
    async def test_spawn_tool_not_in_default_toolset(self):
        """SpawnTaskTool is not included unless enable_spawn=True."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
        )
        tool_names = [t.name for t in engine.tools]
        assert "spawn_task" not in tool_names

    @pytest.mark.asyncio
    async def test_spawn_tool_included_when_enabled(self):
        """With enable_spawn=True, spawn_task appears in the tool list."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            enable_spawn=True,
        )
        tool_names = [t.name for t in engine.tools]
        assert "spawn_task" in tool_names

    @pytest.mark.asyncio
    async def test_sub_agent_has_no_spawn_task(self):
        """
        When spawn_task is called, the sub-agent it creates does NOT have
        spawn_task in its tool list (depth-1 enforcement by exclusion).
        """
        spawned_tools: list[str] = []

        class RecordingProvider:
            async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
                # Record the tool names visible to this agent
                if tools:
                    spawned_tools.extend(t.get("function", {}).get("name", "") for t in tools)
                yield StreamChunk(type="text", text="Sub-agent done.")

            async def complete(self, *a, **kw):
                raise NotImplementedError

            async def extract(self, *a, **kw):
                raise NotImplementedError

        tool = SpawnTaskTool()
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=RecordingProvider(),
            enable_spawn=True,
        )

        result = await tool.call({"task": "list all notes"}, engine)

        assert result.status == "success"
        assert "spawn_task" not in spawned_tools
        assert "execute_intent" in spawned_tools
        assert "ToolSearchTool" in spawned_tools

    @pytest.mark.asyncio
    async def test_spawn_returns_sub_agent_summary(self):
        """The summary text from the sub-agent is returned in ExecutionResult.data."""
        tool = SpawnTaskTool()
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(["I found 1 note: Meeting notes."]),
            enable_spawn=True,
        )

        result = await tool.call({"task": "list notes"}, engine)

        assert result.status == "success"
        assert result.data is not None
        assert "Meeting notes" in result.data["summary"]

    @pytest.mark.asyncio
    async def test_spawn_empty_task_returns_error(self):
        tool = SpawnTaskTool()
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
        )

        result = await tool.call({"task": ""}, engine)
        assert result.status == "error"
        assert "task" in (result.message or "").lower()

    @pytest.mark.asyncio
    async def test_model_can_use_spawn_task_via_loop(self):
        """
        When spawn_task is in the model's tool list, the loop dispatches it
        and the result flows back as a ToolResultEvent.
        """
        from intent_api_harness.messages import ToolCall as TC

        parent_calls = 0

        class ParentAndSubProvider:
            """
            Single provider that acts differently based on call number.
            Call 1: parent first turn → yields spawn_task call
            Call 2: sub-agent turn → yields text summary
            Call 3: parent second turn → yields final text
            """
            async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
                nonlocal parent_calls
                parent_calls += 1
                n = parent_calls
                if n == 1:
                    # Parent: call spawn_task
                    yield StreamChunk(type="tool_call_start", tool_call_id="tc1", tool_call_name="spawn_task")
                    yield StreamChunk(
                        type="tool_call_end",
                        tool_call=TC(id="tc1", tool_name="spawn_task", input={"task": "find notes"}),
                    )
                elif n == 2:
                    # Sub-agent: return summary
                    yield StreamChunk(type="text", text="Found 1 note: Meeting notes.")
                else:
                    # Parent: final text after seeing spawn result
                    yield StreamChunk(type="text", text="Sub-agent found notes for you.")

            async def complete(self, *a, **kw): raise NotImplementedError
            async def extract(self, *a, **kw): raise NotImplementedError

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=ParentAndSubProvider(),
            enable_spawn=True,
        )

        events = []
        async for event in engine.submit_message("find all notes", db=None):
            events.append(event)

        tool_starts = [e for e in events if isinstance(e, ToolStartEvent)]
        tool_results = [e for e in events if isinstance(e, ToolResultEvent)]

        assert any(e.tool_name == "spawn_task" for e in tool_starts)
        assert len(tool_results) >= 1

        spawn_result = next(
            r for r in tool_results
            if events[events.index(r) - 1].tool_name == "spawn_task"
            if isinstance(events[events.index(r) - 1], ToolStartEvent)
        ) if False else tool_results[0]

        # Sub-agent should have produced a summary (success or the text result)
        assert spawn_result.result.status in ("success", "error")


# ── P3.W2 — Hooks ─────────────────────────────────────────────────────────────


class TestHarnessHooks:
    @pytest.mark.asyncio
    async def test_fire_hooks_calls_all_hooks(self):
        """fire_hooks calls every hook in the list."""
        events_received: list[tuple[str, str]] = []

        class RecordHook:
            async def on_event(self, event: HookEvent, data: dict) -> None:
                events_received.append((type(self).__name__, event.value))

        hooks = [RecordHook(), RecordHook()]
        await fire_hooks(hooks, HookEvent.SESSION_START, {"session_id": "abc"})

        assert len(events_received) == 2
        assert all(e[1] == "session_start" for e in events_received)

    @pytest.mark.asyncio
    async def test_fire_hooks_tolerates_exceptions(self):
        """A failing hook does not propagate — other hooks still run."""
        called: list[str] = []

        class BrokenHook:
            async def on_event(self, event, data):
                raise RuntimeError("hook exploded")

        class GoodHook:
            async def on_event(self, event, data):
                called.append("good")

        await fire_hooks([BrokenHook(), GoodHook()], HookEvent.INTENT_CALL, {})
        assert "good" in called

    @pytest.mark.asyncio
    async def test_fire_hooks_empty_list(self):
        """fire_hooks with empty list is a no-op."""
        await fire_hooks([], HookEvent.SESSION_END, {})  # should not raise

    @pytest.mark.asyncio
    async def test_session_start_hook_fires(self):
        """SESSION_START hook fires on first submit_message."""
        received: list[HookEvent] = []

        class TrackHook:
            async def on_event(self, event, data):
                received.append(event)

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            hooks=[TrackHook()],
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        # Wait briefly for background tasks to complete
        await asyncio.sleep(0.05)
        assert HookEvent.SESSION_START in received

    @pytest.mark.asyncio
    async def test_session_end_hook_fires(self):
        """SESSION_END hook fires after the loop completes."""
        received: list[HookEvent] = []

        class TrackHook:
            async def on_event(self, event, data):
                received.append(event)

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            hooks=[TrackHook()],
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        await asyncio.sleep(0.05)
        assert HookEvent.SESSION_END in received

    @pytest.mark.asyncio
    async def test_turn_start_hook_fires(self):
        """TURN_START hook fires at the beginning of each loop iteration."""
        received: list[HookEvent] = []

        class TrackHook:
            async def on_event(self, event, data):
                received.append(event)

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            hooks=[TrackHook()],
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        await asyncio.sleep(0.05)
        assert HookEvent.TURN_START in received

    @pytest.mark.asyncio
    async def test_intent_call_and_result_hooks_fire(self):
        """INTENT_CALL and INTENT_RESULT hooks fire when execute_intent is called."""
        from intent_api_harness.messages import ToolCall as TC
        received: list[HookEvent] = []

        class TrackHook:
            async def on_event(self, event, data):
                received.append(event)

        call_count = 0

        class ToolCallProvider:
            async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
                nonlocal call_count
                call_count += 1
                if call_count == 1:
                    yield StreamChunk(type="tool_call_start", tool_call_id="tc1", tool_call_name="execute_intent")
                    yield StreamChunk(
                        type="tool_call_end",
                        tool_call=TC(id="tc1", tool_name="execute_intent", input={"model": "Note", "action": "list"}),
                    )
                else:
                    yield StreamChunk(type="text", text="Got the notes.")

            async def complete(self, *a, **kw): raise NotImplementedError
            async def extract(self, *a, **kw): raise NotImplementedError

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=ToolCallProvider(),
            hooks=[TrackHook()],
        )

        async for _ in engine.submit_message("list notes", db=None):
            pass

        await asyncio.sleep(0.05)
        assert HookEvent.INTENT_CALL in received
        assert HookEvent.INTENT_RESULT in received

    @pytest.mark.asyncio
    async def test_hook_receives_session_id(self):
        """Hook data includes session_id for correlation."""
        received_data: list[dict] = []

        class DataHook:
            async def on_event(self, event, data):
                received_data.append({"event": event, "data": data})

        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            hooks=[DataHook()],
        )

        async for _ in engine.submit_message("hello", db=None):
            pass

        await asyncio.sleep(0.05)

        start_data = next(d for d in received_data if d["event"] == HookEvent.SESSION_START)
        assert start_data["data"]["session_id"] == engine.session_id

    @pytest.mark.asyncio
    async def test_hooks_not_called_when_empty(self):
        """Engine with no hooks completes normally."""
        engine = ChatEngine(
            config=ChatEngineConfig(app_name="Test"),
            user={"id": "u1"},
            intent_context=_make_context(),
            registry=_make_registry(),
            model_provider=MockProvider(),
            hooks=[],
        )

        events = []
        async for event in engine.submit_message("hello", db=None):
            events.append(event)

        end = next(e for e in events if isinstance(e, SessionEndEvent))
        assert end.reason == "success"


# ── P3.W3 / P3.W4 — Cloud provider contract tests ────────────────────────────


class TestIntentAPICloudCompactionProvider:
    """Tests cloud compaction provider request shape using httpx mock transport."""

    def _make_mock_transport(self, response_body: dict) -> httpx.MockTransport:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=response_body)
        return httpx.MockTransport(handler)

    @pytest.mark.asyncio
    async def test_sends_to_machine_intent_endpoint(self):
        """Request goes to /api/machine-intent."""
        captured: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(request)
            return httpx.Response(200, json={"summary": "Test summary"})

        provider = IntentAPICloudCompactionProvider(api_key="test-key")

        # Patch httpx.AsyncClient to use mock transport
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            result = await provider.compact(
                messages=[UserMessage(content="hello")],
                system_prompt="Be helpful",
                model_provider=None,
                tool_summaries=[],
            )
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert len(captured) == 1
        assert "/api/machine-intent" in str(captured[0].url)

    @pytest.mark.asyncio
    async def test_sends_correct_intent_model(self):
        """Request body uses model='Harness', action='custom', command='compact'."""
        captured_body: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_body.append(json.loads(request.content))
            return httpx.Response(200, json={"summary": "OK"})

        provider = IntentAPICloudCompactionProvider(api_key="test-key")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            await provider.compact(
                messages=[UserMessage(content="hello")],
                system_prompt="test",
                model_provider=None,
                tool_summaries=[],
            )
        finally:
            httpx.AsyncClient.__init__ = original_init

        body = captured_body[0]
        assert body["model"] == "Harness"
        assert body["action"] == "custom"
        assert body["command"] == "compact"

    @pytest.mark.asyncio
    async def test_sends_bearer_auth_header(self):
        """Authorization: Bearer {api_key} header is present."""
        captured_headers: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_headers.append(dict(request.headers))
            return httpx.Response(200, json={"summary": "OK"})

        provider = IntentAPICloudCompactionProvider(api_key="my-secret-key")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            await provider.compact(
                messages=[UserMessage(content="hello")],
                system_prompt="test",
                model_provider=None,
                tool_summaries=[],
            )
        finally:
            httpx.AsyncClient.__init__ = original_init

        headers = captured_headers[0]
        assert headers.get("authorization") == "Bearer my-secret-key"

    @pytest.mark.asyncio
    async def test_returns_compaction_result(self):
        """Provider returns a valid CompactionResult from cloud response."""
        from intent_api_harness.compaction.provider import CompactionResult

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"summary": "## Compact\nUser listed notes."})

        provider = IntentAPICloudCompactionProvider(api_key="key")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            result = await provider.compact(
                messages=[UserMessage(content="list my notes")],
                system_prompt="test",
                model_provider=None,
                tool_summaries=[],
            )
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert isinstance(result, CompactionResult)
        assert result.summary_messages[0].content == "## Compact\nUser listed notes."


class TestIntentAPICloudMemoryProvider:
    """Tests cloud memory provider request shape."""

    @pytest.mark.asyncio
    async def test_load_sends_read_intent(self):
        """load() sends model='Memory', action='read'."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(json.loads(request.content))
            return httpx.Response(200, json={"summary": "old memory", "key_facts": [], "session_count": 2})

        provider = IntentAPICloudMemoryProvider(api_key="key", app_id="my-app")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            memory = await provider.load("user123", "team1")
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert captured[0]["model"] == "Memory"
        assert captured[0]["action"] == "read"
        assert captured[0]["id"] == "user123"
        assert memory is not None
        assert memory.summary == "old memory"
        assert memory.session_count == 2

    @pytest.mark.asyncio
    async def test_load_returns_none_on_404(self):
        """load() returns None when cloud returns 404."""
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, json={"detail": "not found"})

        provider = IntentAPICloudMemoryProvider(api_key="key", app_id="app")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            result = await provider.load("new_user")
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert result is None

    @pytest.mark.asyncio
    async def test_save_sends_update_intent(self):
        """save() sends model='Memory', action='update'."""
        captured: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured.append(json.loads(request.content))
            return httpx.Response(200, json={"ok": True})

        provider = IntentAPICloudMemoryProvider(api_key="key", app_id="my-app")
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        from intent_api_harness.memory.provider import Memory

        try:
            await provider.save(Memory(
                user_id="user123",
                team_id="team1",
                summary="User prefers short blog posts.",
                session_count=3,
            ))
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert captured[0]["model"] == "Memory"
        assert captured[0]["action"] == "update"
        assert captured[0]["id"] == "user123"
        assert captured[0]["payload"]["summary"] == "User prefers short blog posts."
        assert captured[0]["payload"]["app_id"] == "my-app"

    @pytest.mark.asyncio
    async def test_custom_endpoint(self):
        """Custom endpoint overrides the default."""
        captured_urls: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_urls.append(str(request.url))
            return httpx.Response(404)

        provider = IntentAPICloudMemoryProvider(
            api_key="key",
            app_id="app",
            endpoint="https://self-hosted.example.com",
        )
        original_init = httpx.AsyncClient.__init__

        def mock_init(self_client, *args, **kwargs):
            kwargs["transport"] = httpx.MockTransport(handler)
            original_init(self_client, *args, **kwargs)

        httpx.AsyncClient.__init__ = mock_init

        try:
            await provider.load("u1")
        finally:
            httpx.AsyncClient.__init__ = original_init

        assert "self-hosted.example.com" in captured_urls[0]
