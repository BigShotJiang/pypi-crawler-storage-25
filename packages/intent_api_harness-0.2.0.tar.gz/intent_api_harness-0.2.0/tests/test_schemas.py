"""
Tests for P1.W2 — Pydantic schemas: messages, events, state.
"""

from __future__ import annotations

import json

import pytest

from intent_api_harness.messages import (
    AssistantMessage,
    CompactBoundaryMessage,
    ExecutionResult,
    MessageRole,
    SystemMessage,
    ToolCall,
    ToolResultMessage,
    UserMessage,
)
from intent_api_harness.events import (
    CompactEvent,
    ErrorEvent,
    ModeChangeEvent,
    SessionEndEvent,
    SessionStartEvent,
    TextDeltaEvent,
    ThinkingDeltaEvent,
    ToolResultEvent,
    ToolStartEvent,
    TokenUsage,
    IntentSummary,
)
from intent_api_harness.state import CompactTracking, LoopState, ToolSummary


# ── Messages ──────────────────────────────────────────────────────────────────


def test_user_message_type_discriminator():
    msg = UserMessage(content="hello")
    assert msg.type == "user"
    assert msg.role == MessageRole.USER


def test_assistant_message_type_discriminator():
    msg = AssistantMessage(content="hi there")
    assert msg.type == "assistant"
    assert msg.role == MessageRole.ASSISTANT


def test_assistant_message_with_tool_calls():
    tc = ToolCall(id="tc1", tool_name="execute_intent", input={"model": "Brand", "action": "list"})
    msg = AssistantMessage(tool_calls=[tc])
    assert msg.content is None
    assert msg.tool_calls[0].tool_name == "execute_intent"


def test_tool_result_message_type_discriminator():
    result = ExecutionResult(status="success", data={"items": []})
    msg = ToolResultMessage(tool_call_id="tc1", result=result)
    assert msg.type == "tool_result"
    assert msg.role == MessageRole.TOOL


def test_system_message_type_discriminator():
    msg = SystemMessage(subtype="init", content="System started")
    assert msg.type == "system"
    assert msg.role == MessageRole.SYSTEM


def test_compact_boundary_message_unique_type():
    boundary = CompactBoundaryMessage(pre_token_count=1000, messages_summarized=10)
    assert boundary.type == "compact_boundary"
    # Distinct from SystemMessage (different type discriminator)
    sys_msg = SystemMessage(subtype="init", content="x")
    assert boundary.type != sys_msg.type


def test_execution_result_statuses():
    for status in ("success", "denied", "quota_exceeded", "upgrade_required", "error"):
        r = ExecutionResult(status=status)
        assert r.status == status


def test_messages_serialize_to_json():
    msgs = [
        UserMessage(content="hello"),
        AssistantMessage(content="world"),
        CompactBoundaryMessage(pre_token_count=500, messages_summarized=5),
    ]
    for msg in msgs:
        data = msg.model_dump_json()
        parsed = json.loads(data)
        assert "type" in parsed
        assert "id" in parsed


# ── Events ────────────────────────────────────────────────────────────────────


def test_session_start_event():
    e = SessionStartEvent(session_id="abc", model="anthropic/claude-sonnet-4-20250514", tools=["execute_intent"])
    assert e.type == "session.start"
    assert e.session_id == "abc"


def test_text_delta_event():
    e = TextDeltaEvent(session_id="abc", text="hello")
    assert e.type == "text.delta"


def test_thinking_delta_event():
    e = ThinkingDeltaEvent(session_id="abc", text="thinking...")
    assert e.type == "thinking.delta"


def test_tool_start_event_with_intent():
    intent = IntentSummary(model="Brand", action="list")
    e = ToolStartEvent(
        session_id="abc",
        tool_call_id="tc1",
        tool_name="execute_intent",
        display="Loading Brand list",
        intent=intent,
    )
    assert e.type == "tool.start"
    assert e.intent.model == "Brand"


def test_tool_result_event():
    result = ExecutionResult(status="success", data={"count": 3})
    e = ToolResultEvent(session_id="abc", tool_call_id="tc1", result=result)
    assert e.type == "tool.result"
    assert e.result.status == "success"


def test_compact_event():
    e = CompactEvent(session_id="abc", pre_token_count=50000, post_token_count=3000, messages_summarized=40)
    assert e.type == "compact"


def test_error_event():
    e = ErrorEvent(session_id="abc", error_type="PermissionDenied", message="nope")
    assert e.type == "error"
    assert e.recoverable is False


def test_session_end_event():
    e = SessionEndEvent(session_id="abc", reason="success", turn_count=5)
    assert e.type == "session.end"
    assert e.reason == "success"


def test_events_serialize_with_type_field():
    events = [
        SessionStartEvent(session_id="s", model="m", tools=[]),
        TextDeltaEvent(session_id="s", text="x"),
        ThinkingDeltaEvent(session_id="s", text="y"),
        ToolStartEvent(session_id="s", tool_call_id="t", tool_name="execute_intent"),
        ToolResultEvent(session_id="s", tool_call_id="t", result=ExecutionResult(status="success")),
        CompactEvent(session_id="s", pre_token_count=1, post_token_count=1, messages_summarized=1),
        ErrorEvent(session_id="s", error_type="E", message="m"),
        ModeChangeEvent(session_id="s", mode="execute"),
        SessionEndEvent(session_id="s", reason="success", turn_count=1),
    ]
    for event in events:
        data = json.loads(event.model_dump_json())
        assert "type" in data
        assert "session_id" in data


# ── State ─────────────────────────────────────────────────────────────────────


def test_loop_state_defaults():
    state = LoopState()
    assert state.turn_count == 0
    assert state.token_count == 0
    assert state.compact_tracking.consecutive_failures == 0
    assert state.pending_tool_summaries == []


def test_compact_tracking_failures():
    tracking = CompactTracking(consecutive_failures=2)
    assert tracking.consecutive_failures == 2


def test_tool_summary():
    s = ToolSummary(tool_name="execute_intent", intent_id="Brand.list", status="success", turn=1)
    assert s.display is None
    assert s.turn == 1
