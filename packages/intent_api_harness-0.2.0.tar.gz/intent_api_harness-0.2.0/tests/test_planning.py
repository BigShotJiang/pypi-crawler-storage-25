"""
P2.W8 — Tests for ThinkTool, TodoWriteTool, planning prompt, and tool registration.

25 tests covering:
  ThinkTool (3)
  TodoWriteTool (8)
  System prompt (9)
  Tool registration (5)
"""

from __future__ import annotations

import pytest

from intent_api import IntentService
from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext
from intent_api_harness.engine import ChatEngine, ChatEngineConfig
from intent_api_harness.model_provider import StreamChunk
from intent_api_harness.tools.think_tool import ThinkTool
from intent_api_harness.tools.todo_tool import TodoItem, TodoStatus, TodoWriteTool


# ── Fixtures ──────────────────────────────────────────────────────────────────


class DummyService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        return []


def _make_registry() -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Dummy", DummyService())
    return registry


def _make_context() -> IntentContext:
    return IntentContext(type="user")


def _make_engine(**kwargs) -> ChatEngine:
    config = ChatEngineConfig(app_name="TestApp", **kwargs)

    class MockProvider:
        async def stream(self, messages, system_prompt=None, tools=None, max_output_tokens=None):
            yield StreamChunk(type="text", text="Done.")

        async def complete(self, *a, **kw):
            raise NotImplementedError

        async def extract(self, *a, **kw):
            raise NotImplementedError

    return ChatEngine(
        config=config,
        user={"id": "u1"},
        intent_context=_make_context(),
        registry=_make_registry(),
        model_provider=MockProvider(),
    )


# ── ThinkTool ─────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_think_tool_returns_reasoning_unchanged():
    tool = ThinkTool()
    result = await tool.call({"reasoning": "Step 1: list brands. Step 2: generate posts."}, engine=None)
    assert result.status == "success"
    assert result.data["reasoning"] == "Step 1: list brands. Step 2: generate posts."


@pytest.mark.asyncio
async def test_think_tool_display_is_thinking():
    tool = ThinkTool()
    result = await tool.call({"reasoning": "Some reasoning."}, engine=None)
    assert result.display == "Thinking..."


def test_think_tool_is_read_only():
    assert ThinkTool().is_read_only is True


# ── TodoWriteTool ─────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_todo_write_creates_list():
    tool = TodoWriteTool(session_id="s1")
    result = await tool.call({
        "todos": [
            {"content": "Load brands", "status": "in_progress", "active_form": "Loading brands"},
            {"content": "Generate posts", "status": "pending", "active_form": "Generating posts"},
        ]
    }, engine=None)
    assert result.status == "success"
    assert len(result.data["new_todos"]) == 2


@pytest.mark.asyncio
async def test_todo_write_returns_old_and_new_todos():
    tool = TodoWriteTool(session_id="s1")
    # First call
    await tool.call({"todos": [
        {"content": "Task A", "status": "in_progress", "active_form": "Doing A"},
    ]}, engine=None)
    # Second call — should have old todos from previous call
    result = await tool.call({"todos": [
        {"content": "Task A", "status": "completed", "active_form": "Doing A"},
        {"content": "Task B", "status": "in_progress", "active_form": "Doing B"},
    ]}, engine=None)
    assert len(result.data["old_todos"]) == 1
    assert result.data["old_todos"][0]["content"] == "Task A"


@pytest.mark.asyncio
async def test_todo_write_auto_clears_when_all_completed():
    tool = TodoWriteTool(session_id="s1")
    result = await tool.call({"todos": [
        {"content": "Task A", "status": "completed", "active_form": "Doing A"},
        {"content": "Task B", "status": "completed", "active_form": "Doing B"},
    ]}, engine=None)
    assert result.data["all_completed"] is True
    assert tool.current_todos == []


@pytest.mark.asyncio
async def test_todo_write_preserves_list_when_not_all_completed():
    tool = TodoWriteTool(session_id="s1")
    await tool.call({"todos": [
        {"content": "Task A", "status": "completed", "active_form": "Doing A"},
        {"content": "Task B", "status": "in_progress", "active_form": "Doing B"},
    ]}, engine=None)
    assert len(tool.current_todos) == 2


@pytest.mark.asyncio
async def test_todo_write_review_nudge_when_3_plus_completed():
    tool = TodoWriteTool(session_id="s1")
    result = await tool.call({"todos": [
        {"content": "Task A", "status": "completed", "active_form": "Doing A"},
        {"content": "Task B", "status": "completed", "active_form": "Doing B"},
        {"content": "Task C", "status": "completed", "active_form": "Doing C"},
    ]}, engine=None)
    assert "NOTE:" in result.message
    assert "3+" in result.message


@pytest.mark.asyncio
async def test_todo_write_no_nudge_when_fewer_than_3():
    tool = TodoWriteTool(session_id="s1")
    result = await tool.call({"todos": [
        {"content": "Task A", "status": "completed", "active_form": "Doing A"},
        {"content": "Task B", "status": "completed", "active_form": "Doing B"},
    ]}, engine=None)
    assert "NOTE:" not in result.message


@pytest.mark.asyncio
async def test_todo_write_display_shows_in_progress_active_form():
    tool = TodoWriteTool(session_id="s1")
    result = await tool.call({"todos": [
        {"content": "Load brands", "status": "in_progress", "active_form": "Loading brands"},
        {"content": "Generate", "status": "pending", "active_form": "Generating"},
    ]}, engine=None)
    assert result.display == "Loading brands"


def test_todo_write_per_session_isolation():
    tool1 = TodoWriteTool(session_id="session-1")
    tool2 = TodoWriteTool(session_id="session-2")
    # They start empty and are independent
    assert tool1.current_todos == []
    assert tool2.current_todos == []
    assert tool1 is not tool2


# ── System prompt ─────────────────────────────────────────────────────────────


def _get_prompt(**kwargs) -> str:
    from intent_api_harness.catalog import IntentCatalog
    from intent_api_harness.prompts.system import SystemPromptBuilder
    catalog = IntentCatalog([])
    builder = SystemPromptBuilder()
    return builder.build(app_name="TestApp", catalog=catalog, **kwargs)


def test_system_prompt_includes_thinking_instructions_when_enabled():
    prompt = _get_prompt(enable_thinking=True, enable_todos=True)
    assert "Think" in prompt
    assert "think" in prompt.lower()


def test_system_prompt_excludes_thinking_instructions_when_disabled():
    prompt = _get_prompt(enable_thinking=False, enable_todos=True)
    # The vocabulary bridge mentions Think, so check the planning-specific guidance
    assert "Think tool" not in prompt
    assert "think first" not in prompt.lower()


def test_system_prompt_includes_todo_instructions_when_enabled():
    prompt = _get_prompt(enable_thinking=True, enable_todos=True)
    assert "TodoWrite" in prompt


def test_system_prompt_excludes_todo_instructions_when_disabled():
    prompt = _get_prompt(enable_thinking=True, enable_todos=False)
    # Vocabulary bridge still mentions TodoWrite in tool list, but planning section gone
    assert "Break down and manage" not in prompt


def test_system_prompt_includes_parallel_tool_calls():
    prompt = _get_prompt()
    assert "parallel" in prompt.lower()
    assert "independently" in prompt.lower() or "dependencies" in prompt.lower()


def test_system_prompt_includes_failure_recovery():
    prompt = _get_prompt()
    assert "diagnose" in prompt.lower()
    assert "blindly" in prompt.lower() or "identical action" in prompt.lower()


def test_system_prompt_includes_output_efficiency():
    prompt = _get_prompt()
    assert "concise" in prompt.lower() or "straight to the point" in prompt.lower()


def test_custom_instructions_append_not_replace():
    prompt_without = _get_prompt()
    prompt_with = _get_prompt(custom_instructions="Always respond in French.")
    # Default sections still present
    assert "parallel" in prompt_with.lower()
    assert "Application instructions" in prompt_with
    assert "French" in prompt_with
    # Default sections not lost
    assert "diagnose" in prompt_with.lower()


def test_system_prompt_under_5k_tokens_excluding_catalog_and_memory():
    """Rough check: base prompt should be under 5000 * 4 chars = 20000 chars."""
    prompt = _get_prompt()
    # chars / 4 = token estimate
    estimated_tokens = len(prompt) // 4
    assert estimated_tokens < 5000, f"Base prompt is {estimated_tokens} estimated tokens"


# ── Tool registration ─────────────────────────────────────────────────────────


def test_default_config_registers_4_tools_in_correct_order():
    engine = _make_engine()
    names = [t.name for t in engine.tools]
    # Default: Think, TodoWrite, execute_intent, ToolSearchTool, EnterPlanMode
    assert names[:4] == ["Think", "TodoWrite", "execute_intent", "ToolSearchTool"]
    assert "EnterPlanMode" in names


def test_enable_thinking_false_registers_3_tools_no_think():
    engine = _make_engine(enable_thinking=False)
    names = [t.name for t in engine.tools]
    assert "Think" not in names
    assert "TodoWrite" in names
    assert "execute_intent" in names


def test_enable_todos_false_registers_3_tools_no_todo():
    engine = _make_engine(enable_todos=False)
    names = [t.name for t in engine.tools]
    assert "TodoWrite" not in names
    assert "Think" in names
    assert "execute_intent" in names


def test_both_disabled_registers_2_tools():
    engine = _make_engine(enable_thinking=False, enable_todos=False)
    names = [t.name for t in engine.tools]
    assert "Think" not in names
    assert "TodoWrite" not in names
    assert "execute_intent" in names
    assert "ToolSearchTool" in names


def test_tool_schemas_match_tool_count():
    engine = _make_engine()
    assert len(engine.tool_schemas) == len(engine.tools)
    schema_names = [s["function"]["name"] for s in engine.tool_schemas]
    tool_names = [t.name for t in engine.tools]
    assert schema_names == tool_names
