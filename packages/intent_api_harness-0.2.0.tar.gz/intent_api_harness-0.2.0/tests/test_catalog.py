"""
Tests for P1.W5 — Intent catalog generation.
"""

from __future__ import annotations

import pytest
from pydantic import BaseModel

from intent_api import IntentService, custom_action
from intent_api.registry import ServiceRegistry
from intent_api_harness.catalog import IntentCatalog, _crud_display


# ── Test services ─────────────────────────────────────────────────────────────


class _KeywordPayload(BaseModel):
    keyword: str


class BrandService(IntentService):
    __display_prefix__ = "Brand"

    async def list(self, *, db, user, context, skip, limit):
        return []

    async def create(self, *, db, user, context, payload):
        return {}

    async def read(self, *, db, user, context, id):
        return {}


class BlogPostService(IntentService):
    __display_prefix__ = "Blog Post"

    async def list(self, *, db, user, context, skip, limit):
        return []

    @custom_action(
        schema=_KeywordPayload,
        display="Generating blog posts",
        description="Generate blog posts from a keyword",
    )
    async def generate(self, *, db, user, context, id, payload):
        return {}

    @custom_action(name="export_mdx", display="Exporting as MDX")
    async def export(self, *, db, user, context, id, payload):
        return {}


class InternalService(IntentService):
    async def list(self, *, db, user, context, skip, limit):
        return []


# ── Build registry + catalog ──────────────────────────────────────────────────


def _make_registry(include_internal_in_chat: bool = False) -> ServiceRegistry:
    registry = ServiceRegistry()
    registry.register("Brand", BrandService())
    registry.register("BlogPost", BlogPostService())
    registry.register(
        "Internal",
        InternalService(),
        expose_chat=include_internal_in_chat,
    )
    return registry


# ── Tests ─────────────────────────────────────────────────────────────────────


def test_catalog_includes_chat_exposed_only():
    registry = _make_registry(include_internal_in_chat=False)
    catalog = IntentCatalog.from_registry(registry)
    models = {e.model for e in catalog.entries}
    assert "Brand" in models
    assert "BlogPost" in models
    assert "Internal" not in models


def test_catalog_includes_internal_when_chat_exposed():
    registry = _make_registry(include_internal_in_chat=True)
    catalog = IntentCatalog.from_registry(registry)
    models = {e.model for e in catalog.entries}
    assert "Internal" in models


def test_crud_entries_generated():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    brand_entries = [e for e in catalog.entries if e.model == "Brand"]
    actions = {e.action for e in brand_entries}
    assert "list" in actions
    assert "create" in actions
    assert "read" in actions


def test_custom_command_entries_generated():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    blog_entries = [e for e in catalog.entries if e.model == "BlogPost"]
    commands = {e.command for e in blog_entries if e.action == "custom"}
    assert "generate" in commands
    assert "export_mdx" in commands


def test_custom_command_display_from_decorator():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    generate = next(
        e for e in catalog.entries
        if e.model == "BlogPost" and e.command == "generate"
    )
    assert generate.display == "Generating blog posts"


def test_custom_command_description_from_decorator():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    generate = next(
        e for e in catalog.entries
        if e.model == "BlogPost" and e.command == "generate"
    )
    assert generate.description == "Generate blog posts from a keyword"


def test_crud_display_uses_display_prefix():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    brand_list = next(e for e in catalog.entries if e.model == "Brand" and e.action == "list")
    assert "Brand" in brand_list.display


def test_crud_entry_read_type():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    brand_list = next(e for e in catalog.entries if e.model == "Brand" and e.action == "list")
    assert brand_list.type == "read"


def test_crud_entry_write_type():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    brand_create = next(e for e in catalog.entries if e.model == "Brand" and e.action == "create")
    assert brand_create.type == "write"


def test_payload_schema_simplified():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    generate = next(
        e for e in catalog.entries
        if e.model == "BlogPost" and e.command == "generate"
    )
    assert generate.payload_schema is not None
    assert "keyword" in generate.payload_schema


def test_search_by_query():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    results = catalog.search(query="blog")
    models = {e.model for e in results}
    assert "BlogPost" in models


def test_search_by_model():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    results = catalog.search(query="", model="brand")
    assert all(e.model == "Brand" for e in results)


def test_search_by_action():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    results = catalog.search(query="", action="list")
    assert all(e.action == "list" for e in results)


def test_search_no_results():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    results = catalog.search(query="xyznonexistent123")
    assert results == []


def test_to_compact_text_contains_models():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    text = catalog.to_compact_text()
    assert "Brand" in text
    assert "BlogPost" in text


def test_catalog_len():
    registry = _make_registry()
    catalog = IntentCatalog.from_registry(registry)
    assert len(catalog) > 0


# ── _crud_display helper ──────────────────────────────────────────────────────


def test_crud_display_list():
    assert _crud_display("list", "Brand") == "Loading Brand list"


def test_crud_display_create():
    assert _crud_display("create", "Blog Post") == "Creating Blog Post"


def test_crud_display_delete():
    assert _crud_display("delete", "User") == "Deleting User"
