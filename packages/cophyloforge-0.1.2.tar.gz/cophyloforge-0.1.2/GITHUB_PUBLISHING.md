# GitHub Publishing Guide

This guide covers first-time repository setup and pushing code/tags for `CoPhyloForge`.

## 1. Initialize Git (If Needed)

Run this only if `.git/` does not exist yet:

```bash
git init -b main
git add -A
git commit -m "Initial import for cophyloforge packaging"
```

## 2. Add a Remote

If the remote is not configured:

```bash
git remote add origin git@github.com:<OWNER_OR_ORG>/CoPhyloForge.git
```

If it already exists, verify it:

```bash
git remote -v
```

## 3. Create the GitHub Repository with `gh` (Optional)

If you want `gh` to create the repo and wire `origin` automatically:

```bash
gh auth login
gh repo create <OWNER_OR_ORG>/CoPhyloForge --source=. --remote=origin --private
```

Use `--public` instead of `--private` if the repository should be public.

## 4. Push the Main Branch

```bash
git push -u origin main
```

## 5. Push Release Tags

```bash
git tag -a v0.1.0 -m "cophyloforge 0.1.0"
git push origin v0.1.0
```

## 6. Verify GitHub Actions

Check runs in the web UI (`Actions` tab) or via CLI:

```bash
gh run list --workflow ci.yml
gh run list --workflow publish.yml
```

The `publish.yml` workflow should run only when a `v*` tag is pushed.
