"""Command line interface for CophyloForge."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Sequence

from . import __version__
from .api import batch_predict as api_batch_predict
from .api import download_model as api_download_model
from .api import predict as api_predict
from .io import format_validation, validate_input_files, write_association_template
from .model_registry import DEFAULT_MODEL_NAME, ModelDownloadError, ModelRegistryError, describe_model, get_model_info


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cophyloforge", description="CophyloForge CPU inference tools")
    parser.add_argument("--cache-dir", type=Path, default=None, help="Override the model cache directory")
    subparsers = parser.add_subparsers(dest="command", required=True)

    version = subparsers.add_parser("version", help="Print package and default model information")
    version.set_defaults(func=_cmd_version)

    download = subparsers.add_parser("download-model", help="Download and cache a model artifact")
    download.add_argument("--model", default=DEFAULT_MODEL_NAME, help="Model name from the registry")
    download.add_argument("--force", action="store_true", help="Redownload even if the model is already cached")
    download.set_defaults(func=_cmd_download_model)

    validate = subparsers.add_parser("validate-input", help="Validate one host/symbiont tree and association table")
    validate.add_argument("--host-tree", required=True, type=Path, help="Host tree in Newick format")
    validate.add_argument("--sym-tree", required=True, type=Path, help="Symbiont tree in Newick format")
    validate.add_argument("--associations", required=True, type=Path, help="Association TSV/CSV file")
    validate.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    validate.set_defaults(func=_cmd_validate_input)

    template = subparsers.add_parser("init-association-template", help="Write a blank association TSV template from tree tip labels")
    template.add_argument("--host-tree", required=True, type=Path, help="Host tree in Newick format")
    template.add_argument("--sym-tree", required=True, type=Path, help="Symbiont tree in Newick format")
    template.add_argument("--format", required=True, choices=["edge", "matrix"], help="Template format to write")
    template.add_argument("--out", required=True, type=Path, help="Output TSV path")
    template.set_defaults(func=_cmd_init_association_template)

    predict = subparsers.add_parser("predict", help="Run inference for one case")
    predict.add_argument("--host-tree", required=True, type=Path, help="Host tree in Newick format")
    predict.add_argument("--sym-tree", required=True, type=Path, help="Symbiont tree in Newick format")
    predict.add_argument("--associations", required=True, type=Path, help="Association TSV/CSV file")
    predict.add_argument("--outdir", required=True, type=Path, help="Directory for JSON/TSV/report outputs")
    predict.add_argument("--model", default=DEFAULT_MODEL_NAME, help="Registry model name or local checkpoint path")
    predict.add_argument("--abstain-threshold", type=float, default=0.5, help="Probability threshold for recommended_abstain")
    predict.set_defaults(func=_cmd_predict)

    batch = subparsers.add_parser("batch-predict", help="Run inference for many cases")
    source = batch.add_mutually_exclusive_group(required=True)
    source.add_argument("--manifest", type=Path, help="CSV/JSONL manifest with host_tree,sym_tree,associations columns")
    source.add_argument("--input-dir", type=Path, help="Folder containing cases")
    batch.add_argument("--outdir", required=True, type=Path, help="Directory for batch outputs")
    batch.add_argument("--model", default=DEFAULT_MODEL_NAME, help="Registry model name or local checkpoint path")
    batch.add_argument("--abstain-threshold", type=float, default=0.5, help="Probability threshold for recommended_abstain")
    batch.set_defaults(func=_cmd_batch_predict)
    return parser


def _cmd_version(args: argparse.Namespace) -> int:
    print(f"cophyloforge {__version__}")
    print(describe_model(DEFAULT_MODEL_NAME, cache_dir=args.cache_dir))
    return 0


def _cmd_download_model(args: argparse.Namespace) -> int:
    cached = api_download_model(model_name=args.model, force=args.force, cache_dir=args.cache_dir)
    print(f"model: {cached.info.name}")
    print(f"version: {cached.info.version}")
    print(f"source: {cached.info.doi}")
    print(f"path: {cached.path}")
    if cached.checksum:
        print(f"checksum: {cached.checksum}")
    return 0


def _cmd_validate_input(args: argparse.Namespace) -> int:
    validation = validate_input_files(args.host_tree, args.sym_tree, args.associations)
    if args.json:
        print(json.dumps(validation.to_dict(), indent=2, sort_keys=True))
    else:
        print(format_validation(validation))
    return 0 if validation.valid else 2


def _cmd_init_association_template(args: argparse.Namespace) -> int:
    output = write_association_template(args.host_tree, args.sym_tree, args.out, args.format)
    print(f"template: {output}")
    print(f"format: {args.format}")
    return 0


def _cmd_predict(args: argparse.Namespace) -> int:
    validation = validate_input_files(args.host_tree, args.sym_tree, args.associations)
    if not validation.valid:
        print(format_validation(validation), file=sys.stderr)
        return 2
    result = api_predict(
        args.host_tree,
        args.sym_tree,
        args.associations,
        model=args.model,
        outdir=args.outdir,
        return_dict=True,
        cache_dir=args.cache_dir,
        abstain_threshold=args.abstain_threshold,
    )
    assert result is not None
    print(json.dumps(result, indent=2, sort_keys=True))
    print(f"outputs: {args.outdir}")
    return 0


def _cmd_batch_predict(args: argparse.Namespace) -> int:
    results = api_batch_predict(
        manifest=args.manifest,
        folder=args.input_dir,
        outdir=args.outdir,
        model=args.model,
        cache_dir=args.cache_dir,
        abstain_threshold=args.abstain_threshold,
    )
    print(f"processed: {len(results)}")
    print(f"outputs: {args.outdir}")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (FileNotFoundError, ValueError, ModelRegistryError, ModelDownloadError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
