"""Input parsing and validation for CophyloForge prediction."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


class InputError(ValueError):
    """Raised when user input files are malformed."""


@dataclass
class NewickNode:
    name: str = ""
    length: float = 0.0
    children: list["NewickNode"] | None = None

    def __post_init__(self) -> None:
        if self.children is None:
            self.children = []


@dataclass(frozen=True)
class Association:
    symbiont: str
    host: str


@dataclass(frozen=True)
class AssociationTable:
    rows: tuple[Association, ...]
    source: Path
    format: str
    duplicate_links: tuple[Association, ...] = ()
    empty_rows: int = 0

    @property
    def symbionts(self) -> set[str]:
        return {row.symbiont for row in self.rows}

    @property
    def hosts(self) -> set[str]:
        return {row.host for row in self.rows}


@dataclass(frozen=True)
class TreeSummary:
    path: Path
    leaf_count: int
    node_count: int
    max_depth: int
    leaf_names: tuple[str, ...]


@dataclass(frozen=True)
class InputValidation:
    host_tree: TreeSummary
    sym_tree: TreeSummary
    association_count: int
    unique_associated_hosts: int
    unique_associated_symbionts: int
    association_format: str
    duplicate_links: tuple[Association, ...]
    empty_rows: int
    unknown_hosts: tuple[str, ...]
    unknown_symbionts: tuple[str, ...]
    warnings: tuple[str, ...]

    @property
    def valid(self) -> bool:
        return not self.unknown_hosts and not self.unknown_symbionts

    def to_dict(self) -> dict[str, object]:
        return {
            "valid": self.valid,
            "host_leaf_count": self.host_tree.leaf_count,
            "sym_leaf_count": self.sym_tree.leaf_count,
            "host_node_count": self.host_tree.node_count,
            "sym_node_count": self.sym_tree.node_count,
            "association_count": self.association_count,
            "unique_associated_hosts": self.unique_associated_hosts,
            "unique_associated_symbionts": self.unique_associated_symbionts,
            "association_format": self.association_format,
            "duplicate_links": [{"host": row.host, "symbiont": row.symbiont} for row in self.duplicate_links],
            "empty_rows": self.empty_rows,
            "unknown_hosts": list(self.unknown_hosts),
            "unknown_symbionts": list(self.unknown_symbionts),
            "warnings": list(self.warnings),
        }


class _NewickParser:
    def __init__(self, text: str) -> None:
        self.text = text.strip()
        self.pos = 0

    def parse(self) -> NewickNode:
        if not self.text:
            raise InputError("Newick file is empty.")
        node = self._parse_subtree()
        self._skip_ws()
        if self._peek() == ";":
            self.pos += 1
        self._skip_ws()
        if self.pos != len(self.text):
            raise InputError(f"Unexpected Newick suffix at offset {self.pos}: {self.text[self.pos:self.pos + 20]!r}")
        return node

    def _parse_subtree(self) -> NewickNode:
        self._skip_ws()
        if self._peek() == "(":
            self.pos += 1
            children: list[NewickNode] = []
            while True:
                children.append(self._parse_subtree())
                self._skip_ws()
                char = self._peek()
                if char == ",":
                    self.pos += 1
                    continue
                if char == ")":
                    self.pos += 1
                    break
                raise InputError(f"Expected ',' or ')' in Newick at offset {self.pos}.")
            name, length = self._parse_name_length()
            return NewickNode(name=name, length=length, children=children)
        name, length = self._parse_name_length(required_name=True)
        return NewickNode(name=name, length=length)

    def _parse_name_length(self, required_name: bool = False) -> tuple[str, float]:
        self._skip_ws()
        name = self._parse_name()
        if required_name and not name:
            raise InputError(f"Missing Newick leaf label at offset {self.pos}.")
        self._skip_ws()
        length = 0.0
        if self._peek() == ":":
            self.pos += 1
            token = self._read_until({",", ")", ";"}).strip()
            if token:
                try:
                    length = float(token)
                except ValueError:
                    length = 0.0
        return name, length

    def _parse_name(self) -> str:
        self._skip_ws()
        if self._peek() in {"'", '"'}:
            quote = self._peek()
            self.pos += 1
            chars: list[str] = []
            while self.pos < len(self.text):
                char = self.text[self.pos]
                self.pos += 1
                if char == quote:
                    break
                chars.append(char)
            return "".join(chars).strip()
        return self._read_until({":", ",", ")", ";"}).strip()

    def _read_until(self, stop_chars: set[str]) -> str:
        start = self.pos
        while self.pos < len(self.text) and self.text[self.pos] not in stop_chars:
            self.pos += 1
        return self.text[start:self.pos]

    def _skip_ws(self) -> None:
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def _peek(self) -> str:
        return "" if self.pos >= len(self.text) else self.text[self.pos]


def read_newick(path: Path | str) -> NewickNode:
    path = Path(path)
    if not path.is_file():
        raise InputError(f"Tree file does not exist: {path}")
    return _NewickParser(path.read_text(encoding="utf-8")).parse()


def iter_nodes(root: NewickNode) -> Iterable[tuple[NewickNode, int]]:
    stack: list[tuple[NewickNode, int]] = [(root, 0)]
    while stack:
        node, depth = stack.pop()
        yield node, depth
        for child in reversed(node.children or []):
            stack.append((child, depth + 1))


def leaf_names(root: NewickNode) -> list[str]:
    return [node.name for node, _ in iter_nodes(root) if not node.children and node.name]


def summarize_tree(path: Path | str, root: NewickNode | None = None) -> TreeSummary:
    path = Path(path)
    root = root or read_newick(path)
    nodes = list(iter_nodes(root))
    leaves = [node.name for node, _depth in nodes if not node.children and node.name]
    return TreeSummary(
        path=path,
        leaf_count=len(leaves),
        node_count=len(nodes),
        max_depth=max((depth for _node, depth in nodes), default=0),
        leaf_names=tuple(leaves),
    )


def _sniff_delimiter(line: str) -> str:
    return "," if line.count(",") > line.count("\t") else "\t"


def _truthy_cell(value: str) -> bool:
    text = value.strip().lower()
    return text not in {"", "0", "false", "f", "no", "n", "none", "na", "nan"}


def _normalise_header(value: str) -> str:
    return value.strip().lower().replace("-", "_").replace(" ", "_")


def _split_hosts(value: str) -> list[str]:
    hosts: list[str] = []
    for chunk in value.replace(",", ";").split(";"):
        host = chunk.strip()
        if host:
            hosts.append(host)
    return hosts


def _deduplicate(rows: Sequence[Association]) -> tuple[tuple[Association, ...], tuple[Association, ...]]:
    seen: set[Association] = set()
    unique: list[Association] = []
    duplicates: list[Association] = []
    duplicate_seen: set[Association] = set()
    for row in rows:
        if row in seen:
            if row not in duplicate_seen:
                duplicates.append(row)
                duplicate_seen.add(row)
            continue
        seen.add(row)
        unique.append(row)
    return tuple(unique), tuple(duplicates)


def read_associations(path: Path | str) -> AssociationTable:
    """Read edge-list or binary matrix association files.

    The public formats are:
    - edge-list TSV/CSV with required columns ``host`` and ``symbiont``
    - binary matrix TSV/CSV with symbionts in the first column and hosts in the remaining columns

    A legacy ``symbiont`` + ``hosts_semicolon_separated`` table remains supported for
    compatibility with historical research outputs.
    """
    path = Path(path)
    if not path.is_file():
        raise InputError(f"Association file does not exist: {path}")
    text = path.read_text(encoding="utf-8")
    raw_lines = [line for line in text.splitlines() if not line.lstrip().startswith("#")]
    empty_rows = sum(1 for line in raw_lines if not line.strip())
    lines = [line for line in raw_lines if line.strip()]
    if not lines:
        return AssociationTable(rows=(), source=path, format="empty", empty_rows=empty_rows)

    delimiter = _sniff_delimiter(lines[0])
    reader = csv.reader(lines, delimiter=delimiter)
    rows = list(reader)
    if not rows:
        return AssociationTable(rows=(), source=path, format="empty", empty_rows=empty_rows)

    header = [_normalise_header(cell) for cell in rows[0]]
    data_rows = rows[1:]
    associations: list[Association] = []

    sym_candidates = ("symbiont", "sym", "symbiont_id", "sym_tip", "parasite", "parasite_id")
    host_candidates = ("host", "host_id", "host_tip")
    hosts_candidates = ("hosts", "hosts_semicolon_separated", "host_list", "associated_hosts")
    sym_idx = next((header.index(name) for name in sym_candidates if name in header), None)
    host_idx = next((header.index(name) for name in host_candidates if name in header), None)
    hosts_idx = next((header.index(name) for name in hosts_candidates if name in header), None)

    if host_idx is not None and sym_idx is not None and len(header) == 2:
        for row in data_rows:
            if not any(cell.strip() for cell in row):
                empty_rows += 1
                continue
            if len(row) <= max(sym_idx, host_idx):
                continue
            sym = row[sym_idx].strip()
            host = row[host_idx].strip()
            if sym and host:
                associations.append(Association(symbiont=sym, host=host))
            else:
                empty_rows += 1
        unique, duplicates = _deduplicate(associations)
        return AssociationTable(rows=unique, source=path, format="edge-list", duplicate_links=duplicates, empty_rows=empty_rows)

    if sym_idx is not None and hosts_idx is not None:
        for row in data_rows:
            if not any(cell.strip() for cell in row):
                empty_rows += 1
                continue
            if len(row) <= max(sym_idx, hosts_idx):
                continue
            sym = row[sym_idx].strip()
            if not sym:
                empty_rows += 1
                continue
            for host in _split_hosts(row[hosts_idx]):
                if host:
                    associations.append(Association(symbiont=sym, host=host))
        unique, duplicates = _deduplicate(associations)
        return AssociationTable(rows=unique, source=path, format="legacy-symbiont-hosts", duplicate_links=duplicates, empty_rows=empty_rows)

    if len(header) >= 2:
        for row in data_rows:
            if not row or not any(cell.strip() for cell in row):
                empty_rows += 1
                continue
            sym = row[0].strip()
            if not sym:
                empty_rows += 1
                continue
            for index, cell in enumerate(row[1:], start=1):
                if index < len(rows[0]) and _truthy_cell(cell):
                    host = rows[0][index].strip()
                    if sym and host:
                        associations.append(Association(symbiont=sym, host=host))
        unique, duplicates = _deduplicate(associations)
        return AssociationTable(rows=unique, source=path, format="matrix", duplicate_links=duplicates, empty_rows=empty_rows)

    raise InputError(
        "Association file must be a TSV/CSV edge table, a symbiont-to-hosts table, or a binary association matrix."
    )


def validate_input_files(host_tree: Path | str, sym_tree: Path | str, associations: Path | str) -> InputValidation:
    host_root = read_newick(host_tree)
    sym_root = read_newick(sym_tree)
    assoc_table = read_associations(associations)
    host_summary = summarize_tree(host_tree, host_root)
    sym_summary = summarize_tree(sym_tree, sym_root)
    host_set = set(host_summary.leaf_names)
    sym_set = set(sym_summary.leaf_names)
    unknown_hosts = tuple(sorted(assoc_table.hosts - host_set))
    unknown_symbionts = tuple(sorted(assoc_table.symbionts - sym_set))
    warnings: list[str] = []
    if assoc_table.format not in {"edge-list", "matrix"}:
        warnings.append(
            f"Association file format is {assoc_table.format}; public examples use edge-list or matrix format."
        )
    if not assoc_table.rows:
        warnings.append("No valid observed associations were found.")
    if assoc_table.duplicate_links:
        warnings.append(f"{len(assoc_table.duplicate_links)} duplicate association links were ignored.")
    if assoc_table.empty_rows:
        warnings.append(f"{assoc_table.empty_rows} empty or incomplete association rows were ignored.")
    if host_summary.leaf_count == 0:
        warnings.append("Host tree has no named leaves.")
    if sym_summary.leaf_count == 0:
        warnings.append("Symbiont tree has no named leaves.")
    unassociated_hosts = host_set - assoc_table.hosts
    unassociated_symbionts = sym_set - assoc_table.symbionts
    if unassociated_hosts:
        warnings.append(f"{len(unassociated_hosts)} host leaves have no observed association.")
    if unassociated_symbionts:
        warnings.append(f"{len(unassociated_symbionts)} symbiont leaves have no observed association.")
    return InputValidation(
        host_tree=host_summary,
        sym_tree=sym_summary,
        association_count=len(assoc_table.rows),
        unique_associated_hosts=len(assoc_table.hosts),
        unique_associated_symbionts=len(assoc_table.symbionts),
        association_format=assoc_table.format,
        duplicate_links=assoc_table.duplicate_links,
        empty_rows=assoc_table.empty_rows,
        unknown_hosts=unknown_hosts,
        unknown_symbionts=unknown_symbionts,
        warnings=tuple(warnings),
    )


def format_validation(validation: InputValidation) -> str:
    lines = [
        f"valid: {validation.valid}",
        f"host tree: {validation.host_tree.leaf_count} leaves, {validation.host_tree.node_count} nodes",
        f"symbiont tree: {validation.sym_tree.leaf_count} leaves, {validation.sym_tree.node_count} nodes",
        f"association format: {validation.association_format}",
        f"associations: {validation.association_count}",
        f"hosts in tree: {validation.host_tree.leaf_count}",
        f"symbionts in tree: {validation.sym_tree.leaf_count}",
        f"associated hosts: {validation.unique_associated_hosts}",
        f"associated symbionts: {validation.unique_associated_symbionts}",
        f"duplicate links: {len(validation.duplicate_links)}",
        f"empty rows: {validation.empty_rows}",
    ]
    if validation.unknown_hosts:
        lines.append("missing host names not found in host tree: " + ", ".join(validation.unknown_hosts[:10]))
    if validation.unknown_symbionts:
        lines.append("missing symbiont names not found in symbiont tree: " + ", ".join(validation.unknown_symbionts[:10]))
    if validation.duplicate_links:
        preview = ", ".join(f"{row.host}-{row.symbiont}" for row in validation.duplicate_links[:10])
        lines.append("duplicate link examples: " + preview)
    for warning in validation.warnings:
        lines.append(f"warning: {warning}")
    return "\n".join(lines)


def write_association_template(
    host_tree: Path | str,
    sym_tree: Path | str,
    output: Path | str,
    template_format: str = "edge",
) -> Path:
    """Write a blank edge-list or zero-filled matrix association template."""
    host_summary = summarize_tree(host_tree)
    sym_summary = summarize_tree(sym_tree)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if template_format == "edge":
        content = "host\tsymbiont\n"
    elif template_format == "matrix":
        header = ["symbiont", *host_summary.leaf_names]
        lines = ["\t".join(header)]
        for sym_name in sym_summary.leaf_names:
            lines.append("\t".join([sym_name, *(["0"] * host_summary.leaf_count)]))
        content = "\n".join(lines) + "\n"
    else:
        raise InputError("Template format must be 'edge' or 'matrix'.")
    output.write_text(content, encoding="utf-8")
    return output
