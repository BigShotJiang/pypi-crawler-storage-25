"""CPU inference for frozen CophyloForge checkpoints."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

import torch
from torch import nn

from . import __version__
from .preprocess import DEFAULT_METADATA_FIELDS, REGRESSION_TARGETS, DatasetSchema, build_prediction_batch_from_files, move_batch_to_device


@dataclass
class ModelConfig:
    tree_feature_dim: int = 10
    hidden_dim: int = 128
    metadata_dim: int = len(DEFAULT_METADATA_FIELDS)
    metadata_hidden_dim: int = 64
    gnn_layers: int = 4
    interaction_layers: int = 2
    dropout: float = 0.10
    activation_checkpointing: bool = False
    scenario_classes: list[str] = field(default_factory=list)
    event_names: list[str] = field(default_factory=list)
    regression_targets: list[str] = field(default_factory=lambda: list(REGRESSION_TARGETS))


@dataclass
class LoadedModel:
    model: "CophyloMultitaskModel"
    schema: DatasetSchema
    config: ModelConfig
    checkpoint_path: Path
    checkpoint_metadata: dict[str, Any]


class GraphConvLayer(nn.Module):
    def __init__(self, hidden_dim: int, dropout: float) -> None:
        super().__init__()
        self.update = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
        )
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        if edge_index.numel() == 0:
            agg = torch.zeros_like(h)
        else:
            src, dst = edge_index[0], edge_index[1]
            agg = torch.zeros_like(h)
            agg.index_add_(0, dst, h[src])
            deg = torch.zeros((h.shape[0], 1), dtype=h.dtype, device=h.device)
            deg.index_add_(0, dst, torch.ones((dst.shape[0], 1), dtype=h.dtype, device=h.device))
            agg = agg / deg.clamp_min(1.0)
        delta = self.update(torch.cat([h, agg], dim=-1))
        return self.norm(h + delta)


class TreeEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, layers: int, dropout: float) -> None:
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim),
            nn.Dropout(dropout),
        )
        self.layers = nn.ModuleList([GraphConvLayer(hidden_dim, dropout) for _ in range(layers)])

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        h = self.input(x)
        for layer in self.layers:
            h = layer(h, edge_index)
        return h


class AssociationInteractionLayer(nn.Module):
    def __init__(self, hidden_dim: int, dropout: float) -> None:
        super().__init__()
        self.host_update = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.sym_update = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.host_norm = nn.LayerNorm(hidden_dim)
        self.sym_norm = nn.LayerNorm(hidden_dim)

    def forward(self, host_h: torch.Tensor, sym_h: torch.Tensor, assoc_index: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if assoc_index.numel() == 0:
            return host_h, sym_h
        host_idx, sym_idx = assoc_index[0], assoc_index[1]
        host_msg = torch.zeros_like(host_h)
        host_msg.index_add_(0, host_idx, sym_h[sym_idx])
        host_deg = torch.zeros((host_h.shape[0], 1), dtype=host_h.dtype, device=host_h.device)
        host_deg.index_add_(0, host_idx, torch.ones((host_idx.shape[0], 1), dtype=host_h.dtype, device=host_h.device))
        host_msg = host_msg / host_deg.clamp_min(1.0)

        sym_msg = torch.zeros_like(sym_h)
        sym_msg.index_add_(0, sym_idx, host_h[host_idx])
        sym_deg = torch.zeros((sym_h.shape[0], 1), dtype=sym_h.dtype, device=sym_h.device)
        sym_deg.index_add_(0, sym_idx, torch.ones((sym_idx.shape[0], 1), dtype=sym_h.dtype, device=sym_h.device))
        sym_msg = sym_msg / sym_deg.clamp_min(1.0)

        host_h = self.host_norm(host_h + self.host_update(torch.cat([host_h, host_msg], dim=-1)))
        sym_h = self.sym_norm(sym_h + self.sym_update(torch.cat([sym_h, sym_msg], dim=-1)))
        return host_h, sym_h


def _pool_mean_max(h: torch.Tensor, batch: torch.Tensor, batch_size: int) -> tuple[torch.Tensor, torch.Tensor]:
    hidden_dim = h.shape[-1]
    sums = torch.zeros((batch_size, hidden_dim), dtype=h.dtype, device=h.device)
    sums.index_add_(0, batch, h)
    counts = torch.zeros((batch_size, 1), dtype=h.dtype, device=h.device)
    counts.index_add_(0, batch, torch.ones((batch.shape[0], 1), dtype=h.dtype, device=h.device))
    means = sums / counts.clamp_min(1.0)
    maxes = []
    for batch_idx in range(batch_size):
        values = h[batch == batch_idx]
        if values.numel() == 0:
            maxes.append(torch.zeros((hidden_dim,), dtype=h.dtype, device=h.device))
        else:
            maxes.append(values.max(dim=0).values)
    return means, torch.stack(maxes, dim=0)


class CophyloMultitaskModel(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        if not config.scenario_classes:
            raise ValueError("ModelConfig.scenario_classes must be populated.")
        self.config = config
        self.host_encoder = TreeEncoder(config.tree_feature_dim, config.hidden_dim, config.gnn_layers, config.dropout)
        self.sym_encoder = TreeEncoder(config.tree_feature_dim, config.hidden_dim, config.gnn_layers, config.dropout)
        self.interactions = nn.ModuleList(
            [AssociationInteractionLayer(config.hidden_dim, config.dropout) for _ in range(config.interaction_layers)]
        )
        self.metadata_encoder = (
            nn.Sequential(
                nn.Linear(config.metadata_dim * 2, config.metadata_hidden_dim),
                nn.GELU(),
                nn.LayerNorm(config.metadata_hidden_dim),
                nn.Dropout(config.dropout),
            )
            if config.metadata_dim > 0
            else None
        )
        metadata_width = config.metadata_hidden_dim if config.metadata_dim > 0 else 0
        joint_width = config.hidden_dim * 5 + metadata_width
        self.trunk = nn.Sequential(
            nn.Linear(joint_width, config.hidden_dim * 2),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim * 2, config.hidden_dim),
            nn.GELU(),
            nn.LayerNorm(config.hidden_dim),
        )
        self.scenario_head = nn.Linear(config.hidden_dim, len(config.scenario_classes))
        self.regression_head = nn.Linear(config.hidden_dim, len(config.regression_targets))
        self.abstain_head = nn.Linear(config.hidden_dim, 1)
        self.event_head = nn.Linear(config.hidden_dim, len(config.event_names)) if config.event_names else None

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        batch_size = int(batch["metadata"].shape[0])
        host_h = self.host_encoder(batch["host_x"], batch["host_edge_index"])
        sym_h = self.sym_encoder(batch["sym_x"], batch["sym_edge_index"])
        for layer in self.interactions:
            host_h, sym_h = layer(host_h, sym_h, batch["assoc_index"])

        host_mean, host_max = _pool_mean_max(host_h, batch["host_batch"], batch_size)
        sym_mean, sym_max = _pool_mean_max(sym_h, batch["sym_batch"], batch_size)
        pieces = [host_mean, host_max, sym_mean, sym_max, torch.abs(host_mean - sym_mean)]
        if self.metadata_encoder is not None:
            metadata = torch.cat([batch["metadata"], batch["metadata_mask"]], dim=-1)
            pieces.append(self.metadata_encoder(metadata))
        z = self.trunk(torch.cat(pieces, dim=-1))
        outputs = {
            "scenario_logits": self.scenario_head(z),
            "regression": self.regression_head(z),
            "abstain_logit": self.abstain_head(z).squeeze(-1),
        }
        if self.event_head is not None:
            outputs["event_logits"] = self.event_head(z)
        else:
            outputs["event_logits"] = torch.zeros((batch_size, 0), dtype=z.dtype, device=z.device)
        return outputs


def model_config_from_dict(data: Mapping[str, Any]) -> ModelConfig:
    cfg = ModelConfig()
    for key, value in data.items():
        if hasattr(cfg, key):
            setattr(cfg, key, value)
    return cfg


def _torch_load(path: Path, map_location: torch.device) -> dict[str, Any]:
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def load_model_from_checkpoint(checkpoint_path: Path | str, device: str | torch.device = "cpu") -> LoadedModel:
    checkpoint_path = Path(checkpoint_path)
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"Model checkpoint does not exist: {checkpoint_path}")
    torch_device = torch.device(device)
    checkpoint = _torch_load(checkpoint_path, torch_device)
    if not isinstance(checkpoint, Mapping) or "model_state" not in checkpoint:
        raise ValueError(f"Checkpoint {checkpoint_path} is not a CophyloForge frozen checkpoint.")
    extra = dict(checkpoint.get("extra") or {})
    schema = DatasetSchema.from_dict(extra.get("schema", {}))
    if not schema.scenario_classes:
        raise ValueError("Checkpoint is missing scenario class metadata.")
    model_cfg = model_config_from_dict(extra.get("model_config", {}))
    model_cfg.scenario_classes = schema.scenario_classes
    model_cfg.event_names = schema.event_names
    model_cfg.metadata_dim = len(schema.metadata_fields)
    model_cfg.regression_targets = schema.regression_targets
    model_cfg.activation_checkpointing = False
    model = CophyloMultitaskModel(model_cfg).to(torch_device)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    return LoadedModel(model=model, schema=schema, config=model_cfg, checkpoint_path=checkpoint_path, checkpoint_metadata=extra)


def _prediction_payload(
    outputs: Mapping[str, torch.Tensor],
    schema: DatasetSchema,
    model_name: str,
    model_version: str,
    model_source: str,
    host_tree: Path,
    sym_tree: Path,
    associations: Path,
    abstain_threshold: float,
) -> dict[str, Any]:
    scenario_probs_tensor = torch.softmax(outputs["scenario_logits"].float().cpu(), dim=-1)[0]
    scenario_idx = int(scenario_probs_tensor.argmax().item())
    scenario_probabilities = {
        schema.scenario_classes[index]: float(scenario_probs_tensor[index].item())
        for index in range(len(schema.scenario_classes))
    }
    regression = outputs["regression"].float().cpu()[0]
    abstain_probability = float(torch.sigmoid(outputs["abstain_logit"].float().cpu())[0].item())
    result: dict[str, Any] = {
        "package_version": __version__,
        "model_name": model_name,
        "model_version": model_version,
        "model_source": model_source,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "inputs": {
            "host_tree": str(host_tree),
            "sym_tree": str(sym_tree),
            "associations": str(associations),
        },
        "scenario_prediction": schema.scenario_classes[scenario_idx],
        "scenario_confidence": float(scenario_probs_tensor[scenario_idx].item()),
        "scenario_probabilities": scenario_probabilities,
        "abstain_probability": abstain_probability,
        "recommended_abstain": bool(abstain_probability >= abstain_threshold),
    }
    for index, name in enumerate(schema.regression_targets):
        result[name] = float(regression[index].item())
    return result


@torch.no_grad()
def predict_one(
    checkpoint_path: Path | str,
    host_tree: Path | str,
    sym_tree: Path | str,
    associations: Path | str,
    model_name: str,
    model_version: str,
    model_source: str,
    metadata: Mapping[str, Any] | None = None,
    abstain_threshold: float = 0.5,
    device: str | torch.device = "cpu",
) -> dict[str, Any]:
    loaded = load_model_from_checkpoint(checkpoint_path, device=device)
    torch_device = torch.device(device)
    batch = build_prediction_batch_from_files(
        host_tree,
        sym_tree,
        associations,
        loaded.schema,
        metadata=metadata,
        example_id=Path(host_tree).stem,
    )
    batch = move_batch_to_device(batch, torch_device)
    outputs = loaded.model(batch)
    return _prediction_payload(
        outputs=outputs,
        schema=loaded.schema,
        model_name=model_name,
        model_version=model_version,
        model_source=model_source,
        host_tree=Path(host_tree),
        sym_tree=Path(sym_tree),
        associations=Path(associations),
        abstain_threshold=abstain_threshold,
    )


def checkpoint_payload_for_tests(config: ModelConfig, schema: DatasetSchema) -> dict[str, Any]:
    """Create a checkpoint payload for lightweight smoke tests."""
    model = CophyloMultitaskModel(config)
    return {
        "model_state": model.state_dict(),
        "extra": {
            "schema": schema.to_dict(),
            "model_config": asdict(config),
            "frozen": True,
        },
    }
