"""Public API for the CophyloForge inference package."""

from __future__ import annotations

__version__ = "0.1.0"

from .api import download_model, init_association_template, predict, validate_input
from .model_registry import DEFAULT_MODEL_NAME, DEFAULT_MODEL_RECORD

__all__ = [
    "__version__",
    "DEFAULT_MODEL_NAME",
    "DEFAULT_MODEL_RECORD",
    "download_model",
    "init_association_template",
    "predict",
    "validate_input",
]
