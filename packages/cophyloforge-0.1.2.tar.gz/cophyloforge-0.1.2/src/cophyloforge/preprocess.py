"""Feature conversion for CophyloForge inference."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import torch

from .io import AssociationTable, NewickNode, read_associations, read_newick


TREE_FEATURE_DIM = 10
REGRESSION_TARGETS = [
    "tracking_score",
    "switch_score",
    "multi_host_fraction",
    "difficulty_score",
]
DEFAULT_METADATA_FIELDS = [
    "n_hosts",
    "bootstrap_reps",
    "host_seq_len",
    "sym_seq_len",
    "host_obs_sampled_tips",
    "sym_obs_sampled_tips",
    "mean_observed_associations_per_symbiont",
]


@dataclass
class DatasetSchema:
    scenario_classes: list[str]
    regression_targets: list[str] = field(default_factory=lambda: list(REGRESSION_TARGETS))
    metadata_fields: list[str] = field(default_factory=lambda: list(DEFAULT_METADATA_FIELDS))
    event_names: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "scenario_classes": list(self.scenario_classes),
            "regression_targets": list(self.regression_targets),
            "metadata_fields": list(self.metadata_fields),
            "event_names": list(self.event_names),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "DatasetSchema":
        return cls(
            scenario_classes=list(data.get("scenario_classes", [])),
            regression_targets=list(data.get("regression_targets", REGRESSION_TARGETS)),
            metadata_fields=list(data.get("metadata_fields", DEFAULT_METADATA_FIELDS)),
            event_names=list(data.get("event_names", [])),
        )


@dataclass
class TreeGraph:
    x: torch.Tensor
    edge_index: torch.Tensor
    tip_name_to_node: dict[str, int]


def _safe_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        x = float(value)
        return x if math.isfinite(x) else None
    if isinstance(value, str):
        if value.lower() in {"true", "false"}:
            return 1.0 if value.lower() == "true" else 0.0
        try:
            x = float(value)
        except ValueError:
            return None
        return x if math.isfinite(x) else None
    return None


def tree_to_graph(root: NewickNode) -> TreeGraph:
    raw_nodes: list[dict[str, Any]] = []
    edges: list[tuple[int, int]] = []
    tip_name_to_node: dict[str, int] = {}

    def walk(node: NewickNode, parent: int | None, depth: int, branch_depth: float) -> int:
        idx = len(raw_nodes)
        children = node.children or []
        is_tip = len(children) == 0
        branch_length = max(float(node.length or 0.0), 0.0)
        raw_nodes.append(
            {
                "name": node.name,
                "branch_length": branch_length,
                "depth": depth,
                "branch_depth": branch_depth,
                "child_count": len(children),
                "parent": parent,
                "is_tip": is_tip,
                "subtree_tips": 0,
            }
        )
        if parent is not None:
            edges.append((parent, idx))
            edges.append((idx, parent))
        if is_tip and node.name:
            tip_name_to_node[node.name] = idx
            raw_nodes[idx]["subtree_tips"] = 1
            return 1
        total_tips = 0
        for child in children:
            total_tips += walk(child, idx, depth + 1, branch_depth + max(float(child.length or 0.0), 0.0))
        raw_nodes[idx]["subtree_tips"] = total_tips
        return max(total_tips, 1)

    total_tips = walk(root, None, 0, 0.0)
    max_depth = max(1, max(node["depth"] for node in raw_nodes))
    max_branch_depth = max(1.0, max(node["branch_depth"] for node in raw_nodes))
    denom_preorder = max(1, len(raw_nodes) - 1)
    features: list[list[float]] = []
    for idx, node in enumerate(raw_nodes):
        child_count = float(node["child_count"])
        parent_degree = 0.0 if node["parent"] is None else 1.0
        total_degree = child_count + parent_degree
        branch_length = float(node["branch_length"])
        features.append(
            [
                float(node["depth"]) / float(max_depth),
                branch_length,
                math.log1p(branch_length),
                min(child_count / 8.0, 1.0),
                min(total_degree / 9.0, 1.0),
                1.0 if node["is_tip"] else 0.0,
                1.0 if node["parent"] is None else 0.0,
                float(idx) / float(denom_preorder),
                float(node["subtree_tips"]) / float(max(1, total_tips)),
                float(node["branch_depth"]) / float(max_branch_depth),
            ]
        )
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous() if edges else torch.zeros((2, 0), dtype=torch.long)
    return TreeGraph(x=torch.tensor(features, dtype=torch.float32), edge_index=edge_index, tip_name_to_node=tip_name_to_node)


def associations_to_index(table: AssociationTable, host: TreeGraph, sym: TreeGraph) -> torch.Tensor:
    edges: list[tuple[int, int]] = []
    for row in table.rows:
        host_idx = host.tip_name_to_node.get(row.host)
        sym_idx = sym.tip_name_to_node.get(row.symbiont)
        if host_idx is not None and sym_idx is not None:
            edges.append((host_idx, sym_idx))
    return torch.tensor(edges, dtype=torch.long).t().contiguous() if edges else torch.zeros((2, 0), dtype=torch.long)


def metadata_tensors(
    schema: DatasetSchema,
    host: TreeGraph,
    sym: TreeGraph,
    associations: AssociationTable,
    metadata: Mapping[str, Any] | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    values_by_name: dict[str, Any] = dict(metadata or {})
    host_tip_count = sum(1 for _name in host.tip_name_to_node)
    sym_tip_count = sum(1 for _name in sym.tip_name_to_node)
    values_by_name.setdefault("n_hosts", host_tip_count)
    values_by_name.setdefault("host_obs_sampled_tips", host_tip_count)
    values_by_name.setdefault("sym_obs_sampled_tips", sym_tip_count)
    if sym_tip_count:
        values_by_name.setdefault("mean_observed_associations_per_symbiont", len(associations.rows) / float(sym_tip_count))

    values: list[float] = []
    mask: list[float] = []
    aliases = {
        "n_hosts": ["n_hosts", "host_n_hosts"],
        "bootstrap_reps": ["bootstrap_reps", "bootstrap_replicates"],
        "host_seq_len": ["host_seq_len"],
        "sym_seq_len": ["sym_seq_len"],
    }
    for field_name in schema.metadata_fields:
        candidates = aliases.get(field_name, [field_name])
        raw = None
        for candidate in candidates:
            if candidate in values_by_name:
                raw = values_by_name[candidate]
                break
        numeric = _safe_float(raw)
        if numeric is None:
            values.append(0.0)
            mask.append(0.0)
        else:
            values.append(numeric)
            mask.append(1.0)
    return torch.tensor(values, dtype=torch.float32), torch.tensor(mask, dtype=torch.float32)


def build_prediction_batch(
    host_root: NewickNode,
    sym_root: NewickNode,
    associations: AssociationTable,
    schema: DatasetSchema,
    metadata: Mapping[str, Any] | None = None,
    example_id: str = "case",
) -> dict[str, Any]:
    host = tree_to_graph(host_root)
    sym = tree_to_graph(sym_root)
    assoc_index = associations_to_index(associations, host, sym)
    metadata_tensor, metadata_mask = metadata_tensors(schema, host, sym, associations, metadata)
    return {
        "example_id": [example_id],
        "host_x": host.x,
        "host_edge_index": host.edge_index,
        "host_batch": torch.zeros((host.x.shape[0],), dtype=torch.long),
        "sym_x": sym.x,
        "sym_edge_index": sym.edge_index,
        "sym_batch": torch.zeros((sym.x.shape[0],), dtype=torch.long),
        "assoc_index": assoc_index,
        "metadata": metadata_tensor.unsqueeze(0),
        "metadata_mask": metadata_mask.unsqueeze(0),
    }


def build_prediction_batch_from_files(
    host_tree: Path | str,
    sym_tree: Path | str,
    associations: Path | str,
    schema: DatasetSchema,
    metadata: Mapping[str, Any] | None = None,
    example_id: str = "case",
) -> dict[str, Any]:
    return build_prediction_batch(
        read_newick(host_tree),
        read_newick(sym_tree),
        read_associations(associations),
        schema,
        metadata=metadata,
        example_id=example_id,
    )


def move_batch_to_device(batch: dict[str, Any], device: torch.device) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in batch.items():
        out[key] = value.to(device) if torch.is_tensor(value) else value
    return out
