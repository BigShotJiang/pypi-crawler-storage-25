"""Prediction report writers."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Mapping


SUMMARY_COLUMNS = [
    "package_version",
    "model_name",
    "model_version",
    "model_source",
    "timestamp",
    "scenario_prediction",
    "scenario_confidence",
    "tracking_score",
    "switch_score",
    "multi_host_fraction",
    "difficulty_score",
    "abstain_probability",
    "recommended_abstain",
]


def write_json(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def write_tsv(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    row = {column: payload.get(column, "") for column in SUMMARY_COLUMNS}
    inputs = payload.get("inputs")
    if isinstance(inputs, Mapping):
        row["host_tree"] = inputs.get("host_tree", "")
        row["sym_tree"] = inputs.get("sym_tree", "")
        row["associations"] = inputs.get("associations", "")
    probabilities = payload.get("scenario_probabilities")
    if isinstance(probabilities, Mapping):
        for key, value in probabilities.items():
            row[f"probability_{key}"] = value
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(row), delimiter="\t")
        writer.writeheader()
        writer.writerow(row)
    return path


def write_text_report(path: Path, payload: Mapping[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "CophyloForge prediction report",
        "",
        f"scenario: {payload.get('scenario_prediction')}",
        f"confidence: {payload.get('scenario_confidence')}",
        f"recommended_abstain: {payload.get('recommended_abstain')}",
        f"model: {payload.get('model_name')} {payload.get('model_version')}",
        f"source: {payload.get('model_source')}",
        "",
        "scores:",
        f"tracking_score: {payload.get('tracking_score')}",
        f"switch_score: {payload.get('switch_score')}",
        f"multi_host_fraction: {payload.get('multi_host_fraction')}",
        f"difficulty_score: {payload.get('difficulty_score')}",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def write_prediction_outputs(payload: Mapping[str, Any], outdir: Path | str, prefix: str = "prediction") -> dict[str, Path]:
    outdir = Path(outdir)
    return {
        "json": write_json(outdir / f"{prefix}.json", payload),
        "tsv": write_tsv(outdir / f"{prefix}.tsv", payload),
        "report": write_text_report(outdir / f"{prefix}_report.txt", payload),
    }
