"""Model registry and Zenodo-backed downloader."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from . import __version__
from .cache import CacheError, Checksum, download_file, model_cache_dir, parse_checksum, verify_file


DEFAULT_MODEL_NAME = "default"
DEFAULT_MODEL_RECORD = "10.5281/zenodo.19656529"


class ModelRegistryError(RuntimeError):
    """Raised when a model cannot be resolved from the registry."""


class ModelDownloadError(RuntimeError):
    """Raised when a model cannot be downloaded or verified."""


@dataclass(frozen=True)
class ModelInfo:
    name: str
    version: str
    doi: str
    source_url: str
    api_url: str
    architecture: str
    filename: str
    checksum: str | None = None
    min_package_version: str = "0.1.0"
    description: str = "Frozen CophyloForge inference checkpoint"


@dataclass(frozen=True)
class CachedModel:
    info: ModelInfo
    path: Path
    metadata_path: Path
    cached: bool
    checksum: str | None = None
    size_bytes: int | None = None
    source_record: Mapping[str, Any] | None = None


MODEL_REGISTRY: dict[str, ModelInfo] = {
    DEFAULT_MODEL_NAME: ModelInfo(
        name=DEFAULT_MODEL_NAME,
        version="0.1.0",
        doi=DEFAULT_MODEL_RECORD,
        source_url=f"https://doi.org/{DEFAULT_MODEL_RECORD}",
        api_url="https://zenodo.org/api/records/19656529",
        architecture="CophyloMultitaskModel",
        filename="best_frozen.pt",
        checksum=None,
        min_package_version="0.1.0",
        description="Default archived CophyloForge frozen inference checkpoint",
    )
}


def list_models() -> list[ModelInfo]:
    return list(MODEL_REGISTRY.values())


def get_model_info(model_name: str = DEFAULT_MODEL_NAME) -> ModelInfo:
    try:
        return MODEL_REGISTRY[model_name]
    except KeyError as exc:
        available = ", ".join(sorted(MODEL_REGISTRY))
        raise ModelRegistryError(f"Unknown model {model_name!r}. Available models: {available}") from exc


def _metadata_path(cache_path: Path) -> Path:
    return cache_path.with_suffix(cache_path.suffix + ".json")


def cached_model_path(info: ModelInfo, cache_dir: Path | str | None = None) -> Path:
    return model_cache_dir(info.name, info.version, cache_dir) / info.filename


def get_cached_model(model_name: str = DEFAULT_MODEL_NAME, cache_dir: Path | str | None = None) -> CachedModel | None:
    info = get_model_info(model_name)
    path = cached_model_path(info, cache_dir)
    metadata_path = _metadata_path(path)
    if not path.is_file():
        return None
    checksum = info.checksum
    size_bytes = path.stat().st_size
    source_record: Mapping[str, Any] | None = None
    if metadata_path.is_file():
        try:
            data = json.loads(metadata_path.read_text(encoding="utf-8"))
            checksum = data.get("checksum") or checksum
            size_bytes = data.get("size_bytes") or size_bytes
            source_record = data.get("source_record")
        except (OSError, json.JSONDecodeError):
            pass
    return CachedModel(info=info, path=path, metadata_path=metadata_path, cached=True, checksum=checksum, size_bytes=size_bytes, source_record=source_record)


def fetch_zenodo_record(info: ModelInfo, timeout: int = 60) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(info.api_url, timeout=timeout) as response:
            payload = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise ModelDownloadError(f"Zenodo returned HTTP {exc.code} for {info.api_url}.") from exc
    except urllib.error.URLError as exc:
        raise ModelDownloadError(f"Could not reach Zenodo record {info.api_url}: {exc}") from exc
    try:
        record = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise ModelDownloadError(f"Zenodo returned invalid JSON for {info.api_url}.") from exc
    if not isinstance(record, dict):
        raise ModelDownloadError(f"Zenodo record {info.api_url} did not return an object.")
    return record


def _file_key(file_record: Mapping[str, Any]) -> str:
    return str(file_record.get("key") or file_record.get("filename") or file_record.get("name") or "")


def _file_url(file_record: Mapping[str, Any]) -> str | None:
    links = file_record.get("links")
    if isinstance(links, Mapping):
        for key in ("self", "content", "download"):
            value = links.get(key)
            if value:
                return str(value)
    value = file_record.get("download_url") or file_record.get("url")
    return str(value) if value else None


def select_zenodo_file(record: Mapping[str, Any], preferred_filename: str) -> Mapping[str, Any]:
    files = record.get("files") or []
    if not isinstance(files, list) or not files:
        raise ModelDownloadError("The Zenodo record does not list downloadable files.")
    by_name = {Path(_file_key(item)).name: item for item in files if isinstance(item, Mapping)}
    if preferred_filename in by_name:
        return by_name[preferred_filename]
    candidates = [item for item in files if isinstance(item, Mapping)]
    pt_files = [item for item in candidates if _file_key(item).lower().endswith((".pt", ".pth"))]
    for item in pt_files:
        key = _file_key(item).lower()
        if "frozen" in key and "best" in key:
            return item
    if pt_files:
        return pt_files[0]
    raise ModelDownloadError(
        f"The Zenodo record does not contain {preferred_filename!r} or another .pt/.pth checkpoint."
    )


def _record_summary(record: Mapping[str, Any]) -> dict[str, Any]:
    metadata = record.get("metadata") if isinstance(record.get("metadata"), Mapping) else {}
    return {
        "id": record.get("id"),
        "doi": record.get("doi") or metadata.get("doi"),
        "version": metadata.get("version"),
        "title": metadata.get("title"),
        "created": record.get("created"),
        "modified": record.get("modified"),
    }


def download_model(
    model_name: str = DEFAULT_MODEL_NAME,
    force: bool = False,
    cache_dir: Path | str | None = None,
    timeout: int = 120,
) -> CachedModel:
    info = get_model_info(model_name)
    destination = cached_model_path(info, cache_dir)
    metadata_path = _metadata_path(destination)

    checksum = parse_checksum(info.checksum)
    if destination.is_file() and not force:
        try:
            verify_file(destination, checksum)
        except CacheError as exc:
            raise ModelDownloadError(str(exc)) from exc
        cached = get_cached_model(model_name, cache_dir)
        if cached is not None:
            return cached

    record = fetch_zenodo_record(info, timeout=timeout)
    file_record = select_zenodo_file(record, info.filename)
    url = _file_url(file_record)
    if not url:
        raise ModelDownloadError(f"Selected Zenodo file {_file_key(file_record)!r} has no download URL.")

    checksum_text = info.checksum or str(file_record.get("checksum") or "")
    checksum = parse_checksum(checksum_text)
    try:
        download_file(url, destination, checksum=checksum, timeout=timeout)
    except CacheError as exc:
        raise ModelDownloadError(str(exc)) from exc

    metadata = {
        "model": asdict(info),
        "package_version": __version__,
        "source_record": _record_summary(record),
        "zenodo_file": {
            "key": _file_key(file_record),
            "size": file_record.get("size"),
            "checksum": file_record.get("checksum"),
            "url": url,
        },
        "checksum": checksum_text or None,
        "size_bytes": destination.stat().st_size,
    }
    metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return CachedModel(
        info=info,
        path=destination,
        metadata_path=metadata_path,
        cached=True,
        checksum=checksum_text or None,
        size_bytes=destination.stat().st_size,
        source_record=metadata["source_record"],
    )


def describe_model(model_name: str = DEFAULT_MODEL_NAME, cache_dir: Path | str | None = None) -> str:
    info = get_model_info(model_name)
    cached = get_cached_model(model_name, cache_dir)
    status = f"cached at {cached.path}" if cached else "not cached"
    return (
        f"{info.name} model {info.version}\n"
        f"architecture: {info.architecture}\n"
        f"source: {info.doi} ({info.source_url})\n"
        f"cache: {status}"
    )


def resolve_model_path(model: str | Path = DEFAULT_MODEL_NAME, cache_dir: Path | str | None = None) -> tuple[Path, ModelInfo]:
    path = Path(model).expanduser()
    if path.is_file():
        return path, ModelInfo(
            name=path.stem,
            version="local",
            doi="local",
            source_url=str(path),
            api_url="",
            architecture="CophyloMultitaskModel",
            filename=path.name,
        )
    info = get_model_info(str(model))
    cached = get_cached_model(info.name, cache_dir)
    if cached is None:
        raise ModelRegistryError(
            f"Model {info.name!r} is not cached. Run 'cophyloforge download-model --model {info.name}' first."
        )
    return cached.path, info
