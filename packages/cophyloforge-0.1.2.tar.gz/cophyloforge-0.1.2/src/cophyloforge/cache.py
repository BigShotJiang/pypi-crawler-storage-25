"""Model cache and integrity helpers."""

from __future__ import annotations

import hashlib
import os
import sys
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO


class CacheError(RuntimeError):
    """Raised when a model cannot be cached or verified."""


@dataclass(frozen=True)
class Checksum:
    algorithm: str
    hexdigest: str


def user_cache_dir(app_name: str = "cophyloforge") -> Path:
    """Return a standard per-user cache directory without extra dependencies."""
    override = os.environ.get("COPHYLOFORGE_CACHE_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or Path.home() / "AppData" / "Local"
        return Path(base) / app_name
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / app_name
    base = os.environ.get("XDG_CACHE_HOME")
    return (Path(base).expanduser() if base else Path.home() / ".cache") / app_name


def model_cache_dir(model_name: str, model_version: str, cache_dir: Path | str | None = None) -> Path:
    root = Path(cache_dir).expanduser() if cache_dir else user_cache_dir()
    safe_name = model_name.replace("/", "_")
    safe_version = model_version.replace("/", "_")
    return root / "models" / safe_name / safe_version


def parse_checksum(value: str | None) -> Checksum | None:
    if not value:
        return None
    text = value.strip()
    if not text:
        return None
    if ":" in text:
        algorithm, hexdigest = text.split(":", 1)
    else:
        algorithm, hexdigest = "sha256", text
    algorithm = algorithm.lower().replace("-", "")
    if algorithm not in hashlib.algorithms_available:
        return None
    return Checksum(algorithm=algorithm, hexdigest=hexdigest.lower())


def file_hexdigest(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().lower()


def verify_file(path: Path, checksum: Checksum | None) -> None:
    if checksum is None:
        return
    actual = file_hexdigest(path, checksum.algorithm)
    if actual != checksum.hexdigest:
        raise CacheError(
            f"Checksum mismatch for {path}. Expected {checksum.algorithm}:{checksum.hexdigest}, got {actual}."
        )


def _copy_stream(src: BinaryIO, destination: Path) -> None:
    with destination.open("wb") as out:
        while True:
            chunk = src.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)


def download_file(url: str, destination: Path, checksum: Checksum | None = None, timeout: int = 120) -> Path:
    """Download a URL atomically and verify it when a supported checksum is available."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=destination.name + ".", suffix=".tmp", dir=str(destination.parent))
    os.close(fd)
    tmp_path = Path(tmp_name)
    try:
        try:
            with urllib.request.urlopen(url, timeout=timeout) as response:
                _copy_stream(response, tmp_path)
        except urllib.error.URLError as exc:
            raise CacheError(f"Could not download model artifact from {url}: {exc}") from exc
        verify_file(tmp_path, checksum)
        tmp_path.replace(destination)
        return destination
    finally:
        if tmp_path.exists():
            tmp_path.unlink()
