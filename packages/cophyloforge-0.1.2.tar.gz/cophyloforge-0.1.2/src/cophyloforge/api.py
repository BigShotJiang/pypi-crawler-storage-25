"""Compact public Python API for CophyloForge."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from .io import InputValidation, validate_input_files, write_association_template
from .model_registry import DEFAULT_MODEL_NAME, CachedModel, download_model as _download_model, resolve_model_path
from .report import write_prediction_outputs


def download_model(
    model_name: str = DEFAULT_MODEL_NAME,
    force: bool = False,
    cache_dir: Path | str | None = None,
) -> CachedModel:
    """Download and cache a named model artifact."""
    return _download_model(model_name=model_name, force=force, cache_dir=cache_dir)


def validate_input(host_tree: Path | str, sym_tree: Path | str, associations: Path | str) -> InputValidation:
    """Validate input files and return a structured summary."""
    return validate_input_files(host_tree, sym_tree, associations)


def init_association_template(
    host_tree: Path | str,
    sym_tree: Path | str,
    output: Path | str,
    template_format: str = "edge",
) -> Path:
    """Create a blank edge-list or zero-filled matrix association template."""
    return write_association_template(host_tree, sym_tree, output, template_format)


def predict(
    host_tree: Path | str,
    sym_tree: Path | str,
    associations: Path | str,
    model: str | Path = DEFAULT_MODEL_NAME,
    outdir: Path | str | None = None,
    return_dict: bool = True,
    metadata: Mapping[str, Any] | None = None,
    cache_dir: Path | str | None = None,
    abstain_threshold: float = 0.5,
) -> dict[str, Any] | None:
    """Run one CPU prediction from tree and association files."""
    from .inference import predict_one

    checkpoint_path, info = resolve_model_path(model, cache_dir=cache_dir)
    result = predict_one(
        checkpoint_path=checkpoint_path,
        host_tree=host_tree,
        sym_tree=sym_tree,
        associations=associations,
        model_name=info.name,
        model_version=info.version,
        model_source=info.doi if info.doi != "local" else info.source_url,
        metadata=metadata,
        abstain_threshold=abstain_threshold,
        device="cpu",
    )
    if outdir is not None:
        write_prediction_outputs(result, outdir)
    return result if return_dict else None


def _iter_manifest_rows(path: Path) -> Iterable[dict[str, str]]:
    if path.suffix.lower() == ".jsonl":
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    yield json.loads(line)
        return
    with path.open("r", encoding="utf-8", newline="") as fh:
        yield from csv.DictReader(fh)


def _case_from_folder(folder: Path) -> dict[str, str] | None:
    candidates = [
        {
            "host_tree": folder / "host.nwk",
            "sym_tree": folder / "sym.nwk",
            "associations": folder / "assoc.tsv",
        },
        {
            "host_tree": folder / "trees" / "host_obs_sampled.nwk",
            "sym_tree": folder / "trees" / "sym_obs_sampled.nwk",
            "associations": folder / "associations" / "assoc_obs.tsv",
        },
    ]
    for case in candidates:
        if all(Path(value).is_file() for value in case.values()):
            return {key: str(value) for key, value in case.items()}
    return None


def discover_cases(manifest: Path | str | None = None, folder: Path | str | None = None) -> list[dict[str, str]]:
    """Return cases from a CSV/JSONL manifest or from child folders."""
    if manifest is not None:
        manifest_path = Path(manifest)
        base_dir = manifest_path.parent
        rows = []
        for row in _iter_manifest_rows(manifest_path):
            def resolve(value: str) -> str:
                path = Path(value)
                return str(path if path.is_absolute() else base_dir / path)

            try:
                rows.append(
                    {
                        "case_id": str(row.get("case_id") or row.get("id") or len(rows)),
                        "host_tree": resolve(str(row["host_tree"])),
                        "sym_tree": resolve(str(row["sym_tree"])),
                        "associations": resolve(str(row["associations"])),
                    }
                )
            except KeyError as exc:
                raise ValueError("Batch manifest must contain host_tree, sym_tree, and associations columns.") from exc
        return rows
    if folder is None:
        raise ValueError("Provide either a manifest file or an input folder.")
    root = Path(folder)
    cases: list[dict[str, str]] = []
    direct = _case_from_folder(root)
    if direct:
        direct["case_id"] = root.name or "case"
        cases.append(direct)
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        case = _case_from_folder(child)
        if case:
            case["case_id"] = child.name
            cases.append(case)
    if not cases:
        raise ValueError(f"No prediction cases found under {root}.")
    return cases


def batch_predict(
    manifest: Path | str | None = None,
    folder: Path | str | None = None,
    outdir: Path | str = "cophyloforge_batch_results",
    model: str | Path = DEFAULT_MODEL_NAME,
    cache_dir: Path | str | None = None,
    abstain_threshold: float = 0.5,
) -> list[dict[str, Any]]:
    """Run prediction for every case listed in a manifest or folder."""
    cases = discover_cases(manifest=manifest, folder=folder)
    outdir = Path(outdir)
    results = []
    for case in cases:
        case_outdir = outdir / str(case.get("case_id", len(results)))
        result = predict(
            case["host_tree"],
            case["sym_tree"],
            case["associations"],
            model=model,
            outdir=case_outdir,
            return_dict=True,
            cache_dir=cache_dir,
            abstain_threshold=abstain_threshold,
        )
        assert result is not None
        result["case_id"] = case.get("case_id")
        results.append(result)
    outdir.mkdir(parents=True, exist_ok=True)
    summary_path = outdir / "batch_summary.json"
    summary_path.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return results
