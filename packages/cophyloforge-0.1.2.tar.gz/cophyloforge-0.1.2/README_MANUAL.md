# cophyloforge Manual

This manual is a practical guide for using and releasing the `cophyloforge` end-user package in this mixed research + package repository.

## 1. What Is In This Repository

- Installable package: `src/cophyloforge/`
- Tests for package behavior: `tests/`
- Research/simulation/training code and outputs: top-level research folders (`cophylo_dataset_*`, `runs/`, `sim_out/`, `manuscript/`, etc.)

Only the package and required metadata are intended for PyPI distribution.

## 2. Install for End Users

```bash
python -m pip install cophyloforge
```

## 3. Core CLI Commands

```bash
cophyloforge --help
cophyloforge version
cophyloforge download-model --model default
cophyloforge validate-input --host-tree host.nwk --sym-tree sym.nwk --associations assoc.tsv
cophyloforge predict --host-tree host.nwk --sym-tree sym.nwk --associations assoc.tsv --outdir results
```

## 4. Model Behavior

- The frozen model is not embedded in wheel/sdist artifacts.
- `download-model` resolves the default registry entry for DOI `10.5281/zenodo.19656529`.
- Artifacts are stored in user cache (`~/.cache/cophyloforge` on Linux by default).

## 5. Developer Setup

```bash
python -m pip install --upgrade pip
python -m pip install -e ".[dev]" || python -m pip install -e .
pytest
```

## 6. Local Packaging Check

```bash
rm -rf build dist *.egg-info src/*.egg-info
python -m build
python -m twine check dist/*
```

## 7. Release Flow

Follow [RELEASE.md](RELEASE.md) for the exact release/tag/publish steps.

## 8. GitHub Push Flow

Follow [GITHUB_PUBLISHING.md](GITHUB_PUBLISHING.md) for first-time git/remote setup and push commands.

## 9. PyPI Trusted Publishing Setup

Follow [PYPI_PUBLISHING.md](PYPI_PUBLISHING.md) to configure PyPI trusted publisher fields.
