# PyPI Trusted Publishing Setup

This repository publishes `cophyloforge` from GitHub Actions using PyPA Trusted Publishing.

## Trusted Publisher Checklist

On `pypi.org` for project `cophyloforge`, configure:

- PyPI project name: `cophyloforge`
- GitHub owner/account or organization: `<GITHUB_OWNER>`
- Repository name: `CoPhyloForge`
- Workflow filename: `publish.yml`
- Environment name: `pypi`

These values must match the repository and workflow exactly.

## How Publishing Works

- Release publishing happens from `.github/workflows/publish.yml`.
- The workflow triggers only on git tags matching `v*`.
- When a tag like `v0.1.0` is pushed, GitHub Actions builds distributions and publishes to PyPI.
- GitHub Actions OIDC is used, so no long-lived PyPI API token is needed in the normal workflow.

## GitHub Workflow Permissions

The publish workflow uses:

- `id-token: write`
- `contents: read`
