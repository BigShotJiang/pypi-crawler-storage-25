from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import torch

from cophyloforge.inference import ModelConfig, checkpoint_payload_for_tests, predict_one
from cophyloforge.preprocess import DEFAULT_METADATA_FIELDS, REGRESSION_TARGETS, DatasetSchema


def _write_fixture_inputs(tmp_path: Path) -> tuple[Path, Path, Path]:
    host = tmp_path / "host.nwk"
    sym = tmp_path / "sym.nwk"
    assoc = tmp_path / "assoc.tsv"
    host.write_text("(h1:1,h2:1)hroot;\n", encoding="utf-8")
    sym.write_text("(s1:1,s2:1)sroot;\n", encoding="utf-8")
    assoc.write_text("symbiont\th1\th2\ns1\t1\t0\ns2\t0\t1\n", encoding="utf-8")
    return host, sym, assoc


def test_inference_smoke_with_tiny_checkpoint(tmp_path: Path) -> None:
    schema = DatasetSchema(
        scenario_classes=["tracking", "switch_dominated"],
        regression_targets=list(REGRESSION_TARGETS),
        metadata_fields=list(DEFAULT_METADATA_FIELDS),
        event_names=[],
    )
    config = ModelConfig(
        hidden_dim=8,
        metadata_dim=len(schema.metadata_fields),
        metadata_hidden_dim=4,
        gnn_layers=1,
        interaction_layers=1,
        dropout=0.0,
        activation_checkpointing=False,
        scenario_classes=schema.scenario_classes,
        event_names=schema.event_names,
        regression_targets=schema.regression_targets,
    )
    checkpoint = tmp_path / "tiny.pt"
    torch.save(checkpoint_payload_for_tests(config, schema), checkpoint)
    host, sym, assoc = _write_fixture_inputs(tmp_path)

    result = predict_one(
        checkpoint,
        host,
        sym,
        assoc,
        model_name="tiny",
        model_version="test",
        model_source="local",
    )

    assert result["scenario_prediction"] in schema.scenario_classes
    assert set(result["scenario_probabilities"]) == set(schema.scenario_classes)
    assert "tracking_score" in result
    assert "recommended_abstain" in result
