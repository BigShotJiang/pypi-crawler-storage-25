from __future__ import annotations

from pathlib import Path

from cophyloforge.io import read_associations, validate_input_files, write_association_template


def test_validate_input_table(tmp_path: Path) -> None:
    host = tmp_path / "host.nwk"
    sym = tmp_path / "sym.nwk"
    assoc = tmp_path / "assoc.tsv"
    host.write_text("(h1:1,h2:1)hroot;\n", encoding="utf-8")
    sym.write_text("(s1:1,s2:1)sroot;\n", encoding="utf-8")
    assoc.write_text("host\tsymbiont\nh1\ts1\nh2\ts1\n", encoding="utf-8")

    validation = validate_input_files(host, sym, assoc)

    assert validation.valid
    assert validation.association_format == "edge-list"
    assert validation.host_tree.leaf_count == 2
    assert validation.sym_tree.leaf_count == 2
    assert validation.association_count == 2


def test_read_association_matrix(tmp_path: Path) -> None:
    assoc = tmp_path / "assoc.tsv"
    assoc.write_text("symbiont\th1\th2\ns1\t1\t0\ns2\tfalse\ttrue\n", encoding="utf-8")

    table = read_associations(assoc)

    assert {(row.symbiont, row.host) for row in table.rows} == {("s1", "h1"), ("s2", "h2")}
    assert table.format == "matrix"


def test_validate_reports_duplicates_empty_and_unknown_names(tmp_path: Path) -> None:
    host = tmp_path / "host.nwk"
    sym = tmp_path / "sym.nwk"
    assoc = tmp_path / "assoc.tsv"
    host.write_text("(h1:1,h2:1)hroot;\n", encoding="utf-8")
    sym.write_text("(s1:1,s2:1)sroot;\n", encoding="utf-8")
    assoc.write_text("host\tsymbiont\nh1\ts1\nh1\ts1\n\nmissing_host\tmissing_sym\n\t\n", encoding="utf-8")

    validation = validate_input_files(host, sym, assoc)

    assert not validation.valid
    assert validation.unknown_hosts == ("missing_host",)
    assert validation.unknown_symbionts == ("missing_sym",)
    assert len(validation.duplicate_links) == 1
    assert validation.empty_rows >= 2


def test_write_matrix_template(tmp_path: Path) -> None:
    host = tmp_path / "host.nwk"
    sym = tmp_path / "sym.nwk"
    out = tmp_path / "template.tsv"
    host.write_text("(h1:1,h2:1)hroot;\n", encoding="utf-8")
    sym.write_text("(s1:1,s2:1)sroot;\n", encoding="utf-8")

    write_association_template(host, sym, out, "matrix")

    assert out.read_text(encoding="utf-8").splitlines() == [
        "symbiont\th1\th2",
        "s1\t0\t0",
        "s2\t0\t0",
    ]
