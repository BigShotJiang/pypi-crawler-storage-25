from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

from cophyloforge import model_registry


def test_cli_help() -> None:
    result = subprocess.run([sys.executable, "-m", "cophyloforge.cli", "--help"], check=False, text=True, capture_output=True)
    assert result.returncode == 0
    assert "download-model" in result.stdout
    assert "init-association-template" in result.stdout
    assert "predict" in result.stdout


def test_cli_version() -> None:
    result = subprocess.run([sys.executable, "-m", "cophyloforge.cli", "version"], check=False, text=True, capture_output=True)
    assert result.returncode == 0
    assert "cophyloforge" in result.stdout
    assert "10.5281/zenodo.19656529" in result.stdout


def test_model_registry_mock_download(tmp_path: Path, monkeypatch) -> None:
    source = tmp_path / "source.pt"
    source.write_bytes(b"fake checkpoint bytes")
    digest = hashlib.md5(source.read_bytes()).hexdigest()

    def fake_record(_info, timeout=60):
        return {
            "id": 19656529,
            "doi": "10.5281/zenodo.19656529",
            "metadata": {"title": "fake", "version": "test"},
            "files": [
                {
                    "key": "best_frozen.pt",
                    "size": source.stat().st_size,
                    "checksum": f"md5:{digest}",
                    "links": {"self": source.resolve().as_uri()},
                }
            ],
        }

    monkeypatch.setattr(model_registry, "fetch_zenodo_record", fake_record)

    cached = model_registry.download_model(cache_dir=tmp_path / "cache", force=True)

    assert cached.path.is_file()
    assert cached.path.read_bytes() == b"fake checkpoint bytes"
    assert cached.metadata_path.is_file()
