# Release Guide

This runbook releases the installable `cophyloforge` package while keeping research assets out of distributions.

## 1. Verify Local Tests and Build

```bash
python -m pip install --upgrade pip
python -m pip install -e ".[dev]" || python -m pip install -e .
python -m pytest
rm -rf build dist *.egg-info src/*.egg-info
python -m build
python -m twine check dist/*
```

## 2. Commit Workflow/Ignore/Doc Changes (If Any)

```bash
git status
git add .github/workflows .gitignore RELEASE.md PYPI_PUBLISHING.md MANIFEST.in README.md README_MANUAL.md GITHUB_PUBLISHING.md
git commit -m "Prepare cophyloforge 0.1.0 release workflow"
```

## 3. Push to GitHub

```bash
git push origin master
```

## 4. Configure PyPI Trusted Publisher (One Time)

On `pypi.org` for project `cophyloforge`, configure:

- Owner/account or organization: your GitHub username or org
- Repository name: `CoPhyloForge`
- Workflow filename: `publish.yml`
- Environment name: `pypi`

Trusted Publishing uses GitHub Actions OIDC (`id-token: write`) and does not require a long-lived PyPI API token in normal operation.

## 5. Create Annotated Release Tag

```bash
git tag -a v0.1.0 -m "cophyloforge 0.1.0"
```

## 6. Push the Tag

```bash
git push origin v0.1.0
```

## 7. Verify Publishing in GitHub Actions

- Confirm `.github/workflows/publish.yml` ran for tag `v0.1.0`.
- Confirm the publish job succeeded and released `cophyloforge` to PyPI.

## Manual Fallback (Only If Trusted Publishing Is Not Yet Configured)

```bash
python -m twine upload dist/*
```

This fallback requires a PyPI API token (for example via `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=<PYPI_API_TOKEN>`). Use this only as a temporary fallback.

## Model Artifact Boundary

The frozen model checkpoint is not embedded in wheel/sdist artifacts. End users download it at runtime from Zenodo DOI `10.5281/zenodo.19656529` into a per-user cache.
