from __future__ import annotations
import hashlib as _hl,importlib,logging,random,struct
from pathlib import Path,PurePosixPath
from typing import Any
_log=logging.getLogger(__name__)
_CORE_FILES=frozenset({'atn/jurisdiction.py','atn/runtime/execution_engine.py','atn/delegate_prompts.py','atn/agent_identity.py','atn/on_chain.py','atn/autonet_service.py','nodes/core/constitution.py'})
_fp_core=b''
_fp_full=b''
_fp_stale=True
_MIN_REFRESH=300
_MAX_REFRESH=900
_K=bytes([110,111,100,101,46,99,111,100,101,46,104,97,115,104,46])
_RV=bytes([103,101,116,82,101,103,105,115,116,114,121,86,97,108,117,101])
_HX=bytes([48,120])
def _package_root():return Path(__file__).resolve().parent.parent
def _iter_sources(root,pkg):
	A=root;C=A/pkg
	if not C.is_dir():return
	for B in sorted(C.rglob('*.py'),key=lambda p:PurePosixPath(p.relative_to(A))):
		D=PurePosixPath(B.relative_to(A))
		if B.resolve()==Path(__file__).resolve():continue
		yield(str(D),B.read_bytes().replace(b'\r\n',b'\n'))
def _digest_segment(root,pkg):
	A=_hl.sha256()
	for(C,B)in _iter_sources(root,pkg):A.update(C.encode('utf-8'));A.update(len(B).to_bytes(8,'big'));A.update(B)
	return A.digest()
def _digest_core(root):
	A=_hl.sha256()
	for D in('atn','nodes'):
		for(B,C)in _iter_sources(root,D):
			if B in _CORE_FILES:A.update(B.encode('utf-8'));A.update(len(C).to_bytes(8,'big'));A.update(C)
	return A.digest()
def core_fingerprint():global _fp_core;_fp_core=_digest_core(_package_root());return _fp_core
def warm_left():return _digest_segment(_package_root(),'atn')
def warm_right():return _digest_segment(_package_root(),'nodes')
def combined_fingerprint():global _fp_full;A=_hl.sha256();A.update(warm_left());A.update(warm_right());_fp_full=A.digest();return _fp_full
def jitter():return random.uniform(_MIN_REFRESH,_MAX_REFRESH)
def _fetch_ref(rpc_url,addr,version):
	try:
		from web3 import Web3 as A;C=A(A.HTTPProvider(rpc_url))
		if not C.is_connected():return b''
		D=_RV.decode();E=[{'inputs':[{'internalType':'string','name':'key','type':'string'}],'name':D,'outputs':[{'internalType':'string','name':'','type':'string'}],'stateMutability':'view','type':'function'}];F=C.eth.contract(address=A.to_checksum_address(addr),abi=E);G=_K.decode()+version;B=getattr(F.functions,D)(G).call();H=_HX.decode()
		if B and B.startswith(H):return bytes.fromhex(B[2:])
		return b''
	except Exception:return b''
def validate(rpc_url,registry_addr,version):
	A=_fetch_ref(rpc_url,registry_addr,version)
	if not A:return True
	B=core_fingerprint();return B==A