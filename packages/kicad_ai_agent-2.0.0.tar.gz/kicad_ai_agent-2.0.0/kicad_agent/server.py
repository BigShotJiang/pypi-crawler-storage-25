"""WebSocket 기반 실시간 GUI 서버

Browser (Chat UI) ←WebSocket→ FastAPI ←→ GPT-4o + KiCad IPC API
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import uuid
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from .agent import Agent
from .config import AgentConfig, LLMConfig

logger = logging.getLogger(__name__)

_executor = ThreadPoolExecutor(max_workers=4)

app = FastAPI(title="KiCad AI Agent", version="2.0.0")

static_dir = Path(__file__).parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/", response_class=HTMLResponse)
async def index():
    index_file = static_dir / "index.html"
    if index_file.exists():
        return FileResponse(str(index_file))
    return HTMLResponse("<h1>KiCad AI Agent</h1>")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 실시간 채팅 — 에이전트 1:1 연결"""
    await websocket.accept()
    loop = asyncio.get_event_loop()

    config = _build_config()
    agent = Agent(config)

    async def _send(msg: dict):
        try:
            await websocket.send_text(json.dumps(msg, ensure_ascii=False))
        except Exception:
            pass

    # 초기화
    try:
        status = await loop.run_in_executor(_executor, agent.initialize)
        await _send({
            "type": "system",
            "content": status,
            "kicad_connected": agent.kicad_connected,
        })
    except Exception as e:
        await _send({"type": "error", "content": f"초기화 실패: {e}"})
        await websocket.close()
        return

    # 메시지 루프
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                data = {"type": "chat", "content": raw}

            msg_type = data.get("type", "chat")

            if msg_type == "chat":
                text = data.get("content", "")
                images = data.get("images")

                image_paths = None
                if images:
                    image_paths = _save_temp_images(images, config.workspace)

                event_queue: asyncio.Queue = asyncio.Queue()

                def on_event(event_type: str, edata: dict):
                    loop.call_soon_threadsafe(
                        event_queue.put_nowait,
                        {"type": event_type, **edata},
                    )

                chat_future = loop.run_in_executor(
                    _executor,
                    lambda: agent.chat(text, image_paths=image_paths, on_event=on_event),
                )

                # 이벤트 스트리밍 + 완료 대기
                while True:
                    try:
                        event = event_queue.get_nowait()
                        await _send(event)
                    except asyncio.QueueEmpty:
                        pass

                    if chat_future.done():
                        while not event_queue.empty():
                            event = event_queue.get_nowait()
                            await _send(event)
                        break
                    await asyncio.sleep(0.05)

                try:
                    result = chat_future.result()
                    await _send({"type": "assistant", "content": result})
                except Exception as e:
                    logger.error("채팅 처리 실패: %s", e)
                    await _send({"type": "error", "content": str(e)})

            elif msg_type == "status":
                await _send({
                    "type": "system",
                    "kicad_connected": agent.kicad_connected,
                })

    except WebSocketDisconnect:
        logger.info("WebSocket 연결 종료")
    except Exception as e:
        logger.error("WebSocket 오류: %s", e)


def _build_config() -> AgentConfig:
    load_dotenv()
    workspace = Path(os.environ.get("KICAD_WORKSPACE", ".")).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    return AgentConfig(
        llm=LLMConfig(model=os.environ.get("KICAD_MODEL", "gpt-4o")),
        workspace=workspace,
    )


def _save_temp_images(images: list[dict], workspace: Path) -> list[str]:
    """base64 이미지를 임시 파일로 저장"""
    paths = []
    tmp_dir = workspace / ".tmp_images"
    tmp_dir.mkdir(exist_ok=True)

    for i, img in enumerate(images):
        b64 = img.get("data", "")
        name = img.get("name", f"image_{i}.png")
        if not b64:
            continue
        if "," in b64:
            b64 = b64.split(",", 1)[1]
        fpath = tmp_dir / f"{uuid.uuid4().hex[:8]}_{name}"
        fpath.write_bytes(base64.b64decode(b64))
        paths.append(str(fpath))

    return paths if paths else None


def run_server(
    host: str = "127.0.0.1",
    port: int = 8000,
    open_browser: bool = True,
):
    """서버 실행 + 브라우저 자동 오픈"""
    import uvicorn

    url = f"http://localhost:{port}"
    print(f"\n🚀 KiCad AI Agent 서버: {url}")
    print(f"   Ctrl+C로 종료\n")

    if open_browser:
        import threading
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    uvicorn.run(app, host=host, port=port, log_level="warning")
