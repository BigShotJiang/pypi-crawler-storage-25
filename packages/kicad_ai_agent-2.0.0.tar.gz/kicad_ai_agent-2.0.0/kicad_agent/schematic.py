"""KiCad 회로도(Schematic) S-expression 파서 및 생성기

KiCad의 .kicad_sch 파일은 S-expression(LISP-like) 형식의 텍스트 파일입니다.
이 모듈은 AI가 회로도를 직접 읽고 쓸 수 있도록 파싱/생성 기능을 제공합니다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def parse_sexpr(text: str) -> list:
    """S-expression 문자열을 중첩 리스트로 파싱

    예: '(kicad_sch (version 20231120) (lib_symbols))'
    ->  ['kicad_sch', ['version', '20231120'], ['lib_symbols']]
    """
    tokens = _tokenize(text)
    result, _ = _parse_tokens(tokens, 0)
    return result


def _tokenize(text: str) -> list[str]:
    """S-expression을 토큰 리스트로 분리"""
    tokens = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in "()":
            tokens.append(ch)
            i += 1
        elif ch == '"':
            # 따옴표 문자열
            j = i + 1
            while j < len(text) and text[j] != '"':
                if text[j] == "\\":
                    j += 1  # 이스케이프 문자 건너뛰기
                j += 1
            tokens.append(text[i : j + 1])
            i = j + 1
        elif ch in " \t\n\r":
            i += 1
        else:
            # 일반 토큰
            j = i
            while j < len(text) and text[j] not in " \t\n\r()\"":
                j += 1
            tokens.append(text[i:j])
            i = j
    return tokens


def _parse_tokens(tokens: list[str], pos: int) -> tuple[Any, int]:
    """토큰 리스트를 재귀적으로 파싱"""
    if tokens[pos] == "(":
        result = []
        pos += 1
        while pos < len(tokens) and tokens[pos] != ")":
            item, pos = _parse_tokens(tokens, pos)
            result.append(item)
        return result, pos + 1  # ')' 건너뛰기
    else:
        token = tokens[pos]
        # 따옴표 제거
        if token.startswith('"') and token.endswith('"'):
            token = token[1:-1]
        return token, pos + 1


def sexpr_to_string(expr: list | str, indent: int = 0) -> str:
    """중첩 리스트를 S-expression 문자열로 변환"""
    if isinstance(expr, str):
        if " " in expr or not expr:
            return f'"{expr}"'
        return expr

    parts = []
    prefix = "  " * indent
    tag = expr[0] if expr else ""

    # 짧은 표현은 한 줄로
    flat = f"({' '.join(sexpr_to_string(e) for e in expr)})"
    if len(flat) < 80 and "\n" not in flat:
        return flat

    # 긴 표현은 여러 줄로
    parts.append(f"({sexpr_to_string(expr[0])}")
    for child in expr[1:]:
        if isinstance(child, list):
            parts.append(f"\n{prefix}  {sexpr_to_string(child, indent + 1)}")
        else:
            parts.append(f" {sexpr_to_string(child)}")
    parts.append(")")
    return "".join(parts)


# ─── 회로도 데이터 모델 ───


@dataclass
class Pin:
    """심볼 핀"""

    number: str
    name: str
    pin_type: str  # input, output, passive, power_in, power_out, etc.
    position: tuple[float, float] = (0, 0)
    length: float = 2.54


@dataclass
class Symbol:
    """회로 심볼(부품)"""

    reference: str  # 예: R1, C1, U1
    value: str  # 예: 10k, 100nF, STM32F103
    library_id: str  # 예: Device:R, Device:C
    position: tuple[float, float] = (0, 0)
    rotation: float = 0
    mirror: bool = False
    properties: dict[str, str] = field(default_factory=dict)
    pins: list[Pin] = field(default_factory=list)


@dataclass
class Wire:
    """회로도 배선"""

    start: tuple[float, float]
    end: tuple[float, float]


@dataclass
class Label:
    """넷 라벨"""

    name: str
    position: tuple[float, float]
    rotation: float = 0


@dataclass
class PowerSymbol:
    """전원 심볼 (VCC, GND 등)"""

    name: str  # VCC, GND, +3V3, +5V 등
    position: tuple[float, float]
    rotation: float = 0


@dataclass
class Schematic:
    """전체 회로도 데이터"""

    version: str = "20231120"
    generator: str = "kicad_ai_agent"
    paper_size: str = "A4"
    symbols: list[Symbol] = field(default_factory=list)
    wires: list[Wire] = field(default_factory=list)
    labels: list[Label] = field(default_factory=list)
    power_symbols: list[PowerSymbol] = field(default_factory=list)


class SchematicGenerator:
    """회로도 S-expression 파일 생성기"""

    def __init__(self):
        self._uuid_counter = 0

    def _next_uuid(self) -> str:
        """간단한 UUID 생성 (실제로는 UUID4 사용 권장)"""
        import uuid
        return str(uuid.uuid4())

    def generate(self, schematic: Schematic) -> str:
        """Schematic 객체를 .kicad_sch 파일 형식 문자열로 변환"""
        parts = []
        parts.append(f'(kicad_sch (version {schematic.version}) (generator "{schematic.generator}")')
        parts.append("")
        parts.append(f'  (paper "{schematic.paper_size}")')
        parts.append("")
        parts.append("  (lib_symbols")
        parts.append("  )")
        parts.append("")

        # 심볼 인스턴스 추가
        for sym in schematic.symbols:
            parts.append(self._generate_symbol(sym))
            parts.append("")

        # 전원 심볼 추가
        for pwr in schematic.power_symbols:
            parts.append(self._generate_power_symbol(pwr))
            parts.append("")

        # 배선 추가
        for wire in schematic.wires:
            parts.append(self._generate_wire(wire))

        # 라벨 추가
        for label in schematic.labels:
            parts.append(self._generate_label(label))

        parts.append(")")
        return "\n".join(parts)

    def _generate_symbol(self, sym: Symbol) -> str:
        """심볼을 S-expression으로 변환"""
        uuid = self._next_uuid()
        x, y = sym.position
        lines = [
            f'  (symbol (lib_id "{sym.library_id}") (at {x} {y} {sym.rotation})',
            f'    (uuid "{uuid}")',
        ]

        # 속성: Reference
        lines.append(
            f'    (property "Reference" "{sym.reference}" (at {x} {y - 2.54} 0)'
        )
        lines.append("      (effects (font (size 1.27 1.27)))")
        lines.append("    )")

        # 속성: Value
        lines.append(
            f'    (property "Value" "{sym.value}" (at {x} {y + 2.54} 0)'
        )
        lines.append("      (effects (font (size 1.27 1.27)))")
        lines.append("    )")

        # 추가 속성
        for key, val in sym.properties.items():
            lines.append(
                f'    (property "{key}" "{val}" (at {x} {y} 0)'
            )
            lines.append("      (effects (font (size 1.27 1.27)) hide)")
            lines.append("    )")

        lines.append("  )")
        return "\n".join(lines)

    def _generate_power_symbol(self, pwr: PowerSymbol) -> str:
        """전원 심볼을 S-expression으로 변환"""
        uuid = self._next_uuid()
        x, y = pwr.position
        lib_id = f"power:{pwr.name}"
        return (
            f'  (symbol (lib_id "{lib_id}") (at {x} {y} {pwr.rotation})\n'
            f'    (uuid "{uuid}")\n'
            f'    (property "Reference" "#{pwr.name}" (at {x} {y - 1.27} 0)\n'
            f'      (effects (font (size 1.27 1.27)) hide)\n'
            f"    )\n"
            f'    (property "Value" "{pwr.name}" (at {x} {y + 1.27} 0)\n'
            f"      (effects (font (size 1.27 1.27)))\n"
            f"    )\n"
            f"  )"
        )

    def _generate_wire(self, wire: Wire) -> str:
        """배선을 S-expression으로 변환"""
        x1, y1 = wire.start
        x2, y2 = wire.end
        return f"  (wire (pts (xy {x1} {y1}) (xy {x2} {y2})))"

    def _generate_label(self, label: Label) -> str:
        """라벨을 S-expression으로 변환"""
        x, y = label.position
        uuid = self._next_uuid()
        return (
            f'  (label "{label.name}" (at {x} {y} {label.rotation})\n'
            f'    (uuid "{uuid}")\n'
            f"    (effects (font (size 1.27 1.27)))\n"
            f"  )"
        )

    def save(self, schematic: Schematic, filepath: str | Path) -> Path:
        """회로도를 파일로 저장"""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        content = self.generate(schematic)
        filepath.write_text(content, encoding="utf-8")
        return filepath


class SchematicParser:
    """기존 .kicad_sch 파일을 파싱하여 Schematic 객체로 변환"""

    def parse_file(self, filepath: str | Path) -> Schematic:
        """파일에서 회로도 파싱"""
        text = Path(filepath).read_text(encoding="utf-8")
        return self.parse_text(text)

    def parse_text(self, text: str) -> Schematic:
        """문자열에서 회로도 파싱"""
        tree = parse_sexpr(text)
        sch = Schematic()

        if not tree or tree[0] != "kicad_sch":
            raise ValueError("유효한 KiCad 회로도 파일이 아닙니다")

        for item in tree[1:]:
            if not isinstance(item, list):
                continue
            tag = item[0]
            if tag == "version":
                sch.version = str(item[1])
            elif tag == "paper":
                sch.paper_size = str(item[1])
            elif tag == "symbol":
                sym = self._parse_symbol(item)
                if sym:
                    sch.symbols.append(sym)
            elif tag == "wire":
                wire = self._parse_wire(item)
                if wire:
                    sch.wires.append(wire)
            elif tag == "label":
                lab = self._parse_label(item)
                if lab:
                    sch.labels.append(lab)

        return sch

    def _parse_symbol(self, tree: list) -> Symbol | None:
        """심볼 노드를 파싱"""
        lib_id = ""
        pos = (0.0, 0.0)
        rotation = 0.0
        reference = ""
        value = ""
        properties = {}

        for item in tree[1:]:
            if not isinstance(item, list):
                continue
            tag = item[0]
            if tag == "lib_id":
                lib_id = str(item[1])
            elif tag == "at":
                pos = (float(item[1]), float(item[2]))
                if len(item) > 3:
                    rotation = float(item[3])
            elif tag == "property":
                prop_name = str(item[1])
                prop_value = str(item[2])
                if prop_name == "Reference":
                    reference = prop_value
                elif prop_name == "Value":
                    value = prop_value
                else:
                    properties[prop_name] = prop_value

        if not lib_id:
            return None

        return Symbol(
            reference=reference,
            value=value,
            library_id=lib_id,
            position=pos,
            rotation=rotation,
            properties=properties,
        )

    def _parse_wire(self, tree: list) -> Wire | None:
        """배선 노드를 파싱"""
        for item in tree[1:]:
            if isinstance(item, list) and item[0] == "pts":
                points = []
                for pt in item[1:]:
                    if isinstance(pt, list) and pt[0] == "xy":
                        points.append((float(pt[1]), float(pt[2])))
                if len(points) >= 2:
                    return Wire(start=points[0], end=points[1])
        return None

    def _parse_label(self, tree: list) -> Label | None:
        """라벨 노드를 파싱"""
        if len(tree) < 2:
            return None
        name = str(tree[1])
        pos = (0.0, 0.0)
        rotation = 0.0
        for item in tree[2:]:
            if isinstance(item, list) and item[0] == "at":
                pos = (float(item[1]), float(item[2]))
                if len(item) > 3:
                    rotation = float(item[3])
        return Label(name=name, position=pos, rotation=rotation)
