"""회로 검증 모듈 - DRC/ERC 및 논리적 회로 검증

KiCad의 DRC(Design Rule Check)를 활용하고,
추가적으로 AI 기반의 논리적 회로 검증을 수행합니다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Violation:
    """설계 규칙 위반 항목"""

    severity: Severity
    rule: str
    message: str
    location: str = ""
    auto_fixable: bool = False
    fix_description: str = ""


@dataclass
class ValidationReport:
    """검증 결과 보고서"""

    violations: list[Violation] = field(default_factory=list)
    passed: bool = True
    summary: str = ""

    @property
    def error_count(self) -> int:
        return sum(1 for v in self.violations if v.severity == Severity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for v in self.violations if v.severity == Severity.WARNING)

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "summary": self.summary,
            "violations": [
                {
                    "severity": v.severity.value,
                    "rule": v.rule,
                    "message": v.message,
                    "location": v.location,
                    "auto_fixable": v.auto_fixable,
                    "fix_description": v.fix_description,
                }
                for v in self.violations
            ],
        }


class SchematicValidator:
    """회로도 수준의 검증 (ERC 역할)"""

    def validate(self, schematic) -> ValidationReport:
        """회로도에 대한 기본 규칙 검증"""
        from .schematic import Schematic

        report = ValidationReport()

        if not isinstance(schematic, Schematic):
            report.violations.append(Violation(
                severity=Severity.ERROR,
                rule="INVALID_INPUT",
                message="유효한 회로도 객체가 아닙니다",
            ))
            report.passed = False
            return report

        self._check_power_connections(schematic, report)
        self._check_bypass_capacitors(schematic, report)
        self._check_floating_labels(schematic, report)
        self._check_duplicate_references(schematic, report)
        self._check_missing_values(schematic, report)

        report.passed = report.error_count == 0
        report.summary = (
            f"검증 완료: 에러 {report.error_count}건, "
            f"경고 {report.warning_count}건 발견"
        )
        return report

    def _check_power_connections(self, sch, report: ValidationReport):
        """전원 연결 확인"""
        has_power = any(
            p.name.upper() in ("VCC", "+3V3", "+5V", "+3.3V", "+12V", "VDD", "VBUS")
            for p in sch.power_symbols
        )
        has_ground = any(
            p.name.upper() in ("GND", "VSS", "GNDD", "GNDA")
            for p in sch.power_symbols
        )

        if sch.symbols and not has_power:
            report.violations.append(Violation(
                severity=Severity.ERROR,
                rule="MISSING_POWER",
                message="전원 공급 심볼이 없습니다 (VCC, +3V3, +5V 등)",
                auto_fixable=True,
                fix_description="적절한 전원 심볼을 추가합니다",
            ))

        if sch.symbols and not has_ground:
            report.violations.append(Violation(
                severity=Severity.ERROR,
                rule="MISSING_GROUND",
                message="그라운드(GND) 심볼이 없습니다",
                auto_fixable=True,
                fix_description="GND 심볼을 추가합니다",
            ))

    def _check_bypass_capacitors(self, sch, report: ValidationReport):
        """IC별 바이패스 커패시터 확인"""
        ic_refs = [s.reference for s in sch.symbols if s.reference.startswith("U")]
        cap_count = sum(1 for s in sch.symbols if s.reference.startswith("C"))

        if len(ic_refs) > 0 and cap_count < len(ic_refs):
            report.violations.append(Violation(
                severity=Severity.WARNING,
                rule="MISSING_BYPASS_CAP",
                message=(
                    f"IC {len(ic_refs)}개에 바이패스 커패시터가 부족합니다. "
                    f"현재 커패시터 {cap_count}개 (최소 IC당 1개 필요)"
                ),
                auto_fixable=True,
                fix_description="각 IC에 100nF 바이패스 커패시터를 추가합니다",
            ))

    def _check_floating_labels(self, sch, report: ValidationReport):
        """연결되지 않은 라벨 확인"""
        label_names = [l.name for l in sch.labels]
        for name in set(label_names):
            if label_names.count(name) == 1:
                report.violations.append(Violation(
                    severity=Severity.WARNING,
                    rule="FLOATING_LABEL",
                    message=f"라벨 '{name}'이 하나만 존재합니다 (연결이 불완전할 수 있음)",
                ))

    def _check_duplicate_references(self, sch, report: ValidationReport):
        """중복 레퍼런스 확인"""
        refs = [s.reference for s in sch.symbols]
        seen = set()
        for ref in refs:
            if ref in seen:
                report.violations.append(Violation(
                    severity=Severity.ERROR,
                    rule="DUPLICATE_REFERENCE",
                    message=f"레퍼런스 '{ref}'가 중복됩니다",
                ))
            seen.add(ref)

    def _check_missing_values(self, sch, report: ValidationReport):
        """값이 비어있는 부품 확인"""
        for sym in sch.symbols:
            if not sym.value or sym.value == "~":
                report.violations.append(Violation(
                    severity=Severity.WARNING,
                    rule="MISSING_VALUE",
                    message=f"{sym.reference}의 값이 지정되지 않았습니다",
                ))


class PCBValidator:
    """PCB 수준의 검증 (DRC 결과 활용)"""

    def __init__(self, kicad_bridge):
        self._bridge = kicad_bridge

    def validate(self) -> ValidationReport:
        """KiCad DRC를 실행하고 보고서 생성"""
        report = ValidationReport()

        try:
            drc_results = self._bridge.run_drc()
            for result in drc_results:
                severity = Severity.ERROR if result.get("severity") == "error" else Severity.WARNING
                report.violations.append(Violation(
                    severity=severity,
                    rule="DRC",
                    message=result.get("message", ""),
                    location=result.get("position", ""),
                ))
        except Exception as e:
            report.violations.append(Violation(
                severity=Severity.ERROR,
                rule="DRC_FAILED",
                message=f"DRC 실행 실패: {e}",
            ))

        report.passed = report.error_count == 0
        report.summary = (
            f"PCB DRC 완료: 에러 {report.error_count}건, "
            f"경고 {report.warning_count}건"
        )
        return report
