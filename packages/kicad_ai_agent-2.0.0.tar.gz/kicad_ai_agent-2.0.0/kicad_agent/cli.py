"""CLI — 대화형 인터페이스 (파일 업로드, KiCad 상태 표시)"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

import click
from dotenv import load_dotenv
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

from .agent import Agent
from .config import AgentConfig, KiCadConfig, LLMConfig, ServiceConfig

console = Console()
logger = logging.getLogger(__name__)

BANNER = """\
[bold cyan]╔══════════════════════════════════════════════════╗
║           KiCad AI Agent  v2.0                   ║
║   GPT-4o + KiCad IPC API 자율형 회로 설계 에이전트   ║
╚══════════════════════════════════════════════════╝[/bold cyan]"""

HELP_TEXT = """\
[dim]명령어:
  /file <경로>    이미지 파일 첨부 (회로도, PLC 다이어그램 등)
  /workspace      작업 디렉토리 파일 목록
  /status         KiCad 연결 상태
  /clear          대화 초기화
  /help           도움말
  quit / exit     종료[/dim]"""


def setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


@click.group(invoke_without_command=True)
@click.option("--verbose", "-v", is_flag=True, help="상세 로그 출력")
@click.option("--model", "-m", default="gpt-4o", help="사용할 LLM 모델")
@click.option("--workspace", "-w", default=".", help="작업 디렉토리")
@click.option("--port", "-p", default=8000, type=int, help="웹 서버 포트")
@click.option("--cli-mode", is_flag=True, help="CLI 대화형 모드 (웹 UI 대신)")
@click.pass_context
def main(ctx, verbose: bool, model: str, workspace: str, port: int, cli_mode: bool):
    """KiCad AI Agent — AI가 직접 회로를 설계하고 검증합니다"""
    load_dotenv()
    setup_logging(verbose)

    ctx.ensure_object(dict)
    ctx.obj["config"] = AgentConfig(
        llm=LLMConfig(model=model),
        workspace=Path(workspace).resolve(),
        verbose=verbose,
    )
    ctx.obj["port"] = port

    if ctx.invoked_subcommand is None:
        if cli_mode:
            interactive_mode(ctx.obj["config"])
        else:
            # 기본: 웹 GUI 서버 실행
            _start_web_server(ctx.obj["config"], port)


@main.command()
@click.argument("description")
@click.option("--output", "-o", default=".", help="출력 디렉토리")
@click.pass_context
def create(ctx, description: str, output: str):
    """자연어 설명으로 새 회로 생성

    예: kicad-agent create "NE555 LED 깜빡이 회로"
    """
    config: AgentConfig = ctx.obj["config"]
    config.workspace = Path(output).resolve()

    agent = Agent(config)
    status = agent.initialize()
    console.print(f"[dim]{status}[/dim]")

    console.print(Panel(f"[bold]회로 생성:[/bold] {description}", style="blue"))

    with console.status("[bold green]AI가 회로를 설계하고 있습니다..."):
        response = agent.chat(
            f"다음 요구사항에 맞는 회로도를 생성해주세요:\n\n{description}\n\n"
            "1. 필요한 부품을 선정하세요\n"
            "2. create_schematic 도구로 회로도를 생성하세요\n"
            "3. 생성된 회로를 analyze_circuit 도구로 검증하세요\n"
            "4. 결과를 보고해주세요"
        )

    console.print(Markdown(response))


@main.command()
@click.argument("filepath")
@click.pass_context
def review(ctx, filepath: str):
    """기존 회로를 분석하고 검토

    예: kicad-agent review ./my_circuit.kicad_sch
    """
    config: AgentConfig = ctx.obj["config"]
    config.workspace = Path(filepath).parent.resolve()

    agent = Agent(config)
    status = agent.initialize()
    console.print(f"[dim]{status}[/dim]")

    with console.status("[bold green]AI가 분석 중..."):
        response = agent.auto_review_and_fix(filepath)

    console.print(Markdown(response))


@main.command()
@click.argument("image_path")
@click.option("--question", "-q", default="", help="이미지에 대한 질문")
@click.pass_context
def analyze(ctx, image_path: str, question: str):
    """이미지 파일(회로도, PLC 다이어그램) 분석

    예: kicad-agent analyze plc_diagram.png -q "이 회로를 KiCad로 변환해줘"
    """
    config: AgentConfig = ctx.obj["config"]
    agent = Agent(config)
    status = agent.initialize()
    console.print(f"[dim]{status}[/dim]")

    if not question:
        question = "이 이미지의 회로를 상세히 분석하고, KiCad 회로도로 변환해주세요."

    msg = f"{question}\n\n첨부된 이미지를 참조해주세요."

    with console.status("[bold green]이미지 분석 중..."):
        response = agent.chat(msg, image_paths=[image_path])

    console.print(Markdown(response))


def _start_web_server(config: AgentConfig, port: int):
    """웹 GUI 서버 시작 + 브라우저 자동 오픈"""
    import os
    os.environ["KICAD_WORKSPACE"] = str(config.workspace)
    os.environ["KICAD_MODEL"] = config.llm.model

    console.print(BANNER)
    console.print()
    console.print(f"  🌐 웹 UI: [bold cyan]http://localhost:{port}[/bold cyan]")
    console.print(f"  📂 작업 디렉토리: [cyan]{config.workspace}[/cyan]")
    console.print(f"  🤖 모델: [cyan]{config.llm.model}[/cyan]")
    console.print()
    console.print("  [dim]Ctrl+C로 종료 | --cli-mode 옵션으로 터미널 모드[/dim]")
    console.print()

    from .server import run_server
    run_server(port=port)


@main.command()
@click.option("--port", "-p", default=8000, type=int, help="포트")
@click.option("--no-browser", is_flag=True, help="브라우저 자동 오픈 비활성화")
@click.pass_context
def serve(ctx, port: int, no_browser: bool):
    """웹 GUI 서버 실행"""
    config: AgentConfig = ctx.obj["config"]
    import os
    os.environ["KICAD_WORKSPACE"] = str(config.workspace)
    os.environ["KICAD_MODEL"] = config.llm.model

    console.print(BANNER)
    console.print(f"\n  🌐 http://localhost:{port}\n")

    from .server import run_server
    run_server(port=port, open_browser=not no_browser)


# ─── 서비스 인증 명령 ───

def _get_service_url() -> str:
    return os.environ.get(
        "KICAD_SERVICE_URL",
        "https://kicad-agent.kicad-ai-hk.workers.dev",
    )


def _save_service_key(api_key: str):
    """KICAD_SERVICE_KEY를 .env 파일에 저장"""
    env_path = Path(".env")
    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []

    found = False
    for i, line in enumerate(lines):
        if line.startswith("KICAD_SERVICE_KEY"):
            lines[i] = f"KICAD_SERVICE_KEY={api_key}"
            found = True
            break
    if not found:
        lines.append(f"KICAD_SERVICE_KEY={api_key}")

    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


@main.command()
@click.option("--email", "-e", prompt="이메일", help="이메일 주소")
@click.option("--password", "-p", prompt="비밀번호", hide_input=True, confirmation_prompt=True, help="비밀번호 (8자 이상)")
def register(email: str, password: str):
    """서비스 회원가입 → API 키 발급"""
    import httpx

    url = _get_service_url()
    with console.status("[bold green]서버에 등록 중..."):
        try:
            resp = httpx.post(
                f"{url}/api/auth/register",
                json={"email": email, "password": password},
                timeout=15,
            )
        except httpx.ConnectError:
            console.print("[red]✗ 서버 연결 실패[/red]")
            return

    data = resp.json()
    if resp.status_code == 201:
        api_key = data["api_key"]
        console.print(f"\n[green]✓ 등록 성공![/green]")
        console.print(f"  API 키: [bold cyan]{api_key}[/bold cyan]")
        console.print(f"  플랜: {data['plan']} ({data['tokens_limit']:,} 토큰)")
        _save_service_key(api_key)
        console.print(f"  [dim].env에 자동 저장됨[/dim]\n")
    else:
        msg = data.get("error", {}).get("message", "알 수 없는 오류")
        console.print(f"[red]✗ {msg}[/red]")


@main.command()
@click.option("--email", "-e", prompt="이메일", help="이메일 주소")
@click.option("--password", "-p", prompt="비밀번호", hide_input=True, help="비밀번호")
def login(email: str, password: str):
    """로그인 → API 키 조회 및 저장"""
    import httpx

    url = _get_service_url()
    with console.status("[bold green]로그인 중..."):
        try:
            resp = httpx.post(
                f"{url}/api/auth/login",
                json={"email": email, "password": password},
                timeout=15,
            )
        except httpx.ConnectError:
            console.print("[red]✗ 서버 연결 실패[/red]")
            return

    data = resp.json()
    if resp.status_code == 200:
        api_key = data["api_key"]
        console.print(f"\n[green]✓ 로그인 성공![/green]")
        console.print(f"  플랜: {data['plan']} ({data['tokens_used']:,} / {data['tokens_limit']:,} 토큰)")
        _save_service_key(api_key)
        console.print(f"  [dim].env에 저장됨[/dim]\n")
    else:
        msg = data.get("error", {}).get("message", "알 수 없는 오류")
        console.print(f"[red]✗ {msg}[/red]")


@main.command()
def usage():
    """서비스 사용량 조회"""
    import httpx

    load_dotenv()
    api_key = os.environ.get("KICAD_SERVICE_KEY", "")
    if not api_key:
        console.print("[yellow]서비스 키가 없습니다. kicad-agent register 또는 login을 먼저 실행하세요.[/yellow]")
        return

    url = _get_service_url()
    with console.status("[bold green]조회 중..."):
        try:
            resp = httpx.get(
                f"{url}/api/usage",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
        except httpx.ConnectError:
            console.print("[red]✗ 서버 연결 실패[/red]")
            return

    data = resp.json()
    if resp.status_code == 200:
        pct = data["usage_percent"]
        bar_filled = pct // 5
        bar = f"[green]{'█' * bar_filled}[/green][dim]{'░' * (20 - bar_filled)}[/dim]"
        console.print(f"\n  📧 {data['email']}")
        console.print(f"  📋 플랜: [bold]{data['plan']}[/bold]")
        console.print(f"  📊 사용량: {data['tokens_used']:,} / {data['tokens_limit']:,} 토큰 ({pct}%)")
        console.print(f"  {bar}")
        console.print(f"  🔄 남은 토큰: {data['tokens_remaining']:,}\n")
    else:
        msg = data.get("error", {}).get("message", "알 수 없는 오류")
        console.print(f"[red]✗ {msg}[/red]")


def interactive_mode(config: AgentConfig):
    """대화형 모드 — 자유 대화 + 파일 업로드"""
    console.print(BANNER)
    console.print()

    agent = Agent(config)
    status = agent.initialize()

    kicad_icon = "[green]●[/green]" if agent.kicad_connected else "[red]●[/red]"
    console.print(f"  {kicad_icon} {status}")
    console.print(f"  📂 작업 디렉토리: [cyan]{config.workspace}[/cyan]")
    console.print()
    console.print(HELP_TEXT)
    console.print()

    pending_images: list[str] = []

    while True:
        try:
            prompt_text = "[bold green]You"
            if pending_images:
                prompt_text = f"[bold green]You [dim]({len(pending_images)}개 이미지 첨부)[/dim]"
            user_input = Prompt.ask(prompt_text)
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]종료합니다.[/dim]")
            break

        stripped = user_input.strip()
        if not stripped:
            continue

        if stripped.lower() in ("quit", "exit", "q"):
            console.print("[dim]종료합니다.[/dim]")
            break

        # 명령어 처리
        if stripped.startswith("/"):
            _handle_command(stripped, agent, config, pending_images)
            continue

        # 메시지 전송
        images = pending_images.copy() if pending_images else None
        pending_images.clear()

        with console.status("[bold green]AI 작업 중..."):
            try:
                response = agent.chat(stripped, image_paths=images)
            except Exception as e:
                console.print(f"[red]오류: {e}[/red]")
                continue

        console.print()
        console.print(Markdown(response))
        console.print()


def _handle_command(cmd: str, agent: Agent, config: AgentConfig, pending_images: list[str]):
    """슬래시 명령어 처리"""
    parts = cmd.split(maxsplit=1)
    command = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if command == "/file":
        if not arg:
            console.print("[yellow]사용법: /file <이미지 경로>[/yellow]")
            return
        path = Path(arg)
        if not path.is_absolute():
            path = config.workspace / path
        if not path.exists():
            console.print(f"[red]파일이 없습니다: {path}[/red]")
            return
        pending_images.append(str(path.resolve()))
        console.print(f"[green]✓ 이미지 첨부: {path.name}[/green] (메시지 입력 시 함께 전송)")

    elif command == "/workspace":
        files = list(config.workspace.iterdir())
        if not files:
            console.print("[dim]빈 디렉토리[/dim]")
            return
        for f in sorted(files):
            icon = "📁" if f.is_dir() else "📄"
            size = ""
            if f.is_file():
                sz = f.stat().st_size
                size = f" ({sz:,} bytes)" if sz < 1024 * 1024 else f" ({sz / 1024 / 1024:.1f} MB)"
            console.print(f"  {icon} {f.name}{size}")

    elif command == "/status":
        kicad_icon = "[green]●[/green]" if agent.kicad_connected else "[red]●[/red]"
        console.print(f"  {kicad_icon} KiCad: {'연결됨' if agent.kicad_connected else '미연결'}")
        console.print(f"  📂 작업 디렉토리: {config.workspace}")
        console.print(f"  🤖 모델: {config.llm.model}")

    elif command == "/clear":
        agent._messages = [agent._messages[0]]  # 시스템 프롬프트만 유지
        console.print("[dim]대화가 초기화되었습니다.[/dim]")

    elif command == "/help":
        console.print(HELP_TEXT)

    else:
        console.print(f"[yellow]알 수 없는 명령: {command}[/yellow]")
        console.print(HELP_TEXT)


if __name__ == "__main__":
    main()
