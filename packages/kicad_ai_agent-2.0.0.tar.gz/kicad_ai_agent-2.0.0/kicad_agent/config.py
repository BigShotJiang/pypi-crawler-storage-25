"""설정 관리 모듈"""

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class KiCadConfig:
    """KiCad 연결 설정"""

    api_socket: str = ""
    api_token: str = ""

    def __post_init__(self):
        if not self.api_socket:
            self.api_socket = os.environ.get("KICAD_API_SOCKET", "")
        if not self.api_token:
            self.api_token = os.environ.get("KICAD_API_TOKEN", "")


@dataclass
class LLMConfig:
    """LLM(AI) 설정"""

    provider: str = "openai"
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str = ""
    max_tokens: int = 4096
    temperature: float = 0.1

    def __post_init__(self):
        if not self.api_key:
            if self.provider == "openai":
                self.api_key = os.environ.get("OPENAI_API_KEY", "")
            elif self.provider == "anthropic":
                self.api_key = os.environ.get("ANTHROPIC_API_KEY", "")


@dataclass
class ServiceConfig:
    """클라우드 API 서비스 설정 (유료화용)"""

    api_url: str = ""
    api_key: str = ""

    def __post_init__(self):
        if not self.api_url:
            self.api_url = os.environ.get(
                "KICAD_SERVICE_URL",
                "https://kicad-agent.kicad-ai-hk.workers.dev",
            )
        if not self.api_key:
            self.api_key = os.environ.get("KICAD_SERVICE_KEY", "")


@dataclass
class AgentConfig:
    """에이전트 전체 설정"""

    kicad: KiCadConfig = field(default_factory=KiCadConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    service: ServiceConfig = field(default_factory=ServiceConfig)
    workspace: Path = field(default_factory=lambda: Path.cwd())
    max_iterations: int = 20
    auto_drc: bool = True
    verbose: bool = False
