"""KiCad AI Agent — GPT-4o + KiCad IPC API 자율형 회로 설계 에이전트"""

__version__ = "2.0.0"
