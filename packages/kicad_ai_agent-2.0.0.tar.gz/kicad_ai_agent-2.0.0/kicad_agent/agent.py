"""AI 에이전트 코어 — GPT-4o + KiCad IPC API 자율형 에이전트

Plan → Execute → Verify 사이클로 사용자 요청을 회로 설계로 변환.
GPT-4o Vision으로 이미지 분석 지원.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Callable

from .config import AgentConfig
from .kicad_bridge import KiCadBridge
from .tools import TOOL_DEFINITIONS, ToolExecutor

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """\
당신은 전자 회로 설계 전문가 AI 에이전트입니다.
KiCad IPC API를 통해 PCB를 직접 조작하고, 회로도(.kicad_sch)를 생성합니다.

## 당신의 능력
1. **PCB 조작** (KiCad IPC API): 풋프린트 조회/이동, 트랙 추가, 비아/존 조회, 보드 저장
2. **회로도 생성**: .kicad_sch 파일 생성 (심볼, 배선, 전원, 라벨)
3. **이미지 분석**: 업로드된 회로도/PLC 다이어그램을 GPT-4o Vision으로 분석
4. **파일 관리**: 파일 읽기/쓰기, 워크스페이스 파일 목록
5. **회로 검증**: 전원/GND 확인, 바이패스 커패시터, 중복 레퍼런스 등

## 작업 원칙
- 사용자가 직접 조작하지 않습니다. 모든 것을 자율적으로 수행합니다.
- 항상 먼저 현재 상태를 파악하고(get_board_summary 등), 계획을 세운 뒤, 실행합니다.
- IC에는 바이패스 커패시터(100nF) 배치, 전원 핀 연결을 반드시 확인합니다.
- 작업 완료 후 결과를 요약 보고합니다.

## 제한 사항
- KiCad 9/10의 IPC API는 PCB 편집기만 지원합니다. 회로도 편집기는 미지원.
- 회로도는 파일 생성 후 KiCad로 여는 방식으로 작업합니다.
- DRC는 IPC API에서 미지원이므로 KiCad에서 직접 실행해야 합니다.

한국어로 답변합니다. 수행한 작업과 결과를 명확히 설명합니다.
"""


class Agent:
    """AI 회로 설계 에이전트"""

    def __init__(self, config: AgentConfig):
        self._config = config
        self._bridge = KiCadBridge()
        self._tool_executor = ToolExecutor(
            self._bridge, config.workspace, vision_callback=self._vision_analyze
        )
        self._messages: list[dict[str, Any]] = []
        self._client = None
        self._cloud_mode = False

    def initialize(self) -> str:
        """에이전트 초기화: KiCad 연결 시도 + LLM 클라이언트 생성"""
        kicad_status = self._try_connect_kicad()
        self._init_llm_client()
        if self._cloud_mode:
            # 클라우드 모드: 서버가 시스템 프롬프트 주입 → 로컬에선 생략
            self._messages = []
        else:
            # 로컬 모드: 직접 시스템 프롬프트 설정
            self._messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        return kicad_status

    @property
    def kicad_connected(self) -> bool:
        return self._bridge.connected

    def _try_connect_kicad(self) -> str:
        try:
            info = self._bridge.connect()
            return f"KiCad {info.version} 연결됨 (보드: {info.board_name or 'N/A'})"
        except RuntimeError as e:
            logger.warning("KiCad 미연결: %s", e)
            return "KiCad 미연결 — 회로도 파일 생성 모드로 동작합니다"

    def _init_llm_client(self):
        from openai import OpenAI

        svc = self._config.service
        cfg = self._config.llm

        if svc.api_key:
            # 클라우드 서비스 모드 — 우리 API 서버 경유 (유료)
            self._client = OpenAI(
                api_key=svc.api_key,
                base_url=f"{svc.api_url.rstrip('/')}/api/v1",
            )
            self._cloud_mode = True
            logger.info("클라우드 모드: %s", svc.api_url)
        elif cfg.api_key:
            # 로컬 모드 — 사용자 OpenAI 키 직접 사용
            kwargs: dict[str, Any] = {"api_key": cfg.api_key}
            if cfg.base_url:
                kwargs["base_url"] = cfg.base_url
            self._client = OpenAI(**kwargs)
            self._cloud_mode = False
            logger.info("로컬 모드: 직접 OpenAI API 호출")
        else:
            raise ValueError(
                "API 키가 설정되지 않았습니다.\n"
                "  서비스 이용: kicad-agent register\n"
                "  직접 사용: .env에 OPENAI_API_KEY 설정"
            )

    # ── 대화 ────────────────────────────────────────────

    def chat(
        self,
        user_message: str,
        image_paths: list[str] | None = None,
        on_event: Callable[[str, dict], None] | None = None,
    ) -> str:
        """사용자 메시지 처리 (텍스트 + 선택적 이미지)

        Tool Calling 루프:
        1. 사용자 메시지 → LLM
        2. LLM 도구 호출 → 실행 → 결과를 LLM에 재전달
        3. 최종 응답 반환까지 반복

        on_event: 콜백 (event_type, data) — "tool_start", "tool_end", "thinking"
        """
        if not self._client:
            raise RuntimeError("initialize()를 먼저 호출하세요.")

        def _emit(event_type: str, data: dict | None = None):
            if on_event:
                on_event(event_type, data or {})

        # 이미지가 있으면 multimodal content 구성
        content = self._build_user_content(user_message, image_paths)
        self._messages.append({"role": "user", "content": content})

        for _ in range(self._config.max_iterations):
            _emit("thinking")
            response = self._call_llm()
            message = response.choices[0].message

            if not message.tool_calls:
                self._messages.append({
                    "role": "assistant",
                    "content": message.content or "",
                })
                return message.content or ""

            # 도구 호출 처리
            self._messages.append({
                "role": "assistant",
                "content": message.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in message.tool_calls
                ],
            })

            for tool_call in message.tool_calls:
                func_name = tool_call.function.name
                try:
                    arguments = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    arguments = {}

                _emit("tool_start", {"name": func_name, "args": arguments})
                logger.info("도구 실행: %s", func_name)
                result = self._tool_executor.execute(func_name, arguments)
                logger.debug("도구 결과: %s", result[:500])
                _emit("tool_end", {"name": func_name, "result": result[:300]})

                self._messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result,
                })

        return "최대 반복 횟수에 도달했습니다. 작업을 중단합니다."

    def _build_user_content(self, text: str, image_paths: list[str] | None) -> str | list:
        """이미지가 있으면 multimodal content 배열 생성"""
        if not image_paths:
            return text

        import base64
        content: list[dict] = [{"type": "text", "text": text}]

        for img_path in image_paths:
            path = Path(img_path)
            if not path.exists():
                content.append({"type": "text", "text": f"[파일 없음: {img_path}]"})
                continue

            data = path.read_bytes()
            b64 = base64.b64encode(data).decode("utf-8")
            suffix = path.suffix.lower().lstrip(".")
            mime = {
                "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                "gif": "image/gif", "webp": "image/webp", "bmp": "image/bmp",
            }.get(suffix, "image/png")

            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{b64}", "detail": "high"},
            })

        return content

    def _call_llm(self):
        cfg = self._config.llm
        return self._client.chat.completions.create(
            model=cfg.model,
            messages=self._messages,
            tools=TOOL_DEFINITIONS,
            temperature=cfg.temperature,
            max_tokens=cfg.max_tokens,
        )

    # ── Vision 콜백 (tools.py의 analyze_image에서 호출) ─

    def _vision_analyze(self, b64_image: str, mime_type: str, question: str) -> str:
        """GPT-4o Vision으로 이미지 분석"""
        if not self._client:
            return "에이전트가 초기화되지 않았습니다."

        response = self._client.chat.completions.create(
            model=self._config.llm.model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": question},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{b64_image}", "detail": "high"},
                        },
                    ],
                }
            ],
            max_tokens=4096,
        )
        return response.choices[0].message.content or ""

    # ── 자동 리뷰 ──────────────────────────────────────

    def auto_review_and_fix(self, filepath: str) -> str:
        prompt = (
            f"'{filepath}' 파일의 회로를 검토해주세요.\n"
            "1. 회로를 읽고 분석하세요\n"
            "2. 발견된 문제를 나열하세요\n"
            "3. 가능하면 자동으로 수정하세요\n"
            "4. 최종 결과를 보고하세요"
        )
        return self.chat(prompt)
