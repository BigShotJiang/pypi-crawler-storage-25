"""AI 에이전트 도구(Tool) 정의 — OpenAI Function Calling 형식

KiCad PCB 조작, 회로도 생성, 이미지 분석, 파일 관리 도구.
"""

from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)

# ─── Tool 정의 ───────────────────────────────────────────

TOOL_DEFINITIONS = [
    # ── PCB (KiCad IPC) ──
    {
        "type": "function",
        "function": {
            "name": "get_board_summary",
            "description": "KiCad에 열린 PCB 보드의 요약 정보 (풋프린트, 트랙, 넷, 존 수 및 목록)",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_footprints",
            "description": "보드의 모든 풋프린트 상세 정보 (레퍼런스, 값, 위치, 패드)",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_tracks",
            "description": "보드의 모든 트랙(배선) 목록",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_nets",
            "description": "보드의 모든 넷 목록",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_vias",
            "description": "보드의 모든 비아 목록",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_zones",
            "description": "보드의 모든 존(구리 채움 영역) 목록",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "add_track",
            "description": "보드에 트랙(배선) 추가",
            "parameters": {
                "type": "object",
                "properties": {
                    "start_x": {"type": "number", "description": "시작점 X (mm)"},
                    "start_y": {"type": "number", "description": "시작점 Y (mm)"},
                    "end_x": {"type": "number", "description": "끝점 X (mm)"},
                    "end_y": {"type": "number", "description": "끝점 Y (mm)"},
                    "width_mm": {"type": "number", "description": "폭 (mm)", "default": 0.25},
                    "layer": {"type": "string", "description": "레이어 (F.Cu 등)", "default": "F.Cu"},
                    "net_name": {"type": "string", "description": "넷 이름", "default": ""},
                },
                "required": ["start_x", "start_y", "end_x", "end_y"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "move_footprint",
            "description": "풋프린트를 상대 좌표로 이동",
            "parameters": {
                "type": "object",
                "properties": {
                    "reference": {"type": "string", "description": "레퍼런스 (예: R1, U1)"},
                    "dx_mm": {"type": "number", "description": "X 이동량 (mm)"},
                    "dy_mm": {"type": "number", "description": "Y 이동량 (mm)"},
                },
                "required": ["reference", "dx_mm", "dy_mm"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save_board",
            "description": "현재 보드를 저장",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "refill_zones",
            "description": "모든 존을 다시 채움",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    # ── 회로도 ──
    {
        "type": "function",
        "function": {
            "name": "create_schematic",
            "description": "새 KiCad 회로도(.kicad_sch) 파일 생성. 심볼, 배선, 라벨, 전원 심볼을 포함.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "파일명 (예: my_circuit.kicad_sch)"},
                    "symbols": {
                        "type": "array",
                        "description": "심볼 목록",
                        "items": {
                            "type": "object",
                            "properties": {
                                "reference": {"type": "string"},
                                "value": {"type": "string"},
                                "library_id": {"type": "string"},
                                "x": {"type": "number"},
                                "y": {"type": "number"},
                            },
                            "required": ["reference", "value", "library_id", "x", "y"],
                        },
                    },
                    "wires": {
                        "type": "array",
                        "description": "배선 목록",
                        "items": {
                            "type": "object",
                            "properties": {
                                "start_x": {"type": "number"},
                                "start_y": {"type": "number"},
                                "end_x": {"type": "number"},
                                "end_y": {"type": "number"},
                            },
                            "required": ["start_x", "start_y", "end_x", "end_y"],
                        },
                    },
                    "labels": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "x": {"type": "number"},
                                "y": {"type": "number"},
                            },
                            "required": ["name", "x", "y"],
                        },
                    },
                    "power_symbols": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "x": {"type": "number"},
                                "y": {"type": "number"},
                            },
                            "required": ["name", "x", "y"],
                        },
                    },
                },
                "required": ["filename", "symbols"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_schematic",
            "description": "기존 .kicad_sch 파일을 읽어서 심볼/배선/라벨 정보 반환",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": ".kicad_sch 파일 경로"},
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "open_in_kicad",
            "description": "파일을 KiCad에서 열기 (.kicad_sch 또는 .kicad_pcb)",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "열 파일 경로"},
                },
                "required": ["filepath"],
            },
        },
    },
    # ── 파일 / 분석 ──
    {
        "type": "function",
        "function": {
            "name": "analyze_image",
            "description": "이미지 파일(회로도, PLC 다이어그램 등)을 GPT-4o Vision으로 분석. "
                           "분석 결과를 텍스트로 반환.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "이미지 파일 경로 (.png, .jpg, .pdf 등)"},
                    "question": {
                        "type": "string",
                        "description": "이미지에 대한 질문 (예: '이 PLC 회로도의 부품 목록과 연결 관계를 알려줘')",
                        "default": "이 이미지의 회로를 상세히 분석해주세요. 부품, 연결, 동작 원리를 설명하세요.",
                    },
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_workspace_files",
            "description": "작업 디렉토리의 파일 목록 반환",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "글로브 패턴 (예: *.kicad_sch)", "default": "*"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_text_file",
            "description": "텍스트 파일 내용 읽기",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "읽을 파일 경로"},
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_text_file",
            "description": "텍스트 파일 쓰기",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "쓸 파일 경로"},
                    "content": {"type": "string", "description": "파일 내용"},
                },
                "required": ["filepath", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_circuit",
            "description": "회로도의 논리적 문제점을 분석 (전원, 바이패스 캡, 미연결 핀 등)",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "분석할 .kicad_sch 파일 경로"},
                },
                "required": ["filepath"],
            },
        },
    },
]


class ToolExecutor:
    """AI 도구 실행기"""

    def __init__(self, kicad_bridge, workspace: Path, vision_callback=None):
        from .kicad_bridge import KiCadBridge
        from .schematic import SchematicGenerator, SchematicParser

        self._bridge: KiCadBridge = kicad_bridge
        self._workspace = Path(workspace)
        self._generator = SchematicGenerator()
        self._parser = SchematicParser()
        self._vision_callback = vision_callback  # agent가 설정
        self._handlers: dict[str, Callable] = {
            # PCB
            "get_board_summary": self._get_board_summary,
            "get_footprints": self._get_footprints,
            "get_tracks": self._get_tracks,
            "get_nets": self._get_nets,
            "get_vias": self._get_vias,
            "get_zones": self._get_zones,
            "add_track": self._add_track,
            "move_footprint": self._move_footprint,
            "save_board": self._save_board,
            "refill_zones": self._refill_zones,
            # 회로도
            "create_schematic": self._create_schematic,
            "read_schematic": self._read_schematic,
            "open_in_kicad": self._open_in_kicad,
            # 파일/분석
            "analyze_image": self._analyze_image,
            "list_workspace_files": self._list_workspace_files,
            "read_text_file": self._read_text_file,
            "write_text_file": self._write_text_file,
            "analyze_circuit": self._analyze_circuit,
        }

    def execute(self, tool_name: str, arguments: dict[str, Any]) -> str:
        handler = self._handlers.get(tool_name)
        if not handler:
            return json.dumps({"error": f"알 수 없는 도구: {tool_name}"})
        try:
            result = handler(**arguments)
            return json.dumps(result, ensure_ascii=False, default=str)
        except Exception as e:
            logger.error("도구 %s 실행 실패: %s", tool_name, e, exc_info=True)
            return json.dumps({"error": str(e)})

    # ── PCB 핸들러 ──

    def _get_board_summary(self) -> dict:
        return self._bridge.get_board_summary()

    def _get_footprints(self) -> list:
        return self._bridge.get_footprints()

    def _get_tracks(self) -> list:
        return self._bridge.get_tracks()

    def _get_nets(self) -> list:
        return self._bridge.get_nets()

    def _get_vias(self) -> list:
        return self._bridge.get_vias()

    def _get_zones(self) -> list:
        return self._bridge.get_zones()

    def _add_track(self, **kwargs) -> dict:
        ok = self._bridge.add_track(**kwargs)
        return {"success": ok}

    def _move_footprint(self, reference: str, dx_mm: float, dy_mm: float) -> dict:
        ok = self._bridge.move_footprint(reference, dx_mm, dy_mm)
        return {"success": ok, "reference": reference}

    def _save_board(self) -> dict:
        return {"success": self._bridge.save_board()}

    def _refill_zones(self) -> dict:
        return {"success": self._bridge.refill_zones()}

    # ── 회로도 핸들러 ──

    def _create_schematic(self, filename: str, symbols: list,
                          wires: list | None = None, labels: list | None = None,
                          power_symbols: list | None = None) -> dict:
        from .schematic import Schematic, Symbol, Wire, Label, PowerSymbol

        sch = Schematic()
        for s in symbols:
            sch.symbols.append(Symbol(
                reference=s["reference"], value=s["value"],
                library_id=s["library_id"], position=(s["x"], s["y"]),
            ))
        for w in (wires or []):
            sch.wires.append(Wire(start=(w["start_x"], w["start_y"]),
                                  end=(w["end_x"], w["end_y"])))
        for lb in (labels or []):
            sch.labels.append(Label(name=lb["name"], position=(lb["x"], lb["y"])))
        for p in (power_symbols or []):
            sch.power_symbols.append(PowerSymbol(name=p["name"], position=(p["x"], p["y"])))

        filepath = self._workspace / filename
        saved = self._generator.save(sch, filepath)
        return {"success": True, "filepath": str(saved),
                "symbol_count": len(sch.symbols), "wire_count": len(sch.wires)}

    def _read_schematic(self, filepath: str) -> dict:
        path = self._resolve_path(filepath)
        sch = self._parser.parse_file(path)
        return {
            "symbols": [{"ref": s.reference, "value": s.value, "lib": s.library_id,
                         "position": list(s.position)} for s in sch.symbols],
            "wires": [{"start": list(w.start), "end": list(w.end)} for w in sch.wires],
            "labels": [{"name": lb.name, "position": list(lb.position)} for lb in sch.labels],
            "power_symbols": [{"name": p.name, "position": list(p.position)} for p in sch.power_symbols],
        }

    def _open_in_kicad(self, filepath: str) -> dict:
        path = self._resolve_path(filepath)
        from .kicad_bridge import KiCadBridge
        ok = KiCadBridge.open_file_in_kicad(str(path))
        return {"success": ok, "filepath": str(path)}

    # ── 이미지 분석 ──

    def _analyze_image(self, filepath: str,
                       question: str = "이 이미지의 회로를 상세히 분석해주세요.") -> dict:
        path = self._resolve_path(filepath)
        if not path.exists():
            return {"error": f"파일이 존재하지 않습니다: {path}"}

        suffix = path.suffix.lower()
        if suffix not in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
            return {"error": f"지원하지 않는 이미지 형식: {suffix}"}

        if self._vision_callback is None:
            return {"error": "Vision 콜백이 설정되지 않았습니다"}

        data = path.read_bytes()
        b64 = base64.b64encode(data).decode("utf-8")
        mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                "gif": "image/gif", "webp": "image/webp", "bmp": "image/bmp"}.get(suffix.lstrip("."), "image/png")

        result = self._vision_callback(b64, mime, question)
        return {"analysis": result, "filepath": str(path)}

    # ── 파일 관리 ──

    def _list_workspace_files(self, pattern: str = "*") -> dict:
        files = []
        for p in sorted(self._workspace.glob(pattern)):
            if p.is_file():
                files.append({"name": p.name, "size": p.stat().st_size, "path": str(p)})
        return {"workspace": str(self._workspace), "files": files}

    def _read_text_file(self, filepath: str) -> dict:
        path = self._resolve_path(filepath)
        if not path.exists():
            return {"error": f"파일이 존재하지 않습니다: {path}"}
        content = path.read_text(encoding="utf-8", errors="replace")
        if len(content) > 50000:
            content = content[:50000] + "\n... (50000자 이후 생략)"
        return {"filepath": str(path), "content": content}

    def _write_text_file(self, filepath: str, content: str) -> dict:
        path = self._resolve_path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return {"success": True, "filepath": str(path), "size": len(content)}

    # ── 회로 분석 ──

    def _analyze_circuit(self, filepath: str) -> dict:
        from .validator import SchematicValidator
        path = self._resolve_path(filepath)
        sch = self._parser.parse_file(path)
        validator = SchematicValidator()
        report = validator.validate(sch)
        return report.to_dict()

    # ── 유틸 ──

    def _resolve_path(self, filepath: str) -> Path:
        p = Path(filepath)
        if not p.is_absolute():
            p = self._workspace / p
        return p.resolve()
