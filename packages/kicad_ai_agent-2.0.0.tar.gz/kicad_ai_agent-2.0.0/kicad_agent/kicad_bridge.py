"""KiCad IPC API 연결 및 제어 모듈

kicad-python (kipy) 라이브러리를 통해 실행 중인 KiCad 인스턴스와 통신합니다.
PCB 편집기 전용 — 회로도 편집기는 KiCad 9/10에서 IPC API 미지원.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class KiCadConnectionInfo:
    connected: bool = False
    version: str = ""
    board_name: str = ""


class KiCadBridge:
    """KiCad IPC API 브릿지 — kipy 래퍼"""

    def __init__(self):
        self._kicad = None
        self._board = None
        self._info = KiCadConnectionInfo()

    # ── 연결 ────────────────────────────────────────────

    @property
    def connected(self) -> bool:
        return self._info.connected

    def connect(self) -> KiCadConnectionInfo:
        try:
            from kipy import KiCad
            self._kicad = KiCad()
            ver = self._kicad.get_version()
            self._info.connected = True
            self._info.version = f"{ver.version.major}.{ver.version.minor}.{ver.version.patch}"
            logger.info("KiCad %s 연결됨", self._info.version)
            return self._info
        except ImportError:
            raise RuntimeError(
                "kicad-python 미설치. 'pip install kicad-python'을 실행하세요."
            )
        except Exception as e:
            raise RuntimeError(
                f"KiCad 연결 실패. KiCad를 실행하고 설정 > 플러그인에서 API를 활성화하세요: {e}"
            )

    # ── 보드 ────────────────────────────────────────────

    def get_board(self):
        self._ensure_connected()
        self._board = self._kicad.get_board()
        self._info.board_name = self._board.name
        return self._board

    def get_board_summary(self) -> dict[str, Any]:
        board = self.get_board()
        footprints = list(board.get_footprints())
        tracks = list(board.get_tracks())
        nets = list(board.get_nets())
        zones = list(board.get_zones())
        vias = list(board.get_vias())

        fp_list = []
        for fp in footprints:
            fp_list.append({
                "reference": self._field_value(fp.reference_field),
                "value": self._field_value(fp.value_field),
                "position": self._vec2_mm(fp.position),
                "layer": fp.layer,
            })

        return {
            "board_name": board.name,
            "statistics": {
                "footprints": len(footprints),
                "tracks": len(tracks),
                "vias": len(vias),
                "nets": len(nets),
                "zones": len(zones),
            },
            "footprints": fp_list,
            "nets": [{"name": n.name} for n in nets],
        }

    # ── 풋프린트 ────────────────────────────────────────

    def get_footprints(self) -> list[dict[str, Any]]:
        board = self.get_board()
        result = []
        for fp in board.get_footprints():
            pads = []
            try:
                for pad in fp.definition.pads:
                    pads.append({
                        "number": pad.number,
                        "net": pad.net.name if pad.net else "",
                        "position": self._vec2_mm(pad.position),
                    })
            except Exception:
                pass
            result.append({
                "reference": self._field_value(fp.reference_field),
                "value": self._field_value(fp.value_field),
                "position": self._vec2_mm(fp.position),
                "layer": fp.layer,
                "pads": pads,
            })
        return result

    def move_footprint(self, reference: str, dx_mm: float, dy_mm: float) -> bool:
        """풋프린트를 상대 좌표로 이동"""
        try:
            from kipy.geometry import Vector2
            board = self.get_board()
            for fp in board.get_footprints():
                if self._field_value(fp.reference_field) == reference:
                    fp.position += Vector2.from_xy_mm(dx_mm, dy_mm)
                    board.update_items(fp)
                    return True
            return False
        except Exception as e:
            logger.error("풋프린트 이동 실패: %s", e)
            return False

    # ── 트랙 ────────────────────────────────────────────

    def get_tracks(self) -> list[dict[str, Any]]:
        from kipy.util.units import to_mm
        board = self.get_board()
        result = []
        for track in board.get_tracks():
            result.append({
                "start": self._vec2_mm(track.start),
                "end": self._vec2_mm(track.end),
                "width_mm": to_mm(track.width),
                "layer": track.layer,
                "net": track.net.name if track.net else "",
            })
        return result

    def add_track(self, start_x: float, start_y: float, end_x: float, end_y: float,
                  width_mm: float = 0.25, layer: str = "F.Cu", net_name: str = "") -> bool:
        try:
            from kipy.board_types import Track, Net
            from kipy.geometry import Vector2
            from kipy.util.units import from_mm
            from kipy.util.board_layer import layer_from_canonical_name

            board = self.get_board()
            track = Track()
            track.start = Vector2.from_xy_mm(start_x, start_y)
            track.end = Vector2.from_xy_mm(end_x, end_y)
            track.width = from_mm(width_mm)
            track.layer = layer_from_canonical_name(layer)

            if net_name:
                for net in board.get_nets():
                    if net.name == net_name:
                        track.net = net
                        break

            board.create_items(track)
            return True
        except Exception as e:
            logger.error("트랙 추가 실패: %s", e)
            return False

    # ── 비아 ────────────────────────────────────────────

    def get_vias(self) -> list[dict[str, Any]]:
        from kipy.util.units import to_mm
        board = self.get_board()
        result = []
        for via in board.get_vias():
            result.append({
                "position": self._vec2_mm(via.position),
                "diameter_mm": to_mm(via.diameter),
                "drill_mm": to_mm(via.drill_diameter),
                "net": via.net.name if via.net else "",
            })
        return result

    # ── 넷 ──────────────────────────────────────────────

    def get_nets(self) -> list[dict[str, Any]]:
        board = self.get_board()
        return [{"name": n.name} for n in board.get_nets()]

    # ── 존 ──────────────────────────────────────────────

    def get_zones(self) -> list[dict[str, Any]]:
        board = self.get_board()
        result = []
        for zone in board.get_zones():
            result.append({
                "name": zone.name,
                "net": zone.net.name if zone.net else "",
                "layers": list(zone.layers),
                "priority": zone.priority,
            })
        return result

    # ── 보드 조작 ───────────────────────────────────────

    def save_board(self) -> bool:
        try:
            board = self.get_board()
            board.save()
            return True
        except Exception as e:
            logger.error("보드 저장 실패: %s", e)
            return False

    def export_gerbers(self, output_dir: str, layers: list[int] | None = None) -> bool:
        try:
            board = self.get_board()
            if layers is None:
                layers = board.get_enabled_layers()
            board.export_gerbers(output_dir, layers)
            return True
        except Exception as e:
            logger.error("거버 내보내기 실패: %s", e)
            return False

    def refill_zones(self) -> bool:
        try:
            board = self.get_board()
            board.refill_zones()
            return True
        except Exception as e:
            logger.error("존 채우기 실패: %s", e)
            return False

    # ── 파일 열기 ───────────────────────────────────────

    @staticmethod
    def open_file_in_kicad(filepath: str) -> bool:
        """KiCad에서 파일을 열기 (새 프로세스)"""
        filepath = Path(filepath).resolve()
        if not filepath.exists():
            logger.error("파일이 존재하지 않습니다: %s", filepath)
            return False
        try:
            if sys.platform == "win32":
                import os
                os.startfile(str(filepath))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(filepath)])
            else:
                subprocess.Popen(["xdg-open", str(filepath)])
            return True
        except Exception as e:
            logger.error("파일 열기 실패: %s", e)
            return False

    # ── 유틸리티 ────────────────────────────────────────

    @staticmethod
    def _field_value(field) -> str:
        try:
            return field.text.value
        except Exception:
            try:
                return str(field)
            except Exception:
                return ""

    @staticmethod
    def _vec2_mm(vec) -> dict[str, float]:
        try:
            from kipy.util.units import to_mm
            return {"x": to_mm(vec.x), "y": to_mm(vec.y)}
        except Exception:
            return {"x": 0.0, "y": 0.0}

    def _ensure_connected(self):
        if not self._info.connected or self._kicad is None:
            raise RuntimeError("KiCad에 연결되지 않았습니다. connect()를 먼저 호출하세요.")
