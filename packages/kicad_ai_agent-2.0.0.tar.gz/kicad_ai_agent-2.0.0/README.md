# KiCad AI Agent v2.0

GPT-4o가 회로를 직접 설계·수정·검증하는 자율형 에이전트.  
대화만 하면 AI가 알아서 KiCad 회로도를 만들고, 이미지(PLC 다이어그램 등)를 분석합니다.

---

## 준비물

| 항목 | 설명 |
|------|------|
| **Python 3.10+** | 이미 설치됨 (venv 포함) |
| **KiCad 9.0+** | *(선택)* PCB 직접 조작 시 필요. 없어도 회로도 파일 생성은 가능 |
| **OpenAI API 키** | `.env` 파일에 이미 설정됨 |

### KiCad 연동 하려면 (선택)
1. KiCad 열기
2. **설정** → **플러그인** → **API 서버 활성화** 체크
3. 그 상태로 KiCad를 켜둔 채 에이전트 실행

> KiCad를 안 켜도 됩니다. 그 경우 회로도 파일(.kicad_sch) 생성 모드로 동작합니다.

---

## 실행 방법

### 1단계: 터미널(PowerShell) 열기

VS Code 터미널이나 Windows PowerShell을 엽니다.

### 2단계: 가상환경 활성화

```powershell
cd "c:\Users\Home PC\Documents\kicad_agent"
.\venv\Scripts\Activate.ps1
```

프롬프트 앞에 `(venv)`가 보이면 성공입니다.

### 3단계: 에이전트 실행

```powershell
kicad-agent
```

그러면 이런 화면이 나옵니다:

```
╔══════════════════════════════════════════════════╗
║           KiCad AI Agent  v2.0                   ║
║   GPT-4o + KiCad IPC API 자율형 회로 설계 에이전트   ║
╚══════════════════════════════════════════════════╝

  ● KiCad 미연결 — 회로도 파일 생성 모드로 동작합니다
  📂 작업 디렉토리: C:\Users\Home PC\Documents\kicad_agent

You: _                 ← 여기에 입력
```

---

## 사용법 (대화형 모드)

`You:` 프롬프트에 원하는 걸 한국어로 입력하면 됩니다.

### 회로 만들기

```
You: NE555 타이머로 LED 깜빡이 회로 만들어줘. 5V 전원, 1초 간격
```

AI가 자동으로:
1. 부품 선정 (NE555, R1, R2, C1, LED, 바이패스캡)
2. `.kicad_sch` 파일 생성
3. 회로 검증
4. 결과 보고

생성된 파일은 작업 디렉토리에 저장됩니다.

### 이미지 분석 (PLC 회로도 등)

**1) 이미지 파일 첨부:**
```
You: /file C:\Users\Home PC\Desktop\plc_diagram.png
```
→ `✓ 이미지 첨부: plc_diagram.png` 메시지 출력

**2) 질문 입력:**
```
You: 이 PLC 회로도를 분석해서 KiCad 회로도로 변환해줘
```

AI가 GPT-4o Vision으로 이미지를 분석하고 회로도를 자동 생성합니다.

### 기존 회로 검토

```
You: projects/ne555_led_blinker.kicad_sch 파일을 검토해줘
```

AI가 파일을 읽고 문제점(전원 누락, 바이패스캡 부족 등)을 찾아 보고합니다.

### PCB 조작 (KiCad 실행 중일 때)

```
You: 현재 보드의 풋프린트 목록을 보여줘
You: R1을 오른쪽으로 5mm 이동해줘
You: 보드를 저장해줘
```

---

## 명령어 모음

`You:` 프롬프트에서 `/`로 시작하는 특수 명령어:

| 명령어 | 설명 | 예시 |
|--------|------|------|
| `/file <경로>` | 이미지 첨부 (다음 메시지에 함께 전송) | `/file C:\circuit.png` |
| `/workspace` | 작업 폴더의 파일 목록 | `/workspace` |
| `/status` | KiCad 연결 상태, 모델 정보 | `/status` |
| `/clear` | 대화 기록 초기화 | `/clear` |
| `/help` | 도움말 | `/help` |
| `quit` | 종료 | `quit` |

---

## 원샷 명령어 (대화 없이 바로 실행)

대화 모드 말고 커맨드 한 줄로 바로 실행할 수도 있습니다:

```powershell
# 회로 생성 → projects 폴더에 저장
kicad-agent create "STM32 최소 회로 + USB-C" -o projects

# 이미지 분석
kicad-agent analyze "C:\Users\Home PC\Desktop\plc.png" -q "이걸 KiCad로 변환해"

# 회로 검토
kicad-agent review projects/my_circuit.kicad_sch
```

---

## 생성된 파일 열기

생성된 `.kicad_sch` 파일을 KiCad에서 열려면:

1. KiCad 실행
2. **파일** → **열기** → `projects` 폴더에서 `.kicad_sch` 파일 선택

또는 대화형 모드에서:
```
You: projects/ne555_led_blinker.kicad_sch 파일을 KiCad에서 열어줘
```

---

## 폴더 구조

```
kicad_agent/
├── .env                 ← OpenAI API 키 (이미 설정됨)
├── venv/                ← Python 가상환경
├── kicad_agent/         ← 에이전트 소스코드
│   ├── agent.py         ← AI 에이전트 코어
│   ├── kicad_bridge.py  ← KiCad IPC API 연결
│   ├── tools.py         ← 18개 AI 도구
│   ├── cli.py           ← 대화형 CLI
│   ├── schematic.py     ← 회로도 파일 생성/파싱
│   └── validator.py     ← 회로 검증
├── projects/            ← 생성된 회로도 저장 위치
└── worker/              ← 웹 서비스 (Cloudflare Workers)
```

---

## 문제 해결

| 증상 | 해결 |
|------|------|
| `kicad-agent 명령을 찾을 수 없음` | `.\venv\Scripts\Activate.ps1` 실행 안 함 |
| `KiCad 연결 실패` | KiCad를 켜고 설정→플러그인→API 활성화 |
| `OpenAI API 오류` | `.env` 파일의 `OPENAI_API_KEY` 확인 |
| 생성된 회로도가 KiCad에서 이상함 | KiCad 9.0+ 필요 (8.x 미지원) |
