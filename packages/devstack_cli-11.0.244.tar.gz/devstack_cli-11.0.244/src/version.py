"""
constants, set by build
"""

MAJOR = '11'
BRANCH_NAME = 'release-11'
BUILD_DATE = '2026-04-02-081752'
SHORT_SHA = '000400e'
VERSION = '11+release-11.2026-04-02-081752.000400e'
