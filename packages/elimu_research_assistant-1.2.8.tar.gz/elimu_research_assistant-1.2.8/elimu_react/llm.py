"""
LLM interface with resilient Gemini model fallback logic.
"""

from __future__ import annotations

from typing import Iterable, List, Optional
import re
import time

from google import genai
from google.genai import types, errors as genai_errors


class LLMInterface:
    """
    Wrapper around Google Gemini models with automatic fallback when a model is
    unavailable (404) or temporarily quota-limited (429/ResourceExhausted).
    """

    def __init__(
        self,
        api_key: str,
        model_candidates: Iterable[str],
        temperature: float = 0.1,
    ) -> None:
        self.client = genai.Client(api_key=api_key)
        self.temperature = temperature
        self.candidates: List[str] = list(dict.fromkeys(model_candidates))  # dedupe
        if not self.candidates:
            raise ValueError("At least one Gemini model must be supplied.")

        self._config = types.GenerateContentConfig(
            temperature=temperature,
            top_p=0.9,
            top_k=32,
            max_output_tokens=8192,
            safety_settings=[
                types.SafetySetting(category="HARM_CATEGORY_HARASSMENT",        threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_HATE_SPEECH",       threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold="BLOCK_NONE"),
                types.SafetySetting(category="HARM_CATEGORY_DANGEROUS_CONTENT", threshold="BLOCK_NONE"),
            ],
        )
        self._active_model_name: Optional[str] = None

    # --------------------------------------------------------------------- public API

    def generate(self, prompt: str, retry_per_model: int = 2) -> str:
        last_error: Optional[Exception] = None

        for candidate in self.candidates:
            for attempt in range(retry_per_model):
                try:
                    response = self.client.models.generate_content(
                        model=candidate,
                        contents=prompt,
                        config=self._config,
                    )
                    if not response.text:
                        raise ValueError("Empty response from Gemini model.")
                    self._active_model_name = candidate
                    return response.text
                except genai_errors.ClientError as exc:
                    last_error = exc
                    if exc.code == 429:  # ResourceExhausted / quota
                        delay = self._retry_delay(exc, attempt)
                        time.sleep(delay)
                        continue
                    break  # 404 not found or other 4xx — try next candidate
                except genai_errors.ServerError as exc:
                    last_error = exc
                    break  # server error — try next candidate
                except Exception as exc:
                    last_error = exc
                    break

        if last_error:
            raise last_error
        raise RuntimeError("LLMInterface failed without receiving an exception.")

    # ------------------------------------------------------------------ helpers

    @staticmethod
    def _retry_delay(exc: Exception, attempt_index: int) -> float:
        message = getattr(exc, "message", None) or str(exc)
        match = re.search(r"retry in ([\d\.]+)s", message)
        if match:
            return max(float(match.group(1)), 0.5)
        match = re.search(r"seconds:\s*(\d+)", message)
        if match:
            return max(float(match.group(1)), 1.0)
        return min(2 ** attempt_index, 8.0)
