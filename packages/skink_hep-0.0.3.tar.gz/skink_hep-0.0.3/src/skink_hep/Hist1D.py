from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib as mpl
import numpy as np
from . import PlotBase, Utils
                                   ######################################################
############################################           Hist Plot Class          ###########################################
                                   ######################################################


class HistogramPlot(PlotBase.PlotBase):

    def __init__(self, bins, xlabel = "X", ylabel = "Y", ratio = False, n_ratios = 1, pull = False, n_pulls = 1,
                 density = False, sizex = 8.75, sizey = 5.92, logx = False, logy = False,
                 plot_unc = True, cpallet = "Bold", ratio_max = 2, ratio_min = 0, pull_max = 2.2, pull_min = -2.2):
        
        # Initialize relevant callable values
        self.histograms = []
        self.bin_edges = bins[0]
        self.bin_centres = bins[1]
        self.colours = Utils.C_Pallets[cpallet]
        self.plot_unc = plot_unc
        self.pull = pull
        self.ratio = ratio
        self.ratio_max = ratio_max
        self.ratio_min = ratio_min
        self.pull_max = pull_max
        self.pull_min = pull_min

        super().__init__(xlabel, ylabel, ratio, n_ratios, pull, n_pulls, density = density,
                         sizex = 5, sizey = 5, logx = logx, logy = logy)

        # adds brazil strips to pull plots
        if pull:
            brazil_alpha = 0.3
            for ax_pull in self.ax_pulls:
                ax_pull.fill_between(x=[self.bin_edges[0],self.bin_edges[-1]],
                                     y1=[1,1],y2=[-1,-1], color = "yellow",
                                     alpha = brazil_alpha, edgecolor = None)
                ax_pull.fill_between(x=[self.bin_edges[0],self.bin_edges[-1]],
                                     y1=[2,2],y2=[1,1], color = "green",
                                     alpha = brazil_alpha, edgecolor=None)
                ax_pull.fill_between(x=[self.bin_edges[0],self.bin_edges[-1]], 
                                     y1=[-1,-1],y2=[-2,-2], color = "green",
                                     alpha = brazil_alpha, edgecolor=None)


    def Add(self, data, weights = None, label = "Add Label !!!!!!!!!!", uncs = None, drawstyle = "steps-mid",
            fill = "00", linewidth = 2, linecolour = None, linestyle = "-", orientation = "vertical",
            reference = False, addthis = True, plotuncs = True, pull_plot = "", ratio_plot = ""):

        # Set weights to one if None given
        weights = np.ones_like(data) if weights is None else weights

        # Bin Data into numpy histogram and get uncertainties and density factors
        uncs = np.sqrt(np.histogram(data, weights = weights**2, bins = self.bin_edges)[0]) if uncs is None else uncs
        data = np.histogram(data, weights = weights, bins = self.bin_edges)[0]

        n_entries = np.sum(weights)
        density_factors = 1/(n_entries*(self.bin_edges[1:] - self.bin_edges[:-1])) if self.density else np.array([1 for b in self.bin_centres])

        # If no uncertatinty given then use sqrt(bin value)
        # / by 1/sqrt(n_entries * bin_width) if density is True
        uncs = density_factors * uncs 

        self.histograms.append({"data":  data,
                                "label": label,
                                "uncs": uncs,
                                "drawstyle": drawstyle,
                                "fill": "ff" if fill == "full" else fill,
                                "linewidth": linewidth,
                                "linecolour": linecolour,
                                "linestyle": linestyle,
                                "orientation": orientation,
                                "reference": reference,
                                "addthis": addthis and not reference,
                                "plotuncs": plotuncs,
                                "pull_plot": pull_plot,
                                "ratio_plot": ratio_plot,
                                "density_factors": density_factors})


    def Plot_Unc(self, axis, hist):

        alpha_unc = 0.3
        axis.fill_between(x = self.bin_centres,
                            y1 = hist["data"] - hist["uncs"], y2 = hist["data"] + hist["uncs"],
                            color = hist["linecolour"], zorder = -1000, step = hist["drawstyle"][-3:], 
                            edgecolor = None, alpha = alpha_unc)


    def Plot_Ratio(self, hist, ratio_labels):
        
        ax_ratio = self.ax_ratios[ratio_labels.index(hist["ratio_plot"])]

        ref_bool = [(hists["reference"] and hists["ratio_plot"] == hist["ratio_plot"]) for hists in self.histograms]

        if np.sum(ref_bool) != 1:
            raise("Wrong Number of Reference Hists Specified !!!")

        ref_hist = self.histograms[np.nonzero(ref_bool)[0][0]]

        ax_ratio.set_ylabel(hist["ratio_plot"]+" Ratios")

        ratio_calcs = Utils.CalcNProp("/", [hist["data"]*hist["density_factors"], hist["uncs"]*hist["density_factors"]],
                                      [ref_hist["data"]*ref_hist["density_factors"],ref_hist["uncs"]*ref_hist["density_factors"]])

        temp_hist = hist.copy()
        temp_hist["fill"] = "00"
        temp_hist["density_factors"] = [1 for b in self.bin_centres]
        temp_hist["data"] = ratio_calcs[0]
        temp_hist["uncs"] = ratio_calcs[1]

        self.Plot_Unc(ax_ratio, temp_hist) if self.plot_unc else None

        ax_ratio.plot(self.bin_centres, temp_hist["data"], color = hist["linecolour"],
                      linewidth = hist["linewidth"], label = temp_hist["label"], 
                      drawstyle = temp_hist["drawstyle"], linestyle = hist["linestyle"],
                      markersize = 0)


    def Plot_Pull(self, hist, pull_labels):

        ax_pull = self.ax_pulls[pull_labels.index(hist["pull_plot"])]

        ref_bool = [(hists["reference"] and hists["pull_plot"] == hist["pull_plot"]) for hists in self.histograms]

        if np.sum(ref_bool) != 1:
            raise("Wrong Number of Refernece Hist Specified !!!")

        ref_hist = self.histograms[np.nonzero(ref_bool)[0][0]]

        ax_pull.set_ylabel(hist["pull_plot"]+" Pulls")

        sub_calc = Utils.CalcNProp("-", [hist["data"]*hist["density_factors"], hist["uncs"]*hist["density_factors"]],
                                   [ref_hist["data"]*ref_hist["density_factors"], ref_hist["uncs"]*ref_hist["density_factors"]])

        data = sub_calc[0]/sub_calc[1]

        temp_hist = hist.copy()
        temp_hist["fill"] = "00"
        temp_hist["density_factors"] = [1 for b in self.bin_centres]
        temp_hist["data"] = data
        temp_hist["uncs"] = None


        ax_pull.plot(self.bin_centres, temp_hist["data"], color = hist["linecolour"],
                      linewidth = hist["linewidth"], label = temp_hist["label"], 
                      drawstyle = temp_hist["drawstyle"], linestyle = hist["linestyle"],
                      markersize = 0)


    def Plot(self, plot_path, frame = False):

        if self.ratio:
            # Get Ratio Plot labels
            ratio_labels = [hists["ratio_plot"] for hists in self.histograms]
            ratio_labels = list(dict.fromkeys(ratio_labels))
            if len(ratio_labels) != self.n_ratios:
                raise("Wrong Number of ratio labels specified!!!")

        if self.pull:
            # Get Pull Plot labels
            pull_labels = [hists["pull_plot"] for hists in self.histograms]
            pull_labels = list(dict.fromkeys(pull_labels))
            if len(pull_labels) != self.n_pulls:
                raise("Wrong Number of pull labels specified!!!")

        # Plot each histogram on primary axis
        for count, hist in enumerate(self.histograms):

            hist["linecolour"] = hist["linecolour"] if hist["linecolour"] is not None else self.colours[list(self.colours.keys())[count]]
        
            # Uncertainty Plotting
            self.Plot_Unc(self.ax_primary, hist) if self.plot_unc and hist["plotuncs"] else None
            self.ax_primary.plot(self.bin_centres, hist["data"]*hist["density_factors"],
                                 color = hist["linecolour"], linewidth = hist["linewidth"],
                                 label = hist["label"], drawstyle = hist["drawstyle"],
                                 linestyle = hist["linestyle"], markersize = 0)

            # Ratio Plotting
            self.Plot_Ratio(hist, ratio_labels) if self.ratio and hist["addthis"] else None

            # Pull Plotting
            self.Plot_Pull(hist, pull_labels) if self.pull and hist["addthis"] else None


        self.ax_primary.set_ylim(bottom=0, top = self.ax_primary.get_ylim()[1]*1.1)
        self.ax_primary.set_xlim(left = self.bin_centres[0], right = self.bin_centres[-1])

        if self.ratio:
            for ax_ratio in self.ax_ratios:
                ax_ratio.set_ylim(top = min(self.ratio_max, ax_ratio.get_ylim()[1]),
                                 bottom = max(self.ratio_min, ax_ratio.get_ylim()[0]))
                ax_ratio.set_xlim(left = self.bin_centres[0], right = self.bin_centres[-1])

        if self.pull:
            for ax_pull in self.ax_pulls:
                ax_pull.set_ylim(top = min(self.pull_max, ax_pull.get_ylim()[1]),
                                 bottom = max(self.pull_min, ax_pull.get_ylim()[0]))
                ax_pull.set_xlim(left = self.bin_centres[0], right = self.bin_centres[-1])

        self.ax_primary.set_yscale("log") if self.logy else None
        self.ax_primary.set_xscale("log") if self.logx else None

        self.ax_primary.legend()

        if self.ax_ratios is not None and self.logx:
            for ax_ratio in self.ax_ratios:
                ax_ratios.set_xscale("log")

        if self.ax_pulls is not None and self.logx:
            for ax_pull in self.ax_pulls:
                ax_pull.set_xscale("log")

        plt.draw()

        plt.savefig(plot_path+".pdf", bbox_inches = "tight")
        plt.savefig(plot_path+".png", bbox_inches = "tight")

        plt.close(self.figure)
