from . import Utils, PlotBase, Hist1D, Line, Hist2D

# Sets the style using the default rc params file
Utils.usestyle()
