from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib as mpl
import numpy as np
from . import PlotBase, Utils

                                   ######################################################
############################################           Line Plot Class          ###########################################
                                   ######################################################


class LinePlot(PlotBase.PlotBase):
    
    def __init__(self, xs, xlabel = "X", ylabel = "Y", ratio = False, n_ratios = 1, pull = False, n_pulls = 1,
                  sizex = 8.75, sizey = 5.92, logx = False, logy = False, plot_unc = True,
                  cpallet = "Bold", ratio_max = 2, ratio_min = 0, pull_max = 2.2, pull_min = -2.2):
       
        # Initialize relevant callable values
        self.lines = []
        self.xs = xs
        self.colours = Utils.C_Pallets[cpallet]
        self.plot_unc = plot_unc
        self.pull = pull
        self.ratio = ratio
        self.ratio_max = ratio_max
        self.ratio_min = ratio_min
        self.pull_max = pull_max
        self.pull_min = pull_min

        super().__init__(xlabel, ylabel, ratio, n_ratios, pull, n_pulls,
                         sizex = 5, sizey = 5, logx = logx, logy = logy)
        if pull:
            brazil_alpha = 0.3
            for ax_pull in self.ax_pulls:
                ax_pull.fill_between(x=[xs[0],xs[-1]], y1=[1,1],y2=[-1,-1],
                                     color = "yellow", alpha = brazil_alpha, edgecolor = None)
                ax_pull.fill_between(x=[xs[0],xs[-1]], y1=[2,2],y2=[1,1],
                                     color = "green", alpha = brazil_alpha, edgecolor=None)
                ax_pull.fill_between(x=[xs[0],xs[-1]], y1=[-1,-1],y2=[-2,-2],
                                     color = "green", alpha = brazil_alpha, edgecolor=None)

    
    def Add(self, ys, label = "Add Label !!!!!!!!!!", uncs = None, drawstyle = "default", 
            linewidth = 2, linecolour = None, linestyle = "-",  marker = ".", marker_size = 10,
            reference = False, addthis = True, plotuncs = False, unctype = "fill",
            pull_plot = "", ratio_plot = ""):

        # Force data to be in binned form
        if len(ys) != len(self.xs):
            raise("xs & ys Not Same Shape !!!!")

        # If no uncertatinty given and plot_unc = True require uncs
        if self.plot_unc and uncs is None:
            raise("Plot Uncertainty True but No Uncertainty Given!!!!")         

        self.lines.append({"ys":  np.array(ys),
                           "label": label,
                           "uncs": np.array(uncs),
                           "drawstyle": drawstyle,
                           "linewidth": linewidth,
                           "linecolour": linecolour,
                           "linestyle": linestyle,
                           "marker": marker,
                           "marker_size": marker_size,
                           "reference": reference,
                           "addthis": addthis and not reference,
                           "plotuncs": plotuncs,
                           "unctype": unctype,
                           "pull_plot": pull_plot,
                           "ratio_plot": ratio_plot})


    def Plot_Unc(self, axis, line):

        if line["unctype"] == "fill":            
            axis.fill_between(x = self.xs,
                              y1 = line["ys"] - line["uncs"],
                              y2 = line["ys"] + line["uncs"],
                              color = line["linecolour"], zorder = 1, edgecolor = None, alpha = 0.3)
                            
        elif line["unctype"] == "bars":        
            axis.errorbar(self.xs, 
                          line["ys"],
                          line["uncs"],
                          ls = "none",
                          ecolor = line["linecolour"])

    def Plot_Ratio(self, line, ratio_labels):

        ax_ratio = self.ax_ratios[ratio_labels.index(line["ratio_plot"])]

        ref_bool = [(lines["reference"] and lines["ratio_plot"] == line["ratio_plot"]) for lines in self.lines]

        if np.sum(ref_bool) != 1:
            raise("Wrong Number of Reference Lines Specified !!!")

        ref_line = self.lines[np.nonzero(ref_bool)[0][0]]

        ax_ratio.set_ylabel(line["ratio_plot"]+" Ratios")

        temp_line = line.copy()
        temp_line["ys"] = ref_line["ys"]/line["ys"]
        temp_line["uncs"] = (line["ys"]/ref_line["ys"]) * np.sqrt((ref_line["uncs"]/ref_line["ys"])**2 + (line["uncs"]/line["ys"])**2) if self.plot_unc else None

        self.Plot_Unc(self.ax_ratio, temp_line) if self.plot_unc else None

        ax_ratio.plot(self.xs, temp_line["ys"], color = temp_line["linecolour"], linestyle = temp_line["linestyle"],
                      marker = temp_line["marker"], linewidth = temp_line["linewidth"],
                      ms = temp_line["marker_size"], label = temp_line["label"], drawstyle = temp_line["drawstyle"])


    def Plot_pull(self, line, pull_labels):

        ax_pull = self.ax_pulls[pull_labels.index(line["pull_plot"])]

        ref_bool = [(lines["reference"] and lines["pull_plot"] == line["pull_plot"]) for lines in self.lines]

        if np.sum(ref_bool) != 1:
            raise("Wrong Number of Refernece Lines Specified !!!")

        ref_hist = self.lines[np.nonzero(ref_bool)[0][0]]

        ax_pull.set_ylabel(line["pull_plot"]+" Pulls")

        diff = CalcNProp("-", [ref_line["ys"], ref_line["uncs"]], [line["ys"], line["uncs"]])

        temp_line = line.copy()
        temp_line["ys"] = (diff[0])/(diff[1])
        temp_line["uncs"] = None

        ax_pull.plot(self.xs, temp_line["ys"], color = temp_line["linecolour"], linestyle = temp_line["linestyle"],
                      marker = temp_line["marker"], linewidth = temp_line["linewidth"],
                      ms = temp_line["marker_size"], label = temp_line["label"], drawstyle = temp_line["drawstyle"])


    def Plot(self, plot_path, frame = False, ymax = None, ymin = None):

        if self.ratio:
            # Get Ratio Plot labels
            ratio_labels = [lines["ratio_plot"] for lines in self.lines]
            ratio_labels = list(dict.fromkeys(ratio_labels))
            if len(ratio_labels) != self.n_ratios:
                raise("Wrong Number of ratio labels specified!!!")

        if self.pull:
            # Get Pull Plot labels
            pull_labels = [lines["pull_plot"] for lines in self.lines]
            pull_labels = list(dict.fromkeys(pull_labels))
            if len(pull_labels) != self.n_pulls:
                raise("Wrong Number of pull labels specified!!!")

        # Plot each line on primary axis
        for count, line in enumerate(self.lines):

            line["linecolour"] = line["linecolour"] if line["linecolour"] is not None else self.colours[list(self.colours.keys())[count]]
    
            # Uncertainty Plotting
            self.Plot_Unc(self.ax_primary, line) if self.plot_unc and line["plotuncs"] else None
            self.ax_primary.plot(self.xs, line["ys"], color = line["linecolour"], linestyle = line["linestyle"],
                                marker = line["marker"], linewidth = line["linewidth"],
                                ms = line["marker_size"], label = line["label"], drawstyle = line["drawstyle"])

            # Ratio Plotting
            self.Plot_Ratio(line, ratio_labels) if self.ratio and line["addthis"] else None

            # pull Plotting
            self.Plot_pull(line, pull_labels) if self.pull and line["addthis"] else None

        self.ax_primary.set_ylim(bottom=0, top = self.ax_primary.get_ylim()[1]*1.1)
        self.ax_primary.set_xlim(left = self.xs[0], right = self.xs[-1])

        if self.ratio:
            for ax_ratio in self.ax_ratios:
                ax_ratio.set_ylim(top = min(self.ratio_max, ax_ratio.get_ylim()[1]),
                                 bottom = max(self.ratio_min, ax_ratio.get_ylim()[0]))
                ax_ratio.set_xlim(left = self.xs[0], right = self.xs[-1])

        if self.pull:
            for ax_pull in self.ax_pulls:
                ax_pull.set_ylim(top = min(self.pull_max, ax_pull.get_ylim()[1]),
                                 bottom = max(self.pull_min, ax_pull.get_ylim()[0]))
                ax_pull.set_xlim(left = self.xs[0], right = self.xs[-1])

        self.ax_primary.set_yscale("log") if self.logy else None
        self.ax_primary.set_xscale("log") if self.logx else None

        self.ax_primary.legend()

        if self.ax_ratios is not None and self.logx:
            for ax_ratio in self.ax_ratios:
                ax_ratio.set_xscale("log")

        if self.ax_pulls is not None and self.logx:
            for ax_pull in self.ax_pulls:
                ax_pull.set_xscale("log")

        plt.draw()

        plt.savefig(plot_path+".pdf", bbox_inches = "tight")
        plt.savefig(plot_path+".png", bbox_inches = "tight")

        plt.close(self.figure)


