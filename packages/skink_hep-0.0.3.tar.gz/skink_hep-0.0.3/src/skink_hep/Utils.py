from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from pathlib import Path
import matplotlib as mpl
import numpy as np

# Dictionary of colours

C_Pallets = {"Pastel": {"Orange" : "#E78AA1",
                        "Blue" : "#11B7E0",
                        "Green" : "#00B689",
                        "Red" : "#DE0C62",
                        "Purple" : "#9213E0",},

             "Bold": {"Orange" : "#ff6600",
                      "Blue" : "#0033cc",
                      "Green" : "#009933",
                      "Red" : "#b80053",
                      "Purple" : "#670178",
                      "Yellow" : "#FFD700",
                      "Cyan" : "#00FFFF",
                      "Lime Green" : "#32CD32"}
            }

# Font Dictionaries for ATLAS name
text_fd = dict(ha='left', va='center')
atlas_fd = dict(weight='bold', style='italic', size=18, **text_fd)
internal_fd = dict(size=18, **text_fd)


                                   ######################################################
##############################################       Misc Plot Functions      ###########################################
                                   ######################################################

# Simple function for grabbing which colour we want
# style can be Bold or Pastel
# index can be string (colour name) or int (colour index)
def get_colour(style, index):

    return C_Pallets[style][list(C_Pallets[style].keys())[index]] if type(index) == int else C_Pallets[style][name]

# Simple function for creating bin edges and bin centres for use in plotting    
def get_bins(xmin, xmax, nbins):
    
    bin_edges = np.linspace(xmin,xmax,nbins+1)
    bin_centres = (bin_edges[:-1]+bin_edges[1:])/2
    
    return [bin_edges,bin_centres]


# Function for propogating uncertainties when performing opertations
# Inputs in form of lists with 1st element values and second element the uncertainties
def CalcNProp(operation, xs, ys):
    # Available operations:
    # - Additon/Subtraction
    # - Multiplication/Division
    # - Square and Square root

    if xs[0].shape != ys[0].shape:
        raise("xs and ys not same shape!")
    if xs[1].shape != ys[1].shape:
        raise("xs and ys uncs not same shape!")
    if xs[0].shape != xs[1].shape:
        raise("xs and xs uncs not same shape!")


    zs = [0,0]

    if operation == "+" or operation == "-":
        if operation == "+":
            zs[0] = xs[0] + ys[0]
        elif operation == "-":
            zs[0] = xs[0] - ys[0]

        # Z = X + Y -> DZ = sqrt(DX^2 + DY^2)
        zs[1] = np.sqrt(xs[1]**2 + ys[1]**2)

    elif operation == "*" or operation == "/":
        if operation == "*":
            zs[0] = xs[0] * ys[0]
        elif operation == "/":
            zs[0] = xs[0] / ys[0]

        # Z = X * Y -> DZ/Z = sqrt((DX/X)^2 + (DY/Y)^2)
        zs[1] = zs[0]*np.sqrt((xs[1]/xs[0])**2 + (ys[1]/ys[0])**2)

    elif operation == "**2":
        if ys is not None:
            raise("ys are not None!!!")
        zs[0] = xs[0]**2
        
        # Z = X**2 -> DZ = 2X*DX
        zs[1] = 2*xs[0]*xs[1]

    elif operation == "sqrt":
        if ys is not None:
            raise("ys are not None!!!")        
        zs[0] = np.sqrt(xs[0])

        # Z = sqrt(X) -> DZ = DX/(2sqrt(X))
        zs[1] = xs[1]/(2*np.sqrt(xs[0]))

    else:
        raise("Unkown Operation!!!!")

    return np.array(zs)


# returns the mean and the standard error on the mean
def get_mean(array):

    mean = np.mean(array)
    std = np.std(array)
    n = np.array(array.shape)[0]

    return mean, std/np.sqrt(n)


# Returns the mean and the standard error on the mean
# Assumes Gaussian!!!!!
def get_std(array):

    std = np.std(array)
    n = np.array(array.shape)[0]

    return std, std/np.sqrt(2*n - 2)


# Choose plot style e.g. use ATLAS etc
def usestyle(choice = "default"):

    base_path = Path(__file__).parent.absolute()

    style_map = {"default": base_path / "styles" / "style_params.mplstyle",
                 "ATLAS": base_path / "styles" / "atlas.mplstyle"}

    if choice not in style_map:
        # Use ValueError for bad arguments; raise requires an Exception object
        raise ValueError(f"Unknown style choice: '{choice}'. Valid options: {list(style_map.keys())}")

    style_path = style_map[choice]

    if not style_path.exists():
        raise FileNotFoundError(f"Style file not found at: {style_path}")

    plt.style.use(str(style_path))