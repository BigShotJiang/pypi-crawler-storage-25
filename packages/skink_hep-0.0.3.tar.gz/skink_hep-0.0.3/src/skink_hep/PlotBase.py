from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib as mpl
import numpy as np

def format_subfigures(name, n_ax, n_init, gs, xlabel):

    temp_ax = []

    for n in range(n_ax):
        # Append additional axis under primary plot
        temp_ax.append(plt.subplot(gs[n + n_init]))

        temp_ax[n].set_xlabel(xlabel if n + 1 == n_ax else "")
        temp_ax[n].tick_params(labelbottom = False) if n+1 != n_ax else None

        temp_ax[n].set_ylabel(name)

    return temp_ax

                                   ######################################################
##############################################         Plot Base Class        ###########################################
                                   ######################################################


class PlotBase:

    def __init__(self, xlabel, ylabel, ratio = False, n_ratios = 1, pull = False, n_pulls = 1,
                 density = False, sizex = 8.75, sizey = 5.92, logx = False, logy = False):

        # Get number of additional figures and relative sizes
        n_add = int(ratio) + n_ratios + int(pull) + n_pulls - 2
        height_ratios = [1] * (n_add + 1)
        height_ratios[0] = 3

        # Create figure and axes 
        fig = plt.figure(2, figsize = (sizex, sizey + 1.2 * n_add))
        gs = mpl.gridspec.GridSpec(1 + n_add, 1, height_ratios = height_ratios, wspace = None,
                                                                                hspace = 0.1)

        # Set all the inputs
        self.figure = fig
        self.ax_primary = plt.subplot(gs[0])
        self.density = density
        self.logy = logy
        self.logx = logx
        self.ratio = ratio
        self.n_ratios = n_ratios
        self.pull = pull
        self.n_pulls = n_pulls

        # Set up Labels & axis ticks
        self.ax_primary.set_xlabel(xlabel)
        self.ax_primary.set_ylabel("Density from " + ylabel if density else ylabel)

        # Remove primary xlabel so label goes on add_ax at bottom
        self.ax_primary.tick_params(labelbottom = False) if self.ratio or self.pull else None

        # Creates and configure additional axis
        
        # Ratios
        self.ax_ratios = None
        if ratio:
            self.ax_ratios = format_subfigures("Ratio", n_ratios, 1, gs, xlabel)

        # Pulls
        self.ax_pulls = None
        if self.pull:
            self.ax_pulls = format_subfigures("Pulls", n_pulls, n_ratios + int(ratio), gs, xlabel)
            self.ax_ratios[-1].set_xlabel("") if ratio else None
            self.ax_ratios[-1].tick_params(labelbottom = False) if ratio else None


    def Text(self, text, xpos = 0, ypos = 1, size = 14):
        self.figure.text(x = xpos, y = ypos ,s = text, size = size)



