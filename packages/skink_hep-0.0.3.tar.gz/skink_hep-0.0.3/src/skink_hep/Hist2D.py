from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib as mpl
import numpy as np
from . import PlotBase

                                   ######################################################
############################################          Hist2D Plot Class         ###########################################
                                   ######################################################

class Hist2D(PlotBase.PlotBase):

    def __init__(self, xbins, ybins, xlabel = "X", ylabel = "Y", cmap = "cividis", sizex = 5, sizey = 5, margins = True, plot_unc = True, cbar = False):
        
        # Initialize relevant callable values
        self.xbin_edges = xbins[0]
        self.xbin_centres = xbins[1]
        self.ybin_edges = ybins[0]
        self.ybin_centres = ybins[1]
        self.cmap = cmap
        self.margins = margins
        self.plot_unc = plot_unc
        self.cbar = cbar

        super().__init__(xlabel, ylabel, sizex = 5, sizey = 5)


    def Set(self, xdata, ydata, weights = None, zlabel = "Add Label!!!", colour = "#0000FF", fill = "90", linecolour = "black", linewidth = 1.5, cmin = None, cmax = None):

        # Set weights to one if None given
        weights = np.ones_like(xdata) if weights is None else weights

        self.hist = {"xdata":  xdata,
                     "ydata": ydata,
                     "weights": weights,
                     "cmin": cmin,
                     "cmax": cmax,
                     "zlabel": zlabel,
                     ## The rest is for margins
                     "colour": colour,
                     "fill": fill,
                     "linecolour": linecolour,
                     "linewidth": linewidth
                     }
        
    def PlotMargins(self):
        
        divider = make_axes_locatable(self.ax_primary)

        ax_histx = divider.append_axes("top", 0.6, pad=0, sharex=self.ax_primary)
        ax_histy = divider.append_axes("right", 0.6, pad= -0.03 if self.plot_unc else 0, sharey=self.ax_primary)

        ax_histx.axis("off")
        ax_histy.axis("off")

        self.PlotUnc(ax_histx, self.hist["xdata"], self.xbin_edges, self.xbin_centres)
        self.PlotUnc(ax_histy, self.hist["ydata"], self.ybin_edges, self.ybin_centres)

        ax_histx.hist(self.hist["xdata"], self.xbin_edges, fc = self.hist["colour"] + "90", ec = "black", linewidth = 1.5)
        ax_histy.hist(self.hist["ydata"], self.ybin_edges, fc = self.hist["colour"] + "90", ec = "black", linewidth = 1.5, orientation = "horizontal")

    def PlotUnc(self, axis, data, bin_edges, bin_centres):

        data_hist = np.histogram(data, bin_edges)[0]

        hist = {"data": data_hist,
                "uncs": np.sqrt(data_hist)}

        # Do errors for each bin rather than whole plot so that gaps can occur when shrink != None
        for bin_N in range(len(bin_centres)):

            x1 = bin_edges[bin_N]
            x2 = bin_edges[bin_N+1]

            # split into upper and lower error for alpha matching whith overlap with transparent hist

            # Adding alphas is non-linear
            # For alpha_a on top of alpha_b alpha_both = alpha_a +(1-alpha_a)*alpha_b
            # In this case, alpha_a = fill_alpha/255 and alha_b = 0.3 
            alpha_unc = 0.3
            
            # Lower            
            axis.fill_between(x = [x1,x2],
                              y1 = [hist["data"][bin_N] - hist["uncs"][bin_N], hist["data"][bin_N] - hist["uncs"][bin_N]],
                              y2 = [hist["data"][bin_N], hist["data"][bin_N]],
                              color = self.hist["colour"], zorder = 1, step = "pre", edgecolor = None, alpha = alpha_unc)

            # Upper 
            axis.fill_between(x = [x1,x2],
                              y1 = [hist["data"][bin_N], hist["data"][bin_N]],
                              y2 = [hist["data"][bin_N] + hist["uncs"][bin_N], hist["data"][bin_N] + hist["uncs"][bin_N]],
                              color = self.hist["colour"], zorder = 1, step = "pre", edgecolor = None, alpha = min(alpha_unc + (1-alpha_unc)*(int(self.hist["fill"],16)/255), 1))

    def Plot(self, plot_path):

    
        h = self.ax_primary.hist2d(self.hist["xdata"],self.hist["ydata"], bins = [self.xbin_edges, self.ybin_edges],
                                   weights = self.hist["weights"],
                                   cmap = "cividis",
                                   cmin = self.hist["cmin"],
                                   cmax = self.hist["cmax"])

        self.PlotMargins() if self.margins else None

        if self.cbar:
            cbar = plt.colorbar(h[3])
            cbar.set_label(self.hist["zlabel"])

        plt.draw()

        plt.savefig(plot_path+".pdf", bbox_inches = "tight")
        plt.savefig(plot_path+".png", bbox_inches = "tight")

        plt.close(self.figure)
