from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from lingclaude.core.types import Result

_PROTECTED_PATHS: tuple[str, ...] = (
    "/etc/",
    "/sys/",
    "/proc/",
    "/dev/",
    "/boot/",
    "/root/",
    "/var/log/",
    "/run/",
)


@dataclass(frozen=True)
class FileInfo:
    path: str
    content: str
    size: int
    encoding: str = "utf-8"

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "size": self.size,
            "encoding": self.encoding,
        }


class FileOps:
    def __init__(self, base_dir: str = ".", allow_escape: bool = False) -> None:
        self.base_dir = Path(base_dir).resolve()
        self.allow_escape = allow_escape

    def read(self, path: str) -> Result[FileInfo]:
        target_result = self._resolve(path)
        if target_result.is_error:
            return target_result  # type: ignore[return-value]
        target = target_result.data

        if not target.exists():
            return Result.fail(f"File not found: {path}")
        if not target.is_file():
            return Result.fail(f"Not a file: {path}")

        try:
            content = target.read_text(encoding="utf-8")
            return Result.ok(
                FileInfo(
                    path=str(target),
                    content=content,
                    size=target.stat().st_size,
                )
            )
        except Exception as e:
            return Result.fail(f"Read error: {e}")

    def write(self, path: str, content: str) -> Result[str]:
        target_result = self._resolve(path)
        if target_result.is_error:
            return target_result  # type: ignore[return-value]
        target = target_result.data

        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            return Result.ok(str(target))
        except Exception as e:
            return Result.fail(f"Write error: {e}")

    def edit(
        self, path: str, old_text: str, new_text: str, replace_all: bool = False
    ) -> Result[str]:
        read_result = self.read(path)
        if read_result.is_error:
            return read_result  # type: ignore[return-value]

        content = read_result.data.content
        count = content.count(old_text)
        if count == 0:
            return Result.fail(f"Text not found in {path}")
        if count > 1 and not replace_all:
            return Result.fail(
                f"Multiple matches ({count}) in {path}, use replace_all=True"
            )

        new_content = content.replace(old_text, new_text) if replace_all else content.replace(old_text, new_text, 1)
        write_result = self.write(path, new_content)
        return write_result

    def glob(self, pattern: str) -> Result[tuple[str, ...]]:
        try:
            matches = sorted(self.base_dir.glob(pattern))
            return Result.ok(tuple(str(m.relative_to(self.base_dir)) for m in matches if m.is_file()))
        except Exception as e:
            return Result.fail(f"Glob error: {e}")

    def grep(
        self, pattern: str, include: str = "*.py"
    ) -> Result[tuple[dict[str, Any], ...]]:
        import re

        try:
            regex = re.compile(pattern)
        except re.error as e:
            return Result.fail(f"Invalid regex pattern: {e}")

        results: list[dict[str, Any]] = []

        try:
            for file_path in self.base_dir.rglob(include):
                if not file_path.is_file():
                    continue
                try:
                    for i, line in enumerate(
                        file_path.read_text(encoding="utf-8").splitlines(), 1
                    ):
                        if regex.search(line):
                            results.append(
                                {
                                    "file": str(
                                        file_path.relative_to(self.base_dir)
                                    ),
                                    "line": i,
                                    "content": line.strip(),
                                }
                            )
                except Exception:
                    continue
        except Exception as e:
            return Result.fail(f"Grep error: {e}")

        return Result.ok(tuple(results))

    def exists(self, path: str) -> bool:
        result = self._resolve(path)
        if result.is_error:
            return False
        return result.data.exists()

    def delete(self, path: str) -> Result[str]:
        target_result = self._resolve(path)
        if target_result.is_error:
            return target_result  # type: ignore[return-value]
        target = target_result.data

        if not target.exists():
            return Result.fail(f"Not found: {path}")
        try:
            if target.is_dir():
                import shutil
                shutil.rmtree(target)
            else:
                target.unlink()
            return Result.ok(str(target))
        except Exception as e:
            return Result.fail(f"Delete error: {e}")

    def _resolve(self, path: str) -> Result[Path]:
        p = Path(path)
        if p.is_absolute():
            resolved = p.resolve()
        else:
            resolved = (self.base_dir / p).resolve()

        if self.allow_escape:
            for protected in _PROTECTED_PATHS:
                prot_path = Path(protected)
                if resolved.is_relative_to(prot_path):
                    return Result.fail(
                        f"敏感路径被保护: {path}（{resolved} 在受保护目录 {protected} 下）。"
                        f"此路径始终不可访问，即使启用了 allow_escape"
                    )
            return Result.ok(resolved)

        if not resolved.is_relative_to(self.base_dir):
            return Result.fail(
                f"路径超出项目范围: {path}（解析到 {resolved}，"
                f"允许范围 {self.base_dir}）。如需访问项目外文件，"
                f"请在配置中启用 allow_escape"
            )

        if resolved != (self.base_dir / p).resolve() and not p.is_absolute():
            return Result.fail(
                f"路径遍历被阻止: {path} 包含 '..' 组件，"
                f"解析到 {resolved}。请使用项目内相对路径"
            )

        return Result.ok(resolved)
